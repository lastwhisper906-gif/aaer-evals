# LOGI notes — 0001032975-15-000023


## logi:ScheduleOfAssumptionsForSharebasedAwardsTableTextBlock

[0001032975-15-000023:notes:1]
The grant date fair value of the awards using the Black-Scholes-Metron option-pricing valuation model and Monte-Carlo simulation method are determined applying the following assumptions and values:

[0001032975-15-000023:notes:2]
|  |  | Employee Purchase Plans |  | Stock Option Plans |  | Premium Priced Options |  | Market-based StockOption Plan |
|  |  | Fiscal Years EndedMarch 31, |  | Fiscal Years EndedMarch 31, |  | Fiscal Years EndedMarch 31, |  | Fiscal Years EndedMarch 31, |
|  |  | 2015 |  | 2014 |  | 2013 |  | 2015 |  | 2014 |  | 2013 |  | 2015 |  | 2014 |  | 2013 |  | 2015 |  | 2014 |  | 2013 |
| Dividend yield |  | 1.97 | % |  | 0.43 | % |  | — | % |  | n/a |  | n/a |  | —% |  | n/a |  | n/a |  | —% |  | n/a |  | n/a |  | —% |
| Risk-free interest rate |  | 0.14 | % |  | 0.07 | % |  | 0.09 | % |  | n/a |  | n/a |  | 1.20% |  | n/a |  | n/a |  | 2.00% |  | n/a |  | n/a |  | 1.93% |
| Expected volatility |  | 30 | % |  | 36 | % |  | 47 | % |  | n/a |  | n/a |  | 46% |  | n/a |  | n/a |  | 46% |  | n/a |  | n/a |  | 44% |
| Expected life (years) |  | 0.6 |  |  | 0.5 |  |  | 0.5 |  |  | n/a |  | n/a |  | 6.0 |  | n/a |  | n/a |  | 7.0 |  | n/a |  | n/a |  | 6.0 |
| Weighted average fair value |  | $ | 3.18 |  |  | $ | 2.46 |  |  | $ | 2.14 |  |  | n/a |  | n/a |  | $3.64 |  | n/a |  | n/a |  | $2.52 |  | n/a |  | n/a |  | $2.58 |

[0001032975-15-000023:notes:3]
| Market-based RSUs |  | Years Ended March 31, |
|  |  | 2015 |  | 2014 |  | 2013 |
| Dividend yield |  | 1.86 | % |  | 0.75 | % |  | — | % |
| Risk-free interest rate |  | 0.83 | % |  | 1.09 | % |  | 0.31 | % |
| Expected volatility |  | 46 | % |  | 46 | % |  | 47 | % |
| Expected life (years) |  | 3.0 |  |  | 2.9 |  |  | 3.0 |  |


## logi:ScheduleOfBalanceSheetComponentsAssetsTableTextBlock

[0001032975-15-000023:notes:4]
The following table presents the components of certain balance sheet asset amounts as of March 31, 2015 and 2014 (in thousands):

[0001032975-15-000023:notes:5]
|  |  | March 31, |
|  |  | 2015 |  | 2014 |
| Accounts receivable: |  |  |  |  |  |
| Accounts receivable |  | $ | 344,455 |  |  | $ | 338,194 |  |
| Allowance for doubtful accounts |  | (1,093 | ) |  | (1,712 | ) |
| Allowance for sales returns |  | (17,901 | ) |  | (19,472 | ) |
| Allowance for cooperative marketing arrangements |  | (25,700 | ) |  | (24,135 | ) |
| Allowance for customer incentive programs |  | (48,497 | ) |  | (41,400 | ) |
| Allowance for pricing programs |  | (71,441 | ) |  | (69,446 | ) |
|  |  | $ | 179,823 |  |  | $ | 182,029 |  |
| Inventories: |  |  |  |  |  |  |
| Raw materials |  | $ | 36,376 |  |  | $ | 24,031 |  |
| Work-in-process |  | — |  |  | 42 |  |
| Finished goods |  | 234,354 |  |  | 198,329 |  |
|  |  | $ | 270,730 |  |  | $ | 222,402 |  |
| Other current assets: |  |  |  |  |  |  |
| Income tax and value-added tax receivables |  | $ | 19,403 |  |  | $ | 18,252 |  |
| Deferred tax assets |  | 27,790 |  |  | 27,013 |  |
| Prepaid expenses and other assets |  | 17,236 |  |  | 13,892 |  |
|  |  | $ | 64,429 |  |  | $ | 59,157 |  |
| Property, plant and equipment, net: |  |  |  |  |  |  |
| Plant, buildings and improvements |  | $ | 63,049 |  |  | $ | 69,897 |  |
| Equipment |  | 138,772 |  |  | 134,975 |  |
| Computer equipment |  | 37,835 |  |  | 40,610 |  |
| Software |  | 77,792 |  |  | 81,179 |  |
|  |  | 317,448 |  |  | 326,661 |  |
| Less accumulated depreciation and amortization |  | (257,642 | ) |  | (256,424 | ) |
|  |  | 59,806 |  |  | 70,237 |  |
| Construction-in-process |  | 29,040 |  |  | 15,362 |  |
| Land |  | 2,747 |  |  | 2,792 |  |
|  |  | $ | 91,593 |  |  | $ | 88,391 |  |
| Other assets: |  |  |  |  |  |  |
| Deferred tax assets |  | $ | 39,310 |  |  | $ | 52,883 |  |
| Trading investments for deferred compensation plan |  | 17,237 |  |  | 16,611 |  |
| Other assets |  | 6,441 |  |  | 4,966 |  |
|  |  | $ | 62,988 |  |  | $ | 74,460 |  |


## logi:ScheduleOfBalanceSheetComponentsLiabilityTableTextBlock

[0001032975-15-000023:notes:6]
The following table presents the components of certain balance sheet liability amounts as of March 31, 2015 and 2014 (in thousands):

[0001032975-15-000023:notes:7]
|  |  | March 31, |
|  |  | 2015 |  | 2014 |
| Accrued and other current liabilities: |  |  |  |  |  |  |
| Accrued personnel expenses |  | $ | 50,015 |  |  | $ | 55,165 |  |
| Indirect customer incentive programs |  | 19,730 |  |  | 31,737 |  |
| Accrued restructuring |  | 966 |  |  | 2,121 |  |
| Deferred revenue |  | 24,987 |  |  | 22,529 |  |
| Accrued freight and duty |  | 6,666 |  |  | 6,276 |  |
| Value-added taxes payable |  | 8,608 |  |  | 9,354 |  |
| Accrued royalties |  | 2,321 |  |  | 2,653 |  |
| Warranty accrual |  | 12,630 |  |  | 13,905 |  |
| Employee benefit plan obligation |  | 1,232 |  |  | 1,100 |  |
| Income taxes payable |  | 5,794 |  |  | 7,701 |  |
| Other liabilities |  | 61,963 |  |  | 59,431 |  |
|  |  | $ | 194,912 |  |  | $ | 211,972 |  |
| Non-current liabilities: |  |  |  |  |  |  |
| Warranty accrual |  | $ | 9,080 |  |  | $ | 10,475 |  |
| Obligation for deferred compensation plan |  | 17,237 |  |  | 16,611 |  |
| Long term restructuring |  | 73 |  |  | 5,440 |  |
| Employee benefit plan obligation |  | 51,181 |  |  | 37,899 |  |
| Deferred rent |  | 11,519 |  |  | 15,555 |  |
| Deferred tax liability |  | 1,936 |  |  | 2,304 |  |
| Long term deferred revenue |  | 9,109 |  |  | 9,350 |  |
| Other liabilities |  | 1,397 |  |  | 1,715 |  |
|  |  | $ | 101,532 |  |  | $ | 99,349 |  |


## logi:ScheduleOfRevenueByProductFamilyExcludingInterCompanyTransactionsTableTextBlock

[0001032975-15-000023:notes:8]
Net sales by product categories and sales channels, excluding intercompany transactions, were as follows (in thousands):

[0001032975-15-000023:notes:9]
|  |  | Years Ended March 31, |
|  |  | 2015 |  | 2014 |  | 2013 |
| Peripherals: |  |  |  |  |  |  |  |  |
| Mobile Speakers |  | $ | 178,038 |  |  | $ | 87,414 |  |  | $ | 33,408 |  |
| Gaming |  | 211,911 |  |  | 186,926 |  |  | 144,512 |  |
| Video Collaboration |  | 62,215 |  |  | 29,058 |  |  | 18,700 |  |
| Tablet & Other Accessories |  | 140,994 |  |  | 172,484 |  |  | 119,856 |  |
| Growth |  | 593,158 |  |  | 475,882 |  |  | 316,476 |  |
| Pointing Devices |  | 487,210 |  |  | 506,884 |  |  | 521,083 |  |
| Keyboards & Combos |  | 426,117 |  |  | 415,314 |  |  | 399,144 |  |
| Audio-PC & Wearables |  | 213,496 |  |  | 250,037 |  |  | 289,313 |  |
| PC Webcams |  | 96,680 |  |  | 113,791 |  |  | 137,292 |  |
| Home Control |  | 68,060 |  |  | 67,371 |  |  | 71,641 |  |
| Profit Maximization |  | 1,291,563 |  |  | 1,353,397 |  |  | 1,418,473 |  |
| Retail Strategic Sales (1) |  | 1,884,721 |  |  | 1,829,279 |  |  | 1,734,949 |  |
| Non-Strategic |  | 2,725 |  |  | 37,000 |  |  | 86,102 |  |
| OEM |  | 117,462 |  |  | 141,749 |  |  | 141,186 |  |
|  |  | 2,004,908 |  |  | 2,008,028 |  |  | 1,962,237 |  |
| Video Conferencing |  | 109,039 |  |  | 120,685 |  |  | 137,040 |  |
|  |  | $ | 2,113,947 |  |  | $ | 2,128,713 |  |  | $ | 2,099,277 |  |

[0001032975-15-000023:notes:10]
______________________________________

[0001032975-15-000023:notes:11]
| (1) | Certain products within the retail product families presented in prior years have been reclassified to conform to the current year presentation. There is no impact over total net retail sales. |


## logi:ScheduleOfSharesRepurchasedUnderRepurchasePlanTableTextBlock

[0001032975-15-000023:notes:12]
A summary of the approved share buyback programs are shown in the following table (in thousands, excluding transaction costs):

[0001032975-15-000023:notes:13]
|  |  | Approved |  | Repurchased |
| Share Buyback Program |  | Shares |  | Amounts |  | Shares |  | Amounts |
| March 2014 |  | 17,311 |  |  | $ | 250,000 |  |  | 115 |  |  | $ | 1,663 |  |
| September 2008—amended(1) |  | 28,465 |  |  | 177,030 |  |  | 18,500 |  |  | 170,714 |  |
| September 2008(1) |  | 8,344 |  |  | 250,000 |  |  | 7,609 |  |  | 73,134 |  |
|  |  | 54,120 |  |  | $ | 677,030 |  |  | 26,224 |  |  | $ | 245,511 |  |

[0001032975-15-000023:notes:14]
______________________________

[0001032975-15-000023:notes:15]
(1) Expired in August 2013


## us-gaap:AdvertisingCostsPolicyTextBlock

[0001032975-15-000023:notes:16]
Advertising Costs

[0001032975-15-000023:notes:17]
Advertising costs are expensed as incurred. Advertising costs are recorded as either a marketing and selling expense or a deduction from revenue. Advertising costs reimbursed by the Company to direct or indirect customers must have an identifiable benefit and an estimable fair value in order to be classified as an operating expense. If these criteria are not met, the cost is classified as a reduction of revenue.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001032975-15-000023:notes:18]
Summary of Significant Accounting Policies

[0001032975-15-000023:notes:19]
Basis of Presentation

[0001032975-15-000023:notes:20]
The consolidated financial statements include the accounts of Logitech and its subsidiaries. All intercompany balances and transactions have been eliminated. The consolidated financial statements are presented in accordance with U.S. GAAP (accounting principles generally accepted in the United States of America).

[0001032975-15-000023:notes:21]
Fiscal Year

[0001032975-15-000023:notes:22]
The Company's fiscal year ends on March 31. Interim quarters are thirteen-week periods, each ending on a Friday. For purposes of presentation, the Company has indicated its quarterly periods as ending on the month end.

[0001032975-15-000023:notes:23]
Use of Estimates

[0001032975-15-000023:notes:24]
The preparation of financial statements in conformity with U.S. GAAP requires management to make judgments, estimates and assumptions that affect reported amounts of assets, liabilities, net sales and expenses, and the disclosure of contingent assets and liabilities. Examples of significant estimates and assumptions made by management involve the fair value of goodwill, warranty liabilities, accruals for discretionary customer programs, sales return reserves, allowance for doubtful accounts, inventory valuation, uncertain tax positions, and valuation allowances for deferred tax assets. Although these estimates are based on management's best knowledge of current events and actions that may impact the Company in the future, actual results could differ from those estimates.

[0001032975-15-000023:notes:25]
Foreign Currencies

[0001032975-15-000023:notes:26]
The functional currency of the Company's operations is primarily the U.S. Dollar. Certain operations use the Euro, Chinese Renminbi, Swiss Franc, or other local currencies as their functional currencies. The financial statements of the Company's subsidiaries whose functional currency is other than the U.S. Dollar are translated to U.S. Dollars using period-end rates of exchange for assets and liabilities and monthly average rates for net sales, income and expenses. Cumulative translation gains and losses are included as a component of shareholders' equity in accumulated other comprehensive income/(loss). Gains and losses arising from transactions denominated in currencies other than a subsidiary's functional currency are reported in other income (expense), net in the consolidated statements of operations.

[0001032975-15-000023:notes:27]
Revenue Recognition

[0001032975-15-000023:notes:28]
Revenues are recognized when all of the following criteria are met:

[0001032975-15-000023:notes:29]
| • | Evidence of an arrangement between the Company and the customer exists; |

[0001032975-15-000023:notes:30]
| • | Delivery has occurred and title and risk of loss has transferred to the customer; |

[0001032975-15-000023:notes:31]
| • | The price of the product is fixed or determinable; and |

[0001032975-15-000023:notes:32]
| • | Collectability of the receivable is reasonably assured. |

[0001032975-15-000023:notes:33]
For sales of most hardware peripherals products and hardware bundled with software essential to its functionality, these criteria are met at the time delivery has occurred and title and risk of loss have transferred to the customer.

[0001032975-15-000023:notes:34]
The Company's video conferencing segment has multiple deliverable revenue arrangements that include both undelivered software elements and, hardware with software essential to its functionality. The Company uses the following hierarchy to determine the relative selling price for allocating revenue to the deliverables: (i) VSOE (vendor specific objective evidence) of fair value, if available; (ii) TPE (third party evidence), if VSOE is not available; or (iii) ESP (best estimate of selling price), if neither VSOE nor TPE are available. Management judgment must be used to determine the appropriate deliverables and associated relative selling prices. The Company has identified the Lifesize video conferencing products as products sold with software components that qualify as multiple-deliverable revenue arrangements.

[0001032975-15-000023:notes:35]
Lifesize products include the following deliverables:

[0001032975-15-000023:notes:36]
Non-software deliverables

[0001032975-15-000023:notes:37]
| • | Hardware with software essential to the functionality of the hardware device delivered at time of sale |

[0001032975-15-000023:notes:38]
| • | Maintenance for hardware with essential software, including future when-and-if-available unspecified upgrades |

[0001032975-15-000023:notes:39]
| • | Other services, including training and installation |

[0001032975-15-000023:notes:40]
Software deliverables

[0001032975-15-000023:notes:41]
| • | Non-essential software |

[0001032975-15-000023:notes:42]
| • | Maintenance for non-essential software, including future when-and-if available unspecified upgrades |

[0001032975-15-000023:notes:43]
The relative selling price for hardware with essential software and non-essential software is based on ESP, as VSOE and TPE cannot be established due to variable price discounting. Key factors considered in developing ESP are historical selling prices of the product, pricing of substantially similar products, and other market conditions. Lifesize sells maintenance for non-essential software, maintenance for hardware with essential software, and other services on a standalone basis, and therefore has established VSOE for those deliverables.

[0001032975-15-000023:notes:44]
The consideration received for multiple element arrangements consisting of both non-software and software deliverables is allocated based on relative selling prices to the non-software deliverables and the software deliverables as a group. Amounts allocated to non-software-related elements, such as delivered hardware with essential software, are recognized at the time of sale provided that the other criteria for revenue recognition have been met. Amounts allocated to maintenance services for hardware and essential software are deferred and recognized ratably over the maintenance period. Amounts allocated to other services are deferred and recognized upon completion of services. Amounts allocated to software deliverables such as non-essential software and related services are further allocated to the individual deliverables within the software group. The fair value, based on VSOE, of non-essential software-related maintenance is deferred and recognized ratably over the maintenance period. The residual value of the amounts allocated to software-related elements is recognized at the time of sale.

[0001032975-15-000023:notes:45]
Revenue from Cloud-based services arrangements that allow for the use of a hosted software product or service over a contractually determined period of time without taking possession of software are accounted for as subscriptions with billings recorded as deferred revenue and recognized as revenue ratably over the contractual period beginning on the date the service is made available to customers.

[0001032975-15-000023:notes:46]
Revenues from sales to distributors and authorized resellers are recognized upon shipment net of estimated product returns and expected payments for cooperative marketing arrangements, customer incentive programs and pricing programs. The estimated cost of these programs is recorded as a reduction of sales or as an operating expense, if the Company receives a separately identifiable benefit from the customer and can reasonably estimate the fair value of that benefit. Significant management judgment and estimates are used to determine the cost of these programs in any accounting period.

[0001032975-15-000023:notes:47]
The Company grants limited rights to return products. Return rights vary by customer, and range from just the right to return defective product to stock rotation rights limited to a percentage of sales approved by management. Estimates of expected future product returns are recognized at the time of sale based on analyses of historical return trends by customer and by product, inventories owned by and located at distributors and retailers, current customer demand, current operating conditions, and other relevant customer and product information. Upon recognition, the Company reduces sales and cost of sales for the estimated return. Return trends are influenced by product life cycle status, new product introductions, market acceptance of products, sales levels, product sell-through, the type of customer, seasonality, product quality issues, competitive pressures, operational policies and procedures, and other factors.

[0001032975-15-000023:notes:48]
Return rates can fluctuate over time, but are sufficiently predictable to allow the Company to estimate expected future product returns.

[0001032975-15-000023:notes:49]
The Company enters into cooperative marketing arrangements with many of its distribution and retail customers, and with certain indirect partners, allowing customers to receive a credit equal to a set percentage of their purchases of the Company's products, or a fixed dollar credit for various marketing programs. The objective of these arrangements is to encourage advertising and promotional events to increase sales of the Company's products. Accruals for these marketing arrangements are recorded at the later of time of sale or time of commitment, based on negotiated terms, historical experience and inventory levels in the channel.

[0001032975-15-000023:notes:50]
Customer incentive programs include performance-based incentives and consumer rebates. The Company offers performance-based incentives to its distribution customers, retail customers and indirect partners based on pre-determined performance criteria. Accruals for performance-based incentives are recognized as a reduction of the sale price at the time of sale. Estimates of required accruals are determined based on negotiated terms, consideration of historical experience, anticipated volume of future purchases, and inventory levels in the channel. Consumer rebates are offered from time to time at the Company's discretion for the primary benefit of end-users. Accruals for the estimated costs of consumer rebates and similar incentives are recorded at the later of time of sale or when the incentive is offered, based on the specific terms and conditions. Certain incentive programs, including consumer rebates, require management to estimate the number of customers who will actually redeem the incentive based on historical experience and the specific terms and conditions of particular programs.

[0001032975-15-000023:notes:51]
The Company has agreements with certain of its customers that contain terms allowing price protection credits to be issued in the event of a subsequent price reduction. At management's discretion, the Company also offers special pricing discounts to certain customers. Special pricing discounts are usually offered only for limited time periods or for sales of selected products to specific indirect partners. Management's decision to make price reductions is influenced by product life cycle stage, market acceptance of products, the competitive environment, new product introductions and other factors. Accruals for estimated expected future pricing actions are recognized at the time of sale based on analyses of historical pricing actions by customer and by products, inventories owned by and located at distributors and retailers, current customer demand, current operating conditions, and other relevant customer and product information, such as stage of product life-cycle.

[0001032975-15-000023:notes:52]
The Company regularly evaluates the adequacy of its estimates for product returns, cooperative marketing arrangements, customer incentive programs and pricing programs. Future market conditions and product transitions may require the Company to take action to change such programs. In addition, when the variables used to estimate these costs change, or if actual costs differ significantly from the estimates, the Company would be required to record incremental increases or reductions to sales, cost of goods sold or operating expenses. If, at any future time, the Company becomes unable to reasonably estimate these costs, recognition of revenue might be deferred until products are sold to users, which would adversely impact sales in the period of transition.

[0001032975-15-000023:notes:53]
Shipping and Handling Costs

[0001032975-15-000023:notes:54]
The Company's shipping and handling costs are included in cost of sales in the consolidated statements of operations for all periods presented.

[0001032975-15-000023:notes:55]
Research and Development Costs

[0001032975-15-000023:notes:56]
Costs related to research, design and development of products, which consist primarily of personnel, product design and infrastructure expenses, are charged to research and development expense as they are incurred.

[0001032975-15-000023:notes:57]
Advertising costs are expensed as incurred. Advertising costs are recorded as either a marketing and selling expense or a deduction from revenue. Advertising costs reimbursed by the Company to direct or indirect customers must have an identifiable benefit and an estimable fair value in order to be classified as an operating expense. If these criteria are not met, the cost is classified as a reduction of revenue. Advertising costs during fiscal years 2015, 2014 and 2013 were $174.2 million, $161.2 million and $165.8 million, respectively.

[0001032975-15-000023:notes:58]
Cash Equivalents

[0001032975-15-000023:notes:59]
The Company considers all highly liquid instruments purchased with an original maturity of three months or less to be cash equivalents. Cash equivalents are carried at cost, which approximates fair value.

[0001032975-15-000023:notes:60]
Concentration of Credit Risk

[0001032975-15-000023:notes:61]
Financial instruments that potentially subject the Company to concentrations of credit risk consist principally of cash and cash equivalents and accounts receivable. The Company maintains cash and cash equivalents with various financial institutions to limit exposure with any one financial institution, but is exposed to credit risk in the event of default by financial institutions to the extent that cash balances with individual financial institutions are in excess of amounts that are insured.

[0001032975-15-000023:notes:62]
The Company sells to large OEMs, distributors and retailers and, as a result, maintains individually significant receivable balances with such customers. In fiscal years 2015, 2014 and 2013, one customer in the peripherals operating segment represented 14%, 14% and 11% of the Company's total net sales, respectively. No other customer represented more than 10% of the Company's total net sales during fiscal years 2015, 2014 or 2013. As of March 31, 2015 and 2014, one customer represented 12% and 14% of total accounts receivable, respectively. No other customer represented more than 10% of the Company's total accounts receivable at either March 31, 2015 or 2014. Typical payment terms require customers to pay for product sales generally within 30 to 60 days; however terms may vary by customer type, by country and by selling season. Extended payment terms are sometimes offered to a limited number of customers during the second and third fiscal quarters. The Company does not modify payment terms on existing receivables.

[0001032975-15-000023:notes:63]
The Company's OEM customers tend to be well-capitalized multi-national companies, while distributors and key retailers may be less well-capitalized. The Company manages its accounts receivable credit risk through ongoing credit evaluation of its customers' financial condition. The Company generally does not require collateral from its customers.

[0001032975-15-000023:notes:64]
Allowances for Doubtful Accounts

[0001032975-15-000023:notes:65]
Allowances for doubtful accounts are maintained for estimated losses resulting from the inability of the Company's customers to make required payments. The allowances are based on the Company's regular assessment of the credit worthiness and financial condition of specific customers, as well as its historical experience with bad debts and customer deductions, receivables aging, current economic trends, geographic or country-specific risks and the financial condition of its distribution channels.

[0001032975-15-000023:notes:66]
Inventories

[0001032975-15-000023:notes:67]
Inventories are stated at the lower of cost or market. Costs are computed under the standard cost method, which approximates actual costs determined on the first-in, first-out basis. The Company records write-downs of inventories which are obsolete or in excess of anticipated demand or market value based on a consideration of marketability and product life cycle stage, product development plans, component cost trends, demand forecasts, historical net sales, and assumptions about future demand and market conditions.

[0001032975-15-000023:notes:68]
As of March 31, 2015 and 2014, the Company also recorded a liability of $9.8 million and $9.2 million, respectively, arising from firm, non-cancelable, and unhedged inventory purchase commitments in excess of anticipated demand or market value consistent with its valuation of excess and obsolete inventory. Such liability is included in accrued and other current liabilities.

[0001032975-15-000023:notes:69]
Investments

[0001032975-15-000023:notes:70]
The Company's investment securities portfolio consists of bank time deposits with an original maturity of three months or less and marketable securities (money market and mutual funds) related to a deferred compensation plan.

[0001032975-15-000023:notes:71]
The bank time deposits are classified as cash equivalents and are recorded at cost, which approximates fair value.

[0001032975-15-000023:notes:72]
The marketable securities related to the deferred compensation plan are classified as non-current trading investments, as they are intended to fund the deferred compensation plan long-term liability. Since participants in the deferred compensation plan may select the mutual funds in which their compensation deferrals are invested within the confines of the Rabbi Trust which holds the marketable securities, the Company has designated these marketable securities as trading investments, although there is no intent to actively buy and sell securities within the objective of generating profits on short-term differences in market prices. These securities are recorded at fair value based on quoted market prices. Earnings, gains and losses on trading investments are included in other income (expense), net.

[0001032975-15-000023:notes:73]
Property, Plant and Equipment

[0001032975-15-000023:notes:74]
Property, plant and equipment are stated at cost. Additions and improvements are capitalized, and maintenance and repairs are expensed as incurred. The Company capitalizes the cost of software developed for internal use in connection with major projects. Costs incurred during the feasibility stage are expensed, whereas direct costs incurred during the application development stage are capitalized.

[0001032975-15-000023:notes:75]
Depreciation is provided using the straight-line method. Plant and buildings are depreciated over estimated useful lives from ten to twenty-five years, equipment over useful lives from three to five years, internal-use software development over useful lives of three to seven years and leasehold improvements over the lesser of the useful life of the improvement or the term of the lease.

[0001032975-15-000023:notes:76]
When property and equipment is retired or otherwise disposed of, the cost and accumulated depreciation are relieved from the accounts and the net gain or loss is included in operating expenses.

[0001032975-15-000023:notes:77]
Valuation of Long-Lived Assets

[0001032975-15-000023:notes:78]
The Company reviews long-lived assets, such as property and equipment, and finite-lived intangible assets, for impairment whenever events indicate that the carrying amounts might not be recoverable. Recoverability of property and equipment, and other finite-lived intangible asset is measured by comparing the projected undiscounted net cash flows associated with those assets to their carrying values. If an asset is considered impaired, it is written down to fair value, which is determined based on the asset's projected discounted cash flows or appraised value, depending on the nature of the asset. For purposes of recognition of an impairment for assets held for use, the Company groups assets and liabilities at the lowest level for which cash flows are separately identifiable.

[0001032975-15-000023:notes:79]
Goodwill and Other Intangible Assets

[0001032975-15-000023:notes:80]
The Company's intangible assets principally include goodwill, acquired technology, trademarks, and customer contracts. Other intangible assets with finite lives, which include acquired technology, trademarks and customer contracts, and other are recorded at cost and amortized using the straight-line method over their useful lives ranging from one year to ten years. Intangible assets with indefinite lives, which include only goodwill, are recorded at cost and evaluated at least annually for impairment.

[0001032975-15-000023:notes:81]
In accordance with ASC Topic 350-10 ("ASC 350-10") as it relates to Goodwill and Other Intangible Assets, the Company conducts its annual goodwill impairment analysis as of December 31 each year and as necessary if changes in facts and circumstances indicate that it is more likely than not that the fair value of its reporting units may be less than its carrying amount. Events or changes in facts and circumstances that might indicate potential impairment of goodwill include deterioration in general economic conditions, negative developments in equity and credit markets, adverse changes in the markets in which an entity operates, increases in input costs that have a negative effect on earnings and cash flows, or a trend of negative or declining cash flows or a decline in actual or planned revenue or earnings compared with actual and projected results of relevant prior periods, other relevant entity-specific events such as changes in management, key personnel, strategy, or customers; contemplation of bankruptcy; or litigation. Determining the number of reporting units and the fair value of a reporting unit requires the Company to make judgments and involves the use of significant estimates and assumptions. The Company has two reporting units: peripherals and video conferencing. The allocation of assets and liabilities to each of the reporting units also involves judgment and assumptions.

[0001032975-15-000023:notes:82]
FASB ASC 350-20 permits the Company to make a qualitative assessment of whether it is more likely than not that a reporting unit's fair value is less than its carrying amount before applying the two-step goodwill impairment test. If an entity concludes that it is not more likely than not that the fair value of a reporting unit is less than its carrying amount, it would not be required to perform the two-step impairment test for that reporting unit. The Company may elect to proceed directly to Step 1 without performing a qualitative assessment.

[0001032975-15-000023:notes:83]
The Step 1 of the two-step impairment test involves measuring the recoverability of goodwill at the reporting unit level by comparing the reporting unit's carrying amount, including goodwill, to the estimated fair value of the reporting unit. The fair value is estimated using an income approach employing a discounted cash flow ("DCF") and a market-based model. The DCF model is based on projected cash flows from the Company's most recent forecast ("assessment forecast") developed in connection with each of its reporting units to perform the goodwill impairment assessment. The assessment forecast is based on a number of key assumptions, including, but not limited to, discount rate, compound annual growth rate ("CAGR") during the forecast period, and terminal value. The terminal value is based on an exit price at the end of the assessment forecast using an earnings multiple applied to the final year of the assessment forecast. The discount rate is applied to the projected cash flows to reflect the risks inherent in the timing and amount of the projected cash flows, including the terminal value, and is derived from the weighted average cost of capital of market participants in similar businesses. The market approach model is based on applying certain revenue and earnings multiples of comparable companies relevant to each of the Company's reporting units to the respective revenue and earnings metrics of its reporting units. To test the reasonableness of the fair values indicated by the income approach and the market-based approach, the Company may assess the implied premium of the aggregate fair value over the market capitalization considered attributable to an acquisition control premium, which is the price in excess of a stock market's price that investors would typically pay to gain control of an entity. The DCF model and the market approach require the exercise of significant judgment, including assumptions about appropriate discount rates, long-term growth rates for purposes of determining a terminal value at the end of the discrete forecast period, economic expectations, timing of expected future cash flows, and expectations of returns on equity that will be achieved. Such assumptions are subject to change as a result of changing economic and competitive conditions. If the carrying amount of the reporting unit exceeds its fair value as determined by these assessments, goodwill is considered impaired, and Step 2 of the analysis is performed to measure the amount of impairment loss. Step 2 measures the impairment loss by allocating the reporting unit's fair value to its assets and liabilities other than goodwill, comparing the resulting implied fair value of goodwill with its carrying amount, and recording an impairment charge for the difference.

[0001032975-15-000023:notes:84]
Income Taxes

[0001032975-15-000023:notes:85]
The Company provides for income taxes using the asset and liability method, which requires that deferred tax assets and liabilities be recognized for the expected future tax consequences of temporary differences resulting from differing treatment of items for tax and accounting purposes. In estimating future tax consequences, expected future events are taken into consideration, with the exception of potential tax law or tax rate changes.

[0001032975-15-000023:notes:86]
The Company's assessment of uncertain tax positions requires that management makes estimates and judgments about the application of tax law, the expected resolution of uncertain tax positions and other matters. In the event that uncertain tax positions are resolved for amounts different than the Company's estimates, or the related statutes of limitations expire without the assessment of additional income taxes, the Company will be required to adjust the amounts of the related assets and liabilities in the period in which such events occur. Such adjustments may have a material impact on the Company's income tax provision and its results of operations.

[0001032975-15-000023:notes:87]
Fair Value of Financial Instruments

[0001032975-15-000023:notes:88]
The carrying value of certain of the Company's financial instruments, including cash equivalents, accounts receivable and accounts payable approximates fair value due to their short maturities. The Company's trading investments related to the deferred compensation plan are reported at fair value based on quoted market prices.

[0001032975-15-000023:notes:89]
Net Income (Loss) per Share

[0001032975-15-000023:notes:90]
Basic net income (loss) per share is computed by dividing net income (loss) by the weighted average outstanding shares. Diluted net income (loss) per share is computed using the weighted average outstanding shares and dilutive share equivalents. Dilutive share equivalents consist of share-based awards, including stock options, purchase rights under employee share purchase plan, and restricted stock units ("RSUs").

[0001032975-15-000023:notes:91]
The dilutive effect of in-the-money share-based compensation awards is calculated based on the average share price for each fiscal period using the treasury stock method, which assumes that the amount used to repurchase shares includes the amount the employee must pay for exercising share-based awards, the amount of compensation cost not yet recognized for future service, and the amount of tax impact that would be recorded in additional paid-in capital when the award becomes deductible.

[0001032975-15-000023:notes:92]
Share-Based Compensation Expense

[0001032975-15-000023:notes:93]
Share-based compensation expense includes compensation expense, reduced for estimated forfeitures, for share-based awards granted based on the grant date fair value. The grant date fair value for stock options and stock purchase rights is estimated using the Black-Scholes-Merton option-pricing valuation model. The grant date fair value of RSUs which vest upon meeting certain market conditions is estimated using the Monte-Carlo simulation method. The grant date fair value of time-based and performance-based RSUs is calculated based on the market price on the date of grant, adjusted by estimated dividends yield prior to vesting.

[0001032975-15-000023:notes:94]
Excess tax benefits resulting from share-based awards are classified as cash flows from financing activities in the consolidated statements of cash flows. Excess tax benefits are realized tax benefits from tax deductions for exercised options and vested RSUs in excess of the deferred tax asset attributable to share-based compensation costs for such share-based awards.

[0001032975-15-000023:notes:95]
The Company will recognize a benefit from share-based compensation in additional paid-in capital only if an incremental tax benefit is realized after all other available tax attributes have been utilized.

[0001032975-15-000023:notes:96]
Product Warranty Accrual

[0001032975-15-000023:notes:97]
The Company estimates cost of product warranties at the time the related revenue is recognized based on historical and projected warranty claim rates, historical and projected costs, and knowledge of specific product failures that are outside of the Company's typical experience. Each quarter, the Company reevaluates estimates to assess the adequacy of recorded warranty liabilities considering the size of the installed base of products subject to warranty protection and adjusts the amounts as necessary. If actual product failure rates or repair costs differ from estimates, revisions to the estimated warranty liabilities would be required and could materially affect the Company's results of operations.

[0001032975-15-000023:notes:98]
Comprehensive Income (Loss)

[0001032975-15-000023:notes:99]
Comprehensive income (loss) is defined as the total change in shareholders' equity during the period other than from transactions with shareholders. Comprehensive income (loss) consists of net income (loss) and other comprehensive income (loss). Other comprehensive income (loss) is comprised of currency translation adjustments from those entities not using the U.S. Dollar as their functional currency, unrealized gains and losses on marketable equity securities, net deferred gains and losses and prior service costs and credits for defined benefit pension plans, and net deferred gains and losses on hedging activity.

[0001032975-15-000023:notes:100]
Treasury Shares

[0001032975-15-000023:notes:101]
The Company periodically repurchases shares in the market at fair value. Treasury shares repurchased are recorded at cost as a reduction of total shareholders' equity. Treasury shares held may be reissued to satisfy the exercise of employee stock options and purchase rights, the vesting of restricted stock units, and acquisitions, or may be cancelled with shareholder approval. Treasury shares that are reissued are accounted for using the first-in, first-out basis.

[0001032975-15-000023:notes:102]
Derivative Financial Instruments

[0001032975-15-000023:notes:103]
The Company enters into foreign exchange forward contracts to reduce the short-term effects of currency fluctuations on certain foreign currency receivables or payables and to hedge against exposure to changes in currency exchange rates related to its subsidiaries' forecasted inventory purchases. These forward contracts generally mature within four months.

[0001032975-15-000023:notes:104]
Gains and losses for changes in the fair value of the effective portion of the Company's forward contracts related to forecasted inventory purchases are deferred as a component of accumulated other comprehensive income (loss) until the hedged inventory purchases are sold, at which time the gains or losses are reclassified to cost of goods sold. Gains or losses for changes in the fair value on forward contracts that offset translation losses or gains on foreign currency receivables or payables are recognized are included in other income (expense), net.

[0001032975-15-000023:notes:105]
Restructuring Charges

[0001032975-15-000023:notes:106]
The Company's restructuring charges consist of employee severance, one-time termination benefits and ongoing benefits related to the reduction of its workforce, lease exit costs, and other costs. Liabilities for costs associated with a restructuring activity are measured at fair value and are recognized when the liability is incurred, as opposed to when management commits to a restructuring plan. One-time termination benefits are expensed at the date the entity notifies the employee, unless the employee must provide future service, in which case the benefits are expensed ratably over the future service period. Ongoing benefits are expensed when restructuring activities are probable and the benefit amounts are estimable. Costs to terminate a lease before the end of its term are recognized when the property is vacated. Other costs primarily consist of legal, consulting, and other costs related to employee terminations are expensed when incurred. Termination benefits are calculated based on regional benefit practices and local statutory requirements.

[0001032975-15-000023:notes:107]
Recent Accounting Pronouncements

[0001032975-15-000023:notes:108]
In May 2014, the FASB issued Accounting Standards Update No. 2014-9, "Revenue from Contracts with Customers (Topic 606)," ("ASU 2014-9"). ASU 2014-9 outlines a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. Under the new model, recognition of revenue occurs when a customer obtains control of promised goods or services in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. In addition, the new standard requires that reporting companies disclose the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. As currently issued, the new standard is effective beginning in the first quarter of 2017; early adoption is prohibited. The new standard is required to be applied retrospectively to each prior reporting period presented or retrospectively with the cumulative effect of initially applying it recognized at the date of initial application. The Company has not yet selected a transition method nor has it determined the impact of the new standard on its consolidated financial statements.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001032975-15-000023:notes:109]
Commitments and Contingencies

[0001032975-15-000023:notes:110]
Operating Leases

[0001032975-15-000023:notes:111]
The Company leases facilities under operating leases, certain of which require it to pay property taxes, insurance and maintenance costs. Operating leases for facilities are generally renewable at the Company's option and usually include escalation clauses linked to inflation. Future minimum annual rentals under non-cancelable operating leases at March 31, 2015 are as follows (in thousands):

[0001032975-15-000023:notes:112]
| Years Ending March 31, |  |  |
| 2016 |  | $ | 13,829 |  |
| 2017 |  | 10,397 |  |
| 2018 |  | 8,330 |  |
| 2019 |  | 6,575 |  |
| 2020 |  | 5,193 |  |
| Thereafter |  | 9,908 |  |
|  |  | $ | 54,232 |  |

[0001032975-15-000023:notes:113]
Rent expense for fiscal years 2015, 2014 and 2013 was $12.6 million, $14.7 million and $25.3 million, respectively.

[0001032975-15-000023:notes:114]
In connection with its leased facilities, the Company recognized a liability for asset retirement obligations for 2015 and 2014 representing the present value of estimated remediation costs to be incurred at lease expiration. The liabilities for asset retirement obligations were not material as of March 31, 2015 and 2014.

[0001032975-15-000023:notes:115]
Product Warranties

[0001032975-15-000023:notes:116]
All of the Company's Peripherals products are covered by warranty to be free from defects in material and workmanship for periods ranging from one year to five years. At the time of sale, the Company accrues a warranty liability for estimated costs to provide products, parts or services to repair or replace products in satisfaction of the warranty obligation. The Company's estimate of costs to fulfill its warranty obligations is based on historical experience and expectations of future conditions. When the Company experiences changes in warranty claim activity or costs associated with fulfilling those claims, the warranty liability is adjusted accordingly.

[0001032975-15-000023:notes:117]
Changes in the Company's warranty liability for fiscal years 2015 and 2014 were as follows (in thousands):

[0001032975-15-000023:notes:118]
|  |  | Years Ended March 31, |
|  |  | 2015 |  | 2014 |
| Beginning of the period |  | $ | 24,380 |  |  | $ | 21,442 |  |
| Provision |  | 10,958 |  |  | 15,473 |  |
| Settlements |  | (12,027 | ) |  | (15,206 | ) |
| Currency translation (1) |  | (1,601 | ) |  | 344 |  |
| Adjustment (2) |  | — |  |  | 2,327 |  |
| End of the period |  | $ | 21,710 |  |  | $ | 24,380 |  |

[0001032975-15-000023:notes:119]
_______________________________________________________________________________

[0001032975-15-000023:notes:120]
| (1) | The currency translation during fiscal year 2014 is presented separately to conform to the current year presentation. |

[0001032975-15-000023:notes:121]
| (2) | During fiscal year 2014, the warranty liability allocated to the Company's Home Control product category was reclassified from liabilities held for sale. |

[0001032975-15-000023:notes:122]
Deferred Services Revenue

[0001032975-15-000023:notes:123]
The Company's video conferencing reporting unit offers maintenance contracts with the sale of a majority of its products which allow customers to receive service and support extended beyond the expiration of the product warranty contractual term. The Company recognizes these contracts over the life of the service period.

[0001032975-15-000023:notes:124]
Changes in the Company's deferred services revenue during fiscal years 2015 and 2014 were as follows (in thousands):

[0001032975-15-000023:notes:125]
|  |  | Years Ended March 31, |
|  |  | 2015 |  | 2014 |
| Beginning of the period |  | $ | 30,160 |  |  | $ | 29,327 |  |
| Extended warranties issued |  | 30,256 |  |  | 33,007 |  |
| Amortization |  | (31,766 | ) |  | (32,174 | ) |
| End of the period |  | $ | 28,650 |  |  | $ | 30,160 |  |

[0001032975-15-000023:notes:126]
Investment Commitments

[0001032975-15-000023:notes:127]
During 2015, the Company entered into a limited partnership agreement for a private investment fund specialized in early-stage start-up consumer hardware electronics companies and committed to a capital contribution of $4.0 million over the life of the fund. As of March 31, 2015, no capital has been called upon by the fund.

[0001032975-15-000023:notes:128]
Other Contingencies

[0001032975-15-000023:notes:129]
The Company is subject to an ongoing formal investigation by the SEC’s Enforcement Division, relating to certain issues including the accounting for Revue inventory valuation reserves that resulted in the restatement described in the Fiscal Year 2014 Annual Report on Form 10-K, revision to the Company’s consolidated financial statements concerning warranty accruals and amortization of intangible assets presented in the Company’s Amended Annual Report on Form 10-K/A, filed on August 7, 2013, and the Company’s transactions with a distributor for Fiscal Year 2007 through Fiscal Year 2009. The Company has entered into an agreement with the SEC to extend the statute of limitations. The Company is cooperating with the investigation and recently engaged in discussions to settle the matter with the SEC, including making offers of monetary amounts for a civil penalty.  In accordance with U.S. GAAP, the Company has made an accrual in its financial statements.  The Company cannot predict the timing, range of possible loss or final outcome of this matter.

[0001032975-15-000023:notes:130]
Guarantees

[0001032975-15-000023:notes:131]
Logitech Europe S.A. guaranteed payments of two third-party contract manufacturers' purchase obligations. As of March 31, 2015, the maximum amount of this guarantee was $3.8 million, of which $1.7 million of guaranteed purchase obligations was outstanding.

[0001032975-15-000023:notes:132]
Indemnifications

[0001032975-15-000023:notes:133]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys' fees. As of March 31, 2015, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

[0001032975-15-000023:notes:134]
The Company also indemnifies its current and former directors and certain of its current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. The Company is unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not limited, the obligations are conditional in nature and the facts and circumstances involved in any situation that might arise are variable.

[0001032975-15-000023:notes:135]
Legal Proceedings

[0001032975-15-000023:notes:136]
From time to time the Company is involved in claims and legal proceedings which arise in the ordinary course of its business. The Company is currently subject to several such claims and a small number of legal proceedings. The Company believes that these matters lack merit and intends to vigorously defend against them. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company's defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company's business, financial conditions, cash flows or results of operations in a particular period. Any claims or proceedings against the Company, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company's business.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001032975-15-000023:notes:137]
Employee Benefit Plans

[0001032975-15-000023:notes:138]
Employee Share Purchase Plans and Stock Incentive Plans

[0001032975-15-000023:notes:139]
As of March 31, 2015, the Company offers the 2006 ESPP (2006 Employee Share Purchase Plan (Non-U.S.)), the 1996 ESPP (1996 Employee Share Purchase Plan (U.S.)), the 2006 Plan (2006 Stock Incentive Plan) and the 2012 Plan (2012 Stock Inducement Equity Plan). Shares issued to employees as a result of purchases or exercises under these plans are generally issued from shares held in treasury stock.

[0001032975-15-000023:notes:140]
The following table summarizes share-based compensation expense and related tax benefit recognized for fiscal years 2015, 2014 and 2013 (in thousands):

[0001032975-15-000023:notes:141]
|  |  | Years Ended March 31, |
|  |  | 2015 |  | 2014 |  | 2013 |
| Cost of goods sold |  | $ | 2,473 |  |  | $ | 2,518 |  |  | $ | 2,499 |  |
| Marketing and selling |  | 9,094 |  |  | 8,298 |  |  | 7,825 |  |
| Research and development |  | 3,224 |  |  | 4,546 |  |  | 7,532 |  |
| General and administrative |  | 11,034 |  |  | 10,184 |  |  | 7,342 |  |
| Total share-based compensation expense |  | 25,825 |  |  | 25,546 |  |  | 25,198 |  |
| Income tax benefit |  | (5,558 | ) |  | (4,902 | ) |  | (5,356 | ) |
| Total share-based compensation expense, net of income tax |  | $ | 20,267 |  |  | $ | 20,644 |  |  | $ | 19,842 |  |

[0001032975-15-000023:notes:142]
During the years ended March 31, 2015, 2014 and 2013, the Company capitalized $0.5 million, $0.4 million and $0.4 million, respectively, of stock-based compensation expenses as inventory.

[0001032975-15-000023:notes:143]
The following table summarizes total unamortized share-based compensation expense and the remaining months over which such expense is expected to be recognized, on a weighted-average basis by type of grant (in thousands, except number of months):

[0001032975-15-000023:notes:144]
|  |  | March 31, 2015 |
|  |  | UnamortizedExpense |  | RemainingMonths |
| Stock options and ESPP |  | $ | 1,509 |  |  | 7 |
| Premium-priced stock options |  | 224 |  |  | 12 |
| Time-based RSUs |  | 23,545 |  |  | 21 |
| Market-based and performance-based RSUs |  | 6,383 |  |  | 23 |
|  |  | $ | 31,661 |  |  |  |

[0001032975-15-000023:notes:145]
Under the 1996 ESPP and 2006 ESPP plans, eligible employees may purchase shares at the lower of 85% of the fair market value at the beginning or the end of each offering period, which is generally six months. Subject to continued participation in these plans, purchase agreements are automatically executed at the end of each offering period. An aggregate of 29 million shares was reserved for issuance under the 1996 and 2006 ESPP plans. As of March 31, 2015, a total of 8.3 million shares were available for issuance under these plans. The Company was not current with its periodic reports required to be filed with the SEC and was therefore unable to issue any shares under its Registration Statements on Form S-8 from July 31, 2014 to November 26, 2014. Given the proximity of the unavailability of those registration statements and the end of the then-current ESPP offering period, on July 31, 2014, the Compensation Committee authorized the termination of the then-current ESPP offering period and a one-time payment to each participant in an amount equal to the fifteen percent (15%) discount at which shares would otherwise have been repurchased pursuant to the then-current period of the ESPPs. This one-time payment aggregating to $1.1 million was accounted for as a repurchase of equity awards that reduced additional paid-in capital, resulting in no additional compensation cost. A new ESPP offering period of seven months was initiated on January 1, 2015, which ends on July 31, 2015.

[0001032975-15-000023:notes:146]
The 2006 Plan provides for the grant to eligible employees and non-employee directors of stock options, stock appreciation rights, restricted stock and RSUs. Awards under the 2006 Plan may be conditioned on continued employment, the passage of time or the satisfaction of performance and market vesting criteria. The 2006 Plan had an expiration date of June 16, 2016 until September 5, 2012 when shareholder approved the amendment of the 2006 Plan to eliminate the expiration date. All stock options under this plan have terms not exceeding ten years and are issued at exercise prices not less than the fair market value on the date of grant.

[0001032975-15-000023:notes:147]
Time-based RSUs granted to employees under the 2006 Plan generally vest in four equal annual installments on the grant date anniversary. Time-based RSUs granted to non-executive board members under the 2006 Plan vest in one annual installment on the grant date anniversary. Performance-based RSUs granted under the 2006 plan vest contingent upon the achievement of pre-determined financial metrics. The performance period for performance-based RSUs granted in fiscal year 2015 is three years. Market-based options granted under the 2006 Plan vest upon meeting certain share price performance criteria. Market-based RSUs granted under the 2006 Plan vest at the end of the performance period upon meeting certain share price performance criteria measured against market conditions. The performance period is four years for market-based options granted in fiscal year 2013. The performance period is three years for market-based RSU granted in fiscal years 2015, 2014 and 2013. An aggregate of 24.8 million shares was reserved for issuance under the 2006 Plan. As of March 31, 2015, a total of 9.1 million shares were available for issuance under this plan.

[0001032975-15-000023:notes:148]
Under the 2012 Plan, stock options and RSUs may be granted to eligible employees to serve as inducement material to enter into employment with the Company. Awards under the 2012 Plan may be conditioned on continued employment, the passage of time or the satisfaction of market stock performance criteria, based on individual written employment offer letter. The 2012 Plan has an expiration date of March 28, 2022. Premium-priced stock options granted under the 2012 Plan vest in full if and only when Logitech's average closing share price, over a consecutive ninety-day trading period, meets or exceeds the exercise price of each of the three tranches of the grant. An aggregate of 1.8 million shares was reserved for issuance under the 2012 Plan. As of March 31, 2015, no shares were available for issuance under this plan.

[0001032975-15-000023:notes:149]
The dividend yield assumption is based on the Company's future expectations of dividend payouts. The unvested RSUs or unexercised options are not eligible for these dividends. The expected life is based on historical settlement rates, which the Company believes are most representative of future exercise and post-vesting termination behaviors, or the purchase offerings periods expected to remain outstanding, or the derived period based on the expected stock performance for market-based awards. Expected volatility is based on historical volatility using the Company's daily closing prices, or including the volatility of components of the NASDAQ 100 index for market-based RSUs, over the expected life. The Company considers the historical price volatility of its shares as most representative of future volatility. The risk-free interest rate assumptions are based upon the implied yield of U.S. Treasury zero-coupon issues appropriate for the expected life of the Company's share-based awards.

[0001032975-15-000023:notes:150]
The Company estimates awards forfeitures at the time of grant and revises those estimates in subsequent periods if actual forfeitures differ from those estimates. The Company uses historical data to estimate pre-vesting option and RSU forfeitures and records share-based compensation expense only for those awards that are expected to vest.

[0001032975-15-000023:notes:151]
A summary of the Company's stock option activities under all stock plans for fiscal years 2015, 2014 and 2013 is as follows:

[0001032975-15-000023:notes:152]
|  |  | Number of Shares |  | Weighted-Average Exercise Price |  | Weighted-Average Remaining Contractual Term |  | Aggregate Intrinsic Value |
|  |  | (In thousands) |  |  |  | (Years) |  | (In thousands) |
| Outstanding, March 31, 2012 |  | 13,034 |  |  |  |  |  |  |  |  |
| Granted |  | 3,718 |  |  |  |  |  |  |  |
| Exercised |  | (389 | ) |  |  |  |  |  |  | $ | 1,121 |  |
| Cancelled or expired |  | (2,679 | ) |  |  |  |  |  |  |  |
| Outstanding, March 31, 2013 |  | 13,684 |  |  |  |  |  |  |  |  |
| Granted |  | — |  |  |  |  |  |  |  |  |
| Exercised |  | (551 | ) |  |  |  |  |  |  | $ | 2,045 |  |
| Cancelled or expired |  | (3,317 | ) |  |  |  |  |  |  |  |
| Outstanding, March 31, 2014 |  | 9,816 |  |  | $ | 16 |  |  |  |  |  |  |
| Granted |  | — |  |  | $ | — |  |  |  |  |  |  |
| Exercised |  | (390 | ) |  | $ | 11 |  |  |  |  | $ | 1,505 |  |
| Cancelled or expired |  | (1,550 | ) |  | $ | 16 |  |  |  |  |  |  |
| Outstanding, March 31, 2015 |  | 7,876 |  |  | $ | 18 |  |  | 4.2 |  | $ | 10,177 |  |
| Vested and expected to vest, March 31, 2015 |  | 6,546 |  |  | $ | 18 |  |  | 3.6 |  | $ | 7,308 |  |
| Vested and exercisable, March 31, 2015 |  | 6,296 |  |  | $ | 19 |  |  | 3.5 |  | $ | 6,028 |  |

[0001032975-15-000023:notes:153]
The options outstanding as of March 31, 2015 above includes 1.3 million shares of unvested market-based awards. The number of shares expected to vest for market-based awards is calculated assuming March 31, 2015 was the end of the performance contingency period.

[0001032975-15-000023:notes:154]
As of March 31, 2015, the exercise price of outstanding options ranged from $1 to $39 per option.

[0001032975-15-000023:notes:155]
The tax benefit realized for the tax deduction from options exercised during the fiscal years 2015, 2014 and 2013 was $0.5 million, $0.5 million and $0.3 million, respectively.

[0001032975-15-000023:notes:156]
A summary of the Company's time-based, market-based, and performance-based RSU activities for fiscal years 2015, 2014 and 2013 is as follows (in thousands, except per share values; grant-date fair values are weighted averages):

[0001032975-15-000023:notes:157]
|  |  | Number of Shares |  | Weighted-Average Grant Date Fair Value |  | Weighted-Average Remaining Vesting Period |  | Aggregate Intrinsic Value |
|  |  | (In thousands) |  |  |  | (Years) |  | (In thousands) |
| Outstanding, March 31, 2012 |  | 4,125 |  |  |  |  |  |  |  |  |
| Granted—time-based |  | 2,219 |  |  | $ | 7 |  |  |  |  |  |
| Granted—market-based |  | 101 |  |  | $ | 6 |  |  |  |  |  |
| Vested |  | (1,097 | ) |  |  |  |  |  |  | $ | 8,329 |  |
| Cancelled or expired |  | (706 | ) |  |  |  |  |  |  |  |
| Outstanding, March 31, 2013 |  | 4,642 |  |  |  |  |  |  |  |  |
| Granted—time-based |  | 3,104 |  |  | $ | 11 |  |  |  |  |  |
| Granted—market-based |  | 1,060 |  |  | $ | 8 |  |  |  |  |  |
| Vested |  | (1,560 | ) |  |  |  |  |  |  | $ | 17,810 |  |
| Cancelled or expired |  | (1,158 | ) |  |  |  |  |  |  |  |
| Outstanding, March 31, 2014 |  | 6,088 |  |  | $ | 10 |  |  |  |  |  |
| Granted—time-based |  | 1,332 |  |  | $ | 13 |  |  |  |  |  |
| Granted—market-based |  | 523 |  |  | $ | 13 |  |  |  |  |  |
| Granted - performance-based |  | 55 |  |  | $ | 12 |  |  |  |  |  |
| Vested |  | (1,949 | ) |  | $ | 10 |  |  |  |  | $ | 27,844 |  |
| Cancelled or expired |  | (1,110 | ) |  | $ | 11 |  |  |  |  |  |
| Outstanding, March 31, 2015 |  | 4,939 |  |  | $ | 11 |  |  | 1.5 |  | $ | 64,944 |  |
| Expected to vest, March 31, 2015 |  | 3,466 |  |  | $ | 10 |  |  | 1.3 |  | $ | 45,580 |  |

[0001032975-15-000023:notes:158]
The RSU outstanding as of March 31, 2015 above includes 1.2 million shares of market-based and performance-based shares. The number of shares expected to vest for these awards is calculated assuming March 31, 2015 is the end of the performance contingency period. The number of shares of common stock for market-based awards to be received at vesting will range from zero percent to 150 percent of the target number of stock units based on our total stockholder return (“TSR”) relative to the performance of companies in the NASDAQ-100 Index for each measurement period, generally over a three year period. We present shares granted at 100 percent of target of the number of stock units that may potentially vest.

[0001032975-15-000023:notes:159]
The tax benefit realized for the tax deduction from RSUs that vested during the fiscal years 2015, 2014 and 2013 was $6.9 million, $4.7 million and $1.9 million, respectively.

[0001032975-15-000023:notes:160]
Defined Contribution Plans

[0001032975-15-000023:notes:161]
Certain of the Company's subsidiaries have defined contribution employee benefit plans covering all or a portion of their employees. Contributions to these plans are discretionary for certain plans and are based on specified or statutory requirements for others. The charges to expense for these plans for fiscal years 2015, 2014 and 2013, were $5.8 million, $6.6 million and $6.9 million, respectively.

[0001032975-15-000023:notes:162]
Defined Benefit Plans

[0001032975-15-000023:notes:163]
Certain of the Company's subsidiaries sponsor defined benefit pension plans or non-retirement post-employment benefits covering substantially all of their employees. Benefits are provided based on employees' years of service and earnings, or in accordance with applicable employee benefit regulations. The Company's practice is to fund amounts sufficient to meet the requirements set forth in the applicable employee benefit and tax regulations.

[0001032975-15-000023:notes:164]
The Company recognizes the overfunded or underfunded status of defined benefit pension plans and non-retirement post-employment benefit obligations as an asset or liability in its consolidated balance sheets, and recognizes changes in the funded status of defined benefit pension plans in the year in which the changes occur through accumulated other comprehensive income (loss), which is a component of shareholders' equity. Each plan's assets and benefit obligations are remeasured as of March 31 each year.

[0001032975-15-000023:notes:165]
The net periodic benefit cost of the defined benefit pension plans and the non-retirement post-employment benefit obligations for fiscal years 2015, 2014 and 2013 was as follows (in thousands):

[0001032975-15-000023:notes:166]
|  |  | Years Ended March 31, |
|  |  | 2015 |  | 2014 |  | 2013 |
| Service costs |  | $ | 7,646 |  |  | $ | 8,591 |  |  | $ | 7,842 |  |
| Interest costs |  | 1,970 |  |  | 1,794 |  |  | 1,852 |  |
| Expected return on plan assets |  | (2,084 | ) |  | (1,727 | ) |  | (1,710 | ) |
| Amortization: |  |  |  |  |  |  |
| Net transition obligation |  | 4 |  |  | 4 |  |  | 5 |  |
| Net prior service costs (credit) recognized |  | (45 | ) |  | 210 |  |  | 712 |  |
| Net actuarial loss recognized |  | 301 |  |  | 592 |  |  | 846 |  |
| Settlement and curtailment |  | (13 | ) |  | 769 |  |  | 2,658 |  |
|  |  | $ | 7,779 |  |  | $ | 10,233 |  |  | $ | 12,205 |  |

[0001032975-15-000023:notes:167]
The changes in projected benefit obligations for fiscal years 2015 and 2014 were as follows (in thousands):

[0001032975-15-000023:notes:168]
|  |  | Years Ended March 31, |
|  |  | 2015 |  | 2014 |
| Projected benefit obligations, beginning of the year |  | $ | 102,383 |  |  | $ | 90,234 |  |
| Service costs |  | 7,646 |  |  | 8,591 |  |
| Interest costs |  | 1,970 |  |  | 1,794 |  |
| Plan participant contributions |  | 2,914 |  |  | 2,726 |  |
| Actuarial (gains) losses |  | 16,768 |  |  | (2,942 | ) |
| Benefits paid |  | (5,307 | ) |  | (1,841 | ) |
| Plan amendment related to statutory change |  | (3,936 | ) |  | — |  |
| Settlement and curtailment |  | (157 | ) |  | (1,261 | ) |
| Administrative expense paid |  | (160 | ) |  | (174 | ) |
| Currency exchange rate changes |  | (8,798 | ) |  | 5,256 |  |
| Projected benefit obligations, end of the year |  | $ | 113,323 |  |  | $ | 102,383 |  |

[0001032975-15-000023:notes:169]
The accumulated benefit obligation for all defined benefit pension plans as of March 31, 2015 and 2014 was $92.0 million and $83.2 million, respectively.

[0001032975-15-000023:notes:170]
The following table presents the changes in the fair value of defined benefit pension plan assets for fiscal years 2015 and 2014 (in thousands):

[0001032975-15-000023:notes:171]
|  |  | Years Ended March 31, |
|  |  | 2015 |  | 2014 |
| Fair value of plan assets, beginning of the year |  | $ | 63,384 |  |  | $ | 48,689 |  |
| Actual return on plan assets |  | 136 |  |  | 5,334 |  |
| Employer contributions |  | 5,731 |  |  | 5,390 |  |
| Plan participant contributions |  | 2,914 |  |  | 2,726 |  |
| Benefits paid |  | (5,307 | ) |  | (1,841 | ) |
| Settlement and curtailment |  | (157 | ) |  | (500 | ) |
| Administrative expenses paid |  | (160 | ) |  | (174 | ) |
| Currency exchange rate changes |  | (5,631 | ) |  | 3,760 |  |
| Fair value of plan assets, end of the year |  | $ | 60,910 |  |  | $ | 63,384 |  |

[0001032975-15-000023:notes:172]
The Company's investment objectives are to ensure that the assets of its defined benefit plans are invested to provide an optimal rate of investment return on the total investment portfolio, consistent with the assumption of a reasonable risk level, and to ensure that pension funds are available to meet the plans' benefit obligations as they become due. The Company believes that a well-diversified investment portfolio will result in the highest attainable investment return with an acceptable level of overall risk. Investment strategies and allocation decisions are also governed by applicable governmental regulatory agencies. The Company's investment strategy with respect to its largest defined benefit plan, which is available only to Swiss employees, is to invest in the following allocation ranges starting from January 2014: 20-55% for equities, 25-60% for bonds, and 0-10% for cash and cash equivalents. The Company also can invest in real estate funds, commodity funds, and hedge funds depend upon economic conditions. Prior to January 2014, the Company followed the following allocation ranges: 28-43% for equities, 33-63% for Swiss bonds, 5-15% for foreign bonds, 5-15% for hedge and investment funds, and 0-20% for cash and cash equivalents. The Company's other defined benefit plans, which comprise 7.2% of total defined benefit plan assets as of March 31, 2015, have similar investment and allocation strategies.

[0001032975-15-000023:notes:173]
The following tables present the fair value of the defined benefit pension plan assets by major categories and by levels within the fair value hierarchy as of March 31, 2015 and 2014 (in thousands):

[0001032975-15-000023:notes:174]
|  |  | March 31, |
|  |  | 2015 |  | 2014 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Cash |  | $ | 7,958 |  |  | $ | 46 |  |  | $ | — |  |  | $ | 8,004 |  |  | $ | 10,339 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,339 |  |
| Equity securities |  | 20,476 |  |  | — |  |  | — |  |  | 20,476 |  |  | 17,324 |  |  | — |  |  | — |  |  | 17,324 |  |
| Debt securities |  | 20,357 |  |  | — |  |  | — |  |  | 20,357 |  |  | 20,300 |  |  | — |  |  | — |  |  | 20,300 |  |
| Swiss real estate funds |  | 8,586 |  |  | — |  |  | — |  |  | 8,586 |  |  | 8,970 |  |  | — |  |  | — |  |  | 8,970 |  |
| Hedge funds |  | — |  |  | 3,251 |  |  | — |  |  | 3,251 |  |  | — |  |  | 3,611 |  |  | — |  |  | 3,611 |  |
| Insurance contracts |  | — |  |  | 114 |  |  | — |  |  | 114 |  |  | — |  |  | — |  |  | 2,598 |  |  | 2,598 |  |
| Other |  | 28 |  |  | 94 |  |  | — |  |  | 122 |  |  | 43 |  |  | 199 |  |  | — |  |  | 242 |  |
|  |  | $ | 57,405 |  |  | $ | 3,505 |  |  | $ | — |  |  | $ | 60,910 |  |  | $ | 56,976 |  |  | $ | 3,810 |  |  | $ | 2,598 |  |  | $ | 63,384 |  |

[0001032975-15-000023:notes:175]
The funded status of the plans was as follows (in thousands):

[0001032975-15-000023:notes:176]
|  |  | Years Ended March 31, |
|  |  | 2015 |  | 2014 |
| Fair value of plan assets |  | $ | 60,910 |  |  | $ | 63,384 |  |
| Less: Projected benefit obligations |  | 113,323 |  |  | 102,383 |  |
| Under funded status |  | $ | (52,413 | ) |  | $ | (38,999 | ) |

[0001032975-15-000023:notes:177]
Amounts recognized on the balance sheet for the plans were as follows (in thousands):

[0001032975-15-000023:notes:178]
|  |  | March 31, |
|  |  | 2015 |  | 2014 |
| Current liabilities |  | $ | (1,232 | ) |  | $ | (1,100 | ) |
| Non-current liabilities |  | (51,181 | ) |  | (37,899 | ) |
| Net liabilities |  | $ | (52,413 | ) |  | $ | (38,999 | ) |

[0001032975-15-000023:notes:179]
Amounts recognized in accumulated other comprehensive loss related to defined benefit pension plans were as follows (in thousands):

[0001032975-15-000023:notes:180]
|  |  | March 31, |
|  |  | 2015 |  | 2014 |  | 2013 |
| Net prior service costs (credits) |  | $ | 1,672 |  |  | $ | (2,149 | ) |  | $ | (2,307 | ) |
| Net actuarial loss |  | (28,751 | ) |  | (12,319 | ) |  | (19,850 | ) |
| Net transition obligation |  | (8 | ) |  | (12 | ) |  | (14 | ) |
| Accumulated other comprehensive loss |  | (27,087 | ) |  | (14,480 | ) |  | (22,171 | ) |
| Deferred tax benefit |  | 123 |  |  | 192 |  |  | 315 |  |
| Accumulated other comprehensive loss, net of tax |  | $ | (26,964 | ) |  | $ | (14,288 | ) |  | $ | (21,856 | ) |

[0001032975-15-000023:notes:181]
The following table presents the amounts included in accumulated other comprehensive loss as of March 31, 2015, which are expected to be recognized as a component of net periodic benefit cost in fiscal year 2016 (in thousands):

[0001032975-15-000023:notes:182]
|  |  | Year EndingMarch 31, 2016 |
| Amortization of net transition obligation |  | $ | 4 |  |
| Amortization of net prior service credits |  | (121 | ) |
| Amortization of net actuarial loss |  | 1,750 |  |
|  |  | $ | 1,633 |  |

[0001032975-15-000023:notes:183]
The Company reassesses its benefit plan assumptions on a regular basis. The actuarial assumptions for the defined benefit plans for fiscal years 2015 and 2014 were as follows:

[0001032975-15-000023:notes:184]
|  |  | Years Ended March 31, |
|  |  | 2015 |  | 2014 |
| Benefit Obligations: |  |  |  |  |
| Discount rate |  | 0.75%-7.75% |  | 1.50%-9.25% |
| Estimated rate of compensation increase |  | 2.50%-8.00% |  | 3.00%-8.00% |
| Periodic Costs: |  |  |  |  |
| Discount rate |  | 1.50%-9.25% |  | 1.50%-8.00% |
| Estimated rate of compensation increase |  | 2.50%-8.00% |  | 3.00%-4.00% |
| Expected average rate of return on plan assets |  | 0.75%-3.50% |  | 0.75%-3.50% |

[0001032975-15-000023:notes:185]
The discount rate is estimated based on corporate bond yields or securities of similar quality in the respective country, with a duration approximating the period over which the benefit obligations are expected to be paid. The Company bases the compensation increase assumptions on historical experience and future expectations. The expected average rate of return for the Company's defined benefit pension plans represents the average rate of return expected to be earned on plan assets over the period that the benefit obligations are expected to be paid, based on government bond notes in the respective country, adjusted for corporate risk premiums as appropriate.

[0001032975-15-000023:notes:186]
The following table reflects the benefit payments that the Company expects the plans to pay in the periods noted (in thousands):

[0001032975-15-000023:notes:187]
| Years Ending March 31, |  |  |
| 2016 |  | $ | 4,583 |  |
| 2017 |  | 4,790 |  |
| 2018 |  | 4,987 |  |
| 2019 |  | 5,329 |  |
| 2020 |  | 6,014 |  |
| 2021-2025 |  | 29,245 |  |
|  |  | $ | 54,948 |  |

[0001032975-15-000023:notes:188]
The Company expects to contribute $4.7 million to its defined benefit pension plans during fiscal year 2016.

[0001032975-15-000023:notes:189]
Deferred Compensation Plan

[0001032975-15-000023:notes:190]
One of the Company's subsidiaries offers a deferred compensation plan that permits eligible employees to make 100% vested salary and incentive compensation deferrals within established limits. The Company does not make contributions to the plan.

[0001032975-15-000023:notes:191]
The fair value of the deferred compensation plan's assets is included in other assets on the consolidated balance sheets. The marketable securities are classified as trading investments and were recorded at a fair value of $17.2 million and $16.6 million as of March 31, 2015 and 2014, respectively, based on quoted market prices. The Company also had $17.2 million and $16.6 million deferred compensation liability as of March 31, 2015 and 2014, respectively. Earnings, gains and losses on trading investments are included in other income (expense), net and corresponding changes in deferred compensation liability are included in operating expenses and cost of goods sold.


## us-gaap:DebtDisclosureTextBlock

[0001032975-15-000023:notes:192]
Financing Arrangements

[0001032975-15-000023:notes:193]
The Company had several uncommitted, unsecured bank lines of credit aggregating $38.1 million as of March 31, 2015. There are no financial covenants under these lines of credit with which the Company must comply. As of March 31, 2015, the Company had outstanding bank guarantees of $5.1 million under these lines of credit. There was no borrowing outstanding under the line of credit as of March 31, 2015 or March 31, 2014.


## us-gaap:EarningsPerShareTextBlock

[0001032975-15-000023:notes:194]
The computations of basic and diluted net income (loss) per share for the Company were as follows (in thousands except per share amounts):

[0001032975-15-000023:notes:195]
|  |  | Years Ended March 31, |
|  |  | 2015 |  | 2014 |  | 2013 |
| Net income (loss) |  | $ | 9,283 |  |  | $ | 74,304 |  |  | $ | (227,518 | ) |
| Shares used in net income (loss) per share computation: |  |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding—basic |  | 163,536 |  |  | 160,619 |  |  | 158,468 |  |
| Effect of potentially dilutive equivalent shares |  | 2,638 |  |  | 1,907 |  |  | — |  |
| Weighted average shares outstanding—diluted |  | 166,174 |  |  | 162,526 |  |  | 158,468 |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.06 |  |  | $ | 0.46 |  |  | $ | (1.44 | ) |
| Diluted |  | $ | 0.06 |  |  | $ | 0.46 |  |  | $ | (1.44 | ) |

[0001032975-15-000023:notes:196]
During fiscal years 2015, 2014 and 2013, 9.0 million, 15.1 million and 22.9 million share equivalents attributable to outstanding stock options, RSUs and ESPP were excluded from the calculation of diluted net income (loss) per share because the combined exercise price, average unamortized fair value and assumed tax benefits upon exercise of these options and ESPP or vesting of RSUs were greater than the average market price of the Company's shares, and therefore their inclusion would have been anti-dilutive.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001032975-15-000023:notes:197]
Fair Value Measurements

[0001032975-15-000023:notes:198]
The Company considers fair value as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants at the measurement date. The Company utilizes the following three-level fair value hierarchy to establish the priorities of the inputs used to measure fair value:

[0001032975-15-000023:notes:199]
| • | Level 1—Quoted prices in active markets for identical assets or liabilities. |

[0001032975-15-000023:notes:200]
| • | Level 2—Observable inputs other than quoted market prices included in Level 1, such as quoted prices for similar assets and liabilities in active markets; quoted prices for identical or similar assets and liabilities in markets that are not active; or other inputs that are observable or can be corroborated by observable market data. |

[0001032975-15-000023:notes:201]
| • | Level 3—Unobservable inputs that are supported by little or no market activity and that are significant to the fair value of the assets or liabilities. This includes certain pricing models, discounted cash flow methodologies and similar techniques that use significant unobservable inputs. |

[0001032975-15-000023:notes:202]
The following table presents the Company's financial assets and liabilities, that were accounted for at fair value on a recurring basis, excluding assets related to the Company's defined benefit pension plans, classified by the level within the fair value hierarchy (in thousands):

[0001032975-15-000023:notes:203]
|  |  | March 31, 2015 |  | March 31, 2014 |
|  |  | Level 1 |  | Level 2 |  | Level 1 |  | Level 2 |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 264,647 |  |  | $ | — |  |  | $ | 200,641 |  |  | $ | — |  |
|  |  | $ | 264,647 |  |  | $ | — |  |  | $ | 200,641 |  |  | $ | — |  |
| Trading investments for deferred compensation plan: |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 2,936 |  |  | $ | — |  |  | $ | 3,139 |  |  | $ | — |  |
| Mutual funds |  | 14,301 |  |  | — |  |  | 13,472 |  |  | — |  |
|  |  | $ | 17,237 |  |  | $ | — |  |  | $ | 16,611 |  |  | $ | — |  |
| Foreign exchange derivative assets |  | $ | — |  |  | $ | 2,080 |  |  | $ | — |  |  | $ | 155 |  |
| Foreign exchange derivative liabilities |  | $ | — |  |  | $ | 75 |  |  | $ | — |  |  | $ | 701 |  |

[0001032975-15-000023:notes:204]
There were no material level 3 financial assets held by the Company during fiscal years 2015 or 2014.

[0001032975-15-000023:notes:205]
Investment Securities

[0001032975-15-000023:notes:206]
The marketable securities for the Company's deferred compensation plan are recorded at a fair value of $17.2 million and $16.6 million as of March 31, 2015 and 2014, respectively, based on quoted market prices. Quoted market prices are observable inputs that are classified as Level 1 within the fair value hierarchy. Unrealized trading gains related to trading securities for the fiscal years 2015, 2014 and 2013 were not significant and are included in other income (expense), net.

[0001032975-15-000023:notes:207]
Under certain agreements with the respective counterparties to the Company's derivative contracts, subject to applicable requirements, the Company is allowed to net settle transactions of the same type with a single net amount payable by one party to the other. However, the Company presents its derivative assets and derivative liabilities on a gross basis on the Consolidated Balance Sheets as of March 31, 2015 and 2014.

[0001032975-15-000023:notes:208]
The following table presents the fair values of the Company's derivative instruments as of March 31, 2015 and 2014 (in thousands):

[0001032975-15-000023:notes:209]
|  |  | Derivatives |
|  |  | Asset |  | Liability |
|  |  | March 31, |  | March 31, |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash flow hedges |  | $ | 2,080 |  |  | $ | 4 |  |  | $ | — |  |  | $ | 243 |  |
| Not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | — |  |  | 151 |  |  | 75 |  |  | 458 |  |
|  |  | $ | 2,080 |  |  | $ | 155 |  |  | $ | 75 |  |  | $ | 701 |  |

[0001032975-15-000023:notes:210]
The following table presents the amounts of gains and losses on the Company's derivative instruments for fiscal years 2015, 2014 and 2013 and their locations on its consolidated statements of operations and consolidated statements of comprehensive income (in thousands):

[0001032975-15-000023:notes:211]
|  | Amount ofGain (Loss) Deferred asa Component ofAccumulated OtherComprehensive Loss After Reclassification to Costs of Goods Sold |  | Amount of Loss (Gain)Reclassified fromAccumulated OtherComprehensive Lossto Costs of Goods Sold |  | Amount ofGain (Loss)Immediately Recognizedin Other Income(Expense), Net |
|  | 2015 |  | 2014 |  | 2013 |  | 2015 |  | 2014 |  | 2013 |  | 2015 |  | 2014 |  | 2013 |
| Designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash flow hedges | $ | 4,466 |  |  | $ | (1,025 | ) |  | $ | 566 |  |  | $ | (4,505 | ) |  | $ | 2,472 |  |  | $ | 1,756 |  |  | $ | 20 |  |  | $ | (126 | ) |  | $ | 275 |  |
| Not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 2,479 |  |  | 824 |  |  | 328 |  |
|  | $ | 4,466 |  |  | $ | (1,025 | ) |  | $ | 566 |  |  | $ | (4,505 | ) |  | $ | 2,472 |  |  | $ | 1,756 |  |  | $ | 2,499 |  |  | $ | 698 |  |  | $ | 603 |  |

[0001032975-15-000023:notes:212]
Cash Flow Hedges:   The Company enters into foreign exchange forward contracts to hedge against exposure to changes in currency exchange rates related to its subsidiaries' forecasted inventory purchases. The Company has one entity with a Euro functional currency that purchases inventory in U.S. Dollars. The primary risk managed by using derivative instruments is the currency exchange rate risk. The Company has designated these derivatives as cash flow hedges. These hedging contracts mature within four months, and are denominated in the same currency as the underlying transactions. Gains and losses in the fair value of the effective portion of the hedges are deferred as a component of accumulated other comprehensive loss until the hedged inventory purchases are sold, at which time the gains or losses are reclassified to cost of goods sold. The Company assesses the effectiveness of the hedges by comparing changes in the spot rate of the currency underlying the forward contract with changes in the spot rate of the currency in which the forecasted transaction will be consummated. If the underlying transaction being hedged fails to occur or if a portion of the hedge does not generate offsetting changes in the currency exposure of forecasted inventory purchases, the Company immediately recognizes the gain or loss on the associated financial instrument in other income (expense), net. Such gains and losses were not material during fiscal years 2015, 2014 and 2013. Cash flows from such hedges are classified as operating activities in the Consolidated Statements of Cash Flows. As of March 31, 2015, and 2014, the notional amounts of foreign exchange forward contracts outstanding related to forecasted inventory purchases were $43.5 million and $51.8 million, respectively. The Company estimates that $4.0 million of net gains related to its cash flow hedges included in accumulated other comprehensive loss as of March 31, 2015 will be reclassified into earnings within the next 12 months.

[0001032975-15-000023:notes:213]
Other Derivatives:   The Company also enters into foreign exchange forward and swap contracts to reduce the short-term effects of currency fluctuations on certain foreign currency receivables or payables. These forward and swap contracts generally mature within one month. The primary risk managed by using forward and swap contracts is the currency exchange rate risk. The gains or losses on foreign exchange forward contracts are recognized in other income (expense), net based on the changes in fair value.

[0001032975-15-000023:notes:214]
The notional amounts of foreign exchange forward and swap contracts outstanding as of March 31, 2015 and 2014 relating to foreign currency receivables or payables were $61.7 million and $53.7 million, respectively. Open forward and swap contracts as of March 31, 2015 and 2014 consisted of contracts in Taiwanese Dollars, Australian Dollars, Mexican Pesos, Japanese Yen and British Pounds to be settled at future dates at pre-determined exchange rates.

[0001032975-15-000023:notes:215]
The fair value of all foreign exchange forward and swap contracts is determined based on observable market transactions of spot currency rates and forward rates. Cash flows from these contracts are classified as operating activities in the Consolidated Statements of Cash Flows.

[0001032975-15-000023:notes:216]
Non-Financial Assets Measured at Fair Value on a Nonrecurring Basis

[0001032975-15-000023:notes:217]
The majority of the Company's non-financial assets and liabilities, which include goodwill, intangible assets, inventories, and property, plant and equipment, are not required to be measured at fair value on a recurring basis. However, if certain triggering events occur (or tested at least annually for goodwill) such that a non-financial instrument is required to be evaluated for impairment and an impairment is recorded to reduce the non-financial instrument's carrying value to the fair value as a result of such triggering events, the non-financial assets and liabilities are measured at fair value for the period such triggering events occur. See Note 2 herein, for additional information about how we test various asset classes for impairment. During fiscal year 2015, the Company recognized $122.7 million of impairment related to goodwill of its Video Conferencing reporting unit and the carrying value of which was written down to zero based on Level 3 inputs.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001032975-15-000023:notes:218]
Annual Goodwill Impairment Testing

[0001032975-15-000023:notes:219]
The Company conducts a goodwill impairment analysis annually at December 31 or more frequently if indicators of impairment exist or if a decision is made to sell or exit a business. A significant amount of judgment is involved in determining if an indicator of impairment has occurred. Such indicators may include deterioration in general economic conditions, negative developments in equity and credit markets, adverse changes in the markets in which an entity operates, increases in input costs that have a negative effect on earnings and cash flows, a trend of negative or declining cash flows, a decline in actual or planned revenue or earnings compared with actual and projected results of relevant prior periods, or other relevant entity-specific events such as changes in management, key personnel, strategy, or customers, contemplation of bankruptcy, or litigation. The fair value that could be realized in an actual transaction may differ from that used to evaluate the impairment of goodwill.

[0001032975-15-000023:notes:220]
In reviewing goodwill for impairment, an entity has the option to first assess qualitative factors to determine whether the existence of events or circumstances leads to a determination that it is more likely than not (greater than 50%) that the estimated fair value of a reporting unit is less than its carrying amount. If an entity elects to perform a qualitative assessment and determines that an impairment is more likely than not, the entity is then required to perform the two-step quantitative impairment test; otherwise, no further analysis is required. An entity also may elect not to perform the qualitative assessment and, instead, proceed directly to the two-step quantitative impairment test. The ultimate outcome of the goodwill impairment review for a reporting unit should be the same whether an entity chooses to perform the qualitative assessment or proceeds directly to the two-step quantitative impairment test. Goodwill is allocated among and evaluated for impairment at the reporting unit level, which is defined as an operating segment or one level below an operating segment. The Company has two reporting units, peripherals and video conferencing.

[0001032975-15-000023:notes:221]
Peripherals

[0001032975-15-000023:notes:222]
The Company performed its annual impairment analysis of the goodwill for its peripherals reporting unit at December 31, 2014 by performing a qualitative assessment and concluded that it was more likely than not that the fair value of its peripherals reporting unit exceeded its carrying amount.  In assessing the qualitative factors, the Company considered the impact of these key factors: change in industry and competitive environment, growth in market capitalization of $2.3 billion as of December 31, 2014 from $2.2 billion a year ago, and budgeted-to-actual revenue performance from the prior year. The peripherals reporting unit has seen an improvement in operating income from $64.8 million and $117.8 million for the three and nine months ended December 31, 2013 to $76.1 million and $160.3 million for the three and nine months ended December 31, 2014, respectively. No recent events or changes in circumstances indicate that impairment existed as of March 31, 2015.

[0001032975-15-000023:notes:223]
Video Conferencing

[0001032975-15-000023:notes:224]
The Company proceeded directly to the two-step quantitative impairment test for the video conferencing reporting unit and performed a Step 1 assessment at December 31, 2014. The Company uses a third party valuation expert in the development of its market and income approach models. The annual Step 1 assessment performed as of December 31, 2014 resulted in the Company determining that the video conferencing reporting unit passed the Step 1 test because the estimated fair value of the video conferencing reporting unit from the Step 1 assessment exceeded its carrying value by approximately 38.0%, thus not requiring a Step 2 assessment of this reporting unit. Therefore, the Company concluded it was more likely than not that the goodwill of the video conferencing reporting unit was not impaired as of December 31, 2014.

[0001032975-15-000023:notes:225]
During the fourth quarter of the fiscal year ended March 31, 2015, the net sales of the video conferencing reporting unit decreased to $24.9 million from $31.0 million in the fourth quarter of the fiscal year ended March 31, 2014 and from $29.9 million in the third quarter of fiscal year ended March 31, 2015. The sales decline was concentrated in the video conferencing infrastructure legacy business primarily due to faster shift of customer preference towards Cloud infrastructure conferencing versus on-premise infrastructure solutions and resource realignment, which was not anticipated during annual impairment assessment as of December 31, 2014. This quick shift towards Cloud-based offering resulted in the change in business strategy to de-emphasize Lifesize’s legacy offerings more quickly than planned to enable maximum traction of the Lifesize Cloud, which would result in shrinking the legacy Lifesize business but could grow the Cloud opportunity faster. In the last nine months, the sales of Cloud-based offerings have grown rapidly; however, they are not yet large enough to offset the combination of the short-term portfolio transition. As a result of the lower-than-expected performance in the legacy infrastructure sales, the Company made a strategic decision to sharpen its focus on its new Cloud-based offering. The Company plans to realign its costs and operations to this new strategy as part of a restructuring plan announced during April 2015 and will explore various other options for its Lifesize business. The significant change in business strategy has adversely affected the near-term projections and the Company expects that it will shrink the Lifesize revenue for the next several years, including lowering the overall growth, pushing out the break-even point and increasing the operating loss as well as increasing uncertainty in the near term. In light of the aforementioned, the Company concluded it was appropriate to perform the Step 1 goodwill impairment assessment.

[0001032975-15-000023:notes:226]
As of March 31, 2015, taking into consideration the video conferencing reporting unit’s updated business outlook for fiscal year 2016 and onwards based on the factors discussed above, and the risk of execution of its refocused strategy, the Company updated the future cash flow assumptions for the video conferencing reporting unit and calculated updated estimates of fair value using the income approach. In particular, the Company lowered its December 31, 2014 goodwill impairment test projections of future revenue and operating income (loss) growth and adjusted other factors (such as working capital and capital expenditure). After updating the assumptions and projections, the Company then calculated a present value of the cash flow to arrive at an estimate of fair value under the income approach as of March 31, 2015. Key assumptions included in the income approach were significant reduction in the revenue assumption for fiscal year 2016 through fiscal year 2021 compared with the revenue assumption used in the Company's annual goodwill impairment assessment as of December 31, 2014, CAGR at 7.2%, discount rate at 14%, and terminal growth rate at 4.0%. Consistent with the annual impairment test on December 31, 2014, the Company also updated the estimates of fair value determined under the market approach. Based on the income approach and market approach, the estimated fair value of the video conferencing reporting unit under the Step 1 assessment was lower than the carrying amount of the net asset including goodwill.

[0001032975-15-000023:notes:227]
The video conferencing reporting unit failed the Step 1 test as prescribed under ASC 350, thus requiring a Step 2 assessment of this reporting unit to determine the goodwill impairment. In determining the impairment amount, the fair value of the video conferencing reporting unit was allocated to its assets and liabilities, including any unrecognized intangible assets not on the balance sheet, based on their respective fair values. Assumptions used in measuring the value of these assets and liabilities included the discount rates, working capital, and technology obsolescence rates used in valuing the intangible assets, and pricing of comparable transactions in the market in valuing the tangible assets. Based on this allocation, the implied value of intangible assets and tangible net assets fully absorbed the fair value of the business, leaving no implied fair value left to be allocated to the goodwill. The video conferencing reporting unit's carrying value of goodwill exceeded the implied fair value of goodwill, resulting in a goodwill impairment charge of $122.7 million, which is recorded in the Consolidated Statement of Operations.

[0001032975-15-000023:notes:228]
The current assessment represents the fair value of the video conferencing business as of March 31, 2015. If the Company disposes all or any equity interest of the video conferencing reporting unit in the future, it may result in a gain. The gain will be recognized as a difference between the carrying amount of the video conferencing reporting unit and the proceeds, if any, received from such a disposal.

[0001032975-15-000023:notes:229]
During fiscal year 2013, the Company's video conferencing reporting unit failed the Step 1 test because the estimated fair value was less than its carrying value, thus requiring Step 2 assessment of this reporting unit. This impairment primarily resulted from a decrease in the expected CAGR during the assessment forecast period based on greater evidence of the overall enterprise video conferencing industry experiencing a slowdown, combined with lower demand related to new product launches, increased competition during fiscal year 2013, and other market data. These factors had an adverse effect on the Company's video conferencing operating results and future outlook. During fiscal year 2013, the Company recorded goodwill impairment and other charges of $214.5 million related to its video conferencing reporting unit.

[0001032975-15-000023:notes:230]
Determining the fair value of a reporting unit is judgmental in nature and requires the use of significant estimates and assumptions, including revenue growth rates, operating margins, discount rates and future market conditions, among others. A goodwill impairment charge would have the effect of decreasing the Company's earnings or increasing its losses in such period. If the Company is required to take further substantial impairment charges in future periods, its operating results would be materially and adversely affected in such period.

[0001032975-15-000023:notes:231]
The following table summarizes the activity in the Company's goodwill balance during fiscal years 2015 and 2014 (in thousands):

[0001032975-15-000023:notes:232]
|  |  | Years Ended March 31, |
|  |  | 2015 |  | 2014 |
|  |  | Peripherals |  | VideoConferencing |  | Total |  | Peripherals |  | VideoConferencing |  | Total |
| Beginning of the period |  | $ | 219,415 |  |  | $ | 125,595 |  |  | $ | 345,010 |  |  | $ | 216,744 |  |  | $ | 124,613 |  |  | $ | 341,357 |  |
| Acquisitions |  | 988 |  |  | — |  |  | 988 |  |  | 202 |  |  | — |  |  | 202 |  |
| Impairment |  | — |  |  | (122,734 | ) |  | (122,734 | ) |  | — |  |  | — |  |  | — |  |
| Currency exchange rate impact and other |  | (2,190 | ) |  | (2,861 | ) |  | (5,051 | ) |  | — |  |  | 982 |  |  | 982 |  |
| Reclassified from assets held for sale (1) |  | — |  |  | — |  |  | — |  |  | 2,469 |  |  | — |  |  | 2,469 |  |
| End of the period |  | $ | 218,213 |  |  | $ | — |  |  | $ | 218,213 |  |  | $ | 219,415 |  |  | $ | 125,595 |  |  | $ | 345,010 |  |

[0001032975-15-000023:notes:233]
_________________________________

[0001032975-15-000023:notes:234]
| (1) | Represents allocated goodwill related to the Company's Retail— Home Control product category which was classified as assets held for sale as of March 31, 2013. The allocated goodwill related to the Home Control product category was reclassified from assets held for sale as of March 31, 2014, as the Company updated its strategic plan and decided to retain its Home Control product category. |

[0001032975-15-000023:notes:235]
The Company's acquired other intangible assets subject to amortization were as follows (in thousands):

[0001032975-15-000023:notes:236]
|  |  | March 31, |
|  |  | 2015 |  | 2014 |
|  |  | Gross |  | AccumulatedAmortization |  | Net |  | Gross |  | AccumulatedAmortization |  | Net |
| Trademark and tradenames |  | $ | 13,049 |  |  | $ | (13,038 | ) |  | $ | 11 |  |  | $ | 13,091 |  |  | $ | (11,949 | ) |  | $ | 1,142 |  |
| Technology |  | 81,441 |  |  | (79,716 | ) |  | 1,725 |  |  | 83,080 |  |  | (78,257 | ) |  | 4,823 |  |
| Customer contracts/relationships |  | 38,538 |  |  | (38,408 | ) |  | 130 |  |  | 38,851 |  |  | (34,287 | ) |  | 4,564 |  |
|  |  | $ | 133,028 |  |  | $ | (131,162 | ) |  | $ | 1,866 |  |  | $ | 135,022 |  |  | $ | (124,493 | ) |  | $ | 10,529 |  |

[0001032975-15-000023:notes:237]
For fiscal years 2015, 2014 and 2013, amortization expense for other intangible assets was $8.4 million, $17.8 million and $23.6 million, respectively. The Company expects that annual amortization expense for the fiscal years 2016 and 2017 to be $1.7 million and $0.2 million, respectively.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001032975-15-000023:notes:238]
The Company is incorporated in Switzerland but operates in various countries with differing tax laws and rates. Further, a portion of the Company's income (loss) before taxes and the provision for (benefit from) income taxes is generated outside of Switzerland.

[0001032975-15-000023:notes:239]
Income (loss) before income taxes for the fiscal years 2015, 2014 and 2013 is summarized as follows (in thousands):

[0001032975-15-000023:notes:240]
|  |  | Years Ended March 31, |
|  |  | 2015 |  | 2014 |  | 2013 |
| Swiss |  | $ | 112,308 |  |  | $ | 49,503 |  |  | $ | (53,004 | ) |
| Non-Swiss |  | (98,535 | ) |  | 28,079 |  |  | (200,324 | ) |
| Income (loss) before taxes |  | $ | 13,773 |  |  | $ | 77,582 |  |  | $ | (253,328 | ) |

[0001032975-15-000023:notes:241]
The provision for (benefit from) income taxes is summarized as follows (in thousands):

[0001032975-15-000023:notes:242]
|  |  | Years Ended March 31, |
|  |  | 2015 |  | 2014 |  | 2013 |
| Current: |  |  |  |  |  |  |  |  |
| Swiss |  | $ | 1,228 |  |  | $ | 127 |  |  | $ | 672 |  |
| Non-Swiss |  | 1,188 |  |  | 8,580 |  |  | (23,146 | ) |
| Deferred: |  |  |  |  |  |  |  |  |  |
| Non-Swiss |  | 2,074 |  |  | (5,429 | ) |  | (3,336 | ) |
| Provision for (benefit from) income taxes |  | $ | 4,490 |  |  | $ | 3,278 |  |  | $ | (25,810 | ) |

[0001032975-15-000023:notes:243]
The difference between the provision for (benefit from) income taxes and the expected tax provision (benefit) at the statutory income tax rate of 8.5% is reconciled below (in thousands):

[0001032975-15-000023:notes:244]
|  |  | Years Ended March 31, |
|  |  | 2015 |  | 2014 |  | 2013 |
| Expected tax provision (benefit) at statutory income tax rates |  | $ | 1,171 |  |  | $ | 6,594 |  |  | $ | (21,533 | ) |
| Income taxes at different rates |  | (2,035 | ) |  | 497 |  |  | 5,714 |  |
| Research and development tax credits |  | (1,287 | ) |  | (1,393 | ) |  | (3,302 | ) |
| Foreign tax credits |  | — |  |  | — |  |  | (1,535 | ) |
| Executive compensation |  | 1,557 |  |  | — |  |  | — |  |
| Stock-based compensation |  | 2,261 |  |  | 1,608 |  |  | 1,643 |  |
| Valuation allowance |  | 764 |  |  | 182 |  |  | 3,809 |  |
| Impairment of goodwill and other assets |  | 10,432 |  |  | — |  |  | 18,419 |  |
| Restructuring charges / (credits) |  | (415 | ) |  | 1,174 |  |  | 4,336 |  |
| Tax reserves (releases), net |  | (7,111 | ) |  | (4,660 | ) |  | 1,935 |  |
| Audit settlement |  | (837 | ) |  | (400 | ) |  | (35,608 | ) |
| Other, net |  | (10 | ) |  | (324 | ) |  | 312 |  |
| Provision for (benefit from) income taxes |  | $ | 4,490 |  |  | $ | 3,278 |  |  | $ | (25,810 | ) |

[0001032975-15-000023:notes:245]
On December 19, 2014, the enactment of the Tax Increase Prevention Act of 2014 in the United States extended the federal research and development tax credit through December 31, 2014 which had previously expired on December 31, 2013. The provision for income taxes for fiscal year ended March 31, 2015 reflected a $0.9 million tax benefit as a result of the extension of the tax credit.

[0001032975-15-000023:notes:246]
Deferred income tax assets and liabilities consist of the following (in thousands):

[0001032975-15-000023:notes:247]
|  |  | March 31, |
|  |  | 2015 |  | 2014 |
| Deferred tax assets: |  |  |  |  |  |  |
| Net operating loss carryforwards |  | $ | 8,372 |  |  | $ | 9,421 |  |
| Tax credit carryforwards |  | 2,739 |  |  | 13,241 |  |
| Accruals |  | 44,363 |  |  | 48,153 |  |
| Depreciation and amortization |  | 4,396 |  |  | 4,781 |  |
| Share-based compensation |  | 14,183 |  |  | 15,304 |  |
| Gross deferred tax assets |  | 74,053 |  |  | 90,900 |  |
| Valuation allowance |  | (5,590 | ) |  | (4,872 | ) |
| Gross deferred tax assets after valuation allowance |  | 68,463 |  |  | 86,028 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |
| Acquired intangible assets and other |  | (3,299 | ) |  | (8,436 | ) |
| Gross deferred tax liabilities |  | (3,299 | ) |  | (8,436 | ) |
| Deferred tax assets, net |  | $ | 65,164 |  |  | $ | 77,592 |  |

[0001032975-15-000023:notes:248]
Management regularly assesses the ability to realize deferred tax assets recorded in the Company's entities based upon the weight of available evidence, including such factors as recent earnings history and expected future taxable income. In the event that the Company changes its determination as to the amount of deferred tax assets that can be realized, the Company will adjust its valuation allowance with a corresponding impact to the provision for income taxes in the period in which such determination is made.

[0001032975-15-000023:notes:249]
The Company had a valuation allowance of $5.6 million at March 31, 2015, increased from $4.9 million at March 31, 2014 primarily due to $1.0 million increase in valuation allowance for deferred tax assets in the state of California of the United States. The Company had a valuation allowance of $3.6 million as of March 31, 2015 against such deferred tax assets. The remaining valuation allowance primarily represents $1.5 million for capital loss carryforwards in the United States and $0.5 million for various tax credit carryforwards. The Company determined that it is more likely than not that the Company would not generate sufficient taxable income in the future to utilize such deferred tax assets.

[0001032975-15-000023:notes:250]
Deferred tax assets relating to tax benefits of employee stock grants have been reduced to reflect settlement activity in fiscal years 2015 and 2014. Settlement activity of grants in fiscal years 2015 and 2014 resulted in a "shortfall" in which tax deductions were less than previously recorded share-based compensation expense. The Company recorded a shortfall to equity of $1.8 million and $2.8 million, respectively, in fiscal years 2015 and 2014.

[0001032975-15-000023:notes:251]
As of March 31, 2015, the Company had foreign net operating loss and tax credit carryforwards for income tax purposes of $197.8 million and $40.1 million, respectively, of which $143.3 million of the net operating loss carryforwards and $26.4 million of the tax credit carryforwards, if realized, will be credited to equity since they have not met the applicable realization criteria. Unused net operating loss carryforwards will expire at various dates in fiscal years 2016 to 2035. Certain net operating loss carryforwards in the United States relate to acquisitions and, as a result, are limited in the amount that can be utilized in any one year. The tax credit carryforwards will begin to expire in fiscal year 2019.

[0001032975-15-000023:notes:252]
As of March 31, 2015, the Company had capital loss carryforwards of $4.0 million. The loss will begin to expire in fiscal year 2016.

[0001032975-15-000023:notes:253]
Swiss income taxes and non-Swiss withholding taxes associated with the repatriation of earnings or for other temporary differences related to investments in non-Swiss subsidiaries have not been provided for, as the Company intends to reinvest the earnings of such subsidiaries indefinitely or the Company has concluded that no additional tax liability would arise on the distribution of such earnings. If these earnings were distributed to Switzerland in the form of dividends or otherwise, or if the shares of the relevant non-Swiss subsidiaries were sold or otherwise transferred, the Company may be subject to additional Swiss income taxes and non-Swiss withholding taxes. As of March 31, 2015, the cumulative amount of unremitted earnings of non-Swiss subsidiaries for which no income taxes have been provided is approximately $149.6 million. The amount of unrecognized deferred income tax liability related to these earnings is estimated to be approximately $5.0 million.

[0001032975-15-000023:notes:254]
The Company follows a two-step approach in recognizing and measuring uncertain tax positions. The first step is to evaluate the tax position for recognition by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step is to measure the tax benefit as the largest amount that is more than 50% likely of being realized upon ultimate settlement.

[0001032975-15-000023:notes:255]
As of March 31, 2015 and March 31, 2014, the total amount of unrecognized tax benefits due to uncertain tax positions was $79.0 million and $91.0 million, respectively, of which $79.0 million and $86.1 million would affect the effective income tax rate if recognized, respectively.

[0001032975-15-000023:notes:256]
As of March 31, 2015, the Company had $72.1 million in non-current income taxes payable and $0.1 million in current income taxes payable, including interest and penalties, related to our income tax liability for uncertain tax positions. As of March 31, 2014, the Company had $93.1 million in non-current income taxes payable and $0.3 million in current income taxes payable. Pursuant to ASU 2013-11, Presentation of an Unrecognized Tax Benefit When a Net Operating Loss Carryforward, a Similar Tax Loss, or a Tax Credit Carryforward Exists, which became effective in the first quarter of fiscal year 2015, the Company reclassified $10.3 million of unrecognized tax benefits previously presented as non-current income taxes payable to a reduction in non-current deferred tax assets primarily for tax credit carryforwards.

[0001032975-15-000023:notes:257]
The aggregate changes in gross unrecognized tax benefits in fiscal years 2015, 2014 and 2013 were as follows (in thousands):

[0001032975-15-000023:notes:258]
| March 31, 2012 |  | $ | 136,888 |  |
| Lapse of statute of limitations |  | (6,490 | ) |
| Settlements with tax authorities |  | (42,770 | ) |
| Decreases in balances related to tax positions taken during prior years |  | (1,500 | ) |
| Increases in balances related to tax positions taken during the year |  | 9,570 |  |
| March 31, 2013 |  | $ | 95,698 |  |
| Lapse of statute of limitations |  | (12,514 | ) |
| Settlements with tax authorities |  | (100 | ) |
| Decreases in balances related to tax positions taken during prior years |  | (778 | ) |
| Increases in balances related to tax positions taken during the year |  | 8,740 |  |
| March 31, 2014 |  | $ | 91,046 |  |
| Lapse of statute of limitations |  | (14,071 | ) |
| Settlements with tax authorities |  | (2,160 | ) |
| Decreases in balances related to tax positions taken during prior years |  | (3,544 | ) |
| Increases in balances related to tax positions taken during the year |  | 7,752 |  |
| March 31, 2015 |  | $ | 79,023 |  |

[0001032975-15-000023:notes:259]
The Company recognizes interest and penalties related to unrecognized tax positions in income tax expense. The Company recognized $0.8 million, $1.1 million and $1.0 million in interest and penalties in income tax expense during fiscal years 2015, 2014 and 2013, respectively. As of March 31, 2015, 2014 and 2013, the Company had $4.9 million, $5.6 million and $6.6 million of accrued interest and penalties related to uncertain tax positions, respectively.

[0001032975-15-000023:notes:260]
The Company files Swiss and foreign tax returns. The Company received final tax assessments in Switzerland through fiscal year 2012. For other foreign jurisdictions such as the United States, the Company is generally not subject to tax examinations for years prior to fiscal year 2011. The Company is under examination and has received assessment notices in foreign tax jurisdictions. If the examinations are resolved unfavorably, there is a possibility they may have a material negative impact on its results of operations.

[0001032975-15-000023:notes:261]
Although the Company has adequately provided for uncertain tax positions, the provisions on these positions may change as revised estimates are made or the underlying matters are settled or otherwise resolved. During fiscal year 2016, the Company will continue to review its tax positions and provide for or reverse unrecognized tax benefits as issues arise. During the next 12 months, it is reasonably possible that the amount of unrecognized tax benefits could increase or decrease significantly due to changes in tax law in various jurisdictions, new tax audits and changes in the U.S. Dollar as compared to other currencies. Excluding these factors, uncertain tax positions may decrease by as much as $17.0 million primarily from the lapse of the statutes of limitations in various jurisdictions during the next 12 months.


## us-gaap:InterestAndOtherIncomeTableTextBlock

[0001032975-15-000023:notes:262]
Other income (expense), net comprises of the following (in thousands):

[0001032975-15-000023:notes:263]
|  |  | Years Ended March 31, |
|  |  | 2015 |  | 2014 |  | 2013 |
| Investment income related to deferred compensation plan |  | $ | 1,055 |  |  | $ | 1,487 |  |  | $ | 933 |  |
| Gain on sale of securities |  | — |  |  | — |  |  | 831 |  |
| Impairment of investments |  | (2,298 | ) |  | (624 | ) |  | (3,600 | ) |
| Currency exchange gain (loss), net |  | (1,280 | ) |  | 62 |  |  | 104 |  |
| Other |  | (229 | ) |  | 1,068 |  |  | (466 | ) |
| Other income (expense), net |  | $ | (2,752 | ) |  | $ | 1,993 |  |  | $ | (2,198 | ) |


## us-gaap:InterestAndOtherIncomeTextBlock

[0001032975-15-000023:notes:264]
Interest and Other Income (Expense), net

[0001032975-15-000023:notes:265]
Interest income (expense), net comprises of the following (in thousands):

[0001032975-15-000023:notes:266]
|  |  | Years Ended March 31, |
|  |  | 2015 |  | 2014 |  | 2013 |
| Interest income |  | $ | 1,225 |  |  | $ | 1,831 |  |  | $ | 2,215 |  |
| Interest expense |  | — |  |  | (2,228 | ) |  | (1,308 | ) |
| Interest income (expense), net |  | $ | 1,225 |  |  | $ | (397 | ) |  | $ | 907 |  |


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0001032975-15-000023:notes:267]
Geographic long-lived assets information, primarily fixed assets, are reported below based on the location of the asset (in thousands):

[0001032975-15-000023:notes:268]
|  |  | March 31, |
|  |  | 2015 |  | 2014 |
| Americas |  | $ | 48,527 |  |  | $ | 45,166 |  |
| EMEA |  | 3,584 |  |  | 5,154 |  |
| Asia Pacific |  | 39,482 |  |  | 38,071 |  |
|  |  | $ | 91,593 |  |  | $ | 88,391 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001032975-15-000023:notes:269]
Restructuring

[0001032975-15-000023:notes:270]
The following table summarizes restructuring related activities during fiscal year 2015 and 2014 (in thousands):

[0001032975-15-000023:notes:271]
|  |  | Restructuring |
|  |  | TerminationBenefits |  | Lease ExitCosts |  | Total |
| Accrual balance at March 31, 2013 |  | $ | 13,383 |  |  | $ | 75 |  |  | $ | 13,458 |  |
| Charges |  | 6,463 |  |  | 7,348 |  |  | 13,811 |  |
| Adjustment for deferred rent |  | — |  |  | 1,450 |  |  | 1,450 |  |
| Cash payments |  | (19,534 | ) |  | (1,454 | ) |  | (20,988 | ) |
| Currency exchange impact |  | (170 | ) |  | — |  |  | (170 | ) |
| Accrual balance at March 31, 2014 |  | 142 |  |  | 7,419 |  |  | 7,561 |  |
| Credits |  | (86 | ) |  | (4,802 | ) |  | (4,888 | ) |
| Cash payments |  | (56 | ) |  | (1,578 | ) |  | (1,634 | ) |
| Accrual balance at March 31, 2015 |  | $ | — |  |  | $ | 1,039 |  |  | $ | 1,039 |  |

[0001032975-15-000023:notes:272]
During the second quarter of fiscal year 2014, the Company implemented a restructuring plan solely affecting its video conferencing operating segment to align its organization to its strategic priorities of increasing focus on a tighter range of products and improving profitability. Restructuring charges under this plan primarily consist of severance and other one-time termination benefits. During fiscal year 2014, restructuring charges under this plan included $5.0 million in termination benefits and $0.6 million in lease exit costs. The Company substantially completed this restructuring plan by March 31, 2014.

[0001032975-15-000023:notes:273]
During the fourth quarter of fiscal year 2013, the Company implemented a restructuring plan to align its organization to its strategic priorities of increasing focus on mobility products, improving profitability in PC-related products and enhancing global operational efficiencies. As part of this restructuring plan, the Company reduced its worldwide non-direct labor workforce. Restructuring charges under this plan primarily consisted of severance and other one-time termination benefits. During fiscal year 2015, the Company recorded a $4.9 million restructuring credit primarily as a result of partial termination of its lease agreement for the Silicon Valley campus, which was previously vacated and under the restructuring plan during fiscal year 2014. During fiscal year 2014, restructuring charges under this plan included $1.5 million in termination benefits and $6.7 million in lease exit costs, $5.4 million of which pertains to the consolidation of the Company's Silicon Valley campus from two buildings down to one during the quarter ended March 31, 2014. The Company substantially completed this restructuring plan by the fourth quarter of fiscal year 2014.

[0001032975-15-000023:notes:274]
Termination benefits were calculated based on regional benefit practices and local statutory requirements. Lease exit costs primarily relate to costs associated with the closure of existing facilities. Other charges primarily consist of legal, consulting and other costs related to employee terminations.


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001032975-15-000023:notes:275]
Net sales to unaffiliated customers by geographic region for fiscal years 2015, 2014 and 2013 (based on the customers' location) were as follows (in thousands):

[0001032975-15-000023:notes:276]
|  |  | Years Ended March 31, |
|  |  | 2015 |  | 2014 |  | 2013 |
| Americas |  | $ | 915,478 |  |  | $ | 859,893 |  |  | $ | 808,618 |  |
| EMEA |  | 710,966 |  |  | 767,017 |  |  | 799,075 |  |
| Asia Pacific |  | 487,503 |  |  | 501,803 |  |  | 491,584 |  |
|  |  | $ | 2,113,947 |  |  | $ | 2,128,713 |  |  | $ | 2,099,277 |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001032975-15-000023:notes:277]
The components of accumulated other comprehensive income (loss) were as follows (in thousands):

[0001032975-15-000023:notes:278]
|  |  | Accumulated Other Comprehensive Income (Loss) |
|  |  | CumulativeTranslationAdjustment (1) |  | DefinedBenefitPlans(1) |  | DeferredHedgingGains (Losses) |  | Total |
| March 31, 2014 |  | $ | (70,999 | ) |  | $ | (14,288 | ) |  | $ | (515 | ) |  | $ | (85,802 | ) |
| Other comprehensive income (loss) |  | (19,225 | ) |  | (12,676 | ) |  | 4,466 |  |  | (27,435 | ) |
| March 31, 2015 |  | $ | (90,224 | ) |  | $ | (26,964 | ) |  | $ | 3,951 |  |  | $ | (113,237 | ) |

[0001032975-15-000023:notes:279]
_______________________________________

[0001032975-15-000023:notes:280]
(1) Tax effect was not significant as of March 31, 2015 or 2014.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001032975-15-000023:notes:281]
Net sales and operating income (loss) for the Company's operating segments were as follows (in thousands):

[0001032975-15-000023:notes:282]
|  |  | Years Ended March 31, |
|  |  | 2015 |  | 2014 |  | 2013 |
| Net sales: |  |  |  |  |  |  |  |  |
| Peripherals |  | $ | 2,004,908 |  |  | $ | 2,008,028 |  |  | $ | 1,962,237 |  |
| Video conferencing |  | 109,039 |  |  | 120,685 |  |  | 137,040 |  |
|  |  | $ | 2,113,947 |  |  | $ | 2,128,713 |  |  | $ | 2,099,277 |  |
| Segment operating income (loss): |  |  |  |  |  |  |  |  |  |
| Peripherals(1) |  | $ | 179,136 |  |  | $ | 131,326 |  |  | $ | 25,829 |  |
| Video conferencing(1) |  | (129,650 | ) |  | (12,023 | ) |  | (229,097 | ) |
|  |  | 49,486 |  |  | 119,303 |  |  | (203,268 | ) |
| Other income (expense): |  |  |  |  |  |  |  |  |  |
| Share-based compensation |  | (25,825 | ) |  | (25,546 | ) |  | (25,198 | ) |
| Amortization of intangibles |  | (8,361 | ) |  | (17,771 | ) |  | (23,571 | ) |
| Interest income (expense), net |  | 1,225 |  |  | (397 | ) |  | 907 |  |
| Other income (expense), net |  | (2,752 | ) |  | 1,993 |  |  | (2,198 | ) |
| Income (loss) before income taxes |  | $ | 13,773 |  |  | $ | 77,582 |  |  | $ | (253,328 | ) |

[0001032975-15-000023:notes:283]
________________________________

[0001032975-15-000023:notes:284]
(1) Peripherals operating results include $4.8 million of restructuring credit, $8.0 million and $39.5 million of restructuring charges during fiscal year 2015, 2014 and 2013, respectively, and $2.2 million of impairment of other assets during fiscal year 2013. Video Conferencing operating results include $0.1 million of restructuring credit, $5.8 million and $4.2 million of restructuring charges for fiscal year 2015, 2014 and 2013, respectively, and $122.7 million of $214.5 million of impairment charges for goodwill and other assets for fiscal years 2015 and 2013, respectively.


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001032975-15-000023:notes:285]
VALUATION AND QUALIFYING ACCOUNTS

[0001032975-15-000023:notes:286]
For the Fiscal Years Ended March 31, 2015, 2014 and 2013 (in thousands)

[0001032975-15-000023:notes:287]
The Company's Schedule II includes valuation and qualifying accounts related to allowances for doubtful accounts, sales returns, cooperative marketing arrangements, customer incentive programs, and pricing programs, for direct customers and tax valuation allowances. The Company also has sales incentive programs for indirect customers with whom it does not have a direct sales and receivable relationship. These programs are recorded as accrued liabilities and are not considered valuation or qualifying accounts.

[0001032975-15-000023:notes:288]
|  |  | Balance atBeginning ofYear |  | Charged(Credited) toStatement ofOperations |  | Claims andAdjustmentsApplied AgainstAllowances |  | Balance atEnd ofYear |
| Allowance for doubtful accounts: |  |  |  |  |  |  |  |  |  |  |  |  |
| 2015 |  | $ | 1,712 |  |  | $ | (372 | ) |  | $ | (247 | ) |  | $ | 1,093 |  |
| 2014 |  | $ | 2,153 |  |  | $ | 656 |  |  | $ | (1,097 | ) |  | $ | 1,712 |  |
| 2013 |  | $ | 2,472 |  |  | $ | (107 | ) |  | $ | (212 | ) |  | $ | 2,153 |  |
| Allowance for sales returns: |  |  |  |  |  |  |  |  |  |  |  |  |
| 2015 |  | $ | 19,472 |  |  | $ | 66,481 |  |  | $ | (68,052 | ) |  | $ | 17,901 |  |
| 2014 |  | $ | 21,883 |  |  | $ | 59,483 |  |  | $ | (61,894 | ) |  | $ | 19,472 |  |
| 2013 |  | $ | 24,599 |  |  | $ | 61,315 |  |  | $ | (64,031 | ) |  | $ | 21,883 |  |
| Allowances for cooperative marketing arrangements: |  |  |  |  |  |  |  |  |  |  |  |  |
| 2015 |  | $ | 24,135 |  |  | $ | 116,469 |  |  | $ | (114,904 | ) |  | $ | 25,700 |  |
| 2014 |  | $ | 24,160 |  |  | $ | 102,751 |  |  | $ | (102,776 | ) |  | $ | 24,135 |  |
| 2013 |  | $ | 24,109 |  |  | $ | 96,278 |  |  | $ | (96,227 | ) |  | $ | 24,160 |  |
| Allowances for customer incentive programs: |  |  |  |  |  |  |  |  |  |  |  |  |
| 2015 |  | $ | 41,400 |  |  | $ | 144,507 |  |  | $ | (137,410 | ) |  | $ | 48,497 |  |
| 2014 |  | $ | 42,857 |  |  | $ | 106,810 |  |  | $ | (108,267 | ) |  | $ | 41,400 |  |
| 2013 |  | $ | 42,262 |  |  | $ | 94,313 |  |  | $ | (93,718 | ) |  | $ | 42,857 |  |
| Allowances for pricing programs: |  |  |  |  |  |  |  |  |  |  |  |  |
| 2015 |  | $ | 69,446 |  |  | $ | 249,893 |  |  | $ | (247,898 | ) |  | $ | 71,441 |  |
| 2014 |  | $ | 55,858 |  |  | $ | 221,702 |  |  | $ | (208,114 | ) |  | $ | 69,446 |  |
| 2013 |  | $ | 60,371 |  |  | $ | 182,916 |  |  | $ | (187,429 | ) |  | $ | 55,858 |  |
| Tax valuation allowances: |  |  |  |  |  |  |  |  |  |  |  |  |
| 2015 |  | $ | 4,872 |  |  | $ | 995 |  |  | $ | (277 | ) |  | $ | 5,590 |  |
| 2014 |  | $ | 6,014 |  |  | $ | 515 |  |  | $ | (1,657 | ) |  | $ | 4,872 |  |
| 2013 |  | $ | 2,205 |  |  | $ | 3,865 |  |  | $ | (56 | ) |  | $ | 6,014 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001032975-15-000023:notes:289]
Segment Information

[0001032975-15-000023:notes:290]
The Company has two reporting segments, peripherals and video conferencing, based on product markets and internal organizational structure. The peripherals segment encompasses the design, manufacturing and marketing of peripherals for PCs, tablets and other digital platforms. The video conferencing segment offers scalable high-definition, or HD, video communication endpoints, HD video conferencing systems with integrated monitors, video bridges, a Cloud-based video conferencing solution and other infrastructure software and hardware to support large-scale video deployments and services to support these products. The Company's reporting segments do not record revenue on sales between segments.

[0001032975-15-000023:notes:291]
Operating performance measures for the peripherals segment and the video conferencing segment are reported separately to Logitech's Chief Executive Officer ("CEO"), who is considered to be the Company's Chief Operating Decision Maker ("CODM"). The CEO periodically reviews information such as net sales and operating income (loss) for each operating segment to make business decisions. These operating performance measures do not include share-based compensation expense and amortization of intangible assets. Share-based compensation expense and amortization of intangible assets are presented in the following financial information by operating segment as "other income (expense)." Assets by operating segment are not presented since the Company does not present such data to the CODM.

[0001032975-15-000023:notes:292]
The United States represented 36%, 35% and 33% of net sales for the fiscal years 2015, 2014 and 2013, respectively. No other single country represented more than 10% of net sales during these periods. Revenues from net sales to customers in Switzerland, the Company's home domicile, represented 2% of net sales for each of fiscal years 2015, 2014 and 2013, respectively.

[0001032975-15-000023:notes:293]
Long-lived assets in the United States and China were $48.3 million and $34.0 million at March 31, 2015, respectively, and $44.9 million and $31.9 million at March 31, 2014, respectively. No other countries represented more than 10% of the Company's total consolidated long-lived assets at March 31, 2015 or 2014. Long-lived assets in Switzerland, the Company's home domicile, were $1.5 million and $1.6 million at March 31, 2015 and 2014, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001032975-15-000023:notes:294]
Shareholders' Equity

[0001032975-15-000023:notes:295]
Share Capital

[0001032975-15-000023:notes:296]
The Company's nominal share capital is CHF 43,276,655, consisting of 173,106,620 shares with a par value of CHF 0.25 each, all of which were issued and 8,624,821 of which were held in treasury shares as of March 31, 2015.

[0001032975-15-000023:notes:297]
In September 2008, the Company's shareholders approved an amendment to reserve conditional capital of 25,000,000 shares for potential issuance on the exercise of rights granted under the Company's employee equity incentive plans. The shareholders also approved the creation of conditional capital representing the issuance of up to 25,000,000 shares to cover any conversion rights under a future convertible bond issuance. This conditional capital was created in order to provide financing flexibility for future expansion, investments or acquisitions.

[0001032975-15-000023:notes:298]
Shares Outstanding

[0001032975-15-000023:notes:299]
In September 2012, the Company's shareholders approved the cancellation of the 18.5 million shares repurchased under the September 2008 amended share buyback program. These shares were legally cancelled during fiscal year 2013, which decreased the treasury shares outstanding by this amount and also decreased its shares issued and outstanding from 191.6 million to 173.1 million.

[0001032975-15-000023:notes:300]
Dividends

[0001032975-15-000023:notes:301]
Pursuant to Swiss corporate law, Logitech International S.A. may only pay dividends in Swiss Francs. The payment of dividends is limited to certain amounts of unappropriated retained earnings (CHF 444.9 million or $457.5 million based on the exchange rate at March 31, 2015) and is subject to shareholder approval. In March 2015, the Company announced a plan to pay $250.0 million in cumulative dividends for fiscal year 2015 through fiscal year 2017. The Board of Directors plans to request shareholder approval of the Swiss Franc equivalent of an $85 million dividend for fiscal year 2015 at the Company's next annual general meeting. Based on the exchange rate and the number of shares outstanding as of March 31, 2015, this represents approximately CHF 0.51 per share. In December 2014, Logitech's shareholders approved a cash dividend payment of CHF 43.1 million out of retained earnings to Logitech shareholders. Eligible shareholders were paid CHF 0.26 per share ($0.27 per share in U.S. Dollars), totaling $43.8 million in U.S. Dollars in December 2014. In September 2013, Logitech's shareholders approved a cash dividend payment of CHF 33.7 million out of retained earnings to Logitech's shareholders. Eligible shareholders were paid CHF 0.21 per share ($0.22 per share in U.S. Dollars), totaling $36.1 million in U.S. Dollars in September 2013. In September 2012, the Company's shareholders approved a cash dividend of CHF 125.7 million out of retained earnings to Logitech shareholders. Eligible shareholders were paid CHF 0.79 per share ($0.85 per share in U.S. Dollars), totaling $133.5 million in U.S. Dollars in September 2012. This dividend qualified as a distribution of qualifying additional paid-in capital and, as such, was not subject to Swiss Federal withholding tax.

[0001032975-15-000023:notes:302]
Legal Reserves

[0001032975-15-000023:notes:303]
Under Swiss corporate law, a minimum of 5% of the Company's annual net income must be retained in a legal reserve until this legal reserve equals 20% of the Company's issued and outstanding aggregate par value per share capital. These legal reserves represent an appropriation of retained earnings that are not available for distribution and totaled $9.9 million at March 31, 2015 (based on the exchange rate at March 31, 2015).

[0001032975-15-000023:notes:304]
Additionally, under Swiss corporate law, the Company is required to establish a reserve equal to the cost of repurchased treasury shares owned as of year end. The reserve for treasury shares, which is not available for distribution, totaled $77.4 million at March 31, 2015 (based on the exchange rate at March 31, 2015).

[0001032975-15-000023:notes:305]
Share Repurchases

[0001032975-15-000023:notes:306]
In March 2014, the Company's Board of Directors approved the 2014 share buyback program, which authorizes the Company to use up to $250.0 million to purchase its own shares. The Company's share buyback program is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Purchases may be started or stopped at any time without prior notice depending on market conditions and other factors.

[0001032975-15-000023:notes:307]
In September 2008, the Company's Board of Directors approved the September 2008 share buyback program for $250.0 million. In November 2011, an amendment to the September 2008 share buyback program ("September 2008—amended") was approved by the Company's Board of Directors to enable future purchases of shares for cancellation. In August 2013, the September 2008 share buyback and September 2008—amended share buyback programs expired.

[0001032975-15-000023:notes:308]
During fiscal years 2015 and 2013, 0.1 million and 8.6 million shares were repurchased for $1.7 million and $87.8 million, respectively. There were no share repurchases during fiscal year 2014. During fiscal year 2013, 18.5 million of the repurchased shares were cancelled.

[0001032975-15-000023:notes:309]
Accumulated Other Comprehensive Income (Loss)


## us-gaap:SubsequentEventsTextBlock

[0001032975-15-000023:notes:310]
Subsequent Events

[0001032975-15-000023:notes:311]
On April 22, 2015, the Company announced its intent to exit the OEM business and reorganize Lifesize to sharpen its focus on its Cloud-based offerings, and streamline its overall cost structure through product, overhead and infrastructure cost reductions, including a targeted resource realignment. The Company expects to recognize restructuring charges of approximately $15 million to $20 million.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001032975-15-000023:notes:312]
Balance Sheet Components
