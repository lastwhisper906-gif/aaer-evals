# LOGI MD&A — 0001032975-15-000023


## mdna

[0001032975-15-000023:mdna:1]
ITEM 7.    MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001032975-15-000023:mdna:2]
Overview of Our Company

[0001032975-15-000023:mdna:3]
Logitech is a world leader in products that connect people to the digital experiences they care about. Spanning multiple computing, communication and entertainment platforms, we develop and market innovative hardware and software products that enable or enhance digital navigation, music and video entertainment, gaming, social networking, audio and video communication over the Internet and home-entertainment control. We have two reporting segments: peripherals and video conferencing.

[0001032975-15-000023:mdna:4]
Our peripherals segment encompasses the design, manufacturing and marketing of peripherals for PCs, tablets and other digital platforms. Within our peripherals segment, we classify our retail product categories as growth, profit maximization, and non-strategic. Our growth product categories are: Mobile Speakers, Gaming, Video Collaboration and Tablet & Other Accessories. Our profit maximization categories are: Pointing Devices, Keyboards & Combos, Audio-PC & Wearables, PC Webcams, and Home Control.

[0001032975-15-000023:mdna:5]
Our brand, portfolio management, product development and engineering teams in our peripherals segment are responsible for product strategy, technological innovation, product design and development and to bring our products to market.

[0001032975-15-000023:mdna:6]
Our global marketing organization is responsible for developing and building the Logitech brand, consumer insights, public relations, social media and digital marketing. Our regional retail sales and marketing activities are organized into three geographic areas: Americas (North and South America), EMEA (Europe, Middle East and Africa) and Asia Pacific (including, among other countries, China, Taiwan, Japan and Australia).

[0001032975-15-000023:mdna:7]
We sell our peripherals products to a network of retailers, including direct sales to retailers and indirect sales through distributors. Our worldwide retail network includes wholesale distributors, consumer electronics retailers, mass merchandisers, specialty electronics, computers and telecommunications stores, value-added resellers and online merchants. Sales of our retail peripherals were 89%, 88% and 87% of our net sales for fiscal years 2015, 2014 and 2013, respectively. The large majority of our revenues have historically been derived from sales of our peripherals products for use by consumers. Our OEM customers include several of the world's largest PC manufacturers. Sales to OEM customers were 6% of our net sales for each of fiscal years 2015, 2014 and 2013.

[0001032975-15-000023:mdna:8]
Our video conferencing segment encompasses the a Cloud-based video conferencing solution, design, manufacturing and marketing of Lifesize branded video conferencing products, infrastructure and services for the enterprise, public sector and other small to medium business markets. Video conferencing products include scalable high-definition, or HD, video communication endpoints, HD video conferencing systems with integrated monitors, video bridges, and other infrastructure software and hardware to support large-scale video deployments and services to support these products. The video conferencing segment maintains a separate marketing and sales organization, which sells Lifesize products and services worldwide. Video conferencing product development and product management organizations are separate, but coordinated with our peripherals business, particularly our Consumer Computing Platform group. In April 2015, we announced our intent to reorganize Lifesize with the goal of de-emphasizing Lifesize’s legacy offerings more quickly to enable maximum traction with Lifesize Cloud. We plan to shrink our Lifesize business to grow the cloud opportunity faster. We sell our video conferencing products and services to distributors, value-added resellers, OEMs and, occasionally, direct enterprise customers. Net sales of video conferencing products and services were 5%, 6% and 7% of our net sales in the fiscal year 2015, 2014 and 2013, respectively. During fiscal years 2015 and 2013, we recorded goodwill impairment charges of $122.7 million and $214.5 million related to our video conferencing reporting segment, respectively.

[0001032975-15-000023:mdna:9]
We seek to fulfill the increasing demand for interfaces between people and the expanding digital world across multiple platforms and user environments. The interface evolves as platforms, user models and our target markets evolve. As access to digital information has expanded, we have extended our focus to mobile devices, the digital home, and the enterprise as access points to the Internet and the digital world. All of these platforms require interfaces that are customized according to how the devices are used. We believe that continued investment in product research and development is critical to creating the innovation required to strengthen our competitive

[0001032975-15-000023:mdna:10]
advantage and to drive future sales growth. We are committed to identifying and meeting current and future consumer trends with new and improved product technologies, partnering with others where our strengths are complementary, as well as leveraging the value of the Logitech and Lifesize brands from a competitive, channel partner and consumer experience perspective.

[0001032975-15-000023:mdna:11]
We believe that innovation, design and product quality are important to gaining market acceptance and maintaining market leadership.

[0001032975-15-000023:mdna:12]
We have been expanding the categories of products we sell and entering new markets, such as the markets for mobile speakers. As we do so, we are confronting new competitors, many of which have more experience in the categories or markets and have greater marketing resources and brand name recognition than we have. In addition, because of the continuing convergence of the markets for computing devices and consumer electronics, we expect greater competition in the future from well-established consumer electronics companies in our new categories as well as future ones we might enter. Many of these companies have greater financial, technical, sales, marketing and other resources than we have.

[0001032975-15-000023:mdna:13]
From time to time, we may seek to partner with, or acquire when appropriate, companies that have products, personnel, and technologies that complement our strategic direction. We continually review our product offerings and our strategic direction in light of our profitability targets, competitive conditions, changing consumer trends and the evolving nature of the interface between the consumer and the digital world. In April 2015, we announced our intent to exit the OEM business and to reorganize the Lifesize business to sharpen its focus on its Cloud-based offering.

[0001032975-15-000023:mdna:14]
Summary of Financial Results

[0001032975-15-000023:mdna:15]
Our total net sales for fiscal year 2015 decreased 1% in comparison to fiscal year 2014 due to decreases in video conferencing sales and OEM sales, partially offset by an increase in retail sales.

[0001032975-15-000023:mdna:16]
Retail sales and units sold during fiscal year 2015 increased 1% and 2%, respectively, compared to fiscal year 2014. Retail sales increased 8% and 2% in AMR and Asia Pacific, respectively, partially offset by a decrease of 7% in EMEA.

[0001032975-15-000023:mdna:17]
OEM sales and units sold during fiscal year 2015 decreased 17% and 25%, respectively, compared to fiscal year 2014.

[0001032975-15-000023:mdna:18]
Sales of Lifesize video conferencing products, which were 5% of total net sales during fiscal year 2015, decreased 10% during fiscal year 2015, compared to fiscal year 2014. Lifesize is in the early stages of transitioning its product portfolio to the recently announced Lifesize Cloud, a software-as-a-service (SaaS) offering. While sales of the Cloud offering are growing rapidly, they are not yet large enough to offset the combination of the short-term portfolio transition and soft market conditions for video conferencing infrastructure.

[0001032975-15-000023:mdna:19]
Our gross margin for fiscal year 2015 increased to 36.6%, compared to 34.2% for fiscal year 2014. The increase in gross margin primarily reflects the combination of a significant improvement in both our Profit Maximization categories and Mobile Speakers category, driven largely by product cost reductions and economies of scale, as well as the benefit from exiting the products included in the Non-Strategic category.

[0001032975-15-000023:mdna:20]
Operating expenses for fiscal year 2015 were 35.9% of net sales, compared to 30.6% for fiscal year 2014. The increase in total operating expenses as a percentage of net sales was primarily due to a goodwill impairment charge of $122.7 million relating to our video conferencing reporting unit, $23.7 million in expenses related to the Audit Committee's Independent investigation (as described in our Annual Report on Form 10-K for fiscal year 2014)and related expenses, partially offset by a restructuring credit of $4.9 million during fiscal year 2015 resulting from partial lease termination of our Silicon Valley campus, which was previously vacated and under a restructuring plan during fiscal year 2014, as opposed to a restructuring charge of $13.8 million during fiscal year 2014, as well as savings from prior year's restructuring actions and the ongoing rationalization of infrastructure.

[0001032975-15-000023:mdna:21]
Net income for fiscal year 2015 was $9.3 million, compared to net income of $74.3 million for fiscal year 2014. The decline was primarily due to a goodwill impairment charge of $122.7 million during fiscal year 2015 partially offset by improvements in gross margin as discussed above.

[0001032975-15-000023:mdna:22]
Given our global sales presence and the reporting of our financial results in U.S. Dollars, our financial results for fiscal year 2015 were affected by significant shifts in currency exchange rates during fiscal year 2015. See “Results of Operations” beginning on page 50 for information on the effect of currency exchange results on our net

[0001032975-15-000023:mdna:23]
sales. If the U.S. Dollar remains at its current strong levels in comparison to other currencies, this will affect our results of operations in future periods as well.

[0001032975-15-000023:mdna:24]
Trends in Our Business

[0001032975-15-000023:mdna:25]
Our sales of PC peripherals for use by consumers in Americas and Europe have historically made up the large majority of our revenues. In the last several years, the PC market has changed dramatically and there continues to be significant weakness in the global market for new PCs. This weakness had a negative impact on our net sales in all of our PC-related categories. We believe that this weakness reflects the growing popularity of tablets and smartphones as mobile computing devices.

[0001032975-15-000023:mdna:26]
We believe our future growth will be determined by our ability to rapidly create innovative products across multiple digital platforms - especially accessories for mobility-related products, including tablets and smartphones, gaming and digital music devices, to offset the decline in our PC peripherals. The following discussion represents key trends specific to each of our two operating segments: peripherals and video conferencing.

[0001032975-15-000023:mdna:27]
Trends Specific to our Peripherals Segment

[0001032975-15-000023:mdna:28]
Mobile Speakers:    The mobile speaker market grew throughout fiscal year 2015 based on consumer smartphones, consumption of music through tablets, and the growth of music services and Internet radio.  This market growth, together with our investments in the UE brand, our introduction of new products and our ability to gain market share during fiscal year 2015, has driven our growth in Mobile Speakers.

[0001032975-15-000023:mdna:29]
PC Peripherals (Pointing Devices, Keyboards & Combos, PC Webcams, Gaming and Audio PC & Wearables):    Although the installed base of PC users is large, consumer demand for new PCs has declined in recent years, and we believe it will continue to decline in future years. As a consequence, consumer demand for PC peripherals is slowing, or in some cases declining. As the quality of PC-embedded webcams improves along with the increasing popularity of tablets and smartphones with embedded webcams, we expect future sales of our PC-connected webcams will continue to be weak (or continue to decline on a year-over-year basis). The PC Gaming platform continues to show strong growth as online gaming and multi-platform experiences gain greater popularity and gaming content becomes increasingly more demanding. We believe Logitech is well positioned to benefit from the PC Gaming market growth.

[0001032975-15-000023:mdna:30]
Enterprise Market:    We are continuing our efforts to create and sell products and services to enterprises, including Video Collaboration products. For example, we have introduced the Logitech ConferenceCam CC3000e video collaboration product. Growing our enterprise peripherals business will continue to require investment in selected business-specific products, targeted product marketing, and sales channel development.

[0001032975-15-000023:mdna:31]
Tablets and Other Accessories:    Smaller mobile computing devices, such as tablets with touch interfaces, have created new markets and usage models for peripherals and accessories. We offer a number of products to enhance the use of mobile devices, including keyboard folios for the iPad and iPad mini, and keyboard covers and folios for the iPad Air. We have also introduced keyboard folios for the Samsung Galaxy tablet. While we achieved growth in sales of our tablet covers for the iPad, we have seen the market decline through fiscal year 2015 for the iPad platform, which has impacted the sales of our tablet peripherals.

[0001032975-15-000023:mdna:32]
OEM Business:    Sales of our OEM mice and keyboards have historically made up the bulk of our OEM sales. In recent years, there has been a dramatic shift away from desktop PCs and there continues to be weakness in the global market for PCs, which has adversely affected our sales of OEM mice and keyboards, all of which are sold with name-brand desktop PCs. We expect this trend to continue in the future, and we plan to exit the OEM business as we see limited opportunities for profitable growth.

[0001032975-15-000023:mdna:33]
Trends in Non-Strategic Peripherals Product Categories:    We continue to evaluate our product offerings and exit those which no longer support our strategic direction.

[0001032975-15-000023:mdna:34]
44

[0001032975-15-000023:mdna:35]
Trends Specific to our Video Conferencing Segment

[0001032975-15-000023:mdna:36]
The trend among businesses and institutions to use video conferencing offers a long-term growth opportunity for us. However, the overall video conferencing industry has experienced a slowdown in recent quarters. In addition, there has been an increase in the competitive environment. Lifesize is in the early stages of transitioning its product portfolio to Lifesize Cloud. While sales of this software-as-a-service offering are growing rapidly, they are not yet large enough to offset the combination of the short-term portfolio transition and soft market conditions for video conferencing infrastructure. Looking at this growth opportunity, recently in April 2015, we decided to reorganize Lifesize with the goal of de-emphasizing Lifesize’s legacy offerings more quickly to enable maximum traction with Lifesize Cloud. We plan to shrink our Lifesize business to grow the Cloud opportunity faster. This resulted in an estimated $122.7 million non-cash goodwill impairment charge in the quarter ended March 31, 2015.  We believe the growth in our video conferencing segment depends in part on our ability to increase sales of our new Cloud offering and smooth transition from our legacy infrastructure business.

[0001032975-15-000023:mdna:37]
Critical Accounting Estimates

[0001032975-15-000023:mdna:38]
The preparation of financial statements and related disclosures in conformity with U.S. GAAP (Generally Accepted Accounting Principles in the United States of America) requires us to make judgments, estimates and assumptions that affect reported amounts of assets, liabilities, net sales and expenses, and the disclosure of contingent assets and liabilities.

[0001032975-15-000023:mdna:39]
We consider an accounting estimate critical if it: (i) requires management to make judgments and estimates about matters that are inherently uncertain; and (ii) is important to an understanding of our financial condition and operating results.

[0001032975-15-000023:mdna:40]
We base our estimates on historical experience and on various other assumptions we believe to be reasonable under the circumstances. Although these estimates are based on management's best knowledge of current events and actions that may impact us in the future, actual results could differ from those estimates. Management has discussed the development, selection and disclosure of these critical accounting estimates with the Audit Committee of the Board of Directors.

[0001032975-15-000023:mdna:41]
We believe the following accounting estimates are most critical to our business operations and to an understanding of our financial condition and results of operations, and reflect the more significant judgments and estimates used in the preparation of our consolidated financial statements.

[0001032975-15-000023:mdna:42]
Accruals for Customer Programs

[0001032975-15-000023:mdna:43]
We record accruals for product returns, cooperative marketing arrangements, customer incentive programs and pricing programs. An allowance against accounts receivable is recorded for accruals and program activity related to our direct customers and indirect customers who receive payments for program activity through our direct customers. A liability is recorded for accruals and program activity related to our indirect customers who receive payments directly and do not have a right of offset against a receivable balance. The estimated cost of these programs is usually recorded as a reduction of revenue. If we receive a separately identifiable benefit from the customer and can reasonably estimate the fair value of that benefit, such cost is reflected in cost of sales or in operating expenses. Significant management judgment and estimates must be used to determine the cost of these programs in any accounting period.

[0001032975-15-000023:mdna:44]
Returns.    We grant limited rights to return products. Return rights vary by customer, and range from just the right to return defective product to stock rotation rights limited to a percentage of sales approved by management. Estimates of expected future product returns are recognized at the time of sale based on analyses of historical return trends by customer and by product, inventories owned by and located at distributors and retailers, current customer demand, current operating conditions, and other relevant customer and product information. Upon recognition, we reduce sales and cost of sales for the estimated return. Return trends are influenced by product life cycle status, new product introductions, market acceptance of products, sales levels, product sell-through, the type of customer, seasonality, product quality issues, competitive pressures, operational policies and procedures, and other factors. Return rates can fluctuate over time, but are sufficiently predictable to allow us to estimate expected future product returns.

[0001032975-15-000023:mdna:45]
Cooperative Marketing Arrangements.    We enter into customer marketing programs with many of our distribution and retail customers, and with certain indirect partners, allowing customers to receive a credit equal to a set percentage of their purchases of our products, or a fixed dollar credit for various marketing programs. The objective of these arrangements is to encourage advertising and promotional events to increase sales of our

[0001032975-15-000023:mdna:46]
products. Accruals for these marketing arrangements are recorded at the later of time of sale or time of commitment, based on negotiated terms, historical experience and inventory levels in the channel.

[0001032975-15-000023:mdna:47]
Customer Incentive Programs.    Customer incentive programs include performance-based incentives and consumer rebates. We offer performance-based incentives to our distribution customers, retail customers and indirect partners based on pre-determined performance criteria. Accruals for performance-based incentives are recognized as a reduction of the sale price at the time of sale. Estimates of required accruals are determined based on negotiated terms, consideration of historical experience, anticipated volume of future purchases, and inventory levels in the channel. Consumer rebates are offered from time to time at our discretion for the primary benefit of end-users. Accruals for the estimated costs of consumer rebates and similar incentives are recorded at the later of time of sale or when the incentive is offered, based on the specific terms and conditions. Certain incentive programs, including consumer rebates, require management to estimate the number of customers who will actually redeem the incentive based on historical experience and the specific terms and conditions of particular programs.

[0001032975-15-000023:mdna:48]
Pricing Programs.    We have agreements with certain customers that contain terms allowing price protection credits to be issued in the event of a subsequent price reduction. At our discretion, we also offer special pricing discounts to certain customers. Special pricing discounts are usually offered only for limited time periods or for sales of selected products to specific indirect partners. Our decision to make price reductions is influenced by product life cycle stage, market acceptance of products, the competitive environment, new product introductions and other factors. Accruals for estimated expected future pricing actions are recognized at the time of sale based on analysis of historical pricing actions by customer and by products, inventories owned by and located at distributors and retailers, current customer demand, current operating conditions, and other relevant customer and product information, such as stage of product life-cycle.

[0001032975-15-000023:mdna:49]
We regularly evaluate the adequacy of our accruals for product returns, cooperative marketing arrangements, customer incentive programs and pricing programs. Future market conditions and product transitions may require us to take action to increase such programs. In addition, when the variables used to estimate these costs change, or if actual costs differ significantly from the estimates, we would be required to record incremental increases or reductions to revenue or operating expenses. If, at any future time, we become unable to reasonably estimate these costs, recognition of revenue might be deferred until products are sold to users, which would adversely impact revenue in the period of transition.

[0001032975-15-000023:mdna:50]
Inventory Valuation

[0001032975-15-000023:mdna:51]
We must order components for our products and build inventory in advance of customer orders. Further, our industry is characterized by rapid technological change, short-term customer commitments and rapid changes in demand.

[0001032975-15-000023:mdna:52]
We record inventories at the lower of cost or market value and record write-downs of inventories that are obsolete or in excess of anticipated demand or market value. A review of inventory is performed each fiscal quarter that considers factors including the marketability and product life cycle stage, product development plans, component cost trends, demand forecasts and current sales levels. Inventory on hand which is not expected to be sold or utilized is considered excess, and we recognize the write-off in cost of sales at the time of such determination. The write-off is determined by comparison of the current replacement cost with the estimated selling price less any costs of completion and disposal (net realizable value) and the net realizable value less an allowance for normal profit. At the time of loss recognition, a new cost basis per unit, lower-cost basis for that inventory is established and subsequent changes in facts and circumstances would not result in an increase in the cost basis. If there were an abrupt and substantial decline in demand for Logitech's products or an unanticipated change in technological or customer requirements, we may be required to record additional write-downs that could adversely affect gross margins in the period when the write-downs are recorded.

[0001032975-15-000023:mdna:53]
Share-Based Compensation Expense

[0001032975-15-000023:mdna:54]
Share-based compensation expense includes compensation expense, reduced for estimated forfeitures. The grant date fair value for stock options and stock purchase rights is estimated using the Black-Scholes-Merton option-pricing valuation model. The grant date fair value of RSUs (restricted stock units) that vest upon meeting certain market conditions is estimated using the Monte-Carlo simulation method. The grant date fair value of time-based RSUs is calculated based on the closing market price on the date of grant, adjusted by estimated dividends yield prior to vesting.

[0001032975-15-000023:mdna:55]
Our estimates of share-based compensation expense require a number of complex and subjective assumptions including our stock price volatility, employee exercise patterns, future forfeitures, dividend yield, related tax effects and the selection of an appropriate fair value model. We estimate expected share price volatility based on historical volatility using daily prices over the term of past options, RSUs or purchase offerings, as we consider historical share price volatility as most representative of future volatility. We estimate expected life based on historical settlement rates, which we believe are most representative of future exercise and post-vesting termination behaviors. We use historical data to estimate pre-vesting forfeitures, and we record share-based compensation expense only for those awards that are expected to vest. The dividend yield assumption is based on our history and future expectations of dividend payouts.

[0001032975-15-000023:mdna:56]
The assumptions used in calculating the fair value of share-based compensation expense and related tax effects represent our best estimates, but these estimates involve inherent uncertainties and the application of management judgment. As a result, if factors change and we use different assumptions, or if we decide to use a different valuation model, our share-based compensation expense could be materially different in the future from what we have recorded in the current period, which could materially affect our results of operations.

[0001032975-15-000023:mdna:57]
Accounting for Income Taxes

[0001032975-15-000023:mdna:58]
We operate in multiple jurisdictions and our profits are taxed pursuant to the tax laws of these jurisdictions. Our effective income tax rate may be affected by the changes in or interpretations of tax laws and tax agreements in any given jurisdiction, utilization of net operating loss and tax credit carryforwards, changes in geographical mix of income and expense, and changes in our assessment of matters such as the ability to realize deferred tax assets. As a result of these considerations, we must estimate income taxes in each of the jurisdictions in which we operate. This process involves estimating current tax exposure together with assessing temporary differences resulting from different treatment of items for tax and accounting purposes. These differences result in deferred tax assets and liabilities, which are included in the consolidated balance sheet.

[0001032975-15-000023:mdna:59]
We assess the likelihood that our deferred tax assets will be recovered from future taxable income, considering all available evidence such as historical levels of income, expectations and risks associated with estimates of future taxable income and ongoing prudent and feasible tax strategies. When we determine that we are not able to realize all or part of our deferred tax assets, an adjustment is charged to earnings in the period when such determination is made. Likewise, if we later determine that it is more likely than not that the deferred tax assets would be realized, the previously provided valuation allowance would be reversed.

[0001032975-15-000023:mdna:60]
We make certain estimates and judgments about the application of tax laws, the expected resolution of uncertain tax positions and other matters surrounding the recognition and measurement of uncertain tax benefits. In the event that uncertain tax positions are resolved for amounts different than our estimates, or the related statutes of limitations expire without the assessment of additional income taxes, we will be required to adjust the amounts of the related assets and liabilities in the period in which such events occur. Such adjustments may have a material impact on our income tax provision and our results of operations.

[0001032975-15-000023:mdna:61]
Goodwill

[0001032975-15-000023:mdna:62]
We conduct a goodwill impairment analysis annually at December 31 or more frequently if indicators of impairment exist or if a decision is made to sell or exit a business. A significant amount of judgment is involved in determining if an indicator of impairment has occurred. Such indicators may include deterioration in general economic conditions, negative developments in equity and credit markets, adverse changes in the markets in which an entity operates, increases in input costs that have a negative effect on earnings and cash flows, or a trend of negative or declining cash flows or a decline in actual or planned revenue or earnings compared with actual and projected results of relevant prior periods, or other relevant entity-specific events such as changes in management, key personnel, strategy, or customers, contemplation of bankruptcy, or litigation. The fair value that could be realized in an actual transaction may differ from that used to evaluate the impairment of goodwill.

[0001032975-15-000023:mdna:63]
In reviewing goodwill for impairment, an entity has the option to first assess qualitative factors to determine whether the existence of events or circumstances leads to a determination that it is more likely than not (greater than 50%) that the estimated fair value of a reporting unit is less than its carrying amount. If an entity elects to perform a qualitative assessment and determines that an impairment is more likely than not, the entity is then required to perform the two-step quantitative impairment test; otherwise, no further analysis is required. An entity also may elect not to perform the qualitative assessment and, instead, proceed directly to the two-step quantitative impairment test. The ultimate outcome of the goodwill impairment review for a reporting unit should be the same whether an entity chooses to perform the qualitative assessment or proceeds directly to the two-step quantitative

[0001032975-15-000023:mdna:64]
impairment test. Goodwill is allocated among and evaluated for impairment at the reporting unit level, which is defined as an operating segment or one level below an operating segment. We have two reporting units, peripherals and video conferencing.

[0001032975-15-000023:mdna:65]
Peripherals

[0001032975-15-000023:mdna:66]
We performed our annual impairment analysis of the goodwill for our peripherals reporting unit at December 31, 2014 by performing a qualitative assessment and concluded that it was more likely than not that the fair value of our peripherals reporting unit exceeded its carrying amount. In assessing the qualitative factors, we considered the impact of these key factors: change in industry and competitive environment, growth in market capitalization of $2.3 billion as of December 31, 2014 from $2.2 billion a year ago, and budgeted-to-actual revenue performance from the prior year. The peripherals reporting unit has seen an improvement in operating income from $64.8 million and $117.8 million for the three and nine months ended December 31, 2013 to $76.1 million and $160.3 million for the three and nine months ended December 31, 2014, respectively.

[0001032975-15-000023:mdna:67]
Video Conferencing

[0001032975-15-000023:mdna:68]
We proceeded directly to the two-step quantitative impairment test for the video conferencing reporting unit and performed a Step 1 assessment at December 31, 2014. The Step 1 test involves measuring the recoverability of goodwill at the reporting unit level by comparing the reporting unit’s carrying amount, including goodwill, to the estimated fair value of the reporting unit. The fair value is estimated using an income approach employing a discounted cash flow (“DCF”) and a market-based model. The DCF model is based on projected cash flows from our approved most recent forecast (“assessment forecast”) developed in connection with the video conferencing reporting unit to perform the goodwill impairment assessment. The assessment forecast is based on a number of key assumptions, including, but not limited to, discount rate, compound annual growth rate (“CAGR”) during the forecast period, and terminal value. The terminal value is based on an exit price at the end of the assessment forecast using an earning multiple applied to the final year of the assessment forecast. The discount rate is applied to the projected cash flows to reflect the risks inherent in the timing and amount of the projected cash flows, including the terminal value, and is derived from the weighted average cost of capital of market participants in similar businesses. The market approach is based on applying certain revenue and earnings multiples of comparable companies relevant to each of its reporting units to the respective revenue and earnings metrics of our reporting units. The income approach and the market approach require the exercise of significant judgment, including assumptions about appropriate discount rates, long-term growth rates for purposes of determining a terminal value at the end of the discrete forecast period, economic expectations, timing of expected future cash flows, and expectations of returns on equity that will be achieved. Such assumptions are subject to change as a result of changing economic and competitive conditions. If the carrying amount of the reporting unit exceeds its fair value as determined by these assessments, goodwill is considered impaired and the Step 2 test is performed to measure the amount of impairment loss. The Step 2 test measures the impairment loss by allocating the reporting unit’s fair value to its assets, including unrecognized intangibles which are not carried on the books, and liabilities other than goodwill, and comparing the resulting implied fair value of goodwill with its carrying amount. The implied fair value of goodwill is the excess of the fair value of the reporting unit over the fair value amounts assigned to all of the assets and liabilities of that unit as if the reporting unit was acquired in a business combination and the fair value of the reporting unit represented the purchase price. If the carrying value of goodwill exceeds its implied fair value, an impairment loss equal to such excess would be recognized.

[0001032975-15-000023:mdna:69]
We use a third party valuation expert in the development of our market and income approach models. The annual Step 1 assessment performed as of December 31, 2014 resulted in us determining that the video conferencing reporting unit passed the Step 1 test because the estimated fair value of video conferencing reporting unit from the Step 1 assessment exceeded its carrying value by approximately 38.0%, thus not requiring a Step 2 assessment of this reporting unit. Therefore, we concluded it was more likely than not that the goodwill of the video conferencing reporting unit was not impaired as of December 31, 2014.

[0001032975-15-000023:mdna:70]
During the fourth quarter of the fiscal year ended March 31, 2015, the net sales of the video conferencing reporting unit decreased to $24.9 million from $31.0 million in the fourth quarter of the fiscal year ended March 31, 2014 and from $29.9 million in the third quarter of fiscal year ended March 31, 2015. The sales decline was concentrated in the video conferencing infrastructure legacy business primarily due to faster shift of customer preference towards Cloud infrastructure conferencing versus on-premise infrastructure solutions and resource realignment, which was not anticipated during annual impairment assessment as of December 31, 2014. This quick shift towards Cloud-based offering resulted in the change in business strategy to de-emphasize Lifesize’s legacy offerings more quickly than planned to enable maximum traction of the Lifesize Cloud, which would result in shrinking the legacy Lifesize business but could grow the Cloud opportunity faster. In the last nine months, the sales

[0001032975-15-000023:mdna:71]
of Cloud-based offerings have grown rapidly; however, they are not yet large enough to offset the combination of the short-term portfolio transition. As a result of the lower-than-expected performance in the legacy infrastructure sales, we made a strategic decision to sharpen our focus on our new Cloud-based offering. We plan to realign our costs and operations to this new strategy as part of a restructuring plan announced during April 2015 and are exploring various other options for our Lifesize business. The significant change in business strategy has adversely affected the near-term projections and we expect that it will shrink the Lifesize revenue for the next several years, including lowering the overall growth, pushing out the break-even point and increasing the operating loss as well as increasing uncertainty in the near term. In light of the aforementioned, we concluded it was appropriate to perform the Step 1 goodwill impairment assessment.

[0001032975-15-000023:mdna:72]
As of March 31, 2015, taking into consideration the video conferencing reporting unit’s updated business outlook for fiscal year 2016 based on the factors discussed above and the risk of execution of its refocused strategy, we updated the future cash flow assumptions for the video conferencing reporting unit and calculated updated estimates of fair value using the income approach. In particular, we lowered our December 31, 2014 goodwill impairment test projections of future revenue and operating income (loss) growth and adjusted other factors (such as working capital and capital expenditure). After updating the assumptions and projections, we then calculated a present value of the cash flow to arrive at an estimate of fair value under the income approach as of March 31, 2015. Key assumptions included in the income approach were significant reduction in the revenue assumption for fiscal year 2016 through fiscal year 2021 compared with the revenue assumption used in our annual goodwill impairment assessment as of December 31, 2014, CAGR at 7.2%, discount rate at 14.0%, and terminal growth rate at 4.0%. Consistent with the annual impairment test on December 31, 2014, we also updated the estimates of fair value determined under the market approach. Based on the income approach and market approach, the estimated fair value of the video conferencing reporting unit under the Step 1 assessment was lower than the carrying amount of the net asset including goodwill.

[0001032975-15-000023:mdna:73]
The video conferencing reporting unit failed the Step 1 test as prescribed under ASC 350, thus requiring a Step 2 assessment of this reporting unit to determine the goodwill impairment. In determining the impairment amount, the fair value of the video conferencing reporting unit was allocated to its assets and liabilities, including any unrecognized intangible assets not on the balance sheet, based on their respective fair values. Assumptions used in measuring the value of these assets and liabilities included the discount rates, working capital, and technology obsolescence rates used in valuing the intangible assets, and pricing of comparable transactions in the market in valuing the tangible assets. Based on this allocation, the implied value of intangible assets and tangible net assets fully absorbed the fair value of the business, leaving no implied fair value left to be allocated to the goodwill. The video conferencing reporting unit's carrying value of goodwill exceeded the implied fair value of goodwill, resulting in a goodwill impairment charge of $122.7 million, which is recorded in the Consolidated Statement of Operations.

[0001032975-15-000023:mdna:74]
The current assessment represents the fair value of the video conferencing business as of March 31, 2015. If we dispose all or any equity interest of the video conferencing reporting unit in the future, it may result in a gain. The gain will be recognized as a difference between the carrying amount of the video conferencing reporting unit and the proceeds, if any, received from such a disposal.

[0001032975-15-000023:mdna:75]
During fiscal year 2013, our video conferencing reporting unit failed the Step 1 test because the estimated fair value was less than its carrying value, thus requiring Step 2 assessment of this reporting unit. This impairment primarily resulted from a decrease in the expected CAGR during the assessment forecast period based on greater evidence of the overall enterprise video conferencing industry experiencing a slowdown, combined with lower demand related to new product launches, increased competition during fiscal year 2013, and other market data. These factors had an adverse effect on our video conferencing operating results and future outlook. During fiscal year 2013, we recorded goodwill impairment and other charges of $214.5 million related to our video conferencing reporting unit.

[0001032975-15-000023:mdna:76]
Determining the fair value of a reporting unit is judgmental in nature and requires the use of significant estimates and assumptions, including revenue growth rates, operating margins, discount rates and future market conditions, among others. If we are required to take further substantial impairment charges in future periods, our operating results would be materially and adversely affected in such period.

[0001032975-15-000023:mdna:77]
Product Warranty Accrual

[0001032975-15-000023:mdna:78]
We estimate the cost of product warranties at the time the related revenue is recognized based on historical and projected warranty claim rates, historical and projected costs, and knowledge of specific product failures that are outside of our typical experience. Each quarter, we reevaluate estimates to assess the adequacy of recorded warranty liabilities considering the size of the installed base of products subject to warranty protection and adjust the amounts as necessary. If actual product failure rates or repair costs differ from estimates, revisions to the estimated warranty liabilities would be required and could materially affect our results of operations.

[0001032975-15-000023:mdna:79]
Results of Operations

[0001032975-15-000023:mdna:80]
Non-GAAP Measures

[0001032975-15-000023:mdna:81]
We refer to our net sales excluding the impact of currency exchange rate fluctuations as "constant dollar" sales. Constant dollar sales is a non-GAAP financial measure, which is information derived from consolidated financial information but not presented in our financial statements prepared in accordance with U.S. GAAP. Our management uses these non-GAAP measures in its financial and operational decision-making, and believes these non-GAAP measures, when considered in conjunction with the corresponding GAAP measures, facilitate a better understanding of changes in net sales. Percentage of constant dollar sales growth is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales.

[0001032975-15-000023:mdna:82]
Net Sales

[0001032975-15-000023:mdna:83]
Net sales by channel for fiscal years 2015, 2014 and 2013 were as follows (in thousands):

[0001032975-15-000023:mdna:84]
|  |  | Years Ended March 31, |  | Change |
|  |  | 2015 |  | 2014 |  | 2013 |  | 2015 vs. 2014 |  | 2014 vs. 2013 |
| Retail |  | $ | 1,887,446 |  |  | $ | 1,866,279 |  |  | $ | 1,821,051 |  |  | 1 | % |  | 2 | % |
| OEM |  | 117,462 |  |  | 141,749 |  |  | 141,186 |  |  | (17 | ) |  | — |  |
| Video conferencing |  | 109,039 |  |  | 120,685 |  |  | 137,040 |  |  | (10 | ) |  | (12 | ) |
| Total net sales |  | $ | 2,113,947 |  |  | $ | 2,128,713 |  |  | $ | 2,099,277 |  |  | (1 | ) |  | 1 |  |

[0001032975-15-000023:mdna:85]
Retail:

[0001032975-15-000023:mdna:86]
During fiscal year 2015, retail sales increased 1% and units sold increased 2%, respectively, compared to fiscal year 2014. If currency exchange rates had been constant in 2015 and 2014, our constant dollar retail sales would have increased 4%. The increase in retail sales is primarily due to triple-digit growth in Mobile Speakers and Video Collaboration, and double-digit growth in Gaming, partially offset by declines in Audio-PC & Wearables, Tablet & Other Accessories, PC webcams and our Non-Strategic categories, compared to fiscal year 2014. Our retail average selling price decreased by 1% during fiscal year 2015 compared to fiscal year 2014.

[0001032975-15-000023:mdna:87]
During fiscal year 2014, retail sales increased 2% and units sold decreased 3%, compared to fiscal year 2013. Retail sales increased in Americas and Asia Pacific and decreased in EMEA during fiscal year 2014, compared to fiscal year 2013. The increase in retail sales is primarily due to triple-digit growth in Mobile Speakers, double-digit growth in Tablets & Other Accessories and Gaming, offset in part by a decline in Audio-PC & Wearables, Video, and our Non-Strategic categories, compared to fiscal year 2013.

[0001032975-15-000023:mdna:88]
OEM:

[0001032975-15-000023:mdna:89]
During fiscal year 2015, OEM sales and units sold decreased 17% and 25%, respectively, compared to fiscal year 2014. If currency exchange rates had been constant in 2015 and 2014, our constant dollar OEM net sales would have decreased 17%. The decline was primarily due to the continued weakness in global PCs market and loss of volume shares from certain PC manufactures. Given our heightened focus on our growing Retail Strategic business, we plan to exit the OEM business.

[0001032975-15-000023:mdna:90]
During fiscal year 2014, OEM sales and units sold remained flat, compared to fiscal year 2013.

[0001032975-15-000023:mdna:91]
50

[0001032975-15-000023:mdna:92]
Video conferencing:

[0001032975-15-000023:mdna:93]
During fiscal year 2015, video conferencing net sales decreased 10%, compared to fiscal year 2014. If currency exchange rates had been constant in 2015 and 2014, our constant dollar video conferencing net sales would have decreased 10%. Lifesize is in the process of transitioning its product portfolio to the recently announced Lifesize Cloud, a software-as-a-service (SaaS) offering that provides an affordable, simple and scalable video conferencing solution with little to no need for IT involvement. While sales of the Cloud offering are growing rapidly, they are not yet large enough to offset the combination of the short-term portfolio transition and soft market conditions for video conferencing infrastructure. To align our refocus on Lifesize Cloud offering and transition from Lifesize legacy business, we announced a restructuring plan subsequently in April 2015.

[0001032975-15-000023:mdna:94]
During fiscal year 2014, video conferencing net sales decreased 12%, compared to fiscal year 2013. The decrease primarily resulted from the combination of a changing industry landscape caused by a shift to less expensive, Cloud-based video conferencing solutions, an evolving Lifesize product line and challenges in execution.

[0001032975-15-000023:mdna:95]
Sales Denominated in Other Currencies

[0001032975-15-000023:mdna:96]
Although our financial results are reported in U.S. Dollars, a portion of our sales were generated in currencies other than the U.S. Dollar, such as the Euro, Chinese Renminbi, Japanese Yen, Canadian Dollar, Taiwan Dollar, British Pound and Australian Dollar. During fiscal years 2015, 2014 and 2013, 44%, 45% and 45% of our net sales were denominated in currencies other than the U.S. Dollar, respectively.

[0001032975-15-000023:mdna:97]
Retail Sales by Region

[0001032975-15-000023:mdna:98]
The following table presents the change in retail sales by region for the fiscal year 2015 compared with fiscal year 2014 and fiscal year 2014 compared with fiscal year 2013:

[0001032975-15-000023:mdna:99]
|  |  | 2015 vs. 2014 |  | 2014 vs. 2013 |
| Americas |  | 8 | % |  | 9 | % |
| EMEA |  | (7 | ) |  | (4 | ) |
| Asia Pacific |  | 2 |  |  | 2 |  |

[0001032975-15-000023:mdna:100]
Americas

[0001032975-15-000023:mdna:101]
During fiscal year 2015, retail sales in Americas increased 8%, compared to fiscal year 2014. If currency exchange rates had been constant in 2015 and 2014, our constant dollar retail sales would have increased 9% in the Americas. We achieved sales increases in all strategic categories except Audio-PC & Wearables, PC webcams, and Tablets & Other Accessories. This increase was led by triple digit growth in Mobile Speakers mainly from UE BOOM and our recently launched UE MEGABOOM, and triple digit growth in Video Collaboration mainly from our ConferenceCam CC3000e and Webcam C930e.

[0001032975-15-000023:mdna:102]
During fiscal year 2014, retail sales in Americas increased 9%, compared to fiscal year 2013. Retail sales increased in Mobile Speakers, Gaming, Tablet & Other Accessories, Keyboards & Combos and Pointing Devices, partially offset by decreases in Non-Strategic, Audio-PC & Wearables, Home Control, and PC Webcams. The increase in Tablet & Other Accessories was led by sales of our Ultrathin Keyboard Cover for the iPad and from our recently introduced Keyboard Folio suite of products designed for the iPad, iPad mini and iPad Air. The increase in Mobile Speakers was primarily from the UE BOOM. The increase in Gaming was due to the recent launch of our new gaming products. The increase in Keyboards & Combos was driven by low-end, mid-range and high-end products. Retail sales improved in the United States and Canada during fiscal year 2014, compared to fiscal year 2013.

[0001032975-15-000023:mdna:103]
EMEA

[0001032975-15-000023:mdna:104]
During fiscal year 2015, retail sales in EMEA decreased 7%, compared to fiscal year 2014. If currency exchange rates had been constant in 2015 and 2014, our constant dollar retail sales would have decreased 3% in the EMEA region. Retail sales decreased across all strategic categories except Gaming, Mobile Speakers, Video Collaboration, Home Control and Keyboards and Combos product categories. The decline in sales was heavily impacted by market weakness in Russia and Ukraine. We achieved a triple digit growth in Video Collaboration, and a double digit growth in both Mobile Speakers and Gaming during fiscal year 2015 compared to fiscal year 2014.

[0001032975-15-000023:mdna:105]
During fiscal year 2014, retail sales in EMEA decreased 4%, compared to fiscal year 2013. Retail sales decreased in Pointing Devices, PC Webcams, Audio-PC & Wearables, and Non-Strategic, partially offset by increases in Mobile Speakers, Gaming, Tablet & Other Accessories and Home Control. We experienced a significant decrease in Germany due to sales challenges which we overcame in the second half of fiscal year 2014. The decrease in Germany was partially offset by an increase in the United Kingdom.

[0001032975-15-000023:mdna:106]
Asia Pacific

[0001032975-15-000023:mdna:107]
During fiscal year 2015, retail sales in Asia Pacific increased 2%, compared to fiscal year 2014. If currency exchange rates had been constant in 2015 and 2014, our constant dollar retail sales would have increased 4% in the Asia Pacific region. We achieved triple digit growths in both Mobile Speakers and Video Collaboration, partially offset by the decline in Tablets & Other Accessories, Audio - PC Wearables, and Non-Strategic.

[0001032975-15-000023:mdna:108]
During fiscal year 2014, retail sales in Asia Pacific increased 2%, compared to fiscal year 2013. Retail sales increased in Mobile Speakers, Gaming, Tablet & Other Accessories and Remotes, partially offset by decreases in Non-Strategic, Audio- PC & Wearables, Video, and Pointing Devices and PC keyboards & Desktops. In addition, retail sell-through in Asia Pacific increased 2% during fiscal year 2014, compared to fiscal year 2013.

[0001032975-15-000023:mdna:109]
Net Sales by Product Categories and Sales Channels

[0001032975-15-000023:mdna:110]
Net sales by product categories and sales channels for fiscal years 2015, 2014 and 2013 were as follows (in thousands):

[0001032975-15-000023:mdna:111]
|  |  | Years Ended March 31, |  | Change |
|  |  | 2015 |  | 2014 |  | 2013 |  | 2015 vs. 2014 |  | 2014 vs. 2013 |
| Peripherals: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Mobile Speakers |  | $ | 178,038 |  |  | $ | 87,414 |  |  | $ | 33,408 |  |  | 104 | % |  | 162 | % |
| Gaming |  | 211,911 |  |  | 186,926 |  |  | 144,512 |  |  | 13 |  |  | 29 |  |
| Video Collaboration |  | 62,215 |  |  | 29,058 |  |  | 18,700 |  |  | 114 |  |  | 55 |  |
| Tablet & Other Accessories |  | 140,994 |  |  | 172,484 |  |  | 119,856 |  |  | (18 | ) |  | 44 |  |
| Growth |  | 593,158 |  |  | 475,882 |  |  | 316,476 |  |  | 25 |  |  | 50 |  |
| Pointing Devices |  | 487,210 |  |  | 506,884 |  |  | 521,083 |  |  | (4 | ) |  | (3 | ) |
| Keyboards & Combos |  | 426,117 |  |  | 415,314 |  |  | 399,144 |  |  | 3 |  |  | 4 |  |
| Audio-PC & Wearables |  | 213,496 |  |  | 250,037 |  |  | 289,313 |  |  | (15 | ) |  | (14 | ) |
| PC Webcams |  | 96,680 |  |  | 113,791 |  |  | 137,292 |  |  | (15 | ) |  | (17 | ) |
| Home Control |  | 68,060 |  |  | 67,371 |  |  | 71,641 |  |  | 1 |  |  | (6 | ) |
| Profit Maximization |  | 1,291,563 |  |  | 1,353,397 |  |  | 1,418,473 |  |  | (5 | ) |  | (5 | ) |
| Retail Strategic Sales (1) |  | 1,884,721 |  |  | 1,829,279 |  |  | 1,734,949 |  |  | 3 |  |  | 5 |  |
| Non-Strategic |  | 2,725 |  |  | 37,000 |  |  | 86,102 |  |  | (93 | ) |  | (57 | ) |
| OEM |  | 117,462 |  |  | 141,749 |  |  | 141,186 |  |  | (17 | ) |  | — |  |
|  |  | 2,004,908 |  |  | 2,008,028 |  |  | 1,962,237 |  |  | — |  |  | 2 |  |
| Video Conferencing |  | 109,039 |  |  | 120,685 |  |  | 137,040 |  |  | (10 | ) |  | (12 | ) |
|  |  | $ | 2,113,947 |  |  | $ | 2,128,713 |  |  | $ | 2,099,277 |  |  | (1 | ) |  | 1 |  |

[0001032975-15-000023:mdna:112]
__________________________________________

[0001032975-15-000023:mdna:113]
(1) Certain products within the retail product families presented in prior years have been reclassified to conform to the current year presentation. There's no impact over total net retail sales.

[0001032975-15-000023:mdna:114]
Retail Strategic Sales

[0001032975-15-000023:mdna:115]
During fiscal year 2015, retail strategic sales increased 3% compared to fiscal year 2014. If currency exchange rates had been constant in 2015 and 2014, our constant dollar retail strategic sales would have increased 6%.

[0001032975-15-000023:mdna:116]
During fiscal year 2014, retail strategic sales increased 5% compared to fiscal year 2013.

[0001032975-15-000023:mdna:117]
Retail Strategic - Growth Categories:

[0001032975-15-000023:mdna:118]
Mobile Speakers

[0001032975-15-000023:mdna:119]
Our retail Mobile Speakers category products are portable Bluetooth wireless speakers.

[0001032975-15-000023:mdna:120]
During fiscal year 2015, retail sales of Mobile Speakers increased 104% and units sold increased 99%, compared to fiscal year 2014. The sales increased significantly across our all three regions, with a triple digit growth in both Americas and Asia Pacific regions, are primarily due to strong demand for the UE BOOM, which is our top revenue generating wireless speaker and experienced a triple digit growth in fiscal year 2015, compared to fiscal year 2014. The successful launch of UE MEGABOOM during the fourth quarter of fiscal year 2015 contributed 6% of total Mobile Speakers sales for fiscal year 2015.

[0001032975-15-000023:mdna:121]
During fiscal year 2014, retail sales of Mobile Speakers increased 162% and units sold increased 88%, compared to fiscal year 2013. The 162% increase in our wireless speakers for smartphones and tablets was driven by a strong demand primarily for the UE BOOM. Our top revenue-generating wireless speaker products during fiscal year 2014 included the UE BOOM and the UE Mini BOOM.

[0001032975-15-000023:mdna:122]
Gaming

[0001032975-15-000023:mdna:123]
Our retail Gaming category comprises gaming mice, keyboards, headsets, gamepads and steering wheels.

[0001032975-15-000023:mdna:124]
During fiscal year 2015, retail sales of Gaming increased 13% and units sold increased 21%, compared to fiscal year 2014. This growth was primarily from gaming headsets and gaming mice due to the launch of our new gaming products, including mice, keyboards and headsets. New products made up 12% of total Gaming revenue for fiscal year 2015. Our top revenue-generating Gaming products included the Logitech G502 Proteus Core, the Logitech G27 Racing Wheel, the Logitech G930 Wireless Gaming Headset, and the G430 Cordless Mice.

[0001032975-15-000023:mdna:125]
During fiscal year 2014, retail sales of Gaming increased 29% and units sold increased 24%, compared to fiscal year 2013. This growth was primarily due to the recent launch of our new gaming products, including mice, keyboards and headsets. New products made up 23% of total Gaming revenue for fiscal year 2014. Our top revenue-generating Gaming products included the Logitech G27 Racing Wheel, the Logitech G930 Wireless Gaming Headset, the G500s Laser Gaming Mouse, the G700s Rechargeable Gaming Mouse, and the G710+ Mechanical Gaming Keyboard.

[0001032975-15-000023:mdna:126]
Video Collaboration

[0001032975-15-000023:mdna:127]
Our retail Video Collaboration category primarily includes video products and certain headset products that can connect small and medium sized user groups.

[0001032975-15-000023:mdna:128]
During fiscal year 2015, retail sales of Video Collaboration increased 114% and units sold increased 49%, compared to fiscal year 2014. The sales increased significantly across all products in this category was primarily driven by the success of the Logitech ConferenceCam CC3000e and Logitech ConferenceCam C930e.

[0001032975-15-000023:mdna:129]
During fiscal year 2014, retail sales of Video Collaboration increased 55% and units sold increased 33%, compared to fiscal year 2013. The significant increase in sales across all products in this category was primarily driven by the success of the Logitech Webcam C930e.

[0001032975-15-000023:mdna:130]
Tablet & Other Accessories

[0001032975-15-000023:mdna:131]
Our retail Tablet & Other Accessories category comprises keyboards and covers for tablets and smartphones as well as other accessories for mobile devices.

[0001032975-15-000023:mdna:132]
During fiscal year 2015, retail sales of Tablet & Other Accessories decreased 18% and units sold decreased 5%, compared to fiscal year 2014. The reduction in sales, primarily from tablet keyboards, reflects the combination of a declining demand for iPad tablet platform and increased competition, partially offset by sales growth with our tablet covers for the iPad.

[0001032975-15-000023:mdna:133]
During fiscal year 2014, retail sales of Tablet & Other Accessories increased 44% and units sold increased 87%, compared to fiscal year 2013. The increase was driven by demand for the Logitech Ultrathin Keyboard Cover for the iPad, as well as strong sales from recently introduced products such as the Logitech Ultrathin Keyboard Cover for the iPad Mini and from the Logitech Keyboard Folio suite of products designed for the iPad, iPad mini, and iPad Air. The faster growth in unit shipments reflected the broadening of our portfolio to address a larger portion of the tablet accessory market, including tablet cases.

[0001032975-15-000023:mdna:134]
Retail Strategic - Profit Maximization Categories:

[0001032975-15-000023:mdna:135]
Pointing Devices

[0001032975-15-000023:mdna:136]
Our retail Pointing Devices category comprises PC and Mac-related mice, touchpads and presenters.

[0001032975-15-000023:mdna:137]
During fiscal year 2015, retail sales of Pointing Devices decreased 4% and units sold increased 2%, compared to fiscal year 2014. The decrease in retail sales was primarily due to the continued weakness in the global PC market. The decrease was primarily from our high-end product offerings, which decreased 12%, followed by our low-end product offerings which decreased 5%, partially offset by our mid-range product offerings which increased 1%. Retail sales of corded mice decreased 4% and units sold remained flat. Retail sales of cordless mice decreased 5% and units sold increased 2%.

[0001032975-15-000023:mdna:138]
During fiscal year 2014, retail sales of Pointing Devices decreased 3% and units sold decreased 1%, compared to fiscal year 2013. The decrease in retail sales was primarily due to the continued weakness in the global PC market. The decrease was primarily from our high-end product offerings, which decreased 14%, followed by our mid-range product offerings, which decreased 6%, and our low-end product offerings increased by 1%. Retail sales of corded mice decreased 9% and units sold decreased 10%. Retail sales of cordless mice decreased 1% and units sold increased 4%.

[0001032975-15-000023:mdna:139]
Keyboards & Combos

[0001032975-15-000023:mdna:140]
Our retail Keyboards & Combos category comprises PC keyboards and keyboard/mice combo products.

[0001032975-15-000023:mdna:141]
During fiscal year 2015, retail sales of Keyboards & Combos increased 3% and units sold increased 7%, compared to fiscal year 2014. The sales increase was primarily due to sales increase in our corded and cordless combos. Retail sales of corded and cordless combos increased 19% and 6%, respectively, and units sold increased 25% and 10%, respectively. Our best selling products in this category were the Logitech Wireless Combo MK270 and Wireless Combo MK520, which feature powerful and reliable wireless connections and plug-and-play simplicity. Retail sales of corded and cordless keyboards decreased 9% and 7%, respectively, and units sold decreased 4% and 3%, respectively.

[0001032975-15-000023:mdna:142]
During fiscal year 2014, retail sales of Keyboards & Combos increased 4% and units sold decreased 1%, compared to fiscal year 2013. The sales increase was primarily due to sales increase in our corded and cordless combo. Our best selling product in this category was the Wireless Touch Keyboard K400, which features an integrated touchpad and has been popular for use in the living room. Retail sales of corded and cordless keyboards decreased 17% and 5%, respectively, and units sold decreased 21% and 6%, respectively. Retail sales of corded and cordless combos increased 3% and 7%, respectively, and units sold decreased 1% and increased 10%, respectively.

[0001032975-15-000023:mdna:143]
Audio-PC & Wearables

[0001032975-15-000023:mdna:144]
Our retail Audio-PC & Wearables category comprises PC speakers, PC headsets and in-ear headphones.

[0001032975-15-000023:mdna:145]
During fiscal year 2015, retail sales of Audio-PC decreased 15% and units sold decreased 10%, compared to fiscal year 2014. The decrease was primarily due to decreases in PC speaker retail sales, reflecting a category that appears to be in structural decline as music consumption continues to migrate to mobile platforms, which benefits our mobile speaker product category. Retail sales of our headset products decreased 4% and units decreased 6%. Retail sales of our Wearables products declined 35%.

[0001032975-15-000023:mdna:146]
During fiscal year 2014, retail sales of Audio-PC decreased 14% and units sold decreased 17%, compared to fiscal year 2013. The decrease was primarily due to decreases in PC speaker retail sales of 10% and units sold of 11%. These decreases reflect both a weakness in the overall market for new PCs and a market shift toward mobile audio devices. Retail sales of our Wearables products declined 39%, as we phased out the headphone category.

[0001032975-15-000023:mdna:147]
PC Webcams

[0001032975-15-000023:mdna:148]
Our PC Webcams category comprises PC-based webcams targeted primarily at consumers.

[0001032975-15-000023:mdna:149]
During fiscal year 2015, retail sales of PC Webcams decreased 15% and units sold decreased 18%, compared to fiscal year 2014. The weak sales reflect the ongoing structural decline of the consumer webcam market, which continues to contract.

[0001032975-15-000023:mdna:150]
During fiscal year 2014, retail sales of PC Webcams decreased 17% and units sold decreased 28%, compared to fiscal year 2013. The decrease was due to weakness in our consumer webcam product line, which continued to be negatively impacted by the combination of market trends, including the popularity of embedded webcams in mobile devices, and the overall weakness of the PC market.

[0001032975-15-000023:mdna:151]
Home Control

[0001032975-15-000023:mdna:152]
Our retail Home Control category comprises our Harmony remotes and recently-launched, new Harmony Home Control.

[0001032975-15-000023:mdna:153]
During fiscal year 2015, retail sales of Remotes increased 1% and units sold increased 22%, compared to fiscal year 2014. The increase in Home Control was primarily concentrated in our mid-range and low-end products, partially offset by decreases in our high-end products. New products contributed to 17% of total retail sales of Home Control for fiscal year 2015.

[0001032975-15-000023:mdna:154]
During fiscal year 2014, retail sales of Home Control decreased 6% and units sold decreased 23%, compared to fiscal year 2013. The decrease in Home Control was primarily concentrated in our high-end and low-end products, partially offset by increases in our mid-range product lines.

[0001032975-15-000023:mdna:155]
Non-Strategic

[0001032975-15-000023:mdna:156]
This category comprises a variety of products that we currently intend to transition out of, or have already transitioned out of, because they are no longer strategic to our business. Products currently included in this category include TV camera, Digital Video Security, TV and home speakers, Google TV products, Keyboard/Desktop accessories, and music docks.

[0001032975-15-000023:mdna:157]
During fiscal year 2015, retail sales of this category decreased 93%, compared to fiscal year 2014. During fiscal year 2014, retail sales of this category decreased 57%, compared to fiscal year 2013.

[0001032975-15-000023:mdna:158]
OEM

[0001032975-15-000023:mdna:159]
During fiscal year 2015, OEM sales and units sold decreased 17% and 25%, respectively, compared to fiscal year 2014. This decrease was primarily due to weak mice sales which was expected as we elected not to participate in lower margin opportunities with several customers. We plan to exit the OEM business as we see limited opportunities for profitable growth.

[0001032975-15-000023:mdna:160]
During fiscal year 2014, OEM sales and units sold remained flat compared to fiscal year 2013.

[0001032975-15-000023:mdna:161]
Video Conferencing

[0001032975-15-000023:mdna:162]
During fiscal year 2015, video conferencing sales decreased 10% compared to fiscal year 2014. If currency exchange rates had been constant in 2015 and 2014, our constant dollar video conferencing net sales would have decreased 10%. Lifesize is in the process of transitioning its product portfolio to the recently announced Lifesize Cloud, a software-as-a-service (SaaS) offering that provides an affordable, simple and scalable video conferencing solution with little to no need for IT involvement. While sales of the Cloud offering are growing rapidly, they are not yet large enough to offset the combination of the short-term portfolio transition and soft market conditions for video conferencing infrastructure. We recently decided to reorganize Lifesize with the goal of de-emphasizing Lifesize’s legacy offerings more quickly to enable maximum traction with Lifesize Cloud. We plan to shrink our Lifesize business to grow the Cloud opportunity faster.

[0001032975-15-000023:mdna:163]
During fiscal year 2014, video conferencing sales decreased 12% compared to fiscal year 2013. The decrease was primarily due to a combination of a changing industry landscape caused by a shift to less expensive, Cloud-based video conferencing solutions, an evolving Lifesize product line and challenges in execution experienced in all geographic regions.

[0001032975-15-000023:mdna:164]
55

[0001032975-15-000023:mdna:165]
Gross Profit

[0001032975-15-000023:mdna:166]
Gross profit for fiscal years 2015, 2014 and 2013 was as follows (in thousands):

[0001032975-15-000023:mdna:167]
|  |  | Years Ended March 31, |  | Change |
|  |  | 2015 |  | 2014 |  | 2013 |  | 2015 vs. 2014 |  | 2014 vs. 2013 |
| Net sales |  | $ | 2,113,947 |  |  | $ | 2,128,713 |  |  | $ | 2,099,277 |  |  | (1 | )% |  | 1 | % |
| Cost of goods sold |  | 1,339,750 |  |  | 1,400,844 |  |  | 1,389,643 |  |  | (4 | ) |  | 1 |  |
| Gross profit |  | $ | 774,197 |  |  | $ | 727,869 |  |  | $ | 709,634 |  |  | 6 |  |  | 3 |  |
| Gross margin |  | 36.6 | % |  | 34.2 | % |  | 33.8 | % |  |  |  |  |  |  |

[0001032975-15-000023:mdna:168]
Gross profit consists of net sales, less cost of goods sold, which includes materials, direct labor and related overhead costs, costs of manufacturing facilities, costs of purchasing components from outside suppliers, distribution costs, shipping and handling cost, outside processing costs, write-down of inventories and amortization of intangible assets.

[0001032975-15-000023:mdna:169]
The increase in gross margin during fiscal year 2015, compared to fiscal year 2014, primarily resulted from a 0.5% improvement attributable to cost reduction initiatives across the Pointing Devices, Keyboards & Combos and Mobile Speakers product categories, a 0.5% improvement attributable to exiting non-strategic product categories, a 0.7% improvement attributable to the combination of a $5.8 million reduction in amortization of other intangible assets and a $5.2 million prior year discontinued products write off, and a 0.5% improvement attributable to lower inventory reserves in fiscal year 2015 that was partially offset by a higher percentage of air shipments in fiscal 2015.

[0001032975-15-000023:mdna:170]
The increase in gross margin during fiscal year 2014, compared to fiscal year 2013, was primarily due to cost improvements across all PC-related categories, actions we took since fiscal year 2013 to streamline our product portfolio, inventory reserves of several discontinued Music category products and the discontinuation of projects in 2013 due to restructuring.

[0001032975-15-000023:mdna:171]
Operating Expenses

[0001032975-15-000023:mdna:172]
Operating expenses for fiscal years 2015, 2014 and 2013 were as follows (in thousands):

[0001032975-15-000023:mdna:173]
|  |  | Years Ended March 31, |  | Change |
|  |  | 2015 |  | 2014 |  | 2013 |  | 2015 vs. 2014 |  | 2014 vs. 2013 |
| Marketing and selling |  | $ | 378,593 |  |  | $ | 379,747 |  |  | $ | 431,886 |  |  | — | % |  | (12 | )% |
| % of net sales |  | 17.9 | % |  | 17.8 | % |  | 20.6 | % |  |  |  |  |  |  |
| Research and development |  | 131,012 |  |  | 139,385 |  |  | 155,012 |  |  | (6 | ) |  | (10 | ) |
| % of net sales |  | 6.2 | % |  | 6.5 | % |  | 7.4 | % |  |  |  |  |  |  |
| General and administrative |  | 131,446 |  |  | 118,940 |  |  | 114,381 |  |  | 11 |  |  | 4 |  |
| % of net sales |  | 6.2 | % |  | 5.6 | % |  | 5.4 | % |  |  |  |  |  |  |
| Impairment of goodwill and other assets |  | 122,734 |  |  | — |  |  | 216,688 |  |  | NM |  |  | (100 | ) |
| % of net sales |  | 5.8 | % |  | — | % |  | 10.3 | % |  |  |  |  |  |  |
| Restructuring charges (Credits), net |  | (4,888 | ) |  | 13,811 |  |  | 43,704 |  |  | (135 | ) |  | (68 | ) |
| % of net sales |  | (0.2 | )% |  | 0.6 | % |  | 2.1 | % |  |  |  |  |  |  |
| Total operating expenses |  | $ | 758,897 |  |  | $ | 651,883 |  |  | $ | 961,671 |  |  | 16 |  |  | (32 | ) |
| % of net sales |  | 35.9 | % |  | 30.6 | % |  | 45.8 | % |  |  |  |  |  |  |

[0001032975-15-000023:mdna:174]
__________________________________________

[0001032975-15-000023:mdna:175]
NM—Not Meaningful.

[0001032975-15-000023:mdna:176]
The increase in total operating expenses during fiscal year 2015, compared to fiscal year 2014, was primarily due to a goodwill impairment charge of $122.7 million relating to our video conferencing reporting unit and $23.7 million in expense related to the Audit Committee's Independent investigation during fiscal 2015, partially offset by a restructuring credit of $4.9 million during fiscal year 2015 resulting from partial lease termination of our Silicon Valley campus, which was previously vacated and under a restructuring plan during fiscal year 2014, as opposed to a restructuring charge of $13.8 million during fiscal year 2014.

[0001032975-15-000023:mdna:177]
The decrease in total operating expenses during fiscal year 2014, compared to fiscal year 2013, was primarily due to the $216.7 million impairment of goodwill and other assets recorded in fiscal year 2013, combined with the restructuring plans initiated in fiscal year 2013, which reduced personnel-related expenses in fiscal year 2014 as well as resulted in a $30.0 million decrease in restructuring expenses in fiscal 2013.

[0001032975-15-000023:mdna:178]
Marketing and Selling

[0001032975-15-000023:mdna:179]
Marketing and selling expense consists of personnel and related overhead costs, corporate and product marketing, promotions, advertising, trade shows, customer and technical support and facilities costs.

[0001032975-15-000023:mdna:180]
During fiscal year 2015, marketing and selling expense remained flat compared to fiscal year 2014.

[0001032975-15-000023:mdna:181]
During fiscal year 2014, marketing and selling expense decreased 12%, compared to fiscal year 2013. The decrease was primarily due to $15 million lower personnel-related expenses from the workforce reduction in video conferencing reporting unit as a result of the restructuring plan initiated during fiscal 2014 and $24 million lower advertising and marketing costs related to the launch of new Music category in fiscal year 2013.

[0001032975-15-000023:mdna:182]
Research and Development

[0001032975-15-000023:mdna:183]
Research and development expense consists of personnel and related overhead costs, contractors and outside consultants, supplies and materials, equipment depreciation and facilities costs, all associated with the design and development of new products and enhancements of existing products.

[0001032975-15-000023:mdna:184]
During fiscal year 2015, research and development expense decreased 6%, compared to fiscal year 2014. The decrease was primarily due to $2.8 million lower personnel-related expenses from the workforce reduction in the video conferencing reporting unit as a result of the restructuring plan initiated during fiscal year 2014, $1.3 million decrease in stock-based compensation expense due to fewer grants during fiscal year 2015, and $1.6 million savings from depreciation and amortization expense.

[0001032975-15-000023:mdna:185]
During fiscal year 2014, research and development expense decreased 10%, compared to fiscal year 2013. The decrease was primarily due to $6 million lower personnel-related expenses from the workforce reduction in video conferencing reporting unit as a result of the plan initiated during fiscal 2014 and $9 million lower design and development cost related to the launch of the new Music category in fiscal 2013.

[0001032975-15-000023:mdna:186]
General and Administrative

[0001032975-15-000023:mdna:187]
General and administrative expense consists primarily of personnel and related overhead and facilities costs for the finance, information systems, executives, human resources and legal functions.

[0001032975-15-000023:mdna:188]
During fiscal year 2015, general and administrative expense increased 11% compared to fiscal year 2014. The increase was primarily due to $23.7 million in expense related to the Audit Committee Independent investigation and related expenses, partially offset by infrastructure cost savings such as $6.5 million decrease in information technology costs, including third party vendor cost, and $6.1 million decrease in facility expense as a result of the consolidation of properties.

[0001032975-15-000023:mdna:189]
During fiscal year 2014, general and administrative expense increased 4%, compared to fiscal year 2013. The increase was primarily due to an $8 million increase in personnel-related expenses due to higher variable compensation costs related to our improved performance and share-based compensation expense, partially offset by a $4 million decrease in facility related expenses due to our restructuring plans initiated in fiscal year 2013.

[0001032975-15-000023:mdna:190]
Impairment of Goodwill and Other Assets

[0001032975-15-000023:mdna:191]
We recorded an impairment charge of goodwill of $122.7 million related to our video conferencing reporting unit in fiscal year 2015, and therefore the goodwill of video conferencing reporting unit is reduced to zero as of March 31, 2015. There was no impairment of goodwill and other assets for fiscal year 2014. We recorded an impairment charge of goodwill and other assets of $216.7 million primarily related to the video conferencing reporting unit in fiscal year 2013.

[0001032975-15-000023:mdna:192]
Restructuring Charges

[0001032975-15-000023:mdna:193]
The following table summarizes restructuring-related activities during the years ended March 31, 2015, 2014 and 2013 (in thousands):

[0001032975-15-000023:mdna:194]
|  |  | Restructuring |
|  |  | TerminationBenefits |  | Lease ExitCosts |  | Total |
| Accrual balance at March 31, 2013 |  | $ | 13,383 |  |  | $ | 75 |  |  | $ | 13,458 |  |
| Charges |  | 6,463 |  |  | 7,348 |  |  | 13,811 |  |
| Adjustment for deferred rent |  | — |  |  | 1,450 |  |  | 1,450 |  |
| Cash payments |  | (19,534 | ) |  | (1,454 | ) |  | (20,988 | ) |
| Currency exchange impact |  | (170 | ) |  | — |  |  | (170 | ) |
| Accrual balance at March 31, 2014 |  | 142 |  |  | 7,419 |  |  | 7,561 |  |
| Credits |  | (86 | ) |  | (4,802 | ) |  | (4,888 | ) |
| Cash payments |  | (56 | ) |  | (1,578 | ) |  | (1,634 | ) |
| Accrual balance at March 31, 2015 |  | $ | — |  |  | $ | 1,039 |  |  | $ | 1,039 |  |

[0001032975-15-000023:mdna:195]
During the second quarter of fiscal year 2014, we implemented a restructuring plan solely affecting our video conferencing operating segment to align our organization to our strategic priorities of increasing focus on a tighter range of products, and improving profitability. Restructuring charges under this plan primarily consist of severance and other one-time termination benefits. During fiscal year 2014, restructuring charges under this plan included $5.0 million in termination benefits and $0.6 million in lease exit costs. We substantially completed this restructuring plan by March 31, 2014.

[0001032975-15-000023:mdna:196]
During the fourth quarter of fiscal year 2013, we implemented a restructuring plan to align our organization to our strategic priorities of increasing focus on mobility products, improving profitability in PC-related products and enhancing global operational efficiencies. As part of this restructuring plan, we reduced our worldwide non-direct labor workforce. Restructuring charges under this plan primarily consisted of severance and other one-time termination benefits. During fiscal year 2015, we recorded $4.9 million restructuring credits as a result of partial termination of our lease agreement for the Silicon Valley campus, which was partially vacated during fiscal year 2014. During fiscal year 2014, restructuring charges under this plan included $1.5 million in termination benefits and $6.7 million in lease exit costs, $5.4 million of which pertains to the consolidation of our Silicon Valley campus from two buildings down to one during the quarter ended March 31, 2014. We substantially completed this restructuring plan by the fourth quarter of fiscal year 2014.

[0001032975-15-000023:mdna:197]
Interest Income (Expense), Net

[0001032975-15-000023:mdna:198]
Interest income and expense for fiscal years 2015, 2014 and 2013 were as follows (in thousands):

[0001032975-15-000023:mdna:199]
|  |  | Years Ended March 31, |
|  |  | 2015 |  | 2014 |  | 2013 |
| Interest income |  | $ | 1,225 |  |  | $ | 1,831 |  |  | $ | 2,215 |  |
| Interest expense |  | — |  |  | (2,228 | ) |  | (1,308 | ) |
|  |  | $ | 1,225 |  |  | $ | (397 | ) |  | $ | 907 |  |

[0001032975-15-000023:mdna:200]
Interest expense decreased during fiscal year 2015, compared to fiscal year 2014. The decrease was primarily due to the termination of our $250 million Senior Revolving Credit Facility during fiscal year 2014. There were no new borrowings since then.

[0001032975-15-000023:mdna:201]
Interest expense increased during fiscal year 2014, compared to fiscal year 2013. The increase was primarily due to the write-off of $1.0 million capitalized deferred loan fees related to our $250.0 million Senior Revolving Credit Facility which we chose to terminate during fiscal year 2014.

[0001032975-15-000023:mdna:202]
Other Income (Expense), Net

[0001032975-15-000023:mdna:203]
Other income and expense for fiscal years 2015, 2014 and 2013 were as follows (in thousands):

[0001032975-15-000023:mdna:204]
|  |  | Years Ended March 31, |
|  |  | 2015 |  | 2014 |  | 2013 |
| Investment income related to deferred compensation plan |  | $ | 1,055 |  |  | $ | 1,487 |  |  | $ | 933 |  |
| Gain on sale of securities |  | — |  |  | — |  |  | 831 |  |
| Impairment of investments |  | (2,298 | ) |  | (624 | ) |  | (3,600 | ) |
| Currency exchange gain (loss), net |  | (1,280 | ) |  | 62 |  |  | 104 |  |
| Other |  | (229 | ) |  | 1,068 |  |  | (466 | ) |
|  |  | $ | (2,752 | ) |  | $ | 1,993 |  |  | $ | (2,198 | ) |

[0001032975-15-000023:mdna:205]
Investment income for fiscal years 2015, 2014 and 2013 represents earnings, gains, and losses on trading investments related to a deferred compensation plan offered by one of our subsidiaries.

[0001032975-15-000023:mdna:206]
The $2.3 million, $0.6 million and $3.6 million investment impairment charges in fiscal years 2015, 2014 and 2013, respectively, primarily resulted from the write-down of investments in privately-held companies.

[0001032975-15-000023:mdna:207]
During fiscal year 2013, we sold two available-for-sale securities with a total carrying value of $0.4 million and a total par value of $15.2 million for $0.9 million. This sale resulted in a $0.8 million gain recognized in other income (expense), net, $0.3 million of which resulted from the recognition of a temporary increase in fair value previously recorded in accumulated other comprehensive loss. Following the sales in fiscal year 2013, we have not held any available for sale securities.

[0001032975-15-000023:mdna:208]
Currency exchange gains or losses relate to balances denominated in currencies other than the functional currency in our subsidiaries, as well as to the sale of currencies, and to gains or losses recognized on foreign exchange forward contracts. We do not speculate in currency positions, but we are alert to opportunities to maximize foreign exchange gains and minimize foreign exchange losses.

[0001032975-15-000023:mdna:209]
Provision for (Benefit from) Income Taxes

[0001032975-15-000023:mdna:210]
The provision for (benefit from) income taxes and the effective income tax rate for fiscal years 2015, 2014 and 2013 were as follows (in thousands):

[0001032975-15-000023:mdna:211]
|  |  | Years Ended March 31, |
|  |  | 2015 |  | 2014 |  | 2013 |
| Provision for (benefit from) income taxes |  | $ | 4,490 |  |  | $ | 3,278 |  |  | $ | (25,810 | ) |
| Effective income tax rate |  | 32.6 | % |  | 4.2 | % |  | 10.2 | % |

[0001032975-15-000023:mdna:212]
The change in the effective income tax rate between fiscal year 2015 and 2014 was primarily due to the non-tax deductible goodwill impairment charge of $122.7 million during fiscal year 2015, the mix of income and losses in the various tax jurisdictions in which we operate and a tax benefit of $16.4 million during fiscal year 2015, related to the reversal of uncertain tax positions resulting from the expiration of the statutes of limitations and the closure of tax examination in the state of California of the United States. The effective income tax rate excluding the goodwill impairment charge in fiscal year 2015 is 3.3%. In fiscal year 2014, there was a tax benefit of $14.3 million related to the reversal of uncertain tax positions resulting from the expiration of the statutes of limitations.

[0001032975-15-000023:mdna:213]
The change in the effective income tax rate between fiscal year 2014 and 2013 was primarily due to the mix of income and losses in the various tax jurisdictions and a tax benefit of $14.3 million during fiscal year 2014, related to the reversal of uncertain tax positions resulting from the expiration of the statutes of limitations.  In fiscal year 2013, there was a tax benefit of $35.6 million related to the reversal of uncertain tax positions resulting from the closure of federal income tax examinations in the United States.

[0001032975-15-000023:mdna:214]
On December 19, 2014, the enactment of the Tax Increase Prevention Act of 2014 in the United States extended the federal research and development tax credit through December 31, 2014 which had previously expired on December 31, 2013.  The provision for income taxes for fiscal year ended March 31, 2015 reflected a $0.9 million tax benefit as a result of the extension of the tax credit.

[0001032975-15-000023:mdna:215]
As of March 31, 2015 and March 31, 2014, the total amount of unrecognized tax benefits due to uncertain tax positions was $79.0 million and $91.0 million, respectively, of which $79.0 million and $86.1 million would affect the effective income tax rate if recognized, respectively.

[0001032975-15-000023:mdna:216]
As of March 31, 2015, we had $72.1 million in non-current income taxes payable and $0.1 million in current income taxes payable, including interest and penalties, related to our income tax liability for uncertain tax positions. As of March 31, 2014, we had $93.1 million in non-current income taxes payable and $0.3 million in current income taxes payable. Pursuant to ASU 2013-11, Presentation of an Unrecognized Tax Benefit When a Net Operating Loss Carryforward, a Similar Tax Loss, or a Tax Credit Carryforward Exists, which became effective in the first quarter of fiscal year 2015, we reclassified $10.3 million of unrecognized tax benefits previously presented as non-current income taxes payable to a reduction in non-current deferred tax assets primarily for tax credit carryforwards.

[0001032975-15-000023:mdna:217]
We continue to recognize interest and penalties related to unrecognized tax positions in income tax expense. We recognized $0.8 million, $1.1 million and $1.0 million in interest and penalties in income tax expense during fiscal years 2015, 2014 and 2013, respectively. As of March 31, 2015, 2014 and 2013, we had approximately $4.9 million, $5.6 million and $6.6 million of accrued interest and penalties related to uncertain tax positions.

[0001032975-15-000023:mdna:218]
We file Swiss and foreign tax returns. We received final tax assessments in Switzerland through fiscal year 2012.  For other foreign jurisdictions such as the United States, we are generally not subject to tax examinations for years prior to fiscal year 2011. We are under examination and have received assessment notices in foreign tax jurisdictions. If the examinations are resolved unfavorably, there is a possibility they may have a material negative impact on our results of operations.

[0001032975-15-000023:mdna:219]
Liquidity and Capital Resources

[0001032975-15-000023:mdna:220]
Cash Balances, Available Borrowings, and Capital Resources

[0001032975-15-000023:mdna:221]
At March 31, 2015, we had cash and cash equivalents of $537.0 million, compared with $469.4 million at March 31, 2014. Our cash and cash equivalents consist of bank demand deposits and short-term time deposits of which 81% is held by our Swiss-based entities and 11% is held by our subsidiaries in Hong Kong and China. We do not expect to incur any material adverse tax impact or be significantly inhibited by any country in which we do business from the repatriation of funds to Switzerland, our home domicile.

[0001032975-15-000023:mdna:222]
At March 31, 2015, our working capital was $557.1 million compared with working capital of $478.2 million at March 31, 2014. The increase in working capital over the prior year was primarily due to higher cash and inventory balances, partially offset by higher accounts payable balances at March 31, 2015.

[0001032975-15-000023:mdna:223]
During fiscal year 2015, we generated $178.6 million cash from operating activities. Our main sources of operating cash flows were from net income after adding back non-cash expenses of depreciation, amortization, impairment of goodwill and share-based compensation expense, and from an increase in accounts payable, partially offset by increases in inventories and accounts receivable and a decrease in accrued and other liabilities. Net cash used in investing activities was $48.3 million, primarily for purchase of property, plant, and equipment of $45.3 million and investments in privately held companies of $2.6 million. Net cash used in financing activities was $48.9 million, primarily for the $43.8 million cash dividend payment, $9.2 million tax withholdings related to net share settlements of restricted stock units, partially offset by $4.1 million in proceeds received from the sale of shares upon exercise of options and purchase rights.

[0001032975-15-000023:mdna:224]
We had several uncommitted, unsecured bank lines of credit aggregating to $38.1 million as of March 31, 2015. There are no financial covenants under these lines of credit which we must comply with. As of March 31, 2015, we had outstanding bank guarantees of $5.1 million under these lines of credit. There are no financial covenants under these credit lines.

[0001032975-15-000023:mdna:225]
The following table summarizes our Consolidated Statements of Cash Flows (in thousands):

[0001032975-15-000023:mdna:226]
|  |  | Years Ended March 31, |
|  |  | 2015 |  | 2014 |  | 2013 |
| Net cash provided by operating activities |  | $ | 178,632 |  |  | $ | 205,421 |  |  | $ | 122,389 |  |
| Net cash used in investing activities |  | (48,289 | ) |  | (46,803 | ) |  | (57,723 | ) |
| Net cash used in financing activities |  | (48,854 | ) |  | (22,681 | ) |  | (207,641 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  | (13,863 | ) |  | (349 | ) |  | (1,571 | ) |
| Net increase (decrease) in cash and cash equivalents |  | $ | 67,626 |  |  | $ | 135,588 |  |  | $ | (144,546 | ) |

[0001032975-15-000023:mdna:227]
Cash Flow from Operating Activities

[0001032975-15-000023:mdna:228]
The following table presents selected financial information and statistics for fiscal years 2015, 2014 and 2013 (dollars in thousands):

[0001032975-15-000023:mdna:229]
|  |  | March 31, |
|  |  | 2015 |  | 2014 |  | 2013 |
| Accounts receivable, net |  | $ | 179,823 |  |  | $ | 182,029 |  |  | $ | 178,959 |  |
| Inventories |  | 270,730 |  |  | 222,402 |  |  | 262,644 |  |
| Working capital |  | 557,113 |  |  | 478,213 |  |  | 385,073 |  |
| Days sales in accounts receivable ("DSO")(Days)(1) |  | 35 |  |  | 34 |  |  | 34 |  |
| Inventory turnover ("ITO")(x)(2) |  | 4.6 |  |  | 5.9 |  |  | 4.7 |  |

[0001032975-15-000023:mdna:230]
______________________________

[0001032975-15-000023:mdna:231]
| (1) | DSO is determined using ending accounts receivable as of the most recent quarter-end and net sales for the most recent quarter. |

[0001032975-15-000023:mdna:232]
| (2) | ITO is determined using ending inventories and annualized cost of goods sold (based on the most recent quarterly cost of goods sold). |

[0001032975-15-000023:mdna:233]
ITO as of March 31, 2015 decreased compared to March 31, 2014. The decrease was primarily due to higher inventory levels due to the port strike in the west coast of the United States and change in shipping strategy from air to ocean during the fourth quarter of fiscal year 2015.

[0001032975-15-000023:mdna:234]
ITO as of March 31, 2014 increased, compared to March 31, 2013. The increase was primarily due to lower inventory levels in relation to net sales during the fourth quarter of fiscal year 2014.

[0001032975-15-000023:mdna:235]
Cash Flow from Investing Activities

[0001032975-15-000023:mdna:236]
|  |  | Years Ended March 31, |
|  |  | 2015 |  | 2014 |  | 2013 |
| Purchases of property, plant and equipment |  | $ | (45,253 | ) |  | $ | (46,658 | ) |  | $ | (54,487 | ) |
| Investment in privately held companies |  | (2,550 | ) |  | (300 | ) |  | (4,420 | ) |
| Acquisitions, net of cash acquired |  | (926 | ) |  | (650 | ) |  | — |  |
| Proceeds from sales of available-for-sale securities |  | — |  |  | — |  |  | 917 |  |
| Proceeds from return of investment from strategic investments |  | — |  |  | 261 |  |  | — |  |
| Purchase of trading investments |  | (5,034 | ) |  | (8,450 | ) |  | (4,196 | ) |
| Proceeds from sales of trading investments |  | 5,474 |  |  | 8,994 |  |  | 4,463 |  |
|  |  | $ | (48,289 | ) |  | $ | (46,803 | ) |  | $ | (57,723 | ) |

[0001032975-15-000023:mdna:237]
Our expenditures for property, plant and equipment during fiscal year 2015, 2014 and 2013 were primarily expenditures for leasehold improvements, computer hardware and software, tooling and equipment.

[0001032975-15-000023:mdna:238]
During fiscal year 2015, purchases of property, plant and equipment remained relatively stable compared to fiscal year 2014. We made a $2.5 million strategic investment in one privately held company and acquired one privately held company for $0.9 million, during fiscal year 2015.

[0001032975-15-000023:mdna:239]
During fiscal year 2014, purchases of property, plant and equipment decreased, compared to fiscal year 2013, primarily due to leasehold improvements related to our new Silicon Valley campus during fiscal year 2013. During fiscal year 2014, we made a $0.7 million investment.

[0001032975-15-000023:mdna:240]
During fiscal year 2013, we purchased a strategic investment for $4.0 million in exchange for convertible preferred stock. We accounted for this investment under the cost method of accounting since we have less than 20% ownership interest and we lack the ability to exercise significant influence over the operating and financial policies of the investee. We also purchased another strategic investment for $0.4 million. In addition, we sold our two remaining available-for-sale securities for $0.9 million.

[0001032975-15-000023:mdna:241]
The purchases and sales of trading investments during fiscal years 2015, 2014 and 2013 represent mutual fund activity directed by participants in a deferred compensation plan offered by one of our subsidiaries. The mutual funds are held by a Rabbi Trust.

[0001032975-15-000023:mdna:242]
Cash Flow from Financing Activities

[0001032975-15-000023:mdna:243]
|  |  | Years Ended March 31, |
|  |  | 2015 |  | 2014 |  | 2013 |
| Payment of cash dividends |  | $ | (43,767 | ) |  | $ | (36,123 | ) |  | $ | (133,462 | ) |
| Purchases of treasury shares |  | (1,663 | ) |  | — |  |  | (87,812 | ) |
| Contingent consideration related to prior acquisition |  | (100 | ) |  | — |  |  | — |  |
| Repurchase of ESPP awards |  | (1,078 | ) |  | — |  |  | — |  |
| Proceeds from sales of shares upon exercise of options and purchase rights |  | 4,138 |  |  | 16,914 |  |  | 15,982 |  |
| Tax withholdings related to net share settlements of restricted stock units |  | (9,215 | ) |  | (5,718 | ) |  | (2,375 | ) |
| Excess tax benefits from share-based compensation |  | 2,831 |  |  | 2,246 |  |  | 26 |  |
|  |  | $ | (48,854 | ) |  | $ | (22,681 | ) |  | $ | (207,641 | ) |

[0001032975-15-000023:mdna:244]
During fiscal year 2015 and 2014, we paid annual cash dividends of $43.8 million and $36.1 million, respectively, compared to a special one-time distribution of $133.5 million during fiscal year 2013.

[0001032975-15-000023:mdna:245]
During fiscal year 2015, we repurchased 0.1 million shares for $1.7 million. There were no stock repurchases during fiscal year 2014. During fiscal year 2013, we repurchased 8.6 million shares for $87.8 million.

[0001032975-15-000023:mdna:246]
Proceeds from the sale of shares upon exercise of options and purchase rights pursuant to our stock plans during fiscal years 2015, 2014 and 2013 were $4.1 million, $16.9 million and $16.0 million, respectively. The payments of tax withholdings related to net share settlements of RSUs (restricted stock units) during fiscal years 2015, 2014 and 2013 were $9.2 million, $5.7 million and $2.4 million, respectively.

[0001032975-15-000023:mdna:247]
Translation effect of exchange rate changes on cash and cash equivalents

[0001032975-15-000023:mdna:248]
During fiscal year 2015, there was a $13.9 million currency translation exchange rate effect on cash and cash equivalents.  This is primarily due to the 22% weakening of Euro versus U.S Dollar during fiscal year 2015 which had an adverse impact on our cash and cash equivalents balances in subsidiaries with functional currency as Euro.

[0001032975-15-000023:mdna:249]
Cash Outlook

[0001032975-15-000023:mdna:250]
Our principal sources of liquidity are our cash and cash equivalents, cash flow generated from operations and, to a much lesser extent, capital markets and borrowings. Our future working capital requirements and capital expenditures may increase to support investment in product innovations and growth opportunities, or to acquire or invest in complementary businesses, products, services, and technologies.

[0001032975-15-000023:mdna:251]
In March 2015, we announced a plan to pay $250 million in cumulative dividends for fiscal year 2015 through fiscal year 2017. The Board of Directors plans to request shareholder approval of the Swiss Franc equivalent of an $85 million dividend for fiscal year 2015 at our next annual general meeting. Based on exchange rates of 1.0283 and the number of shares outstanding as of March 31, 2015, this represents approximately CHF 0.51 per share,

[0001032975-15-000023:mdna:252]
62

[0001032975-15-000023:mdna:253]
compared to dividend of CHF 0.26 per share for fiscal year 2015. During fiscal year 2015, we paid a cash dividend of CHF 43.1 million (U.S. Dollar amount of $43.8 million) out of retained earnings.

[0001032975-15-000023:mdna:254]
In March 2014, our Board of Directors approved a new share buyback program, which authorizes us to invest up to $250.0 million to purchase our own shares. Our share buyback program provides us with the opportunity to make repurchases during periods of favorable market conditions and is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Purchases may be started or stopped at any time without prior notice depending on market conditions and other factors. During fiscal year 2015, 0.1 million shares were repurchased for $1.7 million under this program.

[0001032975-15-000023:mdna:255]
During the first quarter of fiscal year 2016, we announced that we are committing to pursue a restructuring, including exiting the OEM business, reorganizing Lifesize to sharpen its focus on its Cloud-based offering, and streamlining the Company's overall cost structure through product, overhead and infrastructure cost reductions with a targeted resource realignment.  We expect that we will recognize restructuring charges of approximately $15 million to $20 million, consisting primarily of severance, other one-time termination benefits, and other restructuring charges. We expect this restructuring will save personnel-related costs and other overhead costs and we expect to use the savings from the restructuring to offset currency headwinds and to invest in future growth.

[0001032975-15-000023:mdna:256]
Our other contractual obligations and commitments that require cash are described in the following sections.

[0001032975-15-000023:mdna:257]
For over ten years, we have generated positive cash flows from our operating activities, including cash from operations of $178.6 million, $205.4 million and $122.4 million during fiscal years 2015, 2014 and 2013, respectively. If we do not generate sufficient operating cash flows to support our operations and future planned cash requirements, our operations could be harmed and our access to credit facilities could be restricted or eliminated. However, we believe that the trend of our historical cash flow generation, our projections of future operations and reduced expenses and our available cash balances will provide sufficient liquidity to fund our operations for at least the next 12 months.

[0001032975-15-000023:mdna:258]
Contractual Obligations and Commitments

[0001032975-15-000023:mdna:259]
As of March 31, 2015, our outstanding contractual obligations and commitments included: (i) inventory purchase commitments and obligations, (ii) capital expenditure purchase commitments, and (iii) facilities leased under operating lease commitments. The following table summarizes our contractual obligations and commitments as of March 31, 2015 (in thousands):

[0001032975-15-000023:mdna:260]
|  |  |  |  | Payments Due by Period |
|  |  | March 31, 2015 | <1 year |  | 1-3 years |  | 4-5 years |  | >5 years |
| Inventory commitments |  | $ | 165,912 |  |  | $ | 165,912 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Capital commitments |  | 14,390 |  |  | 14,390 |  |  | — |  |  | — |  |  | — |  |
| Operating leases |  | 54,232 |  |  | 13,829 |  |  | 18,727 |  |  | 11,768 |  |  | 9,908 |  |
|  |  | $ | 234,534 |  |  | $ | 194,131 |  |  | $ | 18,727 |  |  | $ | 11,768 |  |  | $ | 9,908 |  |

[0001032975-15-000023:mdna:261]
Operating Leases

[0001032975-15-000023:mdna:262]
We lease facilities under operating leases, certain of which require us to pay property taxes, insurance and maintenance costs. Operating leases for facilities are generally renewable at our option and usually include escalation clauses linked to inflation. The remaining terms on our non-cancelable operating leases expire in various years through 2030.

[0001032975-15-000023:mdna:263]
Purchase Commitments

[0001032975-15-000023:mdna:264]
As of March 31, 2015, we have fixed purchase commitments of $165.9 million for inventory purchases made in the normal course of business to original design manufacturers, contract manufacturers and other suppliers, the majority of which are expected to be fulfilled during the first quarter of fiscal year 2016. We record a liability for firm, non-cancelable, and unhedged inventory purchase commitments in excess of anticipated demand or market value consistent with our valuation of excess and obsolete inventory. As of March 31, 2015, the liability for these purchase commitments was $9.8 million and is recorded in accrued and other current liabilities and is not included in the preceding table. We have fixed purchase commitments of $14.4 million for capital expenditures, primarily related to commitments for tooling, computer hardware and leasehold improvements. We expect to continue making capital

[0001032975-15-000023:mdna:265]
expenditures in the future to support product development activities and ongoing and expanded operations. Although open purchase commitments are considered enforceable and legally binding, the terms generally allow us the option to reschedule and adjust our requirements based on business needs prior to delivery of goods or performance of services.

[0001032975-15-000023:mdna:266]
Income Taxes Payable

[0001032975-15-000023:mdna:267]
As of March 31, 2015, we had $72.1 million in non-current income taxes payable, including interest and penalties, related to our income tax liability for uncertain tax positions. At this time, we are unable to make a reasonably reliable estimate of the timing of payments in individual years in connection with these tax liabilities; therefore, such amounts are not included in the above contractual obligation table.

[0001032975-15-000023:mdna:268]
Off-Balance Sheet Arrangements

[0001032975-15-000023:mdna:269]
We have not entered into any transactions with unconsolidated entities whereby we have financial guarantees, subordinated retained interests, derivative instruments or other contingent arrangements that expose us to material continuing risks, contingent liabilities, or any other obligation under a variable interest in an unconsolidated entity that provides financing, liquidity, market risk or credit risk support to us.

[0001032975-15-000023:mdna:270]
Investment Commitments

[0001032975-15-000023:mdna:271]
During 2015, we entered into a limited partnership agreement with a private investment fund specialized in early-stage start-up consumer hardware electronics companies and committed a capital contribution of $4.0 million over the life of the fund. As of March 31, 2015, no capital contribution has been called by the fund.

[0001032975-15-000023:mdna:272]
Other Contingencies

[0001032975-15-000023:mdna:273]
We are subject to an ongoing formal investigation by the SEC’s Enforcement Division, relating to certain issues including the accounting for Revue inventory valuation reserves that resulted in the restatement described in the Fiscal Year 2014 Annual Report on Form 10-K, revision to our consolidated financial statements concerning warranty accruals and amortization of intangible assets presented in our Amended Annual Report on Form 10-K/A, filed on August 7, 2013, and our transactions with a distributor for Fiscal Year 2007 through Fiscal Year 2009. We have entered into an agreement with the SEC to extend the statute of limitations. We are cooperating with the investigation and recently engaged in discussions to settle the matter with the SEC, including making offers of monetary amounts for a civil penalty.  In accordance with U.S. GAAP, we have made an accrual in our financial statements.  We cannot predict the timing, range of possible loss or final outcome of this matter.

[0001032975-15-000023:mdna:274]
Guarantees

[0001032975-15-000023:mdna:275]
Logitech Europe S.A. guaranteed payments of third-party contract manufacturers' purchase obligations. As of March 31, 2015, the maximum amount of this guarantee was $3.8 million, of which $1.7 million of guaranteed purchase obligations were outstanding.

[0001032975-15-000023:mdna:276]
Indemnifications

[0001032975-15-000023:mdna:277]
We indemnify certain of our suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys' fees. As of March 31, 2015, no amounts have been accrued for indemnification provisions. We do not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under our indemnification arrangements.

[0001032975-15-000023:mdna:278]
We also indemnify our current and former directors and certain of our current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. We are unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not capped, the obligations are conditional in nature, and the facts and circumstances involved in any situation that might arise are variable.

[0001032975-15-000023:mdna:279]
Research and Development

[0001032975-15-000023:mdna:280]
For a discussion of our research and development activities, patents and licenses, please refer to Item 1, Business.
