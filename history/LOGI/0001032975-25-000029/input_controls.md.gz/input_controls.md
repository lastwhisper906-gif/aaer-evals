# LOGI 10-K controls and the auditor's report


## auditors_report

[0001032975-25-000029:auditors_report:1]
Report of Independent Registered Public Accounting Firm

[0001032975-25-000029:auditors_report:2]
To the Shareholders and Board of Directors

[0001032975-25-000029:auditors_report:3]
Logitech International S.A.:

[0001032975-25-000029:auditors_report:4]
Opinions on the Consolidated Financial Statements and Internal Control Over Financial Reporting

[0001032975-25-000029:auditors_report:5]
We have audited the accompanying consolidated balance sheets of Logitech International S.A. and subsidiaries (the Company) as of March 31, 2025 and 2024, the related consolidated statements of operations, comprehensive income, changes in shareholders’ equity, and cash flows for each of the years in the three-year period ended March 31, 2025, and the related notes and financial statement schedule II (collectively, the consolidated financial statements). We also have audited the Company’s internal control over financial reporting as of March 31, 2025, based on criteria established in Internal Control – Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission.

[0001032975-25-000029:auditors_report:6]
In our opinion, the consolidated financial statements referred to above present fairly, in all material respects, the financial position of the Company as of March 31, 2025 and 2024, and the results of its operations and its cash flows for each of the years in the three-year period ended March 31, 2025, in conformity with U.S. generally accepted accounting principles. Also in our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of March 31, 2025 based on criteria established in Internal Control – Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission.

[0001032975-25-000029:auditors_report:7]
Basis for Opinions

[0001032975-25-000029:auditors_report:8]
The Company’s management is responsible for these consolidated financial statements, for maintaining effective internal control over financial reporting, and for its assessment of the effectiveness of internal control over financial reporting, included in the accompanying Management's Report on Internal Control over Financial Reporting. Our responsibility is to express an opinion on the Company’s consolidated financial statements and an opinion on the Company’s internal control over financial reporting based on our audits. We are a public accounting firm registered with the Public Company Accounting Oversight Board (United States) (PCAOB) and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001032975-25-000029:auditors_report:9]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audits to obtain reasonable assurance about whether the consolidated financial statements are free of material misstatement, whether due to error or fraud, and whether effective internal control over financial reporting was maintained in all material respects.

[0001032975-25-000029:auditors_report:10]
Our audits of the consolidated financial statements included performing procedures to assess the risks of material misstatement of the consolidated financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the consolidated financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the consolidated financial statements. Our audit of internal control over financial reporting included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, and testing and evaluating the design and operating effectiveness of internal control based on the assessed risk. Our audits also included performing such other procedures as we considered necessary in the circumstances. We believe that our audits provide a reasonable basis for our opinions.

[0001032975-25-000029:auditors_report:11]
Definition and Limitations of Internal Control Over Financial Reporting

[0001032975-25-000029:auditors_report:12]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (1) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (2) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance

[0001032975-25-000029:auditors_report:13]
Logitech International S.A. | Fiscal 2025 Form 10-K | 64

[0001032975-25-000029:auditors_report:14]
with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (3) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0001032975-25-000029:auditors_report:15]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001032975-25-000029:auditors_report:16]
Critical Audit Matter

[0001032975-25-000029:auditors_report:17]
The critical audit matter communicated below is a matter arising from the current period audit of the consolidated financial statements that was communicated or required to be communicated to the audit committee and that: (1) relates to accounts or disclosures that are material to the consolidated financial statements and (2) involved our especially challenging, subjective, or complex judgments. The communication of a critical audit matter does not alter in any way our opinion on the consolidated financial statements, taken as a whole, and we are not, by communicating the critical audit matter below, providing a separate opinion on the critical audit matter or on the accounts or disclosures to which it relates.

[0001032975-25-000029:auditors_report:18]
Assessment of the accruals for certain Customer Programs

[0001032975-25-000029:auditors_report:19]
As discussed in Notes 2 and 8 to the consolidated financial statements, the Company recorded accrued Customer Program liabilities of $173.4 million as of March 31, 2025 for customer incentives, cooperative marketing, and pricing programs (collectively, Customer Programs). The Company records these accruals as a reduction of revenue at the time of sale. For certain of these accruals, the Company estimated the amounts based on historical data or future commitments that are planned and controlled by the Company. The Company uses judgment in analyzing historical trends, inventories owned by and located at the customers, products sold by the direct customers to end customers or resellers, known product quality issues, negotiated terms, and other relevant customer and product information, such as stage of product life cycle, which are expected to experience unusually high discounting.

[0001032975-25-000029:auditors_report:20]
We identified the assessment of the accruals for certain Customer Programs as a critical audit matter. Historical experience being predictive of Customer Programs’ earned amounts is the significant assumption used to estimate the accruals for Customer Programs. Due to the inherent uncertainties related to the relevance of the predictive historical experience to the determination of the estimate, the testing required a high degree of auditor judgment.

[0001032975-25-000029:auditors_report:21]
The following are the primary procedures we performed to address this critical audit matter. We evaluated the design and tested the operating effectiveness of certain internal controls related to the critical audit matter. This included controls related to the Company’s assessment of whether historical experience is predictive of Customer Programs’ earned amounts and the Company’s validation of the underlying channel inventory data used to estimate the accruals for Customer Programs. We assessed the historical experience used in estimating the accruals for certain Customer Programs using a combination of the Company’s internal historical information of sales, Customer Programs’ earned amounts, and relevant and reliable third-party channel inventory and sell-through data. In addition, we evaluated the Company’s ability to estimate the accruals for certain Customer Programs by comparing recorded accruals from fiscal year 2024 to actual subsequent Customer Programs’ earned amounts in fiscal year 2025.

[0001032975-25-000029:auditors_report:22]
/s/ KPMG LLP

[0001032975-25-000029:auditors_report:23]
We have served as the Company’s auditor since 2014.

[0001032975-25-000029:auditors_report:24]
San Francisco, California

[0001032975-25-000029:auditors_report:25]
May 23, 2025

[0001032975-25-000029:auditors_report:26]
Logitech International S.A. | Fiscal 2025 Form 10-K | 65

[0001032975-25-000029:auditors_report:27]
LOGITECH INTERNATIONAL S.A.


## item_9a

[0001032975-25-000029:item_9a:1]
ITEM 9A.    CONTROLS AND PROCEDURES

[0001032975-25-000029:item_9a:2]
(a) Evaluation of Disclosure Controls and Procedures

[0001032975-25-000029:item_9a:3]
The Company's management, with the participation of the Company’s Chief Executive Officer (CEO) and Chief Financial Officer (CFO), has conducted an evaluation of the effectiveness of the design and operation of the Company's disclosure controls and procedures (as defined in Rules 13a-15(e) and 15d-15(e) under the Securities Exchange Act of 1934, as amended (the Exchange Act)) as of the end of the period covered by this Annual Report on Form 10-K (this Annual Report) required by Exchange Act Rules 13a-15(b) or 15d-15(b). Disclosure controls and

[0001032975-25-000029:item_9a:4]
Logitech International S.A. | Fiscal 2025 Form 10-K | 53

[0001032975-25-000029:item_9a:5]
procedures are designed to reasonably assure that information required to be disclosed in our reports filed or submitted under the Exchange Act, such as this Annual Report on Form 10-K, is recorded, processed, summarized and reported within the time periods specified in the Securities and Exchange Commission's rules and forms. Disclosure controls and procedures are also designed to reasonably assure that this information is accumulated and communicated to our management, including the CEO and CFO, to allow timely decisions regarding required disclosure. Based on this evaluation, the CEO and CFO concluded that, as of the end of the period covered by this Annual Report, the Company’s disclosure controls and procedures were effective at a reasonable assurance level.

[0001032975-25-000029:item_9a:6]
Attached as exhibits to this Annual Report are certifications of the CEO and CFO, which are required in accordance with Rule 13a-14 of the Exchange Act. This Controls and Procedures section includes the information concerning the controls evaluation referred to in the certifications, and it should be read in conjunction with the certifications for a more complete understanding of the topics presented.

[0001032975-25-000029:item_9a:7]
(b) Management's Report on Internal Control over Financial Reporting

[0001032975-25-000029:item_9a:8]
The Company's management is responsible for establishing and maintaining adequate internal control over financial reporting as defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act. Under the supervision and with the participation of the Company’s management, including the CEO and CFO, the Company conducted an evaluation of the effectiveness of its internal control over financial reporting based on the criteria established in the Internal Control-Integrated Framework (2013), issued by the Committee of Sponsoring Organizations of the Treadway Commission. Based on this evaluation, management has concluded that our internal control over financial reporting was effective as of March 31, 2025.

[0001032975-25-000029:item_9a:9]
The effectiveness of the Company's internal control over financial reporting as of March 31, 2025 has been audited by KPMG LLP, an independent registered public accounting firm, as stated in its report, which appears in Item 15.

[0001032975-25-000029:item_9a:10]
(c) Changes in Internal Control over Financial Reporting

[0001032975-25-000029:item_9a:11]
There were no changes in the Company's internal control over financial reporting during the fourth quarter of fiscal year 2025 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0001032975-25-000029:item_9a:12]
(d) Limitations on the Effectiveness of Controls

[0001032975-25-000029:item_9a:13]
The Company's management, including the CEO and the CFO, does not expect that the Company's disclosure controls and procedures or internal control over financial reporting will prevent all errors and all fraud. Internal control over financial reporting, no matter how well designed and operated, can provide only reasonable, not absolute, assurance that the objectives will be met. Because of the inherent limitations in internal control over financial reporting, no evaluation of controls can provide absolute assurance that all control issues and instances of fraud, if any, within the Company have been detected. These inherent limitations include the realities that judgments in decision making can be faulty and that breakdowns can occur because of simple error or mistake. Controls can also be circumvented by the individual acts of some persons, by collusion of two or more people, or by management override of the controls. The design of any system of controls is based in part on certain assumptions about the likelihood of future events, and there can be no assurance that any design will succeed in achieving its stated goals under all potential future conditions. Over time, controls may become inadequate because of changes in conditions or deterioration in the degree of compliance with policies or procedures. Because of the inherent limitations in a cost-effective control system, misstatements due to error or fraud may occur and not be detected.
