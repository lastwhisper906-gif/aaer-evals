# LOGI notes — 0001032975-25-000029


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001032975-25-000029:notes:1]
Portions of the registrant's Proxy Statement for the 2025 Annual Meeting of Shareholders are incorporated herein by reference in Part III of this Annual Report on Form 10-K to the extent stated herein.


## cyd:CybersecurityRiskManagementProcessesForAssessingIdentifyingAndManagingThreatsTextBlock

[0001032975-25-000029:notes:2]
We have established a Security Governance Framework that defines roles and responsibilities, so that security is taken into account at all levels and in every department or function of the Company. Our framework provides guidance for the organization, governance and implementation of security across the company. Logitech and its infrastructure have been certified for compliance with ISO 27001, an international standard for information security management.

[0001032975-25-000029:notes:3]
Identifying and assessing cybersecurity risks is integrated into our enterprise risk management. As part of our risk management program, we continuously assess risks from third parties, including vendors, suppliers, and other business partners associated with our use of third-party service providers. We have implemented incident response and breach management processes that include the following steps: mobilizing the right stakeholders and containing the attack, maintaining trust with all affected stakeholders and understanding the attack, recovering the most critical business operations, and learning from the attack. We also conduct tabletop exercises to, among other things, align activities and expectations in connection with our incident response processes, discuss strategic questions, and review third party recommendations.

[0001032975-25-000029:notes:4]
We have not previously experienced a cybersecurity event that was determined to be material, and our business strategy, results of operations and financial condition have not been materially affected by risks from cybersecurity threats. For additional information regarding risks from cybersecurity threats, please refer to Item 1A "Risk Factors" in this Annual Report on Form 10-K.


## cyd:CybersecurityRiskBoardOfDirectorsOversightTextBlock

[0001032975-25-000029:notes:5]
Logitech’s Board of Directors oversees risk management and reviews Logitech security risks, controls and procedures. The Board of Directors is assisted in its role by each of the Audit Committee and the Technology and Innovation Committee. The Audit Committee is responsible for the oversight of risks from cybersecurity threats. Members of the Audit Committee receive updates on a semi-annual basis from our Chief Information Security Officer (“CISO”) regarding matters of cybersecurity. The Technology and Innovation Committee periodically reviews the Company’s cybersecurity, information security and other technology risks, controls and procedures, including product security and related threats. Finally, the Board has formed a Cyber Crisis Subcommittee tasked with overseeing any future significant cybersecurity crisis.


## cyd:CybersecurityRiskRoleOfManagementTextBlock

[0001032975-25-000029:notes:6]
Management’s Role in Assessing and Managing Material Risks from Cybersecurity Threats

[0001032975-25-000029:notes:7]
Our Security Team is responsible for evaluating, reporting and advising about security threats and risks, defining and leading the enterprise security program to protect Logitech business against security threats, maintaining and updating the security framework, monitoring the level of compliance with the security framework across Logitech digital assets, products and services, providing enterprise-wide security services, defining security policies, standards and guidelines, advising on secure architectures, performing assessments and due diligence checks internally and with business partners, providing security guidance for digital projects, creating and deploying security training programs, managing security incidents and breaches, and conducting threat intelligence and managing vulnerabilities.

[0001032975-25-000029:notes:8]
Our Security Team also monitors security through the entire software and product development lifecycle. The Head of Application and Product Security is accountable for the release or deployment approval of a product based upon the review of internal and external validation (functionality, performance, security) reports.

[0001032975-25-000029:notes:9]
The Security Team, which is part of the Digital Office organization, is led by the CISO, who has 20 years of security experience across different industries. The CISO reports to our Head of Digital Office, who has more than 20 years of experience leading software and infrastructure teams, including over a decade in the cybersecurity industry. Our security is managed based on industry-leading standards such as ISO 27001, National Institute of Standards and Technology (NIST), Center for Internet Security (CIS), Open Worldwide Application Security Project (OWASP) Application Security Verification Standard (ASVS) and the Software Assurance Maturity Model (SAMM).

[0001032975-25-000029:notes:10]
Our CISO and the Head of Digital Office regularly report on cybersecurity to the Audit Committee and/or the Technology and Innovation Committee and the Board of Directors.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001032975-25-000029:notes:11]
On January 30, 2025, Prakash Arunkundrum, our President of Logitech for Business, adopted a Rule 10b5-1 trading arrangement providing for the sale of an aggregate of up to 14,900 shares of our common stock acquired by Mr. Arunkundrum under our equity plans. The trading arrangement is intended to satisfy the affirmative defense in Rule 10b5-1(c). The first date that sales of any shares are permitted to be sold under the trading arrangement will

[0001032975-25-000029:notes:12]
be May 26, 2025. The trading arrangement terminates on March 16, 2026, or upon the earlier completion of all transactions thereunder.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001032975-25-000029:notes:13]
Summary of Significant Accounting Policies
Basis of Presentation

[0001032975-25-000029:notes:14]
The consolidated financial statements include the accounts of Logitech and its subsidiaries. All intercompany balances and transactions have been eliminated. The consolidated financial statements are presented in accordance with accounting principles generally accepted in the United States ("U.S. GAAP").

[0001032975-25-000029:notes:15]
Fiscal Year

[0001032975-25-000029:notes:16]
The Company's fiscal year ends on March 31. Interim quarters are generally thirteen-week periods, each ending on a Friday. For purposes of presentation, the Company has indicated its quarterly periods end on the last day of the calendar quarter.

[0001032975-25-000029:notes:17]
Reference to Sales

[0001032975-25-000029:notes:18]
References to "sales" in the Notes to the consolidated financial statements means net sales, except as otherwise specified.

[0001032975-25-000029:notes:19]
Use of Estimates

[0001032975-25-000029:notes:20]
The preparation of financial statements in conformity with U.S. GAAP requires management to make judgments, estimates and assumptions that affect the amounts reported in the consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Significant estimates and assumptions made by management involve the fair value of goodwill and intangible assets acquired from business acquisitions, pension obligations, accruals for customer incentives, cooperative marketing, and pricing programs ("Customer Programs") and related breakage when appropriate, inventory valuation, share-based compensation expense, uncertain tax positions, and valuation allowances for deferred tax assets. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ materially from those estimates.

[0001032975-25-000029:notes:21]
Risks and Uncertainties

[0001032975-25-000029:notes:22]
Impacts of Macroeconomic and Geopolitical Conditions on the Company's Business

[0001032975-25-000029:notes:23]
In 2025, the United States introduced trade policy actions that have increased import tariffs across a wide range of countries at various rates, with certain exemptions. The tariff policies in the U.S. and responsive policies enacted in other countries are evolving and may have a material adverse impact on the Company's business. In addition, the Company's business has continued to be impacted by ongoing macroeconomic and geopolitical conditions. These conditions include inflation, interest rate and foreign currency fluctuations, uncertainty in

[0001032975-25-000029:notes:24]
consumer and enterprise demand, low economic growth in certain regions, changes in fiscal policies and geopolitical conflicts.

[0001032975-25-000029:notes:25]
The global and regional economic and political conditions, as well as changes in trade policies, have caused and may continue to cause volatility in demand for the Company's products as well as the cost of tariffs, materials and logistics, and transportation delays, and as a result have impacted and may continue to impact the pricing of the Company's products, product availability and the Company's results of operations.

[0001032975-25-000029:notes:26]
Currencies

[0001032975-25-000029:notes:27]
The functional currency of the Company's operations is primarily the U.S. Dollar. Certain operations use the Euro, Chinese Renminbi, Swiss Franc, or other local currencies as their functional currencies. The financial statements of the Company's subsidiaries whose functional currency is other than the U.S. Dollar are translated to U.S. Dollars using period-end rates of exchange for assets and liabilities and monthly average rates for sales, income and expenses. Cumulative translation gains and losses are included as a component of shareholders' equity in accumulated other comprehensive income (loss). Gains and losses arising from transactions denominated in currencies other than a subsidiary's functional currency are reported in other income (expense), net in the consolidated statements of operations.

[0001032975-25-000029:notes:28]
Revenue Recognition

[0001032975-25-000029:notes:29]
Revenue is recognized when a customer obtains control of promised goods or services in an amount that reflects the transaction price the Company expects to receive in exchange for those goods or services.

[0001032975-25-000029:notes:30]
Substantially all revenue recognized by the Company relates to the contracts with customers to sell products that allow people to connect through gaming, video, computing, music and other digital platforms. These products are hardware devices, which may include embedded software that function together, and are considered as one performance obligation. Hardware devices are generally plug and play, requiring no configuration and little or no installation. Revenue is recognized at a point in time when control of the products is transferred to the customer which generally occurs upon shipment. The Company’s sales contracts with its customers have a one year or shorter term.

[0001032975-25-000029:notes:31]
The Company also provides post-contract customer support (“PCS”) for certain products and related software, which includes unspecified software updates and upgrades, bug fixes and maintenance. The transaction price is allocated to two performance obligations in such contracts, based on a relative standalone selling price. The transaction price allocated to PCS is recognized as revenue on a straight-line basis, which reflects the pattern of delivery of PCS, over the estimated term of the support.

[0001032975-25-000029:notes:32]
The Company also recognizes revenue from subscription services that provide professional streamers with access to streaming software and tools as well as from Video Collaboration support services. These services represent stand-ready performance obligations. Payments for these services are made at the time of or in advance of delivering the services. The proceeds received in advance from such arrangements is recognized as deferred revenue and then recognized as revenue ratably over the service period up to five years.

[0001032975-25-000029:notes:33]
See Note 8 for the current and non-current deferred revenue associated with the Company’s remaining performance obligations to be recognized within the next 12 months and thereafter, respectively.

[0001032975-25-000029:notes:34]
The Company normally requires payment from customers within thirty to sixty days from the invoice date. However, terms may vary by customer type, by country and by selling season. The Company generally does not modify payment terms on existing receivables. The Company's contracts with customers do not include significant financing components as the period between the satisfaction of performance obligations and timing of payment are generally within one year.

[0001032975-25-000029:notes:35]
The transaction price received by the Company from sales to its distributors, retail companies ("retailers"), and authorized resellers is calculated as selling price net of variable consideration which may include product returns and the Company’s payments for Customer Programs related to current period product revenue. The estimated impact of these programs is recorded as a reduction of transaction price or as an operating expense if the Company receives a distinct good or service from the customer and can reasonably estimate the fair value of that good or service received. Customer Programs require management to estimate the percentage of those programs which will not be claimed in the current period or will not be earned by customers, which is commonly referred to as

[0001032975-25-000029:notes:36]
"breakage." Breakage is estimated based on historical claim experience, the period in which customer claims are expected to be submitted, specific terms and conditions with customers and other factors. The Company accounts for breakage as part of variable consideration, subject to constraint, and records the estimated impact in the same period when revenue is recognized at the expected value. Assessing the period in which claims are expected to be submitted and the relevance of the historical claim experience require significant management judgment to estimate the breakage of Customer Programs in any accounting period.

[0001032975-25-000029:notes:37]
The Company enters into cooperative marketing arrangements with many of its customers and with certain indirect partners, allowing customers to receive a credit equal to a set percentage of their purchases of the Company's products, or a fixed dollar amount for various marketing and incentive programs. The objective of these arrangements is to encourage advertising and promotional events to increase sales of the Company's products.

[0001032975-25-000029:notes:38]
Customer incentive programs include consumer rebates and performance-based incentives. Consumer rebates are offered to the Company's customers and indirect partners at the Company's discretion for the primary benefit of end-users. In addition, the Company offers performance-based incentives to many of its customers and indirect partners based on predetermined performance criteria. At management's discretion, the Company also offers special pricing discounts to certain customers. Special pricing discounts are usually offered only for limited time periods or for sales of selected products to specific indirect partners.

[0001032975-25-000029:notes:39]
Cooperative marketing arrangements and customer incentive programs are considered variable consideration, which the Company estimates and records as a reduction to revenue at the time of sale based on negotiated terms, historical experiences, forecasted incentives, anticipated volume of future purchases, and inventory levels in the channel.

[0001032975-25-000029:notes:40]
The Company has agreements with certain customers that contain terms allowing price protection credits to be issued in the event of a subsequent price reduction. Management's decision to make price reductions is influenced by product life cycle stage, market acceptance of products, the competitive environment, new product introductions and other factors.

[0001032975-25-000029:notes:41]
Accruals for estimated expected future pricing actions and Customer Programs are recognized at the time of sale based on analyses of historical pricing actions by customer and by product, inventories owned by and located at customers, current customer demand, current operating conditions, and other relevant customer and product information, such as stage of product life-cycle.

[0001032975-25-000029:notes:42]
Product return rights vary by customer. Estimates of expected future product returns qualify as variable consideration and are recorded as a reduction of the transaction price of the contract at the time of sale based on an analyses of historical return trends by customer and by product, inventories owned by and located at customers, current customer demand, current operating conditions, and other relevant customer and product information. The Company assesses the estimated asset for recovery value for impairment and adjusts the value of the asset for any impairment. Return trends are influenced by product life cycle status, new product introductions, market acceptance of products, sales levels, product sell-through, the type of customer, seasonality, product quality issues, competitive pressures, operational policies and procedures, and other factors. Return rates can fluctuate over time but are sufficiently predictable to allow the Company to estimate expected future product returns.

[0001032975-25-000029:notes:43]
Typically, variable consideration does not need to be constrained as estimates are based on predictive historical data or future commitments that are planned and controlled by the Company. However, the Company continues to assess variable consideration estimates such that it is probable that a significant reversal of revenue will not occur.

[0001032975-25-000029:notes:44]
The Company regularly evaluates the adequacy of its estimates for Customer Programs and product returns. Future market conditions and product transitions may require the Company to take action to change such programs and related estimates. When the variables used to estimate these costs change, or if actual costs differ significantly from the estimates, the Company would be required to increase or reduce revenue or operating expenses to reflect the impact. During the year ended March 31, 2025, changes to these estimates related to performance obligations satisfied in prior periods were not material.

[0001032975-25-000029:notes:45]
Sales taxes and value-added taxes (“VAT”) collected from customers, if applicable, which are remitted to governmental authorities are not included in revenue, and are reflected as a liability on the consolidated balance sheets.

[0001032975-25-000029:notes:46]
Shipping and Handling Costs

[0001032975-25-000029:notes:47]
The Company's shipping and handling costs are included in the cost of goods sold in the consolidated statements of operations.

[0001032975-25-000029:notes:48]
Contract Balances

[0001032975-25-000029:notes:49]
The Company records accounts receivable from contracts with customers when it has an unconditional right to consideration, as accounts receivable, net, on the consolidated balance sheets.

[0001032975-25-000029:notes:50]
The Company records contract liabilities when cash payments are received or due in advance of performance, primarily for implied support and subscriptions. Contract liabilities are included in accrued and other current liabilities and other non-current liabilities on the consolidated balance sheets.

[0001032975-25-000029:notes:51]
Contract Costs

[0001032975-25-000029:notes:52]
The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that otherwise would have been recognized is one year or less. These costs are included in marketing and selling expenses in the consolidated statements of operations. As of March 31, 2025 and 2024, the Company did not have any material deferred contract costs.

[0001032975-25-000029:notes:53]
Research and Development Costs

[0001032975-25-000029:notes:54]
Costs related to research, design and development of products, which consist primarily of personnel, product design and infrastructure expenses, are charged to research and development expense as they are incurred.

[0001032975-25-000029:notes:55]
Advertising Costs

[0001032975-25-000029:notes:56]
Advertising costs are recorded as either a marketing and selling expense or a deduction from revenue as they are incurred. Advertising costs paid or reimbursed by the Company to direct or indirect customers must have an identifiable benefit and an estimable fair value in order to be classified as an operating expense. If these criteria are not met, the payment is classified as a reduction of revenue. Advertising costs recorded as marketing and selling expense are expensed as incurred. Total advertising costs including those characterized as revenue deductions during fiscal years 2025, 2024 and 2023 were $355.1 million, $325.3 million and $383.7 million, respectively, out of which $53.1 million, $46.6 million, and $67.3 million, respectively, were included as operating expense in the consolidated statements of operations.

[0001032975-25-000029:notes:57]
Cash Equivalents

[0001032975-25-000029:notes:58]
The Company classifies all highly liquid instruments purchased, such as bank demand deposits, short-term time deposits, and U.S. Treasury securities, with an original maturity of three months or less at the date of purchase, to be cash equivalents. Cash equivalents are carried at cost, which approximates their fair value.

[0001032975-25-000029:notes:59]
Concentration of Credit Risk

[0001032975-25-000029:notes:60]
Financial instruments that potentially subject the Company to concentrations of credit risk consist principally of cash and cash equivalents and accounts receivable. The Company maintains cash and cash equivalents with various creditworthy financial institutions and has a policy to limit exposure with any one financial institution, but is exposed to credit risk in the event of default by financial institutions to the extent that cash balances with individual financial institutions are in excess of amounts that are insured. The Company periodically assesses the credit risk associated with these financial institutions.

[0001032975-25-000029:notes:61]
The Company sells to large distributors, retailers, and e-tailers and, as a result, maintains individually significant receivable balances with such customers.

[0001032975-25-000029:notes:62]
The Company had the following customers that individually comprised 10% or more of its gross sales:

[0001032975-25-000029:notes:63]
|  |  | Years Ended March 31, |
|  |  | 2025 |  | 2024 |  | 2023 |
| Customer A |  | 14 | % |  | 13 | % |  | 13 | % |
| Customer B |  | 19 | % |  | 18 | % |  | 19 | % |
| Customer C |  | 12 | % |  | 14 | % |  | 15 | % |

[0001032975-25-000029:notes:64]
The Company had the following customers that individually comprised 10% or more of its accounts receivable:

[0001032975-25-000029:notes:65]
|  |  | March 31, |
|  |  | 2025 |  | 2024 |
| Customer A |  | 14 | % |  | 14 | % |
| Customer B |  | 21 | % |  | 20 | % |
| Customer C |  | 10 | % |  | 15 | % |

[0001032975-25-000029:notes:66]
The Company manages its accounts receivable credit risk through ongoing credit evaluation of its customers' financial conditions. The Company generally does not require collateral from its customers.

[0001032975-25-000029:notes:67]
Allowances for Doubtful Accounts

[0001032975-25-000029:notes:68]
Allowances for doubtful accounts are maintained for expected credit losses resulting from the Company's customers' inability to make required payments. The allowances are based on the Company's regular assessment of various factors, including the credit-worthiness and financial condition of specific customers, historical experience with bad debts and customer deductions, receivables aging, current economic conditions, reasonable and supportable forecasts of future economic conditions, and other factors that may affect the Company's ability to collect from customers.

[0001032975-25-000029:notes:69]
Inventories

[0001032975-25-000029:notes:70]
Inventories are stated at the lower of cost and net realizable value. Costs are computed under the standard cost method, which approximates actual costs determined on the first-in, first-out basis. The Company records write-downs of inventories which are obsolete or in excess of anticipated demand or net realizable value based on a consideration of marketability and product life cycle stage, product development plans, component cost trends, historical sales and demand forecasts which consider the assumptions about future demand and market conditions. Inventory on hand which is not expected to be sold or utilized is considered excess, and the Company recognizes the write-down in cost of goods sold at the time of such determination. The write-down is determined by the excess of cost over net realizable value. Net realizable value is the estimated selling price in the ordinary course of business, less reasonably predictable costs of completion, disposal and transportation. At the time of loss recognition, new cost basis per unit and lower-cost basis for that inventory are established and subsequent changes in facts and circumstances would not result in an increase in the cost basis.

[0001032975-25-000029:notes:71]
The Company recorded liabilities arising from firm, non-cancelable, and unhedged inventory purchase commitments in excess of anticipated demand or net realizable value consistent with its valuation of excess and obsolete inventory. Such liability is included in accrued and other current liabilities on the consolidated balance sheets.

[0001032975-25-000029:notes:72]
Property, Plant and Equipment

[0001032975-25-000029:notes:73]
Property, plant and equipment are stated at cost. Additions and improvements are capitalized, and maintenance and repairs are expensed as incurred. The Company capitalizes the cost of software developed for internal use in connection with major projects. Costs incurred during the preliminary project stage and post implementation stage are expensed, whereas direct costs incurred during the application development stage are capitalized.

[0001032975-25-000029:notes:74]
Depreciation expense is recognized using the straight-line method. Plant and buildings are depreciated over estimated useful lives of twenty-five years, equipment over useful lives from three to five years, internal-use software over useful lives from three to seven years, tooling over useful lives from six months to one year, and leasehold improvements over the lesser of the term of the lease or the estimated useful life of leasehold improvements.

[0001032975-25-000029:notes:75]
When property and equipment is retired or otherwise disposed of, the cost and accumulated depreciation are relieved from the accounts and the net gain or loss is included in cost of goods sold or operating expenses, depending on the nature of the property and equipment.

[0001032975-25-000029:notes:76]
Leases

[0001032975-25-000029:notes:77]
The Company determines if an arrangement is a lease or contains a lease at contract inception. The Company determines if a lease is an operating or finance lease and recognizes right-of-use ("ROU") assets and lease liabilities upon lease commencement. Operating lease ROU assets are included in other assets, short-term lease liabilities are included in accrued and other current liabilities, and long-term lease liabilities are included in other non-current liabilities on the Company's consolidated balance sheets. Leases with an initial term of 12 months or less are not recorded on the balance sheet. For the Company's operating leases, the Company accounts for the lease component and related non-lease component as a single lease component. Lease expense is recognized on a straight-line basis over the lease term.

[0001032975-25-000029:notes:78]
For operating leases, the lease liability is initially measured at the present value of the unpaid lease payments at lease commencement date. As most of the leases do not provide an implicit rate, the Company generally uses its incremental borrowing rate as the discount rate for the leases. The Company's incremental borrowing rate is the rate of interest it would have to pay on a collateralized basis to borrow an amount equal to the lease payments under similar terms. Because the Company does not generally borrow on a collateralized basis, it uses its understanding of what its collateralized credit rating would be as an input to deriving an appropriate incremental borrowing rate. The operating lease ROU assets include prepaid lease payments and exclude lease incentives.

[0001032975-25-000029:notes:79]
Intangible Assets

[0001032975-25-000029:notes:80]
The Company's intangible assets include goodwill and intangible assets with finite lives, which primarily include acquired technology and customer contracts and related relationships. Intangible assets with finite lives are carried at cost and amortized using the straight-line method over their useful lives ranging from one to ten years.

[0001032975-25-000029:notes:81]
Impairment of Long-Lived Assets

[0001032975-25-000029:notes:82]
The Company reviews long-lived assets, such as property and equipment, and finite-lived intangible assets, for impairment whenever events indicate that the carrying amounts might not be recoverable. Recoverability of long-lived assets is measured by comparing the projected undiscounted net cash flows associated with those assets to their carrying values. If an asset is considered impaired, it is written down to its fair value, which is determined based on the asset's projected discounted cash flows or appraised value, depending on the nature of the asset. For purposes of recognition of impairment for assets held for use, the Company groups assets and liabilities at the lowest level for which cash flows are separately identifiable.

[0001032975-25-000029:notes:83]
Impairment of Goodwill

[0001032975-25-000029:notes:84]
Goodwill represents the excess of the purchase price over the fair value of the net tangible and identifiable intangible assets acquired in each business combination. The Company conducts a goodwill impairment analysis annually at December 31 or more frequently if indicators of impairment exist or if a decision is made to sell or exit a business. Significant judgments are involved in determining if an indicator of impairment has occurred. Such indicators may include deterioration in general economic conditions, negative developments in equity and credit markets, adverse changes in the markets in which an entity operates, increases in input costs that have a negative effect on earnings and cash flows, or a trend of negative or declining cash flows over multiple periods, among others. The fair value that could be realized in an actual transaction may differ from that used to evaluate the impairment of goodwill.

[0001032975-25-000029:notes:85]
In reviewing goodwill for impairment, the Company has the option to first assess qualitative factors to determine whether the existence of events or circumstances leads to a determination that it is more likely than not (greater than 50%) that the estimated fair value of a reporting unit is less than its carrying amount. The Company also may elect not to perform the qualitative assessment and, instead, proceed directly to the quantitative impairment test. The ultimate outcome of the goodwill impairment review for a reporting unit should be the same whether the Company chooses to perform the qualitative assessment or proceeds directly to the quantitative impairment test. The Company operates as one reporting unit. For the year ended March 31, 2025, the Company elected to perform a qualitative assessment and concluded that it was more likely than not that the fair value of its reporting unit exceeds its carrying amount.

[0001032975-25-000029:notes:86]
Income Taxes

[0001032975-25-000029:notes:87]
The Company provides for income taxes using the asset and liability method, which requires that deferred tax assets and liabilities be recognized for the expected future tax consequences of temporary differences resulting from differing treatment of items for tax and financial reporting purposes, and for operating losses and tax credit carryforwards. In estimating future tax consequences, expected future events are taken into consideration, with the exception of potential tax law or tax rate changes. The Company records a valuation allowance to reduce deferred tax assets to amounts management believes are more likely than not to be realized.

[0001032975-25-000029:notes:88]
The Company's assessment of uncertain tax positions requires that management makes estimates and judgments about the application of tax law, the expected resolution of uncertain tax positions and other matters. In the event that uncertain tax positions are resolved for amounts different than the Company's estimates, or the related statutes of limitations expire without the assessment of additional income taxes, the Company will be required to adjust the amounts of the related assets and liabilities in the period in which such events occur. Such adjustments may have an impact on the Company's income tax provision and its results of operations.

[0001032975-25-000029:notes:89]
Fair Value of Financial Instruments

[0001032975-25-000029:notes:90]
The carrying value of certain of the Company's financial instruments, including cash equivalents, accounts receivable and accounts payable approximates their fair value due to their short maturities.

[0001032975-25-000029:notes:91]
The Company's investment securities portfolio consists of bank demand deposits, short-term time deposits, and U.S. Treasury securities with an original maturity of three months or less and marketable securities (money market and mutual funds) related to a deferred compensation plan.

[0001032975-25-000029:notes:92]
The Company's investments related to the deferred compensation plan are reported at fair value based on quoted market prices. The marketable securities related to the deferred compensation plan are classified as non-current investments, as they are intended to fund the deferred compensation plan's long-term liability. Participants in the deferred compensation plan may select the mutual funds in which their compensation deferrals are invested within the confines of the Rabbi Trust which holds the marketable securities. These securities are recorded at fair value based on quoted market prices. Earnings, gains and losses on deferred compensation investments are included in other income (expense), net in the consolidated statements of operations.

[0001032975-25-000029:notes:93]
The Company also holds certain non-marketable investments that are accounted for as equity method investments and included in other assets in the consolidated balance sheets. In addition, the Company has certain equity investments without readily determinable fair values due to the absence of quoted market prices, the inherent lack of liquidity, and the fact that inputs used to measure fair value are unobservable and require management's judgment. The Company elected the measurement alternative to record these investments at cost and to adjust for impairments and observable price changes resulting from transactions with the same issuer within the statements of operations.

[0001032975-25-000029:notes:94]
Net Income per Share

[0001032975-25-000029:notes:95]
Basic net income per share is computed by dividing net income by the weighted average outstanding shares. Diluted net income per share is computed using the weighted average outstanding shares and dilutive share equivalents. Dilutive share equivalents consist of share-based awards, including stock options, purchase rights under employee share purchase plan, and restricted stock units.

[0001032975-25-000029:notes:96]
The dilutive effect of in-the-money share-based compensation awards is calculated based on the average share price for each fiscal period using the treasury stock method.

[0001032975-25-000029:notes:97]
Share-Based Compensation Expense

[0001032975-25-000029:notes:98]
Share-based compensation expense includes compensation expense for share-based awards granted based on the grant date fair value. The grant date fair value for stock options and stock purchase rights is estimated using the Black-Scholes-Merton option-pricing valuation model. The grant date fair value of service-based restricted stock units ("RSUs") is calculated based on the market price on the date of grant, reduced by estimated dividend yield prior to vesting. The grant date fair value of restricted stock units which vest upon meeting certain market- and performance-based conditions ("PSUs") is estimated using the Monte-Carlo simulation method including the effect of the market condition. Stock-based compensation expense is recognized ratably over the respective requisite service periods of the awards and forfeitures are accounted for when they occur. For PSUs, the Company recognizes compensation expense using its estimate of probable outcome at the end of the performance period

[0001032975-25-000029:notes:99]
(i.e., the estimated performance against the performance targets). The Company periodically adjusts the cumulative stock-based compensation expense recorded when the probable outcome for the PSUs is updated based upon changes in actual and forecasted financial results.

[0001032975-25-000029:notes:100]
Product Warranty

[0001032975-25-000029:notes:101]
All of the Company's products are covered by standard warranty to be free from defects in material and workmanship for periods ranging from one year to three years. The warranty period varies by product and by region. The Company’s standard warranty does not provide a service beyond assuring that the product complies with agreed-upon specifications and is not sold separately. The standard warranty the Company provides qualifies as an assurance warranty and is not treated as a separate performance obligation. The Company estimates cost of product warranties at the time the related revenue is recognized based on historical warranty claim rates, historical costs, and knowledge of specific product failures that are outside of the Company's typical experience. The Company accrues a warranty liability for estimated costs to provide products, parts or services to repair or replace products in satisfaction of the warranty obligation. Each quarter, the Company re-evaluates its estimates to assess the adequacy of recorded warranty liabilities. When the Company experiences changes in warranty claim activity or costs associated with fulfilling those claims, the warranty liability is adjusted accordingly.

[0001032975-25-000029:notes:102]
Comprehensive Income (Loss)

[0001032975-25-000029:notes:103]
Comprehensive income (loss) is defined as the total change in shareholders' equity during the period other than from transactions with shareholders. Comprehensive income (loss) consists of net income (loss) and other comprehensive income (loss). Other comprehensive income (loss) is comprised of currency translation adjustments from those entities not using the U.S. Dollar as their functional currency, net deferred gains and losses and prior service costs and credits for defined benefit pension plans, and net deferred gains and losses on hedging activity.

[0001032975-25-000029:notes:104]
Treasury Shares

[0001032975-25-000029:notes:105]
The Company periodically repurchases shares in the market at fair value. Shares repurchased are recorded at cost as a reduction of total shareholders' equity. Treasury shares held may be reissued to satisfy the exercise of employee stock options and purchase rights, the vesting of restricted stock units, and acquisitions, or may be canceled with shareholder approval. Treasury shares that are reissued are accounted for using the first-in, first-out basis.

[0001032975-25-000029:notes:106]
When treasury shares are reissued, gains from re-issuance of treasury shares are credited to additional paid-in capital while losses from re-issuance of treasury shares are charged to additional paid-in capital to the extent that there are previously recorded gains to offset the losses, otherwise charged to retained earnings in the consolidated balance sheets. When treasury shares are canceled, the Company deducts the par value from registered shares and reflects the excess of share repurchase cost over par value as a reduction to retained earnings.

[0001032975-25-000029:notes:107]
Derivative Financial Instruments

[0001032975-25-000029:notes:108]
The Company enters into foreign exchange forward contracts to reduce the short-term effects of currency fluctuations on certain foreign currency receivables or payables and to hedge against exposure to changes in currency exchange rates related to its subsidiaries' forecasted inventory purchases.

[0001032975-25-000029:notes:109]
Gains or losses from changes in the fair value of forward contracts that offset transaction losses or gains on foreign currency receivables or payables are recognized immediately and included in other income (expense), net in the consolidated statements of operations.

[0001032975-25-000029:notes:110]
Gains and losses for changes in the fair value of the effective portion of the Company's forward contracts related to forecasted inventory purchases are deferred as a component of accumulated other comprehensive gain (loss) until the hedged inventory purchases are sold, at which time the gains or losses are reclassified to cost of goods sold. The Company presents the earnings impact from forward points in the same line item that is used to present the earnings impact of the hedged item (i.e. cost of goods sold) for hedging forecasted inventory purchases.

[0001032975-25-000029:notes:111]
Restructuring Charges

[0001032975-25-000029:notes:112]
The Company's restructuring charges consist of employee severance, one-time termination benefits and ongoing benefits related to the reduction of its workforce, and other costs. Liabilities for costs associated with a restructuring activity are measured at fair value and are recognized when the liability is incurred, as opposed to when management commits to a restructuring plan. One-time termination benefits are expensed at the date the entity notifies the employee, unless the employee must provide future service, in which case the benefits are

[0001032975-25-000029:notes:113]
expensed ratably over the future service period. Ongoing benefits are expensed when restructuring activities are probable and the benefit amounts are estimable. Other costs primarily consist of legal, consulting, and other costs related to employee terminations, and are expensed when incurred. Termination benefits are calculated based on regional benefit practices and local statutory requirements.

[0001032975-25-000029:notes:114]
Recent Accounting Pronouncements Adopted

[0001032975-25-000029:notes:115]
In November 2023, the Financial Accounting Standard Board ("FASB") issued Accounting Standards Update ("ASU") 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures. ASU 2023-07 improves reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses that are regularly provided to the chief operating decision maker. In addition, ASU 2023-07 requires that all existing annual disclosures about segment profit or loss must be provided on an interim basis and clarifies that single reportable segment entities are subject to the disclosure requirement under Topic 280 in its entirety. The Company has adopted this standard for its fiscal year 2025 annual financial statements and interim financial statements thereafter and has applied the standard retrospectively to all prior periods presented in the financial statements. See Note 15 for further information.

[0001032975-25-000029:notes:116]
New Accounting Pronouncements Not Yet Adopted

[0001032975-25-000029:notes:117]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures. ASU 2023-09 requires additional disclosures related to rate reconciliation, income taxes paid, and other disclosures. Under ASU 2023-09, for each annual period presented, public entities are required to (1) disclose specific categories in the tabular rate reconciliation and (2) provide additional information for reconciling items that meet a quantitative threshold. In addition, ASU 2023-09 requires all reporting entities to disclose on an annual basis the amount of income taxes paid disaggregated by federal, state, and foreign taxes as well as the amount of income taxes paid by individual jurisdiction. ASU 2023-09 is effective for public business entities for annual periods beginning after December 15, 2024 and can be applied on a prospective basis with an option to apply the standard retrospectively. Early adoption is permitted. The Company is currently evaluating the impact of ASU 2023-09 on its consolidated financial statements and related disclosures.

[0001032975-25-000029:notes:118]
In November 2024, the FASB issued ASU 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses. ASU 2024-03 requires all public entities to disclose in the notes to the financial statements the amounts of purchases of inventory, employee compensation, depreciation, and intangible asset amortization included in each expense caption of the income statement. ASU 2024-03 is effective for fiscal years beginning after December 15, 2026 and interim periods within fiscal years beginning after December 15, 2027. ASU 2024-03 can be applied either prospectively or retrospectively. Early adoption is permitted. The Company is currently evaluating the impact of ASU 2024-03 on its consolidated financial statements and related disclosures.


## us-gaap:EarningsPerShareTextBlock

[0001032975-25-000029:notes:119]
Net Income Per Share 
The following table summarizes the computations of basic and diluted net income per share for fiscal years 2025, 2024 and 2023 (in thousands except per share amounts):

[0001032975-25-000029:notes:120]
|  |  | Years Ended March 31, |
|  |  | 2025 |  | 2024 |  | 2023 |
| Net income |  | $ | 631,529 |  |  | $ | 612,143 |  |  | $ | 364,575 |  |
| Shares used in net income per share computation: |  |  |  |  |  |  |
| Weighted average shares outstanding - basic |  | 151,322 |  |  | 156,776 |  |  | 162,302 |  |
| Effect of potentially dilutive equivalent shares |  | 1,462 |  |  | 1,395 |  |  | 1,402 |  |
| Weighted average shares outstanding - diluted |  | 152,784 |  |  | 158,171 |  |  | 163,704 |  |
| Net income per share: |  |  |  |  |  |  |
| Basic |  | $ | 4.17 |  |  | $ | 3.90 |  |  | $ | 2.25 |  |
| Diluted |  | $ | 4.13 |  |  | $ | 3.87 |  |  | $ | 2.23 |  |

[0001032975-25-000029:notes:121]
Share equivalents attributable to outstanding stock options, restricted stock units and employee share purchase plans ("ESPP") totaling 0.7 million, 1.1 million, and 2.0 million shares during fiscal years 2025, 2024 and 2023, respectively, were excluded from the calculation of diluted net income per share because their effect would have been antidilutive. A small number of PSUs were not included in the dilutive net income per share calculation because all necessary conditions had not been satisfied by the end of the respective period, and those shares were not issuable if the end of the reporting period were the end of the performance contingency period.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001032975-25-000029:notes:122]
Employee Stock-Based Compensation 
As of March 31, 2025, the Company offers the 2006 Employee Share Purchase Plan (Non-U.S.), as amended and restated ("2006 ESPP"), the 1996 Employee Share Purchase Plan (U.S.), as amended and restated ("1996 ESPP"), and the 2006 Stock Incentive Plan ("2006 Plan") as amended and restated. Shares issued to employees as a result of purchases or exercises under these plans are generally issued from shares held in treasury stock.

[0001032975-25-000029:notes:123]
Under the 1996 ESPP and 2006 ESPP plans, eligible employees may purchase shares at the lower of 85% of the fair market value at the beginning or the end of each offering period, which is generally six months. Subject to continued participation in these plans, purchase agreements are automatically executed at the end of each offering period. An aggregate of 29.0 million shares were reserved for issuance under the 1996 and 2006 ESPP plans. As of March 31, 2025, a total of 2.8 million shares were available for new awards under these plans.

[0001032975-25-000029:notes:124]
The 2006 Plan provides for the grant to eligible employees and non-employee directors of stock options, stock appreciation rights, and restricted stock units. Awards under the 2006 Plan may be conditioned on continued employment, the passage of time or the satisfaction of performance and market vesting criteria. The 2006 Plan, as amended, has no expiration date. On June 29, 2022, the Board authorized 3.3 million additional shares for issuance under the 2006 Plan. An aggregate of 33.8 million shares were reserved for issuance under the 2006 Plan. As of March 31, 2025, a total of 7.2 million shares were available for new awards under this plan.

[0001032975-25-000029:notes:125]
Stock options granted to employees under the 2006 Plan have terms not exceeding ten years and are issued at exercise prices not less than the fair market value on the date of grant.

[0001032975-25-000029:notes:126]
Service-based restricted stock units ("RSUs") granted to employees under the 2006 Plan generally vest in four equal annual installments on the grant date anniversary. RSUs granted to non-executive board members under the 2006 Plan vest on the grant date anniversary, or earlier on the date of the next annual general meeting following the grant date if the non-executive board member is not re-elected as a director at the annual general meeting.

[0001032975-25-000029:notes:127]
Restricted stock units with certain market- and performance-based conditions ("PSUs") granted to employees under the 2006 Plan generally vest at the end of the three-year performance period upon meeting predetermined financial metrics over three years, with the number of shares to be received upon vesting determined based on constant currency revenue growth rate, adjusted operating income (loss) and the Company's total shareholder return ("TSR") relative to the performance of companies in the Russell 3000 Index over the same three years period.

[0001032975-25-000029:notes:128]
The following table summarizes share-based compensation expense and total income tax benefit recognized for fiscal years 2025, 2024 and 2023 (in thousands):

[0001032975-25-000029:notes:129]
|  |  | Years Ended March 31, |
|  |  | 2025 |  | 2024 |  | 2023 |
| Cost of goods sold |  | $ | 10,021 |  |  | $ | 8,004 |  |  | $ | 5,635 |  |
| Marketing and selling |  | 40,378 |  |  | 35,780 |  |  | 34,707 |  |
| Research and development |  | 20,180 |  |  | 17,836 |  |  | 15,292 |  |
| General and administrative |  | 19,334 |  |  | 21,269 |  |  | 15,148 |  |
| Total share-based compensation expense |  | 89,913 |  |  | 82,889 |  |  | 70,782 |  |
| Income tax benefit |  | (20,148) |  |  | (15,305) |  |  | (9,750) |  |
| Total share-based compensation expense, net of income tax benefit |  | $ | 69,765 |  |  | $ | 67,584 |  |  | $ | 61,032 |  |

[0001032975-25-000029:notes:130]
The income tax benefit in the respective periods primarily consisted of tax benefits related to the share-based compensation expense for the period and direct tax benefit realized, including net excess tax benefits recognized from share-based awards vested or exercised during the period.

[0001032975-25-000029:notes:131]
Share-based compensation costs capitalized as part of inventory were $7.6 million, $6.3 million, and $5.6 million for the fiscal year ended March 31, 2025, 2024 and 2023, respectively.

[0001032975-25-000029:notes:132]
As of March 31, 2025, there was $129.5 million of total future stock-based compensation cost to be recognized over a weighted-average period of 2.3 years.

[0001032975-25-000029:notes:133]
The estimates of share-based compensation expense require a number of complex and subjective assumptions including stock price volatility, employee exercise patterns, probability of achievement of the set performance condition, dividend yield, related tax effects and the selection of an appropriate fair value model.

[0001032975-25-000029:notes:134]
The grant date fair value of the ESPP using the Black-Scholes-Merton option-pricing valuation model and the grant date fair value of the PSUs using the Monte-Carlo simulation method are determined with the following assumptions:

[0001032975-25-000029:notes:135]
|  |  |  | Employee Stock Purchase Plans |
|  |  |  | Years Ended March 31, |
|  |  |  | 2025 |  | 2024 |  | 2023 |
| Expected dividend rate |  |  | 1.35% |  | 1.61% |  | 1.78% |
| Risk-free interest rate |  |  | 4.71% |  | 5.36% |  | 3.86% |
| Expected volatility |  |  | 29% |  | 33% |  | 46% |
| Expected term (years) |  |  | 0.5 |  | 0.5 |  | 0.5 |
| Weighted average grant date fair value per share |  |  | $21.74 |  | $19.02 |  | $16.32 |

[0001032975-25-000029:notes:136]
| PSUs |  | Years Ended March 31, |
|  |  | 2025 |  | 2024 |  | 2023 |
| Expected dividend rate |  | 1.41% |  | 1.90% |  | 1.46% |
| Risk-free interest rate |  | 4.55% |  | 3.83% |  | 2.78% |
| Expected volatility |  | 38% |  | 41% |  | 39% |
| Expected term (years) |  | 3.0 |  | 3.0 |  | 3.0 |

[0001032975-25-000029:notes:137]
The expected dividend rate assumption is based on the Company's history and future expectations of dividend payouts. Unvested PSUs are not eligible for these dividends. The expected term is based on the purchase offerings periods expected to remain outstanding for employee stock purchase plan or the performance period for PSUs. Expected volatility is based on historical volatility using the Company's daily closing prices, or including the volatility of components of the Russell 3000 Index for PSUs, over the expected term. The Company considers the historical price volatility of its shares as most representative of future volatility. The risk-free interest rate assumptions are based upon the implied yield of U.S. Treasury zero-coupon issues or Switzerland government bonds appropriate for the expected term of the Company's share-based awards.

[0001032975-25-000029:notes:138]
For PSUs, the Company estimates the probability and timing of the achievement of the set performance condition at the time of the grant based on the historical financial performance and the financial forecast in the remaining performance period and reassesses the probability in subsequent periods when actual results or new information become available.

[0001032975-25-000029:notes:139]
A summary of the Company's stock option activities under all stock plans for fiscal years 2025, 2024 and 2023 is as follows:

[0001032975-25-000029:notes:140]
|  |  | Number of Shares |  | Weighted-Average Exercise Price |  | Weighted-Average Remaining Contractual Term |  | Aggregate Intrinsic Value |  |  |  |  |
|  |  | (In thousands) |  |  |  | (Years) |  | (In thousands) |  |  |  |  |
| Outstanding, March 31, 2022 |  | 1,393 |  |  |  |  |  |  |  |  |  |  |  |
| Exercised |  | (155) |  |  |  |  |  |  | $ | 6,482 |  |  |  |  |  |
| Forfeited |  | (118) |  |  |  |  |  |  |  |  |  |  |  |
| Outstanding, March 31, 2023 |  | 1,120 |  |  |  |  |  |  |  |  |  |  |  |
| Exercised |  | (181) |  |  |  |  |  |  | $ | 6,160 |  |  |  |  |  |
| Forfeited |  | (176) |  |  |  |  |  |  |  |  |  |  |  |
| Outstanding, March 31, 2024 |  | 763 |  |  | $ | 68 |  |  | 7.0 |  | $ | 16,243 |  |  |  |  |  |
| Exercised |  | (111) |  |  | $ | 80 |  |  |  |  | $ | 1,483 |  |  |  |  |  |
| Forfeited |  | (65) |  |  | $ | 80 |  |  |  |  |  |  |  |  |  |
| Outstanding, March 31, 2025 |  | 587 |  |  | $ | 64 |  |  | 5.3 |  | $ | 11,768 |  |  |  |  |  |
| Vested and exercisable, March 31, 2025 |  | 587 |  |  | $ | 64 |  |  | 5.3 |  | $ | 11,768 |  |  |  |  |  |

[0001032975-25-000029:notes:141]
A summary of the Company's RSU and PSU activities for fiscal years 2025, 2024 and 2023 is as follows:

[0001032975-25-000029:notes:142]
|  |  | Number of Shares |  | Weighted-Average Grant Date Fair Value |  | Aggregate Fair Value |  |  |  |  |
|  |  | (In thousands) |  |  |  | (In thousands) |  |  |  |  |
| Outstanding, March 31, 2022 |  | 3,046 |  |  | $ | 68 |  |  |  |  |  |  |  |
| Granted—RSUs |  | 1,584 |  |  | $ | 53 |  |  |  |  |  |  |  |
| Granted—PSUs |  | 407 |  |  | $ | 69 |  |  |  |  |  |  |  |
| Vested |  | (1,143) |  |  |  |  | $ | 85,152 |  |  |  |  |  |
| Forfeited |  | (438) |  |  |  |  |  |  |  |  |  |
| Outstanding, March 31, 2023 |  | 3,456 |  |  | $ | 66 |  |  |  |  |  |  |  |
| Granted—RSUs |  | 1,396 |  |  | $ | 59 |  |  |  |  |  |  |  |
| Granted—PSUs |  | 457 |  |  | $ | 67 |  |  |  |  |  |  |  |
| Vested |  | (1,200) |  |  |  |  | $ | 92,340 |  |  |  |  |  |
| Forfeited |  | (631) |  |  |  |  |  |  |  |  |  |
| Outstanding, March 31, 2024 |  | 3,478 |  |  | $ | 65 |  |  |  |  |  |  |  |
| Granted—RSUs |  | 931 |  |  | $ | 93 |  |  |  |  |  |  |  |
| Granted—PSUs |  | 281 |  |  | $ | 91 |  |  |  |  |  |  |  |
| Vested |  | (1,172) |  |  | $ | 65 |  |  | $ | 113,553 |  |  |  |  |  |
| Forfeited |  | (462) |  |  | $ | 85 |  |  |  |  |  |  |  |
| Outstanding, March 31, 2025 |  | 3,056 |  |  | $ | 73 |  |  |  |  |  |  |  |

[0001032975-25-000029:notes:143]
The shares outstanding as of March 31, 2025 above include 0.7 million shares of PSUs. The Company presents the number of PSUs and weighted-average grant date fair value at 100 percent of the performance target; however, the aggregate fair value of shares vested is based on the actual number of PSUs vested according to achievement of the financial metrics over the performance period.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001032975-25-000029:notes:144]
Employee Benefit Plans
Defined Benefit Plans

[0001032975-25-000029:notes:145]
Certain subsidiaries of the Company sponsor defined benefit pension plans or non-retirement post-employment benefits covering substantially all of their employees. Benefits are provided based on employees' years

[0001032975-25-000029:notes:146]
of service and earnings, or in accordance with applicable employee benefit regulations. The Company's practice is to fund amounts sufficient to meet the requirements set forth in the applicable employee benefit and tax regulations.

[0001032975-25-000029:notes:147]
The Company recognizes the overfunded or underfunded status of defined benefit pension plans and non-retirement post-employment benefit obligations as an asset or liability in its consolidated balance sheets and recognizes changes in the funded status of defined benefit pension plans in the year in which the changes occur through accumulated other comprehensive income (loss), which is a component of shareholders' equity. Each plan's assets and benefit obligations are generally remeasured as of March 31 each year.

[0001032975-25-000029:notes:148]
The net periodic benefit cost of the defined benefit pension plans and the non-retirement post-employment benefit obligations for fiscal years 2025, 2024 and 2023 was as follows (in thousands):

[0001032975-25-000029:notes:149]
|  |  | Years Ended March 31, |
|  |  | 2025 |  | 2024 |  | 2023 |
| Service costs |  | $ | 11,875 |  |  | $ | 11,479 |  |  | $ | 13,195 |  |
| Interest costs |  | 3,298 |  |  | 3,844 |  |  | 2,408 |  |
| Expected return on plan assets |  | (7,671) |  |  | (6,950) |  |  | (3,754) |  |
| Amortization: |  |  |  |  |  |  |
| Net prior service cost (credit) recognized |  | 309 |  |  | (500) |  |  | (458) |  |
| Net actuarial loss (gain) recognized |  | 450 |  |  | (179) |  |  | (3,047) |  |
| Curtailment gain |  | — |  |  | — |  |  | (4,225) |  |
| Settlement loss (gain) |  | — |  |  | 922 |  |  | (339) |  |
| Total net periodic benefit cost |  | $ | 8,261 |  |  | $ | 8,616 |  |  | $ | 3,780 |  |

[0001032975-25-000029:notes:150]
The components of net periodic benefit cost other than the service costs component are included in other income (expense), net in the consolidated statements of operations.

[0001032975-25-000029:notes:151]
The changes in projected benefit obligations for fiscal years 2025 and 2024 were as follows (in thousands):

[0001032975-25-000029:notes:152]
|  |  | Years Ended March 31, |
|  |  | 2025 |  | 2024 |
| Projected benefit obligations, beginning of the year |  | $ | 213,477 |  |  | $ | 195,336 |  |
| Service costs |  | 11,875 |  |  | 11,479 |  |
| Interest costs |  | 3,298 |  |  | 3,844 |  |
| Plan participant contributions |  | 6,676 |  |  | 6,731 |  |
| Actuarial loss |  | 13,691 |  |  | 13,737 |  |
| Benefits paid |  | (10,578) |  |  | (2,405) |  |
| Transfer of prior vested benefits |  | 15,301 |  |  | 6,775 |  |
| Plan amendments |  | 909 |  |  | 380 |  |
| Settlement |  | — |  |  | (22,522) |  |
| Administrative expense paid |  | (157) |  |  | (158) |  |
| Currency exchange rate changes |  | 4,649 |  |  | 280 |  |
| Projected benefit obligations, end of the year |  | $ | 259,141 |  |  | $ | 213,477 |  |

[0001032975-25-000029:notes:153]
The accumulated benefit obligation for all defined benefit pension plans as of March 31, 2025 and 2024 was $227.7 million and $184.8 million, respectively.

[0001032975-25-000029:notes:154]
Actuarial loss related to the change in the benefit obligation for the Company's pension plans for fiscal years 2025 and 2024 were primarily due to changes in discount rate.

[0001032975-25-000029:notes:155]
The changes in the fair value of plan assets for fiscal years 2025 and 2024 were as follows (in thousands):

[0001032975-25-000029:notes:156]
|  |  | Years Ended March 31, |
|  |  | 2025 |  | 2024 |
| Fair value of plan assets, beginning of the year |  | $ | 170,640 |  |  | $ | 162,599 |  |
| Actual return on plan assets |  | 5,076 |  |  | 7,558 |  |
| Employer contributions |  | 10,351 |  |  | 10,888 |  |
| Plan participant contributions |  | 6,676 |  |  | 6,731 |  |
| Benefits paid |  | (10,578) |  |  | (2,405) |  |
| Transfer of prior vested benefits |  | 15,301 |  |  | 6,775 |  |
| Settlement |  | — |  |  | (22,522) |  |
| Administrative expenses paid |  | (157) |  |  | (158) |  |
| Currency exchange rate changes |  | 4,150 |  |  | 1,174 |  |
| Fair value of plan assets, end of the year |  | $ | 201,459 |  |  | $ | 170,640 |  |

[0001032975-25-000029:notes:157]
The Company's investment objectives are to ensure that the assets of its defined benefit plans are invested to provide an optimal rate of investment return on the total investment portfolio, consistent with the assumption of a reasonable risk level, and to ensure that pension funds are available to meet the plans' benefit obligations as they become due. The Company believes that a well-diversified investment portfolio will result in the highest attainable investment return with an acceptable level of overall risk. Investment strategies and allocation decisions are also governed by applicable governmental regulatory agencies. The Company's investment strategy with respect to its largest defined benefit plan, which is available only to Swiss employees, is to invest per the following allocation: 33% in equities, 28% in bonds, 28% in real estate, 4% in cash and cash equivalents and the remaining in other investments. The Company can invest in real estate funds, commodity funds, and hedge funds depending upon economic conditions.

[0001032975-25-000029:notes:158]
The following tables present the fair value of the defined benefit pension plan assets by major categories and by levels within the fair value hierarchy as of March 31, 2025 and 2024 (in thousands):

[0001032975-25-000029:notes:159]
|  |  | March 31, |
|  |  | 2025 |  | 2024 |
|  |  | Level 1 |  | Level 2 |  |  |  | Total |  | Level 1 |  | Level 2 |  |  |  | Total |
| Cash and cash equivalents |  | $ | 21,202 |  |  | $ | — |  |  |  |  | $ | 21,202 |  |  | $ | 14,375 |  |  | $ | — |  |  |  |  | $ | 14,375 |  |
| Equity securities |  | 60,867 |  |  | — |  |  |  |  | 60,867 |  |  | 54,534 |  |  | — |  |  |  |  | 54,534 |  |
| Debt securities |  | 50,178 |  |  | — |  |  |  |  | 50,178 |  |  | 42,153 |  |  | — |  |  |  |  | 42,153 |  |
| Real estate funds |  | 44,906 |  |  | 6,833 |  |  |  |  | 51,739 |  |  | 32,286 |  |  | 10,141 |  |  |  |  | 42,427 |  |
| Hedge funds |  | — |  |  | 8,994 |  |  |  |  | 8,994 |  |  | — |  |  | 10,400 |  |  |  |  | 10,400 |  |
| Other |  | 8,005 |  |  | 474 |  |  |  |  | 8,479 |  |  | 6,335 |  |  | 416 |  |  |  |  | 6,751 |  |
| Total fair value of plan assets |  | $ | 185,158 |  |  | $ | 16,301 |  |  |  |  | $ | 201,459 |  |  | $ | 149,683 |  |  | $ | 20,957 |  |  |  |  | $ | 170,640 |  |

[0001032975-25-000029:notes:160]
The funded status of the plans was as follows (in thousands):

[0001032975-25-000029:notes:161]
|  |  | Years Ended March 31, |
|  |  | 2025 |  | 2024 |
| Fair value of plan assets |  | $ | 201,459 |  |  | $ | 170,640 |  |
| Less: projected benefit obligations |  | 259,141 |  |  | 213,477 |  |
| Underfunded status |  | $ | (57,682) |  |  | $ | (42,837) |  |

[0001032975-25-000029:notes:162]
Amounts recognized on the balance sheets for the plans were as follows (in thousands):

[0001032975-25-000029:notes:163]
|  |  | March 31, |
|  |  | 2025 |  | 2024 |
| Current liabilities |  | $ | 1,728 |  |  | $ | 1,391 |  |
| Non-current liabilities |  | 55,954 |  |  | 41,446 |  |
| Total liabilities |  | $ | 57,682 |  |  | $ | 42,837 |  |

[0001032975-25-000029:notes:164]
Amounts recognized in accumulated other comprehensive income (loss) related to defined benefit pension plans were as follows (in thousands):

[0001032975-25-000029:notes:165]
|  |  | March 31, |
|  |  | 2025 |  | 2024 |  |  |
| Net prior service credits |  | $ | 820 |  |  | $ | 1,385 |  |  |  |
| Net actuarial loss |  | (22,696) |  |  | (6,445) |  |  |  |
| Accumulated other comprehensive loss |  | (21,876) |  |  | (5,060) |  |  |  |
| Deferred taxes |  | (3,400) |  |  | (3,335) |  |  |  |
| Accumulated other comprehensive loss, net of tax |  | $ | (25,276) |  |  | $ | (8,395) |  |  |  |

[0001032975-25-000029:notes:166]
The actuarial assumptions for the defined benefit plans were as follows:

[0001032975-25-000029:notes:167]
|  |  | Years Ended March 31, |
|  |  | 2025 |  | 2024 |
| Benefit Obligations: |  |  |  |  |
| Discount rate |  | 1.20%- 6.50% |  | 1.50% - 7.00% |
| Estimated rate of compensation increase |  | 2.00% - 10.00% |  | 2.25% - 10.00% |
| Cash balance interest credit rate |  | 0.75% - 1.75% |  | 0.50% - 1.75% |

[0001032975-25-000029:notes:168]
|  |  | Years Ended March 31, |
|  |  | 2025 |  | 2024 |  | 2023 |
| Net Periodic Costs: |  |  |  |  |  |  |
| Discount rate |  | 1.50% - 7.00% |  | 1.50% - 7.25% |  | 0.50% - 6.75% |
| Estimated rate of compensation increase |  | 2.25% - 10.00% |  | 2.25% - 10.00% |  | 2.00% - 10.00% |
| Expected average rate of return on plan assets |  | 1.00% - 5.25% |  | 0.50% - 4.50% |  | 1.00% - 2.50% |
| Cash balance interest credit rate |  | 0.50% - 1.75% |  | 0.50% - 1.75% |  | 0.00% - 1.75% |

[0001032975-25-000029:notes:169]
The discount rate is estimated based on corporate bond yields or securities of similar quality in the respective country, with a duration approximating the period over which the benefit obligations are expected to be paid. The Company bases the compensation increase assumptions on historical experience and future expectations. The expected average rate of return for the Company's defined benefit pension plans represents the average rate of return expected to be earned on plan assets over the period that the benefit obligations are expected to be paid, based on government bond notes in the respective country, adjusted for corporate risk premiums as appropriate.

[0001032975-25-000029:notes:170]
The following table reflects the benefit payments that the Company expects the plans to pay in the periods noted (in thousands):

[0001032975-25-000029:notes:171]
| Years Ending March 31, |  |  |
| 2026 |  | $ | 14,523 |  |
| 2027 |  | 16,691 |  |
| 2028 |  | 14,645 |  |
| 2029 |  | 14,802 |  |
| 2030 |  | 14,616 |  |
| Next five fiscal years |  | 77,365 |  |
| Total expected benefit payments by the plan |  | $ | 152,642 |  |

[0001032975-25-000029:notes:172]
The Company expects to contribute $8.0 million to its defined benefit pension plans during fiscal year 2026.

[0001032975-25-000029:notes:173]
Defined Contribution Plans

[0001032975-25-000029:notes:174]
Certain of the Company's subsidiaries have defined contribution employee benefit plans covering all or a portion of their employees. Contributions to these plans are discretionary for certain plans and are based on specified or statutory requirements for others. The charges to expense for these plans for fiscal years 2025, 2024 and 2023, were $13.7 million, $14.4 million and $14.4 million, respectively.

[0001032975-25-000029:notes:175]
Deferred Compensation Plan

[0001032975-25-000029:notes:176]
One of the Company's subsidiaries offers a deferred compensation plan that permits eligible employees to make 100% vested salary and incentive compensation deferrals within established limits. The Company does not make contributions to the plan.

[0001032975-25-000029:notes:177]
The deferred compensation plan's assets consist of marketable securities and are included in other assets on the consolidated balance sheets. The marketable securities were recorded at a fair value of $29.0 million and $29.2 million as of March 31, 2025 and 2024, respectively, based on quoted market prices (see Note 9). The Company also had deferred compensation liability of $29.0 million and $29.2 million, which are included in other non-current liabilities on the consolidated balance sheets as of March 31, 2025 and 2024, respectively. Earnings, gains and losses on deferred compensation investments are included in other income (expense), net (see Note 6) and corresponding changes in deferred compensation liability are included in operating expenses and cost of goods sold in the consolidated statements of operations.


## us-gaap:InterestAndOtherIncomeTextBlock

[0001032975-25-000029:notes:178]
Other Income (Expense), Net
Other income (expense), net, comprises the following (in thousands):

[0001032975-25-000029:notes:179]
|  |  | Years Ended March 31, |
|  |  | 2025 |  | 2024 |  | 2023 |
| Investment gain (loss) related to the deferred compensation plan |  | $ | 2,131 |  |  | $ | 4,320 |  |  | $ | (1,961) |  |
| Currency exchange loss, net |  | (6,401) |  |  | (8,770) |  |  | (7,337) |  |
| Loss on investments, net (1) |  | (2,029) |  |  | (14,674) |  |  | (14,073) |  |
| Non-service cost net pension income and other (2) |  | 3,319 |  |  | 2,748 |  |  | 10,093 |  |
| Other income (expense), net |  | $ | (2,980) |  |  | $ | (16,376) |  |  | $ | (13,278) |  |

[0001032975-25-000029:notes:180]
(1) Includes unrealized gain (loss) from the change in fair value of investments, income (loss) on equity-method investments, and impairment of investments during the periods presented, as applicable (see Note 9).

[0001032975-25-000029:notes:181]
(2) Includes the components of net periodic benefit cost of defined benefit plans other than the service cost component (see Note 5).


## us-gaap:IncomeTaxDisclosureTextBlock

[0001032975-25-000029:notes:182]
Income Taxes 
The Company is incorporated in Switzerland but operates in various countries with differing tax laws and rates. Further, a portion of the Company's income before taxes and the provision for income taxes is generated outside of Switzerland.

[0001032975-25-000029:notes:183]
Income from continuing operations before income taxes for fiscal years 2025, 2024 and 2023 is summarized as follows (in thousands):

[0001032975-25-000029:notes:184]
|  |  | Years Ended March 31, |
|  |  | 2025 |  | 2024 |  | 2023 |
| Swiss |  | $ | 492,941 |  |  | $ | 502,291 |  |  | $ | 282,970 |  |
| Non-Swiss |  | 213,931 |  |  | 119,305 |  |  | 180,552 |  |
| Income before taxes |  | $ | 706,872 |  |  | $ | 621,596 |  |  | $ | 463,522 |  |

[0001032975-25-000029:notes:185]
The provision for income taxes is summarized as follows (in thousands):

[0001032975-25-000029:notes:186]
|  |  | Years Ended March 31, |
|  |  | 2025 |  | 2024 |  | 2023 |
| Current: |  |  |  |  |  |  |
| Swiss |  | $ | (14,673) |  |  | $ | 26,833 |  |  | $ | 19,405 |  |
| Non-Swiss |  | 33,473 |  |  | 25,044 |  |  | 48,829 |  |
| Deferred: |  |  |  |  |  |  |
| Swiss |  | 45,283 |  |  | (47,517) |  |  | 26,629 |  |
| Non-Swiss |  | 11,260 |  |  | 5,093 |  |  | 4,085 |  |
| Provision for income taxes |  | $ | 75,343 |  |  | $ | 9,453 |  |  | $ | 98,947 |  |

[0001032975-25-000029:notes:187]
The difference between the provision for income taxes and the expected tax provision at the Swiss statutory income tax rate of 8.5% is reconciled below (in thousands):

[0001032975-25-000029:notes:188]
|  |  | Years Ended March 31, |
|  |  | 2025 |  | 2024 |  | 2023 |
| Expected tax provision at statutory income tax rates |  | $ | 60,084 |  |  | $ | 52,836 |  |  | $ | 39,399 |  |
| Income taxes at different rates |  | 68,212 |  |  | 47,595 |  |  | 38,467 |  |
| Research and development tax credits |  | (6,797) |  |  | (9,738) |  |  | (152) |  |
| Swiss Tax Benefits |  | — |  |  | (50,051) |  |  | — |  |
| Executive compensation |  | 980 |  |  | 407 |  |  | 749 |  |
| Stock-based compensation |  | (2,162) |  |  | 4,019 |  |  | 5,736 |  |
| Deferred tax effects from TRAF |  | — |  |  | (33,926) |  |  | — |  |
| Valuation allowance |  | 1,000 |  |  | 4,780 |  |  | 908 |  |
| Impairment |  | — |  |  | — |  |  | 1,881 |  |
| Restructuring credits |  | (817) |  |  | — |  |  | (1,764) |  |
| Unrecognized tax benefits/ Audit resolution and statute lapse |  | (43,333) |  |  | 11,535 |  |  | 13,284 |  |
| FDII deduction |  | (1,424) |  |  | (18,675) |  |  | — |  |
| Other, net |  | (400) |  |  | 671 |  |  | 439 |  |
| Provision for income taxes |  | $ | 75,343 |  |  | $ | 9,453 |  |  | $ | 98,947 |  |

[0001032975-25-000029:notes:189]
The effective income tax rate in 2025 includes the tax effect of audit resolutions and the expiration of statutes of limitation of uncertain tax positions totaling $53.3 million, offset by the increase to unrecognized tax benefits in 2025 of $10.0 million. The effective tax rate in 2024 includes the discrete tax benefits recognized in fiscal year 2024 for the benefit of future Swiss tax deductions, the remeasurement of the tax basis of goodwill under TRAF (as defined below), FDII (as defined below) incentive provided by the Tax Cuts and Jobs Act and remeasurement of our Swiss deferred tax assets due to a change in tax rate.

[0001032975-25-000029:notes:190]
On March 28, 2024, the Swiss canton of Vaud confirmed a future tax benefit to be recognized for ten years. This resulted in the Company recording an income tax benefit of $50.1 million during the fiscal year ended March 31, 2024, which will be utilized over a ten-year period.

[0001032975-25-000029:notes:191]
The canton of Vaud completed the legislative process to enact the Swiss Federal Act on Tax Reform and AHV Financing (“TRAF”), a reform to better align the Swiss tax system to international tax standards on March 20, 2020 that took effect as of January 1, 2020. In March 2020, the Company increased the tax basis of goodwill, as a transition measure under TRAF, to be amortized over ten years beginning on January 1, 2020. During the fiscal year ended March 31, 2024, the Company remeasured the tax basis of goodwill under TRAF, which resulted in an income tax benefit of $25.1 million, net of assessment for uncertain tax positions. The remeasurement of the step-up will be amortized over the remaining ten-year amortization period.

[0001032975-25-000029:notes:192]
The Tax Cuts and Jobs Act enacted Section 250, which provides for a deduction with respect to Global Intangible Low-Taxed Income ("GILTI") and Foreign-Derived Intangible Income ("FDII") in the US. The application of this tax incentive is inherently complex. During the fiscal year ended March 31, 2024, the Company analyzed the applicability of FDII and determined that this tax incentive applies to fiscal years 2021, 2022 and 2023. As a result, the Company realized a tax benefit of $18.7 million related to FDII. The Company has also concluded that any GILTI tax since the enactment of Tax Cuts and Jobs Act is immaterial.

[0001032975-25-000029:notes:193]
On December 29, 2023, a change to the cantonal tax legislation was published. According to the law approved by the Vaud parliament, a progressive scale will be applicable for cantonal tax purposes resulting in an increase from the then current tax rate of 13.61% to 14.28% effective fiscal year 2025. The increase in tax rate resulted in a tax benefit of $5.1 million due to a remeasurement of the Company's Swiss deferred tax assets in the fiscal year ended March 31, 2024.

[0001032975-25-000029:notes:194]
The Base Erosion and Profit Shifting Project (the “BEPS Project”) undertaken by the Organization for Economic Co-operation and Development (the “OECD”) recommended changes to numerous long-standing tax principles, including a proposal to reallocate profits among tax jurisdictions in which companies do business (“Pillar One”) and establishing a minimum tax on global income (“Pillar Two”).

[0001032975-25-000029:notes:195]
For the year ended March 31, 2025, the Company assessed its exposure to the OECD Pillar Two global minimum tax rules. The Company has determined that, for the fiscal year 2025, certain jurisdictions in which it operates should qualify for the transitional Country-by-Country Reporting ("CbCR") safe harbor, as outlined in the OECD Administrative Guidance and enacted domestic legislation.

[0001032975-25-000029:notes:196]
The Company's CbCR has been prepared in accordance with the requirements for a Qualified CbCR, using qualified financial statements, and has been reviewed to ensure accuracy and completeness. Based on this data, the Company met safe harbor qualifications and therefore is not required to perform a detailed Pillar Two top-up tax calculation for the current reporting period. No Pillar Two top-up tax expense has been recognized in the year ended March 31, 2025. The OECD and participating countries continue to issue underlying rules and administrative guidance related to Pillar Two, and the Company continues to monitor the relevant developments.

[0001032975-25-000029:notes:197]
Deferred income tax assets and liabilities consist of the following (in thousands):

[0001032975-25-000029:notes:198]
|  |  | March 31, |
|  |  | 2025 |  | 2024 |
| Deferred tax assets: |  |  |  |  |
| Tax attributes carryforward |  | $ | 43,536 |  |  | $ | 43,846 |  |
| Future tax deduction from Swiss Tax Benefits |  | 48,267 |  |  | 49,755 |  |
| Accruals |  | 72,114 |  |  | 77,302 |  |
| Tax step-up of goodwill from TRAF |  | 86,519 |  |  | 105,942 |  |
| Share-based compensation |  | 15,411 |  |  | 13,718 |  |
| Gross deferred tax assets |  | 265,847 |  |  | 290,563 |  |
| Valuation allowance |  | (36,537) |  |  | (35,536) |  |
| Deferred tax assets after valuation allowance |  | 229,310 |  |  | 255,027 |  |
| Deferred tax liabilities: |  |  |  |  |
| Acquired intangible assets and other |  | (27,788) |  |  | (30,901) |  |
| Deferred tax liabilities |  | (27,788) |  |  | (30,901) |  |
| Deferred tax assets, net |  | $ | 201,522 |  |  | $ | 224,126 |  |

[0001032975-25-000029:notes:199]
Management regularly assesses the ability to realize deferred tax assets recorded in the Company's entities based upon the weight of available evidence, including such factors as recent earnings history and expected future taxable income. In the event that the Company changes its determination as to the amount of deferred tax assets that can be realized, the Company will adjust its valuation allowance with a corresponding impact to the provision for income taxes in the period in which such determination is made.

[0001032975-25-000029:notes:200]
The Company had a valuation allowance against deferred tax assets of $36.5 million at March 31, 2025, compared to $35.5 million at March 31, 2024. The Company had a valuation allowance of $36.4 million as of March 31, 2025 against deferred tax assets in the state of California, an increase from $35.3 million as of March 31, 2024 from activities during the year. The Company determined that it is more likely than not that the Company would not generate sufficient taxable income in the future to utilize such deferred tax assets.

[0001032975-25-000029:notes:201]
As of March 31, 2025, the Company had net operating loss carryforwards in Switzerland for income tax purposes of $36.7 million which will begin to expire in fiscal year 2028. The Company had net operating loss and tax credit carryforwards in the United States for income tax purposes of $2.3 million and $76.0 million, respectively, as of March 31, 2025. The net operating loss carryforwards in the United States relate to acquisitions and, as a result, are limited in the amount that can be utilized in any one year and have no expiration. The tax credit carryforwards will begin to expire in fiscal year 2026.

[0001032975-25-000029:notes:202]
Swiss income taxes and non-Swiss withholding taxes associated with the repatriation of earnings or for other temporary differences related to investments in non-Swiss subsidiaries have not been provided for, as the Company intends to reinvest the earnings of such subsidiaries indefinitely. If these earnings were distributed to Switzerland in the form of dividends or otherwise, or if the shares of the relevant non-Swiss subsidiaries were sold or otherwise transferred, the Company may be subject to additional Swiss income taxes and non-Swiss withholding taxes. As of March 31, 2025, the cumulative amount of unremitted earnings of non-Swiss subsidiaries for which no income taxes have been provided is approximately $546.9 million. The amount of unrecognized deferred income tax liability related to these earnings is estimated to be approximately $18.4 million.

[0001032975-25-000029:notes:203]
The Company follows a two-step approach in recognizing and measuring uncertain tax positions. The first step is to evaluate the tax position for recognition by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step is to measure the tax benefit as the largest amount that is more than 50% likely of being realized upon ultimate settlement.

[0001032975-25-000029:notes:204]
As of March 31, 2025 and 2024, the total amount of unrecognized tax benefits due to uncertain tax positions was $152.0 million and $192.7 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-25-000029:notes:205]
As of March 31, 2025 and 2024, the Company had $88.5 million and $112.6 million, respectively, in non-current income taxes payable, including interest and penalties, related to the Company's income tax liability for uncertain tax positions.

[0001032975-25-000029:notes:206]
The aggregate changes in gross unrecognized tax benefits in fiscal years 2025, 2024 and 2023 were as follows (in thousands):

[0001032975-25-000029:notes:207]
| March 31, 2022 |  | $ | 179,372 |  |
| Lapse of statute of limitations |  | (3,586) |  |
| Increases in balances related to tax positions taken during the year |  | 15,214 |  |
| March 31, 2023 |  | $ | 191,000 |  |
| Lapse of statute of limitations |  | (3,863) |  |
| Settlements with taxing authorities |  | 41 |  |
| Increases in balances related to tax positions taken during prior years |  | 705 |  |
| Increases in balances related to tax positions taken during the year |  | $ | 22,332 |  |
| March 31, 2024 |  | $ | 210,215 |  |
| Lapse of statute of limitations |  | (25,075) |  |
| Settlements with taxing authorities |  | (32,314) |  |
| Increases (decreases) in balances related to tax positions taken during prior years |  | (3,055) |  |
| Increases in balances related to tax positions taken during the year |  | 2,213 |  |
| March 31, 2025 |  | $ | 151,984 |  |

[0001032975-25-000029:notes:208]
The Company recognizes interest and penalties related to unrecognized tax positions as income tax expense. The Company recognized $(0.6) million and $1.7 million, in interest and penalties related to unrecognized tax positions in income tax expense during fiscal years 2025 and 2024, respectively. In 2025, the interest accrual was reduced in excess of the current year accrual build as a result of audit settlements and statute lapses. As of March 31, 2025 and 2024, the Company had $7.2 million, and $7.8 million, respectively, of accrued interest and penalties related to uncertain tax positions.

[0001032975-25-000029:notes:209]
The Company files Swiss and foreign tax returns. The Company received final tax assessments in Switzerland through fiscal year 2023. As a result of these audit settlements the Company released $31.8 million of previously recorded unrecognized tax benefits which was fully recognized as a reduction of income tax expense in the year ended March 31, 2025. In the United States, the federal and state tax agencies have the authority to examine periods prior to fiscal year 2021, to the extent allowed by law, but only to the extent tax attributes were generated, carried forward, and are being utilized in subsequent years. The statute of limitations in the United States otherwise lapsed for fiscal year 2021 in fiscal year 2025. The Company is under examination in several foreign tax jurisdictions. If the examinations are resolved unfavorably, there is a possibility they may have a negative impact on its results of operations.

[0001032975-25-000029:notes:210]
Although the Company has adequately provided for uncertain tax positions, the provisions on these positions may change as revised estimates are made or the underlying matters are settled or otherwise resolved. During the next 12 months, it is reasonably possible that the amount of unrecognized tax benefits could increase or decrease significantly due to changes in tax law in various jurisdictions, due to lapse in statute of limitations and other factors, it is not possible to provide a range of potential changes.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001032975-25-000029:notes:211]
Balance Sheet Components
The following table presents the components of certain balance sheet asset amounts as of March 31, 2025 and 2024 (in thousands):

[0001032975-25-000029:notes:212]
|  |  | March 31, |
|  |  | 2025 |  | 2024 |
| Accounts receivable, net: |  |  |  |  |
| Accounts receivable |  | $ | 708,693 |  |  | $ | 744,836 |  |
| Allowance for cooperative marketing arrangements |  | (44,457) |  |  | (41,634) |  |
| Allowance for customer incentive programs |  | (66,564) |  |  | (60,027) |  |
| Allowance for pricing programs |  | (105,876) |  |  | (91,280) |  |
| Other allowances |  | (37,250) |  |  | (10,180) |  |
|  |  | $ | 454,546 |  |  | $ | 541,715 |  |
| Inventories: |  |  |  |  |
| Raw materials |  | $ | 48,699 |  |  | $ | 65,209 |  |
| Finished goods |  | 455,048 |  |  | 357,304 |  |
|  |  | $ | 503,747 |  |  | $ | 422,513 |  |
| Other current assets: |  |  |  |  |
| VAT receivables |  | $ | 46,332 |  |  | $ | 41,172 |  |
| Prepaid expenses and other assets |  | 84,879 |  |  | 105,098 |  |
|  |  | $ | 131,211 |  |  | $ | 146,270 |  |
| Property, plant and equipment, net: |  |  |  |  |
| Plant, buildings and improvements |  | $ | 88,041 |  |  | $ | 84,189 |  |
| Equipment and tooling |  | 324,007 |  |  | 296,857 |  |
| Computer equipment |  | 26,881 |  |  | 26,785 |  |
| Software |  | 95,829 |  |  | 86,161 |  |
|  |  | 534,758 |  |  | 493,992 |  |
| Less: accumulated depreciation and amortization |  | (429,889) |  |  | (387,293) |  |
|  |  | 104,869 |  |  | 106,699 |  |
| Construction-in-process |  | 6,337 |  |  | 7,180 |  |
| Land |  | 2,652 |  |  | 2,710 |  |
|  |  | $ | 113,858 |  |  | $ | 116,589 |  |
| Other assets: |  |  |  |  |
| Deferred tax assets |  | $ | 202,180 |  |  | $ | 224,831 |  |
| Right-of-use assets |  | 75,239 |  |  | 61,163 |  |
| Investments for deferred compensation plan |  | 29,006 |  |  | 29,174 |  |
| Investments in privately held companies |  | 27,980 |  |  | 28,662 |  |
| Other assets |  | 9,672 |  |  | 6,364 |  |
|  |  | $ | 344,077 |  |  | $ | 350,194 |  |

[0001032975-25-000029:notes:213]
The following table presents the components of certain balance sheet liability amounts as of March 31, 2025 and 2024 (in thousands):

[0001032975-25-000029:notes:214]
|  |  | March 31, |
|  |  | 2025 |  | 2024 |
| Accrued and other current liabilities: |  |  |  |  |
| Accrued personnel expenses |  | $ | 180,763 |  |  | $ | 145,473 |  |
| Accrued customer marketing, pricing and incentive programs |  | 173,401 |  |  | 170,371 |  |
| Warranty liabilities |  | 34,428 |  |  | 30,270 |  |
| Income taxes payable |  | 26,841 |  |  | 24,196 |  |
| VAT payable |  | 29,648 |  |  | 28,253 |  |
| Accrued sales return liability |  | 27,913 |  |  | 30,098 |  |
| Deferred revenue (1) |  | 25,798 |  |  | 19,262 |  |
| Accrued loss for inventory purchase commitments |  | 19,614 |  |  | 29,349 |  |
| Operating lease liabilities |  | 15,780 |  |  | 15,107 |  |
| Other current liabilities |  | 152,317 |  |  | 144,883 |  |
|  |  | $ | 686,503 |  |  | $ | 637,262 |  |
| Other non-current liabilities: |  |  |  |  |
| Operating lease liabilities |  | $ | 76,622 |  |  | $ | 61,920 |  |
| Employee benefit plan obligations |  | 57,338 |  |  | 42,707 |  |
| Deferred revenue (1) |  | 38,216 |  |  | 21,097 |  |
| Obligation for deferred compensation plan |  | 29,006 |  |  | 29,174 |  |
| Warranty liabilities |  | 14,756 |  |  | 14,384 |  |
| Deferred tax liabilities |  | 658 |  |  | 705 |  |
| Other non-current liabilities |  | 4,916 |  |  | 2,603 |  |
|  |  | $ | 221,512 |  |  | $ | 172,590 |  |

[0001032975-25-000029:notes:215]
(1) Includes deferred revenue for post-contract customer support and other services.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001032975-25-000029:notes:216]
Fair Value Measurements
Fair Value Measurements

[0001032975-25-000029:notes:217]
The Company considers fair value as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants at the measurement date. The Company utilizes the following three-level fair value hierarchy to establish the priorities of the inputs used to measure fair value:

[0001032975-25-000029:notes:218]
•Level 1—Quoted prices in active markets for identical assets or liabilities.

[0001032975-25-000029:notes:219]
•Level 2—Observable inputs other than quoted market prices included in Level 1, such as quoted prices for similar assets and liabilities in active markets; quoted prices for identical or similar assets and liabilities in markets that are not active; or other inputs that are observable or can be corroborated by observable market data.

[0001032975-25-000029:notes:220]
•Level 3—Unobservable inputs that are supported by little or no market activity and that are significant to the fair value of the assets or liabilities. This includes certain pricing models, discounted cash flow methodologies and similar techniques that use significant unobservable inputs.

[0001032975-25-000029:notes:221]
The following table presents the Company's financial assets and liabilities that were accounted for at fair value on a recurring basis, excluding assets related to the Company's defined benefit pension plans, classified by the level within the fair value hierarchy (in thousands):

[0001032975-25-000029:notes:222]
|  |  | March 31, 2025 |  | March 31, 2024 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Level 1 |  | Level 2 |  | Level 3 |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 852,467 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,042,604 |  |  | $ | — |  |  | $ | — |  |
| Investments for deferred compensation plan included in other assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 90 |  |  | $ | — |  |  | $ | — |  |  | $ | 312 |  |  | $ | — |  |  | $ | — |  |
| Common stock |  | 540 |  |  | — |  |  | — |  |  | 573 |  |  | — |  |  | — |  |
| Money market funds |  | 7,359 |  |  | — |  |  | — |  |  | 8,129 |  |  | — |  |  | — |  |
| Mutual funds |  | 21,017 |  |  | — |  |  | — |  |  | 20,160 |  |  | — |  |  | — |  |
| Total investments for deferred compensation plan |  | $ | 29,006 |  |  | $ | — |  |  | $ | — |  |  | $ | 29,174 |  |  | $ | — |  |  | $ | — |  |
| Currency derivative assets included in other current assets |  | $ | — |  |  | $ | 90 |  |  | $ | — |  |  | $ | — |  |  | $ | 913 |  |  | $ | — |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Contingent consideration included in accrued and other current liabilities |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,215 |  |
| Currency derivative liabilities included in accrued and other current liabilities |  | $ | — |  |  | $ | 2,849 |  |  | $ | — |  |  | $ | — |  |  | $ | 573 |  |  | $ | — |  |

[0001032975-25-000029:notes:223]
Investments for Deferred Compensation Plan

[0001032975-25-000029:notes:224]
The marketable securities for the Company's deferred compensation plan were recorded at a fair value of $29.0 million and $29.2 million as of March 31, 2025 and 2024, respectively, based on quoted market prices. Quoted market prices are observable inputs that are classified as Level 1 within the fair value hierarchy. Unrealized gains (losses) related to marketable securities for fiscal years 2025, 2024 and 2023 were not material and were included in other income (expense), net (see Note 6) and corresponding changes in the deferred compensation liability were included in operating expenses and cost of goods sold, in the Company's consolidated statements of operations.

[0001032975-25-000029:notes:225]
Equity Method Investments

[0001032975-25-000029:notes:226]
The Company has certain non-marketable investments included in other assets that are accounted for as equity method investments, with a carrying value of $18.4 million and $18.0 million as of March 31, 2025 and 2024, respectively. Income (loss) related to equity method investments for fiscal years 2025, 2024 and 2023 was not material and is included in other income (expense), net in the Company's consolidated statements of operations (see Note 6).

[0001032975-25-000029:notes:227]
During fiscal year 2023, the Company recorded an impairment charge, before tax, of $21.4 million for one of its equity method investments as it was determined that the carrying value of the investment was not recoverable. The impairment charge is included in other income (expense), net in the Company's consolidated statement of operations for fiscal year 2023. There was no impairment of equity method investments during fiscal years 2025 and 2024.

[0001032975-25-000029:notes:228]
Assets Measured at Fair Value on a Nonrecurring Basis

[0001032975-25-000029:notes:229]
Financial Assets. The Company has certain equity investments without readily determinable fair values due to the absence of quoted market prices, the inherent lack of liquidity, and the fact that inputs used to measure fair value are unobservable and require management's judgment. When certain events or circumstances indicate that impairment may exist, the Company revalues the investments using various assumptions, including the financial metrics and ratios of comparable public companies. The carrying value is also adjusted for observable price changes with the same or similar security from the same issuer. The amount of these equity investments without readily determinable fair value included in other assets was $8.8 million and $10.1 million as of March 31, 2025 and

[0001032975-25-000029:notes:230]
2024, respectively. During fiscal year 2023, the Company recorded an unrealized gain, before tax, of $6.9 million for its investment in a private company as a result of observable price changes for similar securities issued by this company (level 2 fair value measurement). The impairment charges related to these investments were not material during fiscal years 2025 and 2024.

[0001032975-25-000029:notes:231]
During fiscal year 2024, the Company recorded an impairment loss, before tax, of $9.6 million as a result of the write-off of a note receivable which was deemed no longer recoverable. This note receivable was previously obtained in conjunction with an exchange transaction related to the Company's investment in a privately held company. The impairment loss is included in other income (expense), net, in the Company's consolidated statement of operations for the fiscal year 2024.
Non-Financial Assets. Goodwill, intangible assets, and property, plant and equipment, are not required to be measured at fair value on a recurring basis. However, if the Company is required to evaluate these non-financial assets for impairment, whether due to certain triggering events or because of the required annual impairment test, and a resulting impairment is recorded to reduce the carrying value to the fair value, the non-financial assets are measured at fair value during such period. See Note 2 for additional information about how the Company tests various asset classes for impairment. During fiscal year 2024, the Company recorded impairment charges of $3.5 million related to intangible assets. There was no impairment of non-financial assets during fiscal years 2025 and 2023.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001032975-25-000029:notes:232]
Derivative Financial Instruments
 Under certain agreements with the respective counterparties to the Company's derivative contracts, subject to applicable requirements, the Company is allowed to net settle transactions of the same type with a single net amount payable by one party to the other. However, the Company presents its derivative assets and derivative liabilities on a gross basis in other current assets and accrued and other current liabilities, respectively, on the consolidated balance sheets as of March 31, 2025 and 2024. See Note 9 for the fair values of the Company’s derivative instruments as of March 31, 2025 and 2024.

[0001032975-25-000029:notes:233]
Cash Flow Hedges

[0001032975-25-000029:notes:234]
The Company enters into cash flow hedge contracts to protect against exchange rate exposure of forecasted inventory purchases. These hedging contracts mature within approximately four months. Gains and losses in the fair value of the effective portion of the hedges are deferred as a component of accumulated other comprehensive loss until the hedged inventory purchases are sold, at which time the gains or losses are reclassified to cost of goods sold. Cash flows from such hedges are classified as operating activities in the consolidated statements of cash flows. Hedging relationships are discontinued when the hedging contract is no longer eligible for hedge accounting, or is sold, terminated or exercised, or when the Company removes hedge designation for the contract. Gains and losses in the fair value of the effective portion of the discontinued hedges continue to be reported in accumulated other comprehensive loss until the hedged inventory purchases are sold, unless it is probable that the forecasted inventory purchases will not occur by the end of the originally specified time period or within an additional two-month period of time thereafter.

[0001032975-25-000029:notes:235]
The notional amounts of foreign currency exchange forward contracts outstanding related to forecasted inventory purchases were $74.6 million and $90.5 million as of March 31, 2025 and 2024, respectively. The Company had $3.0 million of net loss related to its cash flow hedges included in accumulated other comprehensive loss as of March 31, 2025, which will be reclassified into earnings within the next twelve months.

[0001032975-25-000029:notes:236]
The following table presents the amounts of gain (loss) on the Company's derivative instruments designated as hedging instruments for fiscal years 2025, 2024 and 2023 and their locations on its consolidated statements of operations and consolidated statements of comprehensive income (in thousands):

[0001032975-25-000029:notes:237]
|  |  | Amount ofGain (Loss) Deferred asa Component ofAccumulated OtherComprehensive Loss |  | Amount of Loss (Gain)Reclassified fromAccumulated OtherComprehensive Lossto Costs of Goods Sold |  |  |
|  |  | 2025 |  | 2024 |  | 2023 |  | 2025 |  | 2024 |  | 2023 |  |  |  |  |  |  |
| Cash flow hedges |  | $ | (703) |  | $ | 1,109 |  |  | $ | 2,625 |  |  | $ | (3,461) |  |  | $ | 3,964 |  |  | $ | (8,391) |  |  |  |  |  |  |  |

[0001032975-25-000029:notes:238]
The Company presents the earnings impact from forward points in the same line item that is used to present the earnings impact of the hedged item, i.e. cost of goods sold, for hedging forecasted inventory purchases and such amount is not material for all periods presented.

[0001032975-25-000029:notes:239]
Other Derivatives

[0001032975-25-000029:notes:240]
The Company also enters into foreign currency exchange forward and swap contracts to reduce the short-term effects of currency exchange rate fluctuations on certain receivables or payables denominated in currencies other than the functional currencies of its subsidiaries. These contracts generally mature within approximately one month. The primary risk managed by using forward and swap contracts is the currency exchange rate risk. The gains or losses on these contracts are not material and included in other income (expense), net in the consolidated statements of operations based on the changes in fair value. The notional amounts of these contracts outstanding as of March 31, 2025 and 2024 were $131.8 million and $79.4 million, respectively.

[0001032975-25-000029:notes:241]
The fair value of all foreign currency exchange forward and swap contracts is determined based on observable market transactions of spot currency rates and forward rates. Cash flows from these contracts are classified as operating activities in the consolidated statements of cash flows.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001032975-25-000029:notes:242]
Goodwill and Other Intangible Assets
The Company conducts its impairment analysis of goodwill annually at December 31 or more frequently if changes in facts and circumstances indicate that it is more likely than not that the fair value of the Company’s reporting unit may be less than its carrying amount. The Company conducted its annual impairment analysis of goodwill as of December 31, 2024 by performing a qualitative assessment and concluded that it was more likely than not that the fair value of its reporting unit exceeded its carrying amount. There have been no triggering events identified affecting the valuation of goodwill subsequent to the annual impairment test.

[0001032975-25-000029:notes:243]
The following table summarizes the activities in the Company's goodwill balance (in thousands):

[0001032975-25-000029:notes:244]
|  |  | Years Ended March 31, |
|  |  | 2025 |  | 2024 |
| Beginning of the period |  | $ | 461,978 |  |  | $ | 454,610 |  |
| Acquisitions |  | — |  |  | 8,156 |  |
| Effects of foreign currency translation |  | 1,252 |  |  | (788) |  |
| End of the period |  | $ | 463,230 |  |  | $ | 461,978 |  |

[0001032975-25-000029:notes:245]
The Company's acquired intangible assets were as follows (in thousands):

[0001032975-25-000029:notes:246]
|  |  | March 31, |
|  |  | 2025 |  | 2024 |
|  |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |
| Trademarks and trade names |  | $ | 32,390 |  |  | $ | (28,675) |  |  | $ | 3,715 |  |  | $ | 32,390 |  |  | $ | (25,739) |  |  | $ | 6,651 |  |
| Developed technology |  | 107,421 |  |  | (96,464) |  |  | 10,957 |  |  | 107,421 |  |  | (86,855) |  |  | 20,566 |  |
| Customer contracts/relationships |  | 69,087 |  |  | (58,646) |  |  | 10,441 |  |  | 69,087 |  |  | (51,061) |  |  | 18,026 |  |
| Effects of foreign currency translation |  | (620) |  |  | 137 |  |  | (483) |  |  | (1,019) |  |  | 379 |  |  | (640) |  |
| Total |  | $ | 208,278 |  |  | $ | (183,648) |  |  | $ | 24,630 |  |  | $ | 207,879 |  |  | $ | (163,276) |  |  | $ | 44,603 |  |

[0001032975-25-000029:notes:247]
For fiscal years 2025, 2024 and 2023, amortization expense for intangible assets was $20.1 million, $21.7 million and $24.4 million, respectively. The Company expects that annual amortization expense for fiscal years 2026, 2027, 2028, 2029 and 2030 will be $12.8 million, $5.6 million, $4.1 million, $1.8 million and $0.3 million, respectively.


## us-gaap:DebtDisclosureTextBlock

[0001032975-25-000029:notes:248]
Financing Arrangements
On January 27, 2025, the Company entered into an unsecured revolving credit facility with a syndicate of banks (the "Credit Agreement"). The Credit Agreement provides a revolving line of credit of up to $750.0 million to the Company including the issuance of letters of credit of up to $100.0 million. The Credit Agreement terminates on January 27, 2030 unless extended in accordance with its terms. The Credit Agreement contains (1) an increase option allowing the Company to secure up to $250.0 million of additional commitments and (2) an extension option to extend the term by one-year which may be exercised no more than two times, subject to certain requirements. Loans under the Credit Agreement are available in U.S. Dollars, Euro, Sterling, Yen, Swiss Francs, Canadian Dollars, Australian Dollars and any other currency agreed to by each lender. Proceeds of loans made under the Credit Agreement may be used for general corporate purposes.

[0001032975-25-000029:notes:249]
The Credit Agreement contains a maximum net debt to adjusted EBITDA ratio, compliance with which is a condition to the Company's ability to borrow. Borrowings under the Credit Agreement will bear interest at a rate determined by reference to benchmark rates plus an applicable spread (ranging from 0 to 1.5%) based on the Company's net leverage ratio or credit rating at the time of the borrowing. Undrawn balances available under the Credit Agreement are subject to commitment fees at the applicable rate determined by reference to the Company's net leverage ratio or credit rating. There has been no borrowing outstanding under the Credit Agreement as of March 31, 2025.

[0001032975-25-000029:notes:250]
In addition, the Company had several uncommitted, unsecured bank lines of credit and letters of credit aggregating to $172.2 million and $172.5 million as of March 31, 2025 and 2024, respectively. There are no financial covenants under the lines of credit with which the Company must comply. There was no borrowing outstanding under the lines of credit as of March 31, 2025 and 2024. As of March 31, 2025 and 2024, the Company had outstanding bank guarantees of $12.1 million and $14.3 million, respectively.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001032975-25-000029:notes:251]
Commitments and Contingencies
Product Warranties

[0001032975-25-000029:notes:252]
Changes in the Company's warranty liabilities for fiscal years 2025 and 2024 were as follows (in thousands):

[0001032975-25-000029:notes:253]
|  |  | Years Ended March 31, |
|  |  | 2025 |  | 2024 |
| Beginning of the period |  | $ | 44,654 |  |  | $ | 40,886 |  |
| Provision |  | 44,876 |  |  | 45,413 |  |
| Settlements |  | (40,316) |  |  | (41,413) |  |
| Effects of foreign currency translation |  | (30) |  |  | (232) |  |
| End of the period |  | $ | 49,184 |  |  | $ | 44,654 |  |

[0001032975-25-000029:notes:254]
Indemnifications

[0001032975-25-000029:notes:255]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys' fees. As of March 31, 2025, no material amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

[0001032975-25-000029:notes:256]
The Company also indemnifies its current and former directors and certain of its current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. The Company is unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not limited, the obligations are conditional in nature and the facts and circumstances involved in any situation that might arise are variable.

[0001032975-25-000029:notes:257]
Legal Proceedings

[0001032975-25-000029:notes:258]
From time to time the Company is involved in claims and legal proceedings that arise in the ordinary course of its business. The Company is currently subject to several such claims and legal proceedings. The Company intends to vigorously defend against them. Management periodically assesses the Company’s liabilities and contingencies in connection with these matters based upon the latest information available. The Company follows ASC ("Accounting Standards Codification") 450, Contingencies, in determining the accounting and disclosure for these contingencies. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows and results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company's defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company's business, financial condition, cash flows and results of operations in a particular period. Any claims or proceedings against the Company can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain a necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company's business.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001032975-25-000029:notes:259]
Shareholders' Equity
Share Capital

[0001032975-25-000029:notes:260]
As of March 31, 2025, the Company's nominal share capital is CHF 42.2 million, consisting of 168,994,142 issued shares with a par value of CHF 0.25 each, of which 20,485,124 were held in treasury shares.

[0001032975-25-000029:notes:261]
The capital band under Swiss law allows a company's board of directors to adjust the company's share capital within a predefined range based on a general authority granted by the company's shareholders. At the 2023 Annual General Meeting ("AGM"), the Company's shareholders approved an amendment to the Company’s Articles of Incorporation to introduce a capital band provision authorizing the Board of Directors to adjust the Company's share capital, without additional shareholder approval, within a range of 155,795,958 registered shares to 190,417,282 registered shares for the five-year period ending on September 13, 2028. In addition, the Company has reserved conditional capital (1) up to 25,000,000 shares for potential issuance for the exercise of rights granted under the Company's employee equity incentive plans, and (2) up to 25,000,000 shares for issuance to cover any conversion rights under any potential future convertible bond issuance.

[0001032975-25-000029:notes:262]
In September 2024, the Company's Board of Directors approved the cancellation of 4.1 million treasury shares, which were repurchased in fiscal year 2024 for an aggregate cost of $332.1 million under the 2023 share repurchase program. The cancellation became effective in the third quarter of fiscal year 2025, and as a result both the number of registered shares issued and the number of treasury shares outstanding decreased by 4.1 million shares. Upon cancellation of these shares, the Company deducted the par value from registered shares and reflected the excess of share repurchase cost over par value as a reduction to retained earnings.

[0001032975-25-000029:notes:263]
Dividends

[0001032975-25-000029:notes:264]
Pursuant to Swiss corporate law, the payment of dividends is limited to certain amounts of unappropriated retained earnings (approximately CHF 812.0 million, or USD equivalent of $921.8 million as of March 31, 2025) and is subject to shareholder approval.

[0001032975-25-000029:notes:265]
In May 2025, the Board of Directors recommended that the Company pay cash dividends for fiscal year 2025 of CHF 1.26 per share (USD equivalent of approximately $1.43 per share, which would result in a gross aggregate dividend of approximately $212.4 million, based on the exchange rate and shares outstanding, net of treasury shares, on March 31, 2025).

[0001032975-25-000029:notes:266]
In September 2024, the Company paid gross cash dividends of CHF 1.16 (USD equivalent of $1.37) per common share, totaling $207.9 million on the Company's outstanding common shares. In September 2023, the Company paid cash dividends of CHF 1.06 (USD equivalent of $1.16) per common share, totaling $182.3 million on the Company’s outstanding common shares. In September 2022, the Company paid cash dividends of CHF 0.96 (USD equivalent of $0.98) per common share, totaling $158.7 million on the Company's outstanding common shares.

[0001032975-25-000029:notes:267]
Any future dividends will be subject to the approval of the Company's shareholders.

[0001032975-25-000029:notes:268]
Legal Reserves

[0001032975-25-000029:notes:269]
Under Swiss corporate law, a minimum of 5% of the Company's annual net income must be retained in a legal reserve until this legal reserve equals 20% of the Company's issued and outstanding aggregate par value per share capital. These legal reserves represent an appropriation of retained earnings that are not available for distribution and totaled $10.9 million at March 31, 2025 (based on the exchange rate at March 31, 2025).

[0001032975-25-000029:notes:270]
Share Repurchases

[0001032975-25-000029:notes:271]
2020 Share Repurchase Program

[0001032975-25-000029:notes:272]
In May 2020, the Company's Board of Directors approved the 2020 share repurchase program, which authorized the Company to use up to $250.0 million to purchase Logitech shares to support equity incentive plans or potential acquisitions. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Purchases may be started or stopped at any time without prior notice depending on market conditions and other factors. In 2021 and 2022, the Company's Board of Directors approved increases to the 2020 share repurchase program, to an aggregate amount of up to $1.5 billion. The 2020 share repurchase program expired on July 27, 2023.

[0001032975-25-000029:notes:273]
2023 Share Repurchase Program

[0001032975-25-000029:notes:274]
In June 2023, the Company's Board of Directors approved a new, three-year share repurchase program, which allows the Company to use up to $1.0 billion to repurchase its shares. The 2023 share repurchase program enables the Company to repurchase shares for cancellation, as well as to support equity incentive plans or potential acquisitions. The Swiss Takeover Board approved the 2023 share repurchase program in July 2023 and the program became effective on July 28, 2023. As of March 31, 2025, $48.3 million was available for repurchase under the 2023 share repurchase program.

[0001032975-25-000029:notes:275]
In March 2025, the Company's Board of Directors approved an increase of $600.0 million to the 2023 share repurchase program, to an aggregate amount of $1.6 billion. The Swiss Takeover Board approved this increase in April 2025 and it became effective on April 2, 2025.

[0001032975-25-000029:notes:276]
The following table summarizes the Company's share repurchase activities for fiscal years 2025, 2024 and 2023 (in thousands):

[0001032975-25-000029:notes:277]
|  | Years Ended March 31, |
|  | 2025 |  | 2024 |  | 2023 |
| 2023 Share Repurchase Program: |  |  |  |  |  |
| Number of shares repurchased (1) | 6,679 |  | 4,459 |  | — |
| Aggregate cost of shares repurchased (1) (2) | $ | 588,028 |  |  | $ | 364,639 |  |  | $ | — |  |
| 2020 Share Repurchase Program: |  |  |  |  |  |
| Number of shares repurchased (3) | — |  | 2,641 |  | 7,562 |
| Aggregate cost of shares repurchased | $ | — |  |  | $ | 159,112 |  |  | $ | 418,346 |  |

[0001032975-25-000029:notes:278]
(1) In fiscal year 2025, all shares were repurchased for cancellation. In fiscal year 2024, 4.1 million shares in an aggregate cost of $332.1 million were repurchased for cancellation and the remaining shares were repurchased to support equity incentive plans.

[0001032975-25-000029:notes:279]
(2) Includes an aggregate cost of $18.7 million and $19.5 million, respectively, that was not yet paid as of March 31, 2025 and 2024.

[0001032975-25-000029:notes:280]
(3) Shares were repurchased to support equity incentive plans.

[0001032975-25-000029:notes:281]
Swiss law limits a company’s ability to hold or repurchase its own shares. The aggregate par value of all shares held in treasury by the Company and its subsidiaries may not exceed 10% of the share capital of the Company, which for the Company corresponds to approximately 16.9 million registered shares as of March 31, 2025. This limitation does not apply to shares repurchased for cancellation, due to the Board of Directors’ authority under the Company’s capital band set forth in the Company’s Articles of Incorporation. As of March 31, 2025, the Company had a total of 20.5 million shares held in treasury stock, which includes 6.7 million shares that have been

[0001032975-25-000029:notes:282]
repurchased for cancellation and 13.8 million shares that have been purchased to support equity incentive plans or potential acquisitions.

[0001032975-25-000029:notes:283]
To the extent that the shares are repurchased to support equity incentive plans or potential acquisitions, the shares are repurchased on the ordinary trading line of SIX Swiss Exchange (“SIX”) and/or The Nasdaq Global Select Market (“Nasdaq”). Shares repurchased for cancellation purposes are repurchased on a second trading line on SIX. Shares may be repurchased from time to time on the open market or in privately negotiated transactions, including under plans complying with the provisions of Rule 10b5-1 and Rule 10b-18 of the Securities Exchange Act of 1934, as amended. Purchases may be started or stopped at any time without prior notice depending on market conditions and other factors and the program does not require the purchase of any minimum number of shares.

[0001032975-25-000029:notes:284]
Accumulated Other Comprehensive Loss

[0001032975-25-000029:notes:285]
The components of accumulated other comprehensive loss were as follows (in thousands):

[0001032975-25-000029:notes:286]
|  |  | Currency TranslationAdjustment |  | DefinedBenefitPlans |  | DeferredHedgingGains (Losses) |  | Total |
| March 31, 2024 |  | $ | (103,947) |  |  | $ | (8,395) |  |  | $ | 1,140 |  |  | $ | (111,202) |  |
| Other comprehensive income (loss) |  | (14,705) |  |  | (16,881) |  |  | (4,164) |  |  | (35,750) |  |
| March 31, 2025 |  | $ | (118,652) |  |  | $ | (25,276) |  |  | $ | (3,024) |  |  | $ | (146,952) |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001032975-25-000029:notes:287]
Segment Information
The Company manages its business activities on a consolidated basis and operates as a single operating segment: Peripherals. The operating segment encompasses the design, manufacturing and sales of peripherals for gaming, PCs, tablets, video conferencing, and other digital platforms. The Company's Chief Operating Decision Maker (the “CODM”) is the Chief Executive Officer. The CODM periodically reviews information such as sales and net income to make business decisions and evaluate performance. The CODM uses net income to evaluate income generated from segment assets (return on assets) in deciding whether to reinvest profits into the Peripherals segment or into other parts of the entity, such as for acquisitions, share repurchase or to pay dividends. The CODM also monitors budget versus actual net income results.

[0001032975-25-000029:notes:288]
The following table presents segment revenue, gross profit, and net income for the periods presented:

[0001032975-25-000029:notes:289]
|  | Years Ended March 31, |
|  | 2025 |  | 2024 |  | 2023 |
| Net sales | $ | 4,554,900 |  |  | $ | 4,298,467 |  |  | $ | 4,538,818 |  |
| Less: Significant segment expenses |  |  |  |  |  |
| Cost of goods sold (1) | 2,572,724 |  |  | 2,501,414 |  |  | 2,800,803 |  |
| Marketing and selling (1) | 774,036 |  |  | 694,530 |  |  | 774,475 |  |
| Research and development (1) | 288,828 |  |  | 269,407 |  |  | 265,504 |  |
| General and administrative (1) | 144,680 |  |  | 133,787 |  |  | 109,504 |  |
| Less: other segment items |  |  |  |  |  |
| Share-based compensation expense | 89,913 |  |  | 82,889 |  |  | 70,782 |  |
| Amortization of intangible assets and acquisition-related costs | 20,249 |  |  | 21,962 |  |  | 24,708 |  |
| Interest income | (54,997) |  |  | (50,636) |  |  | (18,331) |  |
| Other (2) | 12,595 |  |  | 23,518 |  |  | 47,851 |  |
| Provision for income taxes | 75,343 |  |  | 9,453 |  |  | 98,947 |  |
| Net income | $ | 631,529 |  |  | $ | 612,143 |  |  | $ | 364,575 |  |

[0001032975-25-000029:notes:290]
(1) The difference between the amounts included in the table above and the amounts included in the consolidated

[0001032975-25-000029:notes:291]
statements of operations is related to share-based compensation expense (see Note 4).

[0001032975-25-000029:notes:292]
(2) Includes restructuring charges, net, impairment of intangible assets, change in fair value of contingent

[0001032975-25-000029:notes:293]
consideration for business acquisition, and other income (expense), net, as applicable.

[0001032975-25-000029:notes:294]
Sales by product category for fiscal years 2025, 2024 and 2023 were as follows (in thousands):

[0001032975-25-000029:notes:295]
|  |  | Years Ended March 31, |
|  |  | 2025 |  | 2024 |  | 2023 |
| Gaming (1) |  | $ | 1,338,467 |  |  | $ | 1,231,063 |  |  | $ | 1,288,313 |  |
| Keyboards & Combos |  | 882,643 |  |  | 821,441 |  |  | 836,432 |  |
| Pointing Devices |  | 788,784 |  |  | 742,987 |  |  | 728,357 |  |
| Video Collaboration |  | 626,000 |  |  | 609,361 |  |  | 677,923 |  |
| Webcams |  | 315,520 |  |  | 325,225 |  |  | 378,688 |  |
| Tablet Accessories |  | 299,540 |  |  | 254,060 |  |  | 254,374 |  |
| Headsets |  | 179,710 |  |  | 168,478 |  |  | 176,576 |  |
| Other (2) |  | 124,236 |  |  | 145,852 |  |  | 198,155 |  |
| Total Sales |  | $ | 4,554,900 |  |  | $ | 4,298,467 |  |  | $ | 4,538,818 |  |

[0001032975-25-000029:notes:296]
(1) Gaming includes streaming services revenue generated by Streamlabs.

[0001032975-25-000029:notes:297]
(2) Other primarily consists of mobile speakers and PC speakers.

[0001032975-25-000029:notes:298]
Sales by geographic region (based on the customers' locations) for fiscal years 2025, 2024 and 2023 were as follows (in thousands):

[0001032975-25-000029:notes:299]
|  |  | Years Ended March 31, |
|  |  | 2025 |  | 2024 |  | 2023 |
| Americas |  | $ | 1,973,374 |  |  | $ | 1,896,258 |  |  | $ | 1,930,908 |  |
| EMEA |  | 1,413,855 |  |  | 1,301,515 |  |  | 1,299,657 |  |
| Asia Pacific |  | 1,167,671 |  |  | 1,100,694 |  |  | 1,308,253 |  |
| Total Sales |  | $ | 4,554,900 |  |  | $ | 4,298,467 |  |  | $ | 4,538,818 |  |

[0001032975-25-000029:notes:300]
Revenue from sales to customers in the United States represented 35%, 36% and 35% of sales in fiscal years 2025, 2024 and 2023, respectively. Revenue from sales to customers in Germany represented 12%, 14% and 14% of sales in fiscal years 2025, 2024 and 2023, respectively. Revenue from sales to customers in China represented 10%, 10% and 11% of sales in fiscal years 2025, 2024 and 2023, respectively. No other country represented more than 10% of sales during these periods presented herein. Revenue from sales to customers in Switzerland, the Company's country of domicile, represented 3%, 2%, and 3% of sales for fiscal year 2025, 2024 and 2023, respectively.

[0001032975-25-000029:notes:301]
Property, plant and equipment, net (excluding software) and right-of-use assets by geographic region were as follows (in thousands):

[0001032975-25-000029:notes:302]
|  |  | March 31, |
|  |  | 2025 |  | 2024 |
| Americas |  | $ | 61,521 |  |  | $ | 67,762 |  |
| EMEA |  | 47,874 |  |  | 30,819 |  |
| Asia Pacific |  | 60,710 |  |  | 58,901 |  |
| Total |  | $ | 170,105 |  |  | $ | 157,482 |  |

[0001032975-25-000029:notes:303]
Property, plant and equipment, net (excluding software) and right-of-use assets in the United States, China, and Ireland were $60.0 million, $43.4 million and $14.5 million, respectively, as of March 31, 2025. Property, plant and equipment, net (excluding software) and right-of-use assets in the United States, China, and Ireland were $66.5 million, $41.2 million, and $16.2 million, respectively, as of March 31, 2024. Property, plant and equipment, net (excluding software) and right-of-use assets in Switzerland, the Company's country of domicile, were $24.1 million and $9.0 million as of March 31, 2025 and 2024, respectively. No other countries represented more than 10% of the Company's total consolidated property, plant and equipment, net (excluding software) and right-of-use assets as of March 31, 2025 or 2024.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001032975-25-000029:notes:304]
Restructuring 
During the second quarter of fiscal year 2023, the Company initiated a restructuring plan to realign its business group and engineering structure with its go-to-market strategy to more effectively compete within the enterprise market and to better serve end-users. During the fourth quarter of fiscal year 2023, the Company undertook further actions to remove organization layers as well as streamline its marketing organization to increase efficiency. These actions resulted in charges related to employee severance and other termination benefits as well as contract termination and other costs. These restructuring activities were substantially completed during fiscal year 2024.

[0001032975-25-000029:notes:305]
During the fourth quarter of fiscal year 2025, the Company initiated a restructuring plan to reorganize certain functions to enable increased productivity and efficiency. This plan resulted in charges related to employee severance and other termination benefits. The Company expects to substantially complete this restructuring within the next twelve months.

[0001032975-25-000029:notes:306]
The following table summarizes restructuring-related activities during fiscal years 2025, 2024 and 2023 (in thousands):

[0001032975-25-000029:notes:307]
|  |  | TerminationBenefits |  | Contract Termination and Other |  | Total |  |
| Accrued restructuring liability at March 31, 2022 (1) |  | $ | 561 |  |  | $ | 896 |  |  | $ | 1,457 |  |  |
| Charges, net |  | 27,631 |  |  | 6,942 |  |  | 34,573 |  |  |
| Cash payments |  | (14,015) |  |  | (2,481) |  |  | (16,496) |  |  |
| Accrued restructuring liability at March 31, 2023 (1) |  | $ | 14,177 |  |  | $ | 5,357 |  |  | $ | 19,534 |  |  |
| Charges, net |  | 6,011 |  |  | (2,145) |  |  | 3,866 |  |  |
| Cash payments |  | (18,375) |  |  | (1,757) |  |  | (20,132) |  |  |
| Accrued restructuring liability at March 31, 2024 (1) |  | $ | 1,813 |  |  | $ | 1,455 |  |  | $ | 3,268 |  |  |
| Charges, net |  | 9,846 |  |  | (231) |  |  | 9,615 |  |  |
| Cash payments |  | (2,562) |  |  | (241) |  |  | (2,803) |  |  |
| Accrued restructuring liability at March 31, 2025 (1) |  | $ | 9,097 |  |  | $ | 983 |  |  | $ | 10,080 |  |  |

[0001032975-25-000029:notes:308]
(1) The accrual balances are included in accrued and other current liabilities on the Company’s consolidated balance sheets.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001032975-25-000029:notes:309]
Leases
The Company is a lessee in various non-cancelable operating leases, primarily real estate facilities for office space. As of March 31, 2025, the Company's lease arrangements are comprised of operating leases with various expiration dates through July 31, 2035. The lease term for all of the Company’s leases includes the non-cancelable period of the lease. Certain lease agreements include options to renew or terminate the lease, which are not reasonably certain to be exercised and therefore are not factored into the Company's determination of the duration of the lease arrangement. The Company's leases do not contain any material residual value guarantees.

[0001032975-25-000029:notes:310]
The total operating lease costs including short-term lease costs were $19.3 million, $19.5 million and $21.2 million for the years ended March 31, 2025, 2024, and 2023, respectively. Total variable lease costs were not material during the years ended March 31, 2025, 2024 and 2023. The total operating and variable lease costs were included in cost of goods sold, marketing and selling, research and development, and general and administrative in the Company's consolidated statements of operations.

[0001032975-25-000029:notes:311]
Supplemental cash flow information related to operating leases (in thousands):

[0001032975-25-000029:notes:312]
|  |  | Years Ended March 31, |
|  |  | 2025 |  | 2024 |  | 2023 |
| Cash paid for amounts included in the measurement of operating lease liabilities |  | $ | 16,847 |  |  | $ | 13,489 |  |  | $ | 16,565 |  |
| ROU assets obtained in the exchange for operating lease liabilities |  | $ | 26,767 |  |  | $ | 8,593 |  |  | $ | 43,093 |  |

[0001032975-25-000029:notes:313]
Future lease payments included in the measurement of operating lease liabilities as of March 31, 2025 for the following five fiscal years and thereafter are as follows (in thousands):

[0001032975-25-000029:notes:314]
| Years Ending March 31, |  |
| 2026 | $ | 16,992 |  |
| 2027 | 15,775 |  |
| 2028 | 13,158 |  |
| 2029 | 12,591 |  |
| 2030 | 10,722 |  |
| Thereafter | 36,263 |  |
| Total lease payments | $ | 105,501 |  |
| Less: imputed interest | (13,099) |  |
| Present value of lease liabilities | $ | 92,402 |  |

[0001032975-25-000029:notes:315]
Weighted-average lease terms and discount rates were as follows:

[0001032975-25-000029:notes:316]
|  |  | Years Ended March 31, |
|  |  | 2025 |  | 2024 |
| Weighted-average remaining lease terms (in years) |  | 7.6 |  | 7.5 |
| Weighted-average discount rate |  | 3.6 | % |  | 3.8 | % |


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001032975-25-000029:notes:317]
VALUATION AND QUALIFYING ACCOUNTS

[0001032975-25-000029:notes:318]
For the Fiscal Years Ended March 31, 2025, 2024 and 2023 (in thousands)

[0001032975-25-000029:notes:319]
The Company's Schedule II includes valuation and qualifying accounts related to allowances for doubtful accounts, sales returns, cooperative marketing arrangements, customer incentive programs, and pricing programs, for direct customers and tax valuation allowances. The Company also has sales incentive programs for indirect customers with whom it does not have a direct sales and receivable relationship. These programs are recorded as accrued liabilities and are not considered valuation or qualifying accounts.

[0001032975-25-000029:notes:320]
|  |  | Balance atBeginning ofYear |  | Charged(Credited) to Statement ofOperations (1) |  | Claims andAdjustmentsApplied AgainstAllowances (1) |  | Balance atEnd ofYear |
| Allowance for cooperative marketing arrangements: |  |  |  |  |  |  |  |  |
| 2025 |  | $ | 41,634 |  |  | $ | 257,940 |  |  | $ | (255,117) |  |  | $ | 44,457 |  |
| 2024 |  | $ | 40,495 |  |  | $ | 232,837 |  |  | $ | (231,698) |  |  | $ | 41,634 |  |
| 2023 |  | $ | 56,372 |  |  | $ | 262,363 |  |  | $ | (278,240) |  |  | $ | 40,495 |  |
| Allowance for customer incentive programs: |  |  |  |  |  |  |  |  |
| 2025 |  | $ | 60,027 |  |  | $ | 337,039 |  |  | $ | (330,502) |  |  | $ | 66,564 |  |
| 2024 |  | $ | 71,645 |  |  | $ | 299,351 |  |  | $ | (310,969) |  |  | $ | 60,027 |  |
| 2023 |  | $ | 97,460 |  |  | $ | 329,666 |  |  | $ | (355,481) |  |  | $ | 71,645 |  |
| Allowance for pricing programs: |  |  |  |  |  |  |  |  |
| 2025 |  | $ | 91,280 |  |  | $ | 760,024 |  |  | $ | (745,428) |  |  | $ | 105,876 |  |
| 2024 |  | $ | 98,822 |  |  | $ | 707,954 |  |  | $ | (715,496) |  |  | $ | 91,280 |  |
| 2023 |  | $ | 120,797 |  |  | $ | 784,835 |  |  | $ | (806,810) |  |  | $ | 98,822 |  |
| Other allowances: |  |  |  |  |  |  |  |  |
| 2025 |  | $ | 10,180 |  |  | $ | 170,495 |  |  | $ | (143,425) |  |  | $ | 37,250 |  |
| 2024 |  | $ | 10,232 |  |  | $ | 141,909 |  |  | $ | (141,961) |  |  | $ | 10,180 |  |
| 2023 |  | $ | 14,533 |  |  | $ | 155,600 |  |  | $ | (159,901) |  |  | $ | 10,232 |  |
| Tax valuation allowance: |  |  |  |  |  |  |  |  |
| 2025 |  | $ | 35,536 |  |  | $ | 1,000 |  |  | $ | — |  |  | $ | 36,537 |  |
| 2024 |  | $ | 30,766 |  |  | $ | 4,770 |  |  | $ | — |  |  | $ | 35,536 |  |
| 2023 |  | $ | 29,858 |  |  | $ | 908 |  |  | $ | — |  |  | $ | 30,766 |  |

[0001032975-25-000029:notes:321]
(1) The amounts for fiscal years 2024 and 2023 include immaterial impacts from the business acquisitions during the year.
