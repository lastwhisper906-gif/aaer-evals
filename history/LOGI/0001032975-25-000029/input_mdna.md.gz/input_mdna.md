# LOGI MD&A — 0001032975-25-000029


## mdna

[0001032975-25-000029:mdna:1]
ITEM 7.    MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001032975-25-000029:mdna:2]
Company Overview

[0001032975-25-000029:mdna:3]
Logitech designs software-enabled hardware solutions that help businesses thrive and bring people together when working, creating, and gaming. As the point of connection between people and the digital world, our mission is to extend human potential in work and play, in a way that is good for people and the planet. We sell the vast majority of our products under Logitech and Logitech G brand names.

[0001032975-25-000029:mdna:4]
Our diverse, innovative portfolio includes: Gaming, Keyboards & Combos, Pointing Devices, Video Collaboration, Webcams, Tablet Accessories, and Headsets. These products are all classified under a single operating segment: Peripherals (see Note 15 to our consolidated financial statements).

[0001032975-25-000029:mdna:5]
We sell our products to a broad range of international customers, in the Americas, Europe, the Middle East and Africa (“EMEA”) and Asia Pacific. This includes direct sales to retailers, e-tailers, businesses large and small and end consumers through our e-commerce platform, and indirect sales to end customers through distributors.

[0001032975-25-000029:mdna:6]
From time to time, we may seek to partner with or acquire, when appropriate, companies that have products, personnel, and technologies that complement our strategic direction. We continually review our product offerings and our strategic direction in light of our profitability targets, competitive conditions, changing consumer trends and the evolving nature of the interface between the consumer and the digital world.

[0001032975-25-000029:mdna:7]
Impacts of Macroeconomic and Geopolitical Conditions on our Business

[0001032975-25-000029:mdna:8]
In 2025, the United States introduced trade policy actions that have increased import tariffs across a wide range of countries at various rates, with certain exemptions. The tariff policies in the U.S. and responsive policies enacted in other countries are evolving and may have a material adverse impact on our business. In addition, our business has continued to be impacted by ongoing macroeconomic and geopolitical conditions. These conditions include inflation, interest rate and foreign currency fluctuations, uncertainty in consumer and enterprise demand, low economic growth in certain regions, changes in fiscal policies and geopolitical conflicts.

[0001032975-25-000029:mdna:9]
The global and regional economic and political conditions, as well as changes in trade policies, have caused and may continue to cause volatility in demand for our products as well as cost of tariffs, materials and logistics, and transportation delays, and as a result have impacted and may continue to impact the pricing of our products, product availability and our results of operations.

[0001032975-25-000029:mdna:10]
For additional information, see Part I, Item 1A "Risk Factors," including under the captions "Adverse global and regional economic and geopolitical conditions can materially adversely affect our business, results of operations and financial condition," “We purchase key components and products from a limited number of sources, and our business and operating results could be adversely affected if supply were delayed or constrained or if there were shortages of required components,” “Our principal manufacturing operations and third-party contract manufacturers are located in China and Southeast Asia, which exposes us to risks associated with doing business in that geographic area as well as changes in tariffs, adverse trade regulations, adverse tax consequences and pressure to move or diversify our manufacturing locations,” “If we do not accurately forecast market demand for our products, our business and operating results could be adversely affected,” and "If we do not successfully coordinate the worldwide manufacturing and distribution of our products, we could lose sales and our business and operating results could be adversely affected.”

[0001032975-25-000029:mdna:11]
Trends and Uncertainties

[0001032975-25-000029:mdna:12]
Several long-term secular-trends offer long-term structural growth opportunities across Logitech’s product portfolio. We design, create and sell products that benefit from these secular trends which include the following:

[0001032975-25-000029:mdna:13]
•AI: AI has reshaped expectations for productivity improvements, product innovation and technology ecosystem evolution. While we have used AI solutions and machine learning to enhance the features of

[0001032975-25-000029:mdna:14]
different products in our portfolio, AI offers additional growth opportunities and risks as we work to integrate our capabilities with our ecosystem partners.

[0001032975-25-000029:mdna:15]
•New ways of working: The new ways of working that have emerged after the pandemic in which people are splitting time between working in the office, from home, and from other places while on the go, provide opportunities for Logitech to equip multiple workspaces with products across our portfolio including Pointing Devices, Keyboards & Combos, Tablet Accessories, Headsets and Webcams. The new ways of working also provide an opportunity for increased adoption of video conferencing by enterprises and consumers. Our video collaboration products are compatible with a variety of video conference platforms, including Zoom, Microsoft Teams and Google Meet.

[0001032975-25-000029:mdna:16]
•Gaming growth: The ongoing growth and evolution of gaming creates an opportunity for us to provide more tools to a wider community of gamers. In particular, social gaming continues to gain popularity through online gaming, multi-platform experiences and esports.

[0001032975-25-000029:mdna:17]
While we believe we will further benefit from these secular trends, we have experienced and will continue to experience challenges that impact our business and financial results. These challenges include (i) uncertainty in tariffs on goods imported into the U.S. and responsive policies enacted by other countries, (ii) the macroeconomic environment, including inflation, interest rate and foreign currency fluctuations, changes in fiscal policies and low economic growth in certain regions, (iii) the uncertainty of overall consumer and enterprise demand, (iv) the uncertainty of timing of enterprise investments in infrastructure and technology, and (v) the timing of further development of our B2B go-to-market capabilities.

[0001032975-25-000029:mdna:18]
We expect these challenges to continue in the near-term. We have taken steps to mitigate the impact of these challenges, including but not limited to: (i) continued diversification of our manufacturing footprint and supplier ecosystem, (ii) maintaining discipline in our operating expenses, (iii) managing inventory levels to align with demand, (iv) continued investment in our B2B capabilities, and (v) continued release of new products to increase the value proposition of our portfolio.

[0001032975-25-000029:mdna:19]
For additional information, see Part I, Item 1A “Risk Factors.”

[0001032975-25-000029:mdna:20]
Business Seasonality and Product Introductions

[0001032975-25-000029:mdna:21]
We have historically experienced higher sales in our third fiscal quarter ending December 31, compared to other fiscal quarters in our fiscal year, primarily due to increased consumer demand during the holiday season and increased spending by enterprises in the months nearing the calendar year-end. Additionally, new product introductions and business acquisitions can significantly impact sales, product costs and operating expenses. Sales can also be affected when consumers and distributors anticipate a product introduction or changes in business circumstances. However, neither historical seasonal patterns nor historical patterns of product introductions should be considered reliable indicators of our future pattern of product introductions, future sales or financial performance. Furthermore, cash flow is correspondingly lower in the first half of our fiscal year as we typically build inventories in advance of our third fiscal quarter and we also pay an annual dividend following our Annual General Meeting typically held in September.

[0001032975-25-000029:mdna:22]
Summary of Financial Results

[0001032975-25-000029:mdna:23]
Our total sales for fiscal year 2025 increased 6%, compared to fiscal year 2024, primarily driven by an increase in sales of Gaming, Keyboards & Combos, Pointing Devices, and Tablet Accessories, due to improved demand.

[0001032975-25-000029:mdna:24]
Sales for fiscal year 2025 increased 9%, 6% and 4% in the EMEA, Asia Pacific and Americas regions, respectively, compared to fiscal year 2024.

[0001032975-25-000029:mdna:25]
Gross margin for fiscal year 2025 increased by 170 basis points to 43.1%, compared to 41.4% for fiscal year 2024, primarily driven by lower product costs, partially offset by higher promotional spending.

[0001032975-25-000029:mdna:26]
Operating expenses for fiscal year 2025 were $1,307.7 million, or 28.7% of sales, compared to $1,190.7 million, or 27.7% of sales, for fiscal year 2024. The increase in operating expenses was primarily driven by an increase in marketing and selling expenses.

[0001032975-25-000029:mdna:27]
We had an income tax provision of $75.3 million for fiscal year 2025, compared to $9.5 million for fiscal year 2024, primarily driven by the discrete tax benefits recognized in fiscal year 2024 for the benefit of future Swiss tax deductions, the remeasurement of the tax basis of goodwill under the Swiss Federal Act on Tax Reform and AHV Financing ("TRAF"), Foreign Derived Intangible Income ("FDII") incentive provided by the Tax Cuts and Jobs Act

[0001032975-25-000029:mdna:28]
and remeasurement of our Swiss deferred tax assets due to a change in tax rate, partially offset by the tax benefit recognized in fiscal year 2025 from the release of previously recorded tax reserves for uncertain tax positions.

[0001032975-25-000029:mdna:29]
Net income for fiscal year 2025 was $631.5 million, compared to $612.1 million for fiscal year 2024, reflecting higher gross margin, partially offset by an increase in operating expenses and income tax provision.

[0001032975-25-000029:mdna:30]
Critical Accounting Estimates

[0001032975-25-000029:mdna:31]
The preparation of financial statements and related disclosures in conformity with U.S. GAAP requires us to make assumptions, judgments, and estimates that affect reported amounts of assets, liabilities, sales and expenses, and the disclosure of contingent assets and liabilities.

[0001032975-25-000029:mdna:32]
We consider an accounting estimate critical if it: (i) requires management to make judgments and estimates about matters that are inherently uncertain; and (ii) is important to an understanding of our financial condition and operating results.

[0001032975-25-000029:mdna:33]
We base our assumptions, judgments and estimates on historical experience and various other factors that we believe to be reasonable under the circumstances. Although these assumptions, judgments, and estimates are based on management's best knowledge of current events and actions that may impact us in the future, actual results could differ. Management has discussed the development, selection and disclosure of these critical accounting estimates with the Audit Committee of the Board of Directors.

[0001032975-25-000029:mdna:34]
We believe the following accounting estimates are most critical to our business operations and to an understanding of our financial condition and results of operations and reflect the more significant judgments and estimates used in the preparation of our consolidated financial statements.

[0001032975-25-000029:mdna:35]
Accruals for Customer Programs and Product Returns

[0001032975-25-000029:mdna:36]
We record accruals for cooperative marketing, customer incentive, pricing programs ("Customer Programs") and product returns. The estimated cost of these programs is usually recorded as a reduction of revenue. Significant management judgments and estimates must be used to determine the cost of these programs in any accounting period. Customer Programs require management to estimate the percentage of those programs that will not be claimed in the current period or will not be earned by customers, which is commonly referred to as "breakage." Breakage is estimated based on historical claim experience, the period in which the claims are expected to be submitted, specific terms and conditions with customers, and other factors. If we receive a separately identifiable benefit from a customer and can reasonably estimate the fair value of that benefit, the cost of the Customer Programs is recognized in operating expenses.

[0001032975-25-000029:mdna:37]
Customer Incentive Programs. Customer incentive programs include performance-based incentives and consumer rebates. We offer performance-based incentives to our customers and indirect partners based on predetermined performance criteria. Consumer rebates are offered from time to time at our discretion for the primary benefit of end-users. Customer incentive programs are considered variable consideration, which we estimate and record as a reduction to revenue at the time of sale based on negotiated terms, historical experiences, forecasted incentives, the anticipated volume of future purchases, and inventory levels in the channel.

[0001032975-25-000029:mdna:38]
Product Returns. We grant limited rights to return products. Return rights vary by customer and range from just the right to return the defective product to stock rotation rights limited to a percentage of sales approved by management. Estimates of expected future product returns are recognized at the time of sale based on analyses of historical return trends by the customer and by product, inventories owned by and located at customers, current customer demand, current operating conditions, and other relevant customer and product information. Upon recognition, we reduce sales and cost of goods sold for the estimated return. Return trends are influenced by product life cycle status, new product introductions, market acceptance of products, sales levels, product sell-through, the type of customer, seasonality, product quality issues, competitive pressures, operational policies and procedures, and other factors. Return rates can fluctuate over time but are sufficiently predictable to allow us to estimate expected future product returns.

[0001032975-25-000029:mdna:39]
We apply a breakage rate to reduce our accruals of Customer Programs based on the estimated percentage of these Customer Programs that will not be claimed or earned. The breakage rate is applied at the time of sale. Assessing the period in which claims are expected to be submitted and the relevance of the historical claim experience require significant management judgment to estimate the breakage of Customer Programs in any accounting period.

[0001032975-25-000029:mdna:40]
We regularly evaluate the adequacy of our accruals for Customer Programs and product returns. Future market conditions and product transitions may require us to take action to increase such programs. In addition, when the variables used to estimate these costs change, or if actual costs differ significantly from the estimates, we would be required to record incremental increases or reductions to revenue or operating expenses.

[0001032975-25-000029:mdna:41]
Inventory Valuation

[0001032975-25-000029:mdna:42]
We must order components for our products and build inventory in advance of customer orders. Further, our industry is characterized by rapid technological change, short-term customer commitments and rapid changes in demand.

[0001032975-25-000029:mdna:43]
We record inventories at the lower of cost and net realizable value and record write-downs of inventories that are obsolete or in excess of anticipated demand or net realizable value. A review of inventory is performed each fiscal quarter that considers factors including the marketability and product lifecycle stage, product development plans, component cost trends, historical sales, and demand forecasts that consider the assumptions about future demand and market conditions. Inventory on hand that is not expected to be sold or utilized is considered excess, and we recognize the write-down in the cost of goods sold at the time of such determination. The write-down is determined by the excess of cost over net realizable value. Net realizable value is the estimated selling price in the ordinary course of business, less reasonably predictable costs of completion, disposal and transportation. At the time of loss recognition, new cost basis per unit and the lower-cost basis for that inventory are established and subsequent changes in facts and circumstances would not result in an increase in the cost basis. If there is an abrupt and substantial decline in demand for Logitech's products or an unanticipated change in technological or customer requirements, we may be required to record additional write-downs that could adversely affect gross margins in the period when the write-downs are recorded. We also extend the assessment to non-cancelable purchase orders if the inventories are considered excess and record the liability that is reasonably possible to be incurred in accrued and other liabilities.

[0001032975-25-000029:mdna:44]
Accounting for Income Taxes

[0001032975-25-000029:mdna:45]
We operate in multiple jurisdictions and our profits are taxed pursuant to the tax laws of these jurisdictions. Our effective income tax rate may be affected by the changes in or interpretations of tax laws and tax agreements in any given jurisdiction, utilization of net operating loss and tax credit carryforwards, changes in geographical mix of income and expense, and changes in our assessment of matters such as the ability to realize deferred tax assets. As a result of these considerations, we must estimate income taxes in each of the jurisdictions in which we operate. This process involves estimating current tax exposure together with assessing temporary differences resulting from the different treatment of items for tax and accounting purposes. These differences result in deferred tax assets and liabilities, which are included in the consolidated balance sheet.

[0001032975-25-000029:mdna:46]
We make certain estimates and judgments about the application of tax laws, the expected resolution of uncertain tax positions and other matters surrounding the recognition and measurement of uncertain tax benefits. In the event that uncertain tax positions are resolved for amounts different than our estimates, or the related statutes of limitations expire without the assessment of additional income taxes, we will be required to adjust the amounts of the related assets and liabilities in the period in which such events occur. Such adjustments may have a material impact on our income tax provision and our results of operations.

[0001032975-25-000029:mdna:47]
For additional information about our Critical Accounting Estimates, see Note 2—Summary of Significant Accounting Policies in our Notes to our consolidated financial statements.

[0001032975-25-000029:mdna:48]
New Accounting Pronouncements

[0001032975-25-000029:mdna:49]
Refer to Note 2 to the consolidated financial statements included in this Annual Report on Form 10-K for recent accounting pronouncements adopted and to be adopted.

[0001032975-25-000029:mdna:50]
Constant Currency

[0001032975-25-000029:mdna:51]
We refer to our net sales growth rates excluding the impact of currency exchange rate fluctuations as "constant currency" sales growth rates. Percentage of constant currency sales growth is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales.

[0001032975-25-000029:mdna:52]
Given our global sales presence and the reporting of our financial results in U.S. Dollars, our financial results could be affected by significant shifts in currency exchange rates. See “Results of Operations” for information on the effect of currency exchange rate fluctuations on our sales. If the U.S. Dollar appreciates or depreciates in comparison to other currencies in future periods, this will affect our results of operations in future periods as well.

[0001032975-25-000029:mdna:53]
References to Sales

[0001032975-25-000029:mdna:54]
The term “sales” means net sales, except as otherwise specified and the sales growth discussion and sales growth rate percentages are in U.S. Dollars, except as otherwise specified.

[0001032975-25-000029:mdna:55]
Results of Operations

[0001032975-25-000029:mdna:56]
In this section, we discuss the results of our operations for the year ended March 31, 2025 compared to the year ended March 31, 2024. For a discussion of the year ended March 31, 2024 compared to the year ended March 31, 2023, please refer to Part II, Item 7, "Management's Discussion and Analysis of Financial Condition and Results of Operations" in our Annual Report on Form 10-K filed with the SEC on May 16, 2024.

[0001032975-25-000029:mdna:57]
Net Sales

[0001032975-25-000029:mdna:58]
Our sales in fiscal year 2025 increased 6%, compared to fiscal year 2024, primarily driven by an increase in sales of Gaming, Keyboards & Combos, Pointing Devices, and Tablet Accessories, due to improved demand. If currency exchange rates had been constant in fiscal years 2025 and 2024, our sales growth rate in constant currency would have been 7%.

[0001032975-25-000029:mdna:59]
Sales Denominated in Other Currencies

[0001032975-25-000029:mdna:60]
Although our financial results are reported in U.S. Dollars, a portion of our sales was generated in currencies other than the U.S. Dollar, such as the Euro, Chinese Renminbi, Japanese Yen, Australian Dollar, Canadian Dollar, Pound Sterling and New Taiwan Dollar. For the years ended March 31, 2025 and 2024, approximately 49% and 50%, respectively, of our sales were denominated in currencies other than the U.S. Dollar.

[0001032975-25-000029:mdna:61]
Sales by Region

[0001032975-25-000029:mdna:62]
The following table presents the change in sales by region for fiscal year 2025 compared with fiscal year 2024:

[0001032975-25-000029:mdna:63]
|  |  | 2025 vs. 2024 |  |  |
|  |  | Sales Growth Rate |  | Sales Growth Rate in Constant Currency |  |  |  |  |
| Americas |  | 4 | % |  | 5 | % |  |  |  |  |
| EMEA |  | 9 |  |  | 9 |  |  |  |  |  |
| Asia Pacific |  | 6 |  |  | 7 |  |  |  |  |  |

[0001032975-25-000029:mdna:64]
Americas:

[0001032975-25-000029:mdna:65]
The increase in sales in the Americas region for fiscal year 2025, compared to fiscal year 2024, was primarily driven by an increase in sales of Gaming, Tablet Accessories, and Video Collaboration.

[0001032975-25-000029:mdna:66]
EMEA:

[0001032975-25-000029:mdna:67]
The increase in sales in the EMEA region for fiscal year 2025, compared to fiscal year 2024, was primarily driven by an increase in sales of Gaming, Keyboards & Combos, and Pointing Devices.

[0001032975-25-000029:mdna:68]
Asia Pacific:

[0001032975-25-000029:mdna:69]
The increase in sales in the Asia Pacific region for fiscal year 2025, compared to fiscal year 2024, was primarily driven by an increase in sales of Gaming and Tablet Accessories.

[0001032975-25-000029:mdna:70]
Sales by Product Category

[0001032975-25-000029:mdna:71]
Sales by product category for fiscal years 2025 and 2024 were as follows (Dollars in thousands):

[0001032975-25-000029:mdna:72]
|  |  | Years Ended March 31, |  | Change |
|  |  | 2025 |  | 2024 |  | 2025 vs. 2024 |
| Gaming (1) |  | $ | 1,338,467 |  |  | $ | 1,231,063 |  |  | 9 | % |
| Keyboards & Combos |  | 882,643 |  |  | 821,441 |  |  | 7 |  |
| Pointing Devices |  | 788,784 |  |  | 742,987 |  |  | 6 |  |
| Video Collaboration |  | 626,000 |  |  | 609,361 |  |  | 3 |  |
| Webcams |  | 315,520 |  |  | 325,225 |  |  | (3) |  |
| Tablet Accessories |  | 299,540 |  |  | 254,060 |  |  | 18 |  |
| Headsets |  | 179,710 |  |  | 168,478 |  |  | 7 |  |
| Other (2) |  | 124,236 |  |  | 145,852 |  |  | (15) |  |
| Total Sales |  | $ | 4,554,900 |  |  | $ | 4,298,467 |  |  | 6 | % |

[0001032975-25-000029:mdna:73]
(1) Gaming includes streaming services revenue generated by Streamlabs.

[0001032975-25-000029:mdna:74]
(2) Other primarily consists of mobile speakers and PC speakers.

[0001032975-25-000029:mdna:75]
Gaming

[0001032975-25-000029:mdna:76]
Our Gaming category includes gaming mice, steering wheels, headsets, keyboards, console gaming headsets, microphones and Streamlabs services.

[0001032975-25-000029:mdna:77]
During fiscal year 2025, Gaming sales increased 9%, compared to fiscal year 2024, primarily driven by increases in sales of gaming mice and gaming steering wheels.

[0001032975-25-000029:mdna:78]
Keyboards & Combos

[0001032975-25-000029:mdna:79]
Our Keyboards & Combos category includes PC keyboards and keyboard/mice combo products.

[0001032975-25-000029:mdna:80]
During fiscal year 2025, Keyboards & Combos sales increased 7%, compared to fiscal year 2024, primarily driven by an increase in sales of our cordless combos.

[0001032975-25-000029:mdna:81]
Pointing Devices

[0001032975-25-000029:mdna:82]
Our Pointing Devices category includes PC- and Mac-related mice including trackballs and presentation tools.

[0001032975-25-000029:mdna:83]
During fiscal year 2025, Pointing Devices sales increased 6%, compared to fiscal year 2024, primarily driven by an increase in sales of cordless mice.

[0001032975-25-000029:mdna:84]
Video Collaboration

[0001032975-25-000029:mdna:85]
Our Video Collaboration category includes Logitech’s conference room cameras, which combine affordable enterprise-quality audio and high definition 4K video to bring video conferencing to a variety of room sizes.

[0001032975-25-000029:mdna:86]
During fiscal year 2025, Video Collaboration sales increased 3%, compared to fiscal year 2024, primarily due to an increase in sales of conference room cameras as well as an increase in services revenue.

[0001032975-25-000029:mdna:87]
Webcams

[0001032975-25-000029:mdna:88]
Our Webcams category includes PC-based webcams including streaming cameras, and VC webcams that turn any desktop into an instant collaboration space.

[0001032975-25-000029:mdna:89]
During fiscal year 2025, Webcams sales decreased 3%, compared to fiscal year 2024, primarily driven by a decrease in sales of our VC webcams, partially offset by an increase in sales of our PC-based webcams.

[0001032975-25-000029:mdna:90]
Tablet Accessories

[0001032975-25-000029:mdna:91]
Our Tablet Accessories category primarily includes tablet keyboards.

[0001032975-25-000029:mdna:92]
During fiscal year 2025, Tablet Accessories sales increased 18%, compared to fiscal year 2024, primarily driven by strong sales from the education sector related to our Rugged Combo 4 products as well as sales from our new Combo Touch products launched in fiscal year 2025 for the latest releases of iPad Air and iPad Pro. Sales of Tablet Accessories for fiscal year 2025, compared to fiscal year 2024, also benefited from strong sales from the education sector.

[0001032975-25-000029:mdna:93]
Headsets

[0001032975-25-000029:mdna:94]
Our Headsets category includes PC and VC headsets, in-ear headphones, and premium wireless earbuds.

[0001032975-25-000029:mdna:95]
During fiscal year 2025, Headsets sales increased 7%, compared to 2024, primarily driven by an increase in sales of cordless PC headsets and VC headsets.

[0001032975-25-000029:mdna:96]
Other

[0001032975-25-000029:mdna:97]
Our Other category primarily consists of mobile speakers and PC speakers.

[0001032975-25-000029:mdna:98]
During fiscal year 2025, Other sales decreased 15% compared to 2024, primarily driven by a decline in sales of mobile speakers.

[0001032975-25-000029:mdna:99]
Gross Profit

[0001032975-25-000029:mdna:100]
Gross profit for fiscal years 2025 and 2024 was as follows (Dollars in thousands):

[0001032975-25-000029:mdna:101]
|  |  | Years Ended March 31, |
|  |  | 2025 |  | 2024 |  | Change |
| Net sales |  | $ | 4,554,900 |  |  | $ | 4,298,467 |  |  | 6.0 | % |
| Gross profit |  | $ | 1,962,601 |  |  | $ | 1,778,021 |  |  | 10.4 | % |
| Gross margin |  | 43.1 | % |  | 41.4 | % |  |  |

[0001032975-25-000029:mdna:102]
Gross profit consists of sales, less cost of goods sold (which includes materials, direct labor and related overhead costs, costs of manufacturing facilities, royalties, costs of purchasing components from outside suppliers, distribution costs, warranty costs, customer support costs, shipping and handling costs, outside processing costs and write-down of inventories), and amortization of intangible assets.

[0001032975-25-000029:mdna:103]
Gross margin increased by 170 basis points to 43.1% during fiscal year 2025, compared to 41.4% during fiscal year 2024. The increase in gross margin was primarily driven by lower product costs, partially offset by higher promotional spending.

[0001032975-25-000029:mdna:104]
Operating Expenses

[0001032975-25-000029:mdna:105]
Operating expenses for fiscal years 2025 and 2024 were as follows (Dollars in thousands):

[0001032975-25-000029:mdna:106]
|  |  | Years Ended March 31, |
|  |  | 2025 |  | 2024 |  |  |
| Marketing and selling |  | $ | 814,414 |  |  | $ | 730,310 |  |  |  |
| % of sales |  | 17.9 | % |  | 17.0 | % |  |  |
| Research and development |  | 309,008 |  |  | 287,243 |  |  |  |
| % of sales |  | 6.8 | % |  | 6.7 | % |  |  |
| General and administrative |  | 164,014 |  |  | 155,056 |  |  |  |
| % of sales |  | 3.6 | % |  | 3.6 | % |  |  |
| Amortization of intangible assets and acquisition-related costs |  | 10,695 |  |  | 10,934 |  |  |  |
| % of sales |  | 0.2 | % |  | 0.2 | % |  |  |
| Impairment of intangible assets |  | — |  |  | 3,526 |  |  |  |
| % of sales |  | — | % |  | 0.1 | % |  |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | (250) |  |  |  |
| % of sales |  | — | % |  | — | % |  |  |
| Restructuring charges, net |  | 9,615 |  |  | 3,866 |  |  |  |
| % of sales |  | 0.2 | % |  | 0.1 | % |  |  |
| Total operating expenses |  | $ | 1,307,746 |  |  | $ | 1,190,685 |  |  |  |
| % of sales |  | 28.7 | % |  | 27.7 | % |  |  |

[0001032975-25-000029:mdna:107]
The increase in total operating expenses during fiscal year 2025, compared to fiscal year 2024, was primarily due to increases in marketing and selling expenses.

[0001032975-25-000029:mdna:108]
Marketing and Selling

[0001032975-25-000029:mdna:109]
Marketing and selling expenses consist of personnel and related overhead costs, corporate and product marketing, promotions, advertising, trade shows, technical support for customer experiences and facilities costs.

[0001032975-25-000029:mdna:110]
During fiscal year 2025, marketing and selling expenses increased $84.1 million, compared to fiscal year 2024, primarily driven by increased investment in marketing and advertising, a provision for credit loss on accounts receivable recorded in fiscal year 2025, and higher performance-based compensation expense.

[0001032975-25-000029:mdna:111]
Research and Development

[0001032975-25-000029:mdna:112]
Research and development expenses consist of personnel and related overhead costs for contractors and outside consultants, supplies and materials, equipment depreciation and facilities costs, all associated with the design and development of new products and enhancements of existing products.

[0001032975-25-000029:mdna:113]
During fiscal year 2025, research and development expenses increased $21.8 million, compared to fiscal year 2024, primarily driven by increased investment in product innovation and higher personnel-related costs driven by increased headcount as well as higher performance-based compensation expense.

[0001032975-25-000029:mdna:114]
General and Administrative

[0001032975-25-000029:mdna:115]
General and administrative expenses primarily consist of personnel and related overhead, information technology, and facilities costs for the infrastructure functions such as finance, information systems, executives, human resources and legal.

[0001032975-25-000029:mdna:116]
During fiscal year 2025, general and administrative expenses increased $9.0 million, compared to fiscal year 2024, primarily driven by higher personnel-related costs to support business growth.

[0001032975-25-000029:mdna:117]
Amortization of Intangible Assets and Acquisition-Related Costs

[0001032975-25-000029:mdna:118]
Amortization of intangible assets consists of amortization of acquired intangible assets, including customer relationships and trademarks and trade names. Acquisition-related costs include legal expenses, due diligence costs, and other professional costs incurred for business acquisitions.

[0001032975-25-000029:mdna:119]
During fiscal year 2025, amortization of intangible assets and acquisition-related costs remained flat, compared to fiscal year 2024.

[0001032975-25-000029:mdna:120]
Impairment of Intangible Assets

[0001032975-25-000029:mdna:121]
During fiscal year 2024, we recognized a pre-tax impairment charge of $3.5 million, related to our in-process Research and Development intangible asset.

[0001032975-25-000029:mdna:122]
Restructuring Charges, Net

[0001032975-25-000029:mdna:123]
The restructuring charges, net, for the fiscal year 2025 were related to costs incurred as a result of our restructuring plan initiated during the fourth quarter of fiscal year 2025. The restructuring charges, net, for the fiscal year 2024 were related to costs incurred as a result of our restructuring plan initiated during fiscal year 2023 and substantially completed during fiscal year 2024. See Note 16 to our consolidated financial statements for additional information.

[0001032975-25-000029:mdna:124]
Interest Income

[0001032975-25-000029:mdna:125]
Interest income for fiscal years 2025 and 2024 was as follows (in thousands):

[0001032975-25-000029:mdna:126]
|  |  | Years Ended March 31, |
|  |  | 2025 |  | 2024 |  |  |
| Interest income |  | $ | 54,997 |  |  | $ | 50,636 |  |  |  |

[0001032975-25-000029:mdna:127]
We invest in highly liquid instruments with an original maturity of three months or less at the date of purchase, which are classified as cash equivalents. The increase in interest income for fiscal year 2025, compared to fiscal year 2024, was primarily driven by an increase in the average cash equivalents balance.

[0001032975-25-000029:mdna:128]
Other Income (Expense), Net

[0001032975-25-000029:mdna:129]
Other income (expense), net for fiscal years 2025 and 2024 was as follows (in thousands):

[0001032975-25-000029:mdna:130]
|  |  | Years Ended March 31, |
|  |  | 2025 |  | 2024 |  |  |
| Investment gain related to the deferred compensation plan |  | $ | 2,131 |  |  | $ | 4,320 |  |  |  |
| Currency exchange loss, net |  | (6,401) |  |  | (8,770) |  |  |  |
| Loss on investments, net |  | (2,029) |  |  | (14,674) |  |  |  |
| Non-service cost net pension income and other |  | 3,319 |  |  | 2,748 |  |  |  |
| Total |  | $ | (2,980) |  |  | $ | (16,376) |  |  |  |

[0001032975-25-000029:mdna:131]
Investment gain (loss) related to the deferred compensation plan for fiscal years 2025 and 2024 represents earnings, gains, and losses on marketable securities related to a deferred compensation plan offered by one of our subsidiaries. The decrease in investment gain for fiscal year 2025, compared to fiscal year 2024, primarily relates to the change in market performance of the underlying securities.

[0001032975-25-000029:mdna:132]
Currency exchange loss, net, relates to balances denominated in currencies other than the functional currency in our subsidiaries, as well as the sale of currencies, and gains or losses recognized on currency exchange forward contracts. We do not speculate in currency positions, but we are alert to opportunities to maximize currency exchange gains and minimize currency exchange losses. The loss for fiscal year 2025 was related to the exchange rate fluctuations of the Chinese Renminbi and Mexican Peso versus the U.S. Dollar. The loss for fiscal year 2024 was related to the exchange rate fluctuations of the Chinese Renminbi, Australian Dollar, Brazilian Real, and Japanese Yen versus the U.S. Dollar.

[0001032975-25-000029:mdna:133]
Loss on investments, net, includes unrealized gain (loss) from the change in fair value of investments, income (loss) on equity-method investments and impairment of investments during the periods presented, as applicable.

[0001032975-25-000029:mdna:134]
The loss on investments, net, for fiscal year 2025 was not material. The loss on investments, net, for fiscal year 2024 was primarily due to an impairment loss, as a result of the write-off of a note receivable which was deemed no longer recoverable. This note receivable was previously obtained in conjunction with an exchange transaction related to our investment in a privately held company. See Note 9 to our consolidated financial statements for additional information.

[0001032975-25-000029:mdna:135]
Provision for Income Taxes

[0001032975-25-000029:mdna:136]
The provision for income taxes and effective income tax rates for fiscal years 2025 and 2024 were as follows (Dollars in thousands):

[0001032975-25-000029:mdna:137]
|  |  | Years Ended March 31, |
|  |  | 2025 |  | 2024 |  |  |
| Provision for income taxes |  | $ | 75,343 |  |  | $ | 9,453 |  |  |  |
| Effective income tax rate |  | 10.7 | % |  | 1.5 | % |  |  |

[0001032975-25-000029:mdna:138]
The change in the effective income tax rate between fiscal years 2025 and 2024 was primarily due to the tax effect of audit resolutions and the expiration of statutes of limitation of uncertain tax positions in fiscal year 2025 compared with the discrete tax benefits recognized in fiscal year 2024 for the benefit of future Swiss tax deductions, the remeasurement of the tax basis of goodwill under TRAF, FDII incentive provided by the Tax Cuts and Jobs Act and remeasurement of our Swiss deferred tax assets due to a change in tax rate.

[0001032975-25-000029:mdna:139]
On March 28, 2024, the Swiss canton of Vaud confirmed a future tax benefit to be recognized for ten years. This resulted in the Company recording an income tax benefit of $50.1 million during the fiscal year ended March 31, 2024, which will be utilized over a ten-year period.

[0001032975-25-000029:mdna:140]
The canton of Vaud completed the legislative process to enact TRAF, a reform to better align the Swiss tax system to international tax standards, on March 10, 2020, that took effect as of January 1, 2020. In March 2020, we increased the tax basis of goodwill, as a transition measure under TRAF, to be amortized over ten years beginning on January 1, 2020. During the fiscal year ended March 31, 2024, we remeasured the tax basis of goodwill under TRAF, which resulted in an income tax benefit of $25.1 million, net of assessment for uncertain tax positions. The remeasurement of the step-up will be amortized over the remaining ten-year amortization period.

[0001032975-25-000029:mdna:141]
The Tax Cuts and Jobs Act enacted Section 250, which provides for a deduction with respect to Global Intangible Low-Taxed Income ("GILTI") and FDII in the US. The application of this tax incentive is inherently complex. During the fiscal year ended March 31, 2024, we analyzed the applicability of FDII and determined that this tax incentive applies to fiscal years 2021, 2022 and 2023. As a result, we realized a tax benefit of $18.7 million related to FDII. We have also concluded that any GILTI tax since the enactment of Tax Cuts and Jobs Act is immaterial.

[0001032975-25-000029:mdna:142]
On December 29, 2023, a change to the cantonal tax legislation was published. According to the law approved by the Vaud parliament, a progressive scale will be applicable for cantonal tax purposes resulting in an increase from the then current tax rate of 13.61% to 14.28% effective fiscal year 2025. The increase in tax rate resulted in a tax benefit of $5.1 million due to a remeasurement of our Swiss deferred tax assets in the fiscal year ended March 31, 2024.

[0001032975-25-000029:mdna:143]
The Base Erosion and Profit Shifting Project (the “BEPS Project”) undertaken by the Organization for Economic Co-operation and Development (the “OECD”) recommended changes to numerous long-standing tax principles, including a proposal to reallocate profits among tax jurisdictions in which companies do business (“Pillar One”) and establishing a minimum tax on global income (“Pillar Two”). Some jurisdictions, including Switzerland, where we operate have implemented Pillar Two laws to effectuate a 15% minimum tax. The minimum tax, effective beginning in fiscal year 2025 for the Company, is treated as a current cost and does not have an impact on the Company's effective tax rate. The OECD and participating countries continue to issue underlying rules and administrative guidance related to Pillar Two, and we continue to monitor the relevant developments.

[0001032975-25-000029:mdna:144]
As of March 31, 2025 and 2024, the total amount of unrecognized tax benefits due to uncertain tax positions was $152.0 million and $192.7 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-25-000029:mdna:145]
As of March 31, 2025 and 2024, we had $88.5 million and $112.6 million, respectively, in non-current income taxes payable, including interest and penalties, related to our income tax liability for uncertain tax positions. As of

[0001032975-25-000029:mdna:146]
March 31, 2025 and 2024, we had $7.2 million and $7.8 million, respectively, of accrued interest and penalties related to uncertain tax positions.

[0001032975-25-000029:mdna:147]
We file Swiss and foreign tax returns. We received final tax assessments in Switzerland through fiscal year 2023. For other material foreign jurisdictions such as the United States and China, we are generally not subject to tax examinations for years prior to fiscal year 2020 and calendar year 2020, respectively. In the United States, the federal and state tax agencies have the authority to examine periods prior to fiscal year 2020, to the extent allowed by law, where tax attributes were generated, carried forward, and being utilized in subsequent years. We are under examination in foreign tax jurisdictions. If the examinations are resolved unfavorably, there is a possibility that they may have a negative impact on our results of operations.

[0001032975-25-000029:mdna:148]
Liquidity and Capital Resources

[0001032975-25-000029:mdna:149]
Cash Balances, Available Borrowings, and Capital Resources

[0001032975-25-000029:mdna:150]
As of March 31, 2025, we had cash and cash equivalents of $1,503.2 million, compared with $1,520.8 million as of March 31, 2024. Our cash and cash equivalents consist of bank demand deposits, short-term time deposits, and U.S. Treasury securities, of which 53% was held in Switzerland and 27% was held in the United States. We do not expect to incur any material adverse tax impact except for what has already been recognized, or to be significantly inhibited by any country in which we do business, from the repatriation of funds to Switzerland, our country of domicile.

[0001032975-25-000029:mdna:151]
As of March 31, 2025, our working capital was $1,491.6 million, compared to $1,545.5 million as of March 31, 2024. The decrease was primarily driven by a decrease in accounts receivable, net, and an increase in accrued and other liabilities, partially offset by an increase in inventories.

[0001032975-25-000029:mdna:152]
On January 27, 2025, we entered into an unsecured revolving credit facility with a syndicate of banks ("the Credit Agreement"). The Credit Agreement provides a revolving line of credit of up to $750.0 million including the issuance of letters of credit of up to $100.0 million. The Credit Agreement terminates on January 27, 2030 unless extended in accordance with its terms. The Credit Agreement contains (1) an increase option allowing us to secure up to $250.0 million of additional commitments and (2) an extension option to extend the term by one-year which may be exercised no more than two times, subject to certain requirements. Loans under the Credit Agreement are available in U.S. Dollars, Euro, Sterling, Yen, Swiss Francs, Canadian Dollars, Australian Dollars and any other currency agreed to by each lender. Proceeds of loans made under the Credit Agreement may be used for general corporate purposes.

[0001032975-25-000029:mdna:153]
The Credit Agreement contains a maximum net debt to adjusted EBITDA ratio, compliance with which is a condition to our ability to borrow. Borrowings under the Credit Agreement will bear interest at a rate determined by reference to benchmark rates plus an applicable spread (ranging from 0% to 1.5%) based on our net leverage ratio or credit rating at the time of the borrowing. Undrawn balances available under the Credit Agreement are subject to commitment fees at the applicable rate determined by reference to our net leverage ratio or credit rating. There has been no borrowing outstanding under the Credit Agreement as of March 31, 2025.

[0001032975-25-000029:mdna:154]
In addition, we had several uncommitted, unsecured bank lines of credit and letters of credit aggregating to $172.2 million as of March 31, 2025. There are no financial covenants under these lines of credit with which we must comply. There was no borrowing outstanding under these lines of credit as of March 31, 2025. As of March 31, 2025, we had outstanding bank guarantees of $12.1 million.

[0001032975-25-000029:mdna:155]
The following table presents selected financial information and statistics as of March 31, 2025 and 2024 (Dollars in thousands):

[0001032975-25-000029:mdna:156]
|  |  | March 31, |
|  |  | 2025 |  | 2024 |  |  |
| Accounts receivable, net |  | $ | 454,546 |  |  | $ | 541,715 |  |  |  |
| Accounts payable |  | $ | 414,586 |  |  | $ | 448,627 |  |  |  |
| Inventories |  | $ | 503,747 |  |  | $ | 422,513 |  |  |  |
| Days sales in accounts receivable (DSO)(Days)(1) |  | 40 |  |  | 48 |  |  |  |
| Days accounts payable outstanding (DPO) (Days)(2) |  | 65 |  |  | 70 |  |  |  |
| Inventory turnover (ITO)(x)(3) |  | 4.6 |  |  | 5.4 |  |  |  |

[0001032975-25-000029:mdna:157]
(1) DSO is determined using ending accounts receivable, net, as of the most recent quarter-end and sales for the most recent quarter.

[0001032975-25-000029:mdna:158]
(2) DPO is determined using ending accounts payable as of the most recent quarter-end and cost of goods sold for the most recent quarter.

[0001032975-25-000029:mdna:159]
(3) ITO is determined using ending inventories as of the most recent quarter-end and annualized cost of goods sold (based on the most recent quarterly cost of goods sold).

[0001032975-25-000029:mdna:160]
DSO as of March 31, 2025 decreased by 8 days to 40 days, compared to 48 days as of March 31, 2024, primarily due to the timing of sales within the fourth quarter of the fiscal years 2025 and 2024.

[0001032975-25-000029:mdna:161]
DPO as of March 31, 2025 decreased by 5 days to 65 days, compared to 70 days as of March 31, 2024, primarily due to timing of inventory purchases.

[0001032975-25-000029:mdna:162]
ITO as of March 31, 2025 decreased by 0.8 to 4.6, compared to 5.4 as of March 31, 2024, primarily due to a pre-build of inventory in advance of the effective date for incremental tariffs.

[0001032975-25-000029:mdna:163]
If we are not successful in launching and phasing in our new products, or market competition increases, or we are not able to sell the new products at the prices planned, it could have a material impact on our sales, gross profit, operating results including operating cash flow, and inventory turnover in the future.

[0001032975-25-000029:mdna:164]
The following table summarizes our consolidated statement of cash flows for the year ended March 31, 2025 (in thousands):

[0001032975-25-000029:mdna:165]
|  |  | Year ended March 31, 2025 |  |  |
| Net cash provided by operating activities |  | $ | 842,557 |  |  |  |
| Net cash used in investing activities |  | (57,268) |  |  |  |
| Net cash used in financing activities |  | (797,360) |  |  |  |
| Effect of exchange rate changes on cash and cash equivalents |  | (5,566) |  |  |  |
| Net decrease in cash and cash equivalents |  | $ | (17,637) |  |  |  |

[0001032975-25-000029:mdna:166]
For fiscal year 2025, net cash provided by operating activities was $842.6 million resulting from net income of $631.5 million, a favorable impact from adding back non-cash adjustments totaling $228.4 million, and an  unfavorable net change in operating assets and liabilities of $17.3 million. Non-cash adjustments were primarily related to share-based compensation expense, depreciation and amortization, and deferred income taxes. The increase in inventories was primarily due to higher inventory purchases to align with demand. The decrease in accounts receivable, net, was primarily driven by the timing of sales within the quarter. The decrease in accounts payable was primarily driven by the timing of inventory purchases. The increase in accrued and other liabilities was primarily driven by higher income tax payable and higher performance-based compensation accrual due to strong business performance as well as higher deferred revenue due to an increase in services bookings.

[0001032975-25-000029:mdna:167]
For fiscal year 2025, net cash used in investing activities was $57.3 million, primarily due to $56.1 million purchases of property, plant, and equipment. Our expenditures for property, plant and equipment during fiscal year 2025 were primarily for tooling and equipment, and computer hardware and software.

[0001032975-25-000029:mdna:168]
For fiscal year 2025, net cash used in financing activities was $797.4 million, primarily resulting from repurchases of our registered shares of $588.8 million, payments of cash dividends of $207.9 million, and tax

[0001032975-25-000029:mdna:169]
withholdings related to net share settlements of restricted stock units of $32.5 million, partially offset by proceeds from exercise of stock options and purchase rights of $36.4 million.

[0001032975-25-000029:mdna:170]
During fiscal year 2025, the effect of exchange rate changes on cash and cash equivalents was not material.

[0001032975-25-000029:mdna:171]
Cash Outlook

[0001032975-25-000029:mdna:172]
Our principal sources of liquidity are our cash and cash equivalents, cash flow generated from operations and, to a much lesser extent, capital markets and borrowings. Our future working capital requirements and capital expenditures may increase to support investments in product innovations and growth opportunities or to acquire or invest in complementary businesses, products, services, and technologies. Our principal uses of cash, aside from operational needs and capital expenditures, include outlays for dividends and share repurchases reflecting our commitment to return value to our shareholders.

[0001032975-25-000029:mdna:173]
In May 2025, the Board of Directors recommended that we pay cash dividends for fiscal year 2025 of CHF 1.26 per share (approximately $1.43 per share based on the exchange rate on March 31, 2025). Based on our shares outstanding, net of treasury shares, as of March 31, 2025 (148,509,018 shares), this would result in an aggregate gross dividend of approximately CHF 187.1 million (approximately $212.4 million based on the exchange rate on March 31, 2025). In fiscal year 2025, we paid a cash dividend of CHF 1.16 per share, or CHF 176.3 million (U.S. Dollar amount of $207.9 million based on the exchange rate on the date of payment) out of fiscal year 2024 retained earnings. In fiscal year 2024, we paid a cash dividend of CHF 1.06 per share, or CHF 169.1 million (U.S. Dollar amount of $182.3 million based on the exchange rate on the date of payment) out of fiscal year 2023 retained earnings.

[0001032975-25-000029:mdna:174]
In June 2023, our Board of Directors approved a three-year share repurchase program, which allows us to use up to $1.0 billion to repurchase our shares. The 2023 share repurchase program enables us to repurchase shares for cancellation, as well as to support equity incentive plans or potential acquisitions. The Swiss Takeover Board approved the 2023 share repurchase program in July 2023 and the program became effective on July 28, 2023. During the fiscal year ended March 31, 2025, we repurchased 6.7 million shares for an aggregate cost of $588.0 million, under the 2023 share repurchase program for cancellation, of which $18.7 million of the aggregate cost was not paid yet as of March 31, 2025. As of March 31, 2025, $48.3 million was available for repurchase under the 2023 share repurchase program.

[0001032975-25-000029:mdna:175]
In March 2025, our Board of Directors approved an increase of $600.0 million to the 2023 share repurchase program, to an aggregate amount of $1.6 billion. The Swiss Takeover Board approved this increase in April 2025 and it became effective on April 2, 2025. We plan to target share repurchases of $2 billion over the next three years, subject to market conditions and regulatory approvals.

[0001032975-25-000029:mdna:176]
Swiss law limits a company’s ability to hold or repurchase its own shares. The aggregate par value of all shares held in treasury by us and our subsidiaries may not exceed 10% of our issued share capital, which corresponds to approximately 16.9 million registered shares as of March 31, 2025. This limitation does not apply to shares repurchased for cancellation, due to the Board of Directors' authority under the capital band set forth in the Company's Articles of Incorporation. As of March 31 2025, we had a total of 20.5 million shares held in treasury stock, which includes 6.7 million shares that have been repurchased for cancellation and 13.8 million shares that have been purchased to support equity incentive plans or potential acquisitions.

[0001032975-25-000029:mdna:177]
Although we enter into trading plans for systematic repurchases (e.g., 10b5-1 trading plans) from time to time, our 2023 share repurchase program provides us with the opportunity to make opportunistic repurchases during periods of favorable market conditions and is expected to remain in effect for a period of three years through July 27, 2026. To the extent that the shares are repurchased to support equity incentive plans or potential acquisitions, the shares are repurchased on the ordinary trading line of Swiss Exchange ("SIX") and/or the Nasdaq Global Select Market ("Nasdaq"). Shares repurchased for cancellation purposes are repurchased via a second trading line on SIX. Opportunistic purchases may be started or stopped at any time without prior notice depending on market conditions and other factors.

[0001032975-25-000029:mdna:178]
For over ten years, we have generated positive cash flows from our operating activities, including cash from operations of $842.6 million and $1,145.1 million during fiscal years 2025 and 2024, respectively. If we do not generate sufficient operating cash flows to support our operations and future planned cash requirements, our operations could be harmed and our access to credit facilities could be restricted or eliminated. Although we believe that the trend of our historical cash flow generation, our projections of future operations and our available cash balances will provide sufficient liquidity to fund our operations for at least the next 12 months, market volatility driven

[0001032975-25-000029:mdna:179]
by the current macroeconomic and geopolitical environment may increase our costs of capital and otherwise adversely affect our business, results of operations, financial condition and liquidity.

[0001032975-25-000029:mdna:180]
Our other contractual obligations and commitments that require cash are described in the following sections.

[0001032975-25-000029:mdna:181]
Contractual Obligations and Commitments

[0001032975-25-000029:mdna:182]
Purchase Commitments

[0001032975-25-000029:mdna:183]
As of March 31, 2025, we had non-cancelable purchase commitments of $358.7 million for inventory purchases made in the normal course of business from original design manufacturers, contract manufacturers and other suppliers, the majority of which are expected to be fulfilled within the next 12 months. We recorded a liability for firm, non-cancelable, and unhedged inventory purchase commitments in excess of anticipated demand or net realizable value consistent with our valuation of excess and obsolete inventory. As of March 31, 2025, the liability for these purchase commitments was $19.6 million and is recorded in accrued and other current liabilities in the consolidated balance sheet.

[0001032975-25-000029:mdna:184]
We have firm purchase commitments of $19.1 million for capital expenditures primarily related to commitments for tooling and equipment for new and existing products. We expect to continue making capital expenditures in the future to support product development activities and ongoing and expanded operations. Although open purchase commitments are considered enforceable and legally binding, the terms generally allow us to reschedule or adjust our requirements based on business needs prior to delivery of goods or performance of services.

[0001032975-25-000029:mdna:185]
Operating Leases Obligations

[0001032975-25-000029:mdna:186]
We lease facilities under operating leases, certain of which require us to pay property taxes, insurance and maintenance costs. Operating leases for facilities are generally renewable at our option and usually include escalation clauses linked to inflation. The remaining terms of our non-cancelable operating leases expire in various years through 2035. See Note 17 - Leases in our Notes to the consolidated financial statements included in this report for more information on leases.

[0001032975-25-000029:mdna:187]
Income Taxes Payable

[0001032975-25-000029:mdna:188]
As of March 31, 2025, we had $88.5 million in non-current income taxes payable, including interest and penalties, related to our income tax liability for uncertain tax positions. At this time, we are unable to make a reasonably reliable estimate of the timing of payments in individual years in connection with these tax liabilities.

[0001032975-25-000029:mdna:189]
Indemnifications

[0001032975-25-000029:mdna:190]
We indemnify certain suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of March 31, 2025, no material amounts have been accrued for indemnification provisions. We do not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under our indemnification arrangements.

[0001032975-25-000029:mdna:191]
We also indemnify our current and former directors and certain current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. We are unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not capped, the obligations are conditional in nature, and the facts and circumstances involved in any situation that might arise are variable.
