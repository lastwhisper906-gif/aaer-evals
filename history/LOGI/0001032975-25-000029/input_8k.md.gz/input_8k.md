# LOGI 8-K — 0001032975-25-000022 filed 2025-04-29

## item codes, every 8-K on or before 2025-05-23

- 2025-04-29 0001032975-25-000022 — 2.02, 9.01
- 2025-04-10 0001032975-25-000018 — 2.02, 9.01
- 2025-03-03 0001032975-25-000011 — 5.02, 9.01
- 2025-01-28 0001032975-25-000005 — 1.01, 2.02, 2.03, 9.01
- 2024-10-22 0001032975-24-000072 — 2.02, 9.01
- 2024-10-11 0001032975-24-000069 — 5.03, 9.01
- 2024-09-09 0001032975-24-000065 — 5.07, 8.01
- 2024-08-06 0001032975-24-000062 — 5.02, 9.01
- 2024-07-23 0001032975-24-000042 — 2.02, 9.01
- 2024-07-01 0001032975-24-000033 — 5.02, 8.01, 9.01
- 2024-06-13 0001032975-24-000030 — 5.02, 9.01
- 2024-04-30 0001032975-24-000015 — 2.02, 9.01
- 2024-03-18 0001032975-24-000012 — 5.02, 7.01, 9.01
- 2024-01-23 0001032975-24-000004 — 2.02, 9.01
- 2023-10-30 0001032975-23-000082 — 5.02, 9.01
- 2023-10-24 0001032975-23-000075 — 2.02, 9.01
- 2023-09-15 0001032975-23-000072 — 5.07, 8.01
- 2023-07-25 0001032975-23-000050 — 2.02, 9.01
- 2023-06-30 0001032975-23-000037 — 5.02 — amendment, the index does not say of what
- 2023-06-30 0001032975-23-000036 — 5.02
- 2023-06-13 0001032975-23-000030 — 5.02, 7.01, 9.01
- 2023-05-02 0001032975-23-000015 — 2.02, 9.01
- 2023-01-30 0001032975-23-000010 — 5.02, 9.01
- 2023-01-24 0001032975-23-000004 — 2.02, 5.02, 9.01
- 2023-01-12 0001628280-23-000934 — 2.02, 9.01
- 2022-10-25 0001628280-22-026927 — 2.02, 5.02, 9.01
- 2022-09-16 0001628280-22-025080 — 5.07, 8.01
- 2022-07-26 0001032975-22-000027 — 2.02, 9.01
- 2022-06-29 0001032975-22-000018 — 5.02
- 2022-05-03 0001032975-22-000008 — 2.02, 9.01
- 2022-01-25 0001032975-22-000003 — 2.02, 9.01
- 2021-10-26 0001032975-21-000043 — 2.02, 9.01
- 2021-09-10 0001032975-21-000040 — 5.07, 8.01
- 2021-07-27 0001032975-21-000029 — 2.02, 9.01
- 2021-04-29 0001032975-21-000012 — 2.02, 9.01
- 2021-01-19 0001032975-21-000004 — 2.02, 9.01
- 2020-10-20 0001032975-20-000045 — 2.02, 9.01
- 2020-09-11 0001032975-20-000042 — 5.07, 8.01
- 2020-07-21 0001032975-20-000029 — 2.02, 9.01
- 2020-07-01 0001032975-20-000023 — 5.02, 8.01
- 2020-05-12 0001032975-20-000011 — 2.02, 9.01
- 2020-03-30 0001032975-20-000009 — 5.02
- 2020-01-21 0001032975-20-000002 — 2.02, 9.01
- 2019-10-22 0001032975-19-000071 — 9.01
- 2019-09-26 0001032975-19-000068 — 1.01, 7.01, 9.01
- 2019-09-06 0001032975-19-000063 — 5.07, 8.01
- 2019-07-23 0001032975-19-000046 — 2.02, 9.01
- 2019-07-23 0001032975-19-000045 — 5.02, 9.01
- 2019-07-02 0001032975-19-000036 — 5.02
- 2019-06-25 0001032975-19-000034 — 5.02
- 2019-05-03 0001032975-19-000021 — 5.02 — amendment, the index does not say of what
- 2019-04-30 0001032975-19-000017 — 2.02, 5.02, 9.01
- 2019-03-28 0001032975-19-000013 — 5.02
- 2019-01-22 0001032975-19-000004 — 2.02, 9.01
- 2018-10-23 0001032975-18-000044 — 2.02, 9.01
- 2018-09-07 0001032975-18-000040 — 5.07, 8.01
- 2018-07-31 0001032975-18-000035 — 1.01, 2.02, 2.05, 7.01, 9.01
- 2018-06-27 0001032975-18-000020 — 5.02
- 2018-05-03 0001032975-18-000013 — 2.02, 5.02, 9.01
- 2018-01-23 0001032975-18-000005 — 2.02, 9.01
- 2017-10-24 0001032975-17-000043 — 2.02, 9.01
- 2017-09-18 0001032975-17-000040 — 5.07, 8.01
- 2017-07-25 0001032975-17-000028 — 2.02, 9.01
- 2017-07-12 0001032975-17-000022 — 1.01
- 2017-04-26 0001032975-17-000012 — 2.02, 9.01
- 2017-01-25 0001032975-17-000002 — 2.02, 9.01
- 2016-10-26 0001032975-16-000103 — 2.02, 9.01
- 2016-09-13 0001032975-16-000101 — 5.07, 8.01
- 2016-07-28 0001032975-16-000092 — 2.02, 9.01
- 2016-06-30 0001032975-16-000087 — 5.02
- 2016-04-28 0001032975-16-000077 — 2.02, 9.01
- 2016-04-14 0001032975-16-000073 — 1.01, 7.01, 9.01
- 2016-01-21 0001032975-16-000064 — 2.02, 9.01
- 2016-01-04 0001032975-16-000061 — 1.01, 2.01, 9.01
- 2015-12-23 0001032975-15-000059 — 5.02
- 2015-10-22 0001032975-15-000047 — 2.02, 9.01
- 2015-09-11 0001032975-15-000044 — 5.07, 8.01
- 2015-07-24 0001032975-15-000034 — 2.05 — amendment of 0001032975-15-000030
- 2015-07-23 0001032975-15-000030 — 2.02, 9.01
- 2015-06-25 0001032975-15-000025 — 5.02
- 2015-05-14 0001032975-15-000011 — 8.01, 9.01
- 2015-04-23 0001032975-15-000008 — 2.02, 2.05
- 2015-01-22 0001628280-15-000191 — 2.02, 8.01
- 2014-12-23 0001193125-14-450908 — 5.02, 5.07, 8.01
- 2014-11-25 0001193125-14-425233 — 3.01
- 2014-11-13 0001193125-14-411303 — 4.01, 9.01
- 2014-10-23 0001104659-14-073164 — 2.02, 9.01
- 2014-09-04 0001193125-14-331214 — 4.02, 9.01
- 2014-08-18 0001193125-14-313346 — 3.01, 9.01
- 2014-07-24 0001104659-14-053065 — 2.02, 9.01
- 2014-06-05 0001193125-14-226177 — 3.01, 9.01
- 2014-05-22 0001193125-14-208777 — 8.01, 9.01
- 2014-04-24 0001104659-14-029650 — 2.02, 9.01
- 2014-01-23 0001104659-14-003619 — 2.02, 9.01
- 2013-10-24 0001104659-13-077404 — 2.02, 9.01
- 2013-09-09 0001193125-13-361441 — 5.02, 5.07, 8.01, 9.01
- 2013-09-06 0001193125-13-359930 — 5.02, 9.01
- 2013-08-02 0001193125-13-317343 — 5.02
- 2013-07-25 0001104659-13-056372 — 2.02, 9.01
- 2013-06-28 0001193125-13-277394 — 5.02, 9.01
- 2013-06-20 0001193125-13-265914 — 8.01, 9.01
- 2013-04-25 0001104659-13-032570 — 2.02, 9.01
- 2013-04-17 0001193125-13-158923 — 5.02, 9.01
- 2013-03-01 0001193125-13-085804 — 2.05
- 2013-01-24 0001104659-13-004214 — 2.02, 9.01
- 2013-01-02 0001193125-13-000058 — 5.02
- 2012-10-25 0001104659-12-070966 — 2.02, 9.01
- 2012-09-11 0001193125-12-388070 — 5.02, 5.07, 8.01, 9.01
- 2012-08-22 0001193125-12-364167 — 5.02, 8.01, 9.01
- 2012-07-26 0001104659-12-051084 — 2.02, 9.01
- 2012-06-08 0001193125-12-264132 — 2.05, 9.01 — amendment, the index does not say of what
- 2012-04-26 0001193125-12-183657 — 5.02, 9.01
- 2012-04-26 0001104659-12-028470 — 2.02, 2.05, 9.01
- 2012-03-15 0001193125-12-115954 — 5.02, 9.01
- 2012-01-26 0001104659-12-004014 — 2.02, 9.01
- 2012-01-04 0001193125-12-002212 — 1.01, 2.03, 9.01
- 2011-10-27 0001104659-11-058150 — 2.02, 9.01
- 2011-09-12 0001193125-11-245931 — 5.07
- 2011-07-28 0001193125-11-200929 — 5.02, 9.01
- 2011-07-28 0001193125-11-199704 — 2.02, 9.01
- 2011-04-28 0001193125-11-112669 — 2.02, 9.01
- 2011-03-24 0001193125-11-076483 — 5.02, 9.01
- 2011-01-27 0001032975-11-000003 — 9.01
- 2010-10-28 0001032975-10-000032 — 9.01
- 2010-09-13 0001032975-10-000022 — 5.07
- 2010-07-29 0001032975-10-000010 — 2.02, 9.01
- 2010-06-10 0001193125-10-136877 — 5.02, 9.01
- 2010-05-03 0001193125-10-104337 — 5.02
- 2010-04-29 0001032975-10-000008 — 2.02, 9.01
- 2010-02-19 0001032975-10-000006 — 9.01 — amendment of 0001193125-09-252416
- 2010-01-21 0001032975-10-000002 — 2.02, 9.01
- 2009-12-14 0001193125-09-252416 — 2.01, 9.01
- 2009-11-17 0001032975-09-000023 — 1.01
- 2009-10-22 0001032975-09-000018 — 9.01
- 2009-09-22 0001193125-09-195545 — 5.02, 9.01
- 2009-09-03 0001032975-09-000013 — 8.01
- 2009-07-23 0001140361-09-016802 — 2.02, 9.01
- 2009-06-01 0001193125-09-122550 — 5.02
- 2009-04-23 0001193125-09-085054 — 2.02, 9.01
- 2009-04-02 0001193125-09-071272 — 5.02, 9.01
- 2009-01-20 0001193125-09-008454 — 2.05 — amendment of 0001193125-09-002609
- 2009-01-20 0001193125-09-007902 — 2.02, 9.01
- 2009-01-07 0001193125-09-002609 — 2.05, 9.01
- 2009-01-07 0001193125-09-002370 — 5.02, 9.01
- 2008-12-09 0001193125-08-250543 — 5.02, 9.01
- 2008-10-21 0001193125-08-213212 — 2.02, 9.01
- 2008-07-22 0001193125-08-154721 — 2.02, 9.01
- 2008-06-24 0001193125-08-139163 — 5.03, 9.01
- 2008-05-13 0001193125-08-113263 — 5.02, 9.01
- 2008-04-22 0001193125-08-086176 — 2.02, 9.01

## late-filing notifications on or before 2025-05-23

- 2015-06-02 0001032975-15-000020 — NT 10-K, for the period ended 2015-03-31
- 2014-11-06 0001193125-14-401306 — NT 10-Q, for the period ended 2014-09-30
- 2014-07-24 0001193125-14-277575 — NT 10-Q, for the period ended 2014-06-30
- 2014-05-22 0001193125-14-208712 — NT 10-K, for the period ended 2014-03-31
- 2009-08-06 0001032975-09-000006 — NT 10-Q, for the period ended 2009-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001032975-25-000022:8k_2_02:1]
EX-99.1
2
exhibit991q4fy25.htm
EX-99.1

[0001032975-25-000022:8k_2_02:2]
Document

[0001032975-25-000022:8k_2_02:3]
Exhibit 99.1

[0001032975-25-000022:8k_2_02:4]
Editorial Contacts:

[0001032975-25-000022:8k_2_02:5]
Kate Beerkens, Director of Investor Relations - ir@logitech.com

[0001032975-25-000022:8k_2_02:6]
Nicole Kenyon, Head of Global Communications - nkenyon@logitech.com (USA)

[0001032975-25-000022:8k_2_02:7]
Ben Starkie, Corporate Communications - +41 (0) 79-292-3499, bstarkie1@logitech.com (Europe/AP)

[0001032975-25-000022:8k_2_02:8]
Logitech Announces Q4 and Full Fiscal Year 2025 Results

[0001032975-25-000022:8k_2_02:9]
A Year of Broad-Based Sales Growth, Expanded Market Share

[0001032975-25-000022:8k_2_02:10]
and Increased Profitability, Driven by Strategic Priorities

[0001032975-25-000022:8k_2_02:11]
LAUSANNE, Switzerland, and SAN JOSE, Calif., Apr. 29, 2025 — SIX Swiss Exchange Ad hoc announcement pursuant to Art. 53 LR — Logitech International (SIX: LOGN) (Nasdaq: LOGI) today announced financial results for the fourth quarter and full Fiscal Year 2025 ended March 31, 2025.

[0001032975-25-000022:8k_2_02:12]
For Fiscal Year 2025:

[0001032975-25-000022:8k_2_02:13]
•Sales were $4.55 billion, up 6 percent in US dollars and 7 percent in constant currency, compared to the prior year.

[0001032975-25-000022:8k_2_02:14]
•GAAP operating income was $655 million, up 11 percent compared to the prior year. Non-GAAP operating income was $775 million, up 11 percent compared to the prior year.

[0001032975-25-000022:8k_2_02:15]
•GAAP earnings per share (EPS) was $4.13, up 7 percent compared to the prior year. Non-GAAP EPS was $4.84, up 14 percent compared to the prior year.

[0001032975-25-000022:8k_2_02:16]
•Cash flow from operations was $843 million. The year-ending cash balance was $1.5 billion. The Company returned $797 million of cash to shareholders through its annual dividend payment and share repurchases.

[0001032975-25-000022:8k_2_02:17]
For Q4 Fiscal Year 2025:

[0001032975-25-000022:8k_2_02:18]
•Sales were $1.01 billion, flat in US dollars and up 2 percent in constant currency, compared to Q4 of the prior year.

[0001032975-25-000022:8k_2_02:19]
•GAAP operating income was $106 million, down 19 percent, compared to Q4 of the prior year. Non-GAAP operating income was $133 million, down 16 percent, compared to Q4 of the prior year. This was due to a bad debt expense and strategic investments made in the quarter.

[0001032975-25-000022:8k_2_02:20]
•GAAP earnings per share (EPS) was $0.96, down 10 percent compared to Q4 prior year. Non-GAAP EPS was $0.93, down 6 percent compared to the prior year.

[0001032975-25-000022:8k_2_02:21]
•Cash flow from operations was $130 million.

[0001032975-25-000022:8k_2_02:22]
“Fiscal Year 2025 was an outstanding year of broad-based sales growth, driven by our strategic priorities,” said Hanneke Faber, Logitech chief executive officer. “Thanks to our diverse global footprint, strong brand and resilient operations, we are in a strong position to navigate the unpredictable market conditions ahead in Fiscal Year 2026. In this dynamic environment, we will focus on three core principles - playing offense, disciplined cost control and agility.”

[0001032975-25-000022:8k_2_02:23]
“Our teams executed impressively once again this Q4, completing a year of strong operational discipline,” said Matteo Anversa, Logitech chief financial officer. “We closed Fiscal Year 2025 with robust growth across all regions, customer channels and in nearly all our categories. Our growth continued to be extremely profitable, with non-GAAP gross margins at 43.5%. We were pleased to return $797 million of cash to shareholders in the year.”

[0001032975-25-000022:8k_2_02:24]
Outlook

[0001032975-25-000022:8k_2_02:25]
Earlier this month, Logitech communicated that the Company has withdrawn its outlook for Fiscal Year 2026 due to the continuing uncertainty surrounding the tariff environment. The Company today announced an outlook for Q1 FY 2026:

[0001032975-25-000022:8k_2_02:26]
|  | Q1 FY26 outlook |
| Sales | $1,100 - $1,150 million |
| Sales growth (in US dollars, year over year) | 1% - 6% |
| Sales growth (in constant currency, year over year) | 0% - 5% |
| Non-GAAP operating income | $155 - $185 million |
| Non-GAAP op. inc. growth/(decline) (year over year) | (15%) - 1% |

[0001032975-25-000022:8k_2_02:27]
Financial Results Videoconference and Webcast

[0001032975-25-000022:8k_2_02:28]
Logitech will hold a financial results videoconference to discuss the results for Q4 and the full Fiscal Year 2025 on Tuesday, April 29, 2025 at 1:30 p.m. Pacific Daylight Time (PDT) and 10:30 p.m. Central European Summer Time (CEST).

[0001032975-25-000022:8k_2_02:29]
A livestream of the event will be available on the Logitech corporate website at https://ir.logitech.com. This press release and the Q4 Fiscal Year 2025 Shareholder Letter are also available there.

[0001032975-25-000022:8k_2_02:30]
Use of Non-GAAP Financial Information and Constant Currency

[0001032975-25-000022:8k_2_02:31]
To facilitate comparisons to Logitech’s historical results, Logitech has included non-GAAP adjusted measures in this press release, which exclude share-based compensation expense, amortization and impairment of intangible assets, acquisition-related costs, restructuring charges (credits), net, change in fair value of contingent consideration for business acquisition, loss (gain) on investments, non-GAAP income tax adjustment, and other items detailed under “Supplemental Financial Information” after the tables below and posted to our website at https://ir.logitech.com. Logitech also presents percentage sales growth in constant currency (“cc”), a non-GAAP measure, to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales. Logitech believes this information, used together with the GAAP financial information, will help investors to evaluate its current period performance and trends in its business. With respect to the Company's outlook for non-GAAP operating income, most of the excluded amounts pertain to events that have not yet occurred and are not currently possible to estimate with a reasonable degree of accuracy. Therefore, no reconciliation to the GAAP amounts has been provided for the first quarter of Fiscal Year 2026 non-GAAP outlook.

[0001032975-25-000022:8k_2_02:32]
Public Dissemination of Certain Information

[0001032975-25-000022:8k_2_02:33]
Recordings of Logitech’s earnings videoconferences and certain events Logitech participates in or hosts, with members of the investment community are posted on the company’s investor relations website at https://ir.logitech.com. Additionally, Logitech provides notifications of news or announcements regarding its operations and financial performance, including its filings with the Securities and Exchange Commission (SEC), investor events, and press and earnings releases as part of its investor relations website. Logitech intends to use its investor relations website as means of disclosing material nonpublic information and for complying with its disclosure obligations under Regulation FD. Logitech’s corporate governance information also is available on its investor relations website.

[0001032975-25-000022:8k_2_02:34]
About Logitech

[0001032975-25-000022:8k_2_02:35]
Logitech designs software-enabled hardware solutions that help businesses thrive and bring people together when working, creating, and gaming. As the point of connection between people and the digital world, our mission is to extend human potential in work and play, in a way that is good for people and the planet. Founded in 1981, Logitech International is a Swiss public company listed on the SIX Swiss Exchange (LOGN) and on the Nasdaq Global Select Market (LOGI). Find Logitech and its other brands, including Logitech G, at www.logitech.com or company blog.

[0001032975-25-000022:8k_2_02:36]
# # #

[0001032975-25-000022:8k_2_02:37]
Note that unless noted otherwise, comparisons are year over year.

[0001032975-25-000022:8k_2_02:38]
Logitech and other Logitech marks are trademarks or registered trademarks of Logitech Europe S.A. and/or its affiliates in the U.S. and other countries. All other trademarks are the property of their respective owners. For more information about Logitech and its products, visit the company’s website at www.logitech.com.

[0001032975-25-000022:8k_2_02:39]
(LOGIIR)

[0001032975-25-000022:8k_2_02:40]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  | Fiscal Years Ended |
|  |  | March 31, |  | March 31, |
| GAAP CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net sales |  | $ | 1,010,355 |  |  | $ | 1,011,487 |  |  | $ | 4,554,900 |  |  | $ | 4,298,467 |  |
| Cost of goods sold |  | 572,334 |  |  | 572,051 |  |  | 2,582,745 |  |  | 2,509,418 |  |
| Amortization of intangible assets |  | 2,210 |  |  | 2,459 |  |  | 9,554 |  |  | 11,028 |  |
| Gross profit |  | 435,811 |  |  | 436,977 |  |  | 1,962,601 |  |  | 1,778,021 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Marketing and selling |  | 198,598 |  |  | 185,594 |  |  | 814,414 |  |  | 730,310 |  |
| Research and development |  | 79,523 |  |  | 75,421 |  |  | 309,008 |  |  | 287,243 |  |
| General and administrative |  | 40,266 |  |  | 38,510 |  |  | 164,014 |  |  | 155,056 |  |
| Amortization of intangible assets and acquisition-related costs |  | 2,630 |  |  | 2,655 |  |  | 10,695 |  |  | 10,934 |  |
| Impairment of intangible assets |  | — |  |  | 3,526 |  |  | — |  |  | 3,526 |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | (250) |  |  | — |  |  | (250) |  |
| Restructuring charges, net |  | 8,890 |  |  | 1,304 |  |  | 9,615 |  |  | 3,866 |  |
| Total operating expenses |  | 329,907 |  |  | 306,760 |  |  | 1,307,746 |  |  | 1,190,685 |  |
| Operating income |  | 105,904 |  |  | 130,217 |  |  | 654,855 |  |  | 587,336 |  |
| Interest income |  | 12,394 |  |  | 16,128 |  |  | 54,997 |  |  | 50,636 |  |
| Other income (expense), net |  | (91) |  |  | (2,549) |  |  | (2,980) |  |  | (16,376) |  |
| Income before income taxes |  | 118,207 |  |  | 143,796 |  |  | 706,872 |  |  | 621,596 |  |
| Provision for (benefit from) income taxes |  | (25,859) |  |  | (23,819) |  |  | 75,343 |  |  | 9,453 |  |
| Net income |  | $ | 144,066 |  |  | $ | 167,615 |  |  | $ | 631,529 |  |  | $ | 612,143 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.97 |  |  | $ | 1.09 |  |  | $ | 4.17 |  |  | $ | 3.90 |  |
| Diluted |  | $ | 0.96 |  |  | $ | 1.07 |  |  | $ | 4.13 |  |  | $ | 3.87 |  |
| Weighted average shares used to compute net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | 148,999 |  |  | 154,452 |  |  | 151,322 |  |  | 156,776 |  |
| Diluted |  | 150,709 |  |  | 156,204 |  |  | 152,784 |  |  | 158,171 |  |

[0001032975-25-000022:8k_2_02:41]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
|  |  | March 31, |  | March 31, |  |  |  |  |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  | 2025 |  | 2024 |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,503,205 |  |  | $ | 1,520,842 |  |  |  |  |  |
| Accounts receivable, net |  | 454,546 |  |  | 541,715 |  |  |  |  |  |
| Inventories |  | 503,747 |  |  | 422,513 |  |  |  |  |  |
| Other current assets |  | 131,211 |  |  | 146,270 |  |  |  |  |  |
| Total current assets |  | 2,592,709 |  |  | 2,631,340 |  |  |  |  |  |
| Non-current assets: |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  | 113,858 |  |  | 116,589 |  |  |  |  |  |
| Goodwill |  | 463,230 |  |  | 461,978 |  |  |  |  |  |
| Other intangible assets, net |  | 24,630 |  |  | 44,603 |  |  |  |  |  |
| Other assets |  | 344,077 |  |  | 350,194 |  |  |  |  |  |
| Total assets |  | $ | 3,538,504 |  |  | $ | 3,604,704 |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 414,586 |  |  | $ | 448,627 |  |  |  |  |  |
| Accrued and other current liabilities |  | 686,503 |  |  | 637,262 |  |  |  |  |  |
| Total current liabilities |  | 1,101,089 |  |  | 1,085,889 |  |  |  |  |  |
| Non-current liabilities: |  |  |  |  |  |  |  |  |
| Income taxes payable |  | 88,483 |  |  | 112,572 |  |  |  |  |  |
| Other non-current liabilities |  | 221,512 |  |  | 172,590 |  |  |  |  |  |
| Total liabilities |  | 1,411,084 |  |  | 1,371,051 |  |  |  |  |  |
| Shareholders' equity: |  |  |  |  |  |  |  |  |
| Registered shares, CHF 0.25 par valueIssued shares: 168,994 and 173,106 at March 31, 2025 and 2024, respectively |  | 29,432 |  |  | 30,148 |  |  |  |  |  |
| Additional paid-in capital |  | 82,591 |  |  | 63,524 |  |  |  |  |  |
| Shares in treasury, at cost — 20,485 and 19,243 shares at March 31, 2025and 2024, respectively |  | (1,464,912) |  |  | (1,351,336) |  |  |  |  |  |
| Retained earnings |  | 3,627,261 |  |  | 3,602,519 |  |  |  |  |  |
| Accumulated other comprehensive loss |  | (146,952) |  |  | (111,202) |  |  |  |  |  |
| Total shareholders' equity |  | 2,127,420 |  |  | 2,233,653 |  |  |  |  |  |
| Total liabilities and shareholders' equity |  | $ | 3,538,504 |  |  | $ | 3,604,704 |  |  |  |  |  |

[0001032975-25-000022:8k_2_02:42]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  | Fiscal Years Ended |
|  |  | March 31, |  | March 31, |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 144,066 |  |  | $ | 167,615 |  |  | $ | 631,529 |  |  | $ | 612,143 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  | 15,486 |  |  | 14,191 |  |  | 59,664 |  |  | 63,065 |  |
| Amortization of intangible assets |  | 4,840 |  |  | 5,098 |  |  | 20,098 |  |  | 21,681 |  |
| Impairment of intangible assets |  | — |  |  | 3,526 |  |  | — |  |  | 3,526 |  |
| Loss on investments |  | 311 |  |  | 2,461 |  |  | 2,029 |  |  | 14,674 |  |
| Share-based compensation expense |  | 13,846 |  |  | 18,697 |  |  | 89,913 |  |  | 82,889 |  |
| Deferred income taxes |  | 37,891 |  |  | (32,909) |  |  | 56,543 |  |  | (42,424) |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | (250) |  |  | — |  |  | (250) |  |
| Other |  | (10) |  |  | 43 |  |  | 120 |  |  | 379 |  |
| Changes in assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | 197,913 |  |  | 138,305 |  |  | 69,979 |  |  | 91,519 |  |
| Inventories |  | (12,947) |  |  | 21,827 |  |  | (80,501) |  |  | 259,796 |  |
| Other assets |  | 14,554 |  |  | 7,062 |  |  | 23,970 |  |  | 10,760 |  |
| Accounts payable |  | (168,475) |  |  | (81,047) |  |  | (31,627) |  |  | 39,336 |  |
| Accrued and other liabilities |  | (117,819) |  |  | (25,514) |  |  | 840 |  |  | (11,978) |  |
| Net cash provided by operating activities |  | 129,656 |  |  | 239,105 |  |  | 842,557 |  |  | 1,145,116 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  | (12,788) |  |  | (10,312) |  |  | (56,128) |  |  | (55,897) |  |
| Acquisitions, net of cash acquired |  | — |  |  | (286) |  |  | — |  |  | (14,424) |  |
| Purchases of deferred compensation investments |  | (798) |  |  | (3,678) |  |  | (6,600) |  |  | (11,571) |  |
| Proceeds from sales of deferred compensation investments |  | 2,121 |  |  | 3,981 |  |  | 7,079 |  |  | 12,174 |  |
| Other investing activities |  | (446) |  |  | (211) |  |  | (1,619) |  |  | (617) |  |
| Net cash used in investing activities |  | (11,911) |  |  | (10,506) |  |  | (57,268) |  |  | (70,335) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Payment of cash dividends |  | — |  |  | — |  |  | (207,853) |  |  | (182,305) |  |
| Payment of contingent consideration for business acquisition |  | — |  |  | — |  |  | (1,245) |  |  | (5,002) |  |
| Purchases of registered shares |  | (125,516) |  |  | (127,428) |  |  | (588,838) |  |  | (504,203) |  |
| Proceeds from exercises of stock options and purchase rights |  | 16,170 |  |  | 16,878 |  |  | 36,405 |  |  | 32,197 |  |
| Tax withholdings related to net share settlements of restricted stock units |  | (10,234) |  |  | (1,148) |  |  | (32,485) |  |  | (29,744) |  |
| Other financing activities |  | (1,681) |  |  | — |  |  | (3,344) |  |  | (1,116) |  |
| Net cash used in financing activities |  | (121,261) |  |  | (111,698) |  |  | (797,360) |  |  | (690,173) |  |
| Effect of exchange rate changes on cash and cash equivalents |  | 3,889 |  |  | (8,709) |  |  | (5,566) |  |  | (12,789) |  |
| Net increase (decrease) in cash and cash equivalents |  | 373 |  |  | 108,192 |  |  | (17,637) |  |  | 371,819 |  |
| Cash and cash equivalents at beginning of the period |  | 1,502,832 |  |  | 1,412,650 |  |  | 1,520,842 |  |  | 1,149,023 |  |
| Cash and cash equivalents at end of the period |  | $ | 1,503,205 |  |  | $ | 1,520,842 |  |  | $ | 1,503,205 |  |  | $ | 1,520,842 |  |

[0001032975-25-000022:8k_2_02:43]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three Months Ended |  | Fiscal Years Ended |
|  |  | March 31, |  | March 31, |
| NET SALES |  | 2025 |  | 2024 |  | Change |  | 2025 |  | 2024 |  | Change |
| Net sales by product category: |  |  |  |  |  |  |  |  |  |  |  |  |
| Gaming (1) |  | $ | 261,807 |  |  | $ | 273,487 |  |  | (4) | % |  | $ | 1,338,467 |  |  | $ | 1,231,063 |  |  | 9 | % |
| Keyboards & Combos |  | 220,626 |  |  | 216,240 |  |  | 2 |  |  | 882,643 |  |  | 821,441 |  |  | 7 |  |
| Pointing Devices |  | 185,857 |  |  | 170,677 |  |  | 9 |  |  | 788,784 |  |  | 742,987 |  |  | 6 |  |
| Video Collaboration |  | 143,245 |  |  | 148,104 |  |  | (3) |  |  | 626,000 |  |  | 609,361 |  |  | 3 |  |
| Webcams |  | 77,948 |  |  | 75,952 |  |  | 3 |  |  | 315,520 |  |  | 325,225 |  |  | (3) |  |
| Tablet Accessories |  | 57,954 |  |  | 55,808 |  |  | 4 |  |  | 299,540 |  |  | 254,060 |  |  | 18 |  |
| Headsets |  | 42,672 |  |  | 45,455 |  |  | (6) |  |  | 179,710 |  |  | 168,478 |  |  | 7 |  |
| Other (2) |  | 20,246 |  |  | 25,764 |  |  | (21) |  |  | 124,236 |  |  | 145,852 |  |  | (15) |  |
| Total Net Sales |  | $ | 1,010,355 |  |  | $ | 1,011,487 |  |  | — | % |  | $ | 4,554,900 |  |  | $ | 4,298,467 |  |  | 6 | % |

[0001032975-25-000022:8k_2_02:44]
(1) Gaming includes streaming services revenue generated by Streamlabs.

[0001032975-25-000022:8k_2_02:45]
(2) Other primarily consists of mobile speakers and PC speakers.

[0001032975-25-000022:8k_2_02:46]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three Months Ended |  | Fiscal Years Ended |
|  |  | March 31, |  | March 31, |
| GAAP TO NON-GAAP RECONCILIATION (A) |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Gross profit - GAAP |  | $ | 435,811 |  | $ | 436,977 |  | $ | 1,962,601 |  | $ | 1,778,021 |
| Share-based compensation expense |  | 1,348 |  | 1,938 |  | 10,021 |  | 8,004 |
| Amortization of intangible assets |  | 2,210 |  | 2,459 |  | 9,554 |  | 11,028 |
| Gross profit - Non-GAAP |  | $ | 439,369 |  | $ | 441,374 |  | $ | 1,982,176 |  | $ | 1,797,053 |
| Gross margin - GAAP |  | 43.1% |  | 43.2% |  | 43.1% |  | 41.4% |
| Gross margin - Non-GAAP |  | 43.5% |  | 43.6% |  | 43.5% |  | 41.8% |
| Operating expenses - GAAP |  | $ | 329,907 |  | $ | 306,760 |  | $ | 1,307,746 |  | $ | 1,190,685 |
| Less: Share-based compensation expense |  | 12,498 |  | 16,759 |  | 79,892 |  | 74,885 |
| Less: Amortization of intangible assets and acquisition-related costs |  | 2,630 |  | 2,655 |  | 10,695 |  | 10,934 |
| Less: Impairment of intangible assets |  | — |  | 3,526 |  | — |  | 3,526 |
| Less: Change in fair value of contingent consideration for business acquisition |  | — |  | (250) |  | — |  | (250) |
| Less: Restructuring charges, net |  | 8,890 |  | 1,304 |  | 9,615 |  | 3,866 |
| Operating expenses - Non-GAAP |  | $ | 305,889 |  | $ | 282,766 |  | $ | 1,207,544 |  | $ | 1,097,724 |
| % of net sales - GAAP |  | 32.7% |  | 30.3% |  | 28.7% |  | 27.7% |
| % of net sales - Non-GAAP |  | 30.3% |  | 28.0% |  | 26.5% |  | 25.5% |
| Operating income - GAAP |  | $ | 105,904 |  | $ | 130,217 |  | $ | 654,855 |  | $ | 587,336 |
| Share-based compensation expense |  | 13,846 |  | 18,697 |  | 89,913 |  | 82,889 |
| Amortization of intangible assets and acquisition-related costs |  | 4,840 |  | 5,114 |  | 20,249 |  | 21,962 |
| Impairment of intangible assets |  | — |  | 3,526 |  | — |  | 3,526 |
| Change in fair value of contingent consideration for business acquisition |  | — |  | (250) |  | — |  | (250) |
| Restructuring charges, net |  | 8,890 |  | 1,304 |  | 9,615 |  | 3,866 |
| Operating income - Non-GAAP |  | $ | 133,480 |  | $ | 158,608 |  | $ | 774,632 |  | $ | 699,329 |
| % of net sales - GAAP |  | 10.5% |  | 12.9% |  | 14.4% |  | 13.7% |
| % of net sales - Non-GAAP |  | 13.2% |  | 15.7% |  | 17.0% |  | 16.3% |
| Net income - GAAP |  | $ | 144,066 |  | $ | 167,615 |  | $ | 631,529 |  | $ | 612,143 |
| Share-based compensation expense |  | 13,846 |  | 18,697 |  | 89,913 |  | 82,889 |
| Amortization of intangible assets and acquisition-related costs |  | 4,840 |  | 5,114 |  | 20,249 |  | 21,962 |
| Impairment of intangible assets |  | — |  | 3,526 |  | — |  | 3,526 |
| Change in fair value of contingent consideration for business acquisition |  | — |  | (250) |  | — |  | (250) |
| Restructuring charges, net |  | 8,890 |  | 1,304 |  | 9,615 |  | 3,866 |
| Loss on investments |  | 311 |  | 2,461 |  | 2,029 |  | 14,674 |
| Non-GAAP income tax adjustment |  | (32,225) |  | (44,039) |  | (13,405) |  | (66,073) |
| Net income - Non-GAAP |  | $ | 139,728 |  | $ | 154,428 |  | $ | 739,930 |  | $ | 672,737 |
| Net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  | $ | 0.96 |  | $ | 1.07 |  | $ | 4.13 |  | $ | 3.87 |
| Diluted - Non-GAAP |  | $ | 0.93 |  | $ | 0.99 |  | $ | 4.84 |  | $ | 4.25 |
| Shares used to compute net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP and Non-GAAP |  | 150,709 |  | 156,204 |  | 152,784 |  | 158,171 |

[0001032975-25-000022:8k_2_02:47]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three Months Ended |  | Fiscal Years Ended |
|  |  | March 31, |  | March 31, |
| SHARE-BASED COMPENSATION EXPENSE |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Share-based Compensation Expense |  |  |  |  |  |  |  |  |
| Cost of goods sold |  | $ | 1,348 |  |  | $ | 1,938 |  |  | $ | 10,021 |  |  | $ | 8,004 |  |
| Marketing and selling |  | 6,245 |  |  | 7,157 |  |  | 40,378 |  |  | 35,780 |  |
| Research and development |  | 4,331 |  |  | 4,268 |  |  | 20,180 |  |  | 17,836 |  |
| General and administrative |  | 1,922 |  |  | 5,334 |  |  | 19,334 |  |  | 21,269 |  |
| Total share-based compensation expense |  | 13,846 |  |  | 18,697 |  |  | 89,913 |  |  | 82,889 |  |
| Income tax benefit |  | (3,247) |  |  | (4,048) |  |  | (20,148) |  |  | (15,305) |  |
| Total share-based compensation expense, net of income tax benefit |  | $ | 10,599 |  |  | $ | 14,649 |  |  | $ | 69,765 |  |  | $ | 67,584 |  |

[0001032975-25-000022:8k_2_02:48]
*Note: These preliminary results for the three months and fiscal year ended March 31, 2025 are subject to adjustments, including subsequent events that may occur through the date of filing our Annual Report on Form 10-K.

[0001032975-25-000022:8k_2_02:49]
(A) Non-GAAP Financial Measures

[0001032975-25-000022:8k_2_02:50]
To supplement our condensed consolidated financial results prepared in accordance with GAAP, we use a number of financial measures, both GAAP and non-GAAP, in analyzing and assessing our overall business performance, for making operating decisions and for forecasting and planning future periods. We consider the use of non-GAAP financial measures helpful in assessing our current financial performance, ongoing operations and prospects for the future as well as understanding financial and business trends relating to our financial condition and results of operations.

[0001032975-25-000022:8k_2_02:51]
While we use non-GAAP financial measures as a tool to enhance our understanding of certain aspects of our financial performance and to provide incremental insight into the underlying factors and trends affecting both our performance and our cash-generating potential, we do not consider these measures to be a substitute for, or superior to, the information provided by GAAP financial measures. Consistent with this approach, we believe that disclosing non-GAAP financial measures to the readers of our financial statements provides useful supplemental data that, while not a substitute for GAAP financial measures, can offer insight in the review of our financial and operational performance and enables investors to more fully understand trends in our current and future performance. In assessing our business during the quarter and fiscal year ended March 31, 2025 and prior periods presented, we excluded items in the following general categories, each of which are described below:

[0001032975-25-000022:8k_2_02:52]
Share-based compensation expense. We believe that providing non-GAAP measures excluding share-based compensation expense, in addition to the GAAP measures, allows for a more transparent comparison of our financial results from period to period. We prepare and maintain our budgets and forecasts for future periods on a basis consistent with this non-GAAP financial measure. Further, companies use a variety of types of equity awards as well as a variety of methodologies, assumptions and estimates to determine share-based compensation expense. We believe that excluding share-based compensation expense enhances our ability and the ability of investors to understand the impact of non-cash share-based compensation on our operating results and to compare our results against the results of other companies.

[0001032975-25-000022:8k_2_02:53]
Amortization of intangible assets. We incur intangible asset amortization expense, primarily in connection with our acquisitions of various businesses and technologies. The amortization of purchased intangibles varies depending on the level of acquisition activity. We exclude these various charges in budgeting, planning and forecasting future periods and we believe that providing the non-GAAP measures excluding these various non-cash charges, as well as the GAAP measures, provides additional insight when comparing our gross profit, operating expenses, and financial results from period to period.

[0001032975-25-000022:8k_2_02:54]
Impairment of intangible assets. We may incur impairment of intangible assets expense, primarily in connection with our past business or asset acquisitions. We believe that providing the non-GAAP measures excluding these items, as well as the GAAP measures, assists our investors because such expenses are not reflective of our ongoing operating results.

[0001032975-25-000022:8k_2_02:55]
Acquisition-related costs and change in fair value of contingent consideration for business acquisition. We incurred expenses and credits in connection with our acquisitions which we generally would not have otherwise incurred in the periods presented as a part of our continuing operations. Acquisition-related costs include certain incremental expenses incurred to effect a business combination. Fair value of contingent consideration is associated with our estimates of the value of earn-outs in connection with certain acquisitions. We believe that providing the non-GAAP measures excluding these costs and credits, as well as the GAAP measures, assists our investors because such costs are not reflective of our ongoing operating results.

[0001032975-25-000022:8k_2_02:56]
Restructuring charges (credits), net. These charges (credits) are associated with restructuring plans, and will vary based on the initiatives in place during any given period. Restructuring charges may include costs related to employee terminations, facility closures and early cancellation of certain contracts as well as other costs resulting from our restructuring initiatives. We believe that providing the non-GAAP measures excluding these items, as well as the GAAP measures, assists our investors because such charges (credits) are not reflective of our ongoing operating results.

[0001032975-25-000022:8k_2_02:57]
Loss (gain) on investments. We recognize losses (gains) related to our investments in various companies, which vary depending on the operational and financial performance of the companies in which we invest. These amounts include our losses (earnings) on equity method investments, investment impairments and losses (gains) resulting from sales or other events related to our investments. We believe that providing the non-GAAP measures excluding these items, as well as the GAAP measures, assists our investors because such losses (gains) are not reflective of our ongoing operations.

[0001032975-25-000022:8k_2_02:58]
Non-GAAP income tax adjustment.  Non-GAAP income tax adjustment primarily measures the income tax effect of non-GAAP adjustments excluded above as well as the income tax impact of non-recurring deferred taxes, tax settlements, and other non-routine tax events, the determination of which is based upon the nature of the underlying items. For the fiscal year ended March 31, 2025, non-GAAP income tax adjustment included the tax benefit from a remeasurement of the tax basis of goodwill under the Swiss Federal Act on Tax Reform and AHV Financing (“TRAF”).

[0001032975-25-000022:8k_2_02:59]
Each of the non-GAAP financial measures described above, and used in this press release, should not be considered in isolation from, or as a substitute for, a measure of financial performance prepared in accordance with GAAP. Further, investors are cautioned that there are inherent limitations associated with the use of each of these non-GAAP financial measures as an analytical tool. In particular, these non-GAAP financial measures are not based on a comprehensive set of accounting rules or principles and many of the adjustments to the GAAP financial measures reflect the exclusion of items that are recurring and may be reflected in the Company’s financial results for the foreseeable future. We compensate for these limitations by providing specific information in the reconciliation included in this press release regarding the GAAP amounts excluded from the non-GAAP financial measures. In addition, as noted above, we evaluate the non-GAAP financial measures together with the most directly comparable GAAP financial information.

[0001032975-25-000022:8k_2_02:60]
Additional Supplemental Financial Information - Constant Currency

[0001032975-25-000022:8k_2_02:61]
In addition, Logitech presents percentage sales growth in constant currency to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales.
