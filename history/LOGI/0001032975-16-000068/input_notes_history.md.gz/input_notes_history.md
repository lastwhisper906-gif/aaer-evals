# LOGI note change history — 0001032975-15-000052 → 0001032975-16-000068


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2016-01-22):
[0001032975-16-000068:note_history:1]
All of the Company’s peripherals products sold are covered by warranty to be free from defects in material and workmanship. Except for the products sold prior to April 1, 2014, the standard warranty period up to five years, starting from April 1, 2014, which had the standard warranty for all new products launched was changed to two years from date of purchase for European Countries and generally one year from date of purchase for all other countries. At the time of sale, the Company accrues a warranty liability for estimated costs to provide products, parts or services to repair or replace products in satisfaction of the warranty obligation. The Company’s estimate of costs to fulfill its warranty obligations is based on historical experience and expectations of future conditions. When the Company experiences changes in warranty claim activity or costs associated with fulfilling those claims, the warranty liability is adjusted accordingly.

- changed (2016-01-22):
[0001032975-16-000068:note_history:2]
Changes in the Company’s warranty liability for the three and nine months ended December 31, 2015 and 2014 were as follows (in thousands):
  (was, 2015-10-23, similarity 0.9615):
[0001032975-15-000052:note_history:2]
Changes in the Company’s warranty liability for the three and six months ended September 30, 2015 and 2014 were as follows (in thousands):

- changed (2016-01-22):
[0001032975-16-000068:note_history:3]
|  | Three Months EndedDecember 31, |  | Nine Months Ended December 31, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Beginning of the period | $ | 20,399 |  |  | $ | 22,204 |  |  | $ | 21,710 |  |  | $ | 24,380 |  |
| Provision | 1,870 |  |  | 2,381 |  |  | 5,804 |  |  | 6,607 |  |
| Settlements | (2,763 | ) |  | (2,493 | ) |  | (8,008 | ) |  | (8,895 | ) |
| End of the period | $ | 19,506 |  |  | $ | 22,092 |  |  | $ | 19,506 |  |  | $ | 22,092 |  |
  (was, 2015-10-23, similarity 0.926):
[0001032975-15-000052:note_history:3]
|  | Three Months Ended September 30, |  | Six Months Ended September 30, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Beginning of the period | $ | 21,284 |  |  | $ | 23,420 |  |  | $ | 21,710 |  |  | $ | 24,380 |  |
| Provision | 1,792 |  |  | 2,020 |  |  | 3,934 |  |  | 4,226 |  |
| Settlements | (2,677 | ) |  | (3,236 | ) |  | (5,245 | ) |  | (6,402 | ) |
| End of the period | $ | 20,399 |  |  | $ | 22,204 |  |  | $ | 20,399 |  |  | $ | 22,204 |  |

- changed (2016-01-22):
[0001032975-16-000068:note_history:4]
The Company is subject to an ongoing formal investigation by the Enforcement Division of the U.S. Securities and Exchange Commission ("SEC"), relating to certain issues including the accounting for Revue inventory valuation reserves that resulted in the restatement described in the Fiscal 2014 Form 10-K, revision to the Company’s consolidated financial statements concerning warranty accruals and amortization of intangible assets presented in the Company’s Amended Annual Report on Form10-K/A, filed on August 7, 2013, and the Company’s transactions with a distributor for Fiscal Year 2007 through Fiscal Year 2009. The Company has entered into an agreement with the Enforcement Staff to extend the statute of limitations. The Company is cooperating with the investigation and, after discussions with the Enforcement Staff, the Company made an offer of settlement to resolve the matter, which is subject to approval by the SEC.  The proposed settlement would be entered into by the Company without admitting or denying the SEC’s findings and would resolve alleged violations of certain provisions of the Securities Exchange Act of 1934 and related rules, including the anti-fraud provisions.  Under the terms of the proposed settlement, the Company would pay $7.5 million in a civil penalty and agree not to commit or cause any violations of certain provisions of the Securities Exchange Act of 1934 and related rules. There is no assurance that the proposal will be approved by the SEC. In accordance with U.S. GAAP, the Company has made a corresponding accrual in its financial statements.
  (was, 2015-10-23, similarity 0.9971):
[0001032975-15-000052:note_history:4]
The Company is subject to an ongoing formal investigation by the Enforcement Division of the U.S. Securities and Exchange Commission ("SEC"), relating to certain issues including the accounting for Revue inventory valuation reserves that resulted in the restatement described in the Fiscal 2014 Form 10-K, revision to the Company’s consolidated financial statements concerning warranty accruals and amortization of intangible assets presented in the Company’s Amended Annual Report on Form10-K/A, filed on August 7, 2013, and the Company’s transactions with a distributor for Fiscal Year 2007 through Fiscal Year 2009. The Company has entered into an agreement with the Enforcement Staff to extend the statute of limitations. The Company is cooperating with the investigation and, after discussions with the Enforcement Staff, the Company recently made an offer of settlement to resolve the matter, which is subject to approval by the SEC.  The proposed settlement would be entered into by the Company without admitting or denying the SEC’s findings and would resolve alleged violations of certain provisions of the Securities Exchange Act of 1934 and related rules, including the anti-fraud provisions.  Under the terms of the proposed settlement, the Company would pay $7.5 million in a civil penalty and agree not to commit or cause any violations of certain provisions of the Securities Exchange Act of 1934 and related rules. There is no assurance that the proposal will be approved by the SEC. In accordance with U.S. GAAP, the Company has made a corresponding accrual in its financial statements.

- changed (2016-01-22):
[0001032975-16-000068:note_history:5]
Logitech Europe S.A. guaranteed payments of certain third-party contract manufacturers’ purchase obligations. As of December 31, 2015, the maximum amount of this guarantee was $3.8 million, of which $1.3 million of guaranteed purchase obligations were outstanding.
  (was, 2015-10-23, similarity 0.9862):
[0001032975-15-000052:note_history:5]
Logitech Europe S.A. guaranteed payments of certain third-party contract manufacturers’ purchase obligations. As of September 30, 2015, the maximum amount of this guarantee was $3.8 million, of which $0.9 million of guaranteed purchase obligations were outstanding.

- changed (2016-01-22):
[0001032975-16-000068:note_history:6]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of December 31, 2015, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.
  (was, 2015-10-23, similarity 0.9946):
[0001032975-15-000052:note_history:6]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of September 30, 2015, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

- added (2016-01-22):
[0001032975-16-000068:note_history:7]
The Stock Purchase Agreement in connection with the investment by three venture capital firms in Lifesize, Inc. contains representations, warranties and covenants of Logitech and Lifesize, Inc. to the Investors. Logitech has agreed, subject to certain limitations, to indemnify the Investors and certain persons related to the Investors for certain losses resulting from breaches of or inaccuracies in such representations, warranties and covenants as well as certain other obligations, including third-party expenses, restructuring costs and pre-closing tax obligations of Lifesize.

- removed (2016-01-22):
[0001032975-15-000052:note_history:8]
All of the Company’s peripherals products are covered by warranty to be free from defects in material and workmanship for periods ranging from one year to five years. At the time of sale, the Company accrues a warranty liability for estimated costs to provide products, parts or services to repair or replace products in satisfaction of the warranty obligation. The Company’s estimate of costs to fulfill its warranty obligations is based on historical experience and expectations of future conditions. When the Company experiences changes in warranty claim activity or costs associated with fulfilling those claims, the warranty liability is adjusted accordingly.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-01-22):
[0001032975-16-000068:note_history:9]
The Company and Summary of Significant Accounting Policies and Estimates
  (was, 2015-10-23, similarity 0.7368):
[0001032975-15-000052:note_history:9]
Summary of Significant Accounting Policies

- added (2016-01-22):
[0001032975-16-000068:note_history:10]
The Company

- added (2016-01-22):
[0001032975-16-000068:note_history:11]
Logitech is a world leader in products that connect people to the digital experiences they care about. Spanning multiple computing, communication and entertainment platforms, the Company develops and markets innovative hardware and software products that enable or enhance digital navigation, music and video entertainment, gaming, social networking, audio and video communication over the Internet and home-entertainment control.

- changed (2016-01-22):
[0001032975-16-000068:note_history:12]
The condensed consolidated interim financial statements include the accounts of Logitech and its subsidiaries. All intercompany balances and transactions have been eliminated. The condensed consolidated financial statements are presented in accordance with accounting principles generally accepted in the United States of America (“GAAP”) for interim financial information and therefore do not include all the information required by GAAP for complete financial statements. They should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended March 31, 2015, included in its Annual Report on Form 10-K filed with the Securities and Exchange Commission (“SEC”) on June 5, 2015.
  (was, 2015-10-23, similarity 0.7199):
[0001032975-15-000052:note_history:12]
The condensed consolidated interim financial statements include the accounts of Logitech and its subsidiaries. All intercompany balances and transactions have been eliminated. The condensed consolidated financial statements are presented in accordance with accounting principles generally accepted in the United States of America (“GAAP”) for interim financial information and therefore do not include all the information required by GAAP for complete financial statements. They should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended March 31, 2015, included in its Annual Report on Form 10-K filed with the Securities and Exchange Commission (“SEC”) on June 5, 2015.  In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, financial position, comprehensive income, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and six months ended September 30, 2015 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2016, or any future periods.

- added (2016-01-22):
[0001032975-16-000068:note_history:13]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, financial position, comprehensive income, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and nine months ended December 31, 2015 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2016, or any future periods.

- added (2016-01-22):
[0001032975-16-000068:note_history:14]
During the third quarter of fiscal year 2016, the Company's Board of Directors approved a plan to divest the Lifesize video conferencing business, and the Company met all other criteria to classify this business as held for sale. As a result, the Company has classified the results of Lifesize video conferencing business as discontinued operations in its condensed consolidated statements of operations for all periods presented. Additionally, the related assets and liabilities associated with the discontinued operations are classified as held for sale on its condensed consolidated balance sheets. On December 28, 2015, the Company and Lifesize, Inc., a wholly owned subsidiary of the Company (“Lifesize”) which holds the assets of the Company’s Lifesize video conferencing business, entered into a stock purchase agreement (the “Stock Purchase Agreement”) with three venture capital firms. Immediately following the December 28, 2015 closing of the transactions contemplated by the Stock Purchase Agreement, the venture capital firms held 62.5% of the outstanding shares of Lifesize, which resulted in a divestiture of the Lifesize video conferencing business by the Company. The disposition of the Lifesize video conferencing business represents a strategic shift that will have a major effect on the Company's operations and financial results.

- added (2016-01-22):
[0001032975-16-000068:note_history:15]
Unless indicated otherwise, the information in the Notes to the condensed consolidated financial statements relates to our continuing operations and does not include results of Lifesize video conferencing business, which is classified as discontinued operations. See "Note 2 - Discontinued Operations" for more information.

- added (2016-01-22):
[0001032975-16-000068:note_history:16]
Segments

- added (2016-01-22):
[0001032975-16-000068:note_history:17]
ASC 280, Segment Reporting, establishes standards for reporting information about operating segments. Operating segments are defined as components of an enterprise about which separate financial information is available that is evaluated regularly by the chief operating decision maker, or decision making group, in deciding how to allocate resources and in assessing performance. The guidance defines reportable segments as operating segments that meet certain quantitative thresholds. As a result of the events of December 28, 2015 described above and the decision to divest the Company's video conferencing segment, the composition of the Company's previously reported segments changed significantly, such that the remaining peripheral segment is the only segment reported in continuing operations.

- changed (2016-01-22):
[0001032975-16-000068:note_history:18]
The Company's fiscal year ends on March 31. Interim quarters end on the last Friday of each quarter. For purposes of presentation, the Company has indicated its quarterly periods as ending on the last day of the calendar quarter.
  (was, 2015-10-23, similarity 0.8485):
[0001032975-15-000052:note_history:18]
The Company’s fiscal year ends on March 31. Interim quarter ends on last Friday of each quarter.  For purposes of presentation, the Company has indicated its quarterly periods as ending on the quarter end.

- changed (2016-01-22):
[0001032975-16-000068:note_history:19]
There have been no substantial changes in the Company’s significant accounting policies during the nine months ended December 31, 2015 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2015.
  (was, 2015-10-23, similarity 0.9186):
[0001032975-15-000052:note_history:19]
There have been no substantial changes in the Company’s significant accounting policies during the six months ended September 30, 2015 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2015.

- added (2016-01-22):
[0001032975-16-000068:note_history:20]
In April 2014, the FASB issued ASU No. 2014-08, "Presentation of Financial Statements (Topic 205) and Property, Plant and Equipment (Topic 360): Reporting Discontinued Operations and Disclosures of Disposals of Components of an Entity". This new standard raises the threshold for a disposal to qualify as a discontinued operation and requires new disclosures of both discontinued operations and certain other disposals that do not meet the definition of a discontinued operation. The standard is effective prospectively for years beginning on or after December 15, 2014, with early application permitted. The Company adopted ASU No. 2014-08 on April 1, 2015 on a prospective basis and applied the guidance to its disposal of the Lifesize video conferencing business.

- added (2016-01-22):
[0001032975-16-000068:note_history:21]
In November 2015, the FASB issued ASU 2015-17, “Income Taxes (Topic 740), Balance Sheet Classification of Deferred Taxes.” This guidance eliminates the current requirement for an entity to separate deferred income tax liabilities and assets into current and non-current amounts in a classified balance sheet. Instead, this guidance requires deferred tax liabilities, deferred tax assets and valuation allowances be classified as non-current in a classified balance sheet. This ASU is effective for annual reporting periods beginning after December 15, 2016 and interim periods within those annual periods. Early adoption is permitted. Additionally, this guidance may be applied either prospectively or retrospectively to all periods presented. The Company is still evaluating whether to early adopt this guidance as the Company expects adoption will cause significant balance sheet reclassifications. See Note 6, “Balance Sheet Components” for details of the current and non-current deferred income taxes balances.

- added (2016-01-22):
[0001032975-16-000068:note_history:22]
In January 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”)  2016-01 “Financial Instruments- Recognition and Measurement of Financial Assets and Financial Liabilities (Subtopic 825-10).” The amendments require all equity investments to be measured at fair value with changes in the fair value recognized through net income (other than those accounted for under the equity method of accounting or those that result in consolidation of the investee). The amendments also require an entity to present separately in other comprehensive income the portion of the total change in the fair value of a liability resulting from a change in the instrument-specific credit risk when the entity has elected to measure the liability at fair value in accordance with the fair value option for financial instruments. In addition, the amendments eliminate the requirement to disclose the fair value of financial instruments measured at amortized cost for entities that are not public business entities and the requirement to disclose the method(s) and significant assumptions used to estimate the fair value that is required to be disclosed for financial instruments measured at amortized cost on the balance sheet for public business entities. This guidance is effective for fiscal years beginning after December 15, 2017, including interim periods within those fiscal years. The Company does not expect to early adopt this guidance and does not believe that the adoption of this guidance will have a material impact on its condensed consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-01-22):
[0001032975-16-000068:note_history:23]
The Company had several uncommitted, unsecured bank lines of credit aggregating $45.5 million as of December 31, 2015. There are no financial covenants under these lines of credit with which the Company must comply. As of December 31, 2015, the Company had outstanding bank guarantees of $21.8 million under these lines of credit. There was no borrowing outstanding under these lines of credit as of December 31, 2015 or March 31, 2015.
  (was, 2015-10-23, similarity 0.9204):
[0001032975-15-000052:note_history:23]
The Company had several uncommitted, unsecured bank lines of credit aggregating $46.7 million as of September 30, 2015. There are no financial covenants under these lines of credit with which the Company must comply. As of September 30, 2015, the Company had outstanding bank guarantees of $18.2 million under these lines of credit. There was no borrowing outstanding under these lines of credit as of September 30, 2015 or March 31, 2015.
