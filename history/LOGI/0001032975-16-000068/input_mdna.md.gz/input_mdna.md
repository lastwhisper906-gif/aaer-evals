# LOGI MD&A — 0001032975-16-000068


## mdna

[0001032975-16-000068:mdna:1]
[same as prior period, unchanged from 0001032975-15-000052:mdna:1]

[0001032975-16-000068:mdna:2]
[same as prior period, unchanged from 0001032975-15-000052:mdna:2]

[0001032975-16-000068:mdna:3]
[same as prior period, unchanged from 0001032975-15-000052:mdna:3]

[0001032975-16-000068:mdna:4]
Logitech is a world leader in products that connect people to the digital experiences they care about. Spanning multiple computing, communication and entertainment platforms, we develop and market innovative hardware and software products that enable or enhance digital navigation, music and video entertainment, gaming, social networking, audio and video communication over the Internet and home-entertainment control.

[0001032975-16-000068:mdna:5]
During the third quarter of fiscal year 2016, the Company's Board of Directors approved a plan to divest the Lifesize video conferencing business. Subsequently, on December 28, 2015 in the fourth quarter of fiscal year 2016, the Company and Lifesize, Inc., (“Lifesize”) a wholly owned subsidiary of the Company which holds the assets of our video conferencing reportable segment, entered into a stock purchase agreement (the “Stock Purchase

[0001032975-16-000068:mdna:6]
Agreement”) with entities affiliated with three venture capital firms - Redpoint Ventures, Sutter Hill Ventures and Meritech Capital Partners (the "Venture Investors").  Pursuant to the terms of the Stock Purchase Agreement, we sold 2,500,000 shares of Series B Preferred Stock of Lifesize to the Venture Investors for cash proceeds of $2,500,000 and retained 12,000,000 non-voting shares of Series A Preferred Stock of Lifesize. The shares of Series A Preferred Stock of Lifesize retained by the Company represent 37.5% of the total shares outstanding immediately after the closing of the transactions (the "Closing").  Lifesize also issued 17,500,000 shares of Series B Preferred Stock to the Venture Investors for cash proceeds of $17,500,000. The shares of Series B Preferred Stock held by the Venture Investors represent 62.5% of the total shares outstanding immediately after the Closing.  In addition, Lifesize reserved 8,000,000 shares of common stock for issuance pursuant to a stock plan to be adopted by Lifesize following the Closing (the “Employee Pool”), none of which are issued or outstanding at the Closing. The divestiture of the Lifesize video conferencing business is effective on December 28, 2015. The Stock Purchase Agreement contains representations, warranties and covenants of the parties and includes certain indemnification obligations of the Company to the Ventures Investors. See “Note 10 - Commitments and Contingencies” for more information. The Stock Purchase Agreement also contains certain post-closing working capital adjustments. Post closing continuing involvement with the discontinued operations include certain customary services and support which are expected to be provided to Lifesize during the transition period from December 28, 2015 until approximately the end of the third quarter of fiscal year 2017.

[0001032975-16-000068:mdna:7]
The disposition of the Lifesize video conferencing business represents a strategic shift as contemplated by ASC 205-20, Presentation of Financial statement - Discontinued Operations, ("ASC 205-20") that will have a major effect on our operations and financial results. As such, we have classified the results of its Lifesize video conferencing business as discontinued operations in our condensed consolidated statement of operations for all periods presented. Additionally, the related assets and liabilities associated with the discontinued operations are classified as held for sale in its condensed consolidated balance sheet for all periods presented. See "Note 1 - The Company and Summary of Significant Accounting Policies" and "Note 2 - Discontinued Operations". We expect to recognize a disposal gain of $15 million to $20 million as a result of the divestiture, which will be reported in discontinued operations included in the results of fourth quarter of fiscal year 2016. Unless indicated otherwise, the information included in Item 2 relates to our continuing operations and historical financial segment information has been recast to conform to this new presentation within our financial statements.

[0001032975-16-000068:mdna:8]
As a result of the event discussed above, the composition of our previously reported segments changed significantly, such that the remaining peripheral segment is the only segment reported in continuing operations, which encompasses the design, manufacturing and marketing of peripherals for PCs, tablets and other digital platforms. We classify our retail product categories as growth, profit maximization, and non-strategic. Our growth product categories are: Mobile Speakers, Gaming, and Tablet & Other Accessories. Our profit maximization categories are: Pointing Devices, Keyboards & Combos, Audio-PC & Wearables, PC Webcams, and Home Control. See Note 12 to our unaudited condensed consolidated financial statements for information regarding our business and the geographies in which we operate.

[0001032975-16-000068:mdna:9]
Our brand, portfolio management, product development and engineering teams are responsible for product strategy, technological innovation, product design and development and to bring our products to market.

[0001032975-16-000068:mdna:10]
[same as prior period, unchanged from 0001032975-15-000052:mdna:8]

[0001032975-16-000068:mdna:11]
We sell our products to a network of retailers including direct sales to retailers and indirect sales through distributors. Our worldwide retail network includes wholesale distributors, consumer electronics retailers, mass merchandisers, specialty electronics, computers and telecommunications stores, value-added resellers and online merchants. Sales of our retail peripherals were 96% and 94% of our net sales for the nine months ended December 31, 2015 and 2014, respectively. The large majority of our revenues have historically been derived from sales of our retail peripherals products for use by consumers. Sales to OEM customers were 4% and 6% of our net sales for the nine months ended December 31, 2015 and 2014, respectively. In April 2015, we announced our intent to exit the OEM business. The OEM business exit plan was completed in December 2015.

[0001032975-16-000068:mdna:12]
We seek to fulfill the increasing demand for interfaces between people and the expanding digital world across multiple platforms and user environments. The interface evolves as platforms, user models and our target markets evolve. As access to digital information has expanded, we have extended our focus to mobile devices, the digital

[0001032975-16-000068:mdna:13]
home, and the enterprise as access points to the Internet and the digital world. All of these platforms require interfaces that are customized according to how the devices are used. We believe that continued investment in product research and development is critical to creating the innovation required to strengthen our competitive advantage and to drive future sales growth. We are committed to identifying and meeting current and future consumer trends with new and improved product technologies, as well as leveraging the value of the Logitech brand from a competitive, channel partner and consumer experience perspective.

[0001032975-16-000068:mdna:14]
[same as prior period, unchanged from 0001032975-15-000052:mdna:12]

[0001032975-16-000068:mdna:15]
[same as prior period, unchanged from 0001032975-15-000052:mdna:13]

[0001032975-16-000068:mdna:16]
Adoption of New Accounting Pronouncements

[0001032975-16-000068:mdna:17]
We have adopted ASU No. 2014-08, "Presentation of Financial Statements (Topic 205) and Property, Plant and Equipment (Topic 360): Reporting Discontinued Operations and Disclosures of Disposals of Components of an Entity" on a prospective basis and applied the guidance to our disposed Lifesize video conferencing business. See "Note 1 - The Company and Summary of Significant Accounting Policies and Estimates" to the condensed consolidated financial statements for more information.

[0001032975-16-000068:mdna:18]
[same as prior period, unchanged from 0001032975-15-000052:mdna:14]

[0001032975-16-000068:mdna:19]
[same as prior period, unchanged from 0001032975-15-000052:mdna:15]

[0001032975-16-000068:mdna:20]
We base our estimates on historical experience and on various other assumptions we believe to be reasonable under the circumstances. Although these estimates are based on management’s best knowledge of current events and actions that may impact us in the future, actual results could materially differ from those estimates. Management has discussed the development, selection and disclosure of these critical accounting estimates with the Audit Committee of the Board of Directors.

[0001032975-16-000068:mdna:21]
We conduct a goodwill impairment analysis annually at December 31 or more frequently if indicators of impairment exist or if a decision is made to sell or exit a business. A significant amount of judgment is involved in determining if an indicator of impairment has occurred. Such indicators may include deterioration in general economic conditions, negative developments in equity and credit markets, adverse changes in the markets in which an entity operates, increases in input costs that have a negative effect on earnings and cash flows, or a trend of negative or declining cash flows over multiple periods, among others. The fair value that could be realized in an actual transaction may differ from that used to evaluate the impairment of goodwill. As of December 31, 2015, all of the Company's goodwill is related to the peripherals reporting unit.

[0001032975-16-000068:mdna:22]
We performed our annual impairment analysis of the goodwill at December 31, 2015 by performing a qualitative assessment and concluded that it was more likely than not that the fair value of the peripheral reporting unit exceeded its carrying amount. Refer to the Note 8 to the consolidated financial statements included in this report of our Form 10-Q for the disclosures.

[0001032975-16-000068:mdna:23]
There have been no other new or material changes to the critical accounting policies and estimates discussed in our Annual Report on Form 10-K for the fiscal year ended March 31, 2015 that are of significance, or potential significance to the Company.

[0001032975-16-000068:mdna:24]
[same as prior period, unchanged from 0001032975-15-000052:mdna:18]

[0001032975-16-000068:mdna:25]
Our total net sales for the three months ended December 31, 2015 increased 2.8% compared to the three months ended December 31, 2014, due to stronger retail sales, partially offset by declines in OEM.

[0001032975-16-000068:mdna:26]
Our total net sales for the nine months ended December 31, 2015 increased 1.6% compared to the nine months ended December 31, 2014.

[0001032975-16-000068:mdna:27]
Total retail sales increased 4% and units sold increased 1% during the three months ended December 31, 2015, compared to the three months ended December 31, 2014. We experienced an increase in sales of 5% in the Americas region, an increase in sales of 9% in the Asia Pacific region, and a decrease in sales of 1% in the EMEA region.

[0001032975-16-000068:mdna:28]
Total retail sales increased 3% and units sold remained flat during the nine months ended December 31, 2015, compared to the nine months ended December 31, 2014. We experienced an increase in sales of 7% in the Americas region, an increase in sales of 11% in the Asia Pacific region, and a decrease in sales of 6% in the EMEA region.

[0001032975-16-000068:mdna:29]
OEM net sales decreased 12% and 22%, in the three and nine months ended months ended December 31, 2015, respectively, compared to the three and nine months ended December 31, 2014. The decline was expected as we announced, in April 2015, our plan to exit the OEM business which was completed in December 2015.

[0001032975-16-000068:mdna:30]
Our gross margin for the three months ended December 31, 2015 decreased to 33.6% from 35.2% for the three months ended December 31, 2014. Our gross margin for the nine months ended December 31, 2015 decreased to 34.0% from 36.1% for the nine months ended December 31, 2014. The decrease in gross margin is primarily driven by the unfavorable fluctuations in currency exchange rates, partially offset by sales price increase, savings from supply chain efficiency, and a one-time inventory reserve release following the successful depletion of our OEM inventory of approximately $5 million in the current quarter.

[0001032975-16-000068:mdna:31]
Operating expenses for the three months ended December 31, 2015 were 22.5% of net sales, compared to 23.7% in the same period of the prior fiscal year. The decrease was primarily due to the savings from general and administration expenses, favorable currency impact, reduction related to the prior year's independent Audit committee investigation and related expenses, partially offset by the increase in research and development expense.

[0001032975-16-000068:mdna:32]
Operating expenses for the nine months ended December 31, 2015 were 26.5% of net sales, compared to 27.1% in the same period of the prior fiscal year. The decrease was primarily due to the savings from general and administration expenses, favorable currency impact, reduction related to the prior year's independent Audit committee investigation and related expenses, partially offset by the increase in research and development expense and restructuring charges related to our restructuring plan announced in April 2015.

[0001032975-16-000068:mdna:33]
Net income from continuing operations for the three and nine months ended December 31, 2015 was $68.0 million and $111.4 million, respectively, compared to net income from continuing operations of $66.4 million and $129.6 million in the three and nine months ended December 31, 2014, respectively.

[0001032975-16-000068:mdna:34]
Net loss from discontinued operations for the three and nine months ended December 31, 2015 were $3.0 million and $20.7 million, respectively, compared to net loss from discontinued operations of $3.6 million and $11.1 million in the three and nine months ended December 31, 2014, respectively.

[0001032975-16-000068:mdna:35]
Given our global sales presence and the reporting of our financial results in U.S. Dollars, our financial results in fiscal year 2016 have been affected by significant shifts in currency exchange rates compared to fiscal year 2015. See “Results of Operations” for information on the effect of currency exchange results on our net sales. If the U.S. Dollar remains at its current strong levels in comparison to other currencies, this will affect our results of operations in future periods as well.

[0001032975-16-000068:mdna:36]
[same as prior period, unchanged from 0001032975-15-000052:mdna:30]

[0001032975-16-000068:mdna:37]
[same as prior period, unchanged from 0001032975-15-000052:mdna:31]

[0001032975-16-000068:mdna:38]
We believe our future growth will be determined by our ability to create innovative products in a timely manner across multiple digital platforms in our growth categories such as tablets and smartphones, gaming, digital music

[0001032975-16-000068:mdna:39]
devices and video collaboration, to offset the decline in our PC peripherals categories. The following discussion represents key trends in our business.

[0001032975-16-000068:mdna:40]
Trends Specific to our business

[0001032975-16-000068:mdna:41]
Mobile Speakers:    The mobile speaker market grew throughout fiscal year 2015 and the first nine months of fiscal year 2016 driven by growing consumption of music through mobile devices such as smartphones and tablets.  This market growth, together with our investments in the UE brand, our introduction of new products and our ability to gain market share during fiscal year 2015 and the first half of fiscal year 2016, have driven our growth in Mobile Speakers.

[0001032975-16-000068:mdna:42]
Gaming:    The PC Gaming platform continues to show strong growth as online and multi-platform gaming gain greater popularity and gaming content becomes increasingly more demanding. We believe Logitech is well positioned to benefit from the PC Gaming market growth.

[0001032975-16-000068:mdna:43]
PC Peripherals (Pointing Devices, Keyboards & Combos, PC Webcams and Audio - PC & Wearables):    Although the installed base of PC users is large, consumer demand for new PCs has declined in recent years. As a consequence, consumer demand for PC peripherals is slowing, or in some cases declining. Our PC speakers sales are expected to decline as consumers migrate towards mobile speaker solutions such as UE Boom.

[0001032975-16-000068:mdna:44]
[same as prior period, unchanged from 0001032975-15-000052:mdna:37]

[0001032975-16-000068:mdna:45]
Tablets and Other Accessories:    Smaller mobile computing devices, such as tablets with touch interfaces, have created new markets and usage models for peripherals and accessories. We offer a variety of products for the Apple and Android platforms, including keyboard and folios that enhance the consumers mobile device experiences.We have seen the market decline starting in fiscal year 2015 with continued declines in the first nine months of fiscal year 2016 for the iPad platform, which has impacted the sales of our tablet peripherals.

[0001032975-16-000068:mdna:46]
OEM Business:    Sales of our OEM mice and keyboards have historically made up the bulk of our OEM sales. In recent years, there has been a dramatic shift away from desktop PCs and there continues to be weakness in the global market for PCs, which has adversely affected our sales of OEM mice and keyboards, all of which are sold with name-brand desktop PCs. As a result, we announced in April 2015 to exit our OEM business and the exit of our OEM business was completed in December 2015.

[0001032975-16-000068:mdna:47]
[same as prior period, unchanged from 0001032975-15-000052:mdna:40]

[0001032975-16-000068:mdna:48]
Business Application Suite:   In fiscal year 2016, we implemented the upgrade of our worldwide business application suite from Oracle version 11i to Oracle version R12.  This upgrade created delays in our processing of customer claims related to cooperative marketing arrangements, direct and indirect customer incentive programs and pricing programs.  While we are working on enhancing the operational efficiency of the claims processing module in our worldwide business application suite, this has resulted and it may continue to result in higher accruals and allowances for such programs.

[0001032975-16-000068:mdna:49]
[same as prior period, unchanged from 0001032975-15-000052:mdna:43]

[0001032975-16-000068:mdna:50]
[same as prior period, unchanged from 0001032975-15-000052:mdna:44]

[0001032975-16-000068:mdna:51]
[same as prior period, unchanged from 0001032975-15-000052:mdna:45]

[0001032975-16-000068:mdna:52]
[same as prior period, unchanged from 0001032975-15-000052:mdna:46]

[0001032975-16-000068:mdna:53]
Net sales by channel for the three and nine months ended December 31, 2015 and 2014 were as follows (Dollars in thousands):

[0001032975-16-000068:mdna:54]
|  |  | Three Months EndedDecember 31, |  | Nine Months Ended December 31, |
|  |  | 2015 |  | 2014 |  | Change |  | 2015 |  | 2014 |  | Change |
| Retail |  | $ | 594,567 |  |  | $ | 574,025 |  |  | 4 | % |  | $ | 1,516,218 |  |  | $ | 1,471,301 |  |  | 3 | % |
| OEM |  | 26,512 |  |  | 30,297 |  |  | (12 | ) |  | 71,041 |  |  | 91,324 |  |  | (22 | ) |
| Total net sales |  | $ | 621,079 |  |  | $ | 604,322 |  |  | 3 |  |  | $ | 1,587,259 |  |  | $ | 1,562,625 |  |  | 2 |  |

[0001032975-16-000068:mdna:55]
[same as prior period, unchanged from 0001032975-15-000052:mdna:49]

[0001032975-16-000068:mdna:56]
Our net retail sales in the three and nine months ended December 31, 2015 increased 4% and 3%, respectively, compared to the same periods of the prior fiscal year. Sales increases in the Americas and Asia pacific regions, partially offset by a decrease in the EMEA region during the three and nine months ended December 31, 2015. If currency exchange rates had been constant in the three and nine months ended December 31, 2015 and 2014, our constant dollar retail sales would have increased by 9% and 10%, respectively.

[0001032975-16-000068:mdna:57]
[same as prior period, unchanged from 0001032975-15-000052:mdna:51]

[0001032975-16-000068:mdna:58]
OEM net sales decreased 12% and 22% in the three and nine months ended December 31, 2015, respectively, compared to the same periods of the prior fiscal year. Given our heightened focus on our growing Retail Strategic business, the planned exit of our OEM business was completed in December 2015. If currency exchange rates had been constant in the three and six months ended December 31, 2015 and 2014, our constant dollar OEM net sales would have decreased by 12% and 22%, respectively.

[0001032975-16-000068:mdna:59]
Allowances and Accruals for Marketing and Pricing Items

[0001032975-16-000068:mdna:60]
As discussed in the Note 6 to our condensed consolidated financial statements, the increase in the allowances and accruals for cooperative marketing arrangements, customer incentive programs and pricing programs ("Marketing and Pricing Items") as of December 31, 2015 compared with March 31, 2015 was primarily the result of seasonality in the Company's business and changes in product mix, and increases in Marketing and Pricing Items offset by price increases.

[0001032975-16-000068:mdna:61]
[same as prior period, unchanged from 0001032975-15-000052:mdna:55]

[0001032975-16-000068:mdna:62]
The following table presents the change in retail sales by region for the three and nine months ended December 31, 2015, compared to the three and nine months ended December 31, 2014:

[0001032975-16-000068:mdna:63]
|  |  | Three Months EndedDecember 31, 2015Change in Sales |  | Nine Months EndedDecember 31, 2015Change in Sales |
| Americas |  | 5 | % |  | 7 | % |
| EMEA |  | (1 | ) |  | (6 | ) |
| Asia Pacific |  | 9 |  |  | 11 |  |

[0001032975-16-000068:mdna:64]
[same as prior period, unchanged from 0001032975-15-000052:mdna:58]

[0001032975-16-000068:mdna:65]
Retail sales in the Americas region increased 5% and 7%, respectively, during the three and nine months ended December 31, 2015, compared to the same periods of the prior fiscal year. If currency exchange rates had been constant in the three and nine months ended December 31, 2015 and 2014, our constant dollar retail sales would have increased 7% and 8%, respectively. This increase was led by growth in Video Collaboration and Mobile Speakers.

[0001032975-16-000068:mdna:66]
[same as prior period, unchanged from 0001032975-15-000052:mdna:60]

[0001032975-16-000068:mdna:67]
Retail sales in the EMEA region decreased 1% and 6%, respectively, during the three and nine months ended December 31, 2015, compared to the same periods of the prior fiscal year. If currency exchange rates had been constant in the three and nine months ended December 31, 2015 and 2014, our constant dollar retail sales would have increased 10% and 6%, respectively. Excluding the currency impact, this increase was led by growth in Gaming, Video Collaboration and Mobile Speakers.

[0001032975-16-000068:mdna:68]
[same as prior period, unchanged from 0001032975-15-000052:mdna:62]

[0001032975-16-000068:mdna:69]
Retail sales in the Asia Pacific region increased 9% and 11% during the three and nine months ended December 31, 2015, compared to the same periods of the prior fiscal year. If currency exchange rates had been constant in the three and nine months ended December 31, 2015 and 2014, our constant dollar retail sales would have increased 15% and 17%, respectively. We achieved sales increases in Video Collaboration, Mobile Speakers, Gaming, Keyboards & Combos, and PC Webcams during the three and nine months ended December 31, 2015.

[0001032975-16-000068:mdna:70]
[same as prior period, unchanged from 0001032975-15-000052:mdna:64]

[0001032975-16-000068:mdna:71]
Net sales by product category for the three and nine months ended December 31, 2015 and 2014 were as follows (Dollars in thousands):

[0001032975-16-000068:mdna:72]
|  |  | Three Months EndedDecember 31, |  | Nine Months Ended December 31, |
|  |  | 2015 |  | 2014 |  | Change |  | 2015 |  | 2014 |  | Change |
| Mobile Speakers |  | $ | 85,081 |  |  | $ | 62,264 |  |  | 37 | % |  | $ | 206,175 |  |  | $ | 139,631 |  |  | 48 | % |
| Gaming |  | 77,706 |  |  | 70,188 |  |  | 11 |  |  | 189,000 |  |  | 164,570 |  |  | 15 |  |
| Video Collaboration |  | 26,216 |  |  | 16,935 |  |  | 55 |  |  | 67,460 |  |  | 45,968 |  |  | 47 |  |
| Tablet & Other Accessories |  | 35,873 |  |  | 55,100 |  |  | (35 | ) |  | 73,222 |  |  | 114,974 |  |  | (36 | ) |
| Growth |  | 224,876 |  |  | 204,487 |  |  | 10 |  |  | 535,857 |  |  | 465,143 |  |  | 15 |  |
| Pointing Devices |  | 139,711 |  |  | 141,789 |  |  | (1 | ) |  | 381,364 |  |  | 382,524 |  |  | — |  |
| Keyboards & Combos |  | 116,531 |  |  | 114,051 |  |  | 2 |  |  | 324,458 |  |  | 325,217 |  |  | — |  |
| Audio-PC & Wearables |  | 57,300 |  |  | 56,741 |  |  | 1 |  |  | 149,341 |  |  | 162,480 |  |  | (8 | ) |
| PC Webcams |  | 29,648 |  |  | 31,709 |  |  | (6 | ) |  | 74,689 |  |  | 77,454 |  |  | (4 | ) |
| Home Control |  | 25,684 |  |  | 25,116 |  |  | 2 |  |  | 48,548 |  |  | 56,224 |  |  | (14 | ) |
| Profit Maximization |  | 368,874 |  |  | 369,406 |  |  | — |  |  | 978,400 |  |  | 1,003,899 |  |  | (3 | ) |
| Retail Strategic Sales |  | 593,750 |  |  | 573,893 |  |  | 3 |  |  | 1,514,257 |  |  | 1,469,042 |  |  | 3 |  |
| Non-Strategic |  | 817 |  |  | 132 |  |  | 519 |  |  | 1,961 |  |  | 2,259 |  |  | (13 | ) |
| Retail |  | 594,567 |  |  | 574,025 |  |  | 4 |  |  | 1,516,218 |  |  | 1,471,301 |  |  | 3 |  |
| OEM |  | 26,512 |  |  | 30,297 |  |  | (12 | ) |  | 71,041 |  |  | 91,324 |  |  | (22 | ) |
|  |  | 621,079 |  |  | 604,322 |  |  | 3 |  |  | 1,587,259 |  |  | 1,562,625 |  |  | 2 |  |

[0001032975-16-000068:mdna:73]
Certain products within the retail product categories presented in prior periods have been reclassified to conform to the current period's presentation.

[0001032975-16-000068:mdna:74]
[same as prior period, unchanged from 0001032975-15-000052:mdna:68]

[0001032975-16-000068:mdna:75]
During the three and nine months ended December 31, 2015, Retail Strategic sales increased 3% and 3%, respectively, compared to the same periods of prior fiscal year. If currency exchange rates had been constant for the three and nine months ended December 31, 2015 and 2014, our constant dollar retail strategic sales would have increased 9% and 10%, respectively.

[0001032975-16-000068:mdna:76]
[same as prior period, unchanged from 0001032975-15-000052:mdna:70]

[0001032975-16-000068:mdna:77]
During the three and nine months ended December 31, 2015, Retail Strategic sales - Growth categories increased 10% and 15%, respectively, compared to the same periods of prior fiscal year. If currency exchange rates had been constant for the three and nine months ended December 31, 2015 and 2014, our constant dollar Retail Strategic sales - Growth categories would have increased 17% and 23%, respectively.

[0001032975-16-000068:mdna:78]
[same as prior period, unchanged from 0001032975-15-000052:mdna:72]

[0001032975-16-000068:mdna:79]
[same as prior period, unchanged from 0001032975-15-000052:mdna:73]

[0001032975-16-000068:mdna:80]
Retail sales and units sold of Mobile Speakers increased 37% and 34%, respectively, for the three month period ended December 31, 2015, compared to the same period of the prior fiscal year. Retail sales and units sold of Mobile Speakers increased 48% and 38%, respectively, for the nine month period ended December 31, 2015, compared to the same period of the prior fiscal year. Mobile Speaker sales increased significantly for both periods primarily due to the introduction of the UE Megaboom in the fourth quarter of fiscal year 2015 and the UE BOOM 2 in the second quarter of fiscal year 2016.

[0001032975-16-000068:mdna:81]
[same as prior period, unchanged from 0001032975-15-000052:mdna:75]

[0001032975-16-000068:mdna:82]
[same as prior period, unchanged from 0001032975-15-000052:mdna:76]

[0001032975-16-000068:mdna:83]
Retail sales and units sold of Gaming increased 11% and 16%, respectively, for the three months ended December 31, 2015, compared to the same period of the prior fiscal year. Retail sales and units sold of Gaming

[0001032975-16-000068:mdna:84]
increased 15% and 14%, respectively, for the nine months ended December 31, 2015, compared to the same period of the prior fiscal year. Gaming sales increased significantly for both periods primarily driven by increases in Gaming keyboards and Gaming headsets with the new product launch of G933 and G633 headsets.

[0001032975-16-000068:mdna:85]
[same as prior period, unchanged from 0001032975-15-000052:mdna:78]

[0001032975-16-000068:mdna:86]
[same as prior period, unchanged from 0001032975-15-000052:mdna:79]

[0001032975-16-000068:mdna:87]
Retail sales of Video Collaboration increased 55% and units sold increased 64% in the three months ended December 31, 2015, compared to the same period of the prior fiscal year. Retail sales of Video Collaboration increased 47% and units sold increased 51% in the nine months ended December 31, 2015, compared to the same period of the prior fiscal year. The increases in both periods were primarily due to growth in our conference cams.

[0001032975-16-000068:mdna:88]
[same as prior period, unchanged from 0001032975-15-000052:mdna:81]

[0001032975-16-000068:mdna:89]
[same as prior period, unchanged from 0001032975-15-000052:mdna:82]

[0001032975-16-000068:mdna:90]
Retail sales of Tablet & Other Accessories decreased 35% and units sold decreased 38% in the three months ended December 31, 2015, compared to the same period of the prior fiscal year. The reduction in sales reflects the combination of a declining market for iPad shipments, partially offset by the new product introduction of Create backlit tablet keyboard case for iPad Pro.

[0001032975-16-000068:mdna:91]
Retail sales of Tablet & Other Accessories decreased 36% and units sold decreased 27% in the nine months ended December 31, 2015, compared to the same period of the prior fiscal year.

[0001032975-16-000068:mdna:92]
[same as prior period, unchanged from 0001032975-15-000052:mdna:85]

[0001032975-16-000068:mdna:93]
During the three and nine months ended December 31, 2015, Retail Strategic sales - Profit Maximization categories remained flat and decreased 3%, respectively, compared to the same periods of the prior fiscal year. If currency exchange rates had been constant for the three and nine months ended December 31, 2015 and 2014, our constant dollar Retail Strategic sales - Profit Maximization categories would have increased 5% and 3%, respectively.

[0001032975-16-000068:mdna:94]
[same as prior period, unchanged from 0001032975-15-000052:mdna:87]

[0001032975-16-000068:mdna:95]
Our retail Pointing Devices category comprises mice, touchpads and presenters.

[0001032975-16-000068:mdna:96]
Retail sales of Pointing Devices decreased 1% and units sold were flat in the three months ended December 31, 2015, compared to the same period of the prior fiscal year. Sales decreased in low-end and mid-range products, partially offset by an increase at the high end due to the new product introduction of the MX Master Wireless Mouse and MX Anywhere 2 Wireless Mouse.

[0001032975-16-000068:mdna:97]
Retail sales of Pointing Devices remained flat while retail units sold decreased 1% in the nine months ended December 31, 2015, compared to the same period of the prior fiscal year.

[0001032975-16-000068:mdna:98]
[same as prior period, unchanged from 0001032975-15-000052:mdna:91]

[0001032975-16-000068:mdna:99]
[same as prior period, unchanged from 0001032975-15-000052:mdna:92]

[0001032975-16-000068:mdna:100]
Retail sales of Keyboards & Combos increased 2% and units sold increased 4% in the three months ended December 31, 2015, compared to the same period of the prior fiscal year. Sales growth in the Americas region was partially offset by sales decline in the EMEA region. The sales increase was primarily driven by cordless products, partially offset by a decrease in living room keyboard products.

[0001032975-16-000068:mdna:101]
Retail sales of Keyboards & Combos remained flat and units sold increased 3% in the nine months ended December 31, 2015, compared to the same period of the prior fiscal year.

[0001032975-16-000068:mdna:102]
[same as prior period, unchanged from 0001032975-15-000052:mdna:95]

[0001032975-16-000068:mdna:103]
[same as prior period, unchanged from 0001032975-15-000052:mdna:96]

[0001032975-16-000068:mdna:104]
Audio-PC & Wearables sales increased 1% and units sold decreased 7% in the three months ended December 31, 2015, compared to the same period of the prior fiscal year. The increase was driven by the new product introduction of the Z533 Speaker in the second quarter of fiscal year 2016.

[0001032975-16-000068:mdna:105]
Audio-PC & Wearables sales decreased 8% and units sold decreased 9% in the nine months ended December 31, 2015, compared to the same period of the prior fiscal year. The decrease was primarily due to decreases in PC speaker retail sales, reflecting a category in structural decline as music consumption migrates to mobile platforms.

[0001032975-16-000068:mdna:106]
[same as prior period, unchanged from 0001032975-15-000052:mdna:99]

[0001032975-16-000068:mdna:107]
[same as prior period, unchanged from 0001032975-15-000052:mdna:100]

[0001032975-16-000068:mdna:108]
Retail PC Webcams sales decreased 6% and units sold decreased 1% in the three months ended December 31, 2015, compared to the same period of the prior fiscal year. The decrease was primarily driven by the declines in the Americas and EMEA regions, partially offset by growth in the Asia Pacific region.

[0001032975-16-000068:mdna:109]
Retail PC Webcams sales decreased 4% and units sold decreased 5% in the nine months ended December 31, 2015, compared to the same period in the prior fiscal year.

[0001032975-16-000068:mdna:110]
[same as prior period, unchanged from 0001032975-15-000052:mdna:103]

[0001032975-16-000068:mdna:111]
[same as prior period, unchanged from 0001032975-15-000052:mdna:104]

[0001032975-16-000068:mdna:112]
Home Control retail sales increased 2% and units sold were flat in the three months ended December 31, 2015, compared to the same period of the prior fiscal year. The increase was due to the new product introduction of the Harmony Elite.

[0001032975-16-000068:mdna:113]
Home Control retail sales decreased 14% and units sold decreased 5% in the nine months ended December 31, 2015, compared to the same period of the prior fiscal year.

[0001032975-16-000068:mdna:114]
[same as prior period, unchanged from 0001032975-15-000052:mdna:107]

[0001032975-16-000068:mdna:115]
[same as prior period, unchanged from 0001032975-15-000052:mdna:108]

[0001032975-16-000068:mdna:116]
[same as prior period, unchanged from 0001032975-15-000052:mdna:111]

[0001032975-16-000068:mdna:117]
OEM sales decreased 12% and units sold decreased 50% during the three months ended December 31, 2015, compared to the same period of the prior fiscal year. As announced in April 2015, the plan to exit the OEM business by the end of December 2015 was complete.

[0001032975-16-000068:mdna:118]
OEM sales decreased 22% and units sold decreased 29% during the nine months ended December 31, 2015, compared to the same period of the prior fiscal year.

[0001032975-16-000068:mdna:119]
37

[0001032975-16-000068:mdna:120]
[same as prior period, unchanged from 0001032975-15-000052:mdna:116]

[0001032975-16-000068:mdna:121]
Gross profit for three and nine months ended December 31, 2015 and 2014 was as follows (Dollars in thousands):

[0001032975-16-000068:mdna:122]
|  |  | Three Months EndedDecember 31, |  | Nine Months Ended December 31, |
|  |  | 2015 |  | 2014 |  | Change |  | 2015 |  | 2014 |  | Change |
| Net sales |  | $ | 621,079 |  |  | $ | 604,322 |  |  | 3 | % |  | $ | 1,587,259 |  |  | $ | 1,562,625 |  |  | 2 | % |
| Cost of goods sold |  | 412,582 |  |  | 391,715 |  |  | 5 |  |  | 1,048,312 |  |  | 998,842 |  |  | 5 |  |
| Gross profit |  | $ | 208,497 |  |  | $ | 212,607 |  |  | (2 | ) |  | $ | 538,947 |  |  | $ | 563,783 |  |  | (4 | ) |
| Gross margin |  | 33.6 | % |  | 35.2 | % |  |  |  |  | 34.0 | % |  | 36.1 | % |  |  |  |

[0001032975-16-000068:mdna:123]
[same as prior period, unchanged from 0001032975-15-000052:mdna:119]

[0001032975-16-000068:mdna:124]
Gross margin decreased for the three and nine months ended December 31, 2015 compared to the same periods of the prior fiscal year. The decrease in gross margin is primarily driven by the unfavorable fluctuations in currency exchange rates, partially offset by sales price increase, savings from supply chain efficiency, and a one-time inventory reserve release following the successful depletion of our OEM inventory of approximately $5 million in the current quarter.

[0001032975-16-000068:mdna:125]
[same as prior period, unchanged from 0001032975-15-000052:mdna:121]

[0001032975-16-000068:mdna:126]
Operating expenses for the three and nine months ended December 31, 2015 and 2014 were as follows (Dollars in thousands):

[0001032975-16-000068:mdna:127]
|  |  | Three Months EndedDecember 31, |  | Nine Months Ended December 31, |
|  |  | 2015 |  | 2014 |  | Change |  | 2015 |  | 2014 |  | Change |
| Marketing and selling |  | $ | 87,295 |  |  | $ | 87,486 |  |  | — | % |  | $ | 241,924 |  |  | $ | 246,103 |  |  | (2 | )% |
| % of net sales |  | 14.1 | % |  | 14.5 | % |  |  |  |  | 15.2 | % |  | 15.7 | % |  |  |  |
| Research and development |  | 29,273 |  |  | 27,397 |  |  | 7 |  |  | 86,336 |  |  | 80,009 |  |  | 8 |  |
| % of net sales |  | 4.7 | % |  | 4.5 | % |  |  |  |  | 5.4 | % |  | 5.1 | % |  |  |  |
| General and administrative |  | 24,080 |  |  | 28,172 |  |  | (15 | ) |  | 77,966 |  |  | 96,762 |  |  | (19 | ) |
| % of net sales |  | 3.9 | % |  | 4.7 | % |  |  |  |  | 4.9 | % |  | 6.2 | % |  |  |  |
| Restructuring charges (credits), net |  | (666 | ) |  | — |  |  | NM |  |  | 14,018 |  |  | (35 | ) |  | NM |  |
| % of net sales |  | (0.1 | )% |  | — | % |  |  |  |  | 0.9 | % |  | — | % |  |  |  |
| Total operating expenses |  | $ | 139,982 |  |  | $ | 143,055 |  |  | (2 | ) |  | $ | 420,244 |  |  | $ | 422,839 |  |  | (1 | )% |
| % of net sales |  | 22.5 | % |  | 23.7 | % |  |  |  |  | 26.5 | % |  | 27.1 | % |  |  |  |

[0001032975-16-000068:mdna:128]
[same as prior period, unchanged from 0001032975-15-000052:mdna:124]

[0001032975-16-000068:mdna:129]
[same as prior period, unchanged from 0001032975-15-000052:mdna:125]

[0001032975-16-000068:mdna:130]
[same as prior period, unchanged from 0001032975-15-000052:mdna:126]

[0001032975-16-000068:mdna:131]
During the three months ended December 31, 2015, marketing and selling expenses remained flat compared to the same period in the prior fiscal year.

[0001032975-16-000068:mdna:132]
During the nine months ended December 31, 2015, marketing and selling expenses decreased 2% compared to the same period in the prior fiscal year. The decrease was primarily due to savings from exiting the OEM business and currency impact offset by investments in growth product categories.

[0001032975-16-000068:mdna:133]
[same as prior period, unchanged from 0001032975-15-000052:mdna:202]

[0001032975-16-000068:mdna:134]
[same as prior period, unchanged from 0001032975-15-000052:mdna:129]

[0001032975-16-000068:mdna:135]
[same as prior period, unchanged from 0001032975-15-000052:mdna:130]

[0001032975-16-000068:mdna:136]
During the three months ended December 31, 2015, research and development expenses increased 7% compared to the same period in the prior fiscal year. The increase was primarily due to a $0.6 million increase in our Digital Music products development as well as a $0.5 million investment increase in Seeds (new business opportunities) development.

[0001032975-16-000068:mdna:137]
During the nine months ended December 31, 2015, research and development expenses increased 8% compared to the same period in the prior fiscal year. The increase was primarily due to a $4.4 million investment increase in Seeds development as well as a $1.3 million investment in our Digital Music products.

[0001032975-16-000068:mdna:138]
[same as prior period, unchanged from 0001032975-15-000052:mdna:133]

[0001032975-16-000068:mdna:139]
[same as prior period, unchanged from 0001032975-15-000052:mdna:134]

[0001032975-16-000068:mdna:140]
During the three months ended December 31, 2015, general and administrative expenses decreased 15% compared to the same period in the prior fiscal year. The decrease was primarily due to a $2.8 million reduction related to the prior year's independent Audit committee investigation and related expenses and a $0.9 million facility cost savings from building consolidation.

[0001032975-16-000068:mdna:141]
During the nine months ended December 31, 2015, general and administrative expenses decreased 19% compared to the same period in the prior fiscal year. The decrease was primarily due to a $19.0 million reduction related to the prior year's independent Audit committee investigation and a $3.7 million facility cost savings from office building consolidation, partially offset by a $3.5 million additional accrual for our proposed settlement with the SEC (see Other Contingencies for more details).

[0001032975-16-000068:mdna:142]
[same as prior period, unchanged from 0001032975-15-000052:mdna:137]

[0001032975-16-000068:mdna:143]
During the first quarter of fiscal year 2016, we implemented a restructuring plan to exit the OEM business, reorganize Lifesize to sharpen our focus on its cloud-based offering, and streamline our overall cost structure through product, overhead and infrastructure cost reductions with a targeted resource realignment. Restructuring charges incurred during the nine months ended December 31, 2015 under this plan primarily consisted of severance and other ongoing and one-time termination benefits. Charges and other costs related to the workforce reduction and structure realignment are presented as restructuring charges in the Condensed Consolidated Statements of Operations. On a total company basis, including Lifesize business as reported in discontinued operations, we expect to incur approximately $22 million to $25 million under this restructuring plan, including approximately $20.3 million to $23.3 million for cash severance and other personnel costs, and expect to substantially complete this restructuring within the next 3 months. We have paid $16.7 million as of December 31, 2015, on a total company basis. We expect this restructuring will save personnel-related costs and other overhead costs, and we expect to use the savings from the restructuring to offset currency impacts and to invest in future growth.

[0001032975-16-000068:mdna:144]
The following table summarizes restructuring related activities during the nine months ended December 31, 2015 (in thousands).

[0001032975-16-000068:mdna:145]
|  |  | Restructuring - Continuing Operations |
|  |  | TerminationBenefits |  | Lease ExitCosts |  | Other |  | Total |
| Accrual balance at March 31, 2015 |  | $ | — |  |  | $ | 954 |  |  | $ | — |  |  | $ | 954 |  |
| Charges, net |  | 11,469 |  |  | — |  |  | 69 |  |  | 11,538 |  |
| Cash payments |  | (3,727 | ) |  | (796 | ) |  | $ | (44 | ) |  | (4,567 | ) |
| Accrual balance at June 30, 2015 |  | 7,742 |  |  | 158 |  |  | 25 |  |  | 7,925 |  |
| Charges, net |  | 3,124 |  |  | 38 |  |  | (16 | ) |  | 3,146 |  |
| Cash payments |  | (4,608 | ) |  | (115 | ) |  | (9 | ) |  | (4,732 | ) |
| Accrual balance at September 30, 2015 |  | $ | 6,258 |  |  | $ | 81 |  |  | $ | — |  |  | $ | 6,339 |  |
| Credits, net |  | (1,049 | ) |  | 299 |  |  | 84 |  |  | (666 | ) |
| Cash payments |  | (1,716 | ) |  | (255 | ) |  | 6 |  |  | (1,965 | ) |
| Accrual balance at December 31, 2015 |  | $ | 3,493 |  |  | $ | 125 |  |  | $ | 90 |  |  | $ | 3,708 |  |

[0001032975-16-000068:mdna:146]
|  |  | Restructuring - Discontinued Operations |
|  |  | TerminationBenefits |  | Lease ExitCosts |  | Other |  | Total |
| Accrual balance at March 31, 2015 |  | $ | — |  |  | $ | 85 |  |  | $ | — |  |  | $ | 85 |  |
| Charges, net |  | 1,325 |  |  | — |  |  | 132 |  |  | 1,457 |  |
| Cash payments |  | (948 | ) |  |  |  | (107 | ) |  | (1,055 | ) |
| Accrual balance at June 30, 2015 |  | $ | 377 |  |  | $ | 85 |  |  | $ | 25 |  |  | $ | 487 |  |
| Charges, net |  | 5,442 |  |  | — |  |  | 107 |  |  | 5,549 |  |
| Cash payments |  | (504 | ) |  | (7 | ) |  | (132 | ) |  | (643 | ) |
| Accrual balance at September 30, 2015 |  | $ | 5,315 |  |  | $ | 78 |  |  | $ | — |  |  | $ | 5,393 |  |
| Charges, net |  | 376 |  |  | — |  |  | 688 |  |  | 1,064 |  |
| Cash payments |  | (3,688 | ) |  | (7 | ) |  | (13 | ) |  | (3,708 | ) |
| Accrual balance at December 31, 2015 |  | $ | 2,003 |  |  | $ | 71 |  |  | $ | 675 |  |  | $ | 2,749 |  |

[0001032975-16-000068:mdna:147]
[same as prior period, unchanged from 0001032975-15-000052:mdna:141]

[0001032975-16-000068:mdna:148]
Other income (expense), net

[0001032975-16-000068:mdna:149]
Other income and expense for the three and nine months ended December 31, 2015 and 2014 were as follows (in thousands):

[0001032975-16-000068:mdna:150]
|  |  | Three Months EndedDecember 31, |  | Nine Months Ended December 31, |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Investment income (loss) related to deferred compensation plan |  | $ | 348 |  |  | $ | 66 |  |  | $ | (278 | ) |  | $ | 714 |  |
| Currency exchange gains (losses) |  | 442 |  |  | (792 | ) |  | (690 | ) |  | (2,366 | ) |
| Investment impairment and others |  | 72 |  |  | (1,962 | ) |  | 74 |  |  | (2,050 | ) |
|  |  | $ | 862 |  |  | $ | (2,688 | ) |  | $ | (894 | ) |  | $ | (3,702 | ) |

[0001032975-16-000068:mdna:151]
We recognized a $0.4 million currency exchange gain and a $0.7 million currency exchange loss during the three and nine months ended December 31, 2015, respectively. Currency exchange gains (losses) relate to balances denominated in currencies other than the functional currency of our subsidiaries, to the sale of currencies, and to gains or losses recognized on currency exchange forward contracts.

[0001032975-16-000068:mdna:152]
40

[0001032975-16-000068:mdna:153]
Investment impairment and others declined by $2.0 million primarily due to a $2.3 million investment impairment resulting from the write-down of an investment in a privately held company in prior periods.

[0001032975-16-000068:mdna:154]
[same as prior period, unchanged from 0001032975-15-000052:mdna:147]

[0001032975-16-000068:mdna:155]
The provision for income taxes and effective tax rates for the three and nine months ended December 31, 2015 and 2014 were as follows (in thousands):

[0001032975-16-000068:mdna:156]
|  |  | Three Months EndedDecember 31, |  | Nine Months Ended December 31, |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Provision for income taxes |  | $ | 1,442 |  |  | $ | 670 |  |  | $ | 7,006 |  |  | $ | 8,455 |  |
| Effective income tax rate |  | 2.1 | % |  | 1.0 | % |  | 5.9 | % |  | 6.1 | % |

[0001032975-16-000068:mdna:157]
The change in the effective income tax rate for the three and nine months ended December 31, 2015, compared to the three and nine months ended December 31, 2014, is due to the mix of income and losses in the various tax jurisdictions in which we operate. In the three months ended December 31, 2015 and December 31, 2014, there was a discrete tax benefit of $8.4 million and $8.0 million, respectively, from the reversal of uncertain tax positions from the expiration of statutes of limitations. In the nine months ended December 31, 2015 and December 31, 2014, there was an additional discrete tax benefit of $2.2 million and $0.8 million, respectively,  from the preferential income tax rate reduction pursuant to the High and New Technology Enterprise Program in China.

[0001032975-16-000068:mdna:158]
On December 18, 2015, the enactment of the Protecting Americans from Tax Hikes Act of 2015 in the U.S. extended the federal research and development tax credit permanently which had previously expired on December 31, 2014. The income tax provision in the three and nine months ended December 31, 2015 reflected a $1.2 million tax benefit, respectively, as a result of the extension of the tax credit.

[0001032975-16-000068:mdna:159]
As of December 31 and March 31, 2015, the total amount of unrecognized tax benefits due to uncertain tax positions was $75.9 million and $79.0 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-16-000068:mdna:160]
[same as prior period, unchanged from 0001032975-15-000052:mdna:153]

[0001032975-16-000068:mdna:161]
[same as prior period, unchanged from 0001032975-15-000052:mdna:154]

[0001032975-16-000068:mdna:162]
As of December 31, 2015, we had cash and cash equivalents of $505.1 million compared to $533.4 million at March 31, 2015. Our cash and cash equivalents consist of bank demand deposits and short-term time deposits of which 69% is held by our subsidiaries in Switzerland, 18% is held by our subsidiaries in Hong Kong and China, 5% is held by our subsidiaries in the United States, and 8% is held by subsidiaries in various other countries. We do not expect to incur any material adverse tax impact except for what has been recognized or be significantly inhibited by any country in which we do business from the repatriation of funds to Switzerland, our home domicile.

[0001032975-16-000068:mdna:163]
As of December 31, 2015, our working capital was $520.1 million compared to working capital of $557.1 million at March 31, 2015. The decrease was primarily due to lower cash and cash equivalents, primarily as a result of dividend payments and share repurchases, lower inventory balances due to seasonality and higher accounts payable and accrued liabilities, partially offset by higher accounts receivable, net.

[0001032975-16-000068:mdna:164]
On a total company basis, during the nine months ended December 31, 2015, we generated $150.8 million cash from operating activities. Our main cash outflows of operating cash resulted from increases in accounts receivable, partially offset by decreases in inventories and increases in accounts payable and accrued liabilities. Net cash used in investing activities was $52.3 million, primarily from $50.4 million of capital expenditure in computer hardware and software, tooling and equipment. Net cash used in financing activities was $125.4 million, primarily related to dividend payments of $85.9 million, share repurchases of $48.8 million and tax withholdings related to net share settlements of restricted stock units (RSUs) of $5.4 million, partially offset by $12.6 million of proceeds from sales of shares upon exercise of options and purchase rights.

[0001032975-16-000068:mdna:165]
41

[0001032975-16-000068:mdna:166]
We had several uncommitted, unsecured bank lines of credit aggregating $45.5 million as of December 31, 2015. There are no financial covenants under these lines of credit with which we must comply. As of December 31, 2015, we had outstanding bank guarantees of $21.8 million under these lines of credit.

[0001032975-16-000068:mdna:167]
The following table summarizes our Condensed Consolidated Statements of Cash Flows (in thousands), on a total company basis:

[0001032975-16-000068:mdna:168]
|  |  | Nine Months Ended December 31, |
|  |  | 2015 |  | 2014 |
| Net cash provided by operating activities |  | $ | 150,846 |  |  | $ | 137,058 |  |
| Net cash used in investing activities |  | (52,269 | ) |  | (36,934 | ) |
| Net cash used in financing activities |  | (125,423 | ) |  | (47,402 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  | (1,205 | ) |  | (5,521 | ) |
| Net increase (decrease) in cash and cash equivalents |  | $ | (28,051 | ) |  | $ | 47,201 |  |

[0001032975-16-000068:mdna:169]
[same as prior period, unchanged from 0001032975-15-000052:mdna:161]

[0001032975-16-000068:mdna:170]
The following table presents selected financial information and statistics as of December 31, 2015 and 2014 (dollars in thousands):

[0001032975-16-000068:mdna:171]
|  |  | As of December 31 |
|  |  | 2015 |  | 2014 |
| Accounts receivable, net |  | $ | 284,089 |  |  | $ | 291,142 |  |
| Inventories |  | $ | 239,962 |  |  | $ | 233,289 |  |
| Working capital |  | $ | 520,121 |  |  | $ | 559,371 |  |
| Days sales in accounts receivable (“DSO”) (Days) (1) |  | 41 |  |  | 43 |  |
| Inventory turnover (“ITO”) (x)(2) |  | 6.9 |  |  | 6.7 |  |

[0001032975-16-000068:mdna:172]
[same as prior period, unchanged from 0001032975-15-000052:mdna:164]

[0001032975-16-000068:mdna:173]
[same as prior period, unchanged from 0001032975-15-000052:mdna:165]

[0001032975-16-000068:mdna:174]
On a total company basis, during the nine months ended December 31, 2015, we provided cash of $150.8 million from operating activities, compared to $137.1 million for the same period in the prior fiscal year. The primary drivers of the increase in net cash generated from operating cash flows include a reduction in inventory in the current year compared to an increase in the same period of prior year, an increase in accounts receivable in the current year compared to the same period of prior year, and a decrease in net income of $27.9 million, for the nine months ended December 31, 2015, compared to the nine months ended December 31, 2014.

[0001032975-16-000068:mdna:175]
Inventory turnover as of December 31, 2015 remained consistent compared to that as of December 31, 2014. The increase in inventories compared with December 31, 2014 was primarily due to new products introductions, adjusting our inventory strategy to transition from ODM to in-house production and utilizing sea shipments more extensively than air delivery since the fourth quarter of fiscal year 2015. If we are not successful in launching and phasing in our new products launched during the current fiscal year, or we are not able to sell the new products at the prices planned, it could have a material impact on our revenue, gross profit margin, operating results including operating cash flow, and inventory turnover in the future.

[0001032975-16-000068:mdna:176]
[same as prior period, unchanged from 0001032975-15-000052:mdna:169]

[0001032975-16-000068:mdna:177]
The following table presents information on our cash flows from investing activities during the nine months ended December 31, 2015 and 2014 (in thousands), on a total company basis:

[0001032975-16-000068:mdna:178]
|  |  | Nine Months Ended December 31, |
|  |  | 2015 |  | 2014 |
| Purchases of property, plant and equipment |  | $ | (50,443 | ) |  | $ | (34,777 | ) |
| Investment in privately held companies |  | (2,099 | ) |  | (2,550 | ) |
| Purchases of trading investments |  | (4,395 | ) |  | (3,463 | ) |
| Proceeds from sales of trading investments |  | 4,668 |  |  | 3,856 |  |
| Net cash used in investing activities |  | $ | (52,269 | ) |  | $ | (36,934 | ) |

[0001032975-16-000068:mdna:179]
Our expenditures for property, plant and equipment during the nine months ended December 31, 2015 and 2014 were primarily for computer hardware and software, tooling, equipment and leasehold improvements. The increase in purchases of property, plant and equipment during the nine months ended December 31, 2015 is mainly arising from the building of production lines to accommodate the in-house manufacturing of certain products compared with purchase from third parties in the prior period to align with our goal of cost saving.

[0001032975-16-000068:mdna:180]
The purchases and sales of trading investments in the nine months ended December 31, 2015 and 2014 represent mutual fund and money market fund activities directed by participants in a deferred compensation plan offered by one of our subsidiaries. The mutual funds and money market funds are held by a Rabbi trust.

[0001032975-16-000068:mdna:181]
[same as prior period, unchanged from 0001032975-15-000052:mdna:174]

[0001032975-16-000068:mdna:182]
The following table presents information on our cash flows from financing activities during the nine months ended December 31, 2015 and 2014 (in thousands), on a total company basis:

[0001032975-16-000068:mdna:183]
|  |  | Nine Months Ended December 31, |
|  |  | 2015 |  | 2014 |
| Payment of cash dividends |  | $ | (85,915 | ) |  | $ | (43,767 | ) |
| Contingent consideration related to prior acquisition |  | — |  |  | (100 | ) |
| Repurchases of ESPP awards |  | — |  |  | (1,078 | ) |
| Purchases of treasury shares |  | (48,802 | ) |  | — |  |
| Proceeds from sales of shares upon exercise of options and purchase rights |  | 12,562 |  |  | 2,466 |  |
| Tax withholdings related to net share settlements of restricted stock units |  | (5,357 | ) |  | (7,456 | ) |
| Excess tax benefits from share-based compensation |  | 2,089 |  |  | 2,533 |  |
| Net cash used in financing activities |  | $ | (125,423 | ) |  | $ | (47,402 | ) |

[0001032975-16-000068:mdna:184]
During the nine months ended December 31, 2015, 3.5 million shares were repurchased for $48.8 million. There were no share repurchases during the nine months ended December 31, 2014.

[0001032975-16-000068:mdna:185]
During the nine months ended December 31, 2015, we declared and paid cash dividends of CHF0.51 (USD equivalent of $0.53) per common share, totaling $85.9 million in U.S. Dollars, out of retained earnings. Proceeds from the sale of shares upon exercise of options and purchase rights pursuant to our stock plans during the nine months ended December 31, 2015 and 2014 were $12.6 million and $2.5 million, respectively. The payment of required tax withholdings related to net share settlements of RSUs during the nine months ended December 31, 2015 and 2014 was $5.4 million and $7.5 million, respectively.

[0001032975-16-000068:mdna:186]
[same as prior period, unchanged from 0001032975-15-000052:mdna:179]

[0001032975-16-000068:mdna:187]
[same as prior period, unchanged from 0001032975-15-000052:mdna:180]

[0001032975-16-000068:mdna:188]
43

[0001032975-16-000068:mdna:189]
In March 2015, we announced a plan to pay $250 million in cumulative dividends for fiscal year 2015 through fiscal year 2017. During the second quarter of fiscal year 2016, we paid a cash dividend of CHF 83.1 million (U.S. Dollar amount of $85.9 million) out of retained earnings. During fiscal year 2015, we paid a cash dividend of CHF 43.1 million (U.S. Dollar amount of $43.8 million) out of retained earnings.

[0001032975-16-000068:mdna:190]
In March 2014, our Board of Directors approved a new share buyback program, which authorizes us to purchase up to $250.0 million of our own shares. Our share buyback program provides us with the opportunity to make opportunistic repurchases during periods of favorable market conditions and is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market through block trades or otherwise. Purchases may be started or stopped at any time without prior notice depending on market conditions and other factors. During the nine months ended December 31, 2015, 3.5 million shares were repurchased for $48.8 million. There were no share repurchases during the three months ended December 31, 2015, or the three and nine months ended December 31, 2014.

[0001032975-16-000068:mdna:191]
During the first quarter of fiscal year 2016, we announced that we were committing to pursue a restructuring, including exiting the OEM business, reorganizing Lifesize to sharpen our focus on its cloud-based offering, and streamlining our overall cost structure through product, overhead and infrastructure cost reductions with a targeted resource realignment.  We expect to incur approximately $22 million to $25 million under this restructuring plan, and we have paid $16.7 million as of December 31, 2015, on a total company basis. We expect to substantially complete this restructuring within the next 3 months. We expect this restructuring will save personnel-related costs and other overhead costs, and we expect to use the savings from the restructuring to offset currency impact and to invest in future growth.

[0001032975-16-000068:mdna:192]
[same as prior period, unchanged from 0001032975-15-000052:mdna:184]

[0001032975-16-000068:mdna:193]
[same as prior period, unchanged from 0001032975-15-000052:mdna:185]

[0001032975-16-000068:mdna:194]
We lease facilities under operating leases, certain of which require us to pay property taxes, insurance and maintenance costs. Operating leases for facilities are generally renewable at our option and usually include escalation clauses linked to inflation. The remaining terms on our non-cancelable operating leases expire in various years through 2030. Our asset retirement obligations on these leases as of December 31, 2015 were not material.

[0001032975-16-000068:mdna:195]
[same as prior period, unchanged from 0001032975-15-000052:mdna:187]

[0001032975-16-000068:mdna:196]
As of December 31, 2015, we had fixed purchase commitments for inventory purchases made in the normal course of business to original design manufacturers, contract manufacturers and other suppliers, the majority of which are expected to be fulfilled within the next 12 months. Fixed purchase commitments for capital expenditures primarily relate to commitments for tooling for new and existing products, computer hardware, leasehold and improvements. We expect to continue making capital expenditures in the future to support product development activities and ongoing and expanded operations. Although open purchase commitments are considered enforceable and legally binding, the terms generally allow us to reschedule or adjust our requirements based on business needs prior to delivery of goods or performance of services.

[0001032975-16-000068:mdna:197]
[same as prior period, unchanged from 0001032975-15-000052:mdna:189]

[0001032975-16-000068:mdna:198]
For further detail about our contractual obligations and commitments, please refer to our Annual Report on Form 10-K for the fiscal year ended March 31, 2015.

[0001032975-16-000068:mdna:199]
[same as prior period, unchanged from 0001032975-15-000052:mdna:191]

[0001032975-16-000068:mdna:200]
[same as prior period, unchanged from 0001032975-15-000052:mdna:192]

[0001032975-16-000068:mdna:201]
Other Contingencies

[0001032975-16-000068:mdna:202]
We are subject to an ongoing formal investigation by the Enforcement Division of the U.S. Securities and Exchange Commission (SEC), relating to certain issues including the accounting for Revue inventory valuation reserves that resulted in the restatement described in the fiscal year 2014 Annual Report on Form 10-K, revision to our consolidated financial statements concerning warranty accruals and amortization of intangible assets presented in our Amended Annual Report on Form 10-K/A, filed on August 7, 2013, and our transactions with a distributor for fiscal year 2007 through fiscal year 2009. We have entered into an agreement with the Enforcement Staff to extend the statute of limitations. We are cooperating with the investigation and, after discussions with the Enforcement Staff, we made an offer of settlement to resolve the matter, which is subject to approval by the SEC.  The proposed settlement would be entered into by us without admitting or denying the SEC’s findings and would resolve alleged violations of certain provisions of the Securities Exchange Act of 1934 and related rules, including the anti-fraud provisions.  Under the terms of the proposed settlement, we would pay $7.5 million in a civil penalty and agree not to commit or cause any violations of certain provisions of the Securities Exchange Act of 1934 and related rules. There is no assurance that the proposal will be approved by the SEC. In accordance with U.S. GAAP, we have made a corresponding accrual in our financial statements.

[0001032975-16-000068:mdna:203]
[same as prior period, unchanged from 0001032975-15-000052:mdna:195]

[0001032975-16-000068:mdna:204]
Logitech Europe S.A., one of our wholly owned subsidiaries, guaranteed payments of third-party contract manufacturers' purchase obligations. As of December 31, 2015, the maximum amount of this guarantee was $3.8 million, of which $1.3 million of guaranteed purchase obligations were outstanding.

[0001032975-16-000068:mdna:205]
[same as prior period, unchanged from 0001032975-15-000052:mdna:197]

[0001032975-16-000068:mdna:206]
We indemnify certain of our suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of December 31, 2015, no amounts have been accrued for indemnification provisions. We do not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under our indemnification arrangements.

[0001032975-16-000068:mdna:207]
[same as prior period, unchanged from 0001032975-15-000052:mdna:199]

[0001032975-16-000068:mdna:208]
The Stock Purchase Agreement that we entered into in connection with the investment by three venture capital firms in Lifesize, Inc. contains representations, warranties and covenants of Logitech and Lifesize, Inc. to the Investors. Subject to certain limitations, we have agreed to indemnify the Investors and certain persons related to the Investors for certain losses resulting from breaches of or inaccuracies in such representations, warranties and covenants as well as certain other obligations, including third party expenses, restructuring costs and pre-closing tax obligations of Lifesize.

[0001032975-16-000068:mdna:209]
Legal Proceedings

[0001032975-16-000068:mdna:210]
From time to time we are involved in claims and legal proceedings that arise in the ordinary course of our business. We are currently subject to several such claims and a small number of legal proceedings. We believe that these matters lack merit and we intend to vigorously defend against them. Based on currently available information, we do not believe that resolution of pending matters will have a material adverse effect on our financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that our defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on our business, financial condition, cash flows and results of operations in a particular period. Any claims or proceedings against us, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect our business.

[0001032975-16-000068:mdna:211]
46
