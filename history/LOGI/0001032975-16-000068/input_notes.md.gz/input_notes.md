# LOGI notes — 0001032975-16-000068


## logi:ScheduleOfBalanceSheetComponentsAssetsTableTextBlock

[0001032975-16-000068:notes:1]
The following table presents the components of certain balance sheet asset amounts as of December 31 and March 31, 2015, excluding balances classified as held for sale (in thousands):

[0001032975-16-000068:notes:2]
|  |  | December 31,2015 |  | March 31,2015 |
| Accounts receivable, net: |  |  |  |  |  |  |
| Accounts receivable |  | $ | 521,772 |  |  | $ | 328,373 |  |
| Allowance for doubtful accounts |  | (666 | ) |  | (707 | ) |
| Allowance for sales returns |  | (19,838 | ) |  | (17,236 | ) |
| Allowance for cooperative marketing arrangements* |  | (46,036 | ) |  | (24,919 | ) |
| Allowance for customer incentive programs* |  | (74,692 | ) |  | (47,364 | ) |
| Allowance for pricing programs* |  | (96,451 | ) |  | (70,951 | ) |
|  |  | $ | 284,089 |  |  | $ | 167,196 |  |
| Inventories: |  |  |  |  |  |  |
| Raw materials |  | $ | 53,929 |  |  | $ | 36,044 |  |
| Finished goods |  | 186,033 |  |  | 219,936 |  |
|  |  | $ | 239,962 |  |  | $ | 255,980 |  |
| Other current assets: |  |  |  |  |  |  |
| Income tax and value-added tax receivables |  | $ | 25,278 |  |  | $ | 19,318 |  |
| Deferred tax assets |  | 27,798 |  |  | 27,790 |  |
| Prepaid expenses and other assets |  | 18,585 |  |  | 16,254 |  |
|  |  | $ | 71,661 |  |  | $ | 63,362 |  |
| Property, plant and equipment, net: |  |  |  |  |  |  |
| Property, plant and equipment |  | 368,969 |  |  | 332,562 |  |
| Less: accumulated depreciation and amortization |  | (269,824 | ) |  | (246,084 | ) |
|  |  | $ | 99,145 |  |  | $ | 86,478 |  |
| Other assets: |  |  |  |  |  |  |
| Deferred tax assets |  | $ | 33,672 |  |  | $ | 39,310 |  |
| Trading investments for deferred compensation plan |  | 15,265 |  |  | 17,237 |  |
| Other assets |  | 8,334 |  |  | 5,786 |  |
|  |  | $ | 57,271 |  |  | $ | 62,333 |  |


## logi:ScheduleOfBalanceSheetComponentsLiabilityTableTextBlock

[0001032975-16-000068:notes:3]
The following table presents the components of certain balance sheet liability amounts as of December 31 and March 31, 2015, excluding balances classified as held for sale (in thousands):

[0001032975-16-000068:notes:4]
|  |  | December 31,2015 |  | March 31,2015 |
| Accrued and other current liabilities: |  |  |  |  |  |  |
| Accrued personnel expenses |  | $ | 52,956 |  |  | $ | 46,022 |  |
| Indirect customer incentive programs * |  | 32,080 |  |  | 19,730 |  |
| Warranty accrual |  | 12,099 |  |  | 12,630 |  |
| Employee benefit plan obligation |  | 1,969 |  |  | 1,219 |  |
| Income taxes payable |  | 3,732 |  |  | 5,759 |  |
| Other current liabilities |  | 108,383 |  |  | 77,984 |  |
|  |  | $ | 211,219 |  |  | $ | 163,344 |  |
| Non-current liabilities: |  |  |  |  |  |  |
| Warranty accrual |  | $ | 7,407 |  |  | $ | 9,080 |  |
| Obligation for deferred compensation plan |  | 15,265 |  |  | 17,237 |  |
| Employee benefit plan obligation |  | 49,705 |  |  | 51,081 |  |
| Deferred tax liability |  | 1,761 |  |  | 1,936 |  |
| Other non-current liabilities |  | 11,209 |  |  | 11,861 |  |
|  |  | $ | 85,347 |  |  | $ | 91,195 |  |

[0001032975-16-000068:notes:5]
*The increase in the allowances for cooperative marketing arrangements, customer incentive programs, pricing programs and indirect customer incentive programs as of December 31, 2015 compared with March 31, 2015 was primarily the result of seasonality in the Company's business and changes in product mix, and increases in these marketing activities offset by price increases.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001032975-16-000068:notes:6]
The Company and Summary of Significant Accounting Policies and Estimates

[0001032975-16-000068:notes:7]
The Company

[0001032975-16-000068:notes:8]
Logitech is a world leader in products that connect people to the digital experiences they care about. Spanning multiple computing, communication and entertainment platforms, the Company develops and markets innovative hardware and software products that enable or enhance digital navigation, music and video entertainment, gaming, social networking, audio and video communication over the Internet and home-entertainment control.

[0001032975-16-000068:notes:9]
[same as prior period, unchanged from 0001032975-15-000052:notes:6]

[0001032975-16-000068:notes:10]
The condensed consolidated interim financial statements include the accounts of Logitech and its subsidiaries. All intercompany balances and transactions have been eliminated. The condensed consolidated financial statements are presented in accordance with accounting principles generally accepted in the United States of America (“GAAP”) for interim financial information and therefore do not include all the information required by GAAP for complete financial statements. They should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended March 31, 2015, included in its Annual Report on Form 10-K filed with the Securities and Exchange Commission (“SEC”) on June 5, 2015.

[0001032975-16-000068:notes:11]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, financial position, comprehensive income, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and nine months ended December 31, 2015 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2016, or any future periods.

[0001032975-16-000068:notes:12]
During the third quarter of fiscal year 2016, the Company's Board of Directors approved a plan to divest the Lifesize video conferencing business, and the Company met all other criteria to classify this business as held for sale. As a result, the Company has classified the results of Lifesize video conferencing business as discontinued operations in its condensed consolidated statements of operations for all periods presented. Additionally, the related assets and liabilities associated with the discontinued operations are classified as held for sale on its condensed consolidated balance sheets. On December 28, 2015, the Company and Lifesize, Inc., a wholly owned subsidiary of the Company (“Lifesize”) which holds the assets of the Company’s Lifesize video conferencing business, entered into a stock purchase agreement (the “Stock Purchase Agreement”) with three venture capital firms. Immediately following the December 28, 2015 closing of the transactions contemplated by the Stock Purchase Agreement, the venture capital firms held 62.5% of the outstanding shares of Lifesize, which resulted in a divestiture of the Lifesize video conferencing business by the Company. The disposition of the Lifesize video conferencing business represents a strategic shift that will have a major effect on the Company's operations and financial results.

[0001032975-16-000068:notes:13]
Unless indicated otherwise, the information in the Notes to the condensed consolidated financial statements relates to our continuing operations and does not include results of Lifesize video conferencing business, which is classified as discontinued operations. See "Note 2 - Discontinued Operations" for more information.

[0001032975-16-000068:notes:14]
Segments

[0001032975-16-000068:notes:15]
ASC 280, Segment Reporting, establishes standards for reporting information about operating segments. Operating segments are defined as components of an enterprise about which separate financial information is available that is evaluated regularly by the chief operating decision maker, or decision making group, in deciding how to allocate resources and in assessing performance. The guidance defines reportable segments as operating segments that meet certain quantitative thresholds. As a result of the events of December 28, 2015 described above and the decision to divest the Company's video conferencing segment, the composition of the Company's previously reported segments changed significantly, such that the remaining peripheral segment is the only segment reported in continuing operations.

[0001032975-16-000068:notes:16]
[same as prior period, unchanged from 0001032975-15-000052:notes:8]

[0001032975-16-000068:notes:17]
The Company's fiscal year ends on March 31. Interim quarters end on the last Friday of each quarter. For purposes of presentation, the Company has indicated its quarterly periods as ending on the last day of the calendar quarter.

[0001032975-16-000068:notes:18]
[same as prior period, unchanged from 0001032975-15-000052:notes:10]

[0001032975-16-000068:notes:19]
There have been no substantial changes in the Company’s significant accounting policies during the nine months ended December 31, 2015 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2015.

[0001032975-16-000068:notes:20]
[same as prior period, unchanged from 0001032975-15-000052:notes:12]

[0001032975-16-000068:notes:21]
[same as prior period, unchanged from 0001032975-15-000052:notes:13]

[0001032975-16-000068:notes:22]
[same as prior period, unchanged from 0001032975-15-000052:notes:14]

[0001032975-16-000068:notes:23]
In April 2014, the FASB issued ASU No. 2014-08, "Presentation of Financial Statements (Topic 205) and Property, Plant and Equipment (Topic 360): Reporting Discontinued Operations and Disclosures of Disposals of Components of an Entity". This new standard raises the threshold for a disposal to qualify as a discontinued operation and requires new disclosures of both discontinued operations and certain other disposals that do not meet the definition of a discontinued operation. The standard is effective prospectively for years beginning on or after December 15, 2014, with early application permitted. The Company adopted ASU No. 2014-08 on April 1, 2015 on a prospective basis and applied the guidance to its disposal of the Lifesize video conferencing business.

[0001032975-16-000068:notes:24]
In May 2014, the FASB issued Accounting Standards Update No. 2014-9, "Revenue from Contracts with Customers (Topic 606)," ("ASU 2014-9"). ASU 2014-9 outlines a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. Under the new model, recognition of revenue occurs when a customer obtains control of promised goods or services in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. In addition, the new standard requires that reporting companies disclose the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. ASU 2014-09 was originally to be effective for the Company on April 1, 2017. In July 2015, the FASB affirmed a one-year deferral of the effective date of the new revenue standard. The new standard will become effective for the Company on April 1, 2018. Early application is permitted but not before the original effective date of annual periods beginning after December 15, 2016. The new standard is required to be applied retrospectively to each prior reporting period presented or retrospectively with the cumulative effect of initially applying it recognized at the date of initial application. The Company has not yet selected a transition method nor has it determined the impact of the new standard on its condensed consolidated financial statements.

[0001032975-16-000068:notes:25]
In July 2015, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update No. 2015-11, "Simplifying the Measurement of Inventory (Topic 330)",  ("ASU 2015-11"). Topic 330, Inventory, currently requires an entity to measure inventory at the lower of cost or market, with market value represented by replacement cost, net realizable value or net realizable value less a normal profit margin. The amendments in ASU 2015-11 require an entity to measure inventory at the lower of cost or net realizable value. ASU 2015-11 is effective in the first quarter of fiscal year 2018 for the Company, with early adoption permitted. The Company does not expect the adoption of this guidance to have a material impact on its condensed consolidated financial statements.

[0001032975-16-000068:notes:26]
In November 2015, the FASB issued ASU 2015-17, “Income Taxes (Topic 740), Balance Sheet Classification of Deferred Taxes.” This guidance eliminates the current requirement for an entity to separate deferred income tax liabilities and assets into current and non-current amounts in a classified balance sheet. Instead, this guidance requires deferred tax liabilities, deferred tax assets and valuation allowances be classified as non-current in a classified balance sheet. This ASU is effective for annual reporting periods beginning after December 15, 2016 and interim periods within those annual periods. Early adoption is permitted. Additionally, this guidance may be applied either prospectively or retrospectively to all periods presented. The Company is still evaluating whether to early adopt this guidance as the Company expects adoption will cause significant balance sheet reclassifications. See Note 6, “Balance Sheet Components” for details of the current and non-current deferred income taxes balances.

[0001032975-16-000068:notes:27]
In January 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”)  2016-01 “Financial Instruments- Recognition and Measurement of Financial Assets and Financial Liabilities (Subtopic 825-10).” The amendments require all equity investments to be measured at fair value with changes in the fair value recognized through net income (other than those accounted for under the equity method of accounting or those that result in consolidation of the investee). The amendments also require an entity to present separately in other comprehensive income the portion of the total change in the fair value of a liability resulting from a change in the instrument-specific credit risk when the entity has elected to measure the liability at fair value in accordance with the fair value option for financial instruments. In addition, the amendments eliminate the requirement to disclose the fair value of financial instruments measured at amortized cost for entities that are not public business entities and the requirement to disclose the method(s) and significant assumptions used to estimate the fair value that is required to be disclosed for financial instruments measured at amortized cost on the balance sheet for public business entities. This guidance is effective for fiscal years beginning after December 15, 2017, including interim periods within those fiscal years. The Company does not expect to early adopt this guidance and does not believe that the adoption of this guidance will have a material impact on its condensed consolidated financial statements.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001032975-16-000068:notes:28]
Commitments and Contingencies

[0001032975-16-000068:notes:29]
Product Warranties

[0001032975-16-000068:notes:30]
All of the Company’s peripherals products sold are covered by warranty to be free from defects in material and workmanship. Except for the products sold prior to April 1, 2014, the standard warranty period up to five years, starting from April 1, 2014, which had the standard warranty for all new products launched was changed to two years from date of purchase for European Countries and generally one year from date of purchase for all other countries. At the time of sale, the Company accrues a warranty liability for estimated costs to provide products, parts or services to repair or replace products in satisfaction of the warranty obligation. The Company’s estimate of costs to fulfill its warranty obligations is based on historical experience and expectations of future conditions. When the Company experiences changes in warranty claim activity or costs associated with fulfilling those claims, the warranty liability is adjusted accordingly.

[0001032975-16-000068:notes:31]
Changes in the Company’s warranty liability for the three and nine months ended December 31, 2015 and 2014 were as follows (in thousands):

[0001032975-16-000068:notes:32]
|  | Three Months EndedDecember 31, |  | Nine Months Ended December 31, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Beginning of the period | $ | 20,399 |  |  | $ | 22,204 |  |  | $ | 21,710 |  |  | $ | 24,380 |  |
| Provision | 1,870 |  |  | 2,381 |  |  | 5,804 |  |  | 6,607 |  |
| Settlements | (2,763 | ) |  | (2,493 | ) |  | (8,008 | ) |  | (8,895 | ) |
| End of the period | $ | 19,506 |  |  | $ | 22,092 |  |  | $ | 19,506 |  |  | $ | 22,092 |  |

[0001032975-16-000068:notes:33]
Other Contingencies

[0001032975-16-000068:notes:34]
The Company is subject to an ongoing formal investigation by the Enforcement Division of the U.S. Securities and Exchange Commission ("SEC"), relating to certain issues including the accounting for Revue inventory valuation reserves that resulted in the restatement described in the Fiscal 2014 Form 10-K, revision to the Company’s consolidated financial statements concerning warranty accruals and amortization of intangible assets presented in the Company’s Amended Annual Report on Form10-K/A, filed on August 7, 2013, and the Company’s transactions with a distributor for Fiscal Year 2007 through Fiscal Year 2009. The Company has entered into an agreement with the Enforcement Staff to extend the statute of limitations. The Company is cooperating with the investigation and, after discussions with the Enforcement Staff, the Company made an offer of settlement to resolve the matter, which is subject to approval by the SEC.  The proposed settlement would be entered into by the Company without admitting or denying the SEC’s findings and would resolve alleged violations of certain provisions of the Securities Exchange Act of 1934 and related rules, including the anti-fraud provisions.  Under the terms of the proposed settlement, the Company would pay $7.5 million in a civil penalty and agree not to commit or cause any violations of certain provisions of the Securities Exchange Act of 1934 and related rules. There is no assurance that the proposal will be approved by the SEC. In accordance with U.S. GAAP, the Company has made a corresponding accrual in its financial statements.

[0001032975-16-000068:notes:35]
Guarantees

[0001032975-16-000068:notes:36]
Logitech Europe S.A. guaranteed payments of certain third-party contract manufacturers’ purchase obligations. As of December 31, 2015, the maximum amount of this guarantee was $3.8 million, of which $1.3 million of guaranteed purchase obligations were outstanding.

[0001032975-16-000068:notes:37]
Indemnifications

[0001032975-16-000068:notes:38]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of December 31, 2015, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

[0001032975-16-000068:notes:39]
The Company also indemnifies its current and former directors and certain of its current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. The Company is unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not limited, the obligations are conditional in nature and the facts and circumstances involved in any situation that might arise are variable.

[0001032975-16-000068:notes:40]
The Stock Purchase Agreement in connection with the investment by three venture capital firms in Lifesize, Inc. contains representations, warranties and covenants of Logitech and Lifesize, Inc. to the Investors. Logitech has agreed, subject to certain limitations, to indemnify the Investors and certain persons related to the Investors for certain losses resulting from breaches of or inaccuracies in such representations, warranties and covenants as well as certain other obligations, including third-party expenses, restructuring costs and pre-closing tax obligations of Lifesize.

[0001032975-16-000068:notes:41]
Legal Proceedings

[0001032975-16-000068:notes:42]
From time to time the Company is involved in claims and legal proceedings that arise in the ordinary course of its business. The Company is currently subject to several such claims and a small number of legal proceedings. The Company believes that these matters lack merit and intends to vigorously defend against them. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company’s defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company’s business, financial condition, cash flows or results of operations in a particular period. Any claims or proceedings against the Company, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company’s business.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001032975-16-000068:notes:43]
[same as prior period, unchanged from 0001032975-15-000052:notes:31]

[0001032975-16-000068:notes:44]
[same as prior period, unchanged from 0001032975-15-000052:notes:32]

[0001032975-16-000068:notes:45]
As of December 31, 2015, the Company offers the 2006 ESPP (2006 Employee Share Purchase Plan (Non-U.S.)), the 1996 ESPP (1996 Employee Share Purchase Plan (U.S.)), the 2006 Plan (2006 Stock Incentive Plan) and the 2012 Plan (2012 Stock Inducement Equity Plan).

[0001032975-16-000068:notes:46]
The following table summarizes the share-based compensation expense and related tax benefit recognized for the three and nine months ended December 31, 2015 and 2014, excluding balances classified as discontinued operations (in thousands):

[0001032975-16-000068:notes:47]
|  |  | Three Months EndedDecember 31, |  | Nine Months Ended December 31, |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Cost of goods sold |  | $ | 464 |  |  | $ | 560 |  |  | $ | 1,648 |  |  | $ | 1,725 |  |
| Marketing and selling |  | 2,484 |  |  | 2,552 |  |  | 6,545 |  |  | 6,659 |  |
| Research and development |  | 846 |  |  | 765 |  |  | 2,174 |  |  | 1,780 |  |
| General and administrative |  | 2,668 |  |  | 2,520 |  |  | 8,917 |  |  | 8,565 |  |
| Restructuring |  | — |  |  | — |  |  | 7 |  |  | — |  |
| Total share-based compensation expense |  | 6,462 |  |  | 6,397 |  |  | 19,291 |  |  | 18,729 |  |
| Income tax benefit |  | (1,446 | ) |  | (1,391 | ) |  | (2,479 | ) |  | (4,285 | ) |
| Total share-based compensation expense, net of income tax |  | $ | 5,016 |  |  | $ | 5,006 |  |  | $ | 16,812 |  |  | $ | 14,444 |  |

[0001032975-16-000068:notes:48]
As of December 31, 2015 and March 31, 2015, the Company capitalized $0.5 million and $0.5 million of stock-based compensation expenses as inventory, respectively.

[0001032975-16-000068:notes:49]
[same as prior period, unchanged from 0001032975-15-000052:notes:37]

[0001032975-16-000068:notes:50]
Certain of the Company’s subsidiaries sponsor defined benefit pension plans or non-retirement post-employment benefits covering substantially all of their employees. Benefits are provided based on employees’ years of service and earnings, or in accordance with applicable employee benefit regulations. The Company’s practice is to fund amounts sufficient to meet the requirements set forth in the applicable employee benefit and tax regulations. The cost recorded of $2.8 million and $1.8 million for the three months ended December 31, 2015 and 2014, respectively, and $8.6 million and $5.7 million for the nine months ended December 31, 2015 and 2014, respectively, was primarily related to service costs.


## us-gaap:DebtDisclosureTextBlock

[0001032975-16-000068:notes:51]
Financing Arrangements

[0001032975-16-000068:notes:52]
The Company had several uncommitted, unsecured bank lines of credit aggregating $45.5 million as of December 31, 2015. There are no financial covenants under these lines of credit with which the Company must comply. As of December 31, 2015, the Company had outstanding bank guarantees of $21.8 million under these lines of credit. There was no borrowing outstanding under these lines of credit as of December 31, 2015 or March 31, 2015.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001032975-16-000068:notes:53]
Discontinued operations

[0001032975-16-000068:notes:54]
During the third quarter of fiscal year 2016, the Company's Board of Directors approved a plan to divest the Lifesize video conferencing business. Subsequently, on December 28, 2015 in the fourth quarter of fiscal year 2016, the Company and Lifesize, Inc.(“Lifesize”), a wholly owned subsidiary of the Company which holds the assets of the Company’s video conferencing reportable segment, entered into a stock purchase agreement (the “Stock Purchase Agreement”) with entities affiliated with three venture capital firms - Redpoint Ventures, Sutter Hill Ventures and Meritech Capital Partners (the "Venture Investors").  Pursuant to the terms of the Stock Purchase Agreement, the Company sold 2,500,000 shares of Series B Preferred Stock of Lifesize to the Venture Investors for cash proceeds of $2,500,000 and retained 12,000,000 non-voting shares of Series A Preferred Stock of Lifesize.  The shares of Series A Preferred Stock of Lifesize retained by the Company represent 37.5% of the total shares outstanding immediately after the closing of the transactions (the "Closing").  Lifesize also issued 17,500,000 shares of Series B Preferred Stock to the Venture Investors for cash proceeds of $17,500,000. The shares of Series B Preferred Stock held by the Venture Investors represent 62.5% of the total shares outstanding immediately after the Closing.  In addition, Lifesize reserved 8,000,000 shares of common stock for issuance pursuant to a stock plan to be adopted by Lifesize following the Closing (the “Employee Pool”), none of which are issued or outstanding at the Closing. The divestiture of the Lifesize video conferencing business is effective on December 28, 2015. The Stock Purchase Agreement contains representations, warranties and covenants of the parties and includes certain indemnification obligations of the Company to the Venture Investors. See “Note 10 - Commitments and Contingencies” for more information. The Stock Purchase Agreement also contains certain post-closing working capital adjustments. Post closing continuing involvement with the discontinued operations includes certain customary services and support which are expected to be provided to Lifesize during the transition period from December 28, 2015 until approximately the end of the third quarter of fiscal year 2017.

[0001032975-16-000068:notes:55]
The disposition of the Lifesize video conferencing business represents a strategic shift as contemplated by ASC 205-20, Presentation of Financial statement - Discontinued Operations, ("ASC 205-20") that will have a major effect on the Company's operations and financial results. As such, the Company has classified the results of its Lifesize video conferencing business as discontinued operations in its condensed consolidated statement of operations for all periods presented. Additionally, the related assets and liabilities associated with the discontinued operations are classified as held for sale on its condensed consolidated balance sheets for all periods presented. Evaluating whether the disposal of the business represents a strategic shift requires the Company's judgment. Also, evaluating whether the strategic shift will have a "major effect" on the Company's operations and financial results requires assessing not only quantitative factors but also the magnitude of qualitative factors.

[0001032975-16-000068:notes:56]
The retained Series A Preferred Stock gives the Company no voting rights or other influence over the disposed Lifesize video conferencing business, and therefore is expected to be accounted for as a cost-method investment which is expected to be recognized at fair value. The Company expects to recognize a disposal gain of $15 million to $20 million as a result of the divestiture, which will be reported in discontinued operations included in the results of the fourth quarter of fiscal year 2016.

[0001032975-16-000068:notes:57]
Discontinued operations include results of the Lifesize video conferencing business. Discontinued operations also includes other costs incurred by Logitech to effect the divestiture of the Lifesize video conferencing business. These costs include transaction charges, advisory and consulting fees and restructuring cost related to the Lifesize video conferencing business.

[0001032975-16-000068:notes:58]
The following table presents financial results of the video conferencing segment classified as discontinued operations (in thousands):

[0001032975-16-000068:notes:59]
|  |  | Three Months EndedDecember 31, |  | Nine Months Ended December 31, |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Net sales |  | $ | 21,553 |  |  | $ | 29,882 |  |  | $ | 65,554 |  |  | $ | 84,093 |  |
| Cost of goods sold |  | 8,240 |  |  | 11,206 |  |  | 24,951 |  |  | 30,062 |  |
| Gross profit |  | 13,313 |  |  | 18,676 |  |  | 40,603 |  |  | 54,031 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketing and selling |  | 8,877 |  |  | 15,822 |  |  | 31,550 |  |  | 44,112 |  |
| Research and development |  | 4,924 |  |  | 6,218 |  |  | 16,592 |  |  | 17,248 |  |
| General and administrative |  | 1,836 |  |  | 1,636 |  |  | 5,308 |  |  | 4,195 |  |
| Restructuring charges (credits), net |  | 1,064 |  |  | (146 | ) |  | 8,070 |  |  | (111 | ) |
| Total operating expenses |  | 16,701 |  |  | 23,530 |  |  | 61,520 |  |  | 65,444 |  |
| Operating loss from discontinued operations |  | (3,388 | ) |  | (4,854 | ) |  | (20,917 | ) |  | (11,413 | ) |
| Interest expense and other expense, net |  | (47 | ) |  | (328 | ) |  | (180 | ) |  | (385 | ) |
| Loss from discontinued operations before income taxes |  | (3,435 | ) |  | (5,182 | ) |  | (21,097 | ) |  | (11,798 | ) |
| Benefit from income taxes |  | (481 | ) |  | (1,548 | ) |  | (365 | ) |  | (737 | ) |
| Net loss from discontinued operations |  | $ | (2,954 | ) |  | $ | (3,634 | ) |  | $ | (20,732 | ) |  | $ | (11,061 | ) |

[0001032975-16-000068:notes:60]
The following table presents the aggregate carrying amounts of the classes of held for sale assets and liabilities (in thousands):

[0001032975-16-000068:notes:61]
|  |  | December 31,2015 |  | March 31,2015 |
| Carrying amounts of assets included as part of discontinued operations: |  |  |  |  |
| Cash and cash equivalents |  | $ | 3,905 |  |  | $ | 3,659 |  |
| Accounts receivable, net |  | 10,360 |  |  | 12,627 |  |
| Inventories |  | 12,708 |  |  | 14,749 |  |
| Other current assets |  | 1,996 |  |  | 1,067 |  |
| Total current assets |  | 28,969 |  |  | 32,102 |  |
| Property, plant and equipment, net |  | 3,965 |  |  | 5,115 |  |
| Other assets |  | 1,541 |  |  | 2,521 |  |
| Total non-current assets |  | 5,506 |  |  | 7,636 |  |
| Total assets classified as held for sale on the condensed consolidated balance sheets |  | $ | 34,475 |  |  | $ | 39,738 |  |
| Carrying amounts of liabilities included as part of discontinued operations: |  |  |  |  |
| Accounts payable |  | 2,434 |  |  | 7,198 |  |
| Accrued and other current liabilities |  | 32,208 |  |  | 31,568 |  |
| Total current liabilities |  | 34,642 |  |  | 38,766 |  |
| Non-current liabilities |  | 10,063 |  |  | 10,337 |  |
| Total liabilities classified as held for sale on the condensed consolidated balance sheets |  | $ | 44,705 |  |  | $ | 49,103 |  |

[0001032975-16-000068:notes:62]
The following table presents the components of certain balance sheet asset amounts as of December 31 and March 31, 2015 from discontinued operations (in thousands):

[0001032975-16-000068:notes:63]
|  |  | December 31,2015 |  | March 31,2015 |
| Accounts receivable, net: |  |  |  |  |  |  |
| Accounts receivable |  | $ | 13,397 |  |  | $ | 16,082 |  |
| Allowance for accounts receivable |  | (3,037 | ) |  | (3,455 | ) |
|  |  | $ | 10,360 |  |  | $ | 12,627 |  |
| Inventories: |  |  |  |  |  |  |
| Raw materials |  | $ | 574 |  |  | $ | 332 |  |
| Finished goods |  | 12,134 |  |  | 14,417 |  |
|  |  | $ | 12,708 |  |  | $ | 14,749 |  |
| Property, plant and equipment, net: |  |  |  |  |  |  |
| Property, plant and equipment |  | 16,019 |  |  | 16,672 |  |
| Less: accumulated depreciation and amortization |  | (12,054 | ) |  | (11,557 | ) |
|  |  | $ | 3,965 |  |  | $ | 5,115 |  |

[0001032975-16-000068:notes:64]
The following table presents the components of certain balance sheet liability amounts as of December 31 and March 31, 2015 from discontinued operations (in thousands):

[0001032975-16-000068:notes:65]
|  |  | December 31,2015 |  | March 31,2015 |
| Accrued and other current liabilities: |  |  |  |  |  |  |
| Accrued personnel expenses |  | $ | 4,201 |  |  | $ | 3,992 |  |
| Deferred revenue |  | 24,499 |  |  | 24,423 |  |
| Other current liabilities |  | 3,508 |  |  | 3,153 |  |
|  |  | $ | 32,208 |  |  | $ | 31,568 |  |
| Non-current liabilities: |  |  |  |  |  |  |
| Long term deferred revenue |  | 9,359 |  |  | 9,109 |  |
| Other non-current liabilities |  | 704 |  |  | 1,228 |  |
|  |  | $ | 10,063 |  |  | $ | 10,337 |  |


## us-gaap:EarningsPerShareTextBlock

[0001032975-16-000068:notes:66]
[same as prior period, unchanged from 0001032975-15-000052:notes:41]

[0001032975-16-000068:notes:67]
[same as prior period, unchanged from 0001032975-15-000052:notes:42]

[0001032975-16-000068:notes:68]
|  |  | Three Months EndedDecember 31, |  | Nine Months Ended December 31, |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Net Income (loss): |  |  |  |  |  |  |  |  |
| Continuing operations |  | 68,040 |  |  | 66,418 |  |  | 111,352 |  |  | 129,611 |  |
| Discontinued operations |  | (2,954 | ) |  | (3,634 | ) |  | (20,732 | ) |  | (11,061 | ) |
| Net income |  | $ | 65,086 |  |  | $ | 62,784 |  |  | $ | 90,620 |  |  | $ | 118,550 |  |
| Shares used in net income (loss) per share computation: |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding - basic |  | 162,669 |  |  | 163,533 |  |  | 163,521 |  |  | 163,261 |  |
| Effect of potentially dilutive equivalent shares |  | 2,499 |  |  | 2,788 |  |  | 2,430 |  |  | 2,815 |  |
| Weighted average shares outstanding - diluted |  | 165,168 |  |  | 166,321 |  |  | 165,951 |  |  | 166,076 |  |
| Net income (loss) per share - basic: |  |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.42 |  |  | $ | 0.41 |  |  | $ | 0.68 |  |  | $ | 0.79 |  |
| Discontinued operations |  | $ | (0.02 | ) |  | $ | (0.03 | ) |  | $ | (0.13 | ) |  | $ | (0.06 | ) |
| Net income per share - basic |  | $ | 0.40 |  |  | $ | 0.38 |  |  | $ | 0.55 |  |  | $ | 0.73 |  |
| Net income (loss) per share - diluted: |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.41 |  |  | $ | 0.40 |  |  | $ | 0.67 |  |  | $ | 0.78 |  |
| Discontinued operations |  | $ | (0.02 | ) |  | $ | (0.02 | ) |  | $ | (0.12 | ) |  | $ | (0.07 | ) |
| Net income per share - diluted |  | $ | 0.39 |  |  | $ | 0.38 |  |  | $ | 0.55 |  |  | $ | 0.71 |  |

[0001032975-16-000068:notes:69]
Share equivalents attributable to outstanding stock options and restricted stock units ("RSUs") of 6.3 million and 8.1 million for the three months ended December 31, 2015 and 2014, respectively, and 6.6 million and 8.1 million for the nine months ended December 31, 2015 and 2014, were anti-dilutive and excluded from the calculation of diluted net income per share.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001032975-16-000068:notes:70]
[same as prior period, unchanged from 0001032975-15-000052:notes:45]

[0001032975-16-000068:notes:71]
[same as prior period, unchanged from 0001032975-15-000052:notes:46]

[0001032975-16-000068:notes:72]
[same as prior period, unchanged from 0001032975-15-000052:notes:47]

[0001032975-16-000068:notes:73]
[same as prior period, unchanged from 0001032975-15-000052:notes:48]

[0001032975-16-000068:notes:74]
[same as prior period, unchanged from 0001032975-15-000052:notes:49]

[0001032975-16-000068:notes:75]
[same as prior period, unchanged from 0001032975-15-000052:notes:50]

[0001032975-16-000068:notes:76]
|  |  | December 31, 2015 |  | March 31, 2015 |
|  |  | Level 1 |  | Level 2 |  | Level 1 |  | Level 2 |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 80,000 |  |  | $ | — |  |  | $ | 264,597 |  |  | $ | — |  |
|  |  | $ | 80,000 |  |  | $ | — |  |  | $ | 264,597 |  |  | $ | — |  |
| Trading investments for deferred compensation plan: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 2,898 |  |  | $ | — |  |  | $ | 2,936 |  |  | $ | — |  |
| Mutual funds |  | 12,367 |  |  | — |  |  | 14,301 |  |  | — |  |
|  |  | $ | 15,265 |  |  | $ | — |  |  | $ | 17,237 |  |  | $ | — |  |
| Foreign exchange derivative assets |  | $ | — |  |  | $ | 22 |  |  | $ | — |  |  | $ | 2,080 |  |
| Foreign exchange derivative liabilities |  | $ | — |  |  | $ | 1,108 |  |  | $ | — |  |  | $ | 75 |  |

[0001032975-16-000068:notes:77]
There were no material Level 3 financial assets as of December 31 or March 31, 2015.

[0001032975-16-000068:notes:78]
[same as prior period, unchanged from 0001032975-15-000052:notes:53]

[0001032975-16-000068:notes:79]
The marketable securities for the Company's deferred compensation plan are recorded at a fair value of $15.3 million and $17.2 million as of December 31, 2015 and March 31, 2015, respectively, based on quoted market prices. Quoted market prices are observable inputs that are classified as Level 1 within the fair value hierarchy. Unrealized trading gains / (losses) related to trading securities for the three or nine months ended December 31, 2015 and 2014 were not significant and are included in other income (expense), net.

[0001032975-16-000068:notes:80]
[same as prior period, unchanged from 0001032975-15-000052:notes:55]

[0001032975-16-000068:notes:81]
Under certain agreements with the respective counterparties to the Company’s derivative contracts, subject to applicable requirements, the Company is allowed to net settle transactions of the same type with a single net amount payable by one party to the other. However, the Company presents its derivative assets and derivative liabilities on a gross basis on the Condensed Consolidated Balance Sheets as of December 31, 2015 and March 31, 2015.

[0001032975-16-000068:notes:82]
The fair values of the Company’s derivative instruments not designated as hedging instruments were not material as of December 31, 2015 or March 31, 2015. The following table presents the fair values of the Company’s derivative instruments designated as hedging instruments and their accounting line presentation on its Condensed Consolidated Balance Sheets as of December 31, 2015 and March 31, 2015 (in thousands):

[0001032975-16-000068:notes:83]
|  |  | Derivatives |
|  |  | Asset |  | Liability |
|  |  | December 31,2015 |  | March 31,2015 |  | December 31,2015 |  | March 31,2015 |
| Cash flow hedges |  | $ | 17 |  |  | $ | 2,080 |  |  | $ | 1,032 |  |  | $ | — |  |

[0001032975-16-000068:notes:84]
The amount of gain (loss) recognized on derivatives not designated as hedging instruments were not material in all periods presented herein. The following table presents the amounts of gains (losses) on the Company’s derivative instruments designated as hedging instruments and their locations on its condensed consolidated statements of operations and condensed consolidated statements of comprehensive income for the three and nine months ended December 31, 2015 and 2014 (in thousands):

[0001032975-16-000068:notes:85]
|  |  | Three Months EndedDecember 31, |
|  |  | Amount of Gain (Loss) Deferred as a Component of Accumulated Other Comprehensive Loss After Reclassification to Costs of Goods Sold |  | Amount of Loss (Gain) Reclassified from Accumulated Other Comprehensive Loss to Costs of Goods Sold |  | Amount of Gain (Loss) Immediately Recognized inOther Expense, Net |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Cash flow hedges |  | $ | (17 | ) |  | $ | (739 | ) |  | $ | 45 |  |  | $ | (2,025 | ) |  | $ | 64 |  |  | $ | 36 |  |

[0001032975-16-000068:notes:86]
|  |  | Nine Months Ended December 31, |
|  |  | Amount of Gain (Loss) Deferred as a Component of Accumulated Other Comprehensive Loss After Reclassification to Costs of Goods Sold |  | Amount of Loss (Gain) Reclassified from Accumulated Other Comprehensive Loss to Costs of Goods Sold |  | Amount of Gain (Loss) Immediately Recognized inOther Expense, Net |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Cash flow hedges |  | $ | (3,679 | ) |  | $ | 3,198 |  |  | $ | (2,443 | ) |  | $ | (1,840 | ) |  | $ | 207 |  |  | $ | (20 | ) |

[0001032975-16-000068:notes:87]
[same as prior period, unchanged from 0001032975-15-000052:notes:62]

[0001032975-16-000068:notes:88]
The Company enters into currency exchange forward contracts to hedge against exposure to changes in currency exchange rates related to its subsidiaries’ forecasted inventory purchases. The Company has one entity with a euro functional currency that purchases inventory in U.S. Dollars. The primary risk managed by using derivative instruments is the currency exchange rate risk. However, there can be no assurance the hedges will offset more than a portion of the financial impact resulting from movements in currency exchange rates. The Company has designated these derivatives as cash flow hedges. These hedging contracts mature within four months, and are denominated in the same currency as the underlying transactions. Gains and losses in the fair value of the effective portion of the hedges are deferred as a component of accumulated other comprehensive loss until the hedged inventory purchases are sold, at which time the gains or losses are reclassified to cost of goods sold. The Company assesses the effectiveness of the hedges by comparing changes in the spot rate of the currency underlying the forward contract with changes in the spot rate of the currency in which the forecasted transaction will be consummated. If the underlying transaction being hedged fails to occur or if a portion of the hedge does not generate offsetting changes in the currency exposure of forecasted inventory purchases, the Company immediately recognizes the gain or loss on the associated financial instrument in other income (expense), net. Such gains and losses were not material during the three or nine months ended December 31, 2015 and 2014. Cash flows from such hedges are classified as operating activities in the condensed consolidated statements of cash flows. The notional amounts of currency exchange forward contracts outstanding related to forecasted inventory purchases were $48.4 million and $43.5 million at December 31, 2015 and March 31, 2015, respectively. The Company estimates that $0.3 million of net gains related to its cash flow hedges included in accumulated other comprehensive loss as of December 31, 2015 will be reclassified into earnings within the next 12 months.

[0001032975-16-000068:notes:89]
[same as prior period, unchanged from 0001032975-15-000052:notes:64]

[0001032975-16-000068:notes:90]
The Company also enters into currency exchange forward and swap contracts to reduce the short-term effects of currency exchange rate fluctuations on certain foreign currency receivables or payables. These contracts generally mature within one month. The primary risk managed by using forward and swap contracts is the currency exchange rate risk. The gains or losses on currency exchange contracts are recognized in other income (expense), net based on the changes in fair value.

[0001032975-16-000068:notes:91]
The notional amounts of currency exchange forward and swap contracts outstanding as of December 31 and March 31, 2015 relating to foreign currency receivables or payables were $81.8 million and $61.7 million, respectively. Open forward and swap contracts outstanding at December 31, 2015 and March 31, 2015 consisted of contracts in Mexican Pesos, Japanese Yen, British Pounds, Taiwanese Dollars and Australian Dollars to be settled at future dates at pre-determined exchange rates.

[0001032975-16-000068:notes:92]
[same as prior period, unchanged from 0001032975-15-000052:notes:67]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001032975-16-000068:notes:93]
[same as prior period, unchanged from 0001032975-15-000052:notes:68]

[0001032975-16-000068:notes:94]
In accordance with ASC Topic 350-10 (“ASC 350-10”), the Company conducts a goodwill impairment analysis annually at December 31 or more frequently if indicators of impairment exist or if a decision is made to sell or exit a business. A significant amount of judgment is involved in determining if an indicator of impairment has occurred. Such indicators may include deterioration in general economic conditions, negative developments in equity and credit markets, adverse changes in the markets in which an entity operates, increases in input costs that have a negative effect on earnings and cash flows, or a trend of negative or declining cash flows over multiple periods, among others. The fair value that could be realized in an actual transaction may differ from that used to evaluate the impairment of goodwill.

[0001032975-16-000068:notes:95]
In reviewing goodwill for impairment, an entity has the option to first assess qualitative factors to determine whether the existence of events or circumstances leads to a determination that it is more likely than not (greater than 50%) that the estimated fair value of a reporting unit is less than its carrying amount. If an entity elects to perform a qualitative assessment and determines that an impairment is more likely than not, the entity is then required to perform the two-step quantitative impairment test, otherwise no further analysis is required. An entity also may elect not to perform the qualitative assessment and, instead, proceed directly to the two-step quantitative impairment test. The ultimate outcome of the goodwill impairment review for a reporting unit should be the same whether an entity chooses to perform the qualitative assessment or proceeds directly to the two-step quantitative impairment test. As of December 31, 2015 and March 31, 2015, all of the Company's goodwill is related to the peripherals reporting unit.

[0001032975-16-000068:notes:96]
The Company performed its annual impairment analysis of the goodwill for its peripherals reporting unit at December 31, 2015 by performing a qualitative assessment and concluded that it was more likely than not that the fair value of its peripherals reporting unit exceeded its carrying amount.  In assessing the qualitative factors, the Company considered the impact of these key factors: change in industry and competitive environment, growth in market capitalization to $2.5 billion as of December 31, 2015 from $2.3 billion a year ago, and budgeted-to-actual revenue performance from prior year.

[0001032975-16-000068:notes:97]
The following table summarizes the activity in the Company’s goodwill balance during the nine months ended December 31, 2015 (in thousands):

[0001032975-16-000068:notes:98]
| As of March 31, 2015 |  | $ | 218,213 |  |
| Currency impact |  | (15 | ) |
| As of December 31, 2015 |  | $ | 218,198 |  |

[0001032975-16-000068:notes:99]
[same as prior period, unchanged from 0001032975-15-000052:notes:72]

[0001032975-16-000068:notes:100]
Amortization expense for other intangible assets was $0.1 million and $0.2 million for the three months ended December 31, 2015 and 2014, respectively, and $0.4 million and $0.6 million for the nine months ended December 31, 2015 and 2014, respectively.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001032975-16-000068:notes:101]
[same as prior period, unchanged from 0001032975-15-000052:notes:74]

[0001032975-16-000068:notes:102]
[same as prior period, unchanged from 0001032975-15-000052:notes:75]

[0001032975-16-000068:notes:103]
The income tax provision for the three months ended December 31, 2015 was $1.4 million based on an effective income tax rate of 2.1% of pre-tax income, compared to an income tax provision of $0.7 million based on an effective income tax rate of 1.0% of pre-tax income for the three months ended December 31, 2014. The income tax provision for the nine months ended December 31, 2015 was $7.0 million based on an effective income tax rate of 5.9% of pre-tax income, compared to an income tax provision of $8.5 million based on an effective income tax rate of 6.1% of pre-tax income for the nine months ended December 31, 2014.

[0001032975-16-000068:notes:104]
The change in the effective income tax rate for the three and nine months ended December 31, 2015, compared to the three and nine months ended December 31, 2014, is due to the mix of income and losses in the various tax jurisdictions in which the Company operates. In the three months ended December 31, 2015 and December 31, 2014, there was a discrete tax benefit of $8.4 million and $8.0 million, respectively, from the reversal of uncertain tax positions from the expiration of statutes of limitations. In the nine months ended December 31, 2015 and December 31, 2014, there was an additional discrete tax benefit of $2.2 million and $0.8 million, respectively, from the preferential income tax rate reduction pursuant to the High and New Technology Enterprise Program in China.

[0001032975-16-000068:notes:105]
On December 18, 2015, the enactment of the Protecting Americans from Tax Hikes Act of 2015 in the U.S. extended the federal research and development tax credit permanently which had previously expired on December 31, 2014. The income tax provision in the three and nine months ended December 31, 2015 reflected a $1.2 million tax benefit, respectively, as a result of the extension of the tax credit.

[0001032975-16-000068:notes:106]
As of December 31 and March 31, 2015, the total amount of unrecognized tax benefits due to uncertain tax positions was $75.9 million and $79.0 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-16-000068:notes:107]
The Company had $67.9 million in non-current income taxes payable and $0.1 million in current income taxes payable, including interest and penalties, related to our income tax liability for uncertain tax positions as of December 31, 2015, compared to $72.1 million in non-current income taxes payable and $0.1 million in current income taxes payable as of March 31, 2015.

[0001032975-16-000068:notes:108]
The Company recognizes interest and penalties related to unrecognized tax positions in income tax expense. As of December 31 and March 31, 2015, the Company had $4.3 million and $4.9 million of accrued interest and penalties related to uncertain tax positions, respectively.

[0001032975-16-000068:notes:109]
Although the Company has adequately provided for uncertain tax positions, the provisions on these positions may change as revised estimates are made or the underlying matters are settled or otherwise resolved. During fiscal year 2016, the Company will continue to review its tax positions and provide for or reverse unrecognized tax benefits as issues arise. During the next 12 months, it is reasonably possible that the amount of unrecognized tax benefits could increase or decrease significantly due to changes in tax law in various jurisdictions, new tax audits and changes in the U.S. dollar as compared to other currencies. Excluding these factors, uncertain tax positions may decrease by as much as $17.1 million from the lapse of the statutes of limitations in various jurisdictions during the next 12 months.


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0001032975-16-000068:notes:110]
[same as prior period, unchanged from 0001032975-15-000052:notes:83]

[0001032975-16-000068:notes:111]
|  |  | December 31,2015 |  | March 31,2015 |
| Americas |  | $ | 41,170 |  |  | $ | 44,263 |  |
| EMEA |  | 3,294 |  |  | 3,473 |  |
| Asia Pacific |  | 54,681 |  |  | 38,742 |  |
|  |  | $ | 99,145 |  |  | $ | 86,478 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001032975-16-000068:notes:112]
[same as prior period, unchanged from 0001032975-15-000052:notes:85]

[0001032975-16-000068:notes:113]
[same as prior period, unchanged from 0001032975-15-000052:notes:86]

[0001032975-16-000068:notes:114]
During the first quarter of fiscal year 2016, the Company implemented a restructuring plan to exit the OEM business, reorganize Lifesize to sharpen its focus on its cloud-based offering, and streamline the Company's overall cost structure through product, overhead and infrastructure cost reductions with a targeted resource realignment. Restructuring charges incurred during the nine months ended December 31, 2015 under this plan primarily consisted of severance and other ongoing and one-time termination benefits. Charges and other costs related to the workforce reduction and structure realignment are presented as restructuring charges in the Condensed Consolidated Statements of Operations. On a total company basis, including the Lifesize video conferencing business as reported in discontinued operations, the Company expects to incur approximately $22 million to $25 million under this restructuring plan, including approximately $20.3 million to $23.3 million for cash severance and other personnel costs. Of these total amounts as of December 31, 2015, the Company has already paid $16.7 million. The Company expects to substantially complete this restructuring within the next 3 months.

[0001032975-16-000068:notes:115]
The following tables summarize restructuring related activities during the nine months ended December 31, 2015 from continuing operations:

[0001032975-16-000068:notes:116]
|  |  | Restructuring - Continuing Operations |
|  |  | TerminationBenefits |  | Lease ExitCosts |  | Other |  | Total |
| Accrual balance at March 31, 2015 |  | $ | — |  |  | $ | 954 |  |  | $ | — |  |  | $ | 954 |  |
| Charges, net |  | 11,469 |  |  | — |  |  | 69 |  |  | 11,538 |  |
| Cash payments |  | (3,727 | ) |  | (796 | ) |  | (44 | ) |  | (4,567 | ) |
| Accrual balance at June 30, 2015 |  | $ | 7,742 |  |  | $ | 158 |  |  | $ | 25 |  |  | $ | 7,925 |  |
| Charges, net |  | 3,124 |  |  | 38 |  |  | (16 | ) |  | 3,146 |  |
| Cash payments |  | (4,608 | ) |  | (115 | ) |  | (9 | ) |  | (4,732 | ) |
| Accrual balance at September 30, 2015 |  | $ | 6,258 |  |  | $ | 81 |  |  | $ | — |  |  | $ | 6,339 |  |
| Credits, net |  | (1,049 | ) |  | 299 |  |  | 84 |  |  | (666 | ) |
| Cash payments |  | (1,716 | ) |  | (255 | ) |  | 6 |  |  | (1,965 | ) |
| Accrual balance at December 31, 2015 |  | $ | 3,493 |  |  | $ | 125 |  |  | $ | 90 |  |  | $ | 3,708 |  |

[0001032975-16-000068:notes:117]
The following tables summarize restructuring related activities during the nine months ended December 31, 2015 from discontinued operations:

[0001032975-16-000068:notes:118]
|  |  | Restructuring - Discontinued Operations |  |
|  |  | TerminationBenefits |  | Lease ExitCosts |  | Other |  | Total |  |
| Accrual balance at March 31, 2015 |  | $ | — |  |  | $ | 85 |  |  | $ | — |  |  | $ | 85 |  |  |
| Charges, net |  | 1,325 |  |  | — |  |  | 132 |  |  | 1,457 |  |  |
| Cash payments |  | (948 | ) |  | — |  |  | (107 | ) |  | (1,055 | ) |  |
| Accrual balance at June 30, 2015 |  | $ | 377 |  |  | $ | 85 |  |  | $ | 25 |  |  | $ | 487 |  |  |
| Charges, net |  | 5,442 |  |  | — |  |  | 107 |  |  | 5,549 |  |  |
| Cash payments |  | (504 | ) |  | (7 | ) |  | (132 | ) |  | (643 | ) |  |
| Accrual balance at September 30, 2015 |  | $ | 5,315 |  |  | $ | 78 |  |  | $ | — |  |  | $ | 5,393 |  |  |
| Charges, net |  | 376 |  |  | — |  |  | 688 |  |  | 1,064 |  |  |
| Cash payments |  | (3,688 | ) |  | (7 | ) |  | (13 | ) |  | (3,708 | ) |  |
| Accrual balance at December 31, 2015 |  | $ | 2,003 |  |  | $ | 71 |  |  | $ | 675 |  |  | $ | 2,749 |  | * |

[0001032975-16-000068:notes:119]
* Includes $2.2 million in accrued and other current liabilities in continuing operations as it's expected to be paid by the continuing operations pursuant to the transaction occurred on December 28, 2015 (See Note 2) and thus does not meet the held for sale criteria pursuant to ASC 360.


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001032975-16-000068:notes:120]
Net sales to unaffiliated customers by geographic region (based on the customers’ location) for the three and nine months ended December 31, 2015 and 2014 were as follows (in thousands):

[0001032975-16-000068:notes:121]
|  |  | Three Months EndedDecember 31, |  | Nine Months Ended December 31, |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Americas |  | $ | 279,286 |  |  | $ | 266,499 |  |  | $ | 719,735 |  |  | $ | 678,343 |  |
| EMEA |  | 205,827 |  |  | 209,949 |  |  | 494,592 |  |  | 533,401 |  |
| Asia Pacific |  | 135,966 |  |  | 127,874 |  |  | 372,932 |  |  | 350,881 |  |
| Total net sales |  | $ | 621,079 |  |  | $ | 604,322 |  |  | $ | 1,587,259 |  |  | $ | 1,562,625 |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001032975-16-000068:notes:122]
On total company basis, the components of accumulated other comprehensive income (loss) was as follows (in thousands):

[0001032975-16-000068:notes:123]
|  |  | Accumulated Other Comprehensive Income (Loss) |
|  |  | CumulativeTranslationAdjustment (1) |  | DefinedBenefitPlan (1) |  | DeferredHedgingGains (Losses) |  | Total |
| March 31, 2015 |  | $ | (90,224 | ) |  | $ | (26,964 | ) |  | $ | 3,951 |  |  | $ | (113,237 | ) |
| Other comprehensive income (loss) |  | (488 | ) |  | 1,708 |  |  | (3,679 | ) |  | (2,459 | ) |
| December 31, 2015 |  | $ | (90,712 | ) |  | $ | (25,256 | ) |  | $ | 272 |  |  | $ | (115,696 | ) |

[0001032975-16-000068:notes:124]
(1)        Tax effect was not significant as of December 31 or March 31, 2015.


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001032975-16-000068:notes:125]
Net sales by product categories and sales channels, excluding intercompany transactions, for the three and nine months ended December 31, 2015 and 2014 were as follows (in thousands):

[0001032975-16-000068:notes:126]
|  |  | Three Months EndedDecember 31, |  | Nine Months Ended December 31, |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Mobile Speakers |  | $ | 85,081 |  |  | $ | 62,264 |  |  | $ | 206,175 |  |  | $ | 139,631 |  |
| Gaming |  | 77,706 |  |  | 70,188 |  |  | 189,000 |  |  | 164,570 |  |
| Video Collaboration |  | 26,216 |  |  | 16,935 |  |  | 67,460 |  |  | 45,968 |  |
| Tablet & Other Accessories |  | 35,873 |  |  | 55,100 |  |  | 73,222 |  |  | 114,974 |  |
| Growth |  | 224,876 |  |  | 204,487 |  |  | 535,857 |  |  | 465,143 |  |
| Pointing Devices |  | 139,711 |  |  | 141,789 |  |  | 381,364 |  |  | 382,524 |  |
| Keyboards & Combos |  | 116,531 |  |  | 114,051 |  |  | 324,458 |  |  | 325,217 |  |
| Audio-PC & Wearables |  | 57,300 |  |  | 56,741 |  |  | 149,341 |  |  | 162,480 |  |
| PC Webcams |  | 29,648 |  |  | 31,709 |  |  | 74,689 |  |  | 77,454 |  |
| Home Control |  | 25,684 |  |  | 25,116 |  |  | 48,548 |  |  | 56,224 |  |
| Profit Maximization |  | 368,874 |  |  | 369,406 |  |  | 978,400 |  |  | 1,003,899 |  |
| Retail Strategic Sales |  | 593,750 |  |  | 573,893 |  |  | 1,514,257 |  |  | 1,469,042 |  |
| Non-Strategic |  | 817 |  |  | 132 |  |  | 1,961 |  |  | 2,259 |  |
| Retail |  | 594,567 |  |  | 574,025 |  |  | 1,516,218 |  |  | 1,471,301 |  |
| OEM |  | 26,512 |  |  | 30,297 |  |  | 71,041 |  |  | 91,324 |  |
|  |  | $ | 621,079 |  |  | $ | 604,322 |  |  | $ | 1,587,259 |  |  | $ | 1,562,625 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001032975-16-000068:notes:127]
[same as prior period, unchanged from 0001032975-15-000052:notes:99]

[0001032975-16-000068:notes:128]
As discussed in "Note 1 — The Company and Summary of Significant Accounting Policies and Estimates", the Company's Peripherals segment remains as the sole reporting segment reported in continuing operations.

[0001032975-16-000068:notes:129]
The Company's Peripherals segment continues to encompass the design, manufacturing and marketing of peripherals for PCs, tablets and other digital platforms.  Operating performance measures for Peripherals reports directly to the Company's Chief Executive Officer (“CEO”), who is considered to be the Company’s Chief Operating Decision Maker (“CODM”). The CEO periodically reviews information such as net sales and operating income (loss) to make business decisions. These operating performance measures do not include restructuring charges, net, share-based compensation expense and amortization of intangible assets.

[0001032975-16-000068:notes:130]
[same as prior period, unchanged from 0001032975-15-000052:notes:103]

[0001032975-16-000068:notes:131]
Sales are attributed to countries on the basis of the customers’ locations. The United States represented 40% and 35% of the Company’s total consolidated net sales from continuing operations for the three months ended December 31, 2015 and 2014, respectively. No other single country represented more than 10% of the Company's total consolidated net sales during those periods. One customer group of the Company represented 13% and 14% of total consolidated net sales from continuing operations for the three months ended December 31, 2015 and 2014, respectively. Another customer group of the Company represented 13% of sales for the three months ended December 31, 2015.

[0001032975-16-000068:notes:132]
The United States represented 40% and 36% of the Company’s total consolidated net sales from continuing operations for the nine months ended December 31, 2015 and 2014, respectively. No other single country represented more than 10% of the Company’s total consolidated net sales from continuing operations during those periods. One customer group of the Company represented 14% and 15% of the Company’s total consolidated net sales from continuing operations for the nine months ended December 31, 2015 and 2014, respectively. Another customer group of the Company represented 10% of total consolidated net sales from continuing operations for the nine months ended December 31, 2015.

[0001032975-16-000068:notes:133]
Revenues from sales to customers in Switzerland, the Company’s home domicile, represented 2% of the Company’s total consolidated net sales from continuing operations for all the periods presented herein.

[0001032975-16-000068:notes:134]
Long-lived assets in the United States and China were $40.9 million and $50.3 million as of December 31, 2015, respectively, and $44.3 million and $33.4 million at March 31, 2015, respectively. No other countries represented more than 10% of the Company’s total consolidated long-lived assets as of December 31 or March 31, 2015. Long-lived assets in Switzerland, the Company’s home domicile, were $1.6 million and $1.5 million at December 31 and March 31, 2015, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001032975-16-000068:notes:135]
[same as prior period, unchanged from 0001032975-15-000052:notes:108]

[0001032975-16-000068:notes:136]
[same as prior period, unchanged from 0001032975-15-000052:notes:109]

[0001032975-16-000068:notes:137]
In March 2014, the Company’s Board of Directors approved the 2014 share buyback program, which authorizes the Company to use up to $250.0 million to purchase its own shares. The Company’s share buyback program is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market with consideration given to Logitech’s stock price, market conditions and other factors. During the nine months ended December 31, 2015, 3.5 million shares were repurchased for $48.8 million. There were no share repurchases during the three months ended December 31, 2015, or the three and nine months ended December 31, 2014.

[0001032975-16-000068:notes:138]
[same as prior period, unchanged from 0001032975-15-000052:notes:111]

[0001032975-16-000068:notes:139]
In September 2015, the Company declared and paid cash dividends of CHF 0.51 (USD equivalent of $0.53) per common share, totaling $85.9 million, on the Company’s outstanding common stock.

[0001032975-16-000068:notes:140]
[same as prior period, unchanged from 0001032975-15-000052:notes:113]

[0001032975-16-000068:notes:141]
[same as prior period, unchanged from 0001032975-15-000052:notes:114]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001032975-16-000068:notes:142]
[same as prior period, unchanged from 0001032975-15-000052:notes:115]
