# LOGI 8-K — 0001032975-16-000064 filed 2016-01-21

## item codes, every 8-K on or before 2016-01-22

- 2016-01-21 0001032975-16-000064 — 2.02, 9.01
- 2016-01-04 0001032975-16-000061 — 1.01, 2.01, 9.01
- 2015-12-23 0001032975-15-000059 — 5.02
- 2015-10-22 0001032975-15-000047 — 2.02, 9.01
- 2015-09-11 0001032975-15-000044 — 5.07, 8.01
- 2015-07-24 0001032975-15-000034 — 2.05 — amendment of 0001032975-15-000030
- 2015-07-23 0001032975-15-000030 — 2.02, 9.01
- 2015-06-25 0001032975-15-000025 — 5.02
- 2015-05-14 0001032975-15-000011 — 8.01, 9.01
- 2015-04-23 0001032975-15-000008 — 2.02, 2.05
- 2015-01-22 0001628280-15-000191 — 2.02, 8.01
- 2014-12-23 0001193125-14-450908 — 5.02, 5.07, 8.01
- 2014-11-25 0001193125-14-425233 — 3.01
- 2014-11-13 0001193125-14-411303 — 4.01, 9.01
- 2014-10-23 0001104659-14-073164 — 2.02, 9.01
- 2014-09-04 0001193125-14-331214 — 4.02, 9.01
- 2014-08-18 0001193125-14-313346 — 3.01, 9.01
- 2014-07-24 0001104659-14-053065 — 2.02, 9.01
- 2014-06-05 0001193125-14-226177 — 3.01, 9.01
- 2014-05-22 0001193125-14-208777 — 8.01, 9.01
- 2014-04-24 0001104659-14-029650 — 2.02, 9.01
- 2014-01-23 0001104659-14-003619 — 2.02, 9.01
- 2013-10-24 0001104659-13-077404 — 2.02, 9.01
- 2013-09-09 0001193125-13-361441 — 5.02, 5.07, 8.01, 9.01
- 2013-09-06 0001193125-13-359930 — 5.02, 9.01
- 2013-08-02 0001193125-13-317343 — 5.02
- 2013-07-25 0001104659-13-056372 — 2.02, 9.01
- 2013-06-28 0001193125-13-277394 — 5.02, 9.01
- 2013-06-20 0001193125-13-265914 — 8.01, 9.01
- 2013-04-25 0001104659-13-032570 — 2.02, 9.01
- 2013-04-17 0001193125-13-158923 — 5.02, 9.01
- 2013-03-01 0001193125-13-085804 — 2.05
- 2013-01-24 0001104659-13-004214 — 2.02, 9.01
- 2013-01-02 0001193125-13-000058 — 5.02
- 2012-10-25 0001104659-12-070966 — 2.02, 9.01
- 2012-09-11 0001193125-12-388070 — 5.02, 5.07, 8.01, 9.01
- 2012-08-22 0001193125-12-364167 — 5.02, 8.01, 9.01
- 2012-07-26 0001104659-12-051084 — 2.02, 9.01
- 2012-06-08 0001193125-12-264132 — 2.05, 9.01 — amendment, the index does not say of what
- 2012-04-26 0001193125-12-183657 — 5.02, 9.01
- 2012-04-26 0001104659-12-028470 — 2.02, 2.05, 9.01
- 2012-03-15 0001193125-12-115954 — 5.02, 9.01
- 2012-01-26 0001104659-12-004014 — 2.02, 9.01
- 2012-01-04 0001193125-12-002212 — 1.01, 2.03, 9.01
- 2011-10-27 0001104659-11-058150 — 2.02, 9.01
- 2011-09-12 0001193125-11-245931 — 5.07
- 2011-07-28 0001193125-11-200929 — 5.02, 9.01
- 2011-07-28 0001193125-11-199704 — 2.02, 9.01
- 2011-04-28 0001193125-11-112669 — 2.02, 9.01
- 2011-03-24 0001193125-11-076483 — 5.02, 9.01
- 2011-01-27 0001032975-11-000003 — 9.01
- 2010-10-28 0001032975-10-000032 — 9.01
- 2010-09-13 0001032975-10-000022 — 5.07
- 2010-07-29 0001032975-10-000010 — 2.02, 9.01
- 2010-06-10 0001193125-10-136877 — 5.02, 9.01
- 2010-05-03 0001193125-10-104337 — 5.02
- 2010-04-29 0001032975-10-000008 — 2.02, 9.01
- 2010-02-19 0001032975-10-000006 — 9.01 — amendment of 0001193125-09-252416
- 2010-01-21 0001032975-10-000002 — 2.02, 9.01
- 2009-12-14 0001193125-09-252416 — 2.01, 9.01
- 2009-11-17 0001032975-09-000023 — 1.01
- 2009-10-22 0001032975-09-000018 — 9.01
- 2009-09-22 0001193125-09-195545 — 5.02, 9.01
- 2009-09-03 0001032975-09-000013 — 8.01
- 2009-07-23 0001140361-09-016802 — 2.02, 9.01
- 2009-06-01 0001193125-09-122550 — 5.02
- 2009-04-23 0001193125-09-085054 — 2.02, 9.01
- 2009-04-02 0001193125-09-071272 — 5.02, 9.01
- 2009-01-20 0001193125-09-008454 — 2.05 — amendment of 0001193125-09-002609
- 2009-01-20 0001193125-09-007902 — 2.02, 9.01
- 2009-01-07 0001193125-09-002609 — 2.05, 9.01
- 2009-01-07 0001193125-09-002370 — 5.02, 9.01
- 2008-12-09 0001193125-08-250543 — 5.02, 9.01
- 2008-10-21 0001193125-08-213212 — 2.02, 9.01
- 2008-07-22 0001193125-08-154721 — 2.02, 9.01
- 2008-06-24 0001193125-08-139163 — 5.03, 9.01
- 2008-05-13 0001193125-08-113263 — 5.02, 9.01
- 2008-04-22 0001193125-08-086176 — 2.02, 9.01

## late-filing notifications on or before 2016-01-22

- 2015-06-02 0001032975-15-000020 — NT 10-K, for the period ended 2015-03-31
- 2014-11-06 0001193125-14-401306 — NT 10-Q, for the period ended 2014-09-30
- 2014-07-24 0001193125-14-277575 — NT 10-Q, for the period ended 2014-06-30
- 2014-05-22 0001193125-14-208712 — NT 10-K, for the period ended 2014-03-31
- 2009-08-06 0001032975-09-000006 — NT 10-Q, for the period ended 2009-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001032975-16-000064:8k_2_02:1]
EX-99.1
2
exhibit991q3fy16.htm
EXHIBIT 99.1

[0001032975-16-000064:8k_2_02:2]
Exhibit

[0001032975-16-000064:8k_2_02:3]
Exhibit 99.1

[0001032975-16-000064:8k_2_02:4]
Editorial Contacts:

[0001032975-16-000064:8k_2_02:5]
Joe Greenhalgh, Vice President, Investor Relations - USA (510) 713-4430

[0001032975-16-000064:8k_2_02:6]
Krista Todd, Vice President, External Communications - USA (510) 713-5834

[0001032975-16-000064:8k_2_02:7]
Ben Starkie, Corporate Communications - Europe +41-(0) 79-292-3499

[0001032975-16-000064:8k_2_02:8]
Logitech Delivers Better-Than-Expected Q3 Results and

[0001032975-16-000064:8k_2_02:9]
Raises FY 2016 Outlook

[0001032975-16-000064:8k_2_02:10]
Retail Sales Grow 9 Percent in Constant Currency

[0001032975-16-000064:8k_2_02:11]
NEWARK, Calif. - Jan. 20, 2016 and LAUSANNE, Switzerland, Jan. 21, 2016 - Logitech International (SIX: LOGN) (Nasdaq: LOGI) today announced financial results from continuing operations for the third quarter of Fiscal Year 2016.

[0001032975-16-000064:8k_2_02:12]
| • | Q3 sales were $621 million, up 3 percent compared to Q3 of the prior year. Q3 retail sales (total sales excluding OEM) were $595 million and grew 9 percent in constant currency. |

[0001032975-16-000064:8k_2_02:13]
| • | Q3 GAAP operating income was $69 million. Q3 GAAP earnings per share (EPS) were $0.41, compared to $0.40 in the same quarter a year ago. |

[0001032975-16-000064:8k_2_02:14]
| • | Q3 non-GAAP operating income was $74 million, with non-GAAP EPS of $0.41, compared to $0.43 in the same quarter a year ago. |

[0001032975-16-000064:8k_2_02:15]
| • | Cash flow from operations in the quarter, including Lifesize, was $166 million. |

[0001032975-16-000064:8k_2_02:16]
“We delivered a strong performance in Q3, evident across the business,” said Bracken P. Darrell, Logitech president and chief executive officer. “In this milestone quarter for the company, a new Logitech emerged as we completed the exit of our OEM business and separated Lifesize. Logitech’s future business remains - and the future looks bright.  We grew 9 percent in constant currency and our operating income and operating cash flow were strong. Combined, the Gaming, Mobile Speakers and Video Collaboration categories grew 34 percent in constant currency and each of them reached record high sales for a quarter. I’m delighted to raise our outlook as we enter the last quarter of the year.”

[0001032975-16-000064:8k_2_02:17]
Outlook

[0001032975-16-000064:8k_2_02:18]
Logitech increased its profitability outlook for Fiscal Year 2016 to approximately $170 million in           non-GAAP operating income from $150 million, which included Lifesize. The Company also increased its outlook for retail sales to 7 to 9 percent growth in constant currency, up from 7 percent.

[0001032975-16-000064:8k_2_02:19]
Prepared Remarks Available Online

[0001032975-16-000064:8k_2_02:20]
Logitech has made its prepared written remarks for the financial results teleconference available online on the Logitech corporate website at http://ir.logitech.com.

[0001032975-16-000064:8k_2_02:21]
Financial Results Teleconference and Webcast

[0001032975-16-000064:8k_2_02:22]
Logitech will hold a financial results teleconference to discuss the results for Q3 FY 2016 on Jan. 21, 2016 at 8:30 a.m. Eastern Standard Time and 2:30 p.m. Central European Time. A live webcast of the call will be available on the Logitech corporate website at http://ir.logitech.com.

[0001032975-16-000064:8k_2_02:23]
Continuing Operations

[0001032975-16-000064:8k_2_02:24]
Logitech separated its Lifesize division from the Company on Dec. 28, 2015. The Company’s third quarter of Fiscal Year 2016 ended on Dec. 25, 2015, even though, for purposes of presentation, the Company has indicated its third quarter periods as ending on Dec. 31. Except as otherwise noted, all of the results reported in this press release for both the third quarter of Fiscal Year 2016 and the third quarter of Fiscal Year 2015, as well as comparisons between periods, are focused on results from continuing operations and do not address the performance of Lifesize, which is now reported in the Company’s financial statements under discontinued operations or total Logitech including discontinued operations. Logitech’s previous outlook of $150 million in non-GAAP operating income included outlook for Lifesize results. Logitech’s new outlook does not include outlook for Lifesize results. For more information on the impact of the Lifesize separation on Logitech’s historical results, please refer to the Financial Reporting section of Logitech’s Financial History, available on the Logitech corporate website at http://ir.logitech.com.

[0001032975-16-000064:8k_2_02:25]
Use of Non-GAAP Financial Information

[0001032975-16-000064:8k_2_02:26]
To facilitate comparisons to Logitech’s historical results, Logitech has included non-GAAP adjusted measures, which exclude share-based compensation expense, amortization of other intangible assets, restructuring charges (credits), investment impairment (recovery), benefit from (provision for) income taxes, one-time special charges and other items detailed under “Supplemental Financial Information” after the tables below. Logitech also presents percentage sales growth in constant currency, a non-GAAP measure, to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales. Logitech believes this information will help investors to evaluate its current period performance and trends in its business. With respect to the Company’s outlook for non-GAAP operating income, most of these excluded amounts pertain to events that have not yet occurred and are not currently possible to estimate with a reasonable degree of accuracy. Therefore, no reconciliation to the GAAP amounts has been provided for Fiscal Year 2016.

[0001032975-16-000064:8k_2_02:27]
About Logitech

[0001032975-16-000064:8k_2_02:28]
Logitech designs products that have an everyday place in people's lives, connecting them to the digital experiences they care about. Over 30 years ago Logitech started connecting people through computers, and now it’s designing products that bring people together through music, gaming, video and computing. Founded in 1981, Logitech International is a Swiss public company listed on the SIX Swiss

[0001032975-16-000064:8k_2_02:29]
Exchange (LOGN) and on the Nasdaq Global Select Market (LOGI). Find Logitech at www.logitech.com, the company blog or @Logitech.

[0001032975-16-000064:8k_2_02:30]
# # #

[0001032975-16-000064:8k_2_02:31]
Note that unless noted otherwise, comparisons are year over year.

[0001032975-16-000064:8k_2_02:32]
2016 Logitech, Logicool, Logi and other Logitech marks are owned by Logitech and may be registered. All other trademarks are the property of their respective owners. For more information about Logitech and its products, visit the company’s website at www.logitech.com.

[0001032975-16-000064:8k_2_02:33]
(LOGIIR)

[0001032975-16-000064:8k_2_02:34]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| (In thousands, except per share amounts) - Unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | December 31 |  | December 31 |
| GAAP CONSOLIDATED STATEMENTS OF OPERATIONS |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Net sales |  | $ | 621,079 |  |  | $ | 604,322 |  |  | $ | 1,587,259 |  |  | $ | 1,562,625 |  |
| Cost of goods sold |  | 412,582 |  |  | 391,715 |  |  | 1,048,312 |  |  | 998,842 |  |
| Gross profit |  | 208,497 |  |  | 212,607 |  |  | 538,947 |  |  | 563,783 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Marketing and selling |  | 87,295 |  |  | 87,486 |  |  | 241,924 |  |  | 246,103 |  |
| Research and development |  | 29,273 |  |  | 27,397 |  |  | 86,336 |  |  | 80,009 |  |
| General and administrative |  | 24,080 |  |  | 28,172 |  |  | 77,966 |  |  | 96,762 |  |
| Restructuring charges (credits), net |  | (666 | ) |  | — |  |  | 14,018 |  |  | (35 | ) |
| Total operating expenses |  | 139,982 |  |  | 143,055 |  |  | 420,244 |  |  | 422,839 |  |
| Operating income |  | 68,515 |  |  | 69,552 |  |  | 118,703 |  |  | 140,944 |  |
| Interest income, net |  | 105 |  |  | 224 |  |  | 549 |  |  | 824 |  |
| Other income (expense), net |  | 862 |  |  | (2,688 | ) |  | (894 | ) |  | (3,702 | ) |
| Income from continuing operations before income taxes |  | 69,482 |  |  | 67,088 |  |  | 118,358 |  |  | 138,066 |  |
| Provision for income taxes |  | 1,442 |  |  | 670 |  |  | 7,006 |  |  | 8,455 |  |
| Net income from continuing operations |  | 68,040 |  |  | 66,418 |  |  | 111,352 |  |  | 129,611 |  |
| Loss from discontinued operations, net of taxes |  | (2,954 | ) |  | (3,634 | ) |  | (20,732 | ) |  | (11,061 | ) |
| Net income |  | $ | 65,086 |  |  | $ | 62,784 |  |  | $ | 90,620 |  |  | $ | 118,550 |  |
| Net income (loss) per share - basic: |  |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.42 |  |  | $ | 0.41 |  |  | $ | 0.68 |  |  | $ | 0.79 |  |
| Discontinued operations |  | $ | (0.02 | ) |  | $ | (0.03 | ) |  | $ | (0.13 | ) |  | $ | (0.06 | ) |
| Net income per share - basic |  | $ | 0.40 |  |  | $ | 0.38 |  |  | $ | 0.55 |  |  | $ | 0.73 |  |
| Net income (loss) per share - diluted: |  |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.41 |  |  | $ | 0.40 |  |  | $ | 0.67 |  |  | $ | 0.78 |  |
| Discontinued operations |  | $ | (0.02 | ) |  | $ | (0.02 | ) |  | $ | (0.12 | ) |  | $ | (0.07 | ) |
| Net income per share - diluted |  | $ | 0.39 |  |  | $ | 0.38 |  |  | $ | 0.55 |  |  | $ | 0.71 |  |
| Weighted average shares used to compute net income (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | 162,669 |  |  | 163,533 |  |  | 163,521 |  |  | 163,261 |  |
| Diluted |  | 165,168 |  |  | 166,321 |  |  | 165,951 |  |  | 166,076 |  |
| Cash dividends per share |  | $ | — |  |  | $ | 0.27 |  |  | $ | 0.53 |  |  | $ | 0.27 |  |

[0001032975-16-000064:8k_2_02:35]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |
| (In thousands) - Unaudited |  |  |  |  |
|  |  | December 31 |  | March 31, |
| CONSOLIDATED BALANCE SHEETS |  | 2015 |  | 2015 |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 505,082 |  |  | $ | 533,380 |  |
| Accounts receivable, net |  | 284,089 |  |  | 167,196 |  |
| Inventories |  | 239,962 |  |  | 255,980 |  |
| Other current assets |  | 71,661 |  |  | 63,362 |  |
| Current assets held for sale |  | 28,969 |  |  | 32,102 |  |
| Total current assets |  | 1,129,763 |  |  | 1,052,020 |  |
| Non-current assets: |  |  |  |  |
| Property, plant and equipment, net |  | 99,145 |  |  | 86,478 |  |
| Goodwill |  | 218,198 |  |  | 218,213 |  |
| Other assets |  | 57,271 |  |  | 62,333 |  |
| Long-term assets held for sale |  | 5,506 |  |  | 7,636 |  |
| Total assets |  | $ | 1,509,883 |  |  | $ | 1,426,680 |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 363,781 |  |  | $ | 292,797 |  |
| Accrued and other current liabilities |  | 211,219 |  |  | 163,344 |  |
| Current liabilities held for sale |  | 34,642 |  |  | 38,766 |  |
| Total current liabilities |  | 609,642 |  |  | 494,907 |  |
| Non-current liabilities: |  |  |  |  |  |  |
| Income taxes payable |  | 67,885 |  |  | 72,107 |  |
| Other non-current liabilities |  | 85,347 |  |  | 91,195 |  |
| Long-term liabilities held for sale |  | 10,063 |  |  | 10,337 |  |
| Total liabilities |  | 772,937 |  |  | 668,546 |  |
| Total shareholders' equity |  | 736,946 |  |  | 758,134 |  |
| Total liabilities and shareholders' equity |  | $ | 1,509,883 |  |  | $ | 1,426,680 |  |

[0001032975-16-000064:8k_2_02:36]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| (In thousands) - Unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | December 31 |  | December 31 |
| CONSOLIDATED STATEMENTS OF CASH FLOWS * |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 65,086 |  |  | $ | 62,784 |  |  | $ | 90,620 |  |  | $ | 118,550 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  | 14,647 |  |  | 9,867 |  |  | 36,884 |  |  | 29,559 |  |
| Amortization of other intangible assets |  | 310 |  |  | 2,266 |  |  | 1,536 |  |  | 7,624 |  |
| Share-based compensation expense |  | 6,618 |  |  | 7,047 |  |  | 19,875 |  |  | 20,046 |  |
| Investment impairment (recovery) |  | (4 | ) |  | 2,154 |  |  | 176 |  |  | 2,259 |  |
| Gain on disposal of property, plant and equipment |  | — |  |  | (34 | ) |  | — |  |  | (44 | ) |
| Excess tax benefits from share-based compensation |  | (926 | ) |  | (1,867 | ) |  | (2,089 | ) |  | (2,533 | ) |
| Deferred income taxes |  | 1,962 |  |  | (793 | ) |  | 2,914 |  |  | (3,151 | ) |
| Changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | (20,411 | ) |  | (57,465 | ) |  | (115,814 | ) |  | (131,026 | ) |
| Inventories |  | 73,508 |  |  | (3,187 | ) |  | 18,066 |  |  | (30,171 | ) |
| Other assets |  | (818 | ) |  | (952 | ) |  | (9,329 | ) |  | (6,592 | ) |
| Accounts payable |  | 18,402 |  |  | 51,198 |  |  | 68,763 |  |  | 111,310 |  |
| Accrued and other liabilities |  | 7,334 |  |  | 5,336 |  |  | 39,244 |  |  | 21,227 |  |
| Net cash provided by operating activities |  | 165,708 |  |  | 76,354 |  |  | 150,846 |  |  | 137,058 |  |
| Investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  | (19,166 | ) |  | (9,813 | ) |  | (50,443 | ) |  | (34,777 | ) |
| Investment in privately held companies |  | (1,619 | ) |  | — |  |  | (2,099 | ) |  | (2,550 | ) |
| Purchase of trading investments |  | (1,746 | ) |  | (1,233 | ) |  | (4,395 | ) |  | (3,463 | ) |
| Proceeds from sales of trading investments |  | 1,813 |  |  | 1,311 |  |  | 4,668 |  |  | 3,856 |  |
| Net cash used in investing activities |  | (20,718 | ) |  | (9,735 | ) |  | (52,269 | ) |  | (36,934 | ) |
| Financing activities: |  |  |  |  |  |  |  |  |
| Payment of cash dividends |  | — |  |  | (43,767 | ) |  | (85,915 | ) |  | (43,767 | ) |
| Contingent consideration related to prior acquisition |  | — |  |  | — |  |  | — |  |  | (100 | ) |
| Purchases of treasury shares |  | — |  |  | — |  |  | (48,802 | ) |  | — |  |
| Repurchase of ESPP awards |  | — |  |  | — |  |  | — |  |  | (1,078 | ) |
| Proceeds from sales of shares upon exercise of options and purchase rights |  | 1,459 |  |  | 933 |  |  | 12,562 |  |  | 2,466 |  |
| Tax withholdings related to net share settlements of restricted stock units |  | (1,855 | ) |  | (6,133 | ) |  | (5,357 | ) |  | (7,456 | ) |
| Excess tax benefits from share-based compensation |  | 926 |  |  | 1,867 |  |  | 2,089 |  |  | 2,533 |  |
| Net cash provided by (used in) financing activities |  | 530 |  |  | (47,100 | ) |  | (125,423 | ) |  | (47,402 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  | (2,307 | ) |  | (3,128 | ) |  | (1,205 | ) |  | (5,521 | ) |
| Net increase (decrease) in cash and cash equivalents |  | 143,213 |  |  | 16,391 |  |  | (28,051 | ) |  | 47,201 |  |
| Cash and cash equivalents, beginning of the period |  | 365,774 |  |  | 500,222 |  |  | 537,038 |  |  | 469,412 |  |
| Cash and cash equivalents, end of the period |  | $ | 508,987 |  |  | $ | 516,613 |  |  | $ | 508,987 |  |  | $ | 516,613 |  |
| The following amounts reflected in the statements of cash flows are included in discontinued operations: |
| Depreciation |  | $ | 787 |  |  | $ | 630 |  |  | $ | 2,207 |  |  | $ | 1,930 |  |
| Amortization of other intangible assets |  | $ | 198 |  |  | $ | 2,100 |  |  | $ | 1,089 |  |  | $ | 7,027 |  |
| Cash and cash equivalents, beginning of the period |  | $ | 4,639 |  |  | $ | 1,397 |  |  | $ | 3,659 |  |  | $ | 1,894 |  |
| Cash and cash equivalents, end of the period |  | $ | 3,905 |  |  | $ | 8,128 |  |  | $ | 3,905 |  |  | $ | 8,128 |  |

[0001032975-16-000064:8k_2_02:37]
__________________

[0001032975-16-000064:8k_2_02:38]
*Statements of cash flows include discontinued operations

[0001032975-16-000064:8k_2_02:39]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |  |  |  |  |
| (In thousands) - Unaudited |  |  |  |  |  |  |  |  |  |  |
| NET SALES |  | Three Months Ended |  | Nine Months Ended |
|  |  | December 31 |  | December 31 |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2015 |  | 2014 |  | Change |  | 2015 |  | 2014 |  | Change |
| Net sales by channel: |  |  |  |  |  |  |  |  |  |  |  |  |
| Retail |  | $ | 594,567 |  |  | $ | 574,025 |  |  | 4 | % |  | $ | 1,516,218 |  |  | $ | 1,471,301 |  |  | 3 | % |
| OEM |  | 26,512 |  |  | 30,297 |  |  | (12 | ) |  | 71,041 |  |  | 91,324 |  |  | (22 | ) |
| Total net sales |  | $ | 621,079 |  |  | $ | 604,322 |  |  | 3 |  |  | $ | 1,587,259 |  |  | $ | 1,562,625 |  |  | 2 |  |
| Net retail sales by product category(*): |  |  |  |  |  |  |  |  |  |  |  |  |
| Mobile Speakers |  | $ | 85,081 |  |  | $ | 62,264 |  |  | 37 |  |  | $ | 206,175 |  |  | $ | 139,631 |  |  | 48 |  |
| Gaming |  | 77,706 |  |  | 70,188 |  |  | 11 |  |  | 189,000 |  |  | 164,570 |  |  | 15 |  |
| Video Collaboration |  | 26,216 |  |  | 16,935 |  |  | 55 |  |  | 67,460 |  |  | 45,968 |  |  | 47 |  |
| Tablet & Other Accessories |  | 35,873 |  |  | 55,100 |  |  | (35 | ) |  | 73,222 |  |  | 114,974 |  |  | (36 | ) |
| Growth |  | 224,876 |  |  | 204,487 |  |  | 10 |  |  | 535,857 |  |  | 465,143 |  |  | 15 |  |
| Pointing Devices |  | 139,711 |  |  | 141,789 |  |  | (1 | ) |  | 381,364 |  |  | 382,524 |  |  | — |  |
| Keyboards & Combos |  | 116,531 |  |  | 114,051 |  |  | 2 |  |  | 324,458 |  |  | 325,217 |  |  | — |  |
| Audio-PC & Wearables |  | 57,300 |  |  | 56,741 |  |  | 1 |  |  | 149,341 |  |  | 162,480 |  |  | (8 | ) |
| PC Webcams |  | 29,648 |  |  | 31,709 |  |  | (6 | ) |  | 74,689 |  |  | 77,454 |  |  | (4 | ) |
| Home Control |  | 25,684 |  |  | 25,116 |  |  | 2 |  |  | 48,548 |  |  | 56,224 |  |  | (14 | ) |
| Profit Maximization |  | 368,874 |  |  | 369,406 |  |  | — |  |  | 978,400 |  |  | 1,003,899 |  |  | (3 | ) |
| Retail Strategic Sales |  | 593,750 |  |  | 573,893 |  |  | 3 |  |  | 1,514,257 |  |  | 1,469,042 |  |  | 3 |  |
| Non-Strategic |  | 817 |  |  | 132 |  |  | 519 |  |  | 1,961 |  |  | 2,259 |  |  | (13 | ) |
| Total net retail sales |  | $ | 594,567 |  |  | $ | 574,025 |  |  | 4 |  |  | $ | 1,516,218 |  |  | $ | 1,471,301 |  |  | 3 |  |
| __________________ |  |  |  |  |  |  |  |  |  |  |  |  |

[0001032975-16-000064:8k_2_02:40]
* Certain products within the retail product categories as presented in prior periods have been reclassified to conform to the current periods' presentation, with no impact on previously reported total net retail sales.

[0001032975-16-000064:8k_2_02:41]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| (In thousands, except per share amounts) - Unaudited |  |  |  |  |  |  |  |  |
| GAAP TO NON GAAP RECONCILIATION (A) |  | Three Months Ended |  | Nine Months Ended |
|  |  | December 31 |  | December 31 |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Gross profit - GAAP |  | $ | 208,497 |  |  | $ | 212,607 |  |  | $ | 538,947 |  |  | $ | 563,783 |  |
| Share-based compensation expense |  | 464 |  |  | 560 |  |  | 1,648 |  |  | 1,725 |  |
| Gross profit - Non-GAAP |  | $ | 208,961 |  |  | $ | 213,167 |  |  | $ | 540,595 |  |  | $ | 565,508 |  |
| Gross margin - GAAP |  | 33.6 | % |  | 35.2 | % |  | 34.0 | % |  | 36.1 | % |
| Gross margin - Non-GAAP |  | 33.6 | % |  | 35.3 | % |  | 34.1 | % |  | 36.2 | % |
| Operating expenses - GAAP |  | $ | 139,982 |  |  | $ | 143,055 |  |  | $ | 420,244 |  |  | $ | 422,839 |  |
| Less: Share-based compensation expense |  | 5,998 |  |  | 5,837 |  |  | 17,636 |  |  | 17,004 |  |
| Less: Amortization of other intangible assets |  | 112 |  |  | 166 |  |  | 447 |  |  | 597 |  |
| Less: Restructuring charges (credits), net |  | (666 | ) |  | — |  |  | 14,018 |  |  | (35 | ) |
| Less: One time special charge |  | (249 | ) |  | 2,528 |  |  | 4,121 |  |  | 19,524 |  |
| Operating expenses - Non-GAAP |  | $ | 134,787 |  |  | $ | 134,524 |  |  | $ | 384,022 |  |  | $ | 385,749 |  |
| % of net sales - GAAP |  | 22.5 | % |  | 23.7 | % |  | 26.5 | % |  | 27.1 | % |
| % of net sales - Non - GAAP |  | 21.7 | % |  | 22.3 | % |  | 24.2 | % |  | 24.7 | % |
| Operating income - GAAP |  | $ | 68,515 |  |  | $ | 69,552 |  |  | $ | 118,703 |  |  | $ | 140,944 |  |
| Share-based compensation expense |  | 6,462 |  |  | 6,397 |  |  | 19,284 |  |  | 18,729 |  |
| Amortization of other intangible assets |  | 112 |  |  | 166 |  |  | 447 |  |  | 597 |  |
| Restructuring charges (credits), net |  | (666 | ) |  | — |  |  | 14,018 |  |  | (35 | ) |
| One time special charge |  | (249 | ) |  | 2,528 |  |  | 4,121 |  |  | 19,524 |  |
| Operating income - Non - GAAP |  | $ | 74,174 |  |  | $ | 78,643 |  |  | $ | 156,573 |  |  | $ | 179,759 |  |
| % of net sales - GAAP |  | 11.0 | % |  | 11.5 | % |  | 7.5 | % |  | 9.0 | % |
| % of net sales - Non - GAAP |  | 11.9 | % |  | 13.0 | % |  | 9.9 | % |  | 11.5 | % |
| Net income from continuing operations |  | $ | 68,040 |  |  | $ | 66,418 |  |  | $ | 111,352 |  |  | $ | 129,611 |  |
| Share-based compensation expense |  | 6,462 |  |  | 6,397 |  |  | 19,284 |  |  | 18,729 |  |
| Amortization of other intangible assets |  | 112 |  |  | 166 |  |  | 447 |  |  | 597 |  |
| Restructuring charges (credits), net |  | (666 | ) |  | — |  |  | 14,018 |  |  | (35 | ) |
| One time special charge |  | (249 | ) |  | 2,528 |  |  | 4,121 |  |  | 19,524 |  |
| Investment impairment (recovery) |  | (4 | ) |  | 2,154 |  |  | 176 |  |  | 2,259 |  |
| Provision for income taxes |  | (6,709 | ) |  | (6,063 | ) |  | (9,961 | ) |  | (6,934 | ) |
| Net income from continuing operations - Non - GAAP |  | $ | 66,986 |  |  | $ | 71,600 |  |  | $ | 139,437 |  |  | $ | 163,751 |  |
| Net income from continuing operations per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  | $ | 0.41 |  |  | $ | 0.40 |  |  | $ | 0.67 |  |  | $ | 0.78 |  |
| Diluted - Non - GAAP |  | $ | 0.41 |  |  | $ | 0.43 |  |  | $ | 0.84 |  |  | $ | 0.99 |  |
| Shares used to compute net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP and Non - GAAP |  | 165,168 |  |  | 166,321 |  |  | 165,951 |  |  | 166,076 |  |

[0001032975-16-000064:8k_2_02:42]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| (In thousands) - Unaudited |  |  |  |  |  |  |  |  |
| SHARED BASED COMPENSATION EXPENSE |  | Three Months Ended |  | Nine Months Ended |
|  |  | December 31 |  | December 31 |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Share-based Compensation Expense |  |  |  |  |  |  |  |  |
| Cost of goods sold |  | $ | 464 |  |  | $ | 560 |  |  | $ | 1,648 |  |  | $ | 1,725 |  |
| Marketing and selling |  | 2,484 |  |  | 2,552 |  |  | 6,545 |  |  | 6,659 |  |
| Research and Development |  | 846 |  |  | 765 |  |  | 2,174 |  |  | 1,780 |  |
| General and administrative |  | 2,668 |  |  | 2,520 |  |  | 8,917 |  |  | 8,565 |  |
| Restructuring |  | — |  |  | — |  |  | 7 |  |  | — |  |
| Income tax benefit |  | (1,446 | ) |  | (1,391 | ) |  | (2,479 | ) |  | (4,285 | ) |
| Total share-based compensation expense, net of income taxes |  | $ | 5,016 |  |  | $ | 5,006 |  |  | $ | 16,812 |  |  | $ | 14,444 |  |
| __________________ |  |  |  |  |  |  |  |  |

[0001032975-16-000064:8k_2_02:43]
(A) Non-GAAP Financial Measures

[0001032975-16-000064:8k_2_02:44]
To supplement our condensed consolidated financial results prepared in accordance with GAAP, we use a number of financial measures, both GAAP and non-GAAP, in analyzing and assessing our overall business performance, for making operating decisions and for forecasting and planning future periods. We consider the use of non-GAAP financial measures helpful in assessing our current financial performance, ongoing operations and prospects for the future as well as understanding financial and business trends relating to our financial condition and results of operations.

[0001032975-16-000064:8k_2_02:45]
While we use non-GAAP financial measures as a tool to enhance our understanding of certain aspects of our financial performance and to provide incremental insight into the underlying factors and trends affecting both our performance and our cash-generating potential, we do not consider these measures to be a substitute for, or superior to, the information provided by GAAP financial measures. Consistent with this approach, we believe that disclosing non-GAAP financial measures to the readers of our financial statements provides useful supplemental data that, while not a substitute for GAAP financial measures, can offer insight in the review of our financial and operational performance and enables investors to more fully understand trends in our current and future performance. In assessing our business during the quarter ended December 31, 2015, we excluded items in the following general categories, each of which are described below:

[0001032975-16-000064:8k_2_02:46]
Share-based compensation expenses. We believe that providing non-GAAP measures excluding share-based compensation expense, in addition to the GAAP measures, allows for a more transparent comparison of our financial results from period to period. We prepare and maintain our budgets and forecasts for future periods on a basis consistent with this non-GAAP financial measure. Further, companies use a variety of types of equity awards as well as a variety of methodologies, assumptions and estimates to determine share-based compensation expense. We believe that excluding share-based compensation expense enhances our ability and the ability of investors to understand the impact of non-cash share-based compensation on our operating results and to compare our results against the results of other companies.

[0001032975-16-000064:8k_2_02:47]
Amortization of other intangible assets. We incur intangible asset amortization expense, primarily in connection with our acquisitions of various businesses and technologies. The amortization of purchased intangibles varies depending on the level of acquisition activity. We exclude these various charges in budgeting, planning and forecasting future periods and we believe that providing the non-GAAP measures excluding these various non-cash charges, as well as the GAAP measures, provides additional insight when comparing our operating expenses and financial results from period to period.

[0001032975-16-000064:8k_2_02:48]
Restructuring charges (credits). These expenses are associated with re-aligning our business strategies based on current economic conditions. We have undertaken several restructurings in recent years. In connection with our restructuring initiatives, we incurred restructuring charges related to employee terminations, facility closures and early cancellation of certain contracts. We believe that providing the non-GAAP measures excluding these charges, as well

[0001032975-16-000064:8k_2_02:49]
as the GAAP measures, assists our investors because such charges are not reflective of our ongoing operating results in the current period.

[0001032975-16-000064:8k_2_02:50]
Investment impairment (recovery). We incur investment impairment and recovery, primarily related to our investments in various privately-held companies. The investment impairment or recovery varies depending on the operational and financial performance of the privately-held companies we invested in. We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges are not reflective of our ongoing operations.

[0001032975-16-000064:8k_2_02:51]
One-time special charges:  costs related to investigations and related expenses.  These expenses are forensic accounting, audit, consulting and legal fees related to the Audit Committee’s investigation and the ongoing formal investigation by and settlement discussion with the Securities and Exchange Commission (SEC), together with accruals based on settlement discussion with the SEC.  We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges are one-time in nature and not reflective of our ongoing operations.

[0001032975-16-000064:8k_2_02:52]
Other charges. We provided non-GAAP measures excluding the effect of certain charges and income that are not reflective of our ongoing operations.

[0001032975-16-000064:8k_2_02:53]
In addition, Logitech presents percentage sales growth in constant currency, a non-GAAP measure, to show performance unaffected by fluctuations in currency exchange rates.  Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales. Sales for the three months ended December 31, 2015 compared to sales for the three months ended December 31, 2014 grew 8 percent in constant currency and grew 3 percent in U.S. Dollars. Retail sales for the three months ended December 31, 2015 compared to retail sales for the three months ended December 31, 2014 grew 9 percent in constant currency and grew 4 percent in U.S. Dollars. Sales for the combined Gaming, Mobile Speakers and Video Collaboration categories for the three months ended December 31, 2015 compared to sales for those combined categories for the three months ended December 31, 2014 grew 34 percent in constant currency and grew 27 percent in U.S. Dollars.

[0001032975-16-000064:8k_2_02:54]
Each of the non-GAAP financial measures described above, and used in this press release, should not be considered in isolation from, or as a substitute for, a measure of financial performance prepared in accordance with GAAP. Further, investors are cautioned that there are inherent limitations associated with the use of each of these non-GAAP financial measures as an analytical tool. In particular, these non-GAAP financial measures are not based on a comprehensive set of accounting rules or principles and many of the adjustments to the GAAP financial measures reflect the exclusion of items that are recurring and may be reflected in the Company’s financial results for the foreseeable future. We compensate for these limitations by providing specific information in the reconciliation included in this press release regarding the GAAP amounts excluded from the non-GAAP financial measures. In addition, as noted above, we evaluate the non-GAAP financial measures together with the most directly comparable GAAP financial information.
