# LOGI note change history — 0001032975-24-000046 → 0001032975-24-000075


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-10-24):
[0001032975-24-000075:note_history:1]
Changes in the Company’s warranty liabilities for the three and six months ended September 30, 2024 and 2023 were as follows (in thousands):
  (was, 2024-07-25, similarity 0.9243):
[0001032975-24-000046:note_history:1]
Changes in the Company’s warranty liabilities for the three months ended June 30, 2024 and 2023 were as follows (in thousands):

- added (2024-10-24):
[0001032975-24-000075:note_history:2]
|  | Three months ended September 30, |  | Six months ended September 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Beginning of the period | $ | 44,502 |  |  | $ | 39,885 |  |  | $ | 44,654 |  |  | $ | 40,886 |  |
| Provision | 11,776 |  |  | 10,393 |  |  | 21,962 |  |  | 19,485 |  |
| Settlements | (9,975) |  |  | (9,838) |  |  | (20,013) |  |  | (19,756) |  |
| Effects of foreign currency translation | 530 |  |  | (175) |  |  | 230 |  |  | (350) |  |
| End of the period | $ | 46,833 |  |  | $ | 40,265 |  |  | $ | 46,833 |  |  | $ | 40,265 |  |

- changed (2024-10-24):
[0001032975-24-000075:note_history:3]
The Company indemnifies certain suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of September 30, 2024, no material amounts have been accrued for indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.
  (was, 2024-07-25, similarity 0.9898):
[0001032975-24-000046:note_history:3]
The Company indemnifies certain suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of June 30, 2024, no material amounts have been accrued for indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

- added (2024-10-24):
[0001032975-24-000075:note_history:4]
From time to time the Company is involved in claims and legal proceedings that arise in the ordinary course of its business. The Company is currently subject to several such claims and legal proceedings. The Company intends to vigorously defend against them. Management periodically assesses the Company’s liabilities and contingencies in connection with these matters based upon the latest information available. The Company follows ASC

- changed (2024-10-24):
[0001032975-24-000075:note_history:5]
("Accounting Standards Codification") 450, Contingencies, in determining the accounting and disclosure for these contingencies. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows and results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company's defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company's business, financial condition, cash flows and results of operations in a particular period. Any claims or proceedings against the Company can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain a necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company's business.
  (was, 2024-07-25, similarity 0.8211):
[0001032975-24-000046:note_history:5]
From time to time the Company is involved in claims and legal proceedings that arise in the ordinary course of its business. The Company is currently subject to several such claims and legal proceedings. The Company intends to vigorously defend against them. Management periodically assesses the Company’s liabilities and contingencies in connection with these matters based upon the latest information available. The Company follows ASC ("Accounting Standards Codification") 450, Contingencies, in determining the accounting and disclosure for these contingencies. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows and results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company's defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company's business, financial condition, cash flows and results of operations in a particular period. Any claims or proceedings against the Company can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain a necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company's business.

- removed (2024-10-24):
[0001032975-24-000046:note_history:6]
|  | Three months ended June 30, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Beginning of the period | $ | 44,654 |  |  | $ | 40,886 |  |  |  |  |  |
| Provision | 10,186 |  |  | 9,092 |  |  |  |  |  |
| Settlements | (10,038) |  |  | (9,918) |  |  |  |  |  |
| Effects of foreign currency translation | (300) |  |  | (175) |  |  |  |  |  |
| End of the period | $ | 44,502 |  |  | $ | 39,885 |  |  |  |  |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-10-24):
[0001032975-24-000075:note_history:7]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and six months ended September 30, 2024 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2025, or any future periods.
  (was, 2024-07-25, similarity 0.7702):
[0001032975-24-000046:note_history:7]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three months ended June 30, 2024 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2025, or any future periods.

- changed (2024-10-24):
[0001032975-24-000075:note_history:8]
There have been no material changes in the Company’s significant accounting policies during the three and six months ended September 30, 2024 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2024.
  (was, 2024-07-25, similarity 0.9091):
[0001032975-24-000046:note_history:8]
There have been no material changes in the Company’s significant accounting policies during the three months ended June 30, 2024 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2024.

- changed (2024-10-24):
[0001032975-24-000075:note_history:9]
The Company's business has continued to be impacted by macroeconomic and geopolitical conditions. These conditions include inflation, interest rate and foreign currency fluctuations, changes in fiscal policies, geopolitical conflicts, low economic growth in certain regions, and uncertainty in consumer and enterprise demand.
  (was, 2024-07-25, similarity 0.8435):
[0001032975-24-000046:note_history:9]
The Company's business has continued to be impacted by macroeconomic and geopolitical conditions. These conditions include inflation, interest rate and foreign currency fluctuations, changes in fiscal policies, low economic growth in certain regions, and uncertainty in consumer and enterprise demand.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2024-10-24):
[0001032975-24-000075:note_history:10]
The Company had several uncommitted, unsecured bank lines of credit and letters of credit aggregating $178.7 million and $172.5 million as of September 30, 2024 and March 31, 2024, respectively. There are no financial covenants under the lines of credit with which the Company must comply. There was no borrowing outstanding under the lines of credit as of September 30, 2024 or March 31, 2024. As of September 30, 2024 and March 31, 2024, the Company had outstanding bank guarantees of $29.5 million and $14.3 million, respectively.

- removed (2024-10-24):
[0001032975-24-000046:note_history:11]
The Company had several uncommitted, unsecured bank lines of credit and letters of credit aggregating $171.8 million and $172.5 million as of June 30, 2024 and March 31, 2024, respectively. There are no financial covenants under the lines of credit with which the Company must comply. There was no borrowing outstanding under the lines of credit as of June 30, 2024 or March 31, 2024. As of June 30, 2024 and March 31, 2024, the Company had outstanding bank guarantees of $13.5 million and $14.3 million, respectively.
