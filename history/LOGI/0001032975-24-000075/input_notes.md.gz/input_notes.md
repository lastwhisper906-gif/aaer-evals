# LOGI notes — 0001032975-24-000075


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001032975-24-000075:notes:1]
[same as prior period, unchanged from 0001032975-24-000046:notes:1]

[0001032975-24-000075:notes:2]
[same as prior period, unchanged from 0001032975-24-000046:notes:2]

[0001032975-24-000075:notes:3]
[same as prior period, unchanged from 0001032975-24-000046:notes:3]

[0001032975-24-000075:notes:4]
[same as prior period, unchanged from 0001032975-24-000046:notes:4]

[0001032975-24-000075:notes:5]
[same as prior period, unchanged from 0001032975-24-000046:notes:5]

[0001032975-24-000075:notes:6]
[same as prior period, unchanged from 0001032975-24-000046:notes:6]

[0001032975-24-000075:notes:7]
[same as prior period, unchanged from 0001032975-24-000046:notes:7]

[0001032975-24-000075:notes:8]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and six months ended September 30, 2024 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2025, or any future periods.

[0001032975-24-000075:notes:9]
[same as prior period, unchanged from 0001032975-24-000046:notes:9]

[0001032975-24-000075:notes:10]
There have been no material changes in the Company’s significant accounting policies during the three and six months ended September 30, 2024 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2024.

[0001032975-24-000075:notes:11]
[same as prior period, unchanged from 0001032975-24-000046:notes:11]

[0001032975-24-000075:notes:12]
[same as prior period, unchanged from 0001032975-24-000046:notes:12]

[0001032975-24-000075:notes:13]
[same as prior period, unchanged from 0001032975-24-000046:notes:13]

[0001032975-24-000075:notes:14]
[same as prior period, unchanged from 0001032975-24-000046:notes:14]

[0001032975-24-000075:notes:15]
The Company's business has continued to be impacted by macroeconomic and geopolitical conditions. These conditions include inflation, interest rate and foreign currency fluctuations, changes in fiscal policies, geopolitical conflicts, low economic growth in certain regions, and uncertainty in consumer and enterprise demand.

[0001032975-24-000075:notes:16]
[same as prior period, unchanged from 0001032975-24-000046:notes:16]

[0001032975-24-000075:notes:17]
[same as prior period, unchanged from 0001032975-24-000046:notes:17]

[0001032975-24-000075:notes:18]
In November 2023, the Financial Accounting Standard Board ("FASB") issued Accounting Standards Update ("ASU") 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures. ASU 2023-07 improves reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses that are regularly provided to the chief operating decision maker. In addition, ASU 2023-07 requires that all existing annual disclosures about segment profit or loss must be provided on an interim basis and clarifies that single reportable segment entities are subject to the disclosure requirement under Topic 280 in its entirety. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023 and interim periods within those fiscal years beginning after December 15, 2024. A public entity should apply ASU 2023-07 retrospectively to all prior periods presented in the financial statements. Early adoption is permitted. The Company is currently evaluating the impact of ASU 2023-07 on its consolidated financial statements and related disclosures. 
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures. ASU 2023-09 requires additional disclosures related to rate reconciliation, income taxes paid, and other disclosures. Under ASU 2023-09, for each annual period presented, public entities are required to (1) disclose specific categories in the tabular rate reconciliation and (2) provide additional information for reconciling items that meet a quantitative threshold. In addition, ASU 2023-09 requires all reporting entities to disclose on an annual basis the amount of income taxes paid disaggregated by federal, state, and foreign taxes as well as the amount of income taxes paid by individual jurisdiction. ASU 2023-09 is effective for public business entities for annual periods beginning after December 15, 2024 and can be applied on a prospective basis with an option to apply the standard retrospectively. Early adoption is permitted. The Company is currently evaluating the impact of ASU 2023-09 on its consolidated financial statements and related disclosures.


## us-gaap:EarningsPerShareTextBlock

[0001032975-24-000075:notes:19]
[same as prior period, unchanged from 0001032975-24-000046:notes:19]

[0001032975-24-000075:notes:20]
The following table summarizes the computations of basic and diluted net income per share for the three and six months ended September 30, 2024 and 2023 (in thousands, except per share amounts):

[0001032975-24-000075:notes:21]
|  |  | Three months ended September 30, |  | Six months ended September 30, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Net income |  | $ | 145,483 |  |  | $ | 137,117 |  |  | $ | 287,316 |  |  | $ | 199,844 |  |
| Shares used in net income per share computation: |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding - basic |  | 152,460 |  |  | 157,911 |  |  | 152,875 |  |  | 158,385 |  |
| Effect of potentially dilutive equivalent shares |  | 1,212 |  |  | 1,023 |  |  | 1,445 |  |  | 1,160 |  |
| Weighted average shares outstanding - diluted |  | 153,672 |  |  | 158,934 |  |  | 154,320 |  |  | 159,545 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.95 |  |  | $ | 0.87 |  |  | $ | 1.88 |  |  | $ | 1.26 |  |
| Diluted |  | $ | 0.95 |  |  | $ | 0.86 |  |  | $ | 1.86 |  |  | $ | 1.25 |  |

[0001032975-24-000075:notes:22]
Share equivalents attributable to outstanding stock options, restricted stock units and employee share purchase plans totaling 0.9 million and 1.1 million for the three months ended September 30, 2024 and 2023,

[0001032975-24-000075:notes:23]
respectively, and 1.0 million and 1.6 million for the six months ended September 30, 2024 and 2023, respectively, were excluded from the calculation of diluted net income per share because their effect would have been anti-dilutive. A small number of performance-based restricted stock units were not included in the dilutive net income per share calculation because all necessary conditions had not been satisfied by the end of the respective period, and those shares were not issuable if the end of the reporting period were the end of the performance contingency period.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001032975-24-000075:notes:24]
[same as prior period, unchanged from 0001032975-24-000046:notes:24]

[0001032975-24-000075:notes:25]
[same as prior period, unchanged from 0001032975-24-000046:notes:25]

[0001032975-24-000075:notes:26]
As of September 30, 2024, the Company offers the 2006 Employee Share Purchase Plan (Non-U.S.), as amended and restated, the 1996 Employee Share Purchase Plan (U.S.), as amended and restated, and the 2006 Stock Incentive Plan, as amended and restated. Shares issued to employees as a result of purchases or exercises under these plans are generally issued from shares held in treasury stock.

[0001032975-24-000075:notes:27]
The following table summarizes the share-based compensation expense and total income tax benefit recognized for share-based awards for the three and six months ended September 30, 2024 and 2023 (in thousands):

[0001032975-24-000075:notes:28]
|  |  | Three months ended September 30, |  | Six months ended September 30, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Cost of goods sold |  | $ | 3,902 |  |  | $ | 2,462 |  |  | $ | 6,500 |  |  | $ | 3,877 |  |
| Marketing and selling |  | 10,469 |  |  | 9,262 |  |  | 22,320 |  |  | 19,745 |  |
| Research and development |  | 5,067 |  |  | 4,694 |  |  | 10,806 |  |  | 9,147 |  |
| General and administrative |  | 7,031 |  |  | 5,650 |  |  | 10,248 |  |  | 10,810 |  |
| Total share-based compensation expense |  | 26,469 |  |  | 22,068 |  |  | 49,874 |  |  | 43,579 |  |
| Income tax benefit |  | (4,776) |  |  | (2,548) |  |  | (12,378) |  |  | (7,866) |  |
| Total share-based compensation expense, net of income tax benefit |  | $ | 21,693 |  |  | $ | 19,520 |  |  | $ | 37,496 |  |  | $ | 35,713 |  |

[0001032975-24-000075:notes:29]
[same as prior period, unchanged from 0001032975-24-000046:notes:29]

[0001032975-24-000075:notes:30]
Share-based compensation costs capitalized as part of inventory were $1.8 million and $1.5 million for the three months ended September 30, 2024 and 2023, respectively, and $4.3 million and $3.4 million for the six months ended September 30, 2024 and 2023, respectively.

[0001032975-24-000075:notes:31]
[same as prior period, unchanged from 0001032975-24-000046:notes:31]

[0001032975-24-000075:notes:32]
Certain of the Company’s subsidiaries sponsor defined benefit pension plans or non-retirement post-employment benefits covering substantially all of their employees. Benefits are provided based on employees’ years of service and earnings, or in accordance with applicable employee benefit regulations. The Company’s practice is to fund amounts sufficient to meet the requirements set forth in the applicable employee benefit and tax regulations. The costs of $1.8 million and $1.9 million recorded for the three months ended September 30, 2024 and 2023, respectively, and $3.5 million and $3.8 million recorded for the six months ended September 30, 2024 and 2023, respectively, were primarily related to service costs.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001032975-24-000075:notes:33]
[same as prior period, unchanged from 0001032975-24-000046:notes:33]

[0001032975-24-000075:notes:34]
[same as prior period, unchanged from 0001032975-24-000046:notes:34]

[0001032975-24-000075:notes:35]
The income tax provision for the three and six months ended September 30, 2024 was $30.6 million and $56.1 million based on an effective income tax rate of 17.4% and 16.3% of pre-tax income, respectively. The income tax

[0001032975-24-000075:notes:36]
provision for the same periods ended September 30, 2023 was $30.3 million and $42.9 million based on an effective income tax rate of 18.1% and 17.7% of pre-tax income, respectively.

[0001032975-24-000075:notes:37]
The change in the effective income tax rate for the three and six months ended September 30, 2024, compared with the same periods ended September 30, 2023, was primarily due to the change in the mix of income and losses in the various tax jurisdictions in which the Company operates, the favorable tax impacts from share-based compensation and unrecognized tax benefits due to uncertain tax positions.

[0001032975-24-000075:notes:38]
[same as prior period, unchanged from 0001032975-24-000046:notes:37]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001032975-24-000075:notes:39]
[same as prior period, unchanged from 0001032975-24-000046:notes:38]

[0001032975-24-000075:notes:40]
[same as prior period, unchanged from 0001032975-24-000046:notes:39]

[0001032975-24-000075:notes:41]
|  |  | September 30, 2024 |  | March 31, 2024 |
| Accounts receivable, net: |  |  |  |  |
| Accounts receivable |  | $ | 862,485 |  |  | $ | 744,836 |  |
| Allowance for sales returns |  | (13,521) |  |  | (10,180) |  |
| Allowance for cooperative marketing arrangements |  | (43,782) |  |  | (41,634) |  |
| Allowance for customer incentive programs |  | (74,841) |  |  | (60,027) |  |
| Allowance for pricing programs |  | (101,063) |  |  | (91,280) |  |
|  |  | $ | 629,278 |  |  | $ | 541,715 |  |
| Inventories: |  |  |  |  |
| Raw materials |  | $ | 55,634 |  |  | $ | 65,209 |  |
| Finished goods |  | 464,859 |  |  | 357,304 |  |
|  |  | $ | 520,493 |  |  | $ | 422,513 |  |
| Other current assets: |  |  |  |  |
| Value-added tax ("VAT") receivables |  | $ | 67,720 |  |  | $ | 41,172 |  |
| Prepaid expenses and other assets |  | 78,791 |  |  | 105,098 |  |
|  |  | $ | 146,511 |  |  | $ | 146,270 |  |
| Property, plant and equipment, net: |  |  |  |  |
| Property, plant and equipment |  | $ | 523,536 |  |  | $ | 503,882 |  |
| Less: accumulated depreciation and amortization |  | (411,179) |  |  | (387,293) |  |
|  |  | $ | 112,357 |  |  | $ | 116,589 |  |
| Other assets: |  |  |  |  |
| Deferred tax assets |  | $ | 227,009 |  |  | $ | 224,831 |  |
| Right-of-use assets |  | 79,076 |  |  | 61,163 |  |
| Investments for deferred compensation plan |  | 31,929 |  |  | 29,174 |  |
| Investments in privately held companies |  | 27,976 |  |  | 28,662 |  |
| Other assets |  | 8,066 |  |  | 6,364 |  |
|  |  | $ | 374,056 |  |  | $ | 350,194 |  |

[0001032975-24-000075:notes:42]
[same as prior period, unchanged from 0001032975-24-000046:notes:41]

[0001032975-24-000075:notes:43]
|  |  | September 30, 2024 |  | March 31, 2024 |
| Accrued and other current liabilities: |  |  |  |  |
| Accrued customer marketing, pricing and incentive programs |  | $ | 182,559 |  |  | $ | 170,371 |  |
| Accrued personnel expenses |  | 124,571 |  |  | 145,473 |  |
| Income taxes payable |  | 45,093 |  |  | 24,196 |  |
| Warranty liabilities |  | 32,100 |  |  | 30,270 |  |
| VAT payable |  | 27,638 |  |  | 28,253 |  |
| Accrued sales return liability |  | 27,275 |  |  | 30,098 |  |
| Deferred revenue (1) |  | 23,097 |  |  | 19,262 |  |
| Accrued loss for inventory purchase commitments |  | 21,807 |  |  | 29,349 |  |
| Operating lease liabilities |  | 16,011 |  |  | 15,107 |  |
| Other current liabilities |  | 146,680 |  |  | 144,883 |  |
|  |  | $ | 646,831 |  |  | $ | 637,262 |  |
| Other non-current liabilities: |  |  |  |  |
| Operating lease liabilities |  | $ | 79,100 |  |  | $ | 61,920 |  |
| Employee benefit plan obligations |  | 43,662 |  |  | 42,707 |  |
| Obligation for deferred compensation plan |  | 31,929 |  |  | 29,174 |  |
| Deferred revenue (1) |  | 31,512 |  |  | 21,097 |  |
| Warranty liabilities |  | 14,733 |  |  | 14,384 |  |
| Deferred tax liabilities |  | 744 |  |  | 705 |  |
| Other non-current liabilities |  | 2,819 |  |  | 2,603 |  |
|  |  | $ | 204,499 |  |  | $ | 172,590 |  |

[0001032975-24-000075:notes:44]
[same as prior period, unchanged from 0001032975-24-000046:notes:43]


## us-gaap:FairValueDisclosuresTextBlock

[0001032975-24-000075:notes:45]
[same as prior period, unchanged from 0001032975-24-000046:notes:44]

[0001032975-24-000075:notes:46]
[same as prior period, unchanged from 0001032975-24-000046:notes:45]

[0001032975-24-000075:notes:47]
[same as prior period, unchanged from 0001032975-24-000046:notes:46]

[0001032975-24-000075:notes:48]
[same as prior period, unchanged from 0001032975-24-000046:notes:47]

[0001032975-24-000075:notes:49]
[same as prior period, unchanged from 0001032975-24-000046:notes:48]

[0001032975-24-000075:notes:50]
[same as prior period, unchanged from 0001032975-24-000046:notes:49]

[0001032975-24-000075:notes:51]
|  |  | September 30, 2024 |  | March 31, 2024 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Level 1 |  | Level 2 |  | Level 3 |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 926,645 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,042,604 |  |  | $ | — |  |  | $ | — |  |
| Investments for deferred compensation plan included in other assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 203 |  |  | $ | — |  |  | $ | — |  |  | $ | 312 |  |  | $ | — |  |  | $ | — |  |
| Common stock |  | 710 |  |  | — |  |  | — |  |  | 573 |  |  | — |  |  | — |  |
| Money market funds |  | 8,456 |  |  | — |  |  | — |  |  | 8,129 |  |  | — |  |  | — |  |
| Mutual funds |  | 22,560 |  |  | — |  |  | — |  |  | 20,160 |  |  | — |  |  | — |  |
| Total investments for deferred compensation plan |  | $ | 31,929 |  |  | $ | — |  |  | $ | — |  |  | $ | 29,174 |  |  | $ | — |  |  | $ | — |  |
| Currency derivative assetsincluded in other current assets |  | $ | — |  |  | $ | 168 |  |  | $ | — |  |  | $ | — |  |  | $ | 913 |  |  | $ | — |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Contingent consideration included in accrued and other current liabilities |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,215 |  |
| Currency derivative liabilitiesincluded in accrued and other current liabilities |  | $ | — |  |  | $ | 714 |  |  | $ | — |  |  | $ | — |  |  | $ | 573 |  |  | $ | — |  |

[0001032975-24-000075:notes:52]
[same as prior period, unchanged from 0001032975-24-000046:notes:51]

[0001032975-24-000075:notes:53]
The marketable securities for the Company's deferred compensation plan were recorded at a fair value of $31.9 million and $29.2 million, as of September 30, 2024 and March 31, 2024, respectively, based on quoted market prices. Quoted market prices are observable inputs that are classified as Level 1 within the fair value hierarchy. Unrealized gains (losses) related to marketable securities for the three and six months ended September 30, 2024 and 2023 were not material and were included in other income (expense), net, and corresponding changes in the deferred compensation liability were included in operating expenses and cost of goods sold, in the Company's condensed consolidated statements of operations.

[0001032975-24-000075:notes:54]
[same as prior period, unchanged from 0001032975-24-000046:notes:53]

[0001032975-24-000075:notes:55]
The Company has certain non-marketable investments included in other assets that are accounted for as equity method investments, with a carrying value of $18.6 million and $18.0 million as of September 30, 2024 and March 31, 2024, respectively. Gains (losses) related to equity method investments for the three and six months ended September 30, 2024 and 2023 were not material and are included in other income (expense), net, in the Company's condensed consolidated statements of operations. There was no impairment of equity method investments during the three and six months ended September 30, 2024 and 2023.

[0001032975-24-000075:notes:56]
[same as prior period, unchanged from 0001032975-24-000046:notes:55]

[0001032975-24-000075:notes:57]
[same as prior period, unchanged from 0001032975-24-000046:notes:56]

[0001032975-24-000075:notes:58]
The Company has certain equity investments without readily determinable fair values due to the absence of quoted market prices, the inherent lack of liquidity, and the fact that inputs used to measure fair value are unobservable and require management's judgment. When certain events or circumstances indicate that impairment may exist, the Company revalues the investments using various assumptions, including the financial metrics and ratios of comparable public companies. The carrying value is also adjusted for observable price changes with the same or similar security from the same issuer. The amount of these equity investments without readily determinable fair value included in other assets was $8.8 million and $10.1 million as of September 30, 2024 and March 31, 2024, respectively. The impairment charges related to these equity investments were not material during the three and six

[0001032975-24-000075:notes:59]
months ended September 30, 2024. There were no impairment charges related to these equity investments during the three and six months ended September 30, 2023.

[0001032975-24-000075:notes:60]
During the six months ended September 30, 2023, the Company recorded an impairment loss, before tax, of $9.6 million as a result of the write-off of a note receivable which has been deemed no longer recoverable. This note receivable was previously obtained in conjunction with an exchange transaction related to the Company's investment in a privately held company. The impairment loss is included in other income (expense), net, in the Company's condensed consolidated statement of operations for the six months ended September 30, 2023.

[0001032975-24-000075:notes:61]
Non-Financial Assets
Goodwill, intangible assets, and property, plant and equipment, are not required to be measured at fair value on a recurring basis. However, if the Company is required to evaluate these non-financial assets for impairment, whether due to certain triggering events or because of the required annual impairment test, and a resulting impairment is recorded to reduce the carrying value to the fair value, the non-financial assets are measured at fair value during such period. There was no impairment of non-financial assets during the three and six months ended September 30, 2024 and 2023.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001032975-24-000075:notes:62]
[same as prior period, unchanged from 0001032975-24-000046:notes:61]

[0001032975-24-000075:notes:63]
Under certain agreements with the respective counterparties to the Company’s derivative contracts, subject to applicable requirements, the Company is allowed to net settle transactions of the same type with a single net amount payable by one party to the other. However, the Company presents its derivative assets and derivative liabilities on a gross basis in other current assets and accrued and other current liabilities, respectively, on the condensed consolidated balance sheets as of September 30, 2024 and March 31, 2024. See Note 6 for the fair values of the Company’s derivative instruments as of September 30, 2024 and March 31, 2024.

[0001032975-24-000075:notes:64]
[same as prior period, unchanged from 0001032975-24-000046:notes:63]

[0001032975-24-000075:notes:65]
[same as prior period, unchanged from 0001032975-24-000046:notes:64]

[0001032975-24-000075:notes:66]
The notional amounts of foreign currency exchange forward contracts outstanding related to forecasted inventory purchases were $144.4 million and $90.5 million as of September 30, 2024 and March 31, 2024, respectively. The Company had $1.8 million of net loss related to its cash flow hedges included in accumulated other comprehensive loss as of September 30, 2024, which will be reclassified into earnings within the next twelve months.

[0001032975-24-000075:notes:67]
The following table presents the amounts of gain (loss) on the Company’s derivative instruments designated as hedging instruments for the three and six months ended September 30, 2024 and 2023 and their locations on its condensed consolidated statements of operations and condensed consolidated statements of comprehensive income (in thousands):

[0001032975-24-000075:notes:68]
|  |  | Three months ended September 30, |
|  |  | Amount of Gain (Loss)Deferred as a Component of AccumulatedOther Comprehensive Loss |  | Amount of Loss (Gain)Reclassified from Accumulated Other Comprehensive Loss to Costs of Goods Sold |  |  |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |  |  |  |  |
| Cash flow hedges |  | $ | (2,931) |  |  | $ | 2,078 |  |  | $ | (906) |  |  | $ | 1,370 |  |  |  |  |  |
|  |  | Six months ended September 30, |
|  |  | Amount of Gain (Loss)Deferred as a Component of AccumulatedOther Comprehensive Loss |  | Amount of Loss (Gain)Reclassified from Accumulated Other Comprehensive Loss to Costs of Goods Sold |  |  |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |  |  |  |  |
| Cash flow hedges |  | $ | (1,349) |  |  | $ | 1,374 |  |  | $ | (1,639) |  |  | $ | 4,356 |  |  |  |  |  |

[0001032975-24-000075:notes:69]
[same as prior period, unchanged from 0001032975-24-000046:notes:68]

[0001032975-24-000075:notes:70]
[same as prior period, unchanged from 0001032975-24-000046:notes:69]

[0001032975-24-000075:notes:71]
The Company also enters into foreign currency exchange forward and swap contracts to reduce the short-term effects of currency exchange rate fluctuations on certain receivables or payables denominated in currencies other than the functional currencies of its subsidiaries. These contracts generally mature within approximately one month. The primary risk managed by using forward and swap contracts is the currency exchange rate risk. The gains or losses on these contracts are not material and included in other income (expense), net, in the condensed consolidated statements of operations based on the changes in fair value. The notional amounts of these contracts outstanding as of September 30, 2024 and March 31, 2024 were $121.4 million and $79.4 million, respectively.

[0001032975-24-000075:notes:72]
[same as prior period, unchanged from 0001032975-24-000046:notes:71]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001032975-24-000075:notes:73]
Goodwill and Other Intangible Assets
The Company conducts its impairment analysis of goodwill annually at December 31 or more frequently if changes in facts and circumstances indicate that it is more likely than not that the fair value of the Company’s reporting unit may be less than its carrying amount. There have been no triggering events identified affecting the valuation of goodwill and intangible assets during the three and six months ended September 30, 2024 and 2023.

[0001032975-24-000075:notes:74]
[same as prior period, unchanged from 0001032975-24-000046:notes:73]

[0001032975-24-000075:notes:75]
| As of March 31, 2024 |  | $ | 461,978 |  |
| Effects of foreign currency translation |  | 1,734 |  |
| As of September 30, 2024 |  | $ | 463,712 |  |

[0001032975-24-000075:notes:76]
[same as prior period, unchanged from 0001032975-24-000046:notes:75]

[0001032975-24-000075:notes:77]
|  |  | September 30, 2024 |  | March 31, 2024 |
|  |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |
| Trademarks and trade names |  | $ | 32,390 |  |  | $ | (27,207) |  |  | $ | 5,183 |  |  | $ | 32,390 |  |  | $ | (25,739) |  |  | $ | 6,651 |  |
| Developed technology |  | 107,421 |  |  | (91,768) |  |  | 15,653 |  |  | 107,421 |  |  | (86,855) |  |  | 20,566 |  |
| Customer contracts/relationships |  | 69,087 |  |  | (54,854) |  |  | 14,233 |  |  | 69,087 |  |  | (51,061) |  |  | 18,026 |  |
| Effects of foreign currency translation |  | (289) |  |  | 30 |  |  | (259) |  |  | (1,019) |  |  | 379 |  |  | (640) |  |
| Total |  | $ | 208,609 |  |  | $ | (173,799) |  |  | $ | 34,810 |  |  | $ | 207,879 |  |  | $ | (163,276) |  |  | $ | 44,603 |  |


## us-gaap:DebtDisclosureTextBlock

[0001032975-24-000075:notes:78]
Financing Arrangements

[0001032975-24-000075:notes:79]
The Company had several uncommitted, unsecured bank lines of credit and letters of credit aggregating $178.7 million and $172.5 million as of September 30, 2024 and March 31, 2024, respectively. There are no financial covenants under the lines of credit with which the Company must comply. There was no borrowing outstanding under the lines of credit as of September 30, 2024 or March 31, 2024. As of September 30, 2024 and March 31, 2024, the Company had outstanding bank guarantees of $29.5 million and $14.3 million, respectively.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001032975-24-000075:notes:80]
Commitments and Contingencies

[0001032975-24-000075:notes:81]
Product Warranties

[0001032975-24-000075:notes:82]
Changes in the Company’s warranty liabilities for the three and six months ended September 30, 2024 and 2023 were as follows (in thousands):

[0001032975-24-000075:notes:83]
|  | Three months ended September 30, |  | Six months ended September 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Beginning of the period | $ | 44,502 |  |  | $ | 39,885 |  |  | $ | 44,654 |  |  | $ | 40,886 |  |
| Provision | 11,776 |  |  | 10,393 |  |  | 21,962 |  |  | 19,485 |  |
| Settlements | (9,975) |  |  | (9,838) |  |  | (20,013) |  |  | (19,756) |  |
| Effects of foreign currency translation | 530 |  |  | (175) |  |  | 230 |  |  | (350) |  |
| End of the period | $ | 46,833 |  |  | $ | 40,265 |  |  | $ | 46,833 |  |  | $ | 40,265 |  |

[0001032975-24-000075:notes:84]
Indemnifications

[0001032975-24-000075:notes:85]
The Company indemnifies certain suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of September 30, 2024, no material amounts have been accrued for indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

[0001032975-24-000075:notes:86]
The Company also indemnifies its current and former directors and certain current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. The Company is unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not capped, the obligations are conditional in nature, and the facts and circumstances involved in any situation that might arise are variable.

[0001032975-24-000075:notes:87]
Legal Proceedings

[0001032975-24-000075:notes:88]
From time to time the Company is involved in claims and legal proceedings that arise in the ordinary course of its business. The Company is currently subject to several such claims and legal proceedings. The Company intends to vigorously defend against them. Management periodically assesses the Company’s liabilities and contingencies in connection with these matters based upon the latest information available. The Company follows ASC

[0001032975-24-000075:notes:89]
("Accounting Standards Codification") 450, Contingencies, in determining the accounting and disclosure for these contingencies. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows and results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company's defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company's business, financial condition, cash flows and results of operations in a particular period. Any claims or proceedings against the Company can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain a necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company's business.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001032975-24-000075:notes:90]
[same as prior period, unchanged from 0001032975-24-000046:notes:88]

[0001032975-24-000075:notes:91]
In June 2023, the Company's Board of Directors approved a three-year share repurchase program, which allows the Company to use up to $1.0 billion to repurchase its shares. The 2023 share repurchase program enables the Company to repurchase shares for cancellation, as well as to support equity incentive plans or potential acquisitions. The Swiss Takeover Board approved the 2023 share repurchase program in July 2023 and the program became effective on July 28, 2023. During the six months ended September 30, 2024, the Company repurchased 2.9 million shares for an aggregate cost of $262.1 million under the 2023 share repurchase program for cancellation, of which $18.4 million of the aggregate cost was not paid yet as of September 30, 2024. As of September 30, 2024, $373.9 million was available for repurchase under the 2023 share repurchase program.

[0001032975-24-000075:notes:92]
During the six months ended September 30, 2023, the Company repurchased 0.9 million shares for an aggregate cost of $60.1 million under the 2023 share repurchase program for cancellation. In addition, the Company repurchased 2.6 million shares for an aggregate cost of $159.1 million under the previous share repurchase program during the six months ended September 30, 2023. This previous share repurchase program was initially approved by the Company's Board of Directors in May 2020, to purchase Logitech shares to support equity incentive plans or potential acquisitions, and expired on July 27, 2023.

[0001032975-24-000075:notes:93]
Swiss law limits a company’s ability to hold or repurchase its own shares. The aggregate par value of all shares held in treasury by the Company and its subsidiaries may not exceed 10% of the share capital of the Company, which for the Company corresponds to approximately 17.3 million registered shares. This limitation does not apply to shares repurchased for cancellation, due to the Board of Directors’ authority under the Company’s capital band set forth in the Company’s Articles of Incorporation to cancel shares up to a limit of 10% of the Company's current share capital. As of September 30, 2024, the Company had a total of 21.3 million shares held in treasury stock, which includes 7.0 million shares that have been repurchased for cancellation and 14.3 million shares that have been purchased to support equity incentive plans or potential acquisitions.

[0001032975-24-000075:notes:94]
[same as prior period, unchanged from 0001032975-24-000046:notes:93]

[0001032975-24-000075:notes:95]
Share Cancellation

[0001032975-24-000075:notes:96]
In September 2024, the Company's Board of Directors approved the cancellation of 4.1 million treasury shares, which were repurchased in fiscal year 2024 for an aggregate cost of $332.1 million under the 2023 share repurchase program. The cancellation became effective in October 2024, and as a result both the number of registered shares issued and the number of treasury shares outstanding decreased by 4.1 million shares. Upon cancellation of these shares, the Company deducted the par value from registered shares and reflected the excess of share repurchase cost over par value as a reduction to retained earnings.

[0001032975-24-000075:notes:97]
Dividends

[0001032975-24-000075:notes:98]
During the three and six months ended September 30, 2024, the Company declared cash dividends of CHF 1.16 (USD equivalent of $1.37 based on the exchange rate on the date of declaration) per share and paid a total of $207.9 million on the Company's outstanding shares. During the three and six months ended September 30, 2023, the Company declared cash dividends of CHF 1.06 (USD equivalent of $1.19 based on the exchange rate on the date of declaration) per share and paid a total of $182.3 million on the Company's outstanding shares.

[0001032975-24-000075:notes:99]
Any future dividends will be subject to approval of the Company's shareholders.

[0001032975-24-000075:notes:100]
[same as prior period, unchanged from 0001032975-24-000046:notes:94]

[0001032975-24-000075:notes:101]
[same as prior period, unchanged from 0001032975-24-000046:notes:95]

[0001032975-24-000075:notes:102]
|  |  | Currency Translation Adjustment |  | Defined Benefit Plans |  | Deferred Hedging Gains (Losses) |  | Total |
| March 31, 2024 |  | $ | (103,947) |  |  | $ | (8,395) |  |  | $ | 1,140 |  |  | $ | (111,202) |  |
| Other comprehensive income (loss) |  | 15,570 |  |  | (752) |  |  | (2,988) |  |  | 11,830 |  |
| September 30, 2024 |  | $ | (88,377) |  |  | $ | (9,147) |  |  | $ | (1,848) |  |  | $ | (99,372) |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001032975-24-000075:notes:103]
[same as prior period, unchanged from 0001032975-24-000046:notes:97]

[0001032975-24-000075:notes:104]
The Company operates in a single operating segment that encompasses the design, manufacturing and marketing of peripherals for gaming, personal computers ("PCs"), tablets, video conferencing, and other digital platforms. Operating performance measures are provided directly to the Company's Chief Executive Officer ("CEO"), who is considered to be the Company’s Chief Operating Decision Maker. The CEO periodically reviews information such as sales and adjusted operating income (loss) to make business decisions. These operating performance measures do not include restructuring charges (credits), net, share-based compensation expense, amortization and impairment of intangible assets, acquisition-related costs, and change in fair value of contingent consideration from business acquisitions.

[0001032975-24-000075:notes:105]
Sales by product category for the three and six months ended September 30, 2024 and 2023 were as follows (in thousands):

[0001032975-24-000075:notes:106]
|  |  | Three months ended September 30, |  | Six months ended September 30, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Gaming (1) |  | $ | 300,470 |  |  | $ | 282,104 |  |  | $ | 609,945 |  |  | $ | 548,533 |  |
| Keyboards & Combos |  | 209,936 |  |  | 194,914 |  |  | 425,269 |  |  | 375,769 |  |
| Pointing Devices |  | 195,936 |  |  | 191,676 |  |  | 385,882 |  |  | 366,130 |  |
| Video Collaboration |  | 159,660 |  |  | 152,389 |  |  | 306,702 |  |  | 291,735 |  |
| Webcams |  | 80,249 |  |  | 88,222 |  |  | 153,153 |  |  | 163,422 |  |
| Tablet Accessories |  | 85,614 |  |  | 63,677 |  |  | 164,153 |  |  | 134,013 |  |
| Headsets |  | 46,916 |  |  | 44,411 |  |  | 91,152 |  |  | 81,261 |  |
| Other (2) |  | 37,253 |  |  | 39,615 |  |  | 67,995 |  |  | 70,644 |  |
| Total Sales |  | $ | 1,116,034 |  |  | $ | 1,057,008 |  |  | $ | 2,204,251 |  |  | $ | 2,031,507 |  |

[0001032975-24-000075:notes:107]
[same as prior period, unchanged from 0001032975-24-000046:notes:101]

[0001032975-24-000075:notes:108]
[same as prior period, unchanged from 0001032975-24-000046:notes:102]

[0001032975-24-000075:notes:109]
Sales by geographic region (based on the customers’ locations) for the three and six months ended September 30, 2024 and 2023 were as follows (in thousands):

[0001032975-24-000075:notes:110]
|  |  | Three months ended September 30, |  | Six months ended September 30, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Americas |  | $ | 480,081 |  |  | $ | 462,406 |  |  | $ | 965,370 |  |  | $ | 907,574 |  |
| EMEA |  | 351,886 |  |  | 311,805 |  |  | 661,703 |  |  | 570,683 |  |
| Asia Pacific |  | 284,067 |  |  | 282,797 |  |  | 577,178 |  |  | 553,250 |  |
| Total Sales |  | $ | 1,116,034 |  |  | $ | 1,057,008 |  |  | $ | 2,204,251 |  |  | $ | 2,031,507 |  |

[0001032975-24-000075:notes:111]
Revenue from sales to customers in the United States, Germany and China each represented 10% or more of the total consolidated sales for each of the periods presented herein. No other countries represented 10% or more of the Company’s total consolidated sales for the periods presented herein.

[0001032975-24-000075:notes:112]
Switzerland, the Company’s country of domicile, represented 3% of the Company's total consolidated sales for each of the three months ended September 30, 2024 and 2023, and 3% and 2% of the Company's total consolidated sales for the six months ended September 30, 2024 and 2023, respectively.

[0001032975-24-000075:notes:113]
Three customers of the Company each represented 10% or more of the total consolidated gross sales for each of the three and six months ended September 30, 2024 and 2023.

[0001032975-24-000075:notes:114]
[same as prior period, unchanged from 0001032975-24-000046:notes:108]

[0001032975-24-000075:notes:115]
|  |  | September 30, 2024 |  | March 31, 2024 |
| Americas |  | $ | 64,591 |  |  | $ | 67,762 |  |
| EMEA |  | 50,101 |  |  | 30,819 |  |
| Asia Pacific |  | 56,668 |  |  | 58,901 |  |
| Total |  | $ | 171,360 |  |  | $ | 157,482 |  |

[0001032975-24-000075:notes:116]
Property, plant and equipment, net (excluding software) and right-of-use assets in the United States, China and Ireland, were $62.9 million, $40.0 million, and $15.9 million, respectively, as of September 30, 2024. Property, plant and equipment, net (excluding software) and right-of-use assets in the United States, China, and Ireland were $66.5 million, $41.2 million, and $16.2 million, respectively, as of March 31, 2024. 
Property, plant and equipment, net (excluding software) and right-of-use assets in Switzerland, the Company’s country of domicile, were $26.2 million and $9.0 million as of September 30, 2024 and March 31, 2024, respectively. No other countries represented more than 10% of the Company’s total property, plant and equipment, net (excluding software) and right-of-use assets as of September 30, 2024 or March 31, 2024.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001032975-24-000075:notes:117]
On August 28, 2024, Samantha Harnett, our Chief Legal Officer, adopted a Rule 10b5-1 trading arrangement providing for the sale of an aggregate of up to 580 shares of our registered shares acquired by Ms. Harnett under our equity plans. The trading arrangement is intended to satisfy the affirmative defense in Rule 10b5-1(c). The first date that sales of any shares are permitted to be sold under the trading arrangement will be November 27, 2024. The trading arrangement terminates on February 28, 2025, or upon the earlier completion of all transactions thereunder.
