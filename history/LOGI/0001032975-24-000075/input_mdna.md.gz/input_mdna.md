# LOGI MD&A — 0001032975-24-000075


## mdna

[0001032975-24-000075:mdna:1]
[same as prior period, unchanged from 0001032975-24-000046:mdna:1]

[0001032975-24-000075:mdna:2]
[same as prior period, unchanged from 0001032975-24-000046:mdna:2]

[0001032975-24-000075:mdna:3]
[same as prior period, unchanged from 0001032975-24-000046:mdna:3]

[0001032975-24-000075:mdna:4]
[same as prior period, unchanged from 0001032975-24-000046:mdna:4]

[0001032975-24-000075:mdna:5]
[same as prior period, unchanged from 0001032975-24-000046:mdna:5]

[0001032975-24-000075:mdna:6]
[same as prior period, unchanged from 0001032975-24-000046:mdna:6]

[0001032975-24-000075:mdna:7]
[same as prior period, unchanged from 0001032975-24-000046:mdna:7]

[0001032975-24-000075:mdna:8]
[same as prior period, unchanged from 0001032975-24-000046:mdna:8]

[0001032975-24-000075:mdna:9]
[same as prior period, unchanged from 0001032975-24-000046:mdna:9]

[0001032975-24-000075:mdna:10]
•Our expectations regarding our potential indemnification obligations, and the outcome of pending or future legal proceedings and tax audits;

[0001032975-24-000075:mdna:11]
[same as prior period, unchanged from 0001032975-24-000046:mdna:11]

[0001032975-24-000075:mdna:12]
[same as prior period, unchanged from 0001032975-24-000046:mdna:12]

[0001032975-24-000075:mdna:13]
[same as prior period, unchanged from 0001032975-24-000046:mdna:13]

[0001032975-24-000075:mdna:14]
[same as prior period, unchanged from 0001032975-24-000046:mdna:14]

[0001032975-24-000075:mdna:15]
[same as prior period, unchanged from 0001032975-24-000046:mdna:15]

[0001032975-24-000075:mdna:16]
[same as prior period, unchanged from 0001032975-24-000046:mdna:16]

[0001032975-24-000075:mdna:17]
[same as prior period, unchanged from 0001032975-24-000046:mdna:17]

[0001032975-24-000075:mdna:18]
[same as prior period, unchanged from 0001032975-24-000046:mdna:19]

[0001032975-24-000075:mdna:19]
[same as prior period, unchanged from 0001032975-24-000046:mdna:20]

[0001032975-24-000075:mdna:20]
[same as prior period, unchanged from 0001032975-24-000046:mdna:21]

[0001032975-24-000075:mdna:21]
[same as prior period, unchanged from 0001032975-24-000046:mdna:22]

[0001032975-24-000075:mdna:22]
[same as prior period, unchanged from 0001032975-24-000046:mdna:23]

[0001032975-24-000075:mdna:23]
[same as prior period, unchanged from 0001032975-24-000046:mdna:24]

[0001032975-24-000075:mdna:24]
Our business has continued to be impacted by macroeconomic and geopolitical conditions. These conditions include inflation, interest rate and foreign currency fluctuations, changes in fiscal policies, geopolitical conflicts, low economic growth in certain regions, and uncertainty in consumer and enterprise demand.

[0001032975-24-000075:mdna:25]
[same as prior period, unchanged from 0001032975-24-000046:mdna:26]

[0001032975-24-000075:mdna:26]
[same as prior period, unchanged from 0001032975-24-000046:mdna:27]

[0001032975-24-000075:mdna:27]
[same as prior period, unchanged from 0001032975-24-000046:mdna:28]

[0001032975-24-000075:mdna:28]
[same as prior period, unchanged from 0001032975-24-000046:mdna:29]

[0001032975-24-000075:mdna:29]
[same as prior period, unchanged from 0001032975-24-000046:mdna:30]

[0001032975-24-000075:mdna:30]
[same as prior period, unchanged from 0001032975-24-000046:mdna:31]

[0001032975-24-000075:mdna:31]
[same as prior period, unchanged from 0001032975-24-000046:mdna:32]

[0001032975-24-000075:mdna:32]
[same as prior period, unchanged from 0001032975-24-000046:mdna:33]

[0001032975-24-000075:mdna:33]
[same as prior period, unchanged from 0001032975-24-000046:mdna:34]

[0001032975-24-000075:mdna:34]
[same as prior period, unchanged from 0001032975-24-000046:mdna:35]

[0001032975-24-000075:mdna:35]
22

[0001032975-24-000075:mdna:36]
[same as prior period, unchanged from 0001032975-24-000046:mdna:37]

[0001032975-24-000075:mdna:37]
[same as prior period, unchanged from 0001032975-24-000046:mdna:38]

[0001032975-24-000075:mdna:38]
[same as prior period, unchanged from 0001032975-24-000046:mdna:39]

[0001032975-24-000075:mdna:39]
[same as prior period, unchanged from 0001032975-24-000046:mdna:40]

[0001032975-24-000075:mdna:40]
[same as prior period, unchanged from 0001032975-24-000046:mdna:41]

[0001032975-24-000075:mdna:41]
Our total sales for the three and six months ended September 30, 2024 increased 6% and 9%, compared to the three and six months ended September 30, 2023, respectively, primarily due to an increase in sales for Gaming, Keyboards & Combos and Tablet Accessories, driven by improved demand.

[0001032975-24-000075:mdna:42]
Sales for the three months ended September 30, 2024 increased 13% and 4% in the EMEA and Americas regions, respectively, and remained flat in the Asia Pacific region, compared to the three months ended September 30, 2023. Sales for the six months ended September 30, 2024 increased 16%, 6%, and 4% in the EMEA, Americas, and Asia Pacific regions, respectively, compared to the six months ended September 30, 2023.

[0001032975-24-000075:mdna:43]
Gross margin was 43.6% for the three months ended September 30, 2024 and increased by 210 basis points, compared to the three months ended September 30, 2023, reflecting lower product costs and lower inventory reserves driven by improved demand, partially offset by higher promotional spending. Gross margin was 43.2% for the six months ended September 30, 2024 and increased by 310 basis points, compared to the six months ended September 30, 2023, primarily driven by lower product costs.

[0001032975-24-000075:mdna:44]
Operating expenses for the three months ended September 30, 2024 were $325.2 million, or 29.1% of sales, compared to $282.0 million, or 26.7% of sales, for the three months ended September 30, 2023. Operating expenses for the six months ended September 30, 2024 were $638.0 million, or 28.9% of sales, compared to $579.2 million, or 28.5% of sales, for the six months ended September 30, 2023. The increase in operating expense was primarily driven by an increase in marketing and advertising spend.

[0001032975-24-000075:mdna:45]
We had an income tax provision of $30.6 million and $30.3 million for the three months ended September 30, 2024 and September 30, 2023, respectively. We had an income tax provision of $56.1 million and $42.9 million for the six months ended September 30, 2024 and September 30, 2023, respectively. The change in the income tax provision for the three and six months ended September 30, 2024, compared to the three and six months ended September 30, 2023, respectively, was primarily due to the mix of income and losses in the various tax jurisdictions in which we operate, the favorable tax impacts from share-based compensation and unrecognized tax benefits due to uncertain tax positions.

[0001032975-24-000075:mdna:46]
Net income for the three and six months ended September 30, 2024 was $145.5 million and $287.3 million, respectively, compared to $137.1 million and $199.8 million, for the three and six months ended September 30, 2023, respectively.

[0001032975-24-000075:mdna:47]
[same as prior period, unchanged from 0001032975-24-000046:mdna:48]

[0001032975-24-000075:mdna:48]
[same as prior period, unchanged from 0001032975-24-000046:mdna:49]

[0001032975-24-000075:mdna:49]
[same as prior period, unchanged from 0001032975-24-000046:mdna:50]

[0001032975-24-000075:mdna:50]
[same as prior period, unchanged from 0001032975-24-000046:mdna:51]

[0001032975-24-000075:mdna:51]
[same as prior period, unchanged from 0001032975-24-000046:mdna:52]

[0001032975-24-000075:mdna:52]
There have been no material changes in our critical accounting estimates during the six months ended September 30, 2024 compared with the critical accounting estimates disclosed in Management's Discussion and Analysis of Financial Condition and Results of Operations included in our Annual Report on Form 10-K for the fiscal year ended March 31, 2024.

[0001032975-24-000075:mdna:53]
[same as prior period, unchanged from 0001032975-24-000046:mdna:54]

[0001032975-24-000075:mdna:54]
[same as prior period, unchanged from 0001032975-24-000046:mdna:55]

[0001032975-24-000075:mdna:55]
[same as prior period, unchanged from 0001032975-24-000046:mdna:56]

[0001032975-24-000075:mdna:56]
[same as prior period, unchanged from 0001032975-24-000046:mdna:57]

[0001032975-24-000075:mdna:57]
[same as prior period, unchanged from 0001032975-24-000046:mdna:58]

[0001032975-24-000075:mdna:58]
[same as prior period, unchanged from 0001032975-24-000046:mdna:59]

[0001032975-24-000075:mdna:59]
[same as prior period, unchanged from 0001032975-24-000046:mdna:60]

[0001032975-24-000075:mdna:60]
[same as prior period, unchanged from 0001032975-24-000046:mdna:61]

[0001032975-24-000075:mdna:61]
[same as prior period, unchanged from 0001032975-24-000046:mdna:62]

[0001032975-24-000075:mdna:62]
Our sales for the three and six months ended September 30, 2024 increased 6% and 9%, respectively, compared to the three and six months ended September 30, 2023, primarily due to an increase in sales for Gaming, Keyboards & Combos and Tablet Accessories, driven by improved demand. If currency exchange rates had been constant in the three and six months ended September 30, 2024 and 2023, our sales growth rates in constant currency would have been the same as the above sales growth rates.

[0001032975-24-000075:mdna:63]
[same as prior period, unchanged from 0001032975-24-000046:mdna:64]

[0001032975-24-000075:mdna:64]
Although our financial results are reported in U.S. Dollars, a portion of our sales was generated in currencies other than the U.S. Dollar, such as the Euro, Chinese Renminbi, Australian Dollar, Canadian Dollar, Japanese Yen, Pound Sterling and New Taiwan Dollar. During the three months ended September 30, 2024, approximately 49% of our sales were denominated in currencies other than the U.S. Dollar.

[0001032975-24-000075:mdna:65]
[same as prior period, unchanged from 0001032975-24-000046:mdna:66]

[0001032975-24-000075:mdna:66]
The following table presents the change in sales by region for the three and six months ended September 30, 2024, compared with the three and six months ended September 30, 2023:

[0001032975-24-000075:mdna:67]
|  |  | Sales Growth Rate |  | Constant DollarSales Growth Rate |
|  |  | Three Months EndedSeptember 30, 2024 |  | Six Months EndedSeptember 30, 2024 |  | Three Months EndedSeptember 30, 2024 |  | Six Months EndedSeptember 30, 2024 |
| Americas |  | 4 | % |  | 6 | % |  | 5 | % |  | 7 | % |
| EMEA |  | 13 | % |  | 16 | % |  | 13 | % |  | 16 | % |
| Asia Pacific |  | — | % |  | 4 | % |  | 1 | % |  | 7 | % |

[0001032975-24-000075:mdna:68]
[same as prior period, unchanged from 0001032975-24-000046:mdna:69]

[0001032975-24-000075:mdna:69]
The increase in sales in the Americas region for the three-month period presented above was primarily driven by an increase in sales for Keyboards & Combos and Tablet Accessories. The increase in sales in the Americas region for the six-month period presented above was primarily driven by an increase in sales for Keyboards & Combos, Tablet Accessories and Gaming.

[0001032975-24-000075:mdna:70]
[same as prior period, unchanged from 0001032975-24-000046:mdna:71]

[0001032975-24-000075:mdna:71]
The increase in sales in the EMEA region for the three-month period presented above was primarily driven by an increase in sales for Gaming and Tablet Accessories. The increase in sales in the EMEA region for the six-month period presented above was primarily driven by an increase in sales for Gaming, Keyboards & Combos, and Pointing Devices.

[0001032975-24-000075:mdna:72]
[same as prior period, unchanged from 0001032975-24-000046:mdna:73]

[0001032975-24-000075:mdna:73]
The sales in the Asia Pacific region remained flat for the three-month period with a decrease in sales for Webcams and Pointing Devices offset by an increase in sales for other product categories. The increase in sales in the Asia Pacific region for the six-month period presented above was primarily driven by an increase in sales for Gaming.

[0001032975-24-000075:mdna:74]
[same as prior period, unchanged from 0001032975-24-000046:mdna:75]

[0001032975-24-000075:mdna:75]
Sales by product category for the three and six months ended September 30, 2024 and 2023 were as follows (dollars in thousands):

[0001032975-24-000075:mdna:76]
|  |  | Three months ended September 30, |  | Six months ended September 30, |
|  |  | 2024 |  | 2023 |  | Change |  | 2024 |  | 2023 |  | Change |
| Gaming (1) |  | $ | 300,470 |  |  | $ | 282,104 |  |  | 7 | % |  | $ | 609,945 |  |  | $ | 548,533 |  |  | 11 | % |
| Keyboards & Combos |  | 209,936 |  |  | 194,914 |  |  | 8 |  |  | 425,269 |  |  | 375,769 |  |  | 13 |  |
| Pointing Devices |  | 195,936 |  |  | 191,676 |  |  | 2 |  |  | 385,882 |  |  | 366,130 |  |  | 5 |  |
| Video Collaboration |  | 159,660 |  |  | 152,389 |  |  | 5 |  |  | 306,702 |  |  | 291,735 |  |  | 5 |  |
| Webcams |  | 80,249 |  |  | 88,222 |  |  | (9) |  |  | 153,153 |  |  | 163,422 |  |  | (6) |  |
| Tablet Accessories |  | 85,614 |  |  | 63,677 |  |  | 34 |  |  | 164,153 |  |  | 134,013 |  |  | 22 |  |
| Headsets |  | 46,916 |  |  | 44,411 |  |  | 6 |  |  | 91,152 |  |  | 81,261 |  |  | 12 |  |
| Other (2) |  | 37,253 |  |  | 39,615 |  |  | (6) |  |  | 67,995 |  |  | 70,644 |  |  | (4) |  |
| Total Sales |  | $ | 1,116,034 |  |  | $ | 1,057,008 |  |  | 6 | % |  | $ | 2,204,251 |  |  | $ | 2,031,507 |  |  | 9 | % |

[0001032975-24-000075:mdna:77]
[same as prior period, unchanged from 0001032975-24-000046:mdna:78]

[0001032975-24-000075:mdna:78]
[same as prior period, unchanged from 0001032975-24-000046:mdna:79]

[0001032975-24-000075:mdna:79]
[same as prior period, unchanged from 0001032975-24-000046:mdna:80]

[0001032975-24-000075:mdna:80]
[same as prior period, unchanged from 0001032975-24-000046:mdna:81]

[0001032975-24-000075:mdna:81]
Sales of Gaming increased 7% for the three months ended September 30, 2024, compared to the three months ended September 30, 2023, primarily driven by an increase in sales of gaming steering wheels. Sales of Gaming increased 11% for the six months ended September 30, 2024, compared to the six months ended September 30, 2023, primarily driven by an increase in sales of gaming steering wheels and gaming mice.

[0001032975-24-000075:mdna:82]
[same as prior period, unchanged from 0001032975-24-000046:mdna:83]

[0001032975-24-000075:mdna:83]
[same as prior period, unchanged from 0001032975-24-000046:mdna:84]

[0001032975-24-000075:mdna:84]
Sales of Keyboards & Combos increased 8% and 13% for the three and six months ended September 30, 2024, compared to the three and six months ended September 30, 2023, respectively, primarily driven by an increase in sales of cordless combo products.

[0001032975-24-000075:mdna:85]
[same as prior period, unchanged from 0001032975-24-000046:mdna:86]

[0001032975-24-000075:mdna:86]
[same as prior period, unchanged from 0001032975-24-000046:mdna:87]

[0001032975-24-000075:mdna:87]
Sales of Pointing Devices increased 2% and 5% for the three and six months ended September 30, 2024, compared to the three and six months ended September 30, 2023, respectively, primarily driven by an increase in sales of cordless mice, partially offset by a decrease in sales of presentation tools.

[0001032975-24-000075:mdna:88]
[same as prior period, unchanged from 0001032975-24-000046:mdna:89]

[0001032975-24-000075:mdna:89]
[same as prior period, unchanged from 0001032975-24-000046:mdna:90]

[0001032975-24-000075:mdna:90]
Sales of Video Collaboration increased 5% for each of the three and six months ended September 30, 2024, compared to the three and six months ended September 30, 2023, primarily due to an increase in sales of conference room cameras as well as an increase in service revenue.

[0001032975-24-000075:mdna:91]
[same as prior period, unchanged from 0001032975-24-000046:mdna:92]

[0001032975-24-000075:mdna:92]
[same as prior period, unchanged from 0001032975-24-000046:mdna:93]

[0001032975-24-000075:mdna:93]
Sales of Webcams decreased 9% and 6% for the three and six months ended September 30, 2024, compared to the three and six months ended September 30, 2023, respectively, primarily driven by a decrease in sales of our VC webcams, partially offset by an increase of sales of our PC-based webcams.

[0001032975-24-000075:mdna:94]
[same as prior period, unchanged from 0001032975-24-000046:mdna:95]

[0001032975-24-000075:mdna:95]
[same as prior period, unchanged from 0001032975-24-000046:mdna:96]

[0001032975-24-000075:mdna:96]
Sales of Tablet Accessories increased 34% and 22% for the three and six months ended September 30, 2024, respectively, compared to the three and six months ended September 30, 2023, primarily driven by an increase in sales of Rugged Combo 4 Touch as well as sales from our Combo Touch products for the new releases of iPad Air and iPad Pro that were launched in fiscal year 2025. Sales of Tablet Accessories for the three and six months ended September 30, 2024, compared to the three and six months ended September 30, 2023, benefited from strong demand from the education sector.

[0001032975-24-000075:mdna:97]
[same as prior period, unchanged from 0001032975-24-000046:mdna:98]

[0001032975-24-000075:mdna:98]
[same as prior period, unchanged from 0001032975-24-000046:mdna:99]

[0001032975-24-000075:mdna:99]
Sales of Headsets increased 6% for the three months ended September 30, 2024, compared to the three months ended September 30, 2023, primarily driven by an increase in sales of cordless PC headsets. Sales of Headsets increased 12% for the six months ended September 30, 2024, compared to the six months ended September 30, 2023, primarily driven by an increase in sales of cordless PC headsets and VC headsets.

[0001032975-24-000075:mdna:100]
[same as prior period, unchanged from 0001032975-24-000046:mdna:101]

[0001032975-24-000075:mdna:101]
[same as prior period, unchanged from 0001032975-24-000046:mdna:102]

[0001032975-24-000075:mdna:102]
Sales in Other category decreased 6% and 4% for the three and six months ended September 30, 2024, respectively, compared to the three and six months ended September 30, 2023, primarily driven by a decline in sales of PC speakers.

[0001032975-24-000075:mdna:103]
[same as prior period, unchanged from 0001032975-24-000046:mdna:105]

[0001032975-24-000075:mdna:104]
Gross profit for the three and six months ended September 30, 2024 and 2023 was as follows (dollars in thousands):

[0001032975-24-000075:mdna:105]
|  |  | Three months ended September 30, |  | Six months ended September 30, |
|  |  | 2024 |  | 2023 |  | Change |  | 2024 |  | 2023 |  | Change |
| Net sales |  | $ | 1,116,034 |  | $ | 1,057,008 |  | 6 | % |  | $ | 2,204,251 |  | $ | 2,031,507 |  | 9 | % |
| Gross profit |  | $ | 486,091 |  | $ | 438,622 |  | 11 | % |  | $ | 952,349 |  | $ | 814,264 |  | 17 | % |
| Gross margin |  | 43.6 | % |  | 41.5 | % |  |  |  | 43.2 | % |  | 40.1 | % |  |  |

[0001032975-24-000075:mdna:106]
[same as prior period, unchanged from 0001032975-24-000046:mdna:108]

[0001032975-24-000075:mdna:107]
Gross margin was 43.6% for the three months ended September 30, 2024 and increased by 210 basis points, compared to the three months ended September 30, 2023, reflecting lower product costs and lower inventory reserves driven by improved demand, partially offset by higher promotional spending. Gross margin was 43.2% for the six months ended September 30, 2024 and increased by 310 basis points, compared to the six months ended September 30, 2023, primarily driven by lower product costs.

[0001032975-24-000075:mdna:108]
[same as prior period, unchanged from 0001032975-24-000046:mdna:110]

[0001032975-24-000075:mdna:109]
Operating expenses for the three and six months ended September 30, 2024 and 2023 were as follows (dollars in thousands):

[0001032975-24-000075:mdna:110]
|  |  | Three months ended September 30, |  | Six months ended September 30, |  |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |  |
| Marketing and selling |  | $ | 201,863 |  |  | $ | 176,356 |  |  | $ | 398,768 |  |  | $ | 355,541 |  |  |
| % of sales |  | 18.1 | % |  | 16.7 | % |  | 18.1 | % |  | 17.5 | % |  |
| Research and development |  | 76,205 |  |  | 68,559 |  |  | 151,512 |  |  | 139,118 |  |  |
| % of sales |  | 6.8 | % |  | 6.5 | % |  | 6.9 | % |  | 6.8 | % |  |
| General and administrative |  | 44,173 |  |  | 35,538 |  |  | 81,631 |  |  | 76,835 |  |  |
| % of sales |  | 4.0 | % |  | 3.4 | % |  | 3.7 | % |  | 3.8 | % |  |
| Amortization of intangible assets and acquisition-related costs |  | 2,725 |  |  | 3,318 |  |  | 5,428 |  |  | 6,003 |  |  |
| % of sales |  | 0.2 | % |  | 0.3 | % |  | 0.2 | % |  | 0.3 | % |  |
| Restructuring charges (credits), net |  | 229 |  |  | (1,788) |  |  | 615 |  |  | 1,723 |  |  |
| % of sales |  | — | % |  | (0.2) | % |  | — | % |  | 0.1 | % |  |
| Total operating expenses |  | $ | 325,195 |  |  | $ | 281,983 |  |  | $ | 637,954 |  |  | $ | 579,220 |  |  |
| % of sales |  | 29.1 | % |  | 26.7 | % |  | 28.9 | % |  | 28.5 | % |  |

[0001032975-24-000075:mdna:111]
The increase in total operating expenses during the three and six months ended September 30, 2024, compared to the three and six months ended September 30, 2023, was primarily driven by an increase in marketing and selling expenses.

[0001032975-24-000075:mdna:112]
[same as prior period, unchanged from 0001032975-24-000046:mdna:114]

[0001032975-24-000075:mdna:113]
[same as prior period, unchanged from 0001032975-24-000046:mdna:115]

[0001032975-24-000075:mdna:114]
During the three and six months ended September 30, 2024, marketing and selling expenses increased $25.5 million and $43.2 million, respectively, compared to the three and six months ended September 30, 2023, primarily driven by increased investment in marketing and advertising as well as higher performance-based compensation expense.

[0001032975-24-000075:mdna:115]
[same as prior period, unchanged from 0001032975-24-000046:mdna:117]

[0001032975-24-000075:mdna:116]
[same as prior period, unchanged from 0001032975-24-000046:mdna:118]

[0001032975-24-000075:mdna:117]
During the three and six months ended September 30, 2024, research and development expenses increased $7.6 million and $12.4 million, respectively, compared to the three and six months ended September 30, 2023, primarily driven by higher performance-based compensation expense and increased investment in product innovation.

[0001032975-24-000075:mdna:118]
[same as prior period, unchanged from 0001032975-24-000046:mdna:120]

[0001032975-24-000075:mdna:119]
[same as prior period, unchanged from 0001032975-24-000046:mdna:121]

[0001032975-24-000075:mdna:120]
During the three and six months ended September 30, 2024, general and administrative expenses increased $8.6 million and $4.8 million, respectively, compared to the three and six months ended September 30, 2023, primarily driven by higher performance-based compensation expense.

[0001032975-24-000075:mdna:121]
[same as prior period, unchanged from 0001032975-24-000046:mdna:123]

[0001032975-24-000075:mdna:122]
[same as prior period, unchanged from 0001032975-24-000046:mdna:124]

[0001032975-24-000075:mdna:123]
During the three and six months ended September 30, 2024, amortization of intangible assets and acquisition-related costs remained flat, compared to the three and six months ended September 30, 2023.

[0001032975-24-000075:mdna:124]
Restructuring Charges (Credits), Net

[0001032975-24-000075:mdna:125]
The restructuring charges (credits), net for the three and six months ended September 30, 2024 and 2023, were related to costs incurred as a result of our restructuring plan initiated during fiscal year 2023. These restructuring activities were substantially completed during fiscal year 2024.

[0001032975-24-000075:mdna:126]
[same as prior period, unchanged from 0001032975-24-000046:mdna:128]

[0001032975-24-000075:mdna:127]
Interest income for the three and six months ended September 30, 2024 and 2023 was as follows (in thousands):

[0001032975-24-000075:mdna:128]
|  |  | Three months ended September 30, |  | Six months ended September 30, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Interest Income |  | $ | 14,637 |  |  | $ | 11,856 |  |  | $ | 30,427 |  |  | $ | 21,682 |  |

[0001032975-24-000075:mdna:129]
We invest in highly liquid instruments with an original maturity of three months or less at the date of purchase, which are classified as cash equivalents. During the three and six months ended September 30, 2024, interest income increased $2.8 million and $8.7 million, respectively, compared to the three and six months ended September 30, 2023, primarily driven by an increase in the balance of our investments that are classified as cash equivalents as well as an increase in interest rates.

[0001032975-24-000075:mdna:130]
[same as prior period, unchanged from 0001032975-24-000046:mdna:132]

[0001032975-24-000075:mdna:131]
Other income (expense), net for the three and six months ended September 30, 2024 and 2023 was as follows (in thousands):

[0001032975-24-000075:mdna:132]
|  |  | Three months ended September 30, |  | Six months ended September 30, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Investment gain (loss) related to the deferred compensation plan |  | $ | 1,613 |  |  | $ | (324) |  |  | $ | 2,060 |  |  | $ | 700 |  |
| Currency exchange loss, net |  | (1,473) |  |  | (1,712) |  |  | (3,791) |  |  | (4,798) |  |
| Gain (loss) on investments, net |  | (413) |  |  | 214 |  |  | (1,599) |  |  | (11,609) |  |
| Non-service cost net pension income and other |  | 806 |  |  | 778 |  |  | 1,965 |  |  | 1,691 |  |
| Total |  | $ | 533 |  |  | $ | (1,044) |  |  | $ | (1,365) |  |  | $ | (14,016) |  |

[0001032975-24-000075:mdna:133]
Investment gain (loss) related to the deferred compensation plan represents earnings, gains, and losses on marketable securities related to a deferred compensation plan offered by one of our subsidiaries. The increase in investment gain for three and six months ended September 30, 2024, compared to the three and six months ended September 30, 2023, primarily relates to the change in market performance of the underlying securities.

[0001032975-24-000075:mdna:134]
Currency exchange loss, net, relates to balances denominated in currencies other than the functional currency in our subsidiaries, as well as to the sale of currencies, and gains or losses recognized on currency exchange forward contracts. We do not speculate in currency positions, but we are alert to opportunities to maximize currency exchange gains and minimize currency exchange losses. The loss for the three months ended September 30, 2024 was primarily due to fluctuations in currency exchange rates of the Chinese Renminbi against the U.S. Dollar. The loss for the three months ended September 30, 2023 was primarily due to fluctuations in the currency exchange rates of the Swiss Franc against the U.S. Dollar. The loss for the six months ended September 30, 2024 was primarily due to fluctuations in currency exchange rates of the Chinese Renminbi and the Mexican Peso against the

[0001032975-24-000075:mdna:135]
U.S. Dollar. The loss for the six months ended September 30, 2023 was primarily due to fluctuations in the currency exchange rates of the Japanese Yen against the U.S. Dollar.

[0001032975-24-000075:mdna:136]
Gain (loss) on investments, net, includes unrealized gain (loss) from the change in fair value of investments, gain (loss) on equity-method investments and impairment of investments during the periods presented, as applicable. The loss on investments, net, for the three and six months ended September 30, 2024 and the gain on investments, net, for the three months ended September 30, 2023 were not material. The loss on investments, net, for the six months ended September 30, 2023 was primarily due to an impairment loss, as a result of the write-off of a note receivable which has been deemed no longer recoverable. This note receivable was previously obtained in conjunction with an exchange transaction related to our investment in a privately held company. See Note 6 to our condensed consolidated financial statements for more information.

[0001032975-24-000075:mdna:137]
[same as prior period, unchanged from 0001032975-24-000046:mdna:138]

[0001032975-24-000075:mdna:138]
The provision for income taxes and effective income tax rates for the three and six months ended September 30, 2024 and 2023 were as follows (dollars in thousands):

[0001032975-24-000075:mdna:139]
|  |  | Three months ended September 30, |  | Six months ended September 30, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Provision for income taxes |  | $ | 30,583 |  |  | $ | 30,334 |  |  | $ | 56,141 |  |  | $ | 42,866 |  |
| Effective income tax rate |  | 17.4 | % |  | 18.1 | % |  | 16.3 | % |  | 17.7 | % |

[0001032975-24-000075:mdna:140]
The change in the effective income tax rate for the three and six months ended September 30, 2024, compared with the three and six months ended September 30, 2023, was primarily due to the change in the mix of income and losses in the various tax jurisdictions in which we operate, the favorable tax impacts from share-based compensation and unrecognized tax benefits due to uncertain tax positions.

[0001032975-24-000075:mdna:141]
[same as prior period, unchanged from 0001032975-24-000046:mdna:142]

[0001032975-24-000075:mdna:142]
[same as prior period, unchanged from 0001032975-24-000046:mdna:143]

[0001032975-24-000075:mdna:143]
[same as prior period, unchanged from 0001032975-24-000046:mdna:144]

[0001032975-24-000075:mdna:144]
[same as prior period, unchanged from 0001032975-24-000046:mdna:145]

[0001032975-24-000075:mdna:145]
As of September 30, 2024, we had cash and cash equivalents of $1,363.3 million, compared with $1,520.8 million as of March 31, 2024. Our cash and cash equivalents consist of bank demand deposits, short-term time deposits, and U.S. Treasury securities, of which 71% is held in Switzerland and 11% is held in Germany. We do not expect to incur any material adverse tax impact except for what has already been recognized, or to be significantly inhibited by any country in which we do business, from the repatriation of funds to Switzerland, our country of domicile.

[0001032975-24-000075:mdna:146]
As of September 30, 2024, our working capital was $1,457.2 million, compared to $1,545.5 million as of March 31, 2024. The decrease was primarily driven by a decrease in cash and cash equivalents and an increase in accounts payable, partially offset by an increase in inventories and accounts receivable.

[0001032975-24-000075:mdna:147]
We had several uncommitted, unsecured bank lines of credit and letters of credit aggregating $178.7 million as of September 30, 2024. There are no financial covenants under these lines of credit with which we must comply. There was no borrowing outstanding under the lines of credit as of September 30, 2024. As of September 30, 2024, we had outstanding bank guarantees of $29.5 million.

[0001032975-24-000075:mdna:148]
The following tables present selected financial information and statistics as of and for the three months ended September 30, 2024 and 2023 (dollars in thousands):

[0001032975-24-000075:mdna:149]
|  |  | As of September 30, |  |
|  |  | 2024 |  | 2023 |  |
| Accounts receivable, net |  | $ | 629,278 |  |  | $ | 656,895 |  |  |
| Accounts payable |  | $ | 555,490 |  |  | $ | 492,905 |  |  |
| Inventories |  | $ | 520,493 |  |  | $ | 532,943 |  |  |

[0001032975-24-000075:mdna:150]
|  |  | Three months ended September 30, |  |
|  |  | 2024 |  | 2023 |  |
| Days sales in accounts receivable (“DSO”) (Days)(1) |  | 51 |  |  | 56 |  |  |
| Days accounts payable outstanding (“DPO”) (Days)(2) |  | 79 |  |  | 72 |  |  |
| Inventory turnover (“ITO”) (x)(3) |  | 4.8 |  |  | 4.6 |  |  |

[0001032975-24-000075:mdna:151]
[same as prior period, unchanged from 0001032975-24-000046:mdna:152]

[0001032975-24-000075:mdna:152]
[same as prior period, unchanged from 0001032975-24-000046:mdna:153]

[0001032975-24-000075:mdna:153]
[same as prior period, unchanged from 0001032975-24-000046:mdna:154]

[0001032975-24-000075:mdna:154]
DSO for the three months ended September 30, 2024 decreased by 5 days to 51 days, compared to 56 days for the three months ended September 30, 2023, primarily due to higher sales from improved demand as well as timing of sales within the quarter.

[0001032975-24-000075:mdna:155]
DPO for the three months ended September 30, 2024 increased by 7 days to 79 days, compared to 72 days for the three months ended September 30, 2023, primarily due to higher inventory purchases during the second quarter of fiscal year 2025 to align with demand.

[0001032975-24-000075:mdna:156]
ITO for the three months ended September 30, 2024 increased by 0.2 to 4.8, compared to 4.6 for the three months ended September 30, 2023, primarily due to lower inventory balances driven by our efforts to manage inventory levels as well as due to improved demand.

[0001032975-24-000075:mdna:157]
[same as prior period, unchanged from 0001032975-24-000046:mdna:158]

[0001032975-24-000075:mdna:158]
[same as prior period, unchanged from 0001032975-24-000046:mdna:159]

[0001032975-24-000075:mdna:159]
|  |  | Six months ended September 30, |
|  |  | 2024 |  | 2023 |
| Net cash provided by operating activities |  | $ | 342,031 |  |  | $ | 463,059 |  |
| Net cash used in investing activities |  | (31,326) |  |  | (49,151) |  |
| Net cash used in financing activities |  | (474,954) |  |  | (388,269) |  |
| Effect of exchange rate changes on cash and cash equivalents |  | 6,683 |  |  | (10,758) |  |
| Net increase (decrease) in cash and cash equivalents |  | $ | (157,566) |  |  | $ | 14,881 |  |

[0001032975-24-000075:mdna:160]
For the six months ended September 30, 2024, net cash provided by operating activities was $342.0 million resulting from net income of $287.3 million, a favorable impact from adding back non-cash expenses totaling $107.3 million, partially offset by an unfavorable net change in operating assets and liabilities of $52.6 million. Non-cash adjustments were primarily related to share-based compensation expenses, depreciation and amortization and deferred income taxes. The increase in accounts receivable, net, was primarily driven by higher sales. The increases in inventories and accounts payable were due to higher inventory purchases to replenish certain products.

[0001032975-24-000075:mdna:161]
For the six months ended September 30, 2024, net cash used in investing activities was $31.3 million, primarily resulting from $29.1 million of purchases of property, plant, and equipment.

[0001032975-24-000075:mdna:162]
For the six months ended September 30, 2024, net cash used in financing activities was $475.0 million, primarily resulting from payment for repurchases of our registered shares of $263.2 million and payment of cash dividends of $207.9 million.

[0001032975-24-000075:mdna:163]
For the six months ended September 30, 2024, the effect of exchange rate changes on cash and cash equivalents was not material.

[0001032975-24-000075:mdna:164]
[same as prior period, unchanged from 0001032975-24-000046:mdna:165]

[0001032975-24-000075:mdna:165]
[same as prior period, unchanged from 0001032975-24-000046:mdna:166]

[0001032975-24-000075:mdna:166]
In fiscal year 2025, we paid a cash dividend of CHF 176.3 million (U.S. Dollar amount of $207.9 million based on the exchange rate on the date of payment) out of fiscal year 2024 retained earnings. In fiscal year 2024, we paid a cash dividend of CHF 169.1 million (U.S. Dollar amount of $182.3 million based on the exchange rate on the date of payment) out of fiscal year 2023 retained earnings.

[0001032975-24-000075:mdna:167]
In June 2023, our Board of Directors approved a three-year share repurchase program, which allows us to use up to $1.0 billion to repurchase our shares. The 2023 share repurchase program enables us to repurchase shares for cancellation, as well as to support equity incentive plans or potential acquisitions. The Swiss Takeover Board approved the 2023 share repurchase program in July 2023 and the program became effective on July 28, 2023. During the six months ended September 30, 2024, we repurchased 2.9 million shares for an aggregate cost of $262.1 million, under the 2023 share repurchase program for cancellation, of which $18.4 million of the aggregate cost was not paid yet as of September 30, 2024. As of September 30, 2024, $373.9 million was available for repurchase under the 2023 share repurchase program.

[0001032975-24-000075:mdna:168]
Swiss law limits a company’s ability to hold or repurchase its own shares. The aggregate par value of all shares held in treasury by us and our subsidiaries may not exceed 10% of our share capital, which corresponds to approximately 17.3 million registered shares. This limitation does not apply to shares repurchased for cancellation, due to the Board of Directors' authority under the capital band set forth in the Company's Articles of Incorporation to cancel shares up to a limit of 10% of our current share capital. As of September 30, 2024, we had a total of 21.3 million shares held in treasury stock, which includes 7.0 million shares that have been repurchased for cancellation and 14.3 million shares that have been purchased to support equity incentive plans or potential acquisitions.

[0001032975-24-000075:mdna:169]
[same as prior period, unchanged from 0001032975-24-000046:mdna:171]

[0001032975-24-000075:mdna:170]
[same as prior period, unchanged from 0001032975-24-000046:mdna:172]

[0001032975-24-000075:mdna:171]
[same as prior period, unchanged from 0001032975-24-000046:mdna:173]

[0001032975-24-000075:mdna:172]
We lease facilities under operating leases, certain of which require us to pay property taxes, insurance and maintenance costs. Operating leases for facilities are generally renewable at our option and usually include escalation clauses linked to inflation. There have been no material changes to our contractual obligations as previously disclosed in our Annual Report on Form 10-K for the year ended March 31, 2024. The remaining terms of our non-cancelable operating leases expire in various years through 2035.

[0001032975-24-000075:mdna:173]
[same as prior period, unchanged from 0001032975-24-000046:mdna:175]

[0001032975-24-000075:mdna:174]
As of September 30, 2024, we had non-cancelable purchase commitments of $455.3 million for inventory purchases made in the normal course of business from original design manufacturers, contract manufacturers and other suppliers, the majority of which are expected to be fulfilled within the next 12 months. We recorded a liability for firm, non-cancelable, and unhedged inventory purchase commitments in excess of anticipated demand or net realizable value consistent with our valuation of excess and obsolete inventory. As of September 30, 2024, the liability for these purchase commitments was $21.8 million and is recorded in accrued and other current liabilities in the condensed consolidated balance sheet.

[0001032975-24-000075:mdna:175]
We have firm purchase commitments of $12.1 million for capital expenditures primarily related to commitments for tooling and equipment for new and existing products. We expect to continue making capital expenditures in the future to support product development activities and ongoing and expanded operations. Although open purchase commitments are considered enforceable and legally binding, the terms generally allow us to reschedule or adjust our requirements based on business needs prior to delivery of goods or performance of services.

[0001032975-24-000075:mdna:176]
[same as prior period, unchanged from 0001032975-24-000046:mdna:178]

[0001032975-24-000075:mdna:177]
[same as prior period, unchanged from 0001032975-24-000046:mdna:179]

[0001032975-24-000075:mdna:178]
[same as prior period, unchanged from 0001032975-24-000046:mdna:180]

[0001032975-24-000075:mdna:179]
We indemnify certain suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of September 30, 2024, no material amounts have been accrued for indemnification provisions. We do not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under our indemnification arrangements.

[0001032975-24-000075:mdna:180]
[same as prior period, unchanged from 0001032975-24-000046:mdna:182]

[0001032975-24-000075:mdna:181]
Legal Proceedings

[0001032975-24-000075:mdna:182]
From time to time, we are involved in claims and legal proceedings that arise in the ordinary course of our business. For more information about Legal Proceedings, see Part II Item 1 Legal Proceedings of this quarterly report on Form 10-Q for the period ended September 30, 2024.
