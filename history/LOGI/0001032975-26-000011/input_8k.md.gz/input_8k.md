# LOGI 8-K — 0001032975-26-000006 filed 2026-01-27

## item codes, every 8-K on or before 2026-01-28

- 2026-01-27 0001032975-26-000006 — 2.02, 9.01
- 2025-11-14 0001032975-25-000085 — 7.01
- 2025-10-28 0001032975-25-000076 — 2.02, 9.01
- 2025-10-02 0001032975-25-000071 — 3.01
- 2025-09-19 0001032975-25-000068 — 5.02
- 2025-09-09 0001032975-25-000065 — 5.07, 8.01
- 2025-08-27 0001032975-25-000062 — 5.03, 9.01
- 2025-07-29 0001032975-25-000055 — 2.02, 9.01
- 2025-06-17 0001032975-25-000034 — 7.01, 9.01
- 2025-04-29 0001032975-25-000022 — 2.02, 9.01
- 2025-04-10 0001032975-25-000018 — 2.02, 9.01
- 2025-03-03 0001032975-25-000011 — 5.02, 9.01
- 2025-01-28 0001032975-25-000005 — 1.01, 2.02, 2.03, 9.01
- 2024-10-22 0001032975-24-000072 — 2.02, 9.01
- 2024-10-11 0001032975-24-000069 — 5.03, 9.01
- 2024-09-09 0001032975-24-000065 — 5.07, 8.01
- 2024-08-06 0001032975-24-000062 — 5.02, 9.01
- 2024-07-23 0001032975-24-000042 — 2.02, 9.01
- 2024-07-01 0001032975-24-000033 — 5.02, 8.01, 9.01
- 2024-06-13 0001032975-24-000030 — 5.02, 9.01
- 2024-04-30 0001032975-24-000015 — 2.02, 9.01
- 2024-03-18 0001032975-24-000012 — 5.02, 7.01, 9.01
- 2024-01-23 0001032975-24-000004 — 2.02, 9.01
- 2023-10-30 0001032975-23-000082 — 5.02, 9.01
- 2023-10-24 0001032975-23-000075 — 2.02, 9.01
- 2023-09-15 0001032975-23-000072 — 5.07, 8.01
- 2023-07-25 0001032975-23-000050 — 2.02, 9.01
- 2023-06-30 0001032975-23-000037 — 5.02 — amendment, the index does not say of what
- 2023-06-30 0001032975-23-000036 — 5.02
- 2023-06-13 0001032975-23-000030 — 5.02, 7.01, 9.01
- 2023-05-02 0001032975-23-000015 — 2.02, 9.01
- 2023-01-30 0001032975-23-000010 — 5.02, 9.01
- 2023-01-24 0001032975-23-000004 — 2.02, 5.02, 9.01
- 2023-01-12 0001628280-23-000934 — 2.02, 9.01
- 2022-10-25 0001628280-22-026927 — 2.02, 5.02, 9.01
- 2022-09-16 0001628280-22-025080 — 5.07, 8.01
- 2022-07-26 0001032975-22-000027 — 2.02, 9.01
- 2022-06-29 0001032975-22-000018 — 5.02
- 2022-05-03 0001032975-22-000008 — 2.02, 9.01
- 2022-01-25 0001032975-22-000003 — 2.02, 9.01
- 2021-10-26 0001032975-21-000043 — 2.02, 9.01
- 2021-09-10 0001032975-21-000040 — 5.07, 8.01
- 2021-07-27 0001032975-21-000029 — 2.02, 9.01
- 2021-04-29 0001032975-21-000012 — 2.02, 9.01
- 2021-01-19 0001032975-21-000004 — 2.02, 9.01
- 2020-10-20 0001032975-20-000045 — 2.02, 9.01
- 2020-09-11 0001032975-20-000042 — 5.07, 8.01
- 2020-07-21 0001032975-20-000029 — 2.02, 9.01
- 2020-07-01 0001032975-20-000023 — 5.02, 8.01
- 2020-05-12 0001032975-20-000011 — 2.02, 9.01
- 2020-03-30 0001032975-20-000009 — 5.02
- 2020-01-21 0001032975-20-000002 — 2.02, 9.01
- 2019-10-22 0001032975-19-000071 — 9.01
- 2019-09-26 0001032975-19-000068 — 1.01, 7.01, 9.01
- 2019-09-06 0001032975-19-000063 — 5.07, 8.01
- 2019-07-23 0001032975-19-000046 — 2.02, 9.01
- 2019-07-23 0001032975-19-000045 — 5.02, 9.01
- 2019-07-02 0001032975-19-000036 — 5.02
- 2019-06-25 0001032975-19-000034 — 5.02
- 2019-05-03 0001032975-19-000021 — 5.02 — amendment, the index does not say of what
- 2019-04-30 0001032975-19-000017 — 2.02, 5.02, 9.01
- 2019-03-28 0001032975-19-000013 — 5.02
- 2019-01-22 0001032975-19-000004 — 2.02, 9.01
- 2018-10-23 0001032975-18-000044 — 2.02, 9.01
- 2018-09-07 0001032975-18-000040 — 5.07, 8.01
- 2018-07-31 0001032975-18-000035 — 1.01, 2.02, 2.05, 7.01, 9.01
- 2018-06-27 0001032975-18-000020 — 5.02
- 2018-05-03 0001032975-18-000013 — 2.02, 5.02, 9.01
- 2018-01-23 0001032975-18-000005 — 2.02, 9.01
- 2017-10-24 0001032975-17-000043 — 2.02, 9.01
- 2017-09-18 0001032975-17-000040 — 5.07, 8.01
- 2017-07-25 0001032975-17-000028 — 2.02, 9.01
- 2017-07-12 0001032975-17-000022 — 1.01
- 2017-04-26 0001032975-17-000012 — 2.02, 9.01
- 2017-01-25 0001032975-17-000002 — 2.02, 9.01
- 2016-10-26 0001032975-16-000103 — 2.02, 9.01
- 2016-09-13 0001032975-16-000101 — 5.07, 8.01
- 2016-07-28 0001032975-16-000092 — 2.02, 9.01
- 2016-06-30 0001032975-16-000087 — 5.02
- 2016-04-28 0001032975-16-000077 — 2.02, 9.01
- 2016-04-14 0001032975-16-000073 — 1.01, 7.01, 9.01
- 2016-01-21 0001032975-16-000064 — 2.02, 9.01
- 2016-01-04 0001032975-16-000061 — 1.01, 2.01, 9.01
- 2015-12-23 0001032975-15-000059 — 5.02
- 2015-10-22 0001032975-15-000047 — 2.02, 9.01
- 2015-09-11 0001032975-15-000044 — 5.07, 8.01
- 2015-07-24 0001032975-15-000034 — 2.05 — amendment of 0001032975-15-000030
- 2015-07-23 0001032975-15-000030 — 2.02, 9.01
- 2015-06-25 0001032975-15-000025 — 5.02
- 2015-05-14 0001032975-15-000011 — 8.01, 9.01
- 2015-04-23 0001032975-15-000008 — 2.02, 2.05
- 2015-01-22 0001628280-15-000191 — 2.02, 8.01
- 2014-12-23 0001193125-14-450908 — 5.02, 5.07, 8.01
- 2014-11-25 0001193125-14-425233 — 3.01
- 2014-11-13 0001193125-14-411303 — 4.01, 9.01
- 2014-10-23 0001104659-14-073164 — 2.02, 9.01
- 2014-09-04 0001193125-14-331214 — 4.02, 9.01
- 2014-08-18 0001193125-14-313346 — 3.01, 9.01
- 2014-07-24 0001104659-14-053065 — 2.02, 9.01
- 2014-06-05 0001193125-14-226177 — 3.01, 9.01
- 2014-05-22 0001193125-14-208777 — 8.01, 9.01
- 2014-04-24 0001104659-14-029650 — 2.02, 9.01
- 2014-01-23 0001104659-14-003619 — 2.02, 9.01
- 2013-10-24 0001104659-13-077404 — 2.02, 9.01
- 2013-09-09 0001193125-13-361441 — 5.02, 5.07, 8.01, 9.01
- 2013-09-06 0001193125-13-359930 — 5.02, 9.01
- 2013-08-02 0001193125-13-317343 — 5.02
- 2013-07-25 0001104659-13-056372 — 2.02, 9.01
- 2013-06-28 0001193125-13-277394 — 5.02, 9.01
- 2013-06-20 0001193125-13-265914 — 8.01, 9.01
- 2013-04-25 0001104659-13-032570 — 2.02, 9.01
- 2013-04-17 0001193125-13-158923 — 5.02, 9.01
- 2013-03-01 0001193125-13-085804 — 2.05
- 2013-01-24 0001104659-13-004214 — 2.02, 9.01
- 2013-01-02 0001193125-13-000058 — 5.02
- 2012-10-25 0001104659-12-070966 — 2.02, 9.01
- 2012-09-11 0001193125-12-388070 — 5.02, 5.07, 8.01, 9.01
- 2012-08-22 0001193125-12-364167 — 5.02, 8.01, 9.01
- 2012-07-26 0001104659-12-051084 — 2.02, 9.01
- 2012-06-08 0001193125-12-264132 — 2.05, 9.01 — amendment, the index does not say of what
- 2012-04-26 0001193125-12-183657 — 5.02, 9.01
- 2012-04-26 0001104659-12-028470 — 2.02, 2.05, 9.01
- 2012-03-15 0001193125-12-115954 — 5.02, 9.01
- 2012-01-26 0001104659-12-004014 — 2.02, 9.01
- 2012-01-04 0001193125-12-002212 — 1.01, 2.03, 9.01
- 2011-10-27 0001104659-11-058150 — 2.02, 9.01
- 2011-09-12 0001193125-11-245931 — 5.07
- 2011-07-28 0001193125-11-200929 — 5.02, 9.01
- 2011-07-28 0001193125-11-199704 — 2.02, 9.01
- 2011-04-28 0001193125-11-112669 — 2.02, 9.01
- 2011-03-24 0001193125-11-076483 — 5.02, 9.01
- 2011-01-27 0001032975-11-000003 — 9.01
- 2010-10-28 0001032975-10-000032 — 9.01
- 2010-09-13 0001032975-10-000022 — 5.07
- 2010-07-29 0001032975-10-000010 — 2.02, 9.01
- 2010-06-10 0001193125-10-136877 — 5.02, 9.01
- 2010-05-03 0001193125-10-104337 — 5.02
- 2010-04-29 0001032975-10-000008 — 2.02, 9.01
- 2010-02-19 0001032975-10-000006 — 9.01 — amendment of 0001193125-09-252416
- 2010-01-21 0001032975-10-000002 — 2.02, 9.01
- 2009-12-14 0001193125-09-252416 — 2.01, 9.01
- 2009-11-17 0001032975-09-000023 — 1.01
- 2009-10-22 0001032975-09-000018 — 9.01
- 2009-09-22 0001193125-09-195545 — 5.02, 9.01
- 2009-09-03 0001032975-09-000013 — 8.01
- 2009-07-23 0001140361-09-016802 — 2.02, 9.01
- 2009-06-01 0001193125-09-122550 — 5.02
- 2009-04-23 0001193125-09-085054 — 2.02, 9.01
- 2009-04-02 0001193125-09-071272 — 5.02, 9.01
- 2009-01-20 0001193125-09-008454 — 2.05 — amendment of 0001193125-09-002609
- 2009-01-20 0001193125-09-007902 — 2.02, 9.01
- 2009-01-07 0001193125-09-002609 — 2.05, 9.01
- 2009-01-07 0001193125-09-002370 — 5.02, 9.01
- 2008-12-09 0001193125-08-250543 — 5.02, 9.01
- 2008-10-21 0001193125-08-213212 — 2.02, 9.01
- 2008-07-22 0001193125-08-154721 — 2.02, 9.01
- 2008-06-24 0001193125-08-139163 — 5.03, 9.01
- 2008-05-13 0001193125-08-113263 — 5.02, 9.01
- 2008-04-22 0001193125-08-086176 — 2.02, 9.01

## late-filing notifications on or before 2026-01-28

- 2015-06-02 0001032975-15-000020 — NT 10-K, for the period ended 2015-03-31
- 2014-11-06 0001193125-14-401306 — NT 10-Q, for the period ended 2014-09-30
- 2014-07-24 0001193125-14-277575 — NT 10-Q, for the period ended 2014-06-30
- 2014-05-22 0001193125-14-208712 — NT 10-K, for the period ended 2014-03-31
- 2009-08-06 0001032975-09-000006 — NT 10-Q, for the period ended 2009-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001032975-26-000006:8k_2_02:1]
EX-99.1
2
exhibit991q3fy26.htm
EX-99.1

[0001032975-26-000006:8k_2_02:2]
Document

[0001032975-26-000006:8k_2_02:3]
Exhibit 99.1

[0001032975-26-000006:8k_2_02:4]
Editorial Contacts:

[0001032975-26-000006:8k_2_02:5]
Nate Melihercik, Head of Investor Relations - ir@logitech.com

[0001032975-26-000006:8k_2_02:6]
Bruno Rodriguez, Head of Corporate Communications - mediarelations@logitech.com

[0001032975-26-000006:8k_2_02:7]
Ben Starkie, Corporate Communications - +41 (0) 79-292-3499, bstarkie1@logitech.com

[0001032975-26-000006:8k_2_02:8]
Logitech Announces Q3 Fiscal Year 2026 Results

[0001032975-26-000006:8k_2_02:9]
Strong Financial Performance Driven

[0001032975-26-000006:8k_2_02:10]
By Strategic Priorities and Operational Discipline

[0001032975-26-000006:8k_2_02:11]
LAUSANNE, Switzerland, and SAN JOSE, Calif., Jan. 27, 2026 — SIX Swiss Exchange Ad hoc announcement pursuant to Art. 53 LR — Logitech International (SIX: LOGN) (Nasdaq: LOGI) today announced financial results for the third quarter of Fiscal Year 2026.

[0001032975-26-000006:8k_2_02:12]
•Sales were $1.42 billion, up 6 percent in US dollars and 4 percent in constant currency compared to Q3 of the prior year.

[0001032975-26-000006:8k_2_02:13]
•GAAP gross margin was 43.2 percent, up 30 basis points compared to Q3 of the prior year. Non-GAAP gross margin was 43.5 percent, up 30 basis points compared to Q3 of the prior year.

[0001032975-26-000006:8k_2_02:14]
•GAAP operating income was $286 million, up 22 percent compared to Q3 of the prior year. Non-GAAP operating income was $312 million, up 17 percent compared to Q3 of the prior year.

[0001032975-26-000006:8k_2_02:15]
•GAAP earnings per share (EPS) was $1.69, up 28 percent compared to Q3 of the prior year. Non-GAAP EPS was $1.93, up 21 percent compared to Q3 of the prior year.

[0001032975-26-000006:8k_2_02:16]
•Cash flow from operations was $481 million. The quarter-ending cash balance was $1.8 billion.

[0001032975-26-000006:8k_2_02:17]
“We delivered another quarter of excellent financial performance,” said Hanneke Faber, Logitech chief executive officer. “Growth was broad-based across categories, regions and both consumer and business channels. We continued to drive superior innovation with iconic new products like the premium MX Master 4 mouse. And, with the exception of pandemic peaks, we drove record operating income despite tariff headwinds, underscoring the quality of our portfolio, the strength of our innovation and our unique global operational capabilities.”

[0001032975-26-000006:8k_2_02:18]
“Our team’s excellent operational execution and disciplined cost management delivered outstanding gross and operating margins,” said Matteo Anversa, Logitech chief financial officer. “This is a strong performance in our biggest quarter of the year, in spite of the ongoing uncertain environment.”

[0001032975-26-000006:8k_2_02:19]
Outlook

[0001032975-26-000006:8k_2_02:20]
Our financial outlook for the fourth quarter of Fiscal Year 2026 is:

[0001032975-26-000006:8k_2_02:21]
|  |  | Q4 FY26 outlook | FY26 outlook |
| Sales |  | $1,070 - $1,090 million | $4,825 - $4,845 million |
| Sales growth (in US dollars, year over year) |  | 6% - 8% | Approximately 6% |
| Sales growth (in constant currency, year over year) |  | 3% - 5% | Approximately 4% |
| Non-GAAP operating income |  | $155 - $165 million | $900 - $910 million |

[0001032975-26-000006:8k_2_02:22]
Financial Results Videoconference and Webcast

[0001032975-26-000006:8k_2_02:23]
Logitech will hold a financial results videoconference to discuss the results for Q3 Fiscal Year 2026 on Tuesday, January 27, 2026 at 1:30 p.m. Pacific Standard Time (PST) and 10:30 p.m. Central European Time (CET).

[0001032975-26-000006:8k_2_02:24]
A livestream of the event will be available on the Logitech corporate website at https://ir.logitech.com. This press release and the Q3 Fiscal Year 2026 Shareholder Letter are also available there.

[0001032975-26-000006:8k_2_02:25]
Use of Non-GAAP Financial Information and Constant Currency

[0001032975-26-000006:8k_2_02:26]
To facilitate comparisons to Logitech’s historical results, Logitech has included non-GAAP adjusted measures in this press release, which exclude share-based compensation expense, amortization of intangible assets, acquisition-related costs, restructuring charges (credits), net, loss (gain) on investments, non-GAAP income tax adjustment, and other items detailed under “Supplemental Financial Information” after the tables below and posted to our website at https://ir.logitech.com. Logitech also presents percentage sales growth in constant currency (“cc”), a non-GAAP measure, to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales. Logitech believes this information, used together with the GAAP financial information, will help investors to evaluate its current period performance, outlook and trends in its business. With respect to the Company’s outlook for non-GAAP operating income, most of the excluded amounts pertain to events that have not yet occurred and are not currently possible to estimate with a reasonable degree of accuracy. Therefore, no reconciliation to the GAAP amounts has been provided for the fourth quarter of Fiscal Year 2026 non-GAAP outlook.

[0001032975-26-000006:8k_2_02:27]
Public Dissemination of Certain Information

[0001032975-26-000006:8k_2_02:28]
Recordings of Logitech’s earnings videoconferences and certain events Logitech participates in or hosts, with members of the investment community are posted on the company’s investor relations website at https://ir.logitech.com. Additionally, Logitech provides notifications of news or announcements regarding its operations and financial performance, including its filings with the Securities and Exchange Commission (SEC), investor events, and press and earnings releases as part of its investor relations website. Logitech intends to use its investor relations website as means of disclosing material nonpublic

[0001032975-26-000006:8k_2_02:29]
information and for complying with its disclosure obligations under Regulation FD. Logitech’s corporate governance information also is available on its investor relations website.

[0001032975-26-000006:8k_2_02:30]
About Logitech

[0001032975-26-000006:8k_2_02:31]
Logitech designs software-enabled hardware solutions that help businesses thrive and bring people together when working, creating and gaming. As the point of connection between people and the digital world, our mission is to extend human potential in work and play, in a way that is good for people and the planet. Founded in 1981, Logitech International is a Swiss public company listed on the SIX Swiss Exchange (LOGN) and on the Nasdaq Global Select Market (LOGI). Find Logitech and its other brands, including Logitech G, at www.logitech.com or company blog.

[0001032975-26-000006:8k_2_02:32]
# # #

[0001032975-26-000006:8k_2_02:33]
Note that unless noted otherwise, comparisons are year over year.

[0001032975-26-000006:8k_2_02:34]
Logitech and other Logitech marks are trademarks or registered trademarks of Logitech Europe S.A. and/or its affiliates in the U.S. and other countries. All other trademarks are the property of their respective owners. For more information about Logitech and its products, visit the company’s website at www.logitech.com.

[0001032975-26-000006:8k_2_02:35]
(LOGIIR)

[0001032975-26-000006:8k_2_02:36]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended December 31, |  | Nine Months Ended December 31, |
| GAAP CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net sales |  | $ | 1,421,479 |  |  | $ | 1,340,294 |  |  | $ | 3,755,238 |  |  | $ | 3,544,545 |  |
| Cost of goods sold |  | 805,267 |  |  | 763,403 |  |  | 2,141,277 |  |  | 2,010,411 |  |
| Amortization of intangible assets |  | 1,573 |  |  | 2,450 |  |  | 5,904 |  |  | 7,344 |  |
| Gross profit |  | 614,639 |  |  | 574,441 |  |  | 1,608,057 |  |  | 1,526,790 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Marketing and selling |  | 206,875 |  |  | 217,048 |  |  | 601,664 |  |  | 615,816 |  |
| Research and development |  | 78,452 |  |  | 77,973 |  |  | 229,149 |  |  | 229,485 |  |
| General and administrative |  | 41,921 |  |  | 42,117 |  |  | 125,520 |  |  | 123,748 |  |
| Amortization of intangible assets and acquisition-related costs |  | 915 |  |  | 2,637 |  |  | 5,379 |  |  | 8,065 |  |
| Restructuring charges, net |  | 462 |  |  | 110 |  |  | 6,946 |  |  | 725 |  |
| Total operating expenses |  | 328,625 |  |  | 339,885 |  |  | 968,658 |  |  | 977,839 |  |
| Operating income |  | 286,014 |  |  | 234,556 |  |  | 639,399 |  |  | 548,951 |  |
| Interest income |  | 10,985 |  |  | 12,176 |  |  | 34,042 |  |  | 42,603 |  |
| Other income (expense), net |  | 2,131 |  |  | (1,524) |  |  | 3,229 |  |  | (2,889) |  |
| Income before income taxes |  | 299,130 |  |  | 245,208 |  |  | 676,670 |  |  | 588,665 |  |
| Provision for income taxes |  | 48,091 |  |  | 45,061 |  |  | 108,946 |  |  | 101,202 |  |
| Net income |  | $ | 251,039 |  |  | $ | 200,147 |  |  | $ | 567,724 |  |  | $ | 487,463 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.71 |  |  | $ | 1.33 |  |  | $ | 3.86 |  |  | $ | 3.20 |  |
| Diluted |  | $ | 1.69 |  |  | $ | 1.32 |  |  | $ | 3.82 |  |  | $ | 3.18 |  |
| Weighted average shares used to compute net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | 146,827 |  |  | 150,647 |  |  | 147,265 |  |  | 152,127 |  |
| Diluted |  | 148,450 |  |  | 151,895 |  |  | 148,635 |  |  | 153,506 |  |

[0001032975-26-000006:8k_2_02:37]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
|  |  | December 31, |  | March 31, |  |  |  |  |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  | 2025 |  | 2025 |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,817,820 |  |  | $ | 1,503,205 |  |  |  |  |  |
| Accounts receivable, net |  | 683,126 |  |  | 454,546 |  |  |  |  |  |
| Inventories |  | 449,544 |  |  | 503,747 |  |  |  |  |  |
| Other current assets |  | 166,988 |  |  | 131,211 |  |  |  |  |  |
| Total current assets |  | 3,117,478 |  |  | 2,592,709 |  |  |  |  |  |
| Non-current assets: |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  | 115,363 |  |  | 113,858 |  |  |  |  |  |
| Goodwill |  | 466,579 |  |  | 463,230 |  |  |  |  |  |
| Other intangible assets, net |  | 13,889 |  |  | 24,630 |  |  |  |  |  |
| Other assets |  | 382,380 |  |  | 344,077 |  |  |  |  |  |
| Total assets |  | $ | 4,095,689 |  |  | $ | 3,538,504 |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 590,421 |  |  | $ | 414,586 |  |  |  |  |  |
| Accrued and other current liabilities |  | 817,924 |  |  | 686,503 |  |  |  |  |  |
| Total current liabilities |  | 1,408,345 |  |  | 1,101,089 |  |  |  |  |  |
| Non-current liabilities: |  |  |  |  |  |  |  |  |
| Income taxes payable |  | 113,621 |  |  | 88,483 |  |  |  |  |  |
| Other non-current liabilities |  | 238,000 |  |  | 221,512 |  |  |  |  |  |
| Total liabilities |  | 1,759,966 |  |  | 1,411,084 |  |  |  |  |  |
| Shareholders’ equity: |  |  |  |  |  |  |  |  |
| Registered shares, CHF 0.25 par valueIssued shares: 160,784 and 168,994 at December 31, 2025 and March 31, 2025, respectively |  | 28,001 |  |  | 29,432 |  |  |  |  |  |
| Additional paid-in capital |  | 104,310 |  |  | 82,591 |  |  |  |  |  |
| Shares in treasury, at cost Treasury shares: 14,027 and 20,485 at December 31, 2025 and March 31, 2025, respectively |  | (908,278) |  |  | (1,464,912) |  |  |  |  |  |
| Retained earnings |  | 3,237,815 |  |  | 3,627,261 |  |  |  |  |  |
| Accumulated other comprehensive loss |  | (126,125) |  |  | (146,952) |  |  |  |  |  |
| Total shareholders’ equity |  | 2,335,723 |  |  | 2,127,420 |  |  |  |  |  |
| Total liabilities and shareholders’ equity |  | $ | 4,095,689 |  |  | $ | 3,538,504 |  |  |  |  |  |

[0001032975-26-000006:8k_2_02:38]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended December 31, |  | Nine Months Ended December 31, |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 251,039 |  |  | $ | 200,147 |  |  | $ | 567,724 |  |  | $ | 487,463 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  | 16,687 |  |  | 15,075 |  |  | 47,622 |  |  | 44,178 |  |
| Amortization of intangible assets |  | 2,488 |  |  | 5,087 |  |  | 11,283 |  |  | 15,258 |  |
| Loss (gain) on investments |  | (206) |  |  | 119 |  |  | 291 |  |  | 1,718 |  |
| Share-based compensation expense |  | 23,435 |  |  | 26,193 |  |  | 86,575 |  |  | 76,067 |  |
| Deferred income taxes |  | (15,900) |  |  | 2,163 |  |  | 6,296 |  |  | 18,652 |  |
| Other |  | 77 |  |  | 73 |  |  | 65 |  |  | 130 |  |
| Changes in assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | 22,044 |  |  | (46,366) |  |  | (213,815) |  |  | (127,934) |  |
| Inventories |  | 68,701 |  |  | 26,353 |  |  | 66,921 |  |  | (67,554) |  |
| Other assets |  | (12,939) |  |  | 7,175 |  |  | (30,423) |  |  | 9,416 |  |
| Accounts payable |  | 6,548 |  |  | 28,472 |  |  | 171,967 |  |  | 136,848 |  |
| Accrued and other liabilities |  | 118,558 |  |  | 106,379 |  |  | 119,908 |  |  | 118,659 |  |
| Net cash provided by operating activities |  | 480,532 |  |  | 370,870 |  |  | 834,414 |  |  | 712,901 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  | (14,890) |  |  | (14,227) |  |  | (47,723) |  |  | (43,340) |  |
| Purchases of deferred compensation investments |  | (1,520) |  |  | (2,202) |  |  | (5,557) |  |  | (5,802) |  |
| Proceeds from sales of deferred compensation investments |  | 2,159 |  |  | 2,659 |  |  | 5,718 |  |  | 4,958 |  |
| Other investing activities |  | (213) |  |  | (261) |  |  | (1,196) |  |  | (1,173) |  |
| Net cash used in investing activities |  | (14,464) |  |  | (14,031) |  |  | (48,758) |  |  | (45,357) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Payment of cash dividends |  | — |  |  | — |  |  | (233,059) |  |  | (207,853) |  |
| Purchases of registered shares |  | (27,117) |  |  | (200,137) |  |  | (255,380) |  |  | (463,322) |  |
| Proceeds from exercises of stock options and purchase rights |  | 2,459 |  |  | — |  |  | 24,172 |  |  | 20,235 |  |
| Tax withholdings related to net share settlements of restricted stock units |  | (1,195) |  |  | (1,008) |  |  | (19,406) |  |  | (22,251) |  |
| Other financing activities |  | — |  |  | — |  |  | — |  |  | (2,908) |  |
| Net cash used in financing activities |  | (25,853) |  |  | (201,145) |  |  | (483,673) |  |  | (676,099) |  |
| Effect of exchange rate changes on cash and cash equivalents |  | 1,798 |  |  | (16,138) |  |  | 12,632 |  |  | (9,455) |  |
| Net increase (decrease) in cash and cash equivalents |  | 442,013 |  |  | 139,556 |  |  | 314,615 |  |  | (18,010) |  |
| Cash and cash equivalents, beginning of the period |  | 1,375,807 |  |  | 1,363,276 |  |  | 1,503,205 |  |  | 1,520,842 |  |
| Cash and cash equivalents, end of the period |  | $ | 1,817,820 |  |  | $ | 1,502,832 |  |  | $ | 1,817,820 |  |  | $ | 1,502,832 |  |

[0001032975-26-000006:8k_2_02:39]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three Months Ended December 31, |  | Nine Months Ended December 31, |
| NET SALES |  | 2025 |  | 2024 |  | Change |  | 2025 |  | 2024 |  | Change |
| Net sales by product category: |  |  |  |  |  |  |  |  |  |  |  |  |
| Gaming (1) |  | $ | 482,714 |  |  | $ | 466,715 |  |  | 3 | % |  | $ | 1,121,894 |  |  | $ | 1,076,660 |  |  | 4 | % |
| Keyboards & Combos |  | 254,612 |  |  | 236,748 |  |  | 8 |  |  | 712,974 |  |  | 662,017 |  |  | 8 |  |
| Pointing Devices |  | 241,160 |  |  | 217,045 |  |  | 11 |  |  | 658,034 |  |  | 602,927 |  |  | 9 |  |
| Video Collaboration |  | 193,252 |  |  | 176,053 |  |  | 10 |  |  | 527,645 |  |  | 482,755 |  |  | 9 |  |
| Webcams |  | 82,268 |  |  | 84,419 |  |  | (3) |  |  | 249,944 |  |  | 237,572 |  |  | 5 |  |
| Tablet Accessories |  | 93,567 |  |  | 77,433 |  |  | 21 |  |  | 269,855 |  |  | 241,586 |  |  | 12 |  |
| Headsets |  | 45,939 |  |  | 45,886 |  |  | — |  |  | 134,959 |  |  | 137,038 |  |  | (2) |  |
| Other (2) |  | 27,967 |  |  | 35,995 |  |  | (22) |  |  | 79,933 |  |  | 103,990 |  |  | (23) |  |
| Total Net Sales |  | $ | 1,421,479 |  |  | $ | 1,340,294 |  |  | 6 | % |  | $ | 3,755,238 |  |  | $ | 3,544,545 |  |  | 6 | % |

[0001032975-26-000006:8k_2_02:40]
(1) Gaming includes streaming services revenue generated by Streamlabs.

[0001032975-26-000006:8k_2_02:41]
(2) Other primarily consists of mobile speakers and PC speakers.

[0001032975-26-000006:8k_2_02:42]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three Months Ended December 31, |  | Nine Months Ended December 31, |
| GAAP TO NON-GAAP RECONCILIATION (A) |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Gross profit - GAAP |  | $ | 614,639 |  | $ | 574,441 |  | $ | 1,608,057 |  | $ | 1,526,790 |
| Share-based compensation expense |  | 2,636 |  | 2,173 |  | 8,375 |  | 8,673 |
| Amortization of intangible assets |  | 1,573 |  | 2,450 |  | 5,904 |  | 7,344 |
| Gross profit - Non-GAAP |  | $ | 618,848 |  | $ | 579,064 |  | $ | 1,622,336 |  | $ | 1,542,807 |
| Gross margin - GAAP |  | 43.2 | % |  | 42.9 | % |  | 42.8 | % |  | 43.1 | % |
| Gross margin - Non-GAAP |  | 43.5 | % |  | 43.2 | % |  | 43.2 | % |  | 43.5 | % |
| Operating expenses - GAAP |  | $ | 328,625 |  | $ | 339,885 |  | $ | 968,658 |  | $ | 977,839 |
| Less: Share-based compensation expense |  | 20,799 |  | 24,020 |  | 78,200 |  | 67,394 |
| Less: Amortization of intangible assets and acquisition-related costs |  | 915 |  | 2,637 |  | 5,379 |  | 8,065 |
| Less: Restructuring charges, net |  | 462 |  | 110 |  | 6,946 |  | 725 |
| Operating expenses - Non-GAAP |  | $ | 306,449 |  | $ | 313,118 |  | $ | 878,133 |  | $ | 901,655 |
| % of net sales - GAAP |  | 23.1 | % |  | 25.4 | % |  | 25.8 | % |  | 27.6 | % |
| % of net sales - Non-GAAP |  | 21.6 | % |  | 23.4 | % |  | 23.4 | % |  | 25.4 | % |
| Operating income - GAAP |  | $ | 286,014 |  | $ | 234,556 |  | $ | 639,399 |  | $ | 548,951 |
| Share-based compensation expense |  | 23,435 |  | 26,193 |  | 86,575 |  | 76,067 |
| Amortization of intangible assets and acquisition-related costs |  | 2,488 |  | 5,087 |  | 11,283 |  | 15,409 |
| Restructuring charges, net |  | 462 |  | 110 |  | 6,946 |  | 725 |
| Operating income - Non-GAAP |  | $ | 312,399 |  | $ | 265,946 |  | $ | 744,203 |  | $ | 641,152 |
| % of net sales - GAAP |  | 20.1 | % |  | 17.5 | % |  | 17.0 | % |  | 15.5 | % |
| % of net sales - Non-GAAP |  | 22.0 | % |  | 19.8 | % |  | 19.8 | % |  | 18.1 | % |
| Net income - GAAP |  | $ | 251,039 |  | $ | 200,147 |  | $ | 567,724 |  | $ | 487,463 |
| Share-based compensation expense |  | 23,435 |  | 26,193 |  | 86,575 |  | 76,067 |
| Amortization of intangible assets and acquisition-related costs |  | 2,488 |  | 5,087 |  | 11,283 |  | 15,409 |
| Restructuring charges, net |  | 462 |  | 110 |  | 6,946 |  | 725 |
| Loss (gain) on investments |  | (206) |  | 119 |  | 291 |  | 1,718 |
| Non-GAAP income tax adjustment |  | 9,802 |  | 9,834 |  | 17,944 |  | 18,820 |
| Net income - Non-GAAP |  | $ | 287,020 |  | $ | 241,490 |  | $ | 690,763 |  | $ | 600,202 |
| Net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  | $ | 1.69 |  | $ | 1.32 |  | $ | 3.82 |  | $ | 3.18 |
| Diluted - Non-GAAP |  | $ | 1.93 |  | $ | 1.59 |  | $ | 4.65 |  | $ | 3.91 |
| Shares used to compute net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP and Non-GAAP |  | 148,450 |  | 151,895 |  | 148,635 |  | 153,506 |

[0001032975-26-000006:8k_2_02:43]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three Months Ended December 31, |  | Nine Months Ended December 31, |
| SHARE-BASED COMPENSATION EXPENSE |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Share-based Compensation Expense |  |  |  |  |  |  |  |  |
| Cost of goods sold |  | $ | 2,636 |  |  | $ | 2,173 |  |  | $ | 8,375 |  |  | $ | 8,673 |  |
| Marketing and selling |  | 5,911 |  |  | 11,813 |  |  | 31,982 |  |  | 34,133 |  |
| Research and development |  | 5,395 |  |  | 5,043 |  |  | 17,412 |  |  | 15,849 |  |
| General and administrative |  | 9,493 |  |  | 7,164 |  |  | 28,806 |  |  | 17,412 |  |
| Total share-based compensation expense |  | 23,435 |  |  | 26,193 |  |  | 86,575 |  |  | 76,067 |  |
| Income tax benefit |  | (4,699) |  |  | (4,523) |  |  | (15,620) |  |  | (16,901) |  |
| Total share-based compensation expense, net of income tax benefit |  | $ | 18,736 |  |  | $ | 21,670 |  |  | $ | 70,955 |  |  | $ | 59,166 |  |

[0001032975-26-000006:8k_2_02:44]
*Note: These preliminary results for the three and nine months ended December 31, 2025 are subject to adjustments, including subsequent events that may occur through the date of filing our Quarterly Report on Form 10-Q.

[0001032975-26-000006:8k_2_02:45]
(A) Non-GAAP Financial Measures

[0001032975-26-000006:8k_2_02:46]
To supplement our condensed consolidated financial results prepared in accordance with GAAP, we use a number of financial measures, both GAAP and non-GAAP, in analyzing and assessing our overall business performance, for making operating decisions and for forecasting and planning future periods. We consider the use of non-GAAP financial measures helpful in assessing our current financial performance, ongoing operations and prospects for the future as well as understanding financial and business trends relating to our financial condition and results of operations.

[0001032975-26-000006:8k_2_02:47]
While we use non-GAAP financial measures as a tool to enhance our understanding of certain aspects of our financial performance and to provide incremental insight into the underlying factors and trends affecting both our performance and our cash-generating potential, we do not consider these measures to be a substitute for, or superior to, the information provided by GAAP financial measures. Consistent with this approach, we believe that disclosing non-GAAP financial measures to the readers of our financial statements provides useful supplemental data that, while not a substitute for GAAP financial measures, can offer insight in the review of our financial and operational performance and enable investors to more fully understand trends in our current and future performance. In assessing our business during the quarter ended December 31, 2025 and prior periods presented, we excluded items in the following general categories, each of which are described below:

[0001032975-26-000006:8k_2_02:48]
Share-based compensation expense. We believe that providing non-GAAP measures excluding share-based compensation expense, in addition to the GAAP measures, allows for a more transparent comparison of our financial results from period to period. We prepare and maintain our budgets and forecasts for future periods on a basis consistent with this non-GAAP financial measure. Further, companies use a variety of types of equity awards as well as a variety of methodologies, assumptions and estimates to determine share-based compensation expense. We believe that excluding share-based compensation expense enhances our ability and the ability of investors to understand the impact of non-cash share-based compensation on our operating results and to compare our results against the results of other companies.

[0001032975-26-000006:8k_2_02:49]
Amortization of intangible assets. We incur intangible asset amortization expense, primarily in connection with our acquisitions of various businesses and technologies. The amortization of purchased intangibles varies depending on the level of acquisition activity. We exclude these various charges in budgeting, planning and forecasting future periods and we believe that providing the non-GAAP measures excluding these various non-cash charges, as well as the GAAP measures, provides additional insight when comparing our gross profit, operating expenses, and financial results from period to period.

[0001032975-26-000006:8k_2_02:50]
Acquisition-related costs. We incurred expenses in connection with our acquisitions which we generally would not have otherwise incurred in the periods presented as a part of our continuing operations. Acquisition-related costs include certain incremental expenses incurred to effect a business combination. We believe that providing the non-GAAP measures excluding these costs, as well as the GAAP measures, assists our investors because such costs are not reflective of our ongoing operating results.

[0001032975-26-000006:8k_2_02:51]
Restructuring charges (credits), net. These charges (credits) are associated with restructuring plans and will vary based on the initiatives in place during any given period. Restructuring charges may include costs related to employee terminations, facility closures and early cancellation of certain contracts as well as other costs resulting from our restructuring initiatives. We believe that providing the non-GAAP measures excluding these items, as well as the GAAP measures, assists our investors because such charges (credits) are not reflective of our ongoing operating results.

[0001032975-26-000006:8k_2_02:52]
Loss (gain) on investments. We recognize losses (gains) related to our investments in various companies, which vary depending on the operational and financial performance of the companies in which we invest. These amounts include our losses (earnings) on equity method investments as well as investment impairments and losses (gains) resulting from sales or other events related to our investments. We believe that providing the non-GAAP measures excluding these items, as well as the GAAP measures, assists our investors because such losses (gains) are not reflective of our ongoing operations.

[0001032975-26-000006:8k_2_02:53]
Non-GAAP income tax adjustment.  Non-GAAP income tax adjustment primarily measures the income tax effect of non-GAAP adjustments excluded above as well as the income tax impact of non-recurring deferred taxes, tax settlements, and other non-routine tax events, the determination of which is based upon the nature of the underlying items.

[0001032975-26-000006:8k_2_02:54]
Each of the non-GAAP financial measures described above, and used in this press release, should not be considered in isolation from, or as a substitute for, a measure of financial performance prepared in accordance with GAAP. Further, investors are cautioned that there are inherent limitations associated with the use of each of these non-GAAP financial measures as an analytical tool. In particular, these non-GAAP financial measures are not based on a comprehensive set of accounting rules or principles and many of the adjustments to the GAAP financial measures reflect the exclusion of items that are recurring and may be reflected in the Company’s financial results for the foreseeable future. We compensate for these limitations by providing specific information in the reconciliation included in this press release regarding the GAAP amounts excluded from the non-GAAP financial measures. In addition, as noted above, we evaluate the non-GAAP financial measures together with the most directly comparable GAAP financial information.

[0001032975-26-000006:8k_2_02:55]
Additional Supplemental Financial Information - Constant Currency

[0001032975-26-000006:8k_2_02:56]
In addition, Logitech presents percentage sales growth in constant currency to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales.
