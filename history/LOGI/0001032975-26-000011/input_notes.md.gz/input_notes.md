# LOGI notes — 0001032975-26-000011


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001032975-26-000011:notes:1]
[same as prior period, unchanged from 0001032975-25-000080:notes:1]

[0001032975-26-000011:notes:2]
[same as prior period, unchanged from 0001032975-25-000080:notes:2]

[0001032975-26-000011:notes:3]
[same as prior period, unchanged from 0001032975-25-000080:notes:3]

[0001032975-26-000011:notes:4]
Logitech was founded in Switzerland in 1981 and Logitech International S.A. has been the parent holding company of Logitech since 1988. Logitech International S.A. is a Swiss holding company with its registered office in Hautemorges, Switzerland, and headquarters in Lausanne, Switzerland, which conducts its business through subsidiaries in the Americas; Europe, the Middle East and Africa ("EMEA"); and Asia Pacific. Shares of Logitech International S.A. are listed on both the SIX Swiss Exchange under the trading symbol LOGN and the Nasdaq Global Select Market under the trading symbol LOGI.

[0001032975-26-000011:notes:5]
[same as prior period, unchanged from 0001032975-25-000080:notes:5]

[0001032975-26-000011:notes:6]
[same as prior period, unchanged from 0001032975-25-000080:notes:6]

[0001032975-26-000011:notes:7]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and nine months ended December 31, 2025 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2026, or any future periods.

[0001032975-26-000011:notes:8]
[same as prior period, unchanged from 0001032975-25-000080:notes:8]

[0001032975-26-000011:notes:9]
There have been no material changes in the Company’s significant accounting policies during the three and nine months ended December 31, 2025 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2025.

[0001032975-26-000011:notes:10]
[same as prior period, unchanged from 0001032975-25-000080:notes:10]

[0001032975-26-000011:notes:11]
[same as prior period, unchanged from 0001032975-25-000080:notes:11]

[0001032975-26-000011:notes:12]
[same as prior period, unchanged from 0001032975-25-000080:notes:12]

[0001032975-26-000011:notes:13]
Impacts of Macroeconomic, Geopolitical, and Other Factors on the Company's Business

[0001032975-26-000011:notes:14]
In 2025, the United States introduced trade policy actions that have increased import tariffs across a wide range of countries at various rates, with certain exemptions. These tariff policies in the U.S. and responsive policies enacted in other countries are evolving. The incremental tariffs have had and may continue to have an adverse impact on the Company's results of operations. The Company may also be affected by the increases in demand for memory chips and other components caused by the build out of new AI technologies and data centers, leading to a rise in prices for such components and suppliers transitioning away from supplying certain components utilized in the manufacturing of some of the Company’s Video Collaboration products. In addition, the Company's business has continued to be impacted by ongoing macroeconomic and geopolitical conditions. These conditions include inflation, interest rate and foreign currency fluctuations, uncertainty in consumer and enterprise demand, low economic growth in certain regions, changes in fiscal policies and geopolitical conflicts.

[0001032975-26-000011:notes:15]
The global and regional macroeconomic and political conditions, as well as changes in trade policies and memory supply, have caused and may continue to cause volatility in demand for the Company's products, component availability, transit times, and cost of the Company's products including cost of tariffs, materials, and logistics, and as a result, have impacted and may continue to impact the pricing of the Company's products, product availability and the Company's results of operations.

[0001032975-26-000011:notes:16]
[same as prior period, unchanged from 0001032975-25-000080:notes:16]

[0001032975-26-000011:notes:17]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures. ASU 2023-09 requires additional disclosures related to rate reconciliation, income taxes paid, and other disclosures. Under ASU 2023-09, for each annual period presented, public entities are required to (1) disclose specific categories in the tabular rate reconciliation and (2) provide additional information for reconciling items that meet a quantitative threshold. In addition, ASU 2023-09 requires all reporting entities to disclose on an annual basis the amount of income taxes paid disaggregated by federal, state, and foreign taxes as well as the amount of income taxes paid by individual jurisdiction. ASU 2023-09 is effective for public business entities for annual periods beginning after December 15, 2024 and can be applied on a prospective basis with an option to apply the standard retrospectively. Early adoption is permitted. The Company is currently evaluating the impact of ASU 2023-09 on its consolidated financial statements and related disclosures.

[0001032975-26-000011:notes:18]
In November 2024, the FASB issued ASU 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses. ASU 2024-03 requires all public entities to disclose in the notes to the financial statements the amounts of purchases of inventory, employee compensation, depreciation, and intangible asset amortization included in each expense caption of the income statement. ASU 2024-03 is effective for fiscal years beginning after December 15, 2026 and interim periods within fiscal years beginning after December 15, 2027. ASU 2024-03 can be applied either prospectively or retrospectively. Early adoption is permitted. The Company is currently evaluating the impact of ASU 2024-03 on its consolidated financial statements and related disclosures.

[0001032975-26-000011:notes:19]
In July 2025, the FASB issued ASU No. 2025-05, Financial Instruments—Credit Losses (Topic 326): Measurement of Credit Losses for Accounts Receivable and Contract Assets. ASU 2025-05 provides a practical expedient that permits entities to assume that current conditions as of the balance sheet date will remain unchanged over the remaining life of current accounts receivable and current contract assets when estimating the expected credit losses. ASU 2025-05 is effective for annual periods beginning after December 15, 2025, and interim periods within those annual reporting periods. Early adoption is permitted. ASU 2025-05 should be applied on a prospective basis. The Company is currently evaluating the impact of ASU 2025-05 on its consolidated financial statements and related disclosures.

[0001032975-26-000011:notes:20]
In September 2025, the FASB issued ASU No. 2025-06, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal-Use Software. ASU 2025-06 updates the cost capitalization threshold for internal-use software development costs by removing all references to software project development stages and providing new guidance on how to evaluate whether the probable-to-complete recognition threshold has been met. ASU 2025-06 is effective for annual periods beginning after December 15, 2027, and interim periods within those annual reporting periods. Early adoption is permitted. ASU 2025-06 can be applied on a prospective basis, with retrospective or modified retrospective application permitted. The Company is currently evaluating the impact of ASU 2025-06 on its consolidated financial statements and related disclosures.


## us-gaap:EarningsPerShareTextBlock

[0001032975-26-000011:notes:21]
[same as prior period, unchanged from 0001032975-25-000080:notes:21]

[0001032975-26-000011:notes:22]
The following table summarizes the computations of basic and diluted net income per share for the three and nine months ended December 31, 2025 and 2024 (in thousands, except per share amounts):

[0001032975-26-000011:notes:23]
|  |  | Three Months Ended December 31, |  | Nine Months Ended December 31, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net income |  | $ | 251,039 |  |  | $ | 200,147 |  |  | $ | 567,724 |  |  | $ | 487,463 |  |
| Shares used in net income per share computation: |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding - basic |  | 146,827 |  |  | 150,647 |  |  | 147,265 |  |  | 152,127 |  |
| Effect of potentially dilutive equivalent shares |  | 1,623 |  |  | 1,248 |  |  | 1,370 |  |  | 1,379 |  |
| Weighted average shares outstanding - diluted |  | 148,450 |  |  | 151,895 |  |  | 148,635 |  |  | 153,506 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.71 |  |  | $ | 1.33 |  |  | $ | 3.86 |  |  | $ | 3.20 |  |
| Diluted |  | $ | 1.69 |  |  | $ | 1.32 |  |  | $ | 3.82 |  |  | $ | 3.18 |  |

[0001032975-26-000011:notes:24]
Share equivalents attributable to outstanding stock options, restricted stock units and employee share purchase plans totaling 0.6 million and 0.9 million for the nine months ended December 31, 2025 and 2024, respectively, were excluded from the calculation of diluted net income per share because their effect would have been antidilutive. Antidilutive share equivalents totaled 0.8 million for the three months ended December 31, 2024 and were not material for the three months ended December 31, 2025. A small number of performance-based restricted stock units were not included in the diluted net income per share calculation because all necessary conditions had not been satisfied by the end of the respective period, and those shares were not issuable if the end of the reporting period were the end of the performance contingency period.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001032975-26-000011:notes:25]
[same as prior period, unchanged from 0001032975-25-000080:notes:25]

[0001032975-26-000011:notes:26]
[same as prior period, unchanged from 0001032975-25-000080:notes:26]

[0001032975-26-000011:notes:27]
As of December 31, 2025, the Company offers the 2006 Employee Share Purchase Plan (Non-U.S.), as amended and restated, the 1996 Employee Share Purchase Plan (U.S.), as amended and restated, and the 2006 Stock Incentive Plan, as amended and restated. Shares issued to employees as a result of purchases or exercises under these plans are generally issued from shares held in treasury stock.

[0001032975-26-000011:notes:28]
The following table summarizes share-based compensation expense and total income tax benefit recognized for the three and nine months ended December 31, 2025 and 2024 (in thousands):

[0001032975-26-000011:notes:29]
|  |  | Three Months Ended December 31, |  | Nine Months Ended December 31, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Cost of goods sold |  | $ | 2,636 |  |  | $ | 2,173 |  |  | $ | 8,375 |  |  | $ | 8,673 |  |
| Marketing and selling |  | 5,911 |  |  | 11,813 |  |  | 31,982 |  |  | 34,133 |  |
| Research and development |  | 5,395 |  |  | 5,043 |  |  | 17,412 |  |  | 15,849 |  |
| General and administrative |  | 9,493 |  |  | 7,164 |  |  | 28,806 |  |  | 17,412 |  |
| Total share-based compensation expense |  | 23,435 |  |  | 26,193 |  |  | 86,575 |  |  | 76,067 |  |
| Income tax benefit |  | (4,699) |  |  | (4,523) |  |  | (15,620) |  |  | (16,901) |  |
| Total share-based compensation expense, net of income tax benefit |  | $ | 18,736 |  |  | $ | 21,670 |  |  | $ | 70,955 |  |  | $ | 59,166 |  |

[0001032975-26-000011:notes:30]
[same as prior period, unchanged from 0001032975-25-000080:notes:30]

[0001032975-26-000011:notes:31]
Share-based compensation costs capitalized as part of inventory were $1.9 million and $1.6 million for the three months ended December 31, 2025 and 2024, respectively, and $6.7 million and $5.9 million for the nine months ended December 31, 2025 and 2024, respectively.

[0001032975-26-000011:notes:32]
[same as prior period, unchanged from 0001032975-25-000080:notes:32]

[0001032975-26-000011:notes:33]
Certain subsidiaries of the Company sponsor defined benefit pension plans or non-retirement post-employment benefits covering substantially all of their employees. Benefits are provided based on employees’ years of service and earnings, or in accordance with applicable employee benefit regulations. The Company’s practice is to fund amounts sufficient to meet the requirements set forth in the applicable employee benefit and tax regulations. The costs of $1.7 million and $1.8 million recorded for the three months ended December 31, 2025 and 2024, respectively, and $5.2 million and $5.3 million recorded for the nine months ended December 31, 2025 and 2024, respectively, were primarily related to service costs.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001032975-26-000011:notes:34]
[same as prior period, unchanged from 0001032975-25-000080:notes:34]

[0001032975-26-000011:notes:35]
[same as prior period, unchanged from 0001032975-25-000080:notes:35]

[0001032975-26-000011:notes:36]
The income tax provision for the three and nine months ended December 31, 2025 was $48.1 million and $108.9 million, respectively, based on an effective income tax rate of 16.1% of pre-tax income for both periods. The income tax provision for the same periods ended December 31, 2024 was $45.1 million and $101.2 million based on an effective income tax rate of 18.4% and 17.2% of pre-tax income, respectively.

[0001032975-26-000011:notes:37]
The change in the effective income tax rate for the three and nine months ended December 31, 2025, compared with the same periods ended December 31, 2024, was primarily due to the change in the mix of income and losses in the various tax jurisdictions in which the Company operates and favorable return to provision adjustments.

[0001032975-26-000011:notes:38]
[same as prior period, unchanged from 0001032975-25-000080:notes:38]

[0001032975-26-000011:notes:39]
For the three months ended December 31, 2025, the Company assessed its exposure to the OECD Pillar Two global minimum tax rules. The Company has determined that, for the fiscal year 2026, most jurisdictions in which it operates should qualify for the transitional Country-by-Country Reporting ("CbCR") safe harbor, as outlined in the OECD Administrative Guidance and enacted domestic legislation. The Company's CbCR has been prepared in accordance with the requirements for a Qualified CbCR, using qualified financial statements. Based on this data, most jurisdictions continue to meet safe harbor qualifications at 16% tax rates, and therefore, the Company is only required to perform a detailed Pillar Two top-up tax calculation for limited jurisdictions. The estimated top up tax for fiscal year 2026 is not material and has been included in the calculation of the Company's annual effective tax rate.

[0001032975-26-000011:notes:40]
On January 5, 2026, the OECD released an Administrative Guidance package. This package includes a “Side-by-Side” System designed to align the U.S. tax regime with Pillar Two for U.S.-parented multinational groups, effective for tax years beginning on or after January 1, 2026. As the Company is a non-U.S. headquartered multinational, the “Side-by-Side” System itself does not apply to the Company’s tax profile. However, the broader guidance package also introduces a new permanent safe harbor (to replace the transitional CbCR safe harbor for fiscal years beginning in 2027) and a one-year extension of the transitional CbCR safe harbor that may potentially impact the Company’s Pillar Two compliance and reporting. The Company continues to monitor these developments but does not expect a material change to its Pillar Two liability.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001032975-26-000011:notes:41]
[same as prior period, unchanged from 0001032975-25-000080:notes:40]

[0001032975-26-000011:notes:42]
[same as prior period, unchanged from 0001032975-25-000080:notes:41]

[0001032975-26-000011:notes:43]
|  |  | December 31, 2025 |  | March 31, 2025 |
| Accounts receivable, net: |  |  |  |  |
| Accounts receivable |  | $ | 1,136,982 |  |  | $ | 708,693 |  |
| Allowance for cooperative marketing arrangements |  | (71,059) |  |  | (44,457) |  |
| Allowance for customer incentive programs |  | (144,573) |  |  | (66,564) |  |
| Allowance for pricing programs |  | (194,731) |  |  | (105,876) |  |
| Other allowances |  | (43,493) |  |  | (37,250) |  |
|  |  | $ | 683,126 |  |  | $ | 454,546 |  |
| Inventories: |  |  |  |  |
| Raw materials |  | $ | 47,369 |  |  | $ | 48,699 |  |
| Finished goods |  | 402,175 |  |  | 455,048 |  |
|  |  | $ | 449,544 |  |  | $ | 503,747 |  |
| Other current assets: |  |  |  |  |
| Value-added tax ("VAT") receivables |  | $ | 55,552 |  |  | $ | 46,332 |  |
| Prepaid expenses and other assets |  | 111,436 |  |  | 84,879 |  |
|  |  | $ | 166,988 |  |  | $ | 131,211 |  |
| Property, plant and equipment, net: |  |  |  |  |
| Property, plant and equipment |  | $ | 575,631 |  |  | $ | 543,747 |  |
| Less: accumulated depreciation and amortization |  | (460,268) |  |  | (429,889) |  |
|  |  | $ | 115,363 |  |  | $ | 113,858 |  |
| Other assets: |  |  |  |  |
| Deferred tax assets |  | $ | 231,915 |  |  | $ | 202,180 |  |
| Right-of-use assets |  | 74,810 |  |  | 75,239 |  |
| Investments for deferred compensation plan |  | 32,078 |  |  | 29,006 |  |
| Investments in privately held companies |  | 28,863 |  |  | 27,980 |  |
| Other assets |  | 14,714 |  |  | 9,672 |  |
|  |  | $ | 382,380 |  |  | $ | 344,077 |  |

[0001032975-26-000011:notes:44]
[same as prior period, unchanged from 0001032975-25-000080:notes:43]

[0001032975-26-000011:notes:45]
|  |  | December 31, 2025 |  | March 31, 2025 |
| Accrued and other current liabilities: |  |  |  |  |
| Accrued customer marketing, pricing and incentive programs |  | $ | 232,284 |  |  | $ | 173,401 |  |
| Accrued personnel expenses |  | 152,729 |  |  | 180,763 |  |
| Income taxes payable |  | 70,768 |  |  | 26,841 |  |
| VAT payable |  | 51,128 |  |  | 29,648 |  |
| Deferred revenue (1) |  | 37,598 |  |  | 25,798 |  |
| Warranty liabilities |  | 36,257 |  |  | 34,428 |  |
| Accrued sales return liability |  | 28,966 |  |  | 27,913 |  |
| Accrued loss for inventory purchase commitments |  | 22,493 |  |  | 19,614 |  |
| Operating lease liabilities |  | 17,467 |  |  | 15,780 |  |
| Other current liabilities |  | 168,234 |  |  | 152,317 |  |
|  |  | $ | 817,924 |  |  | $ | 686,503 |  |
| Other non-current liabilities: |  |  |  |  |
| Operating lease liabilities |  | $ | 74,515 |  |  | $ | 76,622 |  |
| Employee benefit plan obligations |  | 60,265 |  |  | 57,338 |  |
| Deferred revenue (1) |  | 49,896 |  |  | 38,216 |  |
| Obligation for deferred compensation plan |  | 32,078 |  |  | 29,006 |  |
| Warranty liabilities |  | 15,186 |  |  | 14,756 |  |
| Other non-current liabilities |  | 6,060 |  |  | 5,574 |  |
|  |  | $ | 238,000 |  |  | $ | 221,512 |  |

[0001032975-26-000011:notes:46]
[same as prior period, unchanged from 0001032975-25-000080:notes:45]


## us-gaap:FairValueDisclosuresTextBlock

[0001032975-26-000011:notes:47]
[same as prior period, unchanged from 0001032975-25-000080:notes:46]

[0001032975-26-000011:notes:48]
[same as prior period, unchanged from 0001032975-25-000080:notes:47]

[0001032975-26-000011:notes:49]
[same as prior period, unchanged from 0001032975-25-000080:notes:48]

[0001032975-26-000011:notes:50]
[same as prior period, unchanged from 0001032975-25-000080:notes:49]

[0001032975-26-000011:notes:51]
[same as prior period, unchanged from 0001032975-25-000080:notes:50]

[0001032975-26-000011:notes:52]
[same as prior period, unchanged from 0001032975-25-000080:notes:51]

[0001032975-26-000011:notes:53]
|  |  | December 31, 2025 |  | March 31, 2025 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Level 1 |  | Level 2 |  | Level 3 |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 939,908 |  |  | $ | — |  |  | $ | — |  |  | $ | 852,467 |  |  | $ | — |  |  | $ | — |  |
| Investments for deferred compensation plan included in other assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 99 |  |  | $ | — |  |  | $ | — |  |  | $ | 90 |  |  | $ | — |  |  | $ | — |  |
| Common stock |  | 974 |  |  | — |  |  | — |  |  | 540 |  |  | — |  |  | — |  |
| Money market funds |  | 7,009 |  |  | — |  |  | — |  |  | 7,359 |  |  | — |  |  | — |  |
| Mutual funds |  | 23,996 |  |  | — |  |  | — |  |  | 21,017 |  |  | — |  |  | — |  |
| Total investments for deferred compensation plan |  | $ | 32,078 |  |  | $ | — |  |  | $ | — |  |  | $ | 29,006 |  |  | $ | — |  |  | $ | — |  |
| Currency derivative assets |  | $ | — |  |  | $ | 68 |  |  | $ | — |  |  | $ | — |  |  | $ | 90 |  |  | $ | — |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Currency derivative liabilities |  | $ | — |  |  | $ | 5,924 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,849 |  |  | $ | — |  |

[0001032975-26-000011:notes:54]
[same as prior period, unchanged from 0001032975-25-000080:notes:53]

[0001032975-26-000011:notes:55]
The marketable securities for the Company's deferred compensation plan were recorded at a fair value of $32.1 million and $29.0 million, as of December 31, 2025 and March 31, 2025, respectively, based on quoted market prices. Quoted market prices are observable inputs that are classified as Level 1 within the fair value hierarchy. Unrealized gains (losses) related to marketable securities for the three and nine months ended December 31, 2025 and 2024 were not material and are included in other income (expense), net and corresponding changes in the deferred compensation liability were included in operating expenses and cost of goods sold, in the Company's condensed consolidated statements of operations.

[0001032975-26-000011:notes:56]
[same as prior period, unchanged from 0001032975-25-000080:notes:55]

[0001032975-26-000011:notes:57]
The Company has certain non-marketable investments included in other assets that are accounted for as equity method investments, with a carrying value of $19.2 million and $18.4 million as of December 31, 2025 and March 31, 2025, respectively. Income (loss) related to equity method investments for the three and nine months ended December 31, 2025 and 2024 were not material and are included in other income (expense), net in the Company's condensed consolidated statements of operations. There was no impairment of equity method investments during the three and nine months ended December 31, 2025 and 2024.

[0001032975-26-000011:notes:58]
[same as prior period, unchanged from 0001032975-25-000080:notes:57]

[0001032975-26-000011:notes:59]
[same as prior period, unchanged from 0001032975-25-000080:notes:58]

[0001032975-26-000011:notes:60]
The Company has certain equity investments without readily determinable fair values due to the absence of quoted market prices, the inherent lack of liquidity, and the fact that inputs used to measure fair value are unobservable and require management's judgment. When certain events or circumstances indicate that impairment may exist, the Company revalues the investments using various assumptions, including the financial metrics and ratios of comparable public companies. The carrying value is also adjusted for observable price changes with the same or similar security from the same issuer. The amount of these equity investments without readily determinable fair value included in other assets was $8.8 million as of December 31, 2025 and March 31, 2025. There was no impairment of these equity investments during the three and nine months ended December 31, 2025. The impairment charges related to the equity investments were not material during the three and nine months ended December 31, 2024.

[0001032975-26-000011:notes:61]
Non-Financial Assets
Goodwill, intangible assets, and property, plant and equipment, are not required to be measured at fair value on a recurring basis. However, if the Company is required to evaluate these non-financial assets for impairment, whether due to certain triggering events or because of the required annual impairment test, and a resulting impairment is recorded to reduce the carrying value to the fair value, the non-financial assets are measured at fair value during such period. There was no impairment of non-financial assets during the three and nine months ended December 31, 2025 and 2024.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001032975-26-000011:notes:62]
[same as prior period, unchanged from 0001032975-25-000080:notes:61]

[0001032975-26-000011:notes:63]
Under certain agreements with the respective counterparties to the Company’s derivative contracts, subject to applicable requirements, the Company is allowed to net settle transactions of the same type with a single net amount payable by one party to the other. However, the Company presents its derivative assets and derivative liabilities on a gross basis. Based on maturity, derivative assets are included in other current assets or other assets and derivative liabilities are included in accrued and other current liabilities or other non-current liabilities on the condensed consolidated balance sheets. See Note 6 for the fair values of the Company’s derivative instruments as of December 31, 2025 and March 31, 2025.

[0001032975-26-000011:notes:64]
[same as prior period, unchanged from 0001032975-25-000080:notes:63]

[0001032975-26-000011:notes:65]
The Company enters into cash flow hedge contracts, including foreign currency forward contracts and foreign currency option contracts, to protect against exchange rate exposure of forecasted inventory purchases. Previously, the hedge contracts covered inventory purchases within four months. Beginning in fiscal year 2026, they cover inventory purchases up to sixteen months, with reduced coverage beyond four months. Gains and losses in the fair value of the effective portion of the hedges are deferred as a component of accumulated other comprehensive income (loss) until the hedged inventory purchases are sold, at which time the gains or losses are reclassified to cost of goods sold. Cash flows from such hedges are classified as operating activities in the condensed consolidated statements of cash flows. Hedging relationships are discontinued when the hedging contract is no longer eligible for hedge accounting, or is sold, terminated or exercised, or when the Company removes hedge designation for the contract. Gains and losses in the fair value of the effective portion of the discontinued hedges continue to be reported in accumulated other comprehensive income (loss) until the hedged inventory purchases are sold, unless it is probable that the forecasted inventory purchases will not occur by the end of the originally specified time period or within an additional two-month period of time thereafter.

[0001032975-26-000011:notes:66]
The notional amounts of foreign currency exchange contracts outstanding related to forecasted inventory purchases were $444.5 million and $74.6 million as of December 31, 2025 and March 31, 2025, respectively. The Company had $8.3 million of net loss related to its cash flow hedges included in accumulated other comprehensive loss as of December 31, 2025, which will be reclassified into earnings within the next twelve months.

[0001032975-26-000011:notes:67]
The following table presents the amounts of gain (loss) on the Company’s derivative instruments designated as hedging instruments for the three and nine months ended December 31, 2025 and 2024 and their locations on its condensed consolidated statements of operations and condensed consolidated statements of comprehensive income (in thousands):

[0001032975-26-000011:notes:68]
|  |  | Three Months Ended December 31, |
|  |  | Amount of Gain (Loss)Deferred as a Component of AccumulatedOther Comprehensive Loss |  | Amount of LossReclassified from Accumulated Other Comprehensive Loss to Costs of Goods Sold |  |  |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |  |  |  |  |
| Cash flow hedges |  | $ | (5,047) |  |  | $ | 3,577 |  |  | $ | 3,328 |  |  | $ | 790 |  |  |  |  |  |
|  |  | Nine Months Ended December 31, |
|  |  | Amount of Gain (Loss)Deferred as a Component of AccumulatedOther Comprehensive Loss |  | Amount of Loss (Gain) Reclassified from Accumulated Other Comprehensive Loss to Costs of Goods Sold |  |  |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |  |  |  |  |
| Cash flow hedges |  | $ | (16,807) |  |  | $ | 2,228 |  |  | $ | 11,291 |  |  | $ | (849) |  |  |  |  |  |

[0001032975-26-000011:notes:69]
[same as prior period, unchanged from 0001032975-25-000080:notes:69]

[0001032975-26-000011:notes:70]
The Company also enters into foreign currency exchange forward and swap contracts to reduce the short-term effects of currency exchange rate fluctuations on certain receivables or payables denominated in currencies other than the functional currencies of its subsidiaries. These contracts generally mature within approximately one month. The primary risk managed by using forward and swap contracts is the currency exchange rate risk. The gains or losses on these contracts are not material and are included in other income (expense), net, in the condensed consolidated statements of operations based on the changes in fair value. The notional amounts of these contracts outstanding as of December 31, 2025 and March 31, 2025 were $95.0 million and $131.8 million, respectively.

[0001032975-26-000011:notes:71]
[same as prior period, unchanged from 0001032975-25-000080:notes:71]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001032975-26-000011:notes:72]
Goodwill and Other Intangible Assets
The Company conducts its impairment analysis of goodwill annually at December 31 or more frequently if changes in facts and circumstances indicate that it is more likely than not that the fair value of the Company’s reporting unit may be less than its carrying amount. The Company conducted its annual impairment analysis of goodwill as of December 31, 2025 by performing a qualitative assessment and concluded that it was more likely than not that the fair value of its reporting unit exceeds its carrying amount.

[0001032975-26-000011:notes:73]
[same as prior period, unchanged from 0001032975-25-000080:notes:73]

[0001032975-26-000011:notes:74]
| As of March 31, 2025 |  | $ | 463,230 |  |
| Effects of foreign currency translation |  | 3,349 |  |
| As of December 31, 2025 |  | $ | 466,579 |  |

[0001032975-26-000011:notes:75]
[same as prior period, unchanged from 0001032975-25-000080:notes:75]

[0001032975-26-000011:notes:76]
|  |  | December 31, 2025 |  | March 31, 2025 |
|  |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |
| Trademarks and trade names |  | $ | 32,390 |  |  | $ | (30,282) |  |  | $ | 2,108 |  |  | $ | 32,390 |  |  | $ | (28,675) |  |  | $ | 3,715 |  |
| Developed technology |  | 107,421 |  |  | (102,253) |  |  | 5,168 |  |  | 107,421 |  |  | (96,464) |  |  | 10,957 |  |
| Customer contracts/relationships |  | 69,087 |  |  | (62,393) |  |  | 6,694 |  |  | 69,087 |  |  | (58,646) |  |  | 10,441 |  |
| Effects of foreign currency translation |  | 988 |  |  | (1,069) |  |  | (81) |  |  | (620) |  |  | 137 |  |  | (483) |  |
| Total |  | $ | 209,886 |  |  | $ | (195,997) |  |  | $ | 13,889 |  |  | $ | 208,278 |  |  | $ | (183,648) |  |  | $ | 24,630 |  |


## us-gaap:DebtDisclosureTextBlock

[0001032975-26-000011:notes:77]
Financing Arrangements

[0001032975-26-000011:notes:78]
On January 27, 2025, the Company entered into an unsecured revolving credit facility with a syndicate of banks (the "Credit Agreement"). The Credit Agreement provides a revolving line of credit of up to $750.0 million to the Company including the issuance of letters of credit of up to $100.0 million. The Credit Agreement terminates on January 27, 2030 unless extended in accordance with its terms. The Credit Agreement contains (1) an increase option allowing the Company to secure up to $250.0 million of additional commitments and (2) an extension option to extend the term by one-year which may be exercised no more than two times, subject to certain requirements. Loans under the Credit Agreement are available in U.S. Dollars, Euro, Sterling, Yen, Swiss Francs, Canadian Dollars, Australian Dollars and any other currency agreed to by each lender. Proceeds of loans made under the Credit Agreement may be used for general corporate purposes.

[0001032975-26-000011:notes:79]
The Credit Agreement contains a maximum net debt to adjusted EBITDA ratio, compliance with which is a condition to the Company's ability to borrow. Borrowings under the Credit Agreement will bear interest at a rate determined by reference to benchmark rates plus an applicable spread (ranging from 0% to 1.5%) based on the Company's net leverage ratio or credit rating at the time of the borrowing. Undrawn balances available under the Credit Agreement are subject to commitment fees at the applicable rate determined by reference to the Company's net leverage ratio or credit rating. There has been no borrowing outstanding under the Credit Agreement as of December 31, 2025.
In addition, the Company had several uncommitted, unsecured bank lines of credit and letters of credit aggregating to $164.0 million and $172.2 million as of December 31, 2025 and March 31, 2025, respectively. There are no financial covenants under the lines of credit with which the Company must comply. There was no borrowing outstanding under the lines of credit as of December 31, 2025 or March 31, 2025. As of December 31, 2025 and March 31, 2025, the Company had outstanding bank guarantees of $8.5 million and $12.1 million, respectively.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001032975-26-000011:notes:80]
Commitments and Contingencies

[0001032975-26-000011:notes:81]
Product Warranties

[0001032975-26-000011:notes:82]
Changes in the Company’s warranty liabilities for the three and nine months ended December 31, 2025 and 2024 were as follows (in thousands):

[0001032975-26-000011:notes:83]
|  | Three Months Ended December 31, |  | Nine Months Ended December 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Beginning of the period | $ | 50,191 |  |  | $ | 46,833 |  |  | $ | 49,184 |  |  | $ | 44,654 |  |
| Provision | 9,430 |  |  | 12,060 |  |  | 28,424 |  |  | 34,022 |  |
| Settlements | (8,438) |  |  | (9,111) |  |  | (27,079) |  |  | (29,124) |  |
| Effects of foreign currency translation | 260 |  |  | (721) |  |  | 914 |  |  | (491) |  |
| End of the period | $ | 51,443 |  |  | $ | 49,061 |  |  | $ | 51,443 |  |  | $ | 49,061 |  |

[0001032975-26-000011:notes:84]
Indemnifications

[0001032975-26-000011:notes:85]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of December 31, 2025, no material amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

[0001032975-26-000011:notes:86]
The Company also indemnifies its current and former directors and certain of its current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. The Company is unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not limited, the obligations are conditional in nature, and the facts and circumstances involved in any situation that might arise are variable.

[0001032975-26-000011:notes:87]
Legal Proceedings

[0001032975-26-000011:notes:88]
From time to time the Company is involved in claims and legal proceedings that arise in the ordinary course of its business. The Company is currently subject to several such claims and legal proceedings. The Company intends to vigorously defend against them. Management periodically assesses the Company’s liabilities and contingencies in connection with these matters based upon the latest information available. The Company follows ASC ("Accounting Standards Codification") 450, Contingencies, in determining the accounting and disclosure for these contingencies. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows, and results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company's defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company's business, financial condition, cash flows and results of operations in a particular period. Any claims or proceedings against the Company can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity, and other factors. Any failure to obtain a necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company's business.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001032975-26-000011:notes:89]
[same as prior period, unchanged from 0001032975-25-000080:notes:89]

[0001032975-26-000011:notes:90]
As of December 31, 2025, the Company's nominal share capital is CHF 40.2 million, consisting of 160,784,460 issued shares with a par value of CHF 0.25 each, of which 14,026,614 were held in treasury shares.

[0001032975-26-000011:notes:91]
[same as prior period, unchanged from 0001032975-25-000080:notes:91]

[0001032975-26-000011:notes:92]
[same as prior period, unchanged from 0001032975-25-000080:notes:92]

[0001032975-26-000011:notes:93]
[same as prior period, unchanged from 0001032975-25-000080:notes:93]

[0001032975-26-000011:notes:94]
[same as prior period, unchanged from 0001032975-25-000080:notes:94]

[0001032975-26-000011:notes:95]
increase of $600.0 million to the 2023 share repurchase program, to an aggregate amount of $1.6 billion. The Swiss Takeover Board approved this increase in April 2025 and it became effective on April 2, 2025. As of December 31, 2025, $409.5 million was available for repurchase under the 2023 share repurchase program.

[0001032975-26-000011:notes:96]
The following table summarizes the Company's share repurchase activities for the nine months ended December 31, 2025 and 2024 were as follows (in thousands):

[0001032975-26-000011:notes:97]
|  | Nine Months Ended December 31, |
|  | 2025 |  | 2024 |
| 2023 Share Repurchase Program: |  |  |  |
| Number of shares repurchased (1) | 2,678 |  | 5,328 |
| Aggregate cost of shares repurchased (1) (2) | $ | 239,056 |  |  | $ | 461,402 |  |

[0001032975-26-000011:notes:98]
[same as prior period, unchanged from 0001032975-25-000080:notes:98]

[0001032975-26-000011:notes:99]
(2) Includes an aggregate cost of $2.4 million and $17.6 million, respectively, that was not yet paid as of December 31, 2025 and 2024.

[0001032975-26-000011:notes:100]
Swiss law limits a company’s ability to hold or repurchase its own shares. The aggregate par value of all shares held in treasury by the Company and its subsidiaries may not exceed 10% of the share capital of the Company, which for the Company corresponds to approximately 16.1 million registered shares as of December 31, 2025. This limitation does not apply to shares repurchased for cancellation, due to the Board of Directors’ authority under the Company’s capital band set forth in the Company’s Articles of Incorporation. As of December 31, 2025, the Company had a total of 14.0 million shares held in treasury stock, which includes 1.1 million shares that have been repurchased for cancellation and 12.9 million shares that have been purchased to support equity incentive plans or potential acquisitions.

[0001032975-26-000011:notes:101]
To the extent that the shares are repurchased to support equity incentive plans or potential acquisitions, the shares are repurchased on the ordinary trading line of the SIX Swiss Exchange (“SIX”) and/or The Nasdaq Global Select Market (“Nasdaq”). Shares repurchased for cancellation purposes are repurchased on a second trading line on the SIX. Shares may be repurchased from time to time on the open market or in privately negotiated transactions, including under plans complying with the provisions of Rule 10b5-1 and Rule 10b-18 of the Securities Exchange Act of 1934, as amended. Purchases may be started or stopped at any time without prior notice depending on market conditions and other factors and the program does not require the purchase of any minimum number of shares.

[0001032975-26-000011:notes:102]
[same as prior period, unchanged from 0001032975-25-000080:notes:102]

[0001032975-26-000011:notes:103]
[same as prior period, unchanged from 0001032975-25-000080:notes:103]

[0001032975-26-000011:notes:104]
[same as prior period, unchanged from 0001032975-25-000080:notes:104]

[0001032975-26-000011:notes:105]
During the nine months ended December 31, 2025, the Company declared cash dividends of CHF 1.26 (USD equivalent of $1.58 based on the exchange rate on the date of declaration) per share and paid a total of $233.1 million on the Company's outstanding shares. During the nine months ended December 31, 2024, the Company declared cash dividends of CHF 1.16 (USD equivalent of $1.37 based on the exchange rate on the date of declaration) per share and paid a total of $207.9 million on the Company's outstanding shares.

[0001032975-26-000011:notes:106]
[same as prior period, unchanged from 0001032975-25-000080:notes:106]

[0001032975-26-000011:notes:107]
[same as prior period, unchanged from 0001032975-25-000080:notes:107]

[0001032975-26-000011:notes:108]
[same as prior period, unchanged from 0001032975-25-000080:notes:108]

[0001032975-26-000011:notes:109]
|  |  | Currency Translation Adjustment |  | Defined Benefit Plans |  | Deferred Hedging Losses |  | Total |
| March 31, 2025 |  | $ | (118,652) |  |  | $ | (25,276) |  |  | $ | (3,024) |  |  | $ | (146,952) |  |
| Other comprehensive income (loss) |  | 26,874 |  |  | (531) |  |  | (5,516) |  |  | 20,827 |  |
| December 31, 2025 |  | $ | (91,778) |  |  | $ | (25,807) |  |  | $ | (8,540) |  |  | $ | (126,125) |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001032975-26-000011:notes:110]
[same as prior period, unchanged from 0001032975-25-000080:notes:110]

[0001032975-26-000011:notes:111]
[same as prior period, unchanged from 0001032975-25-000080:notes:111]

[0001032975-26-000011:notes:112]
[same as prior period, unchanged from 0001032975-25-000080:notes:112]

[0001032975-26-000011:notes:113]
|  | Three Months Ended December 31, |  | Nine Months Ended December 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net sales | $ | 1,421,479 |  |  | $ | 1,340,294 |  |  | $ | 3,755,238 |  |  | $ | 3,544,545 |  |
| Less: Significant segment expenses |  |  |  |  |  |  |  |
| Cost of goods sold (1) | 802,631 |  |  | 761,230 |  |  | 2,132,902 |  |  | 2,001,738 |  |
| Marketing and selling (1) | 200,964 |  |  | 205,235 |  |  | 569,682 |  |  | 581,683 |  |
| Research and development (1) | 73,057 |  |  | 72,930 |  |  | 211,737 |  |  | 213,636 |  |
| General and administrative (1) | 32,428 |  |  | 34,953 |  |  | 96,714 |  |  | 106,336 |  |
| Less: other segment items |  |  |  |  |  |  |  |
| Share-based compensation expense | 23,435 |  |  | 26,193 |  |  | 86,575 |  |  | 76,067 |  |
| Amortization of intangible assets and acquisition-related costs | 2,488 |  |  | 5,087 |  |  | 11,283 |  |  | 15,409 |  |
| Interest income | (10,985) |  |  | (12,176) |  |  | (34,042) |  |  | (42,603) |  |
| Other (2) | (1,669) |  |  | 1,634 |  |  | 3,717 |  |  | 3,614 |  |
| Provision for income taxes | 48,091 |  |  | 45,061 |  |  | 108,946 |  |  | 101,202 |  |
| Net income | $ | 251,039 |  |  | $ | 200,147 |  |  | $ | 567,724 |  |  | $ | 487,463 |  |

[0001032975-26-000011:notes:114]
[same as prior period, unchanged from 0001032975-25-000080:notes:114]

[0001032975-26-000011:notes:115]
[same as prior period, unchanged from 0001032975-25-000080:notes:115]

[0001032975-26-000011:notes:116]
Sales by product category for the three and nine months ended December 31, 2025 and 2024 were as follows (in thousands):

[0001032975-26-000011:notes:117]
|  |  | Three Months Ended December 31, |  | Nine Months Ended December 31, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Gaming (1) |  | $ | 482,714 |  |  | $ | 466,715 |  |  | $ | 1,121,894 |  |  | $ | 1,076,660 |  |
| Keyboards & Combos |  | 254,612 |  |  | 236,748 |  |  | 712,974 |  |  | 662,017 |  |
| Pointing Devices |  | 241,160 |  |  | 217,045 |  |  | 658,034 |  |  | 602,927 |  |
| Video Collaboration |  | 193,252 |  |  | 176,053 |  |  | 527,645 |  |  | 482,755 |  |
| Webcams |  | 82,268 |  |  | 84,419 |  |  | 249,944 |  |  | 237,572 |  |
| Tablet Accessories |  | 93,567 |  |  | 77,433 |  |  | 269,855 |  |  | 241,586 |  |
| Headsets |  | 45,939 |  |  | 45,886 |  |  | 134,959 |  |  | 137,038 |  |
| Other (2) |  | 27,967 |  |  | 35,995 |  |  | 79,933 |  |  | 103,990 |  |
| Total Sales |  | $ | 1,421,479 |  |  | $ | 1,340,294 |  |  | $ | 3,755,238 |  |  | $ | 3,544,545 |  |

[0001032975-26-000011:notes:118]
[same as prior period, unchanged from 0001032975-25-000080:notes:118]

[0001032975-26-000011:notes:119]
[same as prior period, unchanged from 0001032975-25-000080:notes:119]

[0001032975-26-000011:notes:120]
Sales by geographic region (based on the customers’ locations) for the three and nine months ended December 31, 2025 and 2024 were as follows (in thousands):

[0001032975-26-000011:notes:121]
|  |  | Three Months Ended December 31, |  | Nine Months Ended December 31, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Americas |  | $ | 556,358 |  |  | $ | 553,563 |  |  | $ | 1,480,784 |  |  | $ | 1,518,933 |  |
| EMEA |  | 485,731 |  |  | 454,665 |  |  | 1,214,948 |  |  | 1,116,368 |  |
| Asia Pacific |  | 379,390 |  |  | 332,066 |  |  | 1,059,506 |  |  | 909,244 |  |
| Total Sales |  | $ | 1,421,479 |  |  | $ | 1,340,294 |  |  | $ | 3,755,238 |  |  | $ | 3,544,545 |  |

[0001032975-26-000011:notes:122]
Revenue from sales to customers in the United States, Germany and China each represented 10% or more of the total consolidated sales for each of the three and nine months ended December 31, 2025 and 2024. No other countries represented 10% or more of the Company’s total consolidated sales for the periods presented herein.

[0001032975-26-000011:notes:123]
Switzerland, the Company’s country of domicile, represented 4% of the Company's total consolidated sales for each of the three and nine months ended December 31, 2025, and 3% of the Company's total consolidated sales for each of the three and nine months ended December 31, 2024.

[0001032975-26-000011:notes:124]
Three customers of the Company each represented 10% or more of the total consolidated gross sales for each of the three and nine months ended December 31, 2025 and 2024.

[0001032975-26-000011:notes:125]
[same as prior period, unchanged from 0001032975-25-000080:notes:125]

[0001032975-26-000011:notes:126]
|  |  | December 31, 2025 |  | March 31, 2025 |
| Americas |  | $ | 60,604 |  |  | $ | 61,521 |  |
| EMEA |  | 50,494 |  |  | 47,874 |  |
| Asia Pacific |  | 62,222 |  |  | 60,710 |  |
| Total |  | $ | 173,320 |  |  | $ | 170,105 |  |

[0001032975-26-000011:notes:127]
Property, plant and equipment, net (excluding software) and right-of-use assets in the United States and China, were $59.1 million and $45.6 million, respectively, as of December 31, 2025. Property, plant and equipment, net (excluding software) and right-of-use assets in the United States and China were $60.0 million and $43.4 million, respectively, as of March 31, 2025. 
Property, plant and equipment, net (excluding software) and right-of-use assets in Switzerland, the Company’s country of domicile, were $26.1 million and $24.1 million as of December 31, 2025 and March 31, 2025, respectively. No other countries represented more than 10% of the Company’s total property, plant and equipment, net (excluding software) and right-of-use assets as of December 31, 2025 or March 31, 2025.
