# LOGI MD&A — 0001032975-26-000011


## mdna

[0001032975-26-000011:mdna:1]
[same as prior period, unchanged from 0001032975-25-000080:mdna:1]

[0001032975-26-000011:mdna:2]
[same as prior period, unchanged from 0001032975-25-000080:mdna:2]

[0001032975-26-000011:mdna:3]
[same as prior period, unchanged from 0001032975-25-000080:mdna:3]

[0001032975-26-000011:mdna:4]
[same as prior period, unchanged from 0001032975-25-000080:mdna:4]

[0001032975-26-000011:mdna:5]
•The availability and pricing of components used to manufacture our products;

[0001032975-26-000011:mdna:6]
[same as prior period, unchanged from 0001032975-25-000080:mdna:5]

[0001032975-26-000011:mdna:7]
[same as prior period, unchanged from 0001032975-25-000080:mdna:6]

[0001032975-26-000011:mdna:8]
[same as prior period, unchanged from 0001032975-25-000080:mdna:7]

[0001032975-26-000011:mdna:9]
[same as prior period, unchanged from 0001032975-25-000080:mdna:8]

[0001032975-26-000011:mdna:10]
[same as prior period, unchanged from 0001032975-25-000080:mdna:9]

[0001032975-26-000011:mdna:11]
[same as prior period, unchanged from 0001032975-25-000080:mdna:10]

[0001032975-26-000011:mdna:12]
•Our expectations regarding our potential indemnification obligations, and the outcome of pending or future legal proceedings and tax audits;

[0001032975-26-000011:mdna:13]
[same as prior period, unchanged from 0001032975-25-000080:mdna:12]

[0001032975-26-000011:mdna:14]
[same as prior period, unchanged from 0001032975-25-000080:mdna:13]

[0001032975-26-000011:mdna:15]
[same as prior period, unchanged from 0001032975-25-000080:mdna:14]

[0001032975-26-000011:mdna:16]
[same as prior period, unchanged from 0001032975-25-000080:mdna:15]

[0001032975-26-000011:mdna:17]
[same as prior period, unchanged from 0001032975-25-000080:mdna:16]

[0001032975-26-000011:mdna:18]
[same as prior period, unchanged from 0001032975-25-000080:mdna:17]

[0001032975-26-000011:mdna:19]
[same as prior period, unchanged from 0001032975-25-000080:mdna:18]

[0001032975-26-000011:mdna:20]
[same as prior period, unchanged from 0001032975-25-000080:mdna:19]

[0001032975-26-000011:mdna:21]
[same as prior period, unchanged from 0001032975-25-000080:mdna:20]

[0001032975-26-000011:mdna:22]
We sell our products to a broad range of international customers, in the Americas; Europe, the Middle East and Africa (“EMEA”); and Asia Pacific. This includes direct sales to retailers, e-tailers, businesses large and small and end consumers through our e-commerce platform, and indirect sales to end customers through distributors.

[0001032975-26-000011:mdna:23]
[same as prior period, unchanged from 0001032975-25-000080:mdna:22]

[0001032975-26-000011:mdna:24]
Impacts of Macroeconomic, Geopolitical, and Other Factors on our Business

[0001032975-26-000011:mdna:25]
In 2025, the United States introduced trade policy actions that have increased import tariffs across a wide range of countries at various rates, with certain exemptions. These tariff policies in the U.S. and responsive policies enacted in other countries are evolving. The incremental tariffs have had and may continue to have an adverse impact on our results of operations. We may also be affected by the increases in demand for memory chips and other components caused by the build out of new AI technologies and data centers, leading to a rise in prices for such components and suppliers transitioning away from supplying certain components utilized in the manufacturing of some of our Video Collaboration products. In addition, our business has continued to be impacted by ongoing macroeconomic and geopolitical conditions. These conditions include inflation, interest rate and foreign currency fluctuations, uncertainty in consumer and enterprise demand, low economic growth in certain regions, changes in fiscal policies and geopolitical conflicts.

[0001032975-26-000011:mdna:26]
The global and regional macroeconomic and political conditions, as well as changes in trade policies and memory supply, have caused and may continue to cause volatility in demand for our products, component availability, transit times and cost of our products including cost of tariffs, materials, and logistics, and as a result, have impacted and may continue to impact the pricing of our products, product availability and our results of operations.

[0001032975-26-000011:mdna:27]
[same as prior period, unchanged from 0001032975-25-000080:mdna:26]

[0001032975-26-000011:mdna:28]
[same as prior period, unchanged from 0001032975-25-000080:mdna:27]

[0001032975-26-000011:mdna:29]
[same as prior period, unchanged from 0001032975-25-000080:mdna:28]

[0001032975-26-000011:mdna:30]
[same as prior period, unchanged from 0001032975-25-000080:mdna:29]

[0001032975-26-000011:mdna:31]
[same as prior period, unchanged from 0001032975-25-000080:mdna:30]

[0001032975-26-000011:mdna:32]
[same as prior period, unchanged from 0001032975-25-000080:mdna:31]

[0001032975-26-000011:mdna:33]
While we believe we will further benefit from these secular trends, we have experienced and will continue to experience challenges that impact our business and financial results. These challenges include (i) uncertainty in tariffs on goods imported into the U.S. and responsive policies enacted by other countries, (ii) uncertainty in supply and pricing of memory chips and other components, (iii) the macroeconomic environment, including inflation, interest rate and foreign currency fluctuations, low economic growth in certain regions, changes in fiscal policies and geopolitical conflicts, (iv) the uncertainty of overall consumer and enterprise demand, (v) the uncertainty of timing of enterprise investments in infrastructure and technology, and (vi) the timing of further development of our B2B go-to-market capabilities.

[0001032975-26-000011:mdna:34]
[same as prior period, unchanged from 0001032975-25-000080:mdna:33]

[0001032975-26-000011:mdna:35]
[same as prior period, unchanged from 0001032975-25-000080:mdna:34]

[0001032975-26-000011:mdna:36]
[same as prior period, unchanged from 0001032975-25-000080:mdna:35]

[0001032975-26-000011:mdna:37]
[same as prior period, unchanged from 0001032975-25-000080:mdna:36]

[0001032975-26-000011:mdna:38]
[same as prior period, unchanged from 0001032975-25-000080:mdna:37]

[0001032975-26-000011:mdna:39]
Our sales were $1,421.5 million and $3,755.2 million for the three and nine months ended December 31, 2025, respectively, an increase of 6% compared to $1,340.3 million and $3,544.5 million for the three and nine months ended December 31, 2024, respectively, primarily due to an increase in sales for Pointing Devices, Keyboards & Combos, Video Collaboration, Gaming, and Tablet Accessories. Our sales for the three and nine months ended December 31, 2025, compared to the same periods ended December 31, 2024, benefited from improved demand in the Asia Pacific and EMEA regions as well as favorable foreign currency exchange rate changes.

[0001032975-26-000011:mdna:40]
Sales for the three months ended December 31, 2025 increased 14%, 7%, and 1% in the Asia Pacific, EMEA, and Americas regions, respectively, compared to the three months ended December 31, 2024. Sales for the nine months ended December 31, 2025 increased 17% and 9% in the Asia Pacific and EMEA regions, respectively, and decreased 3% in the Americas region, compared to the nine months ended December 31, 2024.

[0001032975-26-000011:mdna:41]
Gross margin was 43.2% for the three months ended December 31, 2025 and increased by 30 basis points from 42.9% for the three months ended December 31, 2024. Gross margin was 42.8% for the nine months ended December 31, 2025 and decreased by 30 basis points from 43.1% for the nine months ended December 31, 2024. The increase in gross margin for the three-month period was primarily driven by product cost reductions, price increases in North America, and favorable foreign currency exchange rate changes, partially offset by investment in strategic promotions and increased tariffs. Gross margin decreased during the nine-month period due to investment in strategic promotions and increased tariffs, partially offset by product cost reductions and price increases in North America.

[0001032975-26-000011:mdna:42]
Operating expenses for the three months ended December 31, 2025 were $328.6 million, or 23.1% of sales, compared to $339.9 million, or 25.4% of sales, for the three months ended December 31, 2024. Operating expenses for the nine months ended December 31, 2025 were $968.7 million, or 25.8% of sales, compared to $977.8 million, or 27.6% of sales, for the nine months ended December 31, 2024.

[0001032975-26-000011:mdna:43]
We had an income tax provision of $48.1 million and $45.1 million for the three months ended December 31, 2025 and 2024, respectively. We had an income tax provision of $108.9 million and $101.2 million for the nine months ended December 31, 2025 and 2024, respectively.

[0001032975-26-000011:mdna:44]
Net income for the three and nine months ended December 31, 2025 was $251.0 million and $567.7 million, respectively, compared to $200.1 million and $487.5 million, for the three and nine months ended December 31, 2024, respectively.

[0001032975-26-000011:mdna:45]
[same as prior period, unchanged from 0001032975-25-000080:mdna:44]

[0001032975-26-000011:mdna:46]
[same as prior period, unchanged from 0001032975-25-000080:mdna:45]

[0001032975-26-000011:mdna:47]
[same as prior period, unchanged from 0001032975-25-000080:mdna:46]

[0001032975-26-000011:mdna:48]
[same as prior period, unchanged from 0001032975-25-000080:mdna:47]

[0001032975-26-000011:mdna:49]
We believe that the assumptions, judgments and estimates involved in the accounting for accruals for customer incentives and related breakage, accrued sales return liability, inventory valuation, and uncertain tax positions have the greatest potential impact on our condensed consolidated financial statements. These areas are key components of our results of operations and are based on complex rules requiring us to make judgments and estimates, and consequently, we consider these to be our critical accounting policies.

[0001032975-26-000011:mdna:50]
There have been no material changes in our critical accounting estimates during the nine months ended December 31, 2025 compared with the critical accounting estimates disclosed in Management's Discussion and Analysis of Financial Condition and Results of Operations included in our Annual Report on Form 10-K for the fiscal year ended March 31, 2025.

[0001032975-26-000011:mdna:51]
[same as prior period, unchanged from 0001032975-25-000080:mdna:50]

[0001032975-26-000011:mdna:52]
[same as prior period, unchanged from 0001032975-25-000080:mdna:51]

[0001032975-26-000011:mdna:53]
[same as prior period, unchanged from 0001032975-25-000080:mdna:52]

[0001032975-26-000011:mdna:54]
[same as prior period, unchanged from 0001032975-25-000080:mdna:53]

[0001032975-26-000011:mdna:55]
[same as prior period, unchanged from 0001032975-25-000080:mdna:54]

[0001032975-26-000011:mdna:56]
[same as prior period, unchanged from 0001032975-25-000080:mdna:55]

[0001032975-26-000011:mdna:57]
[same as prior period, unchanged from 0001032975-25-000080:mdna:56]

[0001032975-26-000011:mdna:58]
[same as prior period, unchanged from 0001032975-25-000080:mdna:57]

[0001032975-26-000011:mdna:59]
[same as prior period, unchanged from 0001032975-25-000080:mdna:58]

[0001032975-26-000011:mdna:60]
Our sales for the three and nine months ended December 31, 2025 increased 6%, compared to the three and nine months ended December 31, 2024, primarily due to an increase in sales for Pointing Devices, Keyboards & Combos, Video Collaboration, Gaming, and Tablet Accessories. Our sales for the three and nine months ended December 31, 2025, compared to the same periods ended December 31, 2024, benefited from improved demand in the Asia Pacific and EMEA regions as well as favorable foreign currency exchange rate changes. If currency exchange rates had been constant in each of the three and nine months ended December 31, 2025 and 2024, our sales growth rates in constant currency would have been 4% for both periods.

[0001032975-26-000011:mdna:61]
[same as prior period, unchanged from 0001032975-25-000080:mdna:60]

[0001032975-26-000011:mdna:62]
Although our financial results are reported in U.S. Dollars, a portion of our sales was generated in currencies other than the U.S. Dollar, such as the Euro, Chinese Renminbi, Japanese Yen, Australian Dollar, Canadian Dollar, Pound Sterling and Brazilian Real. During the three months ended December 31, 2025, approximately 54% of our sales were denominated in currencies other than the U.S. Dollar.

[0001032975-26-000011:mdna:63]
[same as prior period, unchanged from 0001032975-25-000080:mdna:62]

[0001032975-26-000011:mdna:64]
The following table presents the change in sales by region for the three and nine months ended December 31, 2025, compared with the three and nine months ended December 31, 2024:

[0001032975-26-000011:mdna:65]
|  |  | Sales Growth Rate |  | Constant DollarSales Growth Rate |
|  |  | Three Months EndedDecember 31, 2025 |  | Nine Months EndedDecember 31, 2025 |  | Three Months EndedDecember 31, 2025 |  | Nine Months EndedDecember 31, 2025 |
| Americas |  | 1% |  | (3)% |  | —% |  | (2)% |
| EMEA |  | 7% |  | 9% |  | 2% |  | 4% |
| Asia Pacific |  | 14% |  | 17% |  | 15% |  | 16% |

[0001032975-26-000011:mdna:66]
[same as prior period, unchanged from 0001032975-25-000080:mdna:65]

[0001032975-26-000011:mdna:67]
The increase in sales in the Americas region for the three-month period presented above was primarily driven by an increase in sales for Pointing Devices and Keyboards & Combos, offset by a decrease in sales for Gaming and mobile speakers. The decrease in sales in the Americas region for the nine-month period presented above was primarily driven by a decrease in sales for Gaming, partially offset by an increase in sales for Pointing Devices. The decline in Gaming sales in both the three-month and nine-month periods was primarily driven by a decline in the Gaming market and a competitive pricing environment in North America.

[0001032975-26-000011:mdna:68]
[same as prior period, unchanged from 0001032975-25-000080:mdna:67]

[0001032975-26-000011:mdna:69]
The increase in sales in the EMEA region for the three- and nine-month periods presented above was primarily driven by an increase in sales for Keyboards & Combos, Video Collaboration and Pointing Devices.

[0001032975-26-000011:mdna:70]
[same as prior period, unchanged from 0001032975-25-000080:mdna:69]

[0001032975-26-000011:mdna:71]
The increase in sales in the Asia Pacific region for the three- and nine-month periods presented above was primarily driven by an increase in sales for Gaming and Tablet Accessories.

[0001032975-26-000011:mdna:72]
[same as prior period, unchanged from 0001032975-25-000080:mdna:71]

[0001032975-26-000011:mdna:73]
Sales by product category for the three and nine months ended December 31, 2025 and 2024 were as follows (Dollars in thousands):

[0001032975-26-000011:mdna:74]
|  |  | Three Months Ended December 31, |  | Nine Months Ended December 31, |
|  |  | 2025 |  | 2024 |  | Change |  | 2025 |  | 2024 |  | Change |
| Gaming (1) |  | $ | 482,714 |  |  | $ | 466,715 |  |  | 3 | % |  | $ | 1,121,894 |  |  | $ | 1,076,660 |  |  | 4 | % |
| Keyboards & Combos |  | 254,612 |  |  | 236,748 |  |  | 8 |  |  | 712,974 |  |  | 662,017 |  |  | 8 |  |
| Pointing Devices |  | 241,160 |  |  | 217,045 |  |  | 11 |  |  | 658,034 |  |  | 602,927 |  |  | 9 |  |
| Video Collaboration |  | 193,252 |  |  | 176,053 |  |  | 10 |  |  | 527,645 |  |  | 482,755 |  |  | 9 |  |
| Webcams |  | 82,268 |  |  | 84,419 |  |  | (3) |  |  | 249,944 |  |  | 237,572 |  |  | 5 |  |
| Tablet Accessories |  | 93,567 |  |  | 77,433 |  |  | 21 |  |  | 269,855 |  |  | 241,586 |  |  | 12 |  |
| Headsets |  | 45,939 |  |  | 45,886 |  |  | — |  |  | 134,959 |  |  | 137,038 |  |  | (2) |  |
| Other (2) |  | 27,967 |  |  | 35,995 |  |  | (22) |  |  | 79,933 |  |  | 103,990 |  |  | (23) |  |
| Total Sales |  | $ | 1,421,479 |  |  | $ | 1,340,294 |  |  | 6 | % |  | $ | 3,755,238 |  |  | $ | 3,544,545 |  |  | 6 | % |

[0001032975-26-000011:mdna:75]
[same as prior period, unchanged from 0001032975-25-000080:mdna:74]

[0001032975-26-000011:mdna:76]
[same as prior period, unchanged from 0001032975-25-000080:mdna:75]

[0001032975-26-000011:mdna:77]
[same as prior period, unchanged from 0001032975-25-000080:mdna:76]

[0001032975-26-000011:mdna:78]
[same as prior period, unchanged from 0001032975-25-000080:mdna:77]

[0001032975-26-000011:mdna:79]
Sales of Gaming increased 3% for the three months ended December 31, 2025, compared to the three months ended December 31, 2024, primarily driven by an increase in sales of gaming mice and steering wheels, partially offset by decreases in other gaming products. Sales of Gaming increased 4% for the nine months ended December 31, 2025, compared to the nine months ended December 31, 2024, primarily driven by an increase in sales of gaming mice, partially offset by decreases in PC gaming headsets and console gaming headsets.

[0001032975-26-000011:mdna:80]
[same as prior period, unchanged from 0001032975-25-000080:mdna:79]

[0001032975-26-000011:mdna:81]
[same as prior period, unchanged from 0001032975-25-000080:mdna:80]

[0001032975-26-000011:mdna:82]
Sales of Keyboards & Combos increased 8% for each of the three and nine months ended December 31, 2025, compared to the three and nine months ended December 31, 2024, primarily driven by an increase in sales of cordless combo products and cordless keyboards.

[0001032975-26-000011:mdna:83]
[same as prior period, unchanged from 0001032975-25-000080:mdna:82]

[0001032975-26-000011:mdna:84]
[same as prior period, unchanged from 0001032975-25-000080:mdna:83]

[0001032975-26-000011:mdna:85]
Sales of Pointing Devices increased 11% and 9% for the three and nine months ended December 31, 2025, compared to the three and nine months ended December 31, 2024, respectively, primarily driven by an increase in sales of cordless mice.

[0001032975-26-000011:mdna:86]
[same as prior period, unchanged from 0001032975-25-000080:mdna:85]

[0001032975-26-000011:mdna:87]
[same as prior period, unchanged from 0001032975-25-000080:mdna:86]

[0001032975-26-000011:mdna:88]
Sales of Video Collaboration increased 10% and 9% for the three and nine months ended December 31, 2025, compared to the three and nine months ended December 31, 2024, respectively, primarily due to an increase in sales of conference room cameras.

[0001032975-26-000011:mdna:89]
[same as prior period, unchanged from 0001032975-25-000080:mdna:88]

[0001032975-26-000011:mdna:90]
[same as prior period, unchanged from 0001032975-25-000080:mdna:89]

[0001032975-26-000011:mdna:91]
Sales of Webcams decreased 3% for the three months ended December 31, 2025, compared to the three months ended December 31, 2024, primarily due to decreases in sales of our VC webcams and streaming cameras, partially offset by an increase in sales of our PC-based webcams. Sales of Webcams increased 5% for the nine months ended December 31, 2025, compared to the nine months ended December 31, 2024, primarily driven by an increase in sales of our PC-based webcams, partially offset by a decrease in sales of our VC webcams and streaming cameras.

[0001032975-26-000011:mdna:92]
[same as prior period, unchanged from 0001032975-25-000080:mdna:91]

[0001032975-26-000011:mdna:93]
[same as prior period, unchanged from 0001032975-25-000080:mdna:92]

[0001032975-26-000011:mdna:94]
Sales of Tablet Accessories increased 21% and 12% for the three and nine months ended December 31, 2025, compared to the three and nine months ended December 31, 2024, respectively, primarily benefiting from strong demand from the education sector.

[0001032975-26-000011:mdna:95]
[same as prior period, unchanged from 0001032975-25-000080:mdna:94]

[0001032975-26-000011:mdna:96]
[same as prior period, unchanged from 0001032975-25-000080:mdna:95]

[0001032975-26-000011:mdna:97]
Sales of Headsets remained relatively flat for the three and nine months ended December 31, 2025, compared to the three and nine months ended December 31, 2024.

[0001032975-26-000011:mdna:98]
[same as prior period, unchanged from 0001032975-25-000080:mdna:97]

[0001032975-26-000011:mdna:99]
[same as prior period, unchanged from 0001032975-25-000080:mdna:98]

[0001032975-26-000011:mdna:100]
Sales in Other category decreased 22% and 23% for the three and nine months ended December 31, 2025, respectively, compared to the three and nine months ended December 31, 2024, primarily driven by a decline in sales of mobile speakers.

[0001032975-26-000011:mdna:101]
[same as prior period, unchanged from 0001032975-25-000080:mdna:100]

[0001032975-26-000011:mdna:102]
Gross profit for the three and nine months ended December 31, 2025 and 2024 was as follows (Dollars in thousands):

[0001032975-26-000011:mdna:103]
|  |  | Three Months Ended December 31, |  | Nine Months Ended December 31, |
|  |  | 2025 |  | 2024 |  | Change |  | 2025 |  | 2024 |  | Change |
| Net sales |  | $ | 1,421,479 |  | $ | 1,340,294 |  | 6 | % |  | $ | 3,755,238 |  | $ | 3,544,545 |  | 6 | % |
| Gross profit |  | $ | 614,639 |  | $ | 574,441 |  | 7 | % |  | $ | 1,608,057 |  | $ | 1,526,790 |  | 5 | % |
| Gross margin |  | 43.2 | % |  | 42.9 | % |  |  |  | 42.8 | % |  | 43.1 | % |  |  |

[0001032975-26-000011:mdna:104]
[same as prior period, unchanged from 0001032975-25-000080:mdna:103]

[0001032975-26-000011:mdna:105]
Gross margin was 43.2% for the three months ended December 31, 2025 and increased by 30 basis points from 42.9% for the three months ended December 31, 2024. Gross margin was 42.8% for the nine months ended December 31, 2025 and decreased by 30 basis points from 43.1% for the nine months ended December 31, 2024. The increase in gross margin for the three-month period was primarily driven by product cost reductions, price increases in North America, and favorable foreign currency exchange rate changes, partially offset by investment in strategic promotions and increased tariffs. Gross margin decreased during the nine-month period due to investment

[0001032975-26-000011:mdna:106]
in strategic promotions and increased tariffs, partially offset by product cost reductions and price increases in North America.

[0001032975-26-000011:mdna:107]
[same as prior period, unchanged from 0001032975-25-000080:mdna:105]

[0001032975-26-000011:mdna:108]
Operating expenses for the three and nine months ended December 31, 2025 and 2024 were as follows (Dollars in thousands):

[0001032975-26-000011:mdna:109]
|  |  | Three Months Ended December 31, |  | Nine Months Ended December 31, |  |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |  |
| Marketing and selling |  | $ | 206,875 |  |  | $ | 217,048 |  |  | $ | 601,664 |  |  | $ | 615,816 |  |  |
| % of sales |  | 14.6 | % |  | 16.2 | % |  | 16.0 | % |  | 17.4 | % |  |
| Research and development |  | 78,452 |  |  | 77,973 |  |  | 229,149 |  |  | 229,485 |  |  |
| % of sales |  | 5.5 | % |  | 5.8 | % |  | 6.1 | % |  | 6.5 | % |  |
| General and administrative |  | 41,921 |  |  | 42,117 |  |  | 125,520 |  |  | 123,748 |  |  |
| % of sales |  | 2.9 | % |  | 3.2 | % |  | 3.4 | % |  | 3.5 | % |  |
| Amortization of intangible assets and acquisition-related costs |  | 915 |  |  | 2,637 |  |  | 5,379 |  |  | 8,065 |  |  |
| % of sales |  | 0.1 | % |  | 0.2 | % |  | 0.1 | % |  | 0.2 | % |  |
| Restructuring charges, net |  | 462 |  |  | 110 |  |  | 6,946 |  |  | 725 |  |  |
| % of sales |  | — | % |  | — | % |  | 0.2 | % |  | — | % |  |
| Total operating expenses |  | $ | 328,625 |  |  | $ | 339,885 |  |  | $ | 968,658 |  |  | $ | 977,839 |  |  |
| % of sales |  | 23.1 | % |  | 25.4 | % |  | 25.8 | % |  | 27.6 | % |  |

[0001032975-26-000011:mdna:110]
The decrease in total operating expenses during the three and nine months ended December 31, 2025, compared to the three and nine months ended December 31, 2024, was primarily driven by a decrease in marketing and selling expenses.

[0001032975-26-000011:mdna:111]
[same as prior period, unchanged from 0001032975-25-000080:mdna:109]

[0001032975-26-000011:mdna:112]
[same as prior period, unchanged from 0001032975-25-000080:mdna:110]

[0001032975-26-000011:mdna:113]
During the three and nine months ended December 31, 2025, marketing and selling expenses decreased $10.2 million and $14.2 million, compared to the three and nine months ended December 31, 2024, respectively, primarily due to a provision for credit loss on accounts receivable recorded in the third quarter of fiscal year 2025. The decrease in marketing and selling expenses for the three-month period was partially offset by an increase in third party marketing and advertising spend.

[0001032975-26-000011:mdna:114]
[same as prior period, unchanged from 0001032975-25-000080:mdna:112]

[0001032975-26-000011:mdna:115]
Research and development expenses consist of personnel and related overhead costs, fees for contractors and outside consultants, supplies and materials, equipment depreciation and facilities costs, all associated with the design and development of new products and enhancements of existing products.

[0001032975-26-000011:mdna:116]
During the three and nine months ended December 31, 2025, research and development expenses remained relatively flat, as we continued to invest in innovation at a similar level as compared to the three and nine months ended December 31, 2024, respectively.

[0001032975-26-000011:mdna:117]
[same as prior period, unchanged from 0001032975-25-000080:mdna:115]

[0001032975-26-000011:mdna:118]
General and administrative expenses primarily consist of personnel and related overhead costs, information technology, and facilities costs for the infrastructure functions such as finance, information systems, executives, human resources and legal.

[0001032975-26-000011:mdna:119]
During the three months ended December 31, 2025, general and administrative expenses remained flat, compared to the three months ended December 31, 2024. During the nine months ended December 31, 2025, general and administrative expenses increased $1.8 million, compared to the nine months ended December 31, 2024, primarily driven by higher variable compensation expense, partially offset by lower third-party spend.

[0001032975-26-000011:mdna:120]
[same as prior period, unchanged from 0001032975-25-000080:mdna:118]

[0001032975-26-000011:mdna:121]
Amortization of intangible assets consists of amortization of acquired intangible assets, including developed technology, customer relationships, and trademarks and trade names. Acquisition-related costs include legal expenses, due diligence costs, and other professional costs incurred for business acquisitions.

[0001032975-26-000011:mdna:122]
During the three and nine months ended December 31, 2025, amortization of intangible assets and acquisition-related costs decreased $1.7 million and $2.7 million, respectively, compared to the three and nine months ended December 31, 2024, driven by full amortization of certain intangible assets.

[0001032975-26-000011:mdna:123]
[same as prior period, unchanged from 0001032975-25-000080:mdna:121]

[0001032975-26-000011:mdna:124]
The restructuring charges, net, for the three and nine months ended December 31, 2025 were related to costs incurred as a result of our restructuring plan initiated during the fourth quarter of fiscal year 2025, which is expected to be substantially completed in fiscal 2026. The restructuring charges, net, for the three and nine months ended December 31, 2024, were related to costs incurred as a result of our restructuring plan initiated during fiscal year 2023, which was substantially completed during fiscal year 2024.

[0001032975-26-000011:mdna:125]
[same as prior period, unchanged from 0001032975-25-000080:mdna:123]

[0001032975-26-000011:mdna:126]
Interest income for the three and nine months ended December 31, 2025 and 2024 was as follows (in thousands):

[0001032975-26-000011:mdna:127]
|  |  | Three Months Ended December 31, |  | Nine Months Ended December 31, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Interest income |  | $ | 10,985 |  |  | $ | 12,176 |  |  | $ | 34,042 |  |  | $ | 42,603 |  |

[0001032975-26-000011:mdna:128]
We invest in highly liquid instruments with an original maturity of three months or less at the date of purchase, which are classified as cash equivalents. During the three and nine months ended December 31, 2025, interest income decreased $1.2 million and $8.6 million, respectively, compared to the three and nine months ended December 31, 2024, primarily driven by a decrease in interest rates, partially offset by an increase in the cash equivalents balance.

[0001032975-26-000011:mdna:129]
[same as prior period, unchanged from 0001032975-25-000080:mdna:127]

[0001032975-26-000011:mdna:130]
Other income (expense), net, for the three and nine months ended December 31, 2025 and 2024 was as follows (in thousands):

[0001032975-26-000011:mdna:131]
|  |  | Three Months Ended December 31, |  | Nine Months Ended December 31, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Investment gain related to the deferred compensation plan |  | $ | 583 |  |  | $ | 571 |  |  | $ | 4,533 |  |  | $ | 2,631 |  |
| Currency exchange gain (loss), net |  | 102 |  |  | (3,282) |  |  | (5,011) |  |  | (7,073) |  |
| Gain (loss) on investments, net |  | 206 |  |  | (119) |  |  | (291) |  |  | (1,718) |  |
| Non-service cost net pension income and other |  | 1,240 |  |  | 1,306 |  |  | 3,998 |  |  | 3,271 |  |
| Total |  | $ | 2,131 |  |  | $ | (1,524) |  |  | $ | 3,229 |  |  | $ | (2,889) |  |

[0001032975-26-000011:mdna:132]
Investment gain related to the deferred compensation plan represents earnings, gains, and losses on marketable securities related to a deferred compensation plan offered by one of our subsidiaries. The increase in investment gain for three and nine months ended December 31, 2025, compared to the three and nine months ended December 31, 2024, primarily relates to the change in market performance of the underlying securities.

[0001032975-26-000011:mdna:133]
Currency exchange gain (loss), net, relates to balances denominated in currencies other than the functional currency in our subsidiaries, as well as the sale of currencies, and gains or losses recognized on currency exchange forward contracts. We do not speculate in currency positions, but we are alert to opportunities to maximize currency exchange gains and minimize currency exchange losses. The gain for the three months ended December 31, 2025 was not material and the loss for the nine months ended December 31, 2025 was primarily due to fluctuations in currency exchange rates of the Swiss Franc and New Taiwan dollar against the U.S. Dollar. The loss for the three months ended December 31, 2024 was primarily due to fluctuations in the currency exchange rates of the Australian Dollar, Japanese Yen, and Brazilian Real against the U.S. Dollar. The loss for the nine months ended December 31, 2024 was primarily due to fluctuations in currency exchange rates of the Chinese Renminbi, Mexican Peso, and Brazilian Real against the U.S. Dollar.

[0001032975-26-000011:mdna:134]
Gain (loss) on investments, net, includes the unrealized gain (loss) from the change in fair value of investments, income (loss) on equity-method investments and impairment of investments during the periods presented, as applicable. The gain (loss) on investments, net, for the three and nine months ended December 31, 2025 and 2024 were not material.

[0001032975-26-000011:mdna:135]
[same as prior period, unchanged from 0001032975-25-000080:mdna:134]

[0001032975-26-000011:mdna:136]
The provision for income taxes and effective income tax rates for the three and nine months ended December 31, 2025 and 2024 were as follows (Dollars in thousands):

[0001032975-26-000011:mdna:137]
|  |  | Three Months Ended December 31, |  | Nine Months Ended December 31, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Provision for income taxes |  | $ | 48,091 |  |  | $ | 45,061 |  |  | $ | 108,946 |  |  | $ | 101,202 |  |
| Effective income tax rate |  | 16.1 | % |  | 18.4 | % |  | 16.1 | % |  | 17.2 | % |

[0001032975-26-000011:mdna:138]
The change in the effective income tax rate for the three and nine months ended December 31, 2025, compared with the three and nine months ended December 31, 2024, was primarily due to the change in the mix of income and losses in the various tax jurisdictions in which we operate and favorable return to provision adjustments.

[0001032975-26-000011:mdna:139]
[same as prior period, unchanged from 0001032975-25-000080:mdna:138]

[0001032975-26-000011:mdna:140]
For the three months ended December 31, 2025, we assessed our exposure to the OECD Pillar Two global minimum tax rules. We have determined that, for the fiscal year 2026, most jurisdictions in which we operate should qualify for the transitional Country-by-Country Reporting ("CbCR") safe harbor, as outlined in the OECD Administrative Guidance and enacted domestic legislation. Our CbCR has been prepared in accordance with the requirements for a Qualified CbCR, using qualified financial statements. Based on this data, most jurisdictions continue to meet safe harbor qualifications at 16% tax rates, and therefore, we are only required to perform a detailed Pillar Two top-up tax calculation for limited jurisdictions. The estimated top up tax for fiscal year 2026 is not material and has been included in the calculation of our annual effective tax rate.

[0001032975-26-000011:mdna:141]
On January 5, 2026, the OECD released an Administrative Guidance package. This package includes a “Side-by-Side” System designed to align the U.S. tax regime with Pillar Two for U.S.-parented multinational groups, effective for tax years beginning on or after January 1, 2026. As we are a non-U.S. headquartered multinational, the “Side-by-Side” System itself does not apply to our tax profile. However, the broader guidance package also introduces a new permanent safe harbor (to replace the transitional CbCR safe harbor for fiscal years beginning in 2027) and a one-year extension of the transitional CbCR safe harbor that may potentially impact our Pillar Two compliance and reporting. We continue to monitor these developments but do not expect a material change to our Pillar Two liability.

[0001032975-26-000011:mdna:142]
[same as prior period, unchanged from 0001032975-25-000080:mdna:140]

[0001032975-26-000011:mdna:143]
[same as prior period, unchanged from 0001032975-25-000080:mdna:141]

[0001032975-26-000011:mdna:144]
As of December 31, 2025, we had cash and cash equivalents of $1,817.8 million, compared with $1,503.2 million as of March 31, 2025. Our cash and cash equivalents consist of bank demand deposits, short-term time deposits, and U.S. Treasury securities, of which 50% was held in the United States, 34% was held in Switzerland and 10% was held in China (including Hong Kong). We do not expect to incur any material adverse tax impact except for what has already been recognized, or to be significantly inhibited by any country in which we do business, from the repatriation of funds to Switzerland, our country of domicile.

[0001032975-26-000011:mdna:145]
As of December 31, 2025, our working capital was $1,709.1 million, compared to $1,491.6 million as of March 31, 2025. The increase was primarily driven by an increase in cash and cash equivalents and accounts receivable, partially offset by an increase in accounts payable and accrued and other current liabilities and a decrease in inventories.

[0001032975-26-000011:mdna:146]
On January 27, 2025, we entered into an unsecured revolving credit facility with a syndicate of banks (the "Credit Agreement"). The Credit Agreement provides a revolving line of credit of up to $750.0 million including the issuance of letters of credit of up to $100.0 million. The Credit Agreement terminates on January 27, 2030 unless extended in accordance with its terms. The Credit Agreement contains (1) an increase option allowing us to secure up to $250.0 million of additional commitments and (2) an extension option to extend the term by one-year which may be exercised no more than two times, subject to certain requirements. Loans under the Credit Agreement are available in U.S. Dollars, Euro, Sterling, Yen, Swiss Francs, Canadian Dollars, Australian Dollars and any other currency agreed to by each lender. Proceeds of loans made under the Credit Agreement may be used for general corporate purposes.

[0001032975-26-000011:mdna:147]
The Credit Agreement contains a maximum net debt to adjusted EBITDA ratio, compliance with which is a condition to our ability to borrow. Borrowings under the Credit Agreement will bear interest at a rate determined by reference to benchmark rates plus an applicable spread (ranging from 0% to 1.5%) based on our net leverage ratio or credit rating at the time of the borrowing. Undrawn balances available under the Credit Agreement are subject to commitment fees at the applicable rate determined by reference to our net leverage ratio or credit rating. There has been no borrowing outstanding under the Credit Agreement as of December 31, 2025.

[0001032975-26-000011:mdna:148]
In addition, we had several uncommitted, unsecured bank lines of credit and letters of credit aggregating to $164.0 million as of December 31, 2025. There are no financial covenants under these lines of credit with which we must comply. There was no borrowing outstanding under these lines of credit as of December 31, 2025. As of December 31, 2025, we had outstanding bank guarantees of $8.5 million.

[0001032975-26-000011:mdna:149]
The following tables present selected financial information and statistics as of and for the three months ended December 31, 2025 and 2024 (Dollars in thousands):

[0001032975-26-000011:mdna:150]
|  |  | As of December 31, |  |
|  |  | 2025 |  | 2024 |  |
| Accounts receivable, net |  | $ | 683,126 |  |  | $ | 648,230 |  |  |
| Accounts payable |  | $ | 590,421 |  |  | $ | 578,951 |  |  |
| Inventories |  | $ | 449,544 |  |  | $ | 483,569 |  |  |

[0001032975-26-000011:mdna:151]
|  |  | Three Months Ended December 31, |  |
|  |  | 2025 |  | 2024 |  |
| Days sales in accounts receivable (“DSO”) (Days)(1) |  | 43 |  |  | 44 |  |  |
| Days accounts payable outstanding (“DPO”) (Days)(2) |  | 66 |  |  | 68 |  |  |
| Inventory turnover (“ITO”) (x)(3) |  | 7.2 |  |  | 6.3 |  |  |

[0001032975-26-000011:mdna:152]
[same as prior period, unchanged from 0001032975-25-000080:mdna:150]

[0001032975-26-000011:mdna:153]
[same as prior period, unchanged from 0001032975-25-000080:mdna:151]

[0001032975-26-000011:mdna:154]
[same as prior period, unchanged from 0001032975-25-000080:mdna:152]

[0001032975-26-000011:mdna:155]
DSO for the three months ended December 31, 2025 decreased by 1 day to 43 days, compared to 44 days for the three months ended December 31, 2024, primarily due to timing of sales and collections within the quarter.

[0001032975-26-000011:mdna:156]
DPO for the three months ended December 31, 2025 decreased by 2 days to 66 days, compared to 68 days for the three months ended December 31, 2024, primarily due to improved demand and strong inventory management.

[0001032975-26-000011:mdna:157]
ITO for the three months ended December 31, 2025 increased by 0.9 to 7.2, compared to 6.3 for the three months ended December 31, 2024, due to improved demand and lower ending inventories.

[0001032975-26-000011:mdna:158]
[same as prior period, unchanged from 0001032975-25-000080:mdna:156]

[0001032975-26-000011:mdna:159]
[same as prior period, unchanged from 0001032975-25-000080:mdna:157]

[0001032975-26-000011:mdna:160]
|  |  | Nine Months Ended December 31, |
|  |  | 2025 |  | 2024 |
| Net cash provided by operating activities |  | $ | 834,414 |  |  | $ | 712,901 |  |
| Net cash used in investing activities |  | (48,758) |  |  | (45,357) |  |
| Net cash used in financing activities |  | (483,673) |  |  | (676,099) |  |
| Effect of exchange rate changes on cash and cash equivalents |  | 12,632 |  |  | (9,455) |  |
| Net increase (decrease) in cash and cash equivalents |  | $ | 314,615 |  |  | $ | (18,010) |  |

[0001032975-26-000011:mdna:161]
For the nine months ended December 31, 2025, net cash provided by operating activities was $834.4 million resulting from net income of $567.7 million, a favorable impact from adding back non-cash expenses totaling $152.1 million and a favorable net change in operating assets and liabilities of $114.6 million. Non-cash adjustments were primarily related to share-based compensation expenses, depreciation and amortization, and deferred income taxes. The increase in accounts receivable, net, was primarily driven by higher sales as well as timing of sales within the quarter. The increase in accounts payable was driven by higher inventory purchases to align with demand, as well as the timing of purchases during the quarter.

[0001032975-26-000011:mdna:162]
For the nine months ended December 31, 2025, net cash used in investing activities was $48.8 million, primarily resulting from $47.7 million of purchases of property, plant, and equipment.

[0001032975-26-000011:mdna:163]
For the nine months ended December 31, 2025, net cash used in financing activities was $483.7 million, primarily resulting from payment for repurchases of our registered shares of $255.4 million and payment of cash dividends of $233.1 million.

[0001032975-26-000011:mdna:164]
For the nine months ended December 31, 2025, the effect of exchange rate changes on cash and cash equivalents was primarily driven by the exchange rate fluctuations of the Swiss Franc, Chinese Renminbi, and Euro versus the U.S. Dollar.

[0001032975-26-000011:mdna:165]
[same as prior period, unchanged from 0001032975-25-000080:mdna:163]

[0001032975-26-000011:mdna:166]
[same as prior period, unchanged from 0001032975-25-000080:mdna:164]

[0001032975-26-000011:mdna:167]
[same as prior period, unchanged from 0001032975-25-000080:mdna:165]

[0001032975-26-000011:mdna:168]
In June 2023, our Board of Directors approved a three-year share repurchase program, which allows us to use up to $1.0 billion to repurchase our shares. The 2023 share repurchase program enables us to repurchase shares for cancellation, as well as to support equity incentive plans or potential acquisitions. The Swiss Takeover Board approved the 2023 share repurchase program in July 2023 and the program became effective on July 28, 2023. In March 2025, our Board of Directors approved an increase of $600.0 million to the 2023 share repurchase program, to an aggregate amount of $1.6 billion. The Swiss Takeover Board approved this increase in April 2025 and it became effective on April 2, 2025. During the nine months ended December 31, 2025, we repurchased 2.7 million shares for an aggregate cost of $239.1 million for cancellation under this share repurchase program, of which $2.4 million of the aggregate cost was not paid yet as of December 31, 2025. As of December 31, 2025, $409.5 million was available for repurchase under the 2023 share repurchase program. We plan to target share repurchases of $2 billion over the three-year period ending March 31, 2028, subject to market conditions and regulatory approvals.

[0001032975-26-000011:mdna:169]
Swiss law limits a company’s ability to hold or repurchase its own shares. The aggregate par value of all shares held in treasury by us and our subsidiaries may not exceed 10% of our issued share capital, which corresponds to approximately 16.1 million registered shares as of December 31, 2025. This limitation does not apply to shares repurchased for cancellation, due to the Board of Directors' authority under the capital band set forth in the Company's Articles of Incorporation. As of December 31, 2025, we had a total of 14.0 million shares held in treasury stock, which includes 1.1 million shares that have been repurchased for cancellation and 12.9 million shares that have been purchased to support equity incentive plans or potential acquisitions.

[0001032975-26-000011:mdna:170]
Although we enter into trading plans for systematic repurchases (e.g., 10b5-1 trading plans) from time to time, our 2023 share repurchase program provides us with the opportunity to make opportunistic repurchases during periods of favorable market conditions and is expected to remain in effect for a period of three years through July 27, 2026. To the extent that the shares are repurchased to support equity incentive plans or potential acquisitions, the shares are repurchased on the ordinary trading line of the Swiss Exchange ("SIX") and/or the Nasdaq Global Select Market ("Nasdaq"). Shares repurchased for cancellation purposes are repurchased via a second trading line on the SIX. Opportunistic purchases may be started or stopped at any time without prior notice depending on market conditions and other factors.

[0001032975-26-000011:mdna:171]
[same as prior period, unchanged from 0001032975-25-000080:mdna:170]

[0001032975-26-000011:mdna:172]
[same as prior period, unchanged from 0001032975-25-000080:mdna:171]

[0001032975-26-000011:mdna:173]
[same as prior period, unchanged from 0001032975-25-000080:mdna:172]

[0001032975-26-000011:mdna:174]
[same as prior period, unchanged from 0001032975-25-000080:mdna:173]

[0001032975-26-000011:mdna:175]
As of December 31, 2025, we had non-cancelable purchase commitments of $434.7 million for inventory purchases made in the normal course of business from original design manufacturers, contract manufacturers and other suppliers, the majority of which are expected to be fulfilled within the next 12 months. We recorded a liability for firm, non-cancelable, and unhedged inventory purchase commitments in excess of anticipated demand or net realizable value consistent with our valuation of excess and obsolete inventory. As of December 31, 2025, the liability for these purchase commitments was $22.5 million and is recorded in accrued and other current liabilities in the condensed consolidated balance sheet.

[0001032975-26-000011:mdna:176]
As of December 31, 2025, we have firm purchase commitments of $20.9 million for capital expenditures primarily related to commitments for tooling and equipment for new and existing products. We expect to continue making capital expenditures in the future to support product development activities and ongoing and expanded operations. Although open purchase commitments are considered enforceable and legally binding, the terms generally allow us to reschedule or adjust our requirements based on business needs prior to delivery of goods or performance of services.

[0001032975-26-000011:mdna:177]
[same as prior period, unchanged from 0001032975-25-000080:mdna:176]

[0001032975-26-000011:mdna:178]
[same as prior period, unchanged from 0001032975-25-000080:mdna:177]

[0001032975-26-000011:mdna:179]
[same as prior period, unchanged from 0001032975-25-000080:mdna:178]

[0001032975-26-000011:mdna:180]
We indemnify certain suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of December 31, 2025, no material amounts have been accrued for indemnification provisions. We do not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under our indemnification arrangements.

[0001032975-26-000011:mdna:181]
[same as prior period, unchanged from 0001032975-25-000080:mdna:180]

[0001032975-26-000011:mdna:182]
Legal Proceedings

[0001032975-26-000011:mdna:183]
From time to time, we are involved in claims and legal proceedings that arise in the ordinary course of our business. For more information about Legal Proceedings, see Part II Item 1 Legal Proceedings of this quarterly report on Form 10-Q for the period ended December 31, 2025.
