# LOGI MD&A — 0001032975-22-000034


## mdna

[0001032975-22-000034:mdna:1]
[same as prior period, unchanged from 0001032975-22-000006:mdna:1]

[0001032975-22-000034:mdna:2]
•Our strategy for growth, future revenues, earnings, cash flow, uses of cash and other measures of financial performance, and market position;

[0001032975-22-000034:mdna:3]
•Our business strategy and investment priorities in relation to competitive offerings and evolving consumer demand trends affecting our products and markets, worldwide economic and capital market conditions, fluctuations in currency exchange rates, and current and future general regional economic conditions for fiscal year 2023 and beyond;

[0001032975-22-000034:mdna:4]
•The scope, nature or impact of acquisition, strategic alliance, and divestiture activities and restructuring of our organizational structure;

[0001032975-22-000034:mdna:5]
•Our expectations regarding the success of our strategic acquisitions, including integration of acquired operations, products, technology, internal controls, personnel and management teams;

[0001032975-22-000034:mdna:6]
•Our expectations regarding our effective tax rate, future tax benefits, tax settlements, the adequacy of our provisions for uncertain tax positions;

[0001032975-22-000034:mdna:7]
•Our expectations regarding our potential indemnification obligations, and the outcome of pending or future legal proceedings and tax audits;

[0001032975-22-000034:mdna:8]
•Our business and product plans and development and product innovation and their impact on future operating results and anticipated operating costs for fiscal year 2023 and beyond;

[0001032975-22-000034:mdna:9]
•Opportunities for growth and our ability to execute on and take advantage of them, market opportunities, and marking initiatives and strategy and our expectations regarding the success thereof;

[0001032975-22-000034:mdna:10]
•Potential tariffs, their effects and our ability to mitigate their effects;

[0001032975-22-000034:mdna:11]
•Capital investments and research and development;

[0001032975-22-000034:mdna:12]
•Our expectations regarding our share repurchase and dividend programs;

[0001032975-22-000034:mdna:13]
•The sufficiency of our cash and cash equivalents, cash generated from operations, and available borrowings under our bank lines of credit to fund capital expenditures and working capital needs;

[0001032975-22-000034:mdna:14]
•The effects of environmental and other laws and regulations in the United States and other countries in which we operate; and

[0001032975-22-000034:mdna:15]
•The impact of global and regional events, such as the coronavirus ("COVID-19") pandemic, inflation and the war in Ukraine, and any associated economic downturn and impacts to our business and future operating and financial performance.

[0001032975-22-000034:mdna:16]
[same as prior period, unchanged from 0001032975-22-000006:mdna:2]

[0001032975-22-000034:mdna:17]
[same as prior period, unchanged from 0001032975-22-000006:mdna:3]

[0001032975-22-000034:mdna:18]
Logitech is a world leader in designing, manufacturing and marketing products that help connect people to digital and cloud experiences. Forty years ago, Logitech created products to improve experiences around the

[0001032975-22-000034:mdna:19]
personal computer ("PC") platform, and today it is a multi-brand, multi-category company designing products that enable people to pursue their passions and connect to the world. Logitech’s products align with several large secular trends including work and learn from anywhere, video everywhere, the increasing popularity of gaming as a spectator and participant sport, and the democratization of content creation. Logitech's brands include Logitech, Logitech G, ASTRO Gaming, Streamlabs, Blue Microphones, and Ultimate Ears. Our Company's website is www.logitech.com.

[0001032975-22-000034:mdna:20]
Our products participate primarily in four large market opportunities: Creativity & Productivity, Gaming, Video Collaboration and Music. We sell our products to a broad network of domestic and international customers, including direct sales to retailers, e-tailers and enterprise customers and indirect sales through distributors. Our worldwide channel network includes consumer electronics distributors, retailers, e-tailers, mass merchandisers, specialty stores, computer and telecommunications stores, value-added resellers and online merchants. We primarily sell our services directly to end customers.

[0001032975-22-000034:mdna:21]
[same as prior period, unchanged from 0001032975-22-000006:mdna:7]

[0001032975-22-000034:mdna:22]
Impacts of Macroeconomic and Geopolitical Conditions on our Business

[0001032975-22-000034:mdna:23]
During the first quarter of fiscal year 2023, we were impacted by adverse macroeconomic and geopolitical

[0001032975-22-000034:mdna:24]
conditions. These conditions include but are not limited to inflation, foreign currency fluctuations, and lower consumer spending. We also continue to be affected by supply chain challenges, and the war in Ukraine has further increased existing global supply chain, logistics, and inflationary challenges. Such global or regional economic and political conditions adversely affect demand for our products. These conditions also have an impact on our suppliers, contract manufacturers, logistics providers, and distributors, causing increases in cost of materials and higher shipping and transportation rates, and as a result impacting the pricing of our products. Price increases may not successfully offset cost increases or may cause us to lose market share and in turn adversely impact our results of operations.

[0001032975-22-000034:mdna:25]
For additional information, see Part II item 1A "Risk Factors," including under the caption "Adverse global and regional economic and geopolitical conditions can materially adversely affect our business, results of operations and financial condition," “We purchase key components and products from a limited number of sources, and our business and operating results could be adversely affected if supply were delayed or constrained or if there were shortages of required components,” “Our principal manufacturing operations and third-party contract manufacturers are located in China and Southeast Asia, which exposes us to risks associated with doing business in that geographic area as well as potential tariffs, adverse tax consequences and pressure to move or diversify our manufacturing locations” and “If we do not accurately forecast market demand for our products, our business and operating results could be adversely affected.”

[0001032975-22-000034:mdna:26]
Impacts of COVID-19 on Our Business

[0001032975-22-000034:mdna:27]
In March 2020, the World Health Organization declared the outbreak of COVID-19 as a pandemic, which continues to spread throughout the world.

[0001032975-22-000034:mdna:28]
The COVID-19 pandemic has resulted in, and could continue to result in, industry-wide global supply chain challenges, including manufacturing, transportation and logistics. We purchase certain products and key components from a limited number of sources, and depend on the supply chain, including freight, to receive components, transport finished goods and deliver our products across the world. While we proactively manage our supply chain, we expect to continue to be impacted by higher logistics and component costs, prolonged delays, and challenges with component availability. Most recently, Shanghai, China, experienced a two-month lockdown beginning in late March 2022 due to another outbreak of COVID-19, resulting in a lockdown of the city, closures of ports and airports, and disruption of commercial activities, further constraining our supply chain. If additional lockdowns or similar measures are instituted in Shanghai or Suzhou, where our manufacturing facility is located, or other places where our suppliers and partners are located, such measures, depending on their duration, could cause additional negative impact on our business and results of operations.

[0001032975-22-000034:mdna:29]
It is still difficult to predict the progression, the duration and all of the effects of COVID-19, how restrictions and shelter-at-home guidelines will continue evolving on a global basis, how consumer demand, supply chain challenges, including inventory and logistical effects and costs, may change over time, and the impact on our future sales and results of operations. The full extent of the impact of the COVID-19 pandemic on our business and our

[0001032975-22-000034:mdna:30]
operational and financial performance remains uncertain and will depend on many factors outside our control. For additional information, see "Liquidity and Capital Resources" below and Item 1A "Risk Factors," including under the caption "The full effect of the COVID-19 pandemic is still uncertain and cannot be predicted, and could adversely affect our business, results of operations and financial condition," "If we do not successfully coordinate the worldwide manufacturing and distribution of our products, we could lose sales” and “We purchase key components and products from a limited number of sources, and our business and operating results could be adversely affected if supply were delayed or constrained or if there were shortages of required components.”

[0001032975-22-000034:mdna:31]
[same as prior period, unchanged from 0001032975-22-000006:mdna:14]

[0001032975-22-000034:mdna:32]
Our total sales for the three months ended June 30, 2022 decreased 12% compared to the same period of the prior fiscal year, driven by decline in sales for most of our product categories, particularly Gaming, PC Webcams and Audio & Wearables.

[0001032975-22-000034:mdna:33]
Sales for the three months ended June 30, 2022 increased 7% in the Asia Pacific region, and decreased 19%, and 18% in the EMEA and Americas regions, respectively, compared to the same period of the prior fiscal year.

[0001032975-22-000034:mdna:34]
Gross margin for the three months ended June 30, 2022 decreased by 380 basis points to 39.6% compared to 43.4% for the same period of the prior fiscal year, primarily due to higher material and logistics costs, unfavorable impacts from changes in currency exchange rates and increased promotional spending.

[0001032975-22-000034:mdna:35]
Operating expenses for the three months ended June 30, 2022 were $344.1 million, or 29.7% of sales, compared to $365.8 million, or 27.9% of sales, in the same period of the prior fiscal year.

[0001032975-22-000034:mdna:36]
Net income for the three months ended June 30, 2022 was $100.8 million compared to the same period of the prior fiscal year of $186.8 million.

[0001032975-22-000034:mdna:37]
[same as prior period, unchanged from 0001032975-22-000006:mdna:20]

[0001032975-22-000034:mdna:38]
Our products participate primarily in four large multi-category market opportunities, including Creativity & Productivity, Gaming, Video Collaboration and Music. The following discussion represents key trends specific to our market opportunities.

[0001032975-22-000034:mdna:39]
Trends Specific to Our Market Opportunities

[0001032975-22-000034:mdna:40]
Creativity & Productivity: In the past few years, mice and keyboard shipments have been strong due to work-from-home, learn-from-home and hybrid work trends as well as increased PC shipments. We believe that innovative PC peripherals, such as our mice and keyboards, can renew the PC usage experience and help improve the productivity and engagement of remote work and learning, thus providing growth opportunities. Hybrid work culture is also greatly expanding the number of new workspaces to which we can attach our PC peripherals. Increasing adoption of various cloud-based applications has led to multiple unique consumer use cases, which we are addressing with our innovative product portfolio and a deep understanding of our customer base. The popularity of streaming coupled with work-from-home trends, provide growth opportunities for our webcam products as well as other products in our portfolio. Smaller mobile computing devices, such as tablets, have created new markets and usage models for peripherals and accessories. We offer a number of products to enhance the use of mobile devices, including a combo backlit keyboard case with trackpad for the iPad.

[0001032975-22-000034:mdna:41]
Gaming: Despite recent declines in the gaming market, PC gaming and console gaming platforms have strong long-term structural growth opportunities driven largely by the popularity of social gaming through online gaming, multi-platform experiences, and esports. We expect gaming will increasingly become one of the largest participant and spectator sports in the world. We believe Logitech is well positioned to benefit from overall gaming market growth. In addition, our acquisition of Streamlabs provides a solid platform to deliver recurring services and subscriptions to gamers and streamers.

[0001032975-22-000034:mdna:42]
Video Collaboration: The long-term structural growth opportunities in the video collaboration market continue to be strong as commercial and consumer adoption of video has seen substantial growth since the start of the COVID-19 pandemic. Video meetings continue to be an opportunity as companies want lower-cost, cloud-based solutions that can provide their employees with the ability to work from anywhere. We are continuing our efforts to create and sell innovative products to accommodate the increasing demand from home offices and small-size meeting rooms, such as huddle rooms, to medium and large-sized meeting rooms. We will continue to invest in the

[0001032975-22-000034:mdna:43]
development of select business-specific products (both hardware and software), targeted product marketing and sales channel development. The digitization of learning and hybrid learning environments have also created demand and growth opportunities in the education market.

[0001032975-22-000034:mdna:44]
Music: Consumers are optimizing their audio experiences on their tablets and smartphones with a variety of music peripherals including wireless mobile speakers and in-ear and other headphones. However, the mobile speaker market has matured and the integration of personal voice assistants has increased competition in the speaker category. In addition, the retail footprint has decreased significantly due to the COVID-19 pandemic. These factors have led to a decline in our Mobile Speakers category sales in the past few years. In the wireless headphone industry, the largest growth in recent years has been in true wireless headphones while traditional wireless headphones have declined significantly. We will continue developing truly wireless audio products as growth in this category of the wireless audio market continues to be strong.

[0001032975-22-000034:mdna:45]
[same as prior period, unchanged from 0001032975-22-000006:mdna:30]

[0001032975-22-000034:mdna:46]
[same as prior period, unchanged from 0001032975-22-000006:mdna:31]

[0001032975-22-000034:mdna:47]
Capitalization and amortization of research and development expenses in the U.S.

[0001032975-22-000034:mdna:48]
Pursuant to the Tax Cuts and Jobs Act of 2017, research and development expenses are required to be capitalized and amortized over five years for U.S. tax purposes if the research and development activities are performed in the United States, effective for tax year beginning after December 31, 2021. Absent a change in legislation, the provision is effective for us beginning in fiscal year 2023 which delays the deductibility of research and development expenses. As a result, cash tax payments in the United States have generally increased beginning in fiscal year 2023 compared to prior years.

[0001032975-22-000034:mdna:49]
Critical Accounting Estimates

[0001032975-22-000034:mdna:50]
The preparation of financial statements and related disclosures in conformity with U.S. GAAP requires us to make assumptions, judgments, and estimates, that affect reported amounts of assets, liabilities, sales and expenses, and the disclosure of contingent assets and liabilities.

[0001032975-22-000034:mdna:51]
We base our assumptions, judgments and estimates on historical experience and various other factors that we believe to be reasonable under the circumstances. Actual results could differ materially from these estimates under different assumptions or conditions. On a regular basis, we evaluate our assumptions, judgments and estimates. We also discuss our critical accounting policies and estimates with the Audit Committee of the Board of Directors.

[0001032975-22-000034:mdna:52]
[same as prior period, unchanged from 0001032975-22-000006:mdna:36]

[0001032975-22-000034:mdna:53]
There have been no material changes in our critical accounting estimates during the three months ended June 30, 2022 compared with the critical accounting estimates disclosed in Management's Discussion and Analysis of Financial Condition and Results of Operations included in our Annual Report on Form 10-K for the fiscal year ended March 31, 2022.

[0001032975-22-000034:mdna:54]
[same as prior period, unchanged from 0001032975-22-000006:mdna:38]

[0001032975-22-000034:mdna:55]
Refer to Note 1 to the condensed consolidated financial statements included in this Quarterly Report on Form 10-Q for recent accounting pronouncements adopted.

[0001032975-22-000034:mdna:56]
Constant Currency

[0001032975-22-000034:mdna:57]
[same as prior period, unchanged from 0001032975-22-000006:mdna:41]

[0001032975-22-000034:mdna:58]
[same as prior period, unchanged from 0001032975-22-000006:mdna:42]

[0001032975-22-000034:mdna:59]
[same as prior period, unchanged from 0001032975-22-000006:mdna:43]

[0001032975-22-000034:mdna:60]
[same as prior period, unchanged from 0001032975-22-000006:mdna:44]

[0001032975-22-000034:mdna:61]
[same as prior period, unchanged from 0001032975-22-000006:mdna:47]

[0001032975-22-000034:mdna:62]
[same as prior period, unchanged from 0001032975-22-000006:mdna:48]

[0001032975-22-000034:mdna:63]
Our sales in the three months ended June 30, 2022, decreased 12% compared to the same period of the prior fiscal year. The decrease in sales for the three month period was primarily driven by a decline in sales for most of our product categories, particularly Gaming, PC Webcams and Audio & Wearables. Our sales for the three month periods were negatively impacted from lower demand, higher promotions and unfavorable changes in currency exchange rates. If currency exchange rates had been constant in the three months ended June 30, 2022 and 2021, our constant dollar sales reduction rate would have been 9% for the three months ended June 30, 2022.

[0001032975-22-000034:mdna:64]
[same as prior period, unchanged from 0001032975-22-000006:mdna:45]

[0001032975-22-000034:mdna:65]
Although our financial results are reported in U.S. Dollars, a portion of our sales was generated in currencies other than the U.S. Dollar, such as the Euro, Chinese Renminbi, Japanese Yen, Australian Dollar, Canadian Dollar, Pound Sterling and New Taiwan Dollar. During the three months ended June 30, 2022, approximately 51% of our sales were denominated in currencies other than the U.S. Dollar.

[0001032975-22-000034:mdna:66]
[same as prior period, unchanged from 0001032975-22-000006:mdna:50]

[0001032975-22-000034:mdna:67]
The following table presents the change in sales by region for the three months ended June 30, 2022, compared with the three months ended June 30, 2021:

[0001032975-22-000034:mdna:68]
|  |  | Sales Growth Rate |  | Constant DollarSales Growth Rate |
| Americas |  | (18) | % |  |  |  | (18) | % |  |  |
| EMEA |  | (19) | % |  |  |  | (12) | % |  |  |
| Asia Pacific |  | 7 | % |  |  |  | 11 | % |  |  |

[0001032975-22-000034:mdna:69]
[same as prior period, unchanged from 0001032975-22-000006:mdna:53]

[0001032975-22-000034:mdna:70]
The decrease in sales in the Americas region for the three month period presented above was primarily driven by a decrease in sales of Gaming, Audio & Wearables and PC Webcams.

[0001032975-22-000034:mdna:71]
[same as prior period, unchanged from 0001032975-22-000006:mdna:55]

[0001032975-22-000034:mdna:72]
The decrease in sales in our EMEA region for the three month period was primarily driven by the decrease in sales of most of the product categories, partially offset by an increase in sales in Video Collaboration.

[0001032975-22-000034:mdna:73]
[same as prior period, unchanged from 0001032975-22-000006:mdna:57]

[0001032975-22-000034:mdna:74]
The increase in sales in our Asia Pacific region for the three month period presented above was primarily driven by an increase in sales of Gaming, partially offset by a decrease in sales in Video Collaboration and PC Webcams.

[0001032975-22-000034:mdna:75]
[same as prior period, unchanged from 0001032975-22-000006:mdna:59]

[0001032975-22-000034:mdna:76]
Sales by product categories for the three months ended June 30, 2022 and 2021 were as follows (Dollars in thousands):

[0001032975-22-000034:mdna:77]
|  |  | Three Months EndedJune 30, |  |  |
|  |  | 2022 |  | 2021 |  | Change |  |  |  |  |  |  |
| Pointing Devices |  | $ | 183,283 |  |  | $ | 182,878 |  |  | — | % |  |  |  |  |  |  |
| Keyboards & Combos |  | 227,720 |  |  | 218,357 |  |  | 4 |  |  |  |  |  |  |  |
| PC Webcams |  | 59,386 |  |  | 109,918 |  |  | (46) |  |  |  |  |  |  |  |
| Tablet & Other Accessories |  | 66,585 |  |  | 79,272 |  |  | (16) |  |  |  |  |  |  |  |
| Gaming (1) |  | 282,806 |  |  | 335,397 |  |  | (16) |  |  |  |  |  |  |  |
| Video Collaboration |  | 246,242 |  |  | 234,885 |  |  | 5 |  |  |  |  |  |  |  |
| Mobile Speakers |  | 22,310 |  |  | 28,484 |  |  | (22) |  |  |  |  |  |  |  |
| Audio & Wearables |  | 69,446 |  |  | 116,607 |  |  | (40) |  |  |  |  |  |  |  |
| Other (2) |  | 2,087 |  |  | 6,260 |  |  | (67) |  |  |  |  |  |  |  |
| Total Sales |  | $ | 1,159,865 |  |  | $ | 1,312,058 |  |  | (12) | % |  |  |  |  |  |  |

[0001032975-22-000034:mdna:78]
[same as prior period, unchanged from 0001032975-22-000006:mdna:62]

[0001032975-22-000034:mdna:79]
(2) Other includes Smart Home.

[0001032975-22-000034:mdna:80]
[same as prior period, unchanged from 0001032975-22-000006:mdna:64]

[0001032975-22-000034:mdna:81]
[same as prior period, unchanged from 0001032975-22-000006:mdna:65]

[0001032975-22-000034:mdna:82]
[same as prior period, unchanged from 0001032975-22-000006:mdna:66]

[0001032975-22-000034:mdna:83]
Pointing Devices sales remained flat for the three months ended June 30, 2022, compared to the same period of the prior fiscal year.

[0001032975-22-000034:mdna:84]
[same as prior period, unchanged from 0001032975-22-000006:mdna:68]

[0001032975-22-000034:mdna:85]
[same as prior period, unchanged from 0001032975-22-000006:mdna:69]

[0001032975-22-000034:mdna:86]
Sales of Keyboards & Combos increased 4% for the three months ended June 30, 2022, compared to the same period of the prior fiscal year, primarily driven by the increase in sales of our cordless PC keyboards.

[0001032975-22-000034:mdna:87]
[same as prior period, unchanged from 0001032975-22-000006:mdna:71]

[0001032975-22-000034:mdna:88]
[same as prior period, unchanged from 0001032975-22-000006:mdna:72]

[0001032975-22-000034:mdna:89]
Sales of PC Webcams decreased 46% for the three months ended June 30, 2022, compared to the same period of the prior fiscal year, primarily driven by the decrease in sales of our HD Pro Webcam C920, 1080p Pro Stream Webcam, Webcam C260 and Streamcam.

[0001032975-22-000034:mdna:90]
[same as prior period, unchanged from 0001032975-22-000006:mdna:75]

[0001032975-22-000034:mdna:91]
[same as prior period, unchanged from 0001032975-22-000006:mdna:76]

[0001032975-22-000034:mdna:92]
Sales of Tablet & Other Accessories products decreased 16% for the three months ended June 30, 2022, compared to the same period of the prior fiscal year, primarily driven by the decrease in sales of most of our products, partially offset by increases in sales of our Rugged Combo 3 Touch and Combo Touch for iPad Air.

[0001032975-22-000034:mdna:93]
[same as prior period, unchanged from 0001032975-22-000006:mdna:78]

[0001032975-22-000034:mdna:94]
[same as prior period, unchanged from 0001032975-22-000006:mdna:79]

[0001032975-22-000034:mdna:95]
[same as prior period, unchanged from 0001032975-22-000006:mdna:80]

[0001032975-22-000034:mdna:96]
Sales of Gaming decreased 16% for the three months ended June 30, 2022, compared to the same period of the prior fiscal year, primarily driven by the decrease in sales our gaming mice, console gaming headsets, and gaming keyboards.

[0001032975-22-000034:mdna:97]
[same as prior period, unchanged from 0001032975-22-000006:mdna:82]

[0001032975-22-000034:mdna:98]
[same as prior period, unchanged from 0001032975-22-000006:mdna:83]

[0001032975-22-000034:mdna:99]
Our Video Collaboration category includes Logitech’s conference room cameras, which combine affordable enterprise-quality audio and high definition 4K video to bring video conferencing to businesses of any size, as well as webcams and headsets that turn any desktop into an instant collaboration space.

[0001032975-22-000034:mdna:100]
Sales of Video Collaboration products increased 5% for the three months ended June 30, 2022, compared to the same period of the prior fiscal year, primarily due to an increase in sales of conference room cameras and headsets, partially offset by a decline in sales of webcams.

[0001032975-22-000034:mdna:101]
[same as prior period, unchanged from 0001032975-22-000006:mdna:86]

[0001032975-22-000034:mdna:102]
[same as prior period, unchanged from 0001032975-22-000006:mdna:87]

[0001032975-22-000034:mdna:103]
[same as prior period, unchanged from 0001032975-22-000006:mdna:88]

[0001032975-22-000034:mdna:104]
Sales of Mobile Speakers decreased 22% for the three months ended June 30, 2022, compared to the same period of the prior fiscal year primarily due to a decrease in sales of most of our Mobile speaker sub-categories, partially offset by an increase in sales of our Hyperboom mobile speakers.

[0001032975-22-000034:mdna:105]
[same as prior period, unchanged from 0001032975-22-000006:mdna:90]

[0001032975-22-000034:mdna:106]
Our Audio & Wearables category comprises PC speakers, PC headsets, in-ear headphones, premium wireless audio wearables and studio-quality Blue Microphones for professionals and consumers.

[0001032975-22-000034:mdna:107]
Sales of Audio & Wearables decreased 40% for the three months ended June 30, 2022, compared to the same period of the prior fiscal year, primarily due to a decrease in sales of our Blue Microphone products and cordless and cordless headsets.

[0001032975-22-000034:mdna:108]
[same as prior period, unchanged from 0001032975-22-000006:mdna:98]

[0001032975-22-000034:mdna:109]
Gross profit for the three months ended June 30, 2022 and 2021 was as follows (Dollars in thousands):

[0001032975-22-000034:mdna:110]
|  |  | Three Months EndedJune 30, |  |  |
|  |  | 2022 |  | 2021 |  | Change |  |  |  |  |  |  |
| Net sales |  | $ | 1,159,865 |  |  | $ | 1,312,058 |  |  | (12) | % |  |  |  |  |  |  |
| Gross profit |  | $ | 459,603 |  |  | $ | 568,926 |  |  | (19) | % |  |  |  |  |  |  |
| Gross margin |  | 39.6 | % |  | 43.4 | % |  |  |  |  |  |  |  |  |

[0001032975-22-000034:mdna:111]
Gross profit consists of sales, less cost of goods sold (which includes materials, direct labor and related overhead costs, costs of manufacturing facilities, royalties, costs of purchasing components from outside suppliers,

[0001032975-22-000034:mdna:112]
distribution costs, warranty costs, customer support costs, shipping and handling costs, outside processing costs and write-down of inventories), and amortization of intangible assets.

[0001032975-22-000034:mdna:113]
Gross margin decreased by 380 basis points to 39.6% for the three months ended June 30, 2022, compared to the same period of the prior fiscal year. Our gross margin declined due to higher material and logistics costs, unfavorable impacts from changes in currency exchange rates, and increased promotional spending.

[0001032975-22-000034:mdna:114]
[same as prior period, unchanged from 0001032975-22-000006:mdna:103]

[0001032975-22-000034:mdna:115]
Operating expenses for the three months ended June 30, 2022 and 2021 were as follows (Dollars in thousands):

[0001032975-22-000034:mdna:116]
|  |  | Three Months EndedJune 30, |  |  |  |
|  |  | 2022 |  | 2021 |  |  |  |  |  |
| Marketing and selling |  | $ | 229,378 |  |  | $ | 252,314 |  |  |  |  |  |  |
| % of sales |  | 19.8 | % |  | 19.2 | % |  |  |  |  |  |
| Research and development |  | 75,517 |  |  | 69,246 |  |  |  |  |  |  |
| % of sales |  | 6.5 | % |  | 5.3 | % |  |  |  |  |  |
| General and administrative |  | 35,860 |  |  | 40,542 |  |  |  |  |  |  |
| % of sales |  | 3.1 | % |  | 3.1 | % |  |  |  |  |  |
| Amortization of intangible assets and acquisition-related costs |  | 3,369 |  |  | 5,217 |  |  |  |  |  |  |
| % of sales |  | 0.3 | % |  | 0.4 | % |  |  |  |  |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | (1,474) |  |  |  |  |  |  |
| % of sales |  | — | % |  | (0.1) | % |  |  |  |  |  |
| Total operating expenses |  | $ | 344,124 |  |  | $ | 365,845 |  |  |  |  |  |  |
| % of sales |  | 29.7 | % |  | 27.9 | % |  |  |  |  |  |

[0001032975-22-000034:mdna:117]
The decrease in total operating expenses during the three months ended June 30, 2022, compared to the same period of the prior fiscal year, were mainly due to decreases in marketing and selling expenses and general and administrative expenses, partially offset by an increase in research and development expenses.

[0001032975-22-000034:mdna:118]
[same as prior period, unchanged from 0001032975-22-000006:mdna:107]

[0001032975-22-000034:mdna:119]
[same as prior period, unchanged from 0001032975-22-000006:mdna:108]

[0001032975-22-000034:mdna:120]
During the three months ended June 30, 2022, marketing and selling expenses decreased $22.9 million, compared to the same period of the prior fiscal year, primarily driven by lower third-party marketing and advertising spend, partially offset by increases in personnel-related costs due to increased headcount to support business growth.

[0001032975-22-000034:mdna:121]
[same as prior period, unchanged from 0001032975-22-000006:mdna:110]

[0001032975-22-000034:mdna:122]
[same as prior period, unchanged from 0001032975-22-000006:mdna:111]

[0001032975-22-000034:mdna:123]
During the three months ended June 30, 2022, research and development expenses increased $6.3 million, compared to the same period of the prior fiscal year, primarily driven by higher personnel-related costs due to increased headcount to support our investment in innovation.

[0001032975-22-000034:mdna:124]
[same as prior period, unchanged from 0001032975-22-000006:mdna:113]

[0001032975-22-000034:mdna:125]
[same as prior period, unchanged from 0001032975-22-000006:mdna:114]

[0001032975-22-000034:mdna:126]
During the three months ended June 30, 2022, general and administrative expenses decreased $4.7 million, compared to the same period of the prior fiscal year, primarily driven by lower personnel-related costs.

[0001032975-22-000034:mdna:127]
[same as prior period, unchanged from 0001032975-22-000006:mdna:116]

[0001032975-22-000034:mdna:128]
Amortization of intangible assets consists of amortization of acquired intangible assets, including customer relationships and trademarks and trade names. Acquisition-related costs include legal expenses, due diligence costs, and other professional costs incurred for business acquisitions.

[0001032975-22-000034:mdna:129]
During the three months ended June 30, 2022, amortization of intangible assets and acquisition-related costs decreased $1.8 million, compared to the same period of the prior fiscal year, primarily due to certain acquired intangible assets becoming fully amortized and the write-off of Jaybird intangible assets in the third quarter of fiscal year 2022.

[0001032975-22-000034:mdna:130]
Interest Income

[0001032975-22-000034:mdna:131]
Interest income for the three months ended June 30, 2022 and 2021 was as follows (in thousands):

[0001032975-22-000034:mdna:132]
|  |  | Three Months EndedJune 30, |
|  |  | 2022 |  | 2021 |  |  |
| Interest Income |  | $ | 1,449 |  |  | $ | 316 |  |  |  |

[0001032975-22-000034:mdna:133]
We invest in highly liquid instruments with an original maturity of three months or less at the date of purchase, which are classified as cash equivalents. During the three months ended June 30, 2022 interest income increased $1.1 million, compared to the same period of the prior fiscal year, primarily driven by the increase in interest rates.

[0001032975-22-000034:mdna:134]
Other Income (Expense), Net

[0001032975-22-000034:mdna:135]
Other income (expense), net for the three months ended June 30, 2022 and 2021 was as follows (Dollars in thousands):

[0001032975-22-000034:mdna:136]
|  |  | Three Months EndedJune 30, |  |  |
|  |  | 2022 |  | 2021 |  |  |  |  |
| Investment income (expense) related to the deferred compensation plan |  | $ | (3,386) |  |  | $ | 1,168 |  |  |  |  |  |
| Currency exchange gain (loss), net |  | (2,960) |  |  | 5,717 |  |  |  |  |  |
| Gain on investments, net |  | 11,357 |  |  | 1,071 |  |  |  |  |  |
| Other |  | 613 |  |  | 479 |  |  |  |  |  |
| Total |  | $ | 5,624 |  |  | $ | 8,435 |  |  |  |  |  |

[0001032975-22-000034:mdna:137]
Investment income related to the deferred compensation plan represents earnings, gains, and losses on marketable securities related to a deferred compensation plan offered by one of our subsidiaries. The decrease in investment income for three months ended June 30, 2022 compared to the same period of the prior fiscal year primarily relates to the change in market performance of the underlying securities.

[0001032975-22-000034:mdna:138]
Currency exchange gain (loss), net, relates to balances denominated in currencies other than the functional currency in our subsidiaries, as well as to the sale of currencies, and gains or losses recognized on currency exchange forward contracts. We do not speculate in currency positions, but we are alert to opportunities to maximize currency exchange gains and minimize currency exchange losses. The loss for the three months ended June 30, 2022 was primarily due to the weakening of the Brazilian Real, Australian Dollar and Japanese Yen against the U.S. Dollar. The gain for the three months ended June 30, 2021 was primarily due to the strengthening of the Brazilian Real against the U.S. Dollar.

[0001032975-22-000034:mdna:139]
Gain on investments, net, represents unrealized gain (loss) from the fair value change of investment and gain (loss) on equity-method investments during the periods presented, as applicable. The gain for the three months ended June 30, 2022 was primarily due to the unrealized gain resulting from observable price changes on equity investments without a readily determinable fair value and gains on equity-method investments.

[0001032975-22-000034:mdna:140]
[same as prior period, unchanged from 0001032975-22-000006:mdna:130]

[0001032975-22-000034:mdna:141]
The provision for income taxes and effective income tax rates for the three months ended June 30, 2022 and 2021 were as follows (Dollars in thousands):

[0001032975-22-000034:mdna:142]
|  |  | Three Months EndedJune 30, |  |  |
|  |  | 2022 |  | 2021 |  |  |  |  |
| Provision for income taxes |  | $ | 21,716 |  |  | $ | 24,991 |  |  |  |  |  |
| Effective income tax rate |  | 17.7 | % |  | 11.8 | % |  |  |  |  |

[0001032975-22-000034:mdna:143]
The change in the effective income tax rate for the three months ended June 30, 2022, compared to the same period ended June 30, 2021 was primarily due to the mix of income and losses in the various tax jurisdictions in which we operate. There were discrete tax benefits of $1.4 million and $1.2 million from the recognition of excess tax benefits in the United States and reversal of uncertain tax positions from the expiration of statutes of limitations, respectively, in the three month period ended June 30, 2022, compared with $13.7 million and $1.0 million, respectively, in the three month period ended June 30, 2021.

[0001032975-22-000034:mdna:144]
As of June 30, 2022 and March 31, 2022, the total amount of unrecognized tax benefits due to uncertain tax positions was $174.3 million and $176.0 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-22-000034:mdna:145]
[same as prior period, unchanged from 0001032975-22-000006:mdna:135]

[0001032975-22-000034:mdna:146]
[same as prior period, unchanged from 0001032975-22-000006:mdna:136]

[0001032975-22-000034:mdna:147]
As of June 30, 2022, we had cash and cash equivalents of $1,106.7 million, compared with $1,328.7 million as of March 31, 2022. Our cash and cash equivalents consist of bank demand deposits and short-term time deposits, of which 62% is held in Switzerland, and 14% were held in China (including Hong Kong), and 10% held in Germany. We do not expect to incur any material adverse tax impact except for what has already been recognized, or to be significantly inhibited by any country in which we do business from the repatriation of funds to Switzerland, our home domicile.

[0001032975-22-000034:mdna:148]
As of June 30, 2022, our working capital was $1,604.8 million, compared to $1,651.8 million as of March 31, 2022. The decrease was primarily driven by lower cash balances, resulting from higher share repurchases, and lower inventories, partially offset by decreases in accrued liabilities and accounts payable and an increase in accounts receivable, net.

[0001032975-22-000034:mdna:149]
We had several uncommitted, unsecured bank lines of credit aggregating $185.9 million as of June 30, 2022. There are no financial covenants under these lines of credit with which we must comply. As of June 30, 2022, we had outstanding bank guarantees of $23.9 million under these lines of credit.

[0001032975-22-000034:mdna:150]
The following tables present selected financial information and statistics as of and for the three months ended June 30, 2022 and 2021 (Dollars in thousands):

[0001032975-22-000034:mdna:151]
|  |  | As of June 30, |  |
|  |  | 2022 |  | 2021 |  |
| Accounts receivable, net |  | $ | 706,886 |  |  | $ | 545,907 |  |  |
| Accounts payable |  | $ | 558,983 |  |  | $ | 709,741 |  |  |
| Inventories |  | $ | 917,356 |  |  | $ | 778,596 |  |  |

[0001032975-22-000034:mdna:152]
|  |  | Three Months EndedJune 30, |  |
|  |  | 2022 |  | 2021 |  |
| Days sales in accounts receivable (“DSO”) (Days) (1) |  | 55 |  |  | 37 |  |  |
| Days accounts payable outstanding (“DPO”) (Days) (2) |  | 72 |  |  | 86 |  |  |
| Inventory turnover (“ITO”) (x)(3) |  | 3.1 |  |  | 3.8 |  |  |

[0001032975-22-000034:mdna:153]
(1) DSO is determined using ending accounts receivable, net as of the most recent quarter-end and sales for the most recent quarter.

[0001032975-22-000034:mdna:154]
(2) DPO is determined using ending accounts payable as of the most recent quarter-end and cost of goods sold for the most recent quarter.

[0001032975-22-000034:mdna:155]
[same as prior period, unchanged from 0001032975-22-000006:mdna:148]

[0001032975-22-000034:mdna:156]
DSO for the three months ended June 30, 2022 increased by 18 days to 55 days, compared to 37 days for the same period of the prior fiscal year, primarily due to a comparatively higher percentage of sales in the last month of the current quarter.

[0001032975-22-000034:mdna:157]
DPO for the three months ended June 30, 2022 decreased by 14 days, compared to 86 days for the same period of the prior fiscal year, primarily due to lower inventory purchases than prior year resulting from softened demand and lower marketing spend.

[0001032975-22-000034:mdna:158]
ITO for the three months ended June 30, 2022 decreased by 0.7, compared to 3.8 for the same period of the prior fiscal year, primarily due to lower demand than prior year.

[0001032975-22-000034:mdna:159]
[same as prior period, unchanged from 0001032975-22-000006:mdna:152]

[0001032975-22-000034:mdna:160]
[same as prior period, unchanged from 0001032975-22-000006:mdna:141]

[0001032975-22-000034:mdna:161]
|  |  | Three Months EndedJune 30, |
|  |  | 2022 |  | 2021 |
| Net cash used in operating activities |  | $ | (35,668) |  |  | $ | (114,970) |  |
| Net cash used in investing activities |  | (27,469) |  |  | (40,347) |  |
| Net cash used in financing activities |  | (144,763) |  |  | (102,533) |  |
| Effect of exchange rate changes on cash and cash equivalents |  | (14,159) |  |  | 5,244 |  |
| Net decrease in cash and cash equivalents |  | $ | (222,059) |  |  | $ | (252,606) |  |

[0001032975-22-000034:mdna:162]
For the three months ended June 30, 2022, we used net cash of $35.7 million from operating activities, resulting from net income of $100.8 million, a favorable impact from adding back non-cash expenses totaling $37.3 million, and an unfavorable net change in operating assets and liabilities of $173.8 million. Non-cash expenses were primarily related to share-based compensation expenses, depreciation, amortization, and gains on investments. The increase in accounts receivable, net was primarily driven by timing of sales within the quarter. The decrease in inventories was primarily driven by lower inventory purchases. The decrease in accounts payable was primarily driven by lower inventory purchases and marketing spend. The decrease in accrued liabilities was primarily driven by payment of the fiscal year 2022 annual bonus.

[0001032975-22-000034:mdna:163]
For the three months ended June 30, 2022, net cash used in investing activities was $27.5, primarily due to $19.6 million of purchases of property, plant, and equipment and $5.8 million payments for acquisitions, net of cash acquired.

[0001032975-22-000034:mdna:164]
For the three months ended June 30, 2022, net cash used in financing activities was $144.8 million, resulting from repurchases of our registered shares of $120.6 million, and tax withholdings related to net share settlements of restricted stock units of $24.1 million.

[0001032975-22-000034:mdna:165]
For the three months ended June 30, 2022, there was a $14.2 million loss from currency exchange rate effect on cash and cash equivalents, primarily due to the weakening of the Euro, Chinese Renminbi, Swiss Franc, Australian Dollar versus the U.S. Dollar by 6%, 5%, 4% and 10%, respectively. The gain from currency translation exchange effect during the three months ended June 30, 2021 was primarily due to the strengthening of the Brazilian Real and the Chinese Renminbi against the U.S. Dollar by 14% and 2%, respectively, during the period.

[0001032975-22-000034:mdna:166]
[same as prior period, unchanged from 0001032975-22-000006:mdna:158]

[0001032975-22-000034:mdna:167]
Our principal sources of liquidity are our cash and cash equivalents, cash flow generated from operations and, to a much lesser extent, capital markets and borrowings. Our future working capital requirements and capital expenditures may increase to support investments in product innovations and growth opportunities or to acquire or invest in complementary businesses, products, services, and technologies. The current market volatility and future impact of COVID-19 cannot be predicted with certainty and may increase our costs of capital and otherwise adversely affect our business, results of operations, financial condition and liquidity.

[0001032975-22-000034:mdna:168]
In May 2022, the Board of Directors recommended that we pay cash dividends for fiscal year 2022 of CHF 0.96 per share (approximately $1.04 per share based on the exchange rate on March 31, 2022). Based on our shares outstanding, net of treasury shares, as of March 31, 2022 (165,252,020 shares), this would result in an aggregate gross dividend of approximately CHF 159.0 million (or approximately $172.1 million based on the exchange rate on March 31, 2022). In fiscal year 2022, we paid a cash dividend of CHF 147.0 million (U.S. Dollar amount of $159.4 million) out of fiscal year 2021 retained earnings. In fiscal year 2021, we paid a cash dividend of CHF 134.0 million (U.S. Dollar amount of $146.7 million) out of fiscal year 2020 retained earnings.

[0001032975-22-000034:mdna:169]
In May 2020, our Board of Directors approved a new share repurchase program, which authorized us to invest up to $250.0 million to purchase our own shares, following the expiration date of the 2017 share repurchase program.  In April 2021, our Board of Directors approved an increase of $750.0 million of the 2020 share repurchase program, to an aggregate amount of $1.0 billion. The Swiss Takeover Board approved this increase and it became effective on May 21, 2021. As of June 30, 2022, $303.1 million was available for repurchase under the 2020 repurchase program.

[0001032975-22-000034:mdna:170]
In July 2022, our Board of Directors approved an increase of $500 million to the 2020 share repurchase program to an aggregate amount of up to $1.5 billion. This increase is subject to approval by the Swiss Takeover Board.

[0001032975-22-000034:mdna:171]
Although we enter into trading plans for systematic repurchases (e.g., 10b5-1 trading plans) from time to time, our share repurchase program provides us with the opportunity to make opportunistic repurchases during periods of favorable market conditions and is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Opportunistic purchases may be started or stopped at any time without prior notice depending on market conditions and other factors.

[0001032975-22-000034:mdna:172]
If we do not generate sufficient operating cash flows to support our operations and future planned cash requirements, our operations could be harmed and our access to credit facilities could be restricted or eliminated. However, we believe that the trend of our historical cash flow generation, our projections of future operations and our available cash balances will provide sufficient liquidity to fund our operations for at least the next 12 months.

[0001032975-22-000034:mdna:173]
[same as prior period, unchanged from 0001032975-22-000006:mdna:164]

[0001032975-22-000034:mdna:174]
We lease facilities under operating leases, certain of which require us to pay property taxes, insurance and maintenance costs. Operating leases for facilities are generally renewable at our option and usually include escalation clauses linked to inflation. There have been no other material changes to our contractual obligations as previously disclosed in our Annual Report on Form 10-K for the year ended March 31, 2022. The remaining terms of our non-cancelable operating leases expire in various years through 2031.

[0001032975-22-000034:mdna:175]
[same as prior period, unchanged from 0001032975-22-000006:mdna:166]

[0001032975-22-000034:mdna:176]
As of June 30, 2022, we had non-cancelable purchase commitments of $674.0 million for inventory purchases made in the normal course of business from original design manufacturers, contract manufacturers and other suppliers, the majority of which are expected to be fulfilled within the next 12 months. We recorded a liability for firm, non-cancelable, and unhedged inventory purchase commitments in excess of anticipated demand or net realizable value consistent with our valuation of excess and obsolete inventory. As of June 30, 2022, the liability for these purchase commitments was $43.1 million and is recorded in accrued and other current liabilities in the condensed consolidated balance sheet.

[0001032975-22-000034:mdna:177]
We have firm purchase commitments of $28.0 million for capital expenditures primarily related to commitments for tooling and equipment for new and existing products. We expect to continue making capital expenditures in the future to support product development activities and ongoing and expanded operations. Although open purchase commitments are considered enforceable and legally binding, the terms generally allow us to reschedule or adjust our requirements based on business needs prior to delivery of goods or performance of services.

[0001032975-22-000034:mdna:178]
[same as prior period, unchanged from 0001032975-22-000006:mdna:169]

[0001032975-22-000034:mdna:179]
For further detail about our contractual obligations and commitments, refer to our Annual Report on Form 10-K for the fiscal year ended March 31, 2022.

[0001032975-22-000034:mdna:180]
[same as prior period, unchanged from 0001032975-22-000006:mdna:171]

[0001032975-22-000034:mdna:181]
We indemnify certain suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of June 30, 2022, no amounts have been accrued for indemnification provisions. We do not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under our indemnification arrangements.

[0001032975-22-000034:mdna:182]
[same as prior period, unchanged from 0001032975-22-000006:mdna:173]

[0001032975-22-000034:mdna:183]
Legal Proceedings

[0001032975-22-000034:mdna:184]
From time to time we are involved in claims and legal proceedings that arise in the ordinary course of our business. For more information about Legal Proceedings, see Part II Item 1 Legal Proceedings of this quarterly report on Form 10-Q for the period ended June 30, 2022.
