# LOGI notes — 0001032975-22-000034


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001032975-22-000034:notes:1]
[same as prior period, unchanged from 0001032975-22-000006:notes:1]

[0001032975-22-000034:notes:2]
Logitech International S.A, together with its consolidated subsidiaries ("Logitech" or the "Company"), designs, manufactures and markets products that help connect people to digital and cloud experiences. Forty years ago, Logitech created products to improve experiences around the personal computer ("PC") platform, and today it is a multi-brand, multi-category company designing products that enable better experiences consuming, sharing and creating any digital content such as computing, gaming, video, and music, whether it is on a computer, mobile device or in the cloud.

[0001032975-22-000034:notes:3]
The Company sells its products to a broad network of domestic and international customers, including direct sales to retailers, e-tailers and enterprise customers, and indirect sales through distributors.

[0001032975-22-000034:notes:4]
Logitech was founded in Switzerland in 1981 and Logitech International S.A. has been the parent holding company of Logitech since 1988. Logitech International S.A. is a Swiss holding company with its registered office in Hautemorges, Switzerland, and headquarters in Lausanne, Switzerland, which conducts its business through subsidiaries in the Americas, Europe, Middle East and Africa ("EMEA") and Asia Pacific. Shares of Logitech International S.A. are listed on both the SIX Swiss Exchange under the trading symbol LOGN and the Nasdaq Global Select Market under the trading symbol LOGI.

[0001032975-22-000034:notes:5]
[same as prior period, unchanged from 0001032975-22-000006:notes:5]

[0001032975-22-000034:notes:6]
The condensed consolidated financial statements include the accounts of Logitech and its subsidiaries. All intercompany balances and transactions have been eliminated. The condensed consolidated financial statements are presented in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") for interim financial information and therefore do not include all the information required by U.S. GAAP for complete financial statements. The condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended March 31, 2022, included in its Annual Report on Form 10-K filed with the Securities and Exchange Commission ("SEC") on May 18, 2022.

[0001032975-22-000034:notes:7]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three months ended June 30, 2022 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2023, or any future periods.

[0001032975-22-000034:notes:8]
[same as prior period, unchanged from 0001032975-22-000006:notes:8]

[0001032975-22-000034:notes:9]
Other than the recent accounting pronouncements adopted and discussed below under Recent Accounting Pronouncements Adopted, there have been no material changes in the Company’s significant accounting policies during the three months ended June 30, 2022 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2022.

[0001032975-22-000034:notes:10]
[same as prior period, unchanged from 0001032975-22-000006:notes:10]

[0001032975-22-000034:notes:11]
The preparation of financial statements in conformity with U.S. GAAP requires management to make judgments, estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Significant estimates and assumptions made by management involve the fair value of goodwill and intangible assets acquired from business acquisitions, contingent consideration for a business acquisition and periodic reassessment of its fair value, valuation of investment in privately held companies classified under Level 3 fair value hierarchy, pension obligations, accruals for customer incentives, cooperative marketing, and pricing programs and related breakage when appropriate, inventory valuation, share-based compensation expense, uncertain tax positions, and valuation allowances for deferred tax assets. Although these

[0001032975-22-000034:notes:12]
estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ materially from those estimates.

[0001032975-22-000034:notes:13]
[same as prior period, unchanged from 0001032975-22-000006:notes:12]

[0001032975-22-000034:notes:14]
Impacts of Macroeconomic and Geopolitical Conditions on the Company's Business

[0001032975-22-000034:notes:15]
During the first quarter of fiscal year 2023, the Company was impacted by adverse macroeconomic and geopolitical conditions. These conditions include but are not limited to inflation, foreign currency fluctuations, and lower consumer spending. The Company also continues to be affected by supply chain challenges, and the war in Ukraine has further increased existing global supply chain, logistics, and inflationary challenges. Such global or regional economic and political conditions adversely affect demand for the Company's products. These conditions also have an impact on its suppliers, contract manufacturers, logistics providers, and distributors, causing increases in cost of materials and higher shipping and transportation rates, and as a result impacting the pricing of its products. Price increases may not successfully offset cost increases or may cause the Company to lose market share and in turn adversely impact its results of operations.

[0001032975-22-000034:notes:16]
Impacts of COVID-19 on the Company's Business

[0001032975-22-000034:notes:17]
In March 2020, the World Health Organization declared the outbreak of COVID-19 as a pandemic, which continues to spread throughout the world. The COVID-19 pandemic has resulted in, and could continue to result in, industry-wide global supply chain challenges, including manufacturing, transportation and logistics. The Company purchases certain products and key components from a limited number of sources, and depends on the supply chain, including freight, to receive components, transport finished goods and deliver its products across the world. While the Company proactively manages its supply chain, it expects to continue to be impacted by higher logistics and component costs, prolonged delays, and challenges with component availability. Most recently, Shanghai, China, experienced a two-month lockdown beginning in late March 2022 due to another outbreak of COVID-19, resulting in a lockdown of the city, closures of ports and airports, and disruption of commercial activities, further constraining the Company's supply chain. If additional lockdowns or similar measures are instituted in Shanghai or Suzhou, where the Company's manufacturing facility is located, or other places where the Company's suppliers and partners are located, such measures, depending on their duration, could cause additional negative impact on the Company's business and results of operations.

[0001032975-22-000034:notes:18]
It is still difficult to predict the progression, the duration and all of the effects of COVID-19, how restrictions and shelter-at-home guidelines will continue evolving on a global basis, how consumer demand, supply chain challenges, including inventory and logistical effects and costs, may change over time, and the impact on the Company's future sales and results of operations. The full extent of the impact of the COVID-19 pandemic on the Company's business and operational and financial performance remains uncertain and will depend on many factors outside the Company's control.

[0001032975-22-000034:notes:19]
[same as prior period, unchanged from 0001032975-22-000006:notes:14]

[0001032975-22-000034:notes:20]
In October 2021, the Financial Accounting Standard Board ("FASB") issued ASU 2021-08, "Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers" (ASU 2021-08). The update requires an acquirer in a business combination to recognize and measure contract assets and contract liabilities acquired in a business combination in accordance with Accounting Standards Codification ("ASC") 606, Revenue from Contracts with Customers, as if it had originated the contracts. The standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2022. The Company early adopted the standard effective April 1, 2022 and applies the standard prospectively to business combinations that occurred on or after April 1, 2022. The adoption of ASU 2021-08 did not have a material impact on the Company's condensed consolidated financial statements.


## us-gaap:EarningsPerShareTextBlock

[0001032975-22-000034:notes:21]
[same as prior period, unchanged from 0001032975-22-000006:notes:18]

[0001032975-22-000034:notes:22]
The following table summarizes the computations of basic and diluted net income per share for the three months ended June 30, 2022 and 2021 (in thousands, except per share amounts):

[0001032975-22-000034:notes:23]
|  |  | Three Months EndedJune 30, |  |  |
|  |  | 2022 |  | 2021 |  |  |  |  |
| Net income |  | $ | 100,836 |  |  | $ | 186,841 |  |  |  |  |  |
| Shares used in net income per share computation: |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding - basic |  | 164,679 |  |  | 168,372 |  |  |  |  |  |
| Effect of potentially dilutive equivalent shares |  | 1,727 |  |  | 3,648 |  |  |  |  |  |
| Weighted average shares outstanding - diluted |  | 166,406 |  |  | 172,020 |  |  |  |  |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.61 |  |  | $ | 1.11 |  |  |  |  |  |
| Diluted |  | $ | 0.61 |  |  | $ | 1.09 |  |  |  |  |  |

[0001032975-22-000034:notes:24]
Share equivalents attributable to outstanding stock options, restricted stock units ("RSUs") and employee share purchase plans ("ESPP") totaling 3.4 million and 0.5 million for the three months ended June 30, 2022 and 2021, respectively, were excluded from the calculation of diluted net income per share because their effect would have been anti-dilutive. A small number of performance-based awards were not included in the calculation because all necessary conditions had not been satisfied by the end of the respective period, and those shares were not issuable if the end of the reporting period were the end of the performance contingency period.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001032975-22-000034:notes:25]
[same as prior period, unchanged from 0001032975-22-000006:notes:22]

[0001032975-22-000034:notes:26]
[same as prior period, unchanged from 0001032975-22-000006:notes:23]

[0001032975-22-000034:notes:27]
As of June 30, 2022, the Company offers the 2006 Employee Share Purchase Plan, as amended and restated (Non-U.S.) ("2006 ESPP"), the 1996 Employee Share Purchase Plan (U.S.), as amended and restated ("1996 ESPP"), and the 2006 Stock Incentive Plan ("2006 Plan") as amended and restated. Shares issued to employees as a result of purchases or exercises under these plans are generally issued from shares held in treasury stock.

[0001032975-22-000034:notes:28]
The following table summarizes the share-based compensation expense and total income tax benefit recognized for share-based awards for the three months ended June 30, 2022 and 2021 (in thousands):

[0001032975-22-000034:notes:29]
|  |  | Three Months EndedJune 30, |  |  |
|  |  | 2022 |  | 2021 |  |  |  |  |
| Cost of goods sold |  | $ | 1,461 |  |  | $ | 1,369 |  |  |  |  |  |
| Marketing and selling |  | 9,797 |  |  | 8,530 |  |  |  |  |  |
| Research and development |  | 5,532 |  |  | 5,061 |  |  |  |  |  |
| General and administrative |  | 6,900 |  |  | 8,691 |  |  |  |  |  |
| Total share-based compensation expense |  | 23,690 |  |  | 23,651 |  |  |  |  |  |
| Income tax benefit |  | (4,322) |  |  | (16,594) |  |  |  |  |  |
| Total share-based compensation expense, net of income tax benefit |  | $ | 19,368 |  |  | $ | 7,057 |  |  |  |  |  |

[0001032975-22-000034:notes:30]
[same as prior period, unchanged from 0001032975-22-000006:notes:27]

[0001032975-22-000034:notes:31]
During the three months ended June 30, 2022 and 2021, share-based compensation costs of $1.8 million and $1.7 million, respectively, were capitalized as part of inventory.

[0001032975-22-000034:notes:32]
[same as prior period, unchanged from 0001032975-22-000006:notes:29]

[0001032975-22-000034:notes:33]
Certain of the Company’s subsidiaries sponsor defined benefit pension plans or non-retirement post-employment benefits covering substantially all of their employees. Benefits are provided based on employees’ years of service and earnings, or in accordance with applicable employee benefit regulations. The Company’s practice is to fund amounts sufficient to meet the requirements set forth in the applicable employee benefit and tax regulations. The costs recorded of $2.8 million and $3.3 million for the three months ended June 30, 2022 and 2021, respectively, were primarily related to service costs.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001032975-22-000034:notes:34]
[same as prior period, unchanged from 0001032975-22-000006:notes:31]

[0001032975-22-000034:notes:35]
[same as prior period, unchanged from 0001032975-22-000006:notes:32]

[0001032975-22-000034:notes:36]
The income tax provision for the three months ended June 30, 2022 was $21.7 million based on an effective income tax rate of 17.7% of pre-tax income, compared to an income tax provision of $25.0 million based on an effective income tax rate of 11.8% of pre-tax income for the three months ended June 30, 2021.

[0001032975-22-000034:notes:37]
The change in the effective income tax rate for the three months ended June 30, 2022, compared to the same period ended June 30, 2021 was primarily due to the mix of income and losses in the various tax jurisdictions in which the Company operates. There were discrete tax benefits of $1.4 million and $1.2 million from the recognition of excess tax benefits in the United States and reversal of uncertain tax positions from the expiration of statutes of limitations, respectively, in the three month period ended June 30, 2022, compared with $13.7 million and $1.0 million, respectively, in the three month period ended June 30, 2021.

[0001032975-22-000034:notes:38]
As of June 30, 2022 and March 31, 2022, the total amount of unrecognized tax benefits due to uncertain tax positions was $174.3 million and $176.0 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-22-000034:notes:39]
As of June 30, 2022 and March 31, 2022, the Company had $82.9 million and $83.4 million, respectively, in non-current income taxes payable including interest and penalties, related to the Company's income tax liability for uncertain tax positions.

[0001032975-22-000034:notes:40]
The Company recognizes interest and penalties related to unrecognized tax positions in the income tax provision. As of June 30, 2022 and March 31, 2022, the Company had $4.3 million and $3.6 million, respectively, of accrued interest and penalties related to uncertain tax positions in non-current income taxes payable.

[0001032975-22-000034:notes:41]
Although the Company has adequately provided for uncertain tax positions, the provisions related to these positions may change as revised estimates are made or the underlying matters are settled or otherwise resolved. During fiscal year 2023, the Company continues to review its tax positions and provide for or reverse unrecognized tax benefits as they arise. During the next twelve months, it is reasonably possible that the amount of unrecognized tax benefits could increase or decrease significantly due to changes in tax law in various jurisdictions, new tax audits and changes in the U.S. dollar as compared to other currencies. Excluding these factors, uncertain tax positions may decrease by as much as $4.2 million from the lapse of the statutes of limitations in various jurisdictions during the next twelve months.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001032975-22-000034:notes:42]
[same as prior period, unchanged from 0001032975-22-000006:notes:40]

[0001032975-22-000034:notes:43]
The following table presents the components of certain balance sheet asset amounts (in thousands):

[0001032975-22-000034:notes:44]
|  |  | June 30, 2022 |  | March 31, 2022 |
| Accounts receivable, net: |  |  |  |  |
| Accounts receivable |  | $ | 961,266 |  |  | $ | 964,766 |  |
| Allowance for doubtful accounts |  | (174) |  |  | (2,212) |  |
| Allowance for sales returns |  | (9,779) |  |  | (12,321) |  |
| Allowance for cooperative marketing arrangements |  | (47,025) |  |  | (56,372) |  |
| Allowance for customer incentive programs |  | (95,215) |  |  | (97,460) |  |
| Allowance for pricing programs |  | (102,187) |  |  | (120,797) |  |
|  |  | $ | 706,886 |  |  | $ | 675,604 |  |
| Inventories: |  |  |  |  |
| Raw materials |  | $ | 243,780 |  |  | $ | 226,155 |  |
| Finished goods |  | 673,576 |  |  | 706,969 |  |
|  |  | $ | 917,356 |  |  | $ | 933,124 |  |
| Other current assets: |  |  |  |  |
| Value-added tax ("VAT") receivables |  | $ | 44,018 |  |  | $ | 58,850 |  |
| Prepaid expenses and other assets |  | 82,671 |  |  | 76,628 |  |
|  |  | $ | 126,689 |  |  | $ | 135,478 |  |
| Property, plant and equipment, net: |  |  |  |  |
| Property, plant and equipment |  | $ | 477,941 |  |  | $ | 459,413 |  |
| Less: accumulated depreciation and amortization |  | (365,701) |  |  | (349,606) |  |
|  |  | $ | 112,240 |  |  | $ | 109,807 |  |
| Other assets: |  |  |  |  |
| Deferred tax assets |  | $ | 187,544 |  |  | $ | 193,629 |  |
| Investments in privately held companies |  | 56,512 |  |  | 43,068 |  |
| Right-of-use assets |  | 41,422 |  |  | 40,661 |  |
| Investments for deferred compensation plan |  | 28,310 |  |  | 28,431 |  |
| Other assets |  | 15,067 |  |  | 14,933 |  |
|  |  | $ | 328,855 |  |  | $ | 320,722 |  |

[0001032975-22-000034:notes:45]
The following table presents the components of certain balance sheet liability amounts (in thousands):

[0001032975-22-000034:notes:46]
|  |  | June 30, 2022 |  | March 31, 2022 |
| Accrued and other current liabilities: |  |  |  |  |
| Accrued customer marketing, pricing and incentive programs |  | $ | 214,342 |  |  | $ | 232,393 |  |
| Accrued personnel expenses |  | 115,168 |  |  | 165,090 |  |
| Accrued sales return liability |  | 43,737 |  |  | 40,507 |  |
| Warranty accrual |  | 31,368 |  |  | 32,987 |  |
| Accrued payables - non-inventory |  | 20,661 |  |  | 26,722 |  |
| VAT payable |  | 20,443 |  |  | 39,602 |  |
| Income taxes payable |  | 19,239 |  |  | 35,355 |  |
| Operating lease liabilities |  | 13,121 |  |  | 13,690 |  |
| Contingent consideration |  | 12,013 |  |  | 8,042 |  |
| Other current liabilities |  | 203,692 |  |  | 190,460 |  |
|  |  | $ | 693,784 |  |  | $ | 784,848 |  |
| Other non-current liabilities: |  |  |  |  |
| Employee benefit plan obligations |  | $ | 48,604 |  |  | $ | 50,741 |  |
| Operating lease liabilities |  | 28,873 |  |  | 28,207 |  |
| Obligation for deferred compensation plan |  | 28,310 |  |  | 28,431 |  |
| Warranty accrual |  | 12,473 |  |  | 13,232 |  |
| Deferred tax liabilities |  | 3,154 |  |  | 1,962 |  |
| Contingent consideration |  | 1,388 |  |  | 4,217 |  |
| Other non-current liabilities |  | 8,898 |  |  | 5,343 |  |
|  |  | $ | 131,700 |  |  | $ | 132,133 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001032975-22-000034:notes:47]
[same as prior period, unchanged from 0001032975-22-000006:notes:45]

[0001032975-22-000034:notes:48]
[same as prior period, unchanged from 0001032975-22-000006:notes:46]

[0001032975-22-000034:notes:49]
[same as prior period, unchanged from 0001032975-22-000006:notes:47]

[0001032975-22-000034:notes:50]
[same as prior period, unchanged from 0001032975-22-000006:notes:48]

[0001032975-22-000034:notes:51]
[same as prior period, unchanged from 0001032975-22-000006:notes:49]

[0001032975-22-000034:notes:52]
[same as prior period, unchanged from 0001032975-22-000006:notes:50]

[0001032975-22-000034:notes:53]
|  |  | June 30, 2022 |  | March 31, 2022 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Level 1 |  | Level 2 |  | Level 3 |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 665,410 |  |  | $ | — |  |  | $ | — |  |  | $ | 762,055 |  |  | $ | — |  |  | $ | — |  |
| Investments for deferred compensation plan included in other assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 138 |  |  | $ | — |  |  | $ | — |  |  | $ | 108 |  |  | $ | — |  |  | $ | — |  |
| Common stock |  | 1,631 |  |  | — |  |  | — |  |  | 2,329 |  |  | — |  |  | — |  |
| Money market funds |  | 7,991 |  |  | — |  |  | — |  |  | 6,765 |  |  | — |  |  | — |  |
| Mutual funds |  | 18,550 |  |  | — |  |  | — |  |  | 19,229 |  |  | — |  |  | — |  |
| Total of investments for deferred compensation plan |  | $ | 28,310 |  |  | $ | — |  |  | $ | — |  |  | $ | 28,431 |  |  | $ | — |  |  | $ | — |  |
| Currency derivative assetsincluded in other current assets |  | $ | — |  |  | $ | 3,147 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,517 |  |  | $ | — |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Contingent consideration included in accrued and other current liabilities |  | $ | — |  |  | $ | — |  |  | $ | 12,013 |  |  | $ | — |  |  | $ | — |  |  | $ | 8,042 |  |
| Contingent consideration included in other non-current liabilities |  | $ | — |  |  | $ | — |  |  | $ | 1,142 |  |  | $ | — |  |  | $ | — |  |  | $ | 3,971 |  |
| Currency derivative liabilitiesincluded in accrued and other current liabilities |  | $ | — |  |  | $ | 160 |  |  | $ | — |  |  | $ | — |  |  | $ | 165 |  |  | $ | — |  |

[0001032975-22-000034:notes:54]
[same as prior period, unchanged from 0001032975-22-000006:notes:59]

[0001032975-22-000034:notes:55]
The following table summarizes the change in the fair value of the Company's contingent consideration balance during the three months ended June 30, 2022 and 2021 (in thousands):

[0001032975-22-000034:notes:56]
|  | Three Months EndedJune 30, |
|  | 2022 |  | 2021 |
| Beginning of the period | $ | 12,259 |  |  | $ | 6,967 |  |
| Fair value of contingent consideration upon acquisition (1) | 1,142 |  |  | 9,973 |  |
| Change in fair value of contingent consideration | — |  |  | (1,474) |  |
| End of the period | $ | 13,401 |  |  | $ | 15,466 |  |

[0001032975-22-000034:notes:57]
(1) Represents the contingent consideration related to the technology acquisitions during the periods.

[0001032975-22-000034:notes:58]
The contingent consideration arising from the technology acquisition on May 19, 2021, represents the future potential earn-out payments of up to $10.0 million payable in cash only upon the achievement of three technical development milestones required to be completed as of December 31, 2021, June 30, 2022, and June 30, 2023. The fair value of the contingent consideration as of the acquisition date was $10.0 million, which was determined using a probability-weighted expected payment model and discounted at the estimated cost of debt. During the third quarter of fiscal year 2022, $0.9 million of the contingent consideration was released from other current liabilities upon cash settlement of the contingent consideration for the first technical development milestone. During the first quarter of fiscal year 2023, the second technical development milestone was achieved and the related contingent consideration is expected to be paid in fiscal year 2023.

[0001032975-22-000034:notes:59]
The contingent consideration arising from the Mevo Acquisition on February 17, 2021 represents the future potential earn-out payments of up to $17.0 million payable in cash only upon the achievement of certain net sales for the period from December 26, 2020 to December 31, 2021. As of March 31, 2021 the fair value of the contingent consideration was $3.4 million. As of December 31, 2021, the fair value of the contingent consideration was

[0001032975-22-000034:notes:60]
released from other current liabilities as the net sales milestone was not achieved upon completion of the earn-out period.

[0001032975-22-000034:notes:61]
The contingent consideration arising from the technology acquisition on January 4, 2021, represents the future potential earn-out payments of up to $3.0 million payable in cash upon the achievement of two technical development milestones required to be completed as of December 31, 2021 and March 31, 2022. The fair value of the contingent amount was determined using a probability-weighted expected payment model and discounted at the estimated cost of debt. The contingent consideration is expected to be paid in fiscal year 2023.

[0001032975-22-000034:notes:62]
Although the estimate of contingent consideration is based on management’s best knowledge of current events, the estimate could change significantly from period to period. Actual results that differ from the assumptions used and any changes to the significant assumptions and unobservable inputs used could have an impact on future results of operations.

[0001032975-22-000034:notes:63]
Investment for Deferred Compensation Plan

[0001032975-22-000034:notes:64]
The marketable securities for the Company's deferred compensation plan were recorded at a fair value of $28.3 million and $28.4 million, as of June 30, 2022 and March 31, 2022, respectively, based on quoted market prices. Quoted market prices are observable inputs that are classified as Level 1 within the fair value hierarchy. Unrealized gains (losses) related to marketable securities for the three months ended June 30, 2022 and 2021 were not material and were included in other income (expense), net in the Company's condensed consolidated statements of operations.

[0001032975-22-000034:notes:65]
[same as prior period, unchanged from 0001032975-22-000006:notes:66]

[0001032975-22-000034:notes:66]
The Company has certain non-marketable investments included in other assets that are accounted for under the equity method of accounting, with a carrying value of $44.8 million and $40.2 million as of June 30, 2022 and March 31, 2022, respectively. Unrealized gains (losses) related to equity investments for the three months ended June 30, 2022 and 2021 were not material and are included in other income (expense), net in the Company's condensed consolidated statements of operations. There was no impairment of these assets during the three months ended June 30, 2022 or 2021.

[0001032975-22-000034:notes:67]
[same as prior period, unchanged from 0001032975-22-000006:notes:69]

[0001032975-22-000034:notes:68]
Financial Assets.  The Company has certain investments without readily determinable fair values due to the absence of quoted market prices, the inherent lack of liquidity, and the fact that inputs used to measure fair value are unobservable and require management's judgment. When certain events or circumstances indicate that impairment may exist, the Company revalues the investments using various assumptions, including the financial metrics and ratios of comparable public companies. The carrying value is also adjusted for observable price changes with the same or similar security from the same issuer. The amount of these investments included in other assets was $11.7 million and $2.9 million as of June 30, 2022 and March 31, 2022, respectively. During the three months ended June 30, 2022, the Company recorded an unrealized gain, before tax, of $6.9 million for its investment in a private company as a result of observable price changes for similar securities issued by this company (level 2 fair value measurement). There was no impairment of these assets during the three months ended June 30, 2022 or 2021.

[0001032975-22-000034:notes:69]
Non-Financial Assets.  Goodwill, intangible assets, and property, plant and equipment, are not required to be measured at fair value on a recurring basis. However, if certain triggering events occur (or tested at least annually for goodwill) such that a non-financial instrument is required to be evaluated for impairment and an impairment is recorded to reduce the non-financial instrument's carrying value to the fair value as a result of such triggering events, the non-financial assets and liabilities are measured at fair value during such period. There was no impairment of non-financial assets during the three months ended June 30, 2022 and 2021.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001032975-22-000034:notes:70]
[same as prior period, unchanged from 0001032975-22-000006:notes:72]

[0001032975-22-000034:notes:71]
Under certain agreements with the respective counterparties to the Company’s derivative contracts, subject to applicable requirements, the Company is allowed to net settle transactions of the same type with a single net amount payable by one party to the other. However, the Company presents its derivative assets and derivative liabilities on a gross basis in other current assets and accrued and other current liabilities, respectively, on the

[0001032975-22-000034:notes:72]
condensed consolidated balance sheets as of June 30, 2022 and March 31, 2022. See Note 6 for the fair values of the Company’s derivative instruments as of June 30, 2022 or March 31, 2022.

[0001032975-22-000034:notes:73]
[same as prior period, unchanged from 0001032975-22-000006:notes:76]

[0001032975-22-000034:notes:74]
The Company enters into cash flow hedge contracts to protect against exchange rate exposure of forecasted inventory purchases. These hedging contracts mature within four months. Gains and losses in the fair value of the effective portion of the hedges are deferred as a component of accumulated other comprehensive loss until the hedged inventory purchases are sold, at which time the gains or losses are reclassified to cost of goods sold. Cash flows from such hedges are classified as operating activities in the condensed consolidated statements of cash flows. Hedging relationships are discontinued when hedging contract is no longer eligible for hedge accounting, or is sold, terminated or exercised, or when the Company removes hedge designation for the contract. Gains and losses in the fair value of the effective portion of the discontinued hedges continue to be reported in accumulated other comprehensive loss until the hedged inventory purchases are sold, unless it is probable that the forecasted inventory purchases will not occur by the end of the originally specified time period or within an additional two-month period of time thereafter.

[0001032975-22-000034:notes:75]
The notional amounts of foreign currency exchange forward contracts outstanding related to forecasted inventory purchases were $96.2 million and $125.4 million as of June 30, 2022 and March 31, 2022, respectively. The Company had $6.4 million of net gains related to its cash flow hedges included in accumulated other comprehensive loss as of June 30, 2022, which will be reclassified into earnings within the next twelve months.

[0001032975-22-000034:notes:76]
The following table presents the amounts of gains on the Company’s derivative instruments designated as hedging instruments for the three months ended June 30, 2022 and 2021 and their locations on its condensed consolidated statements of operations and condensed consolidated statements of comprehensive income (in thousands):

[0001032975-22-000034:notes:77]
|  |  | Three Months EndedJune 30, |
|  |  | Amount of GainDeferred as a Component of AccumulatedOther Comprehensive Loss |  | Amount of GainReclassified from Accumulated Other Comprehensive Loss to Costs of Goods Sold |  |  |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |  |  |  |  |
| Cash flow hedges |  | $ | 6,629 |  |  | $ | 530 |  |  | $ | (2,091) |  |  | $ | (594) |  |  |  |  |  |

[0001032975-22-000034:notes:78]
The Company presents the earnings impact from forward points in the same line item that is used to present the earnings impact of the hedged item, i.e. cost of goods sold, for hedging forecasted inventory purchases and such amount is not material for all periods presented.

[0001032975-22-000034:notes:79]
[same as prior period, unchanged from 0001032975-22-000006:notes:78]

[0001032975-22-000034:notes:80]
The Company also enters into foreign currency exchange forward and swap contracts to reduce the short-term effects of currency exchange rate fluctuations on certain receivables or payables denominated in currencies other than the functional currencies of its subsidiaries. These contracts generally mature within a month. The primary risk managed by using forward and swap contracts is the currency exchange rate risk. The gains or losses on these contracts are not material and included in other income (expense), net in the condensed consolidated statements of operations based on the changes in fair value. The notional amounts of these contracts outstanding as of June 30, 2022 and March 31, 2022 were $206.4 million and $226.5 million, respectively. Foreign currency exchange forward and swap contracts outstanding as of June 30, 2022 and March 31, 2022 consisted of contracts in Japanese Yen, Australian Dollars, Canadian Dollars, Chinese Renminbi, Mexican Pesos, New Taiwan Dollars, and Brazilian Real, to be settled at future dates at pre-determined exchange rates.

[0001032975-22-000034:notes:81]
[same as prior period, unchanged from 0001032975-22-000006:notes:80]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001032975-22-000034:notes:82]
Goodwill and Other Intangible Assets
The Company conducts its impairment analysis of goodwill and indefinite life intangible assets annually at December 31 or more frequently if changes in facts and circumstances indicate that it is more likely than not that the fair value of the Company’s reporting unit may be less than its carrying amount. There have been no triggering events identified affecting the valuation of goodwill and indefinite life intangible assets during the three months ended June 30, 2022 and 2021.

[0001032975-22-000034:notes:83]
The following table summarizes the activities in the Company’s goodwill balance (in thousands):

[0001032975-22-000034:notes:84]
| As of March 31, 2022 |  | $ | 448,175 |  |
| Acquisition |  | 4,980 |  |
| Effects of foreign currency translation |  | (1,946) |  |
| As of June 30, 2022 |  | $ | 451,209 |  |

[0001032975-22-000034:notes:85]
The Company's acquired intangible assets were as follows (in thousands):

[0001032975-22-000034:notes:86]
|  |  | June 30, 2022 |  | March 31, 2022 |
|  |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |
| Trademark and trade names |  | $ | 36,790 |  |  | $ | (23,470) |  |  | $ | 13,320 |  |  | $ | 36,790 |  |  | $ | (22,295) |  |  | $ | 14,495 |  |
| Developed technology |  | 122,075 |  |  | (86,631) |  |  | 35,444 |  |  | 119,407 |  |  | (83,540) |  |  | 35,867 |  |
| Customer contracts/relationships |  | 71,110 |  |  | (42,612) |  |  | 28,498 |  |  | 71,110 |  |  | (40,971) |  |  | 30,139 |  |
| In-process R&D |  | 3,526 |  |  | — |  |  | 3,526 |  |  | 3,826 |  |  | — |  |  | 3,826 |  |
| Effects of foreign currency translation |  | (1,183) |  |  | 215 |  |  | (968) |  |  | (634) |  |  | 86 |  |  | (548) |  |
| Total |  | $ | 232,318 |  |  | $ | (152,498) |  |  | $ | 79,820 |  |  | $ | 230,499 |  |  | $ | (146,720) |  |  | $ | 83,779 |  |


## us-gaap:DebtDisclosureTextBlock

[0001032975-22-000034:notes:87]
Financing Arrangements

[0001032975-22-000034:notes:88]
The Company had several uncommitted, unsecured bank lines of credit aggregating $185.9 million and $195.0 million as of June 30, 2022 and March 31, 2022, respectively. There are no financial covenants under these lines of credit with which the Company must comply. As of June 30, 2022 and March 31, 2022, the Company had outstanding bank guarantees of $23.9 million and $25.5 million, respectively, under these lines of credit. There was no borrowing outstanding under these lines of credit as of June 30, 2022 or March 31, 2022.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001032975-22-000034:notes:89]
Commitments and Contingencies

[0001032975-22-000034:notes:90]
Product Warranties

[0001032975-22-000034:notes:91]
Changes in the Company’s warranty liability for the three months ended June 30, 2022 and 2021 were as follows (in thousands):

[0001032975-22-000034:notes:92]
|  | Three Months EndedJune 30, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| Beginning of the period | $ | 46,219 |  |  | $ | 48,832 |  |  |  |  |  |
| Provision | 6,623 |  |  | 8,446 |  |  |  |  |  |
| Settlements | (8,281) |  |  | (8,315) |  |  |  |  |  |
| Effects of foreign currency translation | (720) |  |  | 130 |  |  |  |  |  |
| End of the period | $ | 43,841 |  |  | $ | 49,093 |  |  |  |  |  |

[0001032975-22-000034:notes:93]
Indemnifications

[0001032975-22-000034:notes:94]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of June 30, 2022, no material amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

[0001032975-22-000034:notes:95]
The Company also indemnifies its current and former directors and certain of its current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. The Company is unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not limited, the obligations are conditional in nature and the facts and circumstances involved in any situation that might arise are variable.

[0001032975-22-000034:notes:96]
Legal Proceedings

[0001032975-22-000034:notes:97]
From time to time the Company is involved in claims and legal proceedings which arise in the ordinary course of its business. The Company is currently subject to several such claims and a small number of legal proceedings. The Company believes that these matters lack merit and intends to vigorously defend against them. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial position, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company's defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company's business, financial position, cash flows or results of operations in a particular period. Any claims or proceedings against the Company, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain a necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company's business.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001032975-22-000034:notes:98]
Shareholders’ Equity
Share Repurchases

[0001032975-22-000034:notes:99]
In May 2020, the Company's Board of Directors approved the 2020 share repurchase program, which authorized the Company to use up to $250.0 million to purchase up to 17.3 million of Logitech shares. The Company's share repurchase program is expected to remain in effect for a period of three years through July 27, 2023. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Purchases may be started or stopped at any time without prior notice depending on market conditions and other factors. In April 2021, the Company's Board of Directors approved an increase of $750.0 million of the 2020 share repurchase program, to an aggregate amount of $1.0 billion. The Swiss Takeover Board approved this increase and it became effective on May 21, 2021. As of June 30, 2022, $303.1 million is still available for repurchase under the 2020 repurchase program.

[0001032975-22-000034:notes:100]
In July 2022, the Company’s Board of Directors approved an increase of $500 million to the 2020 share repurchase program, to an aggregate amount of up to $1.5 billion to purchase up to 17.3 million of Logitech shares. This increase is subject to approval by the Swiss Takeover Board.

[0001032975-22-000034:notes:101]
[same as prior period, unchanged from 0001032975-22-000006:notes:106]

[0001032975-22-000034:notes:102]
[same as prior period, unchanged from 0001032975-22-000006:notes:107]

[0001032975-22-000034:notes:103]
|  |  | CumulativeTranslationAdjustment |  | DefinedBenefitPlans |  | Deferred Hedging Gains |  | Total |
| March 31, 2022 |  | $ | (102,461) |  |  | $ | (3,495) |  |  | $ | 1,833 |  |  | $ | (104,123) |  |
| Other comprehensive income (loss) |  | (21,220) |  |  | (29) |  |  | 4,538 |  |  | (16,711) |  |
| June 30, 2022 |  | $ | (123,681) |  |  | $ | (3,524) |  |  | $ | 6,371 |  |  | $ | (120,834) |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001032975-22-000034:notes:104]
[same as prior period, unchanged from 0001032975-22-000006:notes:109]

[0001032975-22-000034:notes:105]
The Company operates in a single operating segment that encompasses the design, manufacturing and marketing of peripherals for PCs, tablets and other digital platforms. Operating performance measures are provided directly to the Company's CEO, who is considered to be the Company’s Chief Operating Decision Maker. The CEO periodically reviews information such as sales and adjusted operating income (loss) to make business decisions. These operating performance measures do not include share-based compensation expense, amortization of intangible assets, acquisition-related costs and change in fair value of contingent consideration from business acquisition.

[0001032975-22-000034:notes:106]
Sales by product categories and sales channels, excluding intercompany transactions, for the three months ended June 30, 2022 and 2021 were as follows (in thousands):

[0001032975-22-000034:notes:107]
|  |  | Three Months EndedJune 30, |  |  |
|  |  | 2022 |  | 2021 |  |  |  |  |
| Pointing Devices |  | $ | 183,283 |  |  | $ | 182,878 |  |  |  |  |  |
| Keyboards & Combos |  | 227,720 |  |  | 218,357 |  |  |  |  |  |
| PC Webcams |  | 59,386 |  |  | 109,918 |  |  |  |  |  |
| Tablet & Other Accessories |  | 66,585 |  |  | 79,272 |  |  |  |  |  |
| Gaming (1) |  | 282,806 |  |  | 335,397 |  |  |  |  |  |
| Video Collaboration |  | 246,242 |  |  | 234,885 |  |  |  |  |  |
| Mobile Speakers |  | 22,310 |  |  | 28,484 |  |  |  |  |  |
| Audio & Wearables |  | 69,446 |  |  | 116,607 |  |  |  |  |  |
| Other (2) |  | 2,087 |  |  | 6,260 |  |  |  |  |  |
| Total Sales |  | $ | 1,159,865 |  |  | $ | 1,312,058 |  |  |  |  |  |

[0001032975-22-000034:notes:108]
[same as prior period, unchanged from 0001032975-22-000006:notes:113]

[0001032975-22-000034:notes:109]
(2) Other includes Smart Home.

[0001032975-22-000034:notes:110]
Sales by geographic region (based on the customers’ locations) for the three months ended June 30, 2022 and 2021 were as follows (in thousands):

[0001032975-22-000034:notes:111]
|  |  | Three Months EndedJune 30, |  |  |
|  |  | 2022 |  | 2021 |  |  |  |  |
| Americas |  | $ | 502,307 |  |  | $ | 612,566 |  |  |  |  |  |
| EMEA |  | 290,479 |  |  | 357,957 |  |  |  |  |  |
| Asia Pacific |  | 367,079 |  |  | 341,535 |  |  |  |  |  |
| Total sales |  | $ | 1,159,865 |  |  | $ | 1,312,058 |  |  |  |  |  |

[0001032975-22-000034:notes:112]
Revenue from sales to customers in the United States, Germany and China each represented 10% or more of the total consolidated sales for each of the periods presented herein. No other countries represented 10% or more of the Company’s total consolidated sales for the periods presented herein.

[0001032975-22-000034:notes:113]
Switzerland, the Company’s home domicile, represented 2% and 3% of the Company's total consolidated sales for the three months ended June 30, 2022 and 2021, respectively.

[0001032975-22-000034:notes:114]
Three and two customers of the Company each represented 10% or more of the total consolidated sales for the three months ended June 30, 2022 and 2021, respectively.

[0001032975-22-000034:notes:115]
Property, plant and equipment, net (excluding software) and right-of-use assets by geographic region were as follows (in thousands):

[0001032975-22-000034:notes:116]
|  |  | June 30, 2022 |  | March 31, 2022 |
| Americas |  | $ | 20,198 |  |  | $ | 22,578 |  |
| EMEA |  | 26,903 |  |  | 23,830 |  |
| Asia Pacific |  | 88,704 |  |  | 87,265 |  |
| Total |  | $ | 135,805 |  |  | $ | 133,673 |  |

[0001032975-22-000034:notes:117]
Property, plant and equipment, net (excluding software) and right-of-use assets in the United States and China were $19.4 million, $66.3 million, respectively, as of June 30, 2022, and $21.7 million and $66.8 million, respectively, as of March 31, 2022. Property, plant and equipment, net (excluding software) and right-of-use assets in Switzerland, the Company’s home domicile, were $13.8 million and $13.6 million as of June 30, 2022 and March 31, 2022, respectively. No other countries represented 10% or more of the Company’s total consolidated property, plant and equipment, net (excluding software) and right-of-use assets as of June 30, 2022 or March 31, 2022.
