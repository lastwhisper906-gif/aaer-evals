# LOGI 8-K — 0001032975-22-000027 filed 2022-07-26

## item codes, every 8-K on or before 2022-07-28

- 2022-07-26 0001032975-22-000027 — 2.02, 9.01
- 2022-06-29 0001032975-22-000018 — 5.02
- 2022-05-03 0001032975-22-000008 — 2.02, 9.01
- 2022-01-25 0001032975-22-000003 — 2.02, 9.01
- 2021-10-26 0001032975-21-000043 — 2.02, 9.01
- 2021-09-10 0001032975-21-000040 — 5.07, 8.01
- 2021-07-27 0001032975-21-000029 — 2.02, 9.01
- 2021-04-29 0001032975-21-000012 — 2.02, 9.01
- 2021-01-19 0001032975-21-000004 — 2.02, 9.01
- 2020-10-20 0001032975-20-000045 — 2.02, 9.01
- 2020-09-11 0001032975-20-000042 — 5.07, 8.01
- 2020-07-21 0001032975-20-000029 — 2.02, 9.01
- 2020-07-01 0001032975-20-000023 — 5.02, 8.01
- 2020-05-12 0001032975-20-000011 — 2.02, 9.01
- 2020-03-30 0001032975-20-000009 — 5.02
- 2020-01-21 0001032975-20-000002 — 2.02, 9.01
- 2019-10-22 0001032975-19-000071 — 9.01
- 2019-09-26 0001032975-19-000068 — 1.01, 7.01, 9.01
- 2019-09-06 0001032975-19-000063 — 5.07, 8.01
- 2019-07-23 0001032975-19-000046 — 2.02, 9.01
- 2019-07-23 0001032975-19-000045 — 5.02, 9.01
- 2019-07-02 0001032975-19-000036 — 5.02
- 2019-06-25 0001032975-19-000034 — 5.02
- 2019-05-03 0001032975-19-000021 — 5.02 — amendment, the index does not say of what
- 2019-04-30 0001032975-19-000017 — 2.02, 5.02, 9.01
- 2019-03-28 0001032975-19-000013 — 5.02
- 2019-01-22 0001032975-19-000004 — 2.02, 9.01
- 2018-10-23 0001032975-18-000044 — 2.02, 9.01
- 2018-09-07 0001032975-18-000040 — 5.07, 8.01
- 2018-07-31 0001032975-18-000035 — 1.01, 2.02, 2.05, 7.01, 9.01
- 2018-06-27 0001032975-18-000020 — 5.02
- 2018-05-03 0001032975-18-000013 — 2.02, 5.02, 9.01
- 2018-01-23 0001032975-18-000005 — 2.02, 9.01
- 2017-10-24 0001032975-17-000043 — 2.02, 9.01
- 2017-09-18 0001032975-17-000040 — 5.07, 8.01
- 2017-07-25 0001032975-17-000028 — 2.02, 9.01
- 2017-07-12 0001032975-17-000022 — 1.01
- 2017-04-26 0001032975-17-000012 — 2.02, 9.01
- 2017-01-25 0001032975-17-000002 — 2.02, 9.01
- 2016-10-26 0001032975-16-000103 — 2.02, 9.01
- 2016-09-13 0001032975-16-000101 — 5.07, 8.01
- 2016-07-28 0001032975-16-000092 — 2.02, 9.01
- 2016-06-30 0001032975-16-000087 — 5.02
- 2016-04-28 0001032975-16-000077 — 2.02, 9.01
- 2016-04-14 0001032975-16-000073 — 1.01, 7.01, 9.01
- 2016-01-21 0001032975-16-000064 — 2.02, 9.01
- 2016-01-04 0001032975-16-000061 — 1.01, 2.01, 9.01
- 2015-12-23 0001032975-15-000059 — 5.02
- 2015-10-22 0001032975-15-000047 — 2.02, 9.01
- 2015-09-11 0001032975-15-000044 — 5.07, 8.01
- 2015-07-24 0001032975-15-000034 — 2.05 — amendment of 0001032975-15-000030
- 2015-07-23 0001032975-15-000030 — 2.02, 9.01
- 2015-06-25 0001032975-15-000025 — 5.02
- 2015-05-14 0001032975-15-000011 — 8.01, 9.01
- 2015-04-23 0001032975-15-000008 — 2.02, 2.05
- 2015-01-22 0001628280-15-000191 — 2.02, 8.01
- 2014-12-23 0001193125-14-450908 — 5.02, 5.07, 8.01
- 2014-11-25 0001193125-14-425233 — 3.01
- 2014-11-13 0001193125-14-411303 — 4.01, 9.01
- 2014-10-23 0001104659-14-073164 — 2.02, 9.01
- 2014-09-04 0001193125-14-331214 — 4.02, 9.01
- 2014-08-18 0001193125-14-313346 — 3.01, 9.01
- 2014-07-24 0001104659-14-053065 — 2.02, 9.01
- 2014-06-05 0001193125-14-226177 — 3.01, 9.01
- 2014-05-22 0001193125-14-208777 — 8.01, 9.01
- 2014-04-24 0001104659-14-029650 — 2.02, 9.01
- 2014-01-23 0001104659-14-003619 — 2.02, 9.01
- 2013-10-24 0001104659-13-077404 — 2.02, 9.01
- 2013-09-09 0001193125-13-361441 — 5.02, 5.07, 8.01, 9.01
- 2013-09-06 0001193125-13-359930 — 5.02, 9.01
- 2013-08-02 0001193125-13-317343 — 5.02
- 2013-07-25 0001104659-13-056372 — 2.02, 9.01
- 2013-06-28 0001193125-13-277394 — 5.02, 9.01
- 2013-06-20 0001193125-13-265914 — 8.01, 9.01
- 2013-04-25 0001104659-13-032570 — 2.02, 9.01
- 2013-04-17 0001193125-13-158923 — 5.02, 9.01
- 2013-03-01 0001193125-13-085804 — 2.05
- 2013-01-24 0001104659-13-004214 — 2.02, 9.01
- 2013-01-02 0001193125-13-000058 — 5.02
- 2012-10-25 0001104659-12-070966 — 2.02, 9.01
- 2012-09-11 0001193125-12-388070 — 5.02, 5.07, 8.01, 9.01
- 2012-08-22 0001193125-12-364167 — 5.02, 8.01, 9.01
- 2012-07-26 0001104659-12-051084 — 2.02, 9.01
- 2012-06-08 0001193125-12-264132 — 2.05, 9.01 — amendment, the index does not say of what
- 2012-04-26 0001193125-12-183657 — 5.02, 9.01
- 2012-04-26 0001104659-12-028470 — 2.02, 2.05, 9.01
- 2012-03-15 0001193125-12-115954 — 5.02, 9.01
- 2012-01-26 0001104659-12-004014 — 2.02, 9.01
- 2012-01-04 0001193125-12-002212 — 1.01, 2.03, 9.01
- 2011-10-27 0001104659-11-058150 — 2.02, 9.01
- 2011-09-12 0001193125-11-245931 — 5.07
- 2011-07-28 0001193125-11-200929 — 5.02, 9.01
- 2011-07-28 0001193125-11-199704 — 2.02, 9.01
- 2011-04-28 0001193125-11-112669 — 2.02, 9.01
- 2011-03-24 0001193125-11-076483 — 5.02, 9.01
- 2011-01-27 0001032975-11-000003 — 9.01
- 2010-10-28 0001032975-10-000032 — 9.01
- 2010-09-13 0001032975-10-000022 — 5.07
- 2010-07-29 0001032975-10-000010 — 2.02, 9.01
- 2010-06-10 0001193125-10-136877 — 5.02, 9.01
- 2010-05-03 0001193125-10-104337 — 5.02
- 2010-04-29 0001032975-10-000008 — 2.02, 9.01
- 2010-02-19 0001032975-10-000006 — 9.01 — amendment of 0001193125-09-252416
- 2010-01-21 0001032975-10-000002 — 2.02, 9.01
- 2009-12-14 0001193125-09-252416 — 2.01, 9.01
- 2009-11-17 0001032975-09-000023 — 1.01
- 2009-10-22 0001032975-09-000018 — 9.01
- 2009-09-22 0001193125-09-195545 — 5.02, 9.01
- 2009-09-03 0001032975-09-000013 — 8.01
- 2009-07-23 0001140361-09-016802 — 2.02, 9.01
- 2009-06-01 0001193125-09-122550 — 5.02
- 2009-04-23 0001193125-09-085054 — 2.02, 9.01
- 2009-04-02 0001193125-09-071272 — 5.02, 9.01
- 2009-01-20 0001193125-09-008454 — 2.05 — amendment of 0001193125-09-002609
- 2009-01-20 0001193125-09-007902 — 2.02, 9.01
- 2009-01-07 0001193125-09-002609 — 2.05, 9.01
- 2009-01-07 0001193125-09-002370 — 5.02, 9.01
- 2008-12-09 0001193125-08-250543 — 5.02, 9.01
- 2008-10-21 0001193125-08-213212 — 2.02, 9.01
- 2008-07-22 0001193125-08-154721 — 2.02, 9.01
- 2008-06-24 0001193125-08-139163 — 5.03, 9.01
- 2008-05-13 0001193125-08-113263 — 5.02, 9.01
- 2008-04-22 0001193125-08-086176 — 2.02, 9.01

## late-filing notifications on or before 2022-07-28

- 2015-06-02 0001032975-15-000020 — NT 10-K, for the period ended 2015-03-31
- 2014-11-06 0001193125-14-401306 — NT 10-Q, for the period ended 2014-09-30
- 2014-07-24 0001193125-14-277575 — NT 10-Q, for the period ended 2014-06-30
- 2014-05-22 0001193125-14-208712 — NT 10-K, for the period ended 2014-03-31
- 2009-08-06 0001032975-09-000006 — NT 10-Q, for the period ended 2009-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001032975-22-000027:8k_2_02:1]
EX-99.1
2
exhibit991q1fy23.htm
EX-99.1

[0001032975-22-000027:8k_2_02:2]
Document

[0001032975-22-000027:8k_2_02:3]
Exhibit 99.1

[0001032975-22-000027:8k_2_02:4]
Editorial Contacts:

[0001032975-22-000027:8k_2_02:5]
Nate Melihercik, Head of Global Investor Relations - ir@logitech.com

[0001032975-22-000027:8k_2_02:6]
Nicole Kenyon, Head of Global Corporate & Employee Communications - USA +1 (510) 988-8553

[0001032975-22-000027:8k_2_02:7]
Ben Starkie, Corporate Communications - Europe +41 (0) 79-292-3499

[0001032975-22-000027:8k_2_02:8]
Logitech Announces Q1 FY 2023 Results

[0001032975-22-000027:8k_2_02:9]
Company Updates FY 2023 Outlook; Expands Share Buyback Authorization

[0001032975-22-000027:8k_2_02:10]
LAUSANNE, Switzerland, July 26, 2022 and NEWARK, Calif., July 25, 2022 — SIX Swiss Exchange Ad hoc announcement pursuant to Art. 53 LR —  Logitech International (SIX: LOGN) (Nasdaq: LOGI) today announced financial results for the first quarter of Fiscal Year 2023.

[0001032975-22-000027:8k_2_02:11]
•Sales were $1.16 billion, down 12 percent in US dollars and 9 percent in constant currency, compared to Q1 of the prior year. This performance reflects a challenging macroeconomic environment for the industry and compares against a quarter which grew 66 percent last year in US dollars.

[0001032975-22-000027:8k_2_02:12]
•Category sales in US dollars grew 4 percent in Keyboards & Combos, were essentially flat in Pointing Devices and grew 5 percent in Video Collaboration compared to Q1 of the prior year. Sales in these categories in constant currency grew 7 percent, 3 percent and 7 percent, respectively. Gaming sales declined 16 percent in US dollars and 13 percent in constant currency compared to Q1 of the prior year.

[0001032975-22-000027:8k_2_02:13]
•GAAP operating income declined 43 percent to $115 million, compared to $203 million and 143 percent growth in the same quarter a year ago. Non-GAAP operating income declined 38 percent to $146 million, compared to $235 million in the same quarter a year ago.

[0001032975-22-000027:8k_2_02:14]
•GAAP earnings per share (EPS) declined 44 percent to $0.61, compared to $1.09 and 160 percent growth in the same quarter a year ago. Non-GAAP EPS declined 39 percent to $0.74, compared to $1.22 in the same quarter a year ago.

[0001032975-22-000027:8k_2_02:15]
“While macroeconomic challenges affected our performance this quarter, I am encouraged by the continued growth in Video Collaboration, Keyboards & Combos and Pointing Devices as hybrid and return-to-work trends continue to take shape,” said Bracken Darrell, Logitech president and chief executive officer. “This quarter, we demonstrated our operational focus in the face of challenging conditions, and off the back of exceptional growth these past two years. While we will cut back our spending given the current environment, our strong innovation engine paired with secular growth trends - hybrid work, video everywhere, gaming and digital content creation - position us well for the future.”

[0001032975-22-000027:8k_2_02:16]
Outlook

[0001032975-22-000027:8k_2_02:17]
Given the current challenging conditions, Logitech reduced its Fiscal Year 2023 outlook to between negative 8 percent and negative 4 percent sales growth in constant currency, and between $650 million and $750 million in non-GAAP operating income. The Company’s previous outlook was between 2 and 4

[0001032975-22-000027:8k_2_02:18]
percent sales growth in constant currency, and $875 million to $925 million in non-GAAP operating income.

[0001032975-22-000027:8k_2_02:19]
Increased Share Buyback Authorization

[0001032975-22-000027:8k_2_02:20]
Logitech’s board of directors has approved an increased share buyback authorization up to $1.5 billion. This expands the Company’s current $1 billion, three-year share buyback authorization. To date, the Company has repurchased approximately $697 million of shares in the current program. Subject to approval from the Swiss Takeover Board, the increase will provide for a total authorization of approximately $800 million remaining for repurchases over the next 12 months of the program ending in July 2023.

[0001032975-22-000027:8k_2_02:21]
Prepared Remarks Available Online

[0001032975-22-000027:8k_2_02:22]
Logitech has made its prepared written remarks for the financial results videoconference available online on the Logitech corporate website at http://ir.logitech.com.

[0001032975-22-000027:8k_2_02:23]
Financial Results Videoconference and Webcast

[0001032975-22-000027:8k_2_02:24]
Logitech will hold a financial results videoconference to discuss the results for Q1 Fiscal Year 2023 on Tuesday, July 26, 2022 at 8:30 a.m. Eastern Standard Time and 2:30 p.m. Central European Time. A livestream of the event will be available on the Logitech corporate website at http://ir.logitech.com.

[0001032975-22-000027:8k_2_02:25]
Use of Non-GAAP Financial Information and Constant Currency

[0001032975-22-000027:8k_2_02:26]
To facilitate comparisons to Logitech’s historical results, Logitech has included non-GAAP adjusted measures, which exclude share-based compensation expense, amortization of intangible assets, acquisition-related costs, change in fair value of contingent consideration for business acquisition, gain on investments, non-GAAP income tax adjustment, and other items detailed under “Supplemental Financial Information” after the tables below. Logitech also presents percentage sales growth in constant currency, a non-GAAP measure, to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales. Logitech believes this information, used together with the GAAP financial information, will help investors to evaluate its current period performance and trends in its business. With respect to the Company’s outlook for non-GAAP operating income, most of these excluded amounts pertain to events that have not yet occurred and are not currently possible to estimate with a reasonable degree of accuracy. Therefore, no reconciliation to the GAAP amounts has been provided for the Fiscal Year 2023 outlook.

[0001032975-22-000027:8k_2_02:27]
Public Dissemination of Certain Information

[0001032975-22-000027:8k_2_02:28]
Logitech webcasts its earnings calls, and certain events Logitech participates in or hosts, with members of the investment community on its investor relations website at https://ir.logitech.com. Additionally, Logitech provides notifications of news or announcements regarding its operations and financial performance, including its filings with the Securities and Exchange Commission (SEC), investor events,

[0001032975-22-000027:8k_2_02:29]
and press and earnings releases as part of its investor relations website. Logitech intends to use its investor relations website as means of disclosing material nonpublic information and for complying with its disclosure obligations under Regulation FD. Logitech’s corporate governance information also is available on its investor relations website.

[0001032975-22-000027:8k_2_02:30]
About Logitech

[0001032975-22-000027:8k_2_02:31]
Logitech helps all people pursue their passions by designing experiences so everyone can create, achieve, and enjoy more. Logitech designs and creates products that bring people together through computing, gaming, video, streaming and creating, and music. Brands of Logitech include Logitech, Logitech G, ASTRO Gaming, Streamlabs, Blue Microphones and Ultimate Ears. Founded in 1981, and headquartered in Lausanne, Switzerland, Logitech International is a Swiss public company listed on the SIX Swiss Exchange (LOGN) and on the Nasdaq Global Select Market (LOGI). Find Logitech at www.logitech.com, the company blog or @Logitech.

[0001032975-22-000027:8k_2_02:32]
# # #

[0001032975-22-000027:8k_2_02:33]
Note that unless noted otherwise, comparisons are year over year.

[0001032975-22-000027:8k_2_02:34]
Logitech and other Logitech marks are trademarks or registered trademarks of Logitech Europe S.A. and/or its affiliates in the U.S. and other countries. All other trademarks are the property of their respective owners. For more information about Logitech and its products, visit the company’s website at www.logitech.com.

[0001032975-22-000027:8k_2_02:35]
(LOGIIR)

[0001032975-22-000027:8k_2_02:36]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months EndedJune 30, |  |  |
| GAAP CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  | 2022 |  | 2021 |  |  |  |  |
| Net sales |  | $ | 1,159,865 |  |  | $ | 1,312,058 |  |  |  |  |  |
| Cost of goods sold |  | 697,220 |  |  | 739,066 |  |  |  |  |  |
| Amortization of intangible assets |  | 3,042 |  |  | 4,066 |  |  |  |  |  |
| Gross profit |  | 459,603 |  |  | 568,926 |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Marketing and selling |  | 229,378 |  |  | 252,314 |  |  |  |  |  |
| Research and development |  | 75,517 |  |  | 69,246 |  |  |  |  |  |
| General and administrative |  | 35,860 |  |  | 40,542 |  |  |  |  |  |
| Amortization of intangible assets and acquisition-related costs |  | 3,369 |  |  | 5,217 |  |  |  |  |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | (1,474) |  |  |  |  |  |
| Total operating expenses |  | 344,124 |  |  | 365,845 |  |  |  |  |  |
| Operating income |  | 115,479 |  |  | 203,081 |  |  |  |  |  |
| Interest income |  | 1,449 |  |  | 316 |  |  |  |  |  |
| Other income (expense), net |  | 5,624 |  |  | 8,435 |  |  |  |  |  |
| Income before income taxes |  | 122,552 |  |  | 211,832 |  |  |  |  |  |
| Provision for income taxes |  | 21,716 |  |  | 24,991 |  |  |  |  |  |
| Net income |  | $ | 100,836 |  |  | $ | 186,841 |  |  |  |  |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.61 |  |  | $ | 1.11 |  |  |  |  |  |
| Diluted |  | $ | 0.61 |  |  | $ | 1.09 |  |  |  |  |  |
| Weighted average shares used to compute net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | 164,679 |  |  | 168,372 |  |  |  |  |  |
| Diluted |  | 166,406 |  |  | 172,020 |  |  |  |  |  |

[0001032975-22-000027:8k_2_02:37]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
|  |  | June 30, |  | March 31, |  |  |  |  |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  | 2022 |  | 2022 |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,106,657 |  |  | $ | 1,328,716 |  |  |  |  |  |
| Accounts receivable, net |  | 706,886 |  |  | 675,604 |  |  |  |  |  |
| Inventories |  | 917,356 |  |  | 933,124 |  |  |  |  |  |
| Other current assets |  | 126,689 |  |  | 135,478 |  |  |  |  |  |
| Total current assets |  | 2,857,588 |  |  | 3,072,922 |  |  |  |  |  |
| Non-current assets: |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  | 112,240 |  |  | 109,807 |  |  |  |  |  |
| Goodwill |  | 451,209 |  |  | 448,175 |  |  |  |  |  |
| Other intangible assets, net |  | 79,820 |  |  | 83,779 |  |  |  |  |  |
| Other assets |  | 328,855 |  |  | 320,722 |  |  |  |  |  |
| Total assets |  | $ | 3,829,712 |  |  | $ | 4,035,405 |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 558,983 |  |  | $ | 636,306 |  |  |  |  |  |
| Accrued and other current liabilities |  | 693,784 |  |  | 784,848 |  |  |  |  |  |
| Total current liabilities |  | 1,252,767 |  |  | 1,421,154 |  |  |  |  |  |
| Non-current liabilities: |  |  |  |  |  |  |  |  |
| Income taxes payable |  | 82,887 |  |  | 83,380 |  |  |  |  |  |
| Other non-current liabilities |  | 131,700 |  |  | 132,133 |  |  |  |  |  |
| Total liabilities |  | 1,467,354 |  |  | 1,636,667 |  |  |  |  |  |
| Shareholders’ equity: |  |  |  |  |  |  |  |  |
| Registered shares, CHF 0.25 par value: |  | 30,148 |  |  | 30,148 |  |  |  |  |  |
| Issued shares — 173,106 at June 30, 2022 and March 31, 2022 |  |  |  |  |  |  |  |  |
| Additional shares that may be issued out of conditional capitals — 50,000 at June 30,2022 and March 31, 2022 |  |  |  |  |  |  |  |  |
| Additional shares that may be issued out of authorized capital — 17,311 at June 30, 2022 and March 31, 2022 |  |  |  |  |  |  |  |  |
| Additional paid-in capital |  | 98,800 |  |  | 129,925 |  |  |  |  |  |
| Shares in treasury, at cost — 9,051 at June 30, 2022 and 7,855 at March 31, 2022 |  | (722,273) |  |  | (632,893) |  |  |  |  |  |
| Retained earnings |  | 3,076,517 |  |  | 2,975,681 |  |  |  |  |  |
| Accumulated other comprehensive loss |  | (120,834) |  |  | (104,123) |  |  |  |  |  |
| Total shareholders’ equity |  | 2,362,358 |  |  | 2,398,738 |  |  |  |  |  |
| Total liabilities and shareholders’ equity |  | $ | 3,829,712 |  |  | $ | 4,035,405 |  |  |  |  |  |

[0001032975-22-000027:8k_2_02:38]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months EndedJune 30, |  |  |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |  | 2022 |  | 2021 |  |  |  |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 100,836 |  |  | $ | 186,841 |  |  |  |  |  |
| Adjustments to reconcile net income to net cash used in operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  | 18,626 |  |  | 20,462 |  |  |  |  |  |
| Amortization of intangible assets |  | 6,229 |  |  | 8,843 |  |  |  |  |  |
| Gain on investments |  | (11,357) |  |  | (1,071) |  |  |  |  |  |
| Share-based compensation expense |  | 23,690 |  |  | 23,651 |  |  |  |  |  |
| Deferred income taxes |  | 265 |  |  | (4,158) |  |  |  |  |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | (1,474) |  |  |  |  |  |
| Other |  | (124) |  |  | 1,045 |  |  |  |  |  |
| Changes in assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | (44,572) |  |  | 73,308 |  |  |  |  |  |
| Inventories |  | (324) |  |  | (115,166) |  |  |  |  |  |
| Other assets |  | 4,932 |  |  | (30,796) |  |  |  |  |  |
| Accounts payable |  | (70,034) |  |  | (115,620) |  |  |  |  |  |
| Accrued and other liabilities |  | (63,835) |  |  | (160,835) |  |  |  |  |  |
| Net cash used in operating activities |  | (35,668) |  |  | (114,970) |  |  |  |  |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  | (19,563) |  |  | (24,514) |  |  |  |  |  |
| Investment in privately held companies |  | (2,088) |  |  | (501) |  |  |  |  |  |
| Acquisitions, net of cash acquired |  | (5,839) |  |  | (15,586) |  |  |  |  |  |
| Purchases of deferred compensation investments |  | (922) |  |  | (1,091) |  |  |  |  |  |
| Proceeds from sales of deferred compensation investments |  | 943 |  |  | 1,345 |  |  |  |  |  |
| Net cash used in investing activities |  | (27,469) |  |  | (40,347) |  |  |  |  |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Purchases of registered shares |  | (120,619) |  |  | (54,872) |  |  |  |  |  |
| Proceeds from exercises of stock options and purchase rights |  | — |  |  | 2,750 |  |  |  |  |  |
| Tax withholdings related to net share settlements of restricted stock units |  | (24,144) |  |  | (50,411) |  |  |  |  |  |
| Net cash used in financing activities |  | (144,763) |  |  | (102,533) |  |  |  |  |  |
| Effect of exchange rate changes on cash and cash equivalents |  | (14,159) |  |  | 5,244 |  |  |  |  |  |
| Net decrease in cash and cash equivalents |  | (222,059) |  |  | (252,606) |  |  |  |  |  |
| Cash and cash equivalents, beginning of the period |  | 1,328,716 |  |  | 1,750,327 |  |  |  |  |  |
| Cash and cash equivalents, end of the period |  | $ | 1,106,657 |  |  | $ | 1,497,721 |  |  |  |  |  |

[0001032975-22-000027:8k_2_02:39]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three Months EndedJune 30, |  |  |
| NET SALES |  | 2022 |  | 2021 |  | Change |  |  |  |  |  |  |
| Net sales by product category: |  |  |  |  |  |  |  |  |  |  |  |  |
| Pointing Devices |  | $ | 183,283 |  |  | $ | 182,878 |  |  | — | % |  |  |  |  |  |  |
| Keyboards & Combos |  | 227,720 |  |  | 218,357 |  |  | 4 |  |  |  |  |  |  |  |
| PC Webcams |  | 59,386 |  |  | 109,918 |  |  | (46) |  |  |  |  |  |  |  |
| Tablet & Other Accessories |  | 66,585 |  |  | 79,272 |  |  | (16) |  |  |  |  |  |  |  |
| Gaming (1) |  | 282,806 |  |  | 335,397 |  |  | (16) |  |  |  |  |  |  |  |
| Video Collaboration |  | 246,242 |  |  | 234,885 |  |  | 5 |  |  |  |  |  |  |  |
| Mobile Speakers |  | 22,310 |  |  | 28,484 |  |  | (22) |  |  |  |  |  |  |  |
| Audio & Wearables |  | 69,446 |  |  | 116,607 |  |  | (40) |  |  |  |  |  |  |  |
| Other (2) |  | 2,087 |  |  | 6,260 |  |  | (67) |  |  |  |  |  |  |  |
| Total Sales |  | $ | 1,159,865 |  |  | $ | 1,312,058 |  |  | (12) | % |  |  |  |  |  |  |

[0001032975-22-000027:8k_2_02:40]
(1) Gaming includes streaming services revenue generated by Streamlabs.

[0001032975-22-000027:8k_2_02:41]
(2) Other includes Smart Home.

[0001032975-22-000027:8k_2_02:42]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three Months EndedJune 30, |  |  |
| GAAP TO NON-GAAP RECONCILIATION (A) |  | 2022 |  | 2021 |  |  |  |  |
| Gross profit - GAAP |  | $ | 459,603 |  |  | $ | 568,926 |  |  |  |  |  |
| Share-based compensation expense |  | 1,461 |  |  | 1,369 |  |  |  |  |  |
| Amortization of intangible assets |  | 3,042 |  |  | 4,066 |  |  |  |  |  |
| Gross profit - Non-GAAP |  | $ | 464,106 |  |  | $ | 574,361 |  |  |  |  |  |
| Gross margin - GAAP |  | 39.6 | % |  | 43.4 | % |  |  |  |  |
| Gross margin - Non-GAAP |  | 40.0 | % |  | 43.8 | % |  |  |  |  |
| Operating expenses - GAAP |  | $ | 344,124 |  |  | $ | 365,845 |  |  |  |  |  |
| Less: Share-based compensation expense |  | 22,229 |  |  | 22,282 |  |  |  |  |  |
| Less: Amortization of intangible assets and acquisition-related costs |  | 3,369 |  |  | 5,217 |  |  |  |  |  |
| Less: Change in fair value of contingent consideration for business acquisition |  | — |  |  | (1,474) |  |  |  |  |  |
| Operating expenses - Non-GAAP |  | $ | 318,526 |  |  | $ | 339,820 |  |  |  |  |  |
| % of net sales - GAAP |  | 29.7 | % |  | 27.9 | % |  |  |  |  |
| % of net sales - Non - GAAP |  | 27.5 | % |  | 25.9 | % |  |  |  |  |
| Operating income - GAAP |  | $ | 115,479 |  |  | $ | 203,081 |  |  |  |  |  |
| Share-based compensation expense |  | 23,690 |  |  | 23,651 |  |  |  |  |  |
| Amortization of intangible assets and acquisition-related costs |  | 6,411 |  |  | 9,283 |  |  |  |  |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | (1,474) |  |  |  |  |  |
| Operating income - Non - GAAP |  | $ | 145,580 |  |  | $ | 234,541 |  |  |  |  |  |
| % of net sales - GAAP |  | 10.0 | % |  | 15.5 | % |  |  |  |  |
| % of net sales - Non - GAAP |  | 12.6 | % |  | 17.9 | % |  |  |  |  |
| Net income - GAAP |  | $ | 100,836 |  |  | $ | 186,841 |  |  |  |  |  |
| Share-based compensation expense |  | 23,690 |  |  | 23,651 |  |  |  |  |  |
| Amortization of intangible assets and acquisition-related costs |  | 6,411 |  |  | 9,283 |  |  |  |  |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | (1,474) |  |  |  |  |  |
| Gain on investments |  | (11,357) |  |  | (1,071) |  |  |  |  |  |
| Non-GAAP income tax adjustment |  | 3,459 |  |  | (7,416) |  |  |  |  |  |
| Net income - Non - GAAP |  | $ | 123,039 |  |  | $ | 209,814 |  |  |  |  |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  | $ | 0.61 |  |  | $ | 1.09 |  |  |  |  |  |
| Diluted - Non - GAAP |  | $ | 0.74 |  |  | $ | 1.22 |  |  |  |  |  |
| Shares used to compute net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP and Non - GAAP |  | 166,406 |  |  | 172,020 |  |  |  |  |  |

[0001032975-22-000027:8k_2_02:43]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three Months EndedJune 30, |  |  |
| SHARE-BASED COMPENSATION EXPENSE |  | 2022 |  | 2021 |  |  |  |  |
| Share-based Compensation Expense |  |  |  |  |  |  |  |  |
| Cost of goods sold |  | $ | 1,461 |  |  | $ | 1,369 |  |  |  |  |  |
| Marketing and selling |  | 9,797 |  |  | 8,530 |  |  |  |  |  |
| Research and development |  | 5,532 |  |  | 5,061 |  |  |  |  |  |
| General and administrative |  | 6,900 |  |  | 8,691 |  |  |  |  |  |
| Total share-based compensation expense |  | 23,690 |  |  | 23,651 |  |  |  |  |  |
| Income tax benefit |  | (4,322) |  |  | (16,594) |  |  |  |  |  |
| Total share-based compensation expense, net of income tax benefit |  | $ | 19,368 |  |  | $ | 7,057 |  |  |  |  |  |

[0001032975-22-000027:8k_2_02:44]
*Note: These preliminary results for the three months ended June 30, 2022 are subject to adjustments, including subsequent events that may occur through the date of filing our Quarterly Report on Form 10-Q.

[0001032975-22-000027:8k_2_02:45]
(A) Non-GAAP Financial Measures

[0001032975-22-000027:8k_2_02:46]
To supplement our condensed consolidated financial results prepared in accordance with GAAP, we use a number of financial measures, both GAAP and non-GAAP, in analyzing and assessing our overall business performance, for making operating decisions and for forecasting and planning future periods. We consider the use of non-GAAP financial measures helpful in assessing our current financial performance, ongoing operations and prospects for the future as well as understanding financial and business trends relating to our financial condition and results of operations.

[0001032975-22-000027:8k_2_02:47]
While we use non-GAAP financial measures as a tool to enhance our understanding of certain aspects of our financial performance and to provide incremental insight into the underlying factors and trends affecting both our performance and our cash-generating potential, we do not consider these measures to be a substitute for, or superior to, the information provided by GAAP financial measures. Consistent with this approach, we believe that disclosing non-GAAP financial measures to the readers of our financial statements provides useful supplemental data that, while not a substitute for GAAP financial measures, can offer insight in the review of our financial and operational performance and enables investors to more fully understand trends in our current and future performance. In assessing our business during the quarter ended June 30, 2022 and prior periods presented, we excluded items in the following general categories, each of which are described below:

[0001032975-22-000027:8k_2_02:48]
Share-based compensation expense. We believe that providing non-GAAP measures excluding share-based compensation expense, in addition to the GAAP measures, allows for a more transparent comparison of our financial results from period to period. We prepare and maintain our budgets and forecasts for future periods on a basis consistent with this non-GAAP financial measure. Further, companies use a variety of types of equity awards as well as a variety of methodologies, assumptions and estimates to determine share-based compensation expense. We believe that excluding share-based compensation expense enhances our ability and the ability of investors to understand the impact of non-cash share-based compensation on our operating results and to compare our results against the results of other companies.

[0001032975-22-000027:8k_2_02:49]
Amortization of intangible assets. We incur intangible asset amortization expense, primarily in connection with our acquisitions of various businesses and technologies. The amortization of purchased intangibles varies depending on the level of acquisition activity. We exclude these various charges in budgeting, planning and forecasting future periods and we believe that providing the non-GAAP measures excluding these various non-cash charges, as well as the GAAP measures, provides additional insight when comparing our gross profit, operating expenses, and financial results from period to period.

[0001032975-22-000027:8k_2_02:50]
Acquisition-related costs and change in fair value of contingent consideration for business acquisition.  We incurred expenses and credits in connection with our acquisitions which we generally would not have otherwise incurred in the periods presented as a part of our continuing operations. Acquisition related costs include all incremental expenses incurred to effect a business combination. Fair value of contingent consideration is associated with our estimates of the value of earn-outs in connection with certain acquisitions. We believe that providing the non-GAAP measures excluding these costs and credits, as well as the GAAP measures, assists our investors because such costs are not reflective of our ongoing operating results.

[0001032975-22-000027:8k_2_02:51]
Loss (gain) on investments. We recognize losses (gains) related to our investments in various companies, which vary depending on the operational and financial performance of the companies in which we invest. These amounts include our losses (earnings) on equity method investments, investment impairments and losses (gains) resulting from sales or other events related to our investments. We believe that providing the non-GAAP measures excluding these items, as well as the GAAP measures, assists our investors because such losses (gains) are not reflective of our ongoing operations.

[0001032975-22-000027:8k_2_02:52]
Non-GAAP income tax adjustment.  Non-GAAP income tax adjustment primarily measures the income tax effect of non-GAAP adjustments excluded above and other events; the determination of which is based upon the nature of the underlying items, the mix of income and losses in jurisdictions and the relevant tax rates in which we operate.

[0001032975-22-000027:8k_2_02:53]
Each of the non-GAAP financial measures described above, and used in this press release, should not be considered in isolation from, or as a substitute for, a measure of financial performance prepared in accordance with GAAP. Further, investors are cautioned that there are inherent limitations associated with the use of each of these non-GAAP financial measures as an analytical tool. In particular, these non-GAAP financial measures are not based on a comprehensive set of accounting rules or principles and many of the adjustments to the GAAP financial measures reflect the exclusion of items that are recurring and may be reflected in the Company’s financial results for the foreseeable future. We compensate for these limitations by providing specific information in the reconciliation included in this press release regarding the GAAP amounts excluded from the non-GAAP financial measures. In addition, as noted above, we evaluate the non-GAAP financial measures together with the most directly comparable GAAP financial information.

[0001032975-22-000027:8k_2_02:54]
Additional Supplemental Financial Information - Constant Currency

[0001032975-22-000027:8k_2_02:55]
In addition, Logitech presents percentage sales growth in constant currency to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales.
