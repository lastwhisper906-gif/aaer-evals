# LOGI note change history — 0001032975-22-000006 → 0001032975-22-000034


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-07-28):
[0001032975-22-000034:note_history:1]
Changes in the Company’s warranty liability for the three months ended June 30, 2022 and 2021 were as follows (in thousands):
  (was, 2022-01-27, similarity 0.9231):
[0001032975-22-000006:note_history:1]
Changes in the Company’s warranty liability for the three and nine months ended December 31, 2021 and 2020 were as follows (in thousands):

- changed (2022-07-28):
[0001032975-22-000034:note_history:2]
|  | Three Months EndedJune 30, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| Beginning of the period | $ | 46,219 |  |  | $ | 48,832 |  |  |  |  |  |
| Provision | 6,623 |  |  | 8,446 |  |  |  |  |  |
| Settlements | (8,281) |  |  | (8,315) |  |  |  |  |  |
| Effects of foreign currency translation | (720) |  |  | 130 |  |  |  |  |  |
| End of the period | $ | 43,841 |  |  | $ | 49,093 |  |  |  |  |  |
  (was, 2022-01-27, similarity 0.7368):
[0001032975-22-000006:note_history:2]
|  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Beginning of the period | $ | 49,173 |  |  | $ | 41,782 |  |  | $ | 48,832 |  |  | $ | 40,039 |  |
| Provision | 6,962 |  |  | 13,692 |  |  | 23,503 |  |  | 28,575 |  |
| Settlements | (8,056) |  |  | (8,371) |  |  | (24,219) |  |  | (22,073) |  |
| Effects of foreign currency translation | (144) |  |  | 489 |  |  | (181) |  |  | 1,051 |  |
| End of the period | $ | 47,935 |  |  | $ | 47,592 |  |  | $ | 47,935 |  |  | $ | 47,592 |  |

- changed (2022-07-28):
[0001032975-22-000034:note_history:3]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of June 30, 2022, no material amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.
  (was, 2022-01-27, similarity 0.657):
[0001032975-22-000006:note_history:3]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including

- removed (2022-07-28):
[0001032975-22-000006:note_history:4]
reasonable attorneys’ fees. As of December 31, 2021, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-07-28):
[0001032975-22-000034:note_history:5]
Logitech International S.A, together with its consolidated subsidiaries ("Logitech" or the "Company"), designs, manufactures and markets products that help connect people to digital and cloud experiences. Forty years ago, Logitech created products to improve experiences around the personal computer ("PC") platform, and today it is a multi-brand, multi-category company designing products that enable better experiences consuming, sharing and creating any digital content such as computing, gaming, video, and music, whether it is on a computer, mobile device or in the cloud.
  (was, 2022-01-27, similarity 0.8797):
[0001032975-22-000006:note_history:5]
Logitech International S.A, together with its consolidated subsidiaries ("Logitech" or the "Company"), designs, manufactures and markets products that have an everyday place in people's lives, connecting them to the digital experiences they care about. Forty years ago, Logitech created products to improve experiences around the personal PC platform, and today it is a multi-brand, multi-category company designing products that enable better experiences consuming, sharing and creating any digital content such as computing, gaming, video, and music, whether it is on a computer, mobile device or in the cloud.

- changed (2022-07-28):
[0001032975-22-000034:note_history:6]
The Company sells its products to a broad network of domestic and international customers, including direct sales to retailers, e-tailers and enterprise customers, and indirect sales through distributors.
  (was, 2022-01-27, similarity 0.9223):
[0001032975-22-000006:note_history:6]
The Company sells its products to a broad network of domestic and international customers, including direct sales to retailers and e-tailers, and indirect sales through distributors.

- changed (2022-07-28):
[0001032975-22-000034:note_history:7]
Logitech was founded in Switzerland in 1981 and Logitech International S.A. has been the parent holding company of Logitech since 1988. Logitech International S.A. is a Swiss holding company with its registered office in Hautemorges, Switzerland, and headquarters in Lausanne, Switzerland, which conducts its business through subsidiaries in the Americas, Europe, Middle East and Africa ("EMEA") and Asia Pacific. Shares of Logitech International S.A. are listed on both the SIX Swiss Exchange under the trading symbol LOGN and the Nasdaq Global Select Market under the trading symbol LOGI.
  (was, 2022-01-27, similarity 0.9879):
[0001032975-22-000006:note_history:7]
Logitech was founded in Switzerland in 1981 and Logitech International S.A. has been the parent holding company of Logitech since 1988. Logitech International S.A. is a Swiss holding company with its registered office in Apples, Switzerland and headquarters in Lausanne, Switzerland, which conducts its business through subsidiaries in the Americas, Europe, Middle East and Africa ("EMEA") and Asia Pacific. Shares of Logitech International S.A. are listed on both the SIX Swiss Exchange under the trading symbol LOGN and the Nasdaq Global Select Market under the trading symbol LOGI.

- changed (2022-07-28):
[0001032975-22-000034:note_history:8]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three months ended June 30, 2022 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2023, or any future periods.
  (was, 2022-01-27, similarity 0.9573):
[0001032975-22-000006:note_history:8]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and nine months ended December 31, 2021 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2022, or any future periods.

- changed (2022-07-28):
[0001032975-22-000034:note_history:9]
Other than the recent accounting pronouncements adopted and discussed below under Recent Accounting Pronouncements Adopted, there have been no material changes in the Company’s significant accounting policies during the three months ended June 30, 2022 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2022.
  (was, 2022-01-27, similarity 0.9351):
[0001032975-22-000006:note_history:9]
Other than the recent accounting pronouncements adopted and discussed below under Recent Accounting Pronouncements Adopted, there have been no material changes in the Company’s significant accounting policies during the nine months ended December 31, 2021 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2021.

- changed (2022-07-28):
[0001032975-22-000034:note_history:10]
The preparation of financial statements in conformity with U.S. GAAP requires management to make judgments, estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Significant estimates and assumptions made by management involve the fair value of goodwill and intangible assets acquired from business acquisitions, contingent consideration for a business acquisition and periodic reassessment of its fair value, valuation of investment in privately held companies classified under Level 3 fair value hierarchy, pension obligations, accruals for customer incentives, cooperative marketing, and pricing programs and related breakage when appropriate, inventory valuation, share-based compensation expense, uncertain tax positions, and valuation allowances for deferred tax assets. Although these
  (was, 2022-01-27, similarity 0.9023):
[0001032975-22-000006:note_history:10]
The preparation of financial statements in conformity with U.S. GAAP requires management to make judgments, estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Significant estimates and assumptions made by management involve the fair value of goodwill and intangible assets acquired from business acquisitions, contingent consideration for a business acquisition and periodic reassessment of its fair value, valuation of investment in privately held companies classified under Level 3 fair value hierarchy, pension obligations, accruals for customer incentives, cooperative marketing, and pricing programs and related breakage when appropriate, inventory valuation, share-based compensation expense, uncertain tax positions, and valuation allowances for deferred tax assets. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ materially from those estimates.

- added (2022-07-28):
[0001032975-22-000034:note_history:11]
estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ materially from those estimates.

- added (2022-07-28):
[0001032975-22-000034:note_history:12]
Impacts of Macroeconomic and Geopolitical Conditions on the Company's Business

- added (2022-07-28):
[0001032975-22-000034:note_history:13]
During the first quarter of fiscal year 2023, the Company was impacted by adverse macroeconomic and geopolitical conditions. These conditions include but are not limited to inflation, foreign currency fluctuations, and lower consumer spending. The Company also continues to be affected by supply chain challenges, and the war in Ukraine has further increased existing global supply chain, logistics, and inflationary challenges. Such global or regional economic and political conditions adversely affect demand for the Company's products. These conditions also have an impact on its suppliers, contract manufacturers, logistics providers, and distributors, causing increases in cost of materials and higher shipping and transportation rates, and as a result impacting the pricing of its products. Price increases may not successfully offset cost increases or may cause the Company to lose market share and in turn adversely impact its results of operations.

- added (2022-07-28):
[0001032975-22-000034:note_history:14]
Impacts of COVID-19 on the Company's Business

- added (2022-07-28):
[0001032975-22-000034:note_history:15]
In March 2020, the World Health Organization declared the outbreak of COVID-19 as a pandemic, which continues to spread throughout the world. The COVID-19 pandemic has resulted in, and could continue to result in, industry-wide global supply chain challenges, including manufacturing, transportation and logistics. The Company purchases certain products and key components from a limited number of sources, and depends on the supply chain, including freight, to receive components, transport finished goods and deliver its products across the world. While the Company proactively manages its supply chain, it expects to continue to be impacted by higher logistics and component costs, prolonged delays, and challenges with component availability. Most recently, Shanghai, China, experienced a two-month lockdown beginning in late March 2022 due to another outbreak of COVID-19, resulting in a lockdown of the city, closures of ports and airports, and disruption of commercial activities, further constraining the Company's supply chain. If additional lockdowns or similar measures are instituted in Shanghai or Suzhou, where the Company's manufacturing facility is located, or other places where the Company's suppliers and partners are located, such measures, depending on their duration, could cause additional negative impact on the Company's business and results of operations.

- added (2022-07-28):
[0001032975-22-000034:note_history:16]
It is still difficult to predict the progression, the duration and all of the effects of COVID-19, how restrictions and shelter-at-home guidelines will continue evolving on a global basis, how consumer demand, supply chain challenges, including inventory and logistical effects and costs, may change over time, and the impact on the Company's future sales and results of operations. The full extent of the impact of the COVID-19 pandemic on the Company's business and operational and financial performance remains uncertain and will depend on many factors outside the Company's control.

- added (2022-07-28):
[0001032975-22-000034:note_history:17]
In October 2021, the Financial Accounting Standard Board ("FASB") issued ASU 2021-08, "Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers" (ASU 2021-08). The update requires an acquirer in a business combination to recognize and measure contract assets and contract liabilities acquired in a business combination in accordance with Accounting Standards Codification ("ASC") 606, Revenue from Contracts with Customers, as if it had originated the contracts. The standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2022. The Company early adopted the standard effective April 1, 2022 and applies the standard prospectively to business combinations that occurred on or after April 1, 2022. The adoption of ASU 2021-08 did not have a material impact on the Company's condensed consolidated financial statements.

- removed (2022-07-28):
[0001032975-22-000006:note_history:18]
We are subject to risks and uncertainties as a result of the novel coronavirus ("COVID-19"). Capital markets and economies worldwide have been negatively impacted by COVID-19 and it is still unclear how lasting and deep the economic impacts will be. During the three and nine months ended December 31, 2021, the COVID-19 pandemic had mixed effects on the Company’s results of operations. While the Company experienced increased sales for the nine months ended December 31, 2021, compared to the same period of the prior fiscal year, we also experienced supply and demand volatility, as the COVID-19 pandemic and related safety measures and restrictions have evolved differently across the world. In addition, we experienced industry-wide supply chain challenges. The ongoing and full extent of the impact of the COVID-19 pandemic on the Company's business and operational and financial performance and condition, including the sustainability of its effect on trends positive to the Company, is uncertain and will depend on many factors outside the Company's control, including but not limited to the timing, extent, duration and effects of the virus and any of its mutations and variants, the vaccination rates, the development of effective treatments, the imposition of effective public safety and other protective measures and the public's response to such measures, the impact of COVID-19 on the global economy and demand for the Company's products and services. Should the COVID-19 pandemic or global economic slowdown not improve or worsen, or if the Company's attempt to mitigate its impact on its operations and costs is not successful, the Company's business, results of operations, financial condition and prospects may be adversely affected.

- removed (2022-07-28):
[0001032975-22-000006:note_history:19]
In December 2019, the FASB issued ASU 2019-12, "Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes" (ASU 2019-12), which eliminates certain exceptions for recognizing deferred taxes for investments, performing intraperiod allocation and calculating income taxes in interim periods. This ASU also includes guidance to reduce complexity in certain areas, including recognizing deferred taxes for tax goodwill and allocating taxes to members of a consolidated group. ASU 2019-12 is effective for annual and interim periods in fiscal years beginning after December 15, 2020. Early adoption is permitted. The Company adopted this standard effective April 1, 2021. The adoption of ASU 2019-12 did not have a material impact on the Company's condensed consolidated financial statements.

- removed (2022-07-28):
[0001032975-22-000006:note_history:20]
Recent Accounting Pronouncements to Be Adopted

- removed (2022-07-28):
[0001032975-22-000006:note_history:21]
In October 2021, the FASB issued ASU 2021-08, "Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers" (ASU 2021-08). The standard requires an acquirer in a business combination to recognize and measure contract assets and contract liabilities acquired in a business combination in accordance with ASC 606, Revenue from Contracts with Customers, as if it had originated the contracts. The standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2022. Early adoption is permitted. The Company does not expect the adoption of ASU 2021-08 to have a significant impact on its consolidated financial statements and plans to adopt the standard effective April 1, 2023.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2022-07-28):
[0001032975-22-000034:note_history:22]
The Company had several uncommitted, unsecured bank lines of credit aggregating $185.9 million and $195.0 million as of June 30, 2022 and March 31, 2022, respectively. There are no financial covenants under these lines of credit with which the Company must comply. As of June 30, 2022 and March 31, 2022, the Company had outstanding bank guarantees of $23.9 million and $25.5 million, respectively, under these lines of credit. There was no borrowing outstanding under these lines of credit as of June 30, 2022 or March 31, 2022.

- removed (2022-07-28):
[0001032975-22-000006:note_history:23]
The Company had several uncommitted, unsecured bank lines of credit aggregating $194.4 million as of December 31, 2021. There are no financial covenants under these lines of credit with which the Company must comply. As of December 31, 2021, the Company had outstanding bank guarantees of $11.8 million under these lines of credit. There was no borrowing outstanding under these lines of credit as of December 31, 2021 or March 31, 2021.
