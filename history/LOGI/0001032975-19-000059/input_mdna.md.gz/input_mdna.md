# LOGI MD&A — 0001032975-19-000059


## mdna

[0001032975-19-000059:mdna:1]
[same as prior period, unchanged from 0001032975-19-000007:mdna:1]

[0001032975-19-000059:mdna:2]
[same as prior period, unchanged from 0001032975-19-000007:mdna:2]

[0001032975-19-000059:mdna:3]
[same as prior period, unchanged from 0001032975-19-000007:mdna:3]

[0001032975-19-000059:mdna:4]
Logitech is a world leader in designing, manufacturing and marketing products that help connect people to digital and cloud experiences. More than 35 years ago, Logitech created products to improve experiences around the personal PC platform, and today it is a multi-brand, multi-category company designing products that enable better experiences consuming, sharing and creating any digital content such as music, gaming, video and computing, whether it is on a computer, mobile device or in the cloud. Logitech's brands include Logitech, Logitech G, ASTRO Gaming, Ultimate Ears, Jaybird and Blue Microphones. Our Company's website is www.logitech.com.

[0001032975-19-000059:mdna:5]
[same as prior period, unchanged from 0001032975-19-000007:mdna:5]

[0001032975-19-000059:mdna:6]
[same as prior period, unchanged from 0001032975-19-000007:mdna:6]

[0001032975-19-000059:mdna:7]
[same as prior period, unchanged from 0001032975-19-000007:mdna:8]

[0001032975-19-000059:mdna:8]
Our total sales for the three months ended June 30, 2019 increased 6%, compared to the three months ended June 30, 2018, supported by stronger sales in the Americas and EMEA. Blue Microphones contributed 2 points to the sales growth during the period.

[0001032975-19-000059:mdna:9]
Our sales for the three months ended June 30, 2019 increased 6% and 12% in the Americas and EMEA, respectively, compared to the same period of the prior fiscal year. Our sales for the three months ended June 30, 2019 in Asia Pacific were flat compared to the same period of the prior fiscal year.

[0001032975-19-000059:mdna:10]
Our gross margin for the three months ended June 30, 2019 increased 30 basis points to 37.1% from 36.8% for the three months ended June 30, 2018. Our gross margin benefited from product cost savings, tariff mitigation efforts and product mix, partially offset by an increase in China tariffs and unfavorable currency exchange.

[0001032975-19-000059:mdna:11]
Operating expenses for the three months ended June 30, 2019 remained flat compared to the same period of the prior fiscal year. Operating expenses were 29.7% of sales for the three months ended June 30, 2019, compared to 31.5% of sales in the same period of the prior fiscal year.

[0001032975-19-000059:mdna:12]
Net income for the three months ended June 30, 2019 was $45.3 million, compared to $38.5 million for the three months ended June 30, 2018.

[0001032975-19-000059:mdna:13]
[same as prior period, unchanged from 0001032975-19-000007:mdna:19]

[0001032975-19-000059:mdna:14]
[same as prior period, unchanged from 0001032975-19-000007:mdna:20]

[0001032975-19-000059:mdna:15]
[same as prior period, unchanged from 0001032975-19-000007:mdna:21]

[0001032975-19-000059:mdna:16]
[same as prior period, unchanged from 0001032975-19-000007:mdna:22]

[0001032975-19-000059:mdna:17]
Creativity & Productivity:  Although new PC shipments continue to be weak, the installed base of PC users remains large. We believe that innovative PC peripherals, such as our mice and keyboards, can renew the PC usage experience, thus providing growth opportunities. Increasing adoption of various cloud-based applications has led to multiple new consumer use cases, which we are addressing with our innovative product portfolio. The increasing popularity of streaming and broadcasting provides additional growth opportunities for our Webcam products. Smaller mobile computing devices, such as tablets, have created new markets and usage models for peripherals and accessories. We offer a number of products to enhance the use of mobile devices, including a combo backlit keyboard case for the iPad Pro and keyboard folios for the iPad and iPad mini. In fiscal year 2019, we saw a recovery of the iPad tablet market, and our Tablet & Other Accessories category has benefited from the recovery along with our innovative products.

[0001032975-19-000059:mdna:18]
Gaming:  The PC gaming and console gaming platforms continue to show strong structural growth opportunities as online gaming, multi-platform experiences, and esports gain greater popularity and gaming content becomes increasingly more demanding. We believe Logitech is well positioned to benefit from the gaming market growth. With ASTRO Gaming, we are also strengthening our portfolio in adjacent categories, such as the console controller market.

[0001032975-19-000059:mdna:19]
Video Collaboration:  The near and long-term structural growth opportunities in the video collaboration market are significant and, as a result, that market is continuing to attract more competition. Video meetings are on the rise, and companies increasingly want lower-cost, cloud-based solutions. We are continuing our efforts to create and sell innovative products to accommodate the increasing demand from medium and large-sized meeting rooms to small-sized rooms such as huddle rooms. We will continue to invest in select business-specific products, targeted product marketing and sales channel development.

[0001032975-19-000059:mdna:20]
Music:  The music market grew during fiscal year 2019, driven by growing consumption of music through mobile devices such as smartphones and tablets. The integration of personal voice assistants has become increasingly competitive in the speaker categories, but the market for third-party, voice-enabled speakers has not yet gained traction. Moreover, the market for mobile speakers appears to be maturing, which led to a decline in Ultimate Ears sales in fiscal year 2019. In fiscal year 2019, the headphone industry continued to flourish with strong revenue growth. The largest growth was seen in wireless headphones where the market tripled year-over-year and where there was a substantial increase to average selling prices. Continued growth in the headphone market is expected for the next several years as consumers increasingly adopt wireless headphones over wired headphones. With Blue Microphones, we are strengthening our portfolio in adjacent categories, such as the microphones market.

[0001032975-19-000059:mdna:21]
Smart Home:  Our remote business declined substantially in fiscal year 2019 as the attachment to the voice assistants of Harmony Hub-based remote controls was not a sustainable trend. In general, the space is under pressure as the way people consume content is changing. We will continue to explore other innovative experiences for the Smart Home category.

[0001032975-19-000059:mdna:22]
[same as prior period, unchanged from 0001032975-19-000007:mdna:28]

[0001032975-19-000059:mdna:23]
We have historically experienced higher sales in our third fiscal quarter ending December 31, compared to other fiscal quarters in our fiscal year, primarily due to the increased consumer demand for our products during the year-end holiday buying season and year-end spending by enterprises. Additionally, new product introductions and business acquisitions can significantly impact sales, product costs and operating expenses. Product introductions can also impact our sales to our distribution channels as these channels are filled with new product inventory following a product introduction, and often channel inventory of an earlier model product declines as the next related major product launch approaches. Sales can also be affected when consumers and distributors anticipate a product introduction or changes in business circumstances. However, neither historical seasonal patterns nor historical patterns of product introductions should be considered reliable indicators of our future pattern of product introductions, future sales or financial performance.

[0001032975-19-000059:mdna:24]
Swiss Federal Tax Reform

[0001032975-19-000059:mdna:25]
On May 19, 2019, the Swiss electorate approved TRAF, a major reform to better align the Swiss tax system with international tax standards. The tax reform is expected to take effect on January 1, 2020. As of June 30, 2019, TRAF has not been enacted as the federal and cantonal legislative procedures are in process. We have benefited from a longstanding tax ruling from the canton of Vaud through March 31, 2019. We continue to monitor the enactment process and our transitional measures to comply with federal and cantonal tax reform provisions. We anticipate an increase in our cash tax payments in Switzerland beginning in fiscal year 2020.

[0001032975-19-000059:mdna:26]
[same as prior period, unchanged from 0001032975-19-000007:mdna:31]

[0001032975-19-000059:mdna:27]
The preparation of financial statements and related disclosures in conformity with GAAP requires us to make judgments, estimates and assumptions that affect the fair value of goodwill, intangible assets acquired from business acquisitions, valuation of operating right-of-use assets, warranty liabilities, accruals for customer incentives, cooperative marketing, and pricing programs and related breakage when appropriate, accrued sales return liability, allowance for doubtful accounts, inventory valuation, share-based compensation expense, uncertain tax positions, and valuation allowances for deferred tax assets.

[0001032975-19-000059:mdna:28]
[same as prior period, unchanged from 0001032975-19-000007:mdna:33]

[0001032975-19-000059:mdna:29]
We base our estimates on historical experience and on various other assumptions we believe to be reasonable under the circumstances. Although these estimates are based on management's best knowledge of current events and actions that may impact us in the future, actual results could differ from those estimates.

[0001032975-19-000059:mdna:30]
Management has discussed the development, selection and disclosure of these critical accounting estimates with the Audit Committee of the Board of Directors.

[0001032975-19-000059:mdna:31]
Other than the recent accounting pronouncement adoptions and Summary of Significant Accounting Policies discussed in Note 1 to the condensed consolidated financial statements, there have been no substantial changes in our significant accounting policies during the three months ended June 30, 2019, compared with the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended March 31, 2019.

[0001032975-19-000059:mdna:32]
Adoption of New Accounting Pronouncements

[0001032975-19-000059:mdna:33]
Refer to Note 1 to the condensed consolidated financial statements included in this Quarterly Report on Form 10-Q for recent accounting pronouncements adopted and to be adopted.

[0001032975-19-000059:mdna:34]
[same as prior period, unchanged from 0001032975-19-000007:mdna:46]

[0001032975-19-000059:mdna:35]
We refer to our sales growth rates excluding the impact of currency exchange rate fluctuations as "constant dollar" sales growth rates. Percentage of constant dollar sales growth is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales.

[0001032975-19-000059:mdna:36]
Given our global sales presence and the reporting of our financial results in U.S. Dollars, our financial results could be affected by shifts in currency exchange rates. See “Results of Operations” for information on the effect of currency exchange rate results on our sales. If the U.S. Dollar appreciates or depreciates in comparison to other currencies in future periods, this will affect our results of operations in future periods as well.

[0001032975-19-000059:mdna:37]
References to Sales

[0001032975-19-000059:mdna:38]
References to “sales” mean net sales, except as otherwise specified, and the sales growth discussion and sales growth rate percentages are based on U.S. Dollars, except as otherwise specified.

[0001032975-19-000059:mdna:39]
[same as prior period, unchanged from 0001032975-19-000007:mdna:50]

[0001032975-19-000059:mdna:40]
Although our financial results are reported in U.S. Dollars, a portion of our sales was generated in currencies other than the U.S. Dollar, such as the Euro, Chinese Renminbi, Japanese Yen, Canadian Dollar, Taiwan New Dollar, British Pound and Australian Dollar. During the three months ended June 30, 2019, approximately 47% of our sales were denominated in currencies other than the U.S. Dollar.

[0001032975-19-000059:mdna:41]
[same as prior period, unchanged from 0001032975-19-000007:mdna:53]

[0001032975-19-000059:mdna:42]
[same as prior period, unchanged from 0001032975-19-000007:mdna:54]

[0001032975-19-000059:mdna:43]
Our sales in the three months ended June 30, 2019 increased 6% compared to the same period of the prior fiscal year, driven by sales increases in the Americas and EMEA regions. Blue Microphones contributed 2 percentage points of the sales growth rate during the period. Strong growth in Mobile Speakers, Video Collaboration, Audio & Wearables and Tablet and other Accessories was partially offset by a decline in sales for Pointing Devices, PC Webcams and Gaming. If currency exchange rates had been constant in the three months ended June 30, 2019 and 2018, our constant dollar sales growth rates would have been 9%.

[0001032975-19-000059:mdna:44]
25

[0001032975-19-000059:mdna:45]
Sales by Region

[0001032975-19-000059:mdna:46]
The following table presents the change in sales by region for the three months ended June 30, 2019, compared with the three months ended June 30, 2018:

[0001032975-19-000059:mdna:47]
|  |  | Sales Growth Rate |  | Constant DollarSales Growth Rate |
| Americas |  | 6 | % |  | 7 | % |
| EMEA |  | 12 | % |  | 17 | % |
| Asia Pacific |  | — | % |  | 5 | % |

[0001032975-19-000059:mdna:48]
[same as prior period, unchanged from 0001032975-19-000007:mdna:59]

[0001032975-19-000059:mdna:49]
The increase in sales in our Americas region was primarily driven by growth in Mobile Speakers, Audio & Wearables, Video Collaboration and Tablets and Other Accessories, partially offset by a decline in sales for Pointing Devices and PC Webcams.

[0001032975-19-000059:mdna:50]
[same as prior period, unchanged from 0001032975-19-000007:mdna:61]

[0001032975-19-000059:mdna:51]
The increase in sales in our EMEA region was primarily driven by growth in Mobile Speakers, Video Collaboration and Tablets and Other Accessories, partially offset by a decline in sales for Pointing Devices.

[0001032975-19-000059:mdna:52]
[same as prior period, unchanged from 0001032975-19-000007:mdna:63]

[0001032975-19-000059:mdna:53]
The sales in our Asia Pacific region were flat. Growth in Video Collaboration was offset by a decline in sales for Mobile Speakers.

[0001032975-19-000059:mdna:54]
Sales by Product Categories

[0001032975-19-000059:mdna:55]
Sales by product categories for the three months ended June 30, 2019 and 2018 were as follows (Dollars in thousands):

[0001032975-19-000059:mdna:56]
|  |  | Three Months EndedJune 30, |
|  |  | 2019 |  | 2018 |  | Change |
| Pointing Devices |  | $ | 121,983 |  |  | $ | 127,790 |  |  | (5 | )% |
| Keyboards & Combos |  | 128,679 |  |  | 128,222 |  |  | — |  |
| PC Webcams |  | 28,128 |  |  | 29,674 |  |  | (5 | ) |
| Tablet & Other Accessories |  | 38,339 |  |  | 32,436 |  |  | 18 |  |
| Video Collaboration |  | 73,424 |  |  | 58,792 |  |  | 25 |  |
| Mobile Speakers |  | 50,416 |  |  | 34,327 |  |  | 47 |  |
| Audio & Wearables |  | 58,624 |  |  | 52,154 |  |  | 12 |  |
| Gaming |  | 134,515 |  |  | 136,026 |  |  | (1 | ) |
| Smart Home |  | 9,864 |  |  | 9,011 |  |  | 9 |  |
| Other (1) |  | 253 |  |  | 48 |  |  | 427 |  |
| Total sales |  | $ | 644,225 |  |  | $ | 608,480 |  |  | 6 | % |

[0001032975-19-000059:mdna:57]
(1) Other category includes products that we currently intend to phase out, or have already phased out, because they are no longer strategic to our business.

[0001032975-19-000059:mdna:58]
[same as prior period, unchanged from 0001032975-19-000007:mdna:70]

[0001032975-19-000059:mdna:59]
[same as prior period, unchanged from 0001032975-19-000007:mdna:71]

[0001032975-19-000059:mdna:60]
Our Pointing Devices category comprises PC- and Mac-related mice including trackballs, touchpads and presenters.

[0001032975-19-000059:mdna:61]
Sales of Pointing Devices decreased 5% in the three months ended June 30, 2019, compared to the same period of the prior fiscal year. The decrease was across all regions and products types, including corded mice, cordless mice and presentation tools.

[0001032975-19-000059:mdna:62]
[same as prior period, unchanged from 0001032975-19-000007:mdna:74]

[0001032975-19-000059:mdna:63]
Our Keyboards & Combos category comprises PC keyboards, living room keyboards and keyboard/mice combo products.

[0001032975-19-000059:mdna:64]
Sales of Keyboards & Combos remained flat in the three months ended June 30, 2019, compared to the same period of the prior fiscal year. The increase in sales for keyboards was offset by a decline in sales for keyboard/mice combos.

[0001032975-19-000059:mdna:65]
[same as prior period, unchanged from 0001032975-19-000007:mdna:77]

[0001032975-19-000059:mdna:66]
[same as prior period, unchanged from 0001032975-19-000007:mdna:78]

[0001032975-19-000059:mdna:67]
PC Webcams sales decreased 5% in the three months ended June 30, 2019, compared to the same period of the prior fiscal year. The decrease was primarily driven by a decline in the sales of our HD Pro Webcam C920.

[0001032975-19-000059:mdna:68]
[same as prior period, unchanged from 0001032975-19-000007:mdna:80]

[0001032975-19-000059:mdna:69]
[same as prior period, unchanged from 0001032975-19-000007:mdna:81]

[0001032975-19-000059:mdna:70]
Sales of Tablet & Other Accessories products increased 18% in the three months ended June 30, 2019, compared to the same period of the prior fiscal year. The increase was primarily driven by the sales of our Slim Folio keyboard cases for the iPad 5th/6th Generation introduced in the second quarter of fiscal year 2019 and Slim Folio keyboard cases for the 12.9" and 11" iPad Pro introduced in the first quarter of fiscal year 2020, partially offset by a decline in the sales of our Slim Combo keyboard cases for the iPad Pro.

[0001032975-19-000059:mdna:71]
[same as prior period, unchanged from 0001032975-19-000007:mdna:93]

[0001032975-19-000059:mdna:72]
Our Gaming category comprises gaming mice, keyboards, headsets, gamepads, steering wheels, simulation controllers, console gaming headsets and console gaming controllers.

[0001032975-19-000059:mdna:73]
Gaming sales decreased 1% for the three months ended June 30, 2019, compared to the same period of the prior fiscal year. The decrease was primarily driven by declines in the sales of our gaming headsets and console gaming headsets, partially offset by increases in the sales of PC gaming mice and console gaming controllers.

[0001032975-19-000059:mdna:74]
[same as prior period, unchanged from 0001032975-19-000007:mdna:83]

[0001032975-19-000059:mdna:75]
Our Video Collaboration category primarily includes Logitech’s ConferenceCams, which combines affordable

[0001032975-19-000059:mdna:76]
enterprise-quality audio and high definition (HD) 1080p video to bring video conferencing to businesses of any size.

[0001032975-19-000059:mdna:77]
Sales of Video Collaboration products increased 25% in the three months ended June 30, 2019, compared to the same period of the prior fiscal year. The increase was primarily driven by the sales of our Rally Ultra-HD PTZ Conference Camera introduced in the third quarter of fiscal year 2019 and an increase in the sales of our MeetUp video conference camera.

[0001032975-19-000059:mdna:78]
[same as prior period, unchanged from 0001032975-19-000007:mdna:86]

[0001032975-19-000059:mdna:79]
[same as prior period, unchanged from 0001032975-19-000007:mdna:87]

[0001032975-19-000059:mdna:80]
[same as prior period, unchanged from 0001032975-19-000007:mdna:88]

[0001032975-19-000059:mdna:81]
Sales of Mobile Speakers increased 47% for the three months ended June 30, 2019, compared to the same period of the prior fiscal year. The increase was primarily due to the sales of our Ultimate Ears MEGABOOM 3 and BOOM 3 mobile speakers introduced in the second quarter of fiscal year 2019, the sales of our WONDERBOOM 2

[0001032975-19-000059:mdna:82]
introduced in the first quarter of fiscal year 2020 and an increase in the sales of Ultimate Ears MEGABOOM, partially offset by declines in the sales for other existing Ultimate Ears speakers.

[0001032975-19-000059:mdna:83]
[same as prior period, unchanged from 0001032975-19-000007:mdna:90]

[0001032975-19-000059:mdna:84]
[same as prior period, unchanged from 0001032975-19-000007:mdna:91]

[0001032975-19-000059:mdna:85]
Audio & Wearables sales increased 12% for the three months ended June 30, 2019, compared to the same period of the prior fiscal year. The increase was primarily driven by the sales of our Blue Microphones products as a result of our business combination in the second quarter of fiscal year 2019, partially offset by a decline in the sales of our corded headsets, PC speakers and Jaybird products.

[0001032975-19-000059:mdna:86]
[same as prior period, unchanged from 0001032975-19-000007:mdna:96]

[0001032975-19-000059:mdna:87]
Our Smart Home category mainly comprises our Harmony line of advanced home entertainment controllers and home security cameras.

[0001032975-19-000059:mdna:88]
Smart Home sales increased 9% during the three months ended June 30, 2019, compared to the same period of the prior fiscal year. The increase was primarily due to an increase in the sales of our home video products, partially offset by declines in sales of our Harmony remote products.

[0001032975-19-000059:mdna:89]
[same as prior period, unchanged from 0001032975-19-000007:mdna:99]

[0001032975-19-000059:mdna:90]
Gross profit for the three months ended June 30, 2019 and 2018 was as follows (Dollars in thousands):

[0001032975-19-000059:mdna:91]
|  |  | Three Months EndedJune 30, |
|  |  | 2019 |  | 2018 |  | Change |
| Net sales |  | $ | 644,225 |  |  | $ | 608,480 |  |  | 6 | % |
| Gross profit |  | $ | 238,976 |  |  | $ | 223,937 |  |  | 7 |  |
| Gross margin |  | 37.1 | % |  | 36.8 | % |  |  |

[0001032975-19-000059:mdna:92]
Gross profit consists of sales less cost of goods sold (which includes materials, direct labor and related overhead costs, costs of manufacturing facilities, royalties, costs of purchasing components from outside suppliers, distribution costs, warranty costs, customer support, shipping and handling costs, outside processing costs and write-down of inventories), amortization of intangible assets and purchase accounting effect on inventory.

[0001032975-19-000059:mdna:93]
[same as prior period, unchanged from 0001032975-19-000007:mdna:103]

[0001032975-19-000059:mdna:94]
Operating expenses for the three months ended June 30, 2019 and 2018 were as follows (Dollars in thousands):

[0001032975-19-000059:mdna:95]
|  |  | Three Months EndedJune 30, |
|  |  | 2019 |  | 2018 |
| Marketing and selling |  | $ | 123,033 |  |  | $ | 114,584 |  |
| % of sales |  | 19.1 | % |  | 18.8 | % |
| Research and development |  | 42,243 |  |  | 38,987 |  |
| % of sales |  | 6.6 | % |  | 6.4 | % |
| General and administrative |  | 22,159 |  |  | 25,473 |  |
| % of sales |  | 3.4 | % |  | 4.2 | % |
| Amortization of intangible assets and acquisition-related costs |  | 3,596 |  |  | 2,521 |  |
| % of sales |  | 0.6 | % |  | 0.4 | % |
| Restructuring charges, net |  | 478 |  |  | 9,921 |  |
| % of sales |  | — | % | (1) | 1.6 | % |
| Total operating expenses |  | $ | 191,509 |  |  | $ | 191,486 |  |
| % of sales |  | 29.7 | % |  | 31.5 | % |

[0001032975-19-000059:mdna:96]
(1) Absolute value for % of sales is less than 0.1%.

[0001032975-19-000059:mdna:97]
[same as prior period, unchanged from 0001032975-19-000007:mdna:107]

[0001032975-19-000059:mdna:98]
Marketing and selling expenses consist of personnel and related overhead costs, corporate and product marketing, promotions, advertising, trade shows, technical support for customer experiences and facilities costs.

[0001032975-19-000059:mdna:99]
During the three months ended June 30, 2019, marketing and selling expenses increased $8.4 million compared to the same period of the prior fiscal year. The increases were primarily driven by higher advertising and marketing expenses and higher personnel-related costs due to increased headcount, partly resulting from the Blue Microphones acquisition.

[0001032975-19-000059:mdna:100]
[same as prior period, unchanged from 0001032975-19-000007:mdna:110]

[0001032975-19-000059:mdna:101]
[same as prior period, unchanged from 0001032975-19-000007:mdna:111]

[0001032975-19-000059:mdna:102]
During the three months ended June 30, 2019, research and development expenses increased $3.3 million compared to the same period of the prior fiscal year. The increase was primarily driven by higher personnel-related costs due to increased headcount, partly resulting from the Blue Microphones acquisition.

[0001032975-19-000059:mdna:103]
[same as prior period, unchanged from 0001032975-19-000007:mdna:113]

[0001032975-19-000059:mdna:104]
[same as prior period, unchanged from 0001032975-19-000007:mdna:114]

[0001032975-19-000059:mdna:105]
During the three months ended June 30, 2019, general and administrative expenses decreased $3.3 million, compared to the same period of the prior fiscal year. The decrease for the three-month period was primarily driven by lower personnel-related costs.

[0001032975-19-000059:mdna:106]
[same as prior period, unchanged from 0001032975-19-000007:mdna:116]

[0001032975-19-000059:mdna:107]
Amortization of intangible assets consists of amortization of acquired intangible assets, including customer relationships and trade names. Acquisition-related costs include legal expense, due diligence costs, and other professional costs incurred for business acquisitions.

[0001032975-19-000059:mdna:108]
The increase in amortization of intangible assets during the three months ended June 30, 2019, compared with the same period of the prior fiscal year, was primarily driven by the intangible assets acquired through the Blue Microphones acquisition in the second quarter of fiscal year 2019.

[0001032975-19-000059:mdna:109]
Restructuring Charges, Net

[0001032975-19-000059:mdna:110]
During the first quarter of fiscal year 2019, we implemented a restructuring plan to streamline and realign our overall organizational structure and reallocate resources to support our long-term growth opportunities. In July, 2018, our Board of Directors approved additional costs under this restructuring plan, totaling pre-tax charges of approximately $10.0 million to $15.0 million, of which $11.8 million has been recognized cumulatively as of June 30, 2019. The total charges consisted of cash severance and other personnel costs and are presented as restructuring charges, net in the condensed consolidated statements of operations. As of June 30, 2019, the Company has substantially completed this restructuring plan.

[0001032975-19-000059:mdna:111]
The following table summarizes restructuring related activities during the three months ended June 30, 2019 (in thousands):

[0001032975-19-000059:mdna:112]
|  |  | TerminationBenefits |
| Accrual balance at March 31, 2019 |  | $ | 4,389 |  |
| Charges |  | 478 |  |
| Cash payments |  | (1,956 | ) |
| Accrual balance at June 30, 2019 |  | $ | 2,911 |  |

[0001032975-19-000059:mdna:113]
Other Income (Expense), Net

[0001032975-19-000059:mdna:114]
Other income (expense), net for the three months ended June 30, 2019 and 2018 was as follows (in thousands):

[0001032975-19-000059:mdna:115]
|  |  | Three Months EndedJune 30, |
|  |  | 2019 |  | 2018 |
| Investment income related to a deferred compensation plan |  | $ | 589 |  |  | $ | 214 |  |
| Currency exchange gain (loss), net |  | 817 |  |  | (1,874 | ) |
| Gain (loss) on investments |  | 211 |  |  | (13 | ) |
| Other |  | 244 |  |  | 102 |  |
| Total |  | $ | 1,861 |  |  | $ | (1,571 | ) |

[0001032975-19-000059:mdna:116]
Investment income represents earnings, gains, and losses on trading investments related to a deferred compensation plan offered by one of our subsidiaries.

[0001032975-19-000059:mdna:117]
Currency exchange gain (loss), net relates to balances denominated in currencies other than the functional currency in our subsidiaries, as well as to the sale of currencies, and to gains or losses recognized on currency exchange forward contracts. We do not speculate in currency positions, but we are alert to opportunities to maximize currency exchange gains and minimize currency exchange losses.

[0001032975-19-000059:mdna:118]
Provision for (Benefit from) Income Taxes

[0001032975-19-000059:mdna:119]
The provision for (benefit from) income taxes and effective tax rates for the three months ended June 30, 2019 and 2018 were as follows (Dollars in thousands):

[0001032975-19-000059:mdna:120]
|  |  | Three Months EndedJune 30, |
|  |  | 2019 |  | 2018 |
| Provision for (benefit from) income taxes |  | $ | 6,536 |  |  | $ | (5,217 | ) |
| Effective income tax rate |  | 12.6 | % |  | (15.7 | )% |

[0001032975-19-000059:mdna:121]
The change in the effective income tax rate for the three months ended June 30, 2019, compared to the same period of the prior fiscal year, was primarily due to the mix of income and losses in the various tax jurisdictions in  which we operate and the transitional income tax impact in Switzerland. We have benefited from a longstanding tax ruling from the canton of Vaud through March 31, 2019. The transitional income tax impact represents income tax provision at the current full statutory income tax rate of 13.62%, without taking account of the federal and cantonal tax reform yet to be enacted. In the three months ended June 30, 2019, there was a discrete tax provision of $2.3 million to record net deferred tax liability in Switzerland. Furthermore, there were discrete tax benefits of $5.8 million and $1.2 million from the recognition of excess tax benefits in the United States and reversal of uncertain tax positions from the expiration of statutes of limitations, respectively, in the three-month period ended  June 30, 2019, compared with $8.3 million and $0.9 million, respectively, in the three-month period ended June 30, 2018.

[0001032975-19-000059:mdna:122]
As of June 30, 2019 and March 31, 2019, the total amounts of unrecognized tax benefits due to uncertain tax positions were $77.3 million and $76.5 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-19-000059:mdna:123]
[same as prior period, unchanged from 0001032975-19-000007:mdna:140]

[0001032975-19-000059:mdna:124]
[same as prior period, unchanged from 0001032975-19-000007:mdna:141]

[0001032975-19-000059:mdna:125]
As of June 30, 2019, we had cash and cash equivalents of $597.0 million, compared to $604.5 million as of March 31, 2019. As of June 30, 2019, 76% of the cash and cash equivalents were held in Switzerland and 12% held in Hong Kong and China. We do not expect to incur any material adverse tax impact except for what has been recognized, or be significantly inhibited by any country in which we do business from the repatriation of funds to Switzerland, our home domicile.

[0001032975-19-000059:mdna:126]
The decrease in cash and cash equivalents for the three months ended June 30, 2019, was primarily due to payment of annual bonus during the period, purchases of property, plant and equipment, tax withholdings related to settlements of restricted stock units and shares repurchased under our share buyback program, partially offset by proceeds from exercises of stock options and purchase rights and net cash provided by operating activities.

[0001032975-19-000059:mdna:127]
As of June 30, 2019, our working capital was $648.3 million, compared to $632.6 million as of March 31, 2019. The increase was primarily driven by higher accounts receivable, net, higher inventories and lower accrued and other current liabilities, partially offset by lower cash and cash equivalents and higher accounts payable. Our working capital increased by $49.6 million compared to $596.7 million as of June 30, 2018, which was primarily driven by higher accounts receivable, net, higher inventories and lower accounts payable, partially offset by lower cash and cash equivalents and higher accrued and other current liabilities.

[0001032975-19-000059:mdna:128]
We had several uncommitted, unsecured bank lines of credit aggregating $79.3 million as of June 30, 2019. There are no financial covenants under these lines of credit with which we must comply. As of June 30, 2019, we had outstanding bank guarantees of $15.7 million under these lines of credit.

[0001032975-19-000059:mdna:129]
[same as prior period, unchanged from 0001032975-19-000007:mdna:146]

[0001032975-19-000059:mdna:130]
|  |  | Three Months EndedJune 30, |
|  |  | 2019 |  | 2018 |
| Net cash provided by operating activities |  | $ | 36,516 |  |  | $ | 12,282 |  |
| Net cash used in investing activities |  | (9,469 | ) |  | (8,845 | ) |
| Net cash used in financing activities |  | (34,104 | ) |  | (33,959 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  | (503 | ) |  | (7,309 | ) |
| Net decrease in cash and cash equivalents |  | $ | (7,560 | ) |  | $ | (37,831 | ) |

[0001032975-19-000059:mdna:131]
The following table presents selected financial information and statistics as of and for the three months ended June 30, 2019 and 2018 (Dollars in thousands):

[0001032975-19-000059:mdna:132]
|  |  | As of June 30, |
|  |  | 2019 |  | 2018 |
| Accounts receivable, net |  | $ | 418,816 |  |  | $ | 385,546 |  |
| Accounts payable |  | $ | 338,748 |  |  | $ | 343,680 |  |
| Inventories |  | $ | 297,007 |  |  | $ | 272,662 |  |

[0001032975-19-000059:mdna:133]
|  |  | Three Months EndedJune 30, |
|  |  | 2019 |  | 2018 |
| Days sales in accounts receivable (“DSO”) (Days) (1) |  | 59 |  |  | 57 |  |
| Days accounts payable outstanding (“DPO”) (Days) (2) |  | 75 |  |  | 80 |  |
| Inventory turnover (“ITO”) (x)(3) |  | 5.5 |  |  | 5.6 |  |

[0001032975-19-000059:mdna:134]
(1) DSO is determined using ending accounts receivable, net as of the most recent quarter end and sales for the most recent quarter.

[0001032975-19-000059:mdna:135]
(2) DPO is determined using ending accounts payable as of the most recent quarter end and cost of goods sold for the most recent quarter.

[0001032975-19-000059:mdna:136]
[same as prior period, unchanged from 0001032975-19-000007:mdna:153]

[0001032975-19-000059:mdna:137]
DSO for the three months ended June 30, 2019 increased by 2 days to 59 days, compared to 57 days for the same period of the prior fiscal year, primarily due to timing of sales, customer payments and claims.

[0001032975-19-000059:mdna:138]
DPO for the three months ended June 30, 2019 decreased by 5 days, compared to the same period of the prior fiscal year, primarily due to the timing of purchases and related payments.

[0001032975-19-000059:mdna:139]
ITO for the three months ended June 30, 2019 was approximately unchanged, compared to the same period of the prior fiscal year.

[0001032975-19-000059:mdna:140]
If we are not successful in launching and phasing in our new products, or market competition increases, or we are not able to sell the new products at the prices planned, it could have a material impact on our sales, gross profit margin, operating results including operating cash flow, and inventory turnover in the future.

[0001032975-19-000059:mdna:141]
During the three months ended June 30, 2019, we generated $36.5 million of cash from operating activities. Our main sources of operating cash flows were from net income, after adding back non-cash expenses of depreciation, amortization and share-based compensation expense, and from changes in operating assets and liabilities. The increase in accounts receivable, net was primarily driven by growth and timing of sales, customer payments and claims. The increase in other assets was primarily due to an increase in right-of-use assets as a result of the adoption of ASC Topic 842. The increase in accounts payable was primarily driven by the timing of purchases and related payments. The decrease in accrued and other liabilities was primarily due to payment of annual bonus during the period, partially offset by an increase in lease liabilities as a result of the adoption of ASC Topic 842.

[0001032975-19-000059:mdna:142]
Net cash used in investing activities was $9.5 million, primarily due to $9.3 million of purchases of property, plant and equipment.

[0001032975-19-000059:mdna:143]
Net cash used in financing activities was $34.1 million, primarily due to $15.1 million used for repurchases of our registered shares, and $19.4 million tax withholdings related to net share settlements of restricted stock units, partially offset by $0.4 million in proceeds received from exercises of stock options and purchase rights.

[0001032975-19-000059:mdna:144]
During the three months ended June 30, 2019, there was a $0.5 million loss from currency exchange rate effect on cash and cash equivalents, compared to a loss of $7.3 million during the same period of the prior fiscal year. The loss from currency translation exchange effect during the three months ended June 30, 2018 was primarily due to the weakening of the Euro, Brazilian Real and Japanese Yen against the U.S. Dollar by 5%, 14% and 4%, respectively, during the period.

[0001032975-19-000059:mdna:145]
[same as prior period, unchanged from 0001032975-19-000007:mdna:162]

[0001032975-19-000059:mdna:146]
[same as prior period, unchanged from 0001032975-19-000007:mdna:163]

[0001032975-19-000059:mdna:147]
In May 2019, the Board of Directors recommended that the Company pay CHF121.8 million ($122.4 million based on the exchange rate on March 31, 2019) in cash dividends out of retained earnings available at the end of fiscal year 2019. In fiscal year 2019, we paid a cash dividend of CHF 110.7 million (U.S. Dollar amount of  $114.0 million) out of retained earnings available at the end of fiscal year 2018. In fiscal year 2018, we paid a cash dividend of CHF100.0 million (U.S. Dollar amount of $104.2 million) out of retained earnings available at the end of fiscal year 2017. The dividend to be paid in fiscal year 2020 and any future dividends will be subject to the approval of our shareholders.

[0001032975-19-000059:mdna:148]
In March 2017, our Board of Directors approved our 2017 share buyback program, which authorizes us to purchase up to $250.0 million of our outstanding shares over a three-year period. The new program was approved by the Swiss Takeover Board in May 2017. Although we enter into trading plans for systematic repurchases (e.g., 10b5-1 trading plans) from time to time, our share buyback program provides us with the opportunity to make repurchases during periods of favorable market conditions and is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Opportunistic purchases may be started or stopped at any time without prior notice depending on market conditions and other factors. As of June 30, 2019, $172.4 million is still available for repurchase under the 2017 share buyback program.

[0001032975-19-000059:mdna:149]
[same as prior period, unchanged from 0001032975-19-000007:mdna:167]

[0001032975-19-000059:mdna:150]
[same as prior period, unchanged from 0001032975-19-000007:mdna:168]

[0001032975-19-000059:mdna:151]
[same as prior period, unchanged from 0001032975-19-000007:mdna:169]

[0001032975-19-000059:mdna:152]
[same as prior period, unchanged from 0001032975-19-000007:mdna:170]

[0001032975-19-000059:mdna:153]
As of June 30, 2019, we had non-cancelable purchase commitments for inventory purchases made in the normal course of business to original design manufacturers, contract manufacturers and other suppliers, the majority of which are expected to be fulfilled within the next 12 months. Non-cancelable purchase commitments for capital expenditures primarily relate to commitments for tooling for new and existing products, computer hardware, leasehold and improvements. We expect to continue making capital expenditures in the future to support product development activities and ongoing and expanded operations. Although open purchase commitments are considered enforceable and legally binding, the terms generally allow us to reschedule or adjust our requirements based on business needs prior to delivery of goods or performance of services.

[0001032975-19-000059:mdna:154]
[same as prior period, unchanged from 0001032975-19-000007:mdna:172]

[0001032975-19-000059:mdna:155]
For further detail about our contractual obligations and commitments, refer to our Annual Report on Form 10-K for the fiscal year ended March 31, 2019.

[0001032975-19-000059:mdna:156]
[same as prior period, unchanged from 0001032975-19-000007:mdna:174]

[0001032975-19-000059:mdna:157]
[same as prior period, unchanged from 0001032975-19-000007:mdna:175]

[0001032975-19-000059:mdna:158]
[same as prior period, unchanged from 0001032975-19-000007:mdna:178]

[0001032975-19-000059:mdna:159]
We indemnify certain suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of June 30, 2019, no amounts have been accrued for indemnification provisions. We do not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under our indemnification arrangements.

[0001032975-19-000059:mdna:160]
[same as prior period, unchanged from 0001032975-19-000007:mdna:180]

[0001032975-19-000059:mdna:161]
Legal Proceedings

[0001032975-19-000059:mdna:162]
From time to time we are involved in claims and legal proceedings that arise in the ordinary course of our business. We are currently subject to several such claims and a small number of legal proceedings. We believe that these matters lack merit and we intend to vigorously defend against them. Based on currently available information, we do not believe that resolution of pending matters will have a material adverse effect on our financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that our defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on our business, financial condition, cash flows and results of operations in a particular period. Any claims or proceedings against us, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain necessary licenses or other rights, or litigation arising out of intellectual property claims, could adversely affect our business.
