# LOGI notes — 0001032975-19-000059


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001032975-19-000059:notes:1]
[same as prior period, unchanged from 0001032975-19-000007:notes:6]

[0001032975-19-000059:notes:2]
[same as prior period, unchanged from 0001032975-19-000007:notes:7]

[0001032975-19-000059:notes:3]
[same as prior period, unchanged from 0001032975-19-000007:notes:8]

[0001032975-19-000059:notes:4]
[same as prior period, unchanged from 0001032975-19-000007:notes:9]

[0001032975-19-000059:notes:5]
[same as prior period, unchanged from 0001032975-19-000007:notes:10]

[0001032975-19-000059:notes:6]
[same as prior period, unchanged from 0001032975-19-000007:notes:13]

[0001032975-19-000059:notes:7]
The condensed consolidated financial statements include the accounts of Logitech and its subsidiaries. All intercompany balances and transactions have been eliminated. The condensed consolidated financial statements are presented in accordance with accounting principles generally accepted in the United States of America (“GAAP”) for interim financial information and therefore do not include all the information required by GAAP for complete financial statements. The condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended March 31, 2019, included in its Annual Report on Form 10-K filed with the Securities and Exchange Commission (“SEC”) on May 17, 2019.

[0001032975-19-000059:notes:8]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three months ended June 30, 2019 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2020, or any future periods.

[0001032975-19-000059:notes:9]
[same as prior period, unchanged from 0001032975-19-000007:notes:18]

[0001032975-19-000059:notes:10]
Other than the recent accounting pronouncements adopted and discussed below under Recent Accounting Pronouncements Adopted and Summary of Significant Accounting Policies, there have been no changes in the Company’s significant accounting policies during the three months ended June 30, 2019 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2019.

[0001032975-19-000059:notes:11]
[same as prior period, unchanged from 0001032975-19-000007:notes:20]

[0001032975-19-000059:notes:12]
The preparation of financial statements in conformity with GAAP requires management to make judgments, estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Significant estimates and assumptions made by management involve the fair value of goodwill, intangible assets acquired from business acquisitions, valuation of operating right-of-use assets, warranty liabilities, accruals for customer incentives, cooperative marketing, and pricing programs (Customer Programs) and related breakage when appropriate, accrued sales return liability, allowance for doubtful accounts, inventory valuation, share-based compensation expense, uncertain tax positions, and valuation allowances for deferred tax assets.

[0001032975-19-000059:notes:13]
Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ materially from these estimates.

[0001032975-19-000059:notes:14]
[same as prior period, unchanged from 0001032975-19-000007:notes:22]

[0001032975-19-000059:notes:15]
In February 2016, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) No. 2016-02, "Leases (Topic 842)" (ASU 2016-02 or Topic 842), which requires a lessee to recognize right-of-use (ROU) assets and lease liabilities arising from operating and financing leases with terms longer than 12 months on the consolidated balance sheets and to disclose key information about leasing arrangements.

[0001032975-19-000059:notes:16]
The Company adopted the new standard effective April 1, 2019 and recorded an ROU asset and lease liability related to its operating leases. The Company used the modified retrospective approach with the effective date as the date of initial application. Accordingly, the Company applied the new lease standard prospectively to leases existing or commencing on or after April 1, 2019. Prior period balances and disclosures have not been restated. The Company elected the package of transitional practical expedients, which among other provisions, allows the Company to not reassess under the new standard the Company's prior conclusions about lease identification, lease classification and initial direct cost, for any existing leases on the adoption date. In addition, for operating leases, the Company elected to account for lease and non-lease components as a single lease component. The Company also made an accounting policy election to not recognize lease liabilities and ROU assets on its condensed consolidated balance sheet for leases that, at the lease commencement date, have a lease term of 12 months or less.

[0001032975-19-000059:notes:17]
Adoption of the standard resulted in the recognition of $31.3 million of ROU assets and $37.4 million of lease liabilities related to the Company's leases on its condensed consolidated balance sheet on April 1, 2019. The difference of $6.1 million represented deferred rent for leases that existed as of the date of adoption, which decreased the opening balance of ROU assets. In addition, the prepaid rent balance as of the date of adoption increased the opening balance of ROU assets. The deferred rent and prepaid rent balances were derecognized as of the date of adoption and no adjustment was made to retained earnings. The adoption of the standard did not have an impact on our condensed consolidated statement of operations, comprehensive income, changes in shareholders' equity or cash flows.

[0001032975-19-000059:notes:18]
In August 2018, the FASB issued ASU 2018-15, "Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40): Customer's Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract" (ASU 2018-15), which clarifies that implementation costs incurred by customers in cloud computing arrangements are deferred if they would be capitalized by customers in software licensing arrangements under the internal-use software guidance. ASU 2018-15 is effective for annual and interim periods in fiscal years beginning after December 15, 2019, with early adoption permitted. Entities have the option to apply the guidance prospectively to all implementation costs incurred after the date of adoption or retrospectively. The Company adopted this standard effective April 1, 2019 using a prospective adoption method. The adoption of ASU 2018-15 did not have a material impact on the Company's condensed consolidated financial statements.

[0001032975-19-000059:notes:19]
[same as prior period, unchanged from 0001032975-19-000007:notes:44]

[0001032975-19-000059:notes:20]
In August 2018, the FASB issued ASU 2018-13, "Fair Value Measurement (Topic 820): Disclosure Framework - Changes to the Disclosure Requirements for Fair Value Measurements" (ASU 2018-13), which aims to improve the overall usefulness of disclosures to financial statement users and reduce unnecessary costs to companies when preparing fair value measurement disclosures. ASU 2018-13 is effective for annual and interim periods in fiscal years beginning after December 15, 2019. Early adoption is permitted. Retrospective adoption is required, except for certain disclosures which will be required to be applied prospectively for only the most recent interim or annual period presented in the initial fiscal year of adoption. The Company does not expect the adoption of ASU 2018-13 will have a material impact on its consolidated financial statements and plans to adopt the standard effective April 1, 2020.

[0001032975-19-000059:notes:21]
In August 2018, the FASB issued ASU 2018-14, "Compensation - Retirement Benefits - Defined Benefits Plans - General (Subtopic 715-20): Disclosure Framework - Changes to the Disclosure Requirements for Defined Benefit Plans" (ASU 2018-14), which aims to improve the overall usefulness of disclosures to financial statement users and reduce unnecessary costs to companies when preparing defined benefit plan disclosures. ASU 2018-14 is effective for annual periods in fiscal years ending after December 15, 2020. Retrospective adoption is required and early

[0001032975-19-000059:notes:22]
adoption is permitted. The Company does not expect the adoption of ASU 2018-14 will have a material impact on its consolidated financial statements and plans to early adopt the standard effective April 1, 2020.


## us-gaap:EarningsPerShareTextBlock

[0001032975-19-000059:notes:23]
[same as prior period, unchanged from 0001032975-19-000007:notes:128]

[0001032975-19-000059:notes:24]
The following table summarizes the computations of basic and diluted net income per share for the three months ended June 30, 2019 and June 30, 2018 (in thousands, except per share amounts):

[0001032975-19-000059:notes:25]
|  |  | Three Months EndedJune 30, |
|  |  | 2019 |  | 2018 |
| Net income |  | $ | 45,345 |  |  | $ | 38,466 |  |
| Shares used in net income per share computation: |  |  |  |  |  |  |
| Weighted average shares outstanding - basic |  | 166,302 |  |  | 165,317 |  |
| Effect of potentially dilutive equivalent shares |  | 2,495 |  |  | 3,439 |  |
| Weighted average shares outstanding - diluted |  | 168,797 |  |  | 168,756 |  |
| Net income per share: |  |  |  |  |  |  |
| Basic |  | $ | 0.27 |  |  | $ | 0.23 |  |
| Diluted |  | $ | 0.27 |  |  | $ | 0.23 |  |

[0001032975-19-000059:notes:26]
Share equivalents attributable to outstanding stock options, restricted stock units ("RSUs") and employee share purchase rights (ESPP) totaling 2.0 million and 1.5 million for the three months ended June 30, 2019 and 2018, respectively, were excluded from the calculation of diluted net income per share because the combined exercise price and average unamortized grant date fair value upon exercise of these options and ESPP or vesting of RSUs were greater than the average market price of the Company's shares during the periods presented herein, and therefore their inclusion would have been anti-dilutive. Performance-based awards were not included because all necessary conditions have not been satisfied by the end of the respective period, and those shares were not issuable if the end of the reporting period was the end of the contingency period.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001032975-19-000059:notes:27]
[same as prior period, unchanged from 0001032975-19-000007:notes:106]

[0001032975-19-000059:notes:28]
[same as prior period, unchanged from 0001032975-19-000007:notes:107]

[0001032975-19-000059:notes:29]
As of June 30, 2019, the Company offers the 2006 Employee Share Purchase Plan, as amended and restated (Non-U.S.) (2006 ESPP), the 1996 Employee Share Purchase Plan (U.S.), as amended and restated (1996 ESPP), the 2006 Stock Incentive Plan, as amended and restated (2006 Plan), and the 2012 Stock Inducement Equity Plan (2012 Plan).

[0001032975-19-000059:notes:30]
The following table summarizes the share-based compensation expense and total income tax benefit recognized for share-based awards for the three months ended June 30, 2019 and 2018 (in thousands):

[0001032975-19-000059:notes:31]
|  |  | Three Months EndedJune 30, |
|  |  | 2019 |  | 2018 |
| Cost of goods sold |  | $ | 1,158 |  |  | $ | 1,130 |  |
| Marketing and selling |  | 6,849 |  |  | 5,786 |  |
| Research and development |  | 2,154 |  |  | 1,549 |  |
| General and administrative |  | 2,057 |  |  | 4,794 |  |
| Total share-based compensation expense |  | 12,218 |  |  | 13,259 |  |
| Income tax benefit |  | (6,800 | ) |  | (9,529 | ) |
| Total share-based compensation expense, net of income tax benefit |  | $ | 5,418 |  |  | $ | 3,730 |  |

[0001032975-19-000059:notes:32]
The income tax benefit in the respective period primarily consists of tax benefit related to the share-based compensation expense for the period and direct tax benefit realized, including net excess tax benefits recognized from share-based awards vested or exercised during the period.

[0001032975-19-000059:notes:33]
As of June 30, 2019 and 2018, the balance of capitalized share-based compensation included in inventory was $0.9 million and $0.6 million, respectively.

[0001032975-19-000059:notes:34]
[same as prior period, unchanged from 0001032975-19-000007:notes:113]

[0001032975-19-000059:notes:35]
Certain of the Company’s subsidiaries sponsor defined benefit pension plans or non-retirement post-employment benefits covering substantially all of their employees. Benefits are provided based on employees’ years of service and earnings, or in accordance with applicable employee benefit regulations. The Company’s practice is to fund amounts sufficient to meet the requirements set forth in the applicable employee benefit and tax regulations. The costs recorded of $2.4 million and $2.3 million for the three months ended June 30, 2019 and 2018, respectively, were primarily related to service costs.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001032975-19-000059:notes:36]
[same as prior period, unchanged from 0001032975-19-000007:notes:152]

[0001032975-19-000059:notes:37]
[same as prior period, unchanged from 0001032975-19-000007:notes:153]

[0001032975-19-000059:notes:38]
The income tax provision for the three months ended June 30, 2019 was $6.5 million based on an effective income tax rate of 12.6% of pre-tax income, compared to an income tax benefit of $5.2 million based on an effective income tax rate of (15.7)% of pre-tax income for the three months ended June 30, 2018.

[0001032975-19-000059:notes:39]
On May 19, 2019, the Swiss electorate approved the Federal Act on Tax Reform and AHV Financing ("TRAF"), a major reform to better align the Swiss tax system with international tax standards. The tax reform is expected to take effect on January 1, 2020. As of June 30, 2019, TRAF has not been enacted as the federal and cantonal legislative procedures are in process.

[0001032975-19-000059:notes:40]
The change in the effective income tax rate for the three months ended June 30, 2019, compared to the same period ended June 30, 2018, was primarily due to the mix of income and losses in the various tax jurisdictions which the Company operates and the transitional income tax impact in Switzerland. The Company has benefited from a longstanding tax ruling from the canton of Vaud through March 31, 2019. The transitional income tax impact represents income tax provision at the current full statutory income tax rate of 13.62%, without taking account of the federal and cantonal tax reform yet to be enacted. In the three months ended June 30, 2019, there was a discrete tax provision of $2.3 million to record net deferred tax liability in Switzerland. Furthermore, there were discrete tax benefits of $5.8 million and $1.2 million from the recognition of excess tax benefits in the United States and reversal of uncertain tax positions from the expiration of statutes of limitations, respectively, in the three-month period ended June 30, 2019, compared with $8.3 million and $0.9 million, respectively, in the three-month period ended June 30, 2018.

[0001032975-19-000059:notes:41]
As of June 30, 2019 and March 31, 2019, the total amount of unrecognized tax benefits due to uncertain tax positions was $77.3 million and $76.5 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-19-000059:notes:42]
As of June 30, 2019 and March 31, 2019, the Company had $36.1 million and $36.4 million, respectively, in non-current income taxes payable including interest and penalties, related to the Company's income tax liability for uncertain tax positions.

[0001032975-19-000059:notes:43]
The Company recognizes interest and penalties related to unrecognized tax positions in income tax provision. As of June 30, 2019 and March 31, 2019, the Company had $2.6 million and $2.5 million, respectively, of accrued interest and penalties related to uncertain tax positions.

[0001032975-19-000059:notes:44]
Although the Company has adequately provided for uncertain tax positions, the provisions on these positions may change as revised estimates are made or the underlying matters are settled or otherwise resolved. During fiscal year 2020, the Company continues to review its tax positions and provide for or reverse unrecognized tax benefits as they arise. During the next twelve months, it is reasonably possible that the amount of unrecognized tax

[0001032975-19-000059:notes:45]
benefits could increase or decrease significantly due to changes in tax law in various jurisdictions, new tax audits and changes in the U.S. dollar as compared to other currencies. Excluding these factors, uncertain tax positions may decrease by as much as $3.7 million from the lapse of the statutes of limitations in various jurisdictions during the next twelve months.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001032975-19-000059:notes:46]
[same as prior period, unchanged from 0001032975-19-000007:notes:192]

[0001032975-19-000059:notes:47]
The following table presents the components of certain balance sheet asset amounts as of June 30 and March 31, 2019 (in thousands):

[0001032975-19-000059:notes:48]
|  |  | June 30, 2019 |  | March 31, 2019 |
| Accounts receivable, net: |  |  |  |  |  |  |
| Accounts receivable |  | $ | 602,656 |  |  | $ | 573,348 |  |
| Allowance for doubtful accounts |  | (1,029 | ) |  | (84 | ) |
| Allowance for sales returns |  | (5,505 | ) |  | (6,486 | ) |
| Allowance for cooperative marketing arrangements |  | (34,480 | ) |  | (35,080 | ) |
| Allowance for customer incentive programs |  | (58,021 | ) |  | (60,036 | ) |
| Allowance for pricing programs |  | (84,805 | ) |  | (88,353 | ) |
|  |  | $ | 418,816 |  |  | $ | 383,309 |  |
| Inventories: |  |  |  |  |  |  |
| Raw materials |  | $ | 41,380 |  |  | $ | 40,970 |  |
| Finished goods |  | 255,627 |  |  | 252,525 |  |
|  |  | $ | 297,007 |  |  | $ | 293,495 |  |
| Other current assets: |  |  |  |  |  |  |
| Value-added tax receivables |  | $ | 34,989 |  |  | $ | 34,321 |  |
| Prepaid expenses and other assets |  | 33,938 |  |  | 34,795 |  |
|  |  | $ | 68,927 |  |  | $ | 69,116 |  |
| Property, plant and equipment, net: |  |  |  |  |  |  |
| Property, plant and equipment at cost |  | $ | 362,099 |  |  | $ | 359,345 |  |
| Accumulated depreciation and amortization |  | (285,386 | ) |  | (280,793 | ) |
|  |  | $ | 76,713 |  |  | $ | 78,552 |  |
| Other assets: |  |  |  |  |  |  |
| Deferred tax assets |  | $ | 96,183 |  |  | $ | 90,808 |  |
| Right-of-use assets (1) |  | 31,994 |  |  | — |  |
| Trading investments for deferred compensation plan |  | 23,420 |  |  | 20,363 |  |
| Investments in privately held companies |  | 16,371 |  |  | 16,022 |  |
| Other assets |  | 5,480 |  |  | 5,260 |  |
|  |  | $ | 173,448 |  |  | $ | 132,453 |  |

[0001032975-19-000059:notes:49]
(1) Increase of balances was due to the adoption of Topic 842. Refer to Note 1 to the condensed consolidated financial statements for more information.

[0001032975-19-000059:notes:50]
The following table presents the components of certain balance sheet liability amounts as of June 30 and March 31, 2019 (in thousands):

[0001032975-19-000059:notes:51]
|  |  | June 30, 2019 |  | March 31, 2019 |
| Accrued and other current liabilities: |  |  |  |  |  |  |
| Accrued personnel expenses |  | $ | 67,869 |  |  | $ | 103,166 |  |
| Accrued sales return liability |  | 33,735 |  |  | 37,749 |  |
| Accrued customer marketing, pricing and incentive programs |  | 139,625 |  |  | 143,888 |  |
| Lease liability (1) |  | 12,358 |  |  | — |  |
| Warranty accrual |  | 22,461 |  |  | 21,524 |  |
| Income taxes payable |  | 7,445 |  |  | 6,207 |  |
| Other current liabilities |  | 111,182 |  |  | 121,363 |  |
|  |  | $ | 394,675 |  |  | $ | 433,897 |  |
| Other non-current liabilities: |  |  |  |  |  |  |
| Warranty accrual |  | $ | 13,353 |  |  | $ | 12,705 |  |
| Obligation for deferred compensation plan |  | 23,420 |  |  | 20,363 |  |
| Employee benefit plan obligation |  | 51,978 |  |  | 51,448 |  |
| Lease liability (1) |  | 25,816 |  |  | — |  |
| Deferred tax liability |  | 4,351 |  |  | 2,050 |  |
| Other non-current liabilities |  | 1,193 |  |  | 7,016 |  |
|  |  | $ | 120,111 |  |  | $ | 93,582 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001032975-19-000059:notes:52]
[same as prior period, unchanged from 0001032975-19-000007:notes:132]

[0001032975-19-000059:notes:53]
[same as prior period, unchanged from 0001032975-19-000007:notes:133]

[0001032975-19-000059:notes:54]
[same as prior period, unchanged from 0001032975-19-000007:notes:134]

[0001032975-19-000059:notes:55]
[same as prior period, unchanged from 0001032975-19-000007:notes:135]

[0001032975-19-000059:notes:56]
[same as prior period, unchanged from 0001032975-19-000007:notes:136]

[0001032975-19-000059:notes:57]
[same as prior period, unchanged from 0001032975-19-000007:notes:137]

[0001032975-19-000059:notes:58]
|  |  | June 30, 2019 |  | March 31, 2019 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Level 1 |  | Level 2 |  | Level 3 |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 497,035 |  |  | $ | — |  |  | $ | — |  |  | $ | 496,434 |  |  | $ | — |  |  | $ | — |  |
| Trading investments for deferred compensation plan included in other assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 5,315 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,080 |  |  | $ | — |  |  | $ | — |  |
| Mutual funds |  | 18,105 |  |  | — |  |  | — |  |  | 16,283 |  |  | — |  |  | — |  |
| Total of trading investments for deferred compensation plan |  | $ | 23,420 |  |  | $ | — |  |  | $ | — |  |  | $ | 20,363 |  |  | $ | — |  |  | $ | — |  |
| Currency exchange derivative assetsincluded in other current assets |  | $ | — |  |  | $ | 176 |  |  | $ | — |  |  | $ | — |  |  | $ | 455 |  |  | $ | — |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Currency exchange derivative liabilitiesincluded in accrued and other current liabilities |  | $ | — |  |  | $ | 1,177 |  |  | $ | — |  |  | $ | — |  |  | $ | 36 |  |  | $ | — |  |

[0001032975-19-000059:notes:59]
[same as prior period, unchanged from 0001032975-19-000007:notes:139]

[0001032975-19-000059:notes:60]
The marketable securities for the Company's deferred compensation plan were recorded at a fair value of $23.4 million and $20.4 million, as of June 30, 2019 and March 31, 2019, respectively, based on quoted market prices. Quoted market prices are observable inputs that are classified as Level 1 within the fair value hierarchy. Unrealized gains (losses) related to trading securities for the three months ended June 30, 2019 and 2018 were not material and are included in other income (expense), net in the Company's condensed consolidated statements of operations.

[0001032975-19-000059:notes:61]
Equity Method Investments

[0001032975-19-000059:notes:62]
The Company has certain non-marketable investments included in other assets that are accounted for under the equity method of accounting, with a carrying value of $7.0 million and $6.6 million as of June 30, 2019 and March 31, 2019, respectively.

[0001032975-19-000059:notes:63]
[same as prior period, unchanged from 0001032975-19-000007:notes:144]

[0001032975-19-000059:notes:64]
Financial Assets.  The Company has certain investments without readily determinable fair values due to the absence of quoted market prices, the inherent lack of liquidity, and the fact that inputs used to measure fair value are unobservable and require management's judgment. When certain events or circumstances indicate that impairment may exist, the Company revalues the investments using various assumptions, including the financial metrics and ratios of comparable public companies. The carrying value is also adjusted for observable price changes with a same or similar security from the same issuer. The amount of these investments included in other assets as of June 30, 2019 and March 31, 2019 was $9.5 million. There was no impairment of these assets during the three months ended June 30, 2019 or 2018.

[0001032975-19-000059:notes:65]
Non-Financial Assets. The Company’s non-financial assets, such as intangible assets and acquisition-related property, plant and equipment, are recorded at fair value only upon initial recognition or if an impairment is recognized. There was no impairment of these assets during the three months ended June 30, 2019 or 2018.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001032975-19-000059:notes:66]
[same as prior period, unchanged from 0001032975-19-000007:notes:117]

[0001032975-19-000059:notes:67]
Under certain agreements with the respective counterparties to the Company’s derivative contracts, subject to applicable requirements, the Company is allowed to net settle transactions of the same type with a single net

[0001032975-19-000059:notes:68]
amount payable by one party to the other. However, the Company presents its derivative assets and derivative liabilities on a gross basis on the condensed consolidated balance sheets as of June 30, 2019 and March 31, 2019.

[0001032975-19-000059:notes:69]
The fair value of the Company’s derivative instruments was not material as of June 30, 2019 or March 31, 2019. The amount of gain (loss) recognized on derivatives not designated as hedging instruments was not material in all periods presented herein. The following table presents the amounts of gains (losses) on the Company’s derivative instruments designated as hedging instruments and their locations on its condensed consolidated statements of operations and condensed consolidated statements of comprehensive income for the three months ended June 30, 2019 and 2018 (in thousands):

[0001032975-19-000059:notes:70]
|  |  | Three Months EndedJune 30, |
|  |  | Amount of Gain (Loss)Deferred as a Component of AccumulatedOther Comprehensive Loss |  | Amount of Loss (Gain)Reclassified from Accumulated Other Comprehensive Loss to Costs of Goods Sold |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Cash flow hedges |  | $ | (943 | ) |  | $ | 187 |  |  | $ | (226 | ) |  | $ | 2,851 |  |

[0001032975-19-000059:notes:71]
[same as prior period, unchanged from 0001032975-19-000007:notes:123]

[0001032975-19-000059:notes:72]
The Company enters into cash flow hedge contracts to protect against exchange rate exposure of forecasted inventory purchases. These hedging contracts mature within four months. Gains and losses in the fair value of the effective portion of the hedges are deferred as a component of accumulated other comprehensive loss until the hedged inventory purchases are sold, at which time the gains or losses are reclassified to cost of goods sold. Cash flows from such hedges are classified as operating activities in the condensed consolidated statements of cash flows. Hedging relationships are discontinued when hedging contract is no longer eligible for hedge accounting, or is sold, terminated or exercised, or when Company removes hedge designation for the contract. Gains and losses in the fair value of the effective portion of the discontinued hedges continue to be reported in accumulated other comprehensive loss until the hedged inventory purchases are sold, unless it is probable that the forecasted inventory purchases will not occur by the end of the originally specified time period or within an additional two-month period of time thereafter. In all periods presented herein, there have been no forecasted inventory purchases that were probable to not occur by the end of the originally specified time period or within an additional two-month period of time thereafter. The notional amounts of foreign currency exchange forward contracts outstanding related to forecasted inventory purchases were $68.2 million as of June 30, 2019 and $41.4 million as of March 31, 2019. The Company had $0.8 million of net losses related to its cash flow hedges included in accumulated other comprehensive loss as of June 30, 2019 which will be reclassified into earnings within the next 12 months.

[0001032975-19-000059:notes:73]
[same as prior period, unchanged from 0001032975-19-000007:notes:125]

[0001032975-19-000059:notes:74]
The Company also enters into foreign currency exchange forward and swap contracts to reduce the short-term effects of currency exchange rate fluctuations on certain receivables or payables denominated in currencies other than the functional currencies of its subsidiaries. These contracts generally mature within one month. The primary risk managed by using forward and swap contracts is the currency exchange rate risk. The gains or losses on these contracts are recognized in other income (expense), net in the condensed consolidated statements of operations based on the changes in fair value. The notional amounts of these contracts outstanding as of June 30, 2019 and March 31, 2019 were $53.2 million and $50.4 million, respectively. Open forward and swap contracts outstanding as of June 30, 2019 and March 31, 2019 consisted of contracts in Mexican Pesos, Japanese Yen, Canadian Dollars, Taiwan New Dollars and Australian Dollars to be settled at future dates at pre-determined exchange rates.

[0001032975-19-000059:notes:75]
[same as prior period, unchanged from 0001032975-19-000007:notes:127]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001032975-19-000059:notes:76]
[same as prior period, unchanged from 0001032975-19-000007:notes:146]

[0001032975-19-000059:notes:77]
The Company conducts its impairment analysis of goodwill annually at December 31 and as necessary, if changes in facts and circumstances indicate that it is more likely than not that the fair value of the Company’s reporting unit may be less than its carrying amount. There have been no events or circumstances during the three months ended June 30, 2019 that have required the Company to perform an interim assessment of goodwill.

[0001032975-19-000059:notes:78]
The following table summarizes the activities in the Company’s goodwill balance during the three months ended June 30, 2019 (in thousands):

[0001032975-19-000059:notes:79]
| As of March 31, 2019 |  | $ | 343,684 |  |
| Currency translation |  | 18 |  |
| As of June 30, 2019 |  | $ | 343,702 |  |

[0001032975-19-000059:notes:80]
[same as prior period, unchanged from 0001032975-19-000007:notes:150]

[0001032975-19-000059:notes:81]
|  |  | June 30, 2019 |  | March 31, 2019 |
|  |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |
| Trademark and trade names |  | $ | 36,370 |  |  | $ | (14,889 | ) |  | $ | 21,481 |  |  | $ | 36,370 |  |  | $ | (13,659 | ) |  | $ | 22,711 |  |
| Developed technology |  | 95,207 |  |  | (65,612 | ) |  | 29,595 |  |  | 95,207 |  |  | (62,341 | ) |  | 32,866 |  |
| Customer contracts/relationships |  | 84,610 |  |  | (23,554 | ) |  | 61,056 |  |  | 84,610 |  |  | (21,188 | ) |  | 63,422 |  |
| Total |  | $ | 216,187 |  |  | $ | (104,055 | ) |  | $ | 112,132 |  |  | $ | 216,187 |  |  | $ | (97,188 | ) |  | $ | 118,999 |  |


## us-gaap:DebtDisclosureTextBlock

[0001032975-19-000059:notes:82]
Financing Arrangements

[0001032975-19-000059:notes:83]
The Company had several uncommitted, unsecured bank lines of credit aggregating $79.3 million as of June 30, 2019. There are no financial covenants under these lines of credit with which the Company must comply. As of June 30, 2019, the Company had outstanding bank guarantees of $15.7 million under these lines of credit. There was no borrowing outstanding under these lines of credit as of June 30, 2019 or March 31, 2019.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001032975-19-000059:notes:84]
Commitments and Contingencies

[0001032975-19-000059:notes:85]
Product Warranties

[0001032975-19-000059:notes:86]
Changes in the Company’s warranty liability for the three months ended June 30, 2019 and 2018 were as follows (in thousands):

[0001032975-19-000059:notes:87]
|  | Three Months EndedJune 30, |
|  | 2019 |  | 2018 |
| Beginning of the period | $ | 34,229 |  |  | $ | 27,573 |  |
| Provision | 8,535 |  |  | 7,364 |  |
| Settlements | (6,977 | ) |  | (6,552 | ) |
| Currency translation | 27 |  |  | 468 |  |
| End of the period | $ | 35,814 |  |  | $ | 28,853 |  |

[0001032975-19-000059:notes:88]
Indemnifications

[0001032975-19-000059:notes:89]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of June 30, 2019, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

[0001032975-19-000059:notes:90]
The Company also indemnifies its current and former directors and certain of its current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. The Company is unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not limited, the obligations are conditional in nature and the facts and circumstances involved in any situation that might arise are variable.

[0001032975-19-000059:notes:91]
Legal Proceedings

[0001032975-19-000059:notes:92]
From time to time the Company is involved in claims and legal proceedings that arise in the ordinary course of its business. The Company is currently subject to several such claims and a small number of legal proceedings. The Company believes that these matters lack merit and intends to vigorously defend against them. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company’s defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company’s business, financial condition, cash flows or results of operations in a particular period. Any claims or proceedings against the Company, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain a necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company’s business.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001032975-19-000059:notes:93]
[same as prior period, unchanged from 0001032975-19-000007:notes:183]

[0001032975-19-000059:notes:94]
[same as prior period, unchanged from 0001032975-19-000007:notes:184]

[0001032975-19-000059:notes:95]
In March 2017, the Company's Board of Directors approved the 2017 share buyback program, which authorizes the Company to use up to $250.0 million to purchase up to 17.3 million shares of its own shares. The Company's share buyback program is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Purchases may be started or stopped at any time without prior notice depending on market conditions and other factors. As of June 30, 2019, $172.4 million is still available for repurchase under the 2017 buyback program.

[0001032975-19-000059:notes:96]
[same as prior period, unchanged from 0001032975-19-000007:notes:191]

[0001032975-19-000059:notes:97]
The accumulated other comprehensive income (loss) was as follows (in thousands):

[0001032975-19-000059:notes:98]
|  |  | Accumulated Other Comprehensive Income (Loss) |
|  |  | CumulativeTranslationAdjustment (1) |  | DefinedBenefitPlan (1) |  | Deferred Hedging Losses (1) |  | Total |
| March 31, 2019 |  | $ | (92,148 | ) |  | $ | (13,932 | ) |  | $ | 382 |  |  | $ | (105,698 | ) |
| Other comprehensive income (loss) |  | (278 | ) |  | (258 | ) |  | (1,169 | ) |  | (1,705 | ) |
| June 30, 2019 |  | $ | (92,426 | ) |  | $ | (14,190 | ) |  | $ | (787 | ) |  | $ | (107,403 | ) |

[0001032975-19-000059:notes:99]
(1)        Tax effect was not significant as of June 30 or March 31, 2019.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001032975-19-000059:notes:100]
[same as prior period, unchanged from 0001032975-19-000007:notes:176]

[0001032975-19-000059:notes:101]
The Company has determined that it operates in a single operating segment that encompasses the design, manufacturing and marketing of peripherals for PCs, tablets and other digital platforms. Operating performance measures are provided directly to the Company's CEO, who is considered to be the Company’s Chief Operating Decision Maker. The CEO periodically reviews information such as sales and adjusted operating income (loss) to make business decisions. These operating performance measures do not include restructuring charges (credits), net, share-based compensation expense, amortization of intangible assets, charges from the purchase accounting effect on inventory, acquisition-related costs or change in fair value of contingent consideration from business acquisition.

[0001032975-19-000059:notes:102]
Sales by product categories and sales channels, excluding intercompany transactions, for the three months ended June 30, 2019 and 2018 were as follows (in thousands):

[0001032975-19-000059:notes:103]
|  |  | Three Months EndedJune 30, |
|  |  | 2019 |  | 2018 |
| Pointing Devices |  | $ | 121,983 |  |  | $ | 127,790 |  |
| Keyboards & Combos |  | 128,679 |  |  | 128,222 |  |
| PC Webcams |  | 28,128 |  |  | 29,674 |  |
| Tablet & Other Accessories |  | 38,339 |  |  | 32,436 |  |
| Video Collaboration |  | 73,424 |  |  | 58,792 |  |
| Mobile Speakers |  | 50,416 |  |  | 34,327 |  |
| Audio & Wearables |  | 58,624 |  |  | 52,154 |  |
| Gaming |  | 134,515 |  |  | 136,026 |  |
| Smart Home |  | 9,864 |  |  | 9,011 |  |
| Other (1) |  | 253 |  |  | 48 |  |
| Total sales |  | $ | 644,225 |  |  | $ | 608,480 |  |

[0001032975-19-000059:notes:104]
(1) Other category includes products that the Company currently intends to phase out, or has already phased out, because they are no longer strategic to the Company's business.

[0001032975-19-000059:notes:105]
Sales by geographic region (based on the customers’ locations) for the three months ended June 30, 2019 and 2018 were as follows (in thousands):

[0001032975-19-000059:notes:106]
|  |  | Three Months EndedJune 30, |
|  |  | 2019 |  | 2018 |
| Americas |  | $ | 293,445 |  |  | $ | 276,928 |  |
| EMEA |  | 179,106 |  |  | 160,632 |  |
| Asia Pacific |  | 171,674 |  |  | 170,920 |  |
| Total sales |  | $ | 644,225 |  |  | $ | 608,480 |  |

[0001032975-19-000059:notes:107]
[same as prior period, unchanged from 0001032975-19-000007:notes:178]

[0001032975-19-000059:notes:108]
The United States, Germany, and China each represented more than 10% of the total consolidated sales for each of the periods presented herein. No other countries represented 10% or more of the Company’s total consolidated sales for the periods presented herein.

[0001032975-19-000059:notes:109]
Switzerland, the Company’s home domicile, represented 3% of the Company's total consolidated sales for the three months ended June 30, 2019 and represented 2% of the Company's total consolidated sales for the three months ended June 30, 2018.

[0001032975-19-000059:notes:110]
Two customers of the Company each represented more than 10% of the total consolidated gross sales for each of the periods presented herein.

[0001032975-19-000059:notes:111]
Property, plant and equipment, net by geographic region were as follows (in thousands):

[0001032975-19-000059:notes:112]
|  |  | June 30, 2019 |  | March 31, 2019 |
| Americas |  | $ | 27,746 |  |  | $ | 29,813 |  |
| EMEA |  | 4,803 |  |  | 4,537 |  |
| Asia Pacific |  | 44,164 |  |  | 44,202 |  |
| Total property, plant and equipment, net |  | $ | 76,713 |  |  | $ | 78,552 |  |

[0001032975-19-000059:notes:113]
Property, plant and equipment, net in the United States and China were $27.7 million and $36.5 million, respectively, as of June 30, 2019, and $29.8 million and $36.4 million, respectively, as of March 31, 2019. No other countries represented 10% or more of the Company’s total consolidated property, plant and equipment, net as of

[0001032975-19-000059:notes:114]
June 30, 2019 or March 31, 2019. Property, plant and equipment, net in Switzerland, the Company’s home domicile, were $2.0 million and $1.7 million as of June 30, 2019 and March 31, 2019, respectively.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001032975-19-000059:notes:115]
[same as prior period, unchanged from 0001032975-19-000007:notes:164]

[0001032975-19-000059:notes:116]
During the first quarter of fiscal year 2019, the Company implemented a restructuring plan to streamline and realign the Company's overall organizational structure and reallocate resources to support long-term growth opportunities. In July 2018, the Company's Board of Directors approved additional costs under this restructuring plan, totaling pre-tax charges of approximately $10.0 million to $15.0 million, of which $11.8 million has been recognized cumulatively as of June 30, 2019. The total charges consisted of cash severance and other personnel costs and are presented as restructuring charges, net in the condensed consolidated statements of operations, and the accrual balances are presented in accrued and other current liabilities in the condensed consolidated balance sheets. As of June 30, 2019, the Company has substantially completed this restructuring plan.

[0001032975-19-000059:notes:117]
The following table summarizes restructuring related activities during the three months ended June 30, 2019 (in thousands):

[0001032975-19-000059:notes:118]
|  |  | TerminationBenefits |
| Accrual balance at March 31, 2019 |  | $ | 4,389 |  |
| Charges |  | 478 |  |
| Cash payments |  | (1,956 | ) |
| Accrual balance at June 30, 2019 |  | $ | 2,911 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001032975-19-000059:notes:119]
Leases

[0001032975-19-000059:notes:120]
The Company is a lessee in several noncancellable operating leases, primarily real estate facilities for office space and for transportation and office equipment. The Company accounts for leases in accordance with Topic 842 (see Note 1) and determines if an arrangement is a lease or contains a lease at contract inception. ROU assets are included in other assets, short-term lease liabilities are included in accrued and other current liabilities, and long-term lease liabilities are included in other non-current liabilities on the Company's unaudited condensed consolidated balance sheet. Leases with an initial term of 12 months or less are not recorded on the balance sheet. For the Company's operating leases, the Company accounts for the lease and non-lease components as a single lease component. Lease expense is recognized on a straight-line basis over the lease term.

[0001032975-19-000059:notes:121]
For operating leases, the lease liability is initially and subsequently measured at the present value of the unpaid lease payments at lease commencement date.  Topic 842 requires a lessee to discount its unpaid lease payments using the interest rate implicit in the lease or, if the rate cannot be readily determined, its incremental borrowing rate. As the rate implicit in the lease is not readily determinable for the Company's operating leases, the Company generally uses an incremental borrowing rate as the discount rate for the lease. The Company's incremental borrowing rate is the rate of interest it would have to pay on a collateralized basis to borrow an amount equal to the lease payments under similar terms. Because the Company does not generally borrow in a collateralized basis, it uses its understanding of what its collateralized credit rating would be as an input to deriving an appropriate incremental borrowing rate. The operating lease right-of-use asset includes any lease payments made and excludes lease incentives.

[0001032975-19-000059:notes:122]
The Company's lease arrangements comprise of operating leases with various expiration dates through December 31, 2030. The lease term for all of the Company’s leases includes the noncancellable period of the lease. Certain lease agreements include options to renew or terminate the lease, which are not reasonably certain to be exercised and therefore are not factored into our determination of the duration of the lease arrangement.

[0001032975-19-000059:notes:123]
The Company's leases do not contain any material residual value guarantees.

[0001032975-19-000059:notes:124]
For the three months ended June 30, 2019, the total operating lease costs were $3.3 million, which included short-term lease costs and sublease income. Total variable lease costs were immaterial during the three months ended June 30, 2019. The total operating and variable lease costs were included in cost of goods sold, marketing

[0001032975-19-000059:notes:125]
and selling, research and development, and general and administrative in the Company's unaudited condensed consolidated statement of operations.

[0001032975-19-000059:notes:126]
As of June 30, 2019, the weighted-average remaining lease term was 4 years, and the weighted-average discount rate was 2.9%.

[0001032975-19-000059:notes:127]
For the three months ended June 30, 2019, cash paid for amounts included in the measurement of operating lease liabilities was $3.1 million and right-of-use assets obtained in exchange for new operating lease liabilities was $3.4 million.

[0001032975-19-000059:notes:128]
Future lease payments included in the measurement of lease liabilities as of June 30, 2019 for the following five fiscal years and thereafter are as follows (in thousands):

[0001032975-19-000059:notes:129]
|  | Operating Lease |
| Remaining 2020 | $ | 10,294 |  |
| 2021 | 11,003 |  |
| 2022 | 9,065 |  |
| 2023 | 5,486 |  |
| 2024 | 1,236 |  |
| Thereafter | 3,655 |  |
| Total lease payments | 40,739 |  |
| Less interest | (2,565 | ) |
| Present value of lease liabilities | $ | 38,174 |  |

[0001032975-19-000059:notes:130]
Future minimum lease payments, as defined under the previous lease accounting guidance of ASC Topic 840  under our non-cancelable operating leases as of March 31, 2019 were as follows (in thousands):

[0001032975-19-000059:notes:131]
| Years Ending March 31, | Operating Lease |
| 2020 | $ | 11,849 |  |
| 2021 | 10,002 |  |
| 2022 | 7,882 |  |
| 2023 | 5,111 |  |
| 2024 | 1,130 |  |
| Thereafter | 3,646 |  |
| Total lease payments | $ | 39,620 |  |
