# LOGI 8-K — 0001032975-19-000046 filed 2019-07-23

## item codes, every 8-K on or before 2019-07-25

- 2019-07-23 0001032975-19-000046 — 2.02, 9.01
- 2019-07-23 0001032975-19-000045 — 5.02, 9.01
- 2019-07-02 0001032975-19-000036 — 5.02
- 2019-06-25 0001032975-19-000034 — 5.02
- 2019-05-03 0001032975-19-000021 — 5.02 — amendment, the index does not say of what
- 2019-04-30 0001032975-19-000017 — 2.02, 5.02, 9.01
- 2019-03-28 0001032975-19-000013 — 5.02
- 2019-01-22 0001032975-19-000004 — 2.02, 9.01
- 2018-10-23 0001032975-18-000044 — 2.02, 9.01
- 2018-09-07 0001032975-18-000040 — 5.07, 8.01
- 2018-07-31 0001032975-18-000035 — 1.01, 2.02, 2.05, 7.01, 9.01
- 2018-06-27 0001032975-18-000020 — 5.02
- 2018-05-03 0001032975-18-000013 — 2.02, 5.02, 9.01
- 2018-01-23 0001032975-18-000005 — 2.02, 9.01
- 2017-10-24 0001032975-17-000043 — 2.02, 9.01
- 2017-09-18 0001032975-17-000040 — 5.07, 8.01
- 2017-07-25 0001032975-17-000028 — 2.02, 9.01
- 2017-07-12 0001032975-17-000022 — 1.01
- 2017-04-26 0001032975-17-000012 — 2.02, 9.01
- 2017-01-25 0001032975-17-000002 — 2.02, 9.01
- 2016-10-26 0001032975-16-000103 — 2.02, 9.01
- 2016-09-13 0001032975-16-000101 — 5.07, 8.01
- 2016-07-28 0001032975-16-000092 — 2.02, 9.01
- 2016-06-30 0001032975-16-000087 — 5.02
- 2016-04-28 0001032975-16-000077 — 2.02, 9.01
- 2016-04-14 0001032975-16-000073 — 1.01, 7.01, 9.01
- 2016-01-21 0001032975-16-000064 — 2.02, 9.01
- 2016-01-04 0001032975-16-000061 — 1.01, 2.01, 9.01
- 2015-12-23 0001032975-15-000059 — 5.02
- 2015-10-22 0001032975-15-000047 — 2.02, 9.01
- 2015-09-11 0001032975-15-000044 — 5.07, 8.01
- 2015-07-24 0001032975-15-000034 — 2.05 — amendment of 0001032975-15-000030
- 2015-07-23 0001032975-15-000030 — 2.02, 9.01
- 2015-06-25 0001032975-15-000025 — 5.02
- 2015-05-14 0001032975-15-000011 — 8.01, 9.01
- 2015-04-23 0001032975-15-000008 — 2.02, 2.05
- 2015-01-22 0001628280-15-000191 — 2.02, 8.01
- 2014-12-23 0001193125-14-450908 — 5.02, 5.07, 8.01
- 2014-11-25 0001193125-14-425233 — 3.01
- 2014-11-13 0001193125-14-411303 — 4.01, 9.01
- 2014-10-23 0001104659-14-073164 — 2.02, 9.01
- 2014-09-04 0001193125-14-331214 — 4.02, 9.01
- 2014-08-18 0001193125-14-313346 — 3.01, 9.01
- 2014-07-24 0001104659-14-053065 — 2.02, 9.01
- 2014-06-05 0001193125-14-226177 — 3.01, 9.01
- 2014-05-22 0001193125-14-208777 — 8.01, 9.01
- 2014-04-24 0001104659-14-029650 — 2.02, 9.01
- 2014-01-23 0001104659-14-003619 — 2.02, 9.01
- 2013-10-24 0001104659-13-077404 — 2.02, 9.01
- 2013-09-09 0001193125-13-361441 — 5.02, 5.07, 8.01, 9.01
- 2013-09-06 0001193125-13-359930 — 5.02, 9.01
- 2013-08-02 0001193125-13-317343 — 5.02
- 2013-07-25 0001104659-13-056372 — 2.02, 9.01
- 2013-06-28 0001193125-13-277394 — 5.02, 9.01
- 2013-06-20 0001193125-13-265914 — 8.01, 9.01
- 2013-04-25 0001104659-13-032570 — 2.02, 9.01
- 2013-04-17 0001193125-13-158923 — 5.02, 9.01
- 2013-03-01 0001193125-13-085804 — 2.05
- 2013-01-24 0001104659-13-004214 — 2.02, 9.01
- 2013-01-02 0001193125-13-000058 — 5.02
- 2012-10-25 0001104659-12-070966 — 2.02, 9.01
- 2012-09-11 0001193125-12-388070 — 5.02, 5.07, 8.01, 9.01
- 2012-08-22 0001193125-12-364167 — 5.02, 8.01, 9.01
- 2012-07-26 0001104659-12-051084 — 2.02, 9.01
- 2012-06-08 0001193125-12-264132 — 2.05, 9.01 — amendment, the index does not say of what
- 2012-04-26 0001193125-12-183657 — 5.02, 9.01
- 2012-04-26 0001104659-12-028470 — 2.02, 2.05, 9.01
- 2012-03-15 0001193125-12-115954 — 5.02, 9.01
- 2012-01-26 0001104659-12-004014 — 2.02, 9.01
- 2012-01-04 0001193125-12-002212 — 1.01, 2.03, 9.01
- 2011-10-27 0001104659-11-058150 — 2.02, 9.01
- 2011-09-12 0001193125-11-245931 — 5.07
- 2011-07-28 0001193125-11-200929 — 5.02, 9.01
- 2011-07-28 0001193125-11-199704 — 2.02, 9.01
- 2011-04-28 0001193125-11-112669 — 2.02, 9.01
- 2011-03-24 0001193125-11-076483 — 5.02, 9.01
- 2011-01-27 0001032975-11-000003 — 9.01
- 2010-10-28 0001032975-10-000032 — 9.01
- 2010-09-13 0001032975-10-000022 — 5.07
- 2010-07-29 0001032975-10-000010 — 2.02, 9.01
- 2010-06-10 0001193125-10-136877 — 5.02, 9.01
- 2010-05-03 0001193125-10-104337 — 5.02
- 2010-04-29 0001032975-10-000008 — 2.02, 9.01
- 2010-02-19 0001032975-10-000006 — 9.01 — amendment of 0001193125-09-252416
- 2010-01-21 0001032975-10-000002 — 2.02, 9.01
- 2009-12-14 0001193125-09-252416 — 2.01, 9.01
- 2009-11-17 0001032975-09-000023 — 1.01
- 2009-10-22 0001032975-09-000018 — 9.01
- 2009-09-22 0001193125-09-195545 — 5.02, 9.01
- 2009-09-03 0001032975-09-000013 — 8.01
- 2009-07-23 0001140361-09-016802 — 2.02, 9.01
- 2009-06-01 0001193125-09-122550 — 5.02
- 2009-04-23 0001193125-09-085054 — 2.02, 9.01
- 2009-04-02 0001193125-09-071272 — 5.02, 9.01
- 2009-01-20 0001193125-09-008454 — 2.05 — amendment of 0001193125-09-002609
- 2009-01-20 0001193125-09-007902 — 2.02, 9.01
- 2009-01-07 0001193125-09-002609 — 2.05, 9.01
- 2009-01-07 0001193125-09-002370 — 5.02, 9.01
- 2008-12-09 0001193125-08-250543 — 5.02, 9.01
- 2008-10-21 0001193125-08-213212 — 2.02, 9.01
- 2008-07-22 0001193125-08-154721 — 2.02, 9.01
- 2008-06-24 0001193125-08-139163 — 5.03, 9.01
- 2008-05-13 0001193125-08-113263 — 5.02, 9.01
- 2008-04-22 0001193125-08-086176 — 2.02, 9.01

## late-filing notifications on or before 2019-07-25

- 2015-06-02 0001032975-15-000020 — NT 10-K, for the period ended 2015-03-31
- 2014-11-06 0001193125-14-401306 — NT 10-Q, for the period ended 2014-09-30
- 2014-07-24 0001193125-14-277575 — NT 10-Q, for the period ended 2014-06-30
- 2014-05-22 0001193125-14-208712 — NT 10-K, for the period ended 2014-03-31
- 2009-08-06 0001032975-09-000006 — NT 10-Q, for the period ended 2009-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001032975-19-000046:8k_2_02:1]
EX-99.1
2
exhibit991q1fy20.htm
EXHIBIT 99.1

[0001032975-19-000046:8k_2_02:2]
Exhibit

[0001032975-19-000046:8k_2_02:3]
Exhibit 99.1

[0001032975-19-000046:8k_2_02:4]
Editorial Contacts:

[0001032975-19-000046:8k_2_02:5]
Ben Lu, Vice President, Investor Relations - USA (510) 713-5568

[0001032975-19-000046:8k_2_02:6]
Krista Todd, Vice President, Global Communications - USA (510) 713-5834

[0001032975-19-000046:8k_2_02:7]
Ben Starkie, Corporate Communications - Europe +41 (0) 79-292-3499

[0001032975-19-000046:8k_2_02:8]
Logitech Delivers a Strong Start to Fiscal Year 2020

[0001032975-19-000046:8k_2_02:9]
with Robust Sales and Profit Growth

[0001032975-19-000046:8k_2_02:10]
LAUSANNE, Switzerland - July 23, 2019 and NEWARK, Calif., July 22, 2019 - Logitech International (SIX: LOGN) (Nasdaq: LOGI) today announced financial results for the first quarter of Fiscal Year 2020.

[0001032975-19-000046:8k_2_02:11]
| • | Q1 sales were $644 million, up 6 percent in US dollars and 9 percent in constant currency, compared to Q1 of the prior year. |

[0001032975-19-000046:8k_2_02:12]
| • | Q1 GAAP operating income grew 46 percent to $47 million, compared to $32 million in the same quarter a year ago. Q1 GAAP earnings per share (EPS) grew 17 percent to $0.27, compared to $0.23 in the same quarter a year ago. |

[0001032975-19-000046:8k_2_02:13]
| • | Q1 non-GAAP operating income grew 11 percent to $67 million, compared to $61 million in the same quarter a year ago. Q1 non-GAAP EPS grew 15 percent to $0.39, compared to $0.34 in the same quarter a year ago. |

[0001032975-19-000046:8k_2_02:14]
| • | Cash flow from operations was $37 million, compared to $12 million in the same period a year ago. |

[0001032975-19-000046:8k_2_02:15]
“We had a strong start to the year thanks to the consistent execution of our strategy,” said Bracken Darrell, Logitech president and chief executive officer. “Our portfolio of innovative products continues to deliver. We achieved double-digit growth across a number of categories, including Video Collaboration, and growth in all three regions. I’m excited about our business and the innovation ahead of us.”

[0001032975-19-000046:8k_2_02:16]
Outlook

[0001032975-19-000046:8k_2_02:17]
Logitech confirmed its Fiscal Year 2020 outlook of mid to high single-digit sales growth in constant currency and $375 million to $385 million in non-GAAP operating income.

[0001032975-19-000046:8k_2_02:18]
CFO Search

[0001032975-19-000046:8k_2_02:19]
Logitech today confirmed that Nate Olmstead is now the Company’s new chief financial officer, effective immediately. Nate joined Logitech in 2019 as vice president of business finance, with over 16 years of financial management experience, most recently as the vice president of finance for global operations at Hewlett Packard Enterprise.

[0001032975-19-000046:8k_2_02:20]
“Nate has proven to be a good fit for us as a chief financial officer,” said Bracken Darrell, Logitech president and chief executive officer. “He has shown strong strategic insight, financial acumen, and

[0001032975-19-000046:8k_2_02:21]
practical operational experience. I look forward to building on our terrific partnership for many years to come.”

[0001032975-19-000046:8k_2_02:22]
Prepared Remarks Available Online

[0001032975-19-000046:8k_2_02:23]
Logitech has made its prepared written remarks for the financial results teleconference available online on the Logitech corporate website at http://ir.logitech.com.

[0001032975-19-000046:8k_2_02:24]
Financial Results Teleconference and Webcast

[0001032975-19-000046:8k_2_02:25]
Logitech will hold a financial results teleconference to discuss the results for Q1 FY 2020 on

[0001032975-19-000046:8k_2_02:26]
Tuesday, July 23, 2019 at 8:30 a.m. Eastern Daylight Time and 2:30 p.m. Central European Summer Time. A live webcast of the call will be available on the Logitech corporate website at http://ir.logitech.com.

[0001032975-19-000046:8k_2_02:27]
Use of Non-GAAP Financial Information and Constant Currency

[0001032975-19-000046:8k_2_02:28]
To facilitate comparisons to Logitech’s historical results, Logitech has included non-GAAP adjusted measures, which exclude share-based compensation expense, amortization of intangible assets, purchase accounting effect on inventory, acquisition-related costs, change in fair value of contingent consideration for business acquisition, restructuring charges (credits), loss (gain) on investments, non-GAAP income tax adjustment, and other items detailed under “Supplemental Financial Information” after the tables below. Logitech also presents percentage sales growth in constant currency to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales. Logitech believes this information, used together with the GAAP financial information, will help investors to evaluate its current period performance and trends in its business. With respect to the Company’s outlook for non-GAAP operating income, most of these excluded amounts pertain to events that have not yet occurred and are not currently possible to estimate with a reasonable degree of accuracy. Therefore, no reconciliation to the GAAP amounts has been provided for Fiscal Year 2020.

[0001032975-19-000046:8k_2_02:29]
About Logitech

[0001032975-19-000046:8k_2_02:30]
Logitech designs products that have an everyday place in people's lives, connecting them to the digital experiences they care about. More than 35 years ago, Logitech started connecting people through computers, and now it’s a multi-brand company designing products that bring people together through music, gaming, video and computing. Brands of Logitech include Logitech, Logitech G, ASTRO Gaming,Ultimate Ears, Jaybird and Blue Microphones. Founded in 1981, and headquartered in Lausanne, Switzerland, Logitech International is a Swiss public company listed on the SIX Swiss Exchange (LOGN) and on the Nasdaq Global Select Market (LOGI). Find Logitech at www.logitech.com, the company blog or@Logitech.

[0001032975-19-000046:8k_2_02:31]
# # #

[0001032975-19-000046:8k_2_02:32]
Note that unless noted otherwise, comparisons are year over year.

[0001032975-19-000046:8k_2_02:33]
Logitech and other Logitech marks are trademarks or registered trademarks of Logitech Europe S.A and/or its affiliates in the U.S. and other countries.  All other trademarks are the property of their respective owners. For more information about Logitech and its products, visit the company’s website at www.logitech.com.

[0001032975-19-000046:8k_2_02:34]
(LOGIIR)

[0001032975-19-000046:8k_2_02:35]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |
| PRELIMINARY RESULTS * |  |  |  |  |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |
|  |  | Three Months Ended |
|  |  | June 30, |
| GAAP CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  | 2019 |  | 2018 |
| Net sales |  | $ | 644,225 |  |  | $ | 608,480 |  |
| Cost of goods sold |  | 401,978 |  |  | 382,171 |  |
| Amortization of intangible assets and purchase accounting effect on inventory |  | 3,271 |  |  | 2,372 |  |
| Gross profit |  | 238,976 |  |  | 223,937 |  |
| Operating expenses: |  |  |  |  |
| Marketing and selling |  | 123,033 |  |  | 114,584 |  |
| Research and development |  | 42,243 |  |  | 38,987 |  |
| General and administrative |  | 22,159 |  |  | 25,473 |  |
| Amortization of intangible assets and acquisition-related costs |  | 3,596 |  |  | 2,521 |  |
| Restructuring charges, net |  | 478 |  |  | 9,921 |  |
| Total operating expenses |  | 191,509 |  |  | 191,486 |  |
| Operating income |  | 47,467 |  |  | 32,451 |  |
| Interest income |  | 2,553 |  |  | 2,369 |  |
| Other income (expense), net |  | 1,861 |  |  | (1,571 | ) |
| Income before income taxes |  | 51,881 |  |  | 33,249 |  |
| Provision for (benefit from) income taxes (A) |  | 6,536 |  |  | (5,217 | ) |
| Net income |  | $ | 45,345 |  |  | $ | 38,466 |  |
| Net income per share: |  |  |  |  |  |  |
| Basic |  | $ | 0.27 |  |  | $ | 0.23 |  |
| Diluted |  | $ | 0.27 |  |  | $ | 0.23 |  |
| Weighted average shares used to compute net income per share: |  |  |  |  |  |  |
| Basic |  | 166,302 |  |  | 165,317 |  |
| Diluted |  | 168,797 |  |  | 168,756 |  |

[0001032975-19-000046:8k_2_02:36]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |
| PRELIMINARY RESULTS * |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |
|  |  | June 30, 2019 |  | March 31, 2019 |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 596,956 |  |  | $ | 604,516 |  |
| Accounts receivable, net |  | 418,816 |  |  | 383,309 |  |
| Inventories |  | 297,007 |  |  | 293,495 |  |
| Other current assets |  | 68,927 |  |  | 69,116 |  |
| Total current assets |  | 1,381,706 |  |  | 1,350,436 |  |
| Non-current assets: |  |  |  |  |  |  |
| Property, plant and equipment, net |  | 76,713 |  |  | 78,552 |  |
| Goodwill |  | 343,702 |  |  | 343,684 |  |
| Other intangible assets, net |  | 112,132 |  |  | 118,999 |  |
| Other assets (B) |  | 173,448 |  |  | 132,453 |  |
| Total assets |  | $ | 2,087,701 |  |  | $ | 2,024,124 |  |
| Current liabilities: |  |  |  |  |  |  |
| Accounts payable |  | $ | 338,748 |  |  | $ | 283,922 |  |
| Accrued and other current liabilities (B) |  | 394,675 |  |  | 433,897 |  |
| Total current liabilities |  | 733,423 |  |  | 717,819 |  |
| Non-current liabilities: |  |  |  |  |  |  |
| Income taxes payable |  | 36,133 |  |  | 36,384 |  |
| Other non-current liabilities (B) |  | 120,111 |  |  | 93,582 |  |
| Total liabilities |  | 889,667 |  |  | 847,785 |  |
| Shareholders’ equity: |  |  |  |  |
| Registered shares, CHF 0.25 par value: |  | 30,148 |  |  | 30,148 |  |
| Issued shares — 173,106 at June 30 and March 31, 2019 |  |  |  |  |
| Additional shares that may be issued out of conditional capitals — 50,000 at June 30 and March 31, 2019 |  |  |  |  |
| Additional shares that may be issued out of authorized capital — 34,621 at June 30 and March 31, 2019 |  |  |  |  |
| Additional paid-in capital |  | 35,048 |  |  | 56,655 |  |
| Shares in treasury, at cost — 6,642 at June 30, 2019 and 7,244 at March 31, 2019 |  | (170,140 | ) |  | (169,802 | ) |
| Retained earnings |  | 1,410,381 |  |  | 1,365,036 |  |
| Accumulated other comprehensive loss |  | (107,403 | ) |  | (105,698 | ) |
| Total shareholders’ equity |  | 1,198,034 |  |  | 1,176,339 |  |
| Total liabilities and shareholders’ equity |  | $ | 2,087,701 |  |  | $ | 2,024,124 |  |

[0001032975-19-000046:8k_2_02:37]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |
| PRELIMINARY RESULTS * |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |
|  |  | Three Months Ended |
|  |  | June 30, |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |  | 2019 |  | 2018 |
| Cash flows from operating activities: |  |  |  |  |  |  |
| Net income |  | $ | 45,345 |  |  | $ | 38,466 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Depreciation |  | 10,802 |  |  | 10,699 |  |
| Amortization of intangible assets |  | 6,867 |  |  | 4,893 |  |
| Loss (gain) on investments |  | (211 | ) |  | 13 |  |
| Share-based compensation expense |  | 12,218 |  |  | 13,259 |  |
| Deferred income taxes |  | (3,381 | ) |  | (9,659 | ) |
| Other |  | (4 | ) |  | 124 |  |
| Changes in assets and liabilities, net of acquisitions: |  |  |  |  |
| Accounts receivable, net |  | (34,264 | ) |  | (68,557 | ) |
| Inventories |  | (2,681 | ) |  | (18,200 | ) |
| Other assets |  | (5,387 | ) |  | (4,225 | ) |
| Accounts payable |  | 55,592 |  |  | 51,188 |  |
| Accrued and other liabilities |  | (48,380 | ) |  | (5,719 | ) |
| Net cash provided by operating activities |  | 36,516 |  |  | 12,282 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  | (9,340 | ) |  | (8,744 | ) |
| Investment in privately held companies |  | (170 | ) |  | (225 | ) |
| Acquisitions, net of cash acquired |  | — |  |  | (243 | ) |
| Purchases of trading investments |  | (1,155 | ) |  | (2,500 | ) |
| Proceeds from sales of trading investments |  | 1,196 |  |  | 2,867 |  |
| Net cash used in investing activities |  | (9,469 | ) |  | (8,845 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |
| Purchases of registered shares |  | (15,127 | ) |  | (9,982 | ) |
| Proceeds from exercises of stock options and purchase rights |  | 393 |  |  | 1,104 |  |
| Tax withholdings related to net share settlements of restricted stock units |  | (19,370 | ) |  | (25,081 | ) |
| Net cash used in financing activities |  | (34,104 | ) |  | (33,959 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  | (503 | ) |  | (7,309 | ) |
| Net decrease in cash and cash equivalents |  | (7,560 | ) |  | (37,831 | ) |
| Cash and cash equivalents, beginning of the period |  | 604,516 |  |  | 641,947 |  |
| Cash and cash equivalents, end of the period |  | $ | 596,956 |  |  | $ | 604,116 |  |

[0001032975-19-000046:8k_2_02:38]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |
| PRELIMINARY RESULTS * |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |
| NET SALES |  | Three Months Ended |
|  |  | June 30, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2019 |  | 2018 |  | Change |
| Net sales by product category: |  |  |  |  |  |  |
| Pointing Devices |  | $ | 121,983 |  |  | $ | 127,790 |  |  | (5 | )% |
| Keyboards & Combos |  | 128,679 |  |  | 128,222 |  |  | — |  |
| PC Webcams |  | 28,128 |  |  | 29,674 |  |  | (5 | ) |
| Tablet & Other Accessories |  | 38,339 |  |  | 32,436 |  |  | 18 |  |
| Video Collaboration |  | 73,424 |  |  | 58,792 |  |  | 25 |  |
| Mobile Speakers |  | 50,416 |  |  | 34,327 |  |  | 47 |  |
| Audio & Wearables |  | 58,624 |  |  | 52,154 |  |  | 12 |  |
| Gaming |  | 134,515 |  |  | 136,026 |  |  | (1 | ) |
| Smart Home |  | 9,864 |  |  | 9,011 |  |  | 9 |  |
| Other (1) |  | 253 |  |  | 48 |  |  | 427 |  |
| Total sales |  | $ | 644,225 |  |  | $ | 608,480 |  |  | 6 | % |

[0001032975-19-000046:8k_2_02:39]
(1) Other category includes products that we currently intend to phase out, or have already phased out, because they are no longer strategic to our business.

[0001032975-19-000046:8k_2_02:40]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |
| PRELIMINARY RESULTS * |  |  |  |  |
| (In thousands, except per share amounts) - Unaudited |  |  |  |  |
| GAAP TO NON-GAAP RECONCILIATION (C) |  | Three Months Ended |
|  |  | June 30, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2019 |  | 2018 |
| Gross profit - GAAP |  | $ | 238,976 |  |  | $ | 223,937 |  |
| Share-based compensation expense |  | 1,158 |  |  | 1,130 |  |
| Amortization of intangible assets and purchase accounting effect on inventory |  | 3,271 |  |  | 2,372 |  |
| Gross profit - Non-GAAP |  | $ | 243,405 |  |  | $ | 227,439 |  |
| Gross margin - GAAP |  | 37.1 | % |  | 36.8 | % |
| Gross margin - Non-GAAP |  | 37.8 | % |  | 37.4 | % |
| Operating expenses - GAAP |  | $ | 191,509 |  |  | $ | 191,486 |  |
| Less: Share-based compensation expense |  | 11,060 |  |  | 12,129 |  |
| Less: Amortization of intangible assets and acquisition-related costs |  | 3,596 |  |  | 2,521 |  |
| Less: Restructuring charges, net |  | 478 |  |  | 9,921 |  |
| Operating expenses - Non-GAAP |  | $ | 176,375 |  |  | $ | 166,915 |  |
| % of net sales - GAAP |  | 29.7 | % |  | 31.5 | % |
| % of net sales - Non - GAAP |  | 27.4 | % |  | 27.4 | % |
| Operating income - GAAP |  | $ | 47,467 |  |  | $ | 32,451 |  |
| Share-based compensation expense |  | 12,218 |  |  | 13,259 |  |
| Amortization of intangible assets |  | 6,867 |  |  | 4,893 |  |
| Restructuring charges, net |  | 478 |  |  | 9,921 |  |
| Operating income - Non - GAAP |  | $ | 67,030 |  |  | $ | 60,524 |  |
| % of net sales - GAAP |  | 7.4 | % |  | 5.3 | % |
| % of net sales - Non - GAAP |  | 10.4 | % |  | 9.9 | % |
| Net income - GAAP |  | $ | 45,345 |  |  | $ | 38,466 |  |
| Share-based compensation expense |  | 12,218 |  |  | 13,259 |  |
| Amortization of intangible assets |  | 6,867 |  |  | 4,893 |  |
| Restructuring charges, net |  | 478 |  |  | 9,921 |  |
| Loss (gain) on investments |  | (211 | ) |  | 13 |  |
| Non-GAAP income tax adjustment |  | 907 |  |  | (9,109 | ) |
| Net income - Non - GAAP |  | $ | 65,604 |  |  | $ | 57,443 |  |
| Net income per share: |  |  |  |  |
| Diluted - GAAP |  | $ | 0.27 |  |  | $ | 0.23 |  |
| Diluted - Non - GAAP |  | $ | 0.39 |  |  | $ | 0.34 |  |
| Shares used to compute net income per share: |  |  |  |  |
| Diluted - GAAP and Non - GAAP |  | 168,797 |  |  | 168,756 |  |

[0001032975-19-000046:8k_2_02:41]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |
| PRELIMINARY RESULTS * |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |
| SHARE-BASED COMPENSATION EXPENSE |  | Three Months Ended |
|  |  | June 30, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2019 |  | 2018 |
| Share-based Compensation Expense |  |  |  |  |
| Cost of goods sold |  | $ | 1,158 |  |  | $ | 1,130 |  |
| Marketing and selling |  | 6,849 |  |  | 5,786 |  |
| Research and development |  | 2,154 |  |  | 1,549 |  |
| General and administrative |  | 2,057 |  |  | 4,794 |  |
| Total share-based compensation expense |  | 12,218 |  |  | 13,259 |  |
| Income tax benefit |  | (6,800 | ) |  | (9,529 | ) |
| Total share-based compensation expense, net of income tax benefit |  | $ | 5,418 |  |  | $ | 3,730 |  |

[0001032975-19-000046:8k_2_02:42]
*  Note: These preliminary results for the three months ended June 30, 2019 are subject to adjustments, including subsequent events that may occur through the date of filing our Quarterly Report on Form 10-Q.

[0001032975-19-000046:8k_2_02:43]
(A) Swiss Federal Tax Reform

[0001032975-19-000046:8k_2_02:44]
On May 19, 2019, the Swiss electorate approved the Federal Act on Tax Reform & AHV Financing ("TRAF"), a major reform to better align the Swiss tax system with international tax standards. TRAF specifies mandatory and/or voluntary provisions in the cantonal tax law to the extent the federal reform measures are to be implemented through the modification of the cantonal tax law. The harmonization is expected to take effect on January 1, 2020.

[0001032975-19-000046:8k_2_02:45]
The income tax provision for the three months ended June 30, 2019 was $6.5 million based on an effective income tax rate of 12.6% of pre-tax income, compared to an income tax benefit of $5.2 million based on an effective income tax rate of (15.7)% of pre-tax income for the three months ended June 30, 2018. The increase in our tax rate reflects the transitional income tax impact in Switzerland. The transitional income tax impact represents income tax provision at the current full statutory income tax rate of 13.62%, without taking account of the federal and cantonal tax reform yet to be enacted. We expect a gradual and modest increase in our cash tax payments in Switzerland each year until we fully reflect the new Swiss tax rate.

[0001032975-19-000046:8k_2_02:46]
(B)  Adoption of ASC Topic 842

[0001032975-19-000046:8k_2_02:47]
We adopted the new standards for leases under Accounting Standards Codification ("ASC") Topic 842 using the modified retrospective approach as of April 1, 2019 and did not restate the financial statements of the comparative periods as is allowed by election of the transition option under ASC 842. Adoption of the standard resulted in the recognition of $32.0 million of right-of-use assets, $12.4 million of short-term lease liabilities and $25.8 million of long-term lease liabilities related to our leases on June 30, 2019.

[0001032975-19-000046:8k_2_02:48]
(C) Non-GAAP Financial Measures

[0001032975-19-000046:8k_2_02:49]
To supplement our condensed consolidated financial results prepared in accordance with GAAP, we use a number of financial measures, both GAAP and non-GAAP, in analyzing and assessing our overall business performance, for making operating decisions and for forecasting and planning future periods. We consider the use of non-GAAP financial measures helpful in assessing our current financial performance, ongoing operations and prospects for the future as well as understanding financial and business trends relating to our financial condition and results of operations.

[0001032975-19-000046:8k_2_02:50]
While we use non-GAAP financial measures as a tool to enhance our understanding of certain aspects of our financial performance and to provide incremental insight into the underlying factors and trends affecting both our performance and our cash-generating potential, we do not consider these measures to be a substitute for, or superior to, the information provided by GAAP financial measures. Consistent with this approach, we believe that disclosing non-GAAP financial measures to the readers of our financial statements provides useful supplemental data that, while not a substitute for GAAP financial measures, can offer insight in the review of our financial and operational performance and enables investors to more fully understand trends in our current and future performance. In assessing our business during the quarter ended June 30, 2019 and previous periods, we excluded items in the following general categories, each of which are described below:

[0001032975-19-000046:8k_2_02:51]
Share-based compensation expenses. We believe that providing non-GAAP measures excluding share-based compensation expense, in addition to the GAAP measures, allows for a more transparent comparison of our financial results from period to period. We prepare and maintain our budgets and forecasts for future periods on a basis consistent with this non-GAAP financial measure. Further, companies use a variety of types of equity awards as well as a variety of methodologies, assumptions and estimates to determine share-based compensation expense. We believe that excluding share-based compensation expense enhances our ability and the ability of investors to understand the impact of non-cash share-based compensation on our operating results and to compare our results against the results of other companies.

[0001032975-19-000046:8k_2_02:52]
Amortization of intangible assets. We incur intangible asset amortization expense, primarily in connection with our acquisitions of various businesses and technologies. The amortization of purchased intangibles varies depending on the level of acquisition activity. We exclude these various charges in budgeting, planning and forecasting future periods and we believe that providing the non-GAAP measures excluding these various non-cash charges, as well as the GAAP measures, provides additional insight when comparing our gross profit, operating expenses, and financial results from period to period.

[0001032975-19-000046:8k_2_02:53]
Purchase accounting effect on inventory. Business combination accounting principles require us to measure acquired inventory at fair value. The fair value of inventory reflects the acquired company’s cost of manufacturing plus a portion of the expected profit margin. The non-GAAP adjustment excludes the expected profit margin component that is recorded under business combination accounting principles associated with our business acquisitions. We believe the adjustment is useful to investors because such charges are not reflective of our ongoing operations.

[0001032975-19-000046:8k_2_02:54]
Acquisition-related costs and change in fair value of contingent consideration for business acquisition.  We incurred expenses and credits in connection with our acquisitions which we generally would not have otherwise incurred in the periods presented as a part of our continuing operations. Acquisition related costs include all incremental expenses incurred to effect a business combination. Fair value of contingent consideration is associated with our estimates of the value of earn-outs in connection with certain acquisitions. We believe that providing the non-GAAP measures excluding these costs and credits, as well as the GAAP measures, assists our investors because such costs are not reflective of our ongoing operating results.

[0001032975-19-000046:8k_2_02:55]
Restructuring charges (credits). These expenses are associated with re-aligning our business strategies based on current economic conditions. We have undertaken several restructuring plans in recent years. In connection with our restructuring initiatives, we incurred restructuring charges related to employee terminations, facility closures and early cancellation of certain contracts. We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges (credits) are not reflective of our ongoing operating results in the current period.

[0001032975-19-000046:8k_2_02:56]
Loss (gain) on investments. We recognized loss (gain) related to our investments in various companies, which varies depending on the operational and financial performance of those companies in which we invested. We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges are not reflective of our ongoing operations.

[0001032975-19-000046:8k_2_02:57]
Non-GAAP income tax adjustment.  Non-GAAP income tax adjustment primarily measures the income tax effect of non-GAAP adjustments excluded above and other events; the determination of which is based upon the nature of the underlying items, the mix of income and losses in jurisdictions and the relevant tax rates in which we operate.

[0001032975-19-000046:8k_2_02:58]
Each of the non-GAAP financial measures described above, and used in this press release, should not be considered in isolation from, or as a substitute for, a measure of financial performance prepared in accordance with GAAP. Further, investors are cautioned that there are inherent limitations associated with the use of each of these non-GAAP financial measures as an analytical tool. In particular, these non-GAAP financial measures are not based on a comprehensive set of accounting rules or principles and many of the adjustments to the GAAP financial measures reflect the exclusion of items that are recurring and may be reflected in the Company’s financial results for the foreseeable future. We compensate for these limitations by providing specific information in the reconciliation included in this press release regarding the GAAP amounts excluded from the non-GAAP financial measures. In addition, as noted above, we evaluate the non-GAAP financial measures together with the most directly comparable GAAP financial information.

[0001032975-19-000046:8k_2_02:59]
Additional Supplemental Financial Information - Constant Currency

[0001032975-19-000046:8k_2_02:60]
In addition, Logitech presents percentage sales growth in constant currency to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales.
