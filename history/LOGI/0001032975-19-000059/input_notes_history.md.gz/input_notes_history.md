# LOGI note change history — 0001032975-19-000007 → 0001032975-19-000059


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-07-25):
[0001032975-19-000059:note_history:1]
Changes in the Company’s warranty liability for the three months ended June 30, 2019 and 2018 were as follows (in thousands):
  (was, 2019-01-24, similarity 0.9231):
[0001032975-19-000007:note_history:1]
Changes in the Company’s warranty liability for the three and nine months ended December 31, 2018 and 2017 were as follows (in thousands):

- added (2019-07-25):
[0001032975-19-000059:note_history:2]
|  | Three Months EndedJune 30, |
|  | 2019 |  | 2018 |
| Beginning of the period | $ | 34,229 |  |  | $ | 27,573 |  |
| Provision | 8,535 |  |  | 7,364 |  |
| Settlements | (6,977 | ) |  | (6,552 | ) |
| Currency translation | 27 |  |  | 468 |  |
| End of the period | $ | 35,814 |  |  | $ | 28,853 |  |

- changed (2019-07-25):
[0001032975-19-000059:note_history:3]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of June 30, 2019, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.
  (was, 2019-01-24, similarity 0.9906):
[0001032975-19-000007:note_history:3]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of December 31, 2018, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

- removed (2019-07-25):
[0001032975-19-000007:note_history:4]
All of the Company's products are covered by warranty to be free from defects in material and workmanship for periods ranging from one year to five years. The Company’s warranty doesn’t provide a service beyond assuring that the product complies with agreed-upon specifications and is not sold separately. The warranty the Company provides qualifies as an assurance warranty and is not treated as a separate performance obligation. The Company estimates cost of product warranties at the time the related revenue is recognized based on historical warranty claim rates, historical costs, and knowledge of specific product failures that are outside of the Company's typical experience. The Company accrues a warranty liability for estimated costs to provide products, parts or services to repair or replace products in satisfaction of the warranty obligation. Each quarter, the Company reevaluates estimates to assess the adequacy of recorded warranty liabilities. When the Company experiences changes in warranty claim activity or costs associated with fulfilling those claims, the warranty liability is adjusted accordingly. If actual product failure rates or repair costs differ from estimates, revisions to the estimated warranty liabilities would be required and could materially affect the Company's results of operations.

- removed (2019-07-25):
[0001032975-19-000007:note_history:5]
|  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Beginning of the period | $ | 31,754 |  |  | $ | 24,349 |  |  | $ | 27,573 |  |  | $ | 21,911 |  |
| Assumed from business acquisition | — |  |  | — |  |  | 351 |  |  | 1,230 |  |
| Provision | 11,305 |  |  | 7,820 |  |  | 30,625 |  |  | 17,535 |  |
| Settlements | (7,523 | ) |  | (6,050 | ) |  | (22,405 | ) |  | (15,229 | ) |
| Currency translation | (61 | ) |  | 145 |  |  | (669 | ) |  | 817 |  |
| End of the period | $ | 35,475 |  |  | $ | 26,264 |  |  | $ | 35,475 |  |  | $ | 26,264 |  |

- removed (2019-07-25):
[0001032975-19-000007:note_history:6]
Guarantees

- removed (2019-07-25):
[0001032975-19-000007:note_history:7]
Logitech Europe S.A., one of the Company's wholly-owned subsidiaries, has guaranteed payments of certain third-party contract manufacturers’ purchase obligations. As of December 31, 2018, the maximum amount of this guarantee was $3.8 million.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-07-25):
[0001032975-19-000059:note_history:8]
The condensed consolidated financial statements include the accounts of Logitech and its subsidiaries. All intercompany balances and transactions have been eliminated. The condensed consolidated financial statements are presented in accordance with accounting principles generally accepted in the United States of America (“GAAP”) for interim financial information and therefore do not include all the information required by GAAP for complete financial statements. The condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended March 31, 2019, included in its Annual Report on Form 10-K filed with the Securities and Exchange Commission (“SEC”) on May 17, 2019.
  (was, 2019-01-24, similarity 0.9692):
[0001032975-19-000007:note_history:8]
The condensed consolidated financial statements include the accounts of Logitech and its subsidiaries. All intercompany balances and transactions have been eliminated. The condensed consolidated financial statements are presented in accordance with accounting principles generally accepted in the United States of America (“GAAP”) for interim financial information and therefore do not include all the information required by GAAP for complete financial statements. They should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended March 31, 2018, included in its Annual Report on Form 10-K filed with the Securities and Exchange Commission (“SEC”) on May 21, 2018.

- changed (2019-07-25):
[0001032975-19-000059:note_history:9]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three months ended June 30, 2019 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2020, or any future periods.
  (was, 2019-01-24, similarity 0.9573):
[0001032975-19-000007:note_history:9]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and nine months ended December 31, 2018 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2019, or any future periods.

- changed (2019-07-25):
[0001032975-19-000059:note_history:10]
Other than the recent accounting pronouncements adopted and discussed below under Recent Accounting Pronouncements Adopted and Summary of Significant Accounting Policies, there have been no changes in the Company’s significant accounting policies during the three months ended June 30, 2019 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2019.
  (was, 2019-01-24, similarity 0.941):
[0001032975-19-000007:note_history:10]
Other than the recent accounting pronouncements adopted and discussed below under Recent Accounting Pronouncements Adopted and Summary of Significant Accounting Policies, there have been no changes in the Company’s significant accounting policies during the nine months ended December 31, 2018 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2018.

- added (2019-07-25):
[0001032975-19-000059:note_history:11]
The preparation of financial statements in conformity with GAAP requires management to make judgments, estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Significant estimates and assumptions made by management involve the fair value of goodwill, intangible assets acquired from business acquisitions, valuation of operating right-of-use assets, warranty liabilities, accruals for customer incentives, cooperative marketing, and pricing programs (Customer Programs) and related breakage when appropriate, accrued sales return liability, allowance for doubtful accounts, inventory valuation, share-based compensation expense, uncertain tax positions, and valuation allowances for deferred tax assets.

- added (2019-07-25):
[0001032975-19-000059:note_history:12]
Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ materially from these estimates.

- added (2019-07-25):
[0001032975-19-000059:note_history:13]
In February 2016, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) No. 2016-02, "Leases (Topic 842)" (ASU 2016-02 or Topic 842), which requires a lessee to recognize right-of-use (ROU) assets and lease liabilities arising from operating and financing leases with terms longer than 12 months on the consolidated balance sheets and to disclose key information about leasing arrangements.

- added (2019-07-25):
[0001032975-19-000059:note_history:14]
The Company adopted the new standard effective April 1, 2019 and recorded an ROU asset and lease liability related to its operating leases. The Company used the modified retrospective approach with the effective date as the date of initial application. Accordingly, the Company applied the new lease standard prospectively to leases existing or commencing on or after April 1, 2019. Prior period balances and disclosures have not been restated. The Company elected the package of transitional practical expedients, which among other provisions, allows the Company to not reassess under the new standard the Company's prior conclusions about lease identification, lease classification and initial direct cost, for any existing leases on the adoption date. In addition, for operating leases, the Company elected to account for lease and non-lease components as a single lease component. The Company also made an accounting policy election to not recognize lease liabilities and ROU assets on its condensed consolidated balance sheet for leases that, at the lease commencement date, have a lease term of 12 months or less.

- added (2019-07-25):
[0001032975-19-000059:note_history:15]
Adoption of the standard resulted in the recognition of $31.3 million of ROU assets and $37.4 million of lease liabilities related to the Company's leases on its condensed consolidated balance sheet on April 1, 2019. The difference of $6.1 million represented deferred rent for leases that existed as of the date of adoption, which decreased the opening balance of ROU assets. In addition, the prepaid rent balance as of the date of adoption increased the opening balance of ROU assets. The deferred rent and prepaid rent balances were derecognized as of the date of adoption and no adjustment was made to retained earnings. The adoption of the standard did not have an impact on our condensed consolidated statement of operations, comprehensive income, changes in shareholders' equity or cash flows.

- changed (2019-07-25):
[0001032975-19-000059:note_history:16]
In August 2018, the FASB issued ASU 2018-15, "Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40): Customer's Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract" (ASU 2018-15), which clarifies that implementation costs incurred by customers in cloud computing arrangements are deferred if they would be capitalized by customers in software licensing arrangements under the internal-use software guidance. ASU 2018-15 is effective for annual and interim periods in fiscal years beginning after December 15, 2019, with early adoption permitted. Entities have the option to apply the guidance prospectively to all implementation costs incurred after the date of adoption or retrospectively. The Company adopted this standard effective April 1, 2019 using a prospective adoption method. The adoption of ASU 2018-15 did not have a material impact on the Company's condensed consolidated financial statements.
  (was, 2019-01-24, similarity 0.8226):
[0001032975-19-000007:note_history:16]
In August 2018, the FASB issued ASU 2018-15, "Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40): Customer's Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract" ("ASU 2018-15"), which clarifies that implementation costs incurred by customers in cloud computing arrangements are deferred if they would be capitalized by customers in software licensing arrangements under the internal-use software guidance. ASU 2018-15 is effective for annual and interim periods in fiscal years beginning after December 15, 2019, with early adoption permitted. Entities have the option to apply the guidance prospectively to all implementation costs incurred after the date of adoption or retrospectively. The Company does not expect the adoption of ASU 2018-15 will have a material impact on its consolidated financial statements and will adopt the standard effective April 1, 2020.

- changed (2019-07-25):
[0001032975-19-000059:note_history:17]
In August 2018, the FASB issued ASU 2018-13, "Fair Value Measurement (Topic 820): Disclosure Framework - Changes to the Disclosure Requirements for Fair Value Measurements" (ASU 2018-13), which aims to improve the overall usefulness of disclosures to financial statement users and reduce unnecessary costs to companies when preparing fair value measurement disclosures. ASU 2018-13 is effective for annual and interim periods in fiscal years beginning after December 15, 2019. Early adoption is permitted. Retrospective adoption is required, except for certain disclosures which will be required to be applied prospectively for only the most recent interim or annual period presented in the initial fiscal year of adoption. The Company does not expect the adoption of ASU 2018-13 will have a material impact on its consolidated financial statements and plans to adopt the standard effective April 1, 2020.
  (was, 2019-01-24, similarity 0.9471):
[0001032975-19-000007:note_history:17]
In August 2018, the FASB issued ASU 2018-13, "Fair Value Measurement (Topic 820): Disclosure Framework - Changes to the Disclosure Requirements for Fair Value Measurements" ("ASU 2018-13"), which aims to improve the overall usefulness of disclosures to financial statement users and reduce unnecessary costs to companies when preparing fair value measurement disclosures. ASU 2018-13 is effective for annual and interim periods in fiscal years beginning after December 15, 2019. Early adoption is permitted. Retrospective adoption is required, except for certain disclosures which will be required to be applied prospectively for only the most recent interim or annual period presented in the initial fiscal year of adoption. The Company does not expect the adoption of ASU 2018-13 will have a material impact on its consolidated financial statements and will adopt the standard effective April 1, 2020.

- changed (2019-07-25):
[0001032975-19-000059:note_history:18]
In August 2018, the FASB issued ASU 2018-14, "Compensation - Retirement Benefits - Defined Benefits Plans - General (Subtopic 715-20): Disclosure Framework - Changes to the Disclosure Requirements for Defined Benefit Plans" (ASU 2018-14), which aims to improve the overall usefulness of disclosures to financial statement users and reduce unnecessary costs to companies when preparing defined benefit plan disclosures. ASU 2018-14 is effective for annual periods in fiscal years ending after December 15, 2020. Retrospective adoption is required and early
  (was, 2019-01-24, similarity 0.8339):
[0001032975-19-000007:note_history:18]
In August 2018, the FASB issued ASU 2018-14, "Compensation - Retirement Benefits - Defined Benefits Plans - General (Subtopic 715-20): Disclosure Framework - Changes to the Disclosure Requirements for Defined Benefit Plans" ("ASU 2018-14"), which aims to improve the overall usefulness of disclosures to financial statement users and reduce unnecessary costs to companies when preparing defined benefit plan disclosures. ASU 2018-14 is effective for annual periods in fiscal years ending after December 15, 2020. Retrospective adoption is required and early adoption is permitted. The Company does not expect the adoption of ASU 2018-14 will have a material impact on its consolidated financial statements and will adopt the standard effective April 1, 2020.

- added (2019-07-25):
[0001032975-19-000059:note_history:19]
adoption is permitted. The Company does not expect the adoption of ASU 2018-14 will have a material impact on its consolidated financial statements and plans to early adopt the standard effective April 1, 2020.

- removed (2019-07-25):
[0001032975-19-000007:note_history:20]
Business Acquisition

- removed (2019-07-25):
[0001032975-19-000007:note_history:21]
In August 2018, the Company acquired Blue Microphones Holding Corporation. See "Note 2 - Business Acquisition" for more information.

- removed (2019-07-25):
[0001032975-19-000007:note_history:22]
Reclassification

- removed (2019-07-25):
[0001032975-19-000007:note_history:23]
Certain amounts from the comparative period in the accompanying condensed consolidated financial statements have been reclassified to conform to the condensed consolidated financial statement presentation as of and for the three and nine months ended December 31, 2018.

- removed (2019-07-25):
[0001032975-19-000007:note_history:24]
The preparation of financial statements in conformity with GAAP requires management to make judgments, estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Significant estimates and assumptions made by management involve the fair value of goodwill, intangible assets acquired from business acquisitions, warranty liabilities, accruals for customer incentives, cooperative marketing, and pricing programs ("Customer Programs") and related breakage when appropriate, accrued revenue reserve from returns, allowance for doubtful accounts, inventory valuation, contingent consideration from business acquisitions and periodical reassessment of its fair value, share-based compensation expense, uncertain tax positions, and valuation allowances for deferred tax assets. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ materially from these estimates.

- removed (2019-07-25):
[0001032975-19-000007:note_history:25]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-09, "Revenue from Contracts with Customers (Topic 606)" ("ASU 2014-09" or “Topic 606”) which supersedes the revenue recognition requirements under Accounting Standards Codification ("ASC") 605 (“Topic 605”), Revenue Recognition. ASU 2014-09 outlines a new, single, comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes existing revenue recognition guidance, including industry-specific guidance. Under the new guidance, recognition of revenue occurs when a customer obtains control of promised goods or services in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. The new standard requires reporting companies to disclose the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. On April 1, 2018, the Company adopted the new standard and all related amendments using the modified retrospective method applied to those contracts which were not completed as of April 1, 2018. Results for reporting periods beginning after March 31, 2018 are presented under Topic 606, while prior period amounts are not adjusted and continue to be reported in accordance with historic accounting standards under Topic 605.

- removed (2019-07-25):
[0001032975-19-000007:note_history:26]
As a result of the adoption of the new standard, the Company a) recorded a reduction to retained earnings as of April 1, 2018; and b) reclassified certain allowances for sales returns and certain other Customer Programs from accounts receivable, net to accrued and other current liabilities and other current assets.

- removed (2019-07-25):
[0001032975-19-000007:note_history:27]
The cumulative effect of the changes to the condensed consolidated balance sheet from the adoption of Topic 606 was as follows (in thousands):

- removed (2019-07-25):
[0001032975-19-000007:note_history:28]
|  |  | As of March 31, 2018 |  | Effect of Adoption of Topic 606 |  | As of April 1, 2018 |
| Accounts receivable, net |  | $ | 214,885 |  |  | $ | 105,768 |  |  | $ | 320,653 |  |
| Other current assets |  | 56,362 |  |  | 6,195 |  |  | 62,557 |  |
| Accrued and other current liabilities |  | 281,732 |  |  | 122,845 |  |  | 404,577 |  |
| Retained earnings |  | 1,232,316 |  |  | (10,882 | ) |  | 1,221,434 |  |

- removed (2019-07-25):
[0001032975-19-000007:note_history:29]
Net Reduction to Retained Earnings as of April 1, 2018

- removed (2019-07-25):
[0001032975-19-000007:note_history:30]
| • | Under Topic 605, accruals for certain Customer Programs were recognized as a reduction of revenue at the later of when the related revenue is recognized or when the program is offered to the customer. Under Topic 606, these programs qualify as variable consideration and are recorded as a reduction of the transaction price at contract inception based on the expected value method. The Company is required to estimate the accruals for these programs ahead of commitment date if customary business practice creates an implied expectation that such activities will occur in the future. |

- removed (2019-07-25):
[0001032975-19-000007:note_history:31]
| • | Under Topic 606, variable consideration must be estimated at the outset of the arrangement, subject to the constraint guidance to ensure that a significant revenue reversal will not occur. As a result, upon adoption of Topic 606, estimated breakage for accruals of certain Customer Programs is recognized sooner as compared to Topic 605. |

- removed (2019-07-25):
[0001032975-19-000007:note_history:32]
Balance Sheet Reclassifications

- removed (2019-07-25):
[0001032975-19-000007:note_history:33]
| • | Under Topic 605, the gross amount of accrued revenue reserves for sales returns of $31.4 million, net of expected returned inventory of $11.4 million was included within accounts receivable, net as of March 31, 2018. Expected scrap cost of $5.2 million for such expected returned inventory was included in accrued and other current liabilities as of March 31, 2018. Subsequent to the adoption of Topic 606, such balances are presented on a gross basis as accrued revenue reserve from returns of $31.4 million included in accrued and other current liabilities and as return assets of $6.2 million included in other current assets. |

- removed (2019-07-25):
[0001032975-19-000007:note_history:34]
| • | Under Topic 605, revenue reserves for certain Customer Programs totaling $76.7 million, which were estimated using portfolio approach based on aggregated customer level, were included within accounts receivable, net as of March 31, 2018. Subsequent to the adoption of Topic 606, such balances are presented as accrued customer marketing, pricing and incentive programs included in accrued and other current liabilities. |

- removed (2019-07-25):
[0001032975-19-000007:note_history:35]
Certain balances of allowances for sales return and accruals for Customer Programs which were accrued based on offers made to individual customers, met the right of offset criteria in accordance with ASC 210-20, "Balance Sheet (Topic 210)", and are still included within accounts receivable, net.

- removed (2019-07-25):
[0001032975-19-000007:note_history:36]
The adoption of Topic 606 did not have an impact over the total cash flows from operating, investing, or financing activities.

- removed (2019-07-25):
[0001032975-19-000007:note_history:37]
The following tables summarize the impacts of adopting Topic 606 on the Company’s condensed consolidated statements of operations for the three and nine months ended December 31, 2018 and condensed consolidated balance sheet as of December 31, 2018 (in thousands):

- removed (2019-07-25):
[0001032975-19-000007:note_history:38]
|  | Three Months Ended December 31, 2018 |  | Nine Months Ended December 31, 2018 |
|  | As Reported Under Topic 606 | If Reported Under Topic 605 | Effect of Change |  | As Reported Under Topic 606 | If Reported Under Topic 605 | Effect of Change |
| Net sales | $ | 864,388 |  | $ | 853,563 |  | $ | 10,825 |  |  | $ | 2,164,014 |  | $ | 2,158,267 |  | $ | 5,747 |  |

- removed (2019-07-25):
[0001032975-19-000007:note_history:39]
|  |  | As of December 31, 2018 |
|  |  | As Reported Under Topic 606 |  | Balance Under Topic 605 |  | Effect of Change |
| Accounts receivable, net |  | 484,204 |  |  | 345,055 |  |  | 139,149 |  |
| Other current assets |  | 73,174 |  |  | 65,758 |  |  | 7,416 |  |
| Accrued and other current liabilities |  | 478,632 |  |  | 326,932 |  |  | 151,700 |  |
| Retained earnings |  | 1,322,915 |  |  | 1,328,050 |  |  | (5,135 | ) |

- removed (2019-07-25):
[0001032975-19-000007:note_history:40]
In January 2016, the FASB issued ASU 2016-01, "Financial Instruments-Recognition and Measurement of Financial Assets and Financial Liabilities (Subtopic 825-10)" ("ASU 2016-01"). ASU 2016-01 requires entities to measure equity instruments at fair value and recognize any changes in fair value within the statement of operations. The Company adopted ASU 2016-01 effective April 1, 2018 on a prospective basis for its privately held strategic equity securities without readily determinable fair values. The Company elected the measurement alternative to record these investments at cost and to adjust for impairments and observable price changes with a same or similar security from the same issuer within the statement of operations. The adoption of ASU 2016-01 did not have a material impact on the Company's condensed consolidated financial statements.

- removed (2019-07-25):
[0001032975-19-000007:note_history:41]
In October 2016, the FASB issued ASU 2016-16, "Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory" ("ASU 2016-16"), which eliminates the deferral of income tax effects of intra-entity asset transfers until the transferred asset is sold to an unrelated party or recovered through use. However, this standard does not apply to intra-entity transfer of inventory. The Company adopted this standard effective April 1, 2018 on a modified retrospective basis, and the adoption of ASU 2016-16 did not have a material impact on its condensed consolidated financial statements.

- removed (2019-07-25):
[0001032975-19-000007:note_history:42]
In December 2016, the FASB issued ASU 2016-18, "Statement of Cash Flows (Topic 230): Restricted Cash" ("ASU 2016-18"), which requires that a statement of cash flows explains the change during the period in the total of cash, cash equivalents, and amounts generally described as restricted cash or restricted cash equivalents. The Company adopted this standard effective April 1, 2018, utilizing the retrospective transition method to each period presented and the adoption of ASU 2016-18 did not have an impact on its condensed consolidated financial statements as the Company did not have any restricted cash for either period presented.

- removed (2019-07-25):
[0001032975-19-000007:note_history:43]
In January 2017, the FASB issued ASU 2017-01, "Business Combination (Topic 805): Clarifying the Definition of a Business" ("ASU 2017-01"), which changes the definition of a business to assist with evaluating when a set of transferred assets and activities is a business. The Company adopted this standard effective April 1, 2018, and the adoption of ASU 2017-01 did not have a material impact on its condensed consolidated financial statements.

- removed (2019-07-25):
[0001032975-19-000007:note_history:44]
In March 2017, the FASB issued ASU 2017-07, "Compensation-Retirement Benefit (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost" ("ASU 2017-07"), which requires that the Company disaggregate the service cost component from the other components of net benefit cost, and also provides guidance on how to present the service cost component and the other components of net benefit cost in the income statement and allow only the service cost component of net benefit cost to be eligible for capitalization. The Company adopted this standard effective April 1, 2018 using a retrospective adoption method. Other than the revised statement of operations presentation for the periods in fiscal year 2019, the adoption of ASU 2017-07 did not have an impact on the Company’s condensed consolidated financial statements. The impact to the comparative period was immaterial and therefore the prior period statements of operations was not revised.

- removed (2019-07-25):
[0001032975-19-000007:note_history:45]
In August 2017, the FASB issued ASU 2017-12, "Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities" ("ASU 2017-12"), which improves the financial reporting of hedging relationships to better portray the economic results of an entity’s risk management activities in its financial statements and simplifies the application of the hedge accounting guidance. The Company adopted this standard prospectively on April 1, 2018, and the adoption of ASU 2017-12 did not have a material impact on its condensed consolidated financial statements. In accordance with ASU 2017-12, the Company has started presenting the earnings impact from forward points in the cost of goods sold line item, which is used to present the earnings impact of the hedged item.

- removed (2019-07-25):
[0001032975-19-000007:note_history:46]
In February 2016, the FASB issued ASU 2016-02, "Leases (Topic 842)" ("ASU 2016-02" or "Topic 842"), which generally requires companies to recognize right-of-use assets and lease liabilities arising from operating and financing leases with terms longer than 12 months in the consolidated balance sheets. The Company will adopt the new guidance in the first quarter of fiscal year 2020 on a modified retrospective basis, thereby recognizing the cumulative effect of initially applying Topic 842 as an adjustment to opening retained earnings on the adoption date, without revising the balances in comparative periods. The Company plans on electing the package of transitional practical expedients upon adoption which, among other provisions, allows the Company to carry forward historical lease classification, for any expired or existing leases on the adoption date. Although the Company expects to record significant amounts of right-of-use assets and liabilities on its consolidated balance sheets, the Company is still evaluating the full impact that ASU 2016-02 will have on its consolidated financial statements.

- removed (2019-07-25):
[0001032975-19-000007:note_history:47]
Summary of Significant Accounting Policies

- removed (2019-07-25):
[0001032975-19-000007:note_history:48]
Revenue Recognition

- removed (2019-07-25):
[0001032975-19-000007:note_history:49]
Revenue is recognized when a customer obtains control of promised goods or service in an amount that reflects the transaction price the Company expects to receive in exchange for those goods or services.

- removed (2019-07-25):
[0001032975-19-000007:note_history:50]
Substantially all revenue recognized by the Company relates to the contracts with customers to sell products that allow people to connect through music, gaming, video, computing, and other digital platforms. These products are hardware devices, which may include embedded software that function together, and are considered as one performance obligation. Hardware devices are generally plug and play, requiring no configuration and little or no installation. Revenue is recognized at a point in time when control of the products is transferred to the customer which generally occurs upon shipment. The Company’s contracts with its customers generally have a one year term. The Company applies the practical expedient of not disclosing the value of unsatisfied performance obligations for contracts with an original expected length of one year or less.

- removed (2019-07-25):
[0001032975-19-000007:note_history:51]
The Company also provides post-contract customer support (“PCS”) for certain products and related software, which includes unspecified software updates and upgrades, bug fixes and maintenance. The transaction price is allocated to two performance obligations in such contracts, based on a relative standalone selling price. The transaction price allocated to PCS is recognized as revenue on a straight-line basis, which reflects the pattern of delivery of PCS, over the estimated term of the support that is between one to two years. Deferred revenue associated with remaining PCS performance obligation as of December 31, 2018 and March 31, 2018 was not material .

- removed (2019-07-25):
[0001032975-19-000007:note_history:52]
The Company normally requires payment from customers within thirty to sixty days from the invoice date. However, terms may vary by customer type, by country and by selling season. Extended payment terms are sometimes offered to a limited number of customers during the second and third fiscal quarters. The Company does not modify payment terms on existing receivables. The Company's contracts with customers do not include significant financing components as the period between the satisfaction of performance obligations and timing of payment are generally within one year.

- removed (2019-07-25):
[0001032975-19-000007:note_history:53]
The transaction price received by the Company from sales to its distributors, retail companies ("retailers"), and authorized resellers is calculated as selling price net of variable consideration which may include product returns, price protection, and the Company’s payments for Customer Programs related to current period product revenue. The estimated impact of these programs is recorded as a reduction of sales or as an operating expense if the Company receives a distinct good or service from the customer and can reasonably estimate the fair value of that good or service received. Certain Customer Programs require management to estimate the percentage of those programs which will not be claimed or will not be earned by customers based on historical experience and on the specific terms and conditions of particular programs. The percentage of these customer programs that will not be claimed or earned is commonly referred to as "breakage". The Company accounts for breakage as part of variable consideration, subject to constraint, and records the estimated impact in the same period when revenue is recognized at the expected value. Significant management judgments and estimates are used to determine the impact of the program and breakage in any accounting period.

- removed (2019-07-25):
[0001032975-19-000007:note_history:54]
The Company enters into cooperative marketing arrangements with many of its customers and with certain indirect partners, allowing customers to receive a credit equal to a set percentage of their purchases of the Company's products, or a fixed dollar amount for various marketing and incentive programs. The objective of these arrangements is to encourage advertising and promotional events to increase sales of the Company's products.

- removed (2019-07-25):
[0001032975-19-000007:note_history:55]
Customer incentive programs include consumer rebates and performance-based incentives. Consumer rebates are offered to the Company's customers and indirect partners at the Company's discretion for the primary benefit of end-users. In addition, the Company offers performance-based incentives to many of its customers and indirect partners based on predetermined performance criteria. At management's discretion, the Company also offers special pricing discounts to certain customers. Special pricing discounts are usually offered only for limited time periods or for sales of selected products to specific indirect partners.

- removed (2019-07-25):
[0001032975-19-000007:note_history:56]
Cooperative marketing arrangements and customer incentive programs are considered variable consideration, which the Company estimates and records as a reduction to revenue at the time of sale based on negotiated terms, historical experiences, forecasted incentives, anticipated volume of future purchases, and inventory levels in the channel.

- removed (2019-07-25):
[0001032975-19-000007:note_history:57]
The Company has agreements with certain customers that contain terms allowing price protection credits to be issued in the event of a subsequent price reduction. Management's decision to make price reductions is influenced by product life cycle stage, market acceptance of products, the competitive environment, new product introductions and other factors. Accruals for estimated expected future pricing actions are recognized at the time of sale based on analyses of historical pricing actions by customer and by product, inventories owned by and located at customers, current customer demand, current operating conditions, and other relevant customer and product information, such as stage of product life-cycle.

- removed (2019-07-25):
[0001032975-19-000007:note_history:58]
Product return rights vary by customer. Estimates of expected future product returns qualify as variable consideration and are recorded as a reduction of the transaction price of the contract at the time of sale based on an analyses of historical return trends by customer and by product, inventories owned by and located at customers, current customer demand, current operating conditions, and other relevant customer and product information. The Company assesses the estimated returned asset value for impairment, and adjusts the value of the asset for any impairment. Return trends are influenced by product life cycle status, new product introductions, market acceptance of products, sales levels, product sell-through, the type of customer, seasonality, product quality issues, competitive pressures, operational policies and procedures, and other factors. Return rates can fluctuate over time but are sufficiently predictable to allow the Company to estimate expected future product returns.

- removed (2019-07-25):
[0001032975-19-000007:note_history:59]
Typically, variable consideration does not need to be constrained as estimates are based on predictive historical data or future commitments that are planned and controlled by the Company. However, the Company continues to assess variable consideration estimates such that it is probable that a significant reversal of revenue will not occur.

- removed (2019-07-25):
[0001032975-19-000007:note_history:60]
The Company regularly evaluates the adequacy of its estimates for Customer Programs and product returns. Future market conditions and product transitions may require the Company to take action to change such programs and related estimates. When the variables used to estimate these costs change, or if actual costs differ significantly from the estimates, the Company would be required to increase or reduce revenue or operating expenses to reflect the impact.

- removed (2019-07-25):
[0001032975-19-000007:note_history:61]
Sales taxes and value-added taxes (“VAT”) collected from customers, if applicable, which are remitted to governmental authorities are not included in revenue, and are reflected as a liability on the condensed consolidated balance sheets.

- removed (2019-07-25):
[0001032975-19-000007:note_history:62]
Shipping and Handling Costs

- removed (2019-07-25):
[0001032975-19-000007:note_history:63]
The Company's shipping and handling costs are included in cost of goods sold in the condensed consolidated statements of operations for all periods presented.

- removed (2019-07-25):
[0001032975-19-000007:note_history:64]
Contract Balances

- removed (2019-07-25):
[0001032975-19-000007:note_history:65]
The Company records accounts receivable from contracts with customers when it has an unconditional right to consideration, as accounts receivable, net on the condensed consolidated balance sheet.

- removed (2019-07-25):
[0001032975-19-000007:note_history:66]
The Company records contract liabilities when cash payments are received or due in advance of performance, primarily for implied support and subscriptions. Contract liabilities are included in accrued and other current liabilities on the condensed consolidated balance sheets.

- removed (2019-07-25):
[0001032975-19-000007:note_history:67]
As of December 31, 2018 and for the period then ended, and as of April 1, 2018, the Company did not have any material contract liabilities balances or changes.

- removed (2019-07-25):
[0001032975-19-000007:note_history:68]
Contract Costs

- removed (2019-07-25):
[0001032975-19-000007:note_history:69]
The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that otherwise would have been recognized is one year or less. These costs are included in marketing and selling expenses in the condensed consolidated statements of operations. As of December 31, 2018 and March 31, 2018, the Company did not have any material deferred contract costs.

- removed (2019-07-25):
[0001032975-19-000007:note_history:70]
Allowances for Doubtful Accounts

- removed (2019-07-25):
[0001032975-19-000007:note_history:71]
Allowances for doubtful accounts are maintained for estimated losses resulting from the Company's customers' inability to make payments. The allowances are based on the Company's regular assessment of the financial condition of specific customers, as well as its historical experience with bad debts and customer deductions, receivables aging, current economic trends, geographic or country-specific risks and the financial condition of its distribution channels.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-07-25):
[0001032975-19-000059:note_history:72]
The Company had several uncommitted, unsecured bank lines of credit aggregating $79.3 million as of June 30, 2019. There are no financial covenants under these lines of credit with which the Company must comply. As of June 30, 2019, the Company had outstanding bank guarantees of $15.7 million under these lines of credit. There was no borrowing outstanding under these lines of credit as of June 30, 2019 or March 31, 2019.
  (was, 2019-01-24, similarity 0.9127):
[0001032975-19-000007:note_history:72]
The Company had several uncommitted, unsecured bank lines of credit aggregating $79.4 million as of December 31, 2018. There are no financial covenants under these lines of credit with which the Company must comply. As of December 31, 2018, the Company had outstanding bank guarantees of $30.1 million under these lines of credit. There was no borrowing outstanding under these lines of credit as of December 31, 2018 or March 31, 2018.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: no_current_note, score: 0.0

- removed (2019-07-25):
[0001032975-19-000007:note_history:73]
Revenue Recognition

- removed (2019-07-25):
[0001032975-19-000007:note_history:74]
Revenue is recognized when a customer obtains control of promised goods or service in an amount that reflects the transaction price the Company expects to receive in exchange for those goods or services.

- removed (2019-07-25):
[0001032975-19-000007:note_history:75]
Substantially all revenue recognized by the Company relates to the contracts with customers to sell products that allow people to connect through music, gaming, video, computing, and other digital platforms. These products are hardware devices, which may include embedded software that function together, and are considered as one performance obligation. Hardware devices are generally plug and play, requiring no configuration and little or no installation. Revenue is recognized at a point in time when control of the products is transferred to the customer which generally occurs upon shipment. The Company’s contracts with its customers generally have a one year term. The Company applies the practical expedient of not disclosing the value of unsatisfied performance obligations for contracts with an original expected length of one year or less.

- removed (2019-07-25):
[0001032975-19-000007:note_history:76]
The Company also provides post-contract customer support (“PCS”) for certain products and related software, which includes unspecified software updates and upgrades, bug fixes and maintenance. The transaction price is allocated to two performance obligations in such contracts, based on a relative standalone selling price. The transaction price allocated to PCS is recognized as revenue on a straight-line basis, which reflects the pattern of delivery of PCS, over the estimated term of the support that is between one to two years. Deferred revenue associated with remaining PCS performance obligation as of December 31, 2018 and March 31, 2018 was not material .

- removed (2019-07-25):
[0001032975-19-000007:note_history:77]
The Company normally requires payment from customers within thirty to sixty days from the invoice date. However, terms may vary by customer type, by country and by selling season. Extended payment terms are sometimes offered to a limited number of customers during the second and third fiscal quarters. The Company does not modify payment terms on existing receivables. The Company's contracts with customers do not include significant financing components as the period between the satisfaction of performance obligations and timing of payment are generally within one year.

- removed (2019-07-25):
[0001032975-19-000007:note_history:78]
The transaction price received by the Company from sales to its distributors, retail companies ("retailers"), and authorized resellers is calculated as selling price net of variable consideration which may include product returns, price protection, and the Company’s payments for Customer Programs related to current period product revenue. The estimated impact of these programs is recorded as a reduction of sales or as an operating expense if the Company receives a distinct good or service from the customer and can reasonably estimate the fair value of that good or service received. Certain Customer Programs require management to estimate the percentage of those programs which will not be claimed or will not be earned by customers based on historical experience and on the specific terms and conditions of particular programs. The percentage of these customer programs that will not be claimed or earned is commonly referred to as "breakage". The Company accounts for breakage as part of variable consideration, subject to constraint, and records the estimated impact in the same period when revenue is recognized at the expected value. Significant management judgments and estimates are used to determine the impact of the program and breakage in any accounting period.

- removed (2019-07-25):
[0001032975-19-000007:note_history:79]
The Company enters into cooperative marketing arrangements with many of its customers and with certain indirect partners, allowing customers to receive a credit equal to a set percentage of their purchases of the Company's products, or a fixed dollar amount for various marketing and incentive programs. The objective of these arrangements is to encourage advertising and promotional events to increase sales of the Company's products.

- removed (2019-07-25):
[0001032975-19-000007:note_history:80]
Customer incentive programs include consumer rebates and performance-based incentives. Consumer rebates are offered to the Company's customers and indirect partners at the Company's discretion for the primary benefit of end-users. In addition, the Company offers performance-based incentives to many of its customers and indirect partners based on predetermined performance criteria. At management's discretion, the Company also offers special pricing discounts to certain customers. Special pricing discounts are usually offered only for limited time periods or for sales of selected products to specific indirect partners.

- removed (2019-07-25):
[0001032975-19-000007:note_history:81]
Cooperative marketing arrangements and customer incentive programs are considered variable consideration, which the Company estimates and records as a reduction to revenue at the time of sale based on negotiated terms, historical experiences, forecasted incentives, anticipated volume of future purchases, and inventory levels in the channel.

- removed (2019-07-25):
[0001032975-19-000007:note_history:82]
The Company has agreements with certain customers that contain terms allowing price protection credits to be issued in the event of a subsequent price reduction. Management's decision to make price reductions is influenced by product life cycle stage, market acceptance of products, the competitive environment, new product introductions and other factors. Accruals for estimated expected future pricing actions are recognized at the time of sale based on analyses of historical pricing actions by customer and by product, inventories owned by and located at customers, current customer demand, current operating conditions, and other relevant customer and product information, such as stage of product life-cycle.

- removed (2019-07-25):
[0001032975-19-000007:note_history:83]
Product return rights vary by customer. Estimates of expected future product returns qualify as variable consideration and are recorded as a reduction of the transaction price of the contract at the time of sale based on an analyses of historical return trends by customer and by product, inventories owned by and located at customers, current customer demand, current operating conditions, and other relevant customer and product information. The Company assesses the estimated returned asset value for impairment, and adjusts the value of the asset for any impairment. Return trends are influenced by product life cycle status, new product introductions, market acceptance of products, sales levels, product sell-through, the type of customer, seasonality, product quality issues, competitive pressures, operational policies and procedures, and other factors. Return rates can fluctuate over time but are sufficiently predictable to allow the Company to estimate expected future product returns.

- removed (2019-07-25):
[0001032975-19-000007:note_history:84]
Typically, variable consideration does not need to be constrained as estimates are based on predictive historical data or future commitments that are planned and controlled by the Company. However, the Company continues to assess variable consideration estimates such that it is probable that a significant reversal of revenue will not occur.

- removed (2019-07-25):
[0001032975-19-000007:note_history:85]
The Company regularly evaluates the adequacy of its estimates for Customer Programs and product returns. Future market conditions and product transitions may require the Company to take action to change such programs and related estimates. When the variables used to estimate these costs change, or if actual costs differ significantly from the estimates, the Company would be required to increase or reduce revenue or operating expenses to reflect the impact.

- removed (2019-07-25):
[0001032975-19-000007:note_history:86]
Sales taxes and value-added taxes (“VAT”) collected from customers, if applicable, which are remitted to governmental authorities are not included in revenue, and are reflected as a liability on the condensed consolidated balance sheets.

- removed (2019-07-25):
[0001032975-19-000007:note_history:87]
Shipping and Handling Costs

- removed (2019-07-25):
[0001032975-19-000007:note_history:88]
The Company's shipping and handling costs are included in cost of goods sold in the condensed consolidated statements of operations for all periods presented.

- removed (2019-07-25):
[0001032975-19-000007:note_history:89]
Contract Balances

- removed (2019-07-25):
[0001032975-19-000007:note_history:90]
The Company records accounts receivable from contracts with customers when it has an unconditional right to consideration, as accounts receivable, net on the condensed consolidated balance sheet.

- removed (2019-07-25):
[0001032975-19-000007:note_history:91]
The Company records contract liabilities when cash payments are received or due in advance of performance, primarily for implied support and subscriptions. Contract liabilities are included in accrued and other current liabilities on the condensed consolidated balance sheets.

- removed (2019-07-25):
[0001032975-19-000007:note_history:92]
As of December 31, 2018 and for the period then ended, and as of April 1, 2018, the Company did not have any material contract liabilities balances or changes.

- removed (2019-07-25):
[0001032975-19-000007:note_history:93]
Contract Costs

- removed (2019-07-25):
[0001032975-19-000007:note_history:94]
The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that otherwise would have been recognized is one year or less. These costs are included in marketing and selling expenses in the condensed consolidated statements of operations.
