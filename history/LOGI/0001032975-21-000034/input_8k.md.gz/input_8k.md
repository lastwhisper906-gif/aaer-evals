# LOGI 8-K — 0001032975-21-000029 filed 2021-07-27

## item codes, every 8-K on or before 2021-07-29

- 2021-07-27 0001032975-21-000029 — 2.02, 9.01
- 2021-04-29 0001032975-21-000012 — 2.02, 9.01
- 2021-01-19 0001032975-21-000004 — 2.02, 9.01
- 2020-10-20 0001032975-20-000045 — 2.02, 9.01
- 2020-09-11 0001032975-20-000042 — 5.07, 8.01
- 2020-07-21 0001032975-20-000029 — 2.02, 9.01
- 2020-07-01 0001032975-20-000023 — 5.02, 8.01
- 2020-05-12 0001032975-20-000011 — 2.02, 9.01
- 2020-03-30 0001032975-20-000009 — 5.02
- 2020-01-21 0001032975-20-000002 — 2.02, 9.01
- 2019-10-22 0001032975-19-000071 — 9.01
- 2019-09-26 0001032975-19-000068 — 1.01, 7.01, 9.01
- 2019-09-06 0001032975-19-000063 — 5.07, 8.01
- 2019-07-23 0001032975-19-000046 — 2.02, 9.01
- 2019-07-23 0001032975-19-000045 — 5.02, 9.01
- 2019-07-02 0001032975-19-000036 — 5.02
- 2019-06-25 0001032975-19-000034 — 5.02
- 2019-05-03 0001032975-19-000021 — 5.02 — amendment, the index does not say of what
- 2019-04-30 0001032975-19-000017 — 2.02, 5.02, 9.01
- 2019-03-28 0001032975-19-000013 — 5.02
- 2019-01-22 0001032975-19-000004 — 2.02, 9.01
- 2018-10-23 0001032975-18-000044 — 2.02, 9.01
- 2018-09-07 0001032975-18-000040 — 5.07, 8.01
- 2018-07-31 0001032975-18-000035 — 1.01, 2.02, 2.05, 7.01, 9.01
- 2018-06-27 0001032975-18-000020 — 5.02
- 2018-05-03 0001032975-18-000013 — 2.02, 5.02, 9.01
- 2018-01-23 0001032975-18-000005 — 2.02, 9.01
- 2017-10-24 0001032975-17-000043 — 2.02, 9.01
- 2017-09-18 0001032975-17-000040 — 5.07, 8.01
- 2017-07-25 0001032975-17-000028 — 2.02, 9.01
- 2017-07-12 0001032975-17-000022 — 1.01
- 2017-04-26 0001032975-17-000012 — 2.02, 9.01
- 2017-01-25 0001032975-17-000002 — 2.02, 9.01
- 2016-10-26 0001032975-16-000103 — 2.02, 9.01
- 2016-09-13 0001032975-16-000101 — 5.07, 8.01
- 2016-07-28 0001032975-16-000092 — 2.02, 9.01
- 2016-06-30 0001032975-16-000087 — 5.02
- 2016-04-28 0001032975-16-000077 — 2.02, 9.01
- 2016-04-14 0001032975-16-000073 — 1.01, 7.01, 9.01
- 2016-01-21 0001032975-16-000064 — 2.02, 9.01
- 2016-01-04 0001032975-16-000061 — 1.01, 2.01, 9.01
- 2015-12-23 0001032975-15-000059 — 5.02
- 2015-10-22 0001032975-15-000047 — 2.02, 9.01
- 2015-09-11 0001032975-15-000044 — 5.07, 8.01
- 2015-07-24 0001032975-15-000034 — 2.05 — amendment of 0001032975-15-000030
- 2015-07-23 0001032975-15-000030 — 2.02, 9.01
- 2015-06-25 0001032975-15-000025 — 5.02
- 2015-05-14 0001032975-15-000011 — 8.01, 9.01
- 2015-04-23 0001032975-15-000008 — 2.02, 2.05
- 2015-01-22 0001628280-15-000191 — 2.02, 8.01
- 2014-12-23 0001193125-14-450908 — 5.02, 5.07, 8.01
- 2014-11-25 0001193125-14-425233 — 3.01
- 2014-11-13 0001193125-14-411303 — 4.01, 9.01
- 2014-10-23 0001104659-14-073164 — 2.02, 9.01
- 2014-09-04 0001193125-14-331214 — 4.02, 9.01
- 2014-08-18 0001193125-14-313346 — 3.01, 9.01
- 2014-07-24 0001104659-14-053065 — 2.02, 9.01
- 2014-06-05 0001193125-14-226177 — 3.01, 9.01
- 2014-05-22 0001193125-14-208777 — 8.01, 9.01
- 2014-04-24 0001104659-14-029650 — 2.02, 9.01
- 2014-01-23 0001104659-14-003619 — 2.02, 9.01
- 2013-10-24 0001104659-13-077404 — 2.02, 9.01
- 2013-09-09 0001193125-13-361441 — 5.02, 5.07, 8.01, 9.01
- 2013-09-06 0001193125-13-359930 — 5.02, 9.01
- 2013-08-02 0001193125-13-317343 — 5.02
- 2013-07-25 0001104659-13-056372 — 2.02, 9.01
- 2013-06-28 0001193125-13-277394 — 5.02, 9.01
- 2013-06-20 0001193125-13-265914 — 8.01, 9.01
- 2013-04-25 0001104659-13-032570 — 2.02, 9.01
- 2013-04-17 0001193125-13-158923 — 5.02, 9.01
- 2013-03-01 0001193125-13-085804 — 2.05
- 2013-01-24 0001104659-13-004214 — 2.02, 9.01
- 2013-01-02 0001193125-13-000058 — 5.02
- 2012-10-25 0001104659-12-070966 — 2.02, 9.01
- 2012-09-11 0001193125-12-388070 — 5.02, 5.07, 8.01, 9.01
- 2012-08-22 0001193125-12-364167 — 5.02, 8.01, 9.01
- 2012-07-26 0001104659-12-051084 — 2.02, 9.01
- 2012-06-08 0001193125-12-264132 — 2.05, 9.01 — amendment, the index does not say of what
- 2012-04-26 0001193125-12-183657 — 5.02, 9.01
- 2012-04-26 0001104659-12-028470 — 2.02, 2.05, 9.01
- 2012-03-15 0001193125-12-115954 — 5.02, 9.01
- 2012-01-26 0001104659-12-004014 — 2.02, 9.01
- 2012-01-04 0001193125-12-002212 — 1.01, 2.03, 9.01
- 2011-10-27 0001104659-11-058150 — 2.02, 9.01
- 2011-09-12 0001193125-11-245931 — 5.07
- 2011-07-28 0001193125-11-200929 — 5.02, 9.01
- 2011-07-28 0001193125-11-199704 — 2.02, 9.01
- 2011-04-28 0001193125-11-112669 — 2.02, 9.01
- 2011-03-24 0001193125-11-076483 — 5.02, 9.01
- 2011-01-27 0001032975-11-000003 — 9.01
- 2010-10-28 0001032975-10-000032 — 9.01
- 2010-09-13 0001032975-10-000022 — 5.07
- 2010-07-29 0001032975-10-000010 — 2.02, 9.01
- 2010-06-10 0001193125-10-136877 — 5.02, 9.01
- 2010-05-03 0001193125-10-104337 — 5.02
- 2010-04-29 0001032975-10-000008 — 2.02, 9.01
- 2010-02-19 0001032975-10-000006 — 9.01 — amendment of 0001193125-09-252416
- 2010-01-21 0001032975-10-000002 — 2.02, 9.01
- 2009-12-14 0001193125-09-252416 — 2.01, 9.01
- 2009-11-17 0001032975-09-000023 — 1.01
- 2009-10-22 0001032975-09-000018 — 9.01
- 2009-09-22 0001193125-09-195545 — 5.02, 9.01
- 2009-09-03 0001032975-09-000013 — 8.01
- 2009-07-23 0001140361-09-016802 — 2.02, 9.01
- 2009-06-01 0001193125-09-122550 — 5.02
- 2009-04-23 0001193125-09-085054 — 2.02, 9.01
- 2009-04-02 0001193125-09-071272 — 5.02, 9.01
- 2009-01-20 0001193125-09-008454 — 2.05 — amendment of 0001193125-09-002609
- 2009-01-20 0001193125-09-007902 — 2.02, 9.01
- 2009-01-07 0001193125-09-002609 — 2.05, 9.01
- 2009-01-07 0001193125-09-002370 — 5.02, 9.01
- 2008-12-09 0001193125-08-250543 — 5.02, 9.01
- 2008-10-21 0001193125-08-213212 — 2.02, 9.01
- 2008-07-22 0001193125-08-154721 — 2.02, 9.01
- 2008-06-24 0001193125-08-139163 — 5.03, 9.01
- 2008-05-13 0001193125-08-113263 — 5.02, 9.01
- 2008-04-22 0001193125-08-086176 — 2.02, 9.01

## late-filing notifications on or before 2021-07-29

- 2015-06-02 0001032975-15-000020 — NT 10-K, for the period ended 2015-03-31
- 2014-11-06 0001193125-14-401306 — NT 10-Q, for the period ended 2014-09-30
- 2014-07-24 0001193125-14-277575 — NT 10-Q, for the period ended 2014-06-30
- 2014-05-22 0001193125-14-208712 — NT 10-K, for the period ended 2014-03-31
- 2009-08-06 0001032975-09-000006 — NT 10-Q, for the period ended 2009-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001032975-21-000029:8k_2_02:1]
EX-99.1
2
exhibit991q1fy22.htm
EX-99.1

[0001032975-21-000029:8k_2_02:2]
Document

[0001032975-21-000029:8k_2_02:3]
Exhibit 99.1

[0001032975-21-000029:8k_2_02:4]
Editorial Contacts:

[0001032975-21-000029:8k_2_02:5]
Ben Lu, CFA, Vice President, Investor Relations - lir@logitech.com

[0001032975-21-000029:8k_2_02:6]
Nicole Kenyon, Head of Global Corporate & Employee Communications - USA (510) 988-8553

[0001032975-21-000029:8k_2_02:7]
Ben Starkie, Corporate Communications - Europe +41 (0) 79-292-3499

[0001032975-21-000029:8k_2_02:8]
Logitech Delivers Strong Start to Fiscal Year 2022

[0001032975-21-000029:8k_2_02:9]
Company's Q1 Sales Grow 66% and Profits Double

[0001032975-21-000029:8k_2_02:10]
LAUSANNE, Switzerland, July 27, 2021 and NEWARK, Calif., July 26, 2021 — SIX Swiss Exchange Ad hoc announcement pursuant to Art. 53 LR —

[0001032975-21-000029:8k_2_02:11]
Logitech International (SIX: LOGN) (Nasdaq: LOGI) today announced financial results for the first quarter of Fiscal Year 2022.

[0001032975-21-000029:8k_2_02:12]
•Q1 sales were $1.31 billion, up 66 percent in US dollars and 58 percent in constant currency, compared to Q1 of the prior year.

[0001032975-21-000029:8k_2_02:13]
•Q1 GAAP operating income grew 143 percent to $203 million, compared to $83 million in the same quarter a year ago. Q1 GAAP earnings per share (EPS) grew 160 percent to $1.09, compared to $0.42 in the same quarter a year ago.

[0001032975-21-000029:8k_2_02:14]
•Q1 non-GAAP operating income grew 100 percent to $235 million, compared to $117 million in the same quarter a year ago. Q1 non-GAAP EPS grew 91 percent to $1.22, compared to $0.64 in the same quarter a year ago.

[0001032975-21-000029:8k_2_02:15]
“We’ve started strong in Fiscal Year 2022, with Q1 sales up 58% in constant currency and profits doubling versus last year,” said Bracken Darrell, Logitech president and chief executive officer. “Our key categories grew high double digits. This performance demonstrates the strength of our capabilities, excellent operational execution, and ability to capitalize on long-term trends, like gaming, streaming and creating, hybrid work and video everywhere.”

[0001032975-21-000029:8k_2_02:16]
Outlook

[0001032975-21-000029:8k_2_02:17]
Logitech confirmed its Fiscal Year 2022 outlook of flat sales growth in constant currency, plus or minus five percent, and $800 million to $850 million in non-GAAP operating income.

[0001032975-21-000029:8k_2_02:18]
Prepared Remarks Available Online

[0001032975-21-000029:8k_2_02:19]
Logitech has made its prepared written remarks for the financial results videoconference available online on the Logitech corporate website at http://ir.logitech.com.

[0001032975-21-000029:8k_2_02:20]
Financial Results Videoconference and Webcast

[0001032975-21-000029:8k_2_02:21]
Logitech will hold a financial results videoconference to discuss the results for Q1 Fiscal Year 2022 on Tuesday, July 27, 2021 at 8:30 a.m. Eastern Daylight Time and 2:30 p.m. Central European Summer Time. A livestream of the event will be available on the Logitech corporate website at http://ir.logitech.com.

[0001032975-21-000029:8k_2_02:22]
Use of Non-GAAP Financial Information and Constant Currency

[0001032975-21-000029:8k_2_02:23]
To facilitate comparisons to Logitech’s historical results, Logitech has included non-GAAP adjusted measures, which exclude share-based compensation expense, amortization of intangible assets, acquisition-related costs, change in fair value of contingent consideration for business acquisition, restructuring charges (credits), loss (gain) on investments, non-GAAP income tax adjustment, and other items detailed under “Supplemental Financial Information” after the tables below. Logitech also presents percentage sales growth in constant currency, a non-GAAP measure, to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales. Logitech believes this information, used together with the GAAP financial information, will help investors to evaluate its current period performance and trends in its business. With respect to the Company’s outlook for non-GAAP operating income, most of these excluded amounts pertain to events that have not yet occurred and are not currently possible to estimate with a reasonable degree of accuracy. Therefore, no reconciliation to the GAAP amounts has been provided for the Fiscal Year 2022 outlook.

[0001032975-21-000029:8k_2_02:24]
About Logitech

[0001032975-21-000029:8k_2_02:25]
Logitech helps all people pursue their passions by designing experiences so everyone can create, achieve, and enjoy more. Logitech designs and creates products that bring people together through computing, gaming, video, streaming and creating, and music. Brands of Logitech include Logitech, Logitech G, ASTRO Gaming, Streamlabs, Blue Microphones, Ultimate Ears, and Jaybird. Founded in 1981, and headquartered in Lausanne, Switzerland, Logitech International is a Swiss public company listed on the SIX Swiss Exchange (LOGN) and on the Nasdaq Global Select Market (LOGI). Find Logitech at www.logitech.com, the company blog or @Logitech.

[0001032975-21-000029:8k_2_02:26]
# # #

[0001032975-21-000029:8k_2_02:27]
Note that unless noted otherwise, comparisons are year over year.

[0001032975-21-000029:8k_2_02:28]
Logitech and other Logitech marks are trademarks or registered trademarks of Logitech Europe S.A. and/or its affiliates in the U.S. and other countries.  All other trademarks are the property of their respective owners. For more information about Logitech and its products, visit the company’s website at www.logitech.com.

[0001032975-21-000029:8k_2_02:29]
(LOGIIR)

[0001032975-21-000029:8k_2_02:30]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |
| PRELIMINARY RESULTS* |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |
|  |  | Three Months Ended |
|  |  | June 30, |
| GAAP CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  | 2021 |  | 2020 |
| Net sales |  | $ | 1,312,058 |  |  | $ | 791,894 |  |
| Cost of goods sold |  | 739,066 |  |  | 482,638 |  |
| Amortization of intangible assets |  | 4,066 |  |  | 3,523 |  |
| Gross profit |  | 568,926 |  |  | 305,733 |  |
| Operating expenses: |  |  |  |  |
| Marketing and selling |  | 252,314 |  |  | 133,238 |  |
| Research and development |  | 69,246 |  |  | 49,725 |  |
| General and administrative |  | 40,542 |  |  | 29,071 |  |
| Amortization of intangible assets and acquisition-related costs |  | 5,217 |  |  | 4,609 |  |
| Change in fair value of contingent consideration for business acquisition |  | (1,474) |  |  | 5,716 |  |
| Restructuring credits, net |  | — |  |  | (53) |  |
| Total operating expenses |  | 365,845 |  |  | 222,306 |  |
| Operating income |  | 203,081 |  |  | 83,427 |  |
| Interest income |  | 316 |  |  | 620 |  |
| Other income, net |  | 8,435 |  |  | 2,029 |  |
| Income before income taxes |  | 211,832 |  |  | 86,076 |  |
| Provision for income taxes |  | 24,991 |  |  | 14,003 |  |
| Net income |  | $ | 186,841 |  |  | $ | 72,073 |  |
| Net income per share: |  |  |  |  |
| Basic |  | $ | 1.11 |  |  | $ | 0.43 |  |
| Diluted |  | $ | 1.09 |  |  | $ | 0.42 |  |
| Weighted average shares used to compute net income per share: |  |  |  |  |
| Basic |  | 168,372 |  |  | 167,612 |  |
| Diluted |  | 172,020 |  |  | 170,127 |  |

[0001032975-21-000029:8k_2_02:31]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
|  |  | June 30, |  | March 31, |  |  |  |  |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  | 2021 |  | 2021 |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,497,721 |  |  | $ | 1,750,327 |  |  |  |  |  |
| Accounts receivable, net |  | 545,907 |  |  | 612,225 |  |  |  |  |  |
| Inventories |  | 778,596 |  |  | 661,116 |  |  |  |  |  |
| Other current assets |  | 158,130 |  |  | 135,650 |  |  |  |  |  |
| Total current assets |  | 2,980,354 |  |  | 3,159,318 |  |  |  |  |  |
| Non-current assets: |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  | 114,693 |  |  | 114,060 |  |  |  |  |  |
| Goodwill |  | 449,732 |  |  | 429,604 |  |  |  |  |  |
| Other intangible assets, net |  | 112,229 |  |  | 115,148 |  |  |  |  |  |
| Other assets |  | 338,485 |  |  | 324,248 |  |  |  |  |  |
| Total assets |  | $ | 3,995,493 |  |  | $ | 4,142,378 |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 709,741 |  |  | $ | 823,233 |  |  |  |  |  |
| Accrued and other current liabilities |  | 702,589 |  |  | 858,617 |  |  |  |  |  |
| Total current liabilities |  | 1,412,330 |  |  | 1,681,850 |  |  |  |  |  |
| Non-current liabilities: |  |  |  |  |  |  |  |  |
| Income taxes payable |  | 62,968 |  |  | 59,237 |  |  |  |  |  |
| Other non-current liabilities |  | 147,704 |  |  | 139,502 |  |  |  |  |  |
| Total liabilities |  | 1,623,002 |  |  | 1,880,589 |  |  |  |  |  |
| Shareholders’ equity: |  |  |  |  |  |  |  |  |
| Registered shares, CHF 0.25 par value: |  | 30,148 |  |  | 30,148 |  |  |  |  |  |
| Issued shares — 173,106 at June 30 and March 31, 2021 |  |  |  |  |  |  |  |  |
| Additional shares that may be issued out of conditional capitals — 50,000 at June 30 and March 31, 2021 |  |  |  |  |  |  |  |  |
| Additional shares that may be issued out of authorized capital — 17,311 at June 30 and March 31, 2021 |  |  |  |  |  |  |  |  |
| Additional paid-in capital |  | 74,948 |  |  | 129,519 |  |  |  |  |  |
| Shares in treasury, at cost — 4,407 at June 30, 2021 and 4,799 at March 31, 2021 |  | (302,606) |  |  | (279,541) |  |  |  |  |  |
| Retained earnings |  | 2,677,419 |  |  | 2,490,578 |  |  |  |  |  |
| Accumulated other comprehensive loss |  | (107,418) |  |  | (108,915) |  |  |  |  |  |
| Total shareholders’ equity |  | 2,372,491 |  |  | 2,261,789 |  |  |  |  |  |
| Total liabilities and shareholders’ equity |  | $ | 3,995,493 |  |  | $ | 4,142,378 |  |  |  |  |  |

[0001032975-21-000029:8k_2_02:32]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |
|  |  | Three Months Ended |
|  |  | June 30, |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |  | 2021 |  | 2020 |
| Cash flows from operating activities: |  |  |  |  |
| Net income |  | $ | 186,841 |  |  | $ | 72,073 |  |
| Adjustments to reconcile net income to net cash provided by/ (used in) operating activities: |  |  |  |  |
| Depreciation |  | 20,462 |  |  | 11,747 |  |
| Amortization of intangible assets |  | 8,843 |  |  | 8,132 |  |
| Gain on investments |  | (1,071) |  |  | (174) |  |
| Share-based compensation expense |  | 23,651 |  |  | 20,115 |  |
| Deferred income taxes |  | (4,158) |  |  | 3,589 |  |
| Change in fair value of contingent consideration for business acquisition |  | (1,474) |  |  | 5,716 |  |
| Other |  | 1,045 |  |  | 9 |  |
| Changes in assets and liabilities, net of acquisitions: |  |  |  |  |
| Accounts receivable, net |  | 73,308 |  |  | (102,092) |  |
| Inventories |  | (115,166) |  |  | (40,385) |  |
| Other assets |  | (30,796) |  |  | (15,770) |  |
| Accounts payable |  | (115,620) |  |  | 168,346 |  |
| Accrued and other liabilities |  | (160,835) |  |  | (12,459) |  |
| Net cash provided by / (used in) operating activities |  | (114,970) |  |  | 118,847 |  |
| Cash flows from investing activities: |  |  |  |  |
| Purchases of property, plant and equipment |  | (24,514) |  |  | (12,308) |  |
| Investment in privately held companies |  | (501) |  |  | (30) |  |
| Acquisition, net of cash acquired |  | (15,586) |  |  | — |  |
| Purchases of trading investments |  | (1,091) |  |  | (2,424) |  |
| Proceeds from sales of trading investments |  | 1,345 |  |  | 2,362 |  |
| Net cash used in investing activities |  | (40,347) |  |  | (12,400) |  |
| Cash flows from financing activities: |  |  |  |  |
| Purchases of registered shares |  | (54,872) |  |  | — |  |
| Proceeds from exercises of stock options and purchase rights |  | 2,750 |  |  | 9,992 |  |
| Tax withholdings related to net share settlements of restricted stock units |  | (50,411) |  |  | (23,121) |  |
| Net cash used in financing activities |  | (102,533) |  |  | (13,129) |  |
| Effect of exchange rate changes on cash and cash equivalents |  | 5,244 |  |  | 511 |  |
| Net increase / (decrease) in cash and cash equivalents |  | (252,606) |  |  | 93,829 |  |
| Cash and cash equivalents, beginning of the period |  | 1,750,327 |  |  | 715,566 |  |
| Cash and cash equivalents, end of the period |  | $ | 1,497,721 |  |  | $ | 809,395 |  |

[0001032975-21-000029:8k_2_02:33]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three Months Ended |
|  |  | June 30, |
| NET SALES |  | 2021 |  | 2020 |  | Change |
| Net sales by product category: |  |  |  |  |  |  |
| Pointing Devices |  | $ | 182,878 |  |  | $ | 120,469 |  |  | 52 | % |
| Keyboards & Combos |  | 218,357 |  |  | 145,360 |  |  | 50 |  |
| PC Webcams |  | 109,918 |  |  | 60,851 |  |  | 81 |  |
| Tablet & Other Accessories |  | 79,272 |  |  | 46,048 |  |  | 72 |  |
| Gaming (1) |  | 335,397 |  |  | 181,903 |  |  | 84 |  |
| Video Collaboration |  | 234,885 |  |  | 130,074 |  |  | 81 |  |
| Mobile Speakers |  | 28,484 |  |  | 29,009 |  |  | (2) |  |
| Audio & Wearables |  | 116,607 |  |  | 71,365 |  |  | 63 |  |
| Smart Home |  | 6,172 |  |  | 6,810 |  |  | (9) |  |
| Other (2) |  | 88 |  |  | 5 |  |  | 1,660 |  |
| Total Sales |  | $ | 1,312,058 |  |  | $ | 791,894 |  |  | 66 | % |

[0001032975-21-000029:8k_2_02:34]
(1) Gaming includes streaming services revenue generated by Streamlabs.

[0001032975-21-000029:8k_2_02:35]
(2) Other includes products that the Company currently intends to phase out, or has already phased out, because they are no longer strategic to the Company's business.

[0001032975-21-000029:8k_2_02:36]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three Months Ended |
|  |  | June 30, |
| GAAP TO NON GAAP RECONCILIATION (A) |  | 2021 |  | 2020 |
| Gross profit - GAAP |  | $ | 568,926 |  |  | $ | 305,733 |  |
| Share-based compensation expense |  | 1,369 |  |  | 1,400 |  |
| Amortization of intangible assets |  | 4,066 |  |  | 3,523 |  |
| Gross profit - Non-GAAP |  | $ | 574,361 |  |  | $ | 310,656 |  |
| Gross margin - GAAP |  | 43.4 | % |  | 38.6 | % |
| Gross margin - Non-GAAP |  | 43.8 | % |  | 39.2 | % |
| Operating expenses - GAAP |  | $ | 365,845 |  |  | $ | 222,306 |  |
| Less: Share-based compensation expense |  | 22,282 |  |  | 18,715 |  |
| Less: Amortization of intangible assets and acquisition-related costs |  | 5,217 |  |  | 4,609 |  |
| Less: Change in fair value of contingent consideration for business acquisition |  | (1,474) |  |  | 5,716 |  |
| Less: Restructuring credits, net |  | — |  |  | (53) |  |
| Operating expenses - Non-GAAP |  | $ | 339,820 |  |  | $ | 193,319 |  |
| % of net sales - GAAP |  | 27.9 | % |  | 28.1 | % |
| % of net sales - Non - GAAP |  | 25.9 | % |  | 24.4 | % |
| Operating income - GAAP |  | $ | 203,081 |  |  | $ | 83,427 |  |
| Share-based compensation expense |  | 23,651 |  |  | 20,115 |  |
| Amortization of intangible assets and acquisition-related costs |  | 9,283 |  |  | 8,132 |  |
| Change in fair value of contingent consideration for business acquisition |  | (1,474) |  |  | 5,716 |  |
| Restructuring credits, net |  | — |  |  | (53) |  |
| Operating income - Non - GAAP |  | $ | 234,541 |  |  | $ | 117,337 |  |
| % of net sales - GAAP |  | 15.5 | % |  | 10.5 | % |
| % of net sales - Non - GAAP |  | 17.9 | % |  | 14.8 | % |
| Net income - GAAP |  | $ | 186,841 |  |  | $ | 72,073 |  |
| Share-based compensation expense |  | 23,651 |  |  | 20,115 |  |
| Amortization of intangible assets and acquisition-related costs |  | 9,283 |  |  | 8,132 |  |
| Change in fair value of contingent consideration for business acquisition |  | (1,474) |  |  | 5,716 |  |
| Restructuring credits, net |  | — |  |  | (53) |  |
| Gain on investments |  | (1,071) |  |  | (174) |  |
| Non-GAAP income tax adjustment |  | (7,416) |  |  | 3,048 |  |
| Net income - Non - GAAP |  | $ | 209,814 |  |  | $ | 108,857 |  |
| Net income per share: |  |  |  |  |
| Diluted - GAAP |  | $ | 1.09 |  |  | $ | 0.42 |  |
| Diluted - Non - GAAP |  | $ | 1.22 |  |  | $ | 0.64 |  |
| Shares used to compute net income per share: |  |  |  |  |
| Diluted - GAAP and Non - GAAP |  | 172,020 |  |  | 170,127 |  |

[0001032975-21-000029:8k_2_02:37]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three Months Ended |
|  |  | June 30, |
| SHARE-BASED COMPENSATION EXPENSE |  | 2021 |  | 2020 |
| Share-based Compensation Expense |  |  |  |  |
| Cost of goods sold |  | $ | 1,369 |  |  | $ | 1,400 |  |
| Marketing and selling |  | 8,530 |  |  | 8,792 |  |
| Research and development |  | 5,061 |  |  | 3,103 |  |
| General and administrative |  | 8,691 |  |  | 6,820 |  |
| Total share-based compensation expense |  | 23,651 |  |  | 20,115 |  |
| Income tax benefit |  | (16,594) |  |  | (8,111) |  |
| Total share-based compensation expense, net of income tax benefit |  | $ | 7,057 |  |  | $ | 12,004 |  |

[0001032975-21-000029:8k_2_02:38]
*Note: These preliminary results for the three months ended June 30, 2021 are subject to adjustments, including subsequent events that may occur through the date of filing our Quarterly Report on Form 10-Q.

[0001032975-21-000029:8k_2_02:39]
(A) Non-GAAP Financial Measures

[0001032975-21-000029:8k_2_02:40]
To supplement our condensed consolidated financial results prepared in accordance with GAAP, we use a number of financial measures, both GAAP and non-GAAP, in analyzing and assessing our overall business performance, for making operating decisions and for forecasting and planning future periods. We consider the use of non-GAAP financial measures helpful in assessing our current financial performance, ongoing operations and prospects for the future as well as understanding financial and business trends relating to our financial condition and results of operations.

[0001032975-21-000029:8k_2_02:41]
While we use non-GAAP financial measures as a tool to enhance our understanding of certain aspects of our financial performance and to provide incremental insight into the underlying factors and trends affecting both our performance and our cash-generating potential, we do not consider these measures to be a substitute for, or superior to, the information provided by GAAP financial measures. Consistent with this approach, we believe that disclosing non-GAAP financial measures to the readers of our financial statements provides useful supplemental data that, while not a substitute for GAAP financial measures, can offer insight in the review of our financial and operational performance and enables investors to more fully understand trends in our current and future performance. In assessing our business during the quarter ended June 30, 2021 and previous periods, we excluded items in the following general categories, each of which are described below:

[0001032975-21-000029:8k_2_02:42]
Share-based compensation expense. We believe that providing non-GAAP measures excluding share-based compensation expense, in addition to the GAAP measures, allows for a more transparent comparison of our financial results from period to period. We prepare and maintain our budgets and forecasts for future periods on a basis consistent with this non-GAAP financial measure. Further, companies use a variety of types of equity awards as well as a variety of methodologies, assumptions and estimates to determine share-based compensation expense. We believe that excluding share-based compensation expense enhances our ability and the ability of investors to understand the impact of non-cash share-based compensation on our operating results and to compare our results against the results of other companies.

[0001032975-21-000029:8k_2_02:43]
Amortization of intangible assets. We incur intangible asset amortization expense, primarily in connection with our acquisitions of various businesses and technologies. The amortization of purchased intangibles varies depending on the level of acquisition activity. We exclude these various charges in budgeting, planning and forecasting future periods and we believe that providing the non-GAAP measures excluding these various non-cash charges, as well as the GAAP measures, provides additional insight when comparing our gross profit, operating expenses, and financial results from period to period.

[0001032975-21-000029:8k_2_02:44]
Acquisition-related costs and change in fair value of contingent consideration for business acquisition.  We incurred expenses and credits in connection with our acquisitions which we generally would not have otherwise incurred in the periods presented as a part of our continuing operations. Acquisition related costs include all incremental expenses incurred to effect a business combination. Fair value of contingent consideration is associated with our estimates of the value of earn-outs in connection with certain acquisitions. We believe that providing the non-GAAP measures excluding these costs and credits, as well as the GAAP measures, assists our investors because such costs are not reflective of our ongoing operating results.

[0001032975-21-000029:8k_2_02:45]
Restructuring charges (credits). These expenses are associated with re-aligning our business strategies based on current economic conditions. We have undertaken several restructuring plans in recent years. In connection with our restructuring initiatives, we incurred restructuring charges related to employee terminations, facility closures and early cancellation of certain contracts. We believe that providing the non-GAAP measures excluding these items, as well as the GAAP measures, assists our investors because such charges (credits) are not reflective of our ongoing operating results in the current period.

[0001032975-21-000029:8k_2_02:46]
Loss (gain) on investments. We recognize losses (gains) related to our investments in various companies, which vary depending on the operational and financial performance of the companies in which we invest.  These amounts include our losses (earnings) on equity method investments, investment impairments and losses (gains) resulting from sales or other events related to our investments. We believe that providing the non-GAAP measures excluding these items, as well as the GAAP measures, assists our investors because such losses (gains) are not reflective of our ongoing operations.

[0001032975-21-000029:8k_2_02:47]
Non-GAAP income tax adjustment.  Non-GAAP income tax adjustment primarily measures the income tax effect of non-GAAP adjustments excluded above and other events; the determination of which is based upon the nature of the underlying items, the mix of income and losses in jurisdictions and the relevant tax rates in which we operate.

[0001032975-21-000029:8k_2_02:48]
Each of the non-GAAP financial measures described above, and used in this press release, should not be considered in isolation from, or as a substitute for, a measure of financial performance prepared in accordance with GAAP. Further, investors are cautioned that there are inherent limitations associated with the use of each of these non-GAAP financial measures as an analytical tool. In particular, these non-GAAP financial measures are not based on a comprehensive set of accounting rules or principles and many of the adjustments to the GAAP financial measures reflect the exclusion of items that are recurring and may be reflected in the Company’s financial results for the foreseeable future. We compensate for these limitations by providing specific information in the reconciliation included in this press release regarding the GAAP amounts excluded from the non-GAAP financial measures. In addition, as noted above, we evaluate the non-GAAP financial measures together with the most directly comparable GAAP financial information.

[0001032975-21-000029:8k_2_02:49]
Additional Supplemental Financial Information - Constant Currency

[0001032975-21-000029:8k_2_02:50]
In addition, Logitech presents percentage sales growth in constant currency to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales.
