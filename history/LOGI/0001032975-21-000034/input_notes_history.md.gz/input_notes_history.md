# LOGI note change history — 0001032975-21-000009 → 0001032975-21-000034


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-07-29):
[0001032975-21-000034:note_history:1]
Changes in the Company’s warranty liability for the three months ended June 30, 2021 and 2020 were as follows (in thousands):
  (was, 2021-01-21, similarity 0.9231):
[0001032975-21-000009:note_history:1]
Changes in the Company’s warranty liability for the three and nine months ended December 31, 2020 and 2019 were as follows (in thousands):

- changed (2021-07-29):
[0001032975-21-000034:note_history:2]
|  | Three Months EndedJune 30, |  |  |  |
|  | 2021 |  | 2020 |  |  |  |  |  |  |  |
| Beginning of the period | $ | 48,832 |  |  | $ | 40,039 |  |  |  |  |  |  |  |  |
| Provision | 8,446 |  |  | 5,389 |  |  |  |  |  |  |  |  |
| Settlements | (8,315) |  |  | (6,161) |  |  |  |  |  |  |  |  |
| Currency translation | 130 |  |  | 183 |  |  |  |  |  |  |  |  |
| End of the period | $ | 49,093 |  |  | $ | 39,450 |  |  |  |  |  |  |  |  |
  (was, 2021-01-21, similarity 0.7116):
[0001032975-21-000009:note_history:2]
|  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |  |  |  |
| Beginning of the period | $ | 41,782 |  |  | $ | 37,222 |  |  | $ | 40,039 |  |  | $ | 34,229 |  |  |  |  |
| Provision | 13,692 |  |  | 9,608 |  |  | 28,575 |  |  | 26,652 |  |  |  |  |
| Settlements | (8,371) |  |  | (6,840) |  |  | (22,073) |  |  | (20,544) |  |  |  |  |
| Currency translation | 489 |  |  | 187 |  |  | 1,051 |  |  | (160) |  |  |  |  |
| End of the period | $ | 47,592 |  |  | $ | 40,177 |  |  | $ | 47,592 |  |  | $ | 40,177 |  |  |  |  |

- added (2021-07-29):
[0001032975-21-000034:note_history:3]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of June 30, 2021, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

- added (2021-07-29):
[0001032975-21-000034:note_history:4]
From time to time the Company is involved in claims and legal proceedings which arise in the ordinary course of its business. The Company is currently subject to several such claims and a small number of legal proceedings. The Company believes that these matters lack merit and intends to vigorously defend against them. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial position, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company's defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company's business, financial position, cash flows or results of operations in a particular period. Any claims or proceedings against the Company, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain a necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company's business.

- removed (2021-07-29):
[0001032975-21-000009:note_history:5]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these

- removed (2021-07-29):
[0001032975-21-000009:note_history:6]
indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of December 31, 2020, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

- removed (2021-07-29):
[0001032975-21-000009:note_history:7]
From time to time the Company is involved in claims and legal proceedings that arise in the ordinary course of its business. The Company is currently subject to several such claims and a small number of legal proceedings. The Company believes that these matters lack merit and intends to vigorously defend against them. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company’s defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company’s business, financial condition, cash flows or results of operations in a particular period. Any claims or proceedings against the Company, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain a necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company’s business.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-07-29):
[0001032975-21-000034:note_history:8]
Logitech International S.A, together with its consolidated subsidiaries ("Logitech" or the "Company"), designs, manufactures and markets products that have an everyday place in people's lives, connecting them to the digital experiences they care about. Forty years ago, Logitech created products to improve experiences around the personal PC platform, and today it is a multi-brand, multi-category company designing products that enable better experiences consuming, sharing and creating any digital content such as computing, gaming, video, and music, whether it is on a computer, mobile device or in the cloud.
  (was, 2021-01-21, similarity 0.946):
[0001032975-21-000009:note_history:8]
Logitech International S.A, together with its consolidated subsidiaries, (Logitech or the Company) designs, manufactures and markets products that have an everyday place in people's lives, connecting them to the digital experiences they care about. Almost 40 years ago, Logitech created products to improve experiences around the personal PC platform, and today it is a multi-brand, multi-category company designing products that enable better experiences consuming, sharing and creating any digital content such as computing, gaming, video and music, whether it is on a computer, mobile device or in the cloud.

- changed (2021-07-29):
[0001032975-21-000034:note_history:9]
The Company sells its products to a broad network of domestic and international customers, including direct sales to retailers and e-tailers, and indirect sales through distributors.
  (was, 2021-01-21, similarity 0.9972):
[0001032975-21-000009:note_history:9]
The Company sells its products to a broad network of domestic and international customers, including direct sales to retailers and e-tailers and indirect sales through distributors.

- changed (2021-07-29):
[0001032975-21-000034:note_history:10]
Logitech was founded in Switzerland in 1981 and Logitech International S.A. has been the parent holding company of Logitech since 1988. Logitech International S.A. is a Swiss holding company with its registered office in Apples, Switzerland and headquarters in Lausanne, Switzerland, which conducts its business through subsidiaries in the Americas, Europe, Middle East and Africa ("EMEA") and Asia Pacific. Shares of Logitech International S.A. are listed on both the SIX Swiss Exchange under the trading symbol LOGN and the Nasdaq Global Select Market under the trading symbol LOGI.
  (was, 2021-01-21, similarity 0.9913):
[0001032975-21-000009:note_history:10]
Logitech was founded in Switzerland in 1981 and Logitech International S.A. has been the parent holding company of Logitech since 1988. Logitech International S.A. is a Swiss holding company with its registered office in Apples, Switzerland and headquarters in Lausanne, Switzerland, which conducts its business through subsidiaries in the Americas, Europe, Middle East and Africa (EMEA) and Asia Pacific. Shares of Logitech International S.A. are listed on both the SIX Swiss Exchange under the trading symbol LOGN and the Nasdaq Global Select Market under the trading symbol LOGI.

- changed (2021-07-29):
[0001032975-21-000034:note_history:11]
The condensed consolidated financial statements include the accounts of Logitech and its subsidiaries. All intercompany balances and transactions have been eliminated. The condensed consolidated financial statements are presented in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") for interim financial information and therefore do not include all the information required by U.S. GAAP for complete financial statements. The condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended March 31, 2021, included in its Annual Report on Form 10-K filed with the Securities and Exchange Commission ("SEC") on May 12, 2021.
  (was, 2021-01-21, similarity 0.9867):
[0001032975-21-000009:note_history:11]
The condensed consolidated financial statements include the accounts of Logitech and its subsidiaries. All intercompany balances and transactions have been eliminated. The condensed consolidated financial statements are presented in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and therefore do not include all the information required by GAAP for complete financial statements. The condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended March 31, 2020, included in its Annual Report on Form 10-K filed with the Securities and Exchange Commission (SEC) on May 27, 2020.

- changed (2021-07-29):
[0001032975-21-000034:note_history:12]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three months ended June 30, 2021 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2022, or any future periods.
  (was, 2021-01-21, similarity 0.9573):
[0001032975-21-000009:note_history:12]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and nine months ended December 31, 2020 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2021, or any future periods.

- changed (2021-07-29):
[0001032975-21-000034:note_history:13]
Other than the recent accounting pronouncements adopted and discussed below under Recent Accounting Pronouncements Adopted, there have been no material changes in the Company’s significant accounting policies during the three months ended June 30, 2021 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2021.
  (was, 2021-01-21, similarity 0.9351):
[0001032975-21-000009:note_history:13]
Other than the recent accounting pronouncements adopted and discussed below under Recent Accounting Pronouncements Adopted, there have been no material changes in the Company’s significant accounting policies during the nine months ended December 31, 2020 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2020.

- changed (2021-07-29):
[0001032975-21-000034:note_history:14]
The preparation of financial statements in conformity with U.S. GAAP requires management to make judgments, estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Significant estimates and assumptions made by management involve the fair value of goodwill and intangible assets acquired from business acquisitions, contingent consideration for a business acquisition and periodic reassessment of its fair value, valuation of investment in privately held companies classified under Level 3 fair value hierarchy, pension obligations, accruals for customer incentives, cooperative marketing, and pricing programs and related breakage when appropriate, inventory valuation, share-based compensation expense, uncertain tax positions, and valuation allowances for deferred tax assets. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ materially from those estimates.
  (was, 2021-01-21, similarity 0.8903):
[0001032975-21-000009:note_history:14]
The preparation of financial statements in conformity with U.S. GAAP requires management to make judgments, estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Significant estimates and assumptions made by management involve fair value of  goodwill and intangible assets acquired from business acquisitions, valuation of right-of-use assets, valuation of investment in privately held companies classified under Level 3 of the fair value hierarchy, pensions obligations, warranty liabilities, accruals for customer incentives, cooperative marketing, and pricing programs (Customer Programs) and related breakage when appropriate, accrued sales return liability, inventory valuation, share-based compensation expense, uncertain tax positions, and valuation allowances for deferred tax assets. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ materially from these estimates.

- added (2021-07-29):
[0001032975-21-000034:note_history:15]
We are subject to risks and uncertainties as a result of the novel coronavirus ("COVID-19"). Capital markets and economies worldwide have been negatively impacted by COVID-19 and it is still unclear how lasting and deep the economic impacts will be. During the first quarter of fiscal year 2022, the COVID-19 pandemic had mixed effects on the Company’s results of operations. While we experienced increased sales and operating income compared to the first quarter of fiscal year 2021, we also experienced supply and demand volatility, as the COVID-19 pandemic and related safety measures and restrictions have evolved differently across the world. The ongoing and full extent of the impact of the COVID-19 pandemic on the Company's business and operational and financial performance and condition, including the sustainability of its effect on trends positive to the Company, is uncertain and will depend on many factors outside the Company's control, including but not limited to the timing, extent, duration and effects of the virus and any of its mutations, the vaccination rates, the development of effective treatments, the imposition of effective public safety and other protective measures and the public's response to such measures, the impact of COVID-19 on the global economy and demand for the Company's products and services. Should the COVID-19 pandemic or global economic slowdown not improve or worsen, or if the Company's attempt to mitigate its impact on its operations and costs is not successful, the Company's business, results of operations, financial condition and prospects may be adversely affected.

- changed (2021-07-29):
[0001032975-21-000034:note_history:16]
In December 2019, the FASB issued ASU 2019-12, "Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes" (ASU 2019-12), which eliminates certain exceptions for recognizing deferred taxes for investments, performing intraperiod allocation and calculating income taxes in interim periods. This ASU also includes guidance to reduce complexity in certain areas, including recognizing deferred taxes for tax goodwill and allocating taxes to members of a consolidated group. ASU 2019-12 is effective for annual and interim periods in fiscal years beginning after December 15, 2020. Early adoption is permitted. The Company adopted this standard effective April 1, 2021. The adoption of ASU 2019-12 did not have a material impact on the Company's condensed consolidated financial statements.
  (was, 2021-01-21, similarity 0.8467):
[0001032975-21-000009:note_history:16]
In December 2019, the FASB issued ASU 2019-12, "Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes" (ASU 2019-12), which eliminates certain exceptions for recognizing deferred taxes for investments, performing intraperiod allocation and calculating income taxes in interim periods. This ASU also includes guidance to reduce complexity in certain areas, including recognizing deferred taxes for tax goodwill and allocating taxes to members of a consolidated group. ASU 2019-12 is effective for annual and interim periods in fiscal years beginning after December 15, 2020. Early adoption is permitted. The Company is currently assessing the impact of ASU 2019-12 on its consolidated financial statements and plans to adopt the standard effective April 1, 2021.

- removed (2021-07-29):
[0001032975-21-000009:note_history:17]
We are subject to risks and uncertainties as a result of the novel coronavirus (COVID-19). Capital markets and economies worldwide have been negatively impacted by COVID-19 and it is still unclear how lasting and deep the economic impacts will be. During the three and nine months ended December 31, 2020, the COVID-19 pandemic had mixed effects on the Company’s results of operations, and it may continue to have mixed or adverse effects. While there was high demand for and consumption of certain of our products that led to increased sales and operating income during the three and nine months ended December 31, 2020, at the same time the Company experienced disruptions and higher costs in our manufacturing, supply chain and logistics operations and outsourced services. The ongoing and full extent of the impact of the COVID-19 pandemic on the Company's business and operational and financial performance and condition, including the sustainability of its effect on trends positive to the Company, is uncertain and will depend on many factors outside the Company's control, including but not limited to the timing, extent, duration and effects of the virus and any of its mutations, the availability of vaccines and their global deployment, the development of effective treatments, the imposition of effective public safety and other protective measures and the public's response to such measures, the impact of COVID-19 on the global economy and demand for the Company's products and services. Should the COVID-19 pandemic or global economic slowdown not improve or worsen, or if the Company's attempt to mitigate its impact on its operations and costs is not successful, the Company's business, results of operations, financial condition and prospects may be adversely affected.

- removed (2021-07-29):
[0001032975-21-000009:note_history:18]
In June 2016, the FASB issued ASU 2016-13, "Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments" (ASU 2016-13), which was further updated and clarified by the FASB through issuance of additional related ASUs, replaces the incurred-loss impairment methodology and requires immediate recognition of estimated credit losses expected to occur for most financial assets, including trade receivables. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. The Company adopted this standard effective April 1, 2020, using a modified retrospective approach. Upon adoption, the Company updated its credit loss models to utilize a forward-looking current expected credit losses (CECL) model in place of the incurred loss methodology for financial instruments measured at amortized cost, including accounts receivable. The cumulative effect adjustment from adoption was not material to the Company's condensed consolidated financial statements.

- removed (2021-07-29):
[0001032975-21-000009:note_history:19]
In August 2018, the FASB issued ASU 2018-13, "Fair Value Measurement (Topic 820): Disclosure Framework - Changes to the Disclosure Requirements for Fair Value Measurements" (ASU 2018-13), which eliminates, adds and modifies certain disclosure requirements for fair value measurements, including eliminating the requirement to disclose the amount of and reasons for transfers between Level 1 and Level 2 of the fair value hierarchy, and requiring the range and weighted average used to develop significant unobservable inputs for Level 3 fair value measurements.  Some of these disclosure changes must be applied prospectively while others retrospectively depending on requirement. The Company adopted this standard effective April 1, 2020. The adoption of ASU 2018-13 did not have a material impact on the Company's condensed consolidated financial statements.

- removed (2021-07-29):
[0001032975-21-000009:note_history:20]
In August 2018, the FASB issued ASU 2018-14, "Compensation - Retirement Benefits - Defined Benefits Plans - General (Subtopic 715-20): Disclosure Framework - Changes to the Disclosure Requirements for Defined Benefit Plans" (ASU 2018-14), which requires that the Company remove various disclosures that no longer are considered cost-beneficial, namely amounts in accumulated other comprehensive income expected to be recognized as components of net periodic benefit cost over the next fiscal year.  Further, ASU 2018-14 requires disclosure or clarification of the reasons for significant gains or losses related to changes in the benefit obligation for the period.  The Company adopted this standard effective April 1, 2020 using a retrospective approach and the updated disclosures will be included in the Company's Form 10-K for the fiscal year ending March 31, 2021. The adoption of ASU 2018-14 did not have an impact on the Company's condensed consolidated financial statements.

- removed (2021-07-29):
[0001032975-21-000009:note_history:21]
Recent Accounting Pronouncements To Be Adopted


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-07-29):
[0001032975-21-000034:note_history:22]
The Company had several uncommitted, unsecured bank lines of credit aggregating $191.6 million as of June 30, 2021. There are no financial covenants under these lines of credit with which the Company must comply. 
As of June 30, 2021, the Company had outstanding bank guarantees of $24.7 million under these lines of credit. There was no borrowing outstanding under these lines of credit as of June 30, 2021 or March 31, 2021.
  (was, 2021-01-21, similarity 0.9127):
[0001032975-21-000009:note_history:22]
The Company had several uncommitted, unsecured bank lines of credit aggregating $82.6 million as of December 31, 2020. There are no financial covenants under these lines of credit with which the Company must comply. As of December 31, 2020, the Company had outstanding bank guarantees of $37.8 million under these lines of credit. There was no borrowing outstanding under these lines of credit as of December 31, 2020 or March 31, 2020.
