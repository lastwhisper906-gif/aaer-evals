# LOGI MD&A — 0001032975-21-000034


## mdna

[0001032975-21-000034:mdna:1]
[same as prior period, unchanged from 0001032975-21-000009:mdna:1]

[0001032975-21-000034:mdna:2]
[same as prior period, unchanged from 0001032975-21-000009:mdna:2]

[0001032975-21-000034:mdna:3]
[same as prior period, unchanged from 0001032975-21-000009:mdna:3]

[0001032975-21-000034:mdna:4]
Logitech is a world leader in designing, manufacturing and marketing products that help connect people to digital and cloud experiences. Forty years ago, Logitech created products to improve experiences around the personal computer ("PC") platform, and today it is a multi-brand, multi-category company designing products that enable people to pursue their passions and connect to the world. Logitech’s products align with several large secular trends including work and learn from anywhere, video everywhere, the increasing popularity of gaming as a spectator and participant sport, and the democratization of content creation. Logitech's brands include Logitech,

[0001032975-21-000034:mdna:5]
Logitech G, ASTRO Gaming, Streamlabs, Blue Microphones, Ultimate Ears, and Jaybird. Our Company's website is www.logitech.com.

[0001032975-21-000034:mdna:6]
Our products participate in five large market opportunities: Creativity & Productivity, Gaming, Video Collaboration, Music and Smart Home. We sell our products to a broad network of domestic and international customers, including direct sales to retailers and e-tailers, and indirect sales through distributors. Our worldwide channel network includes consumer electronics distributors, retailers, mass merchandisers, specialty stores, computer and telecommunications stores, value-added resellers and online merchants. We sell our services directly to end customers in majority.

[0001032975-21-000034:mdna:7]
[same as prior period, unchanged from 0001032975-21-000009:mdna:6]

[0001032975-21-000034:mdna:8]
[same as prior period, unchanged from 0001032975-21-000009:mdna:7]

[0001032975-21-000034:mdna:9]
In March 2020, the World Health Organization declared the outbreak of a novel coronavirus ("COVID-19") as a pandemic, which continues to spread throughout the world. The spread of COVID-19 has caused public health officials to recommend precautions to mitigate the spread of the virus and, in certain markets in which we operate, government authorities have from time to time issued orders that require the closure of or restrictions on non-essential businesses and people to be quarantined or to shelter-at-home. The COVID-19 pandemic has curtailed global economic activity, caused volatility and disruption in global financial and commercial markets, and is likely to continue to cause uncertainty for an indeterminate amount of time. We are conducting our business with substantial modifications, such as employee remote work in non-manufacturing facilities and travel limitations, among other changes. We are continuing to actively monitor the situation and may take further actions that alter our business operations as may be required by federal, state or local authorities in the countries in which we operate, or that we determine are in the best interest of our employees, customers, partners, suppliers or shareholders.

[0001032975-21-000034:mdna:10]
In fiscal year 2021, we experienced disruptions to our supply chain and logistics services, inventory constraints, and increased logistics costs, as we attempted to address the effects of COVID-19.  At the same time, due to the shelter-at-home requirements or other restrictions in many countries, there was an acceleration of work-from-anywhere, study-from-anywhere, gaming, video collaboration and streaming trends and high demand and consumption of certain of our products that have led to increased sales and operating income. While we experienced increased sales and operating income in the first quarter of fiscal year 2022 compared to the first quarter of fiscal year 2021, we also experienced supply and demand volatility, as the COVID-19 pandemic and related safety measures and restrictions have evolved differently across the world. In addition, if the demand volatility results in a decrease in sales in future periods it could lead to higher promotions and marketing expenses, or excess inventories, or both, which will have an adverse impact on our results of operations. It is difficult to predict the progression, the duration and all of the effects of COVID-19, how business restrictions and shelter-at-home guidelines may evolve on a global basis, how consumer demand, inventory and logistical effects and costs may change over time, and the impact on our future sales and results of operations. The full extent of the impact of COVID-19 on our business and our operational and financial performance is currently uncertain and will depend on many factors outside our control. For additional information, see "Liquidity and Capital Resources" below and Item 1A "Risk Factors," including under the caption "The full effect of the COVID-19 pandemic is still uncertain and cannot be predicted, and could adversely affect the Company's business, results of operations and financial condition."

[0001032975-21-000034:mdna:11]
[same as prior period, unchanged from 0001032975-21-000009:mdna:10]

[0001032975-21-000034:mdna:12]
Our total sales for the three months ended June 30, 2021 increased 66%, compared to the three months ended June 30, 2020, due to stronger sales across all regions and several of our product categories from increased remote work and learning trends, accelerated adoption of video communications for a hybrid work environment, and greater gaming viewership, creation, and participation from home, as a result of COVID-19. Our condensed consolidated statements of operations for the three months ended June 30, 2021 include the results of operations for our first quarter acquisition from its date of acquisition.

[0001032975-21-000034:mdna:13]
Sales for the three months ended June 30, 2021 increased 72%, 70%, and 52% in the Americas, EMEA and Asia Pacific, respectively, compared to the same period of the prior fiscal year.

[0001032975-21-000034:mdna:14]
Gross margin for the three months ended June 30, 2021 increased by 480 basis points to 43.4% from 38.6% for the three months ended June 30, 2020. Our gross margin benefited from higher sales volume, a favorable currency impact, lower logistics costs, and favorable product mix.

[0001032975-21-000034:mdna:15]
Operating expenses for the three months ended June 30, 2021 were $365.8 million, or 27.9% of sales, compared to $222.3 million, or 28.1% of sales in the same period of the prior fiscal year.

[0001032975-21-000034:mdna:16]
Net income for the three months ended June 30, 2021 was $186.8 million compared to $72.1 million for the three months ended June 30, 2020.

[0001032975-21-000034:mdna:17]
[same as prior period, unchanged from 0001032975-21-000009:mdna:17]

[0001032975-21-000034:mdna:18]
Our products participate in five large multi-category market opportunities, including Creativity & Productivity, Gaming, Video Collaboration, Music and Smart Home. The following discussion represents key trends specific to our market opportunities.

[0001032975-21-000034:mdna:19]
[same as prior period, unchanged from 0001032975-21-000009:mdna:19]

[0001032975-21-000034:mdna:20]
Creativity & Productivity: New PC shipments have continued to be strong recently due to work-from-home and learn-from-home trends. We believe that innovative PC peripherals, such as our mice and keyboards, can renew the PC usage experience and help improve the productivity and engagement of remote work and learning, thus providing growth opportunities. Hybrid work culture will also greatly expand the number of new workspaces to which we can attach our PC peripherals. Increasing adoption of various cloud-based applications has led to multiple unique consumer use cases, which we are addressing with our innovative product portfolio and a deep understanding of our customer base. The increasing popularity of streaming and broadcasting, as well as the rising work-from-home trend, provides additional growth opportunities for our webcam products as well as other products in our portfolio. Smaller mobile computing devices, such as tablets, have created new markets and usage models for peripherals and accessories. We offer a number of products to enhance the use of mobile devices, including a combo backlit keyboard case with trackpad for the iPad. Hybrid and remote learning environments have also created demand and growth opportunities in the education market for tablet keyboards and accessories.

[0001032975-21-000034:mdna:21]
Gaming: The PC gaming and console gaming platforms continue to show strong structural growth opportunities as online gaming, multi-platform experiences, and esports gain greater popularity and gaming becomes more social, particularly as other recreational activities have been curtailed or restricted during shelter-at-home mandates. We expect gaming will increasingly become one of the largest participant and spectator sports in the world. We believe Logitech is well positioned to benefit from the overall gaming market growth. Our acquisition of Streamlabs provides a solid platform to deliver recurring services and subscriptions to gamers and streamers.

[0001032975-21-000034:mdna:22]
Video Collaboration: The near and long-term structural growth opportunities in the video collaboration market ("VC") have never been more prevalent than in today’s environment, as commercial and consumer adoption of video has seen substantial growth since the start of the COVID-19 pandemic. Video meetings continue to be on the rise, and companies increasingly want lower-cost, cloud-based solutions that can provide their employees with the ability to work from anywhere. We are continuing our efforts to create and sell innovative products to accommodate the increasing demand from home offices and small-size meeting rooms, such as huddle rooms, to medium and large-sized meeting rooms. We are also experiencing significant demand for our enterprise-grade VC webcams and headsets. We will continue to invest in the development of select business-specific products (both hardware and software), targeted product marketing and sales channel development.

[0001032975-21-000034:mdna:23]
Music: Consumers are optimizing their audio experiences on their tablets and smartphones with a variety of music peripherals including wireless mobile speakers and in-ear and other headphones. However, the mobile speaker market has matured and the integration of personal voice assistants has increased competition in the speaker category. In addition, the retail footprint has decreased significantly due to the COVID-19 pandemic. These factors have led to a decline in our Mobile Speakers category sales in the past three years. In the wireless headphone industry, the largest growth in recent years has been in true wireless headphones while traditional wireless headphones have declined significantly. Continued growth in the wireless headphone market is expected for the next several years as consumers increasingly adopt wireless headphones over wired headphones. In addition, Blue Microphones has experienced strong demand as musicians, performers and streamers increasingly look to entertain and engage with their fans on various online platforms like YouTube, Twitch, and Facebook.

[0001032975-21-000034:mdna:24]
Smart Home: Sales of our Harmony universal remote and Circle security family of products declined substantially in fiscal year 2021. In general, our sales of Harmony and Circle products are under pressure as the way people consume content is changing and as retail stores have been closed or subject to restrictions. The smart home market opportunity is broad, and we will continue to explore other innovative experiences to drive growth in the Smart Home category.

[0001032975-21-000034:mdna:25]
Business Seasonality and Product Introductions

[0001032975-21-000034:mdna:26]
We have historically experienced higher sales in our third fiscal quarter ending December 31, compared to other fiscal quarters in our fiscal year, primarily due to the increased consumer demand for our products during the year-end holiday buying season and year-end spending by enterprises. Additionally, new product introductions and business acquisitions can significantly impact sales, product costs and operating expenses. Product introductions can also impact our sales to distribution channels as these channels are filled with new product inventory following a product introduction, and often channel inventory of an earlier model product declines as the next related major product launch approaches. Sales can also be affected when consumers and distributors anticipate a product introduction or changes in business circumstances. However, neither historical seasonal patterns nor historical patterns of product introductions should be considered reliable indicators of our future pattern of product introductions, future sales or financial performance. Furthermore, cash flow is correspondingly lower in the first half of our fiscal year as we typically build inventories in advance for the third quarter and we pay an annual dividend following our Annual General Meeting, which is typically in September.

[0001032975-21-000034:mdna:27]
[same as prior period, unchanged from 0001032975-21-000009:mdna:27]

[0001032975-21-000034:mdna:28]
As described in our Annual Report on Form 10-K for the fiscal year ended March 31, 2021, the canton of Vaud in Switzerland enacted TRAF on March 10, 2020 that took effect as of January 1, 2020. Our cash tax payments have increased in Switzerland beginning in fiscal year 2020 as a result of our transition out of our longstanding tax ruling from the canton of Vaud.

[0001032975-21-000034:mdna:29]
[same as prior period, unchanged from 0001032975-21-000009:mdna:29]

[0001032975-21-000034:mdna:30]
The preparation of financial statements and related disclosures in conformity with U.S. GAAP requires us to make judgments, estimates, and assumptions that affect reported amounts of assets, liabilities, sales and expenses, and the disclosure of contingent assets and liabilities. We base our assumptions, judgments and estimates on historical experience and various other factors that we believe to be reasonable under the circumstances. Actual results could differ materially from these estimates under different assumptions or conditions. On a regular basis, we evaluate our assumptions, judgments and estimates. We also discuss our critical accounting policies and estimates with the Audit Committee of the Board of Directors.

[0001032975-21-000034:mdna:31]
We believe that the assumptions, judgments and estimates involved in the accounting for accruals for customer incentives and related breakage when appropriate, accrued sales return liability, inventory valuation, uncertain tax positions, and business acquisitions have the greatest potential impact on our condensed consolidated financial statements. These areas are key components of our results of operations and are based on complex rules requiring us to make judgments and estimates and consequently, we consider these to be our critical accounting policies. Historically, our assumptions, judgments and estimates relative to our critical accounting policies have not differed materially from actual results.

[0001032975-21-000034:mdna:32]
There have been no material changes in our critical accounting policies and estimates during the three months ended June 30, 2021 compared with the critical accounting policies and estimates disclosed in Management's Discussion and Analysis of Financial Condition and Results of Operations included in our Annual Report on Form 10-K for the fiscal year ended March 31, 2021.

[0001032975-21-000034:mdna:33]
[same as prior period, unchanged from 0001032975-21-000009:mdna:33]

[0001032975-21-000034:mdna:34]
[same as prior period, unchanged from 0001032975-21-000009:mdna:34]

[0001032975-21-000034:mdna:35]
[same as prior period, unchanged from 0001032975-21-000009:mdna:35]

[0001032975-21-000034:mdna:36]
We refer to our net sales growth rates excluding the impact of currency exchange rate fluctuations as "constant currency" sales growth rates. Percentage of constant currency sales growth is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales.

[0001032975-21-000034:mdna:37]
Given our global sales presence and the reporting of our financial results in U.S. Dollars, our financial results could be affected by significant shifts in currency exchange rates. See “Results of Operations” for information on the effect of currency exchange results on our sales. If the U.S. Dollar appreciates or depreciates in comparison to other currencies in future periods, this will affect our results of operations in future periods as well.

[0001032975-21-000034:mdna:38]
[same as prior period, unchanged from 0001032975-21-000009:mdna:38]

[0001032975-21-000034:mdna:39]
The term “sales” means net sales, except as otherwise specified and the sales growth discussion and sales growth rate percentages are in U.S. Dollars, except as otherwise specified.

[0001032975-21-000034:mdna:40]
[same as prior period, unchanged from 0001032975-21-000009:mdna:40]

[0001032975-21-000034:mdna:41]
Although our financial results are reported in U.S. Dollars, a portion of our sales was generated in currencies other than the U.S. Dollar, such as the Euro, Chinese Renminbi, Japanese Yen, Canadian Dollar, Taiwan New Dollar, British Pound and Australian Dollar. During the three months ended June 30, 2021, approximately 48% of our sales were denominated in currencies other than the U.S. Dollar.

[0001032975-21-000034:mdna:42]
[same as prior period, unchanged from 0001032975-21-000009:mdna:42]

[0001032975-21-000034:mdna:43]
[same as prior period, unchanged from 0001032975-21-000009:mdna:43]

[0001032975-21-000034:mdna:44]
Our sales in the three months ended June 30, 2021 increased 66% compared to the same period of the prior fiscal year, driven by sales increase in all regions and several of our product categories due to continuing hybrid work, work-from-home and study-from-home trends, resulting from the COVID-19 pandemic. Strong sales growth in Gaming, Video Collaboration, Keyboards & Combos, Pointing Devices, PC Webcams, Tablet and Other Accessories, and Audio & Wearables, was partially offset by a decline in sales of Mobile Speakers and Smart Home. If currency exchange rates had been constant in the three months ended June 30, 2021 and 2020, our constant dollar sales growth rate would have been 58%.

[0001032975-21-000034:mdna:45]
[same as prior period, unchanged from 0001032975-21-000009:mdna:45]

[0001032975-21-000034:mdna:46]
The following table presents the change in sales by region for the three months ended June 30, 2021, compared with the three months ended June 30, 2020:

[0001032975-21-000034:mdna:47]
|  |  | Sales Growth Rate |  | Constant DollarSales Growth Rate |
| Americas |  | 72 | % |  |  |  | 70 | % |  |  |
| EMEA |  | 70 | % |  |  |  | 56 | % |  |  |
| Asia Pacific |  | 52 | % |  |  |  | 43 | % |  |  |

[0001032975-21-000034:mdna:48]
The increase in sales globally in the three month periods was primarily driven by growth in sales across a majority of our product categories, partially offset by a decline in sales of Mobile Speakers and Smart Home.

[0001032975-21-000034:mdna:49]
[same as prior period, unchanged from 0001032975-21-000009:mdna:54]

[0001032975-21-000034:mdna:50]
Sales by product categories for the three months ended June 30, 2021 and 2020 were as follows (Dollars in thousands):

[0001032975-21-000034:mdna:51]
|  |  | Three Months EndedJune 30, |  |  |
|  |  | 2021 |  | 2020 |  | Change |  |  |  |  |  |  |
| Pointing Devices |  | $ | 182,878 |  |  | $ | 120,469 |  |  | 52 | % |  |  |  |  |  |  |
| Keyboards & Combos |  | 218,357 |  |  | 145,360 |  |  | 50 |  |  |  |  |  |  |  |
| PC Webcams |  | 109,918 |  |  | 60,851 |  |  | 81 |  |  |  |  |  |  |  |
| Tablet & Other Accessories |  | 79,272 |  |  | 46,048 |  |  | 72 |  |  |  |  |  |  |  |
| Gaming (1) |  | 335,397 |  |  | 181,903 |  |  | 84 |  |  |  |  |  |  |  |
| Video Collaboration |  | 234,885 |  |  | 130,074 |  |  | 81 |  |  |  |  |  |  |  |
| Mobile Speakers |  | 28,484 |  |  | 29,009 |  |  | (2) |  |  |  |  |  |  |  |
| Audio & Wearables |  | 116,607 |  |  | 71,365 |  |  | 63 |  |  |  |  |  |  |  |
| Smart Home |  | 6,172 |  |  | 6,810 |  |  | (9) |  |  |  |  |  |  |  |
| Other (2) |  | 88 |  |  | 5 |  |  | 1,660 |  |  |  |  |  |  |  |
| Total Sales |  | $ | 1,312,058 |  |  | $ | 791,894 |  |  | 66 | % |  |  |  |  |  |  |

[0001032975-21-000034:mdna:52]
[same as prior period, unchanged from 0001032975-21-000009:mdna:57]

[0001032975-21-000034:mdna:53]
[same as prior period, unchanged from 0001032975-21-000009:mdna:58]

[0001032975-21-000034:mdna:54]
[same as prior period, unchanged from 0001032975-21-000009:mdna:59]

[0001032975-21-000034:mdna:55]
[same as prior period, unchanged from 0001032975-21-000009:mdna:60]

[0001032975-21-000034:mdna:56]
Our Pointing Devices category comprises PC- and Mac-related mice including trackballs, touchpads and presentation tools.

[0001032975-21-000034:mdna:57]
Sales of Pointing Devices increased 52% in the three months ended June 30, 2021, compared to the same period of the prior fiscal year. The increase was primarily driven by higher sales of our cordless, corded, and trackball mice as a result of remote working and learning trends.

[0001032975-21-000034:mdna:58]
[same as prior period, unchanged from 0001032975-21-000009:mdna:63]

[0001032975-21-000034:mdna:59]
Our Keyboards & Combos category comprises PC keyboards, keyboard/mice combo products, and living room keyboards.

[0001032975-21-000034:mdna:60]
Sales of Keyboards & Combos increased 50% in the three months ended June 30, 2021, compared to the same period of the prior fiscal year. The increase was primarily driven by an increase in sales of our keyboard/mice combos as well as our cordless and corded PC keyboards.

[0001032975-21-000034:mdna:61]
[same as prior period, unchanged from 0001032975-21-000009:mdna:66]

[0001032975-21-000034:mdna:62]
Our PC Webcams category comprises PC-based webcams targeted primarily at consumers, including streaming cameras.

[0001032975-21-000034:mdna:63]
Sales of PC Webcams increased 81% in the three months ended June 30, 2021, compared to the same period of the prior fiscal year. The increase was seen across the majority of the product sub-categories, driven primarily by sales of our HD Pro Webcam 920, 1080P PRO Stream Webcam, Logitech Streamcam, and C505 HD Webcam, partly due to organizations adopting remote or hybrid work environments.

[0001032975-21-000034:mdna:64]
[same as prior period, unchanged from 0001032975-21-000009:mdna:69]

[0001032975-21-000034:mdna:65]
[same as prior period, unchanged from 0001032975-21-000009:mdna:70]

[0001032975-21-000034:mdna:66]
Sales of Tablet & Other Accessories products increased 72% in the three months ended June 30, 2021, compared to the same period of the prior fiscal year. The increase was primarily driven by sales of our Rugged Folio, our Combo Touch products for iPad Pro 11-inch/12.9-inch introduced in the first quarter of fiscal year 2022, and our Folio Touch for iPad Air (4th generation). We have seen strong demand for Tablet keyboards, partly due to schools embracing various technology devices to better educate students in learning-from-home environments.

[0001032975-21-000034:mdna:67]
[same as prior period, unchanged from 0001032975-21-000009:mdna:72]

[0001032975-21-000034:mdna:68]
Gaming

[0001032975-21-000034:mdna:69]
Our Gaming category comprises gaming mice, keyboards, headsets, gamepads, steering wheels, simulation controllers, console gaming headsets, console gaming controllers, and Streamlabs services.

[0001032975-21-000034:mdna:70]
Sales of Gaming increased 84% for the three months ended June 30, 2021, compared to the same period of the prior fiscal year. The increase was primarily driven by strong performance in nearly all of our Gaming sub-categories, including our gaming mice, PC gaming headsets, gaming steering wheels, gaming keyboards, console gaming headsets and Streamlabs services, partially offset by a decline in the sales of our console gaming controllers.

[0001032975-21-000034:mdna:71]
[same as prior period, unchanged from 0001032975-21-000009:mdna:75]

[0001032975-21-000034:mdna:72]
Video Collaboration

[0001032975-21-000034:mdna:73]
Our Video Collaboration category includes Logitech’s ConferenceCams, which combine affordable enterprise-quality audio and high definition 1080p video to bring video conferencing to businesses of any size.

[0001032975-21-000034:mdna:74]
Sales of Video Collaboration products increased 81% in the three months ended June 30, 2021, compared to the same period of the prior fiscal year. The increase was primarily driven by the sales of our Rally Bar introduced in the fourth quarter of fiscal year 2021, our GROUP video conferencing solution for mid to large-sized meeting rooms, the BRIO 4K Pro Webcam, and Webcam C925E, as video communications become more critical for remote and hybrid work environments.

[0001032975-21-000034:mdna:75]
[same as prior period, unchanged from 0001032975-21-000009:mdna:78]

[0001032975-21-000034:mdna:76]
[same as prior period, unchanged from 0001032975-21-000009:mdna:79]

[0001032975-21-000034:mdna:77]
[same as prior period, unchanged from 0001032975-21-000009:mdna:80]

[0001032975-21-000034:mdna:78]
Sales of Mobile Speakers decreased 2% for the three months ended June 30, 2021, compared to the same period of the prior fiscal year. The decrease was primarily driven by a decline in sales of our MEGABOOM 3, UE WONDERBOOM, and MEGABLAST mobile speakers. The decrease was partially offset by sales of our BOOM 3 and WONDERBOOM 2 speakers.

[0001032975-21-000034:mdna:79]
[same as prior period, unchanged from 0001032975-21-000009:mdna:82]

[0001032975-21-000034:mdna:80]
[same as prior period, unchanged from 0001032975-21-000009:mdna:83]

[0001032975-21-000034:mdna:81]
Sales of Audio & Wearables increased 63% for the three months ended June 30, 2021, compared to the same period of the prior fiscal year. The increase was primarily driven by higher sales of both our corded and cordless headsets, Blue Microphones products, and our PC speakers.

[0001032975-21-000034:mdna:82]
[same as prior period, unchanged from 0001032975-21-000009:mdna:85]

[0001032975-21-000034:mdna:83]
Smart Home

[0001032975-21-000034:mdna:84]
[same as prior period, unchanged from 0001032975-21-000009:mdna:86]

[0001032975-21-000034:mdna:85]
Sales of Smart Home decreased 9% during the three months ended June 30, 2021, compared to the same period of the prior fiscal year. The decrease was primarily due to a decline in sales of most of our Harmony remotes and our home video products, partially offset by increases in sales of our Harmony 665 Remote, Circle View Camera, and Circle View Doorbell, introduced in the third quarter of fiscal year 2021.

[0001032975-21-000034:mdna:86]
[same as prior period, unchanged from 0001032975-21-000009:mdna:88]

[0001032975-21-000034:mdna:87]
Gross profit for the three months ended June 30, 2021 and 2020 was as follows (Dollars in thousands):

[0001032975-21-000034:mdna:88]
|  |  | Three Months EndedJune 30, |  |  |
|  |  | 2021 |  | 2020 |  | Change |  |  |  |  |  |  |
| Net sales |  | $ | 1,312,058 |  |  | $ | 791,894 |  |  | 66 | % |  |  |  |  |  |  |
| Gross profit |  | $ | 568,926 |  |  | $ | 305,733 |  |  | 86 |  |  |  |  |  |  |  |
| Gross margin |  | 43.4 | % |  | 38.6 | % |  |  |  |  |  |  |  |  |

[0001032975-21-000034:mdna:89]
Gross profit consists of sales less cost of goods sold (which includes materials, direct labor and related overhead costs, costs of manufacturing facilities, royalties, costs of purchasing components from outside suppliers, distribution costs, warranty costs, customer support costs, shipping and handling costs, outside processing costs and write-down of inventories), and amortization of intangible assets.

[0001032975-21-000034:mdna:90]
Gross margin increased by 480 basis points for the three months ended June 30, 2021, compared to the same period of the prior fiscal year. Our gross margin benefited from higher sales volume, a favorable currency impact, lower logistics costs, and favorable product mix.

[0001032975-21-000034:mdna:91]
[same as prior period, unchanged from 0001032975-21-000009:mdna:94]

[0001032975-21-000034:mdna:92]
Operating expenses for the three months ended June 30, 2021 and 2020 were as follows (Dollars in thousands):

[0001032975-21-000034:mdna:93]
|  |  | Three Months EndedJune 30, |  |  |
|  |  | 2021 |  | 2020 |  |  |  |  |  |  |  |
| Marketing and selling |  | $ | 252,314 |  |  | $ | 133,238 |  |  |  |  |  |  |  |  |
| % of sales |  | 19.2 | % |  | 16.8 | % |  |  |  |  |  |  |  |
| Research and development |  | 69,246 |  |  | 49,725 |  |  |  |  |  |  |  |  |
| % of sales |  | 5.3 | % |  | 6.3 | % |  |  |  |  |  |  |  |
| General and administrative |  | 40,542 |  |  | 29,071 |  |  |  |  |  |  |  |  |
| % of sales |  | 3.1 | % |  | 3.7 | % |  |  |  |  |  |  |  |
| Amortization of intangible assets and acquisition-related costs |  | 5,217 |  |  | 4,609 |  |  |  |  |  |  |  |  |
| % of sales |  | 0.4 | % |  | 0.6 | % |  |  |  |  |  |  |  |
| Change in fair value of contingent consideration for business acquisition |  | (1,474) |  |  | 5,716 |  |  |  |  |  |  |  |  |
| % of sales |  | (0.1) | % |  | 0.7 | % |  |  |  |  |  |  |  |
| Restructuring credits, net |  | — |  |  | (53) |  |  |  |  |  |  |  |  |
| % of sales |  | — | % | (1) | — | % |  |  |  |  |  |  |  |
| Total operating expenses |  | $ | 365,845 |  |  | $ | 222,306 |  |  |  |  |  |  |  |  |
| % of sales |  | 27.9 | % |  | 28.1 | % |  |  |  |  |  |  |  |

[0001032975-21-000034:mdna:94]
[same as prior period, unchanged from 0001032975-21-000009:mdna:97]

[0001032975-21-000034:mdna:95]
The increase in total operating expenses during the three months ended June 30, 2021, compared to the same period of the prior fiscal year, was mainly due to increases in marketing and selling expenses, research and development expenses, and general and administrative expenses, partially offset by the change in fair value of contingent consideration for business acquisition.

[0001032975-21-000034:mdna:96]
[same as prior period, unchanged from 0001032975-21-000009:mdna:98]

[0001032975-21-000034:mdna:97]
[same as prior period, unchanged from 0001032975-21-000009:mdna:99]

[0001032975-21-000034:mdna:98]
During the three months ended June 30, 2021, marketing and selling expenses increased $119.1 million, compared to the same period of the prior fiscal year. The increase was primarily driven by higher advertising and marketing expenses, including third-party costs and increased headcount, to support our investment in brand awareness and consideration as well as incremental headcount related to investments in enterprise sales coverage.

[0001032975-21-000034:mdna:99]
[same as prior period, unchanged from 0001032975-21-000009:mdna:101]

[0001032975-21-000034:mdna:100]
Research and development expenses consist of personnel and related overhead costs for contractors and outside consultants, supplies and materials, equipment depreciation and facilities costs, all associated with the design and development of new products and enhancements of existing products.

[0001032975-21-000034:mdna:101]
During the three months ended June 30, 2021, research and development expenses increased $19.5 million, compared to the same period of the prior fiscal year. The increase was primarily driven by higher personnel-related costs due to incremental headcount and higher third-party costs to support innovations in both hardware and software.

[0001032975-21-000034:mdna:102]
[same as prior period, unchanged from 0001032975-21-000009:mdna:104]

[0001032975-21-000034:mdna:103]
General and administrative expenses consist primarily of personnel and related overhead, information technology, and facilities costs for the infrastructure functions such as finance, information systems, executives, human resources and legal.

[0001032975-21-000034:mdna:104]
During the three months ended June 30, 2021, general and administrative expenses increased $11.5 million, compared to the same period of the prior fiscal year. The increase was primarily driven by higher personnel-related costs due to investment in additional headcount in IT and other functions to support business growth.

[0001032975-21-000034:mdna:105]
[same as prior period, unchanged from 0001032975-21-000009:mdna:107]

[0001032975-21-000034:mdna:106]
[same as prior period, unchanged from 0001032975-21-000009:mdna:108]

[0001032975-21-000034:mdna:107]
During the three months ended June 30, 2021, amortization of intangible assets and acquisition-related costs increased compared to the same period of the prior fiscal year, primarily driven by the intangible assets acquired through acquisitions completed in the fourth quarter of fiscal year 2021.

[0001032975-21-000034:mdna:108]
[same as prior period, unchanged from 0001032975-21-000009:mdna:112]

[0001032975-21-000034:mdna:109]
Other income, net for the three months ended June 30, 2021 and 2020 was as follows (Dollars in thousands):

[0001032975-21-000034:mdna:110]
|  |  | Three Months EndedJune 30, |  |  |
|  |  | 2021 |  | 2020 |  |  |  |  |
| Investment income related to a deferred compensation plan |  | $ | 1,168 |  |  | $ | 1,556 |  |  |  |  |  |
| Currency exchange gain, net |  | 5,717 |  |  | 57 |  |  |  |  |  |
| Gain on investments |  | 1,071 |  |  | 174 |  |  |  |  |  |
| Other |  | 479 |  |  | 242 |  |  |  |  |  |
| Total |  | $ | 8,435 |  |  | $ | 2,029 |  |  |  |  |  |

[0001032975-21-000034:mdna:111]
[same as prior period, unchanged from 0001032975-21-000009:mdna:115]

[0001032975-21-000034:mdna:112]
Currency exchange gain, net relates to balances denominated in currencies other than the functional currency in our subsidiaries, as well as to the sale of currencies, and to gains or losses recognized on currency exchange forward contracts. We do not speculate in currency positions, but we are alert to opportunities to maximize currency exchange gains and minimize currency exchange losses. The gain for the three months ended June 30, 2021 was primarily due to the strengthening of the Brazilian Real and the Chinese Renminbi against the U.S. Dollar.

[0001032975-21-000034:mdna:113]
Gain on investments represents the unrealized gain from the fair value change on the available-for-sale securities and equity-method investments during the periods presented.

[0001032975-21-000034:mdna:114]
[same as prior period, unchanged from 0001032975-21-000009:mdna:119]

[0001032975-21-000034:mdna:115]
The provision for income taxes and effective income tax rates for the three months ended June 30, 2021 and 2020 were as follows (Dollars in thousands):

[0001032975-21-000034:mdna:116]
|  |  | Three Months EndedJune 30, |  |  |
|  |  | 2021 |  | 2020 |  |  |  |  |
| Provision for income taxes |  | $ | 24,991 |  |  | $ | 14,003 |  |  |  |  |  |
| Effective income tax rate |  | 11.8 | % |  | 16.3 | % |  |  |  |  |

[0001032975-21-000034:mdna:117]
The change in the effective income tax rate for the three months ended June 30, 2021, compared to the same period ended June 30, 2020 was primarily due to the mix of income and losses in the various tax jurisdictions in

[0001032975-21-000034:mdna:118]
which we operate.  There were discrete tax benefits of $13.7 million and $1.0 million from the recognition of excess tax benefits in the United States and reversal of uncertain tax positions from the expiration of statutes of limitations, respectively, in the three-month period ended June 30, 2021, compared with $5.0 million and $1.0 million, respectively, in the three-month period ended June 30, 2020.

[0001032975-21-000034:mdna:119]
As of June 30, 2021 and March 31, 2021, the total amount of unrecognized tax benefits due to uncertain tax positions was $165.5 million and $160.3 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-21-000034:mdna:120]
[same as prior period, unchanged from 0001032975-21-000009:mdna:124]

[0001032975-21-000034:mdna:121]
[same as prior period, unchanged from 0001032975-21-000009:mdna:125]

[0001032975-21-000034:mdna:122]
As of June 30, 2021, we had cash and cash equivalents of $1,497.7 million, compared to $1,750.3 million as of March 31, 2021. As of June 30, 2021, 62% of the cash and cash equivalents were held in Switzerland, 16% were held in Germany, and 12% were held in Hong Kong and China. We do not expect to incur any material adverse tax impact except for what has already been recognized, or be significantly inhibited by any country in which we do business from the repatriation of funds to Switzerland, our home domicile.

[0001032975-21-000034:mdna:123]
The decrease in cash and cash equivalents for the three months ended June 30, 2021, primarily resulted from an increase in net cash used in operating activities, despite positive net income, and an increase in net cash used in financing activities. The increase in net cash used in operating activities was mainly due to the timing of an annual income tax payment for fiscal year 2021, increased inventory purchases to support future demand, a decline in accounts payable due to timing of purchases and related payments, and the annual bonus payment for fiscal year 2021, partially offset by earlier collections on accounts receivable due to timing of sales within the quarter. The increase in net cash used in financing activities was driven by shares repurchased under our share repurchase program in the first quarter of fiscal 2022 compared to no share repurchases in the same period of the prior fiscal year.

[0001032975-21-000034:mdna:124]
As of June 30, 2021, our working capital was $1,568.0 million, compared to $1,477.5 million as of March 31, 2021. The increase was primarily driven by higher inventories and higher other current assets, lower accounts payable, and lower accrued and other current liabilities, partially offset by lower cash and cash equivalents and lower accounts receivable, net. Our working capital increased by $779.2 million compared to $788.8 million as of June 30, 2020, which was primarily driven by higher cash and cash equivalents, higher accounts receivable, net, higher inventories and higher other current assets, partially offset by higher accounts payable and accrued and other current liabilities.

[0001032975-21-000034:mdna:125]
We had several uncommitted, unsecured bank lines of credit aggregating $191.6 million as of June 30, 2021. There are no financial covenants under these lines of credit with which we must comply. As of June 30, 2021, we had outstanding bank guarantees of $24.7 million under these lines of credit.

[0001032975-21-000034:mdna:126]
[same as prior period, unchanged from 0001032975-21-000009:mdna:130]

[0001032975-21-000034:mdna:127]
|  |  | Three Months EndedJune 30, |
|  |  | 2021 |  | 2020 |
| Net cash provided by / (used in) operating activities |  | $ | (114,970) |  |  | $ | 118,847 |  |
| Net cash used in investing activities |  | (40,347) |  |  | (12,400) |  |
| Net cash used in financing activities |  | (102,533) |  |  | (13,129) |  |
| Effect of exchange rate changes on cash and cash equivalents |  | 5,244 |  |  | 511 |  |
| Net increase / (decrease) in cash and cash equivalents |  | $ | (252,606) |  |  | $ | 93,829 |  |

[0001032975-21-000034:mdna:128]
The following table presents selected financial information and statistics as of and for the three months ended June 30, 2021 and 2020 (Dollars in thousands):

[0001032975-21-000034:mdna:129]
|  |  | As of June 30, |  |
|  |  | 2021 |  | 2020 |  |
| Accounts receivable, net |  | $ | 545,907 |  |  | $ | 500,306 |  |  |
| Accounts payable |  | $ | 709,741 |  |  | $ | 429,693 |  |  |
| Inventories |  | $ | 778,596 |  |  | $ | 271,180 |  |  |

[0001032975-21-000034:mdna:130]
|  |  | Three Months EndedJune 30, |  |
|  |  | 2021 |  | 2020 |  |
| Days sales in accounts receivable (“DSO”) (Days) (1) |  | 37 |  |  | 57 |  |  |
| Days accounts payable outstanding (“DPO”) (Days) (2) |  | 86 |  |  | 80 |  |  |
| Inventory turnover (“ITO”) (x)(3) |  | 3.8 |  |  | 7.2 |  |  |

[0001032975-21-000034:mdna:131]
[same as prior period, unchanged from 0001032975-21-000009:mdna:135]

[0001032975-21-000034:mdna:132]
[same as prior period, unchanged from 0001032975-21-000009:mdna:136]

[0001032975-21-000034:mdna:133]
[same as prior period, unchanged from 0001032975-21-000009:mdna:137]

[0001032975-21-000034:mdna:134]
DSO for the three months ended June 30, 2021 decreased by 20 days to 37 days, compared to 57 days for the same period of the prior fiscal year, primarily due to timing of sales within the quarter and a continued focus on collections efficiency.

[0001032975-21-000034:mdna:135]
DPO for the three months ended June 30, 2021 increased by 6 days, compared to 80 days for the same period of the prior fiscal year, primarily due to the timing of purchases and related payments.

[0001032975-21-000034:mdna:136]
ITO for the three months ended June 30, 2021 decreased by 3.4, compared to 7.2 for the same period of the prior fiscal year, primarily due to higher ending inventory resulting from the rebuilding of inventory levels to meet future demand, compared to previously constrained supply from COVID-19 impacts. In the fourth quarter of fiscal year 2020, we experienced manufacturing slowdowns due to the COVID-19 outbreak in China which reduced our ending inventory levels and led to higher inventory turns in the first quarter of fiscal year 2021.

[0001032975-21-000034:mdna:137]
[same as prior period, unchanged from 0001032975-21-000009:mdna:142]

[0001032975-21-000034:mdna:138]
During the three months ended June 30, 2021, net cash used in operating activities was $115.0 million. The decrease in accounts receivable, net was primarily driven by timing of sales. The increase in inventories was primarily driven by an increase in inventory purchases during the first quarter of fiscal year 2022 in anticipation of future demand. The decrease in accounts payable was primarily driven by the timing of purchases and related payments. The decrease in accrued liabilities was primarily driven by payment of the fiscal year 2021 annual bonus and an annual payment for fiscal year 2021 income taxes.

[0001032975-21-000034:mdna:139]
Net cash used in investing activities was $40.3 million, primarily due to $24.5 million of purchases of property, plant and equipment, and $15.6 million of the purchase price (net of cash acquired) for business acquisition.

[0001032975-21-000034:mdna:140]
Net cash used in financing activities was $102.5 million, primarily due to $54.9 million used for repurchases of our registered shares, and $50.4 million for tax withholdings related to net share settlements of restricted stock units, partially offset by $2.8 million in proceeds received from exercises of stock options and purchase rights.

[0001032975-21-000034:mdna:141]
During the three months ended June 30, 2021, there was a $5.2 million gain from currency exchange rate effect on cash and cash equivalents, compared to a gain of $0.5 million during the same period of the prior fiscal year. The gain from currency translation exchange effect during the three months ended June 30, 2021 was primarily due to the strengthening of the Brazilian Real and the Chinese Renminbi against the U.S. Dollar by 14% and 2%, respectively, during the period. The gain from effect of currency exchange rate changes during the three months ended June 30, 2020 was primarily due to the strengthening of the Australian Dollar, Japanese Yen, and Taiwanese Dollar against the U.S. Dollar by 13%, 1%, and 2%, respectively.

[0001032975-21-000034:mdna:142]
[same as prior period, unchanged from 0001032975-21-000009:mdna:148]

[0001032975-21-000034:mdna:143]
[same as prior period, unchanged from 0001032975-21-000009:mdna:149]

[0001032975-21-000034:mdna:144]
In April 2021, the Board of Directors recommended that we pay cash dividends for fiscal year 2021 of CHF 147.0 million ($155.8 million based on the exchange rate on March 31, 2021). In fiscal year 2021, we paid a cash dividend of CHF 134.0 million (U.S. Dollar amount of $146.7 million) out of fiscal year 2020 retained earnings. In fiscal year 2020, we paid a cash dividend of CHF 121.8 million (U.S. Dollar amount of $124.2 million) out of fiscal year 2019 retained earnings.

[0001032975-21-000034:mdna:145]
In May 2020, our Board of Directors approved a new share repurchase program, which authorizes us to invest up to $250.0 million to purchase our own shares, following the expiration date of the 2017 share repurchase program. Although we enter into trading plans for systematic repurchases (e.g., 10b5-1 trading plans) from time to time, our share repurchase program provides us with the opportunity to make opportunistic repurchases during periods of favorable market conditions and is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Opportunistic purchases may be started or stopped at any time without prior notice depending on market conditions and other factors. In April 2021, our Board of Directors approved an increase of $750.0 million of the 2020 share repurchase program, to an aggregate amount of $1.0 billion. The Swiss Takeover Board approved this increase and it became effective on May 21, 2021. As of June 30, 2021, $780.4 million is still available for repurchase under the 2020 repurchase program.

[0001032975-21-000034:mdna:146]
[same as prior period, unchanged from 0001032975-21-000009:mdna:152]

[0001032975-21-000034:mdna:147]
Operating Leases Obligations

[0001032975-21-000034:mdna:148]
[same as prior period, unchanged from 0001032975-21-000009:mdna:154]

[0001032975-21-000034:mdna:149]
[same as prior period, unchanged from 0001032975-21-000009:mdna:155]

[0001032975-21-000034:mdna:150]
As of June 30, 2021, we had non-cancelable purchase commitments of $775.3 million for inventory purchases made in the normal course of business from original design manufacturers, contract manufacturers and other suppliers, the majority of which are expected to be fulfilled within the next 12 months. We recorded a liability for firm, non-cancelable, and unhedged inventory purchase commitments in excess of anticipated demand or net realizable value consistent with our valuation of excess and obsolete inventory. As of June 30, 2021, the liability for these purchase commitments was $13.9 million and is recorded in accrued and other current liabilities.

[0001032975-21-000034:mdna:151]
We have firm purchase commitments of $25.8 million for capital expenditures primarily related to commitments for tooling and equipment for new and existing products. We expect to continue making capital expenditures in the future to support product development activities and ongoing and expanded operations. Although open purchase commitments are considered enforceable and legally binding, the terms generally allow us to reschedule or adjust our requirements based on business needs prior to delivery of goods or performance of services.

[0001032975-21-000034:mdna:152]
[same as prior period, unchanged from 0001032975-21-000009:mdna:159]

[0001032975-21-000034:mdna:153]
For further detail about our contractual obligations and commitments, refer to our Annual Report on Form 10-K for the fiscal year ended March 31, 2021.

[0001032975-21-000034:mdna:154]
[same as prior period, unchanged from 0001032975-21-000009:mdna:163]

[0001032975-21-000034:mdna:155]
We indemnify certain suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of June 30, 2021, no amounts have been accrued for indemnification provisions. We do not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under our indemnification arrangements.

[0001032975-21-000034:mdna:156]
[same as prior period, unchanged from 0001032975-21-000009:mdna:165]

[0001032975-21-000034:mdna:157]
Legal Proceedings

[0001032975-21-000034:mdna:158]
From time to time we are involved in claims and legal proceedings that arise in the ordinary course of our business.  For more information about Legal Proceedings, see Part II Item 1 Legal Proceedings of this quarterly report on Form 10-Q for the period ended June 30, 2021.
