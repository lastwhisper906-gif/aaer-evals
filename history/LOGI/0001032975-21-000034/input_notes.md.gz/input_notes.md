# LOGI notes — 0001032975-21-000034


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001032975-21-000034:notes:1]
[same as prior period, unchanged from 0001032975-21-000009:notes:1]

[0001032975-21-000034:notes:2]
Logitech International S.A, together with its consolidated subsidiaries ("Logitech" or the "Company"), designs, manufactures and markets products that have an everyday place in people's lives, connecting them to the digital experiences they care about. Forty years ago, Logitech created products to improve experiences around the personal PC platform, and today it is a multi-brand, multi-category company designing products that enable better experiences consuming, sharing and creating any digital content such as computing, gaming, video, and music, whether it is on a computer, mobile device or in the cloud.

[0001032975-21-000034:notes:3]
The Company sells its products to a broad network of domestic and international customers, including direct sales to retailers and e-tailers, and indirect sales through distributors.

[0001032975-21-000034:notes:4]
Logitech was founded in Switzerland in 1981 and Logitech International S.A. has been the parent holding company of Logitech since 1988. Logitech International S.A. is a Swiss holding company with its registered office in Apples, Switzerland and headquarters in Lausanne, Switzerland, which conducts its business through subsidiaries in the Americas, Europe, Middle East and Africa ("EMEA") and Asia Pacific. Shares of Logitech International S.A. are listed on both the SIX Swiss Exchange under the trading symbol LOGN and the Nasdaq Global Select Market under the trading symbol LOGI.

[0001032975-21-000034:notes:5]
[same as prior period, unchanged from 0001032975-21-000009:notes:5]

[0001032975-21-000034:notes:6]
The condensed consolidated financial statements include the accounts of Logitech and its subsidiaries. All intercompany balances and transactions have been eliminated. The condensed consolidated financial statements are presented in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") for interim financial information and therefore do not include all the information required by U.S. GAAP for complete financial statements. The condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended March 31, 2021, included in its Annual Report on Form 10-K filed with the Securities and Exchange Commission ("SEC") on May 12, 2021.

[0001032975-21-000034:notes:7]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three months ended June 30, 2021 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2022, or any future periods.

[0001032975-21-000034:notes:8]
[same as prior period, unchanged from 0001032975-21-000009:notes:8]

[0001032975-21-000034:notes:9]
Other than the recent accounting pronouncements adopted and discussed below under Recent Accounting Pronouncements Adopted, there have been no material changes in the Company’s significant accounting policies during the three months ended June 30, 2021 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2021.

[0001032975-21-000034:notes:10]
[same as prior period, unchanged from 0001032975-21-000009:notes:10]

[0001032975-21-000034:notes:11]
The preparation of financial statements in conformity with U.S. GAAP requires management to make judgments, estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Significant estimates and assumptions made by management involve the fair value of goodwill and intangible assets acquired from business acquisitions, contingent consideration for a business acquisition and periodic reassessment of its fair value, valuation of investment in privately held companies classified under Level 3 fair value hierarchy, pension obligations, accruals for customer incentives, cooperative marketing, and pricing programs and related breakage when appropriate, inventory valuation, share-based compensation expense, uncertain tax positions, and valuation allowances for deferred tax assets. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ materially from those estimates.

[0001032975-21-000034:notes:12]
[same as prior period, unchanged from 0001032975-21-000009:notes:12]

[0001032975-21-000034:notes:13]
We are subject to risks and uncertainties as a result of the novel coronavirus ("COVID-19"). Capital markets and economies worldwide have been negatively impacted by COVID-19 and it is still unclear how lasting and deep the economic impacts will be. During the first quarter of fiscal year 2022, the COVID-19 pandemic had mixed effects on the Company’s results of operations. While we experienced increased sales and operating income compared to the first quarter of fiscal year 2021, we also experienced supply and demand volatility, as the COVID-19 pandemic and related safety measures and restrictions have evolved differently across the world. The ongoing and full extent of the impact of the COVID-19 pandemic on the Company's business and operational and financial performance and condition, including the sustainability of its effect on trends positive to the Company, is uncertain and will depend on many factors outside the Company's control, including but not limited to the timing, extent, duration and effects of the virus and any of its mutations, the vaccination rates, the development of effective treatments, the imposition of effective public safety and other protective measures and the public's response to such measures, the impact of COVID-19 on the global economy and demand for the Company's products and services. Should the COVID-19 pandemic or global economic slowdown not improve or worsen, or if the Company's attempt to mitigate its impact on its operations and costs is not successful, the Company's business, results of operations, financial condition and prospects may be adversely affected.

[0001032975-21-000034:notes:14]
[same as prior period, unchanged from 0001032975-21-000009:notes:14]

[0001032975-21-000034:notes:15]
In December 2019, the FASB issued ASU 2019-12, "Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes" (ASU 2019-12), which eliminates certain exceptions for recognizing deferred taxes for investments, performing intraperiod allocation and calculating income taxes in interim periods. This ASU also includes guidance to reduce complexity in certain areas, including recognizing deferred taxes for tax goodwill and allocating taxes to members of a consolidated group. ASU 2019-12 is effective for annual and interim periods in fiscal years beginning after December 15, 2020. Early adoption is permitted. The Company adopted this standard effective April 1, 2021. The adoption of ASU 2019-12 did not have a material impact on the Company's condensed consolidated financial statements.


## us-gaap:EarningsPerShareTextBlock

[0001032975-21-000034:notes:16]
[same as prior period, unchanged from 0001032975-21-000009:notes:20]

[0001032975-21-000034:notes:17]
The following table summarizes the computations of basic and diluted net income per share for the three months ended June 30, 2021 and June 30, 2020 (in thousands, except per share amounts):

[0001032975-21-000034:notes:18]
|  |  | Three Months EndedJune 30, |  |  |
|  |  | 2021 |  | 2020 |  |  |  |  |
| Net income |  | $ | 186,841 |  |  | $ | 72,073 |  |  |  |  |  |
| Shares used in net income per share computation: |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding - basic |  | 168,372 |  |  | 167,612 |  |  |  |  |  |
| Effect of potentially dilutive equivalent shares |  | 3,648 |  |  | 2,515 |  |  |  |  |  |
| Weighted average shares outstanding - diluted |  | 172,020 |  |  | 170,127 |  |  |  |  |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.11 |  |  | $ | 0.43 |  |  |  |  |  |
| Diluted |  | $ | 1.09 |  |  | $ | 0.42 |  |  |  |  |  |

[0001032975-21-000034:notes:19]
Share equivalents attributable to outstanding stock options, restricted stock units ("RSUs") and employee share purchase plans ("ESPP") totaling 0.5 million and 1.4 million for the three months ended June 30, 2021 and 2020, respectively, were excluded from the calculation of diluted net income per share because the combined exercise price and average unamortized grant date fair value upon exercise of these options and ESPP rights or vesting of RSUs were greater than the average market price of the Company's shares during the periods presented herein, and therefore their inclusion would have been anti-dilutive. A small number of performance-based awards were not included in the calculation because all necessary conditions had not been satisfied by the end of the respective period, and those shares were not issuable if the end of the reporting period were the end of the performance contingency period.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001032975-21-000034:notes:20]
[same as prior period, unchanged from 0001032975-21-000009:notes:24]

[0001032975-21-000034:notes:21]
[same as prior period, unchanged from 0001032975-21-000009:notes:25]

[0001032975-21-000034:notes:22]
As of June 30, 2021, the Company offers the 2006 Employee Share Purchase Plan (Non-U.S.), as amended and restated, the 1996 Employee Share Purchase Plan (U.S.), as amended and restated, the 2006 Stock Incentive Plan, as amended and restated, and the 2012 Stock Inducement Equity Plan. Shares issued to employees as a result of purchases or exercises under these plans are generally issued from shares held in treasury stock.

[0001032975-21-000034:notes:23]
The following table summarizes the share-based compensation expense and total income tax benefit recognized for share-based awards for the three months ended June 30, 2021 and 2020 (in thousands):

[0001032975-21-000034:notes:24]
|  |  | Three Months EndedJune 30, |  |  |
|  |  | 2021 |  | 2020 |  |  |  |  |
| Cost of goods sold |  | $ | 1,369 |  |  | $ | 1,400 |  |  |  |  |  |
| Marketing and selling |  | 8,530 |  |  | 8,792 |  |  |  |  |  |
| Research and development |  | 5,061 |  |  | 3,103 |  |  |  |  |  |
| General and administrative |  | 8,691 |  |  | 6,820 |  |  |  |  |  |
| Total share-based compensation expense |  | 23,651 |  |  | 20,115 |  |  |  |  |  |
| Income tax benefit |  | (16,594) |  |  | (8,111) |  |  |  |  |  |
| Total share-based compensation expense, net of income tax benefit |  | $ | 7,057 |  |  | $ | 12,004 |  |  |  |  |  |

[0001032975-21-000034:notes:25]
The income tax benefit in the respective periods primarily consisted of tax benefits related to the share-based compensation expense for the period and direct tax benefit realized, including net excess tax benefits recognized from share-based awards vested or exercised during the period.

[0001032975-21-000034:notes:26]
As of June 30, 2021 and 2020, the balance of capitalized share-based compensation included in inventory was $1.7 million and $0.9 million, respectively.

[0001032975-21-000034:notes:27]
[same as prior period, unchanged from 0001032975-21-000009:notes:31]

[0001032975-21-000034:notes:28]
Certain of the Company’s subsidiaries sponsor defined benefit pension plans or non-retirement post-employment benefits covering substantially all of their employees. Benefits are provided based on employees’ years of service and earnings, or in accordance with applicable employee benefit regulations. The Company’s practice is to fund amounts sufficient to meet the requirements set forth in the applicable employee benefit and tax regulations. The costs recorded of $3.3 million and $2.7 million for the three months ended June 30, 2021 and 2020, respectively, were primarily related to service costs.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001032975-21-000034:notes:29]
[same as prior period, unchanged from 0001032975-21-000009:notes:33]

[0001032975-21-000034:notes:30]
[same as prior period, unchanged from 0001032975-21-000009:notes:34]

[0001032975-21-000034:notes:31]
The income tax provision for the three months ended June 30, 2021 was $25.0 million based on an effective income tax rate of 11.8% of pre-tax income, compared to an income tax provision of $14.0 million based on an effective income tax rate of 16.3% of pre-tax income for the three months ended June 30, 2020.

[0001032975-21-000034:notes:32]
The change in the effective income tax rate for the three months ended June 30, 2021, compared to the same period ended June 30, 2020 was primarily due to the mix of income and losses in the various tax jurisdictions in which the Company operates. There were discrete tax benefits of $13.7 million and $1.0 million from the recognition of excess tax benefits in the United States and reversal of uncertain tax positions from the expiration of statutes of limitations, respectively, in the three-month period ended June 30, 2021, compared with $5.0 million and $1.0 million, respectively, in the three-month period ended June 30, 2020.

[0001032975-21-000034:notes:33]
As of June 30, 2021 and March 31, 2021, the total amount of unrecognized tax benefits due to uncertain tax positions was $165.5 million and $160.3 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-21-000034:notes:34]
As of June 30, 2021 and March 31, 2021, the Company had $63.0 million and $59.2 million, respectively, in non-current income taxes payable including interest and penalties, related to the Company's income tax liability for uncertain tax positions.

[0001032975-21-000034:notes:35]
The Company recognizes interest and penalties related to unrecognized tax positions in the income tax provision. As of June 30, 2021 and March 31, 2021, the Company had $5.1 million and $4.9 million, respectively, of accrued interest and penalties related to uncertain tax positions in non-current income taxes payable.

[0001032975-21-000034:notes:36]
Although the Company has adequately provided for uncertain tax positions, the provisions related to these positions may change as revised estimates are made or the underlying matters are settled or otherwise resolved. During fiscal year 2022, the Company continues to review its tax positions and provide for or reverse unrecognized tax benefits as they arise. During the next twelve months, it is reasonably possible that the amount of unrecognized tax benefits could increase or decrease significantly due to changes in tax law in various jurisdictions, new tax audits and changes in the U.S. dollar as compared to other currencies. Excluding these factors, uncertain tax positions may decrease by as much as $5.1 million from the lapse of the statutes of limitations in various jurisdictions during the next twelve months.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001032975-21-000034:notes:37]
[same as prior period, unchanged from 0001032975-21-000009:notes:42]

[0001032975-21-000034:notes:38]
The following table presents the components of certain balance sheet asset amounts as of June 30 and March 31, 2021 (in thousands):

[0001032975-21-000034:notes:39]
|  |  | June 30, 2021 |  | March 31, 2021 |
| Accounts receivable, net: |  |  |  |  |
| Accounts receivable |  | $ | 812,042 |  |  | $ | 867,868 |  |
| Allowance for doubtful accounts |  | (548) |  |  | (1,161) |  |
| Allowance for sales returns |  | (10,892) |  |  | (14,438) |  |
| Allowance for cooperative marketing arrangements |  | (58,901) |  |  | (43,276) |  |
| Allowance for customer incentive programs |  | (73,806) |  |  | (76,200) |  |
| Allowance for pricing programs |  | (121,988) |  |  | (120,568) |  |
|  |  | $ | 545,907 |  |  | $ | 612,225 |  |
| Inventories: |  |  |  |  |
| Raw materials |  | $ | 166,477 |  |  | $ | 146,886 |  |
| Finished goods |  | 612,119 |  |  | 514,230 |  |
|  |  | $ | 778,596 |  |  | $ | 661,116 |  |
| Other current assets: |  |  |  |  |
| Value-added tax receivables |  | $ | 74,098 |  |  | $ | 67,710 |  |
| Prepaid expenses and other assets |  | 84,032 |  |  | 67,940 |  |
|  |  | $ | 158,130 |  |  | $ | 135,650 |  |
| Property, plant and equipment, net: |  |  |  |  |
| Property, plant and equipment at cost |  | $ | 437,778 |  |  | $ | 417,520 |  |
| Accumulated depreciation and amortization |  | (323,085) |  |  | (303,460) |  |
|  |  | $ | 114,693 |  |  | $ | 114,060 |  |
| Other assets: |  |  |  |  |
| Deferred tax assets |  | $ | 216,671 |  |  | $ | 210,888 |  |
| Right-of-use assets |  | 33,015 |  |  | 31,169 |  |
| Trading investments for deferred compensation plan |  | 29,092 |  |  | 24,809 |  |
| Investments in privately held companies |  | 44,997 |  |  | 43,402 |  |
| Other assets |  | 14,710 |  |  | 13,980 |  |
|  |  | $ | 338,485 |  |  | $ | 324,248 |  |

[0001032975-21-000034:notes:40]
The following table presents the components of certain balance sheet liability amounts as of June 30 and March 31, 2021 (in thousands):

[0001032975-21-000034:notes:41]
|  |  | June 30, 2021 |  | March 31, 2021 |
| Accrued and other current liabilities: |  |  |  |  |
| Accrued customer marketing, pricing and incentive programs |  | $ | 181,423 |  |  | $ | 185,394 |  |
| Accrued personnel expenses |  | 123,427 |  |  | 173,360 |  |
| VAT payable |  | 55,350 |  |  | 50,620 |  |
| Accrued sales return liability |  | 51,122 |  |  | 43,178 |  |
| Accrued payables - non-inventory |  | 43,394 |  |  | 52,392 |  |
| Warranty accrual |  | 33,981 |  |  | 33,228 |  |
| Income taxes payable |  | 27,078 |  |  | 131,408 |  |
| Operating lease liability |  | 14,681 |  |  | 13,101 |  |
| Contingent consideration |  | 11,495 |  |  | 6,967 |  |
| Other current liabilities |  | 160,638 |  |  | 168,969 |  |
|  |  | $ | 702,589 |  |  | $ | 858,617 |  |
| Other non-current liabilities: |  |  |  |  |
| Employee benefit plan obligations |  | $ | 73,726 |  |  | $ | 72,321 |  |
| Obligation for deferred compensation plan |  | 29,092 |  |  | 24,809 |  |
| Operating lease liability |  | 21,310 |  |  | 21,319 |  |
| Warranty accrual |  | 15,112 |  |  | 15,604 |  |
| Contingent consideration |  | 3,971 |  |  | — |  |
| Deferred tax liability |  | 1,679 |  |  | 1,679 |  |
| Other non-current liabilities |  | 2,814 |  |  | 3,770 |  |
|  |  | $ | 147,704 |  |  | $ | 139,502 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001032975-21-000034:notes:42]
[same as prior period, unchanged from 0001032975-21-000009:notes:47]

[0001032975-21-000034:notes:43]
[same as prior period, unchanged from 0001032975-21-000009:notes:48]

[0001032975-21-000034:notes:44]
[same as prior period, unchanged from 0001032975-21-000009:notes:49]

[0001032975-21-000034:notes:45]
[same as prior period, unchanged from 0001032975-21-000009:notes:50]

[0001032975-21-000034:notes:46]
[same as prior period, unchanged from 0001032975-21-000009:notes:51]

[0001032975-21-000034:notes:47]
[same as prior period, unchanged from 0001032975-21-000009:notes:52]

[0001032975-21-000034:notes:48]
|  |  | June 30, 2021 |  | March 31, 2021 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Level 1 |  | Level 2 |  | Level 3 |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 562,606 |  |  | $ | — |  |  | $ | — |  |  | $ | 669,759 |  |  | $ | — |  |  | $ | — |  |
| Trading investments for deferred compensation plan included in other assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 143 |  |  | $ | — |  |  | $ | — |  |  | $ | 31 |  |  | $ | — |  |  | $ | — |  |
| Common stock |  | 1,734 |  |  | — |  |  | — |  |  | 1,569 |  |  | — |  |  | — |  |
| Money market funds |  | 7,511 |  |  | — |  |  | — |  |  | 6,734 |  |  | — |  |  | — |  |
| Mutual funds |  | 19,704 |  |  | — |  |  | — |  |  | 16,475 |  |  | — |  |  | — |  |
| Total of trading investments for deferred compensation plan |  | $ | 29,092 |  |  | $ | — |  |  | $ | — |  |  | $ | 24,809 |  |  | $ | — |  |  | $ | — |  |
| Currency exchange derivative assetsincluded in other current assets |  | $ | — |  |  | $ | 3,628 |  |  | $ | — |  |  | $ | — |  |  | $ | 5,452 |  |  | $ | — |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Contingent consideration for business acquisition included in accrued and other current liabilities |  | $ | — |  |  | $ | — |  |  | $ | 10,957 |  |  | $ | — |  |  | $ | — |  |  | $ | 6,430 |  |
| Contingent consideration for business acquisition included in other non-current liabilities |  | $ | — |  |  | $ | — |  |  | $ | 3,971 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Currency exchange derivative liabilitiesincluded in accrued and other current liabilities |  | $ | — |  |  | $ | 229 |  |  | $ | — |  |  | $ | — |  |  | $ | 100 |  |  | $ | — |  |

[0001032975-21-000034:notes:49]
The following table summarizes the change in the fair value of the Company's contingent consideration balance during the three months ended June 30, 2021 and 2020 (in thousands):

[0001032975-21-000034:notes:50]
|  | Three Months EndedJune 30, |
|  | 2021 |  | 2020 |
| Beginning of the period | $ | 6,967 |  |  | $ | 23,284 |  |
| Fair value of contingent consideration upon acquisition (1) | 9,973 |  |  | — |  |
| Change in fair value of contingent consideration | (1,474) |  |  | 5,716 |  |
| End of the period (2) | $ | 15,466 |  |  | $ | 29,000 |  |

[0001032975-21-000034:notes:51]
(1) Fair value of contingent consideration includes the earn-out of the immaterial technology acquisition. See Contingent Consideration for Business Acquisitions section below for details.

[0001032975-21-000034:notes:52]
(2) As of June 30, 2020, the earn-out period was completed in connection with our acquisition of General Workings, Inc. ("Streamlabs") (discussed below). The earn-out payment of $29.0 million was based on the actual net sales of Streamlabs services during the earn-out period and is no longer subject to fair value measurement and was accordingly transferred out of Level 3. During the third quarter of fiscal year 2021, the fair value of $28.5 million of the contingent consideration was transferred from other current liabilities to equity upon settlement of the contingent consideration through the issuance of shares out of treasury stock. The remaining $0.5 million is held back in escrow for claims made against the escrow and for the payment of taxes.

[0001032975-21-000034:notes:53]
[same as prior period, unchanged from 0001032975-21-000009:notes:57]

[0001032975-21-000034:notes:54]
The marketable securities for the Company's deferred compensation plan were recorded at a fair value of $29.1 million and $24.8 million, as of June 30, 2021 and March 31, 2021, respectively, based on quoted market prices. Quoted market prices are observable inputs that are classified as Level 1 within the fair value hierarchy.

[0001032975-21-000034:notes:55]
Unrealized gains (losses) related to trading securities for the three months ended June 30, 2021 and 2020 were not material and are included in other income, net in the Company's condensed consolidated statements of operations.

[0001032975-21-000034:notes:56]
Contingent Consideration for Business Acquisitions

[0001032975-21-000034:notes:57]
On May 19, 2021, the Company made an immaterial technology acquisition. The contingent consideration for business acquisition arising from the immaterial technology acquisition represents the future potential earn-out payments of up to $10.0 million payable in cash only upon the achievement of three technical development milestones required to be completed for periods ending December 31, 2021, June 30, 2022, and June 30, 2023. The fair value of the contingent amount was determined using a probability-weighted expected payment model and discounted at the estimated cost of debt.

[0001032975-21-000034:notes:58]
On February 17, 2021 (the "Mevo Acquisition Date"), the Company acquired all of the equity interests of Mevo Inc. ("Mevo"). In connection with the acquisition of Mevo, the Company agreed to pay a total earn out payment of up to $17.0 million payable in cash only upon the achievement of certain net sales for the period beginning on December 26, 2020 and ending on December 31, 2021.

[0001032975-21-000034:notes:59]
The fair value of the earn-out as of the Mevo Acquisition Date was $3.4 million which was determined by using a Black-Scholes-Merton valuation model to calculate the probability of the earn-out threshold being met, times the value of the earn-out payment, and discounted at the risk-free rate. The valuation includes significant assumptions and unobservable inputs such as the projected sales of Mevo over the earn-out period, risk-free rate, and the net sales volatility. Projected sales are based on the Company's internal projections, including analysis of the target market and historical sales of Mevo products. The fair value of the contingent consideration decreased to $1.9 million as of June 30, 2021 from $3.4 million as of March 31, 2021.

[0001032975-21-000034:notes:60]
On January 4, 2021, the Company made an immaterial technology acquisition. The contingent consideration for business acquisition arising from the immaterial technology acquisition represents the future potential earn-out payments of up to $3.0 million payable in cash upon the achievement of two technical development milestones required to be completed for periods ending December 31, 2021 and March 31, 2022. The fair value of the contingent amount was determined using a probability-weighted expected payment model and discounted at the estimated cost of debt.

[0001032975-21-000034:notes:61]
On October 31, 2019, the Company acquired all of the equity interests of General Workings, Inc. (Streamlabs). In connection with the acquisition of Streamlabs, the Company agreed to pay a total earn-out payment of up to $29.0 million, payable in stock, only upon the achievement of certain net revenues for the period beginning on January 1, 2020 and ending on June 30, 2020.  The fair value was increased by $5.7 million to $29.0 million as of June 30, 2020, based on actual sales. As of June 30, 2020, the earn-out period was completed, and was no longer subject to fair value measurement. During the third quarter of 2021, the fair value of $28.5 million of the contingent consideration was transferred from other current liabilities to equity upon settlement of the contingent consideration through the issuance of shares out of treasury stock. The remaining amount of $0.5 million is held back in escrow for claims made against the escrow and for the payment of taxes.

[0001032975-21-000034:notes:62]
Although these estimates are based on management’s best knowledge of current events, the estimates could change significantly from period to period. Actual results that differ from the assumptions used and any changes to the significant assumptions and unobservable inputs used could have a material impact on future results of operations.

[0001032975-21-000034:notes:63]
[same as prior period, unchanged from 0001032975-21-000009:notes:63]

[0001032975-21-000034:notes:64]
The Company has certain non-marketable investments included in other assets that are accounted for under the equity method of accounting, with a carrying value of $42.3 million and $40.7 million as of June 30, 2021 and March 31, 2021, respectively. Unrealized gains (losses) related to equity investments for the three months ended June 30, 2021 and 2020 were not material and are included in other income, net in the Company's condensed consolidated statements of operations. There was no impairment of these assets during the three months ended June 30, 2021 or 2020.

[0001032975-21-000034:notes:65]
[same as prior period, unchanged from 0001032975-21-000009:notes:65]

[0001032975-21-000034:notes:66]
Financial Assets.  The Company has certain investments without readily determinable fair values due to the absence of quoted market prices, the inherent lack of liquidity, and the fact that inputs used to measure fair value are unobservable and require management's judgment. When certain events or circumstances indicate that impairment may exist, the Company revalues the investments using various assumptions, including the financial metrics and ratios of comparable public companies. The carrying value is also adjusted for observable price changes with a same or similar security from the same issuer. The amount of these investments included in other assets was immaterial as of June 30, 2021 and March 31, 2021. There was no impairment of these assets during the three months ended June 30, 2021 or 2020.

[0001032975-21-000034:notes:67]
Non-Financial Assets.  Goodwill, intangible assets, and property, plant and equipment, are not required to be measured at fair value on a recurring basis. However, if certain triggering events occur (or tested at least annually for goodwill) such that a non-financial instrument is required to be evaluated for impairment and an impairment is recorded to reduce the non-financial instrument's carrying value to the fair value as a result of such triggering events, the non-financial assets and liabilities are measured at fair value for the period such triggering events occur. There was no impairment of these assets during the three months ended June 30, 2021 or 2020.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001032975-21-000034:notes:68]
[same as prior period, unchanged from 0001032975-21-000009:notes:68]

[0001032975-21-000034:notes:69]
Under certain agreements with the respective counterparties to the Company’s derivative contracts, subject to applicable requirements, the Company is allowed to net settle transactions of the same type with a single net amount payable by one party to the other. However, the Company presents its derivative assets and derivative liabilities on a gross basis on the condensed consolidated balance sheets as of June 30, 2021 and March 31, 2021.

[0001032975-21-000034:notes:70]
The fair value of the Company’s derivative instruments was not material as of June 30, 2021 or March 31, 2021. The amount of gain (loss) recognized on derivatives not designated as hedging instruments was not material in all periods presented herein. The following table presents the amounts of gains (losses) on the Company’s derivative instruments designated as hedging instruments and their locations on its condensed consolidated statements of operations and condensed consolidated statements of comprehensive income for the three months ended June 30, 2021 and 2020 (in thousands):

[0001032975-21-000034:notes:71]
|  |  | Three Months EndedJune 30, |
|  |  | Amount of Gain (Loss)Deferred as a Component of AccumulatedOther Comprehensive Loss |  | Amount of Loss (Gain)Reclassified from Accumulated Other Comprehensive Loss to Costs of Goods Sold |  |  |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |  |  |  |  |
| Cash flow hedges |  | $ | 530 |  |  | $ | (2,367) |  |  | $ | (594) |  |  | $ | (330) |  |  |  |  |  |

[0001032975-21-000034:notes:72]
[same as prior period, unchanged from 0001032975-21-000009:notes:73]

[0001032975-21-000034:notes:73]
The Company enters into cash flow hedge contracts to protect against exchange rate exposure of forecasted inventory purchases. These hedging contracts mature within four months. Gains and losses in the fair value of the effective portion of the hedges are deferred as a component of accumulated other comprehensive loss until the hedged inventory purchases are sold, at which time the gains or losses are reclassified to cost of goods sold. Cash flows from such hedges are classified as operating activities in the condensed consolidated statements of cash flows. Hedging relationships are discontinued when hedging contract is no longer eligible for hedge accounting, or is sold, terminated or exercised, or when Company removes hedge designation for the contract. Gains and losses in the fair value of the effective portion of the discontinued hedges continue to be reported in accumulated other comprehensive loss until the hedged inventory purchases are sold, unless it is probable that the forecasted inventory purchases will not occur by the end of the originally specified time period or within an additional two-month period of time thereafter. In all periods presented herein, there have been no forecasted inventory purchases that were probable to not occur by the end of the originally specified time period or within an additional two-month period of time thereafter. The notional amounts of foreign currency exchange forward contracts outstanding related to forecasted inventory purchases were $138.5 million as of June 30, 2021 and $164.5 million as of March 31, 2021. The Company had $3.7 million of net losses related to its cash flow hedges included in accumulated other comprehensive loss as of June 30, 2021, which will be reclassified into earnings within the next 12 months.

[0001032975-21-000034:notes:74]
[same as prior period, unchanged from 0001032975-21-000009:notes:75]

[0001032975-21-000034:notes:75]
The Company also enters into foreign currency exchange forward and swap contracts to reduce the short-term effects of currency exchange rate fluctuations on certain receivables or payables denominated in currencies other than the functional currencies of its subsidiaries. These contracts generally mature within one month. The primary risk managed by using forward and swap contracts is the currency exchange rate risk. The gains or losses on these contracts are recognized in other income, net in the condensed consolidated statements of operations based on the changes in fair value. The notional amounts of these contracts outstanding as of June 30, 2021 and March 31, 2021 were $240.2 million and $123.8 million, respectively. Open forward and swap contracts outstanding as of June 30, 2021 and March 31, 2021 consisted of contracts in Mexican Pesos, Japanese Yen, Canadian Dollars, Taiwanese Dollars, and Australian Dollars to be settled at future dates at pre-determined exchange rates. Open forward and swap contracts outstanding as of June 30, 2021 additionally consisted of contracts in Chinese Renminbi and Brazilian Real to be settled at future dates at pre-determined exchange rates, which were primarily attributable to the increase in the notional amounts outstanding as of June 30, 2021 compared to March 31, 2021.

[0001032975-21-000034:notes:76]
[same as prior period, unchanged from 0001032975-21-000009:notes:77]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001032975-21-000034:notes:77]
Goodwill and Other Intangible Assets
The Company conducts its impairment analysis of goodwill annually at December 31 and as necessary, if changes in facts and circumstances indicate that it is more likely than not that the fair value of the Company’s reporting unit may be less than its carrying amount. There have been no events or circumstances during the three months ended June 30, 2021 that have required the Company to perform an interim assessment of goodwill.

[0001032975-21-000034:notes:78]
The following table summarizes the activities in the Company’s goodwill balance during the three months ended June 30, 2021 (in thousands):

[0001032975-21-000034:notes:79]
| As of March 31, 2021 |  | $ | 429,604 |  |
| Acquisition |  | 20,721 |  |
| Currency translation |  | (593) |  |
| As of June 30, 2021 |  | $ | 449,732 |  |

[0001032975-21-000034:notes:80]
On May 19, 2021, the Company made an immaterial technology acquisition for a total cash consideration of $25.6 million, including up to $10.0 million earn-out payable in cash upon the achievement of three technical development milestones required to be completed for periods ending December 31, 2021, June 30, 2022, and June 30, 2023, which was accounted for using the acquisition method. The Company retained 6% of the total consideration for the purpose of ensuring seller's representations and warranties.

[0001032975-21-000034:notes:81]
[same as prior period, unchanged from 0001032975-21-000009:notes:81]

[0001032975-21-000034:notes:82]
|  |  | June 30, 2021 |  | March 31, 2021 |
|  |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |
| Trademark and trade names |  | $ | 46,167 |  |  | $ | (26,741) |  |  | $ | 19,426 |  |  | $ | 46,070 |  |  | $ | (25,153) |  |  | $ | 20,917 |  |
| Developed technology |  | 140,231 |  |  | (94,517) |  |  | 45,714 |  |  | 134,406 |  |  | (90,450) |  |  | 43,956 |  |
| Customer contracts/relationships |  | 91,012 |  |  | (47,449) |  |  | 43,563 |  |  | 91,010 |  |  | (44,261) |  |  | 46,749 |  |
| In-process R&D |  | 3,526 |  |  | — |  |  | 3,526 |  |  | 3,526 |  |  | — |  |  | 3,526 |  |
| Total |  | $ | 280,936 |  |  | $ | (168,707) |  |  | $ | 112,229 |  |  | $ | 275,012 |  |  | $ | (159,864) |  |  | $ | 115,148 |  |


## us-gaap:DebtDisclosureTextBlock

[0001032975-21-000034:notes:83]
Financing Arrangements

[0001032975-21-000034:notes:84]
The Company had several uncommitted, unsecured bank lines of credit aggregating $191.6 million as of June 30, 2021. There are no financial covenants under these lines of credit with which the Company must comply. 
As of June 30, 2021, the Company had outstanding bank guarantees of $24.7 million under these lines of credit. There was no borrowing outstanding under these lines of credit as of June 30, 2021 or March 31, 2021.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001032975-21-000034:notes:85]
Commitments and Contingencies

[0001032975-21-000034:notes:86]
Product Warranties

[0001032975-21-000034:notes:87]
Changes in the Company’s warranty liability for the three months ended June 30, 2021 and 2020 were as follows (in thousands):

[0001032975-21-000034:notes:88]
|  | Three Months EndedJune 30, |  |  |  |
|  | 2021 |  | 2020 |  |  |  |  |  |  |  |
| Beginning of the period | $ | 48,832 |  |  | $ | 40,039 |  |  |  |  |  |  |  |  |
| Provision | 8,446 |  |  | 5,389 |  |  |  |  |  |  |  |  |
| Settlements | (8,315) |  |  | (6,161) |  |  |  |  |  |  |  |  |
| Currency translation | 130 |  |  | 183 |  |  |  |  |  |  |  |  |
| End of the period | $ | 49,093 |  |  | $ | 39,450 |  |  |  |  |  |  |  |  |

[0001032975-21-000034:notes:89]
Indemnifications

[0001032975-21-000034:notes:90]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of June 30, 2021, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

[0001032975-21-000034:notes:91]
The Company also indemnifies its current and former directors and certain of its current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. The Company is unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not limited, the obligations are conditional in nature and the facts and circumstances involved in any situation that might arise are variable.

[0001032975-21-000034:notes:92]
Legal Proceedings

[0001032975-21-000034:notes:93]
From time to time the Company is involved in claims and legal proceedings which arise in the ordinary course of its business. The Company is currently subject to several such claims and a small number of legal proceedings. The Company believes that these matters lack merit and intends to vigorously defend against them. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial position, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company's defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company's business, financial position, cash flows or results of operations in a particular period. Any claims or proceedings against the Company, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain a necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company's business.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001032975-21-000034:notes:94]
[same as prior period, unchanged from 0001032975-21-000009:notes:95]

[0001032975-21-000034:notes:95]
In March 2017, the Company's Board of Directors approved the 2017 share repurchase program, which authorized the Company to use up to $250.0 million to purchase up to 17.3 million shares of Logitech shares. This share repurchase program expired in April 2020.

[0001032975-21-000034:notes:96]
In May 2020, the Company's Board of Directors approved the 2020 share repurchase program, which authorized the Company to use up to $250.0 million to purchase up to 17.3 million of Logitech shares. The

[0001032975-21-000034:notes:97]
Company's share repurchase program is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Purchases may be started or stopped at any time without prior notice depending on market conditions and other factors. In April 2021, the Company's Board of Directors approved an increase of $750.0 million of the 2020 share repurchase program, to an aggregate amount of $1.0 billion. The Swiss Takeover Board approved this increase and it became effective on May 21, 2021. As of June 30, 2021, $780.4 million is still available for repurchase under the 2020 repurchase program.

[0001032975-21-000034:notes:98]
[same as prior period, unchanged from 0001032975-21-000009:notes:103]

[0001032975-21-000034:notes:99]
[same as prior period, unchanged from 0001032975-21-000009:notes:104]

[0001032975-21-000034:notes:100]
|  |  | Accumulated Other Comprehensive Income (Loss) |
|  |  | CumulativeTranslationAdjustment |  | DefinedBenefitPlan |  | Deferred Hedging Losses |  | Total |
| March 31, 2021 |  | $ | (89,461) |  |  | $ | (23,200) |  |  | $ | 3,746 |  |  | $ | (108,915) |  |
| Other comprehensive income (loss) |  | 1,850 |  |  | (289) |  |  | (64) |  |  | 1,497 |  |
| June 30, 2021 |  | $ | (87,611) |  |  | $ | (23,489) |  |  | $ | 3,682 |  |  | $ | (107,418) |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001032975-21-000034:notes:101]
[same as prior period, unchanged from 0001032975-21-000009:notes:106]

[0001032975-21-000034:notes:102]
The Company operates in a single operating segment that encompasses the design, manufacturing and marketing of peripherals for PCs, tablets and other digital platforms. Operating performance measures are provided directly to the Company's CEO, who is considered to be the Company’s Chief Operating Decision Maker. The CEO periodically reviews information such as sales and adjusted operating income (loss) to make business decisions. These operating performance measures do not include restructuring charges (credits), net, share-based compensation expense, amortization of intangible assets, charges from the purchase accounting effect on inventory, acquisition-related costs, or change in fair value of contingent consideration from business acquisition.

[0001032975-21-000034:notes:103]
Sales by product categories and sales channels, excluding intercompany transactions, for the three months ended June 30, 2021 and 2020 were as follows (in thousands):

[0001032975-21-000034:notes:104]
|  |  | Three Months EndedJune 30, |  |  |
|  |  | 2021 |  | 2020 |  |  |  |  |
| Pointing Devices |  | $ | 182,878 |  |  | $ | 120,469 |  |  |  |  |  |
| Keyboards & Combos |  | 218,357 |  |  | 145,360 |  |  |  |  |  |
| PC Webcams |  | 109,918 |  |  | 60,851 |  |  |  |  |  |
| Tablet & Other Accessories |  | 79,272 |  |  | 46,048 |  |  |  |  |  |
| Gaming (1) |  | 335,397 |  |  | 181,903 |  |  |  |  |  |
| Video Collaboration |  | 234,885 |  |  | 130,074 |  |  |  |  |  |
| Mobile Speakers |  | 28,484 |  |  | 29,009 |  |  |  |  |  |
| Audio & Wearables |  | 116,607 |  |  | 71,365 |  |  |  |  |  |
| Smart Home |  | 6,172 |  |  | 6,810 |  |  |  |  |  |
| Other (2) |  | 88 |  |  | 5 |  |  |  |  |  |
| Total Sales |  | $ | 1,312,058 |  |  | $ | 791,894 |  |  |  |  |  |

[0001032975-21-000034:notes:105]
[same as prior period, unchanged from 0001032975-21-000009:notes:110]

[0001032975-21-000034:notes:106]
[same as prior period, unchanged from 0001032975-21-000009:notes:111]

[0001032975-21-000034:notes:107]
Sales by geographic region (based on the customers’ locations) for the three months ended June 30, 2021 and 2020 were as follows (in thousands):

[0001032975-21-000034:notes:108]
|  |  | Three Months EndedJune 30, |  |  |
|  |  | 2021 |  | 2020 |  |  |  |  |
| Americas |  | $ | 612,566 |  |  | $ | 356,184 |  |  |  |  |  |
| EMEA |  | 357,957 |  |  | 210,771 |  |  |  |  |  |
| Asia Pacific |  | 341,535 |  |  | 224,939 |  |  |  |  |  |
| Total sales |  | $ | 1,312,058 |  |  | $ | 791,894 |  |  |  |  |  |

[0001032975-21-000034:notes:109]
[same as prior period, unchanged from 0001032975-21-000009:notes:114]

[0001032975-21-000034:notes:110]
The United States, Germany and China each represented 10% or more of the total consolidated sales for each of the periods presented herein. No other countries represented 10% or more of the Company’s total consolidated sales for the periods presented herein.

[0001032975-21-000034:notes:111]
Switzerland, the Company’s home domicile, represented 3% of the Company's total consolidated sales for the three months ended June 30, 2021 and represented 2% of the Company's total consolidated sales for the three months ended June 30, 2020.

[0001032975-21-000034:notes:112]
[same as prior period, unchanged from 0001032975-21-000009:notes:117]

[0001032975-21-000034:notes:113]
[same as prior period, unchanged from 0001032975-21-000009:notes:118]

[0001032975-21-000034:notes:114]
|  |  | June 30, 2021 |  | March 31, 2021 |
| Americas |  | $ | 20,068 |  |  | $ | 20,810 |  |
| EMEA |  | 9,205 |  |  | 8,019 |  |
| Asia Pacific |  | 85,420 |  |  | 85,231 |  |
| Total property, plant and equipment, net |  | $ | 114,693 |  |  | $ | 114,060 |  |

[0001032975-21-000034:notes:115]
Property, plant and equipment, net in the United States and China were $19.7 million and $73.1 million, respectively, as of June 30, 2021, and $20.5 million and $74.0 million, respectively, as of March 31, 2021. No other countries represented 10% or more of the Company’s total consolidated property, plant and equipment, net as of June 30, 2021 or March 31, 2021. Property, plant and equipment, net in Switzerland, the Company’s home domicile, were $6.8 million and $5.7 million as of June 30, 2021 and March 31, 2021, respectively.
