# LOGI 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: 6 candidate headings, none whose body matches 'critical audit matter'.


## item_9a

[0001032975-16-000083:item_9a:1]
ITEM 9A.    CONTROLS AND PROCEDURES

[0001032975-16-000083:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0001032975-16-000083:item_9a:3]
The Company conducted an evaluation of the effectiveness of the design and operation of its disclosure controls and procedures (as defined in Rules 13a-15(e) and 15d-15(e) under the Securities Exchange Act of 1934,

[0001032975-16-000083:item_9a:4]
Logitech International S.A. | Fiscal 2016 Form 10-K | 60

[0001032975-16-000083:item_9a:5]
as amended (the “Exchange Act”)) (“Disclosure Controls”) as of the end of the period covered by this Annual Report on Form 10-K (this “Report”) required by Exchange Act Rules 13a-15(b) or 15d-15(b). The controls evaluation was conducted under the supervision and with the participation of the Company’s management, including the Company’s Chief Executive Officer (“CEO”) and Chief Financial Officer (“CFO”). Based on this evaluation, the CEO and CFO have concluded that as of the end of the period covered by this Report the Company’s Disclosure Controls were effective at a reasonable assurance level.

[0001032975-16-000083:item_9a:6]
Attached as exhibits to this Report are certifications of the CEO and CFO, which are required in accordance with Rule 13a-14 of the Exchange Act. This Controls and Procedures section includes the information concerning the controls evaluation referred to in the certifications, and it should be read in conjunction with the certifications for a more complete understanding of the topics presented.

[0001032975-16-000083:item_9a:7]
Definition of Disclosure Controls

[0001032975-16-000083:item_9a:8]
Disclosure Controls are controls and procedures designed to reasonably assure that information required to be disclosed in the Company’s reports filed under the Exchange Act, such as this Report, is recorded, processed, summarized and reported within the time periods specified in the SEC’s rules and forms. Disclosure Controls are also designed to reasonably assure that such information is accumulated and communicated to the Company’s management, including the CEO and CFO, as appropriate to allow timely decisions regarding required disclosure. The Company’s Disclosure Controls include components of its internal control over financial reporting, which consists of control processes designed to provide reasonable assurance regarding the reliability of its financial reporting and the preparation of financial statements in accordance with generally accepted accounting principles in the United States. To the extent that components of the Company’s internal control over financial reporting are included within its Disclosure Controls, they are included in the scope of the Company’s annual controls evaluation.

[0001032975-16-000083:item_9a:9]
Management's Report on Internal Control over Financial Reporting

[0001032975-16-000083:item_9a:10]
The Company’s management is responsible for establishing and maintaining adequate internal control over financial reporting as defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act. Under the supervision and with the participation of the Company’s management, including the CEO and CFO, the Company conducted an evaluation of the effectiveness of its internal control over financial reporting based on criteria established in the framework in Internal Control—Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission. Based on this evaluation, the Company’s management concluded that the Company’s internal control over financial reporting was effective as of March 31, 2016.

[0001032975-16-000083:item_9a:11]
The effectiveness of the Company’s internal control over financial reporting as of March 31, 2016 has been audited by KPMG LLP, an independent registered public accounting firm, as stated in their report which appears in Item 8, “Financial Statements and Supplementary Data” in this Annual Report on Form 10-K.

[0001032975-16-000083:item_9a:12]
Changes in Internal Controls over Financial Reporting:

[0001032975-16-000083:item_9a:13]
There were no changes in the Company’s internal control over financial reporting that occurred during the fourth quarter of fiscal year 2016 that have materially affected, or are reasonably likely to materially affect, the Company’s internal control over financial reporting.

[0001032975-16-000083:item_9a:14]
Limitations on the Effectiveness of Controls

[0001032975-16-000083:item_9a:15]
The Company's management, including the Chief Executive Officer and Chief Financial Officer, does not expect that the Company's disclosure controls and procedures or internal control over financial reporting will prevent all errors and all fraud. Internal control over financial reporting, no matter how well designed and operated, can provide only reasonable, not absolute, assurance that the objectives will be met. Because of the inherent limitations in internal control over financial reporting, no evaluation of controls can provide absolute assurance that all control issues and instances of fraud, if any, within the Company have been detected. These inherent limitations include the realities that judgments in decision making can be faulty and that breakdowns can occur because of simple error or mistake. Controls can also be circumvented by the individual acts of some persons, by collusion of two or more people, or by management override of the controls. The design of any system of controls is based in part on certain assumptions about the likelihood of future events, and there can be no assurance that any design will succeed in achieving its stated goals under all potential future conditions. Over time, controls may become inadequate because of changes in conditions or deterioration in the degree of compliance with policies or

[0001032975-16-000083:item_9a:16]
Logitech International S.A. | Fiscal 2016 Form 10-K | 61

[0001032975-16-000083:item_9a:17]
procedures. Because of the inherent limitations in a cost-effective control system, misstatements due to error or fraud may occur and not be detected.
