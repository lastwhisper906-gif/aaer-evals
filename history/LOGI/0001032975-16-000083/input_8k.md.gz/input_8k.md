# LOGI 8-K — 0001032975-16-000077 filed 2016-04-28

## item codes, every 8-K on or before 2016-05-23

- 2016-04-28 0001032975-16-000077 — 2.02, 9.01
- 2016-04-14 0001032975-16-000073 — 1.01, 7.01, 9.01
- 2016-01-21 0001032975-16-000064 — 2.02, 9.01
- 2016-01-04 0001032975-16-000061 — 1.01, 2.01, 9.01
- 2015-12-23 0001032975-15-000059 — 5.02
- 2015-10-22 0001032975-15-000047 — 2.02, 9.01
- 2015-09-11 0001032975-15-000044 — 5.07, 8.01
- 2015-07-24 0001032975-15-000034 — 2.05 — amendment of 0001032975-15-000030
- 2015-07-23 0001032975-15-000030 — 2.02, 9.01
- 2015-06-25 0001032975-15-000025 — 5.02
- 2015-05-14 0001032975-15-000011 — 8.01, 9.01
- 2015-04-23 0001032975-15-000008 — 2.02, 2.05
- 2015-01-22 0001628280-15-000191 — 2.02, 8.01
- 2014-12-23 0001193125-14-450908 — 5.02, 5.07, 8.01
- 2014-11-25 0001193125-14-425233 — 3.01
- 2014-11-13 0001193125-14-411303 — 4.01, 9.01
- 2014-10-23 0001104659-14-073164 — 2.02, 9.01
- 2014-09-04 0001193125-14-331214 — 4.02, 9.01
- 2014-08-18 0001193125-14-313346 — 3.01, 9.01
- 2014-07-24 0001104659-14-053065 — 2.02, 9.01
- 2014-06-05 0001193125-14-226177 — 3.01, 9.01
- 2014-05-22 0001193125-14-208777 — 8.01, 9.01
- 2014-04-24 0001104659-14-029650 — 2.02, 9.01
- 2014-01-23 0001104659-14-003619 — 2.02, 9.01
- 2013-10-24 0001104659-13-077404 — 2.02, 9.01
- 2013-09-09 0001193125-13-361441 — 5.02, 5.07, 8.01, 9.01
- 2013-09-06 0001193125-13-359930 — 5.02, 9.01
- 2013-08-02 0001193125-13-317343 — 5.02
- 2013-07-25 0001104659-13-056372 — 2.02, 9.01
- 2013-06-28 0001193125-13-277394 — 5.02, 9.01
- 2013-06-20 0001193125-13-265914 — 8.01, 9.01
- 2013-04-25 0001104659-13-032570 — 2.02, 9.01
- 2013-04-17 0001193125-13-158923 — 5.02, 9.01
- 2013-03-01 0001193125-13-085804 — 2.05
- 2013-01-24 0001104659-13-004214 — 2.02, 9.01
- 2013-01-02 0001193125-13-000058 — 5.02
- 2012-10-25 0001104659-12-070966 — 2.02, 9.01
- 2012-09-11 0001193125-12-388070 — 5.02, 5.07, 8.01, 9.01
- 2012-08-22 0001193125-12-364167 — 5.02, 8.01, 9.01
- 2012-07-26 0001104659-12-051084 — 2.02, 9.01
- 2012-06-08 0001193125-12-264132 — 2.05, 9.01 — amendment, the index does not say of what
- 2012-04-26 0001193125-12-183657 — 5.02, 9.01
- 2012-04-26 0001104659-12-028470 — 2.02, 2.05, 9.01
- 2012-03-15 0001193125-12-115954 — 5.02, 9.01
- 2012-01-26 0001104659-12-004014 — 2.02, 9.01
- 2012-01-04 0001193125-12-002212 — 1.01, 2.03, 9.01
- 2011-10-27 0001104659-11-058150 — 2.02, 9.01
- 2011-09-12 0001193125-11-245931 — 5.07
- 2011-07-28 0001193125-11-200929 — 5.02, 9.01
- 2011-07-28 0001193125-11-199704 — 2.02, 9.01
- 2011-04-28 0001193125-11-112669 — 2.02, 9.01
- 2011-03-24 0001193125-11-076483 — 5.02, 9.01
- 2011-01-27 0001032975-11-000003 — 9.01
- 2010-10-28 0001032975-10-000032 — 9.01
- 2010-09-13 0001032975-10-000022 — 5.07
- 2010-07-29 0001032975-10-000010 — 2.02, 9.01
- 2010-06-10 0001193125-10-136877 — 5.02, 9.01
- 2010-05-03 0001193125-10-104337 — 5.02
- 2010-04-29 0001032975-10-000008 — 2.02, 9.01
- 2010-02-19 0001032975-10-000006 — 9.01 — amendment of 0001193125-09-252416
- 2010-01-21 0001032975-10-000002 — 2.02, 9.01
- 2009-12-14 0001193125-09-252416 — 2.01, 9.01
- 2009-11-17 0001032975-09-000023 — 1.01
- 2009-10-22 0001032975-09-000018 — 9.01
- 2009-09-22 0001193125-09-195545 — 5.02, 9.01
- 2009-09-03 0001032975-09-000013 — 8.01
- 2009-07-23 0001140361-09-016802 — 2.02, 9.01
- 2009-06-01 0001193125-09-122550 — 5.02
- 2009-04-23 0001193125-09-085054 — 2.02, 9.01
- 2009-04-02 0001193125-09-071272 — 5.02, 9.01
- 2009-01-20 0001193125-09-008454 — 2.05 — amendment of 0001193125-09-002609
- 2009-01-20 0001193125-09-007902 — 2.02, 9.01
- 2009-01-07 0001193125-09-002609 — 2.05, 9.01
- 2009-01-07 0001193125-09-002370 — 5.02, 9.01
- 2008-12-09 0001193125-08-250543 — 5.02, 9.01
- 2008-10-21 0001193125-08-213212 — 2.02, 9.01
- 2008-07-22 0001193125-08-154721 — 2.02, 9.01
- 2008-06-24 0001193125-08-139163 — 5.03, 9.01
- 2008-05-13 0001193125-08-113263 — 5.02, 9.01
- 2008-04-22 0001193125-08-086176 — 2.02, 9.01

## late-filing notifications on or before 2016-05-23

- 2015-06-02 0001032975-15-000020 — NT 10-K, for the period ended 2015-03-31
- 2014-11-06 0001193125-14-401306 — NT 10-Q, for the period ended 2014-09-30
- 2014-07-24 0001193125-14-277575 — NT 10-Q, for the period ended 2014-06-30
- 2014-05-22 0001193125-14-208712 — NT 10-K, for the period ended 2014-03-31
- 2009-08-06 0001032975-09-000006 — NT 10-Q, for the period ended 2009-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001032975-16-000077:8k_2_02:1]
EX-99.1
2
exhibit991q4fy16.htm
EXHIBIT 99.1

[0001032975-16-000077:8k_2_02:2]
Exhibit

[0001032975-16-000077:8k_2_02:3]
Exhibit 99.1

[0001032975-16-000077:8k_2_02:4]
Editorial Contacts:

[0001032975-16-000077:8k_2_02:5]
Joe Greenhalgh, Vice President, Investor Relations - USA (510) 713-4430

[0001032975-16-000077:8k_2_02:6]
Krista Todd, Vice President, External Communications - USA (510) 713-5834

[0001032975-16-000077:8k_2_02:7]
Ben Starkie, Corporate Communications - Europe +41-(0) 79-292-3499

[0001032975-16-000077:8k_2_02:8]
Logitech Delivers Best Annual Retail Sales Growth in Five Years

[0001032975-16-000077:8k_2_02:9]
FY 2016 Retail Sales Grow 9 Percent in Constant Currency and

[0001032975-16-000077:8k_2_02:10]
Profitability Beats Expectations; FY 2017 Outlook Confirmed

[0001032975-16-000077:8k_2_02:11]
NEWARK, Calif. - April 27, 2016 and LAUSANNE, Switzerland, April 28, 2016 - Logitech International (SIX: LOGN) (Nasdaq: LOGI) today announced financial results for the fourth quarter and full year of Fiscal Year 2016.

[0001032975-16-000077:8k_2_02:12]
Q4 closed a strong fiscal year with sales for the quarter reaching $431 million. Q4 retail sales (total sales excluding OEM and Lifesize) grew 6 percent in constant currency, GAAP operating income was $10 million and non-GAAP operating income was $22 million.

[0001032975-16-000077:8k_2_02:13]
For the full Fiscal Year 2016, ended March 31, 2016:

[0001032975-16-000077:8k_2_02:14]
| • | Sales were $2.02 billion, up 1 percent compared to the previous fiscal year. Full-year retail sales were $1.95 billion and grew 9 percent in constant currency. |

[0001032975-16-000077:8k_2_02:15]
| • | GAAP operating income was $129 million, with GAAP earnings per share (EPS) of $0.77, compared to $0.89 a year ago. |

[0001032975-16-000077:8k_2_02:16]
| • | Non-GAAP operating income was $179 million, with non-GAAP EPS of $0.98, down from $1.10 a year ago. |

[0001032975-16-000077:8k_2_02:17]
| • | Cash flow from operations was $183 million, and the Company returned $156 million to shareholders in the form of dividends and share repurchases. |

[0001032975-16-000077:8k_2_02:18]
“In FY 2016, we delivered our best annual retail sales growth in five years and better-than-expected profitability,” said Bracken Darrell, Logitech president and chief executive officer. “Sales in our Gaming category grew 23 percent, Mobile Speakers grew 37 percent and Video Collaboration grew 51 percent, all in constant currency. Together, our Mice and Keyboard categories also grew 6 percent in constant currency. This demonstrates our ability to innovate across a diverse portfolio - strong innovation that, when combined with disciplined cost management, drives profitable growth.

[0001032975-16-000077:8k_2_02:19]
“Looking forward to Fiscal Year 2017, we now have a strong foundation upon which to build. We will continue to develop our balanced portfolio of businesses and brands to address a number of big and growing markets - Gaming, Home, Music, Video Collaboration and Creativity & Productivity. We look

[0001032975-16-000077:8k_2_02:20]
forward to delivering another year of fantastic new products and are optimistic for the solid growth and profitability they will generate.”

[0001032975-16-000077:8k_2_02:21]
Outlook

[0001032975-16-000077:8k_2_02:22]
Logitech confirmed its FY 2017 outlook of $185 million to $200 million in non-GAAP operating income and constant currency retail sales growth in the mid-single digits.

[0001032975-16-000077:8k_2_02:23]
Prepared Remarks Available Online

[0001032975-16-000077:8k_2_02:24]
Logitech has made its prepared written remarks for the financial results teleconference available online on the Logitech corporate website at http://ir.logitech.com.

[0001032975-16-000077:8k_2_02:25]
Financial Results Teleconference and Webcast

[0001032975-16-000077:8k_2_02:26]
Logitech will hold a financial results teleconference to discuss the results for Q4 and full-year FY 2016 on Thurs., April 28, 2016 at 8:30 a.m. Eastern Daylight Time and 2:30 p.m. Central European Summer Time. A live webcast of the call will be available on the Logitech corporate website at http://ir.logitech.com.

[0001032975-16-000077:8k_2_02:27]
Continued Operations

[0001032975-16-000077:8k_2_02:28]
Logitech separated its Lifesize division from the Company on Dec. 28, 2015. Except as otherwise noted, all of the results reported in this press release as well as comparisons between periods are focused on results from continuing operations and do not address the performance of Lifesize, which is now reported in the Company’s financial statements under discontinued operations or total Logitech including discontinued operations. For more information on the impact of the Lifesize separation on Logitech’s historical results, please refer to the Financial Reporting section of Logitech’s Financial History, available on the Logitech corporate website at http://ir.logitech.com.

[0001032975-16-000077:8k_2_02:29]
Use of Non-GAAP Financial Information

[0001032975-16-000077:8k_2_02:30]
To facilitate comparisons to Logitech’s historical results, Logitech has included non-GAAP adjusted measures, which exclude share-based compensation expense, amortization of other intangible assets, restructuring charges (credits), investment impairment (recovery), benefit from (provision for) income taxes, one-time special charges and other items detailed under “Supplemental Financial Information” after the tables below. Logitech also presents percentage sales growth in constant currency, a non-GAAP measure, to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales. Logitech believes this information, used together with the GAAP financial information, will help investors to evaluate its current period performance and trends in its business. With respect to the Company’s outlook for non-GAAP operating income, most of these excluded amounts pertain to events that have not yet occurred and are not currently possible to estimate with a reasonable degree of accuracy. Therefore, no reconciliation to the GAAP amounts has been provided for Fiscal Year 2017.

[0001032975-16-000077:8k_2_02:31]
About Logitech

[0001032975-16-000077:8k_2_02:32]
Logitech designs products that have an everyday place in people's lives, connecting them to the digital experiences they care about. Over 30 years ago Logitech started connecting people through computers, and now it’s designing products that bring people together through music, gaming, video and computing. Founded in 1981, Logitech International is a Swiss public company listed on the SIX Swiss Exchange (LOGN) and on the Nasdaq Global Select Market (LOGI). Find Logitech at www.logitech.com, the company blog or @Logitech.

[0001032975-16-000077:8k_2_02:33]
# # #

[0001032975-16-000077:8k_2_02:34]
Note that unless noted otherwise, comparisons are year over year.

[0001032975-16-000077:8k_2_02:35]
2016 Logitech, Logicool, Logi and other Logitech marks are owned by Logitech and may be registered. All other trademarks are the property of their respective owners. For more information about Logitech and its products, visit the company’s website at www.logitech.com.

[0001032975-16-000077:8k_2_02:36]
(LOGIIR)

[0001032975-16-000077:8k_2_02:37]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| (In thousands, except per share amounts) - Unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  | Fiscal Years Ended |
|  |  | March 31 |  | March 31 |
| GAAP CONSOLIDATED STATEMENTS OF OPERATIONS |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Net sales |  | $ | 430,841 |  |  | $ | 442,283 |  |  | $ | 2,018,100 |  |  | $ | 2,004,908 |  |
| Cost of goods sold |  | 288,741 |  |  | 300,609 |  |  | 1,337,053 |  |  | 1,299,451 |  |
| Gross profit |  | 142,100 |  |  | 141,674 |  |  | 681,047 |  |  | 705,457 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Marketing and selling |  | 77,091 |  |  | 75,646 |  |  | 319,015 |  |  | 321,749 |  |
| Research and development |  | 27,288 |  |  | 28,297 |  |  | 113,624 |  |  | 108,306 |  |
| General and administrative |  | 23,582 |  |  | 29,233 |  |  | 101,548 |  |  | 125,995 |  |
| Restructuring charges (credits), net |  | 3,784 |  |  | (4,742 | ) |  | 17,802 |  |  | (4,777 | ) |
| Total operating expenses |  | 131,745 |  |  | 128,434 |  |  | 551,989 |  |  | 551,273 |  |
| Operating income |  | 10,355 |  |  | 13,240 |  |  | 129,058 |  |  | 154,184 |  |
| Interest income, net |  | 241 |  |  | 373 |  |  | 790 |  |  | 1,197 |  |
| Other income (expense), net |  | 2,518 |  |  | 1,404 |  |  | 1,624 |  |  | (2,298 | ) |
| Income from continuing operations before income taxes |  | 13,114 |  |  | 15,017 |  |  | 131,472 |  |  | 153,083 |  |
| Provision for (benefit from) income taxes |  | (3,896 | ) |  | (3,801 | ) |  | 3,110 |  |  | 4,654 |  |
| Net income from continuing operations |  | 17,010 |  |  | 18,818 |  |  | 128,362 |  |  | 148,429 |  |
| Gain (loss) from discontinued operations, net of taxes |  | 11,687 |  |  | (128,085 | ) |  | (9,045 | ) |  | (139,146 | ) |
| Net income (loss) |  | $ | 28,697 |  |  | $ | (109,267 | ) |  | $ | 119,317 |  |  | $ | 9,283 |  |
| Net income (loss) per share - basic: |  |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.10 |  |  | $ | 0.11 |  |  | $ | 0.79 |  |  | $ | 0.91 |  |
| Discontinued operations |  | $ | 0.08 |  |  | $ | (0.77 | ) |  | $ | (0.06 | ) |  | $ | (0.85 | ) |
| Net income (loss) per share - basic |  | $ | 0.18 |  |  | $ | (0.66 | ) |  | $ | 0.73 |  |  | $ | 0.06 |  |
| Net income (loss) per share - diluted: |  |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.10 |  |  | $ | 0.11 |  |  | $ | 0.77 |  |  | $ | 0.89 |  |
| Discontinued operations |  | $ | 0.07 |  |  | $ | (0.77 | ) |  | $ | (0.05 | ) |  | $ | (0.83 | ) |
| Net income (loss) per share - diluted |  | $ | 0.17 |  |  | $ | (0.66 | ) |  | $ | 0.72 |  |  | $ | 0.06 |  |
| Weighted average shares used to compute net income (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | 162,671 |  |  | 164,319 |  |  | 163,296 |  |  | 163,536 |  |
| Diluted |  | 165,365 |  |  | 166,424 |  |  | 165,792 |  |  | 166,174 |  |
| Cash dividends per share |  | $ | — |  |  | $ | — |  |  | $ | 0.53 |  |  | $ | 0.27 |  |

[0001032975-16-000077:8k_2_02:38]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |
| (In thousands) - Unaudited |  |  |  |  |
|  |  | March 31 |  | March 31 |
| CONSOLIDATED BALANCE SHEETS |  | 2016 |  | 2015 |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 519,195 |  |  | $ | 533,380 |  |
| Accounts receivable, net |  | 142,778 |  |  | 167,196 |  |
| Inventories |  | 228,786 |  |  | 255,980 |  |
| Other current assets |  | 35,488 |  |  | 63,362 |  |
| Current assets of discontinued operations |  | — |  |  | 32,102 |  |
| Total current assets |  | 926,247 |  |  | 1,052,020 |  |
| Non-current assets: |  |  |  |  |
| Property, plant and equipment, net |  | 92,860 |  |  | 86,478 |  |
| Goodwill |  | 218,224 |  |  | 218,213 |  |
| Other assets |  | 86,816 |  |  | 62,333 |  |
| Long-term assets of discontinued operations |  | — |  |  | 7,636 |  |
| Total assets |  | $ | 1,324,147 |  |  | $ | 1,426,680 |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 241,166 |  |  | $ | 292,797 |  |
| Accrued and other current liabilities |  | 173,764 |  |  | 163,344 |  |
| Current liabilities of discontinued operations |  | — |  |  | 38,766 |  |
| Total current liabilities |  | 414,930 |  |  | 494,907 |  |
| Non-current liabilities: |  |  |  |  |  |  |
| Income taxes payable |  | 59,734 |  |  | 72,107 |  |
| Other non-current liabilities |  | 89,535 |  |  | 91,195 |  |
| Long-term liabilities of discontinued operations |  | — |  |  | 10,337 |  |
| Total liabilities |  | 564,199 |  |  | 668,546 |  |
| Shareholders' equity: |  |  |  |  |
| Registered shares, CHF 0.25 par value: |  | 30,148 |  |  | 30,148 |  |
| Issued and authorized shares—173,106 at March 31, 2016 and 2015 |  |  |  |  |
| Conditionally authorized shares—50,000 at March 31, 2016 and 2015 |  |  |  |  |
| Additional paid-in capital |  | 6,616 |  |  | — |  |
| Less shares in treasury, at cost—10,697 at March 31, 2016 and 8,625 at March 31, 2015 |  | (128,407 | ) |  | (88,951 | ) |
| Retained earnings |  | 963,576 |  |  | 930,174 |  |
| Accumulated other comprehensive loss |  | (111,985 | ) |  | (113,237 | ) |
| Total shareholders' equity |  | 759,948 |  |  | 758,134 |  |
| Total liabilities and shareholders' equity |  | $ | 1,324,147 |  |  | $ | 1,426,680 |  |

[0001032975-16-000077:8k_2_02:39]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| (In thousands) - Unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  | Fiscal Years Ended |
|  |  | March 31 |  | March 31 |
| CONSOLIDATED STATEMENTS OF CASH FLOWS * |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Operating activities: |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | 28,697 |  |  | $ | (109,267 | ) |  | $ | 119,317 |  |  | $ | 9,283 |  |
| Adjustments to reconcile net income (loss) to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  | 14,224 |  |  | 11,745 |  |  | 51,108 |  |  | 41,304 |  |
| Amortization of other intangible assets |  | 349 |  |  | 737 |  |  | 1,885 |  |  | 8,361 |  |
| Share-based compensation expense |  | 7,476 |  |  | 5,779 |  |  | 27,351 |  |  | 25,825 |  |
| Impairment of goodwill and other assets |  | — |  |  | 122,734 |  |  | — |  |  | 122,734 |  |
| Investment impairment |  | — |  |  | 39 |  |  | — |  |  | 2,298 |  |
| Gain on equity method investments |  | (645 | ) |  | — |  |  | (469 | ) |  | — |  |
| Gain on disposal of property, plant and equipment |  | — |  |  | — |  |  | — |  |  | (44 | ) |
| Net gain on divestiture of discontinued operations |  | (13,684 | ) |  | — |  |  | (13,684 | ) |  | — |  |
| Excess tax benefits from share-based compensation |  | — |  |  | (298 | ) |  | (2,084 | ) |  | (2,831 | ) |
| Deferred income taxes |  | 3,690 |  |  | 5,391 |  |  | 6,604 |  |  | 2,240 |  |
| Changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | 141,327 |  |  | 123,008 |  |  | 25,513 |  |  | (8,018 | ) |
| Inventories |  | 13,900 |  |  | (30,339 | ) |  | 31,966 |  |  | (60,510 | ) |
| Other assets |  | 7,354 |  |  | 2,308 |  |  | (1,975 | ) |  | (4,284 | ) |
| Accounts payable |  | (126,867 | ) |  | (50,897 | ) |  | (58,104 | ) |  | 60,413 |  |
| Accrued and other liabilities |  | (43,561 | ) |  | (39,366 | ) |  | (4,317 | ) |  | (18,139 | ) |
| Net cash provided by operating activities |  | 32,260 |  |  | 41,574 |  |  | 183,111 |  |  | 178,632 |  |
| Investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  | (6,172 | ) |  | (10,476 | ) |  | (56,615 | ) |  | (45,253 | ) |
| Investment in privately held companies |  | (320 | ) |  | — |  |  | (2,419 | ) |  | (2,550 | ) |
| Payments for divestiture of discontinued operations |  | (1,395 | ) |  | — |  |  | (1,395 | ) |  | — |  |
| Acquisitions, net of cash acquired |  | — |  |  | (926 | ) |  | — |  |  | (926 | ) |
| Changes in restricted cash and cash equivalents, net |  | (715 | ) |  | — |  |  | (715 | ) |  | — |  |
| Purchase of trading investments |  | (5,224 | ) |  | (1,571 | ) |  | (9,619 | ) |  | (5,034 | ) |
| Proceeds from sales of trading investments |  | 5,405 |  |  | 1,618 |  |  | 10,073 |  |  | 5,474 |  |
| Net cash used in investing activities |  | (8,421 | ) |  | (11,355 | ) |  | (60,690 | ) |  | (48,289 | ) |
| Financing activities: |  |  |  |  |  |  |  |  |
| Payment of cash dividends |  | — |  |  | — |  |  | (85,915 | ) |  | (43,767 | ) |
| Contingent consideration related to prior acquisition |  | — |  |  | — |  |  | — |  |  | (100 | ) |
| Purchases of treasury shares |  | (21,556 | ) |  | (1,663 | ) |  | (70,358 | ) |  | (1,663 | ) |
| Repurchase of ESPP awards |  | — |  |  | — |  |  | — |  |  | (1,078 | ) |
| Proceeds from sales of shares upon exercise of options and purchase rights |  | 7,205 |  |  | 1,672 |  |  | 19,767 |  |  | 4,138 |  |
| Tax withholdings related to net share settlements of restricted stock units |  | (1,890 | ) |  | (1,759 | ) |  | (7,247 | ) |  | (9,215 | ) |
| Excess tax benefits from share-based compensation |  | — |  |  | 298 |  |  | 2,084 |  |  | 2,831 |  |
| Net cash used in financing activities |  | (16,241 | ) |  | (1,452 | ) |  | (141,669 | ) |  | (48,854 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  | 2,610 |  |  | (8,342 | ) |  | 1,405 |  |  | (13,863 | ) |
| Net increase (decrease) in cash and cash equivalents |  | 10,208 |  |  | 20,425 |  |  | (17,843 | ) |  | 67,626 |  |
| Cash and cash equivalents, beginning of the period |  | 508,987 |  |  | 516,613 |  |  | 537,038 |  |  | 469,412 |  |
| Cash and cash equivalents, end of the period |  | $ | 519,195 |  |  | $ | 537,038 |  |  | $ | 519,195 |  |  | $ | 537,038 |  |

[0001032975-16-000077:8k_2_02:40]
______________

[0001032975-16-000077:8k_2_02:41]
*Statements of consolidated cash flows include discontinued operations

[0001032975-16-000077:8k_2_02:42]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |  |  |  |  |
| (In thousands) - Unaudited |  |  |  |  |  |  |  |  |  |  |
| NET SALES |  | Three Months Ended |  | Fiscal Years Ended |
|  |  | March 31 |  | March 31 |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2016 |  | 2015 |  | Change |  | 2016 |  | 2015 |  | Change |
| Net sales by channel: |  |  |  |  |  |  |  |  |  |  |  |  |
| Retail |  | $ | 430,841 |  |  | $ | 416,144 |  |  | 4 | % |  | $ | 1,947,059 |  |  | $ | 1,887,446 |  |  | 3 | % |
| OEM |  | — |  |  | 26,139 |  |  | (100 | ) |  | 71,041 |  |  | 117,462 |  |  | (40 | ) |
| Total net sales |  | $ | 430,841 |  |  | $ | 442,283 |  |  | (3 | ) |  | $ | 2,018,100 |  |  | $ | 2,004,908 |  |  | 1 |  |
| Net retail sales by product category: |  |  |  |  |  |  |  |  |  |  |  |  |
| Mobile Speakers |  | $ | 23,543 |  |  | $ | 38,406 |  |  | (39 | ) |  | $ | 229,718 |  |  | $ | 178,038 |  |  | 29 |  |
| Gaming |  | 56,102 |  |  | 47,341 |  |  | 19 |  |  | 245,101 |  |  | 211,911 |  |  | 16 |  |
| Video Collaboration |  | 21,862 |  |  | 16,248 |  |  | 35 |  |  | 89,322 |  |  | 62,215 |  |  | 44 |  |
| Tablet & Other Accessories |  | 30,664 |  |  | 26,021 |  |  | 18 |  |  | 103,886 |  |  | 140,994 |  |  | (26 | ) |
| Pointing Devices |  | 111,179 |  |  | 104,686 |  |  | 6 |  |  | 492,543 |  |  | 487,210 |  |  | 1 |  |
| Keyboards & Combos |  | 105,732 |  |  | 100,900 |  |  | 5 |  |  | 430,190 |  |  | 426,117 |  |  | 1 |  |
| Audio-PC & Wearables |  | 46,672 |  |  | 51,015 |  |  | (9 | ) |  | 196,013 |  |  | 213,496 |  |  | (8 | ) |
| PC Webcams |  | 23,952 |  |  | 19,225 |  |  | 25 |  |  | 98,641 |  |  | 96,680 |  |  | 2 |  |
| Home Control |  | 10,527 |  |  | 11,836 |  |  | (11 | ) |  | 59,075 |  |  | 68,060 |  |  | (13 | ) |
| Other (*) |  | 608 |  |  | 466 |  |  | 30 |  |  | 2,570 |  |  | 2,725 |  |  | (6 | ) |
| Total net retail sales |  | $ | 430,841 |  |  | $ | 416,144 |  |  | 4 |  |  | $ | 1,947,059 |  |  | $ | 1,887,446 |  |  | 3 |  |
| __________________ |  |  |  |  |  |  |  |  |  |  |  |  |

[0001032975-16-000077:8k_2_02:43]
* Other category Includes products that we currently intend to transition out of, or have already transitioned out of, because they are no longer strategic to our business.

[0001032975-16-000077:8k_2_02:44]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| (In thousands, except per share amounts) - Unaudited |  |  |  |  |  |  |  |  |
| GAAP TO NON GAAP RECONCILIATION (A) |  | Three Months Ended |  | Fiscal Years Ended |
|  |  | March 31 |  | March 31 |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Gross profit - GAAP |  | $ | 142,100 |  |  | $ | 141,674 |  |  | $ | 681,047 |  |  | $ | 705,457 |  |
| Share-based compensation expense |  | 692 |  |  | 749 |  |  | 2,340 |  |  | 2,474 |  |
| Gross profit - Non-GAAP |  | $ | 142,792 |  |  | $ | 142,423 |  |  | $ | 683,387 |  |  | $ | 707,931 |  |
| Gross margin - GAAP |  | 33.0 | % |  | 32.0 | % |  | 33.7 | % |  | 35.2 | % |
| Gross margin - Non-GAAP |  | 33.1 | % |  | 32.2 | % |  | 33.9 | % |  | 35.3 | % |
| Operating expenses - GAAP |  | $ | 131,745 |  |  | $ | 128,434 |  |  | $ | 551,989 |  |  | $ | 551,273 |  |
| Less: Share-based compensation expense |  | 7,036 |  |  | 4,713 |  |  | 24,672 |  |  | 21,717 |  |
| Less: Amortization of other intangible assets |  | 1 |  |  | 166 |  |  | 448 |  |  | 763 |  |
| Less: Restructuring charges (credits), net |  | 3,784 |  |  | (4,742 | ) |  | 17,802 |  |  | (4,777 | ) |
| Less: One time special charge |  | 555 |  |  | 4,213 |  |  | 4,676 |  |  | 23,737 |  |
| Operating expenses - Non-GAAP |  | $ | 120,369 |  |  | $ | 124,084 |  |  | $ | 504,391 |  |  | $ | 509,833 |  |
| % of net sales - GAAP |  | 30.6 | % |  | 29.0 | % |  | 27.4 | % |  | 27.5 | % |
| % of net sales - Non - GAAP |  | 27.9 | % |  | 28.1 | % |  | 25.0 | % |  | 25.4 | % |
| Operating income - GAAP |  | $ | 10,355 |  |  | $ | 13,240 |  |  | $ | 129,058 |  |  | $ | 154,184 |  |
| Share-based compensation expense |  | 7,728 |  |  | 5,462 |  |  | 27,012 |  |  | 24,191 |  |
| Amortization of other intangible assets |  | 1 |  |  | 166 |  |  | 448 |  |  | 763 |  |
| Restructuring charges (credits), net |  | 3,784 |  |  | (4,742 | ) |  | 17,802 |  |  | (4,777 | ) |
| One time special charge |  | 555 |  |  | 4,213 |  |  | 4,676 |  |  | 23,737 |  |
| Operating income - Non - GAAP |  | $ | 22,423 |  |  | $ | 18,339 |  |  | $ | 178,996 |  |  | $ | 198,098 |  |
| % of net sales - GAAP |  | 2.4 | % |  | 3.0 | % |  | 6.4 | % |  | 7.7 | % |
| % of net sales - Non - GAAP |  | 5.2 | % |  | 4.1 | % |  | 8.9 | % |  | 9.9 | % |
| Net income from continuing operations - GAAP |  | $ | 17,010 |  |  | $ | 18,818 |  |  | $ | 128,362 |  |  | $ | 148,429 |  |
| Share-based compensation expense |  | 7,728 |  |  | 5,462 |  |  | 27,012 |  |  | 24,191 |  |
| Amortization of other intangible assets |  | 1 |  |  | 166 |  |  | 448 |  |  | 763 |  |
| Restructuring charges (credits), net |  | 3,784 |  |  | (4,742 | ) |  | 17,802 |  |  | (4,777 | ) |
| One time special charge |  | 555 |  |  | 4,213 |  |  | 4,676 |  |  | 23,737 |  |
| Investment impairment |  | (645 | ) |  | 39 |  |  | (469 | ) |  | 2,298 |  |
| Provision for income taxes |  | (5,452 | ) |  | (5,534 | ) |  | (15,413 | ) |  | (12,468 | ) |
| Net income from continuing operations - Non - GAAP |  | $ | 22,981 |  |  | $ | 18,422 |  |  | $ | 162,418 |  |  | $ | 182,173 |  |
| Net income from continuing operations per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  | $ | 0.10 |  |  | $ | 0.11 |  |  | $ | 0.77 |  |  | $ | 0.89 |  |
| Diluted - Non - GAAP |  | $ | 0.14 |  |  | $ | 0.11 |  |  | $ | 0.98 |  |  | $ | 1.10 |  |
| Shares used to compute net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP and Non - GAAP |  | 165,365 |  |  | 166,424 |  |  | 165,792 |  |  | 166,174 |  |

[0001032975-16-000077:8k_2_02:45]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| (In thousands) - Unaudited |  |  |  |  |  |  |  |  |
| SHARE-BASED COMPENSATION EXPENSE |  | Three Months Ended |  | Fiscal Years Ended |
|  |  | March 31 |  | March 31 |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Share-based Compensation Expense |  |  |  |  |  |  |  |  |
| Cost of goods sold |  | $ | 692 |  |  | $ | 749 |  |  | $ | 2,340 |  |  | $ | 2,474 |  |
| Marketing and selling |  | 2,728 |  |  | 1,911 |  |  | 9,273 |  |  | 8,570 |  |
| Research and Development |  | 872 |  |  | 601 |  |  | 3,046 |  |  | 2,381 |  |
| General and administrative |  | 3,436 |  |  | 2,201 |  |  | 12,353 |  |  | 10,766 |  |
| Restructuring |  | — |  |  | — |  |  | 7 |  |  | — |  |
| Income tax benefit |  | (2,354 | ) |  | (529 | ) |  | (6,297 | ) |  | (4,814 | ) |
| Total share-based compensation expense, net of income taxes |  | $ | 5,374 |  |  | $ | 4,933 |  |  | $ | 20,722 |  |  | $ | 19,377 |  |
| __________________ |  |  |  |  |  |  |  |  |

[0001032975-16-000077:8k_2_02:46]
(A) Non-GAAP Financial Measures

[0001032975-16-000077:8k_2_02:47]
To supplement our condensed consolidated financial results prepared in accordance with GAAP, we use a number of financial measures, both GAAP and non-GAAP, in analyzing and assessing our overall business performance, for making operating decisions and for forecasting and planning future periods. We consider the use of non-GAAP financial measures helpful in assessing our current financial performance, ongoing operations and prospects for the future as well as understanding financial and business trends relating to our financial condition and results of operations.

[0001032975-16-000077:8k_2_02:48]
While we use non-GAAP financial measures as a tool to enhance our understanding of certain aspects of our financial performance and to provide incremental insight into the underlying factors and trends affecting both our performance and our cash-generating potential, we do not consider these measures to be a substitute for, or superior to, the information provided by GAAP financial measures. Consistent with this approach, we believe that disclosing non-GAAP financial measures to the readers of our financial statements provides useful supplemental data that, while not a substitute for GAAP financial measures, can offer insight in the review of our financial and operational performance and enables investors to more fully understand trends in our current and future performance. In assessing our business during the quarter and year ended March 31, 2016, we excluded items in the following general categories, each of which are described below:

[0001032975-16-000077:8k_2_02:49]
Share-based compensation expenses. We believe that providing non-GAAP measures excluding share-based compensation expense, in addition to the GAAP measures, allows for a more transparent comparison of our financial results from period to period. We prepare and maintain our budgets and forecasts for future periods on a basis consistent with this non-GAAP financial measure. Further, companies use a variety of types of equity awards as well as a variety of methodologies, assumptions and estimates to determine share-based compensation expense. We believe that excluding share-based compensation expense enhances our ability and the ability of investors to understand the impact of non-cash share-based compensation on our operating results and to compare our results against the results of other companies.

[0001032975-16-000077:8k_2_02:50]
Amortization of other intangible assets. We incur intangible asset amortization expense, primarily in connection with our acquisitions of various businesses and technologies. The amortization of purchased intangibles varies depending on the level of acquisition activity. We exclude these various charges in budgeting, planning and forecasting future periods and we believe that providing the non-GAAP measures excluding these various non-cash charges, as well as the GAAP measures, provides additional insight when comparing our operating expenses and financial results from period to period.

[0001032975-16-000077:8k_2_02:51]
Restructuring charges (credits). These expenses are associated with re-aligning our business strategies based on current economic conditions. We have undertaken several restructurings in recent years. In connection with our restructuring initiatives, we incurred restructuring charges related to employee terminations, facility closures and early cancellation of certain contracts. We believe that providing the non-GAAP measures excluding these charges, as well

[0001032975-16-000077:8k_2_02:52]
as the GAAP measures, assists our investors because such charges are not reflective of our ongoing operating results in the current period.

[0001032975-16-000077:8k_2_02:53]
Investment impairment (recovery). We incur investment impairment and recovery, primarily related to our investments in various privately-held companies. The investment impairment or recovery varies depending on the operational and financial performance of the privately-held companies we invested in. We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges are not reflective of our ongoing operations.

[0001032975-16-000077:8k_2_02:54]
One-time special charges:  costs related to investigations and related expenses, and business acquisitions.  These expenses are forensic accounting, audit, consulting and legal fees related to the Audit Committee’s investigation and the formal investigation by and settlement with the Securities and Exchange Commission (SEC), together with accruals based on settlement with the SEC, and related to business acquisitions. We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges are one-time in nature and not reflective of our ongoing operations.

[0001032975-16-000077:8k_2_02:55]
Other charges. We provided non-GAAP measures excluding the effect of certain charges and income that are not reflective of our ongoing operations.

[0001032975-16-000077:8k_2_02:56]
In addition, Logitech presents percentage sales growth in constant currency, a non-GAAP measure, to show performance unaffected by fluctuations in currency exchange rates.  Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales. Sales for the three months ended March 31, 2016 compared to sales for the three months ended March 31, 2015 decreased 1 percent in constant currency and decreased 3 percent in U.S. Dollars. Retail sales for the three months ended March 31, 2016 compared to retail sales for the three months ended March 31, 2015 grew 6 percent in constant currency and grew 4 percent in U.S. Dollars. Retail sales for the year ended March 31, 2016 compared to retail sales for year ended March 31, 2015 grew 9 percent in constant currency and grew 3 percent in U.S. Dollars. Sales in our Gaming, Mobile Speakers and Video Collaboration category for the year ended March 31, 2016 compared to the sales for those categories for the year ended March 31, 2015 grew 23 percent, 37 percent and 51 percent, respectively, in constant currency and grew 16 percent, 29 percent and 44 percent, respectively, in U.S. Dollars. Sales for the combined Mice and Keyboard categories for the year ended March 31, 2016 compared to sales for those combined categories for the year ended March 31, 2015 grew 6 percent in constant currency and grew 1 percent in U.S. Dollars.

[0001032975-16-000077:8k_2_02:57]
Each of the non-GAAP financial measures described above, and used in this press release, should not be considered in isolation from, or as a substitute for, a measure of financial performance prepared in accordance with GAAP. Further, investors are cautioned that there are inherent limitations associated with the use of each of these non-GAAP financial measures as an analytical tool. In particular, these non-GAAP financial measures are not based on a comprehensive set of accounting rules or principles and many of the adjustments to the GAAP financial measures reflect the exclusion of items that are recurring and may be reflected in the Company’s financial results for the foreseeable future. We compensate for these limitations by providing specific information in the reconciliation included in this press release regarding the GAAP amounts excluded from the non-GAAP financial measures. In addition, as noted above, we evaluate the non-GAAP financial measures together with the most directly comparable GAAP financial information.
