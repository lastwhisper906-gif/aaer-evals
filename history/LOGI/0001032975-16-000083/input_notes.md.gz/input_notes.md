# LOGI notes — 0001032975-16-000083


## logi:ScheduleOfAssumptionsForSharebasedAwardsTableTextBlock

[0001032975-16-000083:notes:1]
The grant date fair value of the awards using the Black-Scholes-Merton option-pricing valuation model and Monte-Carlo simulation method are determined applying the following assumptions and values:

[0001032975-16-000083:notes:2]
| Employee Stock Purchase Plans |  | Years Ended March 31, |
|  |  | 2016 |  | 2015 |  | 2014 |
| Dividend yield |  | 3.47 | % |  | 1.97 | % |  | 0.43 | % |
| Risk-free interest rate |  | 0.29 | % |  | 0.14 | % |  | 0.07 | % |
| Expected volatility |  | 26 | % |  | 30 | % |  | 36 | % |
| Expected life (years) |  | 0.5 |  |  | 0.6 |  |  | 0.5 |  |
| Weighted average fair value |  | $ | 3.29 |  |  | $ | 3.18 |  |  | $ | 2.46 |  |

[0001032975-16-000083:notes:3]
| Market-based RSUs |  | Years Ended March 31, |
|  |  | 2016 |  | 2015 |  | 2014 |
| Dividend yield |  | 3.78 | % |  | 1.86 | % |  | 0.75 | % |
| Risk-free interest rate |  | 0.84 | % |  | 0.83 | % |  | 1.09 | % |
| Expected volatility |  | 38 | % |  | 46 | % |  | 46 | % |
| Expected life (years) |  | 3.0 |  |  | 3.0 |  |  | 2.9 |  |


## logi:ScheduleOfBalanceSheetComponentsAssetsTableTextBlock

[0001032975-16-000083:notes:4]
The following table presents the components of certain balance sheet asset amounts as of March 31, 2016 and 2015 (in thousands):

[0001032975-16-000083:notes:5]
|  |  | March 31, |
|  |  | 2016 |  | 2015 |
| Accounts receivable: |  |  |  |  |  |
| Accounts receivable |  | $ | 332,553 |  |  | $ | 328,373 |  |
| Allowance for doubtful accounts |  | (667 | ) |  | (707 | ) |
| Allowance for sales returns |  | (18,526 | ) |  | (17,236 | ) |
| Allowance for cooperative marketing arrangements (*) |  | (28,157 | ) |  | (24,919 | ) |
| Allowance for customer incentive programs (*) |  | (60,872 | ) |  | (47,364 | ) |
| Allowance for pricing programs (*) |  | (81,553 | ) |  | (70,951 | ) |
|  |  | $ | 142,778 |  |  | $ | 167,196 |  |
| Inventories: |  |  |  |  |  |  |
| Raw materials |  | $ | 48,489 |  |  | $ | 36,044 |  |
| Finished goods |  | 180,297 |  |  | 219,936 |  |
|  |  | $ | 228,786 |  |  | $ | 255,980 |  |
| Other current assets: |  |  |  |  |  |  |
| Income tax and value-added tax receivables |  | $ | 22,572 |  |  | $ | 19,318 |  |
| Deferred tax assets (**) |  | — |  |  | 27,790 |  |
| Prepaid expenses and other assets |  | 12,916 |  |  | 16,254 |  |
|  |  | $ | 35,488 |  |  | $ | 63,362 |  |
| Property, plant and equipment, net: |  |  |  |  |  |  |
| Plant, buildings and improvements |  | $ | 62,150 |  |  | $ | 60,205 |  |
| Equipment |  | 166,371 |  |  | 132,907 |  |
| Computer equipment |  | 36,018 |  |  | 32,178 |  |
| Software |  | 97,201 |  |  | 76,184 |  |
|  |  | 361,740 |  |  | 301,474 |  |
| Less accumulated depreciation and amortization |  | (278,352 | ) |  | (246,084 | ) |
|  |  | 83,388 |  |  | 55,390 |  |
| Construction-in-process |  | 6,771 |  |  | 28,341 |  |
| Land |  | 2,701 |  |  | 2,747 |  |
|  |  | $ | 92,860 |  |  | $ | 86,478 |  |
| Other assets: |  |  |  |  |  |  |
| Deferred tax assets (**) |  | $ | 56,208 |  |  | $ | 39,310 |  |
| Trading investments for deferred compensation plan |  | 14,836 |  |  | 17,237 |  |
| Investment in privately held companies |  | 9,247 |  |  | 768 |  |
| Other assets |  | 6,525 |  |  | 5,018 |  |
|  |  | $ | 86,816 |  |  | $ | 62,333 |  |


## logi:ScheduleOfBalanceSheetComponentsLiabilityTableTextBlock

[0001032975-16-000083:notes:6]
The following table presents the components of certain balance sheet liability amounts as of March 31, 2016 and 2015 (in thousands):

[0001032975-16-000083:notes:7]
|  |  | March 31, |
|  |  | 2016 |  | 2015 |
| Accrued and other current liabilities: |  |  |  |  |  |  |
| Accrued personnel expenses |  | $ | 46,025 |  |  | $ | 46,022 |  |
| Indirect customer incentive programs (*) |  | 28,721 |  |  | 19,730 |  |
| Warranty accrual |  | 11,880 |  |  | 12,630 |  |
| Employee benefit plan obligation |  | 1,285 |  |  | 1,219 |  |
| Income taxes payable |  | 1,553 |  |  | 5,759 |  |
| Other liabilities |  | 84,300 |  |  | 77,984 |  |
|  |  | $ | 173,764 |  |  | $ | 163,344 |  |
| Non-current liabilities: |  |  |  |  |  |  |
| Warranty accrual |  | $ | 8,500 |  |  | $ | 9,080 |  |
| Obligation for deferred compensation plan |  | 14,836 |  |  | 17,237 |  |
| Employee benefit plan obligation |  | 53,909 |  |  | 51,081 |  |
| Deferred tax liability (**) |  | 1,665 |  |  | 1,936 |  |
| Other liabilities |  | 10,625 |  |  | 11,861 |  |
|  |  | $ | 89,535 |  |  | $ | 91,195 |  |

[0001032975-16-000083:notes:8]
| (*) | The increase in the allowances for cooperative marketing arrangements, customer incentive programs, pricing programs, and accrued liabilities for indirect customer incentive programs is primarily due to increases in retail sales, timing of claims processed, and increases in the marketing activities, partially offset by price increases. |

[0001032975-16-000083:notes:9]
(**)   Includes reclassifications of deferred tax assets and liabilities related to ASU 2015-17 “Income Taxes (Topic 740): Balance Sheet Classification of Deferred Taxes".


## logi:ScheduleOfRevenueByProductFamilyExcludingInterCompanyTransactionsTableTextBlock

[0001032975-16-000083:notes:10]
Net sales by product categories and sales channels, excluding intercompany transactions, were as follows (in thousands):

[0001032975-16-000083:notes:11]
|  |  | Years Ended March 31, |
|  |  | 2016 |  | 2015 |  | 2014 |
| Mobile Speakers |  | 229,718 |  |  | 178,038 |  |  | 87,414 |  |
| Audio-PC & Wearables |  | 196,013 |  |  | 213,496 |  |  | 250,037 |  |
| Gaming |  | 245,101 |  |  | 211,911 |  |  | 186,926 |  |
| Video Collaboration |  | 89,322 |  |  | 62,215 |  |  | 29,058 |  |
| Home Control |  | 59,075 |  |  | 68,060 |  |  | 67,371 |  |
| Pointing Devices |  | 492,543 |  |  | 487,210 |  |  | 506,884 |  |
| Keyboards & Combos |  | 430,190 |  |  | 426,117 |  |  | 415,314 |  |
| Tablet & Other Accessories |  | 103,886 |  |  | 140,994 |  |  | 172,484 |  |
| PC Webcams |  | 98,641 |  |  | 96,680 |  |  | 113,791 |  |
| Other (1) |  | 2,570 |  |  | 2,725 |  |  | 37,000 |  |
| Total net retail sales |  | 1,947,059 |  |  | 1,887,446 |  |  | 1,866,279 |  |
| OEM |  | 71,041 |  |  | 117,462 |  |  | 141,749 |  |
| Total net sales |  | $ | 2,018,100 |  |  | $ | 2,004,908 |  |  | $ | 2,008,028 |  |

[0001032975-16-000083:notes:12]
______________________________________

[0001032975-16-000083:notes:13]
| (1) | Other category includes products that the Company currently intends to transition out of, or have already transitioned out of, because they are no longer strategic to the Company's business. |


## logi:ScheduleOfSharesRepurchasedUnderRepurchasePlanTableTextBlock

[0001032975-16-000083:notes:14]
A summary of the approved and active share buyback program is shown in the following table (in thousands, excluding transaction costs):

[0001032975-16-000083:notes:15]
|  |  | Approved |  | Repurchased |
| Share Buyback Program |  | Shares |  | Amounts |  | Shares |  | Amounts |
| March 2014 |  | 17,311 |  |  | $ | 250,000 |  |  | 5,066 |  |  | $ | 71,702 |  |


## us-gaap:AdvertisingCostsPolicyTextBlock

[0001032975-16-000083:notes:16]
Advertising Costs

[0001032975-16-000083:notes:17]
Advertising costs are expensed as incurred. Advertising costs are recorded as either a marketing and selling expense or a deduction from revenue. Advertising costs paid or reimbursed by the Company to direct or indirect customers must have an identifiable benefit and an estimable fair value in order to be classified as an operating expense. If these criteria are not met, the cost is classified as a reduction of revenue.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001032975-16-000083:notes:18]
Summary of Significant Accounting Policies

[0001032975-16-000083:notes:19]
Basis of Presentation

[0001032975-16-000083:notes:20]
The consolidated financial statements include the accounts of Logitech and its subsidiaries. All intercompany balances and transactions have been eliminated. The consolidated financial statements are presented in accordance with U.S. GAAP (accounting principles generally accepted in the United States of America).

[0001032975-16-000083:notes:21]
During the third quarter of fiscal year 2016, the Company's Board of Directors approved a plan to divest the Lifesize video conferencing business. On December 28, 2015, the Company and Lifesize, Inc., a wholly owned subsidiary of the Company (“Lifesize”) which holds the assets of the Company’s Lifesize video conferencing business, entered into a stock purchase agreement (the “Stock Purchase Agreement”) with three venture capital firms. Immediately following the December 28, 2015 closing of the transactions contemplated by the Stock Purchase Agreement, the venture capital firms held 62.5% of the outstanding shares of Lifesize, which resulted in a divestiture of the Lifesize video conferencing business by the Company. The disposition of the Lifesize video conferencing business was completed during the fourth quarter of fiscal year 2016, and represents a strategic shift that has a major effect on the Company's operations and financial results. As a result, the Company has classified the results of Lifesize video conferencing business as discontinued operations in its consolidated statements of operations for all periods presented. Additionally, the related assets and liabilities associated with the discontinued operations are classified separately on its consolidated balance sheets for the comparative periods presented herein.

[0001032975-16-000083:notes:22]
Unless indicated otherwise, the information in the Notes to the consolidated financial statements relates to the Company's continuing operations and does not include results of Lifesize video conferencing business, which is classified as discontinued operations. See "Note 3 - Discontinued Operations" for more information.

[0001032975-16-000083:notes:23]
Fiscal Year

[0001032975-16-000083:notes:24]
The Company's fiscal year ends on March 31. Interim quarters are thirteen-week periods, each ending on a Friday of each quarter. For purposes of presentation, the Company has indicated its quarterly periods ending on the last day of the calendar quarter.

[0001032975-16-000083:notes:25]
Use of Estimates

[0001032975-16-000083:notes:26]
The preparation of financial statements in conformity with U.S. GAAP requires management to make judgments, estimates and assumptions that affect the amounts reported in the consolidated financial statements. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Examples of significant estimates and assumptions made by management involve the fair value of goodwill, warranty liabilities, accruals for discretionary customer programs, sales return reserves, allowance for doubtful accounts, inventory valuation, restructuring charges, contingent liabilities, share-based compensation expense, uncertain tax positions, and valuation allowances for deferred tax assets. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ materially from those estimates.

[0001032975-16-000083:notes:27]
Foreign Currencies

[0001032975-16-000083:notes:28]
The functional currency of the Company's operations is primarily the U.S. Dollar. Certain operations use the Euro, Chinese Renminbi, Swiss Franc, or other local currencies as their functional currencies. The financial statements of the Company's subsidiaries whose functional currency is other than the U.S. Dollar are translated to U.S. Dollars using period-end rates of exchange for assets and liabilities and monthly average rates for net sales, income and expenses. Cumulative translation gains and losses are included as a component of shareholders' equity in accumulated other comprehensive loss. Gains and losses arising from transactions denominated in currencies other than a subsidiary's functional currency are reported in other income (expense), net in the consolidated statements of operations.

[0001032975-16-000083:notes:29]
Revenue Recognition

[0001032975-16-000083:notes:30]
Revenue is recognized when all of the following criteria are met:

[0001032975-16-000083:notes:31]
| • | Evidence of an arrangement between the Company and the customer exists; |

[0001032975-16-000083:notes:32]
| • | Delivery has occurred and title and risk of loss has transferred to the customer; |

[0001032975-16-000083:notes:33]
| • | The price of the product is fixed or determinable; and |

[0001032975-16-000083:notes:34]
| • | Collectability of the receivable is reasonably assured. |

[0001032975-16-000083:notes:35]
For sales of most hardware peripherals products and hardware bundled with software essential to its functionality, these criteria are met at the time delivery has occurred and title and risk of loss have transferred to the customer.

[0001032975-16-000083:notes:36]
Revenues from sales to distributors and authorized resellers are recognized upon shipment net of estimated product returns and expected payments for cooperative marketing arrangements, customer incentive programs and pricing programs. The estimated cost of these programs is recorded as a reduction of sales or as an operating expense, if the Company receives a separately identifiable benefit from the customer and can reasonably estimate the fair value of that benefit. Significant management judgment and estimates are used to determine the cost of these programs in any accounting period.

[0001032975-16-000083:notes:37]
The Company enters into cooperative marketing arrangements with many of its distribution and retail customers, and with certain indirect partners, allowing customers to receive a credit equal to a set percentage of their purchases of the Company's products, or a fixed dollar credit for various marketing programs. The objective of these arrangements is to encourage advertising and promotional events to increase sales of the Company's products. Accruals for these marketing arrangements are recorded at the later of time of sale or time of commitment, based on negotiated terms, historical experience and inventory levels in the channel.

[0001032975-16-000083:notes:38]
Customer incentive programs include consumer rebate and performance-based incentives. The Company offers performance-based incentives to its distribution customers, retail customers and indirect partners based on pre-determined performance criteria. Accruals for performance-based incentives are recognized as a reduction of the sale price at the time of sale. Estimates of required accruals are determined based on negotiated terms, consideration of historical experience, anticipated volume of future purchases, and inventory levels in the channel. Consumer rebates are offered from time to time at the Company's discretion for the primary benefit of end-users. Accruals for the estimated costs of consumer rebates and similar incentives are recorded at the later of time of sale or when the incentive is offered, based on the specific terms and conditions. Certain incentive programs, including consumer rebates, require management to estimate the number of customers who will actually redeem the incentive based on historical experience and the specific terms and conditions of particular programs.

[0001032975-16-000083:notes:39]
The Company has agreements with certain of its customers that contain terms allowing price protection credits to be issued in the event of a subsequent price reduction. At management's discretion, the Company also offers special pricing discounts to certain customers. Special pricing discounts are usually offered only for limited time periods or for sales of selected products to specific indirect partners. Management's decision to make price reductions is influenced by product life cycle stage, market acceptance of products, the competitive environment, new product introductions and other factors. Accruals for estimated expected future pricing actions are recognized at the time of sale based on analyses of historical pricing actions by customer and by products, inventories owned by and located at distributors and retailers, current customer demand, current operating conditions, and other relevant customer and product information, such as stage of product life-cycle.

[0001032975-16-000083:notes:40]
The Company grants limited rights to return products. Return rights vary by customer, and range from just the right to return defective product to stock rotation rights limited to a percentage of sales approved by management. Estimates of expected future product returns are recognized at the time of sale based on analyses of historical return trends by customer and by product, inventories owned by and located at distributors and retailers, current customer demand, current operating conditions, and other relevant customer and product information. Upon recognition, the Company reduces sales and cost of sales for the estimated return. Return trends are influenced by product life cycle status, new product introductions, market acceptance of products, sales levels, product sell-through, the type of customer, seasonality, product quality issues, competitive pressures, operational policies and procedures, and other factors.

[0001032975-16-000083:notes:41]
Return rates can fluctuate over time, but are sufficiently predictable to allow the Company to estimate expected future product returns.

[0001032975-16-000083:notes:42]
The Company regularly evaluates the adequacy of its estimates for cooperative marketing arrangements, customer incentive programs and pricing programs, and product returns. Future market conditions and product transitions may require the Company to take action to change such programs. In addition, when the variables used to estimate these costs change, or if actual costs differ significantly from the estimates, the Company would be required to record incremental increases or reductions to sales, cost of goods sold or operating expenses. If, at any future time, the Company becomes unable to reasonably estimate these costs, recognition of revenue might be deferred until products are sold to users, which would adversely impact sales in the period of transition.

[0001032975-16-000083:notes:43]
Shipping and Handling Costs

[0001032975-16-000083:notes:44]
The Company's shipping and handling costs are included in cost of sales in the consolidated statements of operations for all periods presented.

[0001032975-16-000083:notes:45]
Research and Development Costs

[0001032975-16-000083:notes:46]
Costs related to research, design and development of products, which consist primarily of personnel, product design and infrastructure expenses, are charged to research and development expense as they are incurred.

[0001032975-16-000083:notes:47]
Advertising costs are expensed as incurred. Advertising costs are recorded as either a marketing and selling expense or a deduction from revenue. Advertising costs paid or reimbursed by the Company to direct or indirect customers must have an identifiable benefit and an estimable fair value in order to be classified as an operating expense. If these criteria are not met, the cost is classified as a reduction of revenue. Advertising costs during fiscal years 2016, 2015 and 2014 were $181.7 million, $165.7 million and $156.8 million, respectively.

[0001032975-16-000083:notes:48]
Cash Equivalents

[0001032975-16-000083:notes:49]
The Company considers all highly liquid instruments purchased with an original maturity of three months or less to be cash equivalents. Cash equivalents are carried at cost, which approximates fair value.

[0001032975-16-000083:notes:50]
All of the Company's bank time deposits have an original maturity of three months or less and are classified as cash equivalents and are recorded at cost, which approximates fair value.

[0001032975-16-000083:notes:51]
Concentration of Credit Risk

[0001032975-16-000083:notes:52]
Financial instruments that potentially subject the Company to concentrations of credit risk consist principally of cash and cash equivalents and accounts receivable. The Company maintains cash and cash equivalents with various financial institutions to limit exposure with any one financial institution, but is exposed to credit risk in the event of default by financial institutions to the extent that cash balances with individual financial institutions are in excess of amounts that are insured.

[0001032975-16-000083:notes:53]
The Company sells to large distributors and retailers and, as a result, maintains individually significant receivable balances with such customers. In fiscal years 2016, 2015 and 2014, one customer represented 14%, 15% and 15% of the Company's total net sales. In fiscal year 2016, another customer accounted for 10% of the Company's net sales. No other customer represented more than 10% of the Company's total net sales during fiscal years 2016, 2015 or 2014. As of March 31, 2016 and 2015, one customer represented 15% and 13% of total accounts receivable, respectively.  Typical payment terms require customers to pay for product sales generally within 30 to 60 days; however terms may vary by customer type, by country and by selling season. Extended payment terms are sometimes offered to a limited number of customers during the second and third fiscal quarters. The Company does not modify payment terms on existing receivables.

[0001032975-16-000083:notes:54]
The Company manages its accounts receivable credit risk through ongoing credit evaluation of its customers' financial condition. The Company generally does not require collateral from its customers.

[0001032975-16-000083:notes:55]
Allowances for Doubtful Accounts

[0001032975-16-000083:notes:56]
Allowances for doubtful accounts are maintained for estimated losses resulting from the inability of the Company's customers to make required payments. The allowances are based on the Company's regular assessment of the credit worthiness and financial condition of specific customers, as well as its historical experience with bad debts and customer deductions, receivables aging, current economic trends, geographic or country-specific risks and the financial condition of its distribution channels.

[0001032975-16-000083:notes:57]
Inventories

[0001032975-16-000083:notes:58]
Inventories are stated at the lower of cost or market. Costs are computed under the standard cost method, which approximates actual costs determined on the first-in, first-out basis. The Company records write-downs of inventories which are obsolete or in excess of anticipated demand or market value based on a consideration of marketability and product life cycle stage, product development plans, component cost trends, demand forecasts, historical net sales, and assumptions about future demand and market conditions.

[0001032975-16-000083:notes:59]
As of March 31, 2016 and 2015, the Company also recorded a liability of $8.5 million and $9.8 million, respectively, arising from firm, non-cancelable, and unhedged inventory purchase commitments in excess of anticipated demand or market value consistent with its valuation of excess and obsolete inventory. Such liability is included in accrued and other current liabilities.

[0001032975-16-000083:notes:60]
Property, Plant and Equipment

[0001032975-16-000083:notes:61]
Property, plant and equipment are stated at cost. Additions and improvements are capitalized, and maintenance and repairs are expensed as incurred. The Company capitalizes the cost of software developed for internal use in connection with major projects. Costs incurred during the feasibility stage are expensed, whereas direct costs incurred during the application development stage are capitalized.

[0001032975-16-000083:notes:62]
Depreciation is provided using the straight-line method. Plant and buildings are depreciated over estimated useful lives from ten to twenty-five years, equipment over useful lives from three to five years, internal-use software development over useful lives of three to seven years and leasehold improvements over the lesser of the useful life of the improvement or the term of the lease.

[0001032975-16-000083:notes:63]
When property and equipment is retired or otherwise disposed of, the cost and accumulated depreciation are relieved from the accounts and the net gain or loss is included in operating expenses.

[0001032975-16-000083:notes:64]
Valuation of Long-Lived Assets

[0001032975-16-000083:notes:65]
The Company reviews long-lived assets, such as property and equipment, and finite-lived intangible assets, for impairment whenever events indicate that the carrying amounts might not be recoverable. Recoverability of property and equipment, and other finite-lived intangible asset is measured by comparing the projected undiscounted net cash flows associated with those assets to their carrying values. If an asset is considered impaired, it is written down to fair value, which is determined based on the asset's projected discounted cash flows or appraised value, depending on the nature of the asset. For purposes of recognition of an impairment for assets held for use, the Company groups assets and liabilities at the lowest level for which cash flows are separately identifiable.

[0001032975-16-000083:notes:66]
Goodwill and Other Intangible Assets

[0001032975-16-000083:notes:67]
The Company's intangible assets principally include goodwill, acquired technology, trademarks, and customer contracts. Other intangible assets with finite lives, which include acquired technology, trademarks and customer contracts, and other are recorded at cost and amortized using the straight-line method over their useful lives ranging from one year to ten years. Intangible assets with indefinite lives, which include only goodwill, are recorded at cost and evaluated at least annually for impairment.

[0001032975-16-000083:notes:68]
Goodwill represents the excess of the purchase price over the fair value of the net tangible and identifiable intangible assets acquired in each business combination. The Company conducts a goodwill impairment analysis annually at December 31 or more frequently if indicators of impairment exist or if a decision is made to sell or exit a business. A significant amount of judgment is involved in determining if an indicator of impairment has occurred. Such indicators may include deterioration in general economic conditions, negative developments in equity and credit markets, adverse changes in the markets in which an entity operates, increases in input costs that have a negative effect on earnings and cash flows, or a trend of negative or declining cash flows over multiple periods, among others. The fair value that could be realized in an actual transaction may differ from that used to evaluate the impairment of goodwill.

[0001032975-16-000083:notes:69]
In reviewing goodwill for impairment, an entity has the option to first assess qualitative factors to determine whether the existence of events or circumstances leads to a determination that it is more likely than not (greater than 50%) that the estimated fair value of a reporting unit is less than its carrying amount. If an entity elects to perform a qualitative assessment and determines that an impairment is more likely than not, the entity is then required to perform the two-step quantitative impairment test, otherwise no further analysis is required. An entity also may elect not to perform the qualitative assessment and, instead, proceed directly to the two-step quantitative impairment test. The ultimate outcome of the goodwill impairment review for a reporting unit should be the same whether an entity chooses to perform the qualitative assessment or proceeds directly to the two-step quantitative impairment test.

[0001032975-16-000083:notes:70]
Long-lived intangible assets are tested for recoverability whenever events or changes in circumstances indicate that their carrying amounts may not be recoverable.

[0001032975-16-000083:notes:71]
Income Taxes

[0001032975-16-000083:notes:72]
The Company provides for income taxes using the asset and liability method, which requires that deferred tax assets and liabilities be recognized for the expected future tax consequences of temporary differences resulting from differing treatment of items for tax and accounting purposes. In estimating future tax consequences, expected future events are taken into consideration, with the exception of potential tax law or tax rate changes.

[0001032975-16-000083:notes:73]
The Company's assessment of uncertain tax positions requires that management makes estimates and judgments about the application of tax law, the expected resolution of uncertain tax positions and other matters. In the event that uncertain tax positions are resolved for amounts different than the Company's estimates, or the related statutes of limitations expire without the assessment of additional income taxes, the Company will be required to adjust the amounts of the related assets and liabilities in the period in which such events occur. Such adjustments may have a material impact on the Company's income tax provision and its results of operations.

[0001032975-16-000083:notes:74]
Fair Value of Financial Instruments

[0001032975-16-000083:notes:75]
The carrying value of certain of the Company's financial instruments, including cash equivalents, accounts receivable and accounts payable approximates fair value due to their short maturities.

[0001032975-16-000083:notes:76]
The Company's investment securities portfolio consists of bank time deposits with an original maturity of three months or less and marketable securities (money market and mutual funds) related to a deferred compensation plan.

[0001032975-16-000083:notes:77]
The Company's trading investments related to the deferred compensation plan are reported at fair value based on quoted market prices. The marketable securities related to the deferred compensation plan are classified as non-current trading investments, as they are intended to fund the deferred compensation plan long-term liability. Since participants in the deferred compensation plan may select the mutual funds in which their compensation deferrals are invested within the confines of the Rabbi Trust which holds the marketable securities, the Company has designated these marketable securities as trading investments, although there is no intent to actively buy and sell securities within the objective of generating profits on short-term differences in market prices. These securities are recorded at fair value based on quoted market prices. Earnings, gains and losses on trading investments are included in other income (expense), net.

[0001032975-16-000083:notes:78]
The Company also holds investments in equity and other securities that are accounted for as either cost or equity method investments, which are classified as other assets. The cost method investment is initially recognized at fair value, which represents a Level 3 valuation as the assumptions used in valuing this investment were not directly or indirectly observable. The Company reviews the fair value of its non-marketable investments on a regular basis to determine whether the investments in these companies are other-than-temporarily impaired. The Company considers investee financial performance and other information received from the investee companies, as well as any other available estimates of the fair value of the investee companies in its review. If the Company determines the carrying value of an investment exceeds its fair value, and that difference is other than temporary, the Company writes down the value of the investment to its fair value. The fair value of cost investments is not adjusted if there are no identified adverse events or changes in circumstances that may have a material effect on the fair value of the investments.

[0001032975-16-000083:notes:79]
Net Income (Loss) per Share

[0001032975-16-000083:notes:80]
Basic net income (loss) per share is computed by dividing net income (loss) by the weighted average outstanding shares. Diluted net income (loss) per share is computed using the weighted average outstanding shares and dilutive share equivalents. Dilutive share equivalents consist of share-based awards, including stock options, purchase rights under employee share purchase plan, and restricted stock units ("RSUs").

[0001032975-16-000083:notes:81]
The dilutive effect of in-the-money share-based compensation awards is calculated based on the average share price for each fiscal period using the treasury stock method, which assumes that the amount used to repurchase shares includes the amount the employee must pay for exercising share-based awards, the amount of compensation cost not yet recognized for future service, and the amount of tax impact that would be recorded in additional paid-in capital when the award becomes deductible. The dilutive securities are excluded from the computation of diluted net loss per share from continuing operations as their effect would be anti-dilutive.

[0001032975-16-000083:notes:82]
Share-Based Compensation Expense

[0001032975-16-000083:notes:83]
Share-based compensation expense includes compensation expense, reduced for estimated forfeitures, for share-based awards granted based on the grant date fair value. The grant date fair value for stock options and stock purchase rights is estimated using the Black-Scholes-Merton option-pricing valuation model. The grant date fair value of RSUs which vest upon meeting certain market conditions is estimated using the Monte-Carlo simulation method. The grant date fair value of time-based and performance-based RSUs is calculated based on the market price on the date of grant, adjusted by estimated dividends yield prior to vesting. With respect to awards with service conditions only, compensation expense is recognized ratably over the vesting period of the awards.

[0001032975-16-000083:notes:84]
Excess tax benefits resulting from share-based awards are classified as cash flows from financing activities in the consolidated statements of cash flows. Excess tax benefits are realized tax benefits from tax deductions for exercised options and vested RSUs in excess of the deferred tax asset attributable to share-based compensation costs for such share-based awards.

[0001032975-16-000083:notes:85]
The Company will recognize a benefit from share-based compensation in additional paid-in capital only if an incremental tax benefit is realized after all other available tax attributes have been utilized.

[0001032975-16-000083:notes:86]
Product Warranty Accrual

[0001032975-16-000083:notes:87]
The Company estimates cost of product warranties at the time the related revenue is recognized based on historical and projected warranty claim rates, historical and projected costs, and knowledge of specific product failures that are outside of the Company's typical experience. Each quarter, the Company reevaluates estimates to assess the adequacy of recorded warranty liabilities considering the size of the installed base of products subject to warranty protection and adjusts the amounts as necessary. If actual product failure rates or repair costs differ from estimates, revisions to the estimated warranty liabilities would be required and could materially affect the Company's results of operations.

[0001032975-16-000083:notes:88]
Comprehensive Income (Loss)

[0001032975-16-000083:notes:89]
Comprehensive income (loss) is defined as the total change in shareholders' equity during the period other than from transactions with shareholders. Comprehensive income (loss) consists of net income (loss) and other comprehensive income (loss). Other comprehensive income (loss) is comprised of currency translation adjustments from those entities not using the U.S. Dollar as their functional currency, unrealized gains and losses on marketable equity securities, net deferred gains and losses and prior service costs and credits for defined benefit pension plans, and net deferred gains and losses on hedging activity.

[0001032975-16-000083:notes:90]
Treasury Shares

[0001032975-16-000083:notes:91]
The Company periodically repurchases shares in the market at fair value. Treasury shares repurchased are recorded at cost as a reduction of total shareholders' equity. Treasury shares held may be reissued to satisfy the exercise of employee stock options and purchase rights, the vesting of restricted stock units, and acquisitions, or may be cancelled with shareholder approval. Treasury shares that are reissued are accounted for using the first-in, first-out basis.

[0001032975-16-000083:notes:92]
Derivative Financial Instruments

[0001032975-16-000083:notes:93]
The Company enters into foreign exchange forward contracts to reduce the short-term effects of currency fluctuations on certain foreign currency receivables or payables and to hedge against exposure to changes in currency exchange rates related to its subsidiaries' forecasted inventory purchases. These forward contracts generally mature within four months.

[0001032975-16-000083:notes:94]
Gains and losses for changes in the fair value of the effective portion of the Company's forward contracts related to forecasted inventory purchases are deferred as a component of accumulated other comprehensive income (loss) until the hedged inventory purchases are sold, at which time the gains or losses are reclassified to cost of goods sold. Gains or losses for changes in the fair value on forward contracts that offset translation losses or gains on foreign currency receivables or payables are recognized immediately and included in other income (expense), net.

[0001032975-16-000083:notes:95]
Restructuring Charges

[0001032975-16-000083:notes:96]
The Company's restructuring charges consist of employee severance, one-time termination benefits and ongoing benefits related to the reduction of its workforce, lease exit costs, and other costs. Liabilities for costs associated with a restructuring activity are measured at fair value and are recognized when the liability is incurred, as opposed to when management commits to a restructuring plan. One-time termination benefits are expensed at the date the entity notifies the employee, unless the employee must provide future service, in which case the benefits are expensed ratably over the future service period. Ongoing benefits are expensed when restructuring activities are probable and the benefit amounts are estimable. Costs to terminate a lease before the end of its term are recognized when the property is vacated. Other costs primarily consist of legal, consulting, and other costs related to employee terminations are expensed when incurred. Termination benefits are calculated based on regional benefit practices and local statutory requirements.

[0001032975-16-000083:notes:97]
Segments

[0001032975-16-000083:notes:98]
ASC 280, Segment Reporting, establishes standards for reporting information about operating segments. Operating segments are defined as components of an enterprise about which separate financial information is available that is evaluated regularly by the chief operating decision maker, or decision making group, in deciding how to allocate resources and in assessing performance. The guidance defines reportable segments as operating segments that meet certain quantitative thresholds. As a result of the disposition of the Lifesize video conferencing business on December 28, 2015 described above, the composition of the Company's previously reported segments changed significantly, such that the remaining peripheral segment is the only segment reported in continuing operations.

[0001032975-16-000083:notes:99]
Recent Accounting Pronouncements

[0001032975-16-000083:notes:100]
In April 2014, the FASB issued ASU No. 2014-08, "Presentation of Financial Statements (Topic 205) and Property, Plant and Equipment (Topic 360): Reporting Discontinued Operations and Disclosures of Disposals of Components of an Entity". This new standard raises the threshold for a disposal to qualify as a discontinued operation and requires new disclosures of both discontinued operations and certain other disposals that do not meet the definition of a discontinued operation. The standard is effective prospectively for years beginning on or after December 15, 2014, with early application permitted. The Company adopted ASU No. 2014-08 on April 1, 2015 on a prospective basis and applied the guidance to its disposition of the Lifesize video conferencing business.

[0001032975-16-000083:notes:101]
In May 2014, the FASB issued ASU No. 2014-9, "Revenue from Contracts with Customers (Topic 606)," ("ASU 2014-9"). ASU 2014-9 outlines a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. Under the new model, recognition of revenue occurs when a customer obtains control of promised goods or services in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. In addition, the new standard requires that reporting companies disclose the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. ASU 2014-09 was originally to be effective for the Company on April 1, 2017. In July 2015, the FASB affirmed a one-year deferral of the effective date of the new revenue standard. The new standard will become effective for the Company on April 1, 2018. Early application is permitted but not before the original effective date of annual periods beginning after December 15, 2016. The new standard is required to be applied retrospectively to each prior reporting period presented or retrospectively with the cumulative effect of initially applying it recognized at the date of initial application. The Company has not yet selected a transition method nor has it determined whether it will early adopt this guidance or the impact of the new standard on its consolidated financial statements.

[0001032975-16-000083:notes:102]
In July 2015, the FASB issued ASU No. 2015-11, "Simplifying the Measurement of Inventory (Topic 330)",  ("ASU 2015-11"). Topic 330, Inventory, currently requires an entity to measure inventory at the lower of cost or market, with market value represented by replacement cost, net realizable value or net realizable value less a normal profit margin. The amendments in ASU 2015-11 require an entity to measure inventory at the lower of cost or net realizable value. ASU 2015-11 is effective in the first quarter of fiscal year 2018 for the Company, with early adoption permitted. The Company does not expect to early adopt this guidance and does not expect the adoption of this guidance to have a material impact on its consolidated financial statements.

[0001032975-16-000083:notes:103]
In November 2015, FASB issued ASU No. 2015-17, “Income Taxes (Topic 740), Balance Sheet Classification of Deferred Taxes” ("ASU 2015-17"). The guidance eliminates the current requirement for an entity to separate deferred income tax liabilities and assets into current and non-current amounts in a classified balance sheet. Instead, the guidance requires deferred tax liabilities, deferred tax assets and valuation allowances be classified as non-current in a classified balance sheet. The ASU is effective for annual reporting periods beginning after December 15, 2016 and interim periods within those annual periods. Early adoption is permitted. The Company has early adopted the guidance in the fourth quarter of fiscal year 2016 on a prospective basis.  Prior periods are therefore not adjusted.

[0001032975-16-000083:notes:104]
In January 2016, FASB issued ASU 2016-01 “Financial Instruments- Recognition and Measurement of Financial Assets and Financial Liabilities (Subtopic 825-10)”, which amends certain aspects of recognition, measurement, presentation and disclosure of financial instruments, including the requirement to measure certain equity investments at fair value with changes in fair value recognized in net income. This guidance is effective for fiscal years beginning after December 15, 2017, including interim periods within those fiscal years. The Company does not expect to early adopt this guidance and does not believe that the adoption of this guidance will have a material impact on its consolidated financial statements.

[0001032975-16-000083:notes:105]
In February 2016, the FASB issued ASU 2016-02 "Leases (Topic 842)", which requires the recognition of lease assets and lease liabilities arising from operating leases in the statement of financial position. This guidance is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. The Company is evaluating the full effect that ASU 2016-02 will have on its consolidated financial statements and will adopt the standard effective April 1, 2019.

[0001032975-16-000083:notes:106]
In March 2016, the FASB issued ASU 2016-09 "Compensation-Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting". The amendment simplifies several aspects of the accounting for share-based payments, including immediate recognition of all excess tax benefits and deficiencies in the income statement, changing the threshold to qualify for equity classification up to the employees' maximum statutory tax rates, allowing an entity-wide accounting policy election to either estimate the number of awards that are expected to vest or account for forfeitures as they occur, and clarifying the classification on the statement of cash flows for the excess tax benefit and employee taxes paid when an employer withholds shares for tax-withholding purposes. ASU 2016-09 is effective for annual periods beginning after December 15, 2016, and interim periods within those annual periods. Early adoption is permitted in any interim or annual period. The Company is evaluating the effect that ASU 2016-09 will have on its consolidated financial statements and the timing of the adoption of this standard.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001032975-16-000083:notes:107]
Commitments and Contingencies

[0001032975-16-000083:notes:108]
Operating Leases

[0001032975-16-000083:notes:109]
The Company leases facilities under operating leases, certain of which require it to pay property taxes, insurance and maintenance costs. Operating leases for facilities are generally renewable at the Company's option and usually include escalation clauses linked to inflation. Future minimum annual rentals under non-cancelable operating leases at March 31, 2016 are as follows (in thousands):

[0001032975-16-000083:notes:110]
| Years Ending March 31, |  |  |
| 2017 |  | $ | 7,558 |  |
| 2018 |  | 5,411 |  |
| 2019 |  | 4,843 |  |
| 2020 |  | 4,433 |  |
| 2021 |  | 3,190 |  |
| Thereafter |  | 6,539 |  |
|  |  | $ | 31,974 |  |

[0001032975-16-000083:notes:111]
Rent expense for fiscal years 2016, 2015 and 2014 was $10.0 million, $9.6 million and $12.7 million, respectively.

[0001032975-16-000083:notes:112]
In connection with its leased facilities, the Company recognized a liability for asset retirement obligations for 2016 and 2015 representing the present value of estimated remediation costs to be incurred at lease expiration. The liabilities for asset retirement obligations were not material as of March 31, 2016 and 2015.

[0001032975-16-000083:notes:113]
Product Warranties

[0001032975-16-000083:notes:114]
All of the Company's Peripherals products are covered by warranty to be free from defects in material and workmanship for periods ranging from one year to five years. For products launched prior to April 1, 2014, the standard warranty period was up to five years. Starting from April 1, 2014, the standard warranty for all new products launched was changed to two years from date of purchase for European Countries and generally one year from date of purchase for all other countries. At the time of sale, the Company accrues a warranty liability for estimated costs to provide products, parts or services to repair or replace products in satisfaction of the warranty obligation. The Company's estimate of costs to fulfill its warranty obligations is based on historical experience and expectations of future conditions. When the Company experiences changes in warranty claim activity or costs associated with fulfilling those claims, the warranty liability is adjusted accordingly.

[0001032975-16-000083:notes:115]
Changes in the Company's warranty liability for fiscal years 2016 and 2015 were as follows (in thousands):

[0001032975-16-000083:notes:116]
|  |  | Years Ended March 31, |
|  |  | 2016 |  | 2015 |
| Beginning of the period |  | $ | 21,710 |  |  | $ | 24,380 |  |
| Provision |  | 9,772 |  |  | 10,958 |  |
| Settlements |  | (11,339 | ) |  | (12,027 | ) |
| Currency translation |  | 237 |  |  | (1,601 | ) |
| End of the period |  | $ | 20,380 |  |  | $ | 21,710 |  |

[0001032975-16-000083:notes:117]
Investment Commitments

[0001032975-16-000083:notes:118]
During 2015, the Company entered into a limited partnership agreement for a private investment fund specialized in early-stage start-up consumer hardware electronics companies and committed to a capital contribution of $4.0 million over the life of the fund. The Company has invested $0.9 million as of March 31, 2016, which is classified as other assets on the consolidated balance sheet. As of March 31, 2016, $3.1 million capital contribution has not yet been called upon by the fund.

[0001032975-16-000083:notes:119]
Other Contingencies

[0001032975-16-000083:notes:120]
In April 2016, the Company entered into a settlement with the Securities and Exchange Commission (“SEC”) related to the accounting for Revue inventory valuation reserves that resulted in the restatement described in the Fiscal Year 2014 Annual Report on Form 10-K, revision to its consolidated financial statements concerning warranty accruals and amortization of intangible assets presented in its Amended Annual Report on Form 10-K/A, filed on August 7, 2013, and its transactions with a distributor for Fiscal Year 2007 through Fiscal Year 2009. The Company entered into the settlement without admitting or denying the findings of the SEC’s investigation and paid a civil penalty of $7.5 million. This amount was paid in April 2016. The Company made an accrual of the same amount in its consolidated financial statements as of March 31, 2016.

[0001032975-16-000083:notes:121]
Guarantees

[0001032975-16-000083:notes:122]
Logitech Europe S.A. guaranteed payments of two third-party contract manufacturers' purchase obligations. As of March 31, 2016, the maximum amount of this guarantee was $3.8 million, of which $1.0 million of guaranteed purchase obligations was outstanding.

[0001032975-16-000083:notes:123]
Indemnifications

[0001032975-16-000083:notes:124]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys' fees. As of March 31, 2016, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

[0001032975-16-000083:notes:125]
The Company also indemnifies its current and former directors and certain of its current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. The Company is unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not limited, the obligations are conditional in nature and the facts and circumstances involved in any situation that might arise are variable.

[0001032975-16-000083:notes:126]
The Stock Purchase Agreement that the Company entered into in connection with the investment by three venture capital firms in Lifesize, Inc. contains representations, warranties and covenants of Logitech and Lifesize, Inc. to the Venture Investors. Subject to certain limitations, the Company has agreed to indemnify the Venture Investors and certain persons related to the Venture Investors for certain losses resulting from breaches of or inaccuracies in such representations, warranties and covenants as well as certain other obligations, including third party expenses, restructuring costs and pre-closing tax obligations of Lifesize.

[0001032975-16-000083:notes:127]
Legal Proceedings

[0001032975-16-000083:notes:128]
From time to time the Company is involved in claims and legal proceedings which arise in the ordinary course of its business. The Company is currently subject to several such claims and a small number of legal proceedings. The Company believes that these matters lack merit and intends to vigorously defend against them. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial position, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company's defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company's business, financial position, cash flows or results of operations in a particular period. Any claims or proceedings against the Company, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company's business.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001032975-16-000083:notes:129]
Employee Benefit Plans

[0001032975-16-000083:notes:130]
Employee Share Purchase Plans and Stock Incentive Plans

[0001032975-16-000083:notes:131]
As of March 31, 2016, the Company offers the 2006 ESPP (2006 Employee Share Purchase Plan (Non-U.S.)), the 1996 ESPP (1996 Employee Share Purchase Plan (U.S.)), the 2006 Plan (2006 Stock Incentive Plan) and the 2012 Plan (2012 Stock Inducement Equity Plan). Shares issued to employees as a result of purchases or exercises under these plans are generally issued from shares held in treasury stock.

[0001032975-16-000083:notes:132]
The following table summarizes share-based compensation expense and related tax benefit recognized for fiscal years 2016, 2015 and 2014 (in thousands):

[0001032975-16-000083:notes:133]
|  |  | Years Ended March 31, |
|  |  | 2016 |  | 2015 |  | 2014 |
| Cost of goods sold |  | $ | 2,340 |  |  | $ | 2,474 |  |  | $ | 2,518 |  |
| Marketing and selling |  | 9,273 |  |  | 8,570 |  |  | 7,848 |  |
| Research and development |  | 3,046 |  |  | 2,381 |  |  | 2,811 |  |
| General and administrative |  | 12,353 |  |  | 10,766 |  |  | 10,051 |  |
| Restructuring |  | 7 |  |  | — |  |  | — |  |
| Total share-based compensation expense |  | 27,019 |  |  | 24,191 |  |  | 23,228 |  |
| Income tax benefit |  | (6,297 | ) |  | (4,814 | ) |  | (4,447 | ) |
| Total share-based compensation expense, net of income tax |  | $ | 20,722 |  |  | $ | 19,377 |  |  | $ | 18,781 |  |

[0001032975-16-000083:notes:134]
As of March 31, 2016, 2015 and 2014, the Company capitalized $0.5 million, $0.5 million and $0.4 million, respectively, of stock-based compensation expenses as inventory.

[0001032975-16-000083:notes:135]
The following table summarizes total unamortized share-based compensation expense and the remaining months over which such expense is expected to be recognized, on a weighted-average basis by type of grant (in thousands, except number of months):

[0001032975-16-000083:notes:136]
|  |  | March 31, 2016 |
|  |  | UnamortizedExpense |  | RemainingMonths |
| Stock options and ESPP |  | $ | 964 |  |  | 4 |
| Time-based RSUs |  | 25,734 |  |  | 22 |
| Market-based and performance-based RSUs |  | 9,529 |  |  | 18 |
|  |  | $ | 36,227 |  |  |  |

[0001032975-16-000083:notes:137]
Under the 1996 ESPP and 2006 ESPP plans, eligible employees may purchase shares at the lower of 85% of the fair market value at the beginning or the end of each offering period, which is generally six months. Subject to continued participation in these plans, purchase agreements are automatically executed at the end of each offering period. An aggregate of 29 million shares was reserved for issuance under the 1996 and 2006 ESPP plans. As of March 31, 2016, a total of 7.2 million shares were available for issuance under these plans. The Company was not current with its periodic reports required to be filed with the SEC and was therefore unable to issue any shares under its Registration Statements on Form S-8 from July 31, 2014 to November 26, 2014. Given the proximity of the unavailability of those registration statements and the end of the then-current ESPP offering period, on July 31, 2014, the Compensation Committee authorized the termination of the then-current ESPP offering period and a one-time payment to each participant in an amount equal to the fifteen percent (15%) discount at which shares would otherwise have been repurchased pursuant to the then-current period of the ESPPs. This one-time payment aggregating to $1.1 million was accounted for as a repurchase of equity awards that reduced additional paid-in capital, resulting in no additional compensation cost. A new ESPP offering period of seven months was initiated on January 1, 2015, which ended on July 31, 2015. Subsequent to that, the offering periods have returned to standard six months.

[0001032975-16-000083:notes:138]
The 2006 Plan provides for the grant to eligible employees and non-employee directors of stock options, stock appreciation rights, restricted stock and RSUs. Awards under the 2006 Plan may be conditioned on continued employment, the passage of time or the satisfaction of performance and market vesting criteria. The 2006 Plan had an expiration date of June 16, 2016 until September 5, 2012 when shareholder approved the amendment of the 2006 Plan to eliminate the expiration date. All stock options under this plan have terms not exceeding ten years and are issued at exercise prices not less than the fair market value on the date of grant.

[0001032975-16-000083:notes:139]
Time-based RSUs granted to employees under the 2006 Plan generally vest in four equal annual installments on the grant date anniversary. Time-based RSUs granted to non-executive board members under the 2006 Plan vest in one annual installment on the grant date anniversary. Performance-based RSUs granted under the 2006 plan vest contingent upon the achievement of pre-determined financial metrics. The performance period for performance-based RSUs granted in fiscal year 2015 is three years. Market-based options granted under the 2006 Plan vest upon meeting certain share price performance criteria. Market-based RSUs granted under the 2006 Plan vest at the end of the performance period upon meeting certain share price performance criteria measured against market conditions. The performance period is four years for market-based options granted in fiscal year 2013. The performance period is three years for market-based RSU granted in fiscal years 2016, 2015 and 2014. An aggregate of 24.8 million shares was reserved for issuance under the 2006 Plan. As of March 31, 2016, a total of 7.8 million shares were available for issuance under this plan.

[0001032975-16-000083:notes:140]
Under the 2012 Plan, stock options and RSUs may be granted to eligible employees to serve as inducement material to enter into employment with the Company. Awards under the 2012 Plan may be conditioned on continued employment, the passage of time or the satisfaction of market stock performance criteria, based on individual written employment offer letter. The 2012 Plan has an expiration date of March 28, 2022. Premium-priced stock options granted under the 2012 Plan vest in full if and only when Logitech's average closing share price, over a consecutive ninety-day trading period, meets or exceeds the exercise price of each of the three tranches of the grant. An aggregate of 1.8 million shares was reserved for issuance under the 2012 Plan. As of March 31, 2016, no shares were available for issuance under this plan.

[0001032975-16-000083:notes:141]
The estimates of share-based compensation expense require a number of complex and subjective assumptions including stock price volatility, employee exercise patterns, future forfeitures, probability of achievement of the set performance condition, dividend yield, related tax effects and the selection of an appropriate fair value model.

[0001032975-16-000083:notes:142]
The dividend yield assumption is based on the Company's future expectations of dividend payouts. The unvested RSUs or unexercised options are not eligible for these dividends. The expected life is based on historical settlement rates, which the Company believes are most representative of future exercise and post-vesting termination behaviors, or the purchase offerings periods expected to remain outstanding, or the derived period based on the expected stock performance for market-based awards. Expected volatility is based on historical volatility using the Company's daily closing prices, or including the volatility of components of the NASDAQ 100 index for market-based RSUs, over the expected life. The Company considers the historical price volatility of its shares as most representative of future volatility. The risk-free interest rate assumptions are based upon the implied yield of U.S. Treasury zero-coupon issues appropriate for the expected life of the Company's share-based awards.

[0001032975-16-000083:notes:143]
The Company estimates awards forfeitures at the time of grant and revises those estimates in subsequent periods if actual forfeitures differ from those estimates. The Company uses historical data to estimate pre-vesting option and RSU forfeitures and records share-based compensation expense only for those awards that are expected to vest.

[0001032975-16-000083:notes:144]
The Company estimates the probability and timing of the achievement of the set performance condition at the time of the grant based on the historical financial performance and the financial forecast in the remaining performance contingency period and reassesses the probability in subsequent periods when actual results or new information become available.

[0001032975-16-000083:notes:145]
A summary of the Company's stock option activities under all stock plans for fiscal years 2016, 2015 and 2014 is as follows (including discontinued operations for all the periods presented):

[0001032975-16-000083:notes:146]
|  |  | Number of Shares |  | Weighted-Average Exercise Price |  | Weighted-Average Remaining Contractual Term |  | Aggregate Intrinsic Value |
|  |  | (In thousands) |  |  |  | (Years) |  | (In thousands) |
| Outstanding, March 31, 2013 |  | 13,684 |  |  |  |  |  |  |  |  |
| Granted |  | — |  |  |  |  |  |  |  |  |
| Exercised |  | (551 | ) |  |  |  |  |  |  | $ | 2,045 |  |
| Cancelled or expired |  | (3,317 | ) |  |  |  |  |  |  |  |
| Outstanding, March 31, 2014 |  | 9,816 |  |  |  |  |  |  |  |  |
| Granted |  | — |  |  |  |  |  |  |  |  |
| Exercised |  | (390 | ) |  |  |  |  |  |  | $ | 1,505 |  |
| Cancelled or expired |  | (1,550 | ) |  |  |  |  |  |  |  |
| Outstanding, March 31, 2015 |  | 7,876 |  |  | $ | 18 |  |  |  |  |  |  |
| Granted |  | — |  |  | $ | — |  |  |  |  |  |  |
| Exercised |  | (746 | ) |  | $ | 10 |  |  |  |  | $ | 4,026 |  |
| Cancelled or expired |  | (1,796 | ) |  | $ | 20 |  |  |  |  |  |  |
| Outstanding, March 31, 2016 |  | 5,334 |  |  | $ | 18 |  |  | 4.0 |  | $ | 12,436 |  |
| Vested and expected to vest, March 31, 2016 |  | 4,004 |  |  | $ | 19 |  |  | 3.2 |  | $ | 8,119 |  |
| Vested and exercisable, March 31, 2016 |  | 3,879 |  |  | $ | 20 |  |  | 3.1 |  | $ | 7,134 |  |

[0001032975-16-000083:notes:147]
The options outstanding as of March 31, 2016 above includes 1.3 million shares of unvested market-based awards. The number of shares expected to vest for market-based awards is calculated assuming March 31, 2016 were the end of the performance contingency period.

[0001032975-16-000083:notes:148]
As of March 31, 2016, the exercise price of outstanding options ranged from $1 to $40 per option.

[0001032975-16-000083:notes:149]
The tax benefit realized for the tax deduction from options exercised during the fiscal years 2016, 2015 and 2014 was $1.2 million, $0.5 million and $0.5 million, respectively.

[0001032975-16-000083:notes:150]
A summary of the Company's time-based, market-based, and performance-based RSU activities for fiscal years 2016, 2015 and 2014 is as follows (including discontinued operations for all the periods presented):

[0001032975-16-000083:notes:151]
|  |  | Number of Shares |  | Weighted-Average Grant Date Fair Value |  | Weighted-Average Remaining Vesting Period |  | Aggregate Fair Value |
|  |  | (In thousands) |  |  |  | (Years) |  | (In thousands) |
| Outstanding, March 31, 2013 |  | 4,642 |  |  | $ | 10 |  |  |  |  |  |
| Granted—time-based |  | 3,104 |  |  | $ | 11 |  |  |  |  |  |
| Granted—market-based |  | 1,060 |  |  | $ | 8 |  |  |  |  |  |
| Vested |  | (1,560 | ) |  | $ | 9 |  |  |  |  | $ | 17,810 |  |
| Cancelled or expired |  | (1,158 | ) |  | $ | 15 |  |  |  |  |  |
| Outstanding, March 31, 2014 |  | 6,088 |  |  | $ | 10 |  |  |  |  |  |
| Granted—time-based |  | 1,332 |  |  | $ | 13 |  |  |  |  |  |
| Granted—market-based |  | 523 |  |  | $ | 13 |  |  |  |  |  |
| Granted - performance-based |  | 55 |  |  | $ | 12 |  |  |  |  |  |
| Vested |  | (1,949 | ) |  | $ | 10 |  |  |  |  | $ | 27,844 |  |
| Cancelled or expired |  | (1,110 | ) |  | $ | 11 |  |  |  |  |  |
| Outstanding, March 31, 2015 |  | 4,939 |  |  | $ | 11 |  |  |  |  |  |
| Granted—time-based |  | 2,247 |  |  | $ | 13 |  |  |  |  |  |
| Granted—market-based |  | 356 |  |  | $ | 14 |  |  |  |  |  |
| Granted - performance-based |  | 356 |  |  | $ | 13 |  |  |  |  |  |
| Vested |  | (1,557 | ) |  | $ | 10 |  |  |  |  | $ | 22,823 |  |
| Cancelled or expired |  | (820 | ) |  | $ | 12 |  |  |  |  |  |
| Outstanding, March 31, 2016 |  | 5,521 |  |  | $ | 12 |  |  | 1.5 |  | $ | 87,837 |  |
| Expected to vest, March 31, 2016 |  | 4,687 |  |  | $ | 12 |  |  | 1.2 |  | $ | 74,352 |  |

[0001032975-16-000083:notes:152]
The RSU outstanding as of March 31, 2016 above includes 1.7 million shares of market-based and performance-based shares. The number of shares expected to vest for these awards is calculated assuming March 31, 2016 were the end of the performance contingency period. The number of shares of common stock for market-based awards to be received at vesting will range from zero percent to 150 percent of the target number of stock units based on the Company's total stockholder return (“TSR”) relative to the performance of companies in the NASDAQ-100 Index for each measurement period, generally over a three year period. The Company presents shares granted at 100 percent of target of the number of stock units that may potentially vest.

[0001032975-16-000083:notes:153]
The tax benefit realized for the tax deduction from RSUs that vested during the fiscal years 2016, 2015 and 2014 was $5.1 million, $6.9 million and $4.7 million, respectively.

[0001032975-16-000083:notes:154]
Defined Contribution Plans

[0001032975-16-000083:notes:155]
Certain of the Company's subsidiaries have defined contribution employee benefit plans covering all or a portion of their employees. Contributions to these plans are discretionary for certain plans and are based on specified or statutory requirements for others. The charges to expense for these plans for fiscal years 2016, 2015 and 2014, were $6.8 million, $5.5 million and $6.3 million, respectively.

[0001032975-16-000083:notes:156]
Defined Benefit Plans

[0001032975-16-000083:notes:157]
Certain of the Company's subsidiaries sponsor defined benefit pension plans or non-retirement post-employment benefits covering substantially all of their employees. Benefits are provided based on employees' years of service and earnings, or in accordance with applicable employee benefit regulations. The Company's practice is to fund amounts sufficient to meet the requirements set forth in the applicable employee benefit and tax regulations.

[0001032975-16-000083:notes:158]
The Company recognizes the overfunded or underfunded status of defined benefit pension plans and non-retirement post-employment benefit obligations as an asset or liability in its consolidated balance sheets, and recognizes changes in the funded status of defined benefit pension plans in the year in which the changes occur through accumulated other comprehensive income (loss), which is a component of shareholders' equity. Each plan's assets and benefit obligations are remeasured as of March 31 each year.

[0001032975-16-000083:notes:159]
Except for the balance as of March 31, 2016, all the amounts in this "Defined Benefit Plans" section include activities from both continuing and discontinued operations for all the periods presented, and the amounts from discontinued operations are not material for all the periods presented.

[0001032975-16-000083:notes:160]
The net periodic benefit cost of the defined benefit pension plans and the non-retirement post-employment benefit obligations for fiscal years 2016, 2015 and 2014 was as follows (in thousands):

[0001032975-16-000083:notes:161]
|  |  | Years Ended March 31, |
|  |  | 2016 |  | 2015 |  | 2014 |
| Service costs |  | $ | 10,117 |  |  | $ | 7,646 |  |  | $ | 8,591 |  |
| Interest costs |  | 1,147 |  |  | 1,970 |  |  | 1,794 |  |
| Expected return on plan assets |  | (1,657 | ) |  | (2,084 | ) |  | (1,727 | ) |
| Amortization: |  |  |  |  |  |  |
| Net transition obligation |  | 4 |  |  | 4 |  |  | 4 |  |
| Net prior service costs (credit) recognized |  | (124 | ) |  | (45 | ) |  | 210 |  |
| Net actuarial loss recognized |  | 1,854 |  |  | 301 |  |  | 592 |  |
| Settlement and curtailment |  | — |  |  | (13 | ) |  | 769 |  |
|  |  | $ | 11,341 |  |  | $ | 7,779 |  |  | $ | 10,233 |  |

[0001032975-16-000083:notes:162]
The changes in projected benefit obligations for fiscal years 2016 and 2015 were as follows (in thousands):

[0001032975-16-000083:notes:163]
|  |  | Years Ended March 31, |
|  |  | 2016 |  | 2015 |
| Projected benefit obligations, beginning of the year |  | $ | 113,323 |  |  | $ | 102,383 |  |
| Service costs |  | 10,117 |  |  | 7,646 |  |
| Interest costs |  | 1,147 |  |  | 1,970 |  |
| Plan participant contributions |  | 2,990 |  |  | 2,914 |  |
| Actuarial (gains) losses |  | (2,496 | ) |  | 16,768 |  |
| Benefits paid |  | (5,277 | ) |  | (5,307 | ) |
| Plan amendment related to statutory change |  | — |  |  | (3,936 | ) |
| Settlement and curtailment |  | — |  |  | (157 | ) |
| Administrative expense paid |  | — |  |  | (160 | ) |
| Currency exchange rate changes |  | 669 |  |  | (8,798 | ) |
| Projected benefit obligations, end of the year |  | $ | 120,473 |  |  | $ | 113,323 |  |

[0001032975-16-000083:notes:164]
The accumulated benefit obligation for all defined benefit pension plans as of March 31, 2016 and 2015 was $99.5 million and $92.0 million, respectively.

[0001032975-16-000083:notes:165]
The following table presents the changes in the fair value of defined benefit pension plan assets for fiscal years 2016 and 2015 (in thousands):

[0001032975-16-000083:notes:166]
|  |  | Years Ended March 31, |
|  |  | 2016 |  | 2015 |
| Fair value of plan assets, beginning of the year |  | $ | 60,910 |  |  | $ | 63,384 |  |
| Actual return on plan assets |  | (1,160 | ) |  | 136 |  |
| Employer contributions |  | 7,171 |  |  | 5,731 |  |
| Plan participant contributions |  | 2,990 |  |  | 2,914 |  |
| Benefits paid |  | (5,277 | ) |  | (5,307 | ) |
| Settlement and curtailment |  | — |  |  | (157 | ) |
| Administrative expenses paid |  | — |  |  | (160 | ) |
| Currency exchange rate changes |  | 645 |  |  | (5,631 | ) |
| Fair value of plan assets, end of the year |  | $ | 65,279 |  |  | $ | 60,910 |  |

[0001032975-16-000083:notes:167]
The Company's investment objectives are to ensure that the assets of its defined benefit plans are invested to provide an optimal rate of investment return on the total investment portfolio, consistent with the assumption of a reasonable risk level, and to ensure that pension funds are available to meet the plans' benefit obligations as they become due. The Company believes that a well-diversified investment portfolio will result in the highest attainable investment return with an acceptable level of overall risk. Investment strategies and allocation decisions are also governed by applicable governmental regulatory agencies. The Company's investment strategy with respect to its largest defined benefit plan, which is available only to Swiss employees, is to invest in the following allocation ranges starting from January 2015: 20-55% for equities, 25-65% for bonds, and 0-20% for cash and cash equivalents. The Company also can invest in real estate funds, commodity funds, and hedge funds depend upon economic conditions.

[0001032975-16-000083:notes:168]
The following tables present the fair value of the defined benefit pension plan assets by major categories and by levels within the fair value hierarchy as of March 31, 2016 and 2015 (in thousands):

[0001032975-16-000083:notes:169]
|  |  | March 31, |
|  |  | 2016 |  | 2015 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Cash |  | $ | 9,268 |  |  | $ | 47 |  |  | $ | — |  |  | $ | 9,315 |  |  | $ | 7,958 |  |  | $ | 46 |  |  | $ | — |  |  | $ | 8,004 |  |
| Equity securities |  | 18,640 |  |  | — |  |  | — |  |  | 18,640 |  |  | 20,476 |  |  | — |  |  | — |  |  | 20,476 |  |
| Debt securities |  | 21,781 |  |  | — |  |  | — |  |  | 21,781 |  |  | 20,357 |  |  | — |  |  | — |  |  | 20,357 |  |
| Swiss real estate funds |  | 9,622 |  |  | — |  |  | — |  |  | 9,622 |  |  | 8,586 |  |  | — |  |  | — |  |  | 8,586 |  |
| Hedge funds |  | — |  |  | 3,492 |  |  | — |  |  | 3,492 |  |  | — |  |  | 3,251 |  |  | — |  |  | 3,251 |  |
| Insurance contracts |  | — |  |  | 94 |  |  | — |  |  | 94 |  |  | — |  |  | 114 |  |  | — |  |  | 114 |  |
| Other |  | 2,195 |  |  | 140 |  |  | — |  |  | 2,335 |  |  | 28 |  |  | 94 |  |  | — |  |  | 122 |  |
|  |  | $ | 61,506 |  |  | $ | 3,773 |  |  | $ | — |  |  | $ | 65,279 |  |  | $ | 57,405 |  |  | $ | 3,505 |  |  | $ | — |  |  | $ | 60,910 |  |

[0001032975-16-000083:notes:170]
The funded status of the plans was as follows (in thousands):

[0001032975-16-000083:notes:171]
|  |  | Years Ended March 31, |
|  |  | 2016 |  | 2015 |
| Fair value of plan assets |  | $ | 65,279 |  |  | $ | 60,910 |  |
| Less: Projected benefit obligations |  | 120,473 |  |  | 113,323 |  |
| Under funded status |  | $ | (55,194 | ) |  | $ | (52,413 | ) |

[0001032975-16-000083:notes:172]
Amounts recognized on the balance sheet for the plans were as follows (in thousands):

[0001032975-16-000083:notes:173]
|  |  | March 31, |
|  |  | 2016 |  | 2015 |
| Current liabilities |  | $ | (1,285 | ) |  | $ | (1,232 | ) |
| Non-current liabilities |  | (53,909 | ) |  | (51,181 | ) |
| Net liabilities |  | $ | (55,194 | ) |  | $ | (52,413 | ) |

[0001032975-16-000083:notes:174]
Amounts recognized in accumulated other comprehensive loss related to defined benefit pension plans were as follows (in thousands):

[0001032975-16-000083:notes:175]
|  |  | March 31, |
|  |  | 2016 |  | 2015 |  | 2014 |
| Net prior service costs (credits) |  | $ | 1,613 |  |  | $ | 1,672 |  |  | $ | (2,149 | ) |
| Net actuarial loss |  | (27,612 | ) |  | (28,751 | ) |  | (12,319 | ) |
| Net transition obligation |  | (4 | ) |  | (8 | ) |  | (12 | ) |
| Accumulated other comprehensive loss |  | (26,003 | ) |  | (27,087 | ) |  | (14,480 | ) |
| Deferred tax benefit |  | (168 | ) |  | 123 |  |  | 192 |  |
| Accumulated other comprehensive loss, net of tax |  | $ | (26,171 | ) |  | $ | (26,964 | ) |  | $ | (14,288 | ) |

[0001032975-16-000083:notes:176]
The following table presents the amounts included in accumulated other comprehensive loss as of March 31, 2016, which are expected to be recognized as a component of net periodic benefit cost in fiscal year 2017 (in thousands):

[0001032975-16-000083:notes:177]
|  |  | Year EndingMarch 31, 2017 |
| Amortization of net transition obligation |  | $ | 4 |  |
| Amortization of net prior service credits |  | (128 | ) |
| Amortization of net actuarial loss |  | 1,650 |  |
|  |  | $ | 1,526 |  |

[0001032975-16-000083:notes:178]
The Company reassesses its benefit plan assumptions on a regular basis. The actuarial assumptions for the defined benefit plans for fiscal years 2016 and 2015 were as follows:

[0001032975-16-000083:notes:179]
|  |  | Years Ended March 31, |
|  |  | 2016 |  | 2015 |
| Benefit Obligations: |  |  |  |  |
| Discount rate |  | 0.5%-8.00% |  | 0.75%-7.75% |
| Estimated rate of compensation increase |  | 2.50%-10.00% |  | 2.50%-8.00% |
| Periodic Costs: |  |  |  |  |
| Discount rate |  | 0.75%-7.75% |  | 1.50%-9.25% |
| Estimated rate of compensation increase |  | 0.0%-8.00% |  | 2.50%-8.00% |
| Expected average rate of return on plan assets |  | 1.00%-2.75% |  | 0.75%-3.50% |

[0001032975-16-000083:notes:180]
The discount rate is estimated based on corporate bond yields or securities of similar quality in the respective country, with a duration approximating the period over which the benefit obligations are expected to be paid. The Company bases the compensation increase assumptions on historical experience and future expectations. The expected average rate of return for the Company's defined benefit pension plans represents the average rate of return expected to be earned on plan assets over the period that the benefit obligations are expected to be paid, based on government bond notes in the respective country, adjusted for corporate risk premiums as appropriate.

[0001032975-16-000083:notes:181]
The following table reflects the benefit payments that the Company expects the plans to pay in the periods noted (in thousands):

[0001032975-16-000083:notes:182]
| Years Ending March 31, |  |  |
| 2017 |  | $ | 4,751 |  |
| 2018 |  | 4,954 |  |
| 2019 |  | 5,307 |  |
| 2020 |  | 6,026 |  |
| 2021 |  | 5,241 |  |
| 2022-2026 |  | 29,520 |  |
|  |  | $ | 55,799 |  |

[0001032975-16-000083:notes:183]
The Company expects to contribute $4.9 million to its defined benefit pension plans during fiscal year 2017.

[0001032975-16-000083:notes:184]
Deferred Compensation Plan

[0001032975-16-000083:notes:185]
One of the Company's subsidiaries offers a deferred compensation plan that permits eligible employees to make 100% vested salary and incentive compensation deferrals within established limits. The Company does not make contributions to the plan.

[0001032975-16-000083:notes:186]
The deferred compensation plan's assets consist of marketable securities and are included in other assets on the consolidated balance sheets. The marketable securities are classified as trading investments and were recorded at a fair value of $14.8 million and $17.2 million as of March 31, 2016 and 2015, respectively, based on quoted market prices. The Company also had $14.8 million and $17.2 million deferred compensation liability as of March 31, 2016 and 2015, respectively. Earnings, gains and losses on trading investments are included in other income (expense), net and corresponding changes in deferred compensation liability are included in operating expenses and cost of goods sold.


## us-gaap:DebtDisclosureTextBlock

[0001032975-16-000083:notes:187]
Financing Arrangements

[0001032975-16-000083:notes:188]
The Company had several uncommitted, unsecured bank lines of credit aggregating $45.7 million as of March 31, 2016. There are no financial covenants under these lines of credit with which the Company must comply. As of March 31, 2016, the Company had outstanding bank guarantees of $19.7 million under these lines of credit. There was no borrowing outstanding under the line of credit as of March 31, 2016 or March 31, 2015.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001032975-16-000083:notes:189]
The following table presents the fair values of the Company's derivative instruments as of March 31, 2016 and 2015 (in thousands):

[0001032975-16-000083:notes:190]
|  |  | Derivatives |
|  |  | Asset |  | Liability |
|  |  | March 31, |  | March 31, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash flow hedges |  | $ | 10 |  |  | $ | 2,080 |  |  | $ | 1,038 |  |  | $ | — |  |
| Not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | — |  |  | — |  |  | 94 |  |  | 75 |  |
|  |  | $ | 10 |  |  | $ | 2,080 |  |  | $ | 1,132 |  |  | $ | 75 |  |

[0001032975-16-000083:notes:191]
Under certain agreements with the respective counterparties to the Company's derivative contracts, subject to applicable requirements, the Company is allowed to net settle transactions of the same type with a single net amount payable by one party to the other. However, the Company presents its derivative assets and derivative liabilities on a gross basis in other current assets or accrued and other current liabilities on the Consolidated Balance Sheets as of March 31, 2016 and 2015.

[0001032975-16-000083:notes:192]
The following table presents the amounts of gains and losses on the Company's derivative instruments for fiscal years 2016, 2015 and 2014 and their locations on its consolidated statements of operations and consolidated statements of comprehensive income (loss) (in thousands):

[0001032975-16-000083:notes:193]
|  | Amount ofGain (Loss) Deferred asa Component ofAccumulated OtherComprehensive Loss After Reclassification to Costs of Goods Sold |  | Amount of Loss (Gain)Reclassified fromAccumulated OtherComprehensive Lossto Costs of Goods Sold |  | Amount ofGain (Loss)Immediately Recognizedin Other Income(Expense), Net |
|  | 2016 |  | 2015 |  | 2014 |  | 2016 |  | 2015 |  | 2014 |  | 2016 |  | 2015 |  | 2014 |
| Designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash flow hedges | $ | (5,727 | ) |  | $ | 4,466 |  |  | $ | (1,025 | ) |  | $ | (3,296 | ) |  | $ | (4,505 | ) |  | $ | 2,472 |  |  | $ | 292 |  |  | $ | 20 |  |  | $ | (126 | ) |
| Not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (781 | ) |  | 2,479 |  |  | 824 |  |
|  | $ | (5,727 | ) |  | $ | 4,466 |  |  | $ | (1,025 | ) |  | $ | (3,296 | ) |  | $ | (4,505 | ) |  | $ | 2,472 |  |  | $ | (489 | ) |  | $ | 2,499 |  |  | $ | 698 |  |

[0001032975-16-000083:notes:194]
Cash Flow Hedges:   The Company enters into foreign exchange forward contracts to hedge against exposure to changes in currency exchange rates related to its subsidiaries' forecasted inventory purchases. The Company has one entity with a Euro functional currency that purchases inventory in U.S. Dollars. The primary risk managed by using derivative instruments is the currency exchange rate risk. The Company has designated these derivatives as cash flow hedges. These hedging contracts mature within four months, and are denominated in the same currency as the underlying transactions. Gains and losses in the fair value of the effective portion of the hedges are deferred as a component of accumulated other comprehensive loss until the hedged inventory purchases are sold, at which time the gains or losses are reclassified to cost of goods sold. The Company assesses the effectiveness of the hedges by comparing changes in the spot rate of the currency underlying the forward contract with changes in the spot rate of the currency in which the forecasted transaction will be consummated. If the underlying transaction being hedged fails to occur or if a portion of the hedge does not generate offsetting changes in the currency exposure of forecasted inventory purchases, the Company immediately recognizes the gain or loss on the associated financial instrument in other income (expense), net. Such gains and losses were not material during fiscal years 2016, 2015 and 2014. Cash flows from such hedges are classified as operating activities in the Consolidated Statements of Cash Flows. As of March 31, 2016, and 2015, the notional amounts of foreign exchange forward contracts outstanding related to forecasted inventory purchases were $39.8 million and $43.5 million, respectively. The Company estimates that $1.8 million of net losses related to its cash flow hedges included in accumulated other comprehensive loss as of March 31, 2016 will be reclassified into earnings within the next 12 months.

[0001032975-16-000083:notes:195]
Other Derivatives:   The Company also enters into foreign exchange forward and swap contracts to reduce the short-term effects of currency fluctuations on certain foreign currency receivables or payables. These forward and swap contracts generally mature within one month. The primary risk managed by using forward and swap contracts is the currency exchange rate risk. The gains or losses on foreign exchange forward contracts are recognized in other income (expense), net based on the changes in fair value.

[0001032975-16-000083:notes:196]
The notional amounts of foreign exchange forward and swap contracts outstanding as of March 31, 2016 and 2015 relating to foreign currency receivables or payables were $63.7 million and $61.7 million, respectively. Open forward and swap contracts as of March 31, 2016 and 2015 consisted of contracts in Taiwanese Dollars, Australian Dollars, Mexican Pesos, Japanese Yen and British Pounds to be settled at future dates at pre-determined exchange rates.

[0001032975-16-000083:notes:197]
The fair value of all foreign exchange forward and swap contracts is determined based on observable market transactions of spot currency rates and forward rates. Cash flows from these contracts are classified as operating activities in the Consolidated Statements of Cash Flows.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001032975-16-000083:notes:198]
Discontinued Operations

[0001032975-16-000083:notes:199]
During the third quarter of fiscal year 2016, the Company's Board of Directors approved a plan to divest the Lifesize video conferencing business. On December 28, 2015 during the fourth quarter of fiscal year 2016, Logitech International S.A. (the "Company"), and Lifesize, Inc., a wholly owned subsidiary of the Company (“Lifesize”) which holds the assets of the Company’s video conferencing reportable segment, entered into a stock purchase agreement (the “Stock Purchase Agreement”) with entities affiliated with three venture capital investment firms (the "Venture Investors"). Pursuant to the terms of the Stock Purchase Agreement, the Company sold 2,500,000 shares of Series B Preferred Stock of Lifesize to the Venture Investors for cash proceeds of $2,500,000 and retained 12,000,000 non-voting shares of Series A Preferred Stock of Lifesize. The shares of Series A Preferred Stock of Lifesize retained by the Company represent 37.5% of the shares outstanding immediately after the closing of the transactions contemplated by the Stock Purchase Agreement (the “Closing”). Lifesize also issued 17,500,000 shares of Series B Preferred Stock to the Venture Investors for cash proceeds of $17,500,000. The shares of Series B Preferred Stock held by the Venture Investors represent 62.5% of the shares outstanding immediately after the Closing. In addition, Lifesize has reserved 8,000,000 shares of common stock for issuance pursuant to a stock plan to be adopted by Lifesize following the Closing (the “Employee Pool”), none of which are issued or outstanding at the Closing. Post the divestiture, continuing involvement with the discontinued operations includes certain customary services and support which are expected to be provided to Lifesize during the transition period from December 28, 2015 until approximately the end of the third quarter of fiscal year 2017.

[0001032975-16-000083:notes:200]
The Company has classified the results of its Lifesize video conferencing business as discontinued operations in its consolidated statement of operations for all periods presented since the disposition of the Lifesize video conferencing business represents a strategic shift as that has a major effect on the Company's operations and financial results. Additionally, the related assets and liabilities associated with the discontinued operations are classified separately in the assets and liability on its consolidated balance sheets for all periods presented. Evaluating whether the disposal of the business represents a strategic shift requires the Company's judgment. Also, evaluating whether the strategic shift will have a "major effect" on the Company's operations and financial results requires assessing not only quantitative factors but also the magnitude of qualitative factors.

[0001032975-16-000083:notes:201]
The retained Series A Preferred Stock gives the Company no voting rights or any other significant influence over the disposed Lifesize video conferencing business, and therefore is accounted for as a cost method investment which is initially recognized at fair value of $5.6 million at the date of disposition of Lifesize Video Conferencing business. The fair value was determined by using the option pricing methodology with reference to the price of Lifesize’s Series B Preferred Stock paid by Venture Investors. The fair value of the Company’s investment in Series A Preferred Stock is classified as Level 3 as application of the option pricing methodology requires use of significant unobservable inputs including asset volatility of 50%, expected term to exit of three years, and lack of marketability discount of 27%.

[0001032975-16-000083:notes:202]
Discontinued operations include results of the Lifesize video conferencing business. Discontinued operations also include other costs incurred by Logitech to effect the divestiture of the Lifesize video conferencing business. These costs include transaction charges, advisory and consulting fees and restructuring cost related to the Lifesize video conferencing business.

[0001032975-16-000083:notes:203]
The following table presents financial results of the video conferencing classified as discontinued operations (in thousands):

[0001032975-16-000083:notes:204]
|  |  | Years Ended March 31, |
|  |  | 2016 |  | 2015 |  | 2014 |
| Net sales |  | $ | 65,554 |  |  | $ | 109,039 |  |  | $ | 120,684 |  |
| Cost of goods sold |  | 24,951 |  |  | 40,299 |  |  | 54,355 |  |
| Gross profit |  | 40,603 |  |  | 68,740 |  |  | 66,329 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Marketing and selling |  | 32,260 |  |  | 56,856 |  |  | 57,040 |  |
| Research and development |  | 16,526 |  |  | 22,706 |  |  | 26,939 |  |
| General and administrative |  | 5,254 |  |  | 5,439 |  |  | 6,251 |  |
| Impairment of goodwill (#) |  | — |  |  | 122,734 |  |  | — |  |
| Restructuring charges (credits), net |  | 7,900 |  |  | (111 | ) |  | 5,810 |  |
| Operating expenses |  | 61,940 |  |  | 207,624 |  |  | 96,040 |  |
| Operating loss from discontinued operations |  | (21,337 | ) |  | (138,884 | ) |  | (29,711 | ) |
| Interest expense and other, net |  | 205 |  |  | 426 |  |  | 11 |  |
| Gain on disposal of discontinued operations |  | 13,684 |  |  | — |  |  | — |  |
| Loss from discontinued operations before income taxes |  | (7,858 | ) |  | (139,310 | ) |  | (29,722 | ) |
| Provision for (benefit from) income taxes |  | 1,187 |  |  | (164 | ) |  | 1,965 |  |
| Net loss from discontinued operations |  | $ | (9,045 | ) |  | $ | (139,146 | ) |  | $ | (31,687 | ) |

[0001032975-16-000083:notes:205]
(#) The Company recognized $122.7 million impairment of goodwill in its discontinued operations as result of its impairment analysis as of March 31, 2015. Refer to the Company's Annual Report on Form 10-K for fiscal year 2015.

[0001032975-16-000083:notes:206]
The following table presents the aggregate carrying amounts of the major classes of assets and liabilities removed from the consolidated balance sheet immediately before the disposition and assets liabilities of discontinued operations as of March 31, 2015 (in thousands):

[0001032975-16-000083:notes:207]
|  |  | Immediately before the disposition |  | March 31,2015 |
| Carrying amounts of assets included as part of discontinued operations: |  |  |  |  |
| Cash and cash equivalents |  | $ | 3,895 |  |  | $ | 3,659 |  |
| Accounts receivable, net |  | 10,360 |  |  | 12,627 |  |
| Inventories |  | 12,708 |  |  | 14,749 |  |
| Other current assets |  | 1,930 |  |  | 1,067 |  |
| Total current assets |  | 28,893 |  |  | 32,102 |  |
| Property, plant and equipment, net |  | 3,962 |  |  | 5,115 |  |
| Other assets |  | 1,125 |  |  | 2,521 |  |
| Total non-current assets |  | 5,087 |  |  | 7,636 |  |
| Total assets classified as assets from discontinued operations on the consolidated balance sheets |  | $ | 33,980 |  |  | $ | 39,738 |  |
| Carrying amounts of liabilities included as part of discontinued operations: |  |  |  |  |
| Accounts payable |  | $ | 2,382 |  |  | $ | 7,198 |  |
| Accrued and other current liabilities |  | 31,664 |  |  | 31,568 |  |
| Total current liabilities |  | 34,046 |  |  | 38,766 |  |
| Non-current liabilities |  | 9,915 |  |  | 10,337 |  |
| Total liabilities classified as liabilities from discontinued operations on the consolidated balance sheets |  | $ | 43,961 |  |  | $ | 49,103 |  |

[0001032975-16-000083:notes:208]
The Company recognized a gain on its divestiture of Lifesize video conferencing business as follows (in thousands):

[0001032975-16-000083:notes:209]
|  |  | Year Ended |
|  |  | March 31, 2016 |
| Proceeds received from disposition of discontinued operations |  | $ | 2,500 |  |
| Fair value of retained cost method investment as a result of divestiture of discontinued operations |  | 5,591 |  |
| Net liabilities of discontinued operations disposed |  | 9,981 |  |
| Currency translation loss released due to disposition of discontinued operations (1) |  | (3,913 | ) |
| Transaction related costs |  | (475 | ) |
| Gain on disposal of discontinued operations (2) |  | $ | 13,684 |  |

[0001032975-16-000083:notes:210]
| (1) | Currency translation loss recognized as a result of substantial liquidation of a subsidiary using non-USD functional currency, which is part of discontinued operations |

[0001032975-16-000083:notes:211]
| (2) | Gain on disposal of discontinued operation was included in loss from discontinued operations, net of income taxes, in the Company's consolidated statement of operations |


## us-gaap:EarningsPerShareTextBlock

[0001032975-16-000083:notes:212]
The computations of basic and diluted net income (loss) per share for the Company were as follows (in thousands except per share amounts):

[0001032975-16-000083:notes:213]
|  |  | Years Ended March 31, |
|  |  | 2016 |  | 2015 |  | 2014 |
| Net Income (loss): |  |  |  |  |  |  |
| Continuing operations |  | $ | 128,362 |  |  | $ | 148,429 |  |  | $ | 105,991 |  |
| Discontinued operations |  | (9,045 | ) |  | (139,146 | ) |  | (31,687 | ) |
| Net income |  | $ | 119,317 |  |  | $ | 9,283 |  |  | $ | 74,304 |  |
| Shares used in net income (loss) per share computation: |  |  |  |  |  |  |
| Weighted average shares outstanding - basic |  | 163,296 |  |  | 163,536 |  |  | 160,619 |  |
| Effect of potentially dilutive equivalent shares |  | 2,496 |  |  | 2,638 |  |  | 1,907 |  |
| Weighted average shares outstanding - diluted |  | 165,792 |  |  | 166,174 |  |  | 162,526 |  |
| Net income (loss) per share - basic: |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.79 |  |  | $ | 0.91 |  |  | $ | 0.66 |  |
| Discontinued operations |  | $ | (0.06 | ) |  | $ | (0.85 | ) |  | $ | (0.20 | ) |
| Net income per share - basic |  | $ | 0.73 |  |  | $ | 0.06 |  |  | $ | 0.46 |  |
| Net income (loss) per share - diluted: |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.77 |  |  | $ | 0.89 |  |  | $ | 0.65 |  |
| Discontinued operations |  | $ | (0.05 | ) |  | $ | (0.83 | ) |  | $ | (0.19 | ) |
| Net income per share - diluted |  | $ | 0.72 |  |  | $ | 0.06 |  |  | $ | 0.46 |  |

[0001032975-16-000083:notes:214]
During fiscal years 2016, 2015 and 2014, 5.2 million, 9.0 million and 15.1 million share equivalents attributable to outstanding stock options, RSUs and ESPP were excluded from the calculation of diluted net income (loss) per share because the combined exercise price, average unamortized fair value and assumed tax benefits upon exercise of these options and ESPP or vesting of RSUs were greater than the average market price of the Company's shares, and therefore their inclusion would have been anti-dilutive.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001032975-16-000083:notes:215]
Fair Value Measurements

[0001032975-16-000083:notes:216]
The Company considers fair value as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants at the measurement date. The Company utilizes the following three-level fair value hierarchy to establish the priorities of the inputs used to measure fair value:

[0001032975-16-000083:notes:217]
| • | Level 1—Quoted prices in active markets for identical assets or liabilities. |

[0001032975-16-000083:notes:218]
| • | Level 2—Observable inputs other than quoted market prices included in Level 1, such as quoted prices for similar assets and liabilities in active markets; quoted prices for identical or similar assets and liabilities in markets that are not active; or other inputs that are observable or can be corroborated by observable market data. |

[0001032975-16-000083:notes:219]
| • | Level 3—Unobservable inputs that are supported by little or no market activity and that are significant to the fair value of the assets or liabilities. This includes certain pricing models, discounted cash flow methodologies and similar techniques that use significant unobservable inputs. |

[0001032975-16-000083:notes:220]
The following table presents the Company's financial assets and liabilities, that were accounted for at fair value on a recurring basis, excluding assets related to the Company's defined benefit pension plans, classified by the level within the fair value hierarchy (in thousands):

[0001032975-16-000083:notes:221]
|  |  | March 31, 2016 |  | March 31, 2015 |
|  |  | Level 1 |  | Level 2 |  | Level 1 |  | Level 2 |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 10,000 |  |  | $ | — |  |  | $ | 264,647 |  |  | $ | — |  |
|  |  | $ | 10,000 |  |  | $ | — |  |  | $ | 264,647 |  |  | $ | — |  |
| Trading investments for deferred compensation plan: |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 3,467 |  |  | $ | — |  |  | $ | 2,936 |  |  | $ | — |  |
| Mutual funds |  | 11,369 |  |  | — |  |  | 14,301 |  |  | — |  |
|  |  | $ | 14,836 |  |  | $ | — |  |  | $ | 17,237 |  |  | $ | — |  |
| Foreign exchange derivative assets |  | $ | — |  |  | $ | 10 |  |  | $ | — |  |  | $ | 2,080 |  |
| Foreign exchange derivative liabilities |  | $ | — |  |  | $ | 1,132 |  |  | $ | — |  |  | $ | 75 |  |

[0001032975-16-000083:notes:222]
Investment Securities

[0001032975-16-000083:notes:223]
The marketable securities for the Company's deferred compensation plan are recorded at a fair value of $14.8 million and $17.2 million as of March 31, 2016 and 2015, respectively, based on quoted market prices. Quoted market prices are observable inputs that are classified as Level 1 within the fair value hierarchy. Unrealized trading gains related to trading securities for the fiscal years 2016, 2015 and 2014 were not significant and are included in other income (expense), net.

[0001032975-16-000083:notes:224]
Assets Measured at Fair Value on a Nonrecurring Basis

[0001032975-16-000083:notes:225]
The Company’s non-marketable cost method investments, and non-financial assets, such as intangible assets and property, plant and equipment, are recorded at fair value only upon initial recognition or if an impairment is recognized. A summary of the valuation methodologies for assets and liabilities measured on a nonrecurring basis is as follows:

[0001032975-16-000083:notes:226]
Non-marketable cost method investments. These investments are classified as Level 3 due to the absence of quoted market prices, the inherent lack of liquidity, and the fact that inputs used to measure fair value are unobservable and require management's judgment. When certain events or circumstances indicate that impairment may exist, the Company revalues the investments using various assumptions, including the financial metrics and ratios of comparable public companies. There were no significant impairments during the years ended March 31, 2016 or 2015.

[0001032975-16-000083:notes:227]
Included in non-marketable investments primarily is the Company’s investment in Series A Preferred Stock of Lifesize recorded at the estimated fair value of $5.6 million on the date of Lifesize divestiture. Refer to Note 3 "Discontinued Operations" to Consolidated Financial Statements for the valuation approach and significant inputs and assumptions.

[0001032975-16-000083:notes:228]
The aggregate recorded amount of cost method investments included in other assets at March 31, 2016 and March 31, 2015 was $7.4 million and $0.3 million, respectively.

[0001032975-16-000083:notes:229]
Non-Financial Assets. Goodwill, intangible assets, and property, plant and equipment, are not required to be measured at fair value on a recurring basis. However, if certain triggering events occur (or tested at least annually for goodwill) such that a non-financial instrument is required to be evaluated for impairment and an impairment is recorded to reduce the non-financial instrument's carrying value to the fair value as a result of such triggering events, the non-financial assets and liabilities are measured at fair value for the period such triggering events occur. See Note 2 herein, for additional information about how the Company tests various asset classes for impairment.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001032975-16-000083:notes:230]
As of December 31, 2015 and March 31, 2015, all of the Company's goodwill is related to the peripherals reporting unit. The Company performed its annual impairment analysis of the goodwill at December 31, 2015 by performing a qualitative assessment and concluded that it was more likely than not that the fair value of its peripherals reporting unit exceeded its carrying amount.  In assessing the qualitative factors, the Company considered the impact of these key factors: change in industry and competitive environment, growth in market capitalization to $2.5 billion as of December 31, 2015 from $2.3 billion as of December 31, 2014, and budgeted-to-actual revenue performance for the twelve months ended December 31, 2015.  There have been no significant events or circumstances affecting the valuation of goodwill subsequent to the annual impairment test.

[0001032975-16-000083:notes:231]
The following table summarizes the activity in the Company's goodwill balance during fiscal years 2016 and 2015 (in thousands):

[0001032975-16-000083:notes:232]
|  |  | Years Ended March 31, |
|  |  | 2016 |  | 2015 |
| Beginning of the period |  | $ | 218,213 |  |  | $ | 219,415 |  |
| Acquisitions |  | — |  |  | 988 |  |
| Currency exchange rate impact and other |  | 11 |  |  | (2,190 | ) |
| End of the period |  | $ | 218,224 |  |  | $ | 218,213 |  |

[0001032975-16-000083:notes:233]
The Company's acquired other intangible assets are not material as of March 31, 2016 and 2015. There is no addition or disposition of acquired other intangible assets during the years ended March 31, 2016 and 2015.

[0001032975-16-000083:notes:234]
For fiscal years 2016, 2015 and 2014, amortization expense for other intangible assets was $0.4 million, $0.8 million and $2.4 million, respectively. There was no future amortization expense related to the intangible asset as of March 31, 2016.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001032975-16-000083:notes:235]
The Company is incorporated in Switzerland but operates in various countries with differing tax laws and rates. Further, a portion of the Company's income (loss) before taxes and the provision for (benefit from) income taxes is generated outside of Switzerland.

[0001032975-16-000083:notes:236]
Income from continuing operations before income taxes for the fiscal years 2016, 2015 and 2014 is summarized as follows (in thousands):

[0001032975-16-000083:notes:237]
|  |  | Years Ended March 31, |
|  |  | 2016 |  | 2015 |  | 2014 |
| Swiss |  | $ | 80,572 |  |  | $ | 119,460 |  |  | $ | 62,544 |  |
| Non-Swiss |  | 50,900 |  |  | 33,623 |  |  | 44,760 |  |
| Income before taxes |  | $ | 131,472 |  |  | $ | 153,083 |  |  | $ | 107,304 |  |

[0001032975-16-000083:notes:238]
The provision for (benefit from) income taxes is summarized as follows (in thousands):

[0001032975-16-000083:notes:239]
|  |  | Years Ended March 31, |
|  |  | 2016 |  | 2015 |  | 2014 |
| Current: |  |  |  |  |  |  |
| Swiss |  | $ | 1,668 |  |  | $ | 1,152 |  |  | $ | 814 |  |
| Non-Swiss |  | (2,582 | ) |  | 579 |  |  | 6,219 |  |
| Deferred: |  |  |  |  |  |  |
| Non-Swiss |  | 4,024 |  |  | 2,923 |  |  | (5,720 | ) |
| Provision for income taxes |  | $ | 3,110 |  |  | $ | 4,654 |  |  | $ | 1,313 |  |

[0001032975-16-000083:notes:240]
The difference between the provision for income taxes and the expected tax provision at the statutory income tax rate of 8.5% is reconciled below (in thousands):

[0001032975-16-000083:notes:241]
|  |  | Years Ended March 31, |
|  |  | 2016 |  | 2015 |  | 2014 |
| Expected tax provision at statutory income tax rates |  | $ | 11,175 |  |  | $ | 13,012 |  |  | $ | 9,121 |  |
| Income taxes at different rates |  | (2,713 | ) |  | (4,299 | ) |  | (2,523 | ) |
| Research and development tax credits |  | (1,619 | ) |  | (1,120 | ) |  | (1,229 | ) |
| Executive compensation |  | 864 |  |  | 1,557 |  |  | — |  |
| Stock-based compensation |  | 1,446 |  |  | 2,261 |  |  | 1,608 |  |
| Valuation allowance |  | 947 |  |  | 764 |  |  | 182 |  |
| Restructuring charges / (credits) |  | 1,514 |  |  | (415 | ) |  | 1,174 |  |
| Tax reserves (releases), net |  | (8,761 | ) |  | (6,912 | ) |  | (6,209 | ) |
| Audit settlement |  | — |  |  | (837 | ) |  | (400 | ) |
| Other, net |  | 257 |  |  | 643 |  |  | (411 | ) |
| Provision for income taxes |  | $ | 3,110 |  |  | $ | 4,654 |  |  | $ | 1,313 |  |

[0001032975-16-000083:notes:242]
On December 18, 2015, the enactment of the Protecting Americans from Tax Hikes Act of 2015 in the United States extended the federal research and development tax credit permanently which had previously expired on December 31, 2014. The provision for income taxes for fiscal year ended March 31, 2016 reflected a $1.5 million tax benefit as a result of the extension of the tax credit.

[0001032975-16-000083:notes:243]
Deferred income tax assets and liabilities consist of the following (in thousands):

[0001032975-16-000083:notes:244]
|  |  | March 31, |
|  |  | 2016 |  | 2015 |
| Deferred tax assets: |  |  |  |  |  |  |
| Net operating loss carryforwards |  | $ | 7,136 |  |  | $ | 8,372 |  |
| Tax credit carryforwards |  | 2,981 |  |  | 2,739 |  |
| Accruals |  | 36,365 |  |  | 44,363 |  |
| Depreciation and amortization |  | 4,059 |  |  | 4,396 |  |
| Share-based compensation |  | 12,890 |  |  | 14,183 |  |
| Gross deferred tax assets |  | 63,431 |  |  | 74,053 |  |
| Valuation allowance |  | (5,338 | ) |  | (5,590 | ) |
| Gross deferred tax assets after valuation allowance |  | 58,093 |  |  | 68,463 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |
| Acquired intangible assets and other |  | (3,550 | ) |  | (3,299 | ) |
| Gross deferred tax liabilities |  | (3,550 | ) |  | (3,299 | ) |
| Deferred tax assets, net |  | $ | 54,543 |  |  | $ | 65,164 |  |

[0001032975-16-000083:notes:245]
Management regularly assesses the ability to realize deferred tax assets recorded in the Company's entities based upon the weight of available evidence, including such factors as recent earnings history and expected future taxable income. In the event that the Company changes its determination as to the amount of deferred tax assets that can be realized, the Company will adjust its valuation allowance with a corresponding impact to the provision for income taxes in the period in which such determination is made.

[0001032975-16-000083:notes:246]
The Company had a valuation allowance of $5.3 million at March 31, 2016, decreased from $5.6 million at March 31, 2015 primarily due to $1.3 million increase in valuation allowance for deferred tax assets in the state of California of the United States which was offset by $1.5 million decrease in valuation allowance due to the expiration of capital loss carryforwards in the United States. The Company had a valuation allowance of $4.9 million as of March 31, 2016 against deferred tax assets in the state of California of the United States. The remaining valuation allowance primarily represents $0.4 million for various tax credit carryforwards. The Company determined that it is more likely than not that the Company would not generate sufficient taxable income in the future to utilize such deferred tax assets.

[0001032975-16-000083:notes:247]
Deferred tax assets relating to tax benefits of employee stock grants have been reduced to reflect settlement activity in fiscal years 2016 and 2015. Settlement activity of grants in fiscal years 2016 and 2015 resulted in a "shortfall" in which tax deductions were less than previously recorded share-based compensation expense. The Company recorded a shortfall to equity of $2.3 million and $1.8 million, respectively, in fiscal years 2016 and 2015.

[0001032975-16-000083:notes:248]
As of March 31, 2016, the Company had foreign net operating loss and tax credit carryforwards for income tax purposes of $203.5 million and $43.8 million, respectively, of which $146.0 million of the net operating loss carryforwards and $26.6 million of the tax credit carryforwards, if realized, will be credited to equity since they have not met the applicable realization criteria. Unused net operating loss carryforwards will expire at various dates in fiscal years 2017 to 2036. Certain net operating loss carryforwards in the United States relate to acquisitions and, as a result, are limited in the amount that can be utilized in any one year. The tax credit carryforwards will begin to expire in fiscal year 2019.

[0001032975-16-000083:notes:249]
Swiss income taxes and non-Swiss withholding taxes associated with the repatriation of earnings or for other temporary differences related to investments in non-Swiss subsidiaries have not been provided for, as the Company intends to reinvest the earnings of such subsidiaries indefinitely or the Company has concluded that no additional tax liability would arise on the distribution of such earnings. If these earnings were distributed to Switzerland in the form of dividends or otherwise, or if the shares of the relevant non-Swiss subsidiaries were sold or otherwise transferred, the Company may be subject to additional Swiss income taxes and non-Swiss withholding taxes. As of March 31, 2016, the cumulative amount of unremitted earnings of non-Swiss subsidiaries for which no income taxes have been provided is approximately $157.5 million. The amount of unrecognized deferred income tax liability related to these earnings is estimated to be approximately $5.2 million.

[0001032975-16-000083:notes:250]
The Company follows a two-step approach in recognizing and measuring uncertain tax positions. The first step is to evaluate the tax position for recognition by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step is to measure the tax benefit as the largest amount that is more than 50% likely of being realized upon ultimate settlement.

[0001032975-16-000083:notes:251]
As of March 31, 2016 and March 31, 2015, the total amount of unrecognized tax benefits due to uncertain tax positions was $69.9 million and $79.0 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-16-000083:notes:252]
As of March 31, 2016, the Company had $59.7 million in non-current income taxes payable and $0.1 million in current income taxes payable, including interest and penalties, related to the Company's income tax liability for uncertain tax positions. As of March 31, 2015, the Company had $72.1 million in non-current income taxes payable and $0.1 million in current income taxes payable.

[0001032975-16-000083:notes:253]
The aggregate changes in gross unrecognized tax benefits in fiscal years 2016, 2015 and 2014 were as follows (in thousands):

[0001032975-16-000083:notes:254]
| March 31, 2013 |  | $ | 95,698 |  |
| Lapse of statute of limitations |  | (12,514 | ) |
| Settlements with tax authorities |  | (100 | ) |
| Decreases in balances related to tax positions taken during prior years |  | (778 | ) |
| Increases in balances related to tax positions taken during the year |  | 8,740 |  |
| March 31, 2014 |  | $ | 91,046 |  |
| Lapse of statute of limitations |  | (14,071 | ) |
| Settlements with tax authorities |  | (2,160 | ) |
| Decreases in balances related to tax positions taken during prior years |  | (3,544 | ) |
| Increases in balances related to tax positions taken during the year |  | 7,752 |  |
| March 31, 2015 |  | $ | 79,023 |  |
| Lapse of statute of limitations |  | (15,518 | ) |
| Settlements with tax authorities |  | — |  |
| Decreases in balances related to tax positions taken during prior years |  | (1,502 | ) |
| Increases in balances related to tax positions taken during the year |  | 7,876 |  |
| March 31, 2016 |  | $ | 69,879 |  |

[0001032975-16-000083:notes:255]
The Company recognizes interest and penalties related to unrecognized tax positions in income tax expense. The Company recognized $0.3 million, $0.8 million and $1.1 million in interest and penalties in income tax expense during fiscal years 2016, 2015 and 2014, respectively. As of March 31, 2016, 2015 and 2014, the Company had $3.6 million, $4.9 million and $5.6 million of accrued interest and penalties related to uncertain tax positions, respectively.

[0001032975-16-000083:notes:256]
The Company files Swiss and foreign tax returns. The Company received final tax assessments in Switzerland through fiscal year 2013. For other foreign jurisdictions such as the United States, the Company is generally not subject to tax examinations for years prior to fiscal year 2012. The Company is under examination and has received assessment notices in foreign tax jurisdictions. If the examinations are resolved unfavorably, there is a possibility they may have a material negative impact on its results of operations.

[0001032975-16-000083:notes:257]
Although the Company has adequately provided for uncertain tax positions, the provisions on these positions may change as revised estimates are made or the underlying matters are settled or otherwise resolved. During the next 12 months, it is reasonably possible that the amount of unrecognized tax benefits could increase or decrease significantly due to changes in tax law in various jurisdictions, new tax audits and changes in the U.S. Dollar as compared to other currencies. Excluding these factors, uncertain tax positions may decrease by as much as $15.0 million primarily from the lapse of the statutes of limitations in various jurisdictions during the next 12 months.


## us-gaap:InterestAndOtherIncomeTableTextBlock

[0001032975-16-000083:notes:258]
Other income (expense), net comprises of the following (in thousands):

[0001032975-16-000083:notes:259]
|  |  | Years Ended March 31, |
|  |  | 2016 |  | 2015 |  | 2014 |
| Investment income (loss) related to deferred compensation plan |  | $ | (364 | ) |  | $ | 1,055 |  |  | $ | 1,487 |  |
| Impairment of investments |  | — |  |  | (2,298 | ) |  | (624 | ) |
| Currency exchange gain (loss), net |  | 2,110 |  |  | (1,175 | ) |  | (62 | ) |
| Other |  | (122 | ) |  | 120 |  |  | 1,238 |  |
| Other income (expense), net |  | $ | 1,624 |  |  | $ | (2,298 | ) |  | $ | 2,039 |  |


## us-gaap:InterestAndOtherIncomeTextBlock

[0001032975-16-000083:notes:260]
Interest and Other Income (Expense), net

[0001032975-16-000083:notes:261]
Interest income (expense), net comprises of the following (in thousands):

[0001032975-16-000083:notes:262]
|  |  | Years Ended March 31, |
|  |  | 2016 |  | 2015 |  | 2014 |
| Interest income |  | $ | 790 |  |  | $ | 1,197 |  |  | $ | 1,797 |  |
| Interest expense |  | — |  |  | — |  |  | (2,228 | ) |
| Interest income (expense), net |  | $ | 790 |  |  | $ | 1,197 |  |  | $ | (431 | ) |


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0001032975-16-000083:notes:263]
Geographic long-lived assets information, primarily fixed assets, are reported below based on the location of the asset (in thousands):

[0001032975-16-000083:notes:264]
|  |  | March 31, |
|  |  | 2016 |  | 2015 |
| Americas |  | $ | 40,221 |  |  | $ | 44,263 |  |
| EMEA |  | 3,194 |  |  | 3,473 |  |
| Asia Pacific |  | 49,445 |  |  | 38,742 |  |
|  |  | $ | 92,860 |  |  | $ | 86,478 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001032975-16-000083:notes:265]
Restructuring

[0001032975-16-000083:notes:266]
During the first quarter of fiscal year 2016, the Company implemented a restructuring plan to exit the OEM business, reorganize Lifesize to sharpen its focus on its cloud-based offering, and streamline the Company's overall cost structure, overhead and infrastructure cost reductions with a targeted resource realignment. Restructuring charges incurred during the year ended March 31, 2016 under this plan primarily consisted of severance and other ongoing and one-time termination benefits. Charges and other costs related to the workforce reduction and structure realignment are presented as restructuring charges in the Consolidated Statements of Operations. On a total company basis, including the Lifesize video conferencing business as reported in discontinued operations, the Company has incurred $25.5 million under this restructuring plan, including $24.4 million for cash severance and other personnel costs. The Company substantially completed this restructuring plan by the fourth quarter of fiscal year 2016.

[0001032975-16-000083:notes:267]
During the fourth quarter of fiscal year 2013, the Company implemented a restructuring plan to align its organization to its strategic priorities of increasing focus on mobility products, improving profitability in PC-related products and enhancing global operational efficiencies. As part of this restructuring plan, the Company reduced its worldwide non-direct labor workforce. Restructuring charges under this plan primarily consisted of severance and other one-time termination benefits. During fiscal year 2015, the Company recorded a $4.9 million restructuring credit, on a total company basis, primarily as a result of partial termination of its lease agreement for the Silicon Valley campus, which was previously vacated and under the restructuring plan during fiscal year 2014. The Company substantially completed this restructuring plan by the fourth quarter of fiscal year 2014.

[0001032975-16-000083:notes:268]
The following table summarizes restructuring related activities during fiscal year 2016 and 2015 from continuing operations (in thousands):

[0001032975-16-000083:notes:269]
|  |  | Restructuring - Continuing Operations |  |
|  |  | TerminationBenefits |  | Lease ExitCosts |  | Other |  | Total |  |
| Accrual balance at March 31, 2014 |  | $ | — |  |  | $ | 7,309 |  |  | $ | — |  |  | $ | 7,309 |  |  |
| Credits, net |  | — |  |  | (4,777 | ) |  | — |  |  | (4,777 | ) |  |
| Cash payments |  | — |  |  | (1,578 | ) |  | — |  |  | (1,578 | ) |  |
| Accrual balance at March 31, 2015 |  | — |  |  | 954 |  |  | — |  |  | 954 |  |  |
| Charges, net |  | 17,280 |  |  | 337 |  |  | 185 |  |  | 17,802 |  |  |
| Cash payments |  | (11,373 | ) |  | (1,166 | ) |  | (185 | ) |  | (12,724 | ) |  |
| Accrual balance at March 31, 2016 |  | $ | 5,907 |  |  | $ | 125 |  |  | $ | — |  |  | $ | 6,032 |  | * |

[0001032975-16-000083:notes:270]
*This balance is included in accrued and other current liabilities on the Company’s consolidated balance sheets.

[0001032975-16-000083:notes:271]
The following tables summarize restructuring related activities during fiscal year 2016 and 2015 from discontinued operations (in thousands):

[0001032975-16-000083:notes:272]
|  |  | Restructuring - Discontinued Operations |  |
|  |  | TerminationBenefits |  | Lease ExitCosts |  | Other |  | Total |  |
| Accrual balance at March 31, 2014 |  | $ | 142 |  |  | $ | 110 |  |  | $ | — |  |  | $ | 252 |  |  |
| Charges |  | (86 | ) |  | (25 | ) |  | — |  |  | (111 | ) |  |
| Cash payments |  | (56 | ) |  | — |  |  | — |  |  | (56 | ) |  |
| Accrual balance at March 31, 2015 |  | — |  |  | 85 |  |  | — |  |  | 85 |  |  |
| Charges, net |  | 7,095 |  |  | — |  |  | 805 |  |  | 7,900 |  |  |
| Cash payments |  | (6,460 | ) |  | (14 | ) |  | (805 | ) |  | (7,279 | ) |  |
| Adjustment as a result of disposition of discontinued operations |  | (267 | ) |  | (71 | ) |  | — |  |  | (338 | ) |  |
| Accrual balance at March 31, 2016 |  | $ | 368 |  |  | $ | — |  |  | $ | — |  |  | $ | 368 |  | * |

[0001032975-16-000083:notes:273]
*This balance is included in accrued and other current liabilities in continuing operations as of March 31, 2016, as it's expected to be paid by the continuing operations pursuant to the transaction occurred on December 28, 2015 (See Note 3).


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001032975-16-000083:notes:274]
Net sales to unaffiliated customers by geographic region for fiscal years 2016, 2015 and 2014 (based on the customers' location) were as follows (in thousands):

[0001032975-16-000083:notes:275]
|  |  | Years Ended March 31, |
|  |  | 2016 |  | 2015 |  | 2014 |
| Americas |  | $ | 881,379 |  |  | $ | 864,761 |  |  | $ | 799,431 |  |
| EMEA |  | 645,694 |  |  | 670,890 |  |  | 724,671 |  |
| Asia Pacific |  | 491,027 |  |  | 469,257 |  |  | 483,926 |  |
|  |  | $ | 2,018,100 |  |  | $ | 2,004,908 |  |  | $ | 2,008,028 |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001032975-16-000083:notes:276]
The components of accumulated other comprehensive loss were as follows (in thousands):

[0001032975-16-000083:notes:277]
|  |  | Accumulated Other Comprehensive Income (Loss) |
|  |  | CumulativeTranslationAdjustment (1) |  | DefinedBenefitPlans(1) |  | DeferredHedgingGains (Losses) |  | Total |
| March 31, 2015 |  | $ | (90,224 | ) |  | $ | (26,964 | ) |  | $ | 3,951 |  |  | $ | (113,237 | ) |
| Other comprehensive income (loss) |  | 6,186 |  |  | 793 |  |  | (5,727 | ) |  | 1,252 |  |
| March 31, 2016 |  | $ | (84,038 | ) |  | $ | (26,171 | ) |  | $ | (1,776 | ) |  | $ | (111,985 | ) |

[0001032975-16-000083:notes:278]
_______________________________________

[0001032975-16-000083:notes:279]
(1) Tax effect was not significant as of March 31, 2016 or 2015.


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001032975-16-000083:notes:280]
VALUATION AND QUALIFYING ACCOUNTS

[0001032975-16-000083:notes:281]
For the Fiscal Years Ended March 31, 2016, 2015 and 2014 (in thousands)

[0001032975-16-000083:notes:282]
The Company's Schedule II includes valuation and qualifying accounts related to allowances for doubtful accounts, sales returns, cooperative marketing arrangements, customer incentive programs, and pricing programs, for direct customers and tax valuation allowances. The Company also has sales incentive programs for indirect customers with whom it does not have a direct sales and receivable relationship. These programs are recorded as accrued liabilities and are not considered valuation or qualifying accounts.

[0001032975-16-000083:notes:283]
|  |  | Balance atBeginning ofYear |  | Charged(Credited) toStatement ofOperations |  | Claims andAdjustmentsApplied AgainstAllowances |  | Balance atEnd ofYear |
| Allowance for doubtful accounts: |  |  |  |  |  |  |  |  |  |  |  |  |
| 2016 |  | $ | 707 |  |  | $ | 71 |  |  | $ | (111 | ) |  | $ | 667 |  |
| 2015 |  | $ | 1,297 |  |  | $ | (334 | ) |  | $ | (256 | ) |  | $ | 707 |  |
| 2014 |  | $ | 1,724 |  |  | $ | 670 |  |  | $ | (1,097 | ) |  | $ | 1,297 |  |
| Allowance for sales returns: |  |  |  |  |  |  |  |  |  |  |  |  |
| 2016 |  | $ | 17,236 |  |  | $ | 66,935 |  |  | $ | (65,645 | ) |  | $ | 18,526 |  |
| 2015 |  | $ | 18,503 |  |  | $ | 66,785 |  |  | $ | (68,052 | ) |  | $ | 17,236 |  |
| 2014 |  | $ | 20,284 |  |  | $ | 60,113 |  |  | $ | (61,894 | ) |  | $ | 18,503 |  |
| Allowances for cooperative marketing arrangements: |  |  |  |  |  |  |  |  |  |  |  |  |
| 2016 |  | $ | 24,919 |  |  | $ | 131,410 |  |  | $ | (128,172 | ) |  | $ | 28,157 |  |
| 2015 |  | $ | 23,255 |  |  | $ | 113,610 |  |  | $ | (111,946 | ) |  | $ | 24,919 |  |
| 2014 |  | $ | 23,186 |  |  | $ | 100,005 |  |  | $ | (99,936 | ) |  | $ | 23,255 |  |
| Allowances for customer incentive programs: |  |  |  |  |  |  |  |  |  |  |  |  |
| 2016 |  | $ | 47,364 |  |  | $ | 164,307 |  |  | $ | (150,799 | ) |  | $ | 60,872 |  |
| 2015 |  | $ | 40,205 |  |  | $ | 142,413 |  |  | $ | (135,254 | ) |  | $ | 47,364 |  |
| 2014 |  | $ | 41,554 |  |  | $ | 104,719 |  |  | $ | (106,068 | ) |  | $ | 40,205 |  |
| Allowances for pricing programs: |  |  |  |  |  |  |  |  |  |  |  |  |
| 2016 |  | $ | 70,951 |  |  | $ | 260,698 |  |  | $ | (250,096 | ) |  | $ | 81,553 |  |
| 2015 |  | $ | 68,798 |  |  | $ | 246,780 |  |  | $ | (244,627 | ) |  | $ | 70,951 |  |
| 2014 |  | $ | 54,931 |  |  | $ | 217,967 |  |  | $ | (204,100 | ) |  | $ | 68,798 |  |
| Tax valuation allowances: |  |  |  |  |  |  |  |  |  |  |  |  |
| 2016 |  | $ | 5,590 |  |  | $ | 1,255 |  |  | $ | (1,507 | ) |  | $ | 5,338 |  |
| 2015 |  | $ | 4,872 |  |  | $ | 995 |  |  | $ | (277 | ) |  | $ | 5,590 |  |
| 2014 |  | $ | 6,014 |  |  | $ | 515 |  |  | $ | (1,657 | ) |  | $ | 4,872 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001032975-16-000083:notes:284]
Segment Information

[0001032975-16-000083:notes:285]
As discussed in "Note 2 — Summary of Significant Accounting Policies", the Company's Peripherals segment remains as the sole reporting segment reported in continuing operations.

[0001032975-16-000083:notes:286]
The Company's Peripherals segment continues to design, manufacture and markets products that allow people to connect through music, gaming, video, computing, and other digital platforms.  Operating performance measures for Peripherals reports directly to the Company's Chief Executive Officer (“CEO”), who is considered to be the Company’s Chief Operating Decision Maker (“CODM”). The CEO periodically reviews information such as net sales and operating income (loss) to make business decisions. These operating performance measures do not include restructuring charges (credits), net, share-based compensation expense and amortization of intangible assets.

[0001032975-16-000083:notes:287]
The United States represented 38%, 36% and 34% of net sales for the fiscal years 2016, 2015 and 2014, respectively. No other single country represented more than 10% of net sales during these periods. Revenues from net sales to customers in Switzerland, the Company's home domicile, represented 2% of net sales for each of fiscal years 2016, 2015 and 2014.

[0001032975-16-000083:notes:288]
Long-lived assets in the United States and China were $40.0 million and $44.5 million at March 31, 2016, respectively, and $44.3 million and $33.4 million at March 31, 2015, respectively. No other countries represented more than 10% of the Company's total consolidated long-lived assets at March 31, 2016 or 2015. Long-lived assets in Switzerland, the Company's home domicile, were $1.7 million and $1.5 million at March 31, 2016 and 2015, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001032975-16-000083:notes:289]
Shareholders' Equity

[0001032975-16-000083:notes:290]
Share Capital

[0001032975-16-000083:notes:291]
The Company's nominal share capital is CHF 43,276,655, consisting of 173,106,620 shares with a par value of CHF 0.25 each, all of which were issued and 10,697,117 of which were held in treasury shares as of March 31, 2016.

[0001032975-16-000083:notes:292]
In September 2008, the Company's shareholders approved an amendment to reserve conditional capital of 25,000,000 shares for potential issuance on the exercise of rights granted under the Company's employee equity incentive plans. The shareholders also approved the creation of conditional capital representing the issuance of up to 25,000,000 shares to cover any conversion rights under a future convertible bond issuance. This conditional capital was created in order to provide financing flexibility for future expansion, investments or acquisitions.

[0001032975-16-000083:notes:293]
Dividends

[0001032975-16-000083:notes:294]
Pursuant to Swiss corporate law, Logitech International S.A. may only pay dividends in Swiss Francs. The payment of dividends is limited to certain amounts of unappropriated retained earnings (CHF 653.4 million or $680.5 million based on the exchange rate at March 31, 2016) and is subject to shareholder approval. In March 2015, the Company announced a plan to pay $250.0 million in cumulative dividends for fiscal year 2015 through fiscal year 2017. In September 2015, the Company declared and paid cash dividends of CHF 0.51 (USD equivalent of $0.53) per common share, totaling approximately $85.9 million, on the Company’s outstanding common stock.  In December 2014, Logitech's shareholders approved a cash dividend payment of CHF 43.1 million out of retained earnings to Logitech shareholders. Eligible shareholders were paid CHF 0.26 per share ($0.27 per share in U.S. Dollars), totaling $43.8 million in U.S. Dollars in December 2014. In September 2013, Logitech's shareholders approved a cash dividend payment of CHF 33.7 million out of retained earnings to Logitech's shareholders. Eligible shareholders were paid CHF 0.21 per share ($0.22 per share in U.S. Dollars), totaling $36.1 million in U.S. Dollars in September 2013.

[0001032975-16-000083:notes:295]
Legal Reserves

[0001032975-16-000083:notes:296]
Under Swiss corporate law, a minimum of 5% of the Company's annual net income must be retained in a legal reserve until this legal reserve equals 20% of the Company's issued and outstanding aggregate par value per share capital. These legal reserves represent an appropriation of retained earnings that are not available for distribution and totaled $10.0 million at March 31, 2016 (based on the exchange rate at March 31, 2016).

[0001032975-16-000083:notes:297]
Share Repurchases

[0001032975-16-000083:notes:298]
In March 2014, the Company's Board of Directors approved the 2014 share buyback program, which authorizes the Company to use up to $250.0 million to purchase its own shares. The Company's share buyback program is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Purchases may be started or stopped at any time without prior notice depending on market conditions and other factors.

[0001032975-16-000083:notes:299]
During fiscal years 2016 and 2015, 5.0 million and 0.1 million shares were repurchased for $70.4 million and $1.7 million, respectively. There were no share repurchases during fiscal year 2014.

[0001032975-16-000083:notes:300]
Accumulated Other Comprehensive Loss


## us-gaap:SubsequentEventsTextBlock

[0001032975-16-000083:notes:301]
Subsequent Events

[0001032975-16-000083:notes:302]
On April 20, 2016, the Company acquired Jaybird LLC of Salt Lake City, Utah, for approximately $50 million in cash, with an additional earn-out of up to $45 million based on achievement of growth targets over the next two years. The Company is still in the process of preparing the initial accounting of the transaction and expects to establish a preliminary purchase price allocation with respect to this transaction by the end of the first quarter of fiscal year 2017.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001032975-16-000083:notes:303]
Balance Sheet Components
