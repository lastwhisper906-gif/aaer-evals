# LOGI MD&A — 0001032975-16-000083


## mdna

[0001032975-16-000083:mdna:1]
ITEM 7.    MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001032975-16-000083:mdna:2]
Overview of Our Company

[0001032975-16-000083:mdna:3]
Logitech is a world leader in designing products that have an every day place in people's lives, connecting them to the digital experiences they care about. Over 30 years ago we started connecting people through computers, and now we are designing products that bring people together through music, gaming, video and computing.

[0001032975-16-000083:mdna:4]
We design, manufacture and market products that allow people to connect through music, gaming, video, computing, and other digital platforms. Our products participate in five large markets that all have growth potential: Music, Gaming, Video Collaboration, Home, and Creativity and Productivity.

[0001032975-16-000083:mdna:5]
We sell our products to a broad network of domestic and international customers, including direct sales to retailers, e-tailers, and indirect sales through distributors. Our worldwide retail network includes consumer electronics distributors, retailers, mass merchandisers, specialty electronics stores, computer and telecommunications stores, value-added resellers and online merchants.

[0001032975-16-000083:mdna:6]
We seek to fulfill the increasing demand for interfaces between people and the expanding digital world across multiple platforms and user environments. The interface evolves as platforms, user models and our target markets evolve. As access to digital information has expanded, we have extended our focus to mobile devices, the digital home, and the digital world. All of these platforms require interfaces that are customized according to how the devices are used. We believe that continued investment in product research and development is critical to creating the innovation required to strengthen our competitive advantage and to drive future sales growth. We are committed to identifying and meeting current and future consumer trends with new and improved product technologies, as well as leveraging the value of the Logitech brand from a competitive, channel partner, and consumer experience perspective.

[0001032975-16-000083:mdna:7]
We believe that innovation, design and product quality are important to gaining market acceptance and maintaining market leadership.

[0001032975-16-000083:mdna:8]
From time to time, we may seek to partner with, or acquire when appropriate, companies that have products, personnel, and technologies that complement our strategic direction. We continually review our product offerings and our strategic direction in light of our profitability targets, competitive conditions, changing consumer trends and the evolving nature of the interface between the consumer and the digital world.

[0001032975-16-000083:mdna:9]
In fiscal years prior to fiscal year 2016, we had two segments: Peripherals, including retail and OEM products; and Lifesize Video Conferencing. During fiscal year 2016, we divested the Lifesize Video Conferencing segment, and exited the OEM business. Our financial results treat the Lifesize segment as discontinued operations for all the periods presented in this Annual Report on Form 10-K. As a result, sales of products through our retail channels represented 96%, 94% and 93% of our net sales for the fiscal years 2016, 2015 and 2014, respectively.

[0001032975-16-000083:mdna:10]
On April 20, 2016, we acquired Jaybird LLC of Salt Lake City, Utah, ("Jaybird") for approximately $50 million in cash, with an additional earn-out of up to $45 million based on achievement of growth targets over two years. Jaybird is a leader in wireless audio wearables for sports and active lifestyles, and the acquisition of Jaybird expands our long-term growth potential in our Music market.

[0001032975-16-000083:mdna:11]
On December 28, 2015, we and Lifesize, Inc., a wholly owned subsidiary of Logitech which holds the assets of our Lifesize video conferencing business, entered into a stock purchase agreement with three venture capital firms. Immediately following the December 28, 2015 closing of the transaction, the venture capital firms held 62.5% of the outstanding shares of Lifesize, which resulted in a divestiture of the Lifesize video conferencing business by us. The historical results of operations and the financial position of Lifesize are included in the consolidated financial statements of Logitech and are reported as discontinued operations within this Annual Report on Form 10-K. Unless

[0001032975-16-000083:mdna:12]
indicated otherwise, the information included in Item 7 relates to our continuing operations and historical financial information has been recast to conform to this new presentation within our financial statements.

[0001032975-16-000083:mdna:13]
We exited our OEM business during our fiscal quarter ended December 31, 2015. The results of our OEM business are included in our financial statements as part of continuing operations for the nine months ended December 31, 2015 and prior periods. There is no revenue and cost associated with this business in three months ended March 31, 2016, and we do not expect any in future periods.

[0001032975-16-000083:mdna:14]
Summary of Financial Results

[0001032975-16-000083:mdna:15]
Our total net sales for fiscal year 2016 increased 1% in comparison to fiscal year 2015 due to an increase in retail sales, partially offset by a decrease in OEM sales as a result of exiting the OEM business in the third quarter ended December 31, 2015.

[0001032975-16-000083:mdna:16]
Retail sales during fiscal year 2016 increased 3% compared to fiscal year 2015. Retail sales increased 3% and 10% in the Americas ("AMR") and Asia Pacific, respectively, partially offset by a decrease of 1% in EMEA.

[0001032975-16-000083:mdna:17]
Our gross margin for fiscal year 2016 decreased to 33.7%, compared to 35.2% for fiscal year 2015. The decrease in gross margin is primarily driven by the unfavorable fluctuations in currency exchange rates, partially offset by sales price increases and savings from supply chain efficiencies related to freight.

[0001032975-16-000083:mdna:18]
Operating expenses for fiscal year 2016 were 27.4% of net sales, compared to 27.5% for fiscal year 2015. The decrease was primarily due to the savings from general and administration expenses reduction related to the prior year's independent Audit committee investigation and related expenses, partially offset by the increase in research and development expense and restructuring costs related to our restructuring plan announced in April 2015.

[0001032975-16-000083:mdna:19]
Net income from continuing operations for fiscal year 2016 was $128.4 million, compared to $148.4 million for fiscal year 2015.

[0001032975-16-000083:mdna:20]
Trends in Our Business

[0001032975-16-000083:mdna:21]
In 2016, we announced our intention to focus on five large markets, or domains, collections of categories, going forward. Our strategy focuses on five large multi-category markets including Music, Gaming, Video Collaboration, Home and Creativity & Productivity. We see opportunities to deliver growth with products in all these markets.

[0001032975-16-000083:mdna:22]
We believe our future growth will be determined by our ability to rapidly create innovative products across multiple digital platforms, including gaming and digital music devices. The following discussion represents key trends specific to our market opportunities.

[0001032975-16-000083:mdna:23]
Trends Specific to Our Five Market Opportunities

[0001032975-16-000083:mdna:24]
Music:  The music market grew during fiscal year 2016 driven by growing consumption of music through mobile devices such as smartphones and tablets. This market growth, together with our investments in the UE brand, our introduction of new products and our ability to gain market share during fiscal year 2016, has driven our growth in this market.

[0001032975-16-000083:mdna:25]
Gaming:  The PC Gaming platform continues to show strong growth as online gaming and multi-platform experiences gain greater popularity and gaming content becomes increasingly more demanding. We believe Logitech is well positioned to benefit from the gaming market growth.

[0001032975-16-000083:mdna:26]
Video Collaboration:   We are continuing our efforts to create and sell innovative products, including Video Collaboration products, to accommodate the increasing demand from medium sized meeting rooms to small sized rooms such as huddle rooms. During fiscal year 2016, we launched Logitech Group, a transformation in team collaboration that provides high-quality HD video conferencing for groups of up to 20 people and works with the video conferencing applications already in use. We will continue to invest in selected business specific products, targeted product marketing and sales channel development.

[0001032975-16-000083:mdna:27]
Home:  This market increased in fiscal year 2016. We are continuing our efforts to sell our Harmony products in this market.

[0001032975-16-000083:mdna:28]
Creativity & Productivity: Although the consumer demand for PC peripherals is slowing, the installed base of PC users is large. We believe that innovative PC peripherals, such as our mice and keyboards, can renew the PC usage experience, providing growth opportunities. Smaller mobile computing devices, such as tablets with touch

[0001032975-16-000083:mdna:29]
interfaces, have created new markets and usage models for peripherals and accessories. We offer a number of products to enhance the use of mobile devices, including keyboard folios for the iPad and iPad mini, and keyboard covers and folios for the iPad Air. However, we have seen the market decline through fiscal year 2016 for the iPad platform, which has impacted the sales of our tablet accessories.

[0001032975-16-000083:mdna:30]
Business Application Suite

[0001032975-16-000083:mdna:31]
In fiscal year 2016, we implemented the upgrade of our worldwide business application suite from Oracle version 11i to Oracle version R12. This upgrade created delays in our processing of customer claims related to cooperative marketing arrangements, direct and indirect customer incentive programs and pricing programs. While we are working on enhancing the operational efficiency of the claims processing module in our worldwide business application suite, this has resulted and it may continue to result in higher accruals and allowances for such programs.

[0001032975-16-000083:mdna:32]
Business Seasonality and Product Introductions

[0001032975-16-000083:mdna:33]
We have historically experienced higher net sales in its third fiscal quarter ending December 31, compared to other fiscal quarters in its fiscal year, due in part to seasonal holiday demand. Additionally, new product introductions can significantly impact net sales, product costs and operating expenses. Product introductions can also impact our net sales to its distribution channels as these channels are filled with new product inventory following a product introduction, and often channel inventory of an earlier model product declines as the next related major product launch approaches. Net sales can also be affected when consumers and distributors anticipate a product introduction. However, neither historical seasonal patterns nor historical patterns of product introductions should be considered reliable indicators of our future pattern of product introductions, future net sales or financial performance.

[0001032975-16-000083:mdna:34]
Critical Accounting Estimates

[0001032975-16-000083:mdna:35]
The preparation of financial statements and related disclosures in conformity with U.S. GAAP (Generally Accepted Accounting Principles in the United States of America) requires us to make judgments, estimates and assumptions that affect reported amounts of assets, liabilities, net sales and expenses, and the disclosure of contingent assets and liabilities.

[0001032975-16-000083:mdna:36]
We consider an accounting estimate critical if it: (i) requires management to make judgments and estimates about matters that are inherently uncertain; and (ii) is important to an understanding of our financial condition and operating results.

[0001032975-16-000083:mdna:37]
We base our estimates on historical experience and on various other assumptions we believe to be reasonable under the circumstances. Although these estimates are based on management's best knowledge of current events and actions that may impact us in the future, actual results could differ from those estimates. Management has discussed the development, selection and disclosure of these critical accounting estimates with the Audit Committee of the Board of Directors.

[0001032975-16-000083:mdna:38]
We believe the following accounting estimates are most critical to our business operations and to an understanding of our financial condition and results of operations, and reflect the more significant judgments and estimates used in the preparation of our consolidated financial statements.

[0001032975-16-000083:mdna:39]
Accruals for Customer Programs

[0001032975-16-000083:mdna:40]
We record accruals for cooperative marketing arrangements, customer incentive programs, pricing programs and product returns. An allowance against accounts receivable is recorded for accruals and program activity related to our direct customers and indirect customers who receive payments for program activity through our direct customers. A liability is recorded for accruals and program activity related to our indirect customers who receive payments directly and do not have a right of offset against a receivable balance. The estimated cost of these programs is usually recorded as a reduction of revenue. If we receive a separately identifiable benefit from the customer and can reasonably estimate the fair value of that benefit, such cost is reflected in operating expenses. Significant management judgment and estimates must be used to determine the cost of these programs in any accounting period.

[0001032975-16-000083:mdna:41]
Cooperative Marketing Arrangements.    We enter into customer marketing programs with many of our distribution and retail customers, and with certain indirect partners, allowing customers to receive a credit equal to a set percentage of their purchases of our products, or a fixed dollar credit for various marketing programs. The objective of these arrangements is to encourage advertising and promotional events to increase sales of our

[0001032975-16-000083:mdna:42]
products. Accruals for these marketing arrangements are recorded at the later of time of sale or time of commitment, based on negotiated terms, historical experience and inventory levels in the channel.

[0001032975-16-000083:mdna:43]
Customer Incentive Programs.    Customer incentive programs include performance-based incentives and consumer rebates. We offer performance-based incentives to our distribution customers, retail customers and indirect partners based on pre-determined performance criteria. Accruals for performance-based incentives are recognized as a reduction of the sale price at the time of sale. Estimates of required accruals are determined based on negotiated terms, consideration of historical experience, anticipated volume of future purchases, and inventory levels in the channel. Consumer rebates are offered from time to time at our discretion for the primary benefit of end-users. Accruals for the estimated costs of consumer rebates and similar incentives are recorded at the later of time of sale or when the incentive is offered, based on the specific terms and conditions. Certain incentive programs, including consumer rebates, require management to estimate the number of customers who will actually redeem the incentive based on historical experience and the specific terms and conditions of particular programs.

[0001032975-16-000083:mdna:44]
Pricing Programs.    We have agreements with certain customers that contain terms allowing price protection credits to be issued in the event of a subsequent price reduction. At our discretion, we also offer special pricing discounts to certain customers. Special pricing discounts are usually offered only for limited time periods or for sales of selected products to specific indirect partners. Our decision to make price reductions is influenced by product life cycle stage, market acceptance of products, the competitive environment, new product introductions and other factors. Accruals for estimated expected future pricing actions are recognized at the time of sale based on analysis of historical pricing actions by customer and by products, inventories owned by and located at distributors and retailers, current customer demand, current operating conditions, and other relevant customer and product information, such as stage of product life-cycle.

[0001032975-16-000083:mdna:45]
Returns.    We grant limited rights to return products. Return rights vary by customer, and range from just the right to return defective product to stock rotation rights limited to a percentage of sales approved by management. Estimates of expected future product returns are recognized at the time of sale based on analyses of historical return trends by customer and by product, inventories owned by and located at distributors and retailers, current customer demand, current operating conditions, and other relevant customer and product information. Upon recognition, we reduce sales and cost of sales for the estimated return. Return trends are influenced by product life cycle status, new product introductions, market acceptance of products, sales levels, product sell-through, the type of customer, seasonality, product quality issues, competitive pressures, operational policies and procedures, and other factors. Return rates can fluctuate over time, but are sufficiently predictable to allow us to estimate expected future product returns.

[0001032975-16-000083:mdna:46]
We regularly evaluate the adequacy of our accruals for cooperative marketing arrangements, customer incentive programs, pricing programs and product returns. Future market conditions and product transitions may require us to take action to increase such programs. In addition, when the variables used to estimate these costs change, or if actual costs differ significantly from the estimates, we would be required to record incremental increases or reductions to revenue or operating expenses. If, at any future time, we become unable to reasonably estimate these costs, recognition of revenue might be deferred until products are sold to users, which would adversely impact revenue in the period of transition.

[0001032975-16-000083:mdna:47]
Inventory Valuation

[0001032975-16-000083:mdna:48]
We must order components for our products and build inventory in advance of customer orders. Further, our industry is characterized by rapid technological change, short-term customer commitments and rapid changes in demand.

[0001032975-16-000083:mdna:49]
We record inventories at the lower of cost or market value and record write-downs of inventories that are obsolete or in excess of anticipated demand or market value. A review of inventory is performed each fiscal quarter that considers factors including the marketability and product life cycle stage, product development plans, component cost trends, demand forecasts and current sales levels. Inventory on hand which is not expected to be sold or utilized is considered excess, and we recognize the write-down in cost of goods sold at the time of such determination. The write-down is determined by comparison of the replacement cost with the estimated selling price less any costs of completion and disposal (net realizable value) and the net realizable value less the normal profit margin. At the time of loss recognition, new cost basis per unit and lower-cost basis for that inventory are established and subsequent changes in facts and circumstances would not result in an increase in the cost basis. If there is an abrupt and substantial decline in demand for Logitech's products or an unanticipated change in technological or customer requirements, we may be required to record additional write-downs that could adversely affect gross margins in the period when the write-downs are recorded.

[0001032975-16-000083:mdna:50]
Share-Based Compensation Expense

[0001032975-16-000083:mdna:51]
Share-based compensation expense includes compensation expense reduced for estimated forfeitures. The grant date fair value for stock options and stock purchase rights is estimated using the Black-Scholes-Merton option-pricing valuation model. The grant date fair value of RSUs (restricted stock units) that vest upon meeting certain market conditions is estimated using the Monte-Carlo simulation method. The grant date fair value of time-based RSUs and RSUs with performance conditions is calculated based on the closing market price on the date of grant, adjusted by estimated dividends yield prior to vesting.

[0001032975-16-000083:mdna:52]
Our estimates of share-based compensation expense require a number of complex and subjective assumptions including our stock price volatility, employee exercise patterns, future forfeitures, probability of achievement of the set performance conditions, dividend yield, related tax effects and the selection of an appropriate fair value model. We estimate expected share price volatility based on historical volatility using daily prices over the term of past options, RSUs or purchase offerings, as we consider historical share price volatility as most representative of future volatility. We estimate expected life based on historical settlement rates, which we believe are most representative of future exercise and post-vesting termination behaviors. We use historical data to estimate pre-vesting forfeitures, and we record share-based compensation expense only for those awards that are expected to vest. The dividend yield assumption is based on our history and expectations of future dividend payouts.

[0001032975-16-000083:mdna:53]
The assumptions used in calculating the fair value of share-based compensation expense and related tax effects represent our best estimates, but these estimates involve inherent uncertainties and the application of management judgment. As a result, if factors change and we use different assumptions, or if we decide to use a different valuation model, our share-based compensation expense could be materially different in the future from what we have recorded in the current period, which could materially affect our results of operations.

[0001032975-16-000083:mdna:54]
Accounting for Income Taxes

[0001032975-16-000083:mdna:55]
We operate in multiple jurisdictions and our profits are taxed pursuant to the tax laws of these jurisdictions. Our effective income tax rate may be affected by the changes in or interpretations of tax laws and tax agreements in any given jurisdiction, utilization of net operating loss and tax credit carryforwards, changes in geographical mix of income and expense, and changes in our assessment of matters such as the ability to realize deferred tax assets. As a result of these considerations, we must estimate income taxes in each of the jurisdictions in which we operate. This process involves estimating current tax exposure together with assessing temporary differences resulting from different treatment of items for tax and accounting purposes. These differences result in deferred tax assets and liabilities, which are included in the consolidated balance sheet.

[0001032975-16-000083:mdna:56]
We assess the likelihood that our deferred tax assets will be recovered from future taxable income, considering all available evidence such as historical levels of income, expectations and risks associated with estimates of future taxable income and ongoing prudent and feasible tax strategies. When we determine that it is not more likely than not that we will realize all or part of our deferred tax assets, an adjustment is charged to earnings in the period when such determination is made. Likewise, if we later determine that it is more likely than not that all or a part of our deferred tax assets would be realized, the previously provided valuation allowance would be reversed.

[0001032975-16-000083:mdna:57]
We make certain estimates and judgments about the application of tax laws, the expected resolution of uncertain tax positions and other matters surrounding the recognition and measurement of uncertain tax benefits. In the event that uncertain tax positions are resolved for amounts different than our estimates, or the related statutes of limitations expire without the assessment of additional income taxes, we will be required to adjust the amounts of the related assets and liabilities in the period in which such events occur. Such adjustments may have a material impact on our income tax provision and our results of operations.

[0001032975-16-000083:mdna:58]
Goodwill

[0001032975-16-000083:mdna:59]
We conduct a goodwill impairment analysis annually at December 31 or more frequently if indicators of impairment exist or if a decision is made to sell or exit a business. A significant amount of judgment is involved in determining if an indicator of impairment has occurred. Such indicators may include deterioration in general economic conditions, negative developments in equity and credit markets, adverse changes in the markets in which an entity operates, increases in input costs that have a negative effect on earnings and cash flows, a trend of negative or declining cash flows, a decline in actual or planned revenue or earnings compared with actual and projected results of relevant prior periods, or other relevant entity-specific events such as changes in management,

[0001032975-16-000083:mdna:60]
key personnel, strategy or customers, contemplation of bankruptcy, or litigation. The fair value that could be realized in an actual transaction may differ from that used to evaluate the impairment of goodwill.

[0001032975-16-000083:mdna:61]
In reviewing goodwill for impairment, an entity has the option to first assess qualitative factors to determine whether the existence of events or circumstances leads to a determination that it is more likely than not (greater than 50%) that the estimated fair value of a reporting unit is less than its carrying amount. If an entity elects to perform a qualitative assessment and determines that an impairment is more likely than not, the entity is then required to perform the two-step quantitative impairment test; otherwise, no further analysis is required. An entity also may elect not to perform the qualitative assessment and, instead, proceed directly to the two-step quantitative impairment test. The ultimate outcome of the goodwill impairment review for a reporting unit should be the same whether an entity chooses to perform the qualitative assessment or proceeds directly to the two-step quantitative impairment test. Goodwill is allocated among and evaluated for impairment at the reporting unit level, which is defined as an operating segment or one level below an operating segment. We currently have only one reporting unit.

[0001032975-16-000083:mdna:62]
Annual Impairment analysis

[0001032975-16-000083:mdna:63]
We performed our annual impairment analysis of the goodwill at December 31, 2015 by performing a qualitative assessment and concluded that it was more likely than not that the fair value of the peripheral reporting unit exceeded its carrying amount. Refer to the Note 11 to the consolidated financial statements included in this Annual Report on Form 10-K for the disclosures.

[0001032975-16-000083:mdna:64]
Product Warranty Accrual

[0001032975-16-000083:mdna:65]
We estimate the cost of product warranties at the time the related revenue is recognized based on historical and projected warranty claim rates, historical and projected costs, and knowledge of specific product failures that are outside of our typical experience. Each fiscal quarter, we reevaluate estimates to assess the adequacy of recorded warranty liabilities considering the size of the installed base of products subject to warranty protection and adjust the amounts as necessary. If actual product failure rates or repair costs differ from estimates, revisions to the estimated warranty liabilities would be required and could materially affect our results of operations.

[0001032975-16-000083:mdna:66]
Adoption of New Accounting Pronouncements

[0001032975-16-000083:mdna:67]
In April 2014, the FASB issued ASU No. 2014-08, "Presentation of Financial Statements (Topic 205) and Property, Plant and Equipment (Topic 360): Reporting Discontinued Operations and Disclosures of Disposals of Components of an Entity". This new standard raises the threshold for a disposal to qualify as a discontinued operation and requires new disclosures of both discontinued operations and certain other disposals that do not meet the definition of a discontinued operation. The standard is effective prospectively for years beginning on or after December 15, 2014, with early application permitted. We adopted ASU No. 2014-08 on April 1, 2015 on a prospective basis and applied the guidance to our disposition of the Lifesize video conferencing business.

[0001032975-16-000083:mdna:68]
In November 2015, the FASB issued ASU No. 2015-17, “Income Taxes (Topic 740), Balance Sheet Classification of Deferred Taxes” ("ASU 2015-17"). The guidance eliminates the current requirement for an entity to separate deferred income tax liabilities and assets into current and non-current amounts in a classified balance sheet. Instead, the guidance requires deferred tax liabilities, deferred tax assets and valuation allowances be classified as non-current in a classified balance sheet. The ASU is effective for annual reporting periods beginning after December 15, 2016 and interim periods within those annual periods. Early adoption is permitted. We have early adopted the guidance in the fourth quarter of fiscal year 2016 on a prospective basis.  Prior periods are therefore not adjusted.

[0001032975-16-000083:mdna:69]
Refer to the Note 2 to the consolidated financial statements included in this Annual Report on Form 10-K for recent accounting pronouncements to be adopted.

[0001032975-16-000083:mdna:70]
Non-GAAP Measures

[0001032975-16-000083:mdna:71]
We refer to our net sales excluding the impact of currency exchange rate fluctuations as "constant dollar" sales. Constant dollar sales is a non-GAAP financial measure, which is information derived from consolidated financial information but not presented in our financial statements prepared in accordance with U.S. GAAP. Our management uses these non-GAAP measures in its financial and operational decision-making, and believes these non-GAAP measures, when considered in conjunction with the corresponding GAAP measures, facilitate a better understanding of changes in net sales. Percentage of constant dollar sales growth is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales. This non-GAAP financial measure is not intended to be considered in isolation from, or as a substitute for, a measure of financial performance prepared in accordance with GAAP. There are inherent limitations associated with the use of this non-GAAP financial measure as an analytical tool. In particular, this non-GAAP financial measure is not based on a comprehensive set of accounting rules or principles, may be different from non-GAAP financial measures used by other companies, and is not necessarily comparable to similarly-titled measures presented by other companies, limiting its usefulness for comparison purposes. Moreover, presentation of revenue on a constant currency basis is provided for year-over-year comparison purposes only, and investors should be cautioned that the effect of changing currency exchange rates has an actual effect on our operating results in U.S. Dollars.

[0001032975-16-000083:mdna:72]
Given our global sales presence and the reporting of our financial results in U.S. Dollars, our financial results for fiscal year 2016 were affected by significant shifts in currency exchange rates during fiscal year 2016. See “Results of Operations” beginning for information on the effect of currency exchange results on our net sales. If the U.S. Dollar appreciates in comparison to other currencies in future periods, this will affect our results of operations in future periods as well.

[0001032975-16-000083:mdna:73]
Results of Operations

[0001032975-16-000083:mdna:74]
Net Sales

[0001032975-16-000083:mdna:75]
Net sales by channel for fiscal years 2016, 2015 and 2014 were as follows (Dollars in thousands):

[0001032975-16-000083:mdna:76]
|  |  | Years Ended March 31, |  | Change |
|  |  | 2016 |  | 2015 |  | 2014 |  | 2016 vs. 2015 |  | 2015 vs. 2014 |
| Retail |  | $ | 1,947,059 |  |  | $ | 1,887,446 |  |  | $ | 1,866,279 |  |  | 3 | % |  | 1 | % |
| OEM |  | 71,041 |  |  | 117,462 |  |  | 141,749 |  |  | (40 | ) |  | (17 | ) |
| Total net sales |  | $ | 2,018,100 |  |  | $ | 2,004,908 |  |  | $ | 2,008,028 |  |  | 1 |  |  | — |  |

[0001032975-16-000083:mdna:77]
Retail:

[0001032975-16-000083:mdna:78]
During fiscal year 2016, retail sales increased 3%, in comparison to fiscal year 2015. If currency exchange rates had been constant in 2016 and 2015, our constant dollar retail sales would have increased 9%. The increase in sales was driven by double digit growth in Mobile Speakers, Gaming and Video Collaboration product categories.

[0001032975-16-000083:mdna:79]
During fiscal year 2015, retail sales increased 1%, compared to fiscal year 2014. If currency exchange rates had been constant in 2015 and 2014, our constant dollar retail sales would have increased 4%. The increase in retail sales is primarily due to triple-digit growth in Mobile Speakers and Video Collaboration product categories, and double-digit growth in Gaming product category, partially offset by declines in Audio-PC & Wearables, Tablet & Other Accessories, PC webcams and the other product categories, compared to fiscal year 2014.

[0001032975-16-000083:mdna:80]
OEM:

[0001032975-16-000083:mdna:81]
During fiscal year 2016, OEM sales decreased 40%, compared to fiscal year 2015. The decline was primarily due to the exit from our OEM business in December 2015, and there was no revenue during the quarter ended March 31, 2016.

[0001032975-16-000083:mdna:82]
During fiscal year 2015, OEM sales decreased 17% compared to fiscal year 2014.

[0001032975-16-000083:mdna:83]
Sales Denominated in Other Currencies

[0001032975-16-000083:mdna:84]
Although our financial results are reported in U.S. Dollars, a portion of our sales were generated in currencies other than the U.S. Dollar, such as the Euro, Chinese Renminbi, Japanese Yen, Canadian Dollar, Taiwan Dollar, British Pound and Australian Dollar. During fiscal years 2016, 2015 and 2014, 48%, 47% and 48% of our net sales were denominated in currencies other than the U.S. Dollar, respectively.

[0001032975-16-000083:mdna:85]
Retail Sales by Region

[0001032975-16-000083:mdna:86]
The following table presents the change in retail sales by region for fiscal year 2016 compared with fiscal year 2015, and fiscal year 2015 compared with fiscal year 2014:

[0001032975-16-000083:mdna:87]
|  |  | 2016 vs. 2015 |  | 2015 vs. 2014 |
| Americas |  | 3 | % |  | 8 | % |
| EMEA |  | (1 | ) |  | (7 | ) |
| Asia Pacific |  | 10 |  |  | 2 |  |

[0001032975-16-000083:mdna:88]
Americas

[0001032975-16-000083:mdna:89]
During fiscal year 2016, retail sales in Americas increased 3%, compared to fiscal year 2015. If currency exchange rates had been constant in 2016 and 2015, our constant dollar retail sales would have increased 5% in the Americas. This increase was led by double digit growth in the Video Collaboration product category mainly from the Webcam C930e, ConfereneceCam Connect, and PTZ Pro Camera, and double digit growth in the Mobile Speakers product category driven by the UE Boom 2 as well as the UE Megaboom.

[0001032975-16-000083:mdna:90]
During fiscal year 2015, retail sales in Americas increased 8%, compared to fiscal year 2014. If currency exchange rates had been constant in 2015 and 2014, our constant dollar retail sales would have increased 9% in the Americas. We achieved sales increases in all categories except Audio-PC & Wearables, PC webcams, and Tablets & Other Accessories. This increase was led by triple digit growth in Mobile Speakers mainly from UE BOOM and UE MEGABOOM, and triple digit growth in the Video Collaboration product category mainly from our ConferenceCam CC3000e and Webcam C930e.

[0001032975-16-000083:mdna:91]
EMEA

[0001032975-16-000083:mdna:92]
During fiscal year 2016, retail sales in EMEA decreased 1%, compared to fiscal year 2015. If currency exchange rates had been constant in 2016 and 2015, our constant dollar retail sales would have increased 9% in the EMEA region. Double digit growth in Gaming, Video Collaboration and Mobile Speakers product categories were offset by declines in all other product categories.

[0001032975-16-000083:mdna:93]
During fiscal year 2015, retail sales in EMEA decreased 7%, compared to fiscal year 2014. If currency exchange rates had been constant in 2015 and 2014, our constant dollar retail sales would have decreased 3% in the EMEA region. Retail sales decreased across all categories except Gaming, Mobile Speakers, Video Collaboration, Home Control and Keyboards and Combos product categories. The decline in sales was heavily impacted by market weakness in Russia and Ukraine. We achieved triple digit growth in the Video Collaboration product category, and double digit growth in both Mobile Speakers and Gaming product categories during fiscal year 2015 compared to fiscal year 2014.

[0001032975-16-000083:mdna:94]
Asia Pacific

[0001032975-16-000083:mdna:95]
During fiscal year 2016, retail sales in Asia Pacific increased 10%, compared to fiscal year 2015. If currency exchange rates had been constant in 2016 and 2015, our constant dollar retail sales would have increased 15% in the Asia Pacific region. We achieved double digit growth in Video Collaboration, PC Webcams, Mobile Speakers and Gaming product categories, partially offset by the decline in Tablets & Other Accessories and Home Control product categories.

[0001032975-16-000083:mdna:96]
During fiscal year 2015, retail sales in Asia Pacific increased 2%, compared to fiscal year 2014. If currency exchange rates had been constant in 2015 and 2014, our constant dollar retail sales would have increased 4% in the Asia Pacific region. We achieved triple digit growth in both Mobile Speakers and Video Collaboration product categories, partially offset by the decline in Tablets & Other Accessories, Audio - PC Wearables, and Other categories.

[0001032975-16-000083:mdna:97]
Net Retail Sales by Product Categories

[0001032975-16-000083:mdna:98]
Net retail sales by product categories for fiscal years 2016, 2015 and 2014 were as follows (Dollars in thousands):

[0001032975-16-000083:mdna:99]
|  |  | Years Ended March 31, |  | Change |
|  |  | 2016 |  | 2015 |  | 2014 |  | 2016 vs. 2015 |  | 2015 vs. 2014 |
| Mobile Speakers |  | $ | 229,718 |  |  | $ | 178,038 |  |  | $ | 87,414 |  |  | 29 | % |  | 104 | % |
| Audio-PC & Wearables |  | 196,013 |  |  | 213,496 |  |  | 250,037 |  |  | (8 | ) |  | (15 | ) |
| Gaming |  | 245,101 |  |  | 211,911 |  |  | 186,926 |  |  | 16 |  |  | 13 |  |
| Video Collaboration |  | 89,322 |  |  | 62,215 |  |  | 29,058 |  |  | 44 |  |  | 114 |  |
| Home Control |  | 59,075 |  |  | 68,060 |  |  | 67,371 |  |  | (13 | ) |  | 1 |  |
| Pointing Devices |  | 492,543 |  |  | 487,210 |  |  | 506,884 |  |  | 1 |  |  | (4 | ) |
| Keyboards & Combos |  | 430,190 |  |  | 426,117 |  |  | 415,314 |  |  | 1 |  |  | 3 |  |
| Tablet & Other Accessories |  | 103,886 |  |  | 140,994 |  |  | 172,484 |  |  | (26 | ) |  | (18 | ) |
| PC Webcams |  | 98,641 |  |  | 96,680 |  |  | 113,791 |  |  | 2 |  |  | (15 | ) |
| Other (1) |  | 2,570 |  |  | 2,725 |  |  | 37,000 |  |  | (6 | ) |  | (93 | ) |
| Total net retail sales |  | $ | 1,947,059 |  |  | $ | 1,887,446 |  |  | $ | 1,866,279 |  |  | 3 |  |  | 1 |  |

[0001032975-16-000083:mdna:100]
__________________________________________

[0001032975-16-000083:mdna:101]
| (1) | Other category includes products that we currently intend to transition out of, or have already transitioned out of, because they are no longer strategic to our business. |

[0001032975-16-000083:mdna:102]
Retail Sales by Product Categories:

[0001032975-16-000083:mdna:103]
Music market:

[0001032975-16-000083:mdna:104]
Mobile Speakers

[0001032975-16-000083:mdna:105]
Our Mobile Speakers category is made up entirely of bluetooth wireless speakers.

[0001032975-16-000083:mdna:106]
During fiscal year 2016, retail sales of Mobile Speakers increased 29%, compared to fiscal year 2015. The sales increased by double digits across all three regions, primarily due to strong demand of UE Boom 2, UE Megaboom and UE Roll bluetooth wireless speakers.

[0001032975-16-000083:mdna:107]
During fiscal year 2015, retail sales of Mobile Speakers increased 104%, compared to fiscal year 2014. The sales increased significantly across all three regions, with a triple digit growth in both Americas and Asia Pacific regions, primarily due to strong demand for the UE BOOM, and experienced triple digit growth in fiscal year 2015 compared to fiscal year 2014. The successful launch of UE MEGABOOM during the fourth quarter of fiscal year 2015 contributed 6% of total Mobile Speakers sales for fiscal year 2015.

[0001032975-16-000083:mdna:108]
Audio-PC & Wearables

[0001032975-16-000083:mdna:109]
Our Audio-PC & Wearables category comprises PC speakers, PC headsets, in-ear headphones and premium wireless audio wearables.

[0001032975-16-000083:mdna:110]
During fiscal year 2016, retail sales of Audio-PC & Wearables decreased 8%, compared to fiscal year 2015. The decrease was primarily due to decreases in sales in PC Speakers and PC Headsets, partially offset slightly by an increase in audio wearables. Retail sales of our headset products decreased 6%. Retail sales of our Wearables products increased 46%.

[0001032975-16-000083:mdna:111]
During fiscal year 2015, retail sales of Audio-PC & Wearables decreased 15%, compared to fiscal year 2014. The decrease was primarily due to decreases in PC Speaker retail sales, reflecting a category that appears to be in structural decline as music consumption continues to migrate to mobile platforms, which benefits our Mobile Speakers product category. Retail sales of our PC Headset products decreased 4%. Retail sales of our Wearables products declined 35%.

[0001032975-16-000083:mdna:112]
Gaming market:

[0001032975-16-000083:mdna:113]
Gaming

[0001032975-16-000083:mdna:114]
Our Gaming category comprises gaming mice, keyboards, headsets, gamepads and steering wheels.

[0001032975-16-000083:mdna:115]
During fiscal year 2016, retail sales of Gaming increased 16%, compared to fiscal year 2015 with double digit growth for gaming keyboards, gaming headsets, and gaming steering wheels. Some of our top revenue generating products for the year include G29 Driving Force Racing Wheel, G920 Driving Force Wheel, G933 Artemis Spectrum, and the G910 Orion Spark gaming keyboard. New products made up 22% of total Gaming revenue for fiscal year 2016.

[0001032975-16-000083:mdna:116]
During fiscal year 2015, retail sales of Gaming increased 13%, compared to fiscal year 2014. This growth was primarily from gaming headsets and gaming mice due to the launch of our new gaming products, including mice, keyboards and headsets. New products made up 12% of total Gaming revenue for fiscal year 2015. Our top revenue-generating Gaming products included the Logitech G502 Proteus Core, the Logitech G27 Racing Wheel, the Logitech G930 Wireless Gaming Headset, and the G430 Cordless Mice.

[0001032975-16-000083:mdna:117]
Video Collaboration market:

[0001032975-16-000083:mdna:118]
Video Collaboration

[0001032975-16-000083:mdna:119]
Our Video Collaboration category primarily includes products which combine audio and video and other products that can connect small and medium sized user groups.

[0001032975-16-000083:mdna:120]
During fiscal year 2016, retail sales of Video Collaboration increased 44%, compared to fiscal year 2015. The sales increase in this category was primarily driven by the success of ConferenceCam Connect, PTZ Pro Camera, and Webcam C930e.

[0001032975-16-000083:mdna:121]
During fiscal year 2015, retail sales of Video Collaboration increased 114%, compared to fiscal year 2014. The sales increased significantly across all products in this category, primarily driven by the success of the Logitech ConferenceCam CC3000e and Logitech ConferenceCam C930e.

[0001032975-16-000083:mdna:122]
Home market:

[0001032975-16-000083:mdna:123]
Home Control

[0001032975-16-000083:mdna:124]
Our Home Control category includes our Harmony remotes and Harmony Home Control.

[0001032975-16-000083:mdna:125]
During fiscal year 2016, retail sales of Home Control decreased 13%, compared to fiscal year 2015. The decline was primarily driven by the sales decrease of our mid-range products. New products contributed 24% of total retail sales of Home Control for fiscal year 2016.

[0001032975-16-000083:mdna:126]
During fiscal year 2015, retail sales of Home Control increased 1%, compared to fiscal year 2014. The increase in Home Control was primarily concentrated in our mid-range and low-end products, partially offset by decreases in our high-end products. New products contributed 17% of total retail sales of Home Control for fiscal year 2015.

[0001032975-16-000083:mdna:127]
Creativity and Productivity market:

[0001032975-16-000083:mdna:128]
Pointing Devices

[0001032975-16-000083:mdna:129]
Our Pointing Devices category comprises PC and Mac-related mice, touchpads and presenters.

[0001032975-16-000083:mdna:130]
During fiscal year 2016, retail sales of Pointing Devices increased 1%, in comparison to fiscal year 2015. The growth in this category was driven by the MX Master Wireless Mouse. New products contributed approximately 8% of total retail sales of Pointing Devices for fiscal year 2016.

[0001032975-16-000083:mdna:131]
During fiscal year 2015, retail sales of Pointing Devices decreased 4%, compared to fiscal year 2014. The decrease in retail sales was primarily due to the continued weakness in the global PC market. The decrease was primarily from our high-end product offerings, which decreased 12%, followed by our low-end product offerings, which decreased 5%, partially offset by our mid-range product offerings, which increased 1%. Retail sales of corded mice decreased 4%, and retail sales of cordless mice decreased 5%.

[0001032975-16-000083:mdna:132]
Keyboards & Combos

[0001032975-16-000083:mdna:133]
Our Keyboards & Combos category comprises PC keyboards and keyboard/mice combo products.

[0001032975-16-000083:mdna:134]
During fiscal year 2016, retail sales of Keyboards & Combos increased 1%, compared to fiscal year 2015. The sales increase was driven mainly by cordless keyboards which grew 17%. Our best selling products in this category include the Wireless MK270 and MK520 Wireless combos.

[0001032975-16-000083:mdna:135]
During fiscal year 2015, retail sales of Keyboards & Combos increased 3%, compared to fiscal year 2014. The sales increase was primarily due to sales increase in our corded and cordless combos. Retail sales of corded and cordless combos increased 19% and 6%, respectively. Our best selling products in this category were the Logitech Wireless MK270 and MK520 Wireless combos, which feature powerful and reliable wireless connections and plug-and-play simplicity. Retail sales of corded and cordless keyboards decreased 9% and 7%, respectively.

[0001032975-16-000083:mdna:136]
Tablet & Other Accessories

[0001032975-16-000083:mdna:137]
Our Tablet & Other Accessories category comprises keyboards and covers for tablets and smartphones as well as other accessories for mobile devices.

[0001032975-16-000083:mdna:138]
During fiscal year 2016, retail sales of Tablet & Other Accessories decreased 26%, compared to fiscal year 2015. The reduction in sales reflects the combination of a declining market for iPad shipments, partially offset by the new product introduction of Create backlit tablet keyboard case for iPad Pro.

[0001032975-16-000083:mdna:139]
During fiscal year 2015, retail sales of Tablet & Other Accessories decreased 18%, compared to fiscal year 2014. The reduction in sales, primarily from tablet keyboards, reflects the combination of a declining demand for the iPad tablet platform and increased competition, partially offset by sales growth with our tablet covers for the iPads.

[0001032975-16-000083:mdna:140]
PC Webcams

[0001032975-16-000083:mdna:141]
Our PC Webcams category comprises PC-based webcams targeted primarily at consumers.

[0001032975-16-000083:mdna:142]
During fiscal year 2016, retail sales of PC Webcams increased 2%, compared to fiscal year 2015. The growth was primarily driven by Asia Pacific, with sales nearly doubling.

[0001032975-16-000083:mdna:143]
During fiscal year 2015, retail sales of PC Webcams decreased 15%, compared to fiscal year 2014. The weak sales reflect the ongoing structural decline of the consumer webcam market.

[0001032975-16-000083:mdna:144]
Other:

[0001032975-16-000083:mdna:145]
This category comprises a variety of products that we currently intend to transition out of, or have already transitioned out of, because they are no longer strategic to our business. Products currently included in this category include TV camera, Digital Video Security, TV and home speakers, Google TV products, Keyboard/Desktop accessories, and music docks.

[0001032975-16-000083:mdna:146]
During fiscal year 2016, retail sales of this category decreased 6%, compared to fiscal year 2015. During fiscal year 2015, retail sales of this category decreased 93%, compared to fiscal year 2014.

[0001032975-16-000083:mdna:147]
Gross Profit

[0001032975-16-000083:mdna:148]
Gross profit for fiscal years 2016, 2015 and 2014 was as follows (Dollars in thousands):

[0001032975-16-000083:mdna:149]
|  |  | Years Ended March 31, |  | Change |
|  |  | 2016 |  | 2015 |  | 2014 |  | 2016 vs. 2015 |  | 2015 vs. 2014 |
| Net sales |  | $ | 2,018,100 |  |  | $ | 2,004,908 |  |  | $ | 2,008,028 |  |  | 1 | % |  | — | % |
| Cost of goods sold |  | 1,337,053 |  |  | 1,299,451 |  |  | 1,346,489 |  |  | 3 |  |  | (3 | ) |
| Gross profit |  | $ | 681,047 |  |  | $ | 705,457 |  |  | $ | 661,539 |  |  | (3 | ) |  | 7 |  |
| Gross margin |  | 33.7 | % |  | 35.2 | % |  | 32.9 | % |  |  |  |  |  |  |

[0001032975-16-000083:mdna:150]
Gross profit consists of net sales, less cost of goods sold, which includes materials, direct labor and related overhead costs, costs of manufacturing facilities, royalties, costs of purchasing components from outside suppliers, distribution costs, warranty costs, customer support, shipping and handling cost, outside processing costs, write-down of inventories and amortization of intangible assets.

[0001032975-16-000083:mdna:151]
Gross margin is gross profit as a percentage of net sales. The decrease in gross margin during fiscal year 2016, compared to fiscal year 2015, is primarily driven by unfavorable fluctuations in currency exchange rates, partially offset by sales price increases and savings from supply chain efficiencies related to freight.

[0001032975-16-000083:mdna:152]
The increase in gross margin during fiscal year 2015, compared to fiscal year 2014, primarily resulted from an improvement attributable to cost reduction initiatives across the Pointing Devices, Keyboards & Combos and Mobile Speakers product categories, an improvement attributable to exiting non-strategic product categories, an improvement attributable to a $5.2 million discontinued products write-off in fiscal year 2014, and an improvement attributable to lower inventory reserves in fiscal year 2015 that were partially offset by a higher percentage of air shipments in fiscal year 2015.

[0001032975-16-000083:mdna:153]
Operating Expenses

[0001032975-16-000083:mdna:154]
Operating expenses for fiscal years 2016, 2015 and 2014 were as follows (Dollars in thousands):

[0001032975-16-000083:mdna:155]
|  |  | Years Ended March 31, |  | Change |
|  |  | 2016 |  | 2015 |  | 2014 |  | 2016 vs. 2015 |  | 2015 vs. 2014 |
| Marketing and selling |  | $ | 319,015 |  |  | $ | 321,749 |  |  | $ | 322,707 |  |  | (1 | )% |  | — | % |
| % of net sales |  | 15.8 | % |  | 16.0 | % |  | 16.1 | % |  |  |  |  |  |  |
| Research and development |  | 113,624 |  |  | 108,306 |  |  | 112,446 |  |  | 5 |  |  | (4 | ) |
| % of net sales |  | 5.6 | % |  | 5.4 | % |  | 5.6 | % |  |  |  |  |  |  |
| General and administrative |  | 101,548 |  |  | 125,995 |  |  | 112,689 |  |  | (19 | ) |  | 12 |  |
| % of net sales |  | 5.0 | % |  | 6.3 | % |  | 5.6 | % |  |  |  |  |  |  |
| Restructuring charges (Credits), net |  | 17,802 |  |  | (4,777 | ) |  | 8,001 |  |  | (473 | ) |  | (160 | ) |
| % of net sales |  | 0.9 | % |  | (0.2 | )% |  | 0.4 | % |  |  |  |  |  |  |
| Total operating expenses |  | $ | 551,989 |  |  | $551,273 |  | $ | 555,843 |  |  | — |  |  | (1 | ) |
| % of net sales |  | 27.4 | % |  | 27.5 | % |  | 27.7 | % |  |  |  |  |  |  |

[0001032975-16-000083:mdna:156]
Total operating expenses during fiscal year 2016 remained relatively flat, compared to fiscal year 2015, with increase in restructuring charges due to restructuring charges of $17.8 million in fiscal year 2016 compared to a restructuring credit of $4.8 million in fiscal year 2015, and increase in research and development expense partially offset by the decrease in general and administrative expense. Marketing and selling expenses were relatively flat.

[0001032975-16-000083:mdna:157]
The decrease in total operating expenses during fiscal year 2015, compared to fiscal year 2014, was mainly due to a restructuring credit of $4.8 million during fiscal year 2015 resulting from partial lease termination of our Silicon Valley campus, which was previously vacated and under a restructuring plan during fiscal year 2014, as opposed to a restructuring charge of $8.0 million during fiscal year 2014.

[0001032975-16-000083:mdna:158]
Marketing and Selling

[0001032975-16-000083:mdna:159]
Marketing and selling expenses consist of personnel and related overhead costs, corporate and product marketing, promotions, advertising, trade shows, customer and technical support and facilities costs.

[0001032975-16-000083:mdna:160]
During fiscal year 2016, marketing and selling expenses decreased by 1%, compared to fiscal year 2015. The decrease was primarily due to currency impact, offset by investments in growth markets.

[0001032975-16-000083:mdna:161]
During fiscal year 2015, marketing and selling expenses remained flat, compared to fiscal year 2014.

[0001032975-16-000083:mdna:162]
Research and Development

[0001032975-16-000083:mdna:163]
Research and development expenses consist of personnel and related overhead costs, contractors and outside consultants, supplies and materials, equipment depreciation and facilities costs, all associated with the design and development of new products and enhancements of existing products.

[0001032975-16-000083:mdna:164]
During fiscal year 2016, research and development expenses increased by 5%, compared to fiscal year 2015. The increase was primarily due to $4.6 million higher personnel-related expenses and $0.8 million higher consulting cost related to continuing investment in enhancement of existing products and development of new products.

[0001032975-16-000083:mdna:165]
During fiscal year 2015, research and development expenses decreased 4%, compared to fiscal year 2014. The decrease was primarily due to a $1.5 million decrease in outsourcing research and development activities during fiscal year 2015, and $1.5 million savings from depreciation and amortization expense.

[0001032975-16-000083:mdna:166]
General and Administrative

[0001032975-16-000083:mdna:167]
General and administrative expenses consist primarily of personnel and related overhead and facilities costs for the finance, information systems, executives, human resources and legal functions.

[0001032975-16-000083:mdna:168]
During fiscal year 2016, general and administrative expenses decreased by 19%, compared to fiscal year 2015. The decrease was primarily due to reduction of $19.1 million related to the Audit Committee independent investigation and related expenses incurred in fiscal year 2015 and a $2.5 million decrease in personnel-related cost.

[0001032975-16-000083:mdna:169]
During fiscal year 2015, general and administrative expense increased 12% compared to fiscal year 2014. The increase was primarily due to $23.7 million in expense related to the Audit Committee independent investigation and related expenses, partially offset by infrastructure cost savings such as a $6.8 million decrease in information technology costs, including third party vendor cost, and a $5.2 million decrease in facility expense as a result of the consolidation of properties.

[0001032975-16-000083:mdna:170]
Restructuring Charges

[0001032975-16-000083:mdna:171]
The following table summarizes restructuring-related activities during the fiscal years 2016 and 2015 from continuing operations (in thousands):

[0001032975-16-000083:mdna:172]
|  |  | Restructuring - Continuing Operations |
|  |  | TerminationBenefits |  | Lease ExitCosts |  | Other |  | Total |
| Accrual balance at March 31, 2014 |  | $ | — |  |  | $ | 7,309 |  |  | $ | — |  |  | $ | 7,309 |  |
| Credits, net |  | — |  |  | (4,777 | ) |  | — |  |  | (4,777 | ) |
| Cash payments |  | — |  |  | (1,578 | ) |  | — |  |  | (1,578 | ) |
| Accrual balance at March 31, 2015 |  | — |  |  | 954 |  |  | — |  |  | 954 |  |
| Charges, net |  | 17,280 |  |  | 337 |  |  | 185 |  |  | 17,802 |  |
| Cash payments |  | (11,373 | ) |  | (1,166 | ) |  | (185 | ) |  | (12,724 | ) |
| Accrual balance at March 31, 2016 |  | $ | 5,907 |  |  | $ | 125 |  |  | $ | — |  |  | $ | 6,032 |  |

[0001032975-16-000083:mdna:173]
The following table summarizes restructuring-related activities during the fiscal years 2016 and 2015 from discontinued operations (in thousands):

[0001032975-16-000083:mdna:174]
|  |  | Restructuring - Discontinued Operations |
|  |  | TerminationBenefits |  | Lease ExitCosts |  | Other |  | Total |
| Accrual balance at March 31, 2014 |  | $ | 142 |  |  | $ | 110 |  |  | $ | — |  |  | $ | 252 |  |
| Charges |  | (86 | ) |  | (25 | ) |  | — |  |  | (111 | ) |
| Cash payments |  | (56 | ) |  | — |  |  | — |  |  | (56 | ) |
| Accrual balance at March 31, 2015 |  | — |  |  | 85 |  |  | — |  |  | 85 |  |
| Charges, net |  | 7,095 |  |  | — |  |  | 805 |  |  | 7,900 |  |
| Cash payments |  | (6,460 | ) |  | (14 | ) |  | (805 | ) |  | (7,279 | ) |
| Adjustment as a result of disposition of discontinued operations |  | (267 | ) |  | (71 | ) |  | — |  |  | (338 | ) |
| Accrual balance at March 31, 2016 |  | $ | 368 |  |  | $ | — |  |  | $ | — |  |  | $ | 368 |  |

[0001032975-16-000083:mdna:175]
During the first quarter of fiscal year 2016, we implemented a restructuring plan to exit the OEM business, reorganize Lifesize to sharpen its focus on its cloud-based offering, and streamline our overall cost structure, including overhead and infrastructure cost reductions with a targeted resource realignment. Restructuring charges incurred during the year ended March 31, 2016 under this plan primarily consisted of severance and other ongoing

[0001032975-16-000083:mdna:176]
and one-time termination benefits. Charges and other costs related to the workforce reduction and structure realignment are presented as restructuring charges in the Consolidated Statements of Operations. On a total company basis, including the Lifesize video conferencing business as reported in discontinued operations, we have incurred $25.5 million under this restructuring plan, including $24.4 million for cash severance and other personnel costs. We have paid $19.0 million as of March 31, 2016, on a total company basis. We substantially completed this restructuring plan by the fourth quarter of fiscal year 2016, subject to the payment of accrued balance as noted above.

[0001032975-16-000083:mdna:177]
During the fourth quarter of fiscal year 2013, we implemented a restructuring plan to align its organization to its strategic priorities of increasing focus on mobility products, improving profitability in PC-related products and enhancing global operational efficiencies. As part of this restructuring plan, we reduced our worldwide non-direct labor workforce. Restructuring charges under this plan primarily consisted of severance and other one-time termination benefits. During fiscal year 2015, we recorded a $4.9 million restructuring credit on a total company basis, primarily as a result of partial termination of our lease agreement for the Silicon Valley campus, which was previously vacated under the restructuring plan during fiscal year 2014. We substantially completed this restructuring plan by the fourth quarter of fiscal year 2014.

[0001032975-16-000083:mdna:178]
Interest Income (Expense), Net

[0001032975-16-000083:mdna:179]
Interest income and expense for fiscal years 2016, 2015 and 2014 were as follows (in thousands):

[0001032975-16-000083:mdna:180]
|  |  | Years Ended March 31, |
|  |  | 2016 |  | 2015 |  | 2014 |
| Interest income |  | $ | 790 |  |  | $ | 1,197 |  |  | $ | 1,797 |  |
| Interest expense |  | — |  |  | — |  |  | (2,228 | ) |
|  |  | $ | 790 |  |  | $ | 1,197 |  |  | $ | (431 | ) |

[0001032975-16-000083:mdna:181]
Interest expense decreased during fiscal year 2015, compared to fiscal year 2014. The decrease was primarily due to the termination of our $250 million Senior Revolving Credit Facility during fiscal year 2014. There were no new borrowings since then.

[0001032975-16-000083:mdna:182]
Other Income (Expense), Net

[0001032975-16-000083:mdna:183]
Other income and expense for fiscal years 2016, 2015 and 2014 were as follows (in thousands):

[0001032975-16-000083:mdna:184]
|  |  | Years Ended March 31, |
|  |  | 2016 |  | 2015 |  | 2014 |
| Investment income (loss) related to deferred compensation plan |  | $ | (364 | ) |  | $ | 1,055 |  |  | $ | 1,487 |  |
| Impairment of investments |  | — |  |  | (2,298 | ) |  | (624 | ) |
| Currency exchange gain (loss), net |  | 2,110 |  |  | (1,175 | ) |  | (62 | ) |
| Other |  | (122 | ) |  | 120 |  |  | 1,238 |  |
|  |  | $ | 1,624 |  |  | $ | (2,298 | ) |  | $ | 2,039 |  |

[0001032975-16-000083:mdna:185]
Investment income (loss) for fiscal years 2016, 2015 and 2014 represents earnings, gains, and losses on trading investments related to a deferred compensation plan offered by one of our subsidiaries.

[0001032975-16-000083:mdna:186]
The $2.3 million and $0.6 million investment impairment charges in fiscal years 2015 and 2014, respectively, primarily resulted from the write-down of investments in privately-held companies.

[0001032975-16-000083:mdna:187]
Currency exchange gains or losses relate to balances denominated in currencies other than the functional currency in our subsidiaries, as well as to the sale of currencies, and to gains or losses recognized on foreign currency exchange forward contracts. We do not speculate in currency positions, but we are alert to opportunities to maximize foreign exchange gains and minimize foreign currency exchange losses.

[0001032975-16-000083:mdna:188]
Provision for Income Taxes

[0001032975-16-000083:mdna:189]
The provision for income taxes and the effective income tax rate for fiscal years 2016, 2015 and 2014 were as follows (in thousands):

[0001032975-16-000083:mdna:190]
|  |  | Years Ended March 31, |
|  |  | 2016 |  | 2015 |  | 2014 |
| Provision for income taxes |  | $ | 3,110 |  |  | $ | 4,654 |  |  | $ | 1,313 |  |
| Effective income tax rate |  | 2.4 | % |  | 3.0 | % |  | 1.2 | % |

[0001032975-16-000083:mdna:191]
The changes in the effective income tax rate between fiscal years 2016 and 2015 and between fiscal years 2015 and 2014 were primarily due to the mix of income and losses in the various tax jurisdictions in which we operate.  Further, there was a tax benefit of $16.1 million in fiscal year 2016 related to the reversal of uncertain tax positions resulting from the expiration of the statutes of limitations. In fiscal year 2015, there was a tax benefit of $15.4 million related to the reversal of uncertain tax positions resulting from the expiration of the statutes of limitations and the closure of tax examination in the State of California of the United States. In fiscal year 2014, there was a tax benefit of $14.3 million related to the reversal of uncertain tax positions resulting from the expiration of the statutes of limitations.

[0001032975-16-000083:mdna:192]
On December 18, 2015, the enactment of the Protecting Americans from Tax Hikes Act of 2015 in the United States extended the federal research and development tax credit permanently which had previously expired on December 31, 2014. The provision for income taxes for fiscal year ended March 31, 2016 reflected a $1.5 million tax benefit as a result of the extension of the tax credit.

[0001032975-16-000083:mdna:193]
As of March 31, 2016 and March 31, 2015, the total amounts of unrecognized tax benefits due to uncertain tax positions were $69.9 million and $79.0 million, respectively, all of which would affect the effective income tax rates if recognized.

[0001032975-16-000083:mdna:194]
As of March 31, 2016, we had $59.7 million in non-current income taxes payable and $0.1 million in current income taxes payable, including interest and penalties, related to our income tax liability for uncertain tax positions. As of March 31, 2015, we had $72.1 million in non-current income taxes payable and $0.1 million in current income taxes payable. We continue to recognize interest and penalties related to unrecognized tax positions in income tax expense. We recognized $0.3 million, $0.8 million and $1.1 million in interest and penalties in income tax expense during fiscal years 2016, 2015 and 2014, respectively. As of March 31, 2016, 2015 and 2014, we had $3.6 million, $4.9 million and $5.6 million of accrued interest and penalties related to uncertain tax positions, respectively.

[0001032975-16-000083:mdna:195]
We file Swiss and foreign tax returns. We received final tax assessments in Switzerland through fiscal year 2013.  For other foreign jurisdictions such as the United States, we are generally not subject to tax examinations for years prior to fiscal year 2012. We are under examination and have received assessment notices in foreign tax jurisdictions. If the examinations are resolved unfavorably, there is a possibility they may have a material negative impact on our results of operations.

[0001032975-16-000083:mdna:196]
Liquidity and Capital Resources

[0001032975-16-000083:mdna:197]
Cash Balances, Available Borrowings, and Capital Resources

[0001032975-16-000083:mdna:198]
At March 31, 2016, we had cash and cash equivalents of $519.2 million, compared with $533.4 million at March 31, 2015. Our cash and cash equivalents consist of bank demand deposits and short-term time deposits of which 74% is held by our Swiss-based entities and 17% is held by our subsidiaries in Hong Kong and China. We do not expect to incur any material adverse tax impact except for what has been recognized or be significantly inhibited by any country in which we do business from the repatriation of funds to Switzerland, our home domicile.

[0001032975-16-000083:mdna:199]
At March 31, 2016, our working capital was $511.3 million, compared with working capital of $563.8 million at March 31, 2015, excluding working capital from discontinued operations. The decrease in working capital over the prior year was primarily due to lower balances of cash and cash equivalents, inventories, accounts receivables, net, and deferred tax assets which were reclassified to non-current assets as of March 31, 2016 pursuant to the adoption of ASU 2015-17, partially offset by lower accounts payable at March 31, 2016.

[0001032975-16-000083:mdna:200]
During fiscal year 2016, we generated $183.1 million cash from operating activities. Our main sources of operating cash flows were from net income after adding back non-cash expenses of depreciation, amortization, and share-based compensation expense, and from decrease in inventories and accounts receivable, net, partially offset

[0001032975-16-000083:mdna:201]
by decrease in accounts payable and a decrease in accrued and other liabilities. Net cash used in investing activities was $60.7 million, primarily for purchase of property, plant, and equipment of $56.6 million, and investments in privately held companies of $2.4 million, and payments for divestiture of discontinued operations net of cash sold of $1.4 million. Net cash used in financing activities was $141.7 million, primarily for the $85.9 million cash dividends paid during the year, $70.4 million purchase of treasury shares and $7.2 million tax withholdings related to net share settlements of restricted stock units, partially offset by $19.8 million proceeds received from the sale of shares upon exercise of options and purchase rights.

[0001032975-16-000083:mdna:202]
We had several uncommitted, unsecured bank lines of credit aggregating to $45.7 million as of March 31, 2016. There are no financial covenants under these lines of credit with which we must comply. As of March 31, 2016, we had outstanding bank guarantees of $19.7 million under these lines of credit. There are no financial covenants under these credit lines.

[0001032975-16-000083:mdna:203]
The following table summarizes our Consolidated Statements of Cash Flows (in thousands):

[0001032975-16-000083:mdna:204]
|  |  | Years Ended March 31, |
|  |  | 2016 |  | 2015 |  | 2014 |
| Net cash provided by operating activities |  | $ | 183,111 |  |  | $ | 178,632 |  |  | $ | 205,421 |  |
| Net cash used in investing activities |  | (60,690 | ) |  | (48,289 | ) |  | (46,803 | ) |
| Net cash used in financing activities |  | (141,669 | ) |  | (48,854 | ) |  | (22,681 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  | 1,405 |  |  | (13,863 | ) |  | (349 | ) |
| Net increase (decrease) in cash and cash equivalents |  | $ | (17,843 | ) |  | $ | 67,626 |  |  | $ | 135,588 |  |

[0001032975-16-000083:mdna:205]
| The following amounts reflected in the table above are from discontinued operations: |
| Depreciation |  | $ | 2,207 |  |  | $ | 2,562 |  |  | $ | 3,402 |  |
| Amortization of other intangible assets |  | $ | 1,438 |  |  | $ | 7,598 |  |  | $ | 15,369 |  |
| Share-based compensation |  | $ | 332 |  |  | $ | 1,634 |  |  | $ | 2,318 |  |
| Purchases of property, plant and equipment |  | $ | 1,431 |  |  | $ | 3,598 |  |  | $ | 4,233 |  |
| Cash and cash equivalents, beginning of the period |  | $ | 3,659 |  |  | $ | 1,894 |  |  | $ | 2,326 |  |
| Cash and cash equivalents, end of the period |  | $ | — |  |  | $ | 3,659 |  |  | $ | 1,894 |  |

[0001032975-16-000083:mdna:206]
Cash Flow from Operating Activities

[0001032975-16-000083:mdna:207]
The following table presents selected financial information and statistics for fiscal years 2016, 2015 and 2014 (dollars in thousands):

[0001032975-16-000083:mdna:208]
|  |  | March 31, |
|  |  | 2016 |  | 2015 |  | 2014 |
| Accounts receivable, net |  | $ | 142,778 |  |  | $ | 167,196 |  |  | $ | 166,877 |  |
| Inventories |  | 228,786 |  |  | 255,980 |  |  | 212,599 |  |
| Days sales in accounts receivable ("DSO")(Days)(1) |  | 30 |  |  | 34 |  |  | 33 |  |
| Inventory turnover ("ITO")(x)(2) |  | 5.0 |  |  | 4.7 |  |  | 6.0 |  |

[0001032975-16-000083:mdna:209]
______________________________

[0001032975-16-000083:mdna:210]
| (1) | DSO is determined using ending accounts receivable as of the most recent quarter-end and net sales for the most recent quarter. |

[0001032975-16-000083:mdna:211]
| (2) | ITO is determined using ending inventories and annualized cost of goods sold (based on the most recent quarterly cost of goods sold). |

[0001032975-16-000083:mdna:212]
Inventory turnover as of March 31, 2016 increased compared to March 31, 2015. The increase was primarily due to our exit from the OEM business at the end of the quarter ended December 31, 2015 and with no OEM inventories as of March 31, 2016.

[0001032975-16-000083:mdna:213]
Inventory turnover as of March 31, 2015 decreased compared to March 31, 2014. The decrease was primarily due to higher inventory levels due to the port strike on the west coast of the United States and change in shipping strategy from air to ocean during the fourth quarter of fiscal year 2015.

[0001032975-16-000083:mdna:214]
If we are not successful in launching and phasing in our new products launched during the current fiscal year, or we are not able to sell the new products at the prices planned, it could have a material impact on our revenue, gross profit margin, operating results including operating cash flow, and inventory turnover in the future.

[0001032975-16-000083:mdna:215]
Cash Flow from Investing Activities

[0001032975-16-000083:mdna:216]
The following table presents cash flow from investing activities for fiscal years 2016, 2015 and 2014 (dollars in thousands):

[0001032975-16-000083:mdna:217]
|  |  | Years Ended March 31, |
|  |  | 2016 |  | 2015 |  | 2014 |
| Purchases of property, plant and equipment |  | $ | (56,615 | ) |  | $ | (45,253 | ) |  | $ | (46,658 | ) |
| Investment in privately held companies |  | (2,419 | ) |  | (2,550 | ) |  | (300 | ) |
| Payments for divestiture of discontinued operations, net of cash sold |  | (1,395 | ) |  | — |  |  | — |  |
| Changes in restricted cash |  | (715 | ) |  | — |  |  | — |  |
| Acquisitions, net of cash acquired |  | — |  |  | (926 | ) |  | (650 | ) |
| Proceeds from return of investment from strategic investments |  | — |  |  | — |  |  | 261 |  |
| Purchase of trading investments |  | (9,619 | ) |  | (5,034 | ) |  | (8,450 | ) |
| Proceeds from sales of trading investments |  | 10,073 |  |  | 5,474 |  |  | 8,994 |  |
|  |  | $ | (60,690 | ) |  | $ | (48,289 | ) |  | $ | (46,803 | ) |

[0001032975-16-000083:mdna:218]
Our expenditures for property, plant and equipment during fiscal year 2016, 2015 and 2014 were primarily for leasehold improvements, computer hardware and software, tooling and equipment.

[0001032975-16-000083:mdna:219]
Our expenditures for property, plant and equipment increased during fiscal year 2016, compared to fiscal year 2015, mainly due to the building of production lines to accommodate the in-house manufacturing of certain products compared with purchase from third parties in the prior period to align with our goal to achieve cost savings. During fiscal year 2015, purchases of property, plant and equipment remained relatively stable compared to fiscal year 2014.

[0001032975-16-000083:mdna:220]
During fiscal year 2016, we made a $1.5 million strategic investment in one privately held company and $0.9 million investment in a limited partnership with a private investment fund. During fiscal year 2015, we made a $2.6 million strategic investment in one privately held company and acquired one privately held company for $0.9 million. During fiscal year 2014, we acquired one privately held company for $0.7 million.

[0001032975-16-000083:mdna:221]
During fiscal year 2016, the net payments for divestiture of discontinued operations were $1.4 million, and there was $0.7 million for cash outflow to an escrow account for purchase of a domain name.

[0001032975-16-000083:mdna:222]
The purchases and sales of trading investments during fiscal years 2016, 2015 and 2014 represent mutual fund activity directed by participants in a deferred compensation plan offered by one of our subsidiaries. The mutual funds are held by a Rabbi Trust.

[0001032975-16-000083:mdna:223]
Cash Flow from Financing Activities

[0001032975-16-000083:mdna:224]
The following table presents cash flow from financing activities for fiscal years 2016, 2015 and 2014 (dollars in thousands):

[0001032975-16-000083:mdna:225]
|  |  | Years Ended March 31, |
|  |  | 2016 |  | 2015 |  | 2014 |
| Payment of cash dividends |  | $ | (85,915 | ) |  | $ | (43,767 | ) |  | $ | (36,123 | ) |
| Purchases of treasury shares |  | (70,358 | ) |  | (1,663 | ) |  | — |  |
| Contingent consideration related to prior acquisition |  | — |  |  | (100 | ) |  | — |  |
| Repurchase of ESPP awards |  | — |  |  | (1,078 | ) |  | — |  |
| Proceeds from sales of shares upon exercise of options and purchase rights |  | 19,767 |  |  | 4,138 |  |  | 16,914 |  |
| Tax withholdings related to net share settlements of restricted stock units |  | (7,247 | ) |  | (9,215 | ) |  | (5,718 | ) |
| Excess tax benefits from share-based compensation |  | 2,084 |  |  | 2,831 |  |  | 2,246 |  |
|  |  | $ | (141,669 | ) |  | $ | (48,854 | ) |  | $ | (22,681 | ) |

[0001032975-16-000083:mdna:226]
Translation effect of exchange rate changes on cash and cash equivalents

[0001032975-16-000083:mdna:227]
During fiscal year 2016, there was a $1.4 million currency translation exchange rate effect on cash and cash equivalents, compared to a $13.9 million currency translation exchange rate effect during fiscal year 2015, and a $0.3 million currency translation exchange rate effect during fiscal year 2014. Higher currency translation exchange effect during fiscal year 2015 was primarily due to the 22% weakening of the Euro versus the U.S Dollar during fiscal year 2015, which had an adverse impact on our cash and cash equivalents balances in subsidiaries with functional currency as Euro.

[0001032975-16-000083:mdna:228]
Cash Outlook

[0001032975-16-000083:mdna:229]
Our principal sources of liquidity are our cash and cash equivalents, cash flow generated from operations and, to a much lesser extent, capital markets and borrowings. Our future working capital requirements and capital expenditures may increase to support investment in product innovations and growth opportunities, or to acquire or invest in complementary businesses, products, services, and technologies.

[0001032975-16-000083:mdna:230]
In March 2015, we announced a plan to pay $250 million in cumulative dividends for fiscal year 2015 through fiscal year 2017. During fiscal year 2016, we paid a cash dividend of CHF 83.1 million (U.S. Dollar amount of $85.9 million) out of retained earnings. During fiscal year 2015, we paid a cash dividend of CHF 43.1 million (U.S. Dollar amount of $43.8 million) out of retained earnings.

[0001032975-16-000083:mdna:231]
In March 2014, our Board of Directors approved a share buyback program, which authorizes us to invest up to $250.0 million to purchase our own shares. Our share buyback program provides us with the opportunity to make repurchases during periods of favorable market conditions and is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Purchases may be started or stopped at any time without prior notice depending on market conditions and other factors. During fiscal years 2016 and 2015, 5.0 million and 0.1 million shares were repurchased for $70.4 million and $1.7 million, respectively, under this program.

[0001032975-16-000083:mdna:232]
On April 12, 2016, Logitech Europe S.A., one of our wholly-owned subsidiaries, JayBird, LLC, a Utah limited liability company (“Jaybird”), the unit holders of Jaybird and Judd Armstrong (as the Sellers’ Representative under the Securities Purchase Agreement) entered into a securities purchase agreement. On April 20, 2016, we acquired all of the equity interests of Jaybird in exchange for approximately $50 million in cash, with the potential of an additional earn-out of up to $45 million based on achievement of net revenue growth targets over two years.

[0001032975-16-000083:mdna:233]
Our other contractual obligations and commitments that require cash are described in the following sections.

[0001032975-16-000083:mdna:234]
For over ten years, we have generated positive cash flows from our operating activities, including cash from operations of $183.1 million, $178.6 million and $205.4 million during fiscal years 2016, 2015, and 2014, respectively. If we do not generate sufficient operating cash flows to support our operations and future planned cash requirements, our operations could be harmed and our access to credit facilities could be restricted or eliminated.

[0001032975-16-000083:mdna:235]
However, we believe that the trend of our historical cash flow generation, our projections of future operations and our available cash balances will provide sufficient liquidity to fund our operations for at least the next 12 months.

[0001032975-16-000083:mdna:236]
Contractual Obligations and Commitments

[0001032975-16-000083:mdna:237]
The following table summarizes our contractual obligations and commitments as of March 31, 2016 (in thousands):

[0001032975-16-000083:mdna:238]
|  |  |  |  | Payments Due by Period |
|  |  | March 31, 2016 | <1 year |  | 1-3 years |  | 4-5 years |  | >5 years |
| Inventory commitments |  | $ | 158,063 |  |  | $ | 158,063 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Capital commitments |  | 6,188 |  |  | 6,188 |  |  | — |  |  | — |  |  | — |  |
| Expected contribution to employee benefit plan |  | 4,881 |  |  | 4,881 |  |  | * |  |  | * |  |  | * |  |
| Operating leases obligations |  | 31,974 |  |  | 7,558 |  |  | 10,254 |  |  | 7,623 |  |  | 6,539 |  |
|  |  | $ | 201,106 |  |  | $ | 176,690 |  |  | $ | 10,254 |  |  | $ | 7,623 |  |  | $ | 6,539 |  |

[0001032975-16-000083:mdna:239]
*  Employee Benefit Plan Obligation:  Commitments under the retirement plans relate to expected contributions to be made to our defined benefit plans for the next year only. We fund our pension plans so that we meet at least the minimum contribution requirements, as established by local government, funding and taxing authorities. Expected contributions and payments to our defined benefit pension plans and non-retirement post-employment benefit plans beyond one year are excluded from the contractual obligations table because they are dependent on numerous factors that may result in a wide range of outcomes and thus are impractical to estimate. For more information on our defined benefit pension plans and non-retirement post-employment benefit plans, see Note 5 to the Consolidated Financial Statements in Item 8, which is incorporated herein by reference.

[0001032975-16-000083:mdna:240]
Operating Leases Obligation

[0001032975-16-000083:mdna:241]
We lease facilities under operating leases, certain of which require us to pay property taxes, insurance and maintenance costs. Operating leases for facilities are generally renewable at our option and usually include escalation clauses linked to inflation. The remaining terms on our non-cancelable operating leases expire in various years through 2030.

[0001032975-16-000083:mdna:242]
Commitment for Acquisition

[0001032975-16-000083:mdna:243]
On April 20, 2016 we acquired Jaybird LLC of Salt Lake City, Utah, ("Jaybird") for approximately $50 million in cash, with an additional earn-out of up to $45 million based on achievement of growth targets over two years.

[0001032975-16-000083:mdna:244]
Purchase Commitments

[0001032975-16-000083:mdna:245]
As of March 31, 2016, we have fixed purchase commitments of $158.1 million for inventory purchases made in the normal course of business to original design manufacturers, contract manufacturers and other suppliers, the majority of which are expected to be fulfilled during the first quarter of fiscal year 2017. We recorded a liability for firm, non-cancelable, and unhedged inventory purchase commitments in excess of anticipated demand or market value consistent with our valuation of excess and obsolete inventory. As of March 31, 2016, the liability for these purchase commitments was $8.5 million and is recorded in accrued and other current liabilities and is not included in the preceding table. We have fixed purchase commitments of $6.2 million for capital expenditures, primarily related to commitments for tooling, computer hardware and leasehold improvements. We expect to continue making capital expenditures in the future to support product development activities and ongoing and expanded operations as well as aligning our inventory strategy to transition from ODM to in-house production. Although open purchase commitments are considered enforceable and legally binding, the terms generally allow us the option to reschedule and adjust our requirements based on business needs prior to delivery of goods.

[0001032975-16-000083:mdna:246]
Income Taxes Payable

[0001032975-16-000083:mdna:247]
As of March 31, 2016, we had $59.7 million in non-current income taxes payable and $0.1 million in current income taxes payable, including interest and penalties, related to our income tax liability for uncertain tax positions. At this time, we are unable to make a reasonably reliable estimate of the timing of payments in

[0001032975-16-000083:mdna:248]
individual years in connection with these tax liabilities; therefore, such amounts are not included in the above contractual obligation table.

[0001032975-16-000083:mdna:249]
Off-Balance Sheet Arrangements

[0001032975-16-000083:mdna:250]
We have not entered into any transactions with unconsolidated entities whereby we have financial guarantees, subordinated retained interests, derivative instruments or other contingent arrangements that expose us to material continuing risks, contingent liabilities, or any other obligation under a variable interest in an unconsolidated entity that provides financing, liquidity, market risk or credit risk support to us.

[0001032975-16-000083:mdna:251]
Investment Commitments

[0001032975-16-000083:mdna:252]
During 2015, we entered into a limited partnership agreement with a private investment fund specialized in early-stage start-up consumer hardware electronics companies and committed a capital contribution of $4.0 million over the life of the fund. As of March 31, 2016, $3.1 million of the committed capital contribution has not yet been called by the fund.

[0001032975-16-000083:mdna:253]
Settlement

[0001032975-16-000083:mdna:254]
In April 2016, we entered into a settlement with the SEC related to the accounting for Revue inventory valuation reserves that resulted in the restatement described in the Fiscal Year 2014 Annual Report on Form 10-K, revision to our consolidated financial statements concerning warranty accruals and amortization of intangible assets presented in our Amended Annual Report on Form 10-K/A, filed on August 7, 2013, and our transactions with a distributor for fiscal year 2007 through fiscal year 2009.  We entered into the settlement without admitting or denying the findings of the SEC’s investigation and paid a civil penalty of $7.5 million. We made an accrual of the same amount in our consolidated financial statements as of March 31, 2016. This amount was paid in April 2016.

[0001032975-16-000083:mdna:255]
Guarantees

[0001032975-16-000083:mdna:256]
Logitech Europe S.A. guaranteed payments of third-party contract manufacturers' purchase obligations. As of March 31, 2016, the maximum amount of this guarantee was $3.8 million, of which $1.0 million of guaranteed purchase obligations were outstanding.

[0001032975-16-000083:mdna:257]
Indemnifications

[0001032975-16-000083:mdna:258]
We indemnify certain of our suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys' fees. As of March 31, 2016, no amounts have been accrued for indemnification provisions. We do not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under our indemnification arrangements.

[0001032975-16-000083:mdna:259]
We also indemnify our current and former directors and certain of our current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. We are unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not capped, the obligations are conditional in nature, and the facts and circumstances involved in any situation that might arise are variable.

[0001032975-16-000083:mdna:260]
The Stock Purchase Agreement that we entered into in connection with the investment by three venture capital firms in Lifesize, Inc. contains representations, warranties and covenants of Logitech and Lifesize, Inc. to the Venture Investors. Subject to certain limitations, we have agreed to indemnify the Venture Investors and certain persons related to the Venture Investors for certain losses resulting from breaches of or inaccuracies in such representations, warranties and covenants as well as certain other obligations, including third party expenses, restructuring costs and pre-closing tax obligations of Lifesize.
