# LOGI note change history — 0001032975-20-000033 → 0001032975-20-000048


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-10-22):
[0001032975-20-000048:note_history:1]
Changes in the Company’s warranty liability for the three and six months ended September 30, 2020 and 2019 were as follows (in thousands):
  (was, 2020-07-23, similarity 0.9231):
[0001032975-20-000033:note_history:1]
Changes in the Company’s warranty liability for the three months ended June 30, 2020 and 2019 were as follows (in thousands):

- added (2020-10-22):
[0001032975-20-000048:note_history:2]
|  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Beginning of the period | $ | 39,450 |  |  | $ | 35,814 |  |  | $ | 40,039 |  |  | $ | 34,229 |  |
| Provision | 9,494 |  |  | 8,509 |  |  | 14,883 |  |  | 17,044 |  |
| Settlements | (7,541 | ) |  | (6,727 | ) |  | (13,702 | ) |  | (13,704 | ) |
| Currency translation | 379 |  |  | (374 | ) |  | 562 |  |  | (347 | ) |
| End of the period | $ | 41,782 |  |  | $ | 37,222 |  |  | $ | 41,782 |  |  | $ | 37,222 |  |

- changed (2020-10-22):
[0001032975-20-000048:note_history:3]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of September 30, 2020, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.
  (was, 2020-07-23, similarity 0.9899):
[0001032975-20-000033:note_history:3]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of June 30, 2020, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

- removed (2020-10-22):
[0001032975-20-000033:note_history:4]
|  | Three Months EndedJune 30, |
|  | 2020 |  | 2019 |
| Beginning of the period | $ | 40,039 |  |  | $ | 34,229 |  |
| Provision | 5,389 |  |  | 8,535 |  |
| Settlements | (6,161 | ) |  | (6,977 | ) |
| Currency translation | 183 |  |  | 27 |  |
| End of the period | $ | 39,450 |  |  | $ | 35,814 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-10-22):
[0001032975-20-000048:note_history:5]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and six months ended September 30, 2020 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2021, or any future periods.
  (was, 2020-07-23, similarity 0.7702):
[0001032975-20-000033:note_history:5]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three months ended June 30, 2020 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2021, or any future periods.

- changed (2020-10-22):
[0001032975-20-000048:note_history:6]
Other than the recent accounting pronouncements adopted and discussed below under Recent Accounting Pronouncements Adopted and Summary of Significant Accounting Policies, there have been no material changes in the Company’s significant accounting policies during the six months ended September 30, 2020 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2020.
  (was, 2020-07-23, similarity 0.9423):
[0001032975-20-000033:note_history:6]
Other than the recent accounting pronouncements adopted and discussed below under Recent Accounting Pronouncements Adopted and Summary of Significant Accounting Policies, there have been no material changes in the Company’s significant accounting policies during the three months ended June 30, 2020 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2020.

- changed (2020-10-22):
[0001032975-20-000048:note_history:7]
We are subject to risks and uncertainties as a result of the novel coronavirus (COVID-19). The measures taken by many countries in response have contributed to a general slowdown in the global economy and adversely affected, and could in the future continue to adversely affect, the Company's business and operations. Capital markets and economies worldwide have also been negatively impacted by COVID-19 and it is still unclear how lasting and deep the economic impacts will be. During the three and six months ended September 30, 2020, as well as in the fourth quarter of fiscal year 2020, the COVID-19 pandemic had mixed effects on the Company’s results of operations, and it may continue to have mixed or adverse effects. While there was high demand and consumption of certain of our products that led to increased sales and operating income during the fourth quarter of fiscal year 2020 and the three and six months ended September 30, 2020, at the same time the Company experienced disruptions to supply chain and logistics services, inventory constraints and increased logistics costs. The ongoing and full extent of the impact of the COVID-19 pandemic on the Company's business and operational and financial performance and condition, including the sustainability of its effect on trends positive to the Company, is uncertain and will depend on many factors outside the Company's control, including but not limited to the timing, extent, duration and effects of the virus and any of its mutations, the development and availability of effective treatments and vaccines, the imposition of effective public safety and other protective measures, the impact of COVID-19 on the global economy and demand for the Company's products and services. Should the COVID-19 pandemic or global economic slowdown not improve or worsen, or if the Company's attempt to mitigate its impact on its operations and costs is not successful, the Company's business, results of operations, financial condition and prospects may be adversely affected.
  (was, 2020-07-23, similarity 0.9497):
[0001032975-20-000033:note_history:7]
We are subject to risks and uncertainties as a result of the novel coronavirus (COVID-19) and the measures taken by many countries in response have contributed to a general slowdown in the global economy and adversely affected, and could in the future continue to adversely affect, the Company's business and operations. Capital markets and economies worldwide have also been negatively impacted by COVID-19 and it is still unclear how lasting and deep the economic impacts will be. During the three months ended June 30, 2020, as well as in the fourth quarter of fiscal year 2020, the COVID-19 pandemic had mixed effects on the Company’s results of operations, and it may continue to have mixed or adverse effects. While there was high demand and consumption of certain of our products that led to increased sales and operating income during the fourth quarter of fiscal year 2020 and the first quarter of fiscal year 2021, at the same time the Company experienced disruptions to supply chain and logistics services, inventory constraints and increased logistics costs. The ongoing and full extent of the impact of the COVID-19 pandemic on the Company's business and operational and financial performance and condition is uncertain and will depend on many factors outside the Company's control, including but not limited to the timing, extent, duration and effects of the virus and any of its mutations, the development and availability of effective treatments and vaccines, the imposition of effective public safety and other protective measures, the impact of COVID-19 on the global economy and demand for the Company's products and services. Should the COVID-19 pandemic or global economic slowdown not improve or worsen, or if the Company's attempt to mitigate its impact on its operations and costs is not successful, the Company's business, results of operations, financial condition and prospects may be adversely affected.

- changed (2020-10-22):
[0001032975-20-000048:note_history:8]
In August 2018, the FASB issued ASU 2018-13, "Fair Value Measurement (Topic 820): Disclosure Framework - Changes to the Disclosure Requirements for Fair Value Measurements" (ASU 2018-13), which eliminates, adds and modifies certain disclosure requirements for fair value measurements, including eliminating the requirement to disclose the amount of and reasons for transfers between Level 1 and Level 2 of the fair value hierarchy, and requiring the range and weighted average used to develop significant unobservable inputs for Level 3 fair value measurements.  Some of these disclosure changes must be applied prospectively while others retrospectively depending on requirement. The Company adopted this standard effective April 1, 2020. The adoption of ASU 2018-13 did not have a material impact on the Company's condensed consolidated financial statements.
  (was, 2020-07-23, similarity 0.9976):
[0001032975-20-000033:note_history:8]
In August 2018, the FASB issued ASU 2018-13, "Fair Value Measurement (Topic 820): Disclosure Framework - Changes to the Disclosure Requirements for Fair Value Measurements" (ASU 2018-13), which eliminates, adds and modifies certain disclosure requirements for fair value measurements, including eliminating the requirement to disclose the amount of and reasons for transfers between Level 1 and Level 2 of the fair value hierarchy, and requiring the range and weighted average used to develop significant unobservable inputs for Level 3 fair value measurements.  Some of these disclosure changes must be applied prospectively while others retrospectively depending on requirement. The Company adopted this standard effective April 1, 2020. The adoption of ASU 2018-13 did not have a material impact to the Company's condensed consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2020-10-22):
[0001032975-20-000048:note_history:9]
The Company had several uncommitted, unsecured bank lines of credit aggregating $84.2 million as of September 30, 2020. There are no financial covenants under these lines of credit with which the Company must comply. As of September 30, 2020, the Company had outstanding bank guarantees of $22.9 million under these lines of credit. There was no borrowing outstanding under these lines of credit as of September 30, 2020 or March 31, 2020.

- removed (2020-10-22):
[0001032975-20-000033:note_history:10]
The Company had several uncommitted, unsecured bank lines of credit aggregating $81.9 million as of June 30, 2020. There are no financial covenants under these lines of credit with which the Company must comply. As of June 30, 2020, the Company had outstanding bank guarantees of $28.5 million under these lines of credit. There was no borrowing outstanding under these lines of credit as of June 30, 2020 or March 31, 2020.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2020-10-22):
[0001032975-20-000048:note_history:11]
Subsequent Event

- added (2020-10-22):
[0001032975-20-000048:note_history:12]
During October 2020, Logitech issued or reserved 397,763 shares out of treasury shares to former security holders of Streamlabs related to the achievement of certain net sales milestones during the earn-out period of contingent consideration in connection with the business acquisition. The issuances of such shares were deemed to be exempt from registration under the Securities Act, in reliance on Regulation D of the Securities Act as transactions by an issuer not involving a public offering.
