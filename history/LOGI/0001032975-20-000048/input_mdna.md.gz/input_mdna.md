# LOGI MD&A — 0001032975-20-000048


## mdna

[0001032975-20-000048:mdna:1]
[same as prior period, unchanged from 0001032975-20-000033:mdna:1]

[0001032975-20-000048:mdna:2]
[same as prior period, unchanged from 0001032975-20-000033:mdna:2]

[0001032975-20-000048:mdna:3]
[same as prior period, unchanged from 0001032975-20-000033:mdna:3]

[0001032975-20-000048:mdna:4]
Logitech is a world leader in designing, manufacturing and marketing products that help connect people to digital and cloud experiences. More than 35 years ago, Logitech created products to improve experiences around the personal computer (PC) platform, and today it is a multi-brand, multi-category company designing products that enable better experiences when consuming, sharing and creating digital content such as computing, gaming, video and music, whether it is on a computer, mobile device or in the cloud. Logitech's brands include Logitech, Logitech G, ASTRO Gaming, Streamlabs, Ultimate Ears, Jaybird, and Blue Microphones. Our Company's website is www.logitech.com.

[0001032975-20-000048:mdna:5]
[same as prior period, unchanged from 0001032975-20-000033:mdna:6]

[0001032975-20-000048:mdna:6]
From time to time, we may seek to partner with or acquire, when appropriate, companies that have products, personnel, and technologies that complement our strategic direction. We continually review our product offerings and our strategic direction in light of our profitability targets, competitive conditions, changing consumer trends and the evolving nature of the interface between the consumer and the digital world.

[0001032975-20-000048:mdna:7]
[same as prior period, unchanged from 0001032975-20-000033:mdna:8]

[0001032975-20-000048:mdna:8]
In March 2020, the World Health Organization declared the outbreak of a novel coronavirus ("COVID-19") as a pandemic, which continues to spread throughout the world. The spread of COVID-19 has caused public health officials to recommend precautions to mitigate the spread of the virus and, in certain markets in which we operate, government authorities have issued orders that require the closure of non-essential businesses and people to be quarantined or to shelter-at-home. The COVID-19 pandemic has significantly curtailed global economic activity, caused significant volatility and disruption in global financial and commercial markets, and is likely to lead to recessionary pressures for an indeterminate amount of time. We are conducting our business with substantial modifications, such as employee remote work and travel limitations among other changes. We are continuing to actively monitor the situation and may take further actions that could alter our business operations as may be required by federal, state or local authorities in the countries in which we operate, or that we determine are in the best interest of our employees, customers, partners, suppliers or shareholders. It is not clear what the potential effects of COVID-19 or any such modifications or alterations may have on our business, results of operations, financial operations, financial condition and stock price.

[0001032975-20-000048:mdna:9]
During February 2020, following the initial outbreak of COVID-19 in China, we experienced disruptions to our manufacturing, supply chain and logistics services, resulting in temporary inventory declines and an increase in logistics costs. We continued to see disruptions to our supply chain and logistics services, inventory constraints and increased logistics costs during the remainder of the fourth quarter of fiscal year 2020 and the first and second quarters of fiscal year 2021 as we attempted to address the effects of COVID-19, including health-related issues, changing regulations, and increased demand for and depleted inventories of some of our products. At the same time, due to the ongoing shelter-at-home requirements or recommendations in many countries, there has been acceleration of the work-from-home, study-from-home, gaming, video collaboration and streaming trends and high demand and consumption of certain of our products that have led to increased sales and operating income. While it is not yet clear how long the positive demand dynamics will continue, we expect the increased logistics costs and other adverse effects on our gross margins from COVID-19 to continue through the remainder of fiscal year 2021. It is difficult to predict the progression, the duration and all of the effects of COVID-19, when business closure and shelter-at-home guidelines may be eased or lifted, and how consumer demand, inventory and logistical effects and costs may evolve over time, or the impact on our future sales and results of operations. Some of this impact will undoubtedly occur over multiple financial periods and may have a lag effect between periods, such as what we are able to manufacture in one period affecting sales, channel inventory or logistics costs in subsequent periods. The full extent of the impact of COVID-19 on our business and our operational and financial performance is currently uncertain and will depend on many factors outside our control. For additional information, see "Liquidity and Capital resources" below and "Item IA: Risk Factors", including under the caption "The full effect of the COVID-19 pandemic is uncertain and cannot be predicted, and the Company's business, results of operations and financial condition could be adversely affected by the COVID-19 pandemic."

[0001032975-20-000048:mdna:10]
[same as prior period, unchanged from 0001032975-20-000033:mdna:11]

[0001032975-20-000048:mdna:11]
Our total sales for the three and six months ended September 30, 2020 increased 75% and 50%, respectively, compared to the three and six months ended September 30, 2019, due to stronger sales across all regions and several of our product categories from increased remote work and distance learning trends, related to various shelter-at-home mandates, as well as gaming from home, as a result of COVID-19. The results of operations for Streamlabs have been included in our consolidated statement of operations from the acquisition date.

[0001032975-20-000048:mdna:12]
Our sales for the three months ended September 30, 2020 increased 83%, 68%, and 70% in the Americas, EMEA and Asia Pacific, respectively, compared to the same period of the prior fiscal year. Our sales for the six months ended September 30, 2020 increased 52%, 46%, and 52% in the Americas, EMEA and Asia Pacific, respectively, compared to the same period of the prior fiscal year.

[0001032975-20-000048:mdna:13]
26

[0001032975-20-000048:mdna:14]
Our gross margin for the three months ended September 30, 2020 increased by 750 basis points to 45.3% from 37.8% for the three months ended September 30, 2019. Our gross margin for the six months ended September 30, 2020 increased by 520 basis points to 42.7% from 37.5% for the six months ended September 30, 2019. Our gross margin for both periods benefited from higher sales volume, continued restrained promotional spending, and favorable product mix, which more than offset the higher logistics operations costs and unfavorable currency exchange rates.

[0001032975-20-000048:mdna:15]
Operating expenses for the three months ended September 30, 2020 were $248.2 million, or 19.7% of sales, compared to $204.0 million, or 28.3% of sales in the same period of the prior fiscal year.

[0001032975-20-000048:mdna:16]
Operating expenses for the six months ended September 30, 2020 were $470.5 million, or 23.0% of sales, compared to $395.5 million, or 29.0% of sales in the same period of the prior fiscal year.

[0001032975-20-000048:mdna:17]
Net income for the three and six months ended September 30, 2020 was $266.9 million and $339.0 million, respectively, compared to $72.9 million and $118.3 million for the three and six months ended September 30, 2019, respectively.

[0001032975-20-000048:mdna:18]
[same as prior period, unchanged from 0001032975-20-000033:mdna:17]

[0001032975-20-000048:mdna:19]
[same as prior period, unchanged from 0001032975-20-000033:mdna:18]

[0001032975-20-000048:mdna:20]
[same as prior period, unchanged from 0001032975-20-000033:mdna:19]

[0001032975-20-000048:mdna:21]
Creativity & Productivity:  New PC shipments have been strong recently due to work-from-home and study-from-home trends. We believe that innovative PC peripherals, such as our mice and keyboards, can renew the PC usage experience and help improve the productivity and engagement of remote work, distance learning, and telemedicine, thus providing growth opportunities. Increasing adoption of various cloud-based applications has led to multiple unique consumer use cases, which we are addressing with our innovative product portfolio and a deep understanding of our customer base. The increasing popularity of streaming and broadcasting, as well as the rising work-from-home trend, provides additional growth opportunities for our webcam products as well as other products in our portfolio. Smaller mobile computing devices, such as tablets, have created new markets and usage models for peripherals and accessories. We offer a number of products to enhance the use of mobile devices, including a combo backlit keyboard case for the iPad Pro and keyboard folios for other iPad models. Hybrid and distance learning environments have also created demand and growth opportunities for our education tablet keyboards and accessories.

[0001032975-20-000048:mdna:22]
Gaming:  The PC gaming and console gaming platforms continue to show strong structural growth opportunities as online gaming, multi-platform experiences, and esports gain greater popularity and gaming content becomes increasingly more demanding and social particularly as other recreational activities have been curtailed or restricted during shelter-at-home mandates. The new console refresh cycle during the holiday season of 2020 could drive subsequent growth opportunities over the coming years for our ASTRO family of headsets and controllers. We believe Logitech is well positioned to benefit from the overall gaming market growth. With ASTRO Gaming, we also strengthened our portfolio in adjacent categories, such as the console controller market. Our acquisition of Streamlabs provides a solid platform to deliver recurring services and subscriptions to gamers.

[0001032975-20-000048:mdna:23]
Video Collaboration: The near and long-term structural growth opportunities in the video collaboration market (VC) have never been more relevant than in today’s environment, as commercial and consumer adoption of video has seen explosive growth in recent months. Video meetings are on the rise, and companies increasingly want lower-cost, cloud-based solutions that can provide their employees with the ability to work from anywhere. We are continuing our efforts to create and sell innovative products to accommodate the increasing demand from home offices and small-size meeting rooms, such as huddle rooms, to medium and large-sized meeting rooms. We are also experiencing significant demand for our enterprise-grade VC webcams and headsets. We will continue to invest in select business-specific products (both hardware and software), targeted product marketing and sales channel development.

[0001032975-20-000048:mdna:24]
27

[0001032975-20-000048:mdna:25]
Music:  The mobile speaker market has remained soft, and has further weakened as physical retail stores have been recently closed and the retail footprint has decreased significantly due to the COVID-19 pandemic. The integration of personal voice assistants has become increasingly competitive in the speaker categories, but the market for third-party, voice-enabled speakers has not yet gained traction. Moreover, the market for mobile speakers appears to be maturing, which led to a decline in Ultimate Ears sales in the past two years. In fiscal year 2020, the wireless headphone industry continued to flourish with strong revenue growth but has slowed in recent months due to physical retail store closures. The largest growth was in true wireless headphones while traditional wireless headphones have declined significantly. Continued growth in the wireless headphone market is expected for the next several years as consumers increasingly adopt wireless headphones over wired headphones. Blue Microphones has experienced strong demand as musicians, performers and streamers increasingly look to entertain and engage with their fans on various online platforms like YouTube, Twitch, and Facebook.

[0001032975-20-000048:mdna:26]
Smart Home:  Our remote Harmony business declined substantially in fiscal year 2020, offset by growth in our Circle 2 family of security cameras. This trend continued during the first half of fiscal year 2021. In general, our Harmony and Circle 2 products are under pressure as the way people consume content is changing and as retail stores have been closed. The smart home market opportunity is broad and we will continue to explore other innovative experiences to drive growth in the Smart Home category.

[0001032975-20-000048:mdna:27]
[same as prior period, unchanged from 0001032975-20-000033:mdna:25]

[0001032975-20-000048:mdna:28]
We have historically experienced higher sales in our third fiscal quarter ending December 31, compared to other fiscal quarters in our fiscal year, primarily due to the increased consumer demand for our products during the year-end holiday buying season and year-end spending by enterprises. It is not clear to what extent the COVID-19 pandemic will affect this pattern. Additionally, new product introductions and business acquisitions can significantly impact sales, product costs and operating expenses. Product introductions can also impact our sales to distribution channels as these channels are filled with new product inventory following a product introduction, and often channel inventory of an earlier model product declines as the next related major product launch approaches. Sales can also be affected when consumers and distributors anticipate a product introduction or changes in business circumstances. However, neither historical seasonal patterns nor historical patterns of product introductions should be considered reliable indicators of our future pattern of product introductions, future sales or financial performance. Furthermore, cash flow is correspondingly lower in the first half of the fiscal year as we typically build inventories in advance for the third quarter and we pay an annual dividend following our Annual General Meeting, which is typically in September.

[0001032975-20-000048:mdna:29]
[same as prior period, unchanged from 0001032975-20-000033:mdna:27]

[0001032975-20-000048:mdna:30]
[same as prior period, unchanged from 0001032975-20-000033:mdna:28]

[0001032975-20-000048:mdna:31]
[same as prior period, unchanged from 0001032975-20-000033:mdna:29]

[0001032975-20-000048:mdna:32]
[same as prior period, unchanged from 0001032975-20-000033:mdna:30]

[0001032975-20-000048:mdna:33]
[same as prior period, unchanged from 0001032975-20-000033:mdna:31]

[0001032975-20-000048:mdna:34]
There have been no material changes in our critical accounting policies and estimates during the six months ended September 30, 2020 compared with the critical accounting policies and estimates disclosed in Management's Discussions and Analysis of Financial Condition and Results of Operations included in our Annual Report on Form 10-K for the fiscal year ended March 31, 2020.

[0001032975-20-000048:mdna:35]
[same as prior period, unchanged from 0001032975-20-000033:mdna:33]

[0001032975-20-000048:mdna:36]
[same as prior period, unchanged from 0001032975-20-000033:mdna:34]

[0001032975-20-000048:mdna:37]
[same as prior period, unchanged from 0001032975-20-000033:mdna:35]

[0001032975-20-000048:mdna:38]
[same as prior period, unchanged from 0001032975-20-000033:mdna:36]

[0001032975-20-000048:mdna:39]
[same as prior period, unchanged from 0001032975-20-000033:mdna:37]

[0001032975-20-000048:mdna:40]
[same as prior period, unchanged from 0001032975-20-000033:mdna:38]

[0001032975-20-000048:mdna:41]
[same as prior period, unchanged from 0001032975-20-000033:mdna:39]

[0001032975-20-000048:mdna:42]
[same as prior period, unchanged from 0001032975-20-000033:mdna:40]

[0001032975-20-000048:mdna:43]
Although our financial results are reported in U.S. Dollars, a portion of our sales was generated in currencies other than the U.S. Dollar, such as the Euro, Chinese Renminbi, Japanese Yen, Canadian Dollar, Taiwan New Dollar, British Pound and Australian Dollar. During the three months ended September 30, 2020, approximately 50% of our sales were denominated in currencies other than the U.S. Dollar.

[0001032975-20-000048:mdna:44]
[same as prior period, unchanged from 0001032975-20-000033:mdna:42]

[0001032975-20-000048:mdna:45]
[same as prior period, unchanged from 0001032975-20-000033:mdna:43]

[0001032975-20-000048:mdna:46]
Our sales in the three and six months ended September 30, 2020 increased 75% and 50%, respectively, compared to the same period of the prior fiscal year, driven by sales increases in all regions and several of our product categories from increased remote work and distance learning trends, as a result of various shelter-at-home mandates. Strong sales growth in Video Collaboration, Gaming, PC Webcams, Keyboards & Combos, Audio PC & Wearables, Tablet and Other Accessories, and Pointing Devices was partially offset by a decline in sales for Mobile Speakers and Smart Home. If currency exchange rates had been constant in the three and six months ended September 30, 2020 and 2019, our constant dollar sales growth rate would have been 73% and 51%, respectively.

[0001032975-20-000048:mdna:47]
[same as prior period, unchanged from 0001032975-20-000033:mdna:45]

[0001032975-20-000048:mdna:48]
The following table presents the change in sales by region for the three and six months ended September 30, 2020, compared with the three and six months ended September 30, 2019:

[0001032975-20-000048:mdna:49]
|  |  | Sales Growth Rate |  | Constant DollarSales Growth Rate |
|  |  | Three Months Ended September 30, 2020 |  | Six Months Ended September 30, 2020 |  | Three Months Ended September 30, 2020 | Six Months Ended September 30, 2020 |
| Americas |  | 83 | % |  | 52 | % |  | 85 | % | 54 | % |
| EMEA |  | 68 | % |  | 46 | % |  | 63 | % | 45 | % |
| Asia Pacific |  | 70 | % |  | 52 | % |  | 69 | % | 53 | % |

[0001032975-20-000048:mdna:50]
[same as prior period, unchanged from 0001032975-20-000033:mdna:48]

[0001032975-20-000048:mdna:51]
The increase in sales in our Americas region for both the three and six month periods was primarily driven by growth in sales across a majority of our product categories, partially offset by a decline in sales for Mobile Speakers and Smart Home.

[0001032975-20-000048:mdna:52]
[same as prior period, unchanged from 0001032975-20-000033:mdna:50]

[0001032975-20-000048:mdna:53]
The increase in sales in our EMEA region for both the three and six month periods was primarily driven by growth in sales across a majority of our product categories, partially offset by a decline in sales for Mobile Speakers and Smart Home.

[0001032975-20-000048:mdna:54]
[same as prior period, unchanged from 0001032975-20-000033:mdna:52]

[0001032975-20-000048:mdna:55]
The increase in sales in our Asia Pacific region for both the three and six month periods was driven by all product categories.

[0001032975-20-000048:mdna:56]
[same as prior period, unchanged from 0001032975-20-000033:mdna:54]

[0001032975-20-000048:mdna:57]
Sales by product categories for the three and six months ended September 30, 2020 and 2019 were as follows (Dollars in thousands):

[0001032975-20-000048:mdna:58]
|  |  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
|  |  | 2020 |  | 2019 |  | Change |  | 2020 |  | 2019 |  | Change |
| Pointing Devices |  | $ | 169,121 |  |  | $ | 132,770 |  |  | 27 | % |  | $ | 289,590 |  |  | $ | 254,753 |  |  | 14 | % |
| Keyboards & Combos |  | 201,617 |  |  | 139,049 |  |  | 45 |  |  | 346,977 |  |  | 267,728 |  |  | 30 |  |
| PC Webcams |  | 102,469 |  |  | 28,748 |  |  | 256 |  |  | 163,320 |  |  | 56,876 |  |  | 187 |  |
| Tablet & Other Accessories |  | 83,086 |  |  | 33,847 |  |  | 145 |  |  | 129,134 |  |  | 72,186 |  |  | 79 |  |
| Gaming |  | 297,711 |  |  | 161,014 |  |  | 85 |  |  | 479,614 |  |  | 295,529 |  |  | 62 |  |
| Video Collaboration |  | 236,704 |  |  | 89,553 |  |  | 164 |  |  | 366,778 |  |  | 162,977 |  |  | 125 |  |
| Mobile Speakers |  | 43,581 |  |  | 57,232 |  |  | (24 | ) |  | 72,590 |  |  | 107,648 |  |  | (33 | ) |
| Audio & Wearables |  | 114,275 |  |  | 68,018 |  |  | 68 |  |  | 185,640 |  |  | 126,642 |  |  | 47 |  |
| Smart Home |  | 8,573 |  |  | 9,434 |  |  | (9 | ) |  | 15,383 |  |  | 19,298 |  |  | (20 | ) |
| Other (1) |  | 21 |  |  | 26 |  |  | (19 | ) |  | 26 |  |  | 279 |  |  | (91 | ) |
| Total sales |  | $ | 1,257,158 |  |  | $ | 719,691 |  |  | 75 | % |  | $ | 2,049,052 |  |  | $ | 1,363,916 |  |  | 50 | % |

[0001032975-20-000048:mdna:59]
[same as prior period, unchanged from 0001032975-20-000033:mdna:57]

[0001032975-20-000048:mdna:60]
30

[0001032975-20-000048:mdna:61]
[same as prior period, unchanged from 0001032975-20-000033:mdna:58]

[0001032975-20-000048:mdna:62]
[same as prior period, unchanged from 0001032975-20-000033:mdna:59]

[0001032975-20-000048:mdna:63]
[same as prior period, unchanged from 0001032975-20-000033:mdna:60]

[0001032975-20-000048:mdna:64]
Sales of Pointing Devices increased 27% and 14% in the three and six months ended September 30, 2020, respectively, compared to the same period of the prior fiscal year.  The increases in both periods were primarily driven by the increase in sales for cordless and trackball mice, partially offset by a decline in sales of our presentation tools, as most conferences, events, and other large-scale presentations remained prohibited.

[0001032975-20-000048:mdna:65]
[same as prior period, unchanged from 0001032975-20-000033:mdna:62]

[0001032975-20-000048:mdna:66]
[same as prior period, unchanged from 0001032975-20-000033:mdna:63]

[0001032975-20-000048:mdna:67]
Sales of Keyboards & Combos increased 45% and 30% in the three and six months ended September 30, 2020, respectively, compared to the same periods of the prior fiscal year. The increases in both periods were driven by an increase in sales for our cordless keyboards and wireless keyboards/mice combos.  The increase for the six month period was partially offset by a decline in sales for our living room keyboards and corded keyboards/mice combos.

[0001032975-20-000048:mdna:68]
[same as prior period, unchanged from 0001032975-20-000033:mdna:66]

[0001032975-20-000048:mdna:69]
[same as prior period, unchanged from 0001032975-20-000033:mdna:67]

[0001032975-20-000048:mdna:70]
PC Webcams sales increased 256% and 187% in the three and six months ended September 30, 2020, respectively, compared to the same periods of the prior fiscal year. The increases for both periods were across all product sub-categories, primarily driven by an increase in sales of our HD Pro Webcam C920, 1080 PRO Stream Webcam, Webcam C60, and Logitech Streamcam, partly due to more remote work adoption and distance learning.

[0001032975-20-000048:mdna:71]
[same as prior period, unchanged from 0001032975-20-000033:mdna:69]

[0001032975-20-000048:mdna:72]
[same as prior period, unchanged from 0001032975-20-000033:mdna:70]

[0001032975-20-000048:mdna:73]
Sales of Tablet & Other Accessories products increased 145% and 79% in the three and six months ended September 30, 2020, respectively, compared to the same periods of the prior fiscal year. The increase for both periods was primarily driven by an increase in the sales of our Rugged Folio keyboard cases for a newer generation of iPads and Slim Folio keyboard for iPad 7th generation, both introduced in the third quarter of fiscal year 2020, and our Powered Wireless Charging 3-in-1 Dock, introduced in the fourth quarter of fiscal year 2020, partly due to schools embracing various technology devices to better educate students in distance learning environments.

[0001032975-20-000048:mdna:74]
[same as prior period, unchanged from 0001032975-20-000033:mdna:72]

[0001032975-20-000048:mdna:75]
[same as prior period, unchanged from 0001032975-20-000033:mdna:73]

[0001032975-20-000048:mdna:76]
Gaming sales increased 85% and 62% for the three and six months ended September 30, 2020, respectively, compared to the same periods of the prior fiscal year. The increase for both periods was primarily driven by increases in the sales of nearly all our product sub-categories, including Streamlabs services as a result of our business acquisition in the third quarter of fiscal year 2020.

[0001032975-20-000048:mdna:77]
[same as prior period, unchanged from 0001032975-20-000033:mdna:75]

[0001032975-20-000048:mdna:78]
Our Video Collaboration category primarily includes Logitech’s ConferenceCams, which combine affordable enterprise-quality audio and high definition (HD) 1080p video to bring video conferencing to businesses of any size.

[0001032975-20-000048:mdna:79]
Sales of Video Collaboration products increased 164% and 125% in the three and six months ended September 30, 2020, respectively, compared to the same periods of the prior fiscal year. The increases for both periods were primarily driven by the sales of our MeetUp video conferencing camera, Rally Ultra-HD conference camera system, and BRIO 4K Pro Webcam, from continued deployment of video in the office as some countries started reopening work locations and employees started returning to work.

[0001032975-20-000048:mdna:80]
[same as prior period, unchanged from 0001032975-20-000033:mdna:79]

[0001032975-20-000048:mdna:81]
[same as prior period, unchanged from 0001032975-20-000033:mdna:80]

[0001032975-20-000048:mdna:82]
[same as prior period, unchanged from 0001032975-20-000033:mdna:81]

[0001032975-20-000048:mdna:83]
Sales of Mobile Speakers decreased 24% and 33% for the three and six months ended September 30, 2020, compared to the same periods of the prior fiscal year. The decreases for both periods were primarily driven by a decrease in the sales of our UE MEGABOOM, BOOM 3, MEGABOOM 3 and UE WONDERBOOM mobile speakers. The decreases were partially offset by sales from the introduction of our HYPERBOOM speaker in the fourth quarter of fiscal year 2020.

[0001032975-20-000048:mdna:84]
[same as prior period, unchanged from 0001032975-20-000033:mdna:83]

[0001032975-20-000048:mdna:85]
[same as prior period, unchanged from 0001032975-20-000033:mdna:84]

[0001032975-20-000048:mdna:86]
Audio & Wearables sales increased 68% and 47% for the three and six months ended September 30, 2020, respectively, compared to the same periods of the prior fiscal year. The increases for both periods were primarily driven by increases in the sales of both our corded and cordless headsets and Blue Microphones products, partially offset by a decline in the sales of our Jaybird products.

[0001032975-20-000048:mdna:87]
[same as prior period, unchanged from 0001032975-20-000033:mdna:86]

[0001032975-20-000048:mdna:88]
[same as prior period, unchanged from 0001032975-20-000033:mdna:87]

[0001032975-20-000048:mdna:89]
Smart Home sales decreased 9% and 20% during the three and six months ended September 30, 2020, respectively, compared to the same periods of the prior fiscal year. The decrease for the three-month period was primarily due to the decline in sales of our home video products, partially offset by an increase in sales of our Harmony remotes.  The decrease for the six month period was primarily driven by an overall decline in sales of our Harmony remotes and our home video products.

[0001032975-20-000048:mdna:90]
[same as prior period, unchanged from 0001032975-20-000033:mdna:89]

[0001032975-20-000048:mdna:91]
Gross profit for the three and six months ended September 30, 2020 and 2019 was as follows (Dollars in thousands):

[0001032975-20-000048:mdna:92]
|  |  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
|  |  | 2020 |  | 2019 |  | Change |  | 2020 |  | 2019 |  | Change |
| Net sales |  | $ | 1,257,158 |  |  | $ | 719,691 |  |  | 75 | % |  | $ | 2,049,052 |  |  | $ | 1,363,916 |  |  | 50 | % |
| Gross profit |  | $ | 569,723 |  |  | $ | 272,076 |  |  | 109 |  |  | $ | 875,456 |  |  | $ | 511,052 |  |  | 71 |  |
| Gross margin |  | 45.3 | % |  | 37.8 | % |  |  |  | 42.7 | % |  | 37.5 | % |  |  |  |

[0001032975-20-000048:mdna:93]
[same as prior period, unchanged from 0001032975-20-000033:mdna:92]

[0001032975-20-000048:mdna:94]
Gross margin increased by 750 and 520 basis points for the three and six months ended September 30, 2020, respectively, compared to the same periods of the prior fiscal year. Gross margin benefited from higher sales volume, continued restrained promotional spending, and favorable product mix, which more than offset the higher logistics operations costs and unfavorable currency exchange rates.

[0001032975-20-000048:mdna:95]
[same as prior period, unchanged from 0001032975-20-000033:mdna:94]

[0001032975-20-000048:mdna:96]
Operating expenses for the three and six months ended September 30, 2020 and 2019 were as follows (Dollars in thousands):

[0001032975-20-000048:mdna:97]
|  |  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Marketing and selling |  | $ | 158,797 |  |  | $ | 134,155 |  |  | $ | 292,035 |  |  | $ | 257,188 |  |
| % of sales |  | 12.6 | % |  | 18.6 | % |  | 14.3 | % |  | 18.9 | % |
| Research and development |  | 53,379 |  |  | 41,964 |  |  | 103,104 |  |  | 84,207 |  |
| % of sales |  | 4.2 | % |  | 5.8 | % |  | 5.0 | % |  | 6.2 | % |
| General and administrative |  | 31,664 |  |  | 24,048 |  |  | 60,735 |  |  | 46,207 |  |
| % of sales |  | 2.5 | % |  | 3.3 | % |  | 3.0 | % |  | 3.4 | % |
| Amortization of intangible assets and acquisition-related costs |  | 4,331 |  |  | 4,218 |  |  | 8,940 |  |  | 7,814 |  |
| % of sales |  | 0.3 | % |  | 0.6 | % |  | 0.4 | % |  | 0.6 | % |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | — |  |  | 5,716 |  |  | — |  |
| % of sales |  | — | % |  | — | % |  | 0.3 | % |  | — | % |
| Restructuring charges (credits), net |  | (1 | ) |  | (364 | ) |  | (54 | ) |  | 114 |  |
| % of sales |  | — | % | (1) | — | % |  | — | % | (1) | — | % |
| Total operating expenses |  | $ | 248,170 |  |  | $ | 204,021 |  |  | $ | 470,476 |  |  | $ | 395,530 |  |
| % of sales |  | 19.7 | % |  | 28.3 | % |  | 23.0 | % |  | 29.0 | % |

[0001032975-20-000048:mdna:98]
[same as prior period, unchanged from 0001032975-20-000033:mdna:97]

[0001032975-20-000048:mdna:99]
[same as prior period, unchanged from 0001032975-20-000033:mdna:98]

[0001032975-20-000048:mdna:100]
[same as prior period, unchanged from 0001032975-20-000033:mdna:99]

[0001032975-20-000048:mdna:101]
During the three and six months ended September 30, 2020, marketing and selling expenses increased $24.6 million and $34.8 million, respectively, compared to the same periods of the prior fiscal year. The increases were primarily driven by higher personnel-related costs due to increased headcount, partly from the Streamlabs acquisition and increased performance-based variable compensation, partially offset by lower marketing-related expenses.

[0001032975-20-000048:mdna:102]
[same as prior period, unchanged from 0001032975-20-000033:mdna:101]

[0001032975-20-000048:mdna:103]
[same as prior period, unchanged from 0001032975-20-000033:mdna:102]

[0001032975-20-000048:mdna:104]
During the three and six months ended September 30, 2020, research and development expenses increased $11.4 million and $18.9 million, respectively, compared to the same periods of the prior fiscal year. The increases were primarily driven by higher personnel-related costs due to increased headcount.

[0001032975-20-000048:mdna:105]
[same as prior period, unchanged from 0001032975-20-000033:mdna:104]

[0001032975-20-000048:mdna:106]
[same as prior period, unchanged from 0001032975-20-000033:mdna:105]

[0001032975-20-000048:mdna:107]
During the three and six months ended September 30, 2020, general and administrative expenses increased $7.6 million and $14.5 million, respectively, compared to the same periods of the prior fiscal year. The increases were primarily driven by higher personnel-related costs and increased share-based compensation.

[0001032975-20-000048:mdna:108]
[same as prior period, unchanged from 0001032975-20-000033:mdna:108]

[0001032975-20-000048:mdna:109]
[same as prior period, unchanged from 0001032975-20-000033:mdna:109]

[0001032975-20-000048:mdna:110]
During the three and six months ended, September 30, 2020, amortization of intangible assets and acquisition-related costs increased $0.1 million and $1.1 million, respectively, compared to the same period of the prior fiscal year.  The increase for the six months ended September 30, 2020 was primarily driven by amortization of the intangible assets acquired through the Streamlabs acquisition in the third quarter of fiscal year 2020.

[0001032975-20-000048:mdna:111]
[same as prior period, unchanged from 0001032975-20-000033:mdna:111]

[0001032975-20-000048:mdna:112]
The change in fair value of contingent consideration was $5.7 million for the six months ended September 30, 2020, primarily due to growth in Streamlabs' net sales and the achievement of the net sales targets during the six-month earn-out period.

[0001032975-20-000048:mdna:113]
[same as prior period, unchanged from 0001032975-20-000033:mdna:113]

[0001032975-20-000048:mdna:114]
Other income (expense), net for the three and six months ended September 30, 2020 and 2019 was as follows (Dollars in thousands):

[0001032975-20-000048:mdna:115]
|  |  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Investment income related to a deferred compensation plan |  | $ | 1,779 |  |  | $ | 202 |  |  | $ | 3,335 |  |  | $ | 791 |  |
| Currency exchange gain (loss), net |  | 1,669 |  |  | (319 | ) |  | 1,726 |  |  | 499 |  |
| Loss on investments |  | (2,693 | ) |  | (274 | ) |  | (2,519 | ) |  | (63 | ) |
| Other |  | 394 |  |  | 281 |  |  | 636 |  |  | 524 |  |
| Total |  | $ | 1,149 |  |  | $ | (110 | ) |  | $ | 3,178 |  |  | $ | 1,751 |  |

[0001032975-20-000048:mdna:116]
[same as prior period, unchanged from 0001032975-20-000033:mdna:116]

[0001032975-20-000048:mdna:117]
Currency exchange gain (loss), net relates to balances denominated in currencies other than the functional currency in our subsidiaries, as well as to the sale of currencies, and to gains or losses recognized on currency exchange forward contracts. We do not speculate in currency positions, but we are alert to opportunities to maximize currency exchange gains and minimize currency exchange losses.

[0001032975-20-000048:mdna:118]
Loss on investments represents the unrealized loss from the fair value change on the available-for-sale securities and equity-method investments during the periods presented.

[0001032975-20-000048:mdna:119]
[same as prior period, unchanged from 0001032975-20-000033:mdna:118]

[0001032975-20-000048:mdna:120]
The provision for (benefit from) income taxes and effective tax rates for the three and six months ended September 30, 2020 and 2019 were as follows (Dollars in thousands):

[0001032975-20-000048:mdna:121]
|  |  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Provision for (benefit from) income taxes |  | $ | 56,301 |  |  | $ | (2,598 | ) |  | $ | 70,304 |  |  | $ | 3,938 |  |
| Effective income tax rate |  | 17.4 | % |  | (3.7 | )% |  | 17.2 | % |  | 3.2 | % |

[0001032975-20-000048:mdna:122]
The change in the effective income tax rate for the three months ended September 30, 2020, compared to the same period ended September 30, 2019 was primarily due to the mix of income and losses in the various tax jurisdictions in which we operate.  The Swiss income tax provision in the three months ended September 30, 2020 represents the income tax provision at the full statutory income tax rate of 13.63%.  In the same period ended September 30, 2019 when TRAF was yet to be enacted at the federal and cantonal levels, the transition income tax provision reflects the application of the longstanding tax ruling through December 31, 2019, including a retroactive adjustment made to the preceding three-month period ended June 30, 2019 when the transition income tax provision was quantified at the full statutory income tax rate of 13.63% because at the time the canton of Vaud permitted the application of the longstanding tax ruling only through March 31, 2019.  The retroactive adjustment resulted in a tax benefit of $5.9 million in the three months ended September 30, 2019.  In addition, there was a discrete tax benefit of $4.0 million from adjusting deferred tax assets and liabilities in Switzerland in the three months ended September 30, 2019.

[0001032975-20-000048:mdna:123]
The change in the effective income tax rate for the six months ended September 30, 2020, compared to the same period ended September 30, 2019 was primarily due to the mix of income and losses in the various tax jurisdictions in which we operate.  The Swiss income tax provision in the six months ended September 30, 2020 represents the income tax provision at the full statutory income tax rate of 13.63%. The income tax provision in the six months ended September 30, 2019 reflects the application of the longstanding tax ruling through December 31, 2019 as stated above.  In the six months ended September 30, 2019, there was a discrete tax benefit of $1.7 million from adjusting deferred tax assets and liabilities in Switzerland.  Furthermore, there were discrete tax benefits of $5.8 million and $1.5 million from the recognition of excess tax benefits in the United States and reversal of uncertain tax positions from the expiration of statutes of limitations, respectively, in the six-month period ended September 30, 2020, compared with $6.7 million and $1.8 million, respectively, in the six-month period ended September 30, 2019.

[0001032975-20-000048:mdna:124]
As of September 30, 2020 and March 31, 2020, the total amount of unrecognized tax benefits due to uncertain tax positions was $152.5 million and $140.8 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-20-000048:mdna:125]
[same as prior period, unchanged from 0001032975-20-000033:mdna:123]

[0001032975-20-000048:mdna:126]
[same as prior period, unchanged from 0001032975-20-000033:mdna:124]

[0001032975-20-000048:mdna:127]
As of September 30, 2020, we had cash and cash equivalents of $917.2 million, compared to $715.6 million as of March 31, 2020. As of September 30, 2020, 51% of the cash and cash equivalents were held in Switzerland, 21% were held in Germany, and 15% were held in Hong Kong and China. We do not expect to incur any material adverse tax impact except for what has already been recognized, or be significantly inhibited by any country in which we do business from the repatriation of funds to Switzerland, our home domicile.

[0001032975-20-000048:mdna:128]
The increase in cash and cash equivalents for the six months ended September 30, 2020, was primarily due to an increase in net cash provided by operating activities and proceeds from exercises of stock options and purchase rights, partially offset by payment of cash dividends, purchases of property, plant and equipment, tax withholdings related to settlements of restricted stock units, and shares repurchased under our share buyback program.

[0001032975-20-000048:mdna:129]
As of September 30, 2020, our working capital was $952.6 million, compared to $700.3 million as of March 31, 2020. The increase was primarily driven by higher cash and cash equivalents, higher accounts receivable, net, higher inventories and higher other current assets, partially offset by higher accounts payable and accrued and other current liabilities. Our working capital increased by $330.2 million compared to $622.4 million as of September 30, 2019, which

[0001032975-20-000048:mdna:130]
was primarily driven by higher cash and cash equivalents, higher accounts receivable, net, higher inventories  and higher other current assets, partially offset by higher accounts payable and accrued and other current liabilities.

[0001032975-20-000048:mdna:131]
We had several uncommitted, unsecured bank lines of credit aggregating $84.2 million as of September 30, 2020. There are no financial covenants under these lines of credit with which we must comply. As of September 30, 2020, we had outstanding bank guarantees of $22.9 million under these lines of credit.

[0001032975-20-000048:mdna:132]
[same as prior period, unchanged from 0001032975-20-000033:mdna:129]

[0001032975-20-000048:mdna:133]
|  |  | Six Months EndedSeptember 30, |
|  |  | 2020 |  | 2019 |
| Net cash provided by operating activities |  | $ | 398,519 |  |  | $ | 143,019 |  |
| Net cash used in investing activities |  | (30,539 | ) |  | (18,582 | ) |
| Net cash used in financing activities |  | (168,837 | ) |  | (150,884 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  | 2,512 |  |  | (3,605 | ) |
| Net increase (decrease) in cash and cash equivalents |  | $ | 201,655 |  |  | $ | (30,052 | ) |

[0001032975-20-000048:mdna:134]
The following table presents selected financial information and statistics as of and for the three months ended September 30, 2020 and 2019 (Dollars in thousands):

[0001032975-20-000048:mdna:135]
|  |  | As of September 30, |
|  |  | 2020 |  | 2019 |
| Accounts receivable, net |  | $ | 750,749 |  |  | $ | 465,969 |  |
| Accounts payable |  | $ | 662,873 |  |  | $ | 411,043 |  |
| Inventories |  | $ | 394,708 |  |  | $ | 338,314 |  |

[0001032975-20-000048:mdna:136]
|  |  | Three Months EndedSeptember 30, |
|  |  | 2020 |  | 2019 |
| Days sales in accounts receivable (“DSO”) (Days) (1) |  | 54 |  |  | 58 |  |
| Days accounts payable outstanding (“DPO”) (Days) (2) |  | 87 |  |  | 83 |  |
| Inventory turnover (“ITO”) (x)(3) |  | 7.0 |  |  | 5.3 |  |

[0001032975-20-000048:mdna:137]
[same as prior period, unchanged from 0001032975-20-000033:mdna:135]

[0001032975-20-000048:mdna:138]
[same as prior period, unchanged from 0001032975-20-000033:mdna:136]

[0001032975-20-000048:mdna:139]
[same as prior period, unchanged from 0001032975-20-000033:mdna:137]

[0001032975-20-000048:mdna:140]
DSO for the three months ended September 30, 2020 decreased by 4 days to 54 days, compared to 58 days for the same period of the prior fiscal year, primarily due to timing of sales, customer payments and sales linearity.

[0001032975-20-000048:mdna:141]
DPO for the three months ended September 30, 2020 increased by 4 days, compared to 83 days for the same period of the prior fiscal year, primarily due to the timing of purchases and related payments.

[0001032975-20-000048:mdna:142]
ITO for the three months ended September 30, 2020 increased by 1.7, compared to 5.3 for the same period of the prior fiscal year, primarily due to higher sales growth as a result of higher demand for certain of our products

[0001032975-20-000048:mdna:143]
due to the COVID-19 impact.

[0001032975-20-000048:mdna:144]
[same as prior period, unchanged from 0001032975-20-000033:mdna:141]

[0001032975-20-000048:mdna:145]
During the six months ended September 30, 2020, we generated $398.5 million of cash from operating activities. Our main sources of operating cash flows were from net income, after adding back non-cash expenses of depreciation, amortization and share-based compensation expense, from change in fair value of contingent considerations, and from changes in operating assets and liabilities. The increase in accounts receivable, net was primarily driven by growth and timing of sales. The increase in inventories was primarily driven by an increase in inventory purchases, in anticipation of continued high demand for certain of our products, during the six months ended September 30, 2020. The increase in accounts payable was primarily driven by the timing of purchases and related payments.

[0001032975-20-000048:mdna:146]
Net cash used in investing activities was $30.5 million, primarily due to $27.8 million of purchases of property, plant and equipment.

[0001032975-20-000048:mdna:147]
Net cash used in financing activities was $168.8 million, primarily due to the $146.7 million payment of a cash dividend, $22.5 million used for repurchases of our registered shares, and $25.7 million for tax withholdings related to net share settlements of restricted stock units, partially offset by $26.1 million in proceeds received from exercises of stock options and purchase rights.

[0001032975-20-000048:mdna:148]
During the six months ended September 30, 2020, there was a $2.5 million gain from currency exchange rate effect on cash and cash equivalents, compared to a loss of $3.6 million during the same period of the prior fiscal year. The gain from currency translation exchange effect during the six months ended September 30, 2020 was primarily due to the strengthening of the Australian Dollar, Chinese Renminbi, and Japanese Yen against the U.S. Dollar by 15%, 4%, and 3%, respectively, during the period. The loss from effect of currency exchange rate changes during the six months ended September 30, 2019 was primarily due to the weakening of the Euro, Chinese Renminbi and Brazilian Real against the U.S.Dollar by 3%, 5%, and 7%, respectively.

[0001032975-20-000048:mdna:149]
[same as prior period, unchanged from 0001032975-20-000033:mdna:146]

[0001032975-20-000048:mdna:150]
[same as prior period, unchanged from 0001032975-20-000033:mdna:147]

[0001032975-20-000048:mdna:151]
In fiscal year 2021, we paid an annual cash dividend of CHF 134.0 million (U.S. Dollar amount of $146.7 million) out of fiscal year 2020 retained earnings. In fiscal year 2020, we paid an annual cash dividend of CHF 121.8 million (U.S. Dollar amount of $124.2 million) out of fiscal year 2019 retained earnings. Any future dividends will be subject to the approval of our shareholders.

[0001032975-20-000048:mdna:152]
In May 2020, our Board of Directors approved a new share buyback program, which authorizes us to invest up to $250.0 million to purchase our own shares, following the expiration date of the 2017 share buyback program. Although we enter into trading plans for systematic repurchases (e.g., 10b5-1 trading plans) from time to time, our share buyback program provides us with the opportunity to make opportunistic repurchases during periods of favorable market conditions and is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Opportunistic purchases may be started or stopped at any time without prior notice depending on market conditions and other factors. As of September 30, 2020, $227.6 million is still available for repurchase under the 2020 share buyback program.

[0001032975-20-000048:mdna:153]
[same as prior period, unchanged from 0001032975-20-000033:mdna:151]

[0001032975-20-000048:mdna:154]
[same as prior period, unchanged from 0001032975-20-000033:mdna:152]

[0001032975-20-000048:mdna:155]
[same as prior period, unchanged from 0001032975-20-000033:mdna:153]

[0001032975-20-000048:mdna:156]
[same as prior period, unchanged from 0001032975-20-000033:mdna:154]

[0001032975-20-000048:mdna:157]
As of September 30, 2020, we had non-cancelable purchase commitments of $628.6 million for inventory purchases made in the normal course of business from original design manufacturers, contract manufacturers and other suppliers, as well as due to strong sales growth in the six months ended September 30, 2020 and the reduced level of our customers’ inventories, the majority of which are expected to be fulfilled within the next 12 months. The increase of inventory purchase commitment from March 31, 2020 is to replenish the inventory due to business growth as well as a mitigation of supply constraint in the fourth quarter of fiscal year 2020. Non-cancelable purchase commitments for capital expenditures primarily relate to commitments for tooling for new and existing products, computer hardware, leasehold and improvements. We expect to continue making capital expenditures in the future to support product development activities and ongoing and expanded operations. Although open purchase commitments are considered enforceable and legally binding, the terms generally allow us to reschedule or adjust our requirements based on business needs prior to delivery of goods or performance of services.

[0001032975-20-000048:mdna:158]
We recorded a liability for firm, non-cancelable, and unhedged inventory purchase commitments in excess of anticipated demand or net realizable value consistent with our valuation of excess and obsolete inventory. As of September 30, 2020, the liability for these purchase commitments was $8.4 million and is recorded in accrued and other current liabilities. Although open purchase commitments are considered enforceable and legally binding, the terms generally allow us the option to reschedule and adjust our requirements based on business needs prior to delivery of goods.

[0001032975-20-000048:mdna:159]
[same as prior period, unchanged from 0001032975-20-000033:mdna:158]

[0001032975-20-000048:mdna:160]
[same as prior period, unchanged from 0001032975-20-000033:mdna:159]

[0001032975-20-000048:mdna:161]
[same as prior period, unchanged from 0001032975-20-000033:mdna:160]

[0001032975-20-000048:mdna:162]
[same as prior period, unchanged from 0001032975-20-000033:mdna:161]

[0001032975-20-000048:mdna:163]
[same as prior period, unchanged from 0001032975-20-000033:mdna:162]

[0001032975-20-000048:mdna:164]
We indemnify certain suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of September 30, 2020, no amounts have been accrued for indemnification provisions. We do not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under our indemnification arrangements.

[0001032975-20-000048:mdna:165]
[same as prior period, unchanged from 0001032975-20-000033:mdna:164]

[0001032975-20-000048:mdna:166]
Legal Proceedings

[0001032975-20-000048:mdna:167]
From time to time we are involved in claims and legal proceedings that arise in the ordinary course of our business. We are currently subject to several such claims and a small number of legal proceedings. We believe that these matters lack merit and we intend to vigorously defend against them. Based on currently available information, we do not believe that resolution of pending matters will have a material adverse effect on our financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that our defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on our business, financial condition, cash flows and results of operations in a particular period. Any claims or proceedings against us, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain necessary licenses or other rights, or litigation arising out of intellectual property claims, could adversely affect our business.
