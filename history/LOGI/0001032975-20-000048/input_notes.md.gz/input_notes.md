# LOGI notes — 0001032975-20-000048


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001032975-20-000048:notes:1]
[same as prior period, unchanged from 0001032975-20-000033:notes:1]

[0001032975-20-000048:notes:2]
[same as prior period, unchanged from 0001032975-20-000033:notes:2]

[0001032975-20-000048:notes:3]
[same as prior period, unchanged from 0001032975-20-000033:notes:3]

[0001032975-20-000048:notes:4]
[same as prior period, unchanged from 0001032975-20-000033:notes:4]

[0001032975-20-000048:notes:5]
[same as prior period, unchanged from 0001032975-20-000033:notes:5]

[0001032975-20-000048:notes:6]
[same as prior period, unchanged from 0001032975-20-000033:notes:6]

[0001032975-20-000048:notes:7]
[same as prior period, unchanged from 0001032975-20-000033:notes:7]

[0001032975-20-000048:notes:8]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and six months ended September 30, 2020 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2021, or any future periods.

[0001032975-20-000048:notes:9]
[same as prior period, unchanged from 0001032975-20-000033:notes:9]

[0001032975-20-000048:notes:10]
Other than the recent accounting pronouncements adopted and discussed below under Recent Accounting Pronouncements Adopted and Summary of Significant Accounting Policies, there have been no material changes in the Company’s significant accounting policies during the six months ended September 30, 2020 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2020.

[0001032975-20-000048:notes:11]
[same as prior period, unchanged from 0001032975-20-000033:notes:11]

[0001032975-20-000048:notes:12]
[same as prior period, unchanged from 0001032975-20-000033:notes:12]

[0001032975-20-000048:notes:13]
[same as prior period, unchanged from 0001032975-20-000033:notes:13]

[0001032975-20-000048:notes:14]
We are subject to risks and uncertainties as a result of the novel coronavirus (COVID-19). The measures taken by many countries in response have contributed to a general slowdown in the global economy and adversely affected, and could in the future continue to adversely affect, the Company's business and operations. Capital markets and economies worldwide have also been negatively impacted by COVID-19 and it is still unclear how lasting and deep the economic impacts will be. During the three and six months ended September 30, 2020, as well as in the fourth quarter of fiscal year 2020, the COVID-19 pandemic had mixed effects on the Company’s results of operations, and it may continue to have mixed or adverse effects. While there was high demand and consumption of certain of our products that led to increased sales and operating income during the fourth quarter of fiscal year 2020 and the three and six months ended September 30, 2020, at the same time the Company experienced disruptions to supply chain and logistics services, inventory constraints and increased logistics costs. The ongoing and full extent of the impact of the COVID-19 pandemic on the Company's business and operational and financial performance and condition, including the sustainability of its effect on trends positive to the Company, is uncertain and will depend on many factors outside the Company's control, including but not limited to the timing, extent, duration and effects of the virus and any of its mutations, the development and availability of effective treatments and vaccines, the imposition of effective public safety and other protective measures, the impact of COVID-19 on the global economy and demand for the Company's products and services. Should the COVID-19 pandemic or global economic slowdown not improve or worsen, or if the Company's attempt to mitigate its impact on its operations and costs is not successful, the Company's business, results of operations, financial condition and prospects may be adversely affected.

[0001032975-20-000048:notes:15]
[same as prior period, unchanged from 0001032975-20-000033:notes:15]

[0001032975-20-000048:notes:16]
In June 2016, the FASB issued ASU 2016-13, "Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments" (ASU 2016-13), which was further updated and clarified by the FASB through issuance of additional related ASUs, replaces the incurred-loss impairment methodology and requires immediate recognition of estimated credit losses expected to occur for most financial assets, including trade receivables. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. The Company adopted this standard effective April 1, 2020, using a modified retrospective approach. Upon adoption, the Company updated its credit loss models to utilize a forward-looking current expected credit losses (CECL) model in place of the incurred loss methodology for financial instruments measured at amortized cost, including accounts receivable. The cumulative effect adjustment from adoption was not material to the Company's condensed consolidated financial statements.

[0001032975-20-000048:notes:17]
In August 2018, the FASB issued ASU 2018-13, "Fair Value Measurement (Topic 820): Disclosure Framework - Changes to the Disclosure Requirements for Fair Value Measurements" (ASU 2018-13), which eliminates, adds and modifies certain disclosure requirements for fair value measurements, including eliminating the requirement to disclose the amount of and reasons for transfers between Level 1 and Level 2 of the fair value hierarchy, and requiring the range and weighted average used to develop significant unobservable inputs for Level 3 fair value measurements.  Some of these disclosure changes must be applied prospectively while others retrospectively depending on requirement. The Company adopted this standard effective April 1, 2020. The adoption of ASU 2018-13 did not have a material impact on the Company's condensed consolidated financial statements.

[0001032975-20-000048:notes:18]
In August 2018, the FASB issued ASU 2018-14, "Compensation - Retirement Benefits - Defined Benefits Plans - General (Subtopic 715-20): Disclosure Framework - Changes to the Disclosure Requirements for Defined Benefit Plans" (ASU 2018-14), which requires that the Company remove various disclosures that no longer are considered cost-beneficial, namely amounts in accumulated other comprehensive income expected to be recognized as components of net periodic benefit cost over the next fiscal year.  Further, ASU 2018-14 requires disclosure or clarification of the reasons for significant gains or losses related to changes in the benefit obligation for the period.  The Company adopted this standard effective April 1, 2020 using a retrospective approach and the updated disclosures will be included in the Company's Form 10-K for the fiscal year ending March 31, 2021. The adoption of ASU 2018-14 did not have an impact on the Company's condensed consolidated financial statements.

[0001032975-20-000048:notes:19]
[same as prior period, unchanged from 0001032975-20-000033:notes:19]

[0001032975-20-000048:notes:20]
In December 2019, the FASB issued ASU 2019-12, "Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes" (ASU 2019-12), which eliminates certain exceptions for recognizing deferred taxes for investments, performing intraperiod allocation and calculating income taxes in interim periods. This ASU also includes guidance to reduce complexity in certain areas, including recognizing deferred taxes for tax goodwill and allocating taxes to members of a consolidated group. ASU 2019-12 is effective for annual and interim periods in fiscal years beginning after December 15, 2020. Early adoption is permitted. The Company is currently assessing the impact of ASU 2019-12 on its consolidated financial statements and plans to adopt the standard effective April 1, 2021.


## us-gaap:EarningsPerShareTextBlock

[0001032975-20-000048:notes:21]
[same as prior period, unchanged from 0001032975-20-000033:notes:21]

[0001032975-20-000048:notes:22]
The following table summarizes the computations of basic and diluted net income per share for the three and six months ended September 30, 2020 and September 30, 2019 (in thousands, except per share amounts):

[0001032975-20-000048:notes:23]
|  |  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Net income |  | $ | 266,914 |  |  | $ | 72,933 |  |  | $ | 338,987 |  |  | $ | 118,278 |  |
| Shares used in net income per share computation: |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding - basic |  | 168,645 |  |  | 166,662 |  |  | 168,140 |  |  | 166,484 |  |
| Effect of potentially dilutive equivalent shares |  | 2,737 |  |  | 2,365 |  |  | 2,626 |  |  | 2,430 |  |
| Weighted average shares outstanding - diluted |  | 171,382 |  |  | 169,027 |  |  | 170,766 |  |  | 168,914 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.58 |  |  | $ | 0.44 |  |  | $ | 2.02 |  |  | $ | 0.71 |  |
| Diluted |  | $ | 1.56 |  |  | $ | 0.43 |  |  | $ | 1.99 |  |  | $ | 0.70 |  |

[0001032975-20-000048:notes:24]
Share equivalents attributable to outstanding stock options, restricted stock units ("RSUs") and employee share purchase plan ("ESPP") rights totaling 0.4 million and 1.9 million for the three months ended September 30, 2020 and 2019, respectively, and 0.4 million and 2.0 million for the six months ended September 30, 2020 and 2019, respectively, were excluded from the calculation of diluted net income per share because the combined exercise price and average unamortized grant date fair value upon exercise of these options and ESPP rights or vesting of RSUs were greater than the average market price of the Company's shares during the periods presented herein, and therefore their inclusion would have been anti-dilutive. The majority of performance-based awards were not included because all necessary conditions have not been satisfied by the end of the respective period, and those shares were not issuable if the end of the reporting period were the end of the performance contingency period.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001032975-20-000048:notes:25]
[same as prior period, unchanged from 0001032975-20-000033:notes:25]

[0001032975-20-000048:notes:26]
[same as prior period, unchanged from 0001032975-20-000033:notes:26]

[0001032975-20-000048:notes:27]
As of September 30, 2020, the Company offers the 2006 Employee Share Purchase Plan, as amended and restated (Non-U.S.) (2006 ESPP), the 1996 Employee Share Purchase Plan (U.S.), as amended and restated (1996 ESPP), the 2006 Stock Incentive Plan, as amended and restated (2006 Plan), and the 2012 Stock Inducement Equity Plan (2012 Plan).

[0001032975-20-000048:notes:28]
The following table summarizes the share-based compensation expense and total income tax benefit recognized for share-based awards for the three and six months ended September 30, 2020 and 2019 (in thousands):

[0001032975-20-000048:notes:29]
|  |  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Cost of goods sold |  | $ | 1,772 |  |  | $ | 1,184 |  |  | $ | 3,172 |  |  | $ | 2,342 |  |
| Marketing and selling |  | 10,377 |  |  | 6,951 |  |  | 19,169 |  |  | 13,800 |  |
| Research and development |  | 3,763 |  |  | 2,248 |  |  | 6,866 |  |  | 4,402 |  |
| General and administrative |  | 8,873 |  |  | 3,869 |  |  | 15,693 |  |  | 5,926 |  |
| Total share-based compensation expense |  | 24,785 |  |  | 14,252 |  |  | 44,900 |  |  | 26,470 |  |
| Income tax benefit |  | (3,958 | ) |  | (2,723 | ) |  | (12,069 | ) |  | (9,523 | ) |
| Total share-based compensation expense, net of income tax benefit |  | $ | 20,827 |  |  | $ | 11,529 |  |  | $ | 32,831 |  |  | $ | 16,947 |  |

[0001032975-20-000048:notes:30]
[same as prior period, unchanged from 0001032975-20-000033:notes:30]

[0001032975-20-000048:notes:31]
As of September 30, 2020 and 2019, the balance of capitalized share-based compensation included in inventory was $1.3 million and $0.9 million, respectively.

[0001032975-20-000048:notes:32]
[same as prior period, unchanged from 0001032975-20-000033:notes:32]

[0001032975-20-000048:notes:33]
Certain of the Company’s subsidiaries sponsor defined benefit pension plans or non-retirement post-employment benefits covering substantially all of their employees. Benefits are provided based on employees’ years of service and earnings, or in accordance with applicable employee benefit regulations. The Company’s practice is to fund amounts sufficient to meet the requirements set forth in the applicable employee benefit and tax regulations. The costs recorded of $2.7 million and $2.4 million for the three months ended September 30, 2020 and 2019, respectively, and $5.4 million and $4.8 million for the six months ended September 30, 2020 and 2019, respectively, were primarily related to service costs.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001032975-20-000048:notes:34]
[same as prior period, unchanged from 0001032975-20-000033:notes:34]

[0001032975-20-000048:notes:35]
[same as prior period, unchanged from 0001032975-20-000033:notes:35]

[0001032975-20-000048:notes:36]
The canton of Vaud enacted the Federal Act on Tax Reform and AHV Financing ("TRAF"), a major reform to better align the Swiss tax system with international tax standards, on March 10, 2020 to take effect as of January 1, 2020.  The longstanding tax ruling from the canton of Vaud was applicable through December 31, 2019.

[0001032975-20-000048:notes:37]
The income tax provision for the three months ended September 30, 2020 was $56.3 million based on an effective income tax rate of 17.4% of pre-tax income, compared to an income tax benefit of $2.6 million based on an effective income tax rate of (3.7)% of pre-tax income for the three months ended September 30, 2019.  The income tax provision for the six months ended September 30, 2020 was $70.3 million based on an effective income tax rate of 17.2% of pre-tax income, compared to an income tax provision of $3.9 million based on an effective income tax rate of 3.2% of pre-tax income for the six months ended September 30, 2019.

[0001032975-20-000048:notes:38]
The change in the effective income tax rate for the three months ended September 30, 2020, compared to the same period ended September 30, 2019 was primarily due to the mix of income and losses in the various tax jurisdictions in which the Company operates. The Swiss income tax provision in the three months ended September 30, 2020 represents the income tax provision at the full statutory income tax rate of 13.63%.  In the same period ended September 30, 2019 when TRAF was yet to be enacted at the federal and cantonal levels, the transition income tax provision reflects the application of the longstanding tax ruling through December 31, 2019 including a retroactive adjustment made to the preceding three-month period ended June 30, 2019 when the transition income tax provision was quantified at the full statutory income tax rate of 13.63% because at the time the canton of Vaud permitted the application of the longstanding tax ruling only through March 31, 2019.  The retroactive adjustment resulted in a tax benefit of $5.9 million in the three months ended September 30, 2019.  In addition, there was a discrete tax benefit of $4.0 million from adjusting deferred tax assets and liabilities in Switzerland in the three months ended September 30, 2019.

[0001032975-20-000048:notes:39]
The change in the effective income tax rate for the six months ended September 30, 2020, compared to the same period ended September 30, 2019 was primarily due to the mix of income and losses in the various tax jurisdictions in which the Company operates. The Swiss income tax provision in the six months ended September 30, 2020 represents the income tax provision at the full statutory income tax rate of 13.63%.  The income tax provision in the six months ended September 30, 2019 reflects the application of the longstanding tax ruling through December 31, 2019 as stated above.  In the six months ended September 30, 2019, there was a discrete tax benefit of $1.7 million from adjusting deferred tax assets and liabilities in Switzerland.  Furthermore, there were discrete tax benefits of $5.8 million and $1.5 million from the recognition of excess tax benefits in the United States and reversal of uncertain tax positions from the expiration of statutes of limitations, respectively, in the six-month period ended September 30, 2020, compared with $6.7 million and $1.8 million, respectively, in the six-month period ended September 30, 2019.

[0001032975-20-000048:notes:40]
As of September 30, 2020 and March 31, 2020, the total amount of unrecognized tax benefits due to uncertain tax positions was $152.5 million and $140.8 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-20-000048:notes:41]
As of September 30, 2020 and March 31, 2020, the Company had $54.5 million and $40.8 million, respectively, in non-current income taxes payable including interest and penalties, related to the Company's income tax liability for uncertain tax positions.

[0001032975-20-000048:notes:42]
The Company recognizes interest and penalties related to unrecognized tax positions in the income tax provision. As of September 30, 2020 and March 31, 2020, the Company had $4.8 million and $4.5 million, respectively, of accrued interest and penalties related to uncertain tax positions in non-current income taxes payable.

[0001032975-20-000048:notes:43]
[same as prior period, unchanged from 0001032975-20-000033:notes:42]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001032975-20-000048:notes:44]
[same as prior period, unchanged from 0001032975-20-000033:notes:43]

[0001032975-20-000048:notes:45]
The following table presents the components of certain balance sheet asset amounts as of September 30 and March 31, 2020 (in thousands):

[0001032975-20-000048:notes:46]
|  |  | September 30, 2020 |  | March 31, 2020 |
| Accounts receivable, net: |  |  |  |  |  |  |
| Accounts receivable |  | $ | 973,523 |  |  | $ | 597,939 |  |
| Allowance for doubtful accounts |  | (1,358 | ) |  | (1,894 | ) |
| Allowance for sales returns |  | (10,487 | ) |  | (6,599 | ) |
| Allowance for cooperative marketing arrangements |  | (40,396 | ) |  | (38,794 | ) |
| Allowance for customer incentive programs |  | (63,051 | ) |  | (55,741 | ) |
| Allowance for pricing programs |  | (107,482 | ) |  | (100,168 | ) |
|  |  | $ | 750,749 |  |  | $ | 394,743 |  |
| Inventories: |  |  |  |  |  |  |
| Raw materials |  | $ | 60,606 |  |  | $ | 56,052 |  |
| Finished goods |  | 334,102 |  |  | 173,197 |  |
|  |  | $ | 394,708 |  |  | $ | 229,249 |  |
| Other current assets: |  |  |  |  |  |  |
| Value-added tax receivables |  | $ | 41,862 |  |  | $ | 33,616 |  |
| Prepaid expenses and other assets |  | 52,891 |  |  | 41,304 |  |
|  |  | $ | 94,753 |  |  | $ | 74,920 |  |
| Property, plant and equipment, net: |  |  |  |  |  |  |
| Property, plant and equipment at cost |  | $ | 378,392 |  |  | $ | 346,506 |  |
| Accumulated depreciation and amortization |  | (292,006 | ) |  | (270,387 | ) |
|  |  | $ | 86,386 |  |  | $ | 76,119 |  |
| Other assets: |  |  |  |  |  |  |
| Deferred tax assets |  | $ | 222,763 |  |  | $ | 240,528 |  |
| Right-of-use assets |  | 31,386 |  |  | 25,557 |  |
| Trading investments for deferred compensation plan |  | 24,559 |  |  | 20,085 |  |
| Investments in privately held companies |  | 46,942 |  |  | 45,949 |  |
| Other assets |  | 13,747 |  |  | 12,900 |  |
|  |  | $ | 339,397 |  |  | $ | 345,019 |  |

[0001032975-20-000048:notes:47]
The following table presents the components of certain balance sheet liability amounts as of September 30 and March 31, 2020 (in thousands):

[0001032975-20-000048:notes:48]
|  |  | September 30, 2020 |  | March 31, 2020 |
| Accrued and other current liabilities: |  |  |  |  |  |  |
| Accrued personnel expenses |  | $ | 105,159 |  |  | $ | 104,423 |  |
| Accrued sales return liability |  | 28,990 |  |  | 30,267 |  |
| Accrued customer marketing, pricing and incentive programs |  | 143,597 |  |  | 130,220 |  |
| Operating lease liability |  | 12,868 |  |  | 10,945 |  |
| Accrued freight and duty |  | 27,954 |  |  | 13,284 |  |
| Warranty accrual |  | 27,303 |  |  | 25,905 |  |
| Income taxes payable |  | 40,884 |  |  | 8,823 |  |
| Contingent consideration |  | 29,000 |  |  | 23,284 |  |
| Other current liabilities |  | 126,222 |  |  | 107,873 |  |
|  |  | $ | 541,977 |  |  | $ | 455,024 |  |
| Other non-current liabilities: |  |  |  |  |  |  |
| Warranty accrual |  | $ | 14,479 |  |  | $ | 14,134 |  |
| Obligation for deferred compensation plan |  | 24,559 |  |  | 20,085 |  |
| Employee benefit plan obligations |  | 63,837 |  |  | 61,303 |  |
| Operating lease liability |  | 23,017 |  |  | 19,536 |  |
| Deferred tax liability |  | 1,931 |  |  | 1,931 |  |
| Other non-current liabilities |  | 2,726 |  |  | 2,285 |  |
|  |  | $ | 130,549 |  |  | $ | 119,274 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001032975-20-000048:notes:49]
[same as prior period, unchanged from 0001032975-20-000033:notes:48]

[0001032975-20-000048:notes:50]
[same as prior period, unchanged from 0001032975-20-000033:notes:49]

[0001032975-20-000048:notes:51]
[same as prior period, unchanged from 0001032975-20-000033:notes:50]

[0001032975-20-000048:notes:52]
[same as prior period, unchanged from 0001032975-20-000033:notes:51]

[0001032975-20-000048:notes:53]
[same as prior period, unchanged from 0001032975-20-000033:notes:52]

[0001032975-20-000048:notes:54]
[same as prior period, unchanged from 0001032975-20-000033:notes:53]

[0001032975-20-000048:notes:55]
|  |  | September 30, 2020 |  | March 31, 2020 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Level 1 |  | Level 2 |  | Level 3 |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 301,090 |  |  | $ | — |  |  | $ | — |  |  | $ | 564,952 |  |  | $ | — |  |  | $ | — |  |
| Trading investments for deferred compensation plan included in other assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 233 |  |  | $ | — |  |  | $ | — |  |  | $ | 846 |  |  | $ | — |  |  | $ | — |  |
| Common stock |  | 1,388 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Money market funds |  | 8,650 |  |  | — |  |  | — |  |  | 7,147 |  |  | — |  |  | — |  |
| Mutual funds |  | 14,288 |  |  | — |  |  | — |  |  | 12,092 |  |  | — |  |  | — |  |
| Total of trading investments for deferred compensation plan |  | $ | 24,559 |  |  | $ | — |  |  | $ | — |  |  | $ | 20,085 |  |  | $ | — |  |  | $ | — |  |
| Currency exchange derivative assetsincluded in other current assets |  | $ | — |  |  | $ | 1,836 |  |  | $ | — |  |  | $ | — |  |  | $ | 129 |  |  | $ | — |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Contingent consideration for business acquisition included in accrued and other current liabilities |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 23,284 |  |
| Currency exchange derivative liabilitiesincluded in accrued and other current liabilities |  | $ | — |  |  | $ | 130 |  |  | $ | — |  |  | $ | — |  |  | $ | 719 |  |  | $ | — |  |

[0001032975-20-000048:notes:56]
The following table summarizes the change in the fair value of the Company's contingent consideration balance during the six months ended September 30, 2020 (in thousands):

[0001032975-20-000048:notes:57]
|  | Six Months EndedSeptember 30, 2020 |
| Beginning of the period | $ | 23,284 |  |
| Change in fair value of contingent consideration | 5,716 |  |
| End of the period (1) | $ | 29,000 |  |

[0001032975-20-000048:notes:58]
(1) As of June 30, 2020, the earn-out period was completed. The earn-out payment of $29.0 million is based on the actual net sales of Streamlabs services and no longer subject to fair value measurement and was accordingly transferred out of Level 3.  The expected earn-out payment is included in the accrued and other current liabilities of the unaudited condensed consolidated balance sheet.

[0001032975-20-000048:notes:59]
[same as prior period, unchanged from 0001032975-20-000033:notes:58]

[0001032975-20-000048:notes:60]
The marketable securities for the Company's deferred compensation plan were recorded at a fair value of $24.6 million and $20.1 million, as of September 30, 2020 and March 31, 2020, respectively, based on quoted market prices. Quoted market prices are observable inputs that are classified as Level 1 within the fair value hierarchy. Unrealized gains (losses) related to trading securities for the three and six months ended September 30, 2020 and 2019 were not material and are included in other income, net in the Company's condensed consolidated statements of operations.

[0001032975-20-000048:notes:61]
[same as prior period, unchanged from 0001032975-20-000033:notes:60]

[0001032975-20-000048:notes:62]
On October 31, 2019 (the "Streamlabs Acquisition Date"), the Company acquired all of the equity interests of General Workings, Inc. ("Streamlabs"). The contingent consideration for business acquisition arising from the Streamlabs Acquisition represents the future potential earn-out payments of $29.0 million payable in stock only upon the achievement of certain net sales for the period beginning on January 1, 2020 and ending on June 30, 2020. The fair value of the earn-out as of the Streamlabs Acquisition Date was $0.04 million, and increased to $23.3

[0001032975-20-000048:notes:63]
million as of March 31, 2020, which was determined by using a Black-Scholes-Merton valuation model to calculate the probability of the earn-out threshold being met and times the value of the earn-out payment, and discounted at the risk-free rate. The valuation included significant assumptions and unobservable inputs such as the projected sales of Streamlabs over the earn-out period, the risk-free rate, and the net sales volatility. The fair value was increased by $5.7 million to $29.0 million as of June 30, 2020, based on actual sales. The fair value of the contingent consideration no longer needs to be remeasured at each reporting period, as the earn-out period has been completed.

[0001032975-20-000048:notes:64]
[same as prior period, unchanged from 0001032975-20-000033:notes:63]

[0001032975-20-000048:notes:65]
The Company has certain non-marketable investments included in other assets that are accounted for under the equity method of accounting, with a carrying value of $42.3 million and $42.1 million as of September 30, 2020 and March 31, 2020, respectively. There was no impairment of these assets during the three and six months ended September 30, 2020 or 2019.

[0001032975-20-000048:notes:66]
Other Assets Measured at Fair Value on a Nonrecurring Basis

[0001032975-20-000048:notes:67]
Financial Assets.  The Company has certain investments without readily determinable fair values due to the absence of quoted market prices, the inherent lack of liquidity, and the fact that inputs used to measure fair value are unobservable and require management's judgment. When certain events or circumstances indicate that impairment may exist, the Company revalues the investments using various assumptions, including the financial metrics and ratios of comparable public companies. The carrying value is also adjusted for observable price changes with a same or similar security from the same issuer. The amount of these investments included in other assets was immaterial as of September 30, 2020 and March 31, 2020. There was no impairment of these assets during the three and six months ended September 30, 2020 or 2019.

[0001032975-20-000048:notes:68]
Non-Financial Assets.  Goodwill, intangible assets, and property, plant and equipment, are not required to be measured at fair value on a recurring basis. However, if certain triggering events occur (or tested at least annually for goodwill) such that a non-financial instrument is required to be evaluated for impairment and an impairment is recorded to reduce the non-financial instrument's carrying value to the fair value as a result of such triggering events, the non-financial assets and liabilities are measured at fair value for the period such triggering events occur. There was no impairment of these assets during the three and six months ended September 30, 2020 or 2019.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001032975-20-000048:notes:69]
[same as prior period, unchanged from 0001032975-20-000033:notes:68]

[0001032975-20-000048:notes:70]
Under certain agreements with the respective counterparties to the Company’s derivative contracts, subject to applicable requirements, the Company is allowed to net settle transactions of the same type with a single net amount payable by one party to the other. However, the Company presents its derivative assets and derivative liabilities on a gross basis on the condensed consolidated balance sheets as of September 30, 2020 and March 31, 2020.

[0001032975-20-000048:notes:71]
The fair value of the Company’s derivative instruments was not material as of September 30, 2020 or March 31, 2020. The amount of gain (loss) recognized on derivatives not designated as hedging instruments was not material in all periods presented herein. The following table presents the amounts of gains (losses) on the Company’s derivative instruments designated as hedging instruments and their locations on its condensed consolidated statements of operations and condensed consolidated statements of comprehensive income for the  three and six months ended September 30, 2020 and 2019 (in thousands):

[0001032975-20-000048:notes:72]
|  |  | Three Months EndedSeptember 30, |
|  |  | Amount of Gain (Loss)Deferred as a Component of AccumulatedOther Comprehensive Loss |  | Amount of Loss (Gain)Reclassified from Accumulated Other Comprehensive Loss to Costs of Goods Sold |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Cash flow hedges |  | $ | (1,059 | ) |  | $ | 2,380 |  |  | $ | 1,969 |  |  | $ | (132 | ) |

[0001032975-20-000048:notes:73]
|  |  | Six Months EndedSeptember 30, |
|  |  | Amount of Gain (Loss)Deferred as a Component of AccumulatedOther Comprehensive Loss |  | Amount of Loss (Gain)Reclassified from Accumulated Other Comprehensive Loss to Costs of Goods Sold |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Cash flow hedges |  | $ | (3,426 | ) |  | $ | 1,437 |  |  | $ | 1,639 |  |  | $ | (358 | ) |

[0001032975-20-000048:notes:74]
[same as prior period, unchanged from 0001032975-20-000033:notes:72]

[0001032975-20-000048:notes:75]
The Company enters into cash flow hedge contracts to protect against exchange rate exposure of forecasted inventory purchases. These hedging contracts mature within four months. Gains and losses in the fair value of the effective portion of the hedges are deferred as a component of accumulated other comprehensive loss until the hedged inventory purchases are sold, at which time the gains or losses are reclassified to cost of goods sold. Cash flows from such hedges are classified as operating activities in the condensed consolidated statements of cash flows. Hedging relationships are discontinued when hedging contract is no longer eligible for hedge accounting, or is sold, terminated or exercised, or when Company removes hedge designation for the contract. Gains and losses in the fair value of the effective portion of the discontinued hedges continue to be reported in accumulated other comprehensive loss until the hedged inventory purchases are sold, unless it is probable that the forecasted inventory purchases will not occur by the end of the originally specified time period or within an additional two-month period of time thereafter. In all periods presented herein, there have been no forecasted inventory purchases that were probable to not occur by the end of the originally specified time period or within an additional two-month period of time thereafter. The notional amounts of foreign currency exchange forward contracts outstanding related to forecasted inventory purchases were $155.5 million as of September 30, 2020 and $48.0 million as of March 31, 2020. The Company had $2.0 million of net losses related to its cash flow hedges included in accumulated other comprehensive loss as of September 30, 2020, which will be reclassified into earnings within the next 12 months.

[0001032975-20-000048:notes:76]
[same as prior period, unchanged from 0001032975-20-000033:notes:74]

[0001032975-20-000048:notes:77]
The Company also enters into foreign currency exchange forward and swap contracts to reduce the short-term effects of currency exchange rate fluctuations on certain receivables or payables denominated in currencies other than the functional currencies of its subsidiaries. These contracts generally mature within one month. The primary risk managed by using forward and swap contracts is the currency exchange rate risk. The gains or losses on these contracts are recognized in other income, net in the condensed consolidated statements of operations based on the changes in fair value. The notional amounts of these contracts outstanding as of September 30, 2020 and March 31, 2020 were $86.5 million and $64.7 million, respectively. Open forward and swap contracts outstanding as of September 30, 2020 and March 31, 2020 consisted of contracts in Mexican Pesos, Japanese Yen, Canadian Dollars, Taiwan New Dollars and Australian Dollars to be settled at future dates at pre-determined exchange rates.

[0001032975-20-000048:notes:78]
[same as prior period, unchanged from 0001032975-20-000033:notes:76]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001032975-20-000048:notes:79]
[same as prior period, unchanged from 0001032975-20-000033:notes:77]

[0001032975-20-000048:notes:80]
The Company conducts its impairment analysis of goodwill annually at December 31 and as necessary, if changes in facts and circumstances indicate that it is more likely than not that the fair value of the Company’s reporting unit may be less than its carrying amount. There have been no events or circumstances during the six months ended September 30, 2020 that have required the Company to perform an interim assessment of goodwill.

[0001032975-20-000048:notes:81]
The following table summarizes the activities in the Company’s goodwill balance during the six months ended September 30, 2020 (in thousands):

[0001032975-20-000048:notes:82]
| As of March 31, 2020 |  | $ | 400,917 |  |
| Currency translation |  | 36 |  |
| As of September 30, 2020 |  | $ | 400,953 |  |

[0001032975-20-000048:notes:83]
[same as prior period, unchanged from 0001032975-20-000033:notes:81]

[0001032975-20-000048:notes:84]
|  |  | September 30, 2020 |  | March 31, 2020 |
|  |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |
| Trademark and trade names |  | $ | 45,570 |  |  | $ | (22,097 | ) |  | $ | 23,473 |  |  | $ | 45,570 |  |  | $ | (19,061 | ) |  | $ | 26,509 |  |
| Developed technology |  | 118,807 |  |  | (83,481 | ) |  | 35,326 |  |  | 118,807 |  |  | (77,126 | ) |  | 41,681 |  |
| Customer contracts/relationships |  | 90,610 |  |  | (37,707 | ) |  | 52,903 |  |  | 90,610 |  |  | (31,859 | ) |  | 58,751 |  |
| Total |  | $ | 254,987 |  |  | $ | (143,285 | ) |  | $ | 111,702 |  |  | $ | 254,987 |  |  | $ | (128,046 | ) |  | $ | 126,941 |  |


## us-gaap:DebtDisclosureTextBlock

[0001032975-20-000048:notes:85]
Financing Arrangements

[0001032975-20-000048:notes:86]
The Company had several uncommitted, unsecured bank lines of credit aggregating $84.2 million as of September 30, 2020. There are no financial covenants under these lines of credit with which the Company must comply. As of September 30, 2020, the Company had outstanding bank guarantees of $22.9 million under these lines of credit. There was no borrowing outstanding under these lines of credit as of September 30, 2020 or March 31, 2020.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001032975-20-000048:notes:87]
Commitments and Contingencies

[0001032975-20-000048:notes:88]
Product Warranties

[0001032975-20-000048:notes:89]
Changes in the Company’s warranty liability for the three and six months ended September 30, 2020 and 2019 were as follows (in thousands):

[0001032975-20-000048:notes:90]
|  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Beginning of the period | $ | 39,450 |  |  | $ | 35,814 |  |  | $ | 40,039 |  |  | $ | 34,229 |  |
| Provision | 9,494 |  |  | 8,509 |  |  | 14,883 |  |  | 17,044 |  |
| Settlements | (7,541 | ) |  | (6,727 | ) |  | (13,702 | ) |  | (13,704 | ) |
| Currency translation | 379 |  |  | (374 | ) |  | 562 |  |  | (347 | ) |
| End of the period | $ | 41,782 |  |  | $ | 37,222 |  |  | $ | 41,782 |  |  | $ | 37,222 |  |

[0001032975-20-000048:notes:91]
Indemnifications

[0001032975-20-000048:notes:92]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of September 30, 2020, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

[0001032975-20-000048:notes:93]
The Company also indemnifies its current and former directors and certain of its current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. The Company is unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not limited, the obligations are conditional in nature and the facts and circumstances involved in any situation that might arise are variable.

[0001032975-20-000048:notes:94]
Legal Proceedings

[0001032975-20-000048:notes:95]
From time to time the Company is involved in claims and legal proceedings that arise in the ordinary course of its business. The Company is currently subject to several such claims and a small number of legal proceedings. The Company believes that these matters lack merit and intends to vigorously defend against them. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company’s defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company’s business, financial condition, cash flows or results of operations in a particular period. Any claims or proceedings against the Company, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain a necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company’s business.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001032975-20-000048:notes:96]
[same as prior period, unchanged from 0001032975-20-000033:notes:94]

[0001032975-20-000048:notes:97]
[same as prior period, unchanged from 0001032975-20-000033:notes:95]

[0001032975-20-000048:notes:98]
In March 2017, the Company's Board of Directors approved the 2017 share buyback program, which authorized the Company to use up to $250.0 million to purchase up to 17.3 million shares of Logitech shares. This share buyback program expired in April 2020. The Company did not repurchase any of its registered shares during April 2020.

[0001032975-20-000048:notes:99]
In May 2020, the Company's Board of Directors approved the 2020 share buyback program, which authorized the Company to use up to $250.0 million to purchase up to 17.3 million of Logitech shares. The Company's share buyback program is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Purchases may be started or stopped at any time without prior notice depending on market conditions and other factors. As of September 30, 2020, $227.6 million is still available for repurchase under the 2020 buyback program.

[0001032975-20-000048:notes:100]
Dividends

[0001032975-20-000048:notes:101]
During the three and six months ended September 30, 2020, the Company declared and paid cash dividends of CHF 0.79 (USD equivalent of $0.87) per share, totaling $146.7 million on the Company's outstanding shares. During the three and six months ended September 30, 2019, the Company declared and paid cash dividends of CHF 0.73 (USD equivalent of $0.74) per share, totaling $124.2 million on the Company's outstanding shares.

[0001032975-20-000048:notes:102]
Any future dividends will be subject to approval of the Company's shareholders.

[0001032975-20-000048:notes:103]
Additional Authorized and Conditional Shares

[0001032975-20-000048:notes:104]
The Company has reserved conditional capital of 25,000,000 shares for potential issuance on the exercise of rights granted under the Company's employee equity incentive plans and additional conditional capital for financing purposes, representing the issuance of up to 25,000,000 shares to cover any conversion rights under a future convertible bond issuance. At the 2018 Annual General Meeting, the shareholders of the Company authorized the Board of Directors to issue up to an additional 34,621,324 shares of the Company until September 5, 2020, which authority expired on that date. At the 2020 Annual General Meeting, the shareholders of the Company authorized the Board of Directors to issue up to an additional 17,310,662 shares of the Company until September 9, 2022.

[0001032975-20-000048:notes:105]
[same as prior period, unchanged from 0001032975-20-000033:notes:98]

[0001032975-20-000048:notes:106]
[same as prior period, unchanged from 0001032975-20-000033:notes:99]

[0001032975-20-000048:notes:107]
|  |  | Accumulated Other Comprehensive Income (Loss) |
|  |  | CumulativeTranslationAdjustment |  | DefinedBenefitPlan |  | Deferred Hedging Losses |  | Total |
| March 31, 2020 |  | $ | (100,418 | ) |  | $ | (20,016 | ) |  | $ | (226 | ) |  | $ | (120,660 | ) |
| Other comprehensive income (loss) |  | 2,706 |  |  | 889 |  |  | (1,787 | ) |  | 1,808 |  |
| September 30, 2020 |  | $ | (97,712 | ) |  | $ | (19,127 | ) |  | $ | (2,013 | ) |  | $ | (118,852 | ) |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001032975-20-000048:notes:108]
[same as prior period, unchanged from 0001032975-20-000033:notes:101]

[0001032975-20-000048:notes:109]
[same as prior period, unchanged from 0001032975-20-000033:notes:102]

[0001032975-20-000048:notes:110]
Sales by product categories and sales channels, excluding intercompany transactions, for the three and six months ended September 30, 2020 and 2019 were as follows (in thousands):

[0001032975-20-000048:notes:111]
|  |  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Pointing Devices |  | $ | 169,121 |  |  | $ | 132,770 |  |  | $ | 289,590 |  |  | $ | 254,753 |  |
| Keyboards & Combos |  | 201,617 |  |  | 139,049 |  |  | 346,977 |  |  | 267,728 |  |
| PC Webcams |  | 102,469 |  |  | 28,748 |  |  | 163,320 |  |  | 56,876 |  |
| Tablet & Other Accessories |  | 83,086 |  |  | 33,847 |  |  | 129,134 |  |  | 72,186 |  |
| Gaming |  | 297,711 |  |  | 161,014 |  |  | 479,614 |  |  | 295,529 |  |
| Video Collaboration |  | 236,704 |  |  | 89,553 |  |  | 366,778 |  |  | 162,977 |  |
| Mobile Speakers |  | 43,581 |  |  | 57,232 |  |  | 72,590 |  |  | 107,648 |  |
| Audio & Wearables |  | 114,275 |  |  | 68,018 |  |  | 185,640 |  |  | 126,642 |  |
| Smart Home |  | 8,573 |  |  | 9,434 |  |  | 15,383 |  |  | 19,298 |  |
| Other (1) |  | 21 |  |  | 26 |  |  | 26 |  |  | 279 |  |
| Total sales |  | $ | 1,257,158 |  |  | $ | 719,691 |  |  | $ | 2,049,052 |  |  | $ | 1,363,916 |  |

[0001032975-20-000048:notes:112]
[same as prior period, unchanged from 0001032975-20-000033:notes:105]

[0001032975-20-000048:notes:113]
Sales by geographic region (based on the customers’ locations) for the three and six months ended September 30, 2020 and 2019 were as follows (in thousands):

[0001032975-20-000048:notes:114]
|  |  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Americas |  | $ | 542,319 |  |  | $ | 296,837 |  |  | $ | 898,503 |  |  | $ | 590,282 |  |
| EMEA |  | 389,578 |  |  | 231,981 |  |  | 600,349 |  |  | 411,087 |  |
| Asia Pacific |  | 325,261 |  |  | 190,873 |  |  | 550,200 |  |  | 362,547 |  |
| Total sales |  | $ | 1,257,158 |  |  | $ | 719,691 |  |  | $ | 2,049,052 |  |  | $ | 1,363,916 |  |

[0001032975-20-000048:notes:115]
[same as prior period, unchanged from 0001032975-20-000033:notes:108]

[0001032975-20-000048:notes:116]
The United States and Germany each represented 10% or more of the total consolidated sales for each of the periods presented herein. No other countries represented 10% or more of the Company’s total consolidated sales for the periods presented herein.

[0001032975-20-000048:notes:117]
Switzerland, the Company’s home domicile, represented 3% and 2% of the Company's total consolidated sales for the  three and six months ended September 30, 2020, respectively, and represented 4% and 3% of the Company's total consolidated sales for the three and six months ended September 30, 2019, respectively.

[0001032975-20-000048:notes:118]
Two customers of the Company each represented 10% or more of the total consolidated sales for each of the periods presented herein.

[0001032975-20-000048:notes:119]
[same as prior period, unchanged from 0001032975-20-000033:notes:112]

[0001032975-20-000048:notes:120]
|  |  | September 30, 2020 |  | March 31, 2020 |
| Americas |  | $ | 23,080 |  |  | $ | 26,636 |  |
| EMEA |  | 6,257 |  |  | 5,052 |  |
| Asia Pacific |  | 57,049 |  |  | 44,431 |  |
| Total property, plant and equipment, net |  | $ | 86,386 |  |  | $ | 76,119 |  |

[0001032975-20-000048:notes:121]
Property, plant and equipment, net in the United States and China were $22.9 million and $48.9 million, respectively, as of September 30, 2020, and $26.5 million and $36.6 million, respectively, as of March 31, 2020. No other countries represented 10% or more of the Company’s total consolidated property, plant and equipment, net as of September 30, 2020 or March 31, 2020. Property, plant and equipment, net in Switzerland, the Company’s home domicile, were $3.7 million and $2.3 million as of September 30, 2020 and March 31, 2020, respectively.


## us-gaap:SubsequentEventsTextBlock

[0001032975-20-000048:notes:122]
Subsequent Event

[0001032975-20-000048:notes:123]
During October 2020, Logitech issued or reserved 397,763 shares out of treasury shares to former security holders of Streamlabs related to the achievement of certain net sales milestones during the earn-out period of contingent consideration in connection with the business acquisition. The issuances of such shares were deemed to be exempt from registration under the Securities Act, in reliance on Regulation D of the Securities Act as transactions by an issuer not involving a public offering.
