# LOGI MD&A — 0001032975-18-000037


## mdna

[0001032975-18-000037:mdna:1]
[same as prior period, unchanged from 0001032975-18-000007:mdna:1]

[0001032975-18-000037:mdna:2]
[same as prior period, unchanged from 0001032975-18-000007:mdna:2]

[0001032975-18-000037:mdna:3]
[same as prior period, unchanged from 0001032975-18-000007:mdna:3]

[0001032975-18-000037:mdna:4]
Logitech is a world leader in designing, manufacturing and marketing products that help connect people to digital and cloud experiences. More than 35 years ago, Logitech created products to improve experiences around the personal PC platform, and today it is a multi-brand, multi-category company designing products that enable better experiences consuming, sharing and creating any digital content such as music, gaming, video and computing, whether it is on a computer, mobile device or in the cloud. Logitech's brands include Logitech, Jaybird, Ultimate Ears, Logitech G and ASTRO Gaming.

[0001032975-18-000037:mdna:5]
Our products participate in five large markets that all have growth opportunities: Music, Gaming, Video Collaboration, Smart Home and Creativity & Productivity. We sell our products to a broad network of domestic and international customers, including direct sales to retailers and e-tailers, and indirect sales through distributors. Our worldwide channel network includes consumer electronics distributors, retailers, mass merchandisers, specialty stores, computer and telecommunications stores, value-added resellers and online merchants.

[0001032975-18-000037:mdna:6]
[same as prior period, unchanged from 0001032975-18-000007:mdna:6]

[0001032975-18-000037:mdna:7]
[same as prior period, unchanged from 0001032975-18-000007:mdna:8]

[0001032975-18-000037:mdna:8]
Our net sales for the three months ended June 30, 2018 increased 15% compared to the three months ended June 30, 2017, due to stronger net sales across all regions.  ASTRO contributed 5 points to the net sales growth during the period. Our net sales for the three months ended June 30, 2018 increased 13%, 7% and 28% in the Americas, EMEA and Asia Pacific, respectively, compared to the same period of the prior fiscal year.

[0001032975-18-000037:mdna:9]
[same as prior period, unchanged from 0001032975-18-000007:mdna:12]

[0001032975-18-000037:mdna:10]
Our gross margin for the three months ended June 30, 2018 increased 30 basis points to 36.8% from 36.5% for the three months ended June 30, 2017 as a result of a one-time benefit of approximately 60 basis points from a legal settlement with our prior distribution center supplier in the Americas as well as favorable exchange rates and product cost savings. Those benefits were partially offset by supply chain and logistics costs.

[0001032975-18-000037:mdna:11]
Operating expenses for the three months ended June 30, 2018 were $191.5 million, or 31.5% of net sales, compared to $162.2 million, or 30.6% of net sales, in the same period of the prior fiscal year. The increase in operating expenses was primarily driven by $26.5 million higher personnel-related cost due to restructuring charges in the current period, increased variable compensation linked to stronger performance and additional headcount from prior business acquisitions.

[0001032975-18-000037:mdna:12]
Net income for the three months ended June 30, 2018 was $38.5 million, compared to $37.0 million for the three months ended June 30, 2017.

[0001032975-18-000037:mdna:13]
[same as prior period, unchanged from 0001032975-18-000007:mdna:19]

[0001032975-18-000037:mdna:14]
[same as prior period, unchanged from 0001032975-18-000007:mdna:20]

[0001032975-18-000037:mdna:15]
[same as prior period, unchanged from 0001032975-18-000007:mdna:21]

[0001032975-18-000037:mdna:16]
[same as prior period, unchanged from 0001032975-18-000007:mdna:22]

[0001032975-18-000037:mdna:17]
Music:  The music market grew during fiscal year 2018, driven by growing consumption of music through mobile devices such as smartphones and tablets. The integration of personal voice assistants has become increasingly competitive in the speaker categories and the market for third-party, voice-enabled speakers has not yet gained traction. Moreover, the market for mobile speakers appears to be maturing with slower growth. Our investments in the Ultimate Ears and Jaybird brands, new channel expansion, integration of personal voice assistants, such as Google Assistant and Amazon Alexa, and our new product introductions, have driven our growth in this market through the third quarter of fiscal year 2018, though sales of our Mobile Speakers declined during the fourth quarter of fiscal year 2018 and the first quarter of fiscal year 2019. While we continue to introduce new product for improved experiences, we're adjusting our investments to match the slower market growth outlook.

[0001032975-18-000037:mdna:18]
Gaming:  The PC gaming and console gaming platform continues to show strong growth as online gaming, multi-platform experiences, and eSports gain greater popularity and gaming content becomes increasingly more

[0001032975-18-000037:mdna:19]
demanding. We believe Logitech is well positioned to benefit from the PC gaming market growth. With ASTRO Gaming, we are also strengthening our portfolio in adjacent categories, such as the console gaming market.

[0001032975-18-000037:mdna:20]
Video Collaboration:  The near and long-term structural growth opportunities in the video collaboration market are significant. Video meetings are on the rise, and companies increasingly want lower-cost, cloud-based solutions. We are continuing our efforts to create and sell innovative products to accommodate the increasing demand from medium-sized meeting rooms to small-sized rooms such as huddle rooms. We will continue to invest in select business-specific products, targeted product marketing and sales channel development.

[0001032975-18-000037:mdna:21]
Smart Home:  This market grew in fiscal year 2018 and continued to grow in fiscal year 2019. In October 2016, we integrated Amazon Alexa and Google Assistant voice capabilities into our Logitech Harmony Hub that enables voice control of the living room entertainment experience when used with an Amazon Echo or Google Home device. Through Harmony, Alexa can turn on/off and control a TV and AV system. We have also seen early success with the professional installer channel through the recent introduction of the Harmony Pro. We will continue to explore other innovative experiences for the Smart Home.

[0001032975-18-000037:mdna:22]
Creativity & Productivity:  New PC shipments continue to be stable and the installed base of PC users remains large. We believe that innovative PC peripherals, such as our mice and keyboards, can renew the PC usage experience, providing growth opportunities. Smaller mobile computing devices, such as tablets, have created new markets and usage models for peripherals and accessories. We offer a number of products to enhance the use of mobile devices, including keyboard folios for the iPad and iPad mini, and keyboard covers and folios for the iPad Air. In fiscal year 2018, we saw the recovery of the iPad tablet market and our Tablet & Other Accessories category has benefited from the recovery along with our innovative products.

[0001032975-18-000037:mdna:23]
[same as prior period, unchanged from 0001032975-18-000007:mdna:30]

[0001032975-18-000037:mdna:24]
[same as prior period, unchanged from 0001032975-18-000007:mdna:31]

[0001032975-18-000037:mdna:25]
[same as prior period, unchanged from 0001032975-18-000007:mdna:32]

[0001032975-18-000037:mdna:26]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States of America (“GAAP”) requires us to make judgments, estimates and assumptions that affect reported amounts of assets, liabilities, goodwill and intangible assets from business acquisitions, contingent consideration from business acquisitions, and net sales and expenses.

[0001032975-18-000037:mdna:27]
[same as prior period, unchanged from 0001032975-18-000007:mdna:34]

[0001032975-18-000037:mdna:28]
[same as prior period, unchanged from 0001032975-18-000007:mdna:35]

[0001032975-18-000037:mdna:29]
Other than the recent accounting pronouncement adoptions discussed below and Summary of Significant Accounting Policies discussed in Note 1 to the condensed consolidated financial statements, there have been no substantial changes in the Company’s significant accounting policies during the three months ended June 30, 2018, compared with the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended March 31, 2018.

[0001032975-18-000037:mdna:30]
28

[0001032975-18-000037:mdna:31]
[same as prior period, unchanged from 0001032975-18-000007:mdna:37]

[0001032975-18-000037:mdna:32]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standard Update ("ASU") No. 2014-09, "Revenue from Contracts with Customers" ("ASU 2014-09" or “Topic 606”) which supersedes the revenue recognition requirements under ASC 605 (“Topic 605”), Revenue Recognition. ASU 2014-09 outlines a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes existing revenue recognition guidance, including industry-specific guidance. Under the new guidance, recognition of revenue occurs when a customer obtains control of promised goods or services in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. The new standard requires reporting companies to disclose the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. On April 1, 2018, we adopted the new standard and all related amendments using the modified retrospective method applied to those contracts which were not completed as of March 31, 2018. Results for reporting periods beginning after April 1, 2018 are presented under Topic 606, while prior period amounts are not adjusted and continue to be reported in accordance with historic accounting standards under Topic 605.

[0001032975-18-000037:mdna:33]
Refer to Note 1 to the condensed consolidated financial statements for further details of the impact of adoption.

[0001032975-18-000037:mdna:34]
In January 2016, the FASB issued ASU 2016-01, "Financial Instruments-Recognition and Measurement of Financial Assets and Financial Liabilities (Subtopic 825-10)" ("ASU 2016-01"). ASU 2016-01 requires entities to measure equity instruments at fair value and recognize any changes in fair value within the statement of operations. We adopted ASU 2016-01 effective April 1, 2018 on a prospective basis for our privately held strategic equity securities without readily determinable fair values. We elected the measurement alternative to record these investments at cost and to adjust for impairments and observable price changes with a same or similar security from the same issuer within the statement of operations. The adoption of ASU 2016-01 did not have a material impact on our condensed consolidated financial statements.

[0001032975-18-000037:mdna:35]
In October 2016, the FASB issued ASU 2016-16, "Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory" ("ASU 2016-16"), which eliminates the deferral of income tax effects of intra-entity asset transfers until the transferred asset is sold to an unrelated party or recovered through use. However, this standard does not apply to intra-entity transfer of inventory. We adopted this standard effective April 1, 2018 on a modified retrospective basis and the adoption of ASU 2016-16 did not have a material impact on our condensed consolidated financial statements.

[0001032975-18-000037:mdna:36]
In December 2016, the FASB issued ASU 2016-18, "Statement of Cash Flows (Topic 230): Restricted Cash" ("ASU 2016-18"), which requires that a statement of cash flows explains the change during the period in the total of cash, cash equivalents, and amounts generally described as restricted cash or restricted cash equivalents. We adopted this standard effective April 1, 2018 utilizing the retrospective transition method to each period presented and the adoption of ASU 2016-18 did not have a material impact on our condensed consolidated financial statements. We did not have restricted cash for both periods presented.

[0001032975-18-000037:mdna:37]
In January 2017, the FASB issued ASU 2017-01, "Business Combination (Topic 805): Clarifying the Definition of a Business" ("ASU 2017-01"), which changes the definition of a business to assist with evaluating when a set of transferred assets and activities is a business. We adopted this standard effective April 1, 2018 and the adoption of ASU 2017-01 did not have a material impact on our condensed consolidated financial statements.

[0001032975-18-000037:mdna:38]
In March 2017, the FASB issued ASU 2017-07, "Compensation-Retirement Benefit (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost" ("ASU 2017-07"), which requires that the Company disaggregate the service cost component from the other components of net benefit cost, and also provides guidance on how to present the service cost component and the other components of net benefit cost in the income statement and allow only the service cost component of net benefit cost to be eligible for capitalization. We adopted this standard effective April 1, 2018 using a retrospective adoption method. Other than the revised statement of operations presentation, the adoption of ASU 2017-07 did not have an impact on our condensed consolidated financial statements.

[0001032975-18-000037:mdna:39]
In August 2017, the FASB issued ASU 2017-12, "Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities" ("ASU 2017-12"), which improves the financial reporting of hedging relationships to better portray the economic results of an entity’s risk management activities in its financial

[0001032975-18-000037:mdna:40]
statements and simplifies the application of the hedge accounting guidance. We adopted this standard effective April 1, 2018 and the adoption of ASU 2017-12 did not have a material impact on our condensed consolidated financial statements. In accordance with ASC 815-20-45-1A, we have started presenting the earnings impact from forward points in the same line item that is used to present the earnings impact of the hedged item, i.e. Cost of Goods sold, for hedging forecasted inventory purchases.

[0001032975-18-000037:mdna:41]
[same as prior period, unchanged from 0001032975-18-000007:mdna:43]

[0001032975-18-000037:mdna:42]
[same as prior period, unchanged from 0001032975-18-000007:mdna:44]

[0001032975-18-000037:mdna:43]
[same as prior period, unchanged from 0001032975-18-000007:mdna:45]

[0001032975-18-000037:mdna:44]
[same as prior period, unchanged from 0001032975-18-000007:mdna:46]

[0001032975-18-000037:mdna:45]
[same as prior period, unchanged from 0001032975-18-000007:mdna:47]

[0001032975-18-000037:mdna:46]
Although our financial results are reported in U.S. Dollars, a portion of our sales was generated in currencies other than the U.S. Dollar, such as the Euro, Chinese Renminbi, Japanese Yen, Canadian Dollar, Taiwan New Dollar, British Pound and Australian Dollar. During the three months ended June 30, 2018, 49% of our net sales were denominated in currencies other than the U.S. Dollar.

[0001032975-18-000037:mdna:47]
[same as prior period, unchanged from 0001032975-18-000007:mdna:50]

[0001032975-18-000037:mdna:48]
[same as prior period, unchanged from 0001032975-18-000007:mdna:51]

[0001032975-18-000037:mdna:49]
Our net sales in the three months ended June 30, 2018 increased 15%, compared to the same periods of the prior fiscal year. Sales increased across all three regions during the three months ended June 30, 2018. If currency exchange rates had been constant in the three months ended June 30, 2018 and 2017, our constant dollar sales growth rates would have been 12%. We grew double digits for our Gaming, Video Collaboration, Keyboards & Combos, Tablets and Other Accessories, and PC Webcams product categories. ASTRO contributed 5 points to the net sales growth during the period. Sales for Mobile Speaker and Smart Home declined across the regions. The adoption of Topic 606 did not have a material impact on the net sales for the three months ended June 30, 2018.

[0001032975-18-000037:mdna:50]
[same as prior period, unchanged from 0001032975-18-000007:mdna:55]

[0001032975-18-000037:mdna:51]
The following table presents the change in net sales by region for the three months ended June 30, 2018, compared with the three months ended June 30, 2017:

[0001032975-18-000037:mdna:52]
|  |  | Sales Growth Rate |  | Sales Growth Rate in Constant Currency |
| Americas |  | 13 | % |  | 13 | % |
| EMEA |  | 7 |  |  | 1 |  |
| Asia Pacific |  | 28 |  |  | 23 |  |

[0001032975-18-000037:mdna:53]
[same as prior period, unchanged from 0001032975-18-000007:mdna:58]

[0001032975-18-000037:mdna:54]
The increase in net sales in our Americas region was primarily driven by growth in Gaming (including ASTRO), Video Collaboration, Tablets and Other Accessories, Video Collaboration and PC Webcams, partially offset by a decline in sales for Mobile Speakers and Smart Home.

[0001032975-18-000037:mdna:55]
[same as prior period, unchanged from 0001032975-18-000007:mdna:60]

[0001032975-18-000037:mdna:56]
The increase in net sales in our EMEA region was primarily driven by growth in Gaming (including ASTRO), Video Collaboration, Tablets and Other Accessories, partially offset by a decline in sales for Mobile Speakers and Smart Home.

[0001032975-18-000037:mdna:57]
[same as prior period, unchanged from 0001032975-18-000007:mdna:62]

[0001032975-18-000037:mdna:58]
The growth in our Asia Pacific region during the period was primarily driven by growth in Gaming, Keyboards and Combos, Video Collaboration and Pointing Devices.

[0001032975-18-000037:mdna:59]
[same as prior period, unchanged from 0001032975-18-000007:mdna:64]

[0001032975-18-000037:mdna:60]
Net sales by product category for the three months ended June 30, 2018 and 2017 were as follows (Dollars in thousands):

[0001032975-18-000037:mdna:61]
|  |  | Three Months EndedJune 30, |
|  |  | 2018 |  | 2017 |  | Change |
| Pointing Devices |  | $ | 127,790 |  |  | $ | 122,074 |  |  | 5 | % |
| Keyboards & Combos |  | 128,222 |  |  | 116,113 |  |  | 10 |  |
| PC Webcams |  | 29,674 |  |  | 25,625 |  |  | 16 |  |
| Tablet & Other Accessories |  | 32,436 |  |  | 23,218 |  |  | 40 |  |
| Video Collaboration |  | 58,792 |  |  | 35,617 |  |  | 65 |  |
| Mobile Speakers |  | 34,327 |  |  | 62,918 |  |  | (45 | ) |
| Audio & Wearables |  | 52,154 |  |  | 50,202 |  |  | 4 |  |
| Gaming |  | 136,026 |  |  | 77,708 |  |  | 75 |  |
| Smart Home |  | 9,011 |  |  | 16,466 |  |  | (45 | ) |
| Other (1) |  | 48 |  |  | 5 |  |  | 860 |  |
| Total net sales |  | $ | 608,480 |  |  | $ | 529,946 |  |  | 15 |  |

[0001032975-18-000037:mdna:62]
[same as prior period, unchanged from 0001032975-18-000007:mdna:67]

[0001032975-18-000037:mdna:63]
[same as prior period, unchanged from 0001032975-18-000007:mdna:68]

[0001032975-18-000037:mdna:64]
[same as prior period, unchanged from 0001032975-18-000007:mdna:69]

[0001032975-18-000037:mdna:65]
[same as prior period, unchanged from 0001032975-18-000007:mdna:70]

[0001032975-18-000037:mdna:66]
[same as prior period, unchanged from 0001032975-18-000007:mdna:71]

[0001032975-18-000037:mdna:67]
Net sales of Pointing Devices increased 5% for the three months ended June 30, 2018 compared to the same period of the prior fiscal year. The increase for the three-month period was primarily driven by an increase in sales for MX Master 2S Wireless Mouse and the introduction of MX Ergo Wireless Trackball.

[0001032975-18-000037:mdna:68]
[same as prior period, unchanged from 0001032975-18-000007:mdna:73]

[0001032975-18-000037:mdna:69]
[same as prior period, unchanged from 0001032975-18-000007:mdna:74]

[0001032975-18-000037:mdna:70]
Net sales of Keyboards & Combos increased 10% in the three months ended June 30, 2018, compared to the same period of the prior fiscal year. The increase was primarily driven by an increase in sales for cordless keyboards and combos, mainly from the introduction of MK540 Wireless Keyboard Mouse Combo in the fourth quarter of fiscal year 2018, partially offset by a decrease in sales of living room keyboards.

[0001032975-18-000037:mdna:71]
[same as prior period, unchanged from 0001032975-18-000007:mdna:76]

[0001032975-18-000037:mdna:72]
[same as prior period, unchanged from 0001032975-18-000007:mdna:77]

[0001032975-18-000037:mdna:73]
PC Webcams net sales increased 16% in the three months ended June 30, 2018, compared to the same period of the prior fiscal year. The increase for the three-month period was primarily driven by an increase in sales for our HD Pro Webcam C920 and 1080P Pro Stream Webcam.

[0001032975-18-000037:mdna:74]
[same as prior period, unchanged from 0001032975-18-000007:mdna:79]

[0001032975-18-000037:mdna:75]
Our Tablet & Other Accessories category primarily comprises keyboards for tablets.

[0001032975-18-000037:mdna:76]
Net sales of Tablet & Other Accessories products increased 40% in the three months ended June 30, 2018, compared to the same period of the prior fiscal year. The increase was primarily driven by an increase in sales for our education-based Rugged Combo 2 that was introduced in the first quarter of fiscal year 2019, in addition to increased sales for our Slim Folio keyboard case, and our Slim Combo keyboard cases.

[0001032975-18-000037:mdna:77]
[same as prior period, unchanged from 0001032975-18-000007:mdna:82]

[0001032975-18-000037:mdna:78]
[same as prior period, unchanged from 0001032975-18-000007:mdna:83]

[0001032975-18-000037:mdna:79]
[same as prior period, unchanged from 0001032975-18-000007:mdna:84]

[0001032975-18-000037:mdna:80]
Net sales of Video Collaboration products increased 65% in the three months ended June 30, 2018 compared to the same period of the prior fiscal year. The increase was primarily due to strong sales for our Meetup video conference camera, PTZ Pro 2 group camera, and high-end business webcams.

[0001032975-18-000037:mdna:81]
[same as prior period, unchanged from 0001032975-18-000007:mdna:86]

[0001032975-18-000037:mdna:82]
[same as prior period, unchanged from 0001032975-18-000007:mdna:87]

[0001032975-18-000037:mdna:83]
[same as prior period, unchanged from 0001032975-18-000007:mdna:88]

[0001032975-18-000037:mdna:84]
Net sales of Mobile Speakers decreased 45% for the three months ended June 30, 2018, compared to the same period of the prior fiscal year. The decrease for the period was primarily due to a decline in sales for our Ultimate Ears Megaboom, Boom 2, and Wonderboom mobile speakers, partially offset by sales from the introduction of our Ultimate Ears Megablast and Blast mobile speakers in the third quarter of fiscal year 2018.

[0001032975-18-000037:mdna:85]
Audio & Wearables

[0001032975-18-000037:mdna:86]
Our Audio & Wearables category comprises PC speakers, PC headsets, in-ear headphones and premium wireless audio wearables.

[0001032975-18-000037:mdna:87]
Audio & Wearables net sales increased 4% for the three months ended June 30, 2018, compared to the same period of the prior fiscal year. The increase for the period was primarily driven by a sales increase for our corded headsets.

[0001032975-18-000037:mdna:88]
[same as prior period, unchanged from 0001032975-18-000007:mdna:93]

[0001032975-18-000037:mdna:89]
[same as prior period, unchanged from 0001032975-18-000007:mdna:94]

[0001032975-18-000037:mdna:90]
[same as prior period, unchanged from 0001032975-18-000007:mdna:95]

[0001032975-18-000037:mdna:91]
Gaming net sales increased 75% for the three months ended June 30, 2018, compared to the same period of the prior fiscal year. The significant increase for the period was primarily driven by the strong performance of console gaming headsets from the acquisition of ASTRO, as well as the continuing success for our gaming mice and PC gaming headsets.

[0001032975-18-000037:mdna:92]
[same as prior period, unchanged from 0001032975-18-000007:mdna:97]

[0001032975-18-000037:mdna:93]
[same as prior period, unchanged from 0001032975-18-000007:mdna:98]

[0001032975-18-000037:mdna:94]
Our Smart Home category includes our Harmony line of advanced home entertainment controllers and home security cameras.

[0001032975-18-000037:mdna:95]
Smart Home net sales decreased 45% during the three months ended June 30, 2018, compared to the same period of the prior fiscal year. The decrease was primarily due to a decline in sales for our Harmony Smart Home remotes, which grew approximately 50% a year ago, partially offset by an increase in sales for our Circle 2 wired and wireless security cameras introduced in the second quarter of fiscal year 2018.

[0001032975-18-000037:mdna:96]
[same as prior period, unchanged from 0001032975-18-000007:mdna:101]

[0001032975-18-000037:mdna:97]
Gross profit for the three months ended June 30, 2018 and 2017 was as follows (Dollars in thousands):

[0001032975-18-000037:mdna:98]
|  |  | Three Months EndedJune 30, |
|  |  | 2018 |  | 2017 |
| Net sales |  | $ | 608,480 |  |  | $ | 529,946 |  |
| Gross profit |  | $ | 223,937 |  |  | $ | 193,668 |  |
| Gross margin |  | 36.8 | % |  | 36.5 | % |

[0001032975-18-000037:mdna:99]
[same as prior period, unchanged from 0001032975-18-000007:mdna:104]

[0001032975-18-000037:mdna:100]
.

[0001032975-18-000037:mdna:101]
[same as prior period, unchanged from 0001032975-18-000007:mdna:107]

[0001032975-18-000037:mdna:102]
Operating expenses for the three months ended June 30, 2018 and 2017 were as follows (Dollars in thousands):

[0001032975-18-000037:mdna:103]
|  |  | Three Months EndedJune 30, |
|  |  | 2018 |  | 2017 |  |
| Marketing and selling |  | $ | 114,584 |  |  | $ | 102,378 |  |  |
| % of net sales |  | 18.8 | % |  | 19.3 | % |  |
| Research and development |  | 38,987 |  |  | 35,099 |  |  |
| % of net sales |  | 6.4 | % |  | 6.6 | % |  |
| General and administrative |  | 25,473 |  |  | 25,409 |  |  |
| % of net sales |  | 4.2 | % |  | 4.8 | % |  |
| Amortization of intangible assets and acquisition-related costs |  | 2,521 |  |  | 1,390 |  |  |
| % of net sales |  | 0.4 | % |  | 0.3 | % |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | (1,978 | ) |  |
| % of net sales |  | — | % |  | (0.4 | )% |  |
| Restructuring charges (credits), net |  | 9,921 |  |  | (55 | ) |  |
| % of net sales |  | 1.6 | % |  | — | % |  |
| Total operating expenses |  | $ | 191,486 |  |  | $ | 162,243 |  |  |
| % of net sales |  | 31.5 | % |  | 30.6 | % |  |

[0001032975-18-000037:mdna:104]
[same as prior period, unchanged from 0001032975-18-000007:mdna:112]

[0001032975-18-000037:mdna:105]
[same as prior period, unchanged from 0001032975-18-000007:mdna:113]

[0001032975-18-000037:mdna:106]
During the three months ended June 30, 2018, marketing and selling expenses increased $12.2 million compared to the same period of the prior fiscal year. The increase was primarily driven by $11.1 million higher personal-related costs due to  increased variable compensation linked to stronger performance during the first quarter of fiscal year 2019 and increased headcount to expand and support our advertising and marketing efforts for our new products resulting from past business acquisitions.

[0001032975-18-000037:mdna:107]
[same as prior period, unchanged from 0001032975-18-000007:mdna:117]

[0001032975-18-000037:mdna:108]
[same as prior period, unchanged from 0001032975-18-000007:mdna:118]

[0001032975-18-000037:mdna:109]
During the three months ended June 30, 2018, research and development expenses increased $3.9 million compared to the same period in the prior fiscal year. The increase was primarily driven by $2.8 million higher personnel-related costs due to increased headcount from business acquisitions and increased variable compensation linked to stronger performance during the first quarter of fiscal year 2019.

[0001032975-18-000037:mdna:110]
[same as prior period, unchanged from 0001032975-18-000007:mdna:121]

[0001032975-18-000037:mdna:111]
[same as prior period, unchanged from 0001032975-18-000007:mdna:122]

[0001032975-18-000037:mdna:112]
During the three months ended June 30, 2018, general and administrative expenses remained relatively flat, compared to the same period in the prior fiscal year. Higher personnel-related costs were partially offset slightly by a reduction in our external consulting expenses.

[0001032975-18-000037:mdna:113]
[same as prior period, unchanged from 0001032975-18-000007:mdna:124]

[0001032975-18-000037:mdna:114]
Amortization of intangibles and acquisition-related costs during the three months ended June 30, 2018 and 2017 were as follows (in thousands):

[0001032975-18-000037:mdna:115]
|  |  | Three Months EndedJune 30, |
|  |  | 2018 |  | 2017 |
| Amortization of intangible assets |  | $ | 2,521 |  |  | $ | 1,089 |  |
| Acquisition-related costs |  | — |  |  | 301 |  |
| Total |  | $ | 2,521 |  |  | $ | 1,390 |  |

[0001032975-18-000037:mdna:116]
Amortization of intangible assets consists of amortization of acquired intangible assets, including customer relationships and trade names. The increase in amortization of intangible assets during the three months ended June 30, 2018 compared with the same period of the prior fiscal year was primarily driven by the acquisition of ASTRO in the second quarter of fiscal year 2018. Acquisition-related costs include legal expense, due diligence costs, and other professional costs incurred for business acquisitions.

[0001032975-18-000037:mdna:117]
[same as prior period, unchanged from 0001032975-18-000007:mdna:128]

[0001032975-18-000037:mdna:118]
There was no contingent consideration for business acquisition during the three months ended June 30, 2018. The change in fair value of contingent consideration for the three months ended June 30, 2017 was primarily due to lower-than-expected net sales of Jaybird products, partially offset by the change in the time value of money.

[0001032975-18-000037:mdna:119]
Restructuring Charges

[0001032975-18-000037:mdna:120]
During the first quarter of fiscal year 2019, we implemented a restructuring plan to streamline and realign our overall organizational structure and reallocate resources to support the long-term growth opportunities. Subsequent to quarter end, our Board of Directors approved to allow additional costs under this restructuring plan with total pre-tax charges of approximately $10 million to $15 million in the current fiscal year, of which $9.9 million was recognized during the first quarter of fiscal year 2019. The total charges consisted of cash severance and other personnel costs and are presented as restructuring charges in the condensed consolidated statements of operations.

[0001032975-18-000037:mdna:121]
The following table summarizes restructuring related activities during the three months ended June 30, 2018 (in thousands):

[0001032975-18-000037:mdna:122]
|  |  | TerminationBenefits |
| Accrual balance at March 31, 2018 |  | $ | — |  |
| Charges |  | 9,921 |  |
| Cash payments |  | (2,014 | ) |
| Accrual balance at June 30, 2018 |  | $ | 7,907 |  |

[0001032975-18-000037:mdna:123]
Benefit from Income Taxes

[0001032975-18-000037:mdna:124]
The benefit from income taxes and effective tax rates for the three months ended June 30, 2018 and 2017 were as follows (Dollars in thousands):

[0001032975-18-000037:mdna:125]
|  |  | Three Months EndedJune 30, |
|  |  | 2018 |  | 2017 |
| Benefit from income taxes |  | $ | (5,217 | ) |  | $ | (5,436 | ) |
| Effective income tax rate |  | (15.7 | )% |  | (17.2 | )% |

[0001032975-18-000037:mdna:126]
We have not adjusted the net provisional charge from remeasuring deferred tax assets related to the Tax Act in the United States in fiscal year 2018.  We will continue to refine the estimate based on ongoing analysis and available information and interpretations through the third quarter of fiscal year 2019.

[0001032975-18-000037:mdna:127]
The change in the effective income tax rate for the three months ended June 30, 2018, compared to the three months ended June 30, 2017, is primarily due to the mix of income and losses in the various tax jurisdictions which we operate and less excess tax benefits recognized in the United States in the three months ended June 30, 2018.  We recognized excess tax benefits of $8.3 million at 21% federal corporate income tax rate post the Tax Act in the three months ended June 30, 2018.  In the same period in fiscal year 2018, we recognized $9.9 million of excess tax benefits at 35% federal corporate income tax rate, offset by valuation allowance of $1.3 million for federal tax credit carryforwards after adoption of ASU 2016-09. In the three months ended June 30, 2018 and June 30, 2017, there was a discrete tax benefit of $0.9 million and $0.7 million, respectively, from the reversal of uncertain tax positions from the expiration of statutes of limitations.

[0001032975-18-000037:mdna:128]
As of June 30, 2018 and March 31, 2018, the total amount of unrecognized tax benefits due to uncertain tax positions was $68.5 million and $69.1 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-18-000037:mdna:129]
[same as prior period, unchanged from 0001032975-18-000007:mdna:137]

[0001032975-18-000037:mdna:130]
[same as prior period, unchanged from 0001032975-18-000007:mdna:138]

[0001032975-18-000037:mdna:131]
As of June 30, 2018, we had cash and cash equivalents of $604.1 million, compared to $641.9 million as of March 31, 2018, of which 66% is held in Switzerland, 15% is held in Hong Kong and China, 8% in is held in UK and 5% is held in Germany as of June 30, 2018. We do not expect to incur any material adverse tax impact except for what has been recognized, or be significantly inhibited by any country in which we do business from the repatriation of funds to Switzerland, our home domicile.

[0001032975-18-000037:mdna:132]
The decrease in cash and cash equivalents was primarily due to purchases of property, plant and equipment, tax withholdings related to settlements of restricted stock units and the purchases of our shares, partially offset by

[0001032975-18-000037:mdna:133]
net cash provided by operating activities.

[0001032975-18-000037:mdna:134]
As of June 30, 2018, our working capital was $596.7 million, compared to $597.4 million as of March 31, 2018. Our working capital increased compared to $553.3 million as of June 30, 2017, which was primarily driven by higher cash and cash equivalents, accounts receivable, net, partially offset by higher accounts payable and higher accruals.

[0001032975-18-000037:mdna:135]
We had several uncommitted, unsecured bank lines of credit aggregating $81.8 million as of June 30, 2018. There are no financial covenants under these lines of credit with which we must comply. As of June 30, 2018, we had outstanding bank guarantees of $20.9 million under these lines of credit.

[0001032975-18-000037:mdna:136]
[same as prior period, unchanged from 0001032975-18-000007:mdna:144]

[0001032975-18-000037:mdna:137]
|  |  | Three Months EndedJune 30, |
|  |  | 2018 |  | 2017 |
| Net cash provided by (used in) operating activities |  | $ | 12,282 |  |  | $ | (883 | ) |
| Net cash used in investing activities |  | (8,845 | ) |  | (10,357 | ) |
| Net cash used in financing activities |  | (33,959 | ) |  | (9,738 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  | (7,309 | ) |  | 1,102 |  |
| Net decrease in cash and cash equivalents |  | $ | (37,831 | ) |  | $ | (19,876 | ) |

[0001032975-18-000037:mdna:138]
The following table presents selected financial information and statistics as of June 30, 2018 and 2017 (Dollars in thousands):

[0001032975-18-000037:mdna:139]
|  |  | Three Months EndedJune 30, |
|  |  | 2018 |  | 2017 |
| Accounts receivable, net |  | $ | 385,546 |  |  | $ | 221,340 |  |
| Accounts payable |  | $ | 343,680 |  |  | $ | 312,722 |  |
| Inventories |  | $ | 272,662 |  |  | $ | 279,405 |  |
| Days sales in accounts receivable (“DSO”) (Days) (1) |  | 57 |  |  | 38 |  |
| Days accounts payable outstanding (“DPO”) (Days) (2) |  | 80 |  |  | 84 |  |
| Inventory turnover (“ITO”) (x)(3) |  | 5.6 |  |  | 4.8 |  |

[0001032975-18-000037:mdna:140]
[same as prior period, unchanged from 0001032975-18-000007:mdna:148]

[0001032975-18-000037:mdna:141]
[same as prior period, unchanged from 0001032975-18-000007:mdna:149]

[0001032975-18-000037:mdna:142]
[same as prior period, unchanged from 0001032975-18-000007:mdna:150]

[0001032975-18-000037:mdna:143]
DSO for the three months ended June 30, 2018 increased 19 days to 57 days, as compared 38 days for the same period of the prior fiscal year. The adoption of Topic 606, negatively impacted our DSO for the three months ended June 30, 2018 by 17 days, mainly as a result of changes in the balance sheet presentation of certain reserve balances previously shown net within accounts receivable which are now presented as liabilities. The adoption of Topic 606 did not have did not have an impact over the total cash flows from operating, investing, or financing activities. Refer to Note 1 to the condensed consolidated financial statements for the details of the adoption impact of Topic 606. Timing of sales and customer payments also drove the increase in DSO.

[0001032975-18-000037:mdna:144]
DPO for the three months ended June 30, 2018 decreased four days, compared to the same period of the prior fiscal year, primarily due to the timing of purchases and related payments.

[0001032975-18-000037:mdna:145]
ITO for the three months ended June 30, 2018 was higher, compared to the same period of the prior fiscal year. The increase in inventories compared with June 30, 2017 was primarily driven by higher net sales while inventory level decreased.

[0001032975-18-000037:mdna:146]
[same as prior period, unchanged from 0001032975-18-000007:mdna:154]

[0001032975-18-000037:mdna:147]
During the three months ended June 30, 2018, we generated $12.3 million cash in operating activities. Our main sources of operating cash flows were from net income after adding back non-cash expenses of depreciation, amortization, and share-based compensation expense, and from in operating assets and liabilities. The increase in accounts receivable, net, excluding the impact from the adoption of Topic 606 was primarily due to timing of sales and customer payments, and the increase in accounts payable was primarily driven by the higher inventory purchases.

[0001032975-18-000037:mdna:148]
Net cash used in investing activities was $8.8 million, primarily due to $8.7 million of purchases of property, plant and equipment.

[0001032975-18-000037:mdna:149]
Our expenditures for property, plant and equipment during the three months ended June 30, 2018 decreased by $1.3 million, compared to the same period of the prior fiscal year, mainly due to the lower amount of tooling purchases and lower infrastructure expenditure.

[0001032975-18-000037:mdna:150]
Net cash used in financing activities was $34.0 million, primarily for $10.0 million repurchases of our registered shares, $25.1 million tax withholdings related to net share settlements of restricted stock units partially offset by $1.1 million in proceeds received from the exercises of stock options.

[0001032975-18-000037:mdna:151]
During the three months ended June 30, 2018, there was a $7.3 million loss of currency exchange rate effect on cash and cash equivalents, compared to a gain of $1.1 million during the same period of the prior fiscal year. The loss from currency exchange effect during the three months ended June 30, 2018 was primarily due to the weakening of the Euro, Brazilian Real and Japanese Yen against the U.S. Dollar by 5%, 14% and 4%, respectively, during the period. The gain from currency translation exchange effect during the three months ended June 30, 2017 was primarily due to the strengthening of the Euro against the U.S. Dollar by 4% during the period.

[0001032975-18-000037:mdna:152]
[same as prior period, unchanged from 0001032975-18-000007:mdna:161]

[0001032975-18-000037:mdna:153]
[same as prior period, unchanged from 0001032975-18-000007:mdna:162]

[0001032975-18-000037:mdna:154]
In May 2018, the Board of Directors recommended that the Company pay CHF110.7 million ($115.7 million based on the exchange rate on March 31, 2018) in cash dividends for fiscal year 2018. In fiscal year 2018, we paid a cash dividend of CHF100.0 million (U.S. Dollar amount of $104.2 million) out of retained earnings. During fiscal year 2017, we paid a cash dividend of CHF 90.2 million (U.S. Dollar amount of $93.1 million) out of retained earnings. During fiscal year 2016, we paid a cash dividend of CHF 83.1 million (U.S. Dollar amount of $85.9 million) out of retained earnings.

[0001032975-18-000037:mdna:155]
In March 2017, our Board of Directors approved another share buyback program, which authorizes us to purchase up to $250.0 million of our outstanding shares, following the expiration date of our 2014 buyback program. The new program was approved by the Swiss Takeover Board in May 2017. Although we enter into trading plans for systematic repurchases (e.g., 10b5-1 trading plans) from time to time, our share buyback program provides us with the opportunity to make opportunistic repurchases during periods of favorable market conditions and is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Opportunistic purchases may be started or stopped at any time without prior notice depending on market conditions and other factors. As of June 30, 2018, $209.9 million is still available for repurchase under the 2017 buyback program.

[0001032975-18-000037:mdna:156]
The annual bonus is paid in the first quarter of the following fiscal year, and the operating cash flow for that period is negatively affected as a result.

[0001032975-18-000037:mdna:157]
[same as prior period, unchanged from 0001032975-18-000007:mdna:167]

[0001032975-18-000037:mdna:158]
[same as prior period, unchanged from 0001032975-18-000007:mdna:168]

[0001032975-18-000037:mdna:159]
[same as prior period, unchanged from 0001032975-18-000007:mdna:169]

[0001032975-18-000037:mdna:160]
[same as prior period, unchanged from 0001032975-18-000007:mdna:143]

[0001032975-18-000037:mdna:161]
[same as prior period, unchanged from 0001032975-18-000007:mdna:170]

[0001032975-18-000037:mdna:162]
As of June 30, 2018, we had non-cancelable purchase commitments for inventory purchases made in the normal course of business to original design manufacturers, contract manufacturers and other suppliers, the majority of which are expected to be fulfilled within the next 12 months. Non-cancelable purchase commitments for capital expenditures primarily relate to commitments for tooling for new and existing products, computer hardware, leasehold and improvements. We expect to continue making capital expenditures in the future to support product development activities and ongoing and expanded operations. Although open purchase commitments are considered enforceable and legally binding, the terms generally allow us to reschedule or adjust our requirements based on business needs prior to delivery of goods or performance of services.

[0001032975-18-000037:mdna:163]
[same as prior period, unchanged from 0001032975-18-000007:mdna:172]

[0001032975-18-000037:mdna:164]
For further detail about our contractual obligations and commitments, refer to our Annual Report on Form 10-K for the fiscal year ended March 31, 2018.

[0001032975-18-000037:mdna:165]
[same as prior period, unchanged from 0001032975-18-000007:mdna:174]

[0001032975-18-000037:mdna:166]
[same as prior period, unchanged from 0001032975-18-000007:mdna:175]

[0001032975-18-000037:mdna:167]
[same as prior period, unchanged from 0001032975-18-000007:mdna:176]

[0001032975-18-000037:mdna:168]
Logitech Europe S.A., one of our wholly-owned subsidiaries, guaranteed payments of two third-party contract manufacturers' purchase obligations. As of June 30, 2018, the maximum amount of this guarantee was $3.8 million, of which $1.2 million of guaranteed purchase obligations were outstanding.

[0001032975-18-000037:mdna:169]
[same as prior period, unchanged from 0001032975-18-000007:mdna:178]

[0001032975-18-000037:mdna:170]
We indemnify certain suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of June 30, 2018, no amounts have been accrued for indemnification provisions. We do not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under our indemnification arrangements.

[0001032975-18-000037:mdna:171]
[same as prior period, unchanged from 0001032975-18-000007:mdna:180]

[0001032975-18-000037:mdna:172]
The stock purchase agreement that we entered into in connection with the investment by three venture capital firms in Lifesize contains representations, warranties and covenants of Logitech and Lifesize to the Investors. Subject to certain limitations, we have agreed to indemnify the Investors and certain persons related to the Investors for certain losses resulting from breaches of or inaccuracies in such representations, warranties and covenants as well as certain other obligations, including third-party expenses, restructuring costs and pre-closing tax obligations of Lifesize.

[0001032975-18-000037:mdna:173]
Legal Proceedings

[0001032975-18-000037:mdna:174]
From time to time we are involved in claims and legal proceedings that arise in the ordinary course of our business. We are currently subject to several such claims and a small number of legal proceedings. We believe that these matters lack merit and we intend to vigorously defend against them. Based on currently available information, we do not believe that resolution of pending matters will have a material adverse effect on our financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that our defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on our business, financial condition, cash flows and results of operations in a particular period. Any claims or proceedings against us, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect our business.

[0001032975-18-000037:mdna:175]
40
