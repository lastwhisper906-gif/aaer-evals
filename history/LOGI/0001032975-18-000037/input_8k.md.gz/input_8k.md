# LOGI 8-K — 0001032975-18-000035 filed 2018-07-31

## item codes, every 8-K on or before 2018-08-02

- 2018-07-31 0001032975-18-000035 — 1.01, 2.02, 2.05, 7.01, 9.01
- 2018-06-27 0001032975-18-000020 — 5.02
- 2018-05-03 0001032975-18-000013 — 2.02, 5.02, 9.01
- 2018-01-23 0001032975-18-000005 — 2.02, 9.01
- 2017-10-24 0001032975-17-000043 — 2.02, 9.01
- 2017-09-18 0001032975-17-000040 — 5.07, 8.01
- 2017-07-25 0001032975-17-000028 — 2.02, 9.01
- 2017-07-12 0001032975-17-000022 — 1.01
- 2017-04-26 0001032975-17-000012 — 2.02, 9.01
- 2017-01-25 0001032975-17-000002 — 2.02, 9.01
- 2016-10-26 0001032975-16-000103 — 2.02, 9.01
- 2016-09-13 0001032975-16-000101 — 5.07, 8.01
- 2016-07-28 0001032975-16-000092 — 2.02, 9.01
- 2016-06-30 0001032975-16-000087 — 5.02
- 2016-04-28 0001032975-16-000077 — 2.02, 9.01
- 2016-04-14 0001032975-16-000073 — 1.01, 7.01, 9.01
- 2016-01-21 0001032975-16-000064 — 2.02, 9.01
- 2016-01-04 0001032975-16-000061 — 1.01, 2.01, 9.01
- 2015-12-23 0001032975-15-000059 — 5.02
- 2015-10-22 0001032975-15-000047 — 2.02, 9.01
- 2015-09-11 0001032975-15-000044 — 5.07, 8.01
- 2015-07-24 0001032975-15-000034 — 2.05 — amendment of 0001032975-15-000030
- 2015-07-23 0001032975-15-000030 — 2.02, 9.01
- 2015-06-25 0001032975-15-000025 — 5.02
- 2015-05-14 0001032975-15-000011 — 8.01, 9.01
- 2015-04-23 0001032975-15-000008 — 2.02, 2.05
- 2015-01-22 0001628280-15-000191 — 2.02, 8.01
- 2014-12-23 0001193125-14-450908 — 5.02, 5.07, 8.01
- 2014-11-25 0001193125-14-425233 — 3.01
- 2014-11-13 0001193125-14-411303 — 4.01, 9.01
- 2014-10-23 0001104659-14-073164 — 2.02, 9.01
- 2014-09-04 0001193125-14-331214 — 4.02, 9.01
- 2014-08-18 0001193125-14-313346 — 3.01, 9.01
- 2014-07-24 0001104659-14-053065 — 2.02, 9.01
- 2014-06-05 0001193125-14-226177 — 3.01, 9.01
- 2014-05-22 0001193125-14-208777 — 8.01, 9.01
- 2014-04-24 0001104659-14-029650 — 2.02, 9.01
- 2014-01-23 0001104659-14-003619 — 2.02, 9.01
- 2013-10-24 0001104659-13-077404 — 2.02, 9.01
- 2013-09-09 0001193125-13-361441 — 5.02, 5.07, 8.01, 9.01
- 2013-09-06 0001193125-13-359930 — 5.02, 9.01
- 2013-08-02 0001193125-13-317343 — 5.02
- 2013-07-25 0001104659-13-056372 — 2.02, 9.01
- 2013-06-28 0001193125-13-277394 — 5.02, 9.01
- 2013-06-20 0001193125-13-265914 — 8.01, 9.01
- 2013-04-25 0001104659-13-032570 — 2.02, 9.01
- 2013-04-17 0001193125-13-158923 — 5.02, 9.01
- 2013-03-01 0001193125-13-085804 — 2.05
- 2013-01-24 0001104659-13-004214 — 2.02, 9.01
- 2013-01-02 0001193125-13-000058 — 5.02
- 2012-10-25 0001104659-12-070966 — 2.02, 9.01
- 2012-09-11 0001193125-12-388070 — 5.02, 5.07, 8.01, 9.01
- 2012-08-22 0001193125-12-364167 — 5.02, 8.01, 9.01
- 2012-07-26 0001104659-12-051084 — 2.02, 9.01
- 2012-06-08 0001193125-12-264132 — 2.05, 9.01 — amendment, the index does not say of what
- 2012-04-26 0001193125-12-183657 — 5.02, 9.01
- 2012-04-26 0001104659-12-028470 — 2.02, 2.05, 9.01
- 2012-03-15 0001193125-12-115954 — 5.02, 9.01
- 2012-01-26 0001104659-12-004014 — 2.02, 9.01
- 2012-01-04 0001193125-12-002212 — 1.01, 2.03, 9.01
- 2011-10-27 0001104659-11-058150 — 2.02, 9.01
- 2011-09-12 0001193125-11-245931 — 5.07
- 2011-07-28 0001193125-11-200929 — 5.02, 9.01
- 2011-07-28 0001193125-11-199704 — 2.02, 9.01
- 2011-04-28 0001193125-11-112669 — 2.02, 9.01
- 2011-03-24 0001193125-11-076483 — 5.02, 9.01
- 2011-01-27 0001032975-11-000003 — 9.01
- 2010-10-28 0001032975-10-000032 — 9.01
- 2010-09-13 0001032975-10-000022 — 5.07
- 2010-07-29 0001032975-10-000010 — 2.02, 9.01
- 2010-06-10 0001193125-10-136877 — 5.02, 9.01
- 2010-05-03 0001193125-10-104337 — 5.02
- 2010-04-29 0001032975-10-000008 — 2.02, 9.01
- 2010-02-19 0001032975-10-000006 — 9.01 — amendment of 0001193125-09-252416
- 2010-01-21 0001032975-10-000002 — 2.02, 9.01
- 2009-12-14 0001193125-09-252416 — 2.01, 9.01
- 2009-11-17 0001032975-09-000023 — 1.01
- 2009-10-22 0001032975-09-000018 — 9.01
- 2009-09-22 0001193125-09-195545 — 5.02, 9.01
- 2009-09-03 0001032975-09-000013 — 8.01
- 2009-07-23 0001140361-09-016802 — 2.02, 9.01
- 2009-06-01 0001193125-09-122550 — 5.02
- 2009-04-23 0001193125-09-085054 — 2.02, 9.01
- 2009-04-02 0001193125-09-071272 — 5.02, 9.01
- 2009-01-20 0001193125-09-008454 — 2.05 — amendment of 0001193125-09-002609
- 2009-01-20 0001193125-09-007902 — 2.02, 9.01
- 2009-01-07 0001193125-09-002609 — 2.05, 9.01
- 2009-01-07 0001193125-09-002370 — 5.02, 9.01
- 2008-12-09 0001193125-08-250543 — 5.02, 9.01
- 2008-10-21 0001193125-08-213212 — 2.02, 9.01
- 2008-07-22 0001193125-08-154721 — 2.02, 9.01
- 2008-06-24 0001193125-08-139163 — 5.03, 9.01
- 2008-05-13 0001193125-08-113263 — 5.02, 9.01
- 2008-04-22 0001193125-08-086176 — 2.02, 9.01

## late-filing notifications on or before 2018-08-02

- 2015-06-02 0001032975-15-000020 — NT 10-K, for the period ended 2015-03-31
- 2014-11-06 0001193125-14-401306 — NT 10-Q, for the period ended 2014-09-30
- 2014-07-24 0001193125-14-277575 — NT 10-Q, for the period ended 2014-06-30
- 2014-05-22 0001193125-14-208712 — NT 10-K, for the period ended 2014-03-31
- 2009-08-06 0001032975-09-000006 — NT 10-Q, for the period ended 2009-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001032975-18-000035:8k_2_02:1]
EX-99.1
2
exhibit991q1fy19.htm
EXHIBIT 99.1

[0001032975-18-000035:8k_2_02:2]
Exhibit

[0001032975-18-000035:8k_2_02:3]
Exhibit 99.1

[0001032975-18-000035:8k_2_02:4]
Editorial Contacts:

[0001032975-18-000035:8k_2_02:5]
Ben Lu, Vice President, Investor Relations - USA (510) 713-5568

[0001032975-18-000035:8k_2_02:6]
Krista Todd, Vice President, Communications - USA (510) 713-5834

[0001032975-18-000035:8k_2_02:7]
Ben Starkie, Corporate Communications - Europe +41 (0) 79-292-3499

[0001032975-18-000035:8k_2_02:8]
Logitech Beats Expectations with Sales Up 15% and Raises Outlook

[0001032975-18-000035:8k_2_02:9]
NEWARK, Calif. - July 30, 2018 and LAUSANNE, Switzerland, July 31, 2018 - Logitech International (SIX: LOGN) (Nasdaq: LOGI) today announced financial results for the first quarter of Fiscal Year 2019.

[0001032975-18-000035:8k_2_02:10]
| • | Q1 sales were $608 million, up 15 percent in US dollars and 12 percent in constant currency, compared to Q1 of the prior year. |

[0001032975-18-000035:8k_2_02:11]
| • | Q1 GAAP operating income reached $32 million, compared to $31 million in the same quarter a year ago. Q1 GAAP earnings per share (EPS) amounted to $0.23, compared to $0.22 in the same quarter a year ago. GAAP operating income was impacted by a $10 million restructuring charge related to the realignment of resources for growth. |

[0001032975-18-000035:8k_2_02:12]
| • | Q1 non-GAAP operating income grew 41 percent to $61 million, compared to $43 million in the same quarter a year ago. Q1 non-GAAP EPS grew 42 percent to $0.34, versus $0.24 in the same quarter a year ago. |

[0001032975-18-000035:8k_2_02:13]
“We’ve delivered a great start to the year and are raising our guidance,” said Bracken Darrell, Logitech president and chief executive officer. “The diversity of our portfolio and strength of our innovation engine are working. Our Gaming and Video Collaboration categories both grew more than 60% in Q1. But as we always say, ‘you’re only as good as what you’re doing in the future.’ With that in mind, we’re playing offense.  While innovation investments continue to advance and our business is strong, we are realigning our organization to put more firepower against growth opportunities. We also agreed to acquire Blue Microphones, a leading player in the microphone space.”

[0001032975-18-000035:8k_2_02:14]
Investment Through Acquisition

[0001032975-18-000035:8k_2_02:15]
Logitech agreed to acquire Blue Microphones, based in Southern California, for approximately $117 million in cash, assuming breakeven net working capital at close. Blue Microphones is a leader in studio-quality microphones for professionals and consumers. The Blue Microphones acquisition is a new adjacent opportunity for Logitech, consistent with the Company’s approach to M&A. The transaction, which is expected to close by the end of August 2018, should contribute approximately one point of sales growth in Fiscal Year 2019.

[0001032975-18-000035:8k_2_02:16]
Investment in Capabilities

[0001032975-18-000035:8k_2_02:17]
During Q1, Logitech realigned resources to support the continued evolution of its capabilities, portfolio and growth opportunities. The Company has delivered consistent momentum in growth and profitability these past five years and, with this realignment, took proactive steps to prepare for its next five years. As

[0001032975-18-000035:8k_2_02:18]
a result, the Company booked a restructuring charge of approximately $10 million this quarter. These actions are designed to reallocate resources and invest in other capabilities and long-term growth opportunities.

[0001032975-18-000035:8k_2_02:19]
Outlook

[0001032975-18-000035:8k_2_02:20]
Based on the strong performance in Q1 and the acquisition of Blue Microphones, Logitech raised its Fiscal Year 2019 outlook to 9 to 11 percent sales growth in constant currency, up from its previous outlook of high single-digit sales growth in constant currency. The Company also increased its non-GAAP operating income outlook for Fiscal Year 2019 to a range of $325 million to $335 million, up from its prior range of $310 million to $320 million in non-GAAP operating income.

[0001032975-18-000035:8k_2_02:21]
Prepared Remarks Available Online

[0001032975-18-000035:8k_2_02:22]
Logitech has made its prepared written remarks for the financial results teleconference available online on the Logitech corporate website at http://ir.logitech.com.

[0001032975-18-000035:8k_2_02:23]
Financial Results Teleconference and Webcast

[0001032975-18-000035:8k_2_02:24]
Logitech will hold a financial results teleconference to discuss the results for Q1 FY 2019 on

[0001032975-18-000035:8k_2_02:25]
Tuesday, July 31, 2018 at 8:30 a.m. Eastern Daylight Time and 2:30 p.m. Central European Summer Time. A live webcast of the call will be available on the Logitech corporate website at http://ir.logitech.com.

[0001032975-18-000035:8k_2_02:26]
Use of Non-GAAP Financial Information and Constant Currency

[0001032975-18-000035:8k_2_02:27]
To facilitate comparisons to Logitech’s historical results, Logitech has included non-GAAP adjusted measures, which exclude share-based compensation expense, amortization of intangible assets, purchase accounting effect on inventory, acquisition-related costs, change in fair value of contingent consideration for business acquisition, restructuring charges (credits), gain (loss) on investments in privately held companies, non-GAAP income tax adjustment, and other items detailed under “Supplemental Financial Information” after the tables below. Logitech also presents percentage sales growth in constant currency to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales. Logitech believes this information, used together with the GAAP financial information, will help investors to evaluate its current period performance and trends in its business. With respect to the Company’s outlook for non-GAAP operating income, most of these excluded amounts pertain to events that have not yet occurred and are not currently possible to estimate with a reasonable degree of accuracy. Therefore, no reconciliation to the GAAP amounts has been provided for Fiscal Year 2019.

[0001032975-18-000035:8k_2_02:28]
About Logitech

[0001032975-18-000035:8k_2_02:29]
Logitech designs products that have an everyday place in people's lives, connecting them to the digital experiences they care about. More than 35 years ago, Logitech started connecting people through

[0001032975-18-000035:8k_2_02:30]
computers, and now it’s a multi-brand company designing products that bring people together through music, gaming, video and computing. Brands of Logitech include Logitech, Ultimate Ears, Jaybird, Logitech G and ASTRO Gaming. Founded in 1981, and headquartered in Lausanne, Switzerland, Logitech International is a Swiss public company listed on the SIX Swiss Exchange (LOGN) and on the Nasdaq Global Select Market (LOGI). Find Logitech at www.logitech.com, the company blog or @Logitech.

[0001032975-18-000035:8k_2_02:31]
# # #

[0001032975-18-000035:8k_2_02:32]
Note that unless noted otherwise, comparisons are year over year.

[0001032975-18-000035:8k_2_02:33]
Logitech and other Logitech marks are trademarks or registered trademarks of Logitech Europe S.A and/or its affiliates in the U.S. and other countries.  All other trademarks are the property of their respective owners. For more information about Logitech and its products, visit the company’s website at www.logitech.com.

[0001032975-18-000035:8k_2_02:34]
(LOGIIR)

[0001032975-18-000035:8k_2_02:35]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |
| PRELIMINARY RESULTS * |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |
|  |  | Three Months Ended |
|  |  | June 30, |
| GAAP CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  | 2018 |  | 2017 |
| Net sales (A) |  | $ | 608,480 |  |  | $ | 529,946 |  |
| Cost of goods sold |  | 382,171 |  |  | 334,774 |  |
| Amortization of intangible assets and purchase accounting effect on inventory |  | 2,372 |  |  | 1,504 |  |
| Gross profit |  | 223,937 |  |  | 193,668 |  |
| Operating expenses: |  |  |  |  |
| Marketing and selling |  | 114,584 |  |  | 102,378 |  |
| Research and development |  | 38,987 |  |  | 35,099 |  |
| General and administrative |  | 25,473 |  |  | 25,409 |  |
| Amortization of intangible assets and acquisition-related costs |  | 2,521 |  |  | 1,390 |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | (1,978 | ) |
| Restructuring charges (credits), net |  | 9,921 |  |  | (55 | ) |
| Total operating expenses |  | 191,486 |  |  | 162,243 |  |
| Operating income |  | 32,451 |  |  | 31,425 |  |
| Interest income |  | 2,369 |  |  | 1,175 |  |
| Other expense, net |  | (1,571 | ) |  | (1,029 | ) |
| Income before income taxes |  | 33,249 |  |  | 31,571 |  |
| Benefit from income taxes |  | (5,217 | ) |  | (5,436 | ) |
| Net income |  | $ | 38,466 |  |  | $ | 37,007 |  |
| Net income per share: |  |  |  |  |  |  |
| Basic |  | $ | 0.23 |  |  | $ | 0.23 |  |
| Diluted |  | $ | 0.23 |  |  | $ | 0.22 |  |
| Weighted average shares used to compute net income per share: |  |  |  |  |  |  |
| Basic |  | 165,317 |  |  | 163,407 |  |
| Diluted |  | 168,756 |  |  | 168,339 |  |

[0001032975-18-000035:8k_2_02:36]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |
| PRELIMINARY RESULTS * |
| (In thousands) - unaudited |  |  |  |  |
|  |  | June 30, 2018 |  | March 31,2018 |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 604,116 |  |  | $ | 641,947 |  |
| Accounts receivable, net (A) |  | 385,546 |  |  | 214,885 |  |
| Inventories |  | 272,662 |  |  | 259,906 |  |
| Other current assets (A) |  | 62,542 |  |  | 56,362 |  |
| Total current assets |  | 1,324,866 |  |  | 1,173,100 |  |
| Non-current assets: |  |  |  |  |  |  |
| Property, plant and equipment, net |  | 84,721 |  |  | 86,304 |  |
| Goodwill |  | 275,418 |  |  | 275,451 |  |
| Other intangible assets, net |  | 82,719 |  |  | 87,547 |  |
| Other assets |  | 131,761 |  |  | 120,755 |  |
| Total assets |  | $ | 1,899,485 |  |  | $ | 1,743,157 |  |
| Current liabilities: |  |  |  |  |  |  |
| Accounts payable |  | $ | 343,680 |  |  | $ | 293,988 |  |
| Accrued and other current liabilities (A) |  | 384,497 |  |  | 281,732 |  |
| Total current liabilities |  | 728,177 |  |  | 575,720 |  |
| Non-current liabilities: |  |  |  |  |  |  |
| Income taxes payable |  | 33,789 |  |  | 34,956 |  |
| Other non-current liabilities |  | 82,259 |  |  | 81,924 |  |
| Total liabilities |  | 844,225 |  |  | 692,600 |  |
| Shareholders’ equity: |  |  |  |  |
| Registered shares, CHF 0.25 par value: |  | 30,148 |  |  | 30,148 |  |
| Issued and authorized shares — 173,106 at June 30 and March 31, 2018 |  |  |  |  |
| Conditionally authorized shares — 50,000 at June 30 and March 31, 2018 |  |  |  |  |
| Additional paid-in capital |  | 19,093 |  |  | 47,234 |  |
| Shares in treasury, at cost — 7,533 at June 30, 2018 and 8,527 at March 31, 2018 |  | (158,337 | ) |  | (165,686 | ) |
| Retained earnings (A) |  | 1,259,900 |  |  | 1,232,316 |  |
| Accumulated other comprehensive loss |  | (95,544 | ) |  | (93,455 | ) |
| Total shareholders’ equity |  | 1,055,260 |  |  | 1,050,557 |  |
| Total liabilities and shareholders’ equity |  | $ | 1,899,485 |  |  | $ | 1,743,157 |  |

[0001032975-18-000035:8k_2_02:37]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |
| PRELIMINARY RESULTS * |
| (In thousands) - unaudited |  |  |  |  |
|  |  | Three Months Ended |
|  |  | June 30, |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |  | 2018 |  | 2017 |
| Cash flows from operating activities: |  |  |  |  |
| Net income |  | $ | 38,466 |  |  | $ | 37,007 |  |
| Adjustments to reconcile net income to net cash provided by (used in) operating activities: |  |  |  |  |
| Depreciation |  | 10,699 |  |  | 9,148 |  |
| Amortization of intangible assets |  | 4,893 |  |  | 2,593 |  |
| Loss on investments in privately held companies |  | 13 |  |  | 259 |  |
| Share-based compensation expense |  | 13,259 |  |  | 10,705 |  |
| Deferred income taxes |  | (9,659 | ) |  | (9,879 | ) |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | (1,978 | ) |
| Other |  | 124 |  |  | (3 | ) |
| Changes in assets and liabilities, net of acquisitions: |  |  |  |  |
| Accounts receivable, net |  | (68,557 | ) |  | (35,702 | ) |
| Inventories |  | (18,200 | ) |  | (20,389 | ) |
| Other assets |  | (4,225 | ) |  | (3,088 | ) |
| Accounts payable |  | 51,188 |  |  | 38,647 |  |
| Accrued and other liabilities |  | (5,719 | ) |  | (28,203 | ) |
| Net cash provided by (used in) operating activities |  | 12,282 |  |  | (883 | ) |
| Cash flows from investing activities: |  |  |  |  |
| Purchases of property, plant and equipment |  | (8,744 | ) |  | (10,035 | ) |
| Investment in privately held companies |  | (225 | ) |  | (360 | ) |
| Acquisitions, net of cash acquired |  | (243 | ) |  | — |  |
| Purchases of trading investments |  | (2,500 | ) |  | (609 | ) |
| Proceeds from sales of trading investments |  | 2,867 |  |  | 647 |  |
| Net cash used in investing activities |  | (8,845 | ) |  | (10,357 | ) |
| Cash flows from financing activities: |  |  |  |  |
| Purchases of registered shares |  | (9,982 | ) |  | (624 | ) |
| Proceeds from exercises of stock options |  | 1,104 |  |  | 12,569 |  |
| Tax withholdings related to net share settlements of restricted stock units |  | (25,081 | ) |  | (21,683 | ) |
| Net cash used in financing activities |  | (33,959 | ) |  | (9,738 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  | (7,309 | ) |  | 1,102 |  |
| Net decrease in cash and cash equivalents |  | (37,831 | ) |  | (19,876 | ) |
| Cash and cash equivalents , beginning of the period |  | 641,947 |  |  | 547,533 |  |
| Cash and cash equivalents , end of the period |  | $ | 604,116 |  |  | $ | 527,657 |  |

[0001032975-18-000035:8k_2_02:38]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |
| PRELIMINARY RESULTS * |
| (In thousands) - unaudited |  |  |  |  |
| NET SALES |  | Three Months Ended |
|  |  | June 30, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2018 |  | 2017 |  | Change |
| Net sales by product category: |  |  |  |  |  |  |
| Pointing Devices |  | $ | 127,790 |  |  | $ | 122,074 |  |  | 5 | % |
| Keyboards & Combos |  | 128,222 |  |  | 116,113 |  |  | 10 |  |
| PC Webcams |  | 29,674 |  |  | 25,625 |  |  | 16 |  |
| Tablet & Other Accessories |  | 32,436 |  |  | 23,218 |  |  | 40 |  |
| Video Collaboration |  | 58,792 |  |  | 35,617 |  |  | 65 |  |
| Mobile Speakers |  | 34,327 |  |  | 62,918 |  |  | (45 | ) |
| Audio & Wearables |  | 52,154 |  |  | 50,202 |  |  | 4 |  |
| Gaming |  | 136,026 |  |  | 77,708 |  |  | 75 |  |
| Smart Home |  | 9,011 |  |  | 16,466 |  |  | (45 | ) |
| Other (1) |  | 48 |  |  | 5 |  |  | 860 |  |
| Total net sales |  | $ | 608,480 |  |  | $ | 529,946 |  |  | 15 |  |

[0001032975-18-000035:8k_2_02:39]
(1) Other category includes products that we currently intend to transition out of, or have already transitioned out of, because they are no longer strategic to our business.

[0001032975-18-000035:8k_2_02:40]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |
| PRELIMINARY RESULTS * |
| (In thousands, except per share amounts) - Unaudited |  |  |  |  |
| GAAP TO NON-GAAP RECONCILIATION (B) |  | Three Months Ended |
|  |  | June 30, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2018 |  | 2017 |
| Gross profit - GAAP |  | $ | 223,937 |  |  | $ | 193,668 |  |
| Share-based compensation expense |  | 1,130 |  |  | 711 |  |
| Amortization of intangible assets and purchase accounting effect on inventory |  | 2,372 |  |  | 1,504 |  |
| Gross profit - Non-GAAP |  | $ | 227,439 |  |  | $ | 195,883 |  |
| Gross margin - GAAP |  | 36.8 | % |  | 36.5 | % |
| Gross margin - Non-GAAP |  | 37.4 | % |  | 37.0 | % |
| Operating expenses - GAAP |  | $ | 191,486 |  |  | $ | 162,243 |  |
| Less: Share-based compensation expense |  | 12,129 |  |  | 9,994 |  |
| Less: Amortization of intangible assets and acquisition-related costs |  | 2,521 |  |  | 1,390 |  |
| Less: Change in fair value of contingent consideration for business acquisition |  | — |  |  | (1,978 | ) |
| Less: Restructuring charges (credits), net |  | 9,921 |  |  | (55 | ) |
| Operating expenses - Non-GAAP |  | $ | 166,915 |  |  | $ | 152,892 |  |
| % of net sales - GAAP |  | 31.5 | % |  | 30.6 | % |
| % of net sales - Non - GAAP |  | 27.4 | % |  | 28.9 | % |
| Operating income - GAAP |  | $ | 32,451 |  |  | $ | 31,425 |  |
| Share-based compensation expense |  | 13,259 |  |  | 10,705 |  |
| Amortization of intangible assets |  | 4,893 |  |  | 2,593 |  |
| Acquisition-related costs |  | — |  |  | 301 |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | (1,978 | ) |
| Restructuring (charges) credits, net |  | 9,921 |  |  | (55 | ) |
| Operating income - Non - GAAP |  | $ | 60,524 |  |  | $ | 42,991 |  |
| % of net sales - GAAP |  | 5.3 | % |  | 5.9 | % |
| % of net sales - Non - GAAP |  | 9.9 | % |  | 8.1 | % |
| Net income - GAAP |  | $ | 38,466 |  |  | $ | 37,007 |  |
| Share-based compensation expense |  | 13,259 |  |  | 10,705 |  |
| Amortization of intangible assets |  | 4,893 |  |  | 2,593 |  |
| Acquisition-related costs |  | — |  |  | 301 |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | (1,978 | ) |
| Restructuring (charges) credits, net |  | 9,921 |  |  | (55 | ) |
| Loss on investments in privately held companies |  | 13 |  |  | 259 |  |
| Non-GAAP income tax adjustment |  | (9,109 | ) |  | (9,092 | ) |
| Net income - Non - GAAP |  | $ | 57,443 |  |  | $ | 39,740 |  |
| Net income per share: |  |  |  |  |
| Diluted - GAAP |  | $ | 0.23 |  |  | $ | 0.22 |  |
| Diluted - Non - GAAP |  | $ | 0.34 |  |  | $ | 0.24 |  |
| Shares used to compute net income per share: |  |  |  |  |
| Diluted - GAAP and Non - GAAP |  | 168,756 |  |  | 168,339 |  |

[0001032975-18-000035:8k_2_02:41]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |
| PRELIMINARY RESULTS * |
| (In thousands) - unaudited |  |  |  |  |
| SHARE-BASED COMPENSATION EXPENSE |  | Three Months Ended |
|  |  | June 30, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2018 |  | 2017 |
| Share-based Compensation Expense |  |  |  |  |
| Cost of goods sold |  | $ | 1,130 |  |  | $ | 711 |  |
| Marketing and selling |  | 5,786 |  |  | 4,381 |  |
| Research and development |  | 1,549 |  |  | 1,543 |  |
| General and administrative |  | 4,794 |  |  | 4,070 |  |
| Total share-based compensation expense |  | 13,259 |  |  | 10,705 |  |
| Income tax benefit |  | (9,529 | ) |  | (11,282 | ) |
| Total share-based compensation expense, net of income tax |  | $ | 3,730 |  |  | $ | (577 | ) |

[0001032975-18-000035:8k_2_02:42]
*  Note: These preliminary results for the three months ended June 30, 2018 are subject to adjustments, including subsequent events that may occur through the date of filing our Quarterly Report on Form 10-Q.

[0001032975-18-000035:8k_2_02:43]
(A) Adoption of ASC Topic 606

[0001032975-18-000035:8k_2_02:44]
On April 1, 2018, we adopted the new revenue standards under Accounting Standards Codification ("ASC") Topic 606. The adoption of Topic 606 did not have an impact over the total cash flows from operating, investing, or financing activities. The following tables summarize the impacts of adopting Topic 606 on our condensed consolidated statements of operations and balance sheets for the three months ended or as of June 30, 2018 (in thousands):

[0001032975-18-000035:8k_2_02:45]
|  |  | As Reported |  | If Reported Under Topic 605 |  | Effect of Adoption of Topic 606 |
| Net Sales |  | $ | 608,480 |  |  | $ | 608,614 |  |  | $ | (134 | ) |
| Accounts receivable, net |  | 385,546 |  |  | 272,009 |  |  | 113,537 |  |
| Other current assets |  | 62,542 |  |  | 55,237 |  |  | 7,305 |  |
| Accrued and other current liabilities |  | 384,497 |  |  | 252,639 |  |  | 131,858 |  |
| Retained earnings |  | 1,259,900 |  |  | 1,270,916 |  |  | (11,016 | ) |

[0001032975-18-000035:8k_2_02:46]
(B) Non-GAAP Financial Measures

[0001032975-18-000035:8k_2_02:47]
To supplement our condensed consolidated financial results prepared in accordance with GAAP, we use a number of financial measures, both GAAP and non-GAAP, in analyzing and assessing our overall business performance, for making operating decisions and for forecasting and planning future periods. We consider the use of non-GAAP financial measures helpful in assessing our current financial performance, ongoing operations and prospects for the future as well as understanding financial and business trends relating to our financial condition and results of operations.

[0001032975-18-000035:8k_2_02:48]
While we use non-GAAP financial measures as a tool to enhance our understanding of certain aspects of our financial performance and to provide incremental insight into the underlying factors and trends affecting both our performance and our cash-generating potential, we do not consider these measures to be a substitute for, or superior to, the information provided by GAAP financial measures. Consistent with this approach, we believe that disclosing non-GAAP financial measures to the readers of our financial statements provides useful supplemental data that, while not a substitute for GAAP financial measures, can offer insight in the review of our financial and operational performance and enables investors to more fully understand trends in our current and future performance. In assessing our business during the quarter ended June 30, 2018 and previous periods, we excluded items in the following general categories, each of which are described below:

[0001032975-18-000035:8k_2_02:49]
Share-based compensation expenses. We believe that providing non-GAAP measures excluding share-based compensation expense, in addition to the GAAP measures, allows for a more transparent comparison of our financial results from period to period. We prepare and maintain our budgets and forecasts for future periods on a basis consistent with this non-GAAP financial measure. Further, companies use a variety of types of equity awards as well as

[0001032975-18-000035:8k_2_02:50]
a variety of methodologies, assumptions and estimates to determine share-based compensation expense. We believe that excluding share-based compensation expense enhances our ability and the ability of investors to understand the impact of non-cash share-based compensation on our operating results and to compare our results against the results of other companies.

[0001032975-18-000035:8k_2_02:51]
Amortization of intangible assets. We incur intangible asset amortization expense, primarily in connection with our acquisitions of various businesses and technologies. The amortization of purchased intangibles varies depending on the level of acquisition activity. We exclude these various charges in budgeting, planning and forecasting future periods and we believe that providing the non-GAAP measures excluding these various non-cash charges, as well as the GAAP measures, provides additional insight when comparing our gross profit,  operating expenses, and financial results from period to period.

[0001032975-18-000035:8k_2_02:52]
Purchase accounting effect on inventory. Business combination accounting principles require us to measure acquired inventory at fair value. The fair value of inventory reflects the acquired company’s cost of manufacturing plus a portion of the expected profit margin. The non-GAAP adjustment excludes the expected profit margin component that is recorded under business combination accounting principles associated with our business acquisitions. We believe the adjustment is useful to investors because such charges are not reflective of our ongoing operations.

[0001032975-18-000035:8k_2_02:53]
Acquisition-related costs and change in fair value of contingent consideration for business acquisition.  We incurred expenses and credits in connection with our acquisitions which we generally would not have otherwise incurred in the periods presented as a part of our continuing operations. Acquisition related costs include all incremental expenses incurred to effect a business combination. Fair value of contingent consideration is associated with our estimates of the value of earn-outs in connection with certain acquisitions. We believe that providing the non-GAAP measures excluding these costs and credits, as well as the GAAP measures, assists our investors because such costs are not reflective of our ongoing operating results.

[0001032975-18-000035:8k_2_02:54]
Restructuring charges (credits). These expenses are associated with re-aligning our business strategies based on current economic conditions. We have undertaken several restructuring plans in recent years. In connection with our restructuring initiatives, we incurred restructuring charges related to employee terminations, facility closures and early cancellation of certain contracts. We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges (credits) are not reflective of our ongoing operating results in the current period.

[0001032975-18-000035:8k_2_02:55]
Gain (loss) on investments in privately held companies. We recognized gain (loss) related to our investments in various privately-held companies, which varies depending on the operational and financial performance of the privately-held companies in which we invested. We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges are not reflective of our ongoing operations.

[0001032975-18-000035:8k_2_02:56]
Non-GAAP income tax adjustment.  Non-GAAP income tax adjustment primarily measures the income tax effect of non-GAAP adjustments excluded above and other events; the determination of which is based upon the nature of the underlying items, the mix of income and losses in jurisdictions and the relevant tax rates in which we operate.

[0001032975-18-000035:8k_2_02:57]
Each of the non-GAAP financial measures described above, and used in this press release, should not be considered in isolation from, or as a substitute for, a measure of financial performance prepared in accordance with GAAP. Further, investors are cautioned that there are inherent limitations associated with the use of each of these non-GAAP financial measures as an analytical tool. In particular, these non-GAAP financial measures are not based on a comprehensive set of accounting rules or principles and many of the adjustments to the GAAP financial measures reflect the exclusion of items that are recurring and may be reflected in the Company’s financial results for the foreseeable future. We compensate for these limitations by providing specific information in the reconciliation included in this press release regarding the GAAP amounts excluded from the non-GAAP financial measures. In addition, as noted above, we evaluate the non-GAAP financial measures together with the most directly comparable GAAP financial information.

[0001032975-18-000035:8k_2_02:58]
Additional Supplemental Financial Information - Constant Currency

[0001032975-18-000035:8k_2_02:59]
In addition, Logitech presents percentage sales growth in constant currency to show performance unaffected by fluctuations in currency exchange rates.  Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales.

## item 1.01 — body, verbatim

[0001032975-18-000035:8k_body:1]
ITEM 1.01 ENTRY INTO A MATERIAL DEFINITIVE AGREEMENT

[0001032975-18-000035:8k_body:2]
On July 30, 2018, Logitech Europe S.A. (the “Company”), a wholly-owned subsidiary of Logitech International S.A. (the “registrant” or “Logitech”), Blue Microphones Holding Corporation, a Delaware corporation (“Blue”), Riverside Micro-Cap Fund II, L.P., a Delaware limited partnership (“Riverside”), in its capacity as a stockholder of Blue and as representative of the Sellers (as defined below), the other stockholders of Blue listed on Exhibit A of the Stock Purchase Agreement (as defined below) (together with Riverside, the “Stockholders”), the holders of options of common stock of Blue (“Options”) listed on Exhibit B of the Stock Purchase Agreement (the “Optionholders” and, together with the Stockholders, the “Sellers”) and, for purposes of Section 10.11 of the Stock Purchase Agreement only, Logitech Inc., a California corporation and wholly-owned subsidiary of Logitech, entered into a stock purchase agreement (the “Stock Purchase Agreement”). Pursuant to the terms of the Stock Purchase Agreement, the Company will acquire all of the issued and outstanding shares of common stock of Blue in exchange for approximately $116,500,000, subject to (i) an adjustment for Blue’s estimated cash and cash equivalents at the closing of the transaction (the “Closing”), (ii) an adjustment for Blue’s estimated net working capital (which will be determined at Closing and is subject to post-Closing adjustments) and (iii) a decrease for certain transaction expenses incurred by Blue in connection with the transaction and the outstanding indebtedness of Blue, each of which is expected to be paid off at Closing.  Each outstanding Option will be cancelled at the Closing for consideration pursuant to the Stock Purchase Agreement.

[0001032975-18-000035:8k_body:3]
The Stock Purchase Agreement contains representations, warranties and covenants of the parties, closing conditions, and certain indemnification obligations of the Sellers to the Company and its affiliates supported by an escrow fund. The Company is also obligated to obtain representation and warranty insurance at or prior to the Closing.  The Stock Purchase Agreement also contains certain post-closing working capital adjustments. Logitech expects to file a copy of the Stock Purchase Agreement with its Quarterly Report on Form 10-Q for the quarterly period ended September 30, 2018. The summary of the Stock Purchase Agreement does not purport to be complete and is subject to and qualified in its entirety by reference to the Stock Purchase Agreement.

[0001032975-18-000035:8k_body:4]
Subject to the terms of the Stock Purchase Agreement, the representations and warranties by each of the Company, Blue and the Sellers in the Stock Purchase Agreement were made solely for the benefit of the parties to the Stock Purchase Agreement and the Stock Purchase Agreement (i) should not be treated as categorical statements of fact, but rather as a way of allocating the risk to one of the parties if those statements prove to be inaccurate, (ii) may have been qualified in the Stock Purchase Agreement by disclosures that were made to the other parties in accordance with the Stock Purchase Agreement, (iii) may apply contractual standards of “materiality” that are different from “materiality” under applicable securities laws, and (iv) were made only as of the dates specified in the Stock Purchase Agreement.
