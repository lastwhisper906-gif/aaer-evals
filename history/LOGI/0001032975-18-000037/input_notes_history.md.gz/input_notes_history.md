# LOGI note change history — 0001032975-18-000007 → 0001032975-18-000037


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2018-08-02):
[0001032975-18-000037:note_history:1]
All of the Company's products are covered by warranty to be free from defects in material and workmanship for periods ranging from one year to five years. The Company’s warranty doesn’t provide a service beyond assuring that the product complies with agreed-upon specifications and is not sold separately. The warranty the Company provides qualify as assurance warranty and not treated as a separate performance obligation. The Company estimates cost of product warranties at the time the related revenue is recognized based on historical warranty claim rates, historical costs, and knowledge of specific product failures that are outside of the Company's typical experience. The Company accrues a warranty liability for estimated costs to provide products, parts or services to repair or replace products in satisfaction of the warranty obligation. Each quarter, the Company reevaluates estimates to assess the adequacy of recorded warranty liabilities considering the size of the installed base of products subject to warranty protection and adjusts the amounts as necessary. When the Company experiences changes in warranty claim activity or costs associated with fulfilling those claims, the warranty liability is adjusted accordingly. If actual product failure rates or repair costs differ from estimates, revisions to the estimated warranty liabilities would be required and could materially affect the Company's results of operations.

- changed (2018-08-02):
[0001032975-18-000037:note_history:2]
Changes in the Company’s warranty liability for the three months ended June 30, 2018 and 2017 were as follows (in thousands):
  (was, 2018-01-25, similarity 0.9231):
[0001032975-18-000007:note_history:2]
Changes in the Company’s warranty liability for the three and nine months ended December 31, 2017 and 2016 were as follows (in thousands):

- added (2018-08-02):
[0001032975-18-000037:note_history:3]
|  |  | Three Months EndedJune 30, |
|  |  | 2018 |  | 2017 |
| Beginning of the period |  | $ | 27,573 |  |  | $ | 21,911 |  |
| Provision |  | 7,364 |  |  | 5,124 |  |
| Settlements |  | (6,552 | ) |  | (4,567 | ) |
| Currency translation |  | 468 |  |  | (412 | ) |
| End of the period |  | $ | 28,853 |  |  | $ | 22,056 |  |

- changed (2018-08-02):
[0001032975-18-000037:note_history:4]
Logitech Europe S.A., one of the Company's wholly-owned subsidiaries, guaranteed payments of certain third-party contract manufacturers’ purchase obligations. As of June 30, 2018, the maximum amount of this guarantee was $3.8 million, of which $1.2 million of guaranteed purchase obligations were outstanding.
  (was, 2018-01-25, similarity 0.9527):
[0001032975-18-000007:note_history:4]
Logitech Europe S.A., one of our wholly-owned subsidiaries, guaranteed payments of certain third-party contract manufacturers’ purchase obligations. As of December 31, 2017, the maximum amount of this guarantee was $3.8 million, of which $1.7 million of guaranteed purchase obligations were outstanding.

- changed (2018-08-02):
[0001032975-18-000037:note_history:5]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of June 30, 2018, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.
  (was, 2018-01-25, similarity 0.9906):
[0001032975-18-000007:note_history:5]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of December 31, 2017, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

- added (2018-08-02):
[0001032975-18-000037:note_history:6]
The Stock Purchase Agreement that the Company entered into in connection with the investment by three venture capital firms in Lifesize, Inc. contains representations, warranties and covenants of Logitech and Lifesize, Inc. to the Venture Investors. Subject to certain limitations, the Company has agreed to indemnify the Venture Investors and certain persons related to the Venture Investors for certain losses resulting from breaches of or inaccuracies in such representations, warranties and covenants as well as certain other obligations, including third-party expenses, restructuring costs and pre-closing tax obligations of Lifesize.

- removed (2018-08-02):
[0001032975-18-000007:note_history:7]
All of the Company’s peripherals products sold are covered by warranty to be free from defects in material and workmanship. The warranty period varies by product and by region.

- removed (2018-08-02):
[0001032975-18-000007:note_history:8]
|  | Three Months EndedDecember 31, |  | Nine Months Ended December 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Beginning of the period | $ | 24,349 |  |  | $ | 21,612 |  |  | $ | 21,911 |  |  | $ | 20,380 |  |
| Assumed from business acquisition | — |  |  | — |  |  | 1,230 |  |  | 1,963 |  |
| Provision | 7,820 |  |  | 4,521 |  |  | 17,535 |  |  | 10,861 |  |
| Settlements | (6,050 | ) |  | (3,550 | ) |  | (15,229 | ) |  | (10,430 | ) |
| Currency translation | 145 |  |  | (462 | ) |  | 817 |  |  | (653 | ) |
| End of the period | $ | 26,264 |  |  | $ | 22,121 |  |  | $ | 26,264 |  |  | $ | 22,121 |  |

- removed (2018-08-02):
[0001032975-18-000007:note_history:9]
The stock purchase agreement entered on December 28, 2015 in connection with the investment by three venture capital firms in Lifesize contains representations, warranties and covenants of Logitech and Lifesize, Inc. to the Investors. Logitech has agreed, subject to certain limitations, to indemnify the Investors and certain persons related to the Investors for certain losses resulting from breaches of or inaccuracies in such representations, warranties and covenants as well as certain other obligations, including third-party expenses, restructuring costs and pre-closing tax obligations of Lifesize.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2018-08-02):
[0001032975-18-000037:note_history:10]
Logitech International S.A, together with its consolidated subsidiaries, ("Logitech" or the "Company") designs, manufactures and markets products that help connect people to digital and cloud experiences. More than 35 years ago, Logitech created products to improve experiences around the personal PC platform, and today it is a multi-brand, multi-category company designing products that enable better experiences consuming, sharing and creating any digital content such as music, gaming, video and computing, whether it is on a computer, mobile device or in the cloud.

- changed (2018-08-02):
[0001032975-18-000037:note_history:11]
The Company sells its products to a broad network of domestic and international customers, including direct sales to retailers, e-tailers and indirect sales through distributors.
  (was, 2018-01-25, similarity 0.9681):
[0001032975-18-000007:note_history:11]
The Company sells its products to a broad network of domestic and international customers, including direct sales to retailers and indirect sales through distributors.

- changed (2018-08-02):
[0001032975-18-000037:note_history:12]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three months ended June 30, 2018 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2019, or any future periods.
  (was, 2018-01-25, similarity 0.9573):
[0001032975-18-000007:note_history:12]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and nine months ended December 31, 2017 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2018, or any future periods.

- changed (2018-08-02):
[0001032975-18-000037:note_history:13]
Certain amounts from the comparative period in the accompanying condensed consolidated financial statements have been reclassified to conform to the condensed consolidated financial statement presentation as of and for the three months ended June 30, 2018.
  (was, 2018-01-25, similarity 0.891):
[0001032975-18-000007:note_history:13]
Certain amounts from the comparative period in the accompanying unaudited condensed consolidated financial statements have been reclassified to conform to the condensed consolidated financial statement presentation as of and for the three and nine months ended December 31, 2017.

- changed (2018-08-02):
[0001032975-18-000037:note_history:14]
Other than the recent accounting pronouncements adopted and discussed below under Recent Accounting Pronouncements Adopted and Summary of Significant Accounting Policies, there have been no changes in the Company’s significant accounting policies during the three months ended June 30, 2018 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2018.
  (was, 2018-01-25, similarity 0.7931):
[0001032975-18-000007:note_history:14]
Other than the recent accounting pronouncements adopted and discussed below, there have been no substantial changes in the Company’s significant accounting policies during the nine months ended December 31, 2017 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2017.

- added (2018-08-02):
[0001032975-18-000037:note_history:15]
The preparation of financial statements in conformity with GAAP requires management to make judgments, estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Significant estimates and assumptions made by management involve the fair value of goodwill, intangible assets acquired from business acquisitions, warranty liabilities, accruals for customer incentive, cooperative marketing, and pricing programs ("Customer Programs") and related breakage when appropriate, accrued revenue reserve from returns, allowance for doubtful accounts, inventory valuation, contingent consideration from business acquisitions and periodical reassessment of its fair value, share-based compensation expense, uncertain tax positions, and valuation allowances for deferred tax assets. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ materially from those estimates.

- added (2018-08-02):
[0001032975-18-000037:note_history:16]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standard Update ("ASU") No. 2014-09, "Revenue from Contracts with Customers (Topic 606)" ("ASU 2014-09" or “Topic 606”) which supersedes the revenue recognition requirements under ASC 605 (“Topic 605”), Revenue Recognition. ASU 2014-09 outlines a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes existing revenue recognition guidance, including industry-specific guidance. Under the new guidance, recognition of revenue occurs when a customer obtains control of promised goods or services in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. The new standard requires reporting companies to disclose the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. On April 1, 2018, the Company adopted the new standard and all related amendments using the modified retrospective method applied to those contracts which were not completed as of March 31, 2018. Results for reporting periods beginning after April 1, 2018 are presented under Topic 606, while prior period amounts are not adjusted and continue to be reported in accordance with historic accounting standards under Topic 605.

- added (2018-08-02):
[0001032975-18-000037:note_history:17]
As result of the adoption of the new standard, the Company recorded: a) a reduction to retained earnings as of April 1, 2018; b) reclassification of certain allowances for sales returns and certain other Customer Programs from accounts receivable, net to accrued and other current liabilities and other current assets.

- added (2018-08-02):
[0001032975-18-000037:note_history:18]
The cumulative effect of the changes to the condensed consolidated balance sheet from the adoption of Topic 606 was as follows (in thousands):

- added (2018-08-02):
[0001032975-18-000037:note_history:19]
|  |  | As of March 31, 2018 |  | Effect of Adoption of Topic 606 |  | As of April 1, 2018 |
| Accounts receivable, net |  | $ | 214,885 |  |  | $ | 105,768 |  |  | $ | 320,653 |  |
| Other current assets |  | 56,362 |  |  | 6,195 |  |  | 62,557 |  |
| Accrued and other current liabilities |  | 281,732 |  |  | 122,845 |  |  | 404,577 |  |
| Retained earnings |  | 1,232,316 |  |  | (10,882 | ) |  | 1,221,434 |  |

- added (2018-08-02):
[0001032975-18-000037:note_history:20]
Net Reduction to Retained Earnings as of April 1, 2018

- added (2018-08-02):
[0001032975-18-000037:note_history:21]
| • | Under Topic 605, accruals for certain Customer Programs were recognized as a reduction of revenue at the later of when the related revenue is recognized or when the program is offered to the customer. Under Topic 606, these programs qualify as variable consideration and are recorded as a reduction of the transaction price at the contract inception based on the expected value method. The Company is required to estimate for these programs ahead of commitment date if customary business practice creates an implied expectation that such activities will occur in the future. |

- added (2018-08-02):
[0001032975-18-000037:note_history:22]
| • | Under Topic 606, variable consideration must be estimated at the outset of the arrangement, subject to the constraint guidance to ensure that a significant revenue reversal will not occur. As a result, upon adoption of Topic 606, estimated breakage for accruals of certain Customer Programs is recognized sooner as compared to Topic 605. |

- added (2018-08-02):
[0001032975-18-000037:note_history:23]
Balance Sheet Reclassification

- added (2018-08-02):
[0001032975-18-000037:note_history:24]
| • | Under Topic 605, gross amount of accrued revenue reserves for sales returns of $31.4 million, net of expected returned inventory of $11.4 million was included within accounts receivable, net as of March 31, 2018. Expected scrap cost of $5.2 million for such expected returned inventory was included in accrued and other current liabilities as of March 31, 2018. Subsequent to the adoption of Topic 606, such balances are presented on a gross basis as accrued revenue reserve from returns of $31.4 million included in accrued and other current liabilities and as return assets of $6.2 million included in other current assets. |

- added (2018-08-02):
[0001032975-18-000037:note_history:25]
| • | Under Topic 605, revenue reserves for certain Customer Programs totaling $76.7 million, which were estimated using portfolio approach based on aggregated customer level, were included within accounts receivable, net as of March 31, 2018. Subsequent to the adoption of Topic 606, such balances are presented as accrued customer marketing, pricing and incentive programs included in accrued and other current liabilities. |

- added (2018-08-02):
[0001032975-18-000037:note_history:26]
Certain balances of allowances for sales return and accruals for Customer Programs which were accrued based on Customer Program offers made to individual customer, met the right of offset criteria in accordance with ASC 210-20, "Balance Sheet (Topic 210)", and are still included within accounts receivable, net.

- added (2018-08-02):
[0001032975-18-000037:note_history:27]
The adoption of Topic 606 did not have an impact over the total cash flows from operating, investing, or financing activities.

- added (2018-08-02):
[0001032975-18-000037:note_history:28]
The following tables summarize the impacts of adopting Topic 606 on the Company’s condensed consolidated statements of operations and balance sheets for the three months ended or as of June 30, 2018 (in thousands):

- added (2018-08-02):
[0001032975-18-000037:note_history:29]
|  |  | As Reported |  | If Reported Under Topic 605 |  | Effect of Adoption of Topic 606 |
| Net sales |  | $ | 608,480 |  |  | $ | 608,614 |  |  | $ | (134 | ) |
| Accounts receivable, net |  | 385,546 |  |  | 272,009 |  |  | 113,537 |  |
| Other current assets |  | 62,542 |  |  | 55,237 |  |  | 7,305 |  |
| Accrued and other current liabilities |  | 384,497 |  |  | 252,639 |  |  | 131,858 |  |
| Retained earnings |  | 1,259,900 |  |  | 1,270,916 |  |  | (11,016 | ) |

- added (2018-08-02):
[0001032975-18-000037:note_history:30]
In January 2016, the FASB issued ASU 2016-01, "Financial Instruments-Recognition and Measurement of Financial Assets and Financial Liabilities (Subtopic 825-10)" ("ASU 2016-01"). ASU 2016-01 requires entities to measure equity instruments at fair value and recognize any changes in fair value within the statement of operations. The Company adopted ASU 2016-01 effective April 1, 2018 on a prospective basis for its privately held strategic equity securities without readily determinable fair values. The Company elected the measurement alternative to record these investments at cost and to adjust for impairments and observable price changes with a same or similar security from the same issuer within the statement of operations. The adoption of ASU 2016-01 did not have a material impact on the Company's condensed consolidated financial statements.

- added (2018-08-02):
[0001032975-18-000037:note_history:31]
In October 2016, the FASB issued ASU 2016-16, "Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory" ("ASU 2016-16"), which eliminates the deferral of income tax effects of intra-entity asset transfers until the transferred asset is sold to an unrelated party or recovered through use. However, this standard does not apply to intra-entity transfer of inventory. The Company adopted this standard effective April 1, 2018 on a modified retrospective basis and the adoption of ASU 2016-10 did not have a material impact on its condensed consolidated financial statements.

- added (2018-08-02):
[0001032975-18-000037:note_history:32]
In December 2016, the FASB issued ASU 2016-18, "Statement of Cash Flows (Topic 230): Restricted Cash" ("ASU 2016-18"), which requires that a statement of cash flows explains the change during the period in the total of cash, cash equivalents, and amounts generally described as restricted cash or restricted cash equivalents. The Company adopted this standard effective April 1, 2018 utilizing the retrospective transition method to each period presented and the adoption of ASU 2016-18 did not have a material impact on its condensed consolidated financial statements. The Company did not have restricted cash for both periods presented.

- added (2018-08-02):
[0001032975-18-000037:note_history:33]
In January 2017, the FASB issued ASU 2017-01, "Business Combination (Topic 805): Clarifying the Definition of a Business" ("ASU 2017-01"), which changes the definition of a business to assist with evaluating when a set of transferred assets and activities is a business. The Company adopted this standard effective April 1, 2018 and the adoption of ASU 2017-01 did not have a material impact on its condensed consolidated financial statements.

- changed (2018-08-02):
[0001032975-18-000037:note_history:34]
In March 2017, the FASB issued ASU 2017-07, "Compensation-Retirement Benefit (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost" ("ASU 2017-07"), which requires that the Company disaggregate the service cost component from the other components of net benefit cost, and also provides guidance on how to present the service cost component and the other components of net benefit cost in the income statement and allow only the service cost component of net benefit cost to be eligible for capitalization. The Company adopted this standard effective April 1, 2018 using a retrospective adoption method. Other than the revised statement of operations presentation for the current period, the adoption of ASU 2017-07 did not have an impact on the Company’s condensed consolidated financial statements. The impact to the comparative period was immaterial and therefore prior year statement of operations was not revised.
  (was, 2018-01-25, similarity 0.6216):
[0001032975-18-000007:note_history:34]
In March 2017, the FASB issued ASU 2017-07, "Compensation-Retirement Benefit (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost" ("ASU 2017-07"), which requires that the Company disaggregate the service cost component from the other components of net benefit cost, and also provides guidance on how to present the service cost component and the other components of net benefit cost in the income statement and allow only the service cost component of net benefit cost to be eligible for capitalization. ASU 2017-07 is effective for annual periods beginning after December 15, 2017, including interim periods within those annual periods, with early adoption permitted. The Company does not expect that the adoption of ASU 2017-07 will have a material impact on its consolidated financial statements and will adopt this standard effective April 1, 2018.

- added (2018-08-02):
[0001032975-18-000037:note_history:35]
In August 2017, the FASB issued ASU 2017-12, "Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities" ("ASU 2017-12"), which improves the financial reporting of hedging relationships to better portray the economic results of an entity’s risk management activities in its financial statements and simplifies the application of the hedge accounting guidance. The Company adopted this standard effective April 1, 2018 and the adoption of ASU 2017-12 did not have a material impact on its condensed consolidated financial statements. In accordance with ASC 815-20-45-1A, the Company has started presenting the earnings impact from forward points in the same line item that is used to present the earnings impact of the hedged item, i.e. Cost of goods sold for hedging forecasted inventory purchases.

- added (2018-08-02):
[0001032975-18-000037:note_history:36]
In February 2016, the FASB issued ASU 2016-02, "Leases (Topic 842)" ("ASU 2016-02" or "Topic 842"), which generally requires companies to recognize right-of-use assets and lease liabilities arising from operating and financing leases with terms longer than 12 months in the consolidated balance sheets. This guidance will be effective for the Company in the first quarter of fiscal year 2020 on a modified retrospective basis and early adoption is permitted. The Company will adopt the new standard effective April 1, 2019. Although the Company expects to record significant amounts of right-of-use assets and liabilities on its consolidated balance sheets, the Company is still evaluating the full impact of adopting this guidance to determine the amounts and additional disclosures.

- added (2018-08-02):
[0001032975-18-000037:note_history:37]
Summary of Significant Accounting Policies

- added (2018-08-02):
[0001032975-18-000037:note_history:38]
Revenue Recognition

- added (2018-08-02):
[0001032975-18-000037:note_history:39]
Revenue is recognized when a customer obtains control of promised goods or service in an amount that reflects the transaction price the Company expects to receive in exchange for those goods or services.

- added (2018-08-02):
[0001032975-18-000037:note_history:40]
Substantially all revenue recognized by the Company relates to the contracts with customers to sell products that allow people to connect through music, gaming, video, computing, and other digital platforms. These products are hardware devices, which may include embedded software. Hardware devices are generally plug and play, requiring no configuration and little or no installation. Revenue is recognized at a point in time when control of the products is transferred to the customer which generally occurs upon shipment. The Company’s contracts with its customers generally have a term of no more than one year. The Company applies the practical expedient of not disclosing the value of unsatisfied performance obligations for contracts with an original expected length of one year or less.

- added (2018-08-02):
[0001032975-18-000037:note_history:41]
The Company also provides post-contract customer support (“PCS”) for sold products and related software, which includes unspecified software updates and upgrades, bug fixes and maintenance. Revenue allocated to such PCS is recognized on a straight-line basis over the estimated term of the support, which is between 1 to 2 years, and not material for the periods presented herein. Deferred revenue associated with remaining PCS performance obligation is not material as of June 30, 2018 and March 31, 2018.

- added (2018-08-02):
[0001032975-18-000037:note_history:42]
The Company normally requires payments from customers within 30-60 days from invoice date. However, terms may vary by customer type, by country and by selling season. Extended payment terms are sometimes offered to a limited number of customers during the second and third fiscal quarters. The Company does not modify payment terms on existing receivables. The Company's contracts with customers typically do not include significant financing components as the period between the transfer of performance obligations and timing of payment are generally within one year.

- added (2018-08-02):
[0001032975-18-000037:note_history:43]
The transaction price received by the Company from sales to its distributors, retail companies ("retailers"), and authorized resellers is calculated as selling price net of variable consideration which may include product returns, price protection, and Company’s payments for Customer Programs related to current period product revenue. The estimated impact of these programs is recorded as a reduction of sales or as an operating expense if the Company receives a distinct good or service from the customer and can reasonably estimate the fair value of that good or service received. Significant management judgment and estimates are used to determine the impact of these programs in any accounting period. Certain customer programs require management to estimate the percentage of those programs which will not be claimed or will not be earned by customers based on historical experience and on the specific terms and conditions of particular programs. The percentage of these customer programs that will not be claimed or earned is commonly referred to as "breakage". The Company accounts for breakage as part of variable consideration, subject to constraint and records the estimated impact in the same period when revenue is recognized at the expected value considering constraints. Significant management judgments and estimates are used to determine the breakage of the programs in any accounting period.

- added (2018-08-02):
[0001032975-18-000037:note_history:44]
The Company enters into cooperative marketing arrangements with many of its customers and with certain indirect partners, allowing customers to receive a credit equal to a set percentage of their purchases of the Company's products, or a fixed dollar credit for various marketing and incentive programs. The objective of these arrangements is to encourage advertising and promotional events to increase sales of the Company's products.

- added (2018-08-02):
[0001032975-18-000037:note_history:45]
Customer incentive programs include consumer rebates and performance-based incentives. Consumer rebates are offered to the Company's customers and indirect partners at the Company's discretion for the primary benefit of end-users. In addition, the Company offers performance-based incentives to many of its customers and indirect partners based on predetermined performance criteria. At management's discretion, the Company also offers special pricing discounts to certain customers. Special pricing discounts are usually offered only for limited time periods or for sales of selected products to specific indirect partners.

- added (2018-08-02):
[0001032975-18-000037:note_history:46]
Estimates of required accruals for cooperative marketing arrangements and customer incentive programs are determined based on negotiated terms, consideration of historical experience, forecasted incentives, anticipated volume of future purchases, and inventory levels in the channel.

- added (2018-08-02):
[0001032975-18-000037:note_history:47]
The Company has agreements with certain customers that contain terms allowing price protection credits to be issued in the event of a subsequent price reduction. Management's decision to make price reductions is influenced by product life cycle stage, market acceptance of products, the competitive environment, new product introductions and other factors. Accruals for estimated expected future pricing actions are recognized at the time of sale based on analyses of historical pricing actions by customer and by product, inventories owned by and located at customers, current customer demand, current operating conditions, and other relevant customer and product information, such as stage of product life-cycle.

- added (2018-08-02):
[0001032975-18-000037:note_history:48]
Product return rights vary by customer and range from the right to return defective products to stock rotation rights limited to a percentage of sales. Estimates of expected future product returns qualify as variable consideration and are recorded as a reduction of the transaction price of the contract at the time of sale based on analyses of historical return trends by customer and by product, inventories owned by and located at customers, current customer demand, current operating conditions, and other relevant customer and product information. The Company assesses the estimated returned asset value for impairment, and adjusts the value of the asset if it becomes impaired. Return trends are influenced by product life cycle status, new product introductions, market acceptance of products, sales levels, product sell-through, the type of customer, seasonality, product quality issues, competitive pressures, operational policies and procedures, and other factors. Return rates can fluctuate over time but are sufficiently predictable to allow the Company to estimate expected future product returns.

- added (2018-08-02):
[0001032975-18-000037:note_history:49]
Typically variable consideration does not need to be constrained as estimates are based on predictive historical data or future commitments that are planned and controlled by the Company. However, the Company continues to assess variable consideration estimates such that it is probable that a significant reversal of revenue will not occur.

- added (2018-08-02):
[0001032975-18-000037:note_history:50]
The Company regularly evaluates the adequacy of its estimates for Customer Programs and product returns. Future market conditions and product transitions may require the Company to take action to change such programs and related estimates. When the variables used to estimate these costs change, or if actual costs differ significantly from the estimates, the Company would be required to record incremental increases or reductions to sales or operating expenses.

- added (2018-08-02):
[0001032975-18-000037:note_history:51]
Sales taxes and value added taxes (“VAT”) collected from customers which are remitted to governmental authorities are not included in revenue, and are reflected as a liability on the condensed consolidated balance sheets. The Company has elected to exclude sales taxes from the revenue recognized from contracts with customers.

- added (2018-08-02):
[0001032975-18-000037:note_history:52]
Shipping and Handling Costs

- added (2018-08-02):
[0001032975-18-000037:note_history:53]
The Company's shipping and handling costs are included in cost of goods sold in the condensed consolidated statements of operations for all periods presented.

- added (2018-08-02):
[0001032975-18-000037:note_history:54]
Contract Balances

- added (2018-08-02):
[0001032975-18-000037:note_history:55]
The Company records accounts receivable from contracts with customers when it has an unconditional right to consideration, as accounts receivable, net on the condensed consolidated balance sheet.

- added (2018-08-02):
[0001032975-18-000037:note_history:56]
The Company records contract liabilities when cash payments are received or due in advance of performance, primarily for implied support and subscriptions. Contract liabilities are included in accrual and other current liabilities on the condensed consolidated balance sheets.

- added (2018-08-02):
[0001032975-18-000037:note_history:57]
As of June 30, 2018 and April 1, 2018, the Company did not have any material contract liabilities balances or changes.

- added (2018-08-02):
[0001032975-18-000037:note_history:58]
Contract Costs

- added (2018-08-02):
[0001032975-18-000037:note_history:59]
The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that otherwise would have been recognized is one year or less. These costs are included in marketing and selling expenses in the condensed consolidated statements of operations. As of June 30, 2018 and April 1, 2018, the Company does not have material deferred contract costs or changes.

- added (2018-08-02):
[0001032975-18-000037:note_history:60]
Allowances for Doubtful Accounts

- added (2018-08-02):
[0001032975-18-000037:note_history:61]
Allowances for doubtful accounts are maintained for estimated losses resulting from the Company's customers' inability to make required payments. The allowances are based on the Company's regular assessment of the financial condition of specific customers, as well as its historical experience with bad debts and customer deductions, receivables aging, current economic trends, geographic or country specific risks and the financial condition of its distribution channels.

- removed (2018-08-02):
[0001032975-18-000007:note_history:62]
Logitech International S.A, together with its consolidated subsidiaries, ("Logitech" or the "Company") designs, manufactures and markets products that allow people to connect through music, gaming, video, computing, and other digital platforms.

- removed (2018-08-02):
[0001032975-18-000007:note_history:63]
Business Acquisitions

- removed (2018-08-02):
[0001032975-18-000007:note_history:64]
In August 2017, the Company acquired the ASTRO Gaming business. In November 2017, the Company also made a small acquisition. See "Note 2 - Business Acquisitions" for more information.

- removed (2018-08-02):
[0001032975-18-000007:note_history:65]
The preparation of financial statements in conformity with GAAP requires management to make judgments, estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Significant estimates and assumptions made by management involve the fair value of goodwill, intangible assets acquired from business acquisitions, warranty liabilities, accruals for customer programs and related breakage when appropriate, sales return reserves, allowance for doubtful accounts, inventory valuation, contingent consideration from business acquisitions and periodical reassessment of its fair value, share-based compensation expense, uncertain tax positions, and valuation allowances for deferred tax assets. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ materially from those estimates.

- removed (2018-08-02):
[0001032975-18-000007:note_history:66]
In July 2015, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2015-11, "Simplifying the Measurement of Inventory (Topic 330)" ("ASU 2015-11"). Topic 330 previously required an entity to measure inventory at the lower of cost or market, with market value represented by replacement cost, net realizable value or net realizable value less a normal profit margin. ASU 2015-11 requires an entity to measure inventory at the lower of cost or net realizable value and is effective for fiscal years beginning after December 15, 2016. The Company adopted this standard effective April 1, 2017, which has not had a material impact on its consolidated financial statements.

- removed (2018-08-02):
[0001032975-18-000007:note_history:67]
In March 2016, the FASB issued ASU 2016-09, "Compensation-Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting" ("ASU 2016-09"). ASU 2016-09 simplifies several aspects of the accounting for share-based payments, including immediate recognition of all excess tax benefits and deficiencies in the income statement, changing the threshold to qualify for equity classification up to the employees' maximum statutory tax rates, allowing an entity-wide accounting policy election to either estimate the number of awards that are expected to vest or account for forfeitures as they occur, and clarifying the classification on the statement of cash flows for the excess tax benefits and employee taxes paid when an employer withholds shares for tax withholding purposes. ASU 2016-09 is effective for fiscal years beginning after December 15, 2016. The Company adopted this standard effective April 1, 2017. Changes to the statements of cash flows related to the classification of excess tax benefits were implemented on a retroactive basis and accordingly, to conform to the current year presentation, the Company reclassified $6.4 million of excess tax benefits previously reported under financing activities to operating activities for the nine months ended December 31, 2016 on its condensed consolidated statements of cash flows. Under the new standard, the Company accounts for forfeitures as they occur. The change in accounting for forfeitures resulted in a cumulative-effect adjustment to decrease retained earnings as of March 31, 2017 by $3.3 million. The Company further recognized a cumulative-effect adjustment to increase retained earnings as of March 31, 2017 by $57.2 million upon adoption of the new guidance to account for gross excess tax benefits of $75.2 million that were previously not recognized because the related tax deduction had not reduced current income taxes, offset by a valuation allowance of $18.0 million to reduce the deferred tax assets to amounts that are more likely than not to be realized.

- removed (2018-08-02):
[0001032975-18-000007:note_history:68]
In January 2017, the FASB issued ASU 2017-04, "Simplifying the Test for Goodwill Impairment (Topic

- removed (2018-08-02):
[0001032975-18-000007:note_history:69]
350)" ("ASU 2017-04"), which removes Step 2 from the goodwill impairment test. ASU 2017-04 is effective for annual or any interim goodwill impairments in annual periods beginning December 15, 2019, with early adoption permitted. The Company adopted this standard effective April 1, 2017, which has not had a material impact on its consolidated financial statements.

- removed (2018-08-02):
[0001032975-18-000007:note_history:70]
In May 2017, the FASB issued ASU 2017-09, "Compensation-Stock Compensation (Topic 718): Scope of

- removed (2018-08-02):
[0001032975-18-000007:note_history:71]
Modification Accounting" ("ASU 2017-09"), which provides guidance about which changes to the terms or conditions

- removed (2018-08-02):
[0001032975-18-000007:note_history:72]
of a share-based payment award require an entity to apply modification accounting in Topic 718. ASU 2017-09 is

- removed (2018-08-02):
[0001032975-18-000007:note_history:73]
effective for annual periods beginning after December 15, 2017, with early adoption permitted, including adoption in any interim period for which financial statements have not yet been issued. The Company adopted this standard effective April 1, 2017, which has not had a material impact on its consolidated financial statements.

- removed (2018-08-02):
[0001032975-18-000007:note_history:74]
In May 2014, the FASB issued ASU No. 2014-09, "Revenue from Contracts with Customers (Topic 606)" ("ASU 2014-09") which supersedes the revenue recognition requirements under Accounting Standard Codification ("ASC") 605, Revenue Recognition. ASU 2014-09 outlines a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. Under the new model, recognition of revenue occurs when a customer obtains control of promised goods or services in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. The new standard requires reporting companies to disclose the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. The new standard will become effective for the Company on April 1, 2018. The Company will adopt Topic 606 utilizing the modified retrospective transition method, which recognizes the cumulative effect of initially applying Topic 606 as an adjustment to retained earnings at the adoption date. The Company continues to evaluate the impact this new standard will have on the current contracts with customers and the accruals of various sales and marketing programs the Company offers and has identified the following areas that are impacted:

- removed (2018-08-02):
[0001032975-18-000007:note_history:75]
Accrual for cooperative marketing arrangements and customer incentive programs: At the end of every quarter, the Company estimates accruals for cooperative marketing arrangements and customer incentive programs based on negotiated terms, consideration of historical experience, and inventory levels in the channel. Under ASC 605, these programs are recognized as a reduction of revenue at the later of when the related revenue is recognized or when the program is offered to the customer. Under Topic 606, these programs qualify as variable consideration and are recorded as a reduction of the transaction price at the contract inception based on the expected value method. Certain of these programs will reflect such change which will lead to the recognition of the accruals sooner as compared to the guidance in ASC 605.

- removed (2018-08-02):
[0001032975-18-000007:note_history:76]
Breakage estimates: The Company applies a breakage rate to reduce its accruals of customer incentive, cooperative marketing, and pricing programs based on the estimated percentage of these customer programs that will not be claimed or earned. The breakage rate is applied when the Company is able to reasonably estimate the amounts that will be ultimately claimed by customers, which generally occurs up to one quarter after the program is accrued.  Under Topic 606, variable consideration must be estimated at the outset of the arrangement, subject to the constraint guidance to ensure that a significant revenue reversal will not occur. As a result, upon adoption of Topic 606, revenue will be recognized sooner as compared to the existing revenue guidance.

- removed (2018-08-02):
[0001032975-18-000007:note_history:77]
The Company expects to complete its analysis of Topic 606 and reasonably estimate the impact to its consolidated financial statements when its Annual Report on Form 10-K for the fiscal year ending March 31, 2018 is filed. The Company will continue to monitor additional changes, modifications, clarifications or interpretations being undertaken by the FASB, which may impact its current conclusions. It is possible that during the fourth quarter of fiscal year 2018, the Company may identify additional areas which may result in material impact on the Company’s consolidated financial statements.

- removed (2018-08-02):
[0001032975-18-000007:note_history:78]
In January 2016, the FASB issued ASU 2016-01, "Financial Instruments-Recognition and Measurement of Financial Assets and Financial Liabilities (Subtopic 825-10)" ("ASU 2016-01"). ASU 2016-01 is effective for annual periods beginning after December 15, 2017, including interim periods within those annual periods, with early adoption permitted. The Company does not believe that the adoption of ASU 2016-01 will have a material impact on its consolidated financial statements and will adopt this standard effective April 1, 2018.

- removed (2018-08-02):
[0001032975-18-000007:note_history:79]
In February 2016, the FASB issued ASU 2016-02, "Leases (Topic 842)" ("ASU 2016-02"), which requires the recognition of lease assets and lease liabilities arising from operating leases in the statement of financial position. ASU 2016-02 is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years, with early adoption permitted. The Company is evaluating the full effect that ASU 2016-02 will have on its consolidated financial statements and will adopt this standard effective April 1, 2019.

- removed (2018-08-02):
[0001032975-18-000007:note_history:80]
In October 2016, the FASB issued ASU 2016-16, "Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory" ("ASU 2016-16"), which eliminates the deferral of income tax effects of intra-entity asset transfers until the transferred asset is sold to an unrelated party or recovered through use. However, this standard does not apply to intra-entity transfer of inventory.  ASU 2016-16 is effective for annual periods beginning after December 15, 2017, including interim periods within those annual periods, with early adoption permitted but only in the first interim period of an annual period. The cumulative effect of change on equity upon adoption is to be quantified under the modified retrospective approach and recorded as of the beginning of the period of adoption.  The Company does not expect the adoption of ASU 2016-16 will have a material impact on its consolidated financial statements and will adopt this standard effective April 1, 2018.

- removed (2018-08-02):
[0001032975-18-000007:note_history:81]
In December 2016, the FASB issued ASU 2016-18, "Statement of Cash Flows (Topic 230): Restricted Cash" ("ASU 2016-18"), which requires that a statement of cash flows explains the change during the period in the total of cash, cash equivalents, and amounts generally described as restricted cash or restricted cash equivalents.  ASU 2016-18 is effective for annual periods beginning after December 15, 2017, including interim periods within those annual periods, with early adoption permitted. The adoption of this standard should be applied using a retrospective transition method to each period presented. The Company does not expect that the adoption of ASU 2016-18 will have a material impact on its consolidated financial statements and will adopt this standard effective April 1, 2018.

- removed (2018-08-02):
[0001032975-18-000007:note_history:82]
In January 2017, the FASB issued ASU 2017-01, "Business Combination (Topic 805): Clarifying the Definition of a Business" ("ASU 2017-01"), which changes the definition of a business to assist with evaluating when a set of transferred assets and activities is a business. ASU 2017-01 is effective for annual or any interim periods in annual periods beginning after December 15, 2017, with early adoption permitted. The Company does not expect that the adoption of ASU 2017-01 will have a material impact on its consolidated financial statements and will adopt this standard effective April 1, 2018.

- removed (2018-08-02):
[0001032975-18-000007:note_history:83]
In August 2017, the FASB issued ASU 2017-12, "Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities" ("ASU 2017-12"), which improves the financial reporting of hedging relationships to better portray the economic results of an entity’s risk management activities in its financial statements and simplifies the application of the hedge accounting guidance. ASU 2017-12 is effective for annual periods beginning after December 15, 2018, including interim periods within those annual periods, with early adoption permitted. The Company does not expect that the adoption of ASU 2017-12 will have a material impact on its consolidated financial statements and will adopt this standard effective April 1, 2019.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-08-02):
[0001032975-18-000037:note_history:84]
The Company had several uncommitted, unsecured bank lines of credit aggregating $81.8 million as of June 30, 2018. There are no financial covenants under these lines of credit with which the Company must comply. As of June 30, 2018, the Company had outstanding bank guarantees of $20.9 million under these lines of credit. There was no borrowing outstanding under these lines of credit as of June 30, 2018 or March 31, 2018.
  (was, 2018-01-25, similarity 0.9127):
[0001032975-18-000007:note_history:84]
The Company had several uncommitted, unsecured bank lines of credit aggregating $62.1 million as of December 31, 2017. There are no financial covenants under these lines of credit with which the Company must comply. As of December 31, 2017, the Company had outstanding bank guarantees of $44.2 million under these lines of credit. There was no borrowing outstanding under these lines of credit as of December 31, 2017 or March 31, 2017.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2018-08-02):
[0001032975-18-000037:note_history:85]
Revenue Recognition

- added (2018-08-02):
[0001032975-18-000037:note_history:86]
Revenue is recognized when a customer obtains control of promised goods or service in an amount that reflects the transaction price the Company expects to receive in exchange for those goods or services.

- added (2018-08-02):
[0001032975-18-000037:note_history:87]
Substantially all revenue recognized by the Company relates to the contracts with customers to sell products that allow people to connect through music, gaming, video, computing, and other digital platforms. These products are hardware devices, which may include embedded software. Hardware devices are generally plug and play, requiring no configuration and little or no installation. Revenue is recognized at a point in time when control of the products is transferred to the customer which generally occurs upon shipment. The Company’s contracts with its customers generally have a term of no more than one year. The Company applies the practical expedient of not disclosing the value of unsatisfied performance obligations for contracts with an original expected length of one year or less.

- added (2018-08-02):
[0001032975-18-000037:note_history:88]
The Company also provides post-contract customer support (“PCS”) for sold products and related software, which includes unspecified software updates and upgrades, bug fixes and maintenance. Revenue allocated to such PCS is recognized on a straight-line basis over the estimated term of the support, which is between 1 to 2 years, and not material for the periods presented herein. Deferred revenue associated with remaining PCS performance obligation is not material as of June 30, 2018 and March 31, 2018.

- added (2018-08-02):
[0001032975-18-000037:note_history:89]
The Company normally requires payments from customers within 30-60 days from invoice date. However, terms may vary by customer type, by country and by selling season. Extended payment terms are sometimes offered to a limited number of customers during the second and third fiscal quarters. The Company does not modify payment terms on existing receivables. The Company's contracts with customers typically do not include significant financing components as the period between the transfer of performance obligations and timing of payment are generally within one year.

- added (2018-08-02):
[0001032975-18-000037:note_history:90]
The transaction price received by the Company from sales to its distributors, retail companies ("retailers"), and authorized resellers is calculated as selling price net of variable consideration which may include product returns, price protection, and Company’s payments for Customer Programs related to current period product revenue. The estimated impact of these programs is recorded as a reduction of sales or as an operating expense if the Company receives a distinct good or service from the customer and can reasonably estimate the fair value of that good or service received. Significant management judgment and estimates are used to determine the impact of these programs in any accounting period. Certain customer programs require management to estimate the percentage of those programs which will not be claimed or will not be earned by customers based on historical experience and on the specific terms and conditions of particular programs. The percentage of these customer programs that will not be claimed or earned is commonly referred to as "breakage". The Company accounts for breakage as part of variable consideration, subject to constraint and records the estimated impact in the same period when revenue is recognized at the expected value considering constraints. Significant management judgments and estimates are used to determine the breakage of the programs in any accounting period.

- added (2018-08-02):
[0001032975-18-000037:note_history:91]
The Company enters into cooperative marketing arrangements with many of its customers and with certain indirect partners, allowing customers to receive a credit equal to a set percentage of their purchases of the Company's products, or a fixed dollar credit for various marketing and incentive programs. The objective of these arrangements is to encourage advertising and promotional events to increase sales of the Company's products.

- added (2018-08-02):
[0001032975-18-000037:note_history:92]
Customer incentive programs include consumer rebates and performance-based incentives. Consumer rebates are offered to the Company's customers and indirect partners at the Company's discretion for the primary benefit of end-users. In addition, the Company offers performance-based incentives to many of its customers and indirect partners based on predetermined performance criteria. At management's discretion, the Company also offers special pricing discounts to certain customers. Special pricing discounts are usually offered only for limited time periods or for sales of selected products to specific indirect partners.

- added (2018-08-02):
[0001032975-18-000037:note_history:93]
Estimates of required accruals for cooperative marketing arrangements and customer incentive programs are determined based on negotiated terms, consideration of historical experience, forecasted incentives, anticipated volume of future purchases, and inventory levels in the channel.

- added (2018-08-02):
[0001032975-18-000037:note_history:94]
The Company has agreements with certain customers that contain terms allowing price protection credits to be issued in the event of a subsequent price reduction. Management's decision to make price reductions is influenced by product life cycle stage, market acceptance of products, the competitive environment, new product introductions and other factors. Accruals for estimated expected future pricing actions are recognized at the time of sale based on analyses of historical pricing actions by customer and by product, inventories owned by and located at customers, current customer demand, current operating conditions, and other relevant customer and product information, such as stage of product life-cycle.

- added (2018-08-02):
[0001032975-18-000037:note_history:95]
Product return rights vary by customer and range from the right to return defective products to stock rotation rights limited to a percentage of sales. Estimates of expected future product returns qualify as variable consideration and are recorded as a reduction of the transaction price of the contract at the time of sale based on analyses of historical return trends by customer and by product, inventories owned by and located at customers, current customer demand, current operating conditions, and other relevant customer and product information. The Company assesses the estimated returned asset value for impairment, and adjusts the value of the asset if it becomes impaired. Return trends are influenced by product life cycle status, new product introductions, market acceptance of products, sales levels, product sell-through, the type of customer, seasonality, product quality issues, competitive pressures, operational policies and procedures, and other factors. Return rates can fluctuate over time but are sufficiently predictable to allow the Company to estimate expected future product returns.

- added (2018-08-02):
[0001032975-18-000037:note_history:96]
Typically variable consideration does not need to be constrained as estimates are based on predictive historical data or future commitments that are planned and controlled by the Company. However, the Company continues to assess variable consideration estimates such that it is probable that a significant reversal of revenue will not occur.

- added (2018-08-02):
[0001032975-18-000037:note_history:97]
The Company regularly evaluates the adequacy of its estimates for Customer Programs and product returns. Future market conditions and product transitions may require the Company to take action to change such programs and related estimates. When the variables used to estimate these costs change, or if actual costs differ significantly from the estimates, the Company would be required to record incremental increases or reductions to sales or operating expenses.

- added (2018-08-02):
[0001032975-18-000037:note_history:98]
Sales taxes and value added taxes (“VAT”) collected from customers which are remitted to governmental authorities are not included in revenue, and are reflected as a liability on the condensed consolidated balance sheets. The Company has elected to exclude sales taxes from the revenue recognized from contracts with customers.

- added (2018-08-02):
[0001032975-18-000037:note_history:99]
Shipping and Handling Costs

- added (2018-08-02):
[0001032975-18-000037:note_history:100]
The Company's shipping and handling costs are included in cost of goods sold in the condensed consolidated statements of operations for all periods presented.

- added (2018-08-02):
[0001032975-18-000037:note_history:101]
Contract Balances

- added (2018-08-02):
[0001032975-18-000037:note_history:102]
The Company records accounts receivable from contracts with customers when it has an unconditional right to consideration, as accounts receivable, net on the condensed consolidated balance sheet.

- added (2018-08-02):
[0001032975-18-000037:note_history:103]
The Company records contract liabilities when cash payments are received or due in advance of performance, primarily for implied support and subscriptions. Contract liabilities are included in accrual and other current liabilities on the condensed consolidated balance sheets.

- added (2018-08-02):
[0001032975-18-000037:note_history:104]
As of June 30, 2018 and April 1, 2018, the Company did not have any material contract liabilities balances or changes.

- added (2018-08-02):
[0001032975-18-000037:note_history:105]
Contract Costs

- added (2018-08-02):
[0001032975-18-000037:note_history:106]
The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that otherwise would have been recognized is one year or less. These costs are included in marketing and selling expenses in the condensed consolidated statements of operations.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2018-08-02):
[0001032975-18-000037:note_history:107]
Subsequent Event

- added (2018-08-02):
[0001032975-18-000037:note_history:108]
On July 30, 2018, the Company signed an agreement to acquire all equity interests in Blue Microphones Holding Corporation for approximately $117 million in cash, assuming breakeven net working capital at close. Blue Microphones is a leader in studio-quality microphones for professionals and consumers. The Blue Microphones acquisition is consistent with Logitech's merger and acquisition strategy and will supplement the Company's portfolio opportunities. The transaction is expected to close in late August, 2018 and is subject to receipt of regulatory approvals in various jurisdictions and other closing conditions.
