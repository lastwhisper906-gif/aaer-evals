# LOGI notes — 0001032975-18-000037


## logi:ScheduleOfBalanceSheetComponentsAssetsTableTextBlock

[0001032975-18-000037:notes:1]
The following table presents the components of certain balance sheet asset amounts as of June 30 and March 31, 2018 (in thousands):

[0001032975-18-000037:notes:2]
|  |  | June 30, 2018 |  | March 31,2018 |
| Accounts receivable, net: |  |  |  |  |  |  |
| Accounts receivable |  | $ | 541,086 |  |  | $ | 482,872 |  |
| Allowance for doubtful accounts |  | (147 | ) |  | (122 | ) |
| Allowance for sales returns (1) |  | (5,465 | ) |  | (25,515 | ) |
| Allowance for cooperative marketing arrangements (1) |  | (27,268 | ) |  | (30,389 | ) |
| Allowance for customer incentive programs (1) |  | (44,015 | ) |  | (70,592 | ) |
| Allowance for pricing programs (1) |  | (78,645 | ) |  | (141,369 | ) |
|  |  | $ | 385,546 |  |  | $ | 214,885 |  |
| Inventories: |  |  |  |  |  |  |
| Raw materials |  | $ | 35,240 |  |  | $ | 33,603 |  |
| Finished goods |  | 237,422 |  |  | 226,303 |  |
|  |  | $ | 272,662 |  |  | $ | 259,906 |  |
| Other current assets: |  |  |  |  |  |  |
| Value-added tax receivables |  | $ | 27,162 |  |  | $ | 29,477 |  |
| Prepaid expenses and other assets (1) |  | 35,380 |  |  | 26,885 |  |
|  |  | $ | 62,542 |  |  | $ | 56,362 |  |
| Property, plant and equipment, net: |  |  |  |  |  |  |
| Property, plant and equipment at cost |  | $ | 353,625 |  |  | $ | 346,588 |  |
| Less: accumulated depreciation and amortization |  | (268,904 | ) |  | (260,284 | ) |
|  |  | $ | 84,721 |  |  | $ | 86,304 |  |
| Other assets: |  |  |  |  |  |  |
| Deferred tax assets |  | $ | 94,011 |  |  | $ | 84,651 |  |
| Trading investments for deferred compensation plan |  | 20,005 |  |  | 17,748 |  |
| Investments in privately held companies |  | 12,607 |  |  | 12,448 |  |
| Other assets |  | 5,138 |  |  | 5,908 |  |
|  |  | $ | 131,761 |  |  | $ | 120,755 |  |

[0001032975-18-000037:notes:3]
(1) The gross amount of allowances for sales return and certain other customer incentive, cooperative marketing and pricing programs were included within accounts receivable, net balance as of March 31, 2018. Upon adoption of Topic 606, such balances are presented as accrued revenue reserve from returns and accrued customer marketing, pricing and incentive programs included in accrued and other current liabilities and as return assets included in other current assets, respectively, on the balance sheet as of June 30, 2018. Refer to Note 1 to the condensed consolidated financial statements for more information.


## logi:ScheduleOfBalanceSheetComponentsLiabilityTableTextBlock

[0001032975-18-000037:notes:4]
The following table presents the components of certain balance sheet liability amounts as of June 30 and March 31, 2018 (in thousands):

[0001032975-18-000037:notes:5]
|  |  | June 30, 2018 |  | March 31,2018 |
| Accrued and other current liabilities: |  |  |  |  |  |  |
| Accrued personnel expenses |  | $ | 70,811 |  |  | $ | 82,330 |  |
| Accrued revenue reserve from returns (1) |  | 32,219 |  |  | — |  |
| Accrued customer marketing, pricing and incentive programs (1) |  | 149,590 |  |  | 71,962 |  |
| Warranty accrual |  | 17,205 |  |  | 16,279 |  |
| Employee benefit plan obligation |  | 2,026 |  |  | 1,763 |  |
| Income taxes payable |  | 4,858 |  |  | 4,354 |  |
| Other current liabilities |  | 107,788 |  |  | 105,044 |  |
|  |  | $ | 384,497 |  |  | $ | 281,732 |  |
| Other non-current liabilities: |  |  |  |  |  |  |
| Warranty accrual |  | $ | 11,648 |  |  | $ | 11,294 |  |
| Obligation for deferred compensation plan |  | 20,005 |  |  | 17,748 |  |
| Employee benefit plan obligation |  | 40,667 |  |  | 42,434 |  |
| Deferred tax liability |  | 1,980 |  |  | 1,980 |  |
| Other non-current liabilities |  | 7,959 |  |  | 8,468 |  |
|  |  | $ | 82,259 |  |  | $ | 81,924 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001032975-18-000037:notes:6]
[same as prior period, unchanged from 0001032975-18-000007:notes:7]

[0001032975-18-000037:notes:7]
[same as prior period, unchanged from 0001032975-18-000007:notes:8]

[0001032975-18-000037:notes:8]
Logitech International S.A, together with its consolidated subsidiaries, ("Logitech" or the "Company") designs, manufactures and markets products that help connect people to digital and cloud experiences. More than 35 years ago, Logitech created products to improve experiences around the personal PC platform, and today it is a multi-brand, multi-category company designing products that enable better experiences consuming, sharing and creating any digital content such as music, gaming, video and computing, whether it is on a computer, mobile device or in the cloud.

[0001032975-18-000037:notes:9]
The Company sells its products to a broad network of domestic and international customers, including direct sales to retailers, e-tailers and indirect sales through distributors.

[0001032975-18-000037:notes:10]
[same as prior period, unchanged from 0001032975-18-000007:notes:11]

[0001032975-18-000037:notes:11]
[same as prior period, unchanged from 0001032975-18-000007:notes:14]

[0001032975-18-000037:notes:12]
The condensed consolidated interim financial statements include the accounts of Logitech and its subsidiaries. All intercompany balances and transactions have been eliminated. The condensed consolidated financial statements are presented in accordance with accounting principles generally accepted in the United States of America (“GAAP”) for interim financial information and therefore do not include all the information required by GAAP for complete financial statements. They should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended March 31, 2018, included in its Annual Report on Form 10-K filed with the Securities and Exchange Commission (“SEC”) on May 21, 2018.

[0001032975-18-000037:notes:13]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three months ended June 30, 2018 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2019, or any future periods.

[0001032975-18-000037:notes:14]
[same as prior period, unchanged from 0001032975-18-000007:notes:17]

[0001032975-18-000037:notes:15]
Certain amounts from the comparative period in the accompanying condensed consolidated financial statements have been reclassified to conform to the condensed consolidated financial statement presentation as of and for the three months ended June 30, 2018.

[0001032975-18-000037:notes:16]
[same as prior period, unchanged from 0001032975-18-000007:notes:19]

[0001032975-18-000037:notes:17]
Other than the recent accounting pronouncements adopted and discussed below under Recent Accounting Pronouncements Adopted and Summary of Significant Accounting Policies, there have been no changes in the Company’s significant accounting policies during the three months ended June 30, 2018 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2018.

[0001032975-18-000037:notes:18]
[same as prior period, unchanged from 0001032975-18-000007:notes:21]

[0001032975-18-000037:notes:19]
The preparation of financial statements in conformity with GAAP requires management to make judgments, estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Significant estimates and assumptions made by management involve the fair value of goodwill, intangible assets acquired from business acquisitions, warranty liabilities, accruals for customer incentive, cooperative marketing, and pricing programs ("Customer Programs") and related breakage when appropriate, accrued revenue reserve from returns, allowance for doubtful accounts, inventory valuation, contingent consideration from business acquisitions and periodical reassessment of its fair value, share-based compensation expense, uncertain tax positions, and valuation allowances for deferred tax assets. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ materially from those estimates.

[0001032975-18-000037:notes:20]
[same as prior period, unchanged from 0001032975-18-000007:notes:23]

[0001032975-18-000037:notes:21]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standard Update ("ASU") No. 2014-09, "Revenue from Contracts with Customers (Topic 606)" ("ASU 2014-09" or “Topic 606”) which supersedes the revenue recognition requirements under ASC 605 (“Topic 605”), Revenue Recognition. ASU 2014-09 outlines a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes existing revenue recognition guidance, including industry-specific guidance. Under the new guidance, recognition of revenue occurs when a customer obtains control of promised goods or services in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. The new standard requires reporting companies to disclose the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. On April 1, 2018, the Company adopted the new standard and all related amendments using the modified retrospective method applied to those contracts which were not completed as of March 31, 2018. Results for reporting periods beginning after April 1, 2018 are presented under Topic 606, while prior period amounts are not adjusted and continue to be reported in accordance with historic accounting standards under Topic 605.

[0001032975-18-000037:notes:22]
As result of the adoption of the new standard, the Company recorded: a) a reduction to retained earnings as of April 1, 2018; b) reclassification of certain allowances for sales returns and certain other Customer Programs from accounts receivable, net to accrued and other current liabilities and other current assets.

[0001032975-18-000037:notes:23]
The cumulative effect of the changes to the condensed consolidated balance sheet from the adoption of Topic 606 was as follows (in thousands):

[0001032975-18-000037:notes:24]
|  |  | As of March 31, 2018 |  | Effect of Adoption of Topic 606 |  | As of April 1, 2018 |
| Accounts receivable, net |  | $ | 214,885 |  |  | $ | 105,768 |  |  | $ | 320,653 |  |
| Other current assets |  | 56,362 |  |  | 6,195 |  |  | 62,557 |  |
| Accrued and other current liabilities |  | 281,732 |  |  | 122,845 |  |  | 404,577 |  |
| Retained earnings |  | 1,232,316 |  |  | (10,882 | ) |  | 1,221,434 |  |

[0001032975-18-000037:notes:25]
Net Reduction to Retained Earnings as of April 1, 2018

[0001032975-18-000037:notes:26]
| • | Under Topic 605, accruals for certain Customer Programs were recognized as a reduction of revenue at the later of when the related revenue is recognized or when the program is offered to the customer. Under Topic 606, these programs qualify as variable consideration and are recorded as a reduction of the transaction price at the contract inception based on the expected value method. The Company is required to estimate for these programs ahead of commitment date if customary business practice creates an implied expectation that such activities will occur in the future. |

[0001032975-18-000037:notes:27]
| • | Under Topic 606, variable consideration must be estimated at the outset of the arrangement, subject to the constraint guidance to ensure that a significant revenue reversal will not occur. As a result, upon adoption of Topic 606, estimated breakage for accruals of certain Customer Programs is recognized sooner as compared to Topic 605. |

[0001032975-18-000037:notes:28]
Balance Sheet Reclassification

[0001032975-18-000037:notes:29]
| • | Under Topic 605, gross amount of accrued revenue reserves for sales returns of $31.4 million, net of expected returned inventory of $11.4 million was included within accounts receivable, net as of March 31, 2018. Expected scrap cost of $5.2 million for such expected returned inventory was included in accrued and other current liabilities as of March 31, 2018. Subsequent to the adoption of Topic 606, such balances are presented on a gross basis as accrued revenue reserve from returns of $31.4 million included in accrued and other current liabilities and as return assets of $6.2 million included in other current assets. |

[0001032975-18-000037:notes:30]
| • | Under Topic 605, revenue reserves for certain Customer Programs totaling $76.7 million, which were estimated using portfolio approach based on aggregated customer level, were included within accounts receivable, net as of March 31, 2018. Subsequent to the adoption of Topic 606, such balances are presented as accrued customer marketing, pricing and incentive programs included in accrued and other current liabilities. |

[0001032975-18-000037:notes:31]
Certain balances of allowances for sales return and accruals for Customer Programs which were accrued based on Customer Program offers made to individual customer, met the right of offset criteria in accordance with ASC 210-20, "Balance Sheet (Topic 210)", and are still included within accounts receivable, net.

[0001032975-18-000037:notes:32]
The adoption of Topic 606 did not have an impact over the total cash flows from operating, investing, or financing activities.

[0001032975-18-000037:notes:33]
The following tables summarize the impacts of adopting Topic 606 on the Company’s condensed consolidated statements of operations and balance sheets for the three months ended or as of June 30, 2018 (in thousands):

[0001032975-18-000037:notes:34]
|  |  | As Reported |  | If Reported Under Topic 605 |  | Effect of Adoption of Topic 606 |
| Net sales |  | $ | 608,480 |  |  | $ | 608,614 |  |  | $ | (134 | ) |
| Accounts receivable, net |  | 385,546 |  |  | 272,009 |  |  | 113,537 |  |
| Other current assets |  | 62,542 |  |  | 55,237 |  |  | 7,305 |  |
| Accrued and other current liabilities |  | 384,497 |  |  | 252,639 |  |  | 131,858 |  |
| Retained earnings |  | 1,259,900 |  |  | 1,270,916 |  |  | (11,016 | ) |

[0001032975-18-000037:notes:35]
In January 2016, the FASB issued ASU 2016-01, "Financial Instruments-Recognition and Measurement of Financial Assets and Financial Liabilities (Subtopic 825-10)" ("ASU 2016-01"). ASU 2016-01 requires entities to measure equity instruments at fair value and recognize any changes in fair value within the statement of operations. The Company adopted ASU 2016-01 effective April 1, 2018 on a prospective basis for its privately held strategic equity securities without readily determinable fair values. The Company elected the measurement alternative to record these investments at cost and to adjust for impairments and observable price changes with a same or similar security from the same issuer within the statement of operations. The adoption of ASU 2016-01 did not have a material impact on the Company's condensed consolidated financial statements.

[0001032975-18-000037:notes:36]
In October 2016, the FASB issued ASU 2016-16, "Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory" ("ASU 2016-16"), which eliminates the deferral of income tax effects of intra-entity asset transfers until the transferred asset is sold to an unrelated party or recovered through use. However, this standard does not apply to intra-entity transfer of inventory. The Company adopted this standard effective April 1, 2018 on a modified retrospective basis and the adoption of ASU 2016-10 did not have a material impact on its condensed consolidated financial statements.

[0001032975-18-000037:notes:37]
In December 2016, the FASB issued ASU 2016-18, "Statement of Cash Flows (Topic 230): Restricted Cash" ("ASU 2016-18"), which requires that a statement of cash flows explains the change during the period in the total of cash, cash equivalents, and amounts generally described as restricted cash or restricted cash equivalents. The Company adopted this standard effective April 1, 2018 utilizing the retrospective transition method to each period presented and the adoption of ASU 2016-18 did not have a material impact on its condensed consolidated financial statements. The Company did not have restricted cash for both periods presented.

[0001032975-18-000037:notes:38]
In January 2017, the FASB issued ASU 2017-01, "Business Combination (Topic 805): Clarifying the Definition of a Business" ("ASU 2017-01"), which changes the definition of a business to assist with evaluating when a set of transferred assets and activities is a business. The Company adopted this standard effective April 1, 2018 and the adoption of ASU 2017-01 did not have a material impact on its condensed consolidated financial statements.

[0001032975-18-000037:notes:39]
In March 2017, the FASB issued ASU 2017-07, "Compensation-Retirement Benefit (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost" ("ASU 2017-07"), which requires that the Company disaggregate the service cost component from the other components of net benefit cost, and also provides guidance on how to present the service cost component and the other components of net benefit cost in the income statement and allow only the service cost component of net benefit cost to be eligible for capitalization. The Company adopted this standard effective April 1, 2018 using a retrospective adoption method. Other than the revised statement of operations presentation for the current period, the adoption of ASU 2017-07 did not have an impact on the Company’s condensed consolidated financial statements. The impact to the comparative period was immaterial and therefore prior year statement of operations was not revised.

[0001032975-18-000037:notes:40]
In August 2017, the FASB issued ASU 2017-12, "Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities" ("ASU 2017-12"), which improves the financial reporting of hedging relationships to better portray the economic results of an entity’s risk management activities in its financial statements and simplifies the application of the hedge accounting guidance. The Company adopted this standard effective April 1, 2018 and the adoption of ASU 2017-12 did not have a material impact on its condensed consolidated financial statements. In accordance with ASC 815-20-45-1A, the Company has started presenting the earnings impact from forward points in the same line item that is used to present the earnings impact of the hedged item, i.e. Cost of goods sold for hedging forecasted inventory purchases.

[0001032975-18-000037:notes:41]
[same as prior period, unchanged from 0001032975-18-000007:notes:32]

[0001032975-18-000037:notes:42]
In February 2016, the FASB issued ASU 2016-02, "Leases (Topic 842)" ("ASU 2016-02" or "Topic 842"), which generally requires companies to recognize right-of-use assets and lease liabilities arising from operating and financing leases with terms longer than 12 months in the consolidated balance sheets. This guidance will be effective for the Company in the first quarter of fiscal year 2020 on a modified retrospective basis and early adoption is permitted. The Company will adopt the new standard effective April 1, 2019. Although the Company expects to record significant amounts of right-of-use assets and liabilities on its consolidated balance sheets, the Company is still evaluating the full impact of adopting this guidance to determine the amounts and additional disclosures.

[0001032975-18-000037:notes:43]
Summary of Significant Accounting Policies

[0001032975-18-000037:notes:44]
Revenue Recognition

[0001032975-18-000037:notes:45]
Revenue is recognized when a customer obtains control of promised goods or service in an amount that reflects the transaction price the Company expects to receive in exchange for those goods or services.

[0001032975-18-000037:notes:46]
Substantially all revenue recognized by the Company relates to the contracts with customers to sell products that allow people to connect through music, gaming, video, computing, and other digital platforms. These products are hardware devices, which may include embedded software. Hardware devices are generally plug and play, requiring no configuration and little or no installation. Revenue is recognized at a point in time when control of the products is transferred to the customer which generally occurs upon shipment. The Company’s contracts with its customers generally have a term of no more than one year. The Company applies the practical expedient of not disclosing the value of unsatisfied performance obligations for contracts with an original expected length of one year or less.

[0001032975-18-000037:notes:47]
The Company also provides post-contract customer support (“PCS”) for sold products and related software, which includes unspecified software updates and upgrades, bug fixes and maintenance. Revenue allocated to such PCS is recognized on a straight-line basis over the estimated term of the support, which is between 1 to 2 years, and not material for the periods presented herein. Deferred revenue associated with remaining PCS performance obligation is not material as of June 30, 2018 and March 31, 2018.

[0001032975-18-000037:notes:48]
The Company normally requires payments from customers within 30-60 days from invoice date. However, terms may vary by customer type, by country and by selling season. Extended payment terms are sometimes offered to a limited number of customers during the second and third fiscal quarters. The Company does not modify payment terms on existing receivables. The Company's contracts with customers typically do not include significant financing components as the period between the transfer of performance obligations and timing of payment are generally within one year.

[0001032975-18-000037:notes:49]
The transaction price received by the Company from sales to its distributors, retail companies ("retailers"), and authorized resellers is calculated as selling price net of variable consideration which may include product returns, price protection, and Company’s payments for Customer Programs related to current period product revenue. The estimated impact of these programs is recorded as a reduction of sales or as an operating expense if the Company receives a distinct good or service from the customer and can reasonably estimate the fair value of that good or service received. Significant management judgment and estimates are used to determine the impact of these programs in any accounting period. Certain customer programs require management to estimate the percentage of those programs which will not be claimed or will not be earned by customers based on historical experience and on the specific terms and conditions of particular programs. The percentage of these customer programs that will not be claimed or earned is commonly referred to as "breakage". The Company accounts for breakage as part of variable consideration, subject to constraint and records the estimated impact in the same period when revenue is recognized at the expected value considering constraints. Significant management judgments and estimates are used to determine the breakage of the programs in any accounting period.

[0001032975-18-000037:notes:50]
The Company enters into cooperative marketing arrangements with many of its customers and with certain indirect partners, allowing customers to receive a credit equal to a set percentage of their purchases of the Company's products, or a fixed dollar credit for various marketing and incentive programs. The objective of these arrangements is to encourage advertising and promotional events to increase sales of the Company's products.

[0001032975-18-000037:notes:51]
Customer incentive programs include consumer rebates and performance-based incentives. Consumer rebates are offered to the Company's customers and indirect partners at the Company's discretion for the primary benefit of end-users. In addition, the Company offers performance-based incentives to many of its customers and indirect partners based on predetermined performance criteria. At management's discretion, the Company also offers special pricing discounts to certain customers. Special pricing discounts are usually offered only for limited time periods or for sales of selected products to specific indirect partners.

[0001032975-18-000037:notes:52]
Estimates of required accruals for cooperative marketing arrangements and customer incentive programs are determined based on negotiated terms, consideration of historical experience, forecasted incentives, anticipated volume of future purchases, and inventory levels in the channel.

[0001032975-18-000037:notes:53]
The Company has agreements with certain customers that contain terms allowing price protection credits to be issued in the event of a subsequent price reduction. Management's decision to make price reductions is influenced by product life cycle stage, market acceptance of products, the competitive environment, new product introductions and other factors. Accruals for estimated expected future pricing actions are recognized at the time of sale based on analyses of historical pricing actions by customer and by product, inventories owned by and located at customers, current customer demand, current operating conditions, and other relevant customer and product information, such as stage of product life-cycle.

[0001032975-18-000037:notes:54]
Product return rights vary by customer and range from the right to return defective products to stock rotation rights limited to a percentage of sales. Estimates of expected future product returns qualify as variable consideration and are recorded as a reduction of the transaction price of the contract at the time of sale based on analyses of historical return trends by customer and by product, inventories owned by and located at customers, current customer demand, current operating conditions, and other relevant customer and product information. The Company assesses the estimated returned asset value for impairment, and adjusts the value of the asset if it becomes impaired. Return trends are influenced by product life cycle status, new product introductions, market acceptance of products, sales levels, product sell-through, the type of customer, seasonality, product quality issues, competitive pressures, operational policies and procedures, and other factors. Return rates can fluctuate over time but are sufficiently predictable to allow the Company to estimate expected future product returns.

[0001032975-18-000037:notes:55]
Typically variable consideration does not need to be constrained as estimates are based on predictive historical data or future commitments that are planned and controlled by the Company. However, the Company continues to assess variable consideration estimates such that it is probable that a significant reversal of revenue will not occur.

[0001032975-18-000037:notes:56]
The Company regularly evaluates the adequacy of its estimates for Customer Programs and product returns. Future market conditions and product transitions may require the Company to take action to change such programs and related estimates. When the variables used to estimate these costs change, or if actual costs differ significantly from the estimates, the Company would be required to record incremental increases or reductions to sales or operating expenses.

[0001032975-18-000037:notes:57]
Sales taxes and value added taxes (“VAT”) collected from customers which are remitted to governmental authorities are not included in revenue, and are reflected as a liability on the condensed consolidated balance sheets. The Company has elected to exclude sales taxes from the revenue recognized from contracts with customers.

[0001032975-18-000037:notes:58]
Shipping and Handling Costs

[0001032975-18-000037:notes:59]
The Company's shipping and handling costs are included in cost of goods sold in the condensed consolidated statements of operations for all periods presented.

[0001032975-18-000037:notes:60]
Contract Balances

[0001032975-18-000037:notes:61]
The Company records accounts receivable from contracts with customers when it has an unconditional right to consideration, as accounts receivable, net on the condensed consolidated balance sheet.

[0001032975-18-000037:notes:62]
The Company records contract liabilities when cash payments are received or due in advance of performance, primarily for implied support and subscriptions. Contract liabilities are included in accrual and other current liabilities on the condensed consolidated balance sheets.

[0001032975-18-000037:notes:63]
As of June 30, 2018 and April 1, 2018, the Company did not have any material contract liabilities balances or changes.

[0001032975-18-000037:notes:64]
Contract Costs

[0001032975-18-000037:notes:65]
The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that otherwise would have been recognized is one year or less. These costs are included in marketing and selling expenses in the condensed consolidated statements of operations. As of June 30, 2018 and April 1, 2018, the Company does not have material deferred contract costs or changes.

[0001032975-18-000037:notes:66]
Allowances for Doubtful Accounts

[0001032975-18-000037:notes:67]
Allowances for doubtful accounts are maintained for estimated losses resulting from the Company's customers' inability to make required payments. The allowances are based on the Company's regular assessment of the financial condition of specific customers, as well as its historical experience with bad debts and customer deductions, receivables aging, current economic trends, geographic or country specific risks and the financial condition of its distribution channels.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001032975-18-000037:notes:68]
Commitments and Contingencies

[0001032975-18-000037:notes:69]
Product Warranties

[0001032975-18-000037:notes:70]
All of the Company's products are covered by warranty to be free from defects in material and workmanship for periods ranging from one year to five years. The Company’s warranty doesn’t provide a service beyond assuring that the product complies with agreed-upon specifications and is not sold separately. The warranty the Company provides qualify as assurance warranty and not treated as a separate performance obligation. The Company estimates cost of product warranties at the time the related revenue is recognized based on historical warranty claim rates, historical costs, and knowledge of specific product failures that are outside of the Company's typical experience. The Company accrues a warranty liability for estimated costs to provide products, parts or services to repair or replace products in satisfaction of the warranty obligation. Each quarter, the Company reevaluates estimates to assess the adequacy of recorded warranty liabilities considering the size of the installed base of products subject to warranty protection and adjusts the amounts as necessary. When the Company experiences changes in warranty claim activity or costs associated with fulfilling those claims, the warranty liability is adjusted accordingly. If actual product failure rates or repair costs differ from estimates, revisions to the estimated warranty liabilities would be required and could materially affect the Company's results of operations.

[0001032975-18-000037:notes:71]
Changes in the Company’s warranty liability for the three months ended June 30, 2018 and 2017 were as follows (in thousands):

[0001032975-18-000037:notes:72]
|  |  | Three Months EndedJune 30, |
|  |  | 2018 |  | 2017 |
| Beginning of the period |  | $ | 27,573 |  |  | $ | 21,911 |  |
| Provision |  | 7,364 |  |  | 5,124 |  |
| Settlements |  | (6,552 | ) |  | (4,567 | ) |
| Currency translation |  | 468 |  |  | (412 | ) |
| End of the period |  | $ | 28,853 |  |  | $ | 22,056 |  |

[0001032975-18-000037:notes:73]
Guarantees

[0001032975-18-000037:notes:74]
Logitech Europe S.A., one of the Company's wholly-owned subsidiaries, guaranteed payments of certain third-party contract manufacturers’ purchase obligations. As of June 30, 2018, the maximum amount of this guarantee was $3.8 million, of which $1.2 million of guaranteed purchase obligations were outstanding.

[0001032975-18-000037:notes:75]
Indemnifications

[0001032975-18-000037:notes:76]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of June 30, 2018, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

[0001032975-18-000037:notes:77]
The Company also indemnifies its current and former directors and certain of its current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. The Company is unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not limited, the obligations are conditional in nature and the facts and circumstances involved in any situation that might arise are variable.

[0001032975-18-000037:notes:78]
The Stock Purchase Agreement that the Company entered into in connection with the investment by three venture capital firms in Lifesize, Inc. contains representations, warranties and covenants of Logitech and Lifesize, Inc. to the Venture Investors. Subject to certain limitations, the Company has agreed to indemnify the Venture Investors and certain persons related to the Venture Investors for certain losses resulting from breaches of or inaccuracies in such representations, warranties and covenants as well as certain other obligations, including third-party expenses, restructuring costs and pre-closing tax obligations of Lifesize.

[0001032975-18-000037:notes:79]
Legal Proceedings

[0001032975-18-000037:notes:80]
From time to time the Company is involved in claims and legal proceedings that arise in the ordinary course of its business. The Company is currently subject to several such claims and a small number of legal proceedings. The Company believes that these matters lack merit and intends to vigorously defend against them. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company’s defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company’s business, financial condition, cash flows or results of operations in a particular period. Any claims or proceedings against the Company, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain a necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company’s business.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001032975-18-000037:notes:81]
[same as prior period, unchanged from 0001032975-18-000007:notes:76]

[0001032975-18-000037:notes:82]
[same as prior period, unchanged from 0001032975-18-000007:notes:77]

[0001032975-18-000037:notes:83]
As of June 30, 2018, the Company offers the 2006 ESPP (2006 Employee Share Purchase Plan (Non-U.S.)), the 1996 ESPP (1996 Employee Share Purchase Plan (U.S.)), the 2006 Plan (2006 Stock Incentive Plan) and the 2012 Plan (2012 Stock Inducement Equity Plan), each as amended.

[0001032975-18-000037:notes:84]
The following table summarizes the share-based compensation expense and total income tax provision (benefit) recognized for share-based awards for the three months ended June 30, 2018 and 2017 (in thousands):

[0001032975-18-000037:notes:85]
|  |  | Three Months EndedJune 30, |
|  |  | 2018 |  | 2017 |
| Cost of goods sold |  | $ | 1,130 |  |  | $ | 711 |  |
| Marketing and selling |  | 5,786 |  |  | 4,381 |  |
| Research and development |  | 1,549 |  |  | 1,543 |  |
| General and administrative |  | 4,794 |  |  | 4,070 |  |
| Total share-based compensation expense |  | 13,259 |  |  | 10,705 |  |
| Income tax benefit |  | (9,529 | ) |  | (11,282 | ) |
| Total share-based compensation expense, net of income tax |  | $ | 3,730 |  |  | $ | (577 | ) |

[0001032975-18-000037:notes:86]
The income tax benefit in the respective period primarily consists of tax benefit related to the share-based compensation expense for the period and direct tax benefit realized, including net excess tax benefits recognized from share-based awards vested or exercised during the period.

[0001032975-18-000037:notes:87]
As of June 30, 2018 and 2017, the Company capitalized $0.6 million and $0.9 million, respectively, of share-based compensation expense to inventory.

[0001032975-18-000037:notes:88]
[same as prior period, unchanged from 0001032975-18-000007:notes:83]

[0001032975-18-000037:notes:89]
Certain of the Company’s subsidiaries sponsor defined benefit pension plans or non-retirement post-employment benefits covering substantially all of their employees. Benefits are provided based on employees’ years of service and earnings, or in accordance with applicable employee benefit regulations. The Company’s practice is to fund amounts sufficient to meet the requirements set forth in the applicable employee benefit and tax regulations. The cost recorded of $2.3 million and $2.3 million for the three months ended June 30, 2018 and 2017, respectively, was primarily related to service costs.


## us-gaap:DebtDisclosureTextBlock

[0001032975-18-000037:notes:90]
Financing Arrangements

[0001032975-18-000037:notes:91]
The Company had several uncommitted, unsecured bank lines of credit aggregating $81.8 million as of June 30, 2018. There are no financial covenants under these lines of credit with which the Company must comply. As of June 30, 2018, the Company had outstanding bank guarantees of $20.9 million under these lines of credit. There was no borrowing outstanding under these lines of credit as of June 30, 2018 or March 31, 2018.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001032975-18-000037:notes:92]
[same as prior period, unchanged from 0001032975-18-000007:notes:87]

[0001032975-18-000037:notes:93]
Under certain agreements with the respective counterparties to the Company’s derivative contracts, subject to applicable requirements, the Company is allowed to net settle transactions of the same type with a single net amount payable by one party to the other. However, the Company presents its derivative assets and derivative liabilities on a gross basis on the condensed consolidated balance sheets as of June 30, 2018 and March 31, 2018.

[0001032975-18-000037:notes:94]
The fair values of the Company’s derivative instruments not designated as hedging instruments were not material as of June 30, 2018 or March 31, 2018. The following table presents the fair values of the Company’s derivative instruments designated as hedging instruments on a gross basis in other current assets or accrued and other current liabilities on its condensed consolidated balance sheets as of June 30, 2018 and March 31, 2018 (in thousands):

[0001032975-18-000037:notes:95]
|  |  | Derivatives |
|  |  | Asset |  | Liability |
|  |  | June 30, 2018 |  | March 31,2018 |  | June 30, 2018 |  | March 31,2018 |
| Cash flow hedges |  | $ | 275 |  |  | $ | 48 |  |  | $ | 45 |  |  | $ | 402 |  |

[0001032975-18-000037:notes:96]
The amount of gain (loss) recognized on derivatives not designated as hedging instruments was not material in all periods presented herein. The following table presents the amounts of gains (losses) on the Company’s derivative instruments designated as hedging instruments and their locations on its condensed consolidated statements of operations and condensed consolidated statements of comprehensive income for the three months ended June 30, 2018 and 2017 (in thousands):

[0001032975-18-000037:notes:97]
|  |  | Three Months EndedJune 30, |
|  |  | Amount of Gain (Loss)Deferred as a Component of AccumulatedOther Comprehensive Loss |  | Amount of Loss (Gain)Reclassified from Accumulated Other Comprehensive Loss to Costs of Goods Sold |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Cash flow hedges |  | $ | 187 |  |  | $ | (3,209 | ) |  | $ | 2,851 |  |  | $ | 533 |  |

[0001032975-18-000037:notes:98]
Upon adoption of ASU 2017-12, the Company has started presenting the earnings impact from forward points in the same line item that is used to present the earnings impact of the hedged item, i.e. cost of goods sold, for hedging forecasted inventory purchases and such amount is not material for all periods presented.

[0001032975-18-000037:notes:99]
[same as prior period, unchanged from 0001032975-18-000007:notes:94]

[0001032975-18-000037:notes:100]
The Company enters into cash flow hedge contracts to protect against exchange rate exposure of forecasted inventory purchases. These hedging contracts mature within four months. Gains and losses in the fair value of the effective portion of the hedges are deferred as a component of accumulated other comprehensive loss until the hedged inventory purchases are sold, at which time the gains or losses are reclassified to cost of goods sold. Cash flows from such hedges are classified as operating activities in the condensed consolidated statements of cash flows.  Hedging relationships are discontinued when hedging contract is no longer eligible for hedge accounting, or is sold, terminated or exercised, or when Company removes hedge designation for the contract. Gains and losses in the fair value of the effective portion of the discontinued hedges continue to be reported in accumulated other comprehensive loss until the hedged inventory purchases are sold, unless it is probable that the forecasted inventory purchases will not occur by the end of the originally specified time period or within an additional two-month period of time thereafter. In all periods presented herein, there have been no forecasted inventory purchases that were probable to not occur by the end of the originally specified time period or within an additional two-month period of time thereafter. The notional amounts of foreign currency exchange forward contracts outstanding related to forecasted inventory purchases were $72.4 million as of June 30, 2018. As of March 31, 2018, there were no currency forward contracts outstanding related to forecasted inventory purchases. The Company had $0.2 million of net losses related to its cash flow hedges included in accumulated other comprehensive loss as of June 30, 2018 which will be reclassified into earnings within the next 12 months.

[0001032975-18-000037:notes:101]
[same as prior period, unchanged from 0001032975-18-000007:notes:96]

[0001032975-18-000037:notes:102]
The Company also enters into foreign currency exchange forward and swap contracts to reduce the short-term effects of currency exchange rate fluctuations on certain receivables or payables denominated in currencies other than the functional currencies of its subsidiaries. These contracts generally mature within one month. The primary risk managed by using forward and swap contracts is the currency exchange rate risk. The gains or losses on these contracts are recognized in other expense, net in the condensed consolidated statements of operations based on the changes in fair value. The notional amounts of these contracts outstanding as of June 30, 2018 and March 31, 2018 were $60.5 million and $47.2 million, respectively. Open forward and swap contracts outstanding as of June 30, 2018 and March 31, 2018 consisted of contracts in Mexican Pesos, Japanese Yen, Canadian dollars, Taiwanese dollars, and Australian dollars to be settled at future dates at pre-determined exchange rates.

[0001032975-18-000037:notes:103]
[same as prior period, unchanged from 0001032975-18-000007:notes:98]


## us-gaap:EarningsPerShareTextBlock

[0001032975-18-000037:notes:104]
[same as prior period, unchanged from 0001032975-18-000007:notes:99]

[0001032975-18-000037:notes:105]
[same as prior period, unchanged from 0001032975-18-000007:notes:100]

[0001032975-18-000037:notes:106]
|  |  | Three Months EndedJune 30, |
|  |  | 2018 |  | 2017 |
| Net income |  | $ | 38,466 |  |  | $ | 37,007 |  |
| Shares used in net income per share computation: |  |  |  |  |  |  |
| Weighted average shares outstanding - basic |  | 165,317 |  |  | 163,407 |  |
| Effect of potentially dilutive equivalent shares |  | 3,439 |  |  | 4,932 |  |
| Weighted average shares outstanding - diluted |  | 168,756 |  |  | 168,339 |  |
| Net income per share: |  |  |  |  |  |  |
| Basic |  | $ | 0.23 |  |  | $ | 0.23 |  |
| Diluted |  | $ | 0.23 |  |  | $ | 0.22 |  |

[0001032975-18-000037:notes:107]
Share equivalents attributable to outstanding stock options, restricted stock units ("RSUs") and ESPP totaling 1.5 million and 1.4 million for the three months ended June 30, 2018 and 2017, respectively, were excluded from the calculation of diluted net income per share because the combined exercise price and average unamortized grant date fair value upon exercise of these options and ESPP or vesting of RSUs were greater than the average market price of the Company's shares during the periods presented herein, and therefore their inclusion would have been anti-dilutive.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001032975-18-000037:notes:108]
[same as prior period, unchanged from 0001032975-18-000007:notes:105]

[0001032975-18-000037:notes:109]
[same as prior period, unchanged from 0001032975-18-000007:notes:106]

[0001032975-18-000037:notes:110]
[same as prior period, unchanged from 0001032975-18-000007:notes:107]

[0001032975-18-000037:notes:111]
[same as prior period, unchanged from 0001032975-18-000007:notes:108]

[0001032975-18-000037:notes:112]
[same as prior period, unchanged from 0001032975-18-000007:notes:109]

[0001032975-18-000037:notes:113]
[same as prior period, unchanged from 0001032975-18-000007:notes:110]

[0001032975-18-000037:notes:114]
|  |  | June 30, 2018 |  | March 31, 2018 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Level 1 |  | Level 2 |  | Level 3 |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 482,882 |  |  | $ | — |  |  | $ | — |  |  | $ | 492,535 |  |  | $ | — |  |  | $ | — |  |
| Trading investments for deferred compensation plan included in other assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 3,994 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,881 |  |  | $ | — |  |  | $ | — |  |
| Mutual funds |  | 16,011 |  |  | — |  |  | — |  |  | 14,867 |  |  | — |  |  | — |  |
| Total of trading investments for deferred compensation plan |  | $ | 20,005 |  |  | $ | — |  |  | $ | — |  |  | $ | 17,748 |  |  | $ | — |  |  | $ | — |  |
| Currency exchange derivative assetsincluded in other current assets |  | $ | — |  |  | $ | 275 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Currency exchange derivative liabilitiesincluded in accrued and other current liabilities |  | $ | — |  |  | $ | 45 |  |  | $ | — |  |  | $ | — |  |  | $ | 34 |  |  | $ | — |  |

[0001032975-18-000037:notes:115]
[same as prior period, unchanged from 0001032975-18-000007:notes:114]

[0001032975-18-000037:notes:116]
The marketable securities for the Company's deferred compensation plan were recorded at a fair value of $20.0 million and $17.7 million, as of June 30, 2018 and March 31, 2018, respectively, based on quoted market prices. Quoted market prices are observable inputs that are classified as Level 1 within the fair value hierarchy. Unrealized trading gains (losses) related to trading securities for the three months ended June 30, 2018 and 2017 were not material and are included in other expense, net in the Company's condensed consolidated statements of operations.

[0001032975-18-000037:notes:117]
Non-marketable Investments

[0001032975-18-000037:notes:118]
The Company has certain non-marketable investments included in other assets that are accounted for under the equity method of accounting, with carrying value of $5.3 million and $5.1 million as of June 30, 2018 and March 31, 2018, respectively.

[0001032975-18-000037:notes:119]
In addition, the Company has certain investments without readily determinable fair values due to the absence of quoted market prices, the inherent lack of liquidity, and the fact that inputs used to measure fair value are unobservable and require management's judgment. When certain events or circumstances indicate that impairment may exist, the Company revalues the investments using various assumptions, including the financial metrics and ratios of comparable public companies. The carrying value is also adjusted for observable price changes with a same or similar security from the same issuer. The amount of these investments included in other assets as of June 30, 2018 and March 31, 2018 was $7.3 million and $7.3 million, respectively.

[0001032975-18-000037:notes:120]
[same as prior period, unchanged from 0001032975-18-000007:notes:116]

[0001032975-18-000037:notes:121]
The Company’s non-financial assets, such as intangible assets and acquisition-related property, plant and equipment, are recorded at fair value only upon initial recognition or if an impairment is recognized. There was no impairment of these assets during the three months ended June 30, 2018 or 2017.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001032975-18-000037:notes:122]
[same as prior period, unchanged from 0001032975-18-000007:notes:121]

[0001032975-18-000037:notes:123]
The Company conducts its impairment analysis of the goodwill annually at December 31 and as necessary, if changes in facts and circumstances indicate that it is more likely than not that the fair value of the Company’s reporting units may be less than its carrying amount. There have been no events or circumstances during the three months ended June 30, 2018 that have required the Company to perform an interim assessment of goodwill.

[0001032975-18-000037:notes:124]
The following table summarizes the activities in the Company’s goodwill balance during the three months ended June 30, 2018 (in thousands):

[0001032975-18-000037:notes:125]
| As of March 31, 2018 |  | $ | 275,451 |  |
| Currency translation |  | (33 | ) |
| As of June 30, 2018 |  | $ | 275,418 |  |

[0001032975-18-000037:notes:126]
[same as prior period, unchanged from 0001032975-18-000007:notes:126]

[0001032975-18-000037:notes:127]
|  |  | June 30,2018 |  | March 31, 2018 |
|  |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |
| Trademark and trade names |  | $ | 23,870 |  |  | $ | (10,265 | ) |  | $ | 13,605 |  |  | $ | 23,870 |  |  | $ | (9,482 | ) |  | $ | 14,388 |  |
| Developed technology |  | 77,240 |  |  | (53,131 | ) |  | 24,109 |  |  | 77,175 |  |  | (50,755 | ) |  | 26,420 |  |
| Customer contracts/relationships |  | 59,510 |  |  | (14,505 | ) |  | 45,005 |  |  | 59,510 |  |  | (12,771 | ) |  | 46,739 |  |
| Total |  | $ | 160,620 |  |  | $ | (77,901 | ) |  | $ | 82,719 |  |  | $ | 160,555 |  |  | $ | (73,008 | ) |  | $ | 87,547 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001032975-18-000037:notes:128]
[same as prior period, unchanged from 0001032975-18-000007:notes:128]

[0001032975-18-000037:notes:129]
[same as prior period, unchanged from 0001032975-18-000007:notes:129]

[0001032975-18-000037:notes:130]
The Company has not adjusted the net provisional charge from remeasuring deferred tax assets related to the Tax Cuts and Jobs Act (the "Tax Act") in the United States in fiscal year 2018. The Company will continue to refine the estimate based on ongoing analysis and available information and interpretations through the third quarter of fiscal year 2019.

[0001032975-18-000037:notes:131]
The income tax benefit for the three months ended June 30, 2018 was $5.2 million based on an effective income tax rate of (15.7)% of pre-tax income, compared to an income tax benefit of $5.4 million based on an effective income tax rate of (17.2)% of pre-tax income for the three months ended June 30, 2017.

[0001032975-18-000037:notes:132]
The change in the effective income tax rate for the three months ended June 30, 2018, compared to the three months ended June 30, 2017, is primarily due to the mix of income and losses in the various tax jurisdictions which the Company operates and less excess tax benefits recognized in the United States in the three months ended June 30, 2018.  The Company recognized excess tax benefits of $8.3 million at 21% federal corporate income tax rate post the Tax Act in the three months ended June 30, 2018.  In the same period in fiscal year 2018, the Company recognized $9.9 million of excess tax benefits at 35% federal corporate income tax rate, offset by valuation allowance of $1.3 million for federal tax credit carryforwards after adoption of ASU 2016-09. In the three months ended June 30, 2018 and June 30, 2017, there was a discrete tax benefit of $0.9 million and $0.7 million, respectively, from the reversal of uncertain tax positions from the expiration of statutes of limitations.

[0001032975-18-000037:notes:133]
As of June 30, 2018 and March 31, 2018, the total amount of unrecognized tax benefits due to uncertain tax positions was $68.5 million and $69.1 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-18-000037:notes:134]
As of June 30, 2018 and March 31, 2018, the Company had $33.8 million and $35.0 million, respectively, in non-current income taxes payable including interest and penalties, related to the Company's income tax liability for uncertain tax positions.

[0001032975-18-000037:notes:135]
The Company recognizes interest and penalties related to unrecognized tax positions in income tax expense. As of June 30, 2018 and March 31, 2018, the Company had $2.4 million and $2.3 million, respectively, of accrued interest and penalties related to uncertain tax positions.

[0001032975-18-000037:notes:136]
Although the Company has adequately provided for uncertain tax positions, the provisions on these positions may change as revised estimates are made or the underlying matters are settled or otherwise resolved. During fiscal year 2019, the Company continues to review its tax positions and provide for or reverse unrecognized tax benefits as issues arise. During the next twelve months, it is reasonably possible that the amount of unrecognized tax benefits could increase or decrease significantly due to changes in tax law in various jurisdictions, new tax audits and changes in the U.S. dollar as compared to other currencies. Excluding these factors, uncertain tax positions may decrease by as much as $3.3 million from the lapse of the statutes of limitations in various jurisdictions during the next twelve months.


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0001032975-18-000037:notes:137]
[same as prior period, unchanged from 0001032975-18-000007:notes:139]

[0001032975-18-000037:notes:138]
|  |  | June 30, 2018 |  | March 31,2018 |
| Americas |  | $ | 34,098 |  |  | $ | 35,404 |  |
| EMEA |  | 4,600 |  |  | 4,690 |  |
| Asia Pacific |  | 46,023 |  |  | 46,210 |  |
| Total property, plant and equipment, net |  | $ | 84,721 |  |  | $ | 86,304 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001032975-18-000037:notes:139]
Restructuring

[0001032975-18-000037:notes:140]
During the first quarter of fiscal year 2019, the Company implemented a restructuring plan to streamline and realign the Company's overall organizational structure and reallocate resources to support the long-term growth opportunities. Subsequent to quarter end, the Company's Board of Directors approved to allow additional costs under this restructuring plan with total pre-tax charges of approximately $10 million to $15 million in the current fiscal year, of which $9.9 million was recognized during the first quarter of fiscal year 2019. The total charges consisted of cash severance and other personnel costs and are presented as restructuring charges in the condensed consolidated statements of operations.

[0001032975-18-000037:notes:141]
The following table summarizes restructuring related activities during the three months ended June 30, 2018 (in thousands):

[0001032975-18-000037:notes:142]
|  |  | TerminationBenefits |
| Accrual balance at March 31, 2018 |  | $ | — |  |
| Charges |  | 9,921 |  |
| Cash payments |  | (2,014 | ) |
| Accrual balance at June 30, 2018 |  | $ | 7,907 |  |


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001032975-18-000037:notes:143]
Net sales by geographic region (based on the customers’ locations) for the three months ended June 30, 2018 and 2017 were as follows (in thousands):

[0001032975-18-000037:notes:144]
|  |  | Three Months EndedJune 30, |
|  |  | 2018 |  | 2017 |
| Americas |  | $ | 276,928 |  |  | $ | 245,400 |  |
| EMEA |  | 160,632 |  |  | 150,591 |  |
| Asia Pacific |  | 170,920 |  |  | 133,955 |  |
| Total net sales |  | $ | 608,480 |  |  | $ | 529,946 |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001032975-18-000037:notes:145]
[same as prior period, unchanged from 0001032975-18-000007:notes:143]

[0001032975-18-000037:notes:146]
|  |  | Accumulated Other Comprehensive Income (Loss) |
|  |  | CumulativeTranslationAdjustment (1) |  | DefinedBenefitPlan (1) |  | Deferred Hedging Losses (1) |  | Total |
| March 31, 2018 |  | $ | (83,848 | ) |  | $ | (6,398 | ) |  | $ | (3,209 | ) |  | $ | (93,455 | ) |
| Other comprehensive income (loss) |  | (4,963 | ) |  | (164 | ) |  | 3,038 |  |  | (2,089 | ) |
| June 30, 2018 |  | $ | (88,811 | ) |  | $ | (6,562 | ) |  | $ | (171 | ) |  | $ | (95,544 | ) |

[0001032975-18-000037:notes:147]
(1)        Tax effect was not significant as of June 30 or March 31, 2018.


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001032975-18-000037:notes:148]
Net sales by product categories and sales channels, excluding intercompany transactions, for the three months ended June 30, 2018 and 2017 were as follows (in thousands):

[0001032975-18-000037:notes:149]
|  |  | Three Months EndedJune 30, |
|  |  | 2018 |  | 2017 |
| Pointing Devices |  | $ | 127,790 |  |  | $ | 122,074 |  |
| Keyboards & Combos |  | 128,222 |  |  | 116,113 |  |
| PC Webcams |  | 29,674 |  |  | 25,625 |  |
| Tablet & Other Accessories |  | 32,436 |  |  | 23,218 |  |
| Video Collaboration |  | 58,792 |  |  | 35,617 |  |
| Mobile Speakers |  | 34,327 |  |  | 62,918 |  |
| Audio & Wearables |  | 52,154 |  |  | 50,202 |  |
| Gaming |  | 136,026 |  |  | 77,708 |  |
| Smart Home |  | 9,011 |  |  | 16,466 |  |
| Other (1) |  | 48 |  |  | 5 |  |
| Total net sales |  | $ | 608,480 |  |  | $ | 529,946 |  |

[0001032975-18-000037:notes:150]
[same as prior period, unchanged from 0001032975-18-000007:notes:148]


## us-gaap:SegmentReportingDisclosureTextBlock

[0001032975-18-000037:notes:151]
[same as prior period, unchanged from 0001032975-18-000007:notes:149]

[0001032975-18-000037:notes:152]
The Company has determined that it operates in a single operating segment that encompasses the design, manufacturing and marketing of peripherals for PCs, tablets and other digital platforms. Operating performance measures are provided directly to the Company's CEO, who is considered to be the Company’s Chief Operating Decision Maker. The CEO periodically reviews information such as net sales and adjusted operating income (loss) to make business decisions. These operating performance measures do not include restructuring charges (credits), net, share-based compensation expense, amortization of intangible assets, charges from the purchase accounting effect on inventory, acquisition-related costs, change in fair value of contingent consideration from business acquisition, or gain (loss) from equity method investment.

[0001032975-18-000037:notes:153]
[same as prior period, unchanged from 0001032975-18-000007:notes:151]

[0001032975-18-000037:notes:154]
The United States and Germany each represented more than 10% of the total consolidated net sales for each of the periods presented herein. China represented more than 10% of the total consolidated net sales for the three months ended June 30, 2018. No other countries represented more than 10% of the Company’s total consolidated net sales for the periods presented herein.

[0001032975-18-000037:notes:155]
Switzerland, the Company’s home domicile, represented 2% and 1% of the Company’s total consolidated net sales for the three months ended June 30, 2018 and June 30, 2017, respectively.

[0001032975-18-000037:notes:156]
[same as prior period, unchanged from 0001032975-18-000007:notes:154]

[0001032975-18-000037:notes:157]
Property, plant and equipment, net in the United States and China were $34.1 million and $38.4 million, respectively, as of June 30, 2018, and $35.3 million and $37.9 million, respectively, as of March 31, 2018. No other countries represented more than 10% of the Company’s total consolidated property, plant and equipment, net as of June 30, 2018 or March 31, 2018. Property, plant and equipment, net in Switzerland, the Company’s home domicile, were $1.7 million and $1.9 million as of June 30, 2018 and March 31, 2018, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001032975-18-000037:notes:158]
[same as prior period, unchanged from 0001032975-18-000007:notes:156]

[0001032975-18-000037:notes:159]
[same as prior period, unchanged from 0001032975-18-000007:notes:157]

[0001032975-18-000037:notes:160]
In March 2017, the Company's Board of Directors approved the 2017 share buyback program, which authorizes the Company to use up to $250.0 million to purchase up to 17.3 million shares of its own shares. The Company's share buyback program is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Purchases may be started or stopped at any time without prior notice depending on market conditions and other factors. As of June 30, 2018, $209.9 million is still available for repurchase under the 2017 buyback program.

[0001032975-18-000037:notes:161]
[same as prior period, unchanged from 0001032975-18-000007:notes:164]


## us-gaap:SubsequentEventsTextBlock

[0001032975-18-000037:notes:162]
Subsequent Event

[0001032975-18-000037:notes:163]
On July 30, 2018, the Company signed an agreement to acquire all equity interests in Blue Microphones Holding Corporation for approximately $117 million in cash, assuming breakeven net working capital at close. Blue Microphones is a leader in studio-quality microphones for professionals and consumers. The Blue Microphones acquisition is consistent with Logitech's merger and acquisition strategy and will supplement the Company's portfolio opportunities. The transaction is expected to close in late August, 2018 and is subject to receipt of regulatory approvals in various jurisdictions and other closing conditions.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001032975-18-000037:notes:164]
[same as prior period, unchanged from 0001032975-18-000007:notes:165]
