# LOGI MD&A — 0001032975-23-000080


## mdna

[0001032975-23-000080:mdna:1]
[same as prior period, unchanged from 0001032975-23-000066:mdna:1]

[0001032975-23-000080:mdna:2]
[same as prior period, unchanged from 0001032975-23-000066:mdna:2]

[0001032975-23-000080:mdna:3]
[same as prior period, unchanged from 0001032975-23-000066:mdna:3]

[0001032975-23-000080:mdna:4]
[same as prior period, unchanged from 0001032975-23-000066:mdna:4]

[0001032975-23-000080:mdna:5]
[same as prior period, unchanged from 0001032975-23-000066:mdna:5]

[0001032975-23-000080:mdna:6]
[same as prior period, unchanged from 0001032975-23-000066:mdna:6]

[0001032975-23-000080:mdna:7]
[same as prior period, unchanged from 0001032975-23-000066:mdna:7]

[0001032975-23-000080:mdna:8]
[same as prior period, unchanged from 0001032975-23-000066:mdna:8]

[0001032975-23-000080:mdna:9]
•Our expectations regarding our potential indemnification obligations, and the outcome of pending or future legal proceedings and tax audits;

[0001032975-23-000080:mdna:10]
[same as prior period, unchanged from 0001032975-23-000066:mdna:10]

[0001032975-23-000080:mdna:11]
[same as prior period, unchanged from 0001032975-23-000066:mdna:11]

[0001032975-23-000080:mdna:12]
[same as prior period, unchanged from 0001032975-23-000066:mdna:12]

[0001032975-23-000080:mdna:13]
[same as prior period, unchanged from 0001032975-23-000066:mdna:13]

[0001032975-23-000080:mdna:14]
[same as prior period, unchanged from 0001032975-23-000066:mdna:14]

[0001032975-23-000080:mdna:15]
[same as prior period, unchanged from 0001032975-23-000066:mdna:15]

[0001032975-23-000080:mdna:16]
[same as prior period, unchanged from 0001032975-23-000066:mdna:16]

[0001032975-23-000080:mdna:17]
[same as prior period, unchanged from 0001032975-23-000066:mdna:17]

[0001032975-23-000080:mdna:18]
[same as prior period, unchanged from 0001032975-23-000066:mdna:18]

[0001032975-23-000080:mdna:19]
[same as prior period, unchanged from 0001032975-23-000066:mdna:19]

[0001032975-23-000080:mdna:20]
[same as prior period, unchanged from 0001032975-23-000066:mdna:20]

[0001032975-23-000080:mdna:21]
[same as prior period, unchanged from 0001032975-23-000066:mdna:21]

[0001032975-23-000080:mdna:22]
Our business has been impacted by adverse macroeconomic and geopolitical conditions. These conditions include inflation, interest rate and foreign currency fluctuations, slowdown of economic activity around the world, and lower consumer and enterprise spending.

[0001032975-23-000080:mdna:23]
[same as prior period, unchanged from 0001032975-23-000066:mdna:23]

[0001032975-23-000080:mdna:24]
[same as prior period, unchanged from 0001032975-23-000066:mdna:24]

[0001032975-23-000080:mdna:25]
[same as prior period, unchanged from 0001032975-23-000066:mdna:25]

[0001032975-23-000080:mdna:26]
Several long-term secular-trends offer long-term structural growth opportunities across Logitech’s product portfolio, including work and learn from anywhere (hybrid work and learn), video everywhere, the rise of social gaming for participants and spectators, and the democratization of digital content creation. We design, create and sell products that benefit from these secular trends. The trend of hybrid work and learn provides an opportunity to equip meeting rooms, classrooms and personal workspaces, at home or in the office. It also provides an opportunity for increased commercial and consumer adoption of video conferencing. Our video collaboration products are compatible with a variety of video conference platforms, including Zoom, Microsoft Teams, Google Meet, etc. Moving from work to play, Logitech gaming and streaming products benefit from social gaming which continues to gain popularity through online gaming, multi-platform experiences and esports. In addition, the democratization of digital content creation presents an opportunity for anyone to be a content creator because of the accessibility of the tools necessary to code, design, create, make music, game or broadcast to professional standards.

[0001032975-23-000080:mdna:27]
[same as prior period, unchanged from 0001032975-23-000066:mdna:27]

[0001032975-23-000080:mdna:28]
[same as prior period, unchanged from 0001032975-23-000066:mdna:28]

[0001032975-23-000080:mdna:29]
[same as prior period, unchanged from 0001032975-23-000066:mdna:29]

[0001032975-23-000080:mdna:30]
[same as prior period, unchanged from 0001032975-23-000066:mdna:30]

[0001032975-23-000080:mdna:31]
[same as prior period, unchanged from 0001032975-23-000066:mdna:31]

[0001032975-23-000080:mdna:32]
Our total sales for the three and six months ended September 30, 2023 decreased 8% and 12%, compared to the three and six months ended September 30, 2022, respectively, driven by a decline in sales of most of our product categories, as a result of lower demand.

[0001032975-23-000080:mdna:33]
Sales for the three months ended September 30, 2023 decreased 21% and 6% in the Asia Pacific and Americas regions, respectively, and increased 5% in the EMEA region, compared to the three months ended September 30, 2022. Sales for the six months ended September 30, 2023 decreased 24%, 9%, and 3% in the Asia Pacific, Americas, and EMEA regions, respectively, compared to the six months ended September 30, 2022.

[0001032975-23-000080:mdna:34]
Gross margin was 41.5% and 40.1% for the three and six months ended September 30, 2023, respectively, and increased by 330 and 120 basis points, respectively, compared to the three and six months ended September 30, 2022. The increase in gross margin for the three months ended September 30, 2023, compared to the three months ended September 30, 2022, was primarily driven by cost improvement and less reliance on expedited shipping, as well as lower promotions, partially offset by unfavorable product mix. The increase in gross margin for the six months ended September 30, 2023, compared to the six months ended September 30, 2022, was primarily driven by cost improvement and less reliance on expedited shipping, partially offset by unfavorable product mix.

[0001032975-23-000080:mdna:35]
Operating expenses for the three months ended September 30, 2023 were $282.0 million, or 26.7% of sales, compared to $311.4 million, or 27.1% of sales, for the three months ended September 30, 2022. Operating expenses for the six months ended September 30, 2023 were $579.2 million, or 28.5% of sales, compared to $655.5 million, or 28.4% of sales, for the six months ended September 30, 2022. The decrease in operating expense was primarily driven by a reduction in marketing and advertising spend.

[0001032975-23-000080:mdna:36]
Net income for the three and six months ended September 30, 2023 was $137.1 million and $199.8 million, respectively, compared to $82.1 million and $182.9 million for the three and six months ended September 30, 2022, respectively.

[0001032975-23-000080:mdna:37]
[same as prior period, unchanged from 0001032975-23-000066:mdna:37]

[0001032975-23-000080:mdna:38]
[same as prior period, unchanged from 0001032975-23-000066:mdna:38]

[0001032975-23-000080:mdna:39]
[same as prior period, unchanged from 0001032975-23-000066:mdna:39]

[0001032975-23-000080:mdna:40]
[same as prior period, unchanged from 0001032975-23-000066:mdna:40]

[0001032975-23-000080:mdna:41]
We believe that the assumptions, judgments and estimates involved in the accounting for accruals for customer incentives and related breakage when appropriate, accrued sales return liability, inventory valuation, and

[0001032975-23-000080:mdna:42]
uncertain tax positions, have the greatest potential impact on our condensed consolidated financial statements. These areas are key components of our results of operations and are based on complex rules requiring us to make judgments and estimates and consequently, we consider these to be our critical accounting policies. Historically, our assumptions, judgments and estimates relative to our critical accounting policies have not differed materially from actual results.

[0001032975-23-000080:mdna:43]
There have been no material changes in our critical accounting estimates during the six months ended September 30, 2023 compared with the critical accounting estimates disclosed in Management's Discussion and Analysis of Financial Condition and Results of Operations included in our Annual Report on Form 10-K for the fiscal year ended March 31, 2023.

[0001032975-23-000080:mdna:44]
[same as prior period, unchanged from 0001032975-23-000066:mdna:43]

[0001032975-23-000080:mdna:45]
On August 16, 2022, the “Inflation Reduction Act” (H.R. 5376) ("IRA") was signed into law in the U.S. The IRA establishes a new corporate alternative minimum tax based on financial statement income adjusted for certain items. The new minimum tax is effective for tax years beginning after December 31, 2022. The IRA is not expected to have a material impact on our financial statements for the tax year ending March 31, 2024.

[0001032975-23-000080:mdna:46]
[same as prior period, unchanged from 0001032975-23-000066:mdna:45]

[0001032975-23-000080:mdna:47]
[same as prior period, unchanged from 0001032975-23-000066:mdna:46]

[0001032975-23-000080:mdna:48]
[same as prior period, unchanged from 0001032975-23-000066:mdna:47]

[0001032975-23-000080:mdna:49]
[same as prior period, unchanged from 0001032975-23-000066:mdna:48]

[0001032975-23-000080:mdna:50]
[same as prior period, unchanged from 0001032975-23-000066:mdna:49]

[0001032975-23-000080:mdna:51]
[same as prior period, unchanged from 0001032975-23-000066:mdna:50]

[0001032975-23-000080:mdna:52]
[same as prior period, unchanged from 0001032975-23-000066:mdna:51]

[0001032975-23-000080:mdna:53]
Our sales for the three and six months ended September 30, 2023 decreased 8% and 12%, respectively, compared to the three and six months ended September 30, 2022, primarily due to a decline in sales of most of our product categories as a result of lower demand. If currency exchange rates had been constant in the three and six months ended September 30, 2023 and 2022, our constant dollar sales reduction rates would have been 9% and 12%, respectively.

[0001032975-23-000080:mdna:54]
[same as prior period, unchanged from 0001032975-23-000066:mdna:53]

[0001032975-23-000080:mdna:55]
Although our financial results are reported in U.S. Dollars, a portion of our sales was generated in currencies other than the U.S. Dollar, such as the Euro, Chinese Renminbi, Australian Dollar, Canadian Dollar, Japanese Yen, Pound Sterling and New Taiwan Dollar. During the three months ended September 30, 2023, approximately 50% of our sales were denominated in currencies other than the U.S. Dollar.

[0001032975-23-000080:mdna:56]
[same as prior period, unchanged from 0001032975-23-000066:mdna:55]

[0001032975-23-000080:mdna:57]
The following table presents the change in sales by region for the three and six months ended September 30, 2023, compared with the three and six months ended September 30, 2022:

[0001032975-23-000080:mdna:58]
|  |  | Sales Growth Rate |  | Constant DollarSales Growth Rate |
|  |  | Three Months EndedSeptember 30, 2023 |  | Six Months EndedSeptember 30, 2023 |  | Three Months EndedSeptember 30, 2023 |  | Six Months EndedSeptember 30, 2023 |
| Americas |  | (6) | % |  | (9) | % |  | (6) | % |  | (9) | % |
| EMEA |  | 5 | % |  | (3) | % |  | (2) | % |  | (6) | % |
| Asia Pacific |  | (21) | % |  | (24) | % |  | (18) | % |  | (21) | % |

[0001032975-23-000080:mdna:59]
[same as prior period, unchanged from 0001032975-23-000066:mdna:58]

[0001032975-23-000080:mdna:60]
The decrease in sales in the Americas region for the three-month and six-month periods presented above was primarily driven by a decline in sales of most of our product categories, partially offset by an increase in sales of Tablet Accessories.

[0001032975-23-000080:mdna:61]
[same as prior period, unchanged from 0001032975-23-000066:mdna:60]

[0001032975-23-000080:mdna:62]
The increase in sales in our EMEA region for the three-month period presented above was primarily driven by the increase in sales of Gaming, Pointing Devices, and Keyboards & Combos, partially offset by a decline in sales of Webcams. The decrease in sales in our EMEA region for the six-month period presented above was primarily driven by decreases in sales of Video Collaboration and Webcams, partially offset by an increase in sales of Pointing Devices.

[0001032975-23-000080:mdna:63]
[same as prior period, unchanged from 0001032975-23-000066:mdna:62]

[0001032975-23-000080:mdna:64]
The decrease in sales in our Asia Pacific region for the three-month and six-month periods presented above was primarily driven by the decrease in sales of Gaming, Keyboards & Combos, and Video Collaboration.

[0001032975-23-000080:mdna:65]
[same as prior period, unchanged from 0001032975-23-000066:mdna:64]

[0001032975-23-000080:mdna:66]
During the first quarter of fiscal year 2024, we changed the presentation of sales by product category to provide a simpler and clearer view of our business. The change in presentation did not have an impact on previously reported total sales. As a result of these changes, certain prior-period amounts for the three and six months ended September 30, 2022 have been reclassified to conform to the current period presentation. See Note 1 to the condensed consolidated financial statements for further information on the change in presentation.

[0001032975-23-000080:mdna:67]
Sales by product category in the current presentation for the three and six months ended September 30, 2023 and 2022 were as follows (dollars in thousands):

[0001032975-23-000080:mdna:68]
|  |  | Three months ended September 30, |  | Six months ended September 30, |
|  |  | 2023 |  | 2022 |  | Change |  | 2023 |  | 2022 |  | Change |
| Gaming (1) |  | $ | 282,104 |  |  | $ | 322,028 |  |  | (12) | % |  | $ | 548,533 |  |  | $ | 619,949 |  |  | (12) | % |
| Keyboards & Combos |  | 194,914 |  |  | 200,853 |  |  | (3) |  |  | 375,769 |  |  | 428,573 |  |  | (12) |  |
| Pointing Devices |  | 191,676 |  |  | 185,200 |  |  | 3 |  |  | 366,130 |  |  | 368,483 |  |  | (1) |  |
| Video Collaboration |  | 152,389 |  |  | 179,199 |  |  | (15) |  |  | 291,735 |  |  | 360,831 |  |  | (19) |  |
| Webcams |  | 88,222 |  |  | 102,018 |  |  | (14) |  |  | 163,422 |  |  | 211,280 |  |  | (23) |  |
| Tablet Accessories |  | 63,677 |  |  | 54,203 |  |  | 17 |  |  | 134,013 |  |  | 120,788 |  |  | 11 |  |
| Headsets |  | 44,411 |  |  | 44,750 |  |  | (1) |  |  | 81,261 |  |  | 90,693 |  |  | (10) |  |
| Other (2) |  | 39,615 |  |  | 60,700 |  |  | (35) |  |  | 70,644 |  |  | 108,219 |  |  | (35) |  |
| Total Sales |  | $ | 1,057,008 |  |  | $ | 1,148,951 |  |  | (8) | % |  | $ | 2,031,507 |  |  | $ | 2,308,816 |  |  | (12) | % |

[0001032975-23-000080:mdna:69]
[same as prior period, unchanged from 0001032975-23-000066:mdna:68]

[0001032975-23-000080:mdna:70]
[same as prior period, unchanged from 0001032975-23-000066:mdna:69]

[0001032975-23-000080:mdna:71]
[same as prior period, unchanged from 0001032975-23-000066:mdna:70]

[0001032975-23-000080:mdna:72]
Our Gaming category includes gaming mice, steering wheels, headsets, keyboards, console gaming headsets, simulation controllers, studio-quality Blue Microphones and Streamlabs services.

[0001032975-23-000080:mdna:73]
Sales of Gaming decreased 12% in each of the three and six months ended September 30, 2023, compared to the three and six months ended September 30, 2022, primarily driven by the decrease in sales of gaming steering wheels, gaming keyboards, gaming mice and Blue Microphones.

[0001032975-23-000080:mdna:74]
[same as prior period, unchanged from 0001032975-23-000066:mdna:73]

[0001032975-23-000080:mdna:75]
[same as prior period, unchanged from 0001032975-23-000066:mdna:74]

[0001032975-23-000080:mdna:76]
Sales of Keyboards & Combos decreased 3% for the three months ended September 30, 2023, compared to the three months ended September 30, 2022, primarily driven by the decrease in sales of our cordless keyboards, partially offset by an increase in sales of cordless keyboard/mice combo products. Sales of Keyboards & Combos decreased 12% for the six months ended September 30, 2023, compared to the six months ended September 30, 2022, primarily driven by the decrease in sales of cordless keyboards.

[0001032975-23-000080:mdna:77]
[same as prior period, unchanged from 0001032975-23-000066:mdna:76]

[0001032975-23-000080:mdna:78]
[same as prior period, unchanged from 0001032975-23-000066:mdna:77]

[0001032975-23-000080:mdna:79]
Sales of Pointing Devices increased 3% for the three months ended September 30, 2023, compared to the three months ended September 30, 2022, primarily driven by the increase in sales of cordless mice. Sales of Pointing Devices for the six months ended September 30, 2023 declined 1%, compared with sales for the six months ended September 30, 2022, mainly due to a decrease in the sales of cordless mice, partially offset by an increase in sales of presentation tools.

[0001032975-23-000080:mdna:80]
[same as prior period, unchanged from 0001032975-23-000066:mdna:79]

[0001032975-23-000080:mdna:81]
Our Video Collaboration category includes Logitech’s conference room cameras, which combine affordable enterprise-quality audio and high definition 4K video to bring video conferencing to a variety of room sizes.

[0001032975-23-000080:mdna:82]
Sales of Video Collaboration decreased 15% and 19% for the three and six months ended September 30, 2023, compared to the three and six months ended September 30, 2022, respectively, due to a decrease in sales of most of our Video Collaboration products driven by lower enterprise spending.

[0001032975-23-000080:mdna:83]
[same as prior period, unchanged from 0001032975-23-000066:mdna:82]

[0001032975-23-000080:mdna:84]
[same as prior period, unchanged from 0001032975-23-000066:mdna:83]

[0001032975-23-000080:mdna:85]
Sales of Webcams decreased 14% for the three months ended September 30, 2023, compared to the three months ended September 30, 2022, primarily driven by the decrease in sales of our PC-based webcams, such as 1080p Pro Stream Webcam and Brio 500, as well as our VC webcams, such as Webcam C930e. Sales of Webcams decreased 23% for the six months ended September 30, 2023, compared to the six months ended September 30, 2022, primarily driven by the decrease in sales of our VC webcams, such as Webcam C930e and Webcam C925E, as well as our PC-based webcams, such as 1080p Pro Stream Webcam.

[0001032975-23-000080:mdna:86]
[same as prior period, unchanged from 0001032975-23-000066:mdna:85]

[0001032975-23-000080:mdna:87]
[same as prior period, unchanged from 0001032975-23-000066:mdna:86]

[0001032975-23-000080:mdna:88]
Sales of Tablet Accessories increased 17% and 11% for the three and six months ended September 30, 2023, compared to the three and six months ended September 30, 2022, respectively, primarily driven by the increase in sales of our Rugged Combo 3 Touch as well as Combo Touch and Rugged Combo 4 Touch, introduced in the third quarter of fiscal year 2023. For the six months ended September 30, 2023, compared to the six months ended September 30, 2022, the increase in sales of these products was partially offset by the decrease in sales of Rugged Folio.

[0001032975-23-000080:mdna:89]
[same as prior period, unchanged from 0001032975-23-000066:mdna:88]

[0001032975-23-000080:mdna:90]
[same as prior period, unchanged from 0001032975-23-000066:mdna:89]

[0001032975-23-000080:mdna:91]
Sales of Headsets for the three months ended September 30, 2023 remained consistent with sales for the three months ended September 30, 2022. Sales of Headsets decreased 10% for the six months ended September 30, 2023, compared to the six months ended September 30, 2022, primarily driven by the decrease in sales of VC headsets and corded PC headsets.

[0001032975-23-000080:mdna:92]
[same as prior period, unchanged from 0001032975-23-000066:mdna:91]

[0001032975-23-000080:mdna:93]
[same as prior period, unchanged from 0001032975-23-000066:mdna:92]

[0001032975-23-000080:mdna:94]
Sales in Other category decreased 35% in each of the three and six months ended September 30, 2023, compared to the three and six months ended September 30, 2022, primarily driven by a decline in sales of mobile speakers.

[0001032975-23-000080:mdna:95]
[same as prior period, unchanged from 0001032975-23-000066:mdna:94]

[0001032975-23-000080:mdna:96]
Gross profit for the three and six months ended September 30, 2023 and 2022 was as follows (dollars in thousands):

[0001032975-23-000080:mdna:97]
|  |  | Three months ended September 30, |  | Six months ended September 30, |
|  |  | 2023 |  | 2022 |  | Change |  | 2023 |  | 2022 |  | Change |
| Net sales |  | $ | 1,057,008 |  |  | $ | 1,148,951 |  |  | (8) | % |  | $ | 2,031,507 |  |  | $ | 2,308,816 |  |  | (12) | % |
| Gross profit |  | $ | 438,622 |  |  | $ | 438,780 |  |  | — | % |  | $ | 814,264 |  |  | $ | 898,383 |  |  | (9) | % |
| Gross margin |  | 41.5 | % |  | 38.2 | % |  |  |  | 40.1 | % |  | 38.9 | % |  |  |

[0001032975-23-000080:mdna:98]
[same as prior period, unchanged from 0001032975-23-000066:mdna:97]

[0001032975-23-000080:mdna:99]
Gross margin was 41.5% and 40.1% for the three and six months ended September 30, 2023, respectively, and increased by 330 and 120 basis points, compared to the three and six months ended September 30, 2022, respectively. The increase in gross margin for the three months ended September 30, 2023, compared to the three months ended September 30, 2022, was primarily driven by cost improvement and less reliance on expedited shipping, as well as lower promotions, partially offset by unfavorable product mix. The increase in gross margin for the six months ended September 30, 2023, compared to the six months ended September 30, 2022, was primarily driven by cost improvement and less reliance on expedited shipping, partially offset by unfavorable product mix.

[0001032975-23-000080:mdna:100]
[same as prior period, unchanged from 0001032975-23-000066:mdna:99]

[0001032975-23-000080:mdna:101]
Operating expenses for the three and six months ended September 30, 2023 and 2022 were as follows (dollars in thousands):

[0001032975-23-000080:mdna:102]
|  |  | Three months ended September 30, |  | Six months ended September 30, |  |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |  |
| Marketing and selling |  | $ | 176,356 |  |  | $ | 202,091 |  |  | $ | 355,541 |  |  | $ | 431,469 |  |  |
| % of sales |  | 16.7 | % |  | 17.6 | % |  | 17.5 | % |  | 18.7 | % |  |
| Research and development |  | 68,559 |  |  | 69,009 |  |  | 139,118 |  |  | 144,526 |  |  |
| % of sales |  | 6.5 | % |  | 6.0 | % |  | 6.8 | % |  | 6.3 | % |  |
| General and administrative |  | 35,538 |  |  | 26,589 |  |  | 76,835 |  |  | 62,449 |  |  |
| % of sales |  | 3.4 | % |  | 2.3 | % |  | 3.8 | % |  | 2.7 | % |  |
| Amortization of intangible assets and acquisition-related costs |  | 3,318 |  |  | 2,873 |  |  | 6,003 |  |  | 6,242 |  |  |
| % of sales |  | 0.3 | % |  | 0.3 | % |  | 0.3 | % |  | 0.3 | % |  |
| Restructuring charges (credits), net |  | (1,788) |  |  | 10,817 |  |  | 1,723 |  |  | 10,817 |  |  |
| % of sales |  | (0.2) | % |  | 0.9 | % |  | 0.1 | % |  | 0.5 | % |  |
| Total operating expenses |  | $ | 281,983 |  |  | $ | 311,379 |  |  | $ | 579,220 |  |  | $ | 655,503 |  |  |
| % of sales |  | 26.7 | % |  | 27.1 | % |  | 28.5 | % |  | 28.4 | % |  |

[0001032975-23-000080:mdna:103]
The decrease in total operating expenses during the three and six months ended September 30, 2023, compared to the three and six months ended September 30, 2022, was mainly due to decreases in marketing and selling expenses, partially offset by increases to general and administrative expenses.

[0001032975-23-000080:mdna:104]
[same as prior period, unchanged from 0001032975-23-000066:mdna:103]

[0001032975-23-000080:mdna:105]
[same as prior period, unchanged from 0001032975-23-000066:mdna:104]

[0001032975-23-000080:mdna:106]
During the three and six months ended September 30, 2023, marketing and selling expenses decreased $25.7 million and $75.9 million, respectively, compared to the three and six months ended September 30, 2022, primarily driven by our reduction in third-party marketing and advertising spend as well as decreases in personnel-related costs as a result of headcount reduction.

[0001032975-23-000080:mdna:107]
[same as prior period, unchanged from 0001032975-23-000066:mdna:106]

[0001032975-23-000080:mdna:108]
[same as prior period, unchanged from 0001032975-23-000066:mdna:107]

[0001032975-23-000080:mdna:109]
During the three months ended September 30, 2023, research and development expenses remained relatively consistent, compared to the three months ended September 30, 2022. During the six months ended September 30, 2023, research and development expenses decreased $5.4 million, compared to the six months ended September 30, 2022, primarily driven by lower outsourcing expenses.

[0001032975-23-000080:mdna:110]
Research and development expenses as a percentage of sales increased from 6.0% and 6.3% in the three and six months ended September 30, 2022, respectively, to 6.5% and 6.8% in the three and six months ended September 30, 2023, respectively, reflecting our continued investment in innovation.

[0001032975-23-000080:mdna:111]
[same as prior period, unchanged from 0001032975-23-000066:mdna:109]

[0001032975-23-000080:mdna:112]
[same as prior period, unchanged from 0001032975-23-000066:mdna:110]

[0001032975-23-000080:mdna:113]
During the three and six months ended September 30, 2023, general and administrative expenses increased $8.9 million and $14.4 million, respectively, compared to the three and six months ended September 30, 2022, primarily driven by higher personnel-related costs, mainly due to higher accruals for performance-based compensation.

[0001032975-23-000080:mdna:114]
[same as prior period, unchanged from 0001032975-23-000066:mdna:112]

[0001032975-23-000080:mdna:115]
[same as prior period, unchanged from 0001032975-23-000066:mdna:113]

[0001032975-23-000080:mdna:116]
During the three and six months ended September 30, 2023, amortization of intangible assets and acquisition-related costs remained relatively flat, compared to the three and six months ended September 30, 2022.

[0001032975-23-000080:mdna:117]
Restructuring Charges (Credits), Net

[0001032975-23-000080:mdna:118]
The restructuring charges (credits), net for the three and six months ended September 30, 2023 and 2022, were related to costs incurred as a result of our restructuring plan initiated during fiscal year 2023. We expect to substantially complete this restructuring plan within fiscal year 2024.

[0001032975-23-000080:mdna:119]
[same as prior period, unchanged from 0001032975-23-000066:mdna:117]

[0001032975-23-000080:mdna:120]
[same as prior period, unchanged from 0001032975-23-000066:mdna:118]

[0001032975-23-000080:mdna:121]
Interest income for the three and six months ended September 30, 2023 and 2022 was as follows (in thousands):

[0001032975-23-000080:mdna:122]
|  |  | Three months ended September 30, |  | Six months ended September 30, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Interest Income |  | $ | 11,856 |  |  | $ | 3,459 |  |  | $ | 21,682 |  |  | $ | 4,908 |  |

[0001032975-23-000080:mdna:123]
We invest in highly liquid instruments with an original maturity of three months or less at the date of purchase, which are classified as cash equivalents. During the three and six months ended September 30, 2023, interest income increased $8.4 million and $16.8 million, respectively, compared to the three and six months ended September 30, 2022, primarily driven by the increase in interest rates.

[0001032975-23-000080:mdna:124]
[same as prior period, unchanged from 0001032975-23-000066:mdna:122]

[0001032975-23-000080:mdna:125]
Other income (expense), net for the three and six months ended September 30, 2023 and 2022 was as follows (in thousands):

[0001032975-23-000080:mdna:126]
|  |  | Three months ended September 30, |  | Six months ended September 30, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Investment gain (loss) related to the deferred compensation plan |  | $ | (324) |  |  | $ | (762) |  |  | $ | 700 |  |  | $ | (4,148) |  |
| Currency exchange loss, net |  | (1,712) |  |  | (2,052) |  |  | (4,798) |  |  | (5,012) |  |
| Gain (loss) on investments, net |  | 214 |  |  | (22,934) |  |  | (11,609) |  |  | (11,577) |  |
| Non-service cost net pension income and other |  | 778 |  |  | 351 |  |  | 1,691 |  |  | 964 |  |
| Total |  | $ | (1,044) |  |  | $ | (25,397) |  |  | $ | (14,016) |  |  | $ | (19,773) |  |

[0001032975-23-000080:mdna:127]
Investment gain (loss) related to the deferred compensation plan represents earnings, gains, and losses on marketable securities related to a deferred compensation plan offered by one of our subsidiaries. The investment gain or loss for three and six months ended September 30, 2023, compared to the three and six months ended September 30, 2022, primarily relates to the change in market performance of the underlying securities.

[0001032975-23-000080:mdna:128]
Currency exchange loss, net, relates to balances denominated in currencies other than the functional currency in our subsidiaries, as well as to the sale of currencies, and gains or losses recognized on currency exchange forward contracts. We do not speculate in currency positions, but we are alert to opportunities to maximize currency exchange gains and minimize currency exchange losses. The loss for the three months ended September 30, 2023 was primarily due to the weakening of the Swiss Franc against the U.S. Dollar. The loss for the three months ended September 30, 2022 was primarily due to the weakening of the Australian Dollar and the Brazilian Real against the U.S. Dollar offset by gains in the Swiss Franc. The loss for the six months ended September 30, 2023 was primarily due to weakening of the Japanese Yen against the U.S. Dollar. The loss for the six months ended September 30, 2022 was primarily due to the weakening of the Brazilian Real, Australian Dollar, and the Japanese Yen, offset by the gain from the weakening of the Chinese Renminbi against the U.S. Dollar.

[0001032975-23-000080:mdna:129]
Gain (loss) on investments, net, includes unrealized gain (loss) from the fair value change of investment, gain (loss) on equity-method investments and impairment of investments during the periods presented, as applicable. The loss on investments, net for the six months ended September 30, 2023 was primarily due to an impairment loss, as a result of the write-off of a note receivable which has been deemed no longer recoverable. This note receivable was previously obtained in conjunction with an exchange transaction related to our investment in a privately held company. The loss for the three and six months ended September 30, 2022 was primarily due to impairment charges related to one of our equity method investments. The loss for the six months ended September 30, 2022 was partially offset by an unrealized gain related to one of our equity method investments without readily determinable fair value resulting from observable price changes. See Note 6 to our condensed consolidated financial statements for additional information.

[0001032975-23-000080:mdna:130]
[same as prior period, unchanged from 0001032975-23-000066:mdna:128]

[0001032975-23-000080:mdna:131]
The provision for income taxes and effective income tax rates for the three and six months ended September 30, 2023 and 2022 were as follows (dollars in thousands):

[0001032975-23-000080:mdna:132]
|  |  | Three months ended September 30, |  | Six months ended September 30, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Provision for income taxes |  | $ | 30,334 |  |  | $ | 23,372 |  |  | $ | 42,866 |  |  | $ | 45,088 |  |
| Effective income tax rate |  | 18.1 | % |  | 22.2 | % |  | 17.7 | % |  | 19.8 | % |

[0001032975-23-000080:mdna:133]
The change in the effective income tax rate for the three and six months ended September 30, 2023 was primarily due to the mix of income and losses in the various tax jurisdictions in which we operate and the tax impact from share-based compensation, compared with the three and six months ended September 30, 2022.

[0001032975-23-000080:mdna:134]
[same as prior period, unchanged from 0001032975-23-000066:mdna:132]

[0001032975-23-000080:mdna:135]
[same as prior period, unchanged from 0001032975-23-000066:mdna:133]

[0001032975-23-000080:mdna:136]
As of September 30, 2023, we had cash and cash equivalents of $1,163.9 million, compared with $1,149.0 million as of March 31, 2023. Our cash and cash equivalents consist of bank demand deposits and short-term time deposits, of which 65% is held in Switzerland and 12% were held in China (including Hong Kong). We do not expect to incur any material adverse tax impact except for what has already been recognized, or to be significantly inhibited by any country in which we do business, from the repatriation of funds to Switzerland, our country of domicile.

[0001032975-23-000080:mdna:137]
As of September 30, 2023, our working capital was $1,405.3 million, compared to $1,555.1 million as of March 31, 2023. The decrease was driven by a reduction in inventories and an increase in accounts payable, partially offset by a decline in accrued and other current liabilities and an increase in accounts receivable.

[0001032975-23-000080:mdna:138]
We had several uncommitted, unsecured bank lines of credit and letters of credit aggregating $171.5 million as of September 30, 2023. There are no financial covenants under these lines of credit with which we must comply.

[0001032975-23-000080:mdna:139]
There was no borrowing outstanding under the lines of credit as of September 30, 2023. As of September 30, 2023, we had outstanding bank guarantees of $12.2 million under these lines of credit.

[0001032975-23-000080:mdna:140]
The following tables present selected financial information and statistics as of and for the three months ended September 30, 2023 and 2022 (dollars in thousands):

[0001032975-23-000080:mdna:141]
|  |  | As of September 30, |  |
|  |  | 2023 |  | 2022 |  |
| Accounts receivable, net |  | $ | 656,895 |  |  | $ | 772,731 |  |  |
| Accounts payable |  | $ | 492,905 |  |  | $ | 546,563 |  |  |
| Inventories |  | $ | 532,943 |  |  | $ | 879,979 |  |  |

[0001032975-23-000080:mdna:142]
|  |  | Three months ended September 30, |  |
|  |  | 2023 |  | 2022 |  |
| Days sales in accounts receivable (“DSO”) (Days)(1) |  | 56 |  |  | 61 |  |  |
| Days accounts payable outstanding (“DPO”) (Days)(2) |  | 72 |  |  | 69 |  |  |
| Inventory turnover (“ITO”) (x)(3) |  | 4.6 |  |  | 3.2 |  |  |

[0001032975-23-000080:mdna:143]
[same as prior period, unchanged from 0001032975-23-000066:mdna:140]

[0001032975-23-000080:mdna:144]
[same as prior period, unchanged from 0001032975-23-000066:mdna:141]

[0001032975-23-000080:mdna:145]
[same as prior period, unchanged from 0001032975-23-000066:mdna:142]

[0001032975-23-000080:mdna:146]
DSO for the three months ended September 30, 2023 decreased by 5 days to 56 days, compared to 61 days for the three months ended September 30, 2022, primarily due to the timing of sales within the quarter.

[0001032975-23-000080:mdna:147]
DPO for the three months ended September 30, 2023 increased by 3 days to 72 days, compared to 69 days for the three months ended September 30, 2022, primarily due to softened demand, offset by lower inventory purchases and marketing spend.

[0001032975-23-000080:mdna:148]
ITO for the three months ended September 30, 2023 increased by 1.4, compared to 3.2 for the three months ended September 30, 2022, primarily due to lower inventory as of September 30, 2023 resulting from focused inventory management to align with softened demand.

[0001032975-23-000080:mdna:149]
[same as prior period, unchanged from 0001032975-23-000066:mdna:146]

[0001032975-23-000080:mdna:150]
The following table summarizes our condensed consolidated statements of cash flows (in thousands):

[0001032975-23-000080:mdna:151]
|  |  | Six months ended September 30, |
|  |  | 2023 |  | 2022 |
| Net cash provided by operating activities |  | $ | 463,059 |  |  | $ | 37,256 |  |
| Net cash used in investing activities |  | (49,151) |  |  | (53,561) |  |
| Net cash used in financing activities |  | (388,269) |  |  | (416,087) |  |
| Effect of exchange rate changes on cash and cash equivalents |  | (10,758) |  |  | (27,823) |  |
| Net increase (decrease) in cash and cash equivalents |  | $ | 14,881 |  |  | $ | (460,215) |  |

[0001032975-23-000080:mdna:152]
For the six months ended September 30, 2023, net cash provided by operating activities was $463.1 million resulting from net income of $199.8 million, a favorable impact from adding back non-cash expenses totaling $112.1 million, and a favorable net change in operating assets and liabilities of $151.2 million. Non-cash expenses were primarily related to share-based compensation expenses, and depreciation and amortization. The increase in accounts receivable, net was primarily driven by higher sales. The decrease in inventories was primarily driven by our effort to manage inventory level. The increase in accounts payable was due to timing of inventory purchases in preparation for the holiday season. The decrease in accrued and other liabilities was primarily driven by reduction in accrued liabilities related to our customer marketing, pricing and incentive programs and sales return liability in line with reduction in channel inventory.

[0001032975-23-000080:mdna:153]
For the six months ended September 30, 2023, net cash used in investing activities was $49.2 million, primarily resulting from $34.7 million of purchases of property, plant, and equipment and $14.1 million payments for acquisitions, net of cash acquired.

[0001032975-23-000080:mdna:154]
For the six months ended September 30, 2023, net cash used in financing activities was $388.3 million, primarily resulting from payment for repurchases of our registered shares of $188.9 million and payment of cash dividends of $182.3 million.

[0001032975-23-000080:mdna:155]
For the six months ended September 30, 2023, there was a $10.8 million loss from currency exchange rate effect on cash and cash equivalents, primarily due to exchange rate fluctuations of Swiss Franc, Euro, and Chinese Renminbi versus the U.S. Dollar, and timing of our cash transactions over the period. The loss from currency translation exchange rate effect during the six months ended September 30, 2022 was primarily due to the weakening of the Euro, Chinese Renminbi, Swiss Franc, Australian Dollar, New Taiwan Dollar and the Japanese Yen versus the U.S. Dollar.

[0001032975-23-000080:mdna:156]
[same as prior period, unchanged from 0001032975-23-000066:mdna:153]

[0001032975-23-000080:mdna:157]
Our principal sources of liquidity are our cash and cash equivalents, cash flow generated from operations, and, to a much lesser extent, capital markets and borrowings. Our future working capital requirements and capital expenditures may increase to support investments in product innovations and growth opportunities or to acquire or invest in complementary businesses, products, services, and technologies. Market volatility driven by the current macroeconomic and geopolitical environment may increase our costs of capital and otherwise adversely affect our business, results of operations, financial condition and liquidity.

[0001032975-23-000080:mdna:158]
In fiscal year 2024, we paid a cash dividend of CHF 169.1 million (U.S. Dollar amount of $182.3 million based on the exchange rate on the date of payment) out of fiscal year 2023 retained earnings. In fiscal year 2023, we paid a cash dividend of CHF 156.1 million (U.S. Dollar amount of $158.7 million based on the exchange rate on the date of payment) out of fiscal year 2022 retained earnings. In fiscal year 2022, we paid a cash dividend of CHF 147.0 million (U.S. Dollar amount of $159.4 million) out of fiscal year 2021 retained earnings.

[0001032975-23-000080:mdna:159]
In May 2020, our Board of Directors approved the 2020 share repurchase program, which authorized us to invest up to $250.0 million to purchase our own shares to support equity incentive plans or potential acquisitions. In April 2021, our Board of Directors approved an increase of $750.0 million to the 2020 share repurchase program, to an aggregate amount of $1.0 billion. The Swiss Takeover Board approved this increase and it became effective on May 21, 2021. In July 2022, our Board of Directors approved an increase of $500 million to the 2020 share repurchase program to an aggregate amount of up to $1.5 billion. The Swiss Takeover Board approved this increase and it became effective on August 19, 2022. The 2020 share repurchase program expired on July 27, 2023. We repurchased 16.7 million shares for an aggregate cost of $1.2 billion under the 2020 share repurchase program, of which 2.6 million shares for an aggregate cost of $159.1 million were repurchased during the six months ended September 30, 2023.

[0001032975-23-000080:mdna:160]
In June 2023, our Board of Directors approved a new, three-year share repurchase program, which allows us to use up to $1.0 billion to repurchase our shares. The 2023 share repurchase program enables us to repurchase shares for cancellation, as well as to support equity incentive plans or potential acquisitions. The Swiss Takeover Board approved the 2023 share repurchase program in July 2023 and the program became effective on July 28, 2023. During the six months ended September 30, 2023, we repurchased 0.9 million shares for an aggregate cost of $60.1 million under the 2023 share repurchase program for the purpose of cancellation, of which $30.2 million of the aggregate cost was not paid yet as of September 30, 2023. As of September 30, 2023, $940.0 million was available for repurchase under the 2023 share repurchase program.

[0001032975-23-000080:mdna:161]
Swiss law limits a company’s ability to hold or repurchase its own shares. The aggregate par value of all shares held in treasury by us and our subsidiaries may not exceed 10% of our share capital, which corresponds to

[0001032975-23-000080:mdna:162]
approximately 17.3 million registered shares. This limitation does not apply to shares repurchased for cancellation, due to the Board of Directors' authority under the capital band set forth in the Company's Articles of Incorporation to cancel shares up to a limit of 10% of our current share capital. As of September 30, 2023, we had a total of 16.0 million shares held in treasury stock, which includes 0.9 million shares that have been repurchased for cancellation.

[0001032975-23-000080:mdna:163]
Although we enter into trading plans for systematic repurchases (e.g., 10b5-1 trading plans) from time to time, our 2023 share repurchase program provides us with the opportunity to make opportunistic repurchases during periods of favorable market conditions and is expected to remain in effect for a period of three years through July 27, 2026. To the extent that the shares are repurchased to support equity incentive plans or potential acquisitions, the share are repurchased on the ordinary trading line of Swiss Exchange ("SIX") and/or the Nasdaq Global Select Market ("Nasdaq"). Shares repurchased for cancellation purposes are repurchased via a second trading line on SIX. Opportunistic purchases may be started or stopped at any time without prior notice depending on market conditions and other factors.

[0001032975-23-000080:mdna:164]
[same as prior period, unchanged from 0001032975-23-000066:mdna:159]

[0001032975-23-000080:mdna:165]
[same as prior period, unchanged from 0001032975-23-000066:mdna:160]

[0001032975-23-000080:mdna:166]
[same as prior period, unchanged from 0001032975-23-000066:mdna:161]

[0001032975-23-000080:mdna:167]
[same as prior period, unchanged from 0001032975-23-000066:mdna:162]

[0001032975-23-000080:mdna:168]
As of September 30, 2023, we had non-cancelable purchase commitments of $391.5 million for inventory purchases made in the normal course of business from original design manufacturers, contract manufacturers and other suppliers, the majority of which are expected to be fulfilled within the next 12 months. We record a liability for firm, non-cancelable, and unhedged inventory purchase commitments in excess of anticipated demand or net realizable value consistent with our valuation of excess and obsolete inventory. As of September 30, 2023, the liability for these purchase commitments was $33.2 million and is recorded in accrued and other current liabilities in the condensed consolidated balance sheet.

[0001032975-23-000080:mdna:169]
We have firm purchase commitments of $10.7 million for capital expenditures primarily related to commitments for tooling and equipment for new and existing products. We expect to continue making capital expenditures in the future to support product development activities and ongoing and expanded operations. Although open purchase commitments are considered enforceable and legally binding, the terms generally allow us to reschedule or adjust our requirements based on business needs prior to delivery of goods or performance of services.

[0001032975-23-000080:mdna:170]
[same as prior period, unchanged from 0001032975-23-000066:mdna:165]

[0001032975-23-000080:mdna:171]
[same as prior period, unchanged from 0001032975-23-000066:mdna:166]

[0001032975-23-000080:mdna:172]
[same as prior period, unchanged from 0001032975-23-000066:mdna:167]

[0001032975-23-000080:mdna:173]
We indemnify certain suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of September 30, 2023, no material amounts have been accrued for indemnification provisions. We do not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under our indemnification arrangements.

[0001032975-23-000080:mdna:174]
We also indemnify our current and former directors and certain current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. We are unable to reasonably estimate the maximum amount that could be payable under these arrangements because these

[0001032975-23-000080:mdna:175]
exposures are not capped, the obligations are conditional in nature, and the facts and circumstances involved in any situation that might arise are variable.

[0001032975-23-000080:mdna:176]
Legal Proceedings

[0001032975-23-000080:mdna:177]
From time to time we are involved in claims and legal proceedings that arise in the ordinary course of our business. For more information about Legal Proceedings, see Part II Item 1 Legal Proceedings of this quarterly report on Form 10-Q for the period ended September 30, 2023.
