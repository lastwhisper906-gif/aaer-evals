# LOGI note change history — 0001032975-23-000066 → 0001032975-23-000080


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-10-26):
[0001032975-23-000080:note_history:1]
Changes in the Company’s warranty liabilities for the three and six months ended September 30, 2023 and 2022 were as follows (in thousands):
  (was, 2023-07-27, similarity 0.9243):
[0001032975-23-000066:note_history:1]
Changes in the Company’s warranty liabilities for the three months ended June 30, 2023 and 2022 were as follows (in thousands):

- added (2023-10-26):
[0001032975-23-000080:note_history:2]
|  | Three months ended September 30, |  | Six months ended September 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Beginning of the period | $ | 39,885 |  |  | $ | 43,841 |  |  | $ | 40,886 |  |  | $ | 46,219 |  |
| Provision | 10,393 |  |  | 7,897 |  |  | 19,485 |  |  | 14,520 |  |
| Settlements | (9,838) |  |  | (9,098) |  |  | (19,756) |  |  | (17,379) |  |
| Effects of foreign currency translation | (175) |  |  | (680) |  |  | (350) |  |  | (1,400) |  |
| End of the period | $ | 40,265 |  |  | $ | 41,960 |  |  | $ | 40,265 |  |  | $ | 41,960 |  |

- changed (2023-10-26):
[0001032975-23-000080:note_history:3]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of September 30, 2023, no material amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.
  (was, 2023-07-27, similarity 0.99):
[0001032975-23-000066:note_history:3]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of June 30, 2023, no material amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

- added (2023-10-26):
[0001032975-23-000080:note_history:4]
From time to time the Company is involved in claims and legal proceedings that arise in the ordinary course of its business. The Company is currently subject to several such claims and legal proceedings. The Company intends to vigorously defend against them. Management periodically assesses the Company’s liabilities and contingencies in connection with these matters based upon the latest information available. The Company follows ASC ("Accounting Standards Codification") 450 in determining the accounting and disclosure for these contingencies. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows and results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company's defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company's business, financial condition, cash flows and results of operations in a particular period. Any claims or proceedings against the Company can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain a necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company's business.

- removed (2023-10-26):
[0001032975-23-000066:note_history:5]
|  |  |  | Three months ended June 30, |
|  |  |  |  |  | 2023 |  | 2022 |
| Beginning of the period |  |  |  |  | $ | 40,886 |  |  | $ | 46,219 |  |
| Provision |  |  |  |  | 9,092 |  |  | 6,623 |  |
| Settlements |  |  |  |  | (9,918) |  |  | (8,281) |  |
| Effects of foreign currency translation |  |  |  |  | (175) |  |  | (720) |  |
| End of the period |  |  |  |  | $ | 39,885 |  |  | $ | 43,841 |  |

- removed (2023-10-26):
[0001032975-23-000066:note_history:6]
From time to time the Company is involved in claims and legal proceedings that arise in the ordinary course of its business. The Company is currently subject to several such claims and a small number of legal proceedings. The Company believes that these matters lack merit and intends to vigorously defend against them. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows and results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company's defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company's business, financial condition, cash flows and results of operations in a particular period. Any claims or proceedings against the Company, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain a necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company's business.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-10-26):
[0001032975-23-000080:note_history:7]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and six months ended September 30, 2023 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2024, or any future periods.
  (was, 2023-07-27, similarity 0.7702):
[0001032975-23-000066:note_history:7]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three months ended June 30, 2023 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2024, or any future periods.

- changed (2023-10-26):
[0001032975-23-000080:note_history:8]
As a result of these changes, certain prior-period amounts for the three and six months ended September 30, 2022 have been reclassified to conform to the current period presentation as follows (in thousands):
  (was, 2023-07-27, similarity 0.9517):
[0001032975-23-000066:note_history:8]
As a result of these changes, certain prior-period amounts for the three months ended June 30, 2022 have been reclassified to conform to the current period presentation as follows (in thousands):

- added (2023-10-26):
[0001032975-23-000080:note_history:9]
|  |  | Three months ended September 30, 2022 |
|  |  | As previously reported |  | Reclassifications |  | As adjusted |
| Gaming |  | $ | 297,676 |  |  | $ | 24,352 |  | (1) | $ | 322,028 |  |
| Keyboards & Combos |  | 200,853 |  |  | — |  |  | 200,853 |  |
| Pointing Devices |  | 185,200 |  |  | — |  |  | 185,200 |  |
| Video Collaboration |  | 236,180 |  |  | (56,981) |  | (2) (3) | 179,199 |  |
| Webcams (3) |  | 60,166 |  |  | 41,852 |  | (3) | 102,018 |  |
| Tablet Accessories |  | 54,203 |  |  | — |  |  | 54,203 |  |
| Headsets |  | — |  |  | 44,750 |  | (2) | 44,750 |  |
| Other |  | 2,207 |  |  | 58,493 |  | (4) (5) | 60,700 |  |
| Mobile Speakers |  | 39,195 |  |  | (39,195) |  | (4) | — |  |
| Audio & Wearables |  | 73,271 |  |  | (73,271) |  | (1) (2) (5) | — |  |
| Total Sales |  | $ | 1,148,951 |  |  | $ | — |  |  | $ | 1,148,951 |  |

- added (2023-10-26):
[0001032975-23-000080:note_history:10]
|  |  | Six months ended September 30, 2022 |
|  |  | As previously reported |  | Reclassifications |  | As adjusted |
| Gaming |  | $ | 580,482 |  |  | $ | 39,467 |  | (1) | $ | 619,949 |  |
| Keyboards & Combos |  | 428,573 |  |  | — |  |  | 428,573 |  |
| Pointing Devices |  | 368,483 |  |  | — |  |  | 368,483 |  |
| Video Collaboration |  | 482,422 |  |  | (121,591) |  | (2) (3) | 360,831 |  |
| Webcams (3) |  | 119,552 |  |  | 91,728 |  | (3) | 211,280 |  |
| Tablet Accessories |  | 120,788 |  |  | — |  |  | 120,788 |  |
| Headsets |  | — |  |  | 90,693 |  | (2) | 90,693 |  |
| Other |  | 4,294 |  |  | 103,925 |  | (4) (5) | 108,219 |  |
| Mobile Speakers |  | 61,505 |  |  | (61,505) |  | (4) | — |  |
| Audio & Wearables |  | 142,717 |  |  | (142,717) |  | (1) (2) (5) | — |  |
| Total Sales |  | $ | 2,308,816 |  |  | $ | — |  |  | $ | 2,308,816 |  |

- changed (2023-10-26):
[0001032975-23-000080:note_history:11]
There have been no material changes in the Company’s significant accounting policies during the three and six months ended September 30, 2023 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2023.
  (was, 2023-07-27, similarity 0.9091):
[0001032975-23-000066:note_history:11]
There have been no material changes in the Company’s significant accounting policies during the three months ended June 30, 2023 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2023.

- changed (2023-10-26):
[0001032975-23-000080:note_history:12]
The Company's business has been impacted by adverse macroeconomic and geopolitical conditions. These conditions include inflation, interest rate and foreign currency fluctuations, slowdown of economic activity around the world, and lower consumer and enterprise spending.
  (was, 2023-07-27, similarity 0.7549):
[0001032975-23-000066:note_history:12]
The Company's business has been impacted by adverse macroeconomic and geopolitical conditions. These conditions include inflation, interest rate and foreign currency fluctuations, slowdown of economic activity around the world, and lower consumer and enterprise spending. In addition, the war in Ukraine resulted in global supply chain, logistics, and inflationary challenges. The Company has had no revenue in Russia and Ukraine since fiscal year

- changed (2023-10-26):
[0001032975-23-000080:note_history:13]
The global and regional economic and political conditions adversely affect demand for the Company's products. These conditions also had an impact on the Company's suppliers, contract manufacturers, logistics providers, and distributors, causing volatility in cost of materials and shipping and transportation rates, and as a result, impacting the pricing of the Company's products.
  (was, 2023-07-27, similarity 0.9987):
[0001032975-23-000066:note_history:13]
The global and regional economic and political conditions adversely affect demand for the Company's products. These conditions also had an impact on the Company's suppliers, contract manufacturers, logistics providers, and distributors, causing volatility in cost of materials and shipping and transportation rates, and as a result impacting the pricing of the Company's products.

- removed (2023-10-26):
[0001032975-23-000066:note_history:14]
|  |  | As previously reported |  | Reclassifications |  | As adjusted |
| Gaming |  | $ | 282,806 |  |  | $ | 15,115 |  | (1) | $ | 297,921 |  |
| Keyboards & Combos |  | 227,720 |  |  | — |  |  | 227,720 |  |
| Pointing Devices |  | 183,283 |  |  | — |  |  | 183,283 |  |
| Video Collaboration |  | 246,242 |  |  | (64,610) |  | (2) (3) | 181,632 |  |
| Webcams (3) |  | 59,386 |  |  | 49,876 |  | (3) | 109,262 |  |
| Tablet Accessories |  | 66,585 |  |  | — |  |  | 66,585 |  |
| Headsets |  | — |  |  | 45,943 |  | (2) | 45,943 |  |
| Other |  | 2,087 |  |  | 45,432 |  | (4) (5) | 47,519 |  |
| Mobile Speakers |  | 22,310 |  |  | (22,310) |  | (4) | — |  |
| Audio & Wearables |  | 69,446 |  |  | (69,446) |  | (1) (2) (5) | — |  |
| Total Sales |  | $ | 1,159,865 |  |  | $ | — |  |  | $ | 1,159,865 |  |

- removed (2023-10-26):
[0001032975-23-000066:note_history:15]
2023 as it has indefinitely ceased all sales and shipments to Russia and sales in Ukraine have also been halted due to the ongoing military operations on the Ukrainian territory.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2023-10-26):
[0001032975-23-000080:note_history:16]
Financing Arrangements The Company had several uncommitted, unsecured bank lines of credit and letters of credit aggregating $171.5 million and $181.3 million as of September 30, 2023 and March 31, 2023, respectively. There are no financial covenants under the lines of credit with which the Company must comply. There was no borrowing outstanding under the lines of credit as of September 30, 2023 or March 31, 2023. As of September 30, 2023 and March 31, 2023, the Company had outstanding bank guarantees of $12.2 million and $13.6 million, respectively.

- removed (2023-10-26):
[0001032975-23-000066:note_history:17]
Financing Arrangements The Company had several uncommitted, unsecured bank lines of credit and letters of credit aggregating $172.0 million and $181.3 million as of June 30, 2023 and March 31, 2023, respectively. There are no financial covenants under the lines of credit with which the Company must comply. There was no borrowing outstanding under the lines of credit as of June 30, 2023 or March 31, 2023. As of June 30, 2023 and March 31, 2023, the Company had outstanding bank guarantees of $9.2 million and $13.6 million, respectively.
