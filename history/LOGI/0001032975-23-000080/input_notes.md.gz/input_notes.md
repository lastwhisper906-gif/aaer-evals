# LOGI notes — 0001032975-23-000080


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001032975-23-000080:notes:1]
[same as prior period, unchanged from 0001032975-23-000066:notes:1]

[0001032975-23-000080:notes:2]
[same as prior period, unchanged from 0001032975-23-000066:notes:2]

[0001032975-23-000080:notes:3]
[same as prior period, unchanged from 0001032975-23-000066:notes:3]

[0001032975-23-000080:notes:4]
[same as prior period, unchanged from 0001032975-23-000066:notes:4]

[0001032975-23-000080:notes:5]
[same as prior period, unchanged from 0001032975-23-000066:notes:5]

[0001032975-23-000080:notes:6]
[same as prior period, unchanged from 0001032975-23-000066:notes:6]

[0001032975-23-000080:notes:7]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and six months ended September 30, 2023 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2024, or any future periods.

[0001032975-23-000080:notes:8]
[same as prior period, unchanged from 0001032975-23-000066:notes:8]

[0001032975-23-000080:notes:9]
[same as prior period, unchanged from 0001032975-23-000066:notes:9]

[0001032975-23-000080:notes:10]
[same as prior period, unchanged from 0001032975-23-000066:notes:10]

[0001032975-23-000080:notes:11]
[same as prior period, unchanged from 0001032975-23-000066:notes:11]

[0001032975-23-000080:notes:12]
[same as prior period, unchanged from 0001032975-23-000066:notes:12]

[0001032975-23-000080:notes:13]
[same as prior period, unchanged from 0001032975-23-000066:notes:13]

[0001032975-23-000080:notes:14]
As a result of these changes, certain prior-period amounts for the three and six months ended September 30, 2022 have been reclassified to conform to the current period presentation as follows (in thousands):

[0001032975-23-000080:notes:15]
|  |  | Three months ended September 30, 2022 |
|  |  | As previously reported |  | Reclassifications |  | As adjusted |
| Gaming |  | $ | 297,676 |  |  | $ | 24,352 |  | (1) | $ | 322,028 |  |
| Keyboards & Combos |  | 200,853 |  |  | — |  |  | 200,853 |  |
| Pointing Devices |  | 185,200 |  |  | — |  |  | 185,200 |  |
| Video Collaboration |  | 236,180 |  |  | (56,981) |  | (2) (3) | 179,199 |  |
| Webcams (3) |  | 60,166 |  |  | 41,852 |  | (3) | 102,018 |  |
| Tablet Accessories |  | 54,203 |  |  | — |  |  | 54,203 |  |
| Headsets |  | — |  |  | 44,750 |  | (2) | 44,750 |  |
| Other |  | 2,207 |  |  | 58,493 |  | (4) (5) | 60,700 |  |
| Mobile Speakers |  | 39,195 |  |  | (39,195) |  | (4) | — |  |
| Audio & Wearables |  | 73,271 |  |  | (73,271) |  | (1) (2) (5) | — |  |
| Total Sales |  | $ | 1,148,951 |  |  | $ | — |  |  | $ | 1,148,951 |  |

[0001032975-23-000080:notes:16]
|  |  | Six months ended September 30, 2022 |
|  |  | As previously reported |  | Reclassifications |  | As adjusted |
| Gaming |  | $ | 580,482 |  |  | $ | 39,467 |  | (1) | $ | 619,949 |  |
| Keyboards & Combos |  | 428,573 |  |  | — |  |  | 428,573 |  |
| Pointing Devices |  | 368,483 |  |  | — |  |  | 368,483 |  |
| Video Collaboration |  | 482,422 |  |  | (121,591) |  | (2) (3) | 360,831 |  |
| Webcams (3) |  | 119,552 |  |  | 91,728 |  | (3) | 211,280 |  |
| Tablet Accessories |  | 120,788 |  |  | — |  |  | 120,788 |  |
| Headsets |  | — |  |  | 90,693 |  | (2) | 90,693 |  |
| Other |  | 4,294 |  |  | 103,925 |  | (4) (5) | 108,219 |  |
| Mobile Speakers |  | 61,505 |  |  | (61,505) |  | (4) | — |  |
| Audio & Wearables |  | 142,717 |  |  | (142,717) |  | (1) (2) (5) | — |  |
| Total Sales |  | $ | 2,308,816 |  |  | $ | — |  |  | $ | 2,308,816 |  |

[0001032975-23-000080:notes:17]
[same as prior period, unchanged from 0001032975-23-000066:notes:16]

[0001032975-23-000080:notes:18]
[same as prior period, unchanged from 0001032975-23-000066:notes:17]

[0001032975-23-000080:notes:19]
[same as prior period, unchanged from 0001032975-23-000066:notes:18]

[0001032975-23-000080:notes:20]
[same as prior period, unchanged from 0001032975-23-000066:notes:19]

[0001032975-23-000080:notes:21]
[same as prior period, unchanged from 0001032975-23-000066:notes:20]

[0001032975-23-000080:notes:22]
[same as prior period, unchanged from 0001032975-23-000066:notes:21]

[0001032975-23-000080:notes:23]
There have been no material changes in the Company’s significant accounting policies during the three and six months ended September 30, 2023 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2023.

[0001032975-23-000080:notes:24]
[same as prior period, unchanged from 0001032975-23-000066:notes:23]

[0001032975-23-000080:notes:25]
[same as prior period, unchanged from 0001032975-23-000066:notes:24]

[0001032975-23-000080:notes:26]
[same as prior period, unchanged from 0001032975-23-000066:notes:25]

[0001032975-23-000080:notes:27]
[same as prior period, unchanged from 0001032975-23-000066:notes:26]

[0001032975-23-000080:notes:28]
The Company's business has been impacted by adverse macroeconomic and geopolitical conditions. These conditions include inflation, interest rate and foreign currency fluctuations, slowdown of economic activity around the world, and lower consumer and enterprise spending.

[0001032975-23-000080:notes:29]
The global and regional economic and political conditions adversely affect demand for the Company's products. These conditions also had an impact on the Company's suppliers, contract manufacturers, logistics providers, and distributors, causing volatility in cost of materials and shipping and transportation rates, and as a result, impacting the pricing of the Company's products.


## us-gaap:EarningsPerShareTextBlock

[0001032975-23-000080:notes:30]
[same as prior period, unchanged from 0001032975-23-000066:notes:30]

[0001032975-23-000080:notes:31]
The following table summarizes the computations of basic and diluted net income per share for the three and six months ended September 30, 2023 and 2022 (in thousands, except per share amounts):

[0001032975-23-000080:notes:32]
|  |  | Three months ended September 30, |  | Six months ended September 30, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Net income |  | $ | 137,117 |  |  | $ | 82,091 |  |  | $ | 199,844 |  |  | $ | 182,927 |  |
| Shares used in net income per share computation: |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding - basic |  | 157,911 |  |  | 163,186 |  |  | 158,385 |  |  | 163,937 |  |
| Effect of potentially dilutive equivalent shares |  | 1,023 |  |  | 1,142 |  |  | 1,160 |  |  | 1,434 |  |
| Weighted average shares outstanding - diluted |  | 158,934 |  |  | 164,328 |  |  | 159,545 |  |  | 165,371 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.87 |  |  | $ | 0.50 |  |  | $ | 1.26 |  |  | $ | 1.12 |  |
| Diluted |  | $ | 0.86 |  |  | $ | 0.50 |  |  | $ | 1.25 |  |  | $ | 1.11 |  |

[0001032975-23-000080:notes:33]
Share equivalents attributable to outstanding stock options, restricted stock units and employee share purchase plans totaling 1.1 million and 1.7 million for the three months ended September 30, 2023 and 2022, respectively, and 1.6 million and 2.6 million for the six months ended September 30, 2023 and 2022, respectively, were excluded from the calculation of diluted net income per share because their effect would have been anti-dilutive. A small number of performance-based restricted stock units were not included in the dilutive net income per share calculation because all necessary conditions had not been satisfied by the end of the respective period, and those shares were not issuable if the end of the reporting period were the end of the performance contingency period.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001032975-23-000080:notes:34]
[same as prior period, unchanged from 0001032975-23-000066:notes:34]

[0001032975-23-000080:notes:35]
[same as prior period, unchanged from 0001032975-23-000066:notes:35]

[0001032975-23-000080:notes:36]
As of September 30, 2023, the Company offers the 2006 Employee Share Purchase Plan (Non-U.S.), as amended and restated ("2006 ESPP"), the 1996 Employee Share Purchase Plan (U.S.), as amended and restated ("1996 ESPP"), and the 2006 Stock Incentive Plan ("2006 Plan") as amended and restated. Shares issued to employees as a result of purchases or exercises under these plans are generally issued from shares held in treasury stock.

[0001032975-23-000080:notes:37]
The following table summarizes the share-based compensation expense and total income tax benefit recognized for share-based awards for the three and six months ended September 30, 2023 and 2022 (in thousands):

[0001032975-23-000080:notes:38]
|  |  | Three months ended September 30, |  | Six months ended September 30, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Cost of goods sold |  | $ | 2,462 |  |  | $ | 1,443 |  |  | $ | 3,877 |  |  | $ | 2,904 |  |
| Marketing and selling |  | 9,262 |  |  | 7,429 |  |  | 19,745 |  |  | 17,226 |  |
| Research and development |  | 4,694 |  |  | 3,280 |  |  | 9,147 |  |  | 8,812 |  |
| General and administrative |  | 5,650 |  |  | 93 |  |  | 10,810 |  |  | 6,993 |  |
| Total share-based compensation expense |  | 22,068 |  |  | 12,245 |  |  | 43,579 |  |  | 35,935 |  |
| Income tax expense (benefit) |  | (2,548) |  |  | 102 |  |  | (7,866) |  |  | (4,220) |  |
| Total share-based compensation expense, net of income tax expense (benefit) |  | $ | 19,520 |  |  | $ | 12,347 |  |  | $ | 35,713 |  |  | $ | 31,715 |  |

[0001032975-23-000080:notes:39]
[same as prior period, unchanged from 0001032975-23-000066:notes:39]

[0001032975-23-000080:notes:40]
Share-based compensation costs capitalized as part of inventory were $1.5 million and $1.3 million for the three months ended September 30, 2023 and 2022, respectively, and $3.4 million and $3.1 million for the six months ended September 30, 2023 and 2022, respectively.

[0001032975-23-000080:notes:41]
[same as prior period, unchanged from 0001032975-23-000066:notes:41]

[0001032975-23-000080:notes:42]
Certain of the Company’s subsidiaries sponsor defined benefit pension plans or non-retirement post-employment benefits covering substantially all of their employees. Benefits are provided based on employees’ years of service and earnings, or in accordance with applicable employee benefit regulations. The Company’s practice is to fund amounts sufficient to meet the requirements set forth in the applicable employee benefit and tax regulations. The costs of $1.9 million and $2.8 million recorded for the three months ended September 30, 2023 and 2022, respectively, and $3.8 million and $5.6 million recorded for the six months ended September 30, 2023 and 2022, respectively, were primarily related to service costs.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001032975-23-000080:notes:43]
[same as prior period, unchanged from 0001032975-23-000066:notes:43]

[0001032975-23-000080:notes:44]
[same as prior period, unchanged from 0001032975-23-000066:notes:44]

[0001032975-23-000080:notes:45]
The income tax provision for the three and six months ended September 30, 2023 was $30.3 million and $42.9 million based on an effective income tax rate of 18.1% and 17.7% of pre-tax income, respectively. The income tax provision for the same periods ended September 30, 2022 was $23.4 million and $45.1 million based on effective income tax rate of 22.2% and 19.8% of pre-tax income, respectively.

[0001032975-23-000080:notes:46]
The change in the effective income tax rate for the three and six months ended September 30, 2023, compared with the same periods ended September 30, 2022 was primarily due to the mix of income and losses in the various tax jurisdictions in which the Company operates and the tax impact from share-based compensation.

[0001032975-23-000080:notes:47]
Although the Company has adequately provided for uncertain tax positions, the provisions related to these positions may change as revised estimates are made or the underlying matters are settled or otherwise resolved. During fiscal year 2024, the Company continues to review its tax positions and to provide for or reverse unrecognized tax benefits as they arise. During the next twelve months, while it is reasonably possible that the amount of unrecognized tax benefits could increase or decrease significantly, it is not possible to provide a range of potential changes. 
On August 16, 2022, the “Inflation Reduction Act” (H.R. 5376) ("IRA") was signed into law in the United States. The IRA establishes a new corporate alternative minimum tax based on financial statement income adjusted for certain items. The new minimum tax is effective for tax years beginning after December 31, 2022. The IRA is not expected to have a material impact to the Company's financial statements for the tax year ending March 31, 2024.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001032975-23-000080:notes:48]
[same as prior period, unchanged from 0001032975-23-000066:notes:48]

[0001032975-23-000080:notes:49]
[same as prior period, unchanged from 0001032975-23-000066:notes:49]

[0001032975-23-000080:notes:50]
|  |  | September 30, 2023 |  | March 31, 2023 |
| Accounts receivable, net: |  |  |  |  |
| Accounts receivable |  | $ | 882,607 |  |  | $ | 851,576 |  |
| Allowance for doubtful accounts |  | (16) |  |  | (86) |  |
| Allowance for sales returns |  | (10,898) |  |  | (10,146) |  |
| Allowance for cooperative marketing arrangements |  | (37,781) |  |  | (40,495) |  |
| Allowance for customer incentive programs |  | (63,082) |  |  | (71,645) |  |
| Allowance for pricing programs |  | (113,935) |  |  | (98,822) |  |
|  |  | $ | 656,895 |  |  | $ | 630,382 |  |
| Inventories: |  |  |  |  |
| Raw materials |  | $ | 92,083 |  |  | $ | 171,790 |  |
| Finished goods |  | 440,860 |  |  | 511,103 |  |
|  |  | $ | 532,943 |  |  | $ | 682,893 |  |
| Other current assets: |  |  |  |  |
| Value-added tax ("VAT") receivables |  | $ | 51,651 |  |  | $ | 60,343 |  |
| Prepaid expenses and other assets |  | 86,831 |  |  | 82,533 |  |
|  |  | $ | 138,482 |  |  | $ | 142,876 |  |
| Property, plant and equipment, net: |  |  |  |  |
| Property, plant and equipment |  | $ | 510,881 |  |  | $ | 518,358 |  |
| Less: accumulated depreciation and amortization |  | (388,854) |  |  | (396,855) |  |
|  |  | $ | 122,027 |  |  | $ | 121,503 |  |
| Other assets: |  |  |  |  |
| Deferred tax assets |  | $ | 163,053 |  |  | $ | 171,989 |  |
| Right-of-use assets |  | 61,823 |  |  | 67,330 |  |
| Investments in privately held companies |  | 31,544 |  |  | 33,323 |  |
| Investments for deferred compensation plan |  | 28,546 |  |  | 28,213 |  |
| Other assets |  | 6,331 |  |  | 15,438 |  |
|  |  | $ | 291,297 |  |  | $ | 316,293 |  |

[0001032975-23-000080:notes:51]
[same as prior period, unchanged from 0001032975-23-000066:notes:51]

[0001032975-23-000080:notes:52]
|  |  | September 30, 2023 |  | March 31, 2023 |
| Accrued and other current liabilities: |  |  |  |  |
| Accrued customer marketing, pricing and incentive programs |  | $ | 187,559 |  |  | $ | 206,546 |  |
| Accrued personnel expenses |  | 95,279 |  |  | 103,592 |  |
| Accrued loss for inventory purchase commitments |  | 33,157 |  |  | 46,608 |  |
| Accrued sales return liability |  | 33,906 |  |  | 49,462 |  |
| Warranty liabilities |  | 28,085 |  |  | 28,861 |  |
| VAT payable |  | 22,480 |  |  | 33,328 |  |
| Income taxes payable |  | 26,354 |  |  | 18,788 |  |
| Operating lease liabilities |  | 14,099 |  |  | 12,655 |  |
| Contingent consideration |  | 1,700 |  |  | 6,629 |  |
| Other current liabilities |  | 151,423 |  |  | 136,670 |  |
|  |  | $ | 594,042 |  |  | $ | 643,139 |  |
| Other non-current liabilities: |  |  |  |  |
| Operating lease liabilities |  | $ | 59,673 |  |  | $ | 58,361 |  |
| Employee benefit plan obligations |  | 30,241 |  |  | 32,421 |  |
| Obligation for deferred compensation plan |  | 28,546 |  |  | 28,213 |  |
| Warranty liabilities |  | 12,180 |  |  | 12,025 |  |
| Deferred tax liabilities |  | 2,528 |  |  | 2,803 |  |
| Other non-current liabilities |  | 13,415 |  |  | 12,872 |  |
|  |  | $ | 146,583 |  |  | $ | 146,695 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001032975-23-000080:notes:53]
[same as prior period, unchanged from 0001032975-23-000066:notes:53]

[0001032975-23-000080:notes:54]
[same as prior period, unchanged from 0001032975-23-000066:notes:54]

[0001032975-23-000080:notes:55]
[same as prior period, unchanged from 0001032975-23-000066:notes:55]

[0001032975-23-000080:notes:56]
[same as prior period, unchanged from 0001032975-23-000066:notes:56]

[0001032975-23-000080:notes:57]
[same as prior period, unchanged from 0001032975-23-000066:notes:57]

[0001032975-23-000080:notes:58]
[same as prior period, unchanged from 0001032975-23-000066:notes:58]

[0001032975-23-000080:notes:59]
|  |  | September 30, 2023 |  | March 31, 2023 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Level 1 |  | Level 2 |  | Level 3 |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 712,451 |  |  | $ | — |  |  | $ | — |  |  | $ | 661,884 |  |  | $ | — |  |  | $ | — |  |
| Investments for deferred compensation plan included in other assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 82 |  |  | $ | — |  |  | $ | — |  |  | $ | 41 |  |  | $ | — |  |  | $ | — |  |
| Common stock |  | 1,139 |  |  | — |  |  | — |  |  | 988 |  |  | — |  |  | — |  |
| Money market funds |  | 10,544 |  |  | — |  |  | — |  |  | 9,606 |  |  | — |  |  | — |  |
| Mutual funds |  | 16,781 |  |  | — |  |  | — |  |  | 17,578 |  |  | — |  |  | — |  |
| Total investments for deferred compensation plan |  | $ | 28,546 |  |  | $ | — |  |  | $ | — |  |  | $ | 28,213 |  |  | $ | — |  |  | $ | — |  |
| Currency derivative assetsincluded in other current assets |  | $ | — |  |  | $ | 2,446 |  |  | $ | — |  |  | $ | — |  |  | $ | 107 |  |  | $ | — |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Contingent consideration included in accrued and other current liabilities |  | $ | — |  |  | $ | — |  |  | $ | 1,700 |  |  | $ | — |  |  | $ | — |  |  | $ | 6,629 |  |
| Currency derivative liabilitiesincluded in accrued and other current liabilities |  | $ | — |  |  | $ | 86 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,187 |  |  | $ | — |  |

[0001032975-23-000080:notes:60]
[same as prior period, unchanged from 0001032975-23-000066:notes:60]

[0001032975-23-000080:notes:61]
The following table summarizes the change in the Company's contingent consideration balance during the six months ended September 30, 2023 and 2022 (in thousands):

[0001032975-23-000080:notes:62]
|  |  | Six months ended September 30, |
|  |  | 2023 |  | 2022 |
| Beginning of the period |  | $ | 6,629 |  |  | $ | 12,259 |  |
| Fair value of contingent consideration upon acquisition |  | — |  |  | 1,142 |  |
| Payments of contingent consideration |  | (5,002) |  |  | (5,954) |  |
| Effect of foreign currency exchange rate changes |  | 73 |  |  | (2,119) |  |
| End of the period |  | $ | 1,700 |  |  | $ | 5,328 |  |

[0001032975-23-000080:notes:63]
The contingent consideration arising from a technology acquisition on May 19, 2021, represented the future potential earn-out payments of up to $10.0 million payable in cash upon the achievement of three technical development milestones to be completed as of December 31, 2021, June 30, 2022, and June 30, 2023. The fair value of the contingent consideration was $10.0 million at the acquisition date, which was determined using a probability-weighted expected payment model and discounted at the estimated cost of debt. During fiscal year 2022, the Company paid $0.9 million for the contingent consideration related to the first technical development milestone. During fiscal year 2023, the Company paid $4.0 million for the contingent consideration related to the second technical development milestone. During the six months ended September 30, 2023, the Company paid $3.3 million for the contingent consideration related to the third technical development milestone.

[0001032975-23-000080:notes:64]
The contingent consideration arising from a technology acquisition on January 4, 2021, represented the future potential earn-out payments of up to $3.0 million payable in cash upon the achievement of two technical development milestones to be completed as of December 31, 2021 and March 31, 2022. The fair value of the contingent consideration was determined using a probability-weighted expected payment model and discounted at the estimated cost of debt. During fiscal year 2023, the Company paid $2.0 million for the contingent consideration related to the first technical development milestone. During the six months ended September 30, 2023, the Company paid $1.0 million for the contingent consideration related to the second technical development milestone.

[0001032975-23-000080:notes:65]
[same as prior period, unchanged from 0001032975-23-000066:notes:67]

[0001032975-23-000080:notes:66]
The marketable securities for the Company's deferred compensation plan were recorded at a fair value of $28.5 million and $28.2 million, as of September 30, 2023 and March 31, 2023, respectively, based on quoted market prices. Quoted market prices are observable inputs that are classified as Level 1 within the fair value hierarchy. Unrealized gains (losses) related to marketable securities for the three and six months ended September 30, 2023 and 2022 were not material and were included in other income (expense), net, and corresponding changes in the deferred compensation liability were included in operating expenses and cost of goods sold, in the Company's condensed consolidated statements of operations.

[0001032975-23-000080:notes:67]
[same as prior period, unchanged from 0001032975-23-000066:notes:69]

[0001032975-23-000080:notes:68]
The Company has certain non-marketable investments included in other assets that are accounted for as equity method investments, with a carrying value of $18.5 million and $20.5 million as of September 30, 2023 and March 31, 2023, respectively. Gains (losses) related to equity method investments for the three and six months ended September 30, 2023 and 2022 were not material and are included in other income (expense), net, in the Company's condensed consolidated statements of operations.

[0001032975-23-000080:notes:69]
During the three months ended September 30, 2022, the Company recorded an impairment charge, before tax, of $21.4 million for one of its equity method investments as it was determined that the carrying value of the investment was not recoverable. The impairment charge is included in other income (expense), net, in the Company's condensed consolidated statements of operations for the three and six months ended September 30, 2022. There was no impairment of equity method investments during the three and six months ended September 30, 2023.

[0001032975-23-000080:notes:70]
[same as prior period, unchanged from 0001032975-23-000066:notes:71]

[0001032975-23-000080:notes:71]
[same as prior period, unchanged from 0001032975-23-000066:notes:72]

[0001032975-23-000080:notes:72]
The Company has certain equity investments without readily determinable fair values due to the absence of quoted market prices, the inherent lack of liquidity, and the fact that inputs used to measure fair value are unobservable and require management's judgment. When certain events or circumstances indicate that impairment may exist, the Company revalues the investments using various assumptions, including the financial metrics and ratios of comparable public companies. The carrying value is also adjusted for observable price changes with the same or similar security from the same issuer. The amount of these equity investments without readily determinable fair values included in other assets was $12.6 million as of September 30, 2023 and March 31, 2023. During the six months ended September 30, 2022, the Company recorded an unrealized gain, before tax, of $6.9 million for its investment in a private company as a result of observable price changes for similar securities issued by this company (level 2 fair value measurement). There was no impairment of these financial assets during the three and six months ended September 30, 2023 and 2022, other than an immaterial impairment charge related to one of the Company's investments without readily determinable fair value recorded during the three months ended September 30, 2022.

[0001032975-23-000080:notes:73]
During the six months ended September 30, 2023, the Company recorded an impairment loss, before tax, of $9.6 million as a result of the write-off of a note receivable which has been deemed no longer recoverable. This note receivable was previously obtained in conjunction with an exchange transaction related to the Company's investment in a privately held company. The impairment loss is included in other income (expense), net, in the Company's condensed consolidated statement of operations for the six months ended September 30, 2023.

[0001032975-23-000080:notes:74]
Non-Financial Assets
Goodwill, intangible assets, and property, plant and equipment, are not required to be measured at fair value on a recurring basis. However, if the Company is required to evaluate these non-financial assets for impairment, whether due to certain triggering events or because of the required annual impairment test, and a resulting impairment is recorded to reduce the carrying value to the fair value, the non-financial assets are measured at fair value during such period. There was no impairment of non-financial assets during the three and six months ended September 30, 2023 and 2022.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001032975-23-000080:notes:75]
[same as prior period, unchanged from 0001032975-23-000066:notes:76]

[0001032975-23-000080:notes:76]
Under certain agreements with the respective counterparties to the Company’s derivative contracts, subject to applicable requirements, the Company is allowed to net settle transactions of the same type with a single net amount payable by one party to the other. However, the Company presents its derivative assets and derivative liabilities on a gross basis in other current assets and accrued and other current liabilities, respectively, on the condensed consolidated balance sheets as of September 30, 2023 and March 31, 2023. See Note 6 for the fair values of the Company’s derivative instruments as of September 30, 2023 and March 31, 2023.

[0001032975-23-000080:notes:77]
[same as prior period, unchanged from 0001032975-23-000066:notes:78]

[0001032975-23-000080:notes:78]
[same as prior period, unchanged from 0001032975-23-000066:notes:79]

[0001032975-23-000080:notes:79]
The notional amounts of foreign currency exchange forward contracts outstanding related to forecasted inventory purchases were $119.2 million and $72.6 million as of September 30, 2023 and March 31, 2023, respectively. The Company had $1.8 million of net gains related to its cash flow hedges included in accumulated other comprehensive loss as of September 30, 2023, which will be reclassified into earnings within the next twelve months.

[0001032975-23-000080:notes:80]
The following table presents the amounts of gain (loss) on the Company’s derivative instruments designated as hedging instruments for the three and six months ended September 30, 2023 and 2022 and their locations on its condensed consolidated statements of operations and condensed consolidated statements of comprehensive income (in thousands):

[0001032975-23-000080:notes:81]
|  |  | Three months ended September 30, |
|  |  | Amount of GainDeferred as a Component of AccumulatedOther Comprehensive Loss |  | Amount of Loss (Gain)Reclassified from Accumulated Other Comprehensive Loss to Costs of Goods Sold |  |  |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |  |  |  |  |
| Cash flow hedges |  | $ | 2,078 |  |  | $ | 4,935 |  |  | $ | 1,370 |  |  | $ | (4,947) |  |  |  |  |  |
|  |  | Six months ended September 30, |
|  |  | Amount of GainDeferred as a Component of AccumulatedOther Comprehensive Loss |  | Amount of Loss (Gain)Reclassified from Accumulated Other Comprehensive Loss to Costs of Goods Sold |  |  |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |  |  |  |  |
| Cash flow hedges |  | $ | 1,374 |  |  | $ | 11,564 |  |  | $ | 4,356 |  |  | $ | (7,038) |  |  |  |  |  |

[0001032975-23-000080:notes:82]
[same as prior period, unchanged from 0001032975-23-000066:notes:83]

[0001032975-23-000080:notes:83]
[same as prior period, unchanged from 0001032975-23-000066:notes:84]

[0001032975-23-000080:notes:84]
The Company also enters into foreign currency exchange forward and swap contracts to reduce the short-term effects of currency exchange rate fluctuations on certain receivables or payables denominated in currencies other than the functional currencies of its subsidiaries. These contracts generally mature within approximately one month. The primary risk managed by using forward and swap contracts is the currency exchange rate risk. The gains or losses on these contracts are not material and included in other income (expense), net, in the condensed consolidated statements of operations based on the changes in fair value. The notional amounts of these contracts outstanding as of September 30, 2023 and March 31, 2023 were $121.6 million and $111.2 million, respectively. Foreign currency exchange forward and swap contracts outstanding as of September 30, 2023 primarily consisted of contracts in Canadian Dollar, Brazilian Real, and Australian Dollar to be settled at future dates at predetermined exchange rates.

[0001032975-23-000080:notes:85]
[same as prior period, unchanged from 0001032975-23-000066:notes:86]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001032975-23-000080:notes:86]
Goodwill and Other Intangible Assets
The Company conducts its impairment analysis of goodwill annually at December 31 or more frequently if changes in facts and circumstances indicate that it is more likely than not that the fair value of the Company’s reporting unit may be less than its carrying amount. There have been no triggering events identified affecting the valuation of goodwill and intangible assets during the three and six months ended September 30, 2023 and 2022.

[0001032975-23-000080:notes:87]
[same as prior period, unchanged from 0001032975-23-000066:notes:88]

[0001032975-23-000080:notes:88]
| As of March 31, 2023 |  | $ | 454,610 |  |
| Acquisition |  | 8,117 |  |
| Effects of foreign currency translation |  | (1,326) |  |
| As of September 30, 2023 |  | $ | 461,401 |  |

[0001032975-23-000080:notes:89]
[same as prior period, unchanged from 0001032975-23-000066:notes:90]

[0001032975-23-000080:notes:90]
|  |  | September 30, 2023 |  | March 31, 2023 |
|  |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |
| Trademarks and trade names |  | $ | 35,290 |  |  | $ | (27,172) |  |  | $ | 8,118 |  |  | $ | 36,790 |  |  | $ | (26,774) |  |  | $ | 10,016 |  |
| Developed technology |  | 115,221 |  |  | (89,742) |  |  | 25,479 |  |  | 121,730 |  |  | (94,792) |  |  | 26,938 |  |
| Customer contracts/relationships |  | 71,587 |  |  | (49,768) |  |  | 21,819 |  |  | 71,110 |  |  | (47,688) |  |  | 23,422 |  |
| In-process R&D |  | 3,526 |  |  | — |  |  | 3,526 |  |  | 3,526 |  |  | — |  |  | 3,526 |  |
| Effects of foreign currency translation |  | (1,273) |  |  | 412 |  |  | (861) |  |  | (1,021) |  |  | 292 |  |  | (729) |  |
| Total |  | $ | 224,351 |  |  | $ | (166,270) |  |  | $ | 58,081 |  |  | $ | 232,135 |  |  | $ | (168,962) |  |  | $ | 63,173 |  |


## us-gaap:DebtDisclosureTextBlock

[0001032975-23-000080:notes:91]
Financing Arrangements The Company had several uncommitted, unsecured bank lines of credit and letters of credit aggregating $171.5 million and $181.3 million as of September 30, 2023 and March 31, 2023, respectively. There are no financial covenants under the lines of credit with which the Company must comply. There was no borrowing outstanding under the lines of credit as of September 30, 2023 or March 31, 2023. As of September 30, 2023 and March 31, 2023, the Company had outstanding bank guarantees of $12.2 million and $13.6 million, respectively.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001032975-23-000080:notes:92]
Commitments and Contingencies

[0001032975-23-000080:notes:93]
Product Warranties

[0001032975-23-000080:notes:94]
Changes in the Company’s warranty liabilities for the three and six months ended September 30, 2023 and 2022 were as follows (in thousands):

[0001032975-23-000080:notes:95]
|  | Three months ended September 30, |  | Six months ended September 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Beginning of the period | $ | 39,885 |  |  | $ | 43,841 |  |  | $ | 40,886 |  |  | $ | 46,219 |  |
| Provision | 10,393 |  |  | 7,897 |  |  | 19,485 |  |  | 14,520 |  |
| Settlements | (9,838) |  |  | (9,098) |  |  | (19,756) |  |  | (17,379) |  |
| Effects of foreign currency translation | (175) |  |  | (680) |  |  | (350) |  |  | (1,400) |  |
| End of the period | $ | 40,265 |  |  | $ | 41,960 |  |  | $ | 40,265 |  |  | $ | 41,960 |  |

[0001032975-23-000080:notes:96]
Indemnifications

[0001032975-23-000080:notes:97]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of September 30, 2023, no material amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

[0001032975-23-000080:notes:98]
The Company also indemnifies its current and former directors and certain of its current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. The Company is unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not limited, the obligations are conditional in nature and the facts and circumstances involved in any situation that might arise are variable.

[0001032975-23-000080:notes:99]
Legal Proceedings

[0001032975-23-000080:notes:100]
From time to time the Company is involved in claims and legal proceedings that arise in the ordinary course of its business. The Company is currently subject to several such claims and legal proceedings. The Company intends to vigorously defend against them. Management periodically assesses the Company’s liabilities and contingencies in connection with these matters based upon the latest information available. The Company follows ASC ("Accounting Standards Codification") 450 in determining the accounting and disclosure for these contingencies. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows and results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company's defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company's business, financial condition, cash flows and results of operations in a particular period. Any claims or proceedings against the Company can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain a necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company's business.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001032975-23-000080:notes:101]
[same as prior period, unchanged from 0001032975-23-000066:notes:102]

[0001032975-23-000080:notes:102]
[same as prior period, unchanged from 0001032975-23-000066:notes:103]

[0001032975-23-000080:notes:103]
In May 2020, the Company's Board of Directors approved the 2020 share repurchase program, which authorized the Company to use up to $250.0 million to purchase Logitech shares to support equity incentive plans or potential acquisitions. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Purchases may be started or stopped at any time without prior notice depending on market conditions and other factors. In April 2021, the Company's Board of Directors approved an increase of $750.0 million to the

[0001032975-23-000080:notes:104]
2020 share repurchase program, to an aggregate amount of $1.0 billion. The Swiss Takeover Board approved this increase and it became effective on May 21, 2021. In July 2022, the Company’s Board of Directors approved an increase of $500 million to the 2020 share repurchase program, to an aggregate amount of up to $1.5 billion. The Swiss Takeover Board approved this increase and it became effective on August 19, 2022. The 2020 share repurchase program expired on July 27, 2023. The Company repurchased 16.7 million shares for an aggregate cost of $1.2 billion under the 2020 share repurchase program, of which 2.6 million shares for an aggregate cost of $159.1 million were repurchased during the six months ended September 30, 2023.

[0001032975-23-000080:notes:105]
[same as prior period, unchanged from 0001032975-23-000066:notes:105]

[0001032975-23-000080:notes:106]
In June 2023, the Company's Board of Directors approved a new, three-year share repurchase program, which allows the Company to use up to $1.0 billion to repurchase its shares. The 2023 share repurchase program enables the Company to repurchase shares for cancellation, as well as to support equity incentive plans or potential acquisitions. The Swiss Takeover Board approved the 2023 share repurchase program in July 2023 and the program became effective on July 28, 2023. During the six months ended September 30, 2023, the Company repurchased 0.9 million shares for an aggregate cost of $60.1 million under the 2023 share repurchase program for cancellation, of which $30.2 million of the aggregate cost was not paid yet as of September 30, 2023. As of September 30, 2023, $940.0 million was available for repurchase under the 2023 share repurchase program.

[0001032975-23-000080:notes:107]
Swiss law limits a company’s ability to hold or repurchase its own shares. The aggregate par value of all shares held in treasury by the Company and its subsidiaries may not exceed 10% of the share capital of the Company, which for the Company corresponds to approximately 17.3 million registered shares. This limitation does not apply to shares repurchased for cancellation, due to the Board of Directors’ authority under the Company’s capital band set forth in the Company’s Articles of Incorporation to cancel shares up to a limit of 10% of the Company's current share capital. As of September 30, 2023, the Company had a total of 16.0 million shares held in treasury stock, which includes 0.9 million shares that have been repurchased for cancellation.

[0001032975-23-000080:notes:108]
To the extent that the shares are repurchased to support equity incentive plans or potential acquisitions, the shares are repurchased on the ordinary trading line of SIX Swiss Exchange (“SIX”) and/or The Nasdaq Global Select Market (“Nasdaq”). Shares repurchased for cancellation purposes are repurchased on a second trading line on SIX. Shares may be repurchased from time to time on the open market or in privately negotiated transactions, including under plans complying with the provisions of Rule 10b5-1 and Rule 10b-18 of the Securities Exchange Act of 1934, as amended. Purchases may be started or stopped at any time without prior notice depending on market conditions and other factors and the program does not require the purchase of any minimum number of shares.

[0001032975-23-000080:notes:109]
Dividends

[0001032975-23-000080:notes:110]
During the three and six months ended September 30, 2023, the Company declared and paid cash dividends of CHF 1.06 (USD equivalent of $1.19 based on the exchange rate on the date of declaration) per share, totaling $187.2 million on the Company's outstanding shares. During the three and six months ended September 30, 2022, the Company declared and paid cash dividends of CHF 0.96 (USD equivalent of $1.00 based on the exchange rate on the date of declaration) per share, totaling $162.7 million on the Company's outstanding shares.

[0001032975-23-000080:notes:111]
Any future dividends will be subject to approval of the Company's shareholders.

[0001032975-23-000080:notes:112]
[same as prior period, unchanged from 0001032975-23-000066:notes:107]

[0001032975-23-000080:notes:113]
[same as prior period, unchanged from 0001032975-23-000066:notes:108]

[0001032975-23-000080:notes:114]
|  |  | Cumulative Translation Adjustment |  | Defined Benefit Plans |  | Deferred Hedging Gains (Losses) |  | Total |
| March 31, 2023 |  | $ | (100,869) |  |  | $ | 4,525 |  |  | $ | (3,933) |  |  | $ | (100,277) |  |
| Other comprehensive income (loss) |  | (12,151) |  |  | (248) |  |  | 5,730 |  |  | (6,669) |  |
| September 30, 2023 |  | $ | (113,020) |  |  | $ | 4,277 |  |  | $ | 1,797 |  |  | $ | (106,946) |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001032975-23-000080:notes:115]
[same as prior period, unchanged from 0001032975-23-000066:notes:110]

[0001032975-23-000080:notes:116]
[same as prior period, unchanged from 0001032975-23-000066:notes:111]

[0001032975-23-000080:notes:117]
During the first quarter of fiscal year 2024, the Company changed its presentation of Sales by Product Category to provide a simpler and clearer view of the Company's business. The change in presentation did not have an impact on previously reported total sales. As a result of these changes, certain prior-period amounts for the three and six months ended September 30, 2022 have been reclassified to conform to the current period presentation. See Note 1 for further information on the change in presentation.

[0001032975-23-000080:notes:118]
Sales by product category in the current presentation for the three and six months ended September 30, 2023 and 2022 were as follows (in thousands):

[0001032975-23-000080:notes:119]
|  |  | Three months ended September 30, |  | Six months ended September 30, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Gaming (1) |  | $ | 282,104 |  |  | $ | 322,028 |  |  | $ | 548,533 |  |  | $ | 619,949 |  |
| Keyboards & Combos |  | 194,914 |  |  | 200,853 |  |  | 375,769 |  |  | 428,573 |  |
| Pointing Devices |  | 191,676 |  |  | 185,200 |  |  | 366,130 |  |  | 368,483 |  |
| Video Collaboration |  | 152,389 |  |  | 179,199 |  |  | 291,735 |  |  | 360,831 |  |
| Webcams |  | 88,222 |  |  | 102,018 |  |  | 163,422 |  |  | 211,280 |  |
| Tablet Accessories |  | 63,677 |  |  | 54,203 |  |  | 134,013 |  |  | 120,788 |  |
| Headsets |  | 44,411 |  |  | 44,750 |  |  | 81,261 |  |  | 90,693 |  |
| Other (2) |  | 39,615 |  |  | 60,700 |  |  | 70,644 |  |  | 108,219 |  |
| Total Sales |  | $ | 1,057,008 |  |  | $ | 1,148,951 |  |  | $ | 2,031,507 |  |  | $ | 2,308,816 |  |

[0001032975-23-000080:notes:120]
[same as prior period, unchanged from 0001032975-23-000066:notes:115]

[0001032975-23-000080:notes:121]
[same as prior period, unchanged from 0001032975-23-000066:notes:116]

[0001032975-23-000080:notes:122]
Sales by geographic region (based on the customers’ locations) for the three and six months ended September 30, 2023 and 2022 were as follows (in thousands):

[0001032975-23-000080:notes:123]
|  |  | Three months ended September 30, |  | Six months ended September 30, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Americas |  | $ | 462,406 |  |  | $ | 492,176 |  |  | $ | 907,574 |  |  | $ | 994,483 |  |
| EMEA |  | 311,805 |  |  | 297,176 |  |  | 570,683 |  |  | 587,655 |  |
| Asia Pacific |  | 282,797 |  |  | 359,599 |  |  | 553,250 |  |  | 726,678 |  |
| Total Sales |  | $ | 1,057,008 |  |  | $ | 1,148,951 |  |  | $ | 2,031,507 |  |  | $ | 2,308,816 |  |

[0001032975-23-000080:notes:124]
[same as prior period, unchanged from 0001032975-23-000066:notes:119]

[0001032975-23-000080:notes:125]
Switzerland, the Company’s country of domicile, represented 3.0% and 2.0% of the Company's total consolidated sales for the three months ended September 30, 2023 and 2022, respectively, and 2.0% for each of the six months ended September 30, 2023 and 2022.

[0001032975-23-000080:notes:126]
Three customers of the Company each represented 10% or more of the total consolidated gross sales for each of the three and six months ended September 30, 2023 and 2022.

[0001032975-23-000080:notes:127]
[same as prior period, unchanged from 0001032975-23-000066:notes:122]

[0001032975-23-000080:notes:128]
|  |  | September 30, 2023 |  | March 31, 2023 |
| Americas |  | $ | 69,504 |  |  | $ | 59,183 |  |
| EMEA |  | 32,950 |  |  | 38,890 |  |
| Asia Pacific |  | 58,778 |  |  | 69,939 |  |
| Total |  | $ | 161,233 |  |  | $ | 168,012 |  |

[0001032975-23-000080:notes:129]
Property, plant and equipment, net (excluding software) and right-of-use assets in the United States, China, and Ireland were $69.0 million, $40.2 million and $16.6 million, respectively, as of September 30, 2023, and $58.7 million, $48.8 million, and $17.7 million respectively, as of March 31, 2023. No other countries represented more than 10% of the Company’s total consolidated property, plant and equipment, net (excluding software) and right-of-use assets as of September 30, 2023 or March 31, 2023. 
Property, plant and equipment, net (excluding software) and right-of-use assets in Switzerland, the Company’s country of domicile, were $9.9 million and $13.7 million as of September 30, 2023 and March 31, 2023, respectively.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001032975-23-000080:notes:130]
[same as prior period, unchanged from 0001032975-23-000066:notes:125]

[0001032975-23-000080:notes:131]
actions to remove organization layers as well as streamline its marketing organization to increase efficiency. These actions resulted in charges related to employee severance and other termination benefits as well as contract termination and other costs. The Company expects to substantially complete these restructuring activities within fiscal year 2024.

[0001032975-23-000080:notes:132]
The following table summarizes restructuring-related activities during the six months ended September 30, 2023 (in thousands):

[0001032975-23-000080:notes:133]
|  |  | TerminationBenefits |  | Contract Termination and Other |  | Total |  |
| Accrued restructuring liability at March 31, 2023 (1) |  | $ | 14,177 |  |  | $ | 5,357 |  |  | $ | 19,534 |  |  |
| Charges (credits), net |  | 3,309 |  |  | (1,586) |  |  | 1,723 |  |  |
| Cash payments |  | (16,804) |  |  | (1,231) |  |  | (18,035) |  |  |
| Accrued restructuring liability at September 30, 2023 (1) |  | $ | 682 |  |  | $ | 2,540 |  |  | $ | 3,222 |  |  |

[0001032975-23-000080:notes:134]
[same as prior period, unchanged from 0001032975-23-000066:notes:129]
