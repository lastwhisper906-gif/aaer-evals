# LOGI 8-K — 0001032975-23-000075 filed 2023-10-24

## item codes, every 8-K on or before 2023-10-26

- 2023-10-24 0001032975-23-000075 — 2.02, 9.01
- 2023-09-15 0001032975-23-000072 — 5.07, 8.01
- 2023-07-25 0001032975-23-000050 — 2.02, 9.01
- 2023-06-30 0001032975-23-000037 — 5.02 — amendment, the index does not say of what
- 2023-06-30 0001032975-23-000036 — 5.02
- 2023-06-13 0001032975-23-000030 — 5.02, 7.01, 9.01
- 2023-05-02 0001032975-23-000015 — 2.02, 9.01
- 2023-01-30 0001032975-23-000010 — 5.02, 9.01
- 2023-01-24 0001032975-23-000004 — 2.02, 5.02, 9.01
- 2023-01-12 0001628280-23-000934 — 2.02, 9.01
- 2022-10-25 0001628280-22-026927 — 2.02, 5.02, 9.01
- 2022-09-16 0001628280-22-025080 — 5.07, 8.01
- 2022-07-26 0001032975-22-000027 — 2.02, 9.01
- 2022-06-29 0001032975-22-000018 — 5.02
- 2022-05-03 0001032975-22-000008 — 2.02, 9.01
- 2022-01-25 0001032975-22-000003 — 2.02, 9.01
- 2021-10-26 0001032975-21-000043 — 2.02, 9.01
- 2021-09-10 0001032975-21-000040 — 5.07, 8.01
- 2021-07-27 0001032975-21-000029 — 2.02, 9.01
- 2021-04-29 0001032975-21-000012 — 2.02, 9.01
- 2021-01-19 0001032975-21-000004 — 2.02, 9.01
- 2020-10-20 0001032975-20-000045 — 2.02, 9.01
- 2020-09-11 0001032975-20-000042 — 5.07, 8.01
- 2020-07-21 0001032975-20-000029 — 2.02, 9.01
- 2020-07-01 0001032975-20-000023 — 5.02, 8.01
- 2020-05-12 0001032975-20-000011 — 2.02, 9.01
- 2020-03-30 0001032975-20-000009 — 5.02
- 2020-01-21 0001032975-20-000002 — 2.02, 9.01
- 2019-10-22 0001032975-19-000071 — 9.01
- 2019-09-26 0001032975-19-000068 — 1.01, 7.01, 9.01
- 2019-09-06 0001032975-19-000063 — 5.07, 8.01
- 2019-07-23 0001032975-19-000046 — 2.02, 9.01
- 2019-07-23 0001032975-19-000045 — 5.02, 9.01
- 2019-07-02 0001032975-19-000036 — 5.02
- 2019-06-25 0001032975-19-000034 — 5.02
- 2019-05-03 0001032975-19-000021 — 5.02 — amendment, the index does not say of what
- 2019-04-30 0001032975-19-000017 — 2.02, 5.02, 9.01
- 2019-03-28 0001032975-19-000013 — 5.02
- 2019-01-22 0001032975-19-000004 — 2.02, 9.01
- 2018-10-23 0001032975-18-000044 — 2.02, 9.01
- 2018-09-07 0001032975-18-000040 — 5.07, 8.01
- 2018-07-31 0001032975-18-000035 — 1.01, 2.02, 2.05, 7.01, 9.01
- 2018-06-27 0001032975-18-000020 — 5.02
- 2018-05-03 0001032975-18-000013 — 2.02, 5.02, 9.01
- 2018-01-23 0001032975-18-000005 — 2.02, 9.01
- 2017-10-24 0001032975-17-000043 — 2.02, 9.01
- 2017-09-18 0001032975-17-000040 — 5.07, 8.01
- 2017-07-25 0001032975-17-000028 — 2.02, 9.01
- 2017-07-12 0001032975-17-000022 — 1.01
- 2017-04-26 0001032975-17-000012 — 2.02, 9.01
- 2017-01-25 0001032975-17-000002 — 2.02, 9.01
- 2016-10-26 0001032975-16-000103 — 2.02, 9.01
- 2016-09-13 0001032975-16-000101 — 5.07, 8.01
- 2016-07-28 0001032975-16-000092 — 2.02, 9.01
- 2016-06-30 0001032975-16-000087 — 5.02
- 2016-04-28 0001032975-16-000077 — 2.02, 9.01
- 2016-04-14 0001032975-16-000073 — 1.01, 7.01, 9.01
- 2016-01-21 0001032975-16-000064 — 2.02, 9.01
- 2016-01-04 0001032975-16-000061 — 1.01, 2.01, 9.01
- 2015-12-23 0001032975-15-000059 — 5.02
- 2015-10-22 0001032975-15-000047 — 2.02, 9.01
- 2015-09-11 0001032975-15-000044 — 5.07, 8.01
- 2015-07-24 0001032975-15-000034 — 2.05 — amendment of 0001032975-15-000030
- 2015-07-23 0001032975-15-000030 — 2.02, 9.01
- 2015-06-25 0001032975-15-000025 — 5.02
- 2015-05-14 0001032975-15-000011 — 8.01, 9.01
- 2015-04-23 0001032975-15-000008 — 2.02, 2.05
- 2015-01-22 0001628280-15-000191 — 2.02, 8.01
- 2014-12-23 0001193125-14-450908 — 5.02, 5.07, 8.01
- 2014-11-25 0001193125-14-425233 — 3.01
- 2014-11-13 0001193125-14-411303 — 4.01, 9.01
- 2014-10-23 0001104659-14-073164 — 2.02, 9.01
- 2014-09-04 0001193125-14-331214 — 4.02, 9.01
- 2014-08-18 0001193125-14-313346 — 3.01, 9.01
- 2014-07-24 0001104659-14-053065 — 2.02, 9.01
- 2014-06-05 0001193125-14-226177 — 3.01, 9.01
- 2014-05-22 0001193125-14-208777 — 8.01, 9.01
- 2014-04-24 0001104659-14-029650 — 2.02, 9.01
- 2014-01-23 0001104659-14-003619 — 2.02, 9.01
- 2013-10-24 0001104659-13-077404 — 2.02, 9.01
- 2013-09-09 0001193125-13-361441 — 5.02, 5.07, 8.01, 9.01
- 2013-09-06 0001193125-13-359930 — 5.02, 9.01
- 2013-08-02 0001193125-13-317343 — 5.02
- 2013-07-25 0001104659-13-056372 — 2.02, 9.01
- 2013-06-28 0001193125-13-277394 — 5.02, 9.01
- 2013-06-20 0001193125-13-265914 — 8.01, 9.01
- 2013-04-25 0001104659-13-032570 — 2.02, 9.01
- 2013-04-17 0001193125-13-158923 — 5.02, 9.01
- 2013-03-01 0001193125-13-085804 — 2.05
- 2013-01-24 0001104659-13-004214 — 2.02, 9.01
- 2013-01-02 0001193125-13-000058 — 5.02
- 2012-10-25 0001104659-12-070966 — 2.02, 9.01
- 2012-09-11 0001193125-12-388070 — 5.02, 5.07, 8.01, 9.01
- 2012-08-22 0001193125-12-364167 — 5.02, 8.01, 9.01
- 2012-07-26 0001104659-12-051084 — 2.02, 9.01
- 2012-06-08 0001193125-12-264132 — 2.05, 9.01 — amendment, the index does not say of what
- 2012-04-26 0001193125-12-183657 — 5.02, 9.01
- 2012-04-26 0001104659-12-028470 — 2.02, 2.05, 9.01
- 2012-03-15 0001193125-12-115954 — 5.02, 9.01
- 2012-01-26 0001104659-12-004014 — 2.02, 9.01
- 2012-01-04 0001193125-12-002212 — 1.01, 2.03, 9.01
- 2011-10-27 0001104659-11-058150 — 2.02, 9.01
- 2011-09-12 0001193125-11-245931 — 5.07
- 2011-07-28 0001193125-11-200929 — 5.02, 9.01
- 2011-07-28 0001193125-11-199704 — 2.02, 9.01
- 2011-04-28 0001193125-11-112669 — 2.02, 9.01
- 2011-03-24 0001193125-11-076483 — 5.02, 9.01
- 2011-01-27 0001032975-11-000003 — 9.01
- 2010-10-28 0001032975-10-000032 — 9.01
- 2010-09-13 0001032975-10-000022 — 5.07
- 2010-07-29 0001032975-10-000010 — 2.02, 9.01
- 2010-06-10 0001193125-10-136877 — 5.02, 9.01
- 2010-05-03 0001193125-10-104337 — 5.02
- 2010-04-29 0001032975-10-000008 — 2.02, 9.01
- 2010-02-19 0001032975-10-000006 — 9.01 — amendment of 0001193125-09-252416
- 2010-01-21 0001032975-10-000002 — 2.02, 9.01
- 2009-12-14 0001193125-09-252416 — 2.01, 9.01
- 2009-11-17 0001032975-09-000023 — 1.01
- 2009-10-22 0001032975-09-000018 — 9.01
- 2009-09-22 0001193125-09-195545 — 5.02, 9.01
- 2009-09-03 0001032975-09-000013 — 8.01
- 2009-07-23 0001140361-09-016802 — 2.02, 9.01
- 2009-06-01 0001193125-09-122550 — 5.02
- 2009-04-23 0001193125-09-085054 — 2.02, 9.01
- 2009-04-02 0001193125-09-071272 — 5.02, 9.01
- 2009-01-20 0001193125-09-008454 — 2.05 — amendment of 0001193125-09-002609
- 2009-01-20 0001193125-09-007902 — 2.02, 9.01
- 2009-01-07 0001193125-09-002609 — 2.05, 9.01
- 2009-01-07 0001193125-09-002370 — 5.02, 9.01
- 2008-12-09 0001193125-08-250543 — 5.02, 9.01
- 2008-10-21 0001193125-08-213212 — 2.02, 9.01
- 2008-07-22 0001193125-08-154721 — 2.02, 9.01
- 2008-06-24 0001193125-08-139163 — 5.03, 9.01
- 2008-05-13 0001193125-08-113263 — 5.02, 9.01
- 2008-04-22 0001193125-08-086176 — 2.02, 9.01

## late-filing notifications on or before 2023-10-26

- 2015-06-02 0001032975-15-000020 — NT 10-K, for the period ended 2015-03-31
- 2014-11-06 0001193125-14-401306 — NT 10-Q, for the period ended 2014-09-30
- 2014-07-24 0001193125-14-277575 — NT 10-Q, for the period ended 2014-06-30
- 2014-05-22 0001193125-14-208712 — NT 10-K, for the period ended 2014-03-31
- 2009-08-06 0001032975-09-000006 — NT 10-Q, for the period ended 2009-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001032975-23-000075:8k_2_02:1]
EX-99.1
2
exhibit991q2fy24.htm
EX-99.1

[0001032975-23-000075:8k_2_02:2]
Document

[0001032975-23-000075:8k_2_02:3]
Exhibit 99.1

[0001032975-23-000075:8k_2_02:4]
Editorial Contacts:

[0001032975-23-000075:8k_2_02:5]
Nate Melihercik, Head of Global Investor Relations - ir@logitech.com

[0001032975-23-000075:8k_2_02:6]
Nicole Kenyon, Head of Global Corporate and Internal Communications - nkenyon@logitech.com (USA)

[0001032975-23-000075:8k_2_02:7]
Ben Starkie, Corporate Communications - +41 (0) 79-292-3499, bstarkie1@logitech.com (Europe)

[0001032975-23-000075:8k_2_02:8]
Logitech Announces Second Quarter Fiscal Year 2024 Results

[0001032975-23-000075:8k_2_02:9]
Company Raises FY 2024 Outlook

[0001032975-23-000075:8k_2_02:10]
LAUSANNE, Switzerland, Oct. 24, 2023 and SAN JOSE, Calif., Oct. 23, 2023 — SIX Swiss Exchange Ad hoc announcement pursuant to Art. 53 LR — Logitech International (SIX: LOGN) (Nasdaq: LOGI) today announced financial results for the second quarter of Fiscal Year 2024.

[0001032975-23-000075:8k_2_02:11]
•Sales were $1.06 billion, down 8 percent in US dollars and 9 percent in constant currency, compared to the prior year.

[0001032975-23-000075:8k_2_02:12]
•GAAP operating income was $157 million, up 23 percent compared to the prior year. Non-GAAP operating income was $183 million, up 17 percent compared to the prior year. In the quarter, the Company continued to reduce operating expenses, down 9 percent compared to the prior year, in line with the decline in net sales.

[0001032975-23-000075:8k_2_02:13]
•GAAP earnings per share (EPS) was $0.86, up 72 percent compared to the prior year. Non-GAAP EPS was $1.09, up 30 percent compared to the prior year.

[0001032975-23-000075:8k_2_02:14]
•Cash flow from operations was $223 million, up $150 million compared to the prior year. The quarter-ending cash balance was $1.16 billion. In the quarter, the Company returned $276 million of cash to shareholders through its annual dividend payment and share repurchases.

[0001032975-23-000075:8k_2_02:15]
“The Logitech team stepped up execution this quarter and delivered results that demonstrate the underlying potential of our business,” said Guy Gecht, Logitech interim chief executive officer. “We made great progress toward a return to growth and exceeded our pre-pandemic profit levels. Our design-led innovation capabilities were on full display, with 16 new product introductions during the quarter. I'm proud of what our team has accomplished in this challenging environment. We remain focused on developing market leading products, operational excellence, and value creation for shareholders."

[0001032975-23-000075:8k_2_02:16]
“While our second quarter revenue was down compared to last year, we delivered expanded gross margins of 42.0% and operating margins of 17.3%,” said Chuck Boynton, Logitech chief financial officer. “Through strong operating execution and working capital management, we generated $223 million in operating cash flow and returned $276 million to our shareholders. Our focus on cost discipline with a customer-first mindset is paying off, with share growth in key categories. We remain cautiously optimistic on the balance of the year and are pleased to raise the annual outlook.”

[0001032975-23-000075:8k_2_02:17]
CEO Search Update

[0001032975-23-000075:8k_2_02:18]
Over the last four months, the board of directors, led by Wendy Becker, has been conducting a global CEO search looking at internal and external candidates across industries and geographies. The board has met with a number of strong, diverse and experienced candidates, and is moving closer to finalizing a decision.

[0001032975-23-000075:8k_2_02:19]
Updated Full Year Outlook

[0001032975-23-000075:8k_2_02:20]
Logitech raised its full-year outlook for Fiscal Year 2024:

[0001032975-23-000075:8k_2_02:21]
|  |  | Previous FY 2024 outlook |  | New FY 2024 outlook |
| Sales |  | $3.8 - $4.0 billion |  | $4.0 - $4.15 billion |
| Sales decline (in US dollars, year over year) |  | 16% - 12% |  | 12% - 9% |
| Non-GAAP operating income |  | $400 - $500 million |  | $525 - $575 million |
| Non-GAAP op. inc. decline (year over year) |  | 32% - 15% |  | 11% - 2% |

[0001032975-23-000075:8k_2_02:22]
H1 2024 Results Compared to H1 2024 Outlook

[0001032975-23-000075:8k_2_02:23]
Logitech exceeded its outlook for the first half of Fiscal Year 2024:

[0001032975-23-000075:8k_2_02:24]
|  |  | H1 2024 outlook |  | H1 2024 results |
| Sales |  | $1.875 - $1.975 billion |  | $2.032 billion |
| Sales decline (in US dollars, year over year) |  | 19% - 14% |  | 12% |
| Non-GAAP operating income |  | $180 - $220 million |  | $292 million |
| Non-GAAP op. inc. decline (year over year) |  | 40% - 27% |  | 3% |

[0001032975-23-000075:8k_2_02:25]
Financial Results Videoconference and Webcast

[0001032975-23-000075:8k_2_02:26]
Logitech will hold a financial results videoconference to discuss the results for Q2 Fiscal Year 2024 on Tuesday, October 24, 2023 at 8:30 a.m. Eastern Daylight Time and 2:30 p.m. Central European Summer Time. A livestream of the event will be available on the Logitech corporate website at

[0001032975-23-000075:8k_2_02:27]
http://ir.logitech.com.

[0001032975-23-000075:8k_2_02:28]
Use of Non-GAAP Financial Information and Constant Currency

[0001032975-23-000075:8k_2_02:29]
To facilitate comparisons to Logitech’s historical results, Logitech has included non-GAAP adjusted measures in this press release, which exclude share-based compensation expense, amortization of intangible assets, acquisition-related costs, restructuring charges (credits), net, loss (gain) on investments, non-GAAP income tax adjustment, and other items detailed under “Supplemental Financial Information” after the tables below and posted to our website at http://ir.logitech.com. Logitech also presents percentage sales growth in constant currency (“CC”), a non-GAAP measure, to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales. Logitech believes this information, used together with the GAAP financial information, will help investors to evaluate its current period performance, outlook and trends in its business. With respect to the Company’s outlook for non-GAAP operating income, most of these excluded amounts pertain to events that have not yet occurred and are not currently possible to estimate with a reasonable degree of accuracy. Therefore, no

[0001032975-23-000075:8k_2_02:30]
reconciliation to the GAAP amounts has been provided for the full Fiscal Year 2024 non-GAAP operating income outlook.

[0001032975-23-000075:8k_2_02:31]
Public Dissemination of Certain Information

[0001032975-23-000075:8k_2_02:32]
Recordings of Logitech's earnings videoconferences and certain events Logitech participates in or hosts, with members of the investment community are posted on the company's investor relations website at https://ir.logitech.com. Additionally, Logitech provides notifications of news or announcements regarding its operations and financial performance, including its filings with the Securities and Exchange Commission (SEC), investor events, and press and earnings releases as part of its investor relations website. Logitech intends to use its investor relations website as means of disclosing material nonpublic information and for complying with its disclosure obligations under Regulation FD. Logitech’s corporate governance information also is available on its investor relations website.

[0001032975-23-000075:8k_2_02:33]
About Logitech

[0001032975-23-000075:8k_2_02:34]
Logitech helps all people pursue their passions and is committed to doing so in a way that is good for people and the planet. We design hardware and software solutions that help businesses thrive and bring people together when working, creating, gaming and streaming. Brands of Logitech include Logitech, Logitech G, ASTRO Gaming, Streamlabs, Blue Microphones and Ultimate Ears. Founded in 1981, and headquartered in Lausanne, Switzerland, Logitech International is a Swiss public company listed on the SIX Swiss Exchange (LOGN) and on the Nasdaq Global Select Market (LOGI). Find Logitech at www.logitech.com, the company blog or @logitech.

[0001032975-23-000075:8k_2_02:35]
# # #

[0001032975-23-000075:8k_2_02:36]
Note that unless noted otherwise, comparisons are year over year.

[0001032975-23-000075:8k_2_02:37]
Logitech and other Logitech marks are trademarks or registered trademarks of Logitech Europe S.A. and/or its affiliates in the U.S. and other countries. All other trademarks are the property of their respective owners. For more information about Logitech and its products, visit the company’s website at www.logitech.com.

[0001032975-23-000075:8k_2_02:38]
(LOGIIR)

[0001032975-23-000075:8k_2_02:39]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three months ended September 30, |  | Six months ended September 30, |
| GAAP CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Net sales |  | $ | 1,057,008 |  |  | $ | 1,148,951 |  |  | $ | 2,031,507 |  |  | $ | 2,308,816 |  |
| Cost of goods sold |  | 615,403 |  |  | 707,026 |  |  | 1,211,115 |  |  | 1,404,246 |  |
| Amortization of intangible assets |  | 2,983 |  |  | 3,145 |  |  | 6,128 |  |  | 6,187 |  |
| Gross profit |  | 438,622 |  |  | 438,780 |  |  | 814,264 |  |  | 898,383 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Marketing and selling |  | 176,356 |  |  | 202,091 |  |  | 355,541 |  |  | 431,469 |  |
| Research and development |  | 68,559 |  |  | 69,009 |  |  | 139,118 |  |  | 144,526 |  |
| General and administrative |  | 35,538 |  |  | 26,589 |  |  | 76,835 |  |  | 62,449 |  |
| Amortization of intangible assets and acquisition-related costs |  | 3,318 |  |  | 2,873 |  |  | 6,003 |  |  | 6,242 |  |
| Restructuring charges (credits), net |  | (1,788) |  |  | 10,817 |  |  | 1,723 |  |  | 10,817 |  |
| Total operating expenses |  | 281,983 |  |  | 311,379 |  |  | 579,220 |  |  | 655,503 |  |
| Operating income |  | 156,639 |  |  | 127,401 |  |  | 235,044 |  |  | 242,880 |  |
| Interest income |  | 11,856 |  |  | 3,459 |  |  | 21,682 |  |  | 4,908 |  |
| Other income (expense), net |  | (1,044) |  |  | (25,397) |  |  | (14,016) |  |  | (19,773) |  |
| Income before income taxes |  | 167,451 |  |  | 105,463 |  |  | 242,710 |  |  | 228,015 |  |
| Provision for income taxes |  | 30,334 |  |  | 23,372 |  |  | 42,866 |  |  | 45,088 |  |
| Net income |  | $ | 137,117 |  |  | $ | 82,091 |  |  | $ | 199,844 |  |  | $ | 182,927 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.87 |  |  | $ | 0.50 |  |  | $ | 1.26 |  |  | $ | 1.12 |  |
| Diluted |  | $ | 0.86 |  |  | $ | 0.50 |  |  | $ | 1.25 |  |  | $ | 1.11 |  |
| Weighted average shares used to compute net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | 157,911 |  |  | 163,186 |  |  | 158,385 |  |  | 163,937 |  |
| Diluted |  | 158,934 |  |  | 164,328 |  |  | 159,545 |  |  | 165,371 |  |

[0001032975-23-000075:8k_2_02:40]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
|  |  | September 30, |  | March 31, |  |  |  |  |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  | 2023 |  | 2023 |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,163,904 |  |  | $ | 1,149,023 |  |  |  |  |  |
| Accounts receivable, net |  | 656,895 |  |  | 630,382 |  |  |  |  |  |
| Inventories |  | 532,943 |  |  | 682,893 |  |  |  |  |  |
| Other current assets |  | 138,482 |  |  | 142,876 |  |  |  |  |  |
| Total current assets |  | 2,492,224 |  |  | 2,605,174 |  |  |  |  |  |
| Non-current assets: |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  | 122,027 |  |  | 121,503 |  |  |  |  |  |
| Goodwill |  | 461,401 |  |  | 454,610 |  |  |  |  |  |
| Other intangible assets, net |  | 58,081 |  |  | 63,173 |  |  |  |  |  |
| Other assets |  | 291,297 |  |  | 316,293 |  |  |  |  |  |
| Total assets |  | $ | 3,425,030 |  |  | $ | 3,560,753 |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 492,905 |  |  | $ | 406,968 |  |  |  |  |  |
| Accrued and other current liabilities |  | 594,042 |  |  | 643,139 |  |  |  |  |  |
| Total current liabilities |  | 1,086,947 |  |  | 1,050,107 |  |  |  |  |  |
| Non-current liabilities: |  |  |  |  |  |  |  |  |
| Income taxes payable |  | 114,235 |  |  | 106,391 |  |  |  |  |  |
| Other non-current liabilities |  | 146,583 |  |  | 146,695 |  |  |  |  |  |
| Total liabilities |  | 1,347,765 |  |  | 1,303,193 |  |  |  |  |  |
| Shareholders’ equity: |  |  |  |  |  |  |  |  |
| Registered shares, CHF 0.25 par value: |  | 30,148 |  |  | 30,148 |  |  |  |  |  |
| Issued shares — 173,106 at September 30, 2023 and March 31, 2023 |  |  |  |  |  |  |  |  |
| Additional shares that may be issued out of conditional capital — 50,000 at September 30, 2023 and March 31, 2023 |  |  |  |  |  |  |  |  |
| Additional shares that may be issued out of authorized capital — 17,311 at September 30, 2023 and March 31, 2023 |  |  |  |  |  |  |  |  |
| Additional paid-in capital |  | 47,311 |  |  | 127,380 |  |  |  |  |  |
| Shares in treasury, at cost — 16,029 at September 30, 2023 and 13,763 at March 31, 2023 |  | (1,083,468) |  |  | (977,266) |  |  |  |  |  |
| Retained earnings |  | 3,190,220 |  |  | 3,177,575 |  |  |  |  |  |
| Accumulated other comprehensive loss |  | (106,946) |  |  | (100,277) |  |  |  |  |  |
| Total shareholders’ equity |  | 2,077,265 |  |  | 2,257,560 |  |  |  |  |  |
| Total liabilities and shareholders’ equity |  | $ | 3,425,030 |  |  | $ | 3,560,753 |  |  |  |  |  |

[0001032975-23-000075:8k_2_02:41]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three months ended September 30, |  | Six months ended September 30, |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 137,117 |  |  | $ | 82,091 |  |  | $ | 199,844 |  |  | $ | 182,927 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  | 16,637 |  |  | 18,662 |  |  | 34,135 |  |  | 37,288 |  |
| Amortization of intangible assets |  | 5,682 |  |  | 6,015 |  |  | 11,509 |  |  | 12,244 |  |
| Loss (gain) on investments |  | (214) |  |  | 22,934 |  |  | 11,609 |  |  | 11,577 |  |
| Share-based compensation expense |  | 22,068 |  |  | 12,245 |  |  | 43,579 |  |  | 35,935 |  |
| Deferred income taxes |  | 8,146 |  |  | 2,775 |  |  | 11,108 |  |  | 3,040 |  |
| Other |  | 76 |  |  | 242 |  |  | 100 |  |  | 118 |  |
| Changes in assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | (100,752) |  |  | (77,337) |  |  | (35,362) |  |  | (121,909) |  |
| Inventories |  | 35,929 |  |  | 22,114 |  |  | 146,369 |  |  | 21,790 |  |
| Other assets |  | (22,343) |  |  | (175) |  |  | 11,999 |  |  | 4,757 |  |
| Accounts payable |  | 106,442 |  |  | (8,320) |  |  | 88,022 |  |  | (78,354) |  |
| Accrued and other liabilities |  | 14,476 |  |  | (8,322) |  |  | (59,853) |  |  | (72,157) |  |
| Net cash provided by operating activities |  | 223,264 |  |  | 72,924 |  |  | 463,059 |  |  | 37,256 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  | (18,493) |  |  | (25,821) |  |  | (34,731) |  |  | (45,384) |  |
| Investment in privately held companies |  | (322) |  |  | (187) |  |  | (356) |  |  | (2,275) |  |
| Acquisitions, net of cash acquired |  | (12,878) |  |  | — |  |  | (14,138) |  |  | (5,839) |  |
| Purchases of deferred compensation investments |  | (1,479) |  |  | (1,577) |  |  | (2,548) |  |  | (2,499) |  |
| Proceeds from sales of deferred compensation investments |  | 1,551 |  |  | 1,493 |  |  | 2,622 |  |  | 2,436 |  |
| Net cash used in investing activities |  | (31,621) |  |  | (26,092) |  |  | (49,151) |  |  | (53,561) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Payment of cash dividends |  | (182,305) |  |  | (158,680) |  |  | (182,305) |  |  | (158,680) |  |
| Payment of contingent consideration for business acquisition |  | (5,002) |  |  | (5,954) |  |  | (5,002) |  |  | (5,954) |  |
| Purchases of registered shares |  | (93,865) |  |  | (116,942) |  |  | (188,941) |  |  | (237,561) |  |
| Proceeds from exercises of stock options and purchase rights |  | 13,206 |  |  | 12,850 |  |  | 15,319 |  |  | 12,850 |  |
| Tax withholdings related to net share settlements of restricted stock units |  | (2,028) |  |  | (2,598) |  |  | (26,224) |  |  | (26,742) |  |
| Other financing activities |  | (1,116) |  |  | — |  |  | (1,116) |  |  | — |  |
| Net cash used in financing activities |  | (271,110) |  |  | (271,324) |  |  | (388,269) |  |  | (416,087) |  |
| Effect of exchange rate changes on cash and cash equivalents |  | (7,715) |  |  | (13,664) |  |  | (10,758) |  |  | (27,823) |  |
| Net increase (decrease) in cash and cash equivalents |  | (87,182) |  |  | (238,156) |  |  | 14,881 |  |  | (460,215) |  |
| Cash and cash equivalents, beginning of the period |  | 1,251,086 |  |  | 1,106,657 |  |  | 1,149,023 |  |  | 1,328,716 |  |
| Cash and cash equivalents, end of the period |  | $ | 1,163,904 |  |  | $ | 868,501 |  |  | $ | 1,163,904 |  |  | $ | 868,501 |  |

[0001032975-23-000075:8k_2_02:42]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three months ended September 30, |  | Six months ended September 30, |
| NET SALES |  | 2023 |  | 2022 (1) |  | Change |  | 2023 |  | 2022 (1) |  | Change |
| Net sales by product category: |  |  |  |  |  |  |  |  |  |  |  |  |
| Gaming (2) |  | $ | 282,104 |  |  | $ | 322,028 |  |  | (12) | % |  | $ | 548,533 |  |  | $ | 619,949 |  |  | (12) | % |
| Keyboards & Combos |  | 194,914 |  |  | 200,853 |  |  | (3) |  |  | 375,769 |  |  | 428,573 |  |  | (12) |  |
| Pointing Devices |  | 191,676 |  |  | 185,200 |  |  | 3 |  |  | 366,130 |  |  | 368,483 |  |  | (1) |  |
| Video Collaboration |  | 152,389 |  |  | 179,199 |  |  | (15) |  |  | 291,735 |  |  | 360,831 |  |  | (19) |  |
| Webcams |  | 88,222 |  |  | 102,018 |  |  | (14) |  |  | 163,422 |  |  | 211,280 |  |  | (23) |  |
| Tablet Accessories |  | 63,677 |  |  | 54,203 |  |  | 17 |  |  | 134,013 |  |  | 120,788 |  |  | 11 |  |
| Headsets |  | 44,411 |  |  | 44,750 |  |  | (1) |  |  | 81,261 |  |  | 90,693 |  |  | (10) |  |
| Other (3) |  | 39,615 |  |  | 60,700 |  |  | (35) |  |  | 70,644 |  |  | 108,219 |  |  | (35) |  |
| Total Net Sales |  | $ | 1,057,008 |  |  | $ | 1,148,951 |  |  | (8) | % |  | $ | 2,031,507 |  |  | $ | 2,308,816 |  |  | (12) | % |

[0001032975-23-000075:8k_2_02:43]
(1) The Company has reclassified certain prior period amounts to conform to the current period presentation.

[0001032975-23-000075:8k_2_02:44]
(2) Gaming includes streaming services revenue generated by Streamlabs.

[0001032975-23-000075:8k_2_02:45]
(3) Other primarily consists of mobile speakers and PC speakers.

[0001032975-23-000075:8k_2_02:46]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three months ended September 30, |  | Six months ended September 30, |
| GAAP TO NON-GAAP RECONCILIATION (A) |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Gross profit - GAAP |  | $ | 438,622 |  |  | $ | 438,780 |  |  | $ | 814,264 |  |  | $ | 898,383 |  |
| Share-based compensation expense |  | 2,462 |  |  | 1,443 |  |  | 3,877 |  |  | 2,904 |  |
| Amortization of intangible assets |  | 2,983 |  |  | 3,145 |  |  | 6,128 |  |  | 6,187 |  |
| Gross profit - Non-GAAP |  | $ | 444,067 |  |  | $ | 443,368 |  |  | $ | 824,269 |  |  | $ | 907,474 |  |
| Gross margin - GAAP |  | 41.5 | % |  | 38.2 | % |  | 40.1 | % |  | 38.9 | % |
| Gross margin - Non-GAAP |  | 42.0 | % |  | 38.6 | % |  | 40.6 | % |  | 39.3 | % |
| Operating expenses - GAAP |  | $ | 281,983 |  |  | $ | 311,379 |  |  | $ | 579,220 |  |  | $ | 655,503 |  |
| Less: Share-based compensation expense |  | 19,606 |  |  | 10,802 |  |  | 39,702 |  |  | 33,031 |  |
| Less: Amortization of intangible assets and acquisition-related costs |  | 3,318 |  |  | 2,873 |  |  | 6,003 |  |  | 6,242 |  |
| Less: Restructuring charges (credits), net |  | (1,788) |  |  | 10,817 |  |  | 1,723 |  |  | 10,817 |  |
| Operating expenses - Non-GAAP |  | $ | 260,847 |  |  | $ | 286,887 |  |  | $ | 531,792 |  |  | $ | 605,413 |  |
| % of net sales - GAAP |  | 26.7 | % |  | 27.1 | % |  | 28.5 | % |  | 28.4 | % |
| % of net sales - Non-GAAP |  | 24.7 | % |  | 25.0 | % |  | 26.2 | % |  | 26.2 | % |
| Operating income - GAAP |  | $ | 156,639 |  |  | $ | 127,401 |  |  | $ | 235,044 |  |  | $ | 242,880 |  |
| Share-based compensation expense |  | 22,068 |  |  | 12,245 |  |  | 43,579 |  |  | 35,935 |  |
| Amortization of intangible assets and acquisition-related costs |  | 6,301 |  |  | 6,018 |  |  | 12,131 |  |  | 12,429 |  |
| Restructuring charges (credits), net |  | (1,788) |  |  | 10,817 |  |  | 1,723 |  |  | 10,817 |  |
| Operating income - Non-GAAP |  | $ | 183,220 |  |  | $ | 156,481 |  |  | $ | 292,477 |  |  | $ | 302,061 |  |
| % of net sales - GAAP |  | 14.8 | % |  | 11.1 | % |  | 11.6 | % |  | 10.5 | % |
| % of net sales - Non-GAAP |  | 17.3 | % |  | 13.6 | % |  | 14.4 | % |  | 13.1 | % |
| Net income - GAAP |  | $ | 137,117 |  |  | $ | 82,091 |  |  | $ | 199,844 |  |  | $ | 182,927 |  |
| Share-based compensation expense |  | 22,068 |  |  | 12,245 |  |  | 43,579 |  |  | 35,935 |  |
| Amortization of intangible assets and acquisition-related costs |  | 6,301 |  |  | 6,018 |  |  | 12,131 |  |  | 12,429 |  |
| Restructuring charges (credits), net |  | (1,788) |  |  | 10,817 |  |  | 1,723 |  |  | 10,817 |  |
| Loss (gain) on investments |  | (214) |  |  | 22,934 |  |  | 11,609 |  |  | 11,577 |  |
| Non-GAAP income tax adjustment |  | 9,933 |  |  | 3,607 |  |  | 7,930 |  |  | 7,066 |  |
| Net income - Non-GAAP |  | $ | 173,417 |  |  | $ | 137,712 |  |  | $ | 276,816 |  |  | $ | 260,751 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  | $ | 0.86 |  |  | $ | 0.50 |  |  | $ | 1.25 |  |  | $ | 1.11 |  |
| Diluted - Non-GAAP |  | $ | 1.09 |  |  | $ | 0.84 |  |  | $ | 1.74 |  |  | $ | 1.58 |  |
| Shares used to compute net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP and Non-GAAP |  | 158,934 |  |  | 164,328 |  |  | 159,545 |  |  | 165,371 |  |

[0001032975-23-000075:8k_2_02:47]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three months ended September 30, |  | Six months ended September 30, |
| SHARE-BASED COMPENSATION EXPENSE |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Share-based Compensation Expense |  |  |  |  |  |  |  |  |
| Cost of goods sold |  | $ | 2,462 |  |  | $ | 1,443 |  |  | $ | 3,877 |  |  | $ | 2,904 |  |
| Marketing and selling |  | 9,262 |  |  | 7,429 |  |  | 19,745 |  |  | 17,226 |  |
| Research and development |  | 4,694 |  |  | 3,280 |  |  | 9,147 |  |  | 8,812 |  |
| General and administrative |  | 5,650 |  |  | 93 |  |  | 10,810 |  |  | 6,993 |  |
| Total share-based compensation expense |  | 22,068 |  |  | 12,245 |  |  | 43,579 |  |  | 35,935 |  |
| Income tax expense (benefit) |  | (2,548) |  |  | 102 |  |  | (7,866) |  |  | (4,220) |  |
| Total share-based compensation expense, net of income tax expense (benefit) |  | $ | 19,520 |  |  | $ | 12,347 |  |  | $ | 35,713 |  |  | $ | 31,715 |  |

[0001032975-23-000075:8k_2_02:48]
*Note: These preliminary results for the three and six months ended September 30, 2023 are subject to adjustments, including subsequent events that may occur through the date of filing our Quarterly Report on Form 10-Q.

[0001032975-23-000075:8k_2_02:49]
(A) Non-GAAP Financial Measures

[0001032975-23-000075:8k_2_02:50]
To supplement our condensed consolidated financial results prepared in accordance with GAAP, we use a number of financial measures, both GAAP and non-GAAP, in analyzing and assessing our overall business performance, for making operating decisions and for forecasting and planning future periods. We consider the use of non-GAAP financial measures helpful in assessing our current financial performance, ongoing operations and prospects for the future as well as understanding financial and business trends relating to our financial condition and results of operations.

[0001032975-23-000075:8k_2_02:51]
While we use non-GAAP financial measures as a tool to enhance our understanding of certain aspects of our financial performance and to provide incremental insight into the underlying factors and trends affecting both our performance and our cash-generating potential, we do not consider these measures to be a substitute for, or superior to, the information provided by GAAP financial measures. Consistent with this approach, we believe that disclosing non-GAAP financial measures to the readers of our financial statements provides useful supplemental data that, while not a substitute for GAAP financial measures, can offer insight in the review of our financial and operational performance and enables investors to more fully understand trends in our current and future performance. In assessing our business during the quarter ended September 30, 2023 and prior periods presented, we excluded items in the following general categories, each of which are described below:

[0001032975-23-000075:8k_2_02:52]
Share-based compensation expense. We believe that providing non-GAAP measures excluding share-based compensation expense, in addition to the GAAP measures, allows for a more transparent comparison of our financial results from period to period. We prepare and maintain our budgets and forecasts for future periods on a basis consistent with this non-GAAP financial measure. Further, companies use a variety of types of equity awards as well as a variety of methodologies, assumptions and estimates to determine share-based compensation expense. We believe that excluding share-based compensation expense enhances our ability and the ability of investors to understand the impact of non-cash share-based compensation on our operating results and to compare our results against the results of other companies.

[0001032975-23-000075:8k_2_02:53]
Amortization of intangible assets. We incur intangible asset amortization expense, primarily in connection with our acquisitions of various businesses and technologies. The amortization of purchased intangibles varies depending on the level of acquisition activity. We exclude these various charges in budgeting, planning and forecasting future periods and we believe that providing the non-GAAP measures excluding these various non-cash charges, as well as the GAAP measures, provides additional insight when comparing our gross profit, operating expenses, and financial results from period to period.

[0001032975-23-000075:8k_2_02:54]
Acquisition-related costs. We incurred expenses and credits in connection with our acquisitions which we generally would not have otherwise incurred in the periods presented as a part of our continuing operations. Acquisition-related costs include certain incremental expenses incurred to effect a business combination. We believe that providing the non-GAAP measures excluding these costs and credits, as well as the GAAP measures, assists our investors because such costs are not reflective of our ongoing operating results.

[0001032975-23-000075:8k_2_02:55]
Restructuring charges (credits), net. These expenses are associated with restructuring plans, and will vary based on the initiatives in place during any given period. Restructuring charges may include costs related to employee terminations, facility closures and early cancellation of certain contracts as well as other costs resulting from our restructuring initiatives. We believe that providing the non-GAAP measures excluding these items, as well as the GAAP measures, assists our investors because such charges (credits) are not reflective of our ongoing operating results.

[0001032975-23-000075:8k_2_02:56]
Loss (gain) on investments. We recognize losses (gains) related to our investments in various companies, which vary depending on the operational and financial performance of the companies in which we invest. These amounts include our losses (earnings) on equity method investments, investment impairments and losses (gains) resulting from sales or other events related to our investments. We believe that providing the non-GAAP measures excluding these items, as well as the GAAP measures, assists our investors because such losses (gains) are not reflective of our ongoing operations.

[0001032975-23-000075:8k_2_02:57]
Non-GAAP income tax adjustment.  Non-GAAP income tax adjustment primarily measures the income tax effect of non-GAAP adjustments excluded above and other events; the determination of which is based upon the nature of the underlying items, the mix of income and losses in jurisdictions and the relevant tax rates in which we operate.

[0001032975-23-000075:8k_2_02:58]
Each of the non-GAAP financial measures described above, and used in this press release, should not be considered in isolation from, or as a substitute for, a measure of financial performance prepared in accordance with GAAP. Further, investors are cautioned that there are inherent limitations associated with the use of each of these non-GAAP financial measures as an analytical tool. In particular, these non-GAAP financial measures are not based on a comprehensive set of accounting rules or principles and many of the adjustments to the GAAP financial measures reflect the exclusion of items that are recurring and may be reflected in the Company’s financial results for the foreseeable future. We compensate for these limitations by providing specific information in the reconciliation included in this press release regarding the GAAP amounts excluded from the non-GAAP financial measures. In addition, as noted above, we evaluate the non-GAAP financial measures together with the most directly comparable GAAP financial information.

[0001032975-23-000075:8k_2_02:59]
Additional Supplemental Financial Information - Constant Currency

[0001032975-23-000075:8k_2_02:60]
In addition, Logitech presents percentage sales growth in constant currency to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales.
