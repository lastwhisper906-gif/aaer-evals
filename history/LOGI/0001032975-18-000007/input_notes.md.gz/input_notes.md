# LOGI notes — 0001032975-18-000007


## logi:ScheduleOfBalanceSheetComponentsAssetsTableTextBlock

[0001032975-18-000007:notes:1]
The following table presents the components of certain balance sheet asset amounts as of December 31 and March 31, 2017 (in thousands):

[0001032975-18-000007:notes:2]
|  |  | December 31,2017 |  | March 31,2017 |
| Accounts receivable, net: |  |  |  |  |  |  |
| Accounts receivable |  | $ | 668,811 |  |  | $ | 395,754 |  |
| Allowance for doubtful accounts |  | (233 | ) |  | (607 | ) |
| Allowance for sales returns |  | (25,008 | ) |  | (18,800 | ) |
| Allowance for cooperative marketing arrangements * |  | (44,033 | ) |  | (28,022 | ) |
| Allowance for customer incentive programs * |  | (102,974 | ) |  | (60,857 | ) |
| Allowance for pricing programs * |  | (144,810 | ) |  | (102,289 | ) |
|  |  | $ | 351,753 |  |  | $ | 185,179 |  |
| Inventories: |  |  |  |  |  |  |
| Raw materials |  | $ | 35,752 |  |  | $ | 30,582 |  |
| Finished goods |  | 243,227 |  |  | 222,819 |  |
|  |  | $ | 278,979 |  |  | $ | 253,401 |  |
| Other current assets: |  |  |  |  |  |  |
| Value-added tax receivables |  | $ | 29,620 |  |  | $ | 23,132 |  |
| Prepaid expenses and other assets |  | 27,910 |  |  | 18,600 |  |
|  |  | $ | 57,530 |  |  | $ | 41,732 |  |
| Property, plant and equipment, net: |  |  |  |  |  |  |
| Property, plant and equipment at cost |  | $ | 362,809 |  |  | $ | 348,760 |  |
| Less: accumulated depreciation and amortization |  | (275,908 | ) |  | (263,352 | ) |
|  |  | $ | 86,901 |  |  | $ | 85,408 |  |
| Other assets: |  |  |  |  |  |  |
| Deferred tax assets ** |  | $ | 86,518 |  |  | $ | 57,303 |  |
| Trading investments for deferred compensation plan |  | 17,998 |  |  | 15,043 |  |
| Investments in privately held companies |  | 11,969 |  |  | 10,776 |  |
| Other assets |  | 6,354 |  |  | 4,997 |  |
|  |  | $ | 122,839 |  |  | $ | 88,119 |  |

[0001032975-18-000007:notes:3]
*The increases in the allowances for cooperative marketing arrangements, customer incentive programs, pricing programs and indirect customer incentive programs as of December 31, 2017 compared with March 31, 2017 were primarily the result of seasonality in the Company's business and increases in these marketing and promotional activities.

[0001032975-18-000007:notes:4]
**The increase in deferred tax assets was primarily due to the adoption of ASU 2016-09 effective April 1, 2017, partially offset by the remeasurement of federal deferred tax assets as a result of the enactment of the Tax Act in the third quarter of fiscal year 2018. See "Note 5 - Income Taxes" for more information.


## logi:ScheduleOfBalanceSheetComponentsLiabilityTableTextBlock

[0001032975-18-000007:notes:5]
The following table presents the components of certain balance sheet liability amounts as of December 31 and March 31, 2017 (in thousands):

[0001032975-18-000007:notes:6]
|  |  | December 31,2017 |  | March 31,2017 |
| Accrued and other current liabilities: |  |  |  |  |  |  |
| Accrued personnel expenses |  | $ | 73,124 |  |  | $ | 88,346 |  |
| Indirect customer incentive programs * |  | 69,921 |  |  | 36,409 |  |
| Warranty accrual |  | 15,640 |  |  | 13,424 |  |
| Employee benefit plan obligation |  | 2,164 |  |  | 1,266 |  |
| Income taxes payable |  | 4,387 |  |  | 6,232 |  |
| Contingent consideration for business acquisition - current portion |  | — |  |  | 2,889 |  |
| Other current liabilities |  | 112,819 |  |  | 83,707 |  |
|  |  | $ | 278,055 |  |  | $ | 232,273 |  |
| Other non-current liabilities: |  |  |  |  |  |  |
| Warranty accrual |  | $ | 10,624 |  |  | $ | 8,487 |  |
| Obligation for deferred compensation plan |  | 17,998 |  |  | 15,043 |  |
| Employee benefit plan obligation |  | 43,110 |  |  | 41,998 |  |
| Deferred tax liability |  | 1,789 |  |  | 1,789 |  |
| Contingent consideration for business acquisition - non-current portion |  | — |  |  | 7,019 |  |
| Other non-current liabilities |  | 8,483 |  |  | 9,355 |  |
|  |  | $ | 82,004 |  |  | $ | 83,691 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001032975-18-000007:notes:7]
[same as prior period, unchanged from 0001032975-17-000053:notes:5]

[0001032975-18-000007:notes:8]
[same as prior period, unchanged from 0001032975-17-000053:notes:6]

[0001032975-18-000007:notes:9]
[same as prior period, unchanged from 0001032975-17-000053:notes:7]

[0001032975-18-000007:notes:10]
[same as prior period, unchanged from 0001032975-17-000053:notes:8]

[0001032975-18-000007:notes:11]
[same as prior period, unchanged from 0001032975-17-000053:notes:9]

[0001032975-18-000007:notes:12]
Business Acquisitions

[0001032975-18-000007:notes:13]
In August 2017, the Company acquired the ASTRO Gaming business. In November 2017, the Company also made a small acquisition. See "Note 2 - Business Acquisitions" for more information.

[0001032975-18-000007:notes:14]
[same as prior period, unchanged from 0001032975-17-000053:notes:12]

[0001032975-18-000007:notes:15]
[same as prior period, unchanged from 0001032975-17-000053:notes:13]

[0001032975-18-000007:notes:16]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and nine months ended December 31, 2017 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2018, or any future periods.

[0001032975-18-000007:notes:17]
[same as prior period, unchanged from 0001032975-17-000053:notes:15]

[0001032975-18-000007:notes:18]
Certain amounts from the comparative period in the accompanying unaudited condensed consolidated financial statements have been reclassified to conform to the condensed consolidated financial statement presentation as of and for the three and nine months ended December 31, 2017.

[0001032975-18-000007:notes:19]
[same as prior period, unchanged from 0001032975-17-000053:notes:17]

[0001032975-18-000007:notes:20]
Other than the recent accounting pronouncements adopted and discussed below, there have been no substantial changes in the Company’s significant accounting policies during the nine months ended December 31, 2017 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2017.

[0001032975-18-000007:notes:21]
[same as prior period, unchanged from 0001032975-17-000053:notes:19]

[0001032975-18-000007:notes:22]
[same as prior period, unchanged from 0001032975-17-000053:notes:20]

[0001032975-18-000007:notes:23]
[same as prior period, unchanged from 0001032975-17-000053:notes:21]

[0001032975-18-000007:notes:24]
In July 2015, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2015-11, "Simplifying the Measurement of Inventory (Topic 330)" ("ASU 2015-11"). Topic 330 previously required an entity to measure inventory at the lower of cost or market, with market value represented by replacement cost, net realizable value or net realizable value less a normal profit margin. ASU 2015-11 requires an entity to measure inventory at the lower of cost or net realizable value and is effective for fiscal years beginning after December 15, 2016. The Company adopted this standard effective April 1, 2017, which has not had a material impact on its consolidated financial statements.

[0001032975-18-000007:notes:25]
In March 2016, the FASB issued ASU 2016-09, "Compensation-Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting" ("ASU 2016-09"). ASU 2016-09 simplifies several aspects of the accounting for share-based payments, including immediate recognition of all excess tax benefits and deficiencies in the income statement, changing the threshold to qualify for equity classification up to the employees' maximum statutory tax rates, allowing an entity-wide accounting policy election to either estimate the number of awards that are expected to vest or account for forfeitures as they occur, and clarifying the classification on the statement of cash flows for the excess tax benefits and employee taxes paid when an employer withholds shares for tax withholding purposes. ASU 2016-09 is effective for fiscal years beginning after December 15, 2016. The Company adopted this standard effective April 1, 2017. Changes to the statements of cash flows related to the classification of excess tax benefits were implemented on a retroactive basis and accordingly, to conform to the current year presentation, the Company reclassified $6.4 million of excess tax benefits previously reported under financing activities to operating activities for the nine months ended December 31, 2016 on its condensed consolidated statements of cash flows. Under the new standard, the Company accounts for forfeitures as they occur. The change in accounting for forfeitures resulted in a cumulative-effect adjustment to decrease retained earnings as of March 31, 2017 by $3.3 million. The Company further recognized a cumulative-effect adjustment to increase retained earnings as of March 31, 2017 by $57.2 million upon adoption of the new guidance to account for gross excess tax benefits of $75.2 million that were previously not recognized because the related tax deduction had not reduced current income taxes, offset by a valuation allowance of $18.0 million to reduce the deferred tax assets to amounts that are more likely than not to be realized.

[0001032975-18-000007:notes:26]
In January 2017, the FASB issued ASU 2017-04, "Simplifying the Test for Goodwill Impairment (Topic

[0001032975-18-000007:notes:27]
350)" ("ASU 2017-04"), which removes Step 2 from the goodwill impairment test. ASU 2017-04 is effective for annual or any interim goodwill impairments in annual periods beginning December 15, 2019, with early adoption permitted. The Company adopted this standard effective April 1, 2017, which has not had a material impact on its consolidated financial statements.

[0001032975-18-000007:notes:28]
In May 2017, the FASB issued ASU 2017-09, "Compensation-Stock Compensation (Topic 718): Scope of

[0001032975-18-000007:notes:29]
Modification Accounting" ("ASU 2017-09"), which provides guidance about which changes to the terms or conditions

[0001032975-18-000007:notes:30]
of a share-based payment award require an entity to apply modification accounting in Topic 718. ASU 2017-09 is

[0001032975-18-000007:notes:31]
[same as prior period, unchanged from 0001032975-17-000053:notes:29]

[0001032975-18-000007:notes:32]
[same as prior period, unchanged from 0001032975-17-000053:notes:30]

[0001032975-18-000007:notes:33]
In May 2014, the FASB issued ASU No. 2014-09, "Revenue from Contracts with Customers (Topic 606)" ("ASU 2014-09") which supersedes the revenue recognition requirements under Accounting Standard Codification ("ASC") 605, Revenue Recognition. ASU 2014-09 outlines a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. Under the new model, recognition of revenue occurs when a customer obtains control of promised goods or services in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. The new standard requires reporting companies to disclose the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. The new standard will become effective for the Company on April 1, 2018. The Company will adopt Topic 606 utilizing the modified retrospective transition method, which recognizes the cumulative effect of initially applying Topic 606 as an adjustment to retained earnings at the adoption date. The Company continues to evaluate the impact this new standard will have on the current contracts with customers and the accruals of various sales and marketing programs the Company offers and has identified the following areas that are impacted:

[0001032975-18-000007:notes:34]
Accrual for cooperative marketing arrangements and customer incentive programs: At the end of every quarter, the Company estimates accruals for cooperative marketing arrangements and customer incentive programs based on negotiated terms, consideration of historical experience, and inventory levels in the channel. Under ASC 605, these programs are recognized as a reduction of revenue at the later of when the related revenue is recognized or when the program is offered to the customer. Under Topic 606, these programs qualify as variable consideration and are recorded as a reduction of the transaction price at the contract inception based on the expected value method. Certain of these programs will reflect such change which will lead to the recognition of the accruals sooner as compared to the guidance in ASC 605.

[0001032975-18-000007:notes:35]
Breakage estimates: The Company applies a breakage rate to reduce its accruals of customer incentive, cooperative marketing, and pricing programs based on the estimated percentage of these customer programs that will not be claimed or earned. The breakage rate is applied when the Company is able to reasonably estimate the amounts that will be ultimately claimed by customers, which generally occurs up to one quarter after the program is accrued.  Under Topic 606, variable consideration must be estimated at the outset of the arrangement, subject to the constraint guidance to ensure that a significant revenue reversal will not occur. As a result, upon adoption of Topic 606, revenue will be recognized sooner as compared to the existing revenue guidance.

[0001032975-18-000007:notes:36]
The Company expects to complete its analysis of Topic 606 and reasonably estimate the impact to its consolidated financial statements when its Annual Report on Form 10-K for the fiscal year ending March 31, 2018 is filed. The Company will continue to monitor additional changes, modifications, clarifications or interpretations being undertaken by the FASB, which may impact its current conclusions. It is possible that during the fourth quarter of fiscal year 2018, the Company may identify additional areas which may result in material impact on the Company’s consolidated financial statements.

[0001032975-18-000007:notes:37]
In January 2016, the FASB issued ASU 2016-01, "Financial Instruments-Recognition and Measurement of Financial Assets and Financial Liabilities (Subtopic 825-10)" ("ASU 2016-01"). ASU 2016-01 is effective for annual periods beginning after December 15, 2017, including interim periods within those annual periods, with early adoption permitted. The Company does not believe that the adoption of ASU 2016-01 will have a material impact on its consolidated financial statements and will adopt this standard effective April 1, 2018.

[0001032975-18-000007:notes:38]
In February 2016, the FASB issued ASU 2016-02, "Leases (Topic 842)" ("ASU 2016-02"), which requires the recognition of lease assets and lease liabilities arising from operating leases in the statement of financial position. ASU 2016-02 is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years, with early adoption permitted. The Company is evaluating the full effect that ASU 2016-02 will have on its consolidated financial statements and will adopt this standard effective April 1, 2019.

[0001032975-18-000007:notes:39]
In October 2016, the FASB issued ASU 2016-16, "Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory" ("ASU 2016-16"), which eliminates the deferral of income tax effects of intra-entity asset transfers until the transferred asset is sold to an unrelated party or recovered through use. However, this standard does not apply to intra-entity transfer of inventory.  ASU 2016-16 is effective for annual periods beginning after December 15, 2017, including interim periods within those annual periods, with early adoption permitted but only in the first interim period of an annual period. The cumulative effect of change on equity upon adoption is to be quantified under the modified retrospective approach and recorded as of the beginning of the period of adoption.  The Company does not expect the adoption of ASU 2016-16 will have a material impact on its consolidated financial statements and will adopt this standard effective April 1, 2018.

[0001032975-18-000007:notes:40]
In December 2016, the FASB issued ASU 2016-18, "Statement of Cash Flows (Topic 230): Restricted Cash" ("ASU 2016-18"), which requires that a statement of cash flows explains the change during the period in the total of cash, cash equivalents, and amounts generally described as restricted cash or restricted cash equivalents.  ASU 2016-18 is effective for annual periods beginning after December 15, 2017, including interim periods within those annual periods, with early adoption permitted. The adoption of this standard should be applied using a retrospective transition method to each period presented. The Company does not expect that the adoption of ASU 2016-18 will have a material impact on its consolidated financial statements and will adopt this standard effective April 1, 2018.

[0001032975-18-000007:notes:41]
In January 2017, the FASB issued ASU 2017-01, "Business Combination (Topic 805): Clarifying the Definition of a Business" ("ASU 2017-01"), which changes the definition of a business to assist with evaluating when a set of transferred assets and activities is a business. ASU 2017-01 is effective for annual or any interim periods in annual periods beginning after December 15, 2017, with early adoption permitted. The Company does not expect that the adoption of ASU 2017-01 will have a material impact on its consolidated financial statements and will adopt this standard effective April 1, 2018.

[0001032975-18-000007:notes:42]
In March 2017, the FASB issued ASU 2017-07, "Compensation-Retirement Benefit (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost" ("ASU 2017-07"), which requires that the Company disaggregate the service cost component from the other components of net benefit cost, and also provides guidance on how to present the service cost component and the other components of net benefit cost in the income statement and allow only the service cost component of net benefit cost to be eligible for capitalization. ASU 2017-07 is effective for annual periods beginning after December 15, 2017, including interim periods within those annual periods, with early adoption permitted. The Company does not expect that the adoption of ASU 2017-07 will have a material impact on its consolidated financial statements and will adopt this standard effective April 1, 2018.

[0001032975-18-000007:notes:43]
In August 2017, the FASB issued ASU 2017-12, "Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities" ("ASU 2017-12"), which improves the financial reporting of hedging relationships to better portray the economic results of an entity’s risk management activities in its financial statements and simplifies the application of the hedge accounting guidance. ASU 2017-12 is effective for annual periods beginning after December 15, 2018, including interim periods within those annual periods, with early adoption permitted. The Company does not expect that the adoption of ASU 2017-12 will have a material impact on its consolidated financial statements and will adopt this standard effective April 1, 2019.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001032975-18-000007:notes:44]
[same as prior period, unchanged from 0001032975-17-000053:notes:39]

[0001032975-18-000007:notes:45]
On August 11, 2017 (the "Acquisition Date"), the Company acquired certain assets and liabilities constituting the ASTRO Gaming business ("ASTRO") from AG Acquisition Corporation for a purchase price of $85.0 million in cash (the "ASTRO Acquisition"). ASTRO is a leading console gaming accessory brand with a history of producing award-winning headsets for professional gamers and enthusiasts. ASTRO provides a strong growth platform in the console gaming accessories market.

[0001032975-18-000007:notes:46]
ASTRO meets the definition of a business, and its acquisition is accounted for using the acquisition method. The following table summarizes the estimated fair values of the assets acquired and liabilities assumed at the Acquisition Date (in thousands):

[0001032975-18-000007:notes:47]
|  |  | Estimated Fair Value |
| Inventories |  | $ | 10,331 |  |
| Property, plant and equipment |  | 2,760 |  |
| Intangible assets |  | 52,520 |  |
| Other assets |  | 605 |  |
| Total identifiable assets acquired |  | $ | 66,216 |  |
| Accrued liabilities |  | (2,982 | ) |
| Net identifiable assets acquired |  | $ | 63,234 |  |
| Goodwill |  | 21,766 |  |
| Net assets acquired |  | $ | 85,000 |  |

[0001032975-18-000007:notes:48]
[same as prior period, unchanged from 0001032975-17-000053:notes:43]

[0001032975-18-000007:notes:49]
The fair value of the inventory acquired is estimated at its net realizable value, which uses the estimated selling prices, less the cost of disposal and a reasonable profit allowance for the selling efforts. The difference between the fair value of the inventories and the amount recorded by ASTRO immediately before the acquisition date is $0.8 million, which will be recognized in "amortization of intangibles assets and purchase accounting effect on inventory" in the condensed consolidated statements of operations upon the sale of the acquired inventory.

[0001032975-18-000007:notes:50]
The Company included ASTRO's estimated fair value of assets acquired and liabilities assumed in its condensed consolidated balance sheets beginning on the Acquisition Date. The results of operations for ASTRO for this partial quarter have been included in, but are not material to, the Company's condensed consolidated statements of operations from the Acquisition Date. Pro forma results of operations for the ASTRO Acquisition have not been presented because they are not material to the condensed consolidated statements of operations.

[0001032975-18-000007:notes:51]
The following table summarizes the estimated fair values and estimated useful lives of the components of identifiable intangible assets acquired as of the Acquisition Date (Dollars in thousands):

[0001032975-18-000007:notes:52]
|  | Fair Value |  | Estimated Useful Life (years) |
| Developed technology | $ | 12,540 |  |  | 4.0 |
| Customer relationships | 33,100 |  |  | 8.0 |
| Trade name | 6,880 |  |  | 6.0 |
| Total intangible assets acquired | $ | 52,520 |  |  | 6.8 |

[0001032975-18-000007:notes:53]
Intangible assets acquired as a result of the ASTRO Acquisition are being amortized over their estimated useful lives using the straight-line method of amortization. Amortization of acquired developed technology of $0.8 million and $1.2 million, respectively, during the three and nine months ended December 31, 2017 is included in "amortization of intangible assets and purchase accounting effect of inventory" in the condensed consolidated statements of operations. Amortization of the acquired customer relationships and trade name of $1.3 million and $2.0 million, respectively, during the three and nine months ended December 31, 2017 is included in "amortization of intangible assets and acquisition-related costs" in the condensed consolidated statements of operations.

[0001032975-18-000007:notes:54]
[same as prior period, unchanged from 0001032975-17-000053:notes:49]

[0001032975-18-000007:notes:55]
[same as prior period, unchanged from 0001032975-17-000053:notes:50]

[0001032975-18-000007:notes:56]
[same as prior period, unchanged from 0001032975-17-000053:notes:51]

[0001032975-18-000007:notes:57]
The fair values of developed technology and trade name were estimated using the relief-from-royalty method, an income approach (Level 3), which estimates the cost savings that accrue to the owner of the intangible assets that would otherwise be payable as royalties or license fees on revenues earned through the use of the asset. A royalty rate is applied to the projected revenues associated with the intangible assets to determine the amount of savings, which is then discounted to determine the fair value. The developed technology and trade name were valued using royalty rates of 10% and 2%, respectively, and both were discounted at a rate of 13%.

[0001032975-18-000007:notes:58]
[same as prior period, unchanged from 0001032975-17-000053:notes:53]

[0001032975-18-000007:notes:59]
The Company believes the value of purchased intangible assets recorded above represents the fair values of, and approximates the amounts a market participant would pay for, these intangible assets as of the Acquisition Date.

[0001032975-18-000007:notes:60]
The Company incurred acquisition-related costs for the ASTRO Acquisition of approximately $0.3 million and $1.3 million for the three and nine months ended December 31, 2017, respectively. The acquisition-related costs are included in "amortization of intangible assets and acquisition-related costs" in the condensed consolidated statements of operations.

[0001032975-18-000007:notes:61]
For the three and nine months ended December 31, 2017, ASTRO contributed $33.5 million and $36.2 million to net sales, respectively, representing approximately 4% of the net sales of the Company for the three-month period and 2% for the nine-month period.

[0001032975-18-000007:notes:62]
In November 2017, the Company also made a small acquisition for a total consideration of $5.2 million, including cash acquired of $0.9 million. $1.0 million of the total consideration was retained by the Company for the purpose of ensuring the seller's representations, warranties and covenants.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001032975-18-000007:notes:63]
Commitments and Contingencies

[0001032975-18-000007:notes:64]
Product Warranties

[0001032975-18-000007:notes:65]
All of the Company’s peripherals products sold are covered by warranty to be free from defects in material and workmanship. The warranty period varies by product and by region.

[0001032975-18-000007:notes:66]
Changes in the Company’s warranty liability for the three and nine months ended December 31, 2017 and 2016 were as follows (in thousands):

[0001032975-18-000007:notes:67]
|  | Three Months EndedDecember 31, |  | Nine Months Ended December 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Beginning of the period | $ | 24,349 |  |  | $ | 21,612 |  |  | $ | 21,911 |  |  | $ | 20,380 |  |
| Assumed from business acquisition | — |  |  | — |  |  | 1,230 |  |  | 1,963 |  |
| Provision | 7,820 |  |  | 4,521 |  |  | 17,535 |  |  | 10,861 |  |
| Settlements | (6,050 | ) |  | (3,550 | ) |  | (15,229 | ) |  | (10,430 | ) |
| Currency translation | 145 |  |  | (462 | ) |  | 817 |  |  | (653 | ) |
| End of the period | $ | 26,264 |  |  | $ | 22,121 |  |  | $ | 26,264 |  |  | $ | 22,121 |  |

[0001032975-18-000007:notes:68]
Guarantees

[0001032975-18-000007:notes:69]
Logitech Europe S.A., one of our wholly-owned subsidiaries, guaranteed payments of certain third-party contract manufacturers’ purchase obligations. As of December 31, 2017, the maximum amount of this guarantee was $3.8 million, of which $1.7 million of guaranteed purchase obligations were outstanding.

[0001032975-18-000007:notes:70]
Indemnifications

[0001032975-18-000007:notes:71]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of December 31, 2017, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

[0001032975-18-000007:notes:72]
The Company also indemnifies its current and former directors and certain of its current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. The Company is unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not limited, the obligations are conditional in nature and the facts and circumstances involved in any situation that might arise are variable.

[0001032975-18-000007:notes:73]
The stock purchase agreement entered on December 28, 2015 in connection with the investment by three venture capital firms in Lifesize contains representations, warranties and covenants of Logitech and Lifesize, Inc. to the Investors. Logitech has agreed, subject to certain limitations, to indemnify the Investors and certain persons related to the Investors for certain losses resulting from breaches of or inaccuracies in such representations, warranties and covenants as well as certain other obligations, including third-party expenses, restructuring costs and pre-closing tax obligations of Lifesize.

[0001032975-18-000007:notes:74]
Legal Proceedings

[0001032975-18-000007:notes:75]
From time to time the Company is involved in claims and legal proceedings that arise in the ordinary course of its business. The Company is currently subject to several such claims and a small number of legal proceedings. The Company believes that these matters lack merit and intends to vigorously defend against them. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company’s defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company’s business, financial condition, cash flows or results of operations in a particular period. Any claims or proceedings against the Company, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain a necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company’s business.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001032975-18-000007:notes:76]
[same as prior period, unchanged from 0001032975-17-000053:notes:70]

[0001032975-18-000007:notes:77]
[same as prior period, unchanged from 0001032975-17-000053:notes:71]

[0001032975-18-000007:notes:78]
As of December 31, 2017, the Company offers the 2006 ESPP (2006 Employee Share Purchase Plan (Non-U.S.)), the 1996 ESPP (1996 Employee Share Purchase Plan (U.S.)), the 2006 Plan (2006 Stock Incentive Plan) and the 2012 Plan (2012 Stock Inducement Equity Plan), each as amended.

[0001032975-18-000007:notes:79]
The following table summarizes the share-based compensation expense and total income tax provision (benefit) recognized for share-based awards for the three and nine months ended December 31, 2017 and 2016 (in thousands):

[0001032975-18-000007:notes:80]
|  |  | Three Months EndedDecember 31, |  | Nine Months Ended December 31, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Cost of goods sold |  | $ | 960 |  |  | $ | 617 |  |  | $ | 2,762 |  |  | $ | 1,930 |  |
| Marketing and selling |  | 4,624 |  |  | 4,006 |  |  | 13,348 |  |  | 10,687 |  |
| Research and development |  | 1,621 |  |  | 1,176 |  |  | 4,797 |  |  | 3,007 |  |
| General and administrative |  | 4,351 |  |  | 3,588 |  |  | 12,332 |  |  | 10,730 |  |
| Total share-based compensation expense |  | 11,556 |  |  | 9,387 |  |  | 33,239 |  |  | 26,354 |  |
| Income tax provision (benefit) |  | 3,038 |  |  | (2,391 | ) |  | (11,921 | ) |  | (6,092 | ) |
| Total share-based compensation expense, net of income tax |  | $ | 14,594 |  |  | $ | 6,996 |  |  | $ | 21,318 |  |  | $ | 20,262 |  |

[0001032975-18-000007:notes:81]
The income tax benefit in the respective period primarily consists of tax benefit related to the share-based compensation expense for the period and direct tax benefit realized, including net excess tax benefits recognized from share-based awards vested or exercised during the period. The income tax benefit is reduced by income tax provision resulting from remeasurement of applicable federal deferred tax assets due to the enactment of H.R.1, also known as the "Tax Cuts and Jobs Act" ("the Tax Act") in the United States on December 22, 2017. See "Note 5 - Income Taxes" for more information.

[0001032975-18-000007:notes:82]
As of December 31, 2017 and 2016, the Company capitalized $0.8 million and $0.6 million of share-based compensation expense to inventory, respectively.

[0001032975-18-000007:notes:83]
[same as prior period, unchanged from 0001032975-17-000053:notes:77]

[0001032975-18-000007:notes:84]
Certain of the Company’s subsidiaries sponsor defined benefit pension plans or non-retirement post-employment benefits covering substantially all of their employees. Benefits are provided based on employees’ years of service and earnings, or in accordance with applicable employee benefit regulations. The Company’s practice is to fund amounts sufficient to meet the requirements set forth in the applicable employee benefit and tax regulations. The cost recorded of $2.3 million and $2.8 million for the three months ended December 31, 2017 and 2016, respectively, and $6.9 million and $8.4 million for the nine months ended December 31, 2017 and 2016, respectively, was primarily related to service costs.


## us-gaap:DebtDisclosureTextBlock

[0001032975-18-000007:notes:85]
Financing Arrangements

[0001032975-18-000007:notes:86]
The Company had several uncommitted, unsecured bank lines of credit aggregating $62.1 million as of December 31, 2017. There are no financial covenants under these lines of credit with which the Company must comply. As of December 31, 2017, the Company had outstanding bank guarantees of $44.2 million under these lines of credit. There was no borrowing outstanding under these lines of credit as of December 31, 2017 or March 31, 2017.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001032975-18-000007:notes:87]
[same as prior period, unchanged from 0001032975-17-000053:notes:81]

[0001032975-18-000007:notes:88]
Under certain agreements with the respective counterparties to the Company’s derivative contracts, subject to applicable requirements, the Company is allowed to net settle transactions of the same type with a single net amount payable by one party to the other. However, the Company presents its derivative assets and derivative liabilities on a gross basis on the condensed consolidated balance sheets as of December 31, 2017 and March 31, 2017.

[0001032975-18-000007:notes:89]
The fair values of the Company’s derivative instruments not designated as hedging instruments were not material as of December 31, 2017 or March 31, 2017. The following table presents the fair values of the Company’s derivative instruments designated as hedging instruments on a gross basis in other current assets or accrued and other current liabilities on its condensed consolidated balance sheets as of December 31, 2017 and March 31, 2017 (in thousands):

[0001032975-18-000007:notes:90]
|  |  | Derivatives |
|  |  | Asset |  | Liability |
|  |  | December 31,2017 |  | March 31,2017 |  | December 31,2017 |  | March 31,2017 |
| Cash flow hedges |  | $ | 235 |  |  | $ | 48 |  |  | $ | 1,327 |  |  | $ | 402 |  |

[0001032975-18-000007:notes:91]
The amount of gain (loss) recognized on derivatives not designated as hedging instruments was not material in all periods presented herein. The following table presents the amounts of gains (losses) on the Company’s derivative instruments designated as hedging instruments and their locations on its condensed consolidated statements of operations and condensed consolidated statements of comprehensive income for the three and nine months ended December 31, 2017 and 2016 (in thousands):

[0001032975-18-000007:notes:92]
|  |  | Three Months EndedDecember 31, |
|  |  | Amount of Gain (Loss)Deferred as a Component of AccumulatedOther Comprehensive Loss |  | Amount of Loss (Gain)Reclassified from Accumulated Other Comprehensive Loss to Costs of Goods Sold |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Cash flow hedges |  | $ | (677 | ) |  | $ | 2,497 |  |  | $ | 2,248 |  |  | $ | (463 | ) |

[0001032975-18-000007:notes:93]
|  |  | Nine Months Ended December 31, |
|  |  | Amount of Gain (Loss)Deferred as a Component of AccumulatedOther Comprehensive Loss |  | Amount of LossReclassified from Accumulated Other Comprehensive Loss to Costs of Goods Sold |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Cash flow hedges |  | $ | (6,026 | ) |  | $ | 4,026 |  |  | $ | 5,377 |  |  | $ | 432 |  |

[0001032975-18-000007:notes:94]
[same as prior period, unchanged from 0001032975-17-000053:notes:88]

[0001032975-18-000007:notes:95]
The Company enters into cash flow hedge contracts to protect against exchange rate exposure of forecasted inventory purchases. These hedging contracts mature within four months. Gains and losses in the fair value of the effective portion of the hedges are deferred as a component of accumulated other comprehensive loss until the hedged inventory purchases are sold, at which time the gains or losses are reclassified to cost of goods sold. Cash flows from such hedges are classified as operating activities in the condensed consolidated statements of cash flows.  Hedging relationships are discontinued when hedging contract is no longer eligible for hedge accounting, or is sold, terminated or exercised, or when Company removes hedge designation for the contract. Gains and losses in the fair value of the effective portion of the discontinued hedges continue to be reported in accumulated other comprehensive loss until the hedged inventory purchases are sold, unless it is probable that the forecasted inventory purchases will not occur by the end of the originally specified time period or within an additional two-month period of time thereafter. In all periods presented herein, there have been no forecasted inventory purchases that were probable to not occur by the end of the originally specified time period or within an additional two-month period of time thereafter. The notional amounts of foreign currency exchange forward contracts outstanding related to forecasted inventory purchases were $135.0 million and $59.4 million as of December 31, 2017 and March 31, 2017, respectively. The Company estimates that $1.2 million of net losses related to its cash flow hedges included in accumulated other comprehensive loss as of December 31, 2017 will be reclassified into earnings within the next 12 months.

[0001032975-18-000007:notes:96]
[same as prior period, unchanged from 0001032975-17-000053:notes:90]

[0001032975-18-000007:notes:97]
The Company also enters into foreign currency exchange forward and swap contracts to reduce the short-term effects of currency exchange rate fluctuations on certain receivables or payables denominated in currencies other than the functional currencies of its subsidiaries. These contracts generally mature within one month. The primary risk managed by using forward and swap contracts is the currency exchange rate risk. The gains or losses on these contracts are recognized in other income (expense), net in the condensed consolidated statements of operations based on the changes in fair value. The notional amounts of these contracts outstanding as of December 31, 2017 and March 31, 2017 were $89.0 million and $56.7 million, respectively. Open forward and swap contracts outstanding as of December 31, 2017 and March 31, 2017 consisted of contracts in Mexican Pesos, Japanese Yen, British Pounds, Taiwanese Dollars, Canadian Dollars, Australian Dollars and Chinese Renminbi to be settled at future dates at pre-determined exchange rates.

[0001032975-18-000007:notes:98]
[same as prior period, unchanged from 0001032975-17-000053:notes:92]


## us-gaap:EarningsPerShareTextBlock

[0001032975-18-000007:notes:99]
[same as prior period, unchanged from 0001032975-17-000053:notes:93]

[0001032975-18-000007:notes:100]
[same as prior period, unchanged from 0001032975-17-000053:notes:94]

[0001032975-18-000007:notes:101]
|  |  | Three Months EndedDecember 31, |  | Nine Months Ended December 31, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Net Income |  | $ | 80,773 |  |  | $ | 97,465 |  |  | $ | 174,138 |  |  | $ | 166,451 |  |
| Shares used in net income per share computation: |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding - basic |  | 164,248 |  |  | 161,977 |  |  | 163,924 |  |  | 162,070 |  |
| Effect of potentially dilutive equivalent shares |  | 4,831 |  |  | 3,924 |  |  | 4,908 |  |  | 3,141 |  |
| Weighted average shares outstanding - diluted |  | 169,079 |  |  | 165,901 |  |  | 168,832 |  |  | 165,211 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.49 |  |  | $ | 0.60 |  |  | $ | 1.06 |  |  | $ | 1.03 |  |
| Diluted |  | $ | 0.48 |  |  | $ | 0.59 |  |  | $ | 1.03 |  |  | $ | 1.01 |  |

[0001032975-18-000007:notes:102]
Share equivalents attributable to outstanding stock options and restricted stock units of 0.5 million and 1.7 million for the three months ended December 31, 2017 and 2016, respectively, and 1.1 million and 2.8 million for the nine months ended December 31, 2017 and 2016, respectively, were anti-dilutive and excluded from the calculation of diluted net income per share.


## us-gaap:FairValueLiabilitiesMeasuredOnRecurringBasisUnobservableInputReconciliationTextBlock

[0001032975-18-000007:notes:103]
The following table summarizes the changes in fair value of the Company’s contingent consideration balance measured with Level 3 inputs during the three and nine months ended December 31, 2017 and 2016 (in thousands):

[0001032975-18-000007:notes:104]
|  |  | Three Months EndedDecember 31, |  | Nine Months Ended December 31, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Beginning of the period |  | $ | — |  |  | $ | 18,000 |  |  | $ | 9,908 |  |  | $ | — |  |
| Fair value of contingent consideration upon acquisition |  | — |  |  | — |  |  | — |  |  | 18,000 |  |
| Change in fair value of contingent consideration |  | — |  |  | (9,925 | ) |  | (4,908 | ) |  | (9,925 | ) |
| Expected payment (see below) |  | — |  |  | — |  |  | (5,000 | ) |  | — |  |
| End of the period |  | $ | — |  |  | $ | 8,075 |  |  | $ | — |  |  | $ | 8,075 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001032975-18-000007:notes:105]
[same as prior period, unchanged from 0001032975-17-000053:notes:99]

[0001032975-18-000007:notes:106]
[same as prior period, unchanged from 0001032975-17-000053:notes:100]

[0001032975-18-000007:notes:107]
[same as prior period, unchanged from 0001032975-17-000053:notes:101]

[0001032975-18-000007:notes:108]
•Level 2 — Observable inputs other than quoted market prices included in Level 1, such as: quoted prices for similar assets and liabilities in active markets; quoted prices for identical or similar assets and liabilities in markets that are not active; or other inputs that are observable or can be corroborated by observable market data.

[0001032975-18-000007:notes:109]
[same as prior period, unchanged from 0001032975-17-000053:notes:103]

[0001032975-18-000007:notes:110]
[same as prior period, unchanged from 0001032975-17-000053:notes:104]

[0001032975-18-000007:notes:111]
|  |  | December 31, 2017 |  | March 31, 2017 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Level 1 |  | Level 2 |  | Level 3 |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 402,983 |  |  | $ | — |  |  | $ | — |  |  | $ | 448,742 |  |  | $ | — |  |  | $ | — |  |
| Trading investments for deferred compensation plan included in other assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 4,229 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,813 |  |  | $ | — |  |  | $ | — |  |
| Mutual funds |  | 13,769 |  |  | — |  |  | — |  |  | 12,230 |  |  | — |  |  | — |  |
| Total of trading investments for deferred compensation plan |  | $ | 17,998 |  |  | $ | — |  |  | $ | — |  |  | $ | 15,043 |  |  | $ | — |  |  | $ | — |  |
| Currency exchange derivative assetsincluded in other current assets |  | $ | — |  |  | $ | 235 |  |  | $ | — |  |  | $ | — |  |  | $ | 48 |  |  | $ | — |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisition-related contingentconsideration included in accrued andother current liabilities and other non-current liabilities |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 9,908 |  |
| Currency exchange derivative liabilitiesincluded in accrued and other current liabilities |  | $ | — |  |  | $ | 1,392 |  |  | $ | — |  |  | $ | — |  |  | $ | 443 |  |  | $ | — |  |

[0001032975-18-000007:notes:112]
[same as prior period, unchanged from 0001032975-17-000053:notes:106]

[0001032975-18-000007:notes:113]
On April 20, 2016 (the "Jaybird Acquisition Date"), the Company acquired all of the equity interests of Jaybird, LLC (“Jaybird”). The acquisition-related contingent consideration liability arising from the Jaybird acquisition represented the future potential earn-out payments of up to $45.0 million based on the achievement of certain net revenue targets over approximately a two-year period. If the net revenue targets were met, the Company would have paid a maximum of $25.0 million and $20.0 million in fiscal years 2018 and 2019, respectively. The fair value of the earn-out as of the Jaybird Acquisition Date was $18.0 million, which was determined by using a Monte Carlo Simulation that includes significant unobservable inputs such as a risk-adjusted discount rate of 16% and projected net sales of Jaybird over the earn-out period. The fair value was remeasured at each reporting period based on the inputs on the date of remeasurement, with the change in fair value recognized as "change in fair value of contingent consideration for business acquisition" in the operating expense section in the condensed consolidated statements of operations. Projected net sales were based on the Company's internal projections, including analysis of the target markets. In October 2017, before the issuance of the condensed financial statements for the three months ended September 30, 2017, the Company and the sellers of Jaybird entered into an agreement fully, irrevocably and unconditionally releasing the Company from the earn-out rights and payments in exchange for $5.0 million in cash, which approximated the fair value of the contingent consideration as of September 30, 2017. As a result, the contingent consideration was transferred out from financial liability with Level 3 inputs as of September 30, 2017 as fair value measurement was no longer required. The Company paid the $5.0 million in November 2017 and included the same as financing activities on its condensed consolidated statements of cash flows.

[0001032975-18-000007:notes:114]
[same as prior period, unchanged from 0001032975-17-000053:notes:108]

[0001032975-18-000007:notes:115]
The marketable securities for the Company's deferred compensation plan are recorded at a fair value of $18.0 million and $15.0 million, respectively, as of December 31, 2017 and March 31, 2017, based on quoted market prices. Quoted market prices are observable inputs that are classified as Level 1 within the fair value hierarchy. Unrealized trading gains (losses) related to trading securities for the three and nine months ended December 31, 2017 and 2016 were not material and are included in other income (expense), net in the Company's condensed consolidated statements of operations.

[0001032975-18-000007:notes:116]
[same as prior period, unchanged from 0001032975-17-000053:notes:110]

[0001032975-18-000007:notes:117]
The Company’s non-marketable cost method investments, and non-financial assets, such as goodwill, intangible assets and property, plant and equipment, are recorded at fair value only upon initial recognition or if an impairment is recognized. There were no material impairments of long-lived assets during the three and nine months ended December 31, 2017 or 2016.

[0001032975-18-000007:notes:118]
[same as prior period, unchanged from 0001032975-17-000053:notes:112]

[0001032975-18-000007:notes:119]
[same as prior period, unchanged from 0001032975-17-000053:notes:113]

[0001032975-18-000007:notes:120]
The aggregate recorded amount of cost method investments included in other assets as of December 31, 2017 and March 31, 2017 was $7.1 million and $7.4 million, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001032975-18-000007:notes:121]
[same as prior period, unchanged from 0001032975-17-000053:notes:115]

[0001032975-18-000007:notes:122]
The Company conducts its impairment analysis of the goodwill annually at December 31 and as necessary, if changes in facts and circumstances indicate that it is more likely than not that the fair value of the Company’s reporting units may be less than its carrying amount.

[0001032975-18-000007:notes:123]
The Company performed its annual impairment analysis of the goodwill as of December 31, 2017 by performing a qualitative assessment and concluded that it was more likely than not that the fair value of its peripherals reporting unit, the only reportable segment of the Company, exceeded its carrying amount. In assessing the qualitative factors, the Company considered the impact of the following key factors: change in industry and competitive environment, growth in the Company's market capitalization and budgeted-to-actual revenue performance from the last twelve months.

[0001032975-18-000007:notes:124]
The following table summarizes the activities in the Company’s goodwill balance during the nine months ended December 31, 2017 (in thousands):

[0001032975-18-000007:notes:125]
| As of March 31, 2017 |  | $ | 249,741 |  |
| Business acquisitions |  | 25,800 |  |
| Currency translation |  | 22 |  |
| As of December 31, 2017 |  | $ | 275,563 |  |

[0001032975-18-000007:notes:126]
[same as prior period, unchanged from 0001032975-17-000053:notes:119]

[0001032975-18-000007:notes:127]
|  |  | December 31, 2017 |  | March 31, 2017 |
|  |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |
| Trademark and trade names |  | $ | 23,790 |  |  | $ | (8,719 | ) |  | $ | 15,071 |  |  | $ | 16,500 |  |  | $ | (6,933 | ) |  | $ | 9,567 |  |
| Developed Technology |  | 76,875 |  |  | (48,352 | ) |  | 28,523 |  |  | 63,285 |  |  | (42,831 | ) |  | 20,454 |  |
| Customer contracts/relationships |  | 59,760 |  |  | (10,983 | ) |  | 48,777 |  |  | 25,180 |  |  | (7,637 | ) |  | 17,543 |  |
| Total |  | $ | 160,425 |  |  | $ | (68,054 | ) |  | $ | 92,371 |  |  | $ | 104,965 |  |  | $ | (57,401 | ) |  | $ | 47,564 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001032975-18-000007:notes:128]
[same as prior period, unchanged from 0001032975-17-000053:notes:121]

[0001032975-18-000007:notes:129]
[same as prior period, unchanged from 0001032975-17-000053:notes:122]

[0001032975-18-000007:notes:130]
The income tax provision for the three months ended December 31, 2017 was $20.0 million based on an effective income tax rate of 19.9% of pre-tax income, compared to an income tax provision of $1.6 million based on an effective income tax rate of 1.7% of pre-tax income for the three months ended December 31, 2016. The income tax provision for the nine months ended December 31, 2017 was $18.7 million based on an effective income tax rate of 9.7% of pre-tax income, compared to an income tax provision of $10.3 million based on an effective income tax rate of 5.8% for the nine months ended December 31, 2016.

[0001032975-18-000007:notes:131]
On December 22, 2017, the Tax Act was signed into law in the United States. The Tax Act introduced a broad range of tax reform measures that significantly change the federal income tax regime. Among other things, the Tax Act permanently reduces the corporate income tax rate from 35% to 21% effective for tax years including or commencing on January 1, 2018, repeals corporate alternative minimum tax, limits various business deductions, modifies the maximum deduction of net operating loss with no carryback but indefinite carryforward provision and includes various international tax provisions.  Many provisions in the Tax Act are generally effective in tax years beginning after December 31, 2017.

[0001032975-18-000007:notes:132]
ASC 740 requires recognition of the effects of tax law changes in the period of enactment. Notwithstanding that the effective date of the Tax Act for most provisions is January 1, 2018, such effects must be recognized in December 2017 financial statements. In accordance to the new tax legislation, the Company applied a blended federal income tax rate of 31.6% to its operations in the United States effective at the beginning of the fiscal year based on a pro-rated percentage of the number of days before and after January 1, 2018. Furthermore, the Company recorded an income tax charge of $19.9 million from the estimated remeasurement of federal deferred tax assets and liabilities as of December 31, 2017 to reflect the effects of the enacted changes in tax rate and an income tax benefit of $4.1 million from assessment of valuation allowance against tax credits due to changes in tax laws. These amounts account for the change in the effective income tax rate in the three months ended December 31, 2017 compared to the same period of the prior fiscal year.

[0001032975-18-000007:notes:133]
The estimated remeasurement of deferred tax assets and liabilities was based on tax rates generally at 31.6% and 21% depending on the timing of when the individual deferred tax assets and liabilities are expected to recover or settle in the future. The net provisional charge from deferred tax remeasurement and assessment of valuation allowance is based on currently available information and interpretations which are continuing to evolve. The Company continues to analyze additional information and guidance related to certain aspects of the Tax Act, such as limitations on the deductibility of executive compensation, conformity or changes by state taxing authorities in response to the Tax Act, and the final determination of the net deferred tax assets subject to the remeasurement and related impacts to the assessment of valuation allowance. The prospects of supplemental legislation or regulatory processes to address questions that arise because of the Tax Act, or evolving technical interpretations of the tax law, may cause the final impact from the Tax Act to differ from the recorded amounts. The Company continues to appropriately refine such amounts within the measurement period allowed by Staff Accounting Bulletin (“SAB”) No.118, which will be completed no later than the third quarter of fiscal year 2019.

[0001032975-18-000007:notes:134]
The change in the effective income tax rate in the nine months ended December 31, 2017 compared to the same period of the prior fiscal year is primarily due to the recognition of excess tax benefits of $10.8 million after adoption of ASU 2016-09 and income tax benefit from the reversal of uncertain tax positions from the expiration of statutes of limitations are largely offset by income tax provision from the remeasurement of deferred tax assets and liabilities in the third quarter. In the three and nine months ended December 31, 2017, there was a discrete income tax benefit of $6.0 million and $7.9 million, respectively, from the reversal of uncertain tax positions from the expiration of statutes of limitations. In the same periods ended December 31, 2016, the income tax benefit from the reversal of uncertain tax positions from the expiration of statutes of limitations was $9.4 million and $11.1 million, respectively.

[0001032975-18-000007:notes:135]
As of December 31 and March 31, 2017, the total amount of unrecognized tax benefits due to uncertain tax positions was $67.3 million and $63.7 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-18-000007:notes:136]
The Company had $34.4 million in non-current income taxes payable and $0.1 million in current income taxes payable, including interest and penalties, related to its income tax liability for uncertain tax positions as of December 31, 2017, compared to $51.8 million in non-current income taxes payable and $1.5 million in current income taxes payable as of March 31, 2017. The Company applied to a settlement program and paid $1.9 million to the tax authorities in a foreign jurisdiction in the third quarter of fiscal year 2018.

[0001032975-18-000007:notes:137]
The Company recognizes interest and penalties related to unrecognized tax positions in income tax expense. As of December 31 and March 31, 2017, the Company had $2.1 million and $3.0 million, respectively, of accrued interest and penalties related to uncertain tax positions.

[0001032975-18-000007:notes:138]
Although the Company has adequately provided for uncertain tax positions, the provisions on these positions may change as revised estimates are made or the underlying matters are settled or otherwise resolved. During fiscal year 2018, the Company continues to review its tax positions and provide for or reverse unrecognized tax benefits as issues arise. During the next twelve months, it is reasonably possible that the amount of unrecognized tax benefits could increase or decrease significantly due to changes in tax law in various jurisdictions, new tax audits and changes in the U.S. dollar as compared to other currencies. Excluding these factors, uncertain tax positions may decrease by as much as $21.4 million from the lapse of the statutes of limitations in various jurisdictions during the next twelve months.


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0001032975-18-000007:notes:139]
Property, plant and equipment, net by geographic region were as follows (in thousands):

[0001032975-18-000007:notes:140]
|  |  | December 31,2017 |  | March 31,2017 |
| Americas |  | $ | 36,688 |  |  | $ | 37,242 |  |
| EMEA |  | 4,604 |  |  | 4,006 |  |
| Asia Pacific |  | 45,609 |  |  | 44,160 |  |
| Total Property, plant and equipment, net |  | $ | 86,901 |  |  | $ | 85,408 |  |


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001032975-18-000007:notes:141]
Net sales by geographic region (based on the customers’ locations) for the three and nine months ended December 31, 2017 and 2016 were as follows (in thousands):

[0001032975-18-000007:notes:142]
|  |  | Three Months EndedDecember 31, |  | Nine Months Ended December 31, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Americas |  | $ | 380,130 |  |  | $ | 290,724 |  |  | $ | 887,523 |  |  | $ | 753,179 |  |
| EMEA |  | 253,767 |  |  | 233,251 |  |  | 622,681 |  |  | 576,809 |  |
| Asia Pacific |  | 178,124 |  |  | 142,732 |  |  | 464,233 |  |  | 380,887 |  |
| Total net sales |  | $ | 812,021 |  |  | $ | 666,707 |  |  | $ | 1,974,437 |  |  | $ | 1,710,875 |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001032975-18-000007:notes:143]
The accumulated other comprehensive income (loss) was as follows (in thousands):

[0001032975-18-000007:notes:144]
|  |  | Accumulated Other Comprehensive Income (Loss) |
|  |  | CumulativeTranslationAdjustment (1) |  | DefinedBenefitPlan (1) |  | DeferredHedgingLosses |  | Total |
| March 31, 2017 |  | $ | (89,708 | ) |  | $ | (10,480 | ) |  | $ | (518 | ) |  | $ | (100,706 | ) |
| Other comprehensive income (loss) |  | 5,176 |  |  | 1,012 |  |  | (649 | ) |  | 5,539 |  |
| December 31, 2017 |  | $ | (84,532 | ) |  | $ | (9,468 | ) |  | $ | (1,167 | ) |  | $ | (95,167 | ) |

[0001032975-18-000007:notes:145]
(1)        Tax effect was not significant as of December 31 or March 31, 2017.


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001032975-18-000007:notes:146]
Net sales by product categories, excluding intercompany transactions, for the three and nine months ended December 31, 2017 and 2016 were as follows (in thousands):

[0001032975-18-000007:notes:147]
|  |  | Three Months EndedDecember 31, |  | Nine Months Ended December 31, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Pointing Devices |  | $ | 140,983 |  |  | $ | 142,166 |  |  | $ | 386,700 |  |  | $ | 382,249 |  |
| Keyboards & Combos |  | 126,372 |  |  | 125,289 |  |  | 361,685 |  |  | 359,824 |  |
| PC Webcams |  | 27,280 |  |  | 30,503 |  |  | 80,371 |  |  | 80,072 |  |
| Tablet & Other Accessories |  | 26,648 |  |  | 24,852 |  |  | 80,650 |  |  | 59,351 |  |
| Video Collaboration |  | 46,252 |  |  | 35,807 |  |  | 128,008 |  |  | 88,298 |  |
| Mobile Speakers |  | 147,377 |  |  | 106,578 |  |  | 300,843 |  |  | 261,046 |  |
| Audio-PC & Wearables |  | 84,435 |  |  | 67,225 |  |  | 197,082 |  |  | 186,058 |  |
| Gaming |  | 173,802 |  |  | 107,181 |  |  | 365,232 |  |  | 242,874 |  |
| Smart Home |  | 38,692 |  |  | 26,942 |  |  | 73,481 |  |  | 49,916 |  |
| Other (1) |  | 180 |  |  | 164 |  |  | 385 |  |  | 1,187 |  |
| Total net sales |  | $ | 812,021 |  |  | $ | 666,707 |  |  | $ | 1,974,437 |  |  | $ | 1,710,875 |  |

[0001032975-18-000007:notes:148]
[same as prior period, unchanged from 0001032975-17-000053:notes:138]


## us-gaap:SegmentReportingDisclosureTextBlock

[0001032975-18-000007:notes:149]
[same as prior period, unchanged from 0001032975-17-000053:notes:139]

[0001032975-18-000007:notes:150]
[same as prior period, unchanged from 0001032975-17-000053:notes:140]

[0001032975-18-000007:notes:151]
[same as prior period, unchanged from 0001032975-17-000053:notes:141]

[0001032975-18-000007:notes:152]
The United States and Germany each represented more than 10% of the total consolidated net sales for each of the periods presented herein. No other countries represented more than 10% of the Company’s total consolidated net sales for the periods presented herein.

[0001032975-18-000007:notes:153]
Switzerland, the Company’s home domicile, represented 1% and 2% of the Company’s total consolidated net sales for the three and nine months ended December 31, 2017, respectively, and 2% for each of the three and nine months ended December 31, 2016.

[0001032975-18-000007:notes:154]
Two customer groups of the Company each represented more than 10% of the total consolidated net sales for each of the periods presented herein.

[0001032975-18-000007:notes:155]
Property, plant and equipment, net in the United States and China were $36.6 million and $37.8 million, respectively, as of December 31, 2017, and $37.1 million and $37.2 million, respectively, as of March 31, 2017. No other countries represented more than 10% of the Company’s total consolidated property, plant and equipment, net as of December 31, 2017 or March 31, 2017. Property, plant and equipment, net in Switzerland, the Company’s home domicile, were $2.0 million and $2.1 million as of December 31, 2017 and March 31, 2017, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001032975-18-000007:notes:156]
[same as prior period, unchanged from 0001032975-17-000053:notes:146]

[0001032975-18-000007:notes:157]
[same as prior period, unchanged from 0001032975-17-000053:notes:147]

[0001032975-18-000007:notes:158]
[same as prior period, unchanged from 0001032975-17-000053:notes:148]

[0001032975-18-000007:notes:159]
In March 2017, the Company's Board of Directors approved the 2017 share buyback program, which authorizes the Company to use up to $250.0 million to purchase up to 17.3 million shares of its own shares following the expiration date of the 2014 share buyback program. The Company's share buyback program is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Purchases may be started or stopped at any time without prior notice depending on market conditions and other factors.

[0001032975-18-000007:notes:160]
During the nine months ended December 31, 2017 and 2016, 0.6 million and 3.3 million shares, respectively, were repurchased for $20.4 million and $63.8 million, respectively.

[0001032975-18-000007:notes:161]
[same as prior period, unchanged from 0001032975-17-000053:notes:151]

[0001032975-18-000007:notes:162]
During the nine months ended December 31, 2017, the Company declared and paid cash dividends of CHF 0.61 (USD equivalent of $0.63) per common share, totaling $104.2 million on the Company's outstanding common stock. During the nine months ended December 31, 2016, the Company declared and paid cash dividends of CHF 0.56 (USD equivalent of $0.57) per common share, totaling $93.1 million on the Company's outstanding common stock.

[0001032975-18-000007:notes:163]
[same as prior period, unchanged from 0001032975-17-000053:notes:153]

[0001032975-18-000007:notes:164]
Accumulated Other Comprehensive Income (Loss)


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001032975-18-000007:notes:165]
[same as prior period, unchanged from 0001032975-17-000053:notes:155]
