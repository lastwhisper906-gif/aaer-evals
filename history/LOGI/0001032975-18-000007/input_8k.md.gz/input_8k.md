# LOGI 8-K — 0001032975-18-000005 filed 2018-01-23

## item codes, every 8-K on or before 2018-01-25

- 2018-01-23 0001032975-18-000005 — 2.02, 9.01
- 2017-10-24 0001032975-17-000043 — 2.02, 9.01
- 2017-09-18 0001032975-17-000040 — 5.07, 8.01
- 2017-07-25 0001032975-17-000028 — 2.02, 9.01
- 2017-07-12 0001032975-17-000022 — 1.01
- 2017-04-26 0001032975-17-000012 — 2.02, 9.01
- 2017-01-25 0001032975-17-000002 — 2.02, 9.01
- 2016-10-26 0001032975-16-000103 — 2.02, 9.01
- 2016-09-13 0001032975-16-000101 — 5.07, 8.01
- 2016-07-28 0001032975-16-000092 — 2.02, 9.01
- 2016-06-30 0001032975-16-000087 — 5.02
- 2016-04-28 0001032975-16-000077 — 2.02, 9.01
- 2016-04-14 0001032975-16-000073 — 1.01, 7.01, 9.01
- 2016-01-21 0001032975-16-000064 — 2.02, 9.01
- 2016-01-04 0001032975-16-000061 — 1.01, 2.01, 9.01
- 2015-12-23 0001032975-15-000059 — 5.02
- 2015-10-22 0001032975-15-000047 — 2.02, 9.01
- 2015-09-11 0001032975-15-000044 — 5.07, 8.01
- 2015-07-24 0001032975-15-000034 — 2.05 — amendment of 0001032975-15-000030
- 2015-07-23 0001032975-15-000030 — 2.02, 9.01
- 2015-06-25 0001032975-15-000025 — 5.02
- 2015-05-14 0001032975-15-000011 — 8.01, 9.01
- 2015-04-23 0001032975-15-000008 — 2.02, 2.05
- 2015-01-22 0001628280-15-000191 — 2.02, 8.01
- 2014-12-23 0001193125-14-450908 — 5.02, 5.07, 8.01
- 2014-11-25 0001193125-14-425233 — 3.01
- 2014-11-13 0001193125-14-411303 — 4.01, 9.01
- 2014-10-23 0001104659-14-073164 — 2.02, 9.01
- 2014-09-04 0001193125-14-331214 — 4.02, 9.01
- 2014-08-18 0001193125-14-313346 — 3.01, 9.01
- 2014-07-24 0001104659-14-053065 — 2.02, 9.01
- 2014-06-05 0001193125-14-226177 — 3.01, 9.01
- 2014-05-22 0001193125-14-208777 — 8.01, 9.01
- 2014-04-24 0001104659-14-029650 — 2.02, 9.01
- 2014-01-23 0001104659-14-003619 — 2.02, 9.01
- 2013-10-24 0001104659-13-077404 — 2.02, 9.01
- 2013-09-09 0001193125-13-361441 — 5.02, 5.07, 8.01, 9.01
- 2013-09-06 0001193125-13-359930 — 5.02, 9.01
- 2013-08-02 0001193125-13-317343 — 5.02
- 2013-07-25 0001104659-13-056372 — 2.02, 9.01
- 2013-06-28 0001193125-13-277394 — 5.02, 9.01
- 2013-06-20 0001193125-13-265914 — 8.01, 9.01
- 2013-04-25 0001104659-13-032570 — 2.02, 9.01
- 2013-04-17 0001193125-13-158923 — 5.02, 9.01
- 2013-03-01 0001193125-13-085804 — 2.05
- 2013-01-24 0001104659-13-004214 — 2.02, 9.01
- 2013-01-02 0001193125-13-000058 — 5.02
- 2012-10-25 0001104659-12-070966 — 2.02, 9.01
- 2012-09-11 0001193125-12-388070 — 5.02, 5.07, 8.01, 9.01
- 2012-08-22 0001193125-12-364167 — 5.02, 8.01, 9.01
- 2012-07-26 0001104659-12-051084 — 2.02, 9.01
- 2012-06-08 0001193125-12-264132 — 2.05, 9.01 — amendment, the index does not say of what
- 2012-04-26 0001193125-12-183657 — 5.02, 9.01
- 2012-04-26 0001104659-12-028470 — 2.02, 2.05, 9.01
- 2012-03-15 0001193125-12-115954 — 5.02, 9.01
- 2012-01-26 0001104659-12-004014 — 2.02, 9.01
- 2012-01-04 0001193125-12-002212 — 1.01, 2.03, 9.01
- 2011-10-27 0001104659-11-058150 — 2.02, 9.01
- 2011-09-12 0001193125-11-245931 — 5.07
- 2011-07-28 0001193125-11-200929 — 5.02, 9.01
- 2011-07-28 0001193125-11-199704 — 2.02, 9.01
- 2011-04-28 0001193125-11-112669 — 2.02, 9.01
- 2011-03-24 0001193125-11-076483 — 5.02, 9.01
- 2011-01-27 0001032975-11-000003 — 9.01
- 2010-10-28 0001032975-10-000032 — 9.01
- 2010-09-13 0001032975-10-000022 — 5.07
- 2010-07-29 0001032975-10-000010 — 2.02, 9.01
- 2010-06-10 0001193125-10-136877 — 5.02, 9.01
- 2010-05-03 0001193125-10-104337 — 5.02
- 2010-04-29 0001032975-10-000008 — 2.02, 9.01
- 2010-02-19 0001032975-10-000006 — 9.01 — amendment of 0001193125-09-252416
- 2010-01-21 0001032975-10-000002 — 2.02, 9.01
- 2009-12-14 0001193125-09-252416 — 2.01, 9.01
- 2009-11-17 0001032975-09-000023 — 1.01
- 2009-10-22 0001032975-09-000018 — 9.01
- 2009-09-22 0001193125-09-195545 — 5.02, 9.01
- 2009-09-03 0001032975-09-000013 — 8.01
- 2009-07-23 0001140361-09-016802 — 2.02, 9.01
- 2009-06-01 0001193125-09-122550 — 5.02
- 2009-04-23 0001193125-09-085054 — 2.02, 9.01
- 2009-04-02 0001193125-09-071272 — 5.02, 9.01
- 2009-01-20 0001193125-09-008454 — 2.05 — amendment of 0001193125-09-002609
- 2009-01-20 0001193125-09-007902 — 2.02, 9.01
- 2009-01-07 0001193125-09-002609 — 2.05, 9.01
- 2009-01-07 0001193125-09-002370 — 5.02, 9.01
- 2008-12-09 0001193125-08-250543 — 5.02, 9.01
- 2008-10-21 0001193125-08-213212 — 2.02, 9.01
- 2008-07-22 0001193125-08-154721 — 2.02, 9.01
- 2008-06-24 0001193125-08-139163 — 5.03, 9.01
- 2008-05-13 0001193125-08-113263 — 5.02, 9.01
- 2008-04-22 0001193125-08-086176 — 2.02, 9.01

## late-filing notifications on or before 2018-01-25

- 2015-06-02 0001032975-15-000020 — NT 10-K, for the period ended 2015-03-31
- 2014-11-06 0001193125-14-401306 — NT 10-Q, for the period ended 2014-09-30
- 2014-07-24 0001193125-14-277575 — NT 10-Q, for the period ended 2014-06-30
- 2014-05-22 0001193125-14-208712 — NT 10-K, for the period ended 2014-03-31
- 2009-08-06 0001032975-09-000006 — NT 10-Q, for the period ended 2009-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001032975-18-000005:8k_2_02:1]
EX-99.1
2
exhibit991q3fy18.htm
EXHIBIT 99.1

[0001032975-18-000005:8k_2_02:2]
Exhibit

[0001032975-18-000005:8k_2_02:3]
Exhibit 99.1

[0001032975-18-000005:8k_2_02:4]
Editorial Contacts:

[0001032975-18-000005:8k_2_02:5]
Ben Lu, Vice President, Investor Relations - USA (510) 713-5568

[0001032975-18-000005:8k_2_02:6]
Krista Todd, Vice President, Communications - USA (510) 713-5834

[0001032975-18-000005:8k_2_02:7]
Ben Starkie, Corporate Communications - Europe +41 (0) 79-292-3499

[0001032975-18-000005:8k_2_02:8]
Logitech Delivers Record Sales, Up 22%

[0001032975-18-000005:8k_2_02:9]
Company Raises Full Year Outlook for Sales and Profits

[0001032975-18-000005:8k_2_02:10]
NEWARK, Calif. - January 22, 2018 and LAUSANNE, Switzerland, January 23, 2018 -  Logitech International (SIX: LOGN) (Nasdaq: LOGI) today announced financial results for the third quarter of Fiscal Year 2018.

[0001032975-18-000005:8k_2_02:11]
| • | Q3 sales were an all-time record $812 million, up 22 percent in US dollars and 18 percent in constant currency, compared to Q3 of the prior year. |

[0001032975-18-000005:8k_2_02:12]
| • | Q3 GAAP operating income amounted to $100 million, compared to $96 million in the same quarter a year ago. Q3 GAAP earnings per share (EPS) amounted to $0.48, compared to $0.59 in the same quarter a year ago. GAAP profitability was impacted by a one-time $16 million net tax expense following the reduction in the U.S. federal income tax rate and other reforms. |

[0001032975-18-000005:8k_2_02:13]
| • | Q3 non-GAAP operating income grew 18 percent to $117 million, compared to $99 million in the same quarter a year ago. Q3 non-GAAP EPS grew 16 percent to $0.65, compared to $0.56 in the same quarter a year ago. |

[0001032975-18-000005:8k_2_02:14]
| • | Cash flow from operations grew 27 percent to $189 million, the highest quarterly level ever. |

[0001032975-18-000005:8k_2_02:15]
“This holiday quarter, we’ve delivered our highest quarterly sales ever and highest sales growth in seven years,” said Bracken Darrell, Logitech president and chief executive officer. “Video Collaboration, Gaming and Mobile Speakers all grew 25% or more, and we gained share broadly across our product categories. Our ASTRO acquisition also performed better than expected. We are raising our Fiscal Year 2018 outlook.”

[0001032975-18-000005:8k_2_02:16]
Outlook

[0001032975-18-000005:8k_2_02:17]
Logitech raised its Fiscal Year 2018 outlook to 12 to 14 percent sales growth in constant currency, up from its previous range of 10 to 12 percent sales growth in constant currency. The Company also increased its non-GAAP operating income outlook for Fiscal Year 2018 to a range of $270 million to $280 million, up from its prior range of $260 million to $270 million.

[0001032975-18-000005:8k_2_02:18]
Prepared Remarks Available Online

[0001032975-18-000005:8k_2_02:19]
Logitech has made its prepared written remarks for the financial results teleconference available online on the Logitech corporate website at http://ir.logitech.com.

[0001032975-18-000005:8k_2_02:20]
Financial Results Teleconference and Webcast

[0001032975-18-000005:8k_2_02:21]
Logitech will hold a financial results teleconference to discuss the results for Q3 FY 2018 on

[0001032975-18-000005:8k_2_02:22]
Tuesday, January 23, 2018 at 8:30 a.m. Eastern Standard Time and 2:30 p.m. Central European Time. A live webcast of the call will be available on the Logitech corporate website at http://ir.logitech.com.

[0001032975-18-000005:8k_2_02:23]
Use of Non-GAAP Financial Information and Constant Currency

[0001032975-18-000005:8k_2_02:24]
To facilitate comparisons to Logitech’s historical results, Logitech has included non-GAAP adjusted measures, which exclude share-based compensation expense, amortization of intangible assets, purchase accounting effect on inventory, acquisition-related costs, change in fair value of contingent consideration for business acquisition, restructuring charges (credits), gain (loss) on investments in privately held companies, investigation and related expenses, non-GAAP income tax adjustment, and other items detailed under “Supplemental Financial Information” after the tables below. Logitech also presents percentage sales growth in constant currency to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales. Logitech believes this information, used together with the GAAP financial information, will help investors to evaluate its current period performance and trends in its business. With respect to the Company’s outlook for non-GAAP operating income, most of these excluded amounts pertain to events that have not yet occurred and are not currently possible to estimate with a reasonable degree of accuracy. Therefore, no reconciliation to the GAAP amounts has been provided for Fiscal Year 2018.

[0001032975-18-000005:8k_2_02:25]
About Logitech

[0001032975-18-000005:8k_2_02:26]
Logitech designs products that have an everyday place in people's lives, connecting them to the digital experiences they care about. More than 35 years ago, Logitech started connecting people through computers, and now it’s a multi-brand company designing products that bring people together through music, gaming, video and computing. Brands of Logitech include Ultimate Ears, Jaybird, Logitech G and ASTRO Gaming. Founded in 1981, and headquartered in Lausanne, Switzerland, Logitech International is a Swiss public company listed on the SIX Swiss Exchange (LOGN) and on the Nasdaq Global Select Market (LOGI). Find Logitech at www.logitech.com, the company blog or @Logitech.

[0001032975-18-000005:8k_2_02:27]
# # #

[0001032975-18-000005:8k_2_02:28]
to lower our costs and improve our operating leverage; if there is a deterioration of business and economic conditions in one or more of our sales regions or product categories, or significant fluctuations in exchange rates. A detailed discussion of these and other risks and uncertainties that could cause actual results and events to differ materially from such forward-looking statements is included in Logitech’s periodic filings with the Securities and Exchange Commission, including our Quarterly Report on Form 10-Q for the fiscal quarter ended September 30, 2017 and our Annual Report on Form 10-K for the fiscal year ended March 31, 2017, available at www.sec.gov, under the caption Risk Factors and elsewhere. Logitech does not undertake any obligation to update any forward-looking statements to reflect new information or events or circumstances occurring after the date of this press release.

[0001032975-18-000005:8k_2_02:29]
Note that unless noted otherwise, comparisons are year over year.

[0001032975-18-000005:8k_2_02:30]
Logitech and other Logitech marks are trademarks or registered trademarks of Logitech Europe S.A and/or its affiliates in the U.S. and other countries.  All other trademarks are the property of their respective owners. For more information about Logitech and its products, visit the company’s website at www.logitech.com.

[0001032975-18-000005:8k_2_02:31]
(LOGIIR)

[0001032975-18-000005:8k_2_02:32]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS * |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | December 31, |  | December 31, |
| GAAP CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS (A) |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Net sales |  | $ | 812,021 |  |  | $ | 666,707 |  |  | $ | 1,974,437 |  |  | $ | 1,710,875 |  |
| Cost of goods sold |  | 533,631 |  |  | 418,015 |  |  | 1,271,127 |  |  | 1,083,908 |  |
| Amortization of intangible assets and purchase accounting effect on inventory |  | 2,789 |  |  | 1,929 |  |  | 6,304 |  |  | 4,705 |  |
| Gross profit |  | 275,601 |  |  | 246,763 |  |  | 697,006 |  |  | 622,262 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Marketing and selling |  | 116,153 |  |  | 102,036 |  |  | 325,917 |  |  | 279,700 |  |
| Research and development |  | 34,398 |  |  | 32,284 |  |  | 106,144 |  |  | 96,867 |  |
| General and administrative |  | 22,291 |  |  | 24,598 |  |  | 72,850 |  |  | 75,543 |  |
| Amortization of intangible assets and acquisition-related costs |  | 2,496 |  |  | 1,494 |  |  | 6,377 |  |  | 4,535 |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | (9,925 | ) |  | (4,908 | ) |  | (9,925 | ) |
| Total operating expenses |  | 175,338 |  |  | 150,487 |  |  | 506,380 |  |  | 446,720 |  |
| Operating income |  | 100,263 |  |  | 96,276 |  |  | 190,626 |  |  | 175,542 |  |
| Interest income |  | 874 |  |  | 202 |  |  | 3,097 |  |  | 263 |  |
| Other income (expense), net |  | (324 | ) |  | 2,634 |  |  | (894 | ) |  | 943 |  |
| Income before income taxes |  | 100,813 |  |  | 99,112 |  |  | 192,829 |  |  | 176,748 |  |
| Provision for income taxes |  | 20,040 |  |  | 1,647 |  |  | 18,691 |  |  | 10,297 |  |
| Net income |  | $ | 80,773 |  |  | $ | 97,465 |  |  | $ | 174,138 |  |  | $ | 166,451 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.49 |  |  | $ | 0.60 |  |  | $ | 1.06 |  |  | $ | 1.03 |  |
| Diluted |  | $ | 0.48 |  |  | $ | 0.59 |  |  | $ | 1.03 |  |  | $ | 1.01 |  |
| Weighted average shares used to compute net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | 164,248 |  |  | 161,977 |  |  | 163,924 |  |  | 162,070 |  |
| Diluted |  | 169,079 |  |  | 165,901 |  |  | 168,832 |  |  | 165,211 |  |
| Cash dividend per share |  | $ | — |  |  | $ | — |  |  | $ | 0.63 |  |  | $ | 0.57 |  |

[0001032975-18-000005:8k_2_02:33]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |
| PRELIMINARY RESULTS * |
| (In thousands) - unaudited |  |  |  |  |
|  |  | December 31, |  | March 31, |
| CONDENSED CONSOLIDATED BALANCE SHEETS (A) |  | 2017 |  | 2017 |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 564,888 |  |  | $ | 547,533 |  |
| Accounts receivable, net |  | 351,753 |  |  | 185,179 |  |
| Inventories |  | 278,979 |  |  | 253,401 |  |
| Other current assets |  | 57,530 |  |  | 41,732 |  |
| Total current assets |  | 1,253,150 |  |  | 1,027,845 |  |
| Non-current assets: |  |  |  |  |  |  |
| Property, plant and equipment, net |  | 86,901 |  |  | 85,408 |  |
| Goodwill |  | 275,563 |  |  | 249,741 |  |
| Other intangible assets, net |  | 92,371 |  |  | 47,564 |  |
| Other assets |  | 122,839 |  |  | 88,119 |  |
| Total assets |  | $ | 1,830,824 |  |  | $ | 1,498,677 |  |
| Current liabilities: |  |  |  |  |  |  |
| Accounts payable |  | $ | 429,119 |  |  | $ | 274,805 |  |
| Accrued and other current liabilities |  | 278,055 |  |  | 232,273 |  |
| Total current liabilities |  | 707,174 |  |  | 507,078 |  |
| Non-current liabilities: |  |  |  |  |  |  |
| Income taxes payable |  | 34,410 |  |  | 51,797 |  |
| Other non-current liabilities |  | 82,004 |  |  | 83,691 |  |
| Total liabilities |  | 823,588 |  |  | 642,566 |  |
| Shareholders’ equity: |  |  |  |  |
| Registered shares, CHF 0.25 par value: |  | 30,148 |  |  | 30,148 |  |
| Issued and authorized shares — 173,106 at December 31 and March 31, 2017 |  |  |  |  |
| Conditionally authorized shares — 50,000 at December 31 and March 31, 2017 |  |  |  |  |
| Additional paid-in capital |  | 38,902 |  |  | 26,596 |  |
| Shares in treasury, at cost — 8,899 at December 31, 2017 and 10,727 at March 31, 2017 |  | (164,559 | ) |  | (174,037 | ) |
| Retained earnings |  | 1,197,912 |  |  | 1,074,110 |  |
| Accumulated other comprehensive loss |  | (95,167 | ) |  | (100,706 | ) |
| Total shareholders’ equity |  | 1,007,236 |  |  | 856,111 |  |
| Total liabilities and shareholders’ equity |  | $ | 1,830,824 |  |  | $ | 1,498,677 |  |

[0001032975-18-000005:8k_2_02:34]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS * |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | December 31, |  | December 31, |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (A) |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 80,773 |  |  | $ | 97,465 |  |  | $ | 174,138 |  |  | $ | 166,451 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  | 10,850 |  |  | 8,863 |  |  | 30,218 |  |  | 32,479 |  |
| Amortization of intangible assets |  | 4,415 |  |  | 2,751 |  |  | 10,653 |  |  | 6,618 |  |
| Gain on investments in privately held companies |  | (114 | ) |  | (375 | ) |  | (550 | ) |  | (547 | ) |
| Loss (gain) on disposal of property, plant and equipment |  | (5 | ) |  | — |  |  | 7 |  |  | — |  |
| Share-based compensation expense |  | 11,556 |  |  | 9,387 |  |  | 33,239 |  |  | 26,354 |  |
| Deferred income taxes |  | 18,661 |  |  | (88 | ) |  | 6,728 |  |  | (473 | ) |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | (9,925 | ) |  | (4,908 | ) |  | (9,925 | ) |
| Changes in assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | (72,310 | ) |  | (42,413 | ) |  | (164,028 | ) |  | (139,414 | ) |
| Inventories |  | 52,386 |  |  | 13,123 |  |  | (5,692 | ) |  | (15,194 | ) |
| Other assets |  | (10,463 | ) |  | (1,608 | ) |  | (18,953 | ) |  | (6,346 | ) |
| Accounts payable |  | 41,575 |  |  | 25,419 |  |  | 151,711 |  |  | 109,095 |  |
| Accrued and other liabilities |  | 51,260 |  |  | 46,162 |  |  | 43,521 |  |  | 71,549 |  |
| Net cash provided by operating activities |  | 188,584 |  |  | 148,761 |  |  | 256,084 |  |  | 240,647 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  | (10,405 | ) |  | (8,614 | ) |  | (27,593 | ) |  | (23,372 | ) |
| Investment in privately held companies |  | (360 | ) |  | (160 | ) |  | (880 | ) |  | (640 | ) |
| Acquisitions, net of cash acquired |  | (3,323 | ) |  | — |  |  | (88,323 | ) |  | (66,987 | ) |
| Proceeds from return of investment in privately held companies |  | — |  |  | — |  |  | 237 |  |  | — |  |
| Changes in restricted cash |  | — |  |  | — |  |  | — |  |  | 715 |  |
| Purchases of short-term investments |  | — |  |  | — |  |  | (6,789 | ) |  | — |  |
| Sales of short-term investments |  | 6,789 |  |  | — |  |  | 6,789 |  |  | — |  |
| Purchases of trading investments |  | (1,843 | ) |  | (597 | ) |  | (2,842 | ) |  | (5,868 | ) |
| Proceeds from sales of trading investments |  | 2,152 |  |  | 616 |  |  | 3,209 |  |  | 5,912 |  |
| Net cash used in investing activities |  | (6,990 | ) |  | (8,755 | ) |  | (116,192 | ) |  | (90,240 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |
| Payment of cash dividends |  | — |  |  | — |  |  | (104,248 | ) |  | (93,093 | ) |
| Payment of contingent consideration for business acquisition |  | (5,000 | ) |  | — |  |  | (5,000 | ) |  | — |  |
| Purchases of registered shares |  | (9,726 | ) |  | (20,870 | ) |  | (20,408 | ) |  | (63,764 | ) |
| Proceeds from exercises of stock options and purchase rights |  | 947 |  |  | 5,871 |  |  | 30,947 |  |  | 20,355 |  |
| Tax withholdings related to net share settlements of restricted stock units |  | (1,799 | ) |  | (2,007 | ) |  | (25,505 | ) |  | (13,054 | ) |
| Net cash used in financing activities |  | (15,578 | ) |  | (17,006 | ) |  | (124,214 | ) |  | (149,556 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  | 24 |  |  | (4,623 | ) |  | 1,677 |  |  | (6,468 | ) |
| Net increase (decrease) in cash and cash equivalents |  | 166,040 |  |  | 118,377 |  |  | 17,355 |  |  | (5,617 | ) |
| Cash and cash equivalents, beginning of the period |  | 398,848 |  |  | 395,201 |  |  | 547,533 |  |  | 519,195 |  |
| Cash and cash equivalents, end of the period |  | $ | 564,888 |  |  | $ | 513,578 |  |  | $ | 564,888 |  |  | $ | 513,578 |  |

[0001032975-18-000005:8k_2_02:35]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS * |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |  |  |
| NET SALES |  | Three Months Ended |  | Nine Months Ended |
|  |  | December 31, |  | December 31, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2017 |  | 2016 |  | Change |  | 2017 |  | 2016 |  | Change |
| Net sales by product category: |  |  |  |  |  |  |  |  |  |  |  |  |
| Pointing Devices |  | $ | 140,983 |  |  | $ | 142,166 |  |  | (1 | )% |  | $ | 386,700 |  |  | $ | 382,249 |  |  | 1 | % |
| Keyboards & Combos |  | 126,372 |  |  | 125,289 |  |  | 1 |  |  | 361,685 |  |  | 359,824 |  |  | 1 |  |
| PC Webcams |  | 27,280 |  |  | 30,503 |  |  | (11 | ) |  | 80,371 |  |  | 80,072 |  |  | — |  |
| Tablet & Other Accessories |  | 26,648 |  |  | 24,852 |  |  | 7 |  |  | 80,650 |  |  | 59,351 |  |  | 36 |  |
| Video Collaboration |  | 46,252 |  |  | 35,807 |  |  | 29 |  |  | 128,008 |  |  | 88,298 |  |  | 45 |  |
| Mobile Speakers |  | 147,377 |  |  | 106,578 |  |  | 38 |  |  | 300,843 |  |  | 261,046 |  |  | 15 |  |
| Audio-PC & Wearables |  | 84,435 |  |  | 67,225 |  |  | 26 |  |  | 197,082 |  |  | 186,058 |  |  | 6 |  |
| Gaming |  | 173,802 |  |  | 107,181 |  |  | 62 |  |  | 365,232 |  |  | 242,874 |  |  | 50 |  |
| Smart Home |  | 38,692 |  |  | 26,942 |  |  | 44 |  |  | 73,481 |  |  | 49,916 |  |  | 47 |  |
| Other (1) |  | 180 |  |  | 164 |  |  | 10 |  |  | 385 |  |  | 1,187 |  |  | (68 | ) |
| Total net sales |  | $ | 812,021 |  |  | $ | 666,707 |  |  | 22 |  |  | $ | 1,974,437 |  |  | $ | 1,710,875 |  |  | 15 |  |

[0001032975-18-000005:8k_2_02:36]
(1) Other category includes products that we currently intend to transition out of, or have already transitioned out of, because they are no longer strategic to our business.

[0001032975-18-000005:8k_2_02:37]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS * |
| (In thousands, except per share amounts) - Unaudited |  |  |  |  |  |  |  |  |
| GAAP TO NON-GAAP RECONCILIATION (A)(B) |  | Three Months Ended |  | Nine Months Ended |
|  |  | December 31, |  | December 31, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Gross profit - GAAP |  | $ | 275,601 |  |  | $ | 246,763 |  |  | $ | 697,006 |  |  | $ | 622,262 |  |
| Share-based compensation expense |  | 960 |  |  | 617 |  |  | 2,762 |  |  | 1,930 |  |
| Amortization of intangible assets and purchase accounting effect on inventory |  | 2,789 |  |  | 1,929 |  |  | 6,304 |  |  | 4,705 |  |
| Gross profit - Non-GAAP |  | $ | 279,350 |  |  | $ | 249,309 |  |  | $ | 706,072 |  |  | $ | 628,897 |  |
| Gross margin - GAAP |  | 33.9 | % |  | 37.0 | % |  | 35.3 | % |  | 36.4 | % |
| Gross margin - Non-GAAP |  | 34.4 | % |  | 37.4 | % |  | 35.8 | % |  | 36.8 | % |
| Operating expenses - GAAP |  | $ | 175,338 |  |  | $ | 150,487 |  |  | $ | 506,380 |  |  | $ | 446,720 |  |
| Less: Share-based compensation expense |  | 10,596 |  |  | 8,770 |  |  | 30,477 |  |  | 24,424 |  |
| Less: Amortization of intangible assets and acquisition-related costs |  | 2,496 |  |  | 1,494 |  |  | 6,377 |  |  | 4,535 |  |
| Less: Change in fair value of contingent consideration for business acquisition |  | — |  |  | (9,925 | ) |  | (4,908 | ) |  | (9,925 | ) |
| Less: Restructuring credits, net |  | — |  |  | (33 | ) |  | (116 | ) |  | (44 | ) |
| Less: Investigation and related expenses |  | — |  |  | — |  |  | — |  |  | 612 |  |
| Operating expenses - Non-GAAP |  | $ | 162,246 |  |  | $ | 150,181 |  |  | $ | 474,550 |  |  | $ | 427,118 |  |
| % of net sales - GAAP |  | 21.6 | % |  | 22.6 | % |  | 25.6 | % |  | 26.1 | % |
| % of net sales - Non - GAAP |  | 20.0 | % |  | 22.5 | % |  | 24.0 | % |  | 25.0 | % |
| Operating income - GAAP |  | $ | 100,263 |  |  | $ | 96,276 |  |  | $ | 190,626 |  |  | $ | 175,542 |  |
| Share-based compensation expense |  | 11,556 |  |  | 9,387 |  |  | 33,239 |  |  | 26,354 |  |
| Amortization of intangible assets |  | 4,415 |  |  | 2,751 |  |  | 10,653 |  |  | 6,618 |  |
| Purchase accounting effect on inventory |  | 500 |  |  | 457 |  |  | 614 |  |  | 1,160 |  |
| Acquisition-related costs |  | 370 |  |  | 215 |  |  | 1,412 |  |  | 1,462 |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | (9,925 | ) |  | (4,908 | ) |  | (9,925 | ) |
| Restructuring credits, net |  | — |  |  | (33 | ) |  | (116 | ) |  | (44 | ) |
| Investigation and related expenses |  | — |  |  | — |  |  | — |  |  | 612 |  |
| Operating income - Non - GAAP |  | $ | 117,104 |  |  | $ | 99,128 |  |  | $ | 231,520 |  |  | $ | 201,779 |  |
| % of net sales - GAAP |  | 12.3 | % |  | 14.4 | % |  | 9.7 | % |  | 10.3 | % |
| % of net sales - Non - GAAP |  | 14.4 | % |  | 14.9 | % |  | 11.7 | % |  | 11.8 | % |
| Net income - GAAP |  | $ | 80,773 |  |  | $ | 97,465 |  |  | $ | 174,138 |  |  | $ | 166,451 |  |
| Share-based compensation expense |  | 11,556 |  |  | 9,387 |  |  | 33,239 |  |  | 26,354 |  |
| Amortization of intangible assets |  | 4,415 |  |  | 2,751 |  |  | 10,653 |  |  | 6,618 |  |
| Purchase accounting effect on inventory |  | 500 |  |  | 457 |  |  | 614 |  |  | 1,160 |  |
| Acquisition-related costs |  | 370 |  |  | 215 |  |  | 1,412 |  |  | 1,462 |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | (9,925 | ) |  | (4,908 | ) |  | (9,925 | ) |
| Restructuring credits, net |  | — |  |  | (33 | ) |  | (116 | ) |  | (44 | ) |
| Investigation and related expenses |  | — |  |  | — |  |  | — |  |  | 612 |  |
| Gain on investments in privately held companies |  | (114 | ) |  | (375 | ) |  | (550 | ) |  | (547 | ) |
| Non-GAAP income tax adjustment |  | 13,015 |  |  | (7,595 | ) |  | 2,033 |  |  | (8,649 | ) |
| Net income - Non - GAAP |  | $ | 110,515 |  |  | $ | 92,347 |  |  | $ | 216,515 |  |  | $ | 183,492 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  | $ | 0.48 |  |  | $ | 0.59 |  |  | $ | 1.03 |  |  | $ | 1.01 |  |
| Diluted - Non - GAAP |  | $ | 0.65 |  |  | $ | 0.56 |  |  | $ | 1.28 |  |  | $ | 1.11 |  |
| Shares used to compute net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP and Non - GAAP |  | 169,079 |  |  | 165,901 |  |  | 168,832 |  |  | 165,211 |  |

[0001032975-18-000005:8k_2_02:38]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS * |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
| SHARE-BASED COMPENSATION EXPENSE |  | Three Months Ended |  | Nine Months Ended |
|  |  | December 31, |  | December 31, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Share-based Compensation Expense |  |  |  |  |  |  |  |  |
| Cost of goods sold |  | $ | 960 |  |  | $ | 617 |  |  | $ | 2,762 |  |  | $ | 1,930 |  |
| Marketing and selling |  | 4,624 |  |  | 4,006 |  |  | 13,348 |  |  | 10,687 |  |
| Research and development |  | 1,621 |  |  | 1,176 |  |  | 4,797 |  |  | 3,007 |  |
| General and administrative |  | 4,351 |  |  | 3,588 |  |  | 12,332 |  |  | 10,730 |  |
| Total share-based compensation expense |  | 11,556 |  |  | 9,387 |  |  | 33,239 |  |  | 26,354 |  |
| Income tax benefit (provision) |  | 3,038 |  |  | (2,391 | ) |  | (11,921 | ) |  | (6,092 | ) |
| Total share-based compensation expense, net of income tax |  | $ | 14,594 |  |  | $ | 6,996 |  |  | $ | 21,318 |  |  | $ | 20,262 |  |

[0001032975-18-000005:8k_2_02:39]
*  Note: These preliminary results for the three and nine months ended December 31, 2017 are subject to adjustments, including subsequent events that may occur through the date of filing our Quarterly Report on Form 10-Q.

[0001032975-18-000005:8k_2_02:40]
(A) Preliminary valuation from the business acquisition

[0001032975-18-000005:8k_2_02:41]
The preliminary fair value of assets acquired and liabilities assumed from the business acquisition during the current period is included in the tables. The fair value of identifiable intangible assets acquired was based on estimates and assumptions made by us at the time of the acquisition. As additional information becomes available, such as finalization of purchase price adjustment and the finalization of the estimated fair value of the assets acquired and liabilities assumed, we may revise our preliminary or interim estimated fair value of the assets acquired and liabilities assumed during the remainder of the measurement periods (which will not exceed 12 months from the acquisition dates).

[0001032975-18-000005:8k_2_02:42]
(B) Non-GAAP Financial Measures

[0001032975-18-000005:8k_2_02:43]
To supplement our condensed consolidated financial results prepared in accordance with GAAP, we use a number of financial measures, both GAAP and non-GAAP, in analyzing and assessing our overall business performance, for making operating decisions and for forecasting and planning future periods. We consider the use of non-GAAP financial measures helpful in assessing our current financial performance, ongoing operations and prospects for the future as well as understanding financial and business trends relating to our financial condition and results of operations.

[0001032975-18-000005:8k_2_02:44]
While we use non-GAAP financial measures as a tool to enhance our understanding of certain aspects of our financial performance and to provide incremental insight into the underlying factors and trends affecting both our performance and our cash-generating potential, we do not consider these measures to be a substitute for, or superior to, the information provided by GAAP financial measures. Consistent with this approach, we believe that disclosing non-GAAP financial measures to the readers of our financial statements provides useful supplemental data that, while not a substitute for GAAP financial measures, can offer insight in the review of our financial and operational performance and enables investors to more fully understand trends in our current and future performance. In assessing our business during the quarter ended December 31, 2017, we excluded items in the following general categories, each of which are described below:

[0001032975-18-000005:8k_2_02:45]
Share-based compensation expenses. We believe that providing non-GAAP measures excluding share-based compensation expense, in addition to the GAAP measures, allows for a more transparent comparison of our financial results from period to period. We prepare and maintain our budgets and forecasts for future periods on a basis consistent with this non-GAAP financial measure. Further, companies use a variety of types of equity awards as well as a variety of methodologies, assumptions and estimates to determine share-based compensation expense. We believe that excluding share-based compensation expense enhances our ability and the ability of investors to understand the impact of non-cash share-based compensation on our operating results and to compare our results against the results of other companies.

[0001032975-18-000005:8k_2_02:46]
Amortization of intangible assets. We incur intangible asset amortization expense, primarily in connection with our acquisitions of various businesses and technologies. The amortization of purchased intangibles varies depending on the level of acquisition activity. We exclude these various charges in budgeting, planning and forecasting future periods

[0001032975-18-000005:8k_2_02:47]
and we believe that providing the non-GAAP measures excluding these various non-cash charges, as well as the GAAP measures, provides additional insight when comparing our gross profit,  operating expenses, and financial results from period to period.

[0001032975-18-000005:8k_2_02:48]
Purchase accounting effect on inventory. Business combination accounting principles require us to measure acquired inventory at fair value. The fair value of inventory reflects the acquired company’s cost of manufacturing plus a portion of the expected profit margin. The non-GAAP adjustment excludes the expected profit margin component that is recorded under business combination accounting principles associated with our business acquisitions. We believe the adjustment is useful to investors because such charges are not reflective of our ongoing operations.

[0001032975-18-000005:8k_2_02:49]
Acquisition-related costs and change in fair value of contingent consideration for business acquisition.  We incurred expenses and credits in connection with our acquisitions which we generally would not have otherwise incurred in the periods presented as a part of our continuing operations. Acquisition related costs include all incremental expenses incurred to effect a business combination. Fair value of contingent consideration is associated with our estimates of the value of earn-outs in connection with certain acquisitions. We believe that providing the non-GAAP measures excluding these costs and credits, as well as the GAAP measures, assists our investors because such costs are not reflective of our ongoing operating results.

[0001032975-18-000005:8k_2_02:50]
Restructuring charges (credits). These expenses are associated with re-aligning our business strategies based on current economic conditions. We have undertaken several restructuring plans in recent years. In connection with our restructuring initiatives, we incurred restructuring charges related to employee terminations, facility closures and early cancellation of certain contracts. We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges (credits) are not reflective of our ongoing operating results in the current period.

[0001032975-18-000005:8k_2_02:51]
Gain (loss) on investments in privately held companies. We recognized gain (loss) related our investments in various privately-held companies, which varies depending on the operational and financial performance of the privately-held companies in which we invested. We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges are not reflective of our ongoing operations.

[0001032975-18-000005:8k_2_02:52]
Investigation and related expenses.  These expenses are forensic accounting, audit, consulting and legal fees related to the Audit Committee’s investigation and the formal investigation by and settlement with the Securities and Exchange Commission (SEC), together with accruals based on settlement with the SEC. We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges are not reflective of our ongoing operations.

[0001032975-18-000005:8k_2_02:53]
Non-GAAP income tax adjustment.  Non-GAAP income tax adjustment primarily measures the income tax effect of non-GAAP adjustments excluded above and other events; the determination of which is based upon the nature of the underlying items, the mix of income and losses in jurisdictions and the relevant tax rates in which we operate.

[0001032975-18-000005:8k_2_02:54]
Each of the non-GAAP financial measures described above, and used in this press release, should not be considered in isolation from, or as a substitute for, a measure of financial performance prepared in accordance with GAAP. Further, investors are cautioned that there are inherent limitations associated with the use of each of these non-GAAP financial measures as an analytical tool. In particular, these non-GAAP financial measures are not based on a comprehensive set of accounting rules or principles and many of the adjustments to the GAAP financial measures reflect the exclusion of items that are recurring and may be reflected in the Company’s financial results for the foreseeable future. We compensate for these limitations by providing specific information in the reconciliation included in this press release regarding the GAAP amounts excluded from the non-GAAP financial measures. In addition, as noted above, we evaluate the non-GAAP financial measures together with the most directly comparable GAAP financial information.

[0001032975-18-000005:8k_2_02:55]
Additional Supplemental Financial Information - Constant Currency

[0001032975-18-000005:8k_2_02:56]
In addition, Logitech presents percentage sales growth in constant currency to show performance unaffected by fluctuations in currency exchange rates.  Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales.
