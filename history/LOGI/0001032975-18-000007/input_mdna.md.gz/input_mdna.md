# LOGI MD&A — 0001032975-18-000007


## mdna

[0001032975-18-000007:mdna:1]
[same as prior period, unchanged from 0001032975-17-000053:mdna:1]

[0001032975-18-000007:mdna:2]
[same as prior period, unchanged from 0001032975-17-000053:mdna:2]

[0001032975-18-000007:mdna:3]
[same as prior period, unchanged from 0001032975-17-000053:mdna:3]

[0001032975-18-000007:mdna:4]
Logitech is a world leader in designing, manufacturing and marketing products that have an everyday place in people's lives, connecting them to the digital experiences they care about. More than 35 years ago Logitech created products to improve experiences around the PC platform, and now it is designing products that enable better experiences consuming, sharing and creating any digital content (e.g., music, gaming, video), whether it is on a computer, mobile device or in the cloud. Logitech's brands include Logitech, Jaybird, ASTRO, Logitech G and Ultimate Ears.

[0001032975-18-000007:mdna:5]
[same as prior period, unchanged from 0001032975-17-000053:mdna:5]

[0001032975-18-000007:mdna:6]
[same as prior period, unchanged from 0001032975-17-000053:mdna:6]

[0001032975-18-000007:mdna:7]
On August 11, 2017 (the "Acquisition Date"), we acquired certain assets and liabilities constituting the ASTRO Gaming business ("ASTRO") from AG Acquisition Corporation for a purchase price of $85.0 million in cash (the "ASTRO Acquisition"). ASTRO is a leading console gaming brand with a history of producing award-winning headsets for professional gamers and enthusiasts.

[0001032975-18-000007:mdna:8]
[same as prior period, unchanged from 0001032975-17-000053:mdna:8]

[0001032975-18-000007:mdna:9]
Our net sales for the three and nine months ended December 31, 2017 increased 22% and 15%, respectively, compared to the three and nine months ended December 31, 2016, due to stronger net sales across all regions. The results of operations for ASTRO have been included in our condensed consolidated statements of operations from the Acquisition Date. The ASTRO business is highly seasonal and it typically generates approximately half of its fiscal year sales in the third quarter.

[0001032975-18-000007:mdna:10]
For the three and nine months ended December 31, 2017, ASTRO contributed $33.5 million and $36.2 million to net sales, respectively, representing approximately 4% of our net sales for the three-month period and 2% for the nine-month period. For the nine months ended December 31, 2017, Saitek, which was acquired on September 15, 2016, contributed $8.4 million of sales increase, compared with the nine months ended December 31, 2016.

[0001032975-18-000007:mdna:11]
Our net sales for the three months ended December 31, 2017 increased 31%, 9% and 25% in the Americas, EMEA and Asia Pacific, respectively, compared to the same period of the prior fiscal year. Our net sales for the nine months ended December 31, 2017 increased 18%, 8% and 22% in the Americas, EMEA and Asia Pacific, respectively, compared to the same period of the prior fiscal year.

[0001032975-18-000007:mdna:12]
[same as prior period, unchanged from 0001032975-17-000053:mdna:11]

[0001032975-18-000007:mdna:13]
We added a new third-party logistics provider and distribution center in North America in the second half of the second quarter of fiscal year 2018 to support our growth. We experienced significant challenges in the transition from one distribution center to two, operating procedures at the newer distribution center, and in ramping fulfillment in the second quarter and early third quarter of fiscal year 2018. As a result, we incurred additional cost on freight and warehouse-related expense. We have started transition back to only one distribution center for North America and the process is expected to be completed during the fourth quarter of fiscal year 2018.

[0001032975-18-000007:mdna:14]
Our gross margin for the three months ended December 31, 2017 decreased to 33.9% from 37.0% for the three months ended December 31, 2016. Approximately 150 basis points of the decrease in gross margin was driven by an increase in logistics costs including additional costs from the transition of the distribution center in North America and the remaining decrease was primarily due to an increase in promotions related to product transition, and product mix, partially offset by lower variable compensation based on operational metrics.

[0001032975-18-000007:mdna:15]
Our gross margin for the nine months ended December 31, 2017 decreased to 35.3% from 36.4% for the nine months ended December 31, 2016. The decrease in gross margin was primarily driven by an increase in logistics costs including additional costs from the transition of the distribution center in North America, an increase in promotions related to product transition, and product mix, partially offset by product cost reductions and lower variable compensation based on operational metrics in the recent quarter.

[0001032975-18-000007:mdna:16]
Operating expenses for the three months ended December 31, 2017 were $175.3 million, or 21.6% of net sales, compared to $150.5 million, or 22.6% of net sales, in the same period of the prior fiscal year. Operating expenses for the nine months ended December 31, 2017 were $506.4 million, or 25.6% of net sales, compared to $446.7 million, or 26.1% of net sales, in the same period of the prior fiscal year. The increase for the three-month period was primarily driven by higher external expenses to support the advertising and marketing efforts for our new products, higher personnel related cost due to additional headcount from ASTRO Acquisition, and a credit from change in fair value of contingent consideration from the Jaybird Acquisition in the prior year, partially offset by lower variable compensation for fiscal year 2018 based on operational metrics. The increase for the nine-month period was mainly due to increases in marketing and selling expenses and research and development expenses from higher personnel-related costs due to increased headcount and higher external expenses to support the advertising and marketing efforts for our new products, in addition to a lower credit from the change in fair value of contingent consideration for business acquisition, partially offset by lower variable compensation based on operational metrics.

[0001032975-18-000007:mdna:17]
We recorded an income tax charge of $19.9 million from the provisional remeasurement of federal deferred tax assets and liabilities as of December 31, 2017 to reflect the effects of the enacted changes in tax rate and a provisional income tax benefit of $4.1 million from the reduction in federal valuation allowance against tax credits as a result of the tax reform.

[0001032975-18-000007:mdna:18]
Net income for the three and nine months ended December 31, 2017 was $80.8 million and $174.1 million, respectively, compared to $97.5 million and $166.5 million for the three and nine months ended December 31, 2016, respectively.

[0001032975-18-000007:mdna:19]
[same as prior period, unchanged from 0001032975-17-000053:mdna:17]

[0001032975-18-000007:mdna:20]
[same as prior period, unchanged from 0001032975-17-000053:mdna:18]

[0001032975-18-000007:mdna:21]
[same as prior period, unchanged from 0001032975-17-000053:mdna:19]

[0001032975-18-000007:mdna:22]
[same as prior period, unchanged from 0001032975-17-000053:mdna:20]

[0001032975-18-000007:mdna:23]
Music:  The music market grew during the first nine months of fiscal year 2018, driven by growing consumption of music through mobile devices such as smartphones and tablets. According to the Recording Industry Association of America (RIAA), revenues from streaming music platforms grew significantly in the first nine months of 2017. This market growth, together with our investments in the Ultimate Ears and Jaybird brands, new channel expansion, integration of personal voice assistants, such as Google Home and Amazon Alexa, and our new product introductions, has driven our growth in this market. The integration of personal voice assistants has become increasingly competitive in the speaker categories.

[0001032975-18-000007:mdna:24]
[same as prior period, unchanged from 0001032975-17-000053:mdna:22]

[0001032975-18-000007:mdna:25]
[same as prior period, unchanged from 0001032975-17-000053:mdna:23]

[0001032975-18-000007:mdna:26]
Smart Home:  This market increased in fiscal year 2017 and has continued to grow in the first nine months of fiscal year 2018. In October 2016, we integrated Amazon Alexa and Google Assistant voice capabilities into our Logitech Harmony Hub that enables voice control of the living room entertainment experience when used with an Amazon Echo or Echo Dot or a Google Home device. Our Ultimate Ears MEGABLAST and BLAST come with Amazon Alexa built-in, featuring voice-controlled music and the full range of Alexa’s skills. Through Harmony, Alexa can turn on/off and control a TV and AV system. We have also seen success with the professional installer channel

[0001032975-18-000007:mdna:27]
29

[0001032975-18-000007:mdna:28]
through the recent introduction of the Harmony Pro. We will continue to explore other innovative experiences for the Smart Home.

[0001032975-18-000007:mdna:29]
[same as prior period, unchanged from 0001032975-17-000053:mdna:25]

[0001032975-18-000007:mdna:30]
[same as prior period, unchanged from 0001032975-17-000053:mdna:26]

[0001032975-18-000007:mdna:31]
We have historically experienced higher net sales in our third fiscal quarter ending December 31, compared to other fiscal quarters in our fiscal year, due in part to seasonal holiday demand. Additionally, new product introductions and business acquisitions can significantly impact net sales, product costs and operating expenses. Product introductions can also impact our net sales to our distribution channels as these channels are filled with new product inventory following a product introduction, and often channel inventory of an earlier model product declines as the next related major product launch approaches. Net sales can also be affected when consumers and distributors anticipate a product introduction or changes in business circumstances. However, neither historical seasonal patterns nor historical patterns of product introductions should be considered reliable indicators of our future pattern of product introductions, future net sales or financial performance.

[0001032975-18-000007:mdna:32]
[same as prior period, unchanged from 0001032975-17-000053:mdna:28]

[0001032975-18-000007:mdna:33]
[same as prior period, unchanged from 0001032975-17-000053:mdna:29]

[0001032975-18-000007:mdna:34]
[same as prior period, unchanged from 0001032975-17-000053:mdna:30]

[0001032975-18-000007:mdna:35]
[same as prior period, unchanged from 0001032975-17-000053:mdna:31]

[0001032975-18-000007:mdna:36]
Other than the recent accounting pronouncement adoptions discussed below, there have been no substantial changes in the Company’s significant accounting policies during the nine months ended December 31, 2017, compared with the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended March 31, 2017.

[0001032975-18-000007:mdna:37]
[same as prior period, unchanged from 0001032975-17-000053:mdna:33]

[0001032975-18-000007:mdna:38]
In July 2015, the FASB issued ASU No. 2015-11, "Simplifying the Measurement of Inventory (Topic 330)" ("ASU 2015-11"). Topic 330, previously required an entity to measure inventory at the lower of cost or market, with market value represented by replacement cost, net realizable value or net realizable value less a normal profit margin. ASU 2015-11 requires an entity to measure inventory at the lower of cost or net realizable value and effective for fiscal years beginning after December 15, 2016. We adopted this standard effective April 1, 2017, which has not had a material impact on our condensed consolidated financial statements.

[0001032975-18-000007:mdna:39]
In March 2016, the FASB issued ASU 2016-09, "Compensation-Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting" ("ASU 2016-09"). ASU 2016-09 simplifies several aspects of the accounting for share-based payments, including immediate recognition of all excess tax benefits and deficiencies in the income statement, changing the threshold to qualify for equity classification up to the employees' maximum statutory tax rates, allowing an entity-wide accounting policy election to either estimate the number of awards that are expected to vest or account for forfeitures as they occur, and clarifying the classification on the

[0001032975-18-000007:mdna:40]
statement of cash flows for the excess tax benefits and employee taxes paid when an employer withholds shares for tax withholding purposes. ASU 2016-09 is effective for fiscal years beginning after December 15, 2016. We adopted this standard effective April 1, 2017. Changes to the statements of cash flows related to the classification of excess tax benefits were implemented on a retroactive basis and accordingly, to conform to the current year presentation, we reclassified $6.4 million of excess tax benefits previously reported under financing activities to operating activities for the nine months ended December 31, 2016 on our condensed consolidated statements of cash flows. Under the new standard, we account for forfeitures as they occur. The change in accounting for forfeitures resulted in a cumulative-effect adjustment to decrease retained earnings as of March 31, 2017 by $3.3 million. We further recognized a cumulative-effect adjustment to increase retained earnings as of March 31, 2017 by $57.2 million upon adoption of the new guidance to account for gross excess tax benefits of $75.2 million that were previously not recognized because the related tax deduction had not reduced current income taxes, offset by a valuation allowance of $18.0 million to reduce the deferred tax assets to amounts that are more likely than not to be realized.

[0001032975-18-000007:mdna:41]
In January 2017, the FASB issued ASU 2017-04, "Simplifying the Test for Goodwill Impairment (Topic 350)" ("ASU 2017-04"), which removes Step 2 from the goodwill impairment test. ASU 2017-04 is effective for annual or any interim goodwill impairments in annual periods beginning December 15, 2019, with early adoption permitted. We adopted this standard effective April 1, 2017, which has not had a material impact on our condensed consolidated financial statements.

[0001032975-18-000007:mdna:42]
In May 2017, the FASB issued ASU 2017-09, "Compensation-Stock Compensation (Topic 718): Scope of Modification Accounting" ("ASU 2017-09"), which provides guidance about which changes to the terms or conditions of a share-based payment award require an entity to apply modification accounting in Topic 718. ASU 2017-09 is effective for annual periods beginning after December 15, 2017, with early adoption permitted, including adoption in any interim period for which financial statements have not yet been issued. We adopted this standard effective April 1, 2017, which has not had a material impact on our condensed consolidated financial statements.

[0001032975-18-000007:mdna:43]
[same as prior period, unchanged from 0001032975-17-000053:mdna:39]

[0001032975-18-000007:mdna:44]
[same as prior period, unchanged from 0001032975-17-000053:mdna:40]

[0001032975-18-000007:mdna:45]
We refer to our net sales growth rates excluding the impact of currency exchange rate fluctuations as "constant dollar" sales growth rates. Percentage of constant dollar sales growth is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales.

[0001032975-18-000007:mdna:46]
Given our global sales presence and the reporting of our financial results in U.S. Dollars, our financial results could be affected by significant shifts in currency exchange rates. See “Results of Operations” for information on the effect of currency exchange results on our net sales. If the U.S. Dollar appreciates or depreciates in comparison to other currencies in future periods, this will affect our results of operations in future periods as well.

[0001032975-18-000007:mdna:47]
[same as prior period, unchanged from 0001032975-17-000053:mdna:43]

[0001032975-18-000007:mdna:48]
Although our financial results are reported in U.S. Dollars, a portion of our sales was generated in currencies other than the U.S. Dollar, such as the Euro, Chinese Renminbi, Japanese Yen, Canadian Dollar, Taiwan New Dollar, British Pound and Australian Dollar. During the three months ended December 31, 2017, 47% of our net sales were denominated in currencies other than the U.S. Dollar.

[0001032975-18-000007:mdna:49]
31

[0001032975-18-000007:mdna:50]
[same as prior period, unchanged from 0001032975-17-000053:mdna:45]

[0001032975-18-000007:mdna:51]
[same as prior period, unchanged from 0001032975-17-000053:mdna:46]

[0001032975-18-000007:mdna:52]
Net sales for the three and nine months ended December 31, 2017 and 2016 were as follows (Dollars in thousands):

[0001032975-18-000007:mdna:53]
|  |  | Three Months EndedDecember 31, |  | Nine Months Ended December 31, |
|  |  | 2017 |  | 2016 |  | Change |  | 2017 |  | 2016 |  | Change |
| Net Sales |  | $ | 812,021 |  |  | $ | 666,707 |  |  | 22 | % |  | $ | 1,974,437 |  |  | $ | 1,710,875 |  |  | 15 | % |

[0001032975-18-000007:mdna:54]
Our net sales in the three and nine months ended December 31, 2017 increased 22% and 15%, respectively, compared to the same periods of the prior fiscal year. Sales increased across all three regions during the three and nine months ended December 31, 2017. If currency exchange rates had been constant in the three and nine months ended December 31, 2017 and 2016, our constant dollar sales growth rates would have been 18% and 14%, respectively. We grew across most of our product categories, with Gaming, Smart Home, Video Collaboration and Mobile Speakers growing double digits for both periods presented above compared to the same periods of the prior fiscal year.

[0001032975-18-000007:mdna:55]
[same as prior period, unchanged from 0001032975-17-000053:mdna:50]

[0001032975-18-000007:mdna:56]
The following table presents the change in net sales by region for the three and nine months ended December 31, 2017, compared with the three and nine months ended December 31, 2016:

[0001032975-18-000007:mdna:57]
|  |  | Three Months EndedDecember 31, 2017 Change in Sales |  | Nine Months EndedDecember 31, 2017Change in Sales |
| Americas |  | 31 | % |  | 18 | % |
| EMEA |  | 9 |  |  | 8 |  |
| Asia Pacific |  | 25 |  |  | 22 |  |

[0001032975-18-000007:mdna:58]
[same as prior period, unchanged from 0001032975-17-000053:mdna:53]

[0001032975-18-000007:mdna:59]
Net sales in the Americas increased 31% and 18% during the three and nine months ended December 31, 2017, respectively, compared to the same periods of the prior fiscal year. If currency exchange rates had been constant in the three and nine months ended December 31, 2017 and 2016, our constant dollar sales growth rate would have been 30% and 18% in the Americas, respectively. The increase for the three-month period was primarily driven by increases in sales of Gaming (including ASTRO), Mobile Speakers, Audio PC & Wearables and Smart Home. The increase for the nine-month period was driven by increases in sales of all categories, led by Gaming, Mobile Speakers, Tablet & Other Accessories and Smart Home.

[0001032975-18-000007:mdna:60]
[same as prior period, unchanged from 0001032975-17-000053:mdna:55]

[0001032975-18-000007:mdna:61]
Net sales in EMEA increased 9% and 8% during the three and nine months ended December 31, 2017, respectively, compared to the same periods of the prior fiscal year. If currency exchange rates had been constant in the three and nine months ended December 31, 2017 and 2016, our constant dollar sales growth rates would have been 2% and 5%, respectively. The growth in both periods was driven by sales increases in Gaming, Mobile Speakers, Smart Home, and Video Collaboration, partially offset by declines in Pointing Devices and PC Webcams.

[0001032975-18-000007:mdna:62]
[same as prior period, unchanged from 0001032975-17-000053:mdna:57]

[0001032975-18-000007:mdna:63]
Net sales in Asia Pacific increased 25% and 22% during the three and nine months ended December 31, 2017, respectively, compared to the same periods of the prior fiscal year. If currency exchange rates had been constant in the three and nine months ended December 31, 2017 and 2016, our constant dollar sales growth rates would have been 23% and 22%, respectively. The growth in both periods was driven by Gaming, Video Collaboration, Mobile Speakers, Pointing Devices and Audio PC & Wearables.

[0001032975-18-000007:mdna:64]
[same as prior period, unchanged from 0001032975-17-000053:mdna:59]

[0001032975-18-000007:mdna:65]
Net sales by product category for the three and nine months ended December 31, 2017 and 2016 were as follows (Dollars in thousands):

[0001032975-18-000007:mdna:66]
|  |  | Three Months EndedDecember 31, |  | Nine Months Ended December 31, |
|  |  | 2017 |  | 2016 |  | Change |  | 2017 |  | 2016 |  | Change |
| Pointing Devices |  | $ | 140,983 |  |  | $ | 142,166 |  |  | (1 | )% |  | $ | 386,700 |  |  | $ | 382,249 |  |  | 1 | % |
| Keyboards & Combos |  | 126,372 |  |  | 125,289 |  |  | 1 |  |  | 361,685 |  |  | 359,824 |  |  | 1 |  |
| PC Webcams |  | 27,280 |  |  | 30,503 |  |  | (11 | ) |  | 80,371 |  |  | 80,072 |  |  | — |  |
| Tablet & Other Accessories |  | 26,648 |  |  | 24,852 |  |  | 7 |  |  | 80,650 |  |  | 59,351 |  |  | 36 |  |
| Video Collaboration |  | 46,252 |  |  | 35,807 |  |  | 29 |  |  | 128,008 |  |  | 88,298 |  |  | 45 |  |
| Mobile Speakers |  | 147,377 |  |  | 106,578 |  |  | 38 |  |  | 300,843 |  |  | 261,046 |  |  | 15 |  |
| Audio-PC & Wearables |  | 84,435 |  |  | 67,225 |  |  | 26 |  |  | 197,082 |  |  | 186,058 |  |  | 6 |  |
| Gaming |  | 173,802 |  |  | 107,181 |  |  | 62 |  |  | 365,232 |  |  | 242,874 |  |  | 50 |  |
| Smart Home |  | 38,692 |  |  | 26,942 |  |  | 44 |  |  | 73,481 |  |  | 49,916 |  |  | 47 |  |
| Other (1) |  | 180 |  |  | 164 |  |  | 10 |  |  | 385 |  |  | 1,187 |  |  | (68 | ) |
| Total net sales |  | $ | 812,021 |  |  | $ | 666,707 |  |  | 22 |  |  | $ | 1,974,437 |  |  | $ | 1,710,875 |  |  | 15 |  |

[0001032975-18-000007:mdna:67]
[same as prior period, unchanged from 0001032975-17-000053:mdna:62]

[0001032975-18-000007:mdna:68]
[same as prior period, unchanged from 0001032975-17-000053:mdna:63]

[0001032975-18-000007:mdna:69]
[same as prior period, unchanged from 0001032975-17-000053:mdna:64]

[0001032975-18-000007:mdna:70]
[same as prior period, unchanged from 0001032975-17-000053:mdna:65]

[0001032975-18-000007:mdna:71]
[same as prior period, unchanged from 0001032975-17-000053:mdna:66]

[0001032975-18-000007:mdna:72]
Net sales of Pointing Devices decreased 1% for the three months ended and increased 1% for the nine months ended December 31, 2017, respectively, compared to the same periods of the prior fiscal year. The decrease for the three-month period was primarily driven by a decrease in sales of mice, partially offset by an increase in sales of trackball and presentation tools. The increase for the nine-month period was driven by an increase in sales of trackball and presentation tools, partially offset by the decrease in the sales of mice and other pointing devices.

[0001032975-18-000007:mdna:73]
[same as prior period, unchanged from 0001032975-17-000053:mdna:68]

[0001032975-18-000007:mdna:74]
[same as prior period, unchanged from 0001032975-17-000053:mdna:69]

[0001032975-18-000007:mdna:75]
Net sales of Keyboards & Combos increased 1% in the three and nine months ended December 31, 2017, compared to the same periods of the prior fiscal year. The increases for both periods were primarily driven by an increase in sales for cordless keyboards, partially offset by a decrease in sales of living room keyboards.

[0001032975-18-000007:mdna:76]
[same as prior period, unchanged from 0001032975-17-000053:mdna:71]

[0001032975-18-000007:mdna:77]
[same as prior period, unchanged from 0001032975-17-000053:mdna:72]

[0001032975-18-000007:mdna:78]
PC Webcams net sales decreased 11% and remained flat in the three and nine months ended December 31, 2017, respectively, compared to the same periods of the prior fiscal year. The decrease for the three-month period was primarily driven by the decreases in sales across most webcam products within this product category.

[0001032975-18-000007:mdna:79]
[same as prior period, unchanged from 0001032975-17-000053:mdna:74]

[0001032975-18-000007:mdna:80]
[same as prior period, unchanged from 0001032975-17-000053:mdna:75]

[0001032975-18-000007:mdna:81]
Net sales of Tablet & Other Accessories products increased 7% and 36% in the three and nine months ended December 31, 2017, respectively, compared to the same periods of the prior fiscal year. The increases for both periods were primarily driven by an increase in sales of tablet keyboards, including the introduction of the Slim Folio, 10.5-inch and 12.9-inch Slim Combo keyboard cases, partially offset by a decrease in sales for tablet covers and other accessories. Rugged Combo also contributed to the growth for the nine-month period.

[0001032975-18-000007:mdna:82]
[same as prior period, unchanged from 0001032975-17-000053:mdna:77]

[0001032975-18-000007:mdna:83]
[same as prior period, unchanged from 0001032975-17-000053:mdna:78]

[0001032975-18-000007:mdna:84]
[same as prior period, unchanged from 0001032975-17-000053:mdna:79]

[0001032975-18-000007:mdna:85]
Net sales of Video Collaboration products increased 29% and 45% in the three and nine months ended December 31, 2017, respectively, compared to the same periods of the prior fiscal year. The increases for both periods were primarily due to the introduction of the Brio 4K Pro Webcam, PTZ Pro 2 group camera, and Meetup video conference camera in the first half of fiscal year 2018. Logitech Group video conference system also contributed to the growth for the nine-month period.

[0001032975-18-000007:mdna:86]
[same as prior period, unchanged from 0001032975-17-000053:mdna:81]

[0001032975-18-000007:mdna:87]
[same as prior period, unchanged from 0001032975-17-000053:mdna:82]

[0001032975-18-000007:mdna:88]
Our Mobile Speakers category is made up entirely of Bluetooth wireless speakers.

[0001032975-18-000007:mdna:89]
Net sales of Mobile Speakers increased 38% and 15% for the three and nine months ended December 31, 2017, respectively, compared to the same period of the prior fiscal year.  The increases for both periods were primarily due to the introduction of Ultimate Ears WONDERBOOM in early fiscal year 2018, and the launch of MEGABLAST and BLAST in the third quarter of fiscal year 2018.

[0001032975-18-000007:mdna:90]
Audio PC & Wearables

[0001032975-18-000007:mdna:91]
Our Audio PC & Wearables category comprises PC speakers, PC headsets, in-ear headphones and premium wireless audio wearables.

[0001032975-18-000007:mdna:92]
Audio-PC & Wearables net sales increased 26% and 6% for the three and nine months ended December 31, 2017, respectively, compared to the same periods of the prior fiscal year. The increases were primarily driven by a sales increase of Jaybird products, partially offset by a sales decrease of PC speakers and other headsets. Jaybird posted strong growth this quarter, with good contribution from Jaybird Run, our first true wireless earphone, and from our other Jaybird product lines.

[0001032975-18-000007:mdna:93]
[same as prior period, unchanged from 0001032975-17-000053:mdna:88]

[0001032975-18-000007:mdna:94]
[same as prior period, unchanged from 0001032975-17-000053:mdna:89]

[0001032975-18-000007:mdna:95]
[same as prior period, unchanged from 0001032975-17-000053:mdna:90]

[0001032975-18-000007:mdna:96]
Gaming net sales increased 62% and 50% for the three and nine months ended December 31, 2017, respectively, compared to the same periods of the prior fiscal year. The significant increases for both periods were primarily driven by the strong performance of console gaming headsets from the acquisition of ASTRO, as well as the continuing success of our gaming mice, steering wheels, keyboards, headsets and Saitek simulation products.

[0001032975-18-000007:mdna:97]
[same as prior period, unchanged from 0001032975-17-000053:mdna:92]

[0001032975-18-000007:mdna:98]
[same as prior period, unchanged from 0001032975-17-000053:mdna:93]

[0001032975-18-000007:mdna:99]
[same as prior period, unchanged from 0001032975-17-000053:mdna:94]

[0001032975-18-000007:mdna:100]
Smart Home net sales increased 44% and 47% during the three and nine months ended December 31, 2017, respectively, compared to the same periods of the prior fiscal year. The increases were primarily due to the continued success of our Harmony Smart home remote, as well as the introduction of Circle 2 Wired and Circle 2 Wireless security cameras in the second quarter of fiscal year 2018.

[0001032975-18-000007:mdna:101]
[same as prior period, unchanged from 0001032975-17-000053:mdna:96]

[0001032975-18-000007:mdna:102]
Gross profit for the three and nine months ended December 31, 2017 and 2016 was as follows (Dollars in thousands):

[0001032975-18-000007:mdna:103]
|  |  | Three Months EndedDecember 31, |  | Nine Months Ended December 31, |
|  |  | 2017 |  | 2016 |  | Change |  | 2017 |  | 2016 |  | Change |
| Net sales |  | $ | 812,021 |  |  | $ | 666,707 |  |  | 22 | % |  | $ | 1,974,437 |  |  | $ | 1,710,875 |  |  | 15 | % |
| Gross profit |  | $ | 275,601 |  |  | $ | 246,763 |  |  | 12 |  |  | $ | 697,006 |  |  | $ | 622,262 |  |  | 12 |  |
| Gross margin |  | 33.9 | % |  | 37.0 | % |  |  |  | 35.3 | % |  | 36.4 | % |  |  |  |

[0001032975-18-000007:mdna:104]
Gross profit consists of net sales less cost of goods sold (which includes materials, direct labor and related overhead costs, costs of manufacturing facilities, royalties, costs of purchasing components from outside suppliers, distribution costs, warranty costs, customer support, shipping and handling costs, outside processing costs and write-down of inventories), amortization of intangible assets and purchase accounting effect on inventory.

[0001032975-18-000007:mdna:105]
Our gross margin for the three months ended December 31, 2017 decreased by 310 basis points compared to the three months ended December 31, 2016. Approximately 150 basis points of the decrease in gross margin was driven by an increase in logistics costs including additional costs from the transition of the distribution center in North America and the remaining decrease was primarily due to an increase in promotions related to product transition, and product mix, partially offset by lower variable compensation based on operational metrics.

[0001032975-18-000007:mdna:106]
Our gross margin for the nine months ended December 31, 2017 decreased by 110 basis points compared to the nine months ended December 31, 2016. The decrease in gross margin was primarily driven by an increase in logistics costs including additional costs from the transition of the distribution center in North America, an increase in promotions related to product transition, and product mix, partially offset by product cost reductions and lower variable compensation based on operational metrics.

[0001032975-18-000007:mdna:107]
[same as prior period, unchanged from 0001032975-17-000053:mdna:102]

[0001032975-18-000007:mdna:108]
Operating expenses for the three and nine months ended December 31, 2017 and 2016 were as follows (Dollars in thousands):

[0001032975-18-000007:mdna:109]
|  |  | Three Months EndedDecember 31, |  | Nine Months Ended December 31, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Marketing and selling |  | $ | 116,153 |  |  | $ | 102,036 |  |  | $ | 325,917 |  |  | $ | 279,700 |  |
| % of net sales |  | 14.3 | % |  | 15.3 | % |  | 16.5 | % |  | 16.3 | % |
| Research and development |  | 34,398 |  |  | 32,284 |  |  | 106,144 |  |  | 96,867 |  |
| % of net sales |  | 4.2 | % |  | 4.8 | % |  | 5.4 | % |  | 5.7 | % |
| General and administrative |  | 22,291 |  |  | 24,598 |  |  | 72,850 |  |  | 75,543 |  |
| % of net sales |  | 2.7 | % |  | 3.7 | % |  | 3.7 | % |  | 4.4 | % |
| Amortization of intangible assets and acquisition-related costs |  | 2,496 |  |  | 1,494 |  |  | 6,377 |  |  | 4,535 |  |
| % of net sales |  | 0.3 | % |  | 0.2 | % |  | 0.3 | % |  | 0.3 | % |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | (9,925 | ) |  | (4,908 | ) |  | (9,925 | ) |
| % of net sales |  | — | % |  | (1.5 | )% |  | (0.2 | )% |  | (0.6 | )% |
| Total operating expenses |  | $ | 175,338 |  |  | $ | 150,487 |  |  | $ | 506,380 |  |  | $ | 446,720 |  |
| % of net sales |  | 21.6 | % |  | 22.6 | % |  | 25.6 | % |  | 26.1 | % |

[0001032975-18-000007:mdna:110]
The increase in total operating expenses for the three months ended December 31, 2017, compared to the same period of the prior fiscal year, was mainly due to increases in marketing and selling expenses from higher external expenses to support the advertising and marketing efforts for our new products and higher personnel related costs from additional headcount and from ASTRO Acquisition, partially offset by lower variable compensation based on operational metrics. In addition, there was a $9.9 million credit from the change in fair value of contingent consideration for a business acquisition in the prior year, which did not exist in the current year.

[0001032975-18-000007:mdna:111]
The increase in total operating expenses for the nine months ended December 31, 2017, compared to the same period of the prior fiscal year, was mainly due to higher external expenses to support the advertising and marketing efforts for our new products, increases in marketing and selling expenses and research and development expenses from higher personnel-related costs due to increased headcount, in addition to a lower credit from the change in fair value of contingent consideration for business acquisition, partially offset by lower variable compensation based on operational metrics.

[0001032975-18-000007:mdna:112]
[same as prior period, unchanged from 0001032975-17-000053:mdna:106]

[0001032975-18-000007:mdna:113]
[same as prior period, unchanged from 0001032975-17-000053:mdna:107]

[0001032975-18-000007:mdna:114]
During the three months ended December 31, 2017, marketing and selling expenses increased $14.1 million, compared to the same period of the prior fiscal year. The increase was primarily driven by $11.2 million higher external expenses to support the advertising and marketing efforts for our new products and $1.6 million higher personnel-related costs due to increased headcount and from ASTRO Acquisition, partially offset by lower variable compensation based on operational metrics.

[0001032975-18-000007:mdna:115]
During the nine months ended December 31, 2017, marketing and selling expenses increased $46.2 million compared to the same period of the prior fiscal year. The increase was primarily driven by $29.7 million higher external expenses to support the advertising and marketing efforts for our new products and $14.8 million higher personnel-related costs due to increased headcount, partially offset by lower variable compensation based on operational metrics.

[0001032975-18-000007:mdna:116]
36

[0001032975-18-000007:mdna:117]
[same as prior period, unchanged from 0001032975-17-000053:mdna:110]

[0001032975-18-000007:mdna:118]
[same as prior period, unchanged from 0001032975-17-000053:mdna:111]

[0001032975-18-000007:mdna:119]
During the three months ended December 31, 2017, research and development expenses increased $2.1 million compared to the same period in the prior fiscal year. The increase was primarily driven by higher personnel-related costs due to increased headcount to support the development and launch of new products and capabilities and from ASTRO Acquisition, partially offset by lower variable compensation based on operational metrics.

[0001032975-18-000007:mdna:120]
During the nine months ended December 31, 2017, research and development expenses increased $9.3 million compared to the same period in the prior fiscal year. The increase was primarily driven by $9.7 million higher personnel-related costs due to increased headcount to support the development and launch of new products and capabilities, partially offset by lower variable compensation based on operational metrics.

[0001032975-18-000007:mdna:121]
[same as prior period, unchanged from 0001032975-17-000053:mdna:113]

[0001032975-18-000007:mdna:122]
[same as prior period, unchanged from 0001032975-17-000053:mdna:114]

[0001032975-18-000007:mdna:123]
During the three and nine months ended December 31, 2017, general and administrative expenses decreased $2.3 million and $2.7 million, respectively, compared to the same periods in the prior fiscal year, primarily due to lower variable compensation based on operational metrics.

[0001032975-18-000007:mdna:124]
[same as prior period, unchanged from 0001032975-17-000053:mdna:116]

[0001032975-18-000007:mdna:125]
Amortization of intangibles and acquisition-related costs during the three and nine months ended December 31, 2017 and 2016 were as follows (in thousands):

[0001032975-18-000007:mdna:126]
|  |  | Three Months EndedDecember 31, |  | Nine Months Ended December 31, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Amortization of intangible assets |  | $ | 2,126 |  |  | $ | 1,279 |  |  | $ | 4,965 |  |  | $ | 3,074 |  |
| Acquisition-related costs |  | 370 |  |  | 215 |  |  | 1,412 |  |  | 1,461 |  |
| Total |  | $ | 2,496 |  |  | $ | 1,494 |  |  | $ | 6,377 |  |  | $ | 4,535 |  |

[0001032975-18-000007:mdna:127]
[same as prior period, unchanged from 0001032975-17-000053:mdna:119]

[0001032975-18-000007:mdna:128]
[same as prior period, unchanged from 0001032975-17-000053:mdna:120]

[0001032975-18-000007:mdna:129]
During the nine months ended December 31, 2017, the fair value of the contingent consideration for business acquisition decreased $4.9 million. The decrease in fair value of contingent consideration is primarily due to the agreement we reached with the sellers of Jaybird. In October 2017, we entered into an agreement with the sellers of Jaybird fully, irrevocably and unconditionally releases the Company from the earn-out rights and payments in the Jaybird Acquisition agreement in exchange for $5.0 million in cash, which approximates the fair value of the contingent consideration as of September 30, 2017. See "Note 7 - Fair Value Measurements" to our condensed consolidated financial statements for further details.

[0001032975-18-000007:mdna:130]
37

[0001032975-18-000007:mdna:131]
[same as prior period, unchanged from 0001032975-17-000053:mdna:122]

[0001032975-18-000007:mdna:132]
The provision for (benefit from) income taxes and effective tax rates for the three and nine months ended December 31, 2017 and 2016 were as follows (Dollars in thousands):

[0001032975-18-000007:mdna:133]
|  |  | Three Months EndedDecember 31, |  | Nine Months Ended December 31, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Provision for income taxes |  | $ | 20,040 |  |  | $ | 1,647 |  |  | $ | 18,691 |  |  | $ | 10,297 |  |
| Effective income tax rate |  | 19.9 | % |  | 1.7 | % |  | 9.7 | % |  | 5.8 | % |

[0001032975-18-000007:mdna:134]
The change in the effective income tax rate in the three months ended December 31, 2017 compared to the same period of the prior fiscal year is primarily due to $19.9 million of income tax provision from the provisional remeasurement of deferred tax assets and liabilities in the United States based on the applicable enacted federal income tax rates when the temporary differences and tax attribute carryforwards are expected to recover or settle. The remeasurement charge is offset by $4.1 million of provisional income tax benefit from the reduction in federal valuation allowance against tax credits as a result of the tax reform.

[0001032975-18-000007:mdna:135]
The change in the effective income tax rate in the nine months ended December 31, 2017 compared to the same period of the prior fiscal year is primarily due to the recognition of excess tax benefits of $10.8 million after adoption of ASU 2016-09 and income tax benefit from the reversal of uncertain tax positions from the expiration of statutes of limitations are largely offset by income tax provision from the provisional remeasurement of deferred tax assets and liabilities in the third quarter.  In the three and nine months ended December 31, 2017, there was a discrete income tax benefit of $6.0 million and $7.9 million, respectively, from the reversal of uncertain tax positions from the expiration of statutes of limitations. In the same periods ended December 31, 2016, the income tax benefit from the reversal of uncertain tax positions from the expiration of statutes of limitations was $9.4 million and $11.1 million, respectively.

[0001032975-18-000007:mdna:136]
As of December 31 and March 31, 2017, the total amount of unrecognized tax benefits due to uncertain tax positions was $67.3 million and $63.7 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-18-000007:mdna:137]
[same as prior period, unchanged from 0001032975-17-000053:mdna:127]

[0001032975-18-000007:mdna:138]
[same as prior period, unchanged from 0001032975-17-000053:mdna:128]

[0001032975-18-000007:mdna:139]
As of December 31, 2017, we had cash and cash equivalents of $564.9 million, compared to $547.5 million as of March 31, 2017, of which 38% is held in Switzerland, 30% is held in Germany, and 14% is held in Hong Kong and China as of December 31, 2017. We do not expect to incur any material adverse tax impact except for what has been recognized, or be significantly inhibited by any country in which we do business from the repatriation of funds to Switzerland, our home domicile.

[0001032975-18-000007:mdna:140]
The increase in cash and cash equivalents was primarily due to the net income and proceeds from exercises of stock options and purchase rights partially offset by the payment of cash dividends, cash paid for acquisitions, purchases of property, plant and equipment, tax withholdings related to settlements of restricted stock units and the purchases of our shares.

[0001032975-18-000007:mdna:141]
As of December 31, 2017, our working capital was $546.0 million, compared to $520.8 million as of March 31, 2017. The increase was primarily due to higher accounts receivable, net, partially offset by higher accounts payable, higher accruals and other liabilities. Our working capital increased compared to $478.7 million as of December 31, 2016, which was primarily driven by higher accounts receivable, net and higher inventories, partially offset by higher accounts payable and higher accruals and other liabilities.

[0001032975-18-000007:mdna:142]
We had several uncommitted, unsecured bank lines of credit aggregating $62.1 million as of December 31, 2017. There are no financial covenants under these lines of credit with which we must comply. As of December 31, 2017, we had outstanding bank guarantees of $44.2 million under these lines of credit.

[0001032975-18-000007:mdna:143]
[same as prior period, unchanged from 0001032975-17-000053:mdna:170]

[0001032975-18-000007:mdna:144]
The following table summarizes our Condensed Consolidated Statements of Cash Flows (in thousands):

[0001032975-18-000007:mdna:145]
|  |  | Nine Months Ended December 31, |
|  |  | 2017 |  | 2016 |
| Net cash provided by operating activities |  | $ | 256,084 |  |  | $ | 240,647 |  |
| Net cash used in investing activities |  | (116,192 | ) |  | (90,240 | ) |
| Net cash used in financing activities |  | (124,214 | ) |  | (149,556 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  | 1,677 |  |  | (6,468 | ) |
| Net increase (decrease) in cash and cash equivalents |  | $ | 17,355 |  |  | $ | (5,617 | ) |

[0001032975-18-000007:mdna:146]
The following table presents selected financial information and statistics as of December 31, 2017 and 2016 (Dollars in thousands):

[0001032975-18-000007:mdna:147]
|  |  | Three Months EndedDecember 31, |
|  |  | 2017 |  | 2016 |
| Accounts receivable, net |  | $ | 351,753 |  |  | $ | 277,677 |  |
| Accounts payable |  | $ | 429,119 |  |  | $ | 358,196 |  |
| Inventories |  | $ | 278,979 |  |  | $ | 250,286 |  |
| Days sales in accounts receivable (“DSO”) (Days) (1) |  | 39 |  |  | 37 |  |
| Days accounts payable outstanding (“DPO”) (Days) (2) |  | 72 |  |  | 77 |  |
| Inventory turnover (“ITO”) (x)(3) |  | 7.7 |  |  | 6.7 |  |

[0001032975-18-000007:mdna:148]
[same as prior period, unchanged from 0001032975-17-000053:mdna:137]

[0001032975-18-000007:mdna:149]
[same as prior period, unchanged from 0001032975-17-000053:mdna:138]

[0001032975-18-000007:mdna:150]
[same as prior period, unchanged from 0001032975-17-000053:mdna:139]

[0001032975-18-000007:mdna:151]
DSO for the three months ended December 31, 2017 increased two days, compared to December 31, 2016, primarily due to the introduction of breakage model for EMEA marketing and incentive programs during the fourth quarter of fiscal year 2017.

[0001032975-18-000007:mdna:152]
DPO for the three months ended December 31, 2017 decreased five days, compared to December 31, 2016, primarily due to the timing of purchases.

[0001032975-18-000007:mdna:153]
ITO for the three months ended December 31, 2017 was higher, compared to the same period of the prior fiscal year. The increase in inventories compared with December 31, 2016 was primarily driven by higher net sales.

[0001032975-18-000007:mdna:154]
[same as prior period, unchanged from 0001032975-17-000053:mdna:143]

[0001032975-18-000007:mdna:155]
During the nine months ended December 31, 2017, we generated $256.1 million cash in operating activities. Our main sources of operating cash flows were from net income after adding back non-cash expenses of depreciation, amortization, and share-based compensation expense, and from the increases in accounts payable and accrued and other liabilities, offset by the increase in accounts receivable, net. The increase in accounts receivable, net was primarily due to higher sales and timing of customer payments, and the increase in accounts payable and accrued and other liabilities was primarily driven by the timing of payments.

[0001032975-18-000007:mdna:156]
Net cash used in investing activities was $116.2 million, primarily due to $85.0 million of purchase price for the acquisition of the ASTRO business (refer to "Note 2- Business Acquisition" to the condensed consolidated financial statements) and $27.6 million of purchases of property, plant and equipment.

[0001032975-18-000007:mdna:157]
[same as prior period, unchanged from 0001032975-17-000053:mdna:173]

[0001032975-18-000007:mdna:158]
Our expenditures for property, plant and equipment during the nine months ended December 31, 2017 increased by $4.2 million, compared to the same period of the prior fiscal year, mainly due to the higher amount of tooling purchases.

[0001032975-18-000007:mdna:159]
Net cash used in financing activities was $124.2 million, primarily for the $104.2 million cash dividends paid, $20.4 million repurchases of our registered shares, $25.5 million tax withholdings related to net share settlements of restricted stock units, and $5.0 million payment of contingent consideration in connection with the Jaybird acquisition, partially offset by $30.9 million in proceeds received from the exercises of stock options.

[0001032975-18-000007:mdna:160]
During the nine months ended December 31, 2017, there was a $1.7 million gain of currency translation exchange rate effect on cash and cash equivalents, compared to a loss of $6.5 million during the same period of the prior fiscal year. The gain from currency translation exchange effect during the nine months ended December 31, 2017 was primarily due to the strengthening of the Euro against the U.S. Dollar by 12% during the period. The loss from currency translation exchange effect during the nine months ended December 31, 2016 was primarily due to the weakening of the Euro against the U.S. Dollar by 8% during the period, which had an adverse impact on our cash and cash equivalents balances in subsidiaries with Euro as their functional currency.

[0001032975-18-000007:mdna:161]
[same as prior period, unchanged from 0001032975-17-000053:mdna:149]

[0001032975-18-000007:mdna:162]
[same as prior period, unchanged from 0001032975-17-000053:mdna:150]

[0001032975-18-000007:mdna:163]
During the nine months ended December 31, 2017, we declared and paid cash dividends of approximately CHF 0.61 (USD equivalent of $0.63) per common share, totaling $104.2 million on our outstanding common stock. During the nine months ended December 31, 2016, we declared and paid cash dividends of approximately CHF 0.56 (USD equivalent of $0.57) per common share, totaling $93.1 million on our outstanding common stock. Any future dividends will be subject to the approval of our shareholders.

[0001032975-18-000007:mdna:164]
In March 2017, our Board of Directors approved another share buyback program, which authorizes us to purchase up to $250.0 million of our own shares, following the expiration date of our 2014 buyback program. The new program was approved by the Swiss Takeover Board in May 2017. Although we enter into trading plans for systematic repurchases (e.g., 10b5-1 trading plans) from time to time, our share buyback program provides us with the opportunity to make opportunistic repurchases during periods of favorable market conditions and is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Opportunistic purchases may be started or stopped at any time without prior notice depending on market conditions and other factors. As of December 31, 2017, $230.2 million is still available for repurchase under the 2017 buyback program.

[0001032975-18-000007:mdna:165]
As noted in "Note 7 - Fair Value Measurements" to our condensed consolidated financial statements, we acquired all of the equity interest of Jaybird with an additional earn-out of up to $45.0 million in cash based on the achievement of certain net revenue growth targets over two years starting July 2016. If the net revenue growth targets were met, the Company would have paid a maximum of $25.0 million and $20.0 million in fiscal years 2018 and 2019, respectively.  In October 2017, we entered into an agreement with the sellers of Jaybird which fully, irrevocably and unconditionally releases us from the earn-out rights and payments in the Jaybird purchase agreement in exchange for $5.0 million in cash. In November 2017, we made the payment of $5.0 million to the sellers of Jaybird.

[0001032975-18-000007:mdna:166]
[same as prior period, unchanged from 0001032975-17-000053:mdna:154]

[0001032975-18-000007:mdna:167]
[same as prior period, unchanged from 0001032975-17-000053:mdna:155]

[0001032975-18-000007:mdna:168]
[same as prior period, unchanged from 0001032975-17-000053:mdna:156]

[0001032975-18-000007:mdna:169]
We lease facilities under operating leases, certain of which require us to pay property taxes, insurance and maintenance costs. Operating leases for facilities are generally renewable at our option and usually include escalation clauses linked to inflation. The remaining terms of our non-cancelable operating leases expire in various years through 2030.

[0001032975-18-000007:mdna:170]
[same as prior period, unchanged from 0001032975-17-000053:mdna:158]

[0001032975-18-000007:mdna:171]
As of December 31, 2017, we had non-cancelable purchase commitments for inventory purchases made in the normal course of business to original design manufacturers, contract manufacturers and other suppliers, the majority of which are expected to be fulfilled within the next 12 months. Non-cancelable purchase commitments for capital expenditures primarily relate to commitments for tooling for new and existing products, computer hardware, leasehold and improvements. We expect to continue making capital expenditures in the future to support product development activities and ongoing and expanded operations. Although open purchase commitments are considered enforceable and legally binding, the terms generally allow us to reschedule or adjust our requirements based on business needs prior to delivery of goods or performance of services.

[0001032975-18-000007:mdna:172]
[same as prior period, unchanged from 0001032975-17-000053:mdna:160]

[0001032975-18-000007:mdna:173]
[same as prior period, unchanged from 0001032975-17-000053:mdna:161]

[0001032975-18-000007:mdna:174]
[same as prior period, unchanged from 0001032975-17-000053:mdna:162]

[0001032975-18-000007:mdna:175]
[same as prior period, unchanged from 0001032975-17-000053:mdna:163]

[0001032975-18-000007:mdna:176]
[same as prior period, unchanged from 0001032975-17-000053:mdna:164]

[0001032975-18-000007:mdna:177]
Logitech Europe S.A., one of our wholly-owned subsidiaries, guaranteed payments of two third-party contract manufacturers' purchase obligations. As of December 31, 2017, the maximum amount of this guarantee was $3.8 million, of which $1.7 million of guaranteed purchase obligations were outstanding.

[0001032975-18-000007:mdna:178]
[same as prior period, unchanged from 0001032975-17-000053:mdna:166]

[0001032975-18-000007:mdna:179]
We indemnify certain suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of December 31, 2017, no amounts have been accrued for indemnification provisions. We do not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under our indemnification arrangements.

[0001032975-18-000007:mdna:180]
We also indemnify our current and former directors and certain current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. We are unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not capped, the obligations are conditional in nature, and the facts and circumstances involved in any situation that might arise are variable.

[0001032975-18-000007:mdna:181]
The stock purchase agreement that we entered into in connection with the investment by three venture capital firms in Lifesize contains representations, warranties and covenants of Logitech and Lifesize to the Investors. Subject to certain limitations, we have agreed to indemnify the Investors and certain persons related to the Investors for certain losses resulting from breaches of or inaccuracies in such representations, warranties and covenants as well as certain other obligations, including third-party expenses, restructuring costs and pre-closing tax obligations of Lifesize.

[0001032975-18-000007:mdna:182]
Legal Proceedings

[0001032975-18-000007:mdna:183]
From time to time we are involved in claims and legal proceedings that arise in the ordinary course of our business. We are currently subject to several such claims and a small number of legal proceedings. We believe that these matters lack merit and we intend to vigorously defend against them. Based on currently available information, we do not believe that resolution of pending matters will have a material adverse effect on our financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that our defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on our business, financial condition, cash flows and results of operations in a particular period. Any claims or proceedings against us, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect our business.

[0001032975-18-000007:mdna:184]
42
