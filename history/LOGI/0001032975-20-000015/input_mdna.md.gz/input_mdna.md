# LOGI MD&A — 0001032975-20-000015


## mdna

[0001032975-20-000015:mdna:1]
ITEM 7.    MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001032975-20-000015:mdna:2]
Overview of Our Company

[0001032975-20-000015:mdna:3]
Logitech is a world leader in designing, manufacturing and marketing products that help connect people to digital and cloud experiences. More than 35 years ago, Logitech created products to improve experiences around the personal computer (PC) platform, and today it is a multi-brand, multi-category company designing products that enable better experiences consuming, sharing and creating digital content such as computing, gaming, video and music, whether it is on a computer, mobile device or in the cloud. Logitech's brands include Logitech, Logitech G, ASTRO Gaming, Streamlabs, Ultimate Ears, Jaybird, and Blue Microphones. Our Company's website is www.logitech.com.

[0001032975-20-000015:mdna:4]
Our products participate in five large market opportunities: Creativity & Productivity, Gaming, Video Collaboration, Music and Smart Home. We sell our products to a broad network of domestic and international customers, including direct sales to retailers and e-tailers, and indirect sales through distributors. Our worldwide channel network includes consumer electronics distributors, retailers, mass merchandisers, specialty stores, computer and telecommunications stores, value-added resellers and online merchants.

[0001032975-20-000015:mdna:5]
From time to time, we may seek to partner with or acquire when appropriate companies that have products, personnel, and technologies that complement our strategic direction. We continually review our product offerings and our strategic direction in light of our profitability targets, competitive conditions, changing consumer trends and the evolving nature of the interface between the consumer and the digital world.

[0001032975-20-000015:mdna:6]
On October 31, 2019, the Company acquired all equity interests in General Workings, Inc. (Streamlabs) for a total consideration of $105.7 million, which included a working capital adjustment, plus additional contingent consideration of $29.0 million payable in stock only upon the achievement of certain net revenues for the period beginning on January 1, 2020 and ending on June 30, 2020 (the Streamlabs Acquisition). Streamlabs is a leading provider of software and tools for professional streamers. The Streamlabs Acquisition is complementary to the Company's gaming portfolio.

[0001032975-20-000015:mdna:7]
On August 21, 2018, we acquired all equity interests in Blue Microphones Holding Corporation (Blue Microphones) for a total consideration of $134.8 million in cash, which included a working capital adjustment and repayment of debt on behalf of Blue Microphones (the Blue Microphones Acquisition). Blue Microphones is a leading audio manufacturer that designs and produces microphones, headphones, recording tools, and accessories for audio professionals, musicians and consumers. The Blue Microphones Acquisition supplements our product portfolio.

[0001032975-20-000015:mdna:8]
Impacts of COVID-19 to Our Business

[0001032975-20-000015:mdna:9]
In March 2020, the World Health Organization declared the outbreak of a novel coronavirus ("COVID-19") as a pandemic, which continues to spread throughout the world. The spread of COVID-19 has caused public health officials to recommend precautions to mitigate the spread of the virus and, in certain markets in which we operate, government authorities have issued orders that require the closure of non-essential businesses and people to be quarantined or to shelter-at-home. The COVID-19 pandemic has significantly curtailed global economic activity, caused significant volatility and disruption in global financial and commercial markets, and is likely to lead to recessionary conditions for an indeterminate amount of time. We are conducting our business with substantial modifications, such as employee work locations and virtualization among other changes. We are continuing to actively monitor the situation and may take further actions that alter our business operations as may be required by federal, state or local authorities in the countries in which we operate, or that we determine are in the best interest of our employees, customers, partners, suppliers or shareholders. It is not clear what the potential effects of COVID-19 or any such modifications or alterations may have on our business, results of operations, financial operations, financial condition and stock price.

[0001032975-20-000015:mdna:10]
During February 2020, following the initial outbreak of COVID-19 in China, we experienced disruptions to our manufacturing, supply chain and logistics services, resulting in temporary inventory declines and an increase in logistics costs. We expect the increased logistics costs and adverse effects on our gross margins from COVID-19 to continue at least during the first half of fiscal year 2021. However, due to the ongoing shelter-at-home requirements or recommendations in many countries, there was high demand and consumption of our products. It is difficult to predict the progression, the duration and all of the effects of COVID-19, when business closure and shelter at home guidelines may be eased or lifted, and how consumer demand, inventory and logistical effects and costs may evolve over time, or the impact on our future sales and results of operations. Some of this impact will undoubtedly occur over multiple financial periods and may have a lag effect between periods, such as what we are able to manufacture in one period affecting sales, channel inventory or logistics costs in subsequent periods. The full extent of the impact of COVID-19 on our business and our operational and financial performance is currently uncertain and will depend on many factors outside our control. For additional information, see "Liquidity and Capital resources" below and "Item IA: Risk Factors", including under the caption "The full effect of the COVID-19 pandemic is uncertain and cannot be predicted, and the Company's business, results of operations and financial condition could be adversely affected by the COVID-19 pandemic."

[0001032975-20-000015:mdna:11]
Summary of Financial Results

[0001032975-20-000015:mdna:12]
Our total sales for fiscal year 2020 increased 7% in comparison to fiscal year 2019. The growth was broad-based across our regions and across most of our product categories. The results of operations for Streamlabs have been included in our consolidated statements of operations from the acquisition date.

[0001032975-20-000015:mdna:13]
Sales for fiscal year 2020 increased 8%, 9% and 2% in the Americas, EMEA and Asia Pacific, respectively, in comparison to fiscal year 2019.

[0001032975-20-000015:mdna:14]
Gross margin increased by 50 basis points to 37.7% during fiscal year 2020, compared to fiscal year 2019. The increase in gross margin was primarily driven by favorable product mix and benefits from cost savings and operational efficiencies, partially offset by unfavorable currency exchange rates, an increase in U.S.-China tariffs and COVID-19 related costs primarily due to disruptions and higher costs in our manufacturing, supply chain and logistics operations and outsourced services.

[0001032975-20-000015:mdna:15]
Operating expenses for fiscal year 2020 were $845.9 million, or 28.4% of sales, compared to $773.8 million, or 27.8% of sales, for fiscal year 2019. The increase in operating expenses was primarily driven by $39.0 million higher personnel-related costs due to additional headcount from business acquisitions as well as from S&M and R&D departments to support business growth, $13.9 million higher third-party costs primarily in S&M and R&D to support our long-term growth opportunities, $3.3 million higher amortization of intangible assets from the business acquisitions, and a $23.2 million change in fair value of contingent consideration from the Streamlabs Acquisition, partially offset by a decrease of $11.2 million in restructuring charges as we substantially completed our restructuring plan in the first quarter of fiscal year 2020.

[0001032975-20-000015:mdna:16]
Income tax benefit for fiscal year 2020 was impacted by $153.2 million from the measurement of deferred tax assets and liabilities, net of assessment of uncertain tax positions in Switzerland as a result of the enactment of TRAF in the canton of Vaud in Switzerland during the fourth quarter of fiscal year 2020.

[0001032975-20-000015:mdna:17]
Net income for fiscal year 2020 was $449.7 million, compared to $257.6 million for fiscal year 2019.

[0001032975-20-000015:mdna:18]
Trends in Our Business

[0001032975-20-000015:mdna:19]
Our products participate in five large multi-category market opportunities, including Creativity & Productivity, Gaming, Video Collaboration, Music and Smart Home. We see opportunities to deliver growth with products in all these markets. The following discussion represents key trends specific to our market opportunities.

[0001032975-20-000015:mdna:20]
Trends Specific to Our Five Market Opportunities

[0001032975-20-000015:mdna:21]
Creativity & Productivity:  New PC shipments remain lackluster but the installed base of PC users remains large. We believe that innovative PC peripherals, such as our mice and keyboards, can renew the PC usage experience, thus providing growth opportunities. Increasing adoption of various cloud-based applications has led to multiple unique consumer use cases, which we are addressing with our innovative product portfolio and a deep understanding of our customer base. The increasing popularity of streaming and broadcasting, as well as the rising work-from-home trend, provides additional growth opportunities for our webcam products, as well as other products in our portfolio. Smaller mobile computing devices, such as tablets, have created new markets and usage models for peripherals and accessories. We offer a number of products to enhance the use of mobile devices, including a

[0001032975-20-000015:mdna:22]
combo backlit keyboard case for the iPad Pro and keyboard folios for other iPad models. In fiscal year 2020, we achieved our third consecutive year of growth in our Tablet & Other Accessories category.

[0001032975-20-000015:mdna:23]
Gaming:  The PC gaming and console gaming platforms continue to show strong structural growth opportunities as online gaming, multi-platform experiences, and esports gain greater popularity and gaming content becomes increasingly more demanding and social. In fiscal year 2020, the gaming headset market has declined due to challenging comparisons against the launch of the game Fortnite in fiscal year 2019, which boosted gaming product market demand in fiscal year 2019. The new console refresh cycle during the holiday season of 2020 is expected to drive subsequent growth opportunities for our ASTRO family of headsets and controllers. We believe Logitech is well positioned to benefit from the overall gaming market growth. With ASTRO Gaming, we also strengthened our portfolio in adjacent categories, such as the console controller market. Our recent acquisition of Streamlabs provides a solid platform to deliver recurring services and subscriptions to gamers.

[0001032975-20-000015:mdna:24]
Video Collaboration: The near and long-term structural growth opportunities in the video collaboration market have never been more relevant than in today’s environment, as commercial and consumer adoption of video has seen explosive growth in recent months. Video meetings are on the rise, and companies increasingly want lower-cost, cloud-based solutions that can provide their employees with the ability to work from anywhere. We are continuing our efforts to create and sell innovative products to accommodate the increasing demand from medium and large-sized meeting rooms to small-sized rooms such as huddle rooms. We will continue to invest in select business-specific products (both hardware and software), targeted product marketing and sales channel development.

[0001032975-20-000015:mdna:25]
Music:  The mobile speaker market has remained weak, although the consumption of music continues to grow. The integration of personal voice assistants has become increasingly competitive in the speaker categories, but the market for third-party, voice-enabled speakers has not yet gained traction. Moreover, the market for mobile speakers appears to be maturing, which led to a decline in Ultimate Ears sales in the past two years. In fiscal year 2020, the wireless headphone industry continued to flourish with strong revenue growth. The largest growth was in true wireless headphones where the market tripled year-over-year while traditional wireless headphones have declined significantly. Continued growth in the wireless headphone market is expected for the next several years as consumers increasingly adopt wireless headphones over wired headphones. With Blue Microphones, we strengthened our portfolio in adjacent categories, such as the microphones market.

[0001032975-20-000015:mdna:26]
Smart Home:  Our remote business declined substantially in fiscal year 2020, offset by growth in our Circle 2 family of security cameras. In general, the space is under pressure as the way people consume content is changing. We will continue to explore other innovative experiences for the Smart Home category.

[0001032975-20-000015:mdna:27]
Business Seasonality, Product Introductions and Business Acquisitions

[0001032975-20-000015:mdna:28]
We have historically experienced higher sales in our third fiscal quarter ending December 31, compared to other fiscal quarters in our fiscal year, primarily due to the increased consumer demand for our products during the year-end holiday buying season and year-end spending by enterprises. Additionally, new product introductions and business acquisitions can significantly impact sales, product costs and operating expenses. Product introductions can also impact our sales to distribution channels as these channels are filled with new product inventory following a product introduction, and often channel inventory of an earlier model product declines as the next related major product launch approaches. Sales can also be affected when consumers and distributors anticipate a product introduction or changes in business circumstances. However, neither historical seasonal patterns nor historical patterns of product introductions should be considered reliable indicators of our future pattern of product introductions, future sales or financial performance. Furthermore, cash flow is correspondingly lower as we typically build inventories in advance for the third quarter and we pay an annual dividend following our Annual General Meeting, which is typically in September.

[0001032975-20-000015:mdna:29]
Swiss Federal Tax Reform

[0001032975-20-000015:mdna:30]
As we described above, the canton of Vaud in Switzerland enacted TRAF on March 10, 2020 which took effect as of January 1, 2020. Our cash tax payments have increased in Switzerland beginning in fiscal year 2020 as a result of our transition out of our longstanding tax ruling from the canton of Vaud.

[0001032975-20-000015:mdna:31]
Critical Accounting Estimates

[0001032975-20-000015:mdna:32]
The preparation of financial statements and related disclosures in conformity with U.S. GAAP requires us to make judgments, estimates, and assumptions that affect reported amounts of assets, liabilities, sales and expenses, and the disclosure of contingent assets and liabilities.

[0001032975-20-000015:mdna:33]
We consider an accounting estimate critical if it: (i) requires management to make judgments and estimates about matters that are inherently uncertain; and (ii) is important to an understanding of our financial condition and operating results.

[0001032975-20-000015:mdna:34]
We base our estimates on historical experience and on various other assumptions we believe to be reasonable under the circumstances. Although these estimates are based on management's best knowledge of current events and actions that may impact us in the future, actual results could differ from those estimates. Management has discussed the development, selection and disclosure of these critical accounting estimates with the Audit Committee of the Board of Directors.

[0001032975-20-000015:mdna:35]
We believe the following accounting estimates are most critical to our business operations and to an understanding of our financial condition and results of operations and reflect the more significant judgments and estimates used in the preparation of our consolidated financial statements.

[0001032975-20-000015:mdna:36]
Accruals for Customer Programs and Product Returns

[0001032975-20-000015:mdna:37]
We record accruals for cooperative marketing, customer incentive, pricing programs (Customer Programs) and product returns. The estimated cost of these programs is usually recorded as a reduction of revenue. Significant management judgments and estimates must be used to determine the cost of these programs in any accounting period. Certain Customer Programs require management to estimate the percentage of those programs that will not be claimed or will not be earned by customers based on historical experience and on the specific terms and conditions of particular programs. The percentage of these customer programs that will not be claimed or earned is commonly referred to as "breakage". If we receive a separately identifiable benefit from a customer and can reasonably estimate the fair value of that benefit, the cost of the Customer Programs is recognized in operating expenses.

[0001032975-20-000015:mdna:38]
Cooperative Marketing Arrangements.    We enter into customer marketing programs with many of our customers, and with certain indirect partners, allowing customers to receive a credit equal to a set percentage of their purchases of our products, or a fixed dollar credit for various marketing programs. The objective of these arrangements is to encourage advertising and promotional events by our customers to increase sales of our products.

[0001032975-20-000015:mdna:39]
Customer Incentive Programs.    Customer incentive programs include performance-based incentives and consumer rebates. We offer performance-based incentives to our customers and indirect partners based on pre-determined performance criteria. Consumer rebates are offered from time to time at our discretion for the primary benefit of end-users.

[0001032975-20-000015:mdna:40]
Cooperative marketing arrangements and customer incentive programs are considered variable consideration, which we estimate and record as a reduction to revenue at the time of sale based on negotiated terms, historical experiences, forecasted incentives, the anticipated volume of future purchases, and inventory levels in the channel.

[0001032975-20-000015:mdna:41]
Pricing Programs.    We have agreements with certain customers that contain terms allowing price protection credits to be issued in the event of a subsequent price reduction. At our discretion, we also offer special pricing discounts to certain customers. Special pricing discounts are usually offered only for limited time periods or for sales of selected products to specific indirect partners. Our decision to make price reductions is influenced by product life cycle stage, market acceptance of products, the competitive environment, new product introductions and other factors. Accruals for estimated expected future pricing actions are recognized at the time of sale based on analysis of historical pricing actions by customer and by product, inventories owned by and located at distributors and retailers, current customer demand, current operating conditions, and other relevant customer and product information, such as stage of product life-cycle.

[0001032975-20-000015:mdna:42]
Product Returns.    We grant limited rights to return products. Return rights vary by customer and range from just the right to return the defective product to stock rotation rights limited to a percentage of sales approved by management. Estimates of expected future product returns are recognized at the time of sale based on analyses of historical return trends by the customer and by product, inventories owned by and located at customers, current customer demand, current operating conditions, and other relevant customer and product information. Upon recognition, we reduce sales and cost of goods sold for the estimated return. Return trends are influenced by product life cycle status, new product introductions, market acceptance of products, sales levels, product sell-through, the type of customer, seasonality, product quality issues, competitive pressures, operational policies and procedures, and other factors. Return rates can fluctuate over time but are sufficiently predictable to allow us to estimate expected future product returns.

[0001032975-20-000015:mdna:43]
We apply a breakage rate to reduce our accruals of Customer Programs based on the estimated percentage of these customer programs that will not be claimed or earned. The breakage rate is applied at the time of sale. Significant management judgments and estimates are used to determine the breakage of the programs in any accounting period.

[0001032975-20-000015:mdna:44]
We regularly evaluate the adequacy of our accruals for Customer Programs and product returns. Future market conditions and product transitions may require us to take action to increase such programs. In addition, when the variables used to estimate these costs change, or if actual costs differ significantly from the estimates, we would be required to record incremental increases or reductions to revenue or operating expenses.

[0001032975-20-000015:mdna:45]
Inventory Valuation

[0001032975-20-000015:mdna:46]
We must order components for our products and build inventory in advance of customer orders. Further, our industry is characterized by rapid technological change, short-term customer commitments and rapid changes in demand.

[0001032975-20-000015:mdna:47]
We record inventories at the lower of cost and net realizable value and record write-downs of inventories that are obsolete or in excess of anticipated demand or net realizable value. A review of inventory is performed each fiscal quarter that considers factors including the marketability and product lifecycle stage, product development plans, component cost trends, historical sales, and demand forecasts that consider the assumptions about future demand and market conditions. Inventory on hand that is not expected to be sold or utilized is considered excess, and we recognize the write-down in the cost of goods sold at the time of such determination. The write-down is determined by the excess of cost over net realizable value. Net realizable value is the estimated selling price in the ordinary course of business, less reasonably predictable costs of completion, disposal and transportation. At the time of loss recognition, new cost basis per unit and the lower-cost basis for that inventory are established and subsequent changes in facts and circumstances would not result in an increase in the cost basis. If there is an abrupt and substantial decline in demand for Logitech's products or an unanticipated change in technological or customer requirements, we may be required to record additional write-downs that could adversely affect gross margins in the period when the write-downs are recorded.

[0001032975-20-000015:mdna:48]
Share-Based Compensation Expense

[0001032975-20-000015:mdna:49]
The grant date fair value for stock options and stock purchase rights is estimated using the Black-Scholes-Merton option-pricing valuation model. The grant date fair value of restricted stock units (RSUs) that vest upon meeting certain market conditions is estimated using the Monte-Carlo simulation method. The grant date fair value of time-based RSUs and RSUs with performance conditions is calculated based on the closing market price on the date of grant, adjusted by estimated dividends yield prior to vesting.

[0001032975-20-000015:mdna:50]
Our estimates of share-based compensation expense require a number of complex and subjective assumptions including our stock price volatility, the probability of achievement of the set performance conditions, dividend yield, related tax effects, and the selection of an appropriate fair value model. We estimate expected share price volatility based on historical volatility using daily prices over the term of options, RSUs or purchase offerings, as we consider historical share price volatility as most representative of future volatility. The dividend yield assumption is based on our history and expectations of future dividend payouts.

[0001032975-20-000015:mdna:51]
The assumptions used in calculating the fair value of share-based compensation expense and related tax effects represent our best estimates, but these estimates involve inherent uncertainties and the application of management judgments. As a result, if factors change and we use different assumptions, or if we decide to use a different valuation model, our share-based compensation expense could be materially different in the future from what we have recorded in the current period, which could materially affect our results of operations.

[0001032975-20-000015:mdna:52]
Accounting for Income Taxes

[0001032975-20-000015:mdna:53]
We operate in multiple jurisdictions and our profits are taxed pursuant to the tax laws of these jurisdictions. Our effective income tax rate may be affected by the changes in or interpretations of tax laws and tax agreements in any given jurisdiction, utilization of net operating loss and tax credit carryforwards, changes in geographical mix of income and expense, and changes in our assessment of matters such as the ability to realize deferred tax assets. As a result of these considerations, we must estimate income taxes in each of the jurisdictions in which we operate. This process involves estimating current tax exposure together with assessing temporary differences resulting from the different treatment of items for tax and accounting purposes. These differences result in deferred tax assets and liabilities, which are included in the consolidated balance sheet.

[0001032975-20-000015:mdna:54]
We assess the likelihood that our deferred tax assets will be recovered from future taxable income, considering all available evidence such as historical levels of income, expectations and risks associated with estimates of future taxable income and ongoing prudent and feasible tax strategies. When we determine that it is not more likely than not that we will realize all or part of our deferred tax assets, an adjustment is charged to earnings in the period when such determination is made. Likewise, if we later determine that it is more likely than not that all or a part of our deferred tax assets would be realized, the previously provided valuation allowance would be reversed.

[0001032975-20-000015:mdna:55]
We make certain estimates and judgments about the application of tax laws, the expected resolution of uncertain tax positions and other matters surrounding the recognition and measurement of uncertain tax benefits. In the event that uncertain tax positions are resolved for amounts different than our estimates, or the related statutes of limitations expire without the assessment of additional income taxes, we will be required to adjust the amounts of the related assets and liabilities in the period in which such events occur. Such adjustments may have a material impact on our income tax provision and our results of operations.

[0001032975-20-000015:mdna:56]
Goodwill Impairment Analysis

[0001032975-20-000015:mdna:57]
We conduct a goodwill impairment analysis annually at December 31 or more frequently if indicators of impairment exist or if a decision is made to sell or exit a business. Refer to Note 11 to the consolidated financial statements included in this Annual Report on Form 10-K for the disclosures. Significant judgments are involved in determining if an indicator of impairment has occurred. Such indicators may include deterioration in general economic conditions, negative developments in equity and credit markets, adverse changes in the markets in which an entity operates, increases in input costs that have a negative effect on earnings and cash flows, a trend of negative or declining cash flows, a decline in actual or planned revenue or earnings compared with actual and projected results of relevant prior periods, or other relevant entity-specific events such as changes in management, key personnel, strategy or customers, contemplation of bankruptcy, or litigation. The fair value that could be realized in an actual transaction may differ from that used to evaluate the impairment of goodwill.

[0001032975-20-000015:mdna:58]
In reviewing goodwill for impairment, we have the option to first assess qualitative factors to determine whether the existence of events or circumstances leads to a determination that it is more likely than not (greater than 50%) that the estimated fair value of a reporting unit is less than its carrying amount. For the year ended March 31, 2020, we elected to perform a qualitative assessment and determined that impairment was not more likely than not and no further analysis was required. We also may elect not to perform the qualitative assessment and, instead, proceed directly to the quantitative impairment test. The ultimate outcome of the goodwill impairment review for a reporting unit should be the same whether an entity chooses to perform the qualitative assessment or proceeds directly to the quantitative impairment test. Goodwill is allocated among and evaluated for impairment at the reporting unit level, which is defined as an operating segment or one level below an operating segment. We currently have only one reporting unit.

[0001032975-20-000015:mdna:59]
Product Warranty Accrual

[0001032975-20-000015:mdna:60]
We estimate the cost of product warranties at the time the related revenue is recognized based on historical and projected warranty claim rates, historical and projected costs, and knowledge of specific product failures that are outside of our typical experience. Each fiscal quarter, we reevaluate estimates to assess the adequacy of recorded warranty liabilities. When we experience changes in warranty claim activity or costs associated with fulfilling those claims, the warranty liability is adjusted accordingly. If actual product failure rates or repair costs differ from estimates, revisions to the estimated warranty liabilities would be required and could materially affect our results of operations.

[0001032975-20-000015:mdna:61]
Business Acquisitions

[0001032975-20-000015:mdna:62]
Accounting for business acquisitions requires us to make significant estimates and assumptions, especially at the acquisition date with respect to tangible and intangible assets acquired and liabilities assumed and pre-acquisition contingencies. We use our best estimates and assumptions to accurately assign fair value to the tangible and intangible assets acquired and liabilities assumed at the acquisition date.

[0001032975-20-000015:mdna:63]
Examples of critical estimates in valuing certain intangible assets and goodwill we have acquired and liabilities we have assumed include but are not limited to:

[0001032975-20-000015:mdna:64]
| • | assumptions regarding royalty rate range and forecasted revenue growth rate; |

[0001032975-20-000015:mdna:65]
| • | assumptions regarding the estimated useful life of the acquired intangibles; |

[0001032975-20-000015:mdna:66]
| • | discount rates; |

[0001032975-20-000015:mdna:67]
| • | projected risk-based net revenues forecast; and |

[0001032975-20-000015:mdna:68]
| • | asset volatility. |

[0001032975-20-000015:mdna:69]
Unanticipated events and circumstances may occur that may affect the accuracy or validity of such assumptions, estimates or actual results.

[0001032975-20-000015:mdna:70]
The economic useful life of the developed technology from the business acquisitions was determined based on the technology cycle related to developed technology of existing products, as well as the cash flows over the forecasted periods.

[0001032975-20-000015:mdna:71]
The economic useful life of the customer relationships from the business acquisitions was determined based on historical customer turnover rates and the industry benchmarks.

[0001032975-20-000015:mdna:72]
The economic useful life of the trademarks and trade names from the business acquisitions was determined based on the expected life of the trade names and the cash flows anticipated over the forecasted periods.

[0001032975-20-000015:mdna:73]
Adoption of New Accounting Pronouncements

[0001032975-20-000015:mdna:74]
Refer to Note 2 to the consolidated financial statements included in this Annual Report on Form 10-K for recent accounting pronouncements adopted and to be adopted.

[0001032975-20-000015:mdna:75]
Constant Currency

[0001032975-20-000015:mdna:76]
We refer to our net sales growth rates excluding the impact of currency exchange rate fluctuations as "constant currency" sales growth rates. Percentage of constant currency sales growth is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales.

[0001032975-20-000015:mdna:77]
Given our global sales presence and the reporting of our financial results in U.S. Dollars, our financial results could be affected by significant shifts in currency exchange rates. See “Results of Operations” for information on the effect of currency exchange results on our sales. If the U.S. Dollar appreciates or depreciates in comparison to other currencies in future periods, this will affect our results of operations in future periods as well.

[0001032975-20-000015:mdna:78]
Reference to Sales

[0001032975-20-000015:mdna:79]
The term “sales” means net sales, except as otherwise specified and the sales growth discussion and sales growth rate percentages are in U.S. Dollars, except as otherwise specified.

[0001032975-20-000015:mdna:80]
Results of Operations

[0001032975-20-000015:mdna:81]
Net Sales

[0001032975-20-000015:mdna:82]
During fiscal year 2020, sales increased 7% in comparison to fiscal year 2019. If currency exchange rates had been constant in 2020 and 2019, our constant currency sales growth rate would have been 9%. We grew across most of our product categories, with double-digit growth in our Video Collaboration product category and strong growth in Keyboards & Combos, PC Webcams, and Gaming. Sales declined for Mobile Speakers and Smart Home product categories.

[0001032975-20-000015:mdna:83]
During fiscal year 2019, sales increased 9% in comparison to fiscal year 2018. If currency exchange rates had been constant in 2019 and 2018, our constant currency sales growth rate would have been 10%. We grew across most of our product categories, with double digits growth in our Gaming, Video Collaboration and Tablet & Other Accessories product categories and strong growth in Keyboards and Combos. Sales declined for Mobile Speakers and Smart Home product categories. Blue Microphones contributed approximately 2 percentage points to the net sales growth. The adoption of Topic 606 increased our sales for fiscal year 2019 by $3.7 million.

[0001032975-20-000015:mdna:84]
Sales Denominated in Other Currencies

[0001032975-20-000015:mdna:85]
Although our financial results are reported in U.S. Dollars, a portion of our sales was generated in currencies other than the U.S. Dollar, such as the Euro, Chinese Yuan, Japanese Yen, Canadian Dollar, Taiwan Dollar, British Pound and Australian Dollar. For each of the fiscal years 2020, 2019 and 2018, 50% of our sales were denominated in currencies other than the U.S. Dollar.

[0001032975-20-000015:mdna:86]
Sales by Region

[0001032975-20-000015:mdna:87]
The following table presents the change in sales by region for fiscal year 2020 compared with fiscal year 2019, and fiscal year 2019 compared with fiscal year 2018:

[0001032975-20-000015:mdna:88]
|  |  | 2020 vs. 2019 |  | 2019 vs. 2018 |
|  |  | Sales Growth Rate |  | Sales Growth Rate in Constant Currency |  | Sales Growth Rate |  | Sales Growth Rate in Constant Currency |
| Americas |  | 8 | % |  | 8 | % |  | 6 | % |  | 7 | % |
| EMEA |  | 9 |  |  | 13 |  |  | 5 |  |  | 7 |  |
| Asia Pacific |  | 2 |  |  | 4 |  |  | 17 |  |  | 19 |  |

[0001032975-20-000015:mdna:89]
Americas

[0001032975-20-000015:mdna:90]
The increase in sales in fiscal year 2020 of 8% compared with fiscal year 2019 was driven by growth in Video Collaboration, Keyboards and Combos, Tablet & Other Accessories, Audio PC & Wearables, Gaming, Pointing Devices, and PC Webcams, partially offset by sales declines in Mobile Speakers and Smart Home.

[0001032975-20-000015:mdna:91]
The increase in sales in fiscal year 2019 of 6% compared with fiscal year 2018 was driven by growth in Gaming, Video Collaboration, Audio PC & Wearables, Keyboards and Combos, Tablet & Other Accessories and PC Webcams, partially offset by sales declines in Mobile Speakers, Smart Home and Pointing Devices.

[0001032975-20-000015:mdna:92]
EMEA

[0001032975-20-000015:mdna:93]
The increase in sales in fiscal year 2020 of 9% compared with fiscal year 2019 was driven by several of our product categories, with strength in Video Collaboration, Gaming, Mobile Speakers, and PC Webcams, partially offset by sales declines in  Smart Home and Audio PC & Wearables.

[0001032975-20-000015:mdna:94]
The increase in sales in fiscal year 2019 of 5% compared with fiscal year 2018 was driven by several of our product categories, with strength in Video Collaboration, Gaming, Pointing Devices and Tablet & Other Accessories, partially offset by sales declines in Mobile Speakers and Smart Home.

[0001032975-20-000015:mdna:95]
Asia Pacific

[0001032975-20-000015:mdna:96]
The increase in sales in fiscal year 2020 of 2% compared with fiscal year 2019 was primarily driven by sales increases in Video Collaboration, Gaming, Keyboards and Combos and PC Webcams, partially offset by sales declines in Mobile Speakers, Audio PC & Wearables and Tablet and Other Accessories.

[0001032975-20-000015:mdna:97]
The increase in sales in fiscal year 2019 of 17% compared with fiscal year 2018 was primarily driven by sales increases in Video Collaboration, Keyboard & Combos and Pointing Devices, offset by sales declines in Mobile Speakers.

[0001032975-20-000015:mdna:98]
Sales by Product Categories

[0001032975-20-000015:mdna:99]
Sales by product categories for fiscal years 2020, 2019 and 2018 were as follows (Dollars in thousands):

[0001032975-20-000015:mdna:100]
|  |  | Years Ended March 31, |  | Change |
|  |  | 2020 |  | 2019 |  | 2018 |  | 2020 vs. 2019 |  | 2019 vs. 2018 |
| Pointing Devices |  | $ | 544,519 |  |  | $ | 536,890 |  |  | $ | 516,637 |  |  | 1 | % |  | 4 | % |
| Keyboards & Combos |  | 571,720 |  |  | 536,619 |  |  | 498,472 |  |  | 7 |  |  | 8 |  |
| PC Webcams |  | 129,193 |  |  | 121,282 |  |  | 112,147 |  |  | 7 |  |  | 8 |  |
| Tablet & Other Accessories |  | 135,309 |  |  | 128,315 |  |  | 107,942 |  |  | 5 |  |  | 19 |  |
| Video Collaboration |  | 365,616 |  |  | 259,521 |  |  | 182,717 |  |  | 41 |  |  | 42 |  |
| Mobile Speakers |  | 221,791 |  |  | 230,378 |  |  | 314,817 |  |  | (4 | ) |  | (27 | ) |
| Audio & Wearables |  | 273,752 |  |  | 277,429 |  |  | 252,330 |  |  | (1 | ) |  | 10 |  |
| Gaming |  | 690,174 |  |  | 648,130 |  |  | 491,995 |  |  | 6 |  |  | 32 |  |
| Smart Home |  | 43,404 |  |  | 49,344 |  |  | 89,373 |  |  | (12 | ) |  | (45 | ) |
| Other (1) |  | 373 |  |  | 414 |  |  | 433 |  |  | (10 | ) |  | (4 | ) |
| Total Sales |  | $ | 2,975,851 |  |  | $ | 2,788,322 |  |  | $ | 2,566,863 |  |  | 7 |  |  | 9 |  |

[0001032975-20-000015:mdna:101]
| (1) | Other category includes products which we currently intend to phase out, or have already phased out, |

[0001032975-20-000015:mdna:102]
because they are no longer strategic to our business.

[0001032975-20-000015:mdna:103]
Sales by Product Categories:

[0001032975-20-000015:mdna:104]
Creativity & Productivity market:

[0001032975-20-000015:mdna:105]
Pointing Devices

[0001032975-20-000015:mdna:106]
Our Pointing Devices category comprises PC- and Mac-related mice including trackballs touchpads and presenters.

[0001032975-20-000015:mdna:107]
During fiscal year 2020, Pointing Devices sales increased 1%, compared to fiscal year 2019. The increase was primarily driven by the increases in sales of cordless mice, partially offset by a decline in sales of our corded mice and presentation tools.

[0001032975-20-000015:mdna:108]
During fiscal year 2019, Pointing Devices sales increased 4%, compared to fiscal year 2018. The increase was primarily driven by the increases in sales of cordless mice and presentation tools. The increase in cordless mice was led by strong contribution from MX family of premium cordless mice, including the Vertical Wireless Mouse introduced in the second quarter of fiscal year 2019 as well as continued performance for MX Master 2S Wireless Mouse and B220 Silent Mouse.

[0001032975-20-000015:mdna:109]
Keyboards & Combos

[0001032975-20-000015:mdna:110]
Our Keyboards & Combos category comprises PC keyboards, living room keyboards and keyboard/mice combo products.

[0001032975-20-000015:mdna:111]
During fiscal year 2020, Keyboards & Combos sales increased 7%, compared to fiscal year 2019. The increase was primarily driven by an increase in sales of our cordless and corded keyboards and wireless keyboard/mice combos, partially offset by a decline in sales of our living room keyboard products.

[0001032975-20-000015:mdna:112]
During fiscal year 2019, Keyboards & Combos sales increased 8%, compared to fiscal year 2018. The increase was primarily driven by an increase in sales of wireless keyboard/mice combos, mainly from increased sales of our MK 540, MK270 and MK110 wireless combo, and an increase in sales of wireless PC keyboards.

[0001032975-20-000015:mdna:113]
PC Webcams

[0001032975-20-000015:mdna:114]
Our PC Webcams category comprises PC-based webcams targeted primarily at consumers.

[0001032975-20-000015:mdna:115]
During fiscal year 2020, PC Webcams sales increased 7%, compared to fiscal year 2019. The increase was primarily driven by an increase in sales of our Webcam C260, Logitech StreamCam launched in AMR and EMEA in the fourth quarter of fiscal year 2020, and C270i iPTV CAM, partially offset by a decline in sales of our Webcam C170.

[0001032975-20-000015:mdna:116]
During fiscal year 2019, PC Webcams sales increased 8%, compared to fiscal year 2018. The increase was primarily driven by the increases in sales of our HD Pro Webcam C920 and 1080 Pro Stream Webcam.

[0001032975-20-000015:mdna:117]
Tablet & Other Accessories

[0001032975-20-000015:mdna:118]
Our Tablet & Other Accessories category primarily comprises keyboards for tablets.

[0001032975-20-000015:mdna:119]
During fiscal year 2020, Tablet & Other Accessories sales increased 5%, compared to fiscal year 2019. The increase was primarily driven by the introduction of our Slim Folio Pro for the 11" and 12.9" iPad Pro introduced in the first quarter of fiscal year 2020 and sales of our Rugged Combo and Slim Folio for a newer generation of iPads introduced in the third quarter of fiscal year 2020, partially offset by a decline in sales of our Slim Folio for the 2017/2018 iPad and Slim Combos Keyboard cases for 10.5" iPad.

[0001032975-20-000015:mdna:120]
During fiscal year 2019, Tablet & Other Accessories sales increased 19%, compared to fiscal year 2018. The increase was primarily driven by the introduction of our Slim Folio keyboard cases, education-based Rugged Combo 2, Slim Combo keyboard cases, Crayon (a digital pencil) and POWERED (a wireless charging dock for iPhone) during fiscal year 2019.

[0001032975-20-000015:mdna:121]
Gaming market:

[0001032975-20-000015:mdna:122]
Gaming

[0001032975-20-000015:mdna:123]
Our Gaming category comprises gaming mice, keyboards, headsets, gamepads, steering wheels, simulation controllers, console gaming headsets, console gaming controllers, and Streamlabs services.

[0001032975-20-000015:mdna:124]
During fiscal year 2020, Gaming sales increased 6%, compared to fiscal year 2019. The increase was primarily driven by an increase in sales of our gaming mice, gaming keyboards, console gaming controllers, and gaming steering wheels, and sales from Streamlabs services as a result of our business combination (see Note 3 to the consolidated financial statements). The growth was partially offset by a decline in sales of our gaming headsets and console gaming headsets.

[0001032975-20-000015:mdna:125]
During fiscal year 2019, Gaming sales increased 32%, compared to fiscal year 2018. The increase was primarily driven by an increase in sales of our core PC gaming products, and ASTRO console gaming headsets, which benefited from the growing gaming market, growth in eSports, expansions in new channels and regions, and expansion in product portfolios. The increase for fiscal year 2019 was also driven by the fact that the acquisition of ASTRO closed on August 11, 2017, in the middle of our fiscal year 2018 second quarter, resulting in a partial comparative period impact. The growth was partially offset by a slight decline in our simulation products.

[0001032975-20-000015:mdna:126]
Video Collaboration market:

[0001032975-20-000015:mdna:127]
Video Collaboration

[0001032975-20-000015:mdna:128]
Our Video Collaboration category includes Logitech’s ConferenceCams, which combine affordable enterprise-quality audio and high definition (HD) 1080p video to bring video conferencing to businesses of any size.

[0001032975-20-000015:mdna:129]
During fiscal year 2020, Video Collaboration sales increased 41%, compared to fiscal year 2019. The increase was primarily due to increases in sales of our Rally Ultra-HD PTZ Conference Camera, our Tap Touch Controller introduced in the first quarter of fiscal year 2020 and our MeetUp video conference camera, partially offset by a decrease in sales of older generation products.

[0001032975-20-000015:mdna:130]
During fiscal year 2019, Video Collaboration sales increased 42%, compared to fiscal year 2018. The increase was primarily due to an increase in sales for our MeetUp and PTZ Pro 2 video conference cameras, our BRIO Pro Webcam, our C925E Webcam, and the introductions of our Rally and Rally Ultra-HD PTZ Conference Camera in the third quarter of fiscal year 2019.

[0001032975-20-000015:mdna:131]
Music market:

[0001032975-20-000015:mdna:132]
Mobile Speakers

[0001032975-20-000015:mdna:133]
Our Mobile Speakers category is made up entirely of Bluetooth wireless speakers.

[0001032975-20-000015:mdna:134]
During fiscal year 2020, Mobile Speakers sales decreased 4%, compared to fiscal year 2019. The decrease was primarily due to a decline in sales of our WONDERBOOM, BOOM 2, and MEGABLAST, partially offset by sales from the introduction of our WONDERBOOM 2 in the first quarter of fiscal year 2020 and an increase in sales of our BOOM 3.

[0001032975-20-000015:mdna:135]
During fiscal year 2019, Mobile Speakers sales decreased 27%, compared to fiscal year 2018. The decrease was primarily driven by declines in sales of our existing Ultimate Ears speakers. The decrease was partially offset by sales from the introductions of our Ultimate Ears MEGABOOM 3 and BOOM 3 mobile speakers in the second quarter of fiscal year 2019.

[0001032975-20-000015:mdna:136]
Audio & Wearables

[0001032975-20-000015:mdna:137]
Our Audio & Wearables category comprises PC speakers, PC headsets, in-ear headphones, premium wireless audio wearables and studio-quality microphones for professionals and consumers.

[0001032975-20-000015:mdna:138]
During fiscal year 2020, Audio & Wearables sales decreased 1%, compared to fiscal year 2019. The decrease was primarily driven by declines in sales of our PC Speakers and Jaybird traditional wireless products, partially offset by the growth in sales of our Blue Microphones products, as a result of our business combination in the second quarter of fiscal year 2019, and Jaybird True wireless products.

[0001032975-20-000015:mdna:139]
During fiscal year 2019, Audio & Wearables sales increased 10%, compared to fiscal year 2018. The increase was primarily driven by an increase in sales of our corded headsets and sales from Blue Microphones products as a result of our business combination (see Note 3 to the consolidated financial statements), partially offset by a decrease in sales of our PC speakers and Jaybird wireless in-ear headphones.

[0001032975-20-000015:mdna:140]
Smart Home market:

[0001032975-20-000015:mdna:141]
Smart Home

[0001032975-20-000015:mdna:142]
Our Smart Home category mainly comprises our Harmony line of advanced home entertainment controllers and home security cameras.

[0001032975-20-000015:mdna:143]
During fiscal year 2020, Smart Home sales decreased 12%, compared to fiscal year 2019. The decrease was primarily driven by an overall decline in sales in our Harmony remote products, partially offset by an increase in sales of our home security products.

[0001032975-20-000015:mdna:144]
During fiscal year 2019, Smart Home sales decreased 45%, compared to fiscal year 2018. The decrease was primarily due to a decline in sales of our Harmony remotes and home security cameras.

[0001032975-20-000015:mdna:145]
Gross Profit

[0001032975-20-000015:mdna:146]
Gross profit for fiscal years 2020, 2019 and 2018 was as follows (Dollars in thousands):

[0001032975-20-000015:mdna:147]
|  |  | Years Ended March 31, |
|  |  | 2020 |  | 2019 |  | 2018 |
| Net sales |  | $ | 2,975,851 |  |  | $ | 2,788,322 |  |  | $ | 2,566,863 |  |
| Gross profit |  | $ | 1,122,381 |  |  | $ | 1,037,011 |  |  | $ | 909,241 |  |
| Gross margin |  | 37.7 | % |  | 37.2 | % |  | 35.4 | % |

[0001032975-20-000015:mdna:148]
Gross profit consists of sales, less cost of goods sold (which includes materials, direct labor and related overhead costs, costs of manufacturing facilities, royalties, costs of purchasing components from outside suppliers, distribution costs, warranty costs, customer support costs, shipping and handling costs, outside processing costs and write-down of inventories), amortization of intangible assets and purchase accounting effect on inventory.

[0001032975-20-000015:mdna:149]
Gross margin increased by 50 basis points to 37.7% during fiscal year 2020, compared to fiscal year 2019. The increase in gross margin was primarily driven by favorable product mix and benefits from cost savings and operational efficiencies, partially offset by unfavorable currency exchange rates, an increase in U.S.-China tariffs and COVID-19 related costs primarily due to disruptions and higher costs in our manufacturing, supply chain and logistics operations and outsourced services.

[0001032975-20-000015:mdna:150]
Gross margin increased by 180 basis points to 37.2% during fiscal year 2019, compared to fiscal year 2018. The increase in gross margin was primarily driven by favorable product mix and cost reductions. In addition, extra costs incurred due to the transition of the distribution center in North America in the third quarter of fiscal year 2018 negatively affected the gross margin in fiscal year 2018.

[0001032975-20-000015:mdna:151]
Operating Expenses

[0001032975-20-000015:mdna:152]
Operating expenses for fiscal years 2020, 2019 and 2018 were as follows (Dollars in thousands):

[0001032975-20-000015:mdna:153]
|  |  | Years Ended March 31, |
|  |  | 2020 |  | 2019 |  | 2018 |
| Marketing and selling |  | $ | 533,324 |  |  | $ | 488,263 |  |  | $ | 435,489 |  |
| % of sales |  | 17.9 | % |  | 17.5 | % |  | 17.0 | % |
| Research and development |  | 177,593 |  |  | 161,230 |  |  | 143,760 |  |
| % of sales |  | 6.0 | % |  | 5.8 | % |  | 5.6 | % |
| General and administrative |  | 94,015 |  |  | 98,732 |  |  | 96,353 |  |
| % of sales |  | 3.2 | % |  | 3.5 | % |  | 3.8 | % |
| Amortization of intangible assets and acquisition-related costs |  | 17,563 |  |  | 14,290 |  |  | 8,930 |  |
| % of sales |  | 0.6 | % |  | 0.5 | % |  | 0.3 | % |
| Change in fair value of contingent consideration for business acquisition |  | 23,247 |  |  | — |  |  | (4,908 | ) |
| % of sales |  | 0.8 | % |  | — | % |  | (0.2 | )% |
| Restructuring charges (credits), net |  | 144 |  |  | 11,302 |  |  | (116 | ) |
| % of sales |  | — | % |  | 0.4 | % |  | — | % |
| Total operating expenses |  | $ | 845,886 |  |  | $ | 773,817 |  |  | $ | 679,508 |  |
| % of sales |  | 28.4 | % |  | 27.8 | % |  | 26.5 | % |

[0001032975-20-000015:mdna:154]
The increase in total operating expenses during fiscal year 2020, compared to fiscal year 2019, was due to increases in marketing and selling expenses, research and development expenses, fair value of contingent consideration recorded, and amortization of intangible assets from the business acquisitions, offset by decreases in restructuring charges and general and administrative expenses.

[0001032975-20-000015:mdna:155]
The increase in total operating expenses during fiscal year 2019, compared to fiscal year 2018, was due to increases in marketing and selling expenses, research and development expenses, restructuring charges, amortization of intangible assets from the business acquisitions, and a credit from the change in fair value of contingent consideration recorded in fiscal year 2018 for a business acquisition completed in fiscal year 2017.

[0001032975-20-000015:mdna:156]
Marketing and Selling

[0001032975-20-000015:mdna:157]
Marketing and selling expenses consist of personnel and related overhead costs, corporate and product marketing, promotions, advertising, trade shows, technical support for customer experiences and facilities costs.

[0001032975-20-000015:mdna:158]
During fiscal year 2020, marketing and selling expenses increased $45.1 million, compared to fiscal year 2019. The increase was primarily driven by an increase of $36.6 million in personnel-related costs due to increased headcount, partially resulting from the Blue Microphones and Streamlabs acquisitions and increased performance-based variable compensation and an increase of $7.2 million in third-party costs.

[0001032975-20-000015:mdna:159]
During fiscal year 2019, marketing and selling expenses increased $52.8 million, compared to fiscal year 2018. The increase was primarily driven by an increase of $25.4 million in third-party costs including advertising and marketing expenses to support our new products and an increase of $23.9 million in personnel-related costs due to increased headcount, partly due to the Blue Microphones Acquisition and increased performance-based variable compensation.

[0001032975-20-000015:mdna:160]
Research and Development

[0001032975-20-000015:mdna:161]
Research and development expenses consist of personnel and related overhead costs for contractors and outside consultants, supplies and materials, equipment depreciation and facilities costs, all associated with the design and development of new products and enhancements of existing products.

[0001032975-20-000015:mdna:162]
During fiscal year 2020, research and development expenses increased $16.4 million, compared to fiscal year 2019. The increases were primarily driven by an increase of $11.1 million in personnel-related costs due to

[0001032975-20-000015:mdna:163]
increased headcount, partially resulting from the Blue Microphones and Streamlabs acquisitions and an increase of $5.3 million in third-party costs.

[0001032975-20-000015:mdna:164]
During fiscal year 2019, research and development expenses increased $17.5 million, compared to fiscal year 2018. The increase was primarily due to an increase of $9.6 million in personnel-related costs for the development of new products and increased headcount, partially resulting from the Blue Microphones Acquisition, and an increase of $5.8 million in third-party costs.

[0001032975-20-000015:mdna:165]
General and Administrative

[0001032975-20-000015:mdna:166]
General and administrative expenses consist primarily of personnel and related overhead, information technology, and facilities costs for the infrastructure functions such as finance, information systems, executives, human resources and legal.

[0001032975-20-000015:mdna:167]
During fiscal year 2020, general and administrative expenses decreased $4.7 million, compared to fiscal year 2019. The decrease was primarily driven by a decrease of $8.8 million in personnel-related costs, partially offset by an increase of $2.4 million in infrastructure costs.

[0001032975-20-000015:mdna:168]
During fiscal year 2019, general and administrative expenses increased $2.4 million, compared to fiscal year 2018. The increase was primarily due to an increase of $2.8 million in personnel-related costs and an increase of $1.4 million in third-party costs including consulting costs, partially offset by a decrease of $1.9 million in infrastructure costs.

[0001032975-20-000015:mdna:169]
Amortization of Intangibles and Acquisition-Related Costs

[0001032975-20-000015:mdna:170]
Amortization of intangibles included in operating expense and acquisition-related costs during fiscal years 2020, 2019 and 2018 were as follows (in thousands):

[0001032975-20-000015:mdna:171]
|  |  | Years Ended March 31, |
|  |  | 2020 |  | 2019 |  | 2018 |
| Amortization of intangible assets |  | $ | 16,073 |  |  | $ | 12,594 |  |  | $ | 7,518 |  |
| Acquisition-related costs |  | 1,490 |  |  | 1,696 |  |  | 1,412 |  |
| Total |  | $ | 17,563 |  |  | $ | 14,290 |  |  | $ | 8,930 |  |

[0001032975-20-000015:mdna:172]
Amortization of intangible assets consists of amortization of acquired intangible assets, including customer relationships and trademarks and trade names. Acquisition-related costs include legal expense, due diligence costs, and other professional costs incurred for business acquisitions.

[0001032975-20-000015:mdna:173]
The increase in amortization of intangible assets and acquisition-related costs from fiscal year 2019 to 2020 was primarily driven by the intangible assets acquired through the Blue Microphones acquisition in the second quarter of fiscal year 2019 and the Streamlabs Acquisition in the third quarter of fiscal year 2020. The increase in amortization of intangible assets from fiscal year 2018 to 2019 was primarily due to the Blue Microphones Acquisition in fiscal year 2019 and the ASTRO Acquisition in fiscal year 2018.

[0001032975-20-000015:mdna:174]
Change in Fair Value of Contingent Consideration for Business Acquisition

[0001032975-20-000015:mdna:175]
The change in fair value of contingent consideration resulted from the growth in Streamlabs’ net sales since our acquisition and revised projected net sales in the remaining earn-out period.

[0001032975-20-000015:mdna:176]
The change in fair value of contingent consideration for business acquisition during fiscal year 2018 was primarily due to lower-than-expected sales of Jaybird products, and revised projected sales of Jaybird products during the remaining Jaybird Acquisition earn-out period, primarily driven by supply constraints, an evolving product portfolio and changes in the competitive target market.

[0001032975-20-000015:mdna:177]
In October 2017, Logitech and the sellers of Jaybird entered into an agreement fully, irrevocably and unconditionally releasing Logitech from the earn-out rights and payments in exchange for $5.0 million in cash.

[0001032975-20-000015:mdna:178]
Restructuring Charges (Credits)

[0001032975-20-000015:mdna:179]
The following table summarizes restructuring-related activities during fiscal years 2020, 2019 and 2018 from continuing operations (in thousands):

[0001032975-20-000015:mdna:180]
|  |  | Restructuring - Continuing Operations |
|  |  | TerminationBenefits |  | Lease ExitCosts |  | Total |
| Accrual balance at March 31, 2017 |  | $ | 735 |  |  | $ | — |  |  | $ | 735 |  |
| Credits, net |  | (116 | ) |  | — |  |  | (116 | ) |
| Cash payments |  | (619 | ) |  | — |  |  | (619 | ) |
| Accrual balance at March 31, 2018 |  | — |  |  | — |  |  | — |  |
| Charges, net |  | 11,302 |  |  | — |  |  | 11,302 |  |
| Cash payments |  | (6,913 | ) |  | — |  |  | (6,913 | ) |
| Accrual balance at March 31, 2019 |  | 4,389 |  |  | — |  |  | 4,389 |  |
| Charges, net |  | 144 |  |  | — |  |  | 144 |  |
| Cash payments |  | (3,852 | ) |  | — |  |  | (3,852 | ) |
| Accrual balance at March 31, 2020 |  | $ | 681 |  |  | $ | — |  |  | $ | 681 |  |

[0001032975-20-000015:mdna:181]
During the first quarter of fiscal year 2019, we implemented a restructuring plan to streamline and realign our overall organizational structure and reallocate resources to support long-term growth opportunities. In July 2018, the Board of Directors approved additional costs under this restructuring plan, totaling pre-tax charges of approximately $10.0 million to $15.0 million, of which 11.4 million has been recognized cumulatively as of March 31, 2020. The total charges consisted of cash severance and other personnel costs and are presented as restructuring charges (credits), net in the Consolidated Statements of Operations. As of June 30, 2019, the Company had substantially completed this restructuring plan.

[0001032975-20-000015:mdna:182]
The restructuring-related activities for the year ended March 31, 2018 include activities from our restructuring plan implemented in fiscal year 2016.

[0001032975-20-000015:mdna:183]
Interest Income

[0001032975-20-000015:mdna:184]
Interest income for fiscal years 2020, 2019 and 2018 was as follows (in thousands):

[0001032975-20-000015:mdna:185]
|  |  | Years Ended March 31, |
|  |  | 2020 |  | 2019 |  | 2018 |
| Interest Income |  | $ | 9,619 |  |  | $ | 8,375 |  |  | $ | 4,969 |  |

[0001032975-20-000015:mdna:186]
We invest in highly liquid instruments with an original maturity of three months or less at the date of purchase, which are classified as cash equivalents. The increases in interest income for fiscal years 2020 and 2019 compared to the prior periods were both due to higher yield earned on those investments.

[0001032975-20-000015:mdna:187]
Other Income (Expense), Net

[0001032975-20-000015:mdna:188]
Other income and expense for fiscal years 2020, 2019 and 2018 was as follows (in thousands):

[0001032975-20-000015:mdna:189]
|  |  | Years Ended March 31, |
|  |  | 2020 |  | 2019 |  | 2018 |
| Investment income (loss) related to the deferred compensation plan |  | $ | (831 | ) |  | $ | 664 |  |  | $ | 1,386 |  |
| Currency exchange loss, net |  | (909 | ) |  | (3,608 | ) |  | (4,613 | ) |
| Gain on investment, net |  | 39,011 |  |  | 816 |  |  | 669 |  |
| Other |  | 941 |  |  | 1,692 |  |  | 121 |  |
| Total |  | $ | 38,212 |  |  | $ | (436 | ) |  | $ | (2,437 | ) |

[0001032975-20-000015:mdna:190]
Investment income (loss) related to the deferred compensation plan for fiscal years 2020, 2019 and 2018 represents earnings, gains, and losses on trading investments related to a deferred compensation plan offered by one of our subsidiaries.

[0001032975-20-000015:mdna:191]
Currency exchange loss, net relates to balances denominated in currencies other than the functional currency in our subsidiaries, as well as to the sale of currencies, and to gains or losses recognized on currency exchange forward contracts. We do not speculate in currency positions, but we are alert to opportunities to maximize currency exchange gains and minimize currency exchange losses.

[0001032975-20-000015:mdna:192]
Gain on investments, net, represents the realized gain on sales of investment, and unrealized gain (loss) from the fair value change on the available-for-sale securities and equity-method investments during the periods presented. On March 2, 2020, we sold our $5.5 million investment in a privately held company for a total proceeds of $45.3 million consisting of (i) $3.0 million in cash, of which $0.8 million is held in escrow, (ii) a 6% subordinated note with a principal amount of $8.4 million due in 5 years together with the interest, at a fair value of $7.4 million, and (iii) 33.9 million Series A preferred units and 33.9 million Series B common units in Marlin-SL Topco, LP ("Marlin"), representing an ownership interest of approximately 11.8%, with a face value of $33.9 million and fair value of $35.0 million, respectively. As a result, we recognized a gain of $39.8 million in the fourth quarter of fiscal year 2020.

[0001032975-20-000015:mdna:193]
The components of net periodic benefit cost other than the service cost component for the years ended March 31, 2020 and 2019 are included in the line “Other” above as a result of adopting ASU 2017-07 effective April 1, 2018. The impact to the comparative period was immaterial and therefore the prior period statements of operations were not revised.

[0001032975-20-000015:mdna:194]
Provision for (Benefit from) Income Taxes

[0001032975-20-000015:mdna:195]
The provision for (benefit from) income taxes and the effective income tax rate for fiscal years 2020, 2019 and 2018 were as follows (Dollars in thousands):

[0001032975-20-000015:mdna:196]
|  |  | Years Ended March 31, |
|  |  | 2020 |  | 2019 |  | 2018 |
| Provision for (benefit from) income taxes |  | $ | (125,397 | ) |  | $ | 13,560 |  |  | $ | 23,723 |  |
| Effective income tax rate |  | (38.7 | )% |  | 5.0 | % |  | 10.2 | % |

[0001032975-20-000015:mdna:197]
The change in the effective income tax rate between fiscal years 2020 and 2019 was primarily due to the mix of income and losses in the various tax jurisdictions in which we operate and the income tax accounting impact from the enactment of TRAF in the canton of Vaud in Switzerland on March 10, 2020 to take effect as of January 1, 2020.  We have benefited from a longstanding tax ruling from the canton of Vaud through December 31, 2019.  We reached an agreement with the Vaud Tax Administration that would allow for a tax step-up of goodwill to be amortized over ten years beginning on January 1, 2020 as a transition measure. We recorded an income tax benefit of $151.7 million, net of unrecognized tax benefits to account for the book and tax basis difference of the step-up upon enactment.  The deferred income tax benefit from other temporary differences resulting from the Swiss tax reform, net of three-month amortization of the tax step-up amounted to $1.5 million. The aggregate deferred income tax impact in fiscal year 2020 as a result of the enactment of TRAF was $153.2 million.

[0001032975-20-000015:mdna:198]
In addition, we recognized excess tax benefits from share-based payments, net of shortfalls of $6.4 million and $10.1 million in the United States and recognized income tax benefit from the reversal of uncertain tax positions from the expiration of statutes of limitations in the amount of $4.0 million and $2.9 million in fiscal years 2020 and 2019, respectively.

[0001032975-20-000015:mdna:199]
The change in the effective income tax rate between fiscal years 2019 and 2018 was primarily due to the mix of income and losses in the various tax jurisdictions in which we operate and provisional income tax accounting impact from the enactment of H.R.1, also known as the "Tax Cuts and Jobs Act" (the Tax Act) in the United States on December 22, 2017. The Tax Act reduced the corporate income tax rate in the United States from 35% to 21%. We recorded a provisional income tax charge of $21.7 million, net of valuation allowance against tax credits, in fiscal year 2018 to remeasure the deferred tax effects at 21%. Furthermore, we recognized $10.1 million and $13.4 million of excess tax benefits from share-based payments, net of shortfalls, in fiscal years 2019 and 2018, respectively. In the same periods, there were tax benefits of $2.9 million and $8.3 million, respectively, from the reversal of uncertain tax positions from the expiration of statutes of limitations.

[0001032975-20-000015:mdna:200]
As of March 31, 2020 and 2019, the total amounts of unrecognized tax benefits due to uncertain tax positions were $140.8 million and $76.5 million, respectively, all of which would affect the effective income tax rates if recognized.

[0001032975-20-000015:mdna:201]
As of March 31, 2020 and 2019, we had $40.8 million and $36.4 million, respectively, in non-current income taxes payable, including interest and penalties, related to our income tax liability for uncertain tax positions. We recognized $2.0 million, $0.6 million and $0.6 million in interest and penalties related to unrecognized tax positions in income tax expense during fiscal years 2020, 2019 and 2018, respectively. As of March 31, 2020 and 2019, we had $4.5 million and $2.5 million, respectively, of accrued interest and penalties related to uncertain tax positions.

[0001032975-20-000015:mdna:202]
We file Swiss and foreign tax returns. We received final tax assessments in Switzerland through fiscal year 2017. For other foreign jurisdictions such as the United States, we are generally not subject to tax examinations for years prior to fiscal year 2017. We are under examination and have received assessment notices in foreign tax jurisdictions. If the examinations are resolved unfavorably, there is a possibility that they may have a material negative impact on our results of operations.

[0001032975-20-000015:mdna:203]
Liquidity and Capital Resources

[0001032975-20-000015:mdna:204]
Cash Balances, Available Borrowings, and Capital Resources

[0001032975-20-000015:mdna:205]
As of March 31, 2020, we had cash and cash equivalents of $715.6 million, compared with $604.5 million as of March 31, 2019. Our cash and cash equivalents consist of bank demand deposits and short-term time deposits, of which 75% is held in Switzerland and 11% is held in China (including Hong Kong). We do not expect to incur any material adverse tax impact, except for what has been recognized, or be significantly inhibited by any country in which we do business from the repatriation of funds to Switzerland, our home domicile.

[0001032975-20-000015:mdna:206]
As of March 31, 2020, our working capital was $700.3 million, compared with working capital of $632.6 million as of March 31, 2019. The increase in working capital over fiscal year 2019 was primarily due to higher balances of cash and cash equivalents, higher accounts receivable, net, and lower balance of accounts payable, partially offset by lower inventories and higher accrued and other liabilities.

[0001032975-20-000015:mdna:207]
We had several uncommitted, unsecured bank lines of credit aggregating to $81.4 million as of March 31, 2020. There are no financial covenants under these lines of credit with which we must comply. As of March 31, 2020, we had outstanding bank guarantees of $20.7 million under these lines of credit.

[0001032975-20-000015:mdna:208]
The following table presents selected financial information and statistics as of March 31, 2020, 2019 and 2018 (Dollars in thousands):

[0001032975-20-000015:mdna:209]
|  |  | March 31, |
|  |  | 2020 |  | 2019 |  | 2018 |
| Accounts receivable, net |  | $ | 394,743 |  |  | $ | 383,309 |  |  | $ | 214,885 |  |
| Accounts payable |  | $ | 259,120 |  |  | $ | 283,922 |  |  | $ | 293,988 |  |
| Inventories |  | $ | 229,249 |  |  | $ | 293,495 |  |  | $ | 259,906 |  |
| Days sales in accounts receivable (DSO)(Days)(1) |  | 50 |  |  | 55 |  |  | 33 |  |
| Days accounts payable outstanding (DPO) (Days)(2) |  | 54 |  |  | 65 |  |  | 70 |  |
| Inventory turnover (ITO)(x)(3) |  | 7.5 |  |  | 5.3 |  |  | 5.9 |  |

[0001032975-20-000015:mdna:210]
______________________________

[0001032975-20-000015:mdna:211]
| (1) | DSO is determined using ending accounts receivable, net as of the most recent quarter-end and sales for the most recent quarter. |

[0001032975-20-000015:mdna:212]
| (2) | DPO is determined using ending accounts payable as of the most recent quarter-end and cost of goods sold for the most recent quarter. |

[0001032975-20-000015:mdna:213]
| (3) | ITO is determined using ending inventories and the annualized cost of goods sold (based on cost of goods sold for the most recent quarter). |

[0001032975-20-000015:mdna:214]
DSO as of March 31, 2020 decreased by 5 days to 50 days, as compared to 55 days as of March 31, 2019, primarily due to timing of customer payments and sales linearity. DSO as of March 31, 2019 increased by 22 days to 55 days, as compared to 33 days as of March 31, 2018. The adoption of Topic 606 negatively impacted our DSO for the year ended March 31, 2019 by 18 days, mainly as a result of changes in the balance sheet presentation of certain reserve balances previously shown net within accounts receivable which are now presented as accrued and other current liabilities. The adoption of Topic 606 did not have an impact over the total cash flows from operating, investing or financing activities. Timing of sales also increased DSO by four days as of March 31, 2019 relative to the corresponding prior year period.

[0001032975-20-000015:mdna:215]
DPO as of March 31, 2020 decreased 11 days, compared to March 31, 2019, primarily due to less inventory replenishment during the fourth quarter of fiscal year 2020 due to COVID-19 impact and an increase in cost of goods sold due to higher sales growth. DPO as of March 31, 2019 decreased  five days, compared to March 31, 2018, primarily due to the timing of purchases.

[0001032975-20-000015:mdna:216]
ITO as of March 31, 2020 was higher compared to March 31, 2019, primarily due to higher sales growth and lower replenishment in the fourth quarter of fiscal year 2020 due to COVID-19 impact. ITO as of March 31, 2019 was lower compared to March 31, 2018, due to higher inventory related to new product introductions and inventory from the Blue Microphones Acquisition.

[0001032975-20-000015:mdna:217]
If we are not successful in launching and phasing in our new products launched during the current fiscal year, or we are not able to sell the new products at the prices planned, it could have a material impact on our revenue, gross profit margin, operating results including operating cash flow, and inventory turnover in the future.

[0001032975-20-000015:mdna:218]
During fiscal year 2020, we generated $425.0 million in cash from operating activities. Our main sources of operating cash flows were from net income, after deducting the gain on sale of investment in a privately held company, adding back non-cash expenses of depreciation, amortization, share-based compensation expense, change in fair value of contingent considerations, and from changes in operating assets and liabilities. The increase in accounts receivable, net was primarily driven by growth and timing of sales. The decrease in accounts payable was primarily driven by the timing of purchases and inventory supply constraint in the fourth quarter of fiscal year 2020. The decrease in inventories was primarily driven by sales growth and less inventory purchases during the fourth quarter of fiscal year 2020. The increase in accrued and other liabilities was primarily due to higher accrued personnel expenses.

[0001032975-20-000015:mdna:219]
Net cash used in investing activities was $130.2 million, primarily due to $91.6 million of the purchase price (net of cash acquired) for business acquisitions and $39.5 million of purchases of property, plant, and equipment.

[0001032975-20-000015:mdna:220]
Net cash used in financing activities was $176.7 million, primarily due to $124.2 million of cash dividends paid during the year, $50.4 million of repurchases of our registered shares and $24.3 million of tax withholdings related

[0001032975-20-000015:mdna:221]
to net share settlements of restricted stock units, partially offset by $22.2 million in proceeds received from the sale of shares upon exercise of stock options and purchase rights.

[0001032975-20-000015:mdna:222]
Our expenditures for property, plant and equipment during fiscal year 2020 were primarily for tooling and equipment, and computer hardware and software. Our expenditures for property, plant and equipment during fiscal years 2019 and 2018 were primarily for tooling and equipment, computer hardware and software and leasehold improvements. Our expenditures for property, plant and equipment increased during fiscal year 2020, compared to fiscal year 2019, primarily due to higher computer and software and leasehold improvements. Our expenditures for property, plant and equipment decreased during fiscal year 2019, compared to fiscal year 2018, primarily due to a lower amount of tooling purchases.

[0001032975-20-000015:mdna:223]
Our payments for acquisitions, net of cash acquired, during fiscal year 2020 were primarily for the Streamlabs Acquisition. Our payments for acquisitions, net of cash acquired, during fiscal year 2019 were primarily for the Blue Microphones Acquisition (refer to "Note 3 - Business Acquisitions" to the consolidated financial statements). Our payments for acquisitions, net of cash acquired, during fiscal year 2018, were primarily for the ASTRO Acquisition.

[0001032975-20-000015:mdna:224]
The purchases and sales of trading investments during fiscal years 2020, 2019 and 2018 represent mutual fund activity directed by participants in a deferred compensation plan offered by one of our subsidiaries. The mutual funds are held by a Rabbi Trust.

[0001032975-20-000015:mdna:225]
During fiscal year 2020, there was a $7.1 million loss from effect of currency exchange rate changes on cash and cash equivalents, compared to a loss of $10.1 million from effect of currency exchange rate changes during fiscal year 2019, and a $4.7 million gain of currency translation exchange rate effect during fiscal year 2018. The loss from effect of currency rate changes during fiscal year 2020 were primarily due to the weakening of the Euro, Brazilian real and Australian dollar versus the U.S. Dollar by 3%, 25%, and 14%, respectively. The loss from the effect of currency exchange rate changes during fiscal year 2019 were primarily due to the weakening of Euro and Chinese Renminbi versus the U.S. Dollar by 9% and 7%, respectively.

[0001032975-20-000015:mdna:226]
Cash Outlook

[0001032975-20-000015:mdna:227]
Our principal sources of liquidity are our cash and cash equivalents, cash flow generated from operations and, to a much lesser extent, capital markets and borrowings. Our future working capital requirements and capital expenditures may increase to support investments in product innovations and growth opportunities or to acquire or invest in complementary businesses, products, services, and technologies. The future impact of COVID-19 cannot be predicted with certainty and may increase our costs of capital and otherwise adversely affect our business, results of operations, financial conditions and liquidity.

[0001032975-20-000015:mdna:228]
In May 2020, the Board of Directors recommended that we pay cash dividends for fiscal year 2020 of CHF 134.0 million ($138.7 million based on the exchange rate on March 31, 2020). In fiscal year 2020, we paid a cash dividend of CHF 121.8 million (U.S. Dollar amount of $124.2 million) out of fiscal year 2019 retained earnings. In fiscal year 2019, we paid a cash dividend of CHF 110.7 million (U.S. Dollar amount of $114.0 million) out of fiscal year 2018 retained earnings. In fiscal year 2018, we paid a cash dividend of CHF 100.0 million (U.S. Dollar amount of $104.2 million) out of fiscal year 2017 retained earnings.

[0001032975-20-000015:mdna:229]
In May 2020, our Board of Directors approved a new share buyback program, which authorizes us to invest up to $250.0 million to purchase our own shares, following the expiration date of the 2017 share buyback program. Although we enter into trading plans for systematic repurchases (e.g. 10b5-1 trading plans) from time to time, our share buyback program provides us with the opportunity to make opportunistic repurchases during periods of favorable market conditions and is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Opportunistic purchases may be started or stopped at any time without prior notice depending on market conditions and other factors.

[0001032975-20-000015:mdna:230]
In March 2017, our Board of Directors approved the 2017 share buyback program, which authorized us to invest up to $250.0 million to purchase our own shares. As of March 31, 2020, the remaining amount that may be repurchased under the program is $137.4 million. This program expired at the end of April 2020, and there was no share buyback subsequent to March 31, 2020.

[0001032975-20-000015:mdna:231]
For over ten years, we have generated positive cash flows from our operating activities, including cash from operations of $425.0 million, $305.2 million and $346.3 million during fiscal years 2020, 2019, and 2018, respectively. If we do not generate sufficient operating cash flows to support our operations and future planned cash requirements, our operations could be harmed and our access to credit facilities could be restricted or eliminated.

[0001032975-20-000015:mdna:232]
However, we believe that the trend of our historical cash flow generation, our projections of future operations and our available cash balances will provide sufficient liquidity to fund our operations for at least the next 12 months.

[0001032975-20-000015:mdna:233]
Our other contractual obligations and commitments that require cash are described in the following sections.

[0001032975-20-000015:mdna:234]
Contractual Obligations and Commitments

[0001032975-20-000015:mdna:235]
The following table summarizes our contractual obligations and commitments as of March 31, 2020 (in thousands):

[0001032975-20-000015:mdna:236]
|  |  |  |  | Payments Due by Period |
|  |  | March 31, 2020 | <1 year |  | 1-3 years |  | 3-5 years |  | >5 years |
| Inventory purchase commitments |  | $ | 296,539 |  |  | $ | 296,539 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Capital purchase commitments |  | 15,064 |  |  | 15,064 |  |  | — |  |  | — |  |  | — |  |
| Expected contribution to employee benefit plans |  | 5,760 |  |  | 5,760 |  |  | * |  |  | * |  |  | * |  |
| Operating leases obligations |  | 32,367 |  |  | 11,701 |  |  | 15,298 |  |  | 2,507 |  |  | 2,861 |  |
| Total |  | $ | 349,730 |  |  | $ | 329,064 |  |  | $ | 15,298 |  |  | $ | 2,507 |  |  | $ | 2,861 |  |

[0001032975-20-000015:mdna:237]
* Expected contribution to employee benefit plans: Commitments under the retirement plans relate to expected contributions to be made to our defined benefit plans for the next year only. We fund our pension plans so that we meet at least the minimum contribution requirements, as established by local government, funding and taxing authorities. Expected contributions and payments to our defined benefit pension plans and non-retirement post-employment benefit plans beyond one year are excluded from the contractual obligations table because they are dependent on numerous factors that may result in a wide range of outcomes and thus are impractical to estimate. For more information on our defined benefit pension plans and non-retirement post-employment benefit plans, see Note 5 to the Consolidated Financial Statements in Item 8, which is incorporated herein by reference.

[0001032975-20-000015:mdna:238]
Purchase Commitments

[0001032975-20-000015:mdna:239]
As of March 31, 2020, we have non-cancelable purchase commitments of $296.5 million for inventory purchases made in the normal course of business from original design manufacturers, contract manufacturers and other suppliers, the majority of which are expected to be fulfilled during the first two quarters of fiscal year 2021. We recorded a liability for firm, non-cancelable, and unhedged inventory purchase commitments in excess of anticipated demand or net realizable value consistent with our valuation of excess and obsolete inventory. As of March 31, 2020, the liability for these purchase commitments was $9.6 million and is recorded in accrued and other current liabilities and is not included in the preceding table. We have firm purchase commitments of $15.1 million for capital expenditures, primarily related to commitments for tooling, computer hardware and leasehold improvements. We expect to continue making capital expenditures in the future to support product development activities and ongoing and expanded operations. Although open purchase commitments are considered enforceable and legally binding, the terms generally allow us the option to reschedule and adjust our requirements based on business needs prior to delivery of goods.

[0001032975-20-000015:mdna:240]
Operating Leases Obligation

[0001032975-20-000015:mdna:241]
We lease facilities under operating leases, certain of which require us to pay property taxes, insurance and maintenance costs. Operating leases for facilities are generally renewable at our option and usually include escalation clauses linked to inflation. The remaining terms of our non-cancelable operating leases expire in various years through 2031. See "Note 17 - Leases" to the consolidated financial statements included in this report for more information on leases.

[0001032975-20-000015:mdna:242]
Income Taxes Payable

[0001032975-20-000015:mdna:243]
As of March 31, 2020, we had $40.8 million in non-current income taxes payable, including interest and penalties, related to our income tax liability for uncertain tax positions. At this time, we are unable to make a reasonably reliable estimate of the timing of payments in individual years in connection with these tax liabilities; therefore, such amounts are not included in the contractual obligation table above.

[0001032975-20-000015:mdna:244]
Indemnifications

[0001032975-20-000015:mdna:245]
We indemnify certain of our suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys' fees. As of March 31, 2020, no amounts have been accrued for indemnification provisions. We do not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under our indemnification arrangements.

[0001032975-20-000015:mdna:246]
We also indemnify our current and former directors and certain of our current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. We are unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not capped, the obligations are conditional in nature, and the facts and circumstances involved in any situation that might arise are variable.

[0001032975-20-000015:mdna:247]
Off-Balance Sheet Arrangements

[0001032975-20-000015:mdna:248]
We do not have any off-balance sheet arrangements that have, or are reasonably likely to have, a current or future effect on our financial condition, changes in financial condition, revenues or expenses, results of operations, liquidity, capital expenditures or capital resources that are material to investors.
