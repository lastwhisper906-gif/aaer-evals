# LOGI 10-K controls and the auditor's report


## auditors_report

[0001032975-20-000015:auditors_report:1]
Report of Independent Registered Public Accounting Firm

[0001032975-20-000015:auditors_report:2]
To the Shareholders and Board of Directors

[0001032975-20-000015:auditors_report:3]
Logitech International S.A.:

[0001032975-20-000015:auditors_report:4]
Opinions on the Consolidated Financial Statements and Internal Control Over Financial Reporting

[0001032975-20-000015:auditors_report:5]
We have audited the accompanying consolidated balance sheets of Logitech International S.A. and subsidiaries (the Company) as of March 31, 2020 and 2019, the related consolidated statements of operations, comprehensive income, changes in shareholders’ equity, and cash flows for each of the years in the three-year period ended March 31, 2020, and the related notes and financial statement schedule (collectively, the consolidated financial statements). We also have audited the Company’s internal control over financial reporting as of March 31, 2020, based on criteria established in Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission.

[0001032975-20-000015:auditors_report:6]
In our opinion, the consolidated financial statements referred to above present fairly, in all material respects, the financial position of the Company as of March 31, 2020 and 2019, and the results of its operations and its cash flows for each of the years in the three-year period ended March 31, 2020, in conformity with U.S. generally accepted accounting principles. Also in our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of March 31, 2020 based on criteria established in Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission.

[0001032975-20-000015:auditors_report:7]
The Company acquired General Workings, Inc. (Streamlabs) on October 31, 2019, and management excluded from its assessment of the effectiveness of the Company’s internal control over financial reporting as of March 31, 2020, Streamlabs internal control over financial reporting associated with 4% of total assets and less than 1% of total sales included in the consolidated financial statements of the Company as of and for the year ended March 31, 2020. Our audit of internal control over financial reporting of the Company also excluded an evaluation of the internal control over financial reporting of Streamlabs.

[0001032975-20-000015:auditors_report:8]
Change in Accounting Principle

[0001032975-20-000015:auditors_report:9]
As discussed in Note 2 to the consolidated financial statements, the Company has changed its method of accounting for leases as of April 1, 2019 due to the adoption of the FASB’s Accounting Standards Codification (ASC) Topic 842, Leases, its method of accounting for revenue as of April 1, 2018 due to the adoption of ASC Topic 606, Revenue from Contracts with Customers and its method of accounting for excess tax benefits from share-based payments as of April 1, 2017 due to the adoption of ASC Topic 718, Improvements to Employee Share-Based Payment Accounting.

[0001032975-20-000015:auditors_report:10]
Basis for Opinions

[0001032975-20-000015:auditors_report:11]
The Company’s management is responsible for these consolidated financial statements, for maintaining effective internal control over financial reporting, and for its assessment of the effectiveness of internal control over financial reporting, included in the accompanying Management’s Report on Internal Control over Financial Reporting included in Item 9A. Our responsibility is to express an opinion on the Company’s consolidated financial statements and an opinion on the Company’s internal control over financial reporting based on our audits. We are a public accounting firm registered with the Public Company Accounting Oversight Board (United States) (PCAOB) and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001032975-20-000015:auditors_report:12]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audits to obtain reasonable assurance about whether the consolidated financial statements are free of material misstatement, whether due to error or fraud, and whether effective internal control over financial reporting was maintained in all material respects.

[0001032975-20-000015:auditors_report:13]
Our audits of the consolidated financial statements included performing procedures to assess the risks of material misstatement of the consolidated financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the consolidated financial statements. Our audits also included evaluating the accounting

[0001032975-20-000015:auditors_report:14]
principles used and significant estimates made by management, as well as evaluating the overall presentation of the consolidated financial statements. Our audit of internal control over financial reporting included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, and testing and evaluating the design and operating effectiveness of internal control based on the assessed risk. Our audits also included performing such other procedures as we considered necessary in the circumstances. We believe that our audits provide a reasonable basis for our opinions.

[0001032975-20-000015:auditors_report:15]
Definition and Limitations of Internal Control Over Financial Reporting

[0001032975-20-000015:auditors_report:16]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (1) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (2) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (3) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0001032975-20-000015:auditors_report:17]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001032975-20-000015:auditors_report:18]
Critical Audit Matters

[0001032975-20-000015:auditors_report:19]
The critical audit matters communicated below are matters arising from the current period audit of the consolidated financial statements that were communicated or required to be communicated to the audit committee and that: (1) relate to accounts or disclosures that are material to the consolidated financial statements and (2) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the consolidated financial statements, taken as a whole, and we are not, by communicating the critical audit matters below, providing separate opinions on the critical audit matters or on the accounts or disclosures to which they relate.

[0001032975-20-000015:auditors_report:20]
Assessment of the assumptions underlying the breakage rates for certain Customer Programs

[0001032975-20-000015:auditors_report:21]
As discussed in Notes 2 and 8 to the consolidated financial statements, the Company recorded allowances totaling $194,703 thousand as of March 31, 2020 for various cooperative marketing arrangements (marketing development funds and cooperative advertising arrangements), customer incentive and pricing programs, together known as Customer Programs. The Company estimates the percentage of Customer Programs which will not be claimed or will not be earned by customers, which is commonly referred to as "breakage". The length of time between when the Company recognizes revenue and when customers make claims under these Customer Programs can be as long as one year. This requires the Company to use judgment to estimate breakage rates.

[0001032975-20-000015:auditors_report:22]
We identified the assessment of the assumptions underlying the breakage rates for certain Customer Programs as a critical audit matter. The determination of the period in which the claims are expected to be submitted by the customers, historical customer claim experience and historical trend of claims submitted after the expected period are considered the significant assumptions around the breakage rates estimate. The testing of such assumptions required a high degree of auditor judgment due to the inherent uncertainties related to the relevance of historical collection experience to the determination of the breakage rates estimate.

[0001032975-20-000015:auditors_report:23]
The primary procedures we performed to address this critical audit matter included the following. We tested certain internal controls over the Company’s revenue process, including controls over the significant assumptions identified above. We assessed the underlying information related to the expected periods that a customer claim will be submitted and the historical claim experience rate for customer incentive and pricing programs and marketing development funds, by analyzing the trend in the customers’ historical claims and accruals information. In addition, we evaluated the Company’s ability to estimate the breakage rates by comparing the estimated breakage from fiscal 2019 against actual subsequent breakage.

[0001032975-20-000015:auditors_report:24]
Assessment of the accruals for sales returns and certain Customer Programs

[0001032975-20-000015:auditors_report:25]
As discussed in Notes 2 and 8 to the consolidated financial statements, the Company recorded accruals of $30,267 thousand for sales returns and $130,220 thousand for Customer Programs as of March 31, 2020. The Company records these accruals as a reduction of revenue at the time of sale. The Company estimated these accruals based on historical data or future commitments that are planned and controlled by the Company. The Company uses judgment in analyzing historical trends, inventories owned by and located at the customers, products sold by the direct customers to end customers or resellers, known product quality issues and other relevant customer and product information, such as stage of product life cycle which are expected to experience unusually high discounting or returns.

[0001032975-20-000015:auditors_report:26]
We identified the assessment of the accruals for sales returns and certain Customer Programs as a critical audit matter. Historical experience being predictive of future returns and Customer Programs’ earned amounts is the key assumption used to estimate the accrual for sales returns and Customer Programs. Due to the inherent uncertainties related to the relevance of the predictive historical experience to the determination of the estimate, the testing required a high degree of auditor judgment.

[0001032975-20-000015:auditors_report:27]
The primary procedures we performed to address this critical audit matter included the following. We tested certain internal controls over the Company’s accrual process, including controls over the assumption discussed above. We assessed the historical experience used in estimating the accrual for sales returns and certain Customer Programs using a combination of Company internal historical information of sales, returns and Customer Programs’ earned amounts, third-party contracts, and relevant and reliable third-party channel inventory and sell-through data. We confirmed selected customer contracts to assess the terms and conditions related to sales returns and certain Customer Programs. We analyzed channel data trends by product and by region comparing fiscal 2020 quarterly ratios to prior fiscal years. In addition, we evaluated the Company’s ability to estimate the accruals for sales returns and certain Customer Programs by comparing recorded accruals from fiscal 2019 to actual subsequent returns and Customer Programs’ earned amounts.

[0001032975-20-000015:auditors_report:28]
Assessment of unrecognized tax benefit resulted from the tax reform in Switzerland

[0001032975-20-000015:auditors_report:29]
As discussed in Note 7 to the consolidated financial statements, the Company recorded gross unrecognized tax benefits of $71.1 million, excluding associated interest and penalties, for uncertain tax positions taken during fiscal year ended March 31, 2020. The gross unrecognized tax benefits include an uncertain tax position in Switzerland as a result of the enactment of the Federal Act on Tax Reform and AHV Financing ("TRAF") on March 10, 2020 in the canton of Vaud.

[0001032975-20-000015:auditors_report:30]
We identified the assessment of the unrecognized tax benefit associated with a tax position taken upon the enactment of TRAF as a critical audit matter. Complex auditor judgment was required to evaluate the Company’s interpretation and application of TRAF and estimate of the ultimate resolution of the tax position.

[0001032975-20-000015:auditors_report:31]
The primary procedures we performed to address this critical audit matter included the following.  We tested certain internal controls over the Company's unrecognized tax benefit determination process, which relates to the interpretation of TRAF and its application in the assessment of the uncertain tax position process. Since the application of TRAF measures is complex and subject to interpretation, we involved Swiss tax professionals with specialized skills and knowledge, who assisted in:

[0001032975-20-000015:auditors_report:32]
| • | Evaluating the Company's interpretation of TRAF and its potential impact on the unrecognized tax benefit; |

[0001032975-20-000015:auditors_report:33]
| • | Assessing the Company's determination of its tax positions having more than a 50% likelihood to be sustained upon examination, and |

[0001032975-20-000015:auditors_report:34]
| • | Performing an independent assessment of the Company's uncertain tax position taken upon the enactment of TRAF and comparing the results to the Company's evaluation. |

[0001032975-20-000015:auditors_report:35]
/s/ KPMG LLP

[0001032975-20-000015:auditors_report:36]
We have served as the Company’s auditor since 2014.

[0001032975-20-000015:auditors_report:37]
San Francisco, California

[0001032975-20-000015:auditors_report:38]
May 27, 2020

[0001032975-20-000015:auditors_report:39]
LOGITECH INTERNATIONAL S.A.


## item_9a

[0001032975-20-000015:item_9a:1]
ITEM 9A.    CONTROLS AND PROCEDURES

[0001032975-20-000015:item_9a:2]
(a) Evaluation of Disclosure Controls and Procedures

[0001032975-20-000015:item_9a:3]
The Company's management, with the participation of the Company’s Chief Executive Officer (CEO) and Chief Financial Officer (CFO), has conducted an evaluation of the effectiveness of the design and operation of the Company's disclosure controls and procedures (as defined in Rules 13a-15(e) and 15d-15(e) under the Securities Exchange Act of 1934, as amended (the Exchange Act)) as of the end of the period covered by this Annual Report on Form 10-K (this Annual Report) required by Exchange Act Rules 13a-15(b) or 15d-15(b). Disclosure controls and procedures are designed to reasonably assure that information required to be disclosed in our reports filed or submitted under the Exchange Act, such as this Annual Report on Form 10-K, is recorded, processed, summarized and reported within the time periods specified in the Securities and Exchange Commission's rules and forms. Disclosure controls and procedures are also designed to reasonably assure that this information is accumulated and communicated to our management, including the CEO and CFO, to allow timely decisions regarding required disclosure. Based on this evaluation, the CEO and CFO concluded that, as of the end of the period covered by this Annual Report, the Company’s disclosure controls and procedures were effective at a reasonable assurance level.

[0001032975-20-000015:item_9a:4]
The Company acquired Streamlabs on October 31, 2019. Management excluded from its evaluation of the effectiveness of its internal control over financial reporting as of March 31, 2020 the acquired entity’s internal control over financial reporting associated with 4% of total assets and less than 1% of total sales included in the consolidated financial statements as of and for the year ended March 31, 2020.

[0001032975-20-000015:item_9a:5]
Attached as exhibits to this Annual Report are certifications of the CEO and CFO, which are required in accordance with Rule 13a-14 of the Exchange Act. This Controls and Procedures section includes the information concerning the controls evaluation referred to in the certifications, and it should be read in conjunction with the certifications for a more complete understanding of the topics presented.

[0001032975-20-000015:item_9a:6]
(b) Management's Report on Internal Control over Financial Reporting

[0001032975-20-000015:item_9a:7]
The Company's management is responsible for establishing and maintaining adequate internal control over financial reporting as defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act. Under the supervision and with the participation of the Company’s management, including the CEO and CFO, the Company conducted an evaluation of the effectiveness of its internal control over financial reporting based on the criteria established in the Internal Control-Integrated Framework (2013), issued by the Committee of Sponsoring Organizations of the Treadway Commission. Based on this evaluation, management has concluded that our internal control over financial reporting was effective as of March 31, 2020.

[0001032975-20-000015:item_9a:8]
The effectiveness of the Company's internal control over financial reporting as of March 31, 2020 has been audited by KPMG LLP, an independent registered public accounting firm, as stated in its report, which appears in Item 15.

[0001032975-20-000015:item_9a:9]
Logitech International S.A. | Fiscal 2020 Form 10-K | 62

[0001032975-20-000015:item_9a:10]
(c) Changes in Internal Control over Financial Reporting

[0001032975-20-000015:item_9a:11]
There were no changes in our internal control over financial reporting during the fourth quarter of fiscal year 2020 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0001032975-20-000015:item_9a:12]
(d) Limitations on the Effectiveness of Controls

[0001032975-20-000015:item_9a:13]
The Company's management, including the CEO and CFO, does not expect that the Company's disclosure controls and procedures or internal control over financial reporting will prevent all errors and all fraud. Internal control over financial reporting, no matter how well designed and operated, can provide only reasonable, not absolute, assurance that the objectives will be met. Because of the inherent limitations in internal control over financial reporting, no evaluation of controls can provide absolute assurance that all control issues and instances of fraud, if any, within the Company have been detected. These inherent limitations include the realities that judgments in decision making can be faulty and that breakdowns can occur because of simple error or mistake. Controls can also be circumvented by the individual acts of some persons, by collusion of two or more people, or by management override of the controls. The design of any system of controls is based in part on certain assumptions about the likelihood of future events, and there can be no assurance that any design will succeed in achieving its stated goals under all potential future conditions. Over time, controls may become inadequate because of changes in conditions or deterioration in the degree of compliance with policies or procedures. Because of the inherent limitations in a cost-effective control system, misstatements due to error or fraud may occur and not be detected.
