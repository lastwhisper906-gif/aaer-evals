# LOGI 8-K — 0001032975-20-000011 filed 2020-05-12

## item codes, every 8-K on or before 2020-05-27

- 2020-05-12 0001032975-20-000011 — 2.02, 9.01
- 2020-03-30 0001032975-20-000009 — 5.02
- 2020-01-21 0001032975-20-000002 — 2.02, 9.01
- 2019-10-22 0001032975-19-000071 — 9.01
- 2019-09-26 0001032975-19-000068 — 1.01, 7.01, 9.01
- 2019-09-06 0001032975-19-000063 — 5.07, 8.01
- 2019-07-23 0001032975-19-000046 — 2.02, 9.01
- 2019-07-23 0001032975-19-000045 — 5.02, 9.01
- 2019-07-02 0001032975-19-000036 — 5.02
- 2019-06-25 0001032975-19-000034 — 5.02
- 2019-05-03 0001032975-19-000021 — 5.02 — amendment, the index does not say of what
- 2019-04-30 0001032975-19-000017 — 2.02, 5.02, 9.01
- 2019-03-28 0001032975-19-000013 — 5.02
- 2019-01-22 0001032975-19-000004 — 2.02, 9.01
- 2018-10-23 0001032975-18-000044 — 2.02, 9.01
- 2018-09-07 0001032975-18-000040 — 5.07, 8.01
- 2018-07-31 0001032975-18-000035 — 1.01, 2.02, 2.05, 7.01, 9.01
- 2018-06-27 0001032975-18-000020 — 5.02
- 2018-05-03 0001032975-18-000013 — 2.02, 5.02, 9.01
- 2018-01-23 0001032975-18-000005 — 2.02, 9.01
- 2017-10-24 0001032975-17-000043 — 2.02, 9.01
- 2017-09-18 0001032975-17-000040 — 5.07, 8.01
- 2017-07-25 0001032975-17-000028 — 2.02, 9.01
- 2017-07-12 0001032975-17-000022 — 1.01
- 2017-04-26 0001032975-17-000012 — 2.02, 9.01
- 2017-01-25 0001032975-17-000002 — 2.02, 9.01
- 2016-10-26 0001032975-16-000103 — 2.02, 9.01
- 2016-09-13 0001032975-16-000101 — 5.07, 8.01
- 2016-07-28 0001032975-16-000092 — 2.02, 9.01
- 2016-06-30 0001032975-16-000087 — 5.02
- 2016-04-28 0001032975-16-000077 — 2.02, 9.01
- 2016-04-14 0001032975-16-000073 — 1.01, 7.01, 9.01
- 2016-01-21 0001032975-16-000064 — 2.02, 9.01
- 2016-01-04 0001032975-16-000061 — 1.01, 2.01, 9.01
- 2015-12-23 0001032975-15-000059 — 5.02
- 2015-10-22 0001032975-15-000047 — 2.02, 9.01
- 2015-09-11 0001032975-15-000044 — 5.07, 8.01
- 2015-07-24 0001032975-15-000034 — 2.05 — amendment of 0001032975-15-000030
- 2015-07-23 0001032975-15-000030 — 2.02, 9.01
- 2015-06-25 0001032975-15-000025 — 5.02
- 2015-05-14 0001032975-15-000011 — 8.01, 9.01
- 2015-04-23 0001032975-15-000008 — 2.02, 2.05
- 2015-01-22 0001628280-15-000191 — 2.02, 8.01
- 2014-12-23 0001193125-14-450908 — 5.02, 5.07, 8.01
- 2014-11-25 0001193125-14-425233 — 3.01
- 2014-11-13 0001193125-14-411303 — 4.01, 9.01
- 2014-10-23 0001104659-14-073164 — 2.02, 9.01
- 2014-09-04 0001193125-14-331214 — 4.02, 9.01
- 2014-08-18 0001193125-14-313346 — 3.01, 9.01
- 2014-07-24 0001104659-14-053065 — 2.02, 9.01
- 2014-06-05 0001193125-14-226177 — 3.01, 9.01
- 2014-05-22 0001193125-14-208777 — 8.01, 9.01
- 2014-04-24 0001104659-14-029650 — 2.02, 9.01
- 2014-01-23 0001104659-14-003619 — 2.02, 9.01
- 2013-10-24 0001104659-13-077404 — 2.02, 9.01
- 2013-09-09 0001193125-13-361441 — 5.02, 5.07, 8.01, 9.01
- 2013-09-06 0001193125-13-359930 — 5.02, 9.01
- 2013-08-02 0001193125-13-317343 — 5.02
- 2013-07-25 0001104659-13-056372 — 2.02, 9.01
- 2013-06-28 0001193125-13-277394 — 5.02, 9.01
- 2013-06-20 0001193125-13-265914 — 8.01, 9.01
- 2013-04-25 0001104659-13-032570 — 2.02, 9.01
- 2013-04-17 0001193125-13-158923 — 5.02, 9.01
- 2013-03-01 0001193125-13-085804 — 2.05
- 2013-01-24 0001104659-13-004214 — 2.02, 9.01
- 2013-01-02 0001193125-13-000058 — 5.02
- 2012-10-25 0001104659-12-070966 — 2.02, 9.01
- 2012-09-11 0001193125-12-388070 — 5.02, 5.07, 8.01, 9.01
- 2012-08-22 0001193125-12-364167 — 5.02, 8.01, 9.01
- 2012-07-26 0001104659-12-051084 — 2.02, 9.01
- 2012-06-08 0001193125-12-264132 — 2.05, 9.01 — amendment, the index does not say of what
- 2012-04-26 0001193125-12-183657 — 5.02, 9.01
- 2012-04-26 0001104659-12-028470 — 2.02, 2.05, 9.01
- 2012-03-15 0001193125-12-115954 — 5.02, 9.01
- 2012-01-26 0001104659-12-004014 — 2.02, 9.01
- 2012-01-04 0001193125-12-002212 — 1.01, 2.03, 9.01
- 2011-10-27 0001104659-11-058150 — 2.02, 9.01
- 2011-09-12 0001193125-11-245931 — 5.07
- 2011-07-28 0001193125-11-200929 — 5.02, 9.01
- 2011-07-28 0001193125-11-199704 — 2.02, 9.01
- 2011-04-28 0001193125-11-112669 — 2.02, 9.01
- 2011-03-24 0001193125-11-076483 — 5.02, 9.01
- 2011-01-27 0001032975-11-000003 — 9.01
- 2010-10-28 0001032975-10-000032 — 9.01
- 2010-09-13 0001032975-10-000022 — 5.07
- 2010-07-29 0001032975-10-000010 — 2.02, 9.01
- 2010-06-10 0001193125-10-136877 — 5.02, 9.01
- 2010-05-03 0001193125-10-104337 — 5.02
- 2010-04-29 0001032975-10-000008 — 2.02, 9.01
- 2010-02-19 0001032975-10-000006 — 9.01 — amendment of 0001193125-09-252416
- 2010-01-21 0001032975-10-000002 — 2.02, 9.01
- 2009-12-14 0001193125-09-252416 — 2.01, 9.01
- 2009-11-17 0001032975-09-000023 — 1.01
- 2009-10-22 0001032975-09-000018 — 9.01
- 2009-09-22 0001193125-09-195545 — 5.02, 9.01
- 2009-09-03 0001032975-09-000013 — 8.01
- 2009-07-23 0001140361-09-016802 — 2.02, 9.01
- 2009-06-01 0001193125-09-122550 — 5.02
- 2009-04-23 0001193125-09-085054 — 2.02, 9.01
- 2009-04-02 0001193125-09-071272 — 5.02, 9.01
- 2009-01-20 0001193125-09-008454 — 2.05 — amendment of 0001193125-09-002609
- 2009-01-20 0001193125-09-007902 — 2.02, 9.01
- 2009-01-07 0001193125-09-002609 — 2.05, 9.01
- 2009-01-07 0001193125-09-002370 — 5.02, 9.01
- 2008-12-09 0001193125-08-250543 — 5.02, 9.01
- 2008-10-21 0001193125-08-213212 — 2.02, 9.01
- 2008-07-22 0001193125-08-154721 — 2.02, 9.01
- 2008-06-24 0001193125-08-139163 — 5.03, 9.01
- 2008-05-13 0001193125-08-113263 — 5.02, 9.01
- 2008-04-22 0001193125-08-086176 — 2.02, 9.01

## late-filing notifications on or before 2020-05-27

- 2015-06-02 0001032975-15-000020 — NT 10-K, for the period ended 2015-03-31
- 2014-11-06 0001193125-14-401306 — NT 10-Q, for the period ended 2014-09-30
- 2014-07-24 0001193125-14-277575 — NT 10-Q, for the period ended 2014-06-30
- 2014-05-22 0001193125-14-208712 — NT 10-K, for the period ended 2014-03-31
- 2009-08-06 0001032975-09-000006 — NT 10-Q, for the period ended 2009-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001032975-20-000011:8k_2_02:1]
EX-99.1
2
exhibit991q4fy20.htm
EXHIBIT 99.1

[0001032975-20-000011:8k_2_02:2]
Exhibit

[0001032975-20-000011:8k_2_02:3]
Exhibit 99.1

[0001032975-20-000011:8k_2_02:4]
Editorial Contacts:

[0001032975-20-000011:8k_2_02:5]
Ben Lu, CFA, Vice President, Investor Relations - USA (510) 713-5568

[0001032975-20-000011:8k_2_02:6]
Krista Todd, Vice President, Global Communications - USA (510) 713-5834

[0001032975-20-000011:8k_2_02:7]
Nicole Kenyon, Head of Global Corporate & Employee Communications - USA (510) 988-8553

[0001032975-20-000011:8k_2_02:8]
Ben Starkie, Corporate Communications - Europe +41 (0) 79-292-3499

[0001032975-20-000011:8k_2_02:9]
Logitech Exceeds Full-Year Sales and Profit Outlook

[0001032975-20-000011:8k_2_02:10]
Company Confirms FY 2021 Guidance on Strength of Key Product Categories

[0001032975-20-000011:8k_2_02:11]
LAUSANNE, Switzerland, May 12, 2020 and NEWARK, Calif., May 11, 2020 — Logitech International (SIX: LOGN) (Nasdaq: LOGI) today announced financial results for the fourth quarter and full year of Fiscal Year 2020, ended March 31, 2020.

[0001032975-20-000011:8k_2_02:12]
For Fiscal Year 2020:

[0001032975-20-000011:8k_2_02:13]
| • | Sales were Logitech’s highest ever at $2.98 billion, up 7 percent in US dollars and 9 percent in constant currency compared to the prior year. |

[0001032975-20-000011:8k_2_02:14]
| • | GAAP operating income grew 5 percent to $276 million, compared to $263 million a year ago. GAAP earnings per share (EPS) grew 75 percent to $2.66, compared to $1.52 a year ago. |

[0001032975-20-000011:8k_2_02:15]
| • | Non-GAAP operating income grew 10 percent to $387 million, compared to $352 million a year ago. Non-GAAP EPS grew 7 percent to $2.15, compared to $2.01 a year ago. |

[0001032975-20-000011:8k_2_02:16]
| • | Cash flow from operations was a record $425 million, compared to $305 million a year ago. |

[0001032975-20-000011:8k_2_02:17]
For Q4 Fiscal Year 2020:

[0001032975-20-000011:8k_2_02:18]
| • | Sales grew to $709 million, up 14 percent in US dollars and 15 percent in constant currency compared to Q4 of the prior year. |

[0001032975-20-000011:8k_2_02:19]
| • | GAAP operating income was $32 million, down 24 percent primarily due to a one-time, acquisition-related charge. Non-GAAP operating income grew 23 percent to $79 million, compared to Q4 of the prior year. |

[0001032975-20-000011:8k_2_02:20]
“We have delivered five consecutive years at or near double-digit growth, and Logitech’s products have never been more relevant,” said Bracken Darrell, Logitech president and chief executive officer. “Video conferencing, working remotely, creating and streaming content, and gaming are long-term secular trends driving our business. The pandemic hasn’t changed these trends: it has accelerated them.”

[0001032975-20-000011:8k_2_02:21]
“We finished a solid year with a very strong fourth quarter,” said Nate Olmstead, Logitech chief financial officer. “The COVID-19 pandemic introduces operational challenges, yet our ability to execute and strong long-term growth drivers give us the confidence to maintain our financial outlook for Fiscal Year 2021.”

[0001032975-20-000011:8k_2_02:22]
Outlook

[0001032975-20-000011:8k_2_02:23]
Logitech confirmed its Fiscal Year 2021 outlook of mid single-digit sales growth in constant currency and $380 million to $400 million in non-GAAP operating income.

[0001032975-20-000011:8k_2_02:24]
Prepared Remarks Available Online

[0001032975-20-000011:8k_2_02:25]
Logitech has made its prepared written remarks for the financial results teleconference available online on the Logitech corporate website at http://ir.logitech.com.

[0001032975-20-000011:8k_2_02:26]
Financial Results Teleconference and Webcast

[0001032975-20-000011:8k_2_02:27]
Logitech will hold a financial results teleconference to discuss the results for Q4 and the full Fiscal Year 2020 on Tuesday, May 12, 2020 at 8:30 a.m. Eastern Daylight Time and 2:30 p.m. Central European Summer Time. A live webcast of the call will be available on the Logitech corporate website

[0001032975-20-000011:8k_2_02:28]
http://ir.logitech.com.

[0001032975-20-000011:8k_2_02:29]
Use of Non-GAAP Financial Information and Constant Currency

[0001032975-20-000011:8k_2_02:30]
To facilitate comparisons to Logitech’s historical results, Logitech has included non-GAAP adjusted measures, which exclude share-based compensation expense, amortization of intangible assets, purchase accounting effect on inventory, acquisition-related costs, change in fair value of contingent consideration for business acquisition, restructuring charges (credits), gain (loss) on investments in privately held companies, non-GAAP income tax adjustment, and other items detailed under “Supplemental Financial Information” after the tables below. Logitech also presents percentage sales growth in constant currency to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales. Logitech believes this information, used together with the GAAP financial information, will help investors to evaluate its current period performance and trends in its business. With respect to the Company’s outlook for non-GAAP operating income, most of these excluded amounts pertain to events that have not yet occurred and are not currently possible to estimate with a reasonable degree of accuracy. Therefore, no reconciliation to the GAAP amounts has been provided for Fiscal Year 2021.

[0001032975-20-000011:8k_2_02:31]
About Logitech

[0001032975-20-000011:8k_2_02:32]
Logitech designs products that have an everyday place in people's lives, connecting them to the digital experiences they care about. More than 35 years ago, Logitech started connecting people through computers, and now it’s a multi-brand company designing products that bring people together through music, gaming, video and computing. Brands of Logitech include Logitech, Logitech G, ASTRO Gaming, Streamlabs, Ultimate Ears, Jaybird, and Blue Microphones. Founded in 1981, and headquartered in Lausanne, Switzerland, Logitech International is a Swiss public company listed on the SIX Swiss Exchange (LOGN) and on the Nasdaq Global Select Market (LOGI). Find Logitech at www.logitech.com, the company blog or @Logitech.

[0001032975-20-000011:8k_2_02:33]
# # #

[0001032975-20-000011:8k_2_02:34]
Note that unless noted otherwise, comparisons are year over year.

[0001032975-20-000011:8k_2_02:35]
Logitech and other Logitech marks are trademarks or registered trademarks of Logitech Europe S.A and/or its affiliates in the U.S. and other countries.  All other trademarks are the property of their respective owners. For more information about Logitech and its products, visit the company’s website at www.logitech.com.

[0001032975-20-000011:8k_2_02:36]
(LOGIIR)

[0001032975-20-000011:8k_2_02:37]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  | Fiscal Years Ended |
|  |  | March 31, |  | March 31, |
| GAAP CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Net sales |  | $ | 709,248 |  |  | $ | 624,308 |  |  | $ | 2,975,851 |  |  | $ | 2,788,322 |  |
| Cost of goods sold |  | 428,080 |  |  | 388,028 |  |  | 1,838,685 |  |  | 1,737,969 |  |
| Amortization of intangible assets and purchase accounting effect on inventory |  | 4,292 |  |  | 3,305 |  |  | 14,785 |  |  | 13,342 |  |
| Gross profit |  | 276,876 |  |  | 232,975 |  |  | 1,122,381 |  |  | 1,037,011 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Marketing and selling |  | 141,186 |  |  | 119,628 |  |  | 533,324 |  |  | 488,263 |  |
| Research and development |  | 50,094 |  |  | 42,110 |  |  | 177,593 |  |  | 161,230 |  |
| General and administrative |  | 25,465 |  |  | 23,557 |  |  | 94,015 |  |  | 98,732 |  |
| Amortization of intangible assets and acquisition-related costs |  | 4,666 |  |  | 3,913 |  |  | 17,563 |  |  | 14,290 |  |
| Change in fair value of contingent consideration for business acquisition (C) |  | 23,247 |  |  | — |  |  | 23,247 |  |  | — |  |
| Restructuring charges, net |  | 74 |  |  | 1,540 |  |  | 144 |  |  | 11,302 |  |
| Total operating expenses |  | 244,732 |  |  | 190,748 |  |  | 845,886 |  |  | 773,817 |  |
| Operating income |  | 32,144 |  |  | 42,227 |  |  | 276,495 |  |  | 263,194 |  |
| Interest income |  | 2,614 |  |  | 2,666 |  |  | 9,619 |  |  | 8,375 |  |
| Other income (expense), net (D) |  | 35,360 |  |  | 493 |  |  | 38,212 |  |  | (436 | ) |
| Income before income taxes |  | 70,118 |  |  | 45,386 |  |  | 324,326 |  |  | 271,133 |  |
| Provision for (benefit from) income taxes (A) |  | (143,802 | ) |  | 3,265 |  |  | (125,397 | ) |  | 13,560 |  |
| Net income |  | $ | 213,920 |  |  | $ | 42,121 |  |  | $ | 449,723 |  |  | $ | 257,573 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.28 |  |  | $ | 0.25 |  |  | $ | 2.70 |  |  | $ | 1.56 |  |
| Diluted |  | $ | 1.26 |  |  | $ | 0.25 |  |  | $ | 2.66 |  |  | $ | 1.52 |  |
| Weighted average shares used to compute net income per share: |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | 167,290 |  |  | 165,776 |  |  | 166,837 |  |  | 165,609 |  |
| Diluted |  | 169,981 |  |  | 168,956 |  |  | 169,381 |  |  | 168,965 |  |

[0001032975-20-000011:8k_2_02:38]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |
|  |  | March 31, |  | March 31, |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  | 2020 |  | 2019 |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 715,566 |  |  | $ | 604,516 |  |
| Accounts receivable, net |  | 394,743 |  |  | 383,309 |  |
| Inventories |  | 229,249 |  |  | 293,495 |  |
| Other current assets (D) |  | 74,920 |  |  | 69,116 |  |
| Total current assets |  | 1,414,478 |  |  | 1,350,436 |  |
| Non-current assets: |  |  |  |  |  |
| Property, plant and equipment, net |  | 76,119 |  |  | 78,552 |  |
| Goodwill |  | 400,917 |  |  | 343,684 |  |
| Other intangible assets, net |  | 126,941 |  |  | 118,999 |  |
| Other assets (A) (B) (D) |  | 345,019 |  |  | 132,453 |  |
| Total assets |  | $ | 2,363,474 |  |  | $ | 2,024,124 |  |
| Current liabilities: |  |  |  |  |  |  |
| Accounts payable |  | $ | 259,120 |  |  | $ | 283,922 |  |
| Accrued and other current liabilities (B) (C) |  | 455,024 |  |  | 433,897 |  |
| Total current liabilities |  | 714,144 |  |  | 717,819 |  |
| Non-current liabilities: |  |  |  |  |  |  |
| Income taxes payable |  | 40,788 |  |  | 36,384 |  |
| Other non-current liabilities (B) |  | 119,274 |  |  | 93,582 |  |
| Total liabilities |  | 874,206 |  |  | 847,785 |  |
| Shareholders' equity: |  |  |  |  |
| Registered shares, CHF 0.25 par value: |  | 30,148 |  |  | 30,148 |  |
| Issued shares—173,106 at March 31, 2020 and 2019 |  |  |  |  |
| Additional shares that may be issued out of conditional capitals — 50,000 at March 31, 2020 and March 31, 2019 |  |  |  |  |
| Additional shares that may be issued out of authorized capital — 34,621 at March 31, 2020 and March 31, 2019 |  |  |  |  |
| Additional paid-in capital |  | 75,097 |  |  | 56,655 |  |
| Shares in treasury, at cost— 6,210 and 7,244 shares at March 31, 2020 and 2019, respectively |  | (185,896 | ) |  | (169,802 | ) |
| Retained earnings |  | 1,690,579 |  |  | 1,365,036 |  |
| Accumulated other comprehensive loss |  | (120,660 | ) |  | (105,698 | ) |
| Total shareholders' equity |  | 1,489,268 |  |  | 1,176,339 |  |
| Total liabilities and shareholders' equity |  | $ | 2,363,474 |  |  | $ | 2,024,124 |  |

[0001032975-20-000011:8k_2_02:39]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  | Fiscal Years Ended |
|  |  | March 31, |  | March 31, |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 213,920 |  |  | $ | 42,121 |  |  | $ | 449,723 |  |  | $ | 257,573 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |
| Depreciation |  | 10,739 |  |  | 10,816 |  |  | 42,893 |  |  | 43,471 |  |
| Amortization of intangible assets |  | 8,900 |  |  | 6,944 |  |  | 30,858 |  |  | 24,180 |  |
| Share-based compensation expense |  | 14,569 |  |  | 13,102 |  |  | 54,870 |  |  | 50,265 |  |
| Loss (gain) on investments |  | (16 | ) |  | (227 | ) |  | 756 |  |  | (816 | ) |
| Deferred income taxes (A) |  | (160,333 | ) |  | (2,535 | ) |  | (159,853 | ) |  | (12,257 | ) |
| Change in fair value of contingent consideration for business acquisition (C) |  | 23,247 |  |  | — |  |  | 23,247 |  |  | — |  |
| Gain on sale of investment in privately held companies (D) |  | (39,767 | ) |  | — |  |  | (39,767 | ) |  | — |  |
| Other |  | 76 |  |  | 148 |  |  | (936 | ) |  | (230 | ) |
| Changes in assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | 131,524 |  |  | 100,146 |  |  | (15,768 | ) |  | (58,798 | ) |
| Inventories |  | 75,558 |  |  | 47,612 |  |  | 60,388 |  |  | (21,551 | ) |
| Other assets |  | 15,453 |  |  | 2,298 |  |  | 18,319 |  |  | (8,800 | ) |
| Accounts payable |  | (179,440 | ) |  | (152,791 | ) |  | (24,250 | ) |  | (19,134 | ) |
| Accrued and other liabilities |  | (13,584 | ) |  | (35,896 | ) |  | (15,480 | ) |  | 51,278 |  |
| Net cash provided by operating activities |  | 100,846 |  |  |  | 31,738 |  |  | 425,000 |  |  | 305,181 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  | (10,817 | ) |  | (7,626 | ) |  | (39,484 | ) |  | (35,930 | ) |
| Acquisitions, net of cash acquired |  | — |  |  | 94 |  |  | (91,569 | ) |  | (133,814 | ) |
| Investment in privately held companies |  | (35 | ) |  | (175 | ) |  | (345 | ) |  | (2,717 | ) |
| Proceeds from return of investments |  | — |  |  | 124 |  |  | — |  |  | 124 |  |
| Purchases of short-term investments |  | — |  |  | — |  |  | — |  |  | (1,505 | ) |
| Proceeds from sales of property and plant |  | — |  |  | — |  |  | 1,037 |  |  | — |  |
| Purchases of trading investments |  | (8,893 | ) |  | (868 | ) |  | (11,964 | ) |  | (5,203 | ) |
| Proceeds from sales of trading investments |  | 8,952 |  |  | 862 |  |  | 12,091 |  |  | 5,700 |  |
| Net cash used in investing activities |  | (10,793 | ) | — |  | (7,589 | ) |  | (130,234 | ) |  | (173,345 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |
| Payment of cash dividends |  | — |  |  | — |  |  | (124,180 | ) |  | (113,971 | ) |
| Purchases of registered shares |  | (35,310 | ) |  | (9,995 | ) |  | (50,437 | ) |  | (32,449 | ) |
| Proceeds from exercises of stock options and purchase rights |  | 10,701 |  |  | 7,922 |  |  | 22,241 |  |  | 18,057 |  |
| Tax withholdings related to net share settlements of restricted stock units |  | (1,184 | ) |  | (1,659 | ) |  | (24,280 | ) |  | (30,770 | ) |
| Net cash used in financing activities |  | (25,793 | ) |  | (3,732 | ) |  | (176,656 | ) |  | (159,133 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  | (4,740 | ) |  | (389 | ) |  | (7,060 | ) |  | (10,134 | ) |
| Net increase (decrease) in cash and cash equivalents |  | 59,520 |  |  | 20,028 |  |  | 111,050 |  |  | (37,431 | ) |
| Cash and cash equivalents at beginning of the period |  | 656,046 |  |  | 584,488 |  |  | 604,516 |  |  | 641,947 |  |
| Cash and cash equivalents at end of the period |  | $ | 715,566 |  |  | $ | 604,516 |  |  | $ | 715,566 |  |  | $ | 604,516 |  |

[0001032975-20-000011:8k_2_02:40]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |  |  |
| NET SALES |  | Three Months Ended |  | Fiscal Years Ended |
|  |  | March 31, |  | March 31, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2020 |  | 2019 |  | Change |  | 2020 |  | 2019 |  | Change |
| Net sales by product category: |  |  |  |  |  |  |  |  |  |  |  |  |
| Pointing Devices |  | $ | 135,226 |  |  | $ | 131,640 |  |  | 3 | % |  | $ | 544,519 |  |  | $ | 536,890 |  |  | 1 | % |
| Keyboards & Combos |  | 147,659 |  |  | 132,356 |  |  | 12 |  |  | 571,720 |  |  | 536,619 |  |  | 7 |  |
| PC Webcams |  | 40,152 |  |  | 30,366 |  |  | 32 |  |  | 129,193 |  |  | 121,282 |  |  | 7 |  |
| Tablet & Other Accessories |  | 31,867 |  |  | 23,412 |  |  | 36 |  |  | 135,309 |  |  | 128,315 |  |  | 5 |  |
| Video Collaboration |  | 110,675 |  |  | 69,367 |  |  | 60 |  |  | 365,616 |  |  | 259,521 |  |  | 41 |  |
| Mobile Speakers |  | 21,174 |  |  | 22,688 |  |  | (7 | ) |  | 221,791 |  |  | 230,378 |  |  | (4 | ) |
| Audio & Wearables |  | 65,176 |  |  | 65,086 |  |  | — |  |  | 273,752 |  |  | 277,429 |  |  | (1 | ) |
| Gaming |  | 148,909 |  |  | 137,649 |  |  | 8 |  |  | 690,174 |  |  | 648,130 |  |  | 6 |  |
| Smart Home |  | 8,316 |  |  | 11,515 |  |  | (28 | ) |  | 43,404 |  |  | 49,344 |  |  | (12 | ) |
| Other (1) |  | 94 |  |  | 229 |  |  | (59 | ) |  | 373 |  |  | 414 |  |  | (10 | ) |
| Total net retail sales |  | $ | 709,248 |  |  | $ | 624,308 |  |  | 14 |  |  | $ | 2,975,851 |  |  | $ | 2,788,322 |  |  | 7 |  |
| __________________ |  |  |  |  |  |  |  |  |  |  |  |  |

[0001032975-20-000011:8k_2_02:41]
(1) Other category includes products that we currently intend to transition out of, or have already transitioned out of, because they are no longer strategic to our business.

[0001032975-20-000011:8k_2_02:42]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands, except per share amounts) - Unaudited |  |  |  |  |  |  |  |  |
| GAAP TO NON GAAP RECONCILIATION (E) |  | Three Months Ended |  | Fiscal Years Ended |
|  |  | March 31, |  | March 31, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Gross profit - GAAP |  | $ | 276,876 |  |  | $ | 232,975 |  |  | $ | 1,122,381 |  |  | $ | 1,037,011 |  |
| Share-based compensation expense |  | 1,300 |  |  | 938 |  |  | 4,852 |  |  | 3,812 |  |
| Amortization of intangible assets and purchase accounting effect on inventory |  | 4,292 |  |  | 3,305 |  |  | 14,785 |  |  | 13,342 |  |
| Gross profit - Non-GAAP |  | $ | 282,468 |  |  | $ | 237,218 |  |  | $ | 1,142,018 |  |  | $ | 1,054,165 |  |
| Gross margin - GAAP |  | 39.0 | % |  | 37.3 | % |  | 37.7 | % |  | 37.2 | % |
| Gross margin - Non-GAAP |  | 39.8 | % |  | 38.0 | % |  | 38.4 | % |  | 37.8 | % |
| Operating expenses - GAAP |  | $ | 244,732 |  |  | $ | 190,748 |  |  | $ | 845,886 |  |  | $ | 773,817 |  |
| Less: Share-based compensation expense |  | 13,269 |  |  | 12,164 |  |  | 50,018 |  |  | 46,453 |  |
| Less: Amortization of intangible assets and acquisition-related costs |  | 4,665 |  |  | 3,913 |  |  | 17,563 |  |  | 14,290 |  |
| Less: Change in fair value of contingent consideration for business acquisition (C) |  | 23,247 |  |  | — |  |  | 23,247 |  |  | — |  |
| Less: Restructuring charges, net |  | 75 |  |  | 1,540 |  |  | 144 |  |  | 11,302 |  |
| Operating expenses - Non-GAAP |  | $ | 203,476 |  |  | $ | 173,131 |  |  | $ | 754,914 |  |  | $ | 701,772 |  |
| % of net sales - GAAP |  | 34.5 | % |  | 30.6 | % |  | 28.4 | % |  | 27.8 | % |
| % of net sales - Non - GAAP |  | 28.7 | % |  | 27.7 | % |  | 25.4 | % |  | 25.2 | % |
| Operating income - GAAP |  | $ | 32,144 |  |  | $ | 42,227 |  |  | $ | 276,495 |  |  | $ | 263,194 |  |
| Share-based compensation expense |  | 14,569 |  |  | 13,102 |  |  | 54,870 |  |  | 50,265 |  |
| Amortization of intangible assets |  | 8,900 |  |  | 6,944 |  |  | 30,858 |  |  | 24,180 |  |
| Purchase accounting effect on inventory |  | — |  |  | 34 |  |  | — |  |  | 1,756 |  |
| Acquisition-related costs |  | 57 |  |  | 240 |  |  | 1,490 |  |  | 1,696 |  |
| Change in fair value of contingent consideration for business acquisition (C) |  | 23,247 |  |  | — |  |  | 23,247 |  |  | — |  |
| Restructuring charges, net |  | 75 |  |  | 1,540 |  |  | 144 |  |  | 11,302 |  |
| Operating income - Non - GAAP |  | $ | 78,992 |  |  | $ | 64,087 |  |  | $ | 387,104 |  |  | $ | 352,393 |  |
| % of net sales - GAAP |  | 4.5 | % |  | 6.8 | % |  | 9.3 | % |  | 9.4 | % |
| % of net sales - Non - GAAP |  | 11.1 | % |  | 10.3 | % |  | 13.0 | % |  | 12.6 | % |
| Net income - GAAP |  | $ | 213,920 |  |  | $ | 42,121 |  |  | $ | 449,723 |  |  | $ | 257,573 |  |
| Share-based compensation expense |  | 14,569 |  |  | 13,102 |  |  | 54,870 |  |  | 50,265 |  |
| Amortization of intangible assets |  | 8,900 |  |  | 6,944 |  |  | 30,858 |  |  | 24,180 |  |
| Purchase accounting effect on inventory |  | — |  |  | 34 |  |  | — |  |  | 1,756 |  |
| Acquisition-related costs |  | 57 |  |  | 240 |  |  | 1,490 |  |  | 1,696 |  |
| Change in fair value of contingent consideration for business acquisition (C) |  | 23,247 |  |  | — |  |  | 23,247 |  |  | — |  |
| Restructuring charges, net |  | 75 |  |  | 1,540 |  |  | 144 |  |  | 11,302 |  |
| Gain on investments (D) |  | (39,783 | ) |  | (227 | ) |  | (39,011 | ) |  | (816 | ) |
| Non-GAAP income tax adjustment (A) |  | (150,048 | ) |  | 830 |  |  | (156,524 | ) |  | (6,952 | ) |
| Net income - Non - GAAP |  | $ | 70,937 |  |  | $ | 64,584 |  |  | $ | 364,797 |  |  | $ | 339,004 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  | $ | 1.26 |  |  | $ | 0.25 |  |  | $ | 2.66 |  |  | $ | 1.52 |  |
| Diluted - Non - GAAP |  | $ | 0.42 |  |  | $ | 0.38 |  |  | $ | 2.15 |  |  | $ | 2.01 |  |
| Shares used to compute net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP and Non - GAAP |  | 169,981 |  |  | 168,956 |  |  | 169,381 |  |  | 168,965 |  |

[0001032975-20-000011:8k_2_02:43]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
| SHARE-BASED COMPENSATION EXPENSE |  | Three Months Ended |  | Fiscal Years Ended |
|  |  | March 31, |  | March 31, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Share-based Compensation Expense |  |  |  |  |  |  |  |  |
| Cost of goods sold |  | $ | 1,300 |  |  | $ | 938 |  |  | $ | 4,852 |  |  | $ | 3,812 |  |
| Marketing and selling |  | 6,819 |  |  | 5,380 |  |  | 26,835 |  |  | 20,630 |  |
| Research and development |  | 2,629 |  |  | 2,073 |  |  | 9,273 |  |  | 7,368 |  |
| General and administrative |  | 3,821 |  |  | 4,711 |  |  | 13,910 |  |  | 18,455 |  |
| Total share-based compensation expense |  | 14,569 |  |  | 13,102 |  |  | 54,870 |  |  | 50,265 |  |
| Income tax benefit |  | (1,451 | ) |  | (2,515 | ) |  | (14,109 | ) |  | (17,091 | ) |
| Total share-based compensation expense, net of income tax benefit |  | $ | 13,118 |  |  | $ | 10,587 |  |  | $ | 40,761 |  |  | $ | 33,174 |  |

[0001032975-20-000011:8k_2_02:44]
*Note: These preliminary results for the three months and fiscal year ended March 31, 2020 are subject to adjustments, including subsequent events that may occur through the date of filing our Annual Report on Form 10-K.

[0001032975-20-000011:8k_2_02:45]
(A) Swiss Federal Tax Reform

[0001032975-20-000011:8k_2_02:46]
The change in the effective income tax rate between fiscal years 2020 and 2019 was primarily due to the mix of income and losses in the various tax jurisdictions in which we operate and the income tax accounting impact from the enactment of the Federal Act on Tax Reform and AHV Financing ("TRAF") in the canton of Vaud in Switzerland on March 10, 2020 to take effect as of January 1, 2020.  We have benefited from a longstanding tax ruling from the canton of Vaud through December 31, 2019.  We reached an agreement with the Vaud Tax Administration that waiving the benefits of the tax ruling would allow for a tax step-up to be amortized over ten years beginning on January 1, 2020.  TRAF generally permits a tax-free step-up of intangible assets, including goodwill created under a privileged tax regime or when assets are being transferred into Switzerland.  We recorded an income tax benefit of $151.7 million, net of unrecognized tax benefits to account for the book and tax basis difference of the step-up upon enactment.  The deferred income tax benefit from other temporary differences resulting from the Swiss tax reform, net of three-month amortization of the tax step-up amounted to $1.5 million. The aggregate deferred income tax impact in fiscal year 2020 as a result of the enactment of TRAF was $153.2 million.

[0001032975-20-000011:8k_2_02:47]
(B)  Adoption of ASC Topic 842

[0001032975-20-000011:8k_2_02:48]
We adopted the new standards for leases under Accounting Standards Codification ("ASC") Topic 842 using the modified retrospective approach as of April 1, 2019 and did not restate the financial statements of the comparative periods as is allowed by election of the transition option under ASC 842. Adoption of the standard resulted in the recognition of $25.6 million of right-of-use assets, $10.9 million of short-term lease liabilities and $19.5 million of long-term lease liabilities related to our leases on March 31, 2020.

[0001032975-20-000011:8k_2_02:49]
(C) Change in Fair Value of Contingent Consideration

[0001032975-20-000011:8k_2_02:50]
We recorded a $23.2 million change in fair value of contingent consideration due to Streamlabs performance, which we acquired on October 31, 2019.

[0001032975-20-000011:8k_2_02:51]
(D) Gain on Sale of Investment in a Privately Held Company

[0001032975-20-000011:8k_2_02:52]
We recorded a one-time gain of $39.8 million related to the sale of our investment in Lifesize, Inc. in exchange for cash plus an equity interest and subordinated note in another privately held company group as a result of its acquisition of Lifesize, Inc.

[0001032975-20-000011:8k_2_02:53]
(E) Non-GAAP Financial Measures

[0001032975-20-000011:8k_2_02:54]
To supplement our condensed consolidated financial results prepared in accordance with GAAP, we use a number of financial measures, both GAAP and non-GAAP, in analyzing and assessing our overall business performance, for making operating decisions and for forecasting and planning future periods. We consider the use of non-GAAP financial measures helpful in assessing our current financial performance, ongoing operations and prospects for the future as well as understanding financial and business trends relating to our financial condition and results of operations.

[0001032975-20-000011:8k_2_02:55]
While we use non-GAAP financial measures as a tool to enhance our understanding of certain aspects of our financial performance and to provide incremental insight into the underlying factors and trends affecting both our performance and our cash-generating potential, we do not consider these measures to be a substitute for, or superior to, the information provided by GAAP financial measures. Consistent with this approach, we believe that disclosing non-GAAP financial measures to the readers of our financial statements provides useful supplemental data that, while not a substitute for GAAP financial measures, can offer insight in the review of our financial and operational performance and enables investors to more fully understand trends in our current and future performance. In assessing our business during the quarter ended March 31, 2020 and previous periods, we excluded items in the following general categories, each of which are described below:

[0001032975-20-000011:8k_2_02:56]
Share-based compensation expenses. We believe that providing non-GAAP measures excluding share-based compensation expense, in addition to the GAAP measures, allows for a more transparent comparison of our financial results from period to period. We prepare and maintain our budgets and forecasts for future periods on a basis consistent with this non-GAAP financial measure. Further, companies use a variety of types of equity awards as well as a variety of methodologies, assumptions and estimates to determine share-based compensation expense. We believe that excluding share-based compensation expense enhances our ability and the ability of investors to understand the impact of non-cash share-based compensation on our operating results and to compare our results against the results of other companies.

[0001032975-20-000011:8k_2_02:57]
Amortization of intangible assets. We incur intangible asset amortization expense, primarily in connection with our acquisitions of various businesses and technologies. The amortization of purchased intangibles varies depending on the level of acquisition activity. We exclude these various charges in budgeting, planning and forecasting future periods and we believe that providing the non-GAAP measures excluding these various non-cash charges, as well as the GAAP measures, provides additional insight when comparing our gross profit, operating expenses, and financial results from period to period.

[0001032975-20-000011:8k_2_02:58]
Purchase accounting effect on inventory. Business combination accounting principles require us to measure acquired inventory at fair value. The fair value of inventory reflects the acquired company’s cost of manufacturing plus a portion of the expected profit margin. The non-GAAP adjustment excludes the expected profit margin component that is recorded under business combination accounting principles associated with our business acquisitions. We believe the adjustment is useful to investors because such charges are not reflective of our ongoing operations.

[0001032975-20-000011:8k_2_02:59]
Acquisition-related costs and change in fair value of contingent consideration for business acquisition.  We incurred expenses and credits in connection with our acquisitions which we generally would not have otherwise incurred in the periods presented as a part of our continuing operations. Acquisition related costs include all incremental expenses incurred to effect a business combination. Fair value of contingent consideration is associated with our estimates of the value of earn-outs in connection with certain acquisitions. We believe that providing the non-GAAP measures excluding these costs and credits, as well as the GAAP measures, assists our investors because such costs are not reflective of our ongoing operating results.

[0001032975-20-000011:8k_2_02:60]
Restructuring charges (credits). These expenses are associated with re-aligning our business strategies based on current economic conditions. We have undertaken several restructuring plans in recent years. In connection with our restructuring initiatives, we incurred restructuring charges related to employee terminations, facility closures and early cancellation of certain contracts. We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges (credits) are not reflective of our ongoing operating results in the current period.

[0001032975-20-000011:8k_2_02:61]
Loss (gain) on investments. We recognized loss (gain) related to our investments in various companies, which varies depending on the operational and financial performance of those companies in which we invested, and sales of these investments. We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges are not reflective of our ongoing operations.

[0001032975-20-000011:8k_2_02:62]
Non-GAAP income tax adjustment.  Non-GAAP income tax adjustment primarily measures the income tax effect of non-GAAP adjustments excluded above and other events; the determination of which is based upon the nature of the underlying items, the mix of income and losses in jurisdictions and the relevant tax rates in which we operate.

[0001032975-20-000011:8k_2_02:63]
Each of the non-GAAP financial measures described above, and used in this press release, should not be considered in isolation from, or as a substitute for, a measure of financial performance prepared in accordance with GAAP. Further, investors are cautioned that there are inherent limitations associated with the use of each of these non-GAAP financial measures as an analytical tool. In particular, these non-GAAP financial measures are not based on a comprehensive set of accounting rules or principles and many of the adjustments to the GAAP financial measures reflect the exclusion of items that are recurring and may be reflected in the Company’s financial results for the foreseeable future. We compensate for these limitations by providing specific information in the reconciliation included in this press release regarding the GAAP amounts excluded from the non-GAAP financial measures. In addition, as noted above, we evaluate the non-GAAP financial measures together with the most directly comparable GAAP financial information.

[0001032975-20-000011:8k_2_02:64]
Additional Supplemental Financial Information - Constant Currency

[0001032975-20-000011:8k_2_02:65]
In addition, Logitech presents percentage sales growth in constant currency to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales.
