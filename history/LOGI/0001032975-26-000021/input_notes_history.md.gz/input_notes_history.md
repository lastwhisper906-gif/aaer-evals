# LOGI note change history — 0001032975-25-000080 → 0001032975-26-000011


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2026-01-28):
[0001032975-26-000011:note_history:1]
Changes in the Company’s warranty liabilities for the three and nine months ended December 31, 2025 and 2024 were as follows (in thousands):
  (was, 2025-10-29, similarity 0.9621):
[0001032975-25-000080:note_history:1]
Changes in the Company’s warranty liabilities for the three and six months ended September 30, 2025 and 2024 were as follows (in thousands):

- changed (2026-01-28):
[0001032975-26-000011:note_history:2]
|  | Three Months Ended December 31, |  | Nine Months Ended December 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Beginning of the period | $ | 50,191 |  |  | $ | 46,833 |  |  | $ | 49,184 |  |  | $ | 44,654 |  |
| Provision | 9,430 |  |  | 12,060 |  |  | 28,424 |  |  | 34,022 |  |
| Settlements | (8,438) |  |  | (9,111) |  |  | (27,079) |  |  | (29,124) |  |
| Effects of foreign currency translation | 260 |  |  | (721) |  |  | 914 |  |  | (491) |  |
| End of the period | $ | 51,443 |  |  | $ | 49,061 |  |  | $ | 51,443 |  |  | $ | 49,061 |  |
  (was, 2025-10-29, similarity 0.9281):
[0001032975-25-000080:note_history:2]
|  | Three Months Ended September 30, |  | Six Months Ended September 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Beginning of the period | $ | 50,206 |  |  | $ | 44,502 |  |  | $ | 49,184 |  |  | $ | 44,654 |  |
| Provision | 10,372 |  |  | 11,776 |  |  | 18,994 |  |  | 21,962 |  |
| Settlements | (10,392) |  |  | (9,975) |  |  | (18,641) |  |  | (20,013) |  |
| Effects of foreign currency translation | 5 |  |  | 530 |  |  | 654 |  |  | 230 |  |
| End of the period | $ | 50,191 |  |  | $ | 46,833 |  |  | $ | 50,191 |  |  | $ | 46,833 |  |

- changed (2026-01-28):
[0001032975-26-000011:note_history:3]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of December 31, 2025, no material amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.
  (was, 2025-10-29, similarity 0.9946):
[0001032975-25-000080:note_history:3]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of September 30, 2025, no material amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2026-01-28):
[0001032975-26-000011:note_history:4]
Logitech was founded in Switzerland in 1981 and Logitech International S.A. has been the parent holding company of Logitech since 1988. Logitech International S.A. is a Swiss holding company with its registered office in Hautemorges, Switzerland, and headquarters in Lausanne, Switzerland, which conducts its business through subsidiaries in the Americas; Europe, the Middle East and Africa ("EMEA"); and Asia Pacific. Shares of Logitech International S.A. are listed on both the SIX Swiss Exchange under the trading symbol LOGN and the Nasdaq Global Select Market under the trading symbol LOGI.
  (was, 2025-10-29, similarity 0.994):
[0001032975-25-000080:note_history:4]
Logitech was founded in Switzerland in 1981 and Logitech International S.A. has been the parent holding company of Logitech since 1988. Logitech International S.A. is a Swiss holding company with its registered office in Hautemorges, Switzerland, and headquarters in Lausanne, Switzerland, which conducts its business through subsidiaries in the Americas, Europe, Middle East and Africa ("EMEA") and Asia Pacific. Shares of Logitech International S.A. are listed on both the SIX Swiss Exchange under the trading symbol LOGN and the Nasdaq Global Select Market under the trading symbol LOGI.

- changed (2026-01-28):
[0001032975-26-000011:note_history:5]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and nine months ended December 31, 2025 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2026, or any future periods.
  (was, 2025-10-29, similarity 0.9623):
[0001032975-25-000080:note_history:5]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and six months ended September 30, 2025 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2026, or any future periods.

- changed (2026-01-28):
[0001032975-26-000011:note_history:6]
There have been no material changes in the Company’s significant accounting policies during the three and nine months ended December 31, 2025 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2025.
  (was, 2025-10-29, similarity 0.9208):
[0001032975-25-000080:note_history:6]
There have been no material changes in the Company’s significant accounting policies during the three and six months ended September 30, 2025 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2025.

- changed (2026-01-28):
[0001032975-26-000011:note_history:7]
Impacts of Macroeconomic, Geopolitical, and Other Factors on the Company's Business
  (was, 2025-10-29, similarity 0.8447):
[0001032975-25-000080:note_history:7]
Impacts of Macroeconomic and Geopolitical Conditions on the Company's Business

- added (2026-01-28):
[0001032975-26-000011:note_history:8]
In 2025, the United States introduced trade policy actions that have increased import tariffs across a wide range of countries at various rates, with certain exemptions. These tariff policies in the U.S. and responsive policies enacted in other countries are evolving. The incremental tariffs have had and may continue to have an adverse impact on the Company's results of operations. The Company may also be affected by the increases in demand for memory chips and other components caused by the build out of new AI technologies and data centers, leading to a rise in prices for such components and suppliers transitioning away from supplying certain components utilized in the manufacturing of some of the Company’s Video Collaboration products. In addition, the Company's business has continued to be impacted by ongoing macroeconomic and geopolitical conditions. These conditions include inflation, interest rate and foreign currency fluctuations, uncertainty in consumer and enterprise demand, low economic growth in certain regions, changes in fiscal policies and geopolitical conflicts.

- added (2026-01-28):
[0001032975-26-000011:note_history:9]
The global and regional macroeconomic and political conditions, as well as changes in trade policies and memory supply, have caused and may continue to cause volatility in demand for the Company's products, component availability, transit times, and cost of the Company's products including cost of tariffs, materials, and logistics, and as a result, have impacted and may continue to impact the pricing of the Company's products, product availability and the Company's results of operations.

- removed (2026-01-28):
[0001032975-25-000080:note_history:10]
In 2025, the United States introduced trade policy actions that have increased import tariffs across a wide range of countries at various rates, with certain exemptions. These tariff policies in the U.S. and responsive policies enacted in other countries are evolving. The incremental tariffs have had and may continue to have an adverse impact on the Company's results of operations. In addition, the Company's business has continued to be impacted by ongoing macroeconomic and geopolitical conditions. These conditions include inflation, interest rate and foreign currency fluctuations, uncertainty in consumer and enterprise demand, low economic growth in certain regions, changes in fiscal policies and geopolitical conflicts.

- removed (2026-01-28):
[0001032975-25-000080:note_history:11]
The global and regional economic and political conditions, as well as changes in trade policies, have caused and may continue to cause volatility in demand for the Company's products as well as the cost of tariffs, materials and logistics, and transportation delays, and as a result have impacted and may continue to impact the pricing of the Company's products, product availability and the Company's results of operations.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-01-28):
[0001032975-26-000011:note_history:12]
The Credit Agreement contains a maximum net debt to adjusted EBITDA ratio, compliance with which is a condition to the Company's ability to borrow. Borrowings under the Credit Agreement will bear interest at a rate determined by reference to benchmark rates plus an applicable spread (ranging from 0% to 1.5%) based on the Company's net leverage ratio or credit rating at the time of the borrowing. Undrawn balances available under the Credit Agreement are subject to commitment fees at the applicable rate determined by reference to the Company's net leverage ratio or credit rating. There has been no borrowing outstanding under the Credit Agreement as of December 31, 2025.
In addition, the Company had several uncommitted, unsecured bank lines of credit and letters of credit aggregating to $164.0 million and $172.2 million as of December 31, 2025 and March 31, 2025, respectively. There are no financial covenants under the lines of credit with which the Company must comply. There was no borrowing outstanding under the lines of credit as of December 31, 2025 or March 31, 2025. As of December 31, 2025 and March 31, 2025, the Company had outstanding bank guarantees of $8.5 million and $12.1 million, respectively.
  (was, 2025-10-29, similarity 0.9632):
[0001032975-25-000080:note_history:12]
The Credit Agreement contains a maximum net debt to adjusted EBITDA ratio, compliance with which is a condition to the Company's ability to borrow. Borrowings under the Credit Agreement will bear interest at a rate determined by reference to benchmark rates plus an applicable spread (ranging from 0% to 1.5%) based on the Company's net leverage ratio or credit rating at the time of the borrowing. Undrawn balances available under the Credit Agreement are subject to commitment fees at the applicable rate determined by reference to the Company's net leverage ratio or credit rating. There has been no borrowing outstanding under the Credit Agreement as of September 30, 2025.
In addition, the Company had several uncommitted, unsecured bank lines of credit and letters of credit aggregating to $160.9 million and $172.2 million as of September 30, 2025 and March 31, 2025, respectively. There are no financial covenants under the lines of credit with which the Company must comply. There was no borrowing outstanding under the lines of credit as of September 30, 2025 or March 31, 2025. As of September 30, 2025 and March 31, 2025, the Company had outstanding bank guarantees of $11.7 million and $12.1 million, respectively.
