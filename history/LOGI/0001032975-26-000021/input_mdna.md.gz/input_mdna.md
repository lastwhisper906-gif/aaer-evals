# LOGI MD&A — 0001032975-26-000021


## mdna

[0001032975-26-000021:mdna:1]
ITEM 7.    MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001032975-26-000021:mdna:2]
Company Overview

[0001032975-26-000021:mdna:3]
Logitech designs software-enabled hardware solutions that help businesses thrive and bring people together when working, creating, and gaming. As the point of connection between people and the digital world, our mission is to extend human potential in work and play, in a way that is good for people and the planet. We sell the vast majority of our products under the Logitech and Logitech G brand names.

[0001032975-26-000021:mdna:4]
Our diverse, innovative portfolio includes: Gaming, Keyboards & Combos, Pointing Devices, Video Collaboration, Webcams, Tablet Accessories, and Headsets. These products are all classified under a single operating segment: Peripherals (see Note 15 to our consolidated financial statements).

[0001032975-26-000021:mdna:5]
We sell our products to a broad range of international customers, in the Americas; Europe, the Middle East and Africa (“EMEA”); and Asia Pacific. This includes direct sales to retailers, e-tailers, businesses large and small and end consumers through our e-commerce platform, and indirect sales to end customers through distributors.

[0001032975-26-000021:mdna:6]
From time to time, we may seek to partner with or acquire, when appropriate, companies that have products, personnel, and technologies that complement our strategic direction. We continually review our product offerings and our strategic direction in light of our profitability targets, competitive conditions, changing consumer trends and the evolving nature of the interface between the consumer and the digital world.

[0001032975-26-000021:mdna:7]
Impacts of Macroeconomic, Geopolitical, and Other Factors on our Business

[0001032975-26-000021:mdna:8]
As we conduct operations globally, our business has continued to be impacted by ongoing macroeconomic and geopolitical conditions. These conditions include changes in inflation, interest rate and foreign currency fluctuations, uncertainty in consumer and enterprise demand, tariff and trade policies, memory chip availability, volatile energy prices and increased geopolitical tensions, including the armed conflicts in the Middle East.

[0001032975-26-000021:mdna:9]
In 2025, the United States introduced trade policy actions that increased import tariffs across a wide range of countries at various rates, with certain exemptions. In February 2026, the U.S. Supreme Court issued a decision invalidating certain tariffs previously imposed under the International Emergency Economic Powers Act. In May 2026, some companies began receiving notification from the U.S. Customs and Border Protection (CBP) that tariff refunds would be issued; however, the extent and timing of these tariff refunds remain uncertain. Following the U.S. Supreme Court ruling, the U.S. government introduced new temporary tariffs for a 150-day period beginning February 24, 2026. In May 2026, the U.S. Court of International Trade invalidated these temporary tariffs but they remain in place, subject to appeal. The U.S. government may pursue alternative trade measures, including under Sections 301 and 302 of U.S. trade laws, which could result in additional or replacement tariffs. U.S. tariff policies and international trade arrangements continue to evolve and have had, and may continue to have, a significant impact on our results of operations.

[0001032975-26-000021:mdna:10]
We have also been affected by the increases in demand for memory chips and other components caused by the build out of new AI technologies and data centers, leading to a rise in prices for such components and some suppliers transitioning capacity away from certain components utilized in some of our Video Collaboration products.

[0001032975-26-000021:mdna:11]
The global and regional macroeconomic, political and other conditions have caused and may continue to cause volatility in demand for our products, component availability, transit times and cost of our products including cost of tariffs, materials, and logistics, and as a result, have impacted and may continue to impact the pricing of our products, product availability and our results of operations.

[0001032975-26-000021:mdna:12]
For additional information, see Part I, Item 1A "Risk Factors."

[0001032975-26-000021:mdna:13]
Trends and Uncertainties

[0001032975-26-000021:mdna:14]
Several long-term secular-trends offer long-term structural growth opportunities across Logitech’s product portfolio. We design, create and sell products that benefit from these secular trends which include the following:

[0001032975-26-000021:mdna:15]
•AI: AI is reshaping expectations for product innovation, productivity improvements, and the evolution of digital technology ecosystems. AI is embedded in our innovation strategy and product development, enabling us to provide elevated audio, video, and other capabilities throughout our product portfolio, and we plan to continue to integrate AI into future products. Our products are also designed to help people increase productivity and improve performance, leveraging AI benefits across work and play. Logitech’s products are the connection between people and the digital world, providing a broad range of devices that facilitate interaction with AI. Our video collaboration products, webcams, headsets, mice and keyboards serve as the eyes, ears and hands of AI, providing the sensory channels through which our customers experience AI. In addition, we leverage AI internally to accelerate new product introductions, strengthen marketing effectiveness and optimize operational processes across our organization.

[0001032975-26-000021:mdna:16]
•Flexible work: As flexible work models continue to evolve, with employees working from offices, homes and various remote locations, Logitech is well-positioned to meet the demand for versatile and adaptive workplace technology. These working arrangements provide opportunities for Logitech to equip multiple workspaces with products across our portfolio including Pointing Devices, Keyboards & Combos, Tablet Accessories, Headsets and Webcams. Additionally, the rise in distributed teams and remote collaboration is driving increased adoption of video conferencing solutions among businesses and consumers. Our portfolio of video collaboration products are compatible with a variety of video conference platforms, including Zoom, Microsoft Teams and Google Meet.

[0001032975-26-000021:mdna:17]
•Gaming growth: The ongoing growth and evolution of gaming creates an opportunity for us to provide more tools to a wider community of gamers. Gaming is enjoyed by men and women of all ages; competitively as a sport or for fun; for active participation and passive consumption; for personal development or social interaction. As a mainstream activity, gaming continues to gain popularity through online gaming, multi-platform experiences and esports.

[0001032975-26-000021:mdna:18]
While we believe we will further benefit from these secular trends, we have experienced and will continue to experience challenges that impact our business and financial results. These challenges include (i) uncertainty in tariffs on goods imported into the U.S. and responsive policies enacted by other countries, (ii) uncertainty in supply and pricing of memory chips and other components, (iii) the macroeconomic environment, including inflation, interest rate and foreign currency fluctuations, volatile energy prices, and increased geopolitical tensions, and (iv) the uncertainty of overall consumer and enterprise demand.

[0001032975-26-000021:mdna:19]
We expect these challenges to continue in the near-term. We have taken steps to mitigate the impact of these challenges, including but not limited to: (i) continued diversification of our manufacturing footprint and supplier ecosystem, (ii) increasing pricing for certain products, (iii) maintaining discipline in our operating expenses, (iv) managing inventory levels to align with demand and component availability, and (v) continued release of new products to increase the value proposition of our portfolio.

[0001032975-26-000021:mdna:20]
For additional information, see Part I, Item 1A “Risk Factors.”

[0001032975-26-000021:mdna:21]
Seasonality

[0001032975-26-000021:mdna:22]
We experience seasonal trends related to our product sales. Sales are generally highest during our third fiscal quarter (October to December) primarily due to increased consumer demand during the holiday season and increased spending by businesses in the months nearing the calendar year-end. Cash flow is usually correspondingly lower in the first half of our fiscal year, as we typically build inventories in advance of our third fiscal quarter and we also pay an annual dividend following our Annual General Meeting typically held in September.

[0001032975-26-000021:mdna:23]
Summary of Financial Results

[0001032975-26-000021:mdna:24]
Our sales for fiscal year 2026 increased 6%, compared to fiscal year 2025, primarily driven by an increase in sales of Gaming, Pointing Devices, Video Collaboration, and Keyboards & Combos, due to improved demand as well as favorable changes in foreign currency exchange rates.

[0001032975-26-000021:mdna:25]
Sales for fiscal year 2026 increased 15% and 9% in the Asia Pacific and EMEA regions, respectively, and decreased 1% in the Americas regions, compared to fiscal year 2025.

[0001032975-26-000021:mdna:26]
Gross margin for fiscal year 2026 increased by 10 basis points to 43.2%, compared to 43.1% for fiscal year 2025, primarily driven by price increases in North America, product cost reductions, and favorable foreign currency exchange rate changes, substantially offset by investment in strategic promotions and increased tariffs.

[0001032975-26-000021:mdna:27]
Operating expenses for fiscal year 2026 were $1,316.1 million, or 27.2% of sales, compared to $1,307.7 million, or 28.7% of sales, for fiscal year 2025.

[0001032975-26-000021:mdna:28]
We had an income tax provision of $115.3 million for fiscal year 2026, compared to $75.3 million for fiscal year 2025, primarily driven by the expiration of statutes of limitation of uncertain tax positions in fiscal years 2026 and 2025, and the tax effect of audit resolutions in fiscal year 2025.

[0001032975-26-000021:mdna:29]
Net income for fiscal year 2026 was $711.2 million, compared to $631.5 million for fiscal year 2025, reflecting higher gross profit driven by higher demand, partially offset by higher income tax provision.

[0001032975-26-000021:mdna:30]
Critical Accounting Estimates

[0001032975-26-000021:mdna:31]
The preparation of financial statements and related disclosures in conformity with U.S. GAAP requires us to make assumptions, judgments, and estimates that affect reported amounts of assets, liabilities, sales and expenses, and the disclosure of contingent assets and liabilities.

[0001032975-26-000021:mdna:32]
We consider an accounting estimate critical if it: (i) requires management to make judgments and estimates about matters that are inherently uncertain; and (ii) is important to an understanding of our financial condition and operating results.

[0001032975-26-000021:mdna:33]
We base our assumptions, judgments and estimates on historical experience and various other factors that we believe to be reasonable under the circumstances. Although these assumptions, judgments, and estimates are based on management's best knowledge of current events and actions that may impact us in the future, actual results could differ. Management has discussed the development, selection and disclosure of these critical accounting estimates with the Audit Committee of the Board of Directors.

[0001032975-26-000021:mdna:34]
We believe the following accounting estimates are most critical to our business operations and to an understanding of our financial condition and results of operations and reflect the more significant judgments and estimates used in the preparation of our consolidated financial statements.

[0001032975-26-000021:mdna:35]
Accruals for Customer Programs and Product Returns

[0001032975-26-000021:mdna:36]
We record accruals for cooperative marketing, customer incentive, pricing programs ("Customer Programs") and product returns. The estimated cost of these programs is usually recorded as a reduction of revenue. Significant management judgments and estimates must be used to determine the cost of these programs in any accounting period. Customer Programs require management to estimate the percentage of those programs that will not be claimed in the current period or will not be earned by customers, which is commonly referred to as "breakage." Breakage is estimated based on historical claim experience, the period in which the claims are expected to be submitted, specific terms and conditions with customers, and other factors. If we receive a separately identifiable benefit from a customer and can reasonably estimate the fair value of that benefit, the cost of the Customer Programs is recognized in operating expenses.

[0001032975-26-000021:mdna:37]
Customer Incentive Programs. Customer incentive programs include performance-based incentives and consumer rebates. We offer performance-based incentives to our customers and indirect partners based on predetermined performance criteria. Consumer rebates are offered from time to time at our discretion for the primary benefit of end-users. Customer incentive programs are considered variable consideration, which we estimate and record as a reduction to revenue at the time of sale based on negotiated terms, historical experiences, forecasted incentives, the anticipated volume of future purchases, and inventory levels in the channel.

[0001032975-26-000021:mdna:38]
Product Returns. We grant limited rights to return products. Return rights vary by customer and range from just the right to return the defective product to stock rotation rights limited to a percentage of sales approved by management. Estimates of expected future product returns are recognized at the time of sale based on analyses of historical return trends by the customer and by product, inventories owned by and located at customers, current customer demand, current operating conditions, and other relevant customer and product information. Upon recognition, we reduce sales and cost of goods sold for the estimated return. Return trends are influenced by product life cycle status, new product introductions, market acceptance of products, sales levels, product sell-through, the type of customer, seasonality, product quality issues, competitive pressures, operational policies and procedures, and other factors. Return rates can fluctuate over time but are sufficiently predictable to allow us to estimate expected future product returns.

[0001032975-26-000021:mdna:39]
We apply a breakage rate to reduce our accruals of Customer Programs based on the estimated percentage of these Customer Programs that will not be claimed or earned. The breakage rate is applied at the time of sale. Assessing the period in which claims are expected to be submitted and the relevance of the historical claim experience require significant management judgment to estimate the breakage of Customer Programs in any accounting period.

[0001032975-26-000021:mdna:40]
We regularly evaluate the adequacy of our accruals for Customer Programs and product returns. Future market conditions and product transitions may require us to take action to increase such programs. In addition, when the variables used to estimate these costs change, or if actual costs differ significantly from the estimates, we would be required to record incremental increases or reductions to revenue or operating expenses.

[0001032975-26-000021:mdna:41]
Inventory Valuation

[0001032975-26-000021:mdna:42]
We must order components for our products and build inventory in advance of customer orders. Further, our industry is characterized by rapid technological change, short-term customer commitments and rapid changes in demand.

[0001032975-26-000021:mdna:43]
We record inventories at the lower of cost and net realizable value and record write-downs of inventories that are obsolete or in excess of anticipated demand or net realizable value. A review of inventory is performed each fiscal quarter that considers factors including the marketability and product lifecycle stage, product development plans, component cost trends, historical sales, and demand forecasts that consider the assumptions about future demand and market conditions. Inventory on hand that is not expected to be sold or utilized is considered excess, and we recognize the write-down in the cost of goods sold at the time of such determination. The write-down is determined by the excess of cost over net realizable value. Net realizable value is the estimated selling price in the ordinary course of business, less reasonably predictable costs of completion, disposal and transportation. At the time of loss recognition, new cost basis per unit and the lower-cost basis for that inventory are established and subsequent changes in facts and circumstances would not result in an increase in the cost basis. If there is an abrupt and substantial decline in demand for Logitech's products or an unanticipated change in technological or customer requirements, we may be required to record additional write-downs that could adversely affect gross margins in the period when the write-downs are recorded. We also extend the assessment to non-cancelable purchase orders if the inventories are considered excess and record the liability that is reasonably possible to be incurred in accrued and other liabilities.

[0001032975-26-000021:mdna:44]
Accounting for Income Taxes

[0001032975-26-000021:mdna:45]
We operate in multiple jurisdictions and our profits are taxed pursuant to the tax laws of these jurisdictions. Our effective income tax rate may be affected by the changes in or interpretations of tax laws and tax agreements in any given jurisdiction, utilization of net operating loss and tax credit carryforwards, changes in geographical mix of income and expense, and changes in our assessment of matters such as the ability to realize deferred tax assets. As a result of these considerations, we must estimate income taxes in each of the jurisdictions in which we operate. This process involves estimating current tax exposure together with assessing temporary differences resulting from the different treatment of items for tax and accounting purposes. These differences result in deferred tax assets and liabilities, which are included in the consolidated balance sheet.

[0001032975-26-000021:mdna:46]
We make certain estimates and judgments about the application of tax laws, the expected resolution of uncertain tax positions and other matters surrounding the recognition and measurement of uncertain tax benefits. In the event that uncertain tax positions are resolved for amounts different than our estimates, or the related statutes of limitations expire without the assessment of additional income taxes, we will be required to adjust the amounts of the related assets and liabilities in the period in which such events occur. Such adjustments may have a material impact on our income tax provision and our results of operations.

[0001032975-26-000021:mdna:47]
For additional information about our Critical Accounting Estimates, see Note 2—Summary of Significant Accounting Policies in our Notes to our consolidated financial statements.

[0001032975-26-000021:mdna:48]
New Accounting Pronouncements

[0001032975-26-000021:mdna:49]
Refer to Note 2 to the consolidated financial statements included in this Annual Report on Form 10-K for recent accounting pronouncements adopted and to be adopted.

[0001032975-26-000021:mdna:50]
Constant Currency

[0001032975-26-000021:mdna:51]
We refer to our net sales growth rates excluding the impact of currency exchange rate fluctuations as "constant currency" sales growth rates. Percentage of constant currency sales growth is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales.

[0001032975-26-000021:mdna:52]
Given our global sales presence and the reporting of our financial results in U.S. Dollars, our financial results could be affected by significant shifts in currency exchange rates. See “Results of Operations” for information on the effect of currency exchange rate fluctuations on our sales. If the U.S. Dollar appreciates or depreciates in comparison to other currencies in future periods, this will affect our results of operations in future periods as well.

[0001032975-26-000021:mdna:53]
References to Sales

[0001032975-26-000021:mdna:54]
The term “sales” means net sales, except as otherwise specified and the sales growth discussion and sales growth rate percentages are in U.S. Dollars, except as otherwise specified.

[0001032975-26-000021:mdna:55]
Results of Operations

[0001032975-26-000021:mdna:56]
In this section, we discuss the results of our operations for the year ended March 31, 2026 compared to the year ended March 31, 2025. For a discussion of the year ended March 31, 2025 compared to the year ended March 31, 2024, please refer to Part II, Item 7, "Management's Discussion and Analysis of Financial Condition and Results of Operations" in our Annual Report on Form 10-K filed with the SEC on May 23, 2025.

[0001032975-26-000021:mdna:57]
Net Sales

[0001032975-26-000021:mdna:58]
Our sales in fiscal year 2026 increased 6%, compared to fiscal year 2025, primarily driven by an increase in sales of Gaming, Pointing Devices, Video Collaboration, and Keyboards & Combos, due to improved demand. Our sales for the fiscal year ended 2026, compared to the fiscal year ended 2025, benefited from improved demand in the Asia Pacific and EMEA regions as well as favorable foreign currency exchange rate changes. If currency exchange rates had been constant in fiscal years 2026 and 2025, our sales growth rate in constant currency would have been 4%.

[0001032975-26-000021:mdna:59]
Sales Denominated in Other Currencies

[0001032975-26-000021:mdna:60]
Although our financial results are reported in U.S. Dollars, a portion of our sales was generated in currencies other than the U.S. Dollar, such as the Euro, Chinese Renminbi, Japanese Yen, Australian Dollar, Canadian Dollar, Pound Sterling and New Taiwan Dollar. For the years ended March 31, 2026 and 2025, approximately 52% and 49%, respectively, of our sales were denominated in currencies other than the U.S. Dollar.

[0001032975-26-000021:mdna:61]
Sales by Region

[0001032975-26-000021:mdna:62]
The following table presents the change in sales by region for fiscal year 2026 compared with fiscal year 2025:

[0001032975-26-000021:mdna:63]
|  |  | 2026 vs. 2025 |  |  |
|  |  | Sales Growth Rate |  | Sales Growth Rate in Constant Currency |  |  |  |  |
| Americas |  | (1) | % |  | (1) | % |  |  |  |  |
| EMEA |  | 9 |  |  | 3 |  |  |  |  |  |
| Asia Pacific |  | 15 |  |  | 15 |  |  |  |  |  |

[0001032975-26-000021:mdna:64]
Americas

[0001032975-26-000021:mdna:65]
The decrease in sales in the Americas region for fiscal year 2026, compared to fiscal year 2025, was primarily driven by a decrease in sales of Gaming, partially offset by an increase in sales of Pointing Devices and Video Collaboration. The decline in Gaming sales for fiscal year 2026 was primarily driven by a decline in the Gaming market in the region during a substantial portion of the fiscal year and a competitive pricing environment in North America.

[0001032975-26-000021:mdna:66]
EMEA

[0001032975-26-000021:mdna:67]
The increase in sales in the EMEA region for fiscal year 2026, compared to fiscal year 2025, was primarily driven by an increase in sales of Video Collaboration, Gaming, Keyboards & Combos, and Pointing Devices.

[0001032975-26-000021:mdna:68]
Asia Pacific

[0001032975-26-000021:mdna:69]
The increase in sales in the Asia Pacific region for fiscal year 2026, compared to fiscal year 2025, was primarily driven by an increase in sales of Gaming, Tablet Accessories, and Pointing Devices. Our sales growth was fueled by strong market growth in the region during the fiscal year, particularly in Gaming.

[0001032975-26-000021:mdna:70]
Sales by Product Category

[0001032975-26-000021:mdna:71]
Sales by product category for fiscal years 2026 and 2025 were as follows (Dollars in thousands):

[0001032975-26-000021:mdna:72]
|  |  | Years Ended March 31, |  | Change |
|  |  | 2026 |  | 2025 |  | 2026 vs. 2025 |
| Gaming (1) |  | $ | 1,414,206 |  |  | $ | 1,338,467 |  |  | 6 | % |
| Keyboards & Combos |  | 937,551 |  |  | 882,643 |  |  | 6 |  |
| Pointing Devices |  | 858,904 |  |  | 788,784 |  |  | 9 |  |
| Video Collaboration |  | 689,040 |  |  | 626,000 |  |  | 10 |  |
| Webcams |  | 326,172 |  |  | 315,520 |  |  | 3 |  |
| Tablet Accessories |  | 336,189 |  |  | 299,540 |  |  | 12 |  |
| Headsets |  | 179,825 |  |  | 179,710 |  |  | — |  |
| Other (2) |  | 98,874 |  |  | 124,236 |  |  | (20) |  |
| Total Sales |  | $ | 4,840,761 |  |  | $ | 4,554,900 |  |  | 6 | % |

[0001032975-26-000021:mdna:73]
(1) Gaming includes streaming services revenue generated by Streamlabs.

[0001032975-26-000021:mdna:74]
(2) Other primarily consists of mobile speakers and PC speakers.

[0001032975-26-000021:mdna:75]
Gaming

[0001032975-26-000021:mdna:76]
Our Gaming category includes PC gaming (mice, headsets, keyboards), steering wheels, console gaming headsets, microphones and Streamlabs services.

[0001032975-26-000021:mdna:77]
During fiscal year 2026, Gaming sales increased 6%, compared to fiscal year 2025, primarily driven by increases in sales of PC gaming mice and steering wheels, partially offset by a decrease in sales of other gaming products. Sales growth in Asia Pacific and EMEA, were partially offset by a decline in sales in the Americas region.

[0001032975-26-000021:mdna:78]
Keyboards & Combos

[0001032975-26-000021:mdna:79]
Our Keyboards & Combos category includes PC keyboards and keyboard/mice combo products.

[0001032975-26-000021:mdna:80]
During fiscal year 2026, Keyboards & Combos sales increased 6%, compared to fiscal year 2025, primarily driven by an increase in sales of our cordless combo products.

[0001032975-26-000021:mdna:81]
Pointing Devices

[0001032975-26-000021:mdna:82]
Our Pointing Devices category includes PC- and Mac-related mice including trackballs, and presentation tools.

[0001032975-26-000021:mdna:83]
During fiscal year 2026, Pointing Devices sales increased 9%, compared to fiscal year 2025, primarily driven by an increase in sales of cordless mice.

[0001032975-26-000021:mdna:84]
Video Collaboration

[0001032975-26-000021:mdna:85]
Our Video Collaboration category includes Logitech’s conference room cameras, which combine affordable enterprise-quality audio and high definition 4K video to bring video conferencing to a variety of room sizes.

[0001032975-26-000021:mdna:86]
During fiscal year 2026, Video Collaboration sales increased 10%, compared to fiscal year 2025, primarily due to an increase in sales of conference room cameras.

[0001032975-26-000021:mdna:87]
Webcams

[0001032975-26-000021:mdna:88]
Our Webcams category includes webcams and streaming cameras. Our webcams turn any desktop into an instant collaboration space.

[0001032975-26-000021:mdna:89]
During fiscal year 2026, Webcams sales increased 3%, compared to fiscal year 2025, primarily driven by an increase in sales in our Americas and EMEA regions, partially offset by declining sales in the Asia Pacific region.

[0001032975-26-000021:mdna:90]
Tablet Accessories

[0001032975-26-000021:mdna:91]
Our Tablet Accessories category primarily includes tablet keyboards.

[0001032975-26-000021:mdna:92]
During fiscal year 2026, Tablet Accessories sales increased 12%, compared to fiscal year 2025, primarily benefiting from strong sales from the education sector, particularly in our Asia Pacific region.

[0001032975-26-000021:mdna:93]
Headsets

[0001032975-26-000021:mdna:94]
Our Headsets category includes headsets, in-ear headphones, and premium wireless earbuds.

[0001032975-26-000021:mdna:95]
During fiscal year 2026, Headsets sales remained flat compared to 2025.

[0001032975-26-000021:mdna:96]
Other

[0001032975-26-000021:mdna:97]
Our Other category primarily consists of mobile speakers and PC speakers.

[0001032975-26-000021:mdna:98]
During fiscal year 2026, Other sales decreased 20% compared to 2025, primarily driven by a decrease in sales of mobile speakers.

[0001032975-26-000021:mdna:99]
Gross Profit

[0001032975-26-000021:mdna:100]
Gross profit for fiscal years 2026 and 2025 was as follows (Dollars in thousands):

[0001032975-26-000021:mdna:101]
|  |  | Years Ended March 31, |
|  |  | 2026 |  | 2025 |  | Change |
| Net sales |  | $ | 4,840,761 |  |  | $ | 4,554,900 |  |  | 6 | % |
| Gross profit |  | $ | 2,091,337 |  |  | $ | 1,962,601 |  |  | 7 | % |
| Gross margin |  | 43.2 | % |  | 43.1 | % |  |  |

[0001032975-26-000021:mdna:102]
Gross profit consists of sales, less cost of goods sold (which includes materials, direct labor and related overhead costs, costs of manufacturing facilities, royalties, costs of purchasing components from outside suppliers, distribution costs, warranty costs, customer support costs, shipping and handling costs, outside processing costs and write-down of inventories), and amortization of intangible assets.

[0001032975-26-000021:mdna:103]
Gross margin increased by 10 basis points to 43.2% during fiscal year 2026, compared to 43.1% during fiscal year 2025. The increase in gross margin was primarily driven by price increases in North America, product cost reductions, and favorable foreign currency exchange rate changes, substantially offset by investment in strategic promotions and increased tariffs.

[0001032975-26-000021:mdna:104]
Operating Expenses

[0001032975-26-000021:mdna:105]
Operating expenses for fiscal years 2026 and 2025 were as follows (Dollars in thousands):

[0001032975-26-000021:mdna:106]
|  |  | Years Ended March 31, |
|  |  | 2026 |  | 2025 |  |  |
| Marketing and selling |  | $ | 816,604 |  |  | $ | 814,414 |  |  |  |
| % of sales |  | 16.9 | % |  | 17.9 | % |  |  |
| Research and development |  | 316,221 |  |  | 309,008 |  |  |  |
| % of sales |  | 6.5 | % |  | 6.8 | % |  |  |
| General and administrative |  | 167,160 |  |  | 164,014 |  |  |  |
| % of sales |  | 3.5 | % |  | 3.6 | % |  |  |
| Amortization of intangible assets and acquisition-related costs |  | 6,298 |  |  | 10,695 |  |  |  |
| % of sales |  | 0.1 | % |  | 0.2 | % |  |  |
| Restructuring charges, net |  | 9,860 |  |  | 9,615 |  |  |  |
| % of sales |  | 0.2 | % |  | 0.2 | % |  |  |
| Total operating expenses |  | $ | 1,316,143 |  |  | $ | 1,307,746 |  |  |  |
| % of sales |  | 27.2 | % |  | 28.7 | % |  |  |

[0001032975-26-000021:mdna:107]
The increase in total operating expenses during fiscal year 2026, compared to fiscal year 2025, was primarily due to an increase in research and development expense.

[0001032975-26-000021:mdna:108]
Marketing and Selling

[0001032975-26-000021:mdna:109]
Marketing and selling expenses consist of personnel and related overhead costs, corporate and product marketing, advertising, trade shows, technical support for customer experiences and facilities costs.

[0001032975-26-000021:mdna:110]
During fiscal year 2026, marketing and selling expenses increased $2.2 million, compared to fiscal year 2025, primarily driven by increased investment in marketing and selling, partially offset by a provision for credit loss on accounts receivable recorded in fiscal year 2025.

[0001032975-26-000021:mdna:111]
Research and Development

[0001032975-26-000021:mdna:112]
Research and development expenses consist of personnel and related overhead costs, fees for contractors and outside consultants, supplies and materials, equipment depreciation and facilities costs, all associated with the design and development of new products and enhancements of existing products.

[0001032975-26-000021:mdna:113]
During fiscal year 2026, research and development expenses increased $7.2 million, compared to fiscal year 2025, primarily driven by increased investment in product innovation.

[0001032975-26-000021:mdna:114]
General and Administrative

[0001032975-26-000021:mdna:115]
General and administrative expenses primarily consist of personnel and related overhead costs, information technology, and facilities costs for the infrastructure functions such as finance, information systems, executives, human resources and legal.

[0001032975-26-000021:mdna:116]
During fiscal year 2026, general and administrative expenses increased $3.1 million, compared to fiscal year 2025, primarily driven by higher variable compensation expense, partially offset by disciplined cost management.

[0001032975-26-000021:mdna:117]
Amortization of Intangible Assets and Acquisition-Related Costs

[0001032975-26-000021:mdna:118]
Amortization of intangible assets consists of amortization of acquired intangible assets, including developed technology, customer relationships, and trademarks and trade names. Acquisition-related costs include legal expenses, due diligence costs, and other professional costs incurred for business acquisitions.

[0001032975-26-000021:mdna:119]
During fiscal year 2026, amortization of intangible assets and acquisition-related costs decreased $4.4 million, compared to fiscal year 2025, driven by full amortization of certain intangible assets.

[0001032975-26-000021:mdna:120]
Restructuring Charges, Net

[0001032975-26-000021:mdna:121]
The restructuring charges, net, for fiscal years 2026 and 2025 were related to costs incurred as a result of our restructuring plan initiated during the fourth quarter of fiscal year 2025, which was substantially completed in fiscal year 2026. See Note 16 to our consolidated financial statements for additional information.

[0001032975-26-000021:mdna:122]
Interest Income

[0001032975-26-000021:mdna:123]
Interest income for fiscal years 2026 and 2025 was as follows (in thousands):

[0001032975-26-000021:mdna:124]
|  |  | Years Ended March 31, |
|  |  | 2026 |  | 2025 |  |  |
| Interest income |  | $ | 48,246 |  |  | $ | 54,997 |  |  |  |

[0001032975-26-000021:mdna:125]
We invest in highly liquid instruments with an original maturity of three months or less at the date of purchase, which are classified as cash equivalents. The decrease in interest income for fiscal year 2026, compared to fiscal year 2025, was primarily driven by a decrease in interest rates, partially offset by an increase in the cash equivalents balance.

[0001032975-26-000021:mdna:126]
Other Income (Expense), Net

[0001032975-26-000021:mdna:127]
Other income (expense), net for fiscal years 2026 and 2025 was as follows (in thousands):

[0001032975-26-000021:mdna:128]
|  |  | Years Ended March 31, |
|  |  | 2026 |  | 2025 |  |  |
| Investment gain related to the deferred compensation plan |  | $ | 3,714 |  |  | $ | 2,131 |  |  |  |
| Currency exchange loss, net |  | (3,733) |  |  | (6,401) |  |  |  |
| Loss on investments, net |  | (612) |  |  | (2,029) |  |  |  |
| Non-service cost net pension income and other |  | 3,710 |  |  | 3,319 |  |  |  |
| Total |  | $ | 3,079 |  |  | $ | (2,980) |  |  |  |

[0001032975-26-000021:mdna:129]
Investment gain related to the deferred compensation plan for fiscal years 2026 and 2025 represents earnings, gains, and losses on marketable securities related to a deferred compensation plan offered by one of our subsidiaries. The increase in investment gain for fiscal year 2026, compared to fiscal year 2025, primarily relates to the change in market performance of the underlying securities.

[0001032975-26-000021:mdna:130]
Currency exchange loss, net, relates to balances denominated in currencies other than the functional currency in our subsidiaries, as well as the sale of currencies, and gains or losses recognized on currency exchange forward contracts. We do not speculate in currency positions, but we are alert to opportunities to maximize currency exchange gains and minimize currency exchange losses. The loss for fiscal year 2026 was related to the exchange rate fluctuations of the Swedish Krona and Swiss Franc versus the U.S. Dollar. The loss for fiscal year 2025 was related to the exchange rate fluctuations of the Chinese Renminbi and Mexican Peso versus the U.S. Dollar.

[0001032975-26-000021:mdna:131]
Loss on investments, net, includes unrealized gain (loss) from the change in fair value of investments, income (loss) on equity-method investments and impairment of investments during the periods presented, as applicable. The loss on investments, net, for fiscal years 2026 and 2025 was not material.

[0001032975-26-000021:mdna:132]
During fiscal year 2026, non-service cost net pension income and other remained relatively flat, compared to fiscal year 2025.

[0001032975-26-000021:mdna:133]
Provision for Income Taxes

[0001032975-26-000021:mdna:134]
The provision for income taxes and effective income tax rates for fiscal years 2026 and 2025 were as follows (Dollars in thousands):

[0001032975-26-000021:mdna:135]
|  |  | Years Ended March 31, |
|  |  | 2026 |  | 2025 |  |  |
| Provision for income taxes |  | $ | 115,332 |  |  | $ | 75,343 |  |  |  |
| Effective income tax rate |  | 14.0 | % |  | 10.7 | % |  |  |

[0001032975-26-000021:mdna:136]
The change in the effective income tax rate between fiscal years 2026 and 2025 was primarily due to the expiration of statutes of limitation of uncertain tax positions in fiscal years 2026 and 2025, and the tax effect of audit resolutions in fiscal year 2025.

[0001032975-26-000021:mdna:137]
On July 4, 2025, the One Big Beautiful Bill Act (the "OBBBA") was enacted into law in the United States and most relevant provisions will be effective for us beginning in fiscal year 2027. The OBBBA includes numerous provisions that affect corporate taxation, impacting areas such as R&D expensing, bonus depreciation, and international tax provisions. We have reviewed the provisions of the OBBBA to determine the potential impact on our financial statements. Based on this review, and considering our current tax position and operations, at this time we do not expect the OBBBA to have a material impact on our income taxes, including current and deferred tax balances and the effective tax rate.

[0001032975-26-000021:mdna:138]
For the fiscal year 2026, we assessed our exposure to the OECD Pillar Two global minimum tax rules. We have determined that, for the fiscal year 2026, most jurisdictions in which we operate should qualify for the transitional Country-by-Country Reporting ("CbCR") safe harbor, as outlined in the OECD Administrative Guidance and enacted domestic legislation. Our CbCR has been prepared in accordance with the requirements for a Qualified CbCR, using qualified financial statements. Based on this data, most jurisdictions continue to meet safe harbor qualifications at 16% tax rates, and therefore, we are only required to perform a detailed Pillar Two top-up tax calculation for limited jurisdictions. The estimated top up tax for fiscal year 2026 is de minimis.

[0001032975-26-000021:mdna:139]
On January 5, 2026, the OECD released an Administrative Guidance package. This package includes a “Side-by-Side” System designed to align the U.S. tax regime with Pillar Two for U.S.-parented multinational groups, effective for tax years beginning on or after January 1, 2026. As we are a non-U.S. headquartered multinational, the “Side-by-Side” System itself does not apply to our tax profile. However, the broader guidance package also introduces a new permanent safe harbor (to replace the transitional CbCR safe harbor for fiscal years beginning in 2027) and a one-year extension of the transitional CbCR safe harbor that may potentially impact our Pillar Two compliance and reporting. We continue to monitor these developments but do not expect a material change to our Pillar Two liability.

[0001032975-26-000021:mdna:140]
As of March 31, 2026 and 2025, the total amount of unrecognized tax benefits due to uncertain tax positions was $131.4 million and $152.0 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-26-000021:mdna:141]
As of March 31, 2026 and 2025, we had $86.3 million and $88.5 million, respectively, in non-current income taxes payable, including interest and penalties, related to our income tax liability for uncertain tax positions. As of March 31, 2026 and 2025, we had $8.3 million and $7.2 million, respectively, of accrued interest and penalties related to uncertain tax positions.

[0001032975-26-000021:mdna:142]
Our unrecognized tax benefits decreased by $20.6 million during the fiscal year ended March 31, 2026, primarily due to the expiration of the statutes of limitations for certain U.S. federal positions. In the United States, the federal and state tax agencies have the authority to examine periods prior to fiscal year 2022, to the extent allowed by law, but only to the extent tax attributes were generated, carried forward, and are being utilized in subsequent years. The statute of limitations in the United States otherwise lapsed for fiscal year 2022 in fiscal year 2026. We are under examination in several foreign tax jurisdictions.

[0001032975-26-000021:mdna:143]
Liquidity and Capital Resources

[0001032975-26-000021:mdna:144]
Cash Balances, Available Borrowings, and Capital Resources

[0001032975-26-000021:mdna:145]
As of March 31, 2026, we had cash and cash equivalents of $1,741.5 million, compared with $1,503.2 million as of March 31, 2025. Our cash and cash equivalents consist of bank demand deposits, short-term time deposits, and U.S. Treasury securities, of which 50% was held in the United States, 33% was held in Switzerland, and 11% was held in China (including Hong Kong). We do not expect to incur any material adverse tax impact except for what has already been recognized, or to be significantly inhibited by any country in which we do business, from the repatriation of funds to Switzerland, our country of domicile.

[0001032975-26-000021:mdna:146]
As of March 31, 2026, our working capital was $1,602.3 million, compared to $1,491.6 million as of March 31, 2025. The increase was primarily driven by increases in cash and cash equivalents and accounts receivable, net, partially offset by increases in accounts payable and accrued and other liabilities.

[0001032975-26-000021:mdna:147]
On January 27, 2025, we entered into an unsecured revolving credit facility with a syndicate of banks (the "Credit Agreement"). The Credit Agreement provides a revolving line of credit of up to $750.0 million including the issuance of letters of credit of up to $100.0 million. The Credit Agreement terminates on January 27, 2030 unless extended in accordance with its terms. The Credit Agreement contains (1) an increase option allowing us to secure up to $250.0 million of additional commitments and (2) an extension option to extend the term by one-year which may be exercised no more than two times, subject to certain requirements. Loans under the Credit Agreement are available in U.S. Dollars, Euro, Sterling, Yen, Swiss Francs, Canadian Dollars, Australian Dollars and any other currency agreed to by each lender. Proceeds of loans made under the Credit Agreement may be used for general corporate purposes.

[0001032975-26-000021:mdna:148]
The Credit Agreement contains a maximum net debt to adjusted EBITDA ratio, compliance with which is a condition to our ability to borrow. Borrowings under the Credit Agreement will bear interest at a rate determined by reference to benchmark rates plus an applicable spread (ranging from 0% to 1.5%) based on our net leverage ratio or credit rating at the time of the borrowing. Undrawn balances available under the Credit Agreement are subject to commitment fees at the applicable rate determined by reference to our net leverage ratio or credit rating. There has been no borrowing outstanding under the Credit Agreement as of March 31, 2026.

[0001032975-26-000021:mdna:149]
In addition, we had several uncommitted, unsecured bank lines of credit and letters of credit aggregating to $149.0 million as of March 31, 2026. There are no financial covenants under these lines of credit with which we must comply. There was no borrowing outstanding under these lines of credit as of March 31, 2026. As of March 31, 2026, we had outstanding bank guarantees of $2.1 million.

[0001032975-26-000021:mdna:150]
Key Working Capital Metrics

[0001032975-26-000021:mdna:151]
The following table presents selected financial information and statistics as of March 31, 2026 and 2025 (Dollars in thousands):

[0001032975-26-000021:mdna:152]
|  |  | March 31, |
|  |  | 2026 |  | 2025 |  |  |
| Accounts receivable, net |  | $ | 505,867 |  |  | $ | 454,546 |  |  |  |
| Accounts payable |  | $ | 530,983 |  |  | $ | 414,586 |  |  |  |
| Inventories |  | $ | 489,948 |  |  | $ | 503,747 |  |  |  |
| Days sales in accounts receivable (DSO)(Days)(1) |  | 42 |  |  | 40 |  |  |  |
| Days accounts payable outstanding (DPO) (Days)(2) |  | 79 |  |  | 65 |  |  |  |
| Inventory turnover (ITO)(x)(3) |  | 4.9 |  |  | 4.6 |  |  |  |

[0001032975-26-000021:mdna:153]
(1) DSO is determined using ending accounts receivable, net, as of the most recent quarter-end and sales for the most recent quarter.

[0001032975-26-000021:mdna:154]
(2) DPO is determined using ending accounts payable as of the most recent quarter-end and cost of goods sold for the most recent quarter.

[0001032975-26-000021:mdna:155]
(3) ITO is determined using ending inventories as of the most recent quarter-end and annualized cost of goods sold (based on the most recent quarterly cost of goods sold).

[0001032975-26-000021:mdna:156]
DSO as of March 31, 2026 increased by 2 days to 42 days, compared to 40 days as of March 31, 2025, primarily due to the timing of sales within the fourth quarters of fiscal years 2026 and 2025.

[0001032975-26-000021:mdna:157]
DPO as of March 31, 2026 increased by 14 days to 79 days, compared to 65 days as of March 31, 2025, primarily due to higher inventory purchases to align with improved demand.

[0001032975-26-000021:mdna:158]
ITO as of March 31, 2026 increased by 0.3 to 4.9, compared to 4.6 as of March 31, 2025, primarily due to improved demand.

[0001032975-26-000021:mdna:159]
If we are not successful in launching and phasing in our new products, or market competition increases, or we are not able to sell the new products at the prices planned, it could have a material impact on our sales, gross profit, operating results including operating cash flow, and inventory turnover in the future.

[0001032975-26-000021:mdna:160]
Cash Flow Activities

[0001032975-26-000021:mdna:161]
The following table summarizes our consolidated statement of cash flows for the year ended March 31, 2026 (in thousands):

[0001032975-26-000021:mdna:162]
|  |  | Year ended March 31, 2026 |  |  |
| Net cash provided by operating activities |  | $ | 1,037,207 |  |  |  |
| Net cash used in investing activities |  | (62,387) |  |  |  |
| Net cash used in financing activities |  | (751,116) |  |  |  |
| Effect of exchange rate changes on cash and cash equivalents |  | 14,637 |  |  |  |
| Net increase in cash and cash equivalents |  | $ | 238,341 |  |  |  |

[0001032975-26-000021:mdna:163]
For fiscal year 2026, net cash provided by operating activities was $1,037.2 million resulting from net income of $711.2 million, a favorable impact from adding back non-cash adjustments totaling $220.3 million, and a favorable net change in operating assets and liabilities of $105.7 million. Non-cash adjustments were primarily related to share-based compensation expense, depreciation and amortization, and deferred income taxes. The increase in accounts receivable, net, was primarily attributable to increase in sales driven by improved demand as well as the timing of sales within the quarter. The increase in accounts payable was primarily driven by higher inventory purchases to align with improved demand. The increase in accrued and other liabilities was primarily driven by higher income tax payable and as well as higher revenue reserves.

[0001032975-26-000021:mdna:164]
For fiscal year 2026, net cash used in investing activities was $62.4 million, primarily due to $61.6 million purchases of property, plant, and equipment. Our expenditures for property, plant and equipment during fiscal year 2026 were primarily for tooling and equipment, and computer hardware and software.

[0001032975-26-000021:mdna:165]
For fiscal year 2026, net cash used in financing activities was $751.1 million, primarily resulting from repurchases of our registered shares of $534.9 million, payments of cash dividends of $233.1 million, and tax withholdings related to net share settlements of restricted stock units of $21.4 million, partially offset by proceeds from exercise of stock options and purchase rights of $38.3 million.

[0001032975-26-000021:mdna:166]
During fiscal year 2026, there was a $14.6 million gain from foreign currency exchange rate effect on cash and cash equivalents, primarily due to exchange rate fluctuations of Swiss Franc, Chinese Renminbi, Brazilian Real and Euro versus the U.S. Dollar.

[0001032975-26-000021:mdna:167]
Cash Outlook

[0001032975-26-000021:mdna:168]
Our principal sources of liquidity are our cash and cash equivalents, cash flow generated from operations and, to a much lesser extent, capital markets and borrowings. Our future working capital requirements and capital expenditures may increase to support investments in product innovations and growth opportunities or to acquire or invest in complementary businesses, products, services, and technologies. Our principal uses of cash, aside from operational needs and capital expenditures, include outlays for dividends and share repurchases reflecting our commitment to return value to our shareholders.

[0001032975-26-000021:mdna:169]
In May 2026, the Board of Directors recommended that we pay cash dividends for fiscal year 2026 of CHF 1.36 per share (approximately $1.70 per share based on the exchange rate on March 31, 2026). Based on our shares outstanding, net of treasury shares, as of March 31, 2026 (143,502,564 shares), this would result in an aggregate gross dividend of approximately CHF 195.2 million (approximately $243.9 million based on the exchange rate on March 31, 2026). In fiscal year 2026, we paid a cash dividend of CHF 1.26 per share, or CHF 185.1 million (U.S. Dollar amount of $233.1 million based on the exchange rate on the date of payment) out of fiscal year 2025 retained earnings. In fiscal year 2025, we paid a cash dividend of CHF 1.16 per share, or CHF 176.3 million (U.S.

[0001032975-26-000021:mdna:170]
Dollar amount of $207.9 million based on the exchange rate on the date of payment) out of fiscal year 2024 retained earnings.

[0001032975-26-000021:mdna:171]
In June 2023, our Board of Directors approved a three-year share repurchase program, which allows us to use up to $1.0 billion to repurchase our shares. The 2023 share repurchase program enables us to repurchase shares for cancellation, as well as to support equity incentive plans or potential acquisitions. The Swiss Takeover Board approved the 2023 share repurchase program in July 2023 and the program became effective on July 28, 2023. In March 2025, our Board of Directors approved an increase of $600.0 million to the 2023 share repurchase program, to an aggregate amount of $1.6 billion. During the fiscal year ended March 31, 2026, we repurchased 6.2 million shares for an aggregate cost of $557.0 million, under the 2023 share repurchase program for cancellation, of which $40.8 million of the aggregate cost was not paid yet as of March 31, 2026. As of March 31, 2026, $91.8 million was available for repurchase under the 2023 share repurchase program.

[0001032975-26-000021:mdna:172]
In March 2026, our Board of Directors approved a new, three-year share repurchase program to repurchase shares to an aggregate amount of $1.4 billion, or a maximum of 16,078,446 shares. The 2026 share repurchase program enables the Company to repurchase shares for cancellation, as well as to support equity incentive plans or potential acquisitions. The 2026 share repurchase program became effective on May 8, 2026, following approval from the Swiss Takeover Board and the completion of the 2023 share repurchase program.

[0001032975-26-000021:mdna:173]
Swiss law limits a company’s ability to hold or repurchase its own shares. The aggregate par value of all shares held in treasury by us and our subsidiaries may not exceed 10% of our issued share capital, which corresponds to approximately 16.1 million registered shares as of March 31, 2026. This limitation does not apply to shares repurchased for cancellation, due to the Board of Directors' authority under the capital band set forth in the Company's Articles of Incorporation. As of March 31, 2026, we had a total of 17.3 million shares held in treasury stock, which includes 4.7 million shares that have been repurchased for cancellation and 12.6 million shares that have been purchased to support equity incentive plans or potential acquisitions.

[0001032975-26-000021:mdna:174]
Although we enter into trading plans for systematic repurchases (e.g., 10b5-1 trading plans) from time to time, our share repurchase program provides us with the opportunity to make opportunistic repurchases during periods of favorable market conditions. To the extent that the shares are repurchased to support equity incentive plans or potential acquisitions, the shares are repurchased on the ordinary trading line of the SIX Swiss Exchange and/or the Nasdaq Global Select Market. Shares repurchased for cancellation purposes are repurchased via a second trading line on the SIX Swiss Exchange. Opportunistic purchases may be started or stopped at any time without prior notice depending on market conditions and other factors.

[0001032975-26-000021:mdna:175]
For over ten years, we have generated positive cash flows from our operating activities, including cash from operations of $1,037.2 million and $842.6 million during fiscal years 2026 and 2025, respectively. If we do not generate sufficient operating cash flows to support our operations and future planned cash requirements, our operations could be harmed and our access to credit facilities could be restricted or eliminated. Although we believe that the trend of our historical cash flow generation, our projections of future operations and our available cash balances will provide sufficient liquidity to fund our operations for at least the next 12 months, market volatility driven by the current macroeconomic and geopolitical environment may increase our costs of capital and otherwise adversely affect our business, results of operations, financial condition and liquidity.

[0001032975-26-000021:mdna:176]
Our other contractual obligations and commitments that require cash are described in the following sections.

[0001032975-26-000021:mdna:177]
Contractual Obligations and Commitments

[0001032975-26-000021:mdna:178]
Purchase Commitments

[0001032975-26-000021:mdna:179]
As of March 31, 2026, we had non-cancelable purchase commitments of $474.0 million for inventory purchases made in the normal course of business from original design manufacturers, contract manufacturers and other suppliers, the majority of which are expected to be fulfilled within the next 12 months. We recorded a liability for firm, non-cancelable, and unhedged inventory purchase commitments in excess of anticipated demand or net realizable value consistent with our valuation of excess and obsolete inventory. As of March 31, 2026, the liability for these purchase commitments was $18.2 million and is recorded in accrued and other current liabilities in the consolidated balance sheet.

[0001032975-26-000021:mdna:180]
We have firm purchase commitments of $17.5 million for capital expenditures primarily related to commitments for tooling and equipment for new and existing products. We expect to continue making capital expenditures in the future to support product development activities and ongoing and expanded operations. Although open purchase

[0001032975-26-000021:mdna:181]
commitments are considered enforceable and legally binding, the terms generally allow us to reschedule or adjust our requirements based on business needs prior to delivery of goods or performance of services.

[0001032975-26-000021:mdna:182]
Operating Lease Obligations

[0001032975-26-000021:mdna:183]
We lease facilities under operating leases, certain of which require us to pay property taxes, insurance and maintenance costs. Operating leases for facilities are generally renewable at our option and usually include escalation clauses linked to inflation. The remaining terms of our non-cancelable operating leases expire in various years through 2036. See Note 17 - Leases in our Notes to the consolidated financial statements included in this report for more information on leases.

[0001032975-26-000021:mdna:184]
Income Taxes Payable

[0001032975-26-000021:mdna:185]
As of March 31, 2026, we had $86.3 million in non-current income taxes payable, including interest and penalties, related to our income tax liability for uncertain tax positions. At this time, we are unable to make a reasonably reliable estimate of the timing of payments in individual years in connection with these tax liabilities.

[0001032975-26-000021:mdna:186]
Indemnifications

[0001032975-26-000021:mdna:187]
We indemnify certain suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of March 31, 2026, no material amounts have been accrued for indemnification provisions. We do not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under our indemnification arrangements.

[0001032975-26-000021:mdna:188]
We also indemnify our current and former directors and certain current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. We are unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not capped, the obligations are conditional in nature, and the facts and circumstances involved in any situation that might arise are variable.
