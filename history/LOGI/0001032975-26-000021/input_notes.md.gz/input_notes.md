# LOGI notes — 0001032975-26-000021


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001032975-26-000021:notes:1]
Portions of the registrant's Proxy Statement for the 2026 Annual Meeting of Shareholders are incorporated herein by reference in Part III of this Annual Report on Form 10-K to the extent stated herein.


## cyd:CybersecurityRiskManagementProcessesForAssessingIdentifyingAndManagingThreatsTextBlock

[0001032975-26-000021:notes:2]
We have established a Security Governance Framework that defines roles and responsibilities, so that security is taken into account at all levels and in every department or function of the Company. Our framework provides guidance for the organization, governance and implementation of security across the company. Logitech and its infrastructure have been certified for compliance with ISO 27001, an international standard for information security management.

[0001032975-26-000021:notes:3]
Identifying and assessing cybersecurity risks is integrated into our enterprise risk management. As part of our risk management program, we continuously assess risks from third parties, including vendors, suppliers, and other business partners associated with our use of third-party service providers. We have implemented incident response and breach management processes that include the following steps: mobilizing the right stakeholders and containing the attack, maintaining trust with all affected stakeholders and understanding the attack, recovering the most critical business operations, and learning from the attack. We also conduct tabletop exercises to, among other things, align activities and expectations in connection with our incident response processes, discuss strategic questions, and review third party recommendations.

[0001032975-26-000021:notes:4]
We have not previously experienced a cybersecurity event that was determined to be material, and our business strategy, results of operations and financial condition have not been materially affected by risks from cybersecurity threats. In the fall of 2025, we experienced a cybersecurity incident relating to the exfiltration of data, which we believe will not have a material adverse effect on our financial condition or results of operations. However, there can be no assurance that any future, or yet undiscovered, incident will not have a material impact on us, individually or in the aggregate. For additional information regarding risks from cybersecurity threats, please refer to Item 1A "Risk Factors" in this Annual Report on Form 10-K.


## cyd:CybersecurityRiskBoardOfDirectorsOversightTextBlock

[0001032975-26-000021:notes:5]
Logitech’s Board of Directors oversees risk management and reviews Logitech security risks, controls and procedures. The Board of Directors is assisted in its role by each of the Audit Committee and the Technology and Innovation Committee. The Audit Committee is responsible for the oversight of risks from cybersecurity threats. Members of the Audit Committee receive updates on a semi-annual basis from our Chief Information Security Officer (“CISO”) regarding matters of cybersecurity. The Technology and Innovation Committee periodically reviews the Company’s cybersecurity, information security and other technology risks, controls and procedures, including product security and related threats. Finally, the Board has formed a Cyber Crisis Subcommittee tasked with overseeing any future significant cybersecurity crisis.


## cyd:CybersecurityRiskRoleOfManagementTextBlock

[0001032975-26-000021:notes:6]
Management’s Role in Assessing and Managing Material Risks from Cybersecurity Threats

[0001032975-26-000021:notes:7]
Our Security Team is responsible for evaluating, reporting and advising about security threats and risks, defining and leading the enterprise security program to protect Logitech business against security threats, maintaining and updating the security framework, monitoring the level of compliance with the security framework across Logitech digital assets, products and services, providing enterprise-wide security services, defining security policies, standards and guidelines, advising on secure architectures, performing assessments and due diligence checks internally and with business partners, providing security guidance for digital projects, creating and deploying security training programs, managing security incidents and breaches, and conducting threat intelligence and managing vulnerabilities.

[0001032975-26-000021:notes:8]
Our Security Team also monitors security through the entire software and product development lifecycle. The Head of Application and Product Security is accountable for the release or deployment approval of a product based upon the review of internal and external validation (functionality, performance, security) reports.

[0001032975-26-000021:notes:9]
The Security Team, which is part of the Digital Office organization, is led by the CISO, who has 20 years of security experience across different industries. The CISO reports to our Head of Digital Office, who has more than 20 years of experience leading software and infrastructure teams, including over a decade in the cybersecurity industry. Our security is managed based on industry-leading standards such as ISO 27001, National Institute of Standards and Technology ("NIST"), Center for Internet Security ("CIS"), Open Worldwide Application Security Project ("OWASP") Application Security Verification Standard ("ASVS") and the Software Assurance Maturity Model ("SAMM").

[0001032975-26-000021:notes:10]
Our CISO and the Head of Digital Office regularly report on cybersecurity to the Audit Committee and/or the Technology and Innovation Committee and the Board of Directors.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001032975-26-000021:notes:11]
Summary of Significant Accounting Policies
Basis of Presentation

[0001032975-26-000021:notes:12]
The consolidated financial statements include the accounts of Logitech and its subsidiaries. All intercompany balances and transactions have been eliminated. The consolidated financial statements are presented in accordance with accounting principles generally accepted in the United States ("U.S. GAAP").

[0001032975-26-000021:notes:13]
Fiscal Year

[0001032975-26-000021:notes:14]
The Company's fiscal year ends on March 31. Interim quarters are generally thirteen-week periods, each ending on a Friday. For purposes of presentation, the Company has indicated its quarterly periods end on the last day of the calendar quarter.

[0001032975-26-000021:notes:15]
Reference to Sales

[0001032975-26-000021:notes:16]
References to "sales" in the Notes to the consolidated financial statements means net sales, except as otherwise specified.

[0001032975-26-000021:notes:17]
Use of Estimates

[0001032975-26-000021:notes:18]
The preparation of financial statements in conformity with U.S. GAAP requires management to make judgments, estimates and assumptions that affect the amounts reported in the consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Significant estimates and assumptions made by management involve the fair value of goodwill and intangible assets acquired from business acquisitions, pension obligations, accruals for customer incentives, cooperative marketing, and pricing programs ("Customer Programs") and related breakage when appropriate, inventory valuation, share-based compensation expense, uncertain tax positions, and valuation allowances for deferred tax assets. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ materially from those estimates.

[0001032975-26-000021:notes:19]
Risks and Uncertainties

[0001032975-26-000021:notes:20]
Impacts of Macroeconomic, Geopolitical, and Other Factors on the Company's Business

[0001032975-26-000021:notes:21]
As the Company conducts operations globally, its business has continued to be impacted by ongoing macroeconomic and geopolitical conditions. These conditions include changes in inflation, interest rate and foreign currency fluctuations, uncertainty in consumer and enterprise demand, tariff and trade policies, memory chip availability, volatile energy prices and increased geopolitical tensions, including the armed conflicts in the Middle East.

[0001032975-26-000021:notes:22]
In 2025, the United States introduced trade policy actions that increased import tariffs across a wide range of countries at various rates, with certain exemptions. In February 2026, the U.S. Supreme Court issued a decision invalidating certain tariffs previously imposed under the International Emergency Economic Powers Act. In May 2026, some companies began receiving notification from the U.S. Customs and Border Protection (CBP) that tariff refunds would be issued; however, the extent and timing of these tariff refunds remain uncertain. Following the U.S. Supreme Court ruling, the U.S. government introduced new temporary tariffs for a 150-day period beginning February 24, 2026. In May 2026, the U.S. Court of International Trade invalidated these temporary tariffs but they remain in place, subject to appeal. The U.S. government may pursue alternative trade measures, including under Sections 301 and 302 of U.S. trade laws, which could result in additional or replacement tariffs. U.S. tariff policies and international trade arrangements continue to evolve and have had, and may continue to have, a significant impact on the Company's results of operations.

[0001032975-26-000021:notes:23]
The Company has also been affected by the increases in demand for memory chips and other components caused by the build out of new AI technologies and data centers, leading to a rise in prices for such components and some suppliers transitioning capacity away from certain components utilized in some of the Company's Video Collaboration products.

[0001032975-26-000021:notes:24]
The global and regional macroeconomic, political, and other conditions have caused and may continue to cause volatility in demand for the Company's products, component availability, transit times and cost of the Company's products including cost of tariffs, materials, and logistics, and as a result, have impacted and may continue to impact the pricing of the Company's products, product availability and the Company's results of operations.

[0001032975-26-000021:notes:25]
Currencies

[0001032975-26-000021:notes:26]
The functional currency of the Company's operations is primarily the U.S. Dollar. Certain operations use the Euro, Chinese Renminbi, Swiss Franc, or other local currencies as their functional currencies. The financial statements of the Company's subsidiaries whose functional currency is other than the U.S. Dollar are translated to U.S. Dollars using period-end rates of exchange for assets and liabilities and monthly average rates for sales, income and expenses. Cumulative translation gains and losses are included as a component of shareholders' equity in accumulated other comprehensive income (loss). Gains and losses arising from transactions denominated in currencies other than a subsidiary's functional currency are reported in other income (expense), net in the consolidated statements of operations.

[0001032975-26-000021:notes:27]
Revenue Recognition

[0001032975-26-000021:notes:28]
Revenue is recognized when a customer obtains control of promised goods or services in an amount that reflects the transaction price the Company expects to receive in exchange for those goods or services.

[0001032975-26-000021:notes:29]
Substantially all revenue recognized by the Company relates to the contracts with customers to sell products that allow people to connect through gaming, video, computing, music and other digital platforms. These products are hardware devices, which may include embedded software that function together, and are considered as one performance obligation. Hardware devices are generally plug and play, requiring no configuration and little or no installation. Revenue is recognized at a point in time when control of the products is transferred to the customer which generally occurs upon shipment. The Company’s sales contracts with its customers have a one year or shorter term.

[0001032975-26-000021:notes:30]
The Company also provides post-contract customer support (“PCS”) for certain products and related software, which includes unspecified software updates and upgrades, bug fixes and maintenance. The transaction price is allocated to two performance obligations in such contracts, based on a relative standalone selling price. The transaction price allocated to PCS is recognized as revenue on a straight-line basis, which reflects the pattern of delivery of PCS, over the estimated term of the support.

[0001032975-26-000021:notes:31]
The Company also recognizes revenue from subscription services that provide professional streamers with access to streaming software and tools as well as from Video Collaboration support services. These services represent stand-ready performance obligations. Payments for these services are made at the time of or in advance of delivering the services. The proceeds received in advance from such arrangements are recognized as deferred revenue and then recognized as revenue ratably over the service period up to five years.

[0001032975-26-000021:notes:32]
See Note 8 for the current and non-current deferred revenue associated with the Company’s remaining performance obligations to be recognized within the next 12 months and thereafter, respectively.

[0001032975-26-000021:notes:33]
The Company normally requires payment from customers within thirty to sixty days from the invoice date. However, terms may vary by customer type, by country and by selling season. The Company generally does not modify payment terms on existing receivables. The Company's contracts with customers do not include significant financing components as the period between the satisfaction of performance obligations and timing of payment are generally within one year.

[0001032975-26-000021:notes:34]
The transaction price received by the Company from sales to its distributors, retail companies ("retailers"), and authorized resellers is calculated as selling price net of variable consideration which may include product returns and the Company’s payments for Customer Programs related to current period product revenue. The estimated impact of these programs is recorded as a reduction of transaction price or as an operating expense if the Company receives a distinct good or service from the customer and can reasonably estimate the fair value of that good or service received. Customer Programs require management to estimate the percentage of those programs which will not be claimed in the current period or will not be earned by customers, which is commonly referred to as "breakage." Breakage is estimated based on historical claim experience, the period in which customer claims are expected to be submitted, specific terms and conditions with customers and other factors. The Company accounts for breakage as part of variable consideration, subject to constraint, and records the estimated impact in the same period when revenue is recognized at the expected value. Assessing the period in which claims are expected to be submitted and the relevance of the historical claim experience require significant management judgment to estimate the breakage of Customer Programs in any accounting period.

[0001032975-26-000021:notes:35]
The Company enters into cooperative marketing arrangements with many of its customers and with certain indirect partners, allowing customers to receive a credit equal to a set percentage of their purchases of the Company's products, or a fixed dollar amount for various marketing and incentive programs. The objective of these arrangements is to encourage advertising and promotional events to increase sales of the Company's products.

[0001032975-26-000021:notes:36]
Customer incentive programs include consumer rebates and performance-based incentives. Consumer rebates are offered to the Company's customers and indirect partners at the Company's discretion for the primary benefit of end-users. In addition, the Company offers performance-based incentives to many of its customers and indirect partners based on predetermined performance criteria. At management's discretion, the Company also offers special pricing discounts to certain customers. Special pricing discounts are usually offered only for limited time periods or for sales of selected products to specific indirect partners.

[0001032975-26-000021:notes:37]
Cooperative marketing arrangements and customer incentive programs are considered variable consideration, which the Company estimates and records as a reduction to revenue at the time of sale based on negotiated terms, historical experiences, forecasted incentives, anticipated volume of future purchases, and inventory levels in the channel.

[0001032975-26-000021:notes:38]
The Company has agreements with certain customers that contain terms allowing price protection credits to be issued in the event of a subsequent price reduction. Management's decision to make price reductions is influenced by product life cycle stage, market acceptance of products, the competitive environment, new product introductions and other factors.

[0001032975-26-000021:notes:39]
Accruals for estimated expected future pricing actions and Customer Programs are recognized at the time of sale based on analyses of historical pricing actions by customer and by product, inventories owned by and located at customers, current customer demand, current operating conditions, and other relevant customer and product information, such as stage of product life-cycle.

[0001032975-26-000021:notes:40]
Product return rights vary by customer. Estimates of expected future product returns qualify as variable consideration and are recorded as a reduction of the transaction price of the contract at the time of sale based on an analysis of historical return trends by customer and by product, inventories owned by and located at customers, current customer demand, current operating conditions, and other relevant customer and product information. The Company assesses the estimated asset for recovery value for impairment and adjusts the value of the asset for any impairment. Return trends are influenced by product life cycle status, new product introductions, market acceptance of products, sales levels, product sell-through, the type of customer, seasonality, product quality issues, competitive

[0001032975-26-000021:notes:41]
pressures, operational policies and procedures, and other factors. Return rates can fluctuate over time but are sufficiently predictable to allow the Company to estimate expected future product returns.

[0001032975-26-000021:notes:42]
Typically, variable consideration does not need to be constrained as estimates are based on predictive historical data or future commitments that are planned and controlled by the Company. However, the Company continues to assess variable consideration estimates such that it is probable that a significant reversal of revenue will not occur.

[0001032975-26-000021:notes:43]
The Company regularly evaluates the adequacy of its estimates for Customer Programs and product returns. Future market conditions and product transitions may require the Company to take action to change such programs and related estimates. When the variables used to estimate these costs change, or if actual costs differ significantly from the estimates, the Company would be required to increase or reduce revenue or operating expenses to reflect the impact. During the year ended March 31, 2026, changes to these estimates related to performance obligations satisfied in prior periods were not material.

[0001032975-26-000021:notes:44]
Sales taxes and value-added taxes (“VAT”) collected from customers, if applicable, which are remitted to governmental authorities are not included in revenue, and are reflected as a liability on the consolidated balance sheets.

[0001032975-26-000021:notes:45]
Shipping and Handling Costs

[0001032975-26-000021:notes:46]
The Company's shipping and handling costs are included in the cost of goods sold in the consolidated statements of operations.

[0001032975-26-000021:notes:47]
Contract Balances

[0001032975-26-000021:notes:48]
The Company records accounts receivable from contracts with customers when it has an unconditional right to consideration, as accounts receivable, net, on the consolidated balance sheets.

[0001032975-26-000021:notes:49]
The Company records contract liabilities when cash payments are received or due in advance of performance, primarily for implied support and subscriptions. Contract liabilities are included in accrued and other current liabilities and other non-current liabilities on the consolidated balance sheets.

[0001032975-26-000021:notes:50]
Contract Costs

[0001032975-26-000021:notes:51]
The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that otherwise would have been recognized is one year or less. These costs are included in marketing and selling expenses in the consolidated statements of operations. As of March 31, 2026 and 2025, the Company did not have any material deferred contract costs.

[0001032975-26-000021:notes:52]
Research and Development Costs

[0001032975-26-000021:notes:53]
Costs related to research, design and development of products, which consist primarily of personnel, product design and infrastructure expenses, are charged to research and development expense as they are incurred.

[0001032975-26-000021:notes:54]
Advertising Costs

[0001032975-26-000021:notes:55]
Advertising costs are recorded as either a marketing and selling expense or a deduction from revenue as they are incurred. Advertising costs paid or reimbursed by the Company to direct or indirect customers must have an identifiable benefit and an estimable fair value in order to be classified as an operating expense. If these criteria are not met, the payment is classified as a reduction of revenue. Advertising costs recorded as marketing and selling expense are expensed as incurred. Total advertising costs including those characterized as revenue deductions during fiscal years 2026, 2025 and 2024 were $410.9 million, $355.1 million and $325.3 million, respectively, out of which $54.1 million, $53.1 million, and $46.6 million, respectively, were included as operating expense in the consolidated statements of operations.

[0001032975-26-000021:notes:56]
Cash Equivalents

[0001032975-26-000021:notes:57]
The Company classifies all highly liquid instruments purchased, such as bank demand deposits, short-term time deposits, and U.S. Treasury securities, with an original maturity of three months or less at the date of purchase, to be cash equivalents. Cash equivalents are carried at cost, which approximates their fair value.

[0001032975-26-000021:notes:58]
Concentration of Credit Risk

[0001032975-26-000021:notes:59]
Financial instruments that potentially subject the Company to concentrations of credit risk consist principally of cash and cash equivalents and accounts receivable. The Company maintains cash and cash equivalents with various creditworthy financial institutions and has a policy to limit exposure with any one financial institution, but is exposed to credit risk in the event of default by financial institutions to the extent that cash balances with individual financial institutions are in excess of amounts that are insured. The Company periodically assesses the credit risk associated with these financial institutions.

[0001032975-26-000021:notes:60]
The Company sells to large distributors, retailers, and e-tailers and, as a result, maintains individually significant receivable balances with such customers.

[0001032975-26-000021:notes:61]
The Company had the following customers that individually comprised 10% or more of its gross sales:

[0001032975-26-000021:notes:62]
|  |  | Years Ended March 31, |
|  |  | 2026 |  | 2025 |  | 2024 |
| Customer A |  | 14 | % |  | 14 | % |  | 13 | % |
| Customer B |  | 18 | % |  | 19 | % |  | 18 | % |
| Customer C |  | 12 | % |  | 12 | % |  | 14 | % |

[0001032975-26-000021:notes:63]
The Company had the following customers that individually comprised 10% or more of its accounts receivable:

[0001032975-26-000021:notes:64]
|  |  | March 31, |
|  |  | 2026 |  | 2025 |
| Customer A |  | 16 | % |  | 14 | % |
| Customer B |  | 23 | % |  | 21 | % |
| Customer C |  | 13 | % |  | 10 | % |

[0001032975-26-000021:notes:65]
The Company manages its accounts receivable credit risk through ongoing credit evaluation of its customers' financial conditions. The Company generally does not require collateral from its customers.

[0001032975-26-000021:notes:66]
Allowances for Doubtful Accounts

[0001032975-26-000021:notes:67]
Allowances for doubtful accounts are maintained for expected credit losses resulting from the Company's customers' inability to make required payments. The allowances are based on the Company's regular assessment of various factors, including the credit-worthiness and financial condition of specific customers, historical experience with bad debts and customer deductions, receivables aging, current economic conditions, reasonable and supportable forecasts of future economic conditions, and other factors that may affect the Company's ability to collect from customers.

[0001032975-26-000021:notes:68]
Inventories

[0001032975-26-000021:notes:69]
Inventories are stated at the lower of cost and net realizable value. Costs are computed under the standard cost method, which approximates actual costs determined on the first-in, first-out basis. The Company records write-downs of inventories which are obsolete or in excess of anticipated demand or net realizable value based on a consideration of marketability and product life cycle stage, product development plans, component cost trends, historical sales and demand forecasts which consider the assumptions about future demand and market conditions. Inventory on hand which is not expected to be sold or utilized is considered excess, and the Company recognizes the write-down in cost of goods sold at the time of such determination. The write-down is determined by the excess of cost over net realizable value. Net realizable value is the estimated selling price in the ordinary course of business, less reasonably predictable costs of completion, disposal and transportation. At the time of loss recognition, new cost basis per unit and lower-cost basis for that inventory are established and subsequent changes in facts and circumstances would not result in an increase in the cost basis.

[0001032975-26-000021:notes:70]
The Company recorded liabilities arising from firm, non-cancelable, and unhedged inventory purchase commitments in excess of anticipated demand or net realizable value consistent with its valuation of excess and obsolete inventory. Such liability is included in accrued and other current liabilities on the consolidated balance sheets.

[0001032975-26-000021:notes:71]
Property, Plant and Equipment

[0001032975-26-000021:notes:72]
Property, plant and equipment are stated at cost. Additions and improvements are capitalized, and maintenance and repairs are expensed as incurred. The Company capitalizes the cost of software developed for internal use in connection with major projects. Costs incurred during the preliminary project stage and post implementation stage are expensed, whereas direct costs incurred during the application development stage are capitalized.

[0001032975-26-000021:notes:73]
Depreciation expense is recognized using the straight-line method. Plant and buildings are depreciated over estimated useful lives of twenty-five years, equipment over useful lives from three to five years, internal-use software over useful lives of three years, tooling over useful lives from six months to one year, and leasehold improvements over the lesser of the term of the lease or the estimated useful life of leasehold improvements.

[0001032975-26-000021:notes:74]
When property and equipment is retired or otherwise disposed of, the cost and accumulated depreciation are relieved from the accounts and the net gain or loss is included in cost of goods sold or operating expenses, depending on the nature of the property and equipment.

[0001032975-26-000021:notes:75]
Leases

[0001032975-26-000021:notes:76]
The Company determines if an arrangement is a lease or contains a lease at contract inception. The Company determines if a lease is an operating or finance lease and recognizes right-of-use ("ROU") assets and lease liabilities upon lease commencement. Operating lease ROU assets are included in other assets, short-term lease liabilities are included in accrued and other current liabilities, and long-term lease liabilities are included in other non-current liabilities on the Company's consolidated balance sheets. Leases with an initial term of 12 months or less are not recorded on the balance sheet. For the Company's operating leases, the Company accounts for the lease component and related non-lease component as a single lease component. Lease expense is recognized on a straight-line basis over the lease term.

[0001032975-26-000021:notes:77]
For operating leases, the lease liability is initially measured at the present value of the unpaid lease payments at lease commencement date. As most of the leases do not provide an implicit rate, the Company generally uses its incremental borrowing rate as the discount rate for the leases. The Company's incremental borrowing rate is the rate of interest it would have to pay on a collateralized basis to borrow an amount equal to the lease payments under similar terms. Because the Company does not generally borrow on a collateralized basis, it uses its understanding of what its collateralized credit rating would be as an input to deriving an appropriate incremental borrowing rate. The operating lease ROU assets include prepaid lease payments and exclude lease incentives.

[0001032975-26-000021:notes:78]
Intangible Assets

[0001032975-26-000021:notes:79]
The Company's intangible assets include goodwill and intangible assets with finite lives, which primarily include acquired technology and customer contracts and related relationships. Intangible assets with finite lives are carried at cost and amortized using the straight-line method over their useful lives ranging from one to ten years.

[0001032975-26-000021:notes:80]
Impairment of Long-Lived Assets

[0001032975-26-000021:notes:81]
The Company reviews long-lived assets, such as property and equipment, and finite-lived intangible assets, for impairment whenever events indicate that the carrying amounts might not be recoverable. Recoverability of long-lived assets is measured by comparing the projected undiscounted net cash flows associated with those assets to their carrying values. If an asset is considered impaired, it is written down to its fair value, which is determined based on the asset's projected discounted cash flows or appraised value, depending on the nature of the asset. For purposes of recognition of impairment for assets held for use, the Company groups assets and liabilities at the lowest level for which cash flows are separately identifiable.

[0001032975-26-000021:notes:82]
Impairment of Goodwill

[0001032975-26-000021:notes:83]
Goodwill represents the excess of the purchase price over the fair value of the net tangible and identifiable intangible assets acquired in each business combination. The Company conducts a goodwill impairment analysis annually at December 31 or more frequently if indicators of impairment exist or if a decision is made to sell or exit a business. Significant judgments are involved in determining if an indicator of impairment has occurred. Such indicators may include deterioration in general economic conditions, negative developments in equity and credit markets, adverse changes in the markets in which an entity operates, increases in input costs that have a negative effect on earnings and cash flows, or a trend of negative or declining cash flows over multiple periods, among

[0001032975-26-000021:notes:84]
others. The fair value that could be realized in an actual transaction may differ from that used to evaluate the impairment of goodwill.

[0001032975-26-000021:notes:85]
In reviewing goodwill for impairment, the Company has the option to first assess qualitative factors to determine whether the existence of events or circumstances leads to a determination that it is more likely than not (greater than 50%) that the estimated fair value of a reporting unit is less than its carrying amount. The Company also may elect not to perform the qualitative assessment and, instead, proceed directly to the quantitative impairment test. The ultimate outcome of the goodwill impairment review for a reporting unit should be the same whether the Company chooses to perform the qualitative assessment or proceeds directly to the quantitative impairment test. The Company operates as one reporting unit. For the year ended March 31, 2026, the Company elected to perform a qualitative assessment and concluded that it was more likely than not that the fair value of its reporting unit exceeds its carrying amount.

[0001032975-26-000021:notes:86]
Income Taxes

[0001032975-26-000021:notes:87]
The Company provides for income taxes using the asset and liability method, which requires that deferred tax assets and liabilities be recognized for the expected future tax consequences of temporary differences resulting from differing treatment of items for tax and financial reporting purposes, and for operating losses and tax credit carryforwards. In estimating future tax consequences, expected future events are taken into consideration, with the exception of potential tax law or tax rate changes. The Company records a valuation allowance to reduce deferred tax assets to amounts management believes are more likely than not to be realized.

[0001032975-26-000021:notes:88]
The Company's assessment of uncertain tax positions requires that management makes estimates and judgments about the application of tax law, the expected resolution of uncertain tax positions and other matters. In the event that uncertain tax positions are resolved for amounts different than the Company's estimates, or the related statutes of limitations expire without the assessment of additional income taxes, the Company will be required to adjust the amounts of the related assets and liabilities in the period in which such events occur. Such adjustments may have an impact on the Company's income tax provision and its results of operations.

[0001032975-26-000021:notes:89]
Fair Value of Financial Instruments

[0001032975-26-000021:notes:90]
The carrying value of certain of the Company's financial instruments, including cash equivalents, accounts receivable and accounts payable approximates their fair value due to their short maturities.

[0001032975-26-000021:notes:91]
The Company's investment securities portfolio consists of bank demand deposits, short-term time deposits, and U.S. Treasury securities with an original maturity of three months or less and marketable securities (money market and mutual funds) related to a deferred compensation plan.

[0001032975-26-000021:notes:92]
The Company's investments related to the deferred compensation plan are reported at fair value based on quoted market prices. The marketable securities related to the deferred compensation plan are classified as non-current investments, as they are intended to fund the deferred compensation plan's long-term liability. Participants in the deferred compensation plan may select the mutual funds in which their compensation deferrals are invested within the confines of the Rabbi Trust which holds the marketable securities. These securities are recorded at fair value based on quoted market prices. Earnings, gains and losses on deferred compensation investments are included in other income (expense), net in the consolidated statements of operations.

[0001032975-26-000021:notes:93]
The Company also holds certain non-marketable investments that are accounted for as equity method investments and included in other assets in the consolidated balance sheets. In addition, the Company has certain equity investments without readily determinable fair values due to the absence of quoted market prices, the inherent lack of liquidity, and the fact that inputs used to measure fair value are unobservable and require management's judgment. The Company elected the measurement alternative to record these investments at cost and to adjust for impairments and observable price changes resulting from transactions with the same issuer within the statements of operations.

[0001032975-26-000021:notes:94]
Net Income per Share

[0001032975-26-000021:notes:95]
Basic net income per share is computed by dividing net income by the weighted average outstanding shares. Diluted net income per share is computed using the weighted average outstanding shares and dilutive share equivalents. Dilutive share equivalents consist of share-based awards, including stock options, purchase rights under employee share purchase plan, and restricted stock units.

[0001032975-26-000021:notes:96]
The dilutive effect of in-the-money share-based compensation awards is calculated based on the average share price for each fiscal period using the treasury stock method.

[0001032975-26-000021:notes:97]
Share-Based Compensation Expense

[0001032975-26-000021:notes:98]
Share-based compensation expense includes compensation expense for share-based awards granted based on the grant date fair value. The grant date fair value for stock options and stock purchase rights is estimated using the Black-Scholes-Merton option-pricing valuation model. The grant date fair value of service-based restricted stock units ("RSUs") is calculated based on the market price on the date of grant, reduced by estimated dividend yield prior to vesting. The grant date fair value of restricted stock units which vest upon meeting certain market- and performance-based conditions ("PSUs") is estimated using the Monte-Carlo simulation method including the effect of the market condition. Share-based compensation expense is recognized ratably over the respective requisite service periods of the awards and forfeitures are accounted for when they occur. For PSUs, the Company recognizes compensation expense using its estimate of probable outcome at the end of the performance period (i.e., the estimated performance against the performance targets). The Company periodically adjusts the cumulative share-based compensation expense recorded when the probable outcome for the PSUs is updated based upon changes in actual and forecasted financial results.

[0001032975-26-000021:notes:99]
Product Warranty

[0001032975-26-000021:notes:100]
All of the Company's products are covered by standard warranty to be free from defects in material and workmanship for periods ranging from one year to three years. The warranty period varies by product and by region. The Company’s standard warranty does not provide a service beyond assuring that the product complies with agreed-upon specifications and is not sold separately. The standard warranty the Company provides qualifies as an assurance warranty and is not treated as a separate performance obligation. The Company estimates cost of product warranties at the time the related revenue is recognized based on historical warranty claim rates, historical costs, and knowledge of specific product failures that are outside of the Company's typical experience. The Company accrues a warranty liability for estimated costs to provide products, parts or services to repair or replace products in satisfaction of the warranty obligation. Each quarter, the Company re-evaluates its estimates to assess the adequacy of recorded warranty liabilities. When the Company experiences changes in warranty claim activity or costs associated with fulfilling those claims, the warranty liability is adjusted accordingly.

[0001032975-26-000021:notes:101]
Comprehensive Income (Loss)

[0001032975-26-000021:notes:102]
Comprehensive income (loss) is defined as the total change in shareholders' equity during the period other than from transactions with shareholders. Comprehensive income (loss) consists of net income (loss) and other comprehensive income (loss). Other comprehensive income (loss) is comprised of currency translation adjustments from those entities not using the U.S. Dollar as their functional currency, net deferred gains and losses and prior service costs and credits for defined benefit pension plans, and net deferred gains and losses on hedging activity.

[0001032975-26-000021:notes:103]
Treasury Shares

[0001032975-26-000021:notes:104]
The Company periodically repurchases shares in the market at fair value. Shares repurchased are recorded at cost as a reduction of total shareholders' equity. Treasury shares held may be reissued to satisfy the exercise of employee stock options and purchase rights, the vesting of restricted stock units, and acquisitions, or may be canceled with shareholder approval. Treasury shares that are reissued are accounted for using the first-in, first-out basis.

[0001032975-26-000021:notes:105]
When treasury shares are reissued, gains from re-issuance of treasury shares are credited to additional paid-in capital while losses from re-issuance of treasury shares are charged to additional paid-in capital to the extent that there are previously recorded gains to offset the losses, otherwise charged to retained earnings in the consolidated balance sheets. When treasury shares are canceled, the Company deducts the par value from registered shares and reflects the excess of share repurchase cost over par value as a reduction to retained earnings.

[0001032975-26-000021:notes:106]
Derivative Financial Instruments

[0001032975-26-000021:notes:107]
The Company enters into foreign exchange forward and swap contracts to reduce the short-term effects of currency fluctuations on certain foreign currency receivables or payables denominated in currencies other than the functional currencies of its subsidiaries. Gains or losses from changes in the fair value of these contracts that offset transaction losses or gains on foreign currency receivables or payables are recognized immediately and included in other income (expense), net in the consolidated statements of operations.

[0001032975-26-000021:notes:108]
The Company enters into cash flow hedge contracts, including foreign currency forward contracts and foreign currency option contracts, to hedge against exposure to changes in currency exchange rates related to its forecasted inventory purchases. Gains and losses for changes in the fair value of the effective portion of the Company's foreign exchange contracts related to forecasted inventory purchases are deferred as a component of accumulated other comprehensive gain (loss) until the hedged inventory purchases are sold, at which time the gains or losses are reclassified to cost of goods sold.

[0001032975-26-000021:notes:109]
Restructuring Charges

[0001032975-26-000021:notes:110]
The Company's restructuring charges consist of employee severance, one-time termination benefits and ongoing benefits related to the reduction of its workforce, and other costs. Liabilities for costs associated with a restructuring activity are measured at fair value and are recognized when the liability is incurred, as opposed to when management commits to a restructuring plan. One-time termination benefits are expensed at the date the entity notifies the employee, unless the employee must provide future service, in which case the benefits are expensed ratably over the future service period. Ongoing benefits are expensed when restructuring activities are probable and the benefit amounts are estimable. Other costs primarily consist of legal, consulting, and other costs related to employee terminations, and are expensed when incurred. Termination benefits are calculated based on regional benefit practices and local statutory requirements.

[0001032975-26-000021:notes:111]
Recent Accounting Pronouncements Adopted

[0001032975-26-000021:notes:112]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures. ASU 2023-09 requires additional disclosures related to rate reconciliation, income taxes paid, and other disclosures. Under ASU 2023-09, for each annual period presented, public entities are required to (1) disclose specific categories in the tabular rate reconciliation and (2) provide additional information for reconciling items that meet a quantitative threshold. In addition, ASU 2023-09 requires all reporting entities to disclose on an annual basis the amount of income taxes paid disaggregated by federal, state, and foreign taxes as well as the amount of income taxes paid by individual jurisdiction. The Company adopted this ASU in its fiscal year 2026 annual financial statements and applied the standard prospectively. See Note 7 for additional information.

[0001032975-26-000021:notes:113]
New Accounting Pronouncements Not Yet Adopted

[0001032975-26-000021:notes:114]
In November 2024, the FASB issued ASU 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses. ASU 2024-03 requires all public entities to disclose in the notes to the financial statements the amounts of purchases of inventory, employee compensation, depreciation, and intangible asset amortization included in each expense caption of the income statement. ASU 2024-03 is effective for fiscal years beginning after December 15, 2026 and interim periods within fiscal years beginning after December 15, 2027. ASU 2024-03 can be applied either prospectively or retrospectively. Early adoption is permitted. The Company is currently evaluating the impact of ASU 2024-03 on its consolidated financial statements and related disclosures.

[0001032975-26-000021:notes:115]
In July 2025, the FASB issued ASU No. 2025-05, Financial Instruments—Credit Losses (Topic 326): Measurement of Credit Losses for Accounts Receivable and Contract Assets. ASU 2025-05 provides a practical expedient that permits entities to assume that current conditions as of the balance sheet date will remain unchanged over the remaining life of current accounts receivable and current contract assets when estimating the expected credit losses. ASU 2025-05 is effective for annual periods beginning after December 15, 2025, and interim periods within those annual reporting periods. Early adoption is permitted. ASU 2025-05 should be applied on a prospective basis. The Company does not expect the adoption of ASU 2025-05 to have a material impact on its consolidated financial statements or related disclosures.

[0001032975-26-000021:notes:116]
In September 2025, the FASB issued ASU No. 2025-06, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal-Use Software. ASU 2025-06 updates the cost capitalization threshold for internal-use software development costs by removing all references to software project development stages and providing new guidance on how to evaluate whether the probable-to-complete recognition threshold has been met. ASU 2025-06 is effective for annual periods beginning after December 15, 2027, and interim periods within those annual reporting periods. Early adoption is permitted. ASU 2025-06 can be applied on a prospective basis, with retrospective or modified retrospective application permitted. The Company is currently evaluating the impact of ASU 2025-06 on its consolidated financial statements and related disclosures.


## us-gaap:EarningsPerShareTextBlock

[0001032975-26-000021:notes:117]
Net Income Per Share 
The following table summarizes the computations of basic and diluted net income per share for fiscal years 2026, 2025 and 2024 (in thousands except per share amounts):

[0001032975-26-000021:notes:118]
|  |  | Years Ended March 31, |
|  |  | 2026 |  | 2025 |  | 2024 |
| Net income |  | $ | 711,187 |  |  | $ | 631,529 |  |  | $ | 612,143 |  |
| Shares used in net income per share computation: |  |  |  |  |  |  |
| Weighted average shares outstanding - basic |  | 146,775 |  |  | 151,322 |  |  | 156,776 |  |
| Effect of potentially dilutive equivalent shares |  | 1,433 |  |  | 1,462 |  |  | 1,395 |  |
| Weighted average shares outstanding - diluted |  | 148,208 |  |  | 152,784 |  |  | 158,171 |  |
| Net income per share: |  |  |  |  |  |  |
| Basic |  | $ | 4.85 |  |  | $ | 4.17 |  |  | $ | 3.90 |  |
| Diluted |  | $ | 4.80 |  |  | $ | 4.13 |  |  | $ | 3.87 |  |

[0001032975-26-000021:notes:119]
Share equivalents attributable to outstanding stock options, restricted stock units and employee share purchase plans ("ESPP") totaling 0.5 million, 0.7 million, and 1.1 million shares during fiscal years 2026, 2025 and 2024, respectively, were excluded from the calculation of diluted net income per share because their effect would have been antidilutive. A small number of PSUs were not included in the dilutive net income per share calculation in fiscal years 2025 and 2024 because all necessary conditions had not been satisfied, and those shares were not issuable if the end of the reporting period were the end of the performance contingency period.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001032975-26-000021:notes:120]
Employee Stock-Based Compensation 
As of March 31, 2026, the Company offers the 2006 Employee Share Purchase Plan (Non-U.S.), as amended and restated ("2006 ESPP"), the 1996 Employee Share Purchase Plan (U.S.), as amended and restated ("1996 ESPP"), and the 2006 Stock Incentive Plan ("2006 Plan") as amended and restated. Shares issued to employees as a result of purchases or exercises under these plans are generally issued from shares held in treasury stock.

[0001032975-26-000021:notes:121]
Under the 1996 ESPP and 2006 ESPP plans, eligible employees may purchase shares at the lower of 85% of the fair market value at the beginning or the end of each offering period, which is generally six months. Subject to continued participation in these plans, purchase agreements are automatically executed at the end of each offering period. An aggregate of 29.0 million shares were reserved for issuance under the 1996 and 2006 ESPP plans. As of March 31, 2026, a total of 2.4 million shares were available for new awards under these plans.

[0001032975-26-000021:notes:122]
The 2006 Plan provides for the grant to eligible employees and non-employee directors of stock options, stock appreciation rights, and restricted stock units. Awards under the 2006 Plan may be conditioned on continued employment, the passage of time or the satisfaction of performance and market vesting criteria. The 2006 Plan, as amended, has no expiration date. On June 29, 2022, the Board authorized 3.3 million additional shares for issuance under the 2006 Plan. An aggregate of 33.8 million shares were reserved for issuance under the 2006 Plan. As of March 31, 2026, a total of 6.7 million shares were available for new awards under this plan.

[0001032975-26-000021:notes:123]
Stock options granted to employees under the 2006 Plan have terms not exceeding ten years and are issued at exercise prices not less than the fair market value on the date of grant.

[0001032975-26-000021:notes:124]
Service-based restricted stock units ("RSUs") granted to employees under the 2006 Plan generally vest in four equal annual installments on the grant date anniversary. RSUs granted to non-executive board members under the 2006 Plan vest on the grant date anniversary, or earlier on the date of the next annual general meeting following the grant date if the non-executive board member is not re-elected as a director at the annual general meeting.

[0001032975-26-000021:notes:125]
Restricted stock units with certain market- and performance-based conditions ("PSUs") granted to employees under the 2006 Plan generally vest at the end of the three-year performance period upon meeting predetermined financial metrics over three years, with the number of shares to be received upon vesting determined based on constant currency revenue growth rate, adjusted operating income (loss) and the Company's total shareholder return ("TSR") relative to the performance of companies in the Russell 3000 Index over the same three years period.

[0001032975-26-000021:notes:126]
The following table summarizes share-based compensation expense and total income tax benefit recognized for fiscal years 2026, 2025 and 2024 (in thousands):

[0001032975-26-000021:notes:127]
|  |  | Years Ended March 31, |
|  |  | 2026 |  | 2025 |  | 2024 |
| Cost of goods sold |  | $ | 10,631 |  |  | $ | 10,021 |  |  | $ | 8,004 |  |
| Marketing and selling |  | 42,506 |  |  | 40,378 |  |  | 35,780 |  |
| Research and development |  | 22,904 |  |  | 20,180 |  |  | 17,836 |  |
| General and administrative |  | 36,351 |  |  | 19,334 |  |  | 21,269 |  |
| Total share-based compensation expense |  | 112,392 |  |  | 89,913 |  |  | 82,889 |  |
| Income tax benefit |  | (20,721) |  |  | (20,148) |  |  | (15,305) |  |
| Total share-based compensation expense, net of income tax benefit |  | $ | 91,671 |  |  | $ | 69,765 |  |  | $ | 67,584 |  |

[0001032975-26-000021:notes:128]
The income tax benefit in the respective periods primarily consisted of tax benefits related to the share-based compensation expense for the period and direct tax benefit realized, including net excess tax benefits recognized from share-based awards vested or exercised during the period.

[0001032975-26-000021:notes:129]
Share-based compensation costs capitalized as part of inventory were $8.4 million, $7.6 million, and $6.3 million for the fiscal year ended March 31, 2026, 2025 and 2024, respectively.

[0001032975-26-000021:notes:130]
As of March 31, 2026, there was $151.6 million of total future stock-based compensation cost to be recognized over a weighted-average period of 2.3 years.

[0001032975-26-000021:notes:131]
The estimates of share-based compensation expense require a number of complex and subjective assumptions including stock price volatility, employee exercise patterns, probability of achievement of the set performance condition, dividend yield, related tax effects and the selection of an appropriate fair value model.

[0001032975-26-000021:notes:132]
The grant date fair value of the ESPP using the Black-Scholes-Merton option-pricing valuation model and the grant date fair value of the PSUs using the Monte-Carlo simulation method are determined with the following assumptions:

[0001032975-26-000021:notes:133]
|  |  |  | Employee Stock Purchase Plans |
|  |  |  | Years Ended March 31, |
|  |  |  | 2026 |  | 2025 |  | 2024 |
| Expected dividend rate |  |  | 1.79% |  | 1.35% |  | 1.61% |
| Risk-free interest rate |  |  | 3.90% |  | 4.71% |  | 5.36% |
| Expected volatility |  |  | 38% |  | 29% |  | 33% |
| Expected term (years) |  |  | 0.5 |  | 0.5 |  | 0.5 |
| Weighted average grant date fair value per share |  |  | $23.10 |  | $21.74 |  | $19.02 |

[0001032975-26-000021:notes:134]
| PSUs |  | Years Ended March 31, |
|  |  | 2026 |  | 2025 |  | 2024 |
| Expected dividend rate |  | 1.63% |  | 1.41% |  | 1.90% |
| Risk-free interest rate |  | 3.90% |  | 4.55% |  | 3.83% |
| Expected volatility |  | 37% |  | 38% |  | 41% |
| Expected term (years) |  | 3.0 |  | 3.0 |  | 3.0 |

[0001032975-26-000021:notes:135]
The expected dividend rate assumption is based on the Company's history and future expectations of dividend payouts. Unvested stock-awards are not eligible for these dividends. The expected term is based on the purchase offerings periods expected to remain outstanding for employee stock purchase plan or the performance period for PSUs. Expected volatility is based on historical volatility using the Company's daily closing prices, or including the volatility of components of the Russell 3000 Index for PSUs, over the expected term. The Company considers the historical price volatility of its shares as most representative of future volatility. The risk-free interest rate

[0001032975-26-000021:notes:136]
assumptions are based upon the implied yield of U.S. Treasury zero-coupon issues for the expected term of the Company's share-based awards.

[0001032975-26-000021:notes:137]
For PSUs, the Company estimates the probability and timing of the achievement of the set performance condition at the time of the grant based on the historical financial performance and the financial forecast in the remaining performance period and reassesses the probability in subsequent periods when actual results or new information become available.

[0001032975-26-000021:notes:138]
A summary of the Company's stock option activities under all stock plans for fiscal years 2026, 2025 and 2024 is as follows:

[0001032975-26-000021:notes:139]
|  |  | Number of Shares |  | Weighted-Average Exercise Price |  | Weighted-Average Remaining Contractual Term |  | Aggregate Intrinsic Value |  |  |  |  |
|  |  | (In thousands) |  |  |  | (Years) |  | (In thousands) |  |  |  |  |
| Outstanding, March 31, 2023 |  | 1,120 |  |  |  |  |  |  |  |  |  |  |  |
| Exercised |  | (181) |  |  |  |  |  |  | $ | 6,160 |  |  |  |  |  |
| Forfeited |  | (176) |  |  |  |  |  |  |  |  |  |  |  |
| Outstanding, March 31, 2024 |  | 763 |  |  |  |  |  |  |  |  |  |  |  |
| Exercised |  | (111) |  |  |  |  |  |  | $ | 1,483 |  |  |  |  |  |
| Forfeited |  | (65) |  |  |  |  |  |  |  |  |  |  |  |
| Outstanding, March 31, 2025 |  | 587 |  |  | $ | 64 |  |  | 5.3 |  | $ | 11,768 |  |  |  |  |  |
| Exercised |  | (129) |  |  | $ | 67 |  |  |  |  | $ | 4,371 |  |  |  |  |  |
| Outstanding, March 31, 2026 |  | 458 |  |  | $ | 64 |  |  | 4.7 |  | $ | 12,500 |  |  |  |  |  |
| Vested and exercisable, March 31, 2026 |  | 458 |  |  | $ | 64 |  |  | 4.7 |  | $ | 12,500 |  |  |  |  |  |

[0001032975-26-000021:notes:140]
A summary of the Company's RSU and PSU activities for fiscal years 2026, 2025 and 2024 is as follows:

[0001032975-26-000021:notes:141]
|  |  | Number of Shares |  | Weighted-Average Grant Date Fair Value |  | Aggregate Fair Value |  |  |  |  |
|  |  | (In thousands) |  |  |  | (In thousands) |  |  |  |  |
| Outstanding, March 31, 2023 |  | 3,456 |  |  | $ | 66 |  |  |  |  |  |  |  |
| Granted—RSUs |  | 1,396 |  |  | $ | 59 |  |  |  |  |  |  |  |
| Granted—PSUs |  | 457 |  |  | $ | 67 |  |  |  |  |  |  |  |
| Vested |  | (1,200) |  |  |  |  | $ | 92,340 |  |  |  |  |  |
| Forfeited |  | (631) |  |  |  |  |  |  |  |  |  |
| Outstanding, March 31, 2024 |  | 3,478 |  |  | $ | 65 |  |  |  |  |  |  |  |
| Granted—RSUs |  | 931 |  |  | $ | 93 |  |  |  |  |  |  |  |
| Granted—PSUs |  | 281 |  |  | $ | 91 |  |  |  |  |  |  |  |
| Vested |  | (1,172) |  |  |  |  | $ | 113,553 |  |  |  |  |  |
| Forfeited |  | (462) |  |  |  |  |  |  |  |  |  |
| Outstanding, March 31, 2025 |  | 3,056 |  |  | $ | 73 |  |  |  |  |  |  |  |
| Granted—RSUs |  | 1,017 |  |  | $ | 84 |  |  |  |  |  |  |  |
| Granted—PSUs |  | 275 |  |  | $ | 90 |  |  |  |  |  |  |  |
| Vested |  | (895) |  |  | $ | 72 |  |  | $ | 78,466 |  |  |  |  |  |
| Forfeited |  | (512) |  |  | $ | 72 |  |  |  |  |  |  |  |
| Outstanding, March 31, 2026 |  | 2,941 |  |  | $ | 79 |  |  |  |  |  |  |  |

[0001032975-26-000021:notes:142]
The shares outstanding as of March 31, 2026 above include 0.7 million shares of PSUs. The Company presents the number of PSUs and weighted-average grant date fair value at 100 percent of the performance target; however, the aggregate fair value of shares vested is based on the actual number of PSUs vested according to achievement of the financial metrics over the performance period.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001032975-26-000021:notes:143]
Employee Benefit Plans
Defined Benefit Plans

[0001032975-26-000021:notes:144]
Certain subsidiaries of the Company sponsor defined benefit pension plans or non-retirement post-employment benefits covering substantially all of their employees. Benefits are provided based on employees' years of service and earnings, or in accordance with applicable employee benefit regulations. The Company's practice is to fund amounts sufficient to meet the requirements set forth in the applicable employee benefit and tax regulations.

[0001032975-26-000021:notes:145]
The Company recognizes the overfunded or underfunded status of defined benefit pension plans and non-retirement post-employment benefit obligations as an asset or liability in its consolidated balance sheets and recognizes changes in the funded status of defined benefit pension plans in the year in which the changes occur through accumulated other comprehensive income (loss), which is a component of shareholders' equity. Each plan's assets and benefit obligations are generally remeasured as of March 31 each year.

[0001032975-26-000021:notes:146]
The net periodic benefit cost of the defined benefit pension plans and the non-retirement post-employment benefit obligations for fiscal years 2026, 2025 and 2024 was as follows (in thousands):

[0001032975-26-000021:notes:147]
|  |  | Years Ended March 31, |
|  |  | 2026 |  | 2025 |  | 2024 |
| Service costs |  | $ | 13,708 |  |  | $ | 11,875 |  |  | $ | 11,479 |  |
| Interest costs |  | 3,564 |  |  | 3,298 |  |  | 3,844 |  |
| Expected return on plan assets |  | (9,674) |  |  | (7,671) |  |  | (6,950) |  |
| Amortization: |  |  |  |  |  |  |
| Net prior service cost (credit) recognized |  | (658) |  |  | 309 |  |  | (500) |  |
| Net actuarial loss (gain) recognized |  | 919 |  |  | 450 |  |  | (179) |  |
| Settlement loss |  | 1,881 |  |  | — |  |  | 922 |  |
| Total net periodic benefit cost |  | $ | 9,740 |  |  | $ | 8,261 |  |  | $ | 8,616 |  |

[0001032975-26-000021:notes:148]
The components of net periodic benefit cost other than the service cost component are included in other income (expense), net, in the consolidated statements of operations.

[0001032975-26-000021:notes:149]
The changes in projected benefit obligations for fiscal years 2026 and 2025 were as follows (in thousands):

[0001032975-26-000021:notes:150]
|  |  | Years Ended March 31, |
|  |  | 2026 |  | 2025 |
| Projected benefit obligations, beginning of the year |  | $ | 259,141 |  |  | $ | 213,477 |  |
| Service costs |  | 13,708 |  |  | 11,875 |  |
| Interest costs |  | 3,564 |  |  | 3,298 |  |
| Plan participant contributions |  | 7,088 |  |  | 6,676 |  |
| Actuarial loss |  | 2,216 |  |  | 13,691 |  |
| Benefits paid |  | (3,475) |  |  | (10,578) |  |
| Transfer of prior vested benefits |  | 7,416 |  |  | 15,301 |  |
| Plan amendments |  | — |  |  | 909 |  |
| Settlement |  | (18,255) |  |  | — |  |
| Administrative expense paid |  | (174) |  |  | (157) |  |
| Currency exchange rate changes |  | 24,415 |  |  | 4,649 |  |
| Projected benefit obligations, end of the year |  | $ | 295,644 |  |  | $ | 259,141 |  |

[0001032975-26-000021:notes:151]
The accumulated benefit obligation for all defined benefit pension plans as of March 31, 2026 and 2025 was $262.6 million and $227.7 million, respectively.

[0001032975-26-000021:notes:152]
Actuarial loss for fiscal year 2025, related to changes in the Company’s pension benefit obligation, was primarily driven by fluctuations in the discount rate. In fiscal year 2026, actuarial loss was not material.

[0001032975-26-000021:notes:153]
The changes in the fair value of plan assets for fiscal years 2026 and 2025 were as follows (in thousands):

[0001032975-26-000021:notes:154]
|  |  | Years Ended March 31, |
|  |  | 2026 |  | 2025 |
| Fair value of plan assets, beginning of the year |  | $ | 201,459 |  |  | $ | 170,640 |  |
| Actual return on plan assets |  | 9,386 |  |  | 5,076 |  |
| Employer contributions |  | 10,544 |  |  | 10,351 |  |
| Plan participant contributions |  | 7,088 |  |  | 6,676 |  |
| Benefits paid |  | (3,475) |  |  | (10,578) |  |
| Transfer of prior vested benefits |  | 7,416 |  |  | 15,301 |  |
| Settlement |  | (18,255) |  |  | — |  |
| Administrative expenses paid |  | (174) |  |  | (157) |  |
| Currency exchange rate changes |  | 19,842 |  |  | 4,150 |  |
| Fair value of plan assets, end of the year |  | $ | 233,831 |  |  | $ | 201,459 |  |

[0001032975-26-000021:notes:155]
The Company's investment objectives are to ensure that the assets of its defined benefit plans are invested to provide an optimal rate of investment return on the total investment portfolio, consistent with the assumption of a reasonable risk level, and to ensure that pension funds are available to meet the plans' benefit obligations as they become due. The Company believes that a well-diversified investment portfolio will result in the highest attainable investment return with an acceptable level of overall risk. Investment strategies and allocation decisions are also governed by applicable governmental regulatory agencies. The Company's investment strategy with respect to its largest defined benefit plan, which is available only to Swiss employees, is to invest per the following allocation: 33% in equities, 28% in bonds, 28% in real estate, 4% in cash and cash equivalents and the remaining in other investments. The Company can invest in real estate funds, commodity funds, and hedge funds depending upon economic conditions.

[0001032975-26-000021:notes:156]
The following tables present the fair value of the defined benefit pension plan assets by major categories and by levels within the fair value hierarchy as of March 31, 2026 and 2025 (in thousands):

[0001032975-26-000021:notes:157]
|  |  | March 31, |
|  |  | 2026 |  | 2025 |
|  |  | Level 1 |  | Level 2 |  |  |  | Total |  | Level 1 |  | Level 2 |  |  |  | Total |
| Cash and cash equivalents |  | $ | 26,588 |  |  | $ | — |  |  |  |  | $ | 26,588 |  |  | $ | 21,202 |  |  | $ | — |  |  |  |  | $ | 21,202 |  |
| Equity securities |  | 80,223 |  |  | — |  |  |  |  | 80,223 |  |  | 60,867 |  |  | — |  |  |  |  | 60,867 |  |
| Debt securities |  | 52,819 |  |  | — |  |  |  |  | 52,819 |  |  | 50,178 |  |  | — |  |  |  |  | 50,178 |  |
| Real estate funds |  | 31,979 |  |  | 19,443 |  |  |  |  | 51,422 |  |  | 44,906 |  |  | 6,833 |  |  |  |  | 51,739 |  |
| Hedge funds |  | — |  |  | 13,556 |  |  |  |  | 13,556 |  |  | — |  |  | 8,994 |  |  |  |  | 8,994 |  |
| Other |  | 8,721 |  |  | 502 |  |  |  |  | 9,223 |  |  | 8,005 |  |  | 474 |  |  |  |  | 8,479 |  |
| Total fair value of plan assets |  | $ | 200,330 |  |  | $ | 33,501 |  |  |  |  | $ | 233,831 |  |  | $ | 185,158 |  |  | $ | 16,301 |  |  |  |  | $ | 201,459 |  |

[0001032975-26-000021:notes:158]
The funded status of the plans was as follows (in thousands):

[0001032975-26-000021:notes:159]
|  |  | Years Ended March 31, |
|  |  | 2026 |  | 2025 |
| Fair value of plan assets |  | $ | 233,831 |  |  | $ | 201,459 |  |
| Less: projected benefit obligations |  | 295,644 |  |  | 259,141 |  |
| Underfunded status |  | $ | (61,813) |  |  | $ | (57,682) |  |

[0001032975-26-000021:notes:160]
Amounts recognized on the balance sheets for the plans were as follows (in thousands):

[0001032975-26-000021:notes:161]
|  |  | March 31, |
|  |  | 2026 |  | 2025 |
| Current liabilities |  | $ | 2,036 |  |  | $ | 1,728 |  |
| Non-current liabilities |  | 59,777 |  |  | 55,954 |  |
| Total liabilities |  | $ | 61,813 |  |  | $ | 57,682 |  |

[0001032975-26-000021:notes:162]
Amounts recognized in accumulated other comprehensive income (loss) related to defined benefit pension plans were as follows (in thousands):

[0001032975-26-000021:notes:163]
|  |  | March 31, |
|  |  | 2026 |  | 2025 |  |  |
| Net prior service credits |  | $ | 218 |  |  | $ | 820 |  |  |  |
| Net actuarial loss |  | (22,709) |  |  | (22,696) |  |  |  |
| Accumulated other comprehensive loss |  | (22,491) |  |  | (21,876) |  |  |  |
| Deferred taxes |  | 747 |  |  | (3,400) |  |  |  |
| Accumulated other comprehensive loss, net of tax |  | $ | (21,744) |  |  | $ | (25,276) |  |  |  |

[0001032975-26-000021:notes:164]
The actuarial assumptions for the defined benefit plans were as follows:

[0001032975-26-000021:notes:165]
|  |  | Years Ended March 31, |
|  |  | 2026 |  | 2025 |
| Benefit Obligations: |  |  |  |  |
| Discount rate |  | 1.10%- 6.75% |  | 1.20% - 6.50% |
| Estimated rate of compensation increase |  | 2.00% - 10.00% |  | 2.00% - 10.00% |
| Cash balance interest credit rate |  | 0.75% - 1.75% |  | 0.75% - 1.75% |

[0001032975-26-000021:notes:166]
|  |  | Years Ended March 31, |
|  |  | 2026 |  | 2025 |  | 2024 |
| Net Periodic Costs: |  |  |  |  |  |  |
| Discount rate |  | 1.20% - 6.50% |  | 1.50% - 7.00% |  | 1.50% - 7.25% |
| Estimated rate of compensation increase |  | 2.00% - 10.00% |  | 2.25% - 10.00% |  | 2.25% - 10.00% |
| Expected average rate of return on plan assets |  | 1.00% - 4.50% |  | 1.00% - 5.25% |  | 0.50% - 4.50% |
| Cash balance interest credit rate |  | 0.75% - 1.75% |  | 0.50% - 1.75% |  | 0.50% - 1.75% |

[0001032975-26-000021:notes:167]
The discount rate is estimated based on corporate bond yields or securities of similar quality in the respective country, with a duration approximating the period over which the benefit obligations are expected to be paid. The Company bases the compensation increase assumptions on historical experience and future expectations. The expected average rate of return for the Company's defined benefit pension plans represents the average rate of return expected to be earned on plan assets over the period that the benefit obligations are expected to be paid, based on government bond notes in the respective country, adjusted for corporate risk premiums as appropriate.

[0001032975-26-000021:notes:168]
The following table reflects the benefit payments that the Company expects the plans to pay in the periods noted (in thousands):

[0001032975-26-000021:notes:169]
| Years Ending March 31, |  |  |
| 2027 |  | $ | 20,309 |  |
| 2028 |  | $ | 17,109 |  |
| 2029 |  | $ | 16,841 |  |
| 2030 |  | $ | 17,194 |  |
| 2031 |  | $ | 16,247 |  |
| 2032-2036 |  | $ | 89,012 |  |

[0001032975-26-000021:notes:170]
The Company expects to contribute $8.4 million to its defined benefit pension plans during fiscal year 2027.

[0001032975-26-000021:notes:171]
Defined Contribution Plans

[0001032975-26-000021:notes:172]
Certain of the Company's subsidiaries have defined contribution employee benefit plans covering all or a portion of their employees. Contributions to these plans are discretionary for certain plans and are based on specified or statutory requirements for others. The charges to expense for these plans for fiscal years 2026, 2025 and 2024, were $15.7 million, $13.7 million and $14.4 million, respectively.

[0001032975-26-000021:notes:173]
Deferred Compensation Plan

[0001032975-26-000021:notes:174]
One of the Company's subsidiaries offers a deferred compensation plan that permits eligible employees to make 100% vested salary and incentive compensation deferrals within established limits. The Company does not make contributions to the plan.

[0001032975-26-000021:notes:175]
The deferred compensation plan's assets consist of marketable securities and are included in other assets on the consolidated balance sheets. The marketable securities were recorded at a fair value of $30.5 million and $29.0 million as of March 31, 2026 and 2025, respectively, based on quoted market prices (see Note 9). The Company also had deferred compensation liability of $30.5 million and $29.0 million, which are included in other non-current liabilities on the consolidated balance sheets as of March 31, 2026 and 2025, respectively. Earnings, gains and losses on deferred compensation investments are included in other income (expense), net (see Note 6) and corresponding changes in deferred compensation liability are included in operating expenses and cost of goods sold in the consolidated statements of operations.


## us-gaap:InterestAndOtherIncomeTextBlock

[0001032975-26-000021:notes:176]
Other Income (Expense), Net
Other income (expense), net, comprises the following (in thousands):

[0001032975-26-000021:notes:177]
|  |  | Years Ended March 31, |
|  |  | 2026 |  | 2025 |  | 2024 |
| Investment gain related to the deferred compensation plan |  | $ | 3,714 |  |  | $ | 2,131 |  |  | $ | 4,320 |  |
| Currency exchange loss, net |  | (3,733) |  |  | (6,401) |  |  | (8,770) |  |
| Loss on investments, net (1) |  | (612) |  |  | (2,029) |  |  | (14,674) |  |
| Non-service cost net pension income and other (2) |  | 3,710 |  |  | 3,319 |  |  | 2,748 |  |
| Other income (expense), net |  | $ | 3,079 |  |  | $ | (2,980) |  |  | $ | (16,376) |  |

[0001032975-26-000021:notes:178]
(1) Includes unrealized gain (loss) from the change in fair value of investments, income (loss) on equity-method investments, and impairment of investments during the periods presented, as applicable (see Note 9).

[0001032975-26-000021:notes:179]
(2) Includes the components of net periodic benefit cost of defined benefit plans other than the service cost component (see Note 5).


## us-gaap:IncomeTaxDisclosureTextBlock

[0001032975-26-000021:notes:180]
Income Taxes 
The Company is incorporated in Switzerland but operates in various countries with differing tax laws and rates. Further, a portion of the Company's income before taxes and the provision for income taxes is generated outside of Switzerland.

[0001032975-26-000021:notes:181]
Income from continuing operations before income taxes for fiscal years 2026, 2025 and 2024 is summarized as follows (in thousands):

[0001032975-26-000021:notes:182]
|  |  | Years Ended March 31, |
|  |  | 2026 |  | 2025 |  | 2024 |
| Swiss |  | $ | 550,787 |  |  | $ | 492,941 |  |  | $ | 502,291 |  |
| Non-Swiss |  | 275,732 |  |  | 213,931 |  |  | 119,305 |  |
| Income before taxes |  | $ | 826,519 |  |  | $ | 706,872 |  |  | $ | 621,596 |  |

[0001032975-26-000021:notes:183]
The provision for income taxes is summarized as follows (in thousands):

[0001032975-26-000021:notes:184]
|  |  | Years Ended March 31, |
|  |  | 2026 |  | 2025 |  | 2024 |
| Current: |  |  |  |  |  |  |
| Swiss |  | $ | 54,644 |  |  | $ | (14,673) |  |  | $ | 26,833 |  |
| Non-Swiss |  | 30,866 |  |  | 33,473 |  |  | 25,044 |  |
| Deferred: |  |  |  |  |  |  |
| Swiss |  | 38,192 |  |  | 45,283 |  |  | (47,517) |  |
| Non-Swiss |  | (8,370) |  |  | 11,260 |  |  | 5,093 |  |
| Provision for income taxes |  | $ | 115,332 |  |  | $ | 75,343 |  |  | $ | 9,453 |  |

[0001032975-26-000021:notes:185]
The following table is presented in accordance with ASU 2023-09, which the Company adopted in fiscal year 2026. The Company has adopted this standard prospectively. See Note 2 for additional information. The difference between the provision for income taxes and the expected tax provision at the Swiss statutory income tax rate of 8.5% for the current period is reconciled below (in thousands):

[0001032975-26-000021:notes:186]
|  |  | Year Ended March 31, |
|  |  | 2026 |  | As a percent |
| Pretax book income at Statutory rate |  | $ | 70,250 |  |  | 8.5 | % |
| Domestic federal reconciling items: |  |  |  |  |
| Federal Tax Deduction |  | (4,436) |  |  | (0.5) | % |
| Participation Exemption |  | (33,617) |  |  | (4.1) | % |
| Domestic state and local income taxes: |  |  |  |  |
| Vaud |  | 43,812 |  |  | 5.3 | % |
| Zurich |  | 415 |  |  | 0.1 | % |
| Domestic other, net |  | 4,213 |  |  | 0.5 | % |
| Foreign reconciling items: |  |  |  |  |
| U.S.: |  |  |  |  |
| Statutory tax rate difference between United States and Switzerland |  | 13,948 |  |  | 1.7 | % |
| Foreign derived intangible income |  | (4,192) |  |  | (0.5) | % |
| State tax expense, net of federal benefit |  | 4,189 |  |  | 0.5 | % |
| Tax credits |  | (6,022) |  |  | (0.7) | % |
| Non-deductible executive compensation |  | 4,314 |  |  | 0.5 | % |
| Other, net |  | 346 |  |  | — | % |
| China: |  |  |  |  |
| Statutory tax rate difference between China and Switzerland |  | 8,931 |  |  | 1.1 | % |
| Other, net |  | 118 |  |  | — | % |
| Hong Kong - Tax exempt dividends |  | (7,402) |  |  | (0.9) | % |
| Other foreign jurisdictions |  | 45,138 |  |  | 5.5 | % |
| Changes in unrecognized tax benefits |  | (24,673) |  |  | (3.0) | % |
| Effective Tax Rate |  | $ | 115,332 |  |  | 14.0 | % |

[0001032975-26-000021:notes:187]
The effective income tax rate in 2026 includes the tax effect of the expiration of statutes of limitation of uncertain tax positions and non-taxable dividend distributions, offset by foreign earnings taxed at different rates than the statutory rate.

[0001032975-26-000021:notes:188]
The difference between the provision for income taxes and the expected tax provision at the Swiss statutory income tax rate of 8.5% is reconciled for prior periods as previously disclosed prior to the adoption of ASU 2023-09 (in thousands):

[0001032975-26-000021:notes:189]
|  | Years Ended March 31, |
|  |  | 2025 |  | 2024 |
| Expected tax provision at statutory income tax rates |  | $ | 60,084 |  |  | $ | 52,836 |  |
| Income taxes at different rates |  | 68,212 |  |  | 47,595 |  |
| Research and development tax credits |  | (6,797) |  |  | (9,738) |  |
| Swiss Tax Benefits |  | — |  |  | (50,051) |  |
| Executive compensation |  | 980 |  |  | 407 |  |
| Stock-based compensation |  | (2,162) |  |  | 4,019 |  |
| Deferred tax effects from TRAF |  | — |  |  | (33,926) |  |
| Valuation allowance |  | 1,000 |  |  | 4,780 |  |
| Restructuring credits |  | (817) |  |  | — |  |
| Unrecognized tax benefits/ Audit resolution and statute lapse |  | (43,333) |  |  | 11,535 |  |
| FDII deduction |  | (1,424) |  |  | (18,675) |  |
| Other, net |  | (400) |  |  | 671 |  |
| Provision for income taxes |  | $ | 75,343 |  |  | $ | 9,453 |  |

[0001032975-26-000021:notes:190]
The effective income tax rate in 2025 includes the tax effect of audit resolutions and the expiration of statutes of limitation of uncertain tax positions totaling $53.3 million, offset by the increase to unrecognized tax benefits in 2025 of $10.0 million. The effective tax rate in 2024 includes the discrete tax benefits recognized in fiscal year 2024 for the benefit of future Swiss tax deductions, the remeasurement of the tax basis of goodwill under TRAF (as defined below), FDII (as defined below) incentive provided by the Tax Cuts and Jobs Act and remeasurement of the Company's Swiss deferred tax assets due to a change in tax rate.

[0001032975-26-000021:notes:191]
On March 28, 2024, the Swiss canton of Vaud confirmed a future tax benefit to be recognized for ten years. This resulted in the Company recording an income tax benefit of $50.1 million during the fiscal year ended March 31, 2024, which will be utilized over a ten-year period.

[0001032975-26-000021:notes:192]
The canton of Vaud completed the legislative process to enact the Swiss Federal Act on Tax Reform and AHV Financing (“TRAF”), a reform to better align the Swiss tax system to international tax standards on March 20, 2020 that took effect as of January 1, 2020. In March 2020, the Company increased the tax basis of goodwill, as a transition measure under TRAF, to be amortized over ten years beginning on January 1, 2020. During the fiscal year ended March 31, 2024, the Company remeasured the tax basis of goodwill under TRAF, which resulted in an income tax benefit of $25.1 million, net of assessment for uncertain tax positions. The remeasurement of the step-up will be amortized over the remaining ten-year amortization period.

[0001032975-26-000021:notes:193]
On December 29, 2023, a change to the cantonal tax legislation was published. According to the law approved by the Vaud parliament, a progressive scale will be applicable for cantonal tax purposes resulting in an increase from the then current tax rate of 13.61% to 14.28% effective fiscal year 2025. The increase in tax rate resulted in a tax benefit of $5.1 million due to a remeasurement of the Company's Swiss deferred tax assets in the fiscal year ended March 31, 2024.

[0001032975-26-000021:notes:194]
The Tax Cuts and Jobs Act enacted Section 250, which provides for a deduction with respect to Global Intangible Low-Taxed Income ("GILTI") and Foreign-Derived Intangible Income ("FDII") in the U.S. The application of this tax incentive is inherently complex. During the fiscal year ended March 31, 2024, the Company analyzed the applicability of FDII and determined that this tax incentive applies to fiscal years 2021, 2022 and 2023. As a result, the Company realized a tax benefit of $18.7 million related to FDII. The Company has also concluded that any GILTI tax since the enactment of Tax Cuts and Jobs Act is immaterial.

[0001032975-26-000021:notes:195]
On July 4, 2025, the One Big Beautiful Bill Act (the "OBBBA") was enacted into law in the United States and most relevant provisions will be effective for the Company beginning in fiscal year 2027. The OBBBA includes numerous provisions that affect corporate taxation, impacting areas such as R&D expensing, bonus depreciation, and international tax provisions. The Company has reviewed the provisions of the OBBBA to determine the potential impact on the Company's financial statements. Based on this review, and considering the Company's current tax position and operations, at this time the Company does not expect the OBBBA to have a material impact on its income taxes, including current and deferred tax balances and the effective tax rate.

[0001032975-26-000021:notes:196]
For the fiscal year ended March 31, 2026, the Company assessed its exposure to the OECD Pillar Two global minimum tax rules. The Company has determined that, for the fiscal year 2026, most jurisdictions in which it operates should qualify for the transitional Country-by-Country Reporting ("CbCR") safe harbor, as outlined in the OECD Administrative Guidance and enacted domestic legislation. The Company's CbCR has been prepared in accordance with the requirements for a Qualified CbCR, using qualified financial statements. Based on this data, most jurisdictions continue to meet safe harbor qualifications at 16% tax rates, and therefore, the Company is only required to perform a detailed Pillar Two top-up tax calculation for limited jurisdictions. The estimated top up tax for fiscal year 2026 is de minimis.

[0001032975-26-000021:notes:197]
On January 5, 2026, the OECD released an Administrative Guidance package. This package includes a “Side-by-Side” System designed to align the U.S. tax regime with Pillar Two for U.S.-parented multinational groups, effective for tax years beginning on or after January 1, 2026. As the Company is a non-U.S. headquartered multinational, the “Side-by-Side” System itself does not apply to the Company’s tax profile. However, the broader guidance package also introduces a new permanent safe harbor (to replace the transitional CbCR safe harbor for fiscal years beginning in 2027) and a one-year extension of the transitional CbCR safe harbor that may potentially impact the Company’s Pillar Two compliance and reporting. The Company continues to monitor these developments but does not expect a material change to its Pillar Two liability.

[0001032975-26-000021:notes:198]
Deferred income tax assets and liabilities consist of the following (in thousands):

[0001032975-26-000021:notes:199]
|  |  | March 31, |
|  |  | 2026 |  | 2025 |
| Deferred tax assets: |  |  |  |  |
| Tax attributes carryforward |  | $ | 42,408 |  |  | $ | 43,536 |  |
| Future tax deduction from Swiss Tax Benefits |  | 50,630 |  |  | 48,267 |  |
| Accruals |  | 67,963 |  |  | 72,114 |  |
| Tax step-up of goodwill from TRAF |  | 73,512 |  |  | 86,519 |  |
| Share-based compensation |  | 20,228 |  |  | 15,411 |  |
| Gross deferred tax assets |  | 254,741 |  |  | 265,847 |  |
| Valuation allowance |  | (36,922) |  |  | (36,537) |  |
| Deferred tax assets after valuation allowance |  | $ | 217,819 |  |  | $ | 229,310 |  |
| Deferred tax liabilities: |  |  |  |  |
| Acquired intangible assets and other |  | $ | (23,975) |  |  | $ | (27,788) |  |
| Deferred tax liabilities |  | (23,975) |  |  | (27,788) |  |
| Deferred tax assets, net |  | $ | 193,844 |  |  | $ | 201,522 |  |

[0001032975-26-000021:notes:200]
Management regularly assesses the ability to realize deferred tax assets recorded in the Company's entities based upon the weight of available evidence, including such factors as recent earnings history and expected future taxable income. In the event that the Company changes its determination as to the amount of deferred tax assets that can be realized, the Company will adjust its valuation allowance with a corresponding impact to the provision for income taxes in the period in which such determination is made.

[0001032975-26-000021:notes:201]
The Company had a valuation allowance against deferred tax assets of $36.9 million at March 31, 2026, compared to $36.5 million at March 31, 2025. The Company had a valuation allowance of $36.8 million as of March 31, 2026 against deferred tax assets in the state of California, an increase from $36.4 million as of March 31, 2025 from activities during the year. The Company determined that it is more likely than not that the Company would not generate sufficient taxable income in the future to utilize such deferred tax assets.

[0001032975-26-000021:notes:202]
As of March 31, 2026, the Company had net operating loss carryforwards in Switzerland for income tax purposes of $30.8 million which will begin to expire in fiscal year 2028. The Company had net operating loss and tax credit carryforwards in the United States for income tax purposes of $0.4 million and $61.1 million, respectively, as of March 31, 2026. The net operating loss carryforwards in the United States relate to acquisitions and, as a result, are limited in the amount that can be utilized in any one year and have no expiration. The tax credit carryforwards will begin to expire in fiscal year 2027.

[0001032975-26-000021:notes:203]
For the fiscal year ended March 31, 2026, individual jurisdictions are separately presented where the net amount of income taxes paid is equal to or greater than 5% of total income taxes paid. As the Company adopted ASU 2023-09 on a prospective basis, comparative jurisdictional information for prior periods is not presented.

[0001032975-26-000021:notes:204]
The following table presents income taxes, including withholding taxes, paid, net of refunds received, disaggregated by federal, state, and foreign jurisdictions (in thousands):

[0001032975-26-000021:notes:205]
|  |  | Year Ended March 31, |
|  |  | 2026 |
| Switzerland - Federal |  | $ | 19,028 |  |
| Switzerland - Cantonal: |  |  |
| Vaud |  | $ | 21,851 |  |
| Zurich |  | 116 |  |
| Total Cantonal |  | $ | 21,967 |  |
| Foreign: |  |  |
| United States |  | $ | 6,502 |  |
| China |  | 9,466 |  |
| Japan |  | 5,283 |  |
| Brazil |  | 5,059 |  |
| Sweden |  | 4,551 |  |
| Other |  | 14,497 |  |
| Total Foreign |  | $ | 45,358 |  |
| Total |  | $ | 86,353 |  |

[0001032975-26-000021:notes:206]
For fiscal years ended March 31, 2025 and 2024, total income taxes paid, net of refunds received was $67.5 million and $50.9 million, respectively.

[0001032975-26-000021:notes:207]
The Company has accumulated earnings in non-Swiss subsidiaries that are primarily intended to support operations outside of Switzerland. Deferred income taxes have not been recognized on a portion of these earnings with respect to Swiss income taxes and foreign withholding taxes, as such earnings are expected to be reinvested outside of Switzerland to fund local working capital requirements. If repatriated, the Company would generally be subject to foreign withholding taxes, which represent the primary source of incremental tax cost, and limited Swiss income tax, due to the Swiss participation exemption.

[0001032975-26-000021:notes:208]
The Company follows a two-step approach in recognizing and measuring uncertain tax positions. The first step is to evaluate the tax position for recognition by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step is to measure the tax benefit as the largest amount that is more than 50% likely of being realized upon ultimate settlement.

[0001032975-26-000021:notes:209]
As of March 31, 2026 and 2025, the total amount of unrecognized tax benefits due to uncertain tax positions was $131.4 million and $152.0 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-26-000021:notes:210]
As of March 31, 2026 and 2025, the Company had $86.3 million and $88.5 million, respectively, in non-current income taxes payable, including interest and penalties, related to the Company's income tax liability for uncertain tax positions.

[0001032975-26-000021:notes:211]
The aggregate changes in gross unrecognized tax benefits in fiscal years 2026, 2025 and 2024 were as follows (in thousands):

[0001032975-26-000021:notes:212]
| March 31, 2023 |  | $ | 191,000 |  |
| Lapse of statute of limitations |  | (3,863) |  |
| Settlements with taxing authorities |  | 41 |  |
| Increases in balances related to tax positions taken during prior years |  | 705 |  |
| Increases in balances related to tax positions taken during the year |  | 22,332 |  |
| March 31, 2024 |  | $ | 210,215 |  |
| Lapse of statute of limitations |  | (25,075) |  |
| Settlements with taxing authorities |  | (32,314) |  |
| Increases (decreases) in balances related to tax positions taken during prior years |  | (3,055) |  |
| Increases in balances related to tax positions taken during the year |  | 2,213 |  |
| March 31, 2025 |  | $ | 151,984 |  |
| Lapse of statute of limitations |  | (23,176) |  |
| Increases (decreases) in balances related to tax positions taken during prior years |  | (1,120) |  |
| Increases in balances related to tax positions taken during the year |  | 3,673 |  |
| March 31, 2026 |  | $ | 131,361 |  |

[0001032975-26-000021:notes:213]
The Company recognizes interest and penalties related to unrecognized tax positions as income tax expense. The Company recognized $3.1 million and $(0.6) million, in interest and penalties related to unrecognized tax positions in income tax expense during fiscal years 2026 and 2025, respectively. In 2025, the interest accrual was reduced in excess of the current year accrual build as a result of audit settlements and statute lapses. As of March 31, 2026 and 2025, the Company had $8.3 million and $7.2 million, respectively, of accrued interest and penalties related to uncertain tax positions.

[0001032975-26-000021:notes:214]
The Company’s unrecognized tax benefits decreased by $20.6 million during the fiscal year ended March 31, 2026, primarily due to the expiration of the statutes of limitations for certain U.S. federal positions. In the United States, the federal and state tax agencies have the authority to examine periods prior to fiscal year 2022, to the extent allowed by law, but only to the extent tax attributes were generated, carried forward, and are being utilized in subsequent years. The statute of limitations in the United States otherwise lapsed for fiscal year 2022 in fiscal year 2026. The Company is under examination in several foreign tax jurisdictions. If the examinations are resolved unfavorably, there is a possibility they may have a negative impact on its results of operations. Although the Company has adequately provided for uncertain tax positions, the provisions on these positions may change as revised estimates are made or the underlying matters are settled or otherwise resolved.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001032975-26-000021:notes:215]
Balance Sheet Components
The following table presents the components of certain balance sheet asset amounts as of March 31, 2026 and 2025 (in thousands):

[0001032975-26-000021:notes:216]
|  |  | March 31, |
|  |  | 2026 |  | 2025 |
| Accounts receivable, net: |  |  |  |  |
| Accounts receivable |  | $ | 792,466 |  |  | $ | 708,693 |  |
| Allowance for cooperative marketing arrangements |  | (49,964) |  |  | (44,457) |  |
| Allowance for customer incentive programs |  | (73,999) |  |  | (66,564) |  |
| Allowance for pricing programs |  | (144,800) |  |  | (105,876) |  |
| Other allowances |  | (17,836) |  |  | (37,250) |  |
|  |  | $ | 505,867 |  |  | $ | 454,546 |  |
| Inventories: |  |  |  |  |
| Raw materials |  | $ | 62,484 |  |  | $ | 48,699 |  |
| Finished goods |  | 427,464 |  |  | 455,048 |  |
|  |  | $ | 489,948 |  |  | $ | 503,747 |  |
| Other current assets: |  |  |  |  |
| Value-added tax ("VAT") receivables |  | $ | 58,600 |  |  | $ | 46,332 |  |
| Prepaid expenses and other assets |  | 119,295 |  |  | 84,879 |  |
|  |  | $ | 177,895 |  |  | $ | 131,211 |  |
| Property, plant and equipment, net: |  |  |  |  |
| Plant, buildings and improvements |  | $ | 93,023 |  |  | $ | 88,041 |  |
| Equipment and tooling |  | 350,869 |  |  | 324,007 |  |
| Computer equipment |  | 28,108 |  |  | 26,881 |  |
| Software |  | 103,961 |  |  | 95,829 |  |
|  |  | 575,961 |  |  | 534,758 |  |
| Less: accumulated depreciation and amortization |  | (470,964) |  |  | (429,889) |  |
|  |  | 104,997 |  |  | 104,869 |  |
| Construction-in-process |  | 8,750 |  |  | 6,337 |  |
| Land |  | 2,707 |  |  | 2,652 |  |
|  |  | $ | 116,454 |  |  | $ | 113,858 |  |
| Other assets: |  |  |  |  |
| Deferred tax assets |  | $ | 192,083 |  |  | $ | 202,180 |  |
| Right-of-use assets |  | 71,531 |  |  | 75,239 |  |
| Investments for deferred compensation plan |  | 30,495 |  |  | 29,006 |  |
| Investments in privately held companies |  | 28,871 |  |  | 27,980 |  |
| Other assets |  | 16,095 |  |  | 9,672 |  |
|  |  | $ | 339,075 |  |  | $ | 344,077 |  |

[0001032975-26-000021:notes:217]
The following table presents the components of certain balance sheet liability amounts as of March 31, 2026 and 2025 (in thousands):

[0001032975-26-000021:notes:218]
|  |  | March 31, |
|  |  | 2026 |  | 2025 |
| Accrued and other current liabilities: |  |  |  |  |
| Accrued customer marketing, pricing and incentive programs |  | $ | 211,915 |  |  | $ | 173,401 |  |
| Accrued personnel expenses |  | 165,404 |  |  | 180,763 |  |
| Deferred revenue (1) |  | 38,652 |  |  | 25,798 |  |
| Income taxes payable |  | 37,843 |  |  | 26,841 |  |
| VAT payable |  | 36,292 |  |  | 29,648 |  |
| Warranty liabilities |  | 35,488 |  |  | 34,428 |  |
| Accrued sales return liability |  | 27,635 |  |  | 27,913 |  |
| Accrued loss for inventory purchase commitments |  | 18,167 |  |  | 19,614 |  |
| Operating lease liabilities |  | 17,044 |  |  | 15,780 |  |
| Other current liabilities |  | 193,550 |  |  | 152,317 |  |
|  |  | $ | 781,990 |  |  | $ | 686,503 |  |
| Other non-current liabilities: |  |  |  |  |
| Operating lease liabilities |  | $ | 71,111 |  |  | $ | 76,622 |  |
| Employee benefit plan obligations |  | 61,066 |  |  | 57,338 |  |
| Deferred revenue (1) |  | 53,624 |  |  | 38,216 |  |
| Obligation for deferred compensation plan |  | 30,495 |  |  | 29,006 |  |
| Warranty liabilities |  | 14,754 |  |  | 14,756 |  |
| Other non-current liabilities |  | 6,849 |  |  | 5,574 |  |
|  |  | $ | 237,899 |  |  | $ | 221,512 |  |

[0001032975-26-000021:notes:219]
(1) Includes deferred revenue for post-contract customer support and other services.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001032975-26-000021:notes:220]
Fair Value Measurements
Fair Value Measurements

[0001032975-26-000021:notes:221]
The Company considers fair value as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants at the measurement date. The Company utilizes the following three-level fair value hierarchy to establish the priorities of the inputs used to measure fair value:

[0001032975-26-000021:notes:222]
•Level 1—Quoted prices in active markets for identical assets or liabilities.

[0001032975-26-000021:notes:223]
•Level 2—Observable inputs other than quoted market prices included in Level 1, such as quoted prices for similar assets and liabilities in active markets; quoted prices for identical or similar assets and liabilities in markets that are not active; or other inputs that are observable or can be corroborated by observable market data.

[0001032975-26-000021:notes:224]
•Level 3—Unobservable inputs that are supported by little or no market activity and that are significant to the fair value of the assets or liabilities. This includes certain pricing models, discounted cash flow methodologies and similar techniques that use significant unobservable inputs.

[0001032975-26-000021:notes:225]
The following table presents the Company's financial assets and liabilities that were accounted for at fair value on a recurring basis, excluding assets related to the Company's defined benefit pension plans, classified by the level within the fair value hierarchy (in thousands):

[0001032975-26-000021:notes:226]
|  |  | March 31, 2026 |  | March 31, 2025 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Level 1 |  | Level 2 |  | Level 3 |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 863,120 |  |  | $ | — |  |  | $ | — |  |  | $ | 852,467 |  |  | $ | — |  |  | $ | — |  |
| Investments for deferred compensation plan included in other assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 60 |  |  | $ | — |  |  | $ | — |  |  | $ | 90 |  |  | $ | — |  |  | $ | — |  |
| Common stock |  | 902 |  |  | — |  |  | — |  |  | 540 |  |  | — |  |  | — |  |
| Money market funds |  | 4,553 |  |  | — |  |  | — |  |  | 7,359 |  |  | — |  |  | — |  |
| Mutual funds |  | 24,980 |  |  | — |  |  | — |  |  | 21,017 |  |  | — |  |  | — |  |
| Total investments for deferred compensation plan |  | $ | 30,495 |  |  | $ | — |  |  | $ | — |  |  | $ | 29,006 |  |  | $ | — |  |  | $ | — |  |
| Currency derivative assets |  | $ | — |  |  | $ | 5,486 |  |  | $ | — |  |  | $ | — |  |  | $ | 90 |  |  | $ | — |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Currency derivative liabilities |  | $ | — |  |  | $ | 94 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,849 |  |  | $ | — |  |

[0001032975-26-000021:notes:227]
Investments for Deferred Compensation Plan

[0001032975-26-000021:notes:228]
The marketable securities for the Company's deferred compensation plan were recorded at a fair value of $30.5 million and $29.0 million as of March 31, 2026 and 2025, respectively, based on quoted market prices. Quoted market prices are observable inputs that are classified as Level 1 within the fair value hierarchy. Unrealized gains (losses) related to marketable securities for fiscal years 2026, 2025 and 2024 were not material and were included in other income (expense), net (see Note 6) and corresponding changes in the deferred compensation liability were included in operating expenses and cost of goods sold, in the Company's consolidated statements of operations.

[0001032975-26-000021:notes:229]
Equity Method Investments

[0001032975-26-000021:notes:230]
The Company has certain non-marketable investments included in other assets that are accounted for as equity method investments, with a carrying value of $19.1 million and $18.4 million as of March 31, 2026 and 2025, respectively. Income (loss) related to equity method investments for fiscal years 2026, 2025 and 2024 was not material and is included in other income (expense), net in the Company's consolidated statements of operations (see Note 6). There was no impairment of equity method investments during fiscal years 2026, 2025, and 2024.

[0001032975-26-000021:notes:231]
Assets Measured at Fair Value on a Nonrecurring Basis

[0001032975-26-000021:notes:232]
Financial Assets. The Company has certain equity investments without readily determinable fair values due to the absence of quoted market prices, the inherent lack of liquidity, and the fact that inputs used to measure fair value are unobservable and require management's judgment. When certain events or circumstances indicate that impairment may exist, the Company revalues the investments using various assumptions, including the financial metrics and ratios of comparable public companies. The carrying value is also adjusted for observable price changes with the same or similar security from the same issuer. The amount of these equity investments without readily determinable fair value included in other assets was $8.8 million as of March 31, 2026 and 2025. There was no impairment of these equity investments during fiscal year 2026. The impairment charges related to these investments were not material during fiscal years 2025 and 2024.

[0001032975-26-000021:notes:233]
During fiscal year 2024, the Company recorded an impairment loss, before tax, of $9.6 million as a result of the write-off of a note receivable which was deemed no longer recoverable. This note receivable was previously obtained in conjunction with an exchange transaction related to the Company's investment in a privately held company. The impairment loss is included in other income (expense), net, in the Company's consolidated statement of operations for the fiscal year 2024.
Non-Financial Assets. Goodwill, intangible assets, and property, plant and equipment, are not required to be measured at fair value on a recurring basis. However, if the Company is required to evaluate these non-financial assets for impairment, whether due to certain triggering events or because of the required annual impairment test, and a resulting impairment is recorded to reduce the carrying value to the fair value, the non-financial assets are measured at fair value during such period. See Note 2 for additional information about how the Company tests various asset classes for impairment. During fiscal year 2024, the Company recorded impairment charges of $3.5 million related to intangible assets. There was no impairment of non-financial assets during fiscal years 2026 and 2025.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001032975-26-000021:notes:234]
Derivative Financial Instruments
 Under certain agreements with the respective counterparties to the Company's derivative contracts, subject to applicable requirements, the Company is allowed to net settle transactions of the same type with a single net amount payable by one party to the other. However, the Company presents its derivative assets and derivative liabilities on a gross basis. Based on maturity, derivative assets are included in other current assets or other assets and derivative liabilities are included in accrued and other current liabilities or other non-current liabilities on the consolidated balance sheets. See Note 9 for the fair values of the Company’s derivative instruments as of March 31, 2026 and 2025.

[0001032975-26-000021:notes:235]
Cash Flow Hedges

[0001032975-26-000021:notes:236]
The Company enters into cash flow hedge contracts, including foreign currency forward contracts and foreign currency option contracts, to protect against exchange rate exposure of forecasted inventory purchases. Previously, the hedge contracts covered inventory purchases within four months. Beginning in fiscal year 2026, they cover inventory purchases up to sixteen months, with reduced coverage beyond four months. Gains and losses in the fair value of the effective portion of the hedges are deferred as a component of accumulated other comprehensive income (loss) until the hedged inventory purchases are sold, at which time the gains or losses are reclassified to cost of goods sold. Cash flows from such hedges are classified as operating activities in the consolidated statements of cash flows. Hedging relationships are discontinued when the hedging contract is no longer eligible for hedge accounting, or is sold, terminated or exercised, or when the Company removes hedge designation for the contract. Gains and losses in the fair value of the effective portion of the discontinued hedges continue to be reported in accumulated other comprehensive income (loss) until the hedged inventory purchases are sold, unless it is probable that the forecasted inventory purchases will not occur by the end of the originally specified time period or within an additional two-month period of time thereafter.

[0001032975-26-000021:notes:237]
The notional amounts of foreign currency exchange contracts outstanding related to forecasted inventory purchases were $447.9 million and $74.6 million as of March 31, 2026 and 2025, respectively. The Company had $1.9 million of net gain related to its cash flow hedges included in accumulated other comprehensive loss as of March 31, 2026, which will be reclassified into earnings within the next twelve months.

[0001032975-26-000021:notes:238]
The following table presents the amounts of gain (loss) on the Company's derivative instruments designated as hedging instruments for fiscal years 2026, 2025 and 2024 and their locations on its consolidated statements of operations and consolidated statements of comprehensive income (in thousands):

[0001032975-26-000021:notes:239]
|  |  | Amount ofGain (Loss) Deferred asa Component ofAccumulated OtherComprehensive Loss |  | Amount of Loss (Gain)Reclassified fromAccumulated OtherComprehensive Lossto Cost of Goods Sold |  |  |
|  |  | 2026 |  | 2025 |  | 2024 |  | 2026 |  | 2025 |  | 2024 |  |  |  |  |  |  |
| Cash flow hedges |  | $ | (8,214) |  | $ | (703) |  |  | $ | 1,109 |  |  | $ | 13,321 |  |  | $ | (3,461) |  |  | $ | 3,964 |  |  |  |  |  |  |  |

[0001032975-26-000021:notes:240]
Other Derivatives

[0001032975-26-000021:notes:241]
The Company also enters into foreign currency exchange forward and swap contracts to reduce the short-term effects of currency exchange rate fluctuations on certain receivables or payables denominated in currencies other than the functional currencies of its subsidiaries. These contracts generally mature within approximately one month. The primary risk managed by using forward and swap contracts is the currency exchange rate risk. The gains or losses on these contracts are not material and are included in other income (expense), net in the consolidated statements of operations based on the changes in fair value. The notional amounts of these contracts outstanding as of March 31, 2026 and 2025 were $113.0 million and $131.8 million, respectively.

[0001032975-26-000021:notes:242]
The fair value of all foreign currency exchange forward and swap contracts is determined based on observable market transactions of spot currency rates and forward rates. Cash flows from these contracts are classified as operating activities in the consolidated statements of cash flows.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001032975-26-000021:notes:243]
Goodwill and Other Intangible Assets
The Company conducts its impairment analysis of goodwill annually at December 31 or more frequently if changes in facts and circumstances indicate that it is more likely than not that the fair value of the Company’s reporting unit may be less than its carrying amount. The Company conducted its annual impairment analysis of goodwill as of December 31, 2025 by performing a qualitative assessment and concluded that it was more likely than not that the fair value of its reporting unit exceeded its carrying amount. There have been no triggering events identified affecting the valuation of goodwill subsequent to the annual impairment test.

[0001032975-26-000021:notes:244]
The following table summarizes the activities in the Company's goodwill balance (in thousands):

[0001032975-26-000021:notes:245]
|  |  | Years Ended March 31, |
|  |  | 2026 |  | 2025 |
| Beginning of the period |  | $ | 463,230 |  |  | $ | 461,978 |  |
| Effects of foreign currency translation |  | 2,187 |  |  | 1,252 |  |
| End of the period |  | $ | 465,417 |  |  | $ | 463,230 |  |

[0001032975-26-000021:notes:246]
The Company's acquired intangible assets were as follows (in thousands):

[0001032975-26-000021:notes:247]
|  |  | March 31, |
|  |  | 2026 |  | 2025 |
|  |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |
| Trademarks and trade names |  | $ | 32,390 |  |  | $ | (30,569) |  |  | $ | 1,821 |  |  | $ | 32,390 |  |  | $ | (28,675) |  |  | $ | 3,715 |  |
| Developed technology |  | 107,550 |  |  | (103,307) |  |  | 4,243 |  |  | 107,421 |  |  | (96,464) |  |  | 10,957 |  |
| Customer contracts/relationships |  | 69,087 |  |  | (63,021) |  |  | 6,066 |  |  | 69,087 |  |  | (58,646) |  |  | 10,441 |  |
| Effects of foreign currency translation |  | 1,218 |  |  | (962) |  |  | 256 |  |  | (620) |  |  | 137 |  |  | (483) |  |
| Total |  | $ | 210,245 |  |  | $ | (197,859) |  |  | $ | 12,386 |  |  | $ | 208,278 |  |  | $ | (183,648) |  |  | $ | 24,630 |  |

[0001032975-26-000021:notes:248]
For fiscal years 2026, 2025 and 2024, amortization expense for intangible assets was $13.3 million, $20.1 million and $21.7 million, respectively. The Company expects that annual amortization expense for fiscal years 2027, 2028, 2029 and 2030 will be $5.9 million, $4.3 million, $1.9 million, and $0.3 million, respectively. The remaining balance of the Company's intangible assets will be fully amortized by 2030.


## us-gaap:DebtDisclosureTextBlock

[0001032975-26-000021:notes:249]
Financing Arrangements
On January 27, 2025, the Company entered into an unsecured revolving credit facility with a syndicate of banks (the "Credit Agreement"). The Credit Agreement provides a revolving line of credit of up to $750.0 million to the Company including the issuance of letters of credit of up to $100.0 million. The Credit Agreement terminates on January 27, 2030 unless extended in accordance with its terms. The Credit Agreement contains (1) an increase option allowing the Company to secure up to $250.0 million of additional commitments and (2) an extension option to extend the term by one-year which may be exercised no more than two times, subject to certain requirements. Loans under the Credit Agreement are available in U.S. Dollars, Euro, Sterling, Yen, Swiss Francs, Canadian Dollars, Australian Dollars and any other currency agreed to by each lender. Proceeds of loans made under the Credit Agreement may be used for general corporate purposes.

[0001032975-26-000021:notes:250]
The Credit Agreement contains a maximum net debt to adjusted EBITDA ratio, compliance with which is a condition to the Company's ability to borrow. Borrowings under the Credit Agreement will bear interest at a rate determined by reference to benchmark rates plus an applicable spread (ranging from 0% to 1.5%) based on the Company's net leverage ratio or credit rating at the time of the borrowing. Undrawn balances available under the Credit Agreement are subject to commitment fees at the applicable rate determined by reference to the Company's net leverage ratio or credit rating. There has been no borrowing outstanding under the Credit Agreement as of March 31, 2026.

[0001032975-26-000021:notes:251]
In addition, the Company had several uncommitted, unsecured bank lines of credit and letters of credit aggregating to $149.0 million and $172.2 million as of March 31, 2026 and 2025, respectively. There are no financial covenants under the lines of credit with which the Company must comply. There was no borrowing outstanding under the lines of credit as of March 31, 2026 and 2025. As of March 31, 2026 and 2025, the Company had outstanding bank guarantees of $2.1 million and $12.1 million, respectively.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001032975-26-000021:notes:252]
Commitments and Contingencies
Product Warranties

[0001032975-26-000021:notes:253]
Changes in the Company's warranty liabilities for fiscal years 2026 and 2025 were as follows (in thousands):

[0001032975-26-000021:notes:254]
|  |  | Years Ended March 31, |
|  |  | 2026 |  | 2025 |
| Beginning of the period |  | $ | 49,184 |  |  | $ | 44,654 |  |
| Provision |  | 37,617 |  |  | 44,876 |  |
| Settlements |  | (37,411) |  |  | (40,316) |  |
| Effects of foreign currency translation |  | 852 |  |  | (30) |  |
| End of the period |  | $ | 50,242 |  |  | $ | 49,184 |  |

[0001032975-26-000021:notes:255]
Indemnifications

[0001032975-26-000021:notes:256]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys' fees. As of March 31, 2026, no material amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

[0001032975-26-000021:notes:257]
The Company also indemnifies its current and former directors and certain of its current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. The Company is unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not limited, the obligations are conditional in nature and the facts and circumstances involved in any situation that might arise are variable.

[0001032975-26-000021:notes:258]
Legal Proceedings

[0001032975-26-000021:notes:259]
From time to time the Company is involved in claims and legal proceedings that arise in the ordinary course of its business. The Company is currently subject to several such claims and legal proceedings. The Company intends to vigorously defend against them. Management periodically assesses the Company’s liabilities and contingencies in connection with these matters based upon the latest information available. The Company follows ASC ("Accounting Standards Codification") 450, Contingencies, in determining the accounting and disclosure for these contingencies. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows and results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company's defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company's business, financial condition, cash flows and results of operations in a particular period. Any claims or proceedings against the Company can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain a necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company's business.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001032975-26-000021:notes:260]
Shareholders' Equity
Share Capital

[0001032975-26-000021:notes:261]
As of March 31, 2026, the Company's nominal share capital is CHF 40.2 million, consisting of 160,784,460 issued shares with a par value of CHF 0.25 each, of which 17,281,896 were held in treasury shares.

[0001032975-26-000021:notes:262]
The capital band under Swiss law allows a company's board of directors to adjust the company's share capital within a predefined range based on a general authority granted by the company's shareholders. At the 2023 Annual General Meeting ("AGM"), the Company's shareholders approved an amendment to the Company’s Articles of Incorporation to introduce a capital band provision authorizing the Board of Directors to adjust the Company's share capital, without additional shareholder approval, within a range of 155,795,958 registered shares to 190,417,282 registered shares for a five-year period ending on September 13, 2028. At the 2025 AGM, the Company's shareholders approved a renewal of the capital band, setting a new range of 144,706,014 registered shares to 176,862,906 registered shares for a five-year period ending on September 9, 2030. The amendment became effective on October 1, 2025.

[0001032975-26-000021:notes:263]
In addition, the Company has reserved conditional capital (1) up to 25,000,000 shares for potential issuance for the exercise of rights granted under the Company's employee equity incentive plans, and (2) up to 25,000,000 shares for issuance to cover any conversion rights under any potential future convertible bond issuance.

[0001032975-26-000021:notes:264]
Share Cancellation

[0001032975-26-000021:notes:265]
In June 2025, the Company's Board of Directors approved the cancellation of 8.2 million treasury shares, which were repurchased under the 2023 share repurchase program in fiscal year 2025 and the first quarter of fiscal year 2026, for an aggregate cost of $712.2 million. The cancellation became effective in the second quarter of fiscal year 2026, and as a result, both the number of registered shares issued and the number of treasury shares decreased by 8.2 million shares. Upon cancellation of these shares, the Company deducted the par value from registered shares and reflected the excess of share repurchase cost over par value as a reduction to retained earnings.

[0001032975-26-000021:notes:266]
In September 2024, the Company's Board of Directors approved the cancellation of 4.1 million treasury shares, which were repurchased under the 2023 share repurchase program in fiscal year 2024 for an aggregate cost of $332.1 million. The cancellation became effective in the third quarter of fiscal year 2025, and as a result both the number of registered shares issued and the number of treasury shares decreased by 4.1 million shares. Upon cancellation of these shares, the Company deducted the par value from registered shares and reflected the excess of share repurchase cost over par value as a reduction to retained earnings.

[0001032975-26-000021:notes:267]
Dividends

[0001032975-26-000021:notes:268]
Pursuant to Swiss corporate law, the payment of dividends is limited to certain amounts of unappropriated retained earnings (approximately CHF 1,573.5 million, or USD equivalent of $1,966.6 million as of March 31, 2026) and is subject to shareholder approval.

[0001032975-26-000021:notes:269]
In May 2026, the Board of Directors recommended that the Company pay cash dividends for fiscal year 2026 of CHF 1.36 per share (USD equivalent of approximately $1.70 per share, which would result in a gross aggregate dividend of approximately $243.9 million, based on the exchange rate and shares outstanding, net of treasury shares, on March 31, 2026).

[0001032975-26-000021:notes:270]
In September 2025, the Company paid gross cash dividends of CHF 1.26 (USD equivalent of $1.58) per common share, totaling $233.1 million on the Company's outstanding common shares. In September 2024, the Company paid cash dividends of CHF 1.16 (USD equivalent of $1.37) per common share, totaling $207.9 million on the Company’s outstanding common shares. In September 2023, the Company paid cash dividends of CHF 1.06 (USD equivalent of $1.16) per common share, totaling $182.3 million on the Company's outstanding common shares.

[0001032975-26-000021:notes:271]
Any future dividends will be subject to the approval of the Company's shareholders.

[0001032975-26-000021:notes:272]
Legal Reserves

[0001032975-26-000021:notes:273]
Under Swiss corporate law, a minimum of 5% of the Company's annual net income must be retained in a legal reserve until this legal reserve equals 20% of the Company's issued and outstanding aggregate par value per share capital. These legal reserves represent an appropriation of retained earnings that are not available for distribution and totaled $12.0 million at March 31, 2026 (based on the exchange rate at March 31, 2026).

[0001032975-26-000021:notes:274]
Share Repurchases

[0001032975-26-000021:notes:275]
In May 2020, the Company's Board of Directors approved the 2020 share repurchase program, which authorized the Company to use up to $250.0 million to purchase Logitech shares to support equity incentive plans or potential acquisitions. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Purchases may be started or stopped at any time without prior notice depending on market conditions and other factors. In 2021 and 2022, the Company's Board of Directors approved increases to the 2020 share repurchase program, to an aggregate amount of up to $1.5 billion. The 2020 share repurchase program expired on July 27, 2023.

[0001032975-26-000021:notes:276]
In June 2023, the Company's Board of Directors approved a three-year share repurchase program, which  allows the Company to use up to $1.0 billion to repurchase its shares. The 2023 share repurchase program enables the Company to repurchase shares for cancellation, as well as to support equity incentive plans or potential acquisitions. The Swiss Takeover Board approved the 2023 share repurchase program in July 2023 and the program became effective on July 28, 2023. In March 2025, the Company's Board of Directors approved an increase of $600.0 million to the 2023 share repurchase program, to an aggregate amount of $1.6 billion. The Swiss Takeover Board approved this increase in April 2025 and it became effective on April 2, 2025. As of March 31, 2026, $91.8 million was available for repurchase under the 2023 share repurchase program.

[0001032975-26-000021:notes:277]
In March 2026, the Company's Board of Directors approved a new three-year share repurchase program to repurchase shares up to an aggregate amount of $1.4 billion, or a maximum of 16,078,446 shares. The 2026 share repurchase program enables the Company to repurchase shares for cancellation, as well as to support equity incentive plans or potential acquisitions. The program became effective on May 8, 2026, following approval from the Swiss Takeover Board and the completion of the 2023 share repurchase program.

[0001032975-26-000021:notes:278]
The following table summarizes the Company's share repurchase activities for fiscal years 2026, 2025 and 2024 (in thousands):

[0001032975-26-000021:notes:279]
|  | Years Ended March 31, |
|  | 2026 |  | 2025 |  | 2024 |
| 2023 Share Repurchase Program: |  |  |  |  |  |
| Number of shares repurchased (1) | 6,167 |  | 6,679 |  | 4,459 |
| Aggregate cost of shares repurchased (1) (2) | $ | 557,043 |  |  | $ | 588,028 |  |  | $ | 364,639 |  |
| 2020 Share Repurchase Program: |  |  |  |  |  |
| Number of shares repurchased (3) | — |  | — |  | 2,641 |
| Aggregate cost of shares repurchased | $ | — |  |  | $ | — |  |  | $ | 159,112 |  |

[0001032975-26-000021:notes:280]
(1) In fiscal years 2026 and 2025, all shares were repurchased for cancellation. In fiscal year 2024, 4.1 million shares in an aggregate cost of $332.1 million were repurchased for cancellation and the remaining shares were repurchased to support equity incentive plans.

[0001032975-26-000021:notes:281]
(2) Includes an aggregate cost of $40.8 million, $18.7 million, and $19.5 million, respectively, that was not yet paid as of March 31, 2026, 2025 and 2024.

[0001032975-26-000021:notes:282]
(3) Shares were repurchased to support equity incentive plans.

[0001032975-26-000021:notes:283]
Swiss law limits a company’s ability to hold or repurchase its own shares. The aggregate par value of all shares held in treasury by the Company and its subsidiaries may not exceed 10% of the share capital of the Company, which for the Company corresponds to approximately 16.1 million registered shares as of March 31, 2026. This limitation does not apply to shares repurchased for cancellation, due to the Board of Directors’ authority under the Company’s capital band set forth in the Company’s Articles of Incorporation. As of March 31, 2026, the Company had a total of 17.3 million shares held in treasury stock, which includes 4.7 million shares that have been repurchased for cancellation and 12.6 million shares that have been purchased to support equity incentive plans or potential acquisitions.

[0001032975-26-000021:notes:284]
To the extent that the shares are repurchased to support equity incentive plans or potential acquisitions, the shares are repurchased on the ordinary trading line of the SIX Swiss Exchange and/or the Nasdaq Global Select Market. Shares repurchased for cancellation purposes are repurchased on a second trading line on the SIX Swiss Exchange. Shares may be repurchased from time to time on the open market or in privately negotiated transactions, including under plans complying with the provisions of Rule 10b5-1 and Rule 10b-18 of the Securities Exchange Act of 1934, as amended. Purchases may be started or stopped at any time without prior notice depending on market conditions and other factors and the program does not require the purchase of any minimum number of shares.

[0001032975-26-000021:notes:285]
Accumulated Other Comprehensive Loss

[0001032975-26-000021:notes:286]
The components of accumulated other comprehensive loss were as follows (in thousands):

[0001032975-26-000021:notes:287]
|  |  | Currency TranslationAdjustment |  | DefinedBenefitPlans |  | DeferredHedgingGains (Losses) |  | Total |
| March 31, 2025 |  | $ | (118,652) |  |  | $ | (25,276) |  |  | $ | (3,024) |  |  | $ | (146,952) |  |
| Other comprehensive income (loss) |  | 24,496 |  |  | 3,532 |  |  | 5,107 |  |  | 33,135 |  |
| March 31, 2026 |  | $ | (94,156) |  |  | $ | (21,744) |  |  | $ | 2,083 |  |  | $ | (113,817) |  |


## us-gaap:SegmentReportingPolicyPolicyTextBlock

[0001032975-26-000021:notes:288]
Segment InformationThe Company manages its business activities on a consolidated basis and operates as a single operating segment: Peripherals. The operating segment encompasses the design, manufacturing and sales of peripherals for gaming, PCs, tablets, video conferencing, and other digital platforms. The Company's Chief Operating Decision Maker (the “CODM”) is the Chief Executive Officer. The CODM periodically reviews information such as sales and net income to make business decisions and evaluate performance. The CODM uses net income to evaluate income generated from segment assets (return on assets) in deciding whether to reinvest profits into the Peripherals segment or into other parts of the entity, such as for acquisitions, share repurchase or to pay dividends. The CODM also monitors budget versus actual net income results.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001032975-26-000021:notes:289]
Segment Information
The Company manages its business activities on a consolidated basis and operates as a single operating segment: Peripherals. The operating segment encompasses the design, manufacturing and sales of peripherals for gaming, PCs, tablets, video conferencing, and other digital platforms. The Company's Chief Operating Decision Maker (the “CODM”) is the Chief Executive Officer. The CODM periodically reviews information such as sales and net income to make business decisions and evaluate performance. The CODM uses net income to evaluate income generated from segment assets (return on assets) in deciding whether to reinvest profits into the Peripherals segment or into other parts of the entity, such as for acquisitions, share repurchase or to pay dividends. The CODM also monitors budget versus actual net income results.

[0001032975-26-000021:notes:290]
The following table presents segment revenue, gross profit, and net income for the periods presented:

[0001032975-26-000021:notes:291]
|  | Years Ended March 31, |
|  | 2026 |  | 2025 |  | 2024 |
| Net sales | $ | 4,840,761 |  |  | $ | 4,554,900 |  |  | $ | 4,298,467 |  |
| Less: Significant segment expenses |  |  |  |  |  |
| Cost of goods sold (1) | 2,731,776 |  |  | 2,572,724 |  |  | 2,501,414 |  |
| Marketing and selling (1) | 774,098 |  |  | 774,036 |  |  | 694,530 |  |
| Research and development (1) | 293,317 |  |  | 288,828 |  |  | 269,407 |  |
| General and administrative (1) | 130,809 |  |  | 144,680 |  |  | 133,787 |  |
| Less: other segment items |  |  |  |  |  |
| Share-based compensation expense | 112,392 |  |  | 89,913 |  |  | 82,889 |  |
| Amortization of intangible assets and acquisition-related costs | 13,315 |  |  | 20,249 |  |  | 21,962 |  |
| Interest income | (48,246) |  |  | (54,997) |  |  | (50,636) |  |
| Other (2) | 6,781 |  |  | 12,595 |  |  | 23,518 |  |
| Provision for income taxes | 115,332 |  |  | 75,343 |  |  | 9,453 |  |
| Net income | $ | 711,187 |  |  | $ | 631,529 |  |  | $ | 612,143 |  |

[0001032975-26-000021:notes:292]
(1) The difference between the amounts included in the table above and the amounts included in the consolidated

[0001032975-26-000021:notes:293]
statements of operations is related to share-based compensation expense (see Note 4).

[0001032975-26-000021:notes:294]
(2) Includes restructuring charges, net, impairment of intangible assets, change in fair value of contingent

[0001032975-26-000021:notes:295]
consideration for business acquisition, and other income (expense), net, as applicable.

[0001032975-26-000021:notes:296]
Sales by product category for fiscal years 2026, 2025 and 2024 were as follows (in thousands):

[0001032975-26-000021:notes:297]
|  |  | Years Ended March 31, |
|  |  | 2026 |  | 2025 |  | 2024 |
| Gaming (1) |  | $ | 1,414,206 |  |  | $ | 1,338,467 |  |  | $ | 1,231,063 |  |
| Keyboards & Combos |  | 937,551 |  |  | 882,643 |  |  | 821,441 |  |
| Pointing Devices |  | 858,904 |  |  | 788,784 |  |  | 742,987 |  |
| Video Collaboration |  | 689,040 |  |  | 626,000 |  |  | 609,361 |  |
| Webcams |  | 326,172 |  |  | 315,520 |  |  | 325,225 |  |
| Tablet Accessories |  | 336,189 |  |  | 299,540 |  |  | 254,060 |  |
| Headsets |  | 179,825 |  |  | 179,710 |  |  | 168,478 |  |
| Other (2) |  | 98,874 |  |  | 124,236 |  |  | 145,852 |  |
| Total Sales |  | $ | 4,840,761 |  |  | $ | 4,554,900 |  |  | $ | 4,298,467 |  |

[0001032975-26-000021:notes:298]
(1) Gaming includes streaming services revenue generated by Streamlabs.

[0001032975-26-000021:notes:299]
(2) Other primarily consists of mobile speakers and PC speakers.

[0001032975-26-000021:notes:300]
Sales by geographic region (based on the customers' locations) for fiscal years 2026, 2025 and 2024 were as follows (in thousands):

[0001032975-26-000021:notes:301]
|  |  | Years Ended March 31, |
|  |  | 2026 |  | 2025 |  | 2024 |
| Americas |  | $ | 1,955,191 |  |  | $ | 1,973,374 |  |  | $ | 1,896,258 |  |
| EMEA |  | 1,539,065 |  |  | 1,413,855 |  |  | 1,301,515 |  |
| Asia Pacific |  | 1,346,505 |  |  | 1,167,671 |  |  | 1,100,694 |  |
| Total Sales |  | $ | 4,840,761 |  |  | $ | 4,554,900 |  |  | $ | 4,298,467 |  |

[0001032975-26-000021:notes:302]
Revenue from sales to customers in the United States represented 33%, 35% and 36% of sales in fiscal years 2026, 2025 and 2024, respectively. Revenue from sales to customers in Germany represented 12%, 12% and 14% of sales in fiscal years 2026, 2025 and 2024, respectively. Revenue from sales to customers in China represented 12%, 10% and 10% of sales in fiscal years 2026, 2025 and 2024, respectively. No other country represented more than 10% of sales during these periods presented herein. Revenue from sales to customers in Switzerland, the Company's country of domicile, represented 4%, 3%, and 2% of sales for fiscal year 2026, 2025 and 2024, respectively.

[0001032975-26-000021:notes:303]
Property, plant and equipment, net (excluding software) and right-of-use assets by geographic region were as follows (in thousands):

[0001032975-26-000021:notes:304]
|  |  | March 31, |
|  |  | 2026 |  | 2025 |
| Americas |  | $ | 59,103 |  |  | $ | 61,521 |  |
| EMEA |  | 48,119 |  |  | 47,874 |  |
| Asia Pacific |  | 65,089 |  |  | 60,710 |  |
| Total |  | $ | 172,311 |  |  | $ | 170,105 |  |

[0001032975-26-000021:notes:305]
Property, plant and equipment, net (excluding software) and right-of-use assets in the United States and China were $57.6 million and $48.0 million, respectively, as of March 31, 2026. Property, plant and equipment, net (excluding software) and right-of-use assets in the United States and China were $60.0 million and $43.4 million, respectively, as of March 31, 2025. Property, plant and equipment, net (excluding software) and right-of-use assets in Switzerland, the Company's country of domicile, were $25.0 million and $24.1 million as of March 31, 2026 and 2025, respectively. No other countries represented more than 10% of the Company's total consolidated property, plant and equipment, net (excluding software) and right-of-use assets as of March 31, 2026 or 2025.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001032975-26-000021:notes:306]
Restructuring 
During the second quarter of fiscal year 2023, the Company initiated a restructuring plan to realign its business group and engineering structure with its go-to-market strategy to more effectively compete within the enterprise market and to better serve end-users. During the fourth quarter of fiscal year 2023, the Company undertook further actions to remove organization layers as well as streamline its marketing organization to increase efficiency. These actions resulted in charges related to employee severance and other termination benefits as well as contract termination and other costs. These restructuring activities were substantially completed during fiscal year 2024.

[0001032975-26-000021:notes:307]
During the fourth quarter of fiscal year 2025, the Company initiated a restructuring plan to reorganize certain functions to enable increased productivity and efficiency. This plan resulted in charges related to employee severance and other termination benefits. The Company has substantially completed these restructuring activities as of March 31, 2026.

[0001032975-26-000021:notes:308]
The following table summarizes restructuring-related activities during fiscal years 2026, 2025 and 2024 (in thousands):

[0001032975-26-000021:notes:309]
|  |  | TerminationBenefits |  | Contract Termination and Other |  | Total |  |
| Accrued restructuring liability at March 31, 2023 (1) |  | $ | 14,177 |  |  | $ | 5,357 |  |  | $ | 19,534 |  |  |
| Charges, net |  | 6,011 |  |  | (2,145) |  |  | 3,866 |  |  |
| Cash payments |  | (18,375) |  |  | (1,757) |  |  | (20,132) |  |  |
| Accrued restructuring liability at March 31, 2024 (1) |  | $ | 1,813 |  |  | $ | 1,455 |  |  | $ | 3,268 |  |  |
| Charges, net |  | 9,846 |  |  | (231) |  |  | 9,615 |  |  |
| Cash payments |  | (2,562) |  |  | (241) |  |  | (2,803) |  |  |
| Accrued restructuring liability at March 31, 2025 (1) |  | $ | 9,097 |  |  | $ | 983 |  |  | $ | 10,080 |  |  |
| Charges, net |  | 7,584 |  |  | 2,276 |  |  | 9,860 |  |  |
| Cash payments |  | (13,558) |  |  | (2,299) |  |  | (15,857) |  |  |
| Accrued restructuring liability at March 31, 2026 (1) |  | $ | 3,123 |  |  | $ | 960 |  |  | $ | 4,083 |  |  |

[0001032975-26-000021:notes:310]
(1) The accrual balances are included in accrued and other current liabilities on the Company’s consolidated balance sheets.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001032975-26-000021:notes:311]
Leases
The Company is a lessee in various non-cancelable operating leases, primarily real estate facilities for office space. As of March 31, 2026, the Company's lease arrangements are comprised of operating leases with various expiration dates through August 31, 2036. The lease term for all of the Company’s leases includes the non-cancelable period of the lease. Certain lease agreements include options to renew or terminate the lease, which are not reasonably certain to be exercised and therefore are not factored into the Company's determination of the duration of the lease arrangement. The Company's leases do not contain any material residual value guarantees.

[0001032975-26-000021:notes:312]
The total operating lease costs including short-term lease costs were $19.1 million, $19.3 million and $19.5 million for the years ended March 31, 2026, 2025, and 2024, respectively. Total variable lease costs were not material during the years ended March 31, 2026, 2025 and 2024. The total operating and variable lease costs were included in cost of goods sold, marketing and selling, research and development, and general and administrative in the Company's consolidated statements of operations.

[0001032975-26-000021:notes:313]
Supplemental cash flow information related to operating leases (in thousands):

[0001032975-26-000021:notes:314]
|  |  | Years Ended March 31, |
|  |  | 2026 |  | 2025 |  | 2024 |
| Cash paid for amounts included in the measurement of operating lease liabilities |  | $ | 18,056 |  |  | $ | 16,847 |  |  | $ | 13,489 |  |
| ROU assets obtained in exchange for operating lease liabilities |  | $ | 6,902 |  |  | $ | 26,767 |  |  | $ | 8,593 |  |

[0001032975-26-000021:notes:315]
Future lease payments included in the measurement of operating lease liabilities as of March 31, 2026 for the following five fiscal years and thereafter are as follows (in thousands):

[0001032975-26-000021:notes:316]
| Years Ending March 31, |  |
| 2027 | $ | 18,222 |  |
| 2028 | 14,786 |  |
| 2029 | 14,242 |  |
| 2030 | 12,261 |  |
| 2031 | 10,496 |  |
| Thereafter | 29,549 |  |
| Total lease payments | $ | 99,556 |  |
| Less: imputed interest | (11,401) |  |
| Present value of lease liabilities | $ | 88,155 |  |

[0001032975-26-000021:notes:317]
Weighted-average lease terms and discount rates were as follows:

[0001032975-26-000021:notes:318]
|  |  | Years Ended March 31, |
|  |  | 2026 |  | 2025 |
| Weighted-average remaining lease terms (in years) |  | 6.9 |  | 7.6 |
| Weighted-average discount rate |  | 3.6 | % |  | 3.6 | % |


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001032975-26-000021:notes:319]
VALUATION AND QUALIFYING ACCOUNTS

[0001032975-26-000021:notes:320]
For the Fiscal Years Ended March 31, 2026, 2025 and 2024 (in thousands)

[0001032975-26-000021:notes:321]
The Company's Schedule II includes valuation and qualifying accounts related to allowances for doubtful accounts, sales returns, cooperative marketing arrangements, customer incentive programs, and pricing programs, for direct customers and tax valuation allowances. The Company also has sales incentive programs for indirect customers with whom it does not have a direct sales and receivable relationship. These programs are recorded as accrued liabilities and are not considered valuation or qualifying accounts.

[0001032975-26-000021:notes:322]
|  |  | Balance atBeginning ofYear |  | Charged(Credited) to Statement ofOperations (1) |  | Claims andAdjustmentsApplied AgainstAllowances (1) |  | Balance atEnd ofYear |
| Allowance for cooperative marketing arrangements: |  |  |  |  |  |  |  |  |
| 2026 |  | $ | 44,457 |  |  | $ | 305,257 |  |  | $ | (299,750) |  |  | $ | 49,964 |  |
| 2025 |  | $ | 41,634 |  |  | $ | 257,940 |  |  | $ | (255,117) |  |  | $ | 44,457 |  |
| 2024 |  | $ | 40,495 |  |  | $ | 232,837 |  |  | $ | (231,698) |  |  | $ | 41,634 |  |
| Allowance for customer incentive programs: |  |  |  |  |  |  |  |  |
| 2026 |  | $ | 66,564 |  |  | $ | 368,668 |  |  | $ | (361,233) |  |  | $ | 73,999 |  |
| 2025 |  | $ | 60,027 |  |  | $ | 337,039 |  |  | $ | (330,502) |  |  | $ | 66,564 |  |
| 2024 |  | $ | 71,645 |  |  | $ | 299,351 |  |  | $ | (310,969) |  |  | $ | 60,027 |  |
| Allowance for pricing programs: |  |  |  |  |  |  |  |  |
| 2026 |  | $ | 105,876 |  |  | $ | 931,144 |  |  | $ | (892,220) |  |  | $ | 144,800 |  |
| 2025 |  | $ | 91,280 |  |  | $ | 760,024 |  |  | $ | (745,428) |  |  | $ | 105,876 |  |
| 2024 |  | $ | 98,822 |  |  | $ | 707,954 |  |  | $ | (715,496) |  |  | $ | 91,280 |  |
| Other allowances: |  |  |  |  |  |  |  |  |
| 2026 |  | $ | 37,250 |  |  | $ | 148,558 |  |  | $ | (167,972) |  |  | $ | 17,836 |  |
| 2025 |  | $ | 10,180 |  |  | $ | 170,495 |  |  | $ | (143,425) |  |  | $ | 37,250 |  |
| 2024 |  | $ | 10,232 |  |  | $ | 141,909 |  |  | $ | (141,961) |  |  | $ | 10,180 |  |
| Tax valuation allowance: |  |  |  |  |  |  |  |  |
| 2026 |  | $ | 36,537 |  |  | $ | 385 |  |  | $ | — |  |  | $ | 36,922 |  |
| 2025 |  | $ | 35,536 |  |  | $ | 1,000 |  |  | $ | — |  |  | $ | 36,537 |  |
| 2024 |  | $ | 30,766 |  |  | $ | 4,770 |  |  | $ | — |  |  | $ | 35,536 |  |

[0001032975-26-000021:notes:323]
(1) The amounts for fiscal year 2024 include immaterial impacts from the business acquisitions during the year.
