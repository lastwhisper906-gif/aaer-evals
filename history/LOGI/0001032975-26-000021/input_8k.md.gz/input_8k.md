# LOGI 8-K — 0001032975-26-000014 filed 2026-05-05

## item codes, every 8-K on or before 2026-05-21

- 2026-05-05 0001032975-26-000014 — 2.02, 9.01
- 2026-01-27 0001032975-26-000006 — 2.02, 9.01
- 2025-11-14 0001032975-25-000085 — 7.01
- 2025-10-28 0001032975-25-000076 — 2.02, 9.01
- 2025-10-02 0001032975-25-000071 — 3.01
- 2025-09-19 0001032975-25-000068 — 5.02
- 2025-09-09 0001032975-25-000065 — 5.07, 8.01
- 2025-08-27 0001032975-25-000062 — 5.03, 9.01
- 2025-07-29 0001032975-25-000055 — 2.02, 9.01
- 2025-06-17 0001032975-25-000034 — 7.01, 9.01
- 2025-04-29 0001032975-25-000022 — 2.02, 9.01
- 2025-04-10 0001032975-25-000018 — 2.02, 9.01
- 2025-03-03 0001032975-25-000011 — 5.02, 9.01
- 2025-01-28 0001032975-25-000005 — 1.01, 2.02, 2.03, 9.01
- 2024-10-22 0001032975-24-000072 — 2.02, 9.01
- 2024-10-11 0001032975-24-000069 — 5.03, 9.01
- 2024-09-09 0001032975-24-000065 — 5.07, 8.01
- 2024-08-06 0001032975-24-000062 — 5.02, 9.01
- 2024-07-23 0001032975-24-000042 — 2.02, 9.01
- 2024-07-01 0001032975-24-000033 — 5.02, 8.01, 9.01
- 2024-06-13 0001032975-24-000030 — 5.02, 9.01
- 2024-04-30 0001032975-24-000015 — 2.02, 9.01
- 2024-03-18 0001032975-24-000012 — 5.02, 7.01, 9.01
- 2024-01-23 0001032975-24-000004 — 2.02, 9.01
- 2023-10-30 0001032975-23-000082 — 5.02, 9.01
- 2023-10-24 0001032975-23-000075 — 2.02, 9.01
- 2023-09-15 0001032975-23-000072 — 5.07, 8.01
- 2023-07-25 0001032975-23-000050 — 2.02, 9.01
- 2023-06-30 0001032975-23-000037 — 5.02 — amendment, the index does not say of what
- 2023-06-30 0001032975-23-000036 — 5.02
- 2023-06-13 0001032975-23-000030 — 5.02, 7.01, 9.01
- 2023-05-02 0001032975-23-000015 — 2.02, 9.01
- 2023-01-30 0001032975-23-000010 — 5.02, 9.01
- 2023-01-24 0001032975-23-000004 — 2.02, 5.02, 9.01
- 2023-01-12 0001628280-23-000934 — 2.02, 9.01
- 2022-10-25 0001628280-22-026927 — 2.02, 5.02, 9.01
- 2022-09-16 0001628280-22-025080 — 5.07, 8.01
- 2022-07-26 0001032975-22-000027 — 2.02, 9.01
- 2022-06-29 0001032975-22-000018 — 5.02
- 2022-05-03 0001032975-22-000008 — 2.02, 9.01
- 2022-01-25 0001032975-22-000003 — 2.02, 9.01
- 2021-10-26 0001032975-21-000043 — 2.02, 9.01
- 2021-09-10 0001032975-21-000040 — 5.07, 8.01
- 2021-07-27 0001032975-21-000029 — 2.02, 9.01
- 2021-04-29 0001032975-21-000012 — 2.02, 9.01
- 2021-01-19 0001032975-21-000004 — 2.02, 9.01
- 2020-10-20 0001032975-20-000045 — 2.02, 9.01
- 2020-09-11 0001032975-20-000042 — 5.07, 8.01
- 2020-07-21 0001032975-20-000029 — 2.02, 9.01
- 2020-07-01 0001032975-20-000023 — 5.02, 8.01
- 2020-05-12 0001032975-20-000011 — 2.02, 9.01
- 2020-03-30 0001032975-20-000009 — 5.02
- 2020-01-21 0001032975-20-000002 — 2.02, 9.01
- 2019-10-22 0001032975-19-000071 — 9.01
- 2019-09-26 0001032975-19-000068 — 1.01, 7.01, 9.01
- 2019-09-06 0001032975-19-000063 — 5.07, 8.01
- 2019-07-23 0001032975-19-000046 — 2.02, 9.01
- 2019-07-23 0001032975-19-000045 — 5.02, 9.01
- 2019-07-02 0001032975-19-000036 — 5.02
- 2019-06-25 0001032975-19-000034 — 5.02
- 2019-05-03 0001032975-19-000021 — 5.02 — amendment, the index does not say of what
- 2019-04-30 0001032975-19-000017 — 2.02, 5.02, 9.01
- 2019-03-28 0001032975-19-000013 — 5.02
- 2019-01-22 0001032975-19-000004 — 2.02, 9.01
- 2018-10-23 0001032975-18-000044 — 2.02, 9.01
- 2018-09-07 0001032975-18-000040 — 5.07, 8.01
- 2018-07-31 0001032975-18-000035 — 1.01, 2.02, 2.05, 7.01, 9.01
- 2018-06-27 0001032975-18-000020 — 5.02
- 2018-05-03 0001032975-18-000013 — 2.02, 5.02, 9.01
- 2018-01-23 0001032975-18-000005 — 2.02, 9.01
- 2017-10-24 0001032975-17-000043 — 2.02, 9.01
- 2017-09-18 0001032975-17-000040 — 5.07, 8.01
- 2017-07-25 0001032975-17-000028 — 2.02, 9.01
- 2017-07-12 0001032975-17-000022 — 1.01
- 2017-04-26 0001032975-17-000012 — 2.02, 9.01
- 2017-01-25 0001032975-17-000002 — 2.02, 9.01
- 2016-10-26 0001032975-16-000103 — 2.02, 9.01
- 2016-09-13 0001032975-16-000101 — 5.07, 8.01
- 2016-07-28 0001032975-16-000092 — 2.02, 9.01
- 2016-06-30 0001032975-16-000087 — 5.02
- 2016-04-28 0001032975-16-000077 — 2.02, 9.01
- 2016-04-14 0001032975-16-000073 — 1.01, 7.01, 9.01
- 2016-01-21 0001032975-16-000064 — 2.02, 9.01
- 2016-01-04 0001032975-16-000061 — 1.01, 2.01, 9.01
- 2015-12-23 0001032975-15-000059 — 5.02
- 2015-10-22 0001032975-15-000047 — 2.02, 9.01
- 2015-09-11 0001032975-15-000044 — 5.07, 8.01
- 2015-07-24 0001032975-15-000034 — 2.05 — amendment of 0001032975-15-000030
- 2015-07-23 0001032975-15-000030 — 2.02, 9.01
- 2015-06-25 0001032975-15-000025 — 5.02
- 2015-05-14 0001032975-15-000011 — 8.01, 9.01
- 2015-04-23 0001032975-15-000008 — 2.02, 2.05
- 2015-01-22 0001628280-15-000191 — 2.02, 8.01
- 2014-12-23 0001193125-14-450908 — 5.02, 5.07, 8.01
- 2014-11-25 0001193125-14-425233 — 3.01
- 2014-11-13 0001193125-14-411303 — 4.01, 9.01
- 2014-10-23 0001104659-14-073164 — 2.02, 9.01
- 2014-09-04 0001193125-14-331214 — 4.02, 9.01
- 2014-08-18 0001193125-14-313346 — 3.01, 9.01
- 2014-07-24 0001104659-14-053065 — 2.02, 9.01
- 2014-06-05 0001193125-14-226177 — 3.01, 9.01
- 2014-05-22 0001193125-14-208777 — 8.01, 9.01
- 2014-04-24 0001104659-14-029650 — 2.02, 9.01
- 2014-01-23 0001104659-14-003619 — 2.02, 9.01
- 2013-10-24 0001104659-13-077404 — 2.02, 9.01
- 2013-09-09 0001193125-13-361441 — 5.02, 5.07, 8.01, 9.01
- 2013-09-06 0001193125-13-359930 — 5.02, 9.01
- 2013-08-02 0001193125-13-317343 — 5.02
- 2013-07-25 0001104659-13-056372 — 2.02, 9.01
- 2013-06-28 0001193125-13-277394 — 5.02, 9.01
- 2013-06-20 0001193125-13-265914 — 8.01, 9.01
- 2013-04-25 0001104659-13-032570 — 2.02, 9.01
- 2013-04-17 0001193125-13-158923 — 5.02, 9.01
- 2013-03-01 0001193125-13-085804 — 2.05
- 2013-01-24 0001104659-13-004214 — 2.02, 9.01
- 2013-01-02 0001193125-13-000058 — 5.02
- 2012-10-25 0001104659-12-070966 — 2.02, 9.01
- 2012-09-11 0001193125-12-388070 — 5.02, 5.07, 8.01, 9.01
- 2012-08-22 0001193125-12-364167 — 5.02, 8.01, 9.01
- 2012-07-26 0001104659-12-051084 — 2.02, 9.01
- 2012-06-08 0001193125-12-264132 — 2.05, 9.01 — amendment, the index does not say of what
- 2012-04-26 0001193125-12-183657 — 5.02, 9.01
- 2012-04-26 0001104659-12-028470 — 2.02, 2.05, 9.01
- 2012-03-15 0001193125-12-115954 — 5.02, 9.01
- 2012-01-26 0001104659-12-004014 — 2.02, 9.01
- 2012-01-04 0001193125-12-002212 — 1.01, 2.03, 9.01
- 2011-10-27 0001104659-11-058150 — 2.02, 9.01
- 2011-09-12 0001193125-11-245931 — 5.07
- 2011-07-28 0001193125-11-200929 — 5.02, 9.01
- 2011-07-28 0001193125-11-199704 — 2.02, 9.01
- 2011-04-28 0001193125-11-112669 — 2.02, 9.01
- 2011-03-24 0001193125-11-076483 — 5.02, 9.01
- 2011-01-27 0001032975-11-000003 — 9.01
- 2010-10-28 0001032975-10-000032 — 9.01
- 2010-09-13 0001032975-10-000022 — 5.07
- 2010-07-29 0001032975-10-000010 — 2.02, 9.01
- 2010-06-10 0001193125-10-136877 — 5.02, 9.01
- 2010-05-03 0001193125-10-104337 — 5.02
- 2010-04-29 0001032975-10-000008 — 2.02, 9.01
- 2010-02-19 0001032975-10-000006 — 9.01 — amendment of 0001193125-09-252416
- 2010-01-21 0001032975-10-000002 — 2.02, 9.01
- 2009-12-14 0001193125-09-252416 — 2.01, 9.01
- 2009-11-17 0001032975-09-000023 — 1.01
- 2009-10-22 0001032975-09-000018 — 9.01
- 2009-09-22 0001193125-09-195545 — 5.02, 9.01
- 2009-09-03 0001032975-09-000013 — 8.01
- 2009-07-23 0001140361-09-016802 — 2.02, 9.01
- 2009-06-01 0001193125-09-122550 — 5.02
- 2009-04-23 0001193125-09-085054 — 2.02, 9.01
- 2009-04-02 0001193125-09-071272 — 5.02, 9.01
- 2009-01-20 0001193125-09-008454 — 2.05 — amendment of 0001193125-09-002609
- 2009-01-20 0001193125-09-007902 — 2.02, 9.01
- 2009-01-07 0001193125-09-002609 — 2.05, 9.01
- 2009-01-07 0001193125-09-002370 — 5.02, 9.01
- 2008-12-09 0001193125-08-250543 — 5.02, 9.01
- 2008-10-21 0001193125-08-213212 — 2.02, 9.01
- 2008-07-22 0001193125-08-154721 — 2.02, 9.01
- 2008-06-24 0001193125-08-139163 — 5.03, 9.01
- 2008-05-13 0001193125-08-113263 — 5.02, 9.01
- 2008-04-22 0001193125-08-086176 — 2.02, 9.01

## late-filing notifications on or before 2026-05-21

- 2015-06-02 0001032975-15-000020 — NT 10-K, for the period ended 2015-03-31
- 2014-11-06 0001193125-14-401306 — NT 10-Q, for the period ended 2014-09-30
- 2014-07-24 0001193125-14-277575 — NT 10-Q, for the period ended 2014-06-30
- 2014-05-22 0001193125-14-208712 — NT 10-K, for the period ended 2014-03-31
- 2009-08-06 0001032975-09-000006 — NT 10-Q, for the period ended 2009-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001032975-26-000014:8k_2_02:1]
EX-99.1
2
exhibit991q4fy26.htm
EX-99.1

[0001032975-26-000014:8k_2_02:2]
Document

[0001032975-26-000014:8k_2_02:3]
Exhibit 99.1

[0001032975-26-000014:8k_2_02:4]
Editorial Contacts:

[0001032975-26-000014:8k_2_02:5]
Kate Beerkens, Director of Investor Relations - ir@logitech.com

[0001032975-26-000014:8k_2_02:6]
Bruno Rodriguez, Head of Corporate Communications - mediarelations@logitech.com

[0001032975-26-000014:8k_2_02:7]
Logitech Announces Q4 and Full Fiscal Year 2026 Results

[0001032975-26-000014:8k_2_02:8]
Strong FY 2026 Demonstrates

[0001032975-26-000014:8k_2_02:9]
Strategy and  Operating Principles Are Delivering

[0001032975-26-000014:8k_2_02:10]
LAUSANNE, Switzerland, and SAN JOSE, Calif., May 5, 2026 — SIX Swiss Exchange Ad hoc announcement pursuant to Art. 53 LR — Logitech International (SIX: LOGN) (Nasdaq: LOGI) today announced financial results for the fourth quarter and full Fiscal Year 2026.

[0001032975-26-000014:8k_2_02:11]
For Fiscal Year 2026:

[0001032975-26-000014:8k_2_02:12]
•Sales were $4.84 billion, up 6 percent in US dollars and 4 percent in constant currency compared to the prior year.

[0001032975-26-000014:8k_2_02:13]
•GAAP operating income was $775 million, up 18 percent compared to the prior year. Non-GAAP operating income was $911 million, up 18 percent compared to the prior year.

[0001032975-26-000014:8k_2_02:14]
•GAAP earnings per share was $4.80, up 16 percent compared to the prior year. Non-GAAP EPS was $5.78, up 19 percent compared to the prior year.

[0001032975-26-000014:8k_2_02:15]
•Cash flow from operations was $1.04 billion. The year-ending cash balance was $1.7 billion. The Company returned $768 million of cash to shareholders through its annual dividend payment and share repurchases.

[0001032975-26-000014:8k_2_02:16]
For Q4 Fiscal Year 2026:

[0001032975-26-000014:8k_2_02:17]
•Sales were $1.09 billion, up 7 percent in US dollars and 3 percent in constant currency compared to Q4 of the prior year.

[0001032975-26-000014:8k_2_02:18]
•GAAP operating income was $136 million, up 28 percent compared to Q4 of the prior year. Non-GAAP operating income was $167 million, up 25 percent compared to Q4 of the prior year.

[0001032975-26-000014:8k_2_02:19]
•GAAP EPS was $0.98, up 2 percent compared to Q4 of the prior year. Non-GAAP EPS was $1.13, up 22 percent compared to Q4 of the prior year.

[0001032975-26-000014:8k_2_02:20]
•Cash flow from operations was $203 million.

[0001032975-26-000014:8k_2_02:21]
“Our strong Fiscal Year 2026 performance demonstrates that our strategy and operating principles of playing offense, cost discipline and agility are working,” said Hanneke Faber, Logitech chief executive officer. “We closed the year with a strong Q4, and were pleased to see a solid return to growth in the Americas, and accelerated growth in Gaming. As we transition into FY27, we are amplifying our focus on future growth. Rapid AI advancements make it a unique period for us to innovate and invest for a future in which both Work and Play will look different.”

[0001032975-26-000014:8k_2_02:22]
“FY 2026 showcased what our teams and business model are capable of,” said Matteo Anversa, Logitech chief financial officer. “Operating income grew 18% year over year, and our annual non-GAAP gross margin of 43.6% and operating margin of 18.8% were the highest ever, outside of pandemic peaks. We also delivered substantial shareholder returns of $768 million in dividends and share repurchases. While the operating environment remains volatile, we see good momentum in the business going into Q1.”

[0001032975-26-000014:8k_2_02:23]
Outlook

[0001032975-26-000014:8k_2_02:24]
Our financial outlook for the first quarter of Fiscal Year 2027 is:

[0001032975-26-000014:8k_2_02:25]
|  |  | Q1 FY27 outlook |
| Sales |  | $1,190 - $1,215 million |
| Sales growth (in US dollars, year over year) |  | 4% - 6% |
| Sales growth (in constant currency, year over year) |  | 2% - 4% |
| Non-GAAP operating income |  | $195 - $215 million |

[0001032975-26-000014:8k_2_02:26]
Financial Results Videoconference and Webcast

[0001032975-26-000014:8k_2_02:27]
Logitech will hold a financial results videoconference to discuss the results for the fourth quarter and full Fiscal Year 2026 on Tuesday, May 5, 2026 at 1:30 p.m. Pacific Daylight Time (PDT) and 10:30 p.m. Central European Summer Time (CEST).

[0001032975-26-000014:8k_2_02:28]
A livestream of the event will be available on the Logitech corporate website at https://ir.logitech.com. This press release and the Q4 Fiscal Year 2026 Shareholder Letter are also available there.

[0001032975-26-000014:8k_2_02:29]
Use of Non-GAAP Financial Information and Constant Currency

[0001032975-26-000014:8k_2_02:30]
To facilitate comparisons to Logitech’s historical results, Logitech has included non-GAAP adjusted measures in this press release, which exclude share-based compensation expense, amortization of intangible assets, acquisition-related costs, restructuring charges (credits), net, loss (gain) on investments, non-GAAP income tax adjustment, and other items detailed under “Supplemental Financial Information” after the tables below and posted to our website at https://ir.logitech.com. Logitech also presents percentage sales growth in constant currency (“cc”), a non-GAAP measure, to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales. Logitech believes this information, used together with the GAAP financial information, will help investors to evaluate its current period performance, outlook and trends in its business. With respect to the Company’s outlook for non-GAAP operating income, most of the excluded amounts pertain to events that have not yet occurred and are not currently possible to estimate with a reasonable degree of accuracy. Therefore, no reconciliation to the GAAP amounts has been provided for the first quarter of Fiscal Year 2027 non-GAAP outlook.

[0001032975-26-000014:8k_2_02:31]
Public Dissemination of Certain Information

[0001032975-26-000014:8k_2_02:32]
Recordings of Logitech’s earnings videoconferences and certain events Logitech participates in or hosts, with members of the investment community are posted on the company’s investor relations website at https://ir.logitech.com. Additionally, Logitech provides notifications of news or announcements regarding its operations and financial performance, including its filings with the Securities and Exchange Commission (SEC), investor events, and press and earnings releases as part of its investor relations website. Logitech intends to use its investor relations website as means of disclosing material nonpublic information and for complying with its disclosure obligations under Regulation FD. Logitech’s corporate governance information also is available on its investor relations website.

[0001032975-26-000014:8k_2_02:33]
About Logitech

[0001032975-26-000014:8k_2_02:34]
Logitech designs software-enabled hardware solutions that help businesses thrive and bring people together when working, creating and gaming. As the point of connection between people and the digital world, our mission is to extend human potential in work and play, in a way that is good for people and the planet. Founded in 1981, Logitech International is a Swiss public company listed on the SIX Swiss Exchange (LOGN) and on the Nasdaq Global Select Market (LOGI). Find Logitech and its other brands, including Logitech G, at www.logitech.com or company blog.

[0001032975-26-000014:8k_2_02:35]
# # #

[0001032975-26-000014:8k_2_02:36]
Note that unless noted otherwise, comparisons are year over year.

[0001032975-26-000014:8k_2_02:37]
Logitech and other Logitech marks are trademarks or registered trademarks of Logitech Europe S.A. and/or its affiliates in the U.S. and other countries. All other trademarks are the property of their respective owners. For more information about Logitech and its products, visit the company’s website at www.logitech.com.

[0001032975-26-000014:8k_2_02:38]
(LOGIIR)

[0001032975-26-000014:8k_2_02:39]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended March 31, |  | Fiscal Years EndedMarch 31, |
| GAAP CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Net sales |  | $ | 1,085,523 |  |  | $ | 1,010,355 |  |  | $ | 4,840,761 |  |  | $ | 4,554,900 |  |
| Cost of goods sold |  | 601,130 |  |  | 572,334 |  |  | 2,742,407 |  |  | 2,582,745 |  |
| Amortization of intangible assets |  | 1,113 |  |  | 2,210 |  |  | 7,017 |  |  | 9,554 |  |
| Gross profit |  | 483,280 |  |  | 435,811 |  |  | 2,091,337 |  |  | 1,962,601 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Marketing and selling |  | 214,940 |  |  | 198,598 |  |  | 816,604 |  |  | 814,414 |  |
| Research and development |  | 87,072 |  |  | 79,523 |  |  | 316,221 |  |  | 309,008 |  |
| General and administrative |  | 41,640 |  |  | 40,266 |  |  | 167,160 |  |  | 164,014 |  |
| Amortization of intangible assets and acquisition-related costs |  | 919 |  |  | 2,630 |  |  | 6,298 |  |  | 10,695 |  |
| Restructuring charges, net |  | 2,914 |  |  | 8,890 |  |  | 9,860 |  |  | 9,615 |  |
| Total operating expenses |  | 347,485 |  |  | 329,907 |  |  | 1,316,143 |  |  | 1,307,746 |  |
| Operating income |  | 135,795 |  |  | 105,904 |  |  | 775,194 |  |  | 654,855 |  |
| Interest income |  | 14,204 |  |  | 12,394 |  |  | 48,246 |  |  | 54,997 |  |
| Other income (expense), net |  | (150) |  |  | (91) |  |  | 3,079 |  |  | (2,980) |  |
| Income before income taxes |  | 149,849 |  |  | 118,207 |  |  | 826,519 |  |  | 706,872 |  |
| Provision for (benefit from) income taxes |  | 6,386 |  |  | (25,859) |  |  | 115,332 |  |  | 75,343 |  |
| Net income |  | $ | 143,463 |  |  | $ | 144,066 |  |  | $ | 711,187 |  |  | $ | 631,529 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.99 |  |  | $ | 0.97 |  |  | $ | 4.85 |  |  | $ | 4.17 |  |
| Diluted |  | $ | 0.98 |  |  | $ | 0.96 |  |  | $ | 4.80 |  |  | $ | 4.13 |  |
| Weighted average shares used to compute net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | 145,384 |  |  | 148,999 |  |  | 146,775 |  |  | 151,322 |  |
| Diluted |  | 147,002 |  |  | 150,709 |  |  | 148,208 |  |  | 152,784 |  |

[0001032975-26-000014:8k_2_02:40]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
|  |  | March 31, |  | March 31, |  |  |  |  |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  | 2026 |  | 2025 |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,741,546 |  |  | $ | 1,503,205 |  |  |  |  |  |
| Accounts receivable, net |  | 505,867 |  |  | 454,546 |  |  |  |  |  |
| Inventories |  | 489,948 |  |  | 503,747 |  |  |  |  |  |
| Other current assets |  | 177,895 |  |  | 131,211 |  |  |  |  |  |
| Total current assets |  | 2,915,256 |  |  | 2,592,709 |  |  |  |  |  |
| Non-current assets: |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  | 116,454 |  |  | 113,858 |  |  |  |  |  |
| Goodwill |  | 465,417 |  |  | 463,230 |  |  |  |  |  |
| Other intangible assets, net |  | 12,386 |  |  | 24,630 |  |  |  |  |  |
| Other assets |  | 339,075 |  |  | 344,077 |  |  |  |  |  |
| Total assets |  | 3,848,588 |  |  | 3,538,504 |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 530,983 |  |  | $ | 414,586 |  |  |  |  |  |
| Accrued and other current liabilities |  | 781,990 |  |  | 686,503 |  |  |  |  |  |
| Total current liabilities |  | 1,312,973 |  |  | 1,101,089 |  |  |  |  |  |
| Non-current liabilities: |  |  |  |  |  |  |  |  |
| Income taxes payable |  | 86,322 |  |  | 88,483 |  |  |  |  |  |
| Other non-current liabilities |  | 237,899 |  |  | 221,512 |  |  |  |  |  |
| Total liabilities |  | 1,637,194 |  |  | 1,411,084 |  |  |  |  |  |
| Shareholders’ equity: |  |  |  |  |  |  |  |  |
| Registered shares, CHF 0.25 par valueIssued shares: 160,784 and 168,994 at March 31, 2026 and 2025, respectively |  | 28,001 |  |  | 29,432 |  |  |  |  |  |
| Additional paid-in capital |  | 123,386 |  |  | 82,591 |  |  |  |  |  |
| Shares in treasury, at cost Treasury shares: 17,282 and 20,485 at March 31, 2026 and 2025, respectively |  | (1,207,454) |  |  | (1,464,912) |  |  |  |  |  |
| Retained earnings |  | 3,381,278 |  |  | 3,627,261 |  |  |  |  |  |
| Accumulated other comprehensive loss |  | (113,817) |  |  | (146,952) |  |  |  |  |  |
| Total shareholders’ equity |  | 2,211,394 |  |  | 2,127,420 |  |  |  |  |  |
| Total liabilities and shareholders’ equity |  | $ | 3,848,588 |  |  | $ | 3,538,504 |  |  |  |  |  |

[0001032975-26-000014:8k_2_02:41]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended March 31, |  | Fiscal Years EndedMarch 31, |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 143,463 |  |  | $ | 144,066 |  |  | $ | 711,187 |  |  | $ | 631,529 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  | 16,517 |  |  | 15,486 |  |  | 64,139 |  |  | 59,664 |  |
| Amortization of intangible assets |  | 2,032 |  |  | 4,840 |  |  | 13,315 |  |  | 20,098 |  |
| Loss on investments |  | 321 |  |  | 311 |  |  | 612 |  |  | 2,029 |  |
| Share-based compensation expense |  | 25,817 |  |  | 13,846 |  |  | 112,392 |  |  | 89,913 |  |
| Deferred income taxes |  | 23,526 |  |  | 37,891 |  |  | 29,822 |  |  | 56,543 |  |
| Other |  | (37) |  |  | (10) |  |  | 28 |  |  | 120 |  |
| Changes in assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | 174,379 |  |  | 197,913 |  |  | (39,436) |  |  | 69,979 |  |
| Inventories |  | (44,039) |  |  | (12,947) |  |  | 22,882 |  |  | (80,501) |  |
| Other assets |  | (6,136) |  |  | 14,554 |  |  | (36,559) |  |  | 23,970 |  |
| Accounts payable |  | (62,793) |  |  | (168,475) |  |  | 109,174 |  |  | (31,627) |  |
| Accrued and other liabilities |  | (70,257) |  |  | (117,819) |  |  | 49,651 |  |  | 840 |  |
| Net cash provided by operating activities |  | 202,793 |  |  | 129,656 |  |  | 1,037,207 |  |  | 842,557 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  | (13,839) |  |  | (12,788) |  |  | (61,562) |  |  | (56,128) |  |
| Purchases of deferred compensation investments |  | (4,922) |  |  | (798) |  |  | (10,479) |  |  | (6,600) |  |
| Proceeds from sales of deferred compensation investments |  | 5,590 |  |  | 2,121 |  |  | 11,308 |  |  | 7,079 |  |
| Other investing activities |  | (458) |  |  | (446) |  |  | (1,654) |  |  | (1,619) |  |
| Net cash used in investing activities |  | (13,629) |  |  | (11,911) |  |  | (62,387) |  |  | (57,268) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Payment of cash dividends |  | — |  |  | — |  |  | (233,059) |  |  | (207,853) |  |
| Payment of contingent consideration for business acquisition |  | — |  |  | — |  |  | — |  |  | (1,245) |  |
| Purchases of registered shares |  | (279,559) |  |  | (125,516) |  |  | (534,939) |  |  | (588,838) |  |
| Proceeds from exercises of stock options and purchase rights |  | 14,148 |  |  | 16,170 |  |  | 38,320 |  |  | 36,405 |  |
| Tax withholdings related to net share settlements of restricted stock units |  | (2,032) |  |  | (10,234) |  |  | (21,438) |  |  | (32,485) |  |
| Other financing activities |  | — |  |  | (1,681) |  |  | — |  |  | (3,344) |  |
| Net cash used in financing activities |  | (267,443) |  |  | (121,261) |  |  | (751,116) |  |  | (797,360) |  |
| Effect of exchange rate changes on cash and cash equivalents |  | 2,005 |  |  | 3,889 |  |  | 14,637 |  |  | (5,566) |  |
| Net increase (decrease) in cash and cash equivalents |  | (76,274) |  |  | 373 |  |  | 238,341 |  |  | (17,637) |  |
| Cash and cash equivalents, beginning of the period |  | 1,817,820 |  |  | 1,502,832 |  |  | 1,503,205 |  |  | 1,520,842 |  |
| Cash and cash equivalents, end of the period |  | $ | 1,741,546 |  |  | $ | 1,503,205 |  |  | $ | 1,741,546 |  |  | $ | 1,503,205 |  |

[0001032975-26-000014:8k_2_02:42]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three Months Ended March 31, |  | Fiscal Years EndedMarch 31, |
| NET SALES |  | 2026 |  | 2025 |  | Change |  | 2026 |  | 2025 |  | Change |
| Net sales by product category: |  |  |  |  |  |  |  |  |  |  |  |  |
| Gaming (1) |  | $ | 292,312 |  |  | $ | 261,807 |  |  | 12 | % |  | $ | 1,414,206 |  |  | $ | 1,338,467 |  |  | 6 | % |
| Keyboards & Combos |  | 224,577 |  |  | 220,626 |  |  | 2 |  |  | 937,551 |  |  | 882,643 |  |  | 6 |  |
| Pointing Devices |  | 200,870 |  |  | 185,857 |  |  | 8 |  |  | 858,904 |  |  | 788,784 |  |  | 9 |  |
| Video Collaboration |  | 161,395 |  |  | 143,245 |  |  | 13 |  |  | 689,040 |  |  | 626,000 |  |  | 10 |  |
| Webcams |  | 76,228 |  |  | 77,948 |  |  | (2) |  |  | 326,172 |  |  | 315,520 |  |  | 3 |  |
| Tablet Accessories |  | 66,334 |  |  | 57,954 |  |  | 14 |  |  | 336,189 |  |  | 299,540 |  |  | 12 |  |
| Headsets |  | 44,866 |  |  | 42,672 |  |  | 5 |  |  | 179,825 |  |  | 179,710 |  |  | — |  |
| Other (2) |  | 18,941 |  |  | 20,246 |  |  | (6) |  |  | 98,874 |  |  | 124,236 |  |  | (20) |  |
| Total Net Sales |  | $ | 1,085,523 |  |  | $ | 1,010,355 |  |  | 7 | % |  | $ | 4,840,761 |  |  | $ | 4,554,900 |  |  | 6 | % |

[0001032975-26-000014:8k_2_02:43]
(1) Gaming includes streaming services revenue generated by Streamlabs.

[0001032975-26-000014:8k_2_02:44]
(2) Other primarily consists of mobile speakers and PC speakers.

[0001032975-26-000014:8k_2_02:45]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three Months Ended March 31, |  | Fiscal Years EndedMarch 31, |
| GAAP TO NON-GAAP RECONCILIATION (A) |  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Gross profit - GAAP |  | $ | 483,280 |  | $ | 435,811 |  | $ | 2,091,337 |  | $ | 1,962,601 |
| Share-based compensation expense |  | 2,256 |  | 1,348 |  | 10,631 |  | 10,021 |
| Amortization of intangible assets |  | 1,113 |  | 2,210 |  | 7,017 |  | 9,554 |
| Gross profit - Non-GAAP |  | $ | 486,649 |  | $ | 439,369 |  | $ | 2,108,985 |  | $ | 1,982,176 |
| Gross margin - GAAP |  | 44.5 | % |  | 43.1 | % |  | 43.2 | % |  | 43.1 | % |
| Gross margin - Non-GAAP |  | 44.8 | % |  | 43.5 | % |  | 43.6 | % |  | 43.5 | % |
| Operating expenses - GAAP |  | $ | 347,485 |  | $ | 329,907 |  | $ | 1,316,143 |  | $ | 1,307,746 |
| Less: Share-based compensation expense |  | 23,561 |  | 12,498 |  | 101,761 |  | 79,892 |
| Less: Amortization of intangible assets and acquisition-related costs |  | 919 |  | 2,630 |  | 6,298 |  | 10,695 |
| Less: Restructuring charges, net |  | 2,914 |  | 8,890 |  | 9,860 |  | 9,615 |
| Operating expenses - Non-GAAP |  | $ | 320,091 |  | $ | 305,889 |  | $ | 1,198,224 |  | $ | 1,207,544 |
| % of net sales - GAAP |  | 32.0 | % |  | 32.7 | % |  | 27.2 | % |  | 28.7 | % |
| % of net sales - Non-GAAP |  | 29.5 | % |  | 30.3 | % |  | 24.8 | % |  | 26.5 | % |
| Operating income - GAAP |  | $ | 135,795 |  | $ | 105,904 |  | $ | 775,194 |  | $ | 654,855 |
| Share-based compensation expense |  | 25,817 |  | 13,846 |  | 112,392 |  | 89,913 |
| Amortization of intangible assets and acquisition-related costs |  | 2,032 |  | 4,840 |  | 13,315 |  | 20,249 |
| Restructuring charges, net |  | 2,914 |  | 8,890 |  | 9,860 |  | 9,615 |
| Operating income - Non-GAAP |  | $ | 166,558 |  | $ | 133,480 |  | $ | 910,761 |  | $ | 774,632 |
| % of net sales - GAAP |  | 12.5 | % |  | 10.5 | % |  | 16.0 | % |  | 14.4 | % |
| % of net sales - Non-GAAP |  | 15.3 | % |  | 13.2 | % |  | 18.8 | % |  | 17.0 | % |
| Net income - GAAP |  | $ | 143,463 |  | $ | 144,066 |  | $ | 711,187 |  | $ | 631,529 |
| Share-based compensation expense |  | 25,817 |  | 13,846 |  | 112,392 |  | 89,913 |
| Amortization of intangible assets and acquisition-related costs |  | 2,032 |  | 4,840 |  | 13,315 |  | 20,249 |
| Restructuring charges, net |  | 2,914 |  | 8,890 |  | 9,860 |  | 9,615 |
| Loss on investments |  | 321 |  | 311 |  | 612 |  | 2,029 |
| Non-GAAP income tax adjustment |  | (8,868) |  | (32,225) |  | 9,076 |  | (13,405) |
| Net income - Non-GAAP |  | $ | 165,679 |  | $ | 139,728 |  | $ | 856,442 |  | $ | 739,930 |
| Net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  | $ | 0.98 |  | $ | 0.96 |  | $ | 4.80 |  | $ | 4.13 |
| Diluted - Non-GAAP |  | $ | 1.13 |  | $ | 0.93 |  | $ | 5.78 |  | $ | 4.84 |
| Shares used to compute net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP and Non-GAAP |  | 147,002 |  | 150,709 |  | 148,208 |  | 152,784 |

[0001032975-26-000014:8k_2_02:46]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three Months Ended March 31, |  | Fiscal Years EndedMarch 31, |
| SHARE-BASED COMPENSATION EXPENSE |  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Share-based Compensation Expense |  |  |  |  |  |  |  |  |
| Cost of goods sold |  | $ | 2,256 |  |  | $ | 1,348 |  |  | $ | 10,631 |  |  | $ | 10,021 |  |
| Marketing and selling |  | 10,524 |  |  | 6,245 |  |  | 42,506 |  |  | 40,378 |  |
| Research and development |  | 5,492 |  |  | 4,331 |  |  | 22,904 |  |  | 20,180 |  |
| General and administrative |  | 7,545 |  |  | 1,922 |  |  | 36,351 |  |  | 19,334 |  |
| Total share-based compensation expense |  | 25,817 |  |  | 13,846 |  |  | 112,392 |  |  | 89,913 |  |
| Income tax benefit |  | (5,101) |  |  | (3,247) |  |  | (20,721) |  |  | (20,148) |  |
| Total share-based compensation expense, net of income tax benefit |  | $ | 20,716 |  |  | $ | 10,599 |  |  | $ | 91,671 |  |  | $ | 69,765 |  |

[0001032975-26-000014:8k_2_02:47]
*Note: These preliminary results for the three months and fiscal year ended March 31, 2026 are subject to adjustments, including subsequent events that may occur through the date of filing our Annual Report on Form 10-K.

[0001032975-26-000014:8k_2_02:48]
(A) Non-GAAP Financial Measures

[0001032975-26-000014:8k_2_02:49]
To supplement our condensed consolidated financial results prepared in accordance with GAAP, we use a number of financial measures, both GAAP and non-GAAP, in analyzing and assessing our overall business performance, for making operating decisions and for forecasting and planning future periods. We consider the use of non-GAAP financial measures helpful in assessing our current financial performance, ongoing operations and prospects for the future as well as understanding financial and business trends relating to our financial condition and results of operations.

[0001032975-26-000014:8k_2_02:50]
While we use non-GAAP financial measures as a tool to enhance our understanding of certain aspects of our financial performance and to provide incremental insight into the underlying factors and trends affecting both our performance and our cash-generating potential, we do not consider these measures to be a substitute for, or superior to, the information provided by GAAP financial measures. Consistent with this approach, we believe that disclosing non-GAAP financial measures to the readers of our financial statements provides useful supplemental data that, while not a substitute for GAAP financial measures, can offer insight in the review of our financial and operational performance and enable investors to more fully understand trends in our current and future performance. In assessing our business during the quarter and fiscal year ended March 31, 2026 and prior periods presented, we excluded items in the following general categories, each of which are described below:

[0001032975-26-000014:8k_2_02:51]
Share-based compensation expense. We believe that providing non-GAAP measures excluding share-based compensation expense, in addition to the GAAP measures, allows for a more transparent comparison of our financial results from period to period. We prepare and maintain our budgets and forecasts for future periods on a basis consistent with this non-GAAP financial measure. Further, companies use a variety of types of equity awards as well as a variety of methodologies, assumptions and estimates to determine share-based compensation expense. We believe that excluding share-based compensation expense enhances our ability and the ability of investors to understand the impact of non-cash share-based compensation on our operating results and to compare our results against the results of other companies.

[0001032975-26-000014:8k_2_02:52]
Amortization of intangible assets. We incur intangible asset amortization expense, primarily in connection with our acquisitions of various businesses and technologies. The amortization of purchased intangibles varies depending on the level of acquisition activity. We exclude these various charges in budgeting, planning and forecasting future periods and we believe that providing the non-GAAP measures excluding these various non-cash charges, as well as the GAAP measures, provides additional insight when comparing our gross profit, operating expenses, and financial results from period to period.

[0001032975-26-000014:8k_2_02:53]
Acquisition-related costs. We incurred expenses in connection with our acquisitions which we generally would not have otherwise incurred in the periods presented as a part of our continuing operations. Acquisition-related costs include certain incremental expenses incurred to effect a business combination. We believe that providing the non-GAAP measures excluding these costs, as well as the GAAP measures, assists our investors because such costs are not reflective of our ongoing operating results.

[0001032975-26-000014:8k_2_02:54]
Restructuring charges (credits), net. These charges (credits) are associated with restructuring plans and will vary based on the initiatives in place during any given period. Restructuring charges may include costs related to employee terminations, facility closures and early cancellation of certain contracts as well as other costs resulting from our restructuring initiatives. We believe that providing the non-GAAP measures excluding these items, as well as the GAAP measures, assists our investors because such charges (credits) are not reflective of our ongoing operating results.

[0001032975-26-000014:8k_2_02:55]
Loss (gain) on investments. We recognize losses (gains) related to our investments in various companies, which vary depending on the operational and financial performance of the companies in which we invest. These amounts include our losses (earnings) on equity method investments as well as investment impairments and losses (gains) resulting from sales or other events related to our investments. We believe that providing the non-GAAP measures excluding these items, as well as the GAAP measures, assists our investors because such losses (gains) are not reflective of our ongoing operations.

[0001032975-26-000014:8k_2_02:56]
Non-GAAP income tax adjustment.  Non-GAAP income tax adjustment primarily measures the income tax effect of non-GAAP adjustments excluded above as well as the income tax impact of non-recurring deferred taxes, tax settlements, and other non-routine tax events, the determination of which is based upon the nature of the underlying items.

[0001032975-26-000014:8k_2_02:57]
Each of the non-GAAP financial measures described above, and used in this press release, should not be considered in isolation from, or as a substitute for, a measure of financial performance prepared in accordance with GAAP. Further, investors are cautioned that there are inherent limitations associated with the use of each of these non-GAAP financial measures as an analytical tool. In particular, these non-GAAP financial measures are not based on a comprehensive set of accounting rules or principles and many of the adjustments to the GAAP financial measures reflect the exclusion of items that are recurring and may be reflected in the Company’s financial results for the foreseeable future. We compensate for these limitations by providing specific information in the reconciliation included in this press release regarding the GAAP amounts excluded from the non-GAAP financial measures. In addition, as noted above, we evaluate the non-GAAP financial measures together with the most directly comparable GAAP financial information.

[0001032975-26-000014:8k_2_02:58]
Additional Supplemental Financial Information - Constant Currency

[0001032975-26-000014:8k_2_02:59]
In addition, Logitech presents percentage sales growth in constant currency to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales.
