# LOGI notes — 0001032975-24-000046


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001032975-24-000046:notes:1]
[same as prior period, unchanged from 0001032975-24-000008:notes:1]

[0001032975-24-000046:notes:2]
Logitech International S.A, together with its consolidated subsidiaries ("Logitech" or the "Company"), designs software-enabled hardware solutions that help businesses thrive and bring people together when working, creating, gaming and streaming. As a point of connection between people and the digital world, the Company's mission is to

[0001032975-24-000046:notes:3]
extend human potential in work and play, in a way that is good for people and the planet.

[0001032975-24-000046:notes:4]
[same as prior period, unchanged from 0001032975-24-000008:notes:3]

[0001032975-24-000046:notes:5]
[same as prior period, unchanged from 0001032975-24-000008:notes:4]

[0001032975-24-000046:notes:6]
[same as prior period, unchanged from 0001032975-24-000008:notes:5]

[0001032975-24-000046:notes:7]
The condensed consolidated financial statements include the accounts of Logitech and its subsidiaries. All intercompany balances and transactions have been eliminated. The condensed consolidated financial statements are presented in accordance with accounting principles generally accepted in the United States ("U.S. GAAP") for interim financial information and therefore do not include all the information required by U.S. GAAP for complete financial statements. The condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended March 31, 2024, included in its Annual Report on Form 10-K filed with the Securities and Exchange Commission ("SEC") on May 16, 2024.

[0001032975-24-000046:notes:8]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three months ended June 30, 2024 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2025, or any future periods.

[0001032975-24-000046:notes:9]
[same as prior period, unchanged from 0001032975-24-000008:notes:22]

[0001032975-24-000046:notes:10]
There have been no material changes in the Company’s significant accounting policies during the three months ended June 30, 2024 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2024.

[0001032975-24-000046:notes:11]
[same as prior period, unchanged from 0001032975-24-000008:notes:24]

[0001032975-24-000046:notes:12]
The preparation of financial statements in conformity with U.S. GAAP requires management to make judgments, estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Significant estimates and assumptions made by management involve the fair value of goodwill and intangible assets acquired from business acquisitions, valuation of investment in privately held companies classified under Level 3 fair value hierarchy, pension obligations, accruals for customer incentives, cooperative marketing, and pricing programs and related breakage when appropriate, inventory valuation, share-based compensation expense, uncertain tax positions, and valuation allowances for deferred tax assets. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ materially from those estimates.

[0001032975-24-000046:notes:13]
[same as prior period, unchanged from 0001032975-24-000008:notes:26]

[0001032975-24-000046:notes:14]
[same as prior period, unchanged from 0001032975-24-000008:notes:27]

[0001032975-24-000046:notes:15]
The Company's business has continued to be impacted by macroeconomic and geopolitical conditions. These conditions include inflation, interest rate and foreign currency fluctuations, changes in fiscal policies, low economic growth in certain regions, and uncertainty in consumer and enterprise demand.

[0001032975-24-000046:notes:16]
The global and regional economic and political conditions have caused and may continue to cause volatility in demand for the Company's products as well as the cost of materials and logistics, and transportation delays, and as a result may impact the pricing of the Company's products, product availability and the Company's results of operations.

[0001032975-24-000046:notes:17]
[same as prior period, unchanged from 0001032975-24-000008:notes:30]

[0001032975-24-000046:notes:18]
In November 2023, the Financial Accounting Standard Board ("FASB") issued Accounting Standards Update ("ASU") 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures. ASU 2023-07 improves reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses that are regularly provided to the chief operating decision maker. In addition, ASU 2023-07 requires that all existing annual disclosures about segment profit or loss must be provided on an interim basis and clarifies that single reportable segment entities are subject to the disclosure requirement under Topic 280 in its entirety. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023 and interim periods within those fiscal years beginning after December 15, 2024. A public entity should apply ASU 2023-07 retrospectively to all prior periods presented in the financial statements. Early adoption is permitted. The Company is currently evaluating the impact of ASU 2023-07 on its consolidated financial statements and related disclosures. 
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures. ASU 2023-09 requires additional disclosures related to rate reconciliation, income taxes paid, and other disclosures. Under ASU 2023-09, for each annual period presented, public entities are required to (1) disclose specific categories in the tabular rate reconciliation and (2) provide additional information for reconciling items that meet a quantitative threshold. In addition, ASU 2023-09 requires all reporting entities to disclose on an annual basis the amount of income taxes paid disaggregated by federal, state, and foreign taxes as well as the amount of income taxes paid by individual jurisdiction. ASU 2023-09 is effective for public business entities for annual periods beginning after December 15, 2024 and can be applied on a prospective basis with an option to apply the standard retrospectively. Early adoption is permitted. The Company is currently evaluating the impact of ASU 2023-09 on its consolidated financial statements and related disclosures.


## us-gaap:EarningsPerShareTextBlock

[0001032975-24-000046:notes:19]
[same as prior period, unchanged from 0001032975-24-000008:notes:32]

[0001032975-24-000046:notes:20]
The following table summarizes the computations of basic and diluted net income per share for the three months ended June 30, 2024 and 2023 (in thousands, except per share amounts):

[0001032975-24-000046:notes:21]
|  |  | Three months ended June 30, |  |  |
|  |  | 2024 |  | 2023 |  |  |  |  |
| Net income |  | $ | 141,833 |  |  | $ | 62,727 |  |  |  |  |  |
| Shares used in net income per share computation: |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding - basic |  | 153,300 |  |  | 158,859 |  |  |  |  |  |
| Effect of potentially dilutive equivalent shares |  | 1,678 |  |  | 1,296 |  |  |  |  |  |
| Weighted average shares outstanding - diluted |  | 154,978 |  |  | 160,155 |  |  |  |  |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.93 |  |  | $ | 0.39 |  |  |  |  |  |
| Diluted |  | $ | 0.92 |  |  | $ | 0.39 |  |  |  |  |  |

[0001032975-24-000046:notes:22]
Share equivalents attributable to outstanding stock options and restricted stock units totaling 1.1 million and 2.0 million for the three months ended June 30, 2024 and 2023, respectively, were excluded from the calculation of diluted net income per share because their effect would have been anti-dilutive. A small number of performance-

[0001032975-24-000046:notes:23]
based restricted stock units were not included in the dilutive net income per share calculation because all necessary conditions had not been satisfied by the end of the respective period, and those shares were not issuable if the end of the reporting period were the end of the performance contingency period.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001032975-24-000046:notes:24]
[same as prior period, unchanged from 0001032975-24-000008:notes:36]

[0001032975-24-000046:notes:25]
[same as prior period, unchanged from 0001032975-24-000008:notes:37]

[0001032975-24-000046:notes:26]
As of June 30, 2024, the Company offers the 2006 Employee Share Purchase Plan (Non-U.S.), as amended and restated, the 1996 Employee Share Purchase Plan (U.S.), as amended and restated, and the 2006 Stock Incentive Plan, as amended and restated. Shares issued to employees as a result of purchases or exercises under these plans are generally issued from shares held in treasury stock.

[0001032975-24-000046:notes:27]
The following table summarizes the share-based compensation expense and total income tax benefit recognized for share-based awards for the three months ended June 30, 2024 and 2023 (in thousands):

[0001032975-24-000046:notes:28]
|  |  | Three months ended June 30, |  |  |
|  |  | 2024 |  | 2023 |  |  |  |  |
| Cost of goods sold |  | $ | 2,598 |  |  | $ | 1,415 |  |  |  |  |  |
| Marketing and selling |  | 11,851 |  |  | 10,483 |  |  |  |  |  |
| Research and development |  | 5,739 |  |  | 4,453 |  |  |  |  |  |
| General and administrative |  | 3,217 |  |  | 5,160 |  |  |  |  |  |
| Total share-based compensation expense |  | 23,405 |  |  | 21,511 |  |  |  |  |  |
| Income tax benefit |  | (7,602) |  |  | (5,318) |  |  |  |  |  |
| Total share-based compensation expense, net of income tax benefit |  | $ | 15,803 |  |  | $ | 16,193 |  |  |  |  |  |

[0001032975-24-000046:notes:29]
The income tax benefit in the respective periods primarily consisted of tax benefits related to the share-based compensation expense for the period and direct tax benefit realized.

[0001032975-24-000046:notes:30]
Share-based compensation costs capitalized as part of inventory were $2.5 million and $1.9 million for the three months ended June 30, 2024 and 2023, respectively.

[0001032975-24-000046:notes:31]
[same as prior period, unchanged from 0001032975-24-000008:notes:43]

[0001032975-24-000046:notes:32]
Certain of the Company’s subsidiaries sponsor defined benefit pension plans or non-retirement post-employment benefits covering substantially all of their employees. Benefits are provided based on employees’ years of service and earnings, or in accordance with applicable employee benefit regulations. The Company’s practice is to fund amounts sufficient to meet the requirements set forth in the applicable employee benefit and tax regulations. The costs of $1.7 million and $1.9 million recorded for the three months ended June 30, 2024 and 2023, respectively, were primarily related to service costs.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001032975-24-000046:notes:33]
[same as prior period, unchanged from 0001032975-24-000008:notes:45]

[0001032975-24-000046:notes:34]
[same as prior period, unchanged from 0001032975-24-000008:notes:46]

[0001032975-24-000046:notes:35]
The income tax provision for the three months ended June 30, 2024 was $25.6 million based on an effective income tax rate of 15.3% of pre-tax income. The income tax provision for the same period ended June 30, 2023 was $12.5 million based on an effective income tax rate of 16.7% of pre-tax income.

[0001032975-24-000046:notes:36]
The change in the effective income tax rate for the three months ended June 30, 2024 compared with the same period ended June 30, 2023 was primarily due to the change in the mix of income and losses in the various tax jurisdictions in which the Company operates, the favorable tax impacts from share-based compensation and Foreign-Derived Intangible Income.

[0001032975-24-000046:notes:37]
The Base Erosion and Profit Shifting Project (the “BEPS Project”) undertaken by the Organization for Economic Co-operation and Development (the "OECD") recommended changes to numerous long-standing tax principles, including a proposal to reallocate profits among tax jurisdictions in which companies do business (“Pillar One”) and establishing a minimum tax on global income (“Pillar Two”). Some jurisdictions, including Switzerland, where the Company operates are implementing Pillar Two laws to effectuate a 15% minimum tax. The minimum tax effective beginning in fiscal year 2025 for the Company, is treated as a current cost and does not have a material impact on the Company's effective tax rate. The OECD and participating countries continue to issue underlying rules and administrative guidance related to Pillar Two, and the Company continues to monitor the relevant developments.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001032975-24-000046:notes:38]
[same as prior period, unchanged from 0001032975-24-000008:notes:55]

[0001032975-24-000046:notes:39]
[same as prior period, unchanged from 0001032975-24-000008:notes:56]

[0001032975-24-000046:notes:40]
|  |  | June 30, 2024 |  | March 31, 2024 |
| Accounts receivable, net: |  |  |  |  |
| Accounts receivable |  | $ | 814,127 |  |  | $ | 744,836 |  |
| Allowance for sales returns |  | (12,212) |  |  | (10,180) |  |
| Allowance for cooperative marketing arrangements |  | (45,590) |  |  | (41,634) |  |
| Allowance for customer incentive programs |  | (67,324) |  |  | (60,027) |  |
| Allowance for pricing programs |  | (97,750) |  |  | (91,280) |  |
|  |  | $ | 591,251 |  |  | $ | 541,715 |  |
| Inventories: |  |  |  |  |
| Raw materials |  | $ | 54,113 |  |  | $ | 65,209 |  |
| Finished goods |  | 405,469 |  |  | 357,304 |  |
|  |  | $ | 459,582 |  |  | $ | 422,513 |  |
| Other current assets: |  |  |  |  |
| Value-added tax ("VAT") receivables |  | $ | 34,551 |  |  | $ | 41,172 |  |
| Prepaid expenses and other assets |  | 106,862 |  |  | 105,098 |  |
|  |  | $ | 141,413 |  |  | $ | 146,270 |  |
| Property, plant and equipment, net: |  |  |  |  |
| Property, plant and equipment |  | $ | 511,096 |  |  | $ | 503,882 |  |
| Less: accumulated depreciation and amortization |  | (397,831) |  |  | (387,293) |  |
|  |  | $ | 113,265 |  |  | $ | 116,589 |  |
| Other assets: |  |  |  |  |
| Deferred tax assets |  | $ | 215,504 |  |  | $ | 224,831 |  |
| Right-of-use assets |  | 61,846 |  |  | 61,163 |  |
| Investments for deferred compensation plan |  | 30,887 |  |  | 29,174 |  |
| Investments in privately held companies |  | 28,292 |  |  | 28,662 |  |
| Other assets |  | 7,003 |  |  | 6,364 |  |
|  |  | $ | 343,532 |  |  | $ | 350,194 |  |

[0001032975-24-000046:notes:41]
[same as prior period, unchanged from 0001032975-24-000008:notes:58]

[0001032975-24-000046:notes:42]
|  |  | June 30, 2024 |  | March 31, 2024 |
| Accrued and other current liabilities: |  |  |  |  |
| Accrued customer marketing, pricing and incentive programs |  | $ | 166,516 |  |  | $ | 170,371 |  |
| Accrued personnel expenses |  | 112,249 |  |  | 145,473 |  |
| Warranty liabilities |  | 30,476 |  |  | 30,270 |  |
| Accrued sales return liability |  | 29,920 |  |  | 30,098 |  |
| Accrued loss for inventory purchase commitments |  | 26,208 |  |  | 29,349 |  |
| Income taxes payable |  | 25,482 |  |  | 24,196 |  |
| VAT payable |  | 21,958 |  |  | 28,253 |  |
| Deferred revenue (1) |  | 21,127 |  |  | 19,262 |  |
| Operating lease liabilities |  | 15,009 |  |  | 15,107 |  |
| Other current liabilities |  | 137,235 |  |  | 144,883 |  |
|  |  | $ | 586,180 |  |  | $ | 637,262 |  |
| Other non-current liabilities: |  |  |  |  |
| Operating lease liabilities |  | $ | 62,886 |  |  | $ | 61,920 |  |
| Employee benefit plan obligations |  | 42,091 |  |  | 42,707 |  |
| Obligation for deferred compensation plan |  | 30,887 |  |  | 29,174 |  |
| Deferred revenue (1) |  | 25,883 |  |  | 21,097 |  |
| Warranty liabilities |  | 14,026 |  |  | 14,384 |  |
| Deferred tax liabilities |  | 708 |  |  | 705 |  |
| Other non-current liabilities |  | 2,640 |  |  | 2,603 |  |
|  |  | $ | 179,121 |  |  | $ | 172,590 |  |

[0001032975-24-000046:notes:43]
(1) Includes deferred revenue for post-contract customer support and other services.


## us-gaap:FairValueDisclosuresTextBlock

[0001032975-24-000046:notes:44]
[same as prior period, unchanged from 0001032975-24-000008:notes:60]

[0001032975-24-000046:notes:45]
[same as prior period, unchanged from 0001032975-24-000008:notes:61]

[0001032975-24-000046:notes:46]
[same as prior period, unchanged from 0001032975-24-000008:notes:62]

[0001032975-24-000046:notes:47]
[same as prior period, unchanged from 0001032975-24-000008:notes:63]

[0001032975-24-000046:notes:48]
[same as prior period, unchanged from 0001032975-24-000008:notes:64]

[0001032975-24-000046:notes:49]
[same as prior period, unchanged from 0001032975-24-000008:notes:65]

[0001032975-24-000046:notes:50]
|  |  | June 30, 2024 |  | March 31, 2024 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Level 1 |  | Level 2 |  | Level 3 |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 1,062,484 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,042,604 |  |  | $ | — |  |  | $ | — |  |
| Investments for deferred compensation plan included in other assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 144 |  |  | $ | — |  |  | $ | — |  |  | $ | 312 |  |  | $ | — |  |  | $ | — |  |
| Common stock |  | 627 |  |  | — |  |  | — |  |  | 573 |  |  | — |  |  | — |  |
| Money market funds |  | 8,664 |  |  | — |  |  | — |  |  | 8,129 |  |  | — |  |  | — |  |
| Mutual funds |  | 21,452 |  |  | — |  |  | — |  |  | 20,160 |  |  | — |  |  | — |  |
| Total investments for deferred compensation plan |  | $ | 30,887 |  |  | $ | — |  |  | $ | — |  |  | $ | 29,174 |  |  | $ | — |  |  | $ | — |  |
| Currency derivative assetsincluded in other current assets |  | $ | — |  |  | $ | 1,546 |  |  | $ | — |  |  | $ | — |  |  | $ | 913 |  |  | $ | — |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Contingent consideration included in accrued and other current liabilities |  | $ | — |  |  | $ | — |  |  | $ | 1,222 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,215 |  |
| Currency derivative liabilitiesincluded in accrued and other current liabilities |  | $ | — |  |  | $ | 68 |  |  | $ | — |  |  | $ | — |  |  | $ | 573 |  |  | $ | — |  |

[0001032975-24-000046:notes:51]
[same as prior period, unchanged from 0001032975-24-000008:notes:72]

[0001032975-24-000046:notes:52]
The marketable securities for the Company's deferred compensation plan were recorded at a fair value of $30.9 million and $29.2 million, as of June 30, 2024 and March 31, 2024, respectively, based on quoted market prices. Quoted market prices are observable inputs that are classified as Level 1 within the fair value hierarchy. Unrealized gains (losses) related to marketable securities for the three months ended June 30, 2024 and 2023 were not material and were included in other income (expense), net, and corresponding changes in the deferred compensation liability were included in operating expenses and cost of goods sold, in the Company's condensed consolidated statements of operations.

[0001032975-24-000046:notes:53]
[same as prior period, unchanged from 0001032975-24-000008:notes:74]

[0001032975-24-000046:notes:54]
The Company has certain non-marketable investments included in other assets that are accounted for as equity method investments, with a carrying value of $18.8 million and $18.0 million as of June 30, 2024 and March 31, 2024, respectively. Gains (losses) related to equity method investments for the three months ended June 30, 2024 and 2023 were not material and are included in other income (expense), net, in the Company's condensed consolidated statements of operations. There was no impairment of equity method investments during the three months ended June 30, 2024 and 2023.

[0001032975-24-000046:notes:55]
[same as prior period, unchanged from 0001032975-24-000008:notes:77]

[0001032975-24-000046:notes:56]
[same as prior period, unchanged from 0001032975-24-000008:notes:78]

[0001032975-24-000046:notes:57]
The Company has certain equity investments without readily determinable fair values due to the absence of quoted market prices, the inherent lack of liquidity, and the fact that inputs used to measure fair value are unobservable and require management's judgment. When certain events or circumstances indicate that impairment may exist, the Company revalues the investments using various assumptions, including the financial metrics and ratios of comparable public companies. The carrying value is also adjusted for observable price changes with the same or similar security from the same issuer. The amount of these equity investments without readily determinable fair value included in other assets was $8.9 million and $10.1 million as of June 30, 2024 and March 31, 2024, respectively. The impairment charges related to these equity investments were not material during three months

[0001032975-24-000046:notes:58]
ended June 30, 2024. There were no impairment charges related to these equity investments during the three months ended June 30, 2023.

[0001032975-24-000046:notes:59]
During the three months ended June 30, 2023, the Company recorded an impairment loss, before tax, of $9.6 million as a result of the write-off of a note receivable which has been deemed no longer recoverable. This note receivable was previously obtained in conjunction with an exchange transaction related to the Company's investment in a privately held company. The impairment loss is included in other income (expense), net, in the Company's condensed consolidated statement of operations for the three months ended June 30, 2023.

[0001032975-24-000046:notes:60]
Non-Financial Assets
Goodwill, intangible assets, and property, plant and equipment, are not required to be measured at fair value on a recurring basis. However, if the Company is required to evaluate these non-financial assets for impairment, whether due to certain triggering events or because of the required annual impairment test, and a resulting impairment is recorded to reduce the carrying value to the fair value, the non-financial assets are measured at fair value during such period. There was no impairment of non-financial assets during the three months ended June 30, 2024 and 2023.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001032975-24-000046:notes:61]
[same as prior period, unchanged from 0001032975-24-000008:notes:82]

[0001032975-24-000046:notes:62]
Under certain agreements with the respective counterparties to the Company’s derivative contracts, subject to applicable requirements, the Company is allowed to net settle transactions of the same type with a single net amount payable by one party to the other. However, the Company presents its derivative assets and derivative liabilities on a gross basis in other current assets and accrued and other current liabilities, respectively, on the condensed consolidated balance sheets as of June 30, 2024 and March 31, 2024. See Note 6 for the fair values of the Company’s derivative instruments as of June 30, 2024 and March 31, 2024.

[0001032975-24-000046:notes:63]
[same as prior period, unchanged from 0001032975-24-000008:notes:84]

[0001032975-24-000046:notes:64]
[same as prior period, unchanged from 0001032975-24-000008:notes:85]

[0001032975-24-000046:notes:65]
The notional amounts of foreign currency exchange forward contracts outstanding related to forecasted inventory purchases were $119.6 million and $90.5 million as of June 30, 2024 and March 31, 2024, respectively. The Company had $2.0 million of net gain related to its cash flow hedges included in accumulated other comprehensive loss as of June 30, 2024, which will be reclassified into earnings within the next twelve months.

[0001032975-24-000046:notes:66]
The following table presents the amounts of gain (loss) on the Company’s derivative instruments designated as hedging instruments for the three months ended June 30, 2024 and 2023 and their locations on its condensed consolidated statements of operations and condensed consolidated statements of comprehensive income (in thousands):

[0001032975-24-000046:notes:67]
|  |  | Three months ended June 30, |
|  |  | Amount of Gain (Loss)Deferred as a Component of AccumulatedOther Comprehensive Loss |  | Amount of Loss (Gain)Reclassified from Accumulated Other Comprehensive Loss to Costs of Goods Sold |  |  |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |  |  |  |  |
| Cash flow hedges |  | $ | 1,582 |  |  | $ | (704) |  |  | $ | (733) |  |  | $ | 2,986 |  |  |  |  |  |

[0001032975-24-000046:notes:68]
The Company presents the earnings impact from forward points in the same line item that is used to present the earnings impact of the hedged item, i.e., cost of goods sold, for hedging forecasted inventory purchases and such amount is not material for all periods presented.

[0001032975-24-000046:notes:69]
[same as prior period, unchanged from 0001032975-24-000008:notes:90]

[0001032975-24-000046:notes:70]
The Company also enters into foreign currency exchange forward and swap contracts to reduce the short-term effects of currency exchange rate fluctuations on certain receivables or payables denominated in currencies other than the functional currencies of its subsidiaries. These contracts generally mature within approximately one month. The primary risk managed by using forward and swap contracts is the currency exchange rate risk. The gains or losses on these contracts are not material and included in other income (expense), net, in the condensed consolidated statements of operations based on the changes in fair value. The notional amounts of these contracts outstanding as of June 30, 2024 and March 31, 2024 were $93.8 million and $79.4 million, respectively.

[0001032975-24-000046:notes:71]
[same as prior period, unchanged from 0001032975-24-000008:notes:92]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001032975-24-000046:notes:72]
Goodwill and Other Intangible Assets
The Company conducts its impairment analysis of goodwill annually at December 31 or more frequently if changes in facts and circumstances indicate that it is more likely than not that the fair value of the Company’s reporting unit may be less than its carrying amount. There have been no triggering events identified affecting the valuation of goodwill and intangible assets during the three months ended June 30, 2024 and 2023.

[0001032975-24-000046:notes:73]
[same as prior period, unchanged from 0001032975-24-000008:notes:94]

[0001032975-24-000046:notes:74]
| As of March 31, 2024 |  | $ | 461,978 |  |
| Effects of foreign currency translation |  | 25 |  |
| As of June 30, 2024 |  | $ | 462,003 |  |

[0001032975-24-000046:notes:75]
[same as prior period, unchanged from 0001032975-24-000008:notes:96]

[0001032975-24-000046:notes:76]
|  |  | June 30, 2024 |  | March 31, 2024 |
|  |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |
| Trademarks and trade names |  | $ | 32,390 |  |  | $ | (26,473) |  |  | $ | 5,917 |  |  | $ | 32,390 |  |  | $ | (25,739) |  |  | $ | 6,651 |  |
| Developed technology |  | 107,421 |  |  | (89,311) |  |  | 18,110 |  |  | 107,421 |  |  | (86,855) |  |  | 20,566 |  |
| Customer contracts/relationships |  | 69,087 |  |  | (52,957) |  |  | 16,130 |  |  | 69,087 |  |  | (51,061) |  |  | 18,026 |  |
| Effects of foreign currency translation |  | (1,048) |  |  | 381 |  |  | (667) |  |  | (1,019) |  |  | 379 |  |  | (640) |  |
| Total |  | $ | 207,850 |  |  | $ | (168,360) |  |  | $ | 39,490 |  |  | $ | 207,879 |  |  | $ | (163,276) |  |  | $ | 44,603 |  |


## us-gaap:DebtDisclosureTextBlock

[0001032975-24-000046:notes:77]
Financing Arrangements

[0001032975-24-000046:notes:78]
The Company had several uncommitted, unsecured bank lines of credit and letters of credit aggregating $171.8 million and $172.5 million as of June 30, 2024 and March 31, 2024, respectively. There are no financial covenants under the lines of credit with which the Company must comply. There was no borrowing outstanding under the lines of credit as of June 30, 2024 or March 31, 2024. As of June 30, 2024 and March 31, 2024, the Company had outstanding bank guarantees of $13.5 million and $14.3 million, respectively.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001032975-24-000046:notes:79]
Commitments and Contingencies

[0001032975-24-000046:notes:80]
Product Warranties

[0001032975-24-000046:notes:81]
Changes in the Company’s warranty liabilities for the three months ended June 30, 2024 and 2023 were as follows (in thousands):

[0001032975-24-000046:notes:82]
|  | Three months ended June 30, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Beginning of the period | $ | 44,654 |  |  | $ | 40,886 |  |  |  |  |  |
| Provision | 10,186 |  |  | 9,092 |  |  |  |  |  |
| Settlements | (10,038) |  |  | (9,918) |  |  |  |  |  |
| Effects of foreign currency translation | (300) |  |  | (175) |  |  |  |  |  |
| End of the period | $ | 44,502 |  |  | $ | 39,885 |  |  |  |  |  |

[0001032975-24-000046:notes:83]
Indemnifications

[0001032975-24-000046:notes:84]
The Company indemnifies certain suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of June 30, 2024, no material amounts have been accrued for indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

[0001032975-24-000046:notes:85]
The Company also indemnifies its current and former directors and certain current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. The Company is unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not capped, the obligations are conditional in nature, and the facts and circumstances involved in any situation that might arise are variable.

[0001032975-24-000046:notes:86]
Legal Proceedings

[0001032975-24-000046:notes:87]
From time to time the Company is involved in claims and legal proceedings that arise in the ordinary course of its business. The Company is currently subject to several such claims and legal proceedings. The Company intends to vigorously defend against them. Management periodically assesses the Company’s liabilities and contingencies in connection with these matters based upon the latest information available. The Company follows ASC ("Accounting Standards Codification") 450, Contingencies, in determining the accounting and disclosure for these contingencies. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows and results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company's defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company's business, financial condition, cash flows and results of operations in a particular period. Any claims or proceedings against the Company can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain a necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company's business.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001032975-24-000046:notes:88]
[same as prior period, unchanged from 0001032975-24-000008:notes:109]

[0001032975-24-000046:notes:89]
In June 2023, the Company's Board of Directors approved a three-year share repurchase program, which allows the Company to use up to $1.0 billion to repurchase its shares. The 2023 share repurchase program enables the Company to repurchase shares for cancellation, as well as to support equity incentive plans or potential acquisitions. The Swiss Takeover Board approved the 2023 share repurchase program in July 2023 and the program became effective on July 28, 2023. During the three months ended June 30, 2024, the Company repurchased 1.4 million shares for an aggregate cost of $132.1 million under the 2023 share repurchase program

[0001032975-24-000046:notes:90]
for cancellation, of which $20.8 million of the aggregate cost was not paid yet as of June 30, 2024. As of June 30, 2024, $503.8 million was available for repurchase under the 2023 share repurchase program.

[0001032975-24-000046:notes:91]
During the three months ended June 30, 2023, the Company repurchased 1.6 million shares for an aggregate cost of $95.1 million under the previous share repurchase program. This program was initially approved by the Company's Board of Directors in May 2020, to purchase Logitech shares to support equity incentive plans or potential acquisitions, and expired on July 27, 2023.

[0001032975-24-000046:notes:92]
Swiss law limits a company’s ability to hold or repurchase its own shares. The aggregate par value of all shares held in treasury by the Company and its subsidiaries may not exceed 10% of the share capital of the Company, which for the Company corresponds to approximately 17.3 million registered shares. This limitation does not apply to shares repurchased for cancellation, due to the Board of Directors’ authority under the Company’s capital band set forth in the Company’s Articles of Incorporation to cancel shares up to a limit of 10% of the Company's current share capital. As of June 30, 2024, the Company had a total of 20.1 million shares held in treasury stock, which includes 5.6 million shares that have been repurchased for cancellation and 14.5 million shares that have been purchased to support equity incentive plans or potential acquisitions.

[0001032975-24-000046:notes:93]
[same as prior period, unchanged from 0001032975-24-000008:notes:115]

[0001032975-24-000046:notes:94]
Accumulated Other Comprehensive Loss

[0001032975-24-000046:notes:95]
The accumulated other comprehensive loss was as follows (in thousands):

[0001032975-24-000046:notes:96]
|  |  | Currency Translation Adjustment |  | Defined Benefit Plans |  | Deferred Hedging Gains |  | Total |
| March 31, 2024 |  | $ | (103,947) |  |  | $ | (8,395) |  |  | $ | 1,140 |  |  | $ | (111,202) |  |
| Other comprehensive income (loss) |  | (5,219) |  |  | (200) |  |  | 849 |  |  | (4,570) |  |
| June 30, 2024 |  | $ | (109,166) |  |  | $ | (8,595) |  |  | $ | 1,989 |  |  | $ | (115,772) |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001032975-24-000046:notes:97]
[same as prior period, unchanged from 0001032975-24-000008:notes:122]

[0001032975-24-000046:notes:98]
The Company operates in a single operating segment that encompasses the design, manufacturing and marketing of peripherals for gaming, personal computers ("PCs"), tablets, video conferencing, and other digital platforms. Operating performance measures are provided directly to the Company's Chief Executive Officer ("CEO"), who is considered to be the Company’s Chief Operating Decision Maker. The CEO periodically reviews information such as sales and adjusted operating income (loss) to make business decisions. These operating performance measures do not include restructuring charges, net, share-based compensation expense, amortization and impairment of intangible assets, acquisition-related costs, and change in fair value of contingent consideration from business acquisitions.

[0001032975-24-000046:notes:99]
Sales by product category for the three months ended June 30, 2024 and 2023 were as follows (in thousands):

[0001032975-24-000046:notes:100]
|  |  | Three months ended June 30, |  |  |
|  |  | 2024 |  | 2023 |  |  |  |  |
| Gaming (1) |  | $ | 309,475 |  |  | $ | 266,429 |  |  |  |  |  |
| Keyboards & Combos |  | 215,333 |  |  | 180,855 |  |  |  |  |  |
| Pointing Devices |  | 189,946 |  |  | 174,454 |  |  |  |  |  |
| Video Collaboration |  | 147,042 |  |  | 139,346 |  |  |  |  |  |
| Webcams |  | 72,904 |  |  | 75,200 |  |  |  |  |  |
| Tablet Accessories |  | 78,539 |  |  | 70,336 |  |  |  |  |  |
| Headsets |  | 44,236 |  |  | 36,850 |  |  |  |  |  |
| Other (2) |  | 30,742 |  |  | 31,029 |  |  |  |  |  |
| Total Sales |  | $ | 1,088,217 |  |  | $ | 974,499 |  |  |  |  |  |

[0001032975-24-000046:notes:101]
[same as prior period, unchanged from 0001032975-24-000008:notes:127]

[0001032975-24-000046:notes:102]
[same as prior period, unchanged from 0001032975-24-000008:notes:128]

[0001032975-24-000046:notes:103]
Sales by geographic region (based on the customers’ locations) for the three months ended June 30, 2024 and 2023 were as follows (in thousands):

[0001032975-24-000046:notes:104]
|  |  | Three months ended June 30, |  |  |
|  |  | 2024 |  | 2023 |  |  |  |  |
| Americas |  | $ | 485,289 |  |  | $ | 445,168 |  |  |  |  |  |
| EMEA |  | 309,817 |  |  | 258,878 |  |  |  |  |  |
| Asia Pacific |  | 293,111 |  |  | 270,453 |  |  |  |  |  |
| Total Sales |  | $ | 1,088,217 |  |  | $ | 974,499 |  |  |  |  |  |

[0001032975-24-000046:notes:105]
Revenue from sales to customers in the United States, China and Germany each represented 10% or more of the total consolidated sales for each of the periods presented herein. No other countries represented 10% or more of the Company’s total consolidated sales for the periods presented herein.

[0001032975-24-000046:notes:106]
Switzerland, the Company’s country of domicile, represented 2% of the Company's total consolidated sales for each of the three months ended June 30, 2024 and 2023.

[0001032975-24-000046:notes:107]
Three customers of the Company each represented 10% or more of the total consolidated gross sales for each of the three months ended June 30, 2024 and 2023.

[0001032975-24-000046:notes:108]
[same as prior period, unchanged from 0001032975-24-000008:notes:134]

[0001032975-24-000046:notes:109]
|  |  | June 30, 2024 |  | March 31, 2024 |
| Americas |  | $ | 65,661 |  |  | $ | 67,762 |  |
| EMEA |  | 30,919 |  |  | 30,819 |  |
| Asia Pacific |  | 57,690 |  |  | 58,901 |  |
| Total |  | $ | 154,270 |  |  | $ | 157,482 |  |

[0001032975-24-000046:notes:110]
Property, plant and equipment, net (excluding software) and right-of-use assets in the United States, China, and Ireland were $64.3 million, $40.9 million and $15.7 million, respectively, as of June 30, 2024, and $66.5 million, $41.2 million, and $16.2 million, respectively, as of March 31, 2024. No other countries represented more than 10% of the Company’s total consolidated property, plant and equipment, net (excluding software) and right-of-use assets as of June 30, 2024 or March 31, 2024. 
Property, plant and equipment, net (excluding software) and right-of-use assets in Switzerland, the Company’s country of domicile, were $7.7 million and $9.0 million as of June 30, 2024 and March 31, 2024, respectively.
