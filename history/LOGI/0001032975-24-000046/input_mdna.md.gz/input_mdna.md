# LOGI MD&A — 0001032975-24-000046


## mdna

[0001032975-24-000046:mdna:1]
[same as prior period, unchanged from 0001032975-24-000008:mdna:1]

[0001032975-24-000046:mdna:2]
[same as prior period, unchanged from 0001032975-24-000008:mdna:2]

[0001032975-24-000046:mdna:3]
•Our business strategy and investment priorities in relation to competitive offerings and evolving consumer demand trends affecting our products and markets, current and future worldwide geopolitical, economic and capital market conditions, including fluctuations in currency exchange rates, changes in fiscal policies, inflation, economic downturns, and disruptions in global logistics;

[0001032975-24-000046:mdna:4]
•Our expectations regarding any restructuring efforts, including the timing thereof;

[0001032975-24-000046:mdna:5]
[same as prior period, unchanged from 0001032975-24-000008:mdna:5]

[0001032975-24-000046:mdna:6]
[same as prior period, unchanged from 0001032975-24-000008:mdna:6]

[0001032975-24-000046:mdna:7]
•The scope, nature or impact of acquisition, strategic alliance, and divestiture activities;

[0001032975-24-000046:mdna:8]
[same as prior period, unchanged from 0001032975-24-000008:mdna:8]

[0001032975-24-000046:mdna:9]
[same as prior period, unchanged from 0001032975-24-000008:mdna:9]

[0001032975-24-000046:mdna:10]
•Our expectations regarding our potential indemnification obligations, and the outcome of pending or future legal proceedings and tax audits;

[0001032975-24-000046:mdna:11]
•Our business development, product development and innovation, and their impact on future operating results and anticipated operating costs for fiscal year 2025 and beyond;

[0001032975-24-000046:mdna:12]
[same as prior period, unchanged from 0001032975-24-000008:mdna:12]

[0001032975-24-000046:mdna:13]
[same as prior period, unchanged from 0001032975-24-000008:mdna:13]

[0001032975-24-000046:mdna:14]
[same as prior period, unchanged from 0001032975-24-000008:mdna:14]

[0001032975-24-000046:mdna:15]
[same as prior period, unchanged from 0001032975-24-000008:mdna:15]

[0001032975-24-000046:mdna:16]
[same as prior period, unchanged from 0001032975-24-000008:mdna:16]

[0001032975-24-000046:mdna:17]
[same as prior period, unchanged from 0001032975-24-000008:mdna:17]

[0001032975-24-000046:mdna:18]
19

[0001032975-24-000046:mdna:19]
Company Overview

[0001032975-24-000046:mdna:20]
Logitech designs software-enabled hardware solutions that help businesses thrive and bring people together when working, creating, gaming and streaming. As a point of connection between people and the digital world, our mission is to extend human potential in work and play, in a way that is good for people and the planet. We sell these products through a number of brands, including Logitech, Logitech G and others.

[0001032975-24-000046:mdna:21]
Our diverse portfolio includes: Gaming, Keyboards & Combos, Pointing Devices, Video Collaboration, Webcams, Tablet Accessories, and Headsets. These products are all classified under a single operating segment: Peripherals (see Note 12 to our condensed consolidated financial statements).

[0001032975-24-000046:mdna:22]
We sell our products to a broad network of international customers in the Americas, Europe, the Middle East and Africa (“EMEA”) and Asia Pacific. This includes direct sales to retailers, e-tailers, and end consumers through our e-commerce platform, and indirect sales to end customers through distributors.

[0001032975-24-000046:mdna:23]
[same as prior period, unchanged from 0001032975-24-000008:mdna:21]

[0001032975-24-000046:mdna:24]
[same as prior period, unchanged from 0001032975-24-000008:mdna:22]

[0001032975-24-000046:mdna:25]
Our business has continued to be impacted by macroeconomic and geopolitical conditions. These conditions include inflation, interest rate and foreign currency fluctuations, changes in fiscal policies, low economic growth in certain regions, and uncertainty in consumer and enterprise demand.

[0001032975-24-000046:mdna:26]
The global and regional economic and political conditions have caused and may continue to cause volatility in demand for our products as well as cost of materials and logistics, and transportation delays, and as a result may impact the pricing of our products, product availability and our results of operations.

[0001032975-24-000046:mdna:27]
[same as prior period, unchanged from 0001032975-24-000008:mdna:25]

[0001032975-24-000046:mdna:28]
[same as prior period, unchanged from 0001032975-24-000008:mdna:26]

[0001032975-24-000046:mdna:29]
Several long-term secular-trends offer long-term structural growth opportunities across Logitech’s product portfolio. We design, create and sell products that benefit from these secular trends which include the following:

[0001032975-24-000046:mdna:30]
•Hybrid work: Hybrid work provides an opportunity to equip multiple workspaces including in the office and other places of work, as well as at home and away from home. Hybrid work also provides an opportunity for increased enterprise and consumer adoption of video conferencing. Our video collaboration products are compatible with a variety of video conference platforms, including Zoom, Microsoft Teams and Google Meet.

[0001032975-24-000046:mdna:31]
•Gaming: The ongoing growth and evolution of gaming creates an opportunity for us to provide more tools to a wider community of gamers. In particular, social gaming continues to gain popularity through online gaming, multi-platform experiences and esports.

[0001032975-24-000046:mdna:32]
•AI: AI has reshaped expectations for productivity improvements, product innovation and technology ecosystem evolution. While we have used AI solutions and machine learning to enhance the features of different products in our portfolio, AI offers additional growth opportunities and risks as we work to integrate our capabilities with our ecosystem partners.

[0001032975-24-000046:mdna:33]
•Climate change: Climate change affects everyone. We already consider sustainability as part of our product design and in other areas and intend to continue to do so in the future.

[0001032975-24-000046:mdna:34]
•The importance of trust: With our well-established Logitech brand, consumer-centric design philosophy, and commitment to high privacy and security standards, we strive to deliver trusted user experiences.

[0001032975-24-000046:mdna:35]
While we believe we will further benefit from these secular trends, we have experienced and will continue to experience challenges that impact our business and financial results. These challenges include (i) the current macroeconomic environment, including interest rate fluctuations, inflation, foreign exchange movements, changes in fiscal policies and low economic growth in certain regions, (ii) the uncertainty with overall consumer and enterprise demand, (iii) the uncertainty with enterprise strategy for office space utilization and related timing of enterprise investments in infrastructure and technology, and (iv) the timing of further development of our B2B go-to-market capabilities.

[0001032975-24-000046:mdna:36]
20

[0001032975-24-000046:mdna:37]
We expect these challenges to continue in the near-term. We have taken steps to mitigate the impact of these challenges, including but not limited to: (i) maintaining discipline in our operating expenses, (ii) managing inventory levels to align with demand, (iii) continued investment in our B2B capabilities, and (iv) release of new products to increase the value proposition of our portfolio.

[0001032975-24-000046:mdna:38]
[same as prior period, unchanged from 0001032975-24-000008:mdna:32]

[0001032975-24-000046:mdna:39]
[same as prior period, unchanged from 0001032975-24-000008:mdna:33]

[0001032975-24-000046:mdna:40]
[same as prior period, unchanged from 0001032975-24-000008:mdna:34]

[0001032975-24-000046:mdna:41]
[same as prior period, unchanged from 0001032975-24-000008:mdna:35]

[0001032975-24-000046:mdna:42]
Our total sales for the three months ended June 30, 2024 increased 12%, compared to the three months ended June 30, 2023, primarily due to an increase in sales for Gaming, Keyboards & Combos and Pointing Devices, driven by improved demand.

[0001032975-24-000046:mdna:43]
Sales for the three months ended June 30, 2024 increased 20%, 9%, and 8% in EMEA, the Americas, and Asia Pacific regions, respectively, compared to the three months ended June 30, 2023.

[0001032975-24-000046:mdna:44]
Gross margin was 42.8% for the three months ended June 30, 2024 and increased by 430 basis points, compared to the three months ended June 30, 2023, primarily driven by lower product costs, as well as lower promotional spend.

[0001032975-24-000046:mdna:45]
Operating expenses for the three months ended June 30, 2024 were $312.8 million, or 28.7% of sales, compared to $297.2 million, or 30.5% of sales, for the three months ended June 30, 2023. The increase in operating expense was primarily driven by an increase in marketing and advertising spend.

[0001032975-24-000046:mdna:46]
We had an income tax provision of $25.6 million and $12.5 million for the three months ended June 30, 2024 and June 30, 2023, respectively. The change in the income tax provision for the three months ended June 30, 2024 compared to the three months ended June 30, 2023 was primarily due to the mix of income and losses in the various tax jurisdictions in which we operate, the favorable tax impacts from share-based compensation and Foreign-Derived Intangible Income.

[0001032975-24-000046:mdna:47]
Net income for the three months ended June 30, 2024 was $141.8 million compared to $62.7 million for the three months ended June 30, 2023.

[0001032975-24-000046:mdna:48]
[same as prior period, unchanged from 0001032975-24-000008:mdna:42]

[0001032975-24-000046:mdna:49]
[same as prior period, unchanged from 0001032975-24-000008:mdna:43]

[0001032975-24-000046:mdna:50]
We consider an accounting estimate critical if it (i) requires management to make judgments and estimates about matters that are inherently uncertain and (ii) is important to an understanding of our financial condition and operating results.

[0001032975-24-000046:mdna:51]
[same as prior period, unchanged from 0001032975-24-000008:mdna:45]

[0001032975-24-000046:mdna:52]
[same as prior period, unchanged from 0001032975-24-000008:mdna:46]

[0001032975-24-000046:mdna:53]
There have been no material changes in our critical accounting estimates during the three months ended June 30, 2024 compared with the critical accounting estimates disclosed in Management's Discussion and Analysis of Financial Condition and Results of Operations included in our Annual Report on Form 10-K for the fiscal year ended March 31, 2024.

[0001032975-24-000046:mdna:54]
[same as prior period, unchanged from 0001032975-24-000008:mdna:48]

[0001032975-24-000046:mdna:55]
[same as prior period, unchanged from 0001032975-24-000008:mdna:49]

[0001032975-24-000046:mdna:56]
[same as prior period, unchanged from 0001032975-24-000008:mdna:50]

[0001032975-24-000046:mdna:57]
[same as prior period, unchanged from 0001032975-24-000008:mdna:51]

[0001032975-24-000046:mdna:58]
[same as prior period, unchanged from 0001032975-24-000008:mdna:52]

[0001032975-24-000046:mdna:59]
[same as prior period, unchanged from 0001032975-24-000008:mdna:53]

[0001032975-24-000046:mdna:60]
[same as prior period, unchanged from 0001032975-24-000008:mdna:54]

[0001032975-24-000046:mdna:61]
[same as prior period, unchanged from 0001032975-24-000008:mdna:55]

[0001032975-24-000046:mdna:62]
[same as prior period, unchanged from 0001032975-24-000008:mdna:56]

[0001032975-24-000046:mdna:63]
Our sales for the three months ended June 30, 2024 increased 12%, compared to the three months ended June 30, 2023, primarily due to an increase in sales for Gaming, Keyboards & Combos and Pointing Devices, driven by improved demand. If currency exchange rates had been constant in the three months ended June 30, 2024 and 2023, our sales growth rate in constant currency would have been 13%.

[0001032975-24-000046:mdna:64]
[same as prior period, unchanged from 0001032975-24-000008:mdna:58]

[0001032975-24-000046:mdna:65]
Although our financial results are reported in U.S. Dollars, a portion of our sales was generated in currencies other than the U.S. Dollar, such as the Euro, Chinese Renminbi, Australian Dollar, Canadian Dollar, Japanese Yen, Pound Sterling and New Taiwan Dollar. During the three months ended June 30, 2024, approximately 49% of our sales were denominated in currencies other than the U.S. Dollar.

[0001032975-24-000046:mdna:66]
[same as prior period, unchanged from 0001032975-24-000008:mdna:60]

[0001032975-24-000046:mdna:67]
The following table presents the change in sales by region for the three months ended June 30, 2024, compared with the three months ended June 30, 2023:

[0001032975-24-000046:mdna:68]
|  |  | Sales Growth Rate |  | Constant DollarSales Growth Rate |
| Americas |  | 9 | % |  |  |  | 9 | % |  |  |
| EMEA |  | 20 | % |  |  |  | 20 | % |  |  |
| Asia Pacific |  | 8 | % |  |  |  | 13 | % |  |  |

[0001032975-24-000046:mdna:69]
[same as prior period, unchanged from 0001032975-24-000008:mdna:63]

[0001032975-24-000046:mdna:70]
The increase in sales in the Americas region for the three-month period presented above was primarily driven by an increase in sales for Keyboards & Combos, Gaming, and Pointing Devices.

[0001032975-24-000046:mdna:71]
[same as prior period, unchanged from 0001032975-24-000008:mdna:65]

[0001032975-24-000046:mdna:72]
The increase in sales in our EMEA region for the three-month period presented above was primarily driven by an increase in sales for Keyboards & Combos, Gaming, and Pointing Devices.

[0001032975-24-000046:mdna:73]
[same as prior period, unchanged from 0001032975-24-000008:mdna:67]

[0001032975-24-000046:mdna:74]
The increase in sales in our Asia Pacific region for the three-month period presented above was primarily driven by an increase in sales for Gaming and Keyboards & Combos.

[0001032975-24-000046:mdna:75]
[same as prior period, unchanged from 0001032975-24-000008:mdna:69]

[0001032975-24-000046:mdna:76]
Sales by product category for the three months ended June 30, 2024 and 2023 were as follows (dollars in thousands):

[0001032975-24-000046:mdna:77]
|  |  | Three months ended June 30, |  |  |
|  |  | 2024 |  | 2023 |  | Change |  |  |  |  |  |  |
| Gaming (1) |  | $ | 309,475 |  |  | $ | 266,429 |  |  | 16 | % |  |  |  |  |  |  |
| Keyboards & Combos |  | 215,333 |  |  | 180,855 |  |  | 19 |  |  |  |  |  |  |  |
| Pointing Devices |  | 189,946 |  |  | 174,454 |  |  | 9 |  |  |  |  |  |  |  |
| Video Collaboration |  | 147,042 |  |  | 139,346 |  |  | 6 |  |  |  |  |  |  |  |
| Webcams |  | 72,904 |  |  | 75,200 |  |  | (3) |  |  |  |  |  |  |  |
| Tablet Accessories |  | 78,539 |  |  | 70,336 |  |  | 12 |  |  |  |  |  |  |  |
| Headsets |  | 44,236 |  |  | 36,850 |  |  | 20 |  |  |  |  |  |  |  |
| Other (2) |  | 30,742 |  |  | 31,029 |  |  | (1) |  |  |  |  |  |  |  |
| Total Sales |  | $ | 1,088,217 |  |  | $ | 974,499 |  |  | 12 | % |  |  |  |  |  |  |

[0001032975-24-000046:mdna:78]
[same as prior period, unchanged from 0001032975-24-000008:mdna:73]

[0001032975-24-000046:mdna:79]
[same as prior period, unchanged from 0001032975-24-000008:mdna:74]

[0001032975-24-000046:mdna:80]
[same as prior period, unchanged from 0001032975-24-000008:mdna:75]

[0001032975-24-000046:mdna:81]
[same as prior period, unchanged from 0001032975-24-000008:mdna:76]

[0001032975-24-000046:mdna:82]
Sales of Gaming increased 16% for the three months ended June 30, 2024, compared to the three months ended June 30, 2023, primarily driven by an increase in sales of gaming mice and gaming steering wheels.

[0001032975-24-000046:mdna:83]
[same as prior period, unchanged from 0001032975-24-000008:mdna:78]

[0001032975-24-000046:mdna:84]
[same as prior period, unchanged from 0001032975-24-000008:mdna:79]

[0001032975-24-000046:mdna:85]
Sales of Keyboards & Combos increased 19% for the three months ended June 30, 2024, compared to the three months ended June 30, 2023, primarily driven by an increase in sales of cordless combo products.

[0001032975-24-000046:mdna:86]
[same as prior period, unchanged from 0001032975-24-000008:mdna:81]

[0001032975-24-000046:mdna:87]
Our Pointing Devices category includes PC- and Mac-related mice including trackballs and presentation tools.

[0001032975-24-000046:mdna:88]
Sales of Pointing Devices increased 9% for the three months ended June 30, 2024, compared to the three months ended June 30, 2023, primarily driven by an increase in sales of cordless mice.

[0001032975-24-000046:mdna:89]
[same as prior period, unchanged from 0001032975-24-000008:mdna:84]

[0001032975-24-000046:mdna:90]
[same as prior period, unchanged from 0001032975-24-000008:mdna:85]

[0001032975-24-000046:mdna:91]
Sales of Video Collaboration increased 6% for the three months ended June 30, 2024, compared to the three months ended June 30, 2023, primarily due to an increase in sales of conference room cameras and docks.

[0001032975-24-000046:mdna:92]
[same as prior period, unchanged from 0001032975-24-000008:mdna:87]

[0001032975-24-000046:mdna:93]
[same as prior period, unchanged from 0001032975-24-000008:mdna:88]

[0001032975-24-000046:mdna:94]
Sales of Webcams decreased 3% for the three months ended June 30, 2024, compared to the three months ended June 30, 2023, primarily driven by a decrease in sales of our VC webcams, partially offset by an increase of sales of our PC-based webcams.

[0001032975-24-000046:mdna:95]
[same as prior period, unchanged from 0001032975-24-000008:mdna:90]

[0001032975-24-000046:mdna:96]
Our Tablet Accessories category primarily includes tablet keyboards.

[0001032975-24-000046:mdna:97]
Sales of Tablet Accessories increased 12% for the three months ended June 30, 2024, compared to the three months ended June 30, 2023, primarily driven by an increase in sales of Rugged Combo 4 Touch and Rugged Combo 4, partially offset by a decrease in sales of Rugged Combo 3 Touch. Sales of Tablet Accessories for the three months ended June 30, 2024, compared to the three months ended June 30, 2023, benefited from strong demand from the education sector.

[0001032975-24-000046:mdna:98]
[same as prior period, unchanged from 0001032975-24-000008:mdna:93]

[0001032975-24-000046:mdna:99]
[same as prior period, unchanged from 0001032975-24-000008:mdna:94]

[0001032975-24-000046:mdna:100]
Sales of Headsets increased 20% for the three months ended June 30, 2024, compared to the three months ended June 30, 2023, primarily driven by an increase in sales of corded and cordless PC headsets and VC headsets.

[0001032975-24-000046:mdna:101]
[same as prior period, unchanged from 0001032975-24-000008:mdna:96]

[0001032975-24-000046:mdna:102]
[same as prior period, unchanged from 0001032975-24-000008:mdna:97]

[0001032975-24-000046:mdna:103]
Sales in Other category remained flat for the three months ended June 30, 2024, compared to the three months ended June 30, 2023.

[0001032975-24-000046:mdna:104]
24

[0001032975-24-000046:mdna:105]
[same as prior period, unchanged from 0001032975-24-000008:mdna:99]

[0001032975-24-000046:mdna:106]
Gross profit for the three months ended June 30, 2024 and 2023 was as follows (dollars in thousands):

[0001032975-24-000046:mdna:107]
|  |  | Three months ended June 30, |  |  |
|  |  | 2024 |  | 2023 |  | Change |  |  |  |  |  |  |
| Net sales |  | $ | 1,088,217 |  | $ | 974,499 |  | 12 | % |  |  |  |  |  |  |
| Gross profit |  | $ | 466,258 |  | $ | 375,642 |  | 24 | % |  |  |  |  |  |  |
| Gross margin |  | 42.8 | % |  | 38.5 | % |  |  |  |  |  |  |  |  |

[0001032975-24-000046:mdna:108]
[same as prior period, unchanged from 0001032975-24-000008:mdna:102]

[0001032975-24-000046:mdna:109]
Gross margin was 42.8% for the three months ended June 30, 2024 and increased by 430 basis points compared to the three months ended June 30, 2023. The gross margin increase was primarily driven by lower product costs, as well as lower promotional spend.

[0001032975-24-000046:mdna:110]
[same as prior period, unchanged from 0001032975-24-000008:mdna:104]

[0001032975-24-000046:mdna:111]
Operating expenses for the three months ended June 30, 2024 and 2023 were as follows (dollars in thousands):

[0001032975-24-000046:mdna:112]
|  |  | Three months ended June 30, |  |  |  |
|  |  | 2024 |  | 2023 |  |  |  |  |  |
| Marketing and selling |  | $ | 196,905 |  |  | $ | 179,185 |  |  |  |  |  |  |
| % of sales |  | 18.1 | % |  | 18.4 | % |  |  |  |  |  |
| Research and development |  | 75,307 |  |  | 70,559 |  |  |  |  |  |  |
| % of sales |  | 6.9 | % |  | 7.2 | % |  |  |  |  |  |
| General and administrative |  | 37,458 |  |  | 41,297 |  |  |  |  |  |  |
| % of sales |  | 3.5 | % |  | 4.2 | % |  |  |  |  |  |
| Amortization of intangible assets and acquisition-related costs |  | 2,703 |  |  | 2,685 |  |  |  |  |  |  |
| % of sales |  | 0.2 | % |  | 0.3 | % |  |  |  |  |  |
| Restructuring charges, net |  | 386 |  |  | 3,511 |  |  |  |  |  |  |
| % of sales |  | — | % |  | 0.4 | % |  |  |  |  |  |
| Total operating expenses |  | $ | 312,759 |  |  | $ | 297,237 |  |  |  |  |  |  |
| % of sales |  | 28.7 | % |  | 30.5 | % |  |  |  |  |  |

[0001032975-24-000046:mdna:113]
The increase in total operating expenses for the three months ended June 30, 2024, compared to the three months ended June 30, 2023, was primarily driven by an increase in marketing and selling expenses.

[0001032975-24-000046:mdna:114]
[same as prior period, unchanged from 0001032975-24-000008:mdna:108]

[0001032975-24-000046:mdna:115]
[same as prior period, unchanged from 0001032975-24-000008:mdna:109]

[0001032975-24-000046:mdna:116]
During the three months ended June 30, 2024, marketing and selling expenses increased $17.7 million, compared to the three months ended June 30, 2023, primarily driven by an increase in third-party marketing and advertising spend as well as higher performance-based compensation expense.

[0001032975-24-000046:mdna:117]
[same as prior period, unchanged from 0001032975-24-000008:mdna:111]

[0001032975-24-000046:mdna:118]
[same as prior period, unchanged from 0001032975-24-000008:mdna:112]

[0001032975-24-000046:mdna:119]
During the three months ended June 30, 2024, research and development expenses increased $4.7 million, compared to the three months ended June 30, 2023, primarily driven by higher performance-based compensation expense.

[0001032975-24-000046:mdna:120]
[same as prior period, unchanged from 0001032975-24-000008:mdna:115]

[0001032975-24-000046:mdna:121]
[same as prior period, unchanged from 0001032975-24-000008:mdna:116]

[0001032975-24-000046:mdna:122]
During the three months ended June 30, 2024, general and administrative expenses decreased $3.8 million, compared to the three months ended June 30, 2023, primarily driven by an accrued litigation cost recorded in the three months ended June 30, 2023.

[0001032975-24-000046:mdna:123]
[same as prior period, unchanged from 0001032975-24-000008:mdna:118]

[0001032975-24-000046:mdna:124]
[same as prior period, unchanged from 0001032975-24-000008:mdna:119]

[0001032975-24-000046:mdna:125]
During the three months ended June 30, 2024, amortization of intangible assets and acquisition-related costs remained flat, compared to the three months ended June 30, 2023.

[0001032975-24-000046:mdna:126]
[same as prior period, unchanged from 0001032975-24-000008:mdna:121]

[0001032975-24-000046:mdna:127]
The restructuring charges, net for the three months ended June 30, 2024 and 2023, were related to costs incurred as a result of our restructuring plan initiated during fiscal year 2023. These restructuring activities were substantially completed during fiscal year 2024.

[0001032975-24-000046:mdna:128]
[same as prior period, unchanged from 0001032975-24-000008:mdna:124]

[0001032975-24-000046:mdna:129]
Interest income for the three months ended June 30, 2024 and 2023 was as follows (in thousands):

[0001032975-24-000046:mdna:130]
|  |  | Three months ended June 30, |  |  |
|  |  | 2024 |  | 2023 |  |  |  |  |
| Interest Income |  | $ | 15,790 |  |  | $ | 9,826 |  |  |  |  |  |

[0001032975-24-000046:mdna:131]
We invest in highly liquid instruments with an original maturity of three months or less at the date of purchase, which are classified as cash equivalents. During the three months ended June 30, 2024, interest income increased $6.0 million, compared to the three months ended June 30, 2023, primarily driven by an increase in the balance of our investments that are classified as cash equivalents as well as an increase in interest rates.

[0001032975-24-000046:mdna:132]
[same as prior period, unchanged from 0001032975-24-000008:mdna:128]

[0001032975-24-000046:mdna:133]
Other income (expense), net for the three months ended June 30, 2024 and 2023 was as follows (in thousands):

[0001032975-24-000046:mdna:134]
|  |  | Three months ended June 30, |  |  |
|  |  | 2024 |  | 2023 |  |  |  |  |
| Investment gain related to the deferred compensation plan |  | $ | 447 |  |  | $ | 1,024 |  |  |  |  |  |
| Currency exchange loss, net |  | (2,318) |  |  | (3,086) |  |  |  |  |  |
| Loss on investments, net |  | (1,186) |  |  | (11,823) |  |  |  |  |  |
| Non-service cost net pension income and other |  | 1,159 |  |  | 913 |  |  |  |  |  |
| Total |  | $ | (1,898) |  |  | $ | (12,972) |  |  |  |  |  |

[0001032975-24-000046:mdna:135]
Investment gain (loss) related to the deferred compensation plan represents earnings, gains, and losses on marketable securities related to a deferred compensation plan offered by one of our subsidiaries. The decrease in investment gain for three months ended June 30, 2024, compared to the three months ended June 30, 2023, primarily relates to the change in market performance of the underlying securities.

[0001032975-24-000046:mdna:136]
Currency exchange loss, net, relates to balances denominated in currencies other than the functional currency in our subsidiaries, as well as to the sale of currencies, and gains or losses recognized on currency exchange forward contracts. We do not speculate in currency positions, but we are alert to opportunities to maximize currency exchange gains and minimize currency exchange losses. The loss for the three months ended June 30, 2024 was primarily due to fluctuations in currency exchange rates of the Mexican Peso and Japanese Yen against the U.S. Dollar. The loss for the three months ended June 30, 2023 was primarily due to the weakening of the Japanese Yen against the U.S. Dollar.

[0001032975-24-000046:mdna:137]
Loss on investments, net, includes unrealized gain (loss) from the change in fair value of investments, gain (loss) on equity-method investments and impairment of investments during the periods presented, as applicable. The loss on investments, net, for the three months ended June 30, 2024 was not material. The loss on investments, net, for the three months ended June 30, 2023 was primarily due to an impairment loss, as a result of the write-off of a note receivable which has been deemed no longer recoverable. This note receivable was previously obtained in conjunction with an exchange transaction related to our investment in a privately held company. See Note 6 to our condensed consolidated financial statements for more information.

[0001032975-24-000046:mdna:138]
[same as prior period, unchanged from 0001032975-24-000008:mdna:134]

[0001032975-24-000046:mdna:139]
The provision for income taxes and effective income tax rates for the three months ended June 30, 2024 and 2023 were as follows (dollars in thousands):

[0001032975-24-000046:mdna:140]
|  |  | Three months ended June 30, |  |  |
|  |  | 2024 |  | 2023 |  |  |  |  |
| Provision for income taxes |  | $ | 25,558 |  |  | $ | 12,532 |  |  |  |  |  |
| Effective income tax rate |  | 15.3 | % |  | 16.7 | % |  |  |  |  |

[0001032975-24-000046:mdna:141]
The change in the effective income tax rate for the three months ended June 30, 2024 compared with the three months ended June 30, 2023 was primarily due to the change in the mix of income and losses in the various tax jurisdictions in which we operate, the favorable tax impacts from share-based compensation and Foreign-Derived Intangible Income.

[0001032975-24-000046:mdna:142]
The BEPS Project undertaken by the OECD recommended changes to numerous long-standing tax principles, including a proposal to reallocate profits among tax jurisdictions in which companies do business (“Pillar One”) and establishing a minimum tax on global income (“Pillar Two”). Some jurisdictions, including Switzerland, where we operate are implementing Pillar Two laws to effectuate a 15% minimum tax. The minimum tax effective beginning in fiscal year 2025 for the Company, is treated as a current cost and does not have a material impact on the Company's effective tax rate. The OECD and participating countries continue to issue underlying rules and administrative guidance related to Pillar Two, and we continue to monitor the relevant developments.

[0001032975-24-000046:mdna:143]
We file Swiss and foreign tax returns. We received final tax assessments in Switzerland through fiscal year 2019. For other material foreign jurisdictions such as the United States, we are generally not subject to tax examinations for years prior to fiscal year 2020 and calendar year 2020, respectively. In the United States, the federal and state tax agencies have the authority to examine periods prior to fiscal year 2020, to the extent allowed by law, where tax attributes were generated, carried forward, and being utilized in subsequent years. We are under examination in foreign tax jurisdictions. If the examinations are resolved unfavorably, there is a possibility that they may have a material negative impact on our results of operations.

[0001032975-24-000046:mdna:144]
[same as prior period, unchanged from 0001032975-24-000008:mdna:141]

[0001032975-24-000046:mdna:145]
[same as prior period, unchanged from 0001032975-24-000008:mdna:142]

[0001032975-24-000046:mdna:146]
As of June 30, 2024, we had cash and cash equivalents of $1,534.4 million, compared with $1,520.8 million as of March 31, 2024. Our cash and cash equivalents consist of bank demand deposits, short-term time deposits, and U.S. Treasury securities, of which 71% is held in Switzerland and 15% is held in Germany. We do not expect to incur any material adverse tax impact except for what has already been recognized, or to be significantly inhibited by any country in which we do business, from the repatriation of funds to Switzerland, our country of domicile.

[0001032975-24-000046:mdna:147]
As of June 30, 2024, our working capital was $1,586.1 million, compared to $1,545.5 million as of March 31, 2024. The increase was primarily driven by a decrease in accrued and other liabilities and increases in accounts receivable, net, and inventories, partially offset by an increase in accounts payable.

[0001032975-24-000046:mdna:148]
We had several uncommitted, unsecured bank lines of credit and letters of credit aggregating $171.8 million as of June 30, 2024. There are no financial covenants under these lines of credit with which we must comply. There was no borrowing outstanding under the lines of credit as of June 30, 2024. As of June 30, 2024, we had outstanding bank guarantees of $13.5 million.

[0001032975-24-000046:mdna:149]
The following tables present selected financial information and statistics as of and for the three months ended June 30, 2024 and 2023 (dollars in thousands):

[0001032975-24-000046:mdna:150]
|  |  | As of June 30, |  |
|  |  | 2024 |  | 2023 |  |
| Accounts receivable, net |  | $ | 591,251 |  |  | $ | 562,602 |  |  |
| Accounts payable |  | $ | 554,301 |  |  | $ | 386,599 |  |  |
| Inventories |  | $ | 459,582 |  |  | $ | 572,344 |  |  |

[0001032975-24-000046:mdna:151]
|  |  | Three months ended June 30, |  |
|  |  | 2024 |  | 2023 |  |
| Days sales in accounts receivable (“DSO”) (Days)(1) |  | 49 |  |  | 52 |  |  |
| Days accounts payable outstanding (“DPO”) (Days)(2) |  | 80 |  |  | 58 |  |  |
| Inventory turnover (“ITO”) (x)(3) |  | 5.4 |  |  | 4.2 |  |  |

[0001032975-24-000046:mdna:152]
[same as prior period, unchanged from 0001032975-24-000008:mdna:149]

[0001032975-24-000046:mdna:153]
[same as prior period, unchanged from 0001032975-24-000008:mdna:150]

[0001032975-24-000046:mdna:154]
(3) ITO is determined using ending inventories as of the most recent quarter-end and annualized cost of goods sold (based on cost of goods sold for the most recent quarter).

[0001032975-24-000046:mdna:155]
DSO for the three months ended June 30, 2024 decreased by 3 days to 49 days, compared to 52 days for the three months ended June 30, 2023, primarily due to higher sales driven by improved demand.

[0001032975-24-000046:mdna:156]
DPO for the three months ended June 30, 2024 increased by 22 days to 80 days, compared to 58 days for the three months ended June 30, 2023, primarily due to higher inventory purchases to replenish certain products during the first quarter of fiscal year 2025.

[0001032975-24-000046:mdna:157]
ITO for the three months ended June 30, 2024 increased by 1.2 to 5.4, compared to 4.2 for the three months ended June 30, 2023, primarily due to lower inventory balance as of June 30, 2024, compared to June 30, 2023, driven by our efforts to manage inventory level.

[0001032975-24-000046:mdna:158]
[same as prior period, unchanged from 0001032975-24-000008:mdna:155]

[0001032975-24-000046:mdna:159]
[same as prior period, unchanged from 0001032975-24-000008:mdna:156]

[0001032975-24-000046:mdna:160]
|  |  | Three months ended June 30, |
|  |  | 2024 |  | 2023 |
| Net cash provided by operating activities |  | $ | 176,029 |  |  | $ | 239,795 |  |
| Net cash used in investing activities |  | (15,359) |  |  | (17,530) |  |
| Net cash used in financing activities |  | (145,134) |  |  | (117,159) |  |
| Effect of exchange rate changes on cash and cash equivalents |  | (1,998) |  |  | (3,043) |  |
| Net increase in cash and cash equivalents |  | $ | 13,538 |  |  | $ | 102,063 |  |

[0001032975-24-000046:mdna:161]
For the three months ended June 30, 2024, net cash provided by operating activities was $176.0 million resulting from net income of $141.8 million, a favorable impact from adding back non-cash expenses totaling $55.8 million, partially offset by an unfavorable net change in operating assets and liabilities of $21.6 million. Non-cash adjustments were primarily related to share-based compensation expenses, and depreciation and amortization. The increase in accounts receivable, net, was primarily driven by higher sales. The increases in inventories and accounts payable were due to higher inventory purchases to replenish certain products. The decrease in accrued and other liabilities was primarily driven by payment of the fiscal year 2024 annual bonus.

[0001032975-24-000046:mdna:162]
For the three months ended June 30, 2024, net cash used in investing activities was $15.4 million, primarily resulting from $14.6 million of purchases of property, plant, and equipment.

[0001032975-24-000046:mdna:163]
For the three months ended June 30, 2024, net cash used in financing activities was $145.1 million, primarily resulting from payment for repurchases of our registered shares of $130.9 million.

[0001032975-24-000046:mdna:164]
For the three months ended June 30, 2024, the effect of exchange rate changes on cash and cash equivalents is not material.

[0001032975-24-000046:mdna:165]
[same as prior period, unchanged from 0001032975-24-000008:mdna:162]

[0001032975-24-000046:mdna:166]
[same as prior period, unchanged from 0001032975-24-000008:mdna:163]

[0001032975-24-000046:mdna:167]
In May 2024, the Board of Directors recommended that we pay cash dividends for fiscal year 2024 of CHF 1.16 per share (approximately $1.28 per share based on the exchange rate on March 31, 2024). Based on our shares outstanding, net of treasury shares, as of March 31, 2024 (153,863,262 shares), this would result in an aggregate gross dividend of approximately CHF 178.5 million (approximately $197.2 million based on the exchange rate on March 31, 2024). In fiscal year 2024, we paid a cash dividend of CHF 1.06 per share, or CHF 169.1 million (U.S. Dollar amount of $182.3 million based on the exchange rate on the date of payment) out of fiscal year 2023 retained earnings.

[0001032975-24-000046:mdna:168]
In June 2023, our Board of Directors approved a three-year share repurchase program, which allows us to use up to $1.0 billion to repurchase our shares. The 2023 share repurchase program enables us to repurchase shares for cancellation, as well as to support equity incentive plans or potential acquisitions. The Swiss Takeover Board approved the 2023 share repurchase program in July 2023 and the program became effective on July 28, 2023. During the three months ended June 30, 2024, we repurchased 1.4 million shares for an aggregate cost of $132.1 million, under the 2023 share repurchase program for cancellation, of which $20.8 million of the aggregate

[0001032975-24-000046:mdna:169]
cost was not paid yet as of June 30, 2024. As of June 30, 2024, $503.8 million was available for repurchase under the 2023 share repurchase program.

[0001032975-24-000046:mdna:170]
Swiss law limits a company’s ability to hold or repurchase its own shares. The aggregate par value of all shares held in treasury by us and our subsidiaries may not exceed 10% of our share capital, which corresponds to approximately 17.3 million registered shares. This limitation does not apply to shares repurchased for cancellation, due to the Board of Directors' authority under the capital band set forth in the Company's Articles of Incorporation to cancel shares up to a limit of 10% of our current share capital. As of June 30, 2024, we had a total of 20.1 million shares held in treasury stock, which includes 5.6 million shares that have been repurchased for cancellation and 14.5 million shares that have been purchased to support equity incentive plans or potential acquisitions.

[0001032975-24-000046:mdna:171]
Although we enter into trading plans for systematic repurchases (e.g., 10b5-1 trading plans) from time to time, our 2023 share repurchase program provides us with the opportunity to make opportunistic repurchases during periods of favorable market conditions and is expected to remain in effect for a period of three years through July 27, 2026. To the extent that the shares are repurchased to support equity incentive plans or potential acquisitions, the shares are repurchased on the ordinary trading line of Swiss Exchange ("SIX") and/or the Nasdaq Global Select Market ("Nasdaq"). Shares repurchased for cancellation purposes are repurchased via a second trading line on SIX. Opportunistic purchases may be started or stopped at any time without prior notice depending on market conditions and other factors.

[0001032975-24-000046:mdna:172]
[same as prior period, unchanged from 0001032975-24-000008:mdna:170]

[0001032975-24-000046:mdna:173]
[same as prior period, unchanged from 0001032975-24-000008:mdna:171]

[0001032975-24-000046:mdna:174]
We lease facilities under operating leases, certain of which require us to pay property taxes, insurance and maintenance costs. Operating leases for facilities are generally renewable at our option and usually include escalation clauses linked to inflation. There have been no material changes to our contractual obligations as previously disclosed in our Annual Report on Form 10-K for the year ended March 31, 2024. The remaining terms of our non-cancelable operating leases expire in various years through 2034.

[0001032975-24-000046:mdna:175]
[same as prior period, unchanged from 0001032975-24-000008:mdna:173]

[0001032975-24-000046:mdna:176]
As of June 30, 2024, we had non-cancelable purchase commitments of $390.4 million for inventory purchases made in the normal course of business from original design manufacturers, contract manufacturers and other suppliers, the majority of which are expected to be fulfilled within the next 12 months. We recorded a liability for firm, non-cancelable, and unhedged inventory purchase commitments in excess of anticipated demand or net realizable value consistent with our valuation of excess and obsolete inventory. As of June 30, 2024, the liability for these purchase commitments was $26.2 million and is recorded in accrued and other current liabilities in the condensed consolidated balance sheet.

[0001032975-24-000046:mdna:177]
We have firm purchase commitments of $12.9 million for capital expenditures primarily related to commitments for tooling and equipment for new and existing products. We expect to continue making capital expenditures in the future to support product development activities and ongoing and expanded operations. Although open purchase commitments are considered enforceable and legally binding, the terms generally allow us to reschedule or adjust our requirements based on business needs prior to delivery of goods or performance of services.

[0001032975-24-000046:mdna:178]
[same as prior period, unchanged from 0001032975-24-000008:mdna:176]

[0001032975-24-000046:mdna:179]
For further detail about our contractual obligations and commitments, refer to our Annual Report on Form 10-K for the fiscal year ended March 31, 2024.

[0001032975-24-000046:mdna:180]
[same as prior period, unchanged from 0001032975-24-000008:mdna:178]

[0001032975-24-000046:mdna:181]
We indemnify certain suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of June 30, 2024, no material amounts have been accrued for indemnification provisions. We do not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under our indemnification arrangements.

[0001032975-24-000046:mdna:182]
We also indemnify our current and former directors and certain current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. We are unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not capped, the obligations are conditional in nature, and the facts and circumstances involved in any situation that might arise are variable.

[0001032975-24-000046:mdna:183]
Legal Proceedings

[0001032975-24-000046:mdna:184]
From time to time, we are involved in claims and legal proceedings that arise in the ordinary course of our business. For more information about Legal Proceedings, see Part II Item 1 Legal Proceedings of this quarterly report on Form 10-Q for the period ended June 30, 2024.
