# LOGI 8-K — 0001032975-24-000042 filed 2024-07-23

## item codes, every 8-K on or before 2024-07-25

- 2024-07-23 0001032975-24-000042 — 2.02, 9.01
- 2024-07-01 0001032975-24-000033 — 5.02, 8.01, 9.01
- 2024-06-13 0001032975-24-000030 — 5.02, 9.01
- 2024-04-30 0001032975-24-000015 — 2.02, 9.01
- 2024-03-18 0001032975-24-000012 — 5.02, 7.01, 9.01
- 2024-01-23 0001032975-24-000004 — 2.02, 9.01
- 2023-10-30 0001032975-23-000082 — 5.02, 9.01
- 2023-10-24 0001032975-23-000075 — 2.02, 9.01
- 2023-09-15 0001032975-23-000072 — 5.07, 8.01
- 2023-07-25 0001032975-23-000050 — 2.02, 9.01
- 2023-06-30 0001032975-23-000037 — 5.02 — amendment, the index does not say of what
- 2023-06-30 0001032975-23-000036 — 5.02
- 2023-06-13 0001032975-23-000030 — 5.02, 7.01, 9.01
- 2023-05-02 0001032975-23-000015 — 2.02, 9.01
- 2023-01-30 0001032975-23-000010 — 5.02, 9.01
- 2023-01-24 0001032975-23-000004 — 2.02, 5.02, 9.01
- 2023-01-12 0001628280-23-000934 — 2.02, 9.01
- 2022-10-25 0001628280-22-026927 — 2.02, 5.02, 9.01
- 2022-09-16 0001628280-22-025080 — 5.07, 8.01
- 2022-07-26 0001032975-22-000027 — 2.02, 9.01
- 2022-06-29 0001032975-22-000018 — 5.02
- 2022-05-03 0001032975-22-000008 — 2.02, 9.01
- 2022-01-25 0001032975-22-000003 — 2.02, 9.01
- 2021-10-26 0001032975-21-000043 — 2.02, 9.01
- 2021-09-10 0001032975-21-000040 — 5.07, 8.01
- 2021-07-27 0001032975-21-000029 — 2.02, 9.01
- 2021-04-29 0001032975-21-000012 — 2.02, 9.01
- 2021-01-19 0001032975-21-000004 — 2.02, 9.01
- 2020-10-20 0001032975-20-000045 — 2.02, 9.01
- 2020-09-11 0001032975-20-000042 — 5.07, 8.01
- 2020-07-21 0001032975-20-000029 — 2.02, 9.01
- 2020-07-01 0001032975-20-000023 — 5.02, 8.01
- 2020-05-12 0001032975-20-000011 — 2.02, 9.01
- 2020-03-30 0001032975-20-000009 — 5.02
- 2020-01-21 0001032975-20-000002 — 2.02, 9.01
- 2019-10-22 0001032975-19-000071 — 9.01
- 2019-09-26 0001032975-19-000068 — 1.01, 7.01, 9.01
- 2019-09-06 0001032975-19-000063 — 5.07, 8.01
- 2019-07-23 0001032975-19-000046 — 2.02, 9.01
- 2019-07-23 0001032975-19-000045 — 5.02, 9.01
- 2019-07-02 0001032975-19-000036 — 5.02
- 2019-06-25 0001032975-19-000034 — 5.02
- 2019-05-03 0001032975-19-000021 — 5.02 — amendment, the index does not say of what
- 2019-04-30 0001032975-19-000017 — 2.02, 5.02, 9.01
- 2019-03-28 0001032975-19-000013 — 5.02
- 2019-01-22 0001032975-19-000004 — 2.02, 9.01
- 2018-10-23 0001032975-18-000044 — 2.02, 9.01
- 2018-09-07 0001032975-18-000040 — 5.07, 8.01
- 2018-07-31 0001032975-18-000035 — 1.01, 2.02, 2.05, 7.01, 9.01
- 2018-06-27 0001032975-18-000020 — 5.02
- 2018-05-03 0001032975-18-000013 — 2.02, 5.02, 9.01
- 2018-01-23 0001032975-18-000005 — 2.02, 9.01
- 2017-10-24 0001032975-17-000043 — 2.02, 9.01
- 2017-09-18 0001032975-17-000040 — 5.07, 8.01
- 2017-07-25 0001032975-17-000028 — 2.02, 9.01
- 2017-07-12 0001032975-17-000022 — 1.01
- 2017-04-26 0001032975-17-000012 — 2.02, 9.01
- 2017-01-25 0001032975-17-000002 — 2.02, 9.01
- 2016-10-26 0001032975-16-000103 — 2.02, 9.01
- 2016-09-13 0001032975-16-000101 — 5.07, 8.01
- 2016-07-28 0001032975-16-000092 — 2.02, 9.01
- 2016-06-30 0001032975-16-000087 — 5.02
- 2016-04-28 0001032975-16-000077 — 2.02, 9.01
- 2016-04-14 0001032975-16-000073 — 1.01, 7.01, 9.01
- 2016-01-21 0001032975-16-000064 — 2.02, 9.01
- 2016-01-04 0001032975-16-000061 — 1.01, 2.01, 9.01
- 2015-12-23 0001032975-15-000059 — 5.02
- 2015-10-22 0001032975-15-000047 — 2.02, 9.01
- 2015-09-11 0001032975-15-000044 — 5.07, 8.01
- 2015-07-24 0001032975-15-000034 — 2.05 — amendment of 0001032975-15-000030
- 2015-07-23 0001032975-15-000030 — 2.02, 9.01
- 2015-06-25 0001032975-15-000025 — 5.02
- 2015-05-14 0001032975-15-000011 — 8.01, 9.01
- 2015-04-23 0001032975-15-000008 — 2.02, 2.05
- 2015-01-22 0001628280-15-000191 — 2.02, 8.01
- 2014-12-23 0001193125-14-450908 — 5.02, 5.07, 8.01
- 2014-11-25 0001193125-14-425233 — 3.01
- 2014-11-13 0001193125-14-411303 — 4.01, 9.01
- 2014-10-23 0001104659-14-073164 — 2.02, 9.01
- 2014-09-04 0001193125-14-331214 — 4.02, 9.01
- 2014-08-18 0001193125-14-313346 — 3.01, 9.01
- 2014-07-24 0001104659-14-053065 — 2.02, 9.01
- 2014-06-05 0001193125-14-226177 — 3.01, 9.01
- 2014-05-22 0001193125-14-208777 — 8.01, 9.01
- 2014-04-24 0001104659-14-029650 — 2.02, 9.01
- 2014-01-23 0001104659-14-003619 — 2.02, 9.01
- 2013-10-24 0001104659-13-077404 — 2.02, 9.01
- 2013-09-09 0001193125-13-361441 — 5.02, 5.07, 8.01, 9.01
- 2013-09-06 0001193125-13-359930 — 5.02, 9.01
- 2013-08-02 0001193125-13-317343 — 5.02
- 2013-07-25 0001104659-13-056372 — 2.02, 9.01
- 2013-06-28 0001193125-13-277394 — 5.02, 9.01
- 2013-06-20 0001193125-13-265914 — 8.01, 9.01
- 2013-04-25 0001104659-13-032570 — 2.02, 9.01
- 2013-04-17 0001193125-13-158923 — 5.02, 9.01
- 2013-03-01 0001193125-13-085804 — 2.05
- 2013-01-24 0001104659-13-004214 — 2.02, 9.01
- 2013-01-02 0001193125-13-000058 — 5.02
- 2012-10-25 0001104659-12-070966 — 2.02, 9.01
- 2012-09-11 0001193125-12-388070 — 5.02, 5.07, 8.01, 9.01
- 2012-08-22 0001193125-12-364167 — 5.02, 8.01, 9.01
- 2012-07-26 0001104659-12-051084 — 2.02, 9.01
- 2012-06-08 0001193125-12-264132 — 2.05, 9.01 — amendment, the index does not say of what
- 2012-04-26 0001193125-12-183657 — 5.02, 9.01
- 2012-04-26 0001104659-12-028470 — 2.02, 2.05, 9.01
- 2012-03-15 0001193125-12-115954 — 5.02, 9.01
- 2012-01-26 0001104659-12-004014 — 2.02, 9.01
- 2012-01-04 0001193125-12-002212 — 1.01, 2.03, 9.01
- 2011-10-27 0001104659-11-058150 — 2.02, 9.01
- 2011-09-12 0001193125-11-245931 — 5.07
- 2011-07-28 0001193125-11-200929 — 5.02, 9.01
- 2011-07-28 0001193125-11-199704 — 2.02, 9.01
- 2011-04-28 0001193125-11-112669 — 2.02, 9.01
- 2011-03-24 0001193125-11-076483 — 5.02, 9.01
- 2011-01-27 0001032975-11-000003 — 9.01
- 2010-10-28 0001032975-10-000032 — 9.01
- 2010-09-13 0001032975-10-000022 — 5.07
- 2010-07-29 0001032975-10-000010 — 2.02, 9.01
- 2010-06-10 0001193125-10-136877 — 5.02, 9.01
- 2010-05-03 0001193125-10-104337 — 5.02
- 2010-04-29 0001032975-10-000008 — 2.02, 9.01
- 2010-02-19 0001032975-10-000006 — 9.01 — amendment of 0001193125-09-252416
- 2010-01-21 0001032975-10-000002 — 2.02, 9.01
- 2009-12-14 0001193125-09-252416 — 2.01, 9.01
- 2009-11-17 0001032975-09-000023 — 1.01
- 2009-10-22 0001032975-09-000018 — 9.01
- 2009-09-22 0001193125-09-195545 — 5.02, 9.01
- 2009-09-03 0001032975-09-000013 — 8.01
- 2009-07-23 0001140361-09-016802 — 2.02, 9.01
- 2009-06-01 0001193125-09-122550 — 5.02
- 2009-04-23 0001193125-09-085054 — 2.02, 9.01
- 2009-04-02 0001193125-09-071272 — 5.02, 9.01
- 2009-01-20 0001193125-09-008454 — 2.05 — amendment of 0001193125-09-002609
- 2009-01-20 0001193125-09-007902 — 2.02, 9.01
- 2009-01-07 0001193125-09-002609 — 2.05, 9.01
- 2009-01-07 0001193125-09-002370 — 5.02, 9.01
- 2008-12-09 0001193125-08-250543 — 5.02, 9.01
- 2008-10-21 0001193125-08-213212 — 2.02, 9.01
- 2008-07-22 0001193125-08-154721 — 2.02, 9.01
- 2008-06-24 0001193125-08-139163 — 5.03, 9.01
- 2008-05-13 0001193125-08-113263 — 5.02, 9.01
- 2008-04-22 0001193125-08-086176 — 2.02, 9.01

## late-filing notifications on or before 2024-07-25

- 2015-06-02 0001032975-15-000020 — NT 10-K, for the period ended 2015-03-31
- 2014-11-06 0001193125-14-401306 — NT 10-Q, for the period ended 2014-09-30
- 2014-07-24 0001193125-14-277575 — NT 10-Q, for the period ended 2014-06-30
- 2014-05-22 0001193125-14-208712 — NT 10-K, for the period ended 2014-03-31
- 2009-08-06 0001032975-09-000006 — NT 10-Q, for the period ended 2009-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001032975-24-000042:8k_2_02:1]
EX-99.1
2
exhibit991q1fy25.htm
EX-99.1

[0001032975-24-000042:8k_2_02:2]
Document

[0001032975-24-000042:8k_2_02:3]
Exhibit 99.1

[0001032975-24-000042:8k_2_02:4]
Editorial Contacts:

[0001032975-24-000042:8k_2_02:5]
Nate Melihercik, Head of Global Investor Relations - ir@logitech.com

[0001032975-24-000042:8k_2_02:6]
Nicole Kenyon, Head of Global Corporate and Internal Communications - nkenyon@logitech.com (USA)

[0001032975-24-000042:8k_2_02:7]
Ben Starkie, Corporate Communications - +41 (0) 79-292-3499, bstarkie1@logitech.com (Europe)

[0001032975-24-000042:8k_2_02:8]
Logitech Announces Q1 Fiscal Year 2025 Results

[0001032975-24-000042:8k_2_02:9]
Net Sales Grow 12%; Company Raises FY 2025 Outlook

[0001032975-24-000042:8k_2_02:10]
LAUSANNE, Switzerland, July 23, 2024 and SAN JOSE, Calif., July 22, 2024 — SIX Swiss Exchange Ad hoc announcement pursuant to Art. 53 LR — Logitech International (SIX: LOGN) (Nasdaq: LOGI) today announced financial results for the first quarter of Fiscal Year 2025.

[0001032975-24-000042:8k_2_02:11]
•Sales were $1.1 billion, up 12 percent in US dollars and 13 percent in constant currency, compared to Q1 of the prior year.

[0001032975-24-000042:8k_2_02:12]
•GAAP operating income was $153 million, up 96 percent, compared to Q1 of the prior year.     Non-GAAP operating income was $182 million, up 67 percent, compared to Q1 of the prior year.

[0001032975-24-000042:8k_2_02:13]
•GAAP earnings per share (EPS) was $0.92, up 136 percent compared to Q1 of the prior year. Non-GAAP EPS was $1.13, up 74 percent compared to Q1 of the prior year.

[0001032975-24-000042:8k_2_02:14]
•Cash flow from operations was $176 million, down 27 percent compared to Q1 of the prior year.

[0001032975-24-000042:8k_2_02:15]
“We started the new fiscal year strong, with high-quality, broad-based growth across all regions and key categories,” said Hanneke Faber, Logitech chief executive officer. “Our team continued disciplined execution, as evidenced by excellent gross and operating margin growth. I am pleased to increase our FY25 outlook for both net sales and non-GAAP operating income.”

[0001032975-24-000042:8k_2_02:16]
Outlook

[0001032975-24-000042:8k_2_02:17]
Logitech raised its full-year outlook for Fiscal Year 2025:

[0001032975-24-000042:8k_2_02:18]
|  |  | Previous FY25 outlook |  | New FY25 outlook |
| Sales |  | $4.3 - $4.4 billion |  | $4.34 - $4.43 billion |
| Sales growth (in US dollars, year over year) |  | 0% - 2% |  | 1% - 3% |
| Non-GAAP operating income |  | $685 - $715 million |  | $700 - $730 million |
| Non-GAAP op. inc. growth / (decline) (year over year) |  | (2)% - 2% |  | 0% - 4% |

[0001032975-24-000042:8k_2_02:19]
Financial Results Videoconference and Webcast

[0001032975-24-000042:8k_2_02:20]
Logitech will hold a financial results videoconference to discuss the results for Q1 Fiscal Year 2025 on Tuesday, July 23, 2024 at 5:30 a.m. Pacific Daylight Time and 2:30 p.m. Central European Summer Time. A livestream of the event will be available on the Logitech corporate website at https://ir.logitech.com. This press release and the Q1 Fiscal Year 2025 Shareholder Letter are also available there.

[0001032975-24-000042:8k_2_02:21]
Fiscal Year 2024 Impact Report

[0001032975-24-000042:8k_2_02:22]
Logitech has released the Company’s seventeenth edition of its annual Impact Report, detailing the Company’s progress in terms of environmental and social sustainability. The 2024 Impact Report can be found at https://impactreport.logitech.com/ on the Company’s sustainability webpage https://www.logitech.com/sustainability.

[0001032975-24-000042:8k_2_02:23]
Use of Non-GAAP Financial Information and Constant Currency

[0001032975-24-000042:8k_2_02:24]
To facilitate comparisons to Logitech’s historical results, Logitech has included non-GAAP adjusted measures in this press release, which exclude share-based compensation expense, amortization of intangible assets, acquisition-related costs, restructuring charges, net, loss on investments, non-GAAP income tax adjustment, and other items detailed under “Supplemental Financial Information” after the tables below and posted to our website at https://ir.logitech.com. Logitech also presents percentage sales growth in constant currency (“cc”), a non-GAAP measure, to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales. Logitech believes this information, used together with the GAAP financial information, will help investors to evaluate its current period performance, outlook and trends in its business. With respect to the Company’s outlook for non-GAAP operating income, most of these excluded amounts pertain to events that have not yet occurred and are not currently possible to estimate with a reasonable degree of accuracy. Therefore, no reconciliation to the GAAP amounts has been provided for the Fiscal Year 2025 non-GAAP operating income outlook.

[0001032975-24-000042:8k_2_02:25]
Public Dissemination of Certain Information

[0001032975-24-000042:8k_2_02:26]
Recordings of Logitech’s earnings videoconferences and certain events Logitech participates in or hosts, with members of the investment community are posted on the company’s investor relations website at https://ir.logitech.com. Additionally, Logitech provides notifications of news or announcements regarding its operations and financial performance, including its filings with the Securities and Exchange Commission (SEC), investor events, and press and earnings releases as part of its investor relations website. Logitech intends to use its investor relations website as means of disclosing material nonpublic information and for complying with its disclosure obligations under Regulation FD. Logitech’s corporate governance information also is available on its investor relations website.

[0001032975-24-000042:8k_2_02:27]
About Logitech

[0001032975-24-000042:8k_2_02:28]
Logitech designs software-enabled hardware solutions that help businesses thrive and bring people together when working, creating, gaming and streaming. As the point of connection between people and the digital world, our purpose is to extend human potential in work and play, in a way that is good for people and the planet. Founded in 1981, Logitech International is a Swiss public company listed on the SIX Swiss Exchange (LOGN) and on the Nasdaq Global Select Market (LOGI). Find Logitech and its other brands, including Logitech G, at www.logitech.com or company blog.

[0001032975-24-000042:8k_2_02:29]
# # #

[0001032975-24-000042:8k_2_02:30]
Note that unless noted otherwise, comparisons are year over year.

[0001032975-24-000042:8k_2_02:31]
Logitech and other Logitech marks are trademarks or registered trademarks of Logitech Europe S.A. and/or its affiliates in the U.S. and other countries. All other trademarks are the property of their respective owners. For more information about Logitech and its products, visit the company’s website at www.logitech.com.

[0001032975-24-000042:8k_2_02:32]
(LOGIIR)

[0001032975-24-000042:8k_2_02:33]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three months ended June 30, |  |  |
| GAAP CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  | 2024 |  | 2023 |  |  |  |  |
| Net sales |  | $ | 1,088,217 |  |  | $ | 974,499 |  |  |  |  |  |
| Cost of goods sold |  | 619,517 |  |  | 595,712 |  |  |  |  |  |
| Amortization of intangible assets |  | 2,442 |  |  | 3,145 |  |  |  |  |  |
| Gross profit |  | 466,258 |  |  | 375,642 |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Marketing and selling |  | 196,905 |  |  | 179,185 |  |  |  |  |  |
| Research and development |  | 75,307 |  |  | 70,559 |  |  |  |  |  |
| General and administrative |  | 37,458 |  |  | 41,297 |  |  |  |  |  |
| Amortization of intangible assets and acquisition-related costs |  | 2,703 |  |  | 2,685 |  |  |  |  |  |
| Restructuring charges, net |  | 386 |  |  | 3,511 |  |  |  |  |  |
| Total operating expenses |  | 312,759 |  |  | 297,237 |  |  |  |  |  |
| Operating income |  | 153,499 |  |  | 78,405 |  |  |  |  |  |
| Interest income |  | 15,790 |  |  | 9,826 |  |  |  |  |  |
| Other income (expense), net |  | (1,898) |  |  | (12,972) |  |  |  |  |  |
| Income before income taxes |  | 167,391 |  |  | 75,259 |  |  |  |  |  |
| Provision for income taxes |  | 25,558 |  |  | 12,532 |  |  |  |  |  |
| Net income |  | $ | 141,833 |  |  | $ | 62,727 |  |  |  |  |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.93 |  |  | $ | 0.39 |  |  |  |  |  |
| Diluted |  | $ | 0.92 |  |  | $ | 0.39 |  |  |  |  |  |
| Weighted average shares used to compute net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | 153,300 |  |  | 158,859 |  |  |  |  |  |
| Diluted |  | 154,978 |  |  | 160,155 |  |  |  |  |  |

[0001032975-24-000042:8k_2_02:34]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
|  |  | June 30, |  | March 31, |  |  |  |  |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  | 2024 |  | 2024 |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,534,380 |  |  | $ | 1,520,842 |  |  |  |  |  |
| Accounts receivable, net |  | 591,251 |  |  | 541,715 |  |  |  |  |  |
| Inventories |  | 459,582 |  |  | 422,513 |  |  |  |  |  |
| Other current assets |  | 141,413 |  |  | 146,270 |  |  |  |  |  |
| Total current assets |  | 2,726,626 |  |  | 2,631,340 |  |  |  |  |  |
| Non-current assets: |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  | 113,265 |  |  | 116,589 |  |  |  |  |  |
| Goodwill |  | 462,003 |  |  | 461,978 |  |  |  |  |  |
| Other intangible assets, net |  | 39,490 |  |  | 44,603 |  |  |  |  |  |
| Other assets |  | 343,532 |  |  | 350,194 |  |  |  |  |  |
| Total assets |  | $ | 3,684,916 |  |  | $ | 3,604,704 |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 554,301 |  |  | $ | 448,627 |  |  |  |  |  |
| Accrued and other current liabilities |  | 586,180 |  |  | 637,262 |  |  |  |  |  |
| Total current liabilities |  | 1,140,481 |  |  | 1,085,889 |  |  |  |  |  |
| Non-current liabilities: |  |  |  |  |  |  |  |  |
| Income taxes payable |  | 116,379 |  |  | 112,572 |  |  |  |  |  |
| Other non-current liabilities |  | 179,121 |  |  | 172,590 |  |  |  |  |  |
| Total liabilities |  | 1,435,981 |  |  | 1,371,051 |  |  |  |  |  |
| Shareholders’ equity: |  |  |  |  |  |  |  |  |
| Registered shares, CHF 0.25 par value: |  | 30,148 |  |  | 30,148 |  |  |  |  |  |
| Issued shares — 173,106 at June 30, 2024 and March 31, 2024 |  |  |  |  |  |  |  |  |
| Additional shares that may be issued out of conditional capital — 50,000 at June 30, 2024 and March 31, 2024 |  |  |  |  |  |  |  |  |
| Additional shares that may be issued out of authorized capital — 17,311 at June 30, 2024 and March 31, 2024 |  |  |  |  |  |  |  |  |
| Additional paid-in capital |  | 57,036 |  |  | 63,524 |  |  |  |  |  |
| Shares in treasury, at cost — 20,090 at June 30, 2024 and 19,243 at March 31, 2024 |  | (1,418,051) |  |  | (1,351,336) |  |  |  |  |  |
| Retained earnings |  | 3,695,574 |  |  | 3,602,519 |  |  |  |  |  |
| Accumulated other comprehensive loss |  | (115,772) |  |  | (111,202) |  |  |  |  |  |
| Total shareholders’ equity |  | 2,248,935 |  |  | 2,233,653 |  |  |  |  |  |
| Total liabilities and shareholders’ equity |  | $ | 3,684,916 |  |  | $ | 3,604,704 |  |  |  |  |  |

[0001032975-24-000042:8k_2_02:35]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
|  |  |  |  | Three months ended June 30, |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |  |  |  |  |  | 2024 |  | 2023 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  |  |  |  |  | $ | 141,833 |  |  | $ | 62,727 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  |  |  |  | 14,506 |  |  | 17,498 |  |
| Amortization of intangible assets |  |  |  |  |  | 5,079 |  |  | 5,827 |  |
| Loss on investments |  |  |  |  |  | 1,186 |  |  | 11,823 |  |
| Share-based compensation expense |  |  |  |  |  | 23,405 |  |  | 21,511 |  |
| Deferred income taxes |  |  |  |  |  | 11,662 |  |  | 2,962 |  |
| Other |  |  |  |  |  | (24) |  |  | 24 |  |
| Changes in assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  |  |  |  | (53,952) |  |  | 65,390 |  |
| Inventories |  |  |  |  |  | (39,095) |  |  | 110,440 |  |
| Other assets |  |  |  |  |  | 4,907 |  |  | 34,342 |  |
| Accounts payable |  |  |  |  |  | 109,028 |  |  | (18,420) |  |
| Accrued and other liabilities |  |  |  |  |  | (42,506) |  |  | (74,329) |  |
| Net cash provided by operating activities |  |  |  |  |  | 176,029 |  |  | 239,795 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  |  |  |  | (14,586) |  |  | (16,238) |  |
| Purchases of deferred compensation investments |  |  |  |  |  | (695) |  |  | (1,069) |  |
| Proceeds from sales of deferred compensation investments |  |  |  |  |  | 738 |  |  | 1,071 |  |
| Other investing activities |  |  |  |  |  | (816) |  |  | (1,294) |  |
| Net cash used in investing activities |  |  |  |  |  | (15,359) |  |  | (17,530) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Purchases of registered shares |  |  |  |  |  | (130,899) |  |  | (95,076) |  |
| Proceeds from exercises of stock options and purchase rights |  |  |  |  |  | 4,618 |  |  | 2,113 |  |
| Tax withholdings related to net share settlements of restricted stock units |  |  |  |  |  | (18,853) |  |  | (24,196) |  |
| Net cash used in financing activities |  |  |  |  |  | (145,134) |  |  | (117,159) |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  |  |  |  | (1,998) |  |  | (3,043) |  |
| Net increase in cash and cash equivalents |  |  |  |  |  | 13,538 |  |  | 102,063 |  |
| Cash and cash equivalents, beginning of the period |  |  |  |  |  | 1,520,842 |  |  | 1,149,023 |  |
| Cash and cash equivalents, end of the period |  |  |  |  |  | $ | 1,534,380 |  |  | $ | 1,251,086 |  |

[0001032975-24-000042:8k_2_02:36]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three months ended June 30, |  |  |
| NET SALES |  | 2024 |  | 2023 |  | Change |  |  |  |  |  |  |
| Net sales by product category: |  |  |  |  |  |  |  |  |  |  |  |  |
| Gaming (1) |  | $ | 309,475 |  |  | $ | 266,429 |  |  | 16 | % |  |  |  |  |  |  |
| Keyboards & Combos |  | 215,333 |  |  | 180,855 |  |  | 19 |  |  |  |  |  |  |  |
| Pointing Devices |  | 189,946 |  |  | 174,454 |  |  | 9 |  |  |  |  |  |  |  |
| Video Collaboration |  | 147,042 |  |  | 139,346 |  |  | 6 |  |  |  |  |  |  |  |
| Webcams |  | 72,904 |  |  | 75,200 |  |  | (3) |  |  |  |  |  |  |  |
| Tablet Accessories |  | 78,539 |  |  | 70,336 |  |  | 12 |  |  |  |  |  |  |  |
| Headsets |  | 44,236 |  |  | 36,850 |  |  | 20 |  |  |  |  |  |  |  |
| Other (2) |  | 30,742 |  |  | 31,029 |  |  | (1) |  |  |  |  |  |  |  |
| Total Net Sales |  | $ | 1,088,217 |  |  | $ | 974,499 |  |  | 12 | % |  |  |  |  |  |  |

[0001032975-24-000042:8k_2_02:37]
(1) Gaming includes streaming services revenue generated by Streamlabs.

[0001032975-24-000042:8k_2_02:38]
(2) Other primarily consists of mobile speakers and PC speakers.

[0001032975-24-000042:8k_2_02:39]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three months ended June 30, |  |  |
| GAAP TO NON-GAAP RECONCILIATION (A) |  | 2024 |  | 2023 |  |  |  |  |
| Gross profit - GAAP |  | $ | 466,258 |  | $ | 375,642 |  |  |  |  |
| Share-based compensation expense |  | 2,598 |  | 1,415 |  |  |  |  |
| Amortization of intangible assets |  | 2,442 |  | 3,145 |  |  |  |  |
| Gross profit - Non-GAAP |  | $ | 471,298 |  | $ | 380,202 |  |  |  |  |
| Gross margin - GAAP |  | 42.8 | % |  | 38.5 | % |  |  |  |  |
| Gross margin - Non-GAAP |  | 43.3 | % |  | 39.0 | % |  |  |  |  |
| Operating expenses - GAAP |  | $ | 312,759 |  | $ | 297,237 |  |  |  |  |
| Less: Share-based compensation expense |  | 20,807 |  | 20,096 |  |  |  |  |
| Less: Amortization of intangible assets and acquisition-related costs |  | 2,703 |  | 2,685 |  |  |  |  |
| Less: Restructuring charges, net |  | 386 |  | 3,511 |  |  |  |  |
| Operating expenses - Non-GAAP |  | $ | 288,863 |  | $ | 270,945 |  |  |  |  |
| % of net sales - GAAP |  | 28.7 | % |  | 30.5 | % |  |  |  |  |
| % of net sales - Non-GAAP |  | 26.5 | % |  | 27.8 | % |  |  |  |  |
| Operating income - GAAP |  | $ | 153,499 |  | $ | 78,405 |  |  |  |  |
| Share-based compensation expense |  | 23,405 |  | 21,511 |  |  |  |  |
| Amortization of intangible assets and acquisition-related costs |  | 5,145 |  | 5,830 |  |  |  |  |
| Restructuring charges, net |  | 386 |  | 3,511 |  |  |  |  |
| Operating income - Non-GAAP |  | $ | 182,435 |  | $ | 109,257 |  |  |  |  |
| % of net sales - GAAP |  | 14.1 | % |  | 8.0 | % |  |  |  |  |
| % of net sales - Non-GAAP |  | 16.8 | % |  | 11.2 | % |  |  |  |  |
| Net income - GAAP |  | $ | 141,833 |  | $ | 62,727 |  |  |  |  |
| Share-based compensation expense |  | 23,405 |  | 21,511 |  |  |  |  |
| Amortization of intangible assets and acquisition-related costs |  | 5,145 |  | 5,830 |  |  |  |  |
| Restructuring charges, net |  | 386 |  | 3,511 |  |  |  |  |
| Loss on investments |  | 1,186 |  | 11,823 |  |  |  |  |
| Non-GAAP income tax adjustment |  | 2,670 |  | (2,001) |  |  |  |  |
| Net income - Non-GAAP |  | $ | 174,625 |  | $ | 103,401 |  |  |  |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  | $ | 0.92 |  | $ | 0.39 |  |  |  |  |
| Diluted - Non-GAAP |  | $ | 1.13 |  | $ | 0.65 |  |  |  |  |
| Shares used to compute net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP and Non-GAAP |  | 154,978 |  | 160,155 |  |  |  |  |

[0001032975-24-000042:8k_2_02:40]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three months ended June 30, |  |  |
| SHARE-BASED COMPENSATION EXPENSE |  | 2024 |  | 2023 |  |  |  |  |
| Share-based Compensation Expense |  |  |  |  |  |  |  |  |
| Cost of goods sold |  | $ | 2,598 |  |  | $ | 1,415 |  |  |  |  |  |
| Marketing and selling |  | 11,851 |  |  | 10,483 |  |  |  |  |  |
| Research and development |  | 5,739 |  |  | 4,453 |  |  |  |  |  |
| General and administrative |  | 3,217 |  |  | 5,160 |  |  |  |  |  |
| Total share-based compensation expense |  | 23,405 |  |  | 21,511 |  |  |  |  |  |
| Income tax benefit |  | (7,602) |  |  | (5,318) |  |  |  |  |  |
| Total share-based compensation expense, net of income tax benefit |  | $ | 15,803 |  |  | $ | 16,193 |  |  |  |  |  |

[0001032975-24-000042:8k_2_02:41]
*Note: These preliminary results for the three months ended June 30, 2024 are subject to adjustments, including subsequent events that may occur through the date of filing our Quarterly Report on Form 10-Q.

[0001032975-24-000042:8k_2_02:42]
(A) Non-GAAP Financial Measures

[0001032975-24-000042:8k_2_02:43]
To supplement our condensed consolidated financial results prepared in accordance with GAAP, we use a number of financial measures, both GAAP and non-GAAP, in analyzing and assessing our overall business performance, for making operating decisions and for forecasting and planning future periods. We consider the use of non-GAAP financial measures helpful in assessing our current financial performance, ongoing operations and prospects for the future as well as understanding financial and business trends relating to our financial condition and results of operations.

[0001032975-24-000042:8k_2_02:44]
While we use non-GAAP financial measures as a tool to enhance our understanding of certain aspects of our financial performance and to provide incremental insight into the underlying factors and trends affecting both our performance and our cash-generating potential, we do not consider these measures to be a substitute for, or superior to, the information provided by GAAP financial measures. Consistent with this approach, we believe that disclosing non-GAAP financial measures to the readers of our financial statements provides useful supplemental data that, while not a substitute for GAAP financial measures, can offer insight in the review of our financial and operational performance and enables investors to more fully understand trends in our current and future performance. In assessing our business during the quarter ended June 30, 2024 and prior periods presented, we excluded items in the following general categories, each of which are described below:

[0001032975-24-000042:8k_2_02:45]
Share-based compensation expense. We believe that providing non-GAAP measures excluding share-based compensation expense, in addition to the GAAP measures, allows for a more transparent comparison of our financial results from period to period. We prepare and maintain our budgets and forecasts for future periods on a basis consistent with this non-GAAP financial measure. Further, companies use a variety of types of equity awards as well as a variety of methodologies, assumptions and estimates to determine share-based compensation expense. We believe that excluding share-based compensation expense enhances our ability and the ability of investors to understand the impact of non-cash share-based compensation on our operating results and to compare our results against the results of other companies.

[0001032975-24-000042:8k_2_02:46]
Amortization of intangible assets. We incur intangible asset amortization expense, primarily in connection with our acquisitions of various businesses and technologies. The amortization of purchased intangibles varies depending on the level of acquisition activity. We exclude these various charges in budgeting, planning and forecasting future periods and we believe that providing the non-GAAP measures excluding these various non-cash charges, as well as the GAAP measures, provides additional insight when comparing our gross profit, operating expenses, and financial results from period to period.

[0001032975-24-000042:8k_2_02:47]
Acquisition-related costs. We incurred expenses and credits in connection with our acquisitions which we generally would not have otherwise incurred in the periods presented as a part of our continuing operations. Acquisition-related costs include certain incremental expenses incurred to effect a business combination. We believe that providing the non-GAAP measures excluding these costs, as well as the GAAP measures, assists our investors because such costs are not reflective of our ongoing operating results.

[0001032975-24-000042:8k_2_02:48]
Restructuring charges (credits), net. These expenses are associated with restructuring plans, and will vary based on the initiatives in place during any given period. Restructuring charges may include costs related to employee

[0001032975-24-000042:8k_2_02:49]
terminations, facility closures and early cancellation of certain contracts as well as other costs resulting from our restructuring initiatives. We believe that providing the non-GAAP measures excluding these items, as well as the GAAP measures, assists our investors because such charges are not reflective of our ongoing operating results.

[0001032975-24-000042:8k_2_02:50]
Loss (gain) on investments. We recognize losses (gains) related to our investments in various companies, which vary depending on the operational and financial performance of the companies in which we invest. These amounts include our losses (earnings) on equity method investments, investment impairments and losses (gains) resulting from sales or other events related to our investments. We believe that providing the non-GAAP measures excluding these items, as well as the GAAP measures, assists our investors because such losses (gains) are not reflective of our ongoing operations.

[0001032975-24-000042:8k_2_02:51]
Non-GAAP income tax adjustment.  Non-GAAP income tax adjustment primarily measures the income tax effect of non-GAAP adjustments excluded above as well as the income tax impact of non-recurring deferred taxes, tax settlements, and other non-routine tax events, the determination of which is based upon the nature of the underlying items.

[0001032975-24-000042:8k_2_02:52]
Each of the non-GAAP financial measures described above, and used in this press release, should not be considered in isolation from, or as a substitute for, a measure of financial performance prepared in accordance with GAAP. Further, investors are cautioned that there are inherent limitations associated with the use of each of these non-GAAP financial measures as an analytical tool. In particular, these non-GAAP financial measures are not based on a comprehensive set of accounting rules or principles and many of the adjustments to the GAAP financial measures reflect the exclusion of items that are recurring and may be reflected in the Company’s financial results for the foreseeable future. We compensate for these limitations by providing specific information in the reconciliation included in this press release regarding the GAAP amounts excluded from the non-GAAP financial measures. In addition, as noted above, we evaluate the non-GAAP financial measures together with the most directly comparable GAAP financial information.

[0001032975-24-000042:8k_2_02:53]
Additional Supplemental Financial Information - Constant Currency

[0001032975-24-000042:8k_2_02:54]
In addition, Logitech presents percentage sales growth in constant currency to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales.
