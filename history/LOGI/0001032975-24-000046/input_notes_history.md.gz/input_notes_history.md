# LOGI note change history — 0001032975-24-000008 → 0001032975-24-000046


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-07-25):
[0001032975-24-000046:note_history:1]
Changes in the Company’s warranty liabilities for the three months ended June 30, 2024 and 2023 were as follows (in thousands):
  (was, 2024-01-25, similarity 0.9243):
[0001032975-24-000008:note_history:1]
Changes in the Company’s warranty liabilities for the three and nine months ended December 31, 2023 and 2022 were as follows (in thousands):

- changed (2024-07-25):
[0001032975-24-000046:note_history:2]
|  | Three months ended June 30, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Beginning of the period | $ | 44,654 |  |  | $ | 40,886 |  |  |  |  |  |
| Provision | 10,186 |  |  | 9,092 |  |  |  |  |  |
| Settlements | (10,038) |  |  | (9,918) |  |  |  |  |  |
| Effects of foreign currency translation | (300) |  |  | (175) |  |  |  |  |  |
| End of the period | $ | 44,502 |  |  | $ | 39,885 |  |  |  |  |  |
  (was, 2024-01-25, similarity 0.6952):
[0001032975-24-000008:note_history:2]
|  | Three months ended December 31, |  | Nine months ended December 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Beginning of the period | $ | 40,265 |  |  | $ | 41,960 |  |  | $ | 40,886 |  |  | $ | 46,219 |  |
| Provision | 11,249 |  |  | 8,920 |  |  | 30,734 |  |  | 23,440 |  |
| Settlements | (10,158) |  |  | (8,979) |  |  | (29,914) |  |  | (26,358) |  |
| Effects of foreign currency translation | 421 |  |  | 730 |  |  | 71 |  |  | (670) |  |
| End of the period | $ | 41,777 |  |  | $ | 42,631 |  |  | $ | 41,777 |  |  | $ | 42,631 |  |

- changed (2024-07-25):
[0001032975-24-000046:note_history:3]
The Company indemnifies certain suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of June 30, 2024, no material amounts have been accrued for indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.
  (was, 2024-01-25, similarity 0.9798):
[0001032975-24-000008:note_history:3]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of December 31, 2023, no material amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

- changed (2024-07-25):
[0001032975-24-000046:note_history:4]
The Company also indemnifies its current and former directors and certain current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. The Company is unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not capped, the obligations are conditional in nature, and the facts and circumstances involved in any situation that might arise are variable.
  (was, 2024-01-25, similarity 0.983):
[0001032975-24-000008:note_history:4]
The Company also indemnifies its current and former directors and certain of its current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. The Company is unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not limited, the obligations are conditional in nature and the facts and circumstances involved in any situation that might arise are variable.

- added (2024-07-25):
[0001032975-24-000046:note_history:5]
From time to time the Company is involved in claims and legal proceedings that arise in the ordinary course of its business. The Company is currently subject to several such claims and legal proceedings. The Company intends to vigorously defend against them. Management periodically assesses the Company’s liabilities and contingencies in connection with these matters based upon the latest information available. The Company follows ASC ("Accounting Standards Codification") 450, Contingencies, in determining the accounting and disclosure for these contingencies. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows and results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company's defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company's business, financial condition, cash flows and results of operations in a particular period. Any claims or proceedings against the Company can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain a necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company's business.

- removed (2024-07-25):
[0001032975-24-000008:note_history:6]
From time to time the Company is involved in claims and legal proceedings that arise in the ordinary course of its business. The Company is currently subject to several such claims and legal proceedings. The Company intends to vigorously defend against them. Management periodically assesses the Company’s liabilities and contingencies in connection with these matters based upon the latest information available. The Company follows ASC ("Accounting Standards Codification") 450 in determining the accounting and disclosure for these contingencies. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows and results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company's defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company's business, financial condition, cash flows and results of operations in a particular period. Any claims or proceedings against the Company can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain a necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company's business.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2024-07-25):
[0001032975-24-000046:note_history:7]
Logitech International S.A, together with its consolidated subsidiaries ("Logitech" or the "Company"), designs software-enabled hardware solutions that help businesses thrive and bring people together when working, creating, gaming and streaming. As a point of connection between people and the digital world, the Company's mission is to

- added (2024-07-25):
[0001032975-24-000046:note_history:8]
extend human potential in work and play, in a way that is good for people and the planet.

- changed (2024-07-25):
[0001032975-24-000046:note_history:9]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three months ended June 30, 2024 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2025, or any future periods.
  (was, 2024-01-25, similarity 0.9573):
[0001032975-24-000008:note_history:9]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and nine months ended December 31, 2023 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2024, or any future periods.

- changed (2024-07-25):
[0001032975-24-000046:note_history:10]
There have been no material changes in the Company’s significant accounting policies during the three months ended June 30, 2024 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2024.
  (was, 2024-01-25, similarity 0.9091):
[0001032975-24-000008:note_history:10]
There have been no material changes in the Company’s significant accounting policies during the three and nine months ended December 31, 2023 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2023.

- changed (2024-07-25):
[0001032975-24-000046:note_history:11]
The preparation of financial statements in conformity with U.S. GAAP requires management to make judgments, estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Significant estimates and assumptions made by management involve the fair value of goodwill and intangible assets acquired from business acquisitions, valuation of investment in privately held companies classified under Level 3 fair value hierarchy, pension obligations, accruals for customer incentives, cooperative marketing, and pricing programs and related breakage when appropriate, inventory valuation, share-based compensation expense, uncertain tax positions, and valuation allowances for deferred tax assets. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ materially from those estimates.
  (was, 2024-01-25, similarity 0.9567):
[0001032975-24-000008:note_history:11]
The preparation of financial statements in conformity with U.S. GAAP requires management to make judgments, estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Significant estimates and assumptions made by management involve the fair value of goodwill and intangible assets acquired from business acquisitions, contingent consideration for a business acquisition and periodic reassessment of its fair value, valuation of investment in privately held companies classified under Level 3 fair value hierarchy, pension obligations, accruals for customer incentives, cooperative marketing, and pricing programs and related breakage when appropriate, inventory valuation, share-based compensation expense, uncertain tax positions, and valuation allowances for deferred tax assets. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ materially from those estimates.

- changed (2024-07-25):
[0001032975-24-000046:note_history:12]
The Company's business has continued to be impacted by macroeconomic and geopolitical conditions. These conditions include inflation, interest rate and foreign currency fluctuations, changes in fiscal policies, low economic growth in certain regions, and uncertainty in consumer and enterprise demand.
  (was, 2024-01-25, similarity 0.6049):
[0001032975-24-000008:note_history:12]
The Company's business has been impacted by adverse macroeconomic and geopolitical conditions. These conditions include inflation, interest rate and foreign currency fluctuations, slowdown of economic activity around the world, and lower consumer and enterprise spending.

- added (2024-07-25):
[0001032975-24-000046:note_history:13]
The global and regional economic and political conditions have caused and may continue to cause volatility in demand for the Company's products as well as the cost of materials and logistics, and transportation delays, and as a result may impact the pricing of the Company's products, product availability and the Company's results of operations.

- changed (2024-07-25):
[0001032975-24-000046:note_history:14]
In November 2023, the Financial Accounting Standard Board ("FASB") issued Accounting Standards Update ("ASU") 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures. ASU 2023-07 improves reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses that are regularly provided to the chief operating decision maker. In addition, ASU 2023-07 requires that all existing annual disclosures about segment profit or loss must be provided on an interim basis and clarifies that single reportable segment entities are subject to the disclosure requirement under Topic 280 in its entirety. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023 and interim periods within those fiscal years beginning after December 15, 2024. A public entity should apply ASU 2023-07 retrospectively to all prior periods presented in the financial statements. Early adoption is permitted. The Company is currently evaluating the impact of ASU 2023-07 on its consolidated financial statements and related disclosures. 
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures. ASU 2023-09 requires additional disclosures related to rate reconciliation, income taxes paid, and other disclosures. Under ASU 2023-09, for each annual period presented, public entities are required to (1) disclose specific categories in the tabular rate reconciliation and (2) provide additional information for reconciling items that meet a quantitative threshold. In addition, ASU 2023-09 requires all reporting entities to disclose on an annual basis the amount of income taxes paid disaggregated by federal, state, and foreign taxes as well as the amount of income taxes paid by individual jurisdiction. ASU 2023-09 is effective for public business entities for annual periods beginning after December 15, 2024 and can be applied on a prospective basis with an option to apply the standard retrospectively. Early adoption is permitted. The Company is currently evaluating the impact of ASU 2023-09 on its consolidated financial statements and related disclosures.
  (was, 2024-01-25, similarity 0.9998):
[0001032975-24-000008:note_history:14]
In November 2023, the Financial Accounting Standard Board ("FASB") issued Accounting Standards Update ("ASU") 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures. ASU 2023-07 improves reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses that are regularly provided to the chief operating decision maker. In addition, ASU 2023-07 requires that all existing annual disclosures about segment profit or loss must be provided on an interim basis and clarifies that single reportable segment entities are subject to the disclosure requirement under Topic 280 in its entirety. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023 and interim periods within those fiscal years beginning after December 15, 2024. A public entity should apply ASU 2023-07 retrospectively to all prior periods presented in the financial statements. Early adoption is permitted. The Company is currently evaluating the impact of ASU 2023-07 on its consolidated financial statements and related disclosures. 
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures. ASU 2023-09 requires additional disclosures related to rate reconciliation, income taxes paid, and other disclosures. Under ASU 2023-09, for each annual periods presented, public entities are required to (1) disclose specific categories in the tabular rate reconciliation and (2) provide additional information for reconciling items that meet a quantitative threshold. In addition, ASU 2023-09 requires all reporting entities to disclose on an annual basis the amount of income taxes paid disaggregated by federal, state, and foreign taxes as well as the amount of income taxes paid by individual jurisdiction. ASU 2023-09 is effective for public business entities for annual periods beginning after December 15, 2024 and can be applied on a prospective basis with an option to apply the standard retrospectively. Early adoption is permitted. The Company is currently evaluating the impact of ASU 2023-09 on its consolidated financial statements and related disclosures.

- removed (2024-07-25):
[0001032975-24-000008:note_history:15]
Logitech International S.A, together with its consolidated subsidiaries ("Logitech" or the "Company"), designs, manufactures and sells products that help businesses thrive and bring people together when working, creating, gaming and streaming.

- removed (2024-07-25):
[0001032975-24-000008:note_history:16]
Change in Presentation of Sales by Product Category

- removed (2024-07-25):
[0001032975-24-000008:note_history:17]
During the first quarter of fiscal year 2024, the Company changed its presentation of Sales by Product Category, included in Note 12, to provide a simpler and clearer view of the Company's business. The change in presentation did not have an impact on previously reported total sales. These changes included reclassifications of sales between certain product categories resulting in the following:

- removed (2024-07-25):
[0001032975-24-000008:note_history:18]
•The Webcams category (previously PC Webcams) now includes PC webcams and VC webcams;

- removed (2024-07-25):
[0001032975-24-000008:note_history:19]
•Headsets is a new category which includes PC headsets and VC headsets;

- removed (2024-07-25):
[0001032975-24-000008:note_history:20]
•The Mobile Speakers category is no longer a separate category as sales have been reclassified into the Other category;

- removed (2024-07-25):
[0001032975-24-000008:note_history:21]
•The Audio & Wearables category is no longer a separate category as sales have been reclassified into other categories as discussed below.

- removed (2024-07-25):
[0001032975-24-000008:note_history:22]
As a result of these changes, certain prior-period amounts for the three and nine months ended December 31, 2022 have been reclassified to conform to the current period presentation as follows (in thousands):

- removed (2024-07-25):
[0001032975-24-000008:note_history:23]
|  |  | Three months ended December 31, 2022 |
|  |  | As previously reported |  | Reclassifications |  | As adjusted |
| Gaming |  | $ | 391,975 |  |  | $ | 19,952 |  | (1) | $ | 411,927 |  |
| Keyboards & Combos |  | 220,059 |  |  | — |  |  | 220,059 |  |
| Pointing Devices |  | 199,106 |  |  | — |  |  | 199,106 |  |
| Video Collaboration |  | 226,374 |  |  | (52,858) |  | (2) (3) | 173,516 |  |
| Webcams (3) |  | 58,481 |  |  | 35,771 |  | (3) | 94,252 |  |
| Tablet Accessories |  | 65,157 |  |  | — |  |  | 65,157 |  |
| Headsets |  | — |  |  | 46,736 |  | (2) | 46,736 |  |
| Other |  | 1,348 |  |  | 57,824 |  | (4) (5) | 59,172 |  |
| Mobile Speakers |  | 38,321 |  |  | (38,321) |  | (4) | — |  |
| Audio & Wearables |  | 69,104 |  |  | (69,104) |  | (1) (2) (5) | — |  |
| Total Sales |  | $ | 1,269,925 |  |  | $ | — |  |  | $ | 1,269,925 |  |

- removed (2024-07-25):
[0001032975-24-000008:note_history:24]
|  |  | Nine months ended December 31, 2022 |
|  |  | As previously reported |  | Reclassifications |  | As adjusted |
| Gaming |  | $ | 972,457 |  |  | $ | 59,419 |  | (1) | $ | 1,031,876 |  |
| Keyboards & Combos |  | 648,632 |  |  | — |  |  | 648,632 |  |
| Pointing Devices |  | 567,589 |  |  | — |  |  | 567,589 |  |
| Video Collaboration |  | 708,796 |  |  | (174,449) |  | (2) (3) | 534,347 |  |
| Webcams (3) |  | 178,033 |  |  | 127,499 |  | (3) | 305,532 |  |
| Tablet Accessories |  | 185,945 |  |  | — |  |  | 185,945 |  |
| Headsets |  | — |  |  | 137,429 |  | (2) | 137,429 |  |
| Other |  | 5,642 |  |  | 161,749 |  | (4) (5) | 167,391 |  |
| Mobile Speakers |  | 99,826 |  |  | (99,826) |  | (4) | — |  |
| Audio & Wearables |  | 211,821 |  |  | (211,821) |  | (1) (2) (5) | — |  |
| Total Sales |  | $ | 3,578,741 |  |  | $ | — |  |  | $ | 3,578,741 |  |

- removed (2024-07-25):
[0001032975-24-000008:note_history:25]
(1) Reclassification of Blue Microphones from "Audio & Wearables" to the Gaming category.

- removed (2024-07-25):
[0001032975-24-000008:note_history:26]
(2) Reclassification of VC headsets and PC headsets to the new Headsets category from "Video Collaboration" and "Audio & Wearables," respectively.

- removed (2024-07-25):
[0001032975-24-000008:note_history:27]
(3) The Webcams category includes amounts previously reported as "PC Webcams" as well as amounts from VC webcams reclassified from "Video Collaboration."

- removed (2024-07-25):
[0001032975-24-000008:note_history:28]
(4) Reclassification of all amounts previously reported in "Mobile Speakers" to the Other category.

- removed (2024-07-25):
[0001032975-24-000008:note_history:29]
(5) Reclassification of PC speakers previously reported in "Audio & Wearables" to the Other category.

- removed (2024-07-25):
[0001032975-24-000008:note_history:30]
The global and regional economic and political conditions adversely affected demand for the Company's products. In addition, these conditions, including recent transportation issues in the Red Sea, have caused and may continue to cause volatility in the cost of materials and logistics, and transportation delays, and as a result may impact the pricing of the Company's products, product availability and the Company's results of operations.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-07-25):
[0001032975-24-000046:note_history:31]
The Company had several uncommitted, unsecured bank lines of credit and letters of credit aggregating $171.8 million and $172.5 million as of June 30, 2024 and March 31, 2024, respectively. There are no financial covenants under the lines of credit with which the Company must comply. There was no borrowing outstanding under the lines of credit as of June 30, 2024 or March 31, 2024. As of June 30, 2024 and March 31, 2024, the Company had outstanding bank guarantees of $13.5 million and $14.3 million, respectively.
  (was, 2024-01-25, similarity 0.9119):
[0001032975-24-000008:note_history:31]
The Company had several uncommitted, unsecured bank lines of credit and letters of credit aggregating $176.1 million and $181.3 million as of December 31, 2023 and March 31, 2023, respectively. There are no financial covenants under the lines of credit with which the Company must comply. There was no borrowing outstanding under the lines of credit as of December 31, 2023 or March 31, 2023. As of December 31, 2023 and March 31, 2023, the Company had outstanding bank guarantees of $11.1 million and $13.6 million, respectively.
