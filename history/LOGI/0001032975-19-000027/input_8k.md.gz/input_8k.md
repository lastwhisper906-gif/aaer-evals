# LOGI 8-K — 0001032975-19-000017 filed 2019-04-30

## item codes, every 8-K on or before 2019-05-17

- 2019-05-03 0001032975-19-000021 — 5.02 — amendment, the index does not say of what
- 2019-04-30 0001032975-19-000017 — 2.02, 5.02, 9.01
- 2019-03-28 0001032975-19-000013 — 5.02
- 2019-01-22 0001032975-19-000004 — 2.02, 9.01
- 2018-10-23 0001032975-18-000044 — 2.02, 9.01
- 2018-09-07 0001032975-18-000040 — 5.07, 8.01
- 2018-07-31 0001032975-18-000035 — 1.01, 2.02, 2.05, 7.01, 9.01
- 2018-06-27 0001032975-18-000020 — 5.02
- 2018-05-03 0001032975-18-000013 — 2.02, 5.02, 9.01
- 2018-01-23 0001032975-18-000005 — 2.02, 9.01
- 2017-10-24 0001032975-17-000043 — 2.02, 9.01
- 2017-09-18 0001032975-17-000040 — 5.07, 8.01
- 2017-07-25 0001032975-17-000028 — 2.02, 9.01
- 2017-07-12 0001032975-17-000022 — 1.01
- 2017-04-26 0001032975-17-000012 — 2.02, 9.01
- 2017-01-25 0001032975-17-000002 — 2.02, 9.01
- 2016-10-26 0001032975-16-000103 — 2.02, 9.01
- 2016-09-13 0001032975-16-000101 — 5.07, 8.01
- 2016-07-28 0001032975-16-000092 — 2.02, 9.01
- 2016-06-30 0001032975-16-000087 — 5.02
- 2016-04-28 0001032975-16-000077 — 2.02, 9.01
- 2016-04-14 0001032975-16-000073 — 1.01, 7.01, 9.01
- 2016-01-21 0001032975-16-000064 — 2.02, 9.01
- 2016-01-04 0001032975-16-000061 — 1.01, 2.01, 9.01
- 2015-12-23 0001032975-15-000059 — 5.02
- 2015-10-22 0001032975-15-000047 — 2.02, 9.01
- 2015-09-11 0001032975-15-000044 — 5.07, 8.01
- 2015-07-24 0001032975-15-000034 — 2.05 — amendment of 0001032975-15-000030
- 2015-07-23 0001032975-15-000030 — 2.02, 9.01
- 2015-06-25 0001032975-15-000025 — 5.02
- 2015-05-14 0001032975-15-000011 — 8.01, 9.01
- 2015-04-23 0001032975-15-000008 — 2.02, 2.05
- 2015-01-22 0001628280-15-000191 — 2.02, 8.01
- 2014-12-23 0001193125-14-450908 — 5.02, 5.07, 8.01
- 2014-11-25 0001193125-14-425233 — 3.01
- 2014-11-13 0001193125-14-411303 — 4.01, 9.01
- 2014-10-23 0001104659-14-073164 — 2.02, 9.01
- 2014-09-04 0001193125-14-331214 — 4.02, 9.01
- 2014-08-18 0001193125-14-313346 — 3.01, 9.01
- 2014-07-24 0001104659-14-053065 — 2.02, 9.01
- 2014-06-05 0001193125-14-226177 — 3.01, 9.01
- 2014-05-22 0001193125-14-208777 — 8.01, 9.01
- 2014-04-24 0001104659-14-029650 — 2.02, 9.01
- 2014-01-23 0001104659-14-003619 — 2.02, 9.01
- 2013-10-24 0001104659-13-077404 — 2.02, 9.01
- 2013-09-09 0001193125-13-361441 — 5.02, 5.07, 8.01, 9.01
- 2013-09-06 0001193125-13-359930 — 5.02, 9.01
- 2013-08-02 0001193125-13-317343 — 5.02
- 2013-07-25 0001104659-13-056372 — 2.02, 9.01
- 2013-06-28 0001193125-13-277394 — 5.02, 9.01
- 2013-06-20 0001193125-13-265914 — 8.01, 9.01
- 2013-04-25 0001104659-13-032570 — 2.02, 9.01
- 2013-04-17 0001193125-13-158923 — 5.02, 9.01
- 2013-03-01 0001193125-13-085804 — 2.05
- 2013-01-24 0001104659-13-004214 — 2.02, 9.01
- 2013-01-02 0001193125-13-000058 — 5.02
- 2012-10-25 0001104659-12-070966 — 2.02, 9.01
- 2012-09-11 0001193125-12-388070 — 5.02, 5.07, 8.01, 9.01
- 2012-08-22 0001193125-12-364167 — 5.02, 8.01, 9.01
- 2012-07-26 0001104659-12-051084 — 2.02, 9.01
- 2012-06-08 0001193125-12-264132 — 2.05, 9.01 — amendment, the index does not say of what
- 2012-04-26 0001193125-12-183657 — 5.02, 9.01
- 2012-04-26 0001104659-12-028470 — 2.02, 2.05, 9.01
- 2012-03-15 0001193125-12-115954 — 5.02, 9.01
- 2012-01-26 0001104659-12-004014 — 2.02, 9.01
- 2012-01-04 0001193125-12-002212 — 1.01, 2.03, 9.01
- 2011-10-27 0001104659-11-058150 — 2.02, 9.01
- 2011-09-12 0001193125-11-245931 — 5.07
- 2011-07-28 0001193125-11-200929 — 5.02, 9.01
- 2011-07-28 0001193125-11-199704 — 2.02, 9.01
- 2011-04-28 0001193125-11-112669 — 2.02, 9.01
- 2011-03-24 0001193125-11-076483 — 5.02, 9.01
- 2011-01-27 0001032975-11-000003 — 9.01
- 2010-10-28 0001032975-10-000032 — 9.01
- 2010-09-13 0001032975-10-000022 — 5.07
- 2010-07-29 0001032975-10-000010 — 2.02, 9.01
- 2010-06-10 0001193125-10-136877 — 5.02, 9.01
- 2010-05-03 0001193125-10-104337 — 5.02
- 2010-04-29 0001032975-10-000008 — 2.02, 9.01
- 2010-02-19 0001032975-10-000006 — 9.01 — amendment of 0001193125-09-252416
- 2010-01-21 0001032975-10-000002 — 2.02, 9.01
- 2009-12-14 0001193125-09-252416 — 2.01, 9.01
- 2009-11-17 0001032975-09-000023 — 1.01
- 2009-10-22 0001032975-09-000018 — 9.01
- 2009-09-22 0001193125-09-195545 — 5.02, 9.01
- 2009-09-03 0001032975-09-000013 — 8.01
- 2009-07-23 0001140361-09-016802 — 2.02, 9.01
- 2009-06-01 0001193125-09-122550 — 5.02
- 2009-04-23 0001193125-09-085054 — 2.02, 9.01
- 2009-04-02 0001193125-09-071272 — 5.02, 9.01
- 2009-01-20 0001193125-09-008454 — 2.05 — amendment of 0001193125-09-002609
- 2009-01-20 0001193125-09-007902 — 2.02, 9.01
- 2009-01-07 0001193125-09-002609 — 2.05, 9.01
- 2009-01-07 0001193125-09-002370 — 5.02, 9.01
- 2008-12-09 0001193125-08-250543 — 5.02, 9.01
- 2008-10-21 0001193125-08-213212 — 2.02, 9.01
- 2008-07-22 0001193125-08-154721 — 2.02, 9.01
- 2008-06-24 0001193125-08-139163 — 5.03, 9.01
- 2008-05-13 0001193125-08-113263 — 5.02, 9.01
- 2008-04-22 0001193125-08-086176 — 2.02, 9.01

## late-filing notifications on or before 2019-05-17

- 2015-06-02 0001032975-15-000020 — NT 10-K, for the period ended 2015-03-31
- 2014-11-06 0001193125-14-401306 — NT 10-Q, for the period ended 2014-09-30
- 2014-07-24 0001193125-14-277575 — NT 10-Q, for the period ended 2014-06-30
- 2014-05-22 0001193125-14-208712 — NT 10-K, for the period ended 2014-03-31
- 2009-08-06 0001032975-09-000006 — NT 10-Q, for the period ended 2009-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001032975-19-000017:8k_2_02:1]
EX-99.1
2
exhibit991q4fy19.htm
EXHIBIT 99.1

[0001032975-19-000017:8k_2_02:2]
Exhibit

[0001032975-19-000017:8k_2_02:3]
Exhibit 99.1

[0001032975-19-000017:8k_2_02:4]
Editorial Contacts:

[0001032975-19-000017:8k_2_02:5]
Ben Lu, Vice President, Investor Relations - USA (510) 713-5568

[0001032975-19-000017:8k_2_02:6]
Krista Todd, Vice President, Global Communications - USA (510) 713-5834

[0001032975-19-000017:8k_2_02:7]
Ben Starkie, Corporate Communications - Europe +41 (0) 79-292-3499

[0001032975-19-000017:8k_2_02:8]
Logitech Delivers New Sales Record and

[0001032975-19-000017:8k_2_02:9]
Sixth Consecutive Year of Growth

[0001032975-19-000017:8k_2_02:10]
Earnings Per Share Up Over 20%; Company Beats

[0001032975-19-000017:8k_2_02:11]
Three-Year Non-GAAP EPS Goal A Full Year Early

[0001032975-19-000017:8k_2_02:12]
LAUSANNE, Switzerland - Apr. 30, 2019 and NEWARK, Calif., Apr. 29, 2019 - Logitech International (SIX: LOGN) (Nasdaq: LOGI) today announced financial results for the fourth quarter and full year of Fiscal Year 2019, ended March 31, 2019.

[0001032975-19-000017:8k_2_02:13]
For Fiscal Year 2019:

[0001032975-19-000017:8k_2_02:14]
| • | Sales were the highest ever at $2.79 billion, up 9 percent in US dollars and 10 percent in constant currency compared to the prior year, the sixth consecutive year of growth. |

[0001032975-19-000017:8k_2_02:15]
| • | GAAP operating income grew 15 percent to $263 million, compared to $230 million a year ago. GAAP earnings per share (EPS) grew 24 percent to $1.52, compared to $1.23 a year ago. |

[0001032975-19-000017:8k_2_02:16]
| • | Non-GAAP operating income grew 23 percent to $352 million, compared to $287 million a year ago. Non-GAAP EPS grew 26 percent to $2.01, compared to $1.60 a year ago. |

[0001032975-19-000017:8k_2_02:17]
For Q4 Fiscal Year 2019:

[0001032975-19-000017:8k_2_02:18]
| • | Sales grew to $624 million, up 5 percent in US dollars and 9 percent in constant currency compared to Q4 of the prior year. |

[0001032975-19-000017:8k_2_02:19]
| • | GAAP operating income grew 8 percent to $42 million, and non-GAAP operating income grew 16 percent to $64 million, compared to Q4 of the prior year. |

[0001032975-19-000017:8k_2_02:20]
“We’ve delivered our third consecutive year of double-digit growth in constant currency and our highest fiscal year sales ever,” said Bracken Darrell, Logitech president and chief executive officer. “Our innovative, diverse product portfolio delivered, led by strong, sustainable growth in our major categories of Gaming, Video Collaboration, and Creativity & Productivity. And we are not just growing topline, but also systematically delivering strong leverage on the bottom line. In fact, we achieved our plan to double non-GAAP EPS to $2.00 a full year early. Our strategy is working, and we are excited for our future as the world’s leading cloud peripheral company.”

[0001032975-19-000017:8k_2_02:21]
Outlook

[0001032975-19-000017:8k_2_02:22]
Logitech confirmed its Fiscal Year 2020 outlook of mid to high single-digit sales growth in constant currency and $375 million to $385 million in non-GAAP operating income.

[0001032975-19-000017:8k_2_02:23]
Management Update

[0001032975-19-000017:8k_2_02:24]
Additionally, Logitech announced today that Vincent Pilette, Logitech’s chief financial officer, is leaving the Company. Vincent will leave, and cease to be a member of the Group Management Team, at the end of May, 2019, to pursue a senior leadership role at another company. Logitech has named Nate Olmstead interim chief financial officer following Vincent’s departure. Nate joined Logitech in 2019 as vice president of finance, and brings over 16 years of financial management experience, most recently as the vice president of finance for global operations at Hewlett Packard Enterprise. Nate has a BA from Stanford and an MBA from Harvard.

[0001032975-19-000017:8k_2_02:25]
“When I joined Logitech, I had a vision to turn Logitech into a design company, pursuing opportunities in the many new market opportunities enabled by the cloud,” said Bracken Darrell. “We needed financial and operational strength to support the ambition of that vision. Vincent has been a terrific partner for this pursuit these past six years, and we’ve made great progress. But more important than his partnership and leadership is the team he built and the culture of rigor and discipline he helped instill throughout the company. We now have a strong, seasoned finance team across every area and a proven track record of operational excellence. That is his most important legacy. I’m excited for him in his next challenge. And I’m even more energized by our continued progress toward our design company vision."

[0001032975-19-000017:8k_2_02:26]
Prepared Remarks Available Online

[0001032975-19-000017:8k_2_02:27]
Logitech has made its prepared written remarks for the financial results teleconference available online on the Logitech corporate website at http://ir.logitech.com.

[0001032975-19-000017:8k_2_02:28]
Financial Results Teleconference and Webcast

[0001032975-19-000017:8k_2_02:29]
Logitech will hold a financial results teleconference to discuss the results for Q4 and the full Fiscal Year 2019 on Tuesday, April 30, 2019 at 8:30 a.m. Eastern Daylight Time and 2:30 p.m. Central European Summer Time. A live webcast of the call will be available on the Logitech corporate website at http://ir.logitech.com.

[0001032975-19-000017:8k_2_02:30]
Use of Non-GAAP Financial Information and Constant Currency

[0001032975-19-000017:8k_2_02:31]
To facilitate comparisons to Logitech’s historical results, Logitech has included non-GAAP adjusted measures, which exclude share-based compensation expense, amortization of intangible assets, purchase accounting effect on inventory, acquisition-related costs, change in fair value of contingent consideration for business acquisition, restructuring charges (credits), loss (gain) on investments in privately held companies, non-GAAP income tax adjustment, and other items detailed under “Supplemental Financial Information” after the tables below. Logitech also presents percentage sales growth in constant currency to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales. Logitech believes this information, used together with the GAAP financial information, will help investors to evaluate its current period performance and trends in its business. With respect to the

[0001032975-19-000017:8k_2_02:32]
Company’s outlook for non-GAAP operating income, most of these excluded amounts pertain to events that have not yet occurred and are not currently possible to estimate with a reasonable degree of accuracy. Therefore, no reconciliation to the GAAP amounts has been provided for Fiscal Year 2020.

[0001032975-19-000017:8k_2_02:33]
About Logitech

[0001032975-19-000017:8k_2_02:34]
Logitech designs products that have an everyday place in people's lives, connecting them to the digital experiences they care about. More than 35 years ago, Logitech started connecting people through computers, and now it’s a multi-brand company designing products that bring people together through music, gaming, video and computing. Brands of Logitech include Logitech, Ultimate Ears, Jaybird, Blue Microphones, ASTRO Gaming and Logitech G. Founded in 1981, and headquartered in Lausanne, Switzerland, Logitech International is a Swiss public company listed on the SIX Swiss Exchange (LOGN) and on the Nasdaq Global Select Market (LOGI). Find Logitech at www.logitech.com, the company blog or @Logitech.

[0001032975-19-000017:8k_2_02:35]
# # #

[0001032975-19-000017:8k_2_02:36]
Note that unless noted otherwise, comparisons are year over year.

[0001032975-19-000017:8k_2_02:37]
Logitech and other Logitech marks are trademarks or registered trademarks of Logitech Europe S.A and/or its affiliates in the U.S. and other countries.  All other trademarks are the property of their respective owners. For more information about Logitech and its products, visit the company’s website atwww.logitech.com.

[0001032975-19-000017:8k_2_02:38]
(LOGIIR)

[0001032975-19-000017:8k_2_02:39]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  | Fiscal Years Ended |
|  |  | March 31, |  | March 31, |
| GAAP CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Net sales (A) |  | $ | 624,308 |  |  | $ | 592,426 |  |  | $ | 2,788,322 |  |  | $ | 2,566,863 |  |
| Cost of goods sold |  | 388,028 |  |  | 377,617 |  |  | 1,737,969 |  |  | 1,648,744 |  |
| Amortization of intangible assets and purchase accounting effect on inventory |  | 3,305 |  |  | 2,574 |  |  | 13,342 |  |  | 8,878 |  |
| Gross profit |  | 232,975 |  |  | 212,235 |  |  | 1,037,011 |  |  | 909,241 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Marketing and selling |  | 119,628 |  |  | 109,572 |  |  | 488,263 |  |  | 435,489 |  |
| Research and development |  | 42,110 |  |  | 37,616 |  |  | 161,230 |  |  | 143,760 |  |
| General and administrative |  | 23,557 |  |  | 23,387 |  |  | 98,732 |  |  | 96,353 |  |
| Amortization of intangible assets and acquisition-related costs |  | 3,913 |  |  | 2,553 |  |  | 14,290 |  |  | 8,930 |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | — |  |  | — |  |  | (4,908 | ) |
| Restructuring charges (credits), net |  | 1,540 |  |  | — |  |  | 11,302 |  |  | (116 | ) |
| Total operating expenses |  | 190,748 |  |  | 173,128 |  |  | 773,817 |  |  | 679,508 |  |
| Operating income |  | 42,227 |  |  | 39,107 |  |  | 263,194 |  |  | 229,733 |  |
| Interest income |  | 2,666 |  |  | 1,872 |  |  | 8,375 |  |  | 4,969 |  |
| Other income (expense), net |  | 493 |  |  | (1,543 | ) |  | (436 | ) |  | (2,437 | ) |
| Income before income taxes |  | 45,386 |  |  | 39,436 |  |  | 271,133 |  |  | 232,265 |  |
| Provision for income taxes |  | 3,265 |  |  | 5,032 |  |  | 13,560 |  |  | 23,723 |  |
| Net income |  | $ | 42,121 |  |  | $ | 34,404 |  |  | $ | 257,573 |  |  | $ | 208,542 |  |
| Net income per share : |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.25 |  |  | $ | 0.21 |  |  | $ | 1.56 |  |  | $ | 1.27 |  |
| Diluted |  | $ | 0.25 |  |  | $ | 0.20 |  |  | $ | 1.52 |  |  | $ | 1.23 |  |
| Weighted average shares used to compute net income per share: |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | 165,776 |  |  | 164,374 |  |  | 165,609 |  |  | 164,038 |  |
| Diluted |  | 168,956 |  |  | 169,387 |  |  | 168,965 |  |  | 168,971 |  |

[0001032975-19-000017:8k_2_02:40]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |
|  |  | March 31, |  | March 31, |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  | 2019 |  | 2018 |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 604,516 |  |  | $ | 641,947 |  |
| Accounts receivable, net (A) |  | 383,309 |  |  | 214,885 |  |
| Inventories |  | 293,495 |  |  | 259,906 |  |
| Other current assets (A) |  | 69,116 |  |  | 56,362 |  |
| Total current assets |  | 1,350,436 |  |  | 1,173,100 |  |
| Non-current assets: |  |  |  |  |  |
| Property, plant and equipment, net |  | 78,552 |  |  | 86,304 |  |
| Goodwill |  | 343,684 |  |  | 275,451 |  |
| Other intangible assets, net |  | 118,999 |  |  | 87,547 |  |
| Other assets |  | 132,453 |  |  | 120,755 |  |
| Total assets |  | $ | 2,024,124 |  |  | $ | 1,743,157 |  |
| Current liabilities: |  |  |  |  |  |  |
| Accounts payable |  | $ | 283,922 |  |  | $ | 293,988 |  |
| Accrued and other current liabilities (A) |  | 433,897 |  |  | 281,732 |  |
| Total current liabilities |  | 717,819 |  |  | 575,720 |  |
| Non-current liabilities: |  |  |  |  |  |  |
| Income taxes payable |  | 36,384 |  |  | 34,956 |  |
| Other non-current liabilities |  | 93,582 |  |  | 81,924 |  |
| Total liabilities |  | 847,785 |  |  | 692,600 |  |
| Shareholders' equity: |  |  |  |  |
| Registered shares, CHF 0.25 par value: |  | 30,148 |  |  | 30,148 |  |
| Issued shares—173,106 at March 31, 2019 and 2018 |  |  |  |  |
| Additional shares that may be issued out of conditional capitals — 50,000 at March 31, 2019 and March 31, 2018 |  |  |  |  |
| Additional shares that may be issued out of authorized capital — 34,621 at March 31, 2019 and none at March 31, 2018 |  |  |  |  |
| Additional paid-in capital |  | 56,655 |  |  | 47,234 |  |
| Shares in treasury, at cost— 7,244 and 8,527 shares at March 31, 2019 and 2018, respectively |  | (169,802 | ) |  | (165,686 | ) |
| Retained earnings (A) |  | 1,365,036 |  |  | 1,232,316 |  |
| Accumulated other comprehensive loss |  | (105,698 | ) |  | (93,455 | ) |
| Total shareholders' equity |  | 1,176,339 |  |  | 1,050,557 |  |
| Total liabilities and shareholders' equity |  | $ | 2,024,124 |  |  | $ | 1,743,157 |  |

[0001032975-19-000017:8k_2_02:41]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  | Fiscal Years Ended |
|  |  | March 31, |  | March 31, |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 42,121 |  |  | $ | 34,404 |  |  | $ | 257,573 |  |  | $ | 208,542 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |
| Depreciation |  | 10,816 |  |  | 11,077 |  |  | 43,471 |  |  | 41,295 |  |
| Amortization of intangible assets |  | 6,944 |  |  | 4,954 |  |  | 24,180 |  |  | 15,607 |  |
| Share-based compensation expense |  | 13,102 |  |  | 10,899 |  |  | 50,265 |  |  | 44,138 |  |
| Gain on investments |  | (227 | ) |  | (119 | ) |  | (816 | ) |  | (669 | ) |
| Deferred income taxes |  | (2,535 | ) |  | 413 |  |  | (12,257 | ) |  | 7,141 |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | — |  |  | — |  |  | (4,908 | ) |
| Other |  | 148 |  |  | (18 | ) |  | (230 | ) |  | (11 | ) |
| Changes in assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | 100,146 |  |  | 137,665 |  |  | (58,798 | ) |  | (26,363 | ) |
| Inventories |  | 47,612 |  |  | 21,739 |  |  | (21,551 | ) |  | 16,047 |  |
| Other assets |  | 2,298 |  |  | 2,045 |  |  | (8,800 | ) |  | (16,908 | ) |
| Accounts payable |  | (152,791 | ) |  | (134,016 | ) |  | (19,134 | ) |  | 17,695 |  |
| Accrued and other liabilities |  | (35,896 | ) |  | 1,134 |  |  | 51,278 |  |  | 44,655 |  |
| Net cash provided by operating activities |  | 31,738 |  | — |  | 90,177 |  |  | 305,181 |  |  | 346,261 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  | (7,626 | ) |  | (12,155 | ) |  | (35,930 | ) |  | (39,748 | ) |
| Acquisitions, net of cash acquired |  | 94 |  |  | — |  |  | (133,814 | ) |  | (88,323 | ) |
| Investment in privately held companies |  | (175 | ) |  | (360 | ) |  | (2,717 | ) |  | (1,240 | ) |
| Proceeds from return of investments |  | 124 |  |  | — |  |  | 124 |  |  | 237 |  |
| Purchases of short-term investments |  | — |  |  | — |  |  | (1,505 | ) |  | (6,789 | ) |
| Sales of short-term investments |  | — |  |  | — |  |  | — |  |  | 6,789 |  |
| Purchases of trading investments |  | (868 | ) |  | (3,211 | ) |  | (5,203 | ) |  | (6,053 | ) |
| Proceeds from sales of trading investments |  | 862 |  |  | 3,214 |  |  | 5,700 |  |  | 6,423 |  |
| Net cash used in investing activities |  | (7,589 | ) | — |  | (12,512 | ) |  | (173,345 | ) |  | (128,704 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |
| Payment of cash dividends |  | — |  |  | — |  |  | (113,971 | ) |  | (104,248 | ) |
| Payment of contingent consideration for business acquisition |  | — |  |  | — |  |  | — |  |  | (5,000 | ) |
| Purchases of registered shares |  | (9,995 | ) |  | (10,314 | ) |  | (32,449 | ) |  | (30,722 | ) |
| Proceeds from exercises of stock options and purchase rights |  | 7,922 |  |  | 10,963 |  |  | 18,057 |  |  | 41,910 |  |
| Tax withholdings related to net share settlements of restricted stock units |  | (1,659 | ) |  | (4,308 | ) |  | (30,770 | ) |  | (29,813 | ) |
| Net cash used in financing activities |  | (3,732 | ) |  | (3,659 | ) |  | (159,133 | ) |  | (127,873 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  | (389 | ) |  | 3,053 |  |  | (10,134 | ) |  | 4,730 |  |
| Net increase (decrease) in cash and cash equivalents |  | 20,028 |  |  | 77,059 |  |  | (37,431 | ) |  | 94,414 |  |
| Cash and cash equivalents at beginning of the period |  | 584,488 |  |  | 564,888 |  |  | 641,947 |  |  | 547,533 |  |
| Cash and cash equivalents at end of the period |  | $ | 604,516 |  |  | $ | 641,947 |  |  | $ | 604,516 |  |  | $ | 641,947 |  |

[0001032975-19-000017:8k_2_02:42]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |  |  |
| NET SALES |  | Three Months Ended |  | Fiscal Years Ended |
|  |  | March 31, |  | March 31, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2019 |  | 2018 |  | Change |  | 2019 |  | 2018 |  | Change |
| Net sales by product category: |  |  |  |  |  |  |  |  |  |  |  |  |
| Pointing Devices |  | $ | 131,640 |  |  | $ | 129,937 |  |  | 1 | % |  | $ | 536,890 |  |  | $ | 516,637 |  |  | 4 | % |
| Keyboards & Combos |  | 132,356 |  |  | 136,787 |  |  | (3 | ) |  | 536,619 |  |  | 498,472 |  |  | 8 |  |
| PC Webcams |  | 30,366 |  |  | 31,776 |  |  | (4 | ) |  | 121,282 |  |  | 112,147 |  |  | 8 |  |
| Tablet & Other Accessories |  | 23,412 |  |  | 27,292 |  |  | (14 | ) |  | 128,315 |  |  | 107,942 |  |  | 19 |  |
| Video Collaboration |  | 69,367 |  |  | 54,709 |  |  | 27 |  |  | 259,521 |  |  | 182,717 |  |  | 42 |  |
| Mobile Speakers |  | 22,688 |  |  | 13,974 |  |  | 62 |  |  | 230,378 |  |  | 314,817 |  |  | (27 | ) |
| Audio & Wearables |  | 65,086 |  |  | 55,248 |  |  | 18 |  |  | 277,429 |  |  | 252,330 |  |  | 10 |  |
| Gaming |  | 137,649 |  |  | 126,763 |  |  | 9 |  |  | 648,130 |  |  | 491,995 |  |  | 32 |  |
| Smart Home |  | 11,515 |  |  | 15,892 |  |  | (28 | ) |  | 49,344 |  |  | 89,373 |  |  | (45 | ) |
| Other (1) |  | 229 |  |  | 48 |  |  | 377 |  |  | 414 |  |  | 433 |  |  | (4 | ) |
| Total net retail sales |  | $ | 624,308 |  |  | $ | 592,426 |  |  | 5 |  |  | $ | 2,788,322 |  |  | $ | 2,566,863 |  |  | 9 |  |
| __________________ |  |  |  |  |  |  |  |  |  |  |  |  |

[0001032975-19-000017:8k_2_02:43]
(1) Other category includes products that we currently intend to transition out of, or have already transitioned out of, because they are no longer strategic to our business.

[0001032975-19-000017:8k_2_02:44]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands, except per share amounts) - Unaudited |  |  |  |  |  |  |  |  |
| GAAP TO NON GAAP RECONCILIATION (A)(B) |  | Three Months Ended |  | Fiscal Years Ended |
|  |  | March 31, |  | March 31, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Gross profit - GAAP |  | $ | 232,975 |  |  | $ | 212,235 |  |  | $ | 1,037,011 |  |  | $ | 909,241 |  |
| Share-based compensation expense |  | 938 |  |  | 971 |  |  | 3,812 |  |  | 3,733 |  |
| Amortization of intangible assets and purchase accounting effect on inventory |  | 3,305 |  |  | 2,574 |  |  | 13,342 |  |  | 8,878 |  |
| Gross profit - Non-GAAP |  | $ | 237,218 |  |  | $ | 215,780 |  |  | $ | 1,054,165 |  |  | $ | 921,852 |  |
| Gross margin - GAAP |  | 37.3 | % |  | 35.8 | % |  | 37.2 | % |  | 35.4 | % |
| Gross margin - Non-GAAP |  | 38.0 | % |  | 36.4 | % |  | 37.8 | % |  | 35.9 | % |
| Operating expenses - GAAP |  | $ | 190,748 |  |  | $ | 173,128 |  |  | $ | 773,817 |  |  | $ | 679,508 |  |
| Less: Share-based compensation expense |  | 12,164 |  |  | 9,928 |  |  | 46,453 |  |  | 40,405 |  |
| Less: Amortization of intangible assets and acquisition-related costs |  | 3,913 |  |  | 2,553 |  |  | 14,290 |  |  | 8,930 |  |
| Less: Change in fair value of contingent consideration for business acquisition |  | — |  |  | — |  |  | — |  |  | (4,908 | ) |
| Less: Restructuring charges (credits), net |  | 1,540 |  |  | — |  |  | 11,302 |  |  | (116 | ) |
| Operating expenses - Non-GAAP |  | $ | 173,131 |  |  | $ | 160,647 |  |  | $ | 701,772 |  |  | $ | 635,197 |  |
| % of net sales - GAAP |  | 30.6 | % |  | 29.2 | % |  | 27.8 | % |  | 26.5 | % |
| % of net sales - Non - GAAP |  | 27.7 | % |  | 27.1 | % |  | 25.2 | % |  | 24.7 | % |
| Operating income - GAAP |  | $ | 42,227 |  |  | $ | 39,107 |  |  | $ | 263,194 |  |  | $ | 229,733 |  |
| Share-based compensation expense |  | 13,102 |  |  | 10,899 |  |  | 50,265 |  |  | 44,138 |  |
| Amortization of intangible assets |  | 6,944 |  |  | 4,954 |  |  | 24,180 |  |  | 15,607 |  |
| Purchase accounting effect on inventory |  | 34 |  |  | 173 |  |  | 1,756 |  |  | 789 |  |
| Acquisition-related costs |  | 240 |  |  | — |  |  | 1,696 |  |  | 1,412 |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | — |  |  | — |  |  | (4,908 | ) |
| Restructuring charges (credits), net |  | 1,540 |  |  | — |  |  | 11,302 |  |  | (116 | ) |
| Operating income - Non - GAAP |  | $ | 64,087 |  |  | $ | 55,133 |  |  | $ | 352,393 |  |  | $ | 286,655 |  |
| % of net sales - GAAP |  | 6.8 | % |  | 6.6 | % |  | 9.4 | % |  | 8.9 | % |
| % of net sales - Non - GAAP |  | 10.3 | % |  | 9.3 | % |  | 12.6 | % |  | 11.2 | % |
| Net income - GAAP |  | $ | 42,121 |  |  | $ | 34,404 |  |  | $ | 257,573 |  |  | $ | 208,542 |  |
| Share-based compensation expense |  | 13,102 |  |  | 10,899 |  |  | 50,265 |  |  | 44,138 |  |
| Amortization of intangible assets |  | 6,944 |  |  | 4,954 |  |  | 24,180 |  |  | 15,607 |  |
| Purchase accounting effect on inventory |  | 34 |  |  | 173 |  |  | 1,756 |  |  | 789 |  |
| Acquisition-related costs |  | 240 |  |  | — |  |  | 1,696 |  |  | 1,412 |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | — |  |  | — |  |  | (4,908 | ) |
| Restructuring charges (credits), net |  | 1,540 |  |  | — |  |  | 11,302 |  |  | (116 | ) |
| Gain on investments |  | (227 | ) |  | (119 | ) |  | (816 | ) |  | (669 | ) |
| Non-GAAP income tax adjustment |  | 830 |  |  | 4,249 |  |  | (6,952 | ) |  | 6,282 |  |
| Net income - Non - GAAP |  | $ | 64,584 |  |  | $ | 54,560 |  |  | $ | 339,004 |  |  | $ | 271,077 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  | $ | 0.25 |  |  | $ | 0.20 |  |  | $ | 1.52 |  |  | $ | 1.23 |  |
| Diluted - Non - GAAP |  | $ | 0.38 |  |  | $ | 0.32 |  |  | $ | 2.01 |  |  | $ | 1.60 |  |
| Shares used to compute net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP and Non - GAAP |  | 168,956 |  |  | 169,387 |  |  | 168,965 |  |  | 168,971 |  |

[0001032975-19-000017:8k_2_02:45]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
| SHARE-BASED COMPENSATION EXPENSE |  | Three Months Ended |  | Fiscal Years Ended |
|  |  | March 31, |  | March 31, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Share-based Compensation Expense |  |  |  |  |  |  |  |  |
| Cost of goods sold |  | $ | 938 |  |  | $ | 971 |  |  | $ | 3,812 |  |  | $ | 3,733 |  |
| Marketing and selling |  | 5,380 |  |  | 4,417 |  |  | 20,630 |  |  | 17,765 |  |
| Research and development |  | 2,073 |  |  | 1,584 |  |  | 7,368 |  |  | 6,381 |  |
| General and administrative |  | 4,711 |  |  | 3,927 |  |  | 18,455 |  |  | 16,259 |  |
| Total share-based compensation expense |  | 13,102 |  |  | 10,899 |  |  | 50,265 |  |  | 44,138 |  |
| Income tax benefit |  | (2,515 | ) |  | (4,077 | ) |  | (17,091 | ) |  | (15,998 | ) |
| Total share-based compensation expense, net of income tax benefit |  | $ | 10,587 |  |  | $ | 6,822 |  |  | $ | 33,174 |  |  | $ | 28,140 |  |

[0001032975-19-000017:8k_2_02:46]
*Note: These preliminary results for the three months and fiscal year ended March 31, 2019 are subject to adjustments, including subsequent events that may occur through the date of filing our Annual Report on Form 10-K.

[0001032975-19-000017:8k_2_02:47]
(A) Adoption of ASC Topic 606

[0001032975-19-000017:8k_2_02:48]
On April 1, 2018, we adopted the new revenue standards under Accounting Standards Codification ("ASC") Topic 606. The adoption of Topic 606 did not have an impact over the total cash flows from operating, investing, or financing activities. The following tables summarize the impacts of adopting Topic 606 on our condensed consolidated statements of operations for the three months and fiscal year ended  March 31, 2019 and condensed consolidated balance sheets as of March 31, 2019 (in thousands):

[0001032975-19-000017:8k_2_02:49]
|  | Three Months Ended March 31, 2018 |  | Year Ended March 31, 2019 |
|  | As Reported Under Topic 606 | If Reported Under Topic 605 | Effect of Change |  | As Reported Under Topic 606 | If Reported Under Topic 605 | Effect of Change |
| Net sales | $ | 624,308 |  | $ | 626,369 |  | $ | (2,061 | ) |  | $ | 2,788,322 |  | $ | 2,784,636 |  | $ | 3,686 |  |

[0001032975-19-000017:8k_2_02:50]
|  |  | As of March 31, 2019 |
|  |  | As Reported Under Topic 606 |  | Balance Under Topic 605 |  | Effect of Change |
| Accounts receivable, net |  | $ | 383,309 |  |  | $ | 260,401 |  |  | $ | 122,908 |  |
| Other current assets |  | $ | 69,116 |  |  | $ | 60,449 |  |  | $ | 8,667 |  |
| Accrued and other current liabilities |  | $ | 433,897 |  |  | $ | 295,126 |  |  | $ | 138,771 |  |
| Retained earnings |  | $ | 1,365,036 |  |  | $ | 1,372,232 |  |  | $ | (7,196 | ) |

[0001032975-19-000017:8k_2_02:51]
(B) Non-GAAP Financial Measures

[0001032975-19-000017:8k_2_02:52]
To supplement our condensed consolidated financial results prepared in accordance with GAAP, we use a number of financial measures, both GAAP and non-GAAP, in analyzing and assessing our overall business performance, for making operating decisions and for forecasting and planning future periods. We consider the use of non-GAAP financial measures helpful in assessing our current financial performance, ongoing operations and prospects for the future as well as understanding financial and business trends relating to our financial condition and results of operations.

[0001032975-19-000017:8k_2_02:53]
While we use non-GAAP financial measures as a tool to enhance our understanding of certain aspects of our financial performance and to provide incremental insight into the underlying factors and trends affecting both our performance and our cash-generating potential, we do not consider these measures to be a substitute for, or superior to, the information provided by GAAP financial measures. Consistent with this approach, we believe that disclosing non-GAAP financial measures to the readers of our financial statements provides useful supplemental data that, while not a substitute for GAAP financial measures, can offer insight in the review of our financial and operational performance and enables investors to more fully understand trends

[0001032975-19-000017:8k_2_02:54]
in our current and future performance. In assessing our business during the quarter ended March 31, 2019 and previous periods, we excluded items in the following general categories, each of which are described below:

[0001032975-19-000017:8k_2_02:55]
Share-based compensation expenses. We believe that providing non-GAAP measures excluding share-based compensation expense, in addition to the GAAP measures, allows for a more transparent comparison of our financial results from period to period. We prepare and maintain our budgets and forecasts for future periods on a basis consistent with this non-GAAP financial measure. Further, companies use a variety of types of equity awards as well as a variety of methodologies, assumptions and estimates to determine share-based compensation expense. We believe that excluding share-based compensation expense enhances our ability and the ability of investors to understand the impact of non-cash share-based compensation on our operating results and to compare our results against the results of other companies.

[0001032975-19-000017:8k_2_02:56]
Amortization of intangible assets. We incur intangible asset amortization expense, primarily in connection with our acquisitions of various businesses and technologies. The amortization of purchased intangibles varies depending on the level of acquisition activity. We exclude these various charges in budgeting, planning and forecasting future periods and we believe that providing the non-GAAP measures excluding these various non-cash charges, as well as the GAAP measures, provides additional insight when comparing our gross profit, operating expenses, and financial results from period to period.

[0001032975-19-000017:8k_2_02:57]
Purchase accounting effect on inventory. Business combination accounting principles require us to measure acquired inventory at fair value. The fair value of inventory reflects the acquired company’s cost of manufacturing plus a portion of the expected profit margin. The non-GAAP adjustment excludes the expected profit margin component that is recorded under business combination accounting principles associated with our business acquisitions. We believe the adjustment is useful to investors because such charges are not reflective of our ongoing operations.

[0001032975-19-000017:8k_2_02:58]
Acquisition-related costs and change in fair value of contingent consideration for business acquisition.  We incurred expenses and credits in connection with our acquisitions which we generally would not have otherwise incurred in the periods presented as a part of our continuing operations. Acquisition related costs include all incremental expenses incurred to effect a business combination. Fair value of contingent consideration is associated with our estimates of the value of earn-outs in connection with certain acquisitions. We believe that providing the non-GAAP measures excluding these costs and credits, as well as the GAAP measures, assists our investors because such costs are not reflective of our ongoing operating results.

[0001032975-19-000017:8k_2_02:59]
Restructuring charges (credits). These expenses are associated with re-aligning our business strategies based on current economic conditions. We have undertaken several restructuring plans in recent years. In connection with our restructuring initiatives, we incurred restructuring charges related to employee terminations, facility closures and early cancellation of certain contracts. We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges (credits) are not reflective of our ongoing operating results in the current period.

[0001032975-19-000017:8k_2_02:60]
Loss (gain) on investments. We recognized loss (gain) related to our investments in various companies, which varies depending on the operational and financial performance of those companies in which we invested. We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges are not reflective of our ongoing operations.

[0001032975-19-000017:8k_2_02:61]
Non-GAAP income tax adjustment.  Non-GAAP income tax adjustment primarily measures the income tax effect of non-GAAP adjustments excluded above and other events; the determination of which is based upon the nature of the underlying items, the mix of income and losses in jurisdictions and the relevant tax rates in which we operate.

[0001032975-19-000017:8k_2_02:62]
Each of the non-GAAP financial measures described above, and used in this press release, should not be considered in isolation from, or as a substitute for, a measure of financial performance prepared in accordance with GAAP. Further, investors are cautioned that there are inherent limitations associated with the use of each of these non-GAAP financial measures as an analytical tool. In particular, these non-GAAP financial measures are not based on a comprehensive set of accounting rules or principles and many of the adjustments to the GAAP financial measures reflect the exclusion of items that are recurring and may be reflected in the Company’s financial results for the foreseeable future. We compensate for these limitations by providing specific information in the reconciliation included in this press release regarding the GAAP amounts excluded from the non-GAAP financial measures. In addition, as noted above, we evaluate the non-GAAP financial measures together with the most directly comparable GAAP financial information.

[0001032975-19-000017:8k_2_02:63]
Additional Supplemental Financial Information - Constant Currency

[0001032975-19-000017:8k_2_02:64]
In addition, Logitech presents percentage sales growth in constant currency to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales.

## item 5.02 — body, verbatim

[0001032975-19-000017:8k_body:1]
ITEM 5.02. DEPARTURE OF DIRECTORS OR CERTAIN OFFICERS; ELECTION OF DIRECTORS; APPOINTMENT OF CERTAIN OFFICERS; COMPENSATORY ARRANGEMENTS OF CERTAIN OFFICERS

[0001032975-19-000017:8k_body:2]
On April 29, 2019, Vincent Pilette delivered his resignation as Chief Financial Officer and submitted his resignation from the Company’s Group Management Team. Logitech accepted this resignation on April 29, 2019.  Mr. Pilette’s resignation as Chief Financial Officer and from the Group Management Team will be effective following the filing of Logitech’s Annual Report on Form 10-K for the fiscal year ended March 31, 2019, which is required to be filed by May 30, 2019.

[0001032975-19-000017:8k_body:3]
Logitech has appointed Nate Olmstead, Logitech’s Vice President of Business Finance, as interim Chief Financial Officer, effective as of June 1, 2019.  Prior to joining Logitech in April 2019, Mr. Olmstead, age 47, served in various financial management roles at Hewlett-Packard Company and Hewlett-Packard Enterprise, a multinational information technology company, most recently as the Vice President of Finance for Global Operations at Hewlett-Packard Enterprise from June 2017 to March 2019.  Mr. Olmstead also served as Vice President of Finance, EG Global Supply Chain and Quality from February 2015 to June 2017, Vice President of Finance, HP Storage and HP Converged Systems from 2009 to February 2015, and Director, HP Investor Relations from 2006 to 2009.   Mr. Olmstead holds a BA degree from Stanford University and an MBA from Harvard Business School.
