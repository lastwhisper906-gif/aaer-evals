# LOGI notes — 0001032975-19-000027


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001032975-19-000027:notes:1]
Summary of Significant Accounting Policies
Basis of Presentation

[0001032975-19-000027:notes:2]
The consolidated financial statements include the accounts of Logitech and its subsidiaries. All intercompany balances and transactions have been eliminated. The consolidated financial statements are presented in accordance with accounting principles generally accepted in the United States (U.S. GAAP).

[0001032975-19-000027:notes:3]
Fiscal Year

[0001032975-19-000027:notes:4]
The Company's fiscal year ends on March 31. Interim quarters are generally thirteen-week periods, each ending on a Friday. For purposes of presentation, the Company has indicated its quarterly periods end on the last day of the calendar quarter.

[0001032975-19-000027:notes:5]
Reclassification

[0001032975-19-000027:notes:6]
Certain amounts from the comparative periods in the accompanying consolidated financial statements have been reclassified to conform to the consolidated financial statement presentation as of and for the year ended March 31, 2019, due to the adoption of the new accounting pronouncements during the year.

[0001032975-19-000027:notes:7]
Use of Estimates

[0001032975-19-000027:notes:8]
The preparation of financial statements in conformity with U.S. GAAP requires management to make judgments, estimates and assumptions that affect the amounts reported in the consolidated financial statements. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Significant estimates and assumptions made by management involve the fair value of goodwill, intangible assets acquired from business acquisitions, warranty liabilities, accruals for customer incentives, cooperative marketing, and pricing programs (Customer Programs) and related breakage when appropriate, sales return reserves, allowance for doubtful accounts, inventory valuation, contingent consideration from business acquisitions and periodical reassessment of its fair value, share-based compensation expense, uncertain tax positions, and valuation allowances for deferred tax assets. Although these estimates are based on management’s

[0001032975-19-000027:notes:9]
best knowledge of current events and actions that may impact the Company in the future, actual results could differ materially from those estimates.

[0001032975-19-000027:notes:10]
Currencies

[0001032975-19-000027:notes:11]
The functional currency of the Company's operations is primarily the U.S. Dollar. Certain operations use the Euro, Chinese Renminbi, Swiss Franc, or other local currencies as their functional currencies. The financial statements of the Company's subsidiaries whose functional currency is other than the U.S. Dollar are translated to U.S. Dollars using period-end rates of exchange for assets and liabilities and monthly average rates for sales, income and expenses. Cumulative translation gains and losses are included as a component of shareholders' equity in accumulated other comprehensive loss. Gains and losses arising from transactions denominated in currencies other than a subsidiary's functional currency are reported in other income (expense), net in the consolidated statements of operations.

[0001032975-19-000027:notes:12]
Revenue Recognition

[0001032975-19-000027:notes:13]
Revenue is recognized when a customer obtains control of promised goods or service in an amount that reflects the transaction price the Company expects to receive in exchange for those goods or services.

[0001032975-19-000027:notes:14]
Substantially all revenue recognized by the Company relates to the contracts with customers to sell products that allow people to connect through music, gaming, video, computing, and other digital platforms. These products are hardware devices, which may include embedded software that function together, and are considered as one performance obligation. Hardware devices are generally plug and play, requiring no configuration and little or no installation. Revenue is recognized at a point in time when control of the products is transferred to the customer which generally occurs upon shipment. The Company’s sales contracts with its customers have a one year or shorter term. The Company applies the practical expedient of not disclosing the value of unsatisfied performance obligations for contracts with an original expected duration of one year or less.

[0001032975-19-000027:notes:15]
The Company also provides post-contract customer support (“PCS”) for certain products and related software, which includes unspecified software updates and upgrades, bug fixes and maintenance. The transaction price is allocated to two performance obligations in such contracts, based on a relative standalone selling price. The transaction price allocated to PCS is recognized as revenue on a straight-line basis, which reflects the pattern of delivery of PCS, over the estimated term of the support that is between one to two years. Deferred revenue associated with remaining PCS performance obligation as of March 31, 2019 and March 31, 2018 was not material.

[0001032975-19-000027:notes:16]
The Company normally requires payment from customers within thirty to sixty days from the invoice date. However, terms may vary by customer type, by country and by selling season. Extended payment terms are sometimes offered to a limited number of customers during the second and third fiscal quarters. The Company does not modify payment terms on existing receivables. The Company's contracts with customers do not include significant financing components as the period between the satisfaction of performance obligations and timing of payment are generally within one year.

[0001032975-19-000027:notes:17]
The transaction price received by the Company from sales to its distributors, retail companies ("retailers"), and authorized resellers is calculated as selling price net of variable consideration which may include product returns and the Company’s payments for Customer Programs related to current period product revenue. The estimated impact of these programs is recorded as a reduction of transaction price or as an operating expense if the Company receives a distinct good or service from the customer and can reasonably estimate the fair value of that good or service received. Certain Customer Programs require management to estimate the percentage of those programs which will not be claimed or will not be earned by customers based on historical experience and on the specific terms and conditions of particular programs. The percentage of these Customer Programs that will not be claimed or earned is commonly referred to as "breakage". The Company accounts for breakage as part of variable consideration, subject to constraint, and records the estimated impact in the same period when revenue is recognized at the expected value. Significant management judgments and estimates are used to determine the impact of the program and breakage in any accounting period.

[0001032975-19-000027:notes:18]
The Company enters into cooperative marketing arrangements with many of its customers and with certain indirect partners, allowing customers to receive a credit equal to a set percentage of their purchases of the Company's products, or a fixed dollar amount for various marketing and incentive programs. The objective of these arrangements is to encourage advertising and promotional events to increase sales of the Company's products.

[0001032975-19-000027:notes:19]
Customer incentive programs include consumer rebates and performance-based incentives. Consumer rebates are offered to the Company's customers and indirect partners at the Company's discretion for the primary benefit of end-users. In addition, the Company offers performance-based incentives to many of its customers and indirect partners based on predetermined performance criteria. At management's discretion, the Company also offers special pricing discounts to certain customers. Special pricing discounts are usually offered only for limited time periods or for sales of selected products to specific indirect partners.

[0001032975-19-000027:notes:20]
Cooperative marketing arrangements and customer incentive programs are considered variable consideration, which the Company estimates and records as a reduction to revenue at the time of sale based on negotiated terms, historical experiences, forecasted incentives, anticipated volume of future purchases, and inventory levels in the channel.

[0001032975-19-000027:notes:21]
The Company has agreements with certain customers that contain terms allowing price protection credits to be issued in the event of a subsequent price reduction. Management's decision to make price reductions is influenced by product life cycle stage, market acceptance of products, the competitive environment, new product introductions and other factors. Accruals for estimated expected future pricing actions are recognized at the time of sale based on analyses of historical pricing actions by customer and by product, inventories owned by and located at customers, current customer demand, current operating conditions, and other relevant customer and product information, such as stage of product life-cycle.

[0001032975-19-000027:notes:22]
Product return rights vary by customer. Estimates of expected future product returns qualify as variable consideration and are recorded as a reduction of the transaction price of the contract at the time of sale based on an analyses of historical return trends by customer and by product, inventories owned by and located at customers, current customer demand, current operating conditions, and other relevant customer and product information. The Company assesses the estimated asset for recovery value for impairment, and adjusts the value of the asset for any impairment. Return trends are influenced by product life cycle status, new product introductions, market acceptance of products, sales levels, product sell-through, the type of customer, seasonality, product quality issues, competitive pressures, operational policies and procedures, and other factors. Return rates can fluctuate over time but are sufficiently predictable to allow the Company to estimate expected future product returns.

[0001032975-19-000027:notes:23]
Typically, variable consideration does not need to be constrained as estimates are based on predictive historical data or future commitments that are planned and controlled by the Company. However, the Company continues to assess variable consideration estimates such that it is probable that a significant reversal of revenue will not occur.

[0001032975-19-000027:notes:24]
The Company regularly evaluates the adequacy of its estimates for Customer Programs and product returns. Future market conditions and product transitions may require the Company to take action to change such programs and related estimates. When the variables used to estimate these costs change, or if actual costs differ significantly from the estimates, the Company would be required to increase or reduce revenue or operating expenses to reflect the impact. During the year ended March 31, 2019, changes to these estimates related to performance obligations satisfied in prior periods were not material.

[0001032975-19-000027:notes:25]
Sales taxes and value-added taxes (“VAT”) collected from customers, if applicable, which are remitted to governmental authorities are not included in revenue, and are reflected as a liability on the consolidated balance sheets.

[0001032975-19-000027:notes:26]
Shipping and Handling Costs

[0001032975-19-000027:notes:27]
The Company's shipping and handling costs are included in cost of goods sold in the consolidated statements of operations for all periods presented.

[0001032975-19-000027:notes:28]
Contract Balances

[0001032975-19-000027:notes:29]
The Company records accounts receivable from contracts with customers when it has an unconditional right to consideration, as accounts receivable, net on the consolidated balance sheet.

[0001032975-19-000027:notes:30]
The Company records contract liabilities when cash payments are received or due in advance of performance, primarily for implied support and subscriptions. Contract liabilities are included in accrued and other current liabilities on the consolidated balance sheets.

[0001032975-19-000027:notes:31]
As of March 31, 2019 and for the year then ended, and as of April 1, 2018, the Company did not have any material contract liabilities balances or changes.

[0001032975-19-000027:notes:32]
Contract Costs

[0001032975-19-000027:notes:33]
The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that otherwise would have been recognized is one year or less. These costs are included in marketing and selling expenses in the consolidated statements of operations. As of March 31, 2019 and March 31, 2018, the Company did not have any material deferred contract costs.

[0001032975-19-000027:notes:34]
Research and Development Costs

[0001032975-19-000027:notes:35]
Costs related to research, design and development of products, which consist primarily of personnel, product design and infrastructure expenses, are charged to research and development expense as they are incurred.

[0001032975-19-000027:notes:36]
Advertising Costs

[0001032975-19-000027:notes:37]
Advertising costs are recorded as either a marketing and selling expense or a deduction from revenue as they are incurred. Advertising costs paid or reimbursed by the Company to direct or indirect customers must have an identifiable benefit and an estimable fair value in order to be classified as an operating expense. If these criteria are not met, the payment is classified as a reduction of revenue. Advertising costs recorded as marketing and selling expense are expensed as incurred. Total advertising costs including those characterized as revenue deductions during fiscal years 2019, 2018 and 2017 were $278.2 million, $233.7 million and $208.7 million, respectively, out of which $58.8 million, $36.7 million and $32.2 million, respectively, were included as operating expense in the consolidated statements of operations.

[0001032975-19-000027:notes:38]
Cash Equivalents

[0001032975-19-000027:notes:39]
The Company classifies all highly liquid instruments purchased with an original maturity of three months or less at the date of purchase to be cash equivalents. Cash equivalents are carried at cost, which approximates their fair value.

[0001032975-19-000027:notes:40]
All of the Company's bank time deposits have an original maturity of three months or less and are classified as cash equivalents and are recorded at cost, which approximates their fair value.

[0001032975-19-000027:notes:41]
Concentration of Credit Risk

[0001032975-19-000027:notes:42]
Financial instruments that potentially subject the Company to concentrations of credit risk consist principally of cash and cash equivalents and accounts receivable. The Company maintains cash and cash equivalents with various financial institutions to limit exposure with any one financial institution, but is exposed to credit risk in the event of default by financial institutions to the extent that cash balances with individual financial institutions are in excess of amounts that are insured.

[0001032975-19-000027:notes:43]
The Company sells to large distributors and retailers and, as a result, maintains individually significant receivable balances with such customers.

[0001032975-19-000027:notes:44]
The Company had the following customers that individually comprised 10% or more of its gross sales:

[0001032975-19-000027:notes:45]
|  |  | Years Ended March 31, |
|  |  | 2019 |  | 2018 |  | 2017 |
| Customer A |  | 13 | % |  | 15 | % |  | 15 | % |
| Customer B |  | 14 | % |  | 13 | % |  | 12 | % |

[0001032975-19-000027:notes:46]
The Company had the following customers that individually comprised 10% or more of accounts receivable:

[0001032975-19-000027:notes:47]
|  |  | March 31, |
|  |  | 2019 |  | 2018 |
| Customer A |  | 14 | % |  | 15 | % |
| Customer B |  | 15 | % |  | 12 | % |
| Customer C |  | * |  |  | 11 | % |

[0001032975-19-000027:notes:48]
* Less than 10%

[0001032975-19-000027:notes:49]
Typical payment terms require customers to pay for product sales generally within 30 to 60 days; however, terms may vary by customer type, by country and by selling season. Extended payment terms are sometimes offered to a limited number of customers during the second and third fiscal quarters. The Company does not modify payment terms on existing receivables.

[0001032975-19-000027:notes:50]
The Company manages its accounts receivable credit risk through ongoing credit evaluation of its customers' financial conditions. The Company generally does not require collateral from its customers.

[0001032975-19-000027:notes:51]
Allowances for Doubtful Accounts

[0001032975-19-000027:notes:52]
Allowances for doubtful accounts are maintained for estimated losses resulting from the Company's customers' inability to make required payments. The allowances are based on the Company's regular assessment of the credit-worthiness and financial condition of specific customers, as well as its historical experience with bad debts and customer deductions, receivables aging, current economic trends, geographic or country-specific risks and the financial condition of its distribution channels.

[0001032975-19-000027:notes:53]
Inventories

[0001032975-19-000027:notes:54]
Inventories are stated at the lower of cost and net realizable value. Costs are computed under the standard cost method, which approximates actual costs determined on the first-in, first-out basis. The Company records write-downs of inventories which are obsolete or in excess of anticipated demand or net realizable value based on a consideration of marketability and product life cycle stage, product development plans, component cost trends, historical sales and demand forecasts which consider the assumptions about future demand and market conditions. Inventory on hand which is not expected to be sold or utilized is considered excess, and the Company recognizes the write-down in cost of goods sold at the time of such determination. The write-down is determined by the excess of cost over net realizable value. Net realizable value is the estimated selling price in the ordinary course of business, less reasonably predictable costs of completion, disposal and transportation. At the time of loss recognition, new cost basis per unit and lower-cost basis for that inventory are established and subsequent changes in facts and circumstances would not result in an increase in the cost basis.

[0001032975-19-000027:notes:55]
As of March 31, 2019 and 2018, the Company also recorded a liability of $14.1 million and $12.6 million, respectively, arising from firm, non-cancelable, and unhedged inventory purchase commitments in excess of anticipated demand or net realizable value consistent with its valuation of excess and obsolete inventory. Such liability is included in accrued and other current liabilities on the consolidated balance sheets.

[0001032975-19-000027:notes:56]
Property, Plant and Equipment

[0001032975-19-000027:notes:57]
Property, plant and equipment are stated at cost. Additions and improvements are capitalized, and maintenance and repairs are expensed as incurred. The Company capitalizes the cost of software developed for internal use in connection with major projects. Costs incurred during the feasibility stage are expensed, whereas direct costs incurred during the application development stage are capitalized.

[0001032975-19-000027:notes:58]
Depreciation expense is recognized using the straight-line method. Plant and buildings are depreciated over estimated useful lives of twenty-five years, equipment over useful lives from three to five years, internal-use software over useful lives from three to seven years, tooling over useful lives from six months to one year, and leasehold improvements over the lesser of the useful life of the improvement or the term of the lease.

[0001032975-19-000027:notes:59]
When property and equipment is retired or otherwise disposed of, the cost and accumulated depreciation are relieved from the accounts and the net gain or loss is included in operating expenses.

[0001032975-19-000027:notes:60]
Intangible Assets

[0001032975-19-000027:notes:61]
The Company's intangible assets principally include goodwill, acquired technology, trademarks, and customer relationships and contracts. Intangible assets with finite lives, which include acquired technology, trademarks, customer relationships and contracts, and others are carried at cost and amortized using the straight-line method over their useful lives ranging from four to ten years. Intangible assets with indefinite lives, which include only goodwill, are recorded at cost and evaluated at least annually for impairment.

[0001032975-19-000027:notes:62]
Impairment of Long-Lived Assets

[0001032975-19-000027:notes:63]
The Company reviews long-lived assets, such as property and equipment, and finite-lived intangible assets, for impairment whenever events indicate that the carrying amounts might not be recoverable. Recoverability of property and equipment, and other finite-lived intangible asset is measured by comparing the projected undiscounted net cash flows associated with those assets to their carrying values. If an asset is considered impaired, it is written down to its fair value, which is determined based on the asset's projected discounted cash flows or appraised value, depending on the nature of the asset. For purposes of recognition of impairment for assets held for use, the Company groups assets and liabilities at the lowest level for which cash flows are separately identifiable.

[0001032975-19-000027:notes:64]
Impairment of Goodwill

[0001032975-19-000027:notes:65]
Goodwill represents the excess of the purchase price over the fair value of the net tangible and identifiable intangible assets acquired in each business combination. The Company conducts a goodwill impairment analysis annually at December 31 or more frequently if indicators of impairment exist or if a decision is made to sell or exit a business. Significant judgments are involved in determining if an indicator of impairment has occurred. Such indicators may include deterioration in general economic conditions, negative developments in equity and credit markets, adverse changes in the markets in which an entity operates, increases in input costs that have a negative effect on earnings and cash flows, or a trend of negative or declining cash flows over multiple periods, among others. The fair value that could be realized in an actual transaction may differ from that used to evaluate the impairment of goodwill.

[0001032975-19-000027:notes:66]
In reviewing goodwill for impairment, the Company has the option to first assess qualitative factors to determine whether the existence of events or circumstances leads to a determination that it is more likely than not (greater than 50%) that the estimated fair value of a reporting unit is less than its carrying amount. For the year ended March 31, 2019, the Company elected to perform a qualitative assessment and determined that an impairment was not more likely than not and no further analysis was required. The Company also may elect not to perform the qualitative assessment and, instead, proceed directly to the quantitative impairment test. The ultimate outcome of the goodwill impairment review for a reporting unit should be the same whether the Company chooses to perform the qualitative assessment or proceeds directly to the quantitative impairment test.

[0001032975-19-000027:notes:67]
Income Taxes

[0001032975-19-000027:notes:68]
The Company provides for income taxes using the asset and liability method, which requires that deferred tax assets and liabilities be recognized for the expected future tax consequences of temporary differences resulting from differing treatment of items for tax and financial reporting purposes, and for operating losses and tax credit carryforwards. In estimating future tax consequences, expected future events are taken into consideration, with the exception of potential tax law or tax rate changes. The Company records a valuation allowance to reduce deferred tax assets to amounts management believes are more likely than not to be realized.

[0001032975-19-000027:notes:69]
The Company's assessment of uncertain tax positions requires that management makes estimates and judgments about the application of tax law, the expected resolution of uncertain tax positions and other matters. In the event that uncertain tax positions are resolved for amounts different than the Company's estimates, or the related statutes of limitations expire without the assessment of additional income taxes, the Company will be required to adjust the amounts of the related assets and liabilities in the period in which such events occur. Such adjustments may have a material impact on the Company's income tax provision and its results of operations.

[0001032975-19-000027:notes:70]
Fair Value of Financial Instruments

[0001032975-19-000027:notes:71]
The carrying value of certain of the Company's financial instruments, including cash equivalents, accounts receivable and accounts payable approximates their fair value due to their short maturities.

[0001032975-19-000027:notes:72]
The Company's investment securities portfolio consists of bank time deposits with an original maturity of three months or less and marketable securities (money market and mutual funds) related to a deferred compensation plan.

[0001032975-19-000027:notes:73]
The Company's trading investments related to the deferred compensation plan are reported at fair value based on quoted market prices. The marketable securities related to the deferred compensation plan are classified as non-current trading investments, as they are intended to fund the deferred compensation plan's long-term liability. Since participants in the deferred compensation plan may select the mutual funds in which their compensation deferrals are invested within the confines of the Rabbi Trust which holds the marketable securities,

[0001032975-19-000027:notes:74]
the Company has designated these marketable securities as trading investments, although there is no intent to actively buy and sell securities with the objective of generating profits on short-term differences in market prices. These securities are recorded at fair value based on quoted market prices. Earnings, gains and losses on trading investments are included in other income (expense), net in the consolidated statements of operations.

[0001032975-19-000027:notes:75]
The Company also holds non-marketable investments in equity and other securities that are accounted under the equity method, which are classified as other assets. In addition, the Company has certain investments without readily determinable fair values due to the absence of quoted market prices, the inherent lack of liquidity, and the fact that inputs used to measure fair value are unobservable and require management's judgment. The Company elected the measurement alternative to record these investments at cost and to adjust for impairments and observable price changes resulting from transactions with the same issuer within the statement of operations.

[0001032975-19-000027:notes:76]
Net Income per Share

[0001032975-19-000027:notes:77]
Basic net income per share is computed by dividing net income by the weighted average outstanding shares. Diluted net income per share is computed using the weighted average outstanding shares and dilutive share equivalents. Dilutive share equivalents consist of share-based awards, including stock options, purchase rights under employee share purchase plan, and restricted stock units (RSUs).

[0001032975-19-000027:notes:78]
The dilutive effect of in-the-money share-based compensation awards is calculated based on the average share price for each fiscal period using the treasury stock method.

[0001032975-19-000027:notes:79]
Share-Based Compensation Expense

[0001032975-19-000027:notes:80]
Share-based compensation expense includes compensation expense for share-based awards granted based on the grant date fair value. The grant date fair value for stock options and stock purchase rights is estimated using the Black-Scholes-Merton option-pricing valuation model. The grant date fair value of RSUs which vest upon meeting certain market conditions is estimated using the Monte-Carlo simulation method. The grant date fair value of time-based and performance-based RSUs is calculated based on the market price on the date of grant, reduced by estimated dividends yield prior to vesting. With respect to awards with service conditions only, compensation expense is recognized ratably over the vesting period of the awards. For performance-based RSUs, the Company recognizes the estimated expense using a graded-vesting method over requisite service periods of one to three years when the performance condition is determined to be probable. The performance period and the service period of the market-based grants of the Company are both approximately three years and the estimated expense is recognized ratably over the service period.

[0001032975-19-000027:notes:81]
In March 2016, the FASB issued ASU 2016-09, "Compensation-Stock Compensation (Topic 718)": Improvements to Employee Share-Based Payment Accounting" (ASU 2016-09). The Company adopted this standard effective April 1, 2017 using modified retrospective approach. Under the new standard, the Company accounts for forfeitures as they occur. The change in accounting for forfeitures resulted in a cumulative-effect adjustment to decrease retained earnings as of April 1, 2017 by $3.3 million. The Company further recognized a cumulative-effect adjustment to increase retained earnings as of April 1, 2017 by $57.2 million upon adoption of the new guidance to account for gross excess tax benefits of $75.2 million that were previously not recognized because the related tax deduction had not reduced current income taxes, offset by a valuation allowance of $18.0 million to reduce the deferred tax assets to amounts that are more likely than not to be realized.

[0001032975-19-000027:notes:82]
Product Warranty Accrual

[0001032975-19-000027:notes:83]
All of the Company's products are covered by warranty to be free from defects in material and workmanship for periods ranging from one year to five years. The warranty period varies by product and by region. The Company’s warranty doesn’t provide a service beyond assuring that the product complies with agreed-upon specifications and is not sold separately. The warranty the Company provides qualifies as an assurance warranty and is not treated as a separate performance obligation. The Company estimates cost of product warranties at the time the related revenue is recognized based on historical warranty claim rates, historical costs, and knowledge of specific product failures that are outside of the Company's typical experience. The Company accrues a warranty liability for estimated costs to provide products, parts or services to repair or replace products in satisfaction of the warranty obligation. Each quarter, the Company reevaluates estimates to assess the adequacy of recorded warranty liabilities. When the Company experiences changes in warranty claim activity or costs associated with fulfilling those claims, the warranty liability is adjusted accordingly. If actual product failure rates or repair costs differ from estimates, revisions to the estimated warranty liabilities would be required and could materially affect the Company's results of operations.

[0001032975-19-000027:notes:84]
Comprehensive Income (Loss)

[0001032975-19-000027:notes:85]
Comprehensive income (loss) is defined as the total change in shareholders' equity during the period other than from transactions with shareholders. Comprehensive income (loss) consists of net income (loss) and other comprehensive income (loss). Other comprehensive income (loss) is comprised of currency translation adjustments from those entities not using the U.S. Dollar as their functional currency, net deferred gains and losses and prior service costs and credits for defined benefit pension plans, and net deferred gains and losses on hedging activity.

[0001032975-19-000027:notes:86]
Treasury Shares

[0001032975-19-000027:notes:87]
The Company periodically repurchases shares in the market at fair value. Shares repurchased are recorded at cost as a reduction of total shareholders' equity. Treasury shares held may be reissued to satisfy the exercise of employee stock options and purchase rights and the vesting of restricted stock units, or may be canceled with shareholder approval. Treasury shares that are reissued are accounted for using the first-in, first-out basis.

[0001032975-19-000027:notes:88]
Derivative Financial Instruments

[0001032975-19-000027:notes:89]
The Company enters into foreign exchange forward contracts to reduce the short-term effects of currency fluctuations on certain foreign currency receivables or payables and to hedge against exposure to changes in currency exchange rates related to its subsidiaries' forecasted inventory purchases.

[0001032975-19-000027:notes:90]
Gains and losses for changes in the fair value of the effective portion of the Company's forward contracts related to forecasted inventory purchases are deferred as a component of accumulated other comprehensive income (loss) until the hedged inventory purchases are sold, at which time the gains or losses are reclassified to cost of goods sold. The Company presents the earnings impact from forward points in the same line item that is used to present the earnings impact of the hedged item, i.e. cost of goods sold, for hedging forecasted inventory purchases.

[0001032975-19-000027:notes:91]
Gains or losses from changes in the fair value of forward contracts that offset translation losses or gains on foreign currency receivables or payables are recognized immediately and included in other income (expense), net in the consolidated statements of operations.

[0001032975-19-000027:notes:92]
Restructuring Charges

[0001032975-19-000027:notes:93]
The Company's restructuring charges consist of employee severance, one-time termination benefits and ongoing benefits related to the reduction of its workforce, lease exit costs, and other costs. Liabilities for costs associated with a restructuring activity are measured at fair value and are recognized when the liability is incurred, as opposed to when management commits to a restructuring plan. One-time termination benefits are expensed at the date the entity notifies the employee, unless the employee must provide future service, in which case the benefits are expensed ratably over the future service period. Ongoing benefits are expensed when restructuring activities are probable and the benefit amounts are estimable. Costs to terminate a lease before the end of its term are recognized when the property is vacated. Other costs primarily consist of legal, consulting, and other costs related to employee terminations are expensed when incurred. Termination benefits are calculated based on regional benefit practices and local statutory requirements.

[0001032975-19-000027:notes:94]
Recent Accounting Pronouncements Adopted

[0001032975-19-000027:notes:95]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standard Update (ASU) No. 2014-09, "Revenue from Contracts with Customers (Topic 606)" (ASU 2014-09 or Topic 606) which supersedes the revenue recognition requirements under ASC 605 (Topic 605), Revenue Recognition. ASU 2014-09 outlines a new, single, comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes existing revenue recognition guidance, including industry-specific guidance. Under the new guidance, recognition of revenue occurs when a customer obtains control of promised goods or services in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. The new standard requires reporting companies to disclose the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. On April 1, 2018, the Company adopted the new standard and all related amendments using the modified retrospective method applied to those contracts that were not completed as of April 1, 2018. Results for reporting periods beginning after April 1, 2018 are presented under Topic 606, while prior period amounts are not adjusted and continue to be reported in accordance with historic accounting standards under Topic 605.

[0001032975-19-000027:notes:96]
As a result of the adoption of the new standard, the Company recorded: a) a reduction to retained earnings as of April 1, 2018; and b) reclassifications of certain allowances for sales returns and certain other Customer Programs from accounts receivable, net to accrued and other current liabilities and other current assets.

[0001032975-19-000027:notes:97]
The cumulative effect of the changes to the consolidated balance sheet from the adoption of Topic 606 was as follows (in thousands):

[0001032975-19-000027:notes:98]
|  |  | As of March 31, 2018 |  | Effect of Adoption of Topic 606 |  | As of April 1, 2018 |
| Accounts receivable, net |  | $ | 214,885 |  |  | $ | 105,768 |  |  | $ | 320,653 |  |
| Other current assets |  | 56,362 |  |  | 6,195 |  |  | 62,557 |  |
| Accrued and other current liabilities |  | 281,732 |  |  | 122,845 |  |  | 404,577 |  |
| Retained earnings |  | 1,232,316 |  |  | (10,882 | ) |  | 1,221,434 |  |

[0001032975-19-000027:notes:99]
Net Reduction to Retained Earnings as of April 1, 2018

[0001032975-19-000027:notes:100]
| • | Under Topic 605, accruals for certain Customer Programs were recognized as a reduction of revenue at the later of when the related revenue is recognized or when the program is offered to the customer. Under Topic 606, these programs qualify as variable consideration and are recorded as a reduction of the transaction price at the contract inception based on the expected value method. The Company is required to estimate the accruals for these programs ahead of commitment date if customary business practice creates an implied expectation that such activities will occur in the future. |

[0001032975-19-000027:notes:101]
| • | Under Topic 606, variable consideration must be estimated at the outset of the arrangement, subject to the constraint guidance to ensure that a significant revenue reversal will not occur. As a result, upon adoption of Topic 606, estimated breakage for accruals of certain Customer Programs is recognized sooner as compared to Topic 605. |

[0001032975-19-000027:notes:102]
Balance Sheet Reclassifications

[0001032975-19-000027:notes:103]
| • | Under Topic 605, the gross amount of accrued revenue reserves for sales returns of $31.4 million, net of expected returned inventory of $11.4 million was included within accounts receivable, net as of March 31, 2018. Expected scrap cost of $5.2 million for such expected returned inventory was included in accrued and other current liabilities as of March 31, 2018. Subsequent to the adoption of Topic 606, such balances are presented on a gross basis as accrued revenue reserve from returns of $31.4 million included in accrued and other current liabilities and as return assets of $6.2 million included in other current assets. |

[0001032975-19-000027:notes:104]
| • | Under Topic 605, revenue reserves for certain Customer Programs totaling $76.7 million, which were estimated using portfolio approach based on aggregated customer level data, were included within accounts receivable, net as of March 31, 2018. Subsequent to the adoption of Topic 606, such balances are presented as accrued customer marketing, pricing and incentive programs included in accrued and other current liabilities. |

[0001032975-19-000027:notes:105]
Certain balances of allowances for sales return and accruals for Customer Programs which were accrued based on Customer Program offers made to individual customers, met the right of offset criteria in accordance with ASC 210-20, "Balance Sheet (Topic 210)", and are still included within accounts receivable, net.

[0001032975-19-000027:notes:106]
The adoption of Topic 606 did not have an impact on the total cash flows from operating, investing, or financing activities.

[0001032975-19-000027:notes:107]
The following tables summarize the impacts of adopting Topic 606 on the Company’s consolidated statements of operations for the year ended March 31, 2019, and consolidated balance sheet as of March 31, 2019 (in thousands):

[0001032975-19-000027:notes:108]
|  |  | Year Ended March 31, 2019 |
|  |  | As Reported Under Topic 606 |  | If Reported Under Topic 605 |  | Effect of Change |
| Net sales |  | $ | 2,788,322 |  |  | $ | 2,784,636 |  |  | $ | 3,686 |  |

[0001032975-19-000027:notes:109]
|  |  | As of March 31, 2019 |
|  |  | As Reported Under Topic 606 |  | Balance Under Topic 605 |  | Effect of Change |
| Accounts receivable, net |  | $ | 383,309 |  |  | $ | 260,401 |  |  | $ | 122,908 |  |
| Other current assets |  | 69,116 |  |  | 60,449 |  |  | 8,667 |  |
| Accrued and other current liabilities |  | 433,897 |  |  | 295,126 |  |  | 138,771 |  |
| Retained earnings |  | 1,365,036 |  |  | 1,372,232 |  |  | (7,196 | ) |

[0001032975-19-000027:notes:110]
In January 2016, the FASB issued ASU 2016-01, "Financial Instruments-Recognition and Measurement of Financial Assets and Financial Liabilities (Subtopic 825-10)" (ASU 2016-01). ASU 2016-01 requires equity investments that are not accounted for under the equity method or do not result in consolidation to be recorded at fair value and any changes in fair value to be recognized within the statement of operations. The Company adopted ASU 2016-01 effective April 1, 2018, on a prospective basis for its privately held strategic equity investments without readily determinable fair values. The Company elected the measurement alternative to record these investments at cost and to adjust for impairments and observable price changes resulting from transactions with the same issuer within the statement of operations. The adoption of ASU 2016-01 did not have a material impact on the Company's consolidated financial statements.

[0001032975-19-000027:notes:111]
In October 2016, the FASB issued ASU 2016-16, "Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory" (ASU 2016-16), which eliminates the deferral of income tax effects of intra-entity asset transfers until the transferred asset is sold to an unrelated party or recovered through use. However, this standard does not apply to intra-entity transfer of inventory. The Company adopted this standard effective April 1, 2018 on a modified retrospective basis, and the adoption of ASU 2016-16 did not have a material impact on its consolidated financial statements.

[0001032975-19-000027:notes:112]
In December 2016, the FASB issued ASU 2016-18, "Statement of Cash Flows (Topic 230): Restricted Cash" (ASU 2016-18), which requires that a statement of cash flows explains the change during the period in the total of cash, cash equivalents, and amounts generally described as restricted cash or restricted cash equivalents. The Company adopted this standard effective April 1, 2018, utilizing the retrospective transition method to each period presented and the adoption of ASU 2016-18 did not have a material impact on its consolidated financial statements. The consolidated statement of cash flows for the year ended March 31, 2017 has been revised as a result of the adoption and the Company has no restricted cash balances or activities since then.

[0001032975-19-000027:notes:113]
In January 2017, the FASB issued ASU 2017-01, "Business Combination (Topic 805): Clarifying the Definition of a Business" (ASU 2017-01), which changes the definition of a business to assist with evaluating when a set of transferred assets and activities is a business. The Company adopted this standard effective April 1, 2018, and the adoption of ASU 2017-01 did not have a material impact on its consolidated financial statements.

[0001032975-19-000027:notes:114]
In March 2017, the FASB issued ASU 2017-07, "Compensation-Retirement Benefit (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost" (ASU 2017-07), which requires that the Company disaggregate the service cost component from the other components of net benefit cost, and also provides guidance on how to present the service cost component and the other components of net benefit cost in the income statement and allow only the service cost component of net benefit cost to be eligible for capitalization. The Company adopted this standard effective April 1, 2018 using a retrospective adoption method. Other than the revised statement of operations presentation for the periods in the current year, the adoption of ASU 2017-07 did not have an impact on the Company’s consolidated financial statements. The impact to the comparative periods was immaterial and therefore the prior period statements of operations were not revised.

[0001032975-19-000027:notes:115]
In August 2017, the FASB issued ASU 2017-12, "Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities" (ASU 2017-12), which improves the financial reporting of hedging relationships to better portray the economic results of an entity’s risk management activities in its financial statements and

[0001032975-19-000027:notes:116]
simplifies the application of the hedge accounting guidance. The Company adopted this standard prospectively effective April 1, 2018, and the adoption of ASU 2017-12 did not have a material impact on its consolidated financial statements. In accordance with ASU 2017-12, the Company has started presenting the earnings impact from forward points in the cost of goods sold line item, which is used to present the earnings impact of the hedged item.

[0001032975-19-000027:notes:117]
Recent Accounting Pronouncements To Be Adopted

[0001032975-19-000027:notes:118]
In February 2016, the FASB issued ASU 2016-02, "Leases (Topic 842)" (ASU 2016-02 or Topic 842), which generally requires lessees to recognize right-of-use (ROU) assets and lease liabilities arising from operating and financing leases with terms longer than 12 months in the consolidated balance sheets and and to disclose key information about leasing arrangements. In July 2018, the FASB issued ASU 2018-11, "Leases (Topic 842): Targeted Improvements (ASU 2016-02 or Topic 842)", which provides an alternative modified transition method. Under this method, the cumulative-effect adjustment to the opening balance of retained earnings is recognized on the date of adoption with comparative prior periods not restated. The new standard, including related amendments subsequently issued by the FASB, is effective for our interim and annual periods beginning April 1, 2019. The Company will adopt the new guidance in the first quarter of fiscal year 2020 on the alternative modified transition basis, thereby recognizing the cumulative effect of initially applying Topic 842 as an adjustment to opening retained earnings on the adoption date, without revising the balances in comparative periods. The Company plans on electing the package of transitional practical expedients upon adoption which, among other provisions, allows the Company to not to reassess under the new standard our prior conclusions about lease identification, lease classification and initial direct cost, for any existing leases on the adoption date. In addition, for the facility leases, the Company intends to elect to account for lease and non-lease components as a single lease component. The Company will also make an accounting policy election not to record leases that, at the lease commencement date, have a lease term of 12 months or less on the balance sheet. The Company has substantially completed its evaluation of the effect that the adoption of this guidance will have on its consolidated financial statements. In connection with the adoption of the new guidance, the Company expects to recognize ROU assets in the range of $25 million to $35 million and lease liabilities in the range of $30 million to $40 million on its statement of financial position for operating leases, with limited impact to its results of operations and cash flows. The Company believes that substantially all of its undiscounted future minimum operating lease commitments based on its current lease portfolio that were not recognized on its consolidated balance sheet as of March 31, 2019 and as disclosed in Note 13 to the consolidated financial statements, will be subject to the new standard.

[0001032975-19-000027:notes:119]
In August 2018, the FASB issued ASU 2018-13, "Fair Value Measurement (Topic 820): Disclosure Framework - Changes to the Disclosure Requirements for Fair Value Measurements" (ASU 2018-13), which aims to improve the overall usefulness of disclosures to financial statement users and reduce unnecessary costs to companies when preparing fair value measurement disclosures. ASU 2018-13 is effective for annual and interim periods in fiscal years beginning after December 15, 2019. Early adoption is permitted. Retrospective adoption is required, except for certain disclosures which will be required to be applied prospectively for only the most recent interim or annual period presented in the initial fiscal year of adoption. The Company does not expect the adoption of ASU 2018-13 will have a material impact on its consolidated financial statements and will adopt the standard effective April 1, 2020.

[0001032975-19-000027:notes:120]
In August 2018, the FASB issued ASU 2018-14, "Compensation - Retirement Benefits - Defined Benefits Plans - General (Subtopic 715-20): Disclosure Framework - Changes to the Disclosure Requirements for Defined Benefit Plans" (ASU 2018-14), which aims to improve the overall usefulness of disclosures to financial statement users and reduce unnecessary costs to companies when preparing defined benefit plan disclosures. ASU 2018-14 is effective for annual periods in fiscal years ending after December 15, 2020. Retrospective adoption is required and early adoption is permitted. The Company does not expect the adoption of ASU 2018-14 will have a material impact on its consolidated financial statements and will adopt the standard effective April 1, 2020.

[0001032975-19-000027:notes:121]
In August 2018, the FASB issued ASU 2018-15, "Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40): Customer's Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract" (ASU 2018-15), which clarifies that implementation costs incurred by customers in cloud computing arrangements are deferred if they would be capitalized by customers in software licensing arrangements under the internal-use software guidance. ASU 2018-15 is effective for annual and interim periods in fiscal years beginning after December 15, 2019, with early adoption permitted. Entities have the option to apply the guidance prospectively to all implementation costs incurred after the date of adoption or retrospectively. The Company does not expect the adoption of ASU 2018-15 will have a material impact on its consolidated financial statements and will adopt the standard prospectively effective April 1, 2019.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001032975-19-000027:notes:122]
Business Acquisitions

[0001032975-19-000027:notes:123]
Fiscal Year 2019 Acquisition

[0001032975-19-000027:notes:124]
Blue Microphones Acquisition

[0001032975-19-000027:notes:125]
On August 21, 2018 (the "Blue Microphones Acquisition Date"), the Company acquired all equity interests in Blue Microphones Holding Corporation ("Blue Microphones") for a total consideration of $134.8 million in cash (the "Blue Microphones Acquisition"), which included a working capital adjustment and repayment of debt on behalf of Blue Microphones.

[0001032975-19-000027:notes:126]
Blue Microphones is a leading audio manufacturer that designs and produces microphones, headphones, recording tools, and accessories for audio professionals, musicians and consumers. The Blue Microphones Acquisition supplements the Company's product portfolio.

[0001032975-19-000027:notes:127]
Blue Microphones met the definition of a business, and therefore the acquisition is accounted for using the acquisition method.

[0001032975-19-000027:notes:128]
The following table summarizes the estimated fair values of the assets acquired and liabilities assumed at the Blue Microphones Acquisition Date (in thousands):

[0001032975-19-000027:notes:129]
|  |  | Estimated Fair Value |
| Cash and cash equivalents |  | $ | 1,110 |  |
| Accounts receivable |  | 10,979 |  |
| Inventories |  | 19,546 |  |
| Other current assets |  | 997 |  |
| Property, plant and equipment |  | 452 |  |
| Intangible assets |  | 55,567 |  |
| Total identifiable assets acquired |  | $ | 88,651 |  |
| Accounts payable |  | (10,322 | ) |
| Accrued liabilities |  | (11,162 | ) |
| Other long-term liabilities |  | (661 | ) |
| Net identifiable assets acquired |  | $ | 66,506 |  |
| Goodwill |  | 68,269 |  |
| Net assets acquired |  | $ | 134,775 |  |

[0001032975-19-000027:notes:130]
Goodwill related to the acquisition is primarily attributable to opportunities and economies of scale from combining the operations and technologies of Logitech and Blue Microphones and is not deductible for tax purposes.

[0001032975-19-000027:notes:131]
The fair value of the inventory acquired is estimated at its net realizable value, which uses the estimated selling prices, less the cost of disposal and a reasonable profit allowance for the selling efforts. The difference between the fair value of the inventories and the amount recorded by Blue Microphones immediately before the acquisition date is $1.8 million, which has been recognized in "amortization of intangibles assets and purchase accounting effect on inventory" in the consolidated statements of operations upon the sale of the acquired inventory.

[0001032975-19-000027:notes:132]
The following table summarizes the estimated fair values and estimated useful lives of the components of intangible assets acquired as of the Blue Microphones Acquisition Date (Dollars in thousands):

[0001032975-19-000027:notes:133]
|  | Fair Value |  | Estimated Useful Life (years) |
| Developed technology | $ | 17,967 |  |  | 5.0 |
| Customer relationships | 25,100 |  |  | 10.0 |
| Trademark and trade name | 12,500 |  |  | 7.0 |
| Total intangible assets acquired | $ | 55,567 |  |  | 7.7 |

[0001032975-19-000027:notes:134]
Intangible assets acquired as a result of the Blue Microphones Acquisition are being amortized over their estimated useful lives using the straight-line method of amortization, which materially approximates the distribution of the economic value of the intangible assets. Amortization of developed technology of $2.1 million during the year ended March 31, 2019 is included in "amortization of intangible assets and purchase accounting effect of inventory" in the consolidated statements of operations. Amortization of customer relationships, trademark and trade names of $2.5 million during the year ended March 31, 2019 is included in "amortization of intangible assets and acquisition-related costs" in the consolidated statements of operations.

[0001032975-19-000027:notes:135]
Developed technology relates to existing Blue Microphones products. The economic useful life was determined based on the technology cycle related to developed technology of existing products, as well as the cash flows anticipated over the forecasted periods.

[0001032975-19-000027:notes:136]
Customer relationships represent the fair value of future projected revenue that will be derived from sales of products to existing customers of Blue Microphones. The economic useful life was determined based on historical customer attrition rates and industry benchmarks.

[0001032975-19-000027:notes:137]
Trademark and trade name relates to “Blue Microphones”. The economic useful life was determined based on the expected life of the trade name and the cash flows anticipated over the forecasted periods.

[0001032975-19-000027:notes:138]
The fair values of developed technology and trade name were estimated using the relief-from-royalty method, an income approach (Level 3), which estimates the cost savings that accrue to the owner of the intangible assets that would otherwise be payable as royalties or license fees on revenues earned through the use of the asset. A royalty rate is applied to the projected revenues associated with the intangible assets to determine the amount of savings, which is then discounted to determine the fair value. The developed technology and trade name were valued using royalty rates of 10% and 3%, respectively, and both were discounted at a rate of 11%.

[0001032975-19-000027:notes:139]
The fair value of customer relationships was estimated using the excess earnings method, an income approach (Level 3), which converts projected revenues and costs into cash flows. To reflect the fact that certain other assets contributed to the cash flows generated, the returns for these contributory assets were removed to arrive at estimated cash flows solely attributable to the customer relationships, which were discounted at a rate of 11%.

[0001032975-19-000027:notes:140]
The Company believes the fair value of the intangible assets recorded above approximates the amounts a market participant would pay for these intangible assets as of the Acquisition Date.

[0001032975-19-000027:notes:141]
The Company included Blue Microphones' estimated fair value of assets acquired and liabilities assumed in its consolidated balance sheet beginning on the Blue Microphones Acquisition Date. The results of operations for Blue Microphones subsequent to the acquisition date have been included in, but are not material to, the Company's consolidated statements of operations. For the year ended March 31, 2019, Blue Microphones contributed $45.7 million to sales, representing approximately 2% of the sales of the Company.

[0001032975-19-000027:notes:142]
Fiscal Year 2018 Acquisitions

[0001032975-19-000027:notes:143]
ASTRO Acquisition

[0001032975-19-000027:notes:144]
On August 11, 2017 (the ASTRO Acquisition Date), the Company acquired certain assets and liabilities constituting the ASTRO Gaming business (ASTRO) from AG Acquisition Corporation for a purchase price of $85.0 million in cash (the ASTRO Acquisition). ASTRO is a leading console gaming accessory brand with a history of producing award-winning headsets for professional gamers and enthusiasts. ASTRO provides the Company with a strong growth platform in the console gaming accessories market.

[0001032975-19-000027:notes:145]
ASTRO meets the definition of a business, and its acquisition is accounted for using the acquisition method. The following table summarizes the estimated fair values of the assets acquired and liabilities assumed at the ASTRO Acquisition Date (in thousands):

[0001032975-19-000027:notes:146]
|  |  | Estimated Fair Value |
| Inventories |  | $ | 10,331 |  |
| Property, plant and equipment |  | 2,760 |  |
| Intangible assets |  | 52,520 |  |
| Other assets |  | 605 |  |
| Total identifiable assets acquired |  | 66,216 |  |
| Accrued liabilities |  | (2,982 | ) |
| Net identifiable assets acquired |  | 63,234 |  |
| Goodwill |  | 21,766 |  |
| Net assets acquired |  | $ | 85,000 |  |

[0001032975-19-000027:notes:147]
Goodwill related to the acquisition is primarily attributable to opportunities and economies of scale from combining the operations and technologies of Logitech and ASTRO. Goodwill is expected to be deductible for tax purposes.

[0001032975-19-000027:notes:148]
The fair value of the inventory acquired is estimated at their net realizable value, which uses the estimated selling prices, less the costs of disposal and a reasonable profit allowance for the selling efforts. The difference between the fair value of the inventories and the amount recorded by ASTRO immediately before the ASTRO Acquisition Date is $0.8 million, which has been recognized in "amortization of intangibles assets and purchase accounting effect on inventory" in the consolidated statements of operations upon the sale of the acquired inventory.

[0001032975-19-000027:notes:149]
The following table summarizes the estimated fair values and estimated useful lives of the components of intangible assets acquired as of the ASTRO Acquisition Date (Dollars in thousands):

[0001032975-19-000027:notes:150]
|  | Fair Value |  | Estimated Useful Life (years) |
| Developed technology | $ | 12,540 |  |  | 4.0 |
| Customer relationships | 33,100 |  |  | 8.0 |
| Trademark and trade name | 6,880 |  |  | 6.0 |
| Total intangible assets acquired | $ | 52,520 |  |  | 6.8 |

[0001032975-19-000027:notes:151]
Intangible assets acquired as a result of the ASTRO Acquisition are being amortized over their estimated useful lives using the straight-line method of amortization, which materially approximates the distribution of the economic value of the intangible assets. Amortization of developed technology of $3.1 million and $2.0 million during the year ended March 31, 2019 and 2018, respectively, is included in "amortization of intangible assets and purchase accounting effect of inventory" in the consolidated statements of operations. Amortization of customer relationships and trade name of $5.3 million and $3.3 million during the year ended March 31, 2019 and 2018, respectively, is included in "amortization of intangible assets and acquisition-related costs" in the consolidated statements of operations.

[0001032975-19-000027:notes:152]
Developed technology relates to existing ASTRO gaming headset products. The economic useful life was determined based on the technology cycle related to developed technology of existing products, as well as the cash flows anticipated over the forecasted periods.

[0001032975-19-000027:notes:153]
Customer relationships represent the fair value of future projected revenue that will be derived from sales of products to existing customers of ASTRO. The economic useful life was determined based on historical customer attrition rates and industry benchmarks.

[0001032975-19-000027:notes:154]
Trademark and trade name relates to “ASTRO”. The economic useful life was determined based on the expected life of the trade name and the cash flows anticipated over the forecasted periods.

[0001032975-19-000027:notes:155]
The fair value of developed technology and trade name was estimated using the relief-from-royalty method, an income approach (Level 3), which estimates the cost savings that accrue to the owner of the intangible assets that would otherwise be payable as royalties or license fees on revenues earned through the use of the asset. A royalty rate is applied to the projected revenues associated with the intangible assets to determine the amount of savings, which is then discounted to determine the fair value. The developed technology and trade name were valued using royalty rates of 10% and 2%, respectively, and both were discounted at a rate of 13%.

[0001032975-19-000027:notes:156]
The fair value of customer relationships was estimated using the excess earnings method, an income approach (Level 3), which converts projected revenues and costs into cash flows. To reflect the fact that certain other assets contributed to the cash flows generated, the returns for these contributory assets were removed to arrive at estimated cash flows solely attributable to the customer relationships, which were discounted at a rate of 13%.

[0001032975-19-000027:notes:157]
The Company believes the value of intangible assets recorded above approximates the amounts a market participant would pay for, these intangible assets as of the ASTRO Acquisition Date.

[0001032975-19-000027:notes:158]
The Company included ASTRO's estimated fair value of assets acquired and liabilities assumed in its consolidated balance sheets beginning on the ASTRO Acquisition Date. The results of operations for ASTRO have been included in, but are not material to, the Company's consolidated statements of operations from the ASTRO Acquisition Date.

[0001032975-19-000027:notes:159]
In November 2017, the Company also made a small technology acquisition for a total consideration of $5.2 million, including cash acquired of $0.9 million.

[0001032975-19-000027:notes:160]
Change in fair value of contingent consideration for business acquisition

[0001032975-19-000027:notes:161]
On April 20, 2016 (the Jaybird Acquisition Date), the Company acquired all of the equity interests of JayBird, LLC (Jaybird), a Utah limited liability company that develops Bluetooth earbuds, activity trackers, and accessories for sports and active lifestyles, for a purchase price of $54.2 million in cash, with an additional earn-out of up to $45.0 million based on the achievement of certain net revenue growth targets over approximately a two year period (the Jaybird Acquisition). If the net revenue growth targets would have been met, the Company would have paid a maximum of $25.0 million and $20.0 million in fiscal years 2018 and 2019, respectively.  The fair value of the earn-out as of the Jaybird Acquisition Date was $18.0 million. The fair value of the contingent consideration decreased by $4.9 million and $8.1 million for the year ended March 31, 2018 and 2017, respectively, resulting primarily from Jaybird's lower-than-expected sales and revised projected sales in the remaining earn-out period. In October 2017, Logitech and the sellers of Jaybird entered into an agreement fully, irrevocably and unconditionally releasing Logitech from the earn-out rights and payments in exchange for $5.0 million in cash, which was paid in November 2017.

[0001032975-19-000027:notes:162]
Acquisition-related costs and pro forma results of operations

[0001032975-19-000027:notes:163]
The Company incurred acquisition-related costs of approximately $1.7 million, $1.4 million and $1.5 million, in aggregate, for the year ended March 31, 2019, 2018 and 2017, respectively. The acquisition-related costs are included in "Amortization of intangible assets and acquisition-related costs" in the consolidated statements of operations.

[0001032975-19-000027:notes:164]
Pro forma results of operations for the all the acquisitions completed in fiscal year 2019 and 2018 have not been presented because the effects of these acquisitions are not material to the consolidated statements of operations individually or in aggregate for each year.


## us-gaap:ScheduleOfRecognizedIdentifiedAssetsAcquiredAndLiabilitiesAssumedTableTextBlock

[0001032975-19-000027:notes:165]
The following table summarizes the estimated fair values of the assets acquired and liabilities assumed at the ASTRO Acquisition Date (in thousands):


## us-gaap:EarningsPerShareTextBlock

[0001032975-19-000027:notes:166]
Net Income per Share
The computations of basic and diluted net income per share for the Company were as follows (in thousands except per share amounts):

[0001032975-19-000027:notes:167]
|  |  | Years Ended March 31, |
|  |  | 2019 |  | 2018 |  | 2017 |
| Net Income |  | $ | 257,573 |  |  | $ | 208,542 |  |  | $ | 205,876 |  |
| Shares used in net income per share computation: |  |  |  |  |  |  |
| Weighted average shares outstanding - basic |  | 165,609 |  |  | 164,038 |  |  | 162,058 |  |
| Effect of potentially dilutive equivalent shares |  | 3,356 |  |  | 4,933 |  |  | 3,482 |  |
| Weighted average shares outstanding - diluted |  | 168,965 |  |  | 168,971 |  |  | 165,540 |  |
| Net income per share: |  |  |  |  |  |  |
| Basic |  | $ | 1.56 |  |  | $ | 1.27 |  |  | $ | 1.27 |  |
| Diluted |  | $ | 1.52 |  |  | $ | 1.23 |  |  | $ | 1.24 |  |

[0001032975-19-000027:notes:168]
Share equivalents attributable to outstanding stock options, restricted stock units ("RSUs") and employee share purchase rights totaling 1.8 million, 1.1 million and 1.4 million during fiscal years 2019, 2018 and 2017 were excluded from the calculation of diluted net income per share because the combined exercise price and average unamortized grant date fair value of these options and ESPP or vesting of RSUs were greater than the average market price of the Company's shares during the periods presented herein, and therefore their inclusion would have been anti-dilutive. Performance-based awards were not included because all necessary conditions have not been satisfied by the end of the respective period, and those shares were not issuable if the end of the reporting period were the end of the contingency period.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001032975-19-000027:notes:169]
Employee Benefit Plans
Employee Share Purchase Plans and Stock Incentive Plans

[0001032975-19-000027:notes:170]
As of March 31, 2019, the Company offers the 2006 Employee Share Purchase Plan, as amended and restated (Non-U.S.) (2006 ESPP), the 1996 Employee Share Purchase Plan (U.S.), as amended and restated  (1996 ESPP), the 2006 Stock Incentive Plan (2006 Plan) as amended and restated and the 2012 Stock Inducement Equity Plan (2012 Plan). Shares issued to employees as a result of purchases or exercises under these plans are generally issued from shares held in treasury stock.

[0001032975-19-000027:notes:171]
The following table summarizes share-based compensation expense and total income tax benefit recognized for fiscal years 2019, 2018 and 2017 (in thousands):

[0001032975-19-000027:notes:172]
|  |  | Years Ended March 31, |
|  |  | 2019 |  | 2018 |  | 2017 |
| Cost of goods sold |  | $ | 3,812 |  |  | $ | 3,733 |  |  | $ | 2,663 |  |
| Marketing and selling |  | 20,630 |  |  | 17,765 |  |  | 14,723 |  |
| Research and development |  | 7,368 |  |  | 6,381 |  |  | 4,200 |  |
| General and administrative |  | 18,455 |  |  | 16,259 |  |  | 14,304 |  |
| Total share-based compensation expense |  | 50,265 |  |  | 44,138 |  |  | 35,890 |  |
| Income tax benefit |  | (17,091 | ) |  | (15,998 | ) |  | (8,536 | ) |
| Total share-based compensation expense, net of income tax benefit |  | $ | 33,174 |  |  | $ | 28,140 |  |  | $ | 27,354 |  |

[0001032975-19-000027:notes:173]
The income tax benefit in the respective period primarily consists of tax benefit related to the share-based compensation expense for the period and direct tax benefit realized, including net excess tax benefits recognized from share-based awards vested or exercised upon the adoption of ASU 2016-09 on April 1, 2017. The income tax benefit for the year ended March 31, 2018 was reduced by the income tax provision resulting from the remeasurement of applicable deferred tax assets and liabilities due to the enactment of the Tax Act in the United States on December 22, 2017. See "Note 7 - Income Taxes" for more information.

[0001032975-19-000027:notes:174]
As of March 31, 2019, 2018 and 2017, the balance of capitalized stock-based compensation included in inventory was $0.9 million, $0.7 million and $0.6 million, respectively.

[0001032975-19-000027:notes:175]
The following table summarizes total unamortized share-based compensation expense and the remaining period over which such expense is expected to be recognized, on a weighted-average basis by type of grant (in thousands, except number of months):

[0001032975-19-000027:notes:176]
|  |  | March 31, 2019 |
|  |  | UnamortizedExpense |  | RemainingMonths |
| ESPP |  | $ | 1,515 |  |  | 4 |
| Stock Options |  | 7,384 |  |  | 35 |
| Time-based RSUs |  | 65,798 |  |  | 33 |
| Market-based and performance-based RSUs |  | 16,277 |  |  | 20 |
| Total unamortized share-based compensation expense |  | $ | 90,974 |  |  |  |

[0001032975-19-000027:notes:177]
Under the 1996 ESPP and 2006 ESPP plans, eligible employees may purchase shares at the lower of 85% of the fair market value at the beginning or the end of each offering period, which is generally six months. Subject to continued participation in these plans, purchase agreements are automatically executed at the end of each offering period. An aggregate of 29.0 million shares was reserved for issuance under the 1996 and 2006 ESPP plans. As of March 31, 2019, a total of 5.4 million shares was available for new awards under these plans.

[0001032975-19-000027:notes:178]
The 2006 Plan provides for the grant to eligible employees and non-employee directors of stock options, stock appreciation rights, restricted stock and RSUs. Awards under the 2006 Plan may be conditioned on continued employment, the passage of time or the satisfaction of performance and market vesting criteria. The 2006 Plan, as amended, has no expiration date. All stock options under this plan have terms not exceeding ten years and are issued at exercise prices not less than the fair market value on the date of grant. An aggregate of 30.6 million shares was reserved for issuance under the 2006 Plan. As of March 31, 2019, a total of 9.2 million shares was available for new awards under this plan.

[0001032975-19-000027:notes:179]
Time-based RSUs granted to employees under the 2006 Plan generally vest in four equal annual installments on the grant date anniversary. Time-based RSUs granted to non-executive board members under the 2006 Plan vest on the grant date anniversary, or if earlier and only if the non-executive board member is not re-elected as a director at such annual general meeting, the date of the next annual general meeting following the grant date.

[0001032975-19-000027:notes:180]
Performance-based RSUs granted in fiscal years 2016 and 2017 under the 2006 Plan vest contingent upon the achievement of predetermined financial metrics, the performance period of which is approximately three years. The performance condition can be achieved before the end of the performance period. Market-based options granted under the 2006 Plan vest upon meeting the Company's share price performance criteria. The number of shares of common stock to be received at vesting for market-based RSUs granted in fiscal years 2016 and 2017 under the 2006 Plan will range from 0 percent to 150 percent of the target number of stock units based on the Company's total stockholder return (TSR) relative to the performance of companies in the NASDAQ-100 Index for each measurement period, generally over a three-year period. In fiscal years 2018 and 2019, the Company granted RSUs with both performance and market conditions, which vest at the end of the three-year performance period upon meeting predetermined financial metrics over three years, with the number of shares to be received upon vesting determined based on weighted average constant currency revenue growth rate and the Company's TSR relative to the performance of companies in the NASDAQ-100 Index over the same three years period. The Company presents shares granted and vested at 100 percent of the target of the number of stock units that may potentially vest.

[0001032975-19-000027:notes:181]
Under the 2012 Plan, stock options and RSUs may be granted to eligible employees to serve as an inducement to enter into employment with the Company. Awards under the 2012 Plan may be conditioned on continued employment, the passage of time or the satisfaction of market stock performance criteria, based on individually written employment offer letter. The 2012 Plan has an expiration date of March 28, 2022. An aggregate of 1.8 million shares was reserved for issuance under the 2012 Plan. As of March 31, 2019, no shares were available for new awards under this plan.

[0001032975-19-000027:notes:182]
The estimates of share-based compensation expense require a number of complex and subjective assumptions including stock price volatility, employee exercise patterns, probability of achievement of the set performance condition, dividend yield, related tax effects and the selection of an appropriate fair value model.

[0001032975-19-000027:notes:183]
The grant date fair value of the awards using the Black-Scholes-Merton option-pricing valuation model and Monte-Carlo simulation method is determined with the following assumptions and values:

[0001032975-19-000027:notes:184]
|  |  | Stock Options |  | Employee Stock Purchase Plans |
|  |  | Years Ended March 31, |  | Years Ended March 31, |
|  |  | 2019 |  | 2018 |  | 2017 |  | 2019 |  | 2018 |  | 2017 |
| Dividend yield |  | 1.72 | % |  | * |  | * |  | 1.73 | % |  | 1.67 | % |  | 2.50 | % |
| Risk-free interest rate |  | 2.45 | % |  | * |  | * |  | 2.35 | % |  | 1.37 | % |  | 0.51 | % |
| Expected volatility |  | 33 | % |  | * |  | * |  | 31 | % |  | 27 | % |  | 35 | % |
| Expected life (years) |  | 6.2 |  |  | * |  | * |  | 0.5 |  |  | 0.5 |  |  | 0.5 |  |
| Weighted average grant date fair value per share |  | $ | 11.55 |  |  | * |  | * |  | $ | 9.33 |  |  | $ | 8.69 |  |  | $ | 5.73 |  |

[0001032975-19-000027:notes:185]
*  Not applicable as no stock options were granted in the period.

[0001032975-19-000027:notes:186]
| RSUs with Market Conditions |  | Years Ended March 31, |
|  |  | 2019 |  | 2018 |  | 2017 |
| Dividend yield |  | 1.59 | % |  | 1.75 | % |  | 3.29 | % |
| Risk-free interest rate |  | 2.51 | % |  | 1.40 | % |  | 0.86 | % |
| Expected volatility |  | 30 | % |  | 31 | % |  | 34 | % |
| Expected life (years) |  | 3.0 |  |  | 3.0 |  |  | 3.0 |  |

[0001032975-19-000027:notes:187]
The dividend yield assumption is based on the Company's history and future expectations of dividend payouts. The unvested RSUs or unexercised options are not eligible for these dividends. The expected life is based on the purchase offerings periods expected to remain outstanding for employee stock purchase plan, or the performance period for RSUs with market conditions. The expected life for stock options is based on historical settlement rates, which the Company believes are most representative of future exercise and post-vesting termination behaviors. Expected volatility is based on historical volatility using the Company's daily closing prices, or including the volatility of components of the NASDAQ 100 index for market-based RSUs, over the expected life. The Company considers the historical price volatility of its shares as most representative of future volatility. The risk-free interest rate

[0001032975-19-000027:notes:188]
assumptions are based upon the implied yield of U.S. Treasury zero-coupon issues appropriate for the expected life of the Company's share-based awards.

[0001032975-19-000027:notes:189]
For  RSUs with performance conditions, the Company estimates the probability and timing of the achievement of the set performance condition at the time of the grant based on the historical financial performance and the financial forecast in the remaining performance period and reassesses the probability in subsequent periods when actual results or new information become available.

[0001032975-19-000027:notes:190]
A summary of the Company's stock option activities under all stock plans for fiscal years 2019, 2018 and 2017 is as follows:

[0001032975-19-000027:notes:191]
|  |  | Number of Shares |  | Weighted-Average Exercise Price |  | Weighted-Average Remaining Contractual Term |  | Aggregate Intrinsic Value |
|  |  | (In thousands) |  |  |  | (Years) |  | (In thousands) |
| Outstanding, March 31, 2016 |  | 5,334 |  |  |  |  |  |  |  |  |
| Granted |  | — |  |  |  |  |  |  |  |  |
| Exercised |  | (1,784 | ) |  |  |  |  |  |  | $ | 14,627 |  |
| Canceled or expired |  | (500 | ) |  |  |  |  |  |  |  |
| Outstanding, March 31, 2017 |  | 3,050 |  |  |  |  |  |  |  |  |
| Granted |  | — |  |  |  |  |  |  |  |  |
| Exercised |  | (994 | ) |  |  |  |  |  |  | $ | 8,347 |  |
| Canceled or expired |  | (16 | ) |  |  |  |  |  |  |  |
| Outstanding, March 31, 2018 |  | 2,040 |  |  | $ | 14 |  |  |  |  |  |  |
| Granted |  | 649 |  |  | $ | 39 |  |  |  |  |  |  |
| Exercised |  | (82 | ) |  | $ | 21 |  |  |  |  | $ | 1,707 |  |
| Canceled or expired |  | — |  |  |  |  |  |  |  |  |  |
| Outstanding, March 31, 2019 |  | 2,607 |  |  | $ | 20 |  |  | 4.8 |  | $ | 51,005 |  |
| Vested and exercisable, March 31, 2019 |  | 1,958 |  |  | $ | 13 |  |  | 3.1 |  | $ | 50,593 |  |

[0001032975-19-000027:notes:192]
As of March 31, 2019, the exercise price of outstanding options ranged from $2 to $39 per share option.

[0001032975-19-000027:notes:193]
The tax benefit realized for the tax deduction from options exercised during fiscal years 2019, 2018 and 2017 was $0.2 million, $1.8 million and $4.2 million, respectively.

[0001032975-19-000027:notes:194]
A summary of the Company's time-based, market-based, and performance-based RSU activities for fiscal years 2019, 2018 and 2017 is as follows:

[0001032975-19-000027:notes:195]
|  |  | Number of Shares |  | Weighted-Average Grant Date Fair Value |  | Weighted-Average Remaining Vesting Period |  | Aggregate Fair Value |
|  |  | (In thousands) |  |  |  | (Years) |  | (In thousands) |
| Outstanding, March 31, 2016 |  | 5,521 |  |  |  |  |  |  |  |  |
| Granted—time-based |  | 2,390 |  |  | $ | 16 |  |  |  |  |  |
| Granted—market-based |  | 160 |  |  | $ | 15 |  |  |  |  |  |
| Granted - performance-based |  | 604 |  |  | $ | 15 |  |  |  |  |  |
| Vested |  | (2,126 | ) |  |  |  |  |  |  | $ | 48,644 |  |
| Canceled or expired |  | (368 | ) |  |  |  |  |  |  |  |
| Outstanding, March 31, 2017 |  | 6,181 |  |  | $ | 14 |  |  |  |  |  |
| Granted—time-based |  | 1,212 |  |  | $ | 33 |  |  |  |  |  |
| Granted - performance-based |  | 409 |  |  | $ | 33 |  |  |  |  |  |
| Vested |  | (2,248 | ) |  |  |  |  |  |  | $ | 81,582 |  |
| Canceled or expired |  | (333 | ) |  |  |  |  |  |  |  |
| Outstanding, March 31, 2018 |  | 5,221 |  |  | $ | 20 |  |  |  |  |  |
| Granted—time-based |  | 1,290 |  |  | $ | 40 |  |  |  |  |  |
| Granted—market and performance-based |  | 381 |  |  | $ | 39 |  |  |  |  |  |
| Vested |  | (2,148 | ) |  | $ | 17 |  |  |  |  | $ | 89,159 |  |
| Canceled or expired |  | (323 | ) |  | $ | 26 |  |  |  |  |  |
| Outstanding, March 31, 2019 |  | 4,421 |  |  | $ | 29 |  |  | 1.2 |  | $ | 173,970 |  |

[0001032975-19-000027:notes:196]
The RSU outstanding as of March 31, 2019 above includes 1.1 million shares with market-based and performance-based vesting conditions.

[0001032975-19-000027:notes:197]
The tax benefit realized for the tax deduction from RSUs that vested during fiscal years 2019, 2018 and 2017 was $16.2 million, $20.3 million and $13.1 million, respectively.

[0001032975-19-000027:notes:198]
Defined Contribution Plans

[0001032975-19-000027:notes:199]
Certain of the Company's subsidiaries have defined contribution employee benefit plans covering all or a portion of their employees. Contributions to these plans are discretionary for certain plans and are based on specified or statutory requirements for others. The charges to expense for these plans for fiscal years 2019, 2018 and 2017, were $8.7 million, $7.6 million and $5.8 million, respectively.

[0001032975-19-000027:notes:200]
Defined Benefit Plans

[0001032975-19-000027:notes:201]
Certain of the Company's subsidiaries sponsor defined benefit pension plans or non-retirement post-employment benefits covering substantially all of their employees. Benefits are provided based on employees' years of service and earnings, or in accordance with applicable employee benefit regulations. The Company's practice is to fund amounts sufficient to meet the requirements set forth in the applicable employee benefit and tax regulations.

[0001032975-19-000027:notes:202]
The Company recognizes the overfunded or underfunded status of defined benefit pension plans and non-retirement post-employment benefit obligations as an asset or liability in its consolidated balance sheets and recognizes changes in the funded status of defined benefit pension plans in the year in which the changes occur through accumulated other comprehensive income (loss), which is a component of shareholders' equity. Each plan's assets and benefit obligations are remeasured as of March 31 each year.

[0001032975-19-000027:notes:203]
The net periodic benefit cost of the defined benefit pension plans and the non-retirement post-employment benefit obligations for fiscal years 2019, 2018 and 2017 was as follows (in thousands):

[0001032975-19-000027:notes:204]
|  |  | Years Ended March 31, |
|  |  | 2019 |  | 2018 |  | 2017 |
| Service costs |  | $ | 10,564 |  |  | $ | 9,715 |  |  | $ | 10,385 |  |
| Interest costs |  | 1,301 |  |  | 1,126 |  |  | 800 |  |
| Expected return on plan assets |  | (2,167 | ) |  | (1,792 | ) |  | (1,724 | ) |
| Amortization: |  |  |  |  |  |  |
| Net transition obligation |  | — |  |  | — |  |  | 4 |  |
| Net prior service credit recognized |  | (443 | ) |  | (51 | ) |  | (117 | ) |
| Net actuarial loss recognized |  | 450 |  |  | 242 |  |  | 1,032 |  |
| Settlement |  | (97 | ) |  | — |  |  | — |  |
| Total net periodic benefit cost |  | $ | 9,608 |  |  | $ | 9,240 |  |  | $ | 10,380 |  |

[0001032975-19-000027:notes:205]
The components of net periodic benefit cost other than the service costs component are included in the line “other income(expense), net” in the consolidated statements of operations.

[0001032975-19-000027:notes:206]
The changes in projected benefit obligations for fiscal years 2019 and 2018 were as follows (in thousands):

[0001032975-19-000027:notes:207]
|  |  | Years Ended March 31, |
|  |  | 2019 |  | 2018 |
| Projected benefit obligations, beginning of the year |  | $ | 128,915 |  |  | $ | 114,640 |  |
| Service costs |  | 10,564 |  |  | 9,715 |  |
| Interest costs |  | 1,301 |  |  | 1,126 |  |
| Plan participant contributions |  | 3,666 |  |  | 3,522 |  |
| Actuarial gains (losses) |  | 9,506 |  |  | (1,580 | ) |
| Benefits paid |  | (3,793 | ) |  | (1,202 | ) |
| Plan amendment related to statutory change |  | (705 | ) |  | (2,519 | ) |
| Settlement and curtailment |  | (335 | ) |  | — |  |
| Administrative expense paid |  | (142 | ) |  | (144 | ) |
| Currency exchange rate changes and other |  | (5,315 | ) |  | 5,357 |  |
| Projected benefit obligations, end of the year |  | $ | 143,662 |  |  | $ | 128,915 |  |

[0001032975-19-000027:notes:208]
The accumulated benefit obligation for all defined benefit pension plans as of March 31, 2019 and 2018 was $118.7 million and $108.9 million, respectively.

[0001032975-19-000027:notes:209]
The following table presents the changes in the fair value of defined benefit pension plan assets for fiscal years 2019 and 2018 (in thousands):

[0001032975-19-000027:notes:210]
|  |  | Years Ended March 31, |
|  |  | 2019 |  | 2018 |
| Fair value of plan assets, beginning of the year |  | $ | 84,718 |  |  | $ | 71,376 |  |
| Actual return on plan assets |  | 3,350 |  |  | 1,824 |  |
| Employer contributions |  | 6,383 |  |  | 5,995 |  |
| Plan participant contributions |  | 3,666 |  |  | 3,522 |  |
| Benefits paid |  | (3,793 | ) |  | (1,202 | ) |
| Settlement and curtailment |  | (335 | ) |  | — |  |
| Administrative expenses paid |  | (142 | ) |  | (144 | ) |
| Currency exchange rate changes |  | (3,482 | ) |  | 3,347 |  |
| Fair value of plan assets, end of the year |  | $ | 90,365 |  |  | $ | 84,718 |  |

[0001032975-19-000027:notes:211]
The Company's investment objectives are to ensure that the assets of its defined benefit plans are invested to provide an optimal rate of investment return on the total investment portfolio, consistent with the assumption of a reasonable risk level, and to ensure that pension funds are available to meet the plans' benefit obligations as they become due. The Company believes that a well-diversified investment portfolio will result in the highest attainable investment return with an acceptable level of overall risk. Investment strategies and allocation decisions are also governed by applicable governmental regulatory agencies. The Company's investment strategy with respect to its largest defined benefit plan, which is available only to Swiss employees, is to invest per the following allocation: 33% in equities, 34% in bonds, 28% in real estate, 2% in cash and cash equivalents and the remaining in other investments. The Company also can invest in real estate funds, commodity funds, and hedge funds depending upon economic conditions.

[0001032975-19-000027:notes:212]
The following tables present the fair value of the defined benefit pension plan assets by major categories and by levels within the fair value hierarchy as of March 31, 2019 and 2018 (in thousands):

[0001032975-19-000027:notes:213]
|  |  | March 31, |
|  |  | 2019 |  | 2018 |
|  |  | Level 1 |  | Level 2 |  | Total |  | Level 1 |  | Level 2 |  | Total |
| Cash and cash equivalents |  | $ | 10,737 |  |  | $ | — |  |  | $ | 10,737 |  |  | $ | 18,331 |  |  | $ | 24 |  |  | $ | 18,355 |  |
| Equity securities |  | 27,559 |  |  | — |  |  | 27,559 |  |  | 26,204 |  |  | — |  |  | 26,204 |  |
| Debt securities |  | 26,823 |  |  | — |  |  | 26,823 |  |  | 25,150 |  |  | — |  |  | 25,150 |  |
| Swiss real estate funds |  | 21,659 |  |  | — |  |  | 21,659 |  |  | 12,096 |  |  | — |  |  | 12,096 |  |
| Hedge funds |  | — |  |  | 912 |  |  | 912 |  |  | — |  |  | — |  |  | — |  |
| Other |  | 2,377 |  |  | 298 |  |  | 2,675 |  |  | 2,623 |  |  | 290 |  |  | 2,913 |  |
| Total fair value of plan assets |  | $ | 89,155 |  |  | $ | 1,210 |  |  | $ | 90,365 |  |  | $ | 84,404 |  |  | $ | 314 |  |  | $ | 84,718 |  |

[0001032975-19-000027:notes:214]
The funded status of the plans was as follows (in thousands):

[0001032975-19-000027:notes:215]
|  |  | Years Ended March 31, |
|  |  | 2019 |  | 2018 |
| Fair value of plan assets |  | $ | 90,365 |  |  | $ | 84,718 |  |
| Less: projected benefit obligations |  | 143,662 |  |  | 128,915 |  |
| Underfunded status |  | $ | (53,297 | ) |  | $ | (44,197 | ) |

[0001032975-19-000027:notes:216]
Amounts recognized on the balance sheet for the plans were as follows (in thousands):

[0001032975-19-000027:notes:217]
|  |  | March 31, |
|  |  | 2019 |  | 2018 |
| Current liabilities |  | $ | 1,849 |  |  | $ | 1,763 |  |
| Non-current liabilities |  | 51,448 |  |  | 42,434 |  |
| Total liabilities |  | $ | 53,297 |  |  | $ | 44,197 |  |

[0001032975-19-000027:notes:218]
Amounts recognized in accumulated other comprehensive loss related to defined benefit pension plans were as follows (in thousands):

[0001032975-19-000027:notes:219]
|  |  | March 31, |
|  |  | 2019 |  | 2018 |  | 2017 |
| Net prior service credits |  | $ | 3,965 |  |  | $ | 3,843 |  |  | $ | 1,274 |  |
| Net actuarial loss |  | (17,630 | ) |  | (9,821 | ) |  | (11,407 | ) |
| Accumulated other comprehensive loss |  | (13,665 | ) |  | (5,978 | ) |  | (10,133 | ) |
| Deferred tax |  | (267 | ) |  | (420 | ) |  | (347 | ) |
| Accumulated other comprehensive loss, net of tax |  | $ | (13,932 | ) |  | $ | (6,398 | ) |  | $ | (10,480 | ) |

[0001032975-19-000027:notes:220]
The following table presents the amounts included in accumulated other comprehensive loss as of March 31, 2019, which are expected to be recognized as a component of net periodic benefit cost in fiscal year 2020 (in thousands):

[0001032975-19-000027:notes:221]
|  |  | Year EndingMarch 31, 2020 |
| Amortization of net prior service credits |  | $ | (432 | ) |
| Amortization of net actuarial loss |  | 645 |  |
|  |  | $ | 213 |  |

[0001032975-19-000027:notes:222]
The Company reassesses its benefit plan assumptions on a regular basis. The actuarial assumptions for the defined benefit plans for fiscal years 2019 and 2018 were as follows:

[0001032975-19-000027:notes:223]
|  |  | Years Ended March 31, |
|  |  | 2019 |  | 2018 |
| Benefit Obligations: |  |  |  |  |
| Discount rate |  | 0.55% - 7.25% |  | 0.85%-7.50% |
| Estimated rate of compensation increase |  | 2.50% - 10.00% |  | 2.25%-10.00% |
| Periodic Costs: |  |  |  |  |
| Discount rate |  | 0.75% - 7.50% |  | 0.75%-7.00% |
| Estimated rate of compensation increase |  | 2.50% - 10.00% |  | 2.50%-10.00% |
| Expected average rate of return on plan assets |  | 0.75% - 2.75% |  | 1.00%-2.50% |

[0001032975-19-000027:notes:224]
The discount rate is estimated based on corporate bond yields or securities of similar quality in the respective country, with a duration approximating the period over which the benefit obligations are expected to be paid. The Company bases the compensation increase assumptions on historical experience and future expectations. The expected average rate of return for the Company's defined benefit pension plans represents the average rate of return expected to be earned on plan assets over the period that the benefit obligations are expected to be paid, based on government bond notes in the respective country, adjusted for corporate risk premiums as appropriate.

[0001032975-19-000027:notes:225]
The following table reflects the benefit payments that the Company expects the plans to pay in the periods noted (in thousands):

[0001032975-19-000027:notes:226]
| Years Ending March 31, |  |  |
| 2020 |  | $ | 7,956 |  |
| 2021 |  | 7,225 |  |
| 2022 |  | 7,553 |  |
| 2023 |  | 7,294 |  |
| 2024 |  | 7,607 |  |
| 2025-2029 |  | 39,367 |  |
|  |  | $ | 77,002 |  |

[0001032975-19-000027:notes:227]
The Company expects to contribute $5.5 million to its defined benefit pension plans during fiscal year 2020.

[0001032975-19-000027:notes:228]
Deferred Compensation Plan

[0001032975-19-000027:notes:229]
One of the Company's subsidiaries offers a deferred compensation plan that permits eligible employees to make 100% vested salary and incentive compensation deferrals within established limits. The Company does not make contributions to the plan.

[0001032975-19-000027:notes:230]
The deferred compensation plan's assets consist of marketable securities and are included in other assets on the consolidated balance sheets. The marketable securities are classified as trading investments and were recorded at a fair value of $20.4 million and $17.7 million as of March 31, 2019 and 2018, respectively, based on quoted market prices. The Company also had $20.4 million and $17.7 million in deferred compensation liability as of March 31, 2019 and 2018, respectively. Earnings, gains and losses on trading investments are included in other

[0001032975-19-000027:notes:231]
income (expense), net and corresponding changes in deferred compensation liability are included in operating expenses and cost of goods sold.


## us-gaap:InterestAndOtherIncomeTextBlock

[0001032975-19-000027:notes:232]
Other Income (Expense), net
Other income (expense), net comprises of the following (in thousands):

[0001032975-19-000027:notes:233]
|  |  | Years Ended March 31, |
|  |  | 2019 |  | 2018 |  | 2017 |
| Investment income related to the deferred compensation plan |  | $ | 664 |  |  | $ | 1,386 |  |  | $ | 1,343 |  |
| Currency exchange gain (loss), net |  | (3,608 | ) |  | (4,613 | ) |  | 169 |  |
| Other |  | 2,508 |  |  | 790 |  |  | 165 |  |
| Other income (expense), net |  | $ | (436 | ) |  | $ | (2,437 | ) |  | $ | 1,677 |  |

[0001032975-19-000027:notes:234]
The components of net periodic benefit cost other than the service cost component for the year ended March 31, 2019 are included in the line “Other” above as a result of adopting ASU 2017-07 effective April 1, 2018. The impact to the comparative periods was immaterial and therefore the prior period statements of operations were not revised.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001032975-19-000027:notes:235]
Income Taxes 
The Company is incorporated in Switzerland but operates in various countries with differing tax laws and rates. Further, a portion of the Company's income (loss) before taxes and the provision for (benefit from) income taxes is generated outside of Switzerland.

[0001032975-19-000027:notes:236]
Income from continuing operations before income taxes for fiscal years 2019, 2018 and 2017 is summarized as follows (in thousands):

[0001032975-19-000027:notes:237]
|  |  | Years Ended March 31, |
|  |  | 2019 |  | 2018 |  | 2017 |
| Swiss |  | $ | 212,986 |  |  | $ | 177,935 |  |  | $ | 161,544 |  |
| Non-Swiss |  | 58,147 |  |  | 54,330 |  |  | 53,445 |  |
| Income before taxes |  | $ | 271,133 |  |  | $ | 232,265 |  |  | $ | 214,989 |  |

[0001032975-19-000027:notes:238]
The provision for (benefit from) income taxes is summarized as follows (in thousands):

[0001032975-19-000027:notes:239]
|  |  | Years Ended March 31, |
|  |  | 2019 |  | 2018 |  | 2017 |
| Current: |  |  |  |  |  |  |
| Swiss |  | $ | 1,364 |  |  | $ | 3,526 |  |  | $ | 1,934 |  |
| Non-Swiss |  | 24,334 |  |  | 13,142 |  |  | 9,774 |  |
| Deferred: |  |  |  |  |  |  |
| Non-Swiss |  | (12,138 | ) |  | 7,055 |  |  | (2,595 | ) |
| Provision for income taxes |  | $ | 13,560 |  |  | $ | 23,723 |  |  | $ | 9,113 |  |

[0001032975-19-000027:notes:240]
The difference between the provision for income taxes and the expected tax provision at the statutory income tax rate of 8.5% is reconciled below (in thousands):

[0001032975-19-000027:notes:241]
|  |  | Years Ended March 31, |
|  |  | 2019 |  | 2018 |  | 2017 |
| Expected tax provision at statutory income tax rates |  | $ | 23,046 |  |  | $ | 19,743 |  |  | $ | 18,274 |  |
| Income taxes at different rates |  | (10,113 | ) |  | (9,611 | ) |  | (5,247 | ) |
| Research and development tax credits |  | (5,432 | ) |  | (4,124 | ) |  | (2,309 | ) |
| Executive compensation |  | 3,344 |  |  | 1,835 |  |  | 654 |  |
| Stock-based compensation |  | (7,288 | ) |  | (9,376 | ) |  | 1,794 |  |
| Deferred tax effects from Tax Act |  | — |  |  | 22,325 |  |  | — |  |
| Valuation allowance |  | 1,891 |  |  | 533 |  |  | 1,024 |  |
| Restructuring charges / (credits) |  | 961 |  |  | (10 | ) |  | 2 |  |
| Tax reserves (releases), net |  | 8,269 |  |  | 3,627 |  |  | (5,570 | ) |
| Other, net |  | (1,118 | ) |  | (1,219 | ) |  | 491 |  |
| Provision for income taxes |  | $ | 13,560 |  |  | $ | 23,723 |  |  | $ | 9,113 |  |

[0001032975-19-000027:notes:242]
Deferred income tax assets and liabilities consist of the following (in thousands):

[0001032975-19-000027:notes:243]
|  |  | March 31, |
|  |  | 2019 |  | 2018 |
| Deferred tax assets: |  |  |  |  |  |  |
| Net operating loss carryforwards |  | $ | 16,323 |  |  | $ | 15,476 |  |
| Tax credit carryforwards |  | 52,263 |  |  | 45,421 |  |
| Accruals |  | 52,304 |  |  | 42,765 |  |
| Depreciation and amortization |  | 5,716 |  |  | 1,505 |  |
| Share-based compensation |  | 8,703 |  |  | 7,479 |  |
| Gross deferred tax assets |  | 135,309 |  |  | 112,646 |  |
| Valuation allowance |  | (28,375 | ) |  | (25,148 | ) |
| Gross deferred tax assets after valuation allowance |  | 106,934 |  |  | 87,498 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |
| Acquired intangible assets and other |  | (18,176 | ) |  | (4,827 | ) |
| Gross deferred tax liabilities |  | (18,176 | ) |  | (4,827 | ) |
| Deferred tax assets, net |  | $ | 88,758 |  |  | $ | 82,671 |  |

[0001032975-19-000027:notes:244]
The Tax Act enacted in the United States in fiscal year 2018 permanently reduced the corporate income tax rate from 35% to 21% effective for tax years including or commencing on January 1, 2018. It also repealed corporate alternative minimum tax, limited various business deductions such as executive compensation under IRC 162(m) and modified the maximum deduction of net operating loss with no carryback but indefinite carryforward provision among other things. The Company recorded a provisional income tax charge of $21.7 million, net of valuation allowance against tax credits, in fiscal year 2018 to remeasure the deferred tax effects at 21%.

[0001032975-19-000027:notes:245]
The Company completed its review, in the third quarter of fiscal year 2019, of previously recorded provisional income tax amounts related to net deferred tax assets impacted by the Tax Act and concluded that additional information, interpretation and guidance that became available during the twelve-month measurement period did not alter the Company’s application of tax law in remeasuring gross deferred tax assets and related valuation allowance. There were no adjustments deemed necessary in fiscal year 2019.

[0001032975-19-000027:notes:246]
Management regularly assesses the ability to realize deferred tax assets recorded in the Company's entities based upon the weight of available evidence, including such factors as recent earnings history and expected future taxable income. In the event that the Company changes its determination as to the amount of deferred tax assets

[0001032975-19-000027:notes:247]
that can be realized, the Company will adjust its valuation allowance with a corresponding impact to the provision for income taxes in the period in which such determination is made.

[0001032975-19-000027:notes:248]
The Company had a valuation allowance of $28.4 million at March 31, 2019, compared to $25.1 million at March 31, 2018. The federal valuation allowance against tax credits was reduced from $2.3 million as of March 31, 2018 to $1.9 million as of March 31, 2019 due to a release of $0.4 million. The Company had a valuation allowance of $25.7 million as of March 31, 2019 against deferred tax assets in the state of California, an increase from $22.1 million as of March 31, 2018. The increase primarily relates to $2.3 million and $1.3 million from activities related to deferred tax assets and the acquisition of Blue Microphones, respectively. The remaining valuation allowance primarily represents $0.8 million for various tax credit carryforwards. The Company determined that it is more likely than not that the Company would not generate sufficient taxable income in the future to utilize such deferred tax assets.

[0001032975-19-000027:notes:249]
As of March 31, 2019, the Company had foreign net operating loss and tax credit carryforwards for income tax purposes of $252.6 million and $58.1 million. Unused net operating loss carryforwards will expire at various dates in fiscal years 2020 to 2039. Certain net operating loss carryforwards in the United States relate to acquisitions and, as a result, are limited in the amount that can be utilized in any one year. The tax credit carryforwards will begin to expire in fiscal year 2020.

[0001032975-19-000027:notes:250]
Swiss income taxes and non-Swiss withholding taxes associated with the repatriation of earnings or for other temporary differences related to investments in non-Swiss subsidiaries have not been provided for, as the Company intends to reinvest the earnings of such subsidiaries indefinitely or the Company has concluded that no additional tax liability would arise on the distribution of such earnings. If these earnings were distributed to Switzerland in the form of dividends or otherwise, or if the shares of the relevant non-Swiss subsidiaries were sold or otherwise transferred, the Company may be subject to additional Swiss income taxes and non-Swiss withholding taxes. As of March 31, 2019, the cumulative amount of unremitted earnings of non-Swiss subsidiaries for which no income taxes have been provided is approximately $100.3 million. The amount of unrecognized deferred income tax liability related to these earnings is estimated to be approximately $0.8 million.

[0001032975-19-000027:notes:251]
The Company follows a two-step approach in recognizing and measuring uncertain tax positions. The first step is to evaluate the tax position for recognition by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step is to measure the tax benefit as the largest amount that is more than 50% likely of being realized upon ultimate settlement.

[0001032975-19-000027:notes:252]
As of March 31, 2019 and 2018, the total amount of unrecognized tax benefits due to uncertain tax positions was $76.5 million and $69.1 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-19-000027:notes:253]
As of March 31, 2019 and 2018, the Company had $36.4 million and $35.0 million, respectively, in non-current income taxes payable, including interest and penalties, related to the Company's income tax liability for uncertain tax positions.

[0001032975-19-000027:notes:254]
The aggregate changes in gross unrecognized tax benefits in fiscal years 2019, 2018 and 2017 were as follows (in thousands):

[0001032975-19-000027:notes:255]
| March 31, 2016 |  | $ | 69,879 |  |
| Lapse of statute of limitations |  | (14,161 | ) |
| Decreases in balances related to tax positions taken during prior years |  | (1,610 | ) |
| Increases in balances related to tax positions taken during the year |  | 9,559 |  |
| March 31, 2017 |  | $ | 63,667 |  |
| Lapse of statute of limitations |  | (7,505 | ) |
| Decreases in balances related to tax positions taken during prior years |  | (704 | ) |
| Increases in balances related to tax positions taken during the year |  | 13,673 |  |
| March 31, 2018 |  | $ | 69,131 |  |
| Lapse of statute of limitations |  | (2,511 | ) |
| Decreases in balances related to tax positions taken during prior years |  | (1,550 | ) |
| Increases in balances related to tax positions taken during the year |  | 11,479 |  |
| March 31, 2019 |  | $ | 76,549 |  |

[0001032975-19-000027:notes:256]
The Company recognizes interest and penalties related to unrecognized tax positions in income tax expense. The Company recognized $0.6 million, $0.6 million and $0.7 million in interest and penalties in income tax expense during fiscal years 2019, 2018 and 2017, respectively. As of March 31, 2019 and 2018, the Company had $2.5 million and $2.3 million, respectively, of accrued interest and penalties related to uncertain tax positions.

[0001032975-19-000027:notes:257]
The Company files Swiss and foreign tax returns. The Company received final tax assessments in Switzerland through fiscal year 2017. For other foreign jurisdictions such as the United States, the Company is generally not subject to tax examinations for years prior to fiscal year 2016. The Company is under examination and has received assessment notices in foreign tax jurisdictions. If the examinations are resolved unfavorably, there is a possibility they may have a material negative impact on its results of operations.
Although the Company has adequately provided for uncertain tax positions, the provisions on these positions may change as revised estimates are made or the underlying matters are settled or otherwise resolved. During the next 12 months, it is reasonably possible that the amount of unrecognized tax benefits could increase or decrease significantly due to changes in tax law in various jurisdictions, new tax audits and changes in the U.S. Dollar as compared to other currencies. Excluding these factors, uncertain tax positions may decrease by as much as $3.8 million primarily from the lapse of the statutes of limitations in various jurisdictions during the next 12 months.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001032975-19-000027:notes:258]
Balance Sheet Components
The following table presents the components of certain balance sheet asset amounts as of March 31, 2019 and 2018 (in thousands):

[0001032975-19-000027:notes:259]
|  |  | March 31, |
|  |  | 2019 |  | 2018 |
| Accounts receivable, net: |  |  |  |  |  |
| Accounts receivable |  | $ | 573,348 |  |  | $ | 482,872 |  |
| Allowance for doubtful accounts |  | (84 | ) |  | (122 | ) |
| Allowance for sales returns (1) |  | (6,486 | ) |  | (25,515 | ) |
| Allowance for cooperative marketing arrangements (1) |  | (35,080 | ) |  | (30,389 | ) |
| Allowance for customer incentive programs (1) |  | (60,036 | ) |  | (70,592 | ) |
| Allowance for pricing programs (1) |  | (88,353 | ) |  | (141,369 | ) |
|  |  | $ | 383,309 |  |  | $ | 214,885 |  |
| Inventories: |  |  |  |  |  |  |
| Raw materials |  | $ | 40,970 |  |  | $ | 33,603 |  |
| Finished goods |  | 252,525 |  |  | 226,303 |  |
|  |  | $ | 293,495 |  |  | $ | 259,906 |  |
| Other current assets: |  |  |  |  |  |  |
| Value-added tax receivables |  | $ | 34,321 |  |  | $ | 29,477 |  |
| Prepaid expenses and other assets (1) |  | 34,795 |  |  | 26,885 |  |
|  |  | $ | 69,116 |  |  | $ | 56,362 |  |
| Property, plant and equipment, net: |  |  |  |  |  |  |
| Plant, buildings and improvements |  | $ | 65,219 |  |  | $ | 60,747 |  |
| Equipment and tooling |  | 197,540 |  |  | 183,466 |  |
| Computer equipment |  | 24,132 |  |  | 22,752 |  |
| Software |  | 62,663 |  |  | 65,723 |  |
|  |  | 349,554 |  |  | 332,688 |  |
| Less: accumulated depreciation and amortization |  | (280,793 | ) |  | (260,284 | ) |
|  |  | 68,761 |  |  | 72,404 |  |
| Construction-in-process |  | 7,021 |  |  | 11,029 |  |
| Land |  | 2,770 |  |  | 2,871 |  |
|  |  | $ | 78,552 |  |  | $ | 86,304 |  |
| Other assets: |  |  |  |  |  |  |
| Deferred tax assets |  | $ | 90,808 |  |  | $ | 84,651 |  |
| Trading investments for deferred compensation plan |  | 20,363 |  |  | 17,748 |  |
| Investment in privately held companies |  | 16,022 |  |  | 12,448 |  |
| Other assets |  | 5,260 |  |  | 5,908 |  |
|  |  | $ | 132,453 |  |  | $ | 120,755 |  |

[0001032975-19-000027:notes:260]
The following table presents the components of certain balance sheet liability amounts as of March 31, 2019 and 2018 (in thousands):

[0001032975-19-000027:notes:261]
|  |  | March 31, |
|  |  | 2019 |  | 2018 |
| Accrued and other current liabilities: |  |  |  |  |  |  |
| Accrued personnel expenses |  | $ | 103,166 |  |  | $ | 82,330 |  |
| Accrued sales return liability (1) |  | 37,749 |  |  | — |  |
| Accrued customer marketing, pricing and incentive programs (1) |  | 143,888 |  |  | 71,962 |  |
| Warranty accrual |  | 21,524 |  |  | 16,279 |  |
| Income taxes payable |  | 6,207 |  |  | 4,354 |  |
| Other current liabilities |  | 121,363 |  |  | 106,807 |  |
|  |  | $ | 433,897 |  |  | $ | 281,732 |  |
| Other non-current liabilities: |  |  |  |  |  |  |
| Warranty accrual |  | $ | 12,705 |  |  | $ | 11,294 |  |
| Obligation for deferred compensation plan |  | 20,363 |  |  | 17,748 |  |
| Employee benefit plan obligation |  | 51,448 |  |  | 42,434 |  |
| Deferred tax liability |  | 2,050 |  |  | 1,980 |  |
| Other non-current liabilities |  | 7,016 |  |  | 8,468 |  |
|  |  | $ | 93,582 |  |  | $ | 81,924 |  |

[0001032975-19-000027:notes:262]
(1) Certain allowances for sales return and certain other Customer Programs were included within accounts receivable, net balance as of March 31, 2018. Upon adoption of Topic 606, such balances are presented as accrued revenue reserve from returns and accrued customer marketing, pricing and incentive programs included in accrued and other current liabilities, and as return assets included in other current assets, respectively, on the consolidated balance sheet as of March 31, 2018. Refer to Note 2 to the consolidated financial statements for more information.


## logi:ScheduleOfBalanceSheetComponentsAssetsTableTextBlock

[0001032975-19-000027:notes:263]
The following table presents the components of certain balance sheet asset amounts as of March 31, 2019 and 2018 (in thousands):


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001032975-19-000027:notes:264]
Fair Value Measurements
The Company considers fair value as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants at the measurement date. The Company utilizes the following three-level fair value hierarchy to establish the priorities of the inputs used to measure fair value:

[0001032975-19-000027:notes:265]
| • | Level 1—Quoted prices in active markets for identical assets or liabilities. |

[0001032975-19-000027:notes:266]
| • | Level 2—Observable inputs other than quoted market prices included in Level 1, such as quoted prices for similar assets and liabilities in active markets; quoted prices for identical or similar assets and liabilities in markets that are not active; or other inputs that are observable or can be corroborated by observable market data. |

[0001032975-19-000027:notes:267]
| • | Level 3—Unobservable inputs that are supported by little or no market activity and that are significant to the fair value of the assets or liabilities. This includes certain pricing models, discounted cash flow methodologies and similar techniques that use significant unobservable inputs. |

[0001032975-19-000027:notes:268]
The following table presents the Company's financial assets and liabilities that were accounted for at fair value on a recurring basis, excluding assets related to the Company's defined benefit pension plans, classified by the level within the fair value hierarchy (in thousands):

[0001032975-19-000027:notes:269]
|  |  | March 31, 2019 |  | March 31, 2018 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Level 1 |  | Level 2 |  | Level 3 |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 496,434 |  |  | $ | — |  |  | $ | — |  |  | $ | 492,535 |  |  | $ | — |  |  | $ | — |  |
| Trading investments for deferred compensation plan included in other assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 4,080 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,881 |  |  | $ | — |  |  | $ | — |  |
| Mutual funds |  | 16,283 |  |  | — |  |  | — |  |  | 14,867 |  |  | — |  |  | — |  |
| Total of trading investments for deferred compensation plan |  | $ | 20,363 |  |  | $ | — |  |  | $ | — |  |  | $ | 17,748 |  |  | $ | — |  |  | $ | — |  |
| Currency derivative assets included in other current assets |  | $ | — |  |  | $ | 455 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Currency derivative liabilities included in accrued and other current liabilities |  | $ | — |  |  | $ | 36 |  |  | $ | — |  |  | $ | — |  |  | $ | 34 |  |  | $ | — |  |

[0001032975-19-000027:notes:270]
Investment Securities

[0001032975-19-000027:notes:271]
The marketable securities for the Company's deferred compensation plan are recorded at a fair value of $20.4 million and $17.7 million as of March 31, 2019 and 2018, respectively, based on quoted market prices. Quoted market prices are observable inputs that are classified as Level 1 within the fair value hierarchy. Unrealized trading gains related to trading securities for fiscal years 2019, 2018 and 2017 were not material and are included in other income (expense), net in the consolidated statements of operations.

[0001032975-19-000027:notes:272]
Equity Method Investments

[0001032975-19-000027:notes:273]
The Company has certain non-marketable investments included in other assets that are accounted for under the equity method of accounting, with a carrying value of $6.6 million and $5.1 million as of March 31, 2019 and 2018, respectively.

[0001032975-19-000027:notes:274]
Assets Measured at Fair Value on a Nonrecurring Basis

[0001032975-19-000027:notes:275]
The Company’s non-financial assets, such as intangible assets and acquisition-related property, plant and equipment, are recorded at fair value only upon initial recognition or if an impairment is recognized. There was no impairment of long-lived assets during fiscal years 2019, 2018 and 2017.

[0001032975-19-000027:notes:276]
Financial Assets. The Company has certain investments in equity securities of privately held entities without readily determinable fair values due to the absence of quoted market prices, the inherent lack of liquidity, and the fact that inputs used to measure fair value are unobservable and require management's judgment. When certain events or circumstances indicate that impairment may exist, the Company revalues the investments using various assumptions, including the financial metrics and ratios of comparable public companies. The carrying value is also adjusted for observable price changes with the same or similar security from the same issuer. The amount of these investments included in other assets as of March 31, 2019 and March 31, 2018 was $9.5 million and $7.3 million, respectively. There was no impairment of these assets during fiscal years 2019 and 2018.

[0001032975-19-000027:notes:277]
Non-Financial Assets. Goodwill, intangible assets, and property, plant and equipment, are not required to be measured at fair value on a recurring basis. However, if certain triggering events occur (or tested at least annually for goodwill) such that a non-financial instrument is required to be evaluated for impairment and an impairment is recorded to reduce the non-financial instrument's carrying value to the fair value as a result of such triggering events, the non-financial assets and liabilities are measured at fair value for the period such triggering events occur. See Note 2 to the consolidated financial statements for additional information about how the Company tests various asset classes for impairment.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001032975-19-000027:notes:278]
Derivative Financial Instruments
 Under certain agreements with the respective counterparties to the Company's derivative contracts, subject to applicable requirements, the Company is allowed to net settle transactions of the same type with a single net amount payable by one party to the other. However, the Company presents its derivative assets and derivative liabilities on a gross basis in other current assets or accrued and other current liabilities on the consolidated balance sheets as of March 31, 2019 and 2018.

[0001032975-19-000027:notes:279]
The fair values of the Company’s derivative instruments were not material as of March 31, 2019 or March 31, 2018 (refer to Note 9 to the consolidated financial statements for more information). The following table presents the amounts of gains and losses on the Company's derivative instruments designated as hedging instruments for fiscal years 2019, 2018 and 2017 and their locations on its consolidated statements of operations and consolidated statements of comprehensive income (in thousands):

[0001032975-19-000027:notes:280]
|  | Amount ofGain (Loss) Deferred asa Component ofAccumulated OtherComprehensive Loss |  | Amount of Loss (Gain)Reclassified fromAccumulated OtherComprehensive Lossto Costs of Goods Sold |
|  | 2019 |  | 2018 |  | 2017 |  | 2019 |  | 2018 |  | 2017 |
| Designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash flow hedges | $ | 1,781 |  |  | $ | (8,499 | ) |  | $ | 2,928 |  |  | $ | 1,810 |  |  | 5,808 |  |  | $ | (1,670 | ) |

[0001032975-19-000027:notes:281]
Upon adoption of ASU 2017-12, the Company has started presenting the earnings impact from forward points in the same line item that is used to present the earnings impact of the hedged item, i.e. cost of goods sold, for hedging forecasted inventory purchases and such amount is not material for all periods presented.

[0001032975-19-000027:notes:282]
Cash Flow Hedges:  The Company enters into​ cash flow hedge​ contracts to ​protect​ against exchange rate exposure ​of ​forecasted inventory purchases. These hedging contracts mature within four months. Gains and losses in the fair value of the effective portion of the hedges are deferred as a component of accumulated other comprehensive loss until the hedged inventory purchases are sold, at which time the gains or losses are reclassified to cost of goods sold. Cash flows from such hedges are classified as operating activities in the consolidated statements of cash flows. Hedging relationships are discontinued when hedging contract is no longer eligible for hedge accounting, or is sold, terminated or exercised, or when the Company removes hedge designation for the contract. Gains and losses in the fair value of the effective portion of the discontinued hedges continue to be reported in accumulated other comprehensive loss until the hedged inventory purchases are sold, unless it is probable that the forecasted inventory purchases will not occur by the end of the originally specified time period or within an additional two-month period of time thereafter. As of March 31, 2019, the notional amounts of currency forward contracts outstanding related to forecasted inventory purchases was $41.4 million. As of March 31, 2018, there were no currency forward contracts outstanding related to forecasted inventory purchases. The Company estimates that $0.4 million of net gain related to its cash flow hedges included in accumulated other comprehensive loss as of March 31, 2019 will be reclassified into earnings within the next twelve months.

[0001032975-19-000027:notes:283]
Other Derivatives: The Company also enters into currency forward and swap contracts to reduce the short-term effects of currency fluctuations on certain receivables or payables denominated in currencies other than the functional currencies of its subsidiaries. These forward and swap contracts generally mature within one month. The primary risk managed by using forward and swap contracts is the currency exchange rate risk. The gains or losses on these contracts are recognized in other income (expense), net in the consolidated statements of operations based on the changes in fair value. The notional amounts of these contracts outstanding as of March 31, 2019 and 2018 were $50.4 million and $47.2 million, respectively. Open forward and swap contracts as of March 31, 2019 and 2018 consisted of contracts in Taiwanese Dollars, Australian Dollars, Mexican Pesos, Japanese Yen and Canadian Dollars to be settled at future dates at pre-determined exchange rates.

[0001032975-19-000027:notes:284]
The fair value of all currency forward and swap contracts is determined based on observable market transactions of spot currency rates and forward rates. Cash flows from these contracts are classified as operating activities in the consolidated statements of cash flows.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001032975-19-000027:notes:285]
Goodwill and Other Intangible Assets
The Company performed its annual impairment analysis of goodwill as of December 31, 2018 by performing a qualitative assessment and concluded that it was more likely than not that the fair value of its peripherals reporting unit, exceeded its carrying amount. In assessing the qualitative factors, the Company considered the impact of these key factors: change in industry and competitive environment, growth in market capitalization, and budgeted-to-actual revenue performance for the twelve months ended December 31, 2018. There have been no significant events or circumstances affecting the valuation of goodwill subsequent to the annual impairment test.

[0001032975-19-000027:notes:286]
The following table summarizes the activity in the Company's goodwill balance during fiscal years 2019 and 2018 (in thousands):

[0001032975-19-000027:notes:287]
|  |  | Years Ended March 31, |
|  |  | 2019 |  | 2018 |
| Beginning of the period |  | $ | 275,451 |  |  | $ | 249,741 |  |
| Acquisitions |  | 68,269 |  |  | 25,800 |  |
| Currency exchange rate impact |  | (36 | ) |  | (90 | ) |
| End of the period |  | $ | 343,684 |  |  | $ | 275,451 |  |

[0001032975-19-000027:notes:288]
The Company's acquired intangible assets subject to amortization were as follows (in thousands):

[0001032975-19-000027:notes:289]
|  |  | March 31, |
|  |  | 2019 |  | 2018 |
|  |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |
| Trademarks and trade names |  | $ | 36,370 |  |  | $ | (13,659 | ) |  | $ | 22,711 |  |  | $ | 23,870 |  |  | $ | (9,482 | ) |  | $ | 14,388 |  |
| Developed technology |  | 95,207 |  |  | (62,341 | ) |  | 32,866 |  |  | 77,175 |  |  | (50,755 | ) |  | 26,420 |  |
| Customer contracts/relationships |  | 84,610 |  |  | (21,188 | ) |  | 63,422 |  |  | 59,510 |  |  | (12,771 | ) |  | 46,739 |  |
|  |  | $ | 216,187 |  |  | $ | (97,188 | ) |  | $ | 118,999 |  |  | $ | 160,555 |  |  | $ | (73,008 | ) |  | $ | 87,547 |  |

[0001032975-19-000027:notes:290]
For fiscal years 2019, 2018 and 2017, amortization expense for intangible assets was, $24.2 million, $15.6 million and $9.4 million, respectively. The Company expects that annual amortization expense for fiscal years 2020, 2021, 2022, 2023 and 2024 will be $27.5 million, $23.2 million, $20.0 million, $15.9 million and $13.0 million, respectively, and $19.3 million thereafter.


## us-gaap:DebtDisclosureTextBlock

[0001032975-19-000027:notes:291]
Financing Arrangements
The Company had several uncommitted, unsecured bank lines of credit aggregating $80.6 million as of March 31, 2019. There are no financial covenants under these lines of credit with which the Company must comply. As of March 31, 2019, the Company had outstanding bank guarantees of $34.3 million under these lines of credit. There was no borrowing outstanding under the line of credit as of March 31, 2019 or March 31, 2018.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001032975-19-000027:notes:292]
Commitments and Contingencies
Operating Leases

[0001032975-19-000027:notes:293]
The Company leases facilities under operating leases, certain of which require it to pay property taxes, insurance and maintenance costs. Operating leases for facilities are generally renewable at the Company's option and usually include escalation clauses linked to inflation. Future minimum annual rentals under non-cancelable operating leases at March 31, 2019 are as follows (in thousands):

[0001032975-19-000027:notes:294]
| Years Ending March 31, |  |  |
| 2020 |  | $ | 11,849 |  |
| 2021 |  | 10,002 |  |
| 2022 |  | 7,882 |  |
| 2023 |  | 5,111 |  |
| 2024 |  | 1,130 |  |
| Thereafter |  | 3,646 |  |
|  |  | $ | 39,620 |  |

[0001032975-19-000027:notes:295]
Rent expense for fiscal years 2019, 2018 and 2017 was $12.4 million, $11.2 million and $9.9 million, respectively.

[0001032975-19-000027:notes:296]
In connection with its leased facilities, the Company recognized a liability for asset retirement obligations for 2019 and 2018 representing the present value of estimated remediation costs to be incurred at lease expiration. The liabilities for asset retirement obligations were not material as of March 31, 2019 and 2018.

[0001032975-19-000027:notes:297]
Product Warranties

[0001032975-19-000027:notes:298]
Changes in the Company's warranty liability for fiscal years 2019 and 2018 were as follows (in thousands):

[0001032975-19-000027:notes:299]
|  |  | Years Ended March 31, |
|  |  | 2019 |  | 2018 |
| Beginning of the period |  | $ | 27,573 |  |  | $ | 21,911 |  |
| Assumed from business acquisition |  | 351 |  |  | 1,230 |  |
| Provision |  | 36,927 |  |  | 25,103 |  |
| Settlements |  | (29,874 | ) |  | (21,766 | ) |
| Currency translation |  | (748 | ) |  | 1,095 |  |
| End of the period |  | $ | 34,229 |  |  | $ | 27,573 |  |

[0001032975-19-000027:notes:300]
Indemnifications

[0001032975-19-000027:notes:301]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys' fees. As of March 31, 2019, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

[0001032975-19-000027:notes:302]
The Company also indemnifies its current and former directors and certain of its current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. The Company is unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not limited, the obligations are conditional in nature and the facts and circumstances involved in any situation that might arise are variable.

[0001032975-19-000027:notes:303]
Legal Proceedings

[0001032975-19-000027:notes:304]
From time to time the Company is involved in claims and legal proceedings which arise in the ordinary course of its business. The Company is currently subject to several such claims and a small number of legal proceedings. The Company believes that these matters lack merit and intends to vigorously defend against them. Based on currently available information, the Company does not believe that resolution of pending matters will have a material

[0001032975-19-000027:notes:305]
adverse effect on its financial position, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company's defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company's business, financial position, cash flows or results of operations in a particular period. Any claims or proceedings against the Company, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain a necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company's business.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001032975-19-000027:notes:306]
Shareholders' Equity
Share Capital

[0001032975-19-000027:notes:307]
The Company's nominal share capital is CHF 43.3 million, consisting of 173,106,620 shares with a par value of CHF 0.25 each, all of which were issued and 7,243,733 of which were held in treasury shares as of March 31, 2019.

[0001032975-19-000027:notes:308]
The Company's has reserved conditional capital of 25,000,000 shares for potential issuance on the exercise of rights granted under the Company's employee equity incentive plans and additional conditional capital for financing purposes, representing the issuance of up to 25,000,000 shares to cover any conversion rights under a future convertible bond issuance. This conditional capital was created in order to provide financing flexibility for future expansion, investments or acquisitions. During the 2018 Annual General Meeting, the shareholders of the Company authorized the Board of Directors to issue up to an additional 34,621,324 shares of the Company until September 5, 2020.

[0001032975-19-000027:notes:309]
Dividends

[0001032975-19-000027:notes:310]
Pursuant to Swiss corporate law, the payment of dividends is limited to certain amounts of unappropriated retained earnings (CHF 940.9 million or $945.2 million based on the exchange rate at March 31, 2019) and is subject to shareholder approval.

[0001032975-19-000027:notes:311]
In May 2019, the Board of Directors recommended that the Company pay CHF 121.8 million ($122.4 million based on the exchange rate on March 31, 2019) in cash dividends for fiscal year 2019. In September 2018, the Company declared and paid cash dividends of CHF 0.67 (USD equivalent of $0.69) per common share, totaling $114.0 million on the Company's outstanding common stock. In September 2017, the Company declared and paid cash dividends of CHF 0.61 (USD equivalent of $0.63) per common share, totaling approximately $104.2 million in U.S. Dollars, on the Company’s outstanding common stock. In September 2016, the Company declared and paid cash dividends of CHF 0.56 (USD equivalent of $0.57) per common share, totaling approximately $93.1 million in U.S. Dollars, on the Company’s outstanding common stock.

[0001032975-19-000027:notes:312]
Any future dividends will be subject to the approval of the Company's shareholders.

[0001032975-19-000027:notes:313]
Legal Reserves

[0001032975-19-000027:notes:314]
Under Swiss corporate law, a minimum of 5% of the Company's annual net income must be retained in a legal reserve until this legal reserve equals 20% of the Company's issued and outstanding aggregate par value per share capital. These legal reserves represent an appropriation of retained earnings that are not available for distribution and totaled $9.6 million at March 31, 2019 (based on the exchange rate at March 31, 2019).

[0001032975-19-000027:notes:315]
Share Repurchases

[0001032975-19-000027:notes:316]
In March 2014, the Company's Board of Directors approved the 2014 share buyback program, which authorizes the Company to use up to $250.0 million to purchase its own shares. This share buyback program expired in April 2017. In March 2017, the Company's Board of Directors approved the 2017 share buyback program, which authorizes the Company to use up to $250.0 million to purchase its own shares following the expiration date of 2014 buyback program. The Company's share buyback program is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Purchases may be started or stopped at any time without prior notice depending on market conditions and other factors. As of March 31, 2019, $187.4 million is still available for repurchase under the 2017 buyback program.

[0001032975-19-000027:notes:317]
A summary of the approved and active share buyback program is shown in the following table (in thousands, excluding transaction costs):

[0001032975-19-000027:notes:318]
|  |  | Approved |  | Repurchased |
| Share Buyback Program |  | Shares (1) |  | Amounts |  | Shares |  | Amounts |
| March 2014 |  | 17,311 |  |  | $ | 250,000 |  |  | 9,113 |  |  | $ | 155,983 |  |
| March 2017 |  | 17,311 |  |  | $ | 250,000 |  |  | 1,651 |  |  | $ | 62,567 |  |

[0001032975-19-000027:notes:319]
(1) The approval of each of the share buyback programs by the Swiss Takeover Board limits the number of shares that the Company may repurchase to no more than 10% of its authorized share capital and voting rights.

[0001032975-19-000027:notes:320]
Accumulated Other Comprehensive Loss

[0001032975-19-000027:notes:321]
The components of accumulated other comprehensive loss were as follows (in thousands):

[0001032975-19-000027:notes:322]
|  |  | Accumulated Other Comprehensive Income (Loss) |
|  |  | CumulativeTranslationAdjustment (1) |  | DefinedBenefitPlans(1) |  | DeferredHedgingGains (Losses) |  | Total |
| March 31, 2018 |  | $ | (83,848 | ) |  | $ | (6,398 | ) |  | $ | (3,209 | ) |  | $ | (93,455 | ) |
| Other comprehensive income (loss) |  | (8,300 | ) |  | (7,534 | ) |  | 3,591 |  |  | (12,243 | ) |
| March 31, 2019 |  | $ | (92,148 | ) |  | $ | (13,932 | ) |  | $ | 382 |  |  | $ | (105,698 | ) |

[0001032975-19-000027:notes:323]
_______________________________________

[0001032975-19-000027:notes:324]
(1) Tax effect was not significant as of March 31, 2019 or 2018. 
There was a $0.5 million reclassification of currency translation loss included in other income (expense), net for the year ended March 31, 2019 due to the liquidation of one of the Company's subsidiaries.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001032975-19-000027:notes:325]
Segment Information
The Company operates in a single operating segment that encompasses the design, manufacturing and marketing of peripherals for PCs, tablets and other digital platforms. Operating performance measures are provided directly to the Company's CEO, who is considered to be the Company’s Chief Operating Decision Maker. The CEO periodically reviews information such as sales and adjusted operating income (loss) to make business decisions. These operating performance measures do not include restructuring charges (credits), net, share-based compensation expense, amortization of intangible assets, charges from the purchase accounting effect on inventory, acquisition-related costs, or change in fair value of contingent consideration from business acquisition.

[0001032975-19-000027:notes:326]
Sales by product categories were as follows (in thousands):

[0001032975-19-000027:notes:327]
|  |  | Years Ended March 31, |
|  |  | 2019 |  | 2018 |  | 2017 |
| Pointing Devices |  | $ | 536,890 |  |  | $ | 516,637 |  |  | $ | 501,562 |  |
| Keyboards & Combos |  | 536,619 |  |  | 498,472 |  |  | 480,312 |  |
| PC Webcams |  | 121,282 |  |  | 112,147 |  |  | 107,087 |  |
| Tablet & Other Accessories |  | 128,315 |  |  | 107,942 |  |  | 76,879 |  |
| Video Collaboration |  | 259,521 |  |  | 182,717 |  |  | 127,009 |  |
| Mobile Speakers |  | 230,378 |  |  | 314,817 |  |  | 301,021 |  |
| Audio & Wearables |  | 277,429 |  |  | 252,330 |  |  | 246,390 |  |
| Gaming |  | 648,130 |  |  | 491,995 |  |  | 314,362 |  |
| Smart Home |  | 49,344 |  |  | 89,373 |  |  | 65,510 |  |
| Other (1) |  | 414 |  |  | 433 |  |  | 1,295 |  |
| Total Sales |  | $ | 2,788,322 |  |  | $ | 2,566,863 |  |  | $ | 2,221,427 |  |

[0001032975-19-000027:notes:328]
| (1) | Other category includes products that the Company currently intends to phase out, or have already phased out, because they are no longer strategic to the Company's business. |

[0001032975-19-000027:notes:329]
Sales by geographic region for fiscal years 2019, 2018 and 2017 (based on the customers' locations) were as follows (in thousands):

[0001032975-19-000027:notes:330]
|  |  | Years Ended March 31, |
|  |  | 2019 |  | 2018 |  | 2017 |
| Americas |  | $ | 1,190,216 |  |  | $ | 1,118,324 |  |  | $ | 963,674 |  |
| EMEA |  | 861,731 |  |  | 820,347 |  |  | 746,898 |  |
| Asia Pacific |  | 736,375 |  |  | 628,192 |  |  | 510,855 |  |
| Total Sales |  | $ | 2,788,322 |  |  | $ | 2,566,863 |  |  | $ | 2,221,427 |  |

[0001032975-19-000027:notes:331]
Revenues from sales to customers in the United States represented 36%, 37%and 37% of sales in fiscal years 2019, 2018 and 2017, respectively. Revenues from sales to customers in Germany represented 18%, 16% and 17% of sales in fiscal years 2019, 2018 and 2017, respectively. Revenues from sales to customers in China represented 10% of sales in fiscal year 2019. No other single country represented more than 10% of sales during these periods. Revenues from sales to customers in Switzerland, the Company's home domicile, represented 3%, 2% and 2% of sales in fiscal years 2019, 2018 and 2017, respectively.

[0001032975-19-000027:notes:332]
Property, plant and equipment, net by geographic region were as follows (in thousands):

[0001032975-19-000027:notes:333]
|  |  | March 31, |
|  |  | 2019 |  | 2018 |
| Americas |  | $ | 29,813 |  |  | $ | 35,404 |  |
| EMEA |  | 4,537 |  |  | 4,690 |  |
| Asia Pacific |  | 44,202 |  |  | 46,210 |  |
| Total Property, plant and equipment, net |  | $ | 78,552 |  |  | $ | 86,304 |  |

[0001032975-19-000027:notes:334]
Property, plant and equipment, net in the United States and China were $29.8 million and $36.4 million, respectively, as of March 31, 2019, and $35.3 million and $37.9 million, respectively, as of March 31, 2018. No other countries represented more than 10% of the Company's total consolidated property, plant and equipment, net at March 31, 2019 or 2018. Property, plant and equipment, net in Switzerland, the Company's home domicile, were  $1.7 million and $1.9 million at March 31, 2019 and 2018, respectively.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001032975-19-000027:notes:335]
Restructuring
During the first quarter of fiscal year 2019, the Company implemented a restructuring plan to streamline and realign the Company's overall organizational structure and reallocate resources to support long-term growth opportunities. In July 2018, the Company's Board of Directors approved additional costs under this restructuring plan, totaling pre-tax charges of approximately $10.0 million to $15.0 million, of which $11.3 million was recognized during fiscal year 2019. The total charges consisted of cash severance and other personnel costs and are presented as restructuring charges (credits), net in the Consolidated Statements of Operations. The Company expects to have substantially completed this restructuring within the next three months.

[0001032975-19-000027:notes:336]
The restructuring-related activities for the years ended March 31, 2018 and 2017 include activities from the restructuring plan implemented in fiscal year 2016.

[0001032975-19-000027:notes:337]
The following table summarizes restructuring-related activities during fiscal year 2019, 2018 and 2017 (in thousands):

[0001032975-19-000027:notes:338]
|  |  | Restructuring - Continuing Operations |
|  |  | TerminationBenefits |  | Lease ExitCosts |  | Total |
| Accrual balance at March 31, 2016 |  | $ | 5,907 |  |  | $ | 125 |  |  | $ | 6,032 |  |
| Charges, net |  | 23 |  |  | — |  |  | 23 |  |
| Cash payments |  | (5,195 | ) |  | (125 | ) |  | (5,320 | ) |
| Accrual balance at March 31, 2017 |  | 735 |  |  | — |  |  | 735 |  |
| Credits, net |  | (116 | ) |  | — |  |  | (116 | ) |
| Cash payments |  | (619 | ) |  | — |  |  | (619 | ) |
| Accrual balance at March 31, 2018 |  | — |  |  | — |  |  | — |  |
| Charges, net |  | 11,302 |  |  | — |  |  | 11,302 |  |
| Cash payments |  | (6,913 | ) |  | — |  |  | (6,913 | ) |
| Accrual balance at March 31, 2019 |  | $ | 4,389 |  |  | $ | — |  |  | $ | 4,389 |  |

[0001032975-19-000027:notes:339]
The accrual balances are included in accrued and other current liabilities on the Company’s consolidated balance sheets.


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001032975-19-000027:notes:340]
VALUATION AND QUALIFYING ACCOUNTS

[0001032975-19-000027:notes:341]
For the Fiscal Years Ended March 31, 2019, 2018 and 2017 (in thousands)

[0001032975-19-000027:notes:342]
The Company's Schedule II includes valuation and qualifying accounts related to allowances for doubtful accounts, sales returns, cooperative marketing arrangements, customer incentive programs, and pricing programs, for direct customers and tax valuation allowances. The Company also has sales incentive programs for indirect customers with whom it does not have a direct sales and receivable relationship. These programs are recorded as accrued liabilities and are not considered valuation or qualifying accounts.

[0001032975-19-000027:notes:343]
|  |  | Balance atBeginning ofYear |  | Charged(Credited) to Statement ofOperations (1)(2)(3) |  | Claims andAdjustmentsApplied AgainstAllowances (1) |  | Balance atEnd ofYear |
| Allowance for doubtful accounts: |  |  |  |  |  |  |  |  |  |  |  |  |
| 2019 |  | $ | 122 |  |  | $ | 840 |  |  | $ | (878 | ) |  | $ | 84 |  |
| 2018 |  | $ | 607 |  |  | $ | (404 | ) |  | $ | (81 | ) |  | $ | 122 |  |
| 2017 |  | $ | 667 |  |  | $ | 47 |  |  | $ | (107 | ) |  | $ | 607 |  |
| Allowance for sales returns: |  |  |  |  |  |  |  |  |  |  |  |  |
| 2019 (2) |  | $ | 25,515 |  |  | $ | 94,381 |  |  | $ | (113,410 | ) |  | $ | 6,486 |  |
| 2018 |  | $ | 18,800 |  |  | $ | 111,969 |  |  | $ | (105,254 | ) |  | $ | 25,515 |  |
| 2017 |  | $ | 18,526 |  |  | $ | 78,242 |  |  | $ | (77,968 | ) |  | $ | 18,800 |  |
| Allowance for cooperative marketing arrangements: |  |  |  |  |  |  |  |  |  |  |  |  |
| 2019 (2) |  | $ | 30,389 |  |  | $ | 176,323 |  |  | $ | (171,632 | ) |  | $ | 35,080 |  |
| 2018 |  | $ | 28,022 |  |  | $ | 160,664 |  |  | $ | (158,297 | ) |  | $ | 30,389 |  |
| 2017 |  | $ | 28,157 |  |  | $ | 144,656 |  |  | $ | (144,791 | ) |  | $ | 28,022 |  |
| Allowance for customer incentive programs: |  |  |  |  |  |  |  |  |  |  |  |  |
| 2019 (2) |  | $ | 70,592 |  |  | $ | 237,580 |  |  | $ | (248,136 | ) |  | $ | 60,036 |  |
| 2018 |  | $ | 60,857 |  |  | $ | 230,838 |  |  | $ | (221,103 | ) |  | $ | 70,592 |  |
| 2017 |  | $ | 60,872 |  |  | $ | 196,363 |  |  | $ | (196,378 | ) |  | $ | 60,857 |  |
| Allowance for pricing programs: |  |  |  |  |  |  |  |  |  |  |  |  |
| 2019 (2) |  | $ | 141,369 |  |  | $ | 444,540 |  |  | $ | (497,556 | ) |  | $ | 88,353 |  |
| 2018 |  | $ | 102,289 |  |  | $ | 445,048 |  |  | $ | (405,968 | ) |  | $ | 141,369 |  |
| 2017 |  | $ | 81,553 |  |  | $ | 322,118 |  |  | $ | (301,382 | ) |  | $ | 102,289 |  |
| Tax valuation allowance: |  |  |  |  |  |  |  |  |  |  |  |  |
| 2019 |  | $ | 25,148 |  |  | $ | 3,244 |  |  | $ | (17 | ) |  | $ | 28,375 |  |
| 2018 (3) |  | $ | 6,626 |  |  | $ | 18,496 |  |  | $ | 26 |  |  | $ | 25,148 |  |
| 2017 |  | $ | 5,338 |  |  | $ | 1,299 |  |  | $ | (11 | ) |  | $ | 6,626 |  |

[0001032975-19-000027:notes:344]
(1) The amounts for fiscal years 2019 and 2018 both include immaterial impacts from the business acquisitions during the year. Refer to Note 3 to the consolidated financial statements.

[0001032975-19-000027:notes:345]
(2) The amounts charged to the Statement of Operations for allowances for various Customer Programs and sales returns in fiscal year 2019 include the impact of $105.8 million reduction as a result of the adoption of ASU 2014-09 effective April 1, 2018, of which $20.0 million was for allowance for sales returns, $3.2 million was for the allowance for cooperative marketing arrangements, $18.7 million for allowance for customer incentive programs and $63.8 million for allowance for pricing programs. Refer to Note 2 to the consolidated financial statements.

[0001032975-19-000027:notes:346]
(3) The amount charged to the Statement of Operations for the tax valuation allowance in fiscal year 2018 primarily includes the impact of $18.0 million from the adoption of ASU 2016-09 effective April 1, 2017.
