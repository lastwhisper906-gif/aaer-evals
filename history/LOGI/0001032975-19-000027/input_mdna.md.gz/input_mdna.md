# LOGI MD&A — 0001032975-19-000027


## mdna

[0001032975-19-000027:mdna:1]
ITEM 7.    MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001032975-19-000027:mdna:2]
Overview of Our Company

[0001032975-19-000027:mdna:3]
Logitech is a world leader in designing, manufacturing and marketing products that help connect people to digital and cloud experiences. More than 35 years ago, Logitech created products to improve experiences around the personal PC platform, and today it is a multi-brand, multi-category company designing products that enable better experiences consuming, sharing and creating any digital content such as music, gaming, video and computing, whether it is on a computer, mobile device or in the cloud. Logitech's brands include Logitech, Jaybird, Ultimate Ears, Logitech G, ASTRO Gaming and Blue Microphones.

[0001032975-19-000027:mdna:4]
Our products participate in five large market opportunities: Creativity & Productivity, Gaming, Video Collaboration, Music and Smart Home. We sell our products to a broad network of domestic and international customers, including direct sales to retailers and e-tailers, and indirect sales through distributors. Our worldwide channel network includes consumer electronics distributors, retailers, mass merchandisers, specialty stores, computer and telecommunications stores, value-added resellers and online merchants.

[0001032975-19-000027:mdna:5]
From time to time, we may seek to partner with or acquire when appropriate, companies that have products, personnel, and technologies that complement our strategic direction. We continually review our product offerings and our strategic direction in light of our profitability targets, competitive conditions, changing consumer trends and the evolving nature of the interface between the consumer and the digital world.

[0001032975-19-000027:mdna:6]
On August 21, 2018, we acquired all equity interests in Blue Microphones Holding Corporation (Blue Microphones) for a total consideration of $134.8 million in cash (the Blue Microphones Acquisition), which included a working capital adjustment and repayment of debt on behalf of Blue Microphones. Blue Microphones is a leading audio manufacturer that designs and produces microphones, headphones, recording tools, and accessories for audio professionals, musicians and consumers. The Blue Microphones Acquisition supplements our product portfolio.

[0001032975-19-000027:mdna:7]
On August 11, 2017, we acquired certain assets and liabilities constituting the ASTRO Gaming business (ASTRO) from AG Acquisition Corporation for a purchase price of $85.0 million in cash (the ASTRO Acquisition). ASTRO is a leading console gaming accessory brand with a history of producing award-winning headsets for professional gamers and enthusiasts. ASTRO provides a strong growth platform in the console gaming accessories market.

[0001032975-19-000027:mdna:8]
Summary of Financial Results

[0001032975-19-000027:mdna:9]
Our total sales for fiscal year 2019 increased 9% in comparison to fiscal year 2018. The growth was broad-based across our regions and across most of our product categories. The results of operations for Blue Microphones have been included in our consolidated statements of operations from the acquisition date. For fiscal year 2019, Blue Microphones contributed approximately 2 percentage points of the sales growth rate.

[0001032975-19-000027:mdna:10]
Sales for fiscal year 2019 increased 6%, 5% and 17% in the Americas, EMEA and Asia Pacific, respectively.

[0001032975-19-000027:mdna:11]
Gross margin increased by 180 basis points to 37.2% during fiscal year 2019, compared to fiscal year 2018. The increase in gross margin was primarily driven by favorable product mix and cost reductions. In addition, extra costs from the transition of the distribution center in North America in the third quarter of fiscal year 2018 negatively affected the gross margin in fiscal year 2018.

[0001032975-19-000027:mdna:12]
Operating expenses for fiscal year 2019 were $773.8 million, or 27.8% of sales, compared to $679.5 million, or 26.5% of sales, for fiscal year 2018. The increase in operating expenses was primarily driven by: $47.8 million higher personnel-related cost due to restructuring charges in the current period, increased performance-based variable compensation and additional headcount from business acquisitions; $32.6 million higher third-party costs, primarily advertising and marketing expenses to support our new product introductions and new market

[0001032975-19-000027:mdna:13]
opportunities; $5.0 million higher amortization of intangible assets from the business acquisitions; and a $4.9 million non-recurring credit for change in fair value of contingent consideration from an acquisition recorded in fiscal year 2018.

[0001032975-19-000027:mdna:14]
Net income for fiscal year 2019 was $257.6 million, compared to $208.5 million for fiscal year 2018.

[0001032975-19-000027:mdna:15]
Trends in Our Business

[0001032975-19-000027:mdna:16]
Our strategy focuses on five large multi-category market opportunities including Creativity & Productivity, Gaming, Video Collaboration, Music and Smart Home. We see opportunities to deliver growth with products in all these markets. The following discussion represents key trends specific to our market opportunities.

[0001032975-19-000027:mdna:17]
Trends Specific to Our Five Market Opportunities

[0001032975-19-000027:mdna:18]
Creativity & Productivity:  Although new PC shipments continue to be weak, the installed base of PC users remains large. We believe that innovative PC peripherals, such as our mice and keyboards, can renew the PC usage experience, thus providing growth opportunities. Increasing adoption of various cloud-based applications has led to multiple new consumer use cases, which we are addressing with our innovative product portfolio. The increasing popularity of streaming and broadcasting provides additional growth opportunities for our Webcam products. Smaller mobile computing devices, such as tablets, have created new markets and usage models for peripherals and accessories. We offer a number of products to enhance the use of mobile devices, including a combo backlit keyboard case for the iPad Pro and keyboard folios for the iPad and iPad mini. In fiscal year 2019, we have seen a recovery of the iPad tablet market, and our Tablet & Other Accessories category has benefited from the recovery along with our innovative products.

[0001032975-19-000027:mdna:19]
Gaming:  The PC gaming and console gaming platforms continue to show strong growth as online gaming, multi-platform experiences, and esports gain greater popularity and gaming content becomes increasingly more demanding. We believe Logitech is well positioned to benefit from the gaming market growth. With ASTRO Gaming, we are also strengthening our portfolio in adjacent categories, such as the console controller market.

[0001032975-19-000027:mdna:20]
Video Collaboration:  The near and long-term structural growth opportunities in the video collaboration market are significant and are already attracting more competition. Video meetings are on the rise, and companies increasingly want lower-cost, cloud-based solutions. We are continuing our efforts to create and sell innovative products to accommodate the increasing demand from medium and large-sized meeting rooms to small-sized rooms such as huddle rooms. We will continue to invest in select business-specific products, targeted product marketing and sales channel development.

[0001032975-19-000027:mdna:21]
Music:  The music market grew during fiscal year 2019, driven by growing consumption of music through mobile devices such as smartphones and tablets. The integration of personal voice assistants has become increasingly competitive in the speaker categories, but the market for third-party, voice-enabled speakers has not yet gained traction. Moreover, the market for mobile speakers appears to be maturing, which led to a decline in Ultimate Ears sales in fiscal year 2019. In fiscal year 2019, the headphone industry continued to flourish with strong revenue growth. The largest growth came in True Wireless headphones where the market tripled year over year and added substantial increases to average selling price. Continued growth in the headphone category is expected for the next several years as consumers increasingly adopt wireless headphones over wired headphones. With Blue Microphones, we are strengthening our portfolio in adjacent categories, such as the microphones market.

[0001032975-19-000027:mdna:22]
Smart Home:  Our remote business declined substantially in fiscal year 2019 as the attachment to the voice assistants of Harmony Hub-based remote controls was not a sustainable trend. In general, the space is under pressure as the way people consume content is changing. We will continue to explore other innovative experiences for the Smart Home category.

[0001032975-19-000027:mdna:23]
Business Seasonality, Product Introductions and Business Acquisitions

[0001032975-19-000027:mdna:24]
We have historically experienced higher sales in our third fiscal quarter ending December 31, compared to other fiscal quarters in our fiscal year, primarily due to the increased consumer demand for our products during the year-end holiday buying season and year-end spending by enterprises. Additionally, new product introductions and business acquisitions can significantly impact sales, product costs and operating expenses. Product introductions can also impact our sales to distribution channels as these channels are filled with new product inventory following a product introduction, and often channel inventory of an earlier model product declines as the next related major product launch approaches. Sales can also be affected when consumers and distributors anticipate a product introduction or changes in business circumstances. However, neither historical seasonal patterns nor historical

[0001032975-19-000027:mdna:25]
patterns of product introductions should be considered reliable indicators of our future pattern of product introductions, future sales or financial performance.

[0001032975-19-000027:mdna:26]
Critical Accounting Estimates

[0001032975-19-000027:mdna:27]
The preparation of financial statements and related disclosures in conformity with U.S. GAAP requires us to make judgments, estimates, and assumptions that affect reported amounts of assets, liabilities, sales and expenses, and the disclosure of contingent assets and liabilities.

[0001032975-19-000027:mdna:28]
We consider an accounting estimate critical if it: (i) requires management to make judgments and estimates about matters that are inherently uncertain; and (ii) is important to an understanding of our financial condition and operating results.

[0001032975-19-000027:mdna:29]
We base our estimates on historical experience and on various other assumptions we believe to be reasonable under the circumstances. Although these estimates are based on management's best knowledge of current events and actions that may impact us in the future, actual results could differ from those estimates. Management has discussed the development, selection and disclosure of these critical accounting estimates with the Audit Committee of the Board of Directors.

[0001032975-19-000027:mdna:30]
We believe the following accounting estimates are most critical to our business operations and to an understanding of our financial condition and results of operations and reflect the more significant judgments and estimates used in the preparation of our consolidated financial statements.

[0001032975-19-000027:mdna:31]
Accruals for Customer Programs and Product Returns

[0001032975-19-000027:mdna:32]
We record accruals for cooperative marketing, customer incentive, pricing programs (Customer Programs) and product returns. The estimated cost of these programs is usually recorded as a reduction of revenue. Significant management judgments and estimates must be used to determine the cost of these programs in any accounting period. Certain Customer Programs require management to estimate the percentage of those programs which will not be claimed or will not be earned by customers based on historical experience and on the specific terms and conditions of particular programs. The percentage of these customer programs that will not be claimed or earned is commonly referred to as "breakage". If we receive a separately identifiable benefit from a customer and can reasonably estimate the fair value of that benefit, the cost of the Customer Programs is recognized in operating expenses.

[0001032975-19-000027:mdna:33]
Cooperative Marketing Arrangements.    We enter into customer marketing programs with many of our customers, and with certain indirect partners, allowing customers to receive a credit equal to a set percentage of their purchases of our products, or a fixed dollar credit for various marketing programs. The objective of these arrangements is to encourage advertising and promotional events to increase sales of our products.

[0001032975-19-000027:mdna:34]
Customer Incentive Programs.    Customer incentive programs include performance-based incentives and consumer rebates. We offer performance-based incentives to our customers and indirect partners based on pre-determined performance criteria. Consumer rebates are offered from time to time at our discretion for the primary benefit of end-users.

[0001032975-19-000027:mdna:35]
Cooperative marketing arrangements and customer incentive programs are considered variable consideration, which we estimate and record as a reduction to revenue at the time of sale based on negotiated terms, historical experiences, forecasted incentives, the anticipated volume of future purchases, and inventory levels in the channel.

[0001032975-19-000027:mdna:36]
Pricing Programs.    We have agreements with certain customers that contain terms allowing price protection credits to be issued in the event of a subsequent price reduction. At our discretion, we also offer special pricing discounts to certain customers. Special pricing discounts are usually offered only for limited time periods or for sales of selected products to specific indirect partners. Our decision to make price reductions is influenced by product life cycle stage, market acceptance of products, the competitive environment, new product introductions and other factors. Accruals for estimated expected future pricing actions are recognized at the time of sale based on analysis of historical pricing actions by customer and by product, inventories owned by and located at distributors and retailers, current customer demand, current operating conditions, and other relevant customer and product information, such as stage of product life-cycle.

[0001032975-19-000027:mdna:37]
Product Returns.    We grant limited rights to return products. Return rights vary by customer and range from just the right to return the defective product to stock rotation rights limited to a percentage of sales approved by management. Estimates of expected future product returns are recognized at the time of sale based on analyses of

[0001032975-19-000027:mdna:38]
historical return trends by the customer and by product, inventories owned by and located at customers, current customer demand, current operating conditions, and other relevant customer and product information. Upon recognition, we reduce sales and cost of goods sold for the estimated return. Return trends are influenced by product life cycle status, new product introductions, market acceptance of products, sales levels, product sell-through, the type of customer, seasonality, product quality issues, competitive pressures, operational policies and procedures, and other factors. Return rates can fluctuate over time but are sufficiently predictable to allow us to estimate expected future product returns.

[0001032975-19-000027:mdna:39]
We apply a breakage rate to reduce our accruals of Customer Programs based on the estimated percentage of these customer programs that will not be claimed or earned. The breakage rate is applied at the time of sale. Significant management judgments and estimates are used to determine the breakage of the programs in any accounting period.

[0001032975-19-000027:mdna:40]
We regularly evaluate the adequacy of our accruals for Customer Programs and product returns. Future market conditions and product transitions may require us to take action to increase such programs. In addition, when the variables used to estimate these costs change, or if actual costs differ significantly from the estimates, we would be required to record incremental increases or reductions to revenue or operating expenses.

[0001032975-19-000027:mdna:41]
Inventory Valuation

[0001032975-19-000027:mdna:42]
We must order components for our products and build inventory in advance of customer orders. Further, our industry is characterized by rapid technological change, short-term customer commitments and rapid changes in demand.

[0001032975-19-000027:mdna:43]
We record inventories at the lower of cost and net realizable value and record write-downs of inventories that are obsolete or in excess of anticipated demand or net realizable value. A review of inventory is performed each fiscal quarter that considers factors including the marketability and product lifecycle stage, product development plans, component cost trends, historical sales and demand forecasts which consider the assumptions about future demand and market conditions. Inventory on hand which is not expected to be sold or utilized is considered excess, and we recognize the write-down in the cost of goods sold at the time of such determination. The write-down is determined by the excess of cost over net realizable value. Net realizable value is the estimated selling price in the ordinary course of business, less reasonably predictable costs of completion, disposal and transportation. At the time of loss recognition, new cost basis per unit and the lower-cost basis for that inventory is established and subsequent changes in facts and circumstances would not result in an increase in the cost basis. If there is an abrupt and substantial decline in demand for Logitech's products or an unanticipated change in technological or customer requirements, we may be required to record additional write-downs that could adversely affect gross margins in the period when the write-downs are recorded.

[0001032975-19-000027:mdna:44]
Share-Based Compensation Expense

[0001032975-19-000027:mdna:45]
The grant date fair value for stock options and stock purchase rights is estimated using the Black-Scholes-Merton option-pricing valuation model. The grant date fair value of restricted stock units (RSUs) that vest upon meeting certain market conditions is estimated using the Monte-Carlo simulation method. The grant date fair value of time-based RSUs and RSUs with performance conditions is calculated based on the closing market price on the date of grant, adjusted by estimated dividends yield prior to vesting.

[0001032975-19-000027:mdna:46]
Our estimates of share-based compensation expense require a number of complex and subjective assumptions including our stock price volatility, the probability of achievement of the set performance conditions, dividend yield, related tax effects and the selection of an appropriate fair value model. We estimate expected share price volatility based on historical volatility using daily prices over the term of options, RSUs or purchase offerings, as we consider historical share price volatility as most representative of future volatility. The dividend yield assumption is based on our history and expectations of future dividend payouts.

[0001032975-19-000027:mdna:47]
The assumptions used in calculating the fair value of share-based compensation expense and related tax effects represent our best estimates, but these estimates involve inherent uncertainties and the application of management judgments. As a result, if factors change and we use different assumptions, or if we decide to use a different valuation model, our share-based compensation expense could be materially different in the future from what we have recorded in the current period, which could materially affect our results of operations.

[0001032975-19-000027:mdna:48]
Accounting for Income Taxes

[0001032975-19-000027:mdna:49]
We operate in multiple jurisdictions and our profits are taxed pursuant to the tax laws of these jurisdictions. Our effective income tax rate may be affected by the changes in or interpretations of tax laws and tax agreements in any given jurisdiction, utilization of net operating loss and tax credit carryforwards, changes in geographical mix of income and expense, and changes in our assessment of matters such as the ability to realize deferred tax assets. As a result of these considerations, we must estimate income taxes in each of the jurisdictions in which we operate. This process involves estimating current tax exposure together with assessing temporary differences resulting from the different treatment of items for tax and accounting purposes. These differences result in deferred tax assets and liabilities, which are included in the consolidated balance sheet.

[0001032975-19-000027:mdna:50]
We assess the likelihood that our deferred tax assets will be recovered from future taxable income, considering all available evidence such as historical levels of income, expectations and risks associated with estimates of future taxable income and ongoing prudent and feasible tax strategies. When we determine that it is not more likely than not that we will realize all or part of our deferred tax assets, an adjustment is charged to earnings in the period when such determination is made. Likewise, if we later determine that it is more likely than not that all or a part of our deferred tax assets would be realized, the previously provided valuation allowance would be reversed.

[0001032975-19-000027:mdna:51]
We make certain estimates and judgments about the application of tax laws, the expected resolution of uncertain tax positions and other matters surrounding the recognition and measurement of uncertain tax benefits. In the event that uncertain tax positions are resolved for amounts different than our estimates, or the related statutes of limitations expire without the assessment of additional income taxes, we will be required to adjust the amounts of the related assets and liabilities in the period in which such events occur. Such adjustments may have a material impact on our income tax provision and our results of operations.

[0001032975-19-000027:mdna:52]
Goodwill Impairment Analysis

[0001032975-19-000027:mdna:53]
We conduct a goodwill impairment analysis annually at December 31 or more frequently if indicators of impairment exist or if a decision is made to sell or exit a business. Refer to Note 11 to the consolidated financial statements included in this Annual Report on Form 10-K for the disclosures. Significant judgments are involved in determining if an indicator of impairment has occurred. Such indicators may include deterioration in general economic conditions, negative developments in equity and credit markets, adverse changes in the markets in which an entity operates, increases in input costs that have a negative effect on earnings and cash flows, a trend of negative or declining cash flows, a decline in actual or planned revenue or earnings compared with actual and projected results of relevant prior periods, or other relevant entity-specific events such as changes in management, key personnel, strategy or customers, contemplation of bankruptcy, or litigation. The fair value that could be realized in an actual transaction may differ from that used to evaluate the impairment of goodwill.

[0001032975-19-000027:mdna:54]
In reviewing goodwill for impairment, we have the option to first assess qualitative factors to determine whether the existence of events or circumstances leads to a determination that it is more likely than not (greater than 50%) that the estimated fair value of a reporting unit is less than its carrying amount. For the year ended March 31, 2019, we elected to perform a qualitative assessment and determined that impairment was not more likely than not and no further analysis was required. We also may elect not to perform the qualitative assessment and, instead, proceed directly to the quantitative impairment test. The ultimate outcome of the goodwill impairment review for a reporting unit should be the same whether an entity chooses to perform the qualitative assessment or proceeds directly to the quantitative impairment test. Goodwill is allocated among and evaluated for impairment at the reporting unit level, which is defined as an operating segment or one level below an operating segment. We currently have only one reporting unit.

[0001032975-19-000027:mdna:55]
Product Warranty Accrual

[0001032975-19-000027:mdna:56]
We estimate the cost of product warranties at the time the related revenue is recognized based on historical and projected warranty claim rates, historical and projected costs, and knowledge of specific product failures that are outside of our typical experience. Each fiscal quarter, we reevaluate estimates to assess the adequacy of recorded warranty liabilities. When we experience changes in warranty claim activity or costs associated with fulfilling those claims, the warranty liability is adjusted accordingly. If actual product failure rates or repair costs differ from estimates, revisions to the estimated warranty liabilities would be required and could materially affect our results of operations.

[0001032975-19-000027:mdna:57]
Business Acquisitions

[0001032975-19-000027:mdna:58]
Accounting for business acquisitions requires us to make significant estimates and assumptions, especially at the acquisition date with respect to tangible and intangible assets acquired and liabilities assumed and pre-acquisition contingencies. We use our best estimates and assumptions to accurately assign fair value to the tangible and intangible assets acquired and liabilities assumed at the acquisition date.

[0001032975-19-000027:mdna:59]
Examples of critical estimates in valuing certain intangible assets and goodwill we have acquired include but are not limited to:

[0001032975-19-000027:mdna:60]
| • | assumptions regarding royalty rate range and forecasted revenue growth rate; |

[0001032975-19-000027:mdna:61]
| • | assumptions regarding the estimated useful life of the acquired intangibles; |

[0001032975-19-000027:mdna:62]
| • | discount rates. |

[0001032975-19-000027:mdna:63]
Unanticipated events and circumstances may occur that may affect the accuracy or validity of such assumptions, estimates or actual results.

[0001032975-19-000027:mdna:64]
The economic useful life of the developed technology from the business acquisitions was determined based on the technology cycle related to developed technology of existing products, as well as the cash flows over the forecasted periods.

[0001032975-19-000027:mdna:65]
The economic useful life of the customer relationships from the business acquisitions was determined based on historical customer turnover rates and the industry benchmarks.

[0001032975-19-000027:mdna:66]
The economic useful life of the trademarks and trade names from the business acquisitions was determined based on the expected life of the trade names and the cash flows anticipated over the forecasted periods

[0001032975-19-000027:mdna:67]
Adoption of New Accounting Pronouncements

[0001032975-19-000027:mdna:68]
Refer to Note 2 to the consolidated financial statements included in this Annual Report on Form 10-K for recent accounting pronouncements adopted and to be adopted.

[0001032975-19-000027:mdna:69]
Constant Currency

[0001032975-19-000027:mdna:70]
We refer to our net sales growth rates excluding the impact of currency exchange rate fluctuations as "constant currency" sales growth rates. Percentage of constant currency sales growth is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales.

[0001032975-19-000027:mdna:71]
Given our global sales presence and the reporting of our financial results in U.S. Dollars, our financial results could be affected by significant shifts in currency exchange rates. See “Results of Operations” for information on the effect of currency exchange results on our sales. If the U.S. Dollar appreciates or depreciates in comparison to other currencies in future periods, this will affect our results of operations in future periods as well.

[0001032975-19-000027:mdna:72]
Reference to Sales

[0001032975-19-000027:mdna:73]
The term “sales” means net sales, except as otherwise specified and the sales growth discussion and sales growth rate percentages are in U.S. Dollars, except as otherwise specified.

[0001032975-19-000027:mdna:74]
Results of Operations

[0001032975-19-000027:mdna:75]
Net Sales

[0001032975-19-000027:mdna:76]
During fiscal year 2019, sales increased 9% in comparison to fiscal year 2018. If currency exchange rates had been constant in 2019 and 2018, our constant currency sales growth rate would have been 10%. We grew across most of our product categories, with double-digit growth in our Gaming, Video Collaboration, Tablet & Other Accessories and Audio & Wearables product categories and strong growth in Keyboards & Combos. Sales declined for Mobile Speakers and Smart Home product categories. Blue Microphones contributed approximately 2 percentage points of the sales growth rate. The adoption of Topic 606 increased our sales for fiscal year 2019 by $3.7 million.

[0001032975-19-000027:mdna:77]
During fiscal year 2018, sales increased 16% in comparison to fiscal year 2017. If currency exchange rates had been constant in 2018 and 2017, our constant currency sales growth rate would have been 13%. We grew across almost all our product categories. Tablet & Other Accessories, Video Collaboration, Gaming, and Smart

[0001032975-19-000027:mdna:78]
Home grew double digits, with Gaming contributing more than 8 percentage points of the sales growth rate during the year, including approximately 2 percentage points contributed by ASTRO.

[0001032975-19-000027:mdna:79]
Sales Denominated in Other Currencies

[0001032975-19-000027:mdna:80]
Although our financial results are reported in U.S. Dollars, a portion of our sales was generated in currencies other than the U.S. Dollar, such as the Euro, Chinese Renminbi, Japanese Yen, Canadian Dollar, Taiwan Dollar, British Pound and Australian Dollar. For each of the fiscal years 2019, 2018 and 2017, 50% of our sales were denominated in currencies other than the U.S. Dollar.

[0001032975-19-000027:mdna:81]
Sales by Region

[0001032975-19-000027:mdna:82]
The following table presents the change in sales by region for fiscal year 2019 compared with fiscal year 2018, and fiscal year 2018 compared with fiscal year 2017:

[0001032975-19-000027:mdna:83]
|  |  | 2019 vs. 2018 |  | 2018 vs. 2017 |
|  |  | Sales Growth Rate |  | Sales Growth Rate in Constant Currency |  | Sales Growth Rate |  | Sales Growth Rate in Constant Currency |
| Americas |  | 6 | % |  | 7 | % |  | 16 | % |  | 16 | % |
| EMEA |  | 5 |  |  | 7 |  |  | 10 |  |  | 4 |  |
| Asia Pacific |  | 17 |  |  | 19 |  |  | 23 |  |  | 22 |  |

[0001032975-19-000027:mdna:84]
Americas

[0001032975-19-000027:mdna:85]
The increase in sales in fiscal year 2019 of 6% compared with fiscal year 2018 was driven by growth in Gaming, Video Collaboration, Audio & Wearables, Keyboards and Combos, Tablet & Other Accessories and PC Webcams, partially offset by sales declines in Mobile Speakers, Smart Home and Pointing Devices.

[0001032975-19-000027:mdna:86]
The increase in sales in fiscal year 2018 of 16% compared with fiscal year 2017 was driven by growth in Pointing Devices, Tablet & Other Accessories, Video Collaboration, Gaming, and Smart Home.

[0001032975-19-000027:mdna:87]
EMEA

[0001032975-19-000027:mdna:88]
The increase in sales in fiscal year 2019 of 5% compared with fiscal year 2018 was driven by several of our product categories, with growth in Video Collaboration, Gaming, Pointing Devices and Tablet & Other Accessories, partially offset by sales declines in Mobile Speakers and Smart Home.

[0001032975-19-000027:mdna:89]
The increase in sales in fiscal year 2018 of 10% compared with fiscal year 2017 was driven by several of our product categories, with growth in Video Collaboration, Gaming, and Smart Home, partially offset by Pointing Devices and Audio & Wearables.

[0001032975-19-000027:mdna:90]
Asia Pacific

[0001032975-19-000027:mdna:91]
The increase in sales in fiscal year 2019 of 17% compared with fiscal year 2018 was primarily driven by sales increases in Gaming, Video Collaboration, Keyboard & Combos and Pointing Devices, offset by sales declines in Mobile Speakers.

[0001032975-19-000027:mdna:92]
The increase in sales in fiscal year 2018 of 23% compared with fiscal year 2017 was primarily driven by sales increases in Pointing Devices, Video Collaboration, Music and Gaming.

[0001032975-19-000027:mdna:93]
Sales by Product Categories

[0001032975-19-000027:mdna:94]
Sales by product categories for fiscal years 2019, 2018 and 2017 were as follows (Dollars in thousands):

[0001032975-19-000027:mdna:95]
|  |  | Years Ended March 31, |  | Change |
|  |  | 2019 |  | 2018 |  | 2017 |  | 2019 vs. 2018 |  | 2018 vs. 2017 |
| Pointing Devices |  | $ | 536,890 |  |  | $ | 516,637 |  |  | $ | 501,562 |  |  | 4 | % |  | 3 | % |
| Keyboards & Combos |  | 536,619 |  |  | 498,472 |  |  | 480,312 |  |  | 8 |  |  | 4 |  |
| PC Webcams |  | 121,282 |  |  | 112,147 |  |  | 107,087 |  |  | 8 |  |  | 5 |  |
| Tablet & Other Accessories |  | 128,315 |  |  | 107,942 |  |  | 76,879 |  |  | 19 |  |  | 40 |  |
| Video Collaboration |  | 259,521 |  |  | 182,717 |  |  | 127,009 |  |  | 42 |  |  | 44 |  |
| Mobile Speakers |  | 230,378 |  |  | 314,817 |  |  | 301,021 |  |  | (27 | ) |  | 5 |  |
| Audio & Wearables |  | 277,429 |  |  | 252,330 |  |  | 246,390 |  |  | 10 |  |  | 2 |  |
| Gaming |  | 648,130 |  |  | 491,995 |  |  | 314,362 |  |  | 32 |  |  | 57 |  |
| Smart Home |  | 49,344 |  |  | 89,373 |  |  | 65,510 |  |  | (45 | ) |  | 36 |  |
| Other (1) |  | 414 |  |  | 433 |  |  | 1,295 |  |  | (4 | ) |  | (67 | ) |
| Total Sales |  | $ | 2,788,322 |  |  | $ | 2,566,863 |  |  | $ | 2,221,427 |  |  | 9 |  |  | 16 |  |

[0001032975-19-000027:mdna:96]
| (1) | Other category includes products which we currently intend to phase out, or have already phased out, |

[0001032975-19-000027:mdna:97]
because they are no longer strategic to our business.

[0001032975-19-000027:mdna:98]
Sales by Product Categories:

[0001032975-19-000027:mdna:99]
Creativity & Productivity market:

[0001032975-19-000027:mdna:100]
Pointing Devices

[0001032975-19-000027:mdna:101]
Our Pointing Devices category comprises PC and Mac-related mice including trackballs, touchpads and presentation tools.

[0001032975-19-000027:mdna:102]
During fiscal year 2019, Pointing Devices sales increased 4%, compared to fiscal year 2018. The increase was primarily driven by the increases in sales of cordless mice and presentation tools. The increase in cordless mice was lead by strong contribution from the MX family of premium cordless mice, including the Vertical Wireless Mouse introduced in the second quarter of fiscal year 2019 as well as continued performance for MX Master 2S Wireless Mouse and B220 Silent Mouse.

[0001032975-19-000027:mdna:103]
During fiscal year 2018, Pointing Devices sales increased 3%, compared to fiscal year 2017. The increase was primarily driven by the increases in sales of cordless mice, trackball and presentation tools, partially offset by a decrease in the sales of corded mice.

[0001032975-19-000027:mdna:104]
Keyboards & Combos

[0001032975-19-000027:mdna:105]
Our Keyboards & Combos category comprises PC keyboards, living room keyboards and keyboard/mice combo products.

[0001032975-19-000027:mdna:106]
During fiscal year 2019, Keyboards & Combos sales increased 8%, compared to fiscal year 2018. The increase was primarily driven by the increases in sales of wireless keyboard/mice combos, mainly from increased sales of our MK 540, MK270 and MK110 wireless keyboard/mice combo, and an increase in sales of our wireless PC keyboard.

[0001032975-19-000027:mdna:107]
During fiscal year 2018, Keyboards & Combos sales increased 4%, compared to fiscal year 2017. The increase was primarily driven by the introduction of Craft cordless keyboard and increased sales of our MK270 and MK235 wireless keyboard/mice combo, partially offset by the decreases in sales of the MK710 wireless keyboard/mice combo and K400 Plus wireless keyboard.

[0001032975-19-000027:mdna:108]
PC Webcams

[0001032975-19-000027:mdna:109]
Our PC Webcams category comprises PC-based webcams targeted primarily at consumers.

[0001032975-19-000027:mdna:110]
During fiscal year 2019, PC Webcams sales increased 8%, compared to fiscal year 2018. The increase was primarily driven by the increases in sales of our HD Pro Webcam C920 and 1080 Pro Steam Webcam.

[0001032975-19-000027:mdna:111]
During fiscal year 2018, PC Webcams sales increased 5%, compared to fiscal year 2017. The increase was primarily driven by the increases in sales of our 1080P Pro Stream Webcam, partially offset by the decrease in sales of our HD Pro Webcam C920 and HD Webcam C525.

[0001032975-19-000027:mdna:112]
Tablet & Other Accessories

[0001032975-19-000027:mdna:113]
Our Tablet & Other Accessories category comprises keyboards for tablets and smartphones as well as other accessories for mobile devices.

[0001032975-19-000027:mdna:114]
During fiscal year 2019, Tablet & Other Accessories sales increased 19%, compared to fiscal year 2018. The increase was primarily driven by the introductions of our Slim Folio keyboard cases for the iPad 5th/6th Generation, education-based Rugged Combo 2, Slim Combo keyboard cases for the iPad 5th/6th Generation, Crayon (a digital pencil) and POWERED (a wireless charging dock for iPhone) during fiscal year 2019.

[0001032975-19-000027:mdna:115]
During fiscal year 2018, Tablet & Other Accessories sales increased 40%, compared to fiscal year 2017. The increase was primarily driven by the introduction of Slim Folio keyboard cases for the iPad 5th Generation, Slim Combo keyboard cases for the iPad Pro, and Rugged Combo keyboard case, partially offset by a decrease in sales of Create and Type+ keyboard cases.

[0001032975-19-000027:mdna:116]
Gaming market:

[0001032975-19-000027:mdna:117]
Gaming

[0001032975-19-000027:mdna:118]
Our Gaming category comprises gaming mice, keyboards, headsets, gamepads, steering wheels, simulation controllers, console gaming headsets and console gaming controllers.

[0001032975-19-000027:mdna:119]
During fiscal year 2019, Gaming sales increased 32%, compared to fiscal year 2018. The increase was primarily due to increases in sales of our core PC gaming products and console gaming headsets, which benefited from the growing gaming market, growth in eSports, expansions in new channels and regions, and expansion in product portfolios. The increase for fiscal year 2019 was also driven by the fact that the ASTRO Acquisition closed on August 11, 2017, in the middle of our fiscal year 2018 second quarter, resulting in a partial comparative period impact. The growth was partially offset by a slight decline in our simulation products.

[0001032975-19-000027:mdna:120]
During fiscal year 2018, Gaming sales increased 57%, compared to fiscal year 2017. Growth in Gaming sales was broad-based, especially driven by the ASTRO Acquisition, the sales increases of the G29 Driving Force steering wheel, the G502 Proteus Spectrum gaming mouse and the G203 gaming mouse, and the introduction of the G903 gaming mouse. For fiscal year 2018, ASTRO contributed $54.1 million to sales.

[0001032975-19-000027:mdna:121]
Video Collaboration market:

[0001032975-19-000027:mdna:122]
Video Collaboration

[0001032975-19-000027:mdna:123]
Our Video Collaboration category includes Logitech’s ConferenceCams, which combines affordable enterprise-quality audio and high definition (HD) 1080p video to bring video conferencing to businesses of any size.

[0001032975-19-000027:mdna:124]
During fiscal year 2019, Video Collaboration sales increased 42%, compared to fiscal year 2018. The increase was primarily due to increases in sales of our MeetUp and PTZ Pro 2 video conference cameras, BRIO Pro Webcam and C925E Webcam, and the introductions of our Rally and Rally Ultra-HD PTZ Conference Camera in the third quarter of fiscal year 2019.

[0001032975-19-000027:mdna:125]
During fiscal year 2018, Video Collaboration sales increased 44%, compared to fiscal year 2017. The increase was primarily due to the introductions of MeetUp and PTZ Pro 2 video conference cameras and increases in sales of our Logitech Group conference camera, C930e and Brio 4K Pro webcams. The sales increase was partially offset by a decrease in sales of our PTZ Pro video conference camera.

[0001032975-19-000027:mdna:126]
Music market:

[0001032975-19-000027:mdna:127]
Mobile Speakers

[0001032975-19-000027:mdna:128]
Our Mobile Speakers category comprises portable wireless Bluetooth and Wi-Fi speakers.

[0001032975-19-000027:mdna:129]
During fiscal year 2019, Mobile Speakers sales decreased 27%, compared to fiscal year 2018. The decrease was primarily due to decreases in sales of our existing Ultimate Ears speakers. The decrease was partially offset by sales from the introductions of our Ultimate Ears MEGABOOM 3 and BOOM 3 mobile speakers in the second quarter of fiscal year 2019.

[0001032975-19-000027:mdna:130]
During fiscal year 2018, Mobile Speakers sales increased 5%, compared to fiscal year 2017. The increase was primarily due to the increases in sales of the Ultimate Ears WONDERBOOM product and the introductions of the Ultimate Ears BLAST and MEGABLAST, which were both released in the third quarter of fiscal year 2018. The sales increase was partially offset by a decrease in sales of our Ultimate Ears BOOM 2, Ultimate Ears MEGABOOM, and Ultimate Ears ROLL 2.

[0001032975-19-000027:mdna:131]
Audio & Wearables

[0001032975-19-000027:mdna:132]
Our Audio & Wearables category comprises PC speakers, PC headsets, in-ear headphones, premium wireless audio wearables and studio-quality microphones for professionals and consumers.

[0001032975-19-000027:mdna:133]
During fiscal year 2019, Audio & Wearables sales increased 10%, compared to fiscal year 2018. The increase was primarily due to the increase in sales of our corded headsets and sales from products as a result of the Blue Microphones Acquisition (see Note 3 to the consolidated financial statements), partially offset by a decrease in sales of our PC speakers and Jaybird wireless in-ear headphones.

[0001032975-19-000027:mdna:134]
During fiscal year 2018, Audio & Wearables sales increased 2%, compared to fiscal year 2017. The increase was primarily due to the increase in sales from our Jaybird wireless in-ear headphones, partially offset by a decrease in sales of our PC speakers.

[0001032975-19-000027:mdna:135]
Smart Home market:

[0001032975-19-000027:mdna:136]
Smart Home

[0001032975-19-000027:mdna:137]
Our Smart Home category mainly comprises our Harmony line of advanced home entertainment controllers and home security cameras.

[0001032975-19-000027:mdna:138]
During fiscal year 2019, Smart Home sales decreased 45%, compared to fiscal year 2018. The decrease was primarily due to the decreases in sales of our Harmony remotes and home security cameras.

[0001032975-19-000027:mdna:139]
During fiscal year 2018, Smart Home sales increased 36%, compared to fiscal year 2017. The increase was primarily due to the introductions of our Circle 2 wired and wireless home security cameras, in addition to the increase in sales of our Harmony Elite remote, partially offset by a decrease in sales of our Harmony 650 remote.

[0001032975-19-000027:mdna:140]
Gross Profit

[0001032975-19-000027:mdna:141]
Gross profit for fiscal years 2019, 2018 and 2017 was as follows (Dollars in thousands):

[0001032975-19-000027:mdna:142]
|  |  | Years Ended March 31, |
|  |  | 2019 |  | 2018 |  | 2017 |
| Net sales |  | $ | 2,788,322 |  |  | $ | 2,566,863 |  |  | $ | 2,221,427 |  |
| Gross profit |  | $ | 1,037,011 |  |  | $ | 909,241 |  |  | $ | 820,041 |  |
| Gross margin |  | 37.2 | % |  | 35.4 | % |  | 36.9 | % |

[0001032975-19-000027:mdna:143]
Gross profit consists of sales, less cost of goods sold (which includes materials, direct labor and related overhead costs, costs of manufacturing facilities, royalties, costs of purchasing components from outside suppliers, distribution costs, warranty costs, customer support, shipping and handling costs, outside processing costs and write-down of inventories), amortization of intangible assets and purchase accounting effect on inventory.

[0001032975-19-000027:mdna:144]
Gross margin increased by 180 basis points to 37.2% during fiscal year 2019, compared to fiscal year 2018. The increase in gross margin was primarily driven by favorable product mix and cost reductions. In addition, extra costs incurred due to the transition of the distribution center in North America in the third quarter of fiscal year 2018 negatively affected the gross margin in fiscal year 2018.

[0001032975-19-000027:mdna:145]
Gross margin decreased by 150 basis points to 35.4% during fiscal year 2018, compared to fiscal year 2017. The decrease in gross margin was primarily driven by increases in Customer Program spend, additional costs incurred due to the transition of the distribution center in North America in the third quarter of fiscal year 2018, and product mix, partially offset by product cost reductions and favorable currency exchange rates. In addition, in fiscal year 2017, we recorded a benefit of $14.4 million primarily due to a change in estimated breakage attributable to Customer Program accruals in EMEA.

[0001032975-19-000027:mdna:146]
Operating Expenses

[0001032975-19-000027:mdna:147]
Operating expenses for fiscal years 2019, 2018 and 2017 were as follows (Dollars in thousands):

[0001032975-19-000027:mdna:148]
|  |  | Years Ended March 31, |
|  |  | 2019 |  | 2018 |  | 2017 |
| Marketing and selling |  | $ | 488,263 |  |  | $ | 435,489 |  |  | $ | 379,641 |  |
| % of sales |  | 17.5 | % |  | 17.0 | % |  | 17.1 | % |
| Research and development |  | 161,230 |  |  | 143,760 |  |  | 130,525 |  |
| % of sales |  | 5.8 | % |  | 5.6 | % |  | 5.9 | % |
| General and administrative |  | 98,732 |  |  | 96,353 |  |  | 100,270 |  |
| % of sales |  | 3.5 | % |  | 3.8 | % |  | 4.5 | % |
| Amortization of intangible assets and acquisition-related costs |  | 14,290 |  |  | 8,930 |  |  | 5,814 |  |
| % of sales |  | 0.5 | % |  | 0.3 | % |  | 0.3 | % |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | (4,908 | ) |  | (8,092 | ) |
| % of sales |  | — | % |  | (0.2 | )% |  | (0.4 | )% |
| Restructuring charges (credits), net |  | 11,302 |  |  | (116 | ) |  | 23 |  |
| % of sales |  | 0.4 | % |  | — | % |  | — | % |
| Total operating expenses |  | $ | 773,817 |  |  | $ | 679,508 |  |  | $ | 608,181 |  |
| % of sales |  | 27.8 | % |  | 26.5 | % |  | 27.4 | % |

[0001032975-19-000027:mdna:149]
The increase in total operating expenses during fiscal year 2019, compared to fiscal year 2018, was due to increases in marketing and selling expenses, research and development expenses, restructuring charges, amortization of intangible assets from the business acquisitions, and a credit from the change in fair value of contingent consideration recorded in fiscal year 2018 for a business acquisition completed in fiscal year 2017.

[0001032975-19-000027:mdna:150]
The increase in total operating expenses during fiscal year 2018, compared to fiscal year 2017, was due to increases in marketing and selling expenses, research and development expenses, amortization of intangible assets from the business acquisitions, and a lower credit from the change in fair value of contingent consideration for business acquisition, partially offset by the decrease in general and administrative expenses.

[0001032975-19-000027:mdna:151]
Marketing and Selling

[0001032975-19-000027:mdna:152]
Marketing and selling expenses consist of personnel and related overhead costs, corporate and product marketing, promotions, advertising, trade shows, technical support for customer experiences and facilities costs.

[0001032975-19-000027:mdna:153]
During fiscal year 2019, marketing and selling expenses increased $52.8 million, compared to fiscal year 2018. The increase was primarily due to an increase of $25.4 million in third-party costs including advertising and marketing expenses to support our new products and an increase of $23.9 million in personnel-related costs due to increased headcount, partly resulting from the Blue Microphones Acquisition, and increased performance-based variable compensation.

[0001032975-19-000027:mdna:154]
During fiscal year 2018, marketing and selling expenses increased $55.8 million, compared to fiscal year 2017. The increase was primarily due to an increase of $30.2 million in expenses for external advertising and marketing and an increase of $23.2 million in personnel-related costs due to increased headcount during the last twelve months to expand our marketing team to support our increased advertising and marketing efforts for our products, including the increased headcount resulting from the ASTRO Acquisition.

[0001032975-19-000027:mdna:155]
Research and Development

[0001032975-19-000027:mdna:156]
Research and development expenses consist of personnel and related overhead costs for contractors and outside consultants, supplies and materials, equipment depreciation and facilities costs, all associated with the design and development of new products and enhancements of existing products.

[0001032975-19-000027:mdna:157]
During fiscal year 2019, research and development expenses increased $17.5 million, compared to fiscal year 2018. The increase was primarily due to an increase of $9.6 million in personnel-related costs for the development

[0001032975-19-000027:mdna:158]
of new products and increased headcount, partly resulting from the Blue Microphones Acquisition, and an increase of $5.8 million in third-party costs.

[0001032975-19-000027:mdna:159]
During fiscal year 2018, research and development expenses increased $13.2 million, compared to fiscal year 2017. The increase was primarily due to an increase in higher personnel-related costs for the development of new products and increased headcount from the ASTRO Acquisition.

[0001032975-19-000027:mdna:160]
General and Administrative

[0001032975-19-000027:mdna:161]
General and administrative expenses consist primarily of personnel and related overhead and facilities costs for the finance, information systems, executives, human resources and legal functions.

[0001032975-19-000027:mdna:162]
During fiscal year 2019, general and administrative expenses increased $2.4 million, compared to fiscal year 2018. The increase was primarily due to an increase of $2.8 million in personnel-related costs and an increase of $1.4 million in third-party costs including consulting costs, partially offset by a decrease of $1.9 million in infrastructure costs.

[0001032975-19-000027:mdna:163]
During fiscal year 2018, general and administrative expenses decreased $3.9 million, compared to fiscal year 2017. The decrease was primarily due to a decrease of $6.8 million in third-party costs, including mainly consulting costs, partially offset by an increase of $2.6 million in personnel-related costs.

[0001032975-19-000027:mdna:164]
Amortization of Intangibles and Acquisition-Related Costs

[0001032975-19-000027:mdna:165]
Amortization of intangibles included in operating expense and acquisition-related costs during fiscal years 2019, 2018 and 2017 were as follows (in thousands):

[0001032975-19-000027:mdna:166]
|  |  | Years Ended March 31, |
|  |  | 2019 |  | 2018 |  | 2017 |
| Amortization of intangible assets |  | $ | 12,594 |  |  | $ | 7,518 |  |  | $ | 4,352 |  |
| Acquisition-related costs |  | 1,696 |  |  | 1,412 |  |  | 1,462 |  |
| Total |  | $ | 14,290 |  |  | $ | 8,930 |  |  | $ | 5,814 |  |

[0001032975-19-000027:mdna:167]
Amortization of intangible assets consists of amortization of acquired intangible assets, including customer relationships and trademarks and trade names. Acquisition-related costs include legal expense, due diligence costs, and other professional costs incurred for business acquisitions.

[0001032975-19-000027:mdna:168]
The increase in amortization of intangible assets from fiscal year 2018 to 2019 was primarily due to the Blue Microphones Acquisition and the ASTRO Acquisition. The increase in amortization of intangible assets from fiscal year 2018 to 2017 was primarily driven by the ASTRO Acquisition.

[0001032975-19-000027:mdna:169]
Change in Fair Value of Contingent Consideration for Business Acquisition

[0001032975-19-000027:mdna:170]
The change in fair value of contingent consideration for business acquisition during fiscal years 2018 and 2017 is primarily due to lower-than-expected sales of Jaybird products, and revised projected sales of Jaybird products during the remaining Jaybird Acquisition earn-out period, primarily driven by supply constraints, an evolving product portfolio and changes in the competitive target market.

[0001032975-19-000027:mdna:171]
In October 2017, Logitech and the sellers of Jaybird entered into an agreement fully, irrevocably and unconditionally releasing Logitech from the earn-out rights and payments in exchange for $5.0 million in cash.

[0001032975-19-000027:mdna:172]
Restructuring Charges (Credits)

[0001032975-19-000027:mdna:173]
The following table summarizes restructuring-related activities during fiscal years 2019, 2018 and 2017 from continuing operations (in thousands):

[0001032975-19-000027:mdna:174]
|  |  | Restructuring - Continuing Operations |
|  |  | TerminationBenefits |  | Lease ExitCosts |  | Total |
| Accrual balance at March 31, 2016 |  | $ | 5,907 |  |  | $ | 125 |  |  | $ | 6,032 |  |
| Charges, net |  | 23 |  |  | — |  |  | 23 |  |
| Cash payments |  | (5,195 | ) |  | (125 | ) |  | (5,320 | ) |
| Accrual balance at March 31, 2017 |  | 735 |  |  | — |  |  | 735 |  |
| Credits, net |  | (116 | ) |  | — |  |  | (116 | ) |
| Cash payments |  | (619 | ) |  | — |  |  | (619 | ) |
| Accrual balance at March 31, 2018 |  | — |  |  | — |  |  | — |  |
| Charges, net |  | 11,302 |  |  | — |  |  | 11,302 |  |
| Cash payments |  | (6,913 | ) |  | — |  |  | (6,913 | ) |
| Accrual balance at March 31, 2019 |  | $ | 4,389 |  |  | $ | — |  |  | $ | 4,389 |  |

[0001032975-19-000027:mdna:175]
During the first quarter of fiscal year 2019, we implemented a restructuring plan to streamline and realign our overall organizational structure and reallocate resources to support long-term growth opportunities. In July 2018, the Board of Directors approved additional costs under this restructuring plan, totaling pre-tax charges of approximately $10.0 million to $15.0 million, of which $11.3 million was recognized during fiscal year 2019. The total charges consisted of cash severance and other personnel costs and are presented as restructuring charges (credits), net in the Consolidated Statements of Operations. We expect to have substantially completed this restructuring within the next three months.

[0001032975-19-000027:mdna:176]
The restructuring-related activities for the years ended March 31, 2018 and 2017 include activities from our restructuring plan implemented in fiscal year 2016.

[0001032975-19-000027:mdna:177]
Interest Income

[0001032975-19-000027:mdna:178]
Interest income for fiscal years 2019, 2018 and 2017 was as follows (in thousands):

[0001032975-19-000027:mdna:179]
|  |  | Years Ended March 31, |
|  |  | 2019 |  | 2018 |  | 2017 |
| Interest Income |  | $ | 8,375 |  |  | $ | 4,969 |  |  | $ | 1,452 |  |

[0001032975-19-000027:mdna:180]
We invest in highly liquid instruments with an original maturity of three months or less at the date of purchase, which are classified as cash equivalents. The increases in interest income for fiscal years 2019 and 2018 compared to the prior periods were both due to higher yield earned on those investments.

[0001032975-19-000027:mdna:181]
Other Income (Expense), Net

[0001032975-19-000027:mdna:182]
Other income and expense for fiscal years 2019, 2018 and 2017 was as follows (in thousands):

[0001032975-19-000027:mdna:183]
|  |  | Years Ended March 31, |
|  |  | 2019 |  | 2018 |  | 2017 |
| Investment income related to the deferred compensation plan |  | $ | 664 |  |  | $ | 1,386 |  |  | $ | 1,343 |  |
| Currency exchange gain (loss), net |  | (3,608 | ) |  | (4,613 | ) |  | 169 |  |
| Other |  | 2,508 |  |  | 790 |  |  | 165 |  |
| Total |  | $ | (436 | ) |  | $ | (2,437 | ) |  | $ | 1,677 |  |

[0001032975-19-000027:mdna:184]
Investment income related to the deferred compensation plan for fiscal years 2019, 2018 and 2017 represents earnings, gains, and losses on trading investments related to a deferred compensation plan offered by one of our subsidiaries.

[0001032975-19-000027:mdna:185]
Currency exchange gains or losses relate to balances denominated in currencies other than the functional currency in our subsidiaries, as well as to the sale of currencies, and to gains or losses recognized on currency exchange forward contracts. We do not speculate in currency positions, but we are alert to opportunities to maximize currency exchange gains and minimize currency exchange losses.

[0001032975-19-000027:mdna:186]
The components of net periodic benefit cost other than the service cost component for the year ended March 31, 2019 are included in the line “Other” above as a result of adopting ASU 2017-07 effective April 1, 2018. The impact to the comparative period was immaterial and therefore the prior period statements of operations were not revised.

[0001032975-19-000027:mdna:187]
Provision for Income Taxes

[0001032975-19-000027:mdna:188]
The provision for income taxes and the effective income tax rate for fiscal years 2019, 2018 and 2017 were as follows (Dollars in thousands):

[0001032975-19-000027:mdna:189]
|  |  | Years Ended March 31, |
|  |  | 2019 |  | 2018 |  | 2017 |
| Provision for income taxes |  | $ | 13,560 |  |  | $ | 23,723 |  |  | $ | 9,113 |  |
| Effective income tax rate |  | 5.0 | % |  | 10.2 | % |  | 4.2 | % |

[0001032975-19-000027:mdna:190]
The change in the effective income tax rate between fiscal years 2019 and 2018 was primarily due to the mix of income and losses in the various tax jurisdictions in which we operate and provisional income tax accounting impact from the enactment of H.R.1, also known as the "Tax Cuts and Jobs Act" (the Tax Act) in the United States on December 22, 2017. The Tax Act permanently reduced the corporate income tax rate in the United States from 35% to 21%. We recorded a provisional income tax charge of $21.7 million, net of valuation allowance against tax credits, in fiscal year 2018 to remeasure the deferred tax effects at 21%. Furthermore, we recognized $10.1 million and $13.4 million of excess tax benefits, net of shortfalls, in fiscal year 2019 and 2018, respectively. In the same periods, there were tax benefits of $2.9 million and $8.3 million, respectively, from the reversal of uncertain tax positions from the expiration of statutes of limitations.

[0001032975-19-000027:mdna:191]
The change in the effective income tax rate between fiscal years 2018 and 2017 was primarily driven by provisional impacts in fiscal year 2018 from the Tax Act described above. We recognized $13.4 million of excess tax benefits, net of shortfalls, in fiscal year 2018 after the adoption of ASU 2016-09. Furthermore, there was a tax benefit of $8.3 million in fiscal year 2018 related to the reversal of uncertain tax positions resulting from the expiration of statutes of limitations, compared to $15.4 million in fiscal year 2017.

[0001032975-19-000027:mdna:192]
As of March 31, 2019 and 2018, the total amounts of unrecognized tax benefits due to uncertain tax positions were $76.5 million and $69.1 million, respectively, all of which would affect the effective income tax rates if recognized.

[0001032975-19-000027:mdna:193]
As of March 31, 2019 and 2018, we had $36.4 million and $35.0 million, respectively, in non-current income taxes payable, including interest and penalties, related to our income tax liability for uncertain tax positions. We recognized $0.6 million, $0.6 million and $0.7 million in interest and penalties related to unrecognized tax positions

[0001032975-19-000027:mdna:194]
in income tax expense during fiscal years 2019, 2018 and 2017, respectively. As of March 31, 2019 and 2018, we had $2.5 million and $2.3 million, respectively, of accrued interest and penalties related to uncertain tax positions.

[0001032975-19-000027:mdna:195]
We file Swiss and foreign tax returns. We received final tax assessments in Switzerland through fiscal year 2017. For other foreign jurisdictions such as the United States, we are generally not subject to tax examinations for years prior to fiscal year 2016. We are under examination and have received assessment notices in foreign tax jurisdictions. If the examinations are resolved unfavorably, there is a possibility that they may have a material negative impact on our results of operations.

[0001032975-19-000027:mdna:196]
Liquidity and Capital Resources

[0001032975-19-000027:mdna:197]
Cash Balances, Available Borrowings, and Capital Resources

[0001032975-19-000027:mdna:198]
As of March 31, 2019, we had cash and cash equivalents of $604.5 million, compared with $641.9 million as of March 31, 2018. Our cash and cash equivalents consist of bank demand deposits and short-term time deposits, of which 77% is held in Switzerland and 10% is held in China (including Hong Kong). We do not expect to incur any material adverse tax impact, except for what has been recognized, or be significantly inhibited by any country in which we do business from the repatriation of funds to Switzerland, our home domicile.

[0001032975-19-000027:mdna:199]
As of March 31, 2019, our working capital was $632.6 million, compared with working capital of $597.4 million as of March 31, 2018. The increase in working capital over fiscal year 2018 was primarily due to higher accounts receivable, net, higher inventories and other current assets, and lower balance of accounts payable, partially offset by lower balances of cash and cash equivalents and higher accrued and other current liabilities.

[0001032975-19-000027:mdna:200]
We had several uncommitted, unsecured bank lines of credit aggregating to $80.6 million as of March 31, 2019. There are no financial covenants under these lines of credit with which we must comply. As of March 31, 2019, we had outstanding bank guarantees of $34.3 million under these lines of credit.

[0001032975-19-000027:mdna:201]
The following table presents selected financial information and statistics as of March 31, 2019, 2018 and 2017 (Dollars in thousands):

[0001032975-19-000027:mdna:202]
|  |  | March 31, |
|  |  | 2019 |  | 2018 |  | 2017 |
| Accounts receivable, net |  | $ | 383,309 |  |  | $ | 214,885 |  |  | $ | 185,179 |  |
| Accounts payable |  | $ | 283,922 |  |  | $ | 293,988 |  |  | $ | 274,805 |  |
| Inventories |  | $ | 293,495 |  |  | $ | 259,906 |  |  | $ | 253,401 |  |
| Days sales in accounts receivable (DSO)(Days)(1) |  | 55 |  |  | 33 |  |  | 33 |  |
| Days accounts payable outstanding (DPO) (Days)(2) |  | 65 |  |  | 70 |  |  | 79 |  |
| Inventory turnover (ITO)(x)(3) |  | 5.3 |  |  | 5.9 |  |  | 4.9 |  |

[0001032975-19-000027:mdna:203]
______________________________

[0001032975-19-000027:mdna:204]
| (1) | DSO is determined using ending accounts receivable, net as of the most recent quarter-end and sales for the most recent quarter. |

[0001032975-19-000027:mdna:205]
| (2) | DPO is determined using ending accounts payable as of the most recent quarter-end and cost of goods sold for the most recent quarter. |

[0001032975-19-000027:mdna:206]
| (3) | ITO is determined using ending inventories and the annualized cost of goods sold (based on cost of goods sold for the most recent quarter). |

[0001032975-19-000027:mdna:207]
DSO as of March 31, 2019 increased by 22 days to 55 days, as compared to 33 days as of March 31, 2018. The adoption of Topic 606 negatively impacted our DSO for the year ended March 31, 2019 by 18 days, mainly as a result of changes in the balance sheet presentation of certain reserve balances previously shown net within accounts receivable which are now presented as accrued and other current liabilities. The adoption of Topic 606 did not have an impact over the total cash flows from operating, investing or financing activities. Refer to Note 2 to the consolidated financial statements for the details of the adoption impact of Topic 606. Timing of sales also increased DSO by 4 days. DSO as of March 31, 2018 was consistent with DSO as of March 31, 2017.

[0001032975-19-000027:mdna:208]
DPO as of March 31, 2019 decreased 5 days, compared to March 31, 2018, primarily due to the timing of purchases. DPO as of March 31, 2018 decreased 9 days, compared to March 31, 2017, primarily due to the timing of purchases and payments.

[0001032975-19-000027:mdna:209]
ITO as of March 31, 2019 was lower compared to March 31, 2018, due to higher inventory related to new product introductions and inventory from the Blue Microphones Acquisition. ITO as of March 31, 2018 was higher compared to March 31, 2017, due to higher sales growth (hence higher cost of goods sold) than inventory increase.

[0001032975-19-000027:mdna:210]
If we are not successful in launching and phasing in our new products launched during the current fiscal year, or we are not able to sell the new products at the prices planned, it could have a material impact on our revenue, gross profit margin, operating results including operating cash flow, and inventory turnover in the future.

[0001032975-19-000027:mdna:211]
During fiscal year 2019, we generated $305.2 million in cash from operating activities. Our main sources of operating cash flows were from net income, after adding back non-cash expenses of depreciation, amortization, and share-based compensation expense, and from changes in operating assets and liabilities. The increase in accounts receivable, net was primarily driven by growth and timing of sales. The decrease in accounts payable was primarily driven by the timing of purchases. The increase in inventories net of effect of acquisition was primarily driven by new product introductions. The increase in accrued and other liabilities was primarily due to higher accrued personnel expenses and increase in warranty liabilities.

[0001032975-19-000027:mdna:212]
Net cash used in investing activities was $173.3 million, primarily due to $133.8 million of the purchase price (net of cash acquired) for business acquisitions, $35.9 million of purchases of property, plant, and equipment, and $2.7 million of investments in privately held companies.

[0001032975-19-000027:mdna:213]
Net cash used in financing activities was $159.1 million, primarily due to $114.0 million of cash dividends paid during the year, $32.4 million of repurchases of our registered shares and $30.8 million of tax withholdings related to net share settlements of restricted stock units, partially offset by $18.1 million in proceeds received from the sale of shares upon exercise of stock options and purchase rights.

[0001032975-19-000027:mdna:214]
Our expenditures for property, plant and equipment during fiscal years 2019, 2018 and 2017 were primarily for tooling and equipment, computer hardware and software and leasehold improvements. Our expenditures for property, plant and equipment decreased during fiscal year 2019, compared to fiscal year 2018, primarily due to a lower amount of tooling purchases. Our expenditures for property, plant and equipment increased during fiscal year 2018, compared to fiscal year 2017, primarily due to a higher amount of tooling purchases.

[0001032975-19-000027:mdna:215]
Our payments for acquisitions, net of cash acquired, during fiscal year 2019 were primarily for the Blue Microphones Acquisition. Our payments for acquisitions, net of cash acquired, during fiscal year 2018, were primarily for the ASTRO Acquisition (refer to "Note 3 - Business Acquisitions" to the consolidated financial statements). Our payments for acquisitions, net of cash acquired, during fiscal year 2017, were for the Jaybird Acquisition and the Saitek Acquisition.

[0001032975-19-000027:mdna:216]
The purchases and sales of trading investments during fiscal years 2019, 2018 and 2017 represent mutual fund activity directed by participants in a deferred compensation plan offered by one of our subsidiaries. The mutual funds are held by a Rabbi Trust.

[0001032975-19-000027:mdna:217]
During fiscal year 2019, there was a $10.1 million loss of currency translation exchange rate effect on cash and cash equivalents, compared to a gain of $4.7 million of currency translation exchange rate effect during fiscal year 2018, and a $5.4 million loss of currency translation exchange rate effect during fiscal year 2017. Currency translation exchange effects during fiscal year 2019 were primarily due to the weakening of Euro and Chinese Renminbi versus the U.S. Dollar by 9% and 7%, respectively, in fiscal year 2019. Currency translation exchange effects during fiscal year 2018 were primarily due to the strengthening of the Euro versus the U.S. Dollar by 15% in fiscal year 2018.

[0001032975-19-000027:mdna:218]
Cash Outlook

[0001032975-19-000027:mdna:219]
Our principal sources of liquidity are our cash and cash equivalents, cash flow generated from operations and, to a much lesser extent, capital markets and borrowings. Our future working capital requirements and capital expenditures may increase to support investments in product innovations and growth opportunities or to acquire or invest in complementary businesses, products, services, and technologies.

[0001032975-19-000027:mdna:220]
In May 2019, the Board of Directors recommended that the Company pay CHF121.8 million ($122.4 million based on the exchange rate on March 31, 2019) in cash dividends for fiscal year 2019. In fiscal year 2019, we paid a cash dividend of CHF110.7 million (U.S. Dollar amount of $114.0 million) out of retained earnings. In fiscal year 2018, we paid a cash dividend of CHF100.0 million (U.S. Dollar amount of $104.2 million) out of retained earnings. During fiscal year 2017, we paid a cash dividend of CHF 90.2 million (U.S. Dollar amount of $93.1 million) out of retained earnings.

[0001032975-19-000027:mdna:221]
In March 2017, our Board of Directors approved a new share buyback program, which authorizes us to invest up to $250.0 million to purchase our own shares, following the expiration date of the 2014 share buyback program. The new program was approved by the Swiss Takeover Board in May 2017. Although we enter into trading plans for systematic repurchases (e.g. 10b5-1 trading plans) from time to time, our share buyback program provides us with the opportunity to make opportunistic repurchases during periods of favorable market conditions and is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Opportunistic purchases may be started or stopped at any time without prior notice depending on market conditions and other factors. As of March 31, 2019, the remaining amount that may be repurchased under the program is $187.4 million.

[0001032975-19-000027:mdna:222]
For over ten years, we have generated positive cash flows from our operating activities, including cash from operations of $305.2 million, $346.3 million and $288.4 million during fiscal years 2019, 2018, and 2017, respectively. If we do not generate sufficient operating cash flows to support our operations and future planned cash requirements, our operations could be harmed and our access to credit facilities could be restricted or eliminated. However, we believe that the trend of our historical cash flow generation, our projections of future operations and our available cash balances will provide sufficient liquidity to fund our operations for at least the next 12 months.

[0001032975-19-000027:mdna:223]
Our other contractual obligations and commitments that require cash are described in the following sections.

[0001032975-19-000027:mdna:224]
Contractual Obligations and Commitments

[0001032975-19-000027:mdna:225]
The following table summarizes our contractual obligations and commitments as of March 31, 2019 (in thousands):

[0001032975-19-000027:mdna:226]
|  |  |  |  | Payments Due by Period |
|  |  | March 31, 2019 | <1 year |  | 1-3 years |  | 3-5 years |  | >5 years |
| Inventory purchase commitments |  | $ | 227,609 |  |  | $ | 227,609 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Capital purchase commitments |  | 12,132 |  |  | 12,132 |  |  | — |  |  | — |  |  | — |  |
| Expected contribution to employee benefit plan |  | 5,456 |  |  | 5,456 |  |  | * |  |  | * |  |  | * |  |
| Operating leases obligations |  | 39,620 |  |  | 11,849 |  |  | 17,884 |  |  | 6,241 |  |  | 3,646 |  |
| Total |  | $ | 284,817 |  |  | $ | 257,046 |  |  | $ | 17,884 |  |  | $ | 6,241 |  |  | $ | 3,646 |  |

[0001032975-19-000027:mdna:227]
* Expected contribution to employee benefit plan: Commitments under the retirement plans relate to expected contributions to be made to our defined benefit plans for the next year only. We fund our pension plans so that we meet at least the minimum contribution requirements, as established by local government, funding and taxing authorities. Expected contributions and payments to our defined benefit pension plans and non-retirement post-employment benefit plans beyond one year are excluded from the contractual obligations table because they are dependent on numerous factors that may result in a wide range of outcomes and thus are impractical to estimate. For more information on our defined benefit pension plans and non-retirement post-employment benefit plans, see Note 5 to the Consolidated Financial Statements in Item 8, which is incorporated herein by reference.

[0001032975-19-000027:mdna:228]
Purchase Commitments

[0001032975-19-000027:mdna:229]
As of March 31, 2019, we have non-cancelable purchase commitments of $227.6 million for inventory purchases made in the normal course of business from original design manufacturers, contract manufacturers and other suppliers, the majority of which are expected to be fulfilled during the first two quarters of fiscal year 2020. We recorded a liability for firm, non-cancelable, and unhedged inventory purchase commitments in excess of anticipated demand or net realizable value consistent with our valuation of excess and obsolete inventory. As of March 31, 2019, the liability for these purchase commitments was $14.1 million and is recorded in accrued and other current liabilities and is not included in the preceding table. We have firm purchase commitments of $12.1 million for capital expenditures, primarily related to commitments for tooling, computer hardware and leasehold improvements. We expect to continue making capital expenditures in the future to support product development activities and ongoing and expanded operations. Although open purchase commitments are considered enforceable and legally binding, the terms generally allow us the option to reschedule and adjust our requirements based on business needs prior to delivery of goods.

[0001032975-19-000027:mdna:230]
Operating Leases Obligation

[0001032975-19-000027:mdna:231]
We lease facilities under operating leases, certain of which require us to pay property taxes, insurance and maintenance costs. Operating leases for facilities are generally renewable at our option and usually include escalation clauses linked to inflation. The remaining terms of our non-cancelable operating leases expire in various years through 2030.

[0001032975-19-000027:mdna:232]
Income Taxes Payable

[0001032975-19-000027:mdna:233]
As of March 31, 2019, we had $36.4 million in non-current income taxes payable, including interest and penalties, related to our income tax liability for uncertain tax positions. At this time, we are unable to make a reasonably reliable estimate of the timing of payments in individual years in connection with these tax liabilities; therefore, such amounts are not included in the contractual obligation table above.

[0001032975-19-000027:mdna:234]
Indemnifications

[0001032975-19-000027:mdna:235]
We indemnify certain of our suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys' fees. As of March 31, 2019, no amounts have been accrued for indemnification provisions. We do not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under our indemnification arrangements.

[0001032975-19-000027:mdna:236]
We also indemnify our current and former directors and certain of our current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. We are unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not capped, the obligations are conditional in nature, and the facts and circumstances involved in any situation that might arise are variable.

[0001032975-19-000027:mdna:237]
Off-Balance Sheet Arrangements

[0001032975-19-000027:mdna:238]
We do not have any off-balance sheet arrangements that have, or are reasonably likely to have, a current or future effect on our financial condition, changes in financial condition, revenues or expenses, results of operations, liquidity, capital expenditures or capital resources that are material to investors.
