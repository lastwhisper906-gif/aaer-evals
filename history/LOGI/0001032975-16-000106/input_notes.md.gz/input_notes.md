# LOGI notes — 0001032975-16-000106


## logi:ScheduleOfBalanceSheetComponentsAssetsTableTextBlock

[0001032975-16-000106:notes:1]
The following table presents the components of certain balance sheet asset amounts as of September 30 and March 31, 2016 (in thousands):

[0001032975-16-000106:notes:2]
|  |  | September 30,2016 |  | March 31,2016 |
| Accounts receivable, net: |  |  |  |  |  |  |
| Accounts receivable |  | $ | 446,430 |  |  | $ | 332,553 |  |
| Allowance for doubtful accounts |  | (805 | ) |  | (667 | ) |
| Allowance for sales returns |  | (22,090 | ) |  | (18,526 | ) |
| Allowance for cooperative marketing arrangements |  | (30,969 | ) |  | (28,157 | ) |
| Allowance for customer incentive programs |  | (57,472 | ) |  | (60,872 | ) |
| Allowance for pricing programs |  | (94,488 | ) |  | (81,553 | ) |
|  |  | $ | 240,606 |  |  | $ | 142,778 |  |
| Inventories: |  |  |  |  |  |  |
| Raw materials |  | $ | 35,805 |  |  | $ | 48,489 |  |
| Finished goods |  | 232,305 |  |  | 180,297 |  |
|  |  | $ | 268,110 |  |  | $ | 228,786 |  |
| Other current assets: |  |  |  |  |  |  |
| Income tax and value-added tax receivables |  | $ | 21,184 |  |  | $ | 22,572 |  |
| Prepaid expenses and other assets |  | 19,017 |  |  | 12,916 |  |
|  |  | $ | 40,201 |  |  | $ | 35,488 |  |
| Property, plant and equipment, net: |  |  |  |  |  |  |
| Property, plant and equipment at cost |  | $ | 376,287 |  |  | 371,212 |  |
| Less: accumulated depreciation and amortization |  | (291,490 | ) |  | (278,352 | ) |
|  |  | $ | 84,797 |  |  | $ | 92,860 |  |
| Other assets: |  |  |  |  |  |  |
| Deferred tax assets |  | $ | 54,187 |  |  | $ | 56,208 |  |
| Trading investments for deferred compensation plan |  | 14,826 |  |  | 14,836 |  |
| Investments held in privately held companies |  | 9,900 |  |  | 9,247 |  |
| Other assets |  | 5,604 |  |  | 6,525 |  |
|  |  | $ | 84,517 |  |  | $ | 86,816 |  |


## logi:ScheduleOfBalanceSheetComponentsLiabilityTableTextBlock

[0001032975-16-000106:notes:3]
The following table presents the components of certain balance sheet liability amounts as of September 30 and March 31, 2016 (in thousands):

[0001032975-16-000106:notes:4]
|  |  | September 30,2016 |  | March 31,2016 |
| Accrued and other current liabilities: |  |  |  |  |  |  |
| Accrued personnel expenses |  | $ | 64,163 |  |  | $ | 46,025 |  |
| Indirect customer incentive programs |  | 32,666 |  |  | 28,721 |  |
| Warranty accrual |  | 13,528 |  |  | 11,880 |  |
| Employee benefit plan obligation |  | 1,738 |  |  | 1,285 |  |
| Income taxes payable |  | 2,606 |  |  | 1,553 |  |
| Contingent consideration for business acquisition - current portion |  | 13,494 |  |  | — |  |
| Other current liabilities |  | 85,715 |  |  | 84,300 |  |
|  |  | $ | 213,910 |  |  | $ | 173,764 |  |
| Non-current liabilities: |  |  |  |  |  |  |
| Warranty accrual |  | $ | 8,084 |  |  | $ | 8,500 |  |
| Obligation for deferred compensation plan |  | 14,826 |  |  | 14,836 |  |
| Employee benefit plan obligation |  | 53,335 |  |  | 53,909 |  |
| Deferred rent |  | 8,656 |  |  | 9,424 |  |
| Deferred tax liability |  | 1,665 |  |  | 1,665 |  |
| Contingent consideration for business acquisition - non-current portion |  | 4,506 |  |  | — |  |
| Other non-current liabilities |  | 1,341 |  |  | 1,201 |  |
|  |  | $ | 92,413 |  |  | $ | 89,535 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001032975-16-000106:notes:5]
[same as prior period, unchanged from 0001032975-16-000097:notes:6]

[0001032975-16-000106:notes:6]
[same as prior period, unchanged from 0001032975-16-000097:notes:7]

[0001032975-16-000106:notes:7]
[same as prior period, unchanged from 0001032975-16-000097:notes:8]

[0001032975-16-000106:notes:8]
[same as prior period, unchanged from 0001032975-16-000097:notes:9]

[0001032975-16-000106:notes:9]
Logitech was founded in Switzerland in 1981 and Logitech International S.A. has been the parent holding company of Logitech since 1988. Logitech International S.A. is a Swiss holding company with its registered office in Apples, Switzerland, which conducts its business through subsidiaries in the Americas, Europe, Middle East and Africa ("EMEA"), and Asia Pacific. Shares of Logitech International S.A. are listed on both the SIX Swiss Exchange under the trading symbol LOGN and the Nasdaq Global Select Market under the trading symbol LOGI.

[0001032975-16-000106:notes:10]
[same as prior period, unchanged from 0001032975-16-000097:notes:11]

[0001032975-16-000106:notes:11]
[same as prior period, unchanged from 0001032975-16-000097:notes:12]

[0001032975-16-000106:notes:12]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and six months ended September 30, 2016 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2017, or any future periods.

[0001032975-16-000106:notes:13]
[same as prior period, unchanged from 0001032975-16-000097:notes:14]

[0001032975-16-000106:notes:14]
Certain amounts from the comparative period in the accompanying unaudited condensed consolidated financial statements have been reclassified to conform to the condensed consolidated financial statement presentation as of and for the three and six months ended September 30, 2016.

[0001032975-16-000106:notes:15]
[same as prior period, unchanged from 0001032975-16-000097:notes:16]

[0001032975-16-000106:notes:16]
There have been no substantial changes in the Company’s significant accounting policies during the six months ended September 30, 2016 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2016.

[0001032975-16-000106:notes:17]
[same as prior period, unchanged from 0001032975-16-000097:notes:18]

[0001032975-16-000106:notes:18]
The preparation of financial statements in conformity with GAAP requires management to make judgments, estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Examples of significant estimates and assumptions made by management involve the fair value of goodwill, intangible assets acquired from business acquisitions, warranty liabilities, accruals for discretionary customer programs, sales return reserves, allowance for doubtful accounts, inventory valuation, restructuring charges, contingent consideration from business acquisitions and periodical reassessment of its fair value, share-based compensation expense, uncertain tax positions, and valuation allowances for deferred tax assets. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ materially from those estimates.

[0001032975-16-000106:notes:19]
[same as prior period, unchanged from 0001032975-16-000097:notes:20]

[0001032975-16-000106:notes:20]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-9, "Revenue from Contracts with Customers (Topic 606)" ("ASU 2014-9"). ASU 2014-9 outlines a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. Under the new model, recognition of revenue occurs when a customer obtains control of promised goods or services in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. In addition, the new standard requires that reporting companies disclose the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. ASU 2014-09 was originally to be effective for the Company on April 1, 2017. In July 2015, the FASB affirmed a one-year deferral of the effective date of the new revenue standard. The new standard will become effective for the Company on April 1, 2018. Early application is permitted but not before the original effective date of annual periods beginning after December 15, 2016. The new standard is required to be applied retrospectively to each prior reporting period presented or retrospectively with the cumulative effect of initially applying it recognized at the date of initial application. The Company has not yet selected a transition method nor has it determined whether it will early adopt this guidance or the impact of the new standard on its condensed consolidated financial statements.

[0001032975-16-000106:notes:21]
In July 2015, the FASB issued ASU No. 2015-11, "Simplifying the Measurement of Inventory (Topic 330)" ("ASU 2015-11"). Topic 330, Inventory, currently requires an entity to measure inventory at the lower of cost or market, with market value represented by replacement cost, net realizable value or net realizable value less a normal profit margin. The amendments in ASU 2015-11 require an entity to measure inventory at the lower of cost or net realizable value. ASU 2015-11 is effective in the first quarter of fiscal year 2018 for the Company, with early adoption permitted. The Company does not expect to early adopt this guidance and does not expect the adoption of this guidance to have a material impact on its condensed consolidated financial statements.

[0001032975-16-000106:notes:22]
In January 2016, the FASB issued ASU 2016-01 “Financial Instruments- Recognition and Measurement of Financial Assets and Financial Liabilities (Subtopic 825-10)”. The guidance is effective in the first quarter of fiscal year 2018 for the Company, with early adoption permitted. The Company does not expect to early adopt this guidance and does not believe that the adoption of this guidance will have a material impact on its condensed consolidated financial statements.

[0001032975-16-000106:notes:23]
In February 2016, the FASB issued ASU 2016-02 "Leases (Topic 842)" ("ASU 2016-02"), which requires the recognition of lease assets and lease liabilities arising from operating leases in the statement of financial position. This guidance is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. The Company is evaluating the full effect that ASU 2016-02 will have on its condensed consolidated financial statements and will adopt the standard effective April 1, 2019.

[0001032975-16-000106:notes:24]
In March 2016, the FASB issued ASU 2016-09 "Compensation-Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting" ("ASU 2016-09"). The amendment simplifies several aspects of the accounting for share-based payments, including immediate recognition of all excess tax benefits and deficiencies in the income statement, changing the threshold to qualify for equity classification up to the employees' maximum statutory tax rates, allowing an entity-wide accounting policy election to either estimate the number of awards that are expected to vest or account for forfeitures as they occur, and clarifying the classification on the statement of cash flows for the excess tax benefit and employee taxes paid when an employer withholds shares for tax-withholding purposes. ASU 2016-09 is effective for annual periods beginning after December 15, 2016, and interim periods within those annual periods. Early adoption is permitted in any interim or annual period. The Company is evaluating the effect that ASU 2016-09 will have on its condensed consolidated financial statements and the timing of the adoption of this standard.

[0001032975-16-000106:notes:25]
In August 2016, the FASB issued ASU 2016-15 "Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments". The amendment gives guidance and reduces diversity in practice with respect to certain types of cash flows. The Company has early adopted this guidance during the second quarter of fiscal year 2017 and the adoption did not impact its consolidated financial statements.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001032975-16-000106:notes:26]
Business Acquisitions

[0001032975-16-000106:notes:27]
Jaybird Acquisition

[0001032975-16-000106:notes:28]
On April 20, 2016 ("Acquisition Date"), the Company acquired all of the equity interest of JayBird, LLC (“Jaybird”), a Utah limited liability company that develops Bluetooth earbuds, activity trackers, and accessories for sports and active lifestyles, for a purchase price of $54.2 million in cash, including a working capital adjustment and payment of a line-of-credit on behalf of Jaybird, with an additional earn-out of up to $45.0 million based on the achievement of certain net revenue growth targets over approximately a two year period (the "Jaybird Acquisition").  If the net revenue growth targets are met, the Company will pay $25.0 million and $20.0 million in fiscal years 2018 and 2019, respectively. The Jaybird Acquisition is expected to accelerate the Company's entry into the wireless wearables space.

[0001032975-16-000106:notes:29]
The Jaybird transaction meets the definition of a business and is accounted for using the acquisition method. The fair value of consideration transferred for the Jaybird Acquisition consists of the following (in thousands):

[0001032975-16-000106:notes:30]
[same as prior period, unchanged from 0001032975-16-000097:notes:29]

[0001032975-16-000106:notes:31]
The fair value of the earn-out payments at the Acquisition Date was determined by providing risk adjusted earnings projections using a Monte Carlo Simulation, which includes inputs that are not observable in the market, and therefore representing a Level 3 measurement. The fair value of this earn-out is discussed further in "Note 8 - Fair Value Measurements" to the condensed consolidated financial statements.

[0001032975-16-000106:notes:32]
The following table summarizes the estimated fair values of the assets acquired and liabilities assumed at the Acquisition Date (in thousands):

[0001032975-16-000106:notes:33]
[same as prior period, unchanged from 0001032975-16-000097:notes:32]

[0001032975-16-000106:notes:34]
Goodwill is primarily attributable to opportunities and economies of scale from combining the operations and technologies of Logitech and Jaybird. Goodwill is expected to be deductible for tax purposes.

[0001032975-16-000106:notes:35]
Inventory is estimated at net realizable value, which uses the estimated selling prices, less the cost of disposal and a reasonable profit allowance for the selling efforts. Upon sales of the inventory, the difference between the fair value of the inventories and the amount recognized by the acquiree immediately before the acquisition date, which is $0.7 million, is recognized in "amortization of intangibles assets and purchase accounting effect on inventory" in the condensed consolidated statements of operations.

[0001032975-16-000106:notes:36]
The Company included Jaybird's estimated fair value of assets acquired and liabilities assumed in its condensed consolidated balance sheets beginning April 20, 2016. The results of operations for Jaybird have been included in the Company's condensed consolidated statements of operations from the acquisition date. For the three and six months ended September 30, 2016, Jaybird contributed $15.6 million and $29.9 million of net sales, respectively.

[0001032975-16-000106:notes:37]
The following table sets forth the components of identifiable intangible assets acquired at their estimated fair values and their estimated useful lives as of the Acquisition Date (Dollars in thousands):

[0001032975-16-000106:notes:38]
[same as prior period, unchanged from 0001032975-16-000097:notes:39]

[0001032975-16-000106:notes:39]
Except for IPR&D, intangible assets acquired as a result of the Jaybird Acquisition are being amortized over their estimated useful lives using the straight-line method of amortization. Amortization of developed technology of $1.2 million and $2.1 million, respectively, during the three and six months ended September 30, 2016 is included in "Amortization of intangible assets and purchase accounting effect of inventory" in the gross profit of the condensed consolidated statements of operations. Amortization of the intangible assets of customer relationship and trade name of $1.0 million and $1.8 million, respectively, during the three and six months ended September 30, 2016 is included in "amortization of intangible assets and acquisition-related costs" in the operating expense of the condensed consolidated statements of operations.

[0001032975-16-000106:notes:40]
Developed technology relates to existing bluetooth wireless sports earbuds. The economic useful life was determined based on the technology cycle related to developed technology of existing products, as well as the cash flows anticipated over the forecasted periods.

[0001032975-16-000106:notes:41]
[same as prior period, unchanged from 0001032975-16-000097:notes:42]

[0001032975-16-000106:notes:42]
[same as prior period, unchanged from 0001032975-16-000097:notes:43]

[0001032975-16-000106:notes:43]
The value of developed technology and trade names was estimated using the relief-from-royalty method, an income approach (Level 3), which estimates the cost savings that accrue to the owner of the intangible assets that would otherwise be payable as royalties or license fees on revenues earned through the use of the asset. A royalty rate is applied to the projected revenues associated with the intangible assets to determine the amount of savings, which is then discounted to determine the fair value. The developed technology and trade names were valued using royalty rates of 10% and 2.5%, respectively, and both were discounted at a rate of 16%.

[0001032975-16-000106:notes:44]
[same as prior period, unchanged from 0001032975-16-000097:notes:45]

[0001032975-16-000106:notes:45]
The IPR&D is accounted for as an indefinite-lived intangible asset and is not amortized until completion or abandonment of the associated research and development efforts. If the research and development efforts are completed, the IPR&D intangible asset will be amortized over the estimated useful life to be determined as of the date the efforts are completed.  IPR&D is tested for impairment annually or periodically if an indicator of impairment exists during the period until completion. The expected release date of the IPR&D is during the period from fiscal year 2017 to fiscal year 2018.

[0001032975-16-000106:notes:46]
[same as prior period, unchanged from 0001032975-16-000097:notes:47]

[0001032975-16-000106:notes:47]
Saitek Acquisition

[0001032975-16-000106:notes:48]
On September 15, 2016, the Company completed the acquisition of the Saitek product line for a total cash consideration of approximately $13.0 million (the "Saitek Acquisition"). Out of the total consideration, $6.7 million was attributed to intangible assets, $4.9 million was attributed to goodwill, and $1.4 million was attributed to net tangible assets acquired. The Saitek Acquisition is expected to enhance the breadth and depth of the Company's product offerings and expand the Company's engineering capabilities in simulation products. The amount of goodwill generated from the Saitek Acquisition is deductible for tax purposes and is not material.  The Company did not generate any revenue from the Saitek product line during the reporting period.

[0001032975-16-000106:notes:49]
The Company incurred acquisition-related costs for both the Jaybird Acquisition and the Saitek Acquisition of approximately $0.8 million and $1.2 million, in aggregate, for the three and six months ended September 30, 2016, respectively. The acquisition-related costs are included in "amortization of intangible assets and acquisition-related costs" in the operating expense of the condensed consolidated statements of operations.

[0001032975-16-000106:notes:50]
Pro forma results of operations for both the Jaybird Acquisition and the Saitek Acquisition have not been presented because they are not material to the condensed consolidated statements of operations individually or in aggregate.

[0001032975-16-000106:notes:51]
The fair value of identifiable intangible assets acquired was based on estimates and assumptions made by management at the time of the acquisitions. As additional information becomes available, such as finalization of the estimated fair value of the assets acquired and liabilities assumed and the fair value of contingent consideration, the Company may revise its preliminary purchase price allocations during the remainder of the measurement periods (which will not exceed 12 months from the acquisition dates). Any such revisions or changes may be material as we finalize the fair values of the tangible and intangible assets acquired and liabilities assumed.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001032975-16-000106:notes:52]
Commitments and Contingencies

[0001032975-16-000106:notes:53]
Product Warranties

[0001032975-16-000106:notes:54]
All of the Company’s peripherals products sold are covered by warranty to be free from defects in material and workmanship.  For products launched prior to April 1, 2014, the standard warranty period was up to five years. Starting from April 1, 2014, the standard warranty for all new products launched was changed to two years from date of purchase for European Countries and generally one year from date of purchase for all other countries.  At the time of sale, the Company accrues a warranty liability for estimated costs to provide products, parts or services to repair or replace products in satisfaction of the warranty obligation. The Company’s estimate of costs to fulfill its warranty obligations is based on historical experience and expectations of future conditions. When the Company experiences changes in warranty claim activity or costs associated with fulfilling those claims, the warranty liability is adjusted accordingly.

[0001032975-16-000106:notes:55]
Changes in the Company’s warranty liability for the three and six months ended September 30, 2016 and 2015 were as follows (in thousands):

[0001032975-16-000106:notes:56]
|  | Three Months EndedSeptember 30, |  | Six Months Ended September 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Beginning of the period | $ | 21,752 |  |  | $ | 21,284 |  |  | $ | 20,380 |  |  | $ | 21,710 |  |
| Assumed from business acquisition | 150 |  |  | — |  |  | 1,963 |  |  | — |  |
| Provision | 3,163 |  |  | 1,879 |  |  | 6,340 |  |  | 3,792 |  |
| Settlements | (3,452 | ) |  | (2,677 | ) |  | (6,880 | ) |  | (5,245 | ) |
| Currency impact | (1 | ) |  | (87 | ) |  | (191 | ) |  | 142 |  |
| End of the period | $ | 21,612 |  |  | $ | 20,399 |  |  | $ | 21,612 |  |  | $ | 20,399 |  |

[0001032975-16-000106:notes:57]
Other Contingencies

[0001032975-16-000106:notes:58]
In April 2016, the Company entered into a settlement with the SEC related to the accounting for Revue inventory valuation reserves that resulted in the restatement described in the Fiscal Year 2014 Annual Report on Form 10-K, revision to its consolidated financial statements concerning warranty accruals and amortization of intangible assets presented in its Amended Annual Report on Form 10-K/A, filed on August 7, 2013, and its transactions with a distributor for Fiscal Year 2007 through Fiscal Year 2009. The Company entered into the settlement without admitting or denying the findings of the SEC’s investigation and paid a civil penalty of $7.5 million in April 2016.

[0001032975-16-000106:notes:59]
Guarantees

[0001032975-16-000106:notes:60]
Logitech Europe S.A. guaranteed payments of certain third-party contract manufacturers’ purchase obligations. As of September 30, 2016, the maximum amount of this guarantee was $3.8 million, of which $1.9 million of guaranteed purchase obligations were outstanding.

[0001032975-16-000106:notes:61]
Indemnifications

[0001032975-16-000106:notes:62]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of September 30, 2016, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

[0001032975-16-000106:notes:63]
The Company also indemnifies its current and former directors and certain of its current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. The Company is unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not limited, the obligations are conditional in nature and the facts and circumstances involved in any situation that might arise are variable.

[0001032975-16-000106:notes:64]
The Stock Purchase Agreement in connection with the investment by three venture capital firms in Lifesize, Inc. contains representations, warranties and covenants of Logitech and Lifesize, Inc. to the Investors. Logitech has agreed, subject to certain limitations, to indemnify the Investors and certain persons related to the Investors for certain losses resulting from breaches of or inaccuracies in such representations, warranties and covenants as well as certain other obligations, including third-party expenses, restructuring costs and pre-closing tax obligations of Lifesize.

[0001032975-16-000106:notes:65]
Legal Proceedings

[0001032975-16-000106:notes:66]
From time to time the Company is involved in claims and legal proceedings that arise in the ordinary course of its business. The Company is currently subject to several such claims and a small number of legal proceedings. The Company believes that these matters lack merit and intends to vigorously defend against them. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company’s defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company’s business, financial condition, cash flows or results of operations in a particular period. Any claims or proceedings against the Company, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company’s business.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001032975-16-000106:notes:67]
[same as prior period, unchanged from 0001032975-16-000097:notes:63]

[0001032975-16-000106:notes:68]
[same as prior period, unchanged from 0001032975-16-000097:notes:64]

[0001032975-16-000106:notes:69]
As of September 30, 2016, the Company offers the 2006 ESPP (2006 Employee Share Purchase Plan (Non-U.S.)), the 1996 ESPP (1996 Employee Share Purchase Plan (U.S.)), the 2006 Plan (2006 Stock Incentive Plan) and the 2012 Plan (2012 Stock Inducement Equity Plan).

[0001032975-16-000106:notes:70]
The following table summarizes the share-based compensation expense and related tax benefit recognized for the three and six months ended September 30, 2016 and 2015, excluding balances classified as discontinued operations (in thousands):

[0001032975-16-000106:notes:71]
|  |  | Three Months EndedSeptember 30, |  | Six Months Ended September 30, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Cost of goods sold |  | $ | 638 |  |  | $ | 580 |  |  | $ | 1,313 |  |  | $ | 1,185 |  |
| Marketing and selling |  | 3,244 |  |  | 1,997 |  |  | 6,681 |  |  | 4,061 |  |
| Research and development |  | 917 |  |  | 655 |  |  | 1,831 |  |  | 1,328 |  |
| General and administrative |  | 3,651 |  |  | 3,074 |  |  | 7,142 |  |  | 6,248 |  |
| Restructuring |  | — |  |  | — |  |  | — |  |  | 7 |  |
| Total share-based compensation expense |  | 8,450 |  |  | 6,306 |  |  | 16,967 |  |  | 12,829 |  |
| Income tax benefit |  | (1,886 | ) |  | (1,160 | ) |  | (3,701 | ) |  | (2,497 | ) |
| Total share-based compensation expense, net of income tax |  | $ | 6,564 |  |  | $ | 5,146 |  |  | $ | 13,266 |  |  | $ | 10,332 |  |

[0001032975-16-000106:notes:72]
As of September 30, 2016 and 2015, the Company capitalized $0.4 million of stock-based compensation expenses as inventory.

[0001032975-16-000106:notes:73]
[same as prior period, unchanged from 0001032975-16-000097:notes:69]

[0001032975-16-000106:notes:74]
Certain of the Company’s subsidiaries sponsor defined benefit pension plans or non-retirement post-employment benefits covering substantially all of their employees. Benefits are provided based on employees’ years of service and earnings, or in accordance with applicable employee benefit regulations. The Company’s practice is to fund amounts sufficient to meet the requirements set forth in the applicable employee benefit and tax regulations. The cost recorded of $2.8 million and $2.9 million for the three months ended September 30, 2016 and 2015, respectively, and $5.6 million and $5.8 million for the six months ended September 30, 2016 and 2015, respectively, was primarily related to service costs.


## us-gaap:DebtDisclosureTextBlock

[0001032975-16-000106:notes:75]
Financing Arrangements

[0001032975-16-000106:notes:76]
The Company had several uncommitted, unsecured bank lines of credit aggregating $44.6 million as of September 30, 2016. There are no financial covenants under these lines of credit with which the Company must comply. As of September 30, 2016, the Company had outstanding bank guarantees of $12.4 million under these lines of credit. There was no borrowing outstanding under these lines of credit as of September 30, 2016 or March 31, 2016.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001032975-16-000106:notes:77]
[same as prior period, unchanged from 0001032975-16-000097:notes:73]

[0001032975-16-000106:notes:78]
Under certain agreements with the respective counterparties to the Company’s derivative contracts, subject to applicable requirements, the Company is allowed to net settle transactions of the same type with a single net amount payable by one party to the other. However, the Company presents its derivative assets and derivative liabilities on a gross basis on the condensed consolidated balance sheets as of September 30, 2016 and March 31, 2016.

[0001032975-16-000106:notes:79]
The fair values of the Company’s derivative instruments not designated as hedging instruments were not material as of September 30, 2016 or March 31, 2016. The following table presents the fair values of the Company’s derivative instruments designated as hedging instruments on a gross basis in other current assets or accrued and other current liabilities on its condensed consolidated balance sheets as of September 30, 2016 and March 31, 2016 (in thousands):

[0001032975-16-000106:notes:80]
|  |  | Derivatives |
|  |  | Asset |  | Liability |
|  |  | September 30,2016 |  | March 31,2016 |  | September 30,2016 |  | March 31,2016 |
| Cash flow hedges |  | $ | 909 |  |  | $ | 10 |  |  | $ | — |  |  | $ | 1,038 |  |

[0001032975-16-000106:notes:81]
The amount of gain (loss) recognized on derivatives not designated as hedging instruments were not material in all periods presented herein. The following table presents the amounts of gains (losses) on the Company’s derivative instruments designated as hedging instruments and their locations on its condensed consolidated statements of operations and condensed consolidated statements of comprehensive income for the three and six months ended September 30, 2016 and 2015 (in thousands):

[0001032975-16-000106:notes:82]
|  |  | Three Months EndedSeptember 30, |
|  |  | Amount of Gain (Loss)Deferred as a Component of AccumulatedOther Comprehensive Loss After Reclassification to Costs of Goods Sold |  | Amount of Loss (Gain) Reclassified from Accumulated Other Comprehensive Loss to Costs of Goods Sold |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Cash flow hedges |  | $ | 719 |  |  | $ | 1,060 |  |  | $ | 155 |  |  | $ | (28 | ) |

[0001032975-16-000106:notes:83]
|  |  | Six Months Ended September 30, |
|  |  | Amount of Gain (Loss)Deferred as a Component of AccumulatedOther Comprehensive Loss After Reclassification to Costs of Goods Sold |  | Amount of Loss (Gain) Reclassified from Accumulated Other Comprehensive Loss to Costs of Goods Sold |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Cash flow hedges |  | $ | 2,424 |  |  | $ | (3,662 | ) |  | $ | 895 |  |  | $ | (2,488 | ) |

[0001032975-16-000106:notes:84]
[same as prior period, unchanged from 0001032975-16-000097:notes:79]

[0001032975-16-000106:notes:85]
The Company enters into currency exchange forward contracts to hedge against exposure to changes in currency exchange rates related to its subsidiaries’ forecasted inventory purchases. The Company has one entity with a Euro functional currency that purchases inventory in U.S. Dollars. The primary risk managed by using derivative instruments is the currency exchange rate risk. However, there can be no assurance the hedges will offset more than a portion of the financial impact resulting from movements in currency exchange rates. The Company has designated these derivatives as cash flow hedges. These hedging contracts mature within four months, and are denominated in the same currency as the underlying transactions. Gains and losses in the fair value of the effective portion of the hedges are deferred as a component of accumulated other comprehensive loss until the hedged inventory purchases are sold, at which time the gains or losses are reclassified to cost of goods sold. The Company assesses the effectiveness of the hedges by comparing changes in the spot rate of the currency underlying the forward contract with changes in the spot rate of the currency in which the forecasted transaction will be consummated. If the underlying transaction being hedged fails to occur or if a portion of the hedge does not generate offsetting changes in the currency exposure of forecasted inventory purchases, the Company immediately recognizes the gain or loss on the associated financial instrument in other expense, net. Such gains and losses were not material during the three and six months ended September 30, 2016 and 2015. Cash flows from such hedges are classified as operating activities in the condensed consolidated statements of cash flows. The notional amounts of currency exchange forward contracts outstanding related to forecasted inventory purchases were $76.9 million and $39.8 million at September 30, 2016 and March 31, 2016, respectively. The Company estimates that $0.6 million of net gains related to its cash flow hedges included in accumulated other comprehensive loss as of September 30, 2016 will be reclassified into earnings within the next 12 months.

[0001032975-16-000106:notes:86]
[same as prior period, unchanged from 0001032975-16-000097:notes:81]

[0001032975-16-000106:notes:87]
[same as prior period, unchanged from 0001032975-16-000097:notes:82]

[0001032975-16-000106:notes:88]
The notional amounts of currency exchange forward and swap contracts outstanding as of September 30 and March 31, 2016 relating to foreign currency receivables or payables were $56.7 million and $63.7 million, respectively. Open forward and swap contracts outstanding as of September 30, 2016 and March 31, 2016 consisted of contracts in Mexican Pesos, Japanese Yen, British Pounds, Taiwanese Dollars and Australian Dollars to be settled at future dates at pre-determined exchange rates.

[0001032975-16-000106:notes:89]
[same as prior period, unchanged from 0001032975-16-000097:notes:84]


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001032975-16-000106:notes:90]
[same as prior period, unchanged from 0001032975-16-000097:notes:85]

[0001032975-16-000106:notes:91]
During the third quarter of fiscal year 2016, the Company's Board of Directors approved a plan to divest the Lifesize video conferencing business. Subsequently, on December 28, 2015 in the fourth quarter of fiscal year 2016, the Company and Lifesize, Inc.(“Lifesize”), a wholly owned subsidiary of the Company which held the assets of the Company’s video conferencing reportable segment, entered into a stock purchase agreement (the “Stock Purchase Agreement”) with entities affiliated with three venture capital firms - Redpoint Ventures, Sutter Hill Ventures and Meritech Capital Partners (the "Venture Investors").  Pursuant to the terms of the Stock Purchase Agreement, the Company sold 2.5 million shares of Series B Preferred Stock of Lifesize to the Venture Investors for cash proceeds of $2.5 million and retained 12 million non-voting shares of Series A Preferred Stock of Lifesize.  The shares of Series A Preferred Stock of Lifesize retained by the Company represent 37.5% of the total shares outstanding immediately after the closing of the transactions (the "Closing").  Lifesize also issued 17.5 million shares of Series B Preferred Stock to the Venture Investors for cash proceeds of $17.5 million. The shares of Series B Preferred Stock held by the Venture Investors represent 62.5% of the total shares outstanding immediately after the Closing.  In addition, Lifesize reserved 8 million shares of common stock for issuance pursuant to a stock plan to be adopted by Lifesize following the Closing, none of which are issued or outstanding at the Closing. The divestiture of the Lifesize video conferencing business was effective on December 28, 2015. The Stock Purchase Agreement contains representations, warranties and covenants of the parties and includes certain indemnification obligations of the Company to the Venture Investors. See “Note 12 - Commitments and Contingencies” to the condensed consolidated financial statements for more information. The Stock Purchase Agreement also contains certain post-closing working capital adjustments. Post-closing continuing involvement with the discontinued operations includes certain customary services and support which are expected to be provided to Lifesize during the transition period from December 28, 2015 until approximately the end of the third quarter of fiscal year 2017.

[0001032975-16-000106:notes:92]
[same as prior period, unchanged from 0001032975-16-000097:notes:87]

[0001032975-16-000106:notes:93]
[same as prior period, unchanged from 0001032975-16-000097:notes:88]

[0001032975-16-000106:notes:94]
The following table presents financial results of the video conferencing segment classified as total discontinued operations for the three and six months ended September 30, 2015 (in thousands):

[0001032975-16-000106:notes:95]
|  |  | Three Months EndedSeptember 30, |  | Six Months Ended September 30, |
|  |  | 2015 |  | 2015 |
| Net sales |  | $ | 21,368 |  |  | $ | 44,002 |  |
| Cost of goods sold |  | 7,874 |  |  | 16,712 |  |
| Gross profit |  | 13,494 |  |  | 27,290 |  |
| Operating expenses: |  |  |  |  |  |  |
| Marketing and selling |  | 11,044 |  |  | 22,675 |  |
| Research and development |  | 6,005 |  |  | 11,668 |  |
| General and administrative |  | 1,777 |  |  | 3,469 |  |
| Restructuring charges, net |  | 5,550 |  |  | 7,007 |  |
| Total operating expenses |  | 24,376 |  |  | 44,819 |  |
| Operating loss from discontinued operations |  | (10,882 | ) |  | (17,529 | ) |
| Interest expense and other expense, net |  | (40 | ) |  | (133 | ) |
| Loss from discontinued operations before income taxes |  | (10,922 | ) |  | (17,662 | ) |
| Provision for income taxes |  | 1,433 |  |  | 116 |  |
| Net loss from discontinued operations |  | $ | (12,355 | ) |  | $ | (17,778 | ) |


## us-gaap:EarningsPerShareTextBlock

[0001032975-16-000106:notes:96]
[same as prior period, unchanged from 0001032975-16-000097:notes:91]

[0001032975-16-000106:notes:97]
[same as prior period, unchanged from 0001032975-16-000097:notes:92]

[0001032975-16-000106:notes:98]
|  |  | Three Months EndedSeptember 30, |  | Six Months Ended September 30, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Net Income (loss): |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 47,045 |  |  | $ | 30,452 |  |  | $ | 68,986 |  |  | $ | 43,312 |  |
| Discontinued operations |  | — |  |  | (12,355 | ) |  | — |  |  | (17,778 | ) |
| Net income |  | $ | 47,045 |  |  | $ | 18,097 |  |  | $ | 68,986 |  |  | $ | 25,534 |  |
| Shares used in net income (loss) per share computation: |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding - basic |  | 162,222 |  |  | 163,515 |  |  | 162,176 |  |  | 163,957 |  |
| Effect of potentially dilutive equivalent shares |  | 3,327 |  |  | 2,326 |  |  | 2,750 |  |  | 2,395 |  |
| Weighted average shares outstanding - diluted |  | 165,549 |  |  | 165,841 |  |  | 164,926 |  |  | 166,352 |  |
| Net income (loss) per share - basic: |  |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.29 |  |  | $ | 0.19 |  |  | $ | 0.43 |  |  | $ | 0.26 |  |
| Discontinued operations |  | — |  |  | (0.08 | ) |  | — |  |  | (0.10 | ) |
| Net income per share - basic |  | $ | 0.29 |  |  | $ | 0.11 |  |  | $ | 0.43 |  |  | $ | 0.16 |  |
| Net income (loss) per share - diluted: |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.28 |  |  | $ | 0.18 |  |  | $ | 0.42 |  |  | $ | 0.26 |  |
| Discontinued operations |  | — |  |  | (0.07 | ) |  | — |  |  | (0.11 | ) |
| Net income per share - diluted |  | $ | 0.28 |  |  | $ | 0.11 |  |  | $ | 0.42 |  |  | $ | 0.15 |  |

[0001032975-16-000106:notes:99]
Share equivalents attributable to outstanding stock options and restricted stock units ("RSUs") of 2.9 million and 7.8 million for the three months ended September 30, 2016 and 2015, respectively, and 3.1 million and 7.6 million for the six months ended September 30, 2016 and 2015, respectively, were anti-dilutive and excluded from the calculation of diluted net income per share.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001032975-16-000106:notes:100]
[same as prior period, unchanged from 0001032975-16-000097:notes:95]

[0001032975-16-000106:notes:101]
[same as prior period, unchanged from 0001032975-16-000097:notes:96]

[0001032975-16-000106:notes:102]
[same as prior period, unchanged from 0001032975-16-000097:notes:97]

[0001032975-16-000106:notes:103]
[same as prior period, unchanged from 0001032975-16-000097:notes:98]

[0001032975-16-000106:notes:104]
[same as prior period, unchanged from 0001032975-16-000097:notes:99]

[0001032975-16-000106:notes:105]
The following table presents the Company’s financial assets and liabilities that were accounted for at fair value on a recurring basis, excluding assets related to the Company’s defined benefit pension plans, classified by the level within the fair value hierarchy (in thousands):

[0001032975-16-000106:notes:106]
|  |  | September 30, 2016 |  | March 31, 2016 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Level 1 |  | Level 2 |  | Level 3 |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 100,742 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,000 |  |  | $ | — |  |  | $ | — |  |
| Trading investments for deferred compensation plan: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 3,051 |  |  | $ | — |  |  | $ | — |  |  | $ | 3,467 |  |  | $ | — |  |  | $ | — |  |
| Mutual funds |  | 11,775 |  |  | — |  |  | — |  |  | 11,369 |  |  | — |  |  | — |  |
| Total of trading investments for deferred compensation plan |  | $ | 14,826 |  |  | $ | — |  |  | $ | — |  |  | $ | 14,836 |  |  | $ | — |  |  | $ | — |  |
| Currency exchange derivative assets |  | $ | — |  |  | $ | 909 |  |  | $ | — |  |  | $ | — |  |  | $ | 10 |  |  | $ | — |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisition-related contingent consideration |  | $ | — |  |  | $ | — |  |  | $ | 18,000 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Currency exchange derivative liabilities |  | $ | — |  |  | $ | 41 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,132 |  |  | $ | — |  |

[0001032975-16-000106:notes:107]
[same as prior period, unchanged from 0001032975-16-000097:notes:102]

[0001032975-16-000106:notes:108]
The marketable securities for the Company's deferred compensation plan are recorded at a fair value of $14.8 million as of September 30, 2016 and March 31, 2016, based on quoted market prices. Quoted market prices are observable inputs that are classified as Level 1 within the fair value hierarchy. Unrealized trading gains / (losses) related to trading securities for the three or six months ended September 30, 2016 and 2015 were not material and are included in "other expense, net" in the Company's condensed consolidated statements of operations.

[0001032975-16-000106:notes:109]
[same as prior period, unchanged from 0001032975-16-000097:notes:104]

[0001032975-16-000106:notes:110]
The acquisition-related contingent consideration liability arising from the Jaybird Acquisition (see "Note 3 - Business Acquisitions" to the condensed consolidated financial statements for more information) represents the future potential earn-out payments of up to $45 million based on the achievement of certain net revenue growth targets over approximately a two year period. If the net revenue growth targets are met, the Company will pay $25 million and $20 million in fiscal years 2018 and 2019, respectively.  The fair value of the earn-out as of the Acquisition Date was $18 million, which was determined by using a Monte Carlo Simulation that includes significant unobservable inputs such as a risk-adjusted discount rate of 16% and projected revenues of Jaybird over the earn-out period. Any changes to the significant unobservable inputs used could have a material impact on future results of operations. Actual payment of contingent consideration in the future could be different from the current fair value of the contingent consideration. The fair value of the contingent consideration is remeasured at each reporting period based on the inputs on the date of remeasurement. The fair value of the contingent consideration was $18 million as of September 30, 2016.

[0001032975-16-000106:notes:111]
[same as prior period, unchanged from 0001032975-16-000097:notes:106]

[0001032975-16-000106:notes:112]
The Company’s non-marketable cost method investments, and non-financial assets, such as goodwill, intangible assets and property, plant and equipment, are recorded at fair value only upon initial recognition or if an impairment is recognized. There were no impairments of long-lived assets during the three and six months ended September 30, 2016 or 2015.

[0001032975-16-000106:notes:113]
[same as prior period, unchanged from 0001032975-16-000097:notes:108]

[0001032975-16-000106:notes:114]
The primary investment included in non-marketable investments is the Company’s investment in Series A Preferred Stock of Lifesize recorded at the fair value of $5.6 million on the date of the Lifesize divestiture.

[0001032975-16-000106:notes:115]
The aggregate recorded amount of cost method investments included in other assets as of September 30, 2016 and March 31, 2016 was $7.4 million.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001032975-16-000106:notes:116]
Goodwill

[0001032975-16-000106:notes:117]
The Company conducts its impairment analysis of goodwill annually at December 31 and as necessary if changes in facts and circumstances indicate that it is more likely than not that the fair value of the Company’s reporting units may be less than its carrying amount. There have been no events or circumstances during the six months ended September 30, 2016 that have required the Company to perform an interim assessment of goodwill.

[0001032975-16-000106:notes:118]
The following table summarizes the activities in the Company’s goodwill balance during the six months ended September 30, 2016 (in thousands):

[0001032975-16-000106:notes:119]
| As of March 31, 2016 |  | $ | 218,224 |  |
| Business acquisitions (See Note 3) |  | 31,553 |  |
| Currency impact |  | (12 | ) |
| As of September 30, 2016 |  | $ | 249,765 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001032975-16-000106:notes:120]
[same as prior period, unchanged from 0001032975-16-000097:notes:117]

[0001032975-16-000106:notes:121]
[same as prior period, unchanged from 0001032975-16-000097:notes:118]

[0001032975-16-000106:notes:122]
The income tax provision for the three months ended September 30, 2016 was $5.6 million based on an effective income tax rate of 10.6% of pre-tax income, compared to an income tax provision of $5.6 million based on an effective income tax rate of 15.5% of pre-tax income for the three months ended September 30, 2015.  The income tax provision for the six months ended September 30, 2016 was $8.7 million based on an effective income tax rate of 11.1% of pre-tax income, compared to an income tax provision of $5.6 million based on an effective income tax rate of 11.4% for the six months ended September 30, 2015.

[0001032975-16-000106:notes:123]
The change in the effective income tax rate for the three and six months ended September 30, 2016, compared to the three and six months ended September 30, 2015, is due to the mix of income and losses in the various tax jurisdictions in which the Company operates. In the six months ended September 30, 2015, there was a discrete tax benefit of $2.2 million from the preferential income tax rate reduction pursuant to the High and New Technology Enterprise Program in China.

[0001032975-16-000106:notes:124]
As of September 30 and March 31, 2016, the total amount of unrecognized tax benefits due to uncertain tax positions was $72.0 million and $69.9 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-16-000106:notes:125]
The Company had $60.4 million in non-current income taxes payable and $0.1 million in current income taxes payable, including interest and penalties, related to our income tax liability for uncertain tax positions as of September 30, 2016 compared to $59.7 million in non-current income taxes payable and $0.1 million in current income taxes payable as of March 31, 2016.

[0001032975-16-000106:notes:126]
The Company recognizes interest and penalties related to unrecognized tax positions in income tax expense. As of September 30 and March 31, 2016, the Company had $3.8 million and $3.6 million, respectively, of accrued interest and penalties related to uncertain tax positions.

[0001032975-16-000106:notes:127]
[same as prior period, unchanged from 0001032975-16-000097:notes:124]


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0001032975-16-000106:notes:128]
[same as prior period, unchanged from 0001032975-16-000097:notes:125]

[0001032975-16-000106:notes:129]
|  |  | September 30,2016 |  | March 31,2016 |
| Americas |  | $ | 38,157 |  |  | $ | 40,221 |  |
| EMEA |  | 3,704 |  |  | 3,194 |  |
| Asia Pacific |  | 42,936 |  |  | 49,445 |  |
|  |  | $ | 84,797 |  |  | $ | 92,860 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001032975-16-000106:notes:130]
[same as prior period, unchanged from 0001032975-16-000097:notes:127]

[0001032975-16-000106:notes:131]
During the first quarter of fiscal year 2016, the Company implemented a restructuring plan to exit the OEM business, reorganize Lifesize to sharpen its focus on its cloud-based offering, and streamline the Company's overall cost structure through product, overhead and infrastructure cost reductions with a targeted resource realignment. Charges and other costs related to the workforce reduction and structure realignment are presented as restructuring charges in the condensed consolidated statements of operations. On a total company basis, including the Lifesize video conferencing business as reported in discontinued operations, the Company has incurred approximately $25.5 million under this restructuring plan, including approximately $24.4 million for cash severance and other personnel costs. The Company substantially completed this restructuring plan by the fourth quarter of fiscal year 2016.

[0001032975-16-000106:notes:132]
The following table summarizes restructuring related activities during the three and six months ended September 30, 2016:

[0001032975-16-000106:notes:133]
|  |  | Restructuring |
|  |  | TerminationBenefits |  | Lease ExitCosts |  | Total |
| Accrual balance at March 31, 2016 |  | $ | 6,275 |  |  | $ | 125 |  |  | $ | 6,400 |  |
| Credits, net |  | (85 | ) |  | — |  |  | (85 | ) |
| Cash payments |  | (1,908 | ) |  | (125 | ) |  | (2,033 | ) |
| Accrual balance at June 30, 2016 |  | $ | 4,282 |  |  | $ | — |  |  | $ | 4,282 |  |
| Charges |  | 74 |  |  | — |  |  | 74 |  |
| Cash payments |  | (1,473 | ) |  | — |  |  | (1,473 | ) |
| Accrual balance at September 30, 2016 |  | $ | 2,883 |  |  | $ | — |  |  | $ | 2,883 |  |


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001032975-16-000106:notes:134]
Net sales to unaffiliated customers by geographic region (based on the customers’ location) for the three and six months ended September 30, 2016 and 2015 were as follows (in thousands):

[0001032975-16-000106:notes:135]
|  |  | Three Months EndedSeptember 30, |  | Six Months Ended September 30, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Americas |  | $ | 239,830 |  |  | $ | 224,766 |  |  | $ | 462,455 |  |  | $ | 440,441 |  |
| EMEA |  | 200,636 |  |  | 169,162 |  |  | 343,558 |  |  | 288,774 |  |
| Asia Pacific |  | 123,838 |  |  | 124,566 |  |  | 238,155 |  |  | 236,965 |  |
| Total net sales |  | $ | 564,304 |  |  | $ | 518,494 |  |  | $ | 1,044,168 |  |  | $ | 966,180 |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001032975-16-000106:notes:136]
On total company basis, the components of accumulated other comprehensive income (loss) were as follows (in thousands):

[0001032975-16-000106:notes:137]
|  |  | Accumulated Other Comprehensive Income (Loss) |
|  |  | CumulativeTranslationAdjustment (1) |  | DefinedBenefitPlan (1) |  | DeferredHedgingGains (Losses) |  | Total |
| March 31, 2016 |  | $ | (84,038 | ) |  | $ | (26,171 | ) |  | $ | (1,776 | ) |  | $ | (111,985 | ) |
| Other comprehensive income |  | 254 |  |  | 1,192 |  |  | 2,424 |  |  | 3,870 |  |
| September 30, 2016 |  | $ | (83,784 | ) |  | $ | (24,979 | ) |  | $ | 648 |  |  | $ | (108,115 | ) |

[0001032975-16-000106:notes:138]
(1)        Tax effect was not significant as of September 30 or March 31, 2016.


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001032975-16-000106:notes:139]
Net sales by product categories and sales channels, excluding intercompany transactions, for the three and six months ended September 30, 2016 and 2015 were as follows (in thousands):

[0001032975-16-000106:notes:140]
|  |  | Three Months EndedSeptember 30, |  | Six Months Ended September 30, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Mobile Speakers |  | $ | 97,172 |  |  | $ | 80,550 |  |  | $ | 154,468 |  |  | $ | 121,094 |  |
| Audio-PC & Wearables |  | 62,254 |  |  | 46,342 |  |  | 118,833 |  |  | 92,041 |  |
| Gaming |  | 79,193 |  |  | 67,624 |  |  | 135,693 |  |  | 111,294 |  |
| Video Collaboration |  | 28,581 |  |  | 20,059 |  |  | 52,491 |  |  | 41,235 |  |
| Home Control |  | 11,807 |  |  | 12,610 |  |  | 22,974 |  |  | 22,864 |  |
| Pointing Devices |  | 123,300 |  |  | 124,668 |  |  | 240,083 |  |  | 241,653 |  |
| Keyboards & Combos |  | 116,516 |  |  | 102,098 |  |  | 234,535 |  |  | 207,927 |  |
| Tablet & Other Accessories |  | 20,614 |  |  | 18,549 |  |  | 34,499 |  |  | 37,358 |  |
| PC Webcams |  | 24,307 |  |  | 23,360 |  |  | 49,569 |  |  | 45,041 |  |
| Other (1) |  | 560 |  |  | 403 |  |  | 1,023 |  |  | 1,144 |  |
| Total net retail sales |  | 564,304 |  |  | 496,263 |  |  | 1,044,168 |  |  | 921,651 |  |
| OEM |  | — |  |  | 22,231 |  |  | — |  |  | 44,529 |  |
| Total net sales |  | $ | 564,304 |  |  | 518,494 |  |  | $ | 1,044,168 |  |  | $ | 966,180 |  |

[0001032975-16-000106:notes:141]
[same as prior period, unchanged from 0001032975-16-000097:notes:138]


## us-gaap:SegmentReportingDisclosureTextBlock

[0001032975-16-000106:notes:142]
[same as prior period, unchanged from 0001032975-16-000097:notes:139]

[0001032975-16-000106:notes:143]
The Company has determined that it operates in a single operating segment that encompasses the design, manufacturing and marketing of peripherals for PCs, tablets and other digital platforms. Operating performance measures are provided directly to the Company's Chief Executive Officer (“CEO”), who is considered to be the Company’s Chief Operating Decision Maker (“CODM”). The CEO periodically reviews information such as net sales and operating income (loss) to make business decisions. These operating performance measures do not include restructuring charges (credits), net, share-based compensation expense and amortization of intangible assets, charges (credits) from the purchase accounting effect on inventory, and acquisition-related costs.

[0001032975-16-000106:notes:144]
Sales are attributed to countries on the basis of the customers’ locations.

[0001032975-16-000106:notes:145]
The United States and Germany each represented more than 10% of the Company’s total consolidated net sales from continuing operations for the three and six months ended September 30, 2016. The United States represented more than 10% of the Company’s total consolidated net sales from continuing operations for the three and six months ended September 30, 2015.

[0001032975-16-000106:notes:146]
Switzerland, the Company’s home domicile, represented 3% and 2%, respectively, of the Company’s total consolidated net sales from continuing operations for the three and six months ended September 30, 2016 and 2% for the three and six months ended September 30, 2015.

[0001032975-16-000106:notes:147]
Two customer groups of the Company each represented more than 10% of total consolidated sales from continuing operations for the three and six months ended September 30, 2016.  One customer group of the Company represented more than 10% of total consolidated sales from continuing operations for the three and six months ended September 30, 2015.

[0001032975-16-000106:notes:148]
Long-lived assets in the United States and China were $38.0 million and $36.6 million as of September 30, 2016, respectively, and $40.0 million and $44.5 million as of March 31, 2016, respectively. No other countries represented more than 10% of the Company’s total consolidated long-lived assets as of September 30 or March 31, 2016. Long-lived assets in Switzerland, the Company’s home domicile, were $2.1 million and $1.7 million as of September 30 and March 31, 2016, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001032975-16-000106:notes:149]
[same as prior period, unchanged from 0001032975-16-000097:notes:144]

[0001032975-16-000106:notes:150]
[same as prior period, unchanged from 0001032975-16-000097:notes:145]

[0001032975-16-000106:notes:151]
In March 2014, the Company’s Board of Directors approved the 2014 share buyback program, which authorizes the Company to use up to $250.0 million to purchase its own shares. The Company’s share buyback program is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market, through block trades or trading plan or otherwise. Opportunistic share repurchases may be started or stopped at any time without prior notice depending on market conditions and other factors. During the six months ended September 30, 2016 and 2015, 2.4 million and 3.5 million shares were repurchased for $42.9 million and $48.8 million, respectively.  During the three months ended September 30, 2016 and 2015, 0.9 million and 2.9 million shares were repurchased for $18.4 million and $40.0 million, respectively.

[0001032975-16-000106:notes:152]
Cash Dividend on Shares of Common Stock

[0001032975-16-000106:notes:153]
During the three and six months ended September 30, 2016, the Company declared and paid cash dividends of CHF 0.56 (USD equivalent of $0.57) per common share, totaling $93.1 million on the Company's outstanding common stock. During the three and six months ended September 30, 2015, the Company declared and paid cash dividends of CHF 0.51 (USD equivalent of $0.53) per common share, totaling $85.9 million on the Company's outstanding common stock.

[0001032975-16-000106:notes:154]
Any future dividends will be subject to the approval of the Company's shareholders.

[0001032975-16-000106:notes:155]
[same as prior period, unchanged from 0001032975-16-000097:notes:147]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001032975-16-000106:notes:156]
[same as prior period, unchanged from 0001032975-16-000097:notes:148]
