# LOGI note change history — 0001032975-16-000097 → 0001032975-16-000106


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-10-27):
[0001032975-16-000106:note_history:1]
Changes in the Company’s warranty liability for the three and six months ended September 30, 2016 and 2015 were as follows (in thousands):
  (was, 2016-07-29, similarity 0.9231):
[0001032975-16-000097:note_history:1]
Changes in the Company’s warranty liability for the three months ended June 30, 2016 and 2015 were as follows (in thousands):

- added (2016-10-27):
[0001032975-16-000106:note_history:2]
|  | Three Months EndedSeptember 30, |  | Six Months Ended September 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Beginning of the period | $ | 21,752 |  |  | $ | 21,284 |  |  | $ | 20,380 |  |  | $ | 21,710 |  |
| Assumed from business acquisition | 150 |  |  | — |  |  | 1,963 |  |  | — |  |
| Provision | 3,163 |  |  | 1,879 |  |  | 6,340 |  |  | 3,792 |  |
| Settlements | (3,452 | ) |  | (2,677 | ) |  | (6,880 | ) |  | (5,245 | ) |
| Currency impact | (1 | ) |  | (87 | ) |  | (191 | ) |  | 142 |  |
| End of the period | $ | 21,612 |  |  | $ | 20,399 |  |  | $ | 21,612 |  |  | $ | 20,399 |  |

- changed (2016-10-27):
[0001032975-16-000106:note_history:3]
In April 2016, the Company entered into a settlement with the SEC related to the accounting for Revue inventory valuation reserves that resulted in the restatement described in the Fiscal Year 2014 Annual Report on Form 10-K, revision to its consolidated financial statements concerning warranty accruals and amortization of intangible assets presented in its Amended Annual Report on Form 10-K/A, filed on August 7, 2013, and its transactions with a distributor for Fiscal Year 2007 through Fiscal Year 2009. The Company entered into the settlement without admitting or denying the findings of the SEC’s investigation and paid a civil penalty of $7.5 million in April 2016.
  (was, 2016-07-29, similarity 0.9387):
[0001032975-16-000097:note_history:3]
In April 2016, the Company entered into a settlement with the Securities and Exchange Commission (“SEC”) related to the accounting for Revue inventory valuation reserves that resulted in the restatement described in the Fiscal Year 2014 Annual Report on Form 10-K, revision to its consolidated financial statements concerning warranty accruals and amortization of intangible assets presented in its Amended Annual Report on Form 10-K/A, filed on August 7, 2013, and its transactions with a distributor for Fiscal Year 2007 through Fiscal Year 2009. The Company entered into the settlement without admitting or denying the findings of the SEC’s investigation and paid a civil penalty of $7.5 million. This amount was paid in April 2016.

- added (2016-10-27):
[0001032975-16-000106:note_history:4]
Logitech Europe S.A. guaranteed payments of certain third-party contract manufacturers’ purchase obligations. As of September 30, 2016, the maximum amount of this guarantee was $3.8 million, of which $1.9 million of guaranteed purchase obligations were outstanding.

- changed (2016-10-27):
[0001032975-16-000106:note_history:5]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of September 30, 2016, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.
  (was, 2016-07-29, similarity 0.9899):
[0001032975-16-000097:note_history:5]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of June 30, 2016, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

- removed (2016-10-27):
[0001032975-16-000097:note_history:6]
|  | Three Months EndedJune 30, |
|  | 2016 |  | 2015 |
| Beginning of the period | $ | 20,380 |  |  | $ | 21,710 |  |
| Assumed from business acquisition | 1,813 |  |  | — |  |
| Provision | 3,177 |  |  | 1,913 |  |
| Settlements | (3,428 | ) |  | (2,568 | ) |
| Currency impact | (190 | ) |  | 229 |  |
| End of the period | $ | 21,752 |  |  | $ | 21,284 |  |

- removed (2016-10-27):
[0001032975-16-000097:note_history:7]
Logitech Europe S.A. guaranteed payments of certain third-party contract manufacturers’ purchase obligations. As of June 30, 2016, the maximum amount of this guarantee was $3.8 million, of which $1.3 million of guaranteed purchase obligations were outstanding.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-10-27):
[0001032975-16-000106:note_history:8]
Logitech was founded in Switzerland in 1981 and Logitech International S.A. has been the parent holding company of Logitech since 1988. Logitech International S.A. is a Swiss holding company with its registered office in Apples, Switzerland, which conducts its business through subsidiaries in the Americas, Europe, Middle East and Africa ("EMEA"), and Asia Pacific. Shares of Logitech International S.A. are listed on both the SIX Swiss Exchange under the trading symbol LOGN and the Nasdaq Global Select Market under the trading symbol LOGI.
  (was, 2016-07-29, similarity 0.9906):
[0001032975-16-000097:note_history:8]
Logitech was founded in Switzerland in 1981 and Logitech International S.A. has been the parent holding company of Logitech since 1988. Logitech International S.A. is a Swiss holding company with its registered office in Apples, Switzerland, which conducts its business through subsidiaries in Americas, Europe, Middle East, Africa ("EMEA") and Asia Pacific. Shares of Logitech International S.A. are listed on both the SIX Swiss Exchange under the trading symbol LOGN and the Nasdaq Global Select Market under the trading symbol LOGI.

- changed (2016-10-27):
[0001032975-16-000106:note_history:9]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and six months ended September 30, 2016 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2017, or any future periods.
  (was, 2016-07-29, similarity 0.7702):
[0001032975-16-000097:note_history:9]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three months ended June 30, 2016 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2017, or any future periods.

- changed (2016-10-27):
[0001032975-16-000106:note_history:10]
Certain amounts from the comparative period in the accompanying unaudited condensed consolidated financial statements have been reclassified to conform to the condensed consolidated financial statement presentation as of and for the three and six months ended September 30, 2016.
  (was, 2016-07-29, similarity 0.9118):
[0001032975-16-000097:note_history:10]
Certain amounts from the comparative period in the accompanying unaudited condensed consolidated financial statements have been reclassified to conform to the condensed consolidated financial statement presentation as of and for the three months ended June 30, 2016.

- changed (2016-10-27):
[0001032975-16-000106:note_history:11]
There have been no substantial changes in the Company’s significant accounting policies during the six months ended September 30, 2016 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2016.
  (was, 2016-07-29, similarity 0.9045):
[0001032975-16-000097:note_history:11]
There have been no substantial changes in the Company’s significant accounting policies during the three months ended June 30, 2016 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2016.

- changed (2016-10-27):
[0001032975-16-000106:note_history:12]
The preparation of financial statements in conformity with GAAP requires management to make judgments, estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Examples of significant estimates and assumptions made by management involve the fair value of goodwill, intangible assets acquired from business acquisitions, warranty liabilities, accruals for discretionary customer programs, sales return reserves, allowance for doubtful accounts, inventory valuation, restructuring charges, contingent consideration from business acquisitions and periodical reassessment of its fair value, share-based compensation expense, uncertain tax positions, and valuation allowances for deferred tax assets. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ materially from those estimates.
  (was, 2016-07-29, similarity 0.6882):
[0001032975-16-000097:note_history:12]
The preparation of financial statements in conformity with GAAP requires management to make judgments, estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Examples of significant estimates and assumptions made by management involve the fair value of goodwill, intangible assets acquired from business acquisitions, warranty liabilities, accruals for discretionary customer programs, sales return reserves, allowance for doubtful accounts, inventory valuation, restructuring charges, contingent consideration from business acquisitions, share-based compensation expense, uncertain tax positions, and valuation allowances for deferred tax assets. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ materially from those estimates.

- changed (2016-10-27):
[0001032975-16-000106:note_history:13]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-9, "Revenue from Contracts with Customers (Topic 606)" ("ASU 2014-9"). ASU 2014-9 outlines a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. Under the new model, recognition of revenue occurs when a customer obtains control of promised goods or services in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. In addition, the new standard requires that reporting companies disclose the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. ASU 2014-09 was originally to be effective for the Company on April 1, 2017. In July 2015, the FASB affirmed a one-year deferral of the effective date of the new revenue standard. The new standard will become effective for the Company on April 1, 2018. Early application is permitted but not before the original effective date of annual periods beginning after December 15, 2016. The new standard is required to be applied retrospectively to each prior reporting period presented or retrospectively with the cumulative effect of initially applying it recognized at the date of initial application. The Company has not yet selected a transition method nor has it determined whether it will early adopt this guidance or the impact of the new standard on its condensed consolidated financial statements.
  (was, 2016-07-29, similarity 0.9997):
[0001032975-16-000097:note_history:13]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-9, "Revenue from Contracts with Customers (Topic 606)," ("ASU 2014-9"). ASU 2014-9 outlines a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. Under the new model, recognition of revenue occurs when a customer obtains control of promised goods or services in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. In addition, the new standard requires that reporting companies disclose the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. ASU 2014-09 was originally to be effective for the Company on April 1, 2017. In July 2015, the FASB affirmed a one-year deferral of the effective date of the new revenue standard. The new standard will become effective for the Company on April 1, 2018. Early application is permitted but not before the original effective date of annual periods beginning after December 15, 2016. The new standard is required to be applied retrospectively to each prior reporting period presented or retrospectively with the cumulative effect of initially applying it recognized at the date of initial application. The Company has not yet selected a transition method nor has it determined whether it will early adopt this guidance or the impact of the new standard on its condensed consolidated financial statements.

- changed (2016-10-27):
[0001032975-16-000106:note_history:14]
In July 2015, the FASB issued ASU No. 2015-11, "Simplifying the Measurement of Inventory (Topic 330)" ("ASU 2015-11"). Topic 330, Inventory, currently requires an entity to measure inventory at the lower of cost or market, with market value represented by replacement cost, net realizable value or net realizable value less a normal profit margin. The amendments in ASU 2015-11 require an entity to measure inventory at the lower of cost or net realizable value. ASU 2015-11 is effective in the first quarter of fiscal year 2018 for the Company, with early adoption permitted. The Company does not expect to early adopt this guidance and does not expect the adoption of this guidance to have a material impact on its condensed consolidated financial statements.
  (was, 2016-07-29, similarity 0.9993):
[0001032975-16-000097:note_history:14]
In July 2015, the FASB issued ASU No. 2015-11, "Simplifying the Measurement of Inventory (Topic 330)",  ("ASU 2015-11"). Topic 330, Inventory, currently requires an entity to measure inventory at the lower of cost or market, with market value represented by replacement cost, net realizable value or net realizable value less a normal profit margin. The amendments in ASU 2015-11 require an entity to measure inventory at the lower of cost or net realizable value. ASU 2015-11 is effective in the first quarter of fiscal year 2018 for the Company, with early adoption permitted. The Company does not expect to early adopt this guidance and does not expect the adoption of this guidance to have a material impact on its condensed consolidated financial statements.

- changed (2016-10-27):
[0001032975-16-000106:note_history:15]
In January 2016, the FASB issued ASU 2016-01 “Financial Instruments- Recognition and Measurement of Financial Assets and Financial Liabilities (Subtopic 825-10)”. The guidance is effective in the first quarter of fiscal year 2018 for the Company, with early adoption permitted. The Company does not expect to early adopt this guidance and does not believe that the adoption of this guidance will have a material impact on its condensed consolidated financial statements.
  (was, 2016-07-29, similarity 0.9956):
[0001032975-16-000097:note_history:15]
In January 2016, FASB issued ASU 2016-01 “Financial Instruments- Recognition and Measurement of Financial Assets and Financial Liabilities (Subtopic 825-10)”. The guidance is effective in the first quarter of fiscal year 2018 for the Company, with early adoption permitted. The Company does not expect to early adopt this guidance and does not believe that the adoption of this guidance will have a material impact on its condensed consolidated financial statements.

- added (2016-10-27):
[0001032975-16-000106:note_history:16]
In February 2016, the FASB issued ASU 2016-02 "Leases (Topic 842)" ("ASU 2016-02"), which requires the recognition of lease assets and lease liabilities arising from operating leases in the statement of financial position. This guidance is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. The Company is evaluating the full effect that ASU 2016-02 will have on its condensed consolidated financial statements and will adopt the standard effective April 1, 2019.

- added (2016-10-27):
[0001032975-16-000106:note_history:17]
In March 2016, the FASB issued ASU 2016-09 "Compensation-Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting" ("ASU 2016-09"). The amendment simplifies several aspects of the accounting for share-based payments, including immediate recognition of all excess tax benefits and deficiencies in the income statement, changing the threshold to qualify for equity classification up to the employees' maximum statutory tax rates, allowing an entity-wide accounting policy election to either estimate the number of awards that are expected to vest or account for forfeitures as they occur, and clarifying the classification on the statement of cash flows for the excess tax benefit and employee taxes paid when an employer withholds shares for tax-withholding purposes. ASU 2016-09 is effective for annual periods beginning after December 15, 2016, and interim periods within those annual periods. Early adoption is permitted in any interim or annual period. The Company is evaluating the effect that ASU 2016-09 will have on its condensed consolidated financial statements and the timing of the adoption of this standard.

- added (2016-10-27):
[0001032975-16-000106:note_history:18]
In August 2016, the FASB issued ASU 2016-15 "Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments". The amendment gives guidance and reduces diversity in practice with respect to certain types of cash flows. The Company has early adopted this guidance during the second quarter of fiscal year 2017 and the adoption did not impact its consolidated financial statements.

- removed (2016-10-27):
[0001032975-16-000097:note_history:19]
In February 2016, the FASB issued ASU 2016-02 "Leases (Topic 842)", which requires the recognition of lease assets and lease liabilities arising from operating leases in the statement of financial position. This guidance is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. The Company is evaluating the full effect that ASU 2016-02 will have on its condensed consolidated financial statements and will adopt the standard effective April 1, 2019.

- removed (2016-10-27):
[0001032975-16-000097:note_history:20]
In March 2016, the FASB issued ASU 2016-09 "Compensation-Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting". The amendment simplifies several aspects of the accounting for share-based payments, including immediate recognition of all excess tax benefits and deficiencies in the income statement, changing the threshold to qualify for equity classification up to the employees' maximum statutory tax rates, allowing an entity-wide accounting policy election to either estimate the number of awards that are expected to vest or account for forfeitures as they occur, and clarifying the classification on the statement of cash flows for the excess tax benefit and employee taxes paid when an employer withholds shares for tax-withholding purposes. ASU 2016-09 is effective for annual periods beginning after December 15, 2016, and interim periods within those annual periods. Early adoption is permitted in any interim or annual period. The Company is evaluating the effect that ASU 2016-09 will have on its condensed consolidated financial statements and the timing of the adoption of this standard.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2016-10-27):
[0001032975-16-000106:note_history:21]
The Company had several uncommitted, unsecured bank lines of credit aggregating $44.6 million as of September 30, 2016. There are no financial covenants under these lines of credit with which the Company must comply. As of September 30, 2016, the Company had outstanding bank guarantees of $12.4 million under these lines of credit. There was no borrowing outstanding under these lines of credit as of September 30, 2016 or March 31, 2016.

- removed (2016-10-27):
[0001032975-16-000097:note_history:22]
The Company had several uncommitted, unsecured bank lines of credit aggregating $44.6 million as of June 30, 2016. There are no financial covenants under these lines of credit with which the Company must comply. As of June 30, 2016, the Company had outstanding bank guarantees of $15.6 million under these lines of credit. There was no borrowing outstanding under these lines of credit as of June 30, 2016 or March 31, 2016.
