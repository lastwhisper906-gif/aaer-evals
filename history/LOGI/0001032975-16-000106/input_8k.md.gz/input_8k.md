# LOGI 8-K — 0001032975-16-000103 filed 2016-10-26

## item codes, every 8-K on or before 2016-10-27

- 2016-10-26 0001032975-16-000103 — 2.02, 9.01
- 2016-09-13 0001032975-16-000101 — 5.07, 8.01
- 2016-07-28 0001032975-16-000092 — 2.02, 9.01
- 2016-06-30 0001032975-16-000087 — 5.02
- 2016-04-28 0001032975-16-000077 — 2.02, 9.01
- 2016-04-14 0001032975-16-000073 — 1.01, 7.01, 9.01
- 2016-01-21 0001032975-16-000064 — 2.02, 9.01
- 2016-01-04 0001032975-16-000061 — 1.01, 2.01, 9.01
- 2015-12-23 0001032975-15-000059 — 5.02
- 2015-10-22 0001032975-15-000047 — 2.02, 9.01
- 2015-09-11 0001032975-15-000044 — 5.07, 8.01
- 2015-07-24 0001032975-15-000034 — 2.05 — amendment of 0001032975-15-000030
- 2015-07-23 0001032975-15-000030 — 2.02, 9.01
- 2015-06-25 0001032975-15-000025 — 5.02
- 2015-05-14 0001032975-15-000011 — 8.01, 9.01
- 2015-04-23 0001032975-15-000008 — 2.02, 2.05
- 2015-01-22 0001628280-15-000191 — 2.02, 8.01
- 2014-12-23 0001193125-14-450908 — 5.02, 5.07, 8.01
- 2014-11-25 0001193125-14-425233 — 3.01
- 2014-11-13 0001193125-14-411303 — 4.01, 9.01
- 2014-10-23 0001104659-14-073164 — 2.02, 9.01
- 2014-09-04 0001193125-14-331214 — 4.02, 9.01
- 2014-08-18 0001193125-14-313346 — 3.01, 9.01
- 2014-07-24 0001104659-14-053065 — 2.02, 9.01
- 2014-06-05 0001193125-14-226177 — 3.01, 9.01
- 2014-05-22 0001193125-14-208777 — 8.01, 9.01
- 2014-04-24 0001104659-14-029650 — 2.02, 9.01
- 2014-01-23 0001104659-14-003619 — 2.02, 9.01
- 2013-10-24 0001104659-13-077404 — 2.02, 9.01
- 2013-09-09 0001193125-13-361441 — 5.02, 5.07, 8.01, 9.01
- 2013-09-06 0001193125-13-359930 — 5.02, 9.01
- 2013-08-02 0001193125-13-317343 — 5.02
- 2013-07-25 0001104659-13-056372 — 2.02, 9.01
- 2013-06-28 0001193125-13-277394 — 5.02, 9.01
- 2013-06-20 0001193125-13-265914 — 8.01, 9.01
- 2013-04-25 0001104659-13-032570 — 2.02, 9.01
- 2013-04-17 0001193125-13-158923 — 5.02, 9.01
- 2013-03-01 0001193125-13-085804 — 2.05
- 2013-01-24 0001104659-13-004214 — 2.02, 9.01
- 2013-01-02 0001193125-13-000058 — 5.02
- 2012-10-25 0001104659-12-070966 — 2.02, 9.01
- 2012-09-11 0001193125-12-388070 — 5.02, 5.07, 8.01, 9.01
- 2012-08-22 0001193125-12-364167 — 5.02, 8.01, 9.01
- 2012-07-26 0001104659-12-051084 — 2.02, 9.01
- 2012-06-08 0001193125-12-264132 — 2.05, 9.01 — amendment, the index does not say of what
- 2012-04-26 0001193125-12-183657 — 5.02, 9.01
- 2012-04-26 0001104659-12-028470 — 2.02, 2.05, 9.01
- 2012-03-15 0001193125-12-115954 — 5.02, 9.01
- 2012-01-26 0001104659-12-004014 — 2.02, 9.01
- 2012-01-04 0001193125-12-002212 — 1.01, 2.03, 9.01
- 2011-10-27 0001104659-11-058150 — 2.02, 9.01
- 2011-09-12 0001193125-11-245931 — 5.07
- 2011-07-28 0001193125-11-200929 — 5.02, 9.01
- 2011-07-28 0001193125-11-199704 — 2.02, 9.01
- 2011-04-28 0001193125-11-112669 — 2.02, 9.01
- 2011-03-24 0001193125-11-076483 — 5.02, 9.01
- 2011-01-27 0001032975-11-000003 — 9.01
- 2010-10-28 0001032975-10-000032 — 9.01
- 2010-09-13 0001032975-10-000022 — 5.07
- 2010-07-29 0001032975-10-000010 — 2.02, 9.01
- 2010-06-10 0001193125-10-136877 — 5.02, 9.01
- 2010-05-03 0001193125-10-104337 — 5.02
- 2010-04-29 0001032975-10-000008 — 2.02, 9.01
- 2010-02-19 0001032975-10-000006 — 9.01 — amendment of 0001193125-09-252416
- 2010-01-21 0001032975-10-000002 — 2.02, 9.01
- 2009-12-14 0001193125-09-252416 — 2.01, 9.01
- 2009-11-17 0001032975-09-000023 — 1.01
- 2009-10-22 0001032975-09-000018 — 9.01
- 2009-09-22 0001193125-09-195545 — 5.02, 9.01
- 2009-09-03 0001032975-09-000013 — 8.01
- 2009-07-23 0001140361-09-016802 — 2.02, 9.01
- 2009-06-01 0001193125-09-122550 — 5.02
- 2009-04-23 0001193125-09-085054 — 2.02, 9.01
- 2009-04-02 0001193125-09-071272 — 5.02, 9.01
- 2009-01-20 0001193125-09-008454 — 2.05 — amendment of 0001193125-09-002609
- 2009-01-20 0001193125-09-007902 — 2.02, 9.01
- 2009-01-07 0001193125-09-002609 — 2.05, 9.01
- 2009-01-07 0001193125-09-002370 — 5.02, 9.01
- 2008-12-09 0001193125-08-250543 — 5.02, 9.01
- 2008-10-21 0001193125-08-213212 — 2.02, 9.01
- 2008-07-22 0001193125-08-154721 — 2.02, 9.01
- 2008-06-24 0001193125-08-139163 — 5.03, 9.01
- 2008-05-13 0001193125-08-113263 — 5.02, 9.01
- 2008-04-22 0001193125-08-086176 — 2.02, 9.01

## late-filing notifications on or before 2016-10-27

- 2015-06-02 0001032975-15-000020 — NT 10-K, for the period ended 2015-03-31
- 2014-11-06 0001193125-14-401306 — NT 10-Q, for the period ended 2014-09-30
- 2014-07-24 0001193125-14-277575 — NT 10-Q, for the period ended 2014-06-30
- 2014-05-22 0001193125-14-208712 — NT 10-K, for the period ended 2014-03-31
- 2009-08-06 0001032975-09-000006 — NT 10-Q, for the period ended 2009-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001032975-16-000103:8k_2_02:1]
EX-99.1
2
exhibit991q2fy17.htm
EXHIBIT 99.1

[0001032975-16-000103:8k_2_02:2]
Exhibit

[0001032975-16-000103:8k_2_02:3]
Exhibit 99.1

[0001032975-16-000103:8k_2_02:4]
Editorial Contacts:

[0001032975-16-000103:8k_2_02:5]
Ben Lu, Vice President, Investor Relations - USA (510) 713-5568

[0001032975-16-000103:8k_2_02:6]
Krista Todd, Vice President, External Communications - USA (510) 713-5834

[0001032975-16-000103:8k_2_02:7]
Ben Starkie, Corporate Communications - Europe +41 (0) 79-292-3499

[0001032975-16-000103:8k_2_02:8]
Logitech Delivers Record Q2 Retail Revenue, Up 14%

[0001032975-16-000103:8k_2_02:9]
NEWARK, Calif. - October 25, 2016 and LAUSANNE, Switzerland, October 26, 2016 - Logitech International (SIX: LOGN) (Nasdaq: LOGI) today announced financial results for the second quarter of Fiscal Year 2017.

[0001032975-16-000103:8k_2_02:10]
| • | Q2 sales were $564 million, up 9 percent compared to Q2 of the prior year. Q2 retail sales grew 14 percent, reaching a record level for Q2. |

[0001032975-16-000103:8k_2_02:11]
| • | Q2 GAAP operating income was $53 million compared to $37 million a year ago. Q2 GAAP earnings per share (EPS) from continuing operations were $0.28 compared to $0.18 a year ago. |

[0001032975-16-000103:8k_2_02:12]
| • | Q2 non-GAAP operating income was $65 million compared to $47 million a year ago, with non-GAAP EPS of $0.35 compared to $0.25 a year ago. |

[0001032975-16-000103:8k_2_02:13]
| • | Q2 cash flow from operations was $74 million compared to $11 million a year ago. |

[0001032975-16-000103:8k_2_02:14]
“We’ve delivered an outstanding quarter - the highest Q2 retail sales in Logitech’s history - and a first half ahead of expectations,” said Bracken Darrell, Logitech president and chief executive officer. “Once more this quarter shows our strategy clearly: new product launches that again demonstrate the power of our innovation engine, ongoing operational excellence, and profitable growth across all our regions and in almost all our market opportunities. As we enter the second half of the year and our biggest quarter, we’ve got momentum, a winning product portfolio and a terrific team.”

[0001032975-16-000103:8k_2_02:15]
Outlook

[0001032975-16-000103:8k_2_02:16]
Logitech’s Fiscal Year 2017 outlook is 8 to 10 percent retail sales growth in constant currency and $195 million to $205 million in non-GAAP operating income.

[0001032975-16-000103:8k_2_02:17]
Prepared Remarks Available Online

[0001032975-16-000103:8k_2_02:18]
Logitech has made its prepared written remarks for the financial results teleconference available online on the Logitech corporate website at http://ir.logitech.com.

[0001032975-16-000103:8k_2_02:19]
Financial Results Teleconference and Webcast

[0001032975-16-000103:8k_2_02:20]
Logitech will hold a financial results teleconference to discuss the results for Q2 FY 2017 on Weds., October 26, 2016 at 8:30 a.m. Eastern Daylight Time and 2:30 p.m. Central European Summer Time. A live webcast of the call will be available on the Logitech corporate website at http://ir.logitech.com.

[0001032975-16-000103:8k_2_02:21]
Continued Operations

[0001032975-16-000103:8k_2_02:22]
Logitech separated its Lifesize division from the Company on Dec. 28, 2015. Except as otherwise noted, all the results reported in this press release as well as comparisons between periods are focused on results from continuing operations and do not address the performance of Lifesize, which is now reported in the Company’s financial statements under discontinued operations or total Logitech including discontinued operations. For more information on the impact of the Lifesize separation on Logitech’s historical results, please refer to the Financial Reporting section of Logitech’s Financial History, available on the Logitech corporate website at http://ir.logitech.com.

[0001032975-16-000103:8k_2_02:23]
Use of Non-GAAP Financial Information and Constant Currency

[0001032975-16-000103:8k_2_02:24]
To facilitate comparisons to Logitech’s historical results, Logitech has included non-GAAP adjusted measures, which exclude share-based compensation expense, amortization of intangible assets, purchase accounting effect on inventory, acquisition-related costs, restructuring charges (credits), gain (loss) on equity-method investment, investigation and related expenses, non-GAAP income tax adjustment, and other items detailed under “Supplemental Financial Information” after the tables below. Logitech also presents percentage sales growth in constant currency to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales. Logitech believes this information, used together with the GAAP financial information, will help investors to evaluate its current period performance and trends in its business. With respect to the Company’s outlook for non-GAAP operating income, most of

[0001032975-16-000103:8k_2_02:25]
these excluded amounts pertain to events that have not yet occurred and are not currently possible to estimate with a reasonable degree of accuracy. Therefore, no reconciliation to the GAAP amounts has been provided for Fiscal Year 2017.

[0001032975-16-000103:8k_2_02:26]
About Logitech

[0001032975-16-000103:8k_2_02:27]
Logitech designs products that have an everyday place in people's lives, connecting them to the digital experiences they care about. Over 30 years ago Logitech started connecting people through computers, and now it’s designing products that bring people together through music, gaming, video and computing. Founded in 1981, Logitech International is a Swiss public company listed on the SIX Swiss Exchange (LOGN) and on the Nasdaq Global Select Market (LOGI). Find Logitech at www.logitech.com, the company blog or @Logitech.

[0001032975-16-000103:8k_2_02:28]
# # #

[0001032975-16-000103:8k_2_02:29]
Note that unless noted otherwise, comparisons are year over year.

[0001032975-16-000103:8k_2_02:30]
2016 Logitech, Logicool, Logi and other Logitech marks are owned by Logitech and may be registered. All other trademarks are the property of their respective owners. For more information about Logitech and its products, visit the company’s website at www.logitech.com.

[0001032975-16-000103:8k_2_02:31]
(LOGIIR)

[0001032975-16-000103:8k_2_02:32]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | September 30, |  | September 30, |
| GAAP CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS (A) |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Net sales |  | $ | 564,304 |  |  | $ | 518,494 |  |  | $ | 1,044,168 |  |  | $ | 966,180 |  |
| Cost of goods sold |  | 356,268 |  |  | 345,977 |  |  | 665,893 |  |  | 635,730 |  |
| Amortization of intangible assets and purchase accounting effect on inventory |  | 1,163 |  |  | — |  |  | 2,776 |  |  | — |  |
| Gross profit |  | 206,873 |  |  | 172,517 |  |  | 375,499 |  |  | 330,450 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Marketing and selling |  | 93,792 |  |  | 78,833 |  |  | 177,664 |  |  | 154,629 |  |
| Research and development |  | 32,632 |  |  | 28,725 |  |  | 64,583 |  |  | 56,727 |  |
| General and administrative |  | 25,216 |  |  | 25,074 |  |  | 50,956 |  |  | 53,886 |  |
| Amortization of intangible assets and acquisition-related costs |  | 1,748 |  |  | 168 |  |  | 3,041 |  |  | 336 |  |
| Restructuring charges (credits), net |  | 74 |  |  | 3,146 |  |  | (11 | ) |  | 14,684 |  |
| Total operating expenses |  | 153,462 |  |  | 135,946 |  |  | 296,233 |  |  | 280,262 |  |
| Operating income |  | 53,411 |  |  | 36,571 |  |  | 79,266 |  |  | 50,188 |  |
| Interest income (expense), net |  | (90 | ) |  | 189 |  |  | 61 |  |  | 444 |  |
| Other expense, net |  | (683 | ) |  | (737 | ) |  | (1,691 | ) |  | (1,756 | ) |
| Income before income taxes |  | 52,638 |  |  | 36,023 |  |  | 77,636 |  |  | 48,876 |  |
| Provision for income taxes |  | 5,593 |  |  | 5,571 |  |  | 8,650 |  |  | 5,564 |  |
| Net income from continuing operations |  | 47,045 |  |  | 30,452 |  |  | 68,986 |  |  | 43,312 |  |
| Loss from discontinued operations, net of taxes |  | — |  |  | (12,355 | ) |  | — |  |  | (17,778 | ) |
| Net income |  | $ | 47,045 |  |  | $ | 18,097 |  |  | $ | 68,986 |  |  | $ | 25,534 |  |
| Net income (loss) per share - basic: |  |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.29 |  |  | $ | 0.19 |  |  | $ | 0.43 |  |  | $ | 0.26 |  |
| Discontinued operations |  | — |  |  | (0.08 | ) |  | — |  |  | (0.10 | ) |
| Net income per share - basic |  | $ | 0.29 |  |  | $ | 0.11 |  |  | $ | 0.43 |  |  | $ | 0.16 |  |
| Net income (loss) per share - diluted: |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.28 |  |  | $ | 0.18 |  |  | $ | 0.42 |  |  | $ | 0.26 |  |
| Discontinued operations |  | — |  |  | (0.07 | ) |  | — |  |  | (0.11 | ) |
| Net income per share - diluted |  | $ | 0.28 |  |  | $ | 0.11 |  |  | $ | 0.42 |  |  | $ | 0.15 |  |
| Weighted average shares used to compute net income (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | 162,222 |  |  | 163,515 |  |  | 162,176 |  |  | 163,957 |  |
| Diluted |  | 165,549 |  |  | 165,841 |  |  | 164,926 |  |  | 166,352 |  |
| Cash dividend per share |  | $ | 0.57 |  |  | $ | 0.53 |  |  | $ | 0.57 |  |  | $ | 0.53 |  |

[0001032975-16-000103:8k_2_02:33]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |
|  |  | September 30, |  | March 31, |
| CONDENSED CONSOLIDATED BALANCE SHEETS (A) |  | 2016 |  | 2016 |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 395,201 |  |  | $ | 519,195 |  |
| Accounts receivable, net |  | 240,606 |  |  | 142,778 |  |
| Inventories |  | 268,110 |  |  | 228,786 |  |
| Other current assets |  | 40,201 |  |  | 35,488 |  |
| Total current assets |  | 944,118 |  |  | 926,247 |  |
| Non-current assets: |  |  |  |  |  |  |
| Property, plant and equipment, net |  | 84,797 |  |  | 92,860 |  |
| Goodwill |  | 249,765 |  |  | 218,224 |  |
| Other intangible assets |  | 53,063 |  |  | — |  |
| Other assets |  | 84,517 |  |  | 86,816 |  |
| Total assets |  | $ | 1,416,260 |  |  | $ | 1,324,147 |  |
| Current liabilities: |  |  |  |  |  |  |
| Accounts payable |  | $ | 333,543 |  |  | $ | 241,166 |  |
| Accrued and other current liabilities |  | 213,910 |  |  | 173,764 |  |
| Total current liabilities |  | 547,453 |  |  | 414,930 |  |
| Non-current liabilities: |  |  |  |  |  |  |
| Income taxes payable |  | 60,360 |  |  | 59,734 |  |
| Other non-current liabilities |  | 92,413 |  |  | 89,535 |  |
| Total liabilities |  | 700,226 |  |  | 564,199 |  |
| Shareholders’ equity: |  |  |  |  |
| Registered shares, CHF 0.25 par value: |  | 30,148 |  |  | 30,148 |  |
| Issued and authorized shares —173,106 at September 30 and March 31, 2016 |  |  |  |  |
| Conditionally authorized shares — 50,000 at September 30 and March 31, 2016 |  |  |  |  |
| Additional paid-in capital |  | 8,851 |  |  | 6,616 |  |
| Less shares in treasury, at cost — 11,009 at September 30, 2016 and 10,697 at March 31, 2016 |  | (152,070 | ) |  | (128,407 | ) |
| Retained earnings |  | 937,220 |  |  | 963,576 |  |
| Accumulated other comprehensive loss |  | (108,115 | ) |  | (111,985 | ) |
| Total shareholders’ equity |  | 716,034 |  |  | 759,948 |  |
| Total liabilities and shareholders’ equity |  | $ | 1,416,260 |  |  | $ | 1,324,147 |  |

[0001032975-16-000103:8k_2_02:34]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | September 30, |  | September 30, |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (A) |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 47,045 |  |  | $ | 18,097 |  |  | $ | 68,986 |  |  | $ | 25,534 |  |
| Non-cash items included in net income: |  |  |  |  |  |  |  |  |
| Depreciation |  | 10,511 |  |  | 11,721 |  |  | 23,616 |  |  | 22,237 |  |
| Amortization of intangible assets |  | 2,159 |  |  | 494 |  |  | 3,867 |  |  | 1,226 |  |
| Loss (gain) on equity-method investment |  | (171 | ) |  | 77 |  |  | (172 | ) |  | 180 |  |
| Share-based compensation expense |  | 8,450 |  |  | 6,508 |  |  | 16,967 |  |  | 13,257 |  |
| Excess tax benefits from share-based compensation |  | (850 | ) |  | (498 | ) |  | (4,130 | ) |  | (1,163 | ) |
| Deferred income taxes |  | 663 |  |  | 7,684 |  |  | (385 | ) |  | 952 |  |
| Changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | (48,340 | ) |  | (54,195 | ) |  | (97,001 | ) |  | (95,403 | ) |
| Inventories |  | (18,310 | ) |  | (1,278 | ) |  | (28,317 | ) |  | (55,442 | ) |
| Other assets |  | (3,567 | ) |  | (6,128 | ) |  | (4,738 | ) |  | (8,511 | ) |
| Accounts payable |  | 40,907 |  |  | 15,820 |  |  | 83,676 |  |  | 50,361 |  |
| Accrued and other liabilities |  | 35,522 |  |  | 12,435 |  |  | 25,387 |  |  | 31,910 |  |
| Net cash provided by (used in) operating activities |  | 74,019 |  |  | 10,737 |  |  | 87,756 |  |  | (14,862 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  | (6,623 | ) |  | (15,987 | ) |  | (14,758 | ) |  | (31,277 | ) |
| Investment in privately held companies |  | (160 | ) |  | (240 | ) |  | (480 | ) |  | (480 | ) |
| Acquisitions, net of cash acquired |  | (13,000 | ) |  | — |  |  | (66,987 | ) |  | — |  |
| Release of restricted cash |  | — |  |  | — |  |  | 715 |  |  | — |  |
| Purchase of trading investments |  | (1,042 | ) |  | (1,746 | ) |  | (5,271 | ) |  | (2,649 | ) |
| Proceeds from sales of trading investments |  | 1,065 |  |  | 2,015 |  |  | 5,296 |  |  | 2,855 |  |
| Net cash used in investing activities |  | (19,760 | ) |  | (15,958 | ) |  | (81,485 | ) |  | (31,551 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |
| Payment of cash dividends |  | (93,093 | ) |  | (85,915 | ) |  | (93,093 | ) |  | (85,915 | ) |
| Purchases of treasury shares |  | (18,472 | ) |  | (39,988 | ) |  | (42,894 | ) |  | (48,802 | ) |
| Proceeds from sales of shares upon exercise of options and purchase rights |  | 13,885 |  |  | 7,037 |  |  | 14,484 |  |  | 11,103 |  |
| Tax withholdings related to net share settlements of restricted stock units |  | (1,862 | ) |  | (2,206 | ) |  | (11,047 | ) |  | (3,502 | ) |
| Excess tax benefits from share-based compensation |  | 850 |  |  | 498 |  |  | 4,130 |  |  | 1,163 |  |
| Net cash used in financing activities |  | (98,692 | ) |  | (120,574 | ) |  | (128,420 | ) |  | (125,953 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  | (477 | ) |  | (659 | ) |  | (1,845 | ) |  | 1,102 |  |
| Net decrease in cash and cash equivalents |  | (44,910 | ) |  | (126,454 | ) |  | (123,994 | ) |  | (171,264 | ) |
| Cash and cash equivalents, beginning of the period |  | 440,111 |  |  | 492,228 |  |  | 519,195 |  |  | 537,038 |  |
| Cash and cash equivalents, end of the period |  | $ | 395,201 |  |  | $ | 365,774 |  |  | $ | 395,201 |  |  | $ | 365,774 |  |
| The following amounts reflected in the statements of cash flows are included in discontinued operations: |
| Depreciation |  | $ | — |  |  | $ | 715 |  |  | $ | — |  |  | $ | 1,420 |  |
| Amortization of other intangible assets |  | $ | — |  |  | $ | 326 |  |  | $ | — |  |  | $ | 890 |  |
| Share-based compensation expense |  | $ | — |  |  | $ | 202 |  |  | $ | — |  |  | $ | 428 |  |
| Purchases of property, plant and equipment |  | $ | — |  |  | $ | 365 |  |  | $ | — |  |  | $ | 750 |  |
| Cash and cash equivalents, beginning of the period |  | $ | — |  |  | $ | 1,911 |  |  | $ | — |  |  | $ | 3,659 |  |
| Cash and cash equivalents, end of the period |  | $ | — |  |  | $ | 4,639 |  |  | $ | — |  |  | $ | 4,639 |  |

[0001032975-16-000103:8k_2_02:35]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |  |  |
| NET SALES |  | Three Months Ended |  | Six Months Ended |
|  |  | September 30, |  | September 30, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2016 |  | 2015 |  | Change |  | 2016 |  | 2015 |  | Change |
| Net sales by channel: |  |  |  |  |  |  |  |  |  |  |  |  |
| Retail |  | $ | 564,304 |  |  | $ | 496,263 |  |  | 14 | % |  | $ | 1,044,168 |  |  | $ | 921,651 |  |  | 13 | % |
| OEM |  | — |  |  | 22,231 |  |  | (100 | ) |  | — |  |  | 44,529 |  |  | (100 | ) |
| Total net sales |  | $ | 564,304 |  |  | $ | 518,494 |  |  | 9 |  |  | $ | 1,044,168 |  |  | $ | 966,180 |  |  | 8 |  |
| Net retail sales by product category: |  |  |  |  |  |  |  |  |  |  |  |  |
| Mobile Speakers |  | $ | 97,172 |  |  | $ | 80,550 |  |  | 21 | % |  | $ | 154,468 |  |  | $ | 121,094 |  |  | 28 | % |
| Audio-PC & Wearables |  | 62,254 |  |  | 46,342 |  |  | 34 |  |  | 118,833 |  |  | 92,041 |  |  | 29 |  |
| Gaming |  | 79,193 |  |  | 67,624 |  |  | 17 |  |  | 135,693 |  |  | 111,294 |  |  | 22 |  |
| Video Collaboration |  | 28,581 |  |  | 20,059 |  |  | 42 |  |  | 52,491 |  |  | 41,235 |  |  | 27 |  |
| Home Control |  | 11,807 |  |  | 12,610 |  |  | (6 | ) |  | 22,974 |  |  | 22,864 |  |  | — |  |
| Pointing Devices |  | 123,300 |  |  | 124,668 |  |  | (1 | ) |  | 240,083 |  |  | 241,653 |  |  | (1 | ) |
| Keyboards & Combos |  | 116,516 |  |  | 102,098 |  |  | 14 |  |  | 234,535 |  |  | 207,927 |  |  | 13 |  |
| Tablet & Other Accessories |  | 20,614 |  |  | 18,549 |  |  | 11 |  |  | 34,499 |  |  | 37,358 |  |  | (8 | ) |
| PC Webcams |  | 24,307 |  |  | 23,360 |  |  | 4 |  |  | 49,569 |  |  | 45,041 |  |  | 10 |  |
| Other (1) |  | 560 |  |  | 403 |  |  | 39 |  |  | 1,023 |  |  | 1,144 |  |  | (11 | ) |
| Total net retail sales |  | $ | 564,304 |  |  | $ | 496,263 |  |  | 14 |  |  | $ | 1,044,168 |  |  | $ | 921,651 |  |  | 13 |  |
| __________________ |  |  |  |  |  |  |  |  |  |  |  |  |

[0001032975-16-000103:8k_2_02:36]
(1) Other category includes products that we currently intend to transition out of, or have already transitioned out of, because they are no longer strategic to our business.

[0001032975-16-000103:8k_2_02:37]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| (In thousands, except per share amounts) - Unaudited |  |  |  |  |  |  |  |  |
| GAAP TO NON GAAP RECONCILIATION (A)(B) |  | Three Months Ended |  | Six Months Ended |
|  |  | September 30, |  | September 30, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Gross profit - GAAP |  | $ | 206,873 |  |  | $ | 172,517 |  |  | $ | 375,499 |  |  | $ | 330,450 |  |
| Share-based compensation expense |  | 638 |  |  | 580 |  |  | 1,313 |  |  | 1,185 |  |
| Amortization of intangible assets and purchase accounting effect on inventory |  | 1,163 |  |  | — |  |  | 2,776 |  |  | — |  |
| Gross profit - Non-GAAP |  | $ | 208,674 |  |  | $ | 173,097 |  |  | $ | 379,588 |  |  | $ | 331,635 |  |
| Gross margin - GAAP |  | 36.7 | % |  | 33.3 | % |  | 36.0 | % |  | 34.2 | % |
| Gross margin - Non-GAAP |  | 37.0 | % |  | 33.4 | % |  | 36.4 | % |  | 34.3 | % |
| Operating expenses - GAAP |  | $ | 153,462 |  |  | $ | 135,946 |  |  | $ | 296,233 |  |  | $ | 280,262 |  |
| Less: Share-based compensation expense |  | 7,812 |  |  | 5,726 |  |  | 15,654 |  |  | 11,637 |  |
| Less: Amortization of intangible assets and acquisition-related costs |  | 1,748 |  |  | 168 |  |  | 3,041 |  |  | 336 |  |
| Less: Restructuring charges (credits), net |  | 74 |  |  | 3,146 |  |  | (11 | ) |  | 14,684 |  |
| Less: Investigation and related expenses |  | — |  |  | 321 |  |  | 612 |  |  | 4,370 |  |
| Operating expenses - Non-GAAP |  | $ | 143,828 |  |  | $ | 126,585 |  |  | $ | 276,937 |  |  | $ | 249,235 |  |
| % of net sales - GAAP |  | 27.2 | % |  | 26.2 | % |  | 28.4 | % |  | 29.0 | % |
| % of net sales - Non - GAAP |  | 25.5 | % |  | 24.4 | % |  | 26.5 | % |  | 25.8 | % |
| Operating income - GAAP |  | $ | 53,411 |  |  | $ | 36,571 |  |  | $ | 79,266 |  |  | $ | 50,188 |  |
| Share-based compensation expense |  | 8,450 |  |  | 6,306 |  |  | 16,967 |  |  | 12,822 |  |
| Amortization of intangible assets |  | 2,159 |  |  | 168 |  |  | 3,867 |  |  | 336 |  |
| Purchase accounting effect on inventory |  | — |  |  | — |  |  | 703 |  |  | — |  |
| Acquisition-related costs |  | 752 |  |  | — |  |  | 1,247 |  |  | — |  |
| Restructuring charges (credits), net |  | 74 |  |  | 3,146 |  |  | (11 | ) |  | 14,684 |  |
| Investigation and related expenses |  | — |  |  | 321 |  |  | 612 |  |  | 4,370 |  |
| Operating income - Non - GAAP |  | $ | 64,846 |  |  | $ | 46,512 |  |  | $ | 102,651 |  |  | $ | 82,400 |  |
| % of net sales - GAAP |  | 9.5 | % |  | 7.1 | % |  | 7.6 | % |  | 5.2 | % |
| % of net sales - Non - GAAP |  | 11.5 | % |  | 9.0 | % |  | 9.8 | % |  | 8.5 | % |
| Net income from continuing operations - GAAP |  | $ | 47,045 |  |  | $ | 30,452 |  |  | $ | 68,986 |  |  | $ | 43,312 |  |
| Share-based compensation expense |  | 8,450 |  |  | 6,306 |  |  | 16,967 |  |  | 12,822 |  |
| Amortization of intangible assets |  | 2,159 |  |  | 168 |  |  | 3,867 |  |  | 336 |  |
| Purchase accounting effect on inventory |  | — |  |  | — |  |  | 703 |  |  | — |  |
| Acquisition-related costs |  | 752 |  |  | — |  |  | 1,247 |  |  | — |  |
| Restructuring charges (credits), net |  | 74 |  |  | 3,146 |  |  | (11 | ) |  | 14,684 |  |
| Investigation and related expenses |  | — |  |  | 321 |  |  | 612 |  |  | 4,370 |  |
| Loss (gain) on equity-method investment |  | (171 | ) |  | 77 |  |  | (172 | ) |  | 180 |  |
| Non-GAAP income tax adjustment |  | (379 | ) |  | 658 |  |  | (1,054 | ) |  | (3,171 | ) |
| Net income from continuing operations - Non - GAAP |  | $ | 57,930 |  |  | $ | 41,128 |  |  | $ | 91,145 |  |  | $ | 72,533 |  |
| Net income from continuing operations per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  | $ | 0.28 |  |  | $ | 0.18 |  |  | $ | 0.42 |  |  | $ | 0.26 |  |
| Diluted - Non - GAAP |  | $ | 0.35 |  |  | $ | 0.25 |  |  | $ | 0.55 |  |  | $ | 0.44 |  |
| Shares used to compute net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP and Non - GAAP |  | 165,549 |  |  | 165,841 |  |  | 164,926 |  |  | 166,352 |  |

[0001032975-16-000103:8k_2_02:38]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
| SHARE-BASED COMPENSATION EXPENSE |  | Three Months Ended |  | Six Months Ended |
|  |  | September 30, |  | September 30, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Share-based Compensation Expense |  |  |  |  |  |  |  |  |
| Cost of goods sold |  | $ | 638 |  |  | $ | 580 |  |  | $ | 1,313 |  |  | $ | 1,185 |  |
| Marketing and selling |  | 3,244 |  |  | 1,997 |  |  | 6,681 |  |  | 4,061 |  |
| Research and development |  | 917 |  |  | 655 |  |  | 1,831 |  |  | 1,328 |  |
| General and administrative |  | 3,651 |  |  | 3,074 |  |  | 7,142 |  |  | 6,248 |  |
| Restructuring |  | — |  |  | — |  |  | — |  |  | 7 |  |
| Total share-based compensation expense |  | 8,450 |  |  | 6,306 |  |  | 16,967 |  |  | 12,829 |  |
| Income tax benefit |  | (1,886 | ) |  | (1,160 | ) |  | (3,701 | ) |  | (2,497 | ) |
| Total share-based compensation expense, net of income tax |  | $ | 6,564 |  |  | $ | 5,146 |  |  | $ | 13,266 |  |  | $ | 10,332 |  |

[0001032975-16-000103:8k_2_02:39]
(A) Preliminary valuation from the business acquisitions

[0001032975-16-000103:8k_2_02:40]
The preliminary purchase price allocations from the business acquisitions during the current periods are included in the tables. The fair value of identifiable intangible assets acquired was based on estimates and assumptions made by us at the time of acquisitions. As additional information becomes available, such as finalization of the estimated fair value of the assets acquired and liabilities assumed and the fair value of contingent consideration, we may revise our preliminary or interim purchase price allocations during the remainder of the measurement periods(which will not exceed 12 months from the acquisition dates). Any such revisions or changes may be material as we finalize the fair values of the tangible and intangible assets acquired and liabilities assumed, and may have a material impact over the results of operations.

[0001032975-16-000103:8k_2_02:41]
(B) Non-GAAP Financial Measures

[0001032975-16-000103:8k_2_02:42]
To supplement our condensed consolidated financial results prepared in accordance with GAAP, we use a number of financial measures, both GAAP and non-GAAP, in analyzing and assessing our overall business performance, for making operating decisions and for forecasting and planning future periods. We consider the use of non-GAAP financial measures helpful in assessing our current financial performance, ongoing operations and prospects for the future as well as understanding financial and business trends relating to our financial condition and results of operations.

[0001032975-16-000103:8k_2_02:43]
While we use non-GAAP financial measures as a tool to enhance our understanding of certain aspects of our financial performance and to provide incremental insight into the underlying factors and trends affecting both our performance and our cash-generating potential, we do not consider these measures to be a substitute for, or superior to, the information provided by GAAP financial measures. Consistent with this approach, we believe that disclosing non-GAAP financial measures to the readers of our financial statements provides useful supplemental data that, while not a substitute for GAAP financial measures, can offer insight in the review of our financial and operational performance and enables investors to more fully understand trends in our current and future performance. In assessing our business during the quarter ended June 30, 2016, we excluded items in the following general categories, each of which are described below:

[0001032975-16-000103:8k_2_02:44]
Share-based compensation expenses. We believe that providing non-GAAP measures excluding share-based compensation expense, in addition to the GAAP measures, allows for a more transparent comparison of our financial results from period to period. We prepare and maintain our budgets and forecasts for future periods on a basis consistent with this non-GAAP financial measure. Further, companies use a variety of types of equity awards as well as a variety of methodologies, assumptions and estimates to determine share-based compensation expense. We believe that excluding share-based compensation expense enhances our ability and the ability of investors to understand the impact of non-cash share-based compensation on our operating results and to compare our results against the results of other companies.

[0001032975-16-000103:8k_2_02:45]
Amortization of intangible assets. We incur intangible asset amortization expense, primarily in connection with our acquisitions of various businesses and technologies. The amortization of purchased intangibles varies depending on the level of acquisition activity. We exclude these various charges in budgeting, planning and forecasting future periods and we believe that providing the non-GAAP measures excluding these various non-cash charges, as well as the

[0001032975-16-000103:8k_2_02:46]
GAAP measures, provides additional insight when comparing our operating expenses and financial results from period to period.

[0001032975-16-000103:8k_2_02:47]
Purchase accounting effect on inventory. Business combination accounting principles require us to measure acquired inventory at fair value. The fair value of inventory reflects the acquired company’s cost of manufacturing plus a portion of the expected profit margin. The non-GAAP adjustment excludes the expected profit margin component that is recorded under business combination accounting principles associated with our business acquisitions. We believe the adjustment is useful to investors because such charges are not reflective of our ongoing operations.

[0001032975-16-000103:8k_2_02:48]
Acquisition-related costs.  We incurred expenses in connection with our acquisitions which we generally would not have otherwise incurred in the periods presented as a part of our continuing operations. Acquisition related costs include all incremental expenses incurred to effect a business combination. We believe that providing the non-GAAP measures excluding these costs, as well as the GAAP measures, assists our investors because such costs are not reflective of our ongoing operating results.

[0001032975-16-000103:8k_2_02:49]
Restructuring charges (credits). These expenses are associated with re-aligning our business strategies based on current economic conditions. We have undertaken several restructuring plans in recent years. In connection with our restructuring initiatives, we incurred restructuring charges related to employee terminations, facility closures and early cancellation of certain contracts. We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges (credits) are not reflective of our ongoing operating results in the current period.

[0001032975-16-000103:8k_2_02:50]
Gain (loss) on equity-method investment. We recognized gain (loss) related our investments in various privately-held companies, which varies depending on the operational and financial performance of the privately-held companies in which we invested. We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges are not reflective of our ongoing operations.

[0001032975-16-000103:8k_2_02:51]
Investigation and related expenses.  These expenses are forensic accounting, audit, consulting and legal fees related to the Audit Committee’s investigation and the formal investigation by and settlement with the Securities and Exchange Commission (SEC), together with accruals based on settlement with the SEC. We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges are not reflective of our ongoing operations.

[0001032975-16-000103:8k_2_02:52]
Non-GAAP income tax adjustment.  Non-GAAP income tax adjustment primarily measures the income tax effect of non-GAAP adjustments excluded above and other events; the determination of which is based upon the nature of the underlying items, the mix of income and losses in jurisdictions and the relevant tax rates in which we operate.

[0001032975-16-000103:8k_2_02:53]
Each of the non-GAAP financial measures described above, and used in this press release, should not be considered in isolation from, or as a substitute for, a measure of financial performance prepared in accordance with GAAP. Further, investors are cautioned that there are inherent limitations associated with the use of each of these non-GAAP financial measures as an analytical tool. In particular, these non-GAAP financial measures are not based on a comprehensive set of accounting rules or principles and many of the adjustments to the GAAP financial measures reflect the exclusion of items that are recurring and may be reflected in the Company’s financial results for the foreseeable future. We compensate for these limitations by providing specific information in the reconciliation included in this press release regarding the GAAP amounts excluded from the non-GAAP financial measures. In addition, as noted above, we evaluate the non-GAAP financial measures together with the most directly comparable GAAP financial information.

[0001032975-16-000103:8k_2_02:54]
Additional Supplemental Financial Information - Constant Currency

[0001032975-16-000103:8k_2_02:55]
In addition, Logitech presents percentage sales growth in constant currency to show performance unaffected by fluctuations in currency exchange rates.  Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales. Sales for the three months ended September 30, 2016 compared to sales for the three months ended September 30, 2015 increased 9 percent in both constant currency and U.S. Dollars. Retail sales for the three months ended September 30, 2016 compared to retail sales for the three months ended September 30, 2015 grew 14 percent in both constant currency and U.S. Dollars.
