# LOGI MD&A — 0001032975-16-000106


## mdna

[0001032975-16-000106:mdna:1]
[same as prior period, unchanged from 0001032975-16-000097:mdna:1]

[0001032975-16-000106:mdna:2]
[same as prior period, unchanged from 0001032975-16-000097:mdna:2]

[0001032975-16-000106:mdna:3]
[same as prior period, unchanged from 0001032975-16-000097:mdna:3]

[0001032975-16-000106:mdna:4]
[same as prior period, unchanged from 0001032975-16-000097:mdna:4]

[0001032975-16-000106:mdna:5]
[same as prior period, unchanged from 0001032975-16-000097:mdna:5]

[0001032975-16-000106:mdna:6]
[same as prior period, unchanged from 0001032975-16-000097:mdna:44]

[0001032975-16-000106:mdna:7]
[same as prior period, unchanged from 0001032975-16-000097:mdna:6]

[0001032975-16-000106:mdna:8]
| • | Gaming: The Gaming market includes products designed for PCs and gaming consoles as well as devices designed to deliver new gaming experiences such as virtual and augmented reality. The rapid rise of eSports, and the promise of new implementations in virtual and augmented reality present growth opportunities in this market. Our products in Gaming include mice and keyboards, headsets, gamepads, steering wheels, and flight and space simulation game controller products. |

[0001032975-16-000106:mdna:9]
[same as prior period, unchanged from 0001032975-16-000097:mdna:8]

[0001032975-16-000106:mdna:10]
[same as prior period, unchanged from 0001032975-16-000097:mdna:9]

[0001032975-16-000106:mdna:11]
| • | Creativity & Productivity: This market is defined by products that enhance the users’ experiences associated with computing platforms. With ever increasing connectivity globally and the consistent growth in time spent by people on these computing platforms, we believe there are meaningful growth opportunities for our products. Our continued innovation in navigation, input and content creation on these platforms can drive growth in this market despite the secular decline of new PC sales. Pointing Devices, Keyboards & Combos, Tablet & Other Accessories, and PC Webcams comprise our product categories that address this market. |

[0001032975-16-000106:mdna:12]
We sell our products to a broad network of domestic and international customers, including direct sales to retailers and e-tailers and indirect sales through distributors. Our worldwide retail network includes consumer electronics distributors, retailers, mass merchandisers, specialty electronics stores, computer and telecommunications stores, value-added resellers and online merchants.

[0001032975-16-000106:mdna:13]
[same as prior period, unchanged from 0001032975-16-000097:mdna:12]

[0001032975-16-000106:mdna:14]
[same as prior period, unchanged from 0001032975-16-000097:mdna:13]

[0001032975-16-000106:mdna:15]
[same as prior period, unchanged from 0001032975-16-000097:mdna:14]

[0001032975-16-000106:mdna:16]
[same as prior period, unchanged from 0001032975-16-000097:mdna:15]

[0001032975-16-000106:mdna:17]
30

[0001032975-16-000106:mdna:18]
On April 20, 2016, we acquired Jaybird for a purchase price of $54.2 million, including a working capital adjustment and payment of a line-of-credit on behalf of Jaybird, along with an additional earn-out of up to $45 million based on achievement of growth targets over two years (the "Jaybird Acquisition"). Jaybird is a leader in wireless audio wearables for sports and active lifestyles, and the acquisition of Jaybird expands our long-term growth potential in our Music market.

[0001032975-16-000106:mdna:19]
On September 15, 2016, we completed the acquisition of the Saitek product line for a total consideration of approximately $13.0 million (the "Saitek Acquisition"). Out of the total consideration, $6.7 million was attributed to intangible assets, $4.9 million was attributed to goodwill, and $1.4 million was attributed to net tangible assets acquired. The Saitek Acquisition is expected to enhance the breadth and depth of our product offerings and expand our engineering capabilities in simulation products. There is no revenue from Saitek product line during the three months ended September 30, 2016.

[0001032975-16-000106:mdna:20]
[same as prior period, unchanged from 0001032975-16-000097:mdna:18]

[0001032975-16-000106:mdna:21]
Our net sales for the three and six months ended September 30, 2016 increased 9% and 8% compared to the three and six months ended September 30, 2015 due to stronger retail sales, partially offset by our exit of the OEM business in the quarter ended December 31, 2015. The results of operations for Jaybird have been included in our condensed consolidated statements of operations from the acquisition date. For the three and six months ended September 30, 2016, Jaybird contributed $15.6 million and $29.9 million to net sales, respectively.

[0001032975-16-000106:mdna:22]
Our retail sales for the three months ended September 30, 2016 increased 14% compared to the three months ended September 30, 2015. Retail sales increased 10%, 22% and 8% in the Americas ("AMR"), EMEA and Asia Pacific, respectively.  Our retail sales for the six months ended September 30, 2016 increased 13% compared to the six months ended September 30, 2015. Retail sales increased 9%, 23% and 10% in AMR, EMEA and Asia Pacific, respectively.

[0001032975-16-000106:mdna:23]
Our gross margin for the three months ended September 30, 2016 increased to 36.7% from 33.3% for the three months ended September 30, 2015. The increases in gross margin for the current quarter were primarily driven by product cost reductions and improvement in product mix due to exit of our OEM products in previous fiscal year, partially offset by amortization of intangible assets from business acquisitions.

[0001032975-16-000106:mdna:24]
Our gross margin for the six months ended September 30, 2016 increased to 36.0% from 34.2% for the six months ended September 30, 2015. The increases in gross margin were primarily driven by product cost reductions and improvement in product mix due to exit of our OEM products in previous fiscal year, partially offset by amortization of intangible assets and purchase accounting effect on inventory from business acquisitions.

[0001032975-16-000106:mdna:25]
Operating expenses for the three months ended September 30, 2016 were 27.2% of net sales, compared to 26.2% in the same period of the prior fiscal year. Operating expenses for the six months ended September 30, 2016 were 28.4% of net sales, compared to 29.0% in the same period of the prior fiscal year. The increase in the current quarter was primarily driven by higher personnel-related costs due to increased headcount, business acquisitions completed during the first half of fiscal year 2017 and higher variable compensation linked to strong performance in the first half of the fiscal year, and amortization of intangibles from the business acquisitions, partially offset by cost savings and a decrease in restructuring charges.

[0001032975-16-000106:mdna:26]
Net income from continuing operations for the three and six months ended September 30, 2016 was $47.0 million and $69.0 million, respectively, compared to $30.5 million and $43.3 million for the three and six months ended September 30, 2015, respectively.

[0001032975-16-000106:mdna:27]
Given our global sales presence and the reporting of our financial results in U.S. Dollars, our financial results could be affected by shifts in currency exchange rates. See “Results of Operations” for information on the effect of currency exchange results on our net sales. If the U.S. Dollar becomes stronger in comparison to other currencies, it will also affect our results of operations in future periods.

[0001032975-16-000106:mdna:28]
[same as prior period, unchanged from 0001032975-16-000097:mdna:26]

[0001032975-16-000106:mdna:29]
[same as prior period, unchanged from 0001032975-16-000097:mdna:27]

[0001032975-16-000106:mdna:30]
We believe our future growth will be determined by our ability to rapidly create innovative products across multiple digital platforms, including gaming, digital music devices, video and computing. The following discussion represents key trends specific to our market opportunities.

[0001032975-16-000106:mdna:31]
[same as prior period, unchanged from 0001032975-16-000097:mdna:29]

[0001032975-16-000106:mdna:32]
Music:  The music market grew during the first six months of fiscal year 2017, driven by growing consumption of music through mobile devices such as smartphones and tablets. This market growth, together with our investments in the UE brand, our introduction of new products, acquisitions of new portfolios and our ability to gain market share, has driven our growth in this market.

[0001032975-16-000106:mdna:33]
Gaming:  The PC Gaming platform continues to show strong growth as online gaming and multi-platform experiences gain greater popularity and gaming content becomes increasingly more demanding. We believe Logitech is well positioned to benefit from the gaming market growth as well as acquisitions of new portfolios.

[0001032975-16-000106:mdna:34]
[same as prior period, unchanged from 0001032975-16-000097:mdna:32]

[0001032975-16-000106:mdna:35]
Home:  This market increased in fiscal year 2016 and has continued growing in fiscal year 2017.

[0001032975-16-000106:mdna:36]
[same as prior period, unchanged from 0001032975-16-000097:mdna:34]

[0001032975-16-000106:mdna:37]
Business Seasonality, Product Introductions and Acquisitions

[0001032975-16-000106:mdna:38]
We have historically experienced higher net sales in our third fiscal quarter ending December 31, compared to other fiscal quarters in our fiscal year, due in part to seasonal holiday demand. Additionally, new product introductions and acquisitions may significantly impact net sales and revenue growth rates, product costs, gross profit margin, and operating expenses. Product introductions can also impact our net sales to our distribution channels as these channels are filled with new product inventory following a product introduction, and often channel inventory of an earlier model product declines as the next related major product launch approaches. Net sales can also be affected when consumers and distributors anticipate a product introduction. However, neither historical seasonal patterns nor historical patterns of product introductions should be considered reliable indicators of our future pattern of product introductions, future net sales or financial performance.

[0001032975-16-000106:mdna:39]
[same as prior period, unchanged from 0001032975-16-000097:mdna:39]

[0001032975-16-000106:mdna:40]
[same as prior period, unchanged from 0001032975-16-000097:mdna:40]

[0001032975-16-000106:mdna:41]
[same as prior period, unchanged from 0001032975-16-000097:mdna:41]

[0001032975-16-000106:mdna:42]
We base our estimates on historical experience and on various other assumptions we believe to be reasonable under the circumstances. Although these estimates are based on management's best knowledge of current events and actions that may impact us in the future, actual results could differ from those estimates.

[0001032975-16-000106:mdna:43]
Management has discussed the development, selection and disclosure of these critical accounting estimates with the Audit Committee of the Board of Directors.

[0001032975-16-000106:mdna:44]
Accounting for business combinations requires us to make significant estimates and assumptions, especially at the acquisition date with respect to tangible and intangible assets acquired and liabilities assumed and pre-acquisition contingencies. We use our best estimates and assumptions to accurately assign fair value to the tangible and intangible assets acquired and liabilities assumed at the acquisition date.

[0001032975-16-000106:mdna:45]
[same as prior period, unchanged from 0001032975-16-000097:mdna:46]

[0001032975-16-000106:mdna:46]
[same as prior period, unchanged from 0001032975-16-000097:mdna:47]

[0001032975-16-000106:mdna:47]
| • | assumptions regarding the estimated useful life of the acquired intangibles; |

[0001032975-16-000106:mdna:48]
| • | discount rates. |

[0001032975-16-000106:mdna:49]
[same as prior period, unchanged from 0001032975-16-000097:mdna:50]

[0001032975-16-000106:mdna:50]
The economic useful life of the developed technology from the business acquisitions was determined based on the technology cycle related to developed technology of existing products, as well as the cash flows over the forecasted periods.

[0001032975-16-000106:mdna:51]
The economic useful life of the customer relationships from the business acquisitions was determined based on historical customer turnover rates and the industry benchmarks.

[0001032975-16-000106:mdna:52]
The economic useful life of the trade name from the business acquisitions was determined based on the expected life of the trade name and the cash flows anticipated over the forecasted periods.

[0001032975-16-000106:mdna:53]
The acquisition-related contingent consideration liability arising from the Jaybird Acquisition (see "Note 3 - Business Acquisitions" to the condensed consolidated financial statements for more information) represents the future potential earn-out payments of up to $45 million based on the achievement of certain net revenue growth targets over approximately a two year period. If the net revenue growth targets are met, we will pay $25 million and $20 million in fiscal year 2018 and 2019, respectively.  The fair value of the earn-out was determined by using a Monte Carlo Simulation that includes significant unobservable inputs such as a risk-adjusted discount rate of 16% and projected revenues of Jaybird over the earn-out period. The fair-value of the earn-out at the acquisition date of $18.0 million was recorded as of the acquisition date. Any changes to the significant unobservable inputs used could have a material impact on future results. Actual payment of contingent consideration in the future could be different from the current fair value of the contingent consideration. The fair value of the contingent consideration is remeasured at each reporting period based on the inputs on the date of remeasurement. The fair value of the contingent consideration was $18 million as of September 30, 2016.

[0001032975-16-000106:mdna:54]
There have been no other new or material changes to the critical accounting policies and estimates discussed in our Annual Report on Form 10-K for the fiscal year ended March 31, 2016 that are of significance, or potential significance, to the Company.

[0001032975-16-000106:mdna:55]
Adoption of New Accounting Guidance

[0001032975-16-000106:mdna:56]
In August 2016, the FASB issued ASU 2016-15 "Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments". The amendment gives guidance and reduces diversity in practice with respect to certain types of cash flows. We have early adopted this guidance during the second quarter of fiscal year 2017 and the adoption did not impact our consolidated financial statements.

[0001032975-16-000106:mdna:57]
[same as prior period, unchanged from 0001032975-16-000097:mdna:56]

[0001032975-16-000106:mdna:58]
We refer to our net sales growth rates excluding the impact of currency exchange rate fluctuations as "constant dollar" sales growth rates.  Percentage of constant dollar sales growth is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales.

[0001032975-16-000106:mdna:59]
[same as prior period, unchanged from 0001032975-16-000097:mdna:58]

[0001032975-16-000106:mdna:60]
[same as prior period, unchanged from 0001032975-16-000097:mdna:59]

[0001032975-16-000106:mdna:61]
Net sales by channel for the three and six months ended September 30, 2016 and 2015 were as follows (Dollars in thousands):

[0001032975-16-000106:mdna:62]
|  |  | Three Months EndedSeptember 30, |  | Six Months Ended September 30, |
|  |  | 2016 |  | 2015 |  | Change |  | 2016 |  | 2015 |  | Change |
| Retail |  | $ | 564,304 |  |  | $ | 496,263 |  |  | 14 | % |  | $ | 1,044,168 |  |  | $ | 921,651 |  |  | 13 | % |
| OEM |  | — |  |  | 22,231 |  |  | (100 | ) |  | — |  |  | 44,529 |  |  | (100 | ) |
| Total net sales |  | $ | 564,304 |  |  | $ | 518,494 |  |  | 9 |  |  | $ | 1,044,168 |  |  | $ | 966,180 |  |  | 8 |  |

[0001032975-16-000106:mdna:63]
[same as prior period, unchanged from 0001032975-16-000097:mdna:62]

[0001032975-16-000106:mdna:64]
Our net retail sales in the three and six months ended September 30, 2016 increased 14% and 13%, respectively, compared to the same periods of the prior fiscal year. Sales increased across all three regions during the three and six months ended September 30, 2016. If currency exchange rates had been constant in the three and six months ended September 30, 2016 and 2015, our constant dollar retail sales would have increased by 14% and 14%, respectively. The increases for both periods include the net sales resulting from the Jaybird Acquisition completed in the first quarter of fiscal year 2017 (see Note 3 - "Business Acquisitions" to the condensed consolidated financial statements).

[0001032975-16-000106:mdna:65]
OEM:

[0001032975-16-000106:mdna:66]
The decline was due to the exit from our OEM business in December 2015, and there was no revenue during the three and six months ended September 30, 2016.

[0001032975-16-000106:mdna:67]
[same as prior period, unchanged from 0001032975-16-000097:mdna:64]

[0001032975-16-000106:mdna:68]
Although our financial results are reported in U.S. Dollars, a portion of our sales were generated in currencies other than the U.S. Dollar, such as the Euro, Chinese Renminbi, Japanese Yen, Canadian Dollar, Taiwan Dollar, British Pound and Australian Dollar. For example, during the three months ended September 30, 2016, 50% of our net sales were denominated in currencies other than the U.S. Dollar.

[0001032975-16-000106:mdna:69]
[same as prior period, unchanged from 0001032975-16-000097:mdna:66]

[0001032975-16-000106:mdna:70]
The following table presents the change in retail sales by region for the three and six months ended September 30, 2016, compared to the three and six months ended September 30, 2015:

[0001032975-16-000106:mdna:71]
|  | Three Months EndedSeptember 30, 2016Change in Sales |  | Six Months EndedSeptember 30, 2016Change in Sales |
| Americas | 10 | % |  | 9 | % |
| EMEA | 22 |  |  | 23 |  |
| Asia Pacific | 8 |  |  | 10 |  |

[0001032975-16-000106:mdna:72]
[same as prior period, unchanged from 0001032975-16-000097:mdna:69]

[0001032975-16-000106:mdna:73]
Retail sales in the Americas region increased 10% and 9%, respectively, during the three and six months ended September 30, 2016, compared to the same periods of the prior fiscal year. If currency exchange rates had been constant in the three and six months ended September 30, 2016 and 2015, our constant dollar retail sales would have increased 11% and 9%, respectively, in the Americas. The increases were driven by Audio PC & Wearables, Video Collaboration, Mobile Speakers and Gaming.

[0001032975-16-000106:mdna:74]
34

[0001032975-16-000106:mdna:75]
[same as prior period, unchanged from 0001032975-16-000097:mdna:71]

[0001032975-16-000106:mdna:76]
Retail sales in the EMEA region increased 22% and 23.0%, respectively, during the three and six months ended September 30, 2016, compared to the same periods of the prior fiscal year. If currency exchange rates had been constant in the three and six months ended September 30, 2016 and 2015, our constant dollar retail sales would have increase 23.0% for both periods. The increases were driven by several of our product categories, with particular strength in Mobile Speakers and Video Collaboration.

[0001032975-16-000106:mdna:77]
[same as prior period, unchanged from 0001032975-16-000097:mdna:73]

[0001032975-16-000106:mdna:78]
Retail sales in the Asia Pacific region increased 8% and 10%, respectively, during the three and six months ended September 30, 2016, compared to the same periods of the prior fiscal year. If currency exchange rates had been constant in the three and six months ended September 30, 2016 and 2015, our constant dollar retail sales would have increased 7% and 10%, respectively.

[0001032975-16-000106:mdna:79]
[same as prior period, unchanged from 0001032975-16-000097:mdna:75]

[0001032975-16-000106:mdna:80]
Net retail sales by product category for the three and six months ended September 30, 2016 and 2015 were as follows (Dollars in thousands):

[0001032975-16-000106:mdna:81]
|  |  | Three Months EndedSeptember 30, |  | Six Months Ended September 30, |
|  |  | 2016 |  | 2015 |  | Change |  | 2016 |  | 2015 |  | Change |
| Mobile Speakers |  | $ | 97,172 |  |  | $ | 80,550 |  |  | 21 | % |  | $ | 154,468 |  |  | $ | 121,094 |  |  | 28 | % |
| Audio-PC & Wearables |  | 62,254 |  |  | 46,342 |  |  | 34 |  |  | 118,833 |  |  | 92,041 |  |  | 29 |  |
| Gaming |  | 79,193 |  |  | 67,624 |  |  | 17 |  |  | 135,693 |  |  | 111,294 |  |  | 22 |  |
| Video Collaboration |  | 28,581 |  |  | 20,059 |  |  | 42 |  |  | 52,491 |  |  | 41,235 |  |  | 27 |  |
| Home Control |  | 11,807 |  |  | 12,610 |  |  | (6 | ) |  | 22,974 |  |  | 22,864 |  |  | — |  |
| Pointing Devices |  | 123,300 |  |  | 124,668 |  |  | (1 | ) |  | 240,083 |  |  | 241,653 |  |  | (1 | ) |
| Keyboards & Combos |  | 116,516 |  |  | 102,098 |  |  | 14 |  |  | 234,535 |  |  | 207,927 |  |  | 13 |  |
| Tablet & Other Accessories |  | 20,614 |  |  | 18,549 |  |  | 11 |  |  | 34,499 |  |  | 37,358 |  |  | (8 | ) |
| PC Webcams |  | 24,307 |  |  | 23,360 |  |  | 4 |  |  | 49,569 |  |  | 45,041 |  |  | 10 |  |
| Other (1) |  | 560 |  |  | 403 |  |  | 39 |  |  | 1,023 |  |  | 1,144 |  |  | (11 | ) |
| Total net retail sales |  | $ | 564,304 |  |  | $ | 496,263 |  |  | 14 |  |  | $ | 1,044,168 |  |  | $ | 921,651 |  |  | 13 |  |

[0001032975-16-000106:mdna:82]
[same as prior period, unchanged from 0001032975-16-000097:mdna:78]

[0001032975-16-000106:mdna:83]
Net Retail Sales by Product Categories

[0001032975-16-000106:mdna:84]
[same as prior period, unchanged from 0001032975-16-000097:mdna:80]

[0001032975-16-000106:mdna:85]
[same as prior period, unchanged from 0001032975-16-000097:mdna:81]

[0001032975-16-000106:mdna:86]
[same as prior period, unchanged from 0001032975-16-000097:mdna:82]

[0001032975-16-000106:mdna:87]
Retail sales of Mobile Speakers increased 21% and 28%, respectively, for the three and six months ended September 30, 2016, compared to the same periods of the prior fiscal year. Mobile Speaker sales increased for both periods primarily due to the introduction of the UE Roll 2 in the first quarter of fiscal year 2017 and UE Boom 2 in the second quarter of fiscal year 2016 as well as the continued success of the UE Megaboom.

[0001032975-16-000106:mdna:88]
[same as prior period, unchanged from 0001032975-16-000097:mdna:84]

[0001032975-16-000106:mdna:89]
Our retail Audio-PC & Wearables category comprises PC speakers, PC headsets and Jaybird earbuds.

[0001032975-16-000106:mdna:90]
Audio-PC & Wearables sales increased 34% and 29%, respectively, for the three and six months ended September 30, 2016, compared to the same periods of the prior fiscal year. The increases for both periods were primarily driven by the Jaybird X2 Sport Bluetooth and the new product introduction of Jaybird Freedom F5 earbuds,

[0001032975-16-000106:mdna:91]
resulting from the Jaybird Acquisition in the first quarter of fiscal year 2017 (see Note 3 - "Business Acquisitions" to the condensed consolidated financial statements).

[0001032975-16-000106:mdna:92]
[same as prior period, unchanged from 0001032975-16-000097:mdna:87]

[0001032975-16-000106:mdna:93]
[same as prior period, unchanged from 0001032975-16-000097:mdna:88]

[0001032975-16-000106:mdna:94]
[same as prior period, unchanged from 0001032975-16-000097:mdna:89]

[0001032975-16-000106:mdna:95]
Retail sales of Gaming increased 17% and 22%, respectively, for the three and six months ended September 30, 2016, compared to the same periods of the prior fiscal year.  The significant increases for both periods were primarily driven by the new product launch of our G502 Proteus Spectrum gaming mouse, G900 Chaos Spectrum gaming mouse and G910 Orion Spark gaming keyboard in the first half of fiscal year 2017.

[0001032975-16-000106:mdna:96]
[same as prior period, unchanged from 0001032975-16-000097:mdna:91]

[0001032975-16-000106:mdna:97]
[same as prior period, unchanged from 0001032975-16-000097:mdna:92]

[0001032975-16-000106:mdna:98]
[same as prior period, unchanged from 0001032975-16-000097:mdna:93]

[0001032975-16-000106:mdna:99]
Retail sales of Video Collaboration increased 42% and 27%, respectively, in the three and six months ended September 30, 2016, compared to the same periods of the prior fiscal year.  The increases in both periods were primarily due to growth in our conference cams, including the Logitech Group conference camera introduced in the fourth quarter of fiscal year 2016, in addition to strong sales from our C930e Webcam.

[0001032975-16-000106:mdna:100]
[same as prior period, unchanged from 0001032975-16-000097:mdna:95]

[0001032975-16-000106:mdna:101]
[same as prior period, unchanged from 0001032975-16-000097:mdna:96]

[0001032975-16-000106:mdna:102]
[same as prior period, unchanged from 0001032975-16-000097:mdna:97]

[0001032975-16-000106:mdna:103]
Home Control retail sales decreased 6% and remained flat, respectively, during the three and six months ended September 30, 2016, compared to the same periods of the prior fiscal year.

[0001032975-16-000106:mdna:104]
Creativity & Productivity Market:

[0001032975-16-000106:mdna:105]
[same as prior period, unchanged from 0001032975-16-000097:mdna:100]

[0001032975-16-000106:mdna:106]
[same as prior period, unchanged from 0001032975-16-000097:mdna:101]

[0001032975-16-000106:mdna:107]
Retail sales of Pointing Devices decreased 1% in both the three and six months ended September 30, 2016, compared to the same periods of the prior fiscal year.

[0001032975-16-000106:mdna:108]
Keyboards & Combos

[0001032975-16-000106:mdna:109]
[same as prior period, unchanged from 0001032975-16-000097:mdna:104]

[0001032975-16-000106:mdna:110]
Retail sales of Keyboards & Combos increased 14% and 13%, respectively, in the three and six months ended September 30, 2016, compared to the same periods of the prior fiscal year. The sales increases for both periods were primarily driven by the strong sales of our wireless keyboard K350 and wireless keyboard K400 plus, in addition to the new product launch of our MK235 Combo in the fourth quarter of fiscal year 2016.

[0001032975-16-000106:mdna:111]
[same as prior period, unchanged from 0001032975-16-000097:mdna:106]

[0001032975-16-000106:mdna:112]
[same as prior period, unchanged from 0001032975-16-000097:mdna:107]

[0001032975-16-000106:mdna:113]
Retail sales of Tablet & Other Accessories increased 11% and decreased 8%, respectively, in the three and six months ended September 30, 2016, compared to the same periods of the prior fiscal year. The sales increase in the three months ended September 30, 2016 was driven by the new product launch of the Create Backlit Tablet Keyboard Case for the iPad Pro 9.7-Inch in the second quarter of fiscal year 2017. The sales decrease in the six months ended September 2016 reflect the declining market for iPad shipments, partially offset by the new product introduction of the Create Backlit Tablet Keyboard Case for the iPad Pro.

[0001032975-16-000106:mdna:114]
[same as prior period, unchanged from 0001032975-16-000097:mdna:109]

[0001032975-16-000106:mdna:115]
[same as prior period, unchanged from 0001032975-16-000097:mdna:110]

[0001032975-16-000106:mdna:116]
Retail PC Webcams sales increased 4% and 10%, respectively, in the three and six months ended September 30, 2016, compared to the same periods of the prior fiscal year. The increases in both periods were primarily driven by strong sales of our HD Pro Webcam C920.

[0001032975-16-000106:mdna:117]
[same as prior period, unchanged from 0001032975-16-000097:mdna:114]

[0001032975-16-000106:mdna:118]
Gross profit for the three and six months ended September 30, 2016 and 2015 was as follows (Dollars in thousands):

[0001032975-16-000106:mdna:119]
|  |  | Three Months EndedSeptember 30, |  | Six Months Ended September 30, |
|  |  | 2016 |  | 2015 |  | Change |  | 2016 |  | 2015 |  | Change |
| Net sales |  | $ | 564,304 |  |  | $ | 518,494 |  |  | 9 | % |  | $ | 1,044,168 |  |  | $ | 966,180 |  |  | 8 | % |
| Cost of goods sold |  | 356,268 |  |  | 345,977 |  |  | 3 |  |  | 665,893 |  |  | 635,730 |  |  | 5 |  |
| Amortization of intangible assets and purchase accounting effect on inventory |  | 1,163 |  |  | — |  |  | NM |  |  | 2,776 |  |  | — |  |  | NM |  |
| Gross profit |  | $ | 206,873 |  |  | $ | 172,517 |  |  | 20 |  |  | $ | 375,499 |  |  | $ | 330,450 |  |  | 14 |  |
| Gross margin |  | 36.7 | % |  | 33.3 | % |  |  |  | 36.0 | % |  | 34.2 | % |  |  |  |

[0001032975-16-000106:mdna:120]
[same as prior period, unchanged from 0001032975-16-000097:mdna:117]

[0001032975-16-000106:mdna:121]
Gross profit consists of net sales, less cost of goods sold (which includes materials, direct labor and related overhead costs, costs of manufacturing facilities, royalties, costs of purchasing components from outside suppliers, distribution costs, warranty costs, customer support, outside processing costs and write-down of inventories, and less amortization of certain intangible assets and purchase accounting effect on inventory.  Purchase accounting effect on inventory was $0.7 million for the six months ended September 30, 2016. Amortization of intangible assets from developed technology was $1.2 million and $2.1 million, respectively, for the three and six months ended September 30, 2016 as a result of the business acquisitions.

[0001032975-16-000106:mdna:122]
Gross margin increased for the three months ended September 30, 2016, compared to the same period of the prior fiscal year. The increases in gross margin for the current quarter were primarily driven by product cost reductions and improvement in product mix due to exit of our OEM products in previous fiscal year, partially offset by amortization of intangible assets from business acquisitions.

[0001032975-16-000106:mdna:123]
Gross margin increased for the six months ended September 30, 2016, compared to the same period of the prior fiscal year. The increases in gross margin were primarily driven by product cost reductions and improvement in product mix due to exit of our OEM products in previous fiscal year, partially offset by amortization of intangible assets and purchase accounting effect on inventory from business acquisitions.

[0001032975-16-000106:mdna:124]
[same as prior period, unchanged from 0001032975-16-000097:mdna:120]

[0001032975-16-000106:mdna:125]
Operating expenses for the three and six months ended September 30, 2016 and 2015 were as follows (Dollars in thousands):

[0001032975-16-000106:mdna:126]
|  |  | Three Months EndedSeptember 30, |  | Six Months Ended September 30, |
|  |  | 2016 |  | 2015 |  | Change |  | 2016 |  | 2015 |  | Change |
| Marketing and selling |  | $ | 93,792 |  |  | $ | 78,833 |  |  | 19 | % |  | $177,664 |  | $154,629 |  | 15 | % |
| % of net sales |  | 16.6 | % |  | 15.2 | % |  |  |  |  | 17.0 | % |  | 16.0 | % |  |  |  |
| Research and development |  | 32,632 |  |  | 28,725 |  |  | 14 |  |  | 64,583 |  |  | 56,727 |  |  | 14 |  |
| % of net sales |  | 5.8 | % |  | 5.5 | % |  |  |  |  | 6.2 | % |  | 5.9 | % |  |  |  |
| General and administrative |  | 25,216 |  |  | 25,074 |  |  | 1 |  |  | 50,956 |  |  | 53,886 |  |  | (5 | ) |
| % of net sales |  | 4.5 | % |  | 4.8 | % |  |  |  |  | 4.9 | % |  | 5.6 | % |  |  |  |
| Amortization of intangibles, acquisition related costs and change in fair value of earn-out |  | 1,748 |  |  | 168 |  |  | 940 |  |  | 3,041 |  |  | 336 |  |  | 805 |  |
| % of net sales |  | 0.3 | % |  | — | % |  |  |  | 0.3 | % |  | — | % |  |  |
| Restructuring charges (credits), net |  | 74 |  |  | 3,146 |  |  | (98 | ) |  | (11 | ) |  | 14,684 |  |  | (100 | ) |
| % of net sales |  | — | % |  | 0.6 | % |  |  |  |  | — | % |  | 1.5 | % |  |  |  |
| Total operating expenses |  | $ | 153,462 |  |  | $ | 135,946 |  |  | 13 |  |  | $296,233 |  | $280,262 |  | 6 |  |
| % of net sales |  | 27.2 | % |  | 26.2 | % |  |  |  |  | 28.4 | % |  | 29.0 | % |  |  |  |

[0001032975-16-000106:mdna:127]
[same as prior period, unchanged from 0001032975-16-000097:mdna:123]

[0001032975-16-000106:mdna:128]
Marketing and selling expenses consist of personnel and related overhead, corporate and product marketing, advertising, trade shows, customer and technical support, and facilities costs.

[0001032975-16-000106:mdna:129]
During the three months ended September 30, 2016, marketing and selling expenses increased 19%, compared to the same period of the prior fiscal year. During the six months ended September 30, 2016, marketing and selling expenses increased 15%, compared to the same period of the prior fiscal year. The increases for both periods were primarily driven by higher personnel-related costs due to increased headcount during the last twelve months to expand our marketing team to support the advertising and marketing efforts for our products, the increased headcount resulting from the Jaybird Acquisition, as well as increased variable compensation linked to stronger performance in the first half fiscal year.

[0001032975-16-000106:mdna:130]
[same as prior period, unchanged from 0001032975-16-000097:mdna:126]

[0001032975-16-000106:mdna:131]
[same as prior period, unchanged from 0001032975-16-000097:mdna:127]

[0001032975-16-000106:mdna:132]
During the three and six months ended September 30, 2016, research and development expenses increased 14%, compared to the same periods in the prior fiscal year. The increases for both periods were primarily driven by  higher personnel-related costs to support the launch of new products, increased headcount from business acquisitions, and increased variable compensation linked to stronger performance in the first half fiscal year.

[0001032975-16-000106:mdna:133]
[same as prior period, unchanged from 0001032975-16-000097:mdna:129]

[0001032975-16-000106:mdna:134]
[same as prior period, unchanged from 0001032975-16-000097:mdna:130]

[0001032975-16-000106:mdna:135]
During the three months ended September 30, 2016, general and administrative expenses increased 1%, compared to the same period in the prior fiscal year.

[0001032975-16-000106:mdna:136]
38

[0001032975-16-000106:mdna:137]
During the six months ended September 30, 2016, general and administrative expenses decreased 5%, compared to the same period in the prior fiscal year. The decrease was primarily due to a $3.5 million reduction related to the prior year's accrual for our settlement with the SEC (see "Note 12 - Commitments and Contingencies" to the condensed consolidated financial statements for more details).

[0001032975-16-000106:mdna:138]
[same as prior period, unchanged from 0001032975-16-000097:mdna:132]

[0001032975-16-000106:mdna:139]
Amortization of intangibles and acquisition-related costs consist of amortization of acquired intangible assets including customer relationships and trade names, and acquisition-related costs including legal expense, due diligence costs, and other professional costs incurred for business acquisitions.

[0001032975-16-000106:mdna:140]
The increase during the three and six months ended September 30, 2016 compared to the same periods in the prior fiscal year was primarily due to the business acquisitions completed in the first half of fiscal year 2017.  Amortization of intangible assets was $0.9 million and $1.7 million, respectively, for the three and six months ended September 30, 2016. Acquisition-related costs were $0.8 million and $1.2 million, respectively, for the three and six months ended September 30, 2016.

[0001032975-16-000106:mdna:141]
[same as prior period, unchanged from 0001032975-16-000097:mdna:135]

[0001032975-16-000106:mdna:142]
The following table summarizes restructuring-related activities during the three and six months ended September 30, 2016 (in thousands).

[0001032975-16-000106:mdna:143]
|  |  | Restructuring |
|  |  | TerminationBenefits |  | Lease ExitCosts |  | Total |
| Accrual balance at March 31, 2016 |  | $ | 6,275 |  |  | $ | 125 |  |  | $ | 6,400 |  |
| Credits, net |  | (85 | ) |  | — |  |  | (85 | ) |
| Cash payments |  | (1,908 | ) |  | (125 | ) |  | (2,033 | ) |
| Accrual balance at June 30, 2016 |  | $ | 4,282 |  |  | $ | — |  |  | $ | 4,282 |  |
| Charges |  | 74 |  |  | — |  |  | 74 |  |
| Cash payments |  | (1,473 | ) |  | — |  |  | (1,473 | ) |
| Accrual balance at September 30, 2016 |  | $ | 2,883 |  |  | $ | — |  |  | $ | 2,883 |  |

[0001032975-16-000106:mdna:144]
[same as prior period, unchanged from 0001032975-16-000097:mdna:138]

[0001032975-16-000106:mdna:145]
[same as prior period, unchanged from 0001032975-16-000097:mdna:139]

[0001032975-16-000106:mdna:146]
Other expense, net for the three and six months ended September 30, 2016 and 2015 was as follows (in thousands):

[0001032975-16-000106:mdna:147]
|  |  | Three Months EndedSeptember 30, |  | Six Months Ended September 30, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Investment gain (loss) related to deferred compensation plan |  | $ | 404 |  |  | $ | (726 | ) |  | $ | 596 |  |  | $ | (626 | ) |
| Currency exchange gain (loss), net |  | (1,250 | ) |  | 30 |  |  | (2,249 | ) |  | (1,132 | ) |
| Other |  | 163 |  |  | (41 | ) |  | (38 | ) |  | 2 |  |
|  |  | $ | (683 | ) |  | $ | (737 | ) |  | $ | (1,691 | ) |  | $ | (1,756 | ) |

[0001032975-16-000106:mdna:148]
Currency exchange gains or losses relate to balances denominated in currencies other than the functional currency in our subsidiaries, as well as to the sale of currencies, and to gains or losses recognized on currency exchange forward contracts. We do not speculate in currency positions, but we are alert to opportunities to maximize currency exchange gains and minimize currency exchange losses.

[0001032975-16-000106:mdna:149]
39

[0001032975-16-000106:mdna:150]
[same as prior period, unchanged from 0001032975-16-000097:mdna:143]

[0001032975-16-000106:mdna:151]
The provision for (benefit from) income taxes and effective tax rates for the three and six months ended September 30, 2016 and 2015 were as follows (Dollars in thousands):

[0001032975-16-000106:mdna:152]
|  |  | Three Months EndedSeptember 30, |  | Six Months Ended September 30, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Provision for income taxes |  | $ | 5,593 |  |  | $ | 5,571 |  |  | $ | 8,650 |  |  | $ | 5,564 |  |
| Effective income tax rate |  | 10.6 | % |  | 15.5 | % |  | 11.1 | % |  | 11.4 | % |

[0001032975-16-000106:mdna:153]
The change in the effective income tax rate for the three and six months ended September 30, 2016, compared to the three and six months ended September 30, 2015, is due to the mix of income and losses in the various tax jurisdictions in which we operate. In the six months ended September 30, 2015, there was a discrete tax benefit of $2.2 million from the preferential income tax rate reduction pursuant to the High and New Technology Enterprise Program in China.

[0001032975-16-000106:mdna:154]
As of September 30 and March 31, 2016, the total amount of unrecognized tax benefits due to uncertain tax positions was $72.0 million and $69.9 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-16-000106:mdna:155]
[same as prior period, unchanged from 0001032975-16-000097:mdna:148]

[0001032975-16-000106:mdna:156]
[same as prior period, unchanged from 0001032975-16-000097:mdna:149]

[0001032975-16-000106:mdna:157]
As of September 30, 2016, we had cash and cash equivalents of $395.2 million, compared to $519.2 million as of March 31, 2016. Our cash and cash equivalents consist of bank demand deposits and short-term time deposits of which 56% is held by our subsidiaries in Switzerland, 32% is held by our subsidiaries in Hong Kong and China, 3% is held by our subsidiaries in the United States, and 9% is held by subsidiaries in various other countries. We do not expect to incur any material adverse tax impact except for what has been recognized or be significantly inhibited by any country in which we do business from the repatriation of funds to Switzerland, our home domicile.

[0001032975-16-000106:mdna:158]
As of September 30, 2016, our working capital was $396.7 million, compared to $511.3 million as of March 31, 2016. The decrease was primarily due to lower cash and cash equivalents, primarily as a result of cash payments for the business acquisitions, dividend payments and share repurchases and higher accounts payable and accrued and other current liabilities, partially offset by higher accounts receivable and net inventory balances due to seasonality.

[0001032975-16-000106:mdna:159]
During the six months ended September 30, 2016, we generated $87.8 million in cash from operating activities. Our main cash inflows came from net income and increases in accounts payable and accrued liabilities, partially offset by increases in accounts receivable and inventories.  Net cash used in investing activities was $81.5 million, primarily due to $67.0 million of purchase price (net of cash acquired) for the business acquisitions (see "Note 3 - Business Acquisitions" to the condensed consolidated financial statements), including a working capital adjustment and payment of a line-of-credit on behalf of Jaybird, and $14.8 million of capital expenditures in computer hardware and software, tooling and equipment. Net cash used in financing activities was $128.4 million, primarily related to our dividend payment of $93.1 million, share repurchases of $42.9 million and tax withholdings related to net share settlements of restricted stock units ("RSUs") of $11.0 million, partially offset by $14.5 million of proceeds from sales of shares upon exercise of options and purchase rights.

[0001032975-16-000106:mdna:160]
We had several uncommitted, unsecured bank lines of credit aggregating $44.6 million as of September 30, 2016. We have not drawn down on these lines of credit as of September 30, 2016. There are no financial covenants under these lines of credit with which we must comply. As of September 30, 2016, we had outstanding bank guarantees of $12.4 million under these lines of credit.

[0001032975-16-000106:mdna:161]
[same as prior period, unchanged from 0001032975-16-000097:mdna:156]

[0001032975-16-000106:mdna:162]
|  |  | Six Months Ended September 30, |
|  |  | 2016 |  | 2015 |
| Net cash provided by (used in) operating activities |  | $ | 87,756 |  |  | $ | (14,862 | ) |
| Net cash used in investing activities |  | (81,485 | ) |  | (31,551 | ) |
| Net cash used in financing activities |  | (128,420 | ) |  | (125,953 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  | (1,845 | ) |  | 1,102 |  |
| Net decrease in cash and cash equivalents |  | $ | (123,994 | ) |  | $ | (171,264 | ) |

[0001032975-16-000106:mdna:163]
| The following amounts reflected in the table above are from discontinued operations: |  |  |
| Depreciation |  | $ | — |  |  | $ | 1,420 |  |
| Amortization of other intangible assets |  | $ | — |  |  | $ | 890 |  |
| Share-based compensation expense |  | $ | — |  |  | $ | 428 |  |
| Purchases of property, plant and equipment |  | $ | — |  |  | $ | 750 |  |
| Cash and cash equivalents, beginning of the period |  | $ | — |  |  | $ | 3,659 |  |
| Cash and cash equivalents, end of the period |  | $ | — |  |  | $ | 4,639 |  |

[0001032975-16-000106:mdna:164]
[same as prior period, unchanged from 0001032975-16-000097:mdna:159]

[0001032975-16-000106:mdna:165]
The following table presents selected financial information and statistics as of September 30, 2016 and 2015 (Dollars in thousands):

[0001032975-16-000106:mdna:166]
|  |  | Three Months EndedSeptember 30, |
|  |  | 2016 |  | 2015 |
| Accounts receivable, net |  | $ | 240,606 |  |  | $ | 264,615 |  |
| Inventories |  | $ | 268,110 |  |  | $ | 312,707 |  |
| Days sales in accounts receivable (“DSO”) (Days) (1) |  | 38 |  |  | 46 |  |
| Inventory turnover (“ITO”) (x)(2) |  | 5.3 |  |  | 4.4 |  |

[0001032975-16-000106:mdna:167]
[same as prior period, unchanged from 0001032975-16-000097:mdna:162]

[0001032975-16-000106:mdna:168]
[same as prior period, unchanged from 0001032975-16-000097:mdna:163]

[0001032975-16-000106:mdna:169]
During the six months ended September 30, 2016, we achieved $87.8 million cash inflow from operating activities, compared to a cash outflow of $14.9 million for the same period in the prior fiscal year. The primary drivers of the increase in net cash generated from operating cash flows include an increase in net income of $43.5 million for the six months ended September 30, 2016, compared to the six months ended September 30, 2015, and a higher increase in accounts payable and a lower increase in inventory in the current period, compared to the same period of the prior fiscal year, partially offset by a lower increase in accrual and other liabilities in the current period, compared to the same period of the prior  fiscal year.

[0001032975-16-000106:mdna:170]
Inventory turnover as of September 30, 2016 was higher compared to that as of September 30, 2015.  The decrease in inventories compared with September 30, 2015 was due to our continuing efforts in demand planning and production planning. If we are not successful in launching and phasing in our new products, including products from acquisitions, during the current fiscal year, or we are not able to sell these products at the prices planned, it could have a material impact on our revenue, gross profit margin, operating income, operating cash flow, and inventory turnover in the future.

[0001032975-16-000106:mdna:171]
[same as prior period, unchanged from 0001032975-16-000097:mdna:167]

[0001032975-16-000106:mdna:172]
The following table presents information on our cash flows from investing activities during the six months ended September 30, 2016 and 2015 (in thousands):

[0001032975-16-000106:mdna:173]
|  |  | Six Months Ended September 30, |
|  |  | 2016 |  | 2015 |
| Purchases of property, plant and equipment |  | $ | (14,758 | ) |  | $ | (31,277 | ) |
| Investment in privately held companies |  | (480 | ) |  | (480 | ) |
| Acquisitions, net of cash acquired |  | (66,987 | ) |  | — |  |
| Release of restricted cash |  | 715 |  |  | — |  |
| Purchase of trading investments |  | (5,271 | ) |  | (2,649 | ) |
| Proceeds from sales of trading investments |  | 5,296 |  |  | 2,855 |  |
| Net cash used in investing activities |  | $ | (81,485 | ) |  | $ | (31,551 | ) |

[0001032975-16-000106:mdna:174]
Our expenditures for property, plant and equipment during the six months ended September 30, 2016 and 2015 were primarily for computer hardware and software, tooling, equipment and leasehold improvements. The decrease in purchases of property, plant and equipment mainly arose from the building of production lines during the six months ended September 30, 2015, to accommodate our in-house manufacturing of certain products, compared with purchase from third parties, to align with our cost saving goal.

[0001032975-16-000106:mdna:175]
Our payments for the acquisitions, net of cash acquired, during the six months ended September 30, 2016, were for the Jaybird Acquisition and the Saitek Acquisition during the period (refer to "Note 3 - Business Acquisitions" to the condensed consolidated financial statements).

[0001032975-16-000106:mdna:176]
The purchases and sales of trading investments in the six months ended September 30, 2016 and 2015 represented mutual fund and money market fund activities directed by participants in a deferred compensation plan offered by one of our subsidiaries. The mutual funds and money market funds are held in a Rabbi trust.

[0001032975-16-000106:mdna:177]
[same as prior period, unchanged from 0001032975-16-000097:mdna:173]

[0001032975-16-000106:mdna:178]
The following table presents information on our cash flows from financing activities during the six months ended September 30, 2016 and 2015 (in thousands), on a total company basis:

[0001032975-16-000106:mdna:179]
|  |  | Six Months Ended September 30, |
|  |  | 2016 |  | 2015 |
| Payment of cash dividends |  | $ | (93,093 | ) |  | $ | (85,915 | ) |
| Purchases of treasury shares |  | (42,894 | ) |  | (48,802 | ) |
| Proceeds from sales of shares upon exercise of options and purchase rights |  | 14,484 |  |  | 11,103 |  |
| Tax withholdings related to net share settlements of restricted stock units |  | (11,047 | ) |  | (3,502 | ) |
| Excess tax benefits from share-based compensation |  | 4,130 |  |  | 1,163 |  |
| Net cash used in financing activities |  | $ | (128,420 | ) |  | $ | (125,953 | ) |

[0001032975-16-000106:mdna:180]
During the six months ended September 30, 2016, we declared and paid cash dividends of approximately CHF 0.56 (USD equivalent of approximately $0.57) per common share, totaling approximately $93.1 million in U.S. Dollars, out of retained earnings.  During the six months ended September 30, 2015, we declared and paid cash dividends of approximately CHF 0.51 (USD equivalent of approximately $0.53) per common share, totaling approximately $85.9 million in U.S. Dollars, out of retained earnings.

[0001032975-16-000106:mdna:181]
During the six months ended September 30, 2016 and 2015, 2.4 million and 3.5 million shares were repurchased for $42.9 million and $48.8 million, respectively.

[0001032975-16-000106:mdna:182]
During the six months ended September 30, 2016 and 2015, $11.0 million and $3.5 million, respectively, were paid for tax withholding related to the vesting for RSUs of employees.

[0001032975-16-000106:mdna:183]
42

[0001032975-16-000106:mdna:184]
[same as prior period, unchanged from 0001032975-16-000097:mdna:178]

[0001032975-16-000106:mdna:185]
[same as prior period, unchanged from 0001032975-16-000097:mdna:179]

[0001032975-16-000106:mdna:186]
In March 2015, we announced a plan to pay $250 million in cumulative dividends for fiscal year 2015 through fiscal year 2017.  During the second quarter of fiscal year 2017, we paid a cash dividend of approximately CHF 90.2 million (USD equivalent of approximately $93.1 million) out of retained earnings.  During fiscal year 2016, we paid a cash dividend of approximately CHF 83.1 million (USD equivalent of approximately $85.9 million) out of retained earnings.

[0001032975-16-000106:mdna:187]
In March 2014, our Board of Directors approved a new share buyback program, which authorizes us to purchase up to $250.0 million of our own shares. Although we enter into trading plans for systematic repurchases (e.g. 10b5-1 trading plans) from time to time, our share buyback program provides us with the opportunity to make opportunistic repurchases during periods of favorable market conditions and is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market through block trades or otherwise. Opportunistic share repurchases may be started or stopped at any time without prior notice depending on market conditions and other factors. As of September 30, 2016, the remaining amount that may be repurchased under the program is $135.5 million.

[0001032975-16-000106:mdna:188]
As noted in "Note 3 - Business Acquisitions" to our condensed consolidated financial statements, we acquired all of the equity interest of Jaybird for a purchase price of $54.2 million, including a working capital adjustment and payment of a line-of-credit on behalf of Jaybird, with an additional earn-out of up to $45 million based on the achievement of certain net revenue growth targets over two years starting July 2016. If the net revenue growth targets are met, the Company will pay $25 million and $20 million in fiscal years 2018 and 2019, respectively.

[0001032975-16-000106:mdna:189]
On September 15, 2016, the Company completed the acquisition of the Saitek product line for total consideration of approximately $13.0 million.

[0001032975-16-000106:mdna:190]
[same as prior period, unchanged from 0001032975-16-000097:mdna:183]

[0001032975-16-000106:mdna:191]
[same as prior period, unchanged from 0001032975-16-000097:mdna:184]

[0001032975-16-000106:mdna:192]
We lease facilities under operating leases, certain of which require us to pay property taxes, insurance and maintenance costs. Operating leases for facilities are generally renewable at our option and usually include escalation clauses linked to inflation. The remaining terms on our non-cancelable operating leases expire in various years through 2030. Our asset retirement obligations on these leases as of September 30, 2016 were not material.

[0001032975-16-000106:mdna:193]
[same as prior period, unchanged from 0001032975-16-000097:mdna:186]

[0001032975-16-000106:mdna:194]
As of September 30, 2016, we had fixed purchase commitments for inventory purchases made in the normal course of business to original design manufacturers, contract manufacturers and other suppliers, the majority of which are expected to be fulfilled within the next 12 months. Fixed purchase commitments for capital expenditures primarily relate to commitments for tooling for new and existing products, computer hardware, leasehold and improvements. We expect to continue making capital expenditures in the future to support product development activities and ongoing and expanded operations. Although open purchase commitments are considered enforceable and legally binding, the terms generally allow us to reschedule or adjust our requirements based on business needs prior to delivery of goods or performance of services.

[0001032975-16-000106:mdna:195]
[same as prior period, unchanged from 0001032975-16-000097:mdna:188]

[0001032975-16-000106:mdna:196]
[same as prior period, unchanged from 0001032975-16-000097:mdna:189]

[0001032975-16-000106:mdna:197]
[same as prior period, unchanged from 0001032975-16-000097:mdna:190]

[0001032975-16-000106:mdna:198]
[same as prior period, unchanged from 0001032975-16-000097:mdna:191]

[0001032975-16-000106:mdna:199]
[same as prior period, unchanged from 0001032975-16-000097:mdna:192]

[0001032975-16-000106:mdna:200]
[same as prior period, unchanged from 0001032975-16-000097:mdna:193]

[0001032975-16-000106:mdna:201]
[same as prior period, unchanged from 0001032975-16-000097:mdna:194]

[0001032975-16-000106:mdna:202]
Logitech Europe S.A., one of our wholly owned subsidiaries, guaranteed payments of third-party contract manufacturers' purchase obligations. As of September 30, 2016, the maximum amount of this guarantee was $3.8 million, of which $1.9 million of guaranteed purchase obligations were outstanding.

[0001032975-16-000106:mdna:203]
[same as prior period, unchanged from 0001032975-16-000097:mdna:196]

[0001032975-16-000106:mdna:204]
We indemnify certain of our suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of September 30, 2016, no amounts have been accrued for indemnification provisions. We do not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under our indemnification arrangements.

[0001032975-16-000106:mdna:205]
[same as prior period, unchanged from 0001032975-16-000097:mdna:198]

[0001032975-16-000106:mdna:206]
The Stock Purchase Agreement that we entered into in connection with the investment by three venture capital firms in Lifesize contains representations, warranties and covenants of Logitech and Lifesize to the Investors. Subject to certain limitations, we have agreed to indemnify the Investors and certain persons related to the Investors for certain losses resulting from breaches of or inaccuracies in such representations, warranties and covenants as well as certain other obligations, including third party expenses, restructuring costs and pre-closing tax obligations of Lifesize.

[0001032975-16-000106:mdna:207]
Legal Proceedings

[0001032975-16-000106:mdna:208]
From time to time we are involved in claims and legal proceedings that arise in the ordinary course of our business. We are currently subject to several such claims and a small number of legal proceedings. We believe that these matters lack merit and we intend to vigorously defend against them. Based on currently available information, we do not believe that resolution of pending matters will have a material adverse effect on our financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that our defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on our business, financial condition, cash flows and results of operations in a particular period. Any claims or proceedings against us, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect our business.
