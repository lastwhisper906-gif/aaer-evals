# LOGI MD&A — 0001628280-22-027224


## mdna

[0001628280-22-027224:mdna:1]
[same as prior period, unchanged from 0001032975-22-000034:mdna:1]

[0001628280-22-027224:mdna:2]
[same as prior period, unchanged from 0001032975-22-000034:mdna:2]

[0001628280-22-027224:mdna:3]
[same as prior period, unchanged from 0001032975-22-000034:mdna:3]

[0001628280-22-027224:mdna:4]
[same as prior period, unchanged from 0001032975-22-000034:mdna:4]

[0001628280-22-027224:mdna:5]
[same as prior period, unchanged from 0001032975-22-000034:mdna:5]

[0001628280-22-027224:mdna:6]
[same as prior period, unchanged from 0001032975-22-000034:mdna:6]

[0001628280-22-027224:mdna:7]
•Our expectations regarding our potential indemnification obligations, and the outcome of pending or future legal proceedings and tax audits;

[0001628280-22-027224:mdna:8]
[same as prior period, unchanged from 0001032975-22-000034:mdna:8]

[0001628280-22-027224:mdna:9]
•Opportunities for growth and our ability to execute on and take advantage of them, market opportunities, and marketing initiatives and strategy and our expectations regarding the success thereof;

[0001628280-22-027224:mdna:10]
[same as prior period, unchanged from 0001032975-22-000034:mdna:10]

[0001628280-22-027224:mdna:11]
[same as prior period, unchanged from 0001032975-22-000034:mdna:11]

[0001628280-22-027224:mdna:12]
[same as prior period, unchanged from 0001032975-22-000034:mdna:12]

[0001628280-22-027224:mdna:13]
•Our expectations regarding our restructuring efforts, including the timing thereof;

[0001628280-22-027224:mdna:14]
[same as prior period, unchanged from 0001032975-22-000034:mdna:13]

[0001628280-22-027224:mdna:15]
[same as prior period, unchanged from 0001032975-22-000034:mdna:14]

[0001628280-22-027224:mdna:16]
[same as prior period, unchanged from 0001032975-22-000034:mdna:15]

[0001628280-22-027224:mdna:17]
[same as prior period, unchanged from 0001032975-22-000034:mdna:16]

[0001628280-22-027224:mdna:18]
[same as prior period, unchanged from 0001032975-22-000034:mdna:17]

[0001628280-22-027224:mdna:19]
Logitech is a world leader in designing, manufacturing and marketing products that help connect people to digital and cloud experiences. Over forty years ago, Logitech created products to improve experiences around the personal computer ("PC") platform, and today it is a multi-brand, multi-category company designing products that enable people to pursue their passions and connect to the world. Logitech’s products align with several large secular trends including work and learn from anywhere, video everywhere, the increasing popularity of gaming as a spectator and participant sport, and the democratization of content creation. Logitech's brands include Logitech, Logitech G, ASTRO Gaming, Streamlabs, Blue Microphones, and Ultimate Ears. Our Company's website is www.logitech.com.

[0001628280-22-027224:mdna:20]
[same as prior period, unchanged from 0001032975-22-000034:mdna:20]

[0001628280-22-027224:mdna:21]
[same as prior period, unchanged from 0001032975-22-000034:mdna:21]

[0001628280-22-027224:mdna:22]
Impacts of Macroeconomic and Geopolitical Conditions and Other Factors on our Business

[0001628280-22-027224:mdna:23]
In March 2020, the World Health Organization declared the outbreak of COVID-19 as a pandemic, which continues to spread throughout the world. The COVID-19 pandemic has resulted in industry-wide global supply chain challenges, including manufacturing, transportation and logistics. We purchase certain products and key components from a limited number of sources, and depends on the supply chain, including freight, to receive components, transport finished goods and deliver our products across the world.

[0001628280-22-027224:mdna:24]
More recently, we have also been impacted by adverse macroeconomic and geopolitical conditions. These conditions include but are not limited to inflation, foreign currency fluctuations, slow down of economic activity around the globe, in part due to rising interest rates, and lower consumer spending. In addition, the war in Ukraine has further increased existing global supply chain, logistics, and inflationary challenges. Such global or regional economic and political conditions adversely affect demand for our products. These conditions also have an impact on our suppliers, contract manufacturers, logistics providers, and distributors, causing increases in cost of materials and higher shipping and transportation rates, and as a result impacting the pricing of our products. Price increases may not successfully offset cost increases or may cause us to lose market share and in turn adversely impact our results of operations.

[0001628280-22-027224:mdna:25]
While global supply chain challenges improved during the second quarter of fiscal 2023, including logistics costs, shipping lead times, and component availability, if macroeconomic and geopolitical conditions and COVID-19 related factors do not improve or worsen, our results of operations may be adversely impacted.

[0001628280-22-027224:mdna:26]
For additional information, see "Liquidity and Capital Resources" below and Part II item 1A "Risk Factors," including under the caption "Adverse global and regional economic and geopolitical conditions can materially adversely affect our business, results of operations and financial condition," “We purchase key components and products from a limited number of sources, and our business and operating results could be adversely affected if supply were delayed or constrained or if there were shortages of required components,” “Our principal manufacturing operations and third-party contract manufacturers are located in China and Southeast Asia, which exposes us to risks associated with doing business in that geographic area as well as potential tariffs, adverse trade regulations, adverse tax consequences and pressure to move or diversify our manufacturing locations,” “If we do not accurately forecast market demand for our products, our business and operating results could be adversely affected,” "The full effect of the COVID-19 pandemic is still uncertain and cannot be predicted, and could adversely affect our business, results of operations and financial condition" and "If we do not successfully coordinate the worldwide manufacturing and distribution of our products, we could lose sales.”

[0001628280-22-027224:mdna:27]
[same as prior period, unchanged from 0001032975-22-000034:mdna:31]

[0001628280-22-027224:mdna:28]
Our total sales for each of the three and six months ended September 30, 2022 decreased 12% compared to the same periods of the prior fiscal year, driven by a decline in sales for all of our product categories other than Video Collaboration.

[0001628280-22-027224:mdna:29]
Sales for the three months ended September 30, 2022 decreased 26%, 9%, and 2% in the EMEA, Americas and the Asia Pacific regions, respectively, compared to the same period of the prior fiscal year. Sales for the six months ended September 30, 2022, increased 3% in the Asia Pacific region, and decreased 22% and 14% in the EMEA and Americas regions, respectively, compared to the same period of the prior fiscal year.

[0001628280-22-027224:mdna:30]
Gross margin was 38.2% and 38.9% for the three and six months ended September 30, 2022, respectively, and decreased by 330 basis points and 350 basis points, respectively, compared to the same periods of the prior fiscal year, primarily due to higher material costs and unfavorable impacts from changes in currency exchange rates.

[0001628280-22-027224:mdna:31]
Operating expenses for the three months ended September 30, 2022 were $311.4 million, or 27.1% of sales, compared to $362.8 million, or 27.8% of sales, in the same period of the prior fiscal year. Operating expenses for the six months ended September 30, 2022 were $655.5 million, or 28.4% of sales, compared to $728.6 million or 27.8% of sales, in the same period of the prior fiscal year.

[0001628280-22-027224:mdna:32]
Net income for the three and six months ended September 30, 2022 was $82.1 million and $182.9 million, respectively, compared to the same periods of the prior fiscal year of $139.5 million, and $326.3 million, respectively.

[0001628280-22-027224:mdna:33]
[same as prior period, unchanged from 0001032975-22-000034:mdna:37]

[0001628280-22-027224:mdna:34]
[same as prior period, unchanged from 0001032975-22-000034:mdna:38]

[0001628280-22-027224:mdna:35]
[same as prior period, unchanged from 0001032975-22-000034:mdna:39]

[0001628280-22-027224:mdna:36]
Creativity & Productivity: In the past few years, mice and keyboard shipments have been strong due to work-from-home, learn-from-home and hybrid work trends. We believe that innovative personal workspace peripherals, such as our mice and keyboards, can refresh the design of personal workspaces and help improve the productivity and engagement of remote work and learning, thus providing growth opportunities. Hybrid work culture is also expanding the number of new workspaces to which we can attach our personal workspace peripherals. Increasing adoption of various cloud-based applications has led to multiple unique consumer use cases, which we are addressing with our innovative product portfolio and a deep understanding of our customer base. The popularity of streaming coupled with hybrid work trends, provide growth opportunities for our webcam products as well as other products in our portfolio. Smaller mobile computing devices, such as tablets, have created new markets and usage models for our peripherals and accessories.

[0001628280-22-027224:mdna:37]
[same as prior period, unchanged from 0001032975-22-000034:mdna:41]

[0001628280-22-027224:mdna:38]
Video Collaboration: The long-term structural growth opportunities in the video collaboration market continue to drive commercial and consumer adoption of video conferencing. Video meetings continue to be an opportunity as companies want lower-cost, cloud-based solutions that can provide their employees with the ability to work from anywhere. We are continuing our efforts to create and sell innovative products to accommodate the increasing demand from home offices and small-size meeting rooms, such as huddle rooms, to medium and large-sized meeting rooms. We will continue to invest in the development of select business-specific products (both hardware and software), targeted product marketing and sales channel development. We believe the continued digitization of learning and hybrid learning environments is a future growth opportunity.

[0001628280-22-027224:mdna:39]
Music: Consumers are optimizing their audio experiences on their tablets and smartphones with a variety of music peripherals including wireless mobile speakers and in-ear and other headphones. However, the mobile speaker market has matured and the integration of personal voice assistants has increased competition in the speaker category leading to a decline in our Mobile Speakers category sales in the past few years. In addition, we will continue developing true wireless audio products as growth in this category of the wireless audio market continues to be strong.

[0001628280-22-027224:mdna:40]
[same as prior period, unchanged from 0001032975-22-000034:mdna:45]

[0001628280-22-027224:mdna:41]
[same as prior period, unchanged from 0001032975-22-000034:mdna:46]

[0001628280-22-027224:mdna:42]
[same as prior period, unchanged from 0001032975-22-000034:mdna:47]

[0001628280-22-027224:mdna:43]
[same as prior period, unchanged from 0001032975-22-000034:mdna:48]

[0001628280-22-027224:mdna:44]
[same as prior period, unchanged from 0001032975-22-000034:mdna:49]

[0001628280-22-027224:mdna:45]
[same as prior period, unchanged from 0001032975-22-000034:mdna:50]

[0001628280-22-027224:mdna:46]
[same as prior period, unchanged from 0001032975-22-000034:mdna:51]

[0001628280-22-027224:mdna:47]
[same as prior period, unchanged from 0001032975-22-000034:mdna:52]

[0001628280-22-027224:mdna:48]
There have been no material changes in our critical accounting estimates during the six months ended September 30, 2022 compared with the critical accounting estimates disclosed in Management's Discussion and Analysis of Financial Condition and Results of Operations included in our Annual Report on Form 10-K for the fiscal year ended March 31, 2022.

[0001628280-22-027224:mdna:49]
[same as prior period, unchanged from 0001032975-22-000034:mdna:54]

[0001628280-22-027224:mdna:50]
[same as prior period, unchanged from 0001032975-22-000034:mdna:55]

[0001628280-22-027224:mdna:51]
[same as prior period, unchanged from 0001032975-22-000034:mdna:56]

[0001628280-22-027224:mdna:52]
[same as prior period, unchanged from 0001032975-22-000034:mdna:57]

[0001628280-22-027224:mdna:53]
[same as prior period, unchanged from 0001032975-22-000034:mdna:58]

[0001628280-22-027224:mdna:54]
[same as prior period, unchanged from 0001032975-22-000034:mdna:59]

[0001628280-22-027224:mdna:55]
[same as prior period, unchanged from 0001032975-22-000034:mdna:60]

[0001628280-22-027224:mdna:56]
[same as prior period, unchanged from 0001032975-22-000034:mdna:61]

[0001628280-22-027224:mdna:57]
[same as prior period, unchanged from 0001032975-22-000034:mdna:62]

[0001628280-22-027224:mdna:58]
Our sales for each of the three and six months ended September 30, 2022 decreased 12%, compared to the same periods of the prior fiscal year, which was primarily driven by a decline in sales for all of our product categories other than Video Collaboration. Our sales for the three and six month periods were also negatively impacted from lower demand and unfavorable changes in currency exchange rates. If currency exchange rates had been constant in the three and six months ended September 30, 2022 and 2021, our constant dollar sales reduction rates would have been 7% and 8%, respectively.

[0001628280-22-027224:mdna:59]
[same as prior period, unchanged from 0001032975-22-000034:mdna:64]

[0001628280-22-027224:mdna:60]
Although our financial results are reported in U.S. Dollars, a portion of our sales was generated in currencies other than the U.S. Dollar, such as the Euro, Chinese Renminbi, Australian Dollar, Canadian Dollar, Japanese Yen, Pound Sterling and New Taiwan Dollar. During the three months ended September 30, 2022, approximately 50% of our sales were denominated in currencies other than the U.S. Dollar.

[0001628280-22-027224:mdna:61]
[same as prior period, unchanged from 0001032975-22-000034:mdna:66]

[0001628280-22-027224:mdna:62]
The following table presents the change in sales by region for the three and six months ended September 30, 2022, compared with the three and six months ended September 30, 2021:

[0001628280-22-027224:mdna:63]
|  |  | Sales Growth Rate |  | Constant DollarSales Growth Rate |
|  |  | Three Months EndedSeptember 30, 2022 |  | Six Months EndedSeptember 30, 2022 |  | Three Months EndedSeptember 30, 2022 |  | Six Months EndedSeptember 30, 2022 |
| Americas |  | (9) | % |  | (14) | % |  | (9) | % |  | (14) | % |
| EMEA |  | (26) | % |  | (22) | % |  | (16) | % |  | (14) | % |
| Asia Pacific |  | (2) | % |  | 3 | % |  | 4 | % |  | 8 | % |

[0001628280-22-027224:mdna:64]
[same as prior period, unchanged from 0001032975-22-000034:mdna:69]

[0001628280-22-027224:mdna:65]
The decrease in sales in the Americas region for the three-month period presented above was primarily driven by a decrease in sales of PC Webcams, Gaming, and Tablet & Other Accessories. The decrease in sales in the Americas region for the six-month periods presented above was primarily driven by a decrease in sales of Gaming, Audio & Wearables, and PC Webcams.

[0001628280-22-027224:mdna:66]
[same as prior period, unchanged from 0001032975-22-000034:mdna:71]

[0001628280-22-027224:mdna:67]
The decrease in sales in our EMEA region for the three-and-six-month periods was primarily driven by the decrease in sales of all of our product categories except Video Collaboration.

[0001628280-22-027224:mdna:68]
[same as prior period, unchanged from 0001032975-22-000034:mdna:73]

[0001628280-22-027224:mdna:69]
The decrease in sales in our Asia Pacific region for the three-month period presented above was primarily driven by a decrease in sales of PC Webcams, Keyboards & Combos and Tablet & Other Accessories, partially offset by an increase in sales of Gaming. The increase in sales for the six-month period was primarily driven by an increase in sales of Gaming and Pointing Devices, partially offset by decrease in sales of the other product categories.

[0001628280-22-027224:mdna:70]
[same as prior period, unchanged from 0001032975-22-000034:mdna:75]

[0001628280-22-027224:mdna:71]
Sales by product categories for the three and six months ended September 30, 2022 and 2021 were as follows (Dollars in thousands):

[0001628280-22-027224:mdna:72]
|  |  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
|  |  | 2022 |  | 2021 |  | Change |  | 2022 |  | 2021 |  | Change |
| Pointing Devices |  | $ | 185,200 |  |  | $ | 189,014 |  |  | (2) | % |  | $ | 368,483 |  |  | $ | 371,892 |  |  | (1) | % |
| Keyboards & Combos |  | 200,853 |  |  | 236,272 |  |  | (15) |  |  | 428,573 |  |  | 454,629 |  |  | (6) |  |
| PC Webcams |  | 60,166 |  |  | 94,471 |  |  | (36) |  |  | 119,552 |  |  | 204,389 |  |  | (42) |  |
| Tablet & Other Accessories |  | 54,203 |  |  | 80,801 |  |  | (33) |  |  | 120,788 |  |  | 160,073 |  |  | (25) |  |
| Gaming (1) |  | 297,676 |  |  | 330,777 |  |  | (10) |  |  | 580,482 |  |  | 666,174 |  |  | (13) |  |
| Video Collaboration |  | 236,180 |  |  | 231,653 |  |  | 2 |  |  | 482,422 |  |  | 466,538 |  |  | 3 |  |
| Mobile Speakers |  | 39,195 |  |  | 39,492 |  |  | (1) |  |  | 61,505 |  |  | 67,976 |  |  | (10) |  |
| Audio & Wearables |  | 73,271 |  |  | 98,078 |  |  | (25) |  |  | 142,717 |  |  | 214,685 |  |  | (34) |  |
| Other (2) |  | 2,207 |  |  | 5,709 |  |  | (61) |  |  | 4,294 |  |  | 11,969 |  |  | (64) |  |
| Total Sales |  | $ | 1,148,951 |  |  | $ | 1,306,267 |  |  | (12) | % |  | $ | 2,308,816 |  |  | $ | 2,618,325 |  |  | (12) | % |

[0001628280-22-027224:mdna:73]
[same as prior period, unchanged from 0001032975-22-000034:mdna:78]

[0001628280-22-027224:mdna:74]
[same as prior period, unchanged from 0001032975-22-000034:mdna:79]

[0001628280-22-027224:mdna:75]
[same as prior period, unchanged from 0001032975-22-000034:mdna:80]

[0001628280-22-027224:mdna:76]
[same as prior period, unchanged from 0001032975-22-000034:mdna:81]

[0001628280-22-027224:mdna:77]
[same as prior period, unchanged from 0001032975-22-000034:mdna:82]

[0001628280-22-027224:mdna:78]
Sales of Pointing Devices remained flat for the three and six months ended September 30, 2022, compared to the same periods of the prior fiscal year.

[0001628280-22-027224:mdna:79]
[same as prior period, unchanged from 0001032975-22-000034:mdna:84]

[0001628280-22-027224:mdna:80]
[same as prior period, unchanged from 0001032975-22-000034:mdna:85]

[0001628280-22-027224:mdna:81]
Sales of Keyboards & Combos decreased 15% for the three months ended September 30, 2022 compared to the same period of the prior fiscal year, primarily driven by the decrease in sales of our cordless combos and corded PC keyboards. Sales of Keyboards & Combos decreased 6% for the six months ended September 30, 2022, compared to the same period of the prior fiscal year, primarily driven by the decrease in sales of our cordless combos and corded PC keyboards, partially offset by the increase in sales of our cordless PC keyboards.

[0001628280-22-027224:mdna:82]
[same as prior period, unchanged from 0001032975-22-000034:mdna:87]

[0001628280-22-027224:mdna:83]
[same as prior period, unchanged from 0001032975-22-000034:mdna:88]

[0001628280-22-027224:mdna:84]
Sales of PC Webcams decreased 36% and 42% for the three and six months ended September 30, 2022, respectively, compared to the same periods of the prior fiscal year, primarily driven by the decrease in sales of our HD Pro Webcam C920, 1080p Pro Stream Webcam, and Webcam C260.

[0001628280-22-027224:mdna:85]
[same as prior period, unchanged from 0001032975-22-000034:mdna:90]

[0001628280-22-027224:mdna:86]
[same as prior period, unchanged from 0001032975-22-000034:mdna:91]

[0001628280-22-027224:mdna:87]
Sales of Tablet & Other Accessories products decreased 33% and 25% for the three and six months ended September 30, 2022, respectively, compared to the same periods of the prior fiscal year, primarily driven by the decrease in sales of most of our products, partially offset by increases in sales of our Rugged Combo 3 Touch and Combo Touch for iPad Air.

[0001628280-22-027224:mdna:88]
[same as prior period, unchanged from 0001032975-22-000034:mdna:93]

[0001628280-22-027224:mdna:89]
[same as prior period, unchanged from 0001032975-22-000034:mdna:94]

[0001628280-22-027224:mdna:90]
[same as prior period, unchanged from 0001032975-22-000034:mdna:95]

[0001628280-22-027224:mdna:91]
Sales of Gaming decreased 10% and 13% for the three and six months ended September 30, 2022, respectively, compared to the same periods of the prior fiscal year, primarily driven by the decrease in sales of most of the gaming sub-categories, partially offset by an increase in sales of our gaming steering wheels.

[0001628280-22-027224:mdna:92]
[same as prior period, unchanged from 0001032975-22-000034:mdna:97]

[0001628280-22-027224:mdna:93]
[same as prior period, unchanged from 0001032975-22-000034:mdna:98]

[0001628280-22-027224:mdna:94]
[same as prior period, unchanged from 0001032975-22-000034:mdna:99]

[0001628280-22-027224:mdna:95]
Sales of Video Collaboration products increased 2% and 3% for the three and six months ended September 30, 2022, respectively, compared to the same periods of the prior fiscal year, primarily due to an increase in sales of conference room cameras, headsets, and docks, partially offset by a decline in sales of webcams.

[0001628280-22-027224:mdna:96]
[same as prior period, unchanged from 0001032975-22-000034:mdna:101]

[0001628280-22-027224:mdna:97]
[same as prior period, unchanged from 0001032975-22-000034:mdna:102]

[0001628280-22-027224:mdna:98]
[same as prior period, unchanged from 0001032975-22-000034:mdna:103]

[0001628280-22-027224:mdna:99]
Sales of Mobile Speakers remained flat for the three months ended September 30, 2022, compared to the same period of the prior fiscal year. Sales of Mobile Speakers decreased 10% for the six months ended September 30, 2022 compared to the same period of the prior fiscal year primarily due to a decrease in sales of most of our Mobile speaker sub-categories, partially offset by the sales of our Ultimate Ears Wonderboom 3 mini speakers, introduced in the second quarter of fiscal year 2023, and an increase in sales of our Hyperboom mobile speakers.

[0001628280-22-027224:mdna:100]
[same as prior period, unchanged from 0001032975-22-000034:mdna:105]

[0001628280-22-027224:mdna:101]
[same as prior period, unchanged from 0001032975-22-000034:mdna:106]

[0001628280-22-027224:mdna:102]
Sales of Audio & Wearables decreased 25% and 34% for the three and six months ended September 30, 2022, respectively, compared to the same periods of the prior fiscal year, primarily due to a decrease in sales of almost all sub-categories.

[0001628280-22-027224:mdna:103]
[same as prior period, unchanged from 0001032975-22-000034:mdna:108]

[0001628280-22-027224:mdna:104]
Gross profit for the three and six months ended September 30, 2022 and 2021 was as follows (Dollars in thousands):

[0001628280-22-027224:mdna:105]
|  |  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
|  |  | 2022 |  | 2021 |  | Change |  | 2022 |  | 2021 |  | Change |
| Net sales |  | $ | 1,148,951 |  |  | $ | 1,306,267 |  |  | (12) | % |  | $ | 2,308,816 |  |  | $ | 2,618,325 |  |  | (12) | % |
| Gross profit |  | $ | 438,780 |  |  | $ | 542,163 |  |  | (19) | % |  | $ | 898,383 |  |  | $ | 1,111,089 |  |  | (19) | % |
| Gross margin |  | 38.2 | % |  | 41.5 | % |  |  |  | 38.9 | % |  | 42.4 | % |  |  |

[0001628280-22-027224:mdna:106]
Gross profit consists of sales, less cost of goods sold (which includes materials, direct labor and related overhead costs, costs of manufacturing facilities, royalties, costs of purchasing components from outside suppliers, distribution costs, warranty costs, customer support costs, shipping and handling costs, outside processing costs and write-down of inventories), and amortization of intangible assets.

[0001628280-22-027224:mdna:107]
Gross margin for the three and six months ended September 30, 2022 decreased by 330 basis points and 350 basis points, respectively, compared to the same periods of the prior fiscal year, primarily due to higher material costs and unfavorable impacts from changes in currency exchange rates.

[0001628280-22-027224:mdna:108]
[same as prior period, unchanged from 0001032975-22-000034:mdna:114]

[0001628280-22-027224:mdna:109]
Operating expenses for the three and six months ended September 30, 2022 and 2021 were as follows (Dollars in thousands):

[0001628280-22-027224:mdna:110]
|  |  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |  |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |  |
| Marketing and selling |  | $ | 202,091 |  |  | $ | 256,627 |  |  | $ | 431,469 |  |  | $ | 508,941 |  |  |
| % of sales |  | 17.6 | % |  | 19.6 | % |  | 18.7 | % |  | 19.4 | % |  |
| Research and development |  | 69,009 |  |  | 68,661 |  |  | 144,526 |  |  | 137,907 |  |  |
| % of sales |  | 6.0 | % |  | 5.3 | % |  | 6.3 | % |  | 5.3 | % |  |
| General and administrative |  | 26,589 |  |  | 33,271 |  |  | 62,449 |  |  | 73,813 |  |  |
| % of sales |  | 2.3 | % |  | 2.5 | % |  | 2.7 | % |  | 2.8 | % |  |
| Amortization of intangible assets and acquisition-related costs |  | 2,873 |  |  | 5,107 |  |  | 6,242 |  |  | 10,324 |  |  |
| % of sales |  | 0.3 | % |  | 0.4 | % |  | 0.3 | % |  | 0.4 | % |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | (925) |  |  | — |  |  | (2,399) |  |  |
| % of sales |  | N/A |  | (0.1) | % |  | N/A |  | (0.1) | % |  |
| Restructuring charges, net |  | 10,817 |  |  | 11 |  |  | 10,817 |  |  | 11 |  |  |
| % of sales |  | 0.9 | % |  | — | % |  | 0.5 | % |  | — | % |  |
| Total operating expenses |  | $ | 311,379 |  |  | $ | 362,752 |  |  | $ | 655,503 |  |  | $ | 728,597 |  |  |
| % of sales |  | 27.1 | % |  | 27.8 | % |  | 28.4 | % |  | 27.8 | % |  |

[0001628280-22-027224:mdna:111]
The decrease in total operating expenses during the three and six months ended September 30, 2022, compared to the same periods of the prior fiscal year, were mainly due to decreases in marketing and selling expenses and general and administrative expenses, partially offset by an increase in restructuring expenses.

[0001628280-22-027224:mdna:112]
[same as prior period, unchanged from 0001032975-22-000034:mdna:118]

[0001628280-22-027224:mdna:113]
[same as prior period, unchanged from 0001032975-22-000034:mdna:119]

[0001628280-22-027224:mdna:114]
During the three and six months ended September 30, 2022, marketing and selling expenses decreased $54.5 million and $77.5 million, respectively, compared to the same periods of the prior fiscal year, primarily driven by lower third-party marketing and advertising spend.

[0001628280-22-027224:mdna:115]
[same as prior period, unchanged from 0001032975-22-000034:mdna:121]

[0001628280-22-027224:mdna:116]
[same as prior period, unchanged from 0001032975-22-000034:mdna:122]

[0001628280-22-027224:mdna:117]
During the three months ended September 30, 2022, research and development expenses remained flat, compared to the same period of the prior fiscal year. During the six months ended September 30, 2022, research and development expenses increased $6.6 million, compared to the same period of the prior fiscal year, primarily driven by higher outsourcing expenses, and higher travel and entertainment expenses.

[0001628280-22-027224:mdna:118]
[same as prior period, unchanged from 0001032975-22-000034:mdna:124]

[0001628280-22-027224:mdna:119]
[same as prior period, unchanged from 0001032975-22-000034:mdna:125]

[0001628280-22-027224:mdna:120]
During the three and six months ended September 30, 2022, general and administrative expenses decreased $6.7 million and $11.4 million, respectively, compared to the same periods of the prior fiscal year, primarily driven by lower personnel-related costs.

[0001628280-22-027224:mdna:121]
[same as prior period, unchanged from 0001032975-22-000034:mdna:127]

[0001628280-22-027224:mdna:122]
[same as prior period, unchanged from 0001032975-22-000034:mdna:128]

[0001628280-22-027224:mdna:123]
During the three and six months ended September 30, 2022, amortization of intangible assets and acquisition-related costs decreased $2.2 million and $4.1 million, respectively, compared to the same periods of the prior fiscal year, primarily due to certain acquired intangible assets becoming fully amortized and the write-off of Jaybird intangible assets in the third quarter of fiscal year 2022.

[0001628280-22-027224:mdna:124]
Restructuring Charges, Net

[0001628280-22-027224:mdna:125]
During the second quarter of fiscal year 2023, we initiated a restructuring plan to realign our business group and engineering structure with our go-to-market strategy to more effectively compete within the enterprise market and to better serve end-users. As a result, we recorded pre-tax restructuring charges of $10.8 million, related to employee severance and other termination benefits, for the three and six months ended September 30, 2022. We expect to substantially complete this restructuring within the next twelve months.

[0001628280-22-027224:mdna:126]
[same as prior period, unchanged from 0001032975-22-000034:mdna:130]

[0001628280-22-027224:mdna:127]
Interest income for the three and six months ended September 30, 2022 and 2021 was as follows (in thousands):

[0001628280-22-027224:mdna:128]
|  |  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Interest income |  | $ | 3,459 |  |  | $ | 201 |  |  | $ | 4,908 |  |  | $ | 517 |  |

[0001628280-22-027224:mdna:129]
We invest in highly liquid instruments with an original maturity of three months or less at the date of purchase, which are classified as cash equivalents. During the three and six months ended September 30, 2022 interest income increased $3.3 million and $4.4 million, respectively, compared to the same periods of the prior fiscal year, primarily driven by the increase in interest rates.

[0001628280-22-027224:mdna:130]
[same as prior period, unchanged from 0001032975-22-000034:mdna:134]

[0001628280-22-027224:mdna:131]
Other income (expense), net for the three and six months ended September 30, 2022 and 2021 was as follows (Dollars in thousands):

[0001628280-22-027224:mdna:132]
|  |  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Investment income (expense) related to the deferred compensation plan |  | $ | (762) |  |  | $ | (73) |  |  | $ | (4,148) |  |  | $ | 1,095 |  |
| Currency exchange gain (loss), net |  | (2,052) |  |  | (4,979) |  |  | (5,012) |  |  | 738 |  |
| Loss on investments, net |  | (22,934) |  |  | (2,032) |  |  | (11,577) |  |  | (961) |  |
| Other |  | 351 |  |  | 381 |  |  | 964 |  |  | 860 |  |
| Total |  | $ | (25,397) |  |  | $ | (6,703) |  |  | $ | (19,773) |  |  | $ | 1,732 |  |

[0001628280-22-027224:mdna:133]
Investment income related to the deferred compensation plan represents earnings, gains, and losses on marketable securities related to a deferred compensation plan offered by one of our subsidiaries. The decrease in investment income for three and six months ended September 30, 2022 compared to the same periods of the prior fiscal year primarily relates to the change in market performance of the underlying securities.

[0001628280-22-027224:mdna:134]
Currency exchange gain (loss), net, relates to balances denominated in currencies other than the functional currency in our subsidiaries, as well as to the sale of currencies, and gains or losses recognized on currency exchange forward contracts. We do not speculate in currency positions, but we are alert to opportunities to maximize currency exchange gains and minimize currency exchange losses. The loss for the three months ended September 30, 2022 was primarily due to the weakening of the Australian Dollar, and the Brazilian Real against the U.S. Dollar offset by gains in the Swiss Franc. The loss for the three months ended September 30, 2021 was primarily due to the weakening of the Brazilian Real against the U.S. Dollar. The loss for the six months ended September 30, 2022 was primarily due to the weakening of the Brazilian Real, Australian Dollar, and the Japanese Yen, offset by the gain from the weakening of the Chinese Renminbi against the U.S Dollar. The gain for the six months ended September 30, 2021 was primarily due to the strengthening of the Brazilian Real offset by the loss from the strengthening of the Chinese Renminbi against the U.S Dollar.

[0001628280-22-027224:mdna:135]
Loss on investments, net, represents unrealized gain (loss) from the fair value change of investment, gain (loss) on equity-method investments and impairment of investments during the periods presented, as applicable. The loss for the three and six months ended September 30, 2022 were primarily due to the impairment charges related to one of our equity method investments. The loss for the six months ended September 30, 2022 was partially offset by an unrealized gain related to one of our equity investments without readily determinable fair value resulting from observable price changes. See Note 6 to our condensed consolidated financial statements for additional information.

[0001628280-22-027224:mdna:136]
[same as prior period, unchanged from 0001032975-22-000034:mdna:140]

[0001628280-22-027224:mdna:137]
The provision for income taxes and effective income tax rates for the three and six months ended September 30, 2022 and 2021 were as follows (Dollars in thousands):

[0001628280-22-027224:mdna:138]
|  |  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Provision for income taxes |  | $ | 23,372 |  |  | $ | 33,453 |  |  | $ | 45,088 |  |  | $ | 58,444 |  |
| Effective income tax rate |  | 22.2 | % |  | 19.3 | % |  | 19.8 | % |  | 15.2 | % |

[0001628280-22-027224:mdna:139]
The change in the effective income tax rate for the three and six months ended September 30, 2022 was primarily due to the mix of income and losses in the various tax jurisdictions in which we operate. There was a discrete tax provision of $0.2 million and a discrete tax benefit of $1.2 million from the recognition of shortfalls and excess tax benefits, respectively, in the United States in the three and six months ended September 30, 2022. In addition, there were discrete tax benefits of $0.3 million and $1.5 million from the reversal of uncertain tax positions from the expiration of statutes of limitations, respectively, in the three and six month period ended September 30, 2022. The change in the effective income tax rate for the three and six months ended September 30, 2021 was primarily due to the mix of income and losses in the various tax jurisdictions in which we operate. There were

[0001628280-22-027224:mdna:140]
discrete tax benefits of $0.6 million and $14.3 million from the recognition of excess tax benefits in the United States in the three and six months ended September 30, 2021, respectively. Furthermore, there were discrete tax benefits of $0.5 million and $1.5 million from the reversal of uncertain tax positions from the expiration of statutes of limitations, respectively, in the three and six month period ended September 30, 2021.

[0001628280-22-027224:mdna:141]
As of September 30, 2022 and March 31, 2022, the total amount of unrecognized tax benefits due to uncertain tax positions was $174.9 million and $176.0 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001628280-22-027224:mdna:142]
[same as prior period, unchanged from 0001032975-22-000034:mdna:145]

[0001628280-22-027224:mdna:143]
[same as prior period, unchanged from 0001032975-22-000034:mdna:146]

[0001628280-22-027224:mdna:144]
As of September 30, 2022, we had cash and cash equivalents of $868.5 million, compared with $1,328.7 million as of March 31, 2022. Our cash and cash equivalents consist of bank demand deposits and short-term time deposits, of which 66% is held in Switzerland and 17% were held in China (including Hong Kong). We do not expect to incur any material adverse tax impact except for what has already been recognized, or to be significantly inhibited by any country in which we do business from the repatriation of funds to Switzerland, our home domicile.

[0001628280-22-027224:mdna:145]
As of September 30, 2022, our working capital was $1,448.0 million, compared to $1,651.8 million as of March 31, 2022. The decrease was primarily driven by lower cash balances, resulting from higher share repurchases and payments of cash dividends, and lower inventories, partially offset by decreases in accrued liabilities and accounts payable, and an increase in accounts receivable, net.

[0001628280-22-027224:mdna:146]
We had several uncommitted, unsecured bank lines of credit aggregating $176.0 million as of September 30, 2022. There are no financial covenants under these lines of credit with which we must comply. As of September 30, 2022, we had outstanding bank guarantees of $22.2 million under these lines of credit.

[0001628280-22-027224:mdna:147]
The following tables present selected financial information and statistics as of and for the three months ended September 30, 2022 and 2021 (Dollars in thousands):

[0001628280-22-027224:mdna:148]
|  |  | As of September 30, |  |
|  |  | 2022 |  | 2021 |  |
| Accounts receivable, net |  | $ | 772,731 |  |  | $ | 728,074 |  |  |
| Accounts payable |  | $ | 546,563 |  |  | $ | 660,720 |  |  |
| Inventories |  | $ | 879,979 |  |  | $ | 827,710 |  |  |

[0001628280-22-027224:mdna:149]
|  |  | Three Months EndedSeptember 30, |  |
|  |  | 2022 |  | 2021 |  |
| Days sales in accounts receivable (“DSO”) (Days)(1) |  | 61 |  |  | 50 |  |  |
| Days accounts payable outstanding (“DPO”) (Days)(2) |  | 69 |  |  | 78 |  |  |
| Inventory turnover (“ITO”) (x)(3) |  | 3.2 |  |  | 3.7 |  |  |

[0001628280-22-027224:mdna:150]
[same as prior period, unchanged from 0001032975-22-000034:mdna:153]

[0001628280-22-027224:mdna:151]
[same as prior period, unchanged from 0001032975-22-000034:mdna:154]

[0001628280-22-027224:mdna:152]
[same as prior period, unchanged from 0001032975-22-000034:mdna:155]

[0001628280-22-027224:mdna:153]
DSO for the three months ended September 30, 2022 increased by 11 days to 61 days, compared to 50 days for the same period of the prior fiscal year, primarily due to a comparatively higher percentage of sales in the last month of the current quarter.

[0001628280-22-027224:mdna:154]
DPO for the three months ended September 30, 2022 decreased by 9 days, compared to 78 days for the same period of the prior fiscal year, primarily due to lower inventory purchases than prior year resulting from softened demand and lower marketing spend.

[0001628280-22-027224:mdna:155]
ITO for the three months ended September 30, 2022 decreased by 0.5, compared to 3.7 for the same period of the prior fiscal year, primarily due to lower demand and higher inventory balance than prior year.

[0001628280-22-027224:mdna:156]
[same as prior period, unchanged from 0001032975-22-000034:mdna:159]

[0001628280-22-027224:mdna:157]
[same as prior period, unchanged from 0001032975-22-000034:mdna:160]

[0001628280-22-027224:mdna:158]
|  |  | Six Months EndedSeptember 30, |
|  |  | 2022 |  | 2021 |
| Net cash provided by (used in) operating activities |  | $ | 37,256 |  |  | $ | (177,848) |  |
| Net cash used in investing activities |  | (53,561) |  |  | (63,208) |  |
| Net cash used in financing activities |  | (416,087) |  |  | (371,905) |  |
| Effect of exchange rate changes on cash and cash equivalents |  | (27,823) |  |  | (70) |  |
| Net decrease in cash and cash equivalents |  | $ | (460,215) |  |  | $ | (613,031) |  |

[0001628280-22-027224:mdna:159]
For the six months ended September 30, 2022, net cash provided by operating activities was $37.3 million  resulting from net income of $182.9 million, a favorable impact from adding back non-cash expenses totaling $100.2 million, and an unfavorable net change in operating assets and liabilities of $245.9 million. Non-cash expenses were primarily related to depreciation and amortization, share-based compensation expenses, and loss on investments. The increase in accounts receivable, net was primarily driven by timing of sales within the quarter. The decrease in inventories was primarily driven by lower inventory purchases. The decrease in accounts payable was primarily driven by lower inventory purchases and marketing spend. The decrease in accrued and other liabilities was primarily driven by payment of the fiscal year 2022 annual bonus.

[0001628280-22-027224:mdna:160]
For the six months ended September 30, 2022, net cash used in investing activities was $53.6 million, primarily due to $45.4 million of purchases of property, plant, and equipment and $5.8 million payments for acquisitions, net of cash acquired.

[0001628280-22-027224:mdna:161]
For the six months ended September 30, 2022, net cash used in financing activities was $416.1 million, resulting from repurchases of our registered shares of $237.6 million, payment of cash dividends of $158.7 million, and tax withholdings related to net share settlements of restricted stock units of $26.7 million.

[0001628280-22-027224:mdna:162]
For the six months ended September 30, 2022, there was a $27.8 million loss from currency exchange rate effect on cash and cash equivalents, primarily due to the weakening of the Euro, Chinese Renminbi, Swiss Franc, Australian Dollar, New Taiwan Dollar and the Japanese Yen versus the U.S. Dollar by 12%, 11%, 6%, 14%, 10% and 16%, respectively. The loss from the effect of currency rate changes was immaterial during the six months ended September 30, 2021.

[0001628280-22-027224:mdna:163]
[same as prior period, unchanged from 0001032975-22-000034:mdna:166]

[0001628280-22-027224:mdna:164]
[same as prior period, unchanged from 0001032975-22-000034:mdna:167]

[0001628280-22-027224:mdna:165]
In fiscal year 2023, we paid a cash dividend of CHF 156.1 million (U.S. Dollar amount of $158.7 million based on the exchange rate on the date of payment) out of fiscal year 2022 retained earnings. In fiscal year 2022, we paid a cash dividend of CHF 147.0 million (U.S. Dollar amount of $159.4 million) out of fiscal year 2021 retained earnings.

[0001628280-22-027224:mdna:166]
In May 2020, our Board of Directors approved a share repurchase program, which authorized us to invest up to $250.0 million to purchase our own shares, following the expiration date of the 2017 share repurchase program.

[0001628280-22-027224:mdna:167]
In April 2021, our Board of Directors approved an increase of $750.0 million of the 2020 share repurchase program, to an aggregate amount of $1.0 billion. The Swiss Takeover Board approved this increase and it became effective on May 21, 2021. In July 2022, our Board of Directors approved an increase of $500 million to the 2020 share repurchase program to an aggregate amount of up to $1.5 billion. The Swiss Takeover Board approved this increase and it became effective on August 19, 2022. As of September 30, 2022, $686.3 million was available for repurchase under the 2020 repurchase program.

[0001628280-22-027224:mdna:168]
Although we enter into trading plans for systematic repurchases (e.g., 10b5-1 trading plans) from time to time, our share repurchase program provides us with the opportunity to make opportunistic repurchases during periods of favorable market conditions and is expected to remain in effect for a period of three years through July 27, 2023. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Opportunistic purchases may be started or stopped at any time without prior notice depending on market conditions and other factors.

[0001628280-22-027224:mdna:169]
[same as prior period, unchanged from 0001032975-22-000034:mdna:172]

[0001628280-22-027224:mdna:170]
[same as prior period, unchanged from 0001032975-22-000034:mdna:173]

[0001628280-22-027224:mdna:171]
We lease facilities under operating leases, certain of which require us to pay property taxes, insurance and maintenance costs. Operating leases for facilities are generally renewable at our option and usually include escalation clauses linked to inflation. During the six months ended September 30, 2022, our operating lease obligations increased approximately $50.0 million, primarily related to newly commenced operating leases for office spaces in the Americas and EMEA regions. There have been no other material changes to our contractual obligations as previously disclosed in our Annual Report on Form 10-K for the year ended March 31, 2022. The remaining terms of our non-cancelable operating leases expire in various years through 2033.

[0001628280-22-027224:mdna:172]
[same as prior period, unchanged from 0001032975-22-000034:mdna:175]

[0001628280-22-027224:mdna:173]
As of September 30, 2022, we had non-cancelable purchase commitments of $589.5 million for inventory purchases made in the normal course of business from original design manufacturers, contract manufacturers and other suppliers, the majority of which are expected to be fulfilled within the next 12 months. We recorded a liability for firm, non-cancelable, and unhedged inventory purchase commitments in excess of anticipated demand or net realizable value consistent with our valuation of excess and obsolete inventory. As of September 30, 2022, the liability for these purchase commitments was $46.1 million and is recorded in accrued and other current liabilities in the condensed consolidated balance sheet.

[0001628280-22-027224:mdna:174]
We have firm purchase commitments of $20.0 million for capital expenditures primarily related to commitments for tooling and equipment for new and existing products. We expect to continue making capital expenditures in the future to support product development activities and ongoing and expanded operations. Although open purchase commitments are considered enforceable and legally binding, the terms generally allow us to reschedule or adjust our requirements based on business needs prior to delivery of goods or performance of services.

[0001628280-22-027224:mdna:175]
[same as prior period, unchanged from 0001032975-22-000034:mdna:178]

[0001628280-22-027224:mdna:176]
[same as prior period, unchanged from 0001032975-22-000034:mdna:179]

[0001628280-22-027224:mdna:177]
[same as prior period, unchanged from 0001032975-22-000034:mdna:180]

[0001628280-22-027224:mdna:178]
We indemnify certain suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of September 30, 2022, no amounts have been accrued for indemnification provisions. We do not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under our indemnification arrangements.

[0001628280-22-027224:mdna:179]
[same as prior period, unchanged from 0001032975-22-000034:mdna:182]

[0001628280-22-027224:mdna:180]
Legal Proceedings

[0001628280-22-027224:mdna:181]
From time to time we are involved in claims and legal proceedings that arise in the ordinary course of our business. For more information about Legal Proceedings, see Part II Item 1 Legal Proceedings of this quarterly report on Form 10-Q for the period ended September 30, 2022.

[0001628280-22-027224:mdna:182]
36
