# LOGI notes — 0001628280-22-027224


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001628280-22-027224:notes:1]
[same as prior period, unchanged from 0001032975-22-000034:notes:1]

[0001628280-22-027224:notes:2]
Logitech International S.A, together with its consolidated subsidiaries ("Logitech" or the "Company"), designs, manufactures and markets products that help connect people to digital and cloud experiences. Over forty years ago, Logitech created products to improve experiences around the personal computer ("PC") platform, and today it is a multi-brand, multi-category company designing products that enable better experiences consuming, sharing and creating any digital content such as computing, gaming, video, and music, whether it is on a computer, mobile device or in the cloud.

[0001628280-22-027224:notes:3]
[same as prior period, unchanged from 0001032975-22-000034:notes:3]

[0001628280-22-027224:notes:4]
[same as prior period, unchanged from 0001032975-22-000034:notes:4]

[0001628280-22-027224:notes:5]
[same as prior period, unchanged from 0001032975-22-000034:notes:5]

[0001628280-22-027224:notes:6]
[same as prior period, unchanged from 0001032975-22-000034:notes:6]

[0001628280-22-027224:notes:7]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and six months ended September 30, 2022 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2023, or any future periods.

[0001628280-22-027224:notes:8]
[same as prior period, unchanged from 0001032975-22-000034:notes:8]

[0001628280-22-027224:notes:9]
Other than the recent accounting pronouncements adopted and discussed below under Recent Accounting Pronouncements Adopted, there have been no material changes in the Company’s significant accounting policies during the six months ended September 30, 2022 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2022.

[0001628280-22-027224:notes:10]
[same as prior period, unchanged from 0001032975-22-000034:notes:10]

[0001628280-22-027224:notes:11]
[same as prior period, unchanged from 0001032975-22-000034:notes:11]

[0001628280-22-027224:notes:12]
[same as prior period, unchanged from 0001032975-22-000034:notes:12]

[0001628280-22-027224:notes:13]
[same as prior period, unchanged from 0001032975-22-000034:notes:13]

[0001628280-22-027224:notes:14]
Impacts of Macroeconomic and Geopolitical Conditions and Other Factors on the Company's Business

[0001628280-22-027224:notes:15]
In March 2020, the World Health Organization declared the outbreak of COVID-19 as a pandemic, which continues to spread throughout the world. The COVID-19 pandemic has resulted in industry-wide global supply chain challenges, including manufacturing, transportation and logistics. The Company purchases certain products and key components from a limited number of sources, and depends on the supply chain, including freight, to receive components, transport finished goods and deliver the Company's products across the world.

[0001628280-22-027224:notes:16]
More recently, the Company has also been impacted by adverse macroeconomic and geopolitical conditions. These conditions include but are not limited to inflation, foreign currency fluctuations, slow down of economic activity around the globe, in part due to rising interest rates, and lower consumer spending. In addition, the war in Ukraine has further increased existing global supply chain, logistics, and inflationary challenges. Such global or regional economic and political conditions adversely affect demand for the Company's products. These conditions also have an impact on the Company's suppliers, contract manufacturers, logistics providers, and distributors, causing increases in cost of materials and higher shipping and transportation rates, and as a result impacting the pricing of the Company's products. Price increases may not successfully offset cost increases or may cause the Company to lose market share and in turn adversely impact the Company's results of operations.

[0001628280-22-027224:notes:17]
While global supply chain challenges improved during the second quarter of fiscal 2023, including logistics costs, shipping lead times, and component availability, if macroeconomic and geopolitical conditions and COVID-19 related factors do not improve or worsen, the Company's results of operations may be adversely impacted.

[0001628280-22-027224:notes:18]
[same as prior period, unchanged from 0001032975-22-000034:notes:19]

[0001628280-22-027224:notes:19]
In October 2021, the Financial Accounting Standard Board issued ASU 2021-08, "Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers" (ASU 2021-08). The update requires an acquirer in a business combination to recognize and measure contract assets and contract liabilities acquired in a business combination in accordance with Accounting Standards Codification ("ASC") 606, Revenue from Contracts with Customers, as if it had originated the contracts. The standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2022. The Company early adopted the standard effective April 1, 2022 and applies the standard prospectively to business combinations that occurred on or after April 1, 2022. The adoption of ASU 2021-08 did not have a material impact on the Company's condensed consolidated financial statements.


## us-gaap:EarningsPerShareTextBlock

[0001628280-22-027224:notes:20]
[same as prior period, unchanged from 0001032975-22-000034:notes:21]

[0001628280-22-027224:notes:21]
The following table summarizes the computations of basic and diluted net income per share for the three and six months ended September 30, 2022 and 2021 (in thousands, except per share amounts):

[0001628280-22-027224:notes:22]
|  |  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Net income |  | $ | 82,091 |  |  | $ | 139,456 |  |  | $ | 182,927 |  |  | $ | 326,297 |  |
| Shares used in net income per share computation: |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding - basic |  | 163,186 |  |  | 168,389 |  |  | 163,937 |  |  | 168,380 |  |
| Effect of potentially dilutive equivalent shares |  | 1,142 |  |  | 2,954 |  |  | 1,434 |  |  | 3,302 |  |
| Weighted average shares outstanding - diluted |  | 164,328 |  |  | 171,343 |  |  | 165,371 |  |  | 171,682 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.50 |  |  | $ | 0.83 |  |  | $ | 1.12 |  |  | $ | 1.94 |  |
| Diluted |  | $ | 0.50 |  |  | $ | 0.81 |  |  | $ | 1.11 |  |  | $ | 1.90 |  |

[0001628280-22-027224:notes:23]
Share equivalents attributable to outstanding stock options, restricted stock units ("RSUs") and employee share purchase plans ("ESPP") totaling 1.7 million and 0.5 million for the three months ended September 30, 2022 and 2021, respectively, and 2.6 million and 0.5 million for the six months ended September 30, 2022 and 2021, respectively, were excluded from the calculation of diluted net income per share because their effect would have been anti-dilutive. A small number of performance-based awards were not included in the calculation because all necessary conditions had not been satisfied by the end of the respective period, and those shares were not issuable if the end of the reporting period were the end of the performance contingency period.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001628280-22-027224:notes:24]
[same as prior period, unchanged from 0001032975-22-000034:notes:25]

[0001628280-22-027224:notes:25]
[same as prior period, unchanged from 0001032975-22-000034:notes:26]

[0001628280-22-027224:notes:26]
As of September 30, 2022, the Company offers the 2006 Employee Share Purchase Plan (Non-U.S.), as amended and restated ("2006 ESPP"), the 1996 Employee Share Purchase Plan (U.S.), as amended and restated ("1996 ESPP"), and the 2006 Stock Incentive Plan ("2006 Plan") as amended and restated. Shares issued to employees as a result of purchases or exercises under these plans are generally issued from shares held in treasury stock.

[0001628280-22-027224:notes:27]
The following table summarizes the share-based compensation expense and total income tax benefit recognized for share-based awards for the three and six months ended September 30, 2022 and 2021 (in thousands):

[0001628280-22-027224:notes:28]
|  |  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Cost of goods sold |  | $ | 1,443 |  |  | $ | 2,102 |  |  | $ | 2,904 |  |  | $ | 3,471 |  |
| Marketing and selling |  | 7,429 |  |  | 9,758 |  |  | 17,226 |  |  | 18,288 |  |
| Research and development |  | 3,280 |  |  | 4,724 |  |  | 8,812 |  |  | 9,785 |  |
| General and administrative |  | 93 |  |  | 7,438 |  |  | 6,993 |  |  | 16,129 |  |
| Total share-based compensation expense |  | 12,245 |  |  | 24,022 |  |  | 35,935 |  |  | 47,673 |  |
| Income tax expense (benefit) |  | 102 |  |  | (3,285) |  |  | (4,220) |  |  | (19,879) |  |
| Total share-based compensation expense, net of income tax expense (benefit) |  | $ | 12,347 |  |  | $ | 20,737 |  |  | $ | 31,715 |  |  | $ | 27,794 |  |

[0001628280-22-027224:notes:29]
[same as prior period, unchanged from 0001032975-22-000034:notes:30]

[0001628280-22-027224:notes:30]
Share-based compensation costs capitalized as part of inventory were $1.3 million for each of the three months ended September 30, 2022 and 2021, and $3.1 million and $3.0 million for the six months ended September 30, 2022 and 2021, respectively.

[0001628280-22-027224:notes:31]
[same as prior period, unchanged from 0001032975-22-000034:notes:32]

[0001628280-22-027224:notes:32]
Certain of the Company’s subsidiaries sponsor defined benefit pension plans or non-retirement post-employment benefits covering substantially all of their employees. Benefits are provided based on employees’ years of service and earnings, or in accordance with applicable employee benefit regulations. The Company’s practice is to fund amounts sufficient to meet the requirements set forth in the applicable employee benefit and tax regulations. The costs of $2.8 million and $3.3 million recorded for the three months ended September 30, 2022 and 2021, respectively, and $5.6 million and $6.6 million for the six months ended September 30, 2022 and 2021, respectively, were primarily related to service costs.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-22-027224:notes:33]
[same as prior period, unchanged from 0001032975-22-000034:notes:34]

[0001628280-22-027224:notes:34]
[same as prior period, unchanged from 0001032975-22-000034:notes:35]

[0001628280-22-027224:notes:35]
The income tax provision for the three and six months ended September 30, 2022 was $23.4 million and $45.1 million, based on an effective income tax rate of 22.2% and 19.8% of pre-tax income, respectively. The income tax provision for the same periods ended September 30, 2021 was $33.5 million and $58.4 million, based on an effective income tax rate of 19.3% and 15.2% of pre-tax income, respectively.

[0001628280-22-027224:notes:36]
The change in the effective income tax rate for the three and six months ended September 30, 2022 was primarily due to the mix of income and losses in the various tax jurisdictions in which the Company operates. There was a discrete tax provision of $0.2 million and a discrete tax benefit of $1.2 million from the recognition of shortfalls and excess tax benefits, respectively, in the United States in the three and six months ended September 30, 2022. In addition, there were discrete tax benefits of $0.3 million and $1.5 million from the reversal of uncertain tax positions from the expiration of statutes of limitations, respectively, in the three and six month period ended September 30, 2022. The change in the effective income tax rate for the three and six months ended September 30, 2021 was primarily due to the mix of income and losses in the various tax jurisdictions in which the Company operates. There were discrete tax benefits of $0.6 million and $14.3 million from the recognition of excess tax benefits in the United States in the three and six months ended September 30, 2021, respectively. Furthermore, there were discrete tax benefits of $0.5 million and $1.5 million from the reversal of uncertain tax positions from the expiration of statutes of limitations, respectively, in the three and six month period ended September 30, 2021.

[0001628280-22-027224:notes:37]
As of September 30, 2022 and March 31, 2022, the total amount of unrecognized tax benefits due to uncertain tax positions was $174.9 million and $176.0 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001628280-22-027224:notes:38]
As of September 30, 2022 and March 31, 2022, the Company had $97.5 million and $83.4 million, respectively, in non-current income taxes payable including interest and penalties, related to the Company's income tax liability for uncertain tax positions.

[0001628280-22-027224:notes:39]
The Company recognizes interest and penalties related to unrecognized tax positions in the income tax provision. As of September 30, 2022 and March 31, 2022, the Company had $4.9 million and $3.6 million, respectively, of accrued interest and penalties related to uncertain tax positions in non-current income taxes payable.

[0001628280-22-027224:notes:40]
Although the Company has adequately provided for uncertain tax positions, the provisions related to these positions may change as revised estimates are made or the underlying matters are settled or otherwise resolved. During fiscal year 2023, the Company continues to review its tax positions and provide for or reverse unrecognized tax benefits as they arise. During the next twelve months, it is reasonably possible that the amount of unrecognized tax benefits could increase or decrease significantly due to changes in tax law in various jurisdictions, new tax audits and changes in the U.S. dollar as compared to other currencies. Excluding these factors, uncertain tax positions may decrease by as much as $4.2 million from the lapse of the statutes of limitations in various jurisdictions during the next twelve months.
On August 16, 2022, the “Inflation Reduction Act” (H.R. 5376) ("IRA") was signed into law in the United States. The IRA establishes a new corporate alternative minimum tax based on financial statement income adjusted for certain items. The new minimum tax is effective for tax years beginning after December 31, 2022. The Company does not expect the IRA will have a material impact to the Company's financial statements when it becomes effective.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001628280-22-027224:notes:41]
[same as prior period, unchanged from 0001032975-22-000034:notes:42]

[0001628280-22-027224:notes:42]
[same as prior period, unchanged from 0001032975-22-000034:notes:43]

[0001628280-22-027224:notes:43]
|  |  | September 30, 2022 |  | March 31, 2022 |
| Accounts receivable, net: |  |  |  |  |
| Accounts receivable |  | $ | 1,014,934 |  |  | $ | 964,766 |  |
| Allowance for doubtful accounts |  | — |  |  | (2,212) |  |
| Allowance for sales returns |  | (10,499) |  |  | (12,321) |  |
| Allowance for cooperative marketing arrangements |  | (45,172) |  |  | (56,372) |  |
| Allowance for customer incentive programs |  | (74,194) |  |  | (97,460) |  |
| Allowance for pricing programs |  | (112,338) |  |  | (120,797) |  |
|  |  | $ | 772,731 |  |  | $ | 675,604 |  |
| Inventories: |  |  |  |  |
| Raw materials |  | $ | 225,010 |  |  | $ | 226,155 |  |
| Finished goods |  | 654,969 |  |  | 706,969 |  |
|  |  | $ | 879,979 |  |  | $ | 933,124 |  |
| Other current assets: |  |  |  |  |
| Value-added tax ("VAT") receivables |  | $ | 47,686 |  |  | $ | 58,850 |  |
| Prepaid expenses and other assets |  | 89,238 |  |  | 76,628 |  |
|  |  | $ | 136,924 |  |  | $ | 135,478 |  |
| Property, plant and equipment, net: |  |  |  |  |
| Property, plant and equipment |  | $ | 488,686 |  |  | $ | 459,413 |  |
| Less: accumulated depreciation and amortization |  | (375,359) |  |  | (349,606) |  |
|  |  | $ | 113,327 |  |  | $ | 109,807 |  |
| Other assets: |  |  |  |  |
| Deferred tax assets |  | $ | 195,728 |  |  | $ | 193,629 |  |
| Investments in privately held companies |  | 33,767 |  |  | 43,068 |  |
| Right-of-use assets |  | 77,767 |  |  | 40,661 |  |
| Investments for deferred compensation plan |  | 27,969 |  |  | 28,431 |  |
| Other assets |  | 14,819 |  |  | 14,933 |  |
|  |  | $ | 350,050 |  |  | $ | 320,722 |  |

[0001628280-22-027224:notes:44]
[same as prior period, unchanged from 0001032975-22-000034:notes:45]

[0001628280-22-027224:notes:45]
|  |  | September 30, 2022 |  | March 31, 2022 |
| Accrued and other current liabilities: |  |  |  |  |
| Accrued customer marketing, pricing and incentive programs |  | $ | 221,894 |  |  | $ | 232,393 |  |
| Accrued personnel expenses |  | 90,561 |  |  | 165,090 |  |
| Accrued sales return liability |  | 48,583 |  |  | 40,507 |  |
| Warranty accrual |  | 29,882 |  |  | 32,987 |  |
| VAT payable |  | 25,062 |  |  | 39,602 |  |
| Income taxes payable |  | 22,783 |  |  | 35,355 |  |
| Accrued payables - non-inventory |  | 16,147 |  |  | 26,722 |  |
| Operating lease liabilities |  | 11,687 |  |  | 13,690 |  |
| Contingent consideration |  | 5,083 |  |  | 8,042 |  |
| Other current liabilities |  | 191,939 |  |  | 190,460 |  |
|  |  | $ | 663,621 |  |  | $ | 784,848 |  |
| Other non-current liabilities: |  |  |  |  |
| Employee benefit plan obligations |  | $ | 46,872 |  |  | $ | 50,741 |  |
| Operating lease liabilities |  | 68,250 |  |  | 28,207 |  |
| Obligation for deferred compensation plan |  | 27,969 |  |  | 28,431 |  |
| Warranty accrual |  | 12,078 |  |  | 13,232 |  |
| Deferred tax liabilities |  | 3,117 |  |  | 1,962 |  |
| Contingent consideration |  | 245 |  |  | 4,217 |  |
| Other non-current liabilities |  | 10,173 |  |  | 5,343 |  |
|  |  | $ | 168,704 |  |  | $ | 132,133 |  |

[0001628280-22-027224:notes:46]
The Company recorded approximately $47.0 million right-of-use assets and operating lease liabilities during the six months ended September 30, 2022, primarily related to newly commenced operating leases for office spaces in the Americas and EMEA regions.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001628280-22-027224:notes:47]
[same as prior period, unchanged from 0001032975-22-000034:notes:47]

[0001628280-22-027224:notes:48]
[same as prior period, unchanged from 0001032975-22-000034:notes:48]

[0001628280-22-027224:notes:49]
[same as prior period, unchanged from 0001032975-22-000034:notes:49]

[0001628280-22-027224:notes:50]
[same as prior period, unchanged from 0001032975-22-000034:notes:50]

[0001628280-22-027224:notes:51]
[same as prior period, unchanged from 0001032975-22-000034:notes:51]

[0001628280-22-027224:notes:52]
[same as prior period, unchanged from 0001032975-22-000034:notes:52]

[0001628280-22-027224:notes:53]
|  |  | September 30, 2022 |  | March 31, 2022 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Level 1 |  | Level 2 |  | Level 3 |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 553,644 |  |  | $ | — |  |  | $ | — |  |  | $ | 762,055 |  |  | $ | — |  |  | $ | — |  |
| Investments for deferred compensation plan included in other assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 164 |  |  | $ | — |  |  | $ | — |  |  | $ | 108 |  |  | $ | — |  |  | $ | — |  |
| Common stock |  | 1,703 |  |  | — |  |  | — |  |  | 2,329 |  |  | — |  |  | — |  |
| Money market funds |  | 9,052 |  |  | — |  |  | — |  |  | 6,765 |  |  | — |  |  | — |  |
| Mutual funds |  | 17,050 |  |  | — |  |  | — |  |  | 19,229 |  |  | — |  |  | — |  |
| Total of investments for deferred compensation plan |  | $ | 27,969 |  |  | $ | — |  |  | $ | — |  |  | $ | 28,431 |  |  | $ | — |  |  | $ | — |  |
| Currency derivative assetsincluded in other current assets |  | $ | — |  |  | $ | 3,270 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,517 |  |  | $ | — |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Contingent consideration included in accrued and other current liabilities |  | $ | — |  |  | $ | — |  |  | $ | 5,083 |  |  | $ | — |  |  | $ | — |  |  | $ | 8,042 |  |
| Contingent consideration included in other non-current liabilities |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 3,971 |  |
| Currency derivative liabilitiesincluded in accrued and other current liabilities |  | $ | — |  |  | $ | 150 |  |  | $ | — |  |  | $ | — |  |  | $ | 165 |  |  | $ | — |  |

[0001628280-22-027224:notes:54]
[same as prior period, unchanged from 0001032975-22-000034:notes:54]

[0001628280-22-027224:notes:55]
The following table summarizes the change in the fair value of the Company's contingent consideration balance during the six months ended September 30, 2022 and 2021 (in thousands):

[0001628280-22-027224:notes:56]
|  |  | Six Months EndedSeptember 30, |
|  |  | 2022 |  | 2021 |
| Beginning of the period |  | $ | 12,259 |  |  | $ | 6,967 |  |
| Fair value of contingent consideration upon acquisition (1) |  | 1,142 |  |  | 9,973 |  |
| Change in fair value of contingent consideration |  | — |  |  | (2,399) |  |
| Settlement of contingent consideration |  | (5,954) |  |  | — |  |
| Effect of foreign currency exchange rate changes |  | (2,119) |  |  | — |  |
| End of the period |  | $ | 5,328 |  |  | $ | 14,541 |  |

[0001628280-22-027224:notes:57]
[same as prior period, unchanged from 0001032975-22-000034:notes:57]

[0001628280-22-027224:notes:58]
The contingent consideration arising from the technology acquisition on May 19, 2021, represents the future potential earn-out payments of up to $10.0 million payable in cash only upon the achievement of three technical development milestones required to be completed as of December 31, 2021, June 30, 2022, and June 30, 2023. The fair value of the contingent consideration as of the acquisition date was $10.0 million, which was determined using a probability-weighted expected payment model and discounted at the estimated cost of debt. During the third quarter of fiscal year 2022, $0.9 million of the contingent consideration was released from other current liabilities upon cash settlement of the contingent consideration for the first technical development milestone. During the second quarter of fiscal year 2023, the Company paid $4.0 million for the contingent consideration related to the second technical development milestone.

[0001628280-22-027224:notes:59]
The contingent consideration arising from the Mevo Acquisition on February 17, 2021 represents the future potential earn-out payments of up to $17.0 million payable in cash only upon the achievement of certain net sales

[0001628280-22-027224:notes:60]
for the period from December 26, 2020 to December 31, 2021. As of March 31, 2021 the fair value of the contingent consideration was $3.4 million. As of December 31, 2021, the fair value of the contingent consideration was released from other current liabilities as the net sales milestone was not achieved upon completion of the earn-out period.

[0001628280-22-027224:notes:61]
The contingent consideration arising from the technology acquisition on January 4, 2021, represents the future potential earn-out payments of up to $3.0 million payable in cash upon the achievement of two technical development milestones required to be completed as of December 31, 2021 and March 31, 2022. The fair value of the contingent amount was determined using a probability-weighted expected payment model and discounted at the estimated cost of debt. During the second quarter of fiscal year 2023, the Company paid $2.0 million for the contingent consideration related to the first technical development milestone.

[0001628280-22-027224:notes:62]
[same as prior period, unchanged from 0001032975-22-000034:notes:62]

[0001628280-22-027224:notes:63]
[same as prior period, unchanged from 0001032975-22-000034:notes:63]

[0001628280-22-027224:notes:64]
The marketable securities for the Company's deferred compensation plan were recorded at a fair value of $28.0 million and $28.4 million, as of September 30, 2022 and March 31, 2022, respectively, based on quoted market prices. Quoted market prices are observable inputs that are classified as Level 1 within the fair value hierarchy. Unrealized gains (losses) related to marketable securities for the three and six months ended September 30, 2022 and 2021 were not material and were included in other income (expense), net in the Company's condensed consolidated statements of operations.

[0001628280-22-027224:notes:65]
[same as prior period, unchanged from 0001032975-22-000034:notes:65]

[0001628280-22-027224:notes:66]
The Company has certain non-marketable investments included in other assets that are accounted for as equity method investments, with a carrying value of $22.9 million and $40.2 million as of September 30, 2022 and March 31, 2022, respectively. Unrealized gains (losses) related to equity method investments for the three and six months ended September 30, 2022 and 2021 were not material and are included in other income (expense), net in the Company's condensed consolidated statements of operations.

[0001628280-22-027224:notes:67]
During the three months ended September 30, 2022, the Company recorded an impairment charge, before tax, of $21.4 million for one of its equity method investments as it was determined that the carrying value of the investment was not recoverable. The impairment charge is included in other income (expense), net in the Company's condensed consolidated statements of operations for the three and six months ended September 30, 2022. There was no impairment of equity method investments during the three and six months ended September 30, 2021.

[0001628280-22-027224:notes:68]
[same as prior period, unchanged from 0001032975-22-000034:notes:67]

[0001628280-22-027224:notes:69]
Financial Assets.  The Company has certain equity investments without readily determinable fair values due to the absence of quoted market prices, the inherent lack of liquidity, and the fact that inputs used to measure fair value are unobservable and require management's judgment. When certain events or circumstances indicate that impairment may exist, the Company revalues the investments using various assumptions, including the financial metrics and ratios of comparable public companies. The carrying value is also adjusted for observable price changes with the same or similar security from the same issuer. The amount of these equity investments without readily determinable fair value included in other assets was $10.9 million and $2.9 million as of September 30, 2022 and March 31, 2022, respectively. During the six months ended September 30, 2022, the Company recorded an unrealized gain, before tax, of $6.9 million for its investment in a private company as a result of observable price changes for similar securities issued by this company (level 2 fair value measurement). There was no impairment of these financial assets during the three and six months ended September 30, 2022 and 2021, other than an immaterial impairment charge related to one of the Company’s investments without readily determinable fair value recorded during the three months ended September 30, 2022.

[0001628280-22-027224:notes:70]
Non-Financial Assets.  Goodwill, intangible assets, and property, plant and equipment, are not required to be measured at fair value on a recurring basis. However, if certain triggering events occur such that a non-financial instrument is required to be evaluated for impairment and an impairment is recorded to reduce the non-financial 
instrument's carrying value to the fair value as a result of such triggering events (or as a result of the Company's annual impairment analysis for goodwill), the non-financial assets and liabilities are measured at fair value during such period. There was no impairment of non-financial assets during the three and six months ended September 30, 2022 and 2021.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001628280-22-027224:notes:71]
[same as prior period, unchanged from 0001032975-22-000034:notes:70]

[0001628280-22-027224:notes:72]
Under certain agreements with the respective counterparties to the Company’s derivative contracts, subject to applicable requirements, the Company is allowed to net settle transactions of the same type with a single net amount payable by one party to the other. However, the Company presents its derivative assets and derivative liabilities on a gross basis in other current assets and accrued and other current liabilities, respectively, on the condensed consolidated balance sheets as of September 30, 2022 and March 31, 2022. See Note 6 for the fair values of the Company’s derivative instruments as of September 30, 2022 and March 31, 2022.

[0001628280-22-027224:notes:73]
[same as prior period, unchanged from 0001032975-22-000034:notes:73]

[0001628280-22-027224:notes:74]
[same as prior period, unchanged from 0001032975-22-000034:notes:74]

[0001628280-22-027224:notes:75]
The notional amounts of foreign currency exchange forward contracts outstanding related to forecasted inventory purchases were $115.0 million and $125.4 million as of September 30, 2022 and March 31, 2022, respectively. The Company had $6.4 million of net gains related to its cash flow hedges included in accumulated other comprehensive loss as of September 30, 2022, which will be reclassified into earnings within the next twelve months.

[0001628280-22-027224:notes:76]
The following table presents the amounts of gains on the Company’s derivative instruments designated as hedging instruments for the three and six months ended September 30, 2022 and 2021 and their locations on its condensed consolidated statements of operations and condensed consolidated statements of comprehensive income (in thousands):

[0001628280-22-027224:notes:77]
|  |  | Three Months EndedSeptember 30, |
|  |  | Amount of GainDeferred as a Component of AccumulatedOther Comprehensive Loss |  | Amount of GainReclassified from Accumulated Other Comprehensive Loss to Costs of Goods Sold |  |  |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |  |  |  |  |
| Cash flow hedges |  | $ | 4,935 |  |  | $ | 2,132 |  |  | $ | (4,947) |  |  | $ | (1,314) |  |  |  |  |  |
|  |  | Six Months EndedSeptember 30, |
|  |  | Amount of GainDeferred as a Component of AccumulatedOther Comprehensive Loss |  | Amount of GainReclassified from Accumulated Other Comprehensive Loss to Costs of Goods Sold |  |  |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |  |  |  |  |
| Cash flow hedges |  | $ | 11,564 |  |  | $ | 2,662 |  |  | $ | (7,038) |  |  | $ | (1,908) |  |  |  |  |  |

[0001628280-22-027224:notes:78]
[same as prior period, unchanged from 0001032975-22-000034:notes:78]

[0001628280-22-027224:notes:79]
[same as prior period, unchanged from 0001032975-22-000034:notes:79]

[0001628280-22-027224:notes:80]
The Company also enters into foreign currency exchange forward and swap contracts to reduce the short-term effects of currency exchange rate fluctuations on certain receivables or payables denominated in currencies other than the functional currencies of its subsidiaries. These contracts generally mature within a month. The primary risk managed by using forward and swap contracts is the currency exchange rate risk. The gains or losses on these contracts are not material and included in other income (expense), net in the condensed consolidated statements of operations based on the changes in fair value. The notional amounts of these contracts outstanding as of September 30, 2022 and March 31, 2022 were $204.6 million and $226.5 million, respectively. Foreign currency exchange forward and swap contracts outstanding as of September 30, 2022 and March 31, 2022 consisted of contracts in Japanese Yen, Brazilian Real, Australian Dollars, Canadian Dollars, Mexican Pesos, Chinese Renminbi, and New Taiwan Dollars, to be settled at future dates at pre-determined exchange rates.

[0001628280-22-027224:notes:81]
[same as prior period, unchanged from 0001032975-22-000034:notes:81]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001628280-22-027224:notes:82]
Goodwill and Other Intangible Assets
The Company conducts its impairment analysis of goodwill and indefinite life intangible assets annually on December 31 or more frequently if changes in facts and circumstances indicate that it is more likely than not that the fair value of the Company’s reporting unit may be less than its carrying amount. There have been no triggering events identified affecting the valuation of goodwill and indefinite life intangible assets during the three and six months ended September 30, 2022 and 2021.

[0001628280-22-027224:notes:83]
[same as prior period, unchanged from 0001032975-22-000034:notes:83]

[0001628280-22-027224:notes:84]
| As of March 31, 2022 |  | $ | 448,175 |  |
| Acquisition |  | 4,980 |  |
| Effects of foreign currency translation |  | (3,263) |  |
| As of September 30, 2022 |  | $ | 449,892 |  |

[0001628280-22-027224:notes:85]
[same as prior period, unchanged from 0001032975-22-000034:notes:85]

[0001628280-22-027224:notes:86]
|  |  | September 30, 2022 |  | March 31, 2022 |
|  |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |
| Trademark and trade names |  | $ | 36,790 |  |  | $ | (24,628) |  |  | $ | 12,162 |  |  | $ | 36,790 |  |  | $ | (22,295) |  |  | $ | 14,495 |  |
| Developed technology |  | 122,142 |  |  | (89,775) |  |  | 32,367 |  |  | 119,407 |  |  | (83,540) |  |  | 35,867 |  |
| Customer contracts/relationships |  | 71,110 |  |  | (44,416) |  |  | 26,694 |  |  | 71,110 |  |  | (40,971) |  |  | 30,139 |  |
| In-process R&D |  | 3,526 |  |  | — |  |  | 3,526 |  |  | 3,826 |  |  | — |  |  | 3,826 |  |
| Effects of foreign currency translation |  | (1,598) |  |  | 344 |  |  | (1,254) |  |  | (634) |  |  | 86 |  |  | (548) |  |
| Total |  | $ | 231,970 |  |  | $ | (158,475) |  |  | $ | 73,495 |  |  | $ | 230,499 |  |  | $ | (146,720) |  |  | $ | 83,779 |  |


## us-gaap:DebtDisclosureTextBlock

[0001628280-22-027224:notes:87]
Financing Arrangements

[0001628280-22-027224:notes:88]
The Company had several uncommitted, unsecured bank lines of credit aggregating $176.0 million and $195.0 million as of September 30, 2022 and March 31, 2022, respectively. There are no financial covenants under these lines of credit with which the Company must comply. As of September 30, 2022 and March 31, 2022, the Company 
had outstanding bank guarantees of $22.2 million and $25.5 million, respectively, under these lines of credit. There was no borrowing outstanding under these lines of credit as of September 30, 2022 or March 31, 2022.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-22-027224:notes:89]
Commitments and Contingencies

[0001628280-22-027224:notes:90]
Product Warranties

[0001628280-22-027224:notes:91]
Changes in the Company’s warranty liability for the three and six months ended September 30, 2022 and 2021 were as follows (in thousands):

[0001628280-22-027224:notes:92]
|  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Beginning of the period | $ | 43,841 |  |  | $ | 49,093 |  |  | $ | 46,219 |  |  | $ | 48,832 |  |
| Provision | 7,897 |  |  | 8,095 |  |  | 14,520 |  |  | 16,541 |  |
| Settlements | (9,098) |  |  | (7,848) |  |  | (17,379) |  |  | (16,163) |  |
| Effects of foreign currency translation | (680) |  |  | (167) |  |  | (1,400) |  |  | (37) |  |
| End of the period | $ | 41,960 |  |  | $ | 49,173 |  |  | $ | 41,960 |  |  | $ | 49,173 |  |

[0001628280-22-027224:notes:93]
Indemnifications

[0001628280-22-027224:notes:94]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of September 30, 2022, no material amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

[0001628280-22-027224:notes:95]
The Company also indemnifies its current and former directors and certain of its current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. The Company is unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not limited, the obligations are conditional in nature and the facts and circumstances involved in any situation that might arise are variable.

[0001628280-22-027224:notes:96]
Legal Proceedings

[0001628280-22-027224:notes:97]
From time to time the Company is involved in claims and legal proceedings that arise in the ordinary course of its business. The Company is currently subject to several such claims and a small number of legal proceedings. The Company believes that these matters lack merit and intends to vigorously defend against them. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company's defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company's business, financial condition, cash flows and results of operations in a particular period. Any claims or proceedings against the Company, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain a necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company's business.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001628280-22-027224:notes:98]
[same as prior period, unchanged from 0001032975-22-000034:notes:98]

[0001628280-22-027224:notes:99]
In May 2020, the Company's Board of Directors approved the 2020 share repurchase program, which authorized the Company to use up to $250.0 million to purchase up to 17.3 million of Logitech shares. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Purchases may be started or stopped at any time without prior notice depending on market conditions and other factors. In April 2021, the Company's Board of Directors approved an increase of $750.0 million of the 2020 share repurchase program, to an

[0001628280-22-027224:notes:100]
aggregate amount of $1.0 billion. The Swiss Takeover Board approved this increase and it became effective on May 21, 2021.

[0001628280-22-027224:notes:101]
In July 2022, the Company’s Board of Directors approved an increase of $500 million to the 2020 share repurchase program, to an aggregate amount of up to $1.5 billion to purchase up to 17.3 million of Logitech shares. The Swiss Takeover Board approved this increase and it became effective on August 19, 2022. As of September 30, 2022, $686.3 million was available for repurchase under the 2020 repurchase program. The 2020 share repurchase program is expected to remain in effect for a period of three years through July 27, 2023.

[0001628280-22-027224:notes:102]
Dividends

[0001628280-22-027224:notes:103]
During the three and six months ended September 30, 2022, the Company declared and paid cash dividends of CHF 0.96 (USD equivalent of $1.00 based on the exchange rate on the date of declaration) per share, totaling $162.7 million on the Company's outstanding shares. During the three and six months ended September 30, 2021, the Company declared and paid cash dividends of CHF 0.87 (USD equivalent of $0.95 based on the exchange rate on the date of declaration) per share, totaling $159.4 million on the Company's outstanding shares.

[0001628280-22-027224:notes:104]
Any future dividends will be subject to approval of the Company's shareholders.

[0001628280-22-027224:notes:105]
[same as prior period, unchanged from 0001032975-22-000034:notes:101]

[0001628280-22-027224:notes:106]
[same as prior period, unchanged from 0001032975-22-000034:notes:102]

[0001628280-22-027224:notes:107]
|  |  | CumulativeTranslationAdjustment |  | DefinedBenefitPlans |  | Deferred Hedging Gains |  | Total |
| March 31, 2022 |  | $ | (102,461) |  |  | $ | (3,495) |  |  | $ | 1,833 |  |  | $ | (104,123) |  |
| Other comprehensive income (loss) |  | (39,283) |  |  | (114) |  |  | 4,526 |  |  | (34,871) |  |
| September 30, 2022 |  | $ | (141,744) |  |  | $ | (3,609) |  |  | $ | 6,359 |  |  | $ | (138,994) |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-22-027224:notes:108]
[same as prior period, unchanged from 0001032975-22-000034:notes:104]

[0001628280-22-027224:notes:109]
The Company operates in a single operating segment that encompasses the design, manufacturing and marketing of peripherals for PCs, tablets and other digital platforms. Operating performance measures are provided directly to the Company's CEO, who is considered to be the Company’s Chief Operating Decision Maker. The CEO periodically reviews information such as sales and adjusted operating income (loss) to make business decisions. These operating performance measures do not include restructuring charges, net, share-based compensation expense, amortization of intangible assets, acquisition-related costs and change in fair value of contingent consideration from business acquisition.

[0001628280-22-027224:notes:110]
Sales by product categories and sales channels, excluding intercompany transactions, for the three and six months ended September 30, 2022 and 2021 were as follows (in thousands):

[0001628280-22-027224:notes:111]
|  |  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Pointing Devices |  | $ | 185,200 |  |  | $ | 189,014 |  |  | $ | 368,483 |  |  | $ | 371,892 |  |
| Keyboards & Combos |  | 200,853 |  |  | 236,272 |  |  | 428,573 |  |  | 454,629 |  |
| PC Webcams |  | 60,166 |  |  | 94,471 |  |  | 119,552 |  |  | 204,389 |  |
| Tablet & Other Accessories |  | 54,203 |  |  | 80,801 |  |  | 120,788 |  |  | 160,073 |  |
| Gaming (1) |  | 297,676 |  |  | 330,777 |  |  | 580,482 |  |  | 666,174 |  |
| Video Collaboration |  | 236,180 |  |  | 231,653 |  |  | 482,422 |  |  | 466,538 |  |
| Mobile Speakers |  | 39,195 |  |  | 39,492 |  |  | 61,505 |  |  | 67,976 |  |
| Audio & Wearables |  | 73,271 |  |  | 98,078 |  |  | 142,717 |  |  | 214,685 |  |
| Other (2) |  | 2,207 |  |  | 5,709 |  |  | 4,294 |  |  | 11,969 |  |
| Total Sales |  | $ | 1,148,951 |  |  | $ | 1,306,267 |  |  | $ | 2,308,816 |  |  | $ | 2,618,325 |  |

[0001628280-22-027224:notes:112]
[same as prior period, unchanged from 0001032975-22-000034:notes:108]

[0001628280-22-027224:notes:113]
[same as prior period, unchanged from 0001032975-22-000034:notes:109]

[0001628280-22-027224:notes:114]
Sales by geographic region (based on the customers’ locations) for the three and six months ended September 30, 2022 and 2021 were as follows (in thousands):

[0001628280-22-027224:notes:115]
|  |  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Americas |  | $ | 492,176 |  |  | $ | 541,515 |  |  | $ | 994,483 |  |  | $ | 1,154,081 |  |
| EMEA |  | 297,176 |  |  | 399,452 |  |  | 587,655 |  |  | 757,409 |  |
| Asia Pacific |  | 359,599 |  |  | 365,300 |  |  | 726,678 |  |  | 706,835 |  |
| Total sales |  | $ | 1,148,951 |  |  | $ | 1,306,267 |  |  | $ | 2,308,816 |  |  | $ | 2,618,325 |  |

[0001628280-22-027224:notes:116]
[same as prior period, unchanged from 0001032975-22-000034:notes:112]

[0001628280-22-027224:notes:117]
Switzerland, the Company’s home domicile, represented 2% and 3% of the Company's total consolidated sales for the three months ended September 30, 2022 and 2021, respectively, and 2% and 3% for the six months ended September 30, 2022 and 2021, respectively.

[0001628280-22-027224:notes:118]
Three customers of the Company each represented 10% or more of the total consolidated gross sales for the three and six months ended September 30, 2022, respectively. Two customers of the Company each represented 10% or more of the total consolidated sales for the three and six months ended September 30, 2021, respectively.

[0001628280-22-027224:notes:119]
[same as prior period, unchanged from 0001032975-22-000034:notes:115]

[0001628280-22-027224:notes:120]
|  |  | September 30, 2022 |  | March 31, 2022 |
| Americas |  | $ | 51,469 |  |  | $ | 22,578 |  |
| EMEA |  | 36,214 |  |  | 23,830 |  |
| Asia Pacific |  | 84,091 |  |  | 87,265 |  |
| Total |  | $ | 171,774 |  |  | $ | 133,673 |  |

[0001628280-22-027224:notes:121]
Property, plant and equipment, net (excluding software) and right-of-use assets in the United States and China were $50.8 million and $63.4 million, respectively, as of September 30, 2022, and $21.7 million and $66.8 million, respectively, as of March 31, 2022. Property, plant and equipment, net (excluding software) and right-of-use assets in Switzerland, the Company’s country of incorporation, were $13.2 million and $13.6 million as of September 30, 2022 and March 31, 2022, respectively. No other countries represented 10% or more of the Company’s total 
consolidated property, plant and equipment, net (excluding software) and right-of-use assets as of September 30, 2022 or March 31, 2022.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001628280-22-027224:notes:122]
Restructuring During the second quarter of fiscal year 2023, the Company initiated a restructuring plan to realign its business group and engineering structure with its go-to-market strategy to more effectively compete within the enterprise market and to better serve end-users. As a result, the Company recorded pre-tax restructuring charges of $10.8 million, related to employee severance and other termination benefits, for the three and six months ended September 30, 2022, which are included in restructuring charges, net in the condensed consolidated statement of operations. As of September 30, 2022, restructuring liabilities of $9.7 million are included in accrued and other current liabilities in the condensed consolidated balance sheet. The Company expects to substantially complete this restructuring within the next twelve months.
