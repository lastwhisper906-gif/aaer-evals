# LOGI note change history — 0001032975-22-000034 → 0001628280-22-027224


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-10-27):
[0001628280-22-027224:note_history:1]
Changes in the Company’s warranty liability for the three and six months ended September 30, 2022 and 2021 were as follows (in thousands):
  (was, 2022-07-28, similarity 0.9231):
[0001032975-22-000034:note_history:1]
Changes in the Company’s warranty liability for the three months ended June 30, 2022 and 2021 were as follows (in thousands):

- added (2022-10-27):
[0001628280-22-027224:note_history:2]
|  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Beginning of the period | $ | 43,841 |  |  | $ | 49,093 |  |  | $ | 46,219 |  |  | $ | 48,832 |  |
| Provision | 7,897 |  |  | 8,095 |  |  | 14,520 |  |  | 16,541 |  |
| Settlements | (9,098) |  |  | (7,848) |  |  | (17,379) |  |  | (16,163) |  |
| Effects of foreign currency translation | (680) |  |  | (167) |  |  | (1,400) |  |  | (37) |  |
| End of the period | $ | 41,960 |  |  | $ | 49,173 |  |  | $ | 41,960 |  |  | $ | 49,173 |  |

- changed (2022-10-27):
[0001628280-22-027224:note_history:3]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of September 30, 2022, no material amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.
  (was, 2022-07-28, similarity 0.99):
[0001032975-22-000034:note_history:3]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of June 30, 2022, no material amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

- changed (2022-10-27):
[0001628280-22-027224:note_history:4]
From time to time the Company is involved in claims and legal proceedings that arise in the ordinary course of its business. The Company is currently subject to several such claims and a small number of legal proceedings. The Company believes that these matters lack merit and intends to vigorously defend against them. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company's defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company's business, financial condition, cash flows and results of operations in a particular period. Any claims or proceedings against the Company, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain a necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company's business.
  (was, 2022-07-28, similarity 0.9886):
[0001032975-22-000034:note_history:4]
From time to time the Company is involved in claims and legal proceedings which arise in the ordinary course of its business. The Company is currently subject to several such claims and a small number of legal proceedings. The Company believes that these matters lack merit and intends to vigorously defend against them. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial position, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company's defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company's business, financial position, cash flows or results of operations in a particular period. Any claims or proceedings against the Company, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain a necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company's business.

- removed (2022-10-27):
[0001032975-22-000034:note_history:5]
|  | Three Months EndedJune 30, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| Beginning of the period | $ | 46,219 |  |  | $ | 48,832 |  |  |  |  |  |
| Provision | 6,623 |  |  | 8,446 |  |  |  |  |  |
| Settlements | (8,281) |  |  | (8,315) |  |  |  |  |  |
| Effects of foreign currency translation | (720) |  |  | 130 |  |  |  |  |  |
| End of the period | $ | 43,841 |  |  | $ | 49,093 |  |  |  |  |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-10-27):
[0001628280-22-027224:note_history:6]
Logitech International S.A, together with its consolidated subsidiaries ("Logitech" or the "Company"), designs, manufactures and markets products that help connect people to digital and cloud experiences. Over forty years ago, Logitech created products to improve experiences around the personal computer ("PC") platform, and today it is a multi-brand, multi-category company designing products that enable better experiences consuming, sharing and creating any digital content such as computing, gaming, video, and music, whether it is on a computer, mobile device or in the cloud.
  (was, 2022-07-28, similarity 0.9957):
[0001032975-22-000034:note_history:6]
Logitech International S.A, together with its consolidated subsidiaries ("Logitech" or the "Company"), designs, manufactures and markets products that help connect people to digital and cloud experiences. Forty years ago, Logitech created products to improve experiences around the personal computer ("PC") platform, and today it is a multi-brand, multi-category company designing products that enable better experiences consuming, sharing and creating any digital content such as computing, gaming, video, and music, whether it is on a computer, mobile device or in the cloud.

- changed (2022-10-27):
[0001628280-22-027224:note_history:7]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and six months ended September 30, 2022 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2023, or any future periods.
  (was, 2022-07-28, similarity 0.7702):
[0001032975-22-000034:note_history:7]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three months ended June 30, 2022 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2023, or any future periods.

- changed (2022-10-27):
[0001628280-22-027224:note_history:8]
Other than the recent accounting pronouncements adopted and discussed below under Recent Accounting Pronouncements Adopted, there have been no material changes in the Company’s significant accounting policies during the six months ended September 30, 2022 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2022.
  (was, 2022-07-28, similarity 0.9351):
[0001032975-22-000034:note_history:8]
Other than the recent accounting pronouncements adopted and discussed below under Recent Accounting Pronouncements Adopted, there have been no material changes in the Company’s significant accounting policies during the three months ended June 30, 2022 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2022.

- changed (2022-10-27):
[0001628280-22-027224:note_history:9]
Impacts of Macroeconomic and Geopolitical Conditions and Other Factors on the Company's Business
  (was, 2022-07-28, similarity 0.8966):
[0001032975-22-000034:note_history:9]
Impacts of Macroeconomic and Geopolitical Conditions on the Company's Business

- added (2022-10-27):
[0001628280-22-027224:note_history:10]
In March 2020, the World Health Organization declared the outbreak of COVID-19 as a pandemic, which continues to spread throughout the world. The COVID-19 pandemic has resulted in industry-wide global supply chain challenges, including manufacturing, transportation and logistics. The Company purchases certain products and key components from a limited number of sources, and depends on the supply chain, including freight, to receive components, transport finished goods and deliver the Company's products across the world.

- added (2022-10-27):
[0001628280-22-027224:note_history:11]
More recently, the Company has also been impacted by adverse macroeconomic and geopolitical conditions. These conditions include but are not limited to inflation, foreign currency fluctuations, slow down of economic activity around the globe, in part due to rising interest rates, and lower consumer spending. In addition, the war in Ukraine has further increased existing global supply chain, logistics, and inflationary challenges. Such global or regional economic and political conditions adversely affect demand for the Company's products. These conditions also have an impact on the Company's suppliers, contract manufacturers, logistics providers, and distributors, causing increases in cost of materials and higher shipping and transportation rates, and as a result impacting the pricing of the Company's products. Price increases may not successfully offset cost increases or may cause the Company to lose market share and in turn adversely impact the Company's results of operations.

- added (2022-10-27):
[0001628280-22-027224:note_history:12]
While global supply chain challenges improved during the second quarter of fiscal 2023, including logistics costs, shipping lead times, and component availability, if macroeconomic and geopolitical conditions and COVID-19 related factors do not improve or worsen, the Company's results of operations may be adversely impacted.

- changed (2022-10-27):
[0001628280-22-027224:note_history:13]
In October 2021, the Financial Accounting Standard Board issued ASU 2021-08, "Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers" (ASU 2021-08). The update requires an acquirer in a business combination to recognize and measure contract assets and contract liabilities acquired in a business combination in accordance with Accounting Standards Codification ("ASC") 606, Revenue from Contracts with Customers, as if it had originated the contracts. The standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2022. The Company early adopted the standard effective April 1, 2022 and applies the standard prospectively to business combinations that occurred on or after April 1, 2022. The adoption of ASU 2021-08 did not have a material impact on the Company's condensed consolidated financial statements.
  (was, 2022-07-28, similarity 0.995):
[0001032975-22-000034:note_history:13]
In October 2021, the Financial Accounting Standard Board ("FASB") issued ASU 2021-08, "Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers" (ASU 2021-08). The update requires an acquirer in a business combination to recognize and measure contract assets and contract liabilities acquired in a business combination in accordance with Accounting Standards Codification ("ASC") 606, Revenue from Contracts with Customers, as if it had originated the contracts. The standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2022. The Company early adopted the standard effective April 1, 2022 and applies the standard prospectively to business combinations that occurred on or after April 1, 2022. The adoption of ASU 2021-08 did not have a material impact on the Company's condensed consolidated financial statements.

- removed (2022-10-27):
[0001032975-22-000034:note_history:14]
During the first quarter of fiscal year 2023, the Company was impacted by adverse macroeconomic and geopolitical conditions. These conditions include but are not limited to inflation, foreign currency fluctuations, and lower consumer spending. The Company also continues to be affected by supply chain challenges, and the war in Ukraine has further increased existing global supply chain, logistics, and inflationary challenges. Such global or regional economic and political conditions adversely affect demand for the Company's products. These conditions also have an impact on its suppliers, contract manufacturers, logistics providers, and distributors, causing increases in cost of materials and higher shipping and transportation rates, and as a result impacting the pricing of its products. Price increases may not successfully offset cost increases or may cause the Company to lose market share and in turn adversely impact its results of operations.

- removed (2022-10-27):
[0001032975-22-000034:note_history:15]
Impacts of COVID-19 on the Company's Business

- removed (2022-10-27):
[0001032975-22-000034:note_history:16]
In March 2020, the World Health Organization declared the outbreak of COVID-19 as a pandemic, which continues to spread throughout the world. The COVID-19 pandemic has resulted in, and could continue to result in, industry-wide global supply chain challenges, including manufacturing, transportation and logistics. The Company purchases certain products and key components from a limited number of sources, and depends on the supply chain, including freight, to receive components, transport finished goods and deliver its products across the world. While the Company proactively manages its supply chain, it expects to continue to be impacted by higher logistics and component costs, prolonged delays, and challenges with component availability. Most recently, Shanghai, China, experienced a two-month lockdown beginning in late March 2022 due to another outbreak of COVID-19, resulting in a lockdown of the city, closures of ports and airports, and disruption of commercial activities, further constraining the Company's supply chain. If additional lockdowns or similar measures are instituted in Shanghai or Suzhou, where the Company's manufacturing facility is located, or other places where the Company's suppliers and partners are located, such measures, depending on their duration, could cause additional negative impact on the Company's business and results of operations.

- removed (2022-10-27):
[0001032975-22-000034:note_history:17]
It is still difficult to predict the progression, the duration and all of the effects of COVID-19, how restrictions and shelter-at-home guidelines will continue evolving on a global basis, how consumer demand, supply chain challenges, including inventory and logistical effects and costs, may change over time, and the impact on the Company's future sales and results of operations. The full extent of the impact of the COVID-19 pandemic on the Company's business and operational and financial performance remains uncertain and will depend on many factors outside the Company's control.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2022-10-27):
[0001628280-22-027224:note_history:18]
The Company had several uncommitted, unsecured bank lines of credit aggregating $176.0 million and $195.0 million as of September 30, 2022 and March 31, 2022, respectively. There are no financial covenants under these lines of credit with which the Company must comply. As of September 30, 2022 and March 31, 2022, the Company 
had outstanding bank guarantees of $22.2 million and $25.5 million, respectively, under these lines of credit. There was no borrowing outstanding under these lines of credit as of September 30, 2022 or March 31, 2022.

- removed (2022-10-27):
[0001032975-22-000034:note_history:19]
The Company had several uncommitted, unsecured bank lines of credit aggregating $185.9 million and $195.0 million as of June 30, 2022 and March 31, 2022, respectively. There are no financial covenants under these lines of credit with which the Company must comply. As of June 30, 2022 and March 31, 2022, the Company had outstanding bank guarantees of $23.9 million and $25.5 million, respectively, under these lines of credit. There was no borrowing outstanding under these lines of credit as of June 30, 2022 or March 31, 2022.
