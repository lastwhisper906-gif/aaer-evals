# LOGI 8-K — 0001628280-22-026927 filed 2022-10-25

## item codes, every 8-K on or before 2022-10-27

- 2022-10-25 0001628280-22-026927 — 2.02, 5.02, 9.01
- 2022-09-16 0001628280-22-025080 — 5.07, 8.01
- 2022-07-26 0001032975-22-000027 — 2.02, 9.01
- 2022-06-29 0001032975-22-000018 — 5.02
- 2022-05-03 0001032975-22-000008 — 2.02, 9.01
- 2022-01-25 0001032975-22-000003 — 2.02, 9.01
- 2021-10-26 0001032975-21-000043 — 2.02, 9.01
- 2021-09-10 0001032975-21-000040 — 5.07, 8.01
- 2021-07-27 0001032975-21-000029 — 2.02, 9.01
- 2021-04-29 0001032975-21-000012 — 2.02, 9.01
- 2021-01-19 0001032975-21-000004 — 2.02, 9.01
- 2020-10-20 0001032975-20-000045 — 2.02, 9.01
- 2020-09-11 0001032975-20-000042 — 5.07, 8.01
- 2020-07-21 0001032975-20-000029 — 2.02, 9.01
- 2020-07-01 0001032975-20-000023 — 5.02, 8.01
- 2020-05-12 0001032975-20-000011 — 2.02, 9.01
- 2020-03-30 0001032975-20-000009 — 5.02
- 2020-01-21 0001032975-20-000002 — 2.02, 9.01
- 2019-10-22 0001032975-19-000071 — 9.01
- 2019-09-26 0001032975-19-000068 — 1.01, 7.01, 9.01
- 2019-09-06 0001032975-19-000063 — 5.07, 8.01
- 2019-07-23 0001032975-19-000046 — 2.02, 9.01
- 2019-07-23 0001032975-19-000045 — 5.02, 9.01
- 2019-07-02 0001032975-19-000036 — 5.02
- 2019-06-25 0001032975-19-000034 — 5.02
- 2019-05-03 0001032975-19-000021 — 5.02 — amendment, the index does not say of what
- 2019-04-30 0001032975-19-000017 — 2.02, 5.02, 9.01
- 2019-03-28 0001032975-19-000013 — 5.02
- 2019-01-22 0001032975-19-000004 — 2.02, 9.01
- 2018-10-23 0001032975-18-000044 — 2.02, 9.01
- 2018-09-07 0001032975-18-000040 — 5.07, 8.01
- 2018-07-31 0001032975-18-000035 — 1.01, 2.02, 2.05, 7.01, 9.01
- 2018-06-27 0001032975-18-000020 — 5.02
- 2018-05-03 0001032975-18-000013 — 2.02, 5.02, 9.01
- 2018-01-23 0001032975-18-000005 — 2.02, 9.01
- 2017-10-24 0001032975-17-000043 — 2.02, 9.01
- 2017-09-18 0001032975-17-000040 — 5.07, 8.01
- 2017-07-25 0001032975-17-000028 — 2.02, 9.01
- 2017-07-12 0001032975-17-000022 — 1.01
- 2017-04-26 0001032975-17-000012 — 2.02, 9.01
- 2017-01-25 0001032975-17-000002 — 2.02, 9.01
- 2016-10-26 0001032975-16-000103 — 2.02, 9.01
- 2016-09-13 0001032975-16-000101 — 5.07, 8.01
- 2016-07-28 0001032975-16-000092 — 2.02, 9.01
- 2016-06-30 0001032975-16-000087 — 5.02
- 2016-04-28 0001032975-16-000077 — 2.02, 9.01
- 2016-04-14 0001032975-16-000073 — 1.01, 7.01, 9.01
- 2016-01-21 0001032975-16-000064 — 2.02, 9.01
- 2016-01-04 0001032975-16-000061 — 1.01, 2.01, 9.01
- 2015-12-23 0001032975-15-000059 — 5.02
- 2015-10-22 0001032975-15-000047 — 2.02, 9.01
- 2015-09-11 0001032975-15-000044 — 5.07, 8.01
- 2015-07-24 0001032975-15-000034 — 2.05 — amendment of 0001032975-15-000030
- 2015-07-23 0001032975-15-000030 — 2.02, 9.01
- 2015-06-25 0001032975-15-000025 — 5.02
- 2015-05-14 0001032975-15-000011 — 8.01, 9.01
- 2015-04-23 0001032975-15-000008 — 2.02, 2.05
- 2015-01-22 0001628280-15-000191 — 2.02, 8.01
- 2014-12-23 0001193125-14-450908 — 5.02, 5.07, 8.01
- 2014-11-25 0001193125-14-425233 — 3.01
- 2014-11-13 0001193125-14-411303 — 4.01, 9.01
- 2014-10-23 0001104659-14-073164 — 2.02, 9.01
- 2014-09-04 0001193125-14-331214 — 4.02, 9.01
- 2014-08-18 0001193125-14-313346 — 3.01, 9.01
- 2014-07-24 0001104659-14-053065 — 2.02, 9.01
- 2014-06-05 0001193125-14-226177 — 3.01, 9.01
- 2014-05-22 0001193125-14-208777 — 8.01, 9.01
- 2014-04-24 0001104659-14-029650 — 2.02, 9.01
- 2014-01-23 0001104659-14-003619 — 2.02, 9.01
- 2013-10-24 0001104659-13-077404 — 2.02, 9.01
- 2013-09-09 0001193125-13-361441 — 5.02, 5.07, 8.01, 9.01
- 2013-09-06 0001193125-13-359930 — 5.02, 9.01
- 2013-08-02 0001193125-13-317343 — 5.02
- 2013-07-25 0001104659-13-056372 — 2.02, 9.01
- 2013-06-28 0001193125-13-277394 — 5.02, 9.01
- 2013-06-20 0001193125-13-265914 — 8.01, 9.01
- 2013-04-25 0001104659-13-032570 — 2.02, 9.01
- 2013-04-17 0001193125-13-158923 — 5.02, 9.01
- 2013-03-01 0001193125-13-085804 — 2.05
- 2013-01-24 0001104659-13-004214 — 2.02, 9.01
- 2013-01-02 0001193125-13-000058 — 5.02
- 2012-10-25 0001104659-12-070966 — 2.02, 9.01
- 2012-09-11 0001193125-12-388070 — 5.02, 5.07, 8.01, 9.01
- 2012-08-22 0001193125-12-364167 — 5.02, 8.01, 9.01
- 2012-07-26 0001104659-12-051084 — 2.02, 9.01
- 2012-06-08 0001193125-12-264132 — 2.05, 9.01 — amendment, the index does not say of what
- 2012-04-26 0001193125-12-183657 — 5.02, 9.01
- 2012-04-26 0001104659-12-028470 — 2.02, 2.05, 9.01
- 2012-03-15 0001193125-12-115954 — 5.02, 9.01
- 2012-01-26 0001104659-12-004014 — 2.02, 9.01
- 2012-01-04 0001193125-12-002212 — 1.01, 2.03, 9.01
- 2011-10-27 0001104659-11-058150 — 2.02, 9.01
- 2011-09-12 0001193125-11-245931 — 5.07
- 2011-07-28 0001193125-11-200929 — 5.02, 9.01
- 2011-07-28 0001193125-11-199704 — 2.02, 9.01
- 2011-04-28 0001193125-11-112669 — 2.02, 9.01
- 2011-03-24 0001193125-11-076483 — 5.02, 9.01
- 2011-01-27 0001032975-11-000003 — 9.01
- 2010-10-28 0001032975-10-000032 — 9.01
- 2010-09-13 0001032975-10-000022 — 5.07
- 2010-07-29 0001032975-10-000010 — 2.02, 9.01
- 2010-06-10 0001193125-10-136877 — 5.02, 9.01
- 2010-05-03 0001193125-10-104337 — 5.02
- 2010-04-29 0001032975-10-000008 — 2.02, 9.01
- 2010-02-19 0001032975-10-000006 — 9.01 — amendment of 0001193125-09-252416
- 2010-01-21 0001032975-10-000002 — 2.02, 9.01
- 2009-12-14 0001193125-09-252416 — 2.01, 9.01
- 2009-11-17 0001032975-09-000023 — 1.01
- 2009-10-22 0001032975-09-000018 — 9.01
- 2009-09-22 0001193125-09-195545 — 5.02, 9.01
- 2009-09-03 0001032975-09-000013 — 8.01
- 2009-07-23 0001140361-09-016802 — 2.02, 9.01
- 2009-06-01 0001193125-09-122550 — 5.02
- 2009-04-23 0001193125-09-085054 — 2.02, 9.01
- 2009-04-02 0001193125-09-071272 — 5.02, 9.01
- 2009-01-20 0001193125-09-008454 — 2.05 — amendment of 0001193125-09-002609
- 2009-01-20 0001193125-09-007902 — 2.02, 9.01
- 2009-01-07 0001193125-09-002609 — 2.05, 9.01
- 2009-01-07 0001193125-09-002370 — 5.02, 9.01
- 2008-12-09 0001193125-08-250543 — 5.02, 9.01
- 2008-10-21 0001193125-08-213212 — 2.02, 9.01
- 2008-07-22 0001193125-08-154721 — 2.02, 9.01
- 2008-06-24 0001193125-08-139163 — 5.03, 9.01
- 2008-05-13 0001193125-08-113263 — 5.02, 9.01
- 2008-04-22 0001193125-08-086176 — 2.02, 9.01

## late-filing notifications on or before 2022-10-27

- 2015-06-02 0001032975-15-000020 — NT 10-K, for the period ended 2015-03-31
- 2014-11-06 0001193125-14-401306 — NT 10-Q, for the period ended 2014-09-30
- 2014-07-24 0001193125-14-277575 — NT 10-Q, for the period ended 2014-06-30
- 2014-05-22 0001193125-14-208712 — NT 10-K, for the period ended 2014-03-31
- 2009-08-06 0001032975-09-000006 — NT 10-Q, for the period ended 2009-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001628280-22-026927:8k_2_02:1]
EX-99.1
2
exhibit991q2fy23.htm
EX-99.1

[0001628280-22-026927:8k_2_02:2]
Document

[0001628280-22-026927:8k_2_02:3]
Exhibit 99.1

[0001628280-22-026927:8k_2_02:4]
Editorial Contacts:

[0001628280-22-026927:8k_2_02:5]
Nate Melihercik, Head of Global Investor Relations - ir@logitech.com

[0001628280-22-026927:8k_2_02:6]
Nicole Kenyon, Head of Global Corporate & Employee Communications - USA  (510) 988-8553

[0001628280-22-026927:8k_2_02:7]
Ben Starkie, Corporate Communications - Europe +41 (0) 79-292-3499

[0001628280-22-026927:8k_2_02:8]
Logitech Announces Q2 FY 2023 Results

[0001628280-22-026927:8k_2_02:9]
Company Reaffirms Fiscal Year 2023 Outlook

[0001628280-22-026927:8k_2_02:10]
LAUSANNE, Switzerland, October 25, 2022 and NEWARK, Calif., October 24, 2022 — SIX Swiss Exchange Ad hoc announcement pursuant to Art. 53 LR —  Logitech International (SIX: LOGN) (Nasdaq: LOGI) today announced financial results for the second quarter of Fiscal Year 2023.

[0001628280-22-026927:8k_2_02:11]
•Sales were $1.15 billion, down 12 percent in US dollars and 7 percent in constant currency, compared to Q2 of the prior year. This performance reflects a challenging macroeconomic environment.

[0001628280-22-026927:8k_2_02:12]
•Category sales in US dollars grew 2 percent in Video Collaboration and declined 2 percent in Pointing Devices compared to Q2 of the prior year. Sales in these categories in constant currency grew 7 percent and 3 percent respectively. Gaming and Keyboard & Combos sales declined 10 percent and 15 percent in US dollars respectively, and 4 percent and 10 percent in constant currency, compared to Q2 of the prior year.

[0001628280-22-026927:8k_2_02:13]
•GAAP operating income declined 29 percent to $127 million, compared to $179 million in the same quarter a year ago. Non-GAAP operating income declined 26 percent to $156 million, compared to $211 million in the same quarter a year ago.

[0001628280-22-026927:8k_2_02:14]
•GAAP earnings per share (EPS) declined 38 percent to $0.50, compared to $0.81 in the same quarter a year ago. Non-GAAP EPS declined 20 percent to $0.84, compared to $1.05 in the same quarter a year ago.

[0001628280-22-026927:8k_2_02:15]
•Cash flow from operations was $73 million, compared to negative $63 million in the same quarter a year ago. In the quarter, the Company returned $276 million of cash to shareholders through its annual dividend payment and share repurchases.

[0001628280-22-026927:8k_2_02:16]
“As we enter the holiday season we continue to drive innovation, announcing more than 20 products which tap into the long-term trends of hybrid work, video everywhere, gaming and digital content creation,” said Bracken Darrell, Logitech president and chief executive officer. “In the face of global macroeconomic headwinds we will continue to pursue operational excellence and deliver industry-leading innovation.”

[0001628280-22-026927:8k_2_02:17]
Chief Financial Officer

[0001628280-22-026927:8k_2_02:18]
Separately, Logitech also announced that Nate Olmstead, chief financial officer, will be leaving the Company. Logitech will be launching a search and Mr. Olmstead currently plans to stay on as CFO through the transition.

[0001628280-22-026927:8k_2_02:19]
“Over the past nearly four years, Nate has been an incredible partner. His leadership helped steer Logitech through an unprecedented pandemic and period of extraordinary growth,” said Bracken Darrell. “Nate has built a world-class finance team and I’m grateful for his contribution."

[0001628280-22-026927:8k_2_02:20]
“I am honored to have been part of the transformational change Logitech has undergone these last four years,” said Nate Olmstead.  “I’m proud of the strong finance team we have in place and excited about what’s ahead for Logitech.”

[0001628280-22-026927:8k_2_02:21]
Outlook

[0001628280-22-026927:8k_2_02:22]
Logitech reaffirmed its Fiscal Year 2023 outlook of between negative 8 percent and negative 4 percent sales growth in constant currency, and between $650 million and $750 million in non-GAAP operating income.

[0001628280-22-026927:8k_2_02:23]
Prepared Remarks Available Online

[0001628280-22-026927:8k_2_02:24]
Logitech has made its prepared written remarks for the financial results videoconference available online on the Logitech corporate website at http://ir.logitech.com.

[0001628280-22-026927:8k_2_02:25]
Financial Results Videoconference and Webcast

[0001628280-22-026927:8k_2_02:26]
Logitech will hold a financial results videoconference to discuss the results for Q2 Fiscal Year 2023 on Tuesday, October 25, 2022 at 8:30 a.m. Eastern Daylight Time and 2:30 p.m. Central European Summer Time. A livestream of the event will be available on the Logitech corporate website at http://ir.logitech.com.

[0001628280-22-026927:8k_2_02:27]
Use of Non-GAAP Financial Information and Constant Currency

[0001628280-22-026927:8k_2_02:28]
To facilitate comparisons to Logitech’s historical results, Logitech has included non-GAAP adjusted measures, which exclude share-based compensation expense, amortization of intangible assets, acquisition-related costs, change in fair value of contingent consideration for business acquisition, restructuring charges, loss on investments, non-GAAP income tax adjustment, and other items detailed under “Supplemental Financial Information” after the tables below. Logitech also presents percentage sales growth in constant currency, a non-GAAP measure, to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales. Logitech believes this information, used together with the GAAP financial information, will help investors to evaluate its current period performance and trends in its business. With respect to the Company’s outlook for non-GAAP operating income, most of these excluded amounts pertain to events that have not yet occurred and are not currently possible to estimate with a reasonable degree of accuracy. Therefore, no reconciliation to the GAAP amounts has been provided for the Fiscal Year 2023 outlook.

[0001628280-22-026927:8k_2_02:29]
Public Dissemination of Certain Information

[0001628280-22-026927:8k_2_02:30]
Logitech webcasts its earnings calls, and certain events Logitech participates in or hosts, with members of the investment community on its investor relations website at https://ir.logitech.com. Additionally, Logitech provides notifications of news or announcements regarding its operations and financial

[0001628280-22-026927:8k_2_02:31]
performance, including its filings with the Securities and Exchange Commission (SEC), investor events, and press and earnings releases as part of its investor relations website. Logitech intends to use its investor relations website as means of disclosing material nonpublic information and for complying with its disclosure obligations under Regulation FD. Logitech’s corporate governance information also is available on its investor relations website.

[0001628280-22-026927:8k_2_02:32]
About Logitech

[0001628280-22-026927:8k_2_02:33]
Logitech helps all people pursue their passions by designing experiences so everyone can create, achieve, and enjoy more. Logitech designs and creates products that bring people together through computing, gaming, video, streaming and creating, and music. Brands of Logitech include Logitech, Logitech G, ASTRO Gaming, Streamlabs, Blue Microphones and Ultimate Ears. Founded in 1981, and headquartered in Lausanne, Switzerland, Logitech International is a Swiss public company listed on the SIX Swiss Exchange (LOGN) and on the Nasdaq Global Select Market (LOGI). Find Logitech at www.logitech.com, the company blog or @Logitech.

[0001628280-22-026927:8k_2_02:34]
# # #

[0001628280-22-026927:8k_2_02:35]
Note that unless noted otherwise, comparisons are year over year.

[0001628280-22-026927:8k_2_02:36]
Logitech and other Logitech marks are trademarks or registered trademarks of Logitech Europe S.A. and/or its affiliates in the U.S. and other countries. All other trademarks are the property of their respective owners. For more information about Logitech and its products, visit the company’s website at www.logitech.com.

[0001628280-22-026927:8k_2_02:37]
(LOGIIR)

[0001628280-22-026927:8k_2_02:38]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
| GAAP CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Net sales |  | $ | 1,148,951 |  |  | $ | 1,306,267 |  |  | $ | 2,308,816 |  |  | $ | 2,618,325 |  |
| Cost of goods sold |  | 707,026 |  |  | 760,268 |  |  | 1,404,246 |  |  | 1,499,334 |  |
| Amortization of intangible assets |  | 3,145 |  |  | 3,836 |  |  | 6,187 |  |  | 7,902 |  |
| Gross profit |  | 438,780 |  |  | 542,163 |  |  | 898,383 |  |  | 1,111,089 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Marketing and selling |  | 202,091 |  |  | 256,627 |  |  | 431,469 |  |  | 508,941 |  |
| Research and development |  | 69,009 |  |  | 68,661 |  |  | 144,526 |  |  | 137,907 |  |
| General and administrative |  | 26,589 |  |  | 33,271 |  |  | 62,449 |  |  | 73,813 |  |
| Amortization of intangible assets and acquisition-related costs |  | 2,873 |  |  | 5,107 |  |  | 6,242 |  |  | 10,324 |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | (925) |  |  | — |  |  | (2,399) |  |
| Restructuring charges, net |  | 10,817 |  |  | 11 |  |  | 10,817 |  |  | 11 |  |
| Total operating expenses |  | 311,379 |  |  | 362,752 |  |  | 655,503 |  |  | 728,597 |  |
| Operating income |  | 127,401 |  |  | 179,411 |  |  | 242,880 |  |  | 382,492 |  |
| Interest income |  | 3,459 |  |  | 201 |  |  | 4,908 |  |  | 517 |  |
| Other income (expense), net |  | (25,397) |  |  | (6,703) |  |  | (19,773) |  |  | 1,732 |  |
| Income before income taxes |  | 105,463 |  |  | 172,909 |  |  | 228,015 |  |  | 384,741 |  |
| Provision for income taxes |  | 23,372 |  |  | 33,453 |  |  | 45,088 |  |  | 58,444 |  |
| Net income |  | $ | 82,091 |  |  | $ | 139,456 |  |  | $ | 182,927 |  |  | $ | 326,297 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.50 |  |  | $ | 0.83 |  |  | $ | 1.12 |  |  | $ | 1.94 |  |
| Diluted |  | $ | 0.50 |  |  | $ | 0.81 |  |  | $ | 1.11 |  |  | $ | 1.90 |  |
| Weighted average shares used to compute net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | 163,186 |  |  | 168,389 |  |  | 163,937 |  |  | 168,380 |  |
| Diluted |  | 164,328 |  |  | 171,343 |  |  | 165,371 |  |  | 171,682 |  |

[0001628280-22-026927:8k_2_02:39]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
|  |  | September 30, |  | March 31, |  |  |  |  |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  | 2022 |  | 2022 |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 868,501 |  |  | $ | 1,328,716 |  |  |  |  |  |
| Accounts receivable, net |  | 772,731 |  |  | 675,604 |  |  |  |  |  |
| Inventories |  | 879,979 |  |  | 933,124 |  |  |  |  |  |
| Other current assets |  | 136,924 |  |  | 135,478 |  |  |  |  |  |
| Total current assets |  | 2,658,135 |  |  | 3,072,922 |  |  |  |  |  |
| Non-current assets: |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  | 113,327 |  |  | 109,807 |  |  |  |  |  |
| Goodwill |  | 449,892 |  |  | 448,175 |  |  |  |  |  |
| Other intangible assets, net |  | 73,495 |  |  | 83,779 |  |  |  |  |  |
| Other assets |  | 350,050 |  |  | 320,722 |  |  |  |  |  |
| Total assets |  | $ | 3,644,899 |  |  | $ | 4,035,405 |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 546,563 |  |  | $ | 636,306 |  |  |  |  |  |
| Accrued and other current liabilities |  | 663,621 |  |  | 784,848 |  |  |  |  |  |
| Total current liabilities |  | 1,210,184 |  |  | 1,421,154 |  |  |  |  |  |
| Non-current liabilities: |  |  |  |  |  |  |  |  |
| Income taxes payable |  | 97,450 |  |  | 83,380 |  |  |  |  |  |
| Other non-current liabilities |  | 168,704 |  |  | 132,133 |  |  |  |  |  |
| Total liabilities |  | 1,476,338 |  |  | 1,636,667 |  |  |  |  |  |
| Shareholders’ equity: |  |  |  |  |  |  |  |  |
| Registered shares, CHF 0.25 par value: |  | 30,148 |  |  | 30,148 |  |  |  |  |  |
| Issued shares — 173,106 at September 30, 2022 and March 31, 2022 |  |  |  |  |  |  |  |  |
| Additional shares that may be issued out of conditional capitals — 50,000 at September 30, 2022 and March 31, 2022 |  |  |  |  |  |  |  |  |
| Additional shares that may be issued out of authorized capital — 17,311 at September 30, 2022 and March 31, 2022 |  |  |  |  |  |  |  |  |
| Additional paid-in capital |  | 106,130 |  |  | 129,925 |  |  |  |  |  |
| Shares in treasury, at cost — 10,943 at September 30, 2022 and 7,855 at March 31, 2022 |  | (824,650) |  |  | (632,893) |  |  |  |  |  |
| Retained earnings |  | 2,995,927 |  |  | 2,975,681 |  |  |  |  |  |
| Accumulated other comprehensive loss |  | (138,994) |  |  | (104,123) |  |  |  |  |  |
| Total shareholders’ equity |  | 2,168,561 |  |  | 2,398,738 |  |  |  |  |  |
| Total liabilities and shareholders’ equity |  | $ | 3,644,899 |  |  | $ | 4,035,405 |  |  |  |  |  |

[0001628280-22-026927:8k_2_02:40]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 82,091 |  |  | $ | 139,456 |  |  | $ | 182,927 |  |  | $ | 326,297 |  |
| Adjustments to reconcile net income to net cash provided by (used in) operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  | 18,662 |  |  | 23,012 |  |  | 37,288 |  |  | 43,474 |  |
| Amortization of intangible assets |  | 6,015 |  |  | 8,625 |  |  | 12,244 |  |  | 17,468 |  |
| Loss on investments |  | 22,934 |  |  | 2,032 |  |  | 11,577 |  |  | 961 |  |
| Share-based compensation expense |  | 12,245 |  |  | 24,022 |  |  | 35,935 |  |  | 47,673 |  |
| Deferred income taxes |  | 2,775 |  |  | 10,966 |  |  | 3,040 |  |  | 6,808 |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | (925) |  |  | — |  |  | (2,399) |  |
| Other |  | 242 |  |  | 14 |  |  | 118 |  |  | 1,059 |  |
| Changes in assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | (77,337) |  |  | (186,316) |  |  | (121,909) |  |  | (113,008) |  |
| Inventories |  | 22,114 |  |  | (52,422) |  |  | 21,790 |  |  | (167,588) |  |
| Other assets |  | (175) |  |  | (17,644) |  |  | 4,757 |  |  | (48,440) |  |
| Accounts payable |  | (8,320) |  |  | (39,862) |  |  | (78,354) |  |  | (155,482) |  |
| Accrued and other liabilities |  | (8,322) |  |  | 26,164 |  |  | (72,157) |  |  | (134,671) |  |
| Net cash provided by (used in) operating activities |  | 72,924 |  |  | (62,878) |  |  | 37,256 |  |  | (177,848) |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  | (25,821) |  |  | (22,718) |  |  | (45,384) |  |  | (47,232) |  |
| Investment in privately held companies |  | (187) |  |  | (400) |  |  | (2,275) |  |  | (901) |  |
| Acquisitions, net of cash acquired |  | — |  |  | — |  |  | (5,839) |  |  | (15,586) |  |
| Purchases of deferred compensation investments |  | (1,577) |  |  | (1,375) |  |  | (2,499) |  |  | (2,466) |  |
| Proceeds from sales of deferred compensation investments |  | 1,493 |  |  | 1,632 |  |  | 2,436 |  |  | 2,977 |  |
| Net cash used in investing activities |  | (26,092) |  |  | (22,861) |  |  | (53,561) |  |  | (63,208) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Payment of cash dividends |  | (158,680) |  |  | (159,410) |  |  | (158,680) |  |  | (159,410) |  |
| Payment of contingent consideration for business acquisition |  | (5,954) |  |  | — |  |  | (5,954) |  |  | — |  |
| Purchases of registered shares |  | (116,942) |  |  | (119,508) |  |  | (237,561) |  |  | (174,380) |  |
| Proceeds from exercises of stock options and purchase rights |  | 12,850 |  |  | 13,886 |  |  | 12,850 |  |  | 16,636 |  |
| Tax withholdings related to net share settlements of restricted stock units |  | (2,598) |  |  | (4,340) |  |  | (26,742) |  |  | (54,751) |  |
| Net cash used in financing activities |  | (271,324) |  |  | (269,372) |  |  | (416,087) |  |  | (371,905) |  |
| Effect of exchange rate changes on cash and cash equivalents |  | (13,664) |  |  | (5,314) |  |  | (27,823) |  |  | (70) |  |
| Net decrease in cash and cash equivalents |  | (238,156) |  |  | (360,425) |  |  | (460,215) |  |  | (613,031) |  |
| Cash and cash equivalents, beginning of the period |  | 1,106,657 |  |  | 1,497,721 |  |  | 1,328,716 |  |  | 1,750,327 |  |
| Cash and cash equivalents, end of the period |  | $ | 868,501 |  |  | $ | 1,137,296 |  |  | $ | 868,501 |  |  | $ | 1,137,296 |  |

[0001628280-22-026927:8k_2_02:41]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
| NET SALES |  | 2022 |  | 2021 |  | Change |  | 2022 |  | 2021 |  | Change |
| Net sales by product category: |  |  |  |  |  |  |  |  |  |  |  |  |
| Pointing Devices |  | $ | 185,200 |  |  | $ | 189,014 |  |  | (2) | % |  | $ | 368,483 |  |  | $ | 371,892 |  |  | (1) | % |
| Keyboards & Combos |  | 200,853 |  |  | 236,272 |  |  | (15) |  |  | 428,573 |  |  | 454,629 |  |  | (6) |  |
| PC Webcams |  | 60,166 |  |  | 94,471 |  |  | (36) |  |  | 119,552 |  |  | 204,389 |  |  | (42) |  |
| Tablet & Other Accessories |  | 54,203 |  |  | 80,801 |  |  | (33) |  |  | 120,788 |  |  | 160,073 |  |  | (25) |  |
| Gaming (1) |  | 297,676 |  |  | 330,777 |  |  | (10) |  |  | 580,482 |  |  | 666,174 |  |  | (13) |  |
| Video Collaboration |  | 236,180 |  |  | 231,653 |  |  | 2 |  |  | 482,422 |  |  | 466,538 |  |  | 3 |  |
| Mobile Speakers |  | 39,195 |  |  | 39,492 |  |  | (1) |  |  | 61,505 |  |  | 67,976 |  |  | (10) |  |
| Audio & Wearables |  | 73,271 |  |  | 98,078 |  |  | (25) |  |  | 142,717 |  |  | 214,685 |  |  | (34) |  |
| Other (2) |  | 2,207 |  |  | 5,709 |  |  | (61) |  |  | 4,294 |  |  | 11,969 |  |  | (64) |  |
| Total Sales |  | $ | 1,148,951 |  |  | $ | 1,306,267 |  |  | (12) | % |  | $ | 2,308,816 |  |  | $ | 2,618,325 |  |  | (12) | % |

[0001628280-22-026927:8k_2_02:42]
(1) Gaming includes streaming services revenue generated by Streamlabs.

[0001628280-22-026927:8k_2_02:43]
(2) Other includes Smart Home.

[0001628280-22-026927:8k_2_02:44]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
| GAAP TO NON-GAAP RECONCILIATION (A) |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Gross profit - GAAP |  | $ | 438,780 |  |  | $ | 542,163 |  |  | $ | 898,383 |  |  | $ | 1,111,089 |  |
| Share-based compensation expense |  | 1,443 |  |  | 2,102 |  |  | 2,904 |  |  | 3,471 |  |
| Amortization of intangible assets |  | 3,145 |  |  | 3,836 |  |  | 6,187 |  |  | 7,902 |  |
| Gross profit - Non-GAAP |  | $ | 443,368 |  |  | $ | 548,101 |  |  | $ | 907,474 |  |  | $ | 1,122,462 |  |
| Gross margin - GAAP |  | 38.2 | % |  | 41.5 | % |  | 38.9 | % |  | 42.4 | % |
| Gross margin - Non-GAAP |  | 38.6 | % |  | 42.0 | % |  | 39.3 | % |  | 42.9 | % |
| Operating expenses - GAAP |  | $ | 311,379 |  |  | $ | 362,752 |  |  | $ | 655,503 |  |  | $ | 728,597 |  |
| Less: Share-based compensation expense |  | 10,802 |  |  | 21,920 |  |  | 33,031 |  |  | 44,202 |  |
| Less: Amortization of intangible assets and acquisition-related costs |  | 2,873 |  |  | 5,107 |  |  | 6,242 |  |  | 10,324 |  |
| Less: Change in fair value of contingent consideration for business acquisition |  | — |  |  | (925) |  |  | — |  |  | (2,399) |  |
| Less: Restructuring charges, net |  | 10,817 |  |  | 11 |  |  | 10,817 |  |  | 11 |  |
| Operating expenses - Non-GAAP |  | $ | 286,887 |  |  | $ | 336,639 |  |  | $ | 605,413 |  |  | $ | 676,459 |  |
| % of net sales - GAAP |  | 27.1 | % |  | 27.8 | % |  | 28.4 | % |  | 27.8 | % |
| % of net sales - Non-GAAP |  | 25.0 | % |  | 25.8 | % |  | 26.2 | % |  | 25.8 | % |
| Operating income - GAAP |  | $ | 127,401 |  |  | $ | 179,411 |  |  | $ | 242,880 |  |  | $ | 382,492 |  |
| Share-based compensation expense |  | 12,245 |  |  | 24,022 |  |  | 35,935 |  |  | 47,673 |  |
| Amortization of intangible assets and acquisition-related costs |  | 6,018 |  |  | 8,943 |  |  | 12,429 |  |  | 18,226 |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | (925) |  |  | — |  |  | (2,399) |  |
| Restructuring charges, net |  | 10,817 |  |  | 11 |  |  | 10,817 |  |  | 11 |  |
| Operating income - Non-GAAP |  | $ | 156,481 |  |  | $ | 211,462 |  |  | $ | 302,061 |  |  | $ | 446,003 |  |
| % of net sales - GAAP |  | 11.1 | % |  | 13.7 | % |  | 10.5 | % |  | 14.6 | % |
| % of net sales - Non-GAAP |  | 13.6 | % |  | 16.2 | % |  | 13.1 | % |  | 17.0 | % |
| Net income - GAAP |  | $ | 82,091 |  |  | $ | 139,456 |  |  | $ | 182,927 |  |  | $ | 326,297 |  |
| Share-based compensation expense |  | 12,245 |  |  | 24,022 |  |  | 35,935 |  |  | 47,673 |  |
| Amortization of intangible assets and acquisition-related costs |  | 6,018 |  |  | 8,943 |  |  | 12,429 |  |  | 18,226 |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | (925) |  |  | — |  |  | (2,399) |  |
| Restructuring charges, net |  | 10,817 |  |  | 11 |  |  | 10,817 |  |  | 11 |  |
| Loss on investments |  | 22,934 |  |  | 2,032 |  |  | 11,577 |  |  | 961 |  |
| Non-GAAP income tax adjustment |  | 3,607 |  |  | 6,825 |  |  | 7,066 |  |  | (591) |  |
| Net income - Non-GAAP |  | $ | 137,712 |  |  | $ | 180,364 |  |  | $ | 260,751 |  |  | $ | 390,178 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  | $ | 0.50 |  |  | $ | 0.81 |  |  | $ | 1.11 |  |  | $ | 1.90 |  |
| Diluted - Non-GAAP |  | $ | 0.84 |  |  | $ | 1.05 |  |  | $ | 1.58 |  |  | $ | 2.27 |  |
| Shares used to compute net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP and Non-GAAP |  | 164,328 |  |  | 171,343 |  |  | 165,371 |  |  | 171,682 |  |

[0001628280-22-026927:8k_2_02:45]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
| SHARE-BASED COMPENSATION EXPENSE |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Share-based Compensation Expense |  |  |  |  |  |  |  |  |
| Cost of goods sold |  | $ | 1,443 |  |  | $ | 2,102 |  |  | $ | 2,904 |  |  | $ | 3,471 |  |
| Marketing and selling |  | 7,429 |  |  | 9,758 |  |  | 17,226 |  |  | 18,288 |  |
| Research and development |  | 3,280 |  |  | 4,724 |  |  | 8,812 |  |  | 9,785 |  |
| General and administrative |  | 93 |  |  | 7,438 |  |  | 6,993 |  |  | 16,129 |  |
| Total share-based compensation expense |  | 12,245 |  |  | 24,022 |  |  | 35,935 |  |  | 47,673 |  |
| Income tax expense (benefit) |  | 102 |  |  | (3,285) |  |  | (4,220) |  |  | (19,879) |  |
| Total share-based compensation expense, net of income tax expense (benefit) |  | $ | 12,347 |  |  | $ | 20,737 |  |  | $ | 31,715 |  |  | $ | 27,794 |  |

[0001628280-22-026927:8k_2_02:46]
*Note: These preliminary results for the three and six months ended September 30, 2022 are subject to adjustments, including subsequent events that may occur through the date of filing our Quarterly Report on Form 10-Q.

[0001628280-22-026927:8k_2_02:47]
(A) Non-GAAP Financial Measures

[0001628280-22-026927:8k_2_02:48]
To supplement our condensed consolidated financial results prepared in accordance with GAAP, we use a number of financial measures, both GAAP and non-GAAP, in analyzing and assessing our overall business performance, for making operating decisions and for forecasting and planning future periods. We consider the use of non-GAAP financial measures helpful in assessing our current financial performance, ongoing operations and prospects for the future as well as understanding financial and business trends relating to our financial condition and results of operations.

[0001628280-22-026927:8k_2_02:49]
While we use non-GAAP financial measures as a tool to enhance our understanding of certain aspects of our financial performance and to provide incremental insight into the underlying factors and trends affecting both our performance and our cash-generating potential, we do not consider these measures to be a substitute for, or superior to, the information provided by GAAP financial measures. Consistent with this approach, we believe that disclosing non-GAAP financial measures to the readers of our financial statements provides useful supplemental data that, while not a substitute for GAAP financial measures, can offer insight in the review of our financial and operational performance and enables investors to more fully understand trends in our current and future performance. In assessing our business during the quarter ended September 30, 2022 and prior periods presented, we excluded items in the following general categories, each of which are described below:

[0001628280-22-026927:8k_2_02:50]
Share-based compensation expense. We believe that providing non-GAAP measures excluding share-based compensation expense, in addition to the GAAP measures, allows for a more transparent comparison of our financial results from period to period. We prepare and maintain our budgets and forecasts for future periods on a basis consistent with this non-GAAP financial measure. Further, companies use a variety of types of equity awards as well as a variety of methodologies, assumptions and estimates to determine share-based compensation expense. We believe that excluding share-based compensation expense enhances our ability and the ability of investors to understand the impact of non-cash share-based compensation on our operating results and to compare our results against the results of other companies.

[0001628280-22-026927:8k_2_02:51]
Amortization of intangible assets. We incur intangible asset amortization expense, primarily in connection with our acquisitions of various businesses and technologies. The amortization of purchased intangibles varies depending on the level of acquisition activity. We exclude these various charges in budgeting, planning and forecasting future periods and we believe that providing the non-GAAP measures excluding these various non-cash charges, as well as the GAAP measures, provides additional insight when comparing our gross profit, operating expenses, and financial results from period to period.

[0001628280-22-026927:8k_2_02:52]
Acquisition-related costs and change in fair value of contingent consideration for business acquisition.  We incurred expenses and credits in connection with our acquisitions which we generally would not have otherwise incurred in the periods presented as a part of our continuing operations. Acquisition related costs include all incremental expenses incurred to effect a business combination. Fair value of contingent consideration is associated with our estimates of the value of earn-outs in connection with certain acquisitions. We believe that providing the non-GAAP measures excluding these costs and credits, as well as the GAAP measures, assists our investors because such costs are not reflective of our ongoing operating results.

[0001628280-22-026927:8k_2_02:53]
Restructuring charges, net. These expenses are associated with restructuring plans, and will vary based on the initiatives in place during any given period. Restructuring charges may include costs related to employee terminations, facility closures and early cancellation of certain contracts as well as other costs resulting from our restructuring initiatives. We believe that providing the non-GAAP measures excluding these items, as well as the GAAP measures, assists our investors because such charges are not reflective of our ongoing operating results.

[0001628280-22-026927:8k_2_02:54]
Loss (gain) on investments. We recognize losses (gains) related to our investments in various companies, which vary depending on the operational and financial performance of the companies in which we invest. These amounts include our losses (earnings) on equity method investments, investment impairments and losses (gains) resulting from sales or other events related to our investments. We believe that providing the non-GAAP measures excluding these items, as well as the GAAP measures, assists our investors because such losses (gains) are not reflective of our ongoing operations.

[0001628280-22-026927:8k_2_02:55]
Non-GAAP income tax adjustment.  Non-GAAP income tax adjustment primarily measures the income tax effect of non-GAAP adjustments excluded above and other events; the determination of which is based upon the nature of the underlying items, the mix of income and losses in jurisdictions and the relevant tax rates in which we operate.

[0001628280-22-026927:8k_2_02:56]
Each of the non-GAAP financial measures described above, and used in this press release, should not be considered in isolation from, or as a substitute for, a measure of financial performance prepared in accordance with GAAP. Further, investors are cautioned that there are inherent limitations associated with the use of each of these non-GAAP financial measures as an analytical tool. In particular, these non-GAAP financial measures are not based on a comprehensive set of accounting rules or principles and many of the adjustments to the GAAP financial measures reflect the exclusion of items that are recurring and may be reflected in the Company’s financial results for the foreseeable future. We compensate for these limitations by providing specific information in the reconciliation included in this press release regarding the GAAP amounts excluded from the non-GAAP financial measures. In addition, as noted above, we evaluate the non-GAAP financial measures together with the most directly comparable GAAP financial information.

[0001628280-22-026927:8k_2_02:57]
Additional Supplemental Financial Information - Constant Currency

[0001628280-22-026927:8k_2_02:58]
In addition, Logitech presents percentage sales growth in constant currency to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales.

## item 5.02 — body, verbatim

[0001628280-22-026927:8k_body:1]
ITEM 5.02. DEPARTURE OF DIRECTORS OR CERTAIN OFFICERS; ELECTION OF DIRECTORS; APPOINTMENT OF CERTAIN OFFICERS; COMPENSATORY ARRANGEMENTS OF CERTAIN OFFICERS

[0001628280-22-026927:8k_body:2]
On October 23, 2022, Logitech and Nate Olmstead, Logitech’s Chief Financial Officer, agreed that Mr. Olmstead would leave Logitech.  Logitech intends to commence a search process for a new CFO, and Mr. Olmstead currently intends to remain with Logitech through the hiring of a new CFO and a subsequent transition period.  Mr. Olmstead’s departure is not due to any disagreement with Logitech’s operations, policies or practices.
