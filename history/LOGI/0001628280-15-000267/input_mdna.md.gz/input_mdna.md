# LOGI MD&A — 0001628280-15-000267


## mdna

[0001628280-15-000267:mdna:1]
[same as prior period, unchanged from 0001104659-14-083669:mdna:1]

[0001628280-15-000267:mdna:2]
[same as prior period, unchanged from 0001104659-14-083669:mdna:2]

[0001628280-15-000267:mdna:3]
[same as prior period, unchanged from 0001104659-14-083669:mdna:3]

[0001628280-15-000267:mdna:4]
[same as prior period, unchanged from 0001104659-14-083669:mdna:4]

[0001628280-15-000267:mdna:5]
[same as prior period, unchanged from 0001104659-14-083669:mdna:5]

[0001628280-15-000267:mdna:6]
[same as prior period, unchanged from 0001104659-14-083669:mdna:6]

[0001628280-15-000267:mdna:7]
[same as prior period, unchanged from 0001104659-14-083669:mdna:8]

[0001628280-15-000267:mdna:8]
[same as prior period, unchanged from 0001104659-14-083669:mdna:9]

[0001628280-15-000267:mdna:9]
We sell our peripherals products to a network of retailers (direct sales to retailers, as well as indirect sales through distributors) and OEMs. Our worldwide retail network includes wholesale distributors, consumer electronics retailers, mass merchandisers, specialty electronics, computers and telecommunications stores, value-added resellers and online merchants. Sales of our retail peripherals were 89% and 88% of our net sales for the nine months ended December 31, 2014 and 2013. The large majority of our revenues have historically been derived from sales of our peripherals products for use by consumers. Our OEM customers include several of the world’s largest PC manufacturers. Sales to OEM customers were 6% and 7% of our net sales for the nine months ended December 31, 2014 and 2013.

[0001628280-15-000267:mdna:10]
Our video conferencing segment encompasses the design, manufacturing and marketing of Lifesize branded video conferencing products, infrastructure and services for the enterprise, public sector and other small to medium business markets. Video conferencing products include scalable high-definition, or HD, video communication endpoints, HD video conferencing systems with integrated monitors, video bridges, a cloud based video conferencing solution and other infrastructure software and hardware to support large-scale video deployments and services to support these products. The video conferencing segment maintains a separate marketing and sales organization, which sells Lifesize products and services worldwide. Video conferencing product development and product management organizations are separate, but coordinated with our peripherals business, particularly our Consumer Computing Platform group. We sell our video conferencing products and services to distributors, value-added resellers, OEMs and, occasionally, direct enterprise customers. Sales of Lifesize products were 5% and 5% of our net sales in the nine months ended December 31, 2014 and 2013.

[0001628280-15-000267:mdna:11]
[same as prior period, unchanged from 0001104659-14-083669:mdna:12]

[0001628280-15-000267:mdna:12]
[same as prior period, unchanged from 0001104659-14-083669:mdna:13]

[0001628280-15-000267:mdna:13]
[same as prior period, unchanged from 0001104659-14-083669:mdna:14]

[0001628280-15-000267:mdna:14]
[same as prior period, unchanged from 0001104659-14-083669:mdna:15]

[0001628280-15-000267:mdna:15]
From time to time, we may seek to partner with, or acquire when appropriate, companies that have products, personnel, and technologies that complement our strategic direction. We continually review our product offerings and our strategic direction in light of our profitability targets, competitive conditions, changing consumer trends and the evolving nature of the interface between the consumer and the digital world.

[0001628280-15-000267:mdna:16]
[same as prior period, unchanged from 0001104659-14-083669:mdna:18]

[0001628280-15-000267:mdna:17]
[same as prior period, unchanged from 0001104659-14-083669:mdna:19]

[0001628280-15-000267:mdna:18]
[same as prior period, unchanged from 0001104659-14-083669:mdna:20]

[0001628280-15-000267:mdna:19]
[same as prior period, unchanged from 0001104659-14-083669:mdna:21]

[0001628280-15-000267:mdna:20]
[same as prior period, unchanged from 0001104659-14-083669:mdna:22]

[0001628280-15-000267:mdna:21]
We conduct a goodwill impairment analysis annually at December 31 or more frequently if indicators of impairment exist or if a decision is made to sell or exit a business. A significant amount of judgment is involved in determining if an indicator of impairment has occurred. Such indicators may include deterioration in general economic conditions, negative developments in equity and credit markets, adverse changes in the markets in which an entity operates, increases in input costs that have a negative effect on earnings and cash flows, or a trend of negative or declining cash flows over multiple periods, among others. The fair value that could be realized in an actual transaction may differ from that used to evaluate the impairment of goodwill.

[0001628280-15-000267:mdna:22]
We performed our annual goodwill impairment assessments at December 31, 2014 and concluded there was no impairment of goodwill as of December 31, 2014. Refer to the Note 9 to the consolidated financial statements included in this report of our Form 10-Q for the disclosures.

[0001628280-15-000267:mdna:23]
[same as prior period, unchanged from 0001104659-14-083669:mdna:23]

[0001628280-15-000267:mdna:24]
As disclosed in our Annual Report on Form 10-K for the year ended March 31, 2014 and in the audited consolidated financial statements contained therein, the Company has restated and revised its financial statements for the fiscal years ended March 31, 2012 and 2013, respectively. The impact of the adjustments also immaterially impact the financial statements for the first three quarters of the fiscal year ended March 31, 2014 as previously included in the Company’s quarterly reports on Form 10-Q for Fiscal 2014. The financial statements for three and nine months ended December 31, 2013 included in this Form 10-Q are revised and should be read in conjunction with Item 8, “Financial Statements and Supplementary Data”

[0001628280-15-000267:mdna:25]
disclosed in the Company’s Annual Report on Form 10-K for the fiscal year ended March 31, 2014, filed with the SEC on November 13, 2014.

[0001628280-15-000267:mdna:26]
The adjustments included in these financial statements for the three and nine months ended December 31, 2013 primarily related to a correction to revenue that was previously recorded as an out-of-period adjustment and is now being reported in the correct period, capitalization of property, plant and equipment which was previously incorrectly expensed, other misstatements, and the tax impact of these adjustments.

[0001628280-15-000267:mdna:27]
[same as prior period, unchanged from 0001104659-14-083669:mdna:26]

[0001628280-15-000267:mdna:28]
Our total net sales for the three and nine months ended December 31, 2014 both increased by 1% compared with the three months and nine months ended December 31, 2013, due to an increase in retail sales, offset by declines in OEM and video conferencing sales.

[0001628280-15-000267:mdna:29]
Retail sales and units sold during the three months ended December 31, 2014 increased 2% and 4% compared with the three months ended December 31, 2013. We experienced an increase in sales of 10% in the Americas region, an increase in sales of 3% in the Asia Pacific region, and a decrease in sales of 7% in the EMEA region.

[0001628280-15-000267:mdna:30]
Retail sales and units sold during the nine months ended December 31, 2014 increased 2% and 3% compared with the nine months ended December 31, 2013. We experienced an increase in sales of 10% in the Americas region, a decrease of 5% in the EMEA region and the sales in the Asia Pacific region remained flat.

[0001628280-15-000267:mdna:31]
OEM net sales decreased 12% and units sold decreased 19% in the three months ended December 31, 2014 compared with the preceding fiscal year. OEM net sales decreased 14% and units sold decreased 22% in the nine months ended December 31, 2014 compared with the preceding fiscal year. The decline was primarily due to weak mice sales that were only partially offset by growth in Keyboards & Desktops. The decline in mice sales was expected, as we elected not to participate in lower margin opportunities with several customers.

[0001628280-15-000267:mdna:32]
Sales of video conferencing products, which were 5% of total net sales in the three and nine months ended December 31, 2014 and 2013, remained flat in the three months ended December 31, 2014 and decreased by 6% in the nine months ended December 31, 2014, compared with the same periods of preceding fiscal year. Lifesize is in the early stages of transitioning its product portfolio to the recently announced Lifesize Cloud, a software-as-a-service (SaaS) offering that is off to a promising start, that we believe provides an affordable, simple and scalable video conferencing solution with little to no need for IT involvement. Sales of Lifesize Cloud are growing rapidly, offsetting a shift from it's on-premise infrastructure products.  Video systems sales are growing and are expected to continue growing as an integral part of the full Lifesize solution.

[0001628280-15-000267:mdna:33]
Our gross margin for the three months ended December 31, 2014 improved to 36.5% compared with 34.1% for the three months ended December 31, 2013. Our gross margin for the nine months ended December 31, 2014 improved to 37.5% compared with 34.6% for the nine months ended December 31, 2013. The improvement in gross margin primarily reflects the combination of a significant improvement in both our Profit Maximization categories and Mobile Speakers products, driven largely by product cost reductions and economies of scale, as well as the benefit from exiting the products included in the Other/Non-Strategic Category.

[0001628280-15-000267:mdna:34]
Operating expenses for the three months ended December 31, 2014 were 26.3% of net sales, compared with 25.7% in the same period of the prior fiscal year. The increase was primarily in Sales & Marketing which reflects selective investments to drive sales growth in categories such as Mobile Speakers products and Lifesize Cloud, and $2.5 million in expenses related to the Audit Committee’s investigation.

[0001628280-15-000267:mdna:35]
Operating expenses for the nine months ended December 31, 2014 were 29.7% of net sales, compared with 30.3% in the same period of the prior fiscal year. The decrease in total operating expenses as a percentage of net sales for the nine months ended December 31, 2014 compared to prior period were primarily due to savings from prior year’s restructuring actions and the ongoing rationalization of infrastructure. These savings were offset by $19.5 million expenses related to the Audit Committee’s investigation.

[0001628280-15-000267:mdna:36]
Net income for the three and nine months ended December 31, 2014 were $62.8 million and $118.6 million, respectively, compared with net income of $47.9 million and $63.7 million in the three and nine months ended December 31, 2013.

[0001628280-15-000267:mdna:37]
[same as prior period, unchanged from 0001104659-14-083669:mdna:36]

[0001628280-15-000267:mdna:38]
[same as prior period, unchanged from 0001104659-14-083669:mdna:37]

[0001628280-15-000267:mdna:39]
[same as prior period, unchanged from 0001104659-14-083669:mdna:38]

[0001628280-15-000267:mdna:40]
[same as prior period, unchanged from 0001104659-14-083669:mdna:39]

[0001628280-15-000267:mdna:41]
PC Peripherals: Although the installed base of PC users is large, consumer demand for new PCs has declined in recent years, and we believe it will continue to decline in future years. As a consequence, consumer demand for PC peripherals is slowing, or in some cases declining, although the quality of PC-embedded webcams improves along with the increasing popularity of tablets and other accessories and audio-PC wearables.

[0001628280-15-000267:mdna:42]
[same as prior period, unchanged from 0001104659-14-083669:mdna:41]

[0001628280-15-000267:mdna:43]
Tablets and Other Accessories. Smaller mobile computing devices, such as tablets with touch interfaces, have created new markets and usage models for peripherals and accessories. We offer a number of products to enhance the use of mobile devices, including keyboard folios for the iPad and iPad mini, and keyboard covers and folios for the iPad Air. We have also introduced keyboard folios for the Samsung Galaxy tablet as well as the Wired Keyboard for the iPad, designed primarily for use in the classroom. While we achieved growth in sales of our tablet covers for the iPad, we have seen the market decline for iPads.

[0001628280-15-000267:mdna:44]
Mobile Speakers. We believe that digital music, the seamless consumption of digital audio content on mobile devices, presents a growth opportunity for us. Many consumers listen to music as a popular entertainment activity, fueled by the growth in smartphones, tablets, music services and Internet radio. We believe we have a solid foundation of mobile speaker solutions to satisfy consumers’ needs for music consumption, in the digital music speaker space. We continue to invest in the UE brand and introduce innovative products in this category such as UE BOOM, a wireless speaker that offers 360-degree stereo sound.

[0001628280-15-000267:mdna:45]
OEM Business. Sales of our OEM mice and keyboards have historically made up the bulk of our OEM sales. In recent years, there has been a dramatic shift away from desktop PCs and there continues to be weakness in the global market for PCs, which has adversely affected our sales of OEM mice and keyboards, all of which are sold with name-brand desktop PCs. We expect this trend to continue and for OEM sales to comprise a smaller percentage of our total sales in the future.

[0001628280-15-000267:mdna:46]
Trends in Non-Strategic Peripherals Product Categories. We continue to evaluate our product offerings and exit those which no longer support our strategic direction.

[0001628280-15-000267:mdna:47]
[same as prior period, unchanged from 0001104659-14-083669:mdna:47]

[0001628280-15-000267:mdna:48]
The trend among businesses and institutions to use video conferencing offers a long-term growth opportunity for us. However, the overall video conferencing industry has experienced a slowdown in recent quarters. In addition, there has been an increase in the competitive environment. We believe the growth in our video conferencing segment depends in part on our ability to increase sales to enterprises with existing installed bases of equipment supplied by our competitors and to enterprises that may purchase such competitor equipment in the future. We believe the ability of our Lifesize products to integrate with the equipment of other telecommunications, video conferencing or telepresence equipment suppliers to be a key factor in purchasing decisions by current or prospective Lifesize customers. In addition, Lifesize has broadened its product portfolio to include infrastructure, cloud services and other offerings which require different approaches to developing customer solutions. We are also seeking to offer Lifesize products designed to enhance the use of mobile devices in video conferencing applications.

[0001628280-15-000267:mdna:49]
Non-GAAP Measures

[0001628280-15-000267:mdna:50]
We refer to our net sales excluding the impact of foreign currency exchange rates as constant dollar sales. Constant dollar sales is a non-GAAP financial measure, which is information derived from consolidated financial information but not presented in our financial statements prepared in accordance with U.S. GAAP. Our management uses these non-GAAP measures in its financial and operational decision-making, and believes these non-GAAP measures, when considered in conjunction with the corresponding GAAP measures, facilitate a better understanding of changes in net sales. Percentage of constant dollar sales growth is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales.

[0001628280-15-000267:mdna:51]
[same as prior period, unchanged from 0001104659-14-083669:mdna:49]

[0001628280-15-000267:mdna:52]
[same as prior period, unchanged from 0001104659-14-083669:mdna:50]

[0001628280-15-000267:mdna:53]
Net sales by channel for the three and nine months ended December 31, 2014 and 2013 were as follows (in thousands):

[0001628280-15-000267:mdna:54]
|  |  | Three Months Ended December 31, |  | Nine Months Ended December 31, |
|  |  | 2014 |  | 2013 |  | Change |  | 2014 |  | 2013 |  | Change |
| Retail |  | $ | 574,025 |  |  | $ | 564,221 |  |  | 2 | % |  | $ | 1,471,301 |  |  | $ | 1,442,085 |  |  | 2 | % |
| OEM |  | 30,297 |  |  | 34,542 |  |  | (12 | ) |  | 91,323 |  |  | 106,581 |  |  | (14 | ) |
| Video conferencing |  | 29,882 |  |  | 29,956 |  |  | — |  |  | 84,094 |  |  | 89,726 |  |  | (6 | ) |
| Total net sales |  | $ | 634,204 |  |  | $ | 628,719 |  |  | 1 |  |  | $ | 1,646,718 |  |  | $ | 1,638,392 |  |  | 1 |  |

[0001628280-15-000267:mdna:55]
[same as prior period, unchanged from 0001104659-14-083669:mdna:53]

[0001628280-15-000267:mdna:56]
Our net retail sales in both the three and nine months ended December 31, 2014 increased by 2% compared with the same periods of the prior fiscal year. Sales increases in the Americas and Asia pacific regions were offset in part by a decrease in the EMEA region during the three months ended December 31, 2014. If foreign currency exchange rates had been constant in the three and nine months ended December 31, 2014 and 2013, our constant dollar retail sales would have increased by 5% and 3%, respectively. Our retail average selling price decreased by 2% and 1% during the three and nine months ended December 31, 2014. Products priced below $40 represented approximately 45% and 48% of retail sales in the three and nine months ended December 31, 2014, compared with 44% and 48% of total retail sales in the three and nine months ended December 31, 2013. Sales of products priced above $100 represented 19% and 17% of retail sales in the three and nine months ended December 31, 2014, compared with 16% and 15% of total retail sales for the three and nine months ended December 31, 2013.

[0001628280-15-000267:mdna:57]
[same as prior period, unchanged from 0001104659-14-083669:mdna:55]

[0001628280-15-000267:mdna:58]
OEM net sales decreased 12% and 14% and units sold decreased 19% and 22%  in the three and nine months ended December 31, 2014 compared with the same periods of preceding fiscal year. The decline was primarily due to overall weaker market conditions and competitive pressures for pointing devices that were only partially offset by growth in PC Keyboards & Desktops. If foreign currency exchange rates had been constant in the three and nine months ended December 31, 2014 and 2013, our constant dollar OEM net sales would have decreased by 12% and 14%, respectively.

[0001628280-15-000267:mdna:59]
[same as prior period, unchanged from 0001104659-14-083669:mdna:57]

[0001628280-15-000267:mdna:60]
Video conferencing net sales remained flat and decreased 6% during the three and nine months ended December 31, 2014, respectively, compared with the same period of the prior fiscal year. If foreign currency exchange rates had been constant in the three and nine months ended December 31, 2014 and 2013, our constant dollar video conferencing net sales would have remained flat and decreased by 6%, respectively. Lifesize is in the process of transitioning its product portfolio to the recently announced Lifesize Cloud, a software-as-a-service (SaaS) offering that provides an affordable, simple and scalable video conferencing solution with little to no need for IT involvement. Sales of Lifesize Cloud are growing rapidly, offsetting a shift from it's on-premise infrastructure products.  Video systems sales are growing and are expected to continue growing as an integral part of the full Lifesize solution.

[0001628280-15-000267:mdna:61]
[same as prior period, unchanged from 0001104659-14-083669:mdna:59]

[0001628280-15-000267:mdna:62]
The following table presents the change in retail sales by for the three and nine months ended December 31, 2014 compared with the three and nine months ended December 31, 2013:

[0001628280-15-000267:mdna:63]
|  |  | Three Months EndedDecember 31, 2014Change in Sales |  | Nine Months EndedDecember 31, 2014Change in Sales |
| Americas |  | 10 | % |  | 10 | % |
| EMEA |  | (7 | ) |  | (5 | ) |
| Asia Pacific |  | 3 |  |  | — |  |

[0001628280-15-000267:mdna:64]
Americas:

[0001628280-15-000267:mdna:65]
The Americas region increased by 10% in retail sales during both the three and nine months ended December 31, 2014, compared with the same periods of the prior fiscal year.  If foreign currency exchange rates had been constant in the three and nine months ended December 31, 2014 and 2013, our constant dollar retail sales would have increased by 11%  and 10% in the Americas. We have achieved sales increases in all strategic categories except Audio-PC & Wearables, Remotes, and Tablets & Other Accessories. This increase was led by triple digit growth in Mobile Speakers.

[0001628280-15-000267:mdna:66]
EMEA:

[0001628280-15-000267:mdna:67]
Retail sales in the EMEA region decreased by 7% and 5% during the three and nine months ended December 31, 2014, compared with the same period of the prior fiscal year.  If foreign currency exchange rates had been constant in the three and nine months ended December 31, 2014 and 2013, our constant dollar retail sales would have decreased by 2% and 4% in the EMEA region. The decline in sales reflects weak market conditions in Russia and Ukraine. Sales of Mobile Speakers for the first nine months ended December 31, 2014 had a double digit growth and we achieved growth in Video driven by UC ConferenceCams and growth in PC Keyboards & Desktops and PC Gaming. Sales of our Remotes product categories also increased during the three and nine months ended December 31, 2014 compared with the same periods of prior fiscal year.

[0001628280-15-000267:mdna:68]
Asia Pacific:

[0001628280-15-000267:mdna:69]
Asia Pacific region retail sales increased by 3% and remained flat during the three and nine months ended December 31, 2014, respectively, compared with the same periods of the prior fiscal year. If foreign currency exchange rates had been constant in the three and nine months ended December 31, 2014 and 2013, our constant dollar retail sales in the Asia Pacific region would have increased by 7% and 2%, respectively. We had double digit growth in Video category primarily due to enterprise webcam and video collaboration products during the three and nine months ended December 31, 2014. We had double digit growth and triple digit growth in our Mobile Speakers category during the three and nine months ended December 31, 2014, respectively. These increases were offset in part by weakness in our Tablet, Other accessories, Audio-PC Wearables, PC Gaming and decline in sales from exiting our non-strategic categories.

[0001628280-15-000267:mdna:70]
Net Sales by Product Category

[0001628280-15-000267:mdna:71]
Net sales by product category during the three and nine months ended December 31, 2014 and 2013 were as follows (in thousands):

[0001628280-15-000267:mdna:72]
|  |  | Three Months Ended December 31, |  | Nine Months Ended December 31, |
|  |  | 2014 |  | 2013 (1) |  | Change |  | 2014 |  | 2013 (1) |  | Change |
| Peripherals: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PC Gaming |  | $ | 70,188 |  |  | $ | 58,173 |  |  | 21 | % |  | $ | 164,570 |  |  | $ | 141,645 |  |  | 16 | % |
| Tablet & Other Accessories |  | 55,100 |  |  | 77,009 |  |  | (28 | ) |  | 114,973 |  |  | 150,263 |  |  | (23 | ) |
| Mobile Speakers |  | 62,264 |  |  | 34,198 |  |  | 82 |  |  | 139,631 |  |  | 68,032 |  |  | 105 |  |
| Growth |  | 187,552 |  |  | 169,380 |  |  | 11 |  |  | 419,174 |  |  | 359,940 |  |  | 16 |  |
| Pointing Devices |  | 141,789 |  |  | 141,757 |  |  | — |  |  | 382,524 |  |  | 387,064 |  |  | (1 | ) |
| PC Keyboards & Desktops |  | 114,058 |  |  | 108,682 |  |  | 5 |  |  | 325,299 |  |  | 311,955 |  |  | 4 |  |
| Audio-PC &Wearables |  | 58,696 |  |  | 69,021 |  |  | (15 | ) |  | 166,999 |  |  | 195,082 |  |  | (14 | ) |
| Video |  | 46,682 |  |  | 38,154 |  |  | 22 |  |  | 118,822 |  |  | 105,740 |  |  | 12 |  |
| Remotes |  | 25,116 |  |  | 26,049 |  |  | (4 | ) |  | 56,224 |  |  | 53,950 |  |  | 4 |  |
| Profit Maximization |  | 386,341 |  |  | 383,663 |  |  | 1 |  |  | 1,049,868 |  |  | 1,053,791 |  |  | — |  |
| Other |  | 132 |  |  | 11,178 |  |  | (99 | ) |  | 2,259 |  |  | 28,354 |  |  | (92 | ) |
| Non-Strategic |  | 132 |  |  | 11,178 |  |  | (99 | ) |  | 2,259 |  |  | 28,354 |  |  | (92 | ) |
| Retail |  | 574,025 |  |  | 564,221 |  |  | 2 |  |  | 1,471,301 |  |  | 1,442,085 |  |  | 2 |  |
| OEM |  | 30,297 |  |  | 34,542 |  |  | (12 | ) |  | 91,323 |  |  | 106,581 |  |  | (14 | ) |
|  |  | 604,322 |  |  | 598,763 |  |  | 1 |  |  | 1,562,624 |  |  | 1,548,666 |  |  | 1 |  |
| Video conferencing |  | 29,882 |  |  | 29,956 |  |  | — |  |  | 84,094 |  |  | 89,726 |  |  | (6 | ) |
|  |  | $ | 634,204 |  |  | $ | 628,719 |  |  | 1 |  |  | $ | 1,646,718 |  |  | $ | 1,638,392 |  |  | 1 |  |

[0001628280-15-000267:mdna:73]
[same as prior period, unchanged from 0001104659-14-083669:mdna:71]

[0001628280-15-000267:mdna:74]
[same as prior period, unchanged from 0001104659-14-083669:mdna:72]

[0001628280-15-000267:mdna:75]
[same as prior period, unchanged from 0001104659-14-083669:mdna:73]

[0001628280-15-000267:mdna:76]
[same as prior period, unchanged from 0001104659-14-083669:mdna:74]

[0001628280-15-000267:mdna:77]
Retail sales of PC Gaming increased 21% and units sold increased 24% in the three months ended December 31, 2014 compared to the three months ended December 31, 2013. Headset sales increased by 50%, with our F930 Wireless Gaming Headset making a strong contribution. Gaming mice and keyboard sales both increased by over 20%, with keyboard sales benefiting from the launch of our newest gaming keyboard, the G910 Orion Spark Mechanical Keyboard. Sales of our PC Gaming products grew strongly in both the Americas and EMEA, reflecting our improved product portfolio. Our overall growth in the category was constrained by a decline in sales of legacy steering wheels for console and PC platforms.

[0001628280-15-000267:mdna:78]
Retail sales of PC Gaming increased 16% and units sold increased 20%, in the nine months ended December 31, 2014 compared to the nine months ended December 31, 2013. New products made up 22% of total PC Gaming revenue for the nine months ended December 31, 2014.

[0001628280-15-000267:mdna:79]
[same as prior period, unchanged from 0001104659-14-083669:mdna:77]

[0001628280-15-000267:mdna:80]
[same as prior period, unchanged from 0001104659-14-083669:mdna:78]

[0001628280-15-000267:mdna:81]
Retail sales of Tablet & Other Accessories decreased 28% and units sold decreased 18% in the three months ended December 31, 2014, compared with the same period of the prior fiscal year. The reduction in sales reflects the combination of a

[0001628280-15-000267:mdna:82]
declining market for iPad shipments as well as execution challenges as we phased-in our new products, offset in part by sales growth with our tablet covers for the iPad.

[0001628280-15-000267:mdna:83]
Retail sales of Tablet & Other Accessories decreased 23% and units sold decreased 3% in the nine months ended December 31, 2014, compared with the same period of the prior fiscal year. New products made up 57% of total Tablet & Other Accessories revenue for the nine months ended December 31, 2014.

[0001628280-15-000267:mdna:84]
[same as prior period, unchanged from 0001104659-14-083669:mdna:81]

[0001628280-15-000267:mdna:85]
[same as prior period, unchanged from 0001104659-14-083669:mdna:82]

[0001628280-15-000267:mdna:86]
Retail sales and units sold of Mobile Speakers increased 82% and 86% respectively for the three month period ended December 31, 2014, compared with the same period of the prior fiscal year. Mobile Speaker sales increased significantly across our three regions due to strong demand for the UE Boom with sales in the Americas region doubling. UE Boom is now our best selling product across all product categories.

[0001628280-15-000267:mdna:87]
Retail sales and units sold of Mobile Speakers increased 105% and 113% respectively for the nine months ended December 31, 2014, compared with the same period of the prior fiscal year.

[0001628280-15-000267:mdna:88]
[same as prior period, unchanged from 0001104659-14-083669:mdna:85]

[0001628280-15-000267:mdna:89]
[same as prior period, unchanged from 0001104659-14-083669:mdna:86]

[0001628280-15-000267:mdna:90]
[same as prior period, unchanged from 0001104659-14-083669:mdna:87]

[0001628280-15-000267:mdna:91]
Retail sales of Pointing Devices remained flat while retail units sold increased 6% in the three months ended December 31, 2014, compared to the three month period ended December 31, 2013. Sales declined at the high end of the category, with growth in the mid-range and low-end. Sales of cordless mice decreased 1% with units sold increased 5%, while corded mice sales decreased 1%, with units sold increased 7%.

[0001628280-15-000267:mdna:92]
Retail sales of Pointing Devices decreased 1% while retail units sold increased 3% in the nine months ended December 31, 2014, compared to the nine month period ended December 31, 2013. Sales declined at the high end, with growth in the mid-range and low range. Sales of all cordless mice decreased 2% with units sold increased 4%, and corded mice sales decreased 1% with units sold decreased 1% .

[0001628280-15-000267:mdna:93]
[same as prior period, unchanged from 0001104659-14-083669:mdna:90]

[0001628280-15-000267:mdna:94]
[same as prior period, unchanged from 0001104659-14-083669:mdna:91]

[0001628280-15-000267:mdna:95]
Retail sales of PC Keyboards & Desktops increased 5% and units sold increased 12% in the three months ended December 31, 2014, compared with the same period of the prior fiscal year. We achieved single digit sales growth in all three of our retail sales regions. The sales increase was driven by corded and cordless combo products with strong contributions from the Wireless Combo MK270 and MK345 while sales of living room keyboards remained flat. Sales of corded and cordless combos increased 7% and 12%, respectively and units sold increased 26% and 20%, respectively.

[0001628280-15-000267:mdna:96]
Retail sales of PC Keyboards & Desktops and units sold increased 4% and 7% in the nine months ended December 31, 2014, compared with the same period of the prior fiscal year. The sales increase was driven by mid-range and low-end corded and cordless combo products. Sales of corded and cordless combos increased 23% and 7%, respectively and units sold increased 25% and 9%, respectively. Sales of corded and cordless keyboards decreased 4% and 7%, respectively and units sold decreased 2% and 5%, respectively. Living room key boards sales decreased 2% while units sold increased 4%.

[0001628280-15-000267:mdna:97]
[same as prior period, unchanged from 0001104659-14-083669:mdna:94]

[0001628280-15-000267:mdna:98]
[same as prior period, unchanged from 0001104659-14-083669:mdna:95]

[0001628280-15-000267:mdna:99]
Audio-PC & Wearables sales and units sold decreased 15%, in the three months ended December 31, 2014, compared with the same period of the prior fiscal year. The decrease was primarily due to decreases in PC speaker retail sales, reflecting a category that appears to be in structural decline as music consumption continues to migrate to mobile platforms, which benefits products such as our UE Bluetooth mobile speakers. Retail sales of our headset products decreased 9% and units decreased 8%.

[0001628280-15-000267:mdna:100]
Audio-PC & Wearables sales decreased 14% and units sold decreased 13%, in the nine months ended December 31, 2014, compared with the same period of the prior fiscal year. The decrease was primarily due to decreases in PC speaker retail sales, reflecting a category that appears to be in structural decline as music consumption continues to migrate to mobile platforms, which benefits products such as our UE Bluetooth mobile speakers. Retail sales of our headset products decreased 5% and units sold decreased 8%.

[0001628280-15-000267:mdna:101]
[same as prior period, unchanged from 0001104659-14-083669:mdna:98]

[0001628280-15-000267:mdna:102]
Our retail Video category comprises retail webcams, and business webcams and ConferenceCams delivering easy to use, affordable video collaboration solutions.

[0001628280-15-000267:mdna:103]
Retail Video sales increased 22% and units sold decreased 2% in the three months ended December 31, 2014, compared with the same period in the prior fiscal year. The sales growth in the Video category, which was achieved across all regions, was driven by our video collaboration offerings, such as the ConferenceCam CC3000E targeted at small and midsize conference rooms, as well as growth in business webcams.

[0001628280-15-000267:mdna:104]
Retail Video sales increased by 12% and units sold decreased by 12% in the nine months ended December 31, 2014, compared with the same period in the prior fiscal year. The sales growth in the Video category, which was achieved across all regions, was driven by our video collaboration offerings as well as growth in business webcams.

[0001628280-15-000267:mdna:105]
[same as prior period, unchanged from 0001104659-14-083669:mdna:102]

[0001628280-15-000267:mdna:106]
Our retail Remotes category comprises our Harmony branded products.

[0001628280-15-000267:mdna:107]
Remote retail sales decreased 4% and units sold increased 11% in the three months ended December 31, 2014, compared with the same period of the prior fiscal year. Sales decline was primarily driven by new Harmony Living Home products including Harmony Ultimate Touch with lower pricing.

[0001628280-15-000267:mdna:108]
Remote retail sales increased 4% and units sold increased 21% in the nine months ended December 31, 2014, compared with the same period of the prior fiscal year. Sales increase driven by new product launches partially offset by decline of Harmony Touch with lower pricing.

[0001628280-15-000267:mdna:109]
Non Strategic:

[0001628280-15-000267:mdna:110]
This category comprises a variety of products that we currently intend to transition out of, or have already transitioned out of, because they are no longer strategic to our business. Products categories included in this category include TV Camera, Digital Video Security, TV and home speakers, Google TV products, and Keyboard/ Desktop accessories.

[0001628280-15-000267:mdna:111]
Non-strategic retail sales decreased by 99% and 92%  and units sold decreased by 83% and 74% during the three and nine months ended December 31, 2014, compared with same period in the prior fiscal year.

[0001628280-15-000267:mdna:112]
[same as prior period, unchanged from 0001104659-14-083669:mdna:109]

[0001628280-15-000267:mdna:113]
OEM sales and units sold decreased by 12% and 19% during the three months ended, and decreased 14% and 22% during the nine months ended December 31, 2014, compared with the same period of the prior fiscal year. This decrease was primarily due to weak mice sales that were only partially offset by growth in Keyboards & Desktops. The decline in mice sales was expected, as we elected not to participate in lower margin opportunities with several customers.

[0001628280-15-000267:mdna:114]
[same as prior period, unchanged from 0001104659-14-083669:mdna:111]

[0001628280-15-000267:mdna:115]
Video conferencing net sales remained flat and decreased 6% during the three and nine months ended December 31, 2014, compared with the same period of the prior fiscal year. Lifesize is in the process of transitioning its product portfolio to the recently announced Lifesize Cloud, a software-as-a-service (SaaS) offering that provides an affordable, simple and scalable video conferencing solution with little to no need for IT involvement. Sales of Lifesize Cloud are growing rapidly, offsetting a shift from it's on-premise infrastructure products.  Video systems sales are growing and are expected to continue growing as an integral part of the full Lifesize solution.

[0001628280-15-000267:mdna:116]
[same as prior period, unchanged from 0001104659-14-083669:mdna:113]

[0001628280-15-000267:mdna:117]
Gross profit for the three and nine months ended December 31, 2014 and 2013 was as follows (in thousands):

[0001628280-15-000267:mdna:118]
|  |  | Three Months Ended December 31, |  | Nine Months Ended December 31, |
|  |  | 2014 |  | 2013 |  | Change |  | 2014 |  | 2013 |  | Change |
| Net sales |  | $ | 634,204 |  |  | $ | 628,719 |  |  | 1 | % |  | $ | 1,646,718 |  |  | $ | 1,638,392 |  |  | 1 | % |
| Cost of goods sold |  | 402,921 |  |  | 414,418 |  |  | (3 | ) |  | 1,028,905 |  |  | 1,071,867 |  |  | (4 | ) |
| Gross profit |  | $ | 231,283 |  |  | $ | 214,301 |  |  | 8 |  |  | $ | 617,813 |  |  | $ | 566,525 |  |  | 9 |  |
| Gross margin |  | 36.5 | % |  | 34.1 | % |  |  |  |  | 37.5 | % |  | 34.6 | % |  |  |  |

[0001628280-15-000267:mdna:119]
Gross profit consists of net sales, less cost of goods sold, which includes materials, direct labor and related overhead costs, costs of manufacturing facilities, costs of purchasing components from outside suppliers, distribution costs, warranty cost, customer support, outside processing costs, write-down of inventories and amortization of intangible assets.

[0001628280-15-000267:mdna:120]
The improvement in gross margin for the three months ended December 31, 2014 compared with the same period of the prior fiscal year primarily resulted from 1.3% margin improvement from the cost reduction initiatives in categories of Pointing Devices, Combos and Keyboards and Mobile Speakers, 0.9% from change of product mix driven by exiting our non-strategic categories, and lower inventory reserves, partially offset by increases in freight and duty costs.

[0001628280-15-000267:mdna:121]
The improvement in gross margin for the nine months ended December 31, 2014 compared with the same period of the prior fiscal year primarily resulted from 1.2% margin improvement from cost reduction initiatives across multiple product categories, 0.7% improvement due to change of product mix driven by exiting our non-strategic categories and lower mix of Tablets offset by a higher mix in Mobile Speakers, and 0.4% improvement due to one-time write off of $5.2 million for discontinued products resulting from the restructuring of our Video Conferencing reporting segment in the nine months ended December 31, 2013.

[0001628280-15-000267:mdna:122]
[same as prior period, unchanged from 0001104659-14-083669:mdna:118]

[0001628280-15-000267:mdna:123]
Operating expenses for the three and nine months ended December 31, 2014 and 2013 were as follows (in thousands):

[0001628280-15-000267:mdna:124]
|  |  | Three Months Ended December 31, |  | Nine Months Ended December 31, |
|  |  | 2014 |  | 2013 |  | Change |  | 2014 |  | 2013 |  | Change |
| Marketing and selling |  | $ | 103,307 |  |  | $ | 94,273 |  |  | 10 | % |  | $ | 290,215 |  |  | $ | 288,817 |  |  | — | % |
| % of net sales |  | 16.3 | % |  | 15.0 | % |  |  |  |  | 17.6 | % |  | 17.6 | % |  |  |  |
| Research and development |  | 33,616 |  |  | 34,577 |  |  | (3 | ) |  | 97,257 |  |  | 108,589 |  |  | (10 | ) |
| % of net sales |  | 5.3 | % |  | 5.5 | % |  |  |  |  | 5.9 | % |  | 6.6 | % |  |  |  |
| General and administrative |  | 29,808 |  |  | 31,998 |  |  | (7 | ) |  | 100,957 |  |  | 90,247 |  |  | 12 |  |
| % of net sales |  | 4.7 | % |  | 5.1 | % |  |  |  |  | 6.1 | % |  | 5.5 | % |  |  |  |
| Restructuring charges (credits), net |  | (146 | ) |  | 822 |  |  | (118 | ) |  | (146 | ) |  | 8,621 |  |  | (102 | ) |
| % of net sales |  | — | % |  | 0.1 | % |  |  |  |  | — | % |  | 0.5 | % |  |  |  |
| Total operating expenses |  | $ | 166,585 |  |  | $ | 161,670 |  |  | 3 |  |  | $ | 488,283 |  |  | $ | 496,274 |  |  | (2 | ) |
| % of net sales |  | 26.3 | % |  | 25.7 | % |  |  |  |  | 29.7 | % |  | 30.3 | % |  |  |  |

[0001628280-15-000267:mdna:125]
[same as prior period, unchanged from 0001104659-14-083669:mdna:122]

[0001628280-15-000267:mdna:126]
Marketing and selling expense consists of personnel and related overhead costs, corporate and product marketing, advertising, trade shows, customer and technical support and facilities costs.

[0001628280-15-000267:mdna:127]
During the three months ended December 31, 2014, marketing and selling expenses increased 10%, compared to the three months ended December 31, 2013. The increase was primarily due to a $8.6 million investment in marketing and promotional activities for our Mobile Speakers and Gaming product categories and a $2.1 million investment in marketing and promotional activities in our LifeSize Cloud product offerings, partially offset by a $1.7 million savings in other marketing and selling expenses. The increase in marketing and promotion investments is consistent with our strategic plan for these product

[0001628280-15-000267:mdna:128]
categories. During the nine months ended December 31, 2014, marketing and selling expenses remained flat compared to the nine months ended December 31, 2013.

[0001628280-15-000267:mdna:129]
[same as prior period, unchanged from 0001104659-14-083669:mdna:125]

[0001628280-15-000267:mdna:130]
[same as prior period, unchanged from 0001104659-14-083669:mdna:126]

[0001628280-15-000267:mdna:131]
During the three months ended December 31, 2014, research and development expenses decreased 3%, compared to the three months ended December 31, 2013. The decrease was primarily due to lower personnel-related expenses. During the nine months ended December 31, 2014, research and development expenses decreased 10%, compared to the nine months ended December 31, 2013. The decrease was primarily due to $5.8 million lower personnel-related expenses and $3.0 million higher research and development expense in nine months period ended December 31, 2013 related to Gaming and Tablets product categories.

[0001628280-15-000267:mdna:132]
[same as prior period, unchanged from 0001104659-14-083669:mdna:128]

[0001628280-15-000267:mdna:133]
[same as prior period, unchanged from 0001104659-14-083669:mdna:129]

[0001628280-15-000267:mdna:134]
During the three months ended December 31, 2014, general and administrative expenses decreased 7%, compared to the three months ended December 31, 2013. The decrease was primarily due to a $2.3 million saving in IT infrastructure costs. During the nine months ended December 31, 2014, general and administrative expenses increased 12%, compared to the nine months ended December 31, 2013. The increase was driven by a $19.5 million increase in our legal and consulting expense due to the Audit Committee investigation. This increase was partially offset by a $4.7 million saving in IT infrastructure costs and a $2.2 million rent expense savings as a result of the integration of some of our facilities.

[0001628280-15-000267:mdna:135]
[same as prior period, unchanged from 0001104659-14-083669:mdna:131]

[0001628280-15-000267:mdna:136]
During the fourth quarter of fiscal year 2013, Logitech implemented a restructuring plan to align the organization to its strategic priorities of increasing focus on mobility products, improving profitability in PC-related products and enhancing global operational efficiencies. Restructuring charges under this plan primarily consisted of severance and other one-time termination benefits. Charges and other costs related to the workforce reduction are presented as restructuring charges in the consolidated statements of operations. During the three months and nine months ended December 31, 2013, restructuring charges under this plan included $0.1 million and $6.7 million, respectively, in termination benefits to employees, and $0.7 million and $1.9 million in lease exit costs, respectively.

[0001628280-15-000267:mdna:137]
The Company substantially completed the restructuring in the fourth quarter of fiscal year 2014, and did not incur any material charges during the first nine months of fiscal 2015.

[0001628280-15-000267:mdna:138]
[same as prior period, unchanged from 0001104659-14-083669:mdna:134]

[0001628280-15-000267:mdna:139]
Interest Income (Expense), Net

[0001628280-15-000267:mdna:140]
Interest income and expense for the three and nine months ended December 31, 2014 and 2013 were as follows (in thousands):

[0001628280-15-000267:mdna:141]
|  |  | Three Months Ended December 31, |  | Nine Months Ended December 31, |
|  |  | 2014 |  | 2013 |  | Change |  | 2014 |  | 2013 |  | Change |
| Interest income |  | $ | 314 |  |  | $ | 438 |  |  | (28 | )% |  | $ | 902 |  |  | $ | 1,356 |  |  | (33 | )% |
| Interest expense |  | (90 | ) |  | $ | (1,460 | ) |  | (94 | ) |  | (65 | ) |  | (2,218 | ) |  | (97 | ) |
|  |  | $ | 224 |  |  | $ | (1,022 | ) |  | (122 | ) |  | $ | 837 |  |  | $ | (862 | ) |  | (197 | ) |

[0001628280-15-000267:mdna:142]
Interest income was lower in the three and nine months ended December 31, 2014, compared with the three and nine months ended December 31, 2013, primarily due to the mix of cash balances held by subsidiaries in different countries during the three and nine months ended December 31, 2014 compared to the prior periods.

[0001628280-15-000267:mdna:143]
Interest expense was lower in the three and nine months ended December 31, 2014, compared with the three and nine months ended December 31, 2013, primarily due to commitment fees and non-recurring fees related to our $250 million Senior Revolving Credit Facility entered into in December 2011 that was in place during the three and nine months ended December 31, 2013. In December 2013, given the significant improvement in our financial performance and outlook, we chose to terminate this Credit Facility.

[0001628280-15-000267:mdna:144]
[same as prior period, unchanged from 0001104659-14-083669:mdna:143]

[0001628280-15-000267:mdna:145]
Other income and expense for the three and nine months ended December 31, 2014 and 2013 were as follows (in thousands):

[0001628280-15-000267:mdna:146]
|  |  | Three Months Ended December 31, |  | Nine Months Ended December 31, |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Investment income related to deferred compensation plan |  | $ | 66 |  |  | $ | 883 |  |  | $ | 714 |  |  | $ | 1,126 |  |
| Impairment of investments |  | (2,154 | ) |  | (38 | ) |  | (2,259 | ) |  | (307 | ) |
| Foreign currency exchange gain (loss), net |  | (833 | ) |  | (40 | ) |  | (2,476 | ) |  | 185 |  |
| Other |  | (95 | ) |  | 277 |  |  | (78 | ) |  | 357 |  |
|  |  | $ | (3,016 | ) |  | $ | 1,082 |  |  | $ | (4,099 | ) |  | $ | 1,361 |  |

[0001628280-15-000267:mdna:147]
Investment income for three and nine months ended December 31, 2014 and 2013 represents earnings, gains, and losses on trading investments related to a deferred compensation plan offered by one of our subsidiaries.

[0001628280-15-000267:mdna:148]
During the three months and nine months ended December 31, 2014 we had a $2.3 million investment impairment resulting from the write-down of an investment in a privately held company. We had a $0.4 million investment impairment in the nine months ended December 31, 2013 resulting from the write-down of an investment in a privately held company.

[0001628280-15-000267:mdna:149]
The foreign currency exchange losses were $0.8 million and $2.5 million during the three and nine months ended December 31, 2014. Foreign currency exchange gains or losses relate to balances denominated in currencies other than the functional currency of a particular subsidiary, to the sale of currencies, and to gains or losses recognized on foreign exchange forward contracts. The increase in the foreign currency exchange losses mainly results from the weakening euro during the three and nine months ended December 31, 2014.

[0001628280-15-000267:mdna:150]
[same as prior period, unchanged from 0001104659-14-083669:mdna:149]

[0001628280-15-000267:mdna:151]
The provision for and (benefit from) income taxes and effective tax rates for the three and nine months ended December 31, 2014 and 2013 were as follows (in thousands):

[0001628280-15-000267:mdna:152]
|  |  | Three Months Ended December 31, |  | Nine Months Ended December 31, |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Provision for (benefit from) income tax |  | $ | (878 | ) |  | $ | 4,807 |  |  | $ | 7,718 |  |  | $ | 7,064 |  |
| Effective income tax rate |  | (1.4 | )% |  | 9.1 | % |  | 6.1 | % |  | 10.0 | % |

[0001628280-15-000267:mdna:153]
The change in the effective income tax rate for the three and nine months ended December 31, 2014 compared with the three and nine months ended December 31, 2013 is primarily due to the mix of income and losses in the various tax jurisdictions in which we operate. There was a discrete tax benefit of $9.0 million and $11.1 million in the three and nine months ended December 31, 2014, respectively, from the reversal of uncertain tax positions resulting from expiration of the statutes of limitations. In the three and nine months ended December 31, 2013, the discrete tax benefit from the reversal of uncertain tax positions resulting from expiration of the statutes of limitations was $10.0 million and $12.0 million, respectively.

[0001628280-15-000267:mdna:154]
On December 19, 2014, the enactment in the U.S. of the Tax Increase Prevention Act of 2014 extended the U.S. federal research and development tax credit through December 31, 2014 which had previously expired on December 31, 2013.  The income tax benefit and income tax provision in the three and nine months ended December 31, 2014 reflected a $0.8 million tax benefit, respectively, as a result of the extension of the tax credit.

[0001628280-15-000267:mdna:155]
As of December 31 and March 31, 2014, the total amount of unrecognized tax benefits due to uncertain tax positions was $85.1 million and $91.0 million, respectively, of which $83.9 million and $86.1 million, respectively, would affect the effective income tax rate if recognized. Pursuant to ASU 2013-11 which became effective in the first quarter of fiscal year 2015, we reclassified $9.8 million of unrecognized tax benefits previously presented as non-current income taxes payable to a reduction in non-current deferred tax assets for tax credit carryforwards.

[0001628280-15-000267:mdna:156]
[same as prior period, unchanged from 0001104659-14-083669:mdna:156]

[0001628280-15-000267:mdna:157]
[same as prior period, unchanged from 0001104659-14-083669:mdna:157]

[0001628280-15-000267:mdna:158]
As of December 31, 2014, we had cash and cash equivalents of $516.6 million, compared with $469.4 million at March 31, 2014. Our cash and cash equivalents consist of bank demand deposits and short-term time deposits of which 56% is held by our subsidiaries in Switzerland, 36% is held by our subsidiaries in Hong Kong, Germany and the Netherlands, and 8% is held by subsidiaries in various other countries. We do not expect to incur any material adverse tax impact or be significantly inhibited by any country in which we do business from the repatriation of funds to Switzerland, our home domicile.

[0001628280-15-000267:mdna:159]
As of December 31, 2014, our working capital was $559.8 million compared with working capital of $478.2 million at March 31, 2014. The increase in working capital was primarily due to higher cash and cash equivalents, accounts receivable and inventory balances at December 31, 2014.

[0001628280-15-000267:mdna:160]
During the nine months ended December 31, 2014, we generated $137.1 million from operating activities. Our main sources of operating cash flows were net income after adding non-cash expenses of depreciation, amortization and share-based compensation expense, and from increases in accounts payable and accrued liabilities. These sources of operating cash flows were partially offset by increases in accounts receivables and inventories. Net cash used in investing activities was $36.9 million, primarily from $34.8 million of capital expenditure in computer hardware and software, tooling and equipment, and $2.6 million investment in privately held companies. Net cash used in financing activities was $47.4 million, primarily from $43.8 million of cash dividend payments made in December 2014.

[0001628280-15-000267:mdna:161]
We had several uncommitted, unsecured bank lines of credit aggregating $38.7 million as of December 31, 2014. There are no financial covenants under these lines of credit with which we must comply. As of December 31, 2014, we had outstanding bank guarantees of $7.5 million under these lines of credit.

[0001628280-15-000267:mdna:162]
[same as prior period, unchanged from 0001104659-14-083669:mdna:162]

[0001628280-15-000267:mdna:163]
[same as prior period, unchanged from 0001104659-14-083669:mdna:163]

[0001628280-15-000267:mdna:164]
|  |  | Nine Months Ended December 31, |
|  |  | 2014 |  | 2013 |
| Net cash provided by operating activities |  | $ | 137,058 |  |  | $ | 110,699 |  |
| Net cash used in investing activities |  | (36,934 | ) |  | (34,819 | ) |
| Net cash used in financing activities |  | (47,402 | ) |  | (30,023 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  | (5,521 | ) |  | 184 |  |
| Net increase in cash and cash equivalents |  | $ | 47,201 |  |  | $ | 46,041 |  |

[0001628280-15-000267:mdna:165]
[same as prior period, unchanged from 0001104659-14-083669:mdna:166]

[0001628280-15-000267:mdna:166]
The following table presents selected financial information and statistics as of December 31, 2014 and 2013 (dollars in thousands):

[0001628280-15-000267:mdna:167]
|  |  | As ofDecember 31, |  |  |
|  |  | 2014 |  |  |  | 2013 |  |  |
| Accounts receivable, net |  | $ | 306,866 |  |  |  |  | $ | 312,947 |  |  |  |
| Inventories |  | 245,740 |  |  |  |  | 259,154 |  |  |  |
| Working capital |  | 559,847 |  |  |  |  | 451,904 |  |  |  |
| Days sales in accounts receivable (“DSO”)(1) |  | 44 |  |  | days |  | 45 |  |  | days |
| Inventory turnover (“ITO”)(2) |  | 6.6 |  |  | x |  | 6.4 |  |  | x |

[0001628280-15-000267:mdna:168]
(1)             DSO is determined using ending accounts receivable as of the most recent quarter-end and net sales for the most recent quarter.

[0001628280-15-000267:mdna:169]
(2)               ITO is determined using ending inventories and annualized cost of goods sold (based on the most recent quarterly cost of goods sold).

[0001628280-15-000267:mdna:170]
During the nine months ended December 31, 2014, we generated net cash of $137.1 million for operating activities, compared to $110.7 million for the same period in the prior fiscal year. The primary drivers of the increase in net cash generated from operating cash flows include an increase in net income of $54.9 million, partially offset by the decrease in change of operating assets and liability of $16.7 million and the decrease of amortization expense of $7.3 million and the decrease of disposal loss of fixed assets of $3.9 million for the nine months ended December 31, 2014 from the nine months ended December 31, 2013.

[0001628280-15-000267:mdna:171]
DSO remained consistent for the three months ended December 31, 2014 compared to the three months ended December 31, 2013.  Typical payment terms require customers to pay for product sales generally within 30 to 60 days. However, terms may vary by customer type, by country and by selling season. Extended payment terms are sometimes offered to a limited number of customers during the second and third fiscal quarters. We do not modify payment terms on existing receivables, but may offer discounts for early payment.

[0001628280-15-000267:mdna:172]
Inventory turnover during the three months ended December 31, 2014 increased, compared with the three months ended December 31, 2013 due to our better management of inventories.

[0001628280-15-000267:mdna:173]
[same as prior period, unchanged from 0001104659-14-083669:mdna:174]

[0001628280-15-000267:mdna:174]
The following table presents information on our cash flows from investing activities during the nine months ended December 31, 2014 and 2013 (in thousands):

[0001628280-15-000267:mdna:175]
|  |  | Nine Months Ended December 31, |
|  |  | 2014 |  | 2013 |
| Purchases of property, plant and equipment |  | $ | (34,777 | ) |  | $ | (34,910 | ) |
| Investment in privately held companies |  | (2,550 | ) |  | — |  |
| Acquisitions, net of cash acquired |  | — |  |  | (650 | ) |
| Proceeds from return of investment from strategic investment |  | — |  |  | 261 |  |
| Purchase of trading investments |  | (3,463 | ) |  | (7,831 | ) |
| Proceeds from sales of trading investments |  | 3,856 |  |  | 8,311 |  |
| Net cash used in investing activities |  | $ | (36,934 | ) |  | $ | (34,819 | ) |

[0001628280-15-000267:mdna:176]
Our expenditures for property, plant and equipment during the nine months ended December 31, 2014 and 2013 were primarily expenditures for computer hardware and software, tooling and equipment.

[0001628280-15-000267:mdna:177]
During the nine months ended December 31, 2014, we made strategic investments of $2.6 million in privately held companies. During the nine months ended December 31, 2013, we made a $0.7 million strategic investment.

[0001628280-15-000267:mdna:178]
The purchases and sales of trading investments in the three months ended December 31, 2014 and 2013 represent mutual fund activity directed by participants in a deferred compensation plan offered by one of our subsidiaries. The mutual funds are held by a Rabbi Trust.

[0001628280-15-000267:mdna:179]
[same as prior period, unchanged from 0001104659-14-083669:mdna:180]

[0001628280-15-000267:mdna:180]
The following table presents information on our cash flows from financing activities during the nine months ended December 31, 2014 and 2013 (in thousands):

[0001628280-15-000267:mdna:181]
|  |  | Nine Months Ended December 31, |
|  |  | 2014 |  | 2013 |
| Payment of cash dividends |  | $ | (43,767 | ) |  | $ | (36,123 | ) |
| Contingent cash payment of acquisition |  | (100 | ) |  | — |  |
| Repurchase of ESPP awards |  | (1,078 | ) |  | — |  |
| Proceeds from sales of shares upon exercise of options and purchase rights |  | 2,466 |  |  | 8,465 |  |
| Tax withholdings related to net share settlements of restricted stock units |  | (7,456 | ) |  | (2,937 | ) |
| Excess tax benefits from share-based compensation |  | 2,533 |  |  | 572 |  |
| Net cash used in financing activities |  | $ | (47,402 | ) |  | $ | (30,023 | ) |

[0001628280-15-000267:mdna:182]
For both the nine months ended December 31, 2014 and 2013 no share repurchases were made.

[0001628280-15-000267:mdna:183]
Proceeds from the sale of shares upon exercise of options and purchase rights pursuant to our stock plans during the nine months ended December 31, 2014 and 2013 were $2.5 million and $8.5 million, respectively. The payment of required tax withholdings related to net share settlements of RSUs (restricted stock units) during the nine months ended December 31, 2014 and 2013 was $7.5 million and $2.9 million, respectively. During nine months ended December 31, 2014, we paid a cash dividend of CHF 43.1 million (U.S. dollar amount of $43.8 million) out of retained earnings. During nine months ended December 31, 2013, we paid a cash dividend of CHF 33.7 million (U.S. dollar amount of $36.1 million) out of retained earnings.

[0001628280-15-000267:mdna:184]
[same as prior period, unchanged from 0001104659-14-083669:mdna:185]

[0001628280-15-000267:mdna:185]
[same as prior period, unchanged from 0001104659-14-083669:mdna:186]

[0001628280-15-000267:mdna:186]
In March 2014, our Board of Directors approved a new share buyback program, which authorizes us to purchase up to $250.0 million of our own shares. Our share buyback program provides us with the opportunity to make opportunistic repurchases during periods of favorable market conditions and is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market with consideration given to our stock price, market conditions and other factors.  There were no share repurchases during the nine months ended December 31, 2014 and 2013. During most of the nine month period ended December 31, 2014, the Company was not current with its periodic reports required to be filed with the SEC and therefore lost its ability to buy back shares. The Company regained its ability to repurchase shares upon filing its Form 10-Q with SEC on November 26, 2014.

[0001628280-15-000267:mdna:187]
[same as prior period, unchanged from 0001104659-14-083669:mdna:188]

[0001628280-15-000267:mdna:188]
In December 2014, we paid a cash dividend of CHF 43.1 million (U.S. dollar amount of $43.8 million) out of retained earnings. During fiscal year 2014, we paid a cash dividend of CHF 33.7 million (U.S. dollar amount of $36.1 million) out of retained earnings. We plan to issue an annual dividend on a recurring basis. If we do not generate sufficient operating cash flows to support our operations and future planned cash requirements, our operations could be harmed and our access to credit facilities could be restricted or eliminated. However, we believe that the trend of our historical cash flow generation, our projections of future operations and reduced expenses and our available cash balances will provide sufficient liquidity to fund our operations for at least the next 12 months.

[0001628280-15-000267:mdna:189]
[same as prior period, unchanged from 0001104659-14-083669:mdna:191]

[0001628280-15-000267:mdna:190]
[same as prior period, unchanged from 0001104659-14-083669:mdna:192]

[0001628280-15-000267:mdna:191]
We lease facilities under operating leases, certain of which require us to pay property taxes, insurance and maintenance costs. Operating leases for facilities are generally renewable at our option and usually include escalation clauses linked to inflation. The remaining terms on our non-cancelable operating leases expire in various years through 2030. Our asset retirement obligations on these leases as of December 31, 2014 were not material.

[0001628280-15-000267:mdna:192]
[same as prior period, unchanged from 0001104659-14-083669:mdna:194]

[0001628280-15-000267:mdna:193]
As of December 31, 2014, we had fixed purchase commitments for inventory purchases made in the normal course of business to original design manufacturers, contract manufacturers and other suppliers, the majority of which are expected to be fulfilled during the third quarter of fiscal year 2015. Fixed purchase commitments for capital expenditures primarily relate to commitments for computer hardware and leasehold improvements. We expect to continue making capital expenditures in the future to support product development activities and ongoing and expanded operations. Although open purchase commitments are considered enforceable and legally binding, the terms generally allow us to reschedule or adjust our requirements based on business needs prior to delivery of goods or performance of services.

[0001628280-15-000267:mdna:194]
[same as prior period, unchanged from 0001104659-14-083669:mdna:196]

[0001628280-15-000267:mdna:195]
As of December 31, 2014, we had $17.5 million in liabilities related to a deferred compensation plan offered by one of our subsidiaries. For more information, please refer to our Annual Report on Form 10-K for the fiscal year ended March 31, 2014.

[0001628280-15-000267:mdna:196]
[same as prior period, unchanged from 0001104659-14-083669:mdna:198]

[0001628280-15-000267:mdna:197]
As of December 31, 2014, we had $36.4 million in liabilities related to our defined benefit pension plans and non-retirement post-employment benefit obligations, of which $1.5 million is payable in the next 12 months. For more information, please refer to our Annual Report on Form 10-K for the fiscal year ended March 31, 2014.

[0001628280-15-000267:mdna:198]
[same as prior period, unchanged from 0001104659-14-083669:mdna:200]

[0001628280-15-000267:mdna:199]
[same as prior period, unchanged from 0001104659-14-083669:mdna:201]

[0001628280-15-000267:mdna:200]
[same as prior period, unchanged from 0001104659-14-083669:mdna:202]

[0001628280-15-000267:mdna:201]
[same as prior period, unchanged from 0001104659-14-083669:mdna:203]

[0001628280-15-000267:mdna:202]
Other Contingencies

[0001628280-15-000267:mdna:203]
We are subject to an ongoing formal investigation by the SEC, relating to certain issues including the accounting for Revue inventory valuation reserves that resulted in the restatement, described in the Fiscal 2014 Form 10-K, revision to our financial statements concerning warranty accruals and amortization of intangible assets presented in our Form 10-K/A, filed on August 7, 2013, and our transactions with a distributor for Fiscal Year 2007 through Fiscal Year 2009. We are cooperating with the SEC in its ongoing investigation. We have entered into an agreement with the SEC to extend the statute of limitations. We cannot predict the outcome of the investigation at this time and any potential fines or penalties, if any, that may arise from the investigation are currently not estimable.

[0001628280-15-000267:mdna:204]
[same as prior period, unchanged from 0001104659-14-083669:mdna:208]

[0001628280-15-000267:mdna:205]
Logitech Europe S.A.  guaranteed payments of a third-party contract manufacturer’s purchase obligations. As of December 31, 2014, the maximum amount of this guarantee was $3.5 million, of which $1.4 million of guaranteed purchase obligations were outstanding.

[0001628280-15-000267:mdna:206]
[same as prior period, unchanged from 0001104659-14-083669:mdna:210]

[0001628280-15-000267:mdna:207]
We indemnify certain of our suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of December 31, 2014, no amounts have been accrued for indemnification provisions. We do not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under our indemnification arrangements.

[0001628280-15-000267:mdna:208]
[same as prior period, unchanged from 0001104659-14-083669:mdna:212]

[0001628280-15-000267:mdna:209]
Legal Proceedings

[0001628280-15-000267:mdna:210]
From time to time we are involved in claims and legal proceedings that arise in the ordinary course of its business. We are currently subject to several such claims and a small number of legal proceedings. We believe that these matters lack merit and we intend to vigorously defend against them. Based on currently available information, we do not believe that resolution of pending matters will have a material adverse effect on our financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that our defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on our business, financial condition, cash flows and results of operations in a particular period. Any claims or proceedings against us, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect our business.
