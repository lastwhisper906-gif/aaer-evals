# LOGI notes — 0001628280-15-000267


## logi:ScheduleOfBalanceSheetComponentsAssetsTableTextBlock

[0001628280-15-000267:notes:1]
The following table presents the components of certain balance sheet asset amounts as of December 31 and March 31, 2014 (in thousands):

[0001628280-15-000267:notes:2]
|  |  | December 31,2014 |  | March 31,2014 |
| Accounts receivable, net: |  |  |  |  |  |  |
| Accounts receivable |  | $ | 537,240 |  |  | $ | 338,194 |  |
| Allowance for doubtful accounts |  | (1,576 | ) |  | (1,712 | ) |
| Allowance for sales returns |  | (17,706 | ) |  | (19,472 | ) |
| Allowance for cooperative marketing arrangements |  | (36,764 | ) |  | (24,135 | ) |
| Allowance for customer incentive programs |  | (74,096 | ) |  | (41,400 | ) |
| Allowance for pricing programs |  | (100,232 | ) |  | (69,446 | ) |
|  |  | $ | 306,866 |  |  | $ | 182,029 |  |
| Inventories: |  |  |  |  |  |  |
| Raw materials |  | $ | 31,006 |  |  | $ | 24,031 |  |
| Work-in-process |  | 29 |  |  | 42 |  |
| Finished goods |  | 214,705 |  |  | 198,329 |  |
|  |  | $ | 245,740 |  |  | $ | 222,402 |  |
| Other current assets: |  |  |  |  |  |  |
| Income tax and value-added tax receivables |  | $ | 21,729 |  |  | $ | 18,252 |  |
| Deferred tax assets |  | 26,863 |  |  | 27,013 |  |
| Prepaid expenses and other assets |  | 17,021 |  |  | 13,892 |  |
|  |  | $ | 65,613 |  |  | $ | 59,157 |  |
| Property, plant and equipment, net: |  |  |  |  |  |  |
| Plant, buildings and improvements |  | $ | 70,174 |  |  | $ | 69,897 |  |
| Equipment |  | 138,979 |  |  | 134,975 |  |
| Computer equipment |  | 41,106 |  |  | 40,610 |  |
| Software |  | 81,787 |  |  | 81,179 |  |
|  |  | 332,046 |  |  | 326,661 |  |
| Less accumulated depreciation |  | (268,828 | ) |  | (256,424 | ) |
|  |  | 63,218 |  |  | 70,237 |  |
| Construction-in-process |  | 24,832 |  |  | 15,362 |  |
| Land |  | 2,727 |  |  | 2,792 |  |
|  |  | $ | 90,777 |  |  | $ | 88,391 |  |
| Other assets: |  |  |  |  |  |  |
| Deferred tax assets |  | $ | 43,778 |  |  | $ | 52,883 |  |
| Trading investments |  | 17,483 |  |  | 16,611 |  |
| Other assets |  | 5,744 |  |  | 4,966 |  |
|  |  | $ | 67,005 |  |  | $ | 74,460 |  |


## logi:ScheduleOfBalanceSheetComponentsLiabilityTableTextBlock

[0001628280-15-000267:notes:3]
The following table presents the components of certain balance sheet liability amounts as of December 31 and March 31, 2014 (in thousands):

[0001628280-15-000267:notes:4]
|  |  | December 31,2014 |  | March 31,2014 |
| Accrued and other current liabilities: |  |  |  |  |  |  |
| Accrued personnel expenses |  | $ | 54,803 |  |  | $ | 55,165 |  |
| Accrued marketing expenses |  | 13,259 |  |  | 12,844 |  |
| Indirect customer incentive programs |  | 35,868 |  |  | 31,737 |  |
| Accrued restructuring |  | 1,772 |  |  | 2,121 |  |
| Deferred revenue |  | 22,862 |  |  | 22,529 |  |
| Accrued freight and duty |  | 11,723 |  |  | 6,276 |  |
| Value-added taxes payable |  | 9,825 |  |  | 9,354 |  |
| Accrued royalties |  | 3,387 |  |  | 2,653 |  |
| Warranty accrual |  | 12,799 |  |  | 13,905 |  |
| Employee benefit plan obligation |  | 1,498 |  |  | 1,100 |  |
| Income taxes payable |  | 8,894 |  |  | 7,701 |  |
| Other current liabilities |  | 47,960 |  |  | 46,587 |  |
|  |  | $ | 224,650 |  |  | $ | 211,972 |  |
| Non-current liabilities: |  |  |  |  |  |  |
| Warranty accrual |  | $ | 9,293 |  |  | $ | 10,475 |  |
| Obligation for deferred compensation |  | 17,483 |  |  | 16,611 |  |
| Long term restructuring |  | 4,391 |  |  | 5,440 |  |
| Employee benefit plan obligation |  | 34,917 |  |  | 37,899 |  |
| Deferred rent |  | 14,200 |  |  | 15,555 |  |
| Deferred tax liability |  | 1,964 |  |  | 2,304 |  |
| Long term deferred revenue |  | 9,692 |  |  | 9,350 |  |
| Other non-current liabilities |  | 1,523 |  |  | 1,715 |  |
|  |  | $ | 93,463 |  |  | $ | 99,349 |  |


## logi:ScheduleOfErrorCorrectionsAndPriorPeriodAdjustmentsConsolidatedStatementsOfCashFlowsTableTextBlock

[0001628280-15-000267:notes:5]
The following table presents the impact of the correcting adjustments on the Company’s previously reported consolidated statement of cash flows for the nine months ended December 31, 2013 (in thousands):

[0001628280-15-000267:notes:6]
|  |  | Nine Months Ended December 31, 2013 |
|  |  | As Reported |  | Adjustments* |  | As Revised |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 63,944 |  |  | (258 | ) |  | $ | 63,686 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |
| Depreciation |  | 28,756 |  |  | 3,999 |  |  | 32,755 |  |
| Amortization of other intangible assets |  | 14,990 |  |  | — |  |  | 14,990 |  |
| Share-based compensation expense |  | 17,412 |  |  | — |  |  | 17,412 |  |
| Impairment of investments |  | 568 |  |  | — |  |  | 568 |  |
| Loss on disposal of property, plant and equipment |  | 3,878 |  |  | — |  |  | 3,878 |  |
| Excess tax benefits from share- based compensation |  | (572 | ) |  | — |  |  | (572 | ) |
| Deferred income taxes |  | (3,559 | ) |  | (2 | ) |  | (3,561 | ) |
| Changes in assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | (130,265 | ) |  | (606 | ) |  | (130,871 | ) |
| Inventories |  | 14,652 |  |  | (1,156 | ) |  | 13,496 |  |
| Other assets |  | (2,968 | ) |  | — |  |  | (2,968 | ) |
| Accounts payable |  | 62,931 |  |  | (1,508 | ) |  | 61,423 |  |
| Accrued and other liabilities |  | 38,118 |  |  | 2,345 |  |  | 40,463 |  |
| Net cash provided by operating activities |  | 107,885 |  |  | 2,814 |  |  | 110,699 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  | (32,096 | ) |  | (2,814 | ) |  | (34,910 | ) |
| Acquisitions, net of cash acquired |  | (650 | ) |  | — |  |  | (650 | ) |
| Proceeds from return of investment from strategic investment |  | 261 |  |  | — |  |  | 261 |  |
| Purchases of trading investments |  | (7,831 | ) |  | — |  |  | (7,831 | ) |
| Proceeds from sales of trading investments |  | 8,311 |  |  | — |  |  | 8,311 |  |
| Net cash used in investing activities |  | (32,005 | ) |  | (2,814 | ) |  | (34,819 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Payment of cash dividends |  | (36,123 | ) |  | — |  |  | (36,123 | ) |
| Proceeds from sales of shares upon exercise of options and purchase rights |  | 8,465 |  |  | — |  |  | 8,465 |  |
| Tax withholdings related to net share settlements of restricted stock units |  | (2,937 | ) |  | — |  |  | (2,937 | ) |
| Excess tax benefits from share-based compensation |  | 572 |  |  | — |  |  | 572 |  |
| Net cash used in financing activities |  | (30,023 | ) |  | — |  |  | (30,023 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  | 184 |  |  | — |  |  | 184 |  |
| Net increase in cash and cash equivalents |  | 46,041 |  |  | — |  |  | 46,041 |  |
| Cash and cash equivalents at beginning of period |  | 333,824 |  |  | — |  |  | 333,824 |  |
| Cash and cash equivalents at end of period |  | $ | 379,865 |  |  | $ | — |  |  | $ | 379,865 |  |
| Property, plant and equipment purchased during the period and included in period end liability accounts |  | $ | 4,134 |  |  | $ | — |  |  | $ | 4,134 |  |

[0001628280-15-000267:notes:7]
* The adjustments included in these financial statements for the nine months ended December 31, 2013 primarily related to a correction to revenue that was previously recorded as an out-of-period adjustment and is now being reported in the correct period, capitalization of property, plant and equipment which was previously incorrectly expensed, pension obligation, other misstatements, and the tax impact of these adjustments.


## logi:ScheduleOfErrorCorrectionsAndPriorPeriodAdjustmentsConsolidatedStatementsOfComprehensiveIncomeLossTableTextBlock

[0001628280-15-000267:notes:8]
The following table presents the impact of the correcting adjustments on the Company’s previously reported consolidated statement of comprehensive income for the three and nine months ended December 31, 2013 (in thousands):

[0001628280-15-000267:notes:9]
|  |  | Three Months EndedDecember 31, 2013 |  | Nine Months EndedDecember 31, 2013 |
|  |  | As Reported |  | Adjustments* |  | As Revised |  | As Reported |  | Adjustments* |  | As Revised |
| Net income |  | $ | 48,503 |  |  | $ | (619 | ) |  | $ | 47,884 |  |  | $ | 63,944 |  |  | $ | (258 | ) |  | $ | 63,686 |  |
| Other comprehensive income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation gain |  | 682 |  |  | — |  |  | 682 |  |  | 3,511 |  |  | 598 |  |  | 4,109 |  |
| Defined benefit pension plans: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net loss and prior service costs, net of taxes |  | (384 | ) |  | — |  |  | (384 | ) |  | (1,384 | ) |  | 761 |  |  | (623 | ) |
| Amortization included in operating expenses |  | 318 |  |  | — |  |  | 318 |  |  | 933 |  |  | 779 |  |  | 1,712 |  |
| Hedging gain (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Unrealized hedging loss |  | (1,198 | ) |  | — |  |  | (1,198 | ) |  | (3,484 | ) |  | — |  |  | (3,484 | ) |
| Reclassification of hedging loss included in cost of goods sold |  | 1,342 |  |  | — |  |  | 1,342 |  |  | 1,526 |  |  | — |  |  | 1,526 |  |
| Other comprehensive income: |  | 760 |  |  | — |  |  | 760 |  |  | 1,102 |  |  | 2,138 |  |  | 3,240 |  |
| Total comprehensive income |  | $ | 49,263 |  |  | $ | (619 | ) |  | $ | 48,644 |  |  | $ | 65,046 |  |  | $ | 1,880 |  |  | $ | 66,926 |  |

[0001628280-15-000267:notes:10]
* The adjustments included in these financial statements for the three and nine months ended December 31, 2013 primarily related to a correction to revenue that was previously recorded as an out-of-period adjustment and is now being reported in the correct period, capitalization of property, plant and equipment which was previously incorrectly expensed, pension obligation, other misstatements, and the tax impact of these adjustments.


## logi:ScheduleOfErrorCorrectionsAndPriorPeriodAdjustmentsConsolidatedStatementsOfOperationsTableTextBlock

[0001628280-15-000267:notes:11]
The following table presents the impact of the correcting adjustments on the Company’s previously reported consolidated statement of operations for the three and nine months ended December 31, 2013 (in thousands, except for per share amount):

[0001628280-15-000267:notes:12]
|  |  | Three Months EndedDecember 31, 2013 |  | Nine Months EndedDecember 31, 2013 |
|  |  | As Reported |  | Adjustments* |  | As Revised |  | As Reported |  | Adjustments* |  | As Revised |
| Net sales |  | $ | 627,890 |  |  | $ | 829 |  |  | $ | 628,719 |  |  | $ | 1,637,786 |  |  | $ | 606 |  |  | $ | 1,638,392 |  |
| Cost of goods sold |  | 414,528 |  |  | (110 | ) |  | 414,418 |  |  | 1,072,656 |  |  | (789 | ) |  | 1,071,867 |  |
| Gross profit |  | 213,362 |  |  | 939 |  |  | 214,301 |  |  | 565,130 |  |  | 1,395 |  |  | 566,525 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketing and selling |  | 93,624 |  |  | 649 |  |  | 94,273 |  |  | 287,969 |  |  | 848 |  |  | 288,817 |  |
| Research and development |  | 34,103 |  |  | 474 |  |  | 34,577 |  |  | 107,927 |  |  | 662 |  |  | 108,589 |  |
| General and administrative |  | 31,560 |  |  | 438 |  |  | 31,998 |  |  | 90,103 |  |  | 144 |  |  | 90,247 |  |
| Restructuring charges, net |  | 822 |  |  | — |  |  | 822 |  |  | 8,621 |  |  | — |  |  | 8,621 |  |
| Total operating expenses |  | 160,109 |  |  | 1,561 |  |  | 161,670 |  |  | 494,620 |  |  | 1,654 |  |  | 496,274 |  |
| Operating income |  | 53,253 |  |  | (622 | ) |  | 52,631 |  |  | 70,510 |  |  | (259 | ) |  | 70,251 |  |
| Interest expense, net |  | (1,022 | ) |  | — |  |  | (1,022 | ) |  | (862 | ) |  | — |  |  | (862 | ) |
| Other income, net |  | 1,082 |  |  | — |  |  | 1,082 |  |  | 1,361 |  |  | — |  |  | 1,361 |  |
| Income before income taxes |  | 53,313 |  |  | (622 | ) |  | 52,691 |  |  | 71,009 |  |  | (259 | ) |  | 70,750 |  |
| Provision for income taxes |  | 4,810 |  |  | (3 | ) |  | 4,807 |  |  | 7,065 |  |  | (1 | ) |  | 7,064 |  |
| Net income |  | $ | 48,503 |  |  | $ | (619 | ) |  | $ | 47,884 |  |  | $ | 63,944 |  |  | $ | (258 | ) |  | $ | 63,686 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.30 |  |  | $ | — |  |  | $ | 0.30 |  |  | $ | 0.40 |  |  | $ | — |  |  | $ | 0.40 |  |
| Diluted |  | $ | 0.30 |  |  | $ | (0.01 | ) |  | $ | 0.29 |  |  | $ | 0.40 |  |  | $ | (0.01 | ) |  | $ | 0.39 |  |
| Shares used to compute net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | 160,871 |  |  | — |  |  | 160,871 |  |  | 160,051 |  |  | — |  |  | 160,051 |  |
| Diluted |  | 163,388 |  |  | — |  |  | 163,388 |  |  | 161,509 |  |  | — |  |  | 161,509 |  |


## logi:ScheduleOfRevenueByProductFamilyExcludingInterCompanyTransactionsTableTextBlock

[0001628280-15-000267:notes:13]
Net sales by product family, excluding intercompany transactions, for the three and nine months ended December 31, 2014 and 2013 were as follows (in thousands):

[0001628280-15-000267:notes:14]
|  |  | Three Months Ended December 31, |  | Nine Months Ended December 31, |
|  |  | 2014 |  | 2013 (1) |  | 2014 |  | 2013 (1) |
| Peripherals: |  |  |  |  |  |  |  |  |  |  |  |  |
| PC Gaming |  | $ | 70,188 |  |  | $ | 58,173 |  |  | $ | 164,570 |  |  | $ | 141,645 |  |
| Tablet & Other Accessories |  | 55,100 |  |  | 77,009 |  |  | 114,973 |  |  | 150,263 |  |
| Mobile Speakers |  | 62,264 |  |  | 34,198 |  |  | 139,631 |  |  | 68,032 |  |
| Growth |  | 187,552 |  |  | 169,380 |  |  | 419,174 |  |  | 359,940 |  |
| Pointing Devices |  | 141,789 |  |  | 141,757 |  |  | 382,524 |  |  | 387,064 |  |
| PC Keyboards & Desktops |  | 114,058 |  |  | 108,682 |  |  | 325,299 |  |  | 311,955 |  |
| Audio-PC &Wearables |  | 58,696 |  |  | 69,021 |  |  | 166,999 |  |  | 195,082 |  |
| Video |  | 46,682 |  |  | 38,154 |  |  | 118,822 |  |  | 105,740 |  |
| Remotes |  | 25,116 |  |  | 26,049 |  |  | 56,224 |  |  | 53,950 |  |
| Profit Maximization |  | 386,341 |  |  | 383,663 |  |  | 1,049,868 |  |  | 1,053,791 |  |
| Other |  | 132 |  |  | 11,178 |  |  | 2,259 |  |  | 28,354 |  |
| Non-Strategic |  | 132 |  |  | 11,178 |  |  | 2,259 |  |  | 28,354 |  |
| Retail |  | 574,025 |  |  | 564,221 |  |  | 1,471,301 |  |  | 1,442,085 |  |
| OEM |  | 30,297 |  |  | 34,542 |  |  | 91,323 |  |  | 106,581 |  |
|  |  | 604,322 |  |  | 598,763 |  |  | 1,562,624 |  |  | 1,548,666 |  |
| Video conferencing |  | 29,882 |  |  | 29,956 |  |  | 84,094 |  |  | 89,726 |  |
|  |  | $ | 634,204 |  |  | $ | 628,719 |  |  | $ | 1,646,718 |  |  | $ | 1,638,392 |  |

[0001628280-15-000267:notes:15]
(1)   Certain products within the retail product families presented in prior years have been reclassified to conform to the current year presentation.


## us-gaap:AccountingChangesAndErrorCorrectionsTextBlock

[0001628280-15-000267:notes:16]
Revision of Previously Issued Financial Statements

[0001628280-15-000267:notes:17]
As disclosed in the Company’s Annual Report on Form 10-K for the year ended March 31, 2014 and in the audited consolidated financial statements contained therein, the Company has restated and revised its financial statements for the fiscal years ended March 31, 2012 and 2013, respectively. The impact of the adjustments also immaterially impact the financial statements for the first three quarters of the fiscal year ended March 31, 2014 as previously included in the Company’s quarterly reports on Form 10-Q for Fiscal 2014. The financial statements for the three and nine months ended December 31, 2013 included in this Form 10-Q are revised as described below for those adjustments and should be read in conjunction with Item 8, “Financial Statements and Supplementary Data” disclosed in the Company’s Annual Report on Form 10-K for the fiscal year ended March 31, 2014, filed with the SEC on November 13, 2014.

[0001628280-15-000267:notes:18]
The adjustments included in these financial statements for the three and nine months ended December 31, 2013 primarily related to a correction to revenue that was previously recorded as an out-of-period adjustment and is now being reported in the correct period, capitalization of property, plant and equipment which was previously incorrectly expensed, pension obligation, other misstatements, and the tax impact of these adjustments.

[0001628280-15-000267:notes:19]
Consolidated Statements of Operations.

[0001628280-15-000267:notes:20]
Consolidated Statements of Comprehensive Income

[0001628280-15-000267:notes:21]
Consolidated Statement of Cash Flows


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001628280-15-000267:notes:22]
Summary of Significant Accounting Policies

[0001628280-15-000267:notes:23]
[same as prior period, unchanged from 0001104659-14-083669:notes:23]

[0001628280-15-000267:notes:24]
The consolidated interim financial statements include the accounts of Logitech and its subsidiaries. All intercompany balances and transactions have been eliminated. The consolidated financial statements are presented in accordance with accounting principles generally accepted in the United States of America (“GAAP”) for interim financial information and therefore do not include all the information required by GAAP for complete financial statements. They should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended March 31, 2014, included in its Annual Report on Form 10-K filed with the Securities and Exchange Commission (“SEC”) on November 13, 2014.  In the opinion of management, these consolidated financial statements include all adjustments, consisting of normal recurring adjustments, necessary for a fair statement of the results for the periods presented. Operating results for the three and nine months ended December 31, 2014 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2015, or any future periods.

[0001628280-15-000267:notes:25]
[same as prior period, unchanged from 0001104659-14-083669:notes:25]

[0001628280-15-000267:notes:26]
The Company’s fiscal year ends on March 31. Interim quarters are thirteen week periods, each ending on last Friday of the quarters.  For purposes of presentation, the Company has indicated its quarterly periods as ending on the quarter end.

[0001628280-15-000267:notes:27]
[same as prior period, unchanged from 0001104659-14-083669:notes:27]

[0001628280-15-000267:notes:28]
There have been no substantial changes in the Company’s significant accounting policies during the nine months ended December 31, 2014 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2014.

[0001628280-15-000267:notes:29]
[same as prior period, unchanged from 0001104659-14-083669:notes:29]

[0001628280-15-000267:notes:30]
[same as prior period, unchanged from 0001104659-14-083669:notes:30]

[0001628280-15-000267:notes:31]
[same as prior period, unchanged from 0001104659-14-083669:notes:31]

[0001628280-15-000267:notes:32]
In May 2014, the FASB issued Accounting Standards Update No. 2014-09, “Revenue from Contracts with Customers (Topic 606),” (“ASU 2014-09”). ASU 2014-09 outlines a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. This new revenue recognition model provides a five-step analysis in determining when and how revenue is recognized. The new model will require revenue recognition to depict the transfer of promised goods or services to customers in an amount that reflects the consideration a company expects to receive in exchange for those goods or services. The new standard will be effective for the Company beginning April 1, 2017.  Early application is prohibited.  The Company is currently evaluating the impact that adopting this new guidance will have on its consolidated financial statements.

[0001628280-15-000267:notes:33]
In November 2014, the FASB issued Accounting Standards Update No. 2014-17, "Business Combinations (Topic 805): Pushdown Accounting (a consensus of the FASB Emerging Issues Task Force)" ("ASU 2014-17"). ASU 2014-17 provides an acquired entity with an option to apply pushdown accounting in its separate financial statements upon occurrence of an event in which an acquirer obtains control of the acquired entity. An acquired entity may elect the option to apply pushdown accounting in the reporting period in which the change-in-control event occurs. The new standard is effective on November 18, 2014.  Early application is prohibited.  After the effective date, an acquired entity can make an election to apply the guidance to

[0001628280-15-000267:notes:34]
future change-in-control events or to its most recent change-in-control event. However, if the financial statements for the period in which the most recent change-in-control event occurred already have been issued or made available to be issued, the application of this guidance would be a change in accounting principle. The Company has adopted this new guidance and there's no impact on its consolidated financial statements.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-15-000267:notes:35]
Commitments and Contingencies

[0001628280-15-000267:notes:36]
Product Warranties

[0001628280-15-000267:notes:37]
All of the Company’s peripherals products are covered by warranty to be free from defects in material and workmanship for periods ranging from one year to five years. At the time of sale, the Company accrues a warranty liability for estimated costs to provide products, parts or services to repair or replace products in satisfaction of the warranty obligation. The Company’s estimate of costs to fulfill its warranty obligations is based on historical experience and expectations of future conditions. When the Company experiences changes in warranty claim activity or costs associated with fulfilling those claims, the warranty liability is adjusted accordingly.

[0001628280-15-000267:notes:38]
Changes in the Company’s warranty liability for the three and nine months ended December 31, 2014 and 2013 were as follows (in thousands):

[0001628280-15-000267:notes:39]
|  |  | Three Months Ended December 31, |  | Nine Months Ended December 31, |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Beginning of the period |  | $ | 22,204 |  |  | $ | 23,021 |  |  | $ | 24,380 |  |  | $ | 21,442 |  |
| Provision |  | 2,381 |  |  | 4,343 |  |  | 6,607 |  |  | 11,532 |  |
| Settlements |  | (2,493 | ) |  | (3,842 | ) |  | (8,895 | ) |  | (11,779 | ) |
| Adjustment (1) |  | — |  |  | — |  |  | — |  |  | 2,327 |  |
| End of the period |  | $ | 22,092 |  |  | $ | 23,522 |  |  | $ | 22,092 |  |  | $ | 23,522 |  |

[0001628280-15-000267:notes:40]
(1)   During the nine month period December 31, 2013, the warranty liability allocated to the Company’s - Remotes product category was reclassified from liabilities held for sale.

[0001628280-15-000267:notes:41]
Purchase Commitments

[0001628280-15-000267:notes:42]
Commitments for inventory purchases are made in the normal course of business to original design manufacturers, contract manufacturers and other suppliers and are expected to be fulfilled by December 31, 2014. Fixed purchase commitments for capital expenditures primarily related to commitments for computer hardware and leasehold improvements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the Company the option to reschedule and adjust its requirements based on the business needs prior to delivery of goods or performance of services.

[0001628280-15-000267:notes:43]
Other Contingencies

[0001628280-15-000267:notes:44]
The Company is subject to an ongoing formal investigation by the SEC, relating to certain issues including the accounting for Revue inventory valuation reserves that resulted in the restatement described in the Fiscal 2014 Form 10-K, revision to the Company’s financial statements concerning warranty accruals and amortization of intangible assets presented in the Company’s Form 10-K/A, filed on August 7, 2013, and the Company’s transactions with a distributor for Fiscal Year 2007 through Fiscal Year 2009. The Company is cooperating with the SEC in its ongoing investigation. The Company has entered into an agreement with the SEC to extend the statute of limitations. The Company cannot predict the outcome of the investigation at this time and any potential fines or penalties, if any, that may arise from the investigation are currently not estimable.

[0001628280-15-000267:notes:45]
Guarantees

[0001628280-15-000267:notes:46]
Logitech Europe S.A.  guaranteed payments of a third-party contract manufacturer’s purchase obligations. As of December 31, 2014, the maximum amount of this guarantee was $3.5 million, of which $1.4 million of guaranteed purchase obligations were outstanding.

[0001628280-15-000267:notes:47]
Indemnifications

[0001628280-15-000267:notes:48]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of December 31, 2014, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

[0001628280-15-000267:notes:49]
The Company also indemnifies its current and former directors and certain of its current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. The Company is unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not limited, the obligations are conditional in nature and the facts and circumstances involved in any situation that might arise are variable.

[0001628280-15-000267:notes:50]
Legal Proceedings

[0001628280-15-000267:notes:51]
From time to time the Company is involved in claims and legal proceedings that arise in the ordinary course of its business. The Company is currently subject to several such claims and a small number of legal proceedings. The Company believes that these matters lack merit and intends to vigorously defend against them. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company’s defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company’s business, financial condition, cash flows and results of operations in a particular period. Any claims or proceedings against the Company, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company’s business.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001628280-15-000267:notes:52]
Employee Benefit Plans

[0001628280-15-000267:notes:53]
[same as prior period, unchanged from 0001104659-14-083669:notes:51]

[0001628280-15-000267:notes:54]
As of December 31, 2014, the Company offers the 2006 ESPP (2006 Employee Share Purchase Plan (Non-U.S.)), the 1996 ESPP (1996 Employee Share Purchase Plan (U.S.)), the 2006 Plan (2006 Stock Incentive Plan) and the 2012 Plan (2012 Stock Inducement Equity Plan). Please refer to our fiscal year 2014 Form 10-K for additional information regarding the Employee Share Purchase Plans and Stock Incentive Plans.

[0001628280-15-000267:notes:55]
The Company was not current with its periodic reports required to be filed with the SEC and was therefore unable to issue any shares under its Registration Statements on Form S-8 from July 31, 2014 to November 26, 2014. Given the proximity of the unavailability of those registration statements and the end of the then-current ESPP offering period, also on July 31, 2014, the Compensation Committee authorized the termination of the then-current ESPP offering period and a one-time payment to each participant in an amount equal to the fifteen percent (15%) discount at which shares would otherwise have been repurchased pursuant to the then-current period of the ESPPs. This one-time payment was accounted for as a repurchase of equity awards that reduced additional paid in capital, resulting in no additional compensation cost. No new ESPP offering periods were initiated during the three months ended December 31, 2014.

[0001628280-15-000267:notes:56]
The following table summarizes the share-based compensation expense and related tax benefit recognized for the three and nine months ended December 31, 2014 and 2013 (in thousands):

[0001628280-15-000267:notes:57]
|  |  | Three Months Ended December 31, |  | Nine Months Ended December 31, |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Cost of goods sold |  | $ | 560 |  |  | $ | 672 |  |  | $ | 1,724 |  |  | $ | 1,843 |  |
| Marketing and selling |  | 2,786 |  |  | 3,057 |  |  | 6,995 |  |  | 5,980 |  |
| Research and development |  | 1,066 |  |  | 1,906 |  |  | 2,462 |  |  | 3,840 |  |
| General and administrative |  | 2,635 |  |  | 3,278 |  |  | 8,865 |  |  | 5,749 |  |
| Total share-based compensation expense |  | 7,047 |  |  | 8,913 |  |  | 20,046 |  |  | 17,412 |  |
| Income tax benefit |  | (1,623 | ) |  | (168 | ) |  | (4,720 | ) |  | (2,343 | ) |
| Total share-based compensation expense, net of income tax |  | $ | 5,424 |  |  | $ | 8,745 |  |  | $ | 15,326 |  |  | $ | 15,069 |  |

[0001628280-15-000267:notes:58]
During the three months ended December 31, 2014 and 2013, the Company capitalized $0.6 million and $0.5 million of stock-based compensation expenses as inventory, respectively.

[0001628280-15-000267:notes:59]
[same as prior period, unchanged from 0001104659-14-083669:notes:57]

[0001628280-15-000267:notes:60]
Certain of the Company’s subsidiaries have defined contribution employee benefit plans covering all or a portion of their employees. Contributions to these plans are discretionary for certain plans and are based on specified or statutory requirements for others. The charges to expense for these plans for the three months ended December 31, 2014 and 2013 were $1.6 million and $1.4 million, and for the nine months ended December 31, 2014 and 2013 were $4.3 million and $4.7 million, respectively.

[0001628280-15-000267:notes:61]
[same as prior period, unchanged from 0001104659-14-083669:notes:59]

[0001628280-15-000267:notes:62]
Certain of the Company’s subsidiaries sponsor defined benefit pension plans or non-retirement post-employment benefits covering substantially all of their employees. Benefits are provided based on employees’ years of service and earnings, or in accordance with applicable employee benefit regulations. The Company’s practice is to fund amounts sufficient to meet the requirements set forth in the applicable employee benefit and tax regulations. The cost recorded of $1.8 million and $2.4 million for the three months ended December 31, 2014 and 2013 and $5.7 million and $7.6 million for the nine months ended December 31, 2014 and 2013 was primarily related to service costs.


## us-gaap:DebtDisclosureTextBlock

[0001628280-15-000267:notes:63]
Financing Arrangements

[0001628280-15-000267:notes:64]
The Company had several uncommitted, unsecured bank lines of credit aggregating $38.7 million as of December 31, 2014. There are no financial covenants under these lines of credit with which the Company must comply. As of December 31, 2014, the Company had outstanding bank guarantees of $7.5 million under these lines of credit.


## us-gaap:EarningsPerShareTextBlock

[0001628280-15-000267:notes:65]
Net Income per Share

[0001628280-15-000267:notes:66]
[same as prior period, unchanged from 0001104659-14-083669:notes:64]

[0001628280-15-000267:notes:67]
|  |  | Three Months Ended December 31, |  | Nine Months Ended December 31, |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Net income |  | $ | 62,784 |  |  | $ | 47,884 |  |  | $ | 118,550 |  |  | $ | 63,686 |  |
| Shares used in net income per share computation: |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding - basic |  | 163,533 |  |  | 160,871 |  |  | 163,261 |  |  | 160,051 |  |
| Effect of potentially dilutive equivalent shares |  | 2,788 |  |  | 2,517 |  |  | 2,815 |  |  | 1,458 |  |
| Weighted average shares outstanding - diluted |  | 166,321 |  |  | 163,388 |  |  | 166,076 |  |  | 161,509 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.38 |  |  | $ | 0.30 |  |  | $ | 0.73 |  |  | $ | 0.40 |  |
| Diluted |  | $ | 0.38 |  |  | $ | 0.29 |  |  | $ | 0.71 |  |  | $ | 0.39 |  |

[0001628280-15-000267:notes:68]
Share equivalents attributable to outstanding stock options and RSUs of 8,079,134 and 11,080,000 for the three months ended December 31, 2014 and 2013 and 8,079,134 and 15,874,000 for the nine months ended December 31, 2014 and 2013 were excluded from the calculation of diluted net income per share because to do so would have been anti-dilutive for the periods indicated.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001628280-15-000267:notes:69]
[same as prior period, unchanged from 0001104659-14-083669:notes:68]

[0001628280-15-000267:notes:70]
[same as prior period, unchanged from 0001104659-14-083669:notes:69]

[0001628280-15-000267:notes:71]
•Level 1 — Quoted prices in active markets for identical assets or liabilities.

[0001628280-15-000267:notes:72]
•Level 2 — Observable inputs other than quoted market prices included in Level 1, such as quoted prices for similar assets and liabilities in active markets; quoted prices for identical or similar assets and liabilities in markets that are not active; or other inputs that are observable or can be corroborated by observable market data.

[0001628280-15-000267:notes:73]
•Level 3 — Unobservable inputs that are supported by little or no market activity and that are significant to the fair value of the assets or liabilities. This includes certain pricing models, discounted cash flow methodologies and similar techniques that use significant unobservable inputs.

[0001628280-15-000267:notes:74]
[same as prior period, unchanged from 0001104659-14-083669:notes:73]

[0001628280-15-000267:notes:75]
|  |  | December 31, 2014 |  | March 31, 2014 |
|  |  | Level 1 |  | Level 2 |  | Level 1 |  | Level 2 |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 274,552 |  |  | $ | — |  |  | $ | 200,641 |  |  | $ | — |  |
|  |  | $ | 274,552 |  |  | — |  |  | $ | 200,641 |  |  | $ | — |  |
| Trading investments for deferred compensation plan: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 2,981 |  |  | — |  |  | $ | 3,139 |  |  | $ | — |  |
| Mutual funds |  | 14,502 |  |  | — |  |  | 13,472 |  |  | — |  |
|  |  | $ | 17,483 |  |  | — |  |  | $ | 16,611 |  |  | $ | — |  |
| Foreign exchange derivative assets |  | $ | — |  |  | $ | 697 |  |  | $ | — |  |  | $ | 155 |  |
| Foreign exchange derivative liabilities |  | $ | — |  |  | $ | 38 |  |  | $ | — |  |  | $ | 701 |  |

[0001628280-15-000267:notes:76]
There were no significant Level 3 financial assets as of December 31, 2014 or March 31, 2014.

[0001628280-15-000267:notes:77]
[same as prior period, unchanged from 0001104659-14-083669:notes:76]

[0001628280-15-000267:notes:78]
[same as prior period, unchanged from 0001104659-14-083669:notes:77]

[0001628280-15-000267:notes:79]
[same as prior period, unchanged from 0001104659-14-083669:notes:78]

[0001628280-15-000267:notes:80]
The Company’s investment securities portfolio consists of marketable securities (money market and mutual funds) related to a deferred compensation plan at December 31, 2014 and March 31, 2014.

[0001628280-15-000267:notes:81]
The marketable securities related to the deferred compensation plan are classified as non-current assets. Since participants in the deferred compensation plan may select the mutual funds in which their compensation deferrals are invested within the confines of the Rabbi Trust, which holds the marketable securities, the Company has designated these marketable securities as trading investments, although there is no intent to actively buy and sell securities within the objective of generating profits on short-term difference in market prices. Management has classified the investments as non-current assets because final sale of the investments or realization of proceeds by plan participants is not expected within the Company’s normal operating cycle of one year. The marketable securities are recorded at a fair value of $17.5 million and $16.6 million as of December 31, 2014 and March 31, 2014, respectively, based on quoted market prices. Quoted market prices are observable inputs that are classified as Level 1 securities. Earnings, gains and losses on trading investments are included in other income (expense), net.

[0001628280-15-000267:notes:82]
[same as prior period, unchanged from 0001104659-14-083669:notes:81]

[0001628280-15-000267:notes:83]
Under the agreements with the respective counterparties to the Company’s derivative contracts, subject to applicable requirements, the Company does not net settle transactions with any single net amount payable by one party to the other. In accordance with ASU 2011-11, the Company presents its derivative instruments at gross fair values in the Consolidated Balance Sheets as of December 31, 2014 and March 31, 2014.

[0001628280-15-000267:notes:84]
The following table presents the fair values of the Company’s derivative instruments and their accounting line presentation on its Consolidated Balance Sheets as of December 31, 2014 and March 31, 2014 (in thousands):

[0001628280-15-000267:notes:85]
|  |  | Derivatives |
|  |  | Asset |  | Liability |
|  |  | December 31,2014 |  | March 31,2014 |  | December 31,2014 |  | March 31,2014 |
| Designed as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash flow hedges |  | $ | 693 |  |  | $ | 4 |  |  | $ | — |  |  | $ | 243 |  |
| Not designed as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | 4 |  |  | 151 |  |  | 38 |  |  | 458 |  |
|  |  | $ | 697 |  |  | $ | 155 |  |  | $ | 38 |  |  | $ | 701 |  |

[0001628280-15-000267:notes:86]
The following table presents the amounts of gains and losses on the Company’s derivative instruments for the three and nine months ended December 31, 2014 and 2013 (in thousands):

[0001628280-15-000267:notes:87]
|  |  | Three Months Ended December 31, |
|  |  | Net Amount ofGain (Loss) Deferred as aComponent of AccumulatedOther Comprehensive Income |  | Amount of Loss (Gain)Reclassified from AccumulatedOther Comprehensive Income toCosts of Goods Sold |  | Amount of Gain (Loss)Immediately Recognized inOther Income (Expense), Net |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Designed as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash flow hedges |  | $ | (739 | ) |  | $ | 144 |  |  | $ | (2,025 | ) |  | $ | 1,342 |  |  | $ | 36 |  |  | $ | 8 |  |
| Not designed as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | — |  |  | — |  |  | — |  |  | — |  |  | 1,585 |  |  | 899 |  |
|  |  | $ | (739 | ) |  | $ | 144 |  |  | $ | (2,025 | ) |  | $ | 1,342 |  |  | $ | 1,621 |  |  | $ | 907 |  |

[0001628280-15-000267:notes:88]
|  |  | Nine Months Ended December 31, |
|  |  | Net Amount ofGain (Loss) Deferred as aComponent of AccumulatedOther Comprehensive Income |  | Amount of Loss (Gain)Reclassified from AccumulatedOther Comprehensive Income toCosts of Goods Sold |  | Amount of Gain (Loss)Immediately Recognized inOther Income (Expense), Net |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Designed as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash flow hedges |  | $ | 3,198 |  |  | $ | (1,958 | ) |  | $ | (1,840 | ) |  | $ | 1,526 |  |  | $ | (20 | ) |  | $ | 54 |  |
| Not designed as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | — |  |  | — |  |  | — |  |  | — |  |  | 1,908 |  |  | 1,807 |  |
|  |  | $ | 3,198 |  |  | $ | (1,958 | ) |  | $ | (1,840 | ) |  | $ | 1,526 |  |  | $ | 1,888 |  |  | $ | 1,861 |  |

[0001628280-15-000267:notes:89]
[same as prior period, unchanged from 0001104659-14-083669:notes:88]

[0001628280-15-000267:notes:90]
The Company enters into foreign exchange forward contracts to hedge against exposure to changes in foreign currency exchange rates related to its subsidiaries’ forecasted inventory purchases. The Company has one entity with a euro functional currency that purchases inventory in U.S. dollars. The primary risk managed by using derivative instruments is the foreign currency exchange rate risk. The Company has designated these derivatives as cash flow hedges. The Company does not use derivative financial instruments for trading or speculative purposes. These hedging contracts mature within four months, and are denominated in the same currency as the underlying transactions. Gains and losses in the fair value of the effective portion of the hedges are deferred as a component of accumulated other comprehensive loss until the hedged inventory purchases are sold, at which time the gains or losses are reclassified to cost of goods sold. The Company assesses the effectiveness of the hedges by comparing changes in the spot rate of the currency underlying the forward contract with changes in the spot rate of the currency in which the forecasted transaction will be consummated. If the underlying transaction being hedged fails to occur or if a portion of the hedge does not generate offsetting changes in the foreign currency exposure of forecasted inventory purchases, the Company immediately recognizes the gain or loss on the associated financial instrument in other income (expense). Such gains and losses were immaterial during the three and nine months ended December 31, 2014 and 2013. Cash flows from such hedges are classified as operating activities in the consolidated statements of cash flows. The notional amounts of foreign exchange forward contracts outstanding related to forecasted inventory purchases were $41.4 million (€33.9 million) and $51.8 million (€37.6 million) at December 31, 2014 and March 31, 2014. The notional amount represents the future cash flows under contracts to purchase foreign currencies.

[0001628280-15-000267:notes:91]
[same as prior period, unchanged from 0001104659-14-083669:notes:90]

[0001628280-15-000267:notes:92]
The Company also enters into foreign exchange forward and swap contracts to reduce the short-term effects of foreign currency fluctuations on certain foreign currency receivables or payables. These contracts generally have one month maturity. The primary risk managed by using forward and swap contracts is the foreign currency exchange rate risk. The gains or losses on foreign exchange contracts are recognized in other income (expense), net based on the changes in fair value.

[0001628280-15-000267:notes:93]
The notional amounts of foreign exchange contracts outstanding as of December 31 and March 31, 2014 relating to foreign currency receivables or payables were $42.7 million and $53.6 million, respectively. The contracts outstanding at December 31, 2014 and March 31, 2014 consisted of contracts in Mexican pesos, Japanese yen, British pounds, Taiwanese dollars and Australian dollars.

[0001628280-15-000267:notes:94]
[same as prior period, unchanged from 0001104659-14-083669:notes:93]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001628280-15-000267:notes:95]
Goodwill and Other Intangible Assets

[0001628280-15-000267:notes:96]
The Company conducts a goodwill impairment analysis annually at December 31 or more frequently if indicators of impairment exist or if a decision is made to sell or exit a business. A significant amount of judgment is involved in determining if an indicator of impairment has occurred. Such indicators may include deterioration in general economic conditions, negative developments in equity and credit markets, adverse changes in the markets in which an entity operates, increases in input costs that have a negative effect on earnings and cash flows, or a trend of negative or declining cash flows over multiple periods, among others. The fair value that could be realized in an actual transaction may differ from that used to evaluate the impairment of goodwill.

[0001628280-15-000267:notes:97]
In reviewing goodwill for impairment, an entity has the option to first assess qualitative factors to determine whether the existence of events or circumstances leads to a determination that it is more likely than not (greater than 50%) that the estimated fair value of a reporting unit is less than its carrying amount. If an entity elects to perform a qualitative assessment and determines that an impairment is more likely than not, the entity is then required to perform the two-step quantitative impairment test, otherwise no further analysis is required. An entity also may elect not to perform the qualitative assessment and, instead, proceed directly to the two-step quantitative impairment test. The ultimate outcome of the goodwill impairment review for a reporting unit should be the same whether an entity chooses to perform the qualitative assessment or proceeds directly to the two-step quantitative impairment test.

[0001628280-15-000267:notes:98]
Goodwill is allocated among and evaluated for impairment at the reporting unit level, which is defined as an operating segment or one level below an operating segment. The Company has two reporting units, Peripherals and Video Conferencing.

[0001628280-15-000267:notes:99]
Peripherals

[0001628280-15-000267:notes:100]
The Company performed its annual impairment analysis of the goodwill for its peripherals reporting unit at December 31, 2014 by performing a qualitative assessment and concluded that it was more likely than not that the fair value of its peripherals reporting unit exceeded its carrying amount.  In assessing the qualitative factors, the Company considered the impact of these key factors: change in industry and competitive environment, growth in market capitalization of $2.3 billion as of December 31, 2014 from $2.2 billion a year ago, and budgeted-to-actual revenue performance from prior year. The peripherals reporting unit has seen an improvement in operating income from $64.8 million and $117.8 million for the three and nine months ended December 31, 2013 to $76.1 million and $160.3 million for three and nine months ended December 31, 2014, respectively.

[0001628280-15-000267:notes:101]
Video Conferencing

[0001628280-15-000267:notes:102]
The Company proceeded directly to the two-step quantitative impairment test for the video conferencing reporting unit and performed Step 1 assessment at December 31, 2014. The Company used a market approach and income approach (discounted cash flow model) to estimate the current fair value of the video conferencing reporting unit when testing for impairment. A number of significant assumptions and estimates are involved in the application of the market approach and income approach.

[0001628280-15-000267:notes:103]
The market approach utilizes the identification of comparable companies and applying certain revenue multiples or earnings multiples of these comparable companies to the respective revenue and earnings metrics of the reporting unit.

[0001628280-15-000267:notes:104]
The income approach utilizes forecasted operating cash flows, which includes certain assumptions and estimates related to markets and market share, sales volumes and prices, production costs, tax rates, capital spending, discount rate, and working capital changes. Cash flow forecasts are based on approved business unit operating plans. The Company uses a third party valuation expert in the development of our market and income approach models.

[0001628280-15-000267:notes:105]
Key assumptions used in the Step 1 income approach analysis included , the estimated compound annual growth rate (“CAGR”) during the forecast period, use of the appropriate discount rate, and long-term growth rates for purposes of determining a terminal value at the end of the discrete forecast period. A sensitivity assessment of key assumptions for the video conferencing reporting unit Step 1 test is presented below:

[0001628280-15-000267:notes:106]
• CAGR assumption was 6.9% through fiscal year 2022, with a flat forecast in the remainder of fiscal year 2015, and higher growth rates from fiscal years 2016 through 2020, reducing to a growth rate of 4.0% in fiscal year 2022. The forecasted growth contrasts with the recent performance of the video conferencing reporting unit, when the Company experienced a decline in revenue (see Note 13 for further details). The video conferencing reporting unit is in the process of transitioning its product portfolio to the recently announced Lifesize Cloud, a software-as-a-service (SaaS) offering. Sales of Lifesize Cloud are growing rapidly, offsetting a shift from it's on-premise infrastructure products.  Video systems sales are growing and are expected to continue growing as an integral part of the full Lifesize solution. The Company has been investing in the Lifesize Cloud within video conferencing reporting unit. If the CAGR rate were decreased to 2.3%, holding all other assumptions constant, the fair value of the video conferencing reporting unit would decrease, under income approach, to below its carrying value.

[0001628280-15-000267:notes:107]
•Discount rate assumption was 14.0%. If the discount rate were increased to 17.0%, holding all other assumptions constant, it would result in fair value of the video conferencing reporting unit decrease to below its carrying value under income approach.

[0001628280-15-000267:notes:108]
•Terminal growth rate assumption was 4.0%. If the terminal growth rate were decreased to (2.2)%, holding all other assumptions constant, it would result in fair value of the video conferencing reporting unit decrease to below its carrying value under income approach.

[0001628280-15-000267:notes:109]
The assumptions used also included a reduction in future operating expenses as a percentage of revenue, driven by increases in forecasted revenue as described above, combined with reduced operating expenses related to cost cutting initiatives.

[0001628280-15-000267:notes:110]
The annual Step 1 assessment resulted in the Company determining that the video conferencing reporting unit passed the Step 1 test because the estimated fair value of video conferencing reporting unit from Step 1 assessment exceeded its carrying value by approximately 38.0%, thus not requiring a Step 2 assessment of this reporting unit. This result presents a future video conferencing reporting unit goodwill impairment risk to the Company since the margin it cleared the current Step 1 assessment was not significant.

[0001628280-15-000267:notes:111]
In the event the estimated fair value of a reporting unit is less than the carrying value, additional analysis would be required. The additional analysis would compare the carrying amount of the reporting unit's goodwill with the implied fair value of that goodwill, which may involve the use of valuation experts. The implied fair value of goodwill is the excess of the fair value of the reporting unit over the fair value amounts assigned to all of the assets and liabilities of that unit as if the reporting unit was acquired in a business combination and the fair value of the reporting unit represented the purchase price. If the carrying value of goodwill exceeds its implied fair value, an impairment loss equal to such excess would be recognized, which could significantly and adversely impact reported results of operations and shareholders' equity.

[0001628280-15-000267:notes:112]
Determining the fair value of a reporting unit is judgmental in nature and requires the use of significant estimates and assumptions, including revenue growth rates, operating margins, discount rates and future market conditions, among others. It is reasonably possible that changes in the judgments, assumptions and estimates that the Company used in assessing the fair value of the video conferencing reporting unit result in the goodwill to become impaired. A goodwill impairment charge would have the effect of decreasing the Company’s earnings or increasing its losses in such period. If the Company is required to take a substantial impairment charge, its operating results would be materially and adversely affected in such period.

[0001628280-15-000267:notes:113]
As a result of the Company’s annual goodwill impairment assessments, there was no impairment of goodwill as of December 31, 2014.

[0001628280-15-000267:notes:114]
The following table summarizes the activity in the Company’s goodwill balance during the nine months ended December 31, 2014 (in thousands):

[0001628280-15-000267:notes:115]
|  |  | December 31, 2014 |
|  |  |  |  | Video |  |  |
|  |  | Peripherals |  | Conferencing |  | Total |
| Beginning of the period |  | $ | 219,415 |  |  | $ | 125,595 |  |  | $ | 345,010 |  |
| Foreign currency impact |  | — |  |  | (1,573 | ) |  | (1,573 | ) |
| End of the period |  | $ | 219,415 |  |  | $ | 124,022 |  |  | $ | 343,437 |  |

[0001628280-15-000267:notes:116]
Amortization expense for other intangible assets was $2.3 million and $4.5 million for the three months ended December 31, 2014 and 2013, respectively, and $7.6 million and $15.0 million for the nine months ended December 31, 2014 and 2013, respectively. The Company expects that amortization expense for the remaining three months of fiscal year 2015 will be $0.7 million, and annual amortization expense for fiscal years 2016 and 2017 will be $1.8 million and $0.2 million, respectively.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-15-000267:notes:117]
Income Taxes

[0001628280-15-000267:notes:118]
[same as prior period, unchanged from 0001104659-14-083669:notes:104]

[0001628280-15-000267:notes:119]
The income tax benefit for the three months ended December 31, 2014 was $0.9 million based on an effective income tax rate of (1.4)% of pre-tax income, compared to an income tax provision of $4.8 million based on an effective income tax rate of 9.1% of pre-tax income for the three months ended December 31, 2013. The income tax provision for the nine months ended December 31, 2014 was $7.7 million based on an effective income tax rate of 6.1% of pre-tax income, compared to an income tax provision of $7.1 million based on an effective income tax rate of 10.0% of pre-tax income for the nine months ended December 31, 2013.  The change in the effective income tax rate for the three and nine months ended December 31, 2014, compared to the three and nine months ended December 31, 2013, was primarily due to the mix of income and losses in the various tax jurisdictions in which the Company operates. There was a discrete tax benefit of $9.0 million and $11.1 million in the three and nine months ended December 31, 2014, respectively, from the reversal of uncertain tax positions resulting from expiration of the statutes of limitations.   In the three and nine months ended December 31, 2013, the discrete tax benefit from the reversal of uncertain tax positions resulting from expiration of the statutes of limitations was $10.0 million and $12.0 million, respectively.

[0001628280-15-000267:notes:120]
On December 19, 2014, the enactment in the U.S. of the Tax Increase Prevention Act of 2014 extended the U.S. federal research and development tax credit through December 31, 2014 which had previously expired on December 31, 2013.  The income tax benefit and income tax provision in the three and nine months ended December 31, 2014 reflected a $0.8 million tax benefit, respectively, as a result of the extension of the tax credit.

[0001628280-15-000267:notes:121]
As of December 31 and March 31, 2014, the total amount of unrecognized tax benefits due to uncertain tax positions was $85.1 million and $91.0 million, respectively, of which $83.9 million and $86.1 million would affect the effective income tax rate if recognized.

[0001628280-15-000267:notes:122]
As of December 31, 2014, the Company had $79.4 million in non-current income taxes payable and $0.1 million in current income taxes payable, including interest and penalties, related to our income tax liability for uncertain tax positions. As of March 31, 2014, the Company had $93.1 million in non-current income taxes payable and $0.3 million in current income taxes payable.  Pursuant to ASU 2013-11, which became effective in the first quarter of fiscal year 2015, the Company reclassified $9.8 million of unrecognized tax benefits previously presented as non-current income taxes payable as a reduction to non-current deferred tax assets for tax credit carryforwards.

[0001628280-15-000267:notes:123]
The Company continues to recognize interest and penalties related to unrecognized tax positions in income tax expense. As of December 31 and March 31, 2014, the Company had $5.2 million and $5.6 million of accrued interest and penalties related to uncertain tax positions, respectively.

[0001628280-15-000267:notes:124]
Although the Company has adequately provided for uncertain tax positions, the provisions on these positions may change as revised estimates are made or the underlying matters are settled or otherwise resolved. During fiscal year 2015, the Company will continue to review its tax positions and provide for or reverse unrecognized tax benefits as issues arise. During the next 12 months, it is reasonably possible that the amount of unrecognized tax benefits could increase or decrease significantly due to changes in tax law in various jurisdictions, new tax audits and changes in the U.S. dollar as compared to foreign currencies. Excluding these factors, uncertain tax positions may decrease by as much as $16.0 million from the lapse of the statutes of limitations in various jurisdictions during the next 12 months.


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0001628280-15-000267:notes:125]
[same as prior period, unchanged from 0001104659-14-083669:notes:110]

[0001628280-15-000267:notes:126]
|  |  | December 31,2014 |  | March 31,2014 |
| Americas |  | $ | 47,510 |  |  | $ | 45,166 |  |
| EMEA |  | 3,742 |  |  | 5,154 |  |
| Asia Pacific |  | 39,525 |  |  | 38,071 |  |
|  |  | $ | 90,777 |  |  | $ | 88,391 |  |


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001628280-15-000267:notes:127]
Net sales to unaffiliated customers by geographic region (based on the customers’ location) for the three and nine months ended December 31, 2014 and 2013 were as follows (in thousands):

[0001628280-15-000267:notes:128]
|  |  | Three Months Ended December 31, |  | Nine Months Ended December 31, |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Americas |  | $ | 280,652 |  |  | $ | 258,682 |  |  | $ | 718,274 |  |  | $ | 662,122 |  |
| EMEA |  | 221,043 |  |  | 238,972 |  |  | 564,314 |  |  | 596,719 |  |
| Asia Pacific |  | 132,509 |  |  | 131,065 |  |  | 364,130 |  |  | 379,551 |  |
| Total net sales |  | $ | 634,204 |  |  | $ | 628,719 |  |  | $ | 1,646,718 |  |  | $ | 1,638,392 |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001628280-15-000267:notes:129]
[same as prior period, unchanged from 0001104659-14-083669:notes:114]

[0001628280-15-000267:notes:130]
|  |  | Accumulated Other Comprehensive Income (Loss) |
|  |  | Cumulative |  | Defined |  | Deferred |  |  |
|  |  | TranslationAdjustment |  | BenefitPlan (1) |  | HedgingGains (Losses) |  | Total |
| March 31, 2014 |  | $ | (70,999 | ) |  | $ | (14,288 | ) |  | $ | (515 | ) |  | $ | (85,802 | ) |
| Other comprehensive income (loss) |  | (8,051 | ) |  | 1,799 |  |  | 3,198 |  |  | (3,054 | ) |
| December 31, 2014 |  | $ | (79,050 | ) |  | $ | (12,489 | ) |  | $ | 2,683 |  |  | $ | (88,856 | ) |

[0001628280-15-000267:notes:131]
(1)        Net of tax of $192 as of both December 31, 2014 and March 31, 2014.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001628280-15-000267:notes:132]
Net sales and operating income (loss) for the Company’s operating segments for the three and nine months ended December 31, 2014 and 2013 were as follows (in thousands):

[0001628280-15-000267:notes:133]
|  |  | Three Months Ended December 31, |  | Nine Months Ended December 31, |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Net sales: |  |  |  |  |  |  |  |  |  |  |  |  |
| Peripherals |  | $ | 604,322 |  |  | $ | 598,763 |  |  | $ | 1,562,624 |  |  | $ | 1,548,666 |  |
| Video conferencing |  | 29,882 |  |  | 29,956 |  |  | 84,094 |  |  | 89,726 |  |
|  |  | $ | 634,204 |  |  | $ | 628,719 |  |  | $ | 1,646,718 |  |  | $ | 1,638,392 |  |
| Segment operating income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |
| Peripherals (1) |  | $ | 76,114 |  |  | $ | 64,806 |  |  | $ | 160,268 |  |  | $ | 117,784 |  |
| Video conferencing (1) |  | (2,103 | ) |  | 1,210 |  |  | (3,068 | ) |  | (15,131 | ) |
|  |  | 74,011 |  |  | 66,016 |  |  | 157,200 |  |  | 102,653 |  |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation |  | (7,047 | ) |  | (8,913 | ) |  | (20,046 | ) |  | (17,412 | ) |
| Amortization of intangibles |  | (2,266 | ) |  | (4,472 | ) |  | (7,624 | ) |  | (14,990 | ) |
| Interest income, net |  | 224 |  |  | (1,022 | ) |  | 837 |  |  | (862 | ) |
| Other income (expense), net |  | (3,016 | ) |  | 1,082 |  |  | (4,099 | ) |  | 1,361 |  |
| Income before income taxes |  | $ | 61,906 |  |  | $ | 52,691 |  |  | $ | 126,268 |  |  | $ | 70,750 |  |

[0001628280-15-000267:notes:134]
(1)   Peripherals operating results include $0.1 million restructuring credit and a $0.8 million restructuring charge during the three months ended December 31, 2014 and 2013, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-15-000267:notes:135]
Segment Information

[0001628280-15-000267:notes:136]
[same as prior period, unchanged from 0001104659-14-083669:notes:121]

[0001628280-15-000267:notes:137]
Operating performance measures for the peripherals segment and the video conferencing segment are reported separately to the Company's Chief Executive Officer (“CEO”), who is considered to be the Company’s Chief Operating Decision Maker (“CODM”). The CEO periodically reviews information such as net sales and operating income (loss) for each operating segment to make business decisions. These operating performance measures do not include share-based compensation expense and amortization of intangible assets. Share-based compensation expense and amortization of intangible assets are presented in the following financial information by operating segment as “other income (expense), net.” Assets by operating segment are not presented since the Company does not present such data to the CODM.

[0001628280-15-000267:notes:138]
(1)   Peripherals operating results include $0.1 million restructuring credit and a $0.8 million restructuring charge during the three months ended December 31, 2014 and 2013, respectively. Peripherals operating results include $0.1 million restructuring credit and $2.7 million restructuring charges during the nine months ended December 31, 2014 and 2013, respectively. Video conferencing operating results include $0.1 million restructuring credit and $5.9 million of restructuring charges during the nine months ended December 31, 2014 and 2013.

[0001628280-15-000267:notes:139]
Sales are attributed to countries on the basis of the customers’ locations. The United States represented 36% and 34% of the Company’s total consolidated net sales for the three months ended December 31, 2014 and 2013, respectively. No other single country represented more than 10% of the Company’s total consolidated net sales during those periods. Revenues from sales to customers in Switzerland, the Company’s home domicile, represented 2% and 2% of the Company’s total consolidated net sales for the three months ended December 31, 2014 and 2013. One customer group of the Company’s peripheral operating segment represented 14% and 15% of sales for the three months ended December 31, 2014 and 2013, respectively. The United States represented 36% and 35% of the Company’s total consolidated net sales for the nine months ended December 31, 2014 and 2013, respectively. Revenues from sales to customers in Switzerland, the Company’s home domicile, represented 2% and 1% of the Company's total consolidated net sales for the nine months ended December 31, 2014 and 2013. No other single country represented more than 10% of the Company’s total consolidated net sales during those periods. One customer group of the Company’s peripherals reporting segment represented 15% and 14% for the nine months ended December 31, 2014 and 2013, respectively. No other customer makes up more than 10% of revenue for both the three and nine months ended December 31, 2014 and 2013.

[0001628280-15-000267:notes:140]
Long-lived assets in the United States and China were $47.3 million and $34.5 million as of December 31, 2014 and $44.9 million and $31.9 million at March 31, 2014. No other countries represented more than 10% of the Company’s total consolidated long-lived assets as of December 31 and March 31, 2014. Long-lived assets in Switzerland, the Company’s home domicile, were $1.4 million and $1.6 million at December 31 and March 31, 2014.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001628280-15-000267:notes:141]
Shareholders’ Equity

[0001628280-15-000267:notes:142]
[same as prior period, unchanged from 0001104659-14-083669:notes:126]

[0001628280-15-000267:notes:143]
There were no share repurchases during the nine months ended December 31, 2014 and 2013. During most of the nine month period ended December 31, 2014, the Company was not current with its periodic reports required to be filed with the SEC and therefore lost its ability to buy back shares. The Company regained its ability to repurchase shares upon filing its Form 10-Q with SEC on November 26, 2014.

[0001628280-15-000267:notes:144]
[same as prior period, unchanged from 0001104659-14-083669:notes:128]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001628280-15-000267:notes:145]
Balance Sheet Components
