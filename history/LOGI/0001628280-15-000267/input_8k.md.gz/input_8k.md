# LOGI 8-K — 0001628280-15-000191 filed 2015-01-22

## item codes, every 8-K on or before 2015-01-27

- 2015-01-22 0001628280-15-000191 — 2.02, 8.01
- 2014-12-23 0001193125-14-450908 — 5.02, 5.07, 8.01
- 2014-11-25 0001193125-14-425233 — 3.01
- 2014-11-13 0001193125-14-411303 — 4.01, 9.01
- 2014-10-23 0001104659-14-073164 — 2.02, 9.01
- 2014-09-04 0001193125-14-331214 — 4.02, 9.01
- 2014-08-18 0001193125-14-313346 — 3.01, 9.01
- 2014-07-24 0001104659-14-053065 — 2.02, 9.01
- 2014-06-05 0001193125-14-226177 — 3.01, 9.01
- 2014-05-22 0001193125-14-208777 — 8.01, 9.01
- 2014-04-24 0001104659-14-029650 — 2.02, 9.01
- 2014-01-23 0001104659-14-003619 — 2.02, 9.01
- 2013-10-24 0001104659-13-077404 — 2.02, 9.01
- 2013-09-09 0001193125-13-361441 — 5.02, 5.07, 8.01, 9.01
- 2013-09-06 0001193125-13-359930 — 5.02, 9.01
- 2013-08-02 0001193125-13-317343 — 5.02
- 2013-07-25 0001104659-13-056372 — 2.02, 9.01
- 2013-06-28 0001193125-13-277394 — 5.02, 9.01
- 2013-06-20 0001193125-13-265914 — 8.01, 9.01
- 2013-04-25 0001104659-13-032570 — 2.02, 9.01
- 2013-04-17 0001193125-13-158923 — 5.02, 9.01
- 2013-03-01 0001193125-13-085804 — 2.05
- 2013-01-24 0001104659-13-004214 — 2.02, 9.01
- 2013-01-02 0001193125-13-000058 — 5.02
- 2012-10-25 0001104659-12-070966 — 2.02, 9.01
- 2012-09-11 0001193125-12-388070 — 5.02, 5.07, 8.01, 9.01
- 2012-08-22 0001193125-12-364167 — 5.02, 8.01, 9.01
- 2012-07-26 0001104659-12-051084 — 2.02, 9.01
- 2012-06-08 0001193125-12-264132 — 2.05, 9.01 — amendment, the index does not say of what
- 2012-04-26 0001193125-12-183657 — 5.02, 9.01
- 2012-04-26 0001104659-12-028470 — 2.02, 2.05, 9.01
- 2012-03-15 0001193125-12-115954 — 5.02, 9.01
- 2012-01-26 0001104659-12-004014 — 2.02, 9.01
- 2012-01-04 0001193125-12-002212 — 1.01, 2.03, 9.01
- 2011-10-27 0001104659-11-058150 — 2.02, 9.01
- 2011-09-12 0001193125-11-245931 — 5.07
- 2011-07-28 0001193125-11-200929 — 5.02, 9.01
- 2011-07-28 0001193125-11-199704 — 2.02, 9.01
- 2011-04-28 0001193125-11-112669 — 2.02, 9.01
- 2011-03-24 0001193125-11-076483 — 5.02, 9.01
- 2011-01-27 0001032975-11-000003 — 9.01
- 2010-10-28 0001032975-10-000032 — 9.01
- 2010-09-13 0001032975-10-000022 — 5.07
- 2010-07-29 0001032975-10-000010 — 2.02, 9.01
- 2010-06-10 0001193125-10-136877 — 5.02, 9.01
- 2010-05-03 0001193125-10-104337 — 5.02
- 2010-04-29 0001032975-10-000008 — 2.02, 9.01
- 2010-02-19 0001032975-10-000006 — 9.01 — amendment of 0001193125-09-252416
- 2010-01-21 0001032975-10-000002 — 2.02, 9.01
- 2009-12-14 0001193125-09-252416 — 2.01, 9.01
- 2009-11-17 0001032975-09-000023 — 1.01
- 2009-10-22 0001032975-09-000018 — 9.01
- 2009-09-22 0001193125-09-195545 — 5.02, 9.01
- 2009-09-03 0001032975-09-000013 — 8.01
- 2009-07-23 0001140361-09-016802 — 2.02, 9.01
- 2009-06-01 0001193125-09-122550 — 5.02
- 2009-04-23 0001193125-09-085054 — 2.02, 9.01
- 2009-04-02 0001193125-09-071272 — 5.02, 9.01
- 2009-01-20 0001193125-09-008454 — 2.05 — amendment of 0001193125-09-002609
- 2009-01-20 0001193125-09-007902 — 2.02, 9.01
- 2009-01-07 0001193125-09-002609 — 2.05, 9.01
- 2009-01-07 0001193125-09-002370 — 5.02, 9.01
- 2008-12-09 0001193125-08-250543 — 5.02, 9.01
- 2008-10-21 0001193125-08-213212 — 2.02, 9.01
- 2008-07-22 0001193125-08-154721 — 2.02, 9.01
- 2008-06-24 0001193125-08-139163 — 5.03, 9.01
- 2008-05-13 0001193125-08-113263 — 5.02, 9.01
- 2008-04-22 0001193125-08-086176 — 2.02, 9.01

## late-filing notifications on or before 2015-01-27

- 2014-11-06 0001193125-14-401306 — NT 10-Q, for the period ended 2014-09-30
- 2014-07-24 0001193125-14-277575 — NT 10-Q, for the period ended 2014-06-30
- 2014-05-22 0001193125-14-208712 — NT 10-K, for the period ended 2014-03-31
- 2009-08-06 0001032975-09-000006 — NT 10-Q, for the period ended 2009-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001628280-15-000191:8k_2_02:1]
EX-99.1
2
exhibit991.htm
EX-99.1

[0001628280-15-000191:8k_2_02:2]
Exhibit 99.1

[0001628280-15-000191:8k_2_02:3]
Exhibit 99.1

[0001628280-15-000191:8k_2_02:4]
For Immediate Release

[0001628280-15-000191:8k_2_02:5]
Editorial Contacts:

[0001628280-15-000191:8k_2_02:6]
Joe Greenhalgh, Vice President, Investor Relations - USA (510) 713-4430

[0001628280-15-000191:8k_2_02:7]
Krista Todd, Sr. Director, External Communications - USA (510) 713-5834

[0001628280-15-000191:8k_2_02:8]
Ben Starkie, Corporate Communications - Europe +41-(0) 79-292-3499

[0001628280-15-000191:8k_2_02:9]
Logitech Increases Profitability Outlook for Fiscal Year 2015

[0001628280-15-000191:8k_2_02:10]
Following Better-Than-Expected Q3 Results

[0001628280-15-000191:8k_2_02:11]
Retail Sales Momentum Continues with 5 Percent Growth in Constant Currency

[0001628280-15-000191:8k_2_02:12]
NEWARK, Calif. - Jan. 21, 2015 and LAUSANNE, Switzerland, Jan. 22, 2015 - Logitech International (SIX: LOGN) (Nasdaq: LOGI) today announced financial results for the third quarter of Fiscal Year 2015.

[0001628280-15-000191:8k_2_02:13]
| • | Q3 sales were $634 million, up 1 percent compared to Q3 of the prior year, with retail sales up 2 percent. Excluding the unfavorable impact of currency exchange rates, Q3 retail sales grew 5 percent. |

[0001628280-15-000191:8k_2_02:14]
| • | Q3 GAAP operating income was $65 million, with GAAP earnings per share (EPS) of $0.38, compared to $0.29 in the same quarter a year ago. |

[0001628280-15-000191:8k_2_02:15]
| • | Q3 non-GAAP operating income was $76 million, with non-GAAP EPS of $0.41, compared to $0.35 a year ago. |

[0001628280-15-000191:8k_2_02:16]
| • | Cash flow from operations in the quarter was $76 million. Cash flow from operations for the last twelve months was approximately $232 million, up 86 percent compared to the same period a year ago. |

[0001628280-15-000191:8k_2_02:17]
“I’m excited about our strong performance in Q3,” said Bracken P. Darrell, Logitech president and chief executive officer. “We almost doubled sales in Mobile Speakers and also posted healthy growth in PC Gaming and Video Collaboration. Overall, despite the U.S. dollar’s strengthening, our retail sales and profitability continued to grow and we generated robust cash flow. Based on these better-than-expected results and the strength of our product offerings, we have increased our full-year outlook for operating income for the second time this fiscal year.”

[0001628280-15-000191:8k_2_02:18]
Outlook

[0001628280-15-000191:8k_2_02:19]
Despite the unfavorable impact of exchange rates, Logitech increased its profitability outlook for Fiscal Year 2015 from approximately $170 million to approximately $185 million in non-GAAP operating income. The Company adjusted its sales outlook for Fiscal Year 2015 from approximately $2.16 billion to approximately $2.11 billion to reflect the U.S. dollar’s appreciation compared to various other currencies.

[0001628280-15-000191:8k_2_02:20]
Prepared Remarks Available Online

[0001628280-15-000191:8k_2_02:21]
Logitech has made its prepared written remarks for the financial results teleconference available online on the Logitech corporate Web site at http://ir.logitech.com.

[0001628280-15-000191:8k_2_02:22]
Financial Results Teleconference and Webcast

[0001628280-15-000191:8k_2_02:23]
Logitech will hold a financial results teleconference to discuss the results for Q3 FY 2015 on Jan. 22, 2015 at 8:30 a.m. Eastern Standard Time and 14:30 Central European Time. A live webcast of the call will be available on the Logitech corporate website at http://ir.logitech.com.

[0001628280-15-000191:8k_2_02:24]
Use of Non-GAAP Financial Information

[0001628280-15-000191:8k_2_02:25]
To facilitate comparisons to Logitech’s historical results, Logitech has included non-GAAP adjusted measures, which exclude share-based compensation expense, amortization of other intangible assets, restructuring charges (credits), other restructuring-related charges, investment impairment (recovery), benefit from (provision for) income taxes, one-time special charges and other items detailed under “Supplemental Financial Information” after the tables below. Logitech also presents percentage sales growth in constant currency, a non-GAAP measure, to show performance unaffected by fluctuations in foreign currency exchange rates.  Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales. Logitech believes this information will help investors to evaluate its current period performance and trends in its business. With respect to the Company’s outlook for Fiscal Year 2015 non-GAAP operating income, most of these excluded amounts pertain to events that have not yet occurred and are not currently possible to estimate with a reasonable degree of accuracy. Therefore, no reconciliation to the GAAP amount has been provided.

[0001628280-15-000191:8k_2_02:26]
About Logitech

[0001628280-15-000191:8k_2_02:27]
Logitech is a world leader in products that connect people to the digital experiences they care about. Spanning multiple computing, communication and entertainment platforms, Logitech’s combined hardware and software enable or enhance digital navigation, music and video entertainment, gaming, social networking, audio and video communication over the Internet, video security and home-entertainment control. Founded in 1981, Logitech International is a Swiss public company listed on the SIX Swiss Exchange (LOGN) and on the Nasdaq Global Select Market (LOGI).

[0001628280-15-000191:8k_2_02:28]
#   #   #

[0001628280-15-000191:8k_2_02:29]
Note that unless noted otherwise, comparisons are year over year.

[0001628280-15-000191:8k_2_02:30]
Logitech, the Logitech logo, and other Logitech marks are registered in Switzerland and other countries. All other trademarks are the property of their respective owners. For more information about Logitech and its products, visit the company’s Web site at www.logitech.com.

[0001628280-15-000191:8k_2_02:31]
(LOGIIR)

[0001628280-15-000191:8k_2_02:32]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| (In thousands, except per share amounts) -Unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | December 31, |  | December 31, |
| GAAP CONSOLIDATED STATEMENTS OF OPERATIONS |  | 2014 |  | 2013 (1) |  | 2014 |  | 2013 (1) |
| Net sales |  | $ | 634,204 |  |  | $ | 628,719 |  |  | $ | 1,646,718 |  |  | $ | 1,638,392 |  |
| Cost of goods sold |  | 402,921 |  |  | 414,418 |  |  | 1,028,905 |  |  | 1,071,867 |  |
| Gross profit |  | 231,283 |  |  | 214,301 |  |  | 617,813 |  |  | 566,525 |  |
| % of net sales |  | 36.5 | % |  | 34.1 | % |  | 37.5 | % |  | 34.6 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Marketing and selling |  | 103,307 |  |  | 94,273 |  |  | 290,215 |  |  | 288,817 |  |
| Research and development |  | 33,616 |  |  | 34,577 |  |  | 97,257 |  |  | 108,589 |  |
| General and administrative |  | 29,808 |  |  | 31,998 |  |  | 100,957 |  |  | 90,247 |  |
| Restructuring charges (credit), net |  | (146 | ) |  | 822 |  |  | (146 | ) |  | 8,621 |  |
| Total operating expenses |  | 166,585 |  |  | 161,670 |  |  | 488,283 |  |  | 496,274 |  |
| Operating income |  | 64,698 |  |  | 52,631 |  |  | 129,530 |  |  | 70,251 |  |
| Interest income (expense), net |  | 224 |  |  | (1,022 | ) |  | 837 |  |  | (862 | ) |
| Other income (expense), net |  | (3,016 | ) |  | 1,082 |  |  | (4,099 | ) |  | 1,361 |  |
| Income before income taxes |  | 61,906 |  |  | 52,691 |  |  | 126,268 |  |  | 70,750 |  |
| Provision for (benefit from) income taxes |  | (878 | ) |  | 4,807 |  |  | 7,718 |  |  | 7,064 |  |
| Net income |  | $ | 62,784 |  |  | $ | 47,884 |  |  | $ | 118,550 |  |  | $ | 63,686 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.38 |  |  | $ | 0.30 |  |  | $ | 0.73 |  |  | $ | 0.40 |  |
| Diluted |  | $ | 0.38 |  |  | $ | 0.29 |  |  | $ | 0.71 |  |  | $ | 0.39 |  |
| Shares used to compute net income per share : |  |  |  |  |  |  |  |  |
| Basic |  | 163,533 |  |  | 160,871 |  |  | 163,261 |  |  | 160,051 |  |
| Diluted |  | 166,321 |  |  | 163,388 |  |  | 166,076 |  |  | 161,509 |  |

[0001628280-15-000191:8k_2_02:33]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |
| (In thousands) - Unaudited |  |  |  |  |  |  |
|  |  | December 31, |  | March 31, |  | December 31, |
| CONSOLIDATED BALANCE SHEETS |  | 2014 |  | 2014 |  | 2013 (1) |
| Current assets: |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 516,613 |  |  | $ | 469,412 |  |  | $ | 379,865 |  |
| Accounts receivable |  | 306,866 |  |  | 182,029 |  |  | 312,947 |  |
| Inventories |  | 245,740 |  |  | 222,402 |  |  | 259,154 |  |
| Other current assets |  | 65,613 |  |  | 59,157 |  |  | 61,518 |  |
| Total current assets |  | 1,134,832 |  |  | 933,000 |  |  | 1,013,484 |  |
| Non-current assets: |  |  |  |  |  |  |
| Property, plant and equipment, net |  | 90,777 |  |  | 88,391 |  |  | 92,382 |  |
| Goodwill |  | 343,437 |  |  | 345,010 |  |  | 345,036 |  |
| Other intangible assets |  | 2,728 |  |  | 10,529 |  |  | 13,319 |  |
| Other assets |  | 67,005 |  |  | 74,460 |  |  | 70,459 |  |
| Total assets |  | $ | 1,638,779 |  |  | $ | 1,451,390 |  |  | $ | 1,534,680 |  |
| Current liabilities: |  |  |  |  |  |  |
| Accounts payable |  | $ | 350,335 |  |  | $ | 242,815 |  |  | $ | 325,559 |  |
| Accrued and other current liabilities |  | 224,650 |  |  | 211,972 |  |  | 236,022 |  |
| Total current liabilities |  | 574,985 |  |  | 454,787 |  |  | 561,581 |  |
| Non-current liabilities: |  | 172,880 |  |  | 192,475 |  |  | 199,821 |  |
| Total liabilities |  | 747,865 |  |  | 647,262 |  |  | 761,402 |  |
| Total shareholders' equity |  | 890,914 |  |  | 804,128 |  |  | 773,278 |  |
| Total liabilities and shareholders' equity |  | $ | 1,638,779 |  |  | $ | 1,451,390 |  |  | $ | 1,534,680 |  |

[0001628280-15-000191:8k_2_02:34]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| (In thousands) - Unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | December 31, |  | December 31, |
| CONSOLIDATED STATEMENTS OF CASH FLOWS |  | 2014 |  | 2013 (1) |  | 2014 |  | 2013 (1) |
| Operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 62,784 |  |  | $ | 47,884 |  |  | $ | 118,550 |  |  | $ | 63,686 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  | 9,867 |  |  | 10,913 |  |  | 29,559 |  |  | 32,755 |  |
| Amortization of other intangible assets |  | 2,266 |  |  | 4,472 |  |  | 7,624 |  |  | 14,990 |  |
| Share-based compensation expense |  | 7,047 |  |  | 8,913 |  |  | 20,046 |  |  | 17,412 |  |
| Impairment of investments |  | 2,154 |  |  | 38 |  |  | 2,259 |  |  | 568 |  |
| Loss (gain) on disposal of property, plant and equipment |  | (34 | ) |  | 1,422 |  |  | (44 | ) |  | 3,878 |  |
| Excess tax benefits from share-based compensation |  | (1,867 | ) |  | (572 | ) |  | (2,533 | ) |  | (572 | ) |
| Deferred income taxes |  | (793 | ) |  | 340 |  |  | (3,151 | ) |  | (3,561 | ) |
| Changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | (57,465 | ) |  | (54,566 | ) |  | (131,026 | ) |  | (130,871 | ) |
| Inventories |  | (3,187 | ) |  | 35,169 |  |  | (30,171 | ) |  | 13,496 |  |
| Other assets |  | (952 | ) |  | 4,173 |  |  | (6,592 | ) |  | (2,968 | ) |
| Accounts payable |  | 51,198 |  |  | 22,830 |  |  | 111,310 |  |  | 61,423 |  |
| Accrued and other liabilities |  | 5,336 |  |  | 13,374 |  |  | 21,227 |  |  | 40,463 |  |
| Net cash provided by operating activities |  | 76,354 |  |  | 94,390 |  |  | 137,058 |  |  | 110,699 |  |
| Investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  | (9,813 | ) |  | (9,724 | ) |  | (34,777 | ) |  | (34,910 | ) |
| Investments in privately held companies |  | — |  |  | 261 |  |  | (2,550 | ) |  | — |  |
| Acquisitions, net of cash acquired |  | — |  |  | — |  |  | — |  |  | (650 | ) |
| Proceeds from return of investment from strategic investments |  | — |  |  | — |  |  | — |  |  | 261 |  |
| Purchases of trading investments |  | (1,233 | ) |  | (1,685 | ) |  | (3,463 | ) |  | (7,831 | ) |
| Proceeds from sales of trading investments |  | 1,311 |  |  | 1,709 |  |  | 3,856 |  |  | 8,311 |  |
| Net cash used in investing activities |  | (9,735 | ) |  | (9,439 | ) |  | (36,934 | ) |  | (34,819 | ) |
| Financing activities: |  |  |  |  |  |  |  |  |
| Payment of cash dividends |  | (43,767 | ) |  | — |  |  | (43,767 | ) |  | (36,123 | ) |
| Contingent cash payment of acquisition |  | — |  |  | — |  |  | (100 | ) |  | — |  |
| Repurchase of ESPP awards |  | — |  |  | — |  |  | (1,078 | ) |  | — |  |
| Proceeds from sales of shares upon exercise of options and purchase rights |  | 933 |  |  | 2,330 |  |  | 2,466 |  |  | 8,465 |  |
| Tax withholdings related to net share settlements of restricted stock units |  | (6,133 | ) |  | (2,484 | ) |  | (7,456 | ) |  | (2,937 | ) |
| Excess tax benefits from share-based compensation |  | 1,867 |  |  | 572 |  |  | 2,533 |  |  | 572 |  |
| Net cash provided by (used in) financing activities |  | (47,100 | ) |  | 418 |  |  | (47,402 | ) |  | (30,023 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  | (3,128 | ) |  | (300 | ) |  | (5,521 | ) |  | 184 |  |
| Net increase in cash and cash equivalents |  | 16,391 |  |  | 85,069 |  |  | 47,201 |  |  | 46,041 |  |
| Cash and cash equivalents, beginning of the period |  | 500,222 |  |  | 294,796 |  |  | 469,412 |  |  | 333,824 |  |
| Cash and cash equivalents, end of the period |  | $ | 516,613 |  |  | $ | 379,865 |  |  | $ | 516,613 |  |  | $ | 379,865 |  |

[0001628280-15-000191:8k_2_02:35]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| (In thousands, except per share amounts) - Unaudited |  |  |  |  |  |  |  |  |
| NET RETAIL SALES BY PRODUCT CATEGORY |  | Three Months Ended |  | Nine Months Ended |
|  |  | December 31, |  | December 31, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2014 |  | 2013 (1) |  | 2014 |  | 2013 (1) |
| Net sales by channel: |  |  |  |  |  |  |  |  |
| Retail |  | $ | 574,025 |  |  | $ | 564,221 |  |  | $ | 1,471,301 |  |  | $ | 1,442,085 |  |
| OEM |  | 30,297 |  |  | 34,542 |  |  | 91,323 |  |  | 106,581 |  |
| Video conferencing |  | 29,882 |  |  | 29,956 |  |  | 84,094 |  |  | 89,726 |  |
| Total net sales |  | $ | 634,204 |  |  | $ | 628,719 |  |  | $ | 1,646,718 |  |  | $ | 1,638,392 |  |
| Net retail sales by product family(*): |  |  |  |  |  |  |  |  |
| PC Gaming |  | $ | 70,188 |  |  | $ | 58,173 |  |  | $ | 164,570 |  |  | $ | 141,645 |  |
| Tablet & Other Accessories |  | 55,100 |  |  | 77,009 |  |  | 114,973 |  |  | 150,263 |  |
| Mobile Speakers |  | 62,264 |  |  | 34,198 |  |  | 139,631 |  |  | 68,032 |  |
| Growth |  | 187,552 |  |  | 169,380 |  |  | 419,174 |  |  | 359,940 |  |
| Pointing Devices |  | 141,789 |  |  | 141,757 |  |  | 382,524 |  |  | 387,064 |  |
| PC Keyboards & Desktops |  | 114,058 |  |  | 108,682 |  |  | 325,299 |  |  | 311,955 |  |
| Audio-PC &Wearables |  | 58,696 |  |  | 69,021 |  |  | 166,999 |  |  | 195,082 |  |
| Video |  | 46,682 |  |  | 38,154 |  |  | 118,822 |  |  | 105,740 |  |
| Remotes |  | 25,116 |  |  | 26,049 |  |  | 56,224 |  |  | 53,950 |  |
| Profit Maximization |  | 386,341 |  |  | 383,663 |  |  | 1,049,868 |  |  | 1,053,791 |  |
| Other |  | 132 |  |  | 11,178 |  |  | 2,259 |  |  | 28,354 |  |
| Non-Strategic |  | 132 |  |  | 11,178 |  |  | 2,259 |  |  | 28,354 |  |
| Total net retail sales |  | $ | 574,025 |  |  | $ | 564,221 |  |  | $ | 1,471,301 |  |  | $ | 1,442,085 |  |
| __________________ |  |  |  |  |  |  |  |  |

[0001628280-15-000191:8k_2_02:36]
* Certain products within the retail product families as presented in prior years have been reclassified to conform to the current year presentation, with no impact on previously reported total net retail sales.

[0001628280-15-000191:8k_2_02:37]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| (In thousands, except per share amounts) - Unaudited |  |  |  |  |  |  |  |  |
| GAAP TO NON GAAP RECONCILIATION (A) |  | Three Months Ended |  | Nine Months Ended |
|  |  | December 31, |  | December 31, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2014 |  | 2013 (1) |  | 2014 |  | 2013 (1) |
| Gross profit - GAAP |  | $ | 231,283 |  |  | $ | 214,301 |  |  | $ | 617,813 |  |  | $ | 566,525 |  |
| Share-based compensation expense |  | 560 |  |  | 672 |  |  | 1,724 |  |  | 1,843 |  |
| Amortization of other intangible assets |  | 532 |  |  | 2,190 |  |  | 1,626 |  |  | 7,361 |  |
| Restructuring-related charges |  | — |  |  | — |  |  | — |  |  | 5,194 |  |
| Gross profit - Non-GAAP |  | $ | 232,375 |  |  | $ | 217,163 |  |  | $ | 621,163 |  |  | $ | 580,923 |  |
| Gross margin - GAAP |  | 36.5 | % |  | 34.1 | % |  | 37.5 | % |  | 34.6 | % |
| Gross margin - Non-GAAP |  | 36.6 | % |  | 34.5 | % |  | 37.7 | % |  | 35.5 | % |
| Operating expenses - GAAP |  | $ | 166,585 |  |  | $ | 161,670 |  |  | $ | 488,283 |  |  | $ | 496,274 |  |
| Less: Share-based compensation expense |  | 6,487 |  |  | 8,241 |  |  | 18,322 |  |  | 15,569 |  |
| Less: Amortization of other intangible assets |  | 1,734 |  |  | 2,282 |  |  | 5,998 |  |  | 7,629 |  |
| Less: Restructuring charges (credits), net |  | (146 | ) |  | 822 |  |  | (146 | ) |  | 8,621 |  |
| Less: One time special charge |  | 2,520 |  |  | — |  |  | 19,520 |  |  | — |  |
| Operating expenses - Non-GAAP |  | $ | 155,990 |  |  | $ | 150,325 |  |  | $ | 444,589 |  |  | $ | 464,455 |  |
| % of net sales - GAAP |  | 26.3 | % |  | 25.7 | % |  | 29.7 | % |  | 30.3 | % |
| % of net sales - Non - GAAP |  | 24.6 | % |  | 23.9 | % |  | 27.0 | % |  | 28.3 | % |
| Operating income - GAAP |  | $ | 64,698 |  |  | $ | 52,631 |  |  | $ | 129,530 |  |  | $ | 70,251 |  |
| Share-based compensation expense |  | 7,047 |  |  | 8,913 |  |  | 20,046 |  |  | 17,412 |  |
| Amortization of other intangible assets |  | 2,266 |  |  | 4,472 |  |  | 7,624 |  |  | 14,990 |  |
| Restructuring charges (credits), net |  | (146 | ) |  | 822 |  |  | (146 | ) |  | 8,621 |  |
| Restructuring related charges |  | — |  |  | — |  |  | — |  |  | 5,194 |  |
| One time special charge |  | 2,520 |  |  | — |  |  | 19,520 |  |  | — |  |
| Operating income - Non - GAAP |  | $ | 76,385 |  |  | $ | 66,838 |  |  | $ | 176,574 |  |  | $ | 116,468 |  |
| % of net sales - GAAP |  | 10.2 | % |  | 8.4 | % |  | 7.9 | % |  | 4.3 | % |
| % of net sales - Non - GAAP |  | 12.0 | % |  | 10.6 | % |  | 10.7 | % |  | 7.1 | % |
| Net income - GAAP |  | $ | 62,784 |  |  | $ | 47,884 |  |  | $ | 118,550 |  |  | $ | 63,686 |  |
| Share-based compensation expense |  | 7,047 |  |  | 8,913 |  |  | 20,046 |  |  | 17,412 |  |
| Amortization of other intangible assets |  | 2,266 |  |  | 4,472 |  |  | 7,624 |  |  | 14,990 |  |
| Restructuring related charges |  | — |  |  | — |  |  | — |  |  | 5,194 |  |
| Restructuring charges (credits), net |  | (146 | ) |  | 822 |  |  | (146 | ) |  | 8,621 |  |
| One time special charge |  | 2,520 |  |  | — |  |  | 19,520 |  |  | — |  |
| Investment impairment, net |  | 2,154 |  |  | 38 |  |  | 2,259 |  |  | 568 |  |
| Provision for income taxes |  | (8,350 | ) |  | (4,803 | ) |  | (12,257 | ) |  | (10,171 | ) |
| Net income - Non - GAAP |  | $ | 68,275 |  |  | $ | 57,326 |  |  | $ | 155,596 |  |  | $ | 100,300 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  | $ | 0.38 |  |  | $ | 0.29 |  |  | $ | 0.71 |  |  | $ | 0.39 |  |
| Diluted - Non - GAAP |  | $ | 0.41 |  |  | $ | 0.35 |  |  | $ | 0.94 |  |  | $ | 0.62 |  |
| Shares used to compute net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP and Non GAAP |  | 166,321 |  |  | 163,388 |  |  | 166,076 |  |  | 161,509 |  |

[0001628280-15-000191:8k_2_02:38]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| (In thousands, except per share amounts) - Unaudited |  |  |  |  |  |  |  |  |
| SHARED BASED COMPENSATION EXPENSE |  | Three Months Ended |  | Nine Months Ended |
|  |  | December 31, |  | December 31, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Share-based Compensation Expense |  |  |  |  |  |  |  |  |
| Cost of goods sold |  | $ | 560 |  |  | $ | 672 |  |  | $ | 1,724 |  |  | $ | 1,843 |  |
| Marketing and selling |  | 2,786 |  |  | 3,057 |  |  | 6,995 |  |  | 5,980 |  |
| Research and Development |  | 1,066 |  |  | 1,906 |  |  | 2,462 |  |  | 3,840 |  |
| General and administrative |  | 2,635 |  |  | 3,278 |  |  | 8,865 |  |  | 5,749 |  |
| Income tax benefit |  | (1,623 | ) |  | (168 | ) |  | (4,720 | ) |  | (2,343 | ) |
| Total share-based compensation expense after income taxes |  | $ | 5,424 |  |  | $ | 8,745 |  |  | $ | 15,326 |  |  | $ | 15,069 |  |
| __________________ |  |  |  |  |  |  |  |  |

[0001628280-15-000191:8k_2_02:39]
(1) As disclosed in the Company’s Annual Report on Form 10-K for the year ended March 31, 2014 and in the audited consolidated financial statements contained therein, the Company has revised its financial statements for the fiscal year ended March 31, 2013. The impact of the adjustments also immaterially impact the financial statements for the first three quarters of the fiscal year ended March 31, 2014 as previously included in the Company’s quarterly reports on Form 10-Q for Fiscal 2014. Accordingly, the financial statements for the three and nine months ended December 31, 2013 included in this earning release have been revised.

[0001628280-15-000191:8k_2_02:40]
(A) Non-GAAP Financial Measures

[0001628280-15-000191:8k_2_02:41]
To supplement our condensed consolidated financial results prepared in accordance with GAAP, we use a number of financial measures, both GAAP and non-GAAP, in analyzing and assessing our overall business performance, for making operating decisions and for forecasting and planning future periods. We consider the use of non-GAAP financial measures helpful in assessing our current financial performance, ongoing operations and prospects for the future as well as understanding financial and business trends relating to our financial condition and results of operations.

[0001628280-15-000191:8k_2_02:42]
While we use non-GAAP financial measures as a tool to enhance our understanding of certain aspects of our financial performance and to provide incremental insight into the underlying factors and trends affecting both our performance and our cash-generating potential, we do not consider these measures to be a substitute for, or superior to, the information provided by GAAP financial measures. Consistent with this approach, we believe that disclosing non-GAAP financial measures to the readers of our financial statements provides useful supplemental data that, while not a substitute for GAAP financial measures, can offer insight in the review of our financial and operational performance and enables investors to more fully understand trends in our current and future performance. In assessing our business during the three and nine  months ended December 31, 2014, we excluded items in the following general categories, each of which are described below:

[0001628280-15-000191:8k_2_02:43]
Share-based compensation expenses. We believe that providing non-GAAP measures excluding share-based compensation expense, in addition to the GAAP measures, allows for a more transparent comparison of our financial results from period to period. We prepare and maintain our budgets and forecasts for future periods on a basis consistent with this non-GAAP financial measure. Further, companies use a variety of types of equity awards as well as a variety of methodologies, assumptions and estimates to determine share-based compensation expense. We believe that excluding share-based compensation expense enhances our ability and the ability of investors to understand the impact of non-cash share-based compensation on our operating results and to compare our results against the results of other companies.

[0001628280-15-000191:8k_2_02:44]
Amortization of other intangible assets. We incur intangible asset amortization expense, primarily in connection with our acquisitions of various businesses and technologies. The amortization of purchased intangibles varies depending on the level of acquisition activity. We exclude these various charges in budgeting, planning and forecasting future periods and we believe that providing the non-GAAP measures excluding these various non-cash charges, as well as the GAAP measures, provides additional insight when comparing our operating expenses and financial results from period to period.

[0001628280-15-000191:8k_2_02:45]
Restructuring and restructuring-related charges. These expenses are associated with re-aligning our business strategies based on current economic conditions. We have undertaken several restructurings in recent years. In connection with our restructuring initiatives, we incurred restructuring charges related to employee terminations, facility closures and early cancellation of certain contracts. Our restructuring initiatives also resulted in other costs related to restructurings not qualifying for inclusion in

[0001628280-15-000191:8k_2_02:46]
restructuring charges. We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges are not reflective of our ongoing operating results in the current period.

[0001628280-15-000191:8k_2_02:47]
One-time special charges:  costs related to investigations.  These expenses are forensic accounting, audit,

[0001628280-15-000191:8k_2_02:48]
consulting and legal fees related to the Audit Committee’s investigation and the ongoing formal investigation by the Securities and Exchange Commission.  We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges are one-time in nature and not reflective of our ongoing operations.

[0001628280-15-000191:8k_2_02:49]
Other charges. We provided non-GAAP measures excluding the effect of certain charges and income that are not reflective of our ongoing operations.

[0001628280-15-000191:8k_2_02:50]
In addition, Logitech presents percentage sales growth in constant currency, a non-GAAP measure, to show performance unaffected by fluctuations in foreign currency exchange rates.  Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales.  Retail sales for the three months ended December 31, 2014 compared to retail sales for the three months ended December 31, 2013 grew 5 percent in constant currency, on a non-GAAP basis, and 2 percent on a GAAP basis, an increase of 3 percentage points due to foreign currency exchange rates.

[0001628280-15-000191:8k_2_02:51]
Each of the non-GAAP financial measures described above, and used in this press release, should not be considered in isolation from, or as a substitute for, a measure of financial performance prepared in accordance with GAAP. Further, investors are cautioned that there are inherent limitations associated with the use of each of these non-GAAP financial measures as an analytical tool. In particular, these non-GAAP financial measures are not based on a comprehensive set of accounting rules or principles and many of the adjustments to the GAAP financial measures reflect the exclusion of items that are recurring and may be reflected in the Company’s financial results for the foreseeable future. We compensate for these limitations by providing specific information in the reconciliation included in this press release regarding the GAAP amounts excluded from the non-GAAP financial measures. In addition, as noted above, we evaluate the non-GAAP financial measures together with the most directly comparable GAAP financial information.
