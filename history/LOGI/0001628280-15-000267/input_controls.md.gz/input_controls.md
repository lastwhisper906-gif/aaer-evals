# LOGI 10-Q controls and the auditor's report


## item_4_controls

[0001628280-15-000267:item_4_controls:1]
ITEM 4.   CONTROLS AND PROCEDURES

[0001628280-15-000267:item_4_controls:2]
Disclosure Controls and Procedures

[0001628280-15-000267:item_4_controls:3]
As of the end of the period covered by this Quarterly Report on Form 10-Q, Logitech carried out an evaluation, under the supervision and with the participation of our management, including our Chief Executive Officer and our Principal Financial and Accounting Officer, of the effectiveness of our disclosure controls and procedures, (as defined in Rule 13a-15(e) under the Securities and Exchange Act of 1934, as amended, (“the Exchange Act”)). Disclosure controls and procedures are controls and other procedures designed to reasonably assure that information required to be disclosed in our reports filed or submitted under the Exchange Act, such as this Quarterly Report on Form 10-Q, is recorded, processed, summarized and reported within the time periods specified in the Securities and Exchange Commission’s rules and forms. Disclosure controls and procedures are also designed to reasonably assure that this information is accumulated and communicated to our management, including the Chief Executive Officer and the Principal Financial and Accounting Officer, to allow timely decisions regarding required disclosure.

[0001628280-15-000267:item_4_controls:4]
Based on that evaluation, Logitech’s Chief Executive Officer and Principal Financial and Accounting Officer have concluded that, as of December 31, 2014, our disclosure controls and procedures were not effective as a result of the material weaknesses that existed in our internal control over financial reporting described below.

[0001628280-15-000267:item_4_controls:5]
Notwithstanding the material weaknesses discussed below, our Chief Executive Officer and Principal Financial and Accounting Officer have concluded that the consolidated financial statements included in this report fairly present, in all material respects, our financial condition, results of operations and cash flows for the periods presented in conformity with accounting principles generally accepted in the United States.

[0001628280-15-000267:item_4_controls:6]
Material Weaknesses in Internal Control over Financial Reporting

[0001628280-15-000267:item_4_controls:7]
A material weakness is a deficiency, or combination of deficiencies, in internal control over financial reporting, such that there is a reasonable possibility that a material misstatement of the annual or interim financial statements will not be prevented or detected on a timely basis. Management identified the following material weaknesses as of March 31, 2014 that continued to exist as of December 31, 2014:

[0001628280-15-000267:item_4_controls:8]
We did not maintain an effective control environment as former finance management exercised bad judgment and failed to provide effective oversight, which resulted in ineffective information and communication, whereby certain of the Company’s finance personnel did not adequately document and communicate accounting issues across the organization, including to our independent registered public accounting firm. Additionally, there was an insufficient complement of personnel with appropriate accounting knowledge, experience and competence, resulting in incorrect conclusions in the application of generally accepted accounting principles.

[0001628280-15-000267:item_4_controls:9]
The above material weaknesses contributed to the following material weaknesses:

[0001628280-15-000267:item_4_controls:10]
The Company did not design and maintain effective controls related to developing an appropriate methodology to accrue the costs of product warranties given to end customers, including an on-going review of the assumptions within the methodology to determine the completeness and accuracy of the warranty accrual. While this material weakness did not result in any material misstatement of our historical financial statements, it did result in adjustments to our cost of goods sold and warranty accrual accounts in the first quarter of fiscal 2014 and revisions to the Company’s consolidated financial statements for fiscal 2013, 2012 and 2011, and interim periods in fiscal 2013 and 2012. Such revisions were disclosed in the Company’s Form 10- K/A filed on August 7, 2013;

[0001628280-15-000267:item_4_controls:11]
The Company did not design and maintain effective controls to consider all relevant information and document the underlying assumptions in our assessment of the valuation of finished goods, work in process and components inventory, including non-cancelable orders for such inventory, related to our now discontinued Revue product. This material weakness resulted in an incorrect application of generally accepted accounting principles that resulted in a material misstatement of inventory, cost of goods sold and supplier liability accrual accounts and a restatement of the Company’s consolidated financial statements for fiscal 2012 and 2011 and the first quarter of fiscal 2012;

[0001628280-15-000267:item_4_controls:12]
The Company did not design and maintain effective controls over the review of supporting information to determine the completeness and accuracy of the consolidated statement of cash flows, the consolidated statement of comprehensive income (loss) and disclosures in the notes to the consolidated financial statements. While this material weakness did not result in any material misstatement of our historical financial statements, it did result in audit adjustments to the consolidated statement of cash flows, the consolidated statement of comprehensive income (loss) and disclosures in the notes to the Company’s fiscal 2013 consolidated financial statements and similar revisions to our interim consolidated financial statements for the first three interim periods in fiscal 2013, as applicable to the interim consolidated financial statements.

[0001628280-15-000267:item_4_controls:13]
Additionally, these material weaknesses could result in further misstatements of the account balances or disclosures that would result in a material misstatement to the annual or interim consolidated financial statements that would not be prevented or detected.

[0001628280-15-000267:item_4_controls:14]
Management’s Plan to Remediate the Material Weaknesses

[0001628280-15-000267:item_4_controls:15]
In September 2013, the Company hired a new Principal Financial and Accounting Officer who has implemented and continues to implement changes in our internal control over financial reporting to address these material weaknesses, including those identified in our recently completed independent investigation. Our Board of Directors has full confidence in its current management under the leadership of the Chief Executive Officer and Principal Financial and Accounting Officer and we take the integrity of our financial statements seriously. We continue to evaluate the effectiveness of our remediation efforts, including demonstrating that the new or improved controls operate effectively for a reasonable period of time and will continue to make additional changes, if appropriate. If not remediated, these material weaknesses could result in further material misstatements to our financial statements. The following changes to our internal control over financial reporting have been implemented or will be implemented as soon as practicable:

[0001628280-15-000267:item_4_controls:16]
•Provide training in order to enhance the level of communication and understanding of internal controls with key individuals that provide critical information used in financial accounting and reporting on matters relating to business and operations, which impact financial reporting;

[0001628280-15-000267:item_4_controls:17]
•Identify skills gaps within the global finance and accounting organization and recruit resources with appropriate experience and technical expertise to fill gaps, including in the area of SEC reporting and technical accounting.

[0001628280-15-000267:item_4_controls:18]
•Implement a more comprehensive process for review of the financial statements;

[0001628280-15-000267:item_4_controls:19]
•Implement a policy requiring formal documentation of the conclusions and basis for conclusions for all significant accounting positions and financial reporting issues, by finance and accounting personnel with sufficient technical competence, including review and approval by the appropriate level of management;

[0001628280-15-000267:item_4_controls:20]
•Implement a revised and documented methodology and related internal controls over the accrual of warranty costs, including an on-going review of the assumptions within the methodology, the capture of all relevant costs, relating to product warranties given to end customers and appropriate review of the accrual each quarter;

[0001628280-15-000267:item_4_controls:21]
•Clarify existing policy and enhance procedures over inventory valuation, including lower of cost or market (LCM) and excess and obsolete reserve calculations, determining that all relevant information is considered, including future demand forecasts, and that conclusions reached are subject to a comprehensive review as well as ongoing evaluation;

[0001628280-15-000267:item_4_controls:22]
•Implement new controls and improve existing controls over financial reporting, including controls with respect to disclosures in the notes to the consolidated financial statements, and the preparation, review, and approval of the consolidated statement of cash flows and consolidated statement of comprehensive income (loss).

[0001628280-15-000267:item_4_controls:23]
Status as of March 31, 2014

[0001628280-15-000267:item_4_controls:24]
During the period ended March 31, 2014, we implemented the following changes to our internal control over financial reporting:

[0001628280-15-000267:item_4_controls:25]
•Established a Finance and Accounting leadership team, including a new Principal Financial and Accounting Officer, a new Vice President of Internal Audit, a new Assistant Corporate Controller (the latter two who joined in the fourth quarter of fiscal year 2014) subsequently promoted to Corporate Controller, and a new Senior Director of Finance Operations, to strengthen oversight of the team and improve the design, implementation, execution and supervision of internal controls within the organization. Hired experienced additional technical resources in the area of Corporate Controllership Group, SEC Reporting, Financial Planning and Analysis, Operations Finance, and Regional Controllership Group;

[0001628280-15-000267:item_4_controls:26]
•Leveraged the services of consulting firms, until we could hire resources with the required skills to strengthen our internal controls, documentation and communication in the SEC reporting process.

[0001628280-15-000267:item_4_controls:27]
•Hired subject matter experts in the area of Operations Finance to design and oversee improved information and communication processes and other internal controls relating to warranty accruals and inventory reserves;

[0001628280-15-000267:item_4_controls:28]
•Implemented a new methodology for identifying and accruing costs relating to product warranty, including documenting and evaluating the assumptions used and determining appropriate supervision and review each quarter;

[0001628280-15-000267:item_4_controls:29]
•Starting in the fourth quarter of fiscal year 2014, implemented a process to enhance the nature and extent of review of Forms 10-Q and 10-K by a team lead by the new Assistant Controller, a more robust process for disclosure committee meetings, and a final review of these filings with the Principal Financial and Accounting Officer. The Principal Financial and Accounting Officer and the Assistant Controller in turn report the results of this process to the Financial Close, Disclosure and Audit Committees in formal quarterly meetings;

[0001628280-15-000267:item_4_controls:30]
•Provided training to key individuals that provide critical information used in financial accounting and reporting to reinforce pre-established and new controls to improve our ability to detect potential misstatements in our internally prepared reports, analysis and financial records.

[0001628280-15-000267:item_4_controls:31]
Fiscal 2015 Current Status

[0001628280-15-000267:item_4_controls:32]
Further to the above measures, during the period April to December 2014, we have taken further measures to strengthen the processes and controls relating to financial reporting. These measures include:

[0001628280-15-000267:item_4_controls:33]
•Under our new Chief Executive Officer and Principal Financial and Accounting Officer, establishing communications and new processes and controls that allows frequent open communication with key internal stakeholders, our advisors, and our independent registered public accounting firm, on key business and operational matters impacting financial reporting;

[0001628280-15-000267:item_4_controls:34]
•Enhancing the Company’s representation letter control. The Company had a representation letter control, wherein detailed questionnaires containing over 60 questions are sent to over 50 senior level employees of the Company. The feedback received is reviewed by the Controllership Group and appropriate actions are initiated, as a normal process. Effective in the first quarter of fiscal year 2015, the detailed questionnaires and a listing of the responses received and resolution of the issues identified are reviewed by the Controller, and are being shared with our independent registered public accounting firm in order to further enhance communication;

[0001628280-15-000267:item_4_controls:35]
•Strengthening our inventory valuation control through increased standardization and consideration of all relevant inputs including aging, historical sales data, product life cycles and market acceptance;

[0001628280-15-000267:item_4_controls:36]
•Implementing a policy requiring formal documentation of the conclusions and basis for conclusions for all significant accounting positions and financial reporting issues, by finance and accounting personnel with sufficient technical competence, including review and approval by the appropriate level of management;

[0001628280-15-000267:item_4_controls:37]
•Implementing a policy documenting and governing the methodology and related internal controls over the accrual of warranty costs, including an on-going review of the assumptions within the methodology, the capture of all relevant costs relating to product warranties given to end customers and appropriate review of the accrual each quarter;Clarifying existing accounting policies and enhancing procedures over inventory valuation, including lower of cost or market (“LCM) and excess and obsolete reserve calculations, determining that all relevant information is considered, including future demand forecasts, and that conclusions reached are subject to a comprehensive review as well as ongoing evaluation; and

[0001628280-15-000267:item_4_controls:38]
•Clarifying existing accounting policies and enhancing procedures over other processes impacting financial reporting, including but not limited to revenue recognition, expense and commitment authorization, prepaid and other assets, accrual, and journal entries.

[0001628280-15-000267:item_4_controls:39]
Our management believes the foregoing efforts will effectively remediate the material weaknesses after these controls have operated effectively for a reasonable period of time. As we continue to evaluate and work to improve our internal control over financial reporting, management may determine to take additional measures to address the material weaknesses or determine to modify the remediation plan described above.

[0001628280-15-000267:item_4_controls:40]
Changes in Internal Control over Financial Reporting

[0001628280-15-000267:item_4_controls:41]
The changes in the Company’s internal control over financial reporting during the three months ended December 31, 2014, that have materially affected, or are reasonably likely to materially affect, the Company’s internal control over financial reporting, are discussed above in Management’s Plan to Remediate the Material Weaknesses.

[0001628280-15-000267:item_4_controls:42]
Limitations on the Effectiveness of Controls

[0001628280-15-000267:item_4_controls:43]
The Company’s management, including the Chief Executive Officer and Principal Financial and Accounting Officer, does not expect that the Company’s disclosure controls and procedures or internal control over financial reporting will prevent all error and all fraud. Internal control over financial reporting, no matter how well designed and operated, can provide only reasonable, not absolute, assurance that the objectives will be met. Because of the inherent limitations in internal control over financial reporting, no evaluation of controls can provide absolute assurance that all control issues and instances of fraud, if any, within the Company have been detected.

[0001628280-15-000267:item_4_controls:44]
These inherent limitations include the realities that judgments in decision making can be faulty and that breakdowns can occur because of simple error or mistake. Controls can also be circumvented by the individual acts of some persons, by collusion of two or more people, or by management override of the controls. The design of any system of controls is based in part on certain assumptions about the likelihood of future events, and there can be no assurance that any design will succeed in achieving its stated goals under all potential future conditions. Over time, controls may become inadequate because of changes in conditions or deterioration in the degree of compliance with policies or procedures. Because of the inherent limitations in a cost-effective control system, misstatements due to error or fraud may occur and not be detected.
