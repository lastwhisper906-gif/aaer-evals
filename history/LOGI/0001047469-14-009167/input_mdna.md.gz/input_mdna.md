# LOGI MD&A — 0001047469-14-009167


## mdna

[0001047469-14-009167:mdna:1]
ITEM 7.    MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001047469-14-009167:mdna:2]
Restatement and Revision of Previously Issued Consolidated Financial Statements

[0001047469-14-009167:mdna:3]
As we announced on May 21, 2014, the Audit Committee, with the assistance of independent advisors, began an independent
investigation of certain accounting matters related to our previously issued financial statements.

[0001047469-14-009167:mdna:4]
On
September 3, 2014, we announced that, in connection with this investigation, the Audit Committee, on the recommendation of management, concluded that previously issued
financial statements for fiscal years 2011 and 2012 and the first quarter of fiscal year 2012 could no longer be relied on due to an accounting misstatement for inventory valuation reserves for
Logitech's now-discontinued Revue product. As a result, we recorded an adjustment to increase cost of goods sold, and to increase inventory valuation reserves and the accrual for supplier liability
for components related to our now discontinued Revue product by $30.7 million during the fourth quarter of the fiscal year ended March 31, 2011, and recorded a decrease to cost of goods
sold by $34.1 million in the quarter ended June 30, 2011, and an increase to cost of goods sold by $3.4 million in the remainder of fiscal year 2012. As a result, net income and
net income per share for the quarter and year ended March 31, 2011 was reduced by $30.7 million and $0.17 per share, respectively, with net income and net income per share in the quarter
ended June 30, 2011 increasing by $34.1 million and $0.19 per share, respectively, and net income and net income per share in the remainder of fiscal year 2012 decreasing by
$3.4 million and $0.02 per share, respectively. In conjunction with recording of the adjustments related to this restatement, we recorded other immaterial corrections to the consolidated
financial statements or financial information included in this Form 10-K for the fiscal years ended March 31, 2013, 2012, 2011 and 2010. For further discussion of the Audit Committee
investigation, see Note 2, Restatement and Revision of Previously Issued Financial Statements, to the Consolidated Financial Statements included
in Part II—Item 8, Financial Statements and Supplementary Data.

[0001047469-14-009167:mdna:5]
The
Audit Committee has completed its independent investigation and found that, in connection with its quarterly close processes, up until June 2013, the finance organization would
compile lists of financial items, which included significant accounting entries recorded during the quarter, late
accounting entries, disclosure items and certain other items with potential accounting implications. The lists used to track these financial items appear to have been primarily shared within certain
parts of the finance organization and were not shared with our independent registered public accounting firm. Typically, there were between approximately thirty to fifty items per quarter on these
lists and there were multiple versions of these lists per quarter, as items were added, removed and changed. Some of the items on the list were discussed with our independent registered public
accounting firm while others were not.

[0001047469-14-009167:mdna:6]
As
part of the independent investigation, it was determined that nine historical items from these lists during a five year period should have been recorded in an earlier period or a
different amount should have been recorded. The largest item relates to the now-discontinued Revue product and is the cause for the restatement. Two items—the warranty accrual and the
amortization of certain intangible assets—were on the lists in prior periods and were not addressed in a timely manner before we corrected them in our revised Form 10-K/A filed on
August 7, 2013. Certain former finance employees signed the May 30, 2013 management representation letter to our independent registered public accounting firm without disclosing these
issues and, as a result, the management representation letter was inaccurate on this point. Six items

[0001047469-14-009167:mdna:7]
are
not material individually or in aggregate to any of the annual or interim periods reported but are nevertheless being corrected in these restated consolidated financial statements.

[0001047469-14-009167:mdna:8]
There
are two elements to the restatement related to the Revue product: (1) a lower of cost or market ("LCM") charge based on the net realizable value of finished goods and work
in process on-hand inventory and non-cancelable orders for such inventory, and (2) an excess and obsolescence charge for non-cancelable orders for inventory components. The Audit Committee
found that certain former members of the finance organization had information that was not considered, that showed a future loss that was estimable and probable before the filing of the
Form 10-K on May 27, 2011 and that such loss was not recorded in our fiscal year 2011 financial statements. Certain former members of the finance organization erroneously accounted for
the LCM charge in fiscal year 2011 based on the current price or on price reductions instead of considering available contemporaneous evidence of anticipated future price reductions and losses which
were estimable and probable at the time. In addition, the Audit Committee found that a management representation letter dated May 27, 2011 to our independent registered public accounting firm
incorrectly stated that probable future pricing adjustments were considered in the LCM calculation. With respect to the Revue components, certain former members of the finance organization did not
consider all available information and therefore did not record a charge in the fourth quarter of fiscal year 2011 for non-cancelable orders related to components considered excess and obsolete. The
analysis erroneously assumed the components would be manufactured into finished goods, though there was information available that showed that the components would not be manufactured into finished
goods. This information was not reflected in our accounting or provided to our independent registered public accounting firm. The Audit Committee found that there was not an adequate basis for the
historical accounting treatment of the components in the fourth quarter of fiscal year 2011.

[0001047469-14-009167:mdna:9]
Overview of Our Company

[0001047469-14-009167:mdna:10]
Logitech is a world leader in products that connect people to the digital experiences they care about. Spanning multiple computing,
communication and entertainment platforms, we develop and market innovative hardware and software products that enable or enhance digital navigation, music and video entertainment, gaming, social
networking and audio and video communication over the Internet. We have two reporting segments: peripherals and video conferencing.

[0001047469-14-009167:mdna:11]
Our
peripherals segment encompasses the design, manufacturing and marketing of peripherals for PCs, tablets and other digital platforms. Our products for home and business PCs include
mice, trackballs, keyboards, interactive gaming controllers, multimedia speakers, headsets and webcams. Our tablet accessory products include keyboards, keyboard cases and covers, and smart phone
accessories. Our Internet communications products include webcams, conference cams and headsets. Our digital music products include wireless speakers, earphones, and custom in-ear monitors. Our gaming
products include mice, keyboards, headsets and gaming controllers. For home entertainment and home control systems, we offer the Harmony line of advanced remote controls. Since fiscal year 2013, we
have been exiting other non-strategic products, such as speaker docks and headphones, and continue to evaluate non-strategic products as part of our ongoing efforts to strengthen our overall
portfolio.

[0001047469-14-009167:mdna:12]
Within
our peripherals segment, we classify our retail product categories as growth, profit maximization, and non-strategic. Our growth product categories are: PC Gaming, Tablet &
Other Accessories, and Mobile Speakers. Our profit maximization categories are: Pointing Devices, PC Keyboards & Desktops, Audio-PC & Wearables, Video, and Remotes.

[0001047469-14-009167:mdna:13]
Our
brand, portfolio management, product development and engineering teams in our peripherals segment are responsible for product strategy, technological innovation, product design and
development and to bring our products to market.

[0001047469-14-009167:mdna:14]
Our global marketing organization is responsible for developing and building the Logitech brand, consumer insights, public relations, social media and digital
marketing. Our regional retail sales and marketing activities are organized into three geographic areas: Americas (North and South America), EMEA (Europe, Middle East and Africa) and Asia Pacific
(including, among other countries, China, Taiwan, Japan and Australia).

[0001047469-14-009167:mdna:15]
We
sell our peripherals products to a network of retailers, including direct sales to retailers and indirect sales through distributors. Our worldwide retail network includes wholesale
distributors, consumer electronics retailers, mass merchandisers, specialty electronics, computers and telecommunications stores, value-added resellers and online merchants. Sales of our retail
peripherals were 88%, 87% and 86% of our net sales for fiscal years 2014, 2013 and 2012, respectively. The large majority of our revenues have historically been derived from sales of our peripherals
products for use by consumers. Our OEM customers include several of the world's largest PC manufacturers. Sales to OEM customers were 6%, 7% and 8% of our net sales for fiscal years 2014, 2013 and
2012, respectively.

[0001047469-14-009167:mdna:16]
Our
video conferencing segment encompasses the design, manufacturing and marketing of Lifesize branded video conferencing products, infrastructure and services for the enterprise, public
sector and other small to medium business markets. Video conferencing products include scalable high-definition, or HD, video communication endpoints, HD video conferencing systems with integrated
monitors, video bridges, cloud-based video conferencing solution and other infrastructure software and hardware to support large-scale video deployments and services to support these products. The
video conferencing segment maintains a separate marketing and sales organization, which sells Lifesize products and services worldwide. Video conferencing product development and product management
organizations are separate, but coordinated with our peripherals business, particularly our Consumer Computing Platform group. We sell our video conferencing products and services to distributors,
value-added resellers, OEMs and, occasionally, direct enterprise customers. Net sales of video conferencing products were 6%, 7% and 6% of our net sales in the fiscal year 2014, 2013 and 2012,
respectively. During fiscal year 2013, we recorded goodwill impairment charges of $214.5 million related to our video conferencing reporting segment.

[0001047469-14-009167:mdna:17]
We
seek to fulfill the increasing demand for interfaces between people and the expanding digital world across multiple platforms and user environments. The interface evolves as
platforms, user models and our target markets evolve. As access to digital information has expanded, we have extended our focus to mobile devices, the digital home, and the enterprise as access points
to the Internet and the digital world. All of these platforms require interfaces that are customized according to how the devices are used. We believe that continued investment in product research and
development is critical to creating the innovation required to strengthen our competitive advantage and to drive future sales growth. We are committed to identifying and meeting current and future
consumer trends with new and improved product technologies, partnering with others where our strengths are complementary, as well as leveraging the value of the Logitech and Lifesize brands from a
competitive, channel partner and consumer experience perspective.

[0001047469-14-009167:mdna:18]
We
believe that innovation, design and product quality are important to gaining market acceptance and maintaining market leadership.

[0001047469-14-009167:mdna:19]
We
have been expanding the categories of products we sell and entering new markets, such as the markets for mobile device accessories. As we do so, we are confronting new competitors,
many of which have more experience in the categories or markets and have greater marketing resources and brand name recognition than we have. In addition, because of the continuing convergence of the
markets for computing devices and consumer electronics, we expect greater competition in the future from well-established consumer electronics companies in our new categories as well as future ones we
might enter. Many of these companies have greater financial, technical, sales, marketing and other resources than we have.

[0001047469-14-009167:mdna:20]
50

[0001047469-14-009167:mdna:21]
The
peripherals and video conferencing industries are intensely competitive. The peripherals industry is characterized by platform evolution, short product life cycles, continual
performance enhancements, rapid adoption of technological and product advancements by competitors in our retail markets and price sensitivity in the OEM market. We experience aggressive price
competition and other promotional activities from our primary competitors and from less-established brands, including brands owned by some retail customers known as house brands, in response to
declining consumer demand in both mature retail and OEM markets. We may also encounter more competition if any of our competitors in one or more categories decide to enter other categories in which we
currently operate.

[0001047469-14-009167:mdna:22]
From
time to time, we may seek to partner with, or acquire when appropriate, companies that have products, personnel, and technologies that complement our strategic direction. We
continually review our product offerings and our strategic direction in light of our profitability targets, competitive conditions, changing consumer trends and the evolving nature of the interface
between the consumer and the digital world.

[0001047469-14-009167:mdna:23]
Summary of Financial Results

[0001047469-14-009167:mdna:24]
Our total net sales for fiscal year 2014 increased 1% in comparison to fiscal year 2013. Increases in our retail sales were partially
offset by decreases in video conferencing sales.

[0001047469-14-009167:mdna:25]
Retail
sales during fiscal year 2014 increased 2% and units sold decreased 3%, compared to fiscal year 2013. Retail sales increased 9% in Americas and 2% in Asia Pacific, partially
offset by a decrease of 4% in EMEA. If foreign currency exchange rates had been the same in fiscal year 2014 and 2013, the percentage changes in our constant dollar retail sales would have been an
increase of 1% for total retail sales, an increase of 9% in Americas, an increase of 6% in the Asia Pacific, and a decrease of 7% in the EMEA regions.

[0001047469-14-009167:mdna:26]
OEM
sales during fiscal year 2014 remained flat, compared to fiscal year 2013, with OEM sales of $141.7 million during fiscal year 2014. OEM units sold remained flat during fiscal
year 2014, compared to fiscal year 2013.

[0001047469-14-009167:mdna:27]
Sales
of Lifesize video conferencing products, which were 6% of total net sales during fiscal year 2014, decreased 12% during fiscal year 2014, compared to fiscal year 2013, due to a
combination of a changing industry landscape caused by a shift to less expensive, cloud-based video conferencing solutions and, an evolving Lifesize product line. During the second quarter of fiscal
year 2014, we implemented a comprehensive restructuring at Lifesize as part of our efforts to reposition the business and achieve profitability by the end of fiscal year 2014. This restructuring
included reduction in staffing as well as an exit from non-strategic product lines. This restructuring resulted in a return to profitability in the third quarter of fiscal year 2014 before charges for
amortization of intangible assets, share based
compensation, and restructuring. During fiscal year 2013, we recorded goodwill impairment charges of $214.5 million related to our video conferencing reporting segment.

[0001047469-14-009167:mdna:28]
Our
gross margin for fiscal year 2014 increased to 34.2%, compared to 33.8% for fiscal year 2013. The increase in gross margin primarily resulted from cost improvements in some of our
PC-related categories and from actions we took during fiscal year 2013 to streamline our product portfolio.

[0001047469-14-009167:mdna:29]
Operating
expenses for fiscal year 2014 were 30.6% of net sales, compared to 45.8% for fiscal year 2013. The decrease in total operating expenses as a percentage of net sales was
primarily due to a $216.7 million impairment charge of goodwill and other assets during fiscal year 2013 and decreases of $29.9 million in restructuring charges and $52.1 million
in marketing and selling expenses due to headcount reductions as a result of restructuring and lower sales and marketing investment in primarily music products.

[0001047469-14-009167:mdna:30]
Net
income for fiscal year 2014 was $74.3 million, compared to a net loss of $227.5 million for fiscal year 2013. This improvement primarily resulted from a
$216.7 million impairment charge of goodwill and

[0001047469-14-009167:mdna:31]
51

[0001047469-14-009167:mdna:32]
other
assets related to our Lifesize business during fiscal year 2013 and decreases of $29.9 million in restructuring charges and $52.1million in marketing and selling expenses, partially
offset by a shift from a $25.8 million benefit from income taxes for fiscal year 2013 to a $3.3 million provision for income taxes for fiscal year 2014.

[0001047469-14-009167:mdna:33]
Trends in Our Business

[0001047469-14-009167:mdna:34]
Our sales of PC peripherals for use by consumers in Americas and Europe have historically made up the large majority of our revenues.
In the last several years, the PC market has changed dramatically and there continues to be significant weakness in the global market for new PCs. This weakness had a negative impact on our net sales
in all of our PC-related categories. We believe that this weakness reflects the growing popularity of tablets and smartphones as mobile computing devices.

[0001047469-14-009167:mdna:35]
We
believe our future growth will be determined by our ability to rapidly create innovative products across multiple digital platforms, especially for PC Gaming and accessories for
mobility-related products, including tablets, smartphones, Gaming and other mobile devices and for digital music, including wireless speakers, to limit and offset the decline in our PC peripherals. We
pursue growth opportunities in emerging markets, mobility-related products, products for digital music and enterprise markets. The following discussion represents key trends specific to each of our
two operating segments, peripherals and video conferencing.

[0001047469-14-009167:mdna:36]
Trends Specific to our Peripherals Segment

[0001047469-14-009167:mdna:37]
PC Peripherals:    Although the installed base of PC users is large, consumer demand for new PCs has declined in recent years, and we
believe it will
continue to decline in future years. As a consequence, consumer demand for PC peripherals is slowing, or in some cases declining. As the quality of PC-embedded webcams improves along with the
increasing popularity of tablets and smartphones with embedded webcams, we expect future sales of our PC-connected webcams will continue to be weak (or continue to decline on a year over year basis).
The PC Gaming platform continues to show strong growth as online gaming and multi-platform experiences gain greater popularity and gaming content becomes increasingly more demanding. We believe
Logitech is well positioned to benefit from the PC Gaming market growth.

[0001047469-14-009167:mdna:38]
Enterprise Market.    We are continuing our efforts to create and sell products and services to enterprises. For example, we have
introduced the
Logitech ConferenceCam CC3000e video conference solution designed for small to medium conference rooms. Growing our enterprise peripherals business will continue to require investment in selected
business-specific products, targeted product marketing, and sales channel development.

[0001047469-14-009167:mdna:39]
Tablets and Other Accessories.    The increasing popularity of smaller, mobile computing devices, such as tablets with touch interfaces,
have created
new markets and usage models for peripherals and accessories. During fiscal year 2014, we continued to expand and leverage our success in this category through the introductions of keyboard folios for
the iPad and iPad mini, and keyboard covers and folios for the iPad Air. During this time, we also introduced keyboard folios for the Samsung Galaxy tablet as well as the Wired Keyboard for the iPad,
designed primarily for use in the classroom.

[0001047469-14-009167:mdna:40]
Mobile Speakers.    We believe that digital music, the seamless consumption of digital audio content on mobile devices, presents a growth
opportunity
for us. Many consumers listen to music as a popular entertainment activity, fueled by the growth in smart phones, tablets, music services and Internet radio. We believe we have a solid foundation of
audio speaker solutions to satisfy consumers' needs for music consumption, in the digital music speaker space. We continue to invest in the UE brand and introduce innovative new products in this
category such as UE BOOM, a wireless speaker with 360-degree stereo sound.

[0001047469-14-009167:mdna:41]
52

[0001047469-14-009167:mdna:42]
OEM Business.    Sales of our OEM mice and keyboards have historically made up the bulk of our OEM sales. In recent years, there has been
a dramatic
shift away from desktop PCs and there continues to be significant weakness in the global market for PCs, which has adversely affected our sales of OEM mice and keyboards, all of which are sold with
name-brand desktop PCs. We expect this trend to continue and for OEM sales to comprise a smaller percentage of our total sales in the future.

[0001047469-14-009167:mdna:43]
Trends in Non-Strategic Peripherals Product Categories.    Some of our other peripherals product categories are experiencing significant
market
challenges. During the quarter ended December 31, 2012, we identified a number of product categories that no longer fit with our strategic direction at that time. We will continue to evaluate
our product offerings and will exit those which no longer support our strategic direction.

[0001047469-14-009167:mdna:44]
Trends Specific to our Video Conferencing Segment

[0001047469-14-009167:mdna:45]
The trend among businesses and institutions to use video conferencing offers a long-term growth opportunity for us. However, the
overall video conferencing industry has experienced a slowdown in recent quarters. In addition, there has been an increase in the competitive environment. This situation resulted in a
$214.5 million goodwill impairment charge in fiscal year 2013. During the quarters ended March 31, 2013 and September 30, 2013, we implemented restructuring plans affecting our
video conferencing operating segment to align its organization to its strategic priorities of increasing focus on a tighter range of products, expanding cloud-based video conferencing services and
improving profitability. We believe the growth in our video conferencing segment depends in part on our ability to increase sales to enterprises with existing installed bases of equipment supplied by
our
competitors and to enterprises that may purchase such competitor equipment in the future. We believe the ability of our Lifesize products to interoperate with the equipment of other
telecommunications, video conferencing or telepresence equipment suppliers to be a key factor in purchasing decisions by current or prospective Lifesize customers. In addition, Lifesize has broadened
its product portfolio to include infrastructure, cloud services and other offerings which require different approaches to developing customer solutions. We are also seeking to offer Lifesize products
designed to enhance the use of mobile devices in video conferencing applications.

[0001047469-14-009167:mdna:46]
Critical Accounting Estimates

[0001047469-14-009167:mdna:47]
The preparation of financial statements and related disclosures in conformity with U.S. GAAP (Generally Accepted Accounting
Principles in the United States of America) requires us to make judgments, estimates and assumptions that affect reported amounts of assets, liabilities, net sales and expenses, and the disclosure of
contingent assets and liabilities.

[0001047469-14-009167:mdna:48]
We
consider an accounting estimate critical if it: (i) requires management to make judgments and estimates about matters that are inherently uncertain; and (ii) is
important to an understanding of our financial condition and operating results.

[0001047469-14-009167:mdna:49]
We
base our estimates on historical experience and on various other assumptions we believe to be reasonable under the circumstances. Although these estimates are based on management's
best knowledge of current events and actions that may impact us in the future, actual results could differ from those estimates. Management has discussed the development, selection and disclosure of
these critical accounting estimates with the Audit Committee of the Board of Directors.

[0001047469-14-009167:mdna:50]
We
believe the following accounting estimates are most critical to our business operations and to an understanding of our financial condition and results of operations, and reflect the
more significant judgments and estimates used in the preparation of our consolidated financial statements.

[0001047469-14-009167:mdna:51]
Accruals for Customer Programs

[0001047469-14-009167:mdna:52]
We record accruals for product returns, cooperative marketing arrangements, customer incentive programs and pricing programs. An
allowance against accounts receivable is recorded for accruals and program activity related to our direct customers and those indirect customers who receive payments for program activity through our
direct customers. An accrued liability is recorded for accruals and program activity related to our indirect customers who receive payments directly and do not have a right of offset against a
receivable balance. The estimated cost of these programs is recorded as a reduction of revenue, as cost of sales or as an operating expense, if we receive a separately identifiable benefit from the
customer and can reasonably estimate the fair value of that benefit. Significant management judgment and estimates must be used to determine the cost of these programs in any accounting period.

[0001047469-14-009167:mdna:53]
Returns.    We grant limited rights to return products. Return rights vary by customer, and range from just the right to return defective
product to
stock rotation rights limited to a percentage approved by management. Estimates of expected future product returns are recognized at the time of sale based on analyses of historical return trends by
customer and by product, inventories owned by and located at distributors and retailers, current customer demand, current operating conditions, and other relevant customer and product information.
Return trends are influenced by product life cycle status, new product introductions, market acceptance of products, sales levels, product sell-through, the type of customer, seasonality, product
quality issues, competitive pressures, operational policies and procedures and other factors. Return rates can fluctuate over time, but are sufficiently predictable to allow us to estimate expected
future returns.

[0001047469-14-009167:mdna:54]
Cooperative Marketing Arrangements.    We enter into customer marketing programs with many of our distribution and retail customers, and
with certain
indirect partners, allowing customers to receive a credit equal to a set percentage of their purchases of our products, or a fixed dollar credit for various marketing arrangements. The objective of
these arrangements is to encourage advertising and promotional events to increase sales of our products. Accruals for these marketing arrangements are recorded at the time of sale, or time of
commitment, based on negotiated terms, historical experience and inventory levels in the channel.

[0001047469-14-009167:mdna:55]
Customer Incentive Programs.    Customer incentive programs include performance-based incentives and consumer rebates. We offer
performance-based
incentives to our distribution customers, retail customers and indirect partners based on pre-determined performance criteria. Accruals for performance-based incentives are recognized as a reduction
of the sale price at the time of sale. Estimates of required accruals are determined based on negotiated terms, consideration of historical experience, anticipated volume of future purchases, and
inventory levels in the channel. Consumer
rebates are offered from time to time at the Company's discretion for the primary benefit of end-users. Estimated costs of consumer rebates and similar incentives are recorded at the time the
incentive is offered, based on the specific terms and conditions.

[0001047469-14-009167:mdna:56]
Pricing Programs.    We have agreements with certain customers that contain terms allowing price protection credits to be issued in the
event of a
subsequent price reduction. At management's discretion, we also offer special pricing discounts to certain customers. Special pricing discounts are usually offered only for limited time periods or for
sales of selected products to specific indirect and direct partners. Our decision to make price reductions is influenced by product life cycle stage, market acceptance of products, the competitive
environment, new product introductions and other factors. Estimates of expected future pricing actions are recognized at the time of sale based on analyses of historical pricing actions by customer
and by product, inventories owned by and located at distributors and retailers, current customer demand, current operating conditions, and other relevant customer and product information.

[0001047469-14-009167:mdna:57]
We
regularly evaluate the adequacy of our accruals for product returns, cooperative marketing arrangements, customer incentive programs and pricing programs. Future market conditions and
product

[0001047469-14-009167:mdna:58]
transitions
may require us to take action to increase such programs. In addition, when the variables used to estimate these costs change, or if actual costs differ significantly from the estimates, we
would be required to record incremental increases or reductions to revenue or operating expenses. If, at any future time, we become unable to reasonably estimate these costs, recognition of revenue
might be deferred until products are sold to users, which would adversely impact revenue in the period of transition.

[0001047469-14-009167:mdna:59]
Inventory Valuation

[0001047469-14-009167:mdna:60]
We must order components for our products and build inventory in advance of customer orders. Further, our industry is characterized by
rapid technological change, short-term customer commitments and rapid changes in demand.

[0001047469-14-009167:mdna:61]
We
record inventories at the lower of cost or market value and record write-downs of inventories that are obsolete or in excess of anticipated demand or market value. A review of
inventory is performed each fiscal quarter that considers factors including the marketability and product life cycle stage, product development plans, component cost trends, demand forecasts and
current sales levels. Inventory on hand which is not expected to be sold or utilized is considered excess, and we recognize the write-off in cost of sales at the time of such determination. The
write-off is determined by comparison of the current replacement cost with the estimated selling price less any costs of completion and disposal (net realizable value) and the net realizable value
less an allowance for normal profit. At the time of loss recognition, a new per unit, lower-cost basis for that inventory is established and subsequent changes in facts and circumstances would not
result in an increase in the cost basis. If there were an abrupt and substantial decline in demand for Logitech's products or an unanticipated change in technological or customer requirements, we may
be required to record additional write-downs that could adversely affect gross margins in the period when the write-downs are recorded.

[0001047469-14-009167:mdna:62]
Share-Based Compensation Expense

[0001047469-14-009167:mdna:63]
Share-based compensation expense includes compensation expense, reduced for estimated forfeitures. The grant date fair value for stock
options and stock purchase rights is estimated using the Black-Scholes-Merton option-pricing valuation model. The grant date fair value of RSUs (restricted stock units) that vest upon meeting certain
market conditions is estimated using the Monte-Carlo simulation method. The grant date fair value of time-based RSUs is calculated based on the closing market price on the date of grant.

[0001047469-14-009167:mdna:64]
Our
estimates of share-based compensation expense require a number of complex and subjective assumptions including our stock price volatility, employee exercise patterns, future
forfeitures, dividend yield, related tax effects and the selection of an appropriate fair value model. We estimate expected share price volatility based on historical volatility using daily prices
over the term of past options, RSUs or purchase offerings, as we consider historical share price volatility as most representative of future volatility. We estimate expected life based on historical
settlement rates, which we believe are most representative of future exercise and post-vesting termination behaviors. We use historical data to estimate pre-vesting forfeitures, and we record
share-based compensation expense only for those awards that are expected to vest. The dividend yield assumption is based on our history and future expectations of dividend payouts.

[0001047469-14-009167:mdna:65]
The
assumptions used in calculating the fair value of share-based compensation expense and related tax effects represent our best estimates, but these estimates involve inherent
uncertainties and the application of management judgment. As a result, if factors change and we use different assumptions, or if we decide to use a different valuation model, our share-based
compensation expense could be materially different in the future from what we have recorded in the current period, which could materially affect our results of operations.

[0001047469-14-009167:mdna:66]
Accounting for Income Taxes

[0001047469-14-009167:mdna:67]
We operate in multiple jurisdictions and our profits are taxed pursuant to the tax laws of these jurisdictions. Our effective income
tax rate may be affected by the changes in or interpretations of tax laws and tax agreements in any given jurisdiction, utilization of net operating loss and tax credit carryforwards, changes in
geographical mix of income and expense, and changes in our assessment of matters such as the ability to realize deferred tax assets. As a result of these considerations, we must estimate income taxes
in each of the jurisdictions in which we operate. This process involves estimating current tax exposure together with assessing temporary differences resulting from different treatment of items for
tax and accounting purposes. These differences result in deferred tax assets and liabilities, which are included in the consolidated balance sheet.

[0001047469-14-009167:mdna:68]
We
assess the likelihood that our deferred tax assets will be recovered from future taxable income, considering all available evidence such as historical levels of income, expectations
and risks associated with estimates of future taxable income and ongoing prudent and feasible tax strategies. When we determine that we are not able to realize all or part of our deferred tax assets,
an adjustment is charged to earnings in the period when such determination is made. Likewise, if we later determine that it is more likely than not that the deferred tax assets would be realized, the
previously provided valuation allowance would be reversed.

[0001047469-14-009167:mdna:69]
We
make certain estimates and judgments about the application of tax law, the expected resolution of uncertain tax positions and other matters surrounding the recognition and measurement
of uncertain tax benefits. In the event that uncertain tax positions are resolved for amounts different than our estimates, or the related statutes of limitations expire without the assessment of
additional income taxes, we will be required to adjust the amounts of the related assets and liabilities in the period in which such events occur. Such adjustments may have a material impact on our
income tax provision and our results of operations.

[0001047469-14-009167:mdna:70]
Goodwill

[0001047469-14-009167:mdna:71]
We perform our annual goodwill impairment test of each reporting unit as of December 31 and complete the assessment during our
fiscal fourth quarter, or more frequently, if
certain events or circumstances warrant. Events or changes in circumstances which might indicate potential impairment in goodwill include the company-specific factors, including, but not limited to,
stock price volatility, market capitalization relative to net book value, and projected revenue, market growth and operating results. Determining the number of reporting units and the fair value of a
reporting unit requires us to make judgments and involves the use of significant estimates and assumptions. We have two reporting units: peripherals and video conferencing. The allocation of assets
and liabilities to each of our reporting units also involves judgment and assumptions.

[0001047469-14-009167:mdna:72]
The
goodwill impairment assessment involves three tests, Step 0, Step 1 and Step 2. The Step 0 test involves performing an initial qualitative assessment to determine whether it is more
likely than not that the asset is impaired and thus whether it is necessary to proceed to Step 1 and calculate the fair value of the respective reporting unit. We may proceed directly to the Step 1
test without performing the Step 0 test. The Step 1 test involves measuring the recoverability of goodwill at the reporting unit level by comparing the reporting unit's carrying amount, including
goodwill, to the estimated fair value of the reporting unit. The fair value is estimated using an income approach employing a discounted cash flow ("DCF") and a market-based model. The DCF model is
based on projected cash flows from our most recent forecast ("assessment forecast") developed in connection with each of our reporting units to perform the goodwill impairment assessment. The
assessment forecast is based on a number of key assumptions, including, but not limited to, discount rate, compound annual growth rate ("CAGR") during the forecast period, and terminal value. The
terminal value is based on an exit price at the end of the assessment forecast using an earnings multiple applied to the final year of the assessment forecast. The discount rate is applied to the
projected cash flows to reflect the risks inherent in the timing and amount of

[0001047469-14-009167:mdna:73]
the
projected cash flows, including the terminal value, and is derived from the weighted average cost of capital of market participants in similar businesses. The market approach model is based on
applying certain revenue and earnings multiples of comparable companies relevant to each of our reporting units to the respective revenue and earnings metrics of our reporting units. To test the
reasonableness of the fair values indicated by the income approach and the market-based approach, we also assessed the implied premium of the aggregate fair value over the market capitalization
considered attributable to an acquisition control premium, which is the price in excess of a stock market's price that investors would typically pay to gain control of an entity. The discounted cash
flow model and the market approach require the exercise of significant judgment, including assumptions about appropriate discount rates, long-term growth rates for purposes of determining a terminal
value at the end of the discrete forecast period, economic expectations, timing of expected future cash flows, and expectations of returns on equity that will be achieved. Such assumptions are subject
to change as a result of changing economic and competitive conditions. If the carrying amount of the reporting unit exceeds its fair value as determined by these assessments, goodwill is considered
impaired, and the Step 2 test is performed to measure the amount of impairment loss. The Step 2 test measures the impairment loss by allocating the reporting unit's fair value to its assets and
liabilities other than goodwill, comparing the resulting implied fair value of goodwill with its carrying amount, and recording an impairment charge for the difference.

[0001047469-14-009167:mdna:74]
Applicable to Both Reporting Units

[0001047469-14-009167:mdna:75]
We continue to evaluate and monitor all key factors impacting the carrying value of our recorded goodwill, as well as other long-lived
assets. There are a number of uncertainties associated with the key assumptions described above based primarily on the difficulty of predicting our revenues and profitability. Our revenues and
profitability are difficult to predict due to the nature of the markets in which we compete, fluctuating end-user demand, the uncertainty of current and future global economic conditions, and for many
other reasons, including, but not limited to:

[0001047469-14-009167:mdna:76]
•

[0001047469-14-009167:mdna:77]
Our revenues are impacted by consumer demand and future global conditions, which could fluctuate abruptly and
significantly during periods of uncertain economic conditions or geographic distress, as well as from shifts in consumer buying patterns.

[0001047469-14-009167:mdna:78]
•

[0001047469-14-009167:mdna:79]
We must incur a large portion of our costs in advance of sales orders, because we must plan research and production,
order components, buy tooling equipment, and enter into development, sales and marketing, and other operating commitments prior to obtaining firm commitments from our customers. This makes it
difficult for us to rapidly adjust our costs in response to a revenue shortfall.

[0001047469-14-009167:mdna:80]
•

[0001047469-14-009167:mdna:81]
Fluctuations in currency exchange rates can impact our revenues, expenses and profitability because we report our
financial statements in U.S. dollars, whereas a significant portion of our revenues and expenses are in other currencies.

[0001047469-14-009167:mdna:82]
•

[0001047469-14-009167:mdna:83]
The peripherals industry is characterized by short product life cycles, frequent new product introductions, rapidly
changing technology, dynamic consumer demand and evolving industry standards. As a result, we must continually innovate in our new and existing product categories, introduce new products and
technologies, and enhance existing products in order to remain competitive.

[0001047469-14-009167:mdna:84]
•

[0001047469-14-009167:mdna:85]
The video conferencing industry is characterized by continual performance enhancements and large, well-financed
competitors. There is increased participation in the video conferencing market by companies such as Cisco Systems, Inc. and Polycom, Inc., and as a result, we expect competition in the
industry to further intensify.

[0001047469-14-009167:mdna:86]
Should
the actual outcome of some or all of these assumptions differ significantly from the current assumptions, revisions to current cash flow assumptions could cause the fair value of
the reporting units to be significantly different in future periods.

[0001047469-14-009167:mdna:87]
Product Warranty Accrual

[0001047469-14-009167:mdna:88]
We provide for the estimated cost of product warranties at the time the related revenue is recognized based on historical and projected
warranty claim rates, historical and projected cost, and knowledge of specific product failures that are outside of our typical experience. Each quarter, we reevaluate our estimates to assess the
adequacy of our recorded warranty liabilities considering the size of the installed base of products subject to warranty protection and adjust the amounts as necessary. If actual product failure rates
or repair costs differ from estimates, revisions to the estimated warranty liabilities would be required and could materially affect our results of operations.

[0001047469-14-009167:mdna:89]
Results of Operations

[0001047469-14-009167:mdna:90]
We have revised our results of operations for the fiscal year ended March 31, 2013 and restated our results of operations for
the fiscal year ended March 31, 2012. The restatement reflects the results of the independent investigation by the Audit Committee and other corrections identified by the management to the
financial statements. For more information, refer to Note 2 of our Notes to Consolidated Financial Statements in Item 8.

[0001047469-14-009167:mdna:91]
Net Sales

[0001047469-14-009167:mdna:92]
Net sales by channel for fiscal years 2014, 2013 and 2012 were as follows (in thousands):

[0001047469-14-009167:mdna:93]
|  |  |  |  |  |  |  |  | Change |  |
|  |  | Years Ended March 31, |  |
|  |  | 2014 vs. 2013 |  | 2013 vs. 2012 |  |
|  |  | 2014 |  | 2013 |  | 2012 |  |
|  |  |  |  | As Revised |  |  |  |  |  |  |  |
| Retail |  | $ | 1,866,279 |  | $ | 1,821,051 |  | $ | 1,982,783 |  |  | 2 | % |  | (8 | )% |
| OEM |  |  | 141,749 |  |  | 141,186 |  |  | 185,959 |  |  | 0 |  |  | (24 | ) |
| Video conferencing |  |  | 120,685 |  |  | 137,040 |  |  | 147,461 |  |  | (12 | ) |  | (7 | ) |
| Total net sales |  | $ | 2,128,713 |  | $ | 2,099,277 |  | $ | 2,316,203 |  |  | 1 |  |  | (9 | ) |

[0001047469-14-009167:mdna:94]
Retail:

[0001047469-14-009167:mdna:95]
During fiscal year 2014, retail sales increased 2% and units sold decreased 3%, compared to fiscal year 2013. Retail sales increased in
Americas and Asia Pacific and decreased in EMEA during fiscal year 2014, compared to fiscal year 2013. The increase in retail sales is primarily due to triple-digit growth in Mobile Speakers,
double-digit growth in Tablets & Other Accessories and PC Gaming, offset in part by a decline in Audio-PC & Wearables, Video, and our Non-Strategic categories, compared to fiscal year
2013.

[0001047469-14-009167:mdna:96]
During
fiscal year 2013, our retail sales decreased 8% and units sold decreased 7%, compared to fiscal year 2012. We experienced decreases in all three regions during fiscal year 2013,
compared to fiscal year 2012.

[0001047469-14-009167:mdna:97]
OEM:

[0001047469-14-009167:mdna:98]
OEM sales of $141.7 million during fiscal year 2014 remained flat compared to fiscal year 2013. OEM units sold remained flat
during fiscal year 2014 compared with fiscal year 2013. During fiscal year 2013, OEM net sales decreased 24% and units sold decreased 12%, compared to fiscal year 2012. The decrease was primarily due
to lower sales in the keyboard/desktop category and pointing devices.

[0001047469-14-009167:mdna:99]
Lifesize:

[0001047469-14-009167:mdna:100]
During fiscal year 2014, video conferencing net sales decreased 12%, compared to fiscal year 2013. The decrease primarily resulted from
the combination of a changing industry landscape caused by a shift to less expensive, cloud-based video conferencing solutions, an evolving Lifesize product line and challenges

[0001047469-14-009167:mdna:101]
in
execution. During fiscal year 2013, video conferencing net sales decreased 7%, compared to fiscal year 2012. The decrease was reflected in all geographic regions and was impacted by the slowdown in
the overall video conferencing industry in recent years, together with the competitive environment and lower demand related to new product launches.

[0001047469-14-009167:mdna:102]
Sales Denominated in Other Currencies

[0001047469-14-009167:mdna:103]
Although our financial results are reported in U.S. Dollars, a portion of our sales were generated in currencies other than the U.S.
dollar, such as the Euro, Chinese Renminbi, Japanese Yen, Canadian Dollar and Australian Dollar. During fiscal years 2014, 2013 and 2012, 45%, 45% and 45% of our net sales were denominated in
currencies other than the U.S. Dollar, respectively.

[0001047469-14-009167:mdna:104]
Retail Sales by Region

[0001047469-14-009167:mdna:105]
We use sell-through data, which represents sales of our products by our retailer customers to consumers, and by our distributor
customers to resellers, along with other metrics, to assess consumer demand for our products. Sell-through data is subject to limitations due to collection methods and the third-party nature of the
data. Although the sell-through data we obtained typically represents a majority of our retail sales, the customers supplying sell-through data vary by geographic region and from period-to-period. As
a result of these limitations, sell-through data may not be an accurate indicator of actual consumer demand for our products.

[0001047469-14-009167:mdna:106]
Americas

[0001047469-14-009167:mdna:107]
During fiscal year 2014, retail sales in Americas increased 9%, compared to fiscal year 2013. Retail sales increased in Tablet &
Other Accessories, Mobile speakers, PC Gaming, PC Keyboards & Desktops and Pointing Devices, partially offset by decreases in Non-Strategic Other, Audio-PC & Wearables, Remotes, and
Video. The increase in Tablet & Other Accessories was led by sales of our Ultrathin Keyboard Cover for the iPad and from our recently introduced Keyboard Folio suite of products designed for
the iPad, iPad mini and iPad Air. The increase in Mobile Speakers was primarily from the UE BOOM. The increase in PC Gaming was due to the recent launch of our new gaming products. The increase in PC
Keyboards & Desktops was driven by low-end, mid-range and high-end products. Retail sales improved in the United States and Canada during fiscal year 2014, compared to fiscal year 2013. In
addition, retail sell-through increased 9% during fiscal year 2014, compared to fiscal year 2013.

[0001047469-14-009167:mdna:108]
During
fiscal year 2013, Americas decreased 7%, compared to fiscal year 2012. This decrease was primarily from significant decreases in our Non-Strategic Other, Video, Pointing Devices,
Audio- PC & Wearables, Remotes and PC Gaming, partially offset by an increase in Tablets & Other Accessories, due to demand from the Logitech Ultrathin Keyboard Cover for the iPad and
slight increases in PC Keyboards & Desktops and Mobile Speakers. During fiscal year 2013, we experienced weakness primarily in the United States, partially offset by improvements in Mexico and
Brazil. In addition, retail sell-through decreased 5% during fiscal year 2013, compared to fiscal year 2012.

[0001047469-14-009167:mdna:109]
EMEA

[0001047469-14-009167:mdna:110]
During fiscal year 2014, retail sales in EMEA decreased 4%, compared to fiscal year 2013. Retail sales decreased in Pointing Devices,
Video, Audio-PC & Wearables, and Non-Strategic other, partially offset by increases in Tablet & Other Accessories, Mobile Speakers, PC Gaming and Remotes. We experienced a significant
decrease in Germany due to sales challenges which we overcame in the second half of fiscal year 2014. The decrease in Germany was partially offset by an increase in the United Kingdom. In addition,
retail sell-through decreased 4% in Euros during fiscal year 2014, compared to fiscal year 2013.

[0001047469-14-009167:mdna:111]
During
fiscal year 2013, retail sales in EMEA decreased 11%, compared to fiscal year 2012. The decrease was primarily caused by the extreme weakness in the PC market and the continued
macro-

[0001047469-14-009167:mdna:112]
economic
uncertainty across many European countries. The decrease was due to Non-Strategic Other, Pointing Devices, Audio-PC & Wearables, Video, and Mobile Speakers offset in part by
Tablet & Other Accessories, and PC Keyboard & Desktops. During fiscal year 2013, we experienced significant sales decreases in major countries such as Germany, France, Switzerland,
Spain, and the Netherlands.

[0001047469-14-009167:mdna:113]
Asia Pacific

[0001047469-14-009167:mdna:114]
During fiscal year 2014, retail sales in Asia Pacific increased 2%, compared to fiscal year 2013. Retail sales increased in PC Gaming,
Tablet & Other Accessories, Mobile Speakers and Remotes, partially offset by decreases in Non-Strategic Other, Audio- PC & Wearables, Video, and Pointing Devices and PC
keyboards & Desktops. In addition, retail sell-through in Asia Pacific increased 2% during fiscal year 2014, compared to fiscal year 2013.

[0001047469-14-009167:mdna:115]
During
fiscal year 2013, retail sales in Asia Pacific decreased 4%, compared to fiscal year 2012. This decrease was primarily due to decreases in our Non-Strategic Other, remotes, PC
Gaming and Video, partially offset by a significant increase in Tablet & Other Accessories and Mobile Speakers. Decreases by country within the Asia Pacific region were primarily from India,
Australia, Taiwan and South Korea, partially offset by increases in China, New Zealand and Indonesia. Retail sell-through in Asia Pacific increased 2% during fiscal year 2013, compared to fiscal year
2012.

[0001047469-14-009167:mdna:116]
Net Sales by Product Categories

[0001047469-14-009167:mdna:117]
Net sales by product categories for fiscal years 2014, 2013 and 2012 were as follows (in thousands):

[0001047469-14-009167:mdna:118]
|  |  |  |  |  |  |  |  | Change |  |
|  |  | Years Ended March 31, |  |
|  |  | 2014 vs. 2013 |  | 2013 vs. 2012 |  |
|  |  | 2014 |  | 2013* |  | 2012* |  |
|  |  |  |  | As Revised |  |  |  |  |  |  |  |
| Peripherals: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PC Gaming |  | $ | 186,926 |  | $ | 144,512 |  | $ | 186,190 |  |  | 29 | % |  | (22 | )% |
| Tablet & Other Accessories |  |  | 172,484 |  |  | 119,856 |  |  | 44,326 |  |  | 44 |  |  | 170 |  |
| Mobile Speakers |  |  | 87,414 |  |  | 33,408 |  |  | 21,969 |  |  | 162 |  |  | 52 |  |
| Growth |  |  | 446,824 |  |  | 297,776 |  |  | 252,485 |  |  | 50 |  |  | 18 |  |
| Pointing Devices |  |  | 506,884 |  |  | 521,083 |  |  | 559,366 |  |  | (3 | ) |  | (7 | ) |
| PC Keyboards & Desktops |  |  | 415,512 |  |  | 399,144 |  |  | 383,697 |  |  | 4 |  |  | 4 |  |
| Audio-PC &Wearables |  |  | 255,573 |  |  | 292,245 |  |  | 339,394 |  |  | (13 | ) |  | (14 | ) |
| Video |  |  | 137,115 |  |  | 153,060 |  |  | 196,662 |  |  | (10 | ) |  | (22 | ) |
| Remotes |  |  | 67,371 |  |  | 71,641 |  |  | 91,000 |  |  | (6 | ) |  | (21 | ) |
| Profit Maximization |  |  | 1,382,455 |  |  | 1,437,173 |  |  | 1,570,119 |  |  | (4 | ) |  | (8 | ) |
| Other |  |  | 37,000 |  |  | 86,102 |  |  | 160,179 |  |  | (57 | ) |  | (46 | ) |
| Non-Strategic |  |  | 37,000 |  |  | 86,102 |  |  | 160,179 |  |  | (57 | ) |  | (46 | ) |
| OEM |  |  | 141,749 |  |  | 141,186 |  |  | 185,959 |  |  | 0 |  |  | (24 | ) |
|  |  |  | 2,008,028 |  |  | 1,962,237 |  |  | 2,168,742 |  |  | 2 |  |  | (10 | ) |
| Video conferencing |  |  | 120,685 |  |  | 137,040 |  |  | 147,461 |  |  | (12 | ) |  | (7 | ) |
|  |  | $ | 2,128,713 |  | $ | 2,099,277 |  | $ | 2,316,203 |  |  | 1 |  |  | (9 | ) |

[0001047469-14-009167:mdna:119]
*

[0001047469-14-009167:mdna:120]
Certain
products within the retail product families presented in prior years have been reclassified to conform to the current year presentation.

[0001047469-14-009167:mdna:121]
Growth Categories:

[0001047469-14-009167:mdna:122]
PC Gaming

[0001047469-14-009167:mdna:123]
Our retail PC Gaming category comprises PC Gaming mice, keyboards, headsets, gamepads and steering wheels.

[0001047469-14-009167:mdna:124]
During
fiscal year 2014, retail sales of PC Gaming increased 29% and units sold increased 24%, compared to fiscal year 2013. This growth was primarily due to the recent launch of our new
gaming products, including mice, keyboards and headsets. New products made up 23% of total PC Gaming revenue for fiscal year 2014. Our top revenue-generating PC Gaming products included the Logitech
G27 Racing Wheel, the Logitech G930 Wireless Gaming Headset, the G500s Laser Gaming Mouse, the G700s Rechargeable Gaming Mouse, and the G710+ Mechanical Gaming Keyboard.

[0001047469-14-009167:mdna:125]
During
fiscal year 2013, retail sales of PC Gaming decreased 22% and units sold decreased 9%, compared to fiscal year 2012. The decrease was across most of our PC Gaming products, with
the most significant decrease in our steering wheel product category, partially offset by strong sales from select gaming products including the Logitech G930 Wireless Gaming Headsets. The difference
between the decline in gaming sales and the decrease in units sold reflects a product mix shift away from higher-priced steering wheels to lower-priced mice, keyboards and gamepads. The overall
decline in this category primarily reflected an aging product lineup.

[0001047469-14-009167:mdna:126]
Tablet & Other Accessories

[0001047469-14-009167:mdna:127]
Our retail Tablet & Other Accessories category comprises keyboards and covers for tablets and smartphones as well as other
accessories for mobile devices.

[0001047469-14-009167:mdna:128]
During
fiscal year 2014, retail sales of Tablet & Other Accessories increased 44% and units sold increased 87%, compared to fiscal year 2013. The increase was driven by demand for
the Logitech Ultrathin Keyboard Cover for the iPad, as well as strong sales from recently introduced products such as the Logitech Ultrathin Keyboard Cover for the iPad Mini and from the Logitech
Keyboard Folio
suite of products designed for the iPad, iPad mini, and iPad Air. The faster growth in unit shipments reflects the broadening of our portfolio to address a larger portion of the tablet accessory
market, including tablet cases.

[0001047469-14-009167:mdna:129]
During
fiscal year 2013, retail sales of Tablet & Other Accessories represented our strongest product category with an increase of 170% and units sold increase of 124%, compared
to fiscal year 2012. This increase was driven by demand for the Logitech Ultrathin Keyboard Cover, which represented our best selling product across all of our categories.

[0001047469-14-009167:mdna:130]
Mobile Speakers

[0001047469-14-009167:mdna:131]
Our retail Mobile Speakers category includes portable Bluetooth wireless speakers.

[0001047469-14-009167:mdna:132]
During
fiscal year 2014, retail sales of Mobile Speakers increased 162% and units sold increased 88%, compared to fiscal year 2013. The 162% increase in our wireless speakers for
smartphones and tablets was driven by a strong demand primarily for the UE BOOM. Our top revenue-generating wireless speaker products during fiscal year 2014 included the UE BOOM and the UE Mini BOOM.

[0001047469-14-009167:mdna:133]
During
fiscal year 2013, retail sales of Mobile Speakers increased 52% and units sold increased 53%, compared to fiscal year 2012. The increase was from a 52% increase in our wireless
speakers for smartphones and tablets. We experienced strong initial sales from our new wireless speakers including the Logitech UE Mobile Boombox and Logitech UE Boombox, both of which began shipping
late in the second quarter of fiscal year 2013. During the fourth quarter of fiscal year 2013, this category was negatively impacted by very weak demand for the Logitech UE Boombox. The poor sales
performance of this product was due to a lack of competitive differentiation and a form factor that has proved to be too

[0001047469-14-009167:mdna:134]
large
for many consumers. Contrasting, sales continued to be strong for our smaller, lower cost Logitech UE Mobile Boombox.

[0001047469-14-009167:mdna:135]
Profit Maximization Categories:

[0001047469-14-009167:mdna:136]
Pointing Devices

[0001047469-14-009167:mdna:137]
Our retail Pointing Devices category comprises PC and Mac-related mice, touchpads and presenters.

[0001047469-14-009167:mdna:138]
During
fiscal year 2014, retail sales of Pointing Devices decreased 3% and units sold decreased 1%, compared to fiscal year 2013. The decrease in retail sales was primarily due to the
continued weakness in the global PC market. The decrease was primarily from our high-end product offerings, which decreased 14%, followed by our mid-range product offerings, which decreased 6%, and
our low-end product offerings remained relatively flat for the year. Retail sales of corded mice decreased 9% and units sold decreased 10%. Retail sales of cordless mice decreased 1% and units sold
increased 4%.

[0001047469-14-009167:mdna:139]
During
fiscal year 2013, retail sales of pointing devices decreased 7% and units sold decreased 5%, compared to fiscal year 2013. The continued weakness in the global PC market was a
major factor in the sales decrease across all regions except the Asia Pacific region where retail sales were consistent. The decrease in our low-end product offerings, which decreased 6%, and our
mid-range products which decreased 8%, was partially offset by an increase in our high-end product offerings of 3%. Sales of all cordless mice decreased 5% and units sold increased 1%. Corded mice
sales decreased 16% and units sold decreased 13%.

[0001047469-14-009167:mdna:140]
PC Keyboards & Desktops

[0001047469-14-009167:mdna:141]
Our retail PC Keyboard & Desktop category comprises PC keyboards and keyboard/mice combo products.

[0001047469-14-009167:mdna:142]
During
fiscal year 2014, retail sales of PC Keyboards & Desktops increased 4% and units sold decreased 1%, compared to fiscal year 2013. The sales increase was primarily due to
sales increase in our corded and cordless combo. Our best selling product in this category was the Wireless Touch Keyboard K400, which features an integrated touchpad and has been popular for use in
the living room. Retail sales of
corded and cordless keyboards decreased 17% and 5%, respectively, and units sold decreased 21% and 6%, respectively. Retail sales of corded and cordless combos increased 3% and 7%, respectively, and
units sold decreased 1% and increased 10%, respectively.

[0001047469-14-009167:mdna:143]
During
fiscal year 2013, retail sales of PC Keyboards & Desktops increased 4% and units sold increased 1%, compared to fiscal year 2012. Although this category was affected by the
continued weakness in the global PC market, we managed to achieve a modest retail sales increase due to continued development of new, innovative products led by the Logitech Wireless Touch Keyboard
K400, and from other products, including the Logitech Washable Keyboard K310, Logitech Wireless Combo MK240, Logitech Bluetooth Illuminated Keyboard K810 and the Logitech Wireless Solar Keyboard for
Mac. Retail sales of corded and cordless combos decreased 9% and were consistent, respectively, and units sold decreased 7% and increased 4%, respectively. Retail sales of corded and cordless
keyboards decreased 5% and decreased 7%, respectively, and unit sales decreased 11% and were consistent, respectively.

[0001047469-14-009167:mdna:144]
Audio-PC & Wearables

[0001047469-14-009167:mdna:145]
Our retail Audio-PC & Wearables category comprises PC speakers, PC headsets and in-ear headphones.

[0001047469-14-009167:mdna:146]
During
fiscal year 2014, retail sales of Audio-PC decreased 13% and units sold decreased 17%, compared to fiscal year 2013. The decrease was primarily due to decreases in PC speaker
retail sales of 10% and units sold of 11%. These decreases reflect both a weakness in the overall market for new PCs and

[0001047469-14-009167:mdna:147]
62

[0001047469-14-009167:mdna:148]
a
market shift toward mobile audio devices. Retail sales of our Wearables products declined 39%, as we phase out the headphone category.

[0001047469-14-009167:mdna:149]
During
fiscal year 2013, retail sales of Audio-PC decreased 14% and units sold decreased 15%, compared to fiscal year 2012. This was due to a decrease in PC speaker retail sales of 14%
and unit sales decrease of 17% and PC headset retail sales decrease of 8% and units sold decrease of 10%. These decreases reflect both weakness in the overall market for new PCs and a market shift
toward mobile audio devices.

[0001047469-14-009167:mdna:150]
Video

[0001047469-14-009167:mdna:151]
Our retail Video category comprises retail webcams and Unified Communications webcams.

[0001047469-14-009167:mdna:152]
During
fiscal year 2014, retail sales of Video decreased 10% and units sold decreased 26%, compared to fiscal year 2013. The decrease was primarily due to weakness in our consumer webcam
product line, which decreased 17%, and which continued to be negatively impacted by the combination of market trends, including the popularity of embedded webcams in mobile devices, and the overall
weakness of the PC market. The decrease in our webcam product line was concentrated in both the low-end and mid-end of the category. The decrease was partially offset by strong growth in our high-end
category, which increased 28%.

[0001047469-14-009167:mdna:153]
During
fiscal year 2013, retail sales of Video decreased 22% and units sold decreased 27%, compared to fiscal year 2012. The decrease was primarily due to weakness in our webcam product
line, which decreased 26%, and which continued to be negatively impacted by the combination of market trends, including the popularity of embedded webcams in mobile devices, and the overall weakness
of the PC market. We experienced strong growth in the high-end category driven by the Logitech HD Pro Webcam C920, which offers full HD 1080p, and from the Logitech BCC950 Conference Cam for the
enterprise market.

[0001047469-14-009167:mdna:154]
Remotes

[0001047469-14-009167:mdna:155]
Our retail Remotes category comprises our Harmony remotes.

[0001047469-14-009167:mdna:156]
During
fiscal year 2014, retail sales of Remotes decreased 6% and units sold decreased 23%, compared to fiscal year 2013. The decrease in Remotes was primarily concentrated in our
high-end and low-end products, partially offset by increases in our mid-range product lines. New products such Harmony Ultimate and Harmony Smart Control contributed to 58% of total retail sales of
Remotes for fiscal year 2014. The higher decline in units sold reflected our strategic shift away from the low-end products.

[0001047469-14-009167:mdna:157]
During
fiscal year 2013, retail sales of Remotes decreased 21% and units sold decreased 37%, compared to fiscal year 2012. The decrease was concentrated in the low and mid-range remotes,
which decreased 39% and 66%, respectively. The high-end remotes decreased 7%; however we launched Harmony Touch in October 2012, our first new high-end remote in over four years. The significant
decrease in units sold, relative to retail sales, primarily reflects the transition away from selling low end remotes to mid to high-end remotes.

[0001047469-14-009167:mdna:158]
Non-Strategic

[0001047469-14-009167:mdna:159]
This category comprises a variety of products that we currently intend to transition out of, or have already transitioned out of,
because they are no longer strategic to our business. Products currently included in this category include TV camera, Digital Video Security, TV and home speakers, Google TV products, and
Keyboard/Desktop accessories.

[0001047469-14-009167:mdna:160]
During
fiscal year 2014, retail sales of this category decreased 57% and units sold decreased 64%, compared to fiscal year 2013.

[0001047469-14-009167:mdna:161]
63

[0001047469-14-009167:mdna:162]
During
fiscal year 2013, retail sales of this category decreased 46% and units sold decreased 37%, compared to fiscal year 2012.

[0001047469-14-009167:mdna:163]
OEM

[0001047469-14-009167:mdna:164]
During fiscal year 2014, OEM sales and units sold remained flat compared to fiscal year 2013.

[0001047469-14-009167:mdna:165]
During
fiscal year 2013, OEM sales decreased 24% and units sold decreased 12%, compared to fiscal year 2012. These declines were primarily due to lower sales in pointing devices and the
keyboard/desktop category.

[0001047469-14-009167:mdna:166]
Video Conferencing

[0001047469-14-009167:mdna:167]
During fiscal year 2014, video conferencing sales decreased 12% compared to fiscal year 2013. The decrease was primarily due to a
combination of a changing industry landscape caused by a shift to less expensive, cloud-based video conferencing solutions, an evolving Lifesize product line and challenges in execution experienced in
all geographic regions.

[0001047469-14-009167:mdna:168]
During
fiscal year 2013, video conferencing sales decreased 7% compared to fiscal year 2012. The decrease was impacted by the slowdown in the overall video conferencing industry,
together with the competitive environment in fiscal year 2013 and lower demand related to new product launches.

[0001047469-14-009167:mdna:169]
Gross Profit

[0001047469-14-009167:mdna:170]
Gross profit for fiscal years 2014, 2013 and 2012 was as follows (in thousands):

[0001047469-14-009167:mdna:171]
|  |  |  |  |  |  |  |  | Change |  |
|  |  | Years Ended March 31, |  |
|  |  | 2014 vs. 2013 |  | 2013 vs. 2012 |  |
|  |  | 2014 |  | 2013 |  | 2012 |  |
|  |  |  |  | As Revised |  | As Restated |  |  |  |  |  |
| Net sales |  | $ | 2,128,713 |  | $ | 2,099,277 |  | $ | 2,316,203 |  |  | 1 | % |  | (9 | )% |
| Cost of goods sold |  |  | 1,400,844 |  |  | 1,389,643 |  |  | 1,508,670 |  |  | 1 |  |  | (8 | ) |
| Gross profit |  | $ | 727,869 |  | $ | 709,634 |  | $ | 807,533 |  |  | 3 |  |  | (12 | ) |
| Gross margin |  |  | 34.2 | % |  | 33.8 | % |  | 34.9 | % |  |  |  |  |  |  |

[0001047469-14-009167:mdna:172]
Gross
profit consists of net sales, less cost of goods sold, which includes materials, direct labor and related overhead costs, costs of manufacturing facilities, costs of purchasing
components from outside suppliers, distribution costs, outside processing costs, write-down of inventories and amortization of intangible assets.

[0001047469-14-009167:mdna:173]
The
increase in gross margin during fiscal year 2014, compared to fiscal year 2013, was primarily due to cost improvements across all of our PC-related categories and from actions we
took since fiscal year 2013 to streamline our product portfolio, revalue inventory of several discontinued Music category products and the discontinuation of projects in 2013 due to restructuring.

[0001047469-14-009167:mdna:174]
Gross
margin for fiscal year 2013 decreased, compared to fiscal year 2012. During fiscal year 2013, we experienced gross margin improvement from improvements to our global supply chain
process. These improvements were almost entirely offset by an unfavorable change in retail product mix, the negative impact of a weaker euro, a charge to revalue our inventory of several headphones
and a large form-factor wireless speaker included in our mobile speakers retail product category, pricing actions related to the simplification of our product portfolio in Americas and EMEA regions,
costs related to product development efforts that were discontinued as a result of our restructuring plans during fiscal year 2013, and a provision for a patent dispute.

[0001047469-14-009167:mdna:175]
Operating Expenses

[0001047469-14-009167:mdna:176]
Operating expenses for fiscal years 2014, 2013 and 2012 were as follows (in thousands):

[0001047469-14-009167:mdna:177]
|  |  | Years Ended March 31, |  | Change |  |
|  |  | 2014 |  | 2013 |  | 2012 |  | 2014 vs. 2013 |  | 2013 vs. 2012 |  |
|  |  |  |  | As Revised |  | As Restated |  |  |  |  |  |
| Marketing and selling |  | $ | 379,747 |  | $ | 431,886 |  | $ | 422,116 |  |  | (12 | )% |  | 2 | % |
| % of net sales |  |  | 17.8 | % |  | 20.6 | % |  | 18.2 | % |  |  |  |  |  |  |
| Research and development |  |  | 139,385 |  |  | 155,012 |  |  | 162,159 |  |  | (10 | ) |  | (4 | ) |
| % of net sales |  |  | 6.5 | % |  | 7.4 | % |  | 7.0 | % |  |  |  |  |  |  |
| General and administrative |  |  | 118,940 |  |  | 114,381 |  |  | 109,260 |  |  | 4 |  |  | 5 |  |
| % of net sales |  |  | 5.6 | % |  | 5.4 | % |  | 4.7 | % |  |  |  |  |  |  |
| Impairment of goodwill and other assets |  |  | — |  |  | 216,688 |  |  | — |  |  | (100 | ) |  | — |  |
| % of net sales |  |  | 0.0 | % |  | 10.3 | % |  | 0.0 | % |  |  |  |  |  |  |
| Restructuring charges |  |  | 13,811 |  |  | 43,704 |  |  | — |  |  | (68 | ) |  | — |  |
| % of net sales |  |  | 0.7 | % |  | 2.1 | % |  | 0.0 | % |  |  |  |  |  |  |
| Total operating expenses |  | $ | 651,883 |  | $ | 961,671 |  | $ | 693,535 |  |  | (32 | ) |  | 39 |  |
| % of net sales |  |  | 30.6 | % |  | 45.8 | % |  | 29.9 | % |  |  |  |  |  |  |

[0001047469-14-009167:mdna:178]
The
decrease in total operating expenses during fiscal year 2014, compared to fiscal year 2013, was primarily due to the $216.7 million impairment of goodwill and other assets
recorded in fiscal year 2013, combined with the restructuring plans initiated in fiscal year 2013, which reduced personnel-related expenses in fiscal year 2014 and resulted in a $30.0 million
decrease in restructuring expenses.

[0001047469-14-009167:mdna:179]
The
increase in total operating expenses during fiscal year 2013, compared to fiscal year 2012, was mainly due to the $216.7 million impairment charge of goodwill and other assets
primarily related to the Lifesize business and from the $43.7 million in costs related to restructuring plans we implemented in fiscal year 2013.

[0001047469-14-009167:mdna:180]
Marketing and Selling

[0001047469-14-009167:mdna:181]
Marketing and selling expense consists of personnel and related overhead costs, corporate and product marketing, promotions,
advertising, trade shows, customer and technical support and facilities costs.

[0001047469-14-009167:mdna:182]
During
fiscal year 2014, marketing and selling expenses decreased 12%, compared to fiscal year 2013. The decrease was primarily due to $15 million lower personnel-related expenses
from the reduction in Lifesize worldwide workforce restructuring and $24 million lower advertising and marketing cost related to the launch of new Music category in fiscal year 2013.

[0001047469-14-009167:mdna:183]
During
fiscal year 2013, marketing and selling expense increased 2%, compared to fiscal year 2012. We experienced increased advertising, product design, consulting and marketing expenses
associated with the launch of new music products, which were partially offset by decreases in personnel-related expense from restructuring plans we implemented during fiscal year 2013, and reduction
in Digital Home category marketing cost.

[0001047469-14-009167:mdna:184]
Research and Development

[0001047469-14-009167:mdna:185]
Research and development expense consists of personnel and related overhead costs, contractors and outside consultants, supplies and
materials, equipment depreciation and facilities costs, all associated with the design and development of new products and enhancements of existing products.

[0001047469-14-009167:mdna:186]
During
fiscal year 2014, research and development expense decreased 10%, compared to fiscal year 2013. The decrease was primarily due to $6 million lower personnel-related
expenses from the reduction in Lifesize worldwide restructuring and $9 million lower design and development cost related to the fiscal year 2013 launch of the new Music category.

[0001047469-14-009167:mdna:187]
During
fiscal year 2013, research and development expense decreased 4%, compared to fiscal year 2012. The decrease was primarily due to a decrease in personnel related expenses due to
the reduction in worldwide workforce resulting from our restructuring plans.

[0001047469-14-009167:mdna:188]
General and Administrative

[0001047469-14-009167:mdna:189]
General and administrative expense consists primarily of personnel and related overhead and facilities costs for the finance,
information systems, executive, human resources and legal functions.

[0001047469-14-009167:mdna:190]
During
fiscal year 2014, general and administrative expense increased 4%, compared to fiscal year 2013. The increase was primarily due to $8 million increase in personnel-related
expense due to higher variable compensation costs related to our improved performance and share-based compensation expense, partially offset by $4 million decrease of facility related expenses
due to our recent restructuring plans which occurred during fiscal year 2013.

[0001047469-14-009167:mdna:191]
During
fiscal year 2013, general and administrative expense increased 5%, compared to fiscal year 2012. The increase was primarily due to the gain on sale of property and plant related
to unused manufacturing properties in China which impacted fiscal year 2012 and from the write-off of the remaining lease obligations resulting from the exit of our former U.S. corporate offices
during fiscal year 2013, partially offset by a decrease in personnel-related expenses and share-based compensation expense due to the reduction in worldwide workforce from our restructuring plans
during fiscal year 2013.

[0001047469-14-009167:mdna:192]
Impairment of Goodwill and Other Assets

[0001047469-14-009167:mdna:193]
There was no impairment of goodwill and other assets for fiscal year 2014. We recorded an impairment charge of goodwill and other
assets of $216.7 million primarily related to the Lifesize business in fiscal year 2013.

[0001047469-14-009167:mdna:194]
While
performing our annual goodwill impairment analysis of each of our reporting units as of December 31, 2012, we determined that our video conferencing reporting unit's
estimated fair value was less than its carrying value, thus requiring a Step 2 assessment of this reporting unit. This impairment primarily resulted from a decrease in our expected CAGR during the
assessment forecast period based on greater evidence of the overall enterprise video conferencing industry experiencing a slowdown in recent quarters, combined with lower demand related to new product
launches, increased competition in fiscal year 2013 and other market data. The Step 2 test required us to fair value all assets and liabilities of our video conferencing reporting unit to determine
the implied fair value of this reporting unit's goodwill. We were unable to complete the Step 2 analysis prior to filing of our Form 10-Q for the quarterly period ended December 31, 2012
due to the complexities of determining the implied fair value of goodwill of our video conferencing reporting unit. Based on our work performed during the third quarter of fiscal year 2013, we
initially recorded an estimated goodwill impairment charge of $211.0 million. During the fourth quarter of fiscal year 2013, we completed this goodwill impairment assessment and recorded an
additional $3.5 million in goodwill impairment charge related to our video conferencing reporting unit. During the fourth quarter of fiscal year 2013, we also recorded impairment charges of
$2.1 million related to our

[0001047469-14-009167:mdna:195]
digital
video security product line, included within our retail video product category, which we plan to divest.

[0001047469-14-009167:mdna:196]
Restructuring Charges

[0001047469-14-009167:mdna:197]
Our restructuring activities were mainly attributable to the peripherals operating segment. The following table summarizes
restructuring-related activities during the years ended March 31, 2014 and 2013 (in thousands):

[0001047469-14-009167:mdna:198]
|  |  | Restructuring |  |
|  |  | Termination Benefits |  | Lease Exit Costs |  | Other |  | Total |  |
| March 31, 2012 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  |
| Charges |  |  | 41,088 |  |  | 1,308 |  |  | 1,308 |  |  | 43,704 |  |
| Cash payments |  |  | (27,768 | ) |  | (1,233 | ) |  | (1,322 | ) |  | (30,323 | ) |
| Foreign exchange impact |  |  | 63 |  |  | — |  |  | 14 |  |  | 77 |  |
| March 31, 2013 |  |  | 13,383 |  |  | 75 |  |  | — |  |  | 13,458 |  |
| Charges |  |  | 6,463 |  |  | 7,348 |  |  | — |  |  | 13,811 |  |
| Adjustment for deferred rent |  |  | — |  |  | 1,450 |  |  | — |  |  | 1,450 |  |
| Cash payments |  |  | (19,534 | ) |  | (1,454 | ) |  | — |  |  | (20,988 | ) |
| Foreign exchange impact |  |  | (170 | ) |  | — |  |  | — |  |  | (170 | ) |
| March 31, 2014 |  | $ | 142 |  | $ | 7,419 |  | $ | — |  | $ | 7,561 |  |

[0001047469-14-009167:mdna:199]
During
the second quarter of fiscal year 2014, we implemented a restructuring plan solely affecting our video conferencing operating segment to align its organization to its strategic
priorities of increasing focus on a tighter range of products, expanding cloud-based video conferencing services and improving profitability. Restructuring charges under this plan primarily consist of
severance and other one-time termination benefits. During fiscal year 2014, restructuring charges under this plan included $5.0 million in termination benefits and $0.6 million in lease
exit costs. We substantially completed this restructuring plan by March 31, 2014.

[0001047469-14-009167:mdna:200]
During
the fourth quarter of fiscal year 2013, we implemented a restructuring plan to align our organization to our strategic priorities of increasing focus on mobility products,
improving profitability
in PC-related products and enhancing global operational efficiencies. As part of this restructuring plan, we reduced our worldwide non-direct labor workforce. Restructuring charges under this plan
primarily consisted of severance and other one-time termination benefits. During fiscal year 2014, restructuring charges under this plan included $1.5 million in termination benefits and
$6.7 million in lease exit costs, $5.4 million of which pertains to the consolidation our Silicon Valley campus from two buildings down to one during the quarter ended March 31,
2014. During fiscal year 2013, restructuring charges under this plan included $15.2 million in termination benefits to affected employees. We substantially completed this restructuring plan by
the fourth quarter of fiscal year 2014.

[0001047469-14-009167:mdna:201]
During
the first quarter of fiscal year 2013, we implemented a restructuring plan to simplify our organization, better align our costs with our current business and to free up resources
to pursue growth opportunities. A majority of the restructuring activity was completed during the first quarter of fiscal year 2013. As part of this restructuring plan, we reduced our worldwide
non-direct labor workforce. During fiscal year 2013, restructuring charges under this plan included $25.9 million in termination benefits, $1.3 million in legal, consulting, and other
costs as a result of the terminations, and $1.3 million in lease exit costs associated with the closure of existing facilities. Termination benefits are calculated based on regional benefit
practices and local statutory requirements. We substantially completed this restructuring plan by the fourth quarter of fiscal year 2013.

[0001047469-14-009167:mdna:202]
Interest Income (Expense), Net

[0001047469-14-009167:mdna:203]
Interest income and expense for fiscal years 2014, 2013 and 2012 were as follows (in thousands):

[0001047469-14-009167:mdna:204]
|  |  | Years Ended March 31, |  |
|  |  | 2014 |  | 2013 |  | 2012 |  |
| Interest income |  | $ | 1,831 |  | $ | 2,215 |  | $ | 3,121 |  |
| Interest expense |  |  | (2,228 | ) |  | (1,308 | ) |  | (447 | ) |
|  |  | $ | (397 | ) | $ | 907 |  | $ | 2,674 |  |

[0001047469-14-009167:mdna:205]
Interest
income slightly decreased during fiscal year 2014 compared to fiscal year 2013.

[0001047469-14-009167:mdna:206]
Interest
expense increased during fiscal year 2014, compared to fiscal year 2013. The increase was primarily due to the write-off of $1.0 million in amortized loan fees related to
our $250.0 million Senior Revolving Credit Facility which we chose to terminate during fiscal year 2014.

[0001047469-14-009167:mdna:207]
Interest
income decreased during fiscal year 2013, compared to fiscal year 2012. The decrease was primarily due to lower invested balances resulting from the $133.5 million cash
dividend payment made
in September 2012 and from the $87.8 million paid to repurchase 8.6 million shares under our amended September 2008 buyback program.

[0001047469-14-009167:mdna:208]
Interest
expense increased during fiscal year 2013, compared to fiscal year 2012. The increase was primarily due to commitment fees and non-recurring fees related to our
$250 million Senior Revolving Credit Facility entered into in December 2011.

[0001047469-14-009167:mdna:209]
Other Income (Expense), Net

[0001047469-14-009167:mdna:210]
Other income and expense for fiscal years 2014, 2013 and 2012 were as follows (in thousands):

[0001047469-14-009167:mdna:211]
|  |  | Years Ended March 31, |  |
|  |  | 2014 |  | 2013 |  | 2012 |  |
| Investment income related to deferred compensation plan |  | $ | 1,487 |  | $ | 933 |  | $ | 227 |  |
| Gain on sale of securities |  |  | — |  |  | 831 |  |  | 6,109 |  |
| Impairment of investments |  |  | (624 | ) |  | (3,600 | ) |  | — |  |
| Foreign currency exchange gain, net |  |  | 62 |  |  | 104 |  |  | 1,575 |  |
| Other |  |  | 1,068 |  |  | (466 | ) |  | (256 | ) |
|  |  | $ | 1,993 |  | $ | (2,198 | ) | $ | 7,655 |  |

[0001047469-14-009167:mdna:212]
Investment
income for fiscal years 2014, 2013 and 2012 represents earnings, gains, and losses on trading investments related to a deferred compensation plan offered by one of our
subsidiaries.

[0001047469-14-009167:mdna:213]
The
$0.6 million and $3.6 million investment impairment charges in fiscal years 2014 and 2013, respectively, resulted from the write-down of an investment in a
privately-held company.

[0001047469-14-009167:mdna:214]
During
fiscal year 2013, we sold the remaining two of our available-for-sale securities with a total carrying value of $0.4 million and a total par value of $15.2 million
for $0.9 million. This sale resulted in $0.8 million gain recognized in other income (expense), $0.3 million of which resulted from the recognition of a temporary increase in fair
value previously recorded in accumulated other comprehensive loss.

[0001047469-14-009167:mdna:215]
During
fiscal year 2012, we sold two of our available-for-sale securities, with a total carrying value of $0.5 million and a total par value of $10.0 million, for
$6.6 million, resulting in a gain of $6.1 million.

[0001047469-14-009167:mdna:216]
Foreign
currency exchange gains or losses relate to balances denominated in currencies other than the functional currency in one of our subsidiaries, as well as to the sale of
currencies, and to gains or losses

[0001047469-14-009167:mdna:217]
recognized
on foreign exchange forward contracts. We do not speculate in currency positions, but we are alert to opportunities to maximize foreign exchange gains.

[0001047469-14-009167:mdna:218]
Provision for (Benefit from) Income Taxes

[0001047469-14-009167:mdna:219]
The provision for (benefit from) income taxes and effective income tax rate for fiscal years 2014, 2013 and 2012 were as follows (in
thousands):

[0001047469-14-009167:mdna:220]
|  |  | Years Ended March 31, |  |
|  |  | 2014 |  | 2013 |  | 2012 |  |
|  |  |  |  | As Revised |  | As Restated |  |
| Provision for (benefit from) income taxes |  | $ | 3,278 |  | $ | (25,810 | ) | $ | 20,090 |  |
| Effective income tax rate |  |  | 4.2 | % |  | 10.2 | % |  | 16.2 | % |

[0001047469-14-009167:mdna:221]
The
provision for income taxes consists of income and withholding taxes. We operate in multiple jurisdictions and our profits are taxed pursuant to the tax laws of these jurisdictions.
Our effective income tax rate may be affected by changes in or interpretations of tax laws and tax agreements in any given jurisdiction, utilization of net operating loss and tax credit carryforwards,
changes in geographical mix of income and expense, and changes in management's assessment of matters such as the ability to realize deferred tax assets.

[0001047469-14-009167:mdna:222]
The
change in the effective income tax rate between fiscal year 2014 and 2013 was primarily due to the mix of income and losses in the various tax jurisdictions in which we operate and a
tax benefit of $14.3 million during fiscal year 2014, related to the reversal of uncertain tax positions resulting from the expiration of the statutes of limitations. In fiscal year 2013, there
was a tax benefit of $35.6 million related to the reversal of uncertain tax positions resulting from the closure of federal income tax examinations in the United States.

[0001047469-14-009167:mdna:223]
The
change in the effective income tax rate between fiscal year 2013 and 2012 was primarily due to the mix of income and losses in the various tax jurisdictions in which we operate and a
tax benefit of $35.6 million during fiscal year 2013, related to the reversal of uncertain tax positions resulting from the closure of federal income tax examinations in the United States.

[0001047469-14-009167:mdna:224]
The
federal research tax credit in the United States has expired as of December 31, 2013. The income tax expense for the fiscal year ended March 31, 2014 reflected a
$0.8 million tax benefit for research tax credits.

[0001047469-14-009167:mdna:225]
As
of March 31, 2014 and March 31, 2013, the total amount of unrecognized tax benefits due to uncertain tax positions was $91.0 million and $95.4 million,
respectively, of which $86.1 million and $90.3 million would affect the effective income tax rate if recognized, respectively.

[0001047469-14-009167:mdna:226]
As
of March 31, 2014, we had $93.1 million in non-current income taxes payable and $0.3 million in current income taxes payable, including interest and penalties,
related to our income tax liability for uncertain tax positions. As of March 31, 2013, we had $98.8 million in non-current income taxes payable.

[0001047469-14-009167:mdna:227]
We
continue to recognize interest and penalties related to unrecognized tax positions in income tax expense. We recognized $1.1 million, $1.0 million and
$1.2 million in interest and penalties in income tax expense during fiscal years 2014, 2013 and 2012, respectively. As of March 31, 2014, 2013 and 2012, we had approximately
$5.6 million, $6.6 million and $7.5 million of accrued interest and penalties related to uncertain tax positions.

[0001047469-14-009167:mdna:228]
We
file Swiss and foreign tax returns. For all these tax returns, we are generally not subject to tax examinations for years prior to fiscal year 2001. We are under examination and have
received assessment notices in foreign tax jurisdictions. At this time, we are not able to estimate the potential impact that these examinations may have on income tax expense. If the examinations are
resolved unfavorably, there is a possibility they may have a material negative impact on our results of operations.

[0001047469-14-009167:mdna:229]
Liquidity and Capital Resources

[0001047469-14-009167:mdna:230]
Cash Balances, Available Borrowings, and Capital Resources

[0001047469-14-009167:mdna:231]
As of March 31, 2014, we had cash and cash equivalents of $469.4 million, compared with $333.8 million at
March 31, 2013. Our cash and cash equivalents consist of bank demand deposits and short-term time deposits of which 73% is held by our Swiss-based entities and 12% is held by our subsidiaries
in Hong Kong and China. We do not expect to incur any material adverse tax impact or be significantly inhibited by any country in which we do business from the repatriation of funds to Switzerland,
our home domicile.

[0001047469-14-009167:mdna:232]
At
March 31, 2014, our working capital was $478.2 million compared with working capital of $385.1 million at March 31, 2013. The increase in working capital
over the prior year was primarily due to higher cash balances offset by low inventory balances at March 31, 2014.

[0001047469-14-009167:mdna:233]
During
fiscal year 2014, we generated $205.4 million from operating activities. Our main sources of operating cash flows were from net income after adding back non-cash expenses
of depreciation, amortization, and share-based compensation expense, from an increase in accrued and other liabilities and from a decrease in inventories. Net cash used in investing activities was
$46.8 million, primarily for purchase of property, plant, and equipment of $46.7 million. Net cash used in financing activities was $22.7 million, primarily for the
$36.1 million cash dividends, partially offset by $16.9 million in proceeds received from the sale of shares upon exercise of options and purchase rights.

[0001047469-14-009167:mdna:234]
During
fiscal year 2013, we generated $122.4 million of cash flow from operating activities. Our main sources of operating cash flows were net loss after adding back non-cash
expenses of depreciation, amortization, impairment of goodwill and other assets, investment impairment, share-based compensation expense, and from decreases in accounts receivables and inventories.
These sources of operating cash flows were offset in part by decreases in accounts payables and accrued liabilities and an increase in other assets. Net cash used in investing activities was
$57.7 million, primarily for $54.5 million of investments in leasehold improvements, computer hardware and software, tooling and equipment and for our strategic investments of
$4.4 million. Net cash used in financing activities was $207.6 million, primarily for the $133.5 million cash dividend payment and for the $87.8 million used to repurchase
8.6 million shares under our share buyback program, partially offset by $16.0 million in proceeds received from sale of shares upon exercise of options and purchase rights.

[0001047469-14-009167:mdna:235]
In
December 2011, we entered into a Senior Revolving Credit Facility Agreement ("Credit Facility") with a group of primarily Swiss banks that provided for a revolving multicurrency
unsecured credit facility in the amount of up to $250.0 million and subject to certain requirements, permitted us to arrange with existing or new lenders to provide up to an aggregate of
$150.0 million in additional commitments, for a total of $400.0 million. We also paid a quarterly commitment fee of 40% of the applicable margin on the available commitment. In December
2013, given the significant improvement in our financial performance and outlook, we chose to terminate this Credit Facility and wrote-off the capitalized commitment fees totaling $1.0 million.
There were no outstanding borrowings at the time of termination.

[0001047469-14-009167:mdna:236]
We
had several uncommitted, unsecured bank lines of credit aggregating to $40.0 million as of March 31, 2014. There are no financial covenants under these lines of credit
which we must comply with. As of March 31, 2014, we had outstanding bank guarantees of $7.1 million under these lines of credit. We also had credit lines related to corporate credit
cards totaling $6.9 million as of March 31, 2014. There are no financial covenants under these credit lines.

[0001047469-14-009167:mdna:237]
We
file Swiss and foreign tax returns. For all these tax returns, we are generally not subject to tax examinations for years prior to fiscal year 2001. We are under examination and have
received assessment notices in foreign tax jurisdictions. At this time, we are not able to estimate the potential impact that these examinations may have on income tax expense. If the examinations are
resolved unfavorably, there is a possibility they may have a material negative impact on our results of operations.

[0001047469-14-009167:mdna:238]
Although
we have adequately provided for uncertain tax positions, the provisions on these positions may change as revised estimates are made or the underlying matters are settled or
otherwise resolved. It is reasonably possible that resolutions in the next 12 months could increase or decrease the balance of our unrecognized tax benefits but we are not able to estimate the
change at this time.

[0001047469-14-009167:mdna:239]
The
following table summarizes our Consolidated Statements of Cash Flows (in thousands):

[0001047469-14-009167:mdna:240]
|  |  | Years Ended March 31, |  |
|  |  | 2014 |  | 2013 |  | 2012 |  |
|  |  |  |  | As Revised |  | As Restated |  |
| Net cash provided by operating activities |  | $ | 205,421 |  | $ | 122,389 |  | $ | 202,534 |  |
| Net cash used in investing activities |  |  | (46,803 | ) |  | (57,723 | ) |  | (57,602 | ) |
| Net cash used in financing activities |  |  | (22,681 | ) |  | (207,641 | ) |  | (139,374 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (349 | ) |  | (1,571 | ) |  | (5,119 | ) |
| Net increase (decrease) in cash and cash equivalents |  | $ | 135,588 |  | $ | (144,546 | ) | $ | 439 |  |

[0001047469-14-009167:mdna:241]
Cash Flow from Operating Activities

[0001047469-14-009167:mdna:242]
The following table presents selected financial information and statistics for fiscal years 2014, 2013 and 2012 (dollars in thousands):

[0001047469-14-009167:mdna:243]
|  |  | March 31, |  |
|  |  | 2014 |  | 2013 |  | 2012 |  |
|  |  |  |  | As Revised |  | As Restated |  |
| Accounts receivable, net |  | $ | 182,029 |  | $ | 178,959 |  | $ | 223,104 |  |
| Inventories |  |  | 222,402 |  |  | 262,644 |  |  | 297,072 |  |
| Working capital |  |  | 478,213 |  |  | 385,073 |  |  | 574,944 |  |
| Days sales in accounts receivable ("DSO")(1) |  |  | 34 days |  |  | 34 days |  |  | 38 days |  |
| Inventory turnover ("ITO")(2) |  |  | 5.9x |  |  | 4.7x |  |  | 4.6x |  |

[0001047469-14-009167:mdna:244]
(1)

[0001047469-14-009167:mdna:245]
DSO
is determined using ending accounts receivable as of the most recent quarter-end and net sales for the most recent quarter.

[0001047469-14-009167:mdna:246]
(2)

[0001047469-14-009167:mdna:247]
ITO
is determined using ending inventories and annualized cost of goods sold (based on the most recent quarterly cost of goods sold).

[0001047469-14-009167:mdna:248]
DSO
as of March 31, 2014 remained flat compared to March 31, 2013.

[0001047469-14-009167:mdna:249]
DSO
as of March 31, 2013 decreased 4 days, compared to March 31, 2012. The decrease was primarily due to improvement in cash collections.

[0001047469-14-009167:mdna:250]
Typical
payment terms require customers to pay for product sales generally within 30 to 60 days. However, terms may vary by customer type, by country and by selling season.
Extended payment terms are sometimes offered to a limited number of customers during the quarters ended September 30 and December 31. We do not modify payment terms on existing
receivables, but may offer discounts for early payment.

[0001047469-14-009167:mdna:251]
ITO
as of March 31, 2014 increased, compared to March 31, 2013. The increase was primarily due to lower inventory levels in relation to net sales during the fourth quarter
of fiscal year 2014.

[0001047469-14-009167:mdna:252]
ITO
as of March 31, 2013 increased, compared to March 31, 2012. The increase was primarily due to lower inventory levels at March 31, 2013 in relation to net sales
during the fourth quarter of fiscal year 2013.

[0001047469-14-009167:mdna:253]
Cash Flow from Investing Activities

[0001047469-14-009167:mdna:254]
|  |  | Years Ended March 31, |  |
|  |  | 2014 |  | 2013 |  | 2012 |  |
|  |  |  |  | As Revised |  | As Restated |  |
| Purchases of property, plant and equipment |  |  | (46,658 | ) |  | (54,487 | ) |  | (54,199 | ) |
| Purchase of strategic investment |  |  | (300 | ) |  | (4,420 | ) |  | — |  |
| Acquisitions, net of cash acquired |  |  | (650 | ) |  | — |  |  | (18,814 | ) |
| Proceeds from sales of available-for-sale securities |  |  | — |  |  | 917 |  |  | 6,550 |  |
| Proceeds from return of investment from strategic investments |  |  | 261 |  |  | — |  |  | — |  |
| Proceeds from sales of property and equipment |  |  | — |  |  | — |  |  | 8,967 |  |
| Purchase of trading investments |  |  | (8,450 | ) |  | (4,196 | ) |  | (7,505 | ) |
| Proceeds from sales of trading investments |  |  | 8,994 |  |  | 4,463 |  |  | 7,399 |  |
|  |  |  | (46,803 | ) |  | (57,723 | ) |  | (57,602 | ) |

[0001047469-14-009167:mdna:255]
Our
expenditures for property, plant and equipment during fiscal year 2014, 2013 and 2012 were primarily expenditures for leasehold improvements, computer hardware and software, tooling
and equipment.

[0001047469-14-009167:mdna:256]
During
fiscal year 2014, purchases of property, plant and equipment decreased, compared to fiscal year 2013, primarily due to leasehold improvements related to our new Silicon Valley
campus during fiscal year 2013. During fiscal year 2014, we made a $0.7 million investment. During fiscal year 2013, we sold our two remaining available-for-sale securities for
$0.9 million.

[0001047469-14-009167:mdna:257]
During
fiscal year 2013, we purchased a strategic investment for $4.0 million in exchange for convertible preferred stock. We accounted for this investment under the cost method
of accounting since we have less than a 20% ownership interest and we lack the ability to exercise significant influence over the operating and financial policies of the investee. We also purchased
another strategic investment for $0.4 million in exchange for approximate 20% ownership interest. We accounted for this investment under the equity method of accounting since we have the
ability to exercise significant influence over the operating and financial policies of the investee. In addition, we sold our two remaining available-for-sale securities for $0.9 million.

[0001047469-14-009167:mdna:258]
During
fiscal year 2012, $54.2 million capital investment activity was primarily due to leasehold improvements related to our new Americas headquarters. We also acquired
Mirial S.r.l. for a total consideration of $18.8 million (€13.0 million), net of cash acquired of $1.4 million (€1.0 million).
Proceeds from the sale of property and plant related to the sale of unused manufacturing properties in China.

[0001047469-14-009167:mdna:259]
72

[0001047469-14-009167:mdna:260]
The purchases and sales of trading investments during fiscal years 2014, 2013 and 2012 represent mutual fund activity directed by participants in a deferred
compensation plan offered by one of our subsidiaries. The mutual funds are held by a Rabbi Trust.

[0001047469-14-009167:mdna:261]
Cash Flow from Financing Activities

[0001047469-14-009167:mdna:262]
|  |  | Years Ended March 31, |  |
|  |  | 2014 |  | 2013 |  | 2012 |  |
| Payment of cash dividends |  |  | (36,123 | ) |  | (133,462 | ) |  | — |  |
| Purchases of treasury shares |  |  | — |  |  | (87,812 | ) |  | (156,036 | ) |
| Proceeds from sales of shares upon exercise of options and purchase rights |  |  | 16,914 |  |  | 15,982 |  |  | 17,591 |  |
| Tax withholdings related to net share settlements of restricted stock units |  |  | (5,718 | ) |  | (2,375 | ) |  | (966 | ) |
| Excess tax benefits from share-based compensation |  |  | 2,246 |  |  | 26 |  |  | 37 |  |
|  |  |  | (22,681 | ) |  | (207,641 | ) |  | (139,374 | ) |

[0001047469-14-009167:mdna:263]
During
fiscal year 2014, we paid an annual cash dividend of $36.1 million, compared to a special one-time distribution of $133.5 million during fiscal year 2013.

[0001047469-14-009167:mdna:264]
There
was no stock repurchase activity during fiscal year 2014. During fiscal year 2013, we repurchased 8.6 million shares for $87.8 million, compared to
17.5 million shares for $156.0 million during fiscal year 2012.

[0001047469-14-009167:mdna:265]
Proceed
from the sale of shares upon exercise of options and purchase rights pursuant our stock plans during fiscal years 2014, 2013 and 2012 was $16.9 million,
$16.0 million and $17.6 million, respectively. The payment of tax withholdings related to net share settlements of RSUs (restricted stock units) required during fiscal years 2014, 2013
and 2012 was $5.7 million, $2.4 million and $1.0 million, respectively.

[0001047469-14-009167:mdna:266]
Cash Outlook

[0001047469-14-009167:mdna:267]
Our principal sources of liquidity are our cash and cash equivalents, cash flow generated from operations and, to a much lesser extent,
capital markets and borrowings. Our future working capital requirements and capital expenditures may increase to support investment in product innovations and growth opportunities, or to acquire or
invest in complementary businesses, products, services, and technologies.

[0001047469-14-009167:mdna:268]
In
March 2014, our Board of Directors approved a new share buyback program, which authorizes us to invest up to $250.0 million to purchase our own shares. Our share buyback
program provides us with the opportunity to make opportunistic repurchases during periods of favorable market conditions and is expected to remain in effect for a period of three years. Shares may be
repurchased from time to time on the open market, through block trades or otherwise. Purchases may be started or stopped at any time without prior notice depending on market conditions and other
factors.

[0001047469-14-009167:mdna:269]
We
file Swiss and foreign tax returns. For all these tax returns, we are generally not subject to tax examinations for years prior to fiscal year 2001. We are under examination and have
received assessment notices in foreign tax jurisdictions. At this time, we are not able to estimate the potential
impact that these examinations may have on income tax expense. If the examinations are resolved unfavorably, there is a possibility they may have a material negative impact on our results of
operations.

[0001047469-14-009167:mdna:270]
During
the second quarter of fiscal year 2014, we implemented a restructuring plan solely affecting our video conferencing operating segment to align our organization to our strategic
priorities of increasing focus on a tighter range of products, expanding cloud-based video conferencing services and improving

[0001047469-14-009167:mdna:271]
profitability.
During the fourth quarter of fiscal year 2013, we implemented an additional restructuring plan to realign our organization to increase our focus on mobility products, improve
profitability in PC-related products and enhance our global operational efficiencies.

[0001047469-14-009167:mdna:272]
Our
other contractual obligations and commitments that require cash are described in the following sections.

[0001047469-14-009167:mdna:273]
For
over ten years, we have generated positive cash flows from our operating activities, including cash from operations of $205.4 million, $122.4 million and
$202.5 million during fiscal years 2014, 2013 and 2012, respectively. During fiscal year 2013, our level of cash and cash equivalents was significantly reduced by the distribution of
CHF 125.7 million (U.S. dollar amount of $133.5 million) out of retained earnings, and by the $87.8 million in share repurchases. During fiscal year 2014, we paid a cash
dividend of CHF 33.7 million (U.S. dollar amount of $36.1 million) out of retained earnings. On November 12, 2014, the Board approved, subject to approval by our
shareholders and other Swiss statutory requirements, a dividend of CHF 0.2625 per share. We plan to issue an annual dividend on a recurring basis. If we do not generate sufficient operating cash flows
to support our operations and future planned cash requirements, our operations could be harmed and our access to credit facilities could be restricted or eliminated. However, we believe that the trend
of our historical cash flow generation, our projections of future operations and reduced expenses and our available cash balances will provide sufficient liquidity to fund our operations for at least
the next 12 months.

[0001047469-14-009167:mdna:274]
Contractual Obligations and Commitments

[0001047469-14-009167:mdna:275]
As of March 31, 2014, our outstanding contractual obligations and commitments included: (i) facilities leased under
operating lease commitments, (ii) purchase commitments and obligations, (iii) long-term liabilities for income taxes payable, and (iv) defined benefit
pension plan and non-retirement post-employment benefit obligations. The following summarizes our contractual obligations and commitments as of March 31, 2014 (in thousands):

[0001047469-14-009167:mdna:276]
|  |  |  |  | Payments Due by Period |  |
|  |  | March 31, 2014 |  |
|  |  | <1 year |  | 1-3 years |  | 4-5 years |  | >5 years |  |
| Inventory commitments |  | $ | 102,760 |  | $ | 102,760 |  | $ | — |  | $ | — |  | $ | — |  |
| Operating expenses |  |  | 45,969 |  |  | 45,969 |  |  | — |  |  | — |  |  | — |  |
| Capital commitments |  |  | 12,994 |  |  | 12,994 |  |  | — |  |  | — |  |  | — |  |
| Operating leases |  |  | 77,949 |  |  | 17,022 |  |  | 32,947 |  |  | 7,172 |  |  | 20,808 |  |
| Income taxes payable(3) |  |  | 93,126 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Obligation for deferred compensation(1) |  |  | 16,611 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Employee benefit plan obligation(1) |  |  | 38,999 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other non-current obligations(2) |  |  | 1,715 |  |  | — |  |  | — |  |  | — |  |  | — |  |
|  |  | $ | 390,123 |  | $ | 178,745 |  | $ | 32,947 |  | $ | 7,172 |  | $ | 20,808 |  |

[0001047469-14-009167:mdna:277]
(1)

[0001047469-14-009167:mdna:278]
As
specific payment dates for these obligations are unknown, the related balances have not been reflected in the "Payments Due by Period" section of the
table. We expect to contribute $5.3 million to our defined benefit pension plans during fiscal year 2015.

[0001047469-14-009167:mdna:279]
(2)

[0001047469-14-009167:mdna:280]
Other
long-term liabilities at March 31, 2014 related to various other obligations. As specific payment dates for these obligations are unknown, the
related balances have not been reflected in the "Payments Due by Period" section of the table.

[0001047469-14-009167:mdna:281]
(3)

[0001047469-14-009167:mdna:282]
As
specific payment dates to settle the income taxes payable are unknown at March 31, 2014, the related balances have not been reflected in the
"Payments Due by Period" section of the table.

[0001047469-14-009167:mdna:283]
Operating Leases

[0001047469-14-009167:mdna:284]
We lease facilities under operating leases, certain of which require us to pay property taxes, insurance and maintenance costs.
Operating leases for facilities are generally renewable at our option and usually include escalation clauses linked to inflation. The remaining terms on our non-cancelable operating leases expire in
various years through 2028. The liability for asset retirement obligations was not material for fiscal years 2014, 2013, and 2012.

[0001047469-14-009167:mdna:285]
Purchase Commitments

[0001047469-14-009167:mdna:286]
As of March 31, 2014, we have fixed purchase commitments of $102.8 million for inventory purchases made in the normal
course of business to original design manufacturers, contract manufacturers and other suppliers, the majority of which are expected to be fulfilled during the first quarter of fiscal year 2015. We
also had commitments of $46.0 million for consulting services, marketing arrangements, advertising, outsourced customer services, information technology maintenance and support services, and
other services. Fixed purchase commitments for capital expenditures amounted to $13.0 million and primarily relate to commitments for computer hardware and leasehold improvements. We expect to
continue making capital expenditures in the future to support product development activities and ongoing and expanded operations. Although open purchase commitments are considered enforceable and
legally binding, the terms generally allow us the option to reschedule and adjust our requirements based on business needs prior to delivery of goods or performance of services.

[0001047469-14-009167:mdna:287]
Income Taxes Payable

[0001047469-14-009167:mdna:288]
As of March 31, 2014, we had $93.1 million in non-current income taxes payable and $0.3 million in current income
taxes payable, including interest and penalties, related to our income tax liability for uncertain tax positions. As of March 31, 2013, we had $98.8 million in non-current income taxes
payable.

[0001047469-14-009167:mdna:289]
We
file Swiss and foreign tax returns. For all these tax returns, we are generally not subject to tax examinations for years prior to fiscal year 2001. We are under examination and have
received assessment notices in foreign tax jurisdictions. At this time, we are not able to estimate the potential impact that these examinations may have on income tax expense. If the examinations are
resolved unfavorably, there is a possibility they may have a material negative impact on our results of operations.

[0001047469-14-009167:mdna:290]
Obligation for Management Deferred Compensation

[0001047469-14-009167:mdna:291]
At March 31, 2014, we had $16.6 million in liabilities related to a deferred compensation plan offered by one of our
subsidiaries. See Note 5, Employee Benefit Plans, for more information.

[0001047469-14-009167:mdna:292]
Pension and Post-Employment Obligations

[0001047469-14-009167:mdna:293]
At March 31, 2014, we had $39.0 million in liabilities related to our defined benefit pension plans and non-retirement
post-employment benefit obligations, of which $1.1 million is payable in the next 12 months. See Note 5, Employee Benefit Plans,
for more information.

[0001047469-14-009167:mdna:294]
Off-Balance Sheet Arrangements

[0001047469-14-009167:mdna:295]
We have not entered into any transactions with unconsolidated entities whereby we have financial guarantees, subordinated retained
interests, derivative instruments or other contingent arrangements that expose us to material continuing risks, contingent liabilities, or any other obligation under a variable

[0001047469-14-009167:mdna:296]
75

[0001047469-14-009167:mdna:297]
interest
in an unconsolidated entity that provides financing, liquidity, market risk or credit risk support to us.

[0001047469-14-009167:mdna:298]
Other Contingencies:

[0001047469-14-009167:mdna:299]
As previously announced, some of the issues reviewed by the Audit Committee are also the subject of an ongoing formal investigation by
the SEC, including the accounting for Revue inventory valuation reserves that resulted in the restatement, revision to the Company's financial statements concerning warranty accruals and amortization
of intangible assets presented in our Form 10-K/A, filed on August 7, 2013, and the Company's transactions with a distributor for Fiscal Year 2007 through Fiscal Year 2009. The Company
is cooperating with the SEC in its ongoing investigation. The Company has entered into an agreement with the SEC to extend the statute of limitations. The Company cannot predict the outcome of the
investigation at this time and any potential fines or penalties, if any, that may arise from the investigation are currently not estimable.

[0001047469-14-009167:mdna:300]
Guarantees

[0001047469-14-009167:mdna:301]
Logitech International S.A., the parent holding company, has issued several parent guarantees on behalf of its subsidiaries. The
maximum potential future payment under the guarantee arrangements is limited to $80.0 million. As of March 31, 2014, there were no purchase obligations outstanding for which the parent
holding company was required to guarantee payment.

[0001047469-14-009167:mdna:302]
Logitech
Europe S.A., a subsidiary of the parent holding company, has guaranteed the purchase obligations of another Logitech subsidiary under a guarantee agreement. This
guarantee does not specify a maximum amount. As of March 31, 2014, the amount of purchase obligations outstanding under this guarantee was immaterial. In addition, Logitech Europe S.A.
also guaranteed payments of a third-party contract manufacturer's purchase obligations. As of March 31, 2014, the maximum amount of this guarantee was $3.5 million, of which
$2.3 million of guaranteed purchase obligations were outstanding.

[0001047469-14-009167:mdna:303]
Indemnifications

[0001047469-14-009167:mdna:304]
We indemnify certain of our suppliers and customers for losses arising from matters such as intellectual property disputes and product
safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys' fees.
As of March 31, 2014, no amounts have been accrued for indemnification provisions. We do not believe, based on historical experience and information currently available, that it is probable
that any material amounts will be required to be paid under our indemnification arrangements.

[0001047469-14-009167:mdna:305]
We
also indemnify our current and former directors and certain of our current and former officers. Certain costs incurred for providing such indemnification may be recoverable under
various insurance policies. We are unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not capped, the obligations are
conditional in nature, and the facts and circumstances involved in any situation that might arise are variable.

[0001047469-14-009167:mdna:306]
Research and Development

[0001047469-14-009167:mdna:307]
For a discussion of the Company's research and development activities, patents and licenses, please refer to Item 1, Business.

[0001047469-14-009167:mdna:308]
Quarterly Results of Operations

[0001047469-14-009167:mdna:309]
As a result of the findings of the Audit Committee's independent investigation, we have restated our unaudited quarterly financial data
for the quarter ended June 30, 2011, our discussion and analysis regarding our results of operations and cash flows for that quarter as is set forth below. For additional details, see
Note 2 of Notes to our Consolidated Financial Statements and the Company's Supplementary

[0001047469-14-009167:mdna:310]
Data
consisting of unaudited quarterly financial data immediately following Note 16 of Notes to our Consolidated Financial Statements in Part II, Item 8.

[0001047469-14-009167:mdna:311]
|  |  | Three months ended June 30, |  |
|  |  | 2011 |  | 2010 |  |
|  |  | As Restated |  | As Revised |  |
| Net sales |  | $ | 480,441 |  | $ | 479,330 |  |
| Cost of goods sold |  |  | 321,693 |  |  | 310,046 |  |
| Gross profit |  |  | 158,748 |  |  | 169,284 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Marketing and selling |  |  | 98,891 |  |  | 91,338 |  |
| Research and development |  |  | 40,022 |  |  | 38,264 |  |
| General and administrative |  |  | 26,096 |  |  | 27,271 |  |
| Total operating expenses |  |  | 165,009 |  |  | 156,873 |  |
| Operating income (loss) |  |  | (6,261 | ) |  | 12,411 |  |
| Interest income, net |  |  | 690 |  |  | 521 |  |
| Other income, net |  |  | 287 |  |  | 1,796 |  |
| Income (loss) before income taxes |  |  | (5,284 | ) |  | 14,728 |  |
| Benefit from income taxes |  |  | (9,393 | ) |  | (5,402 | ) |
| Net income |  |  | 4,109 |  |  | 20,130 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic |  | $ | 0.02 |  | $ | 0.11 |  |
| Diluted |  | $ | 0.02 |  | $ | 0.11 |  |
| Shares used to compute net income per share: |  |  |  |  |  |  |  |
| Basic |  |  | 179,331 |  |  | 175,492 |  |
| Diluted |  |  | 180,083 |  |  | 177,358 |  |

[0001047469-14-009167:mdna:312]
Net Sales

[0001047469-14-009167:mdna:313]
Net sales by channel for the three months ended June 30, 2011 and 2010 were as follows (in thousands):

[0001047469-14-009167:mdna:314]
|  |  | Three Months Ended June 30, |  |  |  |
|  |  | 2011 |  | 2010 |  | Change % |  |
| Retail |  | $ | 394,776 |  | $ | 393,867 |  |  | 0 | % |
| OEM |  |  | 49,178 |  |  | 58,335 |  |  | (16 | )% |
| LifeSize |  |  | 36,487 |  |  | 27,128 |  |  | 34 | % |
| Total net sales |  | $ | 480,441 |  | $ | 479,330 |  |  | 0 | % |

[0001047469-14-009167:mdna:315]
Our
total net sales were approximately the same in the fiscal quarters ended June 30, 2011 and 2010. Growth in retail sales of the Asia Pacific region and the LifeSize division
sales were offset by essentially flat retail sales in Americas region and declines in the EMEA region retail sales and OEM sales. Approximately 32% and 39% of the Company's total net sales were
denominated in currencies other than the U.S. dollar in the three months ended June 30, 2011 and 2010. If foreign currency exchange rates had been the same in three months ended June 30,
2011 and 2010, our constant dollar total net sales decrease would have been 4%.

[0001047469-14-009167:mdna:316]
77

[0001047469-14-009167:mdna:317]
Retail
units sold increased 2% and our overall retail average selling price decreased 2% in the three months ended June 30, 2011 compared with the three months ended
June 30, 2010. Sales of our retail products priced above $100 represented approximately 15% of our total retail sales in both the three months ended June 30, 2011 and 2010. Products
priced below $40 represented approximately 57% of retail sales in the fiscal quarter ended June 30, 2011 compared with 61% in the fiscal quarter ended June 30, 2010. If foreign currency
exchange rates had been the same in three months ended June 30, 2011 and 2010, our constant dollar retail sales decrease would have been 5%.

[0001047469-14-009167:mdna:318]
Units
sold to OEM customers declined 22% during the fiscal quarter ended June 30, 2011 compared with the same period in the prior fiscal year, primarily due to decreased sales of
our OEM mice and microphones for console singing games. Sales of our OEM mice decreased 12% and units sold decreased 19% during the quarter compared with the same period in the prior fiscal year.
Microphone sales decreased by 91% in the three months ended June 30, 2011 compared with the three months ended June 30, 2010. Sales of OEM keyboards and desktops increased 17% in dollars
during the quarter compared with the prior year, with unit sales essentially flat between the two periods.

[0001047469-14-009167:mdna:319]
LifeSize
net sales represent sales of video conferencing units and related software and services. Sales of our LifeSize products increased 34% in the three months ended June 30,
2011 compared with the three months ended June 30, 2010. Foreign currency exchange rates did not affect LifeSize sales.

[0001047469-14-009167:mdna:320]
Retail Sales by Region

[0001047469-14-009167:mdna:321]
The following table presents the change in retail sales by region for the three months ended June 30, 2011 compared with the
three months ended June 30, 2010.

[0001047469-14-009167:mdna:322]
|  |  | Three months ended June 30, 2011 |  |
| EMEA |  |  | (14 | )% |
| Americas |  |  | 1 | % |
| Asia Pacific |  |  | 29 | % |

[0001047469-14-009167:mdna:323]
Retail
sales in the EMEA region declined due to weak consumer demand for our products across much of Western Europe, most notably in the mature markets of Southern Europe such as Italy
and Spain, where the economic environment was particularly challenging. The largest retail sales declines in EMEA occurred in the audio, digital home and pointing devices product families. Our
constant dollar retail sales decrease in the EMEA region would have been 23%, if foreign currency exchange rates had been the same in the three months ended June 30, 2011 and 2010. Retail units
sold during the three months ended June 30, 2011 decreased 13% compared with the prior year, in line with the sales dollar decrease. Despite the weak demand, the overall level of inventory
carried by our channel partners declined by 22% from March 31, 2011 to June 30, 2011. We believe we have largely stabilized the EMEA-specific pricing and channel management programs
which created the execution issues that negatively impacted our profitability in the fourth quarter of fiscal year 2011. However, we believe that full implementation of the necessary operational
changes will continue through the remainder of fiscal year 2012 which has resulted in a reduction of our expectation for EMEA sales in fiscal year 2012. During the three months ended June 30,
2011, we did achieve strong growth in EMEA's emerging markets, particularly Russia, and sell-through in Germany, our largest market in EMEA, improved in the three months ended June 30, 2011
compared with the three months ended March 31, 2011.

[0001047469-14-009167:mdna:324]
In
Americas region, retail sales increased 1% and retail units sold were flat in the three months ended June 30, 2011 compared with the same period in the prior fiscal year,
primarily due to a 36% sales decline in the digital home product family, which was more than offset by increased sales of keyboards and desktops, pointing devices, and gaming products. In the digital
home category, sales of remote controls in first quarter of fiscal year 2011 included the launch of several new remotes, including the Harmony 300 and

[0001047469-14-009167:mdna:325]
the
Harmony 650, whereas the same period in fiscal year 2012 did not include any remote control product launches. In addition, one of our Americas region customers placed a sizable order for remotes
in the three months ended March 31, 2011, to support a promotion campaign, which negatively impacted sales in the three months ended June 30, 2011. The digital home category also
includes Logitech Revue and related peripherals, which had slightly negative sales in the quarter, as returns of the products were higher than the very modest sales. Retail sell-through in Americas
region increased during the fiscal quarter ended June 30, 2011 compared with the prior year. Foreign currency exchange rates had no effect on retail sales in the region for the three months
ended June 30, 2011.

[0001047469-14-009167:mdna:326]
Asia
Pacific region's retail sales grew 29% during the three months ended June 30, 2011 compared with the same period in 2010, driven primarily by sales in China, which increased
89% compared with the prior year. All product lines grew in the three months ended June 30, 2011 compared with the prior year quarter, except digital home. Total retail units sold in the Asia
Pacific region increased 31% during the quarter ended June 30, 2011 compared with the prior year. Retail sell-through during the quarter increased from the prior year in line with the sales
growth. If foreign currency exchange rates had been the same in the three months ended June 30, 2011 and 2010, our Asia Pacific constant dollar retail sales increase would have been 24%.

[0001047469-14-009167:mdna:327]
Net Retail Sales by Product Family

[0001047469-14-009167:mdna:328]
Net retail sales by product family during the three months ended June 30, 2011 and 2010 were as follows (in thousands):

[0001047469-14-009167:mdna:329]
|  |  | Three Months Ended June 30, |  |  |  |
|  |  | 2011 |  | 2010 |  | Change % |  |
| Retail—Pointing Devices |  | $ | 132,062 |  | $ | 131,846 |  |  | 0 | % |
| Retail—Keyboards & Desktops |  |  | 94,596 |  |  | 75,281 |  |  | 26 | % |
| Retail—Audio |  |  | 81,565 |  |  | 95,646 |  |  | (15 | )% |
| Retail—Video |  |  | 49,845 |  |  | 47,057 |  |  | 6 | % |
| Retail—Gaming |  |  | 23,392 |  |  | 15,451 |  |  | 51 | % |
| Retail—Digital Home |  |  | 13,316 |  |  | 28,586 |  |  | (53 | )% |
| Total net retail sales |  | $ | 394,776 |  | $ | 393,867 |  |  | 0 | % |

[0001047469-14-009167:mdna:330]
Logitech's
Pointing Devices product family includes our mice, trackballs and other pointing devices. Keyboards and desktops (mouse and keyboard combined) include cordless and corded
keyboards and desktops, and keyboards and keyboard cases for tablets. Audio includes speakers and headset products for the PC, the home, the tablet and other mobile entertainment platforms, and
wireless music systems. Our video product family is comprised of PC webcams and Alert video security systems. Gaming includes console and PC gaming peripherals. The Digital Home product family
combines our advanced Harmony Remote controls, Logitech Revue with Google TV, and peripherals associated with the Google TV platform. Net sales reflect accruals for product returns, cooperative
marketing arrangements, customer incentive programs and pricing programs.

[0001047469-14-009167:mdna:331]
Retail Pointing Devices

[0001047469-14-009167:mdna:332]
A decline in dollar sales of pointing devices in our EMEA region for the first quarter of fiscal year 2012 was offset by growth in
Americas and Asia Pacific regions. Retail unit sales of pointing devices increased 9% in the three months ended June 30, 2011 compared with the same period in 2010. Dollar sales of cordless
mice increased 10%, while units grew 24% in the quarter. We achieved strong sales and unit growth in both our high-end as well as our value-priced cordless mice. Dollar sales of cordless mice grew in
both Americas and Asia Pacific regions, with sales in China more than doubling. Unit sales of cordless mice grew in all three regions, with the strongest growth in China. Sales and units of corded
mice decreased 19% and 6% in the three months ended June 30, 2011 compared with the prior fiscal year, with dollar sales declines in all regions.

[0001047469-14-009167:mdna:333]
Retail Keyboards and Desktops

[0001047469-14-009167:mdna:334]
Retail unit sales of keyboards and desktops increased 16% during the quarter ended June 30, 2011 compared with 2010, primarily
due to our cordless keyboards and desktops. Sales of cordless keyboards more than doubled in dollars compared with the prior year, led by the Wireless Solar Keyboard K750. Sales of cordless desktops
increased 2% in dollars during the three months ended June 30, 2011 compared with 2010. We also launched our iPad specific keyboard products in limited distribution, with encouraging results
during the quarter ended June 30, 2011. This new tablet accessories product line includes the Keyboard Case for iPad2 and the Tablet Keyboard for iPad, with additional products planned for
launch in future quarters.

[0001047469-14-009167:mdna:335]
Retail Audio

[0001047469-14-009167:mdna:336]
Retail audio unit sales decreased 13% in the three months ended June 30, 2011 compared with the same period in the prior year.
Dollar sales growth in the Asia Pacific region was more than offset by declines in EMEA and Americas. PC speaker sales decreased 12% in dollars and 5% in units. Sales of our iPod speakers decreased
15% in dollars and 22% in units in the three months ended June 30, 2011 compared with the prior year. Partially offsetting the sales declines in speakers, our Ultimate Ears line of earphones
grew 12% in dollars during the quarter.

[0001047469-14-009167:mdna:337]
Retail Video

[0001047469-14-009167:mdna:338]
Our retail sales in the Video category increased 6%, while units decreased 9% in the quarter ended June 30, 2011 compared with
2010. The growth in sales was driven entirely by the Logitech Alert line of digital video security systems. Webcam sales declined 7% in dollars and 10% in units in the three months ended
June 30, 2011 compared with the same period in 2010, with growth in the Asia Pacific region offset by the sales decline in Americas region.

[0001047469-14-009167:mdna:339]
Retail Gaming

[0001047469-14-009167:mdna:340]
Retail sales of our gaming peripherals grew 51%, while unit sales decreased 7% during the three months ended June 30, 2011
compared with the same period in 2010. The dollar sales growth was due to strong sales of our steering wheels. Steering wheels have a higher selling price than our other gaming products, which
explains the decline in unit sales. PC gaming sales increased 53% in dollars and decreased 4% in units during the three months ended June 30, 2011 compared with the three months ended
June 30, 2010. Console gaming sales increased 69% in dollars and decreased 15% in units in the same periods.

[0001047469-14-009167:mdna:341]
Retail Digital Home

[0001047469-14-009167:mdna:342]
Retail sales in our digital home category, which includes Harmony remotes, Logitech Revue, and our Google TV peripherals, declined 53%
during the quarter ended June 30, 2011 compared with the same quarter in the prior year. Sales of Harmony remotes decreased
48%, with the largest decline in EMEA due to slow moving channel inventory as a result of weak macroeconomic conditions in several countries, combined with the impact of execution issues in
EMEA-specific pricing and channel management programs. The sales decrease in Americas region was attributable to higher sales in the three months ended June 30, 2010 from the successful launch
of several new remotes, and a sizable order from one customer to support a promotion campaign, which occurred in the three months ended March 31, 2011 rather than the three months ended
June 30, 2011.

[0001047469-14-009167:mdna:343]
Gross Profit

[0001047469-14-009167:mdna:344]
Gross profit for the three months ended June 30, 2011 and 2010 was as follows (in thousands):

[0001047469-14-009167:mdna:345]
|  |  | Three Months Ended June 30, |  |
|  |  | 2011 |  | 2010 |  | Change |  |
|  |  | As Restated |  | As Revised |  |  |  |
| Net sales |  | $ | 480,441 |  | $ | 479,330 |  |  | 0 | % |
| Cost of goods sold |  |  | 321,693 |  |  | 310,046 |  |  | 4 |  |
| Gross profit |  | $ | 158,748 |  | $ | 169,284 |  |  | (6 | ) |
| Gross margin |  |  | 33.0 | % |  | 35.3 | % |  |  |  |

[0001047469-14-009167:mdna:346]
Gross
profit consists of net sales, less cost of goods sold which includes materials, direct labor and related overhead costs, costs of manufacturing facilities, costs of purchasing
components from outside suppliers, distribution costs, write-down of inventories and amortization of intangible assets.

[0001047469-14-009167:mdna:347]
Gross
margin declined to 33.0% in the three months ended June 30, 2011 compared with 35.3% in the same period in the prior year, primarily due to product mix in retail sales also
contributed to the lower gross margin in the first quarter of fiscal year 2012.

[0001047469-14-009167:mdna:348]
Operating Expenses

[0001047469-14-009167:mdna:349]
Operating expenses for the three months ended June 30, 2011 and 2010 were as follows (in thousands):

[0001047469-14-009167:mdna:350]
|  |  | Three Months Ended June 30, |  |
|  |  | 2011 |  | 2010 |  | Change |  |
|  |  | As Restated |  | As Revised |  |  |  |
| Marketing and selling |  | $ | 98,891 |  | $ | 91,338 |  |  | 8 | % |
| % of net sales |  |  | 20.6 | % |  | 19.1 | % |  |  |  |
| Research and development |  |  | 40,022 |  |  | 38,264 |  |  | 5 |  |
| % of net sales |  |  | 8.3 | % |  | 8.0 | % |  |  |  |
| General and administrative |  |  | 26,096 |  |  | 27,271 |  |  | (4 | ) |
| % of net sales |  |  | 5.4 | % |  | 5.7 | % |  |  |  |
| Total operating expenses |  | $ | 165,009 |  | $ | 156,873 |  |  | 5 |  |
| % of net sales |  |  | 34.3 | % |  | 32.7 | % |  |  |  |

[0001047469-14-009167:mdna:351]
Approximately
all increase in total operating expenses in the three months ended June 30, 2011 compared with the same period in the prior year was due to investments in marketing,
selling, research, and development related to our LifeSize division.

[0001047469-14-009167:mdna:352]
We
refer to our operating expenses excluding the impact of foreign currency exchange rates as constant dollar operating expenses. Constant dollar operating expenses are a non-GAAP
financial measure, which is information derived from consolidated financial information but not presented in our financial statements prepared in accordance with U.S. GAAP. Our management uses
these non-GAAP measures in its financial and operational decision-making, and believes these non-GAAP measures, when considered in conjunction with the corresponding GAAP measures, facilitate a better
understanding of changes in operating expenses. Constant dollar operating expenses are calculated by translating prior period operating expenses in each local currency at the current period's average
exchange rate for that currency.

[0001047469-14-009167:mdna:353]
Marketing and Selling

[0001047469-14-009167:mdna:354]
Marketing and selling expense consists of personnel and related overhead costs, corporate and product marketing, promotions,
advertising, trade shows, customer and technical support and facilities costs.

[0001047469-14-009167:mdna:355]
Marketing
and selling expenses increased 8% in the three months ended June 30, 2011 compared with the same period in the prior fiscal year primarily due to additional sales and
marketing headcount for LifeSize, B2B and Asia Pacific region, and additional trade show and public relations initiatives for our LifeSize products. Stock compensation costs also increased, due to the
use of RSUs (restricted stock units) instead of stock options. RSUs are less dilutive to shareholders because in general a smaller number of RSUs is granted, since the value at grant of RSUs is
generally greater than the value of stock options. Settlement of a customer bankruptcy dispute also increased expenses in the three months ended June 30, 2011 compared with 2010. Offsetting
these increases were decreases in bonuses, advertising expense, bad debt expense and sales warehouse expense.

[0001047469-14-009167:mdna:356]
The
impact of foreign currency exchange rates also caused sales and marketing expenses to increase. If foreign currency exchange rates had been the same in the three months ended
June 30, 2011 and 2010, the percentage change in constant dollar marketing and selling expense for the three months ended June 30, 2011 would have been 4%.

[0001047469-14-009167:mdna:357]
Research and Development

[0001047469-14-009167:mdna:358]
Research and development expense consists of personnel and related overhead costs, contractors and outside consultants, supplies and
materials, equipment depreciation and facilities costs, all associated with the design and development of new products and enhancements of existing products.

[0001047469-14-009167:mdna:359]
The
5% increase in research and development expense for the three months ended June 30, 2011 compared with the same period in the prior year was primarily due to investment in our
LifeSize division and B2B products, and packaging evaluations. Research and development expense growth for our peripherals division was approximately the same as the change in retail peripherals
sales.

[0001047469-14-009167:mdna:360]
If
foreign currency exchange rates had been the same in the three months ended June 30, 2011 and 2010, there would have been no change in constant dollar research and development
expense.

[0001047469-14-009167:mdna:361]
General and Administrative

[0001047469-14-009167:mdna:362]
General and administrative expense consists primarily of personnel and related overhead and facilities costs for the finance,
information systems, executive, human resources and legal functions.

[0001047469-14-009167:mdna:363]
General
and administrative expense decreased 4% in the three months ended June 30, 2011 compared with the same period last year. Expense decreased due to one-time
$4.9 million recovery of expense from disposal of one abandoned building in China, offset by $2.1 million increase in personnel-related expenses, increased stock compensation expense
from the use of RSUs, recruiting fees and increased litigation expenses.

[0001047469-14-009167:mdna:364]
Interest Income, Net

[0001047469-14-009167:mdna:365]
Interest income and expense for the three months ended June 30, 2011 and 2010 were as follows (in thousands):

[0001047469-14-009167:mdna:366]
|  |  | Three Months Ended June 30, |  |  |  |
|  |  | 2011 |  | 2010 |  | Change |  |
| Interest income |  | $ | 690 |  | $ | 523 |  |  | 32 | % |
| Interest expense |  |  | — |  |  | (2 | ) |  | 100 | % |
| Interest income, net |  | $ | 690 |  | $ | 521 |  |  | 32 | % |

[0001047469-14-009167:mdna:367]
Interest
income increased slightly during the three months ended June 30, 2011 compared with the same period in the prior fiscal year due to slightly higher interest rates.

[0001047469-14-009167:mdna:368]
Other Income, Net

[0001047469-14-009167:mdna:369]
Other income and expense for the three months ended June 30, 2011 and 2010 were as follows (in thousands):

[0001047469-14-009167:mdna:370]
|  |  | Three Months Ended June 30, |  |  |  |
|  |  | 2011 |  | 2010 |  | Change |  |
| Foreign currency exchange gains, net |  | $ | 340 |  | $ | 360 |  |  | (6 | )% |
| Gain on sale of property and plant |  |  | — |  |  | 838 |  |  | (100 | )% |
| Investment income related to deferred compensation plan |  |  | 188 |  |  | 435 |  |  | (57 | )% |
| Other, net |  |  | (241 | ) |  | 163 |  |  | (248 | )% |
| Other income, net |  | $ | 287 |  | $ | 1,796 |  |  | (840 | )% |

[0001047469-14-009167:mdna:371]
Foreign
currency exchange gains or losses relate to balances denominated in currencies other than the functional currency of a particular subsidiary, to the sale of currencies, and to
gains or losses recognized on foreign exchange forward contracts.

[0001047469-14-009167:mdna:372]
The
gain on sale of building for the three months ended June 30, 2010 relates to the sale of our building in Romanel, Switzerland.

[0001047469-14-009167:mdna:373]
Investment
income for the three months ended June 30, 2011 represents earnings and realized and unrealized gains on trading investments related to a deferred compensation plan
offered by one of our subsidiaries. Investment income for the three months ended June 30, 2010 represents changes in the cash surrender value of Company-owned life insurance contracts, related
to the same management deferred compensation plan. In December 2010, the Company surrendered the life insurance contracts for cash, and invested the proceeds in a portfolio of mutual funds, which are
classified as trading investments.

[0001047469-14-009167:mdna:374]
Provision for Income Taxes

[0001047469-14-009167:mdna:375]
The provision for income taxes and effective tax rates for the three months ended June 30, 2011 and 2010 were as follows (in
thousands):

[0001047469-14-009167:mdna:376]
|  |  | Three Months Ended June 30, |  |
|  |  | 2011 |  | 2010 |  |
|  |  | As Restated |  | As Revised |  |
| Benefit from income taxes |  | $ | (9,393 | ) | $ | (5,402 | ) |
| Effective income tax rate |  |  | 177.8 | % |  | (36.7 | )% |

[0001047469-14-009167:mdna:377]
The
provision for income taxes consists of income and withholding taxes. Logitech operates in multiple jurisdictions and its profits are taxed pursuant to the tax laws of these
jurisdictions. The Company's effective income tax rate may be affected by changes in or interpretations of tax laws in any given jurisdiction, utilization of net operating loss and tax credit
carryforwards, changes in geographical mix of income and expense, and changes in management's assessment of matters such as the ability to realize deferred tax assets.

[0001047469-14-009167:mdna:378]
The
change in the effective income tax rate for the three months ended June 30, 2011 compared with the three months ended June 30, 2010 is primarily due to the mix of
income and losses in the various tax jurisdictions in which the Company operates, and a discrete tax benefit of $7.2 million in the three months ended June 30, 2010 from the closure of
income tax audits in certain jurisdictions.

[0001047469-14-009167:mdna:379]
As
of June 30 and March 31, 2011, the total amount of unrecognized tax benefits due to uncertain tax positions was $129.6 million and $130.1 million, of which
$117.0 million and $118.2 million would affect the effective income tax rate if recognized. The decline in the income tax liability associated with uncertain tax benefits is primarily
due to the expiration of statutes of limitations, offset by the impact of foreign currency exchange rates and the accrual of interest expense.

[0001047469-14-009167:mdna:380]
The
Company continues to recognize interest and penalties related to unrecognized tax positions in income tax expense. As of June 30 2011, accrued interest and penalties related
to uncertain tax positions increased to $8.1 million from $8.0 million as of March 31, 2011.

[0001047469-14-009167:mdna:381]
The
Company files Swiss and foreign tax returns. For all these tax returns, the Company is generally not subject to tax examinations for years prior to 1999. During the third quarter of
fiscal year 2011, the U.S. Internal Revenue Service expanded its examination of the Company's U.S. subsidiary to include fiscal years 2008 and 2009 in addition to fiscal years 2006 and 2007. The
Company is also under examination in other tax jurisdictions. At this time it is not possible to estimate the potential impact that these examinations may have on income tax expense. If the
examinations are resolved unfavorably, there is a possibility they may have a material impact on our results of operations.

[0001047469-14-009167:mdna:382]
Although
the Company has adequately provided for uncertain tax positions, the provisions on these positions may change as revised estimates are made or the underlying matters are settled
or otherwise resolved. Although the timing of the resolution or closure on audits is highly uncertain, the Company does not believe it is reasonably possible that the unrecognized tax benefits would
materially change in the next twelve months.

[0001047469-14-009167:mdna:383]
Liquidity and Capital Resources

[0001047469-14-009167:mdna:384]
Cash Balances, Available Borrowings, and Capital Resources

[0001047469-14-009167:mdna:385]
During the three months ended June 30, 2011, operating activities provided net cash of $5.4 million. Our largest sources
of operating cash flows were decrease in accounts receivable and increase in accounts payable balances compared with March 31, 2011, offset by increases in inventory and deferred tax assets.
Net cash used in investing activities was $7.3 million. We invested $12.2 million in capital expenditures for

[0001047469-14-009167:mdna:386]
tooling,
equipment, computer hardware, and software, which was partially offset by proceeds of $4.9 million from the sale of one of our buildings. Net cash provided by financing activities was
$0.5 million, primarily from proceeds from employee stock purchases and the exercise of stock options.

[0001047469-14-009167:mdna:387]
At
June 30, 2011, we had cash and cash equivalents of $476.4 million, comprised of bank demand deposits and short-term time deposits. Cash and cash equivalents are carried
at cost, which is equivalent to fair value.

[0001047469-14-009167:mdna:388]
The
Company has credit lines with several European and Asian banks totaling $150.3 million as of June 30, 2011. As is common for businesses in European and Asian countries,
these credit lines are uncommitted and unsecured. Despite the lack of formal commitments from the banks, we believe that these lines of credit will continue to be made available because of our
long-standing relationships with these banks and our current financial condition. At June 30, 2011, there were no outstanding borrowings under these lines of credit. There are no financial
covenants under these facilities.

[0001047469-14-009167:mdna:389]
We
provide various third parties with irrevocable letters of credit in the normal course of business to secure our obligations to pay or perform pursuant to the requirements of an
underlying agreement or the provision of goods and services. These standby letters of credit are cancelable only at the option of the beneficiary who is authorized to draw drafts on the issuing bank
up to the face amount of the standby letter of credit in accordance with its terms. At June 30, 2011, we had $0.6 million of letters of credit in place, of which $0.1 million was
outstanding. These letters of credit relate primarily to equipment purchases by a subsidiary in China, and expire between July and December 2011.

[0001047469-14-009167:mdna:390]
The
Company has financed its operating and capital requirements primarily through cash flow from operations and, to a lesser extent, from capital markets and bank borrowings. Our normal
short-term liquidity and long-term capital resource requirements are provided from three sources: cash flow generated from operations, cash and cash equivalents on hand, and borrowings, as needed,
under our credit facilities.

[0001047469-14-009167:mdna:391]
Based
upon our available cash balances and credit lines, and the trend of our historical cash flow generation, we believe we have sufficient liquidity to fund operations for the
foreseeable future.

[0001047469-14-009167:mdna:392]
Cash Flow from Operating Activities

[0001047469-14-009167:mdna:393]
The following table presents selected financial information and statistics as of June 30, 2011 and 2010 (dollars in thousands):

[0001047469-14-009167:mdna:394]
|  |  | June 30, |  |
|  |  | 2011 |  | 2010 |  |
|  |  | As Restated |  | As Revised |  |
| Accounts receivable, net |  | $ | 241,456 |  | $ | 213,567 |  |
| Inventories |  |  | 320,592 |  |  | 279,800 |  |
| Net cash provided by operating activities |  |  | 5,374 |  |  | 8,054 |  |
| Days sales in accounts receivable ("DSO")(1) |  |  | 45 days |  |  | 40 days |  |
| Inventory turnover ("ITO")(2) |  |  | 4.0x |  |  | 4.4x |  |

[0001047469-14-009167:mdna:395]
(1)

[0001047469-14-009167:mdna:396]
DSO
is determined using ending accounts receivable as of the most recent quarter-end and net sales for the most recent quarter.

[0001047469-14-009167:mdna:397]
(2)

[0001047469-14-009167:mdna:398]
ITO
is determined using ending inventories and annualized cost of goods sold (based on the most recent quarterly cost of goods sold).

[0001047469-14-009167:mdna:399]
Net cash provided by operating activities decreased to $5.4 million in the three months ended June 30, 2011, from $8.1 million for the same
period in the prior year. The primary drivers of the decline in operating cash flows were the net income of $4.1 million in the three months ended June 30, 2011 compared with net income
of $20.1 million in the three months ended June 30, 2010, and a lower increase in current liabilities, offset by a decrease in accounts receivable when compared with the change in that
balance during the three months ended June 30, 2010.

[0001047469-14-009167:mdna:400]
DSO
for the quarter was five days higher than the same period in the prior year, primarily due to greater sales linearity in the three months ended June 30, 2010. Typical payment
terms require customers to pay for product sales generally within 30 to 60 days. However, terms may vary by customer type, by country and by selling season. Extended payment terms are sometimes
offered to a limited number of customers during the second and third fiscal quarters. The Company does not modify payment terms on existing receivables, but may offer discounts for early payment.

[0001047469-14-009167:mdna:401]
Inventory
turns for the three months ended June 30, 2011 were slightly lower than that in the three months ended June 30, 2010.

[0001047469-14-009167:mdna:402]
Cash Flow from Investing Activities

[0001047469-14-009167:mdna:403]
Cash flows from investing activities during the three months ended June 30, 2011 and 2010 were as follows (in thousands):

[0001047469-14-009167:mdna:404]
|  |  | Three months ended June 30, |  |
|  |  | 2011 |  | 2010 |  |
|  |  | As Restated |  | As Revised |  |
| Purchases of property, plant and equipment |  | $ | (12,191 | ) | $ | (13,854 | ) |
| Proceeds from sale of property and plant |  |  | 4,904 |  |  | 2,688 |  |
| Purchases of trading investments |  |  | (3,545 | ) |  | — |  |
| Proceeds from sale of trading investments |  |  | 3,500 |  |  | — |  |
| Net cash used in investing activities |  | $ | (7,332 | ) | $ | (11,166 | ) |

[0001047469-14-009167:mdna:405]
Our
capital expenditures during the three months ended June 30, 2011 and 2010 were principally for computer hardware and software purchases, equipment, and normal expenditures for
tooling.

[0001047469-14-009167:mdna:406]
Proceeds
from the sale of property, plant and equipment were related to the sale of an unused manufacturing facility in China in the three months ended June 30, 2011 and the sale
of our building in Romanel, Switzerland in the three months ended June 30, 2010.

[0001047469-14-009167:mdna:407]
The
purchases and sales of trading investments in the three months ended June 30, 2011 represent mutual fund activity directed by participants in a deferred compensation plan
offered by one of the Company's subsidiaries. The mutual funds are held by a Rabbi Trust. In the three months ended June 30, 2010, the deferred compensation plan was invested in life insurance
contracts.

[0001047469-14-009167:mdna:408]
Cash Flow from Financing Activities

[0001047469-14-009167:mdna:409]
The following table presents information on our cash flows from financing activities during the three months ended June 30, 2011
and 2010 (in thousands):

[0001047469-14-009167:mdna:410]
|  |  | Three months ended June 30, |  |
|  |  | 2011 |  | 2010 |  |
| Proceeds from sale of shares upon exercise of options and purchase rights |  | $ | 607 |  | $ | 5,329 |  |
| Tax withholdings related to net share settlements of RSUs |  |  | (176 | ) |  | (223 | ) |
| Excess tax benefits from share-based compensation |  |  | 24 |  |  | 421 |  |
| Net cash provided by financing activities |  | $ | 455 |  | $ | 5,527 |  |

[0001047469-14-009167:mdna:411]
During
the three months ended June 30, 2011 and 2010, cash of $0.6 million and $5.3 million was provided by the sale of shares upon exercise of options and purchase
rights pursuant to the Company's stock plans. The payment of tax withholdings related to net share settlements of RSUs (restricted stock units) required the use of $0.2 million in cash in both
three month periods ended June 30, 2011 and 2010. Tax benefits recognized on the exercise of share-based payment awards provided $0.02 million and $0.4 million in the three months
ended June 30, 2011 and 2010.
