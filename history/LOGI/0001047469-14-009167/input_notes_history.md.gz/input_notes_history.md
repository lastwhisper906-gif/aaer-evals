# LOGI note change history — 0001104659-13-081156 → 0001104659-14-005272


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-01-30):
[0001104659-14-005272:note_history:1]
The Company leases facilities under operating leases, certain of which require it to pay property taxes, insurance and maintenance costs. Operating leases for facilities are generally renewable at the Company’s option and usually include escalation clauses linked to inflation. Future minimum annual rentals under non-cancelable operating leases as of December 31, 2013 amounted to $80.0 million.
  (was, 2013-11-05, similarity 0.9819):
[0001104659-13-081156:note_history:1]
The Company leases facilities under operating leases, certain of which require it to pay property taxes, insurance and maintenance costs. Operating leases for facilities are generally renewable at the Company’s option and usually include escalation clauses linked to inflation. Future minimum annual rentals under non-cancelable operating leases at September 30, 2013 amounted to $84.7 million.

- changed (2014-01-30):
[0001104659-14-005272:note_history:2]
The following table describes changes to the Company’s asset retirement obligation liability for the three and nine months ended December 31, 2013 and 2012 (in thousands):
  (was, 2013-11-05, similarity 0.9693):
[0001104659-13-081156:note_history:2]
The following table describes changes to the Company’s asset retirement obligation liability for the three and six months ended September 30, 2013 and 2012 (in thousands):

- added (2014-01-30):
[0001104659-14-005272:note_history:3]
|  |  | Three Months Ended |  | Nine Months Ended |  |
|  |  | December 31, |  | December 31, |  |
|  |  | 2013 |  | 2012 |  | 2013 |  | 2012 |  |
| Beginning of the period |  | $ | 1,178 |  | $ | 1,870 |  | $ | 1,750 |  | $ | 1,918 |  |
| Accrued expenses |  | — |  | 63 |  | — |  | 63 |  |
| Expenses settled |  | — |  | (200 | ) | (596 | ) | (200 | ) |
| Accretion |  | 4 |  | 5 |  | 15 |  | 21 |  |
| Foreign currency translation |  | 4 |  | 32 |  | 17 |  | (32 | ) |
| End of the period |  | $ | 1,186 |  | $ | 1,770 |  | $ | 1,186 |  | $ | 1,770 |  |

- changed (2014-01-30):
[0001104659-14-005272:note_history:4]
All of the Company’s products are covered by warranty to be free from defects in material and workmanship for periods ranging from one to five years. At the time of sale, the Company accrues a warranty liability for estimated costs to provide replacement products and parts or services to repair products under the warranty obligation. The Company’s estimate of costs to fulfill its warranty obligations is based on historical experience and expectations of future requirements. When the Company experiences changes in warranty claim activity or costs associated with fulfilling those claims, the warranty liability is adjusted accordingly. Changes in the Company’s warranty liability for the three and nine months ended December 31, 2013 and 2012 were as follows (in thousands):
  (was, 2013-11-05, similarity 0.9337):
[0001104659-13-081156:note_history:4]
All of the Company’s products are covered by warranty to be free from defects in material and workmanship for periods ranging from one year to five years. At the time of sale, the Company accrues a warranty liability for estimated costs to provide replacement products, parts or services to repair or replace products in satisfaction of the warranty obligation. The Company’s estimate of costs to fulfill its warranty obligations is based on historical experience and expectations of future requirements. When the Company experiences changes in warranty claim activity or costs associated with fulfilling those claims, the warranty liability is adjusted accordingly. Changes in the Company’s warranty liability for the three and six months ended September 30, 2013 and 2012 were as follows (in thousands):

- added (2014-01-30):
[0001104659-14-005272:note_history:5]
|  |  | Three Months Ended |  | Nine Months Ended |  |
|  |  | December 31, |  | December 31, |  |
|  |  | 2013 |  | 2012 |  | 2013 |  | 2012 |  |
|  |  |  |  | (revised) |  |  |  | (revised) |  |
| Beginning of the period |  | $ | 22,085 |  | $ | 23,537 |  | $ | 20,538 |  | $ | 25,494 |  |
| Provision |  | 4,143 |  | 4,169 |  | 10,788 |  | 10,149 |  |
| Settlements |  | (3,568 | ) | (3,955 | ) | (10,993 | ) | (11,892 | ) |
| Adjustment (1) |  | — |  | — |  | 2,327 |  | — |  |
| End of the period |  | $ | 22,660 |  | $ | 23,751 |  | $ | 22,660 |  | $ | 23,751 |  |

- changed (2014-01-30):
[0001104659-14-005272:note_history:6]
(1)         During the nine months ended December 31, 2013, the warranty liability allocated to the Company’s Retail — Remotes product category was reclassified from liabilities held for sale.
  (was, 2013-11-05, similarity 0.711):
[0001104659-13-081156:note_history:6]
(1)         Represents warranty liability previously allocated to the Company’s Retail — Remotes product category which was classified as an asset held for sale as of March 31, 2013.

- changed (2014-01-30):
[0001104659-14-005272:note_history:7]
The Company’s video conferencing reporting unit offers maintenance contracts for sale of the majority of its products which allow for customers to receive service and support in addition to the expiration of the product warranty contractual term. The Company also provides installation services to its customers under contractual arrangements. The Company recognizes these contracts over the life of the service period.
  (was, 2013-11-05, similarity 0.8557):
[0001104659-13-081156:note_history:7]
The Company’s video conferencing reporting unit offers maintenance contracts for sale of the majority of its products which allow for customers to receive service and support in addition to the expiration of the product warranty contractual term.  The Company also provides installation services to its customer under contractual arrangements.  The Company recognizes these contracts over the life of the service period.  Change in the Company’s deferred services revenue during the three and six months ended September 30, 2013 and 2012 were as follows (in thousands):

- added (2014-01-30):
[0001104659-14-005272:note_history:8]
Changes in the Company’s deferred services revenue during the three and nine months ended December 31, 2013 and 2012 were as follows (in thousands):

- added (2014-01-30):
[0001104659-14-005272:note_history:9]
|  |  | Three Months Ended |  | Nine Months Ended |  |
|  |  | December 31, |  | December 31, |  |
|  |  | 2013 |  | 2012 |  | 2013 |  | 2012 |  |
| Beginning of the period |  | $ | 29,068 |  | $ | 27,119 |  | $ | 29,328 |  | $ | 24,568 |  |
| Extended warranties issued |  | 8,800 |  | 8,690 |  | 24,630 |  | 25,084 |  |
| Amortization |  | (8,120 | ) | (7,672 | ) | (24,210 | ) | (21,515 | ) |
| End of the period |  | $ | 29,748 |  | $ | 28,137 |  | $ | 29,748 |  | $ | 28,137 |  |

- changed (2014-01-30):
[0001104659-14-005272:note_history:10]
The cost of providing these services for the three and nine months ended December 31, 2013 was $1.5 million and $5.7 million, respectively, compared to $2.6 million and $6.9 million for the three and nine months ended December 31, 2012, respectively.
  (was, 2013-11-05, similarity 0.6093):
[0001104659-13-081156:note_history:10]
The cost of providing these services for the three months ended September 30, 2013 and 2012 was $2.1 million and $2.3 million, respectively, and for the six months ended September 30, 2013 and 2012 was $4.2 million and $4.3 million, respectively.

- changed (2014-01-30):
[0001104659-14-005272:note_history:11]
At December 31, 2013, the Company had the following outstanding purchase commitments:
  (was, 2013-11-05, similarity 0.9686):
[0001104659-13-081156:note_history:11]
At September 30, 2013, the Company had the following outstanding purchase commitments:

- changed (2014-01-30):
[0001104659-14-005272:note_history:12]
|  |  | December 31, |  |
|  |  | 2013 |  |
| Inventory commitments |  | $ | 97,020 |  |
| Operating expenses |  | 56,305 |  |
| Capital commitments |  | 16,892 |  |
|  |  | $ | 170,217 |  |
  (was, 2013-11-05, similarity 0.8472):
[0001104659-13-081156:note_history:12]
|  |  | September 30, 2013 |  |
| Inventory purchases |  | $ | 132,782 |  |
| Operating expenses |  | 63,426 |  |
| Capital expenditures |  | 18,372 |  |
|  |  | $ | 214,580 |  |

- changed (2014-01-30):
[0001104659-14-005272:note_history:13]
Commitments for inventory purchases are made in the normal course of business to original design manufacturers and to other suppliers for the Company’s internal manufacturing, the majority of the contract manufacturers and other suppliers and are expected to be fulfilled by March 2014. Operating expense commitments are for consulting services, marketing arrangements, advertising, outsourced customer services, information technology maintenance and support services and other services. Fixed purchase commitments for capital expenditures primarily related to commitments for computer hardware and leasehold improvements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the Company the option to reschedule and adjust its requirements based on the business needs prior to delivery of goods or performance of services.
  (was, 2013-11-05, similarity 0.9536):
[0001104659-13-081156:note_history:13]
Commitments for inventory purchases are made in the normal course of business to original design manufacturers, the majority of the contract manufacturers and other suppliers and are expected to be fulfilled by December 2013. Operating expense commitments are for consulting services, marketing arrangements, advertising, outsourced customer services, information technology maintenance and support services, and other services. Fixed purchase commitments for capital expenditures primarily related to commitments for computer hardware and leasehold improvements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the Company the option to reschedule and adjust its requirements based on the business needs prior to delivery of goods or performance of services.

- changed (2014-01-30):
[0001104659-14-005272:note_history:14]
Logitech International S.A., the parent holding company, has guaranteed payment of the purchase obligations of various subsidiaries from certain component suppliers. The maximum potential future payment under the guarantee arrangements is limited to $30.0 million. As of December 31, 2013, there were no purchase obligations outstanding for which the parent holding company was required to guarantee payment.
  (was, 2013-11-05, similarity 0.7107):
[0001104659-13-081156:note_history:14]
Logitech International S.A., the parent holding company, has guaranteed payment of the purchase obligations of various subsidiaries from certain component suppliers. These guarantees generally have an unlimited term. The maximum potential future payment under the guarantee arrangements is limited to $30.0 million. At September 30, 2013, there were no purchase obligations outstanding for which the parent holding company was required to guarantee payment.

- added (2014-01-30):
[0001104659-14-005272:note_history:15]
Logitech Europe S.A., a subsidiary of the parent holding company, has guaranteed the purchase obligations of another Logitech subsidiary under a guarantee agreement. This guarantee does not specify a maximum amount. As of December 31, 2013, there was no amount of purchase obligations outstanding under this guarantee. In addition, Logitech Europe S.A. also guaranteed payments of a third-party contract manufacturer’s purchase obligations as it relates to the Company. As of December 31, 2013, the maximum amount of this guarantee was $3.5 million, of which $1.6 million of guaranteed purchase obligations were outstanding.

- changed (2014-01-30):
[0001104659-14-005272:note_history:16]
Logitech International S.A. and Logitech Europe S.A. have guaranteed certain contingent liabilities of various subsidiaries related to transactions occurring in the normal course of business. As of December 31, 2013, the maximum amount of the guarantees was $28.4 million, of which $5.2 million of guaranteed obligations were outstanding.
  (was, 2013-11-05, similarity 0.8839):
[0001104659-13-081156:note_history:16]
Logitech International S.A. and Logitech Europe S.A. have guaranteed certain contingent liabilities of various subsidiaries related to transactions occurring in the normal course of business. The maximum amount of the guarantees was $35.0 million as of September 30, 2013 and $5.6 million of guaranteed obligations were outstanding under these agreements.

- added (2014-01-30):
[0001104659-14-005272:note_history:17]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of December 31, 2013, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

- added (2014-01-30):
[0001104659-14-005272:note_history:18]
The Company also indemnifies its current and former directors and certain of its current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. The Company is unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not limited, the obligations are conditional in nature and the facts and circumstances involved in any situation that might arise are variable.

- changed (2014-01-30):
[0001104659-14-005272:note_history:19]
From time to time the Company is involved in claims and legal proceedings which arise in the ordinary course of its business. The Company is currently subject to several such claims and a small number of legal proceedings. The Company believes that these matters lack merit and intends to vigorously defend against them. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company’s defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company’s business, financial condition, cash flows and results of operations in a particular period. Any claims or proceedings against the Company, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company’s business.
  (was, 2013-11-05, similarity 0.9947):
[0001104659-13-081156:note_history:19]
From time to time the Company is involved in claims and legal proceedings which arise in the ordinary course of its business. The Company is currently subject to several such claims and a small number of legal proceedings. The Company believes that these matters lack merit and intends to vigorously defend against them. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company’s defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company’s business, financial condition, cash flows and results of operations in a particular period. Any claims or proceedings against us, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company’s business.

- removed (2014-01-30):
[0001104659-13-081156:note_history:20]
|  |  | Three Months ended September 30, |  | Six Months ended September 30, |  |
|  |  | 2013 |  | 2012 |  | 2013 |  | 2012 |  |
| Beginning balance |  | $ | 1,532 |  | $ | 2,001 |  | $ | 1,750 |  | $ | 1,918 |  |
| Liabilities incurred |  | — |  | — |  | — |  | — |  |
| Liabilities settled |  | (375 | ) | — |  | (596 | ) | — |  |
| Accretion expense |  | 9 |  | 4 |  | 11 |  | 16 |  |
| Foreign currency translation |  | 12 |  | (135 | ) | 13 |  | (64 | ) |
| Ending balance |  | $ | 1,178 |  | $ | 1,870 |  | $ | 1,178 |  | $ | 1,870 |  |

- removed (2014-01-30):
[0001104659-13-081156:note_history:21]
|  |  | Three Months ended September 30, |  | Six Months ended September 30, |  |
|  |  | 2013 |  | 2012 |  | 2013 |  | 2012 |  |
|  |  |  |  | As Revised |  |  |  | As Revised |  |
| Beginning balance |  | $ | 22,655 |  | $ | 23,966 |  | $ | 20,538 |  | $ | 25,494 |  |
| Provision during the period |  | 3,356 |  | 3,444 |  | 6,645 |  | 5,981 |  |
| Settlements made during the year, net of adjustments |  | (3,926 | ) | (3,873 | ) | (7,425 | ) | (7,938 | ) |
| Amount classified as liabilities held for sale (1) |  | — |  | — |  | 2,327 |  | — |  |
| Ending balance |  | $ | 22,085 |  | $ | 23,537 |  | $ | 22,085 |  | $ | 23,537 |  |

- removed (2014-01-30):
[0001104659-13-081156:note_history:22]
|  |  | Three Months ended September 30, |  | Six Months ended September 30, |  |
|  |  | 2013 |  | 2012 |  | 2013 |  | 2012 |  |
| Beginning balance |  | $ | 29,080 |  | $ | 26,340 |  | $ | 29,328 |  | $ | 24,568 |  |
| Additions for extended warranties issued during the period |  | 7,914 |  | 8,112 |  | 15,830 |  | 16,394 |  |
| Amortization of deferred revenue for the period |  | (7,926 | ) | (7,333 | ) | (16,090 | ) | (13,843 | ) |
| Ending balance |  | $ | 29,068 |  | $ | 27,119 |  | $ | 29,068 |  | $ | 27,119 |  |

- removed (2014-01-30):
[0001104659-13-081156:note_history:23]
Logitech Europe S.A., a subsidiary of the parent holding company, has guaranteed the purchase obligations of another Logitech subsidiary under two guarantee agreements. One of these guarantees does not specify a maximum amount. The remaining guarantee has a total limit of $7.0 million. As of September 30, 2013, there was an immaterial amount of guaranteed purchase obligations that were outstanding under these guarantees. Logitech Europe S.A. has also guaranteed payment of the purchase obligations of a third-party contract manufacturer under one guarantee agreement. The maximum amount of this guarantee was $3.5 million as of September 30, 2013. As of September 30, 2013, $2.8 million of guaranteed purchase obligations were outstanding under this agreement.

- removed (2014-01-30):
[0001104659-13-081156:note_history:24]
Logitech indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. No amounts have been accrued for indemnification provisions at September 30, 2013. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

- removed (2014-01-30):
[0001104659-13-081156:note_history:25]
Logitech also indemnifies its current and former directors and certain of its current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. Logitech is unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not capped, the obligations are conditional in nature, and the facts and circumstances involved in any situation that might arise are variable.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2014-01-30):
[0001104659-14-005272:note_history:26]
The condensed consolidated interim financial statements include the accounts of Logitech and its subsidiaries. All intercompany balances and transactions have been eliminated. The condensed consolidated financial statements are presented in accordance with accounting principles generally accepted in the United States of America (“GAAP”) for interim financial information and therefore do not include all the information required by GAAP for complete financial statements. They should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended March 31, 2013, included in its Annual Report on Form 10-K/A filed with the SEC on August 7, 2013. In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of normal recurring adjustments, necessary for a fair statement of the results for the periods presented. Operating results for the three and nine months ended December 31, 2013 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2014, or any future periods.

- changed (2014-01-30):
[0001104659-14-005272:note_history:27]
The Company’s fiscal years end on March 31. Interim quarters are thirteen-week periods, each ending on a Friday. For purposes of presentation, the Company has indicated its quarterly periods as ending on the calendar month end.
  (was, 2013-11-05, similarity 0.9796):
[0001104659-13-081156:note_history:27]
The Company’s fiscal years end on March 31. Interim quarters are thirteen-week periods, each ending on a Friday.  For purposes of presentation, the Company has indicated its quarterly periods as ending on the month end.

- changed (2014-01-30):
[0001104659-14-005272:note_history:28]
There have been no substantial changes in the Company’s significant accounting policies during the three and nine months ended December 31, 2013, compared with the significant accounting policies described in its Annual Report on Form 10-K/A for the fiscal year ended March 31, 2013 filed with the SEC on August 7, 2013.
  (was, 2013-11-05, similarity 0.8691):
[0001104659-13-081156:note_history:28]
There have been no substantial changes in the Company’s significant accounting policies during the three and six months ended September 30, 2013, compared with the significant accounting policies described in its Annual Report on Form 10-K/A for the fiscal year ended March 31, 2013.

- changed (2014-01-30):
[0001104659-14-005272:note_history:29]
The preparation of financial statements in conformity with GAAP requires management to make judgments, estimates and assumptions that affect reported amounts of assets, liabilities, net sales and expenses and the disclosure of contingent assets and liabilities. Examples of significant estimates and assumptions made by management involve the fair value of goodwill, accruals for customer programs, inventory valuation, valuation allowances for deferred tax assets and warranty accruals. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ from those estimates.
  (was, 2013-11-05, similarity 0.9956):
[0001104659-13-081156:note_history:29]
The preparation of financial statements in conformity with U.S. GAAP requires management to make judgments, estimates and assumptions that affect reported amounts of assets, liabilities, net sales and expenses, and the disclosure of contingent assets and liabilities. Examples of significant estimates and assumptions made by management involve the fair value of goodwill, accruals for customer programs, inventory valuation, valuation allowances for deferred tax assets and warranty accruals. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ from those estimates.

- added (2014-01-30):
[0001104659-14-005272:note_history:30]
In July 2013, the FASB issued Accounting Standards Update (“ASU”) No. 2013-11, Presentation of an Unrecognized Tax Benefit When a Net Operating Loss Carryforward, a Similar Tax Loss, or a Tax Credit Carryforward Exists. This ASU provides explicit guidance on the financial statement presentation of an unrecognized tax benefit when a net operating loss carryforward, a similar tax loss, or a tax credit carryforward exists. ASU No. 2013-11 is effective for interim and annual periods beginning after December 15, 2013. The Company does not expect the adoption of this guidance to have a material impact on its financial statements.

- removed (2014-01-30):
[0001104659-13-081156:note_history:31]
The consolidated interim financial statements include the accounts of Logitech and its subsidiaries. All intercompany balances and transactions have been eliminated. The consolidated financial statements are presented in accordance with U.S. GAAP (accounting principles generally accepted in the United States of America) for interim financial information and therefore do not include all the information required by U.S. GAAP for complete financial statements. They should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended March 31, 2013, included in its Annual Report on Form 10-K/A. In the opinion of management, these consolidated financial statements include all adjustments, consisting of normal recurring adjustments, necessary for a fair statement of the results for the periods presented. Operating results for the three and six months ended September 30, 2013 are not necessarily indicative of the results that may be expected for the year ending March 31, 2014, or any future periods.

- removed (2014-01-30):
[0001104659-13-081156:note_history:32]
In July 2013, the FASB issued ASU No. 2013-11, “Presentation of an Unrecognized Tax Benefit When a Net Operating Loss Carryforward, a Similar Tax Loss, or a Tax Credit Carryforward Exists”. The ASU provides explicit guidance on the financial statement presentation of an unrecognized tax benefit when a net operating loss carryforward, a similar tax loss, or a tax credit carryforward exists. ASU No. 2013-11 is effective for interim and annual periods beginning after December 15, 2013.  The Company does not expect the adoption of this guidance to have a material impact on its consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2014-01-30):
[0001104659-14-005272:note_history:33]
In December 2011, the Company entered into a Senior Revolving Credit Facility Agreement (“Credit Facility”) with a group of primarily Swiss banks that provided for a revolving multicurrency unsecured credit facility in an amount of up to $250.0 million and subject to certain requirements, permitted the Company to arrange with existing or new lenders to provide up to an aggregate of $150.0 million in additional commitments, for a total of $400.0 million. The Company also paid a quarterly commitment fee of 40% of the applicable margin on the available commitment. In December 2013, the Company on its own volition, terminated this Credit Facility and wrote-off $1.0 million of capitalized deferred loan fees. There were no outstanding borrowings at the time of termination.

- added (2014-01-30):
[0001104659-14-005272:note_history:34]
The Company had several uncommitted, unsecured bank lines of credit aggregating $62.0 million at December 31, 2013. There are no financial covenants under these lines of credit with which the Company must comply. As of December 31, 2013, the Company had no outstanding borrowings under these lines of credit. The Company also had credit lines related to corporate credit cards totaling $7.0 million as of December 31, 2013. The outstanding borrowings under these credit lines are recorded in other current liabilities. There are no financial covenants under these credit lines.

- removed (2014-01-30):
[0001104659-13-081156:note_history:35]
In December 2011, the Company entered into a Senior Revolving Credit Facility Agreement with a group of primarily Swiss banks that provides for a revolving multicurrency unsecured credit facility in an amount of up to $250.0 million. The Company may, upon notice to the lenders and subject to certain requirements, arrange with existing or new lenders to provide up to an aggregate of $150.0 million in additional commitments, for a total of $400.0 million of unsecured revolving credit. The credit facility may be used for working capital, general corporate purposes, and acquisitions. There were no outstanding borrowings under the credit facility at September 30, 2013.

- removed (2014-01-30):
[0001104659-13-081156:note_history:36]
The credit facility matures on October 31, 2016. The Company may prepay the loans under the credit facility in whole or in part at any time without premium or penalty. Borrowings under the credit facility will accrue interest at a per annum rate based on LIBOR (London Interbank Offered Rate), or EURIBOR (Euro Interbank Offered Rate) in the case of loans denominated in euros, plus a variable margin determined quarterly based on the ratio of senior debt-to-earnings before interest, taxes, depreciation and amortization for the preceding four-quarter period, plus, if applicable, an additional rate per annum intended to compensate the lenders for the cost of compliance with regulatory reserve requirements and other banking regulations. The Company also pays a quarterly commitment fee of 40% of the applicable margin on the available commitment. In connection with entering into the credit facility, the Company incurred non-recurring fees totaling $1.5 million, which are amortized on a straight-line basis over the term of the credit facility.

- removed (2014-01-30):
[0001104659-13-081156:note_history:37]
The facility agreement contains representations, covenants, including threshold financial covenants, and events of default customary in Swiss credit markets. Affirmative covenants include covenants regarding reporting requirements, maintenance of insurance, maintenance of properties and compliance with applicable laws and regulations, and financial covenants that require the maintenance of net senior debt, interest cover and adjusted equity ratios determined in accordance with the terms of the facility. Negative covenants limit the ability of the Company and its subsidiaries, among other things, to grant liens, make investments, incur debt, make restricted payments, enter into a merger or acquisition, or sell, transfer or dispose of assets, in each case subject to certain exceptions. As of March 31, 2013, the Company was not in compliance with the interest coverage ratio of this credit facility. This situation resulted from the significant operating loss incurred during fiscal year 2013.  On June 13, 2013, the Company amended this credit facility to amend the definitions of (a) EBITDA to exclude the effect of impairment of goodwill and other intangible assets and (b) interest coverage ratio calculation to utilize EBITDA rather than EBIT. As of September 30, 2013, the Company was not in compliance with the adjusted equity ratio of this facility. This facility continues to be available for the Company’s use based on a temporary waiver of the adjusted equity ratio covenant through the end of the third quarter of fiscal year 2014.

- removed (2014-01-30):
[0001104659-13-081156:note_history:38]
This credit facility stipulates that, upon an uncured event of default under the facility, the lenders may declare all or a portion of the outstanding obligations payable by the Company to be immediately due and payable, terminate their commitments and exercise other rights and remedies provided for under the facility. The events of default under the facility include, among other things, payment defaults, covenant defaults, inaccuracy of representations and warranties, cross defaults with certain other indebtedness, bankruptcy and insolvency events and events that have a material adverse effect (as defined in the facility). Upon a change of control of the Company, lenders whose commitments aggregate more than two-thirds of the total commitments under the facility may terminate the commitments and declare all outstanding obligations to be due and payable.

- removed (2014-01-30):
[0001104659-13-081156:note_history:39]
The Company had several uncommitted, unsecured bank lines of credit aggregating $62 million at September 30, 2013. There are no financial covenants under these lines of credit with which the Company must comply. At September 30, 2013, the Company had no outstanding borrowings under these lines of credit. The Company also had credit lines related to corporate credit cards totaling $17.4 million at September 30, 2013. The outstanding borrowings under these credit lines are recorded in other current liabilities. There are no financial covenants under these credit lines.
