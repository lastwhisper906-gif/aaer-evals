# LOGI 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: 2 candidate headings, none whose body matches 'critical audit matter'.


## item_9a

[0001047469-14-009167:item_9a:1]
ITEM 9A.    CONTROLS AND PROCEDURES

[0001047469-14-009167:item_9a:2]
Background

[0001047469-14-009167:item_9a:3]
The Company announced on May 21, 2014, that the Audit Committee, with the assistance of independent advisors, began an
independent investigation of certain accounting matters related to the Company's previously issued financial statements.

[0001047469-14-009167:item_9a:4]
On
September 3, 2014, the Company announced that, in connection with this investigation, the Audit Committee, on the recommendation of management, concluded that the Company's
previously issued financial statements for fiscal years 2011 and 2012 and the first quarter of fiscal year 2012 could no longer be relied on, due to an accounting misstatement for inventory valuation
reserves for Logitech's now-discontinued Revue product. As a result, we have restated our consolidated financial statements for those periods.

[0001047469-14-009167:item_9a:5]
We
also evaluated the findings identified by this investigation and concluded that material weaknesses existed as of March 31, 2014 related to the control environment, including
an insufficient complement of personnel, and information and communication, that also contributed to the other material weaknesses described in Management's Report on Internal Control over Financial
Reporting.

[0001047469-14-009167:item_9a:6]
In
conjunction with recording the adjustments related to the restatement, we also recorded other immaterial adjustments to the consolidated financial statements included in this
Form 10-K for the fiscal years ended March 31, 2013, 2012, 2011 and 2010.

[0001047469-14-009167:item_9a:7]
Evaluation of Disclosure Controls and Procedures

[0001047469-14-009167:item_9a:8]
As of the end of the period covered by this Annual Report on Form 10-K, Logitech carried out an evaluation, under the
supervision and with the participation of our management, including our Chief Executive Officer and our Principal Financial and Accounting Officer, of the effectiveness of our disclosure controls and
procedures, as defined in Rule 13a-15(e) under the Securities and Exchange Act of 1934, as amended, ("the Exchange Act"). Disclosure controls and procedures are controls and other procedures
designed to reasonably assure that information required to be disclosed in our reports filed or submitted under the Exchange Act, such as this Annual Report on Form 10-K, is recorded,
processed, summarized and reported within the time periods specified in the Securities and Exchange Commission's rules and forms. Disclosure controls and procedures are also designed to reasonably
assure that this information is accumulated and communicated to our management, including the Chief Executive Officer and the Principal Financial and Accounting Officer, to allow timely decisions
regarding required disclosure.

[0001047469-14-009167:item_9a:9]
Based
on that evaluation, Logitech's Chief Executive Officer and Principal Financial and Accounting Officer have concluded that, as of March 31, 2014, our disclosure controls and
procedures were not effective as a result of the material weaknesses that existed in our internal control over financial reporting as described in Management's Report on Internal Control over
Financial Reporting below.

[0001047469-14-009167:item_9a:10]
Notwithstanding
the material weaknesses discussed below, our Chief Executive Officer and Principal Financial and Accounting Officer have concluded that the consolidated financial
statements included in this report fairly present, in all material respects, our financial condition, results of operations and cash flows for the periods presented in conformity with accounting
principles generally accepted in the United States.

[0001047469-14-009167:item_9a:11]
Management's Report on Internal Control over Financial Reporting

[0001047469-14-009167:item_9a:12]
Our management is responsible for establishing and maintaining adequate internal control over financial reporting as such term is
defined in Rule 13a-15(f) of the Exchange Act. Our management assessed, with the oversight of the Board of Directors, the effectiveness of our internal control over financial reporting as of
March 31, 2014. In making this assessment, management
used the criteria established in Internal Control—Integrated Framework (1992) issued by the Committee of Sponsoring Organizations of the
Treadway Commission ("COSO"). Based on this assessment, management has concluded the Company's internal control over financial reporting was not effective as of March 31, 2014 due to the
material weaknesses described below. A material weakness is a deficiency, or combination of deficiencies, in internal control over financial reporting, such that there is a reasonable possibility that
a

[0001047469-14-009167:item_9a:13]
material
misstatement of the annual or interim financial statements will not be prevented or detected on a timely basis.

[0001047469-14-009167:item_9a:14]
Management
determined that the following material weaknesses existed as of March 31, 2014:

[0001047469-14-009167:item_9a:15]
We
did not maintain an effective control environment as former finance management exercised bad judgment and failed to provide effective oversight, which
resulted in ineffective information and communication, whereby certain of the Company's finance personnel did not adequately document and communicate accounting issues across the organization,
including to our independent registered public accounting firm. Additionally, there was an insufficient complement of personnel with appropriate accounting knowledge, experience and competence,
resulting in incorrect conclusions in the application of generally accepted accounting principles.

[0001047469-14-009167:item_9a:16]
The
above material weaknesses contributed to the following material weaknesses:

[0001047469-14-009167:item_9a:17]
The
Company did not design and maintain effective controls related to developing an appropriate methodology to accrue the costs of product warranties given to end customers, including an on-going
review of the assumptions within the methodology to determine the completeness and accuracy of the warranty accrual. While this material weakness did not result in any material misstatement of our
historical financial statements, it did result in adjustments to our cost of goods sold and warranty accrual accounts in the first quarter of fiscal 2014 and revisions to the Company's consolidated
financial statements for fiscal 2013, 2012 and 2011, and interim periods in fiscal 2013 and 2012. Such revisions were disclosed in the Company's Form 10-K/A filed on August 7, 2013;

[0001047469-14-009167:item_9a:18]
The
Company did not design and maintain effective controls to consider all relevant information and document the underlying assumptions in our assessment of the valuation of finished goods, work in
process and components inventory, including non-cancelable orders for such inventory, related to our
now discontinued Revue product. This material weakness resulted in an incorrect application of generally accepted accounting principles that resulted in a material misstatement of inventory, cost of
goods sold and supplier liability accrual accounts and a restatement of the Company's consolidated financial statements for fiscal 2012 and 2011 and the first quarter of fiscal 2012;

[0001047469-14-009167:item_9a:19]
The
Company did not design and maintain effective controls over the review of supporting information to determine the completeness and accuracy of the consolidated statement of cash flows, the
consolidated statement of comprehensive income (loss) and disclosures in the notes to the consolidated financial statements. While this material weakness did not result in any material misstatement of
our historical financial statements, it did result in audit adjustments to the consolidated statement of cash flows, the consolidated statement of comprehensive income (loss) and disclosures in the
notes to the Company's fiscal 2013 consolidated financial statements and similar revisions to our interim consolidated financial statements for the first three interim periods in fiscal 2013, as
applicable to the interim consolidated financial statements.

[0001047469-14-009167:item_9a:20]
Additionally,
these material weaknesses could result in further misstatements of the account balances or disclosures that would result in a material misstatement to the annual or interim
consolidated financial statements that would not be prevented or detected.

[0001047469-14-009167:item_9a:21]
The
effectiveness of the Company's internal control over financial reporting as of March 31, 2014 has been audited by PricewaterhouseCoopers LLP, an independent registered
public accounting firm, as stated in their report, which appears in Item 15.

[0001047469-14-009167:item_9a:22]
Management's Plan to Remediate the Material Weaknesses:

[0001047469-14-009167:item_9a:23]
In September 2013, the Company hired a new Principal Financial and Accounting Officer who has implemented and continues to implement
changes in our internal control over financial reporting to address these material weaknesses, including those identified in our recently completed independent

[0001047469-14-009167:item_9a:24]
investigation.
Our Board of Directors has full confidence in its current management under the leadership of the Chief Executive Officer and Principal Financial and Accounting Officer and we take the
integrity of our financial statements seriously. We continue to evaluate the effectiveness of our remediation efforts, including demonstrating that the new or improved controls operate effectively for
a
reasonable period of time and will continue to make additional changes, if appropriate. If not remediated, these material weaknesses could result in further material misstatements to our financial
statements. The following changes to our internal control over financial reporting have been implemented or will be implemented as soon as
practicable:

[0001047469-14-009167:item_9a:25]
•

[0001047469-14-009167:item_9a:26]
Provide training in order to enhance the level of communication and understanding of internal controls with key
individuals that provide critical information used in financial accounting and reporting on matters relating to business and operations, which impact financial reporting;

[0001047469-14-009167:item_9a:27]
•

[0001047469-14-009167:item_9a:28]
Identify skills gaps within the global finance and accounting organization and recruit resources with appropriate
experience and technical expertise to fill gaps, including in the area of SEC reporting and technical accounting.

[0001047469-14-009167:item_9a:29]
•

[0001047469-14-009167:item_9a:30]
Implement a more comprehensive process for review of the financial statements;

[0001047469-14-009167:item_9a:31]
•

[0001047469-14-009167:item_9a:32]
Implement a policy requiring formal documentation of the conclusions and basis for conclusions for all significant
accounting positions and financial reporting issues, by finance and accounting personnel with sufficient technical competence, including review and approval by the appropriate level of management;

[0001047469-14-009167:item_9a:33]
•

[0001047469-14-009167:item_9a:34]
Implement a revised and documented methodology and related internal controls over the accrual of warranty costs,
including an on-going review of the assumptions within the methodology, the capture of all relevant costs, relating to product warranties given to end customers and appropriate review of the accrual
each quarter;

[0001047469-14-009167:item_9a:35]
•

[0001047469-14-009167:item_9a:36]
Clarify existing policy and enhance procedures over inventory valuation, including lower of cost or market (LCM) and
excess and obsolete reserve calculations, determining that all relevant information is considered, including future demand forecasts, and that conclusions reached are subject to a comprehensive review
as well as ongoing evaluation;

[0001047469-14-009167:item_9a:37]
•

[0001047469-14-009167:item_9a:38]
Implement new controls and improve existing controls over financial reporting, including controls with respect to
disclosures in the notes to the consolidated financial statements, and the preparation, review, and approval of the consolidated statement of cash flows and consolidated statement of comprehensive
income (loss).

[0001047469-14-009167:item_9a:39]
Status as of March 31, 2014

[0001047469-14-009167:item_9a:40]
During the period ended March 31, 2014, we implemented the following changes to our internal control over financial
reporting:

[0001047469-14-009167:item_9a:41]
•

[0001047469-14-009167:item_9a:42]
Established a Finance and Accounting leadership team, including a new Principal Financial and Accounting Officer, a new
Vice President of Internal Audit, a new Assistant Corporate Controller (the latter two who joined in the fourth quarter of fiscal year 2014) subsequently promoted to Corporate Controller, and a new
Senior Director of Finance Operations, to strengthen oversight of the team and improve the design, implementation, execution and supervision of internal controls within the organization. Hired
experienced additional technical resources in the area of Corporate Controllership Group, SEC Reporting, Financial Planning and Analysis, Operations Finance, and Regional Controllership Group;

[0001047469-14-009167:item_9a:43]
•

[0001047469-14-009167:item_9a:44]
Leveraged the services of consulting firms, until we could hire resources with the required skills to strengthen our
internal controls, documentation and communication in the SEC reporting process.

[0001047469-14-009167:item_9a:45]
•

[0001047469-14-009167:item_9a:46]
Hired subject matter experts in the area of Operations Finance to design and oversee improved information and
communication processes and other internal controls relating to warranty accruals and inventory valuation reserves;

[0001047469-14-009167:item_9a:47]
•

[0001047469-14-009167:item_9a:48]
Implemented a new methodology for identifying and accruing costs relating to product warranty, including documenting and
evaluating the assumptions used and determining appropriate supervision and review each quarter;

[0001047469-14-009167:item_9a:49]
•

[0001047469-14-009167:item_9a:50]
Starting in the fourth quarter of fiscal year 2014, implemented a process to enhance the nature and extent of review of
Forms 10-Q and 10-K by a team lead by the new Assistant Controller, a more robust process for disclosure committee meetings, and a final review of these filings with the Principal Financial and
Accounting Officer. The Principal Financial and Accounting Officer and the Assistant Controller in turn report the results of this process to the Financial Close, Disclosure and Audit Committees in
formal quarterly meetings;

[0001047469-14-009167:item_9a:51]
•

[0001047469-14-009167:item_9a:52]
Provided training to key individuals that provide critical information used in financial accounting and reporting to
reinforce pre-established and new controls to improve our ability to detect potential misstatements in our internally prepared reports, analysis and financial records.

[0001047469-14-009167:item_9a:53]
Fiscal 2015 Current Status

[0001047469-14-009167:item_9a:54]
Further to the above measures, during the period April to October 2014, we have taken further measures to strengthen the processes and
controls relating to financial reporting. These measures include:

[0001047469-14-009167:item_9a:55]
•

[0001047469-14-009167:item_9a:56]
Further strengthening the technical capabilities of the global finance and accounting organization by hiring a Director
of External Reporting and Global Accounting, Senior Manager—Revenue, Manager—External Reporting and a Consolidation Accountant;

[0001047469-14-009167:item_9a:57]
•

[0001047469-14-009167:item_9a:58]
Under our new Chief Executive Officer and Principal Financial and Accounting Officer, establishing communications and new
processes and controls that allows frequent open communication with key internal stakeholders, our advisors, and our independent registered public accounting firm, on key business and operational
matters impacting financial reporting;

[0001047469-14-009167:item_9a:59]
•

[0001047469-14-009167:item_9a:60]
Enhancing the Company's representation letter control. The Company had a representation letter control, wherein detailed
questionnaires containing over 60 questions are sent to over 50 senior level employees of the Company. The feedback received is reviewed by the Controllership Group and appropriate actions are
initiated, as a normal process. Effective in the first quarter of fiscal year 2015, the detailed questionnaires and a listing of the responses received and resolution of the issues identified are
reviewed by the Controller, and are being shared with our independent registered public accounting firm in order to further enhance communication; and

[0001047469-14-009167:item_9a:61]
•

[0001047469-14-009167:item_9a:62]
Strengthening our inventory valuation control through increased standardization and consideration of all relevant inputs
including aging, historical sales data, product life cycles and market acceptance.

[0001047469-14-009167:item_9a:63]
Our
management believes the foregoing efforts will effectively remediate the material weaknesses after these controls have operated effectively for a reasonable period of time. As we
continue to evaluate and work to improve our internal control over financial reporting, management may determine to take additional measures to address the material weaknesses or determine to modify
the remediation plan described above.

[0001047469-14-009167:item_9a:64]
Changes in Internal Control over Financial Reporting

[0001047469-14-009167:item_9a:65]
The measures identified as occurring in the fourth quarter of fiscal 2014 above are changes in the Company's internal control over
financial reporting in the three months ended March 31, 2014 that have

[0001047469-14-009167:item_9a:66]
materially
affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0001047469-14-009167:item_9a:67]
Limitations on the Effectiveness of Controls

[0001047469-14-009167:item_9a:68]
The Company's management, including the Chief Executive Officer and Principal Financial and Accounting Officer, does not expect that
the Company's disclosure controls and procedures or internal control over financial reporting will prevent all error and all fraud. Internal control over financial reporting, no matter how well
designed and operated, can provide only reasonable, not absolute, assurance that the objectives will be met. Because of the inherent limitations in internal control over financial reporting, no
evaluation of controls can provide absolute assurance that all control issues and instances of fraud, if any, within the Company have been detected. These inherent limitations include the realities
that judgments in decision making can be faulty and that breakdowns can occur because of simple error or mistake. Controls can also be circumvented by the individual acts of some persons, by collusion
of two or more people, or by management override of the controls. The design of any system of controls is based in part on certain assumptions about the likelihood of future events, and there can be
no assurance that any design will succeed in achieving its stated goals under all potential future conditions. Over time, controls may become inadequate because of changes in conditions or
deterioration in the degree of compliance with policies or procedures. Because of the inherent limitations in a cost-effective control system, misstatements due to error or fraud may occur and not be
detected.
