# LOGI notes — 0001047469-14-009167


## logi:ScheduleOfChangesInAllowanceForDoubtfulAccountsTableTextBlock

[0001047469-14-009167:notes:1]
The following table presents the changes in the allowance for doubtful accounts during the fiscal years ended March 31, 2014, 2013, and 2012 (in thousands):

[0001047469-14-009167:notes:2]
|  |  | Years Ended March 31, |  |
|  |  | 2014 |  | 2013 |  | 2012 |  |
|  |  |  |  | As Revised |  | As Restated |  |
| Beginning of the period |  | $ | 2,153 |  | $ | 2,472 |  | $ | 4,086 |  |
| Expense (reversal), net |  |  | 656 |  |  | (107 | ) |  | (592 | ) |
| Write-offs, net of recoveries |  |  | (1,097 | ) |  | (212 | ) |  | (1,022 | ) |
| End of the period |  | $ | 1,712 |  | $ | 2,153 |  | $ | 2,472 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001047469-14-009167:notes:3]
Note 3—Summary of Significant Accounting Policies

[0001047469-14-009167:notes:4]
Basis of Presentation

[0001047469-14-009167:notes:5]
The consolidated financial statements include the accounts of Logitech and its subsidiaries. All intercompany balances and transactions have been eliminated. The consolidated financial statements are presented in accordance with U.S. GAAP (accounting principles generally accepted in the United States of America).

[0001047469-14-009167:notes:6]
Fiscal Year

[0001047469-14-009167:notes:7]
The Company's fiscal year ends on March 31. Interim quarters are thirteen-week periods, each ending on a Friday. For purposes of presentation, the Company has indicated its quarterly periods as ending on the month end.

[0001047469-14-009167:notes:8]
Use of Estimates

[0001047469-14-009167:notes:9]
The preparation of financial statements in conformity with U.S. GAAP requires management to make judgments, estimates and assumptions that affect reported amounts of assets, liabilities, net sales and expenses, and the disclosure of contingent assets and liabilities. Examples of significant estimates and assumptions made by management involve the fair value of goodwill, warranty liabilities, accruals for discretionary customer programs, sales return reserves, allowance for doubtful accounts, inventory valuation, uncertain tax positions, and valuation allowances for deferred tax assets. Although these estimates are based on management's best knowledge of current events and actions that may impact the Company in the future, actual results could differ from those estimates.

[0001047469-14-009167:notes:10]
Foreign Currencies

[0001047469-14-009167:notes:11]
The functional currency of the Company's operations is primarily the U.S. Dollar. To a lesser extent, certain operations use the Euro, Chinese Renminbi, Swiss Franc, or other local currencies as their functional currencies. The financial statements of the Company's subsidiaries whose functional currency is other than the U.S. Dollar are translated to U.S. Dollars using period-end rates of exchange for assets and liabilities and monthly average rates for net sales, income and expenses. Cumulative translation gains and losses are included as a component of shareholders' equity in accumulated other comprehensive income/(loss). Gains and losses arising from transactions denominated in currencies other than a subsidiary's functional currency are reported in other income (expense), net in the consolidated statements of operations.

[0001047469-14-009167:notes:12]
Revenue Recognition

[0001047469-14-009167:notes:13]
Revenues are recognized when all of the following criteria are met:

[0001047469-14-009167:notes:14]
•

[0001047469-14-009167:notes:15]
evidence of an arrangement between the Company and the customer exists;

[0001047469-14-009167:notes:16]
delivery has occurred and title and risk of loss has transferred to the customer;

[0001047469-14-009167:notes:17]
the price of the product is fixed or determinable; and

[0001047469-14-009167:notes:18]
collectability of the receivable is reasonably assured.

[0001047469-14-009167:notes:19]
For sales of most hardware peripherals products and hardware bundled with software incidental to its functionality, these criteria are met at the time delivery has occurred and title and risk of loss have transferred to the customer.

[0001047469-14-009167:notes:20]
The Company's video conferencing segment has multiple-deliverable revenue arrangements that include both undelivered software elements and hardware with software essential to its functionality. The Company uses the following hierarchy to determine the relative selling price for allocating revenue to the deliverables: (i) VSOE (vendor specific objective evidence) of fair value, if available; (ii) TPE (third party evidence), if VSOE is not available; or (iii) ESP (best estimate of selling price), if neither VSOE nor TPE are available. Management judgment must be used to determine the appropriate deliverables and associated relative selling prices. The Company has identified Logitech Revue, discontinued in fiscal year 2013, and the Lifesize video conferencing products as products sold with software components that qualify as multiple-deliverable revenue arrangements.

[0001047469-14-009167:notes:21]
Lifesize products include the following deliverables:

[0001047469-14-009167:notes:22]
Non-software deliverables

[0001047469-14-009167:notes:23]
Hardware with software essential to the functionality of the hardware device delivered at time of sale

[0001047469-14-009167:notes:24]
Maintenance for hardware with essential software, including future when-and-if-available unspecified upgrades

[0001047469-14-009167:notes:25]
Other services, including training and installation

[0001047469-14-009167:notes:26]
Software deliverables

[0001047469-14-009167:notes:27]
Non-essential software

[0001047469-14-009167:notes:28]
Maintenance for non-essential software, including future when-and-if available unspecified upgrades

[0001047469-14-009167:notes:29]
The relative selling price for Lifesize hardware with essential software and non-essential software is based on ESP, as VSOE and TPE cannot be established due to variable price discounting. Key factors considered in developing ESP are historical selling prices of the product, pricing of substantially similar products, and other market conditions. Lifesize sells maintenance for non-essential software, maintenance for hardware with essential software, and other services on a standalone basis, and therefore has established VSOE for those deliverables.

[0001047469-14-009167:notes:30]
The consideration received for multiple element arrangements consisting of both non-software and software deliverables is allocated based on relative selling prices to the non-software deliverables and the software deliverables as a group. Amounts allocated to non-software-related elements, such as delivered hardware with essential software, are recognized at the time of sale provided that the other conditions for revenue recognition have been met. Amounts allocated to maintenance services for hardware and essential software are deferred and recognized ratably over the maintenance period. Amounts allocated to other services are deferred and recognized upon completion of services. Amounts allocated to software deliverables such as non-essential software and related services are further allocated to the individual deliverables within the software group. The VSOE of non-essential software-related maintenance are deferred and recognized ratably over the maintenance period. The residual value of the amounts allocated to software- related elements is recognized at the time of sale.

[0001047469-14-009167:notes:31]
Revenues from sales to distributors and authorized resellers are recognized upon shipment net of estimated product returns and expected payments for cooperative marketing arrangements, customer incentive programs and pricing programs. The estimated cost of these programs is recorded as a reduction of sales or as an operating expense, if the Company receives a separately identifiable benefit from the customer and can reasonably estimate the fair value of that benefit. Significant management judgment and estimates must be used to determine the cost of these programs in any accounting period.

[0001047469-14-009167:notes:32]
The Company grants limited rights to return product. Return rights vary by customer, and range from just the right to return defective product to stock rotation rights limited to a percentage approved by management. Estimates of expected future product returns are recognized at the time of sale based on analyses of historical return trends by customer and by product, inventories owned by and located at distributors and retailers, current customer demand, current operating conditions, and other relevant customer and product information. Upon recognition the Company reduces sales and cost of sales for the estimated return. Return trends are influenced by product life cycle status, new product introductions, market acceptance of products, sales levels, product sell-through, the type of customer, seasonality, product quality issues, competitive pressures, operational policies and procedures, and other factors. Return rates can fluctuate over time, but are sufficiently predictable to allow the Company to estimate expected future product returns.

[0001047469-14-009167:notes:33]
The Company enters into cooperative marketing arrangements with many of its distribution and retail customers, and with certain indirect partners, allowing customers to receive a credit equal to a set percentage of their purchases of the Company's products, or a fixed dollar credit for various marketing programs. The objective of these arrangements is to encourage advertising and promotional events to increase sales of the Company's products. Accruals for these marketing arrangements are recorded at the later of time of sale or time of commitment, based on negotiated terms, historical experience and inventory levels in the channel.

[0001047469-14-009167:notes:34]
Customer incentive programs include performance-based incentives and consumer rebates. The Company offers performance-based incentives to its distribution customers, retail customers and indirect partners based on pre-determined performance criteria. Accruals for performance-based incentives are recognized as a reduction of the sale price at the time of sale. Estimates of required accruals are determined based on negotiated terms, consideration of historical experience, anticipated volume of future purchases, and inventory levels in the channel. Consumer rebates are offered from time to time at the Company's discretion for the primary benefit of end-users. Accruals for the estimated costs of consumer rebates and similar incentives are recorded at the later of time of sale or when the incentive is offered, based on the specific terms and conditions. Certain incentive programs, including consumer rebates, require management to estimate the number of customers who will actually redeem the incentive based on historical experience and the specific terms and conditions of particular programs.

[0001047469-14-009167:notes:35]
The Company has agreements with certain of its customers that contain terms allowing price protection credits to be issued in the event of a subsequent price reduction. At management's discretion, the Company also offers special pricing discounts to certain customers. Special pricing discounts are usually offered only for limited time periods or for sales of selected products to specific indirect partners. Management's decision to make price reductions is influenced by product life cycle stage, market acceptance of products, the competitive environment, new product introductions and other factors. Accruals for estimated expected future pricing actions are recognized at the time of sale based on analyses of historical pricing actions by customer and by products, inventories owned by and located at distributors and retailers, current customer demand, current operating conditions, and other relevant customer and product information, such as stage of product life-cycle.

[0001047469-14-009167:notes:36]
The Company regularly evaluates the adequacy of its estimates for product returns, cooperative marketing arrangements, customer incentive programs and pricing programs. Future market conditions and product transitions may require the Company to take action to change such programs. In addition, when the variables used to estimate these costs change, or if actual costs differ significantly from the estimates, the Company would be required to record incremental increases or reductions to sales, cost of goods sold or increase operating expenses. If, at any future time, the Company becomes unable to reasonably estimate these costs, recognition of revenue might be deferred until products are sold to users, which would adversely impact sales in the period of transition.

[0001047469-14-009167:notes:37]
The Company's shipping and handling costs are included in cost of sales in the consolidated statements of operations for all periods presented.

[0001047469-14-009167:notes:38]
Research and Development Costs

[0001047469-14-009167:notes:39]
Costs related to research, design and development of products, which consist primarily of personnel, product design and infrastructure expenses, are charged to research and development expense as they are incurred.

[0001047469-14-009167:notes:40]
Advertising Costs

[0001047469-14-009167:notes:41]
Advertising costs are expensed as incurred. Advertising costs are recorded as either a marketing and selling expense or a deduction from revenue. Advertising costs reimbursed by the Company to direct or indirect customers must have an identifiable benefit and an estimable fair value in order to be classified as an operating expense. If these criteria are not met, the cost is classified as a reduction of revenue. Advertising costs during fiscal years 2014, 2013 and 2012 were $161.2 million, $165.8 million and $168.0 million, respectively.

[0001047469-14-009167:notes:42]
Cash Equivalents

[0001047469-14-009167:notes:43]
The Company considers all highly liquid instruments purchased with an original maturity of three months or less to be cash equivalents.

[0001047469-14-009167:notes:44]
Concentration of Credit Risk

[0001047469-14-009167:notes:45]
Financial instruments that potentially subject the Company to concentrations of credit risk consist principally of cash and cash equivalents and accounts receivable. The Company maintains cash and cash equivalents with various financial institutions to limit exposure with any one financial institution, but is exposed to credit risk in the event of default by financial institutions to the extent that cash balances with individual financial institutions are in excess of amounts that are insured.

[0001047469-14-009167:notes:46]
The Company sells to large OEMs, distributors and retailers and, as a result, maintains individually significant receivable balances with such customers. In fiscal years 2014, 2013 and 2012, one customer in the peripherals operating segment represented 14%, 11% and 14% of net sales, respectively. No other customer represented more than 10% of the Company's total net sales during fiscal years 2014, 2013 and 2012. As of both March 31, 2014 and 2013, one customer represented 14% of total accounts receivable. No other customer represented more than 10% of the Company's total accounts receivable at either March 31, 2014 or 2013. Typical payment terms require customers to pay for product sales generally within 30 to 60 days; however terms may vary by customer type, by country and by selling season. Extended payment terms are sometimes offered to a limited number of customers during the second and third fiscal quarters. The Company does not modify payment terms on existing receivables.

[0001047469-14-009167:notes:47]
The Company's OEM customers tend to be well-capitalized multi-national companies, while distributors and key retailers may be less well-capitalized. The Company manages its accounts receivable credit risk through ongoing credit evaluation of its customers' financial condition. The Company generally does not require collateral from its customers.

[0001047469-14-009167:notes:48]
Allowances for Doubtful Accounts

[0001047469-14-009167:notes:49]
Allowances for doubtful accounts are maintained for estimated losses resulting from the inability of the Company's customers to make required payments. The allowances are based on the Company's regular assessment of the credit worthiness and financial condition of specific customers, as well as its historical experience with bad debts and customer deductions, receivables aging, current economic trends, geographic or country-specific risks and the financial condition of its distribution channels.

[0001047469-14-009167:notes:50]
Inventories

[0001047469-14-009167:notes:51]
Inventories are stated at the lower of cost or market. Costs are computed under the standard cost method, which approximates actual costs determined on the first-in, first-out basis. The Company records write-downs of inventories which are obsolete or in excess of anticipated demand or market value based on a consideration of marketability and product life cycle stage, product development plans, component cost trends, demand forecasts, historical net sales, and assumptions about future demand and market conditions.

[0001047469-14-009167:notes:52]
Investments

[0001047469-14-009167:notes:53]
The Company's investment securities portfolio consists of bank time deposits and marketable securities related to a deferred compensation plan.

[0001047469-14-009167:notes:54]
The bank time deposits are classified as cash equivalents and are recorded at cost, which approximates fair value.

[0001047469-14-009167:notes:55]
The marketable securities related to the deferred compensation plan are classified as non-current trading investments, as they are intended to fund the deferred compensation plan long-term liability. Trading activity is directed by plan participants and is not intended to create short-term gains for the benefit of the Company. These securities are recorded at fair value based on quoted market prices. Earnings, gains and losses on trading investments are included in other income (expense), net.

[0001047469-14-009167:notes:56]
Property, Plant and Equipment

[0001047469-14-009167:notes:57]
Property, plant and equipment are stated at cost. Additions and improvements are capitalized, and maintenance and repairs are expensed as incurred. The Company capitalizes the cost of software developed for internal use in connection with major projects. Costs incurred during the feasibility stage are expensed, whereas direct costs incurred during the application development stage are capitalized.

[0001047469-14-009167:notes:58]
Depreciation is provided using the straight-line method. Plant and buildings are depreciated over estimated useful lives from ten to twenty-five years, equipment over useful lives from three to five years, internal-use software development over useful lives of three to seven years and leasehold improvements over the lesser of the useful life of the improvement, up to ten years, or the term of the lease.

[0001047469-14-009167:notes:59]
When property and equipment is retired or otherwise disposed of, the cost and accumulated depreciation are relieved from the accounts and the net gain or loss is included in the determination of other income (expense), net.

[0001047469-14-009167:notes:60]
Valuation of Long-Lived Assets

[0001047469-14-009167:notes:61]
The Company reviews long-lived assets, such as property and equipment, and finite-lived intangible assets, for impairment whenever events indicate that the carrying amounts might not be recoverable. Recoverability of property and equipment, and other finite-lived intangible assets is measured by comparing the projected undiscounted net cash flows associated with those assets to their carrying values. If an asset is considered impaired, it is written down to fair value, which is determined based on the asset's projected discounted cash flows or appraised value, depending on the nature of the asset. For purposes of recognition of an impairment for assets held for use, the Company groups assets and liabilities at the lowest level for which cash flows are separately identifiable.

[0001047469-14-009167:notes:62]
Goodwill and Other Intangible Assets

[0001047469-14-009167:notes:63]
The Company's intangible assets principally include goodwill, acquired technology, trademarks, customer contracts, and customer relationships. Other intangible assets with finite lives, which include acquired technology, trademarks, customer contracts and customer relationships, and other are recorded at cost and amortized using the straight-line method over their useful lives ranging from one year to ten years. Intangible assets with indefinite lives, which include goodwill, are recorded at cost and evaluated at least annually for impairment.

[0001047469-14-009167:notes:64]
In accordance with ASC Topic 350-10 ("ASC 350-10") as it relates to Goodwill and Other Intangible Assets, the Company conducts its annual goodwill impairment analysis as of December 31 each year and as necessary if changes in facts and circumstances indicate that it is more likely than not that the fair value of its reporting units may be less than its carrying amount. Events or changes in facts and circumstances that might indicate potential impairment of goodwill include company-specific factors, including, but not limited to, stock price volatility, market capitalization relative to net book value, and projected revenue, market growth and operating results. Determining the number of reporting units and the fair value of a reporting unit requires the Company to make judgments and involves the use of significant estimates and assumptions. The Company has two reporting units: peripherals and video conferencing. The allocation of assets and liabilities to each of the reporting units also involves judgment and assumptions.

[0001047469-14-009167:notes:65]
FASB ASC 350-20 permits the Company to make a qualitative assessment of whether it is more likely than not that a reporting unit's fair value is less than its carrying amount before applying the two-step goodwill impairment test. If an entity concludes that it is not more likely than not that the fair value of a reporting unit is less than its carrying amount, it would not be required to perform the two-step impairment test for that reporting unit. The Company may elect to proceed directly to Step 1 without performing a qualitative assessment.

[0001047469-14-009167:notes:66]
Step 1 of the two-step impairment test involves measuring the recoverability of goodwill at the reporting unit level by comparing the reporting unit's carrying amount, including goodwill, to the estimated fair value of the reporting unit. The fair value is estimated using an income approach employing a discounted cash flow ("DCF") and a market-based model. The DCF model is based on projected cash flows from the Company's most recent forecast ("assessment forecast") developed in connection with each of its reporting units to perform the goodwill impairment assessment. The assessment forecast is based on a number of key assumptions, including, but not limited to, discount rate, compound annual growth rate ("CAGR") during the forecast period, and terminal value. The terminal value is based on an exit price at the end of the assessment forecast using an earnings multiple applied to the final year of the assessment forecast. The discount rate is applied to the projected cash flows to reflect the risks inherent in the timing and amount of the projected cash flows, including the terminal value, and is derived from the weighted average cost of capital of market participants in similar businesses. The market approach model is based on applying certain revenue and earnings multiples of comparable companies relevant to each of the Company's reporting units to the respective revenue and earnings metrics of its reporting units. To test the reasonableness of the fair values indicated by the income approach and the market-based approach, the Company also assess the implied premium of the aggregate fair value over the market capitalization considered attributable to an acquisition control premium, which is the price in excess of a stock market's price that investors would typically pay to gain control of an entity. The DCF model and the market approach require the exercise of significant judgment, including assumptions about appropriate discount rates, long-term growth rates for purposes of determining a terminal value at the end of the discrete forecast period, economic expectations, timing of expected future cash flows, and expectations of returns on equity that will be achieved. Such assumptions are subject to change as a result of changing economic and competitive conditions. If the carrying amount of the reporting unit exceeds its fair value as determined by these assessments, goodwill is considered impaired, and Step 2 of the analysis is performed to measure the amount of impairment loss. Step 2 measures the impairment loss by allocating the reporting unit's fair value to its assets and liabilities other than goodwill, comparing the resulting implied fair value of goodwill with its carrying amount, and recording an impairment charge for the difference.

[0001047469-14-009167:notes:67]
Income Taxes

[0001047469-14-009167:notes:68]
The Company provides for income taxes using the asset and liability method, which requires that deferred tax assets and liabilities be recognized for the expected future tax consequences of temporary differences resulting from differing treatment of items for tax and accounting purposes. In estimating future tax consequences, expected future events are taken into consideration, with the exception of potential tax law or tax rate changes.

[0001047469-14-009167:notes:69]
The Company's assessment of uncertain tax positions requires that management make estimates and judgments about the application of tax law, the expected resolution of uncertain tax positions and other matters. In the event that uncertain tax positions are resolved for amounts different than the Company's estimates, or the related statutes of limitations expire without the assessment of additional income taxes, the Company will be required to adjust the amounts of the related assets and liabilities in the period in which such events occur. Such adjustments may have a material impact on the Company's income tax provision and its results of operations.

[0001047469-14-009167:notes:70]
Fair Value of Financial Instruments

[0001047469-14-009167:notes:71]
The carrying value of certain of the Company's financial instruments, including cash equivalents, accounts receivable and accounts payable approximates fair value due to their short maturities. The Company's trading investments related to the deferred compensation plan are reported at fair value based on quoted market prices.

[0001047469-14-009167:notes:72]
Net Income (Loss) per Share

[0001047469-14-009167:notes:73]
Basic net income (loss) per share is computed by dividing net income (loss) by the weighted average outstanding shares. Diluted net income (loss) per share is computed using the weighted average outstanding shares and dilutive share equivalents. Dilutive share equivalents consist of share-based compensation awards, including stock options, employee share purchase plan, and restricted stock.

[0001047469-14-009167:notes:74]
The dilutive effect of in-the-money share-based compensation awards is calculated based on the average share price for each fiscal period using the treasury stock method, which assumes that the amount used to repurchase shares includes the amount the employee must pay for exercising share-based awards, the amount of compensation cost not yet recognized for future service, and the amount of tax impact that would be recorded in additional paid-in capital when the award becomes deductible.

[0001047469-14-009167:notes:75]
Share-Based Compensation Expense

[0001047469-14-009167:notes:76]
Share-based compensation expense includes compensation expense, reduced for estimated forfeitures, for share-based compensation awards granted based on the grant-date fair value. The grant date fair value for stock options and stock purchase rights is estimated using the Black-Scholes-Merton option-pricing valuation model. The grant date fair value of RSUs ("restricted stock units") which vest upon meeting certain market conditions is estimated using the Monte-Carlo simulation method. The grant date fair value of time-based RSUs is calculated based on the market price on the date of grant.

[0001047469-14-009167:notes:77]
Excess tax benefits resulting from the exercise of stock options are classified as cash flows from financing activities in the consolidated statements of cash flows. Excess tax benefits are realized tax benefits from tax deductions for exercised options in excess of the deferred tax asset attributable to share-based compensation costs for such options.

[0001047469-14-009167:notes:78]
The Company will recognize a benefit from share-based compensation in paid-in capital only if an incremental tax benefit is realized after all other available tax attributes have been utilized. For income tax footnote disclosure, the Company has elected to offset deferred tax assets from share-based compensation against the valuation allowance related to the net operating loss and tax credit carryforwards from accumulated tax benefits. The Company will recognize these tax benefits in paid-in capital when the deduction reduces cash taxes payable. In addition, the Company has elected to account for the direct benefits of share-based compensation on the research tax credit through continuing operations.

[0001047469-14-009167:notes:79]
Product Warranty Accrual

[0001047469-14-009167:notes:80]
The Company estimates cost of product warranties at the time the related revenue is recognized based on historical and projected warranty claim rates, historical and projected costs, and knowledge of specific product failures that are outside of the Company's typical experience. Each quarter, the Company reevaluates estimates to assess the adequacy of recorded warranty liabilities considering the size of the installed base of products subject to warranty protection and adjusts the amounts as necessary. If actual product failure rates or repair costs differ from estimates, revisions to the estimated warranty liabilities would be required and could materially affect the Company's results of operations.

[0001047469-14-009167:notes:81]
Comprehensive Income (Loss)

[0001047469-14-009167:notes:82]
Comprehensive income (loss) is defined as the total change in shareholders' equity during the period other than from transactions with shareholders. Comprehensive income (loss) consists of net income (loss) and other comprehensive income (loss). Other comprehensive income (loss) is comprised of foreign currency translation adjustments from those entities not using the U.S. Dollar as their functional currency, unrealized gains and losses on marketable equity securities, net deferred gains and losses and prior service costs for defined benefit pension plans, and net deferred gains and losses on hedging activity.

[0001047469-14-009167:notes:83]
Treasury Shares

[0001047469-14-009167:notes:84]
The Company periodically repurchases shares in the market at fair value. Treasury shares repurchased are recorded at cost as a reduction of total shareholders' equity. Treasury shares held may be reissued to satisfy the exercise of employee stock options and purchase rights, the vesting of restricted stock units, and acquisitions, or may be cancelled with shareholder approval. Treasury shares that are reissued are accounted for using the first-in, first-out basis.

[0001047469-14-009167:notes:85]
Derivative Financial Instruments

[0001047469-14-009167:notes:86]
The Company enters into foreign exchange forward contracts to reduce the short-term effects of foreign currency fluctuations on certain foreign currency receivables or payables and to hedge against exposure to changes in foreign currency exchange rates related to its subsidiaries' forecasted inventory purchases. These forward contracts generally mature within one to three months. The Company may also enter into foreign exchange swap contracts to extend the terms of its foreign exchange forward contracts.

[0001047469-14-009167:notes:87]
Gains and losses for changes in the fair value of the effective portion of the Company's forward contracts related to forecasted inventory purchases are deferred as a component of accumulated other comprehensive income (loss) until the hedged inventory purchases are sold, at which time the gains or losses are reclassified to cost of goods sold. Gains or losses for changes in the fair value on forward contracts that offset translation losses or gains on foreign currency receivables or payables are recognized are included in other income (expense), net.

[0001047469-14-009167:notes:88]
Restructuring Charges

[0001047469-14-009167:notes:89]
The Company's restructuring charges consist of employee severance, one-time termination benefits and ongoing benefits related to the reduction of its workforce, lease exit costs, and other costs. Liabilities for costs associated with a restructuring activity are measured at fair value and are recognized when the liability is incurred, as opposed to when management commits to a restructuring plan. One-time termination benefits are expensed at the date the entity notifies the employee, unless the employee must provide future service, in which case the benefits are expensed ratably over the future service period. Ongoing benefits are expensed when restructuring activities are probable and the benefit amounts are estimable. Costs to terminate a lease before the end of its term are recognized when the property is vacated. Other costs primarily consist of legal, consulting, and other costs related to employee terminations and are expensed when incurred. Termination benefits are calculated based on regional benefit practices and local statutory requirements.

[0001047469-14-009167:notes:90]
Recent Accounting Pronouncements

[0001047469-14-009167:notes:91]
In July 2013, the FASB issued Accounting Standards Update ("ASU") No. 2013-11, Presentation of an Unrecognized Tax Benefit When a Net Operating Loss Carryforward, a Similar Tax Loss, or a Tax Credit Carryforward Exists . This ASU provides explicit guidance on the financial statement presentation of an unrecognized tax benefit when a net operating loss carryforward, a similar tax loss, or a tax credit carryforward exists. ASU No. 2013-11 is effective for interim and annual periods beginning after December 15, 2013 and was effective for the Company in the first quarter of fiscal 2015.

[0001047469-14-009167:notes:92]
In May 2014, the FASB issued Accounting Standards Update No. 2014-09, "Revenue from Contracts with Customers (Topic 606)," ("ASU 2014-09"). ASU 2014-09 outlines a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. This new revenue recognition model provides a five-step analysis in determining when and how revenue is recognized. The new model will require revenue recognition to depict the transfer of promised goods or services to customers in an amount that reflects the consideration a company expects to receive in exchange for those goods or services. The new standard will be effective for the Company beginning April 1, 2017. Early application is prohibited. The Company is currently evaluating the impact that adopting this new accounting guidance will have on its consolidated financial statements.


## us-gaap:EarningsPerShareTextBlock

[0001047469-14-009167:notes:93]
Note 4—Net Income (Loss) per Share

[0001047469-14-009167:notes:94]
The computations of basic and diluted net income (loss) per share for the Company were as follows (in thousands except per share amounts):

[0001047469-14-009167:notes:95]
|  |  | Years Ended March 31, |  |
|  |  | 2014 |  | 2013 |  | 2012 |  |
|  |  |  |  | As Revised |  | As Restated |  |
| Net income (loss) |  | $ | 74,304 |  | $ | (227,518 | ) | $ | 104,237 |  |
| Shares used in net income (loss) per share computation: |  |  |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding—basic |  |  | 160,619 |  |  | 158,468 |  |  | 174,648 |  |
| Effect of potentially dilutive equivalent shares |  |  | 1,907 |  |  | — |  |  | 943 |  |
| Weighted average shares outstanding—diluted |  |  | 162,526 |  |  | 158,468 |  |  | 175,591 |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.46 |  | $ | (1.44 | ) | $ | 0.60 |  |
| Diluted |  | $ | 0.46 |  | $ | (1.44 | ) | $ | 0.59 |  |

[0001047469-14-009167:notes:96]
During fiscal years 2014, 2013 and 2012, 15,091,478, 22,859,941, and 18,431,855 share equivalents attributable to outstanding stock options, RSUs, and ESPP were excluded from the calculation of diluted net income (loss) per share because the combined exercise price, average unamortized fair value and assumed tax benefits upon exercise of these options, RSUs, and ESPP were greater than the average market price of the Company's shares, and therefore their inclusion would have been anti-dilutive.


## us-gaap:ScheduleOfIncomeBeforeIncomeTaxDomesticAndForeignTableTextBlock

[0001047469-14-009167:notes:97]
Income (loss) before income taxes for the fiscal years 2014, 2013 and 2012 is summarized as follows (in thousands):

[0001047469-14-009167:notes:98]
|  |  | Years Ended March 31, |  |
|  |  | 2014 |  | 2013(1) |  | 2012(1) |  |
|  |  |  |  | As Revised |  | As Restated |  |
| Swiss |  | $ | 49,503 |  | $ | (53,004 | ) | $ | 31,045 |  |
| Non-Swiss |  |  | 28,079 |  |  | (200,324 | ) |  | 93,282 |  |
| Income (loss) before taxes |  | $ | 77,582 |  | $ | (253,328 | ) | $ | 124,327 |  |

[0001047469-14-009167:notes:99]
(1)

[0001047469-14-009167:notes:100]
During fiscal year 2014, the Company determined that Swiss loss before taxes reported previously as ($121.8) million and ($65.2) million in fiscal years 2013 and 2012, respectively, was overstated by $71.0 million in 2013 and $64.5 million in 2012 and Non-Swiss income (loss) before taxes previously reported as ($129.3) million and $157.8 million for 2013 and 2012 was understated by $71.0 million in 2013 and overstated by $64.5 million in 2012. The overstatement and understatement is due to the elimination of Swiss loss related to stock equity plans were erroneously presented as Non-Swiss in each year. In addition, Swiss loss before taxes increased by ($2.2) million and decreased by $31.7 million in fiscal year 2013 and 2012, respectively to reflect adjustments from the revision and restatement of the respective financial statements.


## us-gaap:ScheduleOfComponentsOfIncomeTaxExpenseBenefitTableTextBlock

[0001047469-14-009167:notes:101]
The provision for (benefit from) income taxes is summarized as follows (in thousands):

[0001047469-14-009167:notes:102]
|  |  | Years Ended March 31, |  |
|  |  | 2014 |  | 2013 |  | 2012 |  |
|  |  |  |  | As Revised |  | As Restated |  |
| Current: |  |  |  |  |  |  |  |  |  |  |
| Swiss |  | $ | 127 |  | $ | 672 |  | $ | 401 |  |
| Non-Swiss |  |  | 8,580 |  |  | (23,146 | ) |  | 24,312 |  |
| Deferred: |  |  |  |  |  |  |  |  |  |  |
| Swiss |  |  | — |  |  | — |  |  | (254 | ) |
| Non-Swiss |  |  | (5,429 | ) |  | (3,336 | ) |  | (4,369 | ) |
| Provision for (benefit from) income taxes |  | $ | 3,278 |  | $ | (25,810 | ) | $ | 20,090 |  |


## us-gaap:ScheduleOfEffectiveIncomeTaxRateReconciliationTableTextBlock

[0001047469-14-009167:notes:103]
The difference between the provision for (benefit from) income taxes and the expected tax provision (benefit) at the statutory income tax rate of 8.5% is reconciled below (in thousands):

[0001047469-14-009167:notes:104]
|  |  | Years Ended March 31, |  |
|  |  | 2014 |  | 2013 |  | 2012 |  |
|  |  |  |  | As Revised |  | As Restated |  |
| Expected tax provision (benefit) at statutory income tax rates |  | $ | 6,594 |  | $ | (21,533 | ) | $ | 10,568 |  |
| Income taxes at different rates |  |  | 497 |  |  | 5,714 |  |  | 2,875 |  |
| Research and development tax credits |  |  | (1,393 | ) |  | (3,302 | ) |  | (1,666 | ) |
| Foreign tax credits |  |  | — |  |  | (1,535 | ) |  | — |  |
| Stock-based compensation |  |  | 1,608 |  |  | 1,643 |  |  | 2,696 |  |
| Valuation allowance |  |  | 182 |  |  | 3,809 |  |  | (104 | ) |
| Impairment |  |  | — |  |  | 18,419 |  |  | — |  |
| Restructuring charges |  |  | 1,174 |  |  | 4,336 |  |  | — |  |
| Tax reserves (releases), net |  |  | (4,660 | ) |  | 1,935 |  |  | 6,555 |  |
| Audit settlement |  |  | (400 | ) |  | (35,608 | ) |  | — |  |
| Other, net |  |  | (324 | ) |  | 312 |  |  | (834 | ) |
| Provision for (benefit from) income taxes |  | $ | 3,278 |  | $ | (25,810 | ) | $ | 20,090 |  |


## us-gaap:ScheduleOfDeferredTaxAssetsAndLiabilitiesTableTextBlock

[0001047469-14-009167:notes:105]
Deferred income tax assets and liabilities consist of the following (in thousands):

[0001047469-14-009167:notes:106]
|  |  | March 31, |  |
|  |  | 2014 |  | 2013(1) |  |
|  |  |  |  | As Revised |  |
| Deferred tax assets: |  |  |  |  |  |  |  |
| Net operating loss carryforwards |  | $ | 9,421 |  | $ | 13,279 |  |
| Tax credit carryforwards |  |  | 13,241 |  |  | 13,746 |  |
| Accruals |  |  | 48,153 |  |  | 44,700 |  |
| Depreciation and amortization |  |  | 4,781 |  |  | 4,453 |  |
| Share-based compensation |  |  | 15,304 |  |  | 17,147 |  |
| Gross deferred tax assets |  |  | 90,900 |  |  | 93,325 |  |
| Valuation allowance |  |  | (4,872 | ) |  | (6,014 | ) |
| Gross deferred tax assets after valuation allowance |  |  | 86,028 |  |  | 87,311 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |  |
| Acquired intangible assets and other |  |  | (8,436 | ) |  | (11,951 | ) |
| Gross deferred tax liabilities |  |  | (8,436 | ) |  | (11,951 | ) |
| Deferred tax assets, net |  | $ | 77,592 |  | $ | 75,360 |  |

[0001047469-14-009167:notes:107]
Deferred tax assets and liabilities as of March 31, 2013 were adjusted to reflect the tax impact from the revision of the financial statement. In addition, during fiscal year 2014, the Company determined that a deferred tax liability related to U.S. flow-through investment of $0.9 million was erroneously presented as a deferred tax asset associated with "Accruals" as of March 31, 2013. The amount was properly reclassed from "Accruals" to "Acquired intangible assets and others" above. The reclassification adjustment has no impact in the Company's Consolidated Statement of Operations, Consolidated Balance Sheet and Statement of Cash Flows.


## us-gaap:ScheduleOfUnrecognizedTaxBenefitsRollForwardTableTextBlock

[0001047469-14-009167:notes:108]
The aggregate changes in gross unrecognized tax benefits in fiscal years 2014, 2013 and 2012 were as follows (in thousands):

[0001047469-14-009167:notes:109]
| March 31, 2011 (As Restated) |  | $ | 130,498 |  |
| Lapse of statute of limitations |  |  | (6,760 | ) |
| Decreases in balances related to tax positions taken during prior years |  |  | (1,200 | ) |
| Increases in balances related to tax positions taken during the year |  |  | 14,350 |  |
| March 31, 2012 (As Restated) |  | $ | 136,888 |  |
| Lapse of statute of limitations |  |  | (6,490 | ) |
| Settlements with tax authorities |  |  | (42,770 | ) |
| Decreases in balances related to tax positions taken during prior years |  |  | (1,500 | ) |
| Increases in balances related to tax positions taken during the year |  |  | 9,570 |  |
| March 31, 2013 (As Revised) |  | $ | 95,698 |  |
| Lapse of statute of limitations |  |  | (12,514 | ) |
| Settlements with tax authorities |  |  | (100 | ) |
| Decreases in balances related to tax positions taken during prior years |  |  | (778 | ) |
| Increases in balances related to tax positions taken during the year |  |  | 8,740 |  |
| March 31, 2014 |  | $ | 91,046 |  |


## us-gaap:InterestAndOtherIncomeTextBlock

[0001047469-14-009167:notes:110]
Note 6—Interest and Other Income (Expense), net

[0001047469-14-009167:notes:111]
Interest income (expense), net was comprised of the following (in thousands):

[0001047469-14-009167:notes:112]
|  |  | Years Ended March 31, |  |
|  |  | 2014 |  | 2013 |  | 2012 |  |
| Interest income |  | $ | 1,831 |  | $ | 2,215 |  | $ | 3,121 |  |
| Interest expense |  |  | (2,228 | ) |  | (1,308 | ) |  | (447 | ) |
| Interest income (expense), net |  | $ | (397 | ) | $ | 907 |  | $ | 2,674 |  |

[0001047469-14-009167:notes:113]
Other income (expense), net was comprised of the following (in thousands):

[0001047469-14-009167:notes:114]
|  |  | Years Ended March 31, |  |
|  |  | 2014 |  | 2013 |  | 2012 |  |
| Investment income related to deferred compensation plan |  | $ | 1,487 |  | $ | 933 |  | $ | 227 |  |
| Gain on sale of securities |  |  | — |  |  | 831 |  |  | 6,109 |  |
| Impairment of investments |  |  | (624 | ) |  | (3,600 | ) |  | — |  |
| Foreign currency exchange gain, net |  |  | 62 |  |  | 104 |  |  | 1,575 |  |
| Other |  |  | 1,068 |  |  | (466 | ) |  | (256 | ) |
| Other income (expense), net |  | $ | 1,993 |  | $ | (2,198 | ) | $ | 7,655 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001047469-14-009167:notes:115]
Note 7—Income Taxes

[0001047469-14-009167:notes:116]
The Company is incorporated in Switzerland but operates in various countries with differing tax laws and rates. Further, a portion of the Company's income (loss) before taxes and the provision for (benefit from) income taxes is generated outside of Switzerland.

[0001047469-14-009167:notes:117]
The federal research tax credit in the United States has expired as of December 31, 2013. The income tax expense for the fiscal year ended March 31, 2014 reflected a $0.8 million tax benefit for research tax credits.

[0001047469-14-009167:notes:118]
Management regularly assesses the ability to realize deferred tax assets recorded in the Company's entities based upon the weight of available evidence, including such factors as recent earnings history and expected future taxable income. In the event that the Company changes its determination as to the amount of deferred tax assets that can be realized, the Company will adjust its valuation allowance with a corresponding impact to the provision for income taxes in the period in which such determination is made.

[0001047469-14-009167:notes:119]
The Company had a valuation allowance of $4.9 million at March 31, 2014, decreased from $6.0 million at March 31, 2013 primarily due to decrease in valuation allowance of $1.3 million for foreign tax credit carryforwards in the United States. The Company elected to deduct foreign taxes in lieu of tax credits in its fiscal year 2013 federal tax return in the United States. The Company had a valuation allowance of $2.6 million as of March 31, 2014 against deferred tax assets in the state of California of the United States. The remaining valuation allowance primarily represents $1.7 million for capital loss carryforwards in the United States and $0.6 million for various tax credit carryforwards. The Company determined that it is more likely than not that the Company would not generate sufficient taxable income in the future to utilize such deferred tax assets.

[0001047469-14-009167:notes:120]
Deferred tax assets relating to tax benefits of employee stock grants have been reduced to reflect settlement activity in fiscal years 2014 and 2013. Settlement activity of grants in fiscal years 2014 and 2013 resulted in a "shortfall" in which tax deductions were less than previously recorded share-based compensation expense. The Company recorded a shortfall to equity of $2.8 million and $4.6 million, respectively, in fiscal years 2014 and 2013.

[0001047469-14-009167:notes:121]
As of March 31, 2014, the Company had foreign net operating loss and tax credit carryforwards for income tax purposes of $196.0 million and $35.7 million, respectively, of which $136.2 million of the net operating loss carryforwards and $22.7 million of the tax credit carryforwards, if realized, will be credited to equity since they have not met the applicable realization criteria. Unused net operating loss carryforwards will expire at various dates in fiscal years 2016 to 2034. Certain net operating loss carryforwards in the United States relate to acquisitions and, as a result, are limited in the amount that can be utilized in any one year. The tax credit carryforwards will begin to expire in fiscal year 2019.

[0001047469-14-009167:notes:122]
As of March 31, 2014, the Company had capital loss carryforwards of $4.6 million. The loss will begin to expire in fiscal year 2016.

[0001047469-14-009167:notes:123]
Swiss income taxes and non-Swiss withholding taxes associated with the repatriation of earnings or for other temporary differences related to investments in non-Swiss subsidiaries have not been provided for, as the Company intends to reinvest the earnings of such subsidiaries indefinitely or the Company has concluded that no additional tax liability would arise on the distribution of such earnings. If these earnings were distributed to Switzerland in the form of dividends or otherwise, or if the shares of the relevant non-Swiss subsidiaries were sold or otherwise transferred, the Company may be subject to additional Swiss income taxes and non-Swiss withholding taxes. As of March 31, 2014, the cumulative amount of unremitted earnings of non-Swiss subsidiaries was $157.4 million. Determination of the amount of unrecognized deferred income tax liability related to these earnings is not practicable.

[0001047469-14-009167:notes:124]
The Company follows a two-step approach to recognizing and measuring uncertain tax positions. The first step is to evaluate the tax position for recognition by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step is to measure the tax benefit as the largest amount that is more than 50% likely of being realized upon ultimate settlement.

[0001047469-14-009167:notes:125]
As of March 31, 2014 and March 31, 2013, the total amount of unrecognized tax benefits due to uncertain tax positions was $91.0 million and $95.4 million, respectively, of which $86.1 million and $90.3 million would affect the effective income tax rate if recognized, respectively.

[0001047469-14-009167:notes:126]
As of March 31, 2014, the Company had $93.1 million in non-current income taxes payable and $0.3 million in current income taxes payable, including interest and penalties, related to our income tax liability for uncertain tax positions. As of March 31, 2013, the Company had $98.8 million in non-current income taxes payable.

[0001047469-14-009167:notes:127]
The Company recognizes interest and penalties related to unrecognized tax positions in income tax expense. The Company recognized $1.1 million, $1.0 million and $1.2 million in interest and penalties in income tax expense during fiscal years 2014, 2013 and 2012, respectively. As of March 31, 2014, 2013 and 2012, the Company had $5.6 million, $6.6 million and $7.5 million of accrued interest and penalties related to uncertain tax positions, respectively.

[0001047469-14-009167:notes:128]
The Company files Swiss and foreign tax returns. For all these tax returns, the Company is generally not subject to tax examinations for years prior to fiscal year 2001. The Company is under examination and has received assessment notices in other tax jurisdictions. At this time, the Company is not able to estimate the potential impact that these examinations may have on its income tax expense. If the examinations are resolved unfavorably, there is a possibility they may have a material negative impact on its results of operations.

[0001047469-14-009167:notes:129]
Although the Company has adequately provided for uncertain tax positions, the provisions on these positions may change as revised estimates are made or the underlying matters are settled or otherwise resolved. During fiscal year 2015, the Company will continue to review its tax positions and provide for or reverse unrecognized tax benefits as issues arise. During the next 12 months, it is reasonably possible that the amount of unrecognized tax benefits could increase or decrease significantly due to changes in tax law in various jurisdictions, new tax audits and changes in the U.S. dollar as compared to foreign currencies. Excluding these factors, uncertain tax positions may decrease by as much as $16.0 million to $18.3 million primarily from the lapse of the statutes of limitations in various jurisdictions during the next 12 months.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001047469-14-009167:notes:130]
Note 5—Employee Benefit Plans

[0001047469-14-009167:notes:131]
Employee Share Purchase Plans and Stock Incentive Plans

[0001047469-14-009167:notes:132]
As of March 31, 2014, the Company offers the 2006 ESPP (2006 Employee Share Purchase Plan (Non-U.S.)), the 1996 ESPP (1996 Employee Share Purchase Plan (U.S.)), the 2006 Plan (2006 Stock Incentive Plan) and the 2012 Plan (2012 Stock Inducement Equity Plan). The 2012 Plan was approved by the Board of Directors in April 2012. On April 13, 2012, the Company filed registration statements to register 5.0 million additional shares to be issued pursuant to the 2006 ESPP and 1.8 million shares under the 2012 Plan. On September 5, 2012, at the fiscal year 2012 Annual General Meeting of Shareholders, Logitech shareholders approved amendments to and restatement of the 2006 Plan, which included the increase of 7.3 million additional shares to be issued under this plan and to prohibit the repricing of options or stock appreciation rights. On October 25, 2012, the Company filed a registration statement to register the 7.3 million additional shares under the 2006 Plan. On September 4, 2013, at the 2013 Annual General Meeting of Shareholders, the Company's shareholders approved amendments to, and restatement of, the 1996 ESPP and the 2006 ESPP, which included the increase of 8.0 million additional shares to be issued under these ESPP plans. On December 9, 2013, the Company filed a registration statement to register the 8.0 million additional shares under the 1996 ESPP and 2006 ESPP. Shares issued to employees as a result of purchases or exercises under these plans are generally issued from shares held in treasury.

[0001047469-14-009167:notes:133]
The following table summarizes share-based compensation expense and related tax benefit recognized for fiscal years 2014, 2013 and 2012 (in thousands):

[0001047469-14-009167:notes:134]
|  |  | Years Ended March 31, |  |
|  |  | 2014 |  | 2013 |  | 2012 |  |
| Cost of goods sold |  | $ | 2,518 |  | $ | 2,499 |  | $ | 3,620 |  |
| Research and development |  |  | 4,546 |  |  | 7,532 |  |  | 7,187 |  |
| Marketing and selling |  |  | 8,298 |  |  | 7,825 |  |  | 12,716 |  |
| General and administrative |  |  | 10,184 |  |  | 7,342 |  |  | 8,006 |  |
| Total share-based compensation expense |  |  | 25,546 |  |  | 25,198 |  |  | 31,529 |  |
| Income tax benefit |  |  | (4,902 | ) |  | (5,356 | ) |  | (6,294 | ) |
| Total share-based compensation expense, net of income tax |  | $ | 20,644 |  | $ | 19,842 |  | $ | 25,235 |  |

[0001047469-14-009167:notes:135]
During the years ended March 31, 2014, 2013, and 2012, the Company capitalized $0.4 million, $0.4 million and $0.7 million, respectively, of stock-based compensation expenses as inventory.

[0001047469-14-009167:notes:136]
The following table summarizes total unamortized share-based compensation expense and the remaining months over which such expense is expected to be recognized, on a weighted-average basis by type of grant (in thousands, except number of months):

[0001047469-14-009167:notes:137]
|  |  | March 31, 2014 |  |
|  |  | Unamortized Expense |  | Remaining Months |  |
| Stock options and ESPP |  | $ | 980 |  |  | 17 |  |
| Premium-priced stock options |  |  | 789 |  |  | 19 |  |
| Market-based stock options |  |  | 1,304 |  |  | 9 |  |
| Time-based RSUs |  |  | 37,379 |  |  | 22 |  |
| Market-based RSUs |  |  | 4,901 |  |  | 27 |  |
|  |  | $ | 45,353 |  |  |  |  |

[0001047469-14-009167:notes:138]
Under the 1996 ESPP and 2006 ESPP plans, eligible employees may purchase shares at the lower of 85% of the fair market value at the beginning or the end of each six-month offering period. Subject to continued participation in these plans, purchase agreements are automatically executed at the end of each offering period. An aggregate of 29,000,000 shares was reserved for issuance under the 1996 and 2006 ESPP plans. As of March 31, 2014, a total of 8,266,700 shares were available for issuance under these plans.

[0001047469-14-009167:notes:139]
The 2006 Plan provides for the grant to eligible employees and non-employee directors of stock options, stock appreciation rights, restricted stock and RSUs. Awards under the 2006 Plan may be conditioned on continued employment, the passage of time or the satisfaction of performance vesting criteria. The 2006 Stock Plan has an expiration date of June 16, 2016. Stock options granted under the 2006 Plan generally vest over three years for non-executive Directors and over four years for employees. All stock options under this plan have terms not exceeding ten years and are issued at exercise prices not less than the fair market value on the date of grant. Premium-priced stock options granted to executives under the 2006 Plan vest only when performance criteria is met as determined by a third party vendor. Time-based RSUs granted to employees under the 2006 Plan generally vest in four equal annual installments on the grant date anniversary. Time-based RSUs granted to non-executive board members under the 2006 Plan vest in one annual installment on the grant date anniversary. Market-based options and RSUs granted under the 2006 Plan vest at the end of the performance period upon meeting certain share price performance criteria measured against market conditions. The performance period is four years for market-based options granted in fiscal year 2013. The performance period is three years for market-based RSU grants made in fiscal years 2014, 2013 and 2012. An aggregate of 24,800,000 shares was reserved for issuance under the 2006 Plan. As of March 31, 2014, a total of 9,136,223 shares were available for issuance under this plan.

[0001047469-14-009167:notes:140]
Under the 2012 Stock Inducement Equity Plan, stock options and RSUs may be granted to eligible employees to serve as inducement material to enter into employment with the Company. Awards under the 2012 Stock Inducement Equity Plan may be conditioned on continued employment, the passage of time or the satisfaction of performance vesting criteria, based on individual written employment offer letter. The 2012 Stock Inducement Equity Plan has an expiration date of March 28, 2022. An aggregate of 1,800,000 shares was reserved for issuance under the 2012 Stock Inducement Equity Plan. As of March 31, 2014, no shares were available for issuance under this plan.

[0001047469-14-009167:notes:141]
A summary of the Company's stock option activity for fiscal years 2014, 2013 and 2012 is as follows (in thousands, except per share data; exercise prices are weighted averages):

[0001047469-14-009167:notes:142]
|  |  | Years Ended March 31, |  |
|  |  | 2014 |  | 2013 |  | 2012 |  |
|  |  | Shares |  | Exercise Price |  | Shares |  | Exercise Price |  | Shares |  | Exercise Price |  |
| Outstanding, beginning of year |  |  | 13,684 |  | $ | 16 |  |  | 13,034 |  | $ | 19 |  |  | 16,312 |  | $ | 19 |  |
| Granted |  |  | — |  | $ | — |  |  | 3,718 |  | $ | 8 |  |  | — |  | $ | — |  |
| Exercised |  |  | (551 | ) | $ | 9 |  |  | (389 | ) | $ | 6 |  |  | (316 | ) | $ | 8 |  |
| Cancelled or expired |  |  | (3,317 | ) | $ | 15 |  |  | (2,679 | ) | $ | 20 |  |  | (2,962 | ) | $ | 22 |  |
| Outstanding, end of year |  |  | 9,816 |  | $ | 16 |  |  | 13,684 |  | $ | 16 |  |  | 13,034 |  | $ | 19 |  |
| Exercisable, end of year |  |  | 7,056 |  | $ | 19 |  |  | 9,355 |  | $ | 19 |  |  | 10,867 |  | $ | 20 |  |

[0001047469-14-009167:notes:143]
The total pretax intrinsic value of stock options exercised during the fiscal years 2014, 2013 and 2012 was $2.0 million, $1.1 million and $0.8 million, respectively, and the tax benefit realized for the tax deduction from options exercised during those periods was $0.5 million, $0.3 million and $0.2 million, respectively. The total fair value of options exercisable as of March 31, 2014, 2013 and 2012 was $42.8 million, $60.5 million and $76.0 million, respectively.

[0001047469-14-009167:notes:144]
The fair value of employee stock options granted and shares purchased under the Company's employee purchase plans was estimated using the Black-Scholes-Merton option-pricing valuation model applying the following assumptions and values.

[0001047469-14-009167:notes:145]
|  |  | Purchase Plans |  | Stock Option Plans |  | Premium Priced Options |  | Market-based Stock Option Plan |
|  |  | Fiscal Years Ended March 31, |  | Fiscal Years Ended March 31, |  | Fiscal Years Ended March 31, |  | Fiscal Years Ended March 31, |
|  |  | 2014 |  | 2013 |  | 2012 |  | 2014 |  | 2013 |  | 2012 |  | 2014 |  | 2013 |  | 2012 |  | 2014 |  | 2013 |  | 2012 |
| Dividend yield |  |  | 0.43 | % |  | 0 | % |  | 0 | % | n/a |  |  | 0 | % | n/a |  | n/a |  |  | 0 | % | n/a |  | n/a |  |  | 0 | % | n/a |
| Risk-free interest rate |  |  | 0.07 | % |  | 0.09 | % |  | 0.13 | % | n/a |  |  | 1.20 | % | n/a |  | n/a |  |  | 2.00 | % | n/a |  | n/a |  |  | 1.93 | % | n/a |
| Expected volatility |  |  | 36 | % |  | 47 | % |  | 52 | % | n/a |  |  | 46 | % | n/a |  | n/a |  |  | 46 | % | n/a |  | n/a |  |  | 44 | % | n/a |
| Expected life (years) |  |  | 0.5 |  |  | 0.5 |  |  | 0.5 |  | n/a |  |  | 6.0 |  | n/a |  | n/a |  |  | 7.0 |  | n/a |  | n/a |  |  | 6.0 |  | n/a |
| Weighted average fair value |  | $ | 2.46 |  | $ | 2.14 |  | $ | 2.96 |  | n/a |  | $ | 3.64 |  | n/a |  | n/a |  | $ | 2.52 |  | n/a |  | n/a |  | $ | 2.58 |  | n/a |

[0001047469-14-009167:notes:146]
The dividend yield assumption is based on the Company's history and future expectations of dividend payouts. In September 2012, the Company's shareholders approved, and the Company paid, a one-time cash dividend of CHF 125.7 million ($133.5 million in U.S. Dollars), out of retained earnings to Logitech's existing shareholders. The dividend qualified as a distribution of qualifying additional paid-in-capital. In May 2013, the Company announced its plan to issue an annual dividend on a recurring basis. In September 2013, the Company's shareholders approved, and the Company paid, a cash dividend of CHF 33.7 million ($36.1 million in U.S. dollars) to the existing shareholders. The unvested or unexercised options and RSUs are not eligible for these dividends. The expected option life represents the weighted-average period the stock options or purchase offerings are expected to remain outstanding. The expected life is based on historical settlement rates, which the Company believes are most representative of future exercise and post-vesting termination behaviors. Expected share price volatility is based on historical volatility using the Company's daily closing prices over the term of past options or purchase offerings. The Company considers the historical price volatility of its shares as most representative of future volatility. The risk-free interest rate assumptions are based upon the implied yield of U.S. Treasury zero-coupon issues appropriate for the term of the Company's stock options or purchase offerings.

[0001047469-14-009167:notes:147]
The Company estimates option forfeitures at the time of grant and revises those estimates in subsequent periods if actual forfeitures differ from those estimates. The Company uses historical data to estimate pre-vesting option forfeitures and records share-based compensation expense only for those awards that are expected to vest.

[0001047469-14-009167:notes:148]
As of March 31, 2014, the exercise price of outstanding options ranged from $1 to $35 per option, the weighted average remaining contractual life of outstanding options was 4.9 years, and the weighted average remaining contractual life of exercisable options was 3.6 years. As of March 31, 2014, the aggregate intrinsic value of outstanding options was $20.1 million and the aggregate intrinsic value of exercisable options was $6.5 million.

[0001047469-14-009167:notes:149]
The total number of fully vested in-the-money options exercisable as of March 31, 2014 was 2,500,762 and 2,756,753 options were unvested, of which 2,370,808 are expected to vest, based on an estimated forfeiture rate of 14%.

[0001047469-14-009167:notes:150]
A summary of the Company's time- and market-based RSU activity for fiscal years 2014, 2013 and 2012 is as follows (in thousands, except per share values; grant-date fair values are weighted averages):

[0001047469-14-009167:notes:151]
|  |  | Years Ended March 31, |  |
|  |  | 2014 |  | 2013 |  | 2012 |  |
|  |  | Shares |  | Fair Value |  | Shares |  | Fair Value |  | Shares |  | Fair Value |  |
| Outstanding, beginning of year |  |  | 4,642 |  | $ | 10 |  |  | 4,125 |  | $ | 13 |  |  | 2,370 |  | $ | 21 |  |
| Granted—time-based |  |  | 3,104 |  | $ | 11 |  |  | 2,219 |  | $ | 7 |  |  | 2,496 |  | $ | 9 |  |
| Granted—market-based |  |  | 1,060 |  | $ | 8 |  |  | 101 |  | $ | 6 |  |  | 516 |  | $ | 11 |  |
| Vested |  |  | (1,560 | ) | $ | 9 |  |  | (1,097 | ) | $ | 11 |  |  | (399 | ) | $ | 19 |  |
| Cancelled or expired |  |  | (1,158 | ) | $ | 15 |  |  | (706 | ) | $ | 13 |  |  | (858 | ) | $ | 19 |  |
| Outstanding, end of year |  |  | 6,088 |  | $ | 10 |  |  | 4,642 |  | $ | 10 |  |  | 4,125 |  | $ | 13 |  |

[0001047469-14-009167:notes:152]
The total pretax intrinsic value of RSUs that vested during the fiscal years 2014, 2013 and 2012 was $ 17.8 million, $8.3 million and $3.8 million, respectively. The tax benefit realized for the tax deduction from RSUs that vested during the fiscal years 2014, 2013 and 2012 was $4.7 million, $1.9 million and $0.9 million, respectively.

[0001047469-14-009167:notes:153]
The Company determines the fair value of the time-based RSUs based on the market price on the date of grant. The fair value of the market-based RSUs is estimated using the Monte-Carlo simulation model applying the following assumptions:

[0001047469-14-009167:notes:154]
|  |  | Years Ended March 31, |  |
|  |  | 2014 |  | 2013 |  | 2012 |  |
| Dividend yield |  |  | 0.75 | % |  | 0 | % |  | 0 | % |
| Risk-free interest rate |  |  | 1.09 | % |  | 0.31 | % |  | 0.99 | % |
| Expected volatility |  |  | 46 | % |  | 47 | % |  | 49 | % |
| Expected life (years) |  |  | 2.9 |  |  | 3.0 |  |  | 3.0 |  |

[0001047469-14-009167:notes:155]
The dividend yield assumption is based on the Company's history and future expectations of dividend payouts. The expected life of the market-based RSUs is the service period at the end of which the RSUs will vest if the market conditions are satisfied. The volatility assumption is based on the actual volatility of Logitech's daily closing share price over a look-back period equal to the years of expected life. The risk free interest rate is derived from the yield on U.S. Treasury Bonds for a term of the same number of years as the expected life.

[0001047469-14-009167:notes:156]
As of March 31, 2014, the grant date fair values of outstanding RSUs ranged from $6 to $20 per RSU.

[0001047469-14-009167:notes:157]
In April 2012, Logitech's Board of Directors approved the 2012 Stock Inducement Equity Plan. Under this plan, Logitech's newly hired President, Bracken P. Darrell, who became President and Chief Executive Officer in January 2013, was granted the following equity incentive awards with a ten year term (in thousands, except per share exercise price and vesting period):

[0001047469-14-009167:notes:158]
| Type of Grant |  | Shares |  | Exercise Price |  | Fair Value |  | Vesting(1) (in years) |  |
| Stock options |  |  | 500 |  | $ | 8 |  | $ | 1,820 |  |  | 4.0 |  |
| Time based RSUs |  |  | 100 |  |  | — |  |  | 803 |  |  | 4.0 |  |
| Premium-priced stock options(2): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| First tranche |  |  | 400 |  |  | 14 |  |  | 1,100 |  |  | 2.5 |  |
| Second tranche |  |  | 400 |  |  | 16 |  |  | 1,024 |  |  | 3.0 |  |
| Third tranche |  |  | 400 |  |  | 20 |  |  | 896 |  |  | 3.9 |  |

[0001047469-14-009167:notes:159]
Vesting period for premium-priced stock options represents estimated requisite service period.

[0001047469-14-009167:notes:160]
(2)

[0001047469-14-009167:notes:161]
Each grant of premium-priced stock options will vest in full if and only when Logitech's average closing share price, over a consecutive ninety-day trading period, meets or exceeds the exercise price of the grant.

[0001047469-14-009167:notes:162]
Defined Contribution Plans

[0001047469-14-009167:notes:163]
Certain of the Company's subsidiaries have defined contribution employee benefit plans covering all or a portion of their employees. Contributions to these plans are discretionary for certain plans and are based on specified or statutory requirements for others. The charges to expense for these plans for fiscal years 2014, 2013 and 2012, were $6.6 million, $6.9 million and $11.6 million, respectively.

[0001047469-14-009167:notes:164]
Defined Benefit Plans

[0001047469-14-009167:notes:165]
Certain of the Company's subsidiaries sponsor defined benefit pension plans or non-retirement post-employment benefits covering substantially all of their employees. Benefits are provided based on employees' years of service and earnings, or in accordance with applicable employee benefit regulations. The Company's practice is to fund amounts sufficient to meet the requirements set forth in the applicable employee benefit and tax regulations.

[0001047469-14-009167:notes:166]
During fiscal year 2013, the Company's Swiss defined benefit pension plan was subject to re-measurement due to the number of plan participants affected by the restructurings implemented during fiscal year 2013, as described in Note 15, Restructuring. The re-measurement resulted in the realization of $2.2 million in previously unrecognized losses which resided within accumulated other comprehensive loss and which the Company entirely recognized during fiscal year 2013. The Company's restructuring plan implemented during the fourth quarter of fiscal year 2013 resulted in an additional $1.2 million in previously unrecognized losses related to affected plan participants which resided within accumulated other comprehensive income (loss) and which the Company entirely recognized during the quarter ended March 31, 2013.

[0001047469-14-009167:notes:167]
The Company recognizes the underfunded or overfunded status of defined benefit pension plans and non-retirement post-employment benefit obligations as an asset or liability in its consolidated balance sheets, and recognizes changes in the funded status of defined benefit pension plans in the year in which the changes occur through accumulated other comprehensive income (loss), which is a component of shareholders' equity. Each plan's assets and benefit obligations are measured as of March 31 each year.

[0001047469-14-009167:notes:168]
The net periodic benefit cost of the defined benefit pension plans and the non-retirement post-employment benefit obligations for fiscal years 2014, 2013 and 2012 was as follows (in thousands):

[0001047469-14-009167:notes:169]
|  |  | Years Ended March 31, |  |
|  |  | 2014 |  | 2013 |  | 2012 |  |
|  |  |  |  | As Revised |  | As Restated |  |
| Service costs |  | $ | 8,591 |  | $ | 7,842 |  | $ | 6,856 |  |
| Interest costs |  |  | 1,794 |  |  | 1,852 |  |  | 2,263 |  |
| Expected return on plan assets |  |  | (1,727 | ) |  | (1,710 | ) |  | (1,969 | ) |
| Amortization of net transition obligation |  |  | 4 |  |  | 5 |  |  | 5 |  |
| Net period service costs recognized |  |  | 210 |  |  | 712 |  |  | 156 |  |
| Net actuarial loss recognized |  |  | 592 |  |  | 846 |  |  | 205 |  |
| Settlement costs |  |  | 769 |  |  | 2,658 |  |  | — |  |
|  |  | $ | 10,233 |  | $ | 12,205 |  | $ | 7,516 |  |

[0001047469-14-009167:notes:170]
The changes in projected benefit obligations for fiscal years 2014 and 2013 were as follows (in thousands):

[0001047469-14-009167:notes:171]
|  |  | Years Ended March 31, |  |
|  |  | 2014 |  | 2013 |  |
|  |  |  |  | As Revised |  |
| Projected benefit obligation, beginning of year |  | $ | 90,234 |  | $ | 97,459 |  |
| Service costs |  |  | 8,591 |  |  | 7,842 |  |
| Interest costs |  |  | 1,794 |  |  | 1,852 |  |
| Plan participant contributions |  |  | 2,726 |  |  | 2,814 |  |
| Actuarial (gains) losses |  |  | (2,942 | ) |  | 7,146 |  |
| Benefits paid |  |  | (1,841 | ) |  | (2,285 | ) |
| Plan amendments |  |  | — |  |  | (1,456 | ) |
| Settlement and curtailment |  |  | (1,261 | ) |  | (18,758 | ) |
| Administrative expense paid |  |  | (174 | ) |  | (164 | ) |
| Foreign currency exchange rate changes |  |  | 5,256 |  |  | (4,216 | ) |
| Projected benefit obligation, end of year |  | $ | 102,383 |  | $ | 90,234 |  |

[0001047469-14-009167:notes:172]
The accumulated benefit obligation for all defined benefit pension plans as of March 31, 2014 and 2013 was $83.2 million and $69.9 million.

[0001047469-14-009167:notes:173]
The following table presents the changes in the fair value of defined benefit pension plan assets for fiscal years 2014 and 2013 (in thousands):

[0001047469-14-009167:notes:174]
|  |  | Years Ended March 31, |  |
|  |  | 2014 |  | 2013 |  |
|  |  |  |  | As Revised |  |
| Fair value of plan assets, beginning of year |  | $ | 48,689 |  | $ | 53,594 |  |
| Actual return on plan assets |  |  | 5,334 |  |  | 2,913 |  |
| Employer contributions |  |  | 5,390 |  |  | 6,352 |  |
| Plan participant contributions |  |  | 2,726 |  |  | 2,814 |  |
| Benefits paid |  |  | (1,841 | ) |  | (2,285 | ) |
| Settlement |  |  | (500 | ) |  | (11,874 | ) |
| Administrative expenses paid |  |  | (174 | ) |  | (164 | ) |
| Foreign currency exchange rate changes |  |  | 3,760 |  |  | (2,661 | ) |
| Fair value of plan assets, end of year |  | $ | 63,384 |  | $ | 48,689 |  |

[0001047469-14-009167:notes:175]
The Company's investment objectives are to ensure that the assets of its defined benefit plans are invested to provide an optimal rate of investment return on the total investment portfolio, consistent with the assumption of a reasonable risk level, and to ensure that pension funds are available to meet the plans' benefit obligations as they become due. The Company believes that a well-diversified investment portfolio will result in the highest attainable investment return with an acceptable level of overall risk. Investment strategies and allocation decisions are also governed by applicable governmental regulatory agencies. The Company's investment strategy with respect to its largest defined benefit plan, which is available only to Swiss employees, is to invest in the following allocation ranges starting from January 2014: 20-55% for equities, 25-60% for bonds, and 0-10% for cash and cash equivalents. The Company also can invest in real estate funds, commodity funds, and hedge funds depend upon economic conditions. Prior to January 2014, the Company followed the following allocation ranges: 28-43% for equities, 33-63% for Swiss bonds, 5-15% for foreign bonds, 5-15% for hedge and investment funds, and 0-20% for cash and cash equivalents. The Company's other defined benefit plans, which comprise 6.2% of total defined benefit plan assets as of March 31, 2014, have similar investment and allocation strategies.

[0001047469-14-009167:notes:176]
The following tables present the fair value of the defined benefit pension plan assets by major categories and by levels within the fair value hierarchy as of March 31, 2014 and 2013 (in thousands):

[0001047469-14-009167:notes:177]
|  |  | March 31, |  |
|  |  | 2014 |  | 2013 |  |
|  |  |  |  |  |  |  |  |  |  | As Revised |  |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  |
| Cash |  | $ | 10,339 |  | $ | — |  | $ | — |  | $ | 10,339 |  | $ | 7,143 |  | $ | — |  | $ | — |  | $ | 7,143 |  |
| Equity securities |  |  | 17,324 |  |  | — |  |  | — |  |  | 17,324 |  |  | 14,802 |  |  | — |  |  | — |  |  | 14,802 |  |
| Debt securities |  |  | 20,300 |  |  | — |  |  | — |  |  | 20,300 |  |  | 20,663 |  |  | — |  |  | — |  |  | 20,663 |  |
| Swiss real estate funds |  |  | 8,970 |  |  | — |  |  | — |  |  | 8,970 |  |  | 3,968 |  |  | — |  |  | — |  |  | 3,968 |  |
| Hedge funds |  |  | — |  |  | 3,611 |  |  | — |  |  | 3,611 |  |  | — |  |  | 1,062 |  |  | — |  |  | 1,062 |  |
| Commodity funds |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 693 |  |  | — |  |  | — |  |  | 693 |  |
| Insurance contracts |  |  | — |  |  | — |  |  | 2,598 |  |  | 2,598 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other |  |  | 43 |  |  | 199 |  |  | — |  |  | 242 |  |  | 106 |  |  | 252 |  |  | — |  |  | 358 |  |
|  |  | $ | 56,976 |  | $ | 3,810 |  | $ | 2,598 |  | $ | 63,384 |  | $ | 47,375 |  | $ | 1,314 |  | $ | — |  | $ | 48,689 |  |

[0001047469-14-009167:notes:178]
The funded status of the defined benefit pension plans is the fair value of plan assets less benefit obligations. The funded status of the non-retirement post-employment benefits is the fair value of the benefit obligations. Projected benefit obligations exceeded plan assets for all plans by $39.0 million and $41.5 million as of March 31, 2014 and 2013.

[0001047469-14-009167:notes:179]
Amounts recognized on the balance sheet for the plans were as follows (in thousands):

[0001047469-14-009167:notes:180]
|  |  | March 31, |  |
|  |  | 2014 |  | 2013 |  |
|  |  |  |  | As Revised |  |
| Current assets |  | $ | — |  | $ | — |  |
| Current liabilities |  |  | (1,100 | ) |  | (994 | ) |
| Non-current liabilities |  |  | (37,899 | ) |  | (40,551 | ) |
| Net liabilities |  | $ | (38,999 | ) | $ | (41,545 | ) |

[0001047469-14-009167:notes:181]
Amounts recognized in accumulated other comprehensive loss related to defined benefit pension plans were as follows (in thousands):

[0001047469-14-009167:notes:182]
|  |  | March 31, |  |
|  |  | 2014 |  | 2013 |  | 2012 |  |
|  |  |  |  | As Revised |  |  |  |
| Net prior service costs |  | $ | (2,149 | ) | $ | (2,307 | ) | $ | (1,918 | ) |
| Net actuarial loss |  |  | (12,319 | ) |  | (19,850 | ) |  | (28,172 | ) |
| Amortization of net transition obligation |  |  | (12 | ) |  | (14 | ) |  | (24 | ) |
| Accumulated other comprehensive loss |  |  | (14,480 | ) |  | (22,171 | ) |  | (30,114 | ) |
| Deferred tax benefit |  |  | 192 |  |  | 315 |  |  | 752 |  |
| Accumulated other comprehensive loss, net of tax |  | $ | (14,288 | ) | $ | (21,856 | ) | $ | (29,362 | ) |

[0001047469-14-009167:notes:183]
Changes in accumulated other comprehensive loss related to the defined benefit pension plans were as follows (in thousands):

[0001047469-14-009167:notes:184]
|  |  | Years Ended March 31, |  |
|  |  | 2014 |  | 2013 |  | 2012 |  |
|  |  |  |  | As Revised |  | As Restated |  |
| Accumulated other comprehensive loss, beginning of year |  | $ | (21,856 | ) | $ | (29,362 | ) | $ | (18,073 | ) |
| Transition obligation recognized |  |  | 4 |  |  | 5 |  |  | — |  |
| Prior service cost (credit) recognized |  |  | 210 |  |  | 153 |  |  | (15 | ) |
| Actuarial loss recognized |  |  | 1,056 |  |  | 1,199 |  |  | 275 |  |
| Curtailment loss |  |  | 761 |  |  | 2,600 |  |  | — |  |
| Settlement gain recognized |  |  | 747 |  |  | 2,276 |  |  | — |  |
| Gain (loss) |  |  | 6,087 |  |  | 1,351 |  |  | (11,808 | ) |
| Prior service credit |  |  | — |  |  | (944 | ) |  | — |  |
| Deferred tax benefit (expense) |  |  | (123 | ) |  | (435 | ) |  | 170 |  |
| Foreign currency exchange rate changes |  |  | (1,174 | ) |  | 1,301 |  |  | 89 |  |
| Accumulated other comprehensive loss, end of year |  | $ | (14,288 | ) | $ | (21,856 | ) | $ | (29,362 | ) |

[0001047469-14-009167:notes:185]
The following table presents the amounts included in accumulated other comprehensive loss as of March 31, 2014, which are expected to be recognized as a component of net periodic benefit cost in fiscal year 2015 (in thousands):

[0001047469-14-009167:notes:186]
|  |  | Year Ending March 31, 2015 |  |
| Amortization of net transition obligation |  | $ | 4 |  |
| Amortization of net prior service costs |  |  | 212 |  |
| Amortization of net actuarial loss |  |  | 368 |  |
|  |  | $ | 584 |  |

[0001047469-14-009167:notes:187]
The Company reassesses its benefit plan assumptions on a regular basis. The actuarial assumptions for the pension plans for fiscal years 2014 and 2013 were as follows:

[0001047469-14-009167:notes:188]
|  |  | Years Ended March 31, |
|  |  | 2014 |  |  |  |  |
|  |  | 2013 |
|  |  | Benefit Obligation |  |  |
|  |  | Periodic Costs |  | Benefit Obligation |  | Periodic Costs |
| Discount rate |  | 1.50%-9.25% |  | 1.50%-8.00% |  | 1.50%-8.00% |  | 1.75%-8.50% |
| Estimated rate of compensation increase |  | 3.00%-8.00% |  | 3.00%-4.00% |  | 3.00%-10.00% |  | 3.00%-10.00% |
| Expected average rate of return on plan assets |  | 1.00%-3.50% |  | 0.75%-3.50% |  | 1.00%-3.50% |  | 0.75%-3.75% |

[0001047469-14-009167:notes:189]
The discount rate is estimated based on corporate bond yields or securities of similar quality in the respective country, with a duration approximating the period over which the benefit obligations are expected to be paid. The Company bases the compensation increase assumptions on historical experience and future expectations. The expected average rate of return for the Company's defined benefit pension plans represents the average rate of return expected to be earned on plan assets over the period that the benefit obligations are expected to be paid, based on government bond notes in the respective country, adjusted for corporate risk premiums as appropriate.

[0001047469-14-009167:notes:190]
The following table reflects the benefit payments that the Company expects the plans to pay in the periods noted (in thousands):

[0001047469-14-009167:notes:191]
| Years Ending March 31, |  |  |  |
| 2015 |  | $ | 4,573 |  |
| 2016 |  |  | 5,144 |  |
| 2017 |  |  | 4,988 |  |
| 2018 |  |  | 5,481 |  |
| 2019 |  |  | 5,615 |  |
| Thereafter |  |  | 29,018 |  |
|  |  | $ | 54,819 |  |

[0001047469-14-009167:notes:192]
The Company expects to contribute $5.3 million to its defined benefit pension plans during fiscal year 2015.

[0001047469-14-009167:notes:193]
Deferred Compensation Plan

[0001047469-14-009167:notes:194]
One of the Company's subsidiaries offers a deferred compensation plan that permits eligible employees to make 100% vested salary and incentive compensation deferrals within established limits. The Company does not make contributions to the plan.

[0001047469-14-009167:notes:195]
The fair value of the deferred compensation plan's assets is included in other assets in the consolidated balance sheets. The marketable securities are classified as trading investments and were recorded at a fair value of $16.6 million and $15.6 million as of March 31, 2014 and 2013, based on quoted market prices. The Company also had $16.6 million and $15.6 million deferred compensation liability as of March 31, 2014 and 2013, respectively. Earnings, gains and losses on trading investments are included in other income (expense), net and corresponding changes in deferred compensation liability are included in operating expenses and cost of goods sold.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001047469-14-009167:notes:196]
Note 8—Balance Sheet Components

[0001047469-14-009167:notes:197]
The following table presents the components of certain balance sheet asset amounts as of March 31, 2014 and 2013 (in thousands):

[0001047469-14-009167:notes:198]
|  |  | March 31, |  |
|  |  | 2014 |  | 2013 |  |
|  |  |  |  | As Revised |  |
| Accounts receivable: |  |  |  |  |  |  |  |
| Accounts receivable |  | $ | 338,194 |  | $ | 325,870 |  |
| Allowance for doubtful accounts |  |  | (1,712 | ) |  | (2,153 | ) |
| Allowance for sales returns |  |  | (19,472 | ) |  | (21,883 | ) |
| Allowance for cooperative marketing arrangements |  |  | (24,135 | ) |  | (24,160 | ) |
| Allowance for customer incentive programs |  |  | (41,400 | ) |  | (42,857 | ) |
| Allowance for pricing programs |  |  | (69,446 | ) |  | (55,858 | ) |
|  |  | $ | 182,029 |  | $ | 178,959 |  |
| Inventories: |  |  |  |  |  |  |  |
| Raw materials |  | $ | 24,031 |  | $ | 37,504 |  |
| Work-in-process |  |  | 42 |  |  | 41 |  |
| Finished goods |  |  | 198,329 |  |  | 225,099 |  |
|  |  | $ | 222,402 |  | $ | 262,644 |  |
| Other current assets: |  |  |  |  |  |  |  |
| Income tax and value-added tax receivables |  | $ | 18,252 |  | $ | 20,073 |  |
| Deferred tax assets |  |  | 27,013 |  |  | 25,004 |  |
| Prepaid expenses and other assets |  |  | 13,892 |  |  | 15,300 |  |
|  |  | $ | 59,157 |  | $ | 60,377 |  |
| Property, plant and equipment, net: |  |  |  |  |  |  |  |
| Plant, buildings and improvements |  | $ | 69,897 |  | $ | 70,009 |  |
| Equipment |  |  | 134,975 |  |  | 133,201 |  |
| Computer equipment |  |  | 40,610 |  |  | 52,881 |  |
| Software |  |  | 81,179 |  |  | 81,320 |  |
|  |  |  | 326,661 |  |  | 337,411 |  |
| Less accumulated depreciation and amortization |  |  | (256,424 | ) |  | (255,564 | ) |
|  |  |  | 70,237 |  |  | 81,847 |  |
| Construction-in-process |  |  | 15,362 |  |  | 9,047 |  |
| Land |  |  | 2,792 |  |  | 2,827 |  |
|  |  | $ | 88,391 |  | $ | 93,721 |  |
| Other assets: |  |  |  |  |  |  |  |
| Deferred tax assets |  | $ | 52,883 |  | $ | 52,404 |  |
| Trading investments |  |  | 16,611 |  |  | 15,599 |  |
| Other assets |  |  | 4,966 |  |  | 6,464 |  |
|  |  | $ | 74,460 |  | $ | 74,467 |  |

[0001047469-14-009167:notes:199]
The following table presents the components of certain balance sheet liability amounts as of March 31, 2014 and 2013 (in thousands):

[0001047469-14-009167:notes:200]
|  |  | March 31, |  |
|  |  | 2014 |  | 2013 |  |
|  |  |  |  | As Revised |  |
| Accrued and other current liabilities: |  |  |  |  |  |  |  |
| Accrued personnel expenses |  | $ | 55,165 |  | $ | 39,631 |  |
| Accrued marketing expenses |  |  | 12,844 |  |  | 11,005 |  |
| Indirect customer incentive programs |  |  | 31,737 |  |  | 29,464 |  |
| Accrued restructuring |  |  | 2,121 |  |  | 13,458 |  |
| Deferred revenue |  |  | 22,529 |  |  | 22,698 |  |
| Accrued freight and duty |  |  | 6,276 |  |  | 5,882 |  |
| Value-added taxes payable |  |  | 9,354 |  |  | 8,544 |  |
| Accrued royalties |  |  | 2,653 |  |  | 3,358 |  |
| Warranty accrual |  |  | 13,905 |  |  | 12,782 |  |
| Employee benefit plan obligation |  |  | 1,100 |  |  | 994 |  |
| Income taxes payable |  |  | 7,701 |  |  | 5,032 |  |
| Other liabilities |  |  | 46,587 |  |  | 40,236 |  |
|  |  | $ | 211,972 |  | $ | 193,084 |  |
| Non-current liabilities: |  |  |  |  |  |  |  |
| Warranty accrual |  |  | 10,475 |  |  | 8,660 |  |
| Obligation for deferred compensation |  |  | 16,611 |  |  | 15,631 |  |
| Long term restructuring |  |  | 5,440 |  |  | — |  |
| Employee benefit plan obligation |  |  | 37,899 |  |  | 40,551 |  |
| Deferred rent |  |  | 15,555 |  |  | 22,315 |  |
| Deferred tax liability |  |  | 2,304 |  |  | 2,048 |  |
| Long term deferred revenue |  |  | 9,350 |  |  | 8,889 |  |
| Other liabilities |  |  | 1,715 |  |  | 1,768 |  |
|  |  | $ | 99,349 |  | $ | 99,862 |  |

[0001047469-14-009167:notes:201]
During the fiscal year 2013, the Company made a strategic decision to divest its Remotes product category and its digital video security product line, included within its Video product category. As a result, assets and liabilities of the Remotes product category and the digital video security product line were classified as held for sale as of March 31, 2013. During the fiscal year ended March 31, 2014, the Company updated its strategic direction and decided to retain its Remotes product category. As a result, the Remotes assets and liabilities held for sale was reclassified from held for sale as of March 31, 2014.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001047469-14-009167:notes:202]
Note 9—Financial Instruments

[0001047469-14-009167:notes:203]
Fair Value Measurements

[0001047469-14-009167:notes:204]
The Company considers fair value as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants at the measurement date. The Company utilizes the following three-level fair value hierarchy to establish the priorities of the inputs used to measure fair value:

[0001047469-14-009167:notes:205]
Level 1—Quoted prices in active markets for identical assets or liabilities.

[0001047469-14-009167:notes:206]
Level 2—Observable inputs other than quoted market prices included in Level 1, such as quoted prices for similar assets and liabilities in active markets; quoted prices for identical or similar assets and liabilities in markets that are not active; or other inputs that are observable or can be corroborated by observable market data.

[0001047469-14-009167:notes:207]
Level 3—Unobservable inputs that are supported by little or no market activity and that are significant to the fair value of the assets or liabilities. This includes certain pricing models, discounted cash flow methodologies and similar techniques that use significant unobservable inputs.

[0001047469-14-009167:notes:208]
The following table presents the Company's financial assets and liabilities, that were accounted for at fair value, excluding assets related to the Company's defined benefit pension plans, classified by the level within the fair value hierarchy (in thousands):

[0001047469-14-009167:notes:209]
|  |  | March 31, 2014 |  | March 31, 2013 |  |
|  |  | Level 1 |  | Level 2 |  | Level 1 |  | Level 2 |  |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  |  | 200,641 |  |  | — |  |  | 119,073 |  |  | — |  |
|  |  | $ | 200,641 |  | $ | — |  | $ | 119,073 |  | $ | — |  |
| Trading investments for deferred compensation plan: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 3,139 |  | $ | — |  | $ | 4,220 |  | $ | — |  |
| Mutual funds |  |  | 13,472 |  |  | — |  |  | 11,379 |  |  | — |  |
|  |  | $ | 16,611 |  | $ | — |  | $ | 15,599 |  | $ | — |  |
| Foreign exchange derivative assets |  | $ | — |  | $ | 155 |  | $ | — |  | $ | 1,197 |  |
| Foreign exchange derivative liabilities |  | $ | — |  | $ | 701 |  | $ | — |  | $ | 707 |  |

[0001047469-14-009167:notes:210]
The following table presents the changes in the Company's Level 3 financial assets during fiscal years 2013 and 2012 (in thousands):

[0001047469-14-009167:notes:211]
|  |  | Years Ended March 31, |  |
|  |  | 2013 |  | 2012 |  |
| Beginning of the period |  | $ | 429 |  | $ | 1,695 |  |
| Sale of securities |  |  | (917 | ) |  | (6,550 | ) |
| Gain on sale of securities |  |  | 831 |  |  | 6,041 |  |
| Reversal of unrealized gain |  |  | (343 | ) |  | (757 | ) |
| End of the period |  | $ | — |  | $ | 429 |  |

[0001047469-14-009167:notes:212]
There were no significant level 3 financial assets held during fiscal year 2014 by the Company.

[0001047469-14-009167:notes:213]
Cash and Cash Equivalents

[0001047469-14-009167:notes:214]
Cash equivalents consist of bank demand deposits and time deposits. The time deposits have original maturities of three months or less. Cash equivalents are carried at cost, which approximates fair value.

[0001047469-14-009167:notes:215]
Investment Securities

[0001047469-14-009167:notes:216]
The Company's investment securities portfolio consists of marketable securities (money market and mutual funds) related to a deferred compensation plan at March 31, 2014 and 2013.

[0001047469-14-009167:notes:217]
The marketable securities related to the deferred compensation plan are classified as non-current other assets. Since participants in the deferred compensation plan may select the mutual funds in which their compensation deferrals are invested within the confines of the Rabbi Trust which holds the marketable securities, the Company has designated these marketable securities as trading investments, although there is no intent to actively buy and sell securities within the objective of generating profits on short-term differences in market prices. Management has classified the investments as non-current assets because final sale of the investments or realization of proceeds by plan participants is not expected within the Company's normal operating cycle of one year. The marketable securities are recorded at a fair value of $16.6 million and $15.6 million as of March 31, 2014 and 2013, based on quoted market prices. Quoted market prices are observable inputs that are classified as Level 1 within the fair value hierarchy. Earnings, gains and losses on trading investments are included in other income (expense), net. Unrealized trading gains of $0.4 million, $0.5 million and $0.1 million are included in other income (expense), net for the fiscal years 2014, 2013 and 2012, respectively, and relate to trading securities held as of March 31, 2014, 2013 and 2012.

[0001047469-14-009167:notes:218]
Derivative Financial Instruments:    Under the agreements with the respective counterparties to the Company's derivative contracts, subject to applicable requirements, the Company does not net settle transactions with a single net amount payable by one party to the other. In accordance with ASU 2011-11, the Company presents its derivative instruments at gross fair values in the Consolidated Balance Sheets as of March 31, 2014 and 2013.

[0001047469-14-009167:notes:219]
The following table presents the fair values of the Company's derivative instruments and their locations on its consolidated balance sheets as of March 31, 2014 and 2013 (in thousands):

[0001047469-14-009167:notes:220]
|  |  | Derivatives |  |
|  |  | Asset |  | Liability |  |
|  |  | March 31, |  | March 31, |  |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |  |
| Designed as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash flow hedges |  | $ | 4 |  | $ | 1,165 |  | $ | 243 |  | $ | — |  |
| Not designed as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange forward contract |  |  | 23 |  |  | — |  |  | 96 |  |  | 270 |  |
| Foreign exchange swap contract |  |  | 128 |  |  | 32 |  |  | 362 |  |  | 437 |  |
|  |  |  | 151 |  |  | 32 |  |  | 458 |  |  | 707 |  |
|  |  | $ | 155 |  | $ | 1,197 |  | $ | 701 |  | $ | 707 |  |

[0001047469-14-009167:notes:221]
The following table presents the amounts of gains and losses on the Company's derivative instruments for fiscal years 2014, 2013, and 2012 and their locations on its consolidated statements of operations (in thousands):

[0001047469-14-009167:notes:222]
|  |  | Years Ended March 31, |  |
|  |  | Amount of Gain (Loss) Deferred as a Component of Accumulated Other Comprehensive Loss |  | Amount of Gain (Loss) Reclassified from Accumulated Other Comprehensive Loss to Costs of Goods Sold |  | Amount of Gain (Loss) Immediately Recognized in Other Income (Expense), Net |  |
|  |  | 2014 |  | 2013 |  | 2012 |  | 2014 |  | 2013 |  | 2012 |  | 2014 |  | 2013 |  | 2012 |  |
| Designed as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash flow hedges |  | $ | (1,025 | ) | $ | 566 |  | $ | 2,916 |  | $ | 2,472 |  | $ | 1,756 |  | $ | (421 | ) | $ | (126 | ) | $ | 275 |  | $ | (198 | ) |
| Not designed as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange forward contract |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (464 | ) |  | (848 | ) |  | (350 | ) |
| Foreign exchange swap contract |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 1,288 |  |  | 1,176 |  |  | (1,884 | ) |
|  |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 824 |  |  | 328 |  |  | (2,234 | ) |
|  |  | $ | (1,025 | ) | $ | 566 |  | $ | 2,916 |  | $ | 2,472 |  | $ | 1,756 |  | $ | (421 | ) | $ | 698 |  | $ | 603 |  | $ | (2,432 | ) |

[0001047469-14-009167:notes:223]
Cash Flow Hedges

[0001047469-14-009167:notes:224]
The Company enters into foreign exchange forward contracts to hedge against exposure to changes in foreign currency exchange rates related to its subsidiaries' forecasted inventory purchases. The Company has one entity with a Euro functional currency that purchases inventory in U.S. Dollars. The primary risk managed by using derivative instruments is the foreign currency exchange rate risk. The Company has designated these derivatives as cash flow hedges. The Company does not use derivative financial instruments for trading or speculative purposes. These hedging contracts mature within four months, and are denominated in the same currency as the underlying transactions. Gains and losses in the fair value of the effective portion of the hedges are deferred as a component of accumulated other comprehensive loss until the hedged inventory purchases are sold, at which time the gains or losses are reclassified to cost of goods sold. The Company assesses the effectiveness of the hedges by comparing changes in the spot rate of the currency underlying the forward contract with changes in the spot rate of the currency in which the forecasted transaction will be consummated. If the underlying transaction being hedged fails to occur or if a portion of the hedge does not generate offsetting changes in the foreign currency exposure of forecasted inventory purchases, the Company immediately recognizes the gain or loss on the associated financial instrument in other income (expense), net. Such gains and losses were not material during fiscal years 2014, 2013 and 2012. Cash flows from such hedges are classified as operating activities in the Consolidated Statements of Cash Flows. As of March 31, 2014 and 2013, the notional amounts of foreign exchange forward contracts outstanding related to forecasted inventory purchases were $51.8 million (€37.6 million), and $38.5 million (€30.1 million), respectively.

[0001047469-14-009167:notes:225]
Foreign Exchange Forward and Swap Contracts

[0001047469-14-009167:notes:226]
The Company also enters into foreign exchange forward contracts to reduce the short-term effects of foreign currency fluctuations on certain foreign currency receivables or payables. These forward contracts generally mature within three months. The Company may also enter into foreign exchange swap contracts to economically extend the terms of its foreign exchange forward contracts. The primary risk managed by using forward and swap contracts is the foreign currency exchange rate risk. The gains or losses on foreign exchange forward contracts are recognized in other income (expense), net based on the changes in fair value.

[0001047469-14-009167:notes:227]
The notional amounts of foreign exchange forward contracts outstanding as of March 31, 2014 and 2013 relating to foreign currency receivables or payables were $23.2 million and $14.2 million, respectively. Open forward contracts as of March 31, 2014 and 2013 consisted of contracts in U.S. Dollars to purchase Taiwanese Dollars and contracts in Euros to sell British Pounds at future dates at pre-determined exchange rates. The notional amounts of foreign exchange swap contracts outstanding as of March 31, 2014 and 2013 were $30.5 million and $19.6 million, respectively. Swap contracts outstanding as of March 31, 2014 and 2013 consisted of contracts in Mexican Pesos, Japanese Yen and Australian Dollars.

[0001047469-14-009167:notes:228]
The fair value of all foreign exchange forward contracts and foreign exchange swap contracts is determined based on observable market transactions of spot currency rates and forward rates. Cash flows from these contracts are classified as operating activities in the Consolidated Statements of Cash Flows.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001047469-14-009167:notes:229]
Note 10—Goodwill and Other Intangible Assets

[0001047469-14-009167:notes:230]
Annual Goodwill Impairment Testing

[0001047469-14-009167:notes:231]
In accordance with ASC Topic 350-10 ("ASC 350-10") as it relates to Goodwill and Other Intangible Assets, the Company conducts a goodwill impairment analysis annually at December 31 and as necessary if changes in facts and circumstances indicate that it is more likely than not that the fair value of the Company's reporting units may be less than its carrying amount.

[0001047469-14-009167:notes:232]
FASB ASC 350-20 permits an entity to make a qualitative assessment of whether it is more likely than not that a reporting unit's fair value is less than its carrying amount before applying the two-step goodwill impairment test. If an entity concludes that it is not more likely than not that the fair value of a reporting unit is less than its carrying amount, it would not be required to perform the two-step impairment test for that reporting unit.

[0001047469-14-009167:notes:233]
Peripherals

[0001047469-14-009167:notes:234]
The Company performed its annual impairment analysis of the goodwill for its peripherals reporting unit as of December 31, 2013 by performing a qualitative assessment and concluded that it was not more likely than not that the fair value of its peripherals reporting units was less than its carrying amount. In assessing the qualitative factors, the Company considered the impact of these key factors: change in industry and competitive environment, growth in market capitalization of $2.2 billion as of December 31, 2013 from $1.2 billion as of December 31, 2012, and forecasted budgeted-to-actual revenue performance for fiscal year 2014. The peripherals reporting unit had an improvement in operating income from $35 million for the nine months ended December 31, 2012 to $117 million for nine months ended December 31, 2013.

[0001047469-14-009167:notes:235]
Video Conferencing

[0001047469-14-009167:notes:236]
In the quarter ended September 30, 2013, the Company implemented a restructuring plan ("this Plan") associated with its video conferencing reporting unit to simplify its organization, better align costs with its current business and free up resources to pursue growth opportunities. This Plan resulted in the reduction of personnel, lease exit costs and the write-off of discontinued video conferencing products. In addition, actual performance was significantly less than projected results for the periods since the prior annual goodwill impairment assessment performed at December 31, 2012, due to the combination of a changing industry landscape caused by a shift to less expensive cloud-based video conferencing solutions, an evolving Lifesize product line and challenges in execution. These factors resulted in the Company concluding that it was more likely than not that the fair value of its video conferencing reporting unit was less than its carrying amount. Therefore, the Company performed an interim Step 1 assessment of its video conferencing reporting unit at September 30, 2013.

[0001047469-14-009167:notes:237]
Step 1 assessment performed during the quarter ended September 30, 2013 involved measuring the recoverability of goodwill by comparing the video conferencing reporting unit's carrying amount, including goodwill, to the fair value of the reporting unit. The fair value was estimated using both an income approach employing a discounted cash flow model and a market approach. The market approach model was based on applying certain revenue multiples of comparable companies to the respective revenue and earnings metrics of the reporting unit. Step 1 assessment resulted in the Company determining that the video conferencing reporting unit passed Step 1 test because the estimated fair value exceeded its carrying value by approximately 23%, thus not requiring a Step 2 assessment of this reporting unit.

[0001047469-14-009167:notes:238]
At December 31, 2013, the Company completed its annual impairment analysis for the goodwill of the video conferencing reporting unit by performing Step 1 assessment as the qualitative factors that lead to the interim assessment had not significantly improved.

[0001047469-14-009167:notes:239]
Key assumptions used in this Step 1 income approach analysis included the appropriate discount rates, compound annual growth rate ("CAGR") during the forecast period, and long-term growth rates for purposes of determining a terminal value at the end of the discrete forecast period. Sensitivity assessment of key assumptions for the video conferencing reporting unit Step 1 test is presented below:

[0001047469-14-009167:notes:240]
CAGR assumption was 7.0% through fiscal year 2021, with a forecast decline in the remainder of fiscal year 2014, and higher growth rates from fiscal years 2015 through 2019, reducing to a growth rate of 4% in fiscal year 2021. The forecasted growth contrasts with the recent performance of the video conferencing reporting unit, when the Company experienced a decline in revenue (see Note 14 for further details). A hypothetical decrease to 1.4% in the CAGR rate, holding all other assumptions constant, would decrease the fair value of the video conferencing reporting unit below its carrying value and hence would result in the reporting unit failing Step 1 of the goodwill impairment test.

[0001047469-14-009167:notes:241]
Discount rate assumption was 15%. A hypothetical increase to 18.9% in the discount rate, holding all other assumptions constant, would result in the reporting unit failing Step 1 of the goodwill impairment test.

[0001047469-14-009167:notes:242]
Terminal growth rate assumption was 4%. A hypothetical decrease to 0% in the terminal growth rate assumption, holding all other assumptions constant, would result in the reporting unit passing Step 1 of the goodwill impairment test.

[0001047469-14-009167:notes:243]
The assumptions used also included a reduction in future operating expenses as a percentage of revenue, driven by increases in forecast revenue as described above, combined with reduced operating expenses related to the fourth quarter of fiscal year 2013 and second quarter of fiscal year 2014 restructuring activities.

[0001047469-14-009167:notes:244]
The annual Step 1 assessment resulted in the Company determining that the video conferencing reporting unit passed Step 1 test because the estimated fair value exceeded its carrying value by approximately 30%, thus not requiring Step 2 assessment of this reporting unit. This result presents a future video conferencing reporting unit goodwill impairment risk to the Company since the margin it cleared the current Step 1 assessment was not significant.

[0001047469-14-009167:notes:245]
As a result of the Company's annual goodwill impairment assessments, there was no impairment of goodwill during the three months ended December 31, 2013. There have been no events or circumstances during the three months ended March 31, 2014 that have required the Company to perform an interim assessment of goodwill.

[0001047469-14-009167:notes:246]
During fiscal year 2013, the Company's video conferencing reporting unit failed Step 1 test because the estimated fair value was less than its carrying value, thus requiring Step 2 assessment of this reporting unit. This impairment primarily resulted from a decrease in the expected CAGR during the assessment forecast period based on greater evidence of the overall enterprise video conferencing industry experiencing a slowdown, combined with lower demand related to new product launches, increased competition during fiscal year 2013 and other market data. These factors had an adverse effect on the Company's video conferencing operating results and future outlook. During fiscal year 2013, the Company recorded goodwill impairment and other charges of $214.5 million related to its video conferencing reporting unit.

[0001047469-14-009167:notes:247]
Determining the fair value of a reporting unit is judgmental in nature and requires the use of significant estimates and assumptions, including revenue growth rates, operating margins, discount rates and future market conditions, among others. It is reasonably possible that changes in the judgments, assumptions and estimates that the Company used in assessing the fair value of the video conferencing reporting unit result in the goodwill to become impaired. A goodwill impairment charge would have the effect of decreasing the Company's earnings or increasing its losses in such period. If the Company is required to take a substantial impairment charge, its operating results would be materially and adversely affected in such period.

[0001047469-14-009167:notes:248]
The following table summarizes the activity in the Company's goodwill balance during fiscal years 2014 and 2013 (in thousands):

[0001047469-14-009167:notes:249]
|  |  | Years Ended March 31, |  |
|  |  | 2014 |  | 2013 |  |
|  |  | Peripherals |  | Video Conferencing |  | Total |  | Peripherals |  | Video Conferencing |  | Total |  |
| Beginning of the period |  | $ | 216,744 |  | $ | 124,613 |  | $ | 341,357 |  | $ | 220,860 |  | $ | 339,663 |  | $ | 560,523 |  |
| Additions |  |  | 202 |  |  | — |  |  | 202 |  |  | — |  |  | — |  |  | — |  |
| Foreign currency impact |  |  | — |  |  | 982 |  |  | 982 |  |  | — |  |  | (550 | ) |  | (550 | ) |
| Impairments |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (214,500 | ) |  | (214,500 | ) |
| Reclassified from (to) assets held for sale(1) |  |  | 2,469 |  |  | — |  |  | 2,469 |  |  | (4,116 | ) |  | — |  |  | (4,116 | ) |
| End of the period |  | $ | 219,415 |  | $ | 125,595 |  | $ | 345,010 |  | $ | 216,744 |  | $ | 124,613 |  | $ | 341,357 |  |

[0001047469-14-009167:notes:250]
Represents allocated goodwill related to the Company's Retail—Digital Video Security product line and Retail—Remotes product category which was classified as assets held for sale as of March 31, 2013. The allocated goodwill related to the Digital Video Security product line was fully impaired as of March 31, 2013. The allocated goodwill related to the Remotes product category was reclassified from assets held for sale as of March 31, 2014, as the Company updated its strategic plan and decided to retain its Remotes product category.

[0001047469-14-009167:notes:251]
The Company's acquired other intangible assets subject to amortization were as follows (in thousands):

[0001047469-14-009167:notes:252]
|  |  | March 31, |  |
|  |  | 2014 |  | 2013 |  |
|  |  | Gross |  | Accumulated Amortization |  | Net |  | Gross(1) |  | Accumulated Amortization(2) |  | Net |  |
| Trademark and tradenames |  | $ | 13,091 |  | $ | (11,949 | ) | $ | 1,142 |  | $ | 13,977 |  | $ | (10,693 | ) | $ | 3,284 |  |
| Technology(1) |  |  | 83,080 |  |  | (78,257 | ) |  | 4,823 |  |  | 73,249 |  |  | (61,560 | ) |  | 11,689 |  |
| Customer contracts |  |  | 38,851 |  |  | (34,287 | ) |  | 4,564 |  |  | 39,068 |  |  | (28,017 | ) |  | 11,051 |  |
|  |  | $ | 135,022 |  | $ | (124,493 | ) | $ | 10,529 |  | $ | 126,294 |  | $ | (100,270 | ) | $ | 26,024 |  |

[0001047469-14-009167:notes:253]
As of March 31, 2013, the Company had $1.7 million of intangible assets, net of accumulated amortization of $19.3 million and impairment charges of $0.5 million, related to Digital Video Security and Remotes product categories classified as held for sale, which are not included in the table above. As of March 31, 2014, the Remotes product category was reclassified from held for sale as the Company updated its strategic plan and decided to retain the Remotes product category. There were no intangible assets classified as held for sale as of March 31, 2014.

[0001047469-14-009167:notes:254]
During fiscal year 2014, the Company determined that the trademarks and trade names gross and accumulated amortization amounts previously reported for fiscal year 2013 were not properly stated due to the inclusion of $15.9 million of fully amortized intangible assets, which were previously retired by the Company as of March 31, 2013. The table above is revised to reflect the correct amounts.

[0001047469-14-009167:notes:255]
For fiscal years 2014, 2013 and 2012, amortization expense for other intangible assets was $17.8 million, $23.6 million and $27.2 million, respectively. The Company expects that annual amortization expense for the fiscal years ending 2015, 2016 and 2017 will be $8.4 million, $1.9 million and $0.2 million, respectively.


## us-gaap:DebtDisclosureTextBlock

[0001047469-14-009167:notes:256]
Note 11—Financing Arrangements

[0001047469-14-009167:notes:257]
In December 2011, the Company entered into a Senior Revolving Credit Facility Agreement ("Credit Facility") with a group of primarily Swiss banks that provided for a revolving multicurrency unsecured credit facility in an amount of up to $250.0 million and subject to certain requirements, permitted the Company to arrange with existing or new lenders to provide up to an aggregate of $150.0 million in additional commitments, for a total of $400.0 million. The Company also paid a quarterly commitment fee of 40% of the applicable margin on the available commitment. In December 2013, given the significant improvement in our financial performance and outlook, the Company chose to terminate this Credit Facility and wrote-off the amortized loan fees totaling $ 1.0 million. There were no outstanding borrowings at the time of termination.

[0001047469-14-009167:notes:258]
The Company had several uncommitted, unsecured bank lines of credit aggregating $40.0 million as of March 31, 2014. There are no financial covenants under these lines of credit with which the Company must comply. As of March 31, 2014, the Company had outstanding bank guarantees of $7.1 million under these lines of credit. The Company also had credit lines related to corporate credit cards totaling $6.9 million as of March 31, 2014. There are no financial covenants under these credit lines.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001047469-14-009167:notes:259]
Note 12—Commitments and Contingencies

[0001047469-14-009167:notes:260]
Operating Leases

[0001047469-14-009167:notes:261]
The Company leases facilities under operating leases, certain of which require it to pay property taxes, insurance and maintenance costs. Operating leases for facilities are generally renewable at the Company's option and usually include escalation clauses linked to inflation. Future minimum annual rentals under non-cancelable operating leases at March 31, 2014 are as follows (in thousands):

[0001047469-14-009167:notes:262]
| Years Ending March 31, |  |  |  |
| 2015 |  | $ | 17,022 |  |
| 2016 |  |  | 13,950 |  |
| 2017 |  |  | 10,454 |  |
| 2018 |  |  | 8,543 |  |
| 2019 |  |  | 7,172 |  |
| Thereafter |  |  | 20,808 |  |
|  |  | $ | 77,949 |  |

[0001047469-14-009167:notes:263]
Rent expense for fiscal years 2014, 2013 and 2012 was $14.7 million, $25.3 million and $25.1 million, respectively.

[0001047469-14-009167:notes:264]
In connection with its leased facilities, the Company has recognized a liability for asset retirement obligations for 2014 and 2013 representing the present value of estimated remediation costs to be incurred at lease expiration. The liability and the expense for asset retirement obligations were immaterial for fiscal years 2014, 2013, and 2012.

[0001047469-14-009167:notes:265]
Product Warranties

[0001047469-14-009167:notes:266]
All of the Company's Peripherals products are covered by warranty to be free from defects in material and workmanship for periods ranging from one year to five years. At the time of sale, the Company accrues a warranty liability for estimated costs to provide products, parts or services to repair or replace products in satisfaction of the warranty obligation. The Company's estimate of costs to fulfill its warranty obligations is based on historical experience and expectations of future conditions. When the Company experiences changes in warranty claim activity or costs associated with fulfilling those claims, the warranty liability is adjusted accordingly.

[0001047469-14-009167:notes:267]
Changes in the Company's warranty liability for fiscal years 2014 and 2013 were as follows (in thousands):

[0001047469-14-009167:notes:268]
|  |  | Years Ended March 31, |  |
|  |  | 2014 |  | 2013 |  |
|  |  |  |  | As revised |  |
| Beginning of the period |  | $ | 21,442 |  | $ | 26,618 |  |
| Provision |  |  | 15,817 |  |  | 12,879 |  |
| Settlements |  |  | (15,206 | ) |  | (15,728 | ) |
| Adjustment(1) |  |  | 2,327 |  |  | (2,327 | ) |
| End of the period |  | $ | 24,380 |  | $ | 21,442 |  |

[0001047469-14-009167:notes:269]
During fiscal year 2014, the warranty liability allocated to the Company's Remotes product category was reclassified from liabilities held for sale.

[0001047469-14-009167:notes:270]
Deferred Services Revenue

[0001047469-14-009167:notes:271]
The Company's video conferencing reporting unit offers maintenance contracts for sale of the majority of its products which allow for customers to receive service and support in addition to the expiration of the product warranty contractual term. The Company also provides installation services to its customer under contractual arrangements. The Company recognizes these contracts over the life of the service period.

[0001047469-14-009167:notes:272]
Change in the Company's deferred services revenue during fiscal years 2014 and 2013 were as follows (in thousands):

[0001047469-14-009167:notes:273]
|  |  | Years Ended March 31, |  |
|  |  | 2014 |  | 2013 |  |
| Beginning of the period |  | $ | 29,327 |  | $ | 24,568 |  |
| Extended warranties issued |  |  | 33,007 |  |  | 34,069 |  |
| Amortization |  |  | (32,174 | ) |  | (29,310 | ) |
| End of the period |  | $ | 30,160 |  | $ | 29,327 |  |

[0001047469-14-009167:notes:274]
The cost of providing these services for fiscal years 2014 and 2013 was $7.8 million and $8.5 million, respectively.

[0001047469-14-009167:notes:275]
Purchase Commitments

[0001047469-14-009167:notes:276]
As of March 31, 2014, the Company had the following outstanding purchase commitments:

[0001047469-14-009167:notes:277]
| Inventory commitments |  | $ | 102,760 |  |
| Operating expenses |  |  | 45,969 |  |
| Capital commitments |  |  | 12,994 |  |
| Total purchase commitments |  | $ | 161,723 |  |

[0001047469-14-009167:notes:278]
Commitments for inventory purchases are made in the normal course of business to original design manufacturers, contract manufacturers and other suppliers and are expected to be fulfilled by June 30, 2014. Operating expense commitments are for consulting services, marketing arrangements, advertising, outsourced customer services, information technology maintenance and support services, and other services. Fixed purchase commitments for capital expenditures primarily related to commitments for computer hardware and leasehold improvements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the Company the option to reschedule and adjust its requirements based on the business needs prior to delivery of goods or performance of services.

[0001047469-14-009167:notes:279]
Other Contingencies

[0001047469-14-009167:notes:280]
As previously announced, some of the issues reviewed by the Audit Committee are also the subject of an ongoing formal investigation by the SEC, including the accounting for Revue inventory valuation reserves that resulted in the restatement, revision to the Company's financial statements concerning warranty accruals and amortization of intangible assets presented in our Form 10-K/A, filed on August 7, 2013, and the Company's transactions with a distributor for Fiscal Year 2007 through Fiscal Year 2009. The Company is cooperating with the SEC in its ongoing investigation. The Company has entered into an agreement with the SEC to extend the statute of limitations. The Company cannot predict the outcome of the investigation at this time and any potential fines or penalties, if any, that may arise from the investigation are currently not estimable.

[0001047469-14-009167:notes:281]
Guarantees

[0001047469-14-009167:notes:282]
Logitech International S.A., the parent holding company, has issued several parent guarantees on behalf of its subsidiaries. The maximum potential future payment under the guarantee arrangements is limited to $80.0 million. As of March 31, 2014, there were no purchase obligations outstanding for which the parent holding company was required to guarantee payment.

[0001047469-14-009167:notes:283]
Logitech Europe S.A., a subsidiary of the parent holding company, has guaranteed the purchase obligations of another Logitech subsidiary under a guarantee agreement. This guarantee does not specify a maximum amount. As of March 31, 2014, the amount of purchase obligations outstanding under this guarantee was immaterial. In addition, Logitech Europe S.A. also guaranteed payments of a third-party contract manufacturer's purchase obligations. As of March 31, 2014, the maximum amount of this guarantee was $3.5 million, of which $2.3 million of guaranteed purchase obligations were outstanding.

[0001047469-14-009167:notes:284]
Indemnifications

[0001047469-14-009167:notes:285]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys' fees. As of March 31, 2014, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

[0001047469-14-009167:notes:286]
The Company also indemnifies its current and former directors and certain of its current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. The Company is unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not limited, the obligations are conditional in nature and the facts and circumstances involved in any situation that might arise are variable.

[0001047469-14-009167:notes:287]
Legal Proceedings

[0001047469-14-009167:notes:288]
From time to time the Company is involved in claims and legal proceedings which arise in the ordinary course of its business. The Company is currently subject to several such claims and a small number of legal proceedings. The Company believes that these matters lack merit and intends to vigorously defend against them. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company's defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company's business, financial condition, cash flows and results of operations in a particular period. Any claims or proceedings against the Company, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company's business.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001047469-14-009167:notes:289]
Note 13—Shareholders' Equity

[0001047469-14-009167:notes:290]
Share Capital

[0001047469-14-009167:notes:291]
The Company's nominal share capital is CHF 43,276,655, consisting of 173,106,620 shares with a par value of CHF 0.25 each, all of which were issued and 10,206,450 which were held in treasury as of March 31, 2014.

[0001047469-14-009167:notes:292]
In September 2008, the Company's shareholders approved an amendment to reserve conditional capital of 25,000,000 shares for potential issuance on the exercise of rights granted under the Company's employee equity incentive plans. The shareholders also approved the creation of conditional capital representing the issuance of up to 25,000,000 shares to cover any conversion rights under a future convertible bond issuance. This conditional capital was created in order to provide financing flexibility for future expansion, investments or acquisitions.

[0001047469-14-009167:notes:293]
Shares Outstanding

[0001047469-14-009167:notes:294]
In September 2012, the Company's shareholders approved the cancellation of the 18.5 million shares repurchased under the September 2008 amended share buyback program. These shares were legally cancelled during fiscal year 2013, which decreased the treasury shares outstanding by this amount but also decreased its shares issued and outstanding from 191.6 million to 173.1 million.

[0001047469-14-009167:notes:295]
Dividends

[0001047469-14-009167:notes:296]
Pursuant to Swiss corporate law, Logitech International S.A. may only pay dividends in Swiss francs. The payment of dividends is limited to certain amounts of unappropriated retained earnings (CHF 458.5 million or $518.1 million based on exchange rates at March 31, 2014) and is subject to shareholder approval. In September 2013, Logitech's shareholders approved a cash dividend payment of CHF 33.7 million out of retained earnings to Logitech shareholders. Eligible shareholders were paid CHF 0.21 per share ($0.22 per share in U.S. dollars), totaling $36.1 million in U.S. Dollars in September 2013. In September 2012, the Company's shareholders approved a cash dividend of CHF 125.7 million out of retained earnings to Logitech shareholders. Eligible shareholders were paid CHF 0.79 per share ($0.85 per share in U.S. dollars), totaling $133.5 million in U.S. dollars in September 2012. This dividend qualified as a distribution of qualifying additional paid-in-capital and, as such, was not subject to Swiss Federal withholding tax.

[0001047469-14-009167:notes:297]
Legal Reserves

[0001047469-14-009167:notes:298]
Under Swiss corporate law, a minimum of 5% of the Company's annual net income must be retained in a legal reserve until this legal reserve equals 20% of the Company's issued and outstanding aggregate par value per share capital. These legal reserves represent an appropriation of retained earnings that are not available for distribution and totaled $10.8 million at March 31, 2014 (based on exchange rates at March 31, 2014).

[0001047469-14-009167:notes:299]
Additionally, under Swiss corporate law, the Company is required to establish a reserve equal to the cost of repurchased treasury shares owned as of year-end. The reserve for treasury shares, which is not available for distribution, totaled $118.4 million at March 31, 2014 (based on exchange rates at March 31, 2014).

[0001047469-14-009167:notes:300]
Share Repurchases

[0001047469-14-009167:notes:301]
In March 2014, the Company's Board of Directors approved the 2014 share buyback program, which authorizes the Company to use up to $250.0 million to purchase its own shares. The Company's share buyback program is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Purchases may be started or stopped at any time without prior notice depending on market conditions and other factors.

[0001047469-14-009167:notes:302]
In September 2008, the Company's Board of Directors approved the September 2008 share buyback program for $250.0 million. In November 2011, an amendment to the September 2008 share buyback program ("September 2008—amended") was approved by the Company's Board of Directors to enable future purchases of shares for cancellation. In August 2013, the September 2008 share buyback and September 2008—amended share buyback programs expired.

[0001047469-14-009167:notes:303]
A summary of the approved share buyback programs are shown in the following table (in thousands, excluding transaction costs).

[0001047469-14-009167:notes:304]
|  |  | Approved |  | Repurchased |  |
| Share Buyback Program |  | Shares |  | Amounts |  | Shares |  | Amounts |  |
| March 2014 |  |  | 17,311 |  | $ | 250,000 |  |  | — |  |  | — |  |
| September 2008—amended(1) |  |  | 28,465 |  |  | 177,030 |  |  | 18,500 |  | $ | 170,714 |  |
| September 2008(1) |  |  | 8,344 |  |  | 250,000 |  |  | 7,609 |  |  | 73,134 |  |
|  |  |  | 54,120 |  | $ | 677,030 |  |  | 26,109 |  | $ | 243,848 |  |

[0001047469-14-009167:notes:305]
Expired in August 2013

[0001047469-14-009167:notes:306]
During fiscal year 2013, 8.6 million shares were repurchased for $87.8 million and during fiscal year 2012, 17.5 million shares were repurchased for $156.0 million. There were no share repurchases during fiscal year 2014. During fiscal year 2013, 18.5 million of the repurchased shares were cancelled.

[0001047469-14-009167:notes:307]
Accumulated Other Comprehensive Income (Loss)

[0001047469-14-009167:notes:308]
The components of accumulated other comprehensive income (loss) were as follows (in thousands):

[0001047469-14-009167:notes:309]
|  |  | Accumulated Other Comprehensive Income (Loss) |  |
|  |  | Cumulative Translation Adjustment |  | Defined Benefit Plan(1) |  | Deferred Hedging Gains (Losses) |  | Total |  |
| March 31, 2013 (As Revised) |  | $ | (73,783 | ) | $ | (21,856 | ) | $ | 510 |  | $ | (95,129 | ) |
| Other comprehensive income (loss) |  |  | 2,784 |  |  | 7,568 |  |  | (1,025 | ) |  | 9,327 |  |
| March 31, 2014 |  | $ | (70,999 | ) | $ | (14,288 | ) | $ | (515 | ) | $ | (85,802 | ) |

[0001047469-14-009167:notes:310]
Net of tax of $192 as of March 31, 2014 and $315 as of March 31, 2013.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001047469-14-009167:notes:311]
Note 14—Segment Information

[0001047469-14-009167:notes:312]
The Company has two reporting segments, peripherals and video conferencing, based on product markets and internal organizational structure. The peripherals segment encompasses the design, manufacturing and marketing of peripherals for PCs, tablets and other digital platforms. The video conferencing segment encompasses the design, manufacturing and marketing of Lifesize video conferencing products, infrastructure and services for the enterprise, public sector and other business markets. The Company's reporting segments do not record revenue on sales between segments as such sales are not material.

[0001047469-14-009167:notes:313]
Operating performance measures for the peripherals segment and the video conferencing segment are reported separately to Logitech's Chief Executive Officer ("CEO"), who is considered to be the Company's Chief Operating Decision Maker ("CODM"). The CEO periodically reviews information such as net sales and operating income (loss) for each operating segment to make business decisions. These operating performance measures do not include share-based compensation expense and amortization of intangible assets. Share-based compensation expense and amortization of intangible assets are presented in the following financial information by operating segment as "other income (expense)." Assets by operating segment are not presented since the Company does not present such data to the CODM.

[0001047469-14-009167:notes:314]
Net sales and operating income (loss) for the Company's operating segments were as follows (in thousands):

[0001047469-14-009167:notes:315]
|  |  | Years Ended March 31, |  |
|  |  | 2014 |  | 2013 |  | 2012 |  |
|  |  |  |  | As Revised |  | As Restated |  |
| Net sales: |  |  |  |  |  |  |  |  |  |  |
| Peripherals |  | $ | 2,008,028 |  | $ | 1,962,237 |  | $ | 2,168,742 |  |
| Video conferencing |  |  | 120,685 |  |  | 137,040 |  |  | 147,461 |  |
|  |  | $ | 2,128,713 |  | $ | 2,099,277 |  | $ | 2,316,203 |  |
| Segment operating income (loss): |  |  |  |  |  |  |  |  |  |  |
| Peripherals(1) |  | $ | 131,326 |  | $ | 25,829 |  | $ | 180,167 |  |
| Video conferencing(1) |  |  | (12,023 | ) |  | (229,097 | ) |  | (7,442 | ) |
|  |  |  | 119,303 |  |  | (203,268 | ) |  | 172,725 |  |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation |  |  | (25,546 | ) |  | (25,198 | ) |  | (31,529 | ) |
| Amortization of intangibles |  |  | (17,771 | ) |  | (23,571 | ) |  | (27,198 | ) |
| Interest income (expense), net |  |  | (397 | ) |  | 907 |  |  | 2,674 |  |
| Other income (expense), net |  |  | 1,993 |  |  | (2,198 | ) |  | 7,655 |  |
| Income (loss) before income taxes |  | $ | 77,582 |  | $ | (253,328 | ) | $ | 124,327 |  |

[0001047469-14-009167:notes:316]
Peripherals operating results include $8.0 million, $39.5 million, and $0 of restructuring charges during fiscal year 2014, 2013, and 2012 respectively and $2.2 million of impairment of other assets during fiscal year 2013. Video Conferencing operating results include $5.8 million, $4.2 million, and $0 of restructuring charges for fiscal year 2014, 2013, and 2012 respectively and $214.5 million of goodwill impairment charge for fiscal year 2013.

[0001047469-14-009167:notes:317]
Net sales by product categories, excluding intercompany transactions, were as follows (in thousands):

[0001047469-14-009167:notes:318]
|  |  | Years Ended March 31, |  |
|  |  | 2014 |  | 2013(1) |  | 2012(1) |  |
|  |  |  |  | As Revised |  |  |  |
| Peripherals: |  |  |  |  |  |  |  |  |  |  |
| PC Gaming |  | $ | 186,926 |  | $ | 144,512 |  | $ | 186,190 |  |
| Tablet & Other Accessories |  |  | 172,484 |  |  | 119,856 |  |  | 44,326 |  |
| Mobile Speakers |  |  | 87,414 |  |  | 33,408 |  |  | 21,969 |  |
| Growth: |  |  | 446,824 |  |  | 297,776 |  |  | 252,485 |  |
| Pointing Devices |  |  | 506,884 |  |  | 521,083 |  |  | 559,366 |  |
| PC Keyboards & Desktops |  |  | 415,512 |  |  | 399,144 |  |  | 383,697 |  |
| Audio-PC &Wearables |  |  | 255,573 |  |  | 292,245 |  |  | 339,394 |  |
| Video |  |  | 137,115 |  |  | 153,060 |  |  | 196,662 |  |
| Remotes |  |  | 67,371 |  |  | 71,641 |  |  | 91,000 |  |
| Profit Maximization: |  |  | 1,382,455 |  |  | 1,437,173 |  |  | 1,570,119 |  |
| Other |  |  | 37,000 |  |  | 86,102 |  |  | 160,179 |  |
| Non-Strategic: |  |  | 37,000 |  |  | 86,102 |  |  | 160,179 |  |
| OEM |  |  | 141,749 |  |  | 141,186 |  |  | 185,959 |  |
|  |  |  | 2,008,028 |  |  | 1,962,237 |  |  | 2,168,742 |  |
| Video conferencing |  |  | 120,685 |  |  | 137,040 |  |  | 147,461 |  |
|  |  | $ | 2,128,713 |  | $ | 2,099,277 |  | $ | 2,316,203 |  |

[0001047469-14-009167:notes:319]
Certain products within the retail product families presented in prior years have been reclassified to conform to the current year presentation.

[0001047469-14-009167:notes:320]
Geographic net sales information in the table below is based on the customers' location. Long-lived assets, primarily fixed assets, are reported below based on the location of the asset.

[0001047469-14-009167:notes:321]
Net sales to unaffiliated customers by geographic region for fiscal years 2014, 2013 and 2012 (based on the customers' location) were as follows (in thousands):

[0001047469-14-009167:notes:322]
|  |  | Years Ended March 31, |  |
|  |  | 2014 |  | 2013 |  | 2012 |  |
|  |  |  |  | As Revised |  |  |  |
| Americas |  | $ | 859,893 |  | $ | 808,618 |  | $ | 879,076 |  |
| EMEA |  |  | 767,017 |  |  | 799,075 |  |  | 897,557 |  |
| Asia Pacific |  |  | 501,803 |  |  | 491,584 |  |  | 539,570 |  |
|  |  | $ | 2,128,713 |  | $ | 2,099,277 |  | $ | 2,316,203 |  |

[0001047469-14-009167:notes:323]
Net sales are attributed to countries on the basis of the customers' locations. The United States represented 35%, 33% and 34% of net sales for the fiscal years 2014, 2013 and 2012, respectively. No other single country represented more than 10% of net sales during these periods. Revenues from net sales to customers in Switzerland, the Company's home domicile, represented 2% of net sales for fiscal years 2014, 2013 and 2012. In fiscal years 2014, 2013 and 2012, one customer in the peripherals operating segment represented 14%, 11% and 14% of net sales, respectively. As of March 31, 2014 and 2013, one customer in the peripherals operating segment represented 14% of total accounts receivable.

[0001047469-14-009167:notes:324]
Long-lived assets by geographic region were as follows (in thousands):

[0001047469-14-009167:notes:325]
|  |  | March 31, |  |
|  |  | 2014 |  | 2013 |  |
|  |  |  |  | As Revised |  |
| Americas |  | $ | 45,166 |  | $ | 45,518 |  |
| EMEA |  |  | 5,154 |  |  | 8,093 |  |
| Asia Pacific |  |  | 38,071 |  |  | 40,110 |  |
|  |  | $ | 88,391 |  | $ | 93,721 |  |

[0001047469-14-009167:notes:326]
Long-lived assets in the United States and China was $44.9 million and $31.9 million at March 31, 2014, respectively, and $45.5 million and $32.2 million at March 31, 2013, respectively. No other countries represented more than 10% of the Company's total consolidated long-lived assets at March 31, 2014 and 2013. Long-lived assets in Switzerland, the Company's home domicile, were $1.6 million and $3.6 million at March 31, 2014 and 2013.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001047469-14-009167:notes:327]
Note 15—Restructuring

[0001047469-14-009167:notes:328]
The following table summarizes restructuring related activities during fiscal year 2014 and 2013 (in thousands):

[0001047469-14-009167:notes:329]
|  |  | Restructuring |  |
|  |  | Termination Benefits |  | Lease Exit Costs |  | Other |  | Total |  |
| March 31, 2012 |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  |
| Charges |  |  | 41,088 |  |  | 1,308 |  |  | 1,308 |  |  | 43,704 |  |
| Cash payments |  |  | (27,768 | ) |  | (1,233 | ) |  | (1,322 | ) |  | (30,323 | ) |
| Foreign exchange impact |  |  | 63 |  |  | — |  |  | 14 |  |  | 77 |  |
| March 31, 2013 |  |  | 13,383 |  |  | 75 |  |  | — |  |  | 13,458 |  |
| Charges |  |  | 6,463 |  |  | 7,348 |  |  | — |  |  | 13,811 |  |
| Adjustment for deferred rent |  |  | — |  |  | 1,450 |  |  | — |  |  | 1,450 |  |
| Cash payments |  |  | (19,534 | ) |  | (1,454 | ) |  | — |  |  | (20,988 | ) |
| Foreign exchange impact |  |  | (170 | ) |  | — |  |  | — |  |  | (170 | ) |
| March 31, 2014 |  | $ | 142 |  | $ | 7,419 |  | $ | — |  | $ | 7,561 |  |

[0001047469-14-009167:notes:330]
During the second quarter of fiscal year 2014, the Company implemented a restructuring plan solely affecting its video conferencing operating segment to align its organization to its strategic priorities of increasing focus on a tighter range of products, expanding cloud-based video conferencing services and improving profitability. Restructuring charges under this plan primarily consist of severance and other one-time termination benefits. During fiscal year 2014, restructuring charges under this plan included $5.0 million in termination benefits and $0.6 million in lease exit costs. The Company substantially completed this restructuring plan by March 31, 2014.

[0001047469-14-009167:notes:331]
During the fourth quarter of fiscal year 2013, the Company implemented a restructuring plan to align its organization to its strategic priorities of increasing focus on mobility products, improving profitability in PC-related products and enhancing global operational efficiencies. As part of this restructuring plan, the Company reduced its worldwide non-direct labor workforce. Restructuring charges under this plan primarily consisted of severance and other one-time termination benefits. During fiscal year 2014, restructuring charges under this plan included $1.5 million in termination benefits and $6.7 million in lease exit costs, $5.4 million of which pertains to the consolidation of the Company's Silicon Valley campus from two buildings down to one during the quarter ended March 31, 2014. During fiscal year 2013, restructuring charges under this plan included $15.2 million in termination benefits. In addition, charges of $0.9 million related to the discontinuance of certain product development efforts were included in cost of goods sold and a $1.2 million charge from the re-measurement of its Swiss and Taiwan defined benefit pension plans caused by the number of plan participants affected by this restructuring, which was not included in the restructuring charges since it related to prior services. The Company substantially completed this restructuring plan by the fourth quarter of fiscal year 2014.

[0001047469-14-009167:notes:332]
During the first quarter of fiscal year 2013, the Company implemented a restructuring plan to simplify its organization, better align its costs with its current business and to free up resources to pursue growth opportunities. A majority of the restructuring activity was completed during the first quarter of fiscal year 2013. As part of this restructuring plan, the Company reduced its worldwide non-direct labor workforce. During fiscal year 2013, restructuring charges under this plan included $25.9 million in termination benefits, $1.3 million in legal, consulting, and other costs as a result of the terminations, and $1.3 million in lease exit costs associated with the closure of existing facilities. Termination benefits are calculated based on regional benefit practices and local statutory requirements. In addition, charges of $3.0 million related to the discontinuance of certain product development efforts were included in cost of goods sold and a $2.2 million charge from the re-measurement of its Swiss defined benefit pension plan caused by the number of plan participants affected by this restructuring, which was not included in the restructuring charges since it related to prior services. The Company substantially completed this restructuring plan by the fourth quarter of fiscal year 2013.

[0001047469-14-009167:notes:333]
Termination benefits were calculated based on regional benefit practices and local statutory requirements. Lease exit costs primarily relate to costs associated with the closure of existing facilities. Other charges primarily consist of legal, consulting and other costs related to employee terminations.


## logi:ScheduleOfErrorCorrectionsAndPriorPeriodAdjustmentsConsolidatedStatementsOfOperationsTableTextBlock

[0001047469-14-009167:notes:334]
The following table presents the impact of correcting adjustments on the Company's previously-reported consolidated statements of operations for fiscal years 2013 and 2012 (in thousands):

[0001047469-14-009167:notes:335]
|  |  | Year ended March 31, 2013 |  | Year ended March 31, 2012 |  |
|  |  | As Reported |  | Adjustments |  | As Revised |  | As Reported |  | Adjustments |  | As Restated |  |
| Net sales |  | $ | 2,099,883 |  | $ | (606 | )(4) | $ | 2,099,277 |  | $ | 2,316,203 |  | $ | — |  | $ | 2,316,203 |  |
| Cost of goods sold |  |  | 1,389,726 |  |  | — |  |  | 1,389,643 |  |  | 1,537,921 |  |  | (30,730 | )(1) |  | 1,508,670 |  |
|  |  |  |  |  |  | 408 | (2) |  |  |  |  |  |  |  | (25 | )(2) |  |  |  |
|  |  |  |  |  |  | — |  |  |  |  |  |  |  |  | 1,294 | (3) |  |  |  |
|  |  |  |  |  |  | (491 | )(4) |  |  |  |  |  |  |  | 210 | (4) |  |  |  |
| Gross profit |  |  | 710,157 |  |  | (523 | ) |  | 709,634 |  |  | 778,282 |  |  | 29,251 |  |  | 807,533 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketing and selling |  |  | 431,598 |  |  | 396 | (2) |  | 431,886 |  |  | 423,854 |  |  | (24 | )(2) |  | 422,116 |  |
|  |  |  |  |  |  | (108 | )(4) |  |  |  |  |  |  |  | (1,714 | )(4) |  |  |  |
| Research and development |  |  | 154,207 |  |  | 324 | (2) |  | 155,012 |  |  | 162,711 |  |  | (20 | )(2) |  | 162,159 |  |
|  |  |  |  |  |  | 481 | (4) |  |  |  |  |  |  |  | (532 | )(4) |  |  |  |
| General and administrative |  |  | 113,824 |  |  | 214 | (2) |  | 114,381 |  |  | 109,456 |  |  | (13 | )(2) |  | 109,260 |  |
|  |  |  |  |  |  | 343 | (4) |  |  |  |  |  |  |  | (183 | )(4) |  |  |  |
| Impairment of goodwill and other assets |  |  | 216,688 |  |  | — |  |  | 216,688 |  |  | — |  |  | — |  |  | — |  |
| Restructuring charges |  |  | 43,704 |  |  | — |  |  | 43,704 |  |  | — |  |  | — |  |  | — |  |
| Total operating expenses |  |  | 960,021 |  |  | 1,650 |  |  | 961,671 |  |  | 696,021 |  |  | (2,486 | ) |  | 693,535 |  |
| Operating income (loss) |  |  | (249,864 | ) |  | (2,173 | ) |  | (252,037 | ) |  | 82,261 |  |  | 31,737 |  |  | 113,998 |  |
| Interest income, net |  |  | 907 |  |  | — |  |  | 907 |  |  | 2,674 |  |  | — |  |  | 2,674 |  |
| Other income (expense), net |  |  | (2,198 | ) |  | — |  |  | (2,198 | ) |  | 7,655 |  |  | — |  |  | 7,655 |  |
| Income (loss) before income taxes |  |  | (251,155 | ) |  | (2,173 | ) |  | (253,328 | ) |  | 92,590 |  |  | 31,737 |  |  | 124,327 |  |
| Provision for (benefit from) income taxes |  |  | (25,588 | ) |  | (222 | )(4) |  | (25,810 | ) |  | 19,819 |  |  | 271 | (4) |  | 20,090 |  |
| Net income (loss) |  | $ | (225,567 | ) | $ | (1,951 | ) | $ | (227,518 | ) | $ | 72,771 |  | $ | 31,466 |  | $ | 104,237 |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | (1.42 | ) | $ | (0.02 | ) | $ | (1.44 | ) | $ | 0.42 |  | $ | 0.18 |  | $ | 0.60 |  |
| Diluted |  | $ | (1.42 | ) | $ | (0.02 | ) | $ | (1.44 | ) | $ | 0.41 |  | $ | 0.18 |  | $ | 0.59 |  |
| Shares used to compute net income (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 158,468 |  |  | — |  |  | 158,468 |  |  | 174,648 |  |  | — |  |  | 174,648 |  |
| Diluted |  |  | 158,468 |  |  | — |  |  | 158,468 |  |  | 175,591 |  |  | — |  |  | 175,591 |  |
| Cash dividend per share |  | $ | 0.85 |  | $ | — |  | $ | 0.85 |  | $ | — |  | $ | — |  | $ | — |  |


## logi:ScheduleOfErrorCorrectionsAndPriorPeriodAdjustmentsConsolidatedStatementsOfComprehensiveIncomeLossTableTextBlock

[0001047469-14-009167:notes:336]
The following table presents the impact of correcting adjustments on the Company's previously-reported consolidated statements of comprehensive income (loss) for fiscal years 2013 and 2012 (in thousands):

[0001047469-14-009167:notes:337]
|  |  | Year ended March 31, 2013 |  | Year ended March 31, 2012 |  |
|  |  | As Reported |  | Adjustments |  | As Revised |  | As Reported |  | Adjustments |  | As Restated |  |
| Net income (loss) |  | $ | (225,567 | ) | $ | — |  | $ | (227,518 | ) | $ | 72,771 |  | $ | 30,730 | (1) | $ | 104,237 |  |
|  |  |  |  |  |  | (1,342 | )(2) |  |  |  |  |  |  |  | 82 | (2) |  |  |  |
|  |  |  |  |  |  | — |  |  |  |  |  |  |  |  | (1,294 | )(3) |  |  |  |
|  |  |  |  |  |  | (609 | )(4) |  |  |  |  |  |  |  | 1,948 | (4) |  |  |  |
| Other comprehensive income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation loss: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation loss |  |  | (6,333 | ) |  | (48 | )(4) |  | (6,381 | ) |  | (8,213 | ) |  | (19 | )(4) |  | (8,232 | ) |
| Defined benefit pension plans: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net gain (loss) and prior service costs, net of taxes |  |  | 4,794 |  |  | (921 | )(4) |  | 3,873 |  |  | (11,564 | ) |  | 15 | (4) |  | (11,549 | ) |
| Reclass of amortization included in operating expenses |  |  | 4,252 |  |  | (619 | )(4) |  | 3,633 |  |  | 275 |  |  | (15 | )(4) |  | 260 |  |
| Hedging gain (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Unrealized hedging gain (loss) |  |  | (1,190 | ) |  | — |  |  | (1,190 | ) |  | 3,337 |  |  | — |  |  | 3,337 |  |
| Reclass of hedging loss (gain) included in cost of goods sold |  |  | 1,756 |  |  | — |  |  | 1,756 |  |  | (421 | ) |  | — |  |  | (421 | ) |
| Net change in unrealized investment loss: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net unrealized loss on investments for the period |  |  | — |  |  | — |  |  | — |  |  | (342 | ) |  | — |  |  | (342 | ) |
| Reclass of investment gain included in other income (expense), net |  |  | (343 | ) |  | — |  |  | (343 | ) |  | (483 | ) |  | — |  |  | (483 | ) |
| Other comprehensive income (loss): |  |  | 2,936 |  |  | (1,588 | ) |  | 1,348 |  |  | (17,411 | ) |  | (19 | ) |  | (17,430 | ) |
| Total comprehensive income (loss) |  | $ | (222,631 | ) | $ | (3,539 | ) | $ | (226,170 | ) | $ | 55,360 |  | $ | 31,447 |  | $ | 86,807 |  |


## logi:ScheduleOfErrorCorrectionsAndPriorPeriodAdjustmentsConsolidatedBalanceSheetTableTextBlock

[0001047469-14-009167:notes:338]
The following table presents the impact of correcting adjustments on the Company's previously-reported consolidated balance sheet as of March 31, 2013 (in thousands):

[0001047469-14-009167:notes:339]
|  |  | March 31, 2013 |  |
|  |  | As Reported |  | Adjustments |  | As Revised |  |
| ASSETS |  |  |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 333,824 |  | $ | — |  | $ | 333,824 |  |
| Accounts receivable, net |  |  | 179,565 |  |  | (606 | )(4) |  | 178,959 |  |
| Inventories |  |  | 261,083 |  |  | 1,561 | (4) |  | 262,644 |  |
| Other current assets |  |  | 58,103 |  |  | 2,274 | (4) |  | 60,377 |  |
| Asset held for sale |  |  | 10,960 |  |  | — |  |  | 10,960 |  |
| Total current assets |  |  | 843,535 |  |  | 3,229 |  |  | 846,764 |  |
| Non-recurring assets: |  |  |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  |  | 87,649 |  |  | 7,034 | (2) |  | 93,721 |  |
|  |  |  |  |  |  | (962 | )(4) |  |  |  |
| Goodwill |  |  | 341,357 |  |  | — |  |  | 341,357 |  |
| Other intangible assets |  |  | 26,024 |  |  | — |  |  | 26,024 |  |
| Other assets |  |  | 75,098 |  |  | (631 | )(4) |  | 74,467 |  |
| Total assets |  | $ | 1,373,663 |  | $ | 8,670 |  | $ | 1,382,333 |  |
| LIABILITIES AND SHAREHOLDERS' EQUITY |  |  |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 265,995 |  |  | (590 | )(4) |  | 265,405 |  |
| Accrued and other current liabilities |  |  | 192,774 |  |  | 310 | (4) |  | 193,084 |  |
| Liabilities held for sale |  |  | 3,202 |  |  | — |  |  | 3,202 |  |
| Total current liabilities |  |  | 461,971 |  |  | (280 | ) |  | 461,691 |  |
| Non-current liabilities: |  |  |  |  |  |  |  |  |  |  |
| Income taxes payable |  |  | 98,827 |  |  | — |  |  | 98,827 |  |
| Other non-current liabilities |  |  | 97,055 |  |  | 2,807 | (4) |  | 99,862 |  |
| Total liabilities |  | $ | 657,853 |  | $ | 2,527 |  | $ | 660,380 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |  |
| Shareholders' equity: |  |  |  |  |  |  |  |  |  |  |
| Registered shares, CHF 0.25 par value: Issued and authorized shares—173,106 at March 31, 2013 Conditionally authorized shares—50,000 at March 31, 2013 |  | $ | 30,148 |  |  | — |  |  | 30,148 |  |
| Additional paid-in capital |  |  | — |  |  | — |  |  | — |  |
| Less: shares in treasury, at cost—13,855 at March 31, 2013 |  |  | (177,847 | ) |  | (2,143 | )(4) |  | (179,990 | ) |
| Retained earnings |  |  | 956,502 |  |  | 7,034 | (2) |  | 966,924 |  |
|  |  |  |  |  |  | 3,388 | (4) |  |  |  |
| Accumulated other comprehensive loss |  |  | (92,993 | ) |  | (2,136 | )(4) |  | (95,129 | ) |
| Total shareholders' equity |  |  | 715,810 |  |  | 6,143 |  |  | 721,953 |  |
| Total liabilities and shareholders' equity |  | $ | 1,373,663 |  | $ | 8,670 |  | $ | 1,382,333 |  |


## logi:ScheduleOfErrorCorrectionsAndPriorPeriodAdjustmentsConsolidatedStatementsOfCashFlowsTableTextBlock

[0001047469-14-009167:notes:340]
The following table presents the impact of correcting adjustments on the Company's previously-reported consolidated statements of cash flows for fiscal years 2013 and 2012 (in thousands):

[0001047469-14-009167:notes:341]
|  |  | Year ended March 31, 2013 |  | Year ended March 31, 2012 |  |
|  |  | As Reported |  | Adjustments |  | As Revised |  | As Reported |  | Adjustments |  | As Restated |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | (225,567 | ) | $ | — |  | $ | (227,518 | ) | $ | 72,771 |  | $ | 30,730 | (1) | $ | 104,237 |  |
|  |  |  |  |  |  | (1,342 | )(2) |  |  |  |  |  |  |  | 82 | (2) |  |  |  |
|  |  |  |  |  |  | — |  |  |  |  |  |  |  |  | (1,294 | )(3) |  |  |  |
|  |  |  |  |  |  | (609 | )(4) |  |  |  |  |  |  |  | 1,948 | (4) |  |  |  |
| Adjustments to reconcile net income (loss) to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 44,419 |  |  | 6,589 | (2) |  | 51,766 |  |  | 45,968 |  |  | 6,310 | (2) |  | 52,277 |  |
|  |  |  |  |  |  | 758 | (4) |  |  |  |  |  |  |  | (1 | )(4) |  |  |  |
| Amortization of other intangible assets |  |  | 23,571 |  |  | — |  |  | 23,571 |  |  | 27,198 |  |  | — |  |  | 27,198 |  |
| Share-based compensation expense |  |  | 25,198 |  |  | — |  |  | 25,198 |  |  | 31,529 |  |  | — |  |  | 31,529 |  |
| Impairment of goodwill and other assets |  |  | 216,688 |  |  | — |  |  | 216,688 |  |  | — |  |  | — |  |  | — |  |
| Impairment of investments |  |  | 3,600 |  |  | — |  |  | 3,600 |  |  | — |  |  | — |  |  | — |  |
| Loss (gain) on disposal of property, plant and equipment |  |  | — |  |  | 2,007 | (4) |  | 2,007 |  |  | (8,967 | ) |  | 2,434 | (4) |  | (6,533 | ) |
| Gain on sales of available-for-sale securities |  |  | (831 | ) |  | — |  |  | (831 | ) |  | (6,109 | ) |  | — |  |  | (6,109 | ) |
| Inventory valuation adjustment |  |  | — |  |  | — |  |  | — |  |  | 34,074 |  |  | (34,074 | )(1) |  | — |  |
| Excess tax benefits from share-based compensation |  |  | (26 | ) |  | — |  |  | (26 | ) |  | (37 | ) |  | — |  |  | (37 | ) |
| Deferred income taxes and other |  |  | 11,552 |  |  | (14,761 | )(4) |  | (3,209 | ) |  | 137 |  |  | (2,386 | )(4) |  | (2,249 | ) |
| Changes in assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 44,667 |  |  | 606 | (4) |  | 45,273 |  |  | 29,279 |  |  | — |  |  | 29,279 |  |
| Inventories |  |  | 23,954 |  |  | (845 | )(4) |  | 23,109 |  |  | (36,621 | ) |  | 3,344 | (4) |  | (33,277 | ) |
| Other assets |  |  | (1,420 | ) |  | 6,801 | (4) |  | 5,381 |  |  | (4,621 | ) |  | 2,051 | (4) |  | (2,570 | ) |
| Accounts payable |  |  | (34,069 | ) |  | 663 | (4) |  | (33,406 | ) |  | 3,622 |  |  | (295 | )(4) |  | 3,327 |  |
| Accrued and other liabilities |  |  | (14,594 | ) |  | — |  |  | (9,214 | ) |  | 7,919 |  |  | 1,294 | (3) |  | 5,462 |  |
|  |  |  |  |  |  | 5,380 | (4) |  |  |  |  |  |  |  | (3,751 | )(4) |  |  |  |
| Net cash provided by operating activities |  |  | 117,142 |  |  | 5,247 |  |  | 122,389 |  |  | 196,142 |  |  | 6,392 |  |  | 202,534 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (49,240 | ) |  | (5,247 | )(2) |  | (54,487 | ) |  | (47,807 | ) |  | (6,392 | )(2) |  | (54,199 | ) |
| Purchase of strategic investment |  |  | (4,420 | ) |  | — |  |  | (4,420 | ) |  | — |  |  | — |  |  | — |  |
| Acquisitions, net of cash acquired |  |  | — |  |  | — |  |  | — |  |  | (18,814 | ) |  | — |  |  | (18,814 | ) |
| Proceeds from sales of available-for-sale securities |  |  | 917 |  |  | — |  |  | 917 |  |  | 6,550 |  |  | — |  |  | 6,550 |  |
| Proceeds from sales of property and plant |  |  | — |  |  | — |  |  | — |  |  | 8,967 |  |  | — |  |  | 8,967 |  |
| Purchases of trading investments |  |  | (4,196 | ) |  | — |  |  | (4,196 | ) |  | (7,505 | ) |  | — |  |  | (7,505 | ) |
| Proceeds from sales of trading investments |  |  | 4,463 |  |  | — |  |  | 4,463 |  |  | 7,399 |  |  | — |  |  | 7,399 |  |
| Net cash used in investing activities |  |  | (52,476 | ) |  | (5,247 | ) |  | (57,723 | ) |  | (51,210 | ) |  | (6,392 | ) |  | (57,602 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Payment of cash dividends |  |  | (133,462 | ) |  | — |  |  | (133,462 | ) |  | — |  |  | — |  |  | — |  |
| Purchases of treasury shares |  |  | (87,812 | ) |  | — |  |  | (87,812 | ) |  | (156,036 | ) |  | — |  |  | (156,036 | ) |
| Proceeds from sales of shares upon exercise of options and purchase rights |  |  | 15,982 |  |  | — |  |  | 15,982 |  |  | 17,591 |  |  | — |  |  | 17,591 |  |
| Tax withholdings related to net share settlements of restricted stock units |  |  | (2,375 | ) |  | — |  |  | (2,375 | ) |  | (966 | ) |  | — |  |  | (966 | ) |
| Excess tax benefits from share-based compensation |  |  | 26 |  |  | — |  |  | 26 |  |  | 37 |  |  | — |  |  | 37 |  |
| Net cash used in financing activities |  |  | (207,641 | ) |  | — |  |  | (207,641 | ) |  | (139,374 | ) |  | — |  |  | (139,374 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (1,571 | ) |  | — |  |  | (1,571 | ) |  | (5,119 | ) |  | — |  |  | (5,119 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | (144,546 | ) |  | — |  |  | (144,546 | ) |  | 439 |  |  | — |  |  | 439 |  |
| Cash and cash equivalents at beginning of period |  |  | 478,370 |  |  | — |  |  | 478,370 |  |  | 477,931 |  |  | — |  |  | 477,931 |  |
| Cash and cash equivalents at end of period |  | $ | 333,824 |  | $ | — |  | $ | 333,824 |  | $ | 478,370 |  | $ | — |  | $ | 478,370 |  |
| Non-cash investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Property, plant and equipment purchased during the period and included in period end liability accounts |  | $ | 4,828 |  | $ | — |  | $ | 4,828 |  | $ | 5,454 |  | $ | — |  | $ | 5,454 |  |
| Supplemental cash flow information: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest paid |  | $ | 1,293 |  | $ | — |  | $ | 1,293 |  | $ | 110 |  | $ | — |  | $ | 110 |  |
| Income taxes paid, net |  | $ | 14,108 |  | $ | — |  | $ | 14,108 |  | $ | 14,422 |  | $ | — |  | $ | 14,422 |  |


## us-gaap:SubsequentEventsTextBlock

[0001047469-14-009167:notes:342]
Note 16—Subsequent events

[0001047469-14-009167:notes:343]
Repurchase of ESPP Awards

[0001047469-14-009167:notes:344]
The Company was not current with its periodic reports required to be filed with the SEC and was therefore unable to issue any shares under its Registration Statements on Form S-8 after July 31, 2014. Given the proximity of the unavailability of those registration statements and the end of the current ESPP offering period, also on July 31, 2014, the Compensation Committee authorized the termination of the current ESPP offering period and a one-time payment to each participant in an amount equal to the fifteen percent (15%) discount at which shares would otherwise have been repurchased pursuant to the current period of the ESPPs. This one-time payment was accounted for as a repurchase of equity awards that reduced additional paid-in capital, resulting in no additional compensation cost. Given the unavailability of the Company's Registration Statements on Form S-8, no new ESPP offering periods were initiated since July 31, 2014.

[0001047469-14-009167:notes:345]
Dividend

[0001047469-14-009167:notes:346]
On November 12, 2014, the Board approved, subject to approval by the Company's shareholders and other Swiss statutory requirements, a dividend of CHF 0.2625 per share.


## us-gaap:AccountingChangesAndErrorCorrectionsTextBlock

[0001047469-14-009167:notes:347]
Note 2—Restatement and Revision of Previously Issued Consolidated Financial Statements

[0001047469-14-009167:notes:348]
As the Company announced on May 21, 2014, the Audit Committee, with the assistance of independent advisors, began an independent investigation of certain accounting matters related to the Company's previously issued financial statements.

[0001047469-14-009167:notes:349]
On September 3, 2014, the Company announced that, in connection with this investigation, the Audit Committee, on the recommendation of management, concluded that the Company's previously issued financial statements for fiscal years 2011 and 2012 and the first quarter of fiscal year 2012 could no longer be relied on due to an accounting misstatement for inventory valuation reserves for Logitech's now-discontinued Revue product. As a result, the Company recorded an adjustment to increase cost of goods sold and to increase inventory valuation reserves and the accrual for supplier liability for components related to the Company's now discontinued Revue product by $30.7 million during fiscal year ended March 31, 2011, with a corresponding decrease to cost of goods sold in fiscal year ended March 31, 2012. As a result, net income and net income per share for fiscal year ended March 31, 2011 was reduced by $30.7 million and $0.17 per share, respectively, with a corresponding increase in fiscal year ended March 31, 2012. In conjunction with recording of the adjustments related to this restatement, the Company recorded other immaterial corrections to the consolidated financial statements included in this Form 10-K for the fiscal years ended March 31, 2013 and 2012.

[0001047469-14-009167:notes:350]
The Audit Committee has completed its independent investigation and found that, in connection with its quarterly close processes, up until June 2013, the Company's finance organization would compile lists of financial items, which included significant accounting entries recorded during the quarter, late accounting entries, disclosure items and certain other items with potential accounting implications. The lists used to track these financial items appear to have been primarily shared within certain parts of the Company's finance organization and were not shared with the Company's independent registered public accounting firm. Typically, there were between approximately thirty to fifty items per quarter on these lists and there were multiple versions of these lists per quarter, as items were added, removed and changed. Some of the items on the list were discussed with the Company's independent registered public accounting firm while others were not.

[0001047469-14-009167:notes:351]
As part of the independent investigation, the Company determined that nine historical items from these lists during a five year period should have been recorded in an earlier period or a different amount should have been recorded. The largest item relates to the now-discontinued Revue product and is the cause for the restatement. Two items—the warranty accrual and the amortization of certain intangible assets—were on the lists in prior periods and were not addressed in a timely manner before the Company corrected them in its revised Form 10-K/A filed on August 7, 2013. Certain former finance employees signed the May 30, 2013 management representation letter to the Company's independent registered public accounting firm without disclosing these issues and, as a result, the management representation letter was inaccurate on this point. Six items are not material individually or in aggregate to any of the annual or interim periods reported but are nevertheless being corrected in these restated consolidated financial statements.

[0001047469-14-009167:notes:352]
There are two elements to the restatement related to the Revue product: (1) a lower of cost or market ("LCM") charge based on the net realizable value of finished goods and work in process on-hand inventory and non-cancelable orders for such inventory, and (2) an excess and obsolescence charge for non-cancelable orders for inventory components. The Audit Committee found that certain former members of the finance organization had information that was not considered, that showed a future loss that was estimable and probable before the filing of the Form 10-K on May 27, 2011 and that such loss was not recorded in the Company's fiscal year 2011 financial statements. Certain former members of the finance organization erroneously accounted for the LCM charge in fiscal year 2011 based on the current price or on price reductions approved by management instead of considering available contemporaneous evidence of anticipated future price reductions and losses which were estimable and probable at the time. In addition, the Audit Committee found that a management representation letter dated May 27, 2011 to the Company's independent registered public accounting firm incorrectly stated that probable future pricing adjustments were considered in the LCM calculation. With respect to the Revue components, certain former members of the finance organization did not consider all available information and therefore did not record a charge in the fourth quarter of fiscal year 2011 for non-cancelable orders related to components considered excess and obsolete. The analysis erroneously assumed the components would be manufactured into finished goods, though there was information available that showed that the components would not be manufactured into finished goods. This information was not reflected in the Company's accounting or provided to the Company's independent registered public accounting firm. The Audit Committee found that the Company did not have an adequate basis for the historical accounting treatment of the components in the fourth quarter of fiscal year 2011.

[0001047469-14-009167:notes:353]
The restated and revised financial statements included the following adjustments:

[0001047469-14-009167:notes:354]
Inventory Valuation Reserve—As described above, the Company determined that there was a material accounting misstatement for Logitech's now-discontinued Revue product in fiscal years 2012 and 2011. As a result, the Company recorded an adjustment to increase cost of goods sold, and to increase inventory valuation reserves and supplier liability for components related to the Company's now discontinued Revue product by $30.7 million during fiscal year ended March 31, 2011, with a corresponding decrease to cost of goods sold during fiscal year ended March 31, 2012.

[0001047469-14-009167:notes:355]
Property Plant and Equipment Capitalization Threshold Convention—Historically, the Company's practice was to apply an accounting convention to immediately expense the entire purchase price of all property and equipment that cost less than certain dollar thresholds instead of capitalizing and depreciating such property and equipment over its useful life. The Company determined that the thresholds utilized were incorrect and resulted in a cumulative understatement of net income and retained earnings through March 31, 2011 of $8.3 million, which the company corrected through an increase to opening retained earnings as of that date. The impact of the correction also resulted in a decrease in cost of goods sold and operating expense and increase in operating income of $0.1 million in fiscal year 2012 and an increase in cost of goods sold and operating expense and increase in operating loss of $1.3 million in fiscal year 2013.

[0001047469-14-009167:notes:356]
(3)

[0001047469-14-009167:notes:357]
Settlement Accrual—The Company determined that it incorrectly recorded a release of a legal settlement accrual of $1.3 million in fiscal year 2012 instead of correctly in fiscal year 2011 as the contingency was resolved before the Annual Report Form 10-K of fiscal year 2011 was issued. The impact of this adjustment was an increase in operating income by $1.3 million in fiscal year 2011 and a corresponding decrease of operating income for the same amount in fiscal year 2012.

[0001047469-14-009167:notes:358]
(4)

[0001047469-14-009167:notes:359]
Other Adjustments—The Company is also correcting a number of other immaterial errors which were previously recorded in prior periods as out-of-period adjustments and are now being revised to report them in the correct period as well as to correct other immaterial errors that were previously uncorrected. Among the corrections, the Company is correcting its accrual for worker compensation, liability for certain of its defined benefit pension plans, balance sheet reclassifications, cash flow reclassifications and tax impact of the above adjustments.

[0001047469-14-009167:notes:360]
Consolidated Statements of Operations

[0001047469-14-009167:notes:361]
Consolidated Statements of Comprehensive Income (Loss)

[0001047469-14-009167:notes:362]
Consolidated Balance Sheet

[0001047469-14-009167:notes:363]
Consolidated Statements of Cash Flows


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001047469-14-009167:notes:364]
Schedule II

[0001047469-14-009167:notes:365]
LOGITECH INTERNATIONAL S.A.

[0001047469-14-009167:notes:366]
VALUATION AND QUALIFYING ACCOUNTS

[0001047469-14-009167:notes:367]
For the Fiscal Years Ended March 31, 2014, 2013 and 2012 (in thousands)

[0001047469-14-009167:notes:368]
The Company's Schedule II includes valuation and qualifying accounts related to allowances for doubtful accounts, sales returns, cooperative marketing arrangements, customer incentive programs, and pricing programs, for direct customers and tax valuation allowances. The Company also has sales incentive programs for indirect customers with whom it does not have a direct sales and receivable relationship. These programs are recorded as accrued liabilities and are not considered valuation or qualifying accounts.

[0001047469-14-009167:notes:369]
|  |  | Balance at Beginning of Year |  | Charged (Credited) to Statement of Operations |  | Claims and Adjustments Applied Against Allowances |  | Balance at End of Year |  |
| Allowance for doubtful accounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 2014 |  | $ | 2,153 |  | $ | 656 |  | $ | (1,097 | ) | $ | 1,712 |  |
| 2013 |  |  | 2,472 |  | $ | (107 | ) | $ | (212 | ) | $ | 2,153 |  |
| 2012 |  |  | 4,086 |  | $ | (592 | ) | $ | (1,022 | ) | $ | 2,472 |  |
| Allowance for sales returns: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 2014 |  | $ | 21,883 |  | $ | 59,483 |  | $ | (61,894 | ) | $ | 19,472 |  |
| 2013 |  |  | 24,599 |  | $ | 61,315 |  | $ | (64,031 | ) | $ | 21,883 |  |
| 2012 |  |  | 29,666 |  | $ | 72,543 |  | $ | (77,610 | ) | $ | 24,599 |  |
| Allowances for cooperative marketing arrangements: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 2014 |  | $ | 24,160 |  | $ | 102,751 |  | $ | (102,776 | ) | $ | 24,135 |  |
| 2013 |  |  | 24,109 |  | $ | 96,278 |  | $ | (96,227 | ) | $ | 24,160 |  |
| 2012 |  |  | 28,669 |  | $ | 101,557 |  | $ | (106,117 | ) | $ | 24,109 |  |
| Allowances for customer incentive programs: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 2014 |  | $ | 42,857 |  | $ | 106,810 |  | $ | (108,267 | ) | $ | 41,400 |  |
| 2013 |  |  | 42,262 |  | $ | 94,313 |  | $ | (93,718 | ) | $ | 42,857 |  |
| 2012 |  |  | 52,358 |  | $ | 108,683 |  | $ | (118,779 | ) | $ | 42,262 |  |
| Allowances for pricing programs: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 2014 |  | $ | 55,858 |  | $ | 221,702 |  | $ | (208,114 | ) | $ | 69,446 |  |
| 2013 (As revised) |  |  | 60,371 |  | $ | 182,916 |  | $ | (187,429 | ) | $ | 55,858 |  |
| 2012 |  |  | 62,258 |  | $ | 196,808 |  | $ | (198,695 | ) | $ | 60,371 |  |
| Tax valuation allowances: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 2014 |  | $ | 6,014 |  | $ | 515 |  | $ | (1,657 | ) | $ | 4,872 |  |
| 2013 |  |  | 2,205 |  | $ | 3,865 |  | $ | (56 | ) | $ | 6,014 |  |
| 2012 |  |  | 2,309 |  | $ | — |  | $ | (104 | ) | $ | 2,205 |  |
