# LOGI MD&A — 0001032975-18-000016


## mdna

[0001032975-18-000016:mdna:1]
ITEM 7.    MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001032975-18-000016:mdna:2]
Overview of Our Company

[0001032975-18-000016:mdna:3]
Logitech is a world leader in designing, manufacturing and marketing products that help connect people to digital and cloud experiences. More than 35 years ago, Logitech created products to improve experiences around the personal PC platform, and today it is a multi-brand, multi-category company designing products that enable better experiences consuming, sharing and creating any digital content such as music, gaming, video and computing, whether it is on a computer, mobile device or in the cloud. Logitech's brands include Logitech, Jaybird, Ultimate Ears, Logitech G and ASTRO Gaming.

[0001032975-18-000016:mdna:4]
Our products participate in five large markets that all have growth opportunities: Music, Gaming, Video Collaboration, Smart Home and Creativity & Productivity. We sell our products to a broad network of domestic and international customers, including direct sales to retailers and e-tailers, and indirect sales through distributors. Our worldwide channel network includes consumer electronics distributors, retailers, mass merchandisers, specialty stores, computer and telecommunications stores, value-added resellers and online merchants.

[0001032975-18-000016:mdna:5]
We operate in a single operating segment: Peripherals. In fiscal years prior to fiscal year 2016, we operated in two segments: Peripherals, including retail and OEM products; and Lifesize Video Conferencing. During fiscal year 2016, we divested the Lifesize Video Conferencing segment and exited the OEM business. Our financial results treat the Lifesize segment as discontinued operations for all the periods presented in this Annual Report on Form 10-K.

[0001032975-18-000016:mdna:6]
From time to time, we may seek to partner with, or acquire when appropriate, companies that have products, personnel, and technologies that complement our strategic direction. We continually review our product offerings and our strategic direction in light of our profitability targets, competitive conditions, changing consumer trends and the evolving nature of the interface between the consumer and the digital world.

[0001032975-18-000016:mdna:7]
On August 11, 2017, we acquired certain assets and liabilities constituting the ASTRO Gaming business (ASTRO) from AG Acquisition Corporation for a purchase price of $85.0 million in cash (the ASTRO Acquisition). ASTRO is a leading console gaming accessory brand with a history of producing award-winning headsets for professional gamers and enthusiasts. ASTRO provides a strong growth platform in the console gaming accessories market. In November 2017, we also made a small technology acquisition for a total consideration of $5.2 million.

[0001032975-18-000016:mdna:8]
On September 15, 2016, we acquired the Saitek product line for a total consideration of approximately $13.0 million (the Saitek Acquisition). The Saitek Acquisition enhances the breadth and depth of our product offerings in the Gaming category and expands our engineering capabilities in simulation products.

[0001032975-18-000016:mdna:9]
On April 20, 2016, we acquired Jaybird LLC of Salt Lake City, Utah (Jaybird) for a purchase price of $54.2 million, including a working capital adjustment and payment of a line-of-credit on behalf of Jaybird, along with an additional earn-out of up to $45.0 million in cash based on achievement of growth targets over two years (the Jaybird Acquisition). In October 2017, Logitech and the sellers of Jaybird entered into an agreement fully, irrevocably and unconditionally releasing Logitech from the earn-out rights and payments in exchange for $5.0 million in cash, which was paid in November 2017. Jaybird is a leader in wireless audio wearables for sports and active lifestyles, and the acquisition of Jaybird expands our long-term growth potential in our Music market.

[0001032975-18-000016:mdna:10]
On December 28, 2015, we and Lifesize, Inc., a wholly owned subsidiary of Logitech which holds the assets of our Lifesize video conferencing business, entered into a stock purchase agreement with three venture capital firms. Immediately following December 28, 2015, closing of the transaction, the venture capital firms held 62.5% of the outstanding shares of Lifesize, which resulted in a divestiture of the Lifesize video conferencing business by us because we have no voting rights or any other significant influence. The historical results of operations and the financial position of Lifesize are included in the consolidated financial statements of Logitech and are reported as discontinued operations within this Annual Report on Form 10-K.

[0001032975-18-000016:mdna:11]
We exited our OEM business during the third quarter of fiscal year 2016. There is no revenue and cost associated with this business since then.

[0001032975-18-000016:mdna:12]
Summary of Financial Results

[0001032975-18-000016:mdna:13]
Our total net sales for fiscal year 2018 increased 16% in comparison to fiscal year 2017. The growth was broad-based across our regions and across our product categories. The results of operations for ASTRO have been included in our consolidated statements of operations from the acquisition date. For fiscal year 2018, ASTRO contributed approximately 2 points to net sales growth.

[0001032975-18-000016:mdna:14]
Net sales for fiscal year 2018 increased 16%, 10% and 23% in the Americas, EMEA and Asia Pacific, respectively.

[0001032975-18-000016:mdna:15]
We transitioned to a new third-party logistics provider and distribution center in North America in the second quarter of fiscal year 2018 to support our growth. We experienced significant challenges in the transition, in operating procedures at the newer distribution center, and in ramping fulfillment in the second quarter and early third quarter of fiscal year 2018. As a result, we incurred additional cost on freight and warehouse-related expense. We have transitioned back to the original distribution center for North America, and the process was completed during the fourth quarter of fiscal year 2018.

[0001032975-18-000016:mdna:16]
Gross margin is gross profit as a percentage of net sales. Gross margin decreased by 150 basis points to 35.4% during fiscal year 2018, compared to fiscal year 2017. The decrease in gross margin was primarily driven by increases in pricing programs and incentive and marketing activities, additional costs from the transition of the distribution center in North America in the third quarter of fiscal year 2018, and product mix, partially offset by product cost reductions and favorable currency exchange rates. In addition, in fiscal year 2017, we recorded a first-time-adoption benefit of $14.4 million primarily due to a change in estimated breakage attributable to customer incentive, cooperative marketing and pricing program accruals in EMEA.

[0001032975-18-000016:mdna:17]
Operating expenses for fiscal year 2018 were $679.5 million, or 26.5% of net sales, compared to $608.2 million, or 27.4%, for fiscal year 2017. The increase in operating expenses was primarily driven by $39.7 million of higher personnel-related costs due to increased headcount, higher share-based compensation and businesses acquired during fiscal year 2018, $22.2 million higher external cost mostly attributed to higher external advertising and marketing expenses, $3.2 million lower credit from change in fair value of contingent consideration for business acquisition and $3.1 million higher amortization of intangible assets from the business acquisitions.

[0001032975-18-000016:mdna:18]
Income tax provision for fiscal year 2018 was impacted by a provisional charge of $21.7 million from the remeasurement of federal and state deferred tax assets and liabilities in the United States to reflect a reduction in corporate income tax rate from 35% to 21% as a result of the enactment of H.R.1, also known as the Tax Cuts and Jobs Act (the Tax Act) in the United States on December 22, 2017.

[0001032975-18-000016:mdna:19]
Net income for fiscal year 2018 was $208.5 million, compared to $205.9 million for fiscal year 2017.

[0001032975-18-000016:mdna:20]
Trends in Our Business

[0001032975-18-000016:mdna:21]
Our strategy focuses on five large multi-category market opportunities including Music, Gaming, Video Collaboration, Smart Home and Creativity & Productivity. We see opportunities to deliver growth with products in all these markets.

[0001032975-18-000016:mdna:22]
We believe our future growth will be determined by our ability to rapidly create innovative products across multiple digital platforms, including gaming, digital music devices, video and computing. The following discussion represents key trends specific to our market opportunities.

[0001032975-18-000016:mdna:23]
Trends Specific to Our Five Market Opportunities

[0001032975-18-000016:mdna:24]
Music:  The music market grew during fiscal year 2018, driven by growing consumption of music through mobile devices such as smartphones and tablets. According to the Recording Industry Association of America (RIAA), revenues from streaming music platforms increased over 40% in 2017. The integration of personal voice assistants has become increasingly competitive in the speaker categories and the market for third-party, voice-enabled speakers has not yet gained traction. Moreover, the market for mobile speakers appears to be maturing with slower growth. Our investments in the Ultimate Ears and Jaybird brands, new channel expansion, integration of personal voice assistants, such as Google Assistant and Amazon Alexa, and our new product introductions, have driven our growth in this market through the third quarter of fiscal year 2018, though sales of our Mobile Speakers declined during the fourth quarter.

[0001032975-18-000016:mdna:25]
Gaming:  The PC gaming and console gaming platform continues to show strong growth as online gaming, multi-platform experiences, and eSports gain greater popularity and gaming content becomes increasingly more demanding. We believe Logitech is well positioned to benefit from the PC gaming market growth. With ASTRO Gaming, we are also strengthening our portfolio in adjacent categories, such as the console gaming market.

[0001032975-18-000016:mdna:26]
Video Collaboration:  The near and long-term structural growth opportunities in the video collaboration market are significant. Video meetings are on the rise, and companies increasingly want lower-cost, cloud-based solutions. We are continuing our efforts to create and sell innovative products to accommodate the increasing demand from medium-sized meeting rooms to small-sized rooms such as huddle rooms. We will continue to invest in select business-specific products, targeted product marketing and sales channel development.

[0001032975-18-000016:mdna:27]
Smart Home:  This market increased in fiscal year 2017 and has continued growing in fiscal year 2018. In October 2016, we integrated Amazon Alexa and Google Assistant voice capabilities into our Logitech Harmony Hub that enables voice control of the living room entertainment experience when used with an Amazon Echo or Google Home device. Through Harmony, Alexa can turn on/off and control a TV and AV system. We have also seen early success with the professional installer channel through the recent introduction of the Harmony Pro. We will continue to explore other innovative experiences for the Smart Home.

[0001032975-18-000016:mdna:28]
Creativity & Productivity:  Although new PC shipments continue to be lackluster, the installed base of PC users remains large. We believe that innovative PC peripherals, such as our mice and keyboards, can renew the PC usage experience, providing growth opportunities. Smaller mobile computing devices, such as tablets, have created new markets and usage models for peripherals and accessories. We offer a number of products to enhance the use of mobile devices, including keyboard folios for the iPad and iPad mini, and keyboard covers and folios for the iPad Air. In fiscal year 2018, we have seen the recovery of the iPad tablet market and our Tablet & Other Accessories category has benefited from the recovery along with our innovative products.

[0001032975-18-000016:mdna:29]
Business Seasonality, Product Introductions and Business Acquisitions

[0001032975-18-000016:mdna:30]
We have historically experienced higher net sales in our third fiscal quarter ending December 31, compared to other fiscal quarters in our fiscal year, due in part to seasonal holiday demand. Additionally, new product introductions and business acquisitions can significantly impact net sales, product costs and operating expenses. Product introductions can also impact our net sales to distribution channels as these channels are filled with new product inventory following a product introduction, and often channel inventory of an earlier model product declines as the next related major product launch approaches. Net sales can also be affected when consumers and distributors anticipate a product introduction or changes in business circumstances. However, neither historical seasonal patterns nor historical patterns of product introductions should be considered reliable indicators of our future pattern of product introductions, future net sales or financial performance.

[0001032975-18-000016:mdna:31]
Critical Accounting Estimates

[0001032975-18-000016:mdna:32]
The preparation of financial statements and related disclosures in conformity with U.S. GAAP requires us to make judgments, estimates, and assumptions that affect reported amounts of assets, liabilities, net sales and expenses, and the disclosure of contingent assets and liabilities.

[0001032975-18-000016:mdna:33]
We consider an accounting estimate critical if it: (i) requires management to make judgments and estimates about matters that are inherently uncertain; and (ii) is important to an understanding of our financial condition and operating results.

[0001032975-18-000016:mdna:34]
We base our estimates on historical experience and on various other assumptions we believe to be reasonable under the circumstances. Although these estimates are based on management's best knowledge of current events and actions that may impact us in the future, actual results could differ from those estimates. Management has discussed the development, selection and disclosure of these critical accounting estimates with the Audit Committee of the Board of Directors.

[0001032975-18-000016:mdna:35]
We believe the following accounting estimates are most critical to our business operations and to an understanding of our financial condition and results of operations and reflect the more significant judgments and estimates used in the preparation of our consolidated financial statements.

[0001032975-18-000016:mdna:36]
Accruals for Customer Programs

[0001032975-18-000016:mdna:37]
We record accruals for cooperative marketing arrangements, customer incentive programs, pricing programs and product returns. An allowance against accounts receivable is recorded for accruals and program activity related to our direct customers and indirect customers who receive payments for program activity through our direct customers. A liability is recorded for accruals and program activity related to our indirect customers who receive payments directly and do not have a right of offset against a receivable balance. The estimated cost of these programs is usually recorded as a reduction of revenue. If we receive a separately identifiable benefit from the customer and can reasonably estimate the fair value of that benefit, such cost is reflected in operating expenses. Significant management judgments and estimates must be used to determine the cost of these programs in any accounting period. Certain customer programs require management to estimate the percentage of those programs which will not be claimed or will not be earned by customers based on historical experience and on the specific terms and conditions of particular programs. The percentage of these customer programs that will not be claimed or earned is commonly referred to as "breakage".

[0001032975-18-000016:mdna:38]
Cooperative Marketing Arrangements.    We enter into customer marketing programs with many of our customers, and with certain indirect partners, allowing customers to receive a credit equal to a set percentage of their purchases of our products, or a fixed dollar credit for various marketing programs. The objective of these arrangements is to encourage advertising and promotional events to increase sales of our products. Accruals for these marketing arrangements are recorded at the later of the date the revenue is recognized or the date the incentive is offered, based on negotiated terms, historical experience and inventory levels in the channel.

[0001032975-18-000016:mdna:39]
Customer Incentive Programs.    Customer incentive programs include performance-based incentives and consumer rebates. We offer performance-based incentives to our customers and indirect partners based on pre-determined performance criteria. Accruals for performance-based incentives are recognized as a reduction of the sale price at the time of sale. Estimates of required accruals are determined based on negotiated terms, consideration of historical experience, anticipated volume of future purchases, and inventory levels in the channel. Consumer rebates are offered from time to time at our discretion for the primary benefit of end-users. Accruals for the estimated costs of consumer rebates and similar incentives are recorded at the later of time of sale or when the incentive is offered, based on the specific terms and conditions.

[0001032975-18-000016:mdna:40]
Pricing Programs.    We have agreements with certain customers that contain terms allowing price protection credits to be issued in the event of a subsequent price reduction. At our discretion, we also offer special pricing discounts to certain customers. Special pricing discounts are usually offered only for limited time periods or for sales of selected products to specific indirect partners. Our decision to make price reductions is influenced by product life cycle stage, market acceptance of products, the competitive environment, new product introductions and other factors. Accruals for estimated expected future pricing actions are recognized at the time of sale based on analysis of historical pricing actions by customer and by product, inventories owned by and located at distributors and retailers, current customer demand, current operating conditions, and other relevant customer and product information, such as stage of product life-cycle.

[0001032975-18-000016:mdna:41]
Returns.    We grant limited rights to return products. Return rights vary by customer and range from just the right to return defective product to stock rotation rights limited to a percentage of sales approved by management. Estimates of expected future product returns are recognized at the time of sale based on analyses of historical return trends by customer and by product, inventories owned by and located at customers, current customer demand, current operating conditions, and other relevant customer and product information. Upon recognition, we reduce sales and cost of goods sold for the estimated return. Return trends are influenced by product life cycle status, new product introductions, market acceptance of products, sales levels, product sell-through, the type of customer, seasonality, product quality issues, competitive pressures, operational policies and procedures, and other factors. Return rates can fluctuate over time, but are sufficiently predictable to allow us to estimate expected future product returns.

[0001032975-18-000016:mdna:42]
We apply a breakage rate to reduce our accruals of customer incentive, cooperative marketing, and pricing programs based on the estimated percentage of these customer programs that will not be claimed or earned. The breakage rate is applied when we are able to reasonably estimate the amounts that will be ultimately claimed by customers. Significant management judgments and estimates are used to determine the breakage of the programs in any accounting period.

[0001032975-18-000016:mdna:43]
We regularly evaluate the adequacy of our accruals for cooperative marketing arrangements, customer incentive programs, pricing programs and product returns. Future market conditions and product transitions may require us to take action to increase such programs. In addition, when the variables used to estimate these costs

[0001032975-18-000016:mdna:44]
change, or if actual costs differ significantly from the estimates, we would be required to record incremental increases or reductions to revenue or operating expenses. If, at any future time, we become unable to reasonably estimate these costs, recognition of revenue might be deferred until products are sold to end users, which would adversely impact revenue in the period of transition.

[0001032975-18-000016:mdna:45]
Inventory Valuation

[0001032975-18-000016:mdna:46]
We must order components for our products and build inventory in advance of customer orders. Further, our industry is characterized by rapid technological change, short-term customer commitments and rapid changes in demand.

[0001032975-18-000016:mdna:47]
We record inventories at the lower of cost and net realizable value and record write-downs of inventories that are obsolete or in excess of anticipated demand or net realizable value. A review of inventory is performed each fiscal quarter that considers factors including the marketability and product lifecycle stage, product development plans, component cost trends, historical net sales and demand forecasts which consider the assumptions about future demand and market conditions. Inventory on hand which is not expected to be sold or utilized is considered excess, and we recognize the write-down in cost of goods sold at the time of such determination. The write-down is determined by the excess of cost over net realizable value. Net realizable value is the estimated selling price in the ordinary course of business, less reasonably predictable costs of completion, disposal and transportation. At the time of loss recognition, new cost basis per unit and lower-cost basis for that inventory is established and subsequent changes in facts and circumstances would not result in an increase in the cost basis. If there is an abrupt and substantial decline in demand for Logitech's products or an unanticipated change in technological or customer requirements, we may be required to record additional write-downs that could adversely affect gross margins in the period when the write-downs are recorded.

[0001032975-18-000016:mdna:48]
Share-Based Compensation Expense

[0001032975-18-000016:mdna:49]
The grant date fair value for stock options and stock purchase rights is estimated using the Black-Scholes-Merton option-pricing valuation model. The grant date fair value of restricted stock units (RSUs) that vest upon meeting certain market conditions is estimated using the Monte-Carlo simulation method. The grant date fair value of time-based RSUs and RSUs with performance conditions is calculated based on the closing market price on the date of grant, adjusted by estimated dividends yield prior to vesting.

[0001032975-18-000016:mdna:50]
Our estimates of share-based compensation expense require a number of complex and subjective assumptions including our stock price volatility, employee exercise patterns, future forfeitures, the probability of achievement of the set performance conditions, dividend yield, related tax effects and the selection of an appropriate fair value model. We estimate expected share price volatility based on historical volatility using daily prices over the term of past options, RSUs or purchase offerings, as we consider historical share price volatility as most representative of future volatility. We estimate expected life based on historical settlement rates, which we believe are most representative of future exercise and post-vesting termination behaviors. The dividend yield assumption is based on our history and expectations of future dividend payouts.  We used historical data to estimate pre-vesting forfeitures, and we recorded share-based compensation expense only for those awards that are expected to vest. Effective April 1, 2017, we adopted Accounting Standards Update (ASU) 2016-09 and account for forfeitures as they occur. Refer to "Adoption of New Accounting Pronouncements" below for details of the impact from the change in accounting.

[0001032975-18-000016:mdna:51]
The assumptions used in calculating the fair value of share-based compensation expense and related tax effects represent our best estimates, but these estimates involve inherent uncertainties and the application of management judgments. As a result, if factors change and we use different assumptions, or if we decide to use a different valuation model, our share-based compensation expense could be materially different in the future from what we have recorded in the current period, which could materially affect our results of operations.

[0001032975-18-000016:mdna:52]
Accounting for Income Taxes

[0001032975-18-000016:mdna:53]
We operate in multiple jurisdictions and our profits are taxed pursuant to the tax laws of these jurisdictions. Our effective income tax rate may be affected by the changes in or interpretations of tax laws and tax agreements in any given jurisdiction, utilization of net operating loss and tax credit carryforwards, changes in geographical mix of income and expense, and changes in our assessment of matters such as the ability to realize deferred tax assets. As a result of these considerations, we must estimate income taxes in each of the jurisdictions in which we operate. This process involves estimating current tax exposure together with assessing temporary differences resulting from different treatment of items for tax and accounting purposes. These differences result in deferred tax assets and liabilities, which are included in the consolidated balance sheet.

[0001032975-18-000016:mdna:54]
We assess the likelihood that our deferred tax assets will be recovered from future taxable income, considering all available evidence such as historical levels of income, expectations and risks associated with estimates of future taxable income and ongoing prudent and feasible tax strategies. When we determine that it is not more likely than not that we will realize all or part of our deferred tax assets, an adjustment is charged to earnings in the period when such determination is made. Likewise, if we later determine that it is more likely than not that all or a part of our deferred tax assets would be realized, the previously provided valuation allowance would be reversed.

[0001032975-18-000016:mdna:55]
We make certain estimates and judgments about the application of tax laws, the expected resolution of uncertain tax positions and other matters surrounding the recognition and measurement of uncertain tax benefits. In the event that uncertain tax positions are resolved for amounts different than our estimates, or the related statutes of limitations expire without the assessment of additional income taxes, we will be required to adjust the amounts of the related assets and liabilities in the period in which such events occur. Such adjustments may have a material impact on our income tax provision and our results of operations.

[0001032975-18-000016:mdna:56]
We have recorded provisional estimates associated with the enactment of the Tax Act in the United States on December 22, 2017. The SEC has provided accounting and reporting guidance in Staff Accounting Bulletin (SAB) No. 118 that allows us to report provisional amounts within a measurement period up to one year due to the complexities inherent in adopting the changes. We consider the remeasurement of deferred income taxes incomplete. New guidance from regulators, interpretation of the law, and refinement of our estimates from ongoing analysis of data and tax positions may change the provisional amounts.

[0001032975-18-000016:mdna:57]
Goodwill

[0001032975-18-000016:mdna:58]
We conduct a goodwill impairment analysis annually at December 31 or more frequently if indicators of impairment exist or if a decision is made to sell or exit a business. A significant amount of judgments are involved in determining if an indicator of impairment has occurred. Such indicators may include deterioration in general economic conditions, negative developments in equity and credit markets, adverse changes in the markets in which an entity operates, increases in input costs that have a negative effect on earnings and cash flows, a trend of negative or declining cash flows, a decline in actual or planned revenue or earnings compared with actual and projected results of relevant prior periods, or other relevant entity-specific events such as changes in management, key personnel, strategy or customers, contemplation of bankruptcy, or litigation. The fair value that could be realized in an actual transaction may differ from that used to evaluate the impairment of goodwill.

[0001032975-18-000016:mdna:59]
In reviewing goodwill for impairment, an entity has the option to first assess qualitative factors to determine whether the existence of events or circumstances leads to a determination that it is more likely than not (greater than 50%) that the estimated fair value of a reporting unit is less than its carrying amount. If an entity elects to perform a qualitative assessment and determines that an impairment is more likely than not, the entity is then required to perform the quantitative impairment test; otherwise, no further analysis is required. An entity also may elect not to perform the qualitative assessment and, instead, proceed directly to the quantitative impairment test. The ultimate outcome of the goodwill impairment review for a reporting unit should be the same whether an entity chooses to perform the qualitative assessment or proceeds directly to the quantitative impairment test. Goodwill is allocated among and evaluated for impairment at the reporting unit level, which is defined as an operating segment or one level below an operating segment. We currently have only one reporting unit.

[0001032975-18-000016:mdna:60]
Annual Impairment analysis

[0001032975-18-000016:mdna:61]
We performed our annual impairment analysis of the goodwill as of December 31, 2017 by performing a qualitative assessment and concluded that it was more likely than not that the fair value of the peripheral reporting unit exceeded its carrying amount. Refer to Note 12 to the consolidated financial statements included in this Annual Report on Form 10-K for the disclosures.

[0001032975-18-000016:mdna:62]
Product Warranty Accrual

[0001032975-18-000016:mdna:63]
We estimate the cost of product warranties at the time the related revenue is recognized based on historical and projected warranty claim rates, historical and projected costs, and knowledge of specific product failures that are outside of our typical experience. Each fiscal quarter, we reevaluate estimates to assess the adequacy of recorded warranty liabilities considering the size of the installed base of products subject to warranty protection and adjust the amounts as necessary. If actual product failure rates or repair costs differ from estimates, revisions to the estimated warranty liabilities would be required and could materially affect our results of operations.

[0001032975-18-000016:mdna:64]
Business Acquisitions

[0001032975-18-000016:mdna:65]
Accounting for business acquisitions requires us to make significant estimates and assumptions, especially at the acquisition date with respect to tangible and intangible assets acquired and liabilities assumed and pre-acquisition contingencies. We use our best estimates and assumptions to accurately assign fair value to the tangible and intangible assets acquired and liabilities assumed at the acquisition date.

[0001032975-18-000016:mdna:66]
Examples of critical estimates in valuing certain intangible assets and goodwill we have acquired include but are not limited to:

[0001032975-18-000016:mdna:67]
| • | royalty rate range and forecasted revenue growth rate assumptions; |

[0001032975-18-000016:mdna:68]
| • | assumptions regarding the estimated useful life of the acquired intangibles; |

[0001032975-18-000016:mdna:69]
| • | discount rates. |

[0001032975-18-000016:mdna:70]
Unanticipated events and circumstances may occur that may affect the accuracy or validity of such assumptions, estimates or actual results.

[0001032975-18-000016:mdna:71]
The economic useful life of the developed technology from the business acquisitions was determined based on the technology cycle related to developed technology of existing products, as well as the cash flows over the forecasted periods.

[0001032975-18-000016:mdna:72]
The economic useful life of the customer relationships from the business acquisitions was determined based on historical customer turnover rates and the industry benchmarks.

[0001032975-18-000016:mdna:73]
The economic useful life of the trade names from the business acquisitions was determined based on the expected life of the trade names and the cash flows anticipated over the forecasted periods.

[0001032975-18-000016:mdna:74]
The fair value of acquisition-related contingent consideration liability arising from the Jaybird Acquisition (see "Note 3 - Business Acquisitions" and "Note 10 - Fair Value Measurements" to the consolidated financial statements for more information) is determined by using a Monte Carlo Simulation that includes significant unobservable inputs such as a risk-adjusted discount rate and projected net sales of Jaybird over the earn-out period, and it is remeasured at each reporting period based on the inputs on the date of remeasurement. Projected net sales are based on our internal projections, including analysis of the target markets. In October 2017, Logitech and the sellers of Jaybird entered into an agreement fully, irrevocably and unconditionally releasing Logitech from the earn-out rights and payments in exchange for $5.0 million in cash, which approximated the fair value of the contingent consideration as of September 30, 2017. We paid the $5.0 million in November 2017.

[0001032975-18-000016:mdna:75]
Adoption of New Accounting Pronouncements

[0001032975-18-000016:mdna:76]
In July 2015, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2015-11, "Simplifying the Measurement of Inventory (Topic 330)" (ASU 2015-11). Topic 330 previously required an entity to measure inventory at the lower of cost or market, with the market value represented by replacement cost, net realizable value or net realizable value less a normal profit margin. ASU 2015-11 requires an entity to measure inventory at the lower of cost and net realizable value and is effective for fiscal years beginning after December 15, 2016. We adopted this standard effective April 1, 2017, which has not had a material impact on our consolidated financial statements.

[0001032975-18-000016:mdna:77]
In March 2016, the FASB issued ASU 2016-09, "Compensation-Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting" (ASU 2016-09). ASU 2016-09 simplifies several aspects of the accounting for share-based payments, including immediate recognition of all excess tax benefits and deficiencies in the income statement, changing the threshold to qualify for equity classification up to the employees' maximum statutory tax rates, allowing an entity-wide accounting policy election to either estimate the number of awards that are expected to vest or account for forfeitures as they occur, and clarifying the classification on the statement of cash flows for the excess tax benefits and employee taxes paid when an employer withholds shares for tax withholding purposes. ASU 2016-09 is effective for fiscal years beginning after December 15, 2016. We adopted this standard effective April 1, 2017. Changes to the statements of cash flows related to the classification of excess tax benefits were implemented on a retroactive basis and accordingly, to conform to the current year presentation, we reclassified $9.7 million and $2.1 million of excess tax benefits previously reported under financing activities to operating activities for the years ended March 31, 2017 and March 31, 2016, respectively, on our consolidated statements of cash flows. Under the new standard, we account for forfeitures as they occur. The change in accounting for forfeitures resulted in a cumulative-effect adjustment to decrease retained earnings as of

[0001032975-18-000016:mdna:78]
March 31, 2017 by $3.3 million. We further recognized a cumulative-effect adjustment to increase retained earnings as of March 31, 2017 by $57.2 million upon adoption of the new guidance to account for gross excess tax benefits of $75.2 million that were previously not recognized because the related tax deduction had not reduced current income taxes, offset by a valuation allowance of $18.0 million to reduce the deferred tax assets to amounts that are more likely than not to be realized.

[0001032975-18-000016:mdna:79]
In January 2017, the FASB issued ASU 2017-04, "Simplifying the Test for Goodwill Impairment (Topic 350)" (ASU 2017-04), which removes Step 2 from the goodwill impairment test. ASU 2017-04 is effective for annual or any interim goodwill impairments in annual periods beginning December 15, 2019, with early adoption permitted. We adopted this standard effective April 1, 2017, which has not had a material impact on our consolidated financial statements.

[0001032975-18-000016:mdna:80]
In May 2017, the FASB issued ASU 2017-09, "Compensation-Stock Compensation (Topic 718): Scope of Modification Accounting" (ASU 2017-09), which provides guidance about which changes to the terms or conditions of a share-based payment award require an entity to apply modification accounting in Topic 718. ASU 2017-09 is effective for annual periods beginning after December 15, 2017, with early adoption permitted, including adoption in any interim period for which financial statements have not yet been issued. We adopted this standard effective April 1, 2017, which has not had a material impact on our consolidated financial statements.

[0001032975-18-000016:mdna:81]
Refer to Note 2 to the consolidated financial statements included in this Annual Report on Form 10-K for recent accounting pronouncements to be adopted.

[0001032975-18-000016:mdna:82]
Constant Currency

[0001032975-18-000016:mdna:83]
We refer to our net sales growth rates excluding the impact of currency exchange rate fluctuations as "constant currency" sales growth rates. Percentage of constant currency sales growth is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales.

[0001032975-18-000016:mdna:84]
Given our global sales presence and the reporting of our financial results in U.S. Dollars, our financial results could be affected by significant shifts in currency exchange rates. See “Results of Operations” for information on the effect of currency exchange results on our net sales. If the U.S. Dollar appreciates or depreciates in comparison to other currencies in future periods, this will affect our results of operations in future periods as well.

[0001032975-18-000016:mdna:85]
Results of Operations

[0001032975-18-000016:mdna:86]
Net Sales

[0001032975-18-000016:mdna:87]
Net sales by channel for fiscal years 2018, 2017 and 2016 were as follows (Dollars in thousands):

[0001032975-18-000016:mdna:88]
|  |  | Years Ended March 31, |  | Change |
|  |  | 2018 |  | 2017 |  | 2016 |  | 2018 vs. 2017 |  | 2017 vs. 2016 |
| Retail |  | $ | 2,566,863 |  |  | $ | 2,221,427 |  |  | $ | 1,947,059 |  |  | 16 | % |  | 14 | % |
| OEM |  | — |  |  | — |  |  | 71,041 |  |  | — |  |  | (100 | ) |
| Total net sales |  | $ | 2,566,863 |  |  | $ | 2,221,427 |  |  | $ | 2,018,100 |  |  | 16 | % |  | 10 | % |

[0001032975-18-000016:mdna:89]
Retail:

[0001032975-18-000016:mdna:90]
During fiscal year 2018, retail sales increased 16%, in comparison to fiscal year 2017. If currency exchange rates had been constant in 2018 and 2017, our constant currency sales growth rate would have been 13%. We grew across almost all our product categories. Tablet & Other Accessories, Video Collaboration, Gaming, and Smart Home grew double digits, with Gaming contributing more than 8 points of the net sales growth during the year, including approximately 2 points contributed by ASTRO.

[0001032975-18-000016:mdna:91]
During fiscal year 2017, retail sales increased 14% in comparison to fiscal year 2016. If currency exchange rates had been constant in 2017 and 2016, our constant currency retail sales growth rate would have been 14.9%. We grew across almost all our product categories. Video Collaboration, Music, Gaming, and Smart Home grew double digits. Jaybird and Saitek contributed approximately 3 points to the net sales growth. We recorded a benefit of $14.4 million primarily due to a change in estimated breakage attributable to customer incentive, cooperative marketing and pricing program accruals in EMEA.

[0001032975-18-000016:mdna:92]
OEM:

[0001032975-18-000016:mdna:93]
As we exited our OEM business in December 2015, there has been no revenue since then.

[0001032975-18-000016:mdna:94]
Sales Denominated in Other Currencies

[0001032975-18-000016:mdna:95]
Although our financial results are reported in U.S. Dollars, a portion of our sales was generated in currencies other than the U.S. Dollar, such as the Euro, Chinese Renminbi, Japanese Yen, Canadian Dollar, Taiwan Dollar, British Pound and Australian Dollar. During fiscal years 2018, 2017 and 2016, 50%, 50% and 48% of our net sales were denominated in currencies other than the U.S. Dollar, respectively.

[0001032975-18-000016:mdna:96]
Retail Sales by Region

[0001032975-18-000016:mdna:97]
The following table presents the change in retail sales by region for fiscal year 2018 compared with fiscal year 2017, and fiscal year 2017 compared with fiscal year 2016:

[0001032975-18-000016:mdna:98]
|  |  | 2018 vs. 2017 |  | 2017 vs. 2016 |
|  |  | Sales Growth Rate |  | Sales Growth Rate in Constant Currency |  | Sales Growth Rate |  | Sales Growth Rate in Constant Currency |
| Americas |  | 16 | % |  | 16 | % |  | 12 | % |  | 13 | % |
| EMEA |  | 10 |  |  | 4 |  |  | 19 |  |  | 21 |  |
| Asia Pacific |  | 23 |  |  | 22 |  |  | 11 |  |  | 11 |  |

[0001032975-18-000016:mdna:99]
Americas

[0001032975-18-000016:mdna:100]
The increase in sales in fiscal year 2018 compared with fiscal year 2017 of 16% was driven by growth in Pointing Devices, Tablet & Other Accessories, Video Collaboration, Gaming, and Smart Home.

[0001032975-18-000016:mdna:101]
The increase in sales of 12% in fiscal year 2017 compared with fiscal year 2016 was driven by growth in Audio PC & Wearables, Mobile Speakers, Gaming and Keyboards & Combos, partially offset by declines in sales for Tablet & Other Accessories.

[0001032975-18-000016:mdna:102]
EMEA

[0001032975-18-000016:mdna:103]
The growth rate of 10% in fiscal year 2018 compared with fiscal year 2017 was driven by several of our product categories, with strength in Video Collaboration, Gaming, and Smart Home, partially offset by Pointing Devices and Audio PC & Wearables.

[0001032975-18-000016:mdna:104]
The increase in sales of 19% in fiscal year 2017 compared with fiscal year 2016 was driven by several of our product categories, with strength in Mobile Speakers, Keyboards & Combos, Video Collaboration and Gaming. We recorded a benefit of $14.4 million primarily due to a change in estimated breakage attributable to customer incentive, cooperative marketing and pricing program accruals in EMEA.

[0001032975-18-000016:mdna:105]
Asia Pacific

[0001032975-18-000016:mdna:106]
The growth of 23% in fiscal year 2018 compared with fiscal year 2017 was primarily driven by sales increases in Pointing Devices, Video Collaboration, Music and Gaming.

[0001032975-18-000016:mdna:107]
The increase in sales of 11% in fiscal year 2017 compared with fiscal year 2016 was primarily driven by sales increases in Gaming and Video Collaboration.

[0001032975-18-000016:mdna:108]
Net Retail Sales by Product Categories

[0001032975-18-000016:mdna:109]
Net retail sales by product categories for fiscal years 2018, 2017 and 2016 were as follows (Dollars in thousands):

[0001032975-18-000016:mdna:110]
|  |  | Years Ended March 31, |  | Change |
|  |  | 2018 |  | 2017 |  | 2016 |  | 2018 vs. 2017 |  | 2017 vs. 2016 |
| Pointing Devices |  | $ | 516,637 |  |  | $ | 501,562 |  |  | $ | 492,543 |  |  | 3 | % |  | 2 | % |
| Keyboards & Combos |  | 498,472 |  |  | 480,312 |  |  | 430,190 |  |  | 4 |  |  | 12 |  |
| PC Webcams |  | 112,147 |  |  | 107,087 |  |  | 98,641 |  |  | 5 |  |  | 9 |  |
| Tablet & Other Accessories |  | 107,942 |  |  | 76,879 |  |  | 103,886 |  |  | 40 |  |  | (26 | ) |
| Video Collaboration |  | 182,717 |  |  | 127,009 |  |  | 89,322 |  |  | 44 |  |  | 42 |  |
| Mobile Speakers |  | 314,817 |  |  | 301,021 |  |  | 229,718 |  |  | 5 |  |  | 31 |  |
| Audio-PC & Wearables |  | 252,330 |  |  | 246,390 |  |  | 196,013 |  |  | 2 |  |  | 26 |  |
| Gaming |  | 491,995 |  |  | 314,362 |  |  | 245,101 |  |  | 57 |  |  | 28 |  |
| Smart Home |  | 89,373 |  |  | 65,510 |  |  | 59,075 |  |  | 36 |  |  | 11 |  |
| Other (1) |  | 433 |  |  | 1,295 |  |  | 2,570 |  |  | (67 | ) |  | (50 | ) |
| Total Net Retail Sales |  | $ | 2,566,863 |  |  | $ | 2,221,427 |  |  | $ | 1,947,059 |  |  | 16 |  |  | 14 |  |

[0001032975-18-000016:mdna:111]
| (1) | Other category includes products out of which we currently intend to transition, or have already transitioned because they are no longer strategic to our business. |

[0001032975-18-000016:mdna:112]
Retail Sales by Product Categories:

[0001032975-18-000016:mdna:113]
Creativity & Productivity market:

[0001032975-18-000016:mdna:114]
Pointing Devices

[0001032975-18-000016:mdna:115]
Our Pointing Devices category comprises PC and Mac-related mice, touchpads and presenters.

[0001032975-18-000016:mdna:116]
During fiscal year 2018, retail sales of Pointing Devices increased 3%, in comparison to fiscal year 2017. Increases in sales of cordless mice, trackball and presentation tools, were partially offset by the decrease in the sales of corded mice.

[0001032975-18-000016:mdna:117]
During fiscal year 2017, retail sales of Pointing Devices increased 2%, in comparison to fiscal year 2016. Increases in sales of presentation tools, corded mice and other pointing devices were offset by the decrease in the sales of cordless mice.

[0001032975-18-000016:mdna:118]
Keyboards & Combos

[0001032975-18-000016:mdna:119]
Our Keyboards & Combos category comprises PC keyboards, living room keyboards and keyboard/mice combo products.

[0001032975-18-000016:mdna:120]
During fiscal year 2018, retail sales of Keyboards & Combos increased 4%, compared to fiscal year 2017. The sales increase was primarily driven by the introduction of Craft cordless keyboard and increased sales of our MK270 and MK235 wireless combo, partially offset the decreases in sales of the MK710 wireless combo and K400 Plus wireless keyboard.

[0001032975-18-000016:mdna:121]
During fiscal year 2017, retail sales of Keyboards & Combos increased 12%, compared to fiscal year 2016. The sales increase was primarily driven by the strong sales of our K400 Plus wireless keyboard and MK270 wireless combo, in addition to sales of our MK235 Combo for the full fiscal year 2017 following its launch in the fourth quarter of fiscal year 2016.

[0001032975-18-000016:mdna:122]
PC Webcams

[0001032975-18-000016:mdna:123]
Our PC Webcams category comprises PC-based webcams targeted primarily at consumers.

[0001032975-18-000016:mdna:124]
During fiscal year 2018, retail sales of PC Webcams increased 5%, compared to fiscal year 2017. The increase was primarily driven by strong sales of our 1080P Pro Stream Webcam, partially offset by the decrease in the sales of the HD Pro Webcam C920 and HD Webcam C525.

[0001032975-18-000016:mdna:125]
During fiscal year 2017, retail sales of PC Webcams increased 9%, compared to fiscal year 2016. The increase was primarily driven by strong sales of our HD Pro Webcam C920, in addition to the introduction of the C922 Pro Stream Webcam.

[0001032975-18-000016:mdna:126]
Tablet & Other Accessories

[0001032975-18-000016:mdna:127]
Our Tablet & Other Accessories category comprises keyboards and covers for tablets and smartphones as well as other accessories for mobile devices.

[0001032975-18-000016:mdna:128]
During fiscal year 2018, retail sales of Tablet & Other Accessories increased 40%, compared to fiscal year 2017. The increase was primarily driven by the introduction of Slim Folio, Slim Combo keyboard cases, and Rugged Combo keyboard case, partially offset by a decrease in sales of Create and Type+ keyboard cases.

[0001032975-18-000016:mdna:129]
During fiscal year 2017, retail sales of Tablet & Other Accessories decreased 26%, compared to fiscal year 2016. The sales decrease reflects the declining market for iPad shipments, partially offset by sales of the Create Tablet Keyboard Case for the iPad Pro for the full fiscal year 2017 following its introduction in September of fiscal year 2016.

[0001032975-18-000016:mdna:130]
Video Collaboration market:

[0001032975-18-000016:mdna:131]
Video Collaboration

[0001032975-18-000016:mdna:132]
Our Video Collaboration category primarily includes products which combine audio and video and other products that can connect any size user groups.

[0001032975-18-000016:mdna:133]
During fiscal year 2018, retail sales of Video Collaboration increased 44%, compared to fiscal year 2017. The increase was primarily due to the introductions of MeetUp and PTZ Pro 2 video conference cameras and continued success of the Logitech Group conference camera, in addition to strong sales for C930e and Brio 4K Pro webcams. The sales increase was partially offset by a decrease in sales for the PTZ Pro video conference camera.

[0001032975-18-000016:mdna:134]
During fiscal year 2017, retail sales of Video Collaboration increased 42%, compared to fiscal year 2016. The increase was primarily due to the continued success of the Logitech Group conference camera.

[0001032975-18-000016:mdna:135]
Music market:

[0001032975-18-000016:mdna:136]
Mobile Speakers

[0001032975-18-000016:mdna:137]
Our Mobile Speakers category is made up entirely of wireless Bluetooth and Wi-Fi speakers.

[0001032975-18-000016:mdna:138]
During fiscal year 2018, retail sales of Mobile Speakers increased 5%, compared to fiscal year 2017. Mobile Speaker sales increased primarily due to the increased sales from the Ultimate Ears WONDERBOOM and the introduction of the Ultimate Ears BLAST and MEGABLAST, which were both released in the third quarter of fiscal year 2018, partially offset by the decreases in sales of the Ultimate Ears BOOM 2, Ultimate Ears MEGABOOM, and Ultimate Ears ROLL 2.

[0001032975-18-000016:mdna:139]
During fiscal year 2017, retail sales of Mobile Speakers increased 31%, compared to fiscal year 2016. Mobile Speaker sales increased primarily due to sales of the Ultimate Ears BOOM 2 for the full fiscal year 2017 following its launch in the second quarter of fiscal year 2016 as well as the continued success of the Ultimate Ears MEGABOOM.

[0001032975-18-000016:mdna:140]
Audio-PC & Wearables

[0001032975-18-000016:mdna:141]
Our Audio-PC & Wearables category comprises PC speakers, PC headsets, in-ear headphones and premium wireless audio wearables.

[0001032975-18-000016:mdna:142]
During fiscal year 2018, retail sales of Audio-PC & Wearables increased 2%, compared to fiscal year 2017. The increase was primarily driven by the continued success of the Jaybird X3 earbuds, in addition to the introduction of the Jaybird RUN earbuds launched in the third quarter of fiscal year 2018, partially offset by the decrease in the sales of the Jaybird Freedom F5 earbuds. Jaybird growth was partially offset by a decline in desktop speakers.

[0001032975-18-000016:mdna:143]
During fiscal year 2017, retail sales of Audio-PC & Wearables increased 26%, compared to fiscal year 2016. The increase was primarily driven by the Jaybird Freedom F5 earbuds and the Jaybird X2 earbuds resulting from the Jaybird Acquisition in the first quarter of fiscal year 2017 (see Note 3 - "Business Acquisitions" to the

[0001032975-18-000016:mdna:144]
consolidated financial statements) and X3 Sport Bluetooth earbuds launched in the third quarter of fiscal year 2017. The growth was partially offset by a decline of our PC speakers and headsets.

[0001032975-18-000016:mdna:145]
Gaming market:

[0001032975-18-000016:mdna:146]
Gaming

[0001032975-18-000016:mdna:147]
Our Gaming category comprises gaming mice, keyboards, headsets, gamepads, steering wheels, Saitek simulation controllers and ASTRO console gaming headsets.

[0001032975-18-000016:mdna:148]
During fiscal year 2018, retail sales of Gaming increased 57%, compared to fiscal year 2017. Growth in Gaming was broad-based, especially driven by the ASTRO Acquisition, the sales increase of the G29 Driving Force steering wheel, the G502 Proteus Spectrum gaming mouse, the G203 gaming mouse and the introduction of the G903 gaming mouse. For fiscal year 2018, ASTRO contributed $54.1 million to net sales.

[0001032975-18-000016:mdna:149]
During fiscal year 2017, retail sales of Gaming increased 28%, compared to fiscal year 2016. The increase was primarily driven by the continued success of our G502 Proteus Spectrum gaming mouse, G900 Chaos Spectrum gaming mouse, G933 Artemis Spectrum gaming headset and G910 Orion Spectrum RGB mechanical gaming keyboard.

[0001032975-18-000016:mdna:150]
Smart Home market:

[0001032975-18-000016:mdna:151]
Smart Home

[0001032975-18-000016:mdna:152]
Our Smart Home category includes our Harmony line of advanced home entertainment controllers, new products dedicated to controlling emerging categories of connected smart home devices such as lighting, thermostats and door locks, and home security camera.

[0001032975-18-000016:mdna:153]
During fiscal year 2018, retail sales of Smart Home increased 36%, compared to fiscal year 2017. The increase was primarily due to the introduction of our Circle 2 wired and wireless home security cameras, in addition to our continued success for our Harmony Elite remote, partially offset by the sales decrease of Harmony 650 remote. We saw strong demand for our voice-enabled Harmony Hub products balanced against a decline in the traditional universal remote market.

[0001032975-18-000016:mdna:154]
During fiscal year 2017, retail sales of Smart Home increased 11%, compared to fiscal year 2016. The increase was primarily due to the continued success of our Harmony Elite remote.

[0001032975-18-000016:mdna:155]
Gross Profit

[0001032975-18-000016:mdna:156]
Gross profit for fiscal years 2018, 2017 and 2016 was as follows (Dollars in thousands):

[0001032975-18-000016:mdna:157]
|  |  | Years Ended March 31, |
|  |  | 2018 |  | 2017 |  | 2016 |
| Net sales |  | $ | 2,566,863 |  |  | $ | 2,221,427 |  |  | $ | 2,018,100 |  |
| Gross profit |  | $ | 909,241 |  |  | $ | 820,041 |  |  | $ | 681,047 |  |
| Gross margin |  | 35.4 | % |  | 36.9 | % |  | 33.7 | % |

[0001032975-18-000016:mdna:158]
Gross profit consists of net sales, less cost of goods sold (which includes materials, direct labor and related overhead costs, costs of manufacturing facilities, royalties, costs of purchasing components from outside suppliers, distribution costs, warranty costs, customer support, shipping and handling costs, outside processing costs and write-down of inventories), amortization of intangible assets and purchase accounting effect on inventory.

[0001032975-18-000016:mdna:159]
Gross margin decreased by 150 basis points to 35.4% during fiscal year 2018, compared to fiscal year 2017. The decrease in gross margin was primarily driven by increases in pricing programs and incentive and marketing activities, additional costs from the transition of the distribution center in North America in the third quarter of fiscal year 2018, and product mix, partially offset by product cost reductions and favorable currency exchange rates. In addition, in fiscal year 2017, we recorded a benefit of $14.4 million primarily due to a change in estimated breakage attributable to customer incentive, cooperative marketing and pricing program accruals in EMEA.

[0001032975-18-000016:mdna:160]
Gross margin increased by 320 basis points to 36.9% during fiscal year 2017, compared to fiscal year 2016. The increase in gross margin was primarily driven by product cost reductions, our exit from the OEM business in fiscal year 2016, a benefit of $14.4 million primarily due to a change in estimated breakage attributable to customer incentive, cooperative marketing and pricing program accruals in EMEA, as well as greater supply chain

[0001032975-18-000016:mdna:161]
efficiencies, partially offset by an increase of promotions, unfavorable currency exchange rates, and amortization of intangible assets and purchase accounting effect on inventory from business acquisitions.

[0001032975-18-000016:mdna:162]
Operating Expenses

[0001032975-18-000016:mdna:163]
Operating expenses for fiscal years 2018, 2017 and 2016 were as follows (Dollars in thousands):

[0001032975-18-000016:mdna:164]
|  |  | Years Ended March 31, |
|  |  | 2018 |  | 2017 |  | 2016 |
| Marketing and selling |  | $ | 435,489 |  |  | $ | 379,641 |  |  | $ | 319,015 |  |
| % of net sales |  | 17.0 | % |  | 17.1 | % |  | 15.8 | % |
| Research and development |  | 143,760 |  |  | 130,525 |  |  | 113,176 |  |
| % of net sales |  | 5.6 | % |  | 5.9 | % |  | 5.6 | % |
| General and administrative |  | 96,353 |  |  | 100,270 |  |  | 101,012 |  |
| % of net sales |  | 3.8 | % |  | 4.5 | % |  | 5.0 | % |
| Amortization of intangible assets and acquisition-related costs |  | 8,930 |  |  | 5,814 |  |  | 984 |  |
| % of net sales |  | 0.3 | % |  | 0.3 | % |  | — | % |
| Change in fair value of contingent consideration for business acquisition |  | (4,908 | ) |  | (8,092 | ) |  | — |  |
| % of net sales |  | (0.2 | )% |  | (0.4 | )% |  | — | % |
| Restructuring charges (credits), net |  | (116 | ) |  | 23 |  |  | 17,802 |  |
| % of net sales |  | — | % |  | — | % |  | 0.9 | % |
| Total operating expenses |  | $ | 679,508 |  |  | $ | 608,181 |  |  | $ | 551,989 |  |
| % of net sales |  | 26.5 | % |  | 27.4 | % |  | 27.4 | % |

[0001032975-18-000016:mdna:165]
The increase in total operating expenses during fiscal year 2018, compared to fiscal year 2017, was mainly due to increases in marketing and selling expenses, research and development expenses, amortization of intangibles from the business acquisitions, and a lower credit from the change in fair value of contingent consideration for business acquisition, partially offset by the decrease in general and administrative expenses.

[0001032975-18-000016:mdna:166]
The increase in total operating expenses during fiscal year 2017, compared to fiscal year 2016, was mainly due to increases in marketing and selling expenses, research and development expenses, amortization of intangible assets from the business acquisitions, partially offset by the decrease in restructuring charges and a credit from the change in fair value of contingent consideration for business acquisition.

[0001032975-18-000016:mdna:167]
Marketing and Selling

[0001032975-18-000016:mdna:168]
Marketing and selling expenses consist of personnel and related overhead costs, corporate and product marketing, promotions, advertising, trade shows, customer and technical support and facilities costs.

[0001032975-18-000016:mdna:169]
During fiscal year 2018, marketing and selling expenses increased $55.8 million, compared to fiscal year 2017. The increase was primarily driven by $23.2 million higher personnel-related costs due to increased headcount during the last twelve months to expand our marketing team to support our increased advertising and marketing efforts for our products, including the increased headcount resulting from the ASTRO Acquisition. Additionally, there was a $30.2 million increase in expenses for external advertising and marketing.

[0001032975-18-000016:mdna:170]
During fiscal year 2017, marketing and selling expenses increased $60.6 million, compared to fiscal year 2016. The increase was primarily driven by $43.8 million higher personnel-related costs due to increased headcount during fiscal year 2017 to expand our marketing team to support the advertising and marketing efforts for our products, including the increased headcount resulting from the Jaybird Acquisition and Saitek Acquisition, and increased variable compensation linked to stronger performance during fiscal year 2017. Additionally, there was a  $18.4 million increase in expenses for external advertising and marketing.

[0001032975-18-000016:mdna:171]
Research and Development

[0001032975-18-000016:mdna:172]
Research and development expenses consist of personnel and related overhead costs for contractors and outside consultants, supplies and materials, equipment depreciation and facilities costs, all associated with the design and development of new products and enhancements of existing products.

[0001032975-18-000016:mdna:173]
During fiscal year 2018, research and development expenses increased $13.2 million, compared to fiscal year 2017. The increase was primarily driven by higher personnel-related costs for the development of new products and increased headcount from business acquisitions.

[0001032975-18-000016:mdna:174]
During fiscal year 2017, research and development expenses increased $17.3 million, compared to fiscal year 2016. The increase was primarily driven by $13.9 million higher personnel-related costs for the development of new products, increased headcount from business acquisitions, and increased variable compensation linked to stronger performance during fiscal year 2017.

[0001032975-18-000016:mdna:175]
General and Administrative

[0001032975-18-000016:mdna:176]
General and administrative expenses consist primarily of personnel and related overhead and facilities costs for the finance, information systems, executives, human resources and legal functions.

[0001032975-18-000016:mdna:177]
During fiscal year 2018, general and administrative expenses decreased $3.9 million, compared to fiscal year 2017. The decrease was primarily due to a $6.8 million reduction related to external expenses mainly consulting expense, partially offset by a $2.6 million increase in personnel-related costs.

[0001032975-18-000016:mdna:178]
During fiscal year 2017, general and administrative expenses decreased $0.7 million, compared to fiscal year 2016. The decrease was primarily due to a $3.5 million reduction related to the prior year's accrual for our settlement with the SEC and a $3.1 million decrease in information technology costs, partially offset by a $6.1 million increase in personnel-related costs largely driven by higher variable compensation linked to stronger performance during the fiscal year 2017.

[0001032975-18-000016:mdna:179]
Amortization of Intangibles and Acquisition-Related Costs

[0001032975-18-000016:mdna:180]
Amortization of intangibles included in operating expense and acquisition-related costs during fiscal years 2018, 2017 and 2016 were as follows (in thousands):

[0001032975-18-000016:mdna:181]
|  |  | Years Ended March 31, |
|  |  | 2018 |  | 2017 |  | 2016 |
| Amortization of intangible assets |  | $ | 7,518 |  |  | $ | 4,352 |  |  | $ | 448 |  |
| Acquisition-related costs |  | 1,412 |  |  | 1,462 |  |  | 536 |  |
| Total |  | $ | 8,930 |  |  | $ | 5,814 |  |  | $ | 984 |  |

[0001032975-18-000016:mdna:182]
Amortization of intangible assets consists of amortization of acquired intangible assets including customer relationships and trade names. Acquisition-related costs include legal expense, due diligence costs, and other professional costs incurred for business acquisitions.

[0001032975-18-000016:mdna:183]
The increase in amortization of intangible assets from fiscal year 2017 to 2018 was primarily driven by the ASTRO Acquisition. The increase in amortization of intangible assets from fiscal year 2016 to 2017 was driven by the Jaybird and Saitek acquisitions.

[0001032975-18-000016:mdna:184]
Change in Fair Value of Contingent Consideration for Business Acquisition

[0001032975-18-000016:mdna:185]
The change in fair value of contingent consideration during fiscal years 2018 and 2017 is primarily due to lower-than-expected net sales of Jaybird products, and revised projected net sales of Jaybird products during the remaining earn-out period, primarily driven by supply constraints, an evolving product portfolio and changes in the competitive target market (see "Note 10 – Fair Value Measurement" to the consolidated financial statements).

[0001032975-18-000016:mdna:186]
In October 2017, Logitech and the sellers of Jaybird entered into an agreement fully, irrevocably and unconditionally releasing Logitech from the earn-out rights and payments in exchange for $5.0 million in cash. We paid the $5.0 million in November 2017 and included the same as financing activities on our consolidated statements of cash flows.

[0001032975-18-000016:mdna:187]
Restructuring Charges (Credits)

[0001032975-18-000016:mdna:188]
The following table summarizes restructuring-related activities during the fiscal years 2018, 2017 and 2016 from continuing operations (in thousands):

[0001032975-18-000016:mdna:189]
|  |  | Restructuring - Continuing Operations |
|  |  | TerminationBenefits |  | Lease ExitCosts |  | Other |  | Total |
| Accrual balance at March 31, 2015 |  | $ | — |  |  | $ | 954 |  |  | $ | — |  |  | $ | 954 |  |
| Charges, net |  | 17,280 |  |  | 337 |  |  | 185 |  |  | 17,802 |  |
| Cash payments |  | (11,373 | ) |  | (1,166 | ) |  | (185 | ) |  | (12,724 | ) |
| Accrual balance at March 31, 2016 |  | $ | 5,907 |  |  | $ | 125 |  |  | $ | — |  |  | $ | 6,032 |  |
| Charges, net |  | 23 |  |  | — |  |  | — |  |  | 23 |  |
| Cash payments |  | (5,195 | ) |  | (125 | ) |  | — |  |  | (5,320 | ) |
| Accrual balance at March 31, 2017 |  | 735 |  |  | — |  |  | — |  |  | 735 |  |
| Credits, net |  | (116 | ) |  | — |  |  | — |  |  | (116 | ) |
| Cash payments |  | (619 | ) |  | — |  |  | — |  |  | (619 | ) |
| Accrual balance at March 31, 2018 |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |

[0001032975-18-000016:mdna:190]
During the first quarter of fiscal year 2016, we implemented a restructuring plan to exit the OEM business, reorganize Lifesize to sharpen its focus on its cloud-based offering, and streamline our overall cost structure, including overhead and infrastructure cost reductions with a targeted resource realignment. Restructuring charges incurred under this plan primarily consisted of severance and other ongoing and one-time termination benefits. Charges and other costs related to the workforce reduction and structure realignment are presented as restructuring charges in the consolidated statements of operations. We substantially completed this restructuring plan by the fourth quarter of fiscal year 2016.

[0001032975-18-000016:mdna:191]
On a total company basis, including the Lifesize video conferencing business as reported in discontinued operations, we have incurred $25.4 million under this restructuring plan, including $24.3 million for cash severance and other personnel costs.

[0001032975-18-000016:mdna:192]
Other Income (Expense), Net

[0001032975-18-000016:mdna:193]
Other income and expense for fiscal years 2018, 2017 and 2016 were as follows (in thousands):

[0001032975-18-000016:mdna:194]
|  |  | Years Ended March 31, |
|  |  | 2018 |  | 2017 |  | 2016 |
| Investment income (loss) related to a deferred compensation plan |  | $ | 1,386 |  |  | $ | 1,343 |  |  | $ | (364 | ) |
| Currency exchange gain (loss), net |  | (4,613 | ) |  | 169 |  |  | 2,110 |  |
| Other |  | 790 |  |  | 165 |  |  | (122 | ) |
| Total |  | $ | (2,437 | ) |  | $ | 1,677 |  |  | $ | 1,624 |  |

[0001032975-18-000016:mdna:195]
Investment income (loss) related to a deferred compensation plan for fiscal years 2018, 2017 and 2016 represents earnings, gains, and losses on trading investments related to a deferred compensation plan offered by one of our subsidiaries.

[0001032975-18-000016:mdna:196]
Currency exchange gains or losses relate to balances denominated in currencies other than the functional currency in our subsidiaries, as well as to the sale of currencies, and to gains or losses recognized on foreign currency exchange forward contracts. We do not speculate in currency positions, but we are alert to opportunities to maximize currency exchange gains and minimize currency exchange losses.

[0001032975-18-000016:mdna:197]
Provision for Income Taxes

[0001032975-18-000016:mdna:198]
The provision for income taxes and the effective income tax rate for fiscal years 2018, 2017 and 2016 were as follows (in thousands):

[0001032975-18-000016:mdna:199]
|  |  | Years Ended March 31, |
|  |  | 2018 |  | 2017 |  | 2016 |
| Provision for income taxes |  | $ | 23,723 |  |  | $ | 9,113 |  |  | $ | 3,110 |  |
| Effective income tax rate |  | 10.2 | % |  | 4.2 | % |  | 2.4 | % |

[0001032975-18-000016:mdna:200]
The changes in the effective income tax rate between fiscal years 2018 and 2017 were primarily driven by provisional impacts in fiscal year 2018 from the Tax Act that was signed into law in the United States on December 22, 2017.  We recorded a provisional income tax charge of $21.7 million from the remeasurement of deferred tax assets and liabilities, net of the release of valuation allowance of $0.6 million to reflect the effects of the enacted reduction in corporate income tax rate from 35% to 21%. We recognized $13.4 million of excess tax benefits, net of shortfalls in fiscal year 2018 after the adoption of ASU 2016-09. Furthermore, there was a tax benefit of $8.3 million in fiscal year 2018 related to the reversal of uncertain tax positions resulting from the expiration of the statutes of limitations, compared to $15.4 million in fiscal year 2017.

[0001032975-18-000016:mdna:201]
The changes in the effective income tax rate between fiscal years 2017 and 2016 were primarily due to the mix of income and losses in the various tax jurisdictions in which we operate.  In fiscal year 2016, besides a tax benefit of $16.1 million related to the reversal of uncertain tax positions resulting from the expiration of the statutes of limitations, there was a tax benefit of $2.2 million from the preferential income tax rate reduction pursuant to the High and New Technology Enterprise Program in China.

[0001032975-18-000016:mdna:202]
As of March 31, 2018 and March 31, 2017, the total amounts of unrecognized tax benefits due to uncertain tax positions were $69.1 million and $63.7 million, respectively, all of which would affect the effective income tax rates if recognized.

[0001032975-18-000016:mdna:203]
As of March 31, 2018, we had $35.0 million in non-current income taxes payable, including interest and penalties, related to our income tax liability for uncertain tax positions. As of March 31, 2017, we had $51.8 million in non-current income taxes payable and $1.5 million in current income taxes payable, including interest and penalties, related to our income tax liability for uncertain tax positions. We recognize interest and penalties related to unrecognized tax positions in income tax expense. We recognized $0.6 million, $0.7 million and $0.3 million in interest and penalties in income tax expense during fiscal years 2018, 2017 and 2016, respectively. As of March 31, 2018, 2017 and 2016, we had $2.3 million, $3.0 million and $3.6 million of accrued interest and penalties related to uncertain tax positions, respectively.

[0001032975-18-000016:mdna:204]
We file Swiss and foreign tax returns. We received final tax assessments in Switzerland through fiscal year 2014.  For other foreign jurisdictions such as the United States, we are generally not subject to tax examinations for years prior to fiscal year 2015. We are under examination and have received assessment notices in foreign tax jurisdictions. If the examinations are resolved unfavorably, there is a possibility they may have a material negative impact on our results of operations.

[0001032975-18-000016:mdna:205]
Liquidity and Capital Resources

[0001032975-18-000016:mdna:206]
Cash Balances, Available Borrowings, and Capital Resources

[0001032975-18-000016:mdna:207]
At March 31, 2018, we had cash and cash equivalents of $641.9 million, compared with $547.5 million at March 31, 2017. Our cash and cash equivalents consist of bank demand deposits and short-term time deposits of which 54% is held in Switzerland, 19% is held in Germany, 11% is held in the UK and 10% is held in Hong Kong and China. We do not expect to incur any material adverse tax impact except for what has been recognized or be significantly inhibited by any country in which we do business from the repatriation of funds to Switzerland, our home domicile.

[0001032975-18-000016:mdna:208]
At March 31, 2018, our working capital was $597.4 million, compared with working capital of $520.8 million at March 31, 2017. The increase in working capital over fiscal year 2017 was primarily due to higher balances of cash and cash equivalents, accounts receivable, net and other current assets, partially offset by higher accounts payable and accrued and other current liabilities.

[0001032975-18-000016:mdna:209]
We had several uncommitted, unsecured bank lines of credit aggregating to $84.5 million as of March 31, 2018. There are no financial covenants under these lines of credit with which we must comply. As of March 31, 2018, we had outstanding bank guarantees of $49.8 million under these lines of credit.

[0001032975-18-000016:mdna:210]
The following table presents selected financial information and statistics for fiscal years 2018, 2017 and 2016 (Dollars in thousands):

[0001032975-18-000016:mdna:211]
|  |  | March 31, |
|  |  | 2018 |  | 2017 |  | 2016 |
| Accounts receivable, net |  | $ | 214,885 |  |  | $ | 185,179 |  |  | $ | 142,778 |  |
| Accounts payable |  | $ | 293,988 |  |  | $ | 274,805 |  |  | $ | 241,166 |  |
| Inventories |  | $ | 259,906 |  |  | $ | 253,401 |  |  | $ | 228,786 |  |
| Days sales in accounts receivable (DSO)(Days)(1) |  | 33 |  |  | 33 |  |  | 30 |  |
| Days accounts payable outstanding (DPO) (Days)(2) |  | 70 |  |  | 79 |  |  | 75 |  |
| Inventory turnover (ITO)(x)(3) |  | 5.9 |  |  | 4.9 |  |  | 5.0 |  |

[0001032975-18-000016:mdna:212]
______________________________

[0001032975-18-000016:mdna:213]
| (1) | DSO is determined using ending accounts receivable, net as of the most recent quarter-end and net sales for the most recent quarter. |

[0001032975-18-000016:mdna:214]
| (2) | DPO is determined using ending accounts payable as of the most recent quarter-end and cost of goods sold for the most recent quarter. |

[0001032975-18-000016:mdna:215]
| (3) | ITO is determined using ending inventories and the annualized cost of goods sold (based on the most recent quarterly cost of goods sold). |

[0001032975-18-000016:mdna:216]
DSO as of March 31, 2018 remained consistent, compared to March 31, 2017. DSO as of March 31, 2017 increased three days, compared to March 31, 2016, primarily due to the timing of net sales and customer payments.

[0001032975-18-000016:mdna:217]
DPO as of March 31, 2018 decreased nine days, compared to March 31, 2017, primarily due to the timing of purchases and payments. DPO as of March 31, 2017 increased four days, compared to March 31, 2016, primarily due to increase in inventories and the timing of payments.

[0001032975-18-000016:mdna:218]
ITO as of March 31, 2018 was higher compared to March 31, 2017 due to higher sales. ITO as of March 31, 2017 remained consistent compared to March 31, 2016.

[0001032975-18-000016:mdna:219]
If we are not successful in launching and phasing in our new products launched during the current fiscal year, or we are not able to sell the new products at the prices planned, it could have a material impact on our revenue, gross profit margin, operating results including operating cash flow, and inventory turnover in the future.

[0001032975-18-000016:mdna:220]
During fiscal year 2018, we generated $346.3 million in cash from operating activities. Our main sources of operating cash flows were from net income after adding back non-cash expenses of depreciation, amortization, and share-based compensation expense, and from changes in operating assets and liabilities. The increase in accounts receivable, net was primarily driven by higher business volumes. The increase in accounts payable was primarily driven by the timing of purchases and the timing of payments. The decrease in inventories net of effect of the acquisition was primarily driven by higher business volumes. The increase in accrued and other liabilities was primarily due to higher promotions and marketing activities for our indirect customers.

[0001032975-18-000016:mdna:221]
Net cash used in investing activities was $128.7 million, primarily due to $88.3 million of the purchase price (net of cash acquired) for business acquisitions, $39.7 million of purchases of property, plant, and equipment, and $1.2 million of investments in privately held companies.

[0001032975-18-000016:mdna:222]
Net cash used in financing activities was $127.9 million, primarily for the $104.2 million cash dividends paid during the year, $30.7 million repurchases of our registered shares and $29.8 million tax withholdings related to net share settlements of restricted stock units, partially offset by $41.9 million in proceeds received from the sale of shares upon exercise of options and purchase rights. We also paid $5.0 million for contingent consideration related to the Jaybird Acquisition.

[0001032975-18-000016:mdna:223]
Our expenditures for property, plant and equipment during fiscal years 2018, 2017 and 2016 were primarily for tooling and equipment, computer hardware and software and leasehold improvements.

[0001032975-18-000016:mdna:224]
Our expenditures for property, plant and equipment increased during fiscal year 2018, compared to fiscal year 2017, primarily due to a higher amount of tooling purchases. Our expenditures for property, plant and equipment decreased during fiscal year 2017, compared to fiscal year 2016, due to a lower amount of tooling purchases.

[0001032975-18-000016:mdna:225]
Our payments for acquisitions, net of cash acquired, during fiscal year 2018, were primarily for the ASTRO Acquisition during the period (refer to "Note 3 - Business Acquisitions" to the consolidated financial statements).  Our payments for acquisitions, net of cash acquired, during fiscal year 2017, were for the Jaybird Acquisition and the Saitek Acquisition during the period (refer to "Note 3 - Business Acquisitions" to the consolidated financial statements).

[0001032975-18-000016:mdna:226]
During fiscal year 2016, the net payments for the divestiture of discontinued operations were $1.4 million.

[0001032975-18-000016:mdna:227]
The purchases and sales of trading investments during fiscal years 2018, 2017 and 2016 represent mutual fund activity directed by participants in a deferred compensation plan offered by one of our subsidiaries. The mutual funds are held by a Rabbi Trust.

[0001032975-18-000016:mdna:228]
Excess tax benefit realized from share-based compensation included in cash flows from financing activities has been reclassified in operating cash flows starting in the first quarter of our fiscal year 2018 on a retrospective basis when we adopted ASU 2016-09. Refer to Note 2 to the consolidated financial statements included in this Annual Report on Form 10-K for recent accounting pronouncements adopted.

[0001032975-18-000016:mdna:229]
During fiscal year 2018, there was a $4.7 million gain of currency translation exchange rate effect on cash and cash equivalents, compared to a loss of $5.4 million of currency translation exchange rate effect during fiscal year 2017, and a $1.4 million gain of currency translation exchange rate effect during fiscal year 2016. Higher currency translation exchange effects during fiscal years 2018 and 2017 were primarily due to the strengthening of the Euro versus the U.S. Dollar by 15% in 2018 and weakening of the Euro versus the U.S. Dollar by 6% in 2017, respectively.

[0001032975-18-000016:mdna:230]
Cash Outlook

[0001032975-18-000016:mdna:231]
Our principal sources of liquidity are our cash and cash equivalents, cash flow generated from operations and, to a much lesser extent, capital markets and borrowings. Our future working capital requirements and capital expenditures may increase to support investment in product innovations and growth opportunities or to acquire or invest in complementary businesses, products, services, and technologies.

[0001032975-18-000016:mdna:232]
In May 2018, the Board of Directors recommended that the Company pay CHF110.7 million ($115.7 million based on the exchange rate on March 31, 2018) in cash dividends for fiscal year 2018. In fiscal year 2018, we paid a cash dividend of CHF100.0 million (U.S. Dollar amount of $104.2 million) out of retained earnings. During fiscal year 2017, we paid a cash dividend of CHF 90.2 million (U.S. Dollar amount of $93.1 million) out of retained earnings. During fiscal year 2016, we paid a cash dividend of CHF 83.1 million (U.S. Dollar amount of $85.9 million) out of retained earnings.

[0001032975-18-000016:mdna:233]
In March 2014, the Board of Directors approved the 2014 share buyback program, which authorizes the Company to use up to $250.0 million to purchase its own shares. This share buyback program expired in April 2017.

[0001032975-18-000016:mdna:234]
In March 2017, our Board of Directors approved a new share buyback program, which authorizes us to invest up to $250.0 million to purchase our own shares, following the expiration date of the 2014 share buyback program. The new program was approved by the Swiss Takeover Board in May 2017. Although we enter into trading plans for systematic repurchases (e.g. 10b5-1 trading plans) from time to time, our share buyback program provides us with the opportunity to make opportunistic repurchases during periods of favorable market conditions and is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Opportunistic purchases may be started or stopped at any time without prior notice depending on market conditions and other factors.  As of March 31, 2018, the remaining amount that may be repurchased under the program is $219.9 million.

[0001032975-18-000016:mdna:235]
Starting with fiscal year 2017, we changed the payment frequency of our employee performance bonus plan from semi-annual payments to an annual payment. The full year bonus for a fiscal year is expected to be made in the first quarter of the following fiscal year, and the operating cash flow for that period could be negative as a result.

[0001032975-18-000016:mdna:236]
Our other contractual obligations and commitments that require cash are described in the following sections.

[0001032975-18-000016:mdna:237]
For over ten years, we have generated positive cash flows from our operating activities, including cash from operations of $346.3 million, $288.4 million and $185.2 million during fiscal years 2018, 2017, and 2016,

[0001032975-18-000016:mdna:238]
respectively. If we do not generate sufficient operating cash flows to support our operations and future planned cash requirements, our operations could be harmed and our access to credit facilities could be restricted or eliminated. However, we believe that the trend of our historical cash flow generation, our projections of future operations and our available cash balances will provide sufficient liquidity to fund our operations for at least the next 12 months.

[0001032975-18-000016:mdna:239]
Contractual Obligations and Commitments

[0001032975-18-000016:mdna:240]
The following table summarizes our contractual obligations and commitments as of March 31, 2018 (in thousands):

[0001032975-18-000016:mdna:241]
|  |  |  |  | Payments Due by Period |
|  |  | March 31, 2018 | <1 year |  | 1-3 years |  | 4-5 years |  | >5 years |
| Inventory purchase commitments |  | $ | 237,110 |  |  | $ | 237,110 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Capital purchase commitments |  | 9,569 |  |  | 9,569 |  |  | — |  |  | — |  |  | — |  |
| Expected contribution to employee benefit plan |  | 5,727 |  |  | 5,727 |  |  | * |  |  | * |  |  | * |  |
| Operating leases obligations |  | 44,501 |  |  | 13,144 |  |  | 18,941 |  |  | 9,964 |  |  | 2,452 |  |
| Total |  | $ | 296,907 |  |  | $ | 265,550 |  |  | $ | 18,941 |  |  | $ | 9,964 |  |  | $ | 2,452 |  |

[0001032975-18-000016:mdna:242]
* Expected contribution to employee benefit plan: Commitments under the retirement plans relate to expected contributions to be made to our defined benefit plans for the next year only. We fund our pension plans so that we meet at least the minimum contribution requirements, as established by local government, funding and taxing authorities. Expected contributions and payments to our defined benefit pension plans and non-retirement post-employment benefit plans beyond one year are excluded from the contractual obligations table because they are dependent on numerous factors that may result in a wide range of outcomes and thus are impractical to estimate. For more information on our defined benefit pension plans and non-retirement post-employment benefit plans, see Note 6 to the Consolidated Financial Statements in Item 8, which is incorporated herein by reference.

[0001032975-18-000016:mdna:243]
Purchase Commitments

[0001032975-18-000016:mdna:244]
As of March 31, 2018, we have non-cancelable purchase commitments of $237.1 million for inventory purchases made in the normal course of business to original design manufacturers, contract manufacturers and other suppliers, the majority of which are expected to be fulfilled during the first two quarters of fiscal year 2019. We recorded a liability for firm, non-cancelable, and unhedged inventory purchase commitments in excess of anticipated demand or net realizable value consistent with our valuation of excess and obsolete inventory. As of March 31, 2018, the liability for these purchase commitments was $12.6 million and is recorded in accrued and other current liabilities and is not included in the preceding table. We have firm purchase commitments of $9.6 million for capital expenditures, primarily related to commitments for tooling, computer hardware and leasehold improvements. We expect to continue making capital expenditures in the future to support product development activities and ongoing and expanded operations. Although open purchase commitments are considered enforceable and legally binding, the terms generally allow us the option to reschedule and adjust our requirements based on business needs prior to delivery of goods.

[0001032975-18-000016:mdna:245]
Operating Leases Obligation

[0001032975-18-000016:mdna:246]
We lease facilities under operating leases, certain of which require us to pay property taxes, insurance and maintenance costs. Operating leases for facilities are generally renewable at our option and usually include escalation clauses linked to inflation. The remaining terms of our non-cancelable operating leases expire in various years through 2030.

[0001032975-18-000016:mdna:247]
Income Taxes Payable

[0001032975-18-000016:mdna:248]
As of March 31, 2018, we had $35.0 million in non-current income taxes payable, including interest and penalties, related to our income tax liability for uncertain tax positions. At this time, we are unable to make a reasonably reliable estimate of the timing of payments in individual years in connection with these tax liabilities; therefore, such amounts are not included in the above contractual obligation table.

[0001032975-18-000016:mdna:249]
Investment Commitments

[0001032975-18-000016:mdna:250]
During 2015, we entered into a limited partnership agreement with a private investment fund specialized in early-stage start-up consumer hardware electronics companies and committed a capital contribution of $4.0 million over the life of the fund. As of March 31, 2018, $1.1 million of the committed capital contribution has not yet been called by the fund.

[0001032975-18-000016:mdna:251]
Guarantees

[0001032975-18-000016:mdna:252]
Logitech Europe S.A. guaranteed payments of two third-party contract manufacturers' purchase obligations. As of March 31, 2018, the maximum amount of these guarantees was $3.8 million, of which $1.0 million of guaranteed purchase obligations were outstanding.

[0001032975-18-000016:mdna:253]
Indemnifications

[0001032975-18-000016:mdna:254]
We indemnify certain of our suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys' fees. As of March 31, 2018, no amounts have been accrued for indemnification provisions. We do not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under our indemnification arrangements.

[0001032975-18-000016:mdna:255]
We also indemnify our current and former directors and certain of our current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. We are unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not capped, the obligations are conditional in nature, and the facts and circumstances involved in any situation that might arise are variable.

[0001032975-18-000016:mdna:256]
The Stock Purchase Agreement that we entered into in connection with the investment by three venture capital firms in Lifesize, Inc. contains representations, warranties and covenants of Logitech and Lifesize, Inc. to the Venture Investors. Subject to certain limitations, we have agreed to indemnify the Venture Investors and certain persons related to the Venture Investors for certain losses resulting from breaches of or inaccuracies in such representations, warranties and covenants as well as certain other obligations, including third-party expenses, restructuring costs and pre-closing tax obligations of Lifesize.

[0001032975-18-000016:mdna:257]
Off-Balance Sheet Arrangements

[0001032975-18-000016:mdna:258]
We do not have any off-balance sheet arrangements that have, or are reasonably likely to have, a current or future effect on our financial condition, changes in financial condition, revenues or expenses, results of operations, liquidity, capital expenditures or capital resources that are material to investors.
