# LOGI notes — 0001032975-18-000016


## logi:ScheduleOfAssumptionsForSharebasedAwardsTableTextBlock

[0001032975-18-000016:notes:1]
The grant date fair value of the awards using the Black-Scholes-Merton option-pricing valuation model and Monte-Carlo simulation method are determined with the following assumptions and values:

[0001032975-18-000016:notes:2]
| Employee Stock Purchase Plans |  | Years Ended March 31, |
|  |  | 2018 |  | 2017 |  | 2016 |
| Dividend yield |  | 1.67 | % |  | 2.50 | % |  | 3.47 | % |
| Risk-free interest rate |  | 1.37 | % |  | 0.51 | % |  | 0.29 | % |
| Expected volatility |  | 27 | % |  | 35 | % |  | 26 | % |
| Expected life (years) |  | 0.5 |  |  | 0.5 |  |  | 0.5 |  |
| Weighted average grant date fair value per share |  | $ | 8.69 |  |  | $ | 5.73 |  |  | $ | 3.29 |  |

[0001032975-18-000016:notes:3]
| RSUs with Market Conditions |  | Years Ended March 31, |
|  |  | 2018 |  | 2017 |  | 2016 |
| Dividend yield |  | 1.75 | % |  | 3.29 | % |  | 3.78 | % |
| Risk-free interest rate |  | 1.40 | % |  | 0.86 | % |  | 0.84 | % |
| Expected volatility |  | 31 | % |  | 34 | % |  | 38 | % |
| Expected life (years) |  | 3.0 |  |  | 3.0 |  |  | 3.0 |  |


## logi:ScheduleOfBalanceSheetComponentsAssetsTableTextBlock

[0001032975-18-000016:notes:4]
The following table presents the components of certain balance sheet asset amounts as of March 31, 2018 and 2017 (in thousands):

[0001032975-18-000016:notes:5]
|  |  | March 31, |
|  |  | 2018 |  | 2017 |
| Accounts receivable: |  |  |  |  |  |
| Accounts receivable |  | $ | 482,872 |  |  | $ | 395,754 |  |
| Allowance for doubtful accounts |  | (122 | ) |  | (607 | ) |
| Allowance for sales returns |  | (25,515 | ) |  | (18,800 | ) |
| Allowance for cooperative marketing arrangements (1) |  | (30,389 | ) |  | (28,022 | ) |
| Allowance for customer incentive programs (1) |  | (70,592 | ) |  | (60,857 | ) |
| Allowance for pricing programs (1) |  | (141,369 | ) |  | (102,289 | ) |
|  |  | $ | 214,885 |  |  | $ | 185,179 |  |
| Inventories: |  |  |  |  |  |  |
| Raw materials |  | $ | 33,603 |  |  | $ | 30,582 |  |
| Finished goods |  | 226,303 |  |  | 222,819 |  |
|  |  | $ | 259,906 |  |  | $ | 253,401 |  |
| Other current assets: |  |  |  |  |  |  |
| Value-added tax receivables |  | $ | 29,477 |  |  | $ | 23,132 |  |
| Prepaid expenses and other assets |  | 26,885 |  |  | 18,600 |  |
|  |  | $ | 56,362 |  |  | $ | 41,732 |  |
| Property, plant and equipment, net: |  |  |  |  |  |  |
| Plant, buildings and improvements |  | $ | 60,747 |  |  | $ | 58,881 |  |
| Equipment and tooling |  | 183,466 |  |  | 176,291 |  |
| Computer equipment |  | 22,752 |  |  | 27,812 |  |
| Software |  | 65,723 |  |  | 72,441 |  |
|  |  | 332,688 |  |  | 335,425 |  |
| Less accumulated depreciation and amortization |  | (260,284 | ) |  | (263,352 | ) |
|  |  | 72,404 |  |  | 72,073 |  |
| Construction-in-process |  | 11,029 |  |  | 10,537 |  |
| Land |  | 2,871 |  |  | 2,798 |  |
|  |  | $ | 86,304 |  |  | $ | 85,408 |  |
| Other assets: |  |  |  |  |  |  |
| Deferred tax assets (2) |  | $ | 84,651 |  |  | $ | 57,303 |  |
| Trading investments for deferred compensation plan |  | 17,748 |  |  | 15,043 |  |
| Investment in privately held companies |  | 12,448 |  |  | 10,776 |  |
| Other assets |  | 5,908 |  |  | 4,997 |  |
|  |  | $ | 120,755 |  |  | $ | 88,119 |  |


## logi:ScheduleOfBalanceSheetComponentsLiabilityTableTextBlock

[0001032975-18-000016:notes:6]
The following table presents the components of certain balance sheet liability amounts as of March 31, 2018 and 2017 (in thousands):

[0001032975-18-000016:notes:7]
|  |  | March 31, |
|  |  | 2018 |  | 2017 |
| Accrued and other current liabilities: |  |  |  |  |  |  |
| Accrued personnel expenses |  | $ | 82,330 |  |  | $ | 88,346 |  |
| Accrued customer marketing, pricing and incentive programs (1) |  | 71,962 |  |  | 36,409 |  |
| Warranty accrual |  | 16,279 |  |  | 13,424 |  |
| Employee benefit plan obligation |  | 1,763 |  |  | 1,266 |  |
| Income taxes payable |  | 4,354 |  |  | 6,232 |  |
| Contingent consideration for business acquisition - current portion |  | — |  |  | 2,889 |  |
| Other current liabilities |  | 105,044 |  |  | 83,707 |  |
|  |  | $ | 281,732 |  |  | $ | 232,273 |  |
| Other non-current liabilities: |  |  |  |  |  |  |
| Warranty accrual |  | $ | 11,294 |  |  | $ | 8,487 |  |
| Obligation for deferred compensation plan |  | 17,748 |  |  | 15,043 |  |
| Employee benefit plan obligation |  | 42,434 |  |  | 41,998 |  |
| Deferred tax liability |  | 1,980 |  |  | 1,789 |  |
| Contingent consideration for business acquisition - non-current portion |  | — |  |  | 7,019 |  |
| Other non-current liabilities |  | 8,468 |  |  | 9,355 |  |
|  |  | $ | 81,924 |  |  | $ | 83,691 |  |

[0001032975-18-000016:notes:8]
(1) The increases in the allowances and accruals for cooperative marketing arrangements, customer incentive programs, pricing programs as of March 31, 2018 compared with March 31, 2017 were primarily the result of increases in pricing programs and incentive and marketing activities.

[0001032975-18-000016:notes:9]
(2) The increase in deferred tax assets was primarily due to the adoption of ASU 2016-09 effective April 1, 2017, partially offset by the remeasurement of federal and state deferred tax assets in fiscal year 2018 as a result of the enactment of the Tax Act on December 22, 2017. See "Note 8 - Income Taxes" for more information.


## logi:ScheduleOfRevenueByProductFamilyExcludingInterCompanyTransactionsTableTextBlock

[0001032975-18-000016:notes:10]
Net sales by product categories and sales channels, excluding intercompany transactions, were as follows (in thousands):

[0001032975-18-000016:notes:11]
|  |  | Years Ended March 31, |
|  |  | 2018 |  | 2017 |  | 2016 |
| Pointing Devices |  | $ | 516,637 |  |  | $ | 501,562 |  |  | $ | 492,543 |  |
| Keyboards & Combos |  | 498,472 |  |  | 480,312 |  |  | 430,190 |  |
| PC Webcams |  | 112,147 |  |  | 107,087 |  |  | 98,641 |  |
| Tablet & Other Accessories |  | 107,942 |  |  | 76,879 |  |  | 103,886 |  |
| Video Collaboration |  | 182,717 |  |  | 127,009 |  |  | 89,322 |  |
| Mobile Speakers |  | 314,817 |  |  | 301,021 |  |  | 229,718 |  |
| Audio-PC & Wearables |  | 252,330 |  |  | 246,390 |  |  | 196,013 |  |
| Gaming |  | 491,995 |  |  | 314,362 |  |  | 245,101 |  |
| Smart Home |  | 89,373 |  |  | 65,510 |  |  | 59,075 |  |
| Other (1) |  | 433 |  |  | 1,295 |  |  | 2,570 |  |
| Total Net Retail Sales |  | 2,566,863 |  |  | 2,221,427 |  |  | 1,947,059 |  |
| OEM |  | — |  |  | — |  |  | 71,041 |  |
| Total Net Sales |  | $ | 2,566,863 |  |  | $ | 2,221,427 |  |  | $ | 2,018,100 |  |

[0001032975-18-000016:notes:12]
| (1) | Other category includes products that the Company currently intends to transition out of, or have already transitioned out of, because they are no longer strategic to the Company's business. |


## logi:ScheduleOfSharesRepurchasedUnderRepurchasePlanTableTextBlock

[0001032975-18-000016:notes:13]
A summary of the approved and active share buyback program is shown in the following table (in thousands, excluding transaction costs):

[0001032975-18-000016:notes:14]
|  |  | Approved |  | Repurchased |
| Share Buyback Program |  | Shares (1) |  | Amounts |  | Shares |  | Amounts |
| March 2014 |  | 17,311 |  |  | $ | 250,000 |  |  | 9,113 |  |  | $ | 155,983 |  |
| March 2017 |  | 17,311 |  |  | $ | 250,000 |  |  | 843 |  |  | $ | 30,107 |  |

[0001032975-18-000016:notes:15]
(1) The approval of each of the share buyback programs by the Swiss Takeover Board limits the number of shares that the Company may repurchase to no more than 10% of its authorized share capital and voting rights.


## us-gaap:AdvertisingCostsPolicyTextBlock

[0001032975-18-000016:notes:16]
Advertising Costs

[0001032975-18-000016:notes:17]
Advertising costs are recorded as either a marketing and selling expense or a deduction from revenue. Advertising costs paid or reimbursed by the Company to direct or indirect customers must have an identifiable benefit and an estimable fair value in order to be classified as an operating expense. If these criteria are not met, the payment is classified as a reduction of revenue.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001032975-18-000016:notes:18]
Summary of Significant Accounting Policies

[0001032975-18-000016:notes:19]
Basis of Presentation

[0001032975-18-000016:notes:20]
The consolidated financial statements include the accounts of Logitech and its subsidiaries. All intercompany balances and transactions have been eliminated. The consolidated financial statements are presented in accordance with U.S. GAAP.

[0001032975-18-000016:notes:21]
During the fourth quarter of fiscal year 2016, the Company completed the disposition of the Lifesize video conferencing business.  As a result, the Company has classified the historical results of Lifesize video conferencing business as discontinued operations in its consolidated statements of operations. See "Note 4 - Discontinued Operations" for more information.

[0001032975-18-000016:notes:22]
Unless indicated otherwise, the information in the Notes to the consolidated financial statements relates to the Company's continuing operations and does not include results of Lifesize video conferencing business, which is classified as discontinued operations.

[0001032975-18-000016:notes:23]
Fiscal Year

[0001032975-18-000016:notes:24]
The Company's fiscal year ends on March 31. Interim quarters are generally thirteen-week periods, each ending on a Friday of each quarter. For purposes of presentation, the Company has indicated its quarterly periods end on the last day of the calendar quarter.

[0001032975-18-000016:notes:25]
Reclassification

[0001032975-18-000016:notes:26]
Certain amounts from the comparative periods in the accompanying consolidated financial statements have been reclassified to conform to the consolidated financial statement presentation as of and for the year ended March 31, 2018.

[0001032975-18-000016:notes:27]
Use of Estimates

[0001032975-18-000016:notes:28]
The preparation of financial statements in conformity with U.S. GAAP requires management to make judgments, estimates and assumptions that affect the amounts reported in the consolidated financial statements. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Significant estimates and assumptions made by management involve the fair value of goodwill, intangible assets acquired from business acquisitions, warranty liabilities, accruals for customer programs and related breakage when appropriate, sales return reserves, allowance for doubtful accounts, inventory valuation, contingent consideration from business acquisitions and periodical reassessment of its fair value, share-based compensation expense, uncertain tax positions, and valuation allowances for deferred tax assets. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ materially from those estimates.

[0001032975-18-000016:notes:29]
Foreign Currencies

[0001032975-18-000016:notes:30]
The functional currency of the Company's operations is primarily the U.S. Dollar. Certain operations use the Euro, Chinese Renminbi, Swiss Franc, or other local currencies as their functional currencies. The financial statements of the Company's subsidiaries whose functional currency is other than the U.S. Dollar are translated to U.S. Dollars using period-end rates of exchange for assets and liabilities and monthly average rates for net sales, income and expenses. Cumulative translation gains and losses are included as a component of shareholders' equity in accumulated other comprehensive loss. Gains and losses arising from transactions denominated in currencies other than a subsidiary's functional currency are reported in other income (expense), net in the consolidated statements of operations.

[0001032975-18-000016:notes:31]
Revenue Recognition

[0001032975-18-000016:notes:32]
Revenue is recognized when all of the following criteria are met:

[0001032975-18-000016:notes:33]
| • | Evidence of an arrangement exists; |

[0001032975-18-000016:notes:34]
| • | Delivery has occurred and title and risk of loss has transferred to a customer; |

[0001032975-18-000016:notes:35]
| • | Price of a product is fixed or determinable; and |

[0001032975-18-000016:notes:36]
| • | Collectability is reasonably assured. |

[0001032975-18-000016:notes:37]
For sales of most hardware peripherals products and hardware bundled with software essential to its functionality, these criteria are met at the time delivery has occurred and title and risk of loss have transferred to the customer.

[0001032975-18-000016:notes:38]
Revenues from sales to distributors and authorized resellers are recognized upon shipment net of estimated product returns and expected payments for cooperative marketing arrangements, customer incentive and pricing programs. The estimated cost of these programs is recorded as a reduction of sales or as an operating expense if the Company receives a separately identifiable benefit from the customer and can reasonably estimate the fair value of that benefit. Significant management judgments and estimates are used to determine the cost of these programs in any accounting period. Certain customer programs require management to estimate the percentage of those programs which will not be claimed or will not be earned by customers based on historical experience and on the specific terms and conditions of particular programs. The percentage of these customer programs that will not be claimed or earned is commonly referred to as "breakage".

[0001032975-18-000016:notes:39]
The Company enters into cooperative marketing arrangements with many of its customers, and with certain indirect partners, allowing customers to receive a credit equal to a set percentage of their purchases of the Company's products, or a fixed dollar credit for various marketing and incentive programs. The objective of these arrangements is to encourage advertising and promotional events to increase sales of the Company's products. Accruals for these marketing arrangements are recorded at the later of the date the revenue is recognized or the date the incentive is offered, based on negotiated terms, historical experience and inventory levels in the channel.

[0001032975-18-000016:notes:40]
Customer incentive programs include consumer rebate and performance-based incentives. The Company offers performance-based incentives to its customers and indirect partners based on pre-determined performance criteria. Accruals for performance-based incentives are recognized as a reduction of the sale price at the time of sale. Estimates of required accruals are determined based on negotiated terms, consideration of historical experience, anticipated volume of future purchases, and inventory levels in the channel. Consumer rebates are offered from time to time at the Company's discretion for the primary benefit of end-users. Accruals for the estimated costs of consumer rebates and similar incentives are recorded at the later of the date the revenue is recognized or when the incentive is offered, based on the specific terms and conditions.

[0001032975-18-000016:notes:41]
The Company has agreements with certain of its customers that contain terms allowing price protection credits to be issued in the event of a subsequent price reduction. At management's discretion, the Company also offers special pricing discounts to certain customers. Special pricing discounts are usually offered only for limited time periods or for sales of selected products to specific indirect partners. Management's decision to make price reductions is influenced by product life cycle stage, market acceptance of products, the competitive environment, new product introductions and other factors. Accruals for estimated expected future pricing actions are recognized at the time of sale based on analyses of historical pricing actions by customer and by product, inventories owned by and located at distributors and retailers, current customer demand, current operating conditions, and other relevant customer and product information, such as stage of product life-cycle.

[0001032975-18-000016:notes:42]
The Company grants limited rights to return products. Return rights vary by customer and range from the right to return defective products to the stock rotation rights limited to a percentage of sales approved by management. Estimates of expected future product returns are recognized at the time of sale based on analyses of historical return trends by customer and by product, inventories owned by and located at customers, current customer demand, current operating conditions, and other relevant customer and product information. Upon recognition, the Company reduces sales and cost of goods sold for the estimated return. Return trends are influenced by product life cycle status, new product introductions, market acceptance of products, sales levels, product sell-through, the type of customer, seasonality, product quality issues, competitive pressures, operational policies and procedures, and other factors.

[0001032975-18-000016:notes:43]
Return rates can fluctuate over time but are sufficiently predictable to allow the Company to estimate expected future product returns.

[0001032975-18-000016:notes:44]
The Company applies a breakage rate to reduce its accruals of customer incentive, cooperative marketing, and pricing programs based on the estimated percentage of these customer programs that will not be claimed or earned. The breakage rate is applied when the Company is able to reasonably estimate the amounts that will be ultimately claimed by customers. Significant management judgments and estimates are used to determine the breakage of the programs in any accounting period. The Company recognized an increase in net sales of $14.4 million during the fourth quarter of the fiscal year 2017, primarily as a result of change in the estimate of breakage. Significant management judgments and estimates are used to determine the breakage of the programs in any accounting period.

[0001032975-18-000016:notes:45]
The Company regularly evaluates the adequacy of its estimates for cooperative marketing arrangements, customer incentive programs and pricing programs, and product returns. Future market conditions and product transitions may require the Company to take action to change such programs. When the variables used to estimate these costs change, or if actual costs differ significantly from the estimates, the Company would be required to record incremental increases or reductions to sales, cost of goods sold or operating expenses. If, at any future time, the Company becomes unable to reasonably estimate these costs, recognition of revenue might be deferred until products are sold to users, which would adversely impact sales in the period of transition.

[0001032975-18-000016:notes:46]
Shipping and Handling Costs

[0001032975-18-000016:notes:47]
The Company's shipping and handling costs are included in cost of goods sold in the consolidated statements of operations for all periods presented.

[0001032975-18-000016:notes:48]
Research and Development Costs

[0001032975-18-000016:notes:49]
Costs related to research, design and development of products, which consist primarily of personnel, product design and infrastructure expenses, are charged to research and development expense as they are incurred.

[0001032975-18-000016:notes:50]
Advertising costs are recorded as either a marketing and selling expense or a deduction from revenue. Advertising costs paid or reimbursed by the Company to direct or indirect customers must have an identifiable benefit and an estimable fair value in order to be classified as an operating expense. If these criteria are not met, the payment is classified as a reduction of revenue. Advertising costs recorded as marketing and selling expense are expensed as incurred. Total advertising costs including those characterized as revenue deductions during fiscal years 2018, 2017 and 2016 were $233.7 million, $208.7 million and $181.7 million, respectively, out of which $36.7 million, $32.2 million and $23.6 million, respectively, were included as operating expense in the consolidated statements of operations.

[0001032975-18-000016:notes:51]
Cash Equivalents

[0001032975-18-000016:notes:52]
The Company classifies all highly liquid instruments purchased with an original maturity of three months or less at the date of purchase to be cash equivalents. Cash equivalents are carried at cost, which approximates their fair value.

[0001032975-18-000016:notes:53]
All of the Company's bank time deposits have an original maturity of three months or less and are classified as cash equivalents and are recorded at cost, which approximates their fair value.

[0001032975-18-000016:notes:54]
Concentration of Credit Risk

[0001032975-18-000016:notes:55]
Financial instruments that potentially subject the Company to concentrations of credit risk consist principally of cash and cash equivalents and accounts receivable. The Company maintains cash and cash equivalents with various financial institutions to limit exposure with any one financial institution, but is exposed to credit risk in the event of default by financial institutions to the extent that cash balances with individual financial institutions are in excess of amounts that are insured.

[0001032975-18-000016:notes:56]
The Company sells to large distributors and retailers and, as a result, maintains individually significant receivable balances with such customers. In fiscal years 2018, 2017 and 2016, sales to one customer group represented 15%, 15% and 14%, respectively, of the Company's sales. In fiscal years 2018, 2017 and 2016, sales to another customer group represented 13%, 12% and 10%, respectively, of the Company's sales. No other sales to a single customer represented more than 10% of the Company's sales during fiscal years 2018, 2017 or 2016. As of March 31, 2018, three customer groups each represented 15%, 12% and 11% of total accounts receivable, respectively. As of March 31, 2017, two customer groups each represented 18% and 12% of total accounts receivable, respectively. Typical payment terms require customers to pay for product sales generally within 30 to 60 days; however, terms may vary by customer type, by country and by selling season. Extended payment terms are sometimes offered to a limited number of customers during the second and third fiscal quarters. The Company does not modify payment terms on existing receivables.

[0001032975-18-000016:notes:57]
The Company manages its accounts receivable credit risk through ongoing credit evaluation of its customers' financial conditions. The Company generally does not require collateral from its customers.

[0001032975-18-000016:notes:58]
Allowances for Doubtful Accounts

[0001032975-18-000016:notes:59]
Allowances for doubtful accounts are maintained for estimated losses resulting from the Company's customers' inability to make required payments. The allowances are based on the Company's regular assessment of the credit-worthiness and financial condition of specific customers, as well as its historical experience with bad debts and customer deductions, receivables aging, current economic trends, geographic or country-specific risks and the financial condition of its distribution channels.

[0001032975-18-000016:notes:60]
Inventories

[0001032975-18-000016:notes:61]
Inventories are stated at the lower of cost and net realizable value. Costs are computed under the standard cost method, which approximates actual costs determined on the first-in, first-out basis. The Company records write-downs of inventories which are obsolete or in excess of anticipated demand or net realizable value based on a consideration of marketability and product life cycle stage, product development plans, component cost trends, historical net sales and demand forecasts which consider the assumptions about future demand and market conditions. Inventory on hand which is not expected to be sold or utilized is considered excess, and the Company recognizes the write-down in cost of goods sold at the time of such determination. The write-down is determined by the excess of cost over net realizable value. Net realizable value is the estimated selling price in the ordinary course of business, less reasonably predictable costs of completion, disposal and transportation. At the time of loss recognition, new cost basis per unit and lower-cost basis for that inventory are established and subsequent changes in facts and circumstances would not result in an increase in the cost basis.

[0001032975-18-000016:notes:62]
As of March 31, 2018 and 2017, the Company also recorded a liability of $12.6 million and $7.2 million, respectively, arising from firm, non-cancelable, and unhedged inventory purchase commitments in excess of anticipated demand or net realizable value consistent with its valuation of excess and obsolete inventory. Such liability is included in accrued and other current liabilities on the consolidated balance sheets.

[0001032975-18-000016:notes:63]
Property, Plant and Equipment

[0001032975-18-000016:notes:64]
Property, plant and equipment are stated at cost. Additions and improvements are capitalized, and maintenance and repairs are expensed as incurred. The Company capitalizes the cost of software developed for internal use in connection with major projects. Costs incurred during the feasibility stage are expensed, whereas direct costs incurred during the application development stage are capitalized.

[0001032975-18-000016:notes:65]
Depreciation expense is recognized using the straight-line method. Plant and buildings are depreciated over estimated useful lives of twenty-five years, equipment over useful lives from three to five years, internal-use software over useful lives from three to seven years, tooling over useful lives from six months to one year, and leasehold improvements over the lesser of the useful life of the improvement or the term of the lease.

[0001032975-18-000016:notes:66]
When property and equipment is retired or otherwise disposed of, the cost and accumulated depreciation are relieved from the accounts and the net gain or loss is included in operating expenses.

[0001032975-18-000016:notes:67]
Intangible Assets

[0001032975-18-000016:notes:68]
The Company's intangible assets principally include goodwill, acquired technology, trademarks, and customer relationships and contracts. Intangible assets with finite lives, which include acquired technology, trademarks, customer relationships and contracts, and others are carried at cost and amortized using the straight-line method over their useful lives ranging from four to eight years. Intangible assets with indefinite lives, which include only goodwill, are recorded at cost and evaluated at least annually for impairment.

[0001032975-18-000016:notes:69]
Impairment of Long-Lived Assets

[0001032975-18-000016:notes:70]
The Company reviews long-lived assets, such as property and equipment, and finite-lived intangible assets, for impairment whenever events indicate that the carrying amounts might not be recoverable. Recoverability of property and equipment, and other finite-lived intangible asset is measured by comparing the projected undiscounted net cash flows associated with those assets to their carrying values. If an asset is considered impaired, it is written down to its fair value, which is determined based on the asset's projected discounted cash flows or appraised value, depending on the nature of the asset. For purposes of recognition of impairment for assets held for use, the Company groups assets and liabilities at the lowest level for which cash flows are separately identifiable.

[0001032975-18-000016:notes:71]
Impairment of Goodwill

[0001032975-18-000016:notes:72]
Goodwill represents the excess of the purchase price over the fair value of the net tangible and identifiable intangible assets acquired in each business combination. The Company conducts a goodwill impairment analysis annually at December 31 or more frequently if indicators of impairment exist or if a decision is made to sell or exit a business. A significant amount of judgments are involved in determining if an indicator of impairment has occurred. Such indicators may include deterioration in general economic conditions, negative developments in equity and credit markets, adverse changes in the markets in which an entity operates, increases in input costs that have a negative effect on earnings and cash flows, or a trend of negative or declining cash flows over multiple periods, among others. The fair value that could be realized in an actual transaction may differ from that used to evaluate the impairment of goodwill.

[0001032975-18-000016:notes:73]
In reviewing goodwill for impairment, an entity has the option to first assess qualitative factors to determine whether the existence of events or circumstances leads to a determination that it is more likely than not (greater than 50%) that the estimated fair value of a reporting unit is less than its carrying amount. If an entity elects to perform a qualitative assessment and determines that an impairment is more likely than not, the entity is then required to perform the quantitative impairment test, otherwise no further analysis is required. An entity also may elect not to perform the qualitative assessment and, instead, proceed directly to the quantitative impairment test. The ultimate outcome of the goodwill impairment review for a reporting unit should be the same whether an entity chooses to perform the qualitative assessment or proceeds directly to the quantitative impairment test.

[0001032975-18-000016:notes:74]
Income Taxes

[0001032975-18-000016:notes:75]
The Company provides for income taxes using the asset and liability method, which requires that deferred tax assets and liabilities be recognized for the expected future tax consequences of temporary differences resulting from differing treatment of items for tax and financial reporting purposes, and for operating losses and tax credit carryforwards. In estimating future tax consequences, expected future events are taken into consideration, with the exception of potential tax law or tax rate changes. The Company records a valuation allowance to reduce deferred tax assets to amounts management believes are more likely than not to be realized.

[0001032975-18-000016:notes:76]
The Company's assessment of uncertain tax positions requires that management makes estimates and judgments about the application of tax law, the expected resolution of uncertain tax positions and other matters. In the event that uncertain tax positions are resolved for amounts different than the Company's estimates, or the related statutes of limitations expire without the assessment of additional income taxes, the Company will be required to adjust the amounts of the related assets and liabilities in the period in which such events occur. Such adjustments may have a material impact on the Company's income tax provision and its results of operations.

[0001032975-18-000016:notes:77]
Fair Value of Financial Instruments

[0001032975-18-000016:notes:78]
The carrying value of certain of the Company's financial instruments, including cash equivalents, accounts receivable and accounts payable approximates their fair value due to their short maturities.

[0001032975-18-000016:notes:79]
The Company's investment securities portfolio consists of bank time deposits with an original maturity of three months or less and marketable securities (money market and mutual funds) related to a deferred compensation plan.

[0001032975-18-000016:notes:80]
The Company's trading investments related to the deferred compensation plan are reported at fair value based on quoted market prices. The marketable securities related to the deferred compensation plan are classified as non-current trading investments, as they are intended to fund the deferred compensation plan long-term liability. Since participants in the deferred compensation plan may select the mutual funds in which their compensation deferrals are invested within the confines of the Rabbi Trust which holds the marketable securities, the Company has designated these marketable securities as trading investments, although there is no intent to actively buy and sell securities within the objective of generating profits on short-term differences in market prices. These securities are recorded at fair value based on quoted market prices. Earnings, gains and losses on trading investments are included in other income (expense), net in the consolidated statements of operations.

[0001032975-18-000016:notes:81]
The Company also holds non-marketable investments in equity and other securities that are accounted for as either cost or equity method investments, which are classified as other assets. The Company reviews the fair value of its non-marketable investments on a regular basis to determine whether the investments in these companies are other-than-temporarily impaired. The Company considers investee financial performance and other information received from the investee companies, as well as any other available estimates of the fair value of the investee companies in its review. If the Company determines that the carrying value of an investment exceeds its fair value, and that difference is other than temporary, the Company writes down the value of the investment to its fair value. The carrying value of cost investments is not adjusted if there are no identified adverse events or changes in circumstances that may have a material effect on the fair value of the investments.

[0001032975-18-000016:notes:82]
Net Income (Loss) per Share

[0001032975-18-000016:notes:83]
Basic net income (loss) per share is computed by dividing net income (loss) by the weighted average outstanding shares. Diluted net income (loss) per share is computed using the weighted average outstanding shares and dilutive share equivalents. Dilutive share equivalents consist of share-based awards, including stock options, purchase rights under employee share purchase plan, and restricted stock units (RSUs).

[0001032975-18-000016:notes:84]
The dilutive effect of in-the-money share-based compensation awards is calculated based on the average share price for each fiscal period using the treasury stock method.

[0001032975-18-000016:notes:85]
Share-Based Compensation Expense

[0001032975-18-000016:notes:86]
Share-based compensation expense includes compensation expense, reduced for estimated forfeitures, for share-based awards granted based on the grant date fair value. The grant date fair value for stock options and stock purchase rights is estimated using the Black-Scholes-Merton option-pricing valuation model. The grant date fair value of RSUs which vest upon meeting certain market conditions is estimated using the Monte-Carlo simulation method. The grant date fair value of time-based and performance-based RSUs is calculated based on the market price on the date of grant, reduced by estimated dividends yield prior to vesting. With respect to awards with service conditions only, compensation expense is recognized ratably over the vesting period of the awards. For performance-based RSUs, the Company recognizes the estimated expense using a graded-vesting method over requisite service periods of one to three years when the performance condition is determined to be probable. The performance period and the service period of the market-based grants of the Company granted are both approximately three years and the estimated expense is recognized ratably over the service period.

[0001032975-18-000016:notes:87]
Effective April 1, 2017, the Company adopted Accounting Standards Update (ASU) 2016-09 and accounts for forfeitures as they occur. Refer to "Recent Accounting Pronouncements Adopted" below for details of the impact from the change in accounting.

[0001032975-18-000016:notes:88]
Product Warranty Accrual

[0001032975-18-000016:notes:89]
The Company estimates cost of product warranties at the time the related revenue is recognized based on historical warranty claim rates, historical costs, and knowledge of specific product failures that are outside of the Company's typical experience. The Company accrues a warranty liability for estimated costs to provide products, parts or services to repair or replace products in satisfaction of the warranty obligation. Each quarter, the Company reevaluates estimates to assess the adequacy of recorded warranty liabilities considering the size of the installed base of products subject to warranty protection and adjusts the amounts as necessary. When the Company experiences changes in warranty claim activity or costs associated with fulfilling those claims, the warranty liability is adjusted accordingly. If actual product failure rates or repair costs differ from estimates, revisions to the estimated warranty liabilities would be required and could materially affect the Company's results of operations.

[0001032975-18-000016:notes:90]
Comprehensive Income (Loss)

[0001032975-18-000016:notes:91]
Comprehensive income (loss) is defined as the total change in shareholders' equity during the period other than from transactions with shareholders. Comprehensive income (loss) consists of net income (loss) and other comprehensive income (loss). Other comprehensive income (loss) is comprised of currency translation adjustments from those entities not using the U.S. Dollar as their functional currency, unrealized gains and losses on marketable equity securities, net deferred gains and losses and prior service costs and credits for defined benefit pension plans, and net deferred gains and losses on hedging activity.

[0001032975-18-000016:notes:92]
Treasury Shares

[0001032975-18-000016:notes:93]
The Company periodically repurchases shares in the market at fair value. Shares repurchased are recorded at cost as a reduction of total shareholders' equity. Treasury shares held may be reissued to satisfy the exercise of employee stock options and purchase rights and the vesting of restricted stock units, or may be canceled with shareholder approval. Treasury shares that are reissued are accounted for using the first-in, first-out basis.

[0001032975-18-000016:notes:94]
Derivative Financial Instruments

[0001032975-18-000016:notes:95]
The Company enters into foreign exchange forward contracts to reduce the short-term effects of currency fluctuations on certain foreign currency receivables or payables and to hedge against exposure to changes in currency exchange rates related to its subsidiaries' forecasted inventory purchases. These forward contracts generally mature within four months.

[0001032975-18-000016:notes:96]
Gains and losses for changes in the fair value of the effective portion of the Company's forward contracts related to forecasted inventory purchases are deferred as a component of accumulated other comprehensive income (loss) until the hedged inventory purchases are sold, at which time the gains or losses are reclassified to cost of goods sold. Gains or losses from changes in the fair value of forward contracts that offset translation losses or gains on foreign currency receivables or payables are recognized immediately and included in other income (expense), net in the consolidated statements of operations.

[0001032975-18-000016:notes:97]
Restructuring Charges

[0001032975-18-000016:notes:98]
The Company's restructuring charges consist of employee severance, one-time termination benefits and ongoing benefits related to the reduction of its workforce, lease exit costs, and other costs. Liabilities for costs associated with a restructuring activity are measured at fair value and are recognized when the liability is incurred, as opposed to when management commits to a restructuring plan. One-time termination benefits are expensed at the date the entity notifies the employee, unless the employee must provide future service, in which case the benefits are expensed ratably over the future service period. Ongoing benefits are expensed when restructuring activities are probable and the benefit amounts are estimable. Costs to terminate a lease before the end of its term are recognized when the property is vacated. Other costs primarily consist of legal, consulting, and other costs related to employee terminations are expensed when incurred. Termination benefits are calculated based on regional benefit practices and local statutory requirements.

[0001032975-18-000016:notes:99]
Segments

[0001032975-18-000016:notes:100]
Operating segments are defined as components of an enterprise about which separate financial information is available that is evaluated regularly by the chief operating decision maker, or decision making group, in deciding how to allocate resources and in assessing performance. Reportable segments are operating segments that meet certain quantitative thresholds. As a result of the divestiture of the Lifesize video conferencing business on December 28, 2015, the composition of the Company's previously reported segments changed, such that the remaining peripheral segment is the only segment reported in continuing operations.

[0001032975-18-000016:notes:101]
Recent Accounting Pronouncements Adopted

[0001032975-18-000016:notes:102]
In July 2015, the Financial Accounting Standards Board (FASB) issued ASU 2015-11, "Simplifying the Measurement of Inventory (Topic 330)" (ASU 2015-11). Topic 330 previously required an entity to measure inventory at the lower of cost or market, with market value represented by replacement cost, net realizable value or net realizable value less a normal profit margin. ASU 2015-11 requires an entity to measure inventory at the lower of cost and net realizable value and is effective for fiscal years beginning after December 15, 2016. The Company adopted this standard effective April 1, 2017, which has not had a material impact on its consolidated financial statements.

[0001032975-18-000016:notes:103]
In March 2016, the FASB issued ASU 2016-09, "Compensation-Stock Compensation (Topic 718)": Improvements to Employee Share-Based Payment Accounting" (ASU 2016-09). ASU 2016-09 simplifies several aspects of the accounting for share-based payments, including immediate recognition of all excess tax benefits and deficiencies in the income statement, changing the threshold to qualify for equity classification up to the employees' maximum statutory tax rates, allowing an entity-wide accounting policy election to either estimate the number of awards that are expected to vest or account for forfeitures as they occur, and clarifying the classification on the statement of cash flows for the excess tax benefits and employee taxes paid when an employer withholds shares for tax withholding purposes. ASU 2016-09 is effective for fiscal years beginning after December 15, 2016. The Company adopted this standard effective April 1, 2017. Changes to the statements of cash flows related to the classification of excess tax benefits were implemented on a retroactive basis and accordingly, to conform to the current year presentation, the Company reclassified $9.7 million and $2.1 million of excess tax benefits previously reported under financing activities to operating activities for the year ended March 31, 2017 and 2016, respectively, on its consolidated statements of cash flows. Under the new standard, the Company accounts for forfeitures as they occur. The change in accounting for forfeitures resulted in a cumulative-effect adjustment to decrease retained earnings as of March 31, 2017 by $3.3 million. The Company further recognized a cumulative-effect adjustment to increase retained earnings as of March 31, 2017 by $57.2 million upon adoption of the new guidance to account for gross excess tax benefits of $75.2 million that were previously not recognized because the related tax deduction had not reduced current income taxes, offset by a valuation allowance of $18.0 million to reduce the deferred tax assets to amounts that are more likely than not to be realized.

[0001032975-18-000016:notes:104]
In January 2017, the FASB issued ASU 2017-04, "Simplifying the Test for Goodwill Impairment (Topic 350)" (ASU 2017-04), which removes Step 2 from the goodwill impairment test. ASU 2017-04 is effective for annual or any interim goodwill impairments in annual periods beginning December 15, 2019, with early adoption permitted. The Company adopted this standard effective April 1, 2017, which has not had a material impact on its consolidated financial statements.

[0001032975-18-000016:notes:105]
In May 2017, the FASB issued ASU 2017-09, "Compensation-Stock Compensation (Topic 718): Scope of Modification Accounting" (ASU 2017-09), which provides guidance about which changes to the terms or conditions of a share-based payment award require an entity to apply modification accounting in Topic 718. ASU 2017-09 is effective for annual periods beginning after December 15, 2017, with early adoption permitted, including adoption in any interim period for which financial statements have not yet been issued. The Company adopted this standard effective April 1, 2017, which has not had a material impact on its consolidated financial statements.

[0001032975-18-000016:notes:106]
Recent Accounting Pronouncements To Be Adopted

[0001032975-18-000016:notes:107]
In May 2014, the FASB issued ASU No. 2014-09, "Revenue from Contracts with Customers (Topic 606)" (ASU 2014-09) which supersedes the revenue recognition requirements under ASC 605, Revenue Recognition. Topic 606 outlines a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. Under the new model, recognition of revenue occurs when a customer obtains control of promised goods or services in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. The new standard requires reporting companies to disclose the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. The new standard will become effective for the Company on April 1, 2018 (the adoption date). The Company will adopt Topic 606 utilizing the modified retrospective transition method, which recognizes the cumulative effect of initially applying Topic 606 as an adjustment to retained earnings at the adoption date. The Company has identified major revenue streams, performed an analysis of its contracts to evaluate the impact of Topic 606, and drafted its accounting policies, and is substantially complete with its evaluation of the impact this new standard will have on its accruals for customer programs. The Company does not expect the adoption to have a material impact to the nature and timing of its revenues, results of operations or retained earnings at the date of adoption. The Company has determined that certain allowance balances for customer incentive, cooperative marketing and pricing programs and customer return rights currently presented net within accounts receivable may need to be presented within current liabilities upon adoption.

[0001032975-18-000016:notes:108]
Under ASC 605, accruals for certain cooperative marketing arrangements, customer incentive programs and pricing programs are recognized as a reduction of revenue at the later of when the related revenue is recognized or when the program is offered to the customer. Under Topic 606, these programs qualify as variable considerations and are recorded as a reduction of the transaction price at the contract inception based on the expected value method. Certain of these programs will require the Company to record an estimate of yet to be committed future sales incentives with respect to revenue already recognized upon adoption.

[0001032975-18-000016:notes:109]
Under Topic 606, variable consideration must be estimated at the outset of the arrangement, subject to the constraint guidance to ensure that a significant revenue reversal will not occur. As a result, upon adoption of Topic 606, breakage will be recognized sooner as compared to the existing revenue guidance.

[0001032975-18-000016:notes:110]
The Company will continue to monitor additional changes, modifications, clarifications or interpretations of Topic 606, which may impact current expectations. It is possible that during the first quarter of fiscal year 2019, the Company could identify items that result in additional changes to its consolidated financial statements other than what is described above.

[0001032975-18-000016:notes:111]
In January 2016, the FASB issued ASU 2016-01 “Financial Instruments- Recognition and Measurement of Financial Assets and Financial Liabilities (Subtopic 825-10)” (ASU 2016-01), which amends certain aspects of recognition, measurement, presentation and disclosure of financial instruments, including the requirement to measure certain equity investments at fair value with changes in fair value recognized in net income. This guidance is effective for fiscal years beginning after December 15, 2017, including interim periods within those fiscal years.  The Company does not expect the adoption of ASU 2016-01 will have a material impact on its consolidated financial statements and has adopted this guidance effective April 1, 2018.

[0001032975-18-000016:notes:112]
In February 2016, the FASB issued ASU 2016-02 "Leases (Topic 842)" (ASU 2016-02), which requires the recognition of lease assets and lease liabilities arising from operating leases in the statement of financial position. This guidance is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. The Company expects the adoption of ASU 2016-02 will have a material impact on its consolidated balance sheets, but is still in the process of evaluating the full impact, and will adopt the standard effective April 1, 2019.

[0001032975-18-000016:notes:113]
In October 2016, the FASB issued ASU 2016-16 "Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory" (ASU 2016-16), which eliminates the deferral of income tax effects of intra-entity asset transfers until the transferred asset is sold to an unrelated party or recovered through use.  ASU 2016-16, however, does not apply to intra-entity transfer of inventory.  The guidance is effective for annual periods beginning after December 15, 2017 and interim reporting periods within those annual periods.  Early adoption is permitted but only in the first interim period of a fiscal year.  The cumulative effect of change on equity upon adoption is to be quantified under the modified retrospective approach and recorded as of the beginning of the period of adoption.  The Company does not expect the adoption of ASU 2016-16 will have a material impact on its consolidated financial statements and has adopted this guidance effective April 1, 2018.

[0001032975-18-000016:notes:114]
In December 2016, the FASB issued ASU 2016-18 "Statement of Cash Flows (Topic 230): Restricted Cash" (ASU 2016-18), which requires that a statement of cash flows explains the change during the period in the total of cash, cash equivalents, and amounts generally described as restricted cash or restricted cash equivalents. The standard is effective for annual periods beginning after December 15, 2017 and interim reporting periods within those annual periods, with early adoption permitted. The adoption of this standard should be applied using a retrospective transition method to each period presented. The Company does not expect the adoption of ASU 2016-18 will have a material impact on its consolidated financial statements and has adopted this standard effective April 1, 2018.

[0001032975-18-000016:notes:115]
In January 2017, the FASB issued ASU 2017-01, "Business Combination (Topic 805): Clarifying the Definition of a Business" (ASU 2017-01), which changes the definition of a business to assist with evaluating when a set of transferred assets and activities is a business. ASU 2017-01 is effective for annual or any interim periods in annual periods beginning after December 15, 2017, with early adoption permitted. The Company does not expect that the adoption of ASU 2017-01 will have a material impact on its consolidated financial statements and has adopted this standard effective April 1, 2018.

[0001032975-18-000016:notes:116]
In March 2017, the FASB issued ASU 2017-07, "Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost" (ASU 2017-07), which requires that the Company disaggregate the service cost component from the other components of net benefit cost, and also provides guidance on how to present the service cost component and the other components of net benefit cost in the income statement and allow only the service cost component of net benefit cost to be eligible for capitalization. The standard is effective for the Company for annual periods beginning after December 15, 2017, including interim periods within those annual periods, with early adoption permitted. The Company does not expect the adoption of ASU 2017-07 will have a material impact on its consolidated financial statements and has adopted this guidance effective April 1, 2018.

[0001032975-18-000016:notes:117]
In August 2017, the FASB issued ASU 2017-12, "Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities" (ASU 2017-12), which improves the financial reporting of hedging relationships to better portray the economic results of an entity’s risk management activities in its financial statements and simplifies the application of the hedge accounting guidance. ASU 2017-12 is effective for annual periods beginning after December 15, 2018, including interim periods within those annual periods, with early adoption permitted. The Company does not expect that the adoption of ASU 2017-12 will have a material impact on its consolidated financial statements and has adopted this standard effective April 1, 2018.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001032975-18-000016:notes:118]
Business Acquisitions

[0001032975-18-000016:notes:119]
Fiscal Year 2018 Acquisitions

[0001032975-18-000016:notes:120]
ASTRO Acquisition

[0001032975-18-000016:notes:121]
On August 11, 2017 (the ASTRO Acquisition Date), the Company acquired certain assets and liabilities constituting the ASTRO Gaming business (ASTRO) from AG Acquisition Corporation for a purchase price of $85.0 million in cash (the ASTRO Acquisition). ASTRO is a leading console gaming accessory brand with a history of producing award-winning headsets for professional gamers and enthusiasts. ASTRO provides the Company with a strong growth platform in the console gaming accessories market.

[0001032975-18-000016:notes:122]
ASTRO meets the definition of a business, and its acquisition is accounted for using the acquisition method. The following table summarizes the estimated fair values of the assets acquired and liabilities assumed at the ASTRO Acquisition Date (in thousands):

[0001032975-18-000016:notes:123]
|  |  | Estimated Fair Value |
| Inventories |  | $ | 10,331 |  |
| Property, plant and equipment |  | 2,760 |  |
| Intangible assets |  | 52,520 |  |
| Other assets |  | 605 |  |
| Total identifiable assets acquired |  | 66,216 |  |
| Accrued liabilities |  | (2,982 | ) |
| Net identifiable assets acquired |  | 63,234 |  |
| Goodwill |  | 21,766 |  |
| Net assets acquired |  | $ | 85,000 |  |

[0001032975-18-000016:notes:124]
Goodwill related to the transaction is primarily attributable to opportunities and economies of scale from combining the operations and technologies of Logitech and ASTRO. Goodwill is expected to be deductible for tax purposes.

[0001032975-18-000016:notes:125]
The fair value of the inventories acquired is estimated at their net realizable value, which uses the estimated selling prices, less the costs of disposal and a reasonable profit allowance for the selling efforts. The difference between the fair value of the inventories and the amount recorded by ASTRO immediately before the ASTRO Acquisition Date is $0.8 million, which has been recognized in "amortization of intangibles assets and purchase accounting effect on inventory" in the consolidated statements of operations upon the sales of the acquired inventories.

[0001032975-18-000016:notes:126]
The Company included ASTRO's estimated fair value of assets acquired and liabilities assumed in its consolidated balance sheets beginning on the ASTRO Acquisition Date. The results of operations for ASTRO have been included in, but are not material to, the Company's consolidated statements of operations from the ASTRO Acquisition Date.

[0001032975-18-000016:notes:127]
The following table summarizes the estimated fair values and estimated useful lives of the components of identifiable intangible assets acquired as of the ASTRO Acquisition Date (Dollars in thousands):

[0001032975-18-000016:notes:128]
|  | Fair Value |  | Estimated Useful Life (years) |
| Developed technology | $ | 12,540 |  |  | 4.0 |
| Customer relationships | 33,100 |  |  | 8.0 |
| Trade name | 6,880 |  |  | 6.0 |
| Total intangible assets acquired | $ | 52,520 |  |  | 6.8 |

[0001032975-18-000016:notes:129]
Intangible assets acquired as a result of the ASTRO Acquisition are being amortized over their estimated useful lives using the straight-line method of amortization. Amortization of acquired developed technology of $2.0 million during the year ended March 31, 2018, is included in "amortization of intangible assets and purchase accounting effect of inventory" in the consolidated statements of operations. Amortization of the acquired customer relationships and trade name of $3.3 million during the year ended March 31, 2018, is included in "amortization of intangible assets and acquisition-related costs" in the consolidated statements of operations.

[0001032975-18-000016:notes:130]
Developed technology relates to existing ASTRO gaming headset products. The economic useful life was determined based on the technology cycle related to developed technology of existing products, as well as the cash flows anticipated over the forecasted periods.

[0001032975-18-000016:notes:131]
Customer relationships represent the fair value of future projected revenue that will be derived from sales of products to existing customers of ASTRO. The economic useful life was determined based on historical customer turnover rates and industry benchmarks.

[0001032975-18-000016:notes:132]
Trade name relates to the “ASTRO” trade name. The economic useful life was determined based on the expected life of the trade name and the cash flows anticipated over the forecasted periods.

[0001032975-18-000016:notes:133]
The fair value of developed technology and trade name was estimated using the relief-from-royalty method, an income approach (Level 3), which estimates the cost savings that accrue to the owner of the intangible assets that would otherwise be payable as royalties or license fees on revenues earned through the use of the asset. A royalty rate is applied to the projected revenues associated with the intangible assets to determine the amount of savings, which is then discounted to determine the fair value. The developed technology and trade name were valued using royalty rates of 10% and 2%, respectively, and both were discounted at a rate of 13%.

[0001032975-18-000016:notes:134]
The fair value of customer relationships was estimated using the excess earnings method, an income approach (Level 3), which converts projected revenues and costs into cash flows. To reflect the fact that certain other assets contributed to the cash flows generated, the returns for these contributory assets were removed to arrive at estimated cash flows solely attributable to the customer relationships, which were discounted at a rate of 13%.

[0001032975-18-000016:notes:135]
The Company believes the value of purchased intangible assets recorded above represents the fair values of, and approximates the amounts a market participant would pay for, these intangible assets as of the ASTRO Acquisition Date.

[0001032975-18-000016:notes:136]
For the year ended March 31, 2018, ASTRO contributed approximately 2 points to net sales growth.

[0001032975-18-000016:notes:137]
In November 2017, the Company also made a small technology acquisition for a total consideration of $5.2 million, including cash acquired of $0.9 million. $1.0 million of the total consideration was retained by the Company for the purpose of ensuring the seller's representations, warranties and covenants.

[0001032975-18-000016:notes:138]
Fiscal Year 2017 Acquisitions

[0001032975-18-000016:notes:139]
Jaybird Acquisition

[0001032975-18-000016:notes:140]
On April 20, 2016 (the Jaybird Acquisition Date), the Company acquired all of the equity interests of JayBird, LLC (Jaybird), a Utah limited liability company that develops Bluetooth earbuds, activity trackers, and accessories for sports and active lifestyles, for a purchase price of $54.2 million in cash, including a working capital adjustment and payment of a line-of-credit on behalf of Jaybird, with an additional earn-out of up to $45.0 million based on the achievement of certain net revenue growth targets over approximately a two year period (the Jaybird Acquisition). If the net revenue growth targets would have been met, the Company would have paid a maximum of $25.0 million and $20.0 million in fiscal years 2018 and 2019, respectively. In October 2017, Logitech and the sellers of Jaybird entered into an agreement fully, irrevocably and unconditionally releasing Logitech from the earn-out rights and payments in exchange for $5.0 million in cash, which was paid in November 2017. The Jaybird Acquisition has accelerated the Company's entry into the wireless wearables space.

[0001032975-18-000016:notes:141]
Jaybird meets the definition of a business and its acquisition is accounted for using the acquisition method. The fair value of consideration transferred for the Jaybird Acquisition consists of the following (in thousands):

[0001032975-18-000016:notes:142]
| Purchase price |  | $ | 54,242 |  |
| Fair value of contingent consideration (earn-out) |  | 18,000 |  |
| Fair value of total consideration transferred |  | $ | 72,242 |  |

[0001032975-18-000016:notes:143]
The fair value of the earn-out payments at the Jaybird Acquisition Date was determined by providing risk-adjusted earnings projections using a Monte Carlo Simulation, which includes inputs that are not observable in the market, and therefore representing a Level 3 measurement. The fair value of this earn-out is discussed further in "Note 10 - Fair Value Measurements" to the consolidated financial statements.

[0001032975-18-000016:notes:144]
The following table summarizes the estimated fair values of the assets acquired and liabilities assumed at the Jaybird Acquisition Date (in thousands):

[0001032975-18-000016:notes:145]
|  |  | Estimated Fair Value |
| Cash and cash equivalents |  | $ | 255 |  |
| Accounts receivable |  | 272 |  |
| Inventories |  | 10,214 |  |
| Other current assets |  | 611 |  |
| Property, plant, and equipment |  | 1,165 |  |
| Intangible assets |  | 50,280 |  |
| Other assets |  | 27 |  |
| Total identifiable assets acquired |  | 62,824 |  |
| Accounts payable |  | (10,513 | ) |
| Accrued liabilities |  | (1,227 | ) |
| Other current liabilities |  | (5,226 | ) |
| Other long-term liabilities |  | (283 | ) |
| Net identifiable assets acquired |  | 45,575 |  |
| Goodwill |  | 26,667 |  |
| Net assets acquired |  | $ | 72,242 |  |

[0001032975-18-000016:notes:146]
Goodwill related to the transaction is primarily attributable to opportunities and economies of scale from combining the operations and technologies of Logitech and Jaybird. Goodwill is expected to be deductible for tax purposes.

[0001032975-18-000016:notes:147]
The difference between the fair value of the inventories and the amount recorded by Jaybird immediately before the acquisition date was $0.7 million, which was recognized in "amortization of intangibles assets and purchase accounting effect on inventory" in the consolidated statements of operations upon the sales of the acquired inventories.

[0001032975-18-000016:notes:148]
The Company included Jaybird's estimated fair value of assets acquired and liabilities assumed in its consolidated balance sheets beginning April 20, 2016. The results of operations for Jaybird have been included in, but are not material to, the Company's consolidated statements of operations from the Jaybird Acquisition Date.

[0001032975-18-000016:notes:149]
The following table summarizes the estimated fair values and estimated useful lives of the components of identifiable intangible assets acquired at their estimated fair values and their estimated useful lives as of the Jaybird Acquisition Date (Dollars in thousands):

[0001032975-18-000016:notes:150]
|  | Fair Value | Estimated Useful Life (years) |
| Developed technology | $ | 18,450 |  | 4.0 |
| Customer relationships | 19,900 |  | 8.0 |
| Trade name | 9,380 |  | 6.0 |
| Intangible assets with finite lives acquired | 47,730 |  | 6.1 |
| In-process research & development (IPR&D) | 2,550 |  | Not Applicable |
| Total intangible assets acquired | $ | 50,280 |  |  |

[0001032975-18-000016:notes:151]
Except for IPR&D, intangible assets acquired as a result of the Jaybird Acquisition are being amortized over their estimated useful lives using the straight-line method of amortization. Amortization of acquired developed technology of $5.1 million and $4.4 million, respectively, during fiscal years 2018 and 2017 is included in "amortization of intangible assets and purchase accounting effect on inventory" in the gross profit of the consolidated statements of operations. Amortization of the acquired customer relationships and trade name of $4.0 million and $3.8 million, respectively, during fiscal years 2018 and 2017 is included in "amortization of intangible assets and acquisition-related costs" in the consolidated statements of operations.

[0001032975-18-000016:notes:152]
Developed technology relates to existing Bluetooth wireless sports earbuds. The economic useful life was determined based on the technology cycle related to the developed technology of existing products, as well as the cash flows anticipated over the forecasted periods.

[0001032975-18-000016:notes:153]
Customer relationships represent the fair value of future projected revenue that will be derived from sales of products to existing customers of Jaybird. The economic useful life was determined based on historical customer turnover rates and industry benchmarks.

[0001032975-18-000016:notes:154]
Trade name relates to the “Jaybird” trade name. The economic useful life was determined based on the expected life of the trade name and the cash flows anticipated over the forecasted periods.

[0001032975-18-000016:notes:155]
The fair value of developed technology and trade name was estimated using the relief-from-royalty method, an income approach (Level 3), which estimates the cost savings that accrue to the owner of the intangible assets that would otherwise be payable as royalties or license fees on revenues earned through the use of the asset. A royalty rate is applied to the projected revenues associated with the intangible assets to determine the amount of savings, which is then discounted to determine the fair value. The developed technology and trade name were valued using royalty rates of 10% and 2.5%, respectively, and both were discounted at a rate of 16%.

[0001032975-18-000016:notes:156]
The fair value of customer relationships was estimated using the excess earnings method, an income approach (Level 3), which converts projected revenues and costs into cash flows. To reflect the fact that certain other assets contribute to the cash flows generated, the returns for these contributory assets were removed to arrive at estimated cash flows solely attributable to the customer relationships, which were discounted at a rate of 16%.

[0001032975-18-000016:notes:157]
The IPR&D is accounted for as an indefinite-lived intangible asset and is not amortized until completion or abandonment of the associated research and development efforts. The IPR&D acquired was reclassified as developed technology intangible assets during the third quarter of fiscal year 2017 when the underlying projects were completed and developed technology is amortized over its estimated useful life of five years.

[0001032975-18-000016:notes:158]
Saitek Acquisition

[0001032975-18-000016:notes:159]
On September 15, 2016, the Company completed the acquisition of the Saitek product line for a total cash consideration of approximately $13.0 million (the Saitek Acquisition). Out of the total consideration, $6.7 million was attributed to intangible assets, $4.9 million was attributed to goodwill, and $1.4 million was attributed to net tangible assets acquired. The Saitek Acquisition enhances the breadth and depth of the Company's product offerings in the Gaming category and expands the Company's engineering capabilities in simulation products. The amount of goodwill generated from the Saitek Acquisition is deductible for tax purposes.

[0001032975-18-000016:notes:160]
Acquisition-related costs and pro forma results of operations

[0001032975-18-000016:notes:161]
The Company incurred acquisition-related costs of approximately $1.4 million and $1.5 million, in aggregate, for the year ended March 31, 2018 and 2017, respectively. The acquisition-related costs are included in "Amortization of intangible assets and acquisition-related costs" in the consolidated statements of operations.

[0001032975-18-000016:notes:162]
Pro forma results of operations for the ASTRO Acquisition, the Jaybird Acquisition and the Saitek Acquisition have not been presented because these acquisitions are not material to the consolidated statements of operations individually or in aggregate.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001032975-18-000016:notes:163]
Commitments and Contingencies

[0001032975-18-000016:notes:164]
Operating Leases

[0001032975-18-000016:notes:165]
The Company leases facilities under operating leases, certain of which require it to pay property taxes, insurance and maintenance costs. Operating leases for facilities are generally renewable at the Company's option and usually include escalation clauses linked to inflation. Future minimum annual rentals under non-cancelable operating leases at March 31, 2018 are as follows (in thousands):

[0001032975-18-000016:notes:166]
| Years Ending March 31, |  |  |
| 2019 |  | $ | 13,144 |  |
| 2020 |  | 10,833 |  |
| 2021 |  | 8,108 |  |
| 2022 |  | 5,743 |  |
| 2023 |  | 4,221 |  |
| Thereafter |  | 2,452 |  |
|  |  | $ | 44,501 |  |

[0001032975-18-000016:notes:167]
Rent expense for fiscal years 2018, 2017 and 2016 was $11.2 million, $9.9 million and $10.0 million, respectively.

[0001032975-18-000016:notes:168]
In connection with its leased facilities, the Company recognized a liability for asset retirement obligations for 2018 and 2017 representing the present value of estimated remediation costs to be incurred at lease expiration. The liabilities for asset retirement obligations were not material as of March 31, 2018 and 2017.

[0001032975-18-000016:notes:169]
Product Warranties

[0001032975-18-000016:notes:170]
All of the Company's Peripherals products are covered by warranty to be free from defects in material and workmanship for periods ranging from one year to five years. The warranty period varies by product and by region.

[0001032975-18-000016:notes:171]
Changes in the Company's warranty liability for fiscal years 2018 and 2017 were as follows (in thousands):

[0001032975-18-000016:notes:172]
|  |  | Years Ended March 31, |
|  |  | 2018 |  | 2017 |
| Beginning of the period |  | $ | 21,911 |  |  | $ | 20,380 |  |
| Assumed from business acquisition |  | 1,230 |  |  | 1,963 |  |
| Provision |  | 25,103 |  |  | 15,341 |  |
| Settlements |  | (21,766 | ) |  | (15,270 | ) |
| Currency translation |  | 1,095 |  |  | (503 | ) |
| End of the period |  | $ | 27,573 |  |  | $ | 21,911 |  |

[0001032975-18-000016:notes:173]
Investment Commitments

[0001032975-18-000016:notes:174]
During 2015, the Company entered into a limited partnership agreement with a private investment fund specialized in early-stage start-up consumer hardware electronics companies and committed to a capital contribution of $4.0 million over the life of the fund. The Company has invested $2.9 million as of March 31, 2018, which is classified as other assets on the consolidated balance sheet. As of March 31, 2018, $1.1 million capital contribution has not yet been called upon by the fund.

[0001032975-18-000016:notes:175]
Guarantees

[0001032975-18-000016:notes:176]
Logitech Europe S.A.,one of the Company's wholly-owned subsidiaries, guaranteed payments of two third-party contract manufacturers' purchase obligations. As of March 31, 2018, the maximum amount of this guarantee was $3.8 million, of which $1.0 million of guaranteed purchase obligations was outstanding.

[0001032975-18-000016:notes:177]
Indemnifications

[0001032975-18-000016:notes:178]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys' fees. As of March 31, 2018, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

[0001032975-18-000016:notes:179]
The Company also indemnifies its current and former directors and certain of its current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. The Company is unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not limited, the obligations are conditional in nature and the facts and circumstances involved in any situation that might arise are variable.

[0001032975-18-000016:notes:180]
The Stock Purchase Agreement that the Company entered into in connection with the investment by three venture capital firms in Lifesize, Inc. contains representations, warranties and covenants of Logitech and Lifesize, Inc. to the Venture Investors. Subject to certain limitations, the Company has agreed to indemnify the Venture Investors and certain persons related to the Venture Investors for certain losses resulting from breaches of or inaccuracies in such representations, warranties and covenants as well as certain other obligations, including third-party expenses, restructuring costs and pre-closing tax obligations of Lifesize.

[0001032975-18-000016:notes:181]
Legal Proceedings

[0001032975-18-000016:notes:182]
From time to time the Company is involved in claims and legal proceedings which arise in the ordinary course of its business. The Company is currently subject to several such claims and a small number of legal proceedings. The Company believes that these matters lack merit and intends to vigorously defend against them. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial position, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company's defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company's business, financial position, cash flows or results of operations in a particular period. Any claims or proceedings against the Company, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain a necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company's business.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001032975-18-000016:notes:183]
Employee Benefit Plans

[0001032975-18-000016:notes:184]
Employee Share Purchase Plans and Stock Incentive Plans

[0001032975-18-000016:notes:185]
As of March 31, 2018, the Company offers the 2006 ESPP (2006 Employee Share Purchase Plan (Non-U.S.)), the 1996 ESPP (1996 Employee Share Purchase Plan (U.S.)), the 2006 Plan (2006 Stock Incentive Plan) and the 2012 Plan (2012 Stock Inducement Equity Plan). Shares issued to employees as a result of purchases or exercises under these plans are generally issued from shares held in treasury stock.

[0001032975-18-000016:notes:186]
The following table summarizes share-based compensation expense and total income tax provision (benefit) recognized for fiscal years 2018, 2017 and 2016 (in thousands):

[0001032975-18-000016:notes:187]
|  |  | Years Ended March 31, |
|  |  | 2018 |  | 2017 |  | 2016 |
| Cost of goods sold |  | $ | 3,733 |  |  | $ | 2,663 |  |  | $ | 2,340 |  |
| Marketing and selling |  | 17,765 |  |  | 14,723 |  |  | 9,273 |  |
| Research and development |  | 6,381 |  |  | 4,200 |  |  | 3,046 |  |
| General and administrative |  | 16,259 |  |  | 14,304 |  |  | 12,353 |  |
| Restructuring |  | — |  |  | — |  |  | 7 |  |
| Total share-based compensation expense |  | 44,138 |  |  | 35,890 |  |  | 27,019 |  |
| Income tax benefit |  | (15,998 | ) |  | (8,536 | ) |  | (6,297 | ) |
| Total share-based compensation expense, net of income tax benefit |  | $ | 28,140 |  |  | $ | 27,354 |  |  | $ | 20,722 |  |

[0001032975-18-000016:notes:188]
The income tax benefit in the respective period primarily consists of tax benefit related to the share-based compensation expense for the period and direct tax benefit realized, including net excess tax benefits recognized from share-based awards vested or exercised upon the adoption of ASU 2016-09 on April 1, 2017. The income tax benefit is reduced by income tax provision resulting from the remeasurement of applicable deferred tax assets and liabilities due to the enactment of the Tax Act in the United States on December 22, 2017. See "Note 8 - Income Taxes" for more information.

[0001032975-18-000016:notes:189]
As of March 31, 2018, 2017 and 2016, the Company capitalized $0.7 million, $0.6 million and $0.5 million, respectively, of stock-based compensation expenses to inventory.

[0001032975-18-000016:notes:190]
The following table summarizes total unamortized share-based compensation expense and the remaining months over which such expense is expected to be recognized, on a weighted-average basis by type of grant (in thousands, except number of months):

[0001032975-18-000016:notes:191]
|  |  | March 31, 2018 |
|  |  | UnamortizedExpense |  | RemainingMonths |
| ESPP |  | $ | 1,337 |  |  | 4 |
| Time-based RSUs |  | 56,723 |  |  | 21 |
| Market-based and performance-based RSUs |  | 13,620 |  |  | 23 |
|  |  | $ | 71,680 |  |  |  |

[0001032975-18-000016:notes:192]
Under the 1996 ESPP and 2006 ESPP plans, eligible employees may purchase shares at the lower of 85% of the fair market value at the beginning or the end of each offering period, which is generally six months. Subject to continued participation in these plans, purchase agreements are automatically executed at the end of each offering period. An aggregate of 29.0 million shares was reserved for issuance under the 1996 and 2006 ESPP plans. As of March 31, 2018, a total of 5.9 million shares was available for new awards under these plans.

[0001032975-18-000016:notes:193]
The 2006 Plan provides for the grant to eligible employees and non-employee directors of stock options, stock appreciation rights, restricted stock and RSUs. Awards under the 2006 Plan may be conditioned on continued employment, the passage of time or the satisfaction of performance and market vesting criteria. The 2006 Plan, as amended, has no expiration date. All stock options under this plan have terms not exceeding ten years and are issued at exercise prices not less than the fair market value on the date of grant. An aggregate of 30.6 million shares was reserved for issuance under the 2006 Plan. As of March 31, 2018, a total of 10.6 million shares was available for new awards under this plan.

[0001032975-18-000016:notes:194]
Time-based RSUs granted to employees under the 2006 Plan generally vest in four equal annual installments on the grant date anniversary. Time-based RSUs granted to non-executive board members under the 2006 Plan vest in one annual installment on the grant date anniversary, or if earlier and only if the non-executive board member is not re-elected as a director at such annual general meeting, the date of the next annual general meeting following the grant date.

[0001032975-18-000016:notes:195]
Performance-based RSUs granted in fiscal years 2016 and 2017 under the 2006 Plan vest contingent upon the achievement of predetermined financial metrics, the performance period of which is approximately three years. The performance condition can be achieved before the end of the performance period. Market-based options granted under the 2006 Plan vest upon meeting the Company's share price performance criteria. The number of shares of common stock to be received at vesting for market-based RSUs granted in fiscal years 2016 and 2017 under the 2006 Plan will range from 0 percent to 150 percent of the target number of stock units based on the Company's total stockholder return (TSR) relative to the performance of companies in the NASDAQ-100 Index for each measurement period, generally over a three-year period. In fiscal year 2018, the Company granted RSUs with both performance and market conditions, which vest at the end of the three-year performance period upon meeting predetermined financial metrics over three years, with the number of shares to be received upon vesting determined based on weighted average constant currency revenue growth rate and the Company's TSR relative to the performance of companies in the NASDAQ-100 Index over the same three year period. The Company presents shares granted and vested at 100 percent of the target of the number of stock units that may potentially vest.

[0001032975-18-000016:notes:196]
Under the 2012 Plan, stock options and RSUs may be granted to eligible employees to serve as an inducement to enter into employment with the Company. Awards under the 2012 Plan may be conditioned on continued employment, the passage of time or the satisfaction of market stock performance criteria, based on individually written employment offer letter. The 2012 Plan has an expiration date of March 28, 2022. An aggregate of 1.8 million shares was reserved for issuance under the 2012 Plan. As of March 31, 2018, no shares were available for new awards under this plan.

[0001032975-18-000016:notes:197]
The estimates of share-based compensation expense require a number of complex and subjective assumptions including stock price volatility, employee exercise patterns, future forfeitures, probability of achievement of the set performance condition, dividend yield, related tax effects and the selection of an appropriate fair value model.

[0001032975-18-000016:notes:198]
The dividend yield assumption is based on the Company's history and future expectations of dividend payouts. The unvested RSUs or unexercised options are not eligible for these dividends. The expected life is based on the purchase offerings periods expected to remain outstanding, or the performance period for RSUs with market conditions. Expected volatility is based on historical volatility using the Company's daily closing prices, or including the volatility of components of the NASDAQ 100 index for market-based RSUs, over the expected life. The Company considers the historical price volatility of its shares as most representative of future volatility. The risk-free interest rate assumptions are based upon the implied yield of U.S. Treasury zero-coupon issues appropriate for the expected life of the Company's share-based awards.

[0001032975-18-000016:notes:199]
The Company estimated awards forfeitures at the time of grant and revised those estimates in subsequent periods if actual forfeitures differ from those estimates. The Company used historical data to estimate pre-vesting option and RSU forfeitures and recorded share-based compensation expense only for those awards that are expected to vest. Effective April 1, 2017, the Company adopted ASU 2016-09 and accounts for forfeitures as they occur. The impact from the change in accounting for forfeitures did not have a material impact on the Company's consolidated financial statements.

[0001032975-18-000016:notes:200]
For  RSUs with performance conditions, the Company estimates the probability and timing of the achievement of the set performance condition at the time of the grant based on the historical financial performance and the financial forecast in the remaining performance period and reassesses the probability in subsequent periods when actual results or new information become available.

[0001032975-18-000016:notes:201]
A summary of the Company's stock option activities under all stock plans for fiscal years 2018, 2017 and 2016 is as follows (including discontinued operations for fiscal year 2016):

[0001032975-18-000016:notes:202]
|  |  | Number of Shares |  | Weighted-Average Exercise Price |  | Weighted-Average Remaining Contractual Term |  | Aggregate Intrinsic Value |
|  |  | (In thousands) |  |  |  | (Years) |  | (In thousands) |
| Outstanding, March 31, 2015 |  | 7,876 |  |  |  |  |  |  |  |  |
| Granted |  | — |  |  |  |  |  |  |  |  |
| Exercised |  | (746 | ) |  |  |  |  |  |  | $ | 4,026 |  |
| Canceled or expired |  | (1,796 | ) |  |  |  |  |  |  |  |
| Outstanding, March 31, 2016 |  | 5,334 |  |  |  |  |  |  |  |  |
| Granted |  | — |  |  |  |  |  |  |  |  |
| Exercised |  | (1,784 | ) |  |  |  |  |  |  | $ | 14,627 |  |
| Canceled or expired |  | (500 | ) |  |  |  |  |  |  |  |
| Outstanding, March 31, 2017 |  | 3,050 |  |  | $ | 18 |  |  |  |  |  |  |
| Granted |  | — |  |  | — |  |  |  |  |  |  |
| Exercised |  | (994 | ) |  | $ | 28 |  |  |  |  | $ | 8,347 |  |
| Canceled or expired |  | (16 | ) |  | $ | 35 |  |  |  |  |  |  |
| Outstanding, March 31, 2018 |  | 2,040 |  |  | $ | 14 |  |  | 4.0 |  | $ | 46,630 |  |
| Vested and exercisable, March 31, 2018 |  | 2,040 |  |  | $ | 14 |  |  | 4.0 |  | $ | 46,630 |  |

[0001032975-18-000016:notes:203]
As of March 31, 2018, the exercise price of outstanding options ranged from $4 to $26 per share option.

[0001032975-18-000016:notes:204]
The tax benefit realized for the tax deduction from options exercised during the fiscal years 2018, 2017 and 2016 was $1.8 million, $4.2 million and $1.2 million, respectively.

[0001032975-18-000016:notes:205]
A summary of the Company's time-based, market-based, and performance-based RSU activities for fiscal years 2018, 2017 and 2016 is as follows (including discontinued operations for all the periods presented):

[0001032975-18-000016:notes:206]
|  |  | Number of Shares |  | Weighted-Average Grant Date Fair Value |  | Weighted-Average Remaining Vesting Period |  | Aggregate Fair Value |
|  |  | (In thousands) |  |  |  | (Years) |  | (In thousands) |
| Outstanding, March 31, 2015 |  | 4,939 |  |  |  |  |  |  |  |  |
| Granted—time-based |  | 2,247 |  |  | $ | 13 |  |  |  |  |  |
| Granted—market-based |  | 356 |  |  | $ | 14 |  |  |  |  |  |
| Granted - performance-based |  | 356 |  |  | $ | 13 |  |  |  |  |  |
| Vested |  | (1,557 | ) |  |  |  |  |  |  | $ | 22,823 |  |
| Canceled or expired |  | (820 | ) |  |  |  |  |  |  |  |
| Outstanding, March 31, 2016 |  | 5,521 |  |  |  |  |  |  |  |  |
| Granted—time-based |  | 2,390 |  |  | $ | 16 |  |  |  |  |  |
| Granted—market-based |  | 160 |  |  | $ | 15 |  |  |  |  |  |
| Granted - performance-based |  | 604 |  |  | $ | 15 |  |  |  |  |  |
| Vested |  | (2,126 | ) |  |  |  |  |  |  | $ | 48,644 |  |
| Canceled or expired |  | (368 | ) |  |  |  |  |  |  |  |
| Outstanding, March 31, 2017 |  | 6,181 |  |  | $ | 14 |  |  |  |  |  |
| Granted—time-based |  | 1,212 |  |  | $ | 33 |  |  |  |  |  |
| Granted—market and performance based |  | 409 |  |  | $ | 33 |  |  |  |  |  |
| Vested |  | (2,248 | ) |  | $ | 14 |  |  |  |  | $ | 81,582 |  |
| Canceled or expired |  | (333 | ) |  | $ | 17 |  |  |  |  |  |
| Outstanding, March 31, 2018 |  | 5,221 |  |  | $ | 20 |  |  | 1.4 |  | $ | 191,777 |  |

[0001032975-18-000016:notes:207]
The RSU outstanding as of March 31, 2018 above includes 1.4 million shares with market-based and performance-based vesting conditions.

[0001032975-18-000016:notes:208]
The tax benefit realized for the tax deduction from RSUs that vested during the fiscal years 2018, 2017 and 2016 was $20.3 million, $13.1 million and $5.1 million, respectively.

[0001032975-18-000016:notes:209]
Defined Contribution Plans

[0001032975-18-000016:notes:210]
Certain of the Company's subsidiaries have defined contribution employee benefit plans covering all or a portion of their employees. Contributions to these plans are discretionary for certain plans and are based on specified or statutory requirements for others. The charges to expense for these plans for fiscal years 2018, 2017 and 2016, were $7.6 million, $5.8 million and $6.8 million, respectively.

[0001032975-18-000016:notes:211]
Defined Benefit Plans

[0001032975-18-000016:notes:212]
Certain of the Company's subsidiaries sponsor defined benefit pension plans or non-retirement post-employment benefits covering substantially all of their employees. Benefits are provided based on employees' years of service and earnings, or in accordance with applicable employee benefit regulations. The Company's practice is to fund amounts sufficient to meet the requirements set forth in the applicable employee benefit and tax regulations.

[0001032975-18-000016:notes:213]
The Company recognizes the overfunded or underfunded status of defined benefit pension plans and non-retirement post-employment benefit obligations as an asset or liability in its consolidated balance sheets and recognizes changes in the funded status of defined benefit pension plans in the year in which the changes occur through accumulated other comprehensive income (loss), which is a component of shareholders' equity. Each plan's assets and benefit obligations are remeasured as of March 31 each year.

[0001032975-18-000016:notes:214]
All the amounts in this "Defined Benefit Plans" section include activities from both continuing and discontinued operations for fiscal year 2016, and the amounts from discontinued operations are not material for that period.

[0001032975-18-000016:notes:215]
The net periodic benefit cost of the defined benefit pension plans and the non-retirement post-employment benefit obligations for fiscal years 2018, 2017 and 2016 was as follows (in thousands):

[0001032975-18-000016:notes:216]
|  |  | Years Ended March 31, |
|  |  | 2018 |  | 2017 |  | 2016 |
| Service costs |  | $ | 9,715 |  |  | $ | 10,385 |  |  | $ | 10,117 |  |
| Interest costs |  | 1,126 |  |  | 800 |  |  | 1,147 |  |
| Expected return on plan assets |  | (1,792 | ) |  | (1,724 | ) |  | (1,657 | ) |
| Amortization: |  |  |  |  |  |  |
| Net transition obligation |  | — |  |  | 4 |  |  | 4 |  |
| Net prior service credit recognized |  | (51 | ) |  | (117 | ) |  | (124 | ) |
| Net actuarial loss recognized |  | 242 |  |  | 1,032 |  |  | 1,854 |  |
|  |  | $ | 9,240 |  |  | $ | 10,380 |  |  | $ | 11,341 |  |

[0001032975-18-000016:notes:217]
The changes in projected benefit obligations for fiscal years 2018 and 2017 were as follows (in thousands):

[0001032975-18-000016:notes:218]
|  |  | Years Ended March 31, |
|  |  | 2018 |  | 2017 |
| Projected benefit obligations, beginning of the year |  | $ | 114,640 |  |  | $ | 120,473 |  |
| Service costs |  | 9,715 |  |  | 10,385 |  |
| Interest costs |  | 1,126 |  |  | 800 |  |
| Plan participant contributions |  | 3,522 |  |  | 3,020 |  |
| Actuarial gains |  | (1,580 | ) |  | (11,081 | ) |
| Benefits paid |  | (1,202 | ) |  | (5,214 | ) |
| Plan amendment related to statutory change |  | (2,519 | ) |  | 65 |  |
| Administrative expense paid |  | (144 | ) |  | (132 | ) |
| Currency exchange rate changes |  | 5,357 |  |  | (3,676 | ) |
| Projected benefit obligations, end of the year |  | $ | 128,915 |  |  | $ | 114,640 |  |

[0001032975-18-000016:notes:219]
The accumulated benefit obligation for all defined benefit pension plans as of March 31, 2018 and 2017 was $108.9 million and $94.3 million, respectively.

[0001032975-18-000016:notes:220]
The following table presents the changes in the fair value of defined benefit pension plan assets for fiscal years 2018 and 2017 (in thousands):

[0001032975-18-000016:notes:221]
|  |  | Years Ended March 31, |
|  |  | 2018 |  | 2017 |
| Fair value of plan assets, beginning of the year |  | $ | 71,376 |  |  | $ | 65,279 |  |
| Actual return on plan assets |  | 1,824 |  |  | 4,733 |  |
| Employer contributions |  | 5,995 |  |  | 5,865 |  |
| Plan participant contributions |  | 3,522 |  |  | 3,020 |  |
| Benefits paid |  | (1,202 | ) |  | (5,214 | ) |
| Administrative expenses paid |  | (144 | ) |  | (132 | ) |
| Currency exchange rate changes |  | 3,347 |  |  | (2,175 | ) |
| Fair value of plan assets, end of the year |  | $ | 84,718 |  |  | $ | 71,376 |  |

[0001032975-18-000016:notes:222]
The Company's investment objectives are to ensure that the assets of its defined benefit plans are invested to provide an optimal rate of investment return on the total investment portfolio, consistent with the assumption of a reasonable risk level, and to ensure that pension funds are available to meet the plans' benefit obligations as they become due. The Company believes that a well-diversified investment portfolio will result in the highest attainable investment return with an acceptable level of overall risk. Investment strategies and allocation decisions are also governed by applicable governmental regulatory agencies. The Company's investment strategy with respect to its largest defined benefit plan, which is available only to Swiss employees, is to invest in the following allocation ranges: 29.5-36.5% for equities, 29.0-39.0% for bonds, and 5.0-15.0% for cash and cash equivalents. The Company also can invest in real estate funds, commodity funds, and hedge funds depending upon economic conditions.

[0001032975-18-000016:notes:223]
The following tables present the fair value of the defined benefit pension plan assets by major categories and by levels within the fair value hierarchy as of March 31, 2018 and 2017 (in thousands):

[0001032975-18-000016:notes:224]
|  |  | March 31, |
|  |  | 2018 |  | 2017 |
|  |  | Level 1 |  | Level 2 |  | Total |  | Level 1 |  | Level 2 |  | Total |
| Cash and cash equivalents |  | $ | 18,331 |  |  | $ | 24 |  |  | $ | 18,355 |  |  | $ | 11,864 |  |  | $ | 46 |  |  | $ | 11,910 |  |
| Equity securities |  | 26,204 |  |  | — |  |  | 26,204 |  |  | 20,985 |  |  | — |  |  | 20,985 |  |
| Debt securities |  | 25,150 |  |  | — |  |  | 25,150 |  |  | 22,373 |  |  | — |  |  | 22,373 |  |
| Swiss real estate funds |  | 12,096 |  |  | — |  |  | 12,096 |  |  | 9,699 |  |  | — |  |  | 9,699 |  |
| Hedge funds |  | — |  |  | — |  |  | — |  |  | — |  |  | 3,507 |  |  | 3,507 |  |
| Insurance contracts |  | — |  |  | 32 |  |  | 32 |  |  | — |  |  | 61 |  |  | 61 |  |
| Other |  | 2,623 |  |  | 258 |  |  | 2,881 |  |  | 2,654 |  |  | 187 |  |  | 2,841 |  |
|  |  | $ | 84,404 |  |  | $ | 314 |  |  | $ | 84,718 |  |  | $ | 67,575 |  |  | $ | 3,801 |  |  | $ | 71,376 |  |

[0001032975-18-000016:notes:225]
The funded status of the plans was as follows (in thousands):

[0001032975-18-000016:notes:226]
|  |  | Years Ended March 31, |
|  |  | 2018 |  | 2017 |
| Fair value of plan assets |  | $ | 84,718 |  |  | $ | 71,376 |  |
| Less: projected benefit obligations |  | 128,915 |  |  | 114,640 |  |
| Underfunded status |  | $ | (44,197 | ) |  | $ | (43,264 | ) |

[0001032975-18-000016:notes:227]
Amounts recognized on the balance sheet for the plans were as follows (in thousands):

[0001032975-18-000016:notes:228]
|  |  | March 31, |
|  |  | 2018 |  | 2017 |
| Current liabilities |  | $ | (1,763 | ) |  | $ | (1,266 | ) |
| Non-current liabilities |  | (42,434 | ) |  | (41,998 | ) |
| Net liabilities |  | $ | (44,197 | ) |  | $ | (43,264 | ) |

[0001032975-18-000016:notes:229]
Amounts recognized in accumulated other comprehensive loss related to defined benefit pension plans were as follows (in thousands):

[0001032975-18-000016:notes:230]
|  |  | March 31, |
|  |  | 2018 |  | 2017 |  | 2016 |
| Net prior service credits |  | $ | 3,843 |  |  | $ | 1,274 |  |  | $ | 1,613 |  |
| Net actuarial loss |  | (9,821 | ) |  | (11,407 | ) |  | (27,612 | ) |
| Net transition obligation |  | — |  |  | — |  |  | (4 | ) |
| Accumulated other comprehensive loss |  | (5,978 | ) |  | (10,133 | ) |  | (26,003 | ) |
| Deferred tax benefit |  | (420 | ) |  | (347 | ) |  | (168 | ) |
| Accumulated other comprehensive loss, net of tax |  | $ | (6,398 | ) |  | $ | (10,480 | ) |  | $ | (26,171 | ) |

[0001032975-18-000016:notes:231]
The following table presents the amounts included in accumulated other comprehensive loss as of March 31, 2018, which are expected to be recognized as a component of net periodic benefit cost in fiscal year 2019 (in thousands):

[0001032975-18-000016:notes:232]
|  |  | Year EndingMarch 31, 2019 |
| Amortization of net prior service credits |  | $ | (381 | ) |
| Amortization of net actuarial loss |  | 95 |  |
|  |  | $ | (286 | ) |

[0001032975-18-000016:notes:233]
The Company reassesses its benefit plan assumptions on a regular basis. The actuarial assumptions for the defined benefit plans for fiscal years 2018 and 2017 were as follows:

[0001032975-18-000016:notes:234]
|  |  | Years Ended March 31, |
|  |  | 2018 |  | 2017 |
| Benefit Obligations: |  |  |  |  |
| Discount rate |  | 0.85%-7.5% |  | 0.75%-7.00% |
| Estimated rate of compensation increase |  | 2.25%-10.00% |  | 2.5%-10.00% |
| Periodic Costs: |  |  |  |  |
| Discount rate |  | 0.75%-7.00% |  | 0.5%-8.00% |
| Estimated rate of compensation increase |  | 2.5%-10.00% |  | 2.5%-10.00% |
| Expected average rate of return on plan assets |  | 1.0%-2.5% |  | 1.0%-2.75% |

[0001032975-18-000016:notes:235]
The discount rate is estimated based on corporate bond yields or securities of similar quality in the respective country, with a duration approximating the period over which the benefit obligations are expected to be paid. The Company bases the compensation increase assumptions on historical experience and future expectations. The expected average rate of return for the Company's defined benefit pension plans represents the average rate of return expected to be earned on plan assets over the period that the benefit obligations are expected to be paid, based on government bond notes in the respective country, adjusted for corporate risk premiums as appropriate.

[0001032975-18-000016:notes:236]
The following table reflects the benefit payments that the Company expects the plans to pay in the periods noted (in thousands):

[0001032975-18-000016:notes:237]
| Years Ending March 31, |  |  |
| 2019 |  | $ | 7,199 |  |
| 2020 |  | 7,701 |  |
| 2021 |  | 7,046 |  |
| 2022 |  | 7,341 |  |
| 2023 |  | 7,064 |  |
| 2024-2028 |  | 38,546 |  |
|  |  | $ | 74,897 |  |

[0001032975-18-000016:notes:238]
The Company expects to contribute $5.7 million to its defined benefit pension plans during fiscal year 2019.

[0001032975-18-000016:notes:239]
Deferred Compensation Plan

[0001032975-18-000016:notes:240]
One of the Company's subsidiaries offers a deferred compensation plan that permits eligible employees to make 100% vested salary and incentive compensation deferrals within established limits. The Company does not make contributions to the plan.

[0001032975-18-000016:notes:241]
The deferred compensation plan's assets consist of marketable securities and are included in other assets on the consolidated balance sheets. The marketable securities are classified as trading investments and were recorded at a fair value of $17.7 million and $15.0 million as of March 31, 2018 and 2017, respectively, based on quoted market prices. The Company also had $17.7 million and $15.0 million in deferred compensation liability as of March 31, 2018 and 2017, respectively. Earnings, gains and losses on trading investments are included in other income (expense), net and corresponding changes in deferred compensation liability are included in operating expenses and cost of goods sold.


## us-gaap:DebtDisclosureTextBlock

[0001032975-18-000016:notes:242]
Financing Arrangements

[0001032975-18-000016:notes:243]
The Company had several uncommitted, unsecured bank lines of credit aggregating $84.5 million as of March 31, 2018. There are no financial covenants under these lines of credit with which the Company must comply. As of March 31, 2018, the Company had outstanding bank guarantees of $49.8 million under these lines of credit. There was no borrowing outstanding under the line of credit as of March 31, 2018 or March 31, 2017.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001032975-18-000016:notes:244]
The following table presents the fair values of the Company's derivative instruments as of March 31, 2018 and 2017 (in thousands):

[0001032975-18-000016:notes:245]
|  |  | Derivatives |
|  |  | Asset |  | Liability |
|  |  | March 31, |  | March 31, |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash flow hedges |  | $ | — |  |  | $ | 48 |  |  | $ | — |  |  | $ | 402 |  |

[0001032975-18-000016:notes:246]
Under certain agreements with the respective counterparties to the Company's derivative contracts, subject to applicable requirements, the Company is allowed to net settle transactions of the same type with a single net amount payable by one party to the other. However, the Company presents its derivative assets and derivative liabilities on a gross basis in other current assets or accrued and other current liabilities on the consolidated balance sheets as of March 31, 2018 and 2017.

[0001032975-18-000016:notes:247]
The fair values of the Company’s derivative instruments not designated as hedging instruments were not material as of March 31, 2018 or March 31, 2017. The following table presents the amounts of gains and losses on the Company's derivative instruments designated as hedging instruments for fiscal years 2018, 2017 and 2016 and their locations on its consolidated statements of operations and consolidated statements of comprehensive income (loss) (in thousands):

[0001032975-18-000016:notes:248]
|  | Amount ofGain (Loss) Deferred asa Component ofAccumulated OtherComprehensive Loss |  | Amount of Loss (Gain)Reclassified fromAccumulated OtherComprehensive Lossto Costs of Goods Sold |
|  | 2018 |  | 2017 |  | 2016 |  | 2018 |  | 2017 |  | 2016 |
| Designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash flow hedges | $ | (8,499 | ) |  | $ | 2,928 |  |  | $ | (2,432 | ) |  | $ | 5,808 |  |  | $ | (1,670 | ) |  | $ | (3,296 | ) |

[0001032975-18-000016:notes:249]
Cash Flow Hedges:  The Company enters into​ cash flow hedge​ contracts to ​protect​ against exchange rate exposure ​of ​forecasted inventory purchases. These hedging contracts mature within four months. Gains and losses in the fair value of the effective portion of the hedges are deferred as a component of accumulated other comprehensive loss until the hedged inventory purchases are sold, at which time the gains or losses are reclassified to cost of goods sold. Cash flows from such hedges are classified as operating activities in the consolidated statements of cash flows. Hedging relationships are discontinued when hedging contract is no longer eligible for hedge accounting, or is sold, terminated or exercised, or when the Company removes hedge designation for the contract. Gains and losses in the fair value of the effective portion of the discontinued hedges continue to be reported in accumulated other comprehensive loss until the hedged inventory purchases are sold, unless it is probable that the forecasted inventory purchases will not occur by the end of the originally specified time period or within an additional two-month period of time thereafter. As of March 31, 2018, there were no currency forward contracts outstanding related to forecasted inventory purchases.  As of March 31, 2017, the notional amounts of currency forward contracts outstanding related to forecasted inventory purchases was $59.4 million. The Company estimates that $3.2 million of net losses related to its cash flow hedges included in accumulated other comprehensive loss as of March 31, 2018 will be reclassified into earnings within the next 12 months.

[0001032975-18-000016:notes:250]
Other Derivatives: The Company also enters into currency forward and swap contracts to reduce the short-term effects of currency fluctuations on certain receivables or payables denominated in currencies other than the functional currencies of its subsidiaries. These forward and swap contracts generally mature within one month. The primary risk managed by using forward and swap contracts is the currency exchange rate risk. The gains or losses on these contracts are recognized in other income (expense), net in the consolidated statements of operations based on the changes in fair value. The notional amounts of these contacts outstanding as of March 31, 2018 and 2017 were $47.2 million and $56.7 million, respectively. Open forward and swap contracts as of March 31, 2018 and 2017 consisted of contracts in Taiwanese Dollars, Australian Dollars, Mexican Pesos, Japanese Yen, Canadian Dollars and British Pounds to be settled at future dates at pre-determined exchange rates.

[0001032975-18-000016:notes:251]
The fair value of all currency forward and swap contracts is determined based on observable market transactions of spot currency rates and forward rates. Cash flows from these contracts are classified as operating activities in the consolidated statements of cash flows.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001032975-18-000016:notes:252]
Discontinued Operations

[0001032975-18-000016:notes:253]
During the third quarter of fiscal year 2016, the Company's Board of Directors approved a plan to divest the Lifesize video conferencing business. On December 28, 2015 during the fourth quarter of fiscal year 2016, the Company, and Lifesize, Inc., a wholly owned subsidiary of the Company (Lifesize) which held the assets of the Company’s video conferencing reportable segment, entered into a stock purchase agreement (the Stock Purchase Agreement) with entities affiliated with three venture capital investment firms (the Venture Investors). Pursuant to the terms of the Stock Purchase Agreement, the Company sold 2.5 million shares of Series B Preferred Stock of Lifesize to the Venture Investors for cash proceeds of $2.5 million and retained 12.0 million non-voting shares of Series A Preferred Stock of Lifesize. The shares of Series A Preferred Stock of Lifesize retained by the Company represent 37.5% of the shares outstanding immediately after the closing of the transactions contemplated by the Stock Purchase Agreement (the Closing). Lifesize also issued 17.5 million shares of Series B Preferred Stock to the Venture Investors for cash proceeds of $17.5 million. The shares of Series B Preferred Stock held by the Venture Investors represent 62.5% of the shares outstanding immediately after the Closing. In addition, Lifesize has reserved 8.0 million shares of common stock for issuance pursuant to a stock plan to be adopted by Lifesize following the Closing, none of which are issued or outstanding at the Closing. The Company substantially completed its transition services for Lifesize during the third quarter of fiscal year 2017.

[0001032975-18-000016:notes:254]
The Company has classified the historical results of its Lifesize video conferencing business as discontinued operations in its consolidated statements of operations since the divestiture of the Lifesize video conferencing business represents a strategic shift that has a major effect on the Company's operations and financial results. Evaluating whether the divestiture of the business represents a strategic shift requires the Company's judgment. Also, evaluating whether the strategic shift will have a "major effect" on the Company's operations and financial results requires assessing not only quantitative factors but also the magnitude of qualitative factors.

[0001032975-18-000016:notes:255]
The retained Series A Preferred Stock gives the Company no voting rights or any other significant influence over the divested Lifesize video conferencing business, and therefore is accounted for as a cost method investment which was initially recognized at fair value of $5.6 million at the date of divestiture of Lifesize Video Conferencing business. The fair value was determined by using the option pricing methodology with reference to the price of Lifesize’s Series B Preferred Stock paid by Venture Investors. The fair value of the Company’s investment in Series A Preferred Stock is classified as Level 3 as the application of the option pricing methodology requires the use of significant unobservable inputs including asset volatility of 50%, expected term to exit of three years, and lack of marketability discount of 27%.

[0001032975-18-000016:notes:256]
Discontinued operations include results of the Lifesize video conferencing business. Discontinued operations also include other costs incurred by Logitech to effect the divestiture of the Lifesize video conferencing business. These costs include transaction charges, advisory and consulting fees and restructuring cost related to the Lifesize video conferencing business.

[0001032975-18-000016:notes:257]
The following table presents financial results of the video conferencing classified as discontinued operations (in thousands):

[0001032975-18-000016:notes:258]
|  |  | Years Ended March 31, |
|  |  | 2016 |
| Net sales |  | $ | 65,554 |  |
| Cost of goods sold |  | 24,951 |  |
| Gross profit |  | 40,603 |  |
| Operating expenses: |  |  |  |
| Marketing and selling |  | 32,260 |  |
| Research and development |  | 16,526 |  |
| General and administrative |  | 5,254 |  |
| Restructuring charges, net |  | 7,900 |  |
| Operating expenses |  | 61,940 |  |
| Operating loss from discontinued operations |  | (21,337 | ) |
| Interest and other expense, net |  | (205 | ) |
| Gain on divestiture of discontinued operations |  | 13,684 |  |
| Loss from discontinued operations before income taxes |  | (7,858 | ) |
| Provision for income taxes |  | 1,187 |  |
| Net loss from discontinued operations |  | $ | (9,045 | ) |

[0001032975-18-000016:notes:259]
The Company recognized a gain on its divestiture of Lifesize video conferencing business as follows (in thousands):

[0001032975-18-000016:notes:260]
|  |  | Year Ended |
|  |  | March 31, 2016 |
| Proceeds received from the divestiture of discontinued operations |  | $ | 2,500 |  |
| Fair value of retained cost method investment as a result of the divestiture of discontinued operations |  | 5,591 |  |
| Net liabilities of discontinued operations divested |  | 9,981 |  |
| Currency translation loss released due to the divestiture of discontinued operations (1) |  | (3,913 | ) |
| Transaction-related costs |  | (475 | ) |
| Gain on divestiture of discontinued operations (2) |  | $ | 13,684 |  |

[0001032975-18-000016:notes:261]
(1) Currency translation loss recognized as a result of the substantial liquidation of a subsidiary using non-USD functional currency, which is part of discontinued operations

[0001032975-18-000016:notes:262]
(2) Gain on divestiture of discontinued operation was included in loss from discontinued operations, net of income taxes, in the Company's consolidated statement of operations


## us-gaap:EarningsPerShareTextBlock

[0001032975-18-000016:notes:263]
The computations of basic and diluted net income (loss) per share for the Company were as follows (in thousands except per share amounts):

[0001032975-18-000016:notes:264]
|  |  | Years Ended March 31, |
|  |  | 2018 |  | 2017 |  | 2016 |
| Net Income (loss): |  |  |  |  |  |  |
| Continuing operations |  | $ | 208,542 |  |  | $ | 205,876 |  |  | $ | 128,362 |  |
| Discontinued operations |  | — |  |  | — |  |  | (9,045 | ) |
| Net income |  | $ | 208,542 |  |  | $ | 205,876 |  |  | $ | 119,317 |  |
| Shares used in net income (loss) per share computation: |  |  |  |  |  |  |
| Weighted average shares outstanding - basic |  | 164,038 |  |  | 162,058 |  |  | 163,296 |  |
| Effect of potentially dilutive equivalent shares |  | 4,933 |  |  | 3,482 |  |  | 2,496 |  |
| Weighted average shares outstanding - diluted |  | 168,971 |  |  | 165,540 |  |  | 165,792 |  |
| Net income (loss) per share - basic: |  |  |  |  |  |  |
| Continuing operations |  | $ | 1.27 |  |  | $ | 1.27 |  |  | $ | 0.79 |  |
| Discontinued operations |  | $ | — |  |  | $ | — |  |  | $ | (0.06 | ) |
| Net income per share - basic |  | $ | 1.27 |  |  | $ | 1.27 |  |  | $ | 0.73 |  |
| Net income (loss) per share - diluted: |  |  |  |  |  |  |
| Continuing operations |  | $ | 1.23 |  |  | $ | 1.24 |  |  | $ | 0.77 |  |
| Discontinued operations |  | $ | — |  |  | $ | — |  |  | $ | (0.05 | ) |
| Net income per share - diluted |  | $ | 1.23 |  |  | $ | 1.24 |  |  | $ | 0.72 |  |

[0001032975-18-000016:notes:265]
During fiscal years 2018, 2017 and 2016, 1.1 million, 1.4 million and 5.2 million share equivalents attributable to outstanding stock options, RSUs and ESPP were excluded from the calculation of diluted net income (loss) per share because the combined exercise price, average unamortized fair value and assumed tax benefits upon exercise of these options and ESPP or vesting of RSUs were greater than the average market price of the Company's shares, and therefore their inclusion would have been anti-dilutive.


## us-gaap:FairValueLiabilitiesMeasuredOnRecurringBasisUnobservableInputReconciliationTextBlock

[0001032975-18-000016:notes:266]
The following table summarizes the changes in the fair value of the Company’s contingent consideration balance measured with Level 3 inputs during fiscal years 2018 and 2017 (in thousands):

[0001032975-18-000016:notes:267]
|  |  | Year Ended March 31, |
|  |  | 2018 |  | 2017 |
| Acquisition-related contingent consideration, beginning of the year |  | $ | 9,908 |  |  | $ | — |  |
| Fair value of contingent consideration upon acquisition |  | — |  |  | 18,000 |  |
| Change in fair value of contingent consideration |  | (4,908 | ) |  | (8,092 | ) |
| Settlement payment |  | $ | (5,000 | ) |  | — |  |
| Acquisition-related contingent consideration, end of the year |  | $ | — |  |  | $ | 9,908 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001032975-18-000016:notes:268]
Fair Value Measurements

[0001032975-18-000016:notes:269]
The Company considers fair value as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants at the measurement date. The Company utilizes the following three-level fair value hierarchy to establish the priorities of the inputs used to measure fair value:

[0001032975-18-000016:notes:270]
| • | Level 1—Quoted prices in active markets for identical assets or liabilities. |

[0001032975-18-000016:notes:271]
| • | Level 2—Observable inputs other than quoted market prices included in Level 1, such as quoted prices for similar assets and liabilities in active markets; quoted prices for identical or similar assets and liabilities in markets that are not active; or other inputs that are observable or can be corroborated by observable market data. |

[0001032975-18-000016:notes:272]
| • | Level 3—Unobservable inputs that are supported by little or no market activity and that are significant to the fair value of the assets or liabilities. This includes certain pricing models, discounted cash flow methodologies and similar techniques that use significant unobservable inputs. |

[0001032975-18-000016:notes:273]
The following table presents the Company's financial assets and liabilities that were accounted for at fair value on a recurring basis, excluding assets related to the Company's defined benefit pension plans, classified by the level within the fair value hierarchy (in thousands):

[0001032975-18-000016:notes:274]
|  |  | March 31, 2018 |  | March 31, 2017 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Level 1 |  | Level 2 |  | Level 3 |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 492,535 |  |  | $ | — |  |  | $ | — |  |  | $ | 448,742 |  |  | $ | — |  |  | $ | — |  |
| Trading investments for deferred compensation plan included in other assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 2,881 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,813 |  |  | $ | — |  |  | $ | — |  |
| Mutual funds |  | 14,867 |  |  | — |  |  | — |  |  | 12,230 |  |  | — |  |  | — |  |
| Total of trading investments for deferred compensation plan |  | $ | 17,748 |  |  | $ | — |  |  | $ | — |  |  | $ | 15,043 |  |  | $ | — |  |  | $ | — |  |
| Currency derivative assets included in other current assets |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 48 |  |  | $ | — |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisition-related contingent consideration included in accrued and other current liabilities and other non-current liabilities |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 9,908 |  |
| Currency derivative liabilities included in accrued and other current liabilities |  | $ | — |  |  | $ | 34 |  |  | $ | — |  |  | $ | — |  |  | $ | 443 |  |  | $ | — |  |

[0001032975-18-000016:notes:275]
Acquisition-related contingent consideration

[0001032975-18-000016:notes:276]
The acquisition-related contingent consideration liability arising from the Jaybird Acquisition (see "Note 3 - Business Acquisitions") represented the future potential earn-out payments of up to $45.0 million in cash based on the achievement of certain net revenue targets over approximately a two year period. If the net revenue targets would have been met, the Company would have paid a maximum of $25.0 million and $20.0 million in fiscal years 2018 and 2019, respectively. The fair value of the earn-out as of the Jaybird Acquisition Date was $18.0 million, which was determined by using a Monte Carlo Simulation that includes significant unobservable inputs such as a risk-adjusted discount rate of 16% and projected net sales of Jaybird over the earn-out period. The fair value was remeasured at each reporting period at the estimated fair value based on the inputs on the date of remeasurement, with the change in fair value recognized as "change in fair value of contingent consideration for business acquisition" in the operating expense section in the consolidated statements of operations. Projected net sales were based on our internal projections, including analysis of the target markets.

[0001032975-18-000016:notes:277]
In October 2017, the Company and the sellers of Jaybird entered into an agreement fully, irrevocably and unconditionally releasing the Company from the earn-out rights and payments in exchange for $5.0 million in cash, which approximated the fair value of the contingent consideration. As a result, the contingent consideration was transferred out from financial liability with Level 3 inputs as fair value measurement was no longer required. The Company paid the $5.0 million in November 2017 and included the same as financing activities on its consolidated statements of cash flows.

[0001032975-18-000016:notes:278]
Investment Securities

[0001032975-18-000016:notes:279]
The marketable securities for the Company's deferred compensation plan are recorded at a fair value of $17.7 million and $15.0 million as of March 31, 2018 and 2017, respectively, based on quoted market prices. Quoted market prices are observable inputs that are classified as Level 1 within the fair value hierarchy. Unrealized trading gains related to trading securities for the fiscal years 2018, 2017 and 2016 were not significant and are included in other income (expense), net in the consolidated statements of operations.

[0001032975-18-000016:notes:280]
Assets Measured at Fair Value on a Nonrecurring Basis

[0001032975-18-000016:notes:281]
The Company’s non-marketable cost method investments, and non-financial assets, such as intangible assets and acquisition-related property, plant and equipment, are recorded at fair value only upon initial recognition or if an impairment is recognized. There was no impairment of long-lived assets during fiscal years 2018, 2017 and 2016.

[0001032975-18-000016:notes:282]
A summary of the valuation methodologies for assets and liabilities measured on a nonrecurring basis is as follows:

[0001032975-18-000016:notes:283]
Non-marketable cost method investments. These investments are classified as Level 3 due to the absence of quoted market prices, the inherent lack of liquidity, and the fact that inputs used to measure fair value are unobservable and require management's judgment. When certain events or circumstances indicate that impairment may exist, the Company revalues the investments using various assumptions, including the financial metrics and ratios of comparable public companies. There was no material impairment during fiscal years 2018, 2017 and 2016.

[0001032975-18-000016:notes:284]
The primary investment included in non-marketable investments is the Company’s investment in Series A Preferred Stock of Lifesize recorded at the estimated fair value of $5.6 million on the date of Lifesize divestiture. Refer to Note 4 "Discontinued Operations" to consolidated financial statements for the valuation approach and significant inputs and assumptions.

[0001032975-18-000016:notes:285]
The aggregate recorded amount of cost method investments included in other assets at March 31, 2018 and March 31, 2017 was $7.3 million and $7.4 million, respectively.

[0001032975-18-000016:notes:286]
Non-Financial Assets. Goodwill, intangible assets, and property, plant and equipment, are not required to be measured at fair value on a recurring basis. However, if certain triggering events occur (or tested at least annually for goodwill) such that a non-financial instrument is required to be evaluated for impairment and an impairment is recorded to reduce the non-financial instrument's carrying value to the fair value as a result of such triggering events, the non-financial assets and liabilities are measured at fair value for the period such triggering events occur. See Note 2 herein, for additional information about how the Company tests various asset classes for impairment.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001032975-18-000016:notes:287]
Goodwill and Other Intangible Assets

[0001032975-18-000016:notes:288]
The Company performed its annual impairment analysis of the goodwill as of December 31, 2017 by performing a qualitative assessment and concluded that it was more likely than not that the fair value of its peripherals reporting unit, the only reporting unit of the Company, exceeded its carrying amount. In assessing the qualitative factors, the Company considered the impact of these key factors: change in industry and competitive environment, growth in market capitalization, and budgeted-to-actual revenue performance for the twelve months ended December 31, 2017. There have been no significant events or circumstances affecting the valuation of goodwill subsequent to the annual impairment test.

[0001032975-18-000016:notes:289]
The following table summarizes the activity in the Company's goodwill balance during fiscal years 2018 and 2017 (in thousands):

[0001032975-18-000016:notes:290]
|  |  | Years Ended March 31, |
|  |  | 2018 |  | 2017 |
| Beginning of the period |  | $ | 249,741 |  |  | $ | 218,224 |  |
| Acquisitions |  | 25,800 |  |  | 31,553 |  |
| Currency exchange rate impact and other |  | (90 | ) |  | (36 | ) |
| End of the period |  | $ | 275,451 |  |  | $ | 249,741 |  |

[0001032975-18-000016:notes:291]
The Company's acquired intangible assets subject to amortization were as follows (in thousands):

[0001032975-18-000016:notes:292]
|  |  | March 31, |
|  |  | 2018 |  | 2017 |
|  |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |
| Trademark and tradenames |  | $ | 23,870 |  |  | $ | (9,482 | ) |  | $ | 14,388 |  |  | $ | 16,500 |  |  | $ | (6,933 | ) |  | $ | 9,567 |  |
| Technology |  | 77,175 |  |  | (50,755 | ) |  | 26,420 |  |  | 63,285 |  |  | (42,831 | ) |  | 20,454 |  |
| Customer contracts/relationships |  | 59,510 |  |  | (12,771 | ) |  | 46,739 |  |  | 25,180 |  |  | (7,637 | ) |  | 17,543 |  |
|  |  | $ | 160,555 |  |  | $ | (73,008 | ) |  | $ | 87,547 |  |  | $ | 104,965 |  |  | $ | (57,401 | ) |  | $ | 47,564 |  |

[0001032975-18-000016:notes:293]
For fiscal years 2018, 2017 and 2016, amortization expense for other intangible assets was, $15.6 million, $9.4 million and $0.4 million, respectively. The Company expects that annual amortization expense for fiscal years 2019, 2020, 2021, 2022 and 2023 will be $19.6 million, $19.6 million, $15.3 million, $12.1 million and $8.1 million, respectively, and $12.9 million thereafter.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001032975-18-000016:notes:294]
The Company is incorporated in Switzerland but operates in various countries with differing tax laws and rates. Further, a portion of the Company's income (loss) before taxes and the provision for (benefit from) income taxes is generated outside of Switzerland.

[0001032975-18-000016:notes:295]
Income from continuing operations before income taxes for the fiscal years 2018, 2017 and 2016 is summarized as follows (in thousands):

[0001032975-18-000016:notes:296]
|  |  | Years Ended March 31, |
|  |  | 2018 |  | 2017 |  | 2016 |
| Swiss |  | $ | 177,935 |  |  | $ | 161,544 |  |  | $ | 80,572 |  |
| Non-Swiss |  | 54,330 |  |  | 53,445 |  |  | 50,900 |  |
| Income before taxes |  | $ | 232,265 |  |  | $ | 214,989 |  |  | $ | 131,472 |  |

[0001032975-18-000016:notes:297]
The provision for (benefit from) income taxes is summarized as follows (in thousands):

[0001032975-18-000016:notes:298]
|  |  | Years Ended March 31, |
|  |  | 2018 |  | 2017 |  | 2016 |
| Current: |  |  |  |  |  |  |
| Swiss |  | $ | 3,526 |  |  | $ | 1,934 |  |  | $ | 1,668 |  |
| Non-Swiss |  | 13,142 |  |  | 9,774 |  |  | (2,582 | ) |
| Deferred: |  |  |  |  |  |  |
| Non-Swiss |  | 7,055 |  |  | (2,595 | ) |  | 4,024 |  |
| Provision for income taxes |  | $ | 23,723 |  |  | $ | 9,113 |  |  | $ | 3,110 |  |

[0001032975-18-000016:notes:299]
The difference between the provision for income taxes and the expected tax provision at the statutory income tax rate of 8.5% is reconciled below (in thousands):

[0001032975-18-000016:notes:300]
|  |  | Years Ended March 31, |
|  |  | 2018 |  | 2017 |  | 2016 |
| Expected tax provision at statutory income tax rates |  | $ | 19,743 |  |  | $ | 18,274 |  |  | $ | 11,175 |  |
| Income taxes at different rates |  | (9,611 | ) |  | (5,247 | ) |  | (2,713 | ) |
| Research and development tax credits |  | (4,124 | ) |  | (2,309 | ) |  | (1,619 | ) |
| Executive compensation |  | 1,835 |  |  | 654 |  |  | 864 |  |
| Stock-based compensation |  | (9,376 | ) |  | 1,794 |  |  | 1,446 |  |
| Deferred tax effects from Tax Act |  | 22,325 |  |  | — |  |  | — |  |
| Valuation allowance |  | 533 |  |  | 1,024 |  |  | 947 |  |
| Restructuring charges / (credits) |  | (10 | ) |  | 2 |  |  | 1,514 |  |
| Tax reserves (releases), net |  | 3,627 |  |  | (5,570 | ) |  | (8,761 | ) |
| Other, net |  | (1,219 | ) |  | 491 |  |  | 257 |  |
| Provision for income taxes |  | $ | 23,723 |  |  | $ | 9,113 |  |  | $ | 3,110 |  |

[0001032975-18-000016:notes:301]
Deferred income tax assets and liabilities consist of the following (in thousands):

[0001032975-18-000016:notes:302]
|  |  | March 31, |
|  |  | 2018 |  | 2017 |
| Deferred tax assets: |  |  |  |  |  |  |
| Net operating loss carryforwards |  | $ | 15,476 |  |  | $ | 4,306 |  |
| Tax credit carryforwards |  | 45,421 |  |  | 5,825 |  |
| Accruals |  | 42,765 |  |  | 41,570 |  |
| Depreciation and amortization |  | 1,505 |  |  | 2,860 |  |
| Share-based compensation |  | 7,479 |  |  | 11,846 |  |
| Gross deferred tax assets |  | 112,646 |  |  | 66,407 |  |
| Valuation allowance |  | (25,148 | ) |  | (6,626 | ) |
| Gross deferred tax assets after valuation allowance |  | 87,498 |  |  | 59,781 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |
| Acquired intangible assets and other |  | (4,827 | ) |  | (4,267 | ) |
| Gross deferred tax liabilities |  | (4,827 | ) |  | (4,267 | ) |
| Deferred tax assets, net |  | $ | 82,671 |  |  | $ | 55,514 |  |

[0001032975-18-000016:notes:303]
On December 22, 2017, the Tax Act was signed into law in the United States. The Tax Act introduced a broad range of tax reform measures that significantly change the federal income tax regime. Among other things, the Tax Act permanently reduces the corporate income tax rate from 35% to 21% effective for tax years including or commencing on January 1, 2018, repeals corporate alternative minimum tax, limits various business deductions such as executive compensation under IRC 162(m), modifies the maximum deduction of net operating loss with no carryback but indefinite carryforward provision. On the international front, the Tax Act enacted a transition tax on applicable accumulated earnings of United States owned foreign subsidiaries and various other provisions. The majority of the international provisions are not applicable to the Company. Many provisions in the Tax Act are generally effective in tax years beginning after December 31, 2017.

[0001032975-18-000016:notes:304]
ASC 740 requires recognition of the effects of tax law changes in the period of enactment. The Company applied a blended federal income tax rate of 31.6% to its operations in the United States effective at the beginning of the fiscal year based on a pro-rated percentage of the number of days before and after January 1, 2018. Furthermore, the Company recorded a provisional income tax charge net of valuation allowance of $21.7 million in fiscal year 2018 to remeasure the deferred tax effects at 21%.

[0001032975-18-000016:notes:305]
The net provisional charge from remeasuring gross deferred tax assets of approximately $35.0 million and assessment of valuation allowance is based on currently available information and interpretations which are continuing to evolve. The Company continues to analyze additional information and guidance related to certain aspects of the Tax Act, such as limitations on the deductibility of executive compensation, conformity or changes by state taxing authorities in response to the Tax Act, and the final determination of the net deferred tax assets subject to the remeasurement and related impacts to the assessment of valuation allowance. The prospects of supplemental legislation or regulatory processes to address questions that arise because of the Tax Act, or evolving technical interpretations of the tax law, may cause the final impact from the Tax Act to differ from the recorded amounts. The measurement period allowed by Staff SAB No.118 is no later than the third quarter of fiscal year 2019.

[0001032975-18-000016:notes:306]
Management regularly assesses the ability to realize deferred tax assets recorded in the Company's entities based upon the weight of available evidence, including such factors as recent earnings history and expected future taxable income. In the event that the Company changes its determination as to the amount of deferred tax assets that can be realized, the Company will adjust its valuation allowance with a corresponding impact to the provision for income taxes in the period in which such determination is made.

[0001032975-18-000016:notes:307]
The Company had a valuation allowance of $25.1 million at March 31, 2018, increased from $6.6 million at March 31, 2017 primarily due to $18.0 million increase for deferred tax assets upon the adoption of ASU 2016-09 on April 1, 2017. The adoption generated federal valuation allowance of $6.4 million and added $11.6 million to California valuation allowance in the United States. The federal valuation allowance was subsequently reduced by $4.1 million from the assessment of the Tax Act against tax credits. The Company had a valuation allowance of $22.1 million as of March 31, 2018 against deferred tax assets in the state of California, an increase from $5.9 million as of March 31, 2017 primarily due to the adoption of ASU 2016-09 described above and impact from the Tax Act in the amount of $3.5 million. The remaining valuation allowance primarily represents $0.7 million for various tax credit carryforwards. The Company determined that it is more likely than not that the Company would not generate sufficient taxable income in the future to utilize such deferred tax assets.

[0001032975-18-000016:notes:308]
As of March 31, 2018, the Company had foreign net operating loss and tax credit carryforwards for income tax purposes of $217.1 million and $50.5 million. Unused net operating loss carryforwards will expire at various dates in fiscal years 2019 to 2038. Certain net operating loss carryforwards in the United States relate to acquisitions and, as a result, are limited in the amount that can be utilized in any one year. The tax credit carryforwards will begin to expire in fiscal year 2020.

[0001032975-18-000016:notes:309]
Swiss income taxes and non-Swiss withholding taxes associated with the repatriation of earnings or for other temporary differences related to investments in non-Swiss subsidiaries have not been provided for, as the Company intends to reinvest the earnings of such subsidiaries indefinitely or the Company has concluded that no additional tax liability would arise on the distribution of such earnings. If these earnings were distributed to Switzerland in the form of dividends or otherwise, or if the shares of the relevant non-Swiss subsidiaries were sold or otherwise transferred, the Company may be subject to additional Swiss income taxes and non-Swiss withholding taxes. As of March 31, 2018, the cumulative amount of unremitted earnings of non-Swiss subsidiaries for which no income taxes have been provided is approximately $90.4 million. The amount of unrecognized deferred income tax liability related to these earnings is estimated to be approximately $0.6 million.

[0001032975-18-000016:notes:310]
The Company follows a two-step approach in recognizing and measuring uncertain tax positions. The first step is to evaluate the tax position for recognition by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step is to measure the tax benefit as the largest amount that is more than 50% likely of being realized upon ultimate settlement.

[0001032975-18-000016:notes:311]
As of March 31, 2018 and March 31, 2017, the total amount of unrecognized tax benefits due to uncertain tax positions was $69.1 million and $63.7 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-18-000016:notes:312]
As of March 31, 2018, the Company had $35.0 million in non-current income taxes payable, including interest and penalties, related to the Company's income tax liability for uncertain tax positions. As of March 31, 2017, the Company had $51.8 million in non-current income taxes payable and $1.5 million in current income taxes payable, including interest and penalties, related to the Company's income tax liability for uncertain tax positions. The Company applied to a settlement program and paid $1.9 million to the tax authorities in a foreign jurisdiction in the third quarter of fiscal year 2018. The audit was effectively settled in the fourth quarter.

[0001032975-18-000016:notes:313]
The aggregate changes in gross unrecognized tax benefits in fiscal years 2018, 2017 and 2016 were as follows (in thousands):

[0001032975-18-000016:notes:314]
| March 31, 2015 |  | $ | 79,023 |  |
| Lapse of statute of limitations |  | (15,518 | ) |
| Decreases in balances related to tax positions taken during prior years |  | (1,502 | ) |
| Increases in balances related to tax positions taken during the year |  | 7,876 |  |
| March 31, 2016 |  | $ | 69,879 |  |
| Lapse of statute of limitations |  | (14,161 | ) |
| Decreases in balances related to tax positions taken during prior years |  | (1,610 | ) |
| Increases in balances related to tax positions taken during the year |  | 9,559 |  |
| March 31, 2017 |  | $ | 63,667 |  |
| Lapse of statute of limitations |  | (7,505 | ) |
| Settlements with tax authorities |  | (704 | ) |
| Increases in balances related to tax positions taken during the year |  | 13,673 |  |
| March 31, 2018 |  | $ | 69,131 |  |

[0001032975-18-000016:notes:315]
The Company recognizes interest and penalties related to unrecognized tax positions in income tax expense. The Company recognized $0.6 million, $0.7 million and $0.3 million in interest and penalties in income tax expense during fiscal years 2018, 2017 and 2016, respectively. As of March 31, 2018, 2017 and 2016, the Company had $2.3 million, $3.0 million and $3.6 million of accrued interest and penalties related to uncertain tax positions, respectively.

[0001032975-18-000016:notes:316]
The Company files Swiss and foreign tax returns. The Company received final tax assessments in Switzerland through fiscal year 2014. For other foreign jurisdictions such as the United States, the Company is generally not subject to tax examinations for years prior to fiscal year 2015. The Company is under examination and has received assessment notices in foreign tax jurisdictions. If the examinations are resolved unfavorably, there is a possibility they may have a material negative impact on its results of operations.

[0001032975-18-000016:notes:317]
Although the Company has adequately provided for uncertain tax positions, the provisions on these positions may change as revised estimates are made or the underlying matters are settled or otherwise resolved. During the next 12 months, it is reasonably possible that the amount of unrecognized tax benefits could increase or decrease significantly due to changes in tax law in various jurisdictions, new tax audits and changes in the U.S. Dollar as compared to other currencies. Excluding these factors, uncertain tax positions may decrease by as much as $21.9 million primarily from the lapse of the statutes of limitations in various jurisdictions during the next 12 months.


## us-gaap:InterestAndOtherIncomeTableTextBlock

[0001032975-18-000016:notes:318]
Other income (expense), net comprises of the following (in thousands):

[0001032975-18-000016:notes:319]
|  |  | Years Ended March 31, |
|  |  | 2018 |  | 2017 |  | 2016 |
| Investment income (loss) related to a deferred compensation plan |  | $ | 1,386 |  |  | $ | 1,343 |  |  | $ | (364 | ) |
| Currency exchange gain (loss), net |  | (4,613 | ) |  | 169 |  |  | 2,110 |  |
| Other |  | 790 |  |  | 165 |  |  | (122 | ) |
| Other income (expense), net |  | $ | (2,437 | ) |  | $ | 1,677 |  |  | $ | 1,624 |  |


## us-gaap:InterestAndOtherIncomeTextBlock

[0001032975-18-000016:notes:320]
Other Income (Expense), net


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0001032975-18-000016:notes:321]
geographic region were as follows (in thousands):

[0001032975-18-000016:notes:322]
|  |  | March 31, |
|  |  | 2018 |  | 2017 |
| Americas |  | $ | 35,404 |  |  | $ | 37,242 |  |
| EMEA |  | 4,690 |  |  | 4,006 |  |
| Asia Pacific |  | 46,210 |  |  | 44,160 |  |
|  |  | $ | 86,304 |  |  | $ | 85,408 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001032975-18-000016:notes:323]
Restructuring

[0001032975-18-000016:notes:324]
During the first quarter of fiscal year 2016, the Company implemented a restructuring plan to exit the OEM business, reorganize Lifesize to sharpen its focus on its cloud-based offering, and streamline the Company's overall cost structure through overhead and infrastructure cost reductions with a targeted resource realignment. Restructuring charges incurred under this plan primarily consisted of severance and other ongoing and one-time termination benefits. Charges and other costs related to the workforce reduction and structure realignment are presented as restructuring charges in the Consolidated Statements of Operations. On a total company basis, including the Lifesize video conferencing business as reported in discontinued operations, the Company has incurred $25.4 million under this restructuring plan, including $24.3 million for cash severance and other personnel costs. The Company substantially completed this restructuring plan by the fourth quarter of fiscal year 2016.

[0001032975-18-000016:notes:325]
The following table summarizes restructuring-related activities during fiscal year 2018, 2017 and 2016 from continuing operations (in thousands):

[0001032975-18-000016:notes:326]
|  |  | Restructuring - Continuing Operations |
|  |  | TerminationBenefits |  | Lease ExitCosts |  | Other |  | Total |
| Accrual balance at March 31, 2015 |  | $ | — |  |  | $ | 954 |  |  | $ | — |  |  | $ | 954 |  |
| Charges, net |  | 17,280 |  |  | 337 |  |  | 185 |  |  | 17,802 |  |
| Cash payments |  | (11,373 | ) |  | (1,166 | ) |  | (185 | ) |  | (12,724 | ) |
| Accrual balance at March 31, 2016 |  | 5,907 |  |  | 125 |  |  | — |  |  | 6,032 |  |
| Charges, net |  | 23 |  |  | — |  |  | — |  |  | 23 |  |
| Cash payments |  | (5,195 | ) |  | (125 | ) |  | — |  |  | (5,320 | ) |
| Accrual balance at March 31, 2017 |  | $ | 735 |  |  | $ | — |  |  | $ | — |  |  | $ | 735 |  |
| Credits, net |  | (116 | ) |  | — |  |  | — |  |  | (116 | ) |
| Cash payments |  | (619 | ) |  | — |  |  | — |  |  | (619 | ) |
| Accrual balance at March 31, 2018 |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |

[0001032975-18-000016:notes:327]
The accrual balances are included in accrued and other current liabilities on the Company’s consolidated balance sheets.


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001032975-18-000016:notes:328]
Net sales by geographic region for fiscal years 2018, 2017 and 2016 (based on the customers' locations) were as follows (in thousands):

[0001032975-18-000016:notes:329]
|  |  | Years Ended March 31, |
|  |  | 2018 |  | 2017 |  | 2016 |
| Americas |  | $ | 1,118,324 |  |  | $ | 963,674 |  |  | $ | 881,379 |  |
| EMEA |  | 820,347 |  |  | 746,898 |  |  | 645,694 |  |
| Asia Pacific |  | 628,192 |  |  | 510,855 |  |  | 491,027 |  |
|  |  | $ | 2,566,863 |  |  | $ | 2,221,427 |  |  | $ | 2,018,100 |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001032975-18-000016:notes:330]
The components of accumulated other comprehensive loss were as follows (in thousands):

[0001032975-18-000016:notes:331]
|  |  | Accumulated Other Comprehensive Income (Loss) |
|  |  | CumulativeTranslationAdjustment (1) |  | DefinedBenefitPlans(1) |  | DeferredHedgingGains (Losses) |  | Total |
| March 31, 2017 |  | $ | (89,708 | ) |  | $ | (10,480 | ) |  | $ | (518 | ) |  | $ | (100,706 | ) |
| Other comprehensive income (loss) |  | 5,860 |  |  | 4,082 |  |  | (2,691 | ) |  | 7,251 |  |
| March 31, 2018 |  | $ | (83,848 | ) |  | $ | (6,398 | ) |  | $ | (3,209 | ) |  | $ | (93,455 | ) |

[0001032975-18-000016:notes:332]
_______________________________________

[0001032975-18-000016:notes:333]
(1) Tax effect was not significant as of March 31, 2018 or 2017.


## us-gaap:ScheduleOfRecognizedIdentifiedAssetsAcquiredAndLiabilitiesAssumedTableTextBlock

[0001032975-18-000016:notes:334]
The following table summarizes the estimated fair values of the assets acquired and liabilities assumed at the ASTRO Acquisition Date (in thousands):


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001032975-18-000016:notes:335]
VALUATION AND QUALIFYING ACCOUNTS

[0001032975-18-000016:notes:336]
For the Fiscal Years Ended March 31, 2018, 2017 and 2016 (in thousands)

[0001032975-18-000016:notes:337]
The Company's Schedule II includes valuation and qualifying accounts related to allowances for doubtful accounts, sales returns, cooperative marketing arrangements, customer incentive programs, and pricing programs, for direct customers and tax valuation allowances. The Company also has sales incentive programs for indirect customers with whom it does not have a direct sales and receivable relationship. These programs are recorded as accrued liabilities and are not considered valuation or qualifying accounts.

[0001032975-18-000016:notes:338]
|  |  | Balance atBeginning ofYear |  | Charged(Credited) to Statement ofOperations (1)(2) |  | Claims andAdjustmentsApplied AgainstAllowances (1) |  | Balance atEnd ofYear |
| Allowance for doubtful accounts: |  |  |  |  |  |  |  |  |  |  |  |  |
| 2018 |  | $ | 607 |  |  | $ | (404 | ) |  | $ | (81 | ) |  | $ | 122 |  |
| 2017 |  | $ | 667 |  |  | $ | 47 |  |  | $ | (107 | ) |  | $ | 607 |  |
| 2016 |  | $ | 707 |  |  | $ | 71 |  |  | $ | (111 | ) |  | $ | 667 |  |
| Allowance for sales returns: |  |  |  |  |  |  |  |  |  |  |  |  |
| 2018 |  | $ | 18,800 |  |  | $ | 111,969 |  |  | $ | (105,254 | ) |  | $ | 25,515 |  |
| 2017 |  | $ | 18,526 |  |  | $ | 78,242 |  |  | $ | (77,968 | ) |  | $ | 18,800 |  |
| 2016 |  | $ | 17,236 |  |  | $ | 66,935 |  |  | $ | (65,645 | ) |  | $ | 18,526 |  |
| Allowances for cooperative marketing arrangements: |  |  |  |  |  |  |  |  |  |  |  |  |
| 2018 |  | $ | 28,022 |  |  | $ | 160,664 |  |  | $ | (158,297 | ) |  | $ | 30,389 |  |
| 2017 |  | $ | 28,157 |  |  | $ | 144,656 |  |  | $ | (144,791 | ) |  | $ | 28,022 |  |
| 2016 |  | $ | 24,919 |  |  | $ | 131,410 |  |  | $ | (128,172 | ) |  | $ | 28,157 |  |
| Allowances for customer incentive programs: |  |  |  |  |  |  |  |  |  |  |  |  |
| 2018 |  | $ | 60,857 |  |  | $ | 230,838 |  |  | $ | (221,103 | ) |  | $ | 70,592 |  |
| 2017 |  | $ | 60,872 |  |  | $ | 196,363 |  |  | $ | (196,378 | ) |  | $ | 60,857 |  |
| 2016 |  | $ | 47,364 |  |  | $ | 164,307 |  |  | $ | (150,799 | ) |  | $ | 60,872 |  |
| Allowances for pricing programs: |  |  |  |  |  |  |  |  |  |  |  |  |
| 2018 |  | $ | 102,289 |  |  | $ | 445,048 |  |  | $ | (405,968 | ) |  | $ | 141,369 |  |
| 2017 |  | $ | 81,553 |  |  | $ | 322,118 |  |  | $ | (301,382 | ) |  | $ | 102,289 |  |
| 2016 |  | $ | 70,951 |  |  | $ | 260,698 |  |  | $ | (250,096 | ) |  | $ | 81,553 |  |
| Tax valuation allowances: |  |  |  |  |  |  |  |  |  |  |  |  |
| 2018 |  | $ | 6,626 |  |  | $ | 18,496 |  |  | $ | 26 |  |  | $ | 25,148 |  |
| 2017 |  | $ | 5,338 |  |  | $ | 1,299 |  |  | $ | (11 | ) |  | $ | 6,626 |  |
| 2016 |  | $ | 5,590 |  |  | $ | 1,255 |  |  | $ | (1,507 | ) |  | $ | 5,338 |  |

[0001032975-18-000016:notes:339]
(1) The amounts for fiscal years 2018 and 2017 both include immaterial impacts from the business acquisitions during the year. Refer to Note 3 to the consolidated financial statements.

[0001032975-18-000016:notes:340]
(2)The amount for tax valuation allowance in fiscal year 2018 primarily includes the impact of $18.0 million from the adoption of ASU 2016-09 effective April 1, 2017. Refer to Note 2 to the consolidated financial statements.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001032975-18-000016:notes:341]
Segment Information

[0001032975-18-000016:notes:342]
As discussed in "Note 2 — Summary of Significant Accounting Policies", the Company has determined that it operates in a single operating segment that encompasses the design, manufacturing and marketing of peripherals for PCs, tablets and other digital platforms. Operating performance measures are provided directly to the Company's CEO, who is considered to be the Company’s Chief Operating Decision Maker. The CEO periodically reviews information such as net sales and adjusted operating income (loss) to make business decisions. These operating performance measures do not include restructuring charges (credits), net, share-based compensation expense, amortization of intangible assets, charges from the purchase accounting effect on inventory, acquisition-related costs, change in fair value of contingent consideration from business acquisition, or gain (loss) from equity method investment.

[0001032975-18-000016:notes:343]
The United States represented 37%, 37% and 38% of net sales for the fiscal years 2018, 2017 and 2016, respectively. Germany represented 16% and 17% of net sales for the fiscal year 2018 and 2017, respectively. No other single country represented more than 10% of net sales during these periods. Revenues from net sales to customers in Switzerland, the Company's home domicile, represented 2% of net sales for each of fiscal years 2018, 2017 and 2016.

[0001032975-18-000016:notes:344]
Property, plant and equipment, net by geographic region were as follows (in thousands):

[0001032975-18-000016:notes:345]
Property, plant and equipment, net in the United States and China were $35.3 million and $37.9 million, respectively, as of March 31, 2018, and $37.1 million and $37.2 million, respectively, as of March 31, 2017. No other countries represented more than 10% of the Company's total consolidated property, plant and equipment, net at March 31, 2018 or 2017. Property, plant and equipment, net in Switzerland, the Company's home domicile, were  1.9 million and $2.1 million at March 31, 2018 and 2017, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001032975-18-000016:notes:346]
Shareholders' Equity

[0001032975-18-000016:notes:347]
Share Capital

[0001032975-18-000016:notes:348]
The Company's nominal share capital is CHF 43.3 million, consisting of 173,106,620 shares with a par value of CHF 0.25 each, all of which were issued and 8,526,642 of which were held in treasury shares as of March 31, 2018.

[0001032975-18-000016:notes:349]
The Company's has reserved conditional capital of 25,000,000 shares for potential issuance on the exercise of rights granted under the Company's employee equity incentive plans and additional conditional capital representing the issuance of up to 25,000,000 shares to cover any conversion rights under a future convertible bond issuance. This conditional capital was created in order to provide financing flexibility for future expansion, investments or acquisitions.

[0001032975-18-000016:notes:350]
Dividends

[0001032975-18-000016:notes:351]
Pursuant to Swiss corporate law, Logitech International S.A. may only pay dividends in Swiss Francs. The payment of dividends is limited to certain amounts of unappropriated retained earnings (CHF 782.3 million or $818.0 million based on the exchange rate at March 31, 2018) and is subject to shareholder approval.

[0001032975-18-000016:notes:352]
In May 2018, the Board of Directors recommended that the Company pay CHF 110.7 million ($115.7 million based on the exchange rate on March 31, 2018) in cash dividends for fiscal year 2018. In September 2017, the Company declared and paid cash dividends of CHF 0.61 (USD equivalent of $0.63) per common share, totaling approximately $104.2 million in U.S. Dollars, on the Company’s outstanding common stock. In September 2016, the Company declared and paid cash dividends of CHF 0.56 (USD equivalent of $0.57) per common share, totaling approximately $93.1 million in U.S. Dollars, on the Company’s outstanding common stock. In September 2015, the Company declared and paid cash dividends of CHF 0.51 per share (USD equivalent of $0.53), totaling approximately $85.9 million in U.S. Dollars.

[0001032975-18-000016:notes:353]
Legal Reserves

[0001032975-18-000016:notes:354]
Under Swiss corporate law, a minimum of 5% of the Company's annual net income must be retained in a legal reserve until this legal reserve equals 20% of the Company's issued and outstanding aggregate par value per share capital. These legal reserves represent an appropriation of retained earnings that are not available for distribution and totaled $10.0 million at March 31, 2018 (based on the exchange rate at March 31, 2018).

[0001032975-18-000016:notes:355]
Share Repurchases

[0001032975-18-000016:notes:356]
In March 2014, the Company's Board of Directors approved the 2014 share buyback program, which authorizes the Company to use up to $250.0 million to purchase its own shares. This share buyback program expired in April 2017.

[0001032975-18-000016:notes:357]
In March 2017, the Company's Board of Directors approved the 2017 share buyback program, which authorizes the Company to use up to $250.0 million to purchase its own shares following the expiration date of 2014 buyback program. The Company's share buyback program is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Purchases may be started or stopped at any time without prior notice depending on market conditions and other factors.

[0001032975-18-000016:notes:358]
Accumulated Other Comprehensive Loss


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001032975-18-000016:notes:359]
Balance Sheet Components
