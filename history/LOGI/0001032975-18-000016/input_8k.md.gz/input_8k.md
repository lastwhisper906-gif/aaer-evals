# LOGI 8-K — 0001032975-18-000013 filed 2018-05-03

## item codes, every 8-K on or before 2018-05-21

- 2018-05-03 0001032975-18-000013 — 2.02, 5.02, 9.01
- 2018-01-23 0001032975-18-000005 — 2.02, 9.01
- 2017-10-24 0001032975-17-000043 — 2.02, 9.01
- 2017-09-18 0001032975-17-000040 — 5.07, 8.01
- 2017-07-25 0001032975-17-000028 — 2.02, 9.01
- 2017-07-12 0001032975-17-000022 — 1.01
- 2017-04-26 0001032975-17-000012 — 2.02, 9.01
- 2017-01-25 0001032975-17-000002 — 2.02, 9.01
- 2016-10-26 0001032975-16-000103 — 2.02, 9.01
- 2016-09-13 0001032975-16-000101 — 5.07, 8.01
- 2016-07-28 0001032975-16-000092 — 2.02, 9.01
- 2016-06-30 0001032975-16-000087 — 5.02
- 2016-04-28 0001032975-16-000077 — 2.02, 9.01
- 2016-04-14 0001032975-16-000073 — 1.01, 7.01, 9.01
- 2016-01-21 0001032975-16-000064 — 2.02, 9.01
- 2016-01-04 0001032975-16-000061 — 1.01, 2.01, 9.01
- 2015-12-23 0001032975-15-000059 — 5.02
- 2015-10-22 0001032975-15-000047 — 2.02, 9.01
- 2015-09-11 0001032975-15-000044 — 5.07, 8.01
- 2015-07-24 0001032975-15-000034 — 2.05 — amendment of 0001032975-15-000030
- 2015-07-23 0001032975-15-000030 — 2.02, 9.01
- 2015-06-25 0001032975-15-000025 — 5.02
- 2015-05-14 0001032975-15-000011 — 8.01, 9.01
- 2015-04-23 0001032975-15-000008 — 2.02, 2.05
- 2015-01-22 0001628280-15-000191 — 2.02, 8.01
- 2014-12-23 0001193125-14-450908 — 5.02, 5.07, 8.01
- 2014-11-25 0001193125-14-425233 — 3.01
- 2014-11-13 0001193125-14-411303 — 4.01, 9.01
- 2014-10-23 0001104659-14-073164 — 2.02, 9.01
- 2014-09-04 0001193125-14-331214 — 4.02, 9.01
- 2014-08-18 0001193125-14-313346 — 3.01, 9.01
- 2014-07-24 0001104659-14-053065 — 2.02, 9.01
- 2014-06-05 0001193125-14-226177 — 3.01, 9.01
- 2014-05-22 0001193125-14-208777 — 8.01, 9.01
- 2014-04-24 0001104659-14-029650 — 2.02, 9.01
- 2014-01-23 0001104659-14-003619 — 2.02, 9.01
- 2013-10-24 0001104659-13-077404 — 2.02, 9.01
- 2013-09-09 0001193125-13-361441 — 5.02, 5.07, 8.01, 9.01
- 2013-09-06 0001193125-13-359930 — 5.02, 9.01
- 2013-08-02 0001193125-13-317343 — 5.02
- 2013-07-25 0001104659-13-056372 — 2.02, 9.01
- 2013-06-28 0001193125-13-277394 — 5.02, 9.01
- 2013-06-20 0001193125-13-265914 — 8.01, 9.01
- 2013-04-25 0001104659-13-032570 — 2.02, 9.01
- 2013-04-17 0001193125-13-158923 — 5.02, 9.01
- 2013-03-01 0001193125-13-085804 — 2.05
- 2013-01-24 0001104659-13-004214 — 2.02, 9.01
- 2013-01-02 0001193125-13-000058 — 5.02
- 2012-10-25 0001104659-12-070966 — 2.02, 9.01
- 2012-09-11 0001193125-12-388070 — 5.02, 5.07, 8.01, 9.01
- 2012-08-22 0001193125-12-364167 — 5.02, 8.01, 9.01
- 2012-07-26 0001104659-12-051084 — 2.02, 9.01
- 2012-06-08 0001193125-12-264132 — 2.05, 9.01 — amendment, the index does not say of what
- 2012-04-26 0001193125-12-183657 — 5.02, 9.01
- 2012-04-26 0001104659-12-028470 — 2.02, 2.05, 9.01
- 2012-03-15 0001193125-12-115954 — 5.02, 9.01
- 2012-01-26 0001104659-12-004014 — 2.02, 9.01
- 2012-01-04 0001193125-12-002212 — 1.01, 2.03, 9.01
- 2011-10-27 0001104659-11-058150 — 2.02, 9.01
- 2011-09-12 0001193125-11-245931 — 5.07
- 2011-07-28 0001193125-11-200929 — 5.02, 9.01
- 2011-07-28 0001193125-11-199704 — 2.02, 9.01
- 2011-04-28 0001193125-11-112669 — 2.02, 9.01
- 2011-03-24 0001193125-11-076483 — 5.02, 9.01
- 2011-01-27 0001032975-11-000003 — 9.01
- 2010-10-28 0001032975-10-000032 — 9.01
- 2010-09-13 0001032975-10-000022 — 5.07
- 2010-07-29 0001032975-10-000010 — 2.02, 9.01
- 2010-06-10 0001193125-10-136877 — 5.02, 9.01
- 2010-05-03 0001193125-10-104337 — 5.02
- 2010-04-29 0001032975-10-000008 — 2.02, 9.01
- 2010-02-19 0001032975-10-000006 — 9.01 — amendment of 0001193125-09-252416
- 2010-01-21 0001032975-10-000002 — 2.02, 9.01
- 2009-12-14 0001193125-09-252416 — 2.01, 9.01
- 2009-11-17 0001032975-09-000023 — 1.01
- 2009-10-22 0001032975-09-000018 — 9.01
- 2009-09-22 0001193125-09-195545 — 5.02, 9.01
- 2009-09-03 0001032975-09-000013 — 8.01
- 2009-07-23 0001140361-09-016802 — 2.02, 9.01
- 2009-06-01 0001193125-09-122550 — 5.02
- 2009-04-23 0001193125-09-085054 — 2.02, 9.01
- 2009-04-02 0001193125-09-071272 — 5.02, 9.01
- 2009-01-20 0001193125-09-008454 — 2.05 — amendment of 0001193125-09-002609
- 2009-01-20 0001193125-09-007902 — 2.02, 9.01
- 2009-01-07 0001193125-09-002609 — 2.05, 9.01
- 2009-01-07 0001193125-09-002370 — 5.02, 9.01
- 2008-12-09 0001193125-08-250543 — 5.02, 9.01
- 2008-10-21 0001193125-08-213212 — 2.02, 9.01
- 2008-07-22 0001193125-08-154721 — 2.02, 9.01
- 2008-06-24 0001193125-08-139163 — 5.03, 9.01
- 2008-05-13 0001193125-08-113263 — 5.02, 9.01
- 2008-04-22 0001193125-08-086176 — 2.02, 9.01

## late-filing notifications on or before 2018-05-21

- 2015-06-02 0001032975-15-000020 — NT 10-K, for the period ended 2015-03-31
- 2014-11-06 0001193125-14-401306 — NT 10-Q, for the period ended 2014-09-30
- 2014-07-24 0001193125-14-277575 — NT 10-Q, for the period ended 2014-06-30
- 2014-05-22 0001193125-14-208712 — NT 10-K, for the period ended 2014-03-31
- 2009-08-06 0001032975-09-000006 — NT 10-Q, for the period ended 2009-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001032975-18-000013:8k_2_02:1]
EX-99.1
2
exhibit991q4fy18.htm
EXHIBIT 99.1

[0001032975-18-000013:8k_2_02:2]
Exhibit

[0001032975-18-000013:8k_2_02:3]
Exhibit 99.1

[0001032975-18-000013:8k_2_02:4]
Editorial Contacts:

[0001032975-18-000013:8k_2_02:5]
Ben Lu, Vice President, Investor Relations - USA (510) 713-5568

[0001032975-18-000013:8k_2_02:6]
Krista Todd, Vice President, External Communications - USA (510) 713-5834

[0001032975-18-000013:8k_2_02:7]
Ben Starkie, Corporate Communications - Europe +41 (0) 79-292-3499

[0001032975-18-000013:8k_2_02:8]
Logitech Grows to Highest Ever Fiscal Year Sales, Up 16%

[0001032975-18-000013:8k_2_02:9]
Fifth Consecutive Year of Strong Financial Performance

[0001032975-18-000013:8k_2_02:10]
Sales for Video Collaboration up 44% and Gaming up 57%

[0001032975-18-000013:8k_2_02:11]
NEWARK, Calif. - May 2, 2018 and LAUSANNE, Switzerland, May 3, 2018 - Logitech International (SIX: LOGN) (Nasdaq: LOGI) today announced financial results for the fourth quarter and full year of Fiscal Year 2018, ended March 31, 2018.

[0001032975-18-000013:8k_2_02:12]
For Fiscal Year 2018:

[0001032975-18-000013:8k_2_02:13]
| • | Sales were the highest ever at $2.57 billion, up 16 percent in US dollars and 13 percent in constant currency, compared to the prior year. |

[0001032975-18-000013:8k_2_02:14]
| • | GAAP operating income grew 8 percent to $230 million, compared to $212 million a year ago. GAAP earnings per share (EPS) was $1.23, compared to $1.24 a year ago. Fiscal Year 2018 GAAP EPS was impacted by a $22 million ($0.13 per share) one-time net tax expense following the reduction in the U.S. federal income tax rate and other reforms. |

[0001032975-18-000013:8k_2_02:15]
| • | Non-GAAP operating income grew 14 percent to $287 million, compared to $252 million a year ago. Non-GAAP EPS grew 13 percent to $1.60, compared to $1.41 a year ago. |

[0001032975-18-000013:8k_2_02:16]
| • | Cash flow from operations grew 20 percent to $346 million - the highest in eight years. |

[0001032975-18-000013:8k_2_02:17]
For Q4 Fiscal Year 2018:

[0001032975-18-000013:8k_2_02:18]
| • | Sales grew to $592 million, up 16 percent in US dollars and 9 percent in constant currency, compared to the prior year. |

[0001032975-18-000013:8k_2_02:19]
| • | GAAP operating income grew to $39 million, and non-GAAP operating income grew to a better-than-expected $55 million. |

[0001032975-18-000013:8k_2_02:20]
| • | Cash flow from operations reached $90 million. |

[0001032975-18-000013:8k_2_02:21]
“Over the past five years we’ve built a business with sustainable growth. We have a resilient and expanding portfolio. We are building five scalable capabilities led by design and engineering,” said Bracken Darrell, Logitech president and chief executive officer. “Fiscal Year 2018 delivered broad-based, double-digit growth led by Gaming and Video Collaboration. Now, as we look to the next five years, we will go on the offense to accelerate the creation of an amazing company.”

[0001032975-18-000013:8k_2_02:22]
Vincent Pilette, Logitech chief financial officer, said, “We’ve delivered a great fiscal year with record sales and better-than-expected profitability and cash flow from operations. We go into Fiscal Year 2019 with

[0001032975-18-000013:8k_2_02:23]
strong momentum, our financial fundamentals in place, and an eye toward shaping the portfolio and reallocating resources to continuously transform.”

[0001032975-18-000013:8k_2_02:24]
Outlook

[0001032975-18-000013:8k_2_02:25]
Logitech confirmed its Fiscal Year 2019 outlook of high single-digit sales growth in constant currency and $310 to $320 million in non-GAAP operating income.

[0001032975-18-000013:8k_2_02:26]
Management Update

[0001032975-18-000013:8k_2_02:27]
On May 2, 2018, L. Joseph Sullivan, the Company’s senior vice president, worldwide operations, announced his retirement and, effective immediately, resigned from the Company’s Group Management Team. The Company accepted this resignation. Mr. Sullivan’s retirement from Logitech will be effective as of February 2, 2019, the end of his contractual notice period.

[0001032975-18-000013:8k_2_02:28]
Prepared Remarks Available Online

[0001032975-18-000013:8k_2_02:29]
Logitech has made its prepared written remarks for the financial results teleconference available online on the Logitech corporate website at http://ir.logitech.com.

[0001032975-18-000013:8k_2_02:30]
Financial Results Teleconference and Webcast

[0001032975-18-000013:8k_2_02:31]
Logitech will hold a financial results teleconference to discuss the results for Q4 and the full Fiscal Year 2018 on Thursday, May 3, 2018 at 8:30 a.m. Eastern Daylight Time and 2:30 p.m. Central European Summer Time. A live webcast of the call will be available on the Logitech corporate website at http://ir.logitech.com.

[0001032975-18-000013:8k_2_02:32]
Use of Non-GAAP Financial Information and Constant Currency

[0001032975-18-000013:8k_2_02:33]
To facilitate comparisons to Logitech’s historical results, Logitech has included non-GAAP adjusted measures, which exclude share-based compensation expense, amortization of intangible assets, purchase accounting effect on inventory, acquisition-related costs, change in fair value of contingent consideration for business acquisition, restructuring charges (credits), gain (loss) on investments in privately held companies, investigation and related expenses, non-GAAP income tax adjustment, and other items detailed under “Supplemental Financial Information” after the tables below. Logitech also presents percentage sales growth in constant currency to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales. Logitech believes this information, used together with the GAAP financial information, will help investors to evaluate its current period performance and trends in its business. With respect to the Company’s outlook for non-GAAP operating income, most of these excluded amounts pertain to events that have not yet occurred and are not currently possible to estimate with a reasonable degree of accuracy. Therefore, no reconciliation to the GAAP amounts has been provided for Fiscal Year 2019.

[0001032975-18-000013:8k_2_02:34]
About Logitech

[0001032975-18-000013:8k_2_02:35]
Logitech designs products that have an everyday place in people's lives, connecting them to the digital experiences they care about. More than 35 years ago, Logitech started connecting people through computers, and now it’s a multi-brand company designing products that bring people together through music, gaming, video and computing. Brands of Logitech include Logitech, Ultimate Ears, Jaybird, Logitech G and ASTRO Gaming. Founded in 1981, and headquartered in Lausanne, Switzerland, Logitech International is a Swiss public company listed on the SIX Swiss Exchange (LOGN) and on the Nasdaq Global Select Market (LOGI). Find Logitech at www.logitech.com, the company blog or @Logitech.

[0001032975-18-000013:8k_2_02:36]
# # #

[0001032975-18-000013:8k_2_02:37]
Note that unless noted otherwise, comparisons are year over year.

[0001032975-18-000013:8k_2_02:38]
Logitech and other Logitech marks are trademarks or registered trademarks of Logitech Europe S.A and/or its affiliates in the U.S. and other countries.  All other trademarks are the property of their respective owners. For more information about Logitech and its products, visit the company’s website at www.logitech.com.

[0001032975-18-000013:8k_2_02:39]
(LOGIIR)

[0001032975-18-000013:8k_2_02:40]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  | Fiscal Years Ended |
|  |  | March 31, |  | March 31, |
| GAAP CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Net sales |  | $ | 592,426 |  |  | $ | 510,552 |  |  | $ | 2,566,863 |  |  | $ | 2,221,427 |  |
| Cost of goods sold |  | 377,617 |  |  | 311,303 |  |  | 1,648,744 |  |  | 1,395,211 |  |
| Amortization of intangible assets and purchase accounting effect on inventory |  | 2,574 |  |  | 1,470 |  |  | 8,878 |  |  | 6,175 |  |
| Gross profit |  | 212,235 |  |  | 197,779 |  |  | 909,241 |  |  | 820,041 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Marketing and selling |  | 109,572 |  |  | 99,941 |  |  | 435,489 |  |  | 379,641 |  |
| Research and development |  | 37,616 |  |  | 33,658 |  |  | 143,760 |  |  | 130,525 |  |
| General and administrative |  | 23,387 |  |  | 24,683 |  |  | 96,353 |  |  | 100,270 |  |
| Amortization of intangible assets and acquisition-related costs |  | 2,553 |  |  | 1,279 |  |  | 8,930 |  |  | 5,814 |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | 1,833 |  |  | (4,908 | ) |  | (8,092 | ) |
| Restructuring charges (credits), net |  | — |  |  | 67 |  |  | (116 | ) |  | 23 |  |
| Total operating expenses |  | 173,128 |  |  | 161,461 |  |  | 679,508 |  |  | 608,181 |  |
| Operating income |  | 39,107 |  |  | 36,318 |  |  | 229,733 |  |  | 211,860 |  |
| Interest income |  | 1,872 |  |  | 1,189 |  |  | 4,969 |  |  | 1,452 |  |
| Other income (expense), net |  | (1,543 | ) |  | 734 |  |  | (2,437 | ) |  | 1,677 |  |
| Income before income taxes |  | 39,436 |  |  | 38,241 |  |  | 232,265 |  |  | 214,989 |  |
| Provision for (benefit from) income taxes |  | 5,032 |  |  | (1,184 | ) |  | 23,723 |  |  | 9,113 |  |
| Net income |  | $ | 34,404 |  |  | $ | 39,425 |  |  | $ | 208,542 |  |  | $ | 205,876 |  |
| Net income per share : |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.21 |  |  | $ | 0.24 |  |  | $ | 1.27 |  |  | $ | 1.27 |  |
| Diluted |  | $ | 0.20 |  |  | $ | 0.24 |  |  | $ | 1.23 |  |  | $ | 1.24 |  |
| Weighted average shares used to compute net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | 164,374 |  |  | 162,023 |  |  | 164,038 |  |  | 162,058 |  |
| Diluted |  | 169,387 |  |  | 166,526 |  |  | 168,971 |  |  | 165,540 |  |
| Cash dividend per share |  | $ | — |  |  | $ | — |  |  | $ | 0.63 |  |  | $ | 0.57 |  |

[0001032975-18-000013:8k_2_02:41]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |
| PRELIMINARY RESULTS |
| (In thousands) - unaudited |  |  |  |  |
|  |  | March 31, |  | March 31, |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  | 2018 |  | 2017 |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 641,947 |  |  | $ | 547,533 |  |
| Accounts receivable, net |  | 214,885 |  |  | 185,179 |  |
| Inventories |  | 259,906 |  |  | 253,401 |  |
| Other current assets |  | 56,362 |  |  | 41,732 |  |
| Total current assets |  | 1,173,100 |  |  | 1,027,845 |  |
| Non-current assets: |  |  |  |  |  |
| Property, plant and equipment, net |  | 86,304 |  |  | 85,408 |  |
| Goodwill |  | 275,451 |  |  | 249,741 |  |
| Other intangible assets, net |  | 87,547 |  |  | 47,564 |  |
| Other assets |  | 120,755 |  |  | 88,119 |  |
| Total assets |  | $ | 1,743,157 |  |  | $ | 1,498,677 |  |
| Current liabilities: |  |  |  |  |  |  |
| Accounts payable |  | $ | 293,988 |  |  | $ | 274,805 |  |
| Accrued and other current liabilities |  | 281,732 |  |  | 232,273 |  |
| Total current liabilities |  | 575,720 |  |  | 507,078 |  |
| Non-current liabilities: |  |  |  |  |  |  |
| Income taxes payable |  | 34,956 |  |  | 51,797 |  |
| Other non-current liabilities |  | 81,924 |  |  | 83,691 |  |
| Total liabilities |  | 692,600 |  |  | 642,566 |  |
| Shareholders' equity: |  |  |  |  |
| Registered shares, CHF 0.25 par value: |  | 30,148 |  |  | 30,148 |  |
| Issued and authorized shares—173,106 at March 31, 2018 and 2017 |  |  |  |  |
| Conditionally authorized shares—50,000 at March 31, 2018 and 2017 |  |  |  |  |
| Additional paid-in capital |  | 47,234 |  |  | 26,596 |  |
| Treasury shares, at cost—8,527 and 10,727 shares at March 31, 2018 and 2017, respectively |  | (165,686 | ) |  | (174,037 | ) |
| Retained earnings |  | 1,232,316 |  |  | 1,074,110 |  |
| Accumulated other comprehensive loss |  | (93,455 | ) |  | (100,706 | ) |
| Total shareholders' equity |  | 1,050,557 |  |  | 856,111 |  |
| Total liabilities and shareholders' equity |  | $ | 1,743,157 |  |  | $ | 1,498,677 |  |

[0001032975-18-000013:8k_2_02:42]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  | Fiscal Years Ended |
|  |  | March 31, |  | March 31, |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 34,404 |  |  | $ | 39,425 |  |  | $ | 208,542 |  |  | $ | 205,876 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |
| Depreciation |  | 11,077 |  |  | 8,642 |  |  | 41,295 |  |  | 41,121 |  |
| Amortization of intangible assets |  | 4,954 |  |  | 2,749 |  |  | 15,607 |  |  | 9,367 |  |
| Share-based compensation expense |  | 10,899 |  |  | 9,536 |  |  | 44,138 |  |  | 35,890 |  |
| Gain on investments in privately held companies |  | (119 | ) |  | (22 | ) |  | (669 | ) |  | (569 | ) |
| Deferred income taxes |  | 413 |  |  | (1,924 | ) |  | 7,141 |  |  | (2,397 | ) |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | 1,833 |  |  | (4,908 | ) |  | (8,092 | ) |
| Other |  | (18 | ) |  | 107 |  |  | (11 | ) |  | 107 |  |
| Changes in assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | 137,665 |  |  | 92,861 |  |  | (26,363 | ) |  | (46,553 | ) |
| Inventories |  | 21,739 |  |  | (234 | ) |  | 16,047 |  |  | (15,428 | ) |
| Other assets |  | 2,045 |  |  | 1,037 |  |  | (16,908 | ) |  | (5,309 | ) |
| Accounts payable |  | (134,016 | ) |  | (84,636 | ) |  | 17,695 |  |  | 24,459 |  |
| Accrued and other liabilities |  | 1,134 |  |  | (21,632 | ) |  | 44,655 |  |  | 49,917 |  |
| Net cash provided by operating activities |  | 90,177 |  | — |  | 47,742 |  |  | 346,261 |  |  | 288,389 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  | (12,155 | ) |  | (8,432 | ) |  | (39,748 | ) |  | (31,804 | ) |
| Acquisitions, net of cash acquired |  | — |  |  | — |  |  | (88,323 | ) |  | (66,987 | ) |
| Investment in privately held companies |  | (360 | ) |  | (320 | ) |  | (1,240 | ) |  | (960 | ) |
| Proceeds from return of investment in privately held companies |  | — |  |  | — |  |  | 237 |  |  | — |  |
| Changes in restricted cash |  | — |  |  | — |  |  | — |  |  | 715 |  |
| Purchases of short-term investments |  | — |  |  | — |  |  | (6,789 | ) |  | — |  |
| Sales of short-term investments |  | — |  |  | — |  |  | 6,789 |  |  | — |  |
| Purchases of trading investments |  | (3,211 | ) |  | (1,184 | ) |  | (6,053 | ) |  | (7,052 | ) |
| Proceeds from sales of trading investments |  | 3,214 |  |  | 1,212 |  |  | 6,423 |  |  | 7,124 |  |
| Net cash used in investing activities |  | (12,512 | ) | — |  | (8,724 | ) |  | (128,704 | ) |  | (98,964 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |
| Payment of cash dividends |  | — |  |  | — |  |  | (104,248 | ) |  | (93,093 | ) |
| Payment of contingent consideration for business acquisition |  | — |  |  | — |  |  | (5,000 | ) |  | — |  |
| Purchases of registered shares |  | (10,314 | ) |  | (20,022 | ) |  | (30,722 | ) |  | (83,786 | ) |
| Proceeds from exercise of stock options and purchase rights |  | 10,963 |  |  | 19,219 |  |  | 41,910 |  |  | 39,574 |  |
| Tax withholdings related to net share settlements of restricted stock units |  | (4,308 | ) |  | (5,358 | ) |  | (29,813 | ) |  | (18,412 | ) |
| Net cash used in financing activities |  | (3,659 | ) |  | (6,161 | ) |  | (127,873 | ) |  | (155,717 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  | 3,053 |  |  | 1,098 |  |  | 4,730 |  |  | (5,370 | ) |
| Net increase in cash and cash equivalents |  | 77,059 |  |  | 33,955 |  |  | 94,414 |  |  | 28,338 |  |
| Cash and cash equivalents at beginning of period |  | 564,888 |  |  | 513,578 |  |  | 547,533 |  |  | 519,195 |  |
| Cash and cash equivalents at end of period |  | $ | 641,947 |  |  | $ | 547,533 |  |  | $ | 641,947 |  |  | $ | 547,533 |  |

[0001032975-18-000013:8k_2_02:43]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |  |  |
| NET SALES |  | Three Months Ended |  | Fiscal Years Ended |
|  |  | March 31, |  | March 31, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2018 |  | 2017 |  | Change |  | 2018 |  | 2017 |  | Change |
| Net sales by product category: |  |  |  |  |  |  |  |  |  |  |  |  |
| Pointing Devices |  | $ | 129,937 |  |  | $ | 119,313 |  |  | 9 | % |  | $ | 516,637 |  |  | $ | 501,562 |  |  | 3 | % |
| Keyboards & Combos |  | 136,787 |  |  | 120,488 |  |  | 14 |  |  | 498,472 |  |  | 480,312 |  |  | 4 |  |
| PC Webcams |  | 31,776 |  |  | 27,015 |  |  | 18 |  |  | 112,147 |  |  | 107,087 |  |  | 5 |  |
| Tablet & Other Accessories |  | 27,292 |  |  | 17,528 |  |  | 56 |  |  | 107,942 |  |  | 76,879 |  |  | 40 |  |
| Video Collaboration |  | 54,709 |  |  | 38,711 |  |  | 41 |  |  | 182,717 |  |  | 127,009 |  |  | 44 |  |
| Mobile Speakers |  | 13,974 |  |  | 39,975 |  |  | (65 | ) |  | 314,817 |  |  | 301,021 |  |  | 5 |  |
| Audio-PC & Wearables |  | 55,248 |  |  | 60,332 |  |  | (8 | ) |  | 252,330 |  |  | 246,390 |  |  | 2 |  |
| Gaming |  | 126,763 |  |  | 71,489 |  |  | 77 |  |  | 491,995 |  |  | 314,362 |  |  | 57 |  |
| Smart Home |  | 15,892 |  |  | 15,594 |  |  | 2 |  |  | 89,373 |  |  | 65,510 |  |  | 36 |  |
| Other (1) |  | 48 |  |  | 107 |  |  | (55 | ) |  | 433 |  |  | 1,295 |  |  | (67 | ) |
| Total net retail sales |  | $ | 592,426 |  |  | $ | 510,552 |  |  | 16 |  |  | $ | 2,566,863 |  |  | $ | 2,221,427 |  |  | 16 |  |
| __________________ |  |  |  |  |  |  |  |  |  |  |  |  |

[0001032975-18-000013:8k_2_02:44]
(1) Other category includes products that we currently intend to transition out of, or have already transitioned out of, because they are no longer strategic to our business.

[0001032975-18-000013:8k_2_02:45]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS |
| (In thousands, except per share amounts) - Unaudited |  |  |  |  |  |  |  |  |
| GAAP TO NON GAAP RECONCILIATION (A) |  | Three Months Ended |  | Fiscal Years Ended |
|  |  | March 31, |  | March 31, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Gross profit - GAAP |  | $ | 212,235 |  |  | $ | 197,779 |  |  | $ | 909,241 |  |  | $ | 820,041 |  |
| Share-based compensation expense |  | 971 |  |  | 733 |  |  | 3,733 |  |  | 2,663 |  |
| Amortization of intangible assets and purchase accounting effect on inventory |  | 2,574 |  |  | 1,470 |  |  | 8,878 |  |  | 6,175 |  |
| Gross profit - Non-GAAP |  | $ | 215,780 |  |  | $ | 199,982 |  |  | $ | 921,852 |  |  | $ | 828,879 |  |
| Gross margin - GAAP |  | 35.8 | % |  | 38.7 | % |  | 35.4 | % |  | 36.9 | % |
| Gross margin - Non-GAAP |  | 36.4 | % |  | 39.2 | % |  | 35.9 | % |  | 37.3 | % |
| Operating expenses - GAAP |  | $ | 173,128 |  |  | $ | 161,461 |  |  | $ | 679,508 |  |  | $ | 608,181 |  |
| Less: Share-based compensation expense |  | 9,928 |  |  | 8,803 |  |  | 40,405 |  |  | 33,227 |  |
| Less: Amortization of intangible assets and acquisition-related costs |  | 2,553 |  |  | 1,279 |  |  | 8,930 |  |  | 5,814 |  |
| Less: Change in fair value of contingent consideration for business acquisition |  | — |  |  | 1,833 |  |  | (4,908 | ) |  | (8,092 | ) |
| Less: Restructuring charges (credit), net |  | — |  |  | 67 |  |  | (116 | ) |  | 23 |  |
| Less: Investigation and related expenses |  | — |  |  | — |  |  | — |  |  | 612 |  |
| Operating expenses - Non-GAAP |  | $ | 160,647 |  |  | $ | 149,479 |  |  | $ | 635,197 |  |  | $ | 576,597 |  |
| % of net sales - GAAP |  | 29.2 | % |  | 31.6 | % |  | 26.5 | % |  | 27.4 | % |
| % of net sales - Non - GAAP |  | 27.1 | % |  | 29.3 | % |  | 24.7 | % |  | 26.0 | % |
| Operating income - GAAP |  | $ | 39,107 |  |  | $ | 36,318 |  |  | $ | 229,733 |  |  | $ | 211,860 |  |
| Share-based compensation expense |  | 10,899 |  |  | 9,536 |  |  | 44,138 |  |  | 35,890 |  |
| Amortization of intangible assets |  | 4,954 |  |  | 2,749 |  |  | 15,607 |  |  | 9,367 |  |
| Purchase accounting effect on inventory |  | 173 |  |  | — |  |  | 789 |  |  | 1,160 |  |
| Acquisition-related costs |  | — |  |  | — |  |  | 1,412 |  |  | 1,462 |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | 1,833 |  |  | (4,908 | ) |  | (8,092 | ) |
| Restructuring charges (credit), net |  | — |  |  | 67 |  |  | (116 | ) |  | 23 |  |
| Investigation and related expenses |  | — |  |  | — |  |  | — |  |  | 612 |  |
| Operating income - Non - GAAP |  | $ | 55,133 |  |  | $ | 50,503 |  |  | $ | 286,655 |  |  | $ | 252,282 |  |
| % of net sales - GAAP |  | 6.6 | % |  | 7.1 | % |  | 8.9 | % |  | 9.5 | % |
| % of net sales - Non - GAAP |  | 9.3 | % |  | 9.9 | % |  | 11.2 | % |  | 11.4 | % |
| Net income - GAAP |  | $ | 34,404 |  |  | $ | 39,425 |  |  | $ | 208,542 |  |  | $ | 205,876 |  |
| Share-based compensation expense |  | 10,899 |  |  | 9,536 |  |  | 44,138 |  |  | 35,890 |  |
| Amortization of intangible assets |  | 4,954 |  |  | 2,749 |  |  | 15,607 |  |  | 9,367 |  |
| Purchase accounting effect on inventory |  | 173 |  |  | — |  |  | 789 |  |  | 1,160 |  |
| Acquisition-related costs |  | — |  |  | — |  |  | 1,412 |  |  | 1,462 |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | 1,833 |  |  | (4,908 | ) |  | (8,092 | ) |
| Restructuring charges (credit), net |  | — |  |  | 67 |  |  | (116 | ) |  | 23 |  |
| Investigation and related expenses |  | — |  |  | — |  |  | — |  |  | 612 |  |
| Gain on investments in privately held companies |  | (119 | ) |  | (22 | ) |  | (669 | ) |  | (569 | ) |
| Non-GAAP income tax adjustment |  | 4,249 |  |  | (4,226 | ) |  | 6,282 |  |  | (12,875 | ) |
| Net income - Non - GAAP |  | $ | 54,560 |  |  | $ | 49,362 |  |  | $ | 271,077 |  |  | $ | 232,854 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  | $ | 0.20 |  |  | $ | 0.24 |  |  | $ | 1.23 |  |  | $ | 1.24 |  |
| Diluted - Non - GAAP |  | $ | 0.32 |  |  | $ | 0.30 |  |  | $ | 1.60 |  |  | $ | 1.41 |  |
| Shares used to compute net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP and Non - GAAP |  | 169,387 |  |  | 166,526 |  |  | 168,971 |  |  | 165,540 |  |

[0001032975-18-000013:8k_2_02:46]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
| SHARE-BASED COMPENSATION EXPENSE |  | Three Months Ended |  | Fiscal Years Ended |
|  |  | March 31, |  | March 31, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Share-based Compensation Expense |  |  |  |  |  |  |  |  |
| Cost of goods sold |  | $ | 971 |  |  | $ | 733 |  |  | $ | 3,733 |  |  | $ | 2,663 |  |
| Marketing and selling |  | 4,417 |  |  | 4,036 |  |  | 17,765 |  |  | 14,723 |  |
| Research and development |  | 1,584 |  |  | 1,193 |  |  | 6,381 |  |  | 4,200 |  |
| General and administrative |  | 3,927 |  |  | 3,574 |  |  | 16,259 |  |  | 14,304 |  |
| Total share-based compensation expense |  | 10,899 |  |  | 9,536 |  |  | 44,138 |  |  | 35,890 |  |
| Income tax benefit |  | (4,077 | ) |  | (2,444 | ) |  | (15,998 | ) |  | (8,536 | ) |
| Total share-based compensation expense, net of income tax |  | $ | 6,822 |  |  | $ | 7,092 |  |  | $ | 28,140 |  |  | $ | 27,354 |  |

[0001032975-18-000013:8k_2_02:47]
Note: These preliminary results for the three months and fiscal year ended March 31, 2018 are subject to adjustments, including subsequent events that may occur through the date of filing our Annual Report on Form 10-K.

[0001032975-18-000013:8k_2_02:48]
(A) Non-GAAP Financial Measures

[0001032975-18-000013:8k_2_02:49]
To supplement our condensed consolidated financial results prepared in accordance with GAAP, we use a number of financial measures, both GAAP and non-GAAP, in analyzing and assessing our overall business performance, for making operating decisions and for forecasting and planning future periods. We consider the use of non-GAAP financial measures helpful in assessing our current financial performance, ongoing operations and prospects for the future as well as understanding financial and business trends relating to our financial condition and results of operations.

[0001032975-18-000013:8k_2_02:50]
While we use non-GAAP financial measures as a tool to enhance our understanding of certain aspects of our financial performance and to provide incremental insight into the underlying factors and trends affecting both our performance and our cash-generating potential, we do not consider these measures to be a substitute for, or superior to, the information provided by GAAP financial measures. Consistent with this approach, we believe that disclosing non-GAAP financial measures to the readers of our financial statements provides useful supplemental data that, while not a substitute for GAAP financial measures, can offer insight in the review of our financial and operational performance and enables investors to more fully understand trends in our current and future performance. In assessing our business during the quarter and year ended March 31, 2018, we excluded items in the following general categories, each of which are described below:

[0001032975-18-000013:8k_2_02:51]
Share-based compensation expenses. We believe that providing non-GAAP measures excluding share-based compensation expense, in addition to the GAAP measures, allows for a more transparent comparison of our financial results from period to period. We prepare and maintain our budgets and forecasts for future periods on a basis consistent with this non-GAAP financial measure. Further, companies use a variety of types of equity awards as well as a variety of methodologies, assumptions and estimates to determine share-based compensation expense. We believe that excluding share-based compensation expense enhances our ability and the ability of investors to understand the impact of non-cash share-based compensation on our operating results and to compare our results against the results of other companies.

[0001032975-18-000013:8k_2_02:52]
Amortization of intangible assets. We incur intangible asset amortization expense, primarily in connection with our acquisitions of various businesses and technologies. The amortization of purchased intangibles varies depending on the level of acquisition activity. We exclude these various charges in budgeting, planning and forecasting future periods and we believe that providing the non-GAAP measures excluding these various non-cash charges, as well as the GAAP measures, provides additional insight when comparing our gross profit, operating expenses and financial results from period to period.

[0001032975-18-000013:8k_2_02:53]
Purchase accounting effect on inventory. Business combination accounting principles require us to measure acquired inventory at fair value. The fair value of inventory reflects the acquired company’s cost of manufacturing plus a portion of the expected profit margin. The non-GAAP adjustment excludes the expected profit margin component that is recorded under business combination accounting principles associated with our business acquisitions. We believe the adjustment is useful to investors because such charges are not reflective of our ongoing operations.

[0001032975-18-000013:8k_2_02:54]
Acquisition-related costs and change in fair value of contingent consideration for business acquisition.  We incurred expenses and credits in connection with our acquisitions which we generally would not have otherwise incurred in the periods presented as a part of our continuing operations. Acquisition related costs include all incremental expenses incurred to effect a business combination. Fair value of contingent consideration is associated with our estimates of the value of earn-outs in connection with certain acquisitions. We believe that providing the non-GAAP measures excluding these costs and credits, as well as the GAAP measures, assists our investors because such costs are not reflective of our ongoing operating results.

[0001032975-18-000013:8k_2_02:55]
Restructuring charges (credits). These expenses are associated with re-aligning our business strategies based on current economic conditions. We have undertaken several restructuring plans in recent years. In connection with our restructuring initiatives, we incurred restructuring charges related to employee terminations, facility closures and early cancellation of certain contracts. We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges (credits) are not reflective of our ongoing operating results in the current period.

[0001032975-18-000013:8k_2_02:56]
Gain (loss) on investments in privately held companies. We recognized gain (loss) related our investments in various privately-held companies, which varies depending on the operational and financial performance of the privately-held companies in which we invested. We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges are not reflective of our ongoing operations.

[0001032975-18-000013:8k_2_02:57]
Investigation and related expenses.  These expenses are forensic accounting, audit, consulting and legal fees related to the Audit Committee’s investigation and the formal investigation by and settlement with the Securities and Exchange Commission (SEC), together with accruals based on settlement with the SEC. We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges are not reflective of our ongoing operations.

[0001032975-18-000013:8k_2_02:58]
Non-GAAP income tax adjustment.  Non-GAAP income tax adjustment primarily measures the income tax effect of non-GAAP adjustments excluded above and other events; the determination of which is based upon the nature of the underlying items, the mix of income and losses in jurisdictions and the relevant tax rates in which we operate. For example, we recognized more GAAP income tax expense in the third and fourth quarter of fiscal year 2018 as a result of the U.S. tax reform that we have excluded as a one-time charge on a non-GAAP basis.

[0001032975-18-000013:8k_2_02:59]
Each of the non-GAAP financial measures described above, and used in this press release, should not be considered in isolation from, or as a substitute for, a measure of financial performance prepared in accordance with GAAP. Further, investors are cautioned that there are inherent limitations associated with the use of each of these non-GAAP financial measures as an analytical tool. In particular, these non-GAAP financial measures are not based on a comprehensive set of accounting rules or principles and many of the adjustments to the GAAP financial measures reflect the exclusion of items that are recurring and may be reflected in the Company’s financial results for the foreseeable future. We compensate for these limitations by providing specific information in the reconciliation included in this press release regarding the GAAP amounts excluded from the non-GAAP financial measures. In addition, as noted above, we evaluate the non-GAAP financial measures together with the most directly comparable GAAP financial information.

[0001032975-18-000013:8k_2_02:60]
Additional Supplemental Financial Information - Constant Currency

[0001032975-18-000013:8k_2_02:61]
In addition, Logitech presents percentage sales growth in constant currency to show performance unaffected by fluctuations in currency exchange rates.  Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales.

## item 5.02 — body, verbatim

[0001032975-18-000013:8k_body:1]
ITEM 5.02. DEPARTURE OF DIRECTORS OR CERTAIN OFFICERS; ELECTION OF DIRECTORS; APPOINTMENT OF CERTAIN OFFICERS; COMPENSATORY ARRANGEMENTS OF CERTAIN OFFICERS

[0001032975-18-000013:8k_body:2]
On May 2, 2018, L. Joseph Sullivan, the Company’s Senior Vice President, Worldwide Operations, announced his retirement and, effective immediately, resigned from the Company’s Group Management Team.  The Company accepted this resignation. Mr. Sullivan’s retirement will be effective as of February 2, 2019, the end of his contractual notice period.
