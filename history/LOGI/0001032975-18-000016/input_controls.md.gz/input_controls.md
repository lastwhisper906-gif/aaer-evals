# LOGI 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: 3 candidate headings, none whose body matches 'critical audit matter'.


## item_9a

[0001032975-18-000016:item_9a:1]
ITEM 9A.    CONTROLS AND PROCEDURES

[0001032975-18-000016:item_9a:2]
(a) Evaluation of Disclosure Controls and Procedures

[0001032975-18-000016:item_9a:3]
The Company conducted an evaluation of the effectiveness of the design and operation of its disclosure controls and procedures (as defined in Rules 13a-15(e) and 15d-15(e) under the Securities Exchange Act of 1934, as amended (the Exchange Act)) as of the end of the period covered by this Annual Report on Form 10-K (this Annual Report) required by Exchange Act Rules 13a-15(b) or 15d-15(b). Such evaluation was conducted under the supervision and with the participation of the Company’s management, including the Company’s Chief Executive Officer (CEO) and Chief Financial Officer (CFO). Disclosure controls and procedures are designed to reasonably assure that information required to be disclosed in our reports filed or submitted under the Exchange Act, such as this Annual Report on Form 10-K, is recorded, processed, summarized and reported within the time periods specified in the Securities and Exchange Commission's rules and forms. Disclosure controls and procedures are also designed to reasonably assure that this information is accumulated and communicated to our management, including the CEO and CFO, to allow timely decisions regarding required disclosure. Based on this evaluation, the CEO and CFO concluded that, as of the end of the period covered by this Annual Report, the Company’s disclosure controls and procedures were effective at a reasonable assurance level.

[0001032975-18-000016:item_9a:4]
Attached as exhibits to this Annual Report are certifications of the CEO and CFO, which are required in accordance with Rule 13a-14 of the Exchange Act. This Controls and Procedures section includes the information concerning the controls evaluation referred to in the certifications, and it should be read in conjunction with the certifications for a more complete understanding of the topics presented.

[0001032975-18-000016:item_9a:5]
(b) Management's Report on Internal Control over Financial Reporting

[0001032975-18-000016:item_9a:6]
The Company's management is responsible for establishing and maintaining adequate internal control over financial reporting as defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act. Under the supervision and with the participation of the Company’s management, including the CEO and CFO, the Company conducted an evaluation of the effectiveness of its internal control over financial reporting based on the criteria established in the Internal Control-Integrated Framework (2013), issued by the Committee of Sponsoring Organizations of the Treadway Commission. Based on this evaluation, management has concluded that our internal control over financial reporting was effective as of March 31, 2018.

[0001032975-18-000016:item_9a:7]
The effectiveness of the Company's internal control over financial reporting as of March 31, 2018 has been audited by KPMG LLP, an independent registered public accounting firm, as stated in its report, which appears in Item 15.

[0001032975-18-000016:item_9a:8]
Logitech International S.A. | Fiscal 2018 Form 10-K | 61

[0001032975-18-000016:item_9a:9]
(c) Changes in Internal Control over Financial Reporting

[0001032975-18-000016:item_9a:10]
Beginning in May 2017, we began implementing the internal control procedures which addressed a previously identified material weakness relating to the accuracy of allowances and accrued liabilities for customer incentive, cooperative marketing and pricing programs in the EMEA region.

[0001032975-18-000016:item_9a:11]
During the fourth quarter of fiscal year 2018, we successfully completed the testing necessary to conclude that the material weakness has been remediated.

[0001032975-18-000016:item_9a:12]
Except as noted above, there have been no changes in the Company's internal control over financial reporting that have materially affected, or that are reasonably likely to materially affect, the Company’s internal control over financial reporting.

[0001032975-18-000016:item_9a:13]
(d) Limitations on the Effectiveness of Controls

[0001032975-18-000016:item_9a:14]
The Company's management, including the CEO and CFO, does not expect that the Company's disclosure controls and procedures or internal control over financial reporting will prevent all errors and all fraud. Internal control over financial reporting, no matter how well designed and operated, can provide only reasonable, not absolute, assurance that the objectives will be met. Because of the inherent limitations in internal control over financial reporting, no evaluation of controls can provide absolute assurance that all control issues and instances of fraud, if any, within the Company have been detected. These inherent limitations include the realities that judgments in decision making can be faulty and that breakdowns can occur because of simple error or mistake. Controls can also be circumvented by the individual acts of some persons, by collusion of two or more people, or by management override of the controls. The design of any system of controls is based in part on certain assumptions about the likelihood of future events, and there can be no assurance that any design will succeed in achieving its stated goals under all potential future conditions. Over time, controls may become inadequate because of changes in conditions or deterioration in the degree of compliance with policies or procedures. Because of the inherent limitations in a cost-effective control system, misstatements due to error or fraud may occur and not be detected.
