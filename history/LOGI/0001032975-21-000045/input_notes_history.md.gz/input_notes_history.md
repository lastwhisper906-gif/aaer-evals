# LOGI note change history — 0001032975-21-000034 → 0001032975-21-000045


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-10-28):
[0001032975-21-000045:note_history:1]
Changes in the Company’s warranty liability for the three and six months ended September 30, 2021 and 2020 were as follows (in thousands):
  (was, 2021-07-29, similarity 0.9231):
[0001032975-21-000034:note_history:1]
Changes in the Company’s warranty liability for the three months ended June 30, 2021 and 2020 were as follows (in thousands):

- added (2021-10-28):
[0001032975-21-000045:note_history:2]
|  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Beginning of the period | $ | 49,093 |  |  | $ | 39,450 |  |  | $ | 48,832 |  |  | $ | 40,039 |  |
| Provision | 8,095 |  |  | 9,494 |  |  | 16,541 |  |  | 14,883 |  |
| Settlements | (7,848) |  |  | (7,541) |  |  | (16,163) |  |  | (13,702) |  |
| Effects of foreign currency translation | (167) |  |  | 379 |  |  | (37) |  |  | 562 |  |
| End of the period | $ | 49,173 |  |  | $ | 41,782 |  |  | $ | 49,173 |  |  | $ | 41,782 |  |

- changed (2021-10-28):
[0001032975-21-000045:note_history:3]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of September 30, 2021, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.
  (was, 2021-07-29, similarity 0.9899):
[0001032975-21-000034:note_history:3]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of June 30, 2021, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

- removed (2021-10-28):
[0001032975-21-000034:note_history:4]
|  | Three Months EndedJune 30, |  |  |  |
|  | 2021 |  | 2020 |  |  |  |  |  |  |  |
| Beginning of the period | $ | 48,832 |  |  | $ | 40,039 |  |  |  |  |  |  |  |  |
| Provision | 8,446 |  |  | 5,389 |  |  |  |  |  |  |  |  |
| Settlements | (8,315) |  |  | (6,161) |  |  |  |  |  |  |  |  |
| Currency translation | 130 |  |  | 183 |  |  |  |  |  |  |  |  |
| End of the period | $ | 49,093 |  |  | $ | 39,450 |  |  |  |  |  |  |  |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-10-28):
[0001032975-21-000045:note_history:5]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and six months ended September 30, 2021 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2022, or any future periods.
  (was, 2021-07-29, similarity 0.7702):
[0001032975-21-000034:note_history:5]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three months ended June 30, 2021 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2022, or any future periods.

- changed (2021-10-28):
[0001032975-21-000045:note_history:6]
Other than the recent accounting pronouncements adopted and discussed below under Recent Accounting Pronouncements Adopted, there have been no material changes in the Company’s significant accounting policies during the six months ended September 30, 2021 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2021.
  (was, 2021-07-29, similarity 0.9351):
[0001032975-21-000034:note_history:6]
Other than the recent accounting pronouncements adopted and discussed below under Recent Accounting Pronouncements Adopted, there have been no material changes in the Company’s significant accounting policies during the three months ended June 30, 2021 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2021.

- changed (2021-10-28):
[0001032975-21-000045:note_history:7]
We are subject to risks and uncertainties as a result of the novel coronavirus ("COVID-19"). Capital markets and economies worldwide have been negatively impacted by COVID-19 and it is still unclear how lasting and deep the economic impacts will be. During the three and six months ended September 30, 2021, the COVID-19 pandemic had mixed effects on the Company’s results of operations. While the Company experienced increased sales for the three and six months ended September 30, 2021, compared to the same period of the prior fiscal year, we also experienced supply and demand volatility, as the COVID-19 pandemic and related safety measures and restrictions have evolved differently across the world. In addition, we experienced industry-wide supply chain challenges. The ongoing and full extent of the impact of the COVID-19 pandemic on the Company's business and operational and financial performance and condition, including the sustainability of its effect on trends positive to the Company, is uncertain and will depend on many factors outside the Company's control, including but not limited to the timing, extent, duration and effects of the virus and any of its mutations, the vaccination rates, the development of effective treatments, the imposition of effective public safety and other protective measures and the public's response to such measures, the impact of COVID-19 on the global economy and demand for the Company's products and services. Should the COVID-19 pandemic or global economic slowdown not improve or worsen, or if the Company's attempt to mitigate its impact on its operations and costs is not successful, the Company's business, results of operations, financial condition and prospects may be adversely affected.
  (was, 2021-07-29, similarity 0.9074):
[0001032975-21-000034:note_history:7]
We are subject to risks and uncertainties as a result of the novel coronavirus ("COVID-19"). Capital markets and economies worldwide have been negatively impacted by COVID-19 and it is still unclear how lasting and deep the economic impacts will be. During the first quarter of fiscal year 2022, the COVID-19 pandemic had mixed effects on the Company’s results of operations. While we experienced increased sales and operating income compared to the first quarter of fiscal year 2021, we also experienced supply and demand volatility, as the COVID-19 pandemic and related safety measures and restrictions have evolved differently across the world. The ongoing and full extent of the impact of the COVID-19 pandemic on the Company's business and operational and financial performance and condition, including the sustainability of its effect on trends positive to the Company, is uncertain and will depend on many factors outside the Company's control, including but not limited to the timing, extent, duration and effects of the virus and any of its mutations, the vaccination rates, the development of effective treatments, the imposition of effective public safety and other protective measures and the public's response to such measures, the impact of COVID-19 on the global economy and demand for the Company's products and services. Should the COVID-19 pandemic or global economic slowdown not improve or worsen, or if the Company's attempt to mitigate its impact on its operations and costs is not successful, the Company's business, results of operations, financial condition and prospects may be adversely affected.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2021-10-28):
[0001032975-21-000045:note_history:8]
The Company had several uncommitted, unsecured bank lines of credit aggregating $191.8 million as of September 30, 2021. There are no financial covenants under these lines of credit with which the Company must comply. As of September 30, 2021, the Company had outstanding bank guarantees of $11.9 million under these lines of credit. There was no borrowing outstanding under these lines of credit as of September 30, 2021 or March 31, 2021.

- removed (2021-10-28):
[0001032975-21-000034:note_history:9]
The Company had several uncommitted, unsecured bank lines of credit aggregating $191.6 million as of June 30, 2021. There are no financial covenants under these lines of credit with which the Company must comply. 
As of June 30, 2021, the Company had outstanding bank guarantees of $24.7 million under these lines of credit. There was no borrowing outstanding under these lines of credit as of June 30, 2021 or March 31, 2021.
