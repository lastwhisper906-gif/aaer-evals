# LOGI MD&A — 0001032975-21-000045


## mdna

[0001032975-21-000045:mdna:1]
[same as prior period, unchanged from 0001032975-21-000034:mdna:1]

[0001032975-21-000045:mdna:2]
[same as prior period, unchanged from 0001032975-21-000034:mdna:2]

[0001032975-21-000045:mdna:3]
[same as prior period, unchanged from 0001032975-21-000034:mdna:3]

[0001032975-21-000045:mdna:4]
[same as prior period, unchanged from 0001032975-21-000034:mdna:4]

[0001032975-21-000045:mdna:5]
25

[0001032975-21-000045:mdna:6]
[same as prior period, unchanged from 0001032975-21-000034:mdna:5]

[0001032975-21-000045:mdna:7]
[same as prior period, unchanged from 0001032975-21-000034:mdna:6]

[0001032975-21-000045:mdna:8]
[same as prior period, unchanged from 0001032975-21-000034:mdna:7]

[0001032975-21-000045:mdna:9]
[same as prior period, unchanged from 0001032975-21-000034:mdna:8]

[0001032975-21-000045:mdna:10]
In March 2020, the World Health Organization declared the outbreak of a novel coronavirus ("COVID-19") as a pandemic, which continues to spread throughout the world. The spread of COVID-19 has caused public health officials to recommend precautions to mitigate the spread of the virus and, in certain markets in which we operate, government authorities have from time to time issued orders that require the closure of or restrictions on non-essential businesses and people to be quarantined or to shelter-at-home. The COVID-19 pandemic has curtailed global economic activity, caused volatility and disruption in global financial and commercial markets, and is likely to continue to cause uncertainty for an indeterminate amount of time. While some of our offices have reopened or will be reopening in the near future, we are conducting our business with substantial modifications, such as employee remote work in many non-manufacturing facilities and travel limitations, among other changes. We are continuing to actively monitor the situation and may take further actions that alter our business operations as may be required by federal, state or local authorities in the countries in which we operate, or that we determine are in the best interest of our employees, customers, partners, suppliers or shareholders.

[0001032975-21-000045:mdna:11]
In fiscal year 2021, we experienced disruptions to our supply chain and logistics, inventory constraints, and increased logistics costs, as we attempted to address the effects of COVID-19.  At the same time, due to the shelter-at-home requirements or other restrictions in many countries, there was an acceleration of work-from-anywhere, study-from-anywhere, gaming, video collaboration and streaming trends and high demand and consumption of certain of our products that led to increased sales and operating income. While we continued to experience increased sales in the first six months of fiscal year 2022 compared to the first six months of fiscal year 2021, we also experienced supply and demand volatility, as the COVID-19 pandemic and related safety measures and restrictions have evolved differently across the world. If the demand volatility results in a decrease in sales in future periods, it could lead to higher promotions and marketing expenses, or excess inventories, or both, which will have an adverse impact on our results of operations.

[0001032975-21-000045:mdna:12]
In addition, the continued COVID-19 pandemic has resulted in industry-wide global supply chain challenges, including manufacturing, transportation and logistics. We purchase certain products and key components from a limited number of sources, and depend on the supply chain, including freight, to receive components, transport finished goods and deliver our products across the world. While we proactively manage our supply chain, we expect to continue to be impacted by higher logistics and component costs, prolonged delays, and challenges with component availability. We believe that our long-term supplier relationships, as well as our hybrid model that includes in-house manufacturing in Suzhou, China, will help to mitigate the effects of these supply chain challenges.

[0001032975-21-000045:mdna:13]
It is difficult to predict the progression, the duration and all of the effects of COVID-19, how business restrictions and shelter-at-home guidelines may evolve on a global basis, how consumer demand, supply chain challenges, including inventory and logistical effects and costs, may change over time, and the impact on our future sales and results of operations. The full extent of the impact of COVID-19 on our business and our operational and financial performance is currently uncertain and will depend on many factors outside our control. For additional information, see "Liquidity and Capital Resources" below and Item 1A "Risk Factors," including under the caption "The full effect of the COVID-19 pandemic is still uncertain and cannot be predicted, and could adversely affect our business, results of operations and financial condition," "If we do not successfully coordinate the worldwide manufacturing and distribution of our products, we could lose sales” and “We purchase key components and products from a limited number of sources, and our business and operating results could be adversely affected if supply were delayed or constrained or if there were shortages of required components.”

[0001032975-21-000045:mdna:14]
26

[0001032975-21-000045:mdna:15]
[same as prior period, unchanged from 0001032975-21-000034:mdna:11]

[0001032975-21-000045:mdna:16]
Our total sales for the three and six months ended September 30, 2021 increased 4% and 28%, respectively, compared to the three and six months ended September 30, 2020. Our condensed consolidated statements of operations for the three and six months ended September 30, 2021 include the results of operations for our first quarter acquisition from its date of acquisition.

[0001032975-21-000045:mdna:17]
Sales for the three months ended September 30, 2021 increased 3%, and 12% in the EMEA and Asia Pacific regions, respectively, compared to the same period of the prior fiscal year. Our sales for the Americas region were flat compared to the same period of the prior fiscal year. Sales for the six months ended September 30, 2021 increased 28%, 26%, and 28% in the Americas, EMEA and Asia Pacific, respectively, compared to the same period of the prior fiscal year.

[0001032975-21-000045:mdna:18]
Gross margin for the three months ended September 30, 2021 decreased by 380 basis points to 41.5% from 45.3% for the three months ended September 30, 2020. Gross margin for the six months ended September 30, 2021 decreased by 30 basis points to 42.4% from 42.7% for the six months ended September 30, 2020.

[0001032975-21-000045:mdna:19]
Operating expenses for the three months ended September 30, 2021 were $362.8 million, or 27.8% of sales, compared to $248.2 million, or 19.7% of sales, in the same period of the prior fiscal year. Operating expenses for the six months ended September 30, 2021 were $728.6 million, or 27.8% of sales, compared to $470.5 million, or 23.0% of sales, in the same period of the prior fiscal year.

[0001032975-21-000045:mdna:20]
Net income for the three and six months ended September 30, 2021 was $139.5 million and $326.3 million, respectively, compared to $266.9 million and $339.0 million for the three and six months ended September 30, 2020, respectively.

[0001032975-21-000045:mdna:21]
[same as prior period, unchanged from 0001032975-21-000034:mdna:17]

[0001032975-21-000045:mdna:22]
[same as prior period, unchanged from 0001032975-21-000034:mdna:18]

[0001032975-21-000045:mdna:23]
[same as prior period, unchanged from 0001032975-21-000034:mdna:19]

[0001032975-21-000045:mdna:24]
[same as prior period, unchanged from 0001032975-21-000034:mdna:20]

[0001032975-21-000045:mdna:25]
[same as prior period, unchanged from 0001032975-21-000034:mdna:21]

[0001032975-21-000045:mdna:26]
Video Collaboration: The near and long-term structural growth opportunities in the video collaboration market ("VC") have never been more prevalent than in today’s environment, as commercial and consumer adoption of video has seen substantial growth since the start of the COVID-19 pandemic. Video meetings continue to be on the rise, and companies increasingly want lower-cost, cloud-based solutions that can provide their employees with the

[0001032975-21-000045:mdna:27]
27

[0001032975-21-000045:mdna:28]
ability to work from anywhere. We are continuing our efforts to create and sell innovative products to accommodate the increasing demand from home offices and small-size meeting rooms, such as huddle rooms, to medium and large-sized meeting rooms. We will continue to invest in the development of select business-specific products (both hardware and software), targeted product marketing and sales channel development.

[0001032975-21-000045:mdna:29]
[same as prior period, unchanged from 0001032975-21-000034:mdna:23]

[0001032975-21-000045:mdna:30]
[same as prior period, unchanged from 0001032975-21-000034:mdna:24]

[0001032975-21-000045:mdna:31]
[same as prior period, unchanged from 0001032975-21-000034:mdna:25]

[0001032975-21-000045:mdna:32]
[same as prior period, unchanged from 0001032975-21-000034:mdna:26]

[0001032975-21-000045:mdna:33]
[same as prior period, unchanged from 0001032975-21-000034:mdna:27]

[0001032975-21-000045:mdna:34]
As described in our Annual Report on Form 10-K for the fiscal year ended March 31, 2021, the canton of Vaud in Switzerland enacted the Tax Reform and AHV Financing ("TRAF") on March 10, 2020 that took effect as of January 1, 2020. Our cash tax payments have increased in Switzerland beginning in fiscal year 2020 as a result of our transition out of our longstanding tax ruling from the canton of Vaud.

[0001032975-21-000045:mdna:35]
[same as prior period, unchanged from 0001032975-21-000034:mdna:29]

[0001032975-21-000045:mdna:36]
The preparation of financial statements and related disclosures in conformity with U.S. GAAP requires us to make assumptions, judgments, and estimates, that affect reported amounts of assets, liabilities, sales and expenses, and the disclosure of contingent assets and liabilities. We base our assumptions, judgments and estimates on historical experience and various other factors that we believe to be reasonable under the circumstances. Actual results could differ materially from these estimates under different assumptions or conditions. On a regular basis, we evaluate our assumptions, judgments and estimates. We also discuss our critical accounting policies and estimates with the Audit Committee of the Board of Directors.

[0001032975-21-000045:mdna:37]
[same as prior period, unchanged from 0001032975-21-000034:mdna:31]

[0001032975-21-000045:mdna:38]
28

[0001032975-21-000045:mdna:39]
There have been no material changes in our critical accounting policies and estimates during the six months ended September 30, 2021 compared with the critical accounting policies and estimates disclosed in Management's Discussion and Analysis of Financial Condition and Results of Operations included in our Annual Report on Form 10-K for the fiscal year ended March 31, 2021.

[0001032975-21-000045:mdna:40]
[same as prior period, unchanged from 0001032975-21-000034:mdna:33]

[0001032975-21-000045:mdna:41]
[same as prior period, unchanged from 0001032975-21-000034:mdna:34]

[0001032975-21-000045:mdna:42]
[same as prior period, unchanged from 0001032975-21-000034:mdna:35]

[0001032975-21-000045:mdna:43]
[same as prior period, unchanged from 0001032975-21-000034:mdna:36]

[0001032975-21-000045:mdna:44]
[same as prior period, unchanged from 0001032975-21-000034:mdna:37]

[0001032975-21-000045:mdna:45]
[same as prior period, unchanged from 0001032975-21-000034:mdna:38]

[0001032975-21-000045:mdna:46]
[same as prior period, unchanged from 0001032975-21-000034:mdna:39]

[0001032975-21-000045:mdna:47]
[same as prior period, unchanged from 0001032975-21-000034:mdna:40]

[0001032975-21-000045:mdna:48]
Although our financial results are reported in U.S. Dollars, a portion of our sales was generated in currencies other than the U.S. Dollar, such as the Euro, Chinese Renminbi, Japanese Yen, Canadian Dollar, Taiwan New Dollar, British Pound and Australian Dollar. During the three months ended September 30, 2021, approximately 50% of our sales were denominated in currencies other than the U.S. Dollar.

[0001032975-21-000045:mdna:49]
[same as prior period, unchanged from 0001032975-21-000034:mdna:42]

[0001032975-21-000045:mdna:50]
[same as prior period, unchanged from 0001032975-21-000034:mdna:43]

[0001032975-21-000045:mdna:51]
Our sales in the three and six months ended September 30, 2021 increased 4% and 28%, respectively, compared to the same periods of the prior fiscal year, driven primarily by stronger sales in the Asia Pacific region. For the three months ended period, strong growth in Keyboards & Combos, Gaming and Pointing Devices was partially offset by a decline in sales for Audio & Wearables, PC Webcams, Mobile Speakers, Smart Home, and Tablet and Other Accessories. For the six months ended September 30, 2021, strong sales growth in Gaming, Keyboards & Combos, Video Collaboration, Pointing Devices, PC Webcams, Tablet and Other Accessories, and Audio & Wearables was partially offset by a decline in sales of Mobile Speakers and Smart Home. If currency exchange rates had been constant in the three and six months ended September 30, 2021 and 2020, our constant dollar sales growth rate would have been 2% and 24%, respectively.

[0001032975-21-000045:mdna:52]
[same as prior period, unchanged from 0001032975-21-000034:mdna:45]

[0001032975-21-000045:mdna:53]
The following table presents the change in sales by region for the three and six months ended September 30, 2021, compared with the three and six months ended September 30, 2020:

[0001032975-21-000045:mdna:54]
|  |  | Sales Growth Rate |  | Constant DollarSales Growth Rate |
|  |  | Three Months EndedSeptember 30, 2021 |  | Six Months EndedSeptember 30, 2021 |  | Three Months EndedSeptember 30, 2021 |  | Six Months EndedSeptember 30, 2021 |
| Americas |  | — | % |  | 28 | % |  | (1) | % |  | 27 | % |
| EMEA |  | 3 | % |  | 26 | % |  | — | % |  | 21 | % |
| Asia Pacific |  | 12 | % |  | 28 | % |  | 9 | % |  | 24 | % |

[0001032975-21-000045:mdna:55]
Americas:

[0001032975-21-000045:mdna:56]
The sales in the Americas region were flat for the three-months ended period presented above. The increase in sales for the six-months ended period was primarily driven by growth in sales across a majority of our product categories, partially offset by a decline in sales of Mobile Speakers and Smart Home.

[0001032975-21-000045:mdna:57]
EMEA:

[0001032975-21-000045:mdna:58]
The increase in sales in our EMEA region for the three-months ended period was primarily driven by growth in sales of Keyboards & Combos, Tablets and Other Accessories, Gaming, and Pointing Devices, partially offset by a decline in sales of the other product categories. The increase in sales for the six-months ended period was primarily driven by growth in sales across a majority of our product categories, partially offset by a decline in Smart Home and Video Collaboration.

[0001032975-21-000045:mdna:59]
Asia Pacific:

[0001032975-21-000045:mdna:60]
The increase in sales in our Asia Pacific region for both the three and six-month periods was driven by growth in sales of Gaming, Pointing Devices, Keyboards & Combos, Video Collaboration, and Mobile Speakers, partially offset by a decline in sales of Tablet and Other Accessories, PC Webcams, and Smart Home.  In addition, sales of Audio & Wearables contributed to growth in the six-month period, but declined in the three-month period.

[0001032975-21-000045:mdna:61]
[same as prior period, unchanged from 0001032975-21-000034:mdna:49]

[0001032975-21-000045:mdna:62]
Sales by product categories for the three and six months ended September 30, 2021 and 2020 were as follows (Dollars in thousands):

[0001032975-21-000045:mdna:63]
|  |  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
|  |  | 2021 |  | 2020 |  | Change |  | 2021 |  | 2020 |  | Change |
| Pointing Devices |  | $ | 189,014 |  |  | $ | 169,121 |  |  | 12 | % |  | $ | 371,892 |  |  | $ | 289,590 |  |  | 28 | % |
| Keyboards & Combos |  | 236,272 |  |  | 201,617 |  |  | 17 |  |  | 454,629 |  |  | 346,977 |  |  | 31 |  |
| PC Webcams |  | 94,471 |  |  | 102,469 |  |  | (8) |  |  | 204,389 |  |  | 163,320 |  |  | 25 |  |
| Tablet & Other Accessories |  | 80,801 |  |  | 83,086 |  |  | (3) |  |  | 160,073 |  |  | 129,134 |  |  | 24 |  |
| Gaming (1) |  | 330,777 |  |  | 297,711 |  |  | 11 |  |  | 666,174 |  |  | 479,614 |  |  | 39 |  |
| Video Collaboration |  | 231,653 |  |  | 236,704 |  |  | (2) |  |  | 466,538 |  |  | 366,778 |  |  | 27 |  |
| Mobile Speakers |  | 39,492 |  |  | 43,581 |  |  | (9) |  |  | 67,976 |  |  | 72,590 |  |  | (6) |  |
| Audio & Wearables |  | 98,078 |  |  | 114,275 |  |  | (14) |  |  | 214,685 |  |  | 185,640 |  |  | 16 |  |
| Smart Home |  | 5,649 |  |  | 8,573 |  |  | (34) |  |  | 11,821 |  |  | 15,383 |  |  | (23) |  |
| Other (2) |  | 60 |  |  | 21 |  |  | 186 |  |  | 148 |  |  | 26 |  |  | 469 |  |
| Total Sales |  | $ | 1,306,267 |  |  | $ | 1,257,158 |  |  | 4 | % |  | $ | 2,618,325 |  |  | $ | 2,049,052 |  |  | 28 | % |

[0001032975-21-000045:mdna:64]
[same as prior period, unchanged from 0001032975-21-000034:mdna:52]

[0001032975-21-000045:mdna:65]
[same as prior period, unchanged from 0001032975-21-000034:mdna:53]

[0001032975-21-000045:mdna:66]
[same as prior period, unchanged from 0001032975-21-000034:mdna:54]

[0001032975-21-000045:mdna:67]
[same as prior period, unchanged from 0001032975-21-000034:mdna:55]

[0001032975-21-000045:mdna:68]
[same as prior period, unchanged from 0001032975-21-000034:mdna:56]

[0001032975-21-000045:mdna:69]
Sales of Pointing Devices increased 12% and 28% in the three and six months ended September 30, 2021, respectively, compared to the same periods of the prior fiscal year. The increases in both periods were primarily driven by the increase in sales for cordless and corded mice and presentation tools. Trackball mice also contributed to the increase in sales for the six-month period.

[0001032975-21-000045:mdna:70]
[same as prior period, unchanged from 0001032975-21-000034:mdna:58]

[0001032975-21-000045:mdna:71]
[same as prior period, unchanged from 0001032975-21-000034:mdna:59]

[0001032975-21-000045:mdna:72]
Sales of Keyboards & Combos increased 17% and 31% in the three and six months ended September 30, 2021, respectively, compared to the same periods of the prior fiscal year. The increases for both periods were primarily driven by an increase in sales of our keyboard/mice combos as well as our cordless and corded PC keyboards.

[0001032975-21-000045:mdna:73]
[same as prior period, unchanged from 0001032975-21-000034:mdna:61]

[0001032975-21-000045:mdna:74]
[same as prior period, unchanged from 0001032975-21-000034:mdna:62]

[0001032975-21-000045:mdna:75]
Sales of PC Webcams decreased 8% for the three months ended and increased 25% for the six months ended September 30, 2021, compared to the same periods of the prior fiscal year. The decrease in sales for the three-month period was primarily driven by a decline in sales of our Streamcam and HD Webcam C615, partially offset by an increase in sales of our HD Webcam C505 and Mevo Start wireless camera.

[0001032975-21-000045:mdna:76]
31

[0001032975-21-000045:mdna:77]
The increase for the six-month period was driven by sales of our HD Pro Webcam C920, 1080P PRO Stream Webcam, Mevo Start wireless camera, and BRIO 4K Stream Edition, partially offset by a decrease in sales of our HD Webcam C615.

[0001032975-21-000045:mdna:78]
[same as prior period, unchanged from 0001032975-21-000034:mdna:64]

[0001032975-21-000045:mdna:79]
[same as prior period, unchanged from 0001032975-21-000034:mdna:65]

[0001032975-21-000045:mdna:80]
Sales of Tablet & Other Accessories products decreased 3% for three months ended and increased 24% for the six months ended September 30, 2021, compared to the same periods of the prior fiscal year. The decrease for the three-month period was primarily due to a decrease in sales of our Rugged Folio and Slim Folio products, partially offset by an increase in sales of our Combo Touch for iPad Pro 12.9-inch, introduced in the second quarter of fiscal year 2022, Combo Touch for iPad Pro 11-inch and Combo Touch for iPad Air, introduced in the first quarter of fiscal year 2022, Folio Touch for iPad Air (4th generation) and POWERED (a wireless 3-in-1 charging dock for Apple products). The increase in sales for the six-month period was primarily driven by the same product sub-categories, partially offset by a decrease in sales of our Rugged Folio.

[0001032975-21-000045:mdna:81]
[same as prior period, unchanged from 0001032975-21-000034:mdna:67]

[0001032975-21-000045:mdna:82]
[same as prior period, unchanged from 0001032975-21-000034:mdna:68]

[0001032975-21-000045:mdna:83]
[same as prior period, unchanged from 0001032975-21-000034:mdna:69]

[0001032975-21-000045:mdna:84]
Sales of Gaming increased 11% and 39% for the three and six months ended September 30, 2021, respectively, compared to the same periods of the prior fiscal year. The increase for both periods was primarily driven by strong performance in nearly all of our Gaming sub-categories, including our gaming mice, PC gaming headsets, gaming steering wheels, gaming keyboards, and Streamlabs services, partially offset by a decline in the sales of our console gaming controllers and gaming speakers. The increase in sales for the three-month period was further offset by a decline in sales of our console gaming headsets.

[0001032975-21-000045:mdna:85]
[same as prior period, unchanged from 0001032975-21-000034:mdna:71]

[0001032975-21-000045:mdna:86]
[same as prior period, unchanged from 0001032975-21-000034:mdna:72]

[0001032975-21-000045:mdna:87]
[same as prior period, unchanged from 0001032975-21-000034:mdna:73]

[0001032975-21-000045:mdna:88]
Sales of Video Collaboration products decreased 2% for three months ended and increased 27% for the six months ended September 30, 2021, compared to the same periods of the prior fiscal year. The decrease for the three-month period was primarily due to a decrease in sales of our Meetup video conference camera, BRIO 4K PRO Webcam, and Webcam C930e, partially offset by an increase in sales of Rally Bar, introduced in the fourth quarter of fiscal year 2021, Rallybar Mini, introduced in the second quarter of fiscal year 2022, and C920e Webcam. The increase in sales for the six-month period was primarily driven by an increase in sales of Rally Bar, Webcam C925E, C920e Webcam, GROUP video conferencing solution for mid to large-sized meeting rooms, and Tap, offset by a decline in sales of our Meetup conference camera and Webcam C930e.

[0001032975-21-000045:mdna:89]
[same as prior period, unchanged from 0001032975-21-000034:mdna:75]

[0001032975-21-000045:mdna:90]
[same as prior period, unchanged from 0001032975-21-000034:mdna:76]

[0001032975-21-000045:mdna:91]
[same as prior period, unchanged from 0001032975-21-000034:mdna:77]

[0001032975-21-000045:mdna:92]
Sales of Mobile Speakers decreased 9% and 6% for the three and six months ended September 30, 2021, respectively, compared to the same periods of the prior fiscal year. The decrease for the three-month period was primarily due to a decrease in sales of our UE WONDERBOOM, partially offset by an increase in sales of our HYPERBOOM speakers. The decrease for the six-month period was driven by a decrease in MEGABOOM3, UE WONDERBOOM, and BOOM2, partially offset by BOOM 3, and HYPERBOOM.

[0001032975-21-000045:mdna:93]
[same as prior period, unchanged from 0001032975-21-000034:mdna:79]

[0001032975-21-000045:mdna:94]
[same as prior period, unchanged from 0001032975-21-000034:mdna:80]

[0001032975-21-000045:mdna:95]
Sales of Audio & Wearables decreased 14% for three months ended and increased 16% for the six months ended September 30, 2021, compared to the same periods of the prior fiscal year. The decrease for the three-month period was primarily due to a decrease in sales of our Blue Microphone products and corded/cordless headsets, offset by an increase in sales of our UE Custom headsets. The increase in sales for the six-month period was primarily driven by an increase in sales of our corded headsets, Blue Microphone products, and UE Custom headsets.

[0001032975-21-000045:mdna:96]
[same as prior period, unchanged from 0001032975-21-000034:mdna:82]

[0001032975-21-000045:mdna:97]
[same as prior period, unchanged from 0001032975-21-000034:mdna:83]

[0001032975-21-000045:mdna:98]
[same as prior period, unchanged from 0001032975-21-000034:mdna:84]

[0001032975-21-000045:mdna:99]
Sales of Smart Home decreased 34% and 23% for the three and six months ended September 30, 2021, respectively, compared to the same periods of the prior fiscal year. The decreases for both periods were primarily due to a decline in sales of most of our Harmony remotes and our home video products, partially offset by increases in sales of our Circle View Doorbell, introduced in the third quarter of fiscal year 2021.

[0001032975-21-000045:mdna:100]
[same as prior period, unchanged from 0001032975-21-000034:mdna:86]

[0001032975-21-000045:mdna:101]
Gross profit for the three and six months ended September 30, 2021 and 2020 was as follows (Dollars in thousands):

[0001032975-21-000045:mdna:102]
|  |  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
|  |  | 2021 |  | 2020 |  | Change |  | 2021 |  | 2020 |  | Change |
| Net sales |  | $ | 1,306,267 |  |  | $ | 1,257,158 |  |  | 4 | % |  | $ | 2,618,325 |  |  | $ | 2,049,052 |  |  | 28 | % |
| Gross profit |  | $ | 542,163 |  |  | $ | 569,723 |  |  | (5) |  |  | $ | 1,111,089 |  |  | $ | 875,456 |  |  | 27 |  |
| Gross margin |  | 41.5 | % |  | 45.3 | % |  |  |  | 42.4 | % |  | 42.7 | % |  |  |

[0001032975-21-000045:mdna:103]
[same as prior period, unchanged from 0001032975-21-000034:mdna:89]

[0001032975-21-000045:mdna:104]
Gross margin decreased by 380 and 30 basis points for the three and six months ended September 30, 2021, respectively, compared to the same periods of the prior fiscal year. Our gross margin for both periods declined due to increased promotional spending, higher reserves for excess inventories, and increased logistics costs, partially offset by favorable currency exchange rates and favorable product mix.

[0001032975-21-000045:mdna:105]
[same as prior period, unchanged from 0001032975-21-000034:mdna:91]

[0001032975-21-000045:mdna:106]
Operating expenses for the three and six months ended September 30, 2021 and 2020 were as follows (Dollars in thousands):

[0001032975-21-000045:mdna:107]
|  |  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |  |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |  |
| Marketing and selling |  | $ | 256,627 |  |  | $ | 158,797 |  |  | $ | 508,941 |  |  | $ | 292,035 |  |  |
| % of sales |  | 19.6 | % |  | 12.6 | % |  | 19.4 | % |  | 14.3 | % |  |
| Research and development |  | 68,661 |  |  | 53,379 |  |  | 137,907 |  |  | 103,104 |  |  |
| % of sales |  | 5.3 | % |  | 4.2 | % |  | 5.3 | % |  | 5.0 | % |  |
| General and administrative |  | 33,271 |  |  | 31,664 |  |  | 73,813 |  |  | 60,735 |  |  |
| % of sales |  | 2.5 | % |  | 2.5 | % |  | 2.8 | % |  | 3.0 | % |  |
| Amortization of intangible assets and acquisition-related costs |  | 5,107 |  |  | 4,331 |  |  | 10,324 |  |  | 8,940 |  |  |
| % of sales |  | 0.4 | % |  | 0.3 | % |  | 0.4 | % |  | 0.4 | % |  |
| Change in fair value of contingent consideration for business acquisition |  | (925) |  |  | — |  |  | (2,399) |  |  | 5,716 |  |  |
| % of sales |  | (0.1) | % |  | — | % |  | (0.1) | % |  | 0.3 | % |  |
| Restructuring charges (credits), net |  | 11 |  |  | (1) |  |  | 11 |  |  | (54) |  |  |
| % of sales |  | — | % | (1) | — | % |  | — | % | (1) | — | % |  |
| Total operating expenses |  | $ | 362,752 |  |  | $ | 248,170 |  |  | $ | 728,597 |  |  | $ | 470,476 |  |  |
| % of sales |  | 27.8 | % |  | 19.7 | % |  | 27.8 | % |  | 23.0 | % |  |

[0001032975-21-000045:mdna:108]
[same as prior period, unchanged from 0001032975-21-000034:mdna:94]

[0001032975-21-000045:mdna:109]
The increase in total operating expenses during the three and six months ended September 30, 2021, compared to the same periods of the prior fiscal year, were mainly due to increases in marketing and selling expenses, research and development expenses, and general and administrative expenses, partially offset by the change in fair value of contingent consideration for business acquisition.

[0001032975-21-000045:mdna:110]
[same as prior period, unchanged from 0001032975-21-000034:mdna:96]

[0001032975-21-000045:mdna:111]
[same as prior period, unchanged from 0001032975-21-000034:mdna:97]

[0001032975-21-000045:mdna:112]
During the three and six months ended September 30, 2021, marketing and selling expenses increased $97.8 million and $216.9 million, respectively, compared to the same periods of the prior fiscal year. The increases for both periods were primarily driven by higher advertising and marketing expenses, including third-party costs and increased headcount, to support our investment in brand awareness and consideration.

[0001032975-21-000045:mdna:113]
[same as prior period, unchanged from 0001032975-21-000034:mdna:99]

[0001032975-21-000045:mdna:114]
[same as prior period, unchanged from 0001032975-21-000034:mdna:100]

[0001032975-21-000045:mdna:115]
During the three and six months ended September 30, 2021, research and development expenses increased $15.3 million and $34.8 million, respectively, compared to the same periods of the prior fiscal year. The increases for both periods were primarily driven by higher personnel-related costs due to increased headcount and higher third-party costs to support innovations in both hardware and software.

[0001032975-21-000045:mdna:116]
[same as prior period, unchanged from 0001032975-21-000034:mdna:102]

[0001032975-21-000045:mdna:117]
[same as prior period, unchanged from 0001032975-21-000034:mdna:103]

[0001032975-21-000045:mdna:118]
During the three and six months ended September 30, 2021, general and administrative expenses increased $1.6 million and $13.1 million, respectively, compared to the same periods of the prior fiscal year. The increase for both periods were primarily driven by higher personnel-related costs due to investment in additional headcount in Information Technology ("IT") and other functions to support business growth.

[0001032975-21-000045:mdna:119]
[same as prior period, unchanged from 0001032975-21-000034:mdna:105]

[0001032975-21-000045:mdna:120]
[same as prior period, unchanged from 0001032975-21-000034:mdna:106]

[0001032975-21-000045:mdna:121]
During the three and six months ended September 30, 2021, amortization of intangible assets and acquisition-related costs increased $0.8 million and $1.4 million, respectively, compared to the same periods of the prior fiscal year. The increases for both periods were primarily driven by the intangible assets acquired through acquisitions completed in the fourth quarter of fiscal year 2021.

[0001032975-21-000045:mdna:122]
[same as prior period, unchanged from 0001032975-21-000034:mdna:108]

[0001032975-21-000045:mdna:123]
Other income, net for the three and six months ended September 30, 2021 and 2020 was as follows (Dollars in thousands):

[0001032975-21-000045:mdna:124]
|  |  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Investment income (loss) related to a deferred compensation plan |  | $ | (73) |  |  | $ | 1,779 |  |  | $ | 1,095 |  |  | $ | 3,335 |  |
| Currency exchange gain (loss), net |  | (4,979) |  |  | 1,669 |  |  | 738 |  |  | 1,726 |  |
| Gain (loss) on investments |  | (2,032) |  |  | (2,693) |  |  | (961) |  |  | (2,519) |  |
| Other |  | 381 |  |  | 394 |  |  | 860 |  |  | 636 |  |
| Total |  | $ | (6,703) |  |  | $ | 1,149 |  |  | $ | 1,732 |  |  | $ | 3,178 |  |

[0001032975-21-000045:mdna:125]
Investment income (loss) represents earnings, gains, and losses on trading investments related to a deferred compensation plan offered by one of our subsidiaries.

[0001032975-21-000045:mdna:126]
Currency exchange gain (loss), net, relates to balances denominated in currencies other than the functional currency in our subsidiaries, as well as to the sale of currencies, and to gains or losses recognized on currency exchange forward contracts. We do not speculate in currency positions, but we are alert to opportunities to maximize currency exchange gains and minimize currency exchange losses. The loss for the three months ended September 30, 2021 was primarily due to the weakening of the Brazilian Real against the U.S. Dollar.

[0001032975-21-000045:mdna:127]
Gain (loss) on investments represents the unrealized gain (loss) from the fair value change on the available-for-sale securities and equity-method investments during the periods presented.

[0001032975-21-000045:mdna:128]
[same as prior period, unchanged from 0001032975-21-000034:mdna:114]

[0001032975-21-000045:mdna:129]
The provision for income taxes and effective income tax rates for the three and six months ended September 30, 2021 and 2020 were as follows (Dollars in thousands):

[0001032975-21-000045:mdna:130]
|  |  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Provision for income taxes |  | $ | 33,453 |  |  | $ | 56,301 |  |  | $ | 58,444 |  |  | $ | 70,304 |  |
| Effective income tax rate |  | 19.3 | % |  | 17.4 | % |  | 15.2 | % |  | 17.2 | % |

[0001032975-21-000045:mdna:131]
The change in the effective income tax rate for the three and six months ended September 30, 2021, compared to the same periods ended September 30, 2020 was primarily due to the mix of income and losses in the various tax jurisdictions in which we operate.  There were discrete tax benefits of $0.6 million and $0.5 million from the recognition of excess tax benefits in the United States and reversal of uncertain tax positions from the expiration of statutes of limitations, respectively, in the three-month period ended September 30, 2021, compared with $0.8 million and $0.5 million, respectively, in the three-month period ended September 30, 2020.  There were discrete tax benefits of $14.3 million and $1.5 million from the recognition of excess tax benefits in the United States and reversal of uncertain tax positions from the expiration of statutes of limitations, respectively, in the six-month period ended September 30, 2021, compared with $5.8 million and $1.5 million, respectively, in the six-month period ended September 30, 2020.

[0001032975-21-000045:mdna:132]
As of September 30, 2021 and March 31, 2021, the total amount of unrecognized tax benefits due to uncertain tax positions was $170.2 million and $160.3 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-21-000045:mdna:133]
[same as prior period, unchanged from 0001032975-21-000034:mdna:120]

[0001032975-21-000045:mdna:134]
[same as prior period, unchanged from 0001032975-21-000034:mdna:121]

[0001032975-21-000045:mdna:135]
As of September 30, 2021, we had cash and cash equivalents of $1,137.3 million, compared to $1,750.3 million as of March 31, 2021. As of September 30, 2021, 54% of the cash and cash equivalents were held in Switzerland, 18% were held in Germany, and 16% were held in Hong Kong and China. We do not expect to incur any material adverse tax impact except for what has already been recognized, or be significantly inhibited by any country in which we do business from the repatriation of funds to Switzerland, our home domicile.

[0001032975-21-000045:mdna:136]
The decrease in cash and cash equivalents for the six months ended September 30, 2021, primarily resulted from an increase in net cash used in operating activities, despite positive net income, and an increase in net cash used in financing activities. The increase in net cash used in operating activities was mainly due to the timing of an annual income tax payment for fiscal year 2021, increased inventory to support future demand and lower inventory turnover partially due to industry wide logistic delays, a decline in accounts payable due to timing of purchases and related payments, the annual bonus payment for fiscal year 2021, and timing of sales within the quarter. The increase in net cash used in financing activities was driven by higher shares repurchased under our share repurchase program and higher dividend paid in the second quarter of fiscal year 2022 compared to the same period of the prior fiscal year.

[0001032975-21-000045:mdna:137]
As of September 30, 2021, our working capital was $1,489.2 million, compared to $1,477.5 million as of March 31, 2021. The increase was primarily driven by higher inventories, higher accounts receivable, net, higher other current assets, lower accounts payable, and lower accrued and other current liabilities, partially offset by lower cash and cash equivalents. Our working capital increased by $536.6 million compared to $952.6 million as of September 30, 2020, which was primarily driven by higher cash and cash equivalents, higher inventories and higher other current assets, partially offset by higher accrued and other current liabilities and lower accounts receivable, net.

[0001032975-21-000045:mdna:138]
We had several uncommitted, unsecured bank lines of credit aggregating $191.8 million as of September 30, 2021. There are no financial covenants under these lines of credit with which we must comply. As of September 30, 2021, we had outstanding bank guarantees of $11.9 million under these lines of credit.

[0001032975-21-000045:mdna:139]
[same as prior period, unchanged from 0001032975-21-000034:mdna:126]

[0001032975-21-000045:mdna:140]
|  |  | Six Months EndedSeptember 30, |
|  |  | 2021 |  | 2020 |
| Net cash provided by / (used in) operating activities |  | $ | (177,848) |  |  | $ | 398,519 |  |
| Net cash used in investing activities |  | (63,208) |  |  | (30,539) |  |
| Net cash used in financing activities |  | (371,905) |  |  | (168,837) |  |
| Effect of exchange rate changes on cash and cash equivalents |  | (70) |  |  | 2,512 |  |
| Net increase / (decrease) in cash and cash equivalents |  | $ | (613,031) |  |  | $ | 201,655 |  |

[0001032975-21-000045:mdna:141]
The following table presents selected financial information and statistics as of and for the three months ended September 30, 2021 and 2020 (Dollars in thousands):

[0001032975-21-000045:mdna:142]
|  |  | As of September 30, |  |
|  |  | 2021 |  | 2020 |  |
| Accounts receivable, net |  | $ | 728,074 |  |  | $ | 750,749 |  |  |
| Accounts payable |  | $ | 660,720 |  |  | $ | 662,873 |  |  |
| Inventories |  | $ | 827,710 |  |  | $ | 394,708 |  |  |

[0001032975-21-000045:mdna:143]
|  |  | Three Months EndedSeptember 30, |  |
|  |  | 2021 |  | 2020 |  |
| Days sales in accounts receivable (“DSO”) (Days) (1) |  | 50 |  |  | 54 |  |  |
| Days accounts payable outstanding (“DPO”) (Days) (2) |  | 78 |  |  | 87 |  |  |
| Inventory turnover (“ITO”) (x)(3) |  | 3.7 |  |  | 7.0 |  |  |

[0001032975-21-000045:mdna:144]
[same as prior period, unchanged from 0001032975-21-000034:mdna:131]

[0001032975-21-000045:mdna:145]
[same as prior period, unchanged from 0001032975-21-000034:mdna:132]

[0001032975-21-000045:mdna:146]
[same as prior period, unchanged from 0001032975-21-000034:mdna:133]

[0001032975-21-000045:mdna:147]
DSO for the three months ended September 30, 2021 decreased by 4 days to 50 days, compared to 54 days for the same period of the prior fiscal year, primarily due to timing of sales within the quarter and a continued focus on collections efficiency.

[0001032975-21-000045:mdna:148]
DPO for the three months ended September 30, 2021 decreased by 9 days, compared to 87 days for the same period of the prior fiscal year, primarily due to the timing of purchases and related payments.

[0001032975-21-000045:mdna:149]
ITO for the three months ended September 30, 2021 decreased by 3.3, compared to 7.0 for the same period of the prior fiscal year, primarily due to higher ending inventory resulting from the rebuilding of inventory levels to meet future demand, compared to previously constrained supply from COVID-19 impacts, and industry wide logistic delays.

[0001032975-21-000045:mdna:150]
[same as prior period, unchanged from 0001032975-21-000034:mdna:137]

[0001032975-21-000045:mdna:151]
During the six months ended September 30, 2021, net cash used in operating activities was $177.8 million. The increase in accounts receivable, net was primarily driven by timing of sales. The increase in inventories was primarily driven by an increase in inventory purchases during the first half of fiscal year 2022 in anticipation of future demand. The decrease in accounts payable was primarily driven by the timing of purchases and related payments.

[0001032975-21-000045:mdna:152]
The decrease in accrued liabilities was primarily driven by payment of the fiscal year 2021 annual bonus and an annual payment for fiscal year 2021 income taxes.

[0001032975-21-000045:mdna:153]
Net cash used in investing activities was $63.2 million, primarily due to $47.2 million of purchases of property, plant and equipment, and $15.6 million of the purchase price (net of cash acquired) for business acquisition.

[0001032975-21-000045:mdna:154]
Net cash used in financing activities was $371.9 million, primarily due to $174.4 million used for repurchases of our registered shares, $159.4 million payment of annual cash dividend, and $54.8 million for tax withholdings related to net share settlements of restricted stock units, partially offset by $16.6 million in proceeds received from exercises of stock options and purchase rights.

[0001032975-21-000045:mdna:155]
During the six months ended September 30, 2021, there was a $0.1 million loss from currency exchange rate effect on cash and cash equivalents, compared to a gain of $2.5 million during the same period of the prior fiscal year. The loss from the effect of currency rate changes was immaterial during the six months ended September 30, 2021. The gain from the effect of currency rate changes during the six months ended September 30, 2020 was primarily due to the strengthening of the Australian Dollar, Chinese Renminbi, and Japanese Yen against the U.S. Dollar by 15%, 4%, and 3%, respectively, during the period.

[0001032975-21-000045:mdna:156]
[same as prior period, unchanged from 0001032975-21-000034:mdna:142]

[0001032975-21-000045:mdna:157]
[same as prior period, unchanged from 0001032975-21-000034:mdna:143]

[0001032975-21-000045:mdna:158]
In fiscal year 2022, we paid a cash dividend of CHF 147.0 million (U.S. Dollar amount of $159.4 million) out of fiscal year 2021 retained earnings. In fiscal year 2021, we paid a cash dividend of CHF 134.0 million (U.S. Dollar amount of $146.7 million) out of fiscal year 2020 retained earnings.

[0001032975-21-000045:mdna:159]
In May 2020, our Board of Directors approved a new share repurchase program, which authorizes us to invest up to $250.0 million to purchase our own shares, following the expiration date of the 2017 share repurchase program. Although we enter into trading plans for systematic repurchases (e.g., 10b5-1 trading plans) from time to time, our share repurchase program provides us with the opportunity to make opportunistic repurchases during periods of favorable market conditions and is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Opportunistic purchases may be started or stopped at any time without prior notice depending on market conditions and other factors. In April 2021, our Board of Directors approved an increase of $750.0 million of the 2020 share repurchase program, to an aggregate amount of $1.0 billion. The Swiss Takeover Board approved this increase and it became effective on May 21, 2021. As of September 30, 2021, $661.0 million is still available for repurchase under the 2020 repurchase program.

[0001032975-21-000045:mdna:160]
[same as prior period, unchanged from 0001032975-21-000034:mdna:146]

[0001032975-21-000045:mdna:161]
[same as prior period, unchanged from 0001032975-21-000034:mdna:147]

[0001032975-21-000045:mdna:162]
We lease facilities under operating leases, certain of which require us to pay property taxes, insurance and maintenance costs. Operating leases for facilities are generally renewable at our option and usually include escalation clauses linked to inflation. During the six months ended September 30, 2021, our operating lease obligations increased $9.3 million, which primarily was related to renewals of existing office spaces.  There have been no other material changes to our contractual obligations as previously disclosed in our Annual Report on Form 10-K for the year ended March 31, 2021. The remaining terms of our non-cancelable operating leases expire in various years through 2031.

[0001032975-21-000045:mdna:163]
[same as prior period, unchanged from 0001032975-21-000034:mdna:149]

[0001032975-21-000045:mdna:164]
As of September 30, 2021, we had non-cancelable purchase commitments of $812.8 million for inventory purchases made in the normal course of business from original design manufacturers, contract manufacturers and other suppliers, the majority of which are expected to be fulfilled within the next 12 months. We recorded a liability for firm, non-cancelable, and unhedged inventory purchase commitments in excess of anticipated demand or net realizable value consistent with our valuation of excess and obsolete inventory. As of September 30, 2021, the liability for these purchase commitments was $22.2 million and is recorded in accrued and other current liabilities.

[0001032975-21-000045:mdna:165]
We have firm purchase commitments of $23.5 million for capital expenditures primarily related to commitments for tooling and equipment for new and existing products. We expect to continue making capital expenditures in the future to support product development activities and ongoing and expanded operations. Although open purchase commitments are considered enforceable and legally binding, the terms generally allow us to reschedule or adjust our requirements based on business needs prior to delivery of goods or performance of services.

[0001032975-21-000045:mdna:166]
[same as prior period, unchanged from 0001032975-21-000034:mdna:152]

[0001032975-21-000045:mdna:167]
[same as prior period, unchanged from 0001032975-21-000034:mdna:153]

[0001032975-21-000045:mdna:168]
[same as prior period, unchanged from 0001032975-21-000034:mdna:154]

[0001032975-21-000045:mdna:169]
We indemnify certain suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of September 30, 2021, no amounts have been accrued for indemnification provisions. We do not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under our indemnification arrangements.

[0001032975-21-000045:mdna:170]
[same as prior period, unchanged from 0001032975-21-000034:mdna:156]

[0001032975-21-000045:mdna:171]
Legal Proceedings

[0001032975-21-000045:mdna:172]
From time to time we are involved in claims and legal proceedings that arise in the ordinary course of our business.  For more information about Legal Proceedings, see Part II Item 1 Legal Proceedings of this quarterly report on Form 10-Q for the period ended September 30, 2021.

[0001032975-21-000045:mdna:173]
39
