# LOGI 8-K — 0001032975-21-000043 filed 2021-10-26

## item codes, every 8-K on or before 2021-10-28

- 2021-10-26 0001032975-21-000043 — 2.02, 9.01
- 2021-09-10 0001032975-21-000040 — 5.07, 8.01
- 2021-07-27 0001032975-21-000029 — 2.02, 9.01
- 2021-04-29 0001032975-21-000012 — 2.02, 9.01
- 2021-01-19 0001032975-21-000004 — 2.02, 9.01
- 2020-10-20 0001032975-20-000045 — 2.02, 9.01
- 2020-09-11 0001032975-20-000042 — 5.07, 8.01
- 2020-07-21 0001032975-20-000029 — 2.02, 9.01
- 2020-07-01 0001032975-20-000023 — 5.02, 8.01
- 2020-05-12 0001032975-20-000011 — 2.02, 9.01
- 2020-03-30 0001032975-20-000009 — 5.02
- 2020-01-21 0001032975-20-000002 — 2.02, 9.01
- 2019-10-22 0001032975-19-000071 — 9.01
- 2019-09-26 0001032975-19-000068 — 1.01, 7.01, 9.01
- 2019-09-06 0001032975-19-000063 — 5.07, 8.01
- 2019-07-23 0001032975-19-000046 — 2.02, 9.01
- 2019-07-23 0001032975-19-000045 — 5.02, 9.01
- 2019-07-02 0001032975-19-000036 — 5.02
- 2019-06-25 0001032975-19-000034 — 5.02
- 2019-05-03 0001032975-19-000021 — 5.02 — amendment, the index does not say of what
- 2019-04-30 0001032975-19-000017 — 2.02, 5.02, 9.01
- 2019-03-28 0001032975-19-000013 — 5.02
- 2019-01-22 0001032975-19-000004 — 2.02, 9.01
- 2018-10-23 0001032975-18-000044 — 2.02, 9.01
- 2018-09-07 0001032975-18-000040 — 5.07, 8.01
- 2018-07-31 0001032975-18-000035 — 1.01, 2.02, 2.05, 7.01, 9.01
- 2018-06-27 0001032975-18-000020 — 5.02
- 2018-05-03 0001032975-18-000013 — 2.02, 5.02, 9.01
- 2018-01-23 0001032975-18-000005 — 2.02, 9.01
- 2017-10-24 0001032975-17-000043 — 2.02, 9.01
- 2017-09-18 0001032975-17-000040 — 5.07, 8.01
- 2017-07-25 0001032975-17-000028 — 2.02, 9.01
- 2017-07-12 0001032975-17-000022 — 1.01
- 2017-04-26 0001032975-17-000012 — 2.02, 9.01
- 2017-01-25 0001032975-17-000002 — 2.02, 9.01
- 2016-10-26 0001032975-16-000103 — 2.02, 9.01
- 2016-09-13 0001032975-16-000101 — 5.07, 8.01
- 2016-07-28 0001032975-16-000092 — 2.02, 9.01
- 2016-06-30 0001032975-16-000087 — 5.02
- 2016-04-28 0001032975-16-000077 — 2.02, 9.01
- 2016-04-14 0001032975-16-000073 — 1.01, 7.01, 9.01
- 2016-01-21 0001032975-16-000064 — 2.02, 9.01
- 2016-01-04 0001032975-16-000061 — 1.01, 2.01, 9.01
- 2015-12-23 0001032975-15-000059 — 5.02
- 2015-10-22 0001032975-15-000047 — 2.02, 9.01
- 2015-09-11 0001032975-15-000044 — 5.07, 8.01
- 2015-07-24 0001032975-15-000034 — 2.05 — amendment of 0001032975-15-000030
- 2015-07-23 0001032975-15-000030 — 2.02, 9.01
- 2015-06-25 0001032975-15-000025 — 5.02
- 2015-05-14 0001032975-15-000011 — 8.01, 9.01
- 2015-04-23 0001032975-15-000008 — 2.02, 2.05
- 2015-01-22 0001628280-15-000191 — 2.02, 8.01
- 2014-12-23 0001193125-14-450908 — 5.02, 5.07, 8.01
- 2014-11-25 0001193125-14-425233 — 3.01
- 2014-11-13 0001193125-14-411303 — 4.01, 9.01
- 2014-10-23 0001104659-14-073164 — 2.02, 9.01
- 2014-09-04 0001193125-14-331214 — 4.02, 9.01
- 2014-08-18 0001193125-14-313346 — 3.01, 9.01
- 2014-07-24 0001104659-14-053065 — 2.02, 9.01
- 2014-06-05 0001193125-14-226177 — 3.01, 9.01
- 2014-05-22 0001193125-14-208777 — 8.01, 9.01
- 2014-04-24 0001104659-14-029650 — 2.02, 9.01
- 2014-01-23 0001104659-14-003619 — 2.02, 9.01
- 2013-10-24 0001104659-13-077404 — 2.02, 9.01
- 2013-09-09 0001193125-13-361441 — 5.02, 5.07, 8.01, 9.01
- 2013-09-06 0001193125-13-359930 — 5.02, 9.01
- 2013-08-02 0001193125-13-317343 — 5.02
- 2013-07-25 0001104659-13-056372 — 2.02, 9.01
- 2013-06-28 0001193125-13-277394 — 5.02, 9.01
- 2013-06-20 0001193125-13-265914 — 8.01, 9.01
- 2013-04-25 0001104659-13-032570 — 2.02, 9.01
- 2013-04-17 0001193125-13-158923 — 5.02, 9.01
- 2013-03-01 0001193125-13-085804 — 2.05
- 2013-01-24 0001104659-13-004214 — 2.02, 9.01
- 2013-01-02 0001193125-13-000058 — 5.02
- 2012-10-25 0001104659-12-070966 — 2.02, 9.01
- 2012-09-11 0001193125-12-388070 — 5.02, 5.07, 8.01, 9.01
- 2012-08-22 0001193125-12-364167 — 5.02, 8.01, 9.01
- 2012-07-26 0001104659-12-051084 — 2.02, 9.01
- 2012-06-08 0001193125-12-264132 — 2.05, 9.01 — amendment, the index does not say of what
- 2012-04-26 0001193125-12-183657 — 5.02, 9.01
- 2012-04-26 0001104659-12-028470 — 2.02, 2.05, 9.01
- 2012-03-15 0001193125-12-115954 — 5.02, 9.01
- 2012-01-26 0001104659-12-004014 — 2.02, 9.01
- 2012-01-04 0001193125-12-002212 — 1.01, 2.03, 9.01
- 2011-10-27 0001104659-11-058150 — 2.02, 9.01
- 2011-09-12 0001193125-11-245931 — 5.07
- 2011-07-28 0001193125-11-200929 — 5.02, 9.01
- 2011-07-28 0001193125-11-199704 — 2.02, 9.01
- 2011-04-28 0001193125-11-112669 — 2.02, 9.01
- 2011-03-24 0001193125-11-076483 — 5.02, 9.01
- 2011-01-27 0001032975-11-000003 — 9.01
- 2010-10-28 0001032975-10-000032 — 9.01
- 2010-09-13 0001032975-10-000022 — 5.07
- 2010-07-29 0001032975-10-000010 — 2.02, 9.01
- 2010-06-10 0001193125-10-136877 — 5.02, 9.01
- 2010-05-03 0001193125-10-104337 — 5.02
- 2010-04-29 0001032975-10-000008 — 2.02, 9.01
- 2010-02-19 0001032975-10-000006 — 9.01 — amendment of 0001193125-09-252416
- 2010-01-21 0001032975-10-000002 — 2.02, 9.01
- 2009-12-14 0001193125-09-252416 — 2.01, 9.01
- 2009-11-17 0001032975-09-000023 — 1.01
- 2009-10-22 0001032975-09-000018 — 9.01
- 2009-09-22 0001193125-09-195545 — 5.02, 9.01
- 2009-09-03 0001032975-09-000013 — 8.01
- 2009-07-23 0001140361-09-016802 — 2.02, 9.01
- 2009-06-01 0001193125-09-122550 — 5.02
- 2009-04-23 0001193125-09-085054 — 2.02, 9.01
- 2009-04-02 0001193125-09-071272 — 5.02, 9.01
- 2009-01-20 0001193125-09-008454 — 2.05 — amendment of 0001193125-09-002609
- 2009-01-20 0001193125-09-007902 — 2.02, 9.01
- 2009-01-07 0001193125-09-002609 — 2.05, 9.01
- 2009-01-07 0001193125-09-002370 — 5.02, 9.01
- 2008-12-09 0001193125-08-250543 — 5.02, 9.01
- 2008-10-21 0001193125-08-213212 — 2.02, 9.01
- 2008-07-22 0001193125-08-154721 — 2.02, 9.01
- 2008-06-24 0001193125-08-139163 — 5.03, 9.01
- 2008-05-13 0001193125-08-113263 — 5.02, 9.01
- 2008-04-22 0001193125-08-086176 — 2.02, 9.01

## late-filing notifications on or before 2021-10-28

- 2015-06-02 0001032975-15-000020 — NT 10-K, for the period ended 2015-03-31
- 2014-11-06 0001193125-14-401306 — NT 10-Q, for the period ended 2014-09-30
- 2014-07-24 0001193125-14-277575 — NT 10-Q, for the period ended 2014-06-30
- 2014-05-22 0001193125-14-208712 — NT 10-K, for the period ended 2014-03-31
- 2009-08-06 0001032975-09-000006 — NT 10-Q, for the period ended 2009-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001032975-21-000043:8k_2_02:1]
EX-99.1
2
exhibit991q2fy22.htm
EX-99.1

[0001032975-21-000043:8k_2_02:2]
Document

[0001032975-21-000043:8k_2_02:3]
Exhibit 99.1

[0001032975-21-000043:8k_2_02:4]
Editorial Contacts:

[0001032975-21-000043:8k_2_02:5]
Nicole Noutsios, Investor Relations - lir@logitech.com

[0001032975-21-000043:8k_2_02:6]
Nicole Kenyon, Head of Global Corporate & Employee Communications - USA +1 (510) 988-8553

[0001032975-21-000043:8k_2_02:7]
Ben Starkie, Corporate Communications - Europe +41 (0) 79-292-3499

[0001032975-21-000043:8k_2_02:8]
Logitech Delivers Record Q2 Sales

[0001032975-21-000043:8k_2_02:9]
Company Confirms FY 2022 Outlook

[0001032975-21-000043:8k_2_02:10]
LAUSANNE, Switzerland, Oct. 26, 2021 and NEWARK, Calif., Oct. 25, 2021 — SIX Swiss Exchange Ad hoc announcement pursuant to Art. 53 LR —

[0001032975-21-000043:8k_2_02:11]
Logitech International (SIX: LOGN) (Nasdaq: LOGI) today announced financial results for the second quarter of Fiscal Year 2022.

[0001032975-21-000043:8k_2_02:12]
•Q2 sales were $1.31 billion, up 4 percent in US dollars and 2 percent in constant currency, compared to Q2 of the prior year.

[0001032975-21-000043:8k_2_02:13]
•Q2 GAAP operating income declined 44 percent to $179 million, compared to $322 million in the same quarter a year ago. Q2 GAAP earnings per share (EPS) declined 48 percent to $0.81, compared to $1.56 in the same quarter a year ago.

[0001032975-21-000043:8k_2_02:14]
•Q2 non-GAAP operating income declined 40 percent to $211 million, compared to $354 million in the same quarter a year ago. Q2 non-GAAP EPS declined 44 percent to $1.05, compared to $1.87 in the same quarter a year ago.

[0001032975-21-000043:8k_2_02:15]
“In Q2 we delivered record sales which beat last year's exceptional sales levels, growing 4% in the quarter and 82% compared to two years ago. We also grew market share in the majority of our key product categories,” said Bracken Darrell, Logitech president and chief executive officer. “We are confirming our full year outlook, despite unprecedented supply chain industry challenges. I am excited about the long-term growth potential of Logitech.”

[0001032975-21-000043:8k_2_02:16]
Outlook

[0001032975-21-000043:8k_2_02:17]
Logitech confirmed its Fiscal Year 2022 outlook of flat sales growth in constant currency, plus or minus five percent, and $800 million to $850 million in non-GAAP operating income.

[0001032975-21-000043:8k_2_02:18]
Prepared Remarks Available Online

[0001032975-21-000043:8k_2_02:19]
Logitech has made its prepared written remarks for the financial results videoconference available online on the Logitech corporate website at http://ir.logitech.com.

[0001032975-21-000043:8k_2_02:20]
Financial Results Videoconference and Webcast

[0001032975-21-000043:8k_2_02:21]
Logitech will hold a financial results videoconference to discuss the results for Q2 Fiscal Year 2022 on Tuesday, October 26, 2021 at 8:30 a.m. Eastern Daylight Time and 2:30 p.m. Central European Summer Time. A livestream of the event will be available on the Logitech corporate website at http://ir.logitech.com.

[0001032975-21-000043:8k_2_02:22]
Use of Non-GAAP Financial Information and Constant Currency

[0001032975-21-000043:8k_2_02:23]
To facilitate comparisons to Logitech’s historical results, Logitech has included non-GAAP adjusted measures, which exclude share-based compensation expense, amortization of intangible assets, acquisition-related costs, change in fair value of contingent consideration for business acquisition, restructuring charges (credits), loss (gain) on investments, non-GAAP income tax adjustment, and other items detailed under “Supplemental Financial Information” after the tables below. Logitech also presents percentage sales growth in constant currency, a non-GAAP measure, to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales. Logitech believes this information, used together with the GAAP financial information, will help investors to evaluate its current period performance and trends in its business. With respect to the Company’s outlook for non-GAAP operating income, most of these excluded amounts pertain to events that have not yet occurred and are not currently possible to estimate with a reasonable degree of accuracy. Therefore, no reconciliation to the GAAP amounts has been provided for the Fiscal Year 2022 outlook.

[0001032975-21-000043:8k_2_02:24]
Public Dissemination of Certain Information

[0001032975-21-000043:8k_2_02:25]
Logitech webcasts its earnings calls and certain events Logitech participates in or hosts with members of the investment community on its investor relations website at https://ir.logitech.com. Additionally, Logitech provides notifications of news or announcements regarding its operations and financial performance, including its filings with the Securities and Exchange Commission (SEC), investor events, and press and earnings releases as part of its investor relations website. Logitech intends to use its investor relations website as means of disclosing material nonpublic information and for complying with its disclosure obligations under Regulation FD. Logitech’s corporate governance information also is available on its investor relations website.

[0001032975-21-000043:8k_2_02:26]
About Logitech

[0001032975-21-000043:8k_2_02:27]
Logitech helps all people pursue their passions by designing experiences so everyone can create, achieve, and enjoy more. Logitech designs and creates products that bring people together through

[0001032975-21-000043:8k_2_02:28]
computing, gaming, video, streaming and creating, and music. Brands of Logitech include Logitech, Logitech G, ASTRO Gaming, Streamlabs, Blue Microphones, Ultimate Ears, and Jaybird. Founded in 1981, and headquartered in Lausanne, Switzerland, Logitech International is a Swiss public company listed on the SIX Swiss Exchange (LOGN) and on the Nasdaq Global Select Market (LOGI). Find Logitech at www.logitech.com, the company blog or @Logitech.

[0001032975-21-000043:8k_2_02:29]
# # #

[0001032975-21-000043:8k_2_02:30]
Note that unless noted otherwise, comparisons are year over year.

[0001032975-21-000043:8k_2_02:31]
Logitech and other Logitech marks are trademarks or registered trademarks of Logitech Europe S.A. and/or its affiliates in the U.S. and other countries. All other trademarks are the property of their respective owners. For more information about Logitech and its products, visit the company’s website at www.logitech.com.

[0001032975-21-000043:8k_2_02:32]
(LOGIIR)

[0001032975-21-000043:8k_2_02:33]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
| GAAP CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Net sales |  | $ | 1,306,267 |  |  | $ | 1,257,158 |  |  | $ | 2,618,325 |  |  | $ | 2,049,052 |  |
| Cost of goods sold |  | 760,268 |  |  | 684,599 |  |  | 1,499,334 |  |  | 1,167,237 |  |
| Amortization of intangible assets |  | 3,836 |  |  | 2,836 |  |  | 7,902 |  |  | 6,359 |  |
| Gross profit |  | 542,163 |  |  | 569,723 |  |  | 1,111,089 |  |  | 875,456 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Marketing and selling |  | 256,627 |  |  | 158,797 |  |  | 508,941 |  |  | 292,035 |  |
| Research and development |  | 68,661 |  |  | 53,379 |  |  | 137,907 |  |  | 103,104 |  |
| General and administrative |  | 33,271 |  |  | 31,664 |  |  | 73,813 |  |  | 60,735 |  |
| Amortization of intangible assets and acquisition-related costs |  | 5,107 |  |  | 4,331 |  |  | 10,324 |  |  | 8,940 |  |
| Change in fair value of contingent consideration for business acquisition |  | (925) |  |  | — |  |  | (2,399) |  |  | 5,716 |  |
| Restructuring charges (credits), net |  | 11 |  |  | (1) |  |  | 11 |  |  | (54) |  |
| Total operating expenses |  | 362,752 |  |  | 248,170 |  |  | 728,597 |  |  | 470,476 |  |
| Operating income |  | 179,411 |  |  | 321,553 |  |  | 382,492 |  |  | 404,980 |  |
| Interest income |  | 201 |  |  | 513 |  |  | 517 |  |  | 1,133 |  |
| Other income (expense), net |  | (6,703) |  |  | 1,149 |  |  | 1,732 |  |  | 3,178 |  |
| Income before income taxes |  | 172,909 |  |  | 323,215 |  |  | 384,741 |  |  | 409,291 |  |
| Provision for income taxes |  | 33,453 |  |  | 56,301 |  |  | 58,444 |  |  | 70,304 |  |
| Net income |  | $ | 139,456 |  |  | $ | 266,914 |  |  | $ | 326,297 |  |  | $ | 338,987 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.83 |  |  | $ | 1.58 |  |  | $ | 1.94 |  |  | $ | 2.02 |  |
| Diluted |  | $ | 0.81 |  |  | $ | 1.56 |  |  | $ | 1.90 |  |  | $ | 1.99 |  |
| Weighted average shares used to compute net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | 168,389 |  |  | 168,645 |  |  | 168,380 |  |  | 168,140 |  |
| Diluted |  | 171,343 |  |  | 171,382 |  |  | 171,682 |  |  | 170,766 |  |

[0001032975-21-000043:8k_2_02:34]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
|  |  | September 30, |  | March 31, |  |  |  |  |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  | 2021 |  | 2021 |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,137,296 |  |  | $ | 1,750,327 |  |  |  |  |  |
| Accounts receivable, net |  | 728,074 |  |  | 612,225 |  |  |  |  |  |
| Inventories |  | 827,710 |  |  | 661,116 |  |  |  |  |  |
| Other current assets |  | 166,731 |  |  | 135,650 |  |  |  |  |  |
| Total current assets |  | 2,859,811 |  |  | 3,159,318 |  |  |  |  |  |
| Non-current assets: |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  | 111,625 |  |  | 114,060 |  |  |  |  |  |
| Goodwill |  | 449,357 |  |  | 429,604 |  |  |  |  |  |
| Other intangible assets, net |  | 103,501 |  |  | 115,148 |  |  |  |  |  |
| Other assets |  | 331,870 |  |  | 324,248 |  |  |  |  |  |
| Total assets |  | $ | 3,856,164 |  |  | $ | 4,142,378 |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 660,720 |  |  | $ | 823,233 |  |  |  |  |  |
| Accrued and other current liabilities |  | 709,878 |  |  | 858,617 |  |  |  |  |  |
| Total current liabilities |  | 1,370,598 |  |  | 1,681,850 |  |  |  |  |  |
| Non-current liabilities: |  |  |  |  |  |  |  |  |
| Income taxes payable |  | 67,651 |  |  | 59,237 |  |  |  |  |  |
| Other non-current liabilities |  | 155,232 |  |  | 139,502 |  |  |  |  |  |
| Total liabilities |  | 1,593,481 |  |  | 1,880,589 |  |  |  |  |  |
| Shareholders’ equity: |  |  |  |  |  |  |  |  |
| Registered shares, CHF 0.25 par value: |  | 30,148 |  |  | 30,148 |  |  |  |  |  |
| Issued shares — 173,106 at September 30 and March 31, 2021 |  |  |  |  |  |  |  |  |
| Additional shares that may be issued out of conditional capitals — 50,000 at September 30 and March 31, 2021 |  |  |  |  |  |  |  |  |
| Additional shares that may be issued out of authorized capital — 17,311 at September 30 and March 31, 2021 |  |  |  |  |  |  |  |  |
| Additional paid-in capital |  | 99,434 |  |  | 129,519 |  |  |  |  |  |
| Shares in treasury, at cost — 5,331 at September 30, 2021 and 4,799 at March 31, 2021 |  | (413,345) |  |  | (279,541) |  |  |  |  |  |
| Retained earnings |  | 2,657,465 |  |  | 2,490,578 |  |  |  |  |  |
| Accumulated other comprehensive loss |  | (111,019) |  |  | (108,915) |  |  |  |  |  |
| Total shareholders’ equity |  | 2,262,683 |  |  | 2,261,789 |  |  |  |  |  |
| Total liabilities and shareholders’ equity |  | $ | 3,856,164 |  |  | $ | 4,142,378 |  |  |  |  |  |

[0001032975-21-000043:8k_2_02:35]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 139,456 |  |  | $ | 266,914 |  |  | $ | 326,297 |  |  | $ | 338,987 |  |
| Adjustments to reconcile net income to net cash provided by/ (used in) operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  | 23,012 |  |  | 10,854 |  |  | 43,474 |  |  | 22,601 |  |
| Amortization of intangible assets |  | 8,625 |  |  | 7,107 |  |  | 17,468 |  |  | 15,239 |  |
| Loss on investments |  | 2,032 |  |  | 2,693 |  |  | 961 |  |  | 2,519 |  |
| Share-based compensation expense |  | 24,022 |  |  | 24,785 |  |  | 47,673 |  |  | 44,900 |  |
| Deferred income taxes |  | 10,966 |  |  | 16,563 |  |  | 6,808 |  |  | 20,152 |  |
| Change in fair value of contingent consideration for business acquisition |  | (925) |  |  | — |  |  | (2,399) |  |  | 5,716 |  |
| Other |  | 14 |  |  | (1,886) |  |  | 1,059 |  |  | (1,877) |  |
| Changes in assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | (186,316) |  |  | (244,746) |  |  | (113,008) |  |  | (346,838) |  |
| Inventories |  | (52,422) |  |  | (120,735) |  |  | (167,588) |  |  | (161,120) |  |
| Other assets |  | (17,644) |  |  | (15,797) |  |  | (48,440) |  |  | (31,567) |  |
| Accounts payable |  | (39,862) |  |  | 230,830 |  |  | (155,482) |  |  | 399,176 |  |
| Accrued and other liabilities |  | 26,164 |  |  | 103,090 |  |  | (134,671) |  |  | 90,631 |  |
| Net cash provided by / (used in) operating activities |  | (62,878) |  |  | 279,672 |  |  | (177,848) |  |  | 398,519 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  | (22,718) |  |  | (15,466) |  |  | (47,232) |  |  | (27,774) |  |
| Investment in privately held companies |  | (400) |  |  | (3,375) |  |  | (901) |  |  | (3,405) |  |
| Acquisition, net of cash acquired |  | — |  |  | — |  |  | (15,586) |  |  | — |  |
| Purchases of trading investments |  | (1,375) |  |  | (5,775) |  |  | (2,466) |  |  | (8,199) |  |
| Proceeds from sales of trading investments |  | 1,632 |  |  | 6,477 |  |  | 2,977 |  |  | 8,839 |  |
| Net cash used in investing activities |  | (22,861) |  |  | (18,139) |  |  | (63,208) |  |  | (30,539) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Payment of cash dividends |  | (159,410) |  |  | (146,705) |  |  | (159,410) |  |  | (146,705) |  |
| Purchases of registered shares |  | (119,508) |  |  | (22,454) |  |  | (174,380) |  |  | (22,454) |  |
| Proceeds from exercises of stock options and purchase rights |  | 13,886 |  |  | 16,074 |  |  | 16,636 |  |  | 26,066 |  |
| Tax withholdings related to net share settlements of restricted stock units |  | (4,340) |  |  | (2,623) |  |  | (54,751) |  |  | (25,744) |  |
| Net cash used in financing activities |  | (269,372) |  |  | (155,708) |  |  | (371,905) |  |  | (168,837) |  |
| Effect of exchange rate changes on cash and cash equivalents |  | (5,314) |  |  | 2,001 |  |  | (70) |  |  | 2,512 |  |
| Net increase / (decrease) in cash and cash equivalents |  | (360,425) |  |  | 107,826 |  |  | (613,031) |  |  | 201,655 |  |
| Cash and cash equivalents, beginning of the period |  | 1,497,721 |  |  | 809,395 |  |  | 1,750,327 |  |  | 715,566 |  |
| Cash and cash equivalents, end of the period |  | $ | 1,137,296 |  |  | $ | 917,221 |  |  | $ | 1,137,296 |  |  | $ | 917,221 |  |

[0001032975-21-000043:8k_2_02:36]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three Months Ended |  | Six Months Ended |
|  |  | September 30, |  | September 30, |
| NET SALES |  | 2021 |  | 2020 |  | Change |  | 2021 |  | 2020 |  | Change |
| Net sales by product category: |  |  |  |  |  |  |  |  |  |  |  |  |
| Pointing Devices |  | $ | 189,014 |  |  | $ | 169,121 |  |  | 12 | % |  | $ | 371,892 |  |  | $ | 289,590 |  |  | 28 | % |
| Keyboards & Combos |  | 236,272 |  |  | 201,617 |  |  | 17 |  |  | 454,629 |  |  | 346,977 |  |  | 31 |  |
| PC Webcams |  | 94,471 |  |  | 102,469 |  |  | (8) |  |  | 204,389 |  |  | 163,320 |  |  | 25 |  |
| Tablet & Other Accessories |  | 80,801 |  |  | 83,086 |  |  | (3) |  |  | 160,073 |  |  | 129,134 |  |  | 24 |  |
| Gaming (1) |  | 330,777 |  |  | 297,711 |  |  | 11 |  |  | 666,174 |  |  | 479,614 |  |  | 39 |  |
| Video Collaboration |  | 231,653 |  |  | 236,704 |  |  | (2) |  |  | 466,538 |  |  | 366,778 |  |  | 27 |  |
| Mobile Speakers |  | 39,492 |  |  | 43,581 |  |  | (9) |  |  | 67,976 |  |  | 72,590 |  |  | (6) |  |
| Audio & Wearables |  | 98,078 |  |  | 114,275 |  |  | (14) |  |  | 214,685 |  |  | 185,640 |  |  | 16 |  |
| Smart Home |  | 5,649 |  |  | 8,573 |  |  | (34) |  |  | 11,821 |  |  | 15,383 |  |  | (23) |  |
| Other (2) |  | 60 |  |  | 21 |  |  | 186 |  |  | 148 |  |  | 26 |  |  | 469 |  |
| Total Sales |  | $ | 1,306,267 |  |  | $ | 1,257,158 |  |  | 4 | % |  | $ | 2,618,325 |  |  | $ | 2,049,052 |  |  | 28 | % |

[0001032975-21-000043:8k_2_02:37]
(1) Gaming includes streaming services revenue generated by Streamlabs.

[0001032975-21-000043:8k_2_02:38]
(2) Other includes products that the Company currently intends to phase out, or has already phased out, because they are no longer strategic to the Company's business.

[0001032975-21-000043:8k_2_02:39]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
| GAAP TO NON GAAP RECONCILIATION (A) |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Gross profit - GAAP |  | $ | 542,163 |  |  | $ | 569,723 |  |  | $ | 1,111,089 |  |  | $ | 875,456 |  |
| Share-based compensation expense |  | 2,102 |  |  | 1,772 |  |  | 3,471 |  |  | 3,172 |  |
| Amortization of intangible assets |  | 3,836 |  |  | 2,836 |  |  | 7,902 |  |  | 6,359 |  |
| Gross profit - Non-GAAP |  | $ | 548,101 |  |  | $ | 574,331 |  |  | $ | 1,122,462 |  |  | $ | 884,987 |  |
| Gross margin - GAAP |  | 41.5 | % |  | 45.3 | % |  | 42.4 | % |  | 42.7 | % |
| Gross margin - Non-GAAP |  | 42.0 | % |  | 45.7 | % |  | 42.9 | % |  | 43.2 | % |
| Operating expenses - GAAP |  | $ | 362,752 |  |  | $ | 248,170 |  |  | $ | 728,597 |  |  | $ | 470,476 |  |
| Less: Share-based compensation expense |  | 21,920 |  |  | 23,013 |  |  | 44,202 |  |  | 41,728 |  |
| Less: Amortization of intangible assets and acquisition-related costs |  | 5,107 |  |  | 4,331 |  |  | 10,324 |  |  | 8,940 |  |
| Less: Change in fair value of contingent consideration for business acquisition |  | (925) |  |  | — |  |  | (2,399) |  |  | 5,716 |  |
| Less: Restructuring charges (credits), net |  | 11 |  |  | (1) |  |  | 11 |  |  | (54) |  |
| Operating expenses - Non-GAAP |  | $ | 336,639 |  |  | $ | 220,827 |  |  | $ | 676,459 |  |  | $ | 414,146 |  |
| % of net sales - GAAP |  | 27.8 | % |  | 19.7 | % |  | 27.8 | % |  | 23.0 | % |
| % of net sales - Non - GAAP |  | 25.8 | % |  | 17.6 | % |  | 25.8 | % |  | 20.2 | % |
| Operating income - GAAP |  | $ | 179,411 |  |  | $ | 321,553 |  |  | $ | 382,492 |  |  | $ | 404,980 |  |
| Share-based compensation expense |  | 24,022 |  |  | 24,785 |  |  | 47,673 |  |  | 44,900 |  |
| Amortization of intangible assets and acquisition-related costs |  | 8,943 |  |  | 7,167 |  |  | 18,226 |  |  | 15,299 |  |
| Change in fair value of contingent consideration for business acquisition |  | (925) |  |  | — |  |  | (2,399) |  |  | 5,716 |  |
| Restructuring charges (credits), net |  | 11 |  |  | (1) |  |  | 11 |  |  | (54) |  |
| Operating income - Non - GAAP |  | $ | 211,462 |  |  | $ | 353,504 |  |  | $ | 446,003 |  |  | $ | 470,841 |  |
| % of net sales - GAAP |  | 13.7 | % |  | 25.6 | % |  | 14.6 | % |  | 19.8 | % |
| % of net sales - Non - GAAP |  | 16.2 | % |  | 28.1 | % |  | 17.0 | % |  | 23.0 | % |
| Net income - GAAP |  | $ | 139,456 |  |  | $ | 266,914 |  |  | $ | 326,297 |  |  | $ | 338,987 |  |
| Share-based compensation expense |  | 24,022 |  |  | 24,785 |  |  | 47,673 |  |  | 44,900 |  |
| Amortization of intangible assets and acquisition-related costs |  | 8,943 |  |  | 7,167 |  |  | 18,226 |  |  | 15,299 |  |
| Change in fair value of contingent consideration for business acquisition |  | (925) |  |  | — |  |  | (2,399) |  |  | 5,716 |  |
| Restructuring charges (credits), net |  | 11 |  |  | (1) |  |  | 11 |  |  | (54) |  |
| Loss on investments |  | 2,032 |  |  | 2,693 |  |  | 961 |  |  | 2,519 |  |
| Non-GAAP income tax adjustment |  | 6,825 |  |  | 18,351 |  |  | (591) |  |  | 21,399 |  |
| Net income - Non - GAAP |  | $ | 180,364 |  |  | $ | 319,909 |  |  | $ | 390,178 |  |  | $ | 428,766 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  | $ | 0.81 |  |  | $ | 1.56 |  |  | $ | 1.90 |  |  | $ | 1.99 |  |
| Diluted - Non - GAAP |  | $ | 1.05 |  |  | $ | 1.87 |  |  | $ | 2.27 |  |  | $ | 2.51 |  |
| Shares used to compute net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP and Non - GAAP |  | 171,343 |  |  | 171,382 |  |  | 171,682 |  |  | 170,766 |  |

[0001032975-21-000043:8k_2_02:40]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
| SHARE-BASED COMPENSATION EXPENSE |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Share-based Compensation Expense |  |  |  |  |  |  |  |  |
| Cost of goods sold |  | $ | 2,102 |  |  | $ | 1,772 |  |  | $ | 3,471 |  |  | $ | 3,172 |  |
| Marketing and selling |  | 9,758 |  |  | 10,377 |  |  | 18,288 |  |  | 19,169 |  |
| Research and development |  | 4,724 |  |  | 3,763 |  |  | 9,785 |  |  | 6,866 |  |
| General and administrative |  | 7,438 |  |  | 8,873 |  |  | 16,129 |  |  | 15,693 |  |
| Total share-based compensation expense |  | 24,022 |  |  | 24,785 |  |  | 47,673 |  |  | 44,900 |  |
| Income tax benefit |  | (3,285) |  |  | (3,958) |  |  | (19,879) |  |  | (12,069) |  |
| Total share-based compensation expense, net of income tax benefit |  | $ | 20,737 |  |  | $ | 20,827 |  |  | $ | 27,794 |  |  | $ | 32,831 |  |

[0001032975-21-000043:8k_2_02:41]
*Note: These preliminary results for the three and six months ended September 30, 2021 are subject to adjustments, including subsequent events that may occur through the date of filing our Quarterly Report on Form 10-Q.

[0001032975-21-000043:8k_2_02:42]
(A) Non-GAAP Financial Measures

[0001032975-21-000043:8k_2_02:43]
To supplement our condensed consolidated financial results prepared in accordance with GAAP, we use a number of financial measures, both GAAP and non-GAAP, in analyzing and assessing our overall business performance, for making operating decisions and for forecasting and planning future periods. We consider the use of non-GAAP financial measures helpful in assessing our current financial performance, ongoing operations and prospects for the future as well as understanding financial and business trends relating to our financial condition and results of operations.

[0001032975-21-000043:8k_2_02:44]
While we use non-GAAP financial measures as a tool to enhance our understanding of certain aspects of our financial performance and to provide incremental insight into the underlying factors and trends affecting both our performance and our cash-generating potential, we do not consider these measures to be a substitute for, or superior to, the information provided by GAAP financial measures. Consistent with this approach, we believe that disclosing non-GAAP financial measures to the readers of our financial statements provides useful supplemental data that, while not a substitute for GAAP financial measures, can offer insight in the review of our financial and operational performance and enables investors to more fully understand trends in our current and future performance. In assessing our business during the quarter ended September 30, 2021 and previous periods, we excluded items in the following general categories, each of which are described below:

[0001032975-21-000043:8k_2_02:45]
Share-based compensation expense. We believe that providing non-GAAP measures excluding share-based compensation expense, in addition to the GAAP measures, allows for a more transparent comparison of our financial results from period to period. We prepare and maintain our budgets and forecasts for future periods on a basis consistent with this non-GAAP financial measure. Further, companies use a variety of types of equity awards as well as a variety of methodologies, assumptions and estimates to determine share-based compensation expense. We believe that excluding share-based compensation expense enhances our ability and the ability of investors to understand the impact of non-cash share-based compensation on our operating results and to compare our results against the results of other companies.

[0001032975-21-000043:8k_2_02:46]
Amortization of intangible assets. We incur intangible asset amortization expense, primarily in connection with our acquisitions of various businesses and technologies. The amortization of purchased intangibles varies depending on the level of acquisition activity. We exclude these various charges in budgeting, planning and forecasting future periods and we believe that providing the non-GAAP measures excluding these various non-cash charges, as well as the GAAP measures, provides additional insight when comparing our gross profit, operating expenses, and financial results from period to period.

[0001032975-21-000043:8k_2_02:47]
Acquisition-related costs and change in fair value of contingent consideration for business acquisition.  We incurred expenses and credits in connection with our acquisitions which we generally would not have otherwise incurred in the periods presented as a part of our continuing operations. Acquisition related costs include all incremental expenses incurred to effect a business combination. Fair value of contingent consideration is associated with our estimates of the value of earn-outs in connection with certain acquisitions. We believe that providing the non-GAAP

[0001032975-21-000043:8k_2_02:48]
measures excluding these costs and credits, as well as the GAAP measures, assists our investors because such costs are not reflective of our ongoing operating results.

[0001032975-21-000043:8k_2_02:49]
Restructuring charges (credits). These expenses are associated with re-aligning our business strategies based on current economic conditions. We have undertaken several restructuring plans in recent years. In connection with our restructuring initiatives, we incurred restructuring charges related to employee terminations, facility closures and early cancellation of certain contracts. We believe that providing the non-GAAP measures excluding these items, as well as the GAAP measures, assists our investors because such charges (credits) are not reflective of our ongoing operating results in the current period.

[0001032975-21-000043:8k_2_02:50]
Loss (gain) on investments. We recognize losses (gains) related to our investments in various companies, which vary depending on the operational and financial performance of the companies in which we invest.  These amounts include our losses (earnings) on equity method investments, investment impairments and losses (gains) resulting from sales or other events related to our investments. We believe that providing the non-GAAP measures excluding these items, as well as the GAAP measures, assists our investors because such losses (gains) are not reflective of our ongoing operations.

[0001032975-21-000043:8k_2_02:51]
Non-GAAP income tax adjustment.  Non-GAAP income tax adjustment primarily measures the income tax effect of non-GAAP adjustments excluded above and other events; the determination of which is based upon the nature of the underlying items, the mix of income and losses in jurisdictions and the relevant tax rates in which we operate.

[0001032975-21-000043:8k_2_02:52]
Each of the non-GAAP financial measures described above, and used in this press release, should not be considered in isolation from, or as a substitute for, a measure of financial performance prepared in accordance with GAAP. Further, investors are cautioned that there are inherent limitations associated with the use of each of these non-GAAP financial measures as an analytical tool. In particular, these non-GAAP financial measures are not based on a comprehensive set of accounting rules or principles and many of the adjustments to the GAAP financial measures reflect the exclusion of items that are recurring and may be reflected in the Company’s financial results for the foreseeable future. We compensate for these limitations by providing specific information in the reconciliation included in this press release regarding the GAAP amounts excluded from the non-GAAP financial measures. In addition, as noted above, we evaluate the non-GAAP financial measures together with the most directly comparable GAAP financial information.

[0001032975-21-000043:8k_2_02:53]
Additional Supplemental Financial Information - Constant Currency

[0001032975-21-000043:8k_2_02:54]
In addition, Logitech presents percentage sales growth in constant currency to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales.
