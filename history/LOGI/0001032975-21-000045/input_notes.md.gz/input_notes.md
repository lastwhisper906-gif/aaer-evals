# LOGI notes — 0001032975-21-000045


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001032975-21-000045:notes:1]
[same as prior period, unchanged from 0001032975-21-000034:notes:1]

[0001032975-21-000045:notes:2]
[same as prior period, unchanged from 0001032975-21-000034:notes:2]

[0001032975-21-000045:notes:3]
[same as prior period, unchanged from 0001032975-21-000034:notes:3]

[0001032975-21-000045:notes:4]
[same as prior period, unchanged from 0001032975-21-000034:notes:4]

[0001032975-21-000045:notes:5]
[same as prior period, unchanged from 0001032975-21-000034:notes:5]

[0001032975-21-000045:notes:6]
[same as prior period, unchanged from 0001032975-21-000034:notes:6]

[0001032975-21-000045:notes:7]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and six months ended September 30, 2021 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2022, or any future periods.

[0001032975-21-000045:notes:8]
[same as prior period, unchanged from 0001032975-21-000034:notes:8]

[0001032975-21-000045:notes:9]
Other than the recent accounting pronouncements adopted and discussed below under Recent Accounting Pronouncements Adopted, there have been no material changes in the Company’s significant accounting policies during the six months ended September 30, 2021 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2021.

[0001032975-21-000045:notes:10]
[same as prior period, unchanged from 0001032975-21-000034:notes:10]

[0001032975-21-000045:notes:11]
[same as prior period, unchanged from 0001032975-21-000034:notes:11]

[0001032975-21-000045:notes:12]
[same as prior period, unchanged from 0001032975-21-000034:notes:12]

[0001032975-21-000045:notes:13]
We are subject to risks and uncertainties as a result of the novel coronavirus ("COVID-19"). Capital markets and economies worldwide have been negatively impacted by COVID-19 and it is still unclear how lasting and deep the economic impacts will be. During the three and six months ended September 30, 2021, the COVID-19 pandemic had mixed effects on the Company’s results of operations. While the Company experienced increased sales for the three and six months ended September 30, 2021, compared to the same period of the prior fiscal year, we also experienced supply and demand volatility, as the COVID-19 pandemic and related safety measures and restrictions have evolved differently across the world. In addition, we experienced industry-wide supply chain challenges. The ongoing and full extent of the impact of the COVID-19 pandemic on the Company's business and operational and financial performance and condition, including the sustainability of its effect on trends positive to the Company, is uncertain and will depend on many factors outside the Company's control, including but not limited to the timing, extent, duration and effects of the virus and any of its mutations, the vaccination rates, the development of effective treatments, the imposition of effective public safety and other protective measures and the public's response to such measures, the impact of COVID-19 on the global economy and demand for the Company's products and services. Should the COVID-19 pandemic or global economic slowdown not improve or worsen, or if the Company's attempt to mitigate its impact on its operations and costs is not successful, the Company's business, results of operations, financial condition and prospects may be adversely affected.

[0001032975-21-000045:notes:14]
[same as prior period, unchanged from 0001032975-21-000034:notes:14]

[0001032975-21-000045:notes:15]
In December 2019, the FASB issued ASU 2019-12, "Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes" (ASU 2019-12), which eliminates certain exceptions for recognizing deferred taxes for investments, performing intraperiod allocation and calculating income taxes in interim periods. This ASU also includes guidance to reduce complexity in certain areas, including recognizing deferred taxes for tax goodwill and allocating taxes to members of a consolidated group. ASU 2019-12 is effective for annual and interim periods in fiscal years beginning after December 15, 2020. Early adoption is permitted. The Company adopted this standard effective April 1, 2021. The adoption of ASU 2019-12 did not have a material impact on the Company's condensed consolidated financial statements.


## us-gaap:EarningsPerShareTextBlock

[0001032975-21-000045:notes:16]
[same as prior period, unchanged from 0001032975-21-000034:notes:16]

[0001032975-21-000045:notes:17]
The following table summarizes the computations of basic and diluted net income per share for the three and six months ended September 30, 2021 and September 30, 2020 (in thousands, except per share amounts):

[0001032975-21-000045:notes:18]
|  |  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Net income |  | $ | 139,456 |  |  | $ | 266,914 |  |  | $ | 326,297 |  |  | $ | 338,987 |  |
| Shares used in net income per share computation: |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding - basic |  | 168,389 |  |  | 168,645 |  |  | 168,380 |  |  | 168,140 |  |
| Effect of potentially dilutive equivalent shares |  | 2,954 |  |  | 2,737 |  |  | 3,302 |  |  | 2,626 |  |
| Weighted average shares outstanding - diluted |  | 171,343 |  |  | 171,382 |  |  | 171,682 |  |  | 170,766 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.83 |  |  | $ | 1.58 |  |  | $ | 1.94 |  |  | $ | 2.02 |  |
| Diluted |  | $ | 0.81 |  |  | $ | 1.56 |  |  | $ | 1.90 |  |  | $ | 1.99 |  |

[0001032975-21-000045:notes:19]
Share equivalents attributable to outstanding stock options, restricted stock units ("RSUs") and employee share purchase plans ("ESPP") totaling 0.5 million and 0.4 million for the three months ended September 30, 2021 and 2020, respectively, and 0.5 million and 0.4 million for the six months ended September 30, 2021 and 2020, respectively, were excluded from the calculation of diluted net income per share because the combined exercise price and average unamortized grant date fair value upon exercise of these options and ESPP rights or vesting of RSUs were greater than the average market price of the Company's shares during the periods presented herein, and therefore their inclusion would have been anti-dilutive. A small number of performance-based awards were not included in the calculation because all necessary conditions had not been satisfied by the end of the respective period, and those shares were not issuable if the end of the reporting period were the end of the performance contingency period.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001032975-21-000045:notes:20]
[same as prior period, unchanged from 0001032975-21-000034:notes:20]

[0001032975-21-000045:notes:21]
[same as prior period, unchanged from 0001032975-21-000034:notes:21]

[0001032975-21-000045:notes:22]
As of September 30, 2021, the Company offers the 2006 Employee Share Purchase Plan (Non-U.S.), as amended and restated, the 1996 Employee Share Purchase Plan (U.S.), as amended and restated, the 2006 Stock Incentive Plan, as amended and restated, and the 2012 Stock Inducement Equity Plan. Shares issued to employees as a result of purchases or exercises under these plans are generally issued from shares held in treasury stock.

[0001032975-21-000045:notes:23]
The following table summarizes the share-based compensation expense and total income tax benefit recognized for share-based awards for the three and six months ended September 30, 2021 and 2020 (in thousands):

[0001032975-21-000045:notes:24]
|  |  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Cost of goods sold |  | $ | 2,102 |  |  | $ | 1,772 |  |  | $ | 3,471 |  |  | $ | 3,172 |  |
| Marketing and selling |  | 9,758 |  |  | 10,377 |  |  | 18,288 |  |  | 19,169 |  |
| Research and development |  | 4,724 |  |  | 3,763 |  |  | 9,785 |  |  | 6,866 |  |
| General and administrative |  | 7,438 |  |  | 8,873 |  |  | 16,129 |  |  | 15,693 |  |
| Total share-based compensation expense |  | 24,022 |  |  | 24,785 |  |  | 47,673 |  |  | 44,900 |  |
| Income tax benefit |  | (3,285) |  |  | (3,958) |  |  | (19,879) |  |  | (12,069) |  |
| Total share-based compensation expense, net of income tax benefit |  | $ | 20,737 |  |  | $ | 20,827 |  |  | $ | 27,794 |  |  | $ | 32,831 |  |

[0001032975-21-000045:notes:25]
[same as prior period, unchanged from 0001032975-21-000034:notes:25]

[0001032975-21-000045:notes:26]
As of September 30, 2021 and 2020, the balance of capitalized share-based compensation included in inventory was $1.3 million and $1.3 million, respectively.

[0001032975-21-000045:notes:27]
[same as prior period, unchanged from 0001032975-21-000034:notes:27]

[0001032975-21-000045:notes:28]
Certain of the Company’s subsidiaries sponsor defined benefit pension plans or non-retirement post-employment benefits covering substantially all of their employees. Benefits are provided based on employees’ years of service and earnings, or in accordance with applicable employee benefit regulations. The Company’s practice is to fund amounts sufficient to meet the requirements set forth in the applicable employee benefit and tax regulations. The costs recorded of $3.3 million and $2.7 million for the three months ended September 30, 2021 and 2020, respectively, and $6.6 million and $5.4 million for the six months ended September 30, 2021 and 2020, respectively, were primarily related to service costs.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001032975-21-000045:notes:29]
[same as prior period, unchanged from 0001032975-21-000034:notes:29]

[0001032975-21-000045:notes:30]
[same as prior period, unchanged from 0001032975-21-000034:notes:30]

[0001032975-21-000045:notes:31]
The income tax provision for the three months ended September 30, 2021 was $33.5 million based on an effective income tax rate of 19.3% of pre-tax income, compared to an income tax provision of $56.3 million based on an effective income tax rate of 17.4% of pre-tax income for the three months ended September 30, 2020.  The income tax provision for the six months ended September 30, 2021 was $58.4 million based on an effective income tax rate of 15.2% of pre-tax income, compared to an income tax provision of $70.3 million based on an effective income tax rate of 17.2% of pre-tax income for the six months ended September 30, 2020.

[0001032975-21-000045:notes:32]
The change in the effective income tax rate for the three and six months ended September 30, 2021, compared to the same periods ended September 30, 2020 was primarily due to the mix of income and losses in the various tax jurisdictions in which the Company operates. There were discrete tax benefits of $0.6 million and $0.5 million from the recognition of excess tax benefits in the United States and reversal of uncertain tax positions from the expiration of statutes of limitations, respectively, in the three-month period ended September 30, 2021, compared with $0.8 million and $0.5 million, respectively, in the three-month period ended September 30, 2020.  There were discrete tax benefits of $14.3 million and $1.5 million from the recognition of excess tax benefits in the United States and the reversal of uncertain tax positions from the expiration of statutes of limitations, respectively, in the six-month period ended September 30, 2021, compared with $5.8 million and $1.5 million, respectively, in the six-month period ended September 30, 2020.

[0001032975-21-000045:notes:33]
As of September 30, 2021 and March 31, 2021, the total amount of unrecognized tax benefits due to uncertain tax positions was $170.2 million and $160.3 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-21-000045:notes:34]
As of September 30, 2021 and March 31, 2021, the Company had $67.7 million and $59.2 million, respectively, in non-current income taxes payable including interest and penalties, related to the Company's income tax liability for uncertain tax positions.

[0001032975-21-000045:notes:35]
The Company recognizes interest and penalties related to unrecognized tax positions in the income tax provision. As of September 30, 2021 and March 31, 2021, the Company had $5.5 million and $4.9 million, respectively, of accrued interest and penalties related to uncertain tax positions in non-current income taxes payable.

[0001032975-21-000045:notes:36]
Although the Company has adequately provided for uncertain tax positions, the provisions related to these positions may change as revised estimates are made or the underlying matters are settled or otherwise resolved. During fiscal year 2022, the Company continues to review its tax positions and provide for or reverse unrecognized tax benefits as they arise. During the next twelve months, it is reasonably possible that the amount of unrecognized tax benefits could increase or decrease significantly due to changes in tax law in various jurisdictions, new tax 
audits and changes in the U.S. dollar as compared to other currencies. Excluding these factors, uncertain tax positions may decrease by as much as $4.9 million from the lapse of the statutes of limitations in various jurisdictions during the next twelve months.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001032975-21-000045:notes:37]
[same as prior period, unchanged from 0001032975-21-000034:notes:37]

[0001032975-21-000045:notes:38]
The following table presents the components of certain balance sheet asset amounts as of September 30 and March 31, 2021 (in thousands):

[0001032975-21-000045:notes:39]
|  |  | September 30, 2021 |  | March 31, 2021 |
| Accounts receivable, net: |  |  |  |  |
| Accounts receivable |  | $ | 1,034,726 |  |  | $ | 867,868 |  |
| Allowance for doubtful accounts |  | (249) |  |  | (1,161) |  |
| Allowance for sales returns |  | (10,857) |  |  | (14,438) |  |
| Allowance for cooperative marketing arrangements |  | (64,216) |  |  | (43,276) |  |
| Allowance for customer incentive programs |  | (94,413) |  |  | (76,200) |  |
| Allowance for pricing programs |  | (136,917) |  |  | (120,568) |  |
|  |  | $ | 728,074 |  |  | $ | 612,225 |  |
| Inventories: |  |  |  |  |
| Raw materials |  | $ | 205,991 |  |  | $ | 146,886 |  |
| Finished goods |  | 621,719 |  |  | 514,230 |  |
|  |  | $ | 827,710 |  |  | $ | 661,116 |  |
| Other current assets: |  |  |  |  |
| Value-added tax receivables |  | $ | 79,381 |  |  | $ | 67,710 |  |
| Prepaid expenses and other assets |  | 87,350 |  |  | 67,940 |  |
|  |  | $ | 166,731 |  |  | $ | 135,650 |  |
| Property, plant and equipment, net: |  |  |  |  |
| Property, plant and equipment at cost |  | $ | 454,417 |  |  | $ | 417,520 |  |
| Accumulated depreciation and amortization |  | (342,792) |  |  | (303,460) |  |
|  |  | $ | 111,625 |  |  | $ | 114,060 |  |
| Other assets: |  |  |  |  |
| Deferred tax assets |  | $ | 204,655 |  |  | $ | 210,888 |  |
| Right-of-use assets |  | 41,234 |  |  | 31,169 |  |
| Trading investments for deferred compensation plan |  | 28,375 |  |  | 24,809 |  |
| Investments in privately held companies |  | 42,749 |  |  | 43,402 |  |
| Other assets |  | 14,857 |  |  | 13,980 |  |
|  |  | $ | 331,870 |  |  | $ | 324,248 |  |

[0001032975-21-000045:notes:40]
The following table presents the components of certain balance sheet liability amounts as of September 30 and March 31, 2021 (in thousands):

[0001032975-21-000045:notes:41]
|  |  | September 30, 2021 |  | March 31, 2021 |
| Accrued and other current liabilities: |  |  |  |  |
| Accrued customer marketing, pricing and incentive programs |  | $ | 208,207 |  |  | $ | 185,394 |  |
| Accrued personnel expenses |  | 113,818 |  |  | 173,360 |  |
| VAT payable |  | 61,441 |  |  | 50,620 |  |
| Accrued sales return liability |  | 45,064 |  |  | 43,178 |  |
| Accrued payables - non-inventory |  | 36,736 |  |  | 52,392 |  |
| Warranty accrual |  | 34,646 |  |  | 33,228 |  |
| Income taxes payable |  | 11,954 |  |  | 131,408 |  |
| Operating lease liability |  | 13,754 |  |  | 13,101 |  |
| Contingent consideration |  | 10,570 |  |  | 6,967 |  |
| Other current liabilities |  | 173,688 |  |  | 168,969 |  |
|  |  | $ | 709,878 |  |  | $ | 858,617 |  |
| Other non-current liabilities: |  |  |  |  |
| Employee benefit plan obligations |  | $ | 73,534 |  |  | $ | 72,321 |  |
| Obligation for deferred compensation plan |  | 28,375 |  |  | 24,809 |  |
| Operating lease liability |  | 29,940 |  |  | 21,319 |  |
| Warranty accrual |  | 14,527 |  |  | 15,604 |  |
| Contingent consideration |  | 3,971 |  |  | — |  |
| Deferred tax liability |  | 1,679 |  |  | 1,679 |  |
| Other non-current liabilities |  | 3,206 |  |  | 3,770 |  |
|  |  | $ | 155,232 |  |  | $ | 139,502 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001032975-21-000045:notes:42]
[same as prior period, unchanged from 0001032975-21-000034:notes:42]

[0001032975-21-000045:notes:43]
[same as prior period, unchanged from 0001032975-21-000034:notes:43]

[0001032975-21-000045:notes:44]
[same as prior period, unchanged from 0001032975-21-000034:notes:44]

[0001032975-21-000045:notes:45]
[same as prior period, unchanged from 0001032975-21-000034:notes:45]

[0001032975-21-000045:notes:46]
[same as prior period, unchanged from 0001032975-21-000034:notes:46]

[0001032975-21-000045:notes:47]
[same as prior period, unchanged from 0001032975-21-000034:notes:47]

[0001032975-21-000045:notes:48]
|  |  | September 30, 2021 |  | March 31, 2021 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Level 1 |  | Level 2 |  | Level 3 |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 402,219 |  |  | $ | — |  |  | $ | — |  |  | $ | 669,759 |  |  | $ | — |  |  | $ | — |  |
| Trading investments for deferred compensation plan included in other assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 63 |  |  | $ | — |  |  | $ | — |  |  | $ | 31 |  |  | $ | — |  |  | $ | — |  |
| Common stock |  | 1,850 |  |  | — |  |  | — |  |  | 1,569 |  |  | — |  |  | — |  |
| Money market funds |  | 7,661 |  |  | — |  |  | — |  |  | 6,734 |  |  | — |  |  | — |  |
| Mutual funds |  | 18,801 |  |  | — |  |  | — |  |  | 16,475 |  |  | — |  |  | — |  |
| Total of trading investments for deferred compensation plan |  | $ | 28,375 |  |  | $ | — |  |  | $ | — |  |  | $ | 24,809 |  |  | $ | — |  |  | $ | — |  |
| Currency exchange derivative assetsincluded in other current assets |  | $ | — |  |  | $ | 2,153 |  |  | $ | — |  |  | $ | — |  |  | $ | 5,452 |  |  | $ | — |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Contingent consideration for business acquisition included in accrued and other current liabilities |  | $ | — |  |  | $ | — |  |  | $ | 10,032 |  |  | $ | — |  |  | $ | — |  |  | $ | 6,430 |  |
| Contingent consideration for business acquisition included in other non-current liabilities |  | $ | — |  |  | $ | — |  |  | $ | 3,971 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Currency exchange derivative liabilitiesincluded in accrued and other current liabilities |  | $ | — |  |  | $ | 109 |  |  | $ | — |  |  | $ | — |  |  | $ | 100 |  |  | $ | — |  |

[0001032975-21-000045:notes:49]
The following table summarizes the change in the fair value of the Company's contingent consideration balance during the six months ended September 30, 2021 and 2020 (in thousands):

[0001032975-21-000045:notes:50]
|  | Six Months EndedSeptember 30, |
|  | 2021 |  | 2020 |
| Beginning of the period | $ | 6,967 |  |  | $ | 23,284 |  |
| Fair value of contingent consideration upon acquisition (1) | 9,973 |  |  | — |  |
| Change in fair value of contingent consideration | (2,399) |  |  | 5,716 |  |
| End of the period (2) | $ | 14,541 |  |  | $ | 29,000 |  |

[0001032975-21-000045:notes:51]
[same as prior period, unchanged from 0001032975-21-000034:notes:51]

[0001032975-21-000045:notes:52]
(2) As of June 30, 2020, the earn-out period was completed in connection with our acquisition of General Workings, Inc. ("Streamlabs") (discussed below). The earn-out payment of $29.0 million was based on the actual net sales of Streamlabs services during the earn-out period and was no longer subject to fair value measurement and was accordingly transferred out of Level 3. During the third quarter of fiscal year 2021, $28.5 million of the contingent consideration was transferred from other current liabilities to equity upon settlement of the contingent consideration through the issuance of shares out of treasury stock. The remaining $0.5 million is held back in escrow for claims made against the escrow and for the payment of taxes.

[0001032975-21-000045:notes:53]
[same as prior period, unchanged from 0001032975-21-000034:notes:53]

[0001032975-21-000045:notes:54]
The marketable securities for the Company's deferred compensation plan were recorded at a fair value of $28.4 million and $24.8 million, as of September 30, 2021 and March 31, 2021, respectively, based on quoted market prices. Quoted market prices are observable inputs that are classified as Level 1 within the fair value

[0001032975-21-000045:notes:55]
hierarchy. Unrealized gains (losses) related to trading securities for the three and six months ended September 30, 2021 and 2020 were not material and are included in other income, net in the Company's condensed consolidated statements of operations.

[0001032975-21-000045:notes:56]
[same as prior period, unchanged from 0001032975-21-000034:notes:56]

[0001032975-21-000045:notes:57]
On May 19, 2021, the Company made an immaterial technology acquisition. The contingent consideration for business acquisition arising from the immaterial technology acquisition represents the future potential earn-out payments of up to $10.0 million payable in cash only upon the achievement of three technical development milestones required to be completed as of December 31, 2021, June 30, 2022, and June 30, 2023. The fair value of the contingent amount was determined using a probability-weighted expected payment model and discounted at the estimated cost of debt.

[0001032975-21-000045:notes:58]
[same as prior period, unchanged from 0001032975-21-000034:notes:58]

[0001032975-21-000045:notes:59]
The fair value of the earn-out as of the Mevo Acquisition Date was $3.4 million which was determined by using a Black-Scholes-Merton valuation model to calculate the probability of the earn-out threshold being met, times the value of the earn-out payment, and discounted at the risk-free rate. The valuation includes significant assumptions and unobservable inputs such as the projected sales of Mevo over the earn-out period, risk-free rate, and the net sales volatility. Projected sales are based on the Company's internal projections, including analysis of the target market and historical sales of Mevo products. The fair value of the contingent consideration decreased to $1.0 million as of September 30, 2021 from $3.4 million as of March 31, 2021.

[0001032975-21-000045:notes:60]
On January 4, 2021, the Company made an immaterial technology acquisition. The contingent consideration for business acquisition arising from the immaterial technology acquisition represents the future potential earn-out payments of up to $3.0 million payable in cash upon the achievement of two technical development milestones required to be completed as of December 31, 2021 and March 31, 2022. The fair value of the contingent amount was determined using a probability-weighted expected payment model and discounted at the estimated cost of debt.

[0001032975-21-000045:notes:61]
On October 31, 2019, the Company acquired all of the equity interests of General Workings, Inc. (Streamlabs). In connection with the acquisition of Streamlabs, the Company agreed to pay a total earn-out payment of up to $29.0 million, payable in stock, only upon the achievement of certain net revenues for the period beginning on January 1, 2020 and ending on June 30, 2020.  The fair value was increased by $5.7 million to $29.0 million as of June 30, 2020, based on actual sales. As of June 30, 2020, the earn-out period was completed, and was no longer subject to fair value measurement. During the third quarter of 2021, $28.5 million of the contingent consideration was transferred from other current liabilities to equity upon settlement of the contingent consideration through the issuance of shares out of treasury stock. The remaining amount of $0.5 million is held back in escrow for claims made against the escrow and for the payment of taxes.

[0001032975-21-000045:notes:62]
[same as prior period, unchanged from 0001032975-21-000034:notes:62]

[0001032975-21-000045:notes:63]
[same as prior period, unchanged from 0001032975-21-000034:notes:63]

[0001032975-21-000045:notes:64]
The Company has certain non-marketable investments included in other assets that are accounted for under the equity method of accounting, with a carrying value of $40.1 million and $40.7 million as of September 30, 2021 and March 31, 2021, respectively. Unrealized gains (losses) related to equity investments for the three and six months ended September 30, 2021 and 2020 were not material and are included in other income, net in the Company's condensed consolidated statements of operations. There was no impairment of these assets during the three and six months ended September 30, 2021 or 2020.

[0001032975-21-000045:notes:65]
[same as prior period, unchanged from 0001032975-21-000034:notes:65]

[0001032975-21-000045:notes:66]
Financial Assets.  The Company has certain investments without readily determinable fair values due to the absence of quoted market prices, the inherent lack of liquidity, and the fact that inputs used to measure fair value are unobservable and require management's judgment. When certain events or circumstances indicate that impairment may exist, the Company revalues the investments using various assumptions, including the financial metrics and ratios of comparable public companies. The carrying value is also adjusted for observable price changes with a same or similar security from the same issuer. The amount of these investments included in other assets was immaterial as of September 30, 2021 and March 31, 2021. There was no impairment of these assets during the three and six months ended September 30, 2021 or 2020.

[0001032975-21-000045:notes:67]
Non-Financial Assets.  Goodwill, intangible assets, and property, plant and equipment, are not required to be measured at fair value on a recurring basis. However, if certain triggering events occur (or tested at least annually for goodwill) such that a non-financial instrument is required to be evaluated for impairment and an impairment is recorded to reduce the non-financial instrument's carrying value to the fair value as a result of such triggering events, the non-financial assets and liabilities are measured at fair value for the period such triggering events occur. There was no impairment of these assets during the three and six months ended September 30, 2021 or 2020.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001032975-21-000045:notes:68]
[same as prior period, unchanged from 0001032975-21-000034:notes:68]

[0001032975-21-000045:notes:69]
Under certain agreements with the respective counterparties to the Company’s derivative contracts, subject to applicable requirements, the Company is allowed to net settle transactions of the same type with a single net amount payable by one party to the other. However, the Company presents its derivative assets and derivative liabilities on a gross basis on the condensed consolidated balance sheets as of September 30, 2021 and March 31, 2021.

[0001032975-21-000045:notes:70]
The fair value of the Company’s derivative instruments was not material as of September 30, 2021 or March 31, 2021. The amount of gain (loss) recognized on derivatives not designated as hedging instruments was not material in all periods presented herein. The following table presents the amounts of gains (losses) on the Company’s derivative instruments designated as hedging instruments and their locations on its condensed consolidated statements of operations and condensed consolidated statements of comprehensive income for the three and six months ended September 30, 2021 and 2020 (in thousands):

[0001032975-21-000045:notes:71]
|  |  | Three Months EndedSeptember 30, |
|  |  | Amount of Gain (Loss)Deferred as a Component of AccumulatedOther Comprehensive Loss |  | Amount of Loss (Gain)Reclassified from Accumulated Other Comprehensive Loss to Costs of Goods Sold |  |  |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |  |  |  |  |
| Cash flow hedges |  | $ | 2,132 |  |  | $ | (1,059) |  |  | $ | (1,314) |  |  | $ | 1,969 |  |  |  |  |  |
|  |  | Six Months EndedSeptember 30, |
|  |  | Amount of Gain (Loss)Deferred as a Component of AccumulatedOther Comprehensive Loss |  | Amount of Loss (Gain)Reclassified from Accumulated Other Comprehensive Loss to Costs of Goods Sold |  |  |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |  |  |  |  |
| Cash flow hedges |  | $ | 2,662 |  |  | $ | (3,426) |  |  | $ | (1,908) |  |  | $ | 1,639 |  |  |  |  |  |

[0001032975-21-000045:notes:72]
[same as prior period, unchanged from 0001032975-21-000034:notes:72]

[0001032975-21-000045:notes:73]
The Company enters into cash flow hedge contracts to protect against exchange rate exposure of forecasted inventory purchases. These hedging contracts mature within four months. Gains and losses in the fair value of the effective portion of the hedges are deferred as a component of accumulated other comprehensive loss until the hedged inventory purchases are sold, at which time the gains or losses are reclassified to cost of goods sold. Cash flows from such hedges are classified as operating activities in the condensed consolidated statements of cash flows. Hedging relationships are discontinued when hedging contract is no longer eligible for hedge accounting, or is sold, terminated or exercised, or when Company removes hedge designation for the contract. Gains and losses in the fair value of the effective portion of the discontinued hedges continue to be reported in accumulated other comprehensive loss until the hedged inventory purchases are sold, unless it is probable that the forecasted inventory purchases will not occur by the end of the originally specified time period or within an additional two-month period of time thereafter. In all periods presented herein, there have been no forecasted inventory purchases that were probable to not occur by the end of the originally specified time period or within an additional two-month period of time thereafter. The notional amounts of foreign currency exchange forward contracts outstanding related to forecasted inventory purchases were $154.5 million as of September 30, 2021 and $164.5 million as of March 31, 2021. The Company had $4.5 million of net gains related to its cash flow hedges included in accumulated other comprehensive loss as of September 30, 2021, which will be reclassified into earnings within the next 12 months.

[0001032975-21-000045:notes:74]
[same as prior period, unchanged from 0001032975-21-000034:notes:74]

[0001032975-21-000045:notes:75]
The Company also enters into foreign currency exchange forward and swap contracts to reduce the short-term effects of currency exchange rate fluctuations on certain receivables or payables denominated in currencies other than the functional currencies of its subsidiaries. These contracts generally mature within one month. The primary risk managed by using forward and swap contracts is the currency exchange rate risk. The gains or losses on these contracts are recognized in other income, net in the condensed consolidated statements of operations based on the changes in fair value. The notional amounts of these contracts outstanding as of September 30, 2021 and March 31, 2021 were $164.6 million and $123.8 million, respectively. Open forward and swap contracts outstanding as of September 30, 2021 and March 31, 2021 consisted of contracts in Mexican Pesos, Japanese Yen, Canadian Dollars, Taiwanese Dollars, and Australian Dollars to be settled at future dates at pre-determined exchange rates. Open forward and swap contracts outstanding as of September 30, 2021 additionally consisted of contracts in Chinese Renminbi and Brazilian Real to be settled at future dates at pre-determined exchange rates, which were primarily attributable to the increase in the notional amounts outstanding as of September 30, 2021 compared to March 31, 2021.

[0001032975-21-000045:notes:76]
[same as prior period, unchanged from 0001032975-21-000034:notes:76]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001032975-21-000045:notes:77]
Goodwill and Other Intangible Assets
The Company conducts its impairment analysis of goodwill annually at December 31 and as necessary, if changes in facts and circumstances indicate that it is more likely than not that the fair value of the Company’s reporting unit may be less than its carrying amount. There have been no events or circumstances during the three months ended September 30, 2021 that have required the Company to perform an interim assessment of goodwill.

[0001032975-21-000045:notes:78]
The following table summarizes the activities in the Company’s goodwill balance during the six months ended September 30, 2021 (in thousands):

[0001032975-21-000045:notes:79]
| As of March 31, 2021 |  | $ | 429,604 |  |
| Acquisition |  | 20,721 |  |
| Effects of foreign currency translation |  | (968) |  |
| As of September 30, 2021 |  | $ | 449,357 |  |

[0001032975-21-000045:notes:80]
On May 19, 2021, the Company made an immaterial technology acquisition for a total cash consideration of $25.6 million, including up to $10.0 million earn-out payable in cash upon the achievement of three technical development milestones required to be completed as of December 31, 2021, June 30, 2022, and June 30, 2023,

[0001032975-21-000045:notes:81]
which was accounted for using the acquisition method. The Company retained 6% of the total consideration for the purpose of ensuring seller's representations and warranties.

[0001032975-21-000045:notes:82]
[same as prior period, unchanged from 0001032975-21-000034:notes:81]

[0001032975-21-000045:notes:83]
|  |  | September 30, 2021 |  | March 31, 2021 |
|  |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |
| Trademark and trade names |  | $ | 46,170 |  |  | $ | (28,347) |  |  | $ | 17,823 |  |  | $ | 46,070 |  |  | $ | (25,153) |  |  | $ | 20,917 |  |
| Developed technology |  | 140,407 |  |  | (98,352) |  |  | 42,055 |  |  | 134,406 |  |  | (90,450) |  |  | 43,956 |  |
| Customer contracts/relationships |  | 91,017 |  |  | (50,649) |  |  | 40,368 |  |  | 91,010 |  |  | (44,261) |  |  | 46,749 |  |
| In-process R&D |  | 3,526 |  |  | — |  |  | 3,526 |  |  | 3,526 |  |  | — |  |  | 3,526 |  |
| Effects of foreign currency translation |  | (287) |  |  | 16 |  |  | (271) |  |  | — |  |  | — |  |  | — |  |
| Total |  | $ | 280,833 |  |  | $ | (177,332) |  |  | $ | 103,501 |  |  | $ | 275,012 |  |  | $ | (159,864) |  |  | $ | 115,148 |  |


## us-gaap:DebtDisclosureTextBlock

[0001032975-21-000045:notes:84]
Financing Arrangements

[0001032975-21-000045:notes:85]
The Company had several uncommitted, unsecured bank lines of credit aggregating $191.8 million as of September 30, 2021. There are no financial covenants under these lines of credit with which the Company must comply. As of September 30, 2021, the Company had outstanding bank guarantees of $11.9 million under these lines of credit. There was no borrowing outstanding under these lines of credit as of September 30, 2021 or March 31, 2021.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001032975-21-000045:notes:86]
Commitments and Contingencies

[0001032975-21-000045:notes:87]
Product Warranties

[0001032975-21-000045:notes:88]
Changes in the Company’s warranty liability for the three and six months ended September 30, 2021 and 2020 were as follows (in thousands):

[0001032975-21-000045:notes:89]
|  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Beginning of the period | $ | 49,093 |  |  | $ | 39,450 |  |  | $ | 48,832 |  |  | $ | 40,039 |  |
| Provision | 8,095 |  |  | 9,494 |  |  | 16,541 |  |  | 14,883 |  |
| Settlements | (7,848) |  |  | (7,541) |  |  | (16,163) |  |  | (13,702) |  |
| Effects of foreign currency translation | (167) |  |  | 379 |  |  | (37) |  |  | 562 |  |
| End of the period | $ | 49,173 |  |  | $ | 41,782 |  |  | $ | 49,173 |  |  | $ | 41,782 |  |

[0001032975-21-000045:notes:90]
Indemnifications

[0001032975-21-000045:notes:91]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of September 30, 2021, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

[0001032975-21-000045:notes:92]
The Company also indemnifies its current and former directors and certain of its current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. The Company is unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not limited, the obligations are conditional in nature and the facts and circumstances involved in any situation that might arise are variable.

[0001032975-21-000045:notes:93]
Legal Proceedings

[0001032975-21-000045:notes:94]
From time to time the Company is involved in claims and legal proceedings which arise in the ordinary course of its business. The Company is currently subject to several such claims and a small number of legal proceedings. The Company believes that these matters lack merit and intends to vigorously defend against them. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial position, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company's defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company's business, financial position, cash flows or results of operations in a particular period. Any claims or proceedings against the Company, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain a necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company's business.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001032975-21-000045:notes:95]
[same as prior period, unchanged from 0001032975-21-000034:notes:94]

[0001032975-21-000045:notes:96]
[same as prior period, unchanged from 0001032975-21-000034:notes:95]

[0001032975-21-000045:notes:97]
In May 2020, the Company's Board of Directors approved the 2020 share repurchase program, which authorized the Company to use up to $250.0 million to purchase up to 17.3 million of Logitech shares. The Company's share repurchase program is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Purchases may be started or stopped at any time without prior notice depending on market conditions and other factors. In April 2021, the Company's Board of Directors approved an increase of $750.0 million of the 2020 share repurchase program, to an aggregate amount of $1.0 billion. The Swiss Takeover Board approved this increase and it became effective on May 21, 2021. As of September 30, 2021, $661.0 million is still available for repurchase under the 2020 repurchase program.

[0001032975-21-000045:notes:98]
Dividends

[0001032975-21-000045:notes:99]
During the three and six months ended September 30, 2021, the Company declared and paid cash dividends of CHF 0.87 (USD equivalent of $0.95) per share, totaling $159.4 million on the Company's outstanding shares. During the three and six months ended September 30, 2020, the Company declared and paid cash dividends of CHF 0.79 (USD equivalent of $0.87) per share, totaling $146.7 million on the Company's outstanding shares.

[0001032975-21-000045:notes:100]
Any future dividends will be subject to approval of the Company's shareholders.

[0001032975-21-000045:notes:101]
[same as prior period, unchanged from 0001032975-21-000034:notes:98]

[0001032975-21-000045:notes:102]
[same as prior period, unchanged from 0001032975-21-000034:notes:99]

[0001032975-21-000045:notes:103]
|  |  | Accumulated Other Comprehensive Income (Loss) |
|  |  | CumulativeTranslationAdjustment |  | DefinedBenefitPlan |  | Deferred Hedging Losses |  | Total |
| March 31, 2021 |  | $ | (89,461) |  |  | $ | (23,200) |  |  | $ | 3,746 |  |  | $ | (108,915) |  |
| Other comprehensive income (loss) |  | (2,876) |  |  | 18 |  |  | 754 |  |  | (2,104) |  |
| September 30, 2021 |  | $ | (92,337) |  |  | $ | (23,182) |  |  | $ | 4,500 |  |  | $ | (111,019) |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001032975-21-000045:notes:104]
[same as prior period, unchanged from 0001032975-21-000034:notes:101]

[0001032975-21-000045:notes:105]
[same as prior period, unchanged from 0001032975-21-000034:notes:102]

[0001032975-21-000045:notes:106]
Sales by product categories and sales channels, excluding intercompany transactions, for the three and six months ended September 30, 2021 and 2020 were as follows (in thousands):

[0001032975-21-000045:notes:107]
|  |  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Pointing Devices |  | $ | 189,014 |  |  | $ | 169,121 |  |  | $ | 371,892 |  |  | $ | 289,590 |  |
| Keyboards & Combos |  | 236,272 |  |  | 201,617 |  |  | 454,629 |  |  | 346,977 |  |
| PC Webcams |  | 94,471 |  |  | 102,469 |  |  | 204,389 |  |  | 163,320 |  |
| Tablet & Other Accessories |  | 80,801 |  |  | 83,086 |  |  | 160,073 |  |  | 129,134 |  |
| Gaming (1) |  | 330,777 |  |  | 297,711 |  |  | 666,174 |  |  | 479,614 |  |
| Video Collaboration |  | 231,653 |  |  | 236,704 |  |  | 466,538 |  |  | 366,778 |  |
| Mobile Speakers |  | 39,492 |  |  | 43,581 |  |  | 67,976 |  |  | 72,590 |  |
| Audio & Wearables |  | 98,078 |  |  | 114,275 |  |  | 214,685 |  |  | 185,640 |  |
| Smart Home |  | 5,649 |  |  | 8,573 |  |  | 11,821 |  |  | 15,383 |  |
| Other (2) |  | 60 |  |  | 21 |  |  | 148 |  |  | 26 |  |
| Total Sales |  | $ | 1,306,267 |  |  | $ | 1,257,158 |  |  | $ | 2,618,325 |  |  | $ | 2,049,052 |  |

[0001032975-21-000045:notes:108]
[same as prior period, unchanged from 0001032975-21-000034:notes:105]

[0001032975-21-000045:notes:109]
[same as prior period, unchanged from 0001032975-21-000034:notes:106]

[0001032975-21-000045:notes:110]
Sales by geographic region (based on the customers’ locations) for the three and six months ended September 30, 2021 and 2020 were as follows (in thousands):

[0001032975-21-000045:notes:111]
|  |  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Americas |  | $ | 541,515 |  |  | $ | 542,319 |  |  | $ | 1,154,081 |  |  | $ | 898,503 |  |
| EMEA |  | 399,452 |  |  | 389,578 |  |  | 757,409 |  |  | 600,349 |  |
| Asia Pacific |  | 365,300 |  |  | 325,261 |  |  | 706,835 |  |  | 550,200 |  |
| Total sales |  | $ | 1,306,267 |  |  | $ | 1,257,158 |  |  | $ | 2,618,325 |  |  | $ | 2,049,052 |  |

[0001032975-21-000045:notes:112]
[same as prior period, unchanged from 0001032975-21-000034:notes:109]

[0001032975-21-000045:notes:113]
The United States and Germany each represented 10% or more of the total consolidated sales for each of the periods presented herein. China represented more than 10% of the total consolidated sales for the three and six months ended September 30, 2021. No other countries represented 10% or more of the Company’s total consolidated sales for the periods presented herein.

[0001032975-21-000045:notes:114]
Switzerland, the Company’s home domicile, represented 3% and 3% of the Company's total consolidated sales for the three and six months ended September 30, 2021, respectively, and represented 3% and 2% of the Company's total consolidated sales for the three and six months ended September 30, 2020, respectively.

[0001032975-21-000045:notes:115]
[same as prior period, unchanged from 0001032975-21-000034:notes:112]

[0001032975-21-000045:notes:116]
[same as prior period, unchanged from 0001032975-21-000034:notes:113]

[0001032975-21-000045:notes:117]
|  |  | September 30, 2021 |  | March 31, 2021 |
| Americas |  | $ | 19,235 |  |  | $ | 20,810 |  |
| EMEA |  | 11,565 |  |  | 8,019 |  |
| Asia Pacific |  | 80,825 |  |  | 85,231 |  |
| Total property, plant and equipment, net |  | $ | 111,625 |  |  | $ | 114,060 |  |

[0001032975-21-000045:notes:118]
Property, plant and equipment, net in the United States and China were $19.0 million and $69.2 million, respectively, as of September 30, 2021, and $20.5 million and $74.0 million, respectively, as of March 31, 2021. No other countries represented 10% or more of the Company’s total consolidated property, plant and equipment, net as of September 30, 2021 or March 31, 2021. Property, plant and equipment, net in Switzerland, the Company’s home domicile, were $9.1 million and $5.7 million as of September 30, 2021 and March 31, 2021, respectively.
