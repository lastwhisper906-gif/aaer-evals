# LOGI MD&A — 0001032975-20-000033


## mdna

[0001032975-20-000033:mdna:1]
[same as prior period, unchanged from 0001032975-20-000005:mdna:1]

[0001032975-20-000033:mdna:2]
[same as prior period, unchanged from 0001032975-20-000005:mdna:2]

[0001032975-20-000033:mdna:3]
[same as prior period, unchanged from 0001032975-20-000005:mdna:3]

[0001032975-20-000033:mdna:4]
Logitech is a world leader in designing, manufacturing and marketing products that help connect people to digital and cloud experiences. More than 35 years ago, Logitech created products to improve experiences around the personal computer (PC) platform, and today it is a multi-brand, multi-category company designing products that enable better experiences consuming, sharing and creating digital content such as computing, gaming, video and music, whether it is on a computer, mobile device or in the cloud. Logitech's brands include Logitech, Logitech G, ASTRO Gaming, Streamlabs, Ultimate Ears, Jaybird, and Blue Microphones. Our Company's website is www.logitech.com.

[0001032975-20-000033:mdna:5]
23

[0001032975-20-000033:mdna:6]
Our products participate in five large market opportunities: Creativity & Productivity, Gaming, Video Collaboration, Music and Smart Home. We sell our products to a broad network of domestic and international customers, including direct sales to retailers and e-tailers, and indirect sales through distributors. Our worldwide channel network includes consumer electronics distributors, retailers, mass merchandisers, specialty stores, computer and telecommunications stores, value-added resellers and online merchants.

[0001032975-20-000033:mdna:7]
From time to time, we may seek to partner with or acquire when appropriate companies that have products, personnel, and technologies that complement our strategic direction. We continually review our product offerings and our strategic direction in light of our profitability targets, competitive conditions, changing consumer trends and the evolving nature of the interface between the consumer and the digital world.

[0001032975-20-000033:mdna:8]
Impacts of COVID-19 to Our Business

[0001032975-20-000033:mdna:9]
In March 2020, the World Health Organization declared the outbreak of a novel coronavirus ("COVID-19") as a pandemic, which continues to spread throughout the world. The spread of COVID-19 has caused public health officials to recommend precautions to mitigate the spread of the virus and, in certain markets in which we operate, government authorities have issued orders that require the closure of non-essential businesses and people to be quarantined or to shelter-at-home. The COVID-19 pandemic has significantly curtailed global economic activity, caused significant volatility and disruption in global financial and commercial markets, and is likely to lead to recessionary pressures for an indeterminate amount of time. We are conducting our business with substantial modifications, such as employee work locations and remote work among other changes. We are continuing to actively monitor the situation and may take further actions that could alter our business operations as may be required by federal, state or local authorities in the countries in which we operate, or that we determine are in the best interest of our employees, customers, partners, suppliers or shareholders. It is not clear what the potential effects of COVID-19 or any such modifications or alterations may have on our business, results of operations, financial operations, financial condition and stock price.

[0001032975-20-000033:mdna:10]
During February 2020, following the initial outbreak of COVID-19 in China, we experienced disruptions to our manufacturing, supply chain and logistics services, resulting in temporary inventory declines and an increase in logistics costs. We continued to see disruptions to our supply chain and logistics services, inventory constraints and increased logistics costs during the remainder of the fourth quarter of fiscal year 2020 and the first quarter of fiscal year 2021 as we attempted to address the effects of COVID-19, including health-related issues, changing regulations, and increased demand for and depleted inventories of some of our products. At the same time, due to the ongoing shelter-at-home requirements or recommendations in many countries, there was high demand and consumption of certain of our products that led to increased sales and operating income. While it is not yet clear how long the positive demand dynamics will continue, we expect the increased logistics costs and other adverse effects on our gross margins from COVID-19 to continue through the remainder of fiscal year 2021. It is difficult to predict the progression, the duration and all of the effects of COVID-19, when business closure and shelter-at-home guidelines may be eased or lifted, and how consumer demand, inventory and logistical effects and costs may evolve over time, or the impact on our future sales and results of operations. Some of this impact will undoubtedly occur over multiple financial periods and may have a lag effect between periods, such as what we are able to manufacture in one period affecting sales, channel inventory or logistics costs in subsequent periods. The full extent of the impact of COVID-19 on our business and our operational and financial performance is currently uncertain and will depend on many factors outside our control. For additional information, see "Liquidity and Capital resources" below and "Item IA: Risk Factors", including under the caption "The full effect of the COVID-19 pandemic is uncertain and cannot be predicted, and the Company's business, results of operations and financial condition could be adversely affected by the COVID-19 pandemic."

[0001032975-20-000033:mdna:11]
[same as prior period, unchanged from 0001032975-20-000005:mdna:8]

[0001032975-20-000033:mdna:12]
Our total sales for the three months ended June 30, 2020 increased 23%, compared to the three months ended June 30, 2019, due to stronger sales across all regions and several of our product categories from increased remote work and distance learning set-ups, related to various shelter-at-home mandates. The results of operations for Streamlabs have been included in our consolidated statement of operations from the acquisition date. Streamlabs contributed 2 points to the sales growth during the period.

[0001032975-20-000033:mdna:13]
Our sales for the three months ended June 30, 2020 increased 21%, 18% and 31% in the Americas, EMEA and Asia Pacific, respectively, compared to the same period of the prior fiscal year.

[0001032975-20-000033:mdna:14]
Our gross margin for the three months ended June 30, 2020 increased by 150 basis points to 38.6% from 37.1% for the three months ended June 30, 2019. The increase in gross margin was driven by lower customer incentive programs, favorable product mix and benefits from cost savings and operational efficiencies, partially offset by COVD-19 related costs primarily due to higher logistics operations costs and unfavorable currency exchange rates.

[0001032975-20-000033:mdna:15]
Operating expenses for the three months ended June 30, 2020 were $222.3 million, or 28.1% of sales, compared to $191.5 million, or 29.7% of sales in the same period of the prior fiscal year.

[0001032975-20-000033:mdna:16]
Net income for the three months ended June 30, 2020 was $72.1 million, compared to $45.3 million for the three months ended June 30, 2019.

[0001032975-20-000033:mdna:17]
[same as prior period, unchanged from 0001032975-20-000005:mdna:16]

[0001032975-20-000033:mdna:18]
Our products participate in five large multi-category market opportunities, including Creativity & Productivity, Gaming, Video Collaboration, Music and Smart Home. We see opportunities to deliver growth with products in all these markets. The following discussion represents key trends specific to our market opportunities.

[0001032975-20-000033:mdna:19]
[same as prior period, unchanged from 0001032975-20-000005:mdna:19]

[0001032975-20-000033:mdna:20]
Creativity & Productivity:  New PC shipments remain lackluster but the installed base of PC users remains large. We believe that innovative PC peripherals, such as our mice and keyboards, can renew the PC usage experience and help improve the productivity and engagement of remote work, distance learning, and telemedicine, thus providing growth opportunities. Increasing adoption of various cloud-based applications has led to multiple unique consumer use cases, which we are addressing with our innovative product portfolio and a deep understanding of our customer base. The increasing popularity of streaming and broadcasting, as well as the rising work-from-home trend, provides additional growth opportunities for our webcam products, as well as other products in our portfolio. Smaller mobile computing devices, such as tablets, have created new markets and usage models for peripherals and accessories. We offer a number of products to enhance the use of mobile devices, including a combo backlit keyboard case for the iPad Pro and keyboard folios for other iPad models. Hybrid and distance learning environments have also created demand and growth opportunities for our education tablet keyboards and accessories.

[0001032975-20-000033:mdna:21]
Gaming:  The PC gaming and console gaming platforms continue to show strong structural growth opportunities as online gaming, multi-platform experiences, and esports gain greater popularity and gaming content becomes increasingly more demanding and social particularly as other recreational activities have been curtained or restricted during stay-at-home mandates. The new console refresh cycle during the holiday season of 2020 could drive subsequent growth opportunities over the coming years for our ASTRO family of headsets and controllers. We believe Logitech is well positioned to benefit from the overall gaming market growth. With ASTRO Gaming, we also strengthened our portfolio in adjacent categories, such as the console controller market. Our acquisition of Streamlabs provides a solid platform to deliver recurring services and subscriptions to gamers.

[0001032975-20-000033:mdna:22]
Video Collaboration: The near and long-term structural growth opportunities in the video collaboration market have never been more relevant than in today’s environment, as commercial and consumer adoption of video has seen explosive growth in recent months. Video meetings are on the rise, and companies increasingly want lower-cost, cloud-based solutions that can provide their employees with the ability to work from anywhere. We are continuing our efforts to create and sell innovative products to accommodate the increasing demand from small-size meeting rooms, such as huddle rooms, to medium and large-sized meeting rooms. We are also experiencing significant demand for our enterprise-grade VC webcams and headsets. We will continue to invest in select business-specific products (both hardware and software), targeted product marketing and sales channel development.

[0001032975-20-000033:mdna:23]
Music:  The mobile speaker market has remained soft, and has further weakened as physical retail stores have been recently closed and retail footprint has decreased significantly due to the COVID-19 pandemic. The integration of personal voice assistants has become increasingly competitive in the speaker categories, but the market for third-party, voice-enabled speakers has not yet gained traction. Moreover, the market for mobile speakers appears to be maturing, which led to a decline in Ultimate Ears sales in the past two years. In fiscal year 2020, the wireless headphone industry continued to flourish with strong revenue growth but has slowed in recent months due to physical retail store closures. The largest growth was in true wireless headphones while traditional wireless headphones have declined significantly. Continued growth in the wireless headphone market is expected for the next several years as consumers increasingly adopt wireless headphones over wired headphones. Blue Microphones has experienced strong demand as musicians, performers and streamers increasingly look to entertain and engage with their fans on various online platforms like YouTube, Twitch, and Facebook.

[0001032975-20-000033:mdna:24]
Smart Home:  Our remote Harmony business declined substantially in fiscal year 2020, offset by growth in our Circle 2 family of security cameras. In general, the space is under pressure as the way people consume content is changing and as retail stores have been closed. We will continue to explore other innovative experiences for the Smart Home category.

[0001032975-20-000033:mdna:25]
[same as prior period, unchanged from 0001032975-20-000005:mdna:25]

[0001032975-20-000033:mdna:26]
We have historically experienced higher sales in our third fiscal quarter ending December 31, compared to other fiscal quarters in our fiscal year, primarily due to the increased consumer demand for our products during the year-end holiday buying season and year-end spending by enterprises. Additionally, new product introductions and business acquisitions can significantly impact sales, product costs and operating expenses. Product introductions can also impact our sales to distribution channels as these channels are filled with new product inventory following a product introduction, and often channel inventory of an earlier model product declines as the next related major product launch approaches. Sales can also be affected when consumers and distributors anticipate a product introduction or changes in business circumstances. However, neither historical seasonal patterns nor historical patterns of product introductions should be considered reliable indicators of our future pattern of product introductions, future sales or financial performance. Furthermore, cash flow is correspondingly lower in the first half of the fiscal year as we typically build inventories in advance for the third quarter and we pay an annual dividend following our Annual General Meeting, which is typically in September.

[0001032975-20-000033:mdna:27]
[same as prior period, unchanged from 0001032975-20-000005:mdna:27]

[0001032975-20-000033:mdna:28]
As we described in our Annual Report on Form 10-K for the fiscal year ended March 31, 2020, the canton of Vaud in Switzerland enacted TRAF on March 10, 2020, effective as of January 1, 2020. Our cash tax payments have increased in Switzerland beginning in fiscal year 2020 as a result of our transition out of our longstanding tax ruling from the canton of Vaud.

[0001032975-20-000033:mdna:29]
Critical Accounting Policies and Estimates

[0001032975-20-000033:mdna:30]
The preparation of financial statements and related disclosures in conformity with GAAP and pursuant to the rules and regulations of the SEC, requires us to make judgments, estimates and assumptions that affect the reported amounts of assets, liabilities, revenue and expenses, and related disclosures of contingent assets and liabilities. We base our assumptions, judgments and estimates on historical experience and various other factors that we believe to be reasonable under the circumstances. Actual results could differ materially from these estimates under different assumptions or conditions. On a regular basis, we evaluate our assumptions, judgments and estimates. We also discuss our critical accounting policies and estimates with the Audit Committee of the Board of Directors.

[0001032975-20-000033:mdna:31]
We believe that the assumptions, judgments and estimates involved in the accounting for accruals for customer incentives, cooperative marketing, and pricing programs (Customer Programs) and related breakage when appropriate, accrued sales return liability, inventory valuation and uncertain tax positions have the greatest potential impact on our condensed consolidated financial statements. These areas are key components of our results of operations and are based on complex rules requiring us to make judgments and estimates and consequently, we consider these to be our critical accounting policies. Historically, our assumptions, judgments and estimates relative to our critical accounting policies have not differed materially from actual results.

[0001032975-20-000033:mdna:32]
There have been no material changes in our critical accounting policies and estimates during the three months ended June 30, 2020 compared with the critical accounting policies and estimates disclosed in Management's Discussions and Analysis of Financial Condition and Results of Operations included in our Annual Report on Form 10-K for the fiscal year ended March 31, 2020.

[0001032975-20-000033:mdna:33]
[same as prior period, unchanged from 0001032975-20-000005:mdna:35]

[0001032975-20-000033:mdna:34]
[same as prior period, unchanged from 0001032975-20-000005:mdna:36]

[0001032975-20-000033:mdna:35]
[same as prior period, unchanged from 0001032975-20-000005:mdna:37]

[0001032975-20-000033:mdna:36]
[same as prior period, unchanged from 0001032975-20-000005:mdna:38]

[0001032975-20-000033:mdna:37]
Given our global sales presence and the reporting of our financial results in U.S. Dollars, our financial results could be affected by shifts in currency exchange rates. See “Results of Operations” for information on the effect of currency exchange rate results on our sales. If the U.S. Dollar appreciates or depreciates in comparison to other currencies in future periods, this will affect our results of operations in future periods as well.

[0001032975-20-000033:mdna:38]
[same as prior period, unchanged from 0001032975-20-000005:mdna:40]

[0001032975-20-000033:mdna:39]
[same as prior period, unchanged from 0001032975-20-000005:mdna:41]

[0001032975-20-000033:mdna:40]
[same as prior period, unchanged from 0001032975-20-000005:mdna:42]

[0001032975-20-000033:mdna:41]
Although our financial results are reported in U.S. Dollars, a portion of our sales was generated in currencies other than the U.S. Dollar, such as the Euro, Chinese Renminbi, Japanese Yen, Canadian Dollar, Taiwan New Dollar, British Pound and Australian Dollar. During the three months ended June 30, 2020, approximately 48% of our sales were denominated in currencies other than the U.S. Dollar.

[0001032975-20-000033:mdna:42]
[same as prior period, unchanged from 0001032975-20-000005:mdna:44]

[0001032975-20-000033:mdna:43]
[same as prior period, unchanged from 0001032975-20-000005:mdna:45]

[0001032975-20-000033:mdna:44]
Our sales in the three months ended June 30, 2020 increased 23% compared to the same period of the prior fiscal year, driven by sales increases in all regions and several of our product categories from increased remote work and distance learning set-ups, as well as from various stay-at-home mandates. Strong growth sales for in Video Collaboration, Gaming, PC Webcams, Keyboards & Combos, Audio PC & Wearables, and Tablet and other Accessories and Keyboards & Combos was partially offset by a decline in sales for Mobile Speakers, Smart Home, and Pointing Devices. If currency exchange rates had been constant in the three months ended June 30, 2020 and 2019, our constant dollar sales growth rate would have been 25%.

[0001032975-20-000033:mdna:45]
[same as prior period, unchanged from 0001032975-20-000005:mdna:47]

[0001032975-20-000033:mdna:46]
The following table presents the change in sales by region for the three months ended June 30, 2020, compared with the three months ended June 30, 2019:

[0001032975-20-000033:mdna:47]
|  |  | Sales Growth Rate |  | Constant DollarSales Growth Rate |
| Americas |  | 21 | % |  | 23 | % |
| EMEA |  | 18 | % |  | 21 | % |
| Asia Pacific |  | 31 | % |  | 33 | % |

[0001032975-20-000033:mdna:48]
[same as prior period, unchanged from 0001032975-20-000005:mdna:50]

[0001032975-20-000033:mdna:49]
The increase in sales in our Americas region was primarily driven by growth in sales for Video Collaboration, Gaming, PC Webcams, and Audio PC & Wearables, partially offset by a decline in sales for Mobile Speakers.

[0001032975-20-000033:mdna:50]
[same as prior period, unchanged from 0001032975-20-000005:mdna:52]

[0001032975-20-000033:mdna:51]
The increase in sales in our EMEA region was primarily driven by growth in sales for PC Webcams, Video Collaboration, and Gaming, partially offset by a decline in sales for Mobile Speakers and Smart Home.

[0001032975-20-000033:mdna:52]
[same as prior period, unchanged from 0001032975-20-000005:mdna:54]

[0001032975-20-000033:mdna:53]
The increase in sales in our Asia Pacific region was primarily driven by growth in sales for PC Webcams, Video Collaboration, Gaming, and Keyboards & Combos, partially offset by a decline in sales for Mobile Speakers.

[0001032975-20-000033:mdna:54]
[same as prior period, unchanged from 0001032975-20-000005:mdna:56]

[0001032975-20-000033:mdna:55]
Sales by product categories for the three months ended June 30, 2020 and 2019 were as follows (Dollars in thousands):

[0001032975-20-000033:mdna:56]
|  |  | Three Months EndedJune 30, |
|  |  | 2020 |  | 2019 |  | Change |
| Pointing Devices |  | $ | 120,469 |  |  | $ | 121,983 |  |  | (1 | )% |
| Keyboards & Combos |  | 145,360 |  |  | 128,679 |  |  | 13 |  |
| PC Webcams |  | 60,851 |  |  | 28,128 |  |  | 116 |  |
| Tablet & Other Accessories |  | 46,048 |  |  | 38,339 |  |  | 20 |  |
| Gaming |  | 181,903 |  |  | 134,515 |  |  | 35 |  |
| Video Collaboration |  | 130,074 |  |  | 73,424 |  |  | 77 |  |
| Mobile Speakers |  | 29,009 |  |  | 50,416 |  |  | (42 | ) |
| Audio & Wearables |  | 71,365 |  |  | 58,624 |  |  | 22 |  |
| Smart Home |  | 6,810 |  |  | 9,864 |  |  | (31 | ) |
| Other (1) |  | 5 |  |  | 253 |  |  | (98 | ) |
| Total sales |  | $ | 791,894 |  |  | $ | 644,225 |  |  | 23 | % |

[0001032975-20-000033:mdna:57]
[same as prior period, unchanged from 0001032975-20-000005:mdna:59]

[0001032975-20-000033:mdna:58]
[same as prior period, unchanged from 0001032975-20-000005:mdna:60]

[0001032975-20-000033:mdna:59]
[same as prior period, unchanged from 0001032975-20-000005:mdna:61]

[0001032975-20-000033:mdna:60]
Our Pointing Devices category comprises PC- and Mac-related mice including trackballs, touchpads and presenters.

[0001032975-20-000033:mdna:61]
Sales of Pointing Devices decreased 1% in the three months ended June 30, 2020, compared to the same period of the prior fiscal year, primarily driven by declines in EMEA and Asia Pacific regions. The decrease was primarily driven by the decrease in sales of presentation tools and corded mice, partially offset by an increase in sales of our cordless mice.

[0001032975-20-000033:mdna:62]
[same as prior period, unchanged from 0001032975-20-000005:mdna:64]

[0001032975-20-000033:mdna:63]
[same as prior period, unchanged from 0001032975-20-000005:mdna:65]

[0001032975-20-000033:mdna:64]
28

[0001032975-20-000033:mdna:65]
Sales of Keyboards & Combos increased 13% in the three months ended June 30, 2020, compared to the same period of the prior fiscal year. The increase was driven by an increase in sales for our cordless keyboards and wireless keyboards/mice combos, partially offset by a decline in sales of our living room keyboard and corded keyboard/mice combos.

[0001032975-20-000033:mdna:66]
[same as prior period, unchanged from 0001032975-20-000005:mdna:67]

[0001032975-20-000033:mdna:67]
[same as prior period, unchanged from 0001032975-20-000005:mdna:68]

[0001032975-20-000033:mdna:68]
PC Webcams sales increased 116% in the three months ended June 30, 2020, compared to the same period of the prior fiscal year. The increase was across all regions and all product types, primarily driven by an increase in sales of our HD Pro Webcam C920, Webcam C60, HD Webcam C615, and Logitech StreamCam partly due to remote work and distance learning.

[0001032975-20-000033:mdna:69]
[same as prior period, unchanged from 0001032975-20-000005:mdna:70]

[0001032975-20-000033:mdna:70]
[same as prior period, unchanged from 0001032975-20-000005:mdna:71]

[0001032975-20-000033:mdna:71]
Sales of Tablet & Other Accessories products increased 20% in the three months ended June 30, 2020, compared to the same period of the prior fiscal year. The increase was primarily driven by the sales of our Rugged Folio keyboard cases for a newer generation of iPads and Slim Folio keyboard for iPad 7th generation, both introduced in the third quarter of fiscal year 2020.

[0001032975-20-000033:mdna:72]
[same as prior period, unchanged from 0001032975-20-000005:mdna:73]

[0001032975-20-000033:mdna:73]
[same as prior period, unchanged from 0001032975-20-000005:mdna:74]

[0001032975-20-000033:mdna:74]
Gaming sales increased 35% for the three months ended June 30, 2020, compared to the same period of the prior fiscal year. The increase was primarily driven by increases in the sales of all our product types, including Streamlabs services as a result of our business combination in the third quarter of fiscal year 2020, except for console gaming controllers.  The decrease in console gaming controllers was primarily driven by decline in the sales of C40 controllers and controller accessories.

[0001032975-20-000033:mdna:75]
[same as prior period, unchanged from 0001032975-20-000005:mdna:76]

[0001032975-20-000033:mdna:76]
Our Video Collaboration category primarily includes Logitech’s ConferenceCams, which combine affordable

[0001032975-20-000033:mdna:77]
[same as prior period, unchanged from 0001032975-20-000005:mdna:78]

[0001032975-20-000033:mdna:78]
Sales of Video Collaboration products increased 77% in the three months ended June 30, 2020, compared to the same period of the prior fiscal year. The increase was primarily driven by the sales of our BRIO 4K Pro Webcam, MeetUp video conferencing camera, Rally Ultra-HD conference camera system, and Pro Webcam Ultra Wide Angle HD Webcam partly due to remote work setups, partially offset by a decline in sales of our BCC950 video conferencing system and older generation products.

[0001032975-20-000033:mdna:79]
[same as prior period, unchanged from 0001032975-20-000005:mdna:80]

[0001032975-20-000033:mdna:80]
[same as prior period, unchanged from 0001032975-20-000005:mdna:81]

[0001032975-20-000033:mdna:81]
[same as prior period, unchanged from 0001032975-20-000005:mdna:82]

[0001032975-20-000033:mdna:82]
Sales of Mobile Speakers decreased 42% for the three months ended June 30, 2020, compared to the same period of the prior fiscal year. The decrease was primarily due to a decrease in sales of our BOOM 3, WONDERBOOM, BOOM 2, and WONDERBOOM 2 mobile speakers, partially offset by an increase in sales from the introduction of our HYPERBOOM speaker in the fourth quarter of fiscal year 2020 and an increase in sales of our MEGABOOM 3 speakers.

[0001032975-20-000033:mdna:83]
[same as prior period, unchanged from 0001032975-20-000005:mdna:84]

[0001032975-20-000033:mdna:84]
[same as prior period, unchanged from 0001032975-20-000005:mdna:85]

[0001032975-20-000033:mdna:85]
Audio & Wearables sales increased 22% for the three months ended June 30, 2020, compared to the same period of the prior fiscal year. The increase was primarily driven by the sales of both our corded and cordless headsets and Blue Microphones products, partially offset by a decline in the sales of our Jaybird traditional wireless products.

[0001032975-20-000033:mdna:86]
[same as prior period, unchanged from 0001032975-20-000005:mdna:87]

[0001032975-20-000033:mdna:87]
[same as prior period, unchanged from 0001032975-20-000005:mdna:88]

[0001032975-20-000033:mdna:88]
Smart Home sales decreased 31% during the three months ended June 30, 2020, compared to the same period of the prior fiscal year. The decrease was primarily driven by an overall decline in sales in our Harmony remote products and our home security products.

[0001032975-20-000033:mdna:89]
[same as prior period, unchanged from 0001032975-20-000005:mdna:91]

[0001032975-20-000033:mdna:90]
Gross profit for the three months ended June 30, 2020 and 2019 was as follows (Dollars in thousands):

[0001032975-20-000033:mdna:91]
|  |  | Three Months EndedJune 30, |
|  |  | 2020 |  | 2019 |  | Change |
| Net sales |  | $ | 791,894 |  |  | $ | 644,225 |  |  | 23 | % |
| Gross profit |  | $ | 305,733 |  |  | $ | 238,976 |  |  | 28 |  |
| Gross margin |  | 38.6 | % |  | 37.1 | % |  |  |

[0001032975-20-000033:mdna:92]
[same as prior period, unchanged from 0001032975-20-000005:mdna:94]

[0001032975-20-000033:mdna:93]
Gross margin increased by 150 basis points for the three months ended June 30, 2020, compared to the same period of the prior fiscal year.  The increase in gross margin was primarily driven by lower customer incentive programs, favorable product mix and benefits from cost savings and operational efficiencies, partially offset by COVD-19 related costs primarily due to higher logistics operations costs and unfavorable currency exchange rates.

[0001032975-20-000033:mdna:94]
[same as prior period, unchanged from 0001032975-20-000005:mdna:95]

[0001032975-20-000033:mdna:95]
Operating expenses for the three months ended June 30, 2020 and 2019 were as follows (Dollars in thousands):

[0001032975-20-000033:mdna:96]
|  |  | Three Months EndedJune 30, |
|  |  | 2020 |  | 2019 |
| Marketing and selling |  | $ | 133,238 |  |  | $ | 123,033 |  |
| % of sales |  | 16.8 | % |  | 19.1 | % |
| Research and development |  | 49,725 |  |  | 42,243 |  |
| % of sales |  | 6.3 | % |  | 6.6 | % |
| General and administrative |  | 29,071 |  |  | 22,159 |  |
| % of sales |  | 3.7 | % |  | 3.4 | % |
| Amortization of intangible assets and acquisition-related costs |  | 4,609 |  |  | 3,596 |  |
| % of sales |  | 0.6 | % |  | 0.6 | % |
| Change in fair value of contingent consideration for business acquisition |  | 5,716 |  |  | — |  |
| % of sales |  | 0.7 | % |  | — | % |
| Restructuring charges (credits), net |  | (53 | ) |  | 478 |  |
| % of sales |  | — | % | (1) | — | % |
| Total operating expenses |  | $ | 222,306 |  |  | $ | 191,509 |  |
| % of sales |  | 28.1 | % |  | 29.7 | % |

[0001032975-20-000033:mdna:97]
[same as prior period, unchanged from 0001032975-20-000005:mdna:98]

[0001032975-20-000033:mdna:98]
[same as prior period, unchanged from 0001032975-20-000005:mdna:99]

[0001032975-20-000033:mdna:99]
[same as prior period, unchanged from 0001032975-20-000005:mdna:100]

[0001032975-20-000033:mdna:100]
During the three months ended June 30, 2020, marketing and selling expenses increased $10.2 million compared to the same period of the prior fiscal year. The increase was primarily driven by higher personnel-related costs due to increased headcount, partially resulting from the Streamlabs acquisition and increased performance-based variable compensation, partially offset by lower marketing related expenses.

[0001032975-20-000033:mdna:101]
[same as prior period, unchanged from 0001032975-20-000005:mdna:102]

[0001032975-20-000033:mdna:102]
[same as prior period, unchanged from 0001032975-20-000005:mdna:103]

[0001032975-20-000033:mdna:103]
During the three months ended June 30, 2020, research and development expenses increased $7.5 million compared to the same period of the prior fiscal year. The increase was primarily driven by higher personnel-related costs due to increased headcount, partially resulting from the Streamlabs acquisition and increased performance-based variable compensation.

[0001032975-20-000033:mdna:104]
[same as prior period, unchanged from 0001032975-20-000005:mdna:105]

[0001032975-20-000033:mdna:105]
[same as prior period, unchanged from 0001032975-20-000005:mdna:106]

[0001032975-20-000033:mdna:106]
31

[0001032975-20-000033:mdna:107]
During the three months ended June 30, 2020, general and administrative expenses increased $6.9 million, compared to the same period of the prior fiscal year. The increase was primarily driven by higher personnel-related costs due to increased headcount and increased share-based compensation.

[0001032975-20-000033:mdna:108]
[same as prior period, unchanged from 0001032975-20-000005:mdna:108]

[0001032975-20-000033:mdna:109]
[same as prior period, unchanged from 0001032975-20-000005:mdna:111]

[0001032975-20-000033:mdna:110]
The increase in amortization of intangible assets during the three months ended June 30, 2020, compared with the same period of the prior fiscal year, was primarily driven by the intangible assets acquired through the Streamlabs acquisition in the third quarter of fiscal year 2020.

[0001032975-20-000033:mdna:111]
Change in Fair Value of Contingent Consideration for Business Acquisition

[0001032975-20-000033:mdna:112]
The change in fair value of contingent consideration was $5.7 million for the three months ended June 30, 2020, primarily due to growth in Streamlabs' net sales and the achievement of the net sales targets during the six-month earn-out period.

[0001032975-20-000033:mdna:113]
[same as prior period, unchanged from 0001032975-20-000005:mdna:117]

[0001032975-20-000033:mdna:114]
Other income (expense), net for the three months ended June 30, 2020 and 2019 was as follows (in thousands):

[0001032975-20-000033:mdna:115]
|  |  | Three Months EndedJune 30, |
|  |  | 2020 |  | 2019 |
| Investment income related to a deferred compensation plan |  | $ | 1,556 |  |  | $ | 589 |  |
| Currency exchange gain, net |  | 57 |  |  | 817 |  |
| Gain on investments |  | 174 |  |  | 211 |  |
| Other |  | 242 |  |  | 244 |  |
| Total |  | $ | 2,029 |  |  | $ | 1,861 |  |

[0001032975-20-000033:mdna:116]
Investment income represents earnings, gains, and losses on trading investments related to a deferred compensation plan offered by one of our subsidiaries.

[0001032975-20-000033:mdna:117]
Currency exchange gain, net relates to balances denominated in currencies other than the functional currency in our subsidiaries, as well as to the sale of currencies, and to gains or losses recognized on currency exchange forward contracts. We do not speculate in currency positions, but we are alert to opportunities to maximize currency exchange gains and minimize currency exchange losses.

[0001032975-20-000033:mdna:118]
[same as prior period, unchanged from 0001032975-20-000005:mdna:123]

[0001032975-20-000033:mdna:119]
The provision for (benefit from) income taxes and effective tax rates for the three months ended June 30, 2020 and 2019 were as follows (Dollars in thousands):

[0001032975-20-000033:mdna:120]
|  |  | Three Months EndedJune 30, |
|  |  | 2020 |  | 2019 |
| Provision for income taxes |  | $ | 14,003 |  |  | $ | 6,536 |  |
| Effective income tax rate |  | 16.3 | % |  | 12.6 | % |

[0001032975-20-000033:mdna:121]
The change in the effective income tax rate for the three months ended June 30, 2020, compared to the same period ended June 30, 2019, was primarily due to the mix of income and losses in the various tax jurisdictions in which we operate.  The Swiss income tax provision in each period represents the income tax provision at the full statutory income tax rate of 13.63%. In the three months ended June 30, 2019 when TRAF was yet to be enacted at the federal and cantonal levels, the transition income tax provision was quantified at the full statutory income tax rate of 13.63% because at the time the canton of Vaud permitted the application of the longstanding tax ruling only through March 31, 2019. There were discrete tax benefits of $5.0 million and $1.0 million from the recognition of excess tax benefits in the United States and reversal of uncertain tax positions from the expiration of statutes of limitations, respectively, in the three-month period ended June 30, 2020, compared with $5.8 million and $1.2 million, respectively, in the three-month period ended June 30, 2019.

[0001032975-20-000033:mdna:122]
As of June 30, 2020 and March 31, 2020, the total amounts of unrecognized tax benefits due to uncertain tax positions were $144.2 million and $140.8 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-20-000033:mdna:123]
[same as prior period, unchanged from 0001032975-20-000005:mdna:129]

[0001032975-20-000033:mdna:124]
[same as prior period, unchanged from 0001032975-20-000005:mdna:130]

[0001032975-20-000033:mdna:125]
As of June 30, 2020, we had cash and cash equivalents of $809.4 million, compared to $715.6 million as of March 31, 2020. As of June 30, 2020, 57% of the cash and cash equivalents were held in Switzerland, 21% held in Germany, and 14% held in Hong Kong and China. We do not expect to incur any material adverse tax impact except for what has been recognized, or be significantly inhibited by any country in which we do business from the repatriation of funds to Switzerland, our home domicile.

[0001032975-20-000033:mdna:126]
The increase in cash and cash equivalents for the three months ended June 30, 2020, was primarily due to an increase in net cash provided by operating activities and proceeds from exercises of stock options and purchase rights, partially offset by payment of annual bonus during the period, purchases of property, plant and equipment, and tax withholdings related to settlements of restricted stock units.

[0001032975-20-000033:mdna:127]
As of June 30, 2020, our working capital was $788.8 million, compared to $700.3 million as of March 31, 2020. The increase was primarily driven by higher cash and cash equivalents, higher accounts receivable, net, higher inventories and lower accrued and other current liabilities, partially offset by higher accounts payable. Our working capital increased by $140.5 million compared to $648.3 million as of June 30, 2019, which was primarily driven by higher cash and cash equivalents, higher accounts receivable, net, and higher other current assets, partially offset by lower inventories and higher accounts payable and accrued and other current liabilities.

[0001032975-20-000033:mdna:128]
We had several uncommitted, unsecured bank lines of credit aggregating $81.9 million as of June 30, 2020. There are no financial covenants under these lines of credit with which we must comply. As of June 30, 2020, we had outstanding bank guarantees of $28.5 million under these lines of credit.

[0001032975-20-000033:mdna:129]
The following table summarizes our condensed consolidated statements of cash flows (Dollars in thousands):

[0001032975-20-000033:mdna:130]
|  |  | Three Months EndedJune 30, |
|  |  | 2020 |  | 2019 |
| Net cash provided by operating activities |  | $ | 118,847 |  |  | $ | 36,516 |  |
| Net cash used in investing activities |  | (12,400 | ) |  | (9,469 | ) |
| Net cash used in financing activities |  | (13,129 | ) |  | (34,104 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  | 511 |  |  | (503 | ) |
| Net increase (decrease) in cash and cash equivalents |  | $ | 93,829 |  |  | $ | (7,560 | ) |

[0001032975-20-000033:mdna:131]
33

[0001032975-20-000033:mdna:132]
The following table presents selected financial information and statistics as of and for the three months ended June 30, 2020 and 2019 (Dollars in thousands):

[0001032975-20-000033:mdna:133]
|  |  | As of June 30, |
|  |  | 2020 |  | 2019 |
| Accounts receivable, net |  | $ | 500,306 |  |  | $ | 418,816 |  |
| Accounts payable |  | $ | 429,693 |  |  | $ | 338,748 |  |
| Inventories |  | $ | 271,180 |  |  | $ | 297,007 |  |

[0001032975-20-000033:mdna:134]
|  |  | Three Months EndedJune 30, |
|  |  | 2020 |  | 2019 |
| Days sales in accounts receivable (“DSO”) (Days) (1) |  | 57 |  |  | 59 |  |
| Days accounts payable outstanding (“DPO”) (Days) (2) |  | 80 |  |  | 75 |  |
| Inventory turnover (“ITO”) (x)(3) |  | 7.2 |  |  | 5.5 |  |

[0001032975-20-000033:mdna:135]
[same as prior period, unchanged from 0001032975-20-000005:mdna:140]

[0001032975-20-000033:mdna:136]
[same as prior period, unchanged from 0001032975-20-000005:mdna:141]

[0001032975-20-000033:mdna:137]
(3) ITO is determined using ending inventories and annualized cost of goods sold (based on the most recent quarterly cost of goods sold).

[0001032975-20-000033:mdna:138]
DSO for the three months ended June 30, 2020 decreased by 2 days to 57 days, compared to 59 days for the same period of the prior fiscal year, primarily due to timing of sales, customer payments and sales linearity.

[0001032975-20-000033:mdna:139]
DPO for the three months ended June 30, 2020 increased by 5 days, compared to 75 days for the same period of the prior fiscal year, primarily due to the timing of purchases and related payments.

[0001032975-20-000033:mdna:140]
ITO for the three months ended June 30, 2020 increased by 1.7, compared to 5.5 for the same period of the prior fiscal year, primarily due to higher sales growth as a result of higher demand due to the COVID-19 impact.

[0001032975-20-000033:mdna:141]
If we are not successful in launching and phasing in our new products, or market competition increases, or we are not able to sell the new products at the prices planned, it could have a material impact on our sales, gross profit margin, operating results including operating cash flow, and inventory turnover in the future.

[0001032975-20-000033:mdna:142]
During the three months ended June 30, 2020, we generated $118.8 million of cash from operating activities. Our main sources of operating cash flows were from net income, after adding back non-cash expenses of depreciation, amortization and share-based compensation expense, change in fair value of contingent considerations, and from changes in operating assets and liabilities. The increase in accounts receivable, net was primarily driven by growth and timing of sales. The increase in inventories was primarily driven by an increase in inventory purchases during the first quarter of fiscal year 2021. The increase in accounts payable was primarily driven by the timing of purchases and related payments. The decrease in accrued and other liabilities was primarily due to payment of annual bonus during the period.

[0001032975-20-000033:mdna:143]
Net cash used in investing activities was $12.4 million, primarily due to $12.3 million of purchases of property, plant and equipment.

[0001032975-20-000033:mdna:144]
Net cash used in financing activities was $13.1 million, primarily due to $23.1 million tax withholdings related to net share settlements of restricted stock units, partially offset by $10.0 million in proceeds received from exercises of stock options and purchase rights.

[0001032975-20-000033:mdna:145]
During the three months ended June 30, 2020, there was a $0.5 million gain from currency exchange rate effect on cash and cash equivalents, compared to a loss of $0.5 million during the same period of the prior fiscal year. The gain from currency translation exchange effect during the three months ended June 30, 2020 was primarily due to the strengthening of the Australian Dollar, Japanese Yen, and Taiwanese Dollar against the U.S. Dollar by 13%, 1%, and 2%, respectively, during the period.

[0001032975-20-000033:mdna:146]
[same as prior period, unchanged from 0001032975-20-000005:mdna:152]

[0001032975-20-000033:mdna:147]
Our principal sources of liquidity are our cash and cash equivalents, cash flow generated from operations and, to a much lesser extent, capital markets and borrowings. Our future working capital requirements and capital expenditures may increase to support investments in product innovations and growth opportunities or to acquire or invest in complementary businesses, products, services, and technologies. The future impact of COVID-19 cannot be predicted with certainty and may increase our costs of capital and otherwise adversely affect our business, results of operations, financial conditions and liquidity.

[0001032975-20-000033:mdna:148]
In May 2020, the Board of Directors recommended that we pay cash dividends for fiscal year 2020 of CHF 134.0 million ($138.7 million based on the exchange rate on March 31, 2020). In fiscal year 2020, we paid a cash dividend of CHF 121.8 million (U.S. Dollar amount of $124.2 million) out of fiscal year 2019 retained earnings. The dividend to be paid in fiscal year 2020 and any future dividends will be subject to the approval of our shareholders.

[0001032975-20-000033:mdna:149]
In May 2020, our Board of Directors approved a new share buyback program, which authorizes us to invest up to $250.0 million to purchase our own shares, following the expiration date of the 2017 share buyback program. Although we enter into trading plans for systematic repurchases (e.g., 10b5-1 trading plans) from time to time, our share buyback program provides us with the opportunity to make opportunistic repurchases during periods of favorable market conditions and is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Opportunistic purchases may be started or stopped at any time without prior notice depending on market conditions and other factors.

[0001032975-20-000033:mdna:150]
Our 2017 share buyback program, which authorized us to invest up to $250.0 million to purchase our own shares, expired at the end of April 2020. There was no share buyback during the three months ended June 30, 2020.

[0001032975-20-000033:mdna:151]
[same as prior period, unchanged from 0001032975-20-000005:mdna:156]

[0001032975-20-000033:mdna:152]
[same as prior period, unchanged from 0001032975-20-000005:mdna:157]

[0001032975-20-000033:mdna:153]
[same as prior period, unchanged from 0001032975-20-000005:mdna:158]

[0001032975-20-000033:mdna:154]
[same as prior period, unchanged from 0001032975-20-000005:mdna:159]

[0001032975-20-000033:mdna:155]
As of June 30, 2020, we had non-cancelable purchase commitments of $401.0 million for inventory purchases made in the normal course of business from original design manufacturers, contract manufacturers and other suppliers, as well as due to strong sales growth in the first quarter of fiscal year 2021 and the reduced level of our customers’ inventories, the majority of which are expected to be fulfilled within the next 12 months. The increase of inventory purchase commitment from March 31, 2020 is to replenish the inventory due to business growth as well as a mitigation of supply constraint in the fourth quarter of fiscal year 2020. Non-cancelable purchase commitments for capital expenditures primarily relate to commitments for tooling for new and existing products, computer hardware, leasehold and improvements. We expect to continue making capital expenditures in the future to support product development activities and ongoing and expanded operations. Although open purchase commitments are considered enforceable and legally binding, the terms generally allow us to reschedule or adjust our requirements based on business needs prior to delivery of goods or performance of services.

[0001032975-20-000033:mdna:156]
35

[0001032975-20-000033:mdna:157]
We recorded a liability for firm, non-cancelable, and unhedged inventory purchase commitments in excess of anticipated demand or net realizable value consistent with our valuation of excess and obsolete inventory. As of June 30, 2020, the liability for these purchase commitments was $10.0 million and is recorded in accrued and other current liabilities. Although open purchase commitments are considered enforceable and legally binding, the terms generally allow us the option to reschedule and adjust our requirements based on business needs prior to delivery of goods.

[0001032975-20-000033:mdna:158]
[same as prior period, unchanged from 0001032975-20-000005:mdna:161]

[0001032975-20-000033:mdna:159]
For further detail about our contractual obligations and commitments, refer to our Annual Report on Form 10-K for the fiscal year ended March 31, 2020.

[0001032975-20-000033:mdna:160]
[same as prior period, unchanged from 0001032975-20-000005:mdna:163]

[0001032975-20-000033:mdna:161]
[same as prior period, unchanged from 0001032975-20-000005:mdna:164]

[0001032975-20-000033:mdna:162]
[same as prior period, unchanged from 0001032975-20-000005:mdna:165]

[0001032975-20-000033:mdna:163]
We indemnify certain suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of June 30, 2020, no amounts have been accrued for indemnification provisions. We do not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under our indemnification arrangements.

[0001032975-20-000033:mdna:164]
[same as prior period, unchanged from 0001032975-20-000005:mdna:167]

[0001032975-20-000033:mdna:165]
Legal Proceedings

[0001032975-20-000033:mdna:166]
From time to time we are involved in claims and legal proceedings that arise in the ordinary course of our business. We are currently subject to several such claims and a small number of legal proceedings. We believe that these matters lack merit and we intend to vigorously defend against them. Based on currently available information, we do not believe that resolution of pending matters will have a material adverse effect on our financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that our defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on our business, financial condition, cash flows and results of operations in a particular period. Any claims or proceedings against us, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain necessary licenses or other rights, or litigation arising out of intellectual property claims, could adversely affect our business.
