# LOGI 8-K — 0001032975-20-000029 filed 2020-07-21

## item codes, every 8-K on or before 2020-07-23

- 2020-07-21 0001032975-20-000029 — 2.02, 9.01
- 2020-07-01 0001032975-20-000023 — 5.02, 8.01
- 2020-05-12 0001032975-20-000011 — 2.02, 9.01
- 2020-03-30 0001032975-20-000009 — 5.02
- 2020-01-21 0001032975-20-000002 — 2.02, 9.01
- 2019-10-22 0001032975-19-000071 — 9.01
- 2019-09-26 0001032975-19-000068 — 1.01, 7.01, 9.01
- 2019-09-06 0001032975-19-000063 — 5.07, 8.01
- 2019-07-23 0001032975-19-000046 — 2.02, 9.01
- 2019-07-23 0001032975-19-000045 — 5.02, 9.01
- 2019-07-02 0001032975-19-000036 — 5.02
- 2019-06-25 0001032975-19-000034 — 5.02
- 2019-05-03 0001032975-19-000021 — 5.02 — amendment, the index does not say of what
- 2019-04-30 0001032975-19-000017 — 2.02, 5.02, 9.01
- 2019-03-28 0001032975-19-000013 — 5.02
- 2019-01-22 0001032975-19-000004 — 2.02, 9.01
- 2018-10-23 0001032975-18-000044 — 2.02, 9.01
- 2018-09-07 0001032975-18-000040 — 5.07, 8.01
- 2018-07-31 0001032975-18-000035 — 1.01, 2.02, 2.05, 7.01, 9.01
- 2018-06-27 0001032975-18-000020 — 5.02
- 2018-05-03 0001032975-18-000013 — 2.02, 5.02, 9.01
- 2018-01-23 0001032975-18-000005 — 2.02, 9.01
- 2017-10-24 0001032975-17-000043 — 2.02, 9.01
- 2017-09-18 0001032975-17-000040 — 5.07, 8.01
- 2017-07-25 0001032975-17-000028 — 2.02, 9.01
- 2017-07-12 0001032975-17-000022 — 1.01
- 2017-04-26 0001032975-17-000012 — 2.02, 9.01
- 2017-01-25 0001032975-17-000002 — 2.02, 9.01
- 2016-10-26 0001032975-16-000103 — 2.02, 9.01
- 2016-09-13 0001032975-16-000101 — 5.07, 8.01
- 2016-07-28 0001032975-16-000092 — 2.02, 9.01
- 2016-06-30 0001032975-16-000087 — 5.02
- 2016-04-28 0001032975-16-000077 — 2.02, 9.01
- 2016-04-14 0001032975-16-000073 — 1.01, 7.01, 9.01
- 2016-01-21 0001032975-16-000064 — 2.02, 9.01
- 2016-01-04 0001032975-16-000061 — 1.01, 2.01, 9.01
- 2015-12-23 0001032975-15-000059 — 5.02
- 2015-10-22 0001032975-15-000047 — 2.02, 9.01
- 2015-09-11 0001032975-15-000044 — 5.07, 8.01
- 2015-07-24 0001032975-15-000034 — 2.05 — amendment of 0001032975-15-000030
- 2015-07-23 0001032975-15-000030 — 2.02, 9.01
- 2015-06-25 0001032975-15-000025 — 5.02
- 2015-05-14 0001032975-15-000011 — 8.01, 9.01
- 2015-04-23 0001032975-15-000008 — 2.02, 2.05
- 2015-01-22 0001628280-15-000191 — 2.02, 8.01
- 2014-12-23 0001193125-14-450908 — 5.02, 5.07, 8.01
- 2014-11-25 0001193125-14-425233 — 3.01
- 2014-11-13 0001193125-14-411303 — 4.01, 9.01
- 2014-10-23 0001104659-14-073164 — 2.02, 9.01
- 2014-09-04 0001193125-14-331214 — 4.02, 9.01
- 2014-08-18 0001193125-14-313346 — 3.01, 9.01
- 2014-07-24 0001104659-14-053065 — 2.02, 9.01
- 2014-06-05 0001193125-14-226177 — 3.01, 9.01
- 2014-05-22 0001193125-14-208777 — 8.01, 9.01
- 2014-04-24 0001104659-14-029650 — 2.02, 9.01
- 2014-01-23 0001104659-14-003619 — 2.02, 9.01
- 2013-10-24 0001104659-13-077404 — 2.02, 9.01
- 2013-09-09 0001193125-13-361441 — 5.02, 5.07, 8.01, 9.01
- 2013-09-06 0001193125-13-359930 — 5.02, 9.01
- 2013-08-02 0001193125-13-317343 — 5.02
- 2013-07-25 0001104659-13-056372 — 2.02, 9.01
- 2013-06-28 0001193125-13-277394 — 5.02, 9.01
- 2013-06-20 0001193125-13-265914 — 8.01, 9.01
- 2013-04-25 0001104659-13-032570 — 2.02, 9.01
- 2013-04-17 0001193125-13-158923 — 5.02, 9.01
- 2013-03-01 0001193125-13-085804 — 2.05
- 2013-01-24 0001104659-13-004214 — 2.02, 9.01
- 2013-01-02 0001193125-13-000058 — 5.02
- 2012-10-25 0001104659-12-070966 — 2.02, 9.01
- 2012-09-11 0001193125-12-388070 — 5.02, 5.07, 8.01, 9.01
- 2012-08-22 0001193125-12-364167 — 5.02, 8.01, 9.01
- 2012-07-26 0001104659-12-051084 — 2.02, 9.01
- 2012-06-08 0001193125-12-264132 — 2.05, 9.01 — amendment, the index does not say of what
- 2012-04-26 0001193125-12-183657 — 5.02, 9.01
- 2012-04-26 0001104659-12-028470 — 2.02, 2.05, 9.01
- 2012-03-15 0001193125-12-115954 — 5.02, 9.01
- 2012-01-26 0001104659-12-004014 — 2.02, 9.01
- 2012-01-04 0001193125-12-002212 — 1.01, 2.03, 9.01
- 2011-10-27 0001104659-11-058150 — 2.02, 9.01
- 2011-09-12 0001193125-11-245931 — 5.07
- 2011-07-28 0001193125-11-200929 — 5.02, 9.01
- 2011-07-28 0001193125-11-199704 — 2.02, 9.01
- 2011-04-28 0001193125-11-112669 — 2.02, 9.01
- 2011-03-24 0001193125-11-076483 — 5.02, 9.01
- 2011-01-27 0001032975-11-000003 — 9.01
- 2010-10-28 0001032975-10-000032 — 9.01
- 2010-09-13 0001032975-10-000022 — 5.07
- 2010-07-29 0001032975-10-000010 — 2.02, 9.01
- 2010-06-10 0001193125-10-136877 — 5.02, 9.01
- 2010-05-03 0001193125-10-104337 — 5.02
- 2010-04-29 0001032975-10-000008 — 2.02, 9.01
- 2010-02-19 0001032975-10-000006 — 9.01 — amendment of 0001193125-09-252416
- 2010-01-21 0001032975-10-000002 — 2.02, 9.01
- 2009-12-14 0001193125-09-252416 — 2.01, 9.01
- 2009-11-17 0001032975-09-000023 — 1.01
- 2009-10-22 0001032975-09-000018 — 9.01
- 2009-09-22 0001193125-09-195545 — 5.02, 9.01
- 2009-09-03 0001032975-09-000013 — 8.01
- 2009-07-23 0001140361-09-016802 — 2.02, 9.01
- 2009-06-01 0001193125-09-122550 — 5.02
- 2009-04-23 0001193125-09-085054 — 2.02, 9.01
- 2009-04-02 0001193125-09-071272 — 5.02, 9.01
- 2009-01-20 0001193125-09-008454 — 2.05 — amendment of 0001193125-09-002609
- 2009-01-20 0001193125-09-007902 — 2.02, 9.01
- 2009-01-07 0001193125-09-002609 — 2.05, 9.01
- 2009-01-07 0001193125-09-002370 — 5.02, 9.01
- 2008-12-09 0001193125-08-250543 — 5.02, 9.01
- 2008-10-21 0001193125-08-213212 — 2.02, 9.01
- 2008-07-22 0001193125-08-154721 — 2.02, 9.01
- 2008-06-24 0001193125-08-139163 — 5.03, 9.01
- 2008-05-13 0001193125-08-113263 — 5.02, 9.01
- 2008-04-22 0001193125-08-086176 — 2.02, 9.01

## late-filing notifications on or before 2020-07-23

- 2015-06-02 0001032975-15-000020 — NT 10-K, for the period ended 2015-03-31
- 2014-11-06 0001193125-14-401306 — NT 10-Q, for the period ended 2014-09-30
- 2014-07-24 0001193125-14-277575 — NT 10-Q, for the period ended 2014-06-30
- 2014-05-22 0001193125-14-208712 — NT 10-K, for the period ended 2014-03-31
- 2009-08-06 0001032975-09-000006 — NT 10-Q, for the period ended 2009-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001032975-20-000029:8k_2_02:1]
EX-99.1
2
exhibit991q1fy21.htm
EXHIBIT 99.1

[0001032975-20-000029:8k_2_02:2]
Exhibit

[0001032975-20-000029:8k_2_02:3]
Exhibit 99.1

[0001032975-20-000029:8k_2_02:4]
Editorial Contacts:

[0001032975-20-000029:8k_2_02:5]
Ben Lu, Vice President, Investor Relations - USA +1 (510) 713-5568

[0001032975-20-000029:8k_2_02:6]
Nicole Kenyon, Head of Global Corporate & Employee Communications - USA +1 (510) 988-8553

[0001032975-20-000029:8k_2_02:7]
Ben Starkie, Corporate Communications - Europe +41 (0) 79-292-3499

[0001032975-20-000029:8k_2_02:8]
Logitech's Growth Accelerates, Q1 Revenue Up 23%

[0001032975-20-000029:8k_2_02:9]
Profits Increase 76% and Company Raises Annual Outlook

[0001032975-20-000029:8k_2_02:10]
LAUSANNE, Switzerland, Jul. 21, 2020 and NEWARK, Calif., Jul 20, 2020 - Logitech International (SIX: LOGN) (Nasdaq: LOGI) today announced financial results for the first quarter of Fiscal Year 2021.

[0001032975-20-000029:8k_2_02:11]
| • | Q1 sales were $792 million, up 23 percent in US dollars and 25 percent in constant currency, compared to Q1 of the prior year. |

[0001032975-20-000029:8k_2_02:12]
| • | Q1 GAAP operating income grew 76 percent to $83 million, compared to $47 million in the same quarter a year ago. Q1 GAAP earnings per share (EPS) grew 56 percent to $0.42, compared to $0.27 in the same quarter a year ago. |

[0001032975-20-000029:8k_2_02:13]
| • | Q1 non-GAAP operating income grew 75 percent to $117 million, compared to $67 million in the same quarter a year ago. Q1 non-GAAP EPS grew 64 percent to $0.64, compared to $0.39 in the same quarter a year ago. |

[0001032975-20-000029:8k_2_02:14]
| • | Cash flow from operations was $119 million, compared to $37 million in the same period a year ago. |

[0001032975-20-000029:8k_2_02:15]
“We delivered an exceptional first quarter and are raising our fiscal year outlook,” said Bracken Darrell, Logitech president and chief executive officer. “We grew sales 25% with strong growth in almost every product category. Our company strategy focuses on four long-term trends: more of us will work from home; video calls will replace audio calls; esports will become as big as conventional sports; and billions of people worldwide will create content, not just a handful of TV and movie studios. Logitech’s business was already positioned to grow from these long-term trends, and since early March they have accelerated, making Logitech more relevant to customers than ever before.”

[0001032975-20-000029:8k_2_02:16]
Outlook

[0001032975-20-000029:8k_2_02:17]
Logitech raised its Fiscal Year 2021 annual sales outlook from mid single-digit sales growth to 10 to 13 percent growth in constant currency. The Company also raised its annual outlook for non-GAAP operating income from a range of $380 million to $400 million, to a range of $410 million to $425 million.

[0001032975-20-000029:8k_2_02:18]
Prepared Remarks Available Online

[0001032975-20-000029:8k_2_02:19]
Logitech has made its prepared written remarks for the financial results teleconference available online on the Logitech corporate website at http://ir.logitech.com.

[0001032975-20-000029:8k_2_02:20]
Financial Results Teleconference and Webcast

[0001032975-20-000029:8k_2_02:21]
Logitech will hold a financial results teleconference to discuss the results for Q1 FY 2021 on

[0001032975-20-000029:8k_2_02:22]
Tuesday, July 21, 2020 at 8:30 a.m. Eastern Daylight Time and 2:30 p.m. Central European Summer Time. A live webcast of the call will be available on the Logitech corporate website at http://ir.logitech.com.

[0001032975-20-000029:8k_2_02:23]
Use of Non-GAAP Financial Information and Constant Currency

[0001032975-20-000029:8k_2_02:24]
To facilitate comparisons to Logitech’s historical results, Logitech has included non-GAAP adjusted measures, which exclude share-based compensation expense, amortization of intangible assets, purchase accounting effect on inventory, acquisition-related costs, change in fair value of contingent consideration for business acquisition, restructuring charges (credits), gain (loss) on investments in privately held companies, non-GAAP income tax adjustment, and other items detailed under “Supplemental Financial Information” after the tables below. Logitech also presents percentage sales growth in constant currency to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales. Logitech believes this information, used together with the GAAP financial information, will help investors to evaluate its current period performance and trends in its business. With respect to the Company’s outlook for non-GAAP operating income, most of these excluded amounts pertain to events that have not yet occurred and are not currently possible to estimate with a reasonable degree of accuracy. Therefore, no reconciliation to the GAAP amounts has been provided for Fiscal Year 2021.

[0001032975-20-000029:8k_2_02:25]
About Logitech

[0001032975-20-000029:8k_2_02:26]
Logitech designs products that have an everyday place in people's lives, connecting them to the digital experiences they care about. More than 35 years ago, Logitech started connecting people through computers, and now it’s a multi-brand company designing products that bring people together through music, gaming, video and computing. Brands of Logitech include Logitech, Logitech G, ASTRO Gaming, Streamlabs, Ultimate Ears, Jaybird and Blue Microphones. Founded in 1981, and headquartered in Lausanne, Switzerland, Logitech International is a Swiss public company listed on the SIX Swiss Exchange (LOGN) and on the Nasdaq Global Select Market (LOGI). Find Logitech at www.logitech.com, the company blog or@Logitech.

[0001032975-20-000029:8k_2_02:27]
# # #

[0001032975-20-000029:8k_2_02:28]
imposition of tariffs that affect our products or operations and our ability to mitigate; risks associated with acquisitions. A detailed discussion of these and other risks and uncertainties that could cause actual results and events to differ materially from such forward-looking statements is included in Logitech’s periodic filings with the Securities and Exchange Commission, including our Annual Report on Form 10-K for the fiscal year ended March 31, 2020, available at www.sec.gov, under the caption Risk Factors and elsewhere. Logitech does not undertake any obligation to update any forward-looking statements to reflect new information or events or circumstances occurring after the date of this press release.

[0001032975-20-000029:8k_2_02:29]
Note that unless noted otherwise, comparisons are year over year.

[0001032975-20-000029:8k_2_02:30]
Logitech and other Logitech marks are trademarks or registered trademarks of Logitech Europe S.A and/or its affiliates in the U.S. and other countries.  All other trademarks are the property of their respective owners. For more information about Logitech and its products, visit the company’s website at www.logitech.com.

[0001032975-20-000029:8k_2_02:31]
(LOGIIR)

[0001032975-20-000029:8k_2_02:32]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |
| PRELIMINARY RESULTS * |  |  |  |  |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |
|  |  | Three Months Ended |
|  |  | June 30, |
| GAAP CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  | 2020 |  | 2019 |
| Net sales |  | $ | 791,894 |  |  | $ | 644,225 |  |
| Cost of goods sold |  | 482,638 |  |  | 401,978 |  |
| Amortization of intangible assets and purchase accounting effect on inventory |  | 3,523 |  |  | 3,271 |  |
| Gross profit |  | 305,733 |  |  | 238,976 |  |
| Operating expenses: |  |  |  |  |
| Marketing and selling |  | 133,238 |  |  | 123,033 |  |
| Research and development |  | 49,725 |  |  | 42,243 |  |
| General and administrative |  | 29,071 |  |  | 22,159 |  |
| Amortization of intangible assets and acquisition-related costs |  | 4,609 |  |  | 3,596 |  |
| Change in fair value of contingent consideration for business acquisition |  | 5,716 |  |  | — |  |
| Restructuring charges (credits), net |  | (53 | ) |  | 478 |  |
| Total operating expenses |  | 222,306 |  |  | 191,509 |  |
| Operating income |  | 83,427 |  |  | 47,467 |  |
| Interest income |  | 620 |  |  | 2,553 |  |
| Other income, net |  | 2,029 |  |  | 1,861 |  |
| Income before income taxes |  | 86,076 |  |  | 51,881 |  |
| Provision for (benefit from) income taxes |  | 14,003 |  |  | 6,536 |  |
| Net income |  | $ | 72,073 |  |  | $ | 45,345 |  |
| Net income per share: |  |  |  |  |  |  |
| Basic |  | $ | 0.43 |  |  | $ | 0.27 |  |
| Diluted |  | $ | 0.42 |  |  | $ | 0.27 |  |
| Weighted average shares used to compute net income per share: |  |  |  |  |  |  |
| Basic |  | 167,612 |  |  | 166,302 |  |
| Diluted |  | 170,127 |  |  | 168,797 |  |

[0001032975-20-000029:8k_2_02:33]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |
| PRELIMINARY RESULTS * |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |
|  |  | June 30, 2020 |  | March 31, 2020 |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 809,395 |  |  | $ | 715,566 |  |
| Accounts receivable, net |  | 500,306 |  |  | 394,743 |  |
| Inventories |  | 271,180 |  |  | 229,249 |  |
| Other current assets |  | 82,470 |  |  | 74,920 |  |
| Total current assets |  | 1,663,351 |  |  | 1,414,478 |  |
| Non-current assets: |  |  |  |  |  |  |
| Property, plant and equipment, net |  | 79,481 |  |  | 76,119 |  |
| Goodwill |  | 400,934 |  |  | 400,917 |  |
| Other intangible assets, net |  | 118,809 |  |  | 126,941 |  |
| Other assets |  | 351,131 |  |  | 345,019 |  |
| Total assets |  | $ | 2,613,706 |  |  | $ | 2,363,474 |  |
| Current liabilities: |  |  |  |  |  |  |
| Accounts payable |  | $ | 429,693 |  |  | $ | 259,120 |  |
| Accrued and other current liabilities |  | 444,826 |  |  | 455,024 |  |
| Total current liabilities |  | 874,519 |  |  | 714,144 |  |
| Non-current liabilities: |  |  |  |  |  |  |
| Income taxes payable |  | 44,261 |  |  | 40,788 |  |
| Other non-current liabilities |  | 127,445 |  |  | 119,274 |  |
| Total liabilities |  | 1,046,225 |  |  | 874,206 |  |
| Shareholders’ equity: |  |  |  |  |
| Registered shares, CHF 0.25 par value: |  | 30,148 |  |  | 30,148 |  |
| Issued shares — 173,106 at June 30 and March 31, 2020 |  |  |  |  |
| Additional shares that may be issued out of conditional capitals — 50,000 at June 30 and March 31, 2020 |  |  |  |  |
| Additional shares that may be issued out of authorized capitals — 34,621 at June 30 and March 31, 2020 |  |  |  |  |
| Additional paid-in capital |  | 54,668 |  |  | 75,097 |  |
| Shares in treasury, at cost — 4,689 at June 30, 2020 and 6,210 at March 31, 2020 |  | (158,463 | ) |  | (185,896 | ) |
| Retained earnings |  | 1,762,099 |  |  | 1,690,579 |  |
| Accumulated other comprehensive loss |  | (120,971 | ) |  | (120,660 | ) |
| Total shareholders’ equity |  | 1,567,481 |  |  | 1,489,268 |  |
| Total liabilities and shareholders’ equity |  | $ | 2,613,706 |  |  | $ | 2,363,474 |  |

[0001032975-20-000029:8k_2_02:34]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |
| PRELIMINARY RESULTS * |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |
|  |  | Three Months Ended |
|  |  | June 30, |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |  | 2020 |  | 2019 |
| Cash flows from operating activities: |  |  |  |  |  |  |
| Net income |  | $ | 72,073 |  |  | $ | 45,345 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Depreciation |  | 11,747 |  |  | 10,802 |  |
| Amortization of intangible assets |  | 8,132 |  |  | 6,867 |  |
| Gain on investments |  | (174 | ) |  | (211 | ) |
| Share-based compensation expense |  | 20,115 |  |  | 12,218 |  |
| Deferred income taxes |  | 3,589 |  |  | (3,381 | ) |
| Change in fair value of contingent consideration for business acquisition |  | 5,716 |  |  | — |  |
| Other |  | 9 |  |  | (4 | ) |
| Changes in assets and liabilities, net of acquisitions: |  |  |  |  |
| Accounts receivable, net |  | (102,092 | ) |  | (34,264 | ) |
| Inventories |  | (40,385 | ) |  | (2,681 | ) |
| Other assets |  | (15,770 | ) |  | (5,387 | ) |
| Accounts payable |  | 168,346 |  |  | 55,592 |  |
| Accrued and other liabilities |  | (12,459 | ) |  | (48,380 | ) |
| Net cash provided by operating activities |  | 118,847 |  |  | 36,516 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  | (12,308 | ) |  | (9,340 | ) |
| Investment in privately held companies |  | (30 | ) |  | (170 | ) |
| Purchases of trading investments |  | (2,424 | ) |  | (1,155 | ) |
| Proceeds from sales of trading investments |  | 2,362 |  |  | 1,196 |  |
| Net cash used in investing activities |  | (12,400 | ) |  | (9,469 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |
| Purchases of registered shares |  | — |  |  | (15,127 | ) |
| Proceeds from exercises of stock options and purchase rights |  | 9,992 |  |  | 393 |  |
| Tax withholdings related to net share settlements of restricted stock units |  | (23,121 | ) |  | (19,370 | ) |
| Net cash used in financing activities |  | (13,129 | ) |  | (34,104 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  | 511 |  |  | (503 | ) |
| Net increase (decrease) in cash and cash equivalents |  | 93,829 |  |  | (7,560 | ) |
| Cash and cash equivalents, beginning of the period |  | 715,566 |  |  | 604,516 |  |
| Cash and cash equivalents, end of the period |  | $ | 809,395 |  |  | $ | 596,956 |  |

[0001032975-20-000029:8k_2_02:35]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |
| PRELIMINARY RESULTS * |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |
| NET SALES |  | Three Months Ended |
|  |  | June 30, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2020 |  | 2019 |  | Change |
| Net sales by product category: |  |  |  |  |  |  |
| Pointing Devices |  | $ | 120,469 |  |  | $ | 121,983 |  |  | (1 | )% |
| Keyboards & Combos |  | 145,360 |  |  | 128,679 |  |  | 13 |  |
| PC Webcams |  | 60,851 |  |  | 28,128 |  |  | 116 |  |
| Tablet & Other Accessories |  | 46,048 |  |  | 38,339 |  |  | 20 |  |
| Gaming |  | 181,903 |  |  | 134,515 |  |  | 35 |  |
| Video Collaboration |  | 130,074 |  |  | 73,424 |  |  | 77 |  |
| Mobile Speakers |  | 29,009 |  |  | 50,416 |  |  | (42 | ) |
| Audio & Wearables |  | 71,365 |  |  | 58,624 |  |  | 22 |  |
| Smart Home |  | 6,810 |  |  | 9,864 |  |  | (31 | ) |
| Other (1) |  | 5 |  |  | 253 |  |  | (98 | ) |
| Total sales |  | $ | 791,894 |  |  | $ | 644,225 |  |  | 23 |  |

[0001032975-20-000029:8k_2_02:36]
(1) Other category includes products that we currently intend to phase out, or have already phased out, because they are no longer strategic to our business.

[0001032975-20-000029:8k_2_02:37]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |
| PRELIMINARY RESULTS * |  |  |  |  |
| (In thousands, except per share amounts) - Unaudited |  |  |  |  |
| GAAP TO NON-GAAP RECONCILIATION (A) |  | Three Months Ended |
|  |  | June 30, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2020 |  | 2019 |
| Gross profit - GAAP |  | $ | 305,733 |  |  | $ | 238,976 |  |
| Share-based compensation expense |  | 1,400 |  |  | 1,158 |  |
| Amortization of intangible assets and purchase accounting effect on inventory |  | 3,523 |  |  | 3,271 |  |
| Gross profit - Non-GAAP |  | $ | 310,656 |  |  | $ | 243,405 |  |
| Gross margin - GAAP |  | 38.6 | % |  | 37.1 | % |
| Gross margin - Non-GAAP |  | 39.2 | % |  | 37.8 | % |
| Operating expenses - GAAP |  | $ | 222,306 |  |  | $ | 191,509 |  |
| Less: Share-based compensation expense |  | 18,715 |  |  | 11,060 |  |
| Less: Amortization of intangible assets and acquisition-related costs |  | 4,609 |  |  | 3,596 |  |
| Less: Change in fair value of contingent consideration for business acquisition |  | 5,716 |  |  | — |  |
| Less: Restructuring charges, net |  | (53 | ) |  | 478 |  |
| Operating expenses - Non-GAAP |  | $ | 193,319 |  |  | $ | 176,375 |  |
| % of net sales - GAAP |  | 28.1 | % |  | 29.7 | % |
| % of net sales - Non - GAAP |  | 24.4 | % |  | 27.4 | % |
| Operating income - GAAP |  | $ | 83,427 |  |  | $ | 47,467 |  |
| Share-based compensation expense |  | 20,115 |  |  | 12,218 |  |
| Amortization of intangible assets |  | 8,132 |  |  | 6,867 |  |
| Change in fair value of contingent consideration for business acquisition |  | 5,716 |  |  | — |  |
| Restructuring charges (credits), net |  | (53 | ) |  | 478 |  |
| Operating income - Non - GAAP |  | $ | 117,337 |  |  | $ | 67,030 |  |
| % of net sales - GAAP |  | 10.5 | % |  | 7.4 | % |
| % of net sales - Non - GAAP |  | 14.8 | % |  | 10.4 | % |
| Net income - GAAP |  | $ | 72,073 |  |  | $ | 45,345 |  |
| Share-based compensation expense |  | 20,115 |  |  | 12,218 |  |
| Amortization of intangible assets |  | 8,132 |  |  | 6,867 |  |
| Change in fair value of contingent consideration for business acquisition |  | 5,716 |  |  | — |  |
| Restructuring charges (credits), net |  | (53 | ) |  | 478 |  |
| Loss (gain) on investments |  | (174 | ) |  | (211 | ) |
| Non-GAAP income tax adjustment |  | 3,048 |  |  | 907 |  |
| Net income - Non - GAAP |  | $ | 108,857 |  |  | $ | 65,604 |  |
| Net income per share: |  |  |  |  |
| Diluted - GAAP |  | $ | 0.42 |  |  | $ | 0.27 |  |
| Diluted - Non - GAAP |  | $ | 0.64 |  |  | $ | 0.39 |  |
| Shares used to compute net income per share: |  |  |  |  |
| Diluted - GAAP and Non - GAAP |  | 170,127 |  |  | 168,797 |  |

[0001032975-20-000029:8k_2_02:38]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |
| PRELIMINARY RESULTS * |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |
| SHARE-BASED COMPENSATION EXPENSE |  | Three Months Ended |
|  |  | June 30, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2020 |  | 2019 |
| Share-based Compensation Expense |  |  |  |  |
| Cost of goods sold |  | $ | 1,400 |  |  | $ | 1,158 |  |
| Marketing and selling |  | 8,792 |  |  | 6,849 |  |
| Research and development |  | 3,103 |  |  | 2,154 |  |
| General and administrative |  | 6,820 |  |  | 2,057 |  |
| Total share-based compensation expense |  | 20,115 |  |  | 12,218 |  |
| Income tax benefit |  | (8,111 | ) |  | (6,800 | ) |
| Total share-based compensation expense, net of income tax benefit |  | $ | 12,004 |  |  | $ | 5,418 |  |

[0001032975-20-000029:8k_2_02:39]
*  Note: These preliminary results for the three months ended June 30, 2020 are subject to adjustments, including subsequent events that may occur through the date of filing our Quarterly Report on Form 10-Q.

[0001032975-20-000029:8k_2_02:40]
(A) Non-GAAP Financial Measures

[0001032975-20-000029:8k_2_02:41]
To supplement our condensed consolidated financial results prepared in accordance with GAAP, we use a number of financial measures, both GAAP and non-GAAP, in analyzing and assessing our overall business performance, for making operating decisions and for forecasting and planning future periods. We consider the use of non-GAAP financial measures helpful in assessing our current financial performance, ongoing operations and prospects for the future as well as understanding financial and business trends relating to our financial condition and results of operations.

[0001032975-20-000029:8k_2_02:42]
While we use non-GAAP financial measures as a tool to enhance our understanding of certain aspects of our financial performance and to provide incremental insight into the underlying factors and trends affecting both our performance and our cash-generating potential, we do not consider these measures to be a substitute for, or superior to, the information provided by GAAP financial measures. Consistent with this approach, we believe that disclosing non-GAAP financial measures to the readers of our financial statements provides useful supplemental data that, while not a substitute for GAAP financial measures, can offer insight in the review of our financial and operational performance and enables investors to more fully understand trends in our current and future performance. In assessing our business during the quarter ended June 30, 2020 and previous periods, we excluded items in the following general categories, each of which are described below:

[0001032975-20-000029:8k_2_02:43]
Share-based compensation expenses. We believe that providing non-GAAP measures excluding share-based compensation expense, in addition to the GAAP measures, allows for a more transparent comparison of our financial results from period to period. We prepare and maintain our budgets and forecasts for future periods on a basis consistent with this non-GAAP financial measure. Further, companies use a variety of types of equity awards as well as a variety of methodologies, assumptions and estimates to determine share-based compensation expense. We believe that excluding share-based compensation expense enhances our ability and the ability of investors to understand the impact of non-cash share-based compensation on our operating results and to compare our results against the results of other companies.

[0001032975-20-000029:8k_2_02:44]
Amortization of intangible assets. We incur intangible asset amortization expense, primarily in connection with our acquisitions of various businesses and technologies. The amortization of purchased intangibles varies depending on the level of acquisition activity. We exclude these various charges in budgeting, planning and forecasting future periods and we believe that providing the non-GAAP measures excluding these various non-cash charges, as well as the GAAP measures, provides additional insight when comparing our gross profit, operating expenses, and financial results from period to period.

[0001032975-20-000029:8k_2_02:45]
Purchase accounting effect on inventory. Business combination accounting principles require us to measure acquired inventory at fair value. The fair value of inventory reflects the acquired company’s cost of manufacturing plus a portion of the expected profit margin. The non-GAAP adjustment excludes the expected profit margin component that is recorded under business combination accounting principles associated with our business acquisitions. We believe the adjustment is useful to investors because such charges are not reflective of our ongoing operations.

[0001032975-20-000029:8k_2_02:46]
Acquisition-related costs and change in fair value of contingent consideration for business acquisition.  We incurred expenses and credits in connection with our acquisitions which we generally would not have otherwise incurred in the periods presented as a part of our continuing operations. Acquisition related costs include all incremental expenses incurred to effect a business combination. Fair value of contingent consideration is associated with our estimates of the value of earn-outs in connection with certain acquisitions. We believe that providing the non-GAAP measures excluding these costs and credits, as well as the GAAP measures, assists our investors because such costs are not reflective of our ongoing operating results.

[0001032975-20-000029:8k_2_02:47]
Restructuring charges (credits). These expenses are associated with re-aligning our business strategies based on current economic conditions. We have undertaken several restructuring plans in recent years. In connection with our restructuring initiatives, we incurred restructuring charges related to employee terminations, facility closures and early cancellation of certain contracts. We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges (credits) are not reflective of our ongoing operating results in the current period.

[0001032975-20-000029:8k_2_02:48]
Loss (gain) on investments. We recognized loss (gain) related to our investments in various companies, which varies depending on the operational and financial performance of those companies in which we invested, and sales of these investments. We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges are not reflective of our ongoing operations.

[0001032975-20-000029:8k_2_02:49]
Non-GAAP income tax adjustment.  Non-GAAP income tax adjustment primarily measures the income tax effect of non-GAAP adjustments excluded above and other events; the determination of which is based upon the nature of the underlying items, the mix of income and losses in jurisdictions and the relevant tax rates in which we operate.

[0001032975-20-000029:8k_2_02:50]
Each of the non-GAAP financial measures described above, and used in this press release, should not be considered in isolation from, or as a substitute for, a measure of financial performance prepared in accordance with GAAP. Further, investors are cautioned that there are inherent limitations associated with the use of each of these non-GAAP financial measures as an analytical tool. In particular, these non-GAAP financial measures are not based on a comprehensive set of accounting rules or principles and many of the adjustments to the GAAP financial measures reflect the exclusion of items that are recurring and may be reflected in the Company’s financial results for the foreseeable future. We compensate for these limitations by providing specific information in the reconciliation included in this press release regarding the GAAP amounts excluded from the non-GAAP financial measures. In addition, as noted above, we evaluate the non-GAAP financial measures together with the most directly comparable GAAP financial information.

[0001032975-20-000029:8k_2_02:51]
Additional Supplemental Financial Information - Constant Currency

[0001032975-20-000029:8k_2_02:52]
In addition, Logitech presents percentage sales growth in constant currency to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales.
