# LOGI note change history — 0001032975-20-000005 → 0001032975-20-000033


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-07-23):
[0001032975-20-000033:note_history:1]
Changes in the Company’s warranty liability for the three months ended June 30, 2020 and 2019 were as follows (in thousands):
  (was, 2020-01-23, similarity 0.9231):
[0001032975-20-000005:note_history:1]
Changes in the Company’s warranty liability for the three and nine months ended December 31, 2019 and 2018 were as follows (in thousands):

- added (2020-07-23):
[0001032975-20-000033:note_history:2]
|  | Three Months EndedJune 30, |
|  | 2020 |  | 2019 |
| Beginning of the period | $ | 40,039 |  |  | $ | 34,229 |  |
| Provision | 5,389 |  |  | 8,535 |  |
| Settlements | (6,161 | ) |  | (6,977 | ) |
| Currency translation | 183 |  |  | 27 |  |
| End of the period | $ | 39,450 |  |  | $ | 35,814 |  |

- changed (2020-07-23):
[0001032975-20-000033:note_history:3]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of June 30, 2020, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.
  (was, 2020-01-23, similarity 0.9906):
[0001032975-20-000005:note_history:3]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of December 31, 2019, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

- removed (2020-07-23):
[0001032975-20-000005:note_history:4]
|  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Beginning of the period | $ | 37,222 |  |  | $ | 31,754 |  |  | $ | 34,229 |  |  | $ | 27,573 |  |
| Assumed from business acquisition | — |  |  | — |  |  | — |  |  | 351 |  |
| Provision | 9,608 |  |  | 11,305 |  |  | 26,652 |  |  | 30,625 |  |
| Settlements | (6,840 | ) |  | (7,523 | ) |  | (20,544 | ) |  | (22,405 | ) |
| Currency translation | 187 |  |  | (61 | ) |  | (160 | ) |  | (669 | ) |
| End of the period | $ | 40,177 |  |  | $ | 35,475 |  |  | $ | 40,177 |  |  | $ | 35,475 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-07-23):
[0001032975-20-000033:note_history:5]
Logitech International S.A, together with its consolidated subsidiaries, (Logitech or the Company) designs, manufactures and markets products that have an everyday place in people's lives, connecting them to the digital experiences they care about. More than 35 years ago, Logitech created products to improve experiences around the personal PC platform, and today it is a multi-brand, multi-category company designing products that enable better experiences consuming, sharing and creating any digital content such as computing, gaming, video and music, whether it is on a computer, mobile device or in the cloud.
  (was, 2020-01-23, similarity 0.8393):
[0001032975-20-000005:note_history:5]
Logitech International S.A, together with its consolidated subsidiaries, ("Logitech" or the "Company") designs, manufactures and markets products that help connect people to digital and cloud experiences. More than 35 years ago, Logitech created products to improve experiences around the personal PC platform, and today it is a multi-brand, multi-category company designing products that enable better experiences consuming, sharing and creating any digital content such as music, gaming, video and computing, whether it is on a computer, mobile device or in the cloud.

- changed (2020-07-23):
[0001032975-20-000033:note_history:6]
Logitech was founded in Switzerland in 1981 and Logitech International S.A. has been the parent holding company of Logitech since 1988. Logitech International S.A. is a Swiss holding company with its registered office in Apples, Switzerland and headquarters in Lausanne, Switzerland, which conducts its business through subsidiaries in the Americas, Europe, Middle East and Africa (EMEA) and Asia Pacific. Shares of Logitech International S.A. are listed on both the SIX Swiss Exchange under the trading symbol LOGN and the Nasdaq Global Select Market under the trading symbol LOGI.
  (was, 2020-01-23, similarity 0.9913):
[0001032975-20-000005:note_history:6]
Logitech was founded in Switzerland in 1981 and Logitech International S.A. has been the parent holding company of Logitech since 1988. Logitech International S.A. is a Swiss holding company with its registered office in Apples, Switzerland and headquarters in Lausanne, Switzerland, which conducts its business through subsidiaries in the Americas, Europe, Middle East and Africa ("EMEA") and Asia Pacific. Shares of Logitech International S.A. are listed on both the SIX Swiss Exchange under the trading symbol LOGN and the Nasdaq Global Select Market under the trading symbol LOGI.

- changed (2020-07-23):
[0001032975-20-000033:note_history:7]
The condensed consolidated financial statements include the accounts of Logitech and its subsidiaries. All intercompany balances and transactions have been eliminated. The condensed consolidated financial statements are presented in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and therefore do not include all the information required by GAAP for complete financial statements. The condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended March 31, 2020, included in its Annual Report on Form 10-K filed with the Securities and Exchange Commission (SEC) on May 27, 2020.
  (was, 2020-01-23, similarity 0.9933):
[0001032975-20-000005:note_history:7]
The condensed consolidated financial statements include the accounts of Logitech and its subsidiaries. All intercompany balances and transactions have been eliminated. The condensed consolidated financial statements are presented in accordance with accounting principles generally accepted in the United States of America (“GAAP”) for interim financial information and therefore do not include all the information required by GAAP for complete financial statements. The condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended March 31, 2019, included in its Annual Report on Form 10-K filed with the Securities and Exchange Commission (“SEC”) on May 17, 2019.

- changed (2020-07-23):
[0001032975-20-000033:note_history:8]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three months ended June 30, 2020 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2021, or any future periods.
  (was, 2020-01-23, similarity 0.9573):
[0001032975-20-000005:note_history:8]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and nine months ended December 31, 2019 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2020, or any future periods.

- changed (2020-07-23):
[0001032975-20-000033:note_history:9]
Other than the recent accounting pronouncements adopted and discussed below under Recent Accounting Pronouncements Adopted and Summary of Significant Accounting Policies, there have been no material changes in the Company’s significant accounting policies during the three months ended June 30, 2020 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2020.
  (was, 2020-01-23, similarity 0.931):
[0001032975-20-000005:note_history:9]
Other than the recent accounting pronouncements adopted and discussed below under Recent Accounting Pronouncements Adopted and Summary of Significant Accounting Policies, there have been no changes in the Company’s significant accounting policies during the nine months ended December 31, 2019 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2019.

- added (2020-07-23):
[0001032975-20-000033:note_history:10]
The preparation of financial statements in conformity with U.S. GAAP requires management to make judgments, estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Significant estimates and assumptions made by management involve fair value of  goodwill and intangible assets acquired from business acquisitions, valuation of right-of-use assets, valuation of investment in privately held companies classified under Level 3 of the fair value hierarchy, pensions obligations, warranty liabilities, accruals for customer incentives, cooperative marketing, and pricing programs (Customer Programs) and related breakage when appropriate, accrued sales return liability, inventory valuation, share-based compensation expense, uncertain tax positions, and valuation allowances for deferred tax assets. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ materially from these estimates.

- added (2020-07-23):
[0001032975-20-000033:note_history:11]
Risks and Uncertainties

- added (2020-07-23):
[0001032975-20-000033:note_history:12]
We are subject to risks and uncertainties as a result of the novel coronavirus (COVID-19) and the measures taken by many countries in response have contributed to a general slowdown in the global economy and adversely affected, and could in the future continue to adversely affect, the Company's business and operations. Capital markets and economies worldwide have also been negatively impacted by COVID-19 and it is still unclear how lasting and deep the economic impacts will be. During the three months ended June 30, 2020, as well as in the fourth quarter of fiscal year 2020, the COVID-19 pandemic had mixed effects on the Company’s results of operations, and it may continue to have mixed or adverse effects. While there was high demand and consumption of certain of our products that led to increased sales and operating income during the fourth quarter of fiscal year 2020 and the first quarter of fiscal year 2021, at the same time the Company experienced disruptions to supply chain and logistics services, inventory constraints and increased logistics costs. The ongoing and full extent of the impact of the COVID-19 pandemic on the Company's business and operational and financial performance and condition is uncertain and will depend on many factors outside the Company's control, including but not limited to the timing, extent, duration and effects of the virus and any of its mutations, the development and availability of effective treatments and vaccines, the imposition of effective public safety and other protective measures, the impact of COVID-19 on the global economy and demand for the Company's products and services. Should the COVID-19 pandemic or global economic slowdown not improve or worsen, or if the Company's attempt to mitigate its impact on its operations and costs is not successful, the Company's business, results of operations, financial condition and prospects may be adversely affected.

- changed (2020-07-23):
[0001032975-20-000033:note_history:13]
In June 2016, the FASB issued ASU 2016-13, "Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments" (ASU 2016-13), which was further updated and clarified by the FASB through issuance of additional related ASUs, replaces the incurred-loss impairment methodology and requires immediate recognition of estimated credit losses expected to occur for most financial assets, including trade receivables. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. The Company adopted this standard effective April 1, 2020, using a modified retrospective approach. Upon adoption, the Company updated its credit loss models to utilize a forward-looking current expected credit losses (CECL) model in place of the incurred loss methodology for financial instruments measured at amortized cost, including accounts receivable. The cumulative effect adjustment from adoption was not material to the Company's condensed consolidated financial statements.
  (was, 2020-01-23, similarity 0.6436):
[0001032975-20-000005:note_history:13]
In June 2016, the FASB issued ASU 2016-13, "Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments" (ASU 2016-13), which was further updated and clarified by the FASB through issuance of additional related ASUs, replaces the incurred-loss impairment methodology and requires immediate recognition of estimated credit losses expected to occur for most financial assets, including trade receivables. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. Early adoption is permitted. The Company does not expect the adoption of ASU 2016-13 will have a material impact on its consolidated financial statements and plans to adopt the standard effective April 1, 2020.

- added (2020-07-23):
[0001032975-20-000033:note_history:14]
In August 2018, the FASB issued ASU 2018-13, "Fair Value Measurement (Topic 820): Disclosure Framework - Changes to the Disclosure Requirements for Fair Value Measurements" (ASU 2018-13), which eliminates, adds and modifies certain disclosure requirements for fair value measurements, including eliminating the requirement to disclose the amount of and reasons for transfers between Level 1 and Level 2 of the fair value hierarchy, and requiring the range and weighted average used to develop significant unobservable inputs for Level 3 fair value measurements.  Some of these disclosure changes must be applied prospectively while others retrospectively depending on requirement. The Company adopted this standard effective April 1, 2020. The adoption of ASU 2018-13 did not have a material impact to the Company's condensed consolidated financial statements.

- added (2020-07-23):
[0001032975-20-000033:note_history:15]
In August 2018, the FASB issued ASU 2018-14, "Compensation - Retirement Benefits - Defined Benefits Plans - General (Subtopic 715-20): Disclosure Framework - Changes to the Disclosure Requirements for Defined Benefit Plans" (ASU 2018-14), which requires that the Company remove various disclosures that no longer are considered cost-beneficial, namely amounts in accumulated other comprehensive income expected to be recognized as components of net periodic benefit cost over the next fiscal year.  Further, ASU 2018-14 requires disclosure or clarification of the reasons for significant gains or losses related to changes in the benefit obligation for the period.  The Company adopted this standard effective April 1, 2020 using a retrospective approach and the updated disclosures will be included in the Company's Form 10-K for the fiscal year ending March 31, 2021. The adoption of ASU 2018-14 did not have an impact on the Company's condensed consolidated financial statements.

- removed (2020-07-23):
[0001032975-20-000005:note_history:16]
Business Acquisition

- removed (2020-07-23):
[0001032975-20-000005:note_history:17]
On October 31, 2019, the Company acquired General Workings, Inc. See "Note 2 - Business Acquisition" for more information.

- removed (2020-07-23):
[0001032975-20-000005:note_history:18]
The preparation of financial statements in conformity with GAAP requires management to make judgments, estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements.

- removed (2020-07-23):
[0001032975-20-000005:note_history:19]
Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Significant estimates and assumptions made by management involve the fair value of goodwill, intangible assets acquired from business acquisitions, contingent consideration for a business acquisition and periodic reassessment of its fair value, valuation of operating right-of-use assets, warranty liabilities, accruals for customer incentives, cooperative marketing, and pricing programs (Customer Programs) and related breakage when appropriate, accrued sales return liability, allowance for doubtful accounts, inventory valuation, share-based compensation expense, uncertain tax positions, and valuation allowances for deferred tax assets. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ materially from these estimates.

- removed (2020-07-23):
[0001032975-20-000005:note_history:20]
In February 2016, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) No. 2016-02, "Leases (Topic 842)" (ASU 2016-02 or Topic 842), which requires a lessee to recognize right-of-use (ROU) assets and lease liabilities arising from operating and financing leases with terms longer than 12 months on the consolidated balance sheets and to disclose key information about leasing arrangements.

- removed (2020-07-23):
[0001032975-20-000005:note_history:21]
The Company adopted the new standard effective April 1, 2019 and recorded an ROU asset and lease liability related to its operating leases. The Company used the modified retrospective approach with the effective date as the date of initial application. Accordingly, the Company applied the new lease standard prospectively to leases existing or commencing on or after April 1, 2019. Prior period balances and disclosures have not been restated. The Company elected the package of transitional practical expedients, which among other provisions, allows the Company to not reassess under the new standard the Company's prior conclusions about lease identification, lease classification and initial direct cost, for any existing leases on the adoption date. In addition, for operating leases, the Company elected to account for lease and non-lease components as a single lease component. The Company also made an accounting policy election to not recognize lease liabilities and ROU assets on its condensed consolidated balance sheet for leases that, at the lease commencement date, have a lease term of 12 months or less.

- removed (2020-07-23):
[0001032975-20-000005:note_history:22]
Adoption of the standard resulted in the recognition of $31.3 million of ROU assets and $37.4 million of lease liabilities related to the Company's leases on its condensed consolidated balance sheet on April 1, 2019. The difference of $6.1 million represented deferred rent for leases that existed as of the date of adoption, which decreased the opening balance of ROU assets. In addition, the prepaid rent balance as of the date of adoption increased the opening balance of ROU assets. The deferred rent and prepaid rent balances were derecognized as of the date of adoption and no adjustment was made to retained earnings. The adoption of the standard did not have an impact on the Company's condensed consolidated statement of operations, comprehensive income, changes in shareholders' equity or cash flows.

- removed (2020-07-23):
[0001032975-20-000005:note_history:23]
In August 2018, the FASB issued ASU 2018-15, "Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40): Customer's Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract" (ASU 2018-15), which clarifies that implementation costs incurred by customers in cloud computing arrangements are deferred if they would be capitalized by customers in software licensing arrangements under the internal-use software guidance. ASU 2018-15 is effective for annual and interim periods in fiscal years beginning after December 15, 2019, with early adoption permitted. Entities have the option to apply the guidance prospectively to all implementation costs incurred after the date of adoption or retrospectively. The Company adopted this standard effective April 1, 2019 using a prospective adoption method. The adoption of ASU 2018-15 did not have a material impact on the Company's condensed consolidated financial statements.

- removed (2020-07-23):
[0001032975-20-000005:note_history:24]
In August 2018, the FASB issued ASU 2018-13, "Fair Value Measurement (Topic 820): Disclosure Framework - Changes to the Disclosure Requirements for Fair Value Measurements" (ASU 2018-13), which aims to improve the overall usefulness of disclosures to financial statement users and reduce unnecessary costs to companies when preparing fair value measurement disclosures. ASU 2018-13 is effective for annual and interim periods in fiscal years beginning after December 15, 2019. Early adoption is permitted. Retrospective adoption is required, except for certain disclosures which will be required to be applied prospectively for only the most recent interim or annual period presented in the initial fiscal year of adoption. The Company does not expect the adoption of ASU 2018-13 will have a material impact on its consolidated financial statements and plans to adopt the standard effective April 1, 2020.

- removed (2020-07-23):
[0001032975-20-000005:note_history:25]
In August 2018, the FASB issued ASU 2018-14, "Compensation - Retirement Benefits - Defined Benefits Plans - General (Subtopic 715-20): Disclosure Framework - Changes to the Disclosure Requirements for Defined Benefit Plans" (ASU 2018-14), which aims to improve the overall usefulness of disclosures to financial statement users and reduce unnecessary costs to companies when preparing defined benefit plan disclosures. ASU 2018-14 is effective for annual periods in fiscal years ending after December 15, 2020. Retrospective adoption is required and early adoption is permitted. The Company does not expect the adoption of ASU 2018-14 will have a material impact on its consolidated financial statements and plans to adopt the standard effective April 1, 2020.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-07-23):
[0001032975-20-000033:note_history:26]
The Company had several uncommitted, unsecured bank lines of credit aggregating $81.9 million as of June 30, 2020. There are no financial covenants under these lines of credit with which the Company must comply. As of June 30, 2020, the Company had outstanding bank guarantees of $28.5 million under these lines of credit. There was no borrowing outstanding under these lines of credit as of June 30, 2020 or March 31, 2020.
  (was, 2020-01-23, similarity 0.9127):
[0001032975-20-000005:note_history:26]
The Company had several uncommitted, unsecured bank lines of credit aggregating $78.4 million as of December 31, 2019. There are no financial covenants under these lines of credit with which the Company must comply. As of December 31, 2019, the Company had outstanding bank guarantees of $17.1 million under these lines of credit. There was no borrowing outstanding under these lines of credit as of December 31, 2019 or March 31, 2019.
