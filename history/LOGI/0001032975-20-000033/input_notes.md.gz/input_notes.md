# LOGI notes — 0001032975-20-000033


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001032975-20-000033:notes:1]
[same as prior period, unchanged from 0001032975-20-000005:notes:1]

[0001032975-20-000033:notes:2]
[same as prior period, unchanged from 0001032975-20-000005:notes:2]

[0001032975-20-000033:notes:3]
Logitech International S.A, together with its consolidated subsidiaries, (Logitech or the Company) designs, manufactures and markets products that have an everyday place in people's lives, connecting them to the digital experiences they care about. More than 35 years ago, Logitech created products to improve experiences around the personal PC platform, and today it is a multi-brand, multi-category company designing products that enable better experiences consuming, sharing and creating any digital content such as computing, gaming, video and music, whether it is on a computer, mobile device or in the cloud.

[0001032975-20-000033:notes:4]
[same as prior period, unchanged from 0001032975-20-000005:notes:4]

[0001032975-20-000033:notes:5]
Logitech was founded in Switzerland in 1981 and Logitech International S.A. has been the parent holding company of Logitech since 1988. Logitech International S.A. is a Swiss holding company with its registered office in Apples, Switzerland and headquarters in Lausanne, Switzerland, which conducts its business through subsidiaries in the Americas, Europe, Middle East and Africa (EMEA) and Asia Pacific. Shares of Logitech International S.A. are listed on both the SIX Swiss Exchange under the trading symbol LOGN and the Nasdaq Global Select Market under the trading symbol LOGI.

[0001032975-20-000033:notes:6]
[same as prior period, unchanged from 0001032975-20-000005:notes:8]

[0001032975-20-000033:notes:7]
The condensed consolidated financial statements include the accounts of Logitech and its subsidiaries. All intercompany balances and transactions have been eliminated. The condensed consolidated financial statements are presented in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and therefore do not include all the information required by GAAP for complete financial statements. The condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended March 31, 2020, included in its Annual Report on Form 10-K filed with the Securities and Exchange Commission (SEC) on May 27, 2020.

[0001032975-20-000033:notes:8]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three months ended June 30, 2020 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2021, or any future periods.

[0001032975-20-000033:notes:9]
[same as prior period, unchanged from 0001032975-20-000005:notes:11]

[0001032975-20-000033:notes:10]
Other than the recent accounting pronouncements adopted and discussed below under Recent Accounting Pronouncements Adopted and Summary of Significant Accounting Policies, there have been no material changes in the Company’s significant accounting policies during the three months ended June 30, 2020 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2020.

[0001032975-20-000033:notes:11]
[same as prior period, unchanged from 0001032975-20-000005:notes:13]

[0001032975-20-000033:notes:12]
The preparation of financial statements in conformity with U.S. GAAP requires management to make judgments, estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Significant estimates and assumptions made by management involve fair value of  goodwill and intangible assets acquired from business acquisitions, valuation of right-of-use assets, valuation of investment in privately held companies classified under Level 3 of the fair value hierarchy, pensions obligations, warranty liabilities, accruals for customer incentives, cooperative marketing, and pricing programs (Customer Programs) and related breakage when appropriate, accrued sales return liability, inventory valuation, share-based compensation expense, uncertain tax positions, and valuation allowances for deferred tax assets. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ materially from these estimates.

[0001032975-20-000033:notes:13]
Risks and Uncertainties

[0001032975-20-000033:notes:14]
We are subject to risks and uncertainties as a result of the novel coronavirus (COVID-19) and the measures taken by many countries in response have contributed to a general slowdown in the global economy and adversely affected, and could in the future continue to adversely affect, the Company's business and operations. Capital markets and economies worldwide have also been negatively impacted by COVID-19 and it is still unclear how lasting and deep the economic impacts will be. During the three months ended June 30, 2020, as well as in the fourth quarter of fiscal year 2020, the COVID-19 pandemic had mixed effects on the Company’s results of operations, and it may continue to have mixed or adverse effects. While there was high demand and consumption of certain of our products that led to increased sales and operating income during the fourth quarter of fiscal year 2020 and the first quarter of fiscal year 2021, at the same time the Company experienced disruptions to supply chain and logistics services, inventory constraints and increased logistics costs. The ongoing and full extent of the impact of the COVID-19 pandemic on the Company's business and operational and financial performance and condition is uncertain and will depend on many factors outside the Company's control, including but not limited to the timing, extent, duration and effects of the virus and any of its mutations, the development and availability of effective treatments and vaccines, the imposition of effective public safety and other protective measures, the impact of COVID-19 on the global economy and demand for the Company's products and services. Should the COVID-19 pandemic or global economic slowdown not improve or worsen, or if the Company's attempt to mitigate its impact on its operations and costs is not successful, the Company's business, results of operations, financial condition and prospects may be adversely affected.

[0001032975-20-000033:notes:15]
[same as prior period, unchanged from 0001032975-20-000005:notes:16]

[0001032975-20-000033:notes:16]
In June 2016, the FASB issued ASU 2016-13, "Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments" (ASU 2016-13), which was further updated and clarified by the FASB through issuance of additional related ASUs, replaces the incurred-loss impairment methodology and requires immediate recognition of estimated credit losses expected to occur for most financial assets, including trade receivables. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. The Company adopted this standard effective April 1, 2020, using a modified retrospective approach. Upon adoption, the Company updated its credit loss models to utilize a forward-looking current expected credit losses (CECL) model in place of the incurred loss methodology for financial instruments measured at amortized cost, including accounts receivable. The cumulative effect adjustment from adoption was not material to the Company's condensed consolidated financial statements.

[0001032975-20-000033:notes:17]
In August 2018, the FASB issued ASU 2018-13, "Fair Value Measurement (Topic 820): Disclosure Framework - Changes to the Disclosure Requirements for Fair Value Measurements" (ASU 2018-13), which eliminates, adds and modifies certain disclosure requirements for fair value measurements, including eliminating the requirement to disclose the amount of and reasons for transfers between Level 1 and Level 2 of the fair value hierarchy, and requiring the range and weighted average used to develop significant unobservable inputs for Level 3 fair value measurements.  Some of these disclosure changes must be applied prospectively while others retrospectively depending on requirement. The Company adopted this standard effective April 1, 2020. The adoption of ASU 2018-13 did not have a material impact to the Company's condensed consolidated financial statements.

[0001032975-20-000033:notes:18]
In August 2018, the FASB issued ASU 2018-14, "Compensation - Retirement Benefits - Defined Benefits Plans - General (Subtopic 715-20): Disclosure Framework - Changes to the Disclosure Requirements for Defined Benefit Plans" (ASU 2018-14), which requires that the Company remove various disclosures that no longer are considered cost-beneficial, namely amounts in accumulated other comprehensive income expected to be recognized as components of net periodic benefit cost over the next fiscal year.  Further, ASU 2018-14 requires disclosure or clarification of the reasons for significant gains or losses related to changes in the benefit obligation for the period.  The Company adopted this standard effective April 1, 2020 using a retrospective approach and the updated disclosures will be included in the Company's Form 10-K for the fiscal year ending March 31, 2021. The adoption of ASU 2018-14 did not have an impact on the Company's condensed consolidated financial statements.

[0001032975-20-000033:notes:19]
Recent Accounting Pronouncements To Be Adopted

[0001032975-20-000033:notes:20]
In December 2019, the FASB issued ASU 2019-12, "Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes" (ASU 2019-12), which eliminates certain exceptions for recognizing deferred taxes for investments, performing intraperiod allocation and calculating income taxes in interim periods. This ASU also includes guidance to reduce complexity in certain areas, including recognizing deferred taxes for tax goodwill and allocating taxes to members of a consolidated group. ASU 2019-12 is effective for annual and interim periods in fiscal years beginning after December 15, 2020. Early adoption is permitted. The Company is currently assessing the impact of ASU 2019-12 on its consolidated financial statements and plans to adopt the standard effective April 1, 2021.


## us-gaap:EarningsPerShareTextBlock

[0001032975-20-000033:notes:21]
[same as prior period, unchanged from 0001032975-20-000005:notes:50]

[0001032975-20-000033:notes:22]
The following table summarizes the computations of basic and diluted net income per share for the three months ended June 30, 2020 and June 30, 2019 (in thousands, except per share amounts):

[0001032975-20-000033:notes:23]
|  |  | Three Months EndedJune 30, |
|  |  | 2020 |  | 2019 |
| Net income |  | $ | 72,073 |  |  | $ | 45,345 |  |
| Shares used in net income per share computation: |  |  |  |  |  |  |
| Weighted average shares outstanding - basic |  | 167,612 |  |  | 166,302 |  |
| Effect of potentially dilutive equivalent shares |  | 2,515 |  |  | 2,495 |  |
| Weighted average shares outstanding - diluted |  | 170,127 |  |  | 168,797 |  |
| Net income per share: |  |  |  |  |  |  |
| Basic |  | $ | 0.43 |  |  | $ | 0.27 |  |
| Diluted |  | $ | 0.42 |  |  | $ | 0.27 |  |

[0001032975-20-000033:notes:24]
Share equivalents attributable to outstanding stock options, restricted stock units ("RSUs") and employee share purchase rights (ESPP) totaling 1.4 million and 2.0 million for the three months ended June 30, 2020 and 2019, respectively, were excluded from the calculation of diluted net income per share because the combined exercise price and average unamortized grant date fair value upon exercise of these options and ESPP or vesting of RSUs were greater than the average market price of the Company's shares during the periods presented herein, and therefore their inclusion would have been anti-dilutive. The majority of performance-based awards were not included because all necessary conditions have not been satisfied by the end of the respective period, and those shares were not issuable if the end of the reporting period were the end of the performance contingency period.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001032975-20-000033:notes:25]
[same as prior period, unchanged from 0001032975-20-000005:notes:54]

[0001032975-20-000033:notes:26]
[same as prior period, unchanged from 0001032975-20-000005:notes:55]

[0001032975-20-000033:notes:27]
As of June 30, 2020, the Company offers the 2006 Employee Share Purchase Plan, as amended and restated (Non-U.S.) (2006 ESPP), the 1996 Employee Share Purchase Plan (U.S.), as amended and restated (1996 ESPP), the 2006 Stock Incentive Plan, as amended and restated (2006 Plan), and the 2012 Stock Inducement Equity Plan (2012 Plan).

[0001032975-20-000033:notes:28]
The following table summarizes the share-based compensation expense and total income tax benefit recognized for share-based awards for the three months ended June 30, 2020 and 2019 (in thousands):

[0001032975-20-000033:notes:29]
|  |  | Three Months EndedJune 30, |
|  |  | 2020 |  | 2019 |
| Cost of goods sold |  | $ | 1,400 |  |  | $ | 1,158 |  |
| Marketing and selling |  | 8,792 |  |  | 6,849 |  |
| Research and development |  | 3,103 |  |  | 2,154 |  |
| General and administrative |  | 6,820 |  |  | 2,057 |  |
| Total share-based compensation expense |  | 20,115 |  |  | 12,218 |  |
| Income tax benefit |  | (8,111 | ) |  | (6,800 | ) |
| Total share-based compensation expense, net of income tax benefit |  | $ | 12,004 |  |  | $ | 5,418 |  |

[0001032975-20-000033:notes:30]
[same as prior period, unchanged from 0001032975-20-000005:notes:59]

[0001032975-20-000033:notes:31]
As of June 30, 2020 and 2019, the balance of capitalized share-based compensation included in inventory was $0.9 million and $0.9 million, respectively.

[0001032975-20-000033:notes:32]
[same as prior period, unchanged from 0001032975-20-000005:notes:61]

[0001032975-20-000033:notes:33]
Certain of the Company’s subsidiaries sponsor defined benefit pension plans or non-retirement post-employment benefits covering substantially all of their employees. Benefits are provided based on employees’ years of service and earnings, or in accordance with applicable employee benefit regulations. The Company’s practice is to fund amounts sufficient to meet the requirements set forth in the applicable employee benefit and tax regulations. The costs recorded of $2.7 million and $2.4 million for the three months ended June 30, 2020 and 2019, respectively, were primarily related to service costs.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001032975-20-000033:notes:34]
[same as prior period, unchanged from 0001032975-20-000005:notes:63]

[0001032975-20-000033:notes:35]
[same as prior period, unchanged from 0001032975-20-000005:notes:64]

[0001032975-20-000033:notes:36]
The canton of Vaud enacted the Federal Act on Tax Reform and AHV Financing ("TRAF"), a major reform to better align the Swiss tax system with international tax standards on March 10, 2020 to take effect as of January 1, 2020.  The longstanding tax ruling from the canton of Vaud was applicable through December 31, 2019.

[0001032975-20-000033:notes:37]
The income tax provision for the three months ended June 30, 2020 was $14.0 million based on an effective income tax rate of 16.3% of pre-tax income, compared to an income tax provision of $6.5 million based on an effective income tax rate of 12.6% of pre-tax income for the three months ended June 30, 2019.

[0001032975-20-000033:notes:38]
The change in the effective income tax rate for the three months ended June 30, 2020, compared to the same period ended June 30, 2019, was primarily due to the mix of income and losses in the various tax jurisdictions which the Company operates. The Swiss income tax provision in each period represents the income tax provision at the full statutory income tax rate of 13.63%. In the three months ended June 30, 2019 when TRAF was yet to be enacted at the federal and cantonal levels, the transition income tax provision was quantified at the full statutory income tax rate of 13.63% because at the time the canton of Vaud permitted the application of the longstanding tax ruling only through March 31, 2019. There were discrete tax benefits of $5.0 million and $1.0 million from the recognition of excess tax benefits in the United States and reversal of uncertain tax positions from the expiration of statutes of limitations, respectively, in the three-month period ended June 30, 2020, compared with $5.8 million and $1.2 million, respectively, in the three-month period ended June 30, 2019.

[0001032975-20-000033:notes:39]
As of June 30, 2020 and March 31, 2020, the total amount of unrecognized tax benefits due to uncertain tax positions was $144.2 million and $140.8 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-20-000033:notes:40]
As of June 30, 2020 and March 31, 2020, the Company had $44.3 million and $40.8 million, respectively, in non-current income taxes payable including interest and penalties, related to the Company's income tax liability for uncertain tax positions.

[0001032975-20-000033:notes:41]
The Company recognizes interest and penalties related to unrecognized tax positions in the income tax provision. As of June 30, 2020 and March 31, 2020, the Company had $4.7 million and $4.5 million, respectively, of accrued interest and penalties related to uncertain tax positions in non-current income taxes payable.

[0001032975-20-000033:notes:42]
Although the Company has adequately provided for uncertain tax positions, the provisions related to these positions may change as revised estimates are made or the underlying matters are settled or otherwise resolved. During fiscal year 2021, the Company continues to review its tax positions and provide for or reverse unrecognized tax benefits as they arise. During the next twelve months, it is reasonably possible that the amount of unrecognized tax benefits could increase or decrease significantly due to changes in tax law in various jurisdictions, new tax audits and changes in the U.S. dollar as compared to other currencies. Excluding these factors, uncertain tax positions may decrease by as much as $4.7 million from the lapse of the statutes of limitations in various jurisdictions during the next twelve months.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001032975-20-000033:notes:43]
[same as prior period, unchanged from 0001032975-20-000005:notes:73]

[0001032975-20-000033:notes:44]
The following table presents the components of certain balance sheet asset amounts as of June 30 and March 31, 2020 (in thousands):

[0001032975-20-000033:notes:45]
|  |  | June 30, 2020 |  | March 31, 2020 |
| Accounts receivable, net: |  |  |  |  |  |  |
| Accounts receivable |  | $ | 699,544 |  |  | $ | 597,939 |  |
| Allowance for doubtful accounts |  | (1,490 | ) |  | (1,894 | ) |
| Allowance for sales returns |  | (7,346 | ) |  | (6,599 | ) |
| Allowance for cooperative marketing arrangements |  | (39,224 | ) |  | (38,794 | ) |
| Allowance for customer incentive programs |  | (51,054 | ) |  | (55,741 | ) |
| Allowance for pricing programs |  | (100,124 | ) |  | (100,168 | ) |
|  |  | $ | 500,306 |  |  | $ | 394,743 |  |
| Inventories: |  |  |  |  |  |  |
| Raw materials |  | $ | 46,916 |  |  | $ | 56,052 |  |
| Finished goods |  | 224,264 |  |  | 173,197 |  |
|  |  | $ | 271,180 |  |  | $ | 229,249 |  |
| Other current assets: |  |  |  |  |  |  |
| Value-added tax receivables |  | $ | 35,417 |  |  | $ | 33,616 |  |
| Prepaid expenses and other assets |  | 47,053 |  |  | 41,304 |  |
|  |  | $ | 82,470 |  |  | $ | 74,920 |  |
| Property, plant and equipment, net: |  |  |  |  |  |  |
| Property, plant and equipment at cost |  | $ | 360,946 |  |  | $ | 346,506 |  |
| Accumulated depreciation and amortization |  | (281,465 | ) |  | (270,387 | ) |
|  |  | $ | 79,481 |  |  | $ | 76,119 |  |
| Other assets: |  |  |  |  |  |  |
| Deferred tax assets |  | $ | 237,213 |  |  | $ | 240,528 |  |
| Right-of-use assets |  | 31,564 |  |  | 25,557 |  |
| Trading investments for deferred compensation plan |  | 22,911 |  |  | 20,085 |  |
| Investments in privately held companies |  | 46,136 |  |  | 45,949 |  |
| Other assets |  | 13,307 |  |  | 12,900 |  |
|  |  | $ | 351,131 |  |  | $ | 345,019 |  |

[0001032975-20-000033:notes:46]
The following table presents the components of certain balance sheet liability amounts as of June 30 and March 31, 2020 (in thousands):

[0001032975-20-000033:notes:47]
|  |  | June 30, 2020 |  | March 31, 2020 |
| Accrued and other current liabilities: |  |  |  |  |  |  |
| Accrued personnel expenses |  | $ | 91,435 |  |  | $ | 104,423 |  |
| Accrued sales return liability |  | 28,233 |  |  | 30,267 |  |
| Accrued customer marketing, pricing and incentive programs |  | 118,240 |  |  | 130,220 |  |
| Operating lease liability |  | 12,312 |  |  | 10,945 |  |
| Warranty accrual |  | 25,471 |  |  | 25,905 |  |
| Contingent consideration |  | 29,000 |  |  | 23,284 |  |
| Other current liabilities |  | 140,135 |  |  | 129,980 |  |
|  |  | $ | 444,826 |  |  | $ | 455,024 |  |
| Other non-current liabilities: |  |  |  |  |  |  |
| Warranty accrual |  | $ | 13,979 |  |  | $ | 14,134 |  |
| Obligation for deferred compensation plan |  | 22,911 |  |  | 20,085 |  |
| Employee benefit plan obligations |  | 62,455 |  |  | 61,303 |  |
| Operating lease liability |  | 23,718 |  |  | 19,536 |  |
| Deferred tax liability |  | 1,931 |  |  | 1,931 |  |
| Other non-current liabilities |  | 2,451 |  |  | 2,285 |  |
|  |  | $ | 127,445 |  |  | $ | 119,274 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001032975-20-000033:notes:48]
[same as prior period, unchanged from 0001032975-20-000005:notes:79]

[0001032975-20-000033:notes:49]
[same as prior period, unchanged from 0001032975-20-000005:notes:80]

[0001032975-20-000033:notes:50]
[same as prior period, unchanged from 0001032975-20-000005:notes:81]

[0001032975-20-000033:notes:51]
[same as prior period, unchanged from 0001032975-20-000005:notes:82]

[0001032975-20-000033:notes:52]
[same as prior period, unchanged from 0001032975-20-000005:notes:83]

[0001032975-20-000033:notes:53]
[same as prior period, unchanged from 0001032975-20-000005:notes:84]

[0001032975-20-000033:notes:54]
|  |  | June 30, 2020 |  | March 31, 2020 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Level 1 |  | Level 2 |  | Level 3 |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 268,405 |  |  | $ | — |  |  | $ | — |  |  | $ | 564,952 |  |  | $ | — |  |  | $ | — |  |
| Trading investments for deferred compensation plan included in other assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 706 |  |  | $ | — |  |  | $ | — |  |  | $ | 846 |  |  | $ | — |  |  | $ | — |  |
| Money market funds |  | 8,539 |  |  | — |  |  | — |  |  | 7,147 |  |  | — |  |  | — |  |
| Mutual funds |  | 13,666 |  |  | — |  |  | — |  |  | 12,092 |  |  | — |  |  | — |  |
| Total of trading investments for deferred compensation plan |  | $ | 22,911 |  |  | $ | — |  |  | $ | — |  |  | $ | 20,085 |  |  | $ | — |  |  | $ | — |  |
| Currency exchange derivative assetsincluded in other current assets |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 129 |  |  | $ | — |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Contingent consideration for business acquisition included in accrued and other current liabilities |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 23,284 |  |
| Currency exchange derivative liabilitiesincluded in accrued and other current liabilities |  | $ | — |  |  | $ | 2,807 |  |  | $ | — |  |  | $ | — |  |  | $ | 719 |  |  | $ | — |  |

[0001032975-20-000033:notes:55]
The following table summarizes the change in the fair value of the Company's contingent consideration balance during the three months ended June 30, 2020 (in thousands):

[0001032975-20-000033:notes:56]
|  | Three Months EndedJune 30, |
| Beginning of the period | $ | 23,284 |  |
| Change in fair value of contingent consideration | 5,716 |  |
| End of the period (1) | $ | 29,000 |  |

[0001032975-20-000033:notes:57]
(1) As of June 30, 2020, the earn-out period is complete. The earn-out payment of $29.0 million is based on the actual net sales of Streamlabs services and no longer subject to fair value measurement and was accordingly transferred out of Level 3.  The expected earn-out payment is included in the accrued and other current liabilities of the unaudited condensed consolidated balance sheet.

[0001032975-20-000033:notes:58]
[same as prior period, unchanged from 0001032975-20-000005:notes:86]

[0001032975-20-000033:notes:59]
The marketable securities for the Company's deferred compensation plan were recorded at a fair value of $22.9 million and $20.1 million, as of June 30, 2020 and March 31, 2020, respectively, based on quoted market prices. Quoted market prices are observable inputs that are classified as Level 1 within the fair value hierarchy. Unrealized gains (losses) related to trading securities for the three months ended June 30, 2020 and 2019 were not material and are included in other income, net in the Company's condensed consolidated statements of operations.

[0001032975-20-000033:notes:60]
[same as prior period, unchanged from 0001032975-20-000005:notes:88]

[0001032975-20-000033:notes:61]
On October 31, 2019 (the "Streamlabs Acquisition Date"), the Company acquired all of the equity interests of General Workings, Inc. ("Streamlabs"). The contingent consideration for business acquisition arising from the Streamlabs Acquisition represents the future potential earn-out payments of $29.0 million payable in stock only upon the achievement of certain net sales for the period beginning on January 1, 2020 and ending on June 30, 2020. The fair value of the earn-out as of the Streamlabs Acquisition Date was $0.04 million, and increased to $23.3 million as of March 31, 2020, which was determined by using a Black-Scholes-Merton valuation model to calculate the probability of the earn-out threshold being met and times the value of the earn-out payment, and discounted at

[0001032975-20-000033:notes:62]
the risk-free rate. The valuation included significant assumptions and unobservable inputs such as the projected sales of Streamlabs over the earn-out period, the risk-free rate, and the net sales volatility. The fair value was increased by $5.7 million to $29.0 million as of June 30, 2020, based on actual sales. The stock payout is expected to be $29.0 million.  The fair value of the contingent consideration no longer needs to be remeasured at each reporting period, as the earn-out period has been completed.

[0001032975-20-000033:notes:63]
[same as prior period, unchanged from 0001032975-20-000005:notes:90]

[0001032975-20-000033:notes:64]
The Company has certain non-marketable investments included in other assets that are accounted for under the equity method of accounting, with a carrying value of $42.3 million and $42.1 million as of June 30, 2020 and March 31, 2020, respectively.

[0001032975-20-000033:notes:65]
[same as prior period, unchanged from 0001032975-20-000005:notes:92]

[0001032975-20-000033:notes:66]
Financial Assets.  The Company has certain investments without readily determinable fair values due to the absence of quoted market prices, the inherent lack of liquidity, and the fact that inputs used to measure fair value are unobservable and require management's judgment. When certain events or circumstances indicate that impairment may exist, the Company revalues the investments using various assumptions, including the financial metrics and ratios of comparable public companies. The carrying value is also adjusted for observable price changes with a same or similar security from the same issuer. The amount of these investments included in other assets as of June 30, 2020 and March 31, 2020 was $3.9 million. There was no impairment of these assets during the three months ended June 30, 2020 or 2019.

[0001032975-20-000033:notes:67]
Non-Financial Assets.  Goodwill, intangible assets, property, plant and equipment, and notes receivable, are not required to be measured at fair value on a recurring basis. However, if certain triggering events occur (or tested at least annually for goodwill) such that a non-financial instrument is required to be evaluated for impairment and an impairment is recorded to reduce the non-financial instrument's carrying value to the fair value as a result of such triggering events, the non-financial assets and liabilities are measured at fair value for the period such triggering events occur. There was no impairment of these assets during the three months ended June 30, 2020 or 2019.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001032975-20-000033:notes:68]
[same as prior period, unchanged from 0001032975-20-000005:notes:95]

[0001032975-20-000033:notes:69]
Under certain agreements with the respective counterparties to the Company’s derivative contracts, subject to applicable requirements, the Company is allowed to net settle transactions of the same type with a single net amount payable by one party to the other. However, the Company presents its derivative assets and derivative liabilities on a gross basis on the condensed consolidated balance sheets as of June 30, 2020 and March 31, 2020.

[0001032975-20-000033:notes:70]
The fair value of the Company’s derivative instruments was not material as of June 30, 2020 or March 31, 2020. The amount of gain (loss) recognized on derivatives not designated as hedging instruments was not material in all periods presented herein. The following table presents the amounts of gains (losses) on the Company’s derivative instruments designated as hedging instruments and their locations on its condensed consolidated statements of operations and condensed consolidated statements of comprehensive income for the three months ended June 30, 2020 and 2019 (in thousands):

[0001032975-20-000033:notes:71]
|  |  | Three Months EndedJune 30, |
|  |  | Amount of Gain (Loss)Deferred as a Component of AccumulatedOther Comprehensive Loss |  | Amount of Loss (Gain)Reclassified from Accumulated Other Comprehensive Loss to Costs of Goods Sold |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Cash flow hedges |  | $ | (2,367 | ) |  | $ | (943 | ) |  | $ | (330 | ) |  | $ | (226 | ) |

[0001032975-20-000033:notes:72]
[same as prior period, unchanged from 0001032975-20-000005:notes:100]

[0001032975-20-000033:notes:73]
The Company enters into cash flow hedge contracts to protect against exchange rate exposure of forecasted inventory purchases. These hedging contracts mature within four months. Gains and losses in the fair value of the effective portion of the hedges are deferred as a component of accumulated other comprehensive loss until the hedged inventory purchases are sold, at which time the gains or losses are reclassified to cost of goods sold. Cash flows from such hedges are classified as operating activities in the condensed consolidated statements of cash flows. Hedging relationships are discontinued when hedging contract is no longer eligible for hedge accounting, or is sold, terminated or exercised, or when Company removes hedge designation for the contract. Gains and losses in the fair value of the effective portion of the discontinued hedges continue to be reported in accumulated other comprehensive loss until the hedged inventory purchases are sold, unless it is probable that the forecasted inventory purchases will not occur by the end of the originally specified time period or within an additional two-month period of time thereafter. In all periods presented herein, there have been no forecasted inventory purchases that were probable to not occur by the end of the originally specified time period or within an additional two-month period of time thereafter. The notional amounts of foreign currency exchange forward contracts outstanding related to forecasted inventory purchases were $93.1 million as of June 30, 2020 and $48.0 million as of March 31, 2020. The Company had $2.9 million of net losses related to its cash flow hedges included in accumulated other comprehensive loss as of June 30, 2020 which will be reclassified into earnings within the next 12 months.

[0001032975-20-000033:notes:74]
[same as prior period, unchanged from 0001032975-20-000005:notes:102]

[0001032975-20-000033:notes:75]
The Company also enters into foreign currency exchange forward and swap contracts to reduce the short-term effects of currency exchange rate fluctuations on certain receivables or payables denominated in currencies other than the functional currencies of its subsidiaries. These contracts generally mature within one month. The primary risk managed by using forward and swap contracts is the currency exchange rate risk. The gains or losses on these contracts are recognized in other income, net in the condensed consolidated statements of operations based on the changes in fair value. The notional amounts of these contracts outstanding as of June 30, 2020 and March 31, 2020 were $73.3 million and $64.7 million, respectively. Open forward and swap contracts outstanding as of June 30, 2020 and March 31, 2020 consisted of contracts in Mexican Pesos, Japanese Yen, Canadian Dollars, Taiwan New Dollars and Australian Dollars to be settled at future dates at pre-determined exchange rates.

[0001032975-20-000033:notes:76]
[same as prior period, unchanged from 0001032975-20-000005:notes:104]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001032975-20-000033:notes:77]
[same as prior period, unchanged from 0001032975-20-000005:notes:105]

[0001032975-20-000033:notes:78]
The Company conducts its impairment analysis of goodwill annually at December 31 and as necessary, if changes in facts and circumstances indicate that it is more likely than not that the fair value of the Company’s reporting unit may be less than its carrying amount. There have been no events or circumstances during the three months ended June 30, 2020 that have required the Company to perform an interim assessment of goodwill.

[0001032975-20-000033:notes:79]
The following table summarizes the activities in the Company’s goodwill balance during the three months ended June 30, 2020 (in thousands):

[0001032975-20-000033:notes:80]
| As of March 31, 2020 |  | $ | 400,917 |  |
| Currency translation |  | 17 |  |
| As of June 30, 2020 |  | $ | 400,934 |  |

[0001032975-20-000033:notes:81]
[same as prior period, unchanged from 0001032975-20-000005:notes:110]

[0001032975-20-000033:notes:82]
|  |  | June 30, 2020 |  | March 31, 2020 |
|  |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |
| Trademark and trade names |  | $ | 45,570 |  |  | $ | (20,578 | ) |  | $ | 24,992 |  |  | $ | 45,570 |  |  | $ | (19,061 | ) |  | $ | 26,509 |  |
| Developed technology |  | 118,807 |  |  | (80,645 | ) |  | 38,162 |  |  | 118,807 |  |  | (77,126 | ) |  | 41,681 |  |
| Customer contracts/relationships |  | 90,610 |  |  | (34,955 | ) |  | 55,655 |  |  | 90,610 |  |  | (31,859 | ) |  | 58,751 |  |
| Total |  | $ | 254,987 |  |  | $ | (136,178 | ) |  | $ | 118,809 |  |  | $ | 254,987 |  |  | $ | (128,046 | ) |  | $ | 126,941 |  |


## us-gaap:DebtDisclosureTextBlock

[0001032975-20-000033:notes:83]
Financing Arrangements

[0001032975-20-000033:notes:84]
The Company had several uncommitted, unsecured bank lines of credit aggregating $81.9 million as of June 30, 2020. There are no financial covenants under these lines of credit with which the Company must comply. As of June 30, 2020, the Company had outstanding bank guarantees of $28.5 million under these lines of credit. There was no borrowing outstanding under these lines of credit as of June 30, 2020 or March 31, 2020.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001032975-20-000033:notes:85]
Commitments and Contingencies

[0001032975-20-000033:notes:86]
Product Warranties

[0001032975-20-000033:notes:87]
Changes in the Company’s warranty liability for the three months ended June 30, 2020 and 2019 were as follows (in thousands):

[0001032975-20-000033:notes:88]
|  | Three Months EndedJune 30, |
|  | 2020 |  | 2019 |
| Beginning of the period | $ | 40,039 |  |  | $ | 34,229 |  |
| Provision | 5,389 |  |  | 8,535 |  |
| Settlements | (6,161 | ) |  | (6,977 | ) |
| Currency translation | 183 |  |  | 27 |  |
| End of the period | $ | 39,450 |  |  | $ | 35,814 |  |

[0001032975-20-000033:notes:89]
Indemnifications

[0001032975-20-000033:notes:90]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of June 30, 2020, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

[0001032975-20-000033:notes:91]
The Company also indemnifies its current and former directors and certain of its current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. The Company is unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not limited, the obligations are conditional in nature and the facts and circumstances involved in any situation that might arise are variable.

[0001032975-20-000033:notes:92]
Legal Proceedings

[0001032975-20-000033:notes:93]
From time to time the Company is involved in claims and legal proceedings that arise in the ordinary course of its business. The Company is currently subject to several such claims and a small number of legal proceedings. The Company believes that these matters lack merit and intends to vigorously defend against them. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company’s defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company’s business, financial condition, cash flows or results of operations in a particular period. Any claims or proceedings against the Company, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain a necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company’s business.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001032975-20-000033:notes:94]
[same as prior period, unchanged from 0001032975-20-000005:notes:123]

[0001032975-20-000033:notes:95]
[same as prior period, unchanged from 0001032975-20-000005:notes:124]

[0001032975-20-000033:notes:96]
In March 2017, the Company's Board of Directors approved the 2017 share buyback program, which authorized the Company to use up to $250.0 million to purchase up to 17.3 million shares of its own shares. This share buyback program expired in April 2020. The Company did not repurchase any of its registered shares during the three months ended June 30, 2020.

[0001032975-20-000033:notes:97]
In May 2020, the Company's Board of Directors approved the 2020 share buyback program, which authorized the Company to use up to $250.0 million to purchase up to 17.3 million of its own shares. The new program will, upon implementation, replace the Company’s prior 2017 share buyback program. The Company's share buyback program is expected to remain in effect for a period of three years from its implementation. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Purchases may be started or stopped at any time without prior notice depending on market conditions and other factors.

[0001032975-20-000033:notes:98]
[same as prior period, unchanged from 0001032975-20-000005:notes:129]

[0001032975-20-000033:notes:99]
[same as prior period, unchanged from 0001032975-20-000005:notes:130]

[0001032975-20-000033:notes:100]
|  |  | Accumulated Other Comprehensive Income (Loss) |
|  |  | CumulativeTranslationAdjustment |  | DefinedBenefitPlan |  | Deferred Hedging Losses |  | Total |
| March 31, 2020 |  | $ | (100,418 | ) |  | $ | (20,016 | ) |  | $ | (226 | ) |  | $ | (120,660 | ) |
| Other comprehensive income (loss) |  | 1,239 |  |  | 1,147 |  |  | (2,697 | ) |  | (311 | ) |
| June 30, 2020 |  | $ | (99,179 | ) |  | $ | (18,869 | ) |  | $ | (2,923 | ) |  | $ | (120,971 | ) |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001032975-20-000033:notes:101]
[same as prior period, unchanged from 0001032975-20-000005:notes:133]

[0001032975-20-000033:notes:102]
[same as prior period, unchanged from 0001032975-20-000005:notes:134]

[0001032975-20-000033:notes:103]
Sales by product categories and sales channels, excluding intercompany transactions, for the three months ended June 30, 2020 and 2019 were as follows (in thousands):

[0001032975-20-000033:notes:104]
|  |  | Three Months EndedJune 30, |
|  |  | 2020 |  | 2019 |
| Pointing Devices |  | $ | 120,469 |  |  | $ | 121,983 |  |
| Keyboards & Combos |  | 145,360 |  |  | 128,679 |  |
| PC Webcams |  | 60,851 |  |  | 28,128 |  |
| Tablet & Other Accessories |  | 46,048 |  |  | 38,339 |  |
| Gaming |  | 181,903 |  |  | 134,515 |  |
| Video Collaboration |  | 130,074 |  |  | 73,424 |  |
| Mobile Speakers |  | 29,009 |  |  | 50,416 |  |
| Audio & Wearables |  | 71,365 |  |  | 58,624 |  |
| Smart Home |  | 6,810 |  |  | 9,864 |  |
| Other (1) |  | 5 |  |  | 253 |  |
| Total sales |  | $ | 791,894 |  |  | $ | 644,225 |  |

[0001032975-20-000033:notes:105]
[same as prior period, unchanged from 0001032975-20-000005:notes:137]

[0001032975-20-000033:notes:106]
Sales by geographic region (based on the customers’ locations) for the three months ended June 30, 2020 and 2019 were as follows (in thousands):

[0001032975-20-000033:notes:107]
|  |  | Three Months EndedJune 30, |
|  |  | 2020 |  | 2019 |
| Americas |  | $ | 356,184 |  |  | $ | 293,445 |  |
| EMEA |  | 210,771 |  |  | 179,106 |  |
| Asia Pacific |  | 224,939 |  |  | 171,674 |  |
| Total sales |  | $ | 791,894 |  |  | $ | 644,225 |  |

[0001032975-20-000033:notes:108]
[same as prior period, unchanged from 0001032975-20-000005:notes:140]

[0001032975-20-000033:notes:109]
The United States, Germany, and China each represented more than 10% of the total consolidated sales for each of the periods presented herein. No other countries represented 10% or more of the Company’s total consolidated sales for the periods presented herein.

[0001032975-20-000033:notes:110]
Switzerland, the Company’s home domicile, represented 2% of the Company's total consolidated sales for the three months ended June 30, 2020 and represented 3% of the Company's total consolidated sales for the three months ended June 30, 2019.

[0001032975-20-000033:notes:111]
Two customers of the Company each represented more than 10% of the total consolidated sales for each of the periods presented herein.

[0001032975-20-000033:notes:112]
[same as prior period, unchanged from 0001032975-20-000005:notes:144]

[0001032975-20-000033:notes:113]
|  |  | June 30, 2020 |  | March 31, 2020 |
| Americas |  | $ | 24,325 |  |  | $ | 26,636 |  |
| EMEA |  | 5,345 |  |  | 5,052 |  |
| Asia Pacific |  | 49,811 |  |  | 44,431 |  |
| Total property, plant and equipment, net |  | $ | 79,481 |  |  | $ | 76,119 |  |

[0001032975-20-000033:notes:114]
Property, plant and equipment, net in the United States and China were $24.1 million and $41.5 million, respectively, as of June 30, 2020, and $26.5 million and $36.6 million, respectively, as of March 31, 2020. No other countries represented 10% or more of the Company’s total consolidated property, plant and equipment, net as of June 30, 2020 or March 31, 2020. Property, plant and equipment, net in Switzerland, the Company’s home domicile, were $2.7 million and $2.3 million as of June 30, 2020 and March 31, 2020, respectively.
