# LOGI notes — 0001032975-15-000052


## logi:ScheduleOfBalanceSheetComponentsAssetsTableTextBlock

[0001032975-15-000052:notes:1]
The following table presents the components of certain balance sheet asset amounts as of September 30 and March 31, 2015 (in thousands):

[0001032975-15-000052:notes:2]
|  |  | September 30,2015 |  | March 31,2015 |
| Accounts receivable, net: |  |  |  |  |  |  |
| Accounts receivable |  | $ | 492,274 |  |  | $ | 344,455 |  |
| Allowance for doubtful accounts |  | (1,078 | ) |  | (1,093 | ) |
| Allowance for sales returns |  | (20,185 | ) |  | (17,901 | ) |
| Allowance for cooperative marketing arrangements |  | (34,938 | ) |  | (25,700 | ) |
| Allowance for customer incentive programs |  | (65,055 | ) |  | (48,497 | ) |
| Allowance for pricing programs |  | (96,288 | ) |  | (71,441 | ) |
|  |  | $ | 274,730 |  |  | $ | 179,823 |  |
| Inventories: |  |  |  |  |  |  |
| Raw materials |  | $ | 59,286 |  |  | $ | 36,376 |  |
| Finished goods |  | 268,768 |  |  | 234,354 |  |
|  |  | $ | 328,054 |  |  | $ | 270,730 |  |
| Other current assets: |  |  |  |  |  |  |
| Income tax and value-added tax receivables |  | $ | 25,662 |  |  | $ | 19,403 |  |
| Deferred tax assets |  | 28,879 |  |  | 27,790 |  |
| Prepaid expenses and other assets |  | 18,963 |  |  | 17,236 |  |
|  |  | $ | 73,504 |  |  | $ | 64,429 |  |
| Property, plant and equipment, net: |  |  |  |  |  |  |
| Property, plant and equipment |  | 376,795 |  |  | 349,235 |  |
| Less: accumulated depreciation and amortization |  | (268,611 | ) |  | (257,642 | ) |
|  |  | $ | 108,184 |  |  | $ | 91,593 |  |
| Other assets: |  |  |  |  |  |  |
| Deferred tax assets |  | $ | 36,799 |  |  | $ | 39,310 |  |
| Trading investments for deferred compensation plan |  | 15,577 |  |  | 17,237 |  |
| Other assets |  | 8,280 |  |  | 6,441 |  |
|  |  | $ | 60,656 |  |  | $ | 62,988 |  |


## logi:ScheduleOfBalanceSheetComponentsLiabilityTableTextBlock

[0001032975-15-000052:notes:3]
The following table presents the components of certain balance sheet liability amounts as of September 30 and March 31, 2015 (in thousands):

[0001032975-15-000052:notes:4]
|  |  | September 30,2015 |  | March 31,2015 |
| Accrued and other current liabilities: |  |  |  |  |  |  |
| Accrued personnel expenses |  | $ | 55,703 |  |  | $ | 50,015 |  |
| Indirect customer incentive programs |  | 26,660 |  |  | 19,730 |  |
| Accrued restructuring |  | 11,661 |  |  | 966 |  |
| Deferred revenue |  | 24,552 |  |  | 24,987 |  |
| Warranty accrual |  | 12,091 |  |  | 12,630 |  |
| Employee benefit plan obligation |  | 1,717 |  |  | 1,232 |  |
| Income taxes payable |  | 4,264 |  |  | 5,794 |  |
| Other current liabilities |  | 95,040 |  |  | 79,558 |  |
|  |  | $ | 231,688 |  |  | $ | 194,912 |  |
| Non-current liabilities: |  |  |  |  |  |  |
| Warranty accrual |  | $ | 8,308 |  |  | $ | 9,080 |  |
| Obligation for deferred compensation plan |  | 15,577 |  |  | 17,237 |  |
| Long term restructuring |  | 71 |  |  | 73 |  |
| Employee benefit plan obligation |  | 50,195 |  |  | 51,181 |  |
| Deferred rent |  | 10,767 |  |  | 11,519 |  |
| Deferred tax liability |  | 1,823 |  |  | 1,936 |  |
| Long term deferred revenue |  | 9,663 |  |  | 9,109 |  |
| Other non-current liabilities |  | 1,650 |  |  | 1,397 |  |
|  |  | $ | 98,054 |  |  | $ | 101,532 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001032975-15-000052:notes:5]
[same as prior period, unchanged from 0001032975-15-000032:notes:5]

[0001032975-15-000052:notes:6]
[same as prior period, unchanged from 0001032975-15-000032:notes:6]

[0001032975-15-000052:notes:7]
The condensed consolidated interim financial statements include the accounts of Logitech and its subsidiaries. All intercompany balances and transactions have been eliminated. The condensed consolidated financial statements are presented in accordance with accounting principles generally accepted in the United States of America (“GAAP”) for interim financial information and therefore do not include all the information required by GAAP for complete financial statements. They should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended March 31, 2015, included in its Annual Report on Form 10-K filed with the Securities and Exchange Commission (“SEC”) on June 5, 2015.  In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, financial position, comprehensive income, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and six months ended September 30, 2015 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2016, or any future periods.

[0001032975-15-000052:notes:8]
[same as prior period, unchanged from 0001032975-15-000032:notes:8]

[0001032975-15-000052:notes:9]
[same as prior period, unchanged from 0001032975-15-000032:notes:9]

[0001032975-15-000052:notes:10]
[same as prior period, unchanged from 0001032975-15-000032:notes:10]

[0001032975-15-000052:notes:11]
There have been no substantial changes in the Company’s significant accounting policies during the six months ended September 30, 2015 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2015.

[0001032975-15-000052:notes:12]
[same as prior period, unchanged from 0001032975-15-000032:notes:12]

[0001032975-15-000052:notes:13]
The preparation of financial statements in conformity with U.S. GAAP requires management to make judgments, estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Examples of significant estimates and assumptions made by management involve the fair value of goodwill, warranty liabilities, accruals for discretionary customer programs, sales return reserves, allowance for doubtful accounts, inventory valuation, restructuring charges, contingent liabilities, uncertain tax positions, and valuation allowances for deferred tax assets. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ materially from those estimates.

[0001032975-15-000052:notes:14]
[same as prior period, unchanged from 0001032975-15-000032:notes:14]

[0001032975-15-000052:notes:15]
In July 2015, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update No. 2015-11, "Simplifying the Measurement of Inventory (Topic 330)",  ("ASU 2015-11"). Topic 330, Inventory, currently requires an entity to measure inventory at the lower of cost or market, with market value represented by replacement cost, net realizable value or net realizable value less a normal profit margin. The amendments in ASU 2015-11 require an entity to measure inventory at the lower of cost or net realizable value. ASU 2015-11 is effective in the first quarter of fiscal year 2018 for the Company, with early adoption permitted. The Company does not expect the adoption of this guidance to have a material impact on its condensed consolidated financial statements.

[0001032975-15-000052:notes:16]
In May 2014, the FASB issued Accounting Standards Update No. 2014-9, "Revenue from Contracts with Customers (Topic 606)," ("ASU 2014-9"). ASU 2014-9 outlines a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. Under the new model, recognition of revenue occurs when a customer obtains control of promised goods or services in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. In addition, the new standard requires that reporting companies disclose the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. ASU 2014-09 was originally to be effective for the Company on April 1, 2017. In July 2015, the FASB affirmed a one-year deferral of the effective date of the new revenue standard. The new standard will become effective for the Company on April 1, 2018. Early application is permitted but not before the original effective date of annual periods beginning after December 15, 2016. The new standard is required to be applied retrospectively to each prior reporting period presented or retrospectively with the cumulative effect of initially applying it recognized at the date of initial application. The Company has not yet selected a transition method nor has it determined the impact of the new standard on its condensed consolidated financial statements.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001032975-15-000052:notes:17]
Commitments and Contingencies

[0001032975-15-000052:notes:18]
Product Warranties

[0001032975-15-000052:notes:19]
All of the Company’s peripherals products are covered by warranty to be free from defects in material and workmanship for periods ranging from one year to five years. At the time of sale, the Company accrues a warranty liability for estimated costs to provide products, parts or services to repair or replace products in satisfaction of the warranty obligation. The Company’s estimate of costs to fulfill its warranty obligations is based on historical experience and expectations of future conditions. When the Company experiences changes in warranty claim activity or costs associated with fulfilling those claims, the warranty liability is adjusted accordingly.

[0001032975-15-000052:notes:20]
Changes in the Company’s warranty liability for the three and six months ended September 30, 2015 and 2014 were as follows (in thousands):

[0001032975-15-000052:notes:21]
|  | Three Months Ended September 30, |  | Six Months Ended September 30, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Beginning of the period | $ | 21,284 |  |  | $ | 23,420 |  |  | $ | 21,710 |  |  | $ | 24,380 |  |
| Provision | 1,792 |  |  | 2,020 |  |  | 3,934 |  |  | 4,226 |  |
| Settlements | (2,677 | ) |  | (3,236 | ) |  | (5,245 | ) |  | (6,402 | ) |
| End of the period | $ | 20,399 |  |  | $ | 22,204 |  |  | $ | 20,399 |  |  | $ | 22,204 |  |

[0001032975-15-000052:notes:22]
Other Contingencies

[0001032975-15-000052:notes:23]
The Company is subject to an ongoing formal investigation by the Enforcement Division of the U.S. Securities and Exchange Commission ("SEC"), relating to certain issues including the accounting for Revue inventory valuation reserves that resulted in the restatement described in the Fiscal 2014 Form 10-K, revision to the Company’s consolidated financial statements concerning warranty accruals and amortization of intangible assets presented in the Company’s Amended Annual Report on Form10-K/A, filed on August 7, 2013, and the Company’s transactions with a distributor for Fiscal Year 2007 through Fiscal Year 2009. The Company has entered into an agreement with the Enforcement Staff to extend the statute of limitations. The Company is cooperating with the investigation and, after discussions with the Enforcement Staff, the Company recently made an offer of settlement to resolve the matter, which is subject to approval by the SEC.  The proposed settlement would be entered into by the Company without admitting or denying the SEC’s findings and would resolve alleged violations of certain provisions of the Securities Exchange Act of 1934 and related rules, including the anti-fraud provisions.  Under the terms of the proposed settlement, the Company would pay $7.5 million in a civil penalty and agree not to commit or cause any violations of certain provisions of the Securities Exchange Act of 1934 and related rules. There is no assurance that the proposal will be approved by the SEC. In accordance with U.S. GAAP, the Company has made a corresponding accrual in its financial statements.

[0001032975-15-000052:notes:24]
Guarantees

[0001032975-15-000052:notes:25]
Logitech Europe S.A. guaranteed payments of certain third-party contract manufacturers’ purchase obligations. As of September 30, 2015, the maximum amount of this guarantee was $3.8 million, of which $0.9 million of guaranteed purchase obligations were outstanding.

[0001032975-15-000052:notes:26]
Indemnifications

[0001032975-15-000052:notes:27]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of September 30, 2015, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

[0001032975-15-000052:notes:28]
The Company also indemnifies its current and former directors and certain of its current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. The Company is unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not limited, the obligations are conditional in nature and the facts and circumstances involved in any situation that might arise are variable.

[0001032975-15-000052:notes:29]
Legal Proceedings

[0001032975-15-000052:notes:30]
From time to time the Company is involved in claims and legal proceedings that arise in the ordinary course of its business. The Company is currently subject to several such claims and a small number of legal proceedings. The Company believes that these matters lack merit and intends to vigorously defend against them. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company’s defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company’s business, financial condition, cash flows or results of operations in a particular period. Any claims or proceedings against the Company, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company’s business.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001032975-15-000052:notes:31]
[same as prior period, unchanged from 0001032975-15-000032:notes:30]

[0001032975-15-000052:notes:32]
[same as prior period, unchanged from 0001032975-15-000032:notes:31]

[0001032975-15-000052:notes:33]
As of September 30, 2015, the Company offers the 2006 ESPP (2006 Employee Share Purchase Plan (Non-U.S.)), the 1996 ESPP (1996 Employee Share Purchase Plan (U.S.)), the 2006 Plan (2006 Stock Incentive Plan) and the 2012 Plan (2012 Stock Inducement Equity Plan).

[0001032975-15-000052:notes:34]
The following table summarizes the share-based compensation expense and related tax benefit recognized for the three and six months ended September 30, 2015 and 2014 (in thousands):

[0001032975-15-000052:notes:35]
|  |  | Three Months EndedSeptember 30, |  | Six Months Ended September 30, |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Cost of goods sold |  | $ | 580 |  |  | $ | 627 |  |  | $ | 1,185 |  |  | $ | 1,165 |  |
| Marketing and selling |  | 2,062 |  |  | 1,653 |  |  | 4,180 |  |  | 4,209 |  |
| Research and development |  | 756 |  |  | 552 |  |  | 1,543 |  |  | 1,396 |  |
| General and administrative |  | 3,110 |  |  | 3,229 |  |  | 6,342 |  |  | 6,229 |  |
| Restructuring |  | — |  |  | — |  |  | 7 |  |  | — |  |
| Total share-based compensation expense |  | 6,508 |  |  | 6,061 |  |  | 13,257 |  |  | 12,999 |  |
| Income tax provision (benefit) |  | 304 |  |  | (1,913 | ) |  | (1,033 | ) |  | (3,097 | ) |
| Total share-based compensation expense, net of income tax |  | $ | 6,812 |  |  | $ | 4,148 |  |  | $ | 12,224 |  |  | $ | 9,902 |  |

[0001032975-15-000052:notes:36]
As of September 30, 2015 and March 31, 2015, the Company capitalized $0.4 million and $0.5 million of stock-based compensation expenses as inventory, respectively.

[0001032975-15-000052:notes:37]
[same as prior period, unchanged from 0001032975-15-000032:notes:36]

[0001032975-15-000052:notes:38]
Certain of the Company’s subsidiaries sponsor defined benefit pension plans or non-retirement post-employment benefits covering substantially all of their employees. Benefits are provided based on employees’ years of service and earnings, or in accordance with applicable employee benefit regulations. The Company’s practice is to fund amounts sufficient to meet the requirements set forth in the applicable employee benefit and tax regulations. The cost recorded of $2.9 million and $1.9 million for the three months ended September 30, 2015 and 2014, respectively, and $5.8 million and $3.9 million for the six months ended September 30, 2015 and 2014, respectively, was primarily related to service costs.


## us-gaap:DebtDisclosureTextBlock

[0001032975-15-000052:notes:39]
Financing Arrangements

[0001032975-15-000052:notes:40]
The Company had several uncommitted, unsecured bank lines of credit aggregating $46.7 million as of September 30, 2015. There are no financial covenants under these lines of credit with which the Company must comply. As of September 30, 2015, the Company had outstanding bank guarantees of $18.2 million under these lines of credit. There was no borrowing outstanding under these lines of credit as of September 30, 2015 or March 31, 2015.


## us-gaap:EarningsPerShareTextBlock

[0001032975-15-000052:notes:41]
[same as prior period, unchanged from 0001032975-15-000032:notes:40]

[0001032975-15-000052:notes:42]
[same as prior period, unchanged from 0001032975-15-000032:notes:41]

[0001032975-15-000052:notes:43]
|  |  | Three Months EndedSeptember 30, |  | Six Months Ended September 30, |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Net income |  | $ | 18,097 |  |  | $ | 36,090 |  |  | $ | 25,534 |  |  | $ | 55,766 |  |
| Shares used in net income per share computation: |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding - basic |  | 163,515 |  |  | 163,230 |  |  | 163,957 |  |  | 163,121 |  |
| Effect of potentially dilutive equivalent shares |  | 2,326 |  |  | 2,835 |  |  | 2,395 |  |  | 2,828 |  |
| Weighted average shares outstanding - diluted |  | 165,841 |  |  | 166,065 |  |  | 166,352 |  |  | 165,949 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.11 |  |  | $ | 0.22 |  |  | $ | 0.16 |  |  | $ | 0.34 |  |
| Diluted |  | $ | 0.11 |  |  | $ | 0.22 |  |  | $ | 0.15 |  |  | $ | 0.34 |  |

[0001032975-15-000052:notes:44]
Share equivalents attributable to outstanding stock options and restricted stock units (RSUs) of 7.8 million and 8.3 million for the three months ended September 30, 2015 and 2014, respectively, and 7.6 million and 8.1 million for the six months ended September 30, 2015 and 2014, were anti-dilutive and excluded from the calculation of diluted net income per share.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001032975-15-000052:notes:45]
[same as prior period, unchanged from 0001032975-15-000032:notes:44]

[0001032975-15-000052:notes:46]
[same as prior period, unchanged from 0001032975-15-000032:notes:45]

[0001032975-15-000052:notes:47]
[same as prior period, unchanged from 0001032975-15-000032:notes:46]

[0001032975-15-000052:notes:48]
[same as prior period, unchanged from 0001032975-15-000032:notes:47]

[0001032975-15-000052:notes:49]
[same as prior period, unchanged from 0001032975-15-000032:notes:48]

[0001032975-15-000052:notes:50]
[same as prior period, unchanged from 0001032975-15-000032:notes:49]

[0001032975-15-000052:notes:51]
|  |  | September 30, 2015 |  | March 31, 2015 |
|  |  | Level 1 |  | Level 2 |  | Level 1 |  | Level 2 |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 35,050 |  |  | $ | — |  |  | $ | 264,647 |  |  | $ | — |  |
|  |  | $ | 35,050 |  |  | $ | — |  |  | $ | 264,647 |  |  | $ | — |  |
| Trading investments for deferred compensation plan: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 3,326 |  |  | $ | — |  |  | $ | 2,936 |  |  | $ | — |  |
| Mutual funds |  | 12,251 |  |  | — |  |  | 14,301 |  |  | — |  |
|  |  | $ | 15,577 |  |  | $ | — |  |  | $ | 17,237 |  |  | $ | — |  |
| Foreign exchange derivative assets |  | $ | — |  |  | $ | 806 |  |  | $ | — |  |  | $ | 2,080 |  |
| Foreign exchange derivative liabilities |  | $ | — |  |  | $ | 88 |  |  | $ | — |  |  | $ | 75 |  |

[0001032975-15-000052:notes:52]
There were no material Level 3 financial assets as of September 30 or March 31, 2015.

[0001032975-15-000052:notes:53]
[same as prior period, unchanged from 0001032975-15-000032:notes:52]

[0001032975-15-000052:notes:54]
The marketable securities for the Company's deferred compensation plan are recorded at a fair value of $15.6 million and $17.2 million as of September 30, 2015 and March 31, 2015, respectively, based on quoted market prices. Quoted market prices are observable inputs that are classified as Level 1 within the fair value hierarchy. Unrealized trading gains / (losses) related to trading securities for the three or six months ended September 30, 2015 and 2014 were not significant and are included in other expense, net.

[0001032975-15-000052:notes:55]
[same as prior period, unchanged from 0001032975-15-000032:notes:54]

[0001032975-15-000052:notes:56]
Under certain agreements with the respective counterparties to the Company’s derivative contracts, subject to applicable requirements, the Company is allowed to net settle transactions of the same type with a single net amount payable by one party to the other. However, the Company presents its derivative assets and derivative liabilities on a gross basis on the Condensed Consolidated Balance Sheets as of September 30, 2015 and March 31, 2015.

[0001032975-15-000052:notes:57]
The fair values of the Company’s derivative instruments not designated as hedging instruments were not material as of September 30, 2015 or March 31, 2015. The following table presents the fair values of the Company’s derivative instruments designated as hedging instruments and their accounting line presentation on its Condensed Consolidated Balance Sheets as of September 30, 2015 and March 31, 2015 (in thousands):

[0001032975-15-000052:notes:58]
|  |  | Derivatives |
|  |  | Asset |
|  |  | September 30,2015 |  | March 31,2015 |
| Cash flow hedges |  | $ | 806 |  |  | $ | 2,080 |  |

[0001032975-15-000052:notes:59]
The amount of gain (loss) recognized on derivatives not designated as hedging instruments were not material in all periods presented herein. The following table presents the amounts of gains (losses) on the Company’s derivative instruments designated as hedging instruments and their locations on its condensed consolidated statements of operations and condensed consolidated statements of comprehensive income for the three and six months ended September 30, 2015 and 2014 (in thousands):

[0001032975-15-000052:notes:60]
|  |  | Three Months EndedSeptember 30, |
|  |  | Amount of Gain (Loss) Deferred as a Component of Accumulated Other Comprehensive Loss After Reclassification to Costs of Goods Sold |  | Amount of Loss (Gain) Reclassified from Accumulated Other Comprehensive Loss to Costs of Goods Sold |  | Amount of Gain (Loss) Immediately Recognized inOther Expense, Net |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Cash flow hedges |  | $ | 1,060 |  |  | $ | 3,290 |  |  | $ | (28 | ) |  | $ | (215 | ) |  | $ | 75 |  |  | $ | (1 | ) |

[0001032975-15-000052:notes:61]
|  |  | Six Months Ended September 30, |
|  |  | Amount of Gain (Loss) Deferred as a Component of Accumulated Other Comprehensive Loss After Reclassification to Costs of Goods Sold |  | Amount of Loss (Gain) Reclassified from Accumulated Other Comprehensive Loss to Costs of Goods Sold |  | Amount of Gain (Loss) Immediately Recognized inOther Expense, Net |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Cash flow hedges |  | $ | (3,662 | ) |  | $ | 3,938 |  |  | $ | (2,488 | ) |  | $ | 185 |  |  | $ | 143 |  |  | $ | (56 | ) |

[0001032975-15-000052:notes:62]
[same as prior period, unchanged from 0001032975-15-000032:notes:60]

[0001032975-15-000052:notes:63]
The Company enters into currency exchange forward contracts to hedge against exposure to changes in currency exchange rates related to its subsidiaries’ forecasted inventory purchases. The Company has one entity with a euro functional currency that purchases inventory in U.S. Dollars. The primary risk managed by using derivative instruments is the currency exchange rate risk. However, there can be no assurance the hedges will offset more than a portion of the financial impact resulting from movements in currency exchange rates. The Company has designated these derivatives as cash flow hedges. These hedging contracts mature within four months, and are denominated in the same currency as the underlying transactions. Gains and losses in the fair value of the effective portion of the hedges are deferred as a component of accumulated other comprehensive loss until the hedged inventory purchases are sold, at which time the gains or losses are reclassified to cost of goods sold. The Company assesses the effectiveness of the hedges by comparing changes in the spot rate of the currency underlying the forward contract with changes in the spot rate of the currency in which the forecasted transaction will be consummated. If the underlying transaction being hedged fails to occur or if a portion of the hedge does not generate offsetting changes in the currency exposure of forecasted inventory purchases, the Company immediately recognizes the gain or loss on the associated financial instrument in other expense, net. Such gains and losses were not material during the three or six months ended September 30, 2015 and 2014. Cash flows from such hedges are classified as operating activities in the condensed consolidated statements of cash flows. The notional amounts of currency exchange forward contracts outstanding related to forecasted inventory purchases were $63.4 million and $43.5 million at September 30, 2015 and March 31, 2015, respectively. The Company estimates that $0.3 million of net gains related to its cash flow hedges included in accumulated other comprehensive loss as of September 30, 2015 will be reclassified into earnings within the next 12 months.

[0001032975-15-000052:notes:64]
[same as prior period, unchanged from 0001032975-15-000032:notes:62]

[0001032975-15-000052:notes:65]
[same as prior period, unchanged from 0001032975-15-000032:notes:63]

[0001032975-15-000052:notes:66]
The notional amounts of currency exchange forward and swap contracts outstanding as of September 30 and March 31, 2015 relating to foreign currency receivables or payables were $60.8 million and $61.7 million, respectively. Open forward and swap contracts outstanding at September 30, 2015 and March 31, 2015 consisted of contracts in Mexican Pesos, Japanese Yen, British Pounds, Taiwanese Dollars and Australian Dollars to be settled at future dates at pre-determined exchange rates.

[0001032975-15-000052:notes:67]
[same as prior period, unchanged from 0001032975-15-000032:notes:65]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001032975-15-000052:notes:68]
[same as prior period, unchanged from 0001032975-15-000032:notes:66]

[0001032975-15-000052:notes:69]
In accordance with ASC Topic 350-10 (“ASC 350-10”), the Company conducts a goodwill impairment analysis annually at December 31 and as necessary if changes in facts and circumstances indicate that it is more likely than not that the fair value of the Company’s reporting units may be less than its carrying amount. There have been no events or circumstances during the six months ended September 30, 2015 that have required the Company to perform an interim assessment of goodwill.

[0001032975-15-000052:notes:70]
As of September 30, 2015 and March 31, 2015, all of the Company's goodwill is related to the Peripheral reporting unit. The following table summarizes the activity in the Company’s goodwill balance during the six months ended September 30, 2015 (in thousands):

[0001032975-15-000052:notes:71]
| As of March 31, 2015 |  | $ | 218,213 |  |
| Currency impact |  | (6 | ) |
| As of September 30, 2015 |  | $ | 218,207 |  |

[0001032975-15-000052:notes:72]
[same as prior period, unchanged from 0001032975-15-000032:notes:70]

[0001032975-15-000052:notes:73]
Amortization expense for other intangible assets was $0.5 million and $2.6 million for the three months ended September 30, 2015 and 2014, respectively, and $1.2 million and $5.4 million for the six months ended September 30, 2015 and 2014, respectively.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001032975-15-000052:notes:74]
[same as prior period, unchanged from 0001032975-15-000032:notes:72]

[0001032975-15-000052:notes:75]
[same as prior period, unchanged from 0001032975-15-000032:notes:73]

[0001032975-15-000052:notes:76]
The income tax provision for the three months ended September 30, 2015 was $7.0 million based on an effective income tax rate of 27.9% of pre-tax income, compared to an income tax provision of $5.5 million based on an effective income tax rate of 13.2% of pre-tax income for the three months ended September 30, 2014. The income tax provision for the six months ended September 30, 2015 was $5.7 million based on an effective income tax rate of 18.2% of pre-tax income, compared to an income tax provision of $8.6 million based on an effective income tax rate of 13.4% of pre-tax income for the six months ended September 30, 2014.

[0001032975-15-000052:notes:77]
The change in the effective income tax rate for the three and six months ended September 30, 2015, compared to the three and six months ended September 30, 2014, is due to the mix of income and losses in the various tax jurisdictions in which the Company operates. In addition, in determining the annual effective tax rate of fiscal year 2016, there is no tax benefit recognized for ordinary losses related to the video conferencing business as realization of the tax benefit of the losses is not assured beyond any reasonable doubt. In the three months ended September 30, 2015, a discrete tax provision of $1.5 million resulting from a write-off to a deferred tax asset related to stock equity awards for the video conferencing business was largely offset by a discrete tax benefit from the reversal of uncertain tax positions from the expiration of statutes of limitations. In the three months ended September 30, 2014, there was a discrete tax benefit of $1.7 million, primarily from the reversal of uncertain tax positions resulting from the expiration of statues of limitations and audit settlements in certain jurisdictions.

[0001032975-15-000052:notes:78]
There was a discrete tax benefit of $2.2 million and $0.8 million in the six months ended September 30, 2015 and 2014, respectively, resulting from the preferential income tax rate reduction pursuant to the High and New Technology Enterprise Program in China.

[0001032975-15-000052:notes:79]
As of September 30 and March 31, 2015, the total amount of unrecognized tax benefits due to uncertain tax positions was $80.4 million and $79.0 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-15-000052:notes:80]
The Company had $74.4 million in non-current income taxes payable and $0.1 million in current income taxes payable, including interest and penalties, related to our income tax liability for uncertain tax positions as of September 30, 2015, compared to $72.1 million in non-current income taxes payable and $0.1 million in current income taxes payable as of March 31, 2015.

[0001032975-15-000052:notes:81]
The Company recognizes interest and penalties related to unrecognized tax positions in income tax expense. As of September 30 and March 31, 2015, the Company had $4.7 million and $4.9 million of accrued interest and penalties related to uncertain tax positions, respectively.

[0001032975-15-000052:notes:82]
Although the Company has adequately provided for uncertain tax positions, the provisions on these positions may change as revised estimates are made or the underlying matters are settled or otherwise resolved. During fiscal year 2016, the Company will continue to review its tax positions and provide for or reverse unrecognized tax benefits as issues arise. During the next 12 months, it is reasonably possible that the amount of unrecognized tax benefits could increase or decrease significantly due to changes in tax law in various jurisdictions, new tax audits and changes in the U.S. dollar as compared to other currencies. Excluding these factors, uncertain tax positions may decrease by as much as $17.2 million from the lapse of the statutes of limitations in various jurisdictions during the next 12 months.


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0001032975-15-000052:notes:83]
[same as prior period, unchanged from 0001032975-15-000032:notes:79]

[0001032975-15-000052:notes:84]
|  |  | September 30,2015 |  | March 31,2015 |
| Americas |  | $ | 46,990 |  |  | $ | 48,527 |  |
| EMEA |  | 2,993 |  |  | 3,584 |  |
| Asia Pacific |  | 58,201 |  |  | 39,482 |  |
|  |  | $ | 108,184 |  |  | $ | 91,593 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001032975-15-000052:notes:85]
[same as prior period, unchanged from 0001032975-15-000032:notes:81]

[0001032975-15-000052:notes:86]
[same as prior period, unchanged from 0001032975-15-000032:notes:82]

[0001032975-15-000052:notes:87]
During the first quarter of fiscal year 2016, the Company implemented a restructuring plan to exit the OEM business, reorganize Lifesize to sharpen its focus on its cloud-based offering, and streamline the Company's overall cost structure through product, overhead and infrastructure cost reductions with a targeted resource realignment. Restructuring charges incurred during the six months ended September 30, 2015 under this plan primarily consisted of severance and other ongoing and one-time termination benefits. Charges and other costs related to the workforce reduction and structure realignment are presented as restructuring charges in the Condensed Consolidated Statements of Operations. The Company expects to incur approximately $22 million to $25 million under this restructuring plan, including approximately $20.3 million to 23.3 million for cash severance and other personnel costs, and expects to substantially complete this restructuring within the next 6 months.

[0001032975-15-000052:notes:88]
The following tables summarize restructuring related activities during the three and six months ended September 30, 2015:

[0001032975-15-000052:notes:89]
|  |  | Restructuring |
|  |  | TerminationBenefits |  | Lease ExitCosts |  | Other |  | Total |
| Accrual balance at March 31, 2015 |  | $ | — |  |  | $ | 1,039 |  |  | $ | — |  |  | $ | 1,039 |  |
| Charges, net |  | 12,794 |  |  | — |  |  | 201 |  |  | 12,995 |  |
| Cash payments |  | (4,675 | ) |  | (796 | ) |  | (151 | ) |  | (5,622 | ) |
| Accrual balance at June 30, 2015 |  | $ | 8,119 |  |  | $ | 243 |  |  | $ | 50 |  |  | $ | 8,412 |  |
| Charges, net |  | 8,566 |  |  | 38 |  |  | 92 |  |  | 8,696 |  |
| Cash payments |  | (5,112 | ) |  | (122 | ) |  | (142 | ) |  | (5,376 | ) |
| Accrual balance at September 30, 2015 |  | $ | 11,573 |  |  | $ | 159 |  |  | $ | — |  |  | $ | 11,732 |  |


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001032975-15-000052:notes:90]
Net sales to unaffiliated customers by geographic region (based on the customers’ location) for the three and six months ended September 30, 2015 and 2014 were as follows (in thousands):

[0001032975-15-000052:notes:91]
|  |  | Three Months EndedSeptember 30, |  | Six Months Ended September 30, |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Americas |  | $ | 239,742 |  |  | $ | 226,091 |  |  | $ | 466,429 |  |  | $ | 437,622 |  |
| EMEA |  | 173,148 |  |  | 189,571 |  |  | 300,514 |  |  | 343,271 |  |
| Asia Pacific |  | 126,972 |  |  | 114,649 |  |  | 243,239 |  |  | 231,621 |  |
| Total net sales |  | $ | 539,862 |  |  | $ | 530,311 |  |  | $ | 1,010,182 |  |  | $ | 1,012,514 |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001032975-15-000052:notes:92]
[same as prior period, unchanged from 0001032975-15-000032:notes:88]

[0001032975-15-000052:notes:93]
|  |  | Accumulated Other Comprehensive Income (Loss) |
|  |  | CumulativeTranslationAdjustment (1) |  | DefinedBenefitPlan (1) |  | DeferredHedgingGains (Losses) |  | Total |
| March 31, 2015 |  | $ | (90,224 | ) |  | $ | (26,964 | ) |  | $ | 3,951 |  |  | $ | (113,237 | ) |
| Other comprehensive income (loss) |  | 2,610 |  |  | 1,025 |  |  | (3,662 | ) |  | (27 | ) |
| September 30, 2015 |  | $ | (87,614 | ) |  | $ | (25,939 | ) |  | $ | 289 |  |  | $ | (113,264 | ) |

[0001032975-15-000052:notes:94]
(1)        Tax effect was not significant as of September 30 or March 31, 2015.


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001032975-15-000052:notes:95]
Net sales by product categories and sales channels, excluding intercompany transactions, for the three and six months ended September 30, 2015 and 2014 were as follows (in thousands):

[0001032975-15-000052:notes:96]
|  |  | Three Months EndedSeptember 30, |  | Six Months Ended September 30, |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Peripherals: |  |  |  |  |  |  |  |  |  |  |  |  |
| Mobile Speakers |  | $ | 80,550 |  |  | $ | 48,538 |  |  | $ | 121,094 |  |  | $ | 77,367 |  |
| Gaming |  | 67,624 |  |  | 47,506 |  |  | 111,294 |  |  | 94,382 |  |
| Video Collaboration |  | 20,059 |  |  | 13,808 |  |  | 41,235 |  |  | 29,033 |  |
| Tablet & Other Accessories |  | 18,549 |  |  | 28,158 |  |  | 37,358 |  |  | 59,874 |  |
| Growth |  | 186,782 |  |  | 138,010 |  |  | 310,981 |  |  | 260,656 |  |
| Pointing Devices |  | 124,668 |  |  | 127,693 |  |  | 241,653 |  |  | 240,735 |  |
| Keyboards & Combos |  | 102,098 |  |  | 105,677 |  |  | 207,927 |  |  | 211,166 |  |
| Audio-PC & Wearables |  | 46,342 |  |  | 57,191 |  |  | 92,041 |  |  | 105,739 |  |
| PC Webcams |  | 23,360 |  |  | 25,282 |  |  | 45,041 |  |  | 45,745 |  |
| Home Control |  | 12,610 |  |  | 18,776 |  |  | 22,864 |  |  | 31,108 |  |
| Profit Maximization |  | 309,078 |  |  | 334,619 |  |  | 609,526 |  |  | 634,493 |  |
| Retail Strategic Sales |  | 495,860 |  |  | 472,629 |  |  | 920,507 |  |  | 895,149 |  |
| Non-Strategic |  | 403 |  |  | 834 |  |  | 1,144 |  |  | 2,127 |  |
| Retail |  | 496,263 |  |  | 473,463 |  |  | 921,651 |  |  | 897,276 |  |
| OEM |  | 22,231 |  |  | 28,394 |  |  | 44,529 |  |  | 61,027 |  |
|  |  | 518,494 |  |  | 501,857 |  |  | 966,180 |  |  | 958,303 |  |
| Video conferencing |  | 21,368 |  |  | 28,454 |  |  | 44,002 |  |  | 54,211 |  |
|  |  | $ | 539,862 |  |  | $ | 530,311 |  |  | $ | 1,010,182 |  |  | $ | 1,012,514 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001032975-15-000052:notes:97]
Net sales and operating income (loss) for the Company’s operating segments for the three and six months ended September 30, 2015 and 2014 were as follows (in thousands):

[0001032975-15-000052:notes:98]
|  |  | Three Months EndedSeptember 30, |  | Six Months Ended September 30, |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Net sales: |  |  |  |  |  |  |  |  |  |  |  |  |
| Peripherals |  | $ | 518,494 |  |  | $ | 501,857 |  |  | $ | 966,180 |  |  | $ | 958,303 |  |
| Video conferencing |  | 21,368 |  |  | 28,454 |  |  | 44,002 |  |  | 54,211 |  |
|  |  | $ | 539,862 |  |  | $ | 530,311 |  |  | $ | 1,010,182 |  |  | $ | 1,012,514 |  |
| Segment operating income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |
| Peripherals |  | $ | 46,191 |  |  | $ | 50,587 |  |  | $ | 78,031 |  |  | $ | 84,154 |  |
| Video conferencing |  | (4,804 | ) |  | 171 |  |  | (9,205 | ) |  | (965 | ) |
|  |  | 41,387 |  |  | 50,758 |  |  | 68,826 |  |  | 83,189 |  |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring charges, net |  | (8,696 | ) |  | — |  |  | (21,691 | ) |  | — |  |
| Share-based compensation |  | (6,508 | ) |  | (6,061 | ) |  | (13,250 | ) |  | (12,999 | ) |
| Amortization of intangibles |  | (494 | ) |  | (2,576 | ) |  | (1,226 | ) |  | (5,358 | ) |
| Interest income, net |  | 192 |  |  | 355 |  |  | 456 |  |  | 613 |  |
| Other expense, net |  | (780 | ) |  | (885 | ) |  | (1,901 | ) |  | (1,083 | ) |
| Income before income taxes |  | $ | 25,101 |  |  | $ | 41,591 |  |  | $ | 31,214 |  |  | $ | 64,362 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001032975-15-000052:notes:99]
[same as prior period, unchanged from 0001032975-15-000032:notes:95]

[0001032975-15-000052:notes:100]
The Company has two reporting segments, peripherals and video conferencing, based on product markets and internal organizational structure. The peripherals segment encompasses the design, manufacturing and marketing of peripherals for PCs, tablets and other digital platforms. The video conferencing segment offers scalable high-definition, or HD, video communication endpoints, HD video conferencing systems with integrated monitors, video bridges, a cloud-based video conferencing solution and other infrastructure software and hardware to support large-scale video deployments and services to support these products. The Company’s reporting segments do not record revenue on sales between segments.

[0001032975-15-000052:notes:101]
Operating performance measures for the peripherals segment and the video conferencing segment are reported separately to the Company's Chief Executive Officer (“CEO”), who is considered to be the Company’s Chief Operating Decision Maker (“CODM”). The CEO periodically reviews information such as net sales and operating income (loss) for each operating segment to make business decisions. These operating performance measures do not include restructuring charges, net, share-based compensation expense and amortization of intangible assets, which are presented in the following financial information by operating segment as “other income (expense)”. Assets by operating segment are not presented since the Company does not present such data to the CODM.

[0001032975-15-000052:notes:102]
Restructuring charges for Peripherals and Video conferencing segments were $3.2 million and $5.5 million, respectively, for the three months ended September 30, 2015. Restructuring charges for Peripherals and Video conferencing segments were $14.7 million and $7.0 million, respectively, for the six months ended September 30, 2015.

[0001032975-15-000052:notes:103]
Certain products within the retail product categories presented in prior periods have been reclassified to conform to the current periods' presentation.

[0001032975-15-000052:notes:104]
Sales are attributed to countries on the basis of the customers’ locations. The United States represented 37% and 36% of the Company’s total consolidated net sales for the three months ended September 30, 2015 and 2014, respectively. No other single country represented more than 10% of the Company’s total consolidated net sales during those periods. One customer group of the Company’s peripheral operating segment represented 15% and 17% of sales for the three months ended September 30, 2015 and 2014, respectively.

[0001032975-15-000052:notes:105]
The United States represented 38% and 36% of the Company’s total consolidated net sales for the six months ended September 30, 2015 and 2014, respectively. No other single country represented more than 10% of the Company’s total consolidated net sales during those periods. One customer group of the Company’s peripheral operating segment represented 14% and 16% of sales for the six months ended September 30, 2015 and 2014, respectively.

[0001032975-15-000052:notes:106]
Revenues from sales to customers in Switzerland, the Company’s home domicile, represented 2% of the Company’s total consolidated net sales for all the periods presented herein.

[0001032975-15-000052:notes:107]
Long-lived assets in the United States and China were $46.8 million and $53.5 million as of September 30, 2015, respectively, and $48.3 million and $34.0 million at March 31, 2015, respectively. No other countries represented more than 10% of the Company’s total consolidated long-lived assets as of September 30 or March 31, 2015. Long-lived assets in Switzerland, the Company’s home domicile, were $1.3 million and $1.5 million at September 30 and March 31, 2015, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001032975-15-000052:notes:108]
[same as prior period, unchanged from 0001032975-15-000032:notes:102]

[0001032975-15-000052:notes:109]
Share Repurchase Program

[0001032975-15-000052:notes:110]
In March 2014, the Company’s Board of Directors approved the 2014 share buyback program, which authorizes the Company to use up to $250.0 million to purchase its own shares. The Company’s share buyback program is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market with consideration given to Logitech’s stock price, market conditions and other factors. During the three and six months ended September 30, 2015, 2.9 million and 3.5 million shares were repurchased for $40.0 million and  $48.8 million, respectively. There were no share repurchases during the three or six months ended September 30, 2014.

[0001032975-15-000052:notes:111]
Cash Dividends on Shares of Common Stock

[0001032975-15-000052:notes:112]
During the three and six months ended September 30, 2015,  the Company declared and paid cash dividends of CHF0.51 (USD equivalent of $0.53 ) per common share, totaling $85.9 million, on the Company’s outstanding common stock.

[0001032975-15-000052:notes:113]
Any future dividends will be subject to the approval of the Company's shareholders.

[0001032975-15-000052:notes:114]
[same as prior period, unchanged from 0001032975-15-000032:notes:104]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001032975-15-000052:notes:115]
[same as prior period, unchanged from 0001032975-15-000032:notes:105]
