# LOGI MD&A — 0001032975-15-000052


## mdna

[0001032975-15-000052:mdna:1]
[same as prior period, unchanged from 0001032975-15-000032:mdna:1]

[0001032975-15-000052:mdna:2]
[same as prior period, unchanged from 0001032975-15-000032:mdna:2]

[0001032975-15-000052:mdna:3]
[same as prior period, unchanged from 0001032975-15-000032:mdna:3]

[0001032975-15-000052:mdna:4]
[same as prior period, unchanged from 0001032975-15-000032:mdna:4]

[0001032975-15-000052:mdna:5]
Our peripherals segment encompasses the design, manufacturing and marketing of peripherals for PCs, tablets and other digital platforms. Within our peripherals segment, we classify our retail product categories as growth,

[0001032975-15-000052:mdna:6]
profit maximization, and non-strategic. Our growth product categories are: Mobile Speakers, Gaming, Video Collaboration and Tablet & Other Accessories. Our profit maximization categories are: Pointing Devices, Keyboards & Combos, Audio-PC & Wearables, PC Webcams, and Home Control.

[0001032975-15-000052:mdna:7]
[same as prior period, unchanged from 0001032975-15-000032:mdna:7]

[0001032975-15-000052:mdna:8]
[same as prior period, unchanged from 0001032975-15-000032:mdna:8]

[0001032975-15-000052:mdna:9]
We sell our peripherals products to a network of retailers including direct sales to retailers and indirect sales through distributors. Our worldwide retail network includes wholesale distributors, consumer electronics retailers, mass merchandisers, specialty electronics, computers and telecommunications stores, value-added resellers and online merchants. Sales of our retail peripherals were 91% and 89% of our net sales for the six months ended September 30, 2015 and 2014, respectively. The large majority of our revenues have historically been derived from sales of our peripherals products for use by consumers. Sales to OEM customers were 4% and 6% of our net sales for the six months ended September 30, 2015 and 2014, respectively. In April 2015, we announced our intent to exit the OEM business. We plan to exit our OEM business by the end of December 2015.

[0001032975-15-000052:mdna:10]
Our video conferencing segment encompasses the cloud-based video conferencing solution and design, manufacturing and marketing of Lifesize branded video conferencing products, infrastructure and services for the enterprise, public sector and other small to medium business markets. Video conferencing products include scalable high-definition, or HD, video communication endpoints, HD video conferencing systems with integrated monitors, video bridges, and other infrastructure software and hardware to support large-scale video deployments and services to support these products. The video conferencing segment maintains a separate marketing and sales organization, which sells Lifesize products and services worldwide, product development and product management. In April 2015, we started reorganizing Lifesize with the goal of de-emphasizing Lifesize’s legacy offerings more quickly to enable maximum traction with Lifesize Cloud. We plan to shrink our Lifesize business to grow the cloud opportunity faster. Also, as part of this restructuring, we are completing a structural separation of Lifesize from the rest of Logitech, which is designed to give us more flexibility with this business in the future. We sell our video conferencing products and services to distributors, value-added resellers, OEMs and, occasionally, direct enterprise customers. Sales of video conferencing products were 5% and 5% of our net sales in the six months ended September 30, 2015 and 2014, respectively.

[0001032975-15-000052:mdna:11]
We seek to fulfill the increasing demand for interfaces between people and the expanding digital world across multiple platforms and user environments. The interface evolves as platforms, user models and our target markets evolve. As access to digital information has expanded, we have extended our focus to mobile devices, the digital home, and the enterprise as access points to the Internet and the digital world. All of these platforms require interfaces that are customized according to how the devices are used. We believe that continued investment in product research and development is critical to creating the innovation required to strengthen our competitive advantage and to drive future sales growth. We are committed to identifying and meeting current and future consumer trends with new and improved product technologies, as well as leveraging the value of the Logitech and Lifesize brands from a competitive, channel partner and consumer experience perspective.

[0001032975-15-000052:mdna:12]
[same as prior period, unchanged from 0001032975-15-000032:mdna:12]

[0001032975-15-000052:mdna:13]
[same as prior period, unchanged from 0001032975-15-000032:mdna:13]

[0001032975-15-000052:mdna:14]
[same as prior period, unchanged from 0001032975-15-000032:mdna:14]

[0001032975-15-000052:mdna:15]
The preparation of financial statements and related disclosures in conformity with U.S. GAAP (Generally Accepted Accounting Principles in the United States of America) requires us to make judgments, estimates and assumptions that affect reported amounts of assets, liabilities, net sales and expenses, and the disclosure of contingent assets and liabilities.

[0001032975-15-000052:mdna:16]
[same as prior period, unchanged from 0001032975-15-000032:mdna:17]

[0001032975-15-000052:mdna:17]
[same as prior period, unchanged from 0001032975-15-000032:mdna:18]

[0001032975-15-000052:mdna:18]
[same as prior period, unchanged from 0001032975-15-000032:mdna:19]

[0001032975-15-000052:mdna:19]
Our total net sales for the three months ended September 30, 2015 increased 2% compared to the three months ended September 30, 2014, due to stronger retail sales, partially offset by declines in OEM and video conferencing sales.

[0001032975-15-000052:mdna:20]
Our total net sales for the six months ended September 30, 2015 remained flat compared to the six months ended September 30, 2014.

[0001032975-15-000052:mdna:21]
Total retail sales increased 5% and units sold decreased 4% during the three months ended September 30, 2015, compared to the three months ended September 30, 2014. We experienced an increase in sales of 7% in the Americas region, an increase in sales of 18% in the Asia Pacific region, and a decrease in sales of 5% in the EMEA region.

[0001032975-15-000052:mdna:22]
Total retail sales increased 3% and units sold decreased 1%, during the six months ended September 30, 2015, compared to the six months ended September 30, 2014. We experienced an increase in sales of 8% in the Americas region, an increase in sales of 11% in the Asia Pacific region, and a decrease in sales of 9% in the EMEA region.

[0001032975-15-000052:mdna:23]
OEM net sales decreased 22% and 27%, in the three and six months ended months ended September 30, 2015, respectively, compared to the three and six months ended September 30, 2014. The decline was expected as we announced, in April 2015, our plan to exit the OEM business.

[0001032975-15-000052:mdna:24]
Sales of video conferencing products in the three and six months ended September 30, 2015 decreased 25% and 19%, respectively, compared to the three and six months ended September 30, 2014. Lifesize is in the process of transitioning its product portfolio to the Lifesize Cloud, a software-as-a-service (SaaS) offering launched in fiscal year 2015. While sales of the cloud offering are growing, they are not yet large enough to offset the combination of the short-term portfolio transition and soft market conditions for video conferencing infrastructure.

[0001032975-15-000052:mdna:25]
Our gross margin for the three months ended September 30, 2015 decreased to 34.5% from 38.6% for the three months ended September 30, 2014. Our gross margin for the six months ended September 30, 2015 decreased to 35.4% from 38.2% for the six months ended September 30, 2014. The decrease in gross margin primarily reflects the unfavorable currency impact, partially offset by product cost savings and price increases during the three and six months ended September 30, 2015.

[0001032975-15-000052:mdna:26]
Operating expenses for the three months ended September 30, 2015 were 29.7% of net sales, compared to 30.7% in the same period of the prior fiscal year. The decrease was primarily due to the savings from marketing and general and administration expenses, favorable currency impact, reduction related to the prior year's independent Audit committee investigation and related expenses, partially offset by the restructuring charges related to the restructuring plan announced in April 2015.

[0001032975-15-000052:mdna:27]
Operating expenses for the six months ended September 30, 2015 were 32.2% of net sales, compared to 31.8% in the same period of the prior fiscal year. The increase was primarily due to restructuring charges related to the restructuring plan announced in April 2015, partially offset by the savings from marketing expenses, favorable currency impact, and reduction related to the prior year's independent Audit committee investigation and related expenses.

[0001032975-15-000052:mdna:28]
Net income for the three and six months ended September 30, 2015 was $18.1 million and $25.5 million, respectively, compared to net income of $36.1 million and $55.8 million in the three and six months ended September 30, 2014, respectively.

[0001032975-15-000052:mdna:29]
Given our global sales presence and the reporting of our financial results in U.S. Dollars, our financial results for the first half of fiscal year 2016 were affected by significant shifts in currency exchange rates compared to the first half of fiscal year 2015. See “Results of Operations” for information on the effect of currency exchange results on our net sales. If the U.S. Dollar remains at its current strong levels in comparison to other currencies, this will affect our results of operations in future periods as well.

[0001032975-15-000052:mdna:30]
[same as prior period, unchanged from 0001032975-15-000032:mdna:28]

[0001032975-15-000052:mdna:31]
Our sales of PC peripherals for use by consumers in the Americas and Europe have historically made up the large majority of our revenues. In the last several years, the PC market has changed dramatically and there continues to be significant weakness in the global market for new PCs. This weakness had a negative impact on our net sales in all of our PC-related categories with the exception of PC Gaming.

[0001032975-15-000052:mdna:32]
We believe our future growth will be determined by our ability to create innovative products in a timely manner across multiple digital platforms -in our growth categories such as tablets and smartphones, gaming, digital music devices and video collaboration, to offset the decline in our PC peripherals categories. The following discussion represents key trends specific to each of our two operating segments: peripherals and video conferencing.

[0001032975-15-000052:mdna:33]
[same as prior period, unchanged from 0001032975-15-000032:mdna:32]

[0001032975-15-000052:mdna:34]
Mobile Speakers:    The mobile speaker market grew throughout fiscal year 2015 and the first half of fiscal year 2016 driven by growing consumption of music through mobile devices such as smartphones and tablets.  This market growth, together with our investments in the UE brand, our introduction of new products and our ability to gain market share during fiscal year 2015 and the first half of fiscal year 2016, have driven our growth in Mobile Speakers.

[0001032975-15-000052:mdna:35]
Gaming:    The PC Gaming platform continues to show strong growth as online gaming and multi-platform gain greater popularity and gaming content becomes increasingly more demanding. We believe Logitech is well positioned to benefit from the PC Gaming market growth.

[0001032975-15-000052:mdna:36]
PC Peripherals (Pointing Devices, Keyboards & Combos, PC Webcams and Audio PC & Wearables):    Although the installed base of PC users is large, consumer demand for new PCs has declined in recent years, and we believe it will continue to decline in future years. As a consequence, consumer demand for PC peripherals is slowing, or in some cases declining. Our PC speakers sales are expected to decline as consumers migrate towards mobile speaker solutions such as UE Boom.

[0001032975-15-000052:mdna:37]
Enterprise Market:    We are continuing our efforts to create and sell products and services to enterprises, with our Video Collaboration products. For example, we have introduced the Logitech ConferenceCam Connect and PTZ Pro camera video collaboration products. Growing our enterprise peripherals business will continue to require investment in selected business-specific products, targeted sales force, product marketing, and sales channel development.

[0001032975-15-000052:mdna:38]
Tablets and Other Accessories:    Smaller mobile computing devices, such as tablets with touch interfaces, have created new markets and usage models for peripherals and accessories. We offer a variety of products for the Apple and Android platforms, including keyboard and folios that enhance the consumers mobile device experiences. We have also introduced keyboard folios for the Samsung Galaxy tablet. We have seen the market decline through fiscal year 2015 with continued declines in the first half of fiscal year 2016 for the iPad platform, which has impacted the sales of our tablet peripherals.

[0001032975-15-000052:mdna:39]
OEM Business:    Sales of our OEM mice and keyboards have historically made up the bulk of our OEM sales. In recent years, there has been a dramatic shift away from desktop PCs and there continues to be weakness in the global market for PCs, which has adversely affected our sales of OEM mice and keyboards, all of which are sold with name-brand desktop PCs. As previously announced, we plan to exit the OEM business by the end of December 2015 as we see limited opportunities for profitable growth.

[0001032975-15-000052:mdna:40]
[same as prior period, unchanged from 0001032975-15-000032:mdna:38]

[0001032975-15-000052:mdna:41]
[same as prior period, unchanged from 0001032975-15-000032:mdna:39]

[0001032975-15-000052:mdna:42]
The overall video conferencing industry has experienced a slowdown in recent quarters. In addition, there has been an increase in the competitive environment. Lifesize is in the process of transitioning its product portfolio to Lifesize Cloud. While sales of this software-as-a-service offering are growing, they are not yet large enough to offset the combination of the short-term portfolio transition and soft market conditions for video conferencing infrastructure. Looking at this growth opportunity, in April 2015, we decided to reorganize Lifesize with the goal of de-emphasizing Lifesize’s legacy offerings more quickly to enable maximum traction with Lifesize Cloud. We plan to shrink our legacy Lifesize business to grow the cloud opportunity faster.

[0001032975-15-000052:mdna:43]
[same as prior period, unchanged from 0001032975-15-000032:mdna:41]

[0001032975-15-000052:mdna:44]
[same as prior period, unchanged from 0001032975-15-000032:mdna:42]

[0001032975-15-000052:mdna:45]
[same as prior period, unchanged from 0001032975-15-000032:mdna:43]

[0001032975-15-000052:mdna:46]
[same as prior period, unchanged from 0001032975-15-000032:mdna:44]

[0001032975-15-000052:mdna:47]
Net sales by channel for the three and six months ended September 30, 2015 and 2014 were as follows (Dollars in thousands):

[0001032975-15-000052:mdna:48]
|  |  | Three Months EndedSeptember 30, |  | Six Months Ended September 30, |
|  |  | 2015 |  | 2014 |  | Change |  | 2015 |  | 2014 |  | Change |
| Retail |  | $ | 496,263 |  |  | $ | 473,463 |  |  | 5 | % |  | $ | 921,651 |  |  | $ | 897,276 |  |  | 3 | % |
| OEM |  | 22,231 |  |  | 28,394 |  |  | (22 | ) |  | 44,529 |  |  | 61,027 |  |  | (27 | ) |
| Video conferencing |  | 21,368 |  |  | 28,454 |  |  | (25 | ) |  | 44,002 |  |  | 54,211 |  |  | (19 | ) |
| Total net sales |  | $ | 539,862 |  |  | $ | 530,311 |  |  | 2 |  |  | $ | 1,010,182 |  |  | $ | 1,012,514 |  |  | — |  |

[0001032975-15-000052:mdna:49]
[same as prior period, unchanged from 0001032975-15-000032:mdna:47]

[0001032975-15-000052:mdna:50]
Our net retail sales in the three and six months ended September 30, 2015 increased 5% and 3%, respectively, compared to the same periods of the prior fiscal year. Sales increases in the Americas and Asia pacific regions, partially offset by a decrease in the EMEA region during the three and six months ended September 30, 2015. If currency exchange rates had been constant in the three and six months ended September 30, 2015 and 2014, our constant dollar retail sales would have increased by 12% and 10%, respectively.

[0001032975-15-000052:mdna:51]
[same as prior period, unchanged from 0001032975-15-000032:mdna:49]

[0001032975-15-000052:mdna:52]
OEM net sales decreased 22% and 27% in the three and six months ended September 30, 2015, respectively, compared to the same periods of the prior fiscal year. Given our heightened focus on our growing Retail Strategic business, we plan to exit the OEM business. If currency exchange rates had been constant in the three and six months ended September 30, 2015 and 2014, our constant dollar OEM net sales would have decreased by 21% and 27%, respectively.

[0001032975-15-000052:mdna:53]
[same as prior period, unchanged from 0001032975-15-000032:mdna:51]

[0001032975-15-000052:mdna:54]
Video conferencing net sales decreased 25% and 19%, respectively, for the three and six months ended September 30, 2015, compared to the same periods of the prior fiscal year. If currency exchange rates had been constant in the three and six months ended September 30, 2015 and 2014, our constant dollar video conferencing net sales would have decreased 25% and 19%, respectively. Lifesize is in the process of transitioning its product portfolio to the recently announced Lifesize Cloud, a software-as-a-service (SaaS) offering that provides an affordable, simple and scalable video conferencing solution with little to no need for information technology (IT) involvement. While sales of the cloud offering are growing, they are not yet large enough to offset the combination of the short-term portfolio transition and soft market conditions for video conferencing infrastructure. The global restructuring plan we announced in April 2015 also covers Lifesize business to align our refocus on Lifesize Cloud offering and transition from Lifesize legacy business.

[0001032975-15-000052:mdna:55]
[same as prior period, unchanged from 0001032975-15-000032:mdna:53]

[0001032975-15-000052:mdna:56]
The following table presents the change in retail sales by region for the three and six months ended September 30, 2015, compared to the three and six months ended September 30, 2014:

[0001032975-15-000052:mdna:57]
|  |  | Three Months EndedSeptember 30, 2015Change in Sales |  | Six Months EndedSeptember 30, 2015Change in Sales |
| Americas |  | 7 | % |  | 8 | % |
| EMEA |  | (5 | ) |  | (9 | ) |
| Asia Pacific |  | 18 |  |  | 11 |  |

[0001032975-15-000052:mdna:58]
[same as prior period, unchanged from 0001032975-15-000032:mdna:56]

[0001032975-15-000052:mdna:59]
Retail sales in the Americas region increased 7% and 8%, respectively, during the three and six months ended September 30, 2015, compared to the same periods of the prior fiscal year. If currency exchange rates had been constant in the three and six months ended September 30, 2015 and 2014, our constant dollar retail sales would have increased 9% and 10%, respectively. We achieved sales increases in all strategic categories except Audio - PC & Wearables, Home Control, and Tablets & Other Accessories. This increase was led by over 70% growth in Mobile Speakers.

[0001032975-15-000052:mdna:60]
[same as prior period, unchanged from 0001032975-15-000032:mdna:58]

[0001032975-15-000052:mdna:61]
Retail sales in the EMEA region decreased 5% and 9%, respectively, during the three and six months ended September 30, 2015, compared to the same periods of the prior fiscal year. If currency exchange rates had been constant in the three and six months ended September 30, 2015 and 2014, our constant dollar retail sales would have increased 7% and 4%, respectively. The decline in sales was impacted by continued market weakness in Russia and Ukraine

[0001032975-15-000052:mdna:62]
[same as prior period, unchanged from 0001032975-15-000032:mdna:60]

[0001032975-15-000052:mdna:63]
Retail sales in the Asia Pacific region increased 18% and 11% during the three and six months ended September 30, 2015, compared to the same periods of the prior fiscal year. If currency exchange rates had been constant in the three and six months ended September 30, 2015 and 2014, our constant dollar retail sales would have increased 26% and 18%, respectively. We achieved sales increases in Video Collaboration, Mobile Speakers, Gaming, Keyboards & Combos, and PC Webcams during the three and six months ended September 30, 2015.

[0001032975-15-000052:mdna:64]
[same as prior period, unchanged from 0001032975-15-000032:mdna:62]

[0001032975-15-000052:mdna:65]
Net sales by product category for the three and six months ended September 30, 2015 and 2014 were as follows (Dollars in thousands):

[0001032975-15-000052:mdna:66]
|  |  | Three Months EndedSeptember 30, |  | Six Months Ended September 30, |
|  |  | 2015 |  | 2014 |  | Change |  | 2015 |  | 2014 |  | Change |
| Peripherals: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Mobile Speakers |  | $ | 80,550 |  |  | $ | 48,538 |  |  | 66 | % |  | $ | 121,094 |  |  | $ | 77,367 |  |  | 57 | % |
| Gaming |  | 67,624 |  |  | 47,506 |  |  | 42 |  |  | 111,294 |  |  | 94,382 |  |  | 18 |  |
| Video Collaboration |  | 20,059 |  |  | 13,808 |  |  | 45 |  |  | 41,235 |  |  | 29,033 |  |  | 42 |  |
| Tablet & Other Accessories |  | 18,549 |  |  | 28,158 |  |  | (34 | ) |  | 37,358 |  |  | 59,874 |  |  | (38 | ) |
| Growth |  | 186,782 |  |  | 138,010 |  |  | 35 |  |  | 310,981 |  |  | 260,656 |  |  | 19 |  |
| Pointing Devices |  | 124,668 |  |  | 127,693 |  |  | (2 | ) |  | 241,653 |  |  | 240,735 |  |  | — |  |
| Keyboards & Combos |  | 102,098 |  |  | 105,677 |  |  | (3 | ) |  | 207,927 |  |  | 211,166 |  |  | (2 | ) |
| Audio-PC & Wearables |  | 46,342 |  |  | 57,191 |  |  | (19 | ) |  | 92,041 |  |  | 105,739 |  |  | (13 | ) |
| PC Webcams |  | 23,360 |  |  | 25,282 |  |  | (8 | ) |  | 45,041 |  |  | 45,745 |  |  | (2 | ) |
| Home Control |  | 12,610 |  |  | 18,776 |  |  | (33 | ) |  | 22,864 |  |  | 31,108 |  |  | (27 | ) |
| Profit Maximization |  | 309,078 |  |  | 334,619 |  |  | (8 | ) |  | 609,526 |  |  | 634,493 |  |  | (4 | ) |
| Retail Strategic Sales |  | 495,860 |  |  | 472,629 |  |  | 5 |  |  | 920,507 |  |  | 895,149 |  |  | 3 |  |
| Non-Strategic |  | 403 |  |  | 834 |  |  | (52 | ) |  | 1,144 |  |  | 2,127 |  |  | (46 | ) |
| Retail |  | 496,263 |  |  | 473,463 |  |  | 5 |  |  | 921,651 |  |  | 897,276 |  |  | 3 |  |
| OEM |  | 22,231 |  |  | 28,394 |  |  | (22 | ) |  | 44,529 |  |  | 61,027 |  |  | (27 | ) |
|  |  | 518,494 |  |  | 501,857 |  |  | 3 |  |  | 966,180 |  |  | 958,303 |  |  | 1 |  |
| Video conferencing |  | 21,368 |  |  | 28,454 |  |  | (25 | ) |  | 44,002 |  |  | 54,211 |  |  | (19 | ) |
|  |  | $ | 539,862 |  |  | $ | 530,311 |  |  | 2 |  |  | $ | 1,010,182 |  |  | $ | 1,012,514 |  |  | — |  |

[0001032975-15-000052:mdna:67]
Certain products within the retail product categories presented in prior periods have been reclassified to conform to the current periods' presentation.

[0001032975-15-000052:mdna:68]
[same as prior period, unchanged from 0001032975-15-000032:mdna:66]

[0001032975-15-000052:mdna:69]
During the three and six months ended September 30, 2015, Retail Strategic sales increased 5% and 3%, respectively, compared to the same periods of prior fiscal year. If currency exchange rates had been constant for the three and six months ended September 30, 2015 and 2014, our constant dollar retail strategic sales would have increased 12% and 10%, respectively.

[0001032975-15-000052:mdna:70]
[same as prior period, unchanged from 0001032975-15-000032:mdna:68]

[0001032975-15-000052:mdna:71]
During the three and six months ended September 30, 2015, Retail Strategic sales - Growth categories increased 35% and 19%, respectively, compared to the same periods of prior fiscal year. If currency exchange rates had been constant for the three and six months ended September 30, 2015 and 2014, our constant dollar Retail Strategic sales - Growth categories would have increased 45% and 28%, respectively.

[0001032975-15-000052:mdna:72]
[same as prior period, unchanged from 0001032975-15-000032:mdna:70]

[0001032975-15-000052:mdna:73]
Our retail Mobile Speakers category is made up entirely of Bluetooth wireless speakers.

[0001032975-15-000052:mdna:74]
Retail sales and units sold of Mobile Speakers increased 66% and 53%, respectively, for the three month period ended September 30, 2015, compared to the same period of the prior fiscal year. Retail sales and units sold of Mobile Speakers increased 57% and 42%, respectively, for the six month period ended September 30, 2015, compared to the same period of the prior fiscal year. Mobile Speaker sales increased significantly for both periods primarily due to the introduction of the UE Megaboom in the fourth quarter of fiscal 2015 and the UE Roll in first quarter of fiscal 2016.

[0001032975-15-000052:mdna:75]
[same as prior period, unchanged from 0001032975-15-000032:mdna:73]

[0001032975-15-000052:mdna:76]
[same as prior period, unchanged from 0001032975-15-000032:mdna:74]

[0001032975-15-000052:mdna:77]
Retail sales and units sold of Gaming increased 42% and 24%, respectively, for the three months ended September 30, 2015, compared to the same period of the prior fiscal year. Retail sales and units sold of Gaming increased 18% and 12%, respectively, for the six months ended September 30, 2015, compared to the same period of the prior fiscal year. Gaming sales increased significantly for both periods primarily driven by increases in Gaming steering wheels sales due to the introductions of new steering wheels for Xbox, PS4 and the PC, and increases in Gaming keyboard sales.

[0001032975-15-000052:mdna:78]
[same as prior period, unchanged from 0001032975-15-000032:mdna:77]

[0001032975-15-000052:mdna:79]
[same as prior period, unchanged from 0001032975-15-000032:mdna:78]

[0001032975-15-000052:mdna:80]
Retail sales of Video Collaboration increased 45% and units sold increased 18% in the three months ended September 30, 2015, compared to the same period of the prior fiscal year. Retail sales of Video Collaboration increased 42% and units sold increased 43% in the six months ended September 30, 2015, compared to the same period of the prior fiscal year. The increases in both periods were primarily due to growth in our conference cams.

[0001032975-15-000052:mdna:81]
[same as prior period, unchanged from 0001032975-15-000032:mdna:80]

[0001032975-15-000052:mdna:82]
Our retail Tablet & Other Accessories consists of keyboards for tablets and covers for tablets as well as other accessories for mobile devices.

[0001032975-15-000052:mdna:83]
Retail sales of Tablet & Other Accessories decreased 34% and units sold decreased 17% in the three months ended September 30, 2015, compared to the same period of the prior fiscal year. The reduction in sales reflects the combination of a declining market for iPad shipments as well as phasing out end-of-life product, partially offset by the new products introduction of Type Plus tablet keyboard and Canvas keyboard case for iPad .

[0001032975-15-000052:mdna:84]
Retail sales of Tablet & Other Accessories decreased 38% and units sold decreased 19% in the six months ended September 30, 2015, compared to the same period of the prior fiscal year.

[0001032975-15-000052:mdna:85]
[same as prior period, unchanged from 0001032975-15-000032:mdna:83]

[0001032975-15-000052:mdna:86]
During the three and six months ended September 30, 2015, Retail Strategic sales - Profit Maximization categories decreased 8% and 4%, respectively, compared to the same periods of the prior fiscal year. If currency exchange rates had been constant for the three and six months ended September 30, 2015 and 2014, our constant dollar Retail Strategic sales - Profit Maximization categories would have decreased 2% and increased 2%, respectively.

[0001032975-15-000052:mdna:87]
[same as prior period, unchanged from 0001032975-15-000032:mdna:85]

[0001032975-15-000052:mdna:88]
Our retail Pointing Devices category comprises of mice, touchpads and presenters.

[0001032975-15-000052:mdna:89]
Retail sales of Pointing Devices decreased 2% and units sold decreased 6% in the three months ended September 30, 2015, compared to the same period of the prior fiscal year. Sales decreased in low end and mid-range products, partially offset by increased at the high end due to the new product introduction of the MX Master Wireless Mouse and MX Anywhere 2 Wireless Mouse.

[0001032975-15-000052:mdna:90]
Retail sales of Pointing Devices remained flat while retail units sold decreased 2% in the six months ended September 30, 2015, compared to the same period of the prior fiscal year.

[0001032975-15-000052:mdna:91]
[same as prior period, unchanged from 0001032975-15-000032:mdna:88]

[0001032975-15-000052:mdna:92]
[same as prior period, unchanged from 0001032975-15-000032:mdna:89]

[0001032975-15-000052:mdna:93]
Retail sales of Keyboards & Combos decreased 3% and units sold decreased 4% in the three months ended September 30, 2015, compared to the same period of the prior fiscal year. Sales declines in the EMEA region were partially offset by sales growth in the Americas and Asia Pacific regions. The sales decline was primarily driven by corded products, partially offset by increase in cordless products.

[0001032975-15-000052:mdna:94]
Retail sales of Keyboards & Combos decreased 2% and units sold increased 2% in the six months ended September 30, 2015, compared to the same period of the prior fiscal year.

[0001032975-15-000052:mdna:95]
[same as prior period, unchanged from 0001032975-15-000032:mdna:91]

[0001032975-15-000052:mdna:96]
[same as prior period, unchanged from 0001032975-15-000032:mdna:92]

[0001032975-15-000052:mdna:97]
Audio-PC & Wearables sales decreased 19% and units sold decreased 15% in the three months ended September 30, 2015, compared to the same period of the prior fiscal year. The decrease was primarily due to decreases in PC speaker retail sales, reflecting a category in structural decline as music consumption migrates to mobile platforms. This migration drives growth products in our Mobile Speakers category.

[0001032975-15-000052:mdna:98]
Audio-PC & Wearables sales decreased 13% and units sold decreased 11% in the six months ended September 30, 2015, compared to the same period of the prior fiscal year.

[0001032975-15-000052:mdna:99]
[same as prior period, unchanged from 0001032975-15-000032:mdna:94]

[0001032975-15-000052:mdna:100]
[same as prior period, unchanged from 0001032975-15-000032:mdna:95]

[0001032975-15-000052:mdna:101]
Retail PC Webcams sales decreased 8% and units sold decreased 13% in the three months ended September 30, 2015, compared to the same period in the prior fiscal year. The decrease was primarily driven by the decline in EMEA region, partially offset by an increase in the Americas.

[0001032975-15-000052:mdna:102]
Retail PC Webcams sales decreased 2% and units sold decreased 7% in the six months ended September 30, 2015, compared to the same period in the prior fiscal year.

[0001032975-15-000052:mdna:103]
[same as prior period, unchanged from 0001032975-15-000032:mdna:97]

[0001032975-15-000052:mdna:104]
[same as prior period, unchanged from 0001032975-15-000032:mdna:98]

[0001032975-15-000052:mdna:105]
Home Control retail sales decreased 33% and units sold decreased 16% in the three months ended September 30, 2015, compared to the same period of the prior fiscal year. The sales decline was primarily driven by declines in high end and mid-range remote controls across all regions.

[0001032975-15-000052:mdna:106]
Home Control retail sales decreased 27% and units sold decreased 10% in the six months ended September 30, 2015, compared to the same period of the prior fiscal year.

[0001032975-15-000052:mdna:107]
[same as prior period, unchanged from 0001032975-15-000032:mdna:100]

[0001032975-15-000052:mdna:108]
This category comprises a variety of products out of which we currently intend to transition, or have already transitioned, because they are no longer strategic to our business. Product categories included in this category mainly consist of TV Camera, Digital Video Security, TV and home speakers, and Keyboard/ Desktop accessories.

[0001032975-15-000052:mdna:109]
Non-strategic retail sales decreased 52% and units sold decreased 72% during the three months ended September 30, 2015, compared to the same period in the prior fiscal year.

[0001032975-15-000052:mdna:110]
Non-strategic retail sales decreased 46% and units sold decreased 57% during the six months ended September 30, 2015, compared to the same period in the prior fiscal year.

[0001032975-15-000052:mdna:111]
[same as prior period, unchanged from 0001032975-15-000032:mdna:103]

[0001032975-15-000052:mdna:112]
OEM sales decreased 22% and units sold decreased 13% during the three months ended September 30, 2015, compared to the same period of the prior fiscal year. As announced in April 2015, we plan to exit the OEM business by the end of December 2015 as we see limited opportunities for profitable growth.

[0001032975-15-000052:mdna:113]
OEM sales decreased 27% and units sold decreased 18% during the six months ended September 30, 2015, compared to the same period of the prior fiscal year.

[0001032975-15-000052:mdna:114]
[same as prior period, unchanged from 0001032975-15-000032:mdna:105]

[0001032975-15-000052:mdna:115]
Video conferencing net sales decreased 25% and 19%, respectively, during the three and six months ended September 30, 2015, compared to the same periods of the prior fiscal year. The decrease in net sales was due to a decrease in legacy business, partially offset by an increase in our cloud offerings.

[0001032975-15-000052:mdna:116]
[same as prior period, unchanged from 0001032975-15-000032:mdna:107]

[0001032975-15-000052:mdna:117]
Gross profit for three and six months ended September 30, 2015 and 2014 was as follows (Dollars in thousands):

[0001032975-15-000052:mdna:118]
|  |  | Three Months EndedSeptember 30, |  | Six Months Ended September 30, |
|  |  | 2015 |  | 2014 |  | Change |  | 2015 |  | 2014 |  | Change |
| Net sales |  | $ | 539,862 |  |  | $ | 530,311 |  |  | 2 | % |  | $ | 1,010,182 |  |  | $ | 1,012,514 |  |  | — | % |
| Cost of goods sold |  | 353,851 |  |  | 325,533 |  |  | 9 |  |  | 652,442 |  |  | 625,984 |  |  | 4 |  |
| Gross profit |  | $ | 186,011 |  |  | $ | 204,778 |  |  | (9 | ) |  | $ | 357,740 |  |  | $ | 386,530 |  |  | (7 | ) |
| Gross margin |  | 34.5 | % |  | 38.6 | % |  |  |  |  | 35.4 | % |  | 38.2 | % |  |  |  |

[0001032975-15-000052:mdna:119]
Gross profit consists of net sales, less cost of goods sold, which includes materials, direct labor and related overhead costs, costs of manufacturing facilities, royalties, costs of purchasing components from outside suppliers, distribution costs, warranty costs, customer support, outside processing costs, write-down of inventories and amortization of intangible assets.

[0001032975-15-000052:mdna:120]
The decrease in gross margin for the three and six months ended September 30, 2015 compared to the same period of the prior fiscal year was primarily driven by the unfavorable currency impact, partially offset by margin improvement from product cost improvement and favorable impact of repricing.

[0001032975-15-000052:mdna:121]
[same as prior period, unchanged from 0001032975-15-000032:mdna:113]

[0001032975-15-000052:mdna:122]
Operating expenses for the three and six months ended September 30, 2015 and 2014 were as follows (Dollars in thousands):

[0001032975-15-000052:mdna:123]
|  |  | Three Months EndedSeptember 30, |  | Six Months Ended September 30, |
|  |  | 2015 |  | 2014 |  | Change |  | 2015 |  | 2014 |  | Change |
| Marketing and selling |  | $ | 89,877 |  |  | $ | 95,862 |  |  | (6 | )% |  | $ | 177,304 |  |  | $ | 186,908 |  |  | (5 | )% |
| % of net sales |  | 16.6 | % |  | 18.1 | % |  |  |  |  | 17.6 | % |  | 18.5 | % |  |  |  |
| Research and development |  | 34,898 |  |  | 32,325 |  |  | 8 |  |  | 68,731 |  |  | 63,641 |  |  | 8 |  |
| % of net sales |  | 6.5 | % |  | 6.1 | % |  |  |  |  | 6.8 | % |  | 6.3 | % |  |  |  |
| General and administrative |  | 26,851 |  |  | 34,470 |  |  | (22 | ) |  | 57,355 |  |  | 71,149 |  |  | (19 | ) |
| % of net sales |  | 5.0 | % |  | 6.5 | % |  |  |  |  | 5.7 | % |  | 7.0 | % |  |  |  |
| Restructuring charges (credits), net |  | 8,696 |  |  | — |  |  | NM |  |  | 21,691 |  |  | — |  |  | NM |  |
| % of net sales |  | 1.6 | % |  | — | % |  |  |  |  | 2.1 | % |  | — | % |  |  |  |
| Total operating expenses |  | $ | 160,322 |  |  | $ | 162,657 |  |  | (1 | ) |  | $ | 325,081 |  |  | $ | 321,698 |  |  | 1 | % |
| % of net sales |  | 29.7 | % |  | 30.7 | % |  |  |  |  | 32.2 | % |  | 31.8 | % |  |  |  |

[0001032975-15-000052:mdna:124]
[same as prior period, unchanged from 0001032975-15-000032:mdna:116]

[0001032975-15-000052:mdna:125]
[same as prior period, unchanged from 0001032975-15-000032:mdna:117]

[0001032975-15-000052:mdna:126]
[same as prior period, unchanged from 0001032975-15-000032:mdna:118]

[0001032975-15-000052:mdna:127]
During the three months ended September 30, 2015, marketing and selling expenses decreased 6%, compared to the same period in the prior fiscal year. The decrease was primarily due to savings in external spending of $2.8 million, a $1.9 million decrease in the amortization of Lifesize intangible assets, in addition to favorable currency impact of $1.0 million to personnel related costs.

[0001032975-15-000052:mdna:128]
During the six months ended September 30, 2015, marketing and selling expenses decreased 5%, compared to the same period in the prior fiscal year. The decrease was primarily due to a $3.6 million savings from personnel related costs primarily for Lifesize restructuring and favorable currency impact, a $3.9 million decrease in the amortization of Lifesize intangible assets, in addition to savings in external spending of $2.3 million.

[0001032975-15-000052:mdna:129]
[same as prior period, unchanged from 0001032975-15-000032:mdna:120]

[0001032975-15-000052:mdna:130]
[same as prior period, unchanged from 0001032975-15-000032:mdna:121]

[0001032975-15-000052:mdna:131]
During the three months ended September 30, 2015, research and development expenses increased 8%, compared to the same period in the prior fiscal year. The increase was primarily due to a $1.7 million investment increase in Seeds development (new business opportunities).

[0001032975-15-000052:mdna:132]
During the six months ended September 30, 2015, research and development expenses increased 8%, compared to the same period in the prior fiscal year. The increase was primarily due to a $2.5 million investment increase in Seeds development.

[0001032975-15-000052:mdna:133]
[same as prior period, unchanged from 0001032975-15-000032:mdna:123]

[0001032975-15-000052:mdna:134]
General and administrative expenses consist primarily of personnel and related overhead costs for the finance, information systems, executive, people & culture, legal and facilities functions.

[0001032975-15-000052:mdna:135]
During the three months ended September 30, 2015, general and administrative expenses decreased 22%, compared to the same period in the prior fiscal year. The decrease was primarily due to an $8.0 million reduction related to the prior year's independent Audit committee investigation and related expenses.

[0001032975-15-000052:mdna:136]
During the six months ended September 30, 2015, general and administrative expenses decreased 19%, compared to the same period in the prior fiscal year. The decrease was primarily due to an $16.5 million reduction related to the prior year's independent Audit committee investigation, partially offset by a $3.5 million additional accrual for our proposed settlement with the SEC (see Other Contingencies for more details).

[0001032975-15-000052:mdna:137]
[same as prior period, unchanged from 0001032975-15-000032:mdna:126]

[0001032975-15-000052:mdna:138]
During the first quarter of fiscal year 2016, we implemented a restructuring plan to exit the OEM business, reorganize Lifesize to sharpen our focus on its cloud-based offering, and streamline our overall cost structure through product, overhead and infrastructure cost reductions with a targeted resource realignment. Restructuring charges incurred during the six months ended September 30, 2015 under this plan primarily consisted of severance and other ongoing and one-time termination benefits. Charges and other costs related to the workforce reduction and structure realignment are presented as restructuring charges in the Condensed Consolidated Statements of Operations. We expect to incur approximately $22 million to $25 million under this restructuring plan, including approximately $20.3 million to 23.3 million for cash severance and other personnel costs, and expect to substantially complete this restructuring within the next 6 months. We expect this restructuring will save personnel-related costs and other overhead costs, and we expect to use the savings from the restructuring to offset currency impacts and to invest in future growth.

[0001032975-15-000052:mdna:139]
The following table summarizes restructuring related activities during the three and six months ended September 30, 2015 (in thousands).

[0001032975-15-000052:mdna:140]
|  |  | Restructuring |
|  |  | TerminationBenefits |  | Lease ExitCosts |  | Other |  | Total |
| Accrual balance at March 31, 2015 |  | $ | — |  |  | $ | 1,039 |  |  | $ | — |  |  | $ | 1,039 |  |
| Charges, net |  | 12,794 |  |  | — |  |  | 201 |  |  | 12,995 |  |
| Cash payments |  | (4,675 | ) |  | (796 | ) |  | $ | (151 | ) |  | (5,622 | ) |
| Accrual balance at June 30, 2015 |  | 8,119 |  |  | 243 |  |  | 50 |  |  | 8,412 |  |
| Charges, net |  | 8,566 |  |  | 38 |  |  | 92 |  |  | 8,696 |  |
| Cash payments |  | (5,112 | ) |  | (122 | ) |  | (142 | ) |  | (5,376 | ) |
| Accrual balance at September 30, 2015 |  | $ | 11,573 |  |  | $ | 159 |  |  | $ | — |  |  | $ | 11,732 |  |

[0001032975-15-000052:mdna:141]
[same as prior period, unchanged from 0001032975-15-000032:mdna:130]

[0001032975-15-000052:mdna:142]
[same as prior period, unchanged from 0001032975-15-000032:mdna:131]

[0001032975-15-000052:mdna:143]
Other income and expense for the three and six months ended September 30, 2015 and 2014 were as follows (in thousands):

[0001032975-15-000052:mdna:144]
|  |  | Three Months EndedSeptember 30, |  | Six Months Ended September 30, |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Investment income (loss) related to deferred compensation plan |  | $ | (753 | ) |  | $ | 385 |  |  | $ | (653 | ) |  | $ | 649 |  |
| Currency exchange gains (losses) |  | 65 |  |  | (975 | ) |  | (1,210 | ) |  | (1,504 | ) |
| Others |  | (92 | ) |  | (295 | ) |  | (38 | ) |  | (228 | ) |
|  |  | $ | (780 | ) |  | $ | (885 | ) |  | $ | (1,901 | ) |  | $ | (1,083 | ) |

[0001032975-15-000052:mdna:145]
We recognized $0.1 million currency exchange gain and $1.2 million currency exchange loss during the three and six months ended September 30, 2015, respectively. Currency exchange gains (losses) relate to balances

[0001032975-15-000052:mdna:146]
denominated in currencies other than the functional currency of our subsidiaries, to the sale of currencies, and to gains or losses recognized on currency exchange forward contracts.

[0001032975-15-000052:mdna:147]
[same as prior period, unchanged from 0001032975-15-000032:mdna:135]

[0001032975-15-000052:mdna:148]
The provision for (benefit from) income taxes and effective tax rates for the three and six months ended September 30, 2015 and 2014 were as follows (in thousands):

[0001032975-15-000052:mdna:149]
|  |  | Three Months EndedSeptember 30, |  | Six Months Ended September 30, |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Provision for (benefit from) income tax |  | $ | 7,004 |  |  | $ | 5,501 |  |  | $ | 5,680 |  |  | $ | 8,596 |  |
| Effective income tax rate |  | 27.9 | % |  | 13.2 | % |  | 18.2 | % |  | 13.4 | % |

[0001032975-15-000052:mdna:150]
The change in the effective income tax rate for the three and six months ended September 30, 2015, compared to the three and six months ended September 30, 2014, is due to the mix of income and losses in the various tax jurisdictions in which we operate. In addition, in determining the annual effective tax rate of fiscal year 2016, there is no tax benefit recognized for ordinary losses related to the video conferencing business as realization of the tax benefit of the losses is not assured beyond any reasonable doubt. In the three months ended September 30, 2015, a discrete tax provision of $1.5 million resulting from a write-off to a deferred tax asset related to stock equity awards for the video conferencing business was largely offset by a discrete tax benefit from the reversal of uncertain tax positions from the expiration of statutes of limitations. In the three months ended September 30, 2014, there was a discrete tax benefit of $1.7 million, primarily from the reversal of uncertain tax positions resulting from the expiration of statues of limitations and audit settlements in certain jurisdictions.

[0001032975-15-000052:mdna:151]
There was a discrete tax benefit of $2.2 million and $0.8 million in the six months ended September 30, 2015 and 2014, respectively, resulting from the preferential income tax rate reduction pursuant to the High and New Technology Enterprise Program in China.

[0001032975-15-000052:mdna:152]
As of September 30 and March 31, 2015, the total amount of unrecognized tax benefits due to uncertain tax positions was $80.4 million and $79.0 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-15-000052:mdna:153]
[same as prior period, unchanged from 0001032975-15-000032:mdna:140]

[0001032975-15-000052:mdna:154]
[same as prior period, unchanged from 0001032975-15-000032:mdna:141]

[0001032975-15-000052:mdna:155]
As of September 30, 2015, we had cash and cash equivalents of $365.8 million, compared to $537.0 million at March 31, 2015. Our cash and cash equivalents consist of bank demand deposits and short-term time deposits of which 44% is held by our subsidiaries in Switzerland, 21% is held by our subsidiaries in Hong Kong and China, 19% is held by our subsidiaries in the Netherlands, 8% is held by our subsidiaries in the United Kingdom, and 8% is held by subsidiaries in various other countries. We do not expect to incur any material adverse tax impact except for what has been recognized or be significantly inhibited by any country in which we do business from the repatriation of funds to Switzerland, our home domicile.

[0001032975-15-000052:mdna:156]
As of September 30, 2015, our working capital was $453.7 million compared to working capital of $557.1 million at March 31, 2015.  The decrease was primarily due to lower cash and cash equivalents, primarily as a result of dividend payments and share repurchases, and higher accounts payable and accrued liabilities, partially offset by higher accounts receivable and inventory balances.

[0001032975-15-000052:mdna:157]
During the six months ended September 30, 2015, we used $14.9 million cash in operating activities. Our main cash outflows of operating cash resulted from increases in accounts receivable and inventories, partially offset by increases in accounts payable and accrued liabilities. Net cash used in investing activities was $31.6 million, primarily from $31.3 million of capital expenditure in computer hardware and software, tooling and equipment. Net cash used in financing activities was $126.0 million, primarily related to dividend payments of $85.9 million, share repurchases of $48.8 million and tax withholdings related to net share settlements of restricted stock units (RSUs) of $3.5 million, partially offset by $11.1 million proceeds from sales of shares upon exercise of options and purchase rights.

[0001032975-15-000052:mdna:158]
We had several uncommitted, unsecured bank lines of credit aggregating $46.7 million as of September 30, 2015. There are no financial covenants under these lines of credit with which we must comply. As of September 30, 2015, we had outstanding bank guarantees of $18.2 million under these lines of credit.

[0001032975-15-000052:mdna:159]
[same as prior period, unchanged from 0001032975-15-000032:mdna:146]

[0001032975-15-000052:mdna:160]
|  |  | Six Months Ended September 30, |
|  |  | 2015 |  | 2014 |
| Net cash provided by (used in) operating activities |  | $ | (14,862 | ) |  | $ | 60,704 |  |
| Net cash used in investing activities |  | (31,551 | ) |  | (27,199 | ) |
| Net cash used in financing activities |  | (125,953 | ) |  | (302 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  | 1,102 |  |  | (2,393 | ) |
| Net increase (decrease) in cash and cash equivalents |  | $ | (171,264 | ) |  | $ | 30,810 |  |

[0001032975-15-000052:mdna:161]
[same as prior period, unchanged from 0001032975-15-000032:mdna:148]

[0001032975-15-000052:mdna:162]
The following table presents selected financial information and statistics as of September 30, 2015 and 2014 (dollars in thousands):

[0001032975-15-000052:mdna:163]
|  |  | As of September 30 |
|  |  | 2015 |  | 2014 |
| Accounts receivable, net |  | $ | 274,730 |  |  | $ | 252,692 |  |
| Inventories |  | 328,054 |  |  | 245,237 |  |
| Working capital |  | 453,688 |  |  | 550,601 |  |
| Days sales in accounts receivable (“DSO”) (Days) (1) |  | 46 |  |  | 43 |  |
| Inventory turnover (“ITO”) (x)(2) |  | 4.3 |  |  | 5.3 |  |

[0001032975-15-000052:mdna:164]
[same as prior period, unchanged from 0001032975-15-000032:mdna:151]

[0001032975-15-000052:mdna:165]
[same as prior period, unchanged from 0001032975-15-000032:mdna:152]

[0001032975-15-000052:mdna:166]
During the six months ended September 30, 2015, we used cash of $14.9 million in operating activities, compared to cash provided by operating activities of $60.7 million for the same period in the prior fiscal year. The primary drivers of the decrease in net cash generated from operating cash flows include inventory change of $28.5 million and accounts receivable change of $21.8 million and a decrease in net income of $30.2 million, for the six months ended September 30, 2015, compared to the six months ended September 30, 2014.

[0001032975-15-000052:mdna:167]
Inventory turnover as of September 30, 2015 decreased, compared to that as of September 30, 2014. The increase in inventories was primarily due to several new launched products, transition from ODM to in-house production and adjusting our inventory strategy to emphasize sea shipments rather than air delivery since the fourth quarter of fiscal year 2015. If we are not successful in launching and phasing in our new products launched during the current fiscal quarter and in the remainder of fiscal year 2016, or we are not able to sell the new products at the prices planned, it could have a material impact on our gross profit margin, operating results including operating cash flow and inventory turnover in the future.

[0001032975-15-000052:mdna:168]
35

[0001032975-15-000052:mdna:169]
[same as prior period, unchanged from 0001032975-15-000032:mdna:155]

[0001032975-15-000052:mdna:170]
The following table presents information on our cash flows from investing activities during the six months ended September 30, 2015 and 2014 (in thousands):

[0001032975-15-000052:mdna:171]
|  |  | Six Months Ended September 30, |
|  |  | 2015 |  | 2014 |
| Purchases of property, plant and equipment |  | $ | (31,277 | ) |  | $ | (24,964 | ) |
| Investment in privately held companies |  | (480 | ) |  | (2,550 | ) |
| Purchases of trading investments |  | (2,649 | ) |  | (2,230 | ) |
| Proceeds from sales of trading investments |  | 2,855 |  |  | 2,545 |  |
| Net cash used in investing activities |  | $ | (31,551 | ) |  | $ | (27,199 | ) |

[0001032975-15-000052:mdna:172]
Our expenditures for property, plant and equipment during the six months ended September 30, 2015 and 2014 were primarily for computer hardware and software, tooling, equipment and leasehold improvements. The increase in purchases of property, plant and equipment during the six months ended September 30, 2015 is mainly arising from the building of production lines to accommodate the in-house manufacturing of certain products compared with purchase from third parties in the prior period to align our goal of cost saving.

[0001032975-15-000052:mdna:173]
The purchases and sales of trading investments in the six months ended September 30, 2015 and 2014 represent mutual fund and money market fund activities directed by participants in a deferred compensation plan offered by one of our subsidiaries. The mutual funds and money market funds are held by a Rabbi trust.

[0001032975-15-000052:mdna:174]
[same as prior period, unchanged from 0001032975-15-000032:mdna:160]

[0001032975-15-000052:mdna:175]
The following table presents information on our cash flows from financing activities during the six months ended September 30, 2015 and 2014 (in thousands):

[0001032975-15-000052:mdna:176]
|  |  | Six Months Ended September 30, |
|  |  | 2015 |  | 2014 |
| Payment of cash dividends |  | $ | (85,915 | ) |  | $ | — |  |
| Contingent consideration related to prior acquisition |  | — |  |  | (100 | ) |
| Repurchases of ESPP awards |  | — |  |  | (1,078 | ) |
| Purchases of treasury shares |  | (48,802 | ) |  | — |  |
| Proceeds from sales of shares upon exercise of options and purchase rights |  | 11,103 |  |  | 1,533 |  |
| Tax withholdings related to net share settlements of restricted stock units |  | (3,502 | ) |  | (1,323 | ) |
| Excess tax benefits from share-based compensation |  | 1,163 |  |  | 666 |  |
| Net cash used in financing activities |  | $ | (125,953 | ) |  | $ | (302 | ) |

[0001032975-15-000052:mdna:177]
During the six months ended September 30, 2015, 3.5 million shares were repurchased for $48.8 million. There were no share repurchases during the six months ended September 30, 2014.

[0001032975-15-000052:mdna:178]
During the six months ended September 30, 2015, we declared and paid cash dividends of CHF0.51 (USD equivalent of $0.53) per common share, totaling $85.9 million in U.S. Dollars, out of retained earnings. Proceeds from the sale of shares upon exercise of options and purchase rights pursuant to our stock plans during the six months ended September 30, 2015 and 2014 were $11.1 million and $1.5 million, respectively. The payment of required tax withholdings related to net share settlements of RSUs during the six months ended September 30, 2015 and 2014 was $3.5 million and $1.3 million, respectively.

[0001032975-15-000052:mdna:179]
[same as prior period, unchanged from 0001032975-15-000032:mdna:165]

[0001032975-15-000052:mdna:180]
[same as prior period, unchanged from 0001032975-15-000032:mdna:166]

[0001032975-15-000052:mdna:181]
In March 2015, we announced a plan to pay $250 million in cumulative dividends for fiscal year 2015 through fiscal year 2017. During the second quarter of fiscal year 2016, we paid a cash dividend of CHF 83.1 million (US Dollar amount of $85.9 million) out of retained earnings. During fiscal year 2015, we paid a cash dividend of CHF 43.1 million (U.S. Dollar amount of $43.8 million) out of retained earnings.

[0001032975-15-000052:mdna:182]
In March 2014, our Board of Directors approved a new share buyback program, which authorizes us to purchase up to $250.0 million of our own shares. Our share buyback program provides us with the opportunity to make opportunistic repurchases during periods of favorable market conditions and is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market through block trades or otherwise. Purchases may be started or stopped at any time without prior notice depending on market conditions and other factors. During the three and six months ended September 30, 2015, 2.9 million shares and 3.5 million were repurchased for $40.0 million and $48.8 million, respectively. There were no share repurchases during the three or six months ended September 30, 2014.

[0001032975-15-000052:mdna:183]
During the first quarter of fiscal year 2016, we announced that we are committing to pursue a restructuring, including exiting the OEM business, reorganizing Lifesize to sharpen our focus on its cloud-based offering, and streamlining our overall cost structure through product, overhead and infrastructure cost reductions with a targeted resource realignment.  We expect to incur approximately $22 million to $25 million under this restructuring plan and we have paid $10.1 million as of September 30, 2015. We expect to substantially complete this restructuring within the next 6 months. We expect this restructuring will save personnel-related costs and other overhead costs, and we expect to use the savings from the restructuring to offset currency impact and to invest in future growth.

[0001032975-15-000052:mdna:184]
If we do not generate sufficient operating cash flows to support our operations and future planned cash requirements, our operations could be harmed and our access to credit could be restricted or eliminated. However, we believe that the trend of our historical cash flow generation, our projections of future operations and reduced expenses and our available cash balances will provide sufficient liquidity to fund our operations for at least the next 12 months.

[0001032975-15-000052:mdna:185]
[same as prior period, unchanged from 0001032975-15-000032:mdna:172]

[0001032975-15-000052:mdna:186]
We lease facilities under operating leases, certain of which require us to pay property taxes, insurance and maintenance costs. Operating leases for facilities are generally renewable at our option and usually include escalation clauses linked to inflation. The remaining terms on our non-cancelable operating leases expire in various years through 2030. Our asset retirement obligations on these leases as of September 30, 2015 were not material.

[0001032975-15-000052:mdna:187]
[same as prior period, unchanged from 0001032975-15-000032:mdna:174]

[0001032975-15-000052:mdna:188]
As of September 30, 2015, we had fixed purchase commitments for inventory purchases made in the normal course of business to original design manufacturers, contract manufacturers and other suppliers, the majority of which are expected to be fulfilled within the next 12 months. Fixed purchase commitments for capital expenditures primarily relate to commitments for tooling for new and existing products, computer hardware, leasehold and improvements. We expect to continue making capital expenditures in the future to support product development activities and ongoing and expanded operations. Although open purchase commitments are considered enforceable and legally binding, the terms generally allow us to reschedule or adjust our requirements based on business needs prior to delivery of goods or performance of services.

[0001032975-15-000052:mdna:189]
[same as prior period, unchanged from 0001032975-15-000032:mdna:176]

[0001032975-15-000052:mdna:190]
[same as prior period, unchanged from 0001032975-15-000032:mdna:177]

[0001032975-15-000052:mdna:191]
[same as prior period, unchanged from 0001032975-15-000032:mdna:178]

[0001032975-15-000052:mdna:192]
[same as prior period, unchanged from 0001032975-15-000032:mdna:179]

[0001032975-15-000052:mdna:193]
Other Contingencies

[0001032975-15-000052:mdna:194]
We are subject to an ongoing formal investigation by the Enforcement Division of the U.S. Securities and Exchange Commission (SEC), relating to certain issues including the accounting for Revue inventory valuation reserves that resulted in the restatement described in the Fiscal Year 2014 Annual Report on Form 10-K, revision to our consolidated financial statements concerning warranty accruals and amortization of intangible assets presented in our Amended Annual Report on Form 10-K/A, filed on August 7, 2013, and our transactions with a distributor for Fiscal Year 2007 through Fiscal Year 2009. We have entered into an agreement with the Enforcement Staff to extend the statute of limitations. We are cooperating with the investigation and, after discussions with the Enforcement Staff, we recently made an offer of settlement to resolve the matter, which is subject to approval by the SEC.  The proposed settlement would be entered into by us without admitting or denying the SEC’s findings and would resolve alleged violations of certain provisions of the Securities Exchange Act of 1934 and related rules, including the anti-fraud provisions.  Under the terms of the proposed settlement, we would pay $7.5 million in a civil penalty and agree not to commit or cause any violations of certain provisions of the Securities Exchange Act of 1934 and related rules. There is no assurance that the proposal will be approved by the SEC. In accordance with U.S. GAAP, we have made a corresponding accrual in our financial statements.

[0001032975-15-000052:mdna:195]
[same as prior period, unchanged from 0001032975-15-000032:mdna:182]

[0001032975-15-000052:mdna:196]
Logitech Europe S.A., one of our wholly owned subsidiaries, guaranteed payments of third-party contract manufacturers' purchase obligations. As of September 30, 2015, the maximum amount of this guarantee was $3.8 million, of which $0.9 million of guaranteed purchase obligations were outstanding.

[0001032975-15-000052:mdna:197]
[same as prior period, unchanged from 0001032975-15-000032:mdna:184]

[0001032975-15-000052:mdna:198]
We indemnify certain of our suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of September 30, 2015, no amounts have been accrued for indemnification provisions. We do not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under our indemnification arrangements.

[0001032975-15-000052:mdna:199]
[same as prior period, unchanged from 0001032975-15-000032:mdna:186]

[0001032975-15-000052:mdna:200]
Legal Proceedings

[0001032975-15-000052:mdna:201]
From time to time we are involved in claims and legal proceedings that arise in the ordinary course of our business. We are currently subject to several such claims and a small number of legal proceedings. We believe that these matters lack merit and we intend to vigorously defend against them. Based on currently available information, we do not believe that resolution of pending matters will have a material adverse effect on our financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that our defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on our business, financial condition, cash flows and results of operations in a particular period. Any claims or proceedings against us, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect our business.

[0001032975-15-000052:mdna:202]
38
