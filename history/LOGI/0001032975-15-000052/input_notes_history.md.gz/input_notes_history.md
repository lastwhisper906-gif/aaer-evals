# LOGI note change history — 0001032975-15-000032 → 0001032975-15-000052


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-10-23):
[0001032975-15-000052:note_history:1]
Changes in the Company’s warranty liability for the three and six months ended September 30, 2015 and 2014 were as follows (in thousands):
  (was, 2015-07-24, similarity 0.9053):
[0001032975-15-000032:note_history:1]
Changes in the Company’s warranty liability for three months ended June 30, 2015 and 2014 were as follows (in thousands):

- added (2015-10-23):
[0001032975-15-000052:note_history:2]
|  | Three Months Ended September 30, |  | Six Months Ended September 30, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Beginning of the period | $ | 21,284 |  |  | $ | 23,420 |  |  | $ | 21,710 |  |  | $ | 24,380 |  |
| Provision | 1,792 |  |  | 2,020 |  |  | 3,934 |  |  | 4,226 |  |
| Settlements | (2,677 | ) |  | (3,236 | ) |  | (5,245 | ) |  | (6,402 | ) |
| End of the period | $ | 20,399 |  |  | $ | 22,204 |  |  | $ | 20,399 |  |  | $ | 22,204 |  |

- added (2015-10-23):
[0001032975-15-000052:note_history:3]
Logitech Europe S.A. guaranteed payments of certain third-party contract manufacturers’ purchase obligations. As of September 30, 2015, the maximum amount of this guarantee was $3.8 million, of which $0.9 million of guaranteed purchase obligations were outstanding.

- changed (2015-10-23):
[0001032975-15-000052:note_history:4]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of September 30, 2015, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.
  (was, 2015-07-24, similarity 0.9899):
[0001032975-15-000032:note_history:4]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of June 30, 2015, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

- removed (2015-10-23):
[0001032975-15-000032:note_history:5]
|  |  | Three Months EndedJune 30, |
|  |  | 2015 |  | 2014 |
| Beginning of the period |  | $ | 21,710 |  |  | $ | 24,380 |  |
| Provision |  | 2,142 |  |  | 2,206 |  |
| Settlements |  | (2,568 | ) |  | (3,166 | ) |
| End of the period |  | $ | 21,284 |  |  | $ | 23,420 |  |

- removed (2015-10-23):
[0001032975-15-000032:note_history:6]
Logitech Europe S.A. guaranteed payments of third-party contract manufacturers’ purchase obligations. As of June 30, 2015, the maximum amount of this guarantee was $3.8 million, of which $1.6 million of guaranteed purchase obligations were outstanding.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-10-23):
[0001032975-15-000052:note_history:7]
The condensed consolidated interim financial statements include the accounts of Logitech and its subsidiaries. All intercompany balances and transactions have been eliminated. The condensed consolidated financial statements are presented in accordance with accounting principles generally accepted in the United States of America (“GAAP”) for interim financial information and therefore do not include all the information required by GAAP for complete financial statements. They should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended March 31, 2015, included in its Annual Report on Form 10-K filed with the Securities and Exchange Commission (“SEC”) on June 5, 2015.  In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, financial position, comprehensive income, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and six months ended September 30, 2015 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2016, or any future periods.
  (was, 2015-07-24, similarity 0.743):
[0001032975-15-000032:note_history:7]
The condensed consolidated interim financial statements include the accounts of Logitech and its subsidiaries. All intercompany balances and transactions have been eliminated. The condensed consolidated financial statements are presented in accordance with accounting principles generally accepted in the United States of America (“GAAP”) for interim financial information and therefore do not include all the information required by GAAP for complete financial statements. They should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended March 31, 2015, included in its Annual Report on Form 10-K filed with the Securities and Exchange Commission (“SEC”) on June 5, 2015.  In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal, recurring adjustments, necessary for a fair statement of the results for the periods presented. Operating results for the three months ended June 30, 2015 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2016, or any future periods.

- changed (2015-10-23):
[0001032975-15-000052:note_history:8]
There have been no substantial changes in the Company’s significant accounting policies during the six months ended September 30, 2015 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2015.
  (was, 2015-07-24, similarity 0.9045):
[0001032975-15-000032:note_history:8]
There have been no substantial changes in the Company’s significant accounting policies during the three months ended June 30, 2015 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2015.

- added (2015-10-23):
[0001032975-15-000052:note_history:9]
The preparation of financial statements in conformity with U.S. GAAP requires management to make judgments, estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Examples of significant estimates and assumptions made by management involve the fair value of goodwill, warranty liabilities, accruals for discretionary customer programs, sales return reserves, allowance for doubtful accounts, inventory valuation, restructuring charges, contingent liabilities, uncertain tax positions, and valuation allowances for deferred tax assets. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ materially from those estimates.

- added (2015-10-23):
[0001032975-15-000052:note_history:10]
In July 2015, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update No. 2015-11, "Simplifying the Measurement of Inventory (Topic 330)",  ("ASU 2015-11"). Topic 330, Inventory, currently requires an entity to measure inventory at the lower of cost or market, with market value represented by replacement cost, net realizable value or net realizable value less a normal profit margin. The amendments in ASU 2015-11 require an entity to measure inventory at the lower of cost or net realizable value. ASU 2015-11 is effective in the first quarter of fiscal year 2018 for the Company, with early adoption permitted. The Company does not expect the adoption of this guidance to have a material impact on its condensed consolidated financial statements.

- added (2015-10-23):
[0001032975-15-000052:note_history:11]
In May 2014, the FASB issued Accounting Standards Update No. 2014-9, "Revenue from Contracts with Customers (Topic 606)," ("ASU 2014-9"). ASU 2014-9 outlines a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. Under the new model, recognition of revenue occurs when a customer obtains control of promised goods or services in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. In addition, the new standard requires that reporting companies disclose the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. ASU 2014-09 was originally to be effective for the Company on April 1, 2017. In July 2015, the FASB affirmed a one-year deferral of the effective date of the new revenue standard. The new standard will become effective for the Company on April 1, 2018. Early application is permitted but not before the original effective date of annual periods beginning after December 15, 2016. The new standard is required to be applied retrospectively to each prior reporting period presented or retrospectively with the cumulative effect of initially applying it recognized at the date of initial application. The Company has not yet selected a transition method nor has it determined the impact of the new standard on its condensed consolidated financial statements.

- removed (2015-10-23):
[0001032975-15-000032:note_history:12]
The preparation of financial statements in conformity with U.S. GAAP requires management to make judgments, estimates and assumptions that affect reported amounts of assets, liabilities, net sales and expenses, and the disclosure of contingent assets and liabilities at the date of the condensed consolidated financial statements. Examples of significant estimates and assumptions made by management involve the fair value of goodwill, warranty liabilities, accruals for discretionary customer programs, sales return reserves, allowance for doubtful accounts, inventory valuation, uncertain tax positions, and valuation allowances for deferred tax assets. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ from those estimates.

- removed (2015-10-23):
[0001032975-15-000032:note_history:13]
In May 2014, the FASB issued Accounting Standards Update No. 2014-9, "Revenue from Contracts with Customers (Topic 606)," ("ASU 2014-9"). ASU 2014-9 outlines a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. Under the new model, recognition of revenue occurs when a customer obtains control of promised goods or services in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. In addition, the new standard requires that reporting companies disclose the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. As currently issued, the new standard is effective beginning in the first quarter of fiscal year 2019; early adoption is prohibited. The new standard is required to be applied retrospectively to each prior reporting period presented or retrospectively with the cumulative effect of initially applying it recognized at the date of initial application. The Company has not yet selected a transition method nor has it determined the impact of the new standard on its condensed consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2015-10-23):
[0001032975-15-000052:note_history:14]
The Company had several uncommitted, unsecured bank lines of credit aggregating $46.7 million as of September 30, 2015. There are no financial covenants under these lines of credit with which the Company must comply. As of September 30, 2015, the Company had outstanding bank guarantees of $18.2 million under these lines of credit. There was no borrowing outstanding under these lines of credit as of September 30, 2015 or March 31, 2015.

- removed (2015-10-23):
[0001032975-15-000032:note_history:15]
The Company had several uncommitted, unsecured bank lines of credit aggregating $34.6 million as of June 30, 2015. There are no financial covenants under these lines of credit with which the Company must comply. As of June 30, 2015, the Company had outstanding bank guarantees of $14.3 million under these lines of credit. There was no borrowing outstanding under the line of credit as of June 30, 2015 or March 31, 2015.
