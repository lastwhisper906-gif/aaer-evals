# LOGI 8-K — 0001032975-15-000047 filed 2015-10-22

## item codes, every 8-K on or before 2015-10-23

- 2015-10-22 0001032975-15-000047 — 2.02, 9.01
- 2015-09-11 0001032975-15-000044 — 5.07, 8.01
- 2015-07-24 0001032975-15-000034 — 2.05 — amendment of 0001032975-15-000030
- 2015-07-23 0001032975-15-000030 — 2.02, 9.01
- 2015-06-25 0001032975-15-000025 — 5.02
- 2015-05-14 0001032975-15-000011 — 8.01, 9.01
- 2015-04-23 0001032975-15-000008 — 2.02, 2.05
- 2015-01-22 0001628280-15-000191 — 2.02, 8.01
- 2014-12-23 0001193125-14-450908 — 5.02, 5.07, 8.01
- 2014-11-25 0001193125-14-425233 — 3.01
- 2014-11-13 0001193125-14-411303 — 4.01, 9.01
- 2014-10-23 0001104659-14-073164 — 2.02, 9.01
- 2014-09-04 0001193125-14-331214 — 4.02, 9.01
- 2014-08-18 0001193125-14-313346 — 3.01, 9.01
- 2014-07-24 0001104659-14-053065 — 2.02, 9.01
- 2014-06-05 0001193125-14-226177 — 3.01, 9.01
- 2014-05-22 0001193125-14-208777 — 8.01, 9.01
- 2014-04-24 0001104659-14-029650 — 2.02, 9.01
- 2014-01-23 0001104659-14-003619 — 2.02, 9.01
- 2013-10-24 0001104659-13-077404 — 2.02, 9.01
- 2013-09-09 0001193125-13-361441 — 5.02, 5.07, 8.01, 9.01
- 2013-09-06 0001193125-13-359930 — 5.02, 9.01
- 2013-08-02 0001193125-13-317343 — 5.02
- 2013-07-25 0001104659-13-056372 — 2.02, 9.01
- 2013-06-28 0001193125-13-277394 — 5.02, 9.01
- 2013-06-20 0001193125-13-265914 — 8.01, 9.01
- 2013-04-25 0001104659-13-032570 — 2.02, 9.01
- 2013-04-17 0001193125-13-158923 — 5.02, 9.01
- 2013-03-01 0001193125-13-085804 — 2.05
- 2013-01-24 0001104659-13-004214 — 2.02, 9.01
- 2013-01-02 0001193125-13-000058 — 5.02
- 2012-10-25 0001104659-12-070966 — 2.02, 9.01
- 2012-09-11 0001193125-12-388070 — 5.02, 5.07, 8.01, 9.01
- 2012-08-22 0001193125-12-364167 — 5.02, 8.01, 9.01
- 2012-07-26 0001104659-12-051084 — 2.02, 9.01
- 2012-06-08 0001193125-12-264132 — 2.05, 9.01 — amendment, the index does not say of what
- 2012-04-26 0001193125-12-183657 — 5.02, 9.01
- 2012-04-26 0001104659-12-028470 — 2.02, 2.05, 9.01
- 2012-03-15 0001193125-12-115954 — 5.02, 9.01
- 2012-01-26 0001104659-12-004014 — 2.02, 9.01
- 2012-01-04 0001193125-12-002212 — 1.01, 2.03, 9.01
- 2011-10-27 0001104659-11-058150 — 2.02, 9.01
- 2011-09-12 0001193125-11-245931 — 5.07
- 2011-07-28 0001193125-11-200929 — 5.02, 9.01
- 2011-07-28 0001193125-11-199704 — 2.02, 9.01
- 2011-04-28 0001193125-11-112669 — 2.02, 9.01
- 2011-03-24 0001193125-11-076483 — 5.02, 9.01
- 2011-01-27 0001032975-11-000003 — 9.01
- 2010-10-28 0001032975-10-000032 — 9.01
- 2010-09-13 0001032975-10-000022 — 5.07
- 2010-07-29 0001032975-10-000010 — 2.02, 9.01
- 2010-06-10 0001193125-10-136877 — 5.02, 9.01
- 2010-05-03 0001193125-10-104337 — 5.02
- 2010-04-29 0001032975-10-000008 — 2.02, 9.01
- 2010-02-19 0001032975-10-000006 — 9.01 — amendment of 0001193125-09-252416
- 2010-01-21 0001032975-10-000002 — 2.02, 9.01
- 2009-12-14 0001193125-09-252416 — 2.01, 9.01
- 2009-11-17 0001032975-09-000023 — 1.01
- 2009-10-22 0001032975-09-000018 — 9.01
- 2009-09-22 0001193125-09-195545 — 5.02, 9.01
- 2009-09-03 0001032975-09-000013 — 8.01
- 2009-07-23 0001140361-09-016802 — 2.02, 9.01
- 2009-06-01 0001193125-09-122550 — 5.02
- 2009-04-23 0001193125-09-085054 — 2.02, 9.01
- 2009-04-02 0001193125-09-071272 — 5.02, 9.01
- 2009-01-20 0001193125-09-008454 — 2.05 — amendment of 0001193125-09-002609
- 2009-01-20 0001193125-09-007902 — 2.02, 9.01
- 2009-01-07 0001193125-09-002609 — 2.05, 9.01
- 2009-01-07 0001193125-09-002370 — 5.02, 9.01
- 2008-12-09 0001193125-08-250543 — 5.02, 9.01
- 2008-10-21 0001193125-08-213212 — 2.02, 9.01
- 2008-07-22 0001193125-08-154721 — 2.02, 9.01
- 2008-06-24 0001193125-08-139163 — 5.03, 9.01
- 2008-05-13 0001193125-08-113263 — 5.02, 9.01
- 2008-04-22 0001193125-08-086176 — 2.02, 9.01

## late-filing notifications on or before 2015-10-23

- 2015-06-02 0001032975-15-000020 — NT 10-K, for the period ended 2015-03-31
- 2014-11-06 0001193125-14-401306 — NT 10-Q, for the period ended 2014-09-30
- 2014-07-24 0001193125-14-277575 — NT 10-Q, for the period ended 2014-06-30
- 2014-05-22 0001193125-14-208712 — NT 10-K, for the period ended 2014-03-31
- 2009-08-06 0001032975-09-000006 — NT 10-Q, for the period ended 2009-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001032975-15-000047:8k_2_02:1]
EX-99.1
2
exhibit991q2fy16.htm
EXHIBIT 99.1

[0001032975-15-000047:8k_2_02:2]
Exhibit

[0001032975-15-000047:8k_2_02:3]
Exhibit 99.1

[0001032975-15-000047:8k_2_02:4]
Editorial Contacts:

[0001032975-15-000047:8k_2_02:5]
Joe Greenhalgh, Vice President, Investor Relations - USA (510) 713-4430

[0001032975-15-000047:8k_2_02:6]
Krista Todd, Vice President, External Communications - USA (510) 713-5834

[0001032975-15-000047:8k_2_02:7]
Ben Starkie, Corporate Communications - Europe +41-(0) 79-292-3499

[0001032975-15-000047:8k_2_02:8]
Logitech Q2 Delivers Best Retail Sales Growth Since 2010

[0001032975-15-000047:8k_2_02:9]
Retail Sales Up 12 Percent in Constant Currency

[0001032975-15-000047:8k_2_02:10]
NEWARK, Calif. - Oct. 21, 2015 and LAUSANNE, Switzerland, Oct. 22, 2015 - Logitech International (SIX: LOGN) (Nasdaq: LOGI) today announced financial results for the second quarter of Fiscal Year 2016.

[0001032975-15-000047:8k_2_02:11]
| • | Q2 sales were $540 million, up 2 percent compared to Q2 of the prior year. Q2 retail sales (total sales excluding OEM and Lifesize) were $496 million and grew 12 percent in constant currency. |

[0001032975-15-000047:8k_2_02:12]
| • | Q2 GAAP operating income was $26 million. Q2 GAAP earnings per share (EPS) were $0.11, compared to $0.22 in the same quarter a year ago. |

[0001032975-15-000047:8k_2_02:13]
| • | Q2 non-GAAP operating income was $42 million, with non-GAAP EPS of $0.22, compared to $0.31 in the same quarter a year ago. |

[0001032975-15-000047:8k_2_02:14]
“I’m excited by our performance this quarter. We delivered our best retail sales growth in almost five years, exceeding expectations,” said Bracken P. Darrell, Logitech president and chief executive officer. “Our growth was broad-based across categories and regions. In constant currency Americas grew 9 percent, EMEA grew 7 percent and Asia Pacific grew 26 percent. In our Growth category, Gaming, Video Collaboration and Mobile Speakers each grew more than 50 percent. Our reinvigorated innovation engine and commitment to design are delivering powerfully and we have strong momentum heading into the holiday peak season.”

[0001032975-15-000047:8k_2_02:15]
Outlook

[0001032975-15-000047:8k_2_02:16]
Logitech confirmed its FY 2016 outlook of $150 million in non-GAAP operating income and 7 percent growth for retail sales in constant currency.

[0001032975-15-000047:8k_2_02:17]
Prepared Remarks Available Online

[0001032975-15-000047:8k_2_02:18]
Logitech has made its prepared written remarks for the financial results teleconference available online on the Logitech corporate Web site at http://ir.logitech.com.

[0001032975-15-000047:8k_2_02:19]
Financial Results Teleconference and Webcast

[0001032975-15-000047:8k_2_02:20]
Logitech will hold a financial results teleconference to discuss the results for Q2 FY 2016 on Oct. 22, 2015 at 8:30 a.m. Eastern Daylight Time and 2:30 p.m. Central European Summer Time. A live webcast of the call will be available on the Logitech corporate website at http://ir.logitech.com.

[0001032975-15-000047:8k_2_02:21]
Use of Non-GAAP Financial Information

[0001032975-15-000047:8k_2_02:22]
To facilitate comparisons to Logitech’s historical results, Logitech has included non-GAAP adjusted measures, which exclude share-based compensation expense, amortization of other intangible assets, restructuring charges (credits), other restructuring-related charges, investment impairment (recovery), benefit from (provision for) income taxes, one-time special charges and other items detailed under “Supplemental Financial Information” after the

[0001032975-15-000047:8k_2_02:23]
tables below. Logitech also presents percentage sales growth in constant currency, a non-GAAP measure, to show performance unaffected by fluctuations in currency exchange rates.  Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales. Logitech believes this information will help investors to evaluate its current period performance and trends in its business. With respect to the Company’s outlook for non-GAAP operating income, most of these excluded amounts pertain to events that have not yet occurred and are not currently possible to estimate with a reasonable degree of accuracy. Therefore, no reconciliation to the GAAP amounts has been provided for Fiscal Year 2016.

[0001032975-15-000047:8k_2_02:24]
About Logitech

[0001032975-15-000047:8k_2_02:25]
Logitech designs products that have an everyday place in people's lives, connecting them to the digital experiences they care about. Over 30 years ago Logitech started connecting people through computers, and now it’s designing products that bring people together through music, gaming, video and computing. Founded in 1981, Logitech International is a Swiss public company listed on the SIX Swiss Exchange (LOGN) and on the Nasdaq Global Select Market (LOGI). Find Logitech at www.logitech.com, the company blog or @Logitech.

[0001032975-15-000047:8k_2_02:26]
# # #

[0001032975-15-000047:8k_2_02:27]
Note that unless noted otherwise, comparisons are year over year.

[0001032975-15-000047:8k_2_02:28]
2015 Logitech, Logicool, Logi and other Logitech marks are owned by Logitech and may be registered. All other trademarks are the property of their respective owners. For more information about Logitech and its products, visit the company’s website at www.logitech.com.

[0001032975-15-000047:8k_2_02:29]
(LOGIIR)

[0001032975-15-000047:8k_2_02:30]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| (In thousands, except per share amounts) -Unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | September 30 |  | September 30 |
| GAAP CONSOLIDATED STATEMENTS OF OPERATIONS |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Net sales |  | $ | 539,862 |  |  | $ | 530,311 |  |  | $ | 1,010,182 |  |  | $ | 1,012,514 |  |
| Cost of goods sold |  | 353,851 |  |  | 325,533 |  |  | 652,442 |  |  | 625,984 |  |
| Gross profit |  | 186,011 |  |  | 204,778 |  |  | 357,740 |  |  | 386,530 |  |
| % of net sales |  | 34.5 | % |  | 38.6 | % |  | 35.4 | % |  | 38.2 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Marketing and selling |  | 89,877 |  |  | 95,862 |  |  | 177,304 |  |  | 186,908 |  |
| Research and development |  | 34,898 |  |  | 32,325 |  |  | 68,731 |  |  | 63,641 |  |
| General and administrative |  | 26,851 |  |  | 34,470 |  |  | 57,355 |  |  | 71,149 |  |
| Restructuring charges, net |  | 8,696 |  |  | — |  |  | 21,691 |  |  | — |  |
| Total operating expenses |  | 160,322 |  |  | 162,657 |  |  | 325,081 |  |  | 321,698 |  |
| Operating income |  | 25,689 |  |  | 42,121 |  |  | 32,659 |  |  | 64,832 |  |
| Interest income, net |  | 192 |  |  | 355 |  |  | 456 |  |  | 613 |  |
| Other expense, net |  | (780 | ) |  | (885 | ) |  | (1,901 | ) |  | (1,083 | ) |
| Income before income taxes |  | 25,101 |  |  | 41,591 |  |  | 31,214 |  |  | 64,362 |  |
| Provision for income taxes |  | 7,004 |  |  | 5,501 |  |  | 5,680 |  |  | 8,596 |  |
| Net income |  | $ | 18,097 |  |  | $ | 36,090 |  |  | $ | 25,534 |  |  | $ | 55,766 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.11 |  |  | $ | 0.22 |  |  | $ | 0.16 |  |  | $ | 0.34 |  |
| Diluted |  | $ | 0.11 |  |  | $ | 0.22 |  |  | $ | 0.15 |  |  | $ | 0.34 |  |
| Weighted average shares used to compute net income per share : |  |  |  |  |  |  |  |  |
| Basic |  | 163,515 |  |  | 163,230 |  |  | 163,957 |  |  | 163,121 |  |
| Diluted |  | 165,841 |  |  | 166,065 |  |  | 166,352 |  |  | 165,949 |  |
| Cash dividends per share |  | 0.53 |  |  | — |  |  | 0.53 |  |  | — |  |

[0001032975-15-000047:8k_2_02:31]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |
| (In thousands) |  |  |  |  |
|  |  | September 30 |  | March 31, |
| CONSOLIDATED BALANCE SHEETS |  | 2015 |  | 2015 |
|  |  | (Unaudited) |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 365,774 |  |  | $ | 537,038 |  |
| Accounts receivable, net |  | 274,730 |  |  | 179,823 |  |
| Inventories |  | 328,054 |  |  | 270,730 |  |
| Other current assets |  | 73,504 |  |  | 64,429 |  |
| Total current assets |  | 1,042,062 |  |  | 1,052,020 |  |
| Non-current assets: |  |  |  |  |
| Property, plant and equipment, net |  | 108,184 |  |  | 91,593 |  |
| Goodwill |  | 218,207 |  |  | 218,213 |  |
| Other intangible assets |  | 666 |  |  | 1,866 |  |
| Other assets |  | 60,656 |  |  | 62,988 |  |
| Total assets |  | $ | 1,429,775 |  |  | $ | 1,426,680 |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 356,686 |  |  | $ | 299,995 |  |
| Accrued and other current liabilities |  | 231,688 |  |  | 194,912 |  |
| Total current liabilities |  | 588,374 |  |  | 494,907 |  |
| Non-current liabilities: |  | 172,428 |  |  | 173,639 |  |
| Total liabilities |  | 760,802 |  |  | 668,546 |  |
| Total shareholders' equity |  | 668,973 |  |  | 758,134 |  |
| Total liabilities and shareholders' equity |  | $ | 1,429,775 |  |  | $ | 1,426,680 |  |

[0001032975-15-000047:8k_2_02:32]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| (In thousands) - Unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | September 30 |  | September 30 |
| CONSOLIDATED STATEMENTS OF CASH FLOWS |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 18,097 |  |  | $ | 36,090 |  |  | $ | 25,534 |  |  | $ | 55,766 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  | 11,721 |  |  | 9,741 |  |  | 22,237 |  |  | 19,692 |  |
| Amortization of other intangible assets |  | 494 |  |  | 2,576 |  |  | 1,226 |  |  | 5,358 |  |
| Share-based compensation expense |  | 6,508 |  |  | 6,061 |  |  | 13,257 |  |  | 12,999 |  |
| Impairment of investments |  | 77 |  |  | 105 |  |  | 180 |  |  | 105 |  |
| Gain on disposal of property, plant and equipment |  | — |  |  | (32 | ) |  | — |  |  | (10 | ) |
| Excess tax benefits from share-based compensation |  | (498 | ) |  | (285 | ) |  | (1,163 | ) |  | (666 | ) |
| Deferred income taxes |  | 7,684 |  |  | (526 | ) |  | 952 |  |  | (2,358 | ) |
| Changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | (54,195 | ) |  | (36,898 | ) |  | (95,403 | ) |  | (73,561 | ) |
| Inventories |  | (1,278 | ) |  | (8,521 | ) |  | (55,442 | ) |  | (26,984 | ) |
| Other assets |  | (6,128 | ) |  | (3,577 | ) |  | (8,511 | ) |  | (5,640 | ) |
| Accounts payable |  | 15,820 |  |  | 19,337 |  |  | 50,361 |  |  | 60,112 |  |
| Accrued and other liabilities |  | 12,435 |  |  | 8,875 |  |  | 31,910 |  |  | 15,891 |  |
| Net cash provided by (used in) operating activities |  | 10,737 |  |  | 32,946 |  |  | (14,862 | ) |  | 60,704 |  |
| Investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  | (15,987 | ) |  | (13,721 | ) |  | (31,277 | ) |  | (24,964 | ) |
| Investment in privately held companies |  | (240 | ) |  | (1,500 | ) |  | (480 | ) |  | (2,550 | ) |
| Purchase of trading investments |  | (1,746 | ) |  | (1,776 | ) |  | (2,649 | ) |  | (2,230 | ) |
| Proceeds from sales of trading investments |  | 2,015 |  |  | 2,039 |  |  | 2,855 |  |  | 2,545 |  |
| Net cash used in investing activities |  | (15,958 | ) |  | (14,958 | ) |  | (31,551 | ) |  | (27,199 | ) |
| Financing activities: |  |  |  |  |  |  |  |  |
| Payment of cash dividends |  | (85,915 | ) |  | — |  |  | (85,915 | ) |  | — |  |
| Contingent consideration related to prior acquisition |  | — |  |  | — |  |  | — |  |  | (100 | ) |
| Purchases of treasury shares |  | (39,988 | ) |  | — |  |  | (48,802 | ) |  | — |  |
| Repurchase of ESPP awards |  | — |  |  | (1,078 | ) |  | — |  |  | (1,078 | ) |
| Proceeds from sales of shares upon exercise of options and purchase rights |  | 7,037 |  |  | 959 |  |  | 11,103 |  |  | 1,533 |  |
| Tax withholdings related to net share settlements of restricted stock units |  | (2,206 | ) |  | (628 | ) |  | (3,502 | ) |  | (1,323 | ) |
| Excess tax benefits from share-based compensation |  | 498 |  |  | 285 |  |  | 1,163 |  |  | 666 |  |
| Net cash used in financing activities |  | (120,574 | ) |  | (462 | ) |  | (125,953 | ) |  | (302 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  | (659 | ) |  | (2,285 | ) |  | 1,102 |  |  | (2,393 | ) |
| Net increase (decrease) in cash and cash equivalents |  | (126,454 | ) |  | 15,241 |  |  | (171,264 | ) |  | 30,810 |  |
| Cash and cash equivalents, beginning of the period |  | 492,228 |  |  | 484,981 |  |  | 537,038 |  |  | 469,412 |  |
| Cash and cash equivalents, end of the period |  | $ | 365,774 |  |  | $ | 500,222 |  |  | $ | 365,774 |  |  | $ | 500,222 |  |

[0001032975-15-000047:8k_2_02:33]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |  |  |  |  |
| (In thousands, except per share amounts) - Unaudited |  |  |  |  |  |  |  |  |  |  |
| NET SALES |  | Three Months Ended |  | Six Months Ended |
|  |  | September 30 |  | September 30 |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2015 |  | 2014 |  | Change |  | 2015 |  | 2014 |  | Change |
| Net sales by channel: |  |  |  |  |  |  |  |  |  |  |  |  |
| Retail |  | $ | 496,263 |  |  | $ | 473,463 |  |  | 5 | % |  | $ | 921,651 |  |  | $ | 897,276 |  |  | 3 | % |
| OEM |  | 22,231 |  |  | 28,394 |  |  | (22 | ) |  | 44,529 |  |  | 61,027 |  |  | (27 | ) |
| Video Conferencing |  | 21,368 |  |  | 28,454 |  |  | (25 | ) |  | 44,002 |  |  | 54,211 |  |  | (19 | ) |
| Total net sales |  | $ | 539,862 |  |  | $ | 530,311 |  |  | 2 |  |  | $ | 1,010,182 |  |  | $ | 1,012,514 |  |  | — |  |
| Net retail sales by product category(*): |  |  |  |  |  |  |  |  |  |  |  |  |
| Mobile Speakers |  | $ | 80,550 |  |  | $ | 48,538 |  |  | 66 |  |  | 121,094 |  |  | 77,367 |  |  | 57 |  |
| Gaming |  | 67,624 |  |  | 47,506 |  |  | 42 |  |  | $ | 111,294 |  |  | $ | 94,382 |  |  | 18 |  |
| Video Collaboration |  | 20,059 |  |  | 13,808 |  |  | 45 |  |  | 41,235 |  |  | 29,033 |  |  | 42 |  |
| Tablet & Other Accessories |  | 18,549 |  |  | 28,158 |  |  | (34 | ) |  | 37,358 |  |  | 59,874 |  |  | (38 | ) |
| Growth |  | 186,782 |  |  | 138,010 |  |  | 35 |  |  | 310,981 |  |  | 260,656 |  |  | 19 |  |
| Pointing Devices |  | 124,668 |  |  | 127,693 |  |  | (2 | ) |  | 241,653 |  |  | 240,735 |  |  | — |  |
| Keyboards & Combos |  | 102,098 |  |  | 105,677 |  |  | (3 | ) |  | 207,927 |  |  | 211,166 |  |  | (2 | ) |
| Audio-PC & Wearables |  | 46,342 |  |  | 57,191 |  |  | (19 | ) |  | 92,041 |  |  | 105,739 |  |  | (13 | ) |
| PC Webcams |  | 23,360 |  |  | 25,282 |  |  | (8 | ) |  | 45,041 |  |  | 45,745 |  |  | (2 | ) |
| Home Control |  | 12,610 |  |  | 18,776 |  |  | (33 | ) |  | 22,864 |  |  | 31,108 |  |  | (27 | ) |
| Profit Maximization |  | 309,078 |  |  | 334,619 |  |  | (8 | ) |  | 609,526 |  |  | 634,493 |  |  | (4 | ) |
| Retail Strategic Sales |  | 495,860 |  |  | 472,629 |  |  | 5 |  |  | 920,507 |  |  | 895,149 |  |  | 3 |  |
| Non-Strategic |  | 403 |  |  | 834 |  |  | (52 | ) |  | 1,144 |  |  | 2,127 |  |  | (46 | ) |
| Total net retail sales |  | $ | 496,263 |  |  | $ | 473,463 |  |  | 5 |  |  | $ | 921,651 |  |  | $ | 897,276 |  |  | 3 |  |
| __________________ |  |  |  |  |  |  |  |  |  |  |  |  |

[0001032975-15-000047:8k_2_02:34]
* Certain products within the retail product categories as presented in prior periods have been reclassified to conform to the current periods' presentation, with no impact on previously reported total net retail sales.

[0001032975-15-000047:8k_2_02:35]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |  |
| (In thousands, except per share amounts) - Unaudited |  |  |  |  |  |  |  |  |  |
| GAAP TO NON GAAP RECONCILIATION (A) |  | Three Months Ended |  | Six Months Ended |
|  |  | September 30 |  | September 30 |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2015 |  | 2014 |  | 2015 |  |  | 2014 |
| Gross profit - GAAP |  | $ | 186,011 |  |  | $ | 204,778 |  |  | $ | 357,740 |  |  |  | $ | 386,530 |  |
| Share-based compensation expense |  | 580 |  |  | 627 |  |  | 1,185 |  |  |  | 1,165 |  |
| Amortization of other intangible assets |  | 279 |  |  | 543 |  |  | 787 |  |  |  | 1,093 |  |
| Gross profit - Non-GAAP |  | $ | 186,870 |  |  | $ | 205,948 |  |  | $ | 359,712 |  |  |  | $ | 388,788 |  |
| Gross margin - GAAP |  | 34.5 | % |  | 38.6 | % |  | 35.4 | % |  |  | 38.2 | % |
| Gross margin - Non-GAAP |  | 34.6 | % |  | 38.8 | % |  | 35.6 | % |  |  | 38.4 | % |
| Operating expenses - GAAP |  | $ | 160,322 |  |  | $ | 162,657 |  |  | $ | 325,081 |  |  |  | $ | 321,698 |  |
| Less: Share-based compensation expense |  | 5,928 |  |  | 5,434 |  |  | 12,065 |  |  |  | 11,834 |  |
| Less: Amortization of other intangible assets |  | 215 |  |  | 2,033 |  |  | 439 |  |  |  | 4,265 |  |
| Less: Restructuring charges, net |  | 8,696 |  |  | — |  |  | 21,691 |  |  |  | — |  |
| Less: One time special charge |  | 321 |  |  | 8,020 |  |  | 4,370 |  | * |  | 16,996 |  |
| Operating expenses - Non-GAAP |  | $ | 145,162 |  |  | $ | 147,170 |  |  | $ | 286,516 |  |  |  | $ | 288,603 |  |
| % of net sales - GAAP |  | 29.7 | % |  | 30.7 | % |  | 32.2 | % |  |  | 31.8 | % |
| % of net sales - Non - GAAP |  | 26.9 | % |  | 27.8 | % |  | 28.4 | % |  |  | 28.5 | % |
| Operating income - GAAP |  | $ | 25,689 |  |  | $ | 42,121 |  |  | $ | 32,659 |  |  |  | $ | 64,832 |  |
| Share-based compensation expense |  | 6,508 |  |  | 6,061 |  |  | 13,250 |  |  |  | 12,999 |  |
| Amortization of other intangible assets |  | 494 |  |  | 2,576 |  |  | 1,226 |  |  |  | 5,358 |  |
| Restructuring charges, net |  | 8,696 |  |  | — |  |  | 21,691 |  |  |  | — |  |
| One time special charge |  | 321 |  |  | 8,020 |  |  | 4,370 |  | * |  | 16,996 |  |
| Operating income - Non - GAAP |  | $ | 41,708 |  |  | $ | 58,778 |  |  | $ | 73,196 |  |  |  | $ | 100,185 |  |
| % of net sales - GAAP |  | 4.8 | % |  | 7.9 | % |  | 3.2 | % |  |  | 6.4 | % |
| % of net sales - Non - GAAP |  | 7.7 | % |  | 11.1 | % |  | 7.2 | % |  |  | 9.9 | % |
| Net income - GAAP |  | $ | 18,097 |  |  | $ | 36,090 |  |  | $ | 25,534 |  |  |  | $ | 55,766 |  |
| Share-based compensation expense |  | 6,508 |  |  | 6,061 |  |  | 13,250 |  |  |  | 12,999 |  |
| Amortization of other intangible assets |  | 494 |  |  | 2,576 |  |  | 1,226 |  |  |  | 5,358 |  |
| Restructuring charges, net |  | 8,696 |  |  | — |  |  | 21,691 |  |  |  | — |  |
| One time special charge |  | 321 |  |  | 8,020 |  |  | 4,370 |  | * |  | 16,996 |  |
| Impairment of investment |  | 77 |  |  | 105 |  |  | 180 |  |  |  | 105 |  |
| Provision for income taxes |  | 2,082 |  |  | (1,803 | ) |  | (3,238 | ) |  |  | (3,907 | ) |
| Net income - Non - GAAP |  | $ | 36,275 |  |  | $ | 51,049 |  |  | $ | 63,013 |  |  |  | $ | 87,317 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  | $ | 0.11 |  |  | $ | 0.22 |  |  | $ | 0.15 |  |  |  | $ | 0.34 |  |
| Diluted - Non - GAAP |  | $ | 0.22 |  |  | $ | 0.31 |  |  | $ | 0.38 |  |  |  | $ | 0.53 |  |
| Shares used to compute net income per share: |  |  |  |  |  |  |  |  |  |
| Diluted - GAAP and Non - GAAP |  | 165,841 |  |  | 166,065 |  |  | 166,352 |  |  |  | 165,949 |  |

[0001032975-15-000047:8k_2_02:36]
* These expenses include an increase of $3.5 million in the accrual for a proposed settlement of the SEC investigation and other expenses related to that investigation.

[0001032975-15-000047:8k_2_02:37]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| (In thousands, except per share amounts) - Unaudited |  |  |  |  |  |  |  |  |
| SHARED BASED COMPENSATION EXPENSE |  | Three Months Ended |  | Six Months Ended |
|  |  | September 30 |  | September 30 |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Share-based Compensation Expense |  |  |  |  |  |  |  |  |
| Cost of goods sold |  | $ | 580 |  |  | $ | 627 |  |  | $ | 1,185 |  |  | $ | 1,165 |  |
| Marketing and selling |  | 2,062 |  |  | 1,653 |  |  | 4,180 |  |  | 4,209 |  |
| Research and Development |  | 756 |  |  | 552 |  |  | 1,543 |  |  | 1,396 |  |
| General and administrative |  | 3,110 |  |  | 3,229 |  |  | 6,342 |  |  | 6,229 |  |
| Restructuring |  | — |  |  | — |  |  | 7 |  |  | — |  |
| Income tax provision (benefit) |  | 304 |  |  | (1,913 | ) |  | (1,033 | ) |  | (3,097 | ) |
| Total share-based compensation expense, net of income taxes |  | $ | 6,812 |  |  | $ | 4,148 |  |  | $ | 12,224 |  |  | $ | 9,902 |  |
| __________________ |  |  |  |  |  |  |  |  |

[0001032975-15-000047:8k_2_02:38]
(A) Non-GAAP Financial Measures

[0001032975-15-000047:8k_2_02:39]
To supplement our condensed consolidated financial results prepared in accordance with GAAP, we use a number of financial measures, both GAAP and non-GAAP, in analyzing and assessing our overall business performance, for making operating decisions and for forecasting and planning future periods. We consider the use of non-GAAP financial measures helpful in assessing our current financial performance, ongoing operations and prospects for the future as well as understanding financial and business trends relating to our financial condition and results of operations.

[0001032975-15-000047:8k_2_02:40]
While we use non-GAAP financial measures as a tool to enhance our understanding of certain aspects of our financial performance and to provide incremental insight into the underlying factors and trends affecting both our performance and our cash-generating potential, we do not consider these measures to be a substitute for, or superior to, the information provided by GAAP financial measures. Consistent with this approach, we believe that disclosing non-GAAP financial measures to the readers of our financial statements provides useful supplemental data that, while not a substitute for GAAP financial measures, can offer insight in the review of our financial and operational performance and enables investors to more fully understand trends in our current and future performance. In assessing our business during the quarter ended September 30, 2015, we excluded items in the following general categories, each of which are described below:

[0001032975-15-000047:8k_2_02:41]
Share-based compensation expenses. We believe that providing non-GAAP measures excluding share-based compensation expense, in addition to the GAAP measures, allows for a more transparent comparison of our financial results from period to period. We prepare and maintain our budgets and forecasts for future periods on a basis consistent with this non-GAAP financial measure. Further, companies use a variety of types of equity awards as well as a variety of methodologies, assumptions and estimates to determine share-based compensation expense. We believe that excluding share-based compensation expense enhances our ability and the ability of investors to understand the impact of non-cash share-based compensation on our operating results and to compare our results against the results of other companies.

[0001032975-15-000047:8k_2_02:42]
Amortization of other intangible assets. We incur intangible asset amortization expense, primarily in connection with our acquisitions of various businesses and technologies. The amortization of purchased intangibles varies depending on the level of acquisition activity. We exclude these various charges in budgeting, planning and forecasting future periods and we believe that providing the non-GAAP measures excluding these various non-cash charges, as well as the GAAP measures, provides additional insight when comparing our operating expenses and financial results from period to period.

[0001032975-15-000047:8k_2_02:43]
Restructuring charges. These expenses are associated with re-aligning our business strategies based on current economic conditions. We have undertaken several restructurings in recent years. In connection with our restructuring initiatives, we incurred restructuring charges related to employee terminations, facility closures and early cancellation of certain contracts. We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP

[0001032975-15-000047:8k_2_02:44]
measures, assists our investors because such charges are not reflective of our ongoing operating results in the current period.

[0001032975-15-000047:8k_2_02:45]
Impairment of investment. We incur investment impairment, primarily related to our investments in various privately-held companies. The investment impairment varies depending on the operational and financial performance of the privately-held companies we invested in. We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges are not reflective of our ongoing operations.

[0001032975-15-000047:8k_2_02:46]
One-time special charges:  costs related to investigations and related expenses.  These expenses are forensic accounting, audit, consulting and legal fees related to the Audit Committee’s investigation and the ongoing formal investigation by and settlement discussion with the Securities and Exchange Commission (SEC), together with accruals based on settlement discussion with the SEC.  We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges are one-time in nature and not reflective of our ongoing operations.

[0001032975-15-000047:8k_2_02:47]
Other charges. We provided non-GAAP measures excluding the effect of certain charges and income that are not reflective of our ongoing operations.

[0001032975-15-000047:8k_2_02:48]
In addition, Logitech presents percentage sales growth in constant currency, a non-GAAP measure, to show performance unaffected by fluctuations in currency exchange rates.  Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales. Sales for the three months ended September 30, 2015 compared to sales for the three months ended September 30, 2014 grew 8 percent in constant currency and grew 2 percent in U.S. Dollars. Retail sales for the three months ended September 30, 2015 compared to retail sales for the three months ended September 30, 2014 grew 12 percent in constant currency and grew 5 percent in U.S. Dollars.

[0001032975-15-000047:8k_2_02:49]
Each of the non-GAAP financial measures described above, and used in this press release, should not be considered in isolation from, or as a substitute for, a measure of financial performance prepared in accordance with GAAP. Further, investors are cautioned that there are inherent limitations associated with the use of each of these non-GAAP financial measures as an analytical tool. In particular, these non-GAAP financial measures are not based on a comprehensive set of accounting rules or principles and many of the adjustments to the GAAP financial measures reflect the exclusion of items that are recurring and may be reflected in the Company’s financial results for the foreseeable future. We compensate for these limitations by providing specific information in the reconciliation included in this press release regarding the GAAP amounts excluded from the non-GAAP financial measures. In addition, as noted above, we evaluate the non-GAAP financial measures together with the most directly comparable GAAP financial information.
