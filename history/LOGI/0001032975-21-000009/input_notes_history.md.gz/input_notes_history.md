# LOGI note change history — 0001032975-20-000048 → 0001032975-21-000009


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-01-21):
[0001032975-21-000009:note_history:1]
Changes in the Company’s warranty liability for the three and nine months ended December 31, 2020 and 2019 were as follows (in thousands):
  (was, 2020-10-22, similarity 0.9615):
[0001032975-20-000048:note_history:1]
Changes in the Company’s warranty liability for the three and six months ended September 30, 2020 and 2019 were as follows (in thousands):

- changed (2021-01-21):
[0001032975-21-000009:note_history:2]
|  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |  |  |  |
| Beginning of the period | $ | 41,782 |  |  | $ | 37,222 |  |  | $ | 40,039 |  |  | $ | 34,229 |  |  |  |  |
| Provision | 13,692 |  |  | 9,608 |  |  | 28,575 |  |  | 26,652 |  |  |  |  |
| Settlements | (8,371) |  |  | (6,840) |  |  | (22,073) |  |  | (20,544) |  |  |  |  |
| Currency translation | 489 |  |  | 187 |  |  | 1,051 |  |  | (160) |  |  |  |  |
| End of the period | $ | 47,592 |  |  | $ | 40,177 |  |  | $ | 47,592 |  |  | $ | 40,177 |  |  |  |  |
  (was, 2020-10-22, similarity 0.7103):
[0001032975-20-000048:note_history:2]
|  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Beginning of the period | $ | 39,450 |  |  | $ | 35,814 |  |  | $ | 40,039 |  |  | $ | 34,229 |  |
| Provision | 9,494 |  |  | 8,509 |  |  | 14,883 |  |  | 17,044 |  |
| Settlements | (7,541 | ) |  | (6,727 | ) |  | (13,702 | ) |  | (13,704 | ) |
| Currency translation | 379 |  |  | (374 | ) |  | 562 |  |  | (347 | ) |
| End of the period | $ | 41,782 |  |  | $ | 37,222 |  |  | $ | 41,782 |  |  | $ | 37,222 |  |

- added (2021-01-21):
[0001032975-21-000009:note_history:3]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these

- changed (2021-01-21):
[0001032975-21-000009:note_history:4]
indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of December 31, 2020, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.
  (was, 2020-10-22, similarity 0.794):
[0001032975-20-000048:note_history:4]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of September 30, 2020, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-01-21):
[0001032975-21-000009:note_history:5]
The Company and Summary of Significant Accounting Policies and Estimates
The Company
  (was, 2020-10-22, similarity 0.9231):
[0001032975-20-000048:note_history:5]
The Company and Summary of Significant Accounting Policies and Estimates

- changed (2021-01-21):
[0001032975-21-000009:note_history:6]
Logitech International S.A, together with its consolidated subsidiaries, (Logitech or the Company) designs, manufactures and markets products that have an everyday place in people's lives, connecting them to the digital experiences they care about. Almost 40 years ago, Logitech created products to improve experiences around the personal PC platform, and today it is a multi-brand, multi-category company designing products that enable better experiences consuming, sharing and creating any digital content such as computing, gaming, video and music, whether it is on a computer, mobile device or in the cloud.
  (was, 2020-10-22, similarity 0.9877):
[0001032975-20-000048:note_history:6]
Logitech International S.A, together with its consolidated subsidiaries, (Logitech or the Company) designs, manufactures and markets products that have an everyday place in people's lives, connecting them to the digital experiences they care about. More than 35 years ago, Logitech created products to improve experiences around the personal PC platform, and today it is a multi-brand, multi-category company designing products that enable better experiences consuming, sharing and creating any digital content such as computing, gaming, video and music, whether it is on a computer, mobile device or in the cloud.

- changed (2021-01-21):
[0001032975-21-000009:note_history:7]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and nine months ended December 31, 2020 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2021, or any future periods.
  (was, 2020-10-22, similarity 0.9623):
[0001032975-20-000048:note_history:7]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and six months ended September 30, 2020 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2021, or any future periods.

- changed (2021-01-21):
[0001032975-21-000009:note_history:8]
Other than the recent accounting pronouncements adopted and discussed below under Recent Accounting Pronouncements Adopted, there have been no material changes in the Company’s significant accounting policies during the nine months ended December 31, 2020 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2020.
  (was, 2020-10-22, similarity 0.8894):
[0001032975-20-000048:note_history:8]
Other than the recent accounting pronouncements adopted and discussed below under Recent Accounting Pronouncements Adopted and Summary of Significant Accounting Policies, there have been no material changes in the Company’s significant accounting policies during the six months ended September 30, 2020 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2020.

- added (2021-01-21):
[0001032975-21-000009:note_history:9]
We are subject to risks and uncertainties as a result of the novel coronavirus (COVID-19). Capital markets and economies worldwide have been negatively impacted by COVID-19 and it is still unclear how lasting and deep the economic impacts will be. During the three and nine months ended December 31, 2020, the COVID-19 pandemic had mixed effects on the Company’s results of operations, and it may continue to have mixed or adverse effects. While there was high demand for and consumption of certain of our products that led to increased sales and operating income during the three and nine months ended December 31, 2020, at the same time the Company experienced disruptions and higher costs in our manufacturing, supply chain and logistics operations and outsourced services. The ongoing and full extent of the impact of the COVID-19 pandemic on the Company's business and operational and financial performance and condition, including the sustainability of its effect on trends positive to the Company, is uncertain and will depend on many factors outside the Company's control, including but not limited to the timing, extent, duration and effects of the virus and any of its mutations, the availability of vaccines and their global deployment, the development of effective treatments, the imposition of effective public safety and other protective measures and the public's response to such measures, the impact of COVID-19 on the global economy and demand for the Company's products and services. Should the COVID-19 pandemic or global economic slowdown not improve or worsen, or if the Company's attempt to mitigate its impact on its operations and costs is not successful, the Company's business, results of operations, financial condition and prospects may be adversely affected.

- removed (2021-01-21):
[0001032975-20-000048:note_history:10]
The Company

- removed (2021-01-21):
[0001032975-20-000048:note_history:11]
We are subject to risks and uncertainties as a result of the novel coronavirus (COVID-19). The measures taken by many countries in response have contributed to a general slowdown in the global economy and adversely affected, and could in the future continue to adversely affect, the Company's business and operations. Capital markets and economies worldwide have also been negatively impacted by COVID-19 and it is still unclear how lasting and deep the economic impacts will be. During the three and six months ended September 30, 2020, as well as in the fourth quarter of fiscal year 2020, the COVID-19 pandemic had mixed effects on the Company’s results of operations, and it may continue to have mixed or adverse effects. While there was high demand and consumption of certain of our products that led to increased sales and operating income during the fourth quarter of fiscal year 2020 and the three and six months ended September 30, 2020, at the same time the Company experienced disruptions to supply chain and logistics services, inventory constraints and increased logistics costs. The ongoing and full extent of the impact of the COVID-19 pandemic on the Company's business and operational and financial performance and condition, including the sustainability of its effect on trends positive to the Company, is uncertain and will depend on many factors outside the Company's control, including but not limited to the timing, extent, duration and effects of the virus and any of its mutations, the development and availability of effective treatments and vaccines, the imposition of effective public safety and other protective measures, the impact of COVID-19 on the global economy and demand for the Company's products and services. Should the COVID-19 pandemic or global economic slowdown not improve or worsen, or if the Company's attempt to mitigate its impact on its operations and costs is not successful, the Company's business, results of operations, financial condition and prospects may be adversely affected.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-01-21):
[0001032975-21-000009:note_history:12]
The Company had several uncommitted, unsecured bank lines of credit aggregating $82.6 million as of December 31, 2020. There are no financial covenants under these lines of credit with which the Company must comply. As of December 31, 2020, the Company had outstanding bank guarantees of $37.8 million under these lines of credit. There was no borrowing outstanding under these lines of credit as of December 31, 2020 or March 31, 2020.
  (was, 2020-10-22, similarity 0.9204):
[0001032975-20-000048:note_history:12]
The Company had several uncommitted, unsecured bank lines of credit aggregating $84.2 million as of September 30, 2020. There are no financial covenants under these lines of credit with which the Company must comply. As of September 30, 2020, the Company had outstanding bank guarantees of $22.9 million under these lines of credit. There was no borrowing outstanding under these lines of credit as of September 30, 2020 or March 31, 2020.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2021-01-21):
[0001032975-20-000048:note_history:13]
Subsequent Event

- removed (2021-01-21):
[0001032975-20-000048:note_history:14]
During October 2020, Logitech issued or reserved 397,763 shares out of treasury shares to former security holders of Streamlabs related to the achievement of certain net sales milestones during the earn-out period of contingent consideration in connection with the business acquisition. The issuances of such shares were deemed to be exempt from registration under the Securities Act, in reliance on Regulation D of the Securities Act as transactions by an issuer not involving a public offering.
