# LOGI MD&A — 0001032975-21-000009


## mdna

[0001032975-21-000009:mdna:1]
[same as prior period, unchanged from 0001032975-20-000048:mdna:1]

[0001032975-21-000009:mdna:2]
[same as prior period, unchanged from 0001032975-20-000048:mdna:2]

[0001032975-21-000009:mdna:3]
[same as prior period, unchanged from 0001032975-20-000048:mdna:3]

[0001032975-21-000009:mdna:4]
Logitech is a world leader in designing, manufacturing and marketing products that help connect people to digital and cloud experiences. Almost 40 years ago, Logitech created products to improve experiences around the personal computer (PC) platform, and today it is a multi-brand, multi-category company designing products that enable better experiences when consuming, sharing and creating digital content such as computing, gaming, video and music, whether it is on a computer, mobile device or in the cloud. Logitech's brands include Logitech, Logitech G, ASTRO Gaming, Streamlabs, Ultimate Ears, Jaybird, and Blue Microphones. Our Company's website is www.logitech.com.

[0001032975-21-000009:mdna:5]
[same as prior period, unchanged from 0001032975-20-000048:mdna:5]

[0001032975-21-000009:mdna:6]
[same as prior period, unchanged from 0001032975-20-000048:mdna:6]

[0001032975-21-000009:mdna:7]
[same as prior period, unchanged from 0001032975-20-000048:mdna:7]

[0001032975-21-000009:mdna:8]
In March 2020, the World Health Organization declared the outbreak of a novel coronavirus ("COVID-19") as a pandemic, which continues to spread throughout the world. The spread of COVID-19 has caused public health officials to recommend precautions to mitigate the spread of the virus and, in certain markets in which we operate, government authorities have from time to time issued orders that require the closure of or restrictions on non-essential businesses and people to be quarantined or to shelter-at-home. The COVID-19 pandemic has significantly curtailed global economic activity, caused significant volatility and disruption in global financial and commercial markets, and is likely to continue to lead to recessionary pressures for an indeterminate amount of time. We are conducting our business with substantial modifications, such as employee remote work in non-manufacturing facilities and travel limitations, among other changes. We are continuing to actively monitor the situation and may take further actions that could alter our business operations as may be required by federal, state or local authorities in the countries in which we operate, or that we determine are in the best interest of our employees, customers, partners, suppliers or shareholders. It is not clear what the potential effects of COVID-19 or any such modifications or alterations may have on our business, results of operations, financial operations, financial condition and stock price.

[0001032975-21-000009:mdna:9]
During February 2020, following the initial outbreak of COVID-19 in China, we experienced disruptions to our manufacturing, supply chain and logistics services, resulting in temporary inventory declines and an increase in logistics costs. We continued to see disruptions to our supply chain and logistics services, inventory constraints and increased logistics costs during the remainder of the fourth quarter of fiscal year 2020 and the first, second, and third quarters of fiscal year 2021 as we attempted to address the effects of COVID-19, including health-related issues, changing regulations, and increased demand for and depleted inventories of some of our products. At the same time, due to the ongoing shelter-at-home requirements or recommendations in many countries, there has been acceleration of the work-from-home, study-from-home, gaming, video collaboration and streaming trends and high demand and consumption of certain of our products that have led to increased sales and operating income. While it is not yet clear how long the positive demand dynamics will continue, we expect the increased logistics costs and other adverse effects on our gross margins from COVID-19 to continue through the remainder of fiscal year 2021. It is difficult to predict the progression, the duration and all of the effects of COVID-19, when business restrictions and shelter-at-home guidelines may be eased or lifted, and how consumer demand, inventory and logistical effects and costs may evolve over time, or the impact on our future sales and results of operations. Some of this impact will undoubtedly occur over multiple financial periods and may have a lag effect between periods, such as what we are able to manufacture in one period affecting sales, channel inventory or logistics costs in subsequent periods. The full extent of the impact of COVID-19 on our business and our operational and financial performance is currently uncertain and will depend on many factors outside our control. For additional information, see "Liquidity and Capital resources" below and "Item IA: Risk Factors", including under the caption "The full effect of the COVID-19 pandemic is uncertain and cannot be predicted, and it could adversely affect the Company's business, results of operations and financial condition."

[0001032975-21-000009:mdna:10]
[same as prior period, unchanged from 0001032975-20-000048:mdna:10]

[0001032975-21-000009:mdna:11]
Our total sales for the three and nine months ended December 31, 2020 increased 85% and 64%, respectively, compared to the three and nine months ended December 31, 2019, due to stronger sales across all regions and several of our product categories from increased remote work and distance learning trends, accelerated adoption of video communications, and greater gaming viewership, creation, and participation from home, as a result of COVID-19. The results of operations for Streamlabs have been included in our consolidated statement of operations from the acquisition date.

[0001032975-21-000009:mdna:12]
Our sales for the three months ended December 31, 2020 increased 85%, 77%, and 95% in the Americas, EMEA and Asia Pacific, respectively, compared to the same period of the prior fiscal year. Our sales for the nine months ended December 31, 2020 increased 65%, 59%, and 68% in the Americas, EMEA and Asia Pacific, respectively, compared to the same period of the prior fiscal year.

[0001032975-21-000009:mdna:13]
Our gross margin for the three months ended December 31, 2020 increased by 780 basis points to 44.9% from 37.1% for the three months ended December 31, 2019. Our gross margin for the nine months ended December 31, 2020 increased by 640 basis points to 43.7% from 37.3% for the nine months ended December 31, 2019. Our gross margin for both periods benefited from higher sales volume, continued restrained promotional spending, favorable product mix, and favorable exchange rates, which more than offset higher logistics operations costs.

[0001032975-21-000009:mdna:14]
Operating expenses for the three months ended December 31, 2020 were $300.9 million, or 18.0% of sales, compared to $205.6 million, or 22.8% of sales in the same period of the prior fiscal year.

[0001032975-21-000009:mdna:15]
Operating expenses for the nine months ended December 31, 2020 were $771.4 million, or 20.8% of sales, compared to $601.2 million, or 26.5% of sales in the same period of the prior fiscal year.

[0001032975-21-000009:mdna:16]
Net income for the three and nine months ended December 31, 2020 was $382.5 million and $721.5 million, respectively, compared to $117.5 million and $235.8 million for the three and nine months ended December 31, 2019, respectively.

[0001032975-21-000009:mdna:17]
[same as prior period, unchanged from 0001032975-20-000048:mdna:18]

[0001032975-21-000009:mdna:18]
[same as prior period, unchanged from 0001032975-20-000048:mdna:19]

[0001032975-21-000009:mdna:19]
[same as prior period, unchanged from 0001032975-20-000048:mdna:20]

[0001032975-21-000009:mdna:20]
Creativity & Productivity:  New PC shipments have continued to be strong recently due to work-from-home and learn-from-home trends. We believe that innovative PC peripherals, such as our mice and keyboards, can renew the PC usage experience and help improve the productivity and engagement of remote work, distance learning, and telemedicine, thus providing growth opportunities. Increasing adoption of various cloud-based applications has led to multiple unique consumer use cases, which we are addressing with our innovative product portfolio and a deep understanding of our customer base. The increasing popularity of streaming and broadcasting, as well as the rising work-from-home trend, provides additional growth opportunities for our webcam products as well as other products in our portfolio. Smaller mobile computing devices, such as tablets, have created new markets and usage models for peripherals and accessories. We offer a number of products to enhance the use of mobile devices, including a combo backlit keyboard case for the iPad Pro and keyboard folios for other iPad models. Hybrid and distance learning environments have also created demand and growth opportunities for our education tablet keyboards and accessories.

[0001032975-21-000009:mdna:21]
Gaming:  The PC gaming and console gaming platforms continue to show strong structural growth opportunities as online gaming, multi-platform experiences, and esports gain greater popularity and gaming content becomes increasingly more demanding and social, particularly as other recreational activities have been curtailed or restricted during shelter-at-home mandates. The new console refresh cycle during the holiday season of 2020 could drive subsequent growth opportunities over the coming years for our ASTRO family of headsets and controllers. We believe Logitech is well positioned to benefit from the overall gaming market growth. Our acquisition of Streamlabs provides a solid platform to deliver recurring services and subscriptions to gamers.

[0001032975-21-000009:mdna:22]
Video Collaboration: The near and long-term structural growth opportunities in the video collaboration market (VC) have never been more relevant than in today’s environment, as commercial and consumer adoption of video has seen explosive growth since the start of the COVID-19 pandemic. Video meetings continue to be on the rise, and companies increasingly want lower-cost, cloud-based solutions that can provide their employees with the ability to work from anywhere. We are continuing our efforts to create and sell innovative products to accommodate the increasing demand from home offices and small-size meeting rooms, such as huddle rooms, to medium and large-sized meeting rooms. We are also experiencing significant demand for our enterprise-grade VC webcams and headsets. We will continue to invest in select business-specific products (both hardware and software), targeted product marketing and sales channel development.

[0001032975-21-000009:mdna:23]
Music:  The mobile speaker market has remained soft, and has further weakened as physical retail stores have been recently closed and the retail footprint has decreased significantly due to the COVID-19 pandemic. The integration of personal voice assistants has become increasingly competitive in the speaker categories, and the market for third-party, voice-enabled speakers has not yet gained traction. Moreover, the market for mobile speakers appears to be maturing, which led to a decline in Ultimate Ears sales in the past two years. In fiscal year 2020, the wireless headphone industry continued to flourish with strong revenue growth but has slowed in recent months. The largest growth is in true wireless headphones while traditional wireless headphones have declined significantly. Continued growth in the wireless headphone market is expected for the next several years as consumers increasingly adopt wireless headphones over wired headphones. Blue Microphones has experienced strong demand as musicians, performers and streamers increasingly look to entertain and engage with their fans on various online platforms like YouTube, Twitch, and Facebook.

[0001032975-21-000009:mdna:24]
Smart Home:  Our remote Harmony business declined substantially in fiscal year 2020, offset by growth in our Circle 2 family of security cameras. This trend continued during the nine months of fiscal year 2021. In general, our Harmony and Circle 2 products are under pressure as the way people consume content is changing and as retail stores have been closed or subject to restrictions. The smart home market opportunity is broad and we will continue to explore other innovative experiences to drive growth in the Smart Home category.

[0001032975-21-000009:mdna:25]
[same as prior period, unchanged from 0001032975-20-000048:mdna:27]

[0001032975-21-000009:mdna:26]
We have historically experienced higher sales in our third fiscal quarter ending December 31, compared to other fiscal quarters in our fiscal year, primarily due to the increased consumer demand for our products during the year-end holiday buying season and year-end spending by enterprises. Due to the spike in the number of cases from the COVID-19 pandemic, and the ongoing shelter-at-home requirements, the third fiscal quarter experienced an even higher demand and consumption of most of our products. Additionally, new product introductions and business acquisitions can significantly impact sales, product costs and operating expenses. Product introductions can also impact our sales to distribution channels as these channels are filled with new product inventory following a product introduction, and often channel inventory of an earlier model product declines as the next related major product launch approaches. Sales can also be affected when consumers and distributors anticipate a product introduction or changes in business circumstances. However, neither historical seasonal patterns nor historical patterns of product introductions should be considered reliable indicators of our future pattern of product introductions, future sales or financial performance. Furthermore, cash flow is correspondingly lower in the first half of the fiscal year as we typically build inventories in advance for the third quarter and we pay an annual dividend following our Annual General Meeting, which is typically in September.

[0001032975-21-000009:mdna:27]
[same as prior period, unchanged from 0001032975-20-000048:mdna:29]

[0001032975-21-000009:mdna:28]
As described in our Annual Report on Form 10-K for the fiscal year ended March 31, 2020, the canton of Vaud in Switzerland enacted TRAF on March 10, 2020 that took effect as of January 1, 2020. Our cash tax payments have increased in Switzerland beginning in fiscal year 2020 as a result of our transition out of our longstanding tax ruling from the canton of Vaud.

[0001032975-21-000009:mdna:29]
[same as prior period, unchanged from 0001032975-20-000048:mdna:31]

[0001032975-21-000009:mdna:30]
[same as prior period, unchanged from 0001032975-20-000048:mdna:32]

[0001032975-21-000009:mdna:31]
[same as prior period, unchanged from 0001032975-20-000048:mdna:33]

[0001032975-21-000009:mdna:32]
There have been no material changes in our critical accounting policies and estimates during the nine months ended December 31, 2020 compared with the critical accounting policies and estimates disclosed in Management's Discussion and Analysis of Financial Condition and Results of Operations included in our Annual Report on Form 10-K for the fiscal year ended March 31, 2020.

[0001032975-21-000009:mdna:33]
[same as prior period, unchanged from 0001032975-20-000048:mdna:35]

[0001032975-21-000009:mdna:34]
[same as prior period, unchanged from 0001032975-20-000048:mdna:36]

[0001032975-21-000009:mdna:35]
[same as prior period, unchanged from 0001032975-20-000048:mdna:37]

[0001032975-21-000009:mdna:36]
[same as prior period, unchanged from 0001032975-20-000048:mdna:38]

[0001032975-21-000009:mdna:37]
[same as prior period, unchanged from 0001032975-20-000048:mdna:39]

[0001032975-21-000009:mdna:38]
[same as prior period, unchanged from 0001032975-20-000048:mdna:40]

[0001032975-21-000009:mdna:39]
[same as prior period, unchanged from 0001032975-20-000048:mdna:41]

[0001032975-21-000009:mdna:40]
[same as prior period, unchanged from 0001032975-20-000048:mdna:42]

[0001032975-21-000009:mdna:41]
Although our financial results are reported in U.S. Dollars, a portion of our sales was generated in currencies other than the U.S. Dollar, such as the Euro, Chinese Renminbi, Japanese Yen, Canadian Dollar, Taiwan New Dollar, British Pound and Australian Dollar. During the three months ended December 31, 2020, approximately 54% of our sales were denominated in currencies other than the U.S. Dollar.

[0001032975-21-000009:mdna:42]
[same as prior period, unchanged from 0001032975-20-000048:mdna:44]

[0001032975-21-000009:mdna:43]
[same as prior period, unchanged from 0001032975-20-000048:mdna:45]

[0001032975-21-000009:mdna:44]
Our sales in the three and nine months ended December 31, 2020 increased 85% and 64%, respectively, compared to the same period of the prior fiscal year, driven by sales increases in all regions and several of our product categories from increased work-from-home and study-from-home trends, as a result of various shelter-at-home mandates. Strong sales growth in Video Collaboration, Gaming, PC Webcams, Tablet and Other Accessories, Keyboards & Combos, Audio & Wearables, and Pointing Devices was partially offset by a decline in sales of Mobile Speakers and Smart Home. If currency exchange rates had been constant in the three and nine months ended December 31, 2020 and 2019, our constant dollar sales growth rate would have been 80% and 63%, respectively.

[0001032975-21-000009:mdna:45]
[same as prior period, unchanged from 0001032975-20-000048:mdna:47]

[0001032975-21-000009:mdna:46]
The following table presents the change in sales by region for the three and nine months ended December 31, 2020, compared with the three and nine months ended December 31, 2019:

[0001032975-21-000009:mdna:47]
|  |  | Sales Growth Rate |  | Constant DollarSales Growth Rate |
|  |  | Three Months EndedDecember 31, 2020 |  | Nine Months EndedDecember 31, 2020 |  | Three Months EndedDecember 31, 2020 |  | Nine Months EndedDecember 31, 2020 |
| Americas |  | 85 | % |  | 65 | % |  | 87 | % |  | 67 | % |
| EMEA |  | 77 | % |  | 59 | % |  | 67 | % |  | 55 | % |
| Asia Pacific |  | 95 | % |  | 68 | % |  | 89 | % |  | 66 | % |

[0001032975-21-000009:mdna:48]
[same as prior period, unchanged from 0001032975-20-000048:mdna:50]

[0001032975-21-000009:mdna:49]
The increase in sales in our Americas region for both the three and nine month periods was primarily driven by growth in sales across a majority of our product categories, partially offset by a decline in sales of Mobile Speakers and Smart Home.

[0001032975-21-000009:mdna:50]
[same as prior period, unchanged from 0001032975-20-000048:mdna:52]

[0001032975-21-000009:mdna:51]
The increase in sales in our EMEA region for both the three and nine month periods was primarily driven by growth in sales across a majority of our product categories, partially offset by a decline in sales of Mobile Speakers and Smart Home.

[0001032975-21-000009:mdna:52]
[same as prior period, unchanged from 0001032975-20-000048:mdna:54]

[0001032975-21-000009:mdna:53]
The increase in sales in our Asia Pacific region for both the three and nine month periods was driven by growth in sales across a majority of our product categories, partially offset by a decline in sales of Mobile Speakers and Smart Home.

[0001032975-21-000009:mdna:54]
[same as prior period, unchanged from 0001032975-20-000048:mdna:56]

[0001032975-21-000009:mdna:55]
Sales by product categories for the three and nine months ended December 31, 2020 and 2019 were as follows (Dollars in thousands):

[0001032975-21-000009:mdna:56]
|  |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  |  | 2020 |  | 2019 |  | Change |  | 2020 |  | 2019 |  | Change |
| Pointing Devices |  | $ | 213,638 |  |  | $ | 154,540 |  |  | 38 | % |  | $ | 503,228 |  |  | $ | 409,293 |  |  | 23 | % |
| Keyboards & Combos |  | 218,269 |  |  | 156,333 |  |  | 40 |  |  | 565,246 |  |  | 424,061 |  |  | 33 |  |
| PC Webcams |  | 131,700 |  |  | 32,165 |  |  | 309 |  |  | 295,020 |  |  | 89,041 |  |  | 231 |  |
| Tablet & Other Accessories |  | 138,052 |  |  | 31,256 |  |  | 342 |  |  | 267,186 |  |  | 103,442 |  |  | 158 |  |
| Gaming (1) |  | 436,426 |  |  | 245,736 |  |  | 78 |  |  | 916,040 |  |  | 541,265 |  |  | 69 |  |
| Video Collaboration |  | 292,500 |  |  | 91,964 |  |  | 218 |  |  | 659,278 |  |  | 254,941 |  |  | 159 |  |
| Mobile Speakers |  | 72,566 |  |  | 92,969 |  |  | (22) |  |  | 145,156 |  |  | 200,617 |  |  | (28) |  |
| Audio & Wearables |  | 152,952 |  |  | 81,934 |  |  | 87 |  |  | 338,592 |  |  | 208,576 |  |  | 62 |  |
| Smart Home |  | 10,593 |  |  | 15,790 |  |  | (33) |  |  | 25,976 |  |  | 35,088 |  |  | (26) |  |
| Other (2) |  | 606 |  |  | — |  |  | — |  |  | 632 |  |  | 279 |  |  | 127 |  |
| Total sales |  | $ | 1,667,302 |  |  | $ | 902,687 |  |  | 85 | % |  | $ | 3,716,354 |  |  | $ | 2,266,603 |  |  | 64 | % |

[0001032975-21-000009:mdna:57]
(1) Gaming includes streaming services revenue generated by Streamlabs.

[0001032975-21-000009:mdna:58]
(2) Other includes products that we currently intend to phase out, or have already phased out, because they are no longer strategic to our business.

[0001032975-21-000009:mdna:59]
[same as prior period, unchanged from 0001032975-20-000048:mdna:61]

[0001032975-21-000009:mdna:60]
[same as prior period, unchanged from 0001032975-20-000048:mdna:62]

[0001032975-21-000009:mdna:61]
[same as prior period, unchanged from 0001032975-20-000048:mdna:63]

[0001032975-21-000009:mdna:62]
Sales of Pointing Devices increased 38% and 23% in the three and nine months ended December 31, 2020, respectively, compared to the same period of the prior fiscal year.  The increases in both periods were primarily driven by the increase in sales of cordless and trackball mice, partially offset by a decline in sales of our presentation tools, as most conferences, events, and other large-scale presentations remained prohibited.

[0001032975-21-000009:mdna:63]
[same as prior period, unchanged from 0001032975-20-000048:mdna:65]

[0001032975-21-000009:mdna:64]
[same as prior period, unchanged from 0001032975-20-000048:mdna:66]

[0001032975-21-000009:mdna:65]
Sales of Keyboards & Combos increased 40% and 33% in the three and nine months ended December 31, 2020, respectively, compared to the same periods of the prior fiscal year. The increases in both periods were driven by an increase in sales of our cordless keyboards and wireless keyboards/mice combos, partially offset by a decline in sales of our living room keyboards. The increase in the nine-month period was further partially offset by a decline in sales of our corded keyboards/mice combos.

[0001032975-21-000009:mdna:66]
[same as prior period, unchanged from 0001032975-20-000048:mdna:68]

[0001032975-21-000009:mdna:67]
[same as prior period, unchanged from 0001032975-20-000048:mdna:69]

[0001032975-21-000009:mdna:68]
PC Webcams sales increased 309% and 231% in the three and nine months ended December 31, 2020, respectively, compared to the same periods of the prior fiscal year. The increases for both periods were across all product sub-categories, primarily driven by an increase in sales of our HD Pro Webcam C920, 1080P PRO Stream Webcam, Webcam C60, and Logitech Streamcam, mostly due to more remote work adoption and learning-from-home.

[0001032975-21-000009:mdna:69]
[same as prior period, unchanged from 0001032975-20-000048:mdna:71]

[0001032975-21-000009:mdna:70]
[same as prior period, unchanged from 0001032975-20-000048:mdna:72]

[0001032975-21-000009:mdna:71]
Sales of Tablet & Other Accessories products increased 342% and 158% in the three and nine months ended December 31, 2020, respectively, compared to the same periods of the prior fiscal year. The increase for both periods was primarily driven by an increase in the sales of our Rugged Folio keyboard cases for a newer generation of iPads and Slim Folio keyboard for iPad 7th generation, both introduced in the third quarter of fiscal year 2020, and our Powered Wireless Charging 3-in-1 Dock, introduced in the fourth quarter of fiscal year 2020. We have seen strong demand for Tablet keyboards, partly due to schools embracing various technology devices to better educate students in learning-from-home environments.

[0001032975-21-000009:mdna:72]
[same as prior period, unchanged from 0001032975-20-000048:mdna:74]

[0001032975-21-000009:mdna:73]
Our Gaming category comprises gaming mice, keyboards, headsets, gamepads, steering wheels, simulation controllers, console gaming headsets, and Streamlabs services.

[0001032975-21-000009:mdna:74]
Gaming sales increased 78% and 69% for the three and nine months ended December 31, 2020, respectively, compared to the same periods of the prior fiscal year. The increase for both periods was primarily driven by increases in the sales of nearly all our product sub-categories, including Streamlabs services, our business acquisition in the third quarter of fiscal year 2020.  The increases for both periods was partially offset by a decline in the sales of our console gaming controllers.

[0001032975-21-000009:mdna:75]
[same as prior period, unchanged from 0001032975-20-000048:mdna:77]

[0001032975-21-000009:mdna:76]
[same as prior period, unchanged from 0001032975-20-000048:mdna:78]

[0001032975-21-000009:mdna:77]
Sales of Video Collaboration products increased 218% and 159% in the three and nine months ended December 31, 2020, respectively, compared to the same periods of the prior fiscal year. The increases for both periods were primarily driven by the sales of our Rally Ultra-HD conference camera system, BRIO 4K Pro Webcam, Webcam C390e, and Webcam C925E as video communications become more critical for a more location-flexible workforce.

[0001032975-21-000009:mdna:78]
[same as prior period, unchanged from 0001032975-20-000048:mdna:80]

[0001032975-21-000009:mdna:79]
[same as prior period, unchanged from 0001032975-20-000048:mdna:81]

[0001032975-21-000009:mdna:80]
[same as prior period, unchanged from 0001032975-20-000048:mdna:82]

[0001032975-21-000009:mdna:81]
Sales of Mobile Speakers decreased 22% and 28% for the three and nine months ended December 31, 2020, compared to the same periods of the prior fiscal year. The decreases for both periods were primarily driven by a decrease in the sales of our BOOM 3, BOOM 2, UE MEGABOOM, and UE WONDERBOOM mobile speakers, in part due to limited outdoor activities and social gatherings. The decreases were partially offset by sales of our WONDERBOOM 2 speakers, and the introduction of our HYPERBOOM speaker in the fourth quarter of fiscal year 2020.

[0001032975-21-000009:mdna:82]
[same as prior period, unchanged from 0001032975-20-000048:mdna:84]

[0001032975-21-000009:mdna:83]
[same as prior period, unchanged from 0001032975-20-000048:mdna:85]

[0001032975-21-000009:mdna:84]
Audio & Wearables sales increased 87% and 62% for the three and nine months ended December 31, 2020, respectively, compared to the same periods of the prior fiscal year. The increases for both periods were primarily driven by increases in the sales of both our corded and cordless headsets and Blue Microphones products, partially offset by a decline in the sales of our Jaybird products.

[0001032975-21-000009:mdna:85]
[same as prior period, unchanged from 0001032975-20-000048:mdna:87]

[0001032975-21-000009:mdna:86]
[same as prior period, unchanged from 0001032975-20-000048:mdna:88]

[0001032975-21-000009:mdna:87]
Smart Home sales decreased 33% and 26% during the three and nine months ended December 31, 2020, respectively, compared to the same periods of the prior fiscal year. The decrease for both periods was primarily due to an overall decline in sales of our Harmony remotes and our home video products.

[0001032975-21-000009:mdna:88]
[same as prior period, unchanged from 0001032975-20-000048:mdna:90]

[0001032975-21-000009:mdna:89]
Gross profit for the three and nine months ended December 31, 2020 and 2019 was as follows (Dollars in thousands):

[0001032975-21-000009:mdna:90]
|  |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  |  | 2020 |  | 2019 |  | Change |  | 2020 |  | 2019 |  | Change |
| Net sales |  | $ | 1,667,302 |  |  | $ | 902,687 |  |  | 85 | % |  | $ | 3,716,354 |  |  | $ | 2,266,603 |  |  | 64 | % |
| Gross profit |  | $ | 749,010 |  |  | $ | 334,453 |  |  | 124 |  |  | $ | 1,624,466 |  |  | $ | 845,505 |  |  | 92 |  |
| Gross margin |  | 44.9 | % |  | 37.1 | % |  |  |  | 43.7 | % |  | 37.3 | % |  |  |

[0001032975-21-000009:mdna:91]
Gross profit consists of sales less cost of goods sold (which includes materials, direct labor and related overhead costs, costs of manufacturing facilities, royalties, costs of purchasing components from outside suppliers,

[0001032975-21-000009:mdna:92]
distribution costs, warranty costs, customer support, shipping and handling costs, outside processing costs and write-down of inventories), amortization of intangible assets.

[0001032975-21-000009:mdna:93]
Gross margin increased by 780 and 640 basis points for the three and nine months ended December 31, 2020, respectively, compared to the same periods of the prior fiscal year. Gross margin benefited from higher sales volume, continued restrained promotional spending, favorable product mix, and favorable exchange rates, which more than offset the higher logistics operations costs.

[0001032975-21-000009:mdna:94]
[same as prior period, unchanged from 0001032975-20-000048:mdna:95]

[0001032975-21-000009:mdna:95]
Operating expenses for the three and nine months ended December 31, 2020 and 2019 were as follows (Dollars in thousands):

[0001032975-21-000009:mdna:96]
|  |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |  |  |  |
| Marketing and selling |  | $ | 204,485 |  |  | $ | 134,950 |  |  | $ | 496,520 |  |  | $ | 392,138 |  |  |  |  |
| % of sales |  | 12.3 | % |  | 14.9 | % |  | 13.4 | % |  | 17.3 | % |  |  |  |
| Research and development |  | 53,910 |  |  | 43,292 |  |  | 157,014 |  |  | 127,499 |  |  |  |  |
| % of sales |  | 3.2 | % |  | 4.8 | % |  | 4.2 | % |  | 5.6 | % |  |  |  |
| General and administrative |  | 37,606 |  |  | 22,344 |  |  | 98,341 |  |  | 68,551 |  |  |  |  |
| % of sales |  | 2.3 | % |  | 2.5 | % |  | 2.6 | % |  | 3.0 | % |  |  |  |
| Amortization of intangible assets and acquisition-related costs |  | 4,946 |  |  | 5,084 |  |  | 13,886 |  |  | 12,898 |  |  |  |  |
| % of sales |  | 0.3 | % |  | 0.6 | % |  | 0.4 | % |  | 0.6 | % |  |  |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | — |  |  | 5,716 |  |  | — |  |  |  |  |
| % of sales |  | — | % |  | — | % |  | 0.2 | % |  | — | % |  |  |  |
| Restructuring charges (credits), net |  | — |  |  | (45) |  |  | (54) |  |  | 69 |  |  |  |  |
| % of sales |  | — | % | (1) | — | % |  | — | % | (1) | — | % |  |  |  |
| Total operating expenses |  | $ | 300,947 |  |  | $ | 205,625 |  |  | $ | 771,423 |  |  | $ | 601,155 |  |  |  |  |
| % of sales |  | 18.0 | % |  | 22.8 | % |  | 20.8 | % |  | 26.5 | % |  |  |  |

[0001032975-21-000009:mdna:97]
[same as prior period, unchanged from 0001032975-20-000048:mdna:98]

[0001032975-21-000009:mdna:98]
[same as prior period, unchanged from 0001032975-20-000048:mdna:99]

[0001032975-21-000009:mdna:99]
[same as prior period, unchanged from 0001032975-20-000048:mdna:100]

[0001032975-21-000009:mdna:100]
During the three and nine months ended December 31, 2020, marketing and selling expenses increased $69.5 million, and $104.4 million, respectively, compared to the same periods of the prior fiscal year.  The increases were primarily driven by higher advertising expenses, personnel-related costs due to increased headcount, increased performance-based variable compensation linked to stronger performance, and increased shared-based compensation.

[0001032975-21-000009:mdna:101]
[same as prior period, unchanged from 0001032975-20-000048:mdna:102]

[0001032975-21-000009:mdna:102]
[same as prior period, unchanged from 0001032975-20-000048:mdna:103]

[0001032975-21-000009:mdna:103]
During the three and nine months ended December 31, 2020, research and development expenses increased $10.6 million and $29.5 million, respectively, compared to the same periods of the prior fiscal year. The increases were primarily driven by higher personnel-related costs due to increased headcount, increased performance-based variable expense linked to stronger performance, and higher investment in new product development.

[0001032975-21-000009:mdna:104]
[same as prior period, unchanged from 0001032975-20-000048:mdna:105]

[0001032975-21-000009:mdna:105]
[same as prior period, unchanged from 0001032975-20-000048:mdna:106]

[0001032975-21-000009:mdna:106]
During the three and nine months ended December 31, 2020, general and administrative expenses increased $15.3 million and $29.8 million, respectively, compared to the same periods of the prior fiscal year. The increases were primarily driven by higher personnel-related costs due to increased headcount, increased performance-based variable compensation linked to stronger performance, and increased shared-based compensation.

[0001032975-21-000009:mdna:107]
[same as prior period, unchanged from 0001032975-20-000048:mdna:108]

[0001032975-21-000009:mdna:108]
[same as prior period, unchanged from 0001032975-20-000048:mdna:109]

[0001032975-21-000009:mdna:109]
During the three months ended December 31, 2020, amortization of intangible assets and acquisition-related costs decreased $0.1 million compared to the same period of the prior fiscal year, primarily driven by intangibles assets that were fully amortized.  For the nine months ended December 31, 2020, amortization of intangible assets and acquisition-related costs increased $1.0 million, compared to the same period of the prior fiscal year, primarily driven by amortization of the intangible assets acquired through the Streamlabs acquisition in the third quarter of fiscal year 2020.

[0001032975-21-000009:mdna:110]
[same as prior period, unchanged from 0001032975-20-000048:mdna:111]

[0001032975-21-000009:mdna:111]
The change in fair value of contingent consideration was $5.7 million for the nine months ended December 31, 2020, primarily due to growth in Streamlabs' net sales and the achievement of the net sales targets during the six-month earn-out period ended June 30, 2020.

[0001032975-21-000009:mdna:112]
Other Income, Net

[0001032975-21-000009:mdna:113]
Other income, net for the three and nine months ended December 31, 2020 and 2019 was as follows (Dollars in thousands):

[0001032975-21-000009:mdna:114]
|  |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Investment income related to a deferred compensation plan |  | $ | 1,049 |  |  | $ | 1,045 |  |  | $ | 4,384 |  |  | $ | 1,836 |  |
| Currency exchange gain, net |  | 7,344 |  |  | 203 |  |  | 9,070 |  |  | 702 |  |
| Loss on investments |  | (2,173) |  |  | (709) |  |  | (4,692) |  |  | (772) |  |
| Other |  | 263 |  |  | 562 |  |  | 899 |  |  | 1,086 |  |
| Total |  | $ | 6,483 |  |  | $ | 1,101 |  |  | $ | 9,661 |  |  | $ | 2,852 |  |

[0001032975-21-000009:mdna:115]
[same as prior period, unchanged from 0001032975-20-000048:mdna:116]

[0001032975-21-000009:mdna:116]
Currency exchange gain, net relates to balances denominated in currencies other than the functional currency in our subsidiaries, as well as to the sale of currencies, and to gains or losses recognized on currency exchange forward contracts. We do not speculate in currency positions, but we are alert to opportunities to maximize currency exchange gains and minimize currency exchange losses.

[0001032975-21-000009:mdna:117]
[same as prior period, unchanged from 0001032975-20-000048:mdna:118]

[0001032975-21-000009:mdna:118]
33

[0001032975-21-000009:mdna:119]
Provision for Income Taxes

[0001032975-21-000009:mdna:120]
The provision for income taxes and effective tax rates for the three and nine months ended December 31, 2020 and 2019 were as follows (Dollars in thousands):

[0001032975-21-000009:mdna:121]
|  |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Provision for income taxes |  | $ | 72,334 |  |  | $ | 14,467 |  |  | $ | 142,638 |  |  | $ | 18,405 |  |
| Effective income tax rate |  | 15.9 | % |  | 11.0 | % |  | 16.5 | % |  | 7.2 | % |

[0001032975-21-000009:mdna:122]
The change in the effective income tax rate for the three and nine months ended December 31, 2020, compared to the same periods ended December 31, 2019 was primarily due to the mix of income and losses in the various tax jurisdictions in which we operate.  The Swiss income tax provision in the three and nine months ended December 31, 2020 represents the income tax provision at the full statutory income tax rate of 13.63%.  In the same periods ended December 31, 2019 when TRAF was yet to be enacted at the federal and cantonal levels, the transition income tax provision reflects the application of the longstanding tax ruling through December 31, 2019.  Furthermore, there was a discrete tax benefit of $1.7 million from adjusting deferred tax assets and liabilities in Switzerland in the nine months ended December 31, 2019.  There were discrete tax benefits of $7.2 million and $2.9 million from the recognition of excess tax benefits in the United States and reversal of uncertain tax positions from the expiration of statutes of limitations, respectively, in the nine-month period ended December 31, 2020, compared with $6.0 million and $2.7 million, respectively, in the nine-month period ended December 31, 2019.

[0001032975-21-000009:mdna:123]
As of December 31, 2020 and March 31, 2020, the total amount of unrecognized tax benefits due to uncertain tax positions was $158.8 million and $140.8 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-21-000009:mdna:124]
[same as prior period, unchanged from 0001032975-20-000048:mdna:125]

[0001032975-21-000009:mdna:125]
[same as prior period, unchanged from 0001032975-20-000048:mdna:126]

[0001032975-21-000009:mdna:126]
As of December 31, 2020, we had cash and cash equivalents of $1,388.7 million, compared to $715.6 million as of March 31, 2020. As of December 31, 2020, 71% of the cash and cash equivalents were held in Switzerland, 13% were held in Germany, and 9% were held in Hong Kong and China. We do not expect to incur any material adverse tax impact except for what has already been recognized, or be significantly inhibited by any country in which we do business from the repatriation of funds to Switzerland, our home domicile.

[0001032975-21-000009:mdna:127]
The increase in cash and cash equivalents for the nine months ended December 31, 2020, was primarily due to an increase in net cash provided by operating activities and proceeds from exercises of stock options and purchase rights, partially offset by payment of cash dividends, purchases of property, plant and equipment, tax withholdings related to settlements of restricted stock units, and shares repurchased under our share buyback program.

[0001032975-21-000009:mdna:128]
As of December 31, 2020, our working capital was $1,361.9 million, compared to $700.3 million as of March 31, 2020. The increase was primarily driven by higher cash and cash equivalents, higher accounts receivable, net, higher inventories and higher other current assets, partially offset by higher accounts payable and accrued and other current liabilities. Our working capital increased by $681.5 million compared to $680.4 million as of December 31, 2019, which was primarily driven by higher cash and cash equivalents, higher accounts receivable, net, higher inventories  and higher other current assets, partially offset by higher accounts payable and accrued and other current liabilities.

[0001032975-21-000009:mdna:129]
We had several uncommitted, unsecured bank lines of credit aggregating $82.6 million as of December 31, 2020. There are no financial covenants under these lines of credit with which we must comply. As of December 31, 2020, we had outstanding bank guarantees of $37.8 million under these lines of credit.

[0001032975-21-000009:mdna:130]
[same as prior period, unchanged from 0001032975-20-000048:mdna:132]

[0001032975-21-000009:mdna:131]
|  |  | Nine Months EndedDecember 31, |
|  |  | 2020 |  | 2019 |
| Net cash provided by operating activities |  | $ | 928,419 |  |  | $ | 324,154 |  |
| Net cash used in investing activities |  | (46,454) |  |  | (119,441) |  |
| Net cash used in financing activities |  | (219,196) |  |  | (150,863) |  |
| Effect of exchange rate changes on cash and cash equivalents |  | 10,408 |  |  | (2,320) |  |
| Net increase in cash and cash equivalents |  | $ | 673,177 |  |  | $ | 51,530 |  |

[0001032975-21-000009:mdna:132]
The following table presents selected financial information and statistics as of and for the three months ended December 31, 2020 and 2019 (Dollars in thousands):

[0001032975-21-000009:mdna:133]
|  |  | As of December 31, |  |
|  |  | 2020 |  | 2019 |  |
| Accounts receivable, net |  | $ | 894,937 |  |  | $ | 531,309 |  |  |
| Accounts payable |  | $ | 811,786 |  |  | $ | 439,035 |  |  |
| Inventories |  | $ | 476,802 |  |  | $ | 307,494 |  |  |

[0001032975-21-000009:mdna:134]
|  |  | Three Months EndedDecember 31, |  |
|  |  | 2020 |  | 2019 |  |
| Days sales in accounts receivable (“DSO”) (Days) (1) |  | 48 |  |  | 53 |  |  |
| Days accounts payable outstanding (“DPO”) (Days) (2) |  | 80 |  |  | 70 |  |  |
| Inventory turnover (“ITO”) (x)(3) |  | 7.7 |  |  | 7.4 |  |  |

[0001032975-21-000009:mdna:135]
[same as prior period, unchanged from 0001032975-20-000048:mdna:137]

[0001032975-21-000009:mdna:136]
[same as prior period, unchanged from 0001032975-20-000048:mdna:138]

[0001032975-21-000009:mdna:137]
[same as prior period, unchanged from 0001032975-20-000048:mdna:139]

[0001032975-21-000009:mdna:138]
DSO for the three months ended December 31, 2020 decreased by 5 days to 48 days, compared to 53 days for the same period of the prior fiscal year, primarily due to timing of sales, customer payments and sales linearity.

[0001032975-21-000009:mdna:139]
DPO for the three months ended December 31, 2020 increased by 10 days, compared to 70 days for the same period of the prior fiscal year, primarily due to the timing of purchases and related payments and an increase in cost of goods sold due to higher sales growth.

[0001032975-21-000009:mdna:140]
ITO for the three months ended December 31, 2020 increased by 0.3, compared to 7.4 for the same period of the prior fiscal year, primarily due to higher sales growth as a result of higher demand for certain of our products

[0001032975-21-000009:mdna:141]
[same as prior period, unchanged from 0001032975-20-000048:mdna:143]

[0001032975-21-000009:mdna:142]
[same as prior period, unchanged from 0001032975-20-000048:mdna:144]

[0001032975-21-000009:mdna:143]
During the nine months ended December 31, 2020, we generated $928.4 million of cash from operating activities. Our main sources of operating cash flows were from net income, after adding back non-cash expenses of depreciation, amortization and share-based compensation expense, from change in fair value of contingent considerations, and from changes in operating assets and liabilities. The increase in accounts receivable, net was primarily driven by growth and timing of sales. The increase in inventories was primarily driven by an increase in inventory purchases in anticipation of continued high demand for certain of our products during the nine months

[0001032975-21-000009:mdna:144]
ended December 31, 2020. The increase in accounts payable was primarily driven by the timing of purchases and related payments. The increase in accrued liabilities was primarily driven by an increase in customer marketing, pricing, and incentive programs, freight and duty due to higher logistic costs, and income taxes payable due to stronger performance.

[0001032975-21-000009:mdna:145]
Net cash used in investing activities was $46.5 million, primarily due to $46.2 million of purchases of property, plant and equipment.

[0001032975-21-000009:mdna:146]
Net cash used in financing activities was $219.2 million, primarily due to the $146.7 million payment of a cash dividend, $72.7 million used for repurchases of our registered shares, and $29.5 million for tax withholdings related to net share settlements of restricted stock units, partially offset by $29.7 million in proceeds received from exercises of stock options and purchase rights.

[0001032975-21-000009:mdna:147]
During the nine months ended December 31, 2020, there was a $10.4 million gain from currency exchange rate effect on cash and cash equivalents, compared to a loss of $2.3 million during the same period of the prior fiscal year. The gain from currency translation exchange effect during the nine months ended December 31, 2020 was primarily due to the strengthening of the Australian Dollar, Euro, Chinese Renmingbi, and Swiss Franc against the U.S. Dollar by 24%, 11%, and 8%, respectively, during the period. The loss from effect of currency exchange rate changes during the nine months ended December 31, 2019 was primarily due to the weakening of the Euro, Chinese Renminbi and Brazilian Real against the U.S. Dollar by 1%, 4%, and 4%, respectively.

[0001032975-21-000009:mdna:148]
[same as prior period, unchanged from 0001032975-20-000048:mdna:149]

[0001032975-21-000009:mdna:149]
[same as prior period, unchanged from 0001032975-20-000048:mdna:150]

[0001032975-21-000009:mdna:150]
[same as prior period, unchanged from 0001032975-20-000048:mdna:151]

[0001032975-21-000009:mdna:151]
In May 2020, our Board of Directors approved a new share buyback program, which authorizes us to invest up to $250.0 million to purchase our own shares, following the expiration date of the 2017 share buyback program. Although we enter into trading plans for systematic repurchases (e.g., 10b5-1 trading plans) from time to time, our share buyback program provides us with the opportunity to make opportunistic repurchases during periods of favorable market conditions and is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Opportunistic purchases may be started or stopped at any time without prior notice depending on market conditions and other factors. As of December 31, 2020, $177.6 million is still available for repurchase under the 2020 share buyback program.

[0001032975-21-000009:mdna:152]
[same as prior period, unchanged from 0001032975-20-000048:mdna:153]

[0001032975-21-000009:mdna:153]
[same as prior period, unchanged from 0001032975-20-000048:mdna:154]

[0001032975-21-000009:mdna:154]
[same as prior period, unchanged from 0001032975-20-000048:mdna:155]

[0001032975-21-000009:mdna:155]
[same as prior period, unchanged from 0001032975-20-000048:mdna:156]

[0001032975-21-000009:mdna:156]
As of December 31, 2020, we had non-cancelable purchase commitments of $853.1 million for inventory purchases made in the normal course of business from original design manufacturers, contract manufacturers and

[0001032975-21-000009:mdna:157]
other suppliers, as well as due to strong sales growth in the nine months ended December 31, 2020, the majority of which are expected to be fulfilled within the next 12 months. The increase of inventory purchase commitment from March 31, 2020 is to replenish the inventory due to business growth. We recorded a liability for firm, non-cancelable, and unhedged inventory purchase commitments in excess of anticipated demand or net realizable value consistent with our valuation of excess and obsolete inventory. As of December 31, 2020, the liability for these purchase commitments was $5.6 million and is recorded in accrued and other current liabilities.

[0001032975-21-000009:mdna:158]
We have firm purchase commitments of $32.8 million for capital expenditures, primarily related to commitments for equipment and tooling for new and existing products. We expect to continue making capital expenditures in the future to support product development activities and ongoing and expanded operations. Although open purchase commitments are considered enforceable and legally binding, the terms generally allow us to reschedule or adjust our requirements based on business needs prior to delivery of goods or performance of services.

[0001032975-21-000009:mdna:159]
[same as prior period, unchanged from 0001032975-20-000048:mdna:159]

[0001032975-21-000009:mdna:160]
[same as prior period, unchanged from 0001032975-20-000048:mdna:160]

[0001032975-21-000009:mdna:161]
[same as prior period, unchanged from 0001032975-20-000048:mdna:161]

[0001032975-21-000009:mdna:162]
[same as prior period, unchanged from 0001032975-20-000048:mdna:162]

[0001032975-21-000009:mdna:163]
[same as prior period, unchanged from 0001032975-20-000048:mdna:163]

[0001032975-21-000009:mdna:164]
We indemnify certain suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of December 31, 2020, no amounts have been accrued for indemnification provisions. We do not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under our indemnification arrangements.

[0001032975-21-000009:mdna:165]
[same as prior period, unchanged from 0001032975-20-000048:mdna:165]

[0001032975-21-000009:mdna:166]
Legal Proceedings

[0001032975-21-000009:mdna:167]
From time to time we are involved in claims and legal proceedings that arise in the ordinary course of our business. We are currently subject to several such claims and a small number of legal proceedings. We believe that these matters lack merit and we intend to vigorously defend against them. Based on currently available information, we do not believe that resolution of pending matters will have a material adverse effect on our financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that our defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on our business, financial condition, cash flows and results of operations in a particular period. Any claims or proceedings against us, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain necessary licenses or other rights, or litigation arising out of intellectual property claims, could adversely affect our business.
