# LOGI 8-K — 0001032975-21-000004 filed 2021-01-19

## item codes, every 8-K on or before 2021-01-21

- 2021-01-19 0001032975-21-000004 — 2.02, 9.01
- 2020-10-20 0001032975-20-000045 — 2.02, 9.01
- 2020-09-11 0001032975-20-000042 — 5.07, 8.01
- 2020-07-21 0001032975-20-000029 — 2.02, 9.01
- 2020-07-01 0001032975-20-000023 — 5.02, 8.01
- 2020-05-12 0001032975-20-000011 — 2.02, 9.01
- 2020-03-30 0001032975-20-000009 — 5.02
- 2020-01-21 0001032975-20-000002 — 2.02, 9.01
- 2019-10-22 0001032975-19-000071 — 9.01
- 2019-09-26 0001032975-19-000068 — 1.01, 7.01, 9.01
- 2019-09-06 0001032975-19-000063 — 5.07, 8.01
- 2019-07-23 0001032975-19-000046 — 2.02, 9.01
- 2019-07-23 0001032975-19-000045 — 5.02, 9.01
- 2019-07-02 0001032975-19-000036 — 5.02
- 2019-06-25 0001032975-19-000034 — 5.02
- 2019-05-03 0001032975-19-000021 — 5.02 — amendment, the index does not say of what
- 2019-04-30 0001032975-19-000017 — 2.02, 5.02, 9.01
- 2019-03-28 0001032975-19-000013 — 5.02
- 2019-01-22 0001032975-19-000004 — 2.02, 9.01
- 2018-10-23 0001032975-18-000044 — 2.02, 9.01
- 2018-09-07 0001032975-18-000040 — 5.07, 8.01
- 2018-07-31 0001032975-18-000035 — 1.01, 2.02, 2.05, 7.01, 9.01
- 2018-06-27 0001032975-18-000020 — 5.02
- 2018-05-03 0001032975-18-000013 — 2.02, 5.02, 9.01
- 2018-01-23 0001032975-18-000005 — 2.02, 9.01
- 2017-10-24 0001032975-17-000043 — 2.02, 9.01
- 2017-09-18 0001032975-17-000040 — 5.07, 8.01
- 2017-07-25 0001032975-17-000028 — 2.02, 9.01
- 2017-07-12 0001032975-17-000022 — 1.01
- 2017-04-26 0001032975-17-000012 — 2.02, 9.01
- 2017-01-25 0001032975-17-000002 — 2.02, 9.01
- 2016-10-26 0001032975-16-000103 — 2.02, 9.01
- 2016-09-13 0001032975-16-000101 — 5.07, 8.01
- 2016-07-28 0001032975-16-000092 — 2.02, 9.01
- 2016-06-30 0001032975-16-000087 — 5.02
- 2016-04-28 0001032975-16-000077 — 2.02, 9.01
- 2016-04-14 0001032975-16-000073 — 1.01, 7.01, 9.01
- 2016-01-21 0001032975-16-000064 — 2.02, 9.01
- 2016-01-04 0001032975-16-000061 — 1.01, 2.01, 9.01
- 2015-12-23 0001032975-15-000059 — 5.02
- 2015-10-22 0001032975-15-000047 — 2.02, 9.01
- 2015-09-11 0001032975-15-000044 — 5.07, 8.01
- 2015-07-24 0001032975-15-000034 — 2.05 — amendment of 0001032975-15-000030
- 2015-07-23 0001032975-15-000030 — 2.02, 9.01
- 2015-06-25 0001032975-15-000025 — 5.02
- 2015-05-14 0001032975-15-000011 — 8.01, 9.01
- 2015-04-23 0001032975-15-000008 — 2.02, 2.05
- 2015-01-22 0001628280-15-000191 — 2.02, 8.01
- 2014-12-23 0001193125-14-450908 — 5.02, 5.07, 8.01
- 2014-11-25 0001193125-14-425233 — 3.01
- 2014-11-13 0001193125-14-411303 — 4.01, 9.01
- 2014-10-23 0001104659-14-073164 — 2.02, 9.01
- 2014-09-04 0001193125-14-331214 — 4.02, 9.01
- 2014-08-18 0001193125-14-313346 — 3.01, 9.01
- 2014-07-24 0001104659-14-053065 — 2.02, 9.01
- 2014-06-05 0001193125-14-226177 — 3.01, 9.01
- 2014-05-22 0001193125-14-208777 — 8.01, 9.01
- 2014-04-24 0001104659-14-029650 — 2.02, 9.01
- 2014-01-23 0001104659-14-003619 — 2.02, 9.01
- 2013-10-24 0001104659-13-077404 — 2.02, 9.01
- 2013-09-09 0001193125-13-361441 — 5.02, 5.07, 8.01, 9.01
- 2013-09-06 0001193125-13-359930 — 5.02, 9.01
- 2013-08-02 0001193125-13-317343 — 5.02
- 2013-07-25 0001104659-13-056372 — 2.02, 9.01
- 2013-06-28 0001193125-13-277394 — 5.02, 9.01
- 2013-06-20 0001193125-13-265914 — 8.01, 9.01
- 2013-04-25 0001104659-13-032570 — 2.02, 9.01
- 2013-04-17 0001193125-13-158923 — 5.02, 9.01
- 2013-03-01 0001193125-13-085804 — 2.05
- 2013-01-24 0001104659-13-004214 — 2.02, 9.01
- 2013-01-02 0001193125-13-000058 — 5.02
- 2012-10-25 0001104659-12-070966 — 2.02, 9.01
- 2012-09-11 0001193125-12-388070 — 5.02, 5.07, 8.01, 9.01
- 2012-08-22 0001193125-12-364167 — 5.02, 8.01, 9.01
- 2012-07-26 0001104659-12-051084 — 2.02, 9.01
- 2012-06-08 0001193125-12-264132 — 2.05, 9.01 — amendment, the index does not say of what
- 2012-04-26 0001193125-12-183657 — 5.02, 9.01
- 2012-04-26 0001104659-12-028470 — 2.02, 2.05, 9.01
- 2012-03-15 0001193125-12-115954 — 5.02, 9.01
- 2012-01-26 0001104659-12-004014 — 2.02, 9.01
- 2012-01-04 0001193125-12-002212 — 1.01, 2.03, 9.01
- 2011-10-27 0001104659-11-058150 — 2.02, 9.01
- 2011-09-12 0001193125-11-245931 — 5.07
- 2011-07-28 0001193125-11-200929 — 5.02, 9.01
- 2011-07-28 0001193125-11-199704 — 2.02, 9.01
- 2011-04-28 0001193125-11-112669 — 2.02, 9.01
- 2011-03-24 0001193125-11-076483 — 5.02, 9.01
- 2011-01-27 0001032975-11-000003 — 9.01
- 2010-10-28 0001032975-10-000032 — 9.01
- 2010-09-13 0001032975-10-000022 — 5.07
- 2010-07-29 0001032975-10-000010 — 2.02, 9.01
- 2010-06-10 0001193125-10-136877 — 5.02, 9.01
- 2010-05-03 0001193125-10-104337 — 5.02
- 2010-04-29 0001032975-10-000008 — 2.02, 9.01
- 2010-02-19 0001032975-10-000006 — 9.01 — amendment of 0001193125-09-252416
- 2010-01-21 0001032975-10-000002 — 2.02, 9.01
- 2009-12-14 0001193125-09-252416 — 2.01, 9.01
- 2009-11-17 0001032975-09-000023 — 1.01
- 2009-10-22 0001032975-09-000018 — 9.01
- 2009-09-22 0001193125-09-195545 — 5.02, 9.01
- 2009-09-03 0001032975-09-000013 — 8.01
- 2009-07-23 0001140361-09-016802 — 2.02, 9.01
- 2009-06-01 0001193125-09-122550 — 5.02
- 2009-04-23 0001193125-09-085054 — 2.02, 9.01
- 2009-04-02 0001193125-09-071272 — 5.02, 9.01
- 2009-01-20 0001193125-09-008454 — 2.05 — amendment of 0001193125-09-002609
- 2009-01-20 0001193125-09-007902 — 2.02, 9.01
- 2009-01-07 0001193125-09-002609 — 2.05, 9.01
- 2009-01-07 0001193125-09-002370 — 5.02, 9.01
- 2008-12-09 0001193125-08-250543 — 5.02, 9.01
- 2008-10-21 0001193125-08-213212 — 2.02, 9.01
- 2008-07-22 0001193125-08-154721 — 2.02, 9.01
- 2008-06-24 0001193125-08-139163 — 5.03, 9.01
- 2008-05-13 0001193125-08-113263 — 5.02, 9.01
- 2008-04-22 0001193125-08-086176 — 2.02, 9.01

## late-filing notifications on or before 2021-01-21

- 2015-06-02 0001032975-15-000020 — NT 10-K, for the period ended 2015-03-31
- 2014-11-06 0001193125-14-401306 — NT 10-Q, for the period ended 2014-09-30
- 2014-07-24 0001193125-14-277575 — NT 10-Q, for the period ended 2014-06-30
- 2014-05-22 0001193125-14-208712 — NT 10-K, for the period ended 2014-03-31
- 2009-08-06 0001032975-09-000006 — NT 10-Q, for the period ended 2009-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001032975-21-000004:8k_2_02:1]
EX-99.1
2
exhibit991q3fy21ng.htm
EX-99.1

[0001032975-21-000004:8k_2_02:2]
Document

[0001032975-21-000004:8k_2_02:3]
Exhibit 99.1

[0001032975-21-000004:8k_2_02:4]
Editorial Contacts:

[0001032975-21-000004:8k_2_02:5]
Ben Lu, CFA, Vice President, Investor Relations - USA (510) 713-5568

[0001032975-21-000004:8k_2_02:6]
Nicole Kenyon, Head of Global Corporate & Employee Communications - USA (510) 988-8553

[0001032975-21-000004:8k_2_02:7]
Ben Starkie, Corporate Communications - Europe +41 (0) 79-292-3499

[0001032975-21-000004:8k_2_02:8]
Logitech’s Q3 Sales Grow 85%, Operating Income Triples

[0001032975-21-000004:8k_2_02:9]
Company Raises Annual Outlook On Strong Momentum

[0001032975-21-000004:8k_2_02:10]
LAUSANNE, Switzerland, Jan. 19, 2021 and NEWARK, Calif., Jan. 18, 2021 — Logitech International (SIX: LOGN) (Nasdaq: LOGI) today announced financial results for the third quarter of Fiscal Year 2021.

[0001032975-21-000004:8k_2_02:11]
•Q3 sales were $1.67 billion, up 85 percent in US dollars and 80 percent in constant currency, compared to Q3 of the prior year.

[0001032975-21-000004:8k_2_02:12]
•Q3 GAAP operating income grew 248 percent to $448 million, compared to $129 million in the same quarter a year ago. Q3 GAAP earnings per share (EPS) grew 222 percent to $2.22, compared to $0.69 in the same quarter a year ago.

[0001032975-21-000004:8k_2_02:13]
•Q3 non-GAAP operating income grew 214 percent to $476 million, compared to $152 million in the same quarter a year ago. Q3 non-GAAP EPS grew 192 percent to $2.45, compared to $0.84 in the same quarter a year ago.

[0001032975-21-000004:8k_2_02:14]
•Cash flow from operations was $530 million, compared to $181 million in the same period a year ago.

[0001032975-21-000004:8k_2_02:15]
“This quarter’s record results demonstrate the strength of our portfolio, addressing long-term growth trends in remote work and education, video collaboration, esports, and digital content creation,” said Bracken Darrell, Logitech president and chief executive officer. “We are increasingly investing in our capabilities and people for the growth potential we see in the future. Logitech has never been more relevant to our customers’ work, play and creativity.”

[0001032975-21-000004:8k_2_02:16]
Outlook

[0001032975-21-000004:8k_2_02:17]
Logitech raised its Fiscal Year 2021 annual outlook to between 57 and 60 percent sales growth in constant currency, and approximately $1.05 billion in non-GAAP operating income. The Company’s previous outlook was between 35 and 40 percent sales growth in constant currency, and a range of $700 million to $725 million in non-GAAP operating income.

[0001032975-21-000004:8k_2_02:18]
Prepared Remarks Available Online

[0001032975-21-000004:8k_2_02:19]
Logitech has made its prepared written remarks for the financial results videoconference and livestream available online on the Logitech corporate website at http://ir.logitech.com.

[0001032975-21-000004:8k_2_02:20]
Financial Results Videoconference and Livestream

[0001032975-21-000004:8k_2_02:21]
Logitech will hold a financial results videoconference to discuss the results for Q3 FY 2021 on Tuesday, January 19, 2021 at 8:30 a.m. Eastern Standard Time and 2:30 p.m. Central European Time. A livestream of the event will be available on the Logitech corporate website at http://ir.logitech.com.

[0001032975-21-000004:8k_2_02:22]
Use of Non-GAAP Financial Information and Constant Currency

[0001032975-21-000004:8k_2_02:23]
To facilitate comparisons to Logitech’s historical results, Logitech has included non-GAAP adjusted measures, which exclude share-based compensation expense, amortization of intangible assets, acquisition-related costs, change in fair value of contingent consideration for business acquisition, restructuring charges (credits), loss (gain) on investments, non-GAAP income tax adjustment, and other items detailed under “Supplemental Financial Information” after the tables below. Logitech also presents percentage sales growth in constant currency to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales. Logitech believes this information, used together with the GAAP financial information, will help investors to evaluate its current period performance and trends in its business. With respect to the Company’s outlook for non-GAAP operating income, most of these excluded amounts pertain to events that have not yet occurred and are not currently possible to estimate with a reasonable degree of accuracy. Therefore, no reconciliation to the GAAP amounts has been provided for Fiscal Year 2021.

[0001032975-21-000004:8k_2_02:24]
About Logitech

[0001032975-21-000004:8k_2_02:25]
Logitech designs products that have an everyday place in people's lives, connecting them to the digital experiences they care about. Almost 40 years ago, Logitech started connecting people through computers, and now it’s a multi-brand company designing products that bring people together through music, gaming, video, and computing. Brands of Logitech include Logitech, Logitech G, ASTRO Gaming, Streamlabs, Blue Microphones, Ultimate Ears, and Jaybird. Founded in 1981, and headquartered in Lausanne, Switzerland, Logitech International is a Swiss public company listed on the SIX Swiss Exchange (LOGN) and on the Nasdaq Global Select Market (LOGI). Find Logitech at www.logitech.com, the company blog or @Logitech.

[0001032975-21-000004:8k_2_02:26]
# # #

[0001032975-21-000004:8k_2_02:27]
Note that unless noted otherwise, comparisons are year over year.

[0001032975-21-000004:8k_2_02:28]
Logitech and other Logitech marks are trademarks or registered trademarks of Logitech Europe S.A and/or its affiliates in the U.S. and other countries.  All other trademarks are the property of their respective owners. For more information about Logitech and its products, visit the company’s website at www.logitech.com.

[0001032975-21-000004:8k_2_02:29]
(LOGIIR)

[0001032975-21-000004:8k_2_02:30]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS * |  |  |  |  |  |  |  |  |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | December 31, |  | December 31, |
| GAAP CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Net sales |  | $ | 1,667,302 |  |  | $ | 902,687 |  |  | $ | 3,716,354 |  |  | $ | 2,266,603 |  |
| Cost of goods sold |  | 914,851 |  |  | 564,283 |  |  | 2,082,088 |  |  | 1,410,605 |  |
| Amortization of intangible assets |  | 3,441 |  |  | 3,951 |  |  | 9,800 |  |  | 10,493 |  |
| Gross profit |  | 749,010 |  |  | 334,453 |  |  | 1,624,466 |  |  | 845,505 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Marketing and selling |  | 204,485 |  |  | 134,950 |  |  | 496,520 |  |  | 392,138 |  |
| Research and development |  | 53,910 |  |  | 43,292 |  |  | 157,014 |  |  | 127,499 |  |
| General and administrative |  | 37,606 |  |  | 22,344 |  |  | 98,341 |  |  | 68,551 |  |
| Amortization of intangible assets and acquisition-related costs |  | 4,946 |  |  | 5,084 |  |  | 13,886 |  |  | 12,898 |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | — |  |  | 5,716 |  |  | — |  |
| Restructuring charges (credits), net |  | — |  |  | (45) |  |  | (54) |  |  | 69 |  |
| Total operating expenses |  | 300,947 |  |  | 205,625 |  |  | 771,423 |  |  | 601,155 |  |
| Operating income |  | 448,063 |  |  | 128,828 |  |  | 853,043 |  |  | 244,350 |  |
| Interest income |  | 311 |  |  | 2,063 |  |  | 1,444 |  |  | 7,006 |  |
| Other income, net |  | 6,483 |  |  | 1,101 |  |  | 9,661 |  |  | 2,852 |  |
| Income before income taxes |  | 454,857 |  |  | 131,992 |  |  | 864,148 |  |  | 254,208 |  |
| Provision for income taxes |  | 72,334 |  |  | 14,467 |  |  | 142,638 |  |  | 18,405 |  |
| Net income |  | $ | 382,523 |  |  | $ | 117,525 |  |  | $ | 721,510 |  |  | $ | 235,803 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 2.26 |  |  | $ | 0.70 |  |  | $ | 4.28 |  |  | $ | 1.41 |  |
| Diluted |  | $ | 2.22 |  |  | $ | 0.69 |  |  | $ | 4.21 |  |  | $ | 1.39 |  |
| Weighted average shares used to compute net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | 169,050 |  |  | 167,063 |  |  | 168,448 |  |  | 166,678 |  |
| Diluted |  | 172,587 |  |  | 169,685 |  |  | 171,378 |  |  | 169,173 |  |

[0001032975-21-000004:8k_2_02:31]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |
| PRELIMINARY RESULTS * |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |
|  |  | December 31, 2020 |  | March 31, 2020 |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,388,743 |  |  | $ | 715,566 |  |
| Accounts receivable, net |  | 894,937 |  |  | 394,743 |  |
| Inventories |  | 476,802 |  |  | 229,249 |  |
| Other current assets |  | 117,741 |  |  | 74,920 |  |
| Total current assets |  | 2,878,223 |  |  | 1,414,478 |  |
| Non-current assets: |  |  |  |  |
| Property, plant and equipment, net |  | 96,683 |  |  | 76,119 |  |
| Goodwill |  | 400,993 |  |  | 400,917 |  |
| Other intangible assets, net |  | 103,314 |  |  | 126,941 |  |
| Other assets |  | 333,733 |  |  | 345,019 |  |
| Total assets |  | $ | 3,812,946 |  |  | $ | 2,363,474 |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 811,786 |  |  | $ | 259,120 |  |
| Accrued and other current liabilities |  | 704,573 |  |  | 455,024 |  |
| Total current liabilities |  | 1,516,359 |  |  | 714,144 |  |
| Non-current liabilities: |  |  |  |  |
| Income taxes payable |  | 60,799 |  |  | 40,788 |  |
| Other non-current liabilities |  | 134,021 |  |  | 119,274 |  |
| Total liabilities |  | 1,711,179 |  |  | 874,206 |  |
| Shareholders’ equity: |  |  |  |  |
| Registered shares, CHF 0.25 par value: |  | 30,148 |  |  | 30,148 |  |
| Issued shares — 173,106 at December 31 and March 31, 2020 |  |  |  |  |
| Additional shares that may be issued out of conditional capitals — 50,000 at December 31 and March 31, 2020 |  |  |  |  |
| Additional shares that may be issued out of authorized capital — 17,311 at December 31 and 34,621 at March 31, 2020 |  |  |  |  |
| Additional paid-in capital |  | 108,140 |  |  | 75,097 |  |
| Shares in treasury, at cost — 4,243 at December 31, 2020 and 6,210 at March 31, 2020 |  | (198,435) |  |  | (185,896) |  |
| Retained earnings |  | 2,264,831 |  |  | 1,690,579 |  |
| Accumulated other comprehensive loss |  | (102,917) |  |  | (120,660) |  |
| Total shareholders’ equity |  | 2,101,767 |  |  | 1,489,268 |  |
| Total liabilities and shareholders’ equity |  | $ | 3,812,946 |  |  | $ | 2,363,474 |  |

[0001032975-21-000004:8k_2_02:32]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS * |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | December 31, |  | December 31, |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 382,523 |  |  | $ | 117,525 |  |  | $ | 721,510 |  |  | $ | 235,803 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  | 13,409 |  |  | 10,768 |  |  | 36,010 |  |  | 32,154 |  |
| Amortization of intangible assets |  | 8,388 |  |  | 8,223 |  |  | 23,627 |  |  | 21,958 |  |
| Loss on investments |  | 2,173 |  |  | 709 |  |  | 4,692 |  |  | 772 |  |
| Share-based compensation expense |  | 19,814 |  |  | 13,831 |  |  | 64,714 |  |  | 40,301 |  |
| Deferred income taxes |  | 17,531 |  |  | 9,458 |  |  | 37,683 |  |  | 480 |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | — |  |  | 5,716 |  |  | — |  |
| Other |  | 207 |  |  | (1,010) |  |  | (1,670) |  |  | (1,012) |  |
| Changes in assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | (129,966) |  |  | (61,337) |  |  | (476,804) |  |  | (147,292) |  |
| Inventories |  | (78,258) |  |  | 32,603 |  |  | (239,378) |  |  | (15,170) |  |
| Other assets |  | (21,714) |  |  | 16,949 |  |  | (53,281) |  |  | 2,866 |  |
| Accounts payable |  | 141,848 |  |  | 26,089 |  |  | 541,024 |  |  | 155,190 |  |
| Accrued and other liabilities |  | 173,945 |  |  | 7,327 |  |  | 264,576 |  |  | (1,896) |  |
| Net cash provided by operating activities |  | 529,900 |  |  | 181,135 |  |  | 928,419 |  |  | 324,154 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  | (18,389) |  |  | (10,575) |  |  | (46,163) |  |  | (28,667) |  |
| Investment in privately held companies |  | (120) |  |  | (140) |  |  | (3,525) |  |  | (310) |  |
| Acquisitions, net of cash acquired |  | (360) |  |  | (91,203) |  |  | (360) |  |  | (91,569) |  |
| Proceeds from the sale of property, plant and equipment |  | — |  |  | 1,037 |  |  | — |  |  | 1,037 |  |
| Proceeds from return of strategic investments |  | 2,934 |  |  | — |  |  | 2,934 |  |  | — |  |
| Purchases of trading investments |  | (2,473) |  |  | (546) |  |  | (10,672) |  |  | (3,071) |  |
| Proceeds from sales of trading investments |  | 2,493 |  |  | 568 |  |  | 11,332 |  |  | 3,139 |  |
| Net cash used in investing activities |  | (15,915) |  |  | (100,859) |  |  | (46,454) |  |  | (119,441) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Payment of cash dividends |  | — |  |  | — |  |  | (146,705) |  |  | (124,180) |  |
| Purchases of registered shares |  | (50,271) |  |  | — |  |  | (72,725) |  |  | (15,127) |  |
| Proceeds from exercises of stock options and purchase rights |  | 3,643 |  |  | 2,209 |  |  | 29,709 |  |  | 11,540 |  |
| Tax withholdings related to net share settlements of restricted stock units |  | (3,731) |  |  | (2,188) |  |  | (29,475) |  |  | (23,096) |  |
| Net cash provided (used) in financing activities |  | (50,359) |  |  | 21 |  |  | (219,196) |  |  | (150,863) |  |
| Effect of exchange rate changes on cash and cash equivalents |  | 7,896 |  |  | 1,285 |  |  | 10,408 |  |  | (2,320) |  |
| Net increase in cash and cash equivalents |  | 471,522 |  |  | 81,582 |  |  | 673,177 |  |  | 51,530 |  |
| Cash and cash equivalents, beginning of the period |  | 917,221 |  |  | 574,464 |  |  | 715,566 |  |  | 604,516 |  |
| Cash and cash equivalents, end of the period |  | $ | 1,388,743 |  |  | $ | 656,046 |  |  | $ | 1,388,743 |  |  | $ | 656,046 |  |

[0001032975-21-000004:8k_2_02:33]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS * |  |  |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three Months Ended |  | Nine Months Ended |
|  |  | December 31, |  | December 31, |
| NET SALES |  | 2020 |  | 2019 |  | Change |  | 2020 |  | 2019 |  | Change |
| Net sales by product category: |  |  |  |  |  |  |  |  |  |  |  |  |
| Pointing Devices |  | $ | 213,638 |  |  | $ | 154,540 |  |  | 38 | % |  | $ | 503,228 |  |  | $ | 409,293 |  |  | 23 | % |
| Keyboards & Combos |  | 218,269 |  |  | 156,333 |  |  | 40 |  |  | 565,246 |  |  | 424,061 |  |  | 33 |  |
| PC Webcams |  | 131,700 |  |  | 32,165 |  |  | 309 |  |  | 295,020 |  |  | 89,041 |  |  | 231 |  |
| Tablet & Other Accessories |  | 138,052 |  |  | 31,256 |  |  | 342 |  |  | 267,186 |  |  | 103,442 |  |  | 158 |  |
| Gaming (1) |  | 436,426 |  |  | 245,736 |  |  | 78 |  |  | 916,040 |  |  | 541,265 |  |  | 69 |  |
| Video Collaboration |  | 292,500 |  |  | 91,964 |  |  | 218 |  |  | 659,278 |  |  | 254,941 |  |  | 159 |  |
| Mobile Speakers |  | 72,566 |  |  | 92,969 |  |  | (22) |  |  | 145,156 |  |  | 200,617 |  |  | (28) |  |
| Audio & Wearables |  | 152,952 |  |  | 81,934 |  |  | 87 |  |  | 338,592 |  |  | 208,576 |  |  | 62 |  |
| Smart Home |  | 10,593 |  |  | 15,790 |  |  | (33) |  |  | 25,976 |  |  | 35,088 |  |  | (26) |  |
| Other (2) |  | 606 |  |  | — |  |  | — |  |  | 632 |  |  | 279 |  |  | 127 |  |
| Total sales |  | $ | 1,667,302 |  |  | $ | 902,687 |  |  | 85 | % |  | $ | 3,716,354 |  |  | $ | 2,266,603 |  |  | 64 | % |

[0001032975-21-000004:8k_2_02:34]
(1) Gaming revenue includes streaming services revenue generated by Streamlabs.

[0001032975-21-000004:8k_2_02:35]
(2) Other category includes products that we currently intend to phase out, or have already phased out, because they are no longer strategic to our business.

[0001032975-21-000004:8k_2_02:36]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS * |  |  |  |  |  |  |  |  |
| (In thousands, except per share amounts) - Unaudited |  |  |  |  |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three Months Ended |  | Nine Months Ended |
|  |  | December 31, |  | December 31, |
| GAAP TO NON-GAAP RECONCILIATION (A) |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Gross profit - GAAP |  | $ | 749,010 |  |  | $ | 334,453 |  |  | $ | 1,624,466 |  |  | $ | 845,505 |  |
| Share-based compensation expense |  | 1,747 |  |  | 1,210 |  |  | 4,919 |  |  | 3,552 |  |
| Amortization of intangible assets |  | 3,441 |  |  | 3,951 |  |  | 9,800 |  |  | 10,493 |  |
| Gross profit - Non-GAAP |  | $ | 754,198 |  |  | $ | 339,614 |  |  | $ | 1,639,185 |  |  | $ | 859,550 |  |
| Gross margin - GAAP |  | 44.9 | % |  | 37.1 | % |  | 43.7 | % |  | 37.3 | % |
| Gross margin - Non-GAAP |  | 45.2 | % |  | 37.6 | % |  | 44.1 | % |  | 37.9 | % |
| Operating expenses - GAAP |  | $ | 300,947 |  |  | $ | 205,625 |  |  | $ | 771,423 |  |  | $ | 601,155 |  |
| Less: Share-based compensation expense |  | 18,067 |  |  | 12,621 |  |  | 59,795 |  |  | 36,749 |  |
| Less: Amortization of intangible assets and acquisition-related costs |  | 4,946 |  |  | 5,084 |  |  | 13,886 |  |  | 12,898 |  |
| Less: Change in fair value of contingent consideration for business acquisition |  | — |  |  | — |  |  | 5,716 |  |  | — |  |
| Less: Restructuring charges (credits), net |  | — |  |  | (45) |  |  | (54) |  |  | 69 |  |
| Operating expenses - Non-GAAP |  | $ | 277,934 |  |  | $ | 187,965 |  |  | $ | 692,080 |  |  | $ | 551,439 |  |
| % of net sales - GAAP |  | 18.0 | % |  | 22.8 | % |  | 20.8 | % |  | 26.5 | % |
| % of net sales - Non - GAAP |  | 16.7 | % |  | 20.8 | % |  | 18.6 | % |  | 24.3 | % |
| Operating income - GAAP |  | $ | 448,063 |  |  | $ | 128,828 |  |  | $ | 853,043 |  |  | $ | 244,350 |  |
| Share-based compensation expense |  | 19,814 |  |  | 13,831 |  |  | 64,714 |  |  | 40,301 |  |
| Amortization of intangible assets and acquisition-related costs |  | 8,387 |  |  | 9,035 |  |  | 23,686 |  |  | 23,391 |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | — |  |  | 5,716 |  |  | — |  |
| Restructuring charges (credits), net |  | — |  |  | (45) |  |  | (54) |  |  | 69 |  |
| Operating income - Non - GAAP |  | $ | 476,264 |  |  | $ | 151,649 |  |  | $ | 947,105 |  |  | $ | 308,111 |  |
| % of net sales - GAAP |  | 26.9 | % |  | 14.3 | % |  | 23.0 | % |  | 10.8 | % |
| % of net sales - Non - GAAP |  | 28.6 | % |  | 16.8 | % |  | 25.5 | % |  | 13.6 | % |
| Net income - GAAP |  | $ | 382,523 |  |  | $ | 117,525 |  |  | $ | 721,510 |  |  | $ | 235,803 |  |
| Share-based compensation expense |  | 19,814 |  |  | 13,831 |  |  | 64,714 |  |  | 40,301 |  |
| Amortization of intangible assets and acquisition related costs |  | 8,387 |  |  | 9,035 |  |  | 23,686 |  |  | 23,391 |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | — |  |  | 5,716 |  |  | — |  |
| Restructuring charges (credits), net |  | — |  |  | (45) |  |  | (54) |  |  | 69 |  |
| Loss on investments |  | 2,173 |  |  | 709 |  |  | 4,692 |  |  | 772 |  |
| Non-GAAP income tax adjustment |  | 10,165 |  |  | 2,123 |  |  | 31,564 |  |  | (6,476) |  |
| Net income - Non - GAAP |  | $ | 423,062 |  |  | $ | 143,178 |  |  | $ | 851,828 |  |  | $ | 293,860 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  | $ | 2.22 |  |  | $ | 0.69 |  |  | $ | 4.21 |  |  | $ | 1.39 |  |
| Diluted - Non - GAAP |  | $ | 2.45 |  |  | $ | 0.84 |  |  | $ | 4.97 |  |  | $ | 1.74 |  |
| Shares used to compute net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP and Non - GAAP |  | 172,587 |  |  | 169,685 |  |  | 171,378 |  |  | 169,173 |  |

[0001032975-21-000004:8k_2_02:37]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS * |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three Months Ended |  | Nine Months Ended |
|  |  | December 31, |  | December 31, |
| SHARE-BASED COMPENSATION EXPENSE |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Share-based Compensation Expense |  |  |  |  |  |  |  |  |
| Cost of goods sold |  | $ | 1,747 |  |  | $ | 1,210 |  |  | $ | 4,919 |  |  | $ | 3,552 |  |
| Marketing and selling |  | 8,390 |  |  | 6,216 |  |  | 27,559 |  |  | 20,016 |  |
| Research and development |  | 3,482 |  |  | 2,242 |  |  | 10,348 |  |  | 6,644 |  |
| General and administrative |  | 6,195 |  |  | 4,163 |  |  | 21,888 |  |  | 10,089 |  |
| Total share-based compensation expense |  | 19,814 |  |  | 13,831 |  |  | 64,714 |  |  | 40,301 |  |
| Income tax benefit |  | (3,471) |  |  | (3,135) |  |  | (15,540) |  |  | (12,658) |  |
| Total share-based compensation expense, net of income tax benefit |  | $ | 16,343 |  |  | $ | 10,696 |  |  | $ | 49,174 |  |  | $ | 27,643 |  |

[0001032975-21-000004:8k_2_02:38]
*  Note: These preliminary results for the three and nine months ended December 31, 2020 are subject to adjustments, including subsequent events that may occur through the date of filing our Quarterly Report on Form 10-Q.

[0001032975-21-000004:8k_2_02:39]
(A) Non-GAAP Financial Measures

[0001032975-21-000004:8k_2_02:40]
To supplement our condensed consolidated financial results prepared in accordance with GAAP, we use a number of financial measures, both GAAP and non-GAAP, in analyzing and assessing our overall business performance, for making operating decisions and for forecasting and planning future periods. We consider the use of non-GAAP financial measures helpful in assessing our current financial performance, ongoing operations and prospects for the future as well as understanding financial and business trends relating to our financial condition and results of operations.

[0001032975-21-000004:8k_2_02:41]
While we use non-GAAP financial measures as a tool to enhance our understanding of certain aspects of our financial performance and to provide incremental insight into the underlying factors and trends affecting both our performance and our cash-generating potential, we do not consider these measures to be a substitute for, or superior to, the information provided by GAAP financial measures. Consistent with this approach, we believe that disclosing non-GAAP financial measures to the readers of our financial statements provides useful supplemental data that, while not a substitute for GAAP financial measures, can offer insight in the review of our financial and operational performance and enables investors to more fully understand trends in our current and future performance. In assessing our business during the quarter ended December 31, 2020 and previous periods, we excluded items in the following general categories, each of which are described below:

[0001032975-21-000004:8k_2_02:42]
Share-based compensation expense. We believe that providing non-GAAP measures excluding share-based compensation expense, in addition to the GAAP measures, allows for a more transparent comparison of our financial results from period to period. We prepare and maintain our budgets and forecasts for future periods on a basis consistent with this non-GAAP financial measure. Further, companies use a variety of types of equity awards as well as a variety of methodologies, assumptions and estimates to determine share-based compensation expense. We believe that excluding share-based compensation expense enhances our ability and the ability of investors to understand the impact of non-cash share-based compensation on our operating results and to compare our results against the results of other companies.

[0001032975-21-000004:8k_2_02:43]
Amortization of intangible assets. We incur intangible asset amortization expense, primarily in connection with our acquisitions of various businesses and technologies. The amortization of purchased intangibles varies depending on the level of acquisition activity. We exclude these various charges in budgeting, planning and forecasting future periods and we believe that providing the non-GAAP measures excluding these various non-cash charges, as well as the GAAP measures, provides additional insight when comparing our gross profit, operating expenses, and financial results from period to period.

[0001032975-21-000004:8k_2_02:44]
Acquisition-related costs and change in fair value of contingent consideration for business acquisition.  We incurred expenses and credits in connection with our acquisitions which we generally would not have otherwise incurred in the periods presented as a part of our continuing operations. Acquisition related costs include all incremental expenses incurred to effect a business combination. Fair value of contingent consideration is associated with our estimates of the value of earn-outs in connection with certain acquisitions. We believe that providing the non-GAAP

[0001032975-21-000004:8k_2_02:45]
measures excluding these costs and credits, as well as the GAAP measures, assists our investors because such costs are not reflective of our ongoing operating results.

[0001032975-21-000004:8k_2_02:46]
Restructuring charges (credits). These expenses are associated with re-aligning our business strategies based on current economic conditions. We have undertaken several restructuring plans in recent years. In connection with our restructuring initiatives, we incurred restructuring charges related to employee terminations, facility closures and early cancellation of certain contracts. We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges (credits) are not reflective of our ongoing operating results in the current period.

[0001032975-21-000004:8k_2_02:47]
Loss (gain) on investments. We recognized loss (gain) related to our investments in various companies, which varies depending on the operational and financial performance of those companies in which we invested, and sales of these investments. We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges are not reflective of our ongoing operations.

[0001032975-21-000004:8k_2_02:48]
Non-GAAP income tax adjustment.  Non-GAAP income tax adjustment primarily measures the income tax effect of non-GAAP adjustments excluded above and other events; the determination of which is based upon the nature of the underlying items, the mix of income and losses in jurisdictions and the relevant tax rates in which we operate.

[0001032975-21-000004:8k_2_02:49]
Each of the non-GAAP financial measures described above, and used in this press release, should not be considered in isolation from, or as a substitute for, a measure of financial performance prepared in accordance with GAAP. Further, investors are cautioned that there are inherent limitations associated with the use of each of these non-GAAP financial measures as an analytical tool. In particular, these non-GAAP financial measures are not based on a comprehensive set of accounting rules or principles and many of the adjustments to the GAAP financial measures reflect the exclusion of items that are recurring and may be reflected in the Company’s financial results for the foreseeable future. We compensate for these limitations by providing specific information in the reconciliation included in this press release regarding the GAAP amounts excluded from the non-GAAP financial measures. In addition, as noted above, we evaluate the non-GAAP financial measures together with the most directly comparable GAAP financial information.

[0001032975-21-000004:8k_2_02:50]
Additional Supplemental Financial Information - Constant Currency

[0001032975-21-000004:8k_2_02:51]
In addition, Logitech presents percentage sales growth in constant currency to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales.
