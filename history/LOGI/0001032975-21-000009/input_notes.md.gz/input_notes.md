# LOGI notes — 0001032975-21-000009


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001032975-21-000009:notes:1]
The Company and Summary of Significant Accounting Policies and Estimates
The Company

[0001032975-21-000009:notes:2]
Logitech International S.A, together with its consolidated subsidiaries, (Logitech or the Company) designs, manufactures and markets products that have an everyday place in people's lives, connecting them to the digital experiences they care about. Almost 40 years ago, Logitech created products to improve experiences around the personal PC platform, and today it is a multi-brand, multi-category company designing products that enable better experiences consuming, sharing and creating any digital content such as computing, gaming, video and music, whether it is on a computer, mobile device or in the cloud.

[0001032975-21-000009:notes:3]
[same as prior period, unchanged from 0001032975-20-000048:notes:4]

[0001032975-21-000009:notes:4]
[same as prior period, unchanged from 0001032975-20-000048:notes:5]

[0001032975-21-000009:notes:5]
[same as prior period, unchanged from 0001032975-20-000048:notes:6]

[0001032975-21-000009:notes:6]
[same as prior period, unchanged from 0001032975-20-000048:notes:7]

[0001032975-21-000009:notes:7]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and nine months ended December 31, 2020 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2021, or any future periods.

[0001032975-21-000009:notes:8]
[same as prior period, unchanged from 0001032975-20-000048:notes:9]

[0001032975-21-000009:notes:9]
Other than the recent accounting pronouncements adopted and discussed below under Recent Accounting Pronouncements Adopted, there have been no material changes in the Company’s significant accounting policies during the nine months ended December 31, 2020 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2020.

[0001032975-21-000009:notes:10]
[same as prior period, unchanged from 0001032975-20-000048:notes:11]

[0001032975-21-000009:notes:11]
[same as prior period, unchanged from 0001032975-20-000048:notes:12]

[0001032975-21-000009:notes:12]
[same as prior period, unchanged from 0001032975-20-000048:notes:13]

[0001032975-21-000009:notes:13]
We are subject to risks and uncertainties as a result of the novel coronavirus (COVID-19). Capital markets and economies worldwide have been negatively impacted by COVID-19 and it is still unclear how lasting and deep the economic impacts will be. During the three and nine months ended December 31, 2020, the COVID-19 pandemic had mixed effects on the Company’s results of operations, and it may continue to have mixed or adverse effects. While there was high demand for and consumption of certain of our products that led to increased sales and operating income during the three and nine months ended December 31, 2020, at the same time the Company experienced disruptions and higher costs in our manufacturing, supply chain and logistics operations and outsourced services. The ongoing and full extent of the impact of the COVID-19 pandemic on the Company's business and operational and financial performance and condition, including the sustainability of its effect on trends positive to the Company, is uncertain and will depend on many factors outside the Company's control, including but not limited to the timing, extent, duration and effects of the virus and any of its mutations, the availability of vaccines and their global deployment, the development of effective treatments, the imposition of effective public safety and other protective measures and the public's response to such measures, the impact of COVID-19 on the global economy and demand for the Company's products and services. Should the COVID-19 pandemic or global economic slowdown not improve or worsen, or if the Company's attempt to mitigate its impact on its operations and costs is not successful, the Company's business, results of operations, financial condition and prospects may be adversely affected.

[0001032975-21-000009:notes:14]
[same as prior period, unchanged from 0001032975-20-000048:notes:15]

[0001032975-21-000009:notes:15]
In June 2016, the FASB issued ASU 2016-13, "Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments" (ASU 2016-13), which was further updated and clarified by the FASB through issuance of additional related ASUs, replaces the incurred-loss impairment methodology and requires immediate recognition of estimated credit losses expected to occur for most financial assets, including trade receivables. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. The Company adopted this standard effective April 1, 2020, using a modified retrospective approach. Upon adoption, the Company updated its credit loss models to utilize a forward-looking current expected credit losses (CECL) model in place of the incurred loss methodology for financial instruments measured at amortized cost, including accounts receivable. The cumulative effect adjustment from adoption was not material to the Company's condensed consolidated financial statements.

[0001032975-21-000009:notes:16]
In August 2018, the FASB issued ASU 2018-13, "Fair Value Measurement (Topic 820): Disclosure Framework - Changes to the Disclosure Requirements for Fair Value Measurements" (ASU 2018-13), which eliminates, adds and modifies certain disclosure requirements for fair value measurements, including eliminating the requirement to disclose the amount of and reasons for transfers between Level 1 and Level 2 of the fair value hierarchy, and requiring the range and weighted average used to develop significant unobservable inputs for Level 3 fair value measurements.  Some of these disclosure changes must be applied prospectively while others retrospectively depending on requirement. The Company adopted this standard effective April 1, 2020. The adoption of ASU 2018-13 did not have a material impact on the Company's condensed consolidated financial statements.

[0001032975-21-000009:notes:17]
In August 2018, the FASB issued ASU 2018-14, "Compensation - Retirement Benefits - Defined Benefits Plans - General (Subtopic 715-20): Disclosure Framework - Changes to the Disclosure Requirements for Defined Benefit Plans" (ASU 2018-14), which requires that the Company remove various disclosures that no longer are considered cost-beneficial, namely amounts in accumulated other comprehensive income expected to be recognized as components of net periodic benefit cost over the next fiscal year.  Further, ASU 2018-14 requires disclosure or clarification of the reasons for significant gains or losses related to changes in the benefit obligation for the period.  The Company adopted this standard effective April 1, 2020 using a retrospective approach and the updated disclosures will be included in the Company's Form 10-K for the fiscal year ending March 31, 2021. The adoption of ASU 2018-14 did not have an impact on the Company's condensed consolidated financial statements.

[0001032975-21-000009:notes:18]
[same as prior period, unchanged from 0001032975-20-000048:notes:19]

[0001032975-21-000009:notes:19]
In December 2019, the FASB issued ASU 2019-12, "Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes" (ASU 2019-12), which eliminates certain exceptions for recognizing deferred taxes for investments, performing intraperiod allocation and calculating income taxes in interim periods. This ASU also includes guidance to reduce complexity in certain areas, including recognizing deferred taxes for tax goodwill and allocating taxes to members of a consolidated group. ASU 2019-12 is effective for annual and interim periods in fiscal years beginning after December 15, 2020. Early adoption is permitted. The Company is currently assessing the impact of ASU 2019-12 on its consolidated financial statements and plans to adopt the standard effective April 1, 2021.


## us-gaap:EarningsPerShareTextBlock

[0001032975-21-000009:notes:20]
[same as prior period, unchanged from 0001032975-20-000048:notes:21]

[0001032975-21-000009:notes:21]
The following table summarizes the computations of basic and diluted net income per share for the three and nine months ended December 31, 2020 and December 31, 2019 (in thousands, except per share amounts):

[0001032975-21-000009:notes:22]
|  |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Net income |  | $ | 382,523 |  |  | $ | 117,525 |  |  | $ | 721,510 |  |  | $ | 235,803 |  |
| Shares used in net income per share computation: |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding - basic |  | 169,050 |  |  | 167,063 |  |  | 168,448 |  |  | 166,678 |  |
| Effect of potentially dilutive equivalent shares |  | 3,537 |  |  | 2,622 |  |  | 2,930 |  |  | 2,495 |  |
| Weighted average shares outstanding - diluted |  | 172,587 |  |  | 169,685 |  |  | 171,378 |  |  | 169,173 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 2.26 |  |  | $ | 0.70 |  |  | $ | 4.28 |  |  | $ | 1.41 |  |
| Diluted |  | $ | 2.22 |  |  | $ | 0.69 |  |  | $ | 4.21 |  |  | $ | 1.39 |  |

[0001032975-21-000009:notes:23]
Share equivalents attributable to outstanding stock options, restricted stock units ("RSUs") and employee share purchase plan ("ESPP") rights totaling 0.3 million and 1.8 million for the three months ended December 31, 2020 and 2019, respectively, and 0.4 million and 1.8 million for the nine months ended December 31, 2020 and 2019, respectively, were excluded from the calculation of diluted net income per share because the combined exercise price and average unamortized grant date fair value upon exercise of these options and ESPP rights or vesting of RSUs were greater than the average market price of the Company's shares during the periods presented herein, and therefore their inclusion would have been anti-dilutive. A small number of performance-based awards were not included in the calculation because all necessary conditions had not been satisfied by the end of the respective period, and those shares were not issuable if the end of the reporting period were the end of the performance contingency period.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001032975-21-000009:notes:24]
[same as prior period, unchanged from 0001032975-20-000048:notes:25]

[0001032975-21-000009:notes:25]
[same as prior period, unchanged from 0001032975-20-000048:notes:26]

[0001032975-21-000009:notes:26]
As of December 31, 2020, the Company offers the 2006 Employee Share Purchase Plan, as amended and restated (Non-U.S.) (2006 ESPP), the 1996 Employee Share Purchase Plan (U.S.), as amended and restated (1996 ESPP), the 2006 Stock Incentive Plan, as amended and restated (2006 Plan), and the 2012 Stock Inducement Equity Plan (2012 Plan).

[0001032975-21-000009:notes:27]
The following table summarizes the share-based compensation expense and total income tax benefit recognized for share-based awards for the three and nine months ended December 31, 2020 and 2019 (in thousands):

[0001032975-21-000009:notes:28]
|  |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Cost of goods sold |  | $ | 1,747 |  |  | $ | 1,210 |  |  | $ | 4,919 |  |  | $ | 3,552 |  |
| Marketing and selling |  | 8,390 |  |  | 6,216 |  |  | 27,559 |  |  | 20,016 |  |
| Research and development |  | 3,482 |  |  | 2,242 |  |  | 10,348 |  |  | 6,644 |  |
| General and administrative |  | 6,195 |  |  | 4,163 |  |  | 21,888 |  |  | 10,089 |  |
| Total share-based compensation expense |  | 19,814 |  |  | 13,831 |  |  | 64,714 |  |  | 40,301 |  |
| Income tax benefit |  | (3,471) |  |  | (3,135) |  |  | (15,540) |  |  | (12,658) |  |
| Total share-based compensation expense, net of income tax benefit |  | $ | 16,343 |  |  | $ | 10,696 |  |  | $ | 49,174 |  |  | $ | 27,643 |  |

[0001032975-21-000009:notes:29]
[same as prior period, unchanged from 0001032975-20-000048:notes:30]

[0001032975-21-000009:notes:30]
As of December 31, 2020 and 2019, the balance of capitalized share-based compensation included in inventory was $1.0 million and $0.9 million, respectively.

[0001032975-21-000009:notes:31]
[same as prior period, unchanged from 0001032975-20-000048:notes:32]

[0001032975-21-000009:notes:32]
Certain of the Company’s subsidiaries sponsor defined benefit pension plans or non-retirement post-employment benefits covering substantially all of their employees. Benefits are provided based on employees’ years of service and earnings, or in accordance with applicable employee benefit regulations. The Company’s practice is to fund amounts sufficient to meet the requirements set forth in the applicable employee benefit and tax regulations. The costs recorded of $2.9 million and $2.3 million for the three months ended December 31, 2020 and 2019, respectively, and $8.3 million and $7.1 million for the nine months ended December 31, 2020 and 2019, respectively, were primarily related to service costs.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001032975-21-000009:notes:33]
[same as prior period, unchanged from 0001032975-20-000048:notes:34]

[0001032975-21-000009:notes:34]
[same as prior period, unchanged from 0001032975-20-000048:notes:35]

[0001032975-21-000009:notes:35]
The canton of Vaud enacted the Federal Act on Tax Reform and AHV Financing ("TRAF"), a major reform to better align the Swiss tax system with international tax standards, on March 10, 2020 that took effect as of January 1, 2020.  The longstanding tax ruling from the canton of Vaud was applicable through December 31, 2019.

[0001032975-21-000009:notes:36]
The income tax provision for the three months ended December 31, 2020 was $72.3 million based on an effective income tax rate of 15.9% of pre-tax income, compared to an income tax provision of $14.5 million based on an effective income tax rate of 11.0% of pre-tax income for the three months ended December 31, 2019.  The income tax provision for the nine months ended December 31, 2020 was $142.6 million based on an effective income tax rate of 16.5% of pre-tax income, compared to an income tax provision of $18.4 million based on an effective income tax rate of 7.2% of pre-tax income for the nine months ended December 31, 2019.

[0001032975-21-000009:notes:37]
The change in the effective income tax rate for the three and nine months ended December 31, 2020, compared to the same periods ended December 31, 2019 was primarily due to the mix of income and losses in the various tax jurisdictions in which the Company operates. The Swiss income tax provision in the three and nine months ended December 31, 2020 represents the income tax provision at the full statutory income tax rate of 13.63%.  In the same periods ended December 31, 2019 when TRAF was yet to be enacted at the federal and cantonal levels, the transition income tax provision reflects the application of the longstanding tax ruling through December 31, 2019.  Furthermore, there was a discrete tax benefit of $1.7 million from adjusting deferred tax assets and liabilities in Switzerland in the nine months ended December 31, 2019.  There were discrete tax benefits of $7.2 million and $2.9 million from the recognition of excess tax benefits in the United States and reversal of uncertain tax positions from the expiration of statutes of limitations, respectively, in the nine-month period ended December 31, 2020, compared with $6.0 million and $2.7 million, respectively, in the nine-month period ended December 31, 2019.

[0001032975-21-000009:notes:38]
As of December 31, 2020 and March 31, 2020, the total amount of unrecognized tax benefits due to uncertain tax positions was $158.8 million and $140.8 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-21-000009:notes:39]
As of December 31, 2020 and March 31, 2020, the Company had $60.8 million and $40.8 million, respectively, in non-current income taxes payable including interest and penalties, related to the Company's income tax liability for uncertain tax positions.

[0001032975-21-000009:notes:40]
The Company recognizes interest and penalties related to unrecognized tax positions in the income tax provision. As of December 31, 2020 and March 31, 2020, the Company had $4.7 million and $4.5 million, respectively, of accrued interest and penalties related to uncertain tax positions in non-current income taxes payable.

[0001032975-21-000009:notes:41]
Although the Company has adequately provided for uncertain tax positions, the provisions related to these positions may change as revised estimates are made or the underlying matters are settled or otherwise resolved. During fiscal year 2021, the Company continues to review its tax positions and provide for or reverse unrecognized tax benefits as they arise. During the next twelve months, it is reasonably possible that the amount of unrecognized tax benefits could increase or decrease significantly due to changes in tax law in various jurisdictions, new tax audits and changes in the U.S. dollar as compared to other currencies. Excluding these factors, uncertain tax positions may decrease by as much as $4.4 million  from the lapse of the statutes of limitations in various jurisdictions during the next twelve months.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001032975-21-000009:notes:42]
[same as prior period, unchanged from 0001032975-20-000048:notes:44]

[0001032975-21-000009:notes:43]
The following table presents the components of certain balance sheet asset amounts as of December 31 and March 31, 2020 (in thousands):

[0001032975-21-000009:notes:44]
|  |  | December 31, 2020 |  | March 31, 2020 |
| Accounts receivable, net: |  |  |  |  |
| Accounts receivable |  | $ | 1,196,050 |  |  | $ | 597,939 |  |
| Allowance for doubtful accounts |  | (1,328) |  |  | (1,894) |  |
| Allowance for sales returns |  | (14,665) |  |  | (6,599) |  |
| Allowance for cooperative marketing arrangements |  | (53,387) |  |  | (38,794) |  |
| Allowance for customer incentive programs |  | (91,863) |  |  | (55,741) |  |
| Allowance for pricing programs |  | (139,870) |  |  | (100,168) |  |
|  |  | $ | 894,937 |  |  | $ | 394,743 |  |
| Inventories: |  |  |  |  |
| Raw materials |  | $ | 94,748 |  |  | $ | 56,052 |  |
| Finished goods |  | 382,054 |  |  | 173,197 |  |
|  |  | $ | 476,802 |  |  | $ | 229,249 |  |
| Other current assets: |  |  |  |  |
| Value-added tax receivables |  | $ | 60,746 |  |  | $ | 33,616 |  |
| Prepaid expenses and other assets |  | 56,995 |  |  | 41,304 |  |
|  |  | $ | 117,741 |  |  | $ | 74,920 |  |
| Property, plant and equipment, net: |  |  |  |  |
| Property, plant and equipment at cost |  | $ | 392,478 |  |  | $ | 346,506 |  |
| Accumulated depreciation and amortization |  | (295,795) |  |  | (270,387) |  |
|  |  | $ | 96,683 |  |  | $ | 76,119 |  |
| Other assets: |  |  |  |  |
| Deferred tax assets |  | $ | 219,145 |  |  | $ | 240,528 |  |
| Right-of-use assets |  | 31,532 |  |  | 25,557 |  |
| Trading investments for deferred compensation plan |  | 24,056 |  |  | 20,085 |  |
| Investments in privately held companies |  | 44,634 |  |  | 45,949 |  |
| Other assets |  | 14,366 |  |  | 12,900 |  |
|  |  | $ | 333,733 |  |  | $ | 345,019 |  |

[0001032975-21-000009:notes:45]
The following table presents the components of certain balance sheet liability amounts as of December 31 and March 31, 2020 (in thousands):

[0001032975-21-000009:notes:46]
|  |  | December 31, 2020 |  | March 31, 2020 |
| Accrued and other current liabilities: |  |  |  |  |
| Accrued personnel expenses |  | $ | 138,735 |  |  | $ | 104,423 |  |
| Accrued sales return liability |  | 33,540 |  |  | 30,267 |  |
| Accrued customer marketing, pricing and incentive programs |  | 163,335 |  |  | 130,220 |  |
| Operating lease liability |  | 12,620 |  |  | 10,945 |  |
| Accrued freight and duty |  | 43,477 |  |  | 13,284 |  |
| Warranty accrual |  | 32,128 |  |  | 25,905 |  |
| Income taxes payable |  | 81,547 |  |  | 8,823 |  |
| Contingent consideration |  | 537 |  |  | 23,284 |  |
| Other current liabilities |  | 198,654 |  |  | 107,873 |  |
|  |  | $ | 704,573 |  |  | $ | 455,024 |  |
| Other non-current liabilities: |  |  |  |  |
| Warranty accrual |  | $ | 15,464 |  |  | $ | 14,134 |  |
| Obligation for deferred compensation plan |  | 24,056 |  |  | 20,085 |  |
| Employee benefit plan obligations |  | 66,420 |  |  | 61,303 |  |
| Operating lease liability |  | 22,537 |  |  | 19,536 |  |
| Deferred tax liability |  | 1,931 |  |  | 1,931 |  |
| Other non-current liabilities |  | 3,613 |  |  | 2,285 |  |
|  |  | $ | 134,021 |  |  | $ | 119,274 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001032975-21-000009:notes:47]
[same as prior period, unchanged from 0001032975-20-000048:notes:49]

[0001032975-21-000009:notes:48]
[same as prior period, unchanged from 0001032975-20-000048:notes:50]

[0001032975-21-000009:notes:49]
[same as prior period, unchanged from 0001032975-20-000048:notes:51]

[0001032975-21-000009:notes:50]
[same as prior period, unchanged from 0001032975-20-000048:notes:52]

[0001032975-21-000009:notes:51]
[same as prior period, unchanged from 0001032975-20-000048:notes:53]

[0001032975-21-000009:notes:52]
[same as prior period, unchanged from 0001032975-20-000048:notes:54]

[0001032975-21-000009:notes:53]
|  |  | December 31, 2020 |  | March 31, 2020 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Level 1 |  | Level 2 |  | Level 3 |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 465,838 |  |  | $ | — |  |  | $ | — |  |  | $ | 564,952 |  |  | $ | — |  |  | $ | — |  |
| Trading investments for deferred compensation plan included in other assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 75 |  |  | $ | — |  |  | $ | — |  |  | $ | 846 |  |  | $ | — |  |  | $ | — |  |
| Common stock |  | 1,544 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Money market funds |  | 7,147 |  |  | — |  |  | — |  |  | 7,147 |  |  | — |  |  | — |  |
| Mutual funds |  | 15,290 |  |  | — |  |  | — |  |  | 12,092 |  |  | — |  |  | — |  |
| Total of trading investments for deferred compensation plan |  | $ | 24,056 |  |  | $ | — |  |  | $ | — |  |  | $ | 20,085 |  |  | $ | — |  |  | $ | — |  |
| Currency exchange derivative assetsincluded in other current assets |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 129 |  |  | $ | — |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Contingent consideration for business acquisition included in accrued and other current liabilities |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 23,284 |  |
| Currency exchange derivative liabilitiesincluded in accrued and other current liabilities |  | $ | — |  |  | $ | 4,523 |  |  | $ | — |  |  | $ | — |  |  | $ | 719 |  |  | $ | — |  |

[0001032975-21-000009:notes:54]
The following table summarizes the change in the fair value of the Company's contingent consideration balance during the nine months ended December 31, 2020 (in thousands):

[0001032975-21-000009:notes:55]
|  | Nine Months EndedDecember 31, 2020 |
| Beginning of the period | $ | 23,284 |  |
| Change in fair value of contingent consideration | 5,716 |  |
| Settlement of contingent consideration | (28,463) |  |
| End of the period (1) | $ | 537 |  |

[0001032975-21-000009:notes:56]
(1) As of June 30, 2020, the earn-out period was completed in connection with our acquisition of Streamlabs (defined below). The earn-out payment of $29.0 million is based on the actual net sales of Streamlabs services during the earn-out period and is no longer subject to fair value measurement and was accordingly transferred out of Level 3. During the third quarter of 2021, the fair value of $28.5 million of the contingent consideration was transferred from other current liabilities to equity upon settlement of the contingent consideration through the issuance of shares out of treasury stock. The remaining amount of $0.5 million is held back in escrow for claims made against the escrow and for the payment of taxes.

[0001032975-21-000009:notes:57]
[same as prior period, unchanged from 0001032975-20-000048:notes:59]

[0001032975-21-000009:notes:58]
The marketable securities for the Company's deferred compensation plan were recorded at a fair value of $24.1 million and $20.1 million, as of December 31, 2020 and March 31, 2020, respectively, based on quoted market prices. Quoted market prices are observable inputs that are classified as Level 1 within the fair value hierarchy. Unrealized gains (losses) related to trading securities for the three and nine months ended December 31, 2020 and 2019 were not material and are included in other income, net in the Company's condensed consolidated statements of operations.

[0001032975-21-000009:notes:59]
[same as prior period, unchanged from 0001032975-20-000048:notes:61]

[0001032975-21-000009:notes:60]
On October 31, 2019 (the "Streamlabs Acquisition Date"), the Company acquired all of the equity interests of General Workings, Inc. ("Streamlabs").  In connection with the acquisition of Streamlabs, the Company agreed to pay a total earn out payment of $29.0 million, payable in stock, only upon the achievement of certain net revenues for the period beginning on January 1, 2020 and ending on June 30, 2020.

[0001032975-21-000009:notes:61]
The fair value of the earn-out as of the Streamlabs Acquisition Date was $0.04 million, and increased to $23.3 million as of March 31, 2020, which was determined by using a Black-Scholes-Merton valuation model to calculate the probability of the earn-out threshold being met and times the value of the earn-out payment, and discounted at the risk-free rate. The fair value was increased by $5.7 million to $29.0 million as of June 30, 2020, based on actual sales. The fair value of the contingent consideration no longer needs to be remeasured after June 30, 2020, as the earn-out period has been completed.

[0001032975-21-000009:notes:62]
During the third quarter of fiscal 2021, Logitech issued 390,397 shares out of treasury shares to former security holders of Streamlabs, in satisfaction of payment of the contingent consideration that was earned during the earn-out period of January 1, 2020 through June 30, 2020. The issuances of such shares were deemed to be exempt from registration under the Securities Act of 1933 (the "Securities Act"), in reliance on Regulation D of the Securities Act as transactions by an issuer not involving a public offering.

[0001032975-21-000009:notes:63]
[same as prior period, unchanged from 0001032975-20-000048:notes:64]

[0001032975-21-000009:notes:64]
The Company has certain non-marketable investments included in other assets that are accounted for under the equity method of accounting, with a carrying value of $39.9 million and $42.1 million as of December 31, 2020 and March 31, 2020, respectively.  Unrealized gains (losses) related to equity investments for the three and nine months ended December 31, 2020 and 2019 were not material and are included in other income, net in the Company's condensed consolidated statements of operations. There was no impairment of these assets during the three and nine months ended December 31, 2020 or 2019.

[0001032975-21-000009:notes:65]
[same as prior period, unchanged from 0001032975-20-000048:notes:66]

[0001032975-21-000009:notes:66]
Financial Assets.  The Company has certain investments without readily determinable fair values due to the absence of quoted market prices, the inherent lack of liquidity, and the fact that inputs used to measure fair value are unobservable and require management's judgment. When certain events or circumstances indicate that impairment may exist, the Company revalues the investments using various assumptions, including the financial metrics and ratios of comparable public companies. The carrying value is also adjusted for observable price changes with a same or similar security from the same issuer. The amount of these investments included in other assets was immaterial as of December 31, 2020 and March 31, 2020. There was no impairment of these assets during the three and nine months ended December 31, 2020 or 2019.

[0001032975-21-000009:notes:67]
Non-Financial Assets.  Goodwill, intangible assets, and property, plant and equipment, are not required to be measured at fair value on a recurring basis. However, if certain triggering events occur (or tested at least annually for goodwill) such that a non-financial instrument is required to be evaluated for impairment and an impairment is recorded to reduce the non-financial instrument's carrying value to the fair value as a result of such triggering events, the non-financial assets and liabilities are measured at fair value for the period such triggering events occur. There was no impairment of these assets during the three and nine months ended December 31, 2020 or 2019.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001032975-21-000009:notes:68]
[same as prior period, unchanged from 0001032975-20-000048:notes:69]

[0001032975-21-000009:notes:69]
Under certain agreements with the respective counterparties to the Company’s derivative contracts, subject to applicable requirements, the Company is allowed to net settle transactions of the same type with a single net amount payable by one party to the other. However, the Company presents its derivative assets and derivative liabilities on a gross basis on the condensed consolidated balance sheets as of December 31, 2020 and March 31, 2020.

[0001032975-21-000009:notes:70]
The fair value of the Company’s derivative instruments was not material as of December 31, 2020 or March 31, 2020. The amount of gain (loss) recognized on derivatives not designated as hedging instruments was not material in all periods presented herein. The following table presents the amounts of gains (losses) on the Company’s derivative instruments designated as hedging instruments and their locations on its condensed consolidated statements of operations and condensed consolidated statements of comprehensive income for the  three and nine months ended December 31, 2020 and 2019 (in thousands):

[0001032975-21-000009:notes:71]
|  |  | Three Months EndedDecember 31, |
|  |  | Amount of Gain (Loss)Deferred as a Component of AccumulatedOther Comprehensive Loss |  | Amount of Loss (Gain)Reclassified from Accumulated Other Comprehensive Loss to Costs of Goods Sold |  |  |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |  |  |  |  |
| Cash flow hedges |  | $ | (6,326) |  |  | $ | (1,381) |  |  | $ | 3,446 |  |  | $ | (739) |  |  |  |  |  |

[0001032975-21-000009:notes:72]
|  |  | Nine Months EndedDecember 31, |
|  |  | Amount of Gain (Loss)Deferred as a Component of AccumulatedOther Comprehensive Loss |  | Amount of Loss (Gain)Reclassified from Accumulated Other Comprehensive Loss to Costs of Goods Sold |  |  |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |  |  |  |  |
| Cash flow hedges |  | $ | (9,752) |  |  | $ | 56 |  |  | $ | 5,085 |  |  | $ | (1,097) |  |  |  |  |  |

[0001032975-21-000009:notes:73]
[same as prior period, unchanged from 0001032975-20-000048:notes:74]

[0001032975-21-000009:notes:74]
The Company enters into cash flow hedge contracts to protect against exchange rate exposure of forecasted inventory purchases. These hedging contracts mature within four months. Gains and losses in the fair value of the effective portion of the hedges are deferred as a component of accumulated other comprehensive loss until the hedged inventory purchases are sold, at which time the gains or losses are reclassified to cost of goods sold. Cash flows from such hedges are classified as operating activities in the condensed consolidated statements of cash flows. Hedging relationships are discontinued when hedging contract is no longer eligible for hedge accounting, or is sold, terminated or exercised, or when Company removes hedge designation for the contract. Gains and losses in the fair value of the effective portion of the discontinued hedges continue to be reported in accumulated other comprehensive loss until the hedged inventory purchases are sold, unless it is probable that the forecasted inventory purchases will not occur by the end of the originally specified time period or within an additional two-month period of time thereafter. In all periods presented herein, there have been no forecasted inventory purchases that were probable to not occur by the end of the originally specified time period or within an additional two-month period of time thereafter. The notional amounts of foreign currency exchange forward contracts outstanding related to forecasted inventory purchases were $166.1 million as of December 31, 2020 and $48.0 million as of March 31, 2020. The Company had $4.9 million of net losses related to its cash flow hedges included in accumulated other comprehensive loss as of December 31, 2020, which will be reclassified into earnings within the next 12 months.

[0001032975-21-000009:notes:75]
[same as prior period, unchanged from 0001032975-20-000048:notes:76]

[0001032975-21-000009:notes:76]
The Company also enters into foreign currency exchange forward and swap contracts to reduce the short-term effects of currency exchange rate fluctuations on certain receivables or payables denominated in currencies other than the functional currencies of its subsidiaries. These contracts generally mature within one month. The primary risk managed by using forward and swap contracts is the currency exchange rate risk. The gains or losses on these contracts are recognized in other income, net in the condensed consolidated statements of operations based on the changes in fair value. The notional amounts of these contracts outstanding as of December 31, 2020 and March 31, 2020 were $157.2 million and $64.7 million, respectively. Open forward and swap contracts outstanding as of December 31, 2020 and March 31, 2020 consisted of contracts in Mexican Pesos, Japanese Yen, Canadian Dollars, Taiwan New Dollars and Australian Dollars to be settled at future dates at pre-determined exchange rates.

[0001032975-21-000009:notes:77]
[same as prior period, unchanged from 0001032975-20-000048:notes:78]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001032975-21-000009:notes:78]
Goodwill and Other Intangible Assets
The Company conducts its impairment analysis of goodwill annually at December 31 and as necessary, if changes in facts and circumstances indicate that it is more likely than not that the fair value of the Company’s reporting unit may be less than its carrying amount. The Company conducted its annual impairment analysis of goodwill as of December 31, 2020 by performing a qualitative assessment and concluded that it was more likely than not that the fair value of its reporting unit exceeds its carrying amount.  In assessing the qualitative factors, the Company considered the impact of change in industry and competitive environment, growth in the Company's market capitalization and budgeted-to-actual revenue performance for the last twelve months.

[0001032975-21-000009:notes:79]
The following table summarizes the activities in the Company’s goodwill balance during the nine months ended December 31, 2020 (in thousands):

[0001032975-21-000009:notes:80]
| As of March 31, 2020 |  | $ | 400,917 |  |
| Currency translation |  | 76 |  |
| As of December 31, 2020 |  | $ | 400,993 |  |

[0001032975-21-000009:notes:81]
[same as prior period, unchanged from 0001032975-20-000048:notes:83]

[0001032975-21-000009:notes:82]
|  |  | December 31, 2020 |  | March 31, 2020 |
|  |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |
| Trademark and trade names |  | $ | 45,570 |  |  | $ | (23,615) |  |  | $ | 21,955 |  |  | $ | 45,570 |  |  | $ | (19,061) |  |  | $ | 26,509 |  |
| Developed technology |  | 118,807 |  |  | (86,922) |  |  | 31,885 |  |  | 118,807 |  |  | (77,126) |  |  | 41,681 |  |
| Customer contracts/relationships |  | 90,610 |  |  | (41,136) |  |  | 49,474 |  |  | 90,610 |  |  | (31,859) |  |  | 58,751 |  |
| Total |  | $ | 254,987 |  |  | $ | (151,673) |  |  | $ | 103,314 |  |  | $ | 254,987 |  |  | $ | (128,046) |  |  | $ | 126,941 |  |


## us-gaap:DebtDisclosureTextBlock

[0001032975-21-000009:notes:83]
Financing Arrangements

[0001032975-21-000009:notes:84]
The Company had several uncommitted, unsecured bank lines of credit aggregating $82.6 million as of December 31, 2020. There are no financial covenants under these lines of credit with which the Company must comply. As of December 31, 2020, the Company had outstanding bank guarantees of $37.8 million under these lines of credit. There was no borrowing outstanding under these lines of credit as of December 31, 2020 or March 31, 2020.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001032975-21-000009:notes:85]
Commitments and Contingencies

[0001032975-21-000009:notes:86]
Product Warranties

[0001032975-21-000009:notes:87]
Changes in the Company’s warranty liability for the three and nine months ended December 31, 2020 and 2019 were as follows (in thousands):

[0001032975-21-000009:notes:88]
|  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |  |  |  |
| Beginning of the period | $ | 41,782 |  |  | $ | 37,222 |  |  | $ | 40,039 |  |  | $ | 34,229 |  |  |  |  |
| Provision | 13,692 |  |  | 9,608 |  |  | 28,575 |  |  | 26,652 |  |  |  |  |
| Settlements | (8,371) |  |  | (6,840) |  |  | (22,073) |  |  | (20,544) |  |  |  |  |
| Currency translation | 489 |  |  | 187 |  |  | 1,051 |  |  | (160) |  |  |  |  |
| End of the period | $ | 47,592 |  |  | $ | 40,177 |  |  | $ | 47,592 |  |  | $ | 40,177 |  |  |  |  |

[0001032975-21-000009:notes:89]
Indemnifications

[0001032975-21-000009:notes:90]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these

[0001032975-21-000009:notes:91]
indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of December 31, 2020, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

[0001032975-21-000009:notes:92]
The Company also indemnifies its current and former directors and certain of its current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. The Company is unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not limited, the obligations are conditional in nature and the facts and circumstances involved in any situation that might arise are variable.

[0001032975-21-000009:notes:93]
Legal Proceedings

[0001032975-21-000009:notes:94]
From time to time the Company is involved in claims and legal proceedings that arise in the ordinary course of its business. The Company is currently subject to several such claims and a small number of legal proceedings. The Company believes that these matters lack merit and intends to vigorously defend against them. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company’s defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company’s business, financial condition, cash flows or results of operations in a particular period. Any claims or proceedings against the Company, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain a necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company’s business.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001032975-21-000009:notes:95]
Shareholders’ Equity
Share Repurchase Program

[0001032975-21-000009:notes:96]
[same as prior period, unchanged from 0001032975-20-000048:notes:98]

[0001032975-21-000009:notes:97]
In May 2020, the Company's Board of Directors approved the 2020 share buyback program, which authorized the Company to use up to $250.0 million to purchase up to 17.3 million of Logitech shares. The Company's share buyback program is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Purchases may be started or stopped at any time without prior notice depending on market conditions and other factors. As of December 31, 2020, $177.6 million is still available for repurchase under the 2020 buyback program.

[0001032975-21-000009:notes:98]
[same as prior period, unchanged from 0001032975-20-000048:notes:100]

[0001032975-21-000009:notes:99]
During the three and nine months ended December 31, 2020, the Company declared and paid cash dividends of CHF 0.79 (USD equivalent of $0.87) per share, totaling $146.7 million on the Company's outstanding shares. During the three and nine months ended December 31, 2019, the Company declared and paid cash dividends of CHF 0.73 (USD equivalent of $0.74) per share, totaling $124.2 million on the Company's outstanding shares.

[0001032975-21-000009:notes:100]
[same as prior period, unchanged from 0001032975-20-000048:notes:102]

[0001032975-21-000009:notes:101]
[same as prior period, unchanged from 0001032975-20-000048:notes:103]

[0001032975-21-000009:notes:102]
[same as prior period, unchanged from 0001032975-20-000048:notes:104]

[0001032975-21-000009:notes:103]
[same as prior period, unchanged from 0001032975-20-000048:notes:105]

[0001032975-21-000009:notes:104]
[same as prior period, unchanged from 0001032975-20-000048:notes:106]

[0001032975-21-000009:notes:105]
|  |  | Accumulated Other Comprehensive Income (Loss) |
|  |  | CumulativeTranslationAdjustment |  | DefinedBenefitPlan |  | Deferred Hedging Losses |  | Total |
| March 31, 2020 |  | $ | (100,418) |  |  | $ | (20,016) |  |  | $ | (226) |  |  | $ | (120,660) |  |
| Other comprehensive income (loss) |  | 22,206 |  |  | 204 |  |  | (4,667) |  |  | 17,743 |  |
| December 31, 2020 |  | $ | (78,212) |  |  | $ | (19,812) |  |  | $ | (4,893) |  |  | $ | (102,917) |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001032975-21-000009:notes:106]
[same as prior period, unchanged from 0001032975-20-000048:notes:108]

[0001032975-21-000009:notes:107]
[same as prior period, unchanged from 0001032975-20-000048:notes:109]

[0001032975-21-000009:notes:108]
Sales by product categories and sales channels, excluding intercompany transactions, for the three and nine months ended December 31, 2020 and 2019 were as follows (in thousands):

[0001032975-21-000009:notes:109]
|  |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Pointing Devices |  | $ | 213,638 |  |  | $ | 154,540 |  |  | $ | 503,228 |  |  | $ | 409,293 |  |
| Keyboards & Combos |  | 218,269 |  |  | 156,333 |  |  | 565,246 |  |  | 424,061 |  |
| PC Webcams |  | 131,700 |  |  | 32,165 |  |  | 295,020 |  |  | 89,041 |  |
| Tablet & Other Accessories |  | 138,052 |  |  | 31,256 |  |  | 267,186 |  |  | 103,442 |  |
| Gaming (1) |  | 436,426 |  |  | 245,736 |  |  | 916,040 |  |  | 541,265 |  |
| Video Collaboration |  | 292,500 |  |  | 91,964 |  |  | 659,278 |  |  | 254,941 |  |
| Mobile Speakers |  | 72,566 |  |  | 92,969 |  |  | 145,156 |  |  | 200,617 |  |
| Audio & Wearables |  | 152,952 |  |  | 81,934 |  |  | 338,592 |  |  | 208,576 |  |
| Smart Home |  | 10,593 |  |  | 15,790 |  |  | 25,976 |  |  | 35,088 |  |
| Other (2) |  | 606 |  |  | — |  |  | 632 |  |  | 279 |  |
| Total sales |  | $ | 1,667,302 |  |  | $ | 902,687 |  |  | $ | 3,716,354 |  |  | $ | 2,266,603 |  |

[0001032975-21-000009:notes:110]
(1) Gaming includes streaming services revenue generated by Streamlabs.

[0001032975-21-000009:notes:111]
(2) Other includes products that the Company currently intends to phase out, or has already phased out, because they are no longer strategic to the Company's business.

[0001032975-21-000009:notes:112]
Sales by geographic region (based on the customers’ locations) for the three and nine months ended December 31, 2020 and 2019 were as follows (in thousands):

[0001032975-21-000009:notes:113]
|  |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Americas |  | $ | 704,718 |  |  | $ | 380,493 |  |  | $ | 1,603,221 |  |  | $ | 970,775 |  |
| EMEA |  | 547,044 |  |  | 308,907 |  |  | 1,147,393 |  |  | 719,994 |  |
| Asia Pacific |  | 415,540 |  |  | 213,287 |  |  | 965,740 |  |  | 575,834 |  |
| Total sales |  | $ | 1,667,302 |  |  | $ | 902,687 |  |  | $ | 3,716,354 |  |  | $ | 2,266,603 |  |

[0001032975-21-000009:notes:114]
[same as prior period, unchanged from 0001032975-20-000048:notes:115]

[0001032975-21-000009:notes:115]
[same as prior period, unchanged from 0001032975-20-000048:notes:116]

[0001032975-21-000009:notes:116]
Switzerland, the Company’s home domicile, represented 3% of the Company's total consolidated sales for the  three and nine months ended December 31, 2020, respectively, and represented 4% of the Company's total consolidated sales for the three and nine months ended December 31, 2019, respectively.

[0001032975-21-000009:notes:117]
[same as prior period, unchanged from 0001032975-20-000048:notes:118]

[0001032975-21-000009:notes:118]
[same as prior period, unchanged from 0001032975-20-000048:notes:119]

[0001032975-21-000009:notes:119]
|  |  | December 31, 2020 |  | March 31, 2020 |
| Americas |  | $ | 21,859 |  |  | $ | 26,636 |  |
| EMEA |  | 6,998 |  |  | 5,052 |  |
| Asia Pacific |  | 67,826 |  |  | 44,431 |  |
| Total property, plant and equipment, net |  | $ | 96,683 |  |  | $ | 76,119 |  |

[0001032975-21-000009:notes:120]
Property, plant and equipment, net in the United States and China were $21.6 million and $59.6 million, respectively, as of December 31, 2020, and $26.5 million and $36.6 million, respectively, as of March 31, 2020. No other countries represented 10% or more of the Company’s total consolidated property, plant and equipment, net as of December 31, 2020 or March 31, 2020. Property, plant and equipment, net in Switzerland, the Company’s home domicile, were $4.6 million and $2.3 million as of December 31, 2020 and March 31, 2020, respectively.
