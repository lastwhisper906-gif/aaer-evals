# LOGI MD&A — 0001032975-17-000016


## mdna

[0001032975-17-000016:mdna:1]
ITEM 7.    MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001032975-17-000016:mdna:2]
Overview of Our Company

[0001032975-17-000016:mdna:3]
Logitech is a world leader in designing, manufacturing and marketing products that have an everyday place in people's lives, connecting them to the digital experiences they care about. More than 35 years ago Logitech created products to improve experiences around the PC platform, and now it is designing products that enable better experiences consuming, sharing and creating any digital content (e.g., music, gaming, video), whether it is on a computer, mobile device or in the cloud. Logitech's brands of include Logitech, Jaybird, Logitech G and Ultimate Ears.

[0001032975-17-000016:mdna:4]
Our products participate in five large markets that all have growth opportunities: Music, Gaming, Video Collaboration, Smart Home and Creativity & Productivity. We sell our products to a broad network of domestic and international customers, including direct sales to retailers and e-tailers, and indirect sales through distributors. Our worldwide channel network includes consumer electronics distributors, retailers, mass merchandisers, specialty electronics stores, computer and telecommunications stores, value-added resellers and online merchants.

[0001032975-17-000016:mdna:5]
We operate in a single operating segment: Peripherals. In fiscal years prior to fiscal year 2016, we operated in two segments: Peripherals, including retail and OEM products; and Lifesize Video Conferencing. During fiscal year 2016, we divested the Lifesize Video Conferencing segment, and exited the OEM business. Our financial results treat the Lifesize segment as discontinued operations for all the periods presented in this Annual Report on Form 10-K.

[0001032975-17-000016:mdna:6]
From time to time, we may seek to partner with, or acquire when appropriate, companies that have products, personnel, and technologies that complement our strategic direction. We continually review our product offerings and our strategic direction in light of our profitability targets, competitive conditions, changing consumer trends and the evolving nature of the interface between the consumer and the digital world.

[0001032975-17-000016:mdna:7]
On September 15, 2016, we acquired Saitek product line for a total consideration of approximately $13.0 million (the "Saitek Acquisition"). The Saitek Acquisition is expected to enhance the breadth and depth of our product offerings and expand our engineering capabilities in simulation products.

[0001032975-17-000016:mdna:8]
On April 20, 2016, we acquired Jaybird LLC of Salt Lake City, Utah ("Jaybird") for a purchase price of $54.2 million, including a working capital adjustment and payment of a line-of-credit on behalf of Jaybird, along with an additional earn-out of up to $45 million in cash based on achievement of growth targets over two years (the "Jaybird Acquisition"). Jaybird is a leader in wireless audio wearables for sports and active lifestyles, and the acquisition of Jaybird expands our long-term growth potential in our Music market.

[0001032975-17-000016:mdna:9]
On December 28, 2015, we and Lifesize, Inc., a wholly owned subsidiary of Logitech which holds the assets of our Lifesize video conferencing business, entered into a stock purchase agreement with three venture capital firms. Immediately following the December 28, 2015 closing of the transaction, the venture capital firms held 62.5% of the outstanding shares of Lifesize, which resulted in a divestiture of the Lifesize video conferencing business by us. The historical results of operations and the financial position of Lifesize are included in the consolidated financial statements of Logitech and are reported as discontinued operations within this Annual Report on Form 10-K.

[0001032975-17-000016:mdna:10]
We exited our OEM business during our fiscal quarter ended December 31, 2015. The results of our OEM business are included in our financial statements as part of continuing operations for the nine months ended December 31, 2015 and prior periods. There is no revenue and cost associated with this business in future periods.

[0001032975-17-000016:mdna:11]
Summary of Financial Results

[0001032975-17-000016:mdna:12]
Our total net sales for fiscal year 2017 increased 10% in comparison to fiscal year 2016 due to an increase in retail sales, partially offset by a decrease in OEM sales as a result of exiting the OEM business in the third quarter ended December 31, 2015. The results of operations for Jaybird and Saitek have been included in our consolidated

[0001032975-17-000016:mdna:13]
statements of operations from the acquisition date. For fiscal year 2017, Jaybird and Saitek contributed a total of $65.7 million of net sales.

[0001032975-17-000016:mdna:14]
Retail sales during fiscal year 2017 increased 14% compared to fiscal year 2016. Retail sales increased 12%, 19% and 11% in the Americas ("AMR"), EMEA and Asia Pacific, respectively.

[0001032975-17-000016:mdna:15]
Our gross margin for fiscal year 2017 increased to 36.9%, compared to 33.7% for fiscal year 2016. The increase in gross margin was primarily driven by product cost reductions and our exit from the OEM business in fiscal year 2016, a benefit of $14.4 million primarily due to a change in estimated breakage attributable to customer incentive, cooperative marketing and pricing program accruals in EMEA, as well as greater supply chain efficiencies, partially offset by an increase of promotions, unfavorable currency exchange rates and amortization of intangible assets and purchase accounting effect on inventory from business acquisitions.

[0001032975-17-000016:mdna:16]
Operating expenses for fiscal year 2017 were $608.2 million, or 27.4% of net sales, compared to $552.0 million, or 27.4% for fiscal year 2016. The increase in operating expenses was primarily driven by higher personnel-related costs due to increased headcount, businesses acquired during fiscal year 2017, a higher variable compensation linked to strong performance, and amortization of intangibles from the business acquisitions, partially offset by a gain from change in fair value of contingent consideration from the Jaybird Acquisition and a decrease in restructuring charges as we substantially completed our restructuring plan in the fourth quarter of fiscal year 2016.

[0001032975-17-000016:mdna:17]
Net income from continuing operations for fiscal year 2017 was $205.9 million, compared to $128.4 million for fiscal year 2016.

[0001032975-17-000016:mdna:18]
Trends in Our Business

[0001032975-17-000016:mdna:19]
Our strategy focuses on five large multi-category market opportunities including Music, Gaming, Video Collaboration, Smart Home and Creativity & Productivity. We see opportunities to deliver growth with products in all these markets.

[0001032975-17-000016:mdna:20]
We believe our future growth will be determined by our ability to rapidly create innovative products across multiple digital platforms, including gaming, digital music devices, video and computing. The following discussion represents key trends specific to our market opportunities.

[0001032975-17-000016:mdna:21]
Trends Specific to Our Five Market Opportunities

[0001032975-17-000016:mdna:22]
Music:  The music market grew during fiscal year 2017 driven by growing consumption of music through mobile devices such as smartphones and tablets. This market growth, together with our investments in the UE brand, new channel expansion, acquisitions of new portfolios and our ability to gain market share during fiscal year 2017, has driven our growth in this market.

[0001032975-17-000016:mdna:23]
Gaming:  The PC Gaming platform continues to show strong growth as online gaming, multi-platform experiences, and eSports gain greater popularity and gaming content becomes increasingly more demanding. We believe Logitech is well positioned to benefit from the gaming market growth.

[0001032975-17-000016:mdna:24]
Video Collaboration:   We are continuing our efforts to create and sell innovative products, including Video Collaboration products, to accommodate the increasing demand from medium-sized meeting rooms to small-sized rooms such as huddle rooms. We will continue to invest in select business-specific products, targeted product marketing and sales channel development.

[0001032975-17-000016:mdna:25]
Smart Home:  This market increased in fiscal year 2016 and has continued growing in fiscal year 2017. In October 2016, we introduced a new Amazon Alexa skill that enables voice control of the living room entertainment experience using a Logitech Harmony Hub with Alexa-enabled devices such as the Amazon Echo or Echo Dot. Through Harmony, Alexa can turn on/off and control a TV and AV system. We have also seen early success with the professional installer channel through the recent introduction of the Harmony Pro. We will continue to explore other innovative experiences for the Smart Home.

[0001032975-17-000016:mdna:26]
Creativity & Productivity: Although the consumer demand for PC peripherals is slowing, the installed base of PC users is large. We believe that innovative PC peripherals, such as our mice and keyboards, can renew the PC usage experience, providing growth opportunities. Smaller mobile computing devices, such as tablets, have created new markets and usage models for peripherals and accessories. We offer a number of products to enhance the use of mobile devices, including keyboard folios for the iPad and iPad mini, and keyboard covers and folios for the iPad Air. However, we have seen the market decline for the iPad platform, which has impacted the sales of our tablet accessories.

[0001032975-17-000016:mdna:27]
Business Seasonality, Product Introductions and Business Acquisitions

[0001032975-17-000016:mdna:28]
We have historically experienced higher net sales in our third fiscal quarter ending December 31, compared to other fiscal quarters in our fiscal year, due in part to seasonal holiday demand. Additionally, new product introductions and business acquisitions can significantly impact net sales, product costs and operating expenses. Product introductions can also impact our net sales to distribution channels as these channels are filled with new product inventory following a product introduction, and often channel inventory of an earlier model product declines as the next related major product launch approaches. Net sales can also be affected when consumers and distributors anticipate a product introduction. However, neither historical seasonal patterns nor historical patterns of product introductions should be considered reliable indicators of our future pattern of product introductions, future net sales or financial performance.

[0001032975-17-000016:mdna:29]
Critical Accounting Estimates

[0001032975-17-000016:mdna:30]
The preparation of financial statements and related disclosures in conformity with U.S. GAAP (Generally Accepted Accounting Principles in the United States of America) requires us to make judgments, estimates and assumptions that affect reported amounts of assets, liabilities, net sales and expenses, and the disclosure of contingent assets and liabilities.

[0001032975-17-000016:mdna:31]
We consider an accounting estimate critical if it: (i) requires management to make judgments and estimates about matters that are inherently uncertain; and (ii) is important to an understanding of our financial condition and operating results.

[0001032975-17-000016:mdna:32]
We base our estimates on historical experience and on various other assumptions we believe to be reasonable under the circumstances. Although these estimates are based on management's best knowledge of current events and actions that may impact us in the future, actual results could differ from those estimates. Management has discussed the development, selection and disclosure of these critical accounting estimates with the Audit Committee of the Board of Directors.

[0001032975-17-000016:mdna:33]
We believe the following accounting estimates are most critical to our business operations and to an understanding of our financial condition and results of operations, and reflect the more significant judgments and estimates used in the preparation of our consolidated financial statements.

[0001032975-17-000016:mdna:34]
Accruals for Customer Programs

[0001032975-17-000016:mdna:35]
We record accruals for cooperative marketing arrangements, customer incentive programs, pricing programs and product returns. An allowance against accounts receivable is recorded for accruals and program activity related to our direct customers and indirect customers who receive payments for program activity through our direct customers. A liability is recorded for accruals and program activity related to our indirect customers who receive payments directly and do not have a right of offset against a receivable balance. The estimated cost of these programs is usually recorded as a reduction of revenue. If we receive a separately identifiable benefit from the customer and can reasonably estimate the fair value of that benefit, such cost is reflected in operating expenses. Significant management judgment and estimates must be used to determine the cost of these programs in any accounting period. Certain customer programs require management to estimate the percentage of those programs which will not be claimed or will not be earned by customers based on historical experience and on the specific terms and conditions of particular programs. The percentage of these customer programs that will not be claimed or earned is commonly referred to as "breakage".

[0001032975-17-000016:mdna:36]
Cooperative Marketing Arrangements.    We enter into customer marketing programs with many of our distribution and retail customers, and with certain indirect partners, allowing customers to receive a credit equal to a set percentage of their purchases of our products, or a fixed dollar credit for various marketing programs. The objective of these arrangements is to encourage advertising and promotional events to increase sales of our products. Accruals for these marketing arrangements are recorded at the later of the date the revenue is recognized or the date the incentive is offered, based on negotiated terms, historical experience and inventory levels in the channel.

[0001032975-17-000016:mdna:37]
Customer Incentive Programs.    Customer incentive programs include performance-based incentives and consumer rebates. We offer performance-based incentives to our distribution customers, retail customers and indirect partners based on pre-determined performance criteria. Accruals for performance-based incentives are recognized as a reduction of the sale price at the time of sale. Estimates of required accruals are determined based on negotiated terms, consideration of historical experience, anticipated volume of future purchases, and inventory levels in the channel. Consumer rebates are offered from time to time at our discretion for the primary benefit of

[0001032975-17-000016:mdna:38]
end-users. Accruals for the estimated costs of consumer rebates and similar incentives are recorded at the later of time of sale or when the incentive is offered, based on the specific terms and conditions.

[0001032975-17-000016:mdna:39]
Pricing Programs.    We have agreements with certain customers that contain terms allowing price protection credits to be issued in the event of a subsequent price reduction. At our discretion, we also offer special pricing discounts to certain customers. Special pricing discounts are usually offered only for limited time periods or for sales of selected products to specific indirect partners. Our decision to make price reductions is influenced by product life cycle stage, market acceptance of products, the competitive environment, new product introductions and other factors. Accruals for estimated expected future pricing actions are recognized at the time of sale based on analysis of historical pricing actions by customer and by product, inventories owned by and located at distributors and retailers, current customer demand, current operating conditions, and other relevant customer and product information, such as stage of product life-cycle.

[0001032975-17-000016:mdna:40]
Returns.    We grant limited rights to return products. Return rights vary by customer, and range from just the right to return defective product to stock rotation rights limited to a percentage of sales approved by management. Estimates of expected future product returns are recognized at the time of sale based on analyses of historical return trends by customer and by product, inventories owned by and located at distributors and retailers, current customer demand, current operating conditions, and other relevant customer and product information. Upon recognition, we reduce sales and cost of goods sold for the estimated return. Return trends are influenced by product life cycle status, new product introductions, market acceptance of products, sales levels, product sell-through, the type of customer, seasonality, product quality issues, competitive pressures, operational policies and procedures, and other factors. Return rates can fluctuate over time, but are sufficiently predictable to allow us to estimate expected future product returns.

[0001032975-17-000016:mdna:41]
In connection with our sales growth strategy in EMEA, we expanded our use of performance-based programs in the region in fiscal years 2016 and 2017. During fiscal 2017, as customer incentive, cooperative marketing and pricing programs offered in fiscal year 2016 began to expire, EMEA experienced a significant increase in the rate of breakage on the related accruals as compared to historical levels. After considering the breakage data available through March 31, 2017, we revised our estimates of breakage associated with fiscal year 2017 customer incentive, cooperative marketing and pricing programs that have not yet expired as of year end. In prior periods, we did not have sufficient historical data on customer breakage patterns in the EMEA region to allow for a reliable estimation of future customer breakage attributable to these allowances and accruals. However, by the fourth quarter of fiscal year 2017, sufficient historical data was available to establish a model to reliably estimate the expected future customer breakage. Primarily as a result of this change in estimate, we recognized an increase in net sales of $14.4 million during the fourth quarter of the fiscal year ended March 31, 2017, compared with the preliminary results furnished to the SEC in the Current Report on Form 8-K on April 26, 2017. Significant management judgment and estimates are used to determine the breakage of the programs in any accounting period.

[0001032975-17-000016:mdna:42]
We regularly evaluate the adequacy of our accruals for cooperative marketing arrangements, customer incentive programs, pricing programs and product returns. Future market conditions and product transitions may require us to take action to increase such programs. In addition, when the variables used to estimate these costs change, or if actual costs differ significantly from the estimates, we would be required to record incremental increases or reductions to revenue or operating expenses. If, at any future time, we become unable to reasonably estimate these costs, recognition of revenue might be deferred until products are sold to users, which would adversely impact revenue in the period of transition.

[0001032975-17-000016:mdna:43]
Inventory Valuation

[0001032975-17-000016:mdna:44]
We must order components for our products and build inventory in advance of customer orders. Further, our industry is characterized by rapid technological change, short-term customer commitments and rapid changes in demand.

[0001032975-17-000016:mdna:45]
We record inventories at the lower of cost or market value and record write-downs of inventories that are obsolete or in excess of anticipated demand or market value. A review of inventory is performed each fiscal quarter that considers factors including the marketability and product life cycle stage, product development plans, component cost trends, demand forecasts and current sales levels. Inventory on hand which is not expected to be sold or utilized is considered excess, and we recognize the write-down in cost of goods sold at the time of such determination. The write-down is determined by comparison of the replacement cost with the estimated selling price less any costs of completion and disposal (net realizable value) and the net realizable value less the normal profit margin. At the time of loss recognition, new cost basis per unit and lower-cost basis for that inventory are established and subsequent changes in facts and circumstances would not result in an increase in the cost basis. If

[0001032975-17-000016:mdna:46]
there is an abrupt and substantial decline in demand for Logitech's products or an unanticipated change in technological or customer requirements, we may be required to record additional write-downs that could adversely affect gross margins in the period when the write-downs are recorded.

[0001032975-17-000016:mdna:47]
Share-Based Compensation Expense

[0001032975-17-000016:mdna:48]
Share-based compensation expense includes compensation expense reduced for estimated forfeitures. The grant date fair value for stock options and stock purchase rights is estimated using the Black-Scholes-Merton option-pricing valuation model. The grant date fair value of restricted stock units ("RSUs") that vest upon meeting certain market conditions is estimated using the Monte-Carlo simulation method. The grant date fair value of time-based RSUs and RSUs with performance conditions is calculated based on the closing market price on the date of grant, adjusted by estimated dividends yield prior to vesting.

[0001032975-17-000016:mdna:49]
Our estimates of share-based compensation expense require a number of complex and subjective assumptions including our stock price volatility, employee exercise patterns, future forfeitures, probability of achievement of the set performance conditions, dividend yield, related tax effects and the selection of an appropriate fair value model. We estimate expected share price volatility based on historical volatility using daily prices over the term of past options, RSUs or purchase offerings, as we consider historical share price volatility as most representative of future volatility. We estimate expected life based on historical settlement rates, which we believe are most representative of future exercise and post-vesting termination behaviors. The dividend yield assumption is based on our history and expectations of future dividend payouts.  We use historical data to estimate pre-vesting forfeitures, and we record share-based compensation expense only for those awards that are expected to vest. Effective April 1, 2017, we will adopt Accounting Standards Update ("ASU") 2016-09 and will account for forfeitures as they occur. The impact from the change in the accounting for forfeitures will not have a material impact on our consolidated financial statements.

[0001032975-17-000016:mdna:50]
The assumptions used in calculating the fair value of share-based compensation expense and related tax effects represent our best estimates, but these estimates involve inherent uncertainties and the application of management judgment. As a result, if factors change and we use different assumptions, or if we decide to use a different valuation model, our share-based compensation expense could be materially different in the future from what we have recorded in the current period, which could materially affect our results of operations.

[0001032975-17-000016:mdna:51]
Accounting for Income Taxes

[0001032975-17-000016:mdna:52]
We operate in multiple jurisdictions and our profits are taxed pursuant to the tax laws of these jurisdictions. Our effective income tax rate may be affected by the changes in or interpretations of tax laws and tax agreements in any given jurisdiction, utilization of net operating loss and tax credit carryforwards, changes in geographical mix of income and expense, and changes in our assessment of matters such as the ability to realize deferred tax assets. As a result of these considerations, we must estimate income taxes in each of the jurisdictions in which we operate. This process involves estimating current tax exposure together with assessing temporary differences resulting from different treatment of items for tax and accounting purposes. These differences result in deferred tax assets and liabilities, which are included in the consolidated balance sheet.

[0001032975-17-000016:mdna:53]
We assess the likelihood that our deferred tax assets will be recovered from future taxable income, considering all available evidence such as historical levels of income, expectations and risks associated with estimates of future taxable income and ongoing prudent and feasible tax strategies. When we determine that it is not more likely than not that we will realize all or part of our deferred tax assets, an adjustment is charged to earnings in the period when such determination is made. Likewise, if we later determine that it is more likely than not that all or a part of our deferred tax assets would be realized, the previously provided valuation allowance would be reversed.

[0001032975-17-000016:mdna:54]
We make certain estimates and judgments about the application of tax laws, the expected resolution of uncertain tax positions and other matters surrounding the recognition and measurement of uncertain tax benefits. In the event that uncertain tax positions are resolved for amounts different than our estimates, or the related statutes of limitations expire without the assessment of additional income taxes, we will be required to adjust the amounts of the related assets and liabilities in the period in which such events occur. Such adjustments may have a material impact on our income tax provision and our results of operations.

[0001032975-17-000016:mdna:55]
Goodwill

[0001032975-17-000016:mdna:56]
We conduct a goodwill impairment analysis annually at December 31 or more frequently if indicators of impairment exist or if a decision is made to sell or exit a business. A significant amount of judgment is involved in determining if an indicator of impairment has occurred. Such indicators may include deterioration in general economic conditions, negative developments in equity and credit markets, adverse changes in the markets in which an entity operates, increases in input costs that have a negative effect on earnings and cash flows, a trend of negative or declining cash flows, a decline in actual or planned revenue or earnings compared with actual and projected results of relevant prior periods, or other relevant entity-specific events such as changes in management, key personnel, strategy or customers, contemplation of bankruptcy, or litigation. The fair value that could be realized in an actual transaction may differ from that used to evaluate the impairment of goodwill.

[0001032975-17-000016:mdna:57]
In reviewing goodwill for impairment, an entity has the option to first assess qualitative factors to determine whether the existence of events or circumstances leads to a determination that it is more likely than not (greater than 50%) that the estimated fair value of a reporting unit is less than its carrying amount. If an entity elects to perform a qualitative assessment and determines that an impairment is more likely than not, the entity is then required to perform the two-step quantitative impairment test; otherwise, no further analysis is required. An entity also may elect not to perform the qualitative assessment and, instead, proceed directly to the two-step quantitative impairment test. The ultimate outcome of the goodwill impairment review for a reporting unit should be the same whether an entity chooses to perform the qualitative assessment or proceeds directly to the two-step quantitative impairment test. Goodwill is allocated among and evaluated for impairment at the reporting unit level, which is defined as an operating segment or one level below an operating segment. We currently have only one reporting unit.

[0001032975-17-000016:mdna:58]
Annual Impairment analysis

[0001032975-17-000016:mdna:59]
We performed our annual impairment analysis of the goodwill as of December 31, 2016 by performing a qualitative assessment and concluded that it was more likely than not that the fair value of the peripheral reporting unit exceeded its carrying amount. Refer to the Note 12 to the consolidated financial statements included in this Annual Report on Form 10-K for the disclosures.

[0001032975-17-000016:mdna:60]
Product Warranty Accrual

[0001032975-17-000016:mdna:61]
We estimate the cost of product warranties at the time the related revenue is recognized based on historical and projected warranty claim rates, historical and projected costs, and knowledge of specific product failures that are outside of our typical experience. Each fiscal quarter, we reevaluate estimates to assess the adequacy of recorded warranty liabilities considering the size of the installed base of products subject to warranty protection and adjust the amounts as necessary. If actual product failure rates or repair costs differ from estimates, revisions to the estimated warranty liabilities would be required and could materially affect our results of operations.

[0001032975-17-000016:mdna:62]
Business Acquisitions

[0001032975-17-000016:mdna:63]
Accounting for business acquisitions requires us to make significant estimates and assumptions, especially at the acquisition date with respect to tangible and intangible assets acquired and liabilities assumed and pre-acquisition contingencies. We use our best estimates and assumptions to accurately assign fair value to the tangible and intangible assets acquired and liabilities assumed at the acquisition date.

[0001032975-17-000016:mdna:64]
Examples of critical estimates in valuing certain intangible assets and goodwill we have acquired include but are not limited to:

[0001032975-17-000016:mdna:65]
| • | royalty rate range and forecasted revenue growth rate assumptions; |

[0001032975-17-000016:mdna:66]
| • | assumptions regarding the estimated useful life of the acquired intangibles; |

[0001032975-17-000016:mdna:67]
| • | discount rates. |

[0001032975-17-000016:mdna:68]
Unanticipated events and circumstances may occur that may affect the accuracy or validity of such assumptions, estimates or actual results.

[0001032975-17-000016:mdna:69]
The economic useful life of the developed technology from the business acquisitions was determined based on the technology cycle related to developed technology of existing products, as well as the cash flows over the forecasted periods.

[0001032975-17-000016:mdna:70]
The economic useful life of the customer relationships from the business acquisitions was determined based on historical customer turnover rates and the industry benchmarks.

[0001032975-17-000016:mdna:71]
The economic useful life of the trade names from the business acquisitions was determined based on the expected life of the trade names and the cash flows anticipated over the forecasted periods.

[0001032975-17-000016:mdna:72]
The fair value of acquisition-related contingent consideration liability arising from the Jaybird Acquisition (see "Note 3 - Business Acquisitions" and "Note 10 - Fair Value Measurements" to the consolidated financial statements for more information) is determined by using a Monte Carlo Simulation that includes significant unobservable inputs such as a risk-adjusted discount rate and projected net sales of Jaybird over the earn-out period, and it is remeasured at each reporting period based on the inputs on the date of remeasurement. Projected net sales are based on our internal projections, including analysis of the target markets. The fair value of the contingent consideration decreased $8.1 million from the acquisition date. The change in fair value of contingent consideration results primarily from Jaybird's lower-than-expected net sales and revised projected net sales in the remaining earn-out period, primarily driven by supply constraints, an evolving product portfolio and changes in the competitive target market. Although these estimates are based on management’s best knowledge of current events, the estimates could change significantly from period to period. Any changes to the significant unobservable inputs used, including the change in the forecast of net sales for the earn-out periods, may result in a change in the fair value of contingent consideration, and could have a material impact on future results of operations. Actual payment of contingent consideration in the future could be different from the current estimated fair value of the contingent consideration.

[0001032975-17-000016:mdna:73]
Adoption of New Accounting Pronouncements

[0001032975-17-000016:mdna:74]
In September 2015, the FASB issued ASU No. 2015-16, “Simplifying the Accounting for Measurement-Period Adjustments (Topic 805)” (“ASU 2015-16”), which eliminates the requirement to restate prior period financial statements for measurement period adjustments in business combinations. ASU 2015-16 requires that the cumulative impact of a measurement period adjustment (including the impact on prior periods) be recognized in the reporting period in which the adjustment is identified. We adopted this standard during the fiscal year 2017 and the adoption did not impact our consolidated financial statements.

[0001032975-17-000016:mdna:75]
In August 2016, the FASB issued ASU 2016-15 "Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments" ("ASU 2016-15"), which gives guidance and reduces diversity in practice with respect to certain types of cash flows. We have early adopted this guidance during the second quarter of fiscal year 2017 and the adoption did not impact our consolidated financial statements.

[0001032975-17-000016:mdna:76]
Refer to Note 2 to the consolidated financial statements included in this Annual Report on Form 10-K for recent accounting pronouncements to be adopted.

[0001032975-17-000016:mdna:77]
Constant Currency

[0001032975-17-000016:mdna:78]
We refer to our net sales growth rates excluding the impact of currency exchange rate fluctuations as "constant dollar" sales growth rates. Percentage of constant dollar sales growth is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales.

[0001032975-17-000016:mdna:79]
Given our global sales presence and the reporting of our financial results in U.S. Dollars, our financial results could be affected by significant shifts in currency exchange rates. See “Results of Operations” for information on the effect of currency exchange results on our net sales. If the U.S. Dollar appreciates in comparison to other currencies in future periods, this will affect our results of operations in future periods as well.

[0001032975-17-000016:mdna:80]
Results of Operations

[0001032975-17-000016:mdna:81]
Net Sales

[0001032975-17-000016:mdna:82]
Net sales by channel for fiscal years 2017, 2016 and 2015 were as follows (Dollars in thousands):

[0001032975-17-000016:mdna:83]
|  |  | Years Ended March 31, |  | Change |
|  |  | 2017 |  | 2016 |  | 2015 |  | 2017 vs. 2016 |  | 2016 vs. 2015 |
| Retail |  | $ | 2,221,427 |  |  | $ | 1,947,059 |  |  | $ | 1,887,446 |  |  | 14 | % |  | 3 | % |
| OEM |  | — |  |  | 71,041 |  |  | 117,462 |  |  | (100 | ) |  | (40 | ) |
| Total net sales |  | $ | 2,221,427 |  |  | $ | 2,018,100 |  |  | $ | 2,004,908 |  |  | 10 |  |  | 1 |  |

[0001032975-17-000016:mdna:84]
Retail:

[0001032975-17-000016:mdna:85]
During fiscal year 2017, retail sales increased 14%, in comparison to fiscal year 2016. If currency exchange rates had been constant in 2017 and 2016, our constant dollar retail sales growth rate would have been 14.9%. We grew across almost all our product categories. Video Collaboration, Music, Gaming, and Smart Home grew double digits. We recorded a benefit of $14.4 million primarily due to a change in estimated breakage attributable to customer incentive, cooperative marketing and pricing program accruals in EMEA.

[0001032975-17-000016:mdna:86]
During fiscal year 2016, retail sales increased 3%, in comparison to fiscal year 2015. If currency exchange rates had been constant in 2016 and 2015, our constant dollar retail sales growth rate would have been 9%. The increase in sales was driven by double digit growth in Mobile Speakers, Gaming and Video Collaboration product categories.

[0001032975-17-000016:mdna:87]
OEM:

[0001032975-17-000016:mdna:88]
As we exited our OEM business in December 2015, there was no revenue during fiscal year 2017.

[0001032975-17-000016:mdna:89]
During fiscal year 2016, OEM sales decreased 40% compared to fiscal year 2015.  The decline was primarily due to the exit from our OEM business and there was no revenue during the quarter ended March 31, 2016.

[0001032975-17-000016:mdna:90]
Sales Denominated in Other Currencies

[0001032975-17-000016:mdna:91]
Although our financial results are reported in U.S. Dollars, a portion of our sales were generated in currencies other than the U.S. Dollar, such as the Euro, Chinese Renminbi, Japanese Yen, Canadian Dollar, Taiwan Dollar, British Pound and Australian Dollar. During fiscal years 2017, 2016 and 2015, 50%, 48% and 47% of our net sales were denominated in currencies other than the U.S. Dollar, respectively.

[0001032975-17-000016:mdna:92]
Retail Sales by Region

[0001032975-17-000016:mdna:93]
The following table presents the change in retail sales by region for fiscal year 2017 compared with fiscal year 2016, and fiscal year 2016 compared with fiscal year 2015:

[0001032975-17-000016:mdna:94]
|  |  | 2017 vs. 2016 |  | 2016 vs. 2015 |
| Americas |  | 12 | % |  | 3 | % |
| EMEA |  | 19 |  |  | (1 | ) |
| Asia Pacific |  | 11 |  |  | 10 |  |

[0001032975-17-000016:mdna:95]
Americas

[0001032975-17-000016:mdna:96]
During fiscal year 2017, retail sales in the Americas increased 12%, compared to fiscal year 2016. If currency exchange rates had been constant in 2017 and 2016, our constant dollar retail sales growth rate would have been 13% in the Americas. The increase was driven by growth in Audio PC & Wearables, Mobile Speakers, Gaming and Keyboards & Combos, partially offset by declines in sales for Tablet & Other Accessories.

[0001032975-17-000016:mdna:97]
During fiscal year 2016, retail sales in the Americas increased 3%, compared to fiscal year 2015. If currency exchange rates had been constant in 2016 and 2015, our constant dollar retail sales growth rate would have been 5% in the Americas. This increase was led by double digit growth in Video Collaboration and Mobile Speakers, partially offset by declines in sales for Tablet & Other Accessories and Home Control.

[0001032975-17-000016:mdna:98]
EMEA

[0001032975-17-000016:mdna:99]
During fiscal year 2017, retail sales in EMEA increased 19%, compared to fiscal year 2016. If currency exchange rates had been constant in 2017 and 2016, our constant dollar retail sales growth rate would have been 21% in the EMEA region. The growth in the period was driven by several of our product categories, with strength in Mobile Speakers, Keyboards & Combos, Video Collaboration and Gaming. We recorded a benefit of $14.4 million primarily due to a change in estimated breakage attributable to customer incentive, cooperative marketing and pricing program accruals in EMEA.

[0001032975-17-000016:mdna:100]
During fiscal year 2016, retail sales in EMEA decreased 1%, compared to fiscal year 2015. If currency exchange rates had been constant in 2016 and 2015, our constant dollar retail sales growth rate would have been 9% in the EMEA region. Double digit growth in Gaming, Video Collaboration and Mobile Speakers product categories were offset by declines in all other product categories.

[0001032975-17-000016:mdna:101]
Asia Pacific

[0001032975-17-000016:mdna:102]
During fiscal year 2017, retail sales in Asia Pacific increased 11%, compared to fiscal year 2016. If currency exchange rates had been constant in 2017 and 2016, our constant dollar retail sales growth rate would have been 11% in the Asia Pacific region. The growth in the period was primarily driven by sales increases in Gaming and Video Collaboration.

[0001032975-17-000016:mdna:103]
During fiscal year 2016, retail sales in Asia Pacific increased 10%, compared to fiscal year 2015. If currency exchange rates had been constant in 2016 and 2015, our constant dollar retail sales growth rate would have been 15% in the Asia Pacific region. We achieved double digit growth in Video Collaboration, PC Webcams, Mobile Speakers and Gaming product categories, partially offset by the decline in Tablets & Other Accessories and Home Control product categories.

[0001032975-17-000016:mdna:104]
Net Retail Sales by Product Categories

[0001032975-17-000016:mdna:105]
Net retail sales by product categories for fiscal years 2017, 2016 and 2015 were as follows (Dollars in thousands):

[0001032975-17-000016:mdna:106]
|  |  | Years Ended March 31, |  | Change |
|  |  | 2017 |  | 2016 |  | 2015 |  | 2017 vs. 2016 |  | 2016 vs. 2015 |
| Mobile Speakers |  | $ | 301,021 |  |  | $ | 229,718 |  |  | $ | 178,038 |  |  | 31 | % |  | 29 | % |
| Audio-PC & Wearables |  | 246,390 |  |  | 196,013 |  |  | 213,496 |  |  | 26 |  |  | (8 | ) |
| Gaming |  | 314,362 |  |  | 245,101 |  |  | 211,911 |  |  | 28 |  |  | 16 |  |
| Video Collaboration |  | 127,009 |  |  | 89,322 |  |  | 62,215 |  |  | 42 |  |  | 44 |  |
| Home Control |  | 65,510 |  |  | 59,075 |  |  | 68,060 |  |  | 11 |  |  | (13 | ) |
| Pointing Devices |  | 501,562 |  |  | 492,543 |  |  | 487,210 |  |  | 2 |  |  | 1 |  |
| Keyboards & Combos |  | 480,312 |  |  | 430,190 |  |  | 426,117 |  |  | 12 |  |  | 1 |  |
| Tablet & Other Accessories |  | 76,879 |  |  | 103,886 |  |  | 140,994 |  |  | (26 | ) |  | (26 | ) |
| PC Webcams |  | 107,087 |  |  | 98,641 |  |  | 96,680 |  |  | 9 |  |  | 2 |  |
| Other (1) |  | 1,295 |  |  | 2,570 |  |  | 2,725 |  |  | (50 | ) |  | (6 | ) |
| Total net retail sales |  | $ | 2,221,427 |  |  | $ | 1,947,059 |  |  | $ | 1,887,446 |  |  | 14 |  |  | 3 |  |

[0001032975-17-000016:mdna:107]
__________________________________________

[0001032975-17-000016:mdna:108]
| (1) | Other category includes products that we currently intend to transition out of, or have already transitioned out of, because they are no longer strategic to our business. |

[0001032975-17-000016:mdna:109]
Retail Sales by Product Categories:

[0001032975-17-000016:mdna:110]
Music market:

[0001032975-17-000016:mdna:111]
Mobile Speakers

[0001032975-17-000016:mdna:112]
Our Mobile Speakers category is made up entirely of bluetooth wireless speakers.

[0001032975-17-000016:mdna:113]
During fiscal year 2017, retail sales of Mobile Speakers increased 31%, compared to fiscal year 2016. Mobile Speaker sales increased primarily due to sales of the UE Boom 2 for the full fiscal year 2017 following its launch in the second quarter of fiscal year 2016 as well as the continued success of the UE Megaboom.

[0001032975-17-000016:mdna:114]
During fiscal year 2016, retail sales of Mobile Speakers increased 29%, compared to fiscal year 2015. The sales increased by double digits across all three regions, primarily due to strong demand of UE Boom 2, UE Megaboom and UE Roll bluetooth wireless speakers.

[0001032975-17-000016:mdna:115]
Audio-PC & Wearables

[0001032975-17-000016:mdna:116]
Our Audio-PC & Wearables category comprises PC speakers, PC headsets, in-ear headphones and premium wireless audio wearables.

[0001032975-17-000016:mdna:117]
During fiscal year 2017, retail sales of Audio-PC & Wearables increased 26%, compared to fiscal year 2016. The increase was primarily driven by the Jaybird Freedom F5 earbuds and the Jaybird X2 earbuds resulting from the Jaybird Acquisition in the first quarter of fiscal year 2017 (see Note 3 - "Business Acquisitions" to the consolidated financial statements) and X3 Sport Bluetooth earbuds launched in the third quarter of fiscal year 2017.

[0001032975-17-000016:mdna:118]
During fiscal year 2016, retail sales of Audio-PC & Wearables decreased 8%, compared to fiscal year 2015. The decrease was primarily due to decreases in sales in PC Speakers and PC Headsets, partially offset by an increase in audio wearables. Retail sales of our headset products decreased 6%. Retail sales of our Wearables products increased 46%.

[0001032975-17-000016:mdna:119]
Gaming market:

[0001032975-17-000016:mdna:120]
Gaming

[0001032975-17-000016:mdna:121]
Our Gaming category comprises gaming mice, keyboards, headsets, gamepads, steering wheels and Saitek simulation controllers.

[0001032975-17-000016:mdna:122]
During fiscal year 2017, retail sales of Gaming increased 28%, compared to fiscal year 2016. The increase was primarily driven by the continued success of our G502 Proteus Spectrum gaming mouse, G900 Chaos Spectrum gaming mouse, G933 Artemis Spectrum gaming headset and the G910 Orion Spectrum RGB mechanical gaming keyboard.

[0001032975-17-000016:mdna:123]
During fiscal year 2016, retail sales of Gaming increased 16%, compared to fiscal year 2015 with double digit growth for gaming keyboards, gaming headsets, and gaming steering wheels. Some of our top revenue-generating products for the year include G29 Driving Force Racing Wheel, G920 Driving Force Wheel, G933 Artemis Spectrum gaming headset, and the G910 Orion Spark gaming keyboard.

[0001032975-17-000016:mdna:124]
Video Collaboration market:

[0001032975-17-000016:mdna:125]
Video Collaboration

[0001032975-17-000016:mdna:126]
Our Video Collaboration category primarily includes products which combine audio and video and other products that can connect small- and medium-sized user groups.

[0001032975-17-000016:mdna:127]
During fiscal year 2017, retail sales of Video Collaboration increased 42%, compared to fiscal year 2016.The increase was primarily due to the continued success of the Logitech Group conference camera.

[0001032975-17-000016:mdna:128]
During fiscal year 2016, retail sales of Video Collaboration increased 44%, compared to fiscal year 2014. The increase was primarily due to the success of ConferenceCam Connect, PTZ Pro Camera, and Webcam C930e.

[0001032975-17-000016:mdna:129]
Smart Home market:

[0001032975-17-000016:mdna:130]
Home Control

[0001032975-17-000016:mdna:131]
Our Home Control category includes our Harmony line of advanced home entertainment controllers and new products dedicated to controlling emerging categories of connected smart home devices such as lighting, thermostats and door locks.

[0001032975-17-000016:mdna:132]
During fiscal year 2017, retail sales of Home Control increased 11%, compared to fiscal year 2016. The increase was primarily due to continued success of our Harmony Elite remote.

[0001032975-17-000016:mdna:133]
During fiscal year 2016, retail sales of Home Control decreased 13%, compared to fiscal year 2015. The decline was primarily driven by the sales decrease of our mid-range products.

[0001032975-17-000016:mdna:134]
Creativity & Productivity market:

[0001032975-17-000016:mdna:135]
Pointing Devices

[0001032975-17-000016:mdna:136]
Our Pointing Devices category comprises PC and Mac-related mice, touchpads and presenters.

[0001032975-17-000016:mdna:137]
During fiscal year 2017, retail sales of Pointing Devices increased 2%, in comparison to fiscal year 2016. Increases in sales of presentation tools, corded mice and other pointing devices were offset by the decrease in the sales of cordless mice.

[0001032975-17-000016:mdna:138]
During fiscal year 2016, retail sales of Pointing Devices increased 1%, compared to fiscal year 2015. The growth in this category was driven by the MX Master Wireless Mouse. New products contributed approximately 8% of total retail sales of Pointing Devices for fiscal year 2016.

[0001032975-17-000016:mdna:139]
Keyboards & Combos

[0001032975-17-000016:mdna:140]
Our Keyboards & Combos category comprises PC keyboards and keyboard/mice combo products.

[0001032975-17-000016:mdna:141]
During fiscal year 2017, retail sales of Keyboards & Combos increased 12%, compared to fiscal year 2016. The sales increase was primarily driven by the strong sales of our K400 Plus wireless keyboard and MK270 wireless combo, in addition to sales of our MK235 Combo for the full fiscal year 2017 following its launch in the fourth quarter of fiscal year 2016.

[0001032975-17-000016:mdna:142]
During fiscal year 2016, retail sales of Keyboards & Combos increased 1%, compared to fiscal year 2015. The sales increase was driven mainly by cordless keyboards which grew 17%. Our best selling products in this category include the Wireless MK270 and MK520 Wireless combos.

[0001032975-17-000016:mdna:143]
Tablet & Other Accessories

[0001032975-17-000016:mdna:144]
Our Tablet & Other Accessories category comprises keyboards and covers for tablets and smartphones as well as other accessories for mobile devices.

[0001032975-17-000016:mdna:145]
During fiscal year 2017, retail sales of Tablet & Other Accessories decreased 26%, compared to fiscal year 2016. The sales decrease reflects the declining market for iPad shipments, partially offset by sales of the Create Tablet Keyboard Case for the iPad Pro for the full fiscal year 2017 following its introduction in September of fiscal year 2016.

[0001032975-17-000016:mdna:146]
During fiscal year 2016, retail sales of Tablet & Other Accessories decreased 26%, compared to fiscal year 2015. The reduction in sales reflects the combination of a declining market for iPad shipments, partially offset by the new product introduction of Create backlit tablet keyboard case for iPad Pro.

[0001032975-17-000016:mdna:147]
PC Webcams

[0001032975-17-000016:mdna:148]
Our PC Webcams category comprises PC-based webcams targeted primarily at consumers.

[0001032975-17-000016:mdna:149]
During fiscal year 2017, retail sales of PC Webcams increased 9%, compared to fiscal year 2016. The increase was primarily driven by strong sales of our HD Pro Webcam C920, in addition to the introduction of the C922 Pro Stream Webcam.

[0001032975-17-000016:mdna:150]
During fiscal year 2016, retail sales of PC Webcams increased 2%, compared to fiscal year 2015. The growth was primarily driven by Asia Pacific, with sales nearly doubling.

[0001032975-17-000016:mdna:151]
Gross Profit

[0001032975-17-000016:mdna:152]
Gross profit for fiscal years 2017, 2016 and 2015 was as follows (Dollars in thousands):

[0001032975-17-000016:mdna:153]
|  |  | Years Ended March 31, |
|  |  | 2017 |  | 2016 |  | 2015 |
| Net sales |  | $ | 2,221,427 |  |  | $ | 2,018,100 |  |  | $ | 2,004,908 |  |
| Gross profit |  | $ | 820,041 |  |  | $ | 681,047 |  |  | $ | 705,457 |  |
| Gross margin |  | 36.9 | % |  | 33.7 | % |  | 35.2 | % |

[0001032975-17-000016:mdna:154]
Gross profit consists of net sales, less cost of goods sold (which includes materials, direct labor and related overhead costs, costs of manufacturing facilities, royalties, costs of purchasing components from outside suppliers,

[0001032975-17-000016:mdna:155]
distribution costs, warranty costs, customer support, shipping and handling cost, outside processing costs and write-down of inventories), amortization of intangible assets and purchase accounting effect on inventory.

[0001032975-17-000016:mdna:156]
Gross margin is gross profit as a percentage of net sales. Gross margin increased by 320 basis points to 36.9% during fiscal year 2017, compared to fiscal year 2016. The increase in gross margin was primarily driven by product cost reductions, our exit from the OEM business in fiscal year 2016, a benefit of $14.4 million primarily due to a change in estimated breakage attributable to customer incentive, cooperative marketing and pricing program accruals in EMEA, as well as greater supply chain efficiencies, partially offset by an increase of promotions, unfavorable currency exchange rates, and amortization of intangible assets and purchase accounting effect on inventory from business acquisitions.

[0001032975-17-000016:mdna:157]
Gross margin decreased by 150 basis points to 33.7% in fiscal year 2016 as compared to fiscal year 2015. The decrease is primarily driven by unfavorable fluctuations in currency exchange rates, partially offset by sales price increases and savings from supply chain efficiencies related to freight.

[0001032975-17-000016:mdna:158]
Operating Expenses

[0001032975-17-000016:mdna:159]
Operating expenses for fiscal years 2017, 2016 and 2015 were as follows (Dollars in thousands):

[0001032975-17-000016:mdna:160]
|  |  | Years Ended March 31, |
|  |  | 2017 |  | 2016 |  | 2015 |
| Marketing and selling |  | $ | 379,641 |  |  | $ | 319,015 |  |  | $ | 321,749 |  |
| % of net sales |  | 17.1 | % |  | 15.8 | % |  | 16.0 | % |
| Research and development |  | 130,525 |  |  | 113,176 |  |  | 107,543 |  |
| % of net sales |  | 5.9 | % |  | 5.6 | % |  | 5.4 | % |
| General and administrative |  | 100,270 |  |  | 101,012 |  |  | 125,995 |  |
| % of net sales |  | 4.5 | % |  | 5.0 | % |  | 6.3 | % |
| Amortization of intangible assets and acquisition-related costs |  | 5,814 |  |  | 984 |  |  | 763 |  |
| % of net sales |  | 0.3 | % |  | — | % |  | — | % |
| Change in fair value of contingent consideration for business acquisition |  | (8,092 | ) |  | — |  |  | — |  |
| % of net sales |  | (0.4 | )% |  | — |  |  | — |  |
| Restructuring charges (credits), net |  | 23 |  |  | 17,802 |  |  | (4,777 | ) |
| % of net sales |  | — | % |  | 0.9 | % |  | (0.2 | )% |
| Total operating expenses |  | $ | 608,181 |  |  | $551,989 |  | $551,273 |
| % of net sales |  | 27.4 | % |  | 27.4 | % |  | 27.5 | % |

[0001032975-17-000016:mdna:161]
The increase in total operating expenses during fiscal year 2017, compared to fiscal year 2016, was mainly due to increases in marketing and selling expenses and research and development expenses and amortization of intangibles from the business acquisitions, partially offset by the decrease in restructuring charges and a credit from the change in fair value of contingent consideration for business acquisition.

[0001032975-17-000016:mdna:162]
Total operating expenses during fiscal year 2016 remained relatively flat, compared to fiscal year 2015, with increase in restructuring charges due to restructuring charges of $17.8 million in fiscal year 2016 compared to a restructuring credit of $4.8 million in fiscal year 2015, and increase in research and development expenses partially offset by the decrease in general and administrative expense. Marketing and selling expenses were relatively flat.

[0001032975-17-000016:mdna:163]
Marketing and Selling

[0001032975-17-000016:mdna:164]
Marketing and selling expenses consist of personnel and related overhead costs, corporate and product marketing, promotions, advertising, trade shows, customer and technical support and facilities costs.

[0001032975-17-000016:mdna:165]
During fiscal year 2017, marketing and selling expenses increased $60.6 million, compared to fiscal year 2016. The increase was primarily driven by $43.8 million higher personnel-related costs due to increased headcount during the last twelve months to expand our marketing team to support the advertising and marketing efforts for our products, including the increased headcount resulting from the Jaybird Acquisition and Saitek Acquisition, and

[0001032975-17-000016:mdna:166]
increased variable compensation linked to stronger performance during fiscal year 2017. Additionally, there was an $18.4 million increase in expenses for external advertising and marketing.

[0001032975-17-000016:mdna:167]
During fiscal year 2016, marketing and selling expenses were relatively flat, compared to fiscal year 2015. The decrease in expense due to currency impact was offset by investments in growth markets.

[0001032975-17-000016:mdna:168]
Research and Development

[0001032975-17-000016:mdna:169]
Research and development expenses consist of personnel and related overhead costs for contractors and outside consultants, supplies and materials, equipment depreciation and facilities costs, all associated with the design and development of new products and enhancements of existing products.

[0001032975-17-000016:mdna:170]
During fiscal year 2017, research and development expenses increased $17.3 million, compared to fiscal year 2016. The increase was primarily driven by $13.9 million higher personnel-related costs for the development of new products, increased headcount from business acquisitions, and increased variable compensation linked to stronger performance during fiscal year 2017.

[0001032975-17-000016:mdna:171]
During fiscal year 2016, research and development expenses increased $5.6 million, compared to fiscal year 2015. The increase was primarily due to $4.6 million higher personnel-related expenses and $0.8 million higher consulting costs related to continuing investment in the enhancement of existing products and development of new products.

[0001032975-17-000016:mdna:172]
General and Administrative

[0001032975-17-000016:mdna:173]
General and administrative expenses consist primarily of personnel and related overhead and facilities costs for the finance, information systems, executives, human resources and legal functions.

[0001032975-17-000016:mdna:174]
During fiscal year 2017, general and administrative expenses decreased $0.7 million, compared to fiscal year 2016. The decrease was primarily due to a $3.5 million reduction related to the prior year's accrual for our settlement with the SEC and a $3.1 million decrease in information technology costs, partially offset by a $6.1 million increase in personnel-related costs largely driven by higher variable compensation linked to stronger performance during the fiscal year 2017.

[0001032975-17-000016:mdna:175]
During fiscal year 2016, general and administrative expenses decreased $25.0 million, compared to fiscal year 2015. The decrease was primarily due to the reduction of $19.1 million related to the Audit Committee independent investigation and related expenses incurred in fiscal year 2015 and a $2.5 million decrease in personnel-related costs.

[0001032975-17-000016:mdna:176]
Amortization of Intangibles and Acquisition-Related Costs

[0001032975-17-000016:mdna:177]
Amortization of intangibles included in operating expense and acquisition-related costs during fiscal year 2017, 2016 and 2015 were as follows (in thousands):

[0001032975-17-000016:mdna:178]
|  |  | Years Ended March 31, |
|  |  | 2017 |  | 2016 |  | 2015 |
| Amortization of intangible assets |  | $ | 4,352 |  |  | $ | 448 |  |  | $ | 763 |  |
| Acquisition-related costs |  | 1,462 |  |  | 536 |  |  | — |  |
| Total |  | $ | 5,814 |  |  | $ | 984 |  |  | $ | 763 |  |

[0001032975-17-000016:mdna:179]
Amortization of intangible assets consists of amortization of acquired intangible assets including customer relationships and trade names. Acquisition-related costs include legal expense, due diligence costs, and other professional costs incurred for business acquisitions.

[0001032975-17-000016:mdna:180]
The increase in amortization of intangible assets from fiscal year 2016 to 2017 was driven by the Jaybird and the Saitek Acquisition.

[0001032975-17-000016:mdna:181]
Change in Fair Value of Contingent Consideration for Business Acquisition

[0001032975-17-000016:mdna:182]
The change in fair value of contingent consideration during fiscal year 2017 is primarily due to lower-than-expected net sales of Jaybird products, and revised projected net sales of Jaybird products during the remaining earn-out period, primarily driven by supply constraints, an evolving product portfolio and changes in the competitive target market (see "Note 10 – Fair Value Measurement" to the consolidated financial statements). Although these

[0001032975-17-000016:mdna:183]
estimates are based on management’s best knowledge of current events, the estimates could change significantly from period to period. Any changes to the significant unobservable inputs used, including the change in the forecast of net sales of the earn-out periods, may result in a change in the fair value of contingent consideration, and could have a material impact on future results of operations. Actual payment of contingent consideration in the future could be different from the current estimated fair value of the contingent consideration.

[0001032975-17-000016:mdna:184]
Restructuring Charges

[0001032975-17-000016:mdna:185]
The following table summarizes restructuring-related activities during the fiscal years 2017 and 2016 from continuing operations (in thousands):

[0001032975-17-000016:mdna:186]
|  |  | Restructuring - Continuing Operations |
|  |  | TerminationBenefits |  | Lease ExitCosts |  | Other |  | Total |
| Accrual balance at March 31, 2015 |  | $ | — |  |  | $ | 954 |  |  | $ | — |  |  | $ | 954 |  |
| Charges, net |  | 17,280 |  |  | 337 |  |  | 185 |  |  | 17,802 |  |
| Cash payments |  | (11,373 | ) |  | (1,166 | ) |  | (185 | ) |  | (12,724 | ) |
| Accrual balance at March 31, 2016 |  | 5,907 |  |  | 125 |  |  | — |  |  | 6,032 |  |
| Charges, net |  | 23 |  |  | — |  |  | — |  |  | 23 |  |
| Cash payments |  | (5,195 | ) |  | (125 | ) |  | — |  |  | (5,320 | ) |
| Accrual balance at March 31, 2017 |  | $ | 735 |  |  | $ | — |  |  | $ | — |  |  | $ | 735 |  |

[0001032975-17-000016:mdna:187]
During the first quarter of fiscal year 2016, we implemented a restructuring plan to exit the OEM business, reorganize Lifesize to sharpen its focus on its cloud-based offering, and streamline our overall cost structure, including overhead and infrastructure cost reductions with a targeted resource realignment. Restructuring charges incurred under this plan primarily consisted of severance and other ongoing and one-time termination benefits. Charges and other costs related to the workforce reduction and structure realignment are presented as restructuring charges in the consolidated statements of operations. We substantially completed this restructuring plan by the fourth quarter of fiscal year 2016.

[0001032975-17-000016:mdna:188]
On a total company basis, including the Lifesize video conferencing business as reported in discontinued operations, we have incurred $25.5 million under this restructuring plan, including $24.4 million for cash severance and other personnel costs.

[0001032975-17-000016:mdna:189]
Other Income (Expense), Net

[0001032975-17-000016:mdna:190]
Other income and expense for fiscal years 2017, 2016 and 2015 were as follows (in thousands):

[0001032975-17-000016:mdna:191]
|  |  | Years Ended March 31, |
|  |  | 2017 |  | 2016 |  | 2015 |
| Investment income (loss) related to a deferred compensation plan |  | $ | 1,343 |  |  | $ | (364 | ) |  | $ | 1,055 |  |
| Impairment of investment |  | — |  |  | — |  |  | (2,298 | ) |
| Currency exchange gain (loss), net |  | 169 |  |  | 2,110 |  |  | (1,175 | ) |
| Other |  | 165 |  |  | (122 | ) |  | 120 |  |
|  |  | $ | 1,677 |  |  | $ | 1,624 |  |  | $ | (2,298 | ) |

[0001032975-17-000016:mdna:192]
Investment income (loss) related to a deferred compensation plan for fiscal years 2017, 2016 and 2015 represents earnings, gains, and losses on trading investments related to a deferred compensation plan offered by one of our subsidiaries.

[0001032975-17-000016:mdna:193]
The $2.3 million investment impairment charges in fiscal year 2015 primarily resulted from the write-down of investments in privately-held companies.

[0001032975-17-000016:mdna:194]
Currency exchange gains or losses relate to balances denominated in currencies other than the functional currency in our subsidiaries, as well as to the sale of currencies, and to gains or losses recognized on foreign

[0001032975-17-000016:mdna:195]
currency exchange forward contracts. We do not speculate in currency positions, but we are alert to opportunities to maximize currency exchange gains and minimize currency exchange losses.

[0001032975-17-000016:mdna:196]
Provision for Income Taxes

[0001032975-17-000016:mdna:197]
The provision for income taxes and the effective income tax rate for fiscal years 2017, 2016 and 2015 were as follows (in thousands):

[0001032975-17-000016:mdna:198]
|  |  | Years Ended March 31, |
|  |  | 2017 |  | 2016 |  | 2015 |
| Provision for income taxes |  | $ | 9,113 |  |  | $ | 3,110 |  |  | $ | 4,654 |  |
| Effective income tax rate |  | 4.2 | % |  | 2.4 | % |  | 3.0 | % |

[0001032975-17-000016:mdna:199]
The changes in the effective income tax rate between fiscal years 2017 and 2016 and between fiscal years 2016 and 2015 were primarily due to the mix of income and losses in the various tax jurisdictions in which we operate.  Further, there was a tax benefit of $15.4 million, $16.1 million and $15.4 million in fiscal years 2017, 2016 and 2015, respectively, related to the reversal of uncertain tax positions resulting from the expiration of the statutes of limitations. In fiscal year 2016 and 2015, there was a tax benefit of $2.2 million and $0.8 million, respectively, from the preferential income tax rate reduction pursuant to the High and New Technology Enterprise Program in China.

[0001032975-17-000016:mdna:200]
As of March 31, 2017 and March 31, 2016, the total amounts of unrecognized tax benefits due to uncertain tax positions were $63.7 million and $69.9 million, respectively, all of which would affect the effective income tax rates if recognized.

[0001032975-17-000016:mdna:201]
As of March 31, 2017, we had $51.8 million in non-current income taxes payable and $1.5 million in current income taxes payable, including interest and penalties, related to our income tax liability for uncertain tax positions. As of March 31, 2016, we had $59.7 million in non-current income taxes payable and $0.1 million in current income taxes payable. We continue to recognize interest and penalties related to unrecognized tax positions in income tax expense. We recognized $0.7 million, $0.3 million and $0.8 million in interest and penalties in income tax expense during fiscal years 2017, 2016 and 2015, respectively. As of March 31, 2017, 2016 and 2015, we had $3.0 million, $3.6 million and $4.9 million of accrued interest and penalties related to uncertain tax positions, respectively.

[0001032975-17-000016:mdna:202]
We file Swiss and foreign tax returns. We received final tax assessments in Switzerland through fiscal year 2014.  For other foreign jurisdictions such as the United States, we are generally not subject to tax examinations for years prior to fiscal year 2013. We are under examination and have received assessment notices in foreign tax jurisdictions. If the examinations are resolved unfavorably, there is a possibility they may have a material negative impact on our results of operations.

[0001032975-17-000016:mdna:203]
Liquidity and Capital Resources

[0001032975-17-000016:mdna:204]
Cash Balances, Available Borrowings, and Capital Resources

[0001032975-17-000016:mdna:205]
At March 31, 2017, we had cash and cash equivalents of $547.5 million, compared with $519.2 million at March 31, 2016. Our cash and cash equivalents consist of bank demand deposits and short-term time deposits of which 52% is held in Switzerland, 28% is held in Germany and 9% is held in Hong Kong and China. We do not expect to incur any material adverse tax impact except for what has been recognized or be significantly inhibited by any country in which we do business from the repatriation of funds to Switzerland, our home domicile.

[0001032975-17-000016:mdna:206]
At March 31, 2017, our working capital was $520.8 million, compared with working capital of $511.3 million at March 31, 2016. The increase in working capital over fiscal year 2017 was primarily due to higher balances of cash and cash equivalents, accounts receivables, net and inventories, partially offset by higher accounts payable and accrued and other current liabilities.

[0001032975-17-000016:mdna:207]
We had several uncommitted, unsecured bank lines of credit aggregating to $43.5 million as of March 31, 2017. There are no financial covenants under these lines of credit with which we must comply. As of March 31, 2017, we had outstanding bank guarantees of $20.7 million under these lines of credit.

[0001032975-17-000016:mdna:208]
The following table summarizes our Consolidated Statements of Cash Flows (in thousands) on a total company basis:

[0001032975-17-000016:mdna:209]
|  |  | Years Ended March 31, |
|  |  | 2017 |  | 2016 |  | 2015 |
| Net cash provided by operating activities |  | $ | 278,728 |  |  | $ | 183,111 |  |  | $ | 178,632 |  |
| Net cash used in investing activities |  | (98,964 | ) |  | (60,690 | ) |  | (48,289 | ) |
| Net cash used in financing activities |  | (146,056 | ) |  | (141,669 | ) |  | (48,854 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  | (5,370 | ) |  | 1,405 |  |  | (13,863 | ) |
| Net increase (decrease) in cash and cash equivalents |  | $ | 28,338 |  |  | $ | (17,843 | ) |  | $ | 67,626 |  |

[0001032975-17-000016:mdna:210]
The cash flows for fiscal years 2016 and 2015 included the cash flows from our discontinued operations, which were not material to the consolidated financial statements.

[0001032975-17-000016:mdna:211]
The following table presents selected financial information and statistics for fiscal years 2017, 2016 and 2015 (dollars in thousands):

[0001032975-17-000016:mdna:212]
|  |  | March 31, |
|  |  | 2017 |  | 2016 |  | 2015 |
| Accounts receivable, net |  | $ | 185,179 |  |  | $ | 142,778 |  |  | $ | 167,196 |  |
| Accounts payable |  | $ | 274,805 |  |  | $ | 241,166 |  |  | $ | 292,797 |  |
| Inventories |  | $ | 253,401 |  |  | $ | 228,786 |  |  | $ | 255,980 |  |
| Days sales in accounts receivable ("DSO")(Days)(1) |  | 33 |  |  | 30 |  |  | 34 |  |
| Days accounts payable outstanding ("DPO") (Days)(2) |  | 79 |  |  | 75 |  |  | 88 |  |
| Inventory turnover ("ITO")(x)(3) |  | 4.9 |  |  | 5.0 |  |  | 4.7 |  |

[0001032975-17-000016:mdna:213]
______________________________

[0001032975-17-000016:mdna:214]
| (1) | DSO is determined using ending accounts receivable, net as of the most recent quarter-end and net sales for the most recent quarter. |

[0001032975-17-000016:mdna:215]
| (2) | DPO is determined using ending accounts payable as of the most recent quarter-end and cost of goods sold for the most recent quarter. |

[0001032975-17-000016:mdna:216]
| (3) | ITO is determined using ending inventories and annualized cost of goods sold (based on the most recent quarterly cost of goods sold). |

[0001032975-17-000016:mdna:217]
DSO as of March 31, 2017 increased three days, compared to March 31, 2016, primarily due to timing of net sales and customer payments. DSO as of March 31, 2016 decreased four days compared to March 31, 2015, primarily due to improvements in the efficiency and effectiveness of collection efforts.

[0001032975-17-000016:mdna:218]
DPO as of March 31, 2017 increased four days, compared to March 31, 2016, primarily due to increase in inventories and timing of payments. DPO as of March 31, 2016 decreased thirteen days, compared to March 31, 2015, primarily due to decrease in inventories and timing of payments.

[0001032975-17-000016:mdna:219]
ITO as of March 31, 2017 remained consistent compared to March 31, 2016. ITO as of March 31, 2016 increased compared to March 31, 2015. The increase was primarily due to exit from the OEM business at the end of the quarter ended December 31, 2015 and with no OEM inventories as of March 31, 2016.

[0001032975-17-000016:mdna:220]
If we are not successful in launching and phasing in our new products launched during the current fiscal year, or we are not able to sell the new products at the prices planned, it could have a material impact on our revenue, gross profit margin, operating results including operating cash flow, and inventory turnover in the future.

[0001032975-17-000016:mdna:221]
During fiscal year 2017, we generated $278.7 million in cash from operating activities. Our main sources of operating cash flows were from net income after adding back non-cash expenses of depreciation, amortization, and share-based compensation expense, and from the increases in accounts payable and accrued and other liabilities, partially offset by the increases in accounts receivable, net and inventories. The increases in accounts receivable, net and accounts payable were primarily driven by higher business volumes and timing of payments. The increase in inventories was primarily driven by higher business volumes. The increase in accrued and other liabilities was

[0001032975-17-000016:mdna:222]
primarily due to change in the payment frequency of our cash bonus plan from semi-annual to annual, and higher variable compensation linked to strong performance for fiscal year 2017.

[0001032975-17-000016:mdna:223]
Net cash used in investing activities was $99.0 million, primarily due to $67.0 million of purchase price (net of cash acquired) for business acquisitions, $31.8 million of purchases of property, plant, and equipment, and $1.0 million of investments in privately held companies.

[0001032975-17-000016:mdna:224]
Net cash used in financing activities was $146.1 million, primarily for the $93.1 million cash dividends paid during the year, $83.8 million repurchases of our registered shares and $18.4 million tax withholdings related to net share settlements of restricted stock units, partially offset by $39.6 million in proceeds received from the sale of shares upon exercise of options and purchase rights.

[0001032975-17-000016:mdna:225]
Our expenditures for property, plant and equipment during fiscal years 2017, 2016 and 2015 were primarily for tooling and equipment, computer hardware and software and leasehold improvements.

[0001032975-17-000016:mdna:226]
Our expenditures for property, plant and equipment decreased during fiscal year 2017, compared to fiscal year 2016, due to a lower amount of tooling purchases. Our expenditures for property, plant and equipment increased during fiscal year 2016, compared to fiscal year 2015, mainly due to the building of production lines to accommodate the in-house manufacturing of certain products compared with purchase from third parties in the prior period to align with our goal to achieve cost savings.

[0001032975-17-000016:mdna:227]
Our payments for acquisitions, net of cash acquired, during fiscal year 2017, were for the Jaybird Acquisition and the Saitek Acquisition during the period (refer to "Note 3 - Business Acquisitions" to the consolidated financial statements).  During fiscal year 2017, we made a $1.0 million investment in a limited partnership with a private investment fund. During fiscal year 2016, we made a $1.5 million strategic investment in one privately held company and $0.9 million investment in a limited partnership with a private investment fund. During fiscal year 2015 we made a $2.6 million strategic investment in one privately held company and acquired one privately held company for $0.9 million.

[0001032975-17-000016:mdna:228]
During fiscal year 2016, the net payments for the divestiture of discontinued operations were $1.4 million, and there was $0.7 million for cash outflow to an escrow account for the purchase of a domain name.

[0001032975-17-000016:mdna:229]
The purchases and sales of trading investments during fiscal years 2017, 2016 and 2015 represent mutual fund activity directed by participants in a deferred compensation plan offered by one of our subsidiaries. The mutual funds are held by a Rabbi Trust.

[0001032975-17-000016:mdna:230]
Excess tax benefit realized from share-based compensation included in cash flows from financing activities will be reclassified in operating cash flows starting in the first quarter of our fiscal year 2018 on a retrospective basis when we adopt ASU 2016-09. Refer to Note 2 to the consolidated financial statements included in this Annual Report on Form 10-K for recent accounting pronouncements to be adopted.

[0001032975-17-000016:mdna:231]
During fiscal year 2017, there was a $5.4 million loss of currency translation exchange rate effect on cash and cash equivalents, compared to a gain of $1.4 million of currency translation exchange rate effect during fiscal year 2016, and a $13.9 million loss of currency translation exchange rate effect during fiscal year 2015. Higher currency translation exchange effects during fiscal years 2017 and 2015 were primarily due to the weakening of the Euro versus the U.S. Dollar by 6% and 22%, respectively, which had an adverse impact on our cash and cash equivalents balances in subsidiaries with Euro as their functional currency.

[0001032975-17-000016:mdna:232]
Cash Outlook

[0001032975-17-000016:mdna:233]
Our principal sources of liquidity are our cash and cash equivalents, cash flow generated from operations and, to a much lesser extent, capital markets and borrowings. Our future working capital requirements and capital expenditures may increase to support investment in product innovations and growth opportunities, or to acquire or invest in complementary businesses, products, services, and technologies.

[0001032975-17-000016:mdna:234]
In May 2017, the Board of Directors recommended that the Company pay approximately CHF 100.0 million (approximately $100.0 million based on the exchange rate on March 31, 2017) in cash dividends for fiscal year 2017. During fiscal year 2017, we paid a cash dividend of CHF 90.2 million (U.S. Dollar amount of $93.1 million) out of retained earnings. During fiscal year 2016, we paid a cash dividend of CHF 83.1 million (U.S. Dollar amount of $85.9 million) out of retained earnings.

[0001032975-17-000016:mdna:235]
In March 2014, our Board of Directors approved a share buyback program, which authorizes us to invest up to $250.0 million to purchase our own shares. As of March 31, 2017, the remaining amount that may be repurchased

[0001032975-17-000016:mdna:236]
under the program is $94.6 million. This buyback program expired in April 2017 with approximately 0.2 million shares purchased for approximately $0.6 million subsequent to the year end.

[0001032975-17-000016:mdna:237]
In March 2017, our Board of Directors approved another share buyback program, which authorizes us to invest up to $250.0 million to purchase our own shares, following the expiration date of the 2014 buyback program. The new program was approved by the Swiss Takeover Board in May 2017. Although we enter into trading plans for systematic repurchases (e.g. 10b5-1 trading plans) from time to time, our share buyback program provides us with the opportunity to make opportunistic repurchases during periods of favorable market conditions and is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Opportunistic purchases may be started or stopped at any time without prior notice depending on market conditions and other factors.

[0001032975-17-000016:mdna:238]
As noted in "Note 3 - Business Acquisitions" to our consolidated financial statements, we acquired all of the equity interest of Jaybird for a purchase price of $54.2 million, including a working capital adjustment and payment of a line-of-credit on behalf of Jaybird, with an additional earn-out of up to $45 million in cash based on the achievement of certain net revenue growth targets over two years starting July 2016. If the net revenue growth targets are met, the Company will pay a maximum of $25 million and $20 million in fiscal years 2018 and 2019, respectively.

[0001032975-17-000016:mdna:239]
We have changed the payment frequency of our employee performance bonus plan from semi-annual payments to an annual payment. The full year bonus for fiscal year 2017 is expected to be made in the first quarter of fiscal year 2018, and the operating cash flow for that period could be negative as a result.

[0001032975-17-000016:mdna:240]
Our other contractual obligations and commitments that require cash are described in the following sections.

[0001032975-17-000016:mdna:241]
For over ten years, we have generated positive cash flows from our operating activities, including cash from operations of $278.7 million, $183.1 million and $178.6 million during fiscal years 2017, 2016, and 2015, respectively. If we do not generate sufficient operating cash flows to support our operations and future planned cash requirements, our operations could be harmed and our access to credit facilities could be restricted or eliminated. However, we believe that the trend of our historical cash flow generation, our projections of future operations and our available cash balances will provide sufficient liquidity to fund our operations for at least the next 12 months.

[0001032975-17-000016:mdna:242]
Contractual Obligations and Commitments

[0001032975-17-000016:mdna:243]
The following table summarizes our contractual obligations and commitments as of March 31, 2017 (in thousands):

[0001032975-17-000016:mdna:244]
|  |  |  |  | Payments Due by Period |
|  |  | March 31, 2017 | <1 year |  | 1-3 years |  | 4-5 years |  | >5 years |
| Inventory purchase commitments |  | $ | 228,118 |  |  | $ | 228,118 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Capital purchase commitments |  | 9,349 |  |  | 9,349 |  |  | — |  |  | — |  |  | — |  |
| Expected contribution to employee benefit plan (1) |  | 5,485 |  |  | 5,485 |  |  | * |  |  | * |  |  | * |  |
| Operating leases obligations |  | 39,363 |  |  | 10,294 |  |  | 15,795 |  |  | 8,991 |  |  | 4,283 |  |
|  |  | $ | 282,315 |  |  | $ | 253,246 |  |  | $ | 15,795 |  |  | $ | 8,991 |  |  | $ | 4,283 |  |

[0001032975-17-000016:mdna:245]
(1) Expected contribution to employee benefit plan:  Commitments under the retirement plans relate to expected contributions to be made to our defined benefit plans for the next year only. We fund our pension plans so that we meet at least the minimum contribution requirements, as established by local government, funding and taxing authorities. Expected contributions and payments to our defined benefit pension plans and non-retirement post-employment benefit plans beyond one year are excluded from the contractual obligations table because they are dependent on numerous factors that may result in a wide range of outcomes and thus are impractical to estimate. For more information on our defined benefit pension plans and non-retirement post-employment benefit plans, see Note 6 to the Consolidated Financial Statements in Item 8, which is incorporated herein by reference.

[0001032975-17-000016:mdna:246]
Purchase Commitments

[0001032975-17-000016:mdna:247]
As of March 31, 2017, we have fixed purchase commitments of $228.1 million for inventory purchases made in the normal course of business to original design manufacturers, contract manufacturers and other suppliers, the majority of which are expected to be fulfilled during the first two quarters of fiscal year 2018. We recorded a liability for firm, non-cancelable, and unhedged inventory purchase commitments in excess of

[0001032975-17-000016:mdna:248]
anticipated demand or market value consistent with our valuation of excess and obsolete inventory. As of March 31, 2017, the liability for these purchase commitments was $7.2 million and is recorded in accrued and other current liabilities and is not included in the preceding table. We have firm purchase commitments of $9.3 million for capital expenditures, primarily related to commitments for tooling, computer hardware and leasehold improvements. We expect to continue making capital expenditures in the future to support product development activities and ongoing and expanded operations. Although open purchase commitments are considered enforceable and legally binding, the terms generally allow us the option to reschedule and adjust our requirements based on business needs prior to delivery of goods.

[0001032975-17-000016:mdna:249]
Operating Leases Obligation

[0001032975-17-000016:mdna:250]
We lease facilities under operating leases, certain of which require us to pay property taxes, insurance and maintenance costs. Operating leases for facilities are generally renewable at our option and usually include escalation clauses linked to inflation. The remaining terms on our non-cancelable operating leases expire in various years through 2030.

[0001032975-17-000016:mdna:251]
Contingent Consideration for Business Acquisition

[0001032975-17-000016:mdna:252]
As noted in "Note 3 - Business Acquisitions" to our consolidated financial statements, we acquired all of the equity interest of Jaybird for a purchase price of $54.2 million, including a working capital adjustment and payment of a line-of-credit on behalf of Jaybird, with an additional earn-out of up to $45 million in cash based on the achievement of certain net revenue growth targets over two years starting July 2016. If the net revenue growth targets are met, we will pay a maximum of $25 million and $20 million in fiscal years 2018 and 2019, respectively. These amounts are not included in the preceding table because these represent the maximum amounts but the actual amounts paid could be different. See "Note 10 - Fair Value Measurements" to the consolidated financial statements for more information regarding the fair value of the contingent consideration.

[0001032975-17-000016:mdna:253]
Income Taxes Payable

[0001032975-17-000016:mdna:254]
As of March 31, 2017, we had $51.8 million in non-current income taxes payable and $1.5 million in current income taxes payable, including interest and penalties, related to our income tax liability for uncertain tax positions. At this time, we are unable to make a reasonably reliable estimate of the timing of payments in individual years in connection with these tax liabilities; therefore, such amounts are not included in the above contractual obligation table.

[0001032975-17-000016:mdna:255]
Investment Commitments

[0001032975-17-000016:mdna:256]
During 2015, we entered into a limited partnership agreement with a private investment fund specialized in early-stage start-up consumer hardware electronics companies and committed a capital contribution of $4.0 million over the life of the fund. As of March 31, 2017, $2.1 million of the committed capital contribution has not yet been called by the fund.

[0001032975-17-000016:mdna:257]
Guarantees

[0001032975-17-000016:mdna:258]
Logitech Europe S.A. guaranteed payments of two third-party contract manufacturers' purchase obligations. As of March 31, 2017, the maximum amount of these guarantees were $3.8 million, of which $1.4 million of guaranteed purchase obligations were outstanding.

[0001032975-17-000016:mdna:259]
Indemnifications

[0001032975-17-000016:mdna:260]
We indemnify certain of our suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys' fees. As of March 31, 2017, no amounts have been accrued for indemnification provisions. We do not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under our indemnification arrangements.

[0001032975-17-000016:mdna:261]
We also indemnify our current and former directors and certain of our current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. We are unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not capped, the obligations are conditional in nature, and the facts and circumstances involved in any situation that might arise are variable.

[0001032975-17-000016:mdna:262]
The Stock Purchase Agreement that we entered into in connection with the investment by three venture capital firms in Lifesize, Inc. contains representations, warranties and covenants of Logitech and Lifesize, Inc. to the Venture Investors. Subject to certain limitations, we have agreed to indemnify the Venture Investors and certain persons related to the Venture Investors for certain losses resulting from breaches of or inaccuracies in such representations, warranties and covenants as well as certain other obligations, including third party expenses, restructuring costs and pre-closing tax obligations of Lifesize.

[0001032975-17-000016:mdna:263]
Off-Balance Sheet Arrangements

[0001032975-17-000016:mdna:264]
We do not have any off-balance sheet arrangements that have, or are reasonably likely to have, a current or future effect on our financial condition, changes in financial condition, revenues or expenses, results of operations, liquidity, capital expenditures or capital resources that are material to investors.
