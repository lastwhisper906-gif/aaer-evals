# LOGI 8-K — 0001032975-17-000012 filed 2017-04-26

## item codes, every 8-K on or before 2017-05-26

- 2017-04-26 0001032975-17-000012 — 2.02, 9.01
- 2017-01-25 0001032975-17-000002 — 2.02, 9.01
- 2016-10-26 0001032975-16-000103 — 2.02, 9.01
- 2016-09-13 0001032975-16-000101 — 5.07, 8.01
- 2016-07-28 0001032975-16-000092 — 2.02, 9.01
- 2016-06-30 0001032975-16-000087 — 5.02
- 2016-04-28 0001032975-16-000077 — 2.02, 9.01
- 2016-04-14 0001032975-16-000073 — 1.01, 7.01, 9.01
- 2016-01-21 0001032975-16-000064 — 2.02, 9.01
- 2016-01-04 0001032975-16-000061 — 1.01, 2.01, 9.01
- 2015-12-23 0001032975-15-000059 — 5.02
- 2015-10-22 0001032975-15-000047 — 2.02, 9.01
- 2015-09-11 0001032975-15-000044 — 5.07, 8.01
- 2015-07-24 0001032975-15-000034 — 2.05 — amendment of 0001032975-15-000030
- 2015-07-23 0001032975-15-000030 — 2.02, 9.01
- 2015-06-25 0001032975-15-000025 — 5.02
- 2015-05-14 0001032975-15-000011 — 8.01, 9.01
- 2015-04-23 0001032975-15-000008 — 2.02, 2.05
- 2015-01-22 0001628280-15-000191 — 2.02, 8.01
- 2014-12-23 0001193125-14-450908 — 5.02, 5.07, 8.01
- 2014-11-25 0001193125-14-425233 — 3.01
- 2014-11-13 0001193125-14-411303 — 4.01, 9.01
- 2014-10-23 0001104659-14-073164 — 2.02, 9.01
- 2014-09-04 0001193125-14-331214 — 4.02, 9.01
- 2014-08-18 0001193125-14-313346 — 3.01, 9.01
- 2014-07-24 0001104659-14-053065 — 2.02, 9.01
- 2014-06-05 0001193125-14-226177 — 3.01, 9.01
- 2014-05-22 0001193125-14-208777 — 8.01, 9.01
- 2014-04-24 0001104659-14-029650 — 2.02, 9.01
- 2014-01-23 0001104659-14-003619 — 2.02, 9.01
- 2013-10-24 0001104659-13-077404 — 2.02, 9.01
- 2013-09-09 0001193125-13-361441 — 5.02, 5.07, 8.01, 9.01
- 2013-09-06 0001193125-13-359930 — 5.02, 9.01
- 2013-08-02 0001193125-13-317343 — 5.02
- 2013-07-25 0001104659-13-056372 — 2.02, 9.01
- 2013-06-28 0001193125-13-277394 — 5.02, 9.01
- 2013-06-20 0001193125-13-265914 — 8.01, 9.01
- 2013-04-25 0001104659-13-032570 — 2.02, 9.01
- 2013-04-17 0001193125-13-158923 — 5.02, 9.01
- 2013-03-01 0001193125-13-085804 — 2.05
- 2013-01-24 0001104659-13-004214 — 2.02, 9.01
- 2013-01-02 0001193125-13-000058 — 5.02
- 2012-10-25 0001104659-12-070966 — 2.02, 9.01
- 2012-09-11 0001193125-12-388070 — 5.02, 5.07, 8.01, 9.01
- 2012-08-22 0001193125-12-364167 — 5.02, 8.01, 9.01
- 2012-07-26 0001104659-12-051084 — 2.02, 9.01
- 2012-06-08 0001193125-12-264132 — 2.05, 9.01 — amendment, the index does not say of what
- 2012-04-26 0001193125-12-183657 — 5.02, 9.01
- 2012-04-26 0001104659-12-028470 — 2.02, 2.05, 9.01
- 2012-03-15 0001193125-12-115954 — 5.02, 9.01
- 2012-01-26 0001104659-12-004014 — 2.02, 9.01
- 2012-01-04 0001193125-12-002212 — 1.01, 2.03, 9.01
- 2011-10-27 0001104659-11-058150 — 2.02, 9.01
- 2011-09-12 0001193125-11-245931 — 5.07
- 2011-07-28 0001193125-11-200929 — 5.02, 9.01
- 2011-07-28 0001193125-11-199704 — 2.02, 9.01
- 2011-04-28 0001193125-11-112669 — 2.02, 9.01
- 2011-03-24 0001193125-11-076483 — 5.02, 9.01
- 2011-01-27 0001032975-11-000003 — 9.01
- 2010-10-28 0001032975-10-000032 — 9.01
- 2010-09-13 0001032975-10-000022 — 5.07
- 2010-07-29 0001032975-10-000010 — 2.02, 9.01
- 2010-06-10 0001193125-10-136877 — 5.02, 9.01
- 2010-05-03 0001193125-10-104337 — 5.02
- 2010-04-29 0001032975-10-000008 — 2.02, 9.01
- 2010-02-19 0001032975-10-000006 — 9.01 — amendment of 0001193125-09-252416
- 2010-01-21 0001032975-10-000002 — 2.02, 9.01
- 2009-12-14 0001193125-09-252416 — 2.01, 9.01
- 2009-11-17 0001032975-09-000023 — 1.01
- 2009-10-22 0001032975-09-000018 — 9.01
- 2009-09-22 0001193125-09-195545 — 5.02, 9.01
- 2009-09-03 0001032975-09-000013 — 8.01
- 2009-07-23 0001140361-09-016802 — 2.02, 9.01
- 2009-06-01 0001193125-09-122550 — 5.02
- 2009-04-23 0001193125-09-085054 — 2.02, 9.01
- 2009-04-02 0001193125-09-071272 — 5.02, 9.01
- 2009-01-20 0001193125-09-008454 — 2.05 — amendment of 0001193125-09-002609
- 2009-01-20 0001193125-09-007902 — 2.02, 9.01
- 2009-01-07 0001193125-09-002609 — 2.05, 9.01
- 2009-01-07 0001193125-09-002370 — 5.02, 9.01
- 2008-12-09 0001193125-08-250543 — 5.02, 9.01
- 2008-10-21 0001193125-08-213212 — 2.02, 9.01
- 2008-07-22 0001193125-08-154721 — 2.02, 9.01
- 2008-06-24 0001193125-08-139163 — 5.03, 9.01
- 2008-05-13 0001193125-08-113263 — 5.02, 9.01
- 2008-04-22 0001193125-08-086176 — 2.02, 9.01

## late-filing notifications on or before 2017-05-26

- 2015-06-02 0001032975-15-000020 — NT 10-K, for the period ended 2015-03-31
- 2014-11-06 0001193125-14-401306 — NT 10-Q, for the period ended 2014-09-30
- 2014-07-24 0001193125-14-277575 — NT 10-Q, for the period ended 2014-06-30
- 2014-05-22 0001193125-14-208712 — NT 10-K, for the period ended 2014-03-31
- 2009-08-06 0001032975-09-000006 — NT 10-Q, for the period ended 2009-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001032975-17-000012:8k_2_02:1]
EX-99.1
2
exhibit991q4fy17.htm
EXHIBIT 99.1

[0001032975-17-000012:8k_2_02:2]
Exhibit

[0001032975-17-000012:8k_2_02:3]
Exhibit 99.1

[0001032975-17-000012:8k_2_02:4]
Editorial Contacts:

[0001032975-17-000012:8k_2_02:5]
Ben Lu, Vice President, Investor Relations - USA (510) 713-5568

[0001032975-17-000012:8k_2_02:6]
Krista Todd, Vice President, External Communications - USA (510) 713-5834

[0001032975-17-000012:8k_2_02:7]
Ben Starkie, Corporate Communications - Europe +41 (0) 79-292-3499

[0001032975-17-000012:8k_2_02:8]
Logitech Delivers Highest Retail Sales Growth in Six Years;

[0001032975-17-000012:8k_2_02:9]
Profit Hits Nine-Year High

[0001032975-17-000012:8k_2_02:10]
FY 2017 Retail Sales Grow 14%; Non-GAAP Operating Income Grows 33%

[0001032975-17-000012:8k_2_02:11]
NEWARK, Calif. - Apr. 25, 2017 and LAUSANNE, Switzerland, Apr. 26, 2017 - Logitech International (SIX: LOGN) (Nasdaq: LOGI) today announced financial results for the fourth quarter and full year of Fiscal Year 2017.

[0001032975-17-000012:8k_2_02:12]
Q4 closed a strong fiscal year with sales for the quarter reaching $496 million. Q4 retail sales grew 17 percent in constant currency, GAAP operating income more than doubled to $22 million and non-GAAP operating income grew 61 percent to $36 million.

[0001032975-17-000012:8k_2_02:13]
For the full Fiscal Year 2017, ended March 31, 2017:

[0001032975-17-000012:8k_2_02:14]
| • | Retail sales grew 14 percent in constant currency, the highest annual retail sales growth in six years. Retail sales grew 13 percent in USD; also a six-year high. |

[0001032975-17-000012:8k_2_02:15]
| • | Sales were $2.21 billion, up 9 percent in USD compared to the prior year, which still included OEM sales, the business the Company exited in Q3 of the prior fiscal year. |

[0001032975-17-000012:8k_2_02:16]
| • | GAAP operating income grew 53 percent to $197 million - the highest in nine years - compared to $129 million a year ago. GAAP earnings per share (EPS) grew 51 percent to $1.16, compared to $0.77 a year ago. |

[0001032975-17-000012:8k_2_02:17]
| • | Non-GAAP operating income grew 33 percent to $238 million - also the highest in nine years - compared to $179 million a year ago. Non-GAAP EPS grew 35 percent to $1.32, compared to $0.98 a year ago. |

[0001032975-17-000012:8k_2_02:18]
| • | Cash flow from operations grew 52 percent to $279 million, the highest level in seven years. |

[0001032975-17-000012:8k_2_02:19]
Bracken Darrell, Logitech president and chief executive officer, said, “Our FY 2017 performance demonstrates the strength of our strategy. For the fourth consecutive year, we accelerated growth in retail sales. We grew across almost all our product categories and in all our regions. Many categories - Video Collaboration, Mobile Speakers, Gaming, and Smart Home - grew double digits, and PC Peripherals saw solid growth too. And we’re just getting started. I’m excited by our pipeline of innovative

[0001032975-17-000012:8k_2_02:20]
products and the amazing world of opportunities unfolding in front of us.”

[0001032975-17-000012:8k_2_02:21]
Vincent Pilette, Logitech CFO, said, “This is a watershed year for Logitech. We improved our financial fundamentals, delivering our highest gross margin in Company history while growing the business by 14%. That, combined with our continued investment in growth initiatives, gives Logitech a strong and exciting platform for the future.”

[0001032975-17-000012:8k_2_02:22]
Outlook

[0001032975-17-000012:8k_2_02:23]
Logitech confirmed its Fiscal Year 2018 outlook of high single-digit retail sales growth in constant currency and $250 to $260 million in non-GAAP operating income.

[0001032975-17-000012:8k_2_02:24]
Prepared Remarks Available Online

[0001032975-17-000012:8k_2_02:25]
Logitech has made its prepared written remarks for the financial results teleconference available online on the Logitech corporate website at http://ir.logitech.com.

[0001032975-17-000012:8k_2_02:26]
Financial Results Teleconference and Webcast

[0001032975-17-000012:8k_2_02:27]
Logitech will hold a financial results teleconference to discuss the results for Q4 and the full FY 2017 on Weds., April 26, 2017 at 8:30 a.m. Eastern Daylight Time and 2:30 p.m. Central European Summer Time. A live webcast of the call will be available on the Logitech corporate website at http://ir.logitech.com.

[0001032975-17-000012:8k_2_02:28]
Continued Operations

[0001032975-17-000012:8k_2_02:29]
Logitech separated its Lifesize division from the Company on Dec. 28, 2015. Since then, the results of Lifesize have not been included in our financial statements. Except as otherwise noted, all of the results reported in this press release as well as comparisons between periods are focused on results from continuing operations and do not address the performance of Lifesize, which is reported in the Company’s financial statements under discontinued operations or total Logitech including discontinued operations for all the periods prior to the disposition of Lifesize. For more information on the impact of the Lifesize separation on Logitech’s historical results, please refer to the Financial Reporting section of Logitech’s Financial History, available on the Logitech corporate website at http://ir.logitech.com.

[0001032975-17-000012:8k_2_02:30]
Use of Non-GAAP Financial Information and Constant Currency

[0001032975-17-000012:8k_2_02:31]
To facilitate comparisons to Logitech’s historical results, Logitech has included non-GAAP adjusted measures, which exclude share-based compensation expense, amortization of intangible assets, purchase accounting effect on inventory, acquisition-related costs, change in fair value of contingent consideration for business acquisition, restructuring charges (credits), gain (loss) on equity-method investment, investigation and related expenses, non-GAAP income tax adjustment, and other items detailed under “Supplemental Financial Information” after the tables below. Logitech also presents percentage sales growth in constant currency to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales. Logitech believes this information, used together with the GAAP

[0001032975-17-000012:8k_2_02:32]
financial information, will help investors to evaluate its current period performance and trends in its business. With respect to the Company’s outlook for non-GAAP operating income, most of these excluded amounts pertain to events that have not yet occurred and are not currently possible to estimate with a reasonable degree of accuracy. Therefore, no reconciliation to the GAAP amounts has been provided for Fiscal Year 2018.

[0001032975-17-000012:8k_2_02:33]
About Logitech

[0001032975-17-000012:8k_2_02:34]
Logitech designs products that have an everyday place in people's lives, connecting them to the digital experiences they care about. More than 35 years ago, Logitech started connecting people through computers, and now it’s a multi-brand company designing products that bring people together through music, gaming, video and computing. Brands of Logitech include Jaybird, Logitech G and Ultimate Ears. Founded in 1981, and headquartered in Lausanne, Switzerland, Logitech International is a Swiss public company listed on the SIX Swiss Exchange (LOGN) and on the Nasdaq Global Select Market (LOGI). Find Logitech at www.logitech.com, the company blog or @Logitech.

[0001032975-17-000012:8k_2_02:35]
# # #

[0001032975-17-000012:8k_2_02:36]
Note that unless noted otherwise, comparisons are year over year.

[0001032975-17-000012:8k_2_02:37]
2017 Logitech, Logicool, Logi and other Logitech marks are owned by Logitech and may be registered. All other trademarks are the property of their respective owners. For more information about Logitech and its products, visit the company’s website at www.logitech.com.

[0001032975-17-000012:8k_2_02:38]
(LOGIIR)

[0001032975-17-000012:8k_2_02:39]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  | Fiscal Years Ended |
|  |  | March 31, |  | March 31, |
| GAAP CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Net sales |  | $ | 496,165 |  |  | $ | 430,841 |  |  | $ | 2,207,040 |  |  | $ | 2,018,100 |  |
| Cost of goods sold |  | 311,303 |  |  | 288,741 |  |  | 1,395,211 |  |  | 1,337,053 |  |
| Amortization of intangible assets and purchase accounting effect on inventory |  | 1,470 |  |  | — |  |  | 6,175 |  |  | — |  |
| Gross profit |  | 183,392 |  |  | 142,100 |  |  | 805,654 |  |  | 681,047 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Marketing and selling |  | 99,941 |  |  | 77,091 |  |  | 379,641 |  |  | 319,015 |  |
| Research and development |  | 33,658 |  |  | 27,287 |  |  | 130,525 |  |  | 113,176 |  |
| General and administrative |  | 24,683 |  |  | 23,046 |  |  | 100,270 |  |  | 101,012 |  |
| Amortization of intangible assets and acquisition-related costs |  | 1,279 |  |  | 537 |  |  | 5,814 |  |  | 984 |  |
| Change in fair value of contingent consideration for business acquisition |  | 1,833 |  |  | — |  |  | (8,092 | ) |  | — |  |
| Restructuring charges, net |  | 67 |  |  | 3,784 |  |  | 23 |  |  | 17,802 |  |
| Total operating expenses |  | 161,461 |  |  | 131,745 |  |  | 608,181 |  |  | 551,989 |  |
| Operating income |  | 21,931 |  |  | 10,355 |  |  | 197,473 |  |  | 129,058 |  |
| Interest income, net |  | 1,189 |  |  | 241 |  |  | 1,452 |  |  | 790 |  |
| Other income, net |  | 734 |  |  | 2,518 |  |  | 1,677 |  |  | 1,624 |  |
| Income before income taxes |  | 23,854 |  |  | 13,114 |  |  | 200,602 |  |  | 131,472 |  |
| Provision for (benefit from) income taxes |  | (1,184 | ) |  | (3,896 | ) |  | 9,113 |  |  | 3,110 |  |
| Net income from continuing operations |  | 25,038 |  |  | 17,010 |  |  | 191,489 |  |  | 128,362 |  |
| Gain (loss) from discontinued operations, net of income taxes |  | — |  |  | 11,687 |  |  | — |  |  | (9,045 | ) |
| Net income |  | $ | 25,038 |  |  | $ | 28,697 |  |  | $ | 191,489 |  |  | $ | 119,317 |  |
| Net income (loss) per share - basic: |  |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.15 |  |  | $ | 0.10 |  |  | $ | 1.18 |  |  | $ | 0.79 |  |
| Discontinued operations |  | — |  |  | 0.08 |  |  | — |  |  | (0.06 | ) |
| Net income per share - basic |  | $ | 0.15 |  |  | $ | 0.18 |  |  | $ | 1.18 |  |  | $ | 0.73 |  |
| Net income (loss) per share - diluted: |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.15 |  |  | $ | 0.10 |  |  | $ | 1.16 |  |  | $ | 0.77 |  |
| Discontinued operations |  | — |  |  | 0.07 |  |  | — |  |  | (0.05 | ) |
| Net income per share - diluted |  | $ | 0.15 |  |  | $ | 0.17 |  |  | $ | 1.16 |  |  | $ | 0.72 |  |
| Weighted average shares used to compute net income (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | 162,023 |  |  | 162,671 |  |  | 162,058 |  |  | 163,296 |  |
| Diluted |  | 166,526 |  |  | 165,365 |  |  | 165,540 |  |  | 165,792 |  |
| Cash dividend per share |  | $ | — |  |  | $ | — |  |  | $ | 0.57 |  |  | $ | 0.53 |  |

[0001032975-17-000012:8k_2_02:40]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |
| PRELIMINARY RESULTS |
| (In thousands) - unaudited |  |  |  |  |
|  |  | March 31, |  | March 31, |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  | 2017 |  | 2016 |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 547,533 |  |  | $ | 519,195 |  |
| Accounts receivable, net |  | 174,854 |  |  | 142,778 |  |
| Inventories |  | 253,401 |  |  | 228,786 |  |
| Other current assets |  | 41,732 |  |  | 35,488 |  |
| Total current assets |  | 1,017,520 |  |  | 926,247 |  |
| Non-current assets: |  |  |  |  |  |  |
| Property, plant and equipment, net |  | 85,408 |  |  | 92,860 |  |
| Goodwill |  | 249,741 |  |  | 218,224 |  |
| Other intangible assets, net |  | 47,564 |  |  | — |  |
| Other assets |  | 88,119 |  |  | 86,816 |  |
| Total assets |  | $ | 1,488,352 |  |  | $ | 1,324,147 |  |
| Current liabilities: |  |  |  |  |  |  |
| Accounts payable |  | $ | 274,805 |  |  | $ | 241,166 |  |
| Accrued and other current liabilities |  | 236,432 |  |  | 173,764 |  |
| Total current liabilities |  | 511,237 |  |  | 414,930 |  |
| Non-current liabilities: |  |  |  |  |  |  |
| Income taxes payable |  | 51,797 |  |  | 59,734 |  |
| Other non-current liabilities |  | 83,691 |  |  | 89,535 |  |
| Total liabilities |  | 646,725 |  |  | 564,199 |  |
| Shareholders' equity: |  |  |  |  |
| Registered shares, CHF 0.25 par value: |  | 30,148 |  |  | 30,148 |  |
| Issued and authorized shares—173,106 at March 31, 2017 and 2016 |  |  |  |  |
| Conditionally authorized shares—50,000 at March 31, 2017 and 2016 |  |  |  |  |
| Additional paid-in capital |  | 26,596 |  |  | 6,616 |  |
| Less shares in treasury, at cost—10,727 at March 31, 2017 and 10,697 at March 31, 2016 |  | (174,037 | ) |  | (128,407 | ) |
| Retained earnings |  | 1,059,723 |  |  | 963,576 |  |
| Accumulated other comprehensive loss |  | (100,803 | ) |  | (111,985 | ) |
| Total shareholders' equity |  | 841,627 |  |  | 759,948 |  |
| Total liabilities and shareholders' equity |  | $ | 1,488,352 |  |  | $ | 1,324,147 |  |

[0001032975-17-000012:8k_2_02:41]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  | Fiscal Years Ended |
|  |  | March 31, |  | March 31, |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS * |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 25,038 |  |  | $ | 28,697 |  |  | $ | 191,489 |  |  | $ | 119,317 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |
| Depreciation |  | 8,642 |  |  | 14,224 |  |  | 41,121 |  |  | 51,108 |  |
| Amortization of intangible assets |  | 2,749 |  |  | 349 |  |  | 9,367 |  |  | 1,885 |  |
| Share-based compensation expense |  | 9,536 |  |  | 7,476 |  |  | 35,890 |  |  | 27,351 |  |
| Gain on equity method investment |  | (22 | ) |  | (645 | ) |  | (569 | ) |  | (469 | ) |
| Loss on disposal of property, plant and equipment |  | 107 |  |  | — |  |  | 107 |  |  | — |  |
| Net gain on divestiture of discontinued operations |  | — |  |  | (13,684 | ) |  | — |  |  | (13,684 | ) |
| Excess tax benefits from share-based compensation |  | (3,304 | ) |  | — |  |  | (9,661 | ) |  | (2,084 | ) |
| Deferred income taxes |  | (1,924 | ) |  | 3,690 |  |  | (2,397 | ) |  | 6,604 |  |
| Change in fair value of contingent consideration for business acquisition |  | 1,833 |  |  | — |  |  | (8,092 | ) |  | — |  |
| Changes in assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | 103,116 |  |  | 141,327 |  |  | (36,298 | ) |  | 25,513 |  |
| Inventories |  | (234 | ) |  | 13,900 |  |  | (15,428 | ) |  | 31,966 |  |
| Other assets |  | 1,037 |  |  | 7,354 |  |  | (5,309 | ) |  | (1,975 | ) |
| Accounts payable |  | (84,636 | ) |  | (126,867 | ) |  | 24,459 |  |  | (58,104 | ) |
| Accrued and other liabilities |  | (17,500 | ) |  | (43,561 | ) |  | 54,049 |  |  | (4,317 | ) |
| Net cash provided by operating activities |  | 44,438 |  |  | 32,260 |  |  | 278,728 |  |  | 183,111 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  | (8,432 | ) |  | (6,172 | ) |  | (31,804 | ) |  | (56,615 | ) |
| Investment in privately held companies |  | (320 | ) |  | (320 | ) |  | (960 | ) |  | (2,419 | ) |
| Payments for divestiture of discontinued operations, net of cash sold |  | — |  |  | (1,395 | ) |  | — |  |  | (1,395 | ) |
| Changes in restricted cash |  | — |  |  | (715 | ) |  | 715 |  |  | (715 | ) |
| Acquisitions, net of cash acquired |  | — |  |  | — |  |  | (66,987 | ) |  | — |  |
| Purchases of trading investments |  | (1,184 | ) |  | (5,224 | ) |  | (7,052 | ) |  | (9,619 | ) |
| Proceeds from sales of trading investments |  | 1,212 |  |  | 5,405 |  |  | 7,124 |  |  | 10,073 |  |
| Net cash used in investing activities |  | (8,724 | ) |  | (8,421 | ) |  | (98,964 | ) |  | (60,690 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |
| Payment of cash dividends |  | — |  |  | — |  |  | (93,093 | ) |  | (85,915 | ) |
| Purchases of treasury shares |  | (20,022 | ) |  | (21,556 | ) |  | (83,786 | ) |  | (70,358 | ) |
| Proceeds from sales of shares upon exercise of options and purchase rights |  | 19,219 |  |  | 7,205 |  |  | 39,574 |  |  | 19,767 |  |
| Tax withholdings related to net share settlements of restricted stock units |  | (5,358 | ) |  | (1,890 | ) |  | (18,412 | ) |  | (7,247 | ) |
| Excess tax benefits from share-based compensation |  | 3,304 |  |  | — |  |  | 9,661 |  |  | 2,084 |  |
| Net cash used in financing activities |  | (2,857 | ) |  | (16,241 | ) |  | (146,056 | ) |  | (141,669 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  | 1,098 |  |  | 2,610 |  |  | (5,370 | ) |  | 1,405 |  |
| Net increase (decrease) in cash and cash equivalents |  | 33,955 |  |  | 10,208 |  |  | 28,338 |  |  | (17,843 | ) |
| Cash and cash equivalents at beginning of period |  | 513,578 |  |  | 508,987 |  |  | 519,195 |  |  | 537,038 |  |
| Cash and cash equivalents at end of period |  | $ | 547,533 |  |  | $ | 519,195 |  |  | $ | 547,533 |  |  | $ | 519,195 |  |
| *Statements of consolidated cash flows include discontinued operations for the three months and the year ended March 31, 2016. |

[0001032975-17-000012:8k_2_02:42]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |  |  |
| NET SALES |  | Three Months Ended |  | Fiscal Years Ended |
|  |  | March 31, |  | March 31, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2017 |  | 2016 |  | Change |  | 2017 |  | 2016 |  | Change |
| Net sales by channel: |  |  |  |  |  |  |  |  |  |  |  |  |
| Retail |  | $ | 496,165 |  |  | $ | 430,841 |  |  | 15 | % |  | $ | 2,207,040 |  |  | $ | 1,947,059 |  |  | 13 | % |
| OEM |  | — |  |  | — |  |  | NM |  |  | — |  |  | 71,041 |  |  | (100 | ) |
| Total net sales |  | $ | 496,165 |  |  | $ | 430,841 |  |  | 15 |  |  | $ | 2,207,040 |  |  | $ | 2,018,100 |  |  | 9 |  |
| Net retail sales by product category: |  |  |  |  |  |  |  |  |  |  |  |  |
| Mobile Speakers |  | $ | 37,983 |  |  | $ | 23,543 |  |  | 61 | % |  | $ | 299,029 |  |  | $ | 229,718 |  |  | 30 | % |
| Audio-PC & Wearables |  | 59,191 |  |  | 46,672 |  |  | 27 |  |  | 245,249 |  |  | 196,013 |  |  | 25 |  |
| Gaming |  | 69,006 |  |  | 56,102 |  |  | 23 |  |  | 311,880 |  |  | 245,101 |  |  | 27 |  |
| Video Collaboration |  | 37,091 |  |  | 21,862 |  |  | 70 |  |  | 125,389 |  |  | 89,322 |  |  | 40 |  |
| Home Control |  | 15,216 |  |  | 10,527 |  |  | 45 |  |  | 65,132 |  |  | 59,075 |  |  | 10 |  |
| Pointing Devices |  | 115,912 |  |  | 111,179 |  |  | 4 |  |  | 498,161 |  |  | 492,543 |  |  | 1 |  |
| Keyboards & Combos |  | 118,225 |  |  | 105,732 |  |  | 12 |  |  | 478,049 |  |  | 430,190 |  |  | 11 |  |
| Tablet & Other Accessories |  | 16,963 |  |  | 30,664 |  |  | (45 | ) |  | 76,314 |  |  | 103,886 |  |  | (27 | ) |
| PC Webcams |  | 26,470 |  |  | 23,952 |  |  | 11 |  |  | 106,542 |  |  | 98,641 |  |  | 8 |  |
| Other (1) |  | 108 |  |  | 608 |  |  | (82 | ) |  | 1,295 |  |  | 2,570 |  |  | (50 | ) |
| Total net retail sales |  | $ | 496,165 |  |  | $ | 430,841 |  |  | 15 |  |  | $ | 2,207,040 |  |  | $ | 1,947,059 |  |  | 13 |  |
| __________________ |  |  |  |  |  |  |  |  |  |  |  |  |

[0001032975-17-000012:8k_2_02:43]
(1) Other category includes products that we currently intend to transition out of, or have already transitioned out of, because they are no longer strategic to our business.

[0001032975-17-000012:8k_2_02:44]
NM=Not Meaningful.

[0001032975-17-000012:8k_2_02:45]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS |
| (In thousands, except per share amounts) - Unaudited |  |  |  |  |  |  |  |  |
| GAAP TO NON GAAP RECONCILIATION (A) |  | Three Months Ended |  | Fiscal Years Ended |
|  |  | March 31, |  | March 31, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Gross profit - GAAP |  | $ | 183,392 |  |  | $ | 142,100 |  |  | $ | 805,654 |  |  | $ | 681,047 |  |
| Share-based compensation expense |  | 733 |  |  | 692 |  |  | 2,663 |  |  | 2,340 |  |
| Amortization of intangible assets and purchase accounting effect on inventory |  | 1,470 |  |  | — |  |  | 6,175 |  |  | — |  |
| Gross profit - Non-GAAP |  | $ | 185,595 |  |  | $ | 142,792 |  |  | $ | 814,492 |  |  | $ | 683,387 |  |
| Gross margin - GAAP |  | 37.0 | % |  | 33.0 | % |  | 36.5 | % |  | 33.7 | % |
| Gross margin - Non-GAAP |  | 37.4 | % |  | 33.1 | % |  | 36.9 | % |  | 33.9 | % |
| Operating expenses - GAAP |  | $ | 161,461 |  |  | $ | 131,745 |  |  | $ | 608,181 |  |  | $ | 551,989 |  |
| Less: Share-based compensation expense |  | 8,803 |  |  | 7,036 |  |  | 33,227 |  |  | 24,672 |  |
| Less: Amortization of intangible assets and acquisition-related costs |  | 1,279 |  |  | 537 |  |  | 5,814 |  |  | 984 |  |
| Less: Change in fair value of contingent consideration for business acquisition |  | 1,833 |  |  | — |  |  | (8,092 | ) |  | — |  |
| Less: Restructuring charges, net |  | 67 |  |  | 3,784 |  |  | 23 |  |  | 17,802 |  |
| Less: Investigation and related expenses |  | — |  |  | 19 |  |  | 612 |  |  | 4,140 |  |
| Operating expenses - Non-GAAP |  | $ | 149,479 |  |  | $ | 120,369 |  |  | $ | 576,597 |  |  | $ | 504,391 |  |
| % of net sales - GAAP |  | 32.5 | % |  | 30.6 | % |  | 27.6 | % |  | 27.4 | % |
| % of net sales - Non - GAAP |  | 30.1 | % |  | 27.9 | % |  | 26.1 | % |  | 25.0 | % |
| Operating income - GAAP |  | $ | 21,931 |  |  | $ | 10,355 |  |  | $ | 197,473 |  |  | $ | 129,058 |  |
| Share-based compensation expense |  | 9,536 |  |  | 7,728 |  |  | 35,890 |  |  | 27,012 |  |
| Amortization of intangible assets |  | 2,749 |  |  | 1 |  |  | 9,367 |  |  | 448 |  |
| Purchase accounting effect on inventory |  | — |  |  | — |  |  | 1,160 |  |  | — |  |
| Acquisition-related costs |  | — |  |  | 536 |  |  | 1,462 |  |  | 536 |  |
| Change in fair value of contingent consideration for business acquisition |  | 1,833 |  |  | — |  |  | (8,092 | ) |  | — |  |
| Restructuring charges, net |  | 67 |  |  | 3,784 |  |  | 23 |  |  | 17,802 |  |
| Investigation and related expenses |  | — |  |  | 19 |  |  | 612 |  |  | 4,140 |  |
| Operating income - Non - GAAP |  | $ | 36,116 |  |  | $ | 22,423 |  |  | $ | 237,895 |  |  | $ | 178,996 |  |
| % of net sales - GAAP |  | 4.4 | % |  | 2.4 | % |  | 8.9 | % |  | 6.4 | % |
| % of net sales - Non - GAAP |  | 7.3 | % |  | 5.2 | % |  | 10.8 | % |  | 8.9 | % |
| Net income from continuing operations - GAAP |  | $ | 25,038 |  |  | $ | 17,010 |  |  | $ | 191,489 |  |  | $ | 128,362 |  |
| Share-based compensation expense |  | 9,536 |  |  | 7,728 |  |  | 35,890 |  |  | 27,012 |  |
| Amortization of intangible assets |  | 2,749 |  |  | 1 |  |  | 9,367 |  |  | 448 |  |
| Purchase accounting effect on inventory |  | — |  |  | — |  |  | 1,160 |  |  | — |  |
| Acquisition-related costs |  | — |  |  | 536 |  |  | 1,462 |  |  | 536 |  |
| Change in fair value of contingent consideration for business acquisition |  | 1,833 |  |  | — |  |  | (8,092 | ) |  | — |  |
| Restructuring charges, net |  | 67 |  |  | 3,784 |  |  | 23 |  |  | 17,802 |  |
| Investigation and related expenses |  | — |  |  | 19 |  |  | 612 |  |  | 4,140 |  |
| Loss (gain) on equity-method investment |  | (22 | ) |  | (645 | ) |  | (569 | ) |  | (469 | ) |
| Non-GAAP income tax adjustment |  | (4,226 | ) |  | (5,452 | ) |  | (12,875 | ) |  | (15,413 | ) |
| Net income from continuing operations - Non - GAAP |  | $ | 34,975 |  |  | $ | 22,981 |  |  | $ | 218,467 |  |  | $ | 162,418 |  |
| Net income from continuing operations per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  | $ | 0.15 |  |  | $ | 0.10 |  |  | $ | 1.16 |  |  | $ | 0.77 |  |
| Diluted - Non - GAAP |  | $ | 0.21 |  |  | $ | 0.14 |  |  | $ | 1.32 |  |  | $ | 0.98 |  |
| Shares used to compute net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP and Non - GAAP |  | 166,526 |  |  | 165,365 |  |  | 165,540 |  |  | 165,792 |  |

[0001032975-17-000012:8k_2_02:46]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
| SHARE-BASED COMPENSATION EXPENSE |  | Three Months Ended |  | Fiscal Years Ended |
|  |  | March 31, |  | March 31, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Share-based Compensation Expense |  |  |  |  |  |  |  |  |
| Cost of goods sold |  | $ | 733 |  |  | $ | 692 |  |  | $ | 2,663 |  |  | $ | 2,340 |  |
| Marketing and selling |  | 4,036 |  |  | 2,728 |  |  | 14,723 |  |  | 9,273 |  |
| Research and development |  | 1,193 |  |  | 872 |  |  | 4,200 |  |  | 3,046 |  |
| General and administrative |  | 3,574 |  |  | 3,436 |  |  | 14,304 |  |  | 12,353 |  |
| Restructuring |  | — |  |  | — |  |  | — |  |  | 7 |  |
| Total share-based compensation expense |  | 9,536 |  |  | 7,728 |  |  | 35,890 |  |  | 27,019 |  |
| Income tax benefit |  | (2,444 | ) |  | (2,354 | ) |  | (8,536 | ) |  | (6,297 | ) |
| Total share-based compensation expense, net of income tax |  | $ | 7,092 |  |  | $ | 5,374 |  |  | $ | 27,354 |  |  | $ | 20,722 |  |

[0001032975-17-000012:8k_2_02:47]
Note: These preliminary results for the three months and fiscal year ended March 31, 2017 are subject to adjustments, including subsequent events that may occur through the date of filing our Annual Report on Form 10-K.

[0001032975-17-000012:8k_2_02:48]
(A) Non-GAAP Financial Measures

[0001032975-17-000012:8k_2_02:49]
To supplement our condensed consolidated financial results prepared in accordance with GAAP, we use a number of financial measures, both GAAP and non-GAAP, in analyzing and assessing our overall business performance, for making operating decisions and for forecasting and planning future periods. We consider the use of non-GAAP financial measures helpful in assessing our current financial performance, ongoing operations and prospects for the future as well as understanding financial and business trends relating to our financial condition and results of operations.

[0001032975-17-000012:8k_2_02:50]
While we use non-GAAP financial measures as a tool to enhance our understanding of certain aspects of our financial performance and to provide incremental insight into the underlying factors and trends affecting both our performance and our cash-generating potential, we do not consider these measures to be a substitute for, or superior to, the information provided by GAAP financial measures. Consistent with this approach, we believe that disclosing non-GAAP financial measures to the readers of our financial statements provides useful supplemental data that, while not a substitute for GAAP financial measures, can offer insight in the review of our financial and operational performance and enables investors to more fully understand trends in our current and future performance. In assessing our business during the quarter and year ended March 31, 2017, we excluded items in the following general categories, each of which are described below:

[0001032975-17-000012:8k_2_02:51]
Share-based compensation expenses. We believe that providing non-GAAP measures excluding share-based compensation expense, in addition to the GAAP measures, allows for a more transparent comparison of our financial results from period to period. We prepare and maintain our budgets and forecasts for future periods on a basis consistent with this non-GAAP financial measure. Further, companies use a variety of types of equity awards as well as a variety of methodologies, assumptions and estimates to determine share-based compensation expense. We believe that excluding share-based compensation expense enhances our ability and the ability of investors to understand the impact of non-cash share-based compensation on our operating results and to compare our results against the results of other companies.

[0001032975-17-000012:8k_2_02:52]
Amortization of intangible assets. We incur intangible asset amortization expense, primarily in connection with our acquisitions of various businesses and technologies. The amortization of purchased intangibles varies depending on the level of acquisition activity. We exclude these various charges in budgeting, planning and forecasting future periods and we believe that providing the non-GAAP measures excluding these various non-cash charges, as well as the GAAP measures, provides additional insight when comparing our operating expenses and financial results from period to period.

[0001032975-17-000012:8k_2_02:53]
Purchase accounting effect on inventory. Business combination accounting principles require us to measure acquired inventory at fair value. The fair value of inventory reflects the acquired company’s cost of manufacturing plus a portion of the expected profit margin. The non-GAAP adjustment excludes the expected profit margin component that is

[0001032975-17-000012:8k_2_02:54]
recorded under business combination accounting principles associated with our business acquisitions. We believe the adjustment is useful to investors because such charges are not reflective of our ongoing operations.

[0001032975-17-000012:8k_2_02:55]
Acquisition-related costs and change in fair value of contingent consideration for business acquisition.  We incurred expenses and credits in connection with our acquisitions which we generally would not have otherwise incurred in the periods presented as a part of our continuing operations. Acquisition related costs include all incremental expenses incurred to effect a business combination. Fair value of contingent consideration is associated with our estimates of the value of earn-outs in connection with certain acquisitions. We believe that providing the non-GAAP measures excluding these costs and credits, as well as the GAAP measures, assists our investors because such costs are not reflective of our ongoing operating results.

[0001032975-17-000012:8k_2_02:56]
Restructuring charges (credits). These expenses are associated with re-aligning our business strategies based on current economic conditions. We have undertaken several restructuring plans in recent years. In connection with our restructuring initiatives, we incurred restructuring charges related to employee terminations, facility closures and early cancellation of certain contracts. We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges (credits) are not reflective of our ongoing operating results in the current period.

[0001032975-17-000012:8k_2_02:57]
Gain (loss) on equity-method investment. We recognized gain (loss) related our investments in various privately-held companies, which varies depending on the operational and financial performance of the privately-held companies in which we invested. We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges are not reflective of our ongoing operations.

[0001032975-17-000012:8k_2_02:58]
Investigation and related expenses.  These expenses are forensic accounting, audit, consulting and legal fees related to the Audit Committee’s investigation and the formal investigation by and settlement with the Securities and Exchange Commission (SEC), together with accruals based on settlement with the SEC. We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges are not reflective of our ongoing operations.

[0001032975-17-000012:8k_2_02:59]
Non-GAAP income tax adjustment.  Non-GAAP income tax adjustment primarily measures the income tax effect of non-GAAP adjustments excluded above and other events; the determination of which is based upon the nature of the underlying items, the mix of income and losses in jurisdictions and the relevant tax rates in which we operate.

[0001032975-17-000012:8k_2_02:60]
Each of the non-GAAP financial measures described above, and used in this press release, should not be considered in isolation from, or as a substitute for, a measure of financial performance prepared in accordance with GAAP. Further, investors are cautioned that there are inherent limitations associated with the use of each of these non-GAAP financial measures as an analytical tool. In particular, these non-GAAP financial measures are not based on a comprehensive set of accounting rules or principles and many of the adjustments to the GAAP financial measures reflect the exclusion of items that are recurring and may be reflected in the Company’s financial results for the foreseeable future. We compensate for these limitations by providing specific information in the reconciliation included in this press release regarding the GAAP amounts excluded from the non-GAAP financial measures. In addition, as noted above, we evaluate the non-GAAP financial measures together with the most directly comparable GAAP financial information.

[0001032975-17-000012:8k_2_02:61]
Additional Supplemental Financial Information - Constant Currency

[0001032975-17-000012:8k_2_02:62]
In addition, Logitech presents percentage sales growth in constant currency to show performance unaffected by fluctuations in currency exchange rates.  Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales.
