# LOGI 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: 3 candidate headings, none whose body matches 'critical audit matter'.


## item_9a

[0001032975-17-000016:item_9a:1]
ITEM 9A.    CONTROLS AND PROCEDURES

[0001032975-17-000016:item_9a:2]
(a) Evaluation of Disclosure Controls and Procedures

[0001032975-17-000016:item_9a:3]
The Company conducted an evaluation of the effectiveness of the design and operation of its disclosure controls and procedures (as defined in Rules 13a-15(e) and 15d-15(e) under the Securities Exchange Act of 1934, as amended (the “Exchange Act”)) (“Disclosure Controls”) as of the end of the period covered by this Annual Report on Form 10-K (this “Report”) required by Exchange Act Rules 13a-15(b) or 15d-15(b). The controls evaluation was conducted under the supervision and with the participation of the Company’s management, including the Company’s Chief Executive Officer (“CEO”) and Chief Financial Officer (“CFO”). Disclosure controls and procedures are designed to reasonably assure that information required to be disclosed in our reports filed or submitted under the Exchange Act, such as this Annual Report on Form 10-K, is recorded, processed, summarized and reported within the time periods specified in the Securities and Exchange Commission's rules and forms. Disclosure controls and procedures are also designed to reasonably assure that this information is accumulated and communicated to our management, including the CEO and CFO, to allow timely decisions regarding required disclosure. Based on this evaluation, the CEO and CFO have concluded that, as of the end of the period covered by this Report, the Company’s Disclosure Controls and procedures were not effective as a result of the material weakness that existed in our internal control over financial reporting as described in Management's Report on Internal Control over Financial Reporting below.

[0001032975-17-000016:item_9a:4]
Notwithstanding the identified material weakness discussed below, management, including our CEO and CFO, believes the consolidated financial statements included in this Annual Report on Form 10-K fairly represent in all material respects our financial condition, results of operations and cash flows at and for the periods presented in accordance with U.S. generally accepted accounting principles.

[0001032975-17-000016:item_9a:5]
(b) Management's Report on Internal Control over Financial Reporting

[0001032975-17-000016:item_9a:6]
Company management is responsible for establishing and maintaining adequate internal control over financial reporting as defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act. Under the supervision and with the participation of the Company’s management, including the CEO and CFO, the Company conducted an evaluation of the effectiveness of its internal control over financial reporting based on criteria established in the framework in Internal Control-Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission. Based on this evaluation, management concluded that our internal control over financial reporting was not effective as of March 31, 2017, due to the material weakness in our internal control over financial reporting described below. A material weakness is “a deficiency or a combination of deficiencies, in internal control over financial reporting, such that there is a reasonable possibility that a material misstatement of the registrant’s annual or interim financial statements will not be prevented or detected in a timely basis.”

[0001032975-17-000016:item_9a:7]
In connection with the Company’s sales growth strategy in EMEA, the Company expanded its use of performance-based customer programs in the region in fiscal 2016 and 2017. As a result, the allowances and accruals for customer incentive, cooperative marketing and pricing programs increased in those years. In prior periods, the Company did not have sufficient historical data on customer breakage patterns in the EMEA region to allow for a reliable estimation of future customer breakage attributable to these allowances and accruals. However, by the fourth quarter of fiscal year 2017, sufficient historical data was available to establish a model to reliably estimate the expected future customer breakage.  As of March 31, 2017, the Company did not identify that sufficient historical data existed to estimate future customer breakage and as a result, the Company did not modify the design of the control activities related to the accuracy of the allowance and accruals to respond to the change in relevant data.  Our management has concluded that this deficiency constitutes a material weakness in our internal control over financial reporting.

[0001032975-17-000016:item_9a:8]
Logitech International S.A. | Fiscal 2017 Form 10-K | 60

[0001032975-17-000016:item_9a:9]
Management concluded that the allowances and accrued liabilities relating to customer programs in the EMEA region were overstated at March 31, 2017 as future breakage was not estimated. This overstatement of allowances and accrued liabilities relating to customer programs in the EMEA region has been corrected in our consolidated financial statements included in this Annual Report on Form 10-K. While the control deficiency did not result in a misstatement of our current or previously issued consolidated financial statements, the control deficiency resulted in changes to our preliminary results of operations for the quarter and year ended March 31, 2017 furnished to the United States Securities and Exchange Commission (“SEC”) in the Current Report on Form 8-K on April 26, 2017.

[0001032975-17-000016:item_9a:10]
The Company’s internal control over financial reporting as of March 31, 2017 has been audited by KPMG LLP, an independent registered public accounting firm, as stated in their report which contains an adverse opinion on the effectiveness of our internal control over financial reporting. This report appears in this Annual Report on Form 10-K, in Item 15(a).

[0001032975-17-000016:item_9a:11]
(c) Remediation Plan

[0001032975-17-000016:item_9a:12]
In May 2017, management has begun implementing a remediation plan to address the material weakness. The remediation plan includes:

[0001032975-17-000016:item_9a:13]
| • | The development and implementation of a new estimation model of breakage related to customer incentive, cooperative marketing and pricing programs in the EMEA region; and |

[0001032975-17-000016:item_9a:14]
| • | The design and implementation of related controls over the new estimation model, which were initiated in conjunction with recording this adjustment in relation to this Annual Report on Form 10-K filing. |

[0001032975-17-000016:item_9a:15]
| • | Enhancements to the process to periodically evaluate and appropriately respond to changing business circumstances that may impact control activities, specifically in the area of the accuracy of the allowances and accruals. |

[0001032975-17-000016:item_9a:16]
Our management believes the foregoing efforts will effectively remediate the material weakness; however, the material weakness cannot be considered remediated until the control has operated for a sufficient period of time and until management has concluded, through testing of several instances, that the control is operating effectively. The Company expects to remediate this material weakness by the end of fiscal year 2018.

[0001032975-17-000016:item_9a:17]
(d) Changes in Internal Controls over Financial Reporting

[0001032975-17-000016:item_9a:18]
There were no changes in the Company’s internal control over financial reporting that occurred during the fourth quarter of fiscal year 2017 that have materially affected, or are reasonably likely to materially affect, the Company’s internal control over financial reporting  other than the material weakness noted above.

[0001032975-17-000016:item_9a:19]
(e) Limitations on the Effectiveness of Controls

[0001032975-17-000016:item_9a:20]
The Company's management, including the Chief Executive Officer and Chief Financial Officer, does not expect that the Company's disclosure controls and procedures or internal control over financial reporting will prevent all errors and all fraud. Internal control over financial reporting, no matter how well designed and operated, can provide only reasonable, not absolute, assurance that the objectives will be met. Because of the inherent limitations in internal control over financial reporting, no evaluation of controls can provide absolute assurance that all control issues and instances of fraud, if any, within the Company have been detected. These inherent limitations include the realities that judgments in decision making can be faulty and that breakdowns can occur because of simple error or mistake. Controls can also be circumvented by the individual acts of some persons, by collusion of two or more people, or by management override of the controls. The design of any system of controls is based in part on certain assumptions about the likelihood of future events, and there can be no assurance that any design will succeed in achieving its stated goals under all potential future conditions. Over time, controls may become inadequate because of changes in conditions or deterioration in the degree of compliance with policies or procedures. Because of the inherent limitations in a cost-effective control system, misstatements due to error or fraud may occur and not be detected.
