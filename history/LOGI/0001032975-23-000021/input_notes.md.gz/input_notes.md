# LOGI notes — 0001032975-23-000021


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001032975-23-000021:notes:1]
Portions of the registrant's Proxy Statement for the 2023 Annual Meeting of Shareholders are incorporated herein by reference in Part III of this Annual Report on Form 10-K to the extent stated herein.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001032975-23-000021:notes:2]
Summary of Significant Accounting Policies
Basis of Presentation

[0001032975-23-000021:notes:3]
The consolidated financial statements include the accounts of Logitech and its subsidiaries. All intercompany balances and transactions have been eliminated. The consolidated financial statements are presented in accordance with accounting principles generally accepted in the United States ("U.S. GAAP").

[0001032975-23-000021:notes:4]
Fiscal Year

[0001032975-23-000021:notes:5]
The Company's fiscal year ends on March 31. Interim quarters are generally thirteen-week periods, each ending on a Friday. For purposes of presentation, the Company has indicated its quarterly periods end on the last day of the calendar quarter.

[0001032975-23-000021:notes:6]
Reference to Sales

[0001032975-23-000021:notes:7]
References to "sales" in the Notes to the consolidated financial statements means net sales, except as otherwise specified.

[0001032975-23-000021:notes:8]
Use of Estimates

[0001032975-23-000021:notes:9]
The preparation of financial statements in conformity with U.S. GAAP requires management to make judgments, estimates and assumptions that affect the amounts reported in the consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Significant estimates and assumptions made by management involve the fair value of goodwill and intangible assets acquired from business acquisitions, contingent consideration for a business acquisition and periodic reassessment of its fair value, valuation of investment in privately held companies classified under Level 3 fair value hierarchy, pension obligations, accruals for customer incentives, cooperative marketing, and pricing programs ("Customer Programs") and related breakage when appropriate, inventory valuation, share-based compensation expense, uncertain tax positions, and valuation allowances for deferred tax assets. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ materially from those estimates.

[0001032975-23-000021:notes:10]
Risks and Uncertainties

[0001032975-23-000021:notes:11]
Impacts of Macroeconomic and Geopolitical Conditions on the Company's Business

[0001032975-23-000021:notes:12]
In fiscal year 2023, the Company's business was impacted by adverse macroeconomic and geopolitical conditions. These conditions included inflation, foreign currency fluctuations, and slowdown of economic activity around the world, in part due to rising interest rates, and lower consumer and enterprise spending. In addition, the war in Ukraine resulted in global supply chain, logistics, and inflationary challenges. The Company had no revenue in Russia and Ukraine in fiscal year 2023 as it has indefinitely ceased all sales and shipments to Russia and sales in Ukraine have also been halted due to the ongoing military operations on the Ukrainian territory.

[0001032975-23-000021:notes:13]
The global and regional economic and political conditions adversely affect demand for the Company's products. These conditions also had an impact on the Company's suppliers, contract manufacturers, logistics providers, and distributors, causing volatility in cost of materials and shipping and transportation rates, and as a result impacting the pricing of the Company's products.

[0001032975-23-000021:notes:14]
Currencies

[0001032975-23-000021:notes:15]
The functional currency of the Company's operations is primarily the U.S. Dollar. Certain operations use the Euro, Chinese Renminbi, Swiss Franc, or other local currencies as their functional currencies. The financial statements of the Company's subsidiaries whose functional currency is other than the U.S. Dollar are translated to U.S. Dollars using period-end rates of exchange for assets and liabilities and monthly average rates for sales, income and expenses. Cumulative translation gains and losses are included as a component of shareholders' equity in accumulated other comprehensive income (loss). Gains and losses arising from transactions denominated in currencies other than a subsidiary's functional currency are reported in other income (expense), net in the consolidated statements of operations.

[0001032975-23-000021:notes:16]
Revenue Recognition

[0001032975-23-000021:notes:17]
Revenue is recognized when a customer obtains control of promised goods or services in an amount that reflects the transaction price the Company expects to receive in exchange for those goods or services.

[0001032975-23-000021:notes:18]
Substantially all revenue recognized by the Company relates to the contracts with customers to sell products that allow people to connect through gaming, video, computing, music and other digital platforms. These products are hardware devices, which may include embedded software that function together, and are considered as one performance obligation. Hardware devices are generally plug and play, requiring no configuration and little or no installation. Revenue is recognized at a point in time when control of the products is transferred to the customer which generally occurs upon shipment. The Company’s sales contracts with its customers have a one year or shorter term. The Company elects not disclosing the value of unsatisfied performance obligations for contracts with an original expected duration of one year or less.

[0001032975-23-000021:notes:19]
The Company also provides post-contract customer support (“PCS”) for certain products and related software, which includes unspecified software updates and upgrades, bug fixes and maintenance. The transaction price is allocated to two performance obligations in such contracts, based on a relative standalone selling price. The transaction price allocated to PCS is recognized as revenue on a straight-line basis, which reflects the pattern of delivery of PCS, over the estimated term of the support that is between one to two years. Deferred revenue associated with remaining PCS performance obligation as of March 31, 2023 and March 31, 2022 was not material.

[0001032975-23-000021:notes:20]
The Company also recognizes revenue from subscription services that provide professional streamers with access to streaming software and tools that represent a single stand-ready performance obligation. Subscriptions are paid for at the time of or in advance of delivering the services. The proceeds received in advance from such arrangements is recognized as deferred revenue and then recognized as revenue ratably over the subscription period.

[0001032975-23-000021:notes:21]
The Company normally requires payment from customers within thirty to sixty days from the invoice date. However, terms may vary by customer type, by country and by selling season. Extended payment terms are sometimes offered to a limited number of customers during the second and third fiscal quarters. The Company generally does not modify payment terms on existing receivables. The Company's contracts with customers do not include significant financing components as the period between the satisfaction of performance obligations and timing of payment are generally within one year.

[0001032975-23-000021:notes:22]
The transaction price received by the Company from sales to its distributors, retail companies ("retailers"), and authorized resellers is calculated as selling price net of variable consideration which may include product returns and the Company’s payments for Customer Programs related to current period product revenue. The estimated impact of these programs is recorded as a reduction of transaction price or as an operating expense if the Company receives a distinct good or service from the customer and can reasonably estimate the fair value of that good or service received. Customer Programs require management to estimate the percentage of those programs which will not be claimed in the current period or will not be earned by customers, which is commonly referred to as "breakage." Breakage is estimated based on historical claim experience, the period in which customer claims are expected to be submitted, specific terms and conditions with customers and other factors. The Company accounts for breakage as part of variable consideration, subject to constraint, and records the estimated impact in the same

[0001032975-23-000021:notes:23]
period when revenue is recognized at the expected value. Assessing the period in which claims are expected to be submitted and the relevance of the historical claim experience require significant management judgment to estimate the breakage of Customer Programs in any accounting period.

[0001032975-23-000021:notes:24]
The Company enters into cooperative marketing arrangements with many of its customers and with certain indirect partners, allowing customers to receive a credit equal to a set percentage of their purchases of the Company's products, or a fixed dollar amount for various marketing and incentive programs. The objective of these arrangements is to encourage advertising and promotional events to increase sales of the Company's products.

[0001032975-23-000021:notes:25]
Customer incentive programs include consumer rebates and performance-based incentives. Consumer rebates are offered to the Company's customers and indirect partners at the Company's discretion for the primary benefit of end-users. In addition, the Company offers performance-based incentives to many of its customers and indirect partners based on predetermined performance criteria. At management's discretion, the Company also offers special pricing discounts to certain customers. Special pricing discounts are usually offered only for limited time periods or for sales of selected products to specific indirect partners.

[0001032975-23-000021:notes:26]
Cooperative marketing arrangements and customer incentive programs are considered variable consideration, which the Company estimates and records as a reduction to revenue at the time of sale based on negotiated terms, historical experiences, forecasted incentives, anticipated volume of future purchases, and inventory levels in the channel.

[0001032975-23-000021:notes:27]
The Company has agreements with certain customers that contain terms allowing price protection credits to be issued in the event of a subsequent price reduction. Management's decision to make price reductions is influenced by product life cycle stage, market acceptance of products, the competitive environment, new product introductions and other factors.

[0001032975-23-000021:notes:28]
Accruals for estimated expected future pricing actions and Customer Programs are recognized at the time of sale based on analyses of historical pricing actions by customer and by product, inventories owned by and located at customers, current customer demand, current operating conditions, and other relevant customer and product information, such as stage of product life-cycle.

[0001032975-23-000021:notes:29]
Product return rights vary by customer. Estimates of expected future product returns qualify as variable consideration and are recorded as a reduction of the transaction price of the contract at the time of sale based on an analyses of historical return trends by customer and by product, inventories owned by and located at customers, current customer demand, current operating conditions, and other relevant customer and product information. The Company assesses the estimated asset for recovery value for impairment and adjusts the value of the asset for any impairment. Return trends are influenced by product life cycle status, new product introductions, market acceptance of products, sales levels, product sell-through, the type of customer, seasonality, product quality issues, competitive pressures, operational policies and procedures, and other factors. Return rates can fluctuate over time but are sufficiently predictable to allow the Company to estimate expected future product returns.

[0001032975-23-000021:notes:30]
Typically, variable consideration does not need to be constrained as estimates are based on predictive historical data or future commitments that are planned and controlled by the Company. However, the Company continues to assess variable consideration estimates such that it is probable that a significant reversal of revenue will not occur.

[0001032975-23-000021:notes:31]
The Company regularly evaluates the adequacy of its estimates for Customer Programs and product returns. Future market conditions and product transitions may require the Company to take action to change such programs and related estimates. When the variables used to estimate these costs change, or if actual costs differ significantly from the estimates, the Company would be required to increase or reduce revenue or operating expenses to reflect the impact. During the year ended March 31, 2023, changes to these estimates related to performance obligations satisfied in prior periods were not material.

[0001032975-23-000021:notes:32]
Sales taxes and value-added taxes (“VAT”) collected from customers, if applicable, which are remitted to governmental authorities are not included in revenue, and are reflected as a liability on the consolidated balance sheets.

[0001032975-23-000021:notes:33]
Shipping and Handling Costs

[0001032975-23-000021:notes:34]
The Company's shipping and handling costs are included in the cost of goods sold in the consolidated statements of operations for all periods presented.

[0001032975-23-000021:notes:35]
Contract Balances

[0001032975-23-000021:notes:36]
The Company records accounts receivable from contracts with customers when it has an unconditional right to consideration, as accounts receivable, net on the consolidated balance sheets.

[0001032975-23-000021:notes:37]
The Company records contract liabilities when cash payments are received or due in advance of performance, primarily for implied support and subscriptions. Contract liabilities are included in accrued and other current liabilities and other non-current liabilities on the consolidated balance sheets.

[0001032975-23-000021:notes:38]
As of March 31, 2023 and 2022, the Company did not have any material contract liabilities balances or changes.

[0001032975-23-000021:notes:39]
Contract Costs

[0001032975-23-000021:notes:40]
The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that otherwise would have been recognized is one year or less. These costs are included in marketing and selling expenses in the consolidated statements of operations. As of March 31, 2023 and 2022, the Company did not have any material deferred contract costs.

[0001032975-23-000021:notes:41]
Research and Development Costs

[0001032975-23-000021:notes:42]
Costs related to research, design and development of products, which consist primarily of personnel, product design and infrastructure expenses, are charged to research and development expense as they are incurred.

[0001032975-23-000021:notes:43]
Advertising Costs

[0001032975-23-000021:notes:44]
Advertising costs are recorded as either a marketing and selling expense or a deduction from revenue as they are incurred. Advertising costs paid or reimbursed by the Company to direct or indirect customers must have an identifiable benefit and an estimable fair value in order to be classified as an operating expense. If these criteria are not met, the payment is classified as a reduction of revenue. Advertising costs recorded as marketing and selling expense are expensed as incurred. Total advertising costs including those characterized as revenue deductions during fiscal years 2023, 2022 and 2021 were $341.1 million, $628.9 million and $450.0 million, respectively, out of which $24.8 million, $267.8 million, and $168.2 million, respectively, were included as operating expense in the consolidated statements of operations.

[0001032975-23-000021:notes:45]
Cash Equivalents

[0001032975-23-000021:notes:46]
The Company classifies all highly liquid instruments purchased, such as bank time deposits, with an original maturity of three months or less at the date of purchase, to be cash equivalents. Cash equivalents are carried at cost, which approximates their fair value.

[0001032975-23-000021:notes:47]
Concentration of Credit Risk

[0001032975-23-000021:notes:48]
Financial instruments that potentially subject the Company to concentrations of credit risk consist principally of cash and cash equivalents and accounts receivable. The Company maintains cash and cash equivalents with various creditworthy financial institutions and has a policy to limit exposure with any one financial institution, but is exposed to credit risk in the event of default by financial institutions to the extent that cash balances with individual financial institutions are in excess of amounts that are insured. The Company periodically assesses the credit risk associated with these financial institutions.

[0001032975-23-000021:notes:49]
The Company sells to large distributors, retailers, and e-tailers and, as a result, maintains individually significant receivable balances with such customers.

[0001032975-23-000021:notes:50]
The Company had the following customers that individually comprised 10% or more of its gross sales:

[0001032975-23-000021:notes:51]
|  |  | Years Ended March 31, |
|  |  | 2023 |  | 2022 |  | 2021 |
| Customer A |  | 13 | % |  | 15 | % |  | 14 | % |
| Customer B |  | 19 | % |  | 17 | % |  | 13 | % |
| Customer C (1) |  | 15 | % |  | 14 | % |  | N/A(1) |

[0001032975-23-000021:notes:52]
(1) The Company's two customers merged during fiscal year 2022 and the percentages for fiscal year 2023 and 2022 reflect the gross sales to the combined company. The percentage for fiscal year 2021 is not disclosed as gross sales to each customer accounted for less than 10% of the Company's gross sales.

[0001032975-23-000021:notes:53]
The Company had the following customers that individually comprised 10% or more of its accounts receivable:

[0001032975-23-000021:notes:54]
|  |  | March 31, |
|  |  | 2023 |  | 2022 |
| Customer A |  | 12 | % |  | 15 | % |
| Customer B |  | 21 | % |  | 17 | % |
| Customer C |  | 15 | % |  | 15 | % |

[0001032975-23-000021:notes:55]
The Company manages its accounts receivable credit risk through ongoing credit evaluation of its customers' financial conditions. The Company generally does not require collateral from its customers.

[0001032975-23-000021:notes:56]
Allowances for Doubtful Accounts

[0001032975-23-000021:notes:57]
Allowances for doubtful accounts are maintained for expected credit losses resulting from the Company's customers' inability to make required payments. The allowances are based on the Company's regular assessment of various factors, including the credit-worthiness and financial condition of specific customers, historical experience with bad debts and customer deductions, receivables aging, current economic conditions, reasonable and supportable forecasts of future economic conditions, and other factors that may affect the Company's ability to collect from customers.

[0001032975-23-000021:notes:58]
Inventories

[0001032975-23-000021:notes:59]
Inventories are stated at the lower of cost and net realizable value. Costs are computed under the standard cost method, which approximates actual costs determined on the first-in, first-out basis. The Company records write-downs of inventories which are obsolete or in excess of anticipated demand or net realizable value based on a consideration of marketability and product life cycle stage, product development plans, component cost trends, historical sales and demand forecasts which consider the assumptions about future demand and market conditions. Inventory on hand which is not expected to be sold or utilized is considered excess, and the Company recognizes the write-down in cost of goods sold at the time of such determination. The write-down is determined by the excess of cost over net realizable value. Net realizable value is the estimated selling price in the ordinary course of business, less reasonably predictable costs of completion, disposal and transportation. At the time of loss recognition, new cost basis per unit and lower-cost basis for that inventory are established and subsequent changes in facts and circumstances would not result in an increase in the cost basis.

[0001032975-23-000021:notes:60]
The Company recorded liabilities arising from firm, non-cancelable, and unhedged inventory purchase commitments in excess of anticipated demand or net realizable value consistent with its valuation of excess and obsolete inventory. Such liability is included in accrued and other current liabilities on the consolidated balance sheets.

[0001032975-23-000021:notes:61]
Property, Plant and Equipment

[0001032975-23-000021:notes:62]
Property, plant and equipment are stated at cost. Additions and improvements are capitalized, and maintenance and repairs are expensed as incurred. The Company capitalizes the cost of software developed for internal use in connection with major projects. Costs incurred during the preliminary project stage and post implementation stage are expensed, whereas direct costs incurred during the application development stage are capitalized.

[0001032975-23-000021:notes:63]
Depreciation expense is recognized using the straight-line method. Plant and buildings are depreciated over estimated useful lives of twenty-five years, equipment over useful lives from three to five years, internal-use

[0001032975-23-000021:notes:64]
software over useful lives from three to ten years, tooling over useful lives from six months to one year, and leasehold improvements over the lesser of the term of the lease or ten years.

[0001032975-23-000021:notes:65]
When property and equipment is retired or otherwise disposed of, the cost and accumulated depreciation are relieved from the accounts and the net gain or loss is included in cost of goods sold or operating expenses, depending on the nature of the property and equipment.

[0001032975-23-000021:notes:66]
Leases

[0001032975-23-000021:notes:67]
The Company determines if an arrangement is a lease or contains a lease at contract inception. The Company determines if a lease is an operating or finance lease and recognizes right-of-use ("ROU") assets and lease liabilities upon lease commencement. Operating lease ROU assets are included in other assets, short-term lease liabilities are included in accrued and other current liabilities, and long-term lease liabilities are included in other non-current liabilities on the Company's consolidated balance sheets. Leases with an initial term of 12 months or less are not recorded on the balance sheet. For the Company's operating leases, the Company accounts for the lease component and related non-lease component as a single lease component. Lease expense is recognized on a straight-line basis over the lease term.

[0001032975-23-000021:notes:68]
For operating leases, the lease liability is initially measured at the present value of the unpaid lease payments at lease commencement date. As most of the leases do not provide an implicit rate, the Company generally uses its incremental borrowing rate as the discount rate for the leases. The Company's incremental borrowing rate is the rate of interest it would have to pay on a collateralized basis to borrow an amount equal to the lease payments under similar terms. Because the Company does not generally borrow in a collateralized basis, it uses its understanding of what its collateralized credit rating would be as an input to deriving an appropriate incremental borrowing rate. The operating lease ROU assets include prepaid lease payments and exclude lease incentives.

[0001032975-23-000021:notes:69]
Intangible Assets

[0001032975-23-000021:notes:70]
The Company's intangible assets principally include goodwill, acquired technology, trademarks, and customer contracts and related relationships. Intangible assets with finite lives, which include acquired technology, trademarks, customer contracts and related relationships, and others are carried at cost and amortized using the straight-line method over their useful lives ranging from one to ten years. Intangible assets with indefinite lives, which include only goodwill and in-process research and development ("IPR&D"), are recorded at cost and evaluated at least annually for impairment. IPR&D is reclassified as intangible assets with finite lives and amortized over its estimated useful life upon completion of the underlying projects.

[0001032975-23-000021:notes:71]
Impairment of Long-Lived Assets

[0001032975-23-000021:notes:72]
The Company reviews long-lived assets, such as property and equipment, and finite-lived intangible assets, for impairment whenever events indicate that the carrying amounts might not be recoverable. Recoverability of long-lived assets is measured by comparing the projected undiscounted net cash flows associated with those assets to their carrying values. If an asset is considered impaired, it is written down to its fair value, which is determined based on the asset's projected discounted cash flows or appraised value, depending on the nature of the asset. For purposes of recognition of impairment for assets held for use, the Company groups assets and liabilities at the lowest level for which cash flows are separately identifiable.

[0001032975-23-000021:notes:73]
Impairment of Goodwill

[0001032975-23-000021:notes:74]
Goodwill represents the excess of the purchase price over the fair value of the net tangible and identifiable intangible assets acquired in each business combination. The Company conducts a goodwill impairment analysis annually at December 31 or more frequently if indicators of impairment exist or if a decision is made to sell or exit a business. Significant judgments are involved in determining if an indicator of impairment has occurred. Such indicators may include deterioration in general economic conditions, negative developments in equity and credit markets, adverse changes in the markets in which an entity operates, increases in input costs that have a negative effect on earnings and cash flows, or a trend of negative or declining cash flows over multiple periods, among others. The fair value that could be realized in an actual transaction may differ from that used to evaluate the impairment of goodwill.

[0001032975-23-000021:notes:75]
In reviewing goodwill for impairment, the Company has the option to first assess qualitative factors to determine whether the existence of events or circumstances leads to a determination that it is more likely than not (greater than 50%) that the estimated fair value of a reporting unit is less than its carrying amount. The Company also may elect not to perform the qualitative assessment and, instead, proceed directly to the quantitative

[0001032975-23-000021:notes:76]
impairment test. The ultimate outcome of the goodwill impairment review for a reporting unit should be the same whether the Company chooses to perform the qualitative assessment or proceeds directly to the quantitative impairment test. The Company operates as one reporting unit. For the year ended March 31, 2023, the Company elected to perform a qualitative assessment and concluded that it was more likely than not that the fair value of its reporting unit exceeds its carrying amount.

[0001032975-23-000021:notes:77]
Income Taxes

[0001032975-23-000021:notes:78]
The Company provides for income taxes using the asset and liability method, which requires that deferred tax assets and liabilities be recognized for the expected future tax consequences of temporary differences resulting from differing treatment of items for tax and financial reporting purposes, and for operating losses and tax credit carryforwards. In estimating future tax consequences, expected future events are taken into consideration, with the exception of potential tax law or tax rate changes. The Company records a valuation allowance to reduce deferred tax assets to amounts management believes are more likely than not to be realized.

[0001032975-23-000021:notes:79]
The Company's assessment of uncertain tax positions requires that management makes estimates and judgments about the application of tax law, the expected resolution of uncertain tax positions and other matters. In the event that uncertain tax positions are resolved for amounts different than the Company's estimates, or the related statutes of limitations expire without the assessment of additional income taxes, the Company will be required to adjust the amounts of the related assets and liabilities in the period in which such events occur. Such adjustments may have a material impact on the Company's income tax provision and its results of operations.

[0001032975-23-000021:notes:80]
Fair Value of Financial Instruments

[0001032975-23-000021:notes:81]
The carrying value of certain of the Company's financial instruments, including cash equivalents, accounts receivable and accounts payable approximates their fair value due to their short maturities.

[0001032975-23-000021:notes:82]
The Company's investment securities portfolio consists of bank time deposits with an original maturity of three months or less and marketable securities (money market and mutual funds) related to a deferred compensation plan.

[0001032975-23-000021:notes:83]
The Company's investments related to the deferred compensation plan are reported at fair value based on quoted market prices. The marketable securities related to the deferred compensation plan are classified as non-current investments, as they are intended to fund the deferred compensation plan's long-term liability. Participants in the deferred compensation plan may select the mutual funds in which their compensation deferrals are invested within the confines of the Rabbi Trust which holds the marketable securities. These securities are recorded at fair value based on quoted market prices. Earnings, gains and losses on deferred compensation investments are included in other income (expense), net in the consolidated statements of operations.

[0001032975-23-000021:notes:84]
The Company also holds certain non-marketable investments that are accounted for as equity method investments and included in other assets in the consolidated balance sheets. In addition, the Company has certain equity investments without readily determinable fair values due to the absence of quoted market prices, the inherent lack of liquidity, and the fact that inputs used to measure fair value are unobservable and require management's judgment. The Company elected the measurement alternative to record these investments at cost and to adjust for impairments and observable price changes resulting from transactions with the same issuer within the statements of operations.

[0001032975-23-000021:notes:85]
Net Income per Share

[0001032975-23-000021:notes:86]
Basic net income per share is computed by dividing net income by the weighted average outstanding shares. Diluted net income per share is computed using the weighted average outstanding shares and dilutive share equivalents. Dilutive share equivalents consist of share-based awards, including stock options, purchase rights under employee share purchase plan, and restricted stock units.

[0001032975-23-000021:notes:87]
The dilutive effect of in-the-money share-based compensation awards is calculated based on the average share price for each fiscal period using the treasury stock method.

[0001032975-23-000021:notes:88]
Share-Based Compensation Expense

[0001032975-23-000021:notes:89]
Share-based compensation expense includes compensation expense for share-based awards granted based on the grant date fair value. The grant date fair value for stock options and stock purchase rights is estimated using the Black-Scholes-Merton option-pricing valuation model. The grant date fair value of service-based restricted stock units ("RSUs") is calculated based on the market price on the date of grant, reduced by estimated dividend yield

[0001032975-23-000021:notes:90]
prior to vesting. The grant date fair value of restricted stock units which vest upon meeting certain market- and performance-based conditions ("PSUs") is estimated using the Monte-Carlo simulation method including the effect of the market condition. Stock-based compensation expense is recognized ratably over the respective requisite service periods of the awards and forfeitures are accounted for when they occur. For PSUs, the Company recognizes compensation expense using its estimate of probable outcome at the end of the performance period (i.e., the estimated performance against the performance targets). The Company periodically adjusts the cumulative stock-based compensation expense recorded when the probable outcome for the PSUs is updated based upon changes in actual and forecasted financial results.

[0001032975-23-000021:notes:91]
Product Warranty

[0001032975-23-000021:notes:92]
All of the Company's products are covered by standard warranty to be free from defects in material and workmanship for periods ranging from one year to three years. The warranty period varies by product and by region. The Company’s standard warranty does not provide a service beyond assuring that the product complies with agreed-upon specifications and is not sold separately. The standard warranty the Company provides qualifies as an assurance warranty and is not treated as a separate performance obligation. The Company estimates cost of product warranties at the time the related revenue is recognized based on historical warranty claim rates, historical costs, and knowledge of specific product failures that are outside of the Company's typical experience. The Company accrues a warranty liability for estimated costs to provide products, parts or services to repair or replace products in satisfaction of the warranty obligation. Each quarter, the Company reevaluates estimates to assess the adequacy of recorded warranty liabilities. When the Company experiences changes in warranty claim activity or costs associated with fulfilling those claims, the warranty liability is adjusted accordingly.

[0001032975-23-000021:notes:93]
Comprehensive Income (Loss)

[0001032975-23-000021:notes:94]
Comprehensive income (loss) is defined as the total change in shareholders' equity during the period other than from transactions with shareholders. Comprehensive income (loss) consists of net income (loss) and other comprehensive income (loss). Other comprehensive income (loss) is comprised of currency translation adjustments from those entities not using the U.S. Dollar as their functional currency, net deferred gains and losses and prior service costs and credits for defined benefit pension plans, and net deferred gains and losses on hedging activity.

[0001032975-23-000021:notes:95]
Treasury Shares

[0001032975-23-000021:notes:96]
The Company periodically repurchases shares in the market at fair value. Shares repurchased are recorded at cost as a reduction of total shareholders' equity. Treasury shares held may be reissued to satisfy the exercise of employee stock options and purchase rights, the vesting of restricted stock units, and acquisitions, or may be canceled with shareholder approval. Treasury shares that are reissued are accounted for using the first-in, first-out basis.

[0001032975-23-000021:notes:97]
Derivative Financial Instruments

[0001032975-23-000021:notes:98]
The Company enters into foreign exchange forward contracts to reduce the short-term effects of currency fluctuations on certain foreign currency receivables or payables and to hedge against exposure to changes in currency exchange rates related to its subsidiaries' forecasted inventory purchases.

[0001032975-23-000021:notes:99]
Gains or losses from changes in the fair value of forward contracts that offset transaction losses or gains on foreign currency receivables or payables are recognized immediately and included in other income (expense), net in the consolidated statements of operations.

[0001032975-23-000021:notes:100]
Gains and losses for changes in the fair value of the effective portion of the Company's forward contracts related to forecasted inventory purchases are deferred as a component of accumulated other comprehensive loss until the hedged inventory purchases are sold, at which time the gains or losses are reclassified to cost of goods sold. The Company presents the earnings impact from forward points in the same line item that is used to present the earnings impact of the hedged item (i.e. cost of goods sold) for hedging forecasted inventory purchases.

[0001032975-23-000021:notes:101]
Restructuring Charges

[0001032975-23-000021:notes:102]
The Company's restructuring charges consist of employee severance, one-time termination benefits and ongoing benefits related to the reduction of its workforce, and other costs. Liabilities for costs associated with a restructuring activity are measured at fair value and are recognized when the liability is incurred, as opposed to when management commits to a restructuring plan. One-time termination benefits are expensed at the date the entity notifies the employee, unless the employee must provide future service, in which case the benefits are expensed ratably over the future service period. Ongoing benefits are expensed when restructuring activities are probable and the benefit amounts are estimable. Other costs primarily consist of legal, consulting, and other costs related to employee terminations, and are expensed when incurred. Termination benefits are calculated based on regional benefit practices and local statutory requirements.

[0001032975-23-000021:notes:103]
Recent Accounting Pronouncements Adopted

[0001032975-23-000021:notes:104]
In October 2021, the Financial Accounting Standard Board issued Accounting Standards Update 2021-08, "Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers" ("ASU 2021-08"). The update requires an acquirer in a business combination to recognize and measure contract assets and contract liabilities acquired in a business combination in accordance with Accounting Standards Codification ("ASC") 606, Revenue from Contracts with Customers, as if it had originated the contracts. The standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2022. The Company early adopted the standard effective April 1, 2022 and applied the standard prospectively to business combinations that occurred on or after April 1, 2022. The adoption of ASU 2021-08 did not have a material impact on the Company's consolidated financial statements.


## us-gaap:EarningsPerShareTextBlock

[0001032975-23-000021:notes:105]
Net Income Per Share 
The following table summarizes the computations of basic and diluted net income per share for fiscal years 2023, 2022 and 2021 (in thousands except per share amounts):

[0001032975-23-000021:notes:106]
|  |  | Years Ended March 31, |
|  |  | 2023 |  | 2022 |  | 2021 |
| Net income |  | $ | 364,575 |  |  | $ | 644,513 |  |  | $ | 947,257 |  |
| Shares used in net income per share computation: |  |  |  |  |  |  |
| Weighted average shares outstanding - basic |  | 162,302 |  |  | 167,447 |  |  | 168,523 |  |
| Effect of potentially dilutive equivalent shares |  | 1,402 |  |  | 2,967 |  |  | 3,252 |  |
| Weighted average shares outstanding - diluted |  | 163,704 |  |  | 170,414 |  |  | 171,775 |  |
| Net income per share: |  |  |  |  |  |  |
| Basic |  | $ | 2.25 |  |  | $ | 3.85 |  |  | $ | 5.62 |  |
| Diluted |  | $ | 2.23 |  |  | $ | 3.78 |  |  | $ | 5.51 |  |

[0001032975-23-000021:notes:107]
Share equivalents attributable to outstanding stock options, RSUs, PSUs and employee share purchase plans ("ESPP") totaling 2.0 million, 2.0 million, and 0.1 million shares during fiscal years 2023, 2022 and 2021, respectively, were excluded from the calculation of diluted net income per share because their effect would have been anti-dilutive.

[0001032975-23-000021:notes:108]
For fiscal years 2023 and 2022, a small number of performance-based awards were not included in the dilutive net income per share calculation because all necessary conditions had not been satisfied by the end of the respective period, and those shares were not issuable if the end of the reporting period were the end of the performance contingency period.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001032975-23-000021:notes:109]
Employee Stock-Based Compensation As of March 31, 2023, the Company offers the 2006 Employee Share Purchase Plan (Non-U.S.), as amended and restated ("2006 ESPP)", the 1996 Employee Share Purchase Plan (U.S.), as amended and restated ("1996 ESPP"), and the 2006 Stock Incentive Plan ("2006 Plan") as amended and restated. Shares issued to employees as a result of purchases or exercises under these plans are generally issued from shares held in treasury stock.
Under the 1996 ESPP and 2006 ESPP plans, eligible employees may purchase shares at the lower of 85% of the fair market value at the beginning or the end of each offering period, which is generally six months. Subject to continued participation in these plans, purchase agreements are automatically executed at the end of each offering period. An aggregate of 29.0 million shares were reserved for issuance under the 1996 and 2006 ESPP plans. As of March 31, 2023, a total of 3.6 million shares were available for new awards under these plans.

[0001032975-23-000021:notes:110]
The 2006 Plan provides for the grant to eligible employees and non-employee directors of stock options, stock appreciation rights, and restricted stock units. Awards under the 2006 Plan may be conditioned on continued employment, the passage of time or the satisfaction of performance and market vesting criteria. The 2006 Plan, as amended, has no expiration date. On June 29, 2022, the Board authorized 3.3 million additional shares for issuance under the 2006 Plan. An aggregate of 33.8 million shares were reserved for issuance under the 2006 Plan. As of March 31, 2023, a total of 8.4 million shares were available for new awards under this plan.

[0001032975-23-000021:notes:111]
Stock options granted to employees under the 2006 Plan have terms not exceeding ten years and are issued at exercise prices not less than the fair market value on the date of grant.

[0001032975-23-000021:notes:112]
Service-based restricted stock units ("RSUs") granted to employees under the 2006 Plan generally vest in four equal annual installments on the grant date anniversary. RSUs granted to non-executive board members under the 2006 Plan vest on the grant date anniversary, or if earlier and only if the non-executive board member is not re-elected as a director at such annual general meeting, the date of the next annual general meeting following the grant date.

[0001032975-23-000021:notes:113]
Restricted stock units with certain market- and performance-based conditions ("PSUs") granted to employees under the 2006 Plan vest at the end of the three-year performance period upon meeting predetermined financial metrics over three years, with the number of shares to be received upon vesting determined based on weighted average constant currency revenue growth rate and the Company's total shareholder return ("TSR") relative to the performance of companies in the Russell 3000 Index over the same three years period.

[0001032975-23-000021:notes:114]
The following table summarizes share-based compensation expense and total income tax benefit recognized for fiscal years 2023, 2022 and 2021 (in thousands):

[0001032975-23-000021:notes:115]
|  |  | Years Ended March 31, |
|  |  | 2023 |  | 2022 |  | 2021 |
| Cost of goods sold |  | $ | 5,635 |  |  | $ | 6,695 |  |  | $ | 6,438 |  |
| Marketing and selling |  | 34,707 |  |  | 37,796 |  |  | 36,788 |  |
| Research and development |  | 15,292 |  |  | 18,356 |  |  | 14,179 |  |
| General and administrative |  | 15,148 |  |  | 30,632 |  |  | 28,614 |  |
| Total share-based compensation expense |  | 70,782 |  |  | 93,479 |  |  | 86,019 |  |
| Income tax benefit |  | (9,750) |  |  | (26,987) |  |  | (19,472) |  |
| Total share-based compensation expense, net of income tax benefit |  | $ | 61,032 |  |  | $ | 66,492 |  |  | $ | 66,547 |  |

[0001032975-23-000021:notes:116]
Share-based compensation costs capitalized as part of inventory were $5.6 million, $5.2 million, and $4.3 million for the fiscal year ended March 31, 2023, 2022 and 2021, respectively.

[0001032975-23-000021:notes:117]
As of March 31, 2023, there was $125.2 million of total future stock-based compensation cost to be recognized over a weighted-average period of 2.4 years.

[0001032975-23-000021:notes:118]
The estimates of share-based compensation expense require a number of complex and subjective assumptions including stock price volatility, employee exercise patterns, probability of achievement of the set performance condition, dividend yield, related tax effects and the selection of an appropriate fair value model.

[0001032975-23-000021:notes:119]
The grant date fair value of the stock options and ESPP using the Black-Scholes-Merton option-pricing valuation model and the grant date fair value of the PSUs using the Monte-Carlo simulation method are determined with the following assumptions and values:

[0001032975-23-000021:notes:120]
|  |  |  | Stock Options(1) |  | Employee Stock Purchase Plans |
|  |  |  | Year Ended March 31, |  | Years Ended March 31, |
|  |  |  |  | 2022 |  |  |  | 2023 |  | 2022 |  | 2021 |
| Expected dividend rate |  |  |  | 1.18 | % |  |  |  | 1.78 | % |  | 1.03 | % |  | 1.04 | % |
| Risk-free interest rate |  |  |  | 1.99 | % |  |  |  | 3.86 | % |  | 0.27 | % |  | 0.10 | % |
| Expected volatility |  |  |  | 34 | % |  |  |  | 46 | % |  | 35 | % |  | 47 | % |
| Expected term (years) |  |  |  | 6.2 |  |  |  | 0.5 |  | 0.5 |  | 0.5 |
| Weighted average grant date fair value per share |  |  |  | $ | 25.88 |  |  |  | $ | 16.32 |  | $ | 23.55 |  | $ | 24.67 |

[0001032975-23-000021:notes:121]
(1) No stock options were granted for fiscal years 2023 and 2021.

[0001032975-23-000021:notes:122]
| PSUs |  | Years Ended March 31, |
|  |  | 2023 |  | 2022 |  | 2021 |
| Expected dividend rate |  | 1.46 | % |  | 0.78 | % |  | 1.24 | % |
| Risk-free interest rate |  | 2.78 | % |  | 0.31 | % |  | 0.21 | % |
| Expected volatility |  | 39 | % |  | 37 | % |  | 31 | % |
| Expected term (years) |  | 3.0 |  | 3.0 |  | 3.0 |

[0001032975-23-000021:notes:123]
The expected dividend rate assumption is based on the Company's history and future expectations of dividend payouts. The unvested PSUs or unexercised options are not eligible for these dividends. The expected term is based on the purchase offerings periods expected to remain outstanding for employee stock purchase plan or the performance period for PSUs. The expected term for stock options represents the estimated period of time until option exercise. Since the Company has limited historical stock option exercise experience, the Company used the simplified method in estimating the expected term, which is calculated as the average of the sum of the vesting term and the original contractual term of the stock options. Expected volatility is based on historical volatility using the Company's daily closing prices, or including the volatility of components of the Russell 3000 Index for PSUs, over the expected term. The Company considers the historical price volatility of its shares as most representative of future volatility. The risk-free interest rate assumptions are based upon the implied yield of U.S. Treasury zero-coupon issues appropriate for the expected term of the Company's share-based awards.

[0001032975-23-000021:notes:124]
For PSUs, the Company estimates the probability and timing of the achievement of the set performance condition at the time of the grant based on the historical financial performance and the financial forecast in the remaining performance period and reassesses the probability in subsequent periods when actual results or new information become available.

[0001032975-23-000021:notes:125]
A summary of the Company's stock option activities under all stock plans for fiscal years 2023, 2022 and 2021 is as follows:

[0001032975-23-000021:notes:126]
|  |  | Number of Shares |  | Weighted-Average Exercise Price |  | Weighted-Average Remaining Contractual Term |  | Aggregate Intrinsic Value |  |  |  |  |
|  |  | (In thousands) |  |  |  | (Years) |  | (In thousands) |  |  |  |  |
| Outstanding, March 31, 2020 |  | 1,969 |  |  |  |  |  |  |  |  |  |  |  |
| Exercised |  | (1,347) |  |  |  |  |  |  | $ | 68,596 |  |  |  |  |  |
| Outstanding, March 31, 2021 |  | 622 |  |  |  |  |  |  |  |  |  |  |  |
| Granted |  | 842 |  |  |  |  |  |  |  |  |  |  |  |
| Exercised |  | (71) |  |  |  |  |  |  | $ | 5,573 |  |  |  |  |  |
| Outstanding, March 31, 2022 |  | 1,393 |  |  | $ | 62 |  |  | 8.3 |  | $ | 21,830 |  |  |  |  |  |
| Exercised |  | (155) |  |  | $ | 21 |  |  |  |  | $ | 6,482 |  |  |  |  |  |
| Forfeited |  | (118) |  |  | $ | 80 |  |  |  |  |  |  |  |  |  |
| Outstanding, March 31, 2023 |  | 1,120 |  |  | $ | 66 |  |  | 7.6 |  | $ | 7,491 |  |  |  |  |  |
| Vested and exercisable, March 31, 2023 |  | 396 |  |  | $ | 39 |  |  | 5.2 |  | $ | 7,491 |  |  |  |  |  |

[0001032975-23-000021:notes:127]
The tax benefit realized for the tax deduction from options exercised during fiscal years 2023, 2022 and 2021 was $0.1 million, $1.2 million and $0.6 million, respectively.

[0001032975-23-000021:notes:128]
A summary of the Company's RSU and PSU activities for fiscal years 2023, 2022 and 2021 is as follows:

[0001032975-23-000021:notes:129]
|  |  | Number of Shares |  | Weighted-Average Grant Date Fair Value |  | Aggregate Fair Value |  |  |  |  |
|  |  | (In thousands) |  |  |  | (In thousands) |  |  |  |  |
| Outstanding, March 31, 2020 |  | 3,951 |  |  | $ | 36 |  |  |  |  |  |  |  |
| Granted—RSUs |  | 1,046 |  |  | $ | 60 |  |  |  |  |  |  |  |
| Granted—PSUs |  | 303 |  |  | $ | 67 |  |  |  |  |  |  |  |
| Vested |  | (1,444) |  |  |  |  | $ | 168,816 |  |  |  |  |  |
| Forfeited |  | (213) |  |  |  |  |  |  |  |  |  |
| Outstanding, March 31, 2021 |  | 3,643 |  |  | $ | 45 |  |  |  |  |  |  |  |
| Granted—RSUs |  | 868 |  |  | $ | 103 |  |  |  |  |  |  |  |
| Granted—PSUs |  | 203 |  |  | $ | 124 |  |  |  |  |  |  |  |
| Vested |  | (1,463) |  |  |  |  | $ | 133,977 |  |  |  |  |  |
| Forfeited |  | (205) |  |  |  |  |  |  |  |  |  |
| Outstanding, March 31, 2022 |  | 3,046 |  |  | $ | 68 |  |  |  |  |  |  |  |
| Granted—RSUs |  | 1,584 |  |  | $ | 53 |  |  |  |  |  |  |  |
| Granted—PSUs |  | 407 |  |  | $ | 69 |  |  |  |  |  |  |  |
| Vested |  | (1,143) |  |  | $ | 48 |  |  | $ | 85,152 |  |  |  |  |  |
| Forfeited |  | (438) |  |  | $ | 68 |  |  |  |  |  |  |  |
| Outstanding, March 31, 2023 |  | 3,456 |  |  | $ | 66 |  |  |  |  |  |  |  |

[0001032975-23-000021:notes:130]
The shares outstanding as of March 31, 2023 above include 0.8 million shares of PSUs. The Company presents the number of PSUs at 100 percent of the performance target; however, the aggregate fair value of shares vested during the year is based on the actual number of stock units vested based on the achievement of the financial metrics over the performance period.

[0001032975-23-000021:notes:131]
The tax benefit realized for the tax deduction from RSUs and PSUs that vested during fiscal years 2023, 2022 and 2021 was $11.1 million, $25.2 million and $16.3 million, respectively.
Employee Benefit Plans
Defined Benefit Plans

[0001032975-23-000021:notes:132]
Certain of the Company's subsidiaries sponsor defined benefit pension plans or non-retirement post-employment benefits covering substantially all of their employees. Benefits are provided based on employees' years of service and earnings, or in accordance with applicable employee benefit regulations. The Company's practice is to fund amounts sufficient to meet the requirements set forth in the applicable employee benefit and tax regulations.

[0001032975-23-000021:notes:133]
The Company recognizes the overfunded or underfunded status of defined benefit pension plans and non-retirement post-employment benefit obligations as an asset or liability in its consolidated balance sheets and recognizes changes in the funded status of defined benefit pension plans in the year in which the changes occur through accumulated other comprehensive income (loss), which is a component of shareholders' equity. Each plan's assets and benefit obligations are generally remeasured as of March 31 each year.

[0001032975-23-000021:notes:134]
The net periodic benefit cost of the defined benefit pension plans and the non-retirement post-employment benefit obligations for fiscal years 2023, 2022 and 2021 was as follows (in thousands):

[0001032975-23-000021:notes:135]
|  |  | Years Ended March 31, |
|  |  | 2023 |  | 2022 |  | 2021 |
| Service costs |  | $ | 13,195 |  |  | $ | 14,693 |  |  | $ | 12,121 |  |
| Interest costs |  | 2,408 |  |  | 920 |  |  | 1,047 |  |
| Expected return on plan assets |  | (3,754) |  |  | (2,930) |  |  | (2,535) |  |
| Amortization: |  |  |  |  |  |  |
| Net prior service credit recognized |  | (458) |  |  | (465) |  |  | (467) |  |
| Net actuarial loss (gain) recognized |  | (3,047) |  |  | (2,158) |  |  | 2,144 |  |
| Curtailment gain |  | (4,225) |  |  | — |  |  | — |  |
| Settlement gain |  | (339) |  |  | — |  |  | — |  |
| Total net periodic benefit cost |  | $ | 3,780 |  |  | $ | 10,060 |  |  | $ | 12,310 |  |

[0001032975-23-000021:notes:136]
The components of net periodic benefit cost other than the service costs component are included in other income (expense), net in the consolidated statements of operations.

[0001032975-23-000021:notes:137]
The changes in projected benefit obligations for fiscal years 2023 and 2022 were as follows (in thousands):

[0001032975-23-000021:notes:138]
|  |  | Years Ended March 31, |
|  |  | 2023 |  | 2022 |
| Projected benefit obligations, beginning of the year |  | $ | 207,551 |  |  | $ | 202,348 |  |
| Service costs |  | 13,195 |  |  | 14,693 |  |
| Interest costs |  | 2,408 |  |  | 920 |  |
| Plan participant contributions |  | 6,870 |  |  | 6,092 |  |
| Actuarial gain |  | (22,965) |  |  | (31,198) |  |
| Benefits paid |  | (2,646) |  |  | (3,904) |  |
| Transfer of prior vested benefits |  | 11,579 |  |  | 14,963 |  |
| Settlement |  | (15,348) |  |  | — |  |
| Curtailment |  | (3,923) |  |  | — |  |
| Administrative expense paid |  | (147) |  |  | (130) |  |
| Currency exchange rate changes |  | (1,238) |  |  | 3,767 |  |
| Projected benefit obligations, end of the year |  | $ | 195,336 |  |  | $ | 207,551 |  |

[0001032975-23-000021:notes:139]
The accumulated benefit obligation for all defined benefit pension plans as of March 31, 2023 and 2022 was $170.3 million and $178.5 million, respectively.

[0001032975-23-000021:notes:140]
Actuarial gains related to the change in the benefit obligation for the Company's pension plans for fiscal years 2023 and 2022 were primarily due to an increase in discount rate.

[0001032975-23-000021:notes:141]
The following table presents the changes in the fair value of defined benefit pension plan assets for fiscal years 2023 and 2022 (in thousands):

[0001032975-23-000021:notes:142]
|  |  | Years Ended March 31, |
|  |  | 2023 |  | 2022 |
| Fair value of plan assets, beginning of the year |  | $ | 156,118 |  |  | $ | 128,061 |  |
| Actual return on plan assets |  | (6,008) |  |  | (2,156) |  |
| Employer contributions |  | 11,645 |  |  | 10,877 |  |
| Plan participant contributions |  | 6,870 |  |  | 6,092 |  |
| Benefits paid |  | (2,646) |  |  | (3,904) |  |
| Transfer of prior vested benefits |  | 11,579 |  |  | 14,963 |  |
| Settlement |  | (15,348) |  |  | — |  |
| Administrative expenses paid |  | (147) |  |  | (130) |  |
| Currency exchange rate changes |  | 536 |  |  | 2,315 |  |
| Fair value of plan assets, end of the year |  | $ | 162,599 |  |  | $ | 156,118 |  |

[0001032975-23-000021:notes:143]
The Company's investment objectives are to ensure that the assets of its defined benefit plans are invested to provide an optimal rate of investment return on the total investment portfolio, consistent with the assumption of a reasonable risk level, and to ensure that pension funds are available to meet the plans' benefit obligations as they become due. The Company believes that a well-diversified investment portfolio will result in the highest attainable investment return with an acceptable level of overall risk. Investment strategies and allocation decisions are also governed by applicable governmental regulatory agencies. The Company's investment strategy with respect to its largest defined benefit plan, which is available only to Swiss employees, is to invest per the following allocation: 33% in equities, 28% in bonds, 28% in real estate, 4% in cash and cash equivalents and the remaining in other investments. The Company can invest in real estate funds, commodity funds, and hedge funds depending upon economic conditions.

[0001032975-23-000021:notes:144]
The following tables present the fair value of the defined benefit pension plan assets by major categories and by levels within the fair value hierarchy as of March 31, 2023 and 2022 (in thousands):

[0001032975-23-000021:notes:145]
|  |  | March 31, |
|  |  | 2023 |  | 2022 |
|  |  | Level 1 |  | Level 2 |  |  |  | Total |  | Level 1 |  | Level 2 |  |  |  | Total |
| Cash and cash equivalents |  | $ | 7,071 |  |  | $ | — |  |  |  |  | $ | 7,071 |  |  | $ | 16,317 |  |  | $ | — |  |  |  |  | $ | 16,317 |  |
| Equity securities |  | 51,963 |  |  | — |  |  |  |  | 51,963 |  |  | 48,591 |  |  | — |  |  |  |  | 48,591 |  |
| Debt securities |  | 43,493 |  |  | — |  |  |  |  | 43,493 |  |  | 38,513 |  |  | — |  |  |  |  | 38,513 |  |
| Real estate funds |  | 21,197 |  |  | 23,710 |  |  |  |  | 44,907 |  |  | 25,146 |  |  | 13,077 |  |  |  |  | 38,223 |  |
| Hedge funds |  | 606 |  |  | 7,907 |  |  |  |  | 8,513 |  |  | — |  |  | 8,076 |  |  |  |  | 8,076 |  |
| Other |  | 6,248 |  |  | 404 |  |  |  |  | 6,652 |  |  | 6,034 |  |  | 364 |  |  |  |  | 6,398 |  |
| Total fair value of plan assets |  | $ | 130,578 |  |  | $ | 32,021 |  |  |  |  | $ | 162,599 |  |  | $ | 134,601 |  |  | $ | 21,517 |  |  |  |  | $ | 156,118 |  |

[0001032975-23-000021:notes:146]
The funded status of the plans was as follows (in thousands):

[0001032975-23-000021:notes:147]
|  |  | Years Ended March 31, |
|  |  | 2023 |  | 2022 |
| Fair value of plan assets |  | $ | 162,599 |  |  | $ | 156,118 |  |
| Less: projected benefit obligations |  | 195,336 |  |  | 207,551 |  |
| Underfunded status |  | $ | (32,737) |  |  | $ | (51,433) |  |

[0001032975-23-000021:notes:148]
Amounts recognized on the balance sheets for the plans were as follows (in thousands):

[0001032975-23-000021:notes:149]
|  |  | March 31, |
|  |  | 2023 |  | 2022 |
| Current liabilities |  | $ | 1,407 |  |  | $ | 1,677 |  |
| Non-current liabilities |  | 31,330 |  |  | 49,756 |  |
| Total liabilities |  | $ | 32,737 |  |  | $ | 51,433 |  |

[0001032975-23-000021:notes:150]
Amounts recognized in accumulated other comprehensive income (loss) related to defined benefit pension plans were as follows (in thousands):

[0001032975-23-000021:notes:151]
|  |  | March 31, |
|  |  | 2023 |  | 2022 |  |  |
| Net prior service credits |  | $ | 2,201 |  |  | $ | 2,883 |  |  |  |
| Net actuarial gain (loss) |  | 5,690 |  |  | (4,304) |  |  |  |
| Accumulated other comprehensive income (loss) |  | 7,891 |  |  | (1,421) |  |  |  |
| Deferred taxes |  | (3,366) |  |  | (2,074) |  |  |  |
| Accumulated other comprehensive income (loss), net of tax |  | $ | 4,525 |  |  | $ | (3,495) |  |  |  |

[0001032975-23-000021:notes:152]
The actuarial assumptions for the defined benefit plans were as follows:

[0001032975-23-000021:notes:153]
|  |  | Years Ended March 31, |
|  |  | 2023 |  | 2022 |
| Benefit Obligations: |  |  |  |  |
| Discount rate |  | 1.00% - 7.25% |  | 1.00% - 6.75% |
| Estimated rate of compensation increase |  | 2.25% - 10.00% |  | 2.00% - 10.00% |
| Cash balance interest credit rate |  | 0.00% - 1.75% |  | 0.00% - 1.75% |

[0001032975-23-000021:notes:154]
|  |  | Years Ended March 31, |
|  |  | 2023 |  | 2022 |  | 2021 |
| Net Periodic Costs: |  |  |  |  |  |  |
| Discount rate |  | 0.50% - 6.75% |  | 0.25% - 6.00% |  | 0.50% - 6.75% |
| Estimated rate of compensation increase |  | 2.00% - 10.00% |  | 2.00% - 10.00% |  | 2.25% - 10.00% |
| Expected average rate of return on plan assets |  | 1.00% - 2.50% |  | 1.00% - 2.25% |  | 1.00% - 2.50% |
| Cash balance interest credit rate |  | 0.00% - 1.75% |  | 0.00% - 1.75% |  | 0.00% - 1.75% |

[0001032975-23-000021:notes:155]
The discount rate is estimated based on corporate bond yields or securities of similar quality in the respective country, with a duration approximating the period over which the benefit obligations are expected to be paid. The Company bases the compensation increase assumptions on historical experience and future expectations. The expected average rate of return for the Company's defined benefit pension plans represents the average rate of return expected to be earned on plan assets over the period that the benefit obligations are expected to be paid, based on government bond notes in the respective country, adjusted for corporate risk premiums as appropriate.

[0001032975-23-000021:notes:156]
The following table reflects the benefit payments that the Company expects the plans to pay in the periods noted (in thousands):

[0001032975-23-000021:notes:157]
| Years Ending March 31, |  |  |
| 2024 |  | $ | 26,765 |  |
| 2025 |  | 11,728 |  |
| 2026 |  | 12,046 |  |
| 2027 |  | 14,440 |  |
| 2028 |  | 12,772 |  |
| Next five fiscal years |  | 66,302 |  |
| Total expected benefit payments by the plan |  | $ | 144,053 |  |

[0001032975-23-000021:notes:158]
The Company expects to contribute $9.4 million to its defined benefit pension plans during fiscal year 2024.

[0001032975-23-000021:notes:159]
Defined Contribution Plans

[0001032975-23-000021:notes:160]
Certain of the Company's subsidiaries have defined contribution employee benefit plans covering all or a portion of their employees. Contributions to these plans are discretionary for certain plans and are based on specified or statutory requirements for others. The charges to expense for these plans for fiscal years 2023, 2022 and 2021, were $14.4 million, $13.9 million and $10.6 million, respectively.

[0001032975-23-000021:notes:161]
Deferred Compensation Plan

[0001032975-23-000021:notes:162]
One of the Company's subsidiaries offers a deferred compensation plan that permits eligible employees to make 100% vested salary and incentive compensation deferrals within established limits. The Company does not make contributions to the plan.

[0001032975-23-000021:notes:163]
The deferred compensation plan's assets consist of marketable securities and are included in other assets on the consolidated balance sheets. The marketable securities were recorded at a fair value of $28.2 million and $28.4 million as of March 31, 2023 and 2022, respectively, based on quoted market prices (see Note 9). The Company also had deferred compensation liability of $28.2 million and $28.4 million, which are included in other non-current liabilities on the consolidated balance sheets as of March 31, 2023 and 2022, respectively. Earnings, gains and losses on deferred compensation investments are included in other income (expense), net and corresponding changes in deferred compensation liability are included in operating expenses and cost of goods sold in the consolidated statements of operations (see Note 6).


## us-gaap:InterestAndOtherIncomeTextBlock

[0001032975-23-000021:notes:164]
Other Income (Expense), net
Other income (expense), net comprises of the following (in thousands):

[0001032975-23-000021:notes:165]
|  |  | Years Ended March 31, |
|  |  | 2023 |  | 2022 |  | 2021 |
| Investment (loss) gain related to the deferred compensation plan |  | $ | (1,961) |  |  | $ | 1,231 |  |  | $ | 5,916 |  |
| Currency exchange loss, net |  | (7,337) |  |  | (4,604) |  |  | (2,688) |  |
| Loss on investments, net (1) |  | (14,073) |  |  | (1,683) |  |  | (5,910) |  |
| Non-service cost net pension income (expense) and other (2) |  | 10,093 |  |  | 5,616 |  |  | 893 |  |
| Other income (expense), net |  | $ | (13,278) |  |  | $ | 560 |  |  | $ | (1,789) |  |

[0001032975-23-000021:notes:166]
(1) Includes realized gain (loss) on sales of investments, unrealized gain (loss) from the change in fair value of investments, gain (loss) on equity-method investments, and impairment of investments during the periods presented, as applicable, (see Note 9).

[0001032975-23-000021:notes:167]
(2) Includes the components of net periodic benefit cost of defined benefit plans other than the service cost component (see Note 5).


## us-gaap:IncomeTaxDisclosureTextBlock

[0001032975-23-000021:notes:168]
Income Taxes 
The Company is incorporated in Switzerland but operates in various countries with differing tax laws and rates. Further, a portion of the Company's income before taxes and the provision for (benefit from) income taxes is generated outside of Switzerland.

[0001032975-23-000021:notes:169]
Income from continuing operations before income taxes for fiscal years 2023, 2022 and 2021 is summarized as follows (in thousands):

[0001032975-23-000021:notes:170]
|  |  | Years Ended March 31, |
|  |  | 2023 |  | 2022 |  | 2021 |
| Swiss |  | $ | 282,970 |  |  | $ | 579,258 |  |  | $ | 984,185 |  |
| Non-Swiss |  | 180,552 |  |  | 196,560 |  |  | 163,935 |  |
| Income before taxes |  | $ | 463,522 |  |  | $ | 775,818 |  |  | $ | 1,148,120 |  |

[0001032975-23-000021:notes:171]
The provision for (benefit from) income taxes is summarized as follows (in thousands):

[0001032975-23-000021:notes:172]
|  |  | Years Ended March 31, |
|  |  | 2023 |  | 2022 |  | 2021 |
| Current: |  |  |  |  |  |  |
| Swiss |  | $ | 19,405 |  |  | $ | 59,659 |  |  | $ | 121,199 |  |
| Non-Swiss |  | 48,829 |  |  | 44,094 |  |  | 45,056 |  |
| Deferred: |  |  |  |  |  |  |
| Swiss |  | 26,629 |  |  | 29,198 |  |  | 31,558 |  |
| Non-Swiss |  | 4,085 |  |  | (1,646) |  |  | 3,050 |  |
| Provision for income taxes |  | $ | 98,947 |  |  | $ | 131,305 |  |  | $ | 200,863 |  |

[0001032975-23-000021:notes:173]
The difference between the provision for (benefit from) income taxes and the expected tax provision (tax benefit) at the statutory income tax rate of 8.5% is reconciled below (in thousands):

[0001032975-23-000021:notes:174]
|  |  | Years Ended March 31, |
|  |  | 2023 |  | 2022 |  | 2021 |
| Expected tax provision at statutory income tax rates |  | $ | 39,399 |  |  | $ | 65,945 |  |  | $ | 97,590 |  |
| Income taxes at different rates |  | 38,467 |  |  | 61,296 |  |  | 88,760 |  |
| Research and development tax credits |  | (152) |  |  | (5,957) |  |  | (3,844) |  |
| Executive compensation |  | 749 |  |  | 4,683 |  |  | 4,821 |  |
| Stock-based compensation |  | 5,736 |  |  | (9,141) |  |  | (3,161) |  |
| Deferred tax effects from TRAF |  | — |  |  | — |  |  | 1,944 |  |
| Valuation allowance |  | 908 |  |  | 887 |  |  | (247) |  |
| Impairment |  | 1,881 |  |  | — |  |  | — |  |
| Restructuring charges / (credits) |  | (1,764) |  |  | — |  |  | (5) |  |
| Unrecognized tax benefits |  | 13,284 |  |  | 16,577 |  |  | 15,978 |  |
| Audit settlement |  | — |  |  | (3,655) |  |  | — |  |
| Other, net |  | 439 |  |  | 670 |  |  | (973) |  |
| Provision for income taxes |  | $ | 98,947 |  |  | $ | 131,305 |  |  | $ | 200,863 |  |

[0001032975-23-000021:notes:175]
Deferred income tax assets and liabilities consist of the following (in thousands):

[0001032975-23-000021:notes:176]
|  |  | March 31, |
|  |  | 2023 |  | 2022 |
| Deferred tax assets: |  |  |  |  |
| Tax attributes carryforward |  | $ | 36,700 |  |  | $ | 34,736 |  |
| Accruals |  | 85,786 |  |  | 88,060 |  |
| Depreciation and amortization |  | 707 |  |  | 585 |  |
| Tax step-up of goodwill from TRAF |  | 100,514 |  |  | 118,000 |  |
| Share-based compensation |  | 11,093 |  |  | 13,152 |  |
| Gross deferred tax assets |  | 234,800 |  |  | 254,533 |  |
| Valuation allowance |  | (30,766) |  |  | (29,858) |  |
| Deferred tax assets after valuation allowance |  | 204,034 |  |  | 224,675 |  |
| Deferred tax liabilities: |  |  |  |  |
| Acquired intangible assets and other |  | (34,848) |  |  | (33,008) |  |
| Deferred tax liabilities |  | (34,848) |  |  | (33,008) |  |
| Deferred tax assets, net |  | $ | 169,186 |  |  | $ | 191,667 |  |

[0001032975-23-000021:notes:177]
Included in tax attributes carryforward above are net operating loss and tax credit carryforwards.

[0001032975-23-000021:notes:178]
Management regularly assesses the ability to realize deferred tax assets recorded in the Company's entities based upon the weight of available evidence, including such factors as recent earnings history and expected future taxable income. In the event that the Company changes its determination as to the amount of deferred tax assets that can be realized, the Company will adjust its valuation allowance with a corresponding impact to the provision for income taxes in the period in which such determination is made.

[0001032975-23-000021:notes:179]
The Company had a valuation allowance against deferred tax assets of $30.8 million at March 31, 2023, compared to $29.9 million at March 31, 2022. The Company had a valuation allowance of $30.8 million as of March 31, 2023 against deferred tax assets in the state of California, an increase from $29.7 million as of March 31, 2022 from activities during the year. The Company determined that it is more likely than not that the Company would not generate sufficient taxable income in the future to utilize such deferred tax assets.

[0001032975-23-000021:notes:180]
As of March 31, 2023, the Company had net operating loss carryforwards in Switzerland for income tax purposes of $17.7 million which will begin to expire in fiscal year 2028. The Company had net operating loss and tax credit carryforwards in the United States for income tax purposes of $60.2 million and $74.6 million, respectively. Unused net operating loss carryforwards will expire at various dates beginning in fiscal year 2030. Certain net operating loss carryforwards in the United States relate to acquisitions and, as a result, are limited in the amount that can be utilized in any one year. The tax credit carryforwards will begin to expire in fiscal year 2030.

[0001032975-23-000021:notes:181]
Swiss income taxes and non-Swiss withholding taxes associated with the repatriation of earnings or for other temporary differences related to investments in non-Swiss subsidiaries have not been provided for, as the Company intends to reinvest the earnings of such subsidiaries indefinitely. If these earnings were distributed to Switzerland in the form of dividends or otherwise, or if the shares of the relevant non-Swiss subsidiaries were sold or otherwise transferred, the Company may be subject to additional Swiss income taxes and non-Swiss withholding taxes. As of March 31, 2023, the cumulative amount of unremitted earnings of non-Swiss subsidiaries for which no income taxes have been provided is approximately $323.8 million. The amount of unrecognized deferred income tax liability related to these earnings is estimated to be approximately $9.5 million.

[0001032975-23-000021:notes:182]
The Company follows a two-step approach in recognizing and measuring uncertain tax positions. The first step is to evaluate the tax position for recognition by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step is to measure the tax benefit as the largest amount that is more than 50% likely of being realized upon ultimate settlement.

[0001032975-23-000021:notes:183]
As of March 31, 2023 and 2022, the total amount of unrecognized tax benefits due to uncertain tax positions was $186.8 million and $176.0 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-23-000021:notes:184]
As of March 31, 2023 and 2022, the Company had $106.4 million and $83.4 million, respectively, in non-current income taxes payable, including interest and penalties, related to the Company's income tax liability for uncertain tax positions.

[0001032975-23-000021:notes:185]
The aggregate changes in gross unrecognized tax benefits in fiscal years 2023, 2022 and 2021 were as follows (in thousands).

[0001032975-23-000021:notes:186]
| March 31, 2020 |  | $ | 143,497 |  |
| Lapse of statute of limitations |  | (4,024) |  |
| Increases in balances related to tax positions taken during the year |  | 23,780 |  |
| March 31, 2021 |  | $ | 163,253 |  |
| Lapse of statute of limitations |  | (4,232) |  |
| Settlements with taxing authorities |  | (2,015) |  |
| Increases in balances related to tax positions taken during the year |  | 22,366 |  |
| March 31, 2022 |  | $ | 179,372 |  |
| Lapse of statute of limitations |  | (3,586) |  |
| Increases in balances related to tax positions taken during the year |  | 15,214 |  |
| March 31, 2023 |  | $ | 191,000 |  |

[0001032975-23-000021:notes:187]
Fiscal year 2020 includes gross unrecognized tax benefits recorded as a result of the enactment of the Tax Reform and AHV Financing ("TRAF") in Switzerland.

[0001032975-23-000021:notes:188]
The Company recognizes interest and penalties related to unrecognized tax positions in income tax expense. The Company recognized $2.7 million, $1.5 million, and $1.1 million in interest and penalties in income tax expense during fiscal years 2023, 2022 and 2021, respectively. As of March 31, 2023 and 2022, the Company had $6.1 million, and $3.6 million, respectively, of accrued interest and penalties related to uncertain tax positions.

[0001032975-23-000021:notes:189]
The Company files Swiss and foreign tax returns. The Company received final tax assessments in Switzerland through fiscal year 2019. For other material foreign jurisdictions such as the United States and China, the Company is generally not subject to tax examinations for years prior to fiscal year 2020 and calendar year 2020, respectively. In the United States, the federal and state tax agencies have the authority to examine periods prior to fiscal year 2020, to the extent allowed by law, where tax attributes were generated, carried forward, and being utilized in subsequent years. The Company is under examination in foreign tax jurisdictions. If the examinations are resolved unfavorably, there is a possibility they may have a material negative impact on its results of operations. In fiscal year 2022, uncertain tax positions decreased by $4.2 million from an effective settlement of an income tax audit in a foreign jurisdiction.
Although the Company has adequately provided for uncertain tax positions, the provisions on these positions may change as revised estimates are made or the underlying matters are settled or otherwise resolved. During the next 12 months, it is reasonably possible that the amount of unrecognized tax benefits could increase or decrease significantly due to changes in tax law in various jurisdictions, new tax audits and changes in the U.S. Dollar as compared to other currencies. Excluding these factors, uncertain tax positions may decrease by as much as $5.0 million primarily from the lapse of the statutes of limitations in various jurisdictions during the next 12 months.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001032975-23-000021:notes:190]
Balance Sheet Components
The following table presents the components of certain balance sheet asset amounts as of March 31, 2023 and 2022 (in thousands):

[0001032975-23-000021:notes:191]
|  |  | March 31, |
|  |  | 2023 |  | 2022 |
| Accounts receivable, net: |  |  |  |  |
| Accounts receivable |  | $ | 851,576 |  |  | $ | 964,766 |  |
| Allowance for doubtful accounts |  | (86) |  |  | (2,212) |  |
| Allowance for sales returns |  | (10,146) |  |  | (12,321) |  |
| Allowance for cooperative marketing arrangements |  | (40,495) |  |  | (56,372) |  |
| Allowance for customer incentive programs |  | (71,645) |  |  | (97,460) |  |
| Allowance for pricing programs |  | (98,822) |  |  | (120,797) |  |
|  |  | $ | 630,382 |  |  | $ | 675,604 |  |
| Inventories: |  |  |  |  |
| Raw materials |  | $ | 171,790 |  |  | $ | 226,155 |  |
| Finished goods |  | 511,103 |  |  | 706,969 |  |
|  |  | $ | 682,893 |  |  | $ | 933,124 |  |
| Other current assets: |  |  |  |  |
| VAT receivables |  | $ | 60,343 |  |  | $ | 58,850 |  |
| Prepaid expenses and other assets |  | 82,533 |  |  | 76,628 |  |
|  |  | $ | 142,876 |  |  | $ | 135,478 |  |
| Property, plant and equipment, net: |  |  |  |  |
| Plant, buildings and improvements |  | $ | 69,360 |  |  | $ | 68,477 |  |
| Equipment and tooling |  | 309,151 |  |  | 268,164 |  |
| Computer equipment |  | 31,535 |  |  | 31,562 |  |
| Software |  | 79,118 |  |  | 72,391 |  |
|  |  | 489,164 |  |  | 440,594 |  |
| Less: accumulated depreciation and amortization |  | (396,855) |  |  | (349,606) |  |
|  |  | 92,309 |  |  | 90,988 |  |
| Construction-in-process |  | 26,399 |  |  | 15,915 |  |
| Land |  | 2,795 |  |  | 2,904 |  |
|  |  | $ | 121,503 |  |  | $ | 109,807 |  |
| Other assets: |  |  |  |  |
| Deferred tax assets |  | $ | 171,989 |  |  | $ | 193,629 |  |
| Right-of-use assets |  | 67,330 |  |  | 40,661 |  |
| Investments in privately held companies |  | 33,323 |  |  | 43,068 |  |
| Investments for deferred compensation plan |  | 28,213 |  |  | 28,431 |  |
| Other assets |  | 15,438 |  |  | 14,933 |  |
|  |  | $ | 316,293 |  |  | $ | 320,722 |  |

[0001032975-23-000021:notes:192]
The following table presents the components of certain balance sheet liability amounts as of March 31, 2023 and 2022 (in thousands):

[0001032975-23-000021:notes:193]
|  |  | March 31, |
|  |  | 2023 |  | 2022 |
| Accrued and other current liabilities: |  |  |  |  |
| Accrued customer marketing, pricing and incentive programs |  | $ | 206,546 |  |  | $ | 232,393 |  |
| Accrued personnel expenses |  | 103,592 |  |  | 165,090 |  |
| Accrued sales return liability |  | 49,462 |  |  | 40,507 |  |
| Accrued loss for inventory purchase commitments |  | 46,608 |  |  | 46,361 |  |
| VAT payable |  | 33,328 |  |  | 39,602 |  |
| Warranty liabilities |  | 28,861 |  |  | 32,987 |  |
| Income taxes payable |  | 18,788 |  |  | 35,355 |  |
| Operating lease liabilities |  | 12,655 |  |  | 13,690 |  |
| Contingent consideration |  | 6,629 |  |  | 8,042 |  |
| Other current liabilities |  | 136,670 |  |  | 170,821 |  |
|  |  | $ | 643,139 |  |  | $ | 784,848 |  |
| Other non-current liabilities: |  |  |  |  |
| Operating lease liabilities |  | $ | 58,361 |  |  | $ | 28,207 |  |
| Employee benefit plan obligations |  | 32,421 |  |  | 50,741 |  |
| Obligation for deferred compensation plan |  | 28,213 |  |  | 28,431 |  |
| Warranty liabilities |  | 12,025 |  |  | 13,232 |  |
| Deferred tax liabilities |  | 2,803 |  |  | 1,962 |  |
| Contingent consideration |  | — |  |  | 4,217 |  |
| Other non-current liabilities |  | 12,872 |  |  | 5,343 |  |
|  |  | $ | 146,695 |  |  | $ | 132,133 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001032975-23-000021:notes:194]
Fair Value Measurements
Fair Value Measurements

[0001032975-23-000021:notes:195]
The Company considers fair value as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants at the measurement date. The Company utilizes the following three-level fair value hierarchy to establish the priorities of the inputs used to measure fair value:

[0001032975-23-000021:notes:196]
•Level 1—Quoted prices in active markets for identical assets or liabilities.

[0001032975-23-000021:notes:197]
•Level 2—Observable inputs other than quoted market prices included in Level 1, such as quoted prices for similar assets and liabilities in active markets; quoted prices for identical or similar assets and liabilities in markets that are not active; or other inputs that are observable or can be corroborated by observable market data.

[0001032975-23-000021:notes:198]
•Level 3—Unobservable inputs that are supported by little or no market activity and that are significant to the fair value of the assets or liabilities. This includes certain pricing models, discounted cash flow methodologies and similar techniques that use significant unobservable inputs.

[0001032975-23-000021:notes:199]
The following table presents the Company's financial assets and liabilities that were accounted for at fair value on a recurring basis, excluding assets related to the Company's defined benefit pension plans, classified by the level within the fair value hierarchy (in thousands):

[0001032975-23-000021:notes:200]
|  |  | March 31, 2023 |  | March 31, 2022 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Level 1 |  | Level 2 |  | Level 3 |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 661,884 |  |  | $ | — |  |  | $ | — |  |  | $ | 762,055 |  |  | $ | — |  |  | $ | — |  |
| Investments for deferred compensation plan included in other assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 41 |  |  | $ | — |  |  | $ | — |  |  | $ | 108 |  |  | $ | — |  |  | $ | — |  |
| Common stock |  | 988 |  |  | — |  |  | — |  |  | 2,329 |  |  | — |  |  | — |  |
| Money market funds |  | 9,606 |  |  | — |  |  | — |  |  | 6,765 |  |  | — |  |  | — |  |
| Mutual funds |  | 17,578 |  |  | — |  |  | — |  |  | 19,229 |  |  | — |  |  | — |  |
| Total of investments for deferred compensation plan |  | $ | 28,213 |  |  | $ | — |  |  | $ | — |  |  | $ | 28,431 |  |  | $ | — |  |  | $ | — |  |
| Currency derivative assets included in other current assets |  | $ | — |  |  | $ | 107 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,517 |  |  | $ | — |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Contingent consideration included in accrued and other current liabilities |  | $ | — |  |  | $ | — |  |  | $ | 6,629 |  |  | $ | — |  |  | $ | — |  |  | $ | 8,042 |  |
| Contingent consideration included in other non-current liabilities |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 3,971 |  |
| Currency derivative liabilities included in accrued and other current liabilities |  | $ | — |  |  | $ | 2,187 |  |  | $ | — |  |  | $ | — |  |  | $ | 165 |  |  | $ | — |  |

[0001032975-23-000021:notes:201]
Contingent Consideration for Business Acquisitions

[0001032975-23-000021:notes:202]
The following table summarizes the change in the Company's contingent consideration balance during fiscal year 2023 and 2022 (in thousands):

[0001032975-23-000021:notes:203]
|  | Year Ended March 31, |
|  | 2023 |  | 2022 |
| Beginning of the period | $ | 12,259 |  |  | $ | 6,967 |  |
| Fair value of contingent consideration upon acquisition | 2,151 |  | 9,973 |  |
| Change in fair value of contingent consideration | — |  |  | (3,509) |  |
| Settlements of contingent consideration | (5,954) |  | (1,172) |  |
| Effect of foreign currency exchange rate changes | $ | (1,827) |  |  | — |  |
| End of the period | $ | 6,629 |  |  | $ | 12,259 |  |

[0001032975-23-000021:notes:204]
On May 19, 2021, the Company made a technology acquisition for a total cash consideration of $25.6 million, which included contingent consideration of $10.0 million payable in cash upon the achievement of three technical development milestones to be completed as of December 31, 2021, June 30, 2022, and June 30, 2023. The fair value of the contingent consideration was $10.0 million at the acquisition date, which was determined using a probability-weighted expected payment model and discounted at the estimated cost of debt. During fiscal year 2022, the Company paid $0.9 million for the contingent consideration related to the first technical development milestone. During fiscal year 2023, the Company paid $4.0 million for the contingent consideration related to the second technical development milestone. The Company expects to pay the contingent consideration for the third technical development milestone within the next twelve months.

[0001032975-23-000021:notes:205]
On February 17, 2021, the Company acquired all equity interests of Mevo Inc. ("Mevo") for a total cash consideration of $33.2 million, plus additional contingent consideration of up to $17.0 million payable in cash only upon the achievement of certain net revenues for the period from December 26, 2020 to December 31, 2021. The fair value of the contingent consideration as of the acquisition date was $3.4 million, which was determined by using a Black-Scholes-Merton valuation model to calculate the probability of the earn-out threshold being met, times the

[0001032975-23-000021:notes:206]
value of the earn-out payment, and discounted at the risk-free rate. The valuation included significant assumptions and unobservable inputs such as the projected sales of Mevo over the earn-out period, risk-free rate, and the net sales volatility. Projected sales were based on the Company's internal projections, including analysis of the target market and historical sales of Mevo products. As of March 31, 2021 the fair value of the contingent consideration remained as $3.4 million. As of December 31, 2021, the fair value of the contingent consideration was released from other current liabilities as the net sales milestone was not achieved upon completion of the earn-out period.

[0001032975-23-000021:notes:207]
On January 4, 2021, the Company made a technology acquisition for a total cash consideration of $11.0 million, which included contingent consideration of $3.0 million payable in cash upon the achievement of two technical development milestones to be completed as of December 31, 2021 and March 31, 2022. The fair value of the contingent consideration was determined using a probability-weighted expected payment model and discounted at the estimated cost of debt. During fiscal year 2023, the Company paid $2.0 million for the contingent consideration related to the first technical development milestone. The Company expects to pay the remaining $1.0 million for the second technical development milestone within the next twelve months.

[0001032975-23-000021:notes:208]
In connection with the acquisition of Streamlabs on October 31, 2019, the Company agreed to pay a total earn-out payment of $29.0 million, payable in stock, only upon the achievement of certain net revenues for the period from January 1, 2020 to June 30, 2020. During fiscal year 2021 and 2022, the Company issued 390,397 and 4,010 shares, respectively, out of treasury stock to former security holders of Streamlabs, in satisfaction of payment of the contingent consideration that was earned during the earn-out period. The issuances of such shares were deemed to be exempt from registration under the Securities Act of 1933 (the "Securities Act"), in reliance on Regulation D of the Securities Act as transactions by an issuer not involving a public offering.

[0001032975-23-000021:notes:209]
Although the estimate of contingent consideration is based on management’s best knowledge of current events, the estimate could change significantly from period to period. Actual results that differ from the assumptions used and any changes to the significant assumptions and unobservable inputs used could have an impact on future results of operations.

[0001032975-23-000021:notes:210]
Investments for Deferred Compensation Plan

[0001032975-23-000021:notes:211]
The marketable securities for the Company's deferred compensation plan are recorded at a fair value of $28.2 million and $28.4 million as of March 31, 2023 and 2022, respectively, based on quoted market prices. Quoted market prices are observable inputs that are classified as Level 1 within the fair value hierarchy. Unrealized gains (losses) related to marketable securities for fiscal years 2023, 2022 and 2021 are included in other income (expense), net in the consolidated statements of operations (see Note 6).

[0001032975-23-000021:notes:212]
Equity Method Investments

[0001032975-23-000021:notes:213]
The Company has certain non-marketable investments included in other assets that are accounted for as equity method investments, with a carrying value of $20.5 million and $40.2 million as of March 31, 2023 and 2022, respectively. Gains (losses) related to equity method investments for fiscal years 2023, 2022 and 2021 were not material and are included in other income (expense), net in the Company's consolidated statements of operations (see Note 6).

[0001032975-23-000021:notes:214]
During fiscal year 2023, the Company recorded an impairment charge, before tax, of $21.4 million for one of its equity method investments as it was determined that the carrying value of the investment was not recoverable. The impairment charge is included in other income (expense), net in the Company's consolidated statement of operations for fiscal year 2023. There was no impairment of equity method investments during fiscal years 2022 and 2021.

[0001032975-23-000021:notes:215]
Assets Measured at Fair Value on a Nonrecurring Basis

[0001032975-23-000021:notes:216]
Financial Assets. The Company has certain equity investments without readily determinable fair values due to the absence of quoted market prices, the inherent lack of liquidity, and the fact that inputs used to measure fair value are unobservable and require management's judgment. When certain events or circumstances indicate that impairment may exist, the Company revalues the investments using various assumptions, including the financial metrics and ratios of comparable public companies. The carrying value is also adjusted for observable price changes with the same or similar security from the same issuer. The amount of these equity investments without readily determinable fair value included in other assets was $12.6 million and $2.9 million as of March 31, 2023 and 2022, respectively. During fiscal year 2023, the Company recorded an unrealized gain, before tax, of $6.9 million for its investment in a private company as a result of observable price changes for similar securities issued by this

[0001032975-23-000021:notes:217]
company (level 2 fair value measurement). There was no impairment of these investments during fiscal year 2022 and the impairment charges related to these investments were not material during fiscal years 2023 and 2021.

[0001032975-23-000021:notes:218]
Non-Financial Assets. Goodwill, intangible assets, and property, plant and equipment, are not required to be measured at fair value on a recurring basis. However, if the Company is required to evaluate these non-financial assets for impairment, whether due to certain triggering events or because of the required annual impairment test, and a resulting impairment is recorded to reduce the carrying value to the fair value, the non-financial assets are measured at fair value during such period. See Note 2 for additional information about how the Company tests various asset classes for impairment. There was no impairment of non-financial assets during the fiscal years of 2023 and 2021. During fiscal year 2022, the Company recorded impairment charges of $7.0 million for the Jaybird-related intangible assets (see Note 11).


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001032975-23-000021:notes:219]
Derivative Financial Instruments
 Under certain agreements with the respective counterparties to the Company's derivative contracts, subject to applicable requirements, the Company is allowed to net settle transactions of the same type with a single net amount payable by one party to the other. However, the Company presents its derivative assets and derivative liabilities on a gross basis in other current assets and accrued and other current liabilities on the consolidated balance sheets as of March 31, 2023 and 2022. See Note 9 for the fair values of the Company’s derivative instruments as of March 31, 2023 and 2022.

[0001032975-23-000021:notes:220]
Cash Flow Hedges

[0001032975-23-000021:notes:221]
The Company enters into cash flow hedge contracts to protect against exchange rate exposure of forecasted inventory purchases. These hedging contracts mature within approximately four months. Gains and losses in the fair value of the effective portion of the hedges are deferred as a component of accumulated other comprehensive loss until the hedged inventory purchases are sold, at which time the gains or losses are reclassified to cost of goods sold. Cash flows from such hedges are classified as operating activities in the consolidated statements of cash flows. Hedging relationships are discontinued when hedging contract is no longer eligible for hedge accounting, or is sold, terminated or exercised, or when the Company removes hedge designation for the contract. Gains and losses in the fair value of the effective portion of the discontinued hedges continue to be reported in accumulated other comprehensive loss until the hedged inventory purchases are sold, unless it is probable that the forecasted inventory purchases will not occur by the end of the originally specified time period or within an additional two-month period of time thereafter.

[0001032975-23-000021:notes:222]
The notional amounts of foreign currency exchange forward contracts outstanding related to forecasted inventory purchases were $72.6 million and $125.4 million as of March 31, 2023 and 2022, respectively. The Company had $3.9 million of net losses related to its cash flow hedges included in accumulated other comprehensive loss as of March 31, 2023, which will be reclassified into earnings within the next twelve months.

[0001032975-23-000021:notes:223]
The following table presents the amounts of gain (loss) on the Company's derivative instruments designated as hedging instruments for fiscal years 2023, 2022 and 2021 and their locations on its consolidated statements of operations and consolidated statements of comprehensive income (in thousands):

[0001032975-23-000021:notes:224]
|  | Amount ofGain (Loss) Deferred asa Component ofAccumulated OtherComprehensive Loss |  | Amount of Loss (Gain)Reclassified fromAccumulated OtherComprehensive Lossto Costs of Goods Sold |  |  |
|  | 2023 |  | 2022 |  | 2021 |  | 2023 |  | 2022 |  | 2021 |  |  |  |  |  |  |
| Cash flow hedges | $ | 2,625 |  | $ | 6,308 |  |  | $ | (4,071) |  |  | $ | (8,391) |  |  | $ | (8,221) |  |  | $ | 8,043 |  |  |  |  |  |  |  |

[0001032975-23-000021:notes:225]
The Company presents the earnings impact from forward points in the same line item that is used to present the earnings impact of the hedged item, i.e. cost of goods sold, for hedging forecasted inventory purchases and such amount is not material for all periods presented.

[0001032975-23-000021:notes:226]
Other Derivatives

[0001032975-23-000021:notes:227]
The Company also enters into foreign currency exchange forward and swap contracts to reduce the short-term effects of currency exchange rate fluctuations on certain receivables or payables denominated in currencies other than the functional currencies of its subsidiaries. These contracts generally mature within approximately a month. The primary risk managed by using forward and swap contracts is the currency exchange rate risk. The gains or losses on these contracts are not material and included in other income (expense), net in the consolidated statements of operations based on the changes in fair value. The notional amounts of these contracts outstanding as of March 31, 2023 and 2022 were $111.2 million and $226.5 million, respectively. Foreign currency exchange forward and swap contracts outstanding as of March 31, 2023 primarily consisted of contracts in Brazilian Real, Japanese Yen, and Mexican Peso to be settled at future dates at pre-determined exchange rates.

[0001032975-23-000021:notes:228]
The fair value of all foreign currency exchange forward and swap contracts is determined based on observable market transactions of spot currency rates and forward rates. Cash flows from these contracts are classified as operating activities in the consolidated statements of cash flows.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001032975-23-000021:notes:229]
Goodwill and Other Intangible Assets
The Company conducts its impairment analysis of goodwill annually at December 31 or more frequently if changes in facts and circumstances indicate that it is more likely than not that the fair value of the Company’s reporting unit may be less than its carrying amount. The Company conducted its annual impairment analysis of goodwill as of December 31, 2022 by performing a qualitative assessment and concluded that it was more likely than not that the fair value of its reporting unit exceeded its carrying amount. In assessing the qualitative factors, the Company considered the impact of change in industry and competitive environment, the Company's market capitalization and budgeted-to-actual revenue performance for the twelve months ended December 31, 2022. There have been no triggering events identified affecting the valuation of goodwill subsequent to the annual impairment test.

[0001032975-23-000021:notes:230]
The following table summarizes the activities in the Company's goodwill balance (in thousands):

[0001032975-23-000021:notes:231]
|  |  | Years Ended March 31, |
|  |  | 2023 |  | 2022 |
| Beginning of the period |  | $ | 448,175 |  |  | $ | 429,604 |  |
| Acquisitions |  | 7,976 |  |  | 20,721 |  |
| Effects of foreign currency translation |  | (1,541) |  |  | (2,150) |  |
| End of the period |  | $ | 454,610 |  |  | $ | 448,175 |  |

[0001032975-23-000021:notes:232]
The Company's acquired intangible assets were as follows (in thousands):

[0001032975-23-000021:notes:233]
|  |  | March 31, |
|  |  | 2023 |  | 2022 |
|  |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |
| Trademarks and trade names |  | $ | 36,790 |  |  | $ | (26,774) |  |  | $ | 10,016 |  |  | $ | 36,790 |  |  | $ | (22,295) |  |  | $ | 14,495 |  |
| Developed technology |  | 121,730 |  |  | (94,792) |  |  | 26,938 |  |  | 119,407 |  |  | (83,540) |  |  | 35,867 |  |
| Customer contracts/relationships |  | 71,110 |  |  | (47,688) |  |  | 23,422 |  |  | 71,110 |  |  | (40,971) |  |  | 30,139 |  |
| In-process R&D |  | 3,526 |  |  | — |  |  | 3,526 |  |  | 3,826 |  |  | — |  |  | 3,826 |  |
| Effects of foreign currency translation |  | (1,021) |  |  | 292 |  |  | (729) |  |  | (634) |  |  | 86 |  |  | (548) |  |
| Total |  | $ | 232,135 |  |  | $ | (168,962) |  |  | $ | 63,173 |  |  | $ | 230,499 |  |  | $ | (146,720) |  |  | $ | 83,779 |  |

[0001032975-23-000021:notes:234]
During fiscal year 2022, the Company recognized a pre-tax impairment charge of $7.0 million to Jaybird-related intangible assets, primarily related to customer contracts and relationships, as a result of its decision to discontinue Jaybird-branded products.

[0001032975-23-000021:notes:235]
For fiscal years 2023, 2022 and 2021, amortization expense for intangible assets was $24.4 million, $30.2 million and $31.8 million, respectively. The Company expects that annual amortization expense for fiscal years 
2024, 2025, 2026, 2027 and 2028 will be $20.3 million, $18.2 million, $11.9 million, $4.9 million and $3.3 million, respectively, and $1.0 million thereafter.


## us-gaap:DebtDisclosureTextBlock

[0001032975-23-000021:notes:236]
Financing ArrangementsThe Company had several uncommitted, unsecured bank lines of credit aggregating $181.3 million and $195.0 million as of March 31, 2023 and 2022, respectively. There are no financial covenants under these lines of credit with which the Company must comply. As of March 31, 2023 and 2022, the Company had outstanding bank guarantees of $13.6 million and $25.5 million, respectively, under these lines of credit. There was no borrowing outstanding under these lines of credit as of March 31, 2023 and 2022.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001032975-23-000021:notes:237]
Commitments and Contingencies
Product Warranties

[0001032975-23-000021:notes:238]
Changes in the Company's warranty liabilities for fiscal years 2023 and 2022 were as follows (in thousands):

[0001032975-23-000021:notes:239]
|  |  | Years Ended March 31, |
|  |  | 2023 |  | 2022 |
| Beginning of the period |  | $ | 46,219 |  |  | $ | 48,832 |  |
| Provision |  | 31,089 |  |  | 29,812 |  |
| Settlements |  | (35,919) |  |  | (32,082) |  |
| Effects of foreign currency translation |  | (503) |  |  | (343) |  |
| End of the period |  | $ | 40,886 |  |  | $ | 46,219 |  |

[0001032975-23-000021:notes:240]
Indemnifications

[0001032975-23-000021:notes:241]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys' fees. As of March 31, 2023, no material amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

[0001032975-23-000021:notes:242]
The Company also indemnifies its current and former directors and certain of its current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. The Company is unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not limited, the obligations are conditional in nature and the facts and circumstances involved in any situation that might arise are variable.

[0001032975-23-000021:notes:243]
Legal Proceedings

[0001032975-23-000021:notes:244]
From time to time the Company is involved in claims and legal proceedings that arise in the ordinary course of its business. The Company is currently subject to several such claims and a small number of legal proceedings. The Company believes that these matters lack merit and intends to vigorously defend against them. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company's defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company's business, financial condition, cash flows or results of operations in a particular period. Any claims or proceedings against the Company, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain a necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company's business.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001032975-23-000021:notes:245]
Shareholders' Equity
Share Capital

[0001032975-23-000021:notes:246]
The Company's nominal share capital is CHF 43.3 million, consisting of 173,106,620 issued shares with a par value of CHF 0.25 each, of which 13,763,347 were held in treasury shares as of March 31, 2023.

[0001032975-23-000021:notes:247]
The Company has reserved conditional capital of 25,000,000 shares for potential issuance on the exercise of rights granted under the Company's employee equity incentive plans and additional conditional capital for financing purposes, representing the issuance of up to 25,000,000 shares to cover any conversion rights under a future convertible bond issuance. At the 2020 Annual General Meeting, the shareholders of the Company authorized the Board of Directors to issue up to an additional 17,310,662 shares of the Company until September 9, 2022, which was authorized at the 2022 Annual General Meeting to be extended to September 14, 2024.

[0001032975-23-000021:notes:248]
Dividends

[0001032975-23-000021:notes:249]
Pursuant to Swiss corporate law, the payment of dividends is limited to certain amounts of unappropriated retained earnings (approximately CHF 1.2 billion, or USD equivalent of $1.3 billion as of March 31, 2023) and is subject to shareholder approval.

[0001032975-23-000021:notes:250]
In May 2023, the Board of Directors recommended that the Company pay cash dividends for fiscal year 2023 of CHF 1.06 per share (USD equivalent of approximately $1.16 per share, which would result in a gross aggregate dividend of approximately $184.2 million, based on the exchange rate and shares outstanding, net of treasury shares, on March 31, 2023).

[0001032975-23-000021:notes:251]
In September 2022, the Company paid gross cash dividends of CHF 0.96 (USD equivalent of $0.98) per common share, totaling $158.7 million on the Company's outstanding common shares. In September 2021, the Company paid cash dividends of CHF 0.87 (USD equivalent of $0.95) per common share, totaling $159.4 million on the Company’s outstanding common shares. In September 2020, the Company paid cash dividends of CHF 0.79 (USD equivalent of $0.87) per common share, totaling $146.7 million on the Company's outstanding common shares.

[0001032975-23-000021:notes:252]
Any future dividends will be subject to the approval of the Company's shareholders.

[0001032975-23-000021:notes:253]
Legal Reserves

[0001032975-23-000021:notes:254]
Under Swiss corporate law, a minimum of 5% of the Company's annual net income must be retained in a legal reserve until this legal reserve equals 20% of the Company's issued and outstanding aggregate par value per share capital. These legal reserves represent an appropriation of retained earnings that are not available for distribution and totaled $10.4 million at March 31, 2023 (based on the exchange rate at March 31, 2023).

[0001032975-23-000021:notes:255]
Share Repurchases

[0001032975-23-000021:notes:256]
In May 2020, the Company's Board of Directors approved the 2020 share repurchase program, which authorized the Company to use up to $250.0 million to purchase up to 17.3 million of Logitech shares. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Purchases may be started or stopped at any time without prior notice depending on market conditions and other factors.

[0001032975-23-000021:notes:257]
In April 2021, the Company's Board of Directors approved an increase of $750.0 million of the 2020 share repurchase program, to an aggregate amount of $1.0 billion. The Swiss Takeover Board approved this increase and it became effective on May 21, 2021.

[0001032975-23-000021:notes:258]
In July 2022, the Company’s Board of Directors approved an increase of $500 million to the 2020 share repurchase program, to an aggregate amount of up to $1.5 billion to purchase up to 17.3 million of Logitech shares. The Swiss Takeover Board approved this increase and it became effective on August 19, 2022. The 2020 share repurchase program is expected to remain in effect for a period of three years through July 27, 2023. As of March 31, 2023, $505.8 million was available for repurchase under the 2020 repurchase program.

[0001032975-23-000021:notes:259]
A summary of the approved and active share repurchase program in fiscal year 2023 is shown in the following table (in thousands, excluding transaction costs):

[0001032975-23-000021:notes:260]
|  |  | Approved |  | Repurchased |
| Share Repurchase Program |  | Shares (1) |  | Amounts |  | Shares |  | Amounts |
| May 2020 |  | 17,311 |  |  | $ | 1,500,000 |  |  | 14,014 |  |  | $ | 994,156 |  |

[0001032975-23-000021:notes:261]
(1) The approval of the share repurchase program by the Swiss Takeover Board limits the number of shares that the Company may repurchase to no more than 10% of its authorized share capital and voting rights.

[0001032975-23-000021:notes:262]
Accumulated Other Comprehensive Loss

[0001032975-23-000021:notes:263]
The components of accumulated other comprehensive loss were as follows (in thousands):

[0001032975-23-000021:notes:264]
|  |  | Currency TranslationAdjustment |  | DefinedBenefitPlans |  | DeferredHedgingGains (Losses) |  | Total |
| March 31, 2022 |  | $ | (102,461) |  |  | $ | (3,495) |  |  | $ | 1,833 |  |  | $ | (104,123) |  |
| Other comprehensive income (loss) |  | 1,592 |  |  | 8,020 |  |  | (5,766) |  |  | 3,846 |  |
| March 31, 2023 |  | $ | (100,869) |  |  | $ | 4,525 |  |  | $ | (3,933) |  |  | $ | (100,277) |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001032975-23-000021:notes:265]
Segment Information
The Company operates in a single operating segment that encompasses the design, manufacturing and marketing of peripherals for PCs, tablets, gaming, video conferencing, and other digital platforms. Operating performance measures are provided directly to the Company's CEO, who is considered to be the Company’s Chief Operating Decision Maker. The CEO periodically reviews information such as sales and adjusted operating income (loss) to make business decisions. These operating performance measures do not include restructuring charges (credits), net, share-based compensation expense, amortization and impairment of intangible assets, acquisition-related costs and change in fair value of contingent consideration from business acquisitions.

[0001032975-23-000021:notes:266]
Sales by product categories were as follows (in thousands):

[0001032975-23-000021:notes:267]
|  |  | Years Ended March 31, |
|  |  | 2023 |  | 2022 |  | 2021 |
| Pointing Devices |  | $ | 728,357 |  |  | $ | 781,108 |  |  | $ | 680,907 |  |
| Keyboards & Combos |  | 836,432 |  |  | 967,301 |  |  | 784,488 |  |
| PC Webcams |  | 227,692 |  |  | 403,651 |  |  | 439,865 |  |
| Tablet & Other Accessories |  | 254,374 |  |  | 310,123 |  |  | 384,301 |  |
| Gaming (1) |  | 1,211,485 |  |  | 1,451,883 |  |  | 1,239,005 |  |
| Video Collaboration |  | 887,517 |  |  | 997,164 |  |  | 1,044,935 |  |
| Mobile Speakers |  | 111,649 |  |  | 149,782 |  |  | 174,895 |  |
| Audio & Wearables |  | 274,231 |  |  | 401,424 |  |  | 468,776 |  |
| Other (2) |  | 7,081 |  |  | 18,665 |  |  | 35,107 |  |
| Total Sales |  | $ | 4,538,818 |  |  | $ | 5,481,101 |  |  | $ | 5,252,279 |  |

[0001032975-23-000021:notes:268]
(1) Gaming includes streaming services revenue generated by Streamlabs.

[0001032975-23-000021:notes:269]
(2) Other includes Smart Home.

[0001032975-23-000021:notes:270]
Sales by geographic region (based on the customers' locations) for fiscal years 2023, 2022 and 2021 were as follows (in thousands):

[0001032975-23-000021:notes:271]
|  |  | Years Ended March 31, |
|  |  | 2023 |  | 2022 |  | 2021 |
| Americas |  | $ | 1,930,908 |  |  | $ | 2,317,941 |  |  | $ | 2,206,552 |  |
| EMEA |  | 1,299,657 |  |  | 1,724,027 |  |  | 1,735,682 |  |
| Asia Pacific |  | 1,308,253 |  |  | 1,439,133 |  |  | 1,310,045 |  |
| Total Sales |  | $ | 4,538,818 |  |  | $ | 5,481,101 |  |  | $ | 5,252,279 |  |

[0001032975-23-000021:notes:272]
Revenues from sales to customers in the United States represented 35%, 34% and 35% of sales in fiscal years 2023, 2022 and 2021, respectively. Revenues from sales to customers in Germany represented 14%, 15% and 16% of sales in fiscal years 2023, 2022 and 2021, respectively. Revenues from sales to customers in China represented 11% and 10% of sales in fiscal years 2023 and 2022, respectively. No other country represented more

[0001032975-23-000021:notes:273]
than 10% of sales during these periods presented herein. Revenues from sales to customers in Switzerland, the Company's country of domicile, represented 3% of sales in each of fiscal years 2023, 2022 and 2021.

[0001032975-23-000021:notes:274]
Property, plant and equipment, net (excluding software) and right-of-use assets by geographic region were as follows (in thousands):

[0001032975-23-000021:notes:275]
|  |  | March 31, |
|  |  | 2023 |  | 2022 |
| Americas |  | $ | 59,183 |  |  | $ | 22,578 |  |
| EMEA |  | 38,890 |  |  | 23,830 |  |
| Asia Pacific |  | 69,939 |  |  | 87,265 |  |
| Total |  | $ | 168,012 |  |  | $ | 133,673 |  |

[0001032975-23-000021:notes:276]
Property, plant and equipment, net (excluding software) and right-of-use assets in the United States, China, and Ireland were $58.7 million, $48.8 million, and $17.7 million, respectively, as of March 31, 2023. Property, plant and equipment, net (excluding software) and right-of-use assets in the United States and China were $21.7 million and $66.8 million, respectively, as of March 31, 2022. Property, plant and equipment, net (excluding software) and right-of-use assets in Switzerland, the Company's country of domicile, were $13.7 million and $13.6 million as of March 31, 2023 and 2022, respectively. No other countries represented more than 10% of the Company's total consolidated property, plant and equipment, net (excluding software) and right-of-use assets as of March 31, 2023 or 2022.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001032975-23-000021:notes:277]
Restructuring 
The following table summarizes restructuring-related activities during fiscal years 2023 and 2022 (in thousands):

[0001032975-23-000021:notes:278]
|  |  | TerminationBenefits |  | Contract Termination and Other |  | Total |  |
| Accrued restructuring liability at March 31, 2021 (1) |  | $ | 627 |  |  | $ | — |  |  | $ | 627 |  |  |
| Charges, net |  | 879 |  |  | 1,286 |  |  | 2,165 |  |  |
| Cash payments |  | (945) |  |  | (390) |  |  | (1,335) |  |  |
| Accrued restructuring liability at March 31, 2022 (1) |  | $ | 561 |  |  | $ | 896 |  |  | $ | 1,457 |  |  |
| Charges, net |  | 27,631 |  |  | 6,942 |  |  | 34,573 |  |  |
| Cash payments |  | (14,015) |  |  | (2,481) |  |  | (16,496) |  |  |
| Accrued restructuring liability at March 31, 2023 (1) |  | $ | 14,177 |  |  | $ | 5,357 |  |  | $ | 19,534 |  |  |

[0001032975-23-000021:notes:279]
(1) The accrual balances are included in accrued and other current liabilities on the Company’s consolidated balance sheets.

[0001032975-23-000021:notes:280]
During the second quarter of fiscal year 2023, the Company initiated a restructuring plan to realign its business group and engineering structure with its go-to-market strategy to more effectively compete within the enterprise market and to better serve end-users. During the fourth quarter of fiscal year 2023, the Company undertook further actions to remove organization layers as well as streamline its marketing organization to increase efficiency. These actions resulted in charges related to employee severance and other termination benefits as well as contract termination and other costs. The Company recorded pre-tax charges totaling $34.6 million in restructuring charges, net in the consolidated statement of operations for the year ended March 31, 2023. The Company expects to substantially complete these restructuring activities within the next twelve months.

[0001032975-23-000021:notes:281]
During the third quarter of fiscal year 2022, as part of the Company's strategic review, the Company decided to cease future product launches under the Jaybird brand within the Audio & Wearables product category. As a result, the Company recorded $7.6 million in cost of goods sold related to write-offs for excess inventories, $7.0 million impairment to the intangible assets acquired as part of the Jaybird acquisition (see Note 11), and $2.2 million in restructuring charges, net, related to production cancellation costs and employee severance and other termination benefits, for the year ended March 31, 2022. This restructuring plan has been substantially completed during fiscal year 2023.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001032975-23-000021:notes:282]
Leases
The Company is a lessee in various noncancellable operating leases, primarily real estate facilities for office space. As of March 31, 2023, the Company's lease arrangements are comprised of operating leases with various expiration dates through November 30, 2033. The lease term for all of the Company’s leases includes the noncancellable period of the lease. Certain lease agreements include options to renew or terminate the lease, which are not reasonably certain to be exercised and therefore are not factored into the Company's determination of the duration of the lease arrangement. The Company's leases do not contain any material residual value guarantees.

[0001032975-23-000021:notes:283]
The total operating lease costs including short-term lease costs were $21.2 million, $17.3 million and $15.0 million as of March 31, 2023, 2022, and 2021, respectively. Total variable lease costs were not material during the year ended March 31, 2023, 2022 and 2021. The total operating and variable lease costs were included in cost of goods sold, marketing and selling, research and development, and general and administrative in the Company's consolidated statements of operations.

[0001032975-23-000021:notes:284]
Supplemental cash flow information related to operating leases (in thousands):

[0001032975-23-000021:notes:285]
|  | Years Ended March 31, |
|  | 2023 |  | 2022 |  | 2021 |
| Cash paid for amounts included in the measurement of operating lease liabilities | $ | 16,565 |  |  | $ | 15,400 |  |  | $ | 13,865 |  |
| ROU assets obtained in the exchange for operating lease liabilities | $ | 43,093 |  |  | $ | 22,174 |  |  | $ | 15,659 |  |

[0001032975-23-000021:notes:286]
Future lease payments included in the measurement of operating lease liabilities as of March 31, 2023 for the following five fiscal years and thereafter are as follows (in thousands):

[0001032975-23-000021:notes:287]
| Years Ending March 31, |  |
| 2024 | $ | 13,409 |  |
| 2025 | 13,657 |  |
| 2026 | 10,769 |  |
| 2027 | 10,155 |  |
| 2028 | 9,107 |  |
| Thereafter | 40,889 |  |
| Total lease payments | $ | 97,986 |  |
| Less: imputed interest | (15,416) |  |
| Less: tenant improvement allowance (1) | (11,554) |  |
| Present value of lease liabilities | $ | 71,016 |  |

[0001032975-23-000021:notes:288]
(1) The operating leases for two real estate facilities in the Americas region provide for tenant improvement allowances, for which the lessors reimburse the Company for the costs of constructing leasehold improvements up to $11.6 million.

[0001032975-23-000021:notes:289]
Weighted-average lease terms and discount rates were as follows:

[0001032975-23-000021:notes:290]
|  | Years Ended March 31, |
|  | 2023 |  | 2022 |
| Weighted-average remaining lease terms (in years) | 8.1 |  | 4.6 |
| Weighted-average discount rate | 3.7 | % |  | 2.8 | % |


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001032975-23-000021:notes:291]
VALUATION AND QUALIFYING ACCOUNTS

[0001032975-23-000021:notes:292]
For the Fiscal Years Ended March 31, 2023, 2022 and 2021 (in thousands)

[0001032975-23-000021:notes:293]
The Company's Schedule II includes valuation and qualifying accounts related to allowances for doubtful accounts, sales returns, cooperative marketing arrangements, customer incentive programs, and pricing programs, for direct customers and tax valuation allowances. The Company also has sales incentive programs for indirect customers with whom it does not have a direct sales and receivable relationship. These programs are recorded as accrued liabilities and are not considered valuation or qualifying accounts.

[0001032975-23-000021:notes:294]
|  |  | Balance atBeginning ofYear |  | Charged(Credited) to Statement ofOperations (1) |  | Claims andAdjustmentsApplied AgainstAllowances (1) |  | Balance atEnd ofYear |
| Allowance for doubtful accounts: |  |  |  |  |  |  |  |  |
| 2023 |  | $ | 2,212 |  |  | $ | (2,019) |  |  | $ | (107) |  |  | $ | 86 |  |
| 2022 |  | $ | 1,161 |  |  | $ | 1,691 |  |  | $ | (640) |  |  | $ | 2,212 |  |
| 2021 |  | $ | 1,894 |  |  | $ | (533) |  |  | $ | (200) |  |  | $ | 1,161 |  |
| Allowance for sales returns: |  |  |  |  |  |  |  |  |
| 2023 |  | $ | 12,321 |  |  | $ | 157,619 |  |  | $ | (159,794) |  |  | $ | 10,146 |  |
| 2022 |  | $ | 14,438 |  |  | $ | 162,381 |  |  | $ | (164,498) |  |  | $ | 12,321 |  |
| 2021 |  | $ | 6,599 |  |  | $ | 122,803 |  |  | $ | (114,964) |  |  | $ | 14,438 |  |
| Allowance for cooperative marketing arrangements: |  |  |  |  |  |  |  |  |
| 2023 |  | $ | 56,372 |  |  | $ | 262,363 |  |  | $ | (278,240) |  |  | $ | 40,495 |  |
| 2022 |  | $ | 43,276 |  |  | $ | 286,116 |  |  | $ | (273,020) |  |  | $ | 56,372 |  |
| 2021 |  | $ | 38,794 |  |  | $ | 222,732 |  |  | $ | (218,250) |  |  | $ | 43,276 |  |
| Allowance for customer incentive programs: |  |  |  |  |  |  |  |  |
| 2023 |  | $ | 97,460 |  |  | $ | 329,666 |  |  | $ | (355,481) |  |  | $ | 71,645 |  |
| 2022 |  | $ | 76,200 |  |  | $ | 348,072 |  |  | $ | (326,812) |  |  | $ | 97,460 |  |
| 2021 |  | $ | 55,741 |  |  | $ | 256,755 |  |  | $ | (236,296) |  |  | $ | 76,200 |  |
| Allowance for pricing programs: |  |  |  |  |  |  |  |  |
| 2023 |  | $ | 120,797 |  |  | $ | 784,835 |  |  | $ | (806,810) |  |  | $ | 98,822 |  |
| 2022 |  | $ | 120,568 |  |  | $ | 885,228 |  |  | $ | (884,999) |  |  | $ | 120,797 |  |
| 2021 |  | $ | 100,168 |  |  | $ | 782,734 |  |  | $ | (762,334) |  |  | $ | 120,568 |  |
| Tax valuation allowance: |  |  |  |  |  |  |  |  |
| 2023 |  | $ | 29,858 |  |  | $ | 908 |  |  | $ | — |  |  | $ | 30,766 |  |
| 2022 |  | $ | 28,926 |  |  | $ | 887 |  |  | $ | 45 |  |  | $ | 29,858 |  |
| 2021 |  | $ | 29,171 |  |  | $ | (245) |  |  | $ | — |  |  | $ | 28,926 |  |

[0001032975-23-000021:notes:295]
(1) The amounts for fiscal years 2023, 2022 and 2021 include immaterial impacts from the business acquisitions during the year.
