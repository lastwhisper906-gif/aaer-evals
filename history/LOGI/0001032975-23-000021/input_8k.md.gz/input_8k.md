# LOGI 8-K — 0001032975-23-000015 filed 2023-05-02

## item codes, every 8-K on or before 2023-05-17

- 2023-05-02 0001032975-23-000015 — 2.02, 9.01
- 2023-01-30 0001032975-23-000010 — 5.02, 9.01
- 2023-01-24 0001032975-23-000004 — 2.02, 5.02, 9.01
- 2023-01-12 0001628280-23-000934 — 2.02, 9.01
- 2022-10-25 0001628280-22-026927 — 2.02, 5.02, 9.01
- 2022-09-16 0001628280-22-025080 — 5.07, 8.01
- 2022-07-26 0001032975-22-000027 — 2.02, 9.01
- 2022-06-29 0001032975-22-000018 — 5.02
- 2022-05-03 0001032975-22-000008 — 2.02, 9.01
- 2022-01-25 0001032975-22-000003 — 2.02, 9.01
- 2021-10-26 0001032975-21-000043 — 2.02, 9.01
- 2021-09-10 0001032975-21-000040 — 5.07, 8.01
- 2021-07-27 0001032975-21-000029 — 2.02, 9.01
- 2021-04-29 0001032975-21-000012 — 2.02, 9.01
- 2021-01-19 0001032975-21-000004 — 2.02, 9.01
- 2020-10-20 0001032975-20-000045 — 2.02, 9.01
- 2020-09-11 0001032975-20-000042 — 5.07, 8.01
- 2020-07-21 0001032975-20-000029 — 2.02, 9.01
- 2020-07-01 0001032975-20-000023 — 5.02, 8.01
- 2020-05-12 0001032975-20-000011 — 2.02, 9.01
- 2020-03-30 0001032975-20-000009 — 5.02
- 2020-01-21 0001032975-20-000002 — 2.02, 9.01
- 2019-10-22 0001032975-19-000071 — 9.01
- 2019-09-26 0001032975-19-000068 — 1.01, 7.01, 9.01
- 2019-09-06 0001032975-19-000063 — 5.07, 8.01
- 2019-07-23 0001032975-19-000046 — 2.02, 9.01
- 2019-07-23 0001032975-19-000045 — 5.02, 9.01
- 2019-07-02 0001032975-19-000036 — 5.02
- 2019-06-25 0001032975-19-000034 — 5.02
- 2019-05-03 0001032975-19-000021 — 5.02 — amendment, the index does not say of what
- 2019-04-30 0001032975-19-000017 — 2.02, 5.02, 9.01
- 2019-03-28 0001032975-19-000013 — 5.02
- 2019-01-22 0001032975-19-000004 — 2.02, 9.01
- 2018-10-23 0001032975-18-000044 — 2.02, 9.01
- 2018-09-07 0001032975-18-000040 — 5.07, 8.01
- 2018-07-31 0001032975-18-000035 — 1.01, 2.02, 2.05, 7.01, 9.01
- 2018-06-27 0001032975-18-000020 — 5.02
- 2018-05-03 0001032975-18-000013 — 2.02, 5.02, 9.01
- 2018-01-23 0001032975-18-000005 — 2.02, 9.01
- 2017-10-24 0001032975-17-000043 — 2.02, 9.01
- 2017-09-18 0001032975-17-000040 — 5.07, 8.01
- 2017-07-25 0001032975-17-000028 — 2.02, 9.01
- 2017-07-12 0001032975-17-000022 — 1.01
- 2017-04-26 0001032975-17-000012 — 2.02, 9.01
- 2017-01-25 0001032975-17-000002 — 2.02, 9.01
- 2016-10-26 0001032975-16-000103 — 2.02, 9.01
- 2016-09-13 0001032975-16-000101 — 5.07, 8.01
- 2016-07-28 0001032975-16-000092 — 2.02, 9.01
- 2016-06-30 0001032975-16-000087 — 5.02
- 2016-04-28 0001032975-16-000077 — 2.02, 9.01
- 2016-04-14 0001032975-16-000073 — 1.01, 7.01, 9.01
- 2016-01-21 0001032975-16-000064 — 2.02, 9.01
- 2016-01-04 0001032975-16-000061 — 1.01, 2.01, 9.01
- 2015-12-23 0001032975-15-000059 — 5.02
- 2015-10-22 0001032975-15-000047 — 2.02, 9.01
- 2015-09-11 0001032975-15-000044 — 5.07, 8.01
- 2015-07-24 0001032975-15-000034 — 2.05 — amendment of 0001032975-15-000030
- 2015-07-23 0001032975-15-000030 — 2.02, 9.01
- 2015-06-25 0001032975-15-000025 — 5.02
- 2015-05-14 0001032975-15-000011 — 8.01, 9.01
- 2015-04-23 0001032975-15-000008 — 2.02, 2.05
- 2015-01-22 0001628280-15-000191 — 2.02, 8.01
- 2014-12-23 0001193125-14-450908 — 5.02, 5.07, 8.01
- 2014-11-25 0001193125-14-425233 — 3.01
- 2014-11-13 0001193125-14-411303 — 4.01, 9.01
- 2014-10-23 0001104659-14-073164 — 2.02, 9.01
- 2014-09-04 0001193125-14-331214 — 4.02, 9.01
- 2014-08-18 0001193125-14-313346 — 3.01, 9.01
- 2014-07-24 0001104659-14-053065 — 2.02, 9.01
- 2014-06-05 0001193125-14-226177 — 3.01, 9.01
- 2014-05-22 0001193125-14-208777 — 8.01, 9.01
- 2014-04-24 0001104659-14-029650 — 2.02, 9.01
- 2014-01-23 0001104659-14-003619 — 2.02, 9.01
- 2013-10-24 0001104659-13-077404 — 2.02, 9.01
- 2013-09-09 0001193125-13-361441 — 5.02, 5.07, 8.01, 9.01
- 2013-09-06 0001193125-13-359930 — 5.02, 9.01
- 2013-08-02 0001193125-13-317343 — 5.02
- 2013-07-25 0001104659-13-056372 — 2.02, 9.01
- 2013-06-28 0001193125-13-277394 — 5.02, 9.01
- 2013-06-20 0001193125-13-265914 — 8.01, 9.01
- 2013-04-25 0001104659-13-032570 — 2.02, 9.01
- 2013-04-17 0001193125-13-158923 — 5.02, 9.01
- 2013-03-01 0001193125-13-085804 — 2.05
- 2013-01-24 0001104659-13-004214 — 2.02, 9.01
- 2013-01-02 0001193125-13-000058 — 5.02
- 2012-10-25 0001104659-12-070966 — 2.02, 9.01
- 2012-09-11 0001193125-12-388070 — 5.02, 5.07, 8.01, 9.01
- 2012-08-22 0001193125-12-364167 — 5.02, 8.01, 9.01
- 2012-07-26 0001104659-12-051084 — 2.02, 9.01
- 2012-06-08 0001193125-12-264132 — 2.05, 9.01 — amendment, the index does not say of what
- 2012-04-26 0001193125-12-183657 — 5.02, 9.01
- 2012-04-26 0001104659-12-028470 — 2.02, 2.05, 9.01
- 2012-03-15 0001193125-12-115954 — 5.02, 9.01
- 2012-01-26 0001104659-12-004014 — 2.02, 9.01
- 2012-01-04 0001193125-12-002212 — 1.01, 2.03, 9.01
- 2011-10-27 0001104659-11-058150 — 2.02, 9.01
- 2011-09-12 0001193125-11-245931 — 5.07
- 2011-07-28 0001193125-11-200929 — 5.02, 9.01
- 2011-07-28 0001193125-11-199704 — 2.02, 9.01
- 2011-04-28 0001193125-11-112669 — 2.02, 9.01
- 2011-03-24 0001193125-11-076483 — 5.02, 9.01
- 2011-01-27 0001032975-11-000003 — 9.01
- 2010-10-28 0001032975-10-000032 — 9.01
- 2010-09-13 0001032975-10-000022 — 5.07
- 2010-07-29 0001032975-10-000010 — 2.02, 9.01
- 2010-06-10 0001193125-10-136877 — 5.02, 9.01
- 2010-05-03 0001193125-10-104337 — 5.02
- 2010-04-29 0001032975-10-000008 — 2.02, 9.01
- 2010-02-19 0001032975-10-000006 — 9.01 — amendment of 0001193125-09-252416
- 2010-01-21 0001032975-10-000002 — 2.02, 9.01
- 2009-12-14 0001193125-09-252416 — 2.01, 9.01
- 2009-11-17 0001032975-09-000023 — 1.01
- 2009-10-22 0001032975-09-000018 — 9.01
- 2009-09-22 0001193125-09-195545 — 5.02, 9.01
- 2009-09-03 0001032975-09-000013 — 8.01
- 2009-07-23 0001140361-09-016802 — 2.02, 9.01
- 2009-06-01 0001193125-09-122550 — 5.02
- 2009-04-23 0001193125-09-085054 — 2.02, 9.01
- 2009-04-02 0001193125-09-071272 — 5.02, 9.01
- 2009-01-20 0001193125-09-008454 — 2.05 — amendment of 0001193125-09-002609
- 2009-01-20 0001193125-09-007902 — 2.02, 9.01
- 2009-01-07 0001193125-09-002609 — 2.05, 9.01
- 2009-01-07 0001193125-09-002370 — 5.02, 9.01
- 2008-12-09 0001193125-08-250543 — 5.02, 9.01
- 2008-10-21 0001193125-08-213212 — 2.02, 9.01
- 2008-07-22 0001193125-08-154721 — 2.02, 9.01
- 2008-06-24 0001193125-08-139163 — 5.03, 9.01
- 2008-05-13 0001193125-08-113263 — 5.02, 9.01
- 2008-04-22 0001193125-08-086176 — 2.02, 9.01

## late-filing notifications on or before 2023-05-17

- 2015-06-02 0001032975-15-000020 — NT 10-K, for the period ended 2015-03-31
- 2014-11-06 0001193125-14-401306 — NT 10-Q, for the period ended 2014-09-30
- 2014-07-24 0001193125-14-277575 — NT 10-Q, for the period ended 2014-06-30
- 2014-05-22 0001193125-14-208712 — NT 10-K, for the period ended 2014-03-31
- 2009-08-06 0001032975-09-000006 — NT 10-Q, for the period ended 2009-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001032975-23-000015:8k_2_02:1]
EX-99.1
2
exhibit991q4fy23.htm
EX-99.1

[0001032975-23-000015:8k_2_02:2]
Document

[0001032975-23-000015:8k_2_02:3]
Exhibit 99.1

[0001032975-23-000015:8k_2_02:4]
Editorial Contacts:

[0001032975-23-000015:8k_2_02:5]
Nate Melihercik, Head of Global Investor Relations - ir@logitech.com

[0001032975-23-000015:8k_2_02:6]
Nicole Kenyon, Head of Global Corporate and Internal Communications - nkenyon@logitech.com (USA)

[0001032975-23-000015:8k_2_02:7]
Ben Starkie, Corporate Communications - +41 (0) 79-292-3499, bstarkie1@logitech.com (Europe)

[0001032975-23-000015:8k_2_02:8]
Logitech Announces Q4 and Full Fiscal Year 2023 Results

[0001032975-23-000015:8k_2_02:9]
Company Reaffirms Outlook for First Half of FY 2024

[0001032975-23-000015:8k_2_02:10]
LAUSANNE, Switzerland, May 2, 2023 and NEWARK, Calif., May 1, 2023 —  SIX Swiss Exchange Ad hoc announcement pursuant to Art. 53 LR — Logitech International (SIX: LOGN) (Nasdaq: LOGI) today announced financial results for the fourth quarter and full Fiscal Year 2023, ended March 31, 2023.

[0001032975-23-000015:8k_2_02:11]
For Fiscal Year 2023:

[0001032975-23-000015:8k_2_02:12]
•Sales were $4.54 billion, down 17 percent in US dollars and 13 percent in constant currency, compared to the prior year. This performance reflects the challenging macroeconomic environment and lower enterprise and consumer spending.

[0001032975-23-000015:8k_2_02:13]
•GAAP operating income was $458 million, down 41 percent, compared to the prior year.

[0001032975-23-000015:8k_2_02:14]
Non-GAAP operating income was $589 million, down 35 percent, compared to the prior year.

[0001032975-23-000015:8k_2_02:15]
Despite the decline, operating expenses were prudently reduced, down 17 percent compared to     the prior year, in line with the decline in net sales.

[0001032975-23-000015:8k_2_02:16]
•GAAP earnings per share (EPS) was $2.23, down 41 percent, compared to the prior year.

[0001032975-23-000015:8k_2_02:17]
Non-GAAP EPS was $3.22, down 30 percent, compared to the prior year.

[0001032975-23-000015:8k_2_02:18]
•Cash flow from operations was $534 million, up 79 percent, and the end-of-year cash balance was $1.15 billion. The Company returned $577 million of cash to shareholders through its annual dividend payment and share repurchases.

[0001032975-23-000015:8k_2_02:19]
•These results were within the range of Logitech’s previously provided Fiscal Year 2023 outlook of between 15 percent and 13 percent sales decline in constant currency, and between $550 million and $600 million in non-GAAP operating income.

[0001032975-23-000015:8k_2_02:20]
For Q4 Fiscal Year 2023:

[0001032975-23-000015:8k_2_02:21]
•Sales were $960 million, down 22 percent in US dollars and 20 percent in constant currency, compared to Q4 of the prior year.

[0001032975-23-000015:8k_2_02:22]
•GAAP operating income was $39 million, down 70 percent, compared to Q4 of the prior year. Non-GAAP operating income was $82 million, down 47 percent, compared to Q4 of the prior year.

[0001032975-23-000015:8k_2_02:23]
“Logitech’s Fiscal Year 2023 performance was in line with our revised outlook,” said Bracken Darrell, Logitech president and chief executive officer. “Despite the decline in sales, we are significantly larger than before the pandemic. We are focused on our long-term strategy, building out our capabilities and capitalizing on the trends that fuel our business - video collaboration, hybrid work, gaming and digital content creation. These trends continue to offer a great opportunity for us to design outstanding, seamless experiences for people to work, play and create from anywhere.”

[0001032975-23-000015:8k_2_02:24]
“We begin Fiscal Year 2024 on solid footing, with a robust balance sheet, improved inventory levels, strong cash flow and no debt,” said Charles Boynton, Logitech chief financial officer. “We have proactively controlled expenses to align our operating costs with reduced revenue. While macro conditions remain uncertain, we reaffirm our outlook for the first half of the new fiscal year.”

[0001032975-23-000015:8k_2_02:25]
Outlook

[0001032975-23-000015:8k_2_02:26]
Logitech confirmed its outlook for the first half of Fiscal Year 2024:

[0001032975-23-000015:8k_2_02:27]
|  |  | H1 2024 outlook |
| Sales |  | $1.8 billion - $1.9 billion |
| Sales decline (in US dollars, year over year) |  | 22% - 18% |
| Non-GAAP operating income |  | $160 million - $190 million |

[0001032975-23-000015:8k_2_02:28]
Prepared Remarks Available Online

[0001032975-23-000015:8k_2_02:29]
Logitech has made its prepared written remarks for the financial results videoconference available online on the Logitech corporate website at http://ir.logitech.com.

[0001032975-23-000015:8k_2_02:30]
Financial Results Videoconference and Webcast

[0001032975-23-000015:8k_2_02:31]
Logitech will hold a financial results videoconference to discuss the results for Q4 and the full Fiscal Year 2023 on Tuesday, May 2, 2023 at 8:30 a.m. Eastern Daylight Time and 2:30 p.m. Central European Summer Time. A livestream of the event will be available on the Logitech corporate website at http://ir.logitech.com.

[0001032975-23-000015:8k_2_02:32]
Use of Non-GAAP Financial Information and Constant Currency

[0001032975-23-000015:8k_2_02:33]
To facilitate comparisons to Logitech’s historical results, Logitech has included non-GAAP adjusted measures in this press release, which exclude share-based compensation expense, amortization of intangible assets, acquisition-related costs, impairment of intangible assets, change in fair value of contingent consideration for business acquisition, restructuring charges, loss on investments, pension curtailment gains, non-GAAP income tax adjustment, and other items detailed under “Supplemental Financial Information” after the tables below and posted to our website at http://ir.logitech.com. Logitech also presents percentage sales growth in constant currency (“CC”), a non-GAAP measure, to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales. Logitech believes this information, used together with the GAAP financial information, will help investors to evaluate its current period performance, outlook and trends in its business. With respect to the Company’s outlook for non-GAAP operating income, most of these excluded amounts pertain to events that have not yet occurred and are not currently possible to estimate with a reasonable degree of accuracy. Therefore, no reconciliation to the GAAP amounts has been provided for the first half of Fiscal Year 2024 non-GAAP operating income outlook.

[0001032975-23-000015:8k_2_02:34]
Public Dissemination of Certain Information

[0001032975-23-000015:8k_2_02:35]
Logitech webcasts its earnings calls, and certain events Logitech participates in or hosts, with members of the investment community on its investor relations website at http://ir.logitech.com. Additionally, Logitech provides notifications of news or announcements regarding its operations and financial performance, including its filings with the Securities and Exchange Commission (SEC), investor events, and press and earnings releases as part of its investor relations website. Logitech intends to use its investor relations website as means of disclosing material nonpublic information and for complying with its disclosure obligations under Regulation FD. Logitech’s corporate governance information also is available on its investor relations website.

[0001032975-23-000015:8k_2_02:36]
About Logitech

[0001032975-23-000015:8k_2_02:37]
Logitech helps all people pursue their passions and is committed to doing so in a way that is good for people and the planet. We design hardware and software solutions that help businesses thrive and bring people together when working, creating, gaming and streaming. Brands of Logitech include Logitech, Logitech G, ASTRO Gaming, Streamlabs, Blue Microphones and Ultimate Ears. Founded in 1981, and headquartered in Lausanne, Switzerland, Logitech International is a Swiss public company listed on the SIX Swiss Exchange (LOGN) and on the Nasdaq Global Select Market (LOGI). Find Logitech at www.logitech.com, the company blog or @logitech.

[0001032975-23-000015:8k_2_02:38]
# # #

[0001032975-23-000015:8k_2_02:39]
Note that unless noted otherwise, comparisons are year over year.

[0001032975-23-000015:8k_2_02:40]
Logitech and other Logitech marks are trademarks or registered trademarks of Logitech Europe S.A. and/or its affiliates in the U.S. and other countries. All other trademarks are the property of their respective owners. For more information about Logitech and its products, visit the company’s website at http://ir.logitech.com.

[0001032975-23-000015:8k_2_02:41]
(LOGIIR)

[0001032975-23-000015:8k_2_02:42]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  | Fiscal Years Ended |
|  |  | March 31, |  | March 31, |
| GAAP CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Net sales |  | $ | 960,077 |  |  | $ | 1,229,994 |  |  | $ | 4,538,818 |  |  | $ | 5,481,101 |  |
| Cost of goods sold |  | 612,703 |  |  | 733,092 |  |  | 2,806,438 |  |  | 3,204,072 |  |
| Amortization of intangible assets |  | 3,510 |  |  | 2,995 |  |  | 12,865 |  |  | 14,023 |  |
| Gross profit |  | 343,864 |  |  | 493,907 |  |  | 1,719,515 |  |  | 2,263,006 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Marketing and selling |  | 181,060 |  |  | 247,017 |  |  | 809,182 |  |  | 1,025,899 |  |
| Research and development |  | 70,630 |  |  | 78,408 |  |  | 280,796 |  |  | 291,844 |  |
| General and administrative |  | 32,437 |  |  | 36,357 |  |  | 124,652 |  |  | 148,648 |  |
| Amortization of intangible assets and acquisition-related costs |  | 2,791 |  |  | 2,961 |  |  | 11,843 |  |  | 16,947 |  |
| Impairment of intangible assets |  | — |  |  | — |  |  | — |  |  | 7,000 |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | — |  |  | — |  |  | (3,509) |  |
| Restructuring charges, net |  | 18,102 |  |  | 395 |  |  | 34,573 |  |  | 2,165 |  |
| Total operating expenses |  | 305,020 |  |  | 365,138 |  |  | 1,261,046 |  |  | 1,488,994 |  |
| Operating income |  | 38,844 |  |  | 128,769 |  |  | 458,469 |  |  | 774,012 |  |
| Interest income |  | 8,758 |  |  | 451 |  |  | 18,331 |  |  | 1,246 |  |
| Other income (expense), net |  | 5,089 |  |  | 2,501 |  |  | (13,278) |  |  | 560 |  |
| Income before income taxes |  | 52,691 |  |  | 131,721 |  |  | 463,522 |  |  | 775,818 |  |
| Provision for income taxes |  | 11,196 |  |  | 23,516 |  |  | 98,947 |  |  | 131,305 |  |
| Net income |  | $ | 41,495 |  |  | $ | 108,205 |  |  | $ | 364,575 |  |  | $ | 644,513 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.26 |  |  | $ | 0.65 |  |  | $ | 2.25 |  |  | $ | 3.85 |  |
| Diluted |  | $ | 0.26 |  |  | $ | 0.64 |  |  | $ | 2.23 |  |  | $ | 3.78 |  |
| Weighted average shares used to compute net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | 160,073 |  |  | 165,898 |  |  | 162,302 |  |  | 167,447 |  |
| Diluted |  | 161,524 |  |  | 168,546 |  |  | 163,704 |  |  | 170,414 |  |

[0001032975-23-000015:8k_2_02:43]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
|  |  | March 31, |  | March 31, |  |  |  |  |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  | 2023 |  | 2022 |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,149,023 |  |  | $ | 1,328,716 |  |  |  |  |  |
| Accounts receivable, net |  | 630,382 |  |  | 675,604 |  |  |  |  |  |
| Inventories |  | 682,893 |  |  | 933,124 |  |  |  |  |  |
| Other current assets |  | 142,876 |  |  | 135,478 |  |  |  |  |  |
| Total current assets |  | 2,605,174 |  |  | 3,072,922 |  |  |  |  |  |
| Non-current assets: |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  | 121,503 |  |  | 109,807 |  |  |  |  |  |
| Goodwill |  | 454,610 |  |  | 448,175 |  |  |  |  |  |
| Other intangible assets, net |  | 63,173 |  |  | 83,779 |  |  |  |  |  |
| Other assets |  | 316,293 |  |  | 320,722 |  |  |  |  |  |
| Total assets |  | $ | 3,560,753 |  |  | $ | 4,035,405 |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 406,968 |  |  | $ | 636,306 |  |  |  |  |  |
| Accrued and other current liabilities |  | 643,139 |  |  | 784,848 |  |  |  |  |  |
| Total current liabilities |  | 1,050,107 |  |  | 1,421,154 |  |  |  |  |  |
| Non-current liabilities: |  |  |  |  |  |  |  |  |
| Income taxes payable |  | 106,391 |  |  | 83,380 |  |  |  |  |  |
| Other non-current liabilities |  | 146,695 |  |  | 132,133 |  |  |  |  |  |
| Total liabilities |  | 1,303,193 |  |  | 1,636,667 |  |  |  |  |  |
| Shareholders' equity: |  |  |  |  |  |  |  |  |
| Registered shares, CHF 0.25 par value: |  | 30,148 |  |  | 30,148 |  |  |  |  |  |
| Issued shares —173,106 at March 31, 2023 and 2022 |  |  |  |  |  |  |  |  |
| Additional shares that may be issued out of conditional capital — 50,000 at March 31, 2023 and 2022 |  |  |  |  |  |  |  |  |
| Additional shares that may be issued out of authorized capital — 17,311 at March 31, 2023 and 2022 |  |  |  |  |  |  |  |  |
| Additional paid-in capital |  | 127,380 |  |  | 129,925 |  |  |  |  |  |
| Shares in treasury, at cost — 13,763 and 7,855 at March 31, 2023 and 2022, respectively |  | (977,266) |  |  | (632,893) |  |  |  |  |  |
| Retained earnings |  | 3,177,575 |  |  | 2,975,681 |  |  |  |  |  |
| Accumulated other comprehensive loss |  | (100,277) |  |  | (104,123) |  |  |  |  |  |
| Total shareholders' equity |  | 2,257,560 |  |  | 2,398,738 |  |  |  |  |  |
| Total liabilities and shareholders' equity |  | $ | 3,560,753 |  |  | $ | 4,035,405 |  |  |  |  |  |

[0001032975-23-000015:8k_2_02:44]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  | Fiscal Years Ended |
|  |  | March 31, |  | March 31, |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 41,495 |  |  | $ | 108,205 |  |  | $ | 364,575 |  |  | $ | 644,513 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  | 19,611 |  |  | 22,974 |  |  | 76,309 |  |  | 88,361 |  |
| Amortization of intangible assets |  | 6,234 |  |  | 5,956 |  |  | 24,407 |  |  | 30,179 |  |
| Impairment of intangible assets |  | — |  |  | — |  |  | — |  |  | 7,000 |  |
| Loss on investments |  | 1,008 |  |  | 262 |  |  | 14,073 |  |  | 1,683 |  |
| Share-based compensation expense |  | 19,042 |  |  | 21,014 |  |  | 70,782 |  |  | 93,479 |  |
| Deferred income taxes |  | 6,486 |  |  | (35) |  |  | 30,714 |  |  | 27,334 |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | — |  |  | — |  |  | (3,509) |  |
| Pension curtailment gains |  | (4,225) |  |  | — |  |  | (4,225) |  |  | — |  |
| Other |  | (406) |  |  | 72 |  |  | 1,005 |  |  | 1,140 |  |
| Changes in assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | 174,732 |  |  | 164,848 |  |  | 51,185 |  |  | (71,510) |  |
| Inventories |  | 121,000 |  |  | (98,812) |  |  | 247,309 |  |  | (276,640) |  |
| Other assets |  | (15,284) |  |  | 2,400 |  |  | 5,634 |  |  | (18,169) |  |
| Accounts payable |  | (84,203) |  |  | (100,666) |  |  | (219,051) |  |  | (181,303) |  |
| Accrued and other liabilities |  | (68,647) |  |  | (26,628) |  |  | (128,707) |  |  | (44,240) |  |
| Net cash provided by operating activities |  | 216,843 |  |  | 99,590 |  |  | 534,010 |  |  | 298,318 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  | (23,231) |  |  | (25,426) |  |  | (92,353) |  |  | (89,152) |  |
| Investment in privately held companies |  | (1,731) |  |  | (203) |  |  | (4,357) |  |  | (1,463) |  |
| Acquisitions, net of cash acquired |  | — |  |  | (350) |  |  | (8,527) |  |  | (16,236) |  |
| Purchases of short-term investments |  | — |  |  | — |  |  | — |  |  | (10,000) |  |
| Proceeds from the sale of short-term investments |  | — |  |  | 7,035 |  |  | — |  |  | 8,260 |  |
| Purchases of deferred compensation investments |  | (1,516) |  |  | (1,414) |  |  | (6,702) |  |  | (5,058) |  |
| Proceeds from sales of deferred compensation investments |  | 1,459 |  |  | 1,501 |  |  | 6,209 |  |  | 5,786 |  |
| Net cash used in investing activities |  | (25,019) |  |  | (18,857) |  |  | (105,730) |  |  | (107,863) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Payment of cash dividends |  | — |  |  | — |  |  | (158,680) |  |  | (159,410) |  |
| Payment of contingent consideration for business acquisition |  | — |  |  | — |  |  | (5,954) |  |  | (880) |  |
| Purchases of registered shares |  | (90,615) |  |  | (121,397) |  |  | (418,346) |  |  | (412,022) |  |
| Proceeds from exercises of stock options and purchase rights |  | 12,726 |  |  | 13,005 |  |  | 28,790 |  |  | 29,649 |  |
| Tax withholdings related to net share settlements of restricted stock units |  | (429) |  |  | (5,628) |  |  | (29,163) |  |  | (64,156) |  |
| Net cash used in financing activities |  | (78,318) |  |  | (114,020) |  |  | (583,353) |  |  | (606,819) |  |
| Effect of exchange rate changes on cash and cash equivalents |  | (614) |  |  | (2,408) |  |  | (24,620) |  |  | (5,247) |  |
| Net increase (decrease) in cash and cash equivalents |  | 112,892 |  |  | (35,695) |  |  | (179,693) |  |  | (421,611) |  |
| Cash and cash equivalents at beginning of the period |  | 1,036,131 |  |  | 1,364,411 |  |  | 1,328,716 |  |  | 1,750,327 |  |
| Cash and cash equivalents at end of the period |  | $ | 1,149,023 |  |  | $ | 1,328,716 |  |  | $ | 1,149,023 |  |  | $ | 1,328,716 |  |

[0001032975-23-000015:8k_2_02:45]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three Months Ended |  | Fiscal Years Ended |
|  |  | March 31, |  | March 31, |
| NET SALES |  | 2023 |  | 2022 |  | Change |  | 2023 |  | 2022 |  | Change |
| Net sales by product category: |  |  |  |  |  |  |  |  |  |  |  |  |
| Pointing Devices |  | $ | 160,768 |  |  | $ | 178,126 |  |  | (10) | % |  | $ | 728,357 |  |  | $ | 781,108 |  |  | (7) | % |
| Keyboards & Combos |  | 187,800 |  |  | 231,064 |  |  | (19) |  |  | 836,432 |  |  | 967,301 |  |  | (14) |  |
| PC Webcams |  | 49,659 |  |  | 84,147 |  |  | (41) |  |  | 227,692 |  |  | 403,651 |  |  | (44) |  |
| Tablet & Other Accessories |  | 68,429 |  |  | 67,191 |  |  | 2 |  |  | 254,374 |  |  | 310,123 |  |  | (18) |  |
| Gaming (1) |  | 239,028 |  |  | 316,427 |  |  | (24) |  |  | 1,211,485 |  |  | 1,451,883 |  |  | (17) |  |
| Video Collaboration |  | 178,721 |  |  | 243,439 |  |  | (27) |  |  | 887,517 |  |  | 997,164 |  |  | (11) |  |
| Mobile Speakers |  | 11,823 |  |  | 25,058 |  |  | (53) |  |  | 111,649 |  |  | 149,782 |  |  | (25) |  |
| Audio & Wearables |  | 62,410 |  |  | 82,459 |  |  | (24) |  |  | 274,231 |  |  | 401,424 |  |  | (32) |  |
| Other (2) |  | 1,439 |  |  | 2,083 |  |  | (31) |  |  | 7,081 |  |  | 18,665 |  |  | (62) |  |
| Total Sales |  | $ | 960,077 |  |  | $ | 1,229,994 |  |  | (22) | % |  | $ | 4,538,818 |  |  | $ | 5,481,101 |  |  | (17) | % |
| __________________ |  |  |  |  |  |  |  |  |  |  |  |  |

[0001032975-23-000015:8k_2_02:46]
(1) Gaming includes streaming services revenue generated by Streamlabs.

[0001032975-23-000015:8k_2_02:47]
(2) Other includes Smart Home.

[0001032975-23-000015:8k_2_02:48]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three Months Ended |  | Fiscal Years Ended |
|  |  | March 31, |  | March 31, |
| GAAP TO NON-GAAP RECONCILIATION (A) |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Gross profit - GAAP |  | $ | 343,864 |  |  | $ | 493,907 |  |  | $ | 1,719,515 |  |  | $ | 2,263,006 |  |
| Share-based compensation expense |  | 1,407 |  |  | 1,442 |  |  | 5,635 |  |  | 6,695 |  |
| Amortization of intangible assets |  | 3,510 |  |  | 2,995 |  |  | 12,865 |  |  | 14,023 |  |
| Gross profit - Non-GAAP |  | $ | 348,781 |  |  | $ | 498,344 |  |  | $ | 1,738,015 |  |  | $ | 2,283,724 |  |
| Gross margin - GAAP |  | 35.8 | % |  | 40.2 | % |  | 37.9 | % |  | 41.3 | % |
| Gross margin - Non-GAAP |  | 36.3 | % |  | 40.5 | % |  | 38.3 | % |  | 41.7 | % |
| Operating expenses - GAAP |  | $ | 305,020 |  |  | $ | 365,138 |  |  | $ | 1,261,046 |  |  | $ | 1,488,994 |  |
| Less: Share-based compensation expense |  | 17,635 |  |  | 19,572 |  |  | 65,147 |  |  | 86,784 |  |
| Less: Amortization of intangible assets and acquisition-related costs |  | 2,791 |  |  | 2,961 |  |  | 11,843 |  |  | 16,947 |  |
| Less: Impairment of intangible assets |  | — |  |  | — |  |  | — |  |  | 7,000 |  |
| Less: Change in fair value of contingent consideration for business acquisition |  | — |  |  | — |  |  | — |  |  | (3,509) |  |
| Less: Restructuring charges, net |  | 18,102 |  |  | 395 |  |  | 34,573 |  |  | 2,165 |  |
| Operating expenses - Non-GAAP |  | $ | 266,492 |  |  | $ | 342,210 |  |  | $ | 1,149,483 |  |  | $ | 1,379,607 |  |
| % of net sales - GAAP |  | 31.8 | % |  | 29.7 | % |  | 27.8 | % |  | 27.2 | % |
| % of net sales - Non-GAAP |  | 27.8 | % |  | 27.8 | % |  | 25.3 | % |  | 25.2 | % |
| Operating income - GAAP |  | $ | 38,844 |  |  | $ | 128,769 |  |  | $ | 458,469 |  |  | $ | 774,012 |  |
| Share-based compensation expense |  | 19,042 |  |  | 21,014 |  |  | 70,782 |  |  | 93,479 |  |
| Amortization of intangible assets and acquisition-related costs |  | 6,301 |  |  | 5,956 |  |  | 24,708 |  |  | 30,970 |  |
| Impairment of intangible assets |  | — |  |  | — |  |  | — |  |  | 7,000 |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | — |  |  | — |  |  | (3,509) |  |
| Restructuring charges, net |  | 18,102 |  |  | 395 |  |  | 34,573 |  |  | 2,165 |  |
| Operating income - Non-GAAP |  | $ | 82,289 |  |  | $ | 156,134 |  |  | $ | 588,532 |  |  | $ | 904,117 |  |
| % of net sales - GAAP |  | 4.0 | % |  | 10.5 | % |  | 10.1 | % |  | 14.1 | % |
| % of net sales - Non-GAAP |  | 8.6 | % |  | 12.7 | % |  | 13.0 | % |  | 16.5 | % |
| Net income - GAAP |  | $ | 41,495 |  |  | $ | 108,205 |  |  | $ | 364,575 |  |  | $ | 644,513 |  |
| Share-based compensation expense |  | 19,042 |  |  | 21,014 |  |  | 70,782 |  |  | 93,479 |  |
| Amortization of intangible assets and acquisition-related costs |  | 6,301 |  |  | 5,956 |  |  | 24,708 |  |  | 30,970 |  |
| Impairment of intangible assets |  | — |  |  | — |  |  | — |  |  | 7,000 |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | — |  |  | — |  |  | (3,509) |  |
| Restructuring charges, net |  | 18,102 |  |  | 395 |  |  | 34,573 |  |  | 2,165 |  |
| Loss on investments |  | 1,008 |  |  | 262 |  |  | 14,073 |  |  | 1,683 |  |
| Pension curtailment gains |  | (4,225) |  |  | — |  |  | (4,225) |  |  | — |  |
| Non-GAAP income tax adjustment |  | (1,167) |  |  | (99) |  |  | 22,129 |  |  | 12,364 |  |
| Net income - Non-GAAP |  | $ | 80,556 |  |  | $ | 135,733 |  |  | $ | 526,615 |  |  | $ | 788,665 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  | $ | 0.26 |  |  | $ | 0.64 |  |  | $ | 2.23 |  |  | $ | 3.78 |  |
| Diluted - Non-GAAP |  | $ | 0.50 |  |  | $ | 0.81 |  |  | $ | 3.22 |  |  | $ | 4.63 |  |
| Shares used to compute net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP and Non-GAAP |  | 161,524 |  |  | 168,546 |  |  | 163,704 |  |  | 170,414 |  |

[0001032975-23-000015:8k_2_02:49]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three Months Ended |  | Fiscal Years Ended |
|  |  | March 31, |  | March 31, |
| SHARE-BASED COMPENSATION EXPENSE |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Share-based Compensation Expense |  |  |  |  |  |  |  |  |
| Cost of goods sold |  | $ | 1,407 |  |  | $ | 1,442 |  |  | $ | 5,635 |  |  | $ | 6,695 |  |
| Marketing and selling |  | 9,467 |  |  | 8,809 |  |  | 34,707 |  |  | 37,796 |  |
| Research and development |  | 3,724 |  |  | 4,061 |  |  | 15,292 |  |  | 18,356 |  |
| General and administrative |  | 4,444 |  |  | 6,702 |  |  | 15,148 |  |  | 30,632 |  |
| Total share-based compensation expense |  | 19,042 |  |  | 21,014 |  |  | 70,782 |  |  | 93,479 |  |
| Income tax benefit |  | (2,254) |  |  | (3,527) |  |  | (9,750) |  |  | (26,987) |  |
| Total share-based compensation expense, net of income tax benefit |  | $ | 16,788 |  |  | $ | 17,487 |  |  | $ | 61,032 |  |  | $ | 66,492 |  |

[0001032975-23-000015:8k_2_02:50]
*Note: These preliminary results for the three months and fiscal year ended March 31, 2023 are subject to adjustments, including subsequent events that may occur through the date of filing our Annual Report on Form 10-K.

[0001032975-23-000015:8k_2_02:51]
(A) Non-GAAP Financial Measures

[0001032975-23-000015:8k_2_02:52]
To supplement our condensed consolidated financial results prepared in accordance with GAAP, we use a number of financial measures, both GAAP and non-GAAP, in analyzing and assessing our overall business performance, for making operating decisions and for forecasting and planning future periods. We consider the use of non-GAAP financial measures helpful in assessing our current financial performance, ongoing operations and prospects for the future as well as understanding financial and business trends relating to our financial condition and results of operations.

[0001032975-23-000015:8k_2_02:53]
While we use non-GAAP financial measures as a tool to enhance our understanding of certain aspects of our financial performance and to provide incremental insight into the underlying factors and trends affecting both our performance and our cash-generating potential, we do not consider these measures to be a substitute for, or superior to, the information provided by GAAP financial measures. Consistent with this approach, we believe that disclosing non-GAAP financial measures to the readers of our financial statements provides useful supplemental data that, while not a substitute for GAAP financial measures, can offer insight in the review of our financial and operational performance and enables investors to more fully understand trends in our current and future performance. In assessing our business during the quarter and fiscal year ended March 31, 2023 and prior periods presented, we excluded items in the following general categories, each of which are described below:

[0001032975-23-000015:8k_2_02:54]
Share-based compensation expense. We believe that providing non-GAAP measures excluding share-based compensation expense, in addition to the GAAP measures, allows for a more transparent comparison of our financial results from period to period. We prepare and maintain our budgets and forecasts for future periods on a basis consistent with this non-GAAP financial measure. Further, companies use a variety of types of equity awards as well as a variety of methodologies, assumptions and estimates to determine share-based compensation expense. We believe that excluding share-based compensation expense enhances our ability and the ability of investors to understand the impact of non-cash share-based compensation on our operating results and to compare our results against the results of other companies.

[0001032975-23-000015:8k_2_02:55]
Amortization of intangible assets. We incur intangible asset amortization expense, primarily in connection with our acquisitions of various businesses and technologies. The amortization of purchased intangibles varies depending on the level of acquisition activity. We exclude these various charges in budgeting, planning and forecasting future periods and we believe that providing the non-GAAP measures excluding these various non-cash charges, as well as the GAAP measures, provides additional insight when comparing our gross profit, operating expenses, and financial results from period to period.

[0001032975-23-000015:8k_2_02:56]
Impairment of intangible assets. We may incur impairment of intangible assets expense, primarily in connection with our past business or asset acquisitions. We believe that providing the non-GAAP measures excluding these items, as well as the GAAP measures, assists our investors because such expenses are not reflective of our ongoing operating results.

[0001032975-23-000015:8k_2_02:57]
Acquisition-related costs and change in fair value of contingent consideration for business acquisition. We incurred expenses and credits in connection with our acquisitions which we generally would not have otherwise incurred in the periods presented as a part of our continuing operations. Acquisition-related costs include certain incremental expenses incurred to effect a business combination. Fair value of contingent consideration is associated with our estimates of the value of earn-outs in connection with certain acquisitions. We believe that providing the non-GAAP measures excluding these costs and credits, as well as the GAAP measures, assists our investors because such costs are not reflective of our ongoing operating results.

[0001032975-23-000015:8k_2_02:58]
Restructuring charges, net. These expenses are associated with restructuring plans, and will vary based on the initiatives in place during any given period. Restructuring charges may include costs related to employee terminations, facility closures and early cancellation of certain contracts as well as other costs resulting from our restructuring initiatives. We believe that providing the non-GAAP measures excluding these items, as well as the GAAP measures, assists our investors because such charges are not reflective of our ongoing operating results.

[0001032975-23-000015:8k_2_02:59]
Loss (gain) on investments. We recognize losses (gains) related to our investments in various companies, which vary depending on the operational and financial performance of the companies in which we invest. These amounts include our losses (earnings) on equity method investments, investment impairments and losses (gains) resulting from sales or other events related to our investments. We believe that providing the non-GAAP measures excluding these items, as well as the GAAP measures, assists our investors because such losses (gains) are not reflective of our ongoing operations.

[0001032975-23-000015:8k_2_02:60]
Pension curtailment losses (gains). Curtailment losses (gains) are associated with our restructuring initiatives as a result of a reduction in the number of participants in our defined benefit pension plans. We believe that providing the non-GAAP measures excluding these losses (gains), as applicable, as well as the GAAP measures, assists our investors because such losses (gains) are not reflective of our ongoing operating results.

[0001032975-23-000015:8k_2_02:61]
Non-GAAP income tax adjustment. Non-GAAP income tax adjustment primarily measures the income tax effect of non-GAAP adjustments excluded above and other events; the determination of which is based upon the nature of the underlying items, the mix of income and losses in jurisdictions and the relevant tax rates in which we operate.

[0001032975-23-000015:8k_2_02:62]
Each of the non-GAAP financial measures described above, and used in this press release, should not be considered in isolation from, or as a substitute for, a measure of financial performance prepared in accordance with GAAP. Further, investors are cautioned that there are inherent limitations associated with the use of each of these non-GAAP financial measures as an analytical tool. In particular, these non-GAAP financial measures are not based on a comprehensive set of accounting rules or principles and many of the adjustments to the GAAP financial measures reflect the exclusion of items that are recurring and may be reflected in the Company’s financial results for the foreseeable future. We compensate for these limitations by providing specific information in the reconciliation included in this press release regarding the GAAP amounts excluded from the non-GAAP financial measures. In addition, as noted above, we evaluate the non-GAAP financial measures together with the most directly comparable GAAP financial information.

[0001032975-23-000015:8k_2_02:63]
Additional Supplemental Financial Information - Constant Currency

[0001032975-23-000015:8k_2_02:64]
In addition, Logitech presents percentage sales growth in constant currency to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales.
