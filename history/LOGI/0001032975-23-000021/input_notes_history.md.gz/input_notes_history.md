# LOGI note change history — 0001628280-22-027224 → 0001032975-23-000007


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-01-26):
[0001032975-23-000007:note_history:1]
Changes in the Company’s warranty liability for the three and nine months ended December 31, 2022 and 2021 were as follows (in thousands):
  (was, 2022-10-27, similarity 0.9615):
[0001628280-22-027224:note_history:1]
Changes in the Company’s warranty liability for the three and six months ended September 30, 2022 and 2021 were as follows (in thousands):

- changed (2023-01-26):
[0001032975-23-000007:note_history:2]
|  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Beginning of the period | $ | 41,960 |  |  | $ | 49,173 |  |  | $ | 46,219 |  |  | $ | 48,832 |  |
| Provision | 8,920 |  |  | 6,962 |  |  | 23,440 |  |  | 23,503 |  |
| Settlements | (8,979) |  |  | (8,056) |  |  | (26,358) |  |  | (24,219) |  |
| Effects of foreign currency translation | 730 |  |  | (144) |  |  | (670) |  |  | (181) |  |
| End of the period | $ | 42,631 |  |  | $ | 47,935 |  |  | $ | 42,631 |  |  | $ | 47,935 |  |
  (was, 2022-10-27, similarity 0.9698):
[0001628280-22-027224:note_history:2]
|  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Beginning of the period | $ | 43,841 |  |  | $ | 49,093 |  |  | $ | 46,219 |  |  | $ | 48,832 |  |
| Provision | 7,897 |  |  | 8,095 |  |  | 14,520 |  |  | 16,541 |  |
| Settlements | (9,098) |  |  | (7,848) |  |  | (17,379) |  |  | (16,163) |  |
| Effects of foreign currency translation | (680) |  |  | (167) |  |  | (1,400) |  |  | (37) |  |
| End of the period | $ | 41,960 |  |  | $ | 49,173 |  |  | $ | 41,960 |  |  | $ | 49,173 |  |

- changed (2023-01-26):
[0001032975-23-000007:note_history:3]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of December 31, 2022, no material amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.
  (was, 2022-10-27, similarity 0.9946):
[0001628280-22-027224:note_history:3]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of September 30, 2022, no material amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-01-26):
[0001032975-23-000007:note_history:4]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and nine months ended December 31, 2022 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2023, or any future periods.
  (was, 2022-10-27, similarity 0.9623):
[0001628280-22-027224:note_history:4]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and six months ended September 30, 2022 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2023, or any future periods.

- changed (2023-01-26):
[0001032975-23-000007:note_history:5]
Other than the recent accounting pronouncements adopted and discussed below under Recent Accounting Pronouncements Adopted, there have been no material changes in the Company’s significant accounting policies during the nine months ended December 31, 2022 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2022.
  (was, 2022-10-27, similarity 0.9446):
[0001628280-22-027224:note_history:5]
Other than the recent accounting pronouncements adopted and discussed below under Recent Accounting Pronouncements Adopted, there have been no material changes in the Company’s significant accounting policies during the six months ended September 30, 2022 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2022.

- changed (2023-01-26):
[0001032975-23-000007:note_history:6]
In March 2020, the World Health Organization declared the outbreak of COVID-19 as a pandemic, which continues to spread throughout the world. The COVID-19 pandemic resulted in industry-wide global supply chain challenges, including manufacturing, transportation and logistics. The Company purchases certain products and key components from a limited number of sources, and depends on the supply chain, including freight, to receive components, transport finished goods and deliver the Company's products across the world.
  (was, 2022-10-27, similarity 0.9961):
[0001628280-22-027224:note_history:6]
In March 2020, the World Health Organization declared the outbreak of COVID-19 as a pandemic, which continues to spread throughout the world. The COVID-19 pandemic has resulted in industry-wide global supply chain challenges, including manufacturing, transportation and logistics. The Company purchases certain products and key components from a limited number of sources, and depends on the supply chain, including freight, to receive components, transport finished goods and deliver the Company's products across the world.

- added (2023-01-26):
[0001032975-23-000007:note_history:7]
More recently, the Company has also been impacted by adverse macroeconomic and geopolitical conditions. These conditions include but are not limited to inflation, foreign currency fluctuations, and slowdown of economic activity around the world, in part due to rising interest rates, and lower consumer and enterprise spending. In addition, the war in Ukraine increased global supply chain, logistics, and inflationary challenges. Such global or regional economic and political conditions adversely affect demand for the Company's products. These conditions also have an impact on the Company's suppliers, contract manufacturers, logistics providers, and distributors, causing volatility in cost of materials and shipping and transportation rates, and as a result impacting the pricing of the Company's products. Price increases may not successfully offset cost increases or may cause the Company to lose market share and in turn adversely impact the Company's results of operations.

- added (2023-01-26):
[0001032975-23-000007:note_history:8]
While global supply chain challenges have improved since the second quarter of fiscal year 2023, including logistics costs and shipping lead times, the increase of COVID-19 infections in China during the third quarter of fiscal year 2023 causes uncertainty in supply availability. If macroeconomic and geopolitical conditions and COVID-19 related factors do not improve or worsen, the Company's results of operations will continue to be adversely impacted.

- removed (2023-01-26):
[0001628280-22-027224:note_history:9]
More recently, the Company has also been impacted by adverse macroeconomic and geopolitical conditions. These conditions include but are not limited to inflation, foreign currency fluctuations, slow down of economic activity around the globe, in part due to rising interest rates, and lower consumer spending. In addition, the war in Ukraine has further increased existing global supply chain, logistics, and inflationary challenges. Such global or regional economic and political conditions adversely affect demand for the Company's products. These conditions also have an impact on the Company's suppliers, contract manufacturers, logistics providers, and distributors, causing increases in cost of materials and higher shipping and transportation rates, and as a result impacting the pricing of the Company's products. Price increases may not successfully offset cost increases or may cause the Company to lose market share and in turn adversely impact the Company's results of operations.

- removed (2023-01-26):
[0001628280-22-027224:note_history:10]
While global supply chain challenges improved during the second quarter of fiscal 2023, including logistics costs, shipping lead times, and component availability, if macroeconomic and geopolitical conditions and COVID-19 related factors do not improve or worsen, the Company's results of operations may be adversely impacted.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-01-26):
[0001032975-23-000007:note_history:11]
The Company had several uncommitted, unsecured bank lines of credit aggregating $179.2 million and $195.0 million as of December 31, 2022 and March 31, 2022, respectively. There are no financial covenants under these lines of credit with which the Company must comply. As of December 31, 2022 and March 31, 2022, the Company had outstanding bank guarantees of $11.6 million and $25.5 million, respectively, under these lines of credit. There was no borrowing outstanding under these lines of credit as of December 31, 2022 or March 31, 2022.
  (was, 2022-10-27, similarity 0.9344):
[0001628280-22-027224:note_history:11]
The Company had several uncommitted, unsecured bank lines of credit aggregating $176.0 million and $195.0 million as of September 30, 2022 and March 31, 2022, respectively. There are no financial covenants under these lines of credit with which the Company must comply. As of September 30, 2022 and March 31, 2022, the Company 
had outstanding bank guarantees of $22.2 million and $25.5 million, respectively, under these lines of credit. There was no borrowing outstanding under these lines of credit as of September 30, 2022 or March 31, 2022.
