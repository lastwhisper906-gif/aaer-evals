# LOGI MD&A — 0001032975-23-000021


## mdna

[0001032975-23-000021:mdna:1]
ITEM 7.    MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001032975-23-000021:mdna:2]
Overview of Our Company

[0001032975-23-000021:mdna:3]
Logitech’s mission is to help all people pursue their passions in a way that is good for people and the planet. We design, manufacture, and sell products that help businesses thrive and bring people together when working, creating, gaming and streaming. We sell these products through a number of brands: Logitech, Logitech G (including ASTRO Gaming, Streamlabs, and Blue Microphones) and Ultimate Ears.

[0001032975-23-000021:mdna:4]
Our products address primarily four large market opportunities: Creativity & Productivity, Gaming, Video Collaboration and Music. We sell our products to a broad network of international customers, including direct sales to retailers, e-tailers, and end consumers through our e-commerce platform, and indirect sales to end customers through distributors.

[0001032975-23-000021:mdna:5]
From time to time, we may seek to partner with or acquire, when appropriate, companies that have products, personnel, and technologies that complement our strategic direction. We continually review our product offerings and our strategic direction in light of our profitability targets, competitive conditions, changing consumer trends and the evolving nature of the interface between the consumer and the digital world.

[0001032975-23-000021:mdna:6]
Impacts of Macroeconomic and Geopolitical Conditions on our Business

[0001032975-23-000021:mdna:7]
In fiscal year 2023, our business was impacted by adverse macroeconomic and geopolitical conditions. These conditions included inflation, foreign currency fluctuations, and slowdown of economic activity around the world, in part due to rising interest rates, and lower consumer and enterprise spending. In addition, the war in Ukraine resulted in global supply chain, logistics, and inflationary challenges. We had no revenue in Russia and Ukraine in fiscal year 2023 as we have indefinitely ceased all sales and shipments to Russia and sales in Ukraine have also been halted due to the ongoing military operations on the Ukrainian territory.

[0001032975-23-000021:mdna:8]
The global and regional economic and political conditions adversely affect demand for our products. These conditions also had an impact on our suppliers, contract manufacturers, logistics providers, and distributors, causing volatility in cost of materials and shipping and transportation rates, and as a result, impacting the pricing of our products.

[0001032975-23-000021:mdna:9]
For additional information, see "Liquidity and Capital Resources" below and Item 1A "Risk Factors," including under the caption "Adverse global and regional economic and geopolitical conditions can materially adversely affect our business, results of operations and financial condition," “We purchase key components and products from a limited number of sources, and our business and operating results could be adversely affected if supply were delayed or constrained or if there were shortages of required components,” “Our principal manufacturing operations and third-party contract manufacturers are located in China and Southeast Asia, which exposes us to risks associated with doing business in that geographic area as well as potential tariffs, adverse trade regulations, adverse tax consequences and pressure to move or diversify our manufacturing locations,” “If we do not accurately forecast market demand for our products, our business and operating results could be adversely affected,” and "If we do not successfully coordinate the worldwide manufacturing and distribution of our products, we could lose sales and our business and operating results could be adversely affected.”

[0001032975-23-000021:mdna:10]
Trends and Uncertainties

[0001032975-23-000021:mdna:11]
Several long-term secular-trends offer long-term structural growth opportunities across Logitech’s product portfolio, including work and learn from anywhere (hybrid work), video everywhere, the rise of social gaming for participants and spectators, and the democratization of digital content creation. We design, create and sell products that benefit from these secular trends. The culture of hybrid work and learn provides an opportunity to equip meeting rooms, classrooms and personal workspaces, at home or in the office.  It also provides an opportunity for increased commercial and consumer adoption of video conferencing. Our video collaboration products are compatible with a variety of video conference platforms, including Zoom, Microsoft Teams, Google Meet, etc. Moving from work to play, Logitech gaming and streaming products benefit from social gaming which continues to

[0001032975-23-000021:mdna:12]
gain popularity through online gaming, multi-platform experiences and esports. In addition, the democratization of digital content creation presents an opportunity for anyone to be a content creator because of the accessibility of the tools necessary to code, design, create, make music, game or broadcast to professional standards.

[0001032975-23-000021:mdna:13]
While we believe we will further benefit from these secular trends, we have experienced and will continue to experience challenges that impact our business and financial results. These challenges include (i) the current macroeconomic environment, including interest rate fluctuations, inflation, foreign exchange movements and low economic growth in certain regions, (ii) low consumer confidence and recent declines in enterprise spending leading to reduced demand for some of our products, (iii) the uncertainty in strategy and timing of enterprises’ “return-to-office” impacting demand for our Video Collaboration and Creativity & Productivity products, and (iv) the timing of further development of our business-to-business go-to-market capabilities.

[0001032975-23-000021:mdna:14]
We expect these challenges to continue in the near-term. We have taken steps to mitigate the impact of these challenges, including but not limited to: (i) reduction in our operating expenses as revenues have declined in order to maintain margins and size the business for the current market, (ii) reduction in inventories to more appropriately align with demand, (iii) continued investment in our business-to-business direct sales channel in order to improve performance, and (iv) release of new products to increase the value proposition of our portfolio.

[0001032975-23-000021:mdna:15]
Business Seasonality and Product Introductions

[0001032975-23-000021:mdna:16]
We have historically experienced higher sales in our third fiscal quarter ending December 31, compared to other fiscal quarters in our fiscal year, primarily due to the increased consumer demand for our products during the year-end holiday buying season and year-end spending by enterprises. Additionally, new product introductions and business acquisitions can significantly impact sales, product costs and operating expenses. Product introductions can also impact our sales to distribution channels as these channels are filled with new product inventory following a product introduction, and often channel inventory of an earlier model product declines as the next related major product launch approaches. Sales can also be affected when consumers and distributors anticipate a product introduction or changes in business circumstances. However, neither historical seasonal patterns nor historical patterns of product introductions should be considered reliable indicators of our future pattern of product introductions, future sales or financial performance. Furthermore, cash flow is correspondingly lower in the first half of our fiscal year as we typically build inventories in advance for the third quarter and we pay an annual dividend following our Annual General Meeting, which is typically in September.

[0001032975-23-000021:mdna:17]
Summary of Financial Results

[0001032975-23-000021:mdna:18]
Our total sales for fiscal year 2023 decreased 17%, compared to fiscal year 2022, primarily driven by a decline in sales of all of our product categories as a result of lower demand and unfavorable changes in currency exchange rates.

[0001032975-23-000021:mdna:19]
Sales for fiscal year 2023 decreased 25%, 17% and 9% in the EMEA, Americas and Asia Pacific regions, respectively, compared to fiscal year 2022.

[0001032975-23-000021:mdna:20]
Gross margin for fiscal year 2023 decreased by 340 basis points to 37.9%, compared to fiscal year 2022, primarily due to inflationary pressure on costs and unfavorable impacts from changes in currency exchange rates, partially offset by a reduction in our use of expedited shipping.

[0001032975-23-000021:mdna:21]
Operating expenses for fiscal year 2023 were $1,261.0 million, or 27.8% of sales, compared to $1,489.0 million, or 27.2% of sales, for fiscal year 2022. The decrease in operating expenses was primarily driven by a reduction in marketing and advertising spend.

[0001032975-23-000021:mdna:22]
Included in the income tax provision of $98.9 million and $131.3 million in fiscal year 2023 and 2022 was $48.3 million and $88.7 million, respectively, of tax expense from Switzerland.

[0001032975-23-000021:mdna:23]
Net income for fiscal year 2023 was $364.6 million, compared to $644.5 million for fiscal year 2022, reflecting lower sales and gross margin, partially offset by a reduction in operating expenses.

[0001032975-23-000021:mdna:24]
Critical Accounting Estimates

[0001032975-23-000021:mdna:25]
The preparation of financial statements and related disclosures in conformity with U.S. GAAP requires us to make assumptions, judgments, and estimates that affect reported amounts of assets, liabilities, sales and expenses, and the disclosure of contingent assets and liabilities.

[0001032975-23-000021:mdna:26]
We consider an accounting estimate critical if it: (i) requires management to make judgments and estimates about matters that are inherently uncertain; and (ii) is important to an understanding of our financial condition and operating results.

[0001032975-23-000021:mdna:27]
We base our assumptions, judgments and estimates on historical experience and various other factors that we believe to be reasonable under the circumstances. Although these assumptions, judgments, and estimates are based on management's best knowledge of current events and actions that may impact us in the future, actual results could differ. Management has discussed the development, selection and disclosure of these critical accounting estimates with the Audit Committee of the Board of Directors.

[0001032975-23-000021:mdna:28]
We believe the following accounting estimates are most critical to our business operations and to an understanding of our financial condition and results of operations and reflect the more significant judgments and estimates used in the preparation of our consolidated financial statements.

[0001032975-23-000021:mdna:29]
Accruals for Customer Programs and Product Returns

[0001032975-23-000021:mdna:30]
We record accruals for cooperative marketing, customer incentive, pricing programs ("Customer Programs") and product returns. The estimated cost of these programs is usually recorded as a reduction of revenue. Significant management judgments and estimates must be used to determine the cost of these programs in any accounting period. Customer Programs require management to estimate the percentage of those programs that will not be claimed in the current period or will not be earned by customers, which is commonly referred to as "breakage." Breakage is estimated based on historical claim experience, the period in which the claims are expected to be submitted, specific terms and conditions with customers, and other factors. If we receive a separately identifiable benefit from a customer and can reasonably estimate the fair value of that benefit, the cost of the Customer Programs is recognized in operating expenses.

[0001032975-23-000021:mdna:31]
Customer Incentive Programs.    Customer incentive programs include performance-based incentives and consumer rebates. We offer performance-based incentives to our customers and indirect partners based on pre-determined performance criteria. Consumer rebates are offered from time to time at our discretion for the primary benefit of end-users. Customer incentive programs are considered variable consideration, which we estimate and record as a reduction to revenue at the time of sale based on negotiated terms, historical experiences, forecasted incentives, the anticipated volume of future purchases, and inventory levels in the channel.

[0001032975-23-000021:mdna:32]
Product Returns.    We grant limited rights to return products. Return rights vary by customer and range from just the right to return the defective product to stock rotation rights limited to a percentage of sales approved by management. Estimates of expected future product returns are recognized at the time of sale based on analyses of historical return trends by the customer and by product, inventories owned by and located at customers, current customer demand, current operating conditions, and other relevant customer and product information. Upon recognition, we reduce sales and cost of goods sold for the estimated return. Return trends are influenced by product life cycle status, new product introductions, market acceptance of products, sales levels, product sell-through, the type of customer, seasonality, product quality issues, competitive pressures, operational policies and procedures, and other factors. Return rates can fluctuate over time but are sufficiently predictable to allow us to estimate expected future product returns.

[0001032975-23-000021:mdna:33]
We apply a breakage rate to reduce our accruals of Customer Programs based on the estimated percentage of these Customer Programs that will not be claimed or earned. The breakage rate is applied at the time of sale. Assessing the period in which claims are expected to be submitted and the relevance of the historical claim experience require significant management judgment to estimate the breakage of Customer Programs in any accounting period.

[0001032975-23-000021:mdna:34]
We regularly evaluate the adequacy of our accruals for Customer Programs and product returns. Future market conditions and product transitions may require us to take action to increase such programs. In addition, when the variables used to estimate these costs change, or if actual costs differ significantly from the estimates, we would be required to record incremental increases or reductions to revenue or operating expenses.

[0001032975-23-000021:mdna:35]
Inventory Valuation

[0001032975-23-000021:mdna:36]
We must order components for our products and build inventory in advance of customer orders. Further, our industry is characterized by rapid technological change, short-term customer commitments and rapid changes in demand.

[0001032975-23-000021:mdna:37]
We record inventories at the lower of cost and net realizable value and record write-downs of inventories that are obsolete or in excess of anticipated demand or net realizable value. A review of inventory is performed each fiscal quarter that considers factors including the marketability and product lifecycle stage, product development plans, component cost trends, historical sales, and demand forecasts that consider the assumptions about future demand and market conditions. Inventory on hand that is not expected to be sold or utilized is considered excess, and we recognize the write-down in the cost of goods sold at the time of such determination. The write-down is determined by the excess of cost over net realizable value. Net realizable value is the estimated selling price in the ordinary course of business, less reasonably predictable costs of completion, disposal and transportation. At the time of loss recognition, new cost basis per unit and the lower-cost basis for that inventory are established and subsequent changes in facts and circumstances would not result in an increase in the cost basis. If there is an abrupt and substantial decline in demand for Logitech's products or an unanticipated change in technological or customer requirements, we may be required to record additional write-downs that could adversely affect gross margins in the period when the write-downs are recorded. We also extend the assessment to non-cancelable purchase orders if the inventories are considered excess and record the liability that is reasonably possible to be incurred in accrued and other liabilities.

[0001032975-23-000021:mdna:38]
Accounting for Income Taxes

[0001032975-23-000021:mdna:39]
We operate in multiple jurisdictions and our profits are taxed pursuant to the tax laws of these jurisdictions. Our effective income tax rate may be affected by the changes in or interpretations of tax laws and tax agreements in any given jurisdiction, utilization of net operating loss and tax credit carryforwards, changes in geographical mix of income and expense, and changes in our assessment of matters such as the ability to realize deferred tax assets. As a result of these considerations, we must estimate income taxes in each of the jurisdictions in which we operate. This process involves estimating current tax exposure together with assessing temporary differences resulting from the different treatment of items for tax and accounting purposes. These differences result in deferred tax assets and liabilities, which are included in the consolidated balance sheet.

[0001032975-23-000021:mdna:40]
We make certain estimates and judgments about the application of tax laws, the expected resolution of uncertain tax positions and other matters surrounding the recognition and measurement of uncertain tax benefits. In the event that uncertain tax positions are resolved for amounts different than our estimates, or the related statutes of limitations expire without the assessment of additional income taxes, we will be required to adjust the amounts of the related assets and liabilities in the period in which such events occur. Such adjustments may have a material impact on our income tax provision and our results of operations.

[0001032975-23-000021:mdna:41]
For additional information about our Critical Accounting Estimates, see Note 2—Summary of Significant Accounting Policies in our Notes to our consolidated financial statements below.

[0001032975-23-000021:mdna:42]
Adoption of New Accounting Pronouncements

[0001032975-23-000021:mdna:43]
Refer to Note 2 to the consolidated financial statements included in this Annual Report on Form 10-K for recent accounting pronouncements adopted.

[0001032975-23-000021:mdna:44]
Inflation Reduction Act in the U.S.

[0001032975-23-000021:mdna:45]
On August 16, 2022, the “Inflation Reduction Act” (H.R. 5376) ("IRA") was signed into law in the U.S. The IRA establishes a new corporate alternative minimum tax based on financial statement income adjusted for certain items. The new minimum tax is effective for tax years beginning after December 31, 2022. We do not expect the IRA will have a material impact to our financial statements when it becomes effective.

[0001032975-23-000021:mdna:46]
Constant Currency

[0001032975-23-000021:mdna:47]
We refer to our net sales growth rates excluding the impact of currency exchange rate fluctuations as "constant currency" sales growth rates. Percentage of constant currency sales growth is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales.

[0001032975-23-000021:mdna:48]
Given our global sales presence and the reporting of our financial results in U.S. Dollars, our financial results could be affected by significant shifts in currency exchange rates. See “Results of Operations” for information on the effect of currency exchange rate fluctuations on our sales. If the U.S. Dollar appreciates or depreciates in comparison to other currencies in future periods, this will affect our results of operations in future periods as well.

[0001032975-23-000021:mdna:49]
References to Sales

[0001032975-23-000021:mdna:50]
The term “sales” means net sales, except as otherwise specified and the sales growth discussion and sales growth rate percentages are in U.S. Dollars, except as otherwise specified.

[0001032975-23-000021:mdna:51]
Results of Operations

[0001032975-23-000021:mdna:52]
In this section, we discuss the results of our operations for the year ended March 31, 2023 compared to the year ended March 31, 2022. For a discussion of the year ended March 31, 2022 compared to the year ended March 31, 2021, please refer to Part II, Item 7, "Management's Discussion and Analysis of Financial Condition and Results of Operations" in our Annual Report on Form 10-K filed with the SEC on May 18, 2022.

[0001032975-23-000021:mdna:53]
Net Sales

[0001032975-23-000021:mdna:54]
Our sales in fiscal year 2023 decreased 17%, compared to fiscal year 2022, driven by a decline in sales of all of our product categories. Our sales were negatively impacted from lower demand and unfavorable changes in currency exchange rates. If currency exchange rates had been constant in fiscal years 2023 and 2022, our sales decline in constant currency would have been 13%.

[0001032975-23-000021:mdna:55]
Sales Denominated in Other Currencies

[0001032975-23-000021:mdna:56]
Although our financial results are reported in U.S. Dollars, a portion of our sales was generated in currencies other than the U.S. Dollar, such as the Euro, Chinese Renminbi, Japanese Yen, Australian Dollar, Canadian Dollar,  Pound Sterling and New Taiwan Dollar. For the years ended March 31, 2023 and 2022, approximately 51% and 50%, respectively, of our sales were denominated in currencies other than the U.S. Dollar.

[0001032975-23-000021:mdna:57]
Sales by Region

[0001032975-23-000021:mdna:58]
The following table presents the change in sales by region for fiscal year 2023 compared with fiscal year 2022:

[0001032975-23-000021:mdna:59]
|  |  | 2023 vs. 2022 |  |  |
|  |  | Sales Growth Rate |  | Sales Growth Rate in Constant Currency |  |  |  |  |
| Americas |  | (17) | % |  | (17) | % |  |  |  |  |
| EMEA |  | (25) |  |  | (17) |  |  |  |  |  |
| Asia Pacific |  | (9) |  |  | (3) |  |  |  |  |  |

[0001032975-23-000021:mdna:60]
Americas:

[0001032975-23-000021:mdna:61]
The decrease in sales in the Americas region for fiscal year 2023, compared to fiscal year 2022, was primarily driven by decreases in sales for Gaming, Video Collaboration, PC Webcams and Audio & Wearables.

[0001032975-23-000021:mdna:62]
EMEA:

[0001032975-23-000021:mdna:63]
The decrease in sales in the EMEA region for fiscal year 2023, compared to fiscal year 2022, was primarily driven by decreases in sales in Gaming, Keyboards & Combos, PC Webcams and Pointing Devices.

[0001032975-23-000021:mdna:64]
Asia Pacific:

[0001032975-23-000021:mdna:65]
The decrease in sales in the Asia Pacific region for fiscal year 2023, compared to fiscal year 2022, was primarily driven by decreases in sales of Keyboards & Combos, PC Webcams, Audio & Wearables, and Video Collaboration, partially offset by an increase in sales of Gaming.

[0001032975-23-000021:mdna:66]
Sales by Product Categories

[0001032975-23-000021:mdna:67]
Sales by product categories for fiscal years 2023 and 2022 were as follows (Dollars in thousands):

[0001032975-23-000021:mdna:68]
|  |  | Years Ended March 31, |  | Change |
|  |  | 2023 |  | 2022 |  | 2023 vs. 2022 |
| Pointing Devices |  | $ | 728,357 |  |  | $ | 781,108 |  |  | (7) | % |
| Keyboards & Combos |  | 836,432 |  |  | 967,301 |  |  | (14) |  |
| PC Webcams |  | 227,692 |  |  | 403,651 |  |  | (44) |  |
| Tablet & Other Accessories |  | 254,374 |  |  | 310,123 |  |  | (18) |  |
| Gaming (1) |  | 1,211,485 |  |  | 1,451,883 |  |  | (17) |  |
| Video Collaboration |  | 887,517 |  |  | 997,164 |  |  | (11) |  |
| Mobile Speakers |  | 111,649 |  |  | 149,782 |  |  | (25) |  |
| Audio & Wearables |  | 274,231 |  |  | 401,424 |  |  | (32) |  |
| Other (2) |  | 7,081 |  |  | 18,665 |  |  | (62) |  |
| Total Sales |  | $ | 4,538,818 |  |  | $ | 5,481,101 |  |  | (17) | % |

[0001032975-23-000021:mdna:69]
(1) Gaming includes streaming services revenue generated by Streamlabs.

[0001032975-23-000021:mdna:70]
(2) Other includes Smart Home.

[0001032975-23-000021:mdna:71]
Creativity & Productivity market:

[0001032975-23-000021:mdna:72]
Pointing Devices

[0001032975-23-000021:mdna:73]
Our Pointing Devices category comprises PC- and Mac-related mice including trackballs, touchpads and presentation tools.

[0001032975-23-000021:mdna:74]
During fiscal year 2023, Pointing Devices sales decreased 7%, compared to fiscal year 2022, primarily driven by the decrease in sales of cordless and corded mice, particularly in our low end products.

[0001032975-23-000021:mdna:75]
Keyboards & Combos

[0001032975-23-000021:mdna:76]
Our Keyboards & Combos category comprises PC keyboards and keyboard/mice combo products.

[0001032975-23-000021:mdna:77]
During fiscal year 2023, Keyboards & Combos sales decreased 14%, compared to fiscal year 2022, primarily driven by the decrease in sales of our cordless combos and corded PC keyboards, particularly in our low end products.

[0001032975-23-000021:mdna:78]
PC Webcams

[0001032975-23-000021:mdna:79]
Our PC Webcams category comprises PC-based webcams targeted primarily at consumers, including streaming cameras.

[0001032975-23-000021:mdna:80]
During fiscal year 2023, PC Webcams sales decreased 44%, compared to fiscal year 2022, primarily driven by the decrease in sales of our HD Pro Webcam C920, 1080p Pro Stream Webcam, and Webcam C260.

[0001032975-23-000021:mdna:81]
Tablet & Other Accessories

[0001032975-23-000021:mdna:82]
Our Tablet & Other Accessories category primarily comprises tablet keyboards and styluses.

[0001032975-23-000021:mdna:83]
During fiscal year 2023, Tablet & Other Accessories sales decreased 18%, compared to fiscal year 2022, primarily driven by the decrease in sales of most of our products, partially offset by increases in sales of our Rugged Combo 3 Touch.

[0001032975-23-000021:mdna:84]
Gaming market:

[0001032975-23-000021:mdna:85]
Gaming

[0001032975-23-000021:mdna:86]
Our Gaming category comprises gaming mice, keyboards, headsets, gamepads, steering wheels, simulation controllers, console gaming headsets, and Streamlabs services.

[0001032975-23-000021:mdna:87]
During fiscal year 2023, Gaming sales decreased 17%, compared to fiscal year 2022, primarily driven by the decrease in sales of gaming mice, keyboards, and headsets.

[0001032975-23-000021:mdna:88]
Video Collaboration market:

[0001032975-23-000021:mdna:89]
Video Collaboration

[0001032975-23-000021:mdna:90]
Our Video Collaboration category includes Logitech’s conference room cameras, which combine affordable enterprise-quality audio and high definition 4K video to bring video conferencing to businesses of any size, as well as webcams and headsets that turn any desktop into an instant collaboration space.

[0001032975-23-000021:mdna:91]
During fiscal year 2023, Video Collaboration sales decreased 11%, compared to fiscal year 2022, primarily due to the decrease in sales of webcams, partially offset by an increase in sales of conference room cameras and docks. Sales for Video Collaboration for fiscal year 2023 were negatively impacted by a slowdown in enterprise spending.

[0001032975-23-000021:mdna:92]
Music market:

[0001032975-23-000021:mdna:93]
Mobile Speakers

[0001032975-23-000021:mdna:94]
Our Mobile Speakers category is made up entirely of Bluetooth wireless speakers.

[0001032975-23-000021:mdna:95]
During fiscal year 2023, Mobile Speakers sales decreased 25%, compared to fiscal year 2022, primarily due to a decrease in sales of most of our Mobile Speaker sub-categories, partially offset by the sales of our Ultimate Ears Wonderboom 3 mini speakers, introduced in the second quarter of fiscal year 2023.

[0001032975-23-000021:mdna:96]
Audio & Wearables

[0001032975-23-000021:mdna:97]
Our Audio & Wearables category comprises PC speakers, PC headsets, in-ear headphones, premium wireless  earbuds and studio-quality Blue Microphones for professionals and consumers.

[0001032975-23-000021:mdna:98]
During fiscal year 2023, Audio & Wearables sales decreased 32%, compared to fiscal year 2022, primarily due to the decrease in sales of almost all sub-categories.

[0001032975-23-000021:mdna:99]
Gross Profit

[0001032975-23-000021:mdna:100]
Gross profit for fiscal years 2023 and 2022 was as follows (Dollars in thousands):

[0001032975-23-000021:mdna:101]
|  |  | Years Ended March 31, |
|  |  | 2023 |  | 2022 |  | Change |
| Net sales |  | $ | 4,538,818 |  |  | $ | 5,481,101 |  |  | (17.2) | % |
| Gross profit |  | $ | 1,719,515 |  |  | $ | 2,263,006 |  |  | (24.0) | % |
| Gross margin |  | 37.9 | % |  | 41.3 | % |  |  |

[0001032975-23-000021:mdna:102]
Gross profit consists of sales, less cost of goods sold (which includes materials, direct labor and related overhead costs, costs of manufacturing facilities, royalties, costs of purchasing components from outside suppliers, distribution costs, warranty costs, customer support costs, shipping and handling costs, outside processing costs and write-down of inventories), and amortization of intangible assets.

[0001032975-23-000021:mdna:103]
Gross margin decreased by 340 basis points to 37.9% during fiscal year 2023, compared to fiscal year 2022. The decrease in gross margin was primarily due to inflationary pressure on costs and unfavorable impacts from changes in currency exchange rates, partially offset by a reduction in our use of expedited shipping.

[0001032975-23-000021:mdna:104]
Operating Expenses

[0001032975-23-000021:mdna:105]
Operating expenses for fiscal years 2023 and 2022 were as follows (Dollars in thousands):

[0001032975-23-000021:mdna:106]
|  |  | Years Ended March 31, |
|  |  | 2023 |  | 2022 |  |  |
| Marketing and selling |  | $ | 809,182 |  |  | $ | 1,025,899 |  |  |  |
| % of sales |  | 17.8 | % |  | 18.7 | % |  |  |
| Research and development |  | 280,796 |  |  | 291,844 |  |  |  |
| % of sales |  | 6.2 | % |  | 5.3 | % |  |  |
| General and administrative |  | 124,652 |  |  | 148,648 |  |  |  |
| % of sales |  | 2.7 | % |  | 2.7 | % |  |  |
| Amortization of intangible assets and acquisition-related costs |  | 11,843 |  |  | 16,947 |  |  |  |
| % of sales |  | 0.3 | % |  | 0.3 | % |  |  |
| Impairment of intangible assets |  | — |  |  | 7,000 |  |  |  |
| % of sales |  | N/A |  | 0.1 | % |  |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | (3,509) |  |  |  |
| % of sales |  | N/A |  | (0.1) | % |  |  |
| Restructuring charges, net |  | 34,573 |  |  | 2,165 |  |  |  |
| % of sales |  | 0.8 | % |  | — | % |  |  |
| Total operating expenses |  | $ | 1,261,046 |  |  | $ | 1,488,994 |  |  |  |
| % of sales |  | 27.8 | % |  | 27.2 | % |  |  |

[0001032975-23-000021:mdna:107]
The decrease in total operating expenses during fiscal year 2023, compared to fiscal year 2022, was mainly due to decreases in marketing and selling expenses, partially offset by an increase in restructuring charges.

[0001032975-23-000021:mdna:108]
Marketing and Selling

[0001032975-23-000021:mdna:109]
Marketing and selling expenses consist of personnel and related overhead costs, corporate and product marketing, promotions, advertising, trade shows, technical support for customer experiences and facilities costs.

[0001032975-23-000021:mdna:110]
During fiscal year 2023, marketing and selling expenses decreased $216.7 million, compared to fiscal year 2022, primarily driven by our reduction in third-party marketing and advertising spend.

[0001032975-23-000021:mdna:111]
Research and Development

[0001032975-23-000021:mdna:112]
Research and development expenses consist of personnel and related overhead costs for contractors and outside consultants, supplies and materials, equipment depreciation and facilities costs, all associated with the design and development of new products and enhancements of existing products.

[0001032975-23-000021:mdna:113]
During fiscal year 2023, research and development expenses decreased $11.0 million, compared to fiscal year 2022, primarily driven by lower personnel-related costs, partially offset by higher outsourcing expenses. Research and development expenses as a percentage of sales increased from 5.3% in fiscal year 2022 to 6.2% in fiscal year 2023 reflecting our continued investment in innovation.

[0001032975-23-000021:mdna:114]
General and Administrative

[0001032975-23-000021:mdna:115]
General and administrative expenses consist primarily of personnel and related overhead, information technology, and facilities costs for the infrastructure functions such as finance, information systems, executives, human resources and legal.

[0001032975-23-000021:mdna:116]
During fiscal year 2023, general and administrative expenses decreased $24.0 million, compared to fiscal year 2022, primarily driven by lower personnel-related costs.

[0001032975-23-000021:mdna:117]
Amortization of Intangible Assets and Acquisition-Related Costs

[0001032975-23-000021:mdna:118]
Amortization of intangible assets included in operating expense and acquisition-related costs during fiscal years 2023 and 2022 were as follows (in thousands):

[0001032975-23-000021:mdna:119]
|  |  | Years Ended March 31, |
|  |  | 2023 |  | 2022 |  |  |
| Amortization of intangible assets |  | $ | 11,542 |  |  | $ | 16,156 |  |  |  |
| Acquisition-related costs |  | 301 |  |  | 791 |  |  |  |
| Total |  | $ | 11,843 |  |  | $ | 16,947 |  |  |  |

[0001032975-23-000021:mdna:120]
Amortization of intangible assets consists of amortization of acquired intangible assets, including customer relationships and trademarks and trade names. Acquisition-related costs include legal expense, due diligence costs, and other professional costs incurred for business acquisitions.

[0001032975-23-000021:mdna:121]
The decrease in amortization of intangible assets and acquisition-related costs from fiscal year 2022 to 2023 was primarily due to certain acquired intangible assets becoming fully amortized and the write-off of Jaybird intangible assets in fiscal year 2022.

[0001032975-23-000021:mdna:122]
Impairment of Intangible Assets

[0001032975-23-000021:mdna:123]
During fiscal year 2022, we recognized a pre-tax impairment charge of $7.0 million, related to the intangibles acquired as part of the Jaybird acquisition due to our decision to discontinue Jaybird-branded products.

[0001032975-23-000021:mdna:124]
Restructuring Charges (Credits), Net

[0001032975-23-000021:mdna:125]
During the second quarter of fiscal year 2023, we initiated a restructuring plan to realign our business group and engineering structure with our go-to-market strategy to more effectively compete within the enterprise market and to better serve end-users. During the fourth quarter of fiscal year 2023, we undertook further actions to remove organization layers as well as streamline our marketing organization to increase efficiency. As a result, we recorded pre-tax restructuring charges totaling $34.6 million primarily related to employee severance and other termination benefits. We expect to substantially complete these restructuring activities within the next twelve months.

[0001032975-23-000021:mdna:126]
The restructuring charges of $2.2 million for fiscal year 2022, were recorded as a result of our decision to exit Jaybird-branded products during the third quarter of fiscal year 2022. This restructuring plan has been substantially completed.

[0001032975-23-000021:mdna:127]
See Note 16 to our consolidated financial statements for additional information.

[0001032975-23-000021:mdna:128]
Interest Income

[0001032975-23-000021:mdna:129]
Interest income for fiscal years 2023 and 2022 was as follows (in thousands):

[0001032975-23-000021:mdna:130]
|  |  | Years Ended March 31, |
|  |  | 2023 |  | 2022 |  |  |
| Interest Income |  | $ | 18,331 |  |  | $ | 1,246 |  |  |  |

[0001032975-23-000021:mdna:131]
We invest in highly liquid instruments with an original maturity of three months or less at the date of purchase, which are classified as cash equivalents. The increase in interest income for fiscal year 2023, compared to fiscal year 2022, was primarily driven by the increase in interest rates.

[0001032975-23-000021:mdna:132]
Other Income (Expense), Net

[0001032975-23-000021:mdna:133]
Other income (expense), net for fiscal years 2023 and 2022 was as follows (in thousands):

[0001032975-23-000021:mdna:134]
|  |  | Years Ended March 31, |
|  |  | 2023 |  | 2022 |  |  |
| Investment gain (loss) related to the deferred compensation plan |  | $ | (1,961) |  |  | $ | 1,231 |  |  |  |
| Currency exchange loss, net |  | (7,337) |  |  | (4,604) |  |  |  |
| Loss on investments, net |  | (14,073) |  |  | (1,683) |  |  |  |
| Non-service cost net pension income (expense) and other |  | 10,093 |  |  | 5,616 |  |  |  |
| Total |  | $ | (13,278) |  |  | $ | 560 |  |  |  |

[0001032975-23-000021:mdna:135]
Investment gain (loss) related to the deferred compensation plan for fiscal years 2023 and 2022 represents earnings, gains, and losses on marketable securities related to a deferred compensation plan offered by one of our subsidiaries. The decrease in investment income for fiscal year 2023 compared to fiscal year 2022 primarily relates to the change in market performance of the underlying securities.

[0001032975-23-000021:mdna:136]
Currency exchange loss, net, relates to balances denominated in currencies other than the functional currency in our subsidiaries, as well as the sale of currencies, and gains or losses recognized on currency exchange forward contracts. We do not speculate in currency positions, but we are alert to opportunities to maximize currency exchange gains and minimize currency exchange losses. The loss for fiscal year 2023 was primarily related to the weakening of the Brazilian Real and Australian Dollar against U.S. Dollar. The loss for fiscal year 2022 was primarily related to the strengthening of the Chinese Renminbi against the U.S. Dollar.

[0001032975-23-000021:mdna:137]
Loss on investments, net, includes unrealized gain (loss) from the fair value change of investment, gain (loss) on equity-method investments and impairment of investments during the periods presented, as applicable. The loss on investments, net for fiscal year 2023 was primarily due to the impairment charge related to one of our equity method investments, partially offset by the unrealized gain related to one of our equity investments without readily determinable fair value resulting from observable price changes. See Note 9 to our consolidated financial statements for additional information.

[0001032975-23-000021:mdna:138]
Non-service cost net pension income (expense) and other increased in fiscal year 2023, compared to fiscal year 2022, primarily due to the curtailment gain recognized in fiscal year 2023 for one of our defined benefit plans as a result of the restructuring actions undertaken by the Company (see Notes 5 and 16 to our consolidated financial statements).

[0001032975-23-000021:mdna:139]
Provision for Income Taxes

[0001032975-23-000021:mdna:140]
The provision for income taxes and effective income tax rates for fiscal years 2023 and 2022 were as follows (Dollars in thousands):

[0001032975-23-000021:mdna:141]
|  |  | Years Ended March 31, |
|  |  | 2023 |  | 2022 |  |  |
| Provision for income taxes |  | $ | 98,947 |  |  | $ | 131,305 |  |  |  |
| Effective income tax rate |  | 21.3 | % |  | 16.9 | % |  |  |

[0001032975-23-000021:mdna:142]
The change in the effective income tax rate between fiscal years 2023 and 2022 was primarily due to the mix of income and losses in the various tax jurisdictions in which we operate.

[0001032975-23-000021:mdna:143]
We recognized excess tax benefits from share-based payments, net of shortfalls of $1.3 million and $16.3 million in the United States in fiscal years 2023 and 2022, respectively, and recognized income tax benefit from the reversal of uncertain tax positions from the expiration of statutes of limitations in the amount of $4.3 million and $4.9 million in fiscal years 2023 and 2022, respectively. In addition, we recognized income tax benefit of $3.7 million from the reversal of uncertain tax positions from an effective settlement of a foreign income tax audit in fiscal year 2022.

[0001032975-23-000021:mdna:144]
As of March 31, 2023 and 2022, the total amount of unrecognized tax benefits due to uncertain tax positions was $186.8 million and $176.0 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-23-000021:mdna:145]
As of March 31, 2023 and 2022, we had $106.4 million and $83.4 million, respectively, in non-current income taxes payable, including interest and penalties, related to our income tax liability for uncertain tax positions. We recognized $2.7 million and $1.5 million, in interest and penalties related to unrecognized tax positions in income tax expense during fiscal years 2023 and 2022, respectively. As of March 31, 2023 and 2022, we had $6.1 million and $3.6 million, respectively, of accrued interest and penalties related to uncertain tax positions.

[0001032975-23-000021:mdna:146]
We file Swiss and foreign tax returns. We received final tax assessments in Switzerland through fiscal year 2019. For other material foreign jurisdictions such as the United States and China, we are generally not subject to tax examinations for years prior to fiscal year 2020 and calendar year 2020, respectively. In the United States, the federal and state tax agencies have the authority to examine periods prior to fiscal year 2020, to the extent allowed by law, where tax attributes were generated, carried forward, and being utilized in subsequent years. We are under examination in foreign tax jurisdictions. If the examinations are resolved unfavorably, there is a possibility that they may have a material negative impact on our results of operations.

[0001032975-23-000021:mdna:147]
Pursuant to the Tax Cuts and Jobs Act of 2017, research and development expenses are required to be capitalized and amortized over five years for U.S. tax purposes if the research and development activities are performed in the U.S. effective for tax year beginning after December 31, 2021. The provision was effective for us beginning in fiscal year 2023. However, the provision which delays the deductibility of research and development expenses is not applicable to our existing research and development activities in the U.S. We evaluate our business activities regularly should the provision become applicable.

[0001032975-23-000021:mdna:148]
Liquidity and Capital Resources

[0001032975-23-000021:mdna:149]
Cash Balances, Available Borrowings, and Capital Resources

[0001032975-23-000021:mdna:150]
As of March 31, 2023, we had cash and cash equivalents of $1,149.0 million, compared with $1,328.7 million as of March 31, 2022. Our cash and cash equivalents consist of bank demand deposits and short-term time deposits, of which 78% is held in Switzerland and 12% is held in China (including Hong Kong). We do not expect to incur any material adverse tax impact except for what has already been recognized, or to be significantly inhibited by any country in which we do business from the repatriation of funds to Switzerland, our country of domicile.

[0001032975-23-000021:mdna:151]
As of March 31, 2023, our working capital was $1,555.1 million, compared to $1,651.8 million as of March 31, 2022. The decrease was primarily driven by lower inventories, lower cash balances resulting from share repurchases and payments of cash dividends, and lower accounts receivable, net, partially offset by decreases in accounts payable and accrued liabilities.

[0001032975-23-000021:mdna:152]
We had several uncommitted, unsecured bank lines of credit aggregating $181.3 million as of March 31, 2023. There are no financial covenants under these lines of credit with which we must comply. As of March 31, 2023, we had outstanding bank guarantees of $13.6 million under these lines of credit.

[0001032975-23-000021:mdna:153]
The following table presents selected financial information and statistics as of March 31, 2023 and 2022 (Dollars in thousands):

[0001032975-23-000021:mdna:154]
|  |  | March 31, |
|  |  | 2023 |  | 2022 |  |  |
| Accounts receivable, net |  | $ | 630,382 |  |  | $ | 675,604 |  |  |  |
| Accounts payable |  | $ | 406,968 |  |  | $ | 636,306 |  |  |  |
| Inventories |  | $ | 682,893 |  |  | $ | 933,124 |  |  |  |
| Days sales in accounts receivable (DSO)(Days)(1) |  | 59 |  |  | 49 |  |  |  |
| Days accounts payable outstanding (DPO) (Days)(2) |  | 59 |  |  | 78 |  |  |  |
| Inventory turnover (ITO)(x)(3) |  | 3.6 |  |  | 3.2 |  |  |  |

[0001032975-23-000021:mdna:155]
(1)DSO is determined using ending accounts receivable, net as of the most recent quarter-end and sales for the most recent quarter.

[0001032975-23-000021:mdna:156]
(2)DPO is determined using ending accounts payable as of the most recent quarter-end and cost of goods sold for the most recent quarter.

[0001032975-23-000021:mdna:157]
(3)ITO is determined using ending inventories and annualized cost of goods sold (based on the most recent quarterly cost of goods sold).

[0001032975-23-000021:mdna:158]
DSO as of March 31, 2023 increased by 10 days to 59 days, as compared to 49 days as of March 31, 2022, primarily due to lower revenues resulting from softened demand, partially offset by timing of sales within the quarter.

[0001032975-23-000021:mdna:159]
DPO as of March 31, 2023 decreased 19 days, compared to March 31, 2022, primarily due to a reduction in inventory purchases and lower marketing spend, partially offset by softened demand.

[0001032975-23-000021:mdna:160]
ITO as of March 31, 2023 increased 0.4, compared to March 31, 2022, primarily due to a lower inventory balance as of March 31, 2023, partially offset by softened demand.

[0001032975-23-000021:mdna:161]
If we are not successful in launching and phasing in our new products, or market competition increases, or we are not able to sell the new products at the prices planned, it could have a material impact on our sales, gross margin, operating results including operating cash flow, and inventory turnover in the future.

[0001032975-23-000021:mdna:162]
The following table summarizes our consolidated statement of cash flows for the year ended March 31, 2023 (Dollars in thousands):

[0001032975-23-000021:mdna:163]
|  |  | Year ended March 31, 2023 |  |  |
| Net cash provided by operating activities |  | $ | 534,010 |  |  |  |
| Net cash used in investing activities |  | (105,730) |  |  |  |
| Net cash used in financing activities |  | (583,353) |  |  |  |
| Effect of exchange rate changes on cash and cash equivalents |  | (24,620) |  |  |  |
| Net decrease in cash and cash equivalents |  | $ | (179,693) |  |  |  |

[0001032975-23-000021:mdna:164]
For fiscal year 2023, net cash provided by operating activities was $534.0 million resulting from net income of 364.6 million, a favorable impact from adding back non-cash expenses totaling $213.1 million, and an unfavorable net change in operating assets and liabilities of $43.6 million. Non-cash expenses were primarily related to depreciation and amortization, share-based compensation expense, and deferred income taxes. The decrease in accounts receivable, net was primarily driven by lower sales, partially offset by the timing of sales within the quarter. The decrease in inventories was primarily driven by a reduction in inventory purchases to align with lower demand. The decrease in accounts payable was primarily driven by the reduction in inventory purchases. The decrease in accrued and other liabilities was primarily driven by a lower annual bonus accrual and lower marketing spend.

[0001032975-23-000021:mdna:165]
For fiscal year 2023, net cash used in investing activities was $105.7 million, primarily due to $92.4 million purchases of property, plant, and equipment. Our expenditures for property, plant and equipment during fiscal year 2023 were primarily for tooling and equipment, building improvements, and computer hardware and software.

[0001032975-23-000021:mdna:166]
For fiscal year 2023, net cash used in financing activities was $583.4 million, resulting from repurchases of our registered shares of $418.3 million, payments of cash dividends of $158.7 million, and tax withholdings related to

[0001032975-23-000021:mdna:167]
net share settlements of restricted stock units of $29.2 million, partially offset by proceeds from exercise of stock options and purchase rights of $28.8 million.

[0001032975-23-000021:mdna:168]
During fiscal year 2023, there was a $24.6 million loss from currency exchange rate effect on cash and cash equivalents, primarily due to exchange rate fluctuations of Euro, Swiss Franc, Chinese Renminbi, and Australian Dollar versus the U.S. Dollar and timing of our cash transactions over the period.

[0001032975-23-000021:mdna:169]
Cash Outlook

[0001032975-23-000021:mdna:170]
Our principal sources of liquidity are our cash and cash equivalents, cash flow generated from operations and, to a much lesser extent, capital markets and borrowings. Our future working capital requirements and capital expenditures may increase to support investments in product innovations and growth opportunities or to acquire or invest in complementary businesses, products, services, and technologies. Market volatility driven by the current macroeconomic and geopolitical environment may increase our costs of capital and otherwise adversely affect our business, results of operations, financial condition and liquidity.

[0001032975-23-000021:mdna:171]
In May 2023, the Board of Directors recommended that we pay cash dividends for fiscal year 2023 of CHF 1.06 per share (approximately $1.16 per share based on the exchange rate on March 31, 2023). Based on our shares outstanding, net of treasury shares, as of March 31, 2023 (159,343,273 shares), this would result in an aggregate gross dividend of approximately CHF 168.9 million (approximately $184.2 million based on the exchange rate on March 31, 2023). In fiscal year 2023, we paid a cash dividend of CHF 0.96 per share, or CHF 156.1 million (U.S. Dollar amount of $158.7 million based on the exchange rate on the date of payment) out of fiscal year 2022 retained earnings. In fiscal year 2022, we paid a cash dividend of CHF 0.87 per share, or CHF 147.0 million (U.S. Dollar amount of $159.4 million) out of fiscal year 2021 retained earnings. In fiscal year 2021, we paid a cash dividend of CHF 0.79 per share, or CHF 134.0 million (U.S. Dollar amount of $146.7 million) out of fiscal year 2020 retained earnings.

[0001032975-23-000021:mdna:172]
In May 2020, our Board of Directors approved the 2020 share repurchase program, which authorized us to invest up to $250.0 million to purchase our own shares. In April 2021, our Board of Directors approved an increase of $750.0 million to the 2020 share repurchase program, to an aggregate amount of $1.0 billion. The Swiss Takeover Board approved this increase and it became effective on May 21, 2021. In July 2022, our Board of Directors approved an increase of $500 million to the 2020 share repurchase program, to an aggregate amount of up to $1.5 billion to purchase up to 17.3 million of Logitech shares. The Swiss Takeover Board approved this increase and it became effective on August 19, 2022. As of March 31, 2023, $505.8 million was available for repurchase under the 2020 repurchase program.

[0001032975-23-000021:mdna:173]
Although we enter into trading plans for systematic repurchases (e.g., 10b5-1 trading plans) from time to time, our share repurchase program provides us with the opportunity to make opportunistic repurchases during periods of favorable market conditions and is expected to remain in effect for a period of three years through July 27, 2023. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Opportunistic purchases may be started or stopped at any time without prior notice depending on market conditions and other factors.

[0001032975-23-000021:mdna:174]
For over ten years, we have generated positive cash flows from our operating activities, including cash from operations of $534.0 million and $298.3 million during fiscal years 2023 and 2022, respectively. If we do not generate sufficient operating cash flows to support our operations and future planned cash requirements, our operations could be harmed and our access to credit facilities could be restricted or eliminated. However, we believe that the trend of our historical cash flow generation, our projections of future operations and our available cash balances will provide sufficient liquidity to fund our operations for at least the next 12 months.

[0001032975-23-000021:mdna:175]
Our other contractual obligations and commitments that require cash are described in the following sections.

[0001032975-23-000021:mdna:176]
Contractual Obligations and Commitments

[0001032975-23-000021:mdna:177]
Purchase Commitments

[0001032975-23-000021:mdna:178]
As of March 31, 2023, we had non-cancelable purchase commitments of $368.1 million for inventory purchases made in the normal course of business from original design manufacturers, contract manufacturers and other suppliers, the majority of which are expected to be fulfilled within the next 12 months. We recorded a liability for firm, non-cancelable, and unhedged inventory purchase commitments in excess of anticipated demand or net realizable value consistent with our valuation of excess and obsolete inventory. As of March 31, 2023, the liability for

[0001032975-23-000021:mdna:179]
these purchase commitments was $46.6 million and is recorded in accrued and other current liabilities in the consolidated balance sheet.

[0001032975-23-000021:mdna:180]
We have firm purchase commitments of $26.3 million for capital expenditures, primarily related to commitments for tooling and equipment for new and existing products and commitments to vendors to fit out and furnish office facilities. We expect to continue making capital expenditures in the future to support product development activities and ongoing and expanded operations. Although open purchase commitments are considered enforceable and legally binding, the terms generally allow us to reschedule or adjust our requirements based on business needs prior to delivery of goods or performance of services.

[0001032975-23-000021:mdna:181]
Operating Leases Obligation

[0001032975-23-000021:mdna:182]
We lease facilities under operating leases, certain of which require us to pay property taxes, insurance and maintenance costs. Operating leases for facilities are generally renewable at our option and usually include escalation clauses linked to inflation. The remaining terms of our non-cancelable operating leases expire in various years through 2033. See Note 17 - Leases in our Notes to the consolidated financial statements included in this report for more information on leases.

[0001032975-23-000021:mdna:183]
Income Taxes Payable

[0001032975-23-000021:mdna:184]
As of March 31, 2023, we had $106.4 million in non-current income taxes payable, including interest and penalties, related to our income tax liability for uncertain tax positions. At this time, we are unable to make a reasonably reliable estimate of the timing of payments in individual years in connection with these tax liabilities.

[0001032975-23-000021:mdna:185]
Indemnifications

[0001032975-23-000021:mdna:186]
We indemnify certain suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of March 31, 2023, no material amounts have been accrued for indemnification provisions. We do not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under our indemnification arrangements.

[0001032975-23-000021:mdna:187]
We also indemnify our current and former directors and certain current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. We are unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not capped, the obligations are conditional in nature, and the facts and circumstances involved in any situation that might arise are variable.
