# OMCL note change history — 0000926326-16-000077 → 0001628280-17-005045


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-05-05):
[0001628280-17-005045:note_history:1]
The Company leases office space and office equipment under operating leases. Commitments under operating leases primarily relate to leasehold property and office equipment. At March 31, 2017, the minimum future payments on non-cancelable operating leases were as follows:
  (was, 2016-11-07, similarity 0.9513):
[0000926326-16-000077:note_history:1]
The Company leases office space and office equipment under operating leases. Commitments under operating leases primarily relate to leasehold property and office equipment.  At September 30, 2016, the minimum future payments on non-cancelable operating leases were as follows:

- changed (2017-05-05):
[0001628280-17-005045:note_history:2]
|  | (In thousands) |
| Remaining nine months of 2017 | $ | 8,522 |  |
| 2018 | 11,389 |  |
| 2019 | 11,318 |  |
| 2020 | 7,375 |  |
| 2021 | 6,708 |  |
| Thereafter | 10,342 |  |
| Total minimum future lease payments | $ | 55,654 |  |
  (was, 2016-11-07, similarity 0.9806):
[0000926326-16-000077:note_history:2]
|  | (In thousands) |
| Remaining three months of 2016 | $ | 2,749 |  |
| 2017 | 10,755 |  |
| 2018 | 10,379 |  |
| 2019 | 10,127 |  |
| 2020 | 6,459 |  |
| Thereafter | 11,086 |  |
| Total minimum future lease payments | $ | 51,555 |  |

- changed (2017-05-05):
[0001628280-17-005045:note_history:3]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. At March 31, 2017, the Company had non-cancelable purchase commitments of $55.6 million, which are expected to be paid within the next twelve months.
  (was, 2016-11-07, similarity 0.6051):
[0000926326-16-000077:note_history:3]
During the course of the business, the Company issues purchase orders based on its current manufacturing needs.  At September 30, 2016, the Company had non-cancelable purchase commitments of $41.0 million, which are expected to be paid within the next twelve months.

- changed (2017-05-05):
[0001628280-17-005045:note_history:4]
The Company is currently involved in various legal proceedings. As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any accrual for contingent liabilities associated with any current legal proceedings based on its belief that any potential loss, while reasonably possible, is not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of this contingency or because of the diversion of management's attention and the creation of significant expenses.
  (was, 2016-11-07, similarity 0.9575):
[0000926326-16-000077:note_history:4]
The Company is currently involved in various legal proceedings. As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any accrual for contingent liabilities associated with the legal proceedings described below based on its belief that any potential loss, while reasonably possible, is not probable. Further, any possible range of loss in any current matters cannot be reasonably estimated at this time. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of this contingency or because of the diversion of management's attention and the creation of significant expenses.

- added (2017-05-05):
[0001628280-17-005045:note_history:5]
The Company is not a party to any legal proceedings that management believes may have a material impact on the Company's financial position or results of operations.

- removed (2017-05-05):
[0000926326-16-000077:note_history:6]
The Company’s legal proceeding as of September 30, 2016 was as follows:

- removed (2017-05-05):
[0000926326-16-000077:note_history:7]
On September 12, 2014, MV Circuit Design, Inc., an Ohio company ("MV Circuit"), brought an action to correct the inventorship of certain patents owned by the Company, as well as related state-law claims against the Company in the Northern District of Ohio (Case No. 1:14-cv-02028-DAP) regarding allegations of fraud in the filing and prosecution of U.S. Patent Nos. 8,180,485, 8,773,270, 8,812,153, PCT/US2007/003765, PCT/US2011/063597, and PCT/US2011/0635505 (the “Action”). On November 14, 2014, the Company filed a Motion to Dismiss the Action.  On March 24, 2015, the Court issued an Order granting in part and denying in part the Motion to Dismiss. Specifically, the Court granted the Company's Motion to Dismiss with respect to Counts 4, 5, and 6 (declaratory judgments regarding PCT/US2007/003765, PCT/US2011/063597, and PCT/US2011/0635505) and count 13 (civil conspiracy). Following an initial Case Management Conference on April 22, 2015, the Court ordered the parties to conduct limited discovery and actively discuss settlement options. On May 17, 2016 the parties reached a settlement agreement in which MV Circuit would dismiss the remaining claims and Omnicell would assign certain patents related to mobile medical cart to MV Circuit.  Omnicell has retained or secured all rights to continue to develop, manufacture, produce, market, license and sell all of its mobile cart product lines, including our SavvyTM mobile medication workstation. On June 1, 2016, the Court dismissed the case with prejudice.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-05-05):
[0001628280-17-005045:note_history:8]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of March 31, 2017 and December 31, 2016, the results of its operations, comprehensive income (loss) and cash flows for the three months ended March 31, 2017 and March 31, 2016. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company's annual report on Form 10-K for the year ended December 31, 2016 filed with the SEC on February 28, 2017. The Company's results of operations, comprehensive income (loss) and cash flows for the three months ended March 31, 2017 are not necessarily indicative of results that may be expected for the year ending December 31, 2017, or for any future period.
  (was, 2016-11-07, similarity 0.9324):
[0000926326-16-000077:note_history:8]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of September 30, 2016 and December 31, 2015, the results of its operations, comprehensive income (loss) and cash flows for the three and nine months ended September 30, 2016 and September 30, 2015. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company's annual report on Form 10-K for the year ended December 31, 2015 filed with the SEC on February 26, 2016. The Company's results of operations, comprehensive income (loss) and cash flows for the three and nine months ended September 30, 2016 are not necessarily indicative of results that may be expected for the year ending December 31, 2016, or for any future period.

- added (2017-05-05):
[0001628280-17-005045:note_history:9]
Certain prior year amounts have been reclassified to conform to the 2017 presentation. These reclassifications include: (i) provision for excess and obsolete inventories, and (ii) provision for the allowance for doubtful accounts have been reclassified/combined with inventories and accounts receivable within net cash provided by operating activities in the Consolidated Statements of Cash Flows. These changes are not material and do not impact previously disclosed net cash provided by operating activities, net cash used in investing activities, and net cash used by financing activities.

- added (2017-05-05):
[0001628280-17-005045:note_history:10]
Additionally, see "Recently adopted authoritative guidance" for the effects of first quarter adoption of ASU 2016-09, Compensation—Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting.

- changed (2017-05-05):
[0001628280-17-005045:note_history:11]
The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company's Condensed Consolidated Financial Statements and accompanying Notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management's best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. The Company's critical accounting policies are those that affect its financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition, accounts receivable and notes receivable from investment in sales-type leases, inventory valuation, capitalized software development costs, valuation and impairment of goodwill, purchased intangibles and long-lived assets, share-based compensation, and accounting for income taxes.
  (was, 2016-11-07, similarity 0.805):
[0000926326-16-000077:note_history:11]
The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company's Condensed Consolidated Financial Statements and accompanying Notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management's best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. The Company's critical accounting policies are those that affect its financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition, share-based compensation, inventory valuation, accounts receivable and notes receivable (investment in sales-type leases), capitalized software development costs, valuation of goodwill and purchased intangibles and long-lived assets, fair value of assets acquired and liabilities assumed in business combinations, and accounting for income taxes.

- changed (2017-05-05):
[0001628280-17-005045:note_history:12]
The Company's Chief Operating Decision Maker ("CODM") is its Chief Executive Officer. The CODM allocates resources and evaluates the performance of the Company's segments using information about its revenues, gross profit, and income from operations. Such evaluation excludes general corporate-level costs that are not specific to either of the reportable segments and are managed separately at the corporate level. Corporate-level costs include expenses related to executive management, finance and accounting, human resources, legal, training and development, and certain administrative expenses.  See Note 13, Segment and Geographical Information, for additional information on segment reporting.
  (was, 2016-11-07, similarity 0.9243):
[0000926326-16-000077:note_history:12]
The Company's Chief Operating Decision Maker ("CODM") is its Chief Executive Officer. The CODM allocates resources and evaluates the performance of the Company's segments using information about its revenues, gross profit, and income from operations. Such evaluation excludes general corporate-level costs that are not specific to either of the reportable segments and are managed separately at the corporate level.  Corporate-level costs include expenses related to executive management, finance and accounting, human resources, legal, training and development, and certain administrative expenses.

- added (2017-05-05):
[0001628280-17-005045:note_history:13]
In March 2016, the FASB issued ASU No. 2016-09, Compensation—Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting. This ASU simplifies several aspects of the accounting for share-based payment transactions, including the income tax consequences, classification of awards as either equity or liabilities, and classification on the statement of cash flows. The provision of ASU No. 2016-09 is effective for annual periods beginning after December 15, 2016, and interim periods within those annual periods. The Company adopted the standard effective January 1, 2017.  The impact of adoption was the recording of excess tax benefits within income tax expense, rather than in Additional Paid in Capital of $0.8 million for the three months ended March 31, 2017. The recording of excess tax benefits within income tax expense rather than Additional Paid in Capital resulted in a $0.02 per share improvement in the net loss to $(0.29) per share. Additionally, the Company recognized the previously unrecognized excess tax benefits using the modified retrospective transition method, which resulted in a cumulative-effect adjustment of $1.6 million to retained earnings. The previously unrecognized excess tax effects were recorded as a deferred tax asset. The Company also elected to apply the change in presentation to the statements of cash flows retrospectively and no longer classifies the excess tax benefits from employee stock plans as a reduction from operating cash flows, resulting in an increase of $0.2 million in the net cash provided by operating activities and a decrease of $0.2 million in the net cash provided by financing activities for the three months ended March 31, 2016. Additionally, on a prospective basis, the calculation of potential common shares for the dilutive earnings per share calculation (when profitable) no longer includes excess tax benefits under the Treasury buyback method, resulting in general in higher dilutive shares. Under ASU 2016-09, the Company made a policy election to continue with forfeiture estimation for expense calculation instead of the alternative of recognition only at forfeiture.

- added (2017-05-05):
[0001628280-17-005045:note_history:14]
In January 2017, the FASB issued ASU 2017-04, Intangibles-Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment, which simplifies the accounting for goodwill impairment for all entities by requiring impairment charges to be based on the first step in today’s two-step impairment test under ASC 350, “Intangibles-Goodwill and Other.” Under the new guidance, if a reporting unit’s carrying amount exceeds its fair value, an entity will record an impairment charge based on that difference. The impairment charge will be limited to the amount of goodwill allocated to that reporting unit. The standard eliminates the current ASC 350 requirement to calculate a goodwill impairment charge using Step 2. ASU 2017-14 is effective for annual and interim impairment tests performed in periods beginning after December 15, 2019. Early adoption is permitted for annual and interim goodwill impairment testing dates after January 1, 2017.  The Company adopted ASU 2017-04 effective January 1, 2017.  The adoption of this authoritative guidance did not have impact on the Company's Condensed Consolidated Financial Statements or related disclosures for the period presented.

- added (2017-05-05):
[0001628280-17-005045:note_history:15]
In January 2017, the FASB issued ASU 2017-01, Business Combinations, which clarifies the definition of a business and provides a screen to determine when a set of assets and activities is not a business. The screen requires that when substantially all of the fair value of the gross assets acquired (or disposed of) is concentrated in a single identifiable asset or a group of similar identifiable assets, the set is not a business. This screen reduces the number of transactions that need to be further evaluated. ASU 2017-01 is effective for fiscal years beginning after December 15, 2017, with early adoption permitted.  The Company adopted ASU 2017-01 effective January 1, 2017.  The adoption of this authoritative guidance did not have impact on the Company's Condensed Consolidated Financial Statements or related disclosures for the period presented.

- added (2017-05-05):
[0001628280-17-005045:note_history:16]
In May 2014, the FASB issued ASU 2014-09-Revenue from Contracts with Customers, which outlines a single, comprehensive model for entities to use in accounting for revenue arising from contracts with customers. The core principle of ASU 2014-09 is to recognize revenue when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. ASU 2014-09 defines a five step process to achieve this core principle and, accordingly, it is possible more judgment and estimates may be required within the revenue recognition process than is required under existing U.S. GAAP, including identifying performance obligations in the contract, estimating the amount of variable consideration to include in the transaction price and allocating the transaction price to each separate performance obligation. The FASB has recently issued several amendments to ASU 2014-09, including clarification on accounting for licenses of intellectual property and identifying performance obligations. ASU 2014-09 will be effective for the Company beginning January 1, 2018.

- added (2017-05-05):
[0001628280-17-005045:note_history:17]
The two permitted transition methods under ASU 2014-09 are the full retrospective method, in which case ASU 2014-09 would be applied to each prior reporting period presented and the cumulative effect of applying ASU 2014-09 would be recognized at the earliest period shown, or the modified retrospective method, in which case the cumulative effect of applying ASU 2014-09 would be recognized at the date of initial application. Currently, the Company is in the process of reviewing our historical contracts to quantify the impact on its consolidated financial statements. Depending on the results of the Company's review, there could be changes to the timing of revenue recognition and certain sales commission and related costs associated with obtaining and fulfilling its customer contracts. The Company will be required to capitalize and amortize incremental costs related to obtaining customer contracts, such as sales commission costs. The Company is also in the process of assessing the appropriate changes to its business processes and upgrading its systems and controls to support recognition and disclosure under ASU 2014-09. The Company otherwise expects to complete its assessment process, including selecting a transition method for adoption, in the next two quarters of 2017.

- removed (2017-05-05):
[0000926326-16-000077:note_history:18]
On January 5, 2016, the Company completed the acquisition of all of the membership interests of Aesynt Holding Coöperatief U.A. ("Aesynt"). The significant accounting policies of Aesynt have been aligned to conform to such accounting policies of Omnicell, and the consolidated financial statements include the results of operations of Aesynt commencing as of the acquisition date.

- removed (2017-05-05):
[0000926326-16-000077:note_history:19]
Certain prior year amounts for the provision for excess and obsolete inventories and provision for receivables allowance have been reclassified/combined with inventories and accounts receivable within net cash provided by operating activities in the Condensed Consolidated Statements of Cash Flows to conform to 2016 presentation. These changes are not material and do not impact previously disclosed net cash provided by operating activities, net cash used in investing activities, and net cash used by financing activities.

- removed (2017-05-05):
[0000926326-16-000077:note_history:20]
The operating results of the acquired Aesynt business are included in the Company's Automation and Analytics reportable segment.

- removed (2017-05-05):
[0000926326-16-000077:note_history:21]
Interest rate swap agreements

- removed (2017-05-05):
[0000926326-16-000077:note_history:22]
During the second quarter of 2016, the Company entered into interest rate swap agreements. The interest rate swap agreements, at their inception, qualified for and were designated as cash flow hedging instruments. In accordance with the Derivatives and Hedging Topic of the Accounting Standards Codification ("ASC"), the Company records its interest rate swaps on its condensed consolidated balance sheet at fair value. The effective portion of changes in fair value are recorded in accumulated other comprehensive loss and are subsequently reclassified into earnings in the period that the hedged forecasted transaction affects earnings. Any ineffective portion is recognized in earnings. Both at inception and on a quarterly basis, the Company performs an effectiveness test. For further information regarding these interest rate swap agreements, please refer to  Note 4, "Derivative Financial Instruments" below.

- removed (2017-05-05):
[0000926326-16-000077:note_history:23]
In April 2015, the Financial Accounting Standards Board ("FASB") issued ASU 2015-05-Intangibles-Goodwill and Other-Internal-Use Software- Customer’s Accounting for Fees Paid in a Cloud Computing Arrangement, which provides guidance on determining whether a cloud computing arrangement contains a software license. If a cloud computing arrangement includes a software license, then the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If a cloud computing arrangement does not include a software license, the customer should account for the arrangement as a service contract. The Company adopted ASU 2015-05 on a prospective basis beginning on January 1, 2016. The impact of ASU 2015-05 did not have a material impact on the Company's consolidated financial position or results of operations for the three and nine months ended September 30, 2016.

- removed (2017-05-05):
[0000926326-16-000077:note_history:24]
In July 2015, the FASB issued ASU No. 2015-11, Simplifying the Measurement of Inventory. This ASU changes the measurement principle for inventory from the lower of cost or market to lower of cost and net realizable value. Net realizable value is the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal and transportation. It applies to entities that measure inventory using a method other than last-in, first-out (LIFO) and the retail inventory method (RIM). The guidance is effective for fiscal years beginning after December 15, 2016. The adoption of this accounting standard update did not have a material impact on the Company's consolidated financial position or results of operations for the three and nine months ended September 30, 2016.

- removed (2017-05-05):
[0000926326-16-000077:note_history:25]
In September 2015, the FASB issued ASU No. 2015-16, Business Combinations (Topic 805): Simplifying the Accounting for Measurement-Period Adjustments. This ASU requires adjustments to provisional amounts that are identified during the measurement period of a business combination to be recognized in the reporting period in which the adjustment amounts are determined. An acquirer is no longer required to revise comparative information for prior periods as if the accounting for the business combination had been completed as of the acquisition date. The provisions of ASU 2015-16 are effective for reporting periods beginning after December 15, 2015. The adoption of this accounting standard update did not have a material impact on the Company's consolidated financial position or results of operations for the three and nine months ended September 30, 2016.

- removed (2017-05-05):
[0000926326-16-000077:note_history:26]
In March 2016, the FASB issued ASU No. 2016-09, Compensation—Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting. This ASU simplifies several aspects of the accounting for share-based payment transactions, including the income tax consequences, classification of awards as either equity or liabilities, and classification on the statement of cash flows. The provision of ASU No. 2016-09 are effective for annual periods beginning after December 15, 2016, and interim periods within those annual periods. Early adoption is permitted for any entity in any interim or annual period. If an entity early adopts the amendments in an interim period, any adjustments are reflected as of the beginning of the fiscal year that includes that interim period. An entity that elects early adoption must adopt all of the amendments in the same period. The Company is currently in the process of evaluating the impact of the adoption of ASU 2016-09 on its consolidated financial statements.

- removed (2017-05-05):
[0000926326-16-000077:note_history:27]
In August 2016, the FASB issued ASU No. 2016-15, Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments. This ASU requires changes in the presentation of certain items including but not limited to debt prepayment or debt extinguishment costs; contingent consideration payments made after a business combination; proceeds from the settlement of insurance claims; proceeds from the settlement of corporate-owned life insurance policies and distributions received from equity method investees. The new guidance will be effective for fiscal years beginning after December 15, 2017, including interim periods within those fiscal years and should be applied prospectively. Early adoption is permitted as of the beginning of an interim or annual reporting period. The Company is currently evaluating the impact ASU 2016-15 will have on its consolidated financial statements.

- removed (2017-05-05):
[0000926326-16-000077:note_history:28]
In October 2016, the FASB issued ASU No. 2016-16, Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory, which reduces the complexity in the accounting standards by allowing the recognition of current and deferred income taxes for an intra-entity asset transfer, other than inventory, when the transfer occurs. Historically, recognition of the income tax consequence was not recognized until the asset was sold to an outside party.  This amendment should be applied on a modified retrospective basis through a cumulative-effect adjustment directly to retained earnings as of the beginning of the period of adoption.  ASU 2016-16 is effective for annual periods beginning after December 15, 2017, including interim reporting periods within those annual reporting periods.  Early adoption is permitted for all entities as of the beginning of an annual reporting period for which financial statements (interim or annual) have not been issued or made available for issuance. The Company is currently evaluating the impact ASU 2016-16 will have on its consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-05-05):
[0001628280-17-005045:note_history:29]
The Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends and other distributions. The Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum consolidated total leverage ratio and maintain a minimum fixed charge coverage ratio.  The Company’s obligations under the Credit Agreement and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and the subsidiary guarantors’ assets. In connection with entering into the Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a collateral agreement and subsidiary guaranty agreement.
  (was, 2016-11-07, similarity 0.9685):
[0000926326-16-000077:note_history:29]
The Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends and other distributions. The Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum consolidated total leverage ratio and maintain a minimum fixed charge coverage ratio.  The Company’s obligations under the Credit Agreement and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and the subsidiary guarantors’ assets. In connection with entering into the Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a collateral agreement and subsidiary guaranty agreement.  The Company was in full compliance with all covenants as of September 30, 2016.

- added (2017-05-05):
[0001628280-17-005045:note_history:30]
On January 5, 2016, the Company borrowed the full $200.0 million under the Term Loan Facility and $55.0 million under the Revolving Credit Facility to complete the Aesynt acquisition and pay related fees and expenses.  On December 2, 2016, the Company borrowed an additional $40.0 million under the Revolver Credit Facility to complete the Ateb acquisition and pay related fees and expenses. As of March 31, 2017 the Company has repaid $74.5 million borrowed under these Facilities, which includes $40.0 million repaid during the three months ended March 31, 2017.

- added (2017-05-05):
[0001628280-17-005045:note_history:31]
On April 11, 2017, the parties entered into the First Amendment to Credit Agreement and Collateral Agreement. Under this amendment, (i) the maximum capital expenditures limit in any fiscal year for property, plant and equipment and software development increased from $35.0 million to $45.0 million, and (ii) the maximum limit for non-permitted investments increased from $10.0 million to $20.0 million.

- added (2017-05-05):
[0001628280-17-005045:note_history:32]
In connection with these Facilities, the Company incurred $7.9 million of debt issuance costs. The debt issuance costs were capitalized and presented as a direct deduction from the carrying amount of that debt liability in accordance with the accounting guidance. The debt issuance costs are being amortized to interest expense using the straight line method from issuance date through 2021. Interest expense (exclusive of fees and issuance cost amortization) was approximately $1.5 million for the three months ended March 31, 2017 and 2016.  The Company was in full compliance with all covenants as of March 31, 2017 and December 31, 2016.

- changed (2017-05-05):
[0001628280-17-005045:note_history:33]
The components of the Company’s debt obligations for the three months ended March 31, 2017 are as follows:
  (was, 2016-11-07, similarity 0.7822):
[0000926326-16-000077:note_history:33]
The components of the Company’s debt obligations as of September 30, 2016 and December 31, 2015 are as follows:

- added (2017-05-05):
[0001628280-17-005045:note_history:34]
|  | December 31, 2016 |  | Borrowings |  | Repayment / Amortization |  | March 31, 2017 |
|  | (In thousands) |
| Term loan facility | $ | 192,500 |  |  | $ | — |  |  | $ | (2,500 | ) |  | $ | 190,000 |  |
| Revolving credit facility | 68,000 |  |  | — |  |  | (37,500 | ) |  | 30,500 |  |
| Total debt under the facilities | 260,500 |  |  | — |  |  | (40,000 | ) |  | 220,500 |  |
| Less: Deferred issuance cost | (6,359 | ) |  | — |  |  | 397 |  |  | (5,962 | ) |
| Total Debt, net of deferred issuance cost | $ | 254,141 |  |  | $ | — |  |  | $ | (39,603 | ) |  | $ | 214,538 |  |
| Long term debt, current portion, net of deferred issuance cost | 8,410 |  |  |  |  |  |  | 8,410 |  |
| Long term debt, net of deferred issuance cost | $ | 245,731 |  |  |  |  |  |  | $ | 206,128 |  |

- added (2017-05-05):
[0001628280-17-005045:note_history:35]
As of March 31, 2017, the carrying amount, net of deferred issuance cost, of $214.5 million approximates the comparable fair value of $217.8 million. The Company's debt facilities are classified as a Level 3 in the fair value hierarchy. The calculation of the fair value is based on a discounted cash flow model using observable market inputs and taking into consideration variables such as interest rate changes, comparable instruments, and long-term credit ratings.

- removed (2017-05-05):
[0000926326-16-000077:note_history:36]
On January 5, 2016, the Company borrowed the full $200 million under the Term Loan Facility and $55 million under the Revolving Credit Facility to complete the Aesynt acquisition and pay related fees and expenses. In connection with these Facilities, the Company incurred $7.9 million of debt issuance costs. The debt issuance costs were capitalized and presented as a direct deduction from the carrying amount of that debt liability in accordance with the accounting guidance. The debt issuance costs are being amortized to interest expense using the straight line method from issuance date through 2021.

- removed (2017-05-05):
[0000926326-16-000077:note_history:37]
|  | December 31, 2015 | Borrowings | Repayment/Amortization | September 30, 2016 |
|  | (In thousands) |
| Term loan facility | $ | — |  | $ | 200,000 |  | $ | (5,000 | ) | $ | 195,000 |  |
| Revolving credit facility | — |  | 55,000 |  | (20,000 | ) | 35,000 |  |
| Total debt under the facilities(1) | — |  | 255,000 |  | (25,000 | ) | 230,000 |  |
| Less: Deferred issuance cost | — |  | (7,949 | ) | 1,193 |  | (6,756 | ) |
| Total Debt, net of deferred issuance cost | $ | — |  | $ | 247,051 |  | $ | (23,807 | ) | 223,244 |  |
| Long term debt, current portion, net of deferred issuance cost |  |  |  | 8,410 |  |
| Long term debt, net of deferred issuance cost |  |  |  | $ | 214,834 |  |

- removed (2017-05-05):
[0000926326-16-000077:note_history:38]
(1) The fair value of total debt under the facilities approximates the book value as of September 30, 2016.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-05-05):
[0001628280-17-005045:note_history:39]
The components of the Company’s debt obligations for the three months ended March 31, 2017 are as follows:
  (was, 2016-11-07, similarity 0.7822):
[0000926326-16-000077:note_history:39]
The components of the Company’s debt obligations as of September 30, 2016 and December 31, 2015 are as follows:

- added (2017-05-05):
[0001628280-17-005045:note_history:40]
|  | December 31, 2016 |  | Borrowings |  | Repayment / Amortization |  | March 31, 2017 |
|  | (In thousands) |
| Term loan facility | $ | 192,500 |  |  | $ | — |  |  | $ | (2,500 | ) |  | $ | 190,000 |  |
| Revolving credit facility | 68,000 |  |  | — |  |  | (37,500 | ) |  | 30,500 |  |
| Total debt under the facilities | 260,500 |  |  | — |  |  | (40,000 | ) |  | 220,500 |  |
| Less: Deferred issuance cost | (6,359 | ) |  | — |  |  | 397 |  |  | (5,962 | ) |
| Total Debt, net of deferred issuance cost | $ | 254,141 |  |  | $ | — |  |  | $ | (39,603 | ) |  | $ | 214,538 |  |
| Long term debt, current portion, net of deferred issuance cost | 8,410 |  |  |  |  |  |  | 8,410 |  |
| Long term debt, net of deferred issuance cost | $ | 245,731 |  |  |  |  |  |  | $ | 206,128 |  |

- removed (2017-05-05):
[0000926326-16-000077:note_history:41]
|  | December 31, 2015 | Borrowings | Repayment/Amortization | September 30, 2016 |
|  | (In thousands) |
| Term loan facility | $ | — |  | $ | 200,000 |  | $ | (5,000 | ) | $ | 195,000 |  |
| Revolving credit facility | — |  | 55,000 |  | (20,000 | ) | 35,000 |  |
| Total debt under the facilities(1) | — |  | 255,000 |  | (25,000 | ) | 230,000 |  |
| Less: Deferred issuance cost | — |  | (7,949 | ) | 1,193 |  | (6,756 | ) |
| Total Debt, net of deferred issuance cost | $ | — |  | $ | 247,051 |  | $ | (23,807 | ) | 223,244 |  |
| Long term debt, current portion, net of deferred issuance cost |  |  |  | 8,410 |  |
| Long term debt, net of deferred issuance cost |  |  |  | $ | 214,834 |  |

- removed (2017-05-05):
[0000926326-16-000077:note_history:42]
(1) The fair value of total debt under the facilities approximates the book value as of September 30, 2016.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2017-05-05):
[0001628280-17-005045:note_history:43]
Subsequent Event

- added (2017-05-05):
[0001628280-17-005045:note_history:44]
On April 19, 2017, the Company announced the acquisition of Dixie Drawl, LLC d/b/a InPharmics ("InPharmics"), a Mississippi-based technology and services company that provides advanced pharmacy informatics solutions to hospital pharmacies, in an all-cash transaction for $5.3 million. The acquisition will expand the capabilities of Omnicell's Performance Center™. The Company is in the process of evaluating the business combination accounting considerations, including the consideration transferred and the initial purchase price allocation.
