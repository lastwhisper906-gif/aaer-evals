# OMCL notes — 0001628280-17-005045


## omcl:ScheduleofLongTermNetInvestmentinSaleTypeLeasesTableTextBlock

[0001628280-17-005045:notes:1]
The receivables as a result of these types of transactions are collateralized by the underlying equipment leased and consist of the following components at March 31, 2017 and December 31, 2016:

[0001628280-17-005045:notes:2]
|  | March 31, 2017 |  | December 31, 2016 |
|  | (In thousands) |
| Net minimum lease payments to be received | $ | 32,214 |  |  | $ | 33,591 |  |
| Less: Unearned interest income portion | (2,506 | ) |  | (2,763 | ) |
| Net investment in sales-type leases | 29,708 |  |  | 30,828 |  |
| Less: Short-term portion(1) | (10,534 | ) |  | (10,243 | ) |
| Long-term net investment in sales-type leases | $ | 19,174 |  |  | $ | 20,585 |  |

[0001628280-17-005045:notes:3]
(1) The short-term portion of the net investments in sales-type leases is included in other current assets in the Condensed Consolidated Balance Sheets.


## omcl:ScheduleofSharebasedCompensationFutureIssuanceofSharesTableTextBlock

[0001628280-17-005045:notes:4]
The Company had the following ordinary shares reserved for future issuance under its equity incentive plans as of March 31, 2017

[0001628280-17-005045:notes:5]
|  | Number of Shares |
|  | (In thousands) |
| Share options outstanding | 3,350 |  |
| Non-vested restricted share awards | 836 |  |
| Shares authorized for future issuance | 2,411 |  |
| ESPP shares available for future issuance | 2,572 |  |
| Total shares reserved for future issuance | 9,169 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001628280-17-005045:notes:6]
[same as prior period, unchanged from 0000926326-16-000077:notes:6]

[0001628280-17-005045:notes:7]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of March 31, 2017 and December 31, 2016, the results of its operations, comprehensive income (loss) and cash flows for the three months ended March 31, 2017 and March 31, 2016. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company's annual report on Form 10-K for the year ended December 31, 2016 filed with the SEC on February 28, 2017. The Company's results of operations, comprehensive income (loss) and cash flows for the three months ended March 31, 2017 are not necessarily indicative of results that may be expected for the year ending December 31, 2017, or for any future period.


## us-gaap:CapitalLeasesInFinancialStatementsOfLessorDisclosureTextBlock

[0001628280-17-005045:notes:8]
Net Investment in Sales-Type Leases

[0001628280-17-005045:notes:9]
On a recurring basis, we enter into sales-type lease transactions which vary in length from one to five years. The receivables as a result of these types of transactions are collateralized by the underlying equipment leased and consist of the following components at March 31, 2017 and December 31, 2016:

[0001628280-17-005045:notes:10]
The Company evaluates its sales-type leases individually and collectively for impairment.  The allowance for credit losses were $0.2 million and $0.3 million as of March 31, 2017 and of December 31, 2016, respectively.

[0001628280-17-005045:notes:11]
At March 31, 2017, the future minimum lease payments under sales-type leases are as follows:

[0001628280-17-005045:notes:12]
|  | March 31, 2017 |
|  | (In thousands) |
| Remaining nine months of 2017 | $ | 9,397 |  |
| 2018 | 7,988 |  |
| 2019 | 6,264 |  |
| 2020 | 4,139 |  |
| 2021 | 2,304 |  |
| Thereafter | 2,122 |  |
| Total | $ | 32,214 |  |


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0001628280-17-005045:notes:13]
Commitments and Contingencies

[0001628280-17-005045:notes:14]
Lease commitments

[0001628280-17-005045:notes:15]
The Company leases office space and office equipment under operating leases. Commitments under operating leases primarily relate to leasehold property and office equipment. At March 31, 2017, the minimum future payments on non-cancelable operating leases were as follows:

[0001628280-17-005045:notes:16]
|  | (In thousands) |
| Remaining nine months of 2017 | $ | 8,522 |  |
| 2018 | 11,389 |  |
| 2019 | 11,318 |  |
| 2020 | 7,375 |  |
| 2021 | 6,708 |  |
| Thereafter | 10,342 |  |
| Total minimum future lease payments | $ | 55,654 |  |

[0001628280-17-005045:notes:17]
Purchase obligations

[0001628280-17-005045:notes:18]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. At March 31, 2017, the Company had non-cancelable purchase commitments of $55.6 million, which are expected to be paid within the next twelve months.

[0001628280-17-005045:notes:19]
Legal Proceedings

[0001628280-17-005045:notes:20]
The Company is currently involved in various legal proceedings. As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any accrual for contingent liabilities associated with any current legal proceedings based on its belief that any potential loss, while reasonably possible, is not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of this contingency or because of the diversion of management's attention and the creation of significant expenses.

[0001628280-17-005045:notes:21]
The Company is not a party to any legal proceedings that management believes may have a material impact on the Company's financial position or results of operations.


## us-gaap:ConsolidationPolicyTextBlock

[0001628280-17-005045:notes:22]
[same as prior period, unchanged from 0000926326-16-000077:notes:25]

[0001628280-17-005045:notes:23]
[same as prior period, unchanged from 0000926326-16-000077:notes:26]


## us-gaap:DebtDisclosureTextBlock

[0001628280-17-005045:notes:24]
Debt

[0001628280-17-005045:notes:25]
On January 5, 2016, the Company entered into a $400 million senior secured credit facility pursuant to a credit agreement, by and among the Company, the lenders from time to time party thereto, Wells Fargo Securities, LLC, as Sole Lead Arranger and Wells Fargo Bank, National Association, as administrative agent (the “Credit Agreement”). The Credit Agreement provides for (a) a five-year revolving credit facility of $200 million (the “Revolving Credit Facility”) and (b) a five-year $200 million term loan facility (the “Term Loan Facility” and together with the Revolving Credit Facility, the “Facilities”). In addition, the Credit Agreement includes a letter of credit sub-limit of up to $10 million and a swing line loan sub-limit of up to $10 million. The Credit Agreement expires on January 5, 2021, upon which date all remaining outstanding borrowings are due and payable.

[0001628280-17-005045:notes:26]
Loans under the Facilities bear interest, at the Company’s option, at a rate equal to either (a) the LIBOR Rate, plus an applicable margin ranging from 1.50% to 2.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) LIBOR for an interest period of one month, plus an applicable margin ranging from 0.50% to 1.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the 2016 Credit Agreement). Undrawn commitments under the Revolving Credit Facility will be subject to a commitment fee ranging from 0.20% to 0.35% per annum based on the Company’s Consolidated Total Net Leverage Ratio on the average daily unused portion of the Revolving Credit Facility. A letter of credit participation fee ranging from 1.50% to 2.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio will accrue on the average daily amount of letter of credit exposure.

[0001628280-17-005045:notes:27]
The Company is permitted to make voluntary prepayments at any time without payment of a premium or penalty, except for any amounts relating to the LIBOR breakage indemnity described in the Credit Agreement. The Company is required to make mandatory prepayments under the Term Loan Facility with (a) net cash proceeds from any issuances of debt (other than certain permitted debt) and (b) net cash proceeds from certain asset dispositions (other than certain asset dispositions) and insurance and condemnation events (subject to reinvestment rights and certain other exceptions). Loans under the Term Loan Facility will amortize in quarterly installments, equal to 5% per annum of the original principal amount thereof during the first two years, which shall increase to 10% per annum during the third and fourth years, and 15% per annum during the fifth year, with the remaining balance payable on January 5, 2021. The Company is required to make mandatory prepayments under the Revolving Credit Facility if at any time the aggregate outstanding principal amount of loans together with the total amount of outstanding letters of credit exceeds the aggregate commitments, with such mandatory prepayment to be equal to the amount of such excess.

[0001628280-17-005045:notes:28]
The Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends and other distributions. The Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum consolidated total leverage ratio and maintain a minimum fixed charge coverage ratio.  The Company’s obligations under the Credit Agreement and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and the subsidiary guarantors’ assets. In connection with entering into the Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a collateral agreement and subsidiary guaranty agreement.

[0001628280-17-005045:notes:29]
On January 5, 2016, the Company borrowed the full $200.0 million under the Term Loan Facility and $55.0 million under the Revolving Credit Facility to complete the Aesynt acquisition and pay related fees and expenses.  On December 2, 2016, the Company borrowed an additional $40.0 million under the Revolver Credit Facility to complete the Ateb acquisition and pay related fees and expenses. As of March 31, 2017 the Company has repaid $74.5 million borrowed under these Facilities, which includes $40.0 million repaid during the three months ended March 31, 2017.

[0001628280-17-005045:notes:30]
On April 11, 2017, the parties entered into the First Amendment to Credit Agreement and Collateral Agreement. Under this amendment, (i) the maximum capital expenditures limit in any fiscal year for property, plant and equipment and software development increased from $35.0 million to $45.0 million, and (ii) the maximum limit for non-permitted investments increased from $10.0 million to $20.0 million.

[0001628280-17-005045:notes:31]
In connection with these Facilities, the Company incurred $7.9 million of debt issuance costs. The debt issuance costs were capitalized and presented as a direct deduction from the carrying amount of that debt liability in accordance with the accounting guidance. The debt issuance costs are being amortized to interest expense using the straight line method from issuance date through 2021. Interest expense (exclusive of fees and issuance cost amortization) was approximately $1.5 million for the three months ended March 31, 2017 and 2016.  The Company was in full compliance with all covenants as of March 31, 2017 and December 31, 2016.

[0001628280-17-005045:notes:32]
The components of the Company’s debt obligations for the three months ended March 31, 2017 are as follows:

[0001628280-17-005045:notes:33]
|  | December 31, 2016 |  | Borrowings |  | Repayment / Amortization |  | March 31, 2017 |
|  | (In thousands) |
| Term loan facility | $ | 192,500 |  |  | $ | — |  |  | $ | (2,500 | ) |  | $ | 190,000 |  |
| Revolving credit facility | 68,000 |  |  | — |  |  | (37,500 | ) |  | 30,500 |  |
| Total debt under the facilities | 260,500 |  |  | — |  |  | (40,000 | ) |  | 220,500 |  |
| Less: Deferred issuance cost | (6,359 | ) |  | — |  |  | 397 |  |  | (5,962 | ) |
| Total Debt, net of deferred issuance cost | $ | 254,141 |  |  | $ | — |  |  | $ | (39,603 | ) |  | $ | 214,538 |  |
| Long term debt, current portion, net of deferred issuance cost | 8,410 |  |  |  |  |  |  | 8,410 |  |
| Long term debt, net of deferred issuance cost | $ | 245,731 |  |  |  |  |  |  | $ | 206,128 |  |

[0001628280-17-005045:notes:34]
As of March 31, 2017, the carrying amount, net of deferred issuance cost, of $214.5 million approximates the comparable fair value of $217.8 million. The Company's debt facilities are classified as a Level 3 in the fair value hierarchy. The calculation of the fair value is based on a discounted cash flow model using observable market inputs and taking into consideration variables such as interest rate changes, comparable instruments, and long-term credit ratings.


## us-gaap:DeferredRevenueDisclosureTextBlock

[0001628280-17-005045:notes:35]
[same as prior period, unchanged from 0000926326-16-000077:notes:36]

[0001628280-17-005045:notes:36]
Short-term deferred revenue includes deferred revenue from product sales and service contracts, net of deferred cost of sales of $16.4 million and $14.2 million as of March 31, 2017 and December 31, 2016, respectively. The short-term deferred revenues from product sales relate to the delivered and invoiced products, pending installation and acceptance, expected to occur within the next twelve months.

[0001628280-17-005045:notes:37]
Long-term deferred revenue includes deferred revenue from service contracts of $16.0 million and $17.1 million, as of March 31, 2017 and December 31, 2016, respectively.


## us-gaap:EarningsPerShareTextBlock

[0001628280-17-005045:notes:38]
Net Loss Per Share

[0001628280-17-005045:notes:39]
Basic net loss per share is computed by dividing net loss for the period by the weighted-average number of shares outstanding during the period, less shares repurchased. In periods of net loss, all potential common shares are anti-dilutive, so diluted net loss per share equals the basic net loss per share. In periods of net income, diluted net income per share is computed by dividing net income for the period by the basic weighted-average number of shares plus any dilutive potential common stock outstanding during the period. Potential common stock includes the effect of outstanding dilutive stock options, restricted stock awards and restricted stock units computed using the treasury stock method. Any anti-dilutive weighted-average dilutive shares related to stock award plans are excluded from the computation of the diluted net income per share.

[0001628280-17-005045:notes:40]
The calculation of basic and diluted net loss per share for the three months ended March 31, 2017 and March 31, 2016 is as follows:

[0001628280-17-005045:notes:41]
|  | Three months ended March 31, |
|  | 2017 |  | 2016 |
|  | (In thousands, except per share data) |
| Net loss | $ | (10,754 | ) |  | $ | (378 | ) |
| Weighted-average shares outstanding — basic | 36,840 |  |  | 35,740 |  |
| Effect of dilutive securities from stock award plans | — |  |  | — |  |
| Weighted-average shares outstanding — diluted | 36,840 |  |  | 35,740 |  |
| Net loss per share - basic and diluted | $ | (0.29 | ) |  | $ | (0.01 | ) |
| Anti-dilutive weighted-average shares related to stock award plans | 4,236 |  |  | 2,045 |  |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001628280-17-005045:notes:42]
The following table represents the fair value hierarchy of the Company’s financial assets and financial liabilities measured at fair value as of March 31, 2017:

[0001628280-17-005045:notes:43]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Interest rate swap contracts | $ | — |  |  | $ | 1,427 |  |  | $ | — |  |  | $ | 1,427 |  |
| Total financial assets | $ | — |  |  | $ | 1,427 |  |  | $ | — |  |  | $ | 1,427 |  |
| Contingent consideration liability | $ | — |  |  | $ | — |  |  | $ | 2,400 |  |  | $ | 2,400 |  |
| Total financial liabilities | $ | — |  |  | $ | — |  |  | $ | 2,400 |  |  | $ | 2,400 |  |

[0001628280-17-005045:notes:44]
There have been no transfers between fair value measurement levels during the three months ended March 31, 2017 and March 31, 2016.

[0001628280-17-005045:notes:45]
The following table represents the fair value hierarchy of the Company’s financial assets and financial liabilities measured at fair value as of December 31, 2016:

[0001628280-17-005045:notes:46]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Interest rate swap contracts | $ | — |  |  | $ | 1,245 |  |  | $ | — |  |  | $ | 1,245 |  |
| Total financial assets | $ | — |  |  | $ | 1,245 |  |  | $ | — |  |  | $ | 1,245 |  |
| Contingent consideration liability | $ | — |  |  | $ | — |  |  | $ | 2,400 |  |  | $ | 2,400 |  |
| Total financial liabilities | $ | — |  |  | $ | — |  |  | $ | 2,400 |  |  | $ | 2,400 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-17-005045:notes:47]
[same as prior period, unchanged from 0000926326-16-000077:notes:53]

[0001628280-17-005045:notes:48]
Cash and cash equivalents of $46.3 million and $54.5 million as of March 31, 2017 and December 31, 2016, respectively, consisted of demand deposits only.

[0001628280-17-005045:notes:49]
[same as prior period, unchanged from 0000926326-16-000077:notes:55]

[0001628280-17-005045:notes:50]
The Company measures its financial instruments at fair value. The Company’s cash equivalents are classified within Level 1 of the fair value hierarchy as they are valued primarily using quoted market prices utilizing market observable inputs. The Company's foreign currency contracts are classified within Level 2 as the valuation inputs are based on quoted prices and market observable data of similar instruments. In accordance with the 2015 Avantec share purchase agreement, the Company agreed to make potential earn-out payments based on the achievement of bookings targets. Actual payments earned and paid were $3.0 million during the year ended 2016. We had $2.4 million of potential earn-out payments accrued as of March 31, 2017.  The contingent consideration is at fair value and not subject to future accretion. The Company's contingent consideration liability is classified within Level 3, as valuation inputs which include the achievement of booking targets and the discount rate were unobservable in the market and significant to the instrument’s valuation.

[0001628280-17-005045:notes:51]
Net investment in sales-type leases. The carrying amount of the Company's sales-type lease receivables is a reasonable estimate of fair value, as the unearned interest income is immaterial.

[0001628280-17-005045:notes:52]
[same as prior period, unchanged from 0000926326-16-000077:notes:58]

[0001628280-17-005045:notes:53]
The Company uses interest rate swap agreements to protect the Company against adverse fluctuations in interest rates by reducing its exposure to variability in cash flows relating to interest payments on a portion of its outstanding debt. The Company's interest rate swaps, which are designated as cash flow hedges, involve the receipt of variable amounts from counterparties in exchange for the Company making fixed-rate payments over the life of the agreements. The Company does not hold or issue any derivative financial instruments for speculative trading purposes.

[0001628280-17-005045:notes:54]
During 2016, the Company entered into an interest rate swap agreement with a combined notional amount of $100.0 million with one counter-party that became effective on June 30, 2016 and is maturing on April 30, 2019. The swap agreement requires the Company to pay a fixed rate of 0.8% and provides that the Company will receive a variable rate based on the one month LIBOR rate subject to a LIBOR floor of 0.0%. Amounts payable by or due to the Company will be net settled with the respective counter-party on the last business day of each month, commencing July 31, 2016.

[0001628280-17-005045:notes:55]
The fair value of the interest rate swap agreements at March 31, 2017 and December 31, 2016 was $1.4 million and $1.2 million, respectively. There were no amounts reclassified into current earnings due to ineffectiveness during the periods presented.


## us-gaap:FiniteLivedAndIndefiniteLivedIntangibleAssetsAcquiredAsPartOfBusinessCombinationTableTextBlock

[0001628280-17-005045:notes:56]
The identifiable intangible assets acquired and their estimated useful lives for amortization are as follows:

[0001628280-17-005045:notes:57]
|  | Aesynt |  | Ateb |
|  | Fair value |  | Weightedaverageuseful life |  | Fair value |  | Weightedaverageuseful life |
|  | (In thousands) |  | (In years) |  | (In thousands) |  | (In years) |
| Customer relationships | $ | 58,200 |  |  | 14-16 |  | $ | 8,900 |  |  | 12 |
| Developed technology | 38,800 |  |  | 8 |  | 3,400 |  |  | 5 |
| Backlog | 20,200 |  |  | 1-3 |  | — |  | — |
| In-process research and development (1) | 3,900 |  |  | — |  | — |  | — |
| Non-compete | 1,800 |  |  | 3 |  | 100 |  |  | 1 |
| Trade names | 800 |  |  | 1 |  | 100 |  |  | 1 |
| Total purchased intangible assets | $ | 123,700 |  |  |  |  | $ | 12,500 |  |  |  |

[0001628280-17-005045:notes:58]
(1) The amortization of the in-process R&D assets begins when the in-process R&D projects are complete.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001628280-17-005045:notes:59]
[same as prior period, unchanged from 0000926326-16-000077:notes:62]

[0001628280-17-005045:notes:60]
[same as prior period, unchanged from 0000926326-16-000077:notes:63]

[0001628280-17-005045:notes:61]
[same as prior period, unchanged from 0000926326-16-000077:notes:64]

[0001628280-17-005045:notes:62]
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |
|  | (In thousands) |
| Net balance as of December 31, 2016 | $ | 215,082 |  |  | $ | 112,642 |  |  | $ | 327,724 |  |
| Foreign currency exchange rate fluctuations | 342 |  |  | 150 |  |  | 492 |  |
| Net balance as of March 31, 2017 | $ | 215,424 |  |  | $ | 112,792 |  |  | $ | 328,216 |  |

[0001628280-17-005045:notes:63]
[same as prior period, unchanged from 0000926326-16-000077:notes:66]

[0001628280-17-005045:notes:64]
The carrying amounts of intangibles assets as of March 31, 2017 and December 31, 2016 are as follows:

[0001628280-17-005045:notes:65]
|  | March 31, 2017 |
|  | Grosscarryingamount |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 132,579 |  |  | $ | (23,974 | ) |  | $ | 143 |  |  | $ | 108,748 |  |  | 1 - 30 |
| Acquired technology | 73,409 |  |  | (15,264 | ) |  | 28 |  |  | 58,173 |  |  | 3 - 20 |
| Backlog | 20,533 |  |  | (14,875 | ) |  | — |  |  | 5,658 |  |  | 1 - 3 |
| Trade names | 8,607 |  |  | (4,063 | ) |  | 5 |  |  | 4,549 |  |  | 1 - 12 |
| Patents | 3,214 |  |  | (1,273 | ) |  | 41 |  |  | 1,982 |  |  | 2 - 20 |
| Non-compete agreements | 1,900 |  |  | (783 | ) |  | — |  |  | 1,117 |  |  | 3 |
| In-process technology | 3,900 |  |  | — |  |  | — |  |  | 3,900 |  |  | — |
| Total intangibles assets, net | $ | 244,142 |  |  | $ | (60,232 | ) |  | $ | 217 |  |  | $ | 184,127 |  |  |  |

[0001628280-17-005045:notes:66]
|  | December 31, 2016 |
|  | Gross carryingamount |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 133,358 |  |  | $ | (20,930 | ) |  | $ | (596 | ) |  | $ | 111,832 |  |  | 1 - 30 |
| Acquired technology | 73,599 |  |  | (13,287 | ) |  | (159 | ) |  | 60,153 |  |  | 3 - 20 |
| Backlog | 20,550 |  |  | (14,083 | ) |  | — |  |  | 6,467 |  |  | 1 - 3 |
| Trade names | 8,667 |  |  | (3,887 | ) |  | (31 | ) |  | 4,749 |  |  | 1 - 12 |
| Patents | 3,154 |  |  | (1,264 | ) |  | — |  |  | 1,890 |  |  | 2 - 20 |
| Non-compete agreements | 1,900 |  |  | (608 | ) |  | — |  |  | 1,292 |  |  | 3 |
| In-process technology | 3,900 |  |  | — |  |  | — |  |  | 3,900 |  |  | — |
| Total intangibles assets, net | $ | 245,128 |  |  | $ | (54,059 | ) |  | $ | (786 | ) |  | $ | 190,283 |  |  |  |

[0001628280-17-005045:notes:67]
Amortization expense of intangible assets was $6.5 million and $9.2 million for the three months ended March 31, 2017 and 2016, respectively.

[0001628280-17-005045:notes:68]
[same as prior period, unchanged from 0000926326-16-000077:notes:71]

[0001628280-17-005045:notes:69]
|  | March 31, 2017 |
|  | (In thousands) |
| Remaining nine months of 2017 | $ | 18,591 |  |
| 2018 | 22,779 |  |
| 2019 | 17,354 |  |
| 2020 | 16,215 |  |
| 2021 | 14,861 |  |
| Thereafter (excluding IPR&D) | 90,427 |  |
| Total | $ | 180,227 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-17-005045:notes:70]
[same as prior period, unchanged from 0000926326-16-000077:notes:73]

[0001628280-17-005045:notes:71]
The Company provides for income taxes for each interim period based on the estimated annual effective tax rate for the year, adjusting for discrete items in the quarter in which they arise. The annual effective tax rate before discrete items was 39.1% and 37.0% for the three months ended March 31, 2017 and 2016, respectively.

[0001628280-17-005045:notes:72]
The 2017 annual effective tax rate differed from the statutory rate of 35% primarily due to the unfavorable impact of state income taxes, foreign rate differential, and non-deductible equity charges, which were partially offset by the domestic production activities deduction and the Federal Research & Development credit.  Additionally, the Company adopted ASU 2019-16 effective January 1, 2017, as described in Note 1. The 2016 annual effective tax rate differed from the statutory rate of 35% primarily due to the favorable impact of the IRS settlement and release of tax reserves, the domestic production activities deduction, and a calculated benefit in state income taxes, offset by unfavorable items such as non-deductible transaction costs related to the Aesynt transaction, and non-deductible equity charges under ASC 740-718.

[0001628280-17-005045:notes:73]
As of March 31, 2017 and December 31, 2016 , the Company had gross unrecognized tax benefits of $6.9 million and $6.5 million, respectively. It is the Company’s policy to classify accrued interest and penalties as part of the unrecognized tax benefits, but to record interest and penalties in operating expense. As of March 31, 2017 and December 31, 2016, the amount of accrued interest and penalties was $1.0 million and $0.7 million, respectively.

[0001628280-17-005045:notes:74]
As of March 31, 2017, calendar years 2011 and thereafter are open and subject to potential examination in one or more jurisdictions. However, our research credit carryforwards that may be used in future years are subject to adjustment, if and when utilized. As such our federal and California tax years remain open from 2015 and 1992, respectively.  During fiscal 2016, the Internal Revenue Service and the Company settled all outstanding items related to the audit of the Company's federal income tax returns for the fiscal years ended December 31, 2014.

[0001628280-17-005045:notes:75]
Although the Company believes it has adequately provided for uncertain tax positions, the provisions on these positions may change as revised estimates are made or the underlying matters are settled or otherwise resolved.  It is not possible at this time to reasonably estimate changes in the unrecognized tax benefits within the next twelve months.


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0001628280-17-005045:notes:76]
[same as prior period, unchanged from 0000926326-16-000077:notes:79]

[0001628280-17-005045:notes:77]
|  | March 31, 2017 |  | December 31, 2016 |
|  | (In thousands) |
| United States | $ | 35,471 |  |  | $ | 36,497 |  |
| Rest of world (1) | 5,525 |  |  | 5,514 |  |
| Total property and equipment, net | $ | 40,996 |  |  | $ | 42,011 |  |

[0001628280-17-005045:notes:78]
[same as prior period, unchanged from 0000926326-16-000077:notes:81]

[0001628280-17-005045:notes:79]
[same as prior period, unchanged from 0000926326-16-000077:notes:82]


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0001628280-17-005045:notes:80]
[same as prior period, unchanged from 0000926326-16-000077:notes:83]

[0001628280-17-005045:notes:81]
On January 5, 2016, the Company completed the acquisition of all of the membership interests of Aesynt pursuant to the Aesynt Securities Purchase Agreement. Aesynt is a provider of automated medication management systems, including dispensing robots with storage solutions, medication storage and dispensing carts and cabinets, I.V. sterile preparation robotics, and software, including software related to medication management. The total consideration was $271.5 million, net of cash on hand at signing of $8.2 million. The results of Aesynt's operations have been included in our consolidated results of operations as of the time of the acquisition, and presented as part of the Automation & Analytics segment.

[0001628280-17-005045:notes:82]
On December 8, 2016, the Company completed its acquisition of ateb, Inc., and Ateb Canada Ltd. (together, “Ateb”) pursuant to Ateb's Securities Purchase Agreement for $40.7 million of cash consideration, net of $0.9 million cash acquired. The cash consideration, included the repayment of Ateb indebtedness and other adjustments provided for in the Ateb's Securities Purchase Agreement.  Ateb is a provider of pharmacy-based patient care solutions and the medication synchronization solutions leader to independent and chain pharmacies. The results of Ateb's operations have been included in our consolidated results of operations as of the time of the acquisition, and presented as part of the Medication Adherence segment.

[0001628280-17-005045:notes:83]
The Company accounted for the acquisitions of Aesynt and Ateb in accordance with the authoritative guidance on business combinations; therefore, the tangible and intangible assets acquired and liabilities assumed were recorded at fair value on the acquisition dates, respectively.

[0001628280-17-005045:notes:84]
The following table represents the allocation of the purchase price to the assets acquired and the liabilities assumed by the Company during each acquisition, respectively, reconciled to the purchase price transferred included in the Company's Consolidated Balance Sheet:

[0001628280-17-005045:notes:85]
|  | Aesynt |  | Ateb(preliminary) |  | Total |
|  | (in thousands) |
| Cash | $ | 8,164 |  |  | $ | 902 |  |  | $ | 9,066 |  |
| Accounts receivable | 43,312 |  |  | 7,905 |  |  | 51,217 |  |
| Inventory | 19,021 |  |  | 225 |  |  | 19,246 |  |
| Other current assets | 3,787 |  |  | 1,239 |  |  | 5,026 |  |
| Total current assets | 74,284 |  |  | 10,271 |  |  | 84,555 |  |
| Property and equipment | 10,389 |  |  | 2,447 |  |  | 12,836 |  |
| Intangibles | 123,700 |  |  | 12,500 |  |  | 136,200 |  |
| Goodwill | 163,599 |  |  | 20,832 |  |  | 184,431 |  |
| Other non-current assets | 968 |  |  | 1,009 |  |  | 1,977 |  |
| Total assets | 372,940 |  |  | 47,059 |  |  | 419,999 |  |
| Current liabilities | 26,753 |  |  | 2,314 |  |  | 29,067 |  |
| Deferred revenue | 25,512 |  |  | 2,776 |  |  | 28,288 |  |
| Non-current deferred tax liabilities | 38,622 |  |  | — |  |  | 38,622 |  |
| Other non-current liabilities | 2,431 |  |  | 367 |  |  | 2,798 |  |
| Total liabilities | 93,318 |  |  | 5,457 |  |  | 98,775 |  |
| Total purchase price | $ | 279,622 |  |  | $ | 41,602 |  |  | $ | 321,224 |  |
| Total purchase price, net of cash received | $ | 271,458 |  |  | $ | 40,700 |  |  | $ | 312,158 |  |

[0001628280-17-005045:notes:86]
The $163.6 million of goodwill arising from the Aesynt acquisition is primarily attributed to sales of future products and services and Aesynt's assembled workforce. The goodwill has been assigned to the Automation & Analytics segment and is not deductible for tax purposes.

[0001628280-17-005045:notes:87]
The $20.8 million of goodwill arising from the Ateb acquisition is primarily attributed to sales of future products and services and Ateb's assembled workforce.

[0001628280-17-005045:notes:88]
Intangibles eligible for recognition separate from goodwill were those that satisfied either the contractual/legal criterion or the separability criterion in the accounting guidance. The identifiable intangible assets acquired and their estimated useful lives for amortization are as follows:

[0001628280-17-005045:notes:89]
Aesynt Acquisition

[0001628280-17-005045:notes:90]
[same as prior period, unchanged from 0000926326-16-000077:notes:92]

[0001628280-17-005045:notes:91]
The fair value of trade names, acquired developed technology, and acquired IPR&D was determined based on an income approach using the relief-from-royalty method at the royalty rates of 0.5%, 4% to 8% and 12.5%, respectively. The fair value of customer relationships, backlog, and non-compete intangible assets were determined based on an income approach using the discounted cash flow method, at the discounted rates of 13%, 10% and13%, respectively. The intangible assets, except customer relationship and IPR&D, are being amortized over their estimated useful lives using the straight line method of amortization. The customer relationship intangible asset is being amortized using a double-declining method of amortization as such method better represents the economic benefits to be obtained. In accordance with authoritative guidance, the IPR&D is accounted for as an indefinite-lived intangible asset until completion or abandonment of the associated research and development efforts. IPR&D is tested for impairment during the period it is considered an indefinite lived asset. IPR&D related projects are expected to be completed in two to three years. As of March 31, 2017, none of the IPR&D projects have been completed, and they have progressed as previously estimated.

[0001628280-17-005045:notes:92]
Ateb Acquisition

[0001628280-17-005045:notes:93]
Customer relationships represent the fair value of the underlying relationships and agreements with Ateb’s customers expected to result in future sales, acquired developed technology represents the fair value of Ateb intellectual property incorporated in their products, non-compete intangible asset represents the fair value of non-compete agreements with former key members of Ateb's management, and trade name represents the fair value of brand and name recognition associated with the marketing of Ateb’s products and services.

[0001628280-17-005045:notes:94]
The fair value of Ateb trade names and acquired developed technology was determined based on an income approach using the relief-from-royalty method at the royalty rates of 0.5% and 5% to 6%, respectively. The fair value of customer relationships, and non-compete intangible assets were determined based on an income approach using the discounted cash flow method, both using a 15% discount rate. The intangible assets for non-compete agreements and trade name are being amortized over their estimated useful lives using the straight line method of amortization. The intangible assets for customer relationship and developed technology are being amortized using a double-declining method of amortization as such method better represents the economic benefits to be obtained.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001628280-17-005045:notes:95]
Recently adopted authoritative guidance

[0001628280-17-005045:notes:96]
In March 2016, the FASB issued ASU No. 2016-09, Compensation—Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting. This ASU simplifies several aspects of the accounting for share-based payment transactions, including the income tax consequences, classification of awards as either equity or liabilities, and classification on the statement of cash flows. The provision of ASU No. 2016-09 is effective for annual periods beginning after December 15, 2016, and interim periods within those annual periods. The Company adopted the standard effective January 1, 2017.  The impact of adoption was the recording of excess tax benefits within income tax expense, rather than in Additional Paid in Capital of $0.8 million for the three months ended March 31, 2017. The recording of excess tax benefits within income tax expense rather than Additional Paid in Capital resulted in a $0.02 per share improvement in the net loss to $(0.29) per share. Additionally, the Company recognized the previously unrecognized excess tax benefits using the modified retrospective transition method, which resulted in a cumulative-effect adjustment of $1.6 million to retained earnings. The previously unrecognized excess tax effects were recorded as a deferred tax asset. The Company also elected to apply the change in presentation to the statements of cash flows retrospectively and no longer classifies the excess tax benefits from employee stock plans as a reduction from operating cash flows, resulting in an increase of $0.2 million in the net cash provided by operating activities and a decrease of $0.2 million in the net cash provided by financing activities for the three months ended March 31, 2016. Additionally, on a prospective basis, the calculation of potential common shares for the dilutive earnings per share calculation (when profitable) no longer includes excess tax benefits under the Treasury buyback method, resulting in general in higher dilutive shares. Under ASU 2016-09, the Company made a policy election to continue with forfeiture estimation for expense calculation instead of the alternative of recognition only at forfeiture.

[0001628280-17-005045:notes:97]
In January 2017, the FASB issued ASU 2017-04, Intangibles-Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment, which simplifies the accounting for goodwill impairment for all entities by requiring impairment charges to be based on the first step in today’s two-step impairment test under ASC 350, “Intangibles-Goodwill and Other.” Under the new guidance, if a reporting unit’s carrying amount exceeds its fair value, an entity will record an impairment charge based on that difference. The impairment charge will be limited to the amount of goodwill allocated to that reporting unit. The standard eliminates the current ASC 350 requirement to calculate a goodwill impairment charge using Step 2. ASU 2017-14 is effective for annual and interim impairment tests performed in periods beginning after December 15, 2019. Early adoption is permitted for annual and interim goodwill impairment testing dates after January 1, 2017.  The Company adopted ASU 2017-04 effective January 1, 2017.  The adoption of this authoritative guidance did not have impact on the Company's Condensed Consolidated Financial Statements or related disclosures for the period presented.

[0001628280-17-005045:notes:98]
In January 2017, the FASB issued ASU 2017-01, Business Combinations, which clarifies the definition of a business and provides a screen to determine when a set of assets and activities is not a business. The screen requires that when substantially all of the fair value of the gross assets acquired (or disposed of) is concentrated in a single identifiable asset or a group of similar identifiable assets, the set is not a business. This screen reduces the number of transactions that need to be further evaluated. ASU 2017-01 is effective for fiscal years beginning after December 15, 2017, with early adoption permitted.  The Company adopted ASU 2017-01 effective January 1, 2017.  The adoption of this authoritative guidance did not have impact on the Company's Condensed Consolidated Financial Statements or related disclosures for the period presented.

[0001628280-17-005045:notes:99]
Recently issued authoritative guidance

[0001628280-17-005045:notes:100]
In May 2014, the FASB issued ASU 2014-09-Revenue from Contracts with Customers, which outlines a single, comprehensive model for entities to use in accounting for revenue arising from contracts with customers. The core principle of ASU 2014-09 is to recognize revenue when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. ASU 2014-09 defines a five step process to achieve this core principle and, accordingly, it is possible more judgment and estimates may be required within the revenue recognition process than is required under existing U.S. GAAP, including identifying performance obligations in the contract, estimating the amount of variable consideration to include in the transaction price and allocating the transaction price to each separate performance obligation. The FASB has recently issued several amendments to ASU 2014-09, including clarification on accounting for licenses of intellectual property and identifying performance obligations. ASU 2014-09 will be effective for the Company beginning January 1, 2018.

[0001628280-17-005045:notes:101]
The two permitted transition methods under ASU 2014-09 are the full retrospective method, in which case ASU 2014-09 would be applied to each prior reporting period presented and the cumulative effect of applying ASU 2014-09 would be recognized at the earliest period shown, or the modified retrospective method, in which case the cumulative effect of applying ASU 2014-09 would be recognized at the date of initial application. Currently, the Company is in the process of reviewing our historical contracts to quantify the impact on its consolidated financial statements. Depending on the results of the Company's review, there could be changes to the timing of revenue recognition and certain sales commission and related costs associated with obtaining and fulfilling its customer contracts. The Company will be required to capitalize and amortize incremental costs related to obtaining customer contracts, such as sales commission costs. The Company is also in the process of assessing the appropriate changes to its business processes and upgrading its systems and controls to support recognition and disclosure under ASU 2014-09. The Company otherwise expects to complete its assessment process, including selecting a transition method for adoption, in the next two quarters of 2017.

[0001628280-17-005045:notes:102]
There was no other recently issued and effective authoritative guidance that is expected to have a material impact on the Company's Condensed Consolidated Financial Statements through the reporting date.


## us-gaap:NonvestedRestrictedStockSharesActivityTableTextBlock

[0001628280-17-005045:notes:103]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |
|  | (In thousands, except per share data) |
| Restricted Stock Awards ("RSAs") |  |  |  |
| Outstanding at December 31, 2016 | 30 |  |  | $ | 31.57 |  |
| Granted | — |  |  |  |  |
| Vested | — |  |  |  |  |
| Forfeited | — |  |  |  |  |
| Outstanding and unvested at March 31, 2017 | 30 |  |  | $ | 31.57 |  |


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001628280-17-005045:notes:104]
[same as prior period, unchanged from 0000926326-16-000077:notes:107]

[0001628280-17-005045:notes:105]
[same as prior period, unchanged from 0000926326-16-000077:notes:108]

[0001628280-17-005045:notes:106]
[same as prior period, unchanged from 0000926326-16-000077:notes:109]

[0001628280-17-005045:notes:107]
Certain prior year amounts have been reclassified to conform to the 2017 presentation. These reclassifications include: (i) provision for excess and obsolete inventories, and (ii) provision for the allowance for doubtful accounts have been reclassified/combined with inventories and accounts receivable within net cash provided by operating activities in the Consolidated Statements of Cash Flows. These changes are not material and do not impact previously disclosed net cash provided by operating activities, net cash used in investing activities, and net cash used by financing activities.

[0001628280-17-005045:notes:108]
Additionally, see "Recently adopted authoritative guidance" for the effects of first quarter adoption of ASU 2016-09, Compensation—Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting.

[0001628280-17-005045:notes:109]
[same as prior period, unchanged from 0000926326-16-000077:notes:112]

[0001628280-17-005045:notes:110]
The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company's Condensed Consolidated Financial Statements and accompanying Notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management's best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. The Company's critical accounting policies are those that affect its financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition, accounts receivable and notes receivable from investment in sales-type leases, inventory valuation, capitalized software development costs, valuation and impairment of goodwill, purchased intangibles and long-lived assets, share-based compensation, and accounting for income taxes.

[0001628280-17-005045:notes:111]
[same as prior period, unchanged from 0000926326-16-000077:notes:114]

[0001628280-17-005045:notes:112]
The Company's Chief Operating Decision Maker ("CODM") is its Chief Executive Officer. The CODM allocates resources and evaluates the performance of the Company's segments using information about its revenues, gross profit, and income from operations. Such evaluation excludes general corporate-level costs that are not specific to either of the reportable segments and are managed separately at the corporate level. Corporate-level costs include expenses related to executive management, finance and accounting, human resources, legal, training and development, and certain administrative expenses.  See Note 13, Segment and Geographical Information, for additional information on segment reporting.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001628280-17-005045:notes:113]
[same as prior period, unchanged from 0000926326-16-000077:notes:118]

[0001628280-17-005045:notes:114]
On February 15, 2017, the Company announced its plan to reduce its workforce by approximately 100 full-time employees and close the Company’s Nashville, Tennessee and Slovenia facilities.  The plan is expected to be completed in fiscal year 2017. The estimated total cost for the plan is $6.5 million, which includes estimated employee severance cost of approximately $3.9 million, and facility-related cost of approximately $2.6 million.  During the three months ended March 31, 2017, the Company accrued $3.8 million of expenses, primarily for employee severance and related expenses, and paid out $2.1 million.  The remaining unpaid balance of $1.7 million accrued expenses is presented as a component of accrued compensation in the Condensed Consolidated Balance Sheet. There were no facility-related costs incurred during the three months ended March 31, 2017.

[0001628280-17-005045:notes:115]
The following table summarizes the restructuring expense recorded in each reportable segment and income statement classification for the three months ended March 31, 2017. There were no restructuring-related expenses recorded during the three months ended March 31, 2016.

[0001628280-17-005045:notes:116]
|  | Automation and Analytics |  | Medication Adherence |  | Corporate |  | Total |
|  | (in thousands) |
| Cost of revenue | $ | 1,266 |  |  | $ | 431 |  |  | $ | — |  |  | $ | 1,697 |  |
| Research and development | 1,006 |  |  | 62 |  |  | — |  |  | 1,068 |  |
| Selling, general and administrative | 480 |  |  | 103 |  |  | 417 |  |  | 1,000 |  |
| Total | $ | 2,752 |  |  | $ | 596 |  |  | $ | 417 |  |  | $ | 3,765 |  |


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001628280-17-005045:notes:117]
[same as prior period, unchanged from 0000926326-16-000077:notes:120]

[0001628280-17-005045:notes:118]
|  | Three months ended |
|  | March 31, 2017 |  | March 31, 2016 |
|  | (In thousands) |
| United States | $ | 132,280 |  |  | $ | 143,493 |  |
| Rest of world (1) | 18,274 |  |  | 27,511 |  |
| Total revenues | $ | 150,554 |  |  | $ | 171,004 |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001628280-17-005045:notes:119]
The following table summarizes the changes in accumulated balances of other comprehensive income (loss) for the three months ended March 31, 2017 and 2016:

[0001628280-17-005045:notes:120]
|  | Foreign currency translation adjustments |  | Unrealized gain (loss) on interest rate swap hedges |  | Total |
|  | (In thousands) |
| December 31, 2016 | $ | (10,764 | ) |  | $ | 1,245 |  |  | $ | (9,519 | ) |
| Other comprehensive income (loss) before reclassifications | 923 |  |  | 176 |  |  | 1,099 |  |
| Amounts reclassified from other comprehensive income (loss), net of tax | — |  |  | 6 |  |  | 6 |  |
| Net current-period other comprehensive income (loss), net of tax | 923 |  |  | 182 |  |  | 1,105 |  |
| March 31, 2017 | $ | (9,841 | ) |  | $ | 1,427 |  |  | $ | (8,414 | ) |

[0001628280-17-005045:notes:121]
|  | Foreign currency translation adjustments |  | Unrealized gain (loss) on interest rate swap hedges |  | Total |
|  | (In thousands) |
| December 31, 2015 | $ | (2,730 | ) |  | $ | — |  |  | $ | (2,730 | ) |
| Other comprehensive income (loss) before reclassifications | (327 | ) |  | — |  |  | (327 | ) |
| Amounts reclassified from other comprehensive income (loss), net of tax | — |  |  | — |  |  | — |  |
| Net current-period other comprehensive income (loss), net of tax | (327 | ) |  | — |  |  | (327 | ) |
| March 31, 2016 | $ | (3,057 | ) |  | $ | — |  |  | $ | (3,057 | ) |


## us-gaap:ScheduleOfCondensedBalanceSheetTableTextBlock

[0001628280-17-005045:notes:122]
Balance sheet details as of March 31, 2017 and December 31, 2016 are presented in the tables below:

[0001628280-17-005045:notes:123]
|  | March 31, 2017 |  | December 31, 2016 |
|  | (In thousands) |
| Inventories: |  |  |  |
| Raw materials | $ | 16,698 |  |  | $ | 14,322 |  |
| Work in process | 8,114 |  |  | 7,800 |  |
| Finished goods | 51,418 |  |  | 47,175 |  |
| Total inventories | $ | 76,230 |  |  | $ | 69,297 |  |
| Prepaid expense |  |  |  |
| Prepaid commissions | $ | 12,385 |  |  | $ | 13,176 |  |
| Other prepaid expenses | 15,390 |  |  | 15,470 |  |
| Total prepaid expense | $ | 27,775 |  |  | $ | 28,646 |  |

[0001628280-17-005045:notes:124]
|  | March 31, 2017 |  | December 31, 2016 |
| Property and equipment: |  |  |  |
| Equipment | $ | 66,578 |  |  | $ | 64,384 |  |
| Furniture and fixtures | 6,614 |  |  | 6,517 |  |
| Leasehold improvements | 9,791 |  |  | 9,778 |  |
| Software | 35,915 |  |  | 35,607 |  |
| Construction in progress | 7,625 |  |  | 7,211 |  |
| Property and equipment, gross | 126,523 |  |  | 123,497 |  |
| Accumulated depreciation and amortization | (85,527 | ) |  | (81,486 | ) |
| Total property and equipment, net | $ | 40,996 |  |  | $ | 42,011 |  |
| Other long term assets: |  |  |  |
| Capitalized software, net | $ | 35,391 |  |  | $ | 33,233 |  |
| Other assets | 1,856 |  |  | 1,818 |  |
| Total other long term assets, net | $ | 37,247 |  |  | $ | 35,051 |  |
| Accrued liabilities: |  |  |  |
| Advance payments from customers | $ | 7,971 |  |  | $ | 7,030 |  |
| Rebates and lease buyouts | 3,905 |  |  | 4,025 |  |
| Group purchasing organization fees | 3,549 |  |  | 3,737 |  |
| Taxes payable | 3,845 |  |  | 4,003 |  |
| Other accrued liabilities | 12,136 |  |  | 12,400 |  |
| Total accrued liabilities | $ | 31,406 |  |  | $ | 31,195 |  |


## us-gaap:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTextBlock

[0001628280-17-005045:notes:125]
[same as prior period, unchanged from 0000926326-16-000077:notes:124]

[0001628280-17-005045:notes:126]
|  | Three months ended |
|  | March 31, 2017 |  | March 31, 2016 |
|  | (In thousands) |
| Cost of product and service revenues | $ | 982 |  |  | $ | 549 |  |
| Research and development | 897 |  |  | 641 |  |
| Selling, general and administrative | 3,632 |  |  | 2,701 |  |
| Total share-based compensation expense | $ | 5,511 |  |  | $ | 3,891 |  |


## us-gaap:ScheduleOfNonvestedRestrictedStockUnitsActivityTableTextBlock

[0001628280-17-005045:notes:127]
The following table summarizes the restricted stock activity under the Company’s equity incentive plans during the three months ended March 31, 2017:

[0001628280-17-005045:notes:128]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Restricted Stock Units ("RSUs") |  |  |  |  |  |  |  |
| Outstanding at December 31, 2016 | 505 |  |  | $ | 31.42 |  |  | 1.6 |  | $ | 17,135 |  |
| Granted | 74 |  |  | 36.57 |  |  |  |  |  |
| Vested | (43 | ) |  | 28.12 |  |  |  |  |  |
| Forfeited | (9 | ) |  | 31.97 |  |  |  |  |  |
| Outstanding and unvested at March 31, 2017 | 527 |  |  | $ | 32.39 |  |  | 1.5 |  | $ | 21,418 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001628280-17-005045:notes:129]
[same as prior period, unchanged from 0000926326-16-000077:notes:129]

[0001628280-17-005045:notes:130]
|  | Three months ended |
|  | March 31, 2017 |  | March 31, 2016 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |  | Automation andAnalytics |  | MedicationAdherence |  | Total |
|  | (In thousands) |
| Revenues | $ | 124,171 |  |  | $ | 26,383 |  |  | $ | 150,554 |  |  | $ | 148,945 |  |  | $ | 22,059 |  |  | $ | 171,004 |  |
| Cost of revenues | 68,761 |  |  | 17,601 |  |  | 86,362 |  |  | 77,207 |  |  | 13,852 |  |  | 91,059 |  |
| Gross profit | 55,410 |  |  | 8,782 |  |  | 64,192 |  |  | 71,738 |  |  | 8,207 |  |  | 79,945 |  |
| Operating expenses | 50,747 |  |  | 11,196 |  |  | 61,943 |  |  | 52,205 |  |  | 5,611 |  |  | 57,816 |  |
| Income (loss) from segment operations | $ | 4,663 |  |  | $ | (2,414 | ) |  | $ | 2,249 |  |  | $ | 19,533 |  |  | $ | 2,596 |  |  | $ | 22,129 |  |
| Corporate costs |  |  |  |  | 19,485 |  |  |  |  |  |  | 20,277 |  |
| Income (loss) from operations |  |  |  |  | $ | (17,236 | ) |  |  |  |  |  | $ | 1,852 |  |


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0001628280-17-005045:notes:131]
The following table summarizes the share option activity under the Company’s equity incentive plans during the three months ended March 31, 2017:

[0001628280-17-005045:notes:132]
|  | Number ofShares |  | Weighted-AverageExercise Price |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Stock Options |  |  |  |  |  |  |  |
| Outstanding at December 31, 2016 | 3,214 |  |  | $ | 26.06 |  |  | 7.3 |  | $ | 26,331 |  |
| Granted | 363 |  |  | 36.67 |  |  |  |  |  |
| Exercised | (188 | ) |  | 22.86 |  |  |  |  |  |
| Expired | (1 | ) |  | 32.59 |  |  |  |  |  |
| Forfeited | (38 | ) |  | 31.72 |  |  |  |  |  |
| Outstanding at March 31, 2017 | 3,350 |  |  | $ | 27.33 |  |  | 7.4 |  | $ | 44,631 |  |
| Exercisable at March 31, 2017 | 1,493 |  |  | $ | 20.88 |  |  | 5.5 |  | $ | 29,519 |  |
| Vested and expected to vest at March 31, 2017 and thereafter | 3,168 |  |  | $ | 26.96 |  |  | 7.3 |  | $ | 43,388 |  |


## us-gaap:ScheduleOfShareBasedPaymentAwardEmployeeStockPurchasePlanValuationAssumptionsTableTextBlock

[0001628280-17-005045:notes:133]
|  | Three months ended |
|  | March 31, 2017 |  | March 31, 2016 |
| Employee Stock Purchase Plan |  |  |  |
| Expected life, years | 0.5-2.0 |  |  | 0.5-2.0 |  |
| Expected volatility, % | 25.8-32.8% |  |  | 25.8-34.8% |  |
| Risk free interest rate, % | 0.52-1.31% |  |  | 0.26-0.79% |  |
| Dividend yield, % | — | % |  | — | % |

[0001628280-17-005045:notes:134]
The following weighted average assumptions are used to value stock options and Employee Stock Purchase Plan ("ESPP") shares issued pursuant to the Company's equity incentive plans for the three months ended March 31, 2017 and 2016:


## us-gaap:ScheduleOfShareBasedPaymentAwardStockOptionsValuationAssumptionsTableTextBlock

[0001628280-17-005045:notes:135]
|  | Three months ended |
|  | March 31, 2017 |  | March 31, 2016 |
| Stock Option Plans |  |  |  |
| Expected life, years | 4.67 |  |  | 4.92 |  |
| Expected volatility, % | 31.1 | % |  | 32.6 | % |
| Risk free interest rate, % | 1.89 | % |  | 1.40 | % |
| Estimated forfeiture rate % | 7.7 | % |  | 8.6 | % |
| Dividend yield, % | — | % |  | — | % |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-17-005045:notes:136]
Segment and Geographical Information

[0001628280-17-005045:notes:137]
[same as prior period, unchanged from 0000926326-16-000077:notes:139]

[0001628280-17-005045:notes:138]
[same as prior period, unchanged from 0000926326-16-000077:notes:140]

[0001628280-17-005045:notes:139]
The Automation and Analytics segment is organized around the design, manufacturing, selling and servicing of medication and supply dispensing systems, pharmacy inventory management systems, and related software. The Automation and Analytics products are designed to enable the Company's customers to enhance and improve the effectiveness of the medication-use process, the efficiency of the medical-surgical supply chain, overall patient care and clinical and financial outcomes of medical facilities. Through modular configuration and upgrades, the Company's systems can be tailored to specific customer needs.

[0001628280-17-005045:notes:140]
[same as prior period, unchanged from 0000926326-16-000077:notes:142]

[0001628280-17-005045:notes:141]
[same as prior period, unchanged from 0000926326-16-000077:notes:143]

[0001628280-17-005045:notes:142]
[same as prior period, unchanged from 0000926326-16-000077:notes:144]

[0001628280-17-005045:notes:143]
There were no customers that accounted for more than 10% of our total revenues for the three months ended March 31, 2017 and 2016. Also, there were no customers that accounted for more than 10% of our accounts receivable as of March 31, 2017 and December 31, 2016.

[0001628280-17-005045:notes:144]
[same as prior period, unchanged from 0000926326-16-000077:notes:146]

[0001628280-17-005045:notes:145]
[same as prior period, unchanged from 0000926326-16-000077:notes:147]


## us-gaap:ShareBasedCompensationPerformanceSharesAwardUnvestedActivityTableTextBlock

[0001628280-17-005045:notes:146]
The following table summarizes the performance-based restricted stock activity under the Company’s equity incentive plans during the three months ended March 31, 2017:

[0001628280-17-005045:notes:147]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value Per Unit |
|  | (In thousands, except per share data) |
| Performance-based Restricted Stock Units ("PSUs") |  |  |  |
| Outstanding at December 31, 2016 | 184 |  |  | $ | 24.89 |  |
| Granted | 126 |  |  | 32.37 |  |
| Vested | (31 | ) |  | 24.66 |  |
| Forfeited | — |  |  | — |  |
| Outstanding and unvested at March 31, 2017 | 279 |  |  | $ | 28.29 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001628280-17-005045:notes:148]
[same as prior period, unchanged from 0000926326-16-000077:notes:150]

[0001628280-17-005045:notes:149]
[same as prior period, unchanged from 0000926326-16-000077:notes:151]

[0001628280-17-005045:notes:150]
For a detailed explanation of the Company's stock plans and subsequent changes, please refer to Note 11, Employee Benefits and Stock-Based Compensation, of its Annual Report on Form 10-K for the year ended December 31, 2016 filed with the SEC on February 28, 2017.

[0001628280-17-005045:notes:151]
[same as prior period, unchanged from 0000926326-16-000077:notes:153]

[0001628280-17-005045:notes:152]
[same as prior period, unchanged from 0000926326-16-000077:notes:154]

[0001628280-17-005045:notes:153]
The weighted-average fair value per share of options granted during the three months ended March 31, 2017 and 2016 was $10.86 and $8.51, respectively. The intrinsic value of options exercised during the three months ended March 31, 2017 and 2016 was $2.9 million and $0.7 million, respectively.

[0001628280-17-005045:notes:154]
As of March 31, 2017, total unrecognized compensation cost related to unvested stock options was $15.4 million, which is expected to be recognized over a weighted-average vesting period of 3.0 years.

[0001628280-17-005045:notes:155]
[same as prior period, unchanged from 0000926326-16-000077:notes:157]

[0001628280-17-005045:notes:156]
The weighted-average grant date fair value per share of RSUs granted during the three months ended March 31, 2017 and March 31, 2016 was $36.57 and $27.77, respectively.

[0001628280-17-005045:notes:157]
As of March 31, 2017, total unrecognized compensation expense related to RSUs was $14.0 million, which is expected to be recognized over the remaining weighted-average vesting period of 2.7 years.

[0001628280-17-005045:notes:158]
As of March 31, 2017, total unrecognized compensation cost related to RSAs was $0.1 million, which is expected to be recognized over the remaining weighted-average vesting period of 0.16 years.

[0001628280-17-005045:notes:159]
[same as prior period, unchanged from 0000926326-16-000077:notes:161]

[0001628280-17-005045:notes:160]
The weighted-average grant date fair value per share of PSUs granted during the three months ended March 31, 2017 and 2016 was $32.37 and $24.66, respectively. As of March 31, 2017, total unrecognized compensation cost related to PSUs was $4.3 million, which is expected to be recognized over the remaining weighted-average period of 1.6 years.

[0001628280-17-005045:notes:161]
[same as prior period, unchanged from 0000926326-16-000077:notes:163]

[0001628280-17-005045:notes:162]
For the three months ending March 31, 2017 and 2016, purchases under the ESPP were approximately 259,000 and 198,000 shares at weighted average prices of $25.51 and $22.74, respectively. As of March 31, 2017, the unrecognized compensation cost related to the shares to be purchased under the ESPP was approximately $2.9 million and is expected to be recognized over a weighted-average period of 1.1 years.

[0001628280-17-005045:notes:163]
[same as prior period, unchanged from 0000926326-16-000077:notes:165]

[0001628280-17-005045:notes:164]
[same as prior period, unchanged from 0000926326-16-000077:notes:166]

[0001628280-17-005045:notes:165]
On August 2, 2016, the Company's Board of Directors (the "Board") authorized a stock repurchase program providing for the repurchase of up to $50.0 million of the Company’s common stock (the “2016 Repurchase Program”). The 2016 Repurchase Program is in addition to the stock repurchase program approved by the Board on November 4, 2014 (the “2014 Repurchase Program”). As of March 31, 2017, the maximum dollar value of shares that may yet be purchased under the two repurchase programs was $54.9 million. The stock repurchase program does not obligate the Company to repurchase any specific number of shares, and the Company may terminate or suspend the repurchase program at any time.

[0001628280-17-005045:notes:166]
During the three and three months period ended March 31, 2017 and 2016, the Company did not repurchase any of its outstanding common stock.


## us-gaap:SubsequentEventsTextBlock

[0001628280-17-005045:notes:167]
Subsequent Event

[0001628280-17-005045:notes:168]
On April 19, 2017, the Company announced the acquisition of Dixie Drawl, LLC d/b/a InPharmics ("InPharmics"), a Mississippi-based technology and services company that provides advanced pharmacy informatics solutions to hospital pharmacies, in an all-cash transaction for $5.3 million. The acquisition will expand the capabilities of Omnicell's Performance Center™. The Company is in the process of evaluating the business combination accounting considerations, including the consideration transferred and the initial purchase price allocation.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001628280-17-005045:notes:169]
[same as prior period, unchanged from 0000926326-16-000077:notes:170]
