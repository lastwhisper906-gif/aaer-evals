# OMCL 8-K — 0001628280-17-004851 filed 2017-05-04

## item codes, every 8-K on or before 2017-05-05

- 2017-05-04 0001628280-17-004851 — 2.02, 9.01
- 2017-02-15 0000926326-17-000010 — 2.05
- 2017-02-15 0000926326-17-000008 — 2.02, 9.01
- 2017-02-13 0000926326-17-000002 — 5.02
- 2016-12-08 0001104659-16-161330 — 2.01, 2.03, 9.01
- 2016-12-06 0001104659-16-160709 — 7.01
- 2016-11-29 0001104659-16-159456 — 1.01, 7.01, 9.01
- 2016-10-27 0000926326-16-000075 — 2.02, 9.01
- 2016-10-07 0000926326-16-000072 — 5.02, 8.01
- 2016-08-05 0000926326-16-000068 — 8.01
- 2016-07-28 0000926326-16-000066 — 2.02, 9.01
- 2016-06-13 0001104659-16-126854 — 5.02
- 2016-05-25 0000926326-16-000060 — 5.07
- 2016-04-28 0000926326-16-000054 — 2.02, 9.01
- 2016-03-21 0001104659-16-106649 — 8.01, 9.01
- 2016-03-17 0000926326-16-000051 — 7.01, 9.01
- 2016-03-17 0000926326-16-000049 — 9.01 — amendment of 0000926326-16-000051
- 2016-02-10 0001104659-16-095486 — 5.02, 9.01
- 2016-02-04 0000926326-16-000041 — 2.02, 9.01
- 2016-01-06 0001104659-16-088299 — 1.01, 2.01, 2.03, 9.01
- 2015-12-10 0000926326-15-000038 — 8.01, 9.01
- 2015-10-29 0001104659-15-074138 — 1.01, 9.01
- 2015-10-29 0000926326-15-000031 — 2.02, 9.01
- 2015-08-20 0001104659-15-061135 — 5.02, 9.01
- 2015-07-30 0000926326-15-000024 — 2.02, 9.01
- 2015-05-22 0001104659-15-040440 — 5.07
- 2015-05-01 0001104659-15-032846 — 5.02
- 2015-05-01 0001104659-15-032844 — 7.01
- 2015-04-30 0000926326-15-000015 — 9.01
- 2015-04-22 0001104659-15-029356 — 8.01, 9.01
- 2015-03-20 0001104659-15-021435 — 3.01
- 2015-03-18 0001104659-15-020699 — 7.01
- 2015-03-17 0001104659-15-020483 — 8.01, 9.01
- 2015-03-02 0001104659-15-015802 — 1.01, 9.01
- 2015-02-12 0001104659-15-009234 — 5.02, 9.01
- 2015-02-03 0000926326-15-000003 — 9.01
- 2015-01-15 0001104659-15-002635 — 5.02
- 2014-11-07 0001104659-14-078398 — 1.01, 8.01, 9.01
- 2014-10-30 0000926326-14-000037 — 2.02, 9.01
- 2014-08-25 0001104659-14-062772 — 8.01, 9.01
- 2014-07-31 0000926326-14-000032 — 2.02, 9.01
- 2014-05-21 0001104659-14-040744 — 5.07
- 2014-05-01 0000926326-14-000008 — 2.02, 9.01
- 2014-04-08 0001104659-14-026441 — 4.01, 9.01
- 2014-04-02 0001104659-14-025179 — 5.02
- 2014-02-07 0001104659-14-007552 — 5.02, 9.01
- 2014-02-04 0001104659-14-006352 — 2.02, 9.01
- 2013-12-09 0001104659-13-088980 — 1.01, 9.01
- 2013-12-02 0001104659-13-087877 — 5.02
- 2013-10-31 0001104659-13-079660 — 2.02, 9.01
- 2013-09-26 0001104659-13-072435 — 1.01, 2.03, 9.01
- 2013-08-01 0001104659-13-058959 — 2.02, 9.01
- 2013-05-23 0001104659-13-044317 — 5.07
- 2013-05-02 0001104659-13-036605 — 2.02, 9.01
- 2013-03-11 0001104659-13-019143 — 8.01
- 2013-02-07 0001104659-13-008477 — 5.02, 9.01
- 2013-01-31 0001104659-13-006446 — 2.02, 9.01
- 2012-11-02 0001104659-12-073697 — 5.02
- 2012-10-25 0001104659-12-071211 — 2.02, 9.01
- 2012-08-06 0001104659-12-054635 — 8.01
- 2012-08-03 0001104659-12-054214 — 2.01, 9.01 — amendment of 0001104659-12-038888
- 2012-08-01 0001104659-12-053005 — 2.02, 9.01
- 2012-06-12 0001104659-12-042936 — 8.01, 9.01
- 2012-05-23 0001104659-12-039459 — 5.07
- 2012-05-22 0001104659-12-038888 — 2.01, 9.01
- 2012-05-02 0001104659-12-032048 — 2.02, 9.01
- 2012-05-02 0001104659-12-032036 — 1.01, 9.01
- 2012-04-04 0001104659-12-023883 — 5.02, 8.01
- 2012-03-20 0001104659-12-019462 — 1.01, 9.01
- 2012-02-13 0001104659-12-009353 — 5.02, 9.01
- 2012-01-26 0001104659-12-004244 — 2.02, 9.01
- 2011-10-27 0001104659-11-058464 — 2.02, 9.01
- 2011-10-25 0001104659-11-057721 — 1.01
- 2011-07-28 0001104659-11-041505 — 2.02, 9.01
- 2011-05-27 0001104659-11-032006 — 5.07
- 2011-05-02 0001104659-11-024908 — 2.02, 9.01
- 2011-04-15 0001104659-11-020407 — 5.02, 9.01 — amendment of 0001104659-11-005638
- 2011-02-08 0001104659-11-005638 — 5.02, 9.01
- 2011-01-27 0001104659-11-003419 — 2.02, 9.01
- 2010-12-22 0001104659-10-064003 — 5.02, 5.07, 9.01
- 2010-10-27 0001104659-10-054036 — 2.02, 9.01
- 2010-10-05 0001104659-10-051173 — 8.01
- 2010-07-22 0001104659-10-039126 — 2.02, 9.01
- 2010-07-09 0001104659-10-037594 — 2.05
- 2010-05-28 0001104659-10-031607 — 5.07
- 2010-04-26 0001104659-10-021797 — 2.02, 9.01
- 2010-03-17 0001104659-10-014849 — 5.02, 9.01
- 2010-02-08 0001104659-10-005457 — 5.02, 9.01
- 2010-01-28 0001104659-10-003627 — 2.02, 9.01
- 2009-10-22 0001104659-09-059972 — 2.02, 9.01
- 2009-07-23 0001104659-09-044508 — 2.02, 9.01
- 2009-05-20 0001104659-09-033938 — 5.02, 9.01
- 2009-04-30 0001104659-09-027707 — 2.02, 9.01
- 2009-03-10 0001104659-09-016178 — 5.02, 9.01
- 2009-02-09 0001104659-09-007692 — 5.02, 9.01
- 2009-01-29 0001104659-09-005022 — 2.02, 2.05, 9.01
- 2009-01-21 0001104659-09-003180 — 2.02, 8.01, 9.01
- 2009-01-06 0001104659-09-000625 — 5.02
- 2008-10-23 0001104659-08-065475 — 2.02, 9.01
- 2008-07-21 0001104659-08-046690 — 2.02, 9.01
- 2008-05-16 0001104659-08-034035 — 8.01, 9.01
- 2008-04-28 0001104659-08-027379 — 7.01, 9.01
- 2008-04-21 0001104659-08-025616 — 2.02, 9.01
- 2008-03-12 0001104659-08-016939 — 7.01, 9.01
- 2008-02-26 0001104659-08-012840 — 7.01, 9.01
- 2008-02-12 0001104659-08-009382 — 5.02, 9.01
- 2008-01-31 0001104659-08-006199 — 2.02, 9.01
- 2007-12-05 0001104659-07-087191 — 1.01, 9.01
- 2007-10-18 0001104659-07-075654 — 2.02, 9.01
- 2007-07-27 0001104659-07-056886 — 5.03, 9.01
- 2007-07-19 0001104659-07-054924 — 2.02, 9.01
- 2007-05-23 0001104659-07-042287 — 8.01, 9.01
- 2007-05-07 0001104659-07-036172 — 1.01, 5.02, 9.01
- 2007-04-24 0001104659-07-030578 — 2.02, 9.01 — amendment, the index does not say of what
- 2007-04-24 0001104659-07-030547 — 2.02, 9.01
- 2007-04-10 0001104659-07-027465 — 5.02, 9.01
- 2007-03-23 0001104659-07-021969 — 2.02, 4.02, 9.01
- 2007-01-30 0001104659-07-005772 — 2.02, 9.01
- 2007-01-09 0001104659-07-001600 — 5.02, 9.01
- 2006-10-30 0001104659-06-069612 — 1.01
- 2006-10-19 0001104659-06-067549 — 2.02, 9.01
- 2006-07-20 0001104659-06-048020 — 2.02, 4.02, 9.01
- 2006-05-17 0001104659-06-035522 — 1.01, 9.01 — amendment of 0001104659-05-011155
- 2006-05-09 0001104659-06-032706 — 1.01, 9.01
- 2006-04-25 0001104659-06-027438 — 2.02, 9.01
- 2006-04-04 0001104659-06-022204 — 1.01, 9.01
- 2006-03-15 0001104659-06-016861 — 1.01, 9.01
- 2006-01-30 0001104659-06-004749 — 2.02, 9.01
- 2006-01-24 0001104659-06-003504 — 1.01, 5.02, 9.01
- 2005-12-13 0001104659-05-060532 — 1.01, 9.01
- 2005-11-10 0001104659-05-054663 — 2.02, 9.01
- 2005-07-21 0001104659-05-033464 — 2.02, 9.01
- 2005-06-22 0001104659-05-029255 — 1.01
- 2005-05-16 0001104659-05-023473 — 2.02, 9.01 — amendment of 0001104659-05-018173
- 2005-05-16 0001104659-05-023471 — 2.02, 9.01 — amendment of 0001104659-05-017382
- 2005-05-10 0001104659-05-022127 — 1.01
- 2005-04-26 0001104659-05-018173 — 2.02, 9.01
- 2005-04-21 0001104659-05-017382 — 2.02, 9.01
- 2005-04-06 0001104659-05-015401 — 5.02
- 2005-03-15 0001104659-05-011155 — 1.01, 9.01
- 2005-03-08 0001104659-05-009975 — 1.01, 9.01
- 2005-02-03 0001104659-05-003943 — 2.02, 9.01
- 2005-01-13 0001104659-05-001314 — 5.02, 9.01
- 2004-10-21 0001104659-04-031413 — 2.02, 9.01
- 2004-07-22 0001104659-04-020572 — 12, 7
- 2004-04-14 0001104659-04-010039 — 12, 7
- 2004-04-05 0001104659-04-009437 — 12, 7
- 2004-01-26 0001104659-04-001655 — 12, 7
- 2003-10-16 0001104659-03-022990 — 12, 7
- 2003-07-17 0001104659-03-015053 — 9
- 2003-04-18 0001104659-03-006823 — 7, 9
- 2003-02-14 0001104659-03-002607 — 5, 7

## late-filing notifications on or before 2017-05-05

- 2015-03-02 0000926326-15-000006 — NT 10-K, for the period ended 2014-12-31
- 2007-03-16 0001104659-07-020094 — NT 10-K, for the period ended 2006-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001628280-17-004851:8k_2_02:1]
EX-99.1
2
exhibit991q117.htm
EXHIBIT 99.1

[0001628280-17-004851:8k_2_02:2]
Exhibit

[0001628280-17-004851:8k_2_02:3]
Exhibit 99.1

[0001628280-17-004851:8k_2_02:4]
| Contact: |  |  |
| Peter Kuipers |  | Omnicell, Inc. |
| Chief Financial Officer |  | 590 East Middlefield Road |
| 800-850-6664, ext. 6180 |  | Mountain View, CA 94043 |
| Peter.kuipers@omnicell.com |  |  |

[0001628280-17-004851:8k_2_02:5]
Omnicell Announces First Quarter 2017 Results

[0001628280-17-004851:8k_2_02:6]
GAAP revenue of $150.6 million and net loss per diluted share of $0.29

[0001628280-17-004851:8k_2_02:7]
Non-GAAP revenue of $150.9 million and net income per diluted shares of $0.06

[0001628280-17-004851:8k_2_02:8]
MOUNTAIN VIEW, Calif. -- May 4, 2017 -- Omnicell, Inc. (NASDAQ: OMCL), a leading provider of medication and supply management solutions to healthcare systems, today announced results for its first quarter ended March 31, 2017.

[0001628280-17-004851:8k_2_02:9]
GAAP results: Revenue for the first quarter of 2017 was $150.6 million, down $21.4 million, or 12.5% from the fourth quarter of 2016, and down $20.5 million or 12.0% from the first quarter of 2016.

[0001628280-17-004851:8k_2_02:10]
First quarter 2017 net loss as reported in accordance with U.S. generally accepted accounting principles (GAAP) was $10.8 million, or $0.29 per diluted share. This compares to GAAP net income of $0.2 million, or $0.00 per diluted share, for the fourth quarter of 2016, and GAAP net loss of $0.4 million, or $0.01 per diluted share, for the first quarter of 2016.

[0001628280-17-004851:8k_2_02:11]
Non-GAAP results: Non-GAAP revenue for the first quarter of 2017 was $150.9 million, down $23.8 million, or 13.6% from the fourth quarter of 2016, and down $22.8 million or 13.1% from the first quarter of 2016.

[0001628280-17-004851:8k_2_02:12]
Non-GAAP net income for the first quarter of 2017 was $2.1 million, or $0.06 per diluted share. This compares to non-GAAP net income of $13.8 million, or $0.37 per diluted share, for the fourth quarter of 2016 and $12.9 million, or $0.35 per diluted share, for the first quarter of 2016.

[0001628280-17-004851:8k_2_02:13]
Non-GAAP net income for each period presented excludes, when applicable, the effect of stock-based compensation expense, amortization expense of acquired intangible assets, acquisition related expenses, fair value adjustments related to business acquisitions, severance and integration related expenses, and amortization of debt issuance cost.

[0001628280-17-004851:8k_2_02:14]
“During the first quarter of 2017, Omnicell won in the marketplace through its differentiated platform and innovative products including the XT Series.  I am pleased with our new conversion wins and customers’ strong interest and acceptance of our new XT Series," said Randall Lipps, Omnicell president, CEO and chairman.  “An expected sequential decline in revenue due to the XT Series product launch and customer implementations timing affected our first quarter revenue and results, but our order intake and pipeline of new sales opportunities demonstrate our strong market momentum.” Mr. Lipps added.

[0001628280-17-004851:8k_2_02:15]
2017 Guidance:

[0001628280-17-004851:8k_2_02:16]
Following the market launch of the XT Series and ramp up of manufacturing for the XT Series in the first quarter of 2017 we expect the revenue and profitability to scale and improve every quarter during 2017.

[0001628280-17-004851:8k_2_02:17]
For the second quarter of 2017, the Company expects non-GAAP revenue to be between $172 million and $178 million. The Company expects second quarter of 2017 non-GAAP earnings to be between $0.21 and $0.27 per share.

[0001628280-17-004851:8k_2_02:18]
For the combined third and fourth quarters of 2017, the Company expects non-GAAP revenue to be between $395 million and $415 million, and non-GAAP earnings to be between $0.95 and $1.05 per share.

[0001628280-17-004851:8k_2_02:19]
For the year 2017, the Company expects product bookings to be between $570 million and $590 million. The Company expects non-GAAP revenue to be between $720 million and $740 million, and non-GAAP earnings to be between $1.22 and $1.34 per share.

[0001628280-17-004851:8k_2_02:20]
The table below summarizes 2017 guidance outlined above:

[0001628280-17-004851:8k_2_02:21]
|  | Q2'17 | Q3'17 through Q4'17 | Total Year 2017 |
| Product Bookings | Not provided | >20% year over year growth | $570 million - $590 million |
| Non-GAAP Revenue | $172 million - $178 million | $395 million - $415 million | $720 million - $740 million |
| Non-GAAP EPS | $0.21 - $0.27 | $0.95 - $1.05 | $1.22 - $1.34 |

[0001628280-17-004851:8k_2_02:22]
Omnicell Conference Call Information

[0001628280-17-004851:8k_2_02:23]
Omnicell will hold a conference call today, Thursday, May 4, 2017 at 8:30 a.m. ET to discuss first quarter financial results. The conference call can be monitored by dialing 1-800-696-5518 within the U.S. or 1-706-758-4883 for all other locations. The Conference ID # is 36563190. Internet users can access the conference call at http://ir.omnicell.com/events.cfm. A replay of the call will be available today at approximately 11:30 a.m. ET and will be available until 11:59 p.m. PT on May 22, 2017. The replay access numbers are 1-855-859-2056 within the U.S. and 1-404-537-3406 for all other locations, Conference ID # is 36563190.

[0001628280-17-004851:8k_2_02:24]
About Omnicell

[0001628280-17-004851:8k_2_02:25]
Since 1992, Omnicell (NASDAQ: OMCL) has been inspired to create safer and more efficient ways to manage medications and supplies across all care settings. As a leader in medication and supply dispensing automation, central pharmacy automation, IV robotics, analytics software, and medication adherence and packaging systems, Omnicell is focused on improving care across the entire healthcare continuum-from the acute care hospital setting, to post-acute skilled nursing and long-term care facilities, to the patient’s home.

[0001628280-17-004851:8k_2_02:26]
Over 4,000 customers worldwide use Omnicell® automation and analytics solutions to increase operational efficiency, reduce medication errors, deliver actionable intelligence and improve patient safety.

[0001628280-17-004851:8k_2_02:27]
Omnicell’s innovative medication adherence solutions, used by over 32,000 institutional and retail pharmacies in North America and the United Kingdom, are designed to improve patient adherence to prescriptions, helping to reduce costly hospital readmissions.

[0001628280-17-004851:8k_2_02:28]
Recent Omnicell acquisitions, including Ateb, add distinct capabilities, particularly in central pharmacy, IV robotics, and pharmacy software, creating the broadest medication management product portfolio in the industry.

[0001628280-17-004851:8k_2_02:29]
For more information about Omnicell, Inc. please visit www.omnicell.com.

[0001628280-17-004851:8k_2_02:30]
Forward-Looking Statements

[0001628280-17-004851:8k_2_02:31]
of the reduction in our workforce and closure of our Nashville and Slovenia facilities, our ability to continue cost reduction efforts, and our ability to implement development and manufacturing Centers of Excellence, unfavorable general economic and market conditions, risks to growth and acceptance of our products and services, including competitive conversions, and to growth of the clinical automation and workflow automation market generally, the potential of increasing competition, potential regulatory changes, the ability of the company to improve sales productivity to grow product bookings, to develop new products and to acquire and successfully integrate companies. These and other risks and uncertainties are described more fully in Omnicell’s most recent filings with the Securities and Exchange Commission. Prospective investors are cautioned not to place undue reliance on forward-looking statements. All forward-looking statements contained in this press release speak only as of the date on which they were made. Omnicell undertakes no obligation to update such statements to reflect events that occur or circumstances that exist after the date on which they were made.

[0001628280-17-004851:8k_2_02:32]
Use of Non-GAAP Financial Information

[0001628280-17-004851:8k_2_02:33]
This press release contains financial measures that are not calculated in accordance with U.S. generally accepted accounting principles (GAAP). Our management evaluates and makes operating decisions using various performance measures. In addition to Omnicell’s GAAP results, we also consider non-GAAP revenue, non-GAAP gross profit, non-GAAP operating expenses, non-GAAP net income, and non-GAAP net income per diluted share. Additionally, we calculate Adjusted EBITDA (another non-GAAP measure) by means of adjustments to GAAP Net Income. These non-GAAP results should not be considered as an alternative to gross profit, operating expenses, net income, net income per diluted share, or any other performance measure derived in accordance with GAAP. We present these non-GAAP results because we consider them to be important supplemental measures of Omnicell’s performance.

[0001628280-17-004851:8k_2_02:34]
Our non-GAAP revenue, non-GAAP gross profit, non-GAAP operating expenses, non-GAAP net income and non-GAAP net income per diluted share are exclusive of certain items to facilitate management’s review of the comparability of Omnicell’s core operating results on a period to period basis because such items are not related to Omnicell’s ongoing core operating results as viewed by management. We define our “core operating results” as those revenues recorded in a particular period and the expenses incurred within that period that directly drive operating income in that period. Management uses these non-GAAP financial measures in making operating decisions because, in addition to meaningful supplemental information regarding operating performance, the measures give us a better understanding of how we should invest in research and development, fund infrastructure growth and evaluate the effectiveness of marketing strategies. In calculating the above non-GAAP results, management specifically adjusted for the following excluded items:

[0001628280-17-004851:8k_2_02:35]
a)  Share-based compensation expense. We excluded from our non-GAAP results the expense related to equity-based compensation plans as they represent expenses that do not require cash settlement from Omnicell.

[0001628280-17-004851:8k_2_02:36]
b) Intangible assets amortization from business acquisitions. We excluded from our non-GAAP results the intangible assets amortization expense resulting from our past acquisitions. These non-cash charges are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results.

[0001628280-17-004851:8k_2_02:37]
c) Amortization of debt issuance cost. Debt issuance cost represents costs associated with the issuance of Term Loan and Revolving Line of Credit facilities. The cost includes underwriting fees, original issue discount, ticking fee, and legal fees. This non-cash expense is not considered by management to reflect the core cash-generating performance of the business and therefore is excluded from our non-GAAP results.

[0001628280-17-004851:8k_2_02:38]
d) Acquisition accounting impact related to deferred revenue. In connection with recent acquisitions, business combination rules require us to account for the fair values of arrangements for which acceptance has not been obtained, and post installation support has not been provided in our purchase accounting. The non-GAAP adjustment to our revenues is intended to include the full amounts of such revenues. We believe the adjustment to these revenues is useful as a measure of the ongoing performance of our business.

[0001628280-17-004851:8k_2_02:39]
e) Inventory fair value adjustments. In connection with acquisition of Aesynt, business combination rules require us to account for the fair values of inventory acquired in our purchase accounting. The non-GAAP adjustment to the cost of revenues is intended to include the impact of such adjustment. We believe the adjustment is useful as a measure of the ongoing performance of our business.

[0001628280-17-004851:8k_2_02:40]
f) Acquisition related expenses. We excluded from the non-GAAP results the expenses which are related to the recent acquisitions. These expenses are unrelated to our ongoing operations and we do not expect them to occur in the ordinary course of business. We believe that excluding these acquisition related expenses provides more meaningful comparisons of the financial results to our

[0001628280-17-004851:8k_2_02:41]
historical operations and forward looking guidance and the financial results of less acquisitive peer companies.

[0001628280-17-004851:8k_2_02:42]
g) Severance and other related expenses. We excluded from our non-GAAP results the expenses which are related to the restructuring and integrations related events. These expenses are unrelated to our ongoing operations and we do not expect them to occur in the ordinary course of business. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward looking guidance and the financial results of less acquisitive peer companies.

[0001628280-17-004851:8k_2_02:43]
Management adjusts for the above items because management believes that, in general, these items possess one or more of the following characteristics: their magnitude and timing is largely outside of Omnicell’s control; they are unrelated to the ongoing operation of the business in the ordinary course; they are unusual and we do not expect them to occur in the ordinary course of business; or they are non-operational, or non-cash expenses involving stock compensation plans.

[0001628280-17-004851:8k_2_02:44]
We believe that the presentation of these non-GAAP financial measures is warranted for several reasons:

[0001628280-17-004851:8k_2_02:45]
1) Such non-GAAP financial measures provide an additional analytical tool for understanding Omnicell’s financial performance by excluding the impact of items which may obscure trends in the core operating results of the business;

[0001628280-17-004851:8k_2_02:46]
2) Since we have historically reported non-GAAP results to the investment community, we believe the inclusion of non-GAAP numbers provides consistency and enhances investors’ ability to compare our performance across financial reporting periods;

[0001628280-17-004851:8k_2_02:47]
3) These non-GAAP financial measures are employed by Omnicell’s management in its own evaluation of performance and are utilized in financial and operational decision making processes, such as budget planning and forecasting; and

[0001628280-17-004851:8k_2_02:48]
4) These non-GAAP financial measures facilitate comparisons to the operating results of other companies in our industry, which use similar financial measures to supplement their GAAP results, thus enhancing the perspective of investors who wish to utilize such comparisons in their analysis of our performance.

[0001628280-17-004851:8k_2_02:49]
Set forth below are additional reasons why share-based compensation expense is excluded from our non-GAAP financial measures:

[0001628280-17-004851:8k_2_02:50]
i)  While share-based compensation calculated in accordance with ASC 718 constitutes an ongoing and recurring expense of Omnicell, it is not an expense that requires cash settlement by Omnicell. We therefore exclude these charges for purposes of evaluating core operating results. Thus, our non-GAAP measurements are presented exclusive of stock-based compensation expense to assist management and investors in evaluating our core operating results.

[0001628280-17-004851:8k_2_02:51]
ii) We present ASC 718 share-based payment compensation expense in our reconciliation of non-GAAP financial measures on a pre-tax basis because the exact tax differences related to the timing and deductibility of share-based compensation, under ASC 718 are dependent upon the trading price of Omnicell’s common stock and the timing and exercise by employees of their stock options. As a result of these timing and market uncertainties the tax effect related to share-based compensation expense would be inconsistent in amount and frequency and is therefore excluded from our non-GAAP results.

[0001628280-17-004851:8k_2_02:52]
Our Adjusted EBITDA calculation is defined as earnings before interest income and expense, taxes, depreciation and amortization, and non-cash expenses, including ASC 718 stock compensation expense, as well as certain non-GAAP adjustments.

[0001628280-17-004851:8k_2_02:53]
As stated above, we present non-GAAP financial measures because we consider them to be important supplemental measures of performance. However, non-GAAP financial measures have limitations as an analytical tool and should not be considered in isolation or as a substitute for Omnicell’s GAAP results. In the future, we expect to incur expenses similar to certain of the non-GAAP adjustments described above and expect to continue reporting non-GAAP financial measures excluding such items. Some of the limitations in relying on non-GAAP financial measures are:

[0001628280-17-004851:8k_2_02:54]
| • | Omnicell’s stock option and stock purchase plans are important components of incentive compensation arrangements and will be reflected as expenses in Omnicell’s GAAP results for the foreseeable future under ASC 718. |

[0001628280-17-004851:8k_2_02:55]
| • | Other companies, including companies in Omnicell’s industry, may calculate non-GAAP financial measures differently than Omnicell, limiting their usefulness as a comparative measure. |

[0001628280-17-004851:8k_2_02:56]
Pursuant to the requirements of SEC Regulation G, a detailed reconciliation between Omnicell’s non-GAAP and GAAP financial results is set forth in the financial tables at the end of this press release. Investors are advised to carefully review and consider this information strictly as a supplement to the GAAP results that are contained in this press release and in Omnicell’s SEC filings.

[0001628280-17-004851:8k_2_02:57]
5

[0001628280-17-004851:8k_2_02:58]
Omnicell, Inc.

[0001628280-17-004851:8k_2_02:59]
Condensed Consolidated Statements of Operations

[0001628280-17-004851:8k_2_02:60]
(Unaudited, in thousands, except per share data)

[0001628280-17-004851:8k_2_02:61]
|  | Three Months Ended |
|  | March 31, 2017 |  | December 31, 2016 |  | March 31, 2016 |
| Revenues: |  |  |  |  |  |
| Product | $ | 98,930 |  |  | $ | 125,753 |  |  | $ | 127,895 |  |
| Services and other revenues | 51,624 |  |  | 46,221 |  |  | 43,109 |  |
| Total revenues | 150,554 |  |  | 171,974 |  |  | 171,004 |  |
| Cost of revenues: |  |  |  |  |  |
| Cost of product revenues | 63,588 |  |  | 78,024 |  |  | 71,918 |  |
| Cost of services and other revenues | 22,774 |  |  | 19,621 |  |  | 19,141 |  |
| Total cost of revenues | 86,362 |  |  | 97,645 |  |  | 91,059 |  |
| Gross profit | 64,192 |  |  | 74,329 |  |  | 79,945 |  |
| Operating expenses: |  |  |  |  |  |
| Research and development | 16,803 |  |  | 14,902 |  |  | 13,838 |  |
| Selling, general and administrative | 64,625 |  |  | 59,608 |  |  | 64,255 |  |
| Total operating expenses | 81,428 |  |  | 74,510 |  |  | 78,093 |  |
| Income (loss) from operations | (17,236 | ) |  | (181 | ) |  | 1,852 |  |
| Interest and other income (expense), net | (2,456 | ) |  | (1,656 | ) |  | (2,171 | ) |
| Loss before provision for income taxes | (19,692 | ) |  | (1,837 | ) |  | (319 | ) |
| Provision (benefit) for income taxes | (8,938 | ) |  | (1,994 | ) |  | 59 |  |
| Net income (loss) | $ | (10,754 | ) |  | $ | 157 |  |  | $ | (378 | ) |
| Net income (loss) per share: |  |  |  |  |  |
| Basic | $ | (0.29 | ) |  | $ | — |  |  | $ | (0.01 | ) |
| Diluted | $ | (0.29 | ) |  | $ | — |  |  | $ | (0.01 | ) |
| Weighted average shares outstanding: |  |  |  |  |  |
| Basic | 36,840 |  |  | 36,553 |  |  | 35,740 |  |
| Diluted | 36,840 |  |  | 37,256 |  |  | 35,740 |  |

[0001628280-17-004851:8k_2_02:62]
6

[0001628280-17-004851:8k_2_02:63]
Omnicell, Inc.

[0001628280-17-004851:8k_2_02:64]
Condensed Consolidated Balance Sheets

[0001628280-17-004851:8k_2_02:65]
(Unaudited, in thousands)

[0001628280-17-004851:8k_2_02:66]
|  | March 31, 2017 |  | December 31, 2016 |
| ASSETS |
| Current assets: |  |  |  |  |
| Cash and cash equivalents | $ | 46,348 |  |  | $ | 54,488 |  |
| Accounts receivable, net | 131,433 |  |  | 150,303 |  |
| Inventories | 76,230 |  |  | 69,297 |  |
| Prepaid expenses | 27,775 |  |  | 28,646 |  |
| Other current assets | 12,593 |  |  | 12,674 |  |
| Total current assets | 294,379 |  |  | 315,408 |  |
| Property and equipment, net | 40,996 |  |  | 42,011 |  |
| Long-term investment in sales-type leases, net | 19,174 |  |  | 20,585 |  |
| Goodwill | 328,216 |  |  | 327,724 |  |
| Intangible assets, net | 184,127 |  |  | 190,283 |  |
| Long-term deferred tax assets | 5,624 |  |  | 4,041 |  |
| Other long-term assets | 37,247 |  |  | 35,051 |  |
| Total assets | $ | 909,763 |  |  | $ | 935,103 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |
| Accounts payable | $ | 38,466 |  |  | $ | 27,069 |  |
| Accrued compensation | 28,677 |  |  | 26,722 |  |
| Accrued liabilities | 31,406 |  |  | 31,195 |  |
| Long-term debt, current portion, net | 8,410 |  |  | 8,410 |  |
| Deferred revenue, net | 90,521 |  |  | 87,516 |  |
| Total current liabilities | 197,480 |  |  | 180,912 |  |
| Long-term, deferred revenue | 15,994 |  |  | 17,051 |  |
| Long-term deferred tax liabilities | 42,502 |  |  | 51,592 |  |
| Other long-term liabilities | 8,716 |  |  | 8,210 |  |
| Long-term debt, net | 206,128 |  |  | 245,731 |  |
| Total liabilities | 470,820 |  |  | 503,496 |  |
| Total stockholders’ equity | 438,943 |  |  | 431,607 |  |
| Total liabilities and stockholders’ equity | $ | 909,763 |  |  | $ | 935,103 |  |

[0001628280-17-004851:8k_2_02:67]
Omnicell, Inc.

[0001628280-17-004851:8k_2_02:68]
Condensed Consolidated Statements of Cash Flows

[0001628280-17-004851:8k_2_02:69]
(Unaudited, in thousands)

[0001628280-17-004851:8k_2_02:70]
|  | Three months ended March 31, |
|  | 2017 |  | 2016 |
| Operating Activities |  |  |  |
| Net loss | $ | (10,754 | ) |  | $ | (378 | ) |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 12,448 |  |  | 14,473 |  |
| (Gain) loss on disposal of fixed assets | — |  |  | 13 |  |
| Share-based compensation expense | 5,511 |  |  | 3,891 |  |
| Income tax benefits from employee stock plans | 11 |  |  | 164 |  |
| Deferred income taxes | (9,091 | ) |  | (1,042 | ) |
| Amortization of debt financing fees | 397 |  |  | 397 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable | 18,870 |  |  | (1,070 | ) |
| Inventories | (6,933 | ) |  | (5,113 | ) |
| Prepaid expenses | 871 |  |  | 1,983 |  |
| Other current assets | 372 |  |  | 324 |  |
| Investment in sales-type leases | 1,120 |  |  | (8,928 | ) |
| Other long-term assets | (38 | ) |  | 1,232 |  |
| Accounts payable | 11,104 |  |  | 1,568 |  |
| Accrued compensation | 1,955 |  |  | 4,114 |  |
| Accrued liabilities | (115 | ) |  | 417 |  |
| Deferred revenue | 1,948 |  |  | 12,663 |  |
| Other long-term liabilities | 506 |  |  | (2,701 | ) |
| Net cash provided by operating activities | 28,182 |  |  | 22,007 |  |
| Investing Activities |  |  |  |
| Purchases of intangible assets, intellectual property and patents | (160 | ) |  | (1,074 | ) |
| Software development for external use | (4,225 | ) |  | (3,070 | ) |
| Purchases of property and equipment | (2,452 | ) |  | (4,261 | ) |
| Business acquisition, net of cash acquired | — |  |  | (271,458 | ) |
| Net cash used in investing activities | (6,837 | ) |  | (279,863 | ) |
| Financing Activities |  |  |  |
| Proceeds from debt, net | — |  |  | 247,059 |  |
| Repayment of debt and revolving credit facility | (40,000 | ) |  | (20,000 | ) |
| Payment for contingent consideration | — |  |  | (3,000 | ) |
| Proceeds from issuances under stock-based compensation plans | 10,916 |  |  | 5,149 |  |
| Employees' taxes paid related to restricted stock units | (1,052 | ) |  | (382 | ) |
| Net cash provided by (used in) financing activities | (30,136 | ) |  | 228,826 |  |
| Effect of exchange rate changes on cash and cash equivalents | 651 |  |  | 300 |  |
| Net decrease in cash and cash equivalents | (8,140 | ) |  | (28,730 | ) |
| Cash and cash equivalents at beginning of period | 54,488 |  |  | 82,217 |  |
| Cash and cash equivalents at end of period | $ | 46,348 |  |  | $ | 53,487 |  |

[0001628280-17-004851:8k_2_02:71]
8

[0001628280-17-004851:8k_2_02:72]
Omnicell, Inc.

[0001628280-17-004851:8k_2_02:73]
Reconciliation of GAAP to Non-GAAP

[0001628280-17-004851:8k_2_02:74]
(Unaudited, in thousands, except per share data and percentage)

[0001628280-17-004851:8k_2_02:75]
|  |  |  |  |  |  | Three Months Ended |
|  |  |  |  |  |  | March 31, 2017 |  | December 31, 2016 |  | March 31, 2016 |
| Reconciliation of GAAP revenue to non-GAAP revenue: |  |  |
| GAAP revenue |  | $ | 150,554 |  |  | $ | 171,974 |  |  | $ | 171,004 |  |
|  | Acquisition accounting impact related to deferred revenue | 313 |  |  | 2,663 |  |  | 2,663 |  |
| Non-GAAP revenue | $ | 150,867 |  |  | $ | 174,637 |  |  | $ | 173,667 |  |
| Reconciliation of GAAP gross profit to non-GAAP gross profit: |  |  |
| GAAP gross profit | $ | 64,192 |  |  | $ | 74,329 |  |  | $ | 79,945 |  |
| GAAP gross margin | 42.6% |  | 43.2% |  | 46.8% |
|  | Share-based compensation expense | 982 |  |  | 776 |  |  | 549 |  |
|  | Amortization of acquired intangibles | 2,837 |  |  | 5,266 |  |  | 5,211 |  |
|  | Acquisition accounting impact related to deferred revenue | 313 |  |  | 2,663 |  |  | 2,663 |  |
|  | Inventory fair value adjustments | — |  |  | 921 |  |  | 921 |  |
|  | Acquisitions related expenses | — |  |  | 5 |  |  | — |  |
|  | Severance and other expenses* | 1,697 |  |  | — |  |  | — |  |
| Non-GAAP gross profit | $ | 70,021 |  |  | $ | 83,960 |  |  | $ | 89,289 |  |
| Non-GAAP gross margin | 46.4% |  | 48.1% |  | 51.4% |
| Reconciliation of GAAP operating expenses to non-GAAP operating expenses: |
| GAAP operating expenses | $ | 81,428 |  |  | $ | 74,510 |  |  | $ | 78,093 |  |
| GAAP operating expenses % to total revenue |  | 54.1% |  | 43.3% |  | 45.7% |
|  | Share-based compensation expense | (4,529 | ) |  | (4,663 | ) |  | (3,342 | ) |
|  | Amortization of acquired intangibles | (3,653 | ) |  | (3,752 | ) |  | (3,948 | ) |
|  | Acquisitions related expenses | (126 | ) |  | (829 | ) |  | (2,349 | ) |
|  | Severance and other expenses* | (2,332 | ) |  | — |  |  | — |  |
| Non-GAAP operating expenses | $ | 70,788 |  |  | $ | 65,266 |  |  | $ | 68,454 |  |
| Non-GAAP operating expenses % to total revenue | 46.9% |  | 37.4% |  | 39.4% |

[0001628280-17-004851:8k_2_02:76]
* Other expenses include relocation charge of $220 and depreciation adjustment related to purchase price allocation from acquisition of $264.

[0001628280-17-004851:8k_2_02:77]
|  |  |  |  |  |  | Three Months Ended |
|  |  |  |  |  |  | March 31, 2017 |  | December 31, 2016 |  | March 31, 2016 |
| Reconciliation of GAAP income (loss) from operations to non-GAAP income from operations: |
| GAAP income (loss) from operations | $ | (17,236 | ) |  | $ | (181 | ) |  | $ | 1,852 |  |
| GAAP operating income (loss) % to total revenue |  | (11.4)% |  | (0.1)% |  | 1.1% |
|  | Share-based compensation expense | 5,511 |  |  | 5,438 |  |  | 3,891 |  |
|  | Amortization of acquired intangibles | 6,490 |  |  | 9,017 |  |  | 9,159 |  |
|  | Acquisition accounting impact related to deferred revenue | 313 |  |  | 2,663 |  |  | 2,663 |  |
|  | Inventory fair value adjustments | — |  |  | 921 |  |  | 921 |  |
|  | Acquisitions related expenses | 126 |  |  | 834 |  |  | 2,349 |  |
|  | Severance and other expenses | 4,029 |  |  | — |  |  | — |  |
| Non-GAAP income (loss) from operations | $ | (767 | ) |  | $ | 18,692 |  |  | $ | 20,835 |  |
| Non-GAAP operating income % to total Non-GAAP revenue | (0.5)% |  | 10.7% |  | 12.0% |
| Reconciliation of GAAP net income (loss) to non-GAAP net income: |  |  |
| GAAP net income (loss) | $ | (10,754 | ) |  | $ | 157 |  |  | $ | (378 | ) |
|  | Share-based compensation expense | 5,511 |  |  | 5,438 |  |  | 3,891 |  |
|  | Amortization of acquired intangibles | 6,490 |  |  | 9,017 |  |  | 9,159 |  |
|  | Acquisition accounting impact related to deferred revenue | 313 |  |  | 2,663 |  |  | 2,663 |  |
|  | Inventory fair value adjustments | — |  |  | 921 |  |  | 921 |  |
|  | Acquisitions related expenses | 523 |  |  | 632 |  |  | 2,349 |  |
|  | Severance and other expenses | 4,029 |  |  | — |  |  | — |  |
|  | Tax effect of the adjustments above(a) | (4,019 | ) |  | (5,031 | ) |  | (5,735 | ) |
| Non-GAAP net income | $ | 2,093 |  |  | $ | 13,797 |  |  | $ | 12,870 |  |
| Reconciliation of GAAP net income (loss) per share - diluted to non-GAAP net income per share - diluted: |
| Shares - diluted GAAP | 36,840 |  |  | 37,256 |  |  | 35,740 |  |
| Shares - diluted Non-GAAP | 37,782 |  |  | 37,256 |  |  | 36,307 |  |
| GAAP net income (loss) per share - diluted | $ | (0.29 | ) |  | $ | — |  |  | $ | (0.01 | ) |
|  | Share-based compensation expense | 0.15 |  |  | 0.15 |  |  | 0.11 |  |
|  | Amortization of acquired intangibles | 0.17 |  |  | 0.24 |  |  | 0.25 |  |
|  | Acquisition accounting impact related to deferred revenue | 0.01 |  |  | 0.07 |  |  | 0.07 |  |
|  | Inventory fair value adjustments | — |  |  | 0.02 |  |  | 0.03 |  |
|  | Acquisitions related expenses | 0.01 |  |  | 0.02 |  |  | 0.06 |  |
|  | Severance and other expenses | 0.11 |  |  | — |  |  | — |  |
|  | Tax effect of the adjustments above(a) | (0.10 | ) |  | (0.13 | ) |  | (0.16 | ) |
| Non-GAAP net income per share - diluted | $ | 0.06 |  |  | $ | 0.37 |  |  | $ | 0.35 |  |
| Reconciliation of GAAP net income (loss) to non-GAAP Adjusted EBITDA(b): |  |  |
| GAAP net income (loss) | $ | (10,754 | ) |  | $ | 157 |  |  | $ | (378 | ) |
|  | Share-based compensation expense | 5,511 |  |  | 5,438 |  |  | 3,891 |  |
|  | Interest (income) and expense, net | 1,432 |  |  | 998 |  |  | 1,747 |  |
|  | Depreciation and amortization expense | 12,448 |  |  | 14,457 |  |  | 14,473 |  |
|  | Acquisition accounting impact related to deferred revenue | 313 |  |  | 2,663 |  |  | 2,663 |  |
|  | Inventory fair value adjustments | — |  |  | 921 |  |  | 921 |  |
|  | Acquisitions related expenses | 523 |  |  | 632 |  |  | 2,349 |  |
|  | Severance expense | 3,765 |  |  | — |  |  | — |  |
|  | Income tax expense | (8,938 | ) |  | (1,994 | ) |  | 59 |  |
| Non-GAAP Adjusted EBITDA | $ | 4,300 |  |  | $ | 23,272 |  |  | $ | 25,725 |  |

[0001628280-17-004851:8k_2_02:78]
(a) Tax effects calculated for all adjustments except share-based compensation expense, using an estimated annual effective tax rate of 35% for fiscal year 2017 and 38% for fiscal year 2016.

[0001628280-17-004851:8k_2_02:79]
(b) Defined as earnings before interest income and expense, taxes, depreciation and amortization, as well as excluding certain non-GAAP adjustments.

[0001628280-17-004851:8k_2_02:80]
10

[0001628280-17-004851:8k_2_02:81]
Omnicell, Inc.

[0001628280-17-004851:8k_2_02:82]
Segmented Information

[0001628280-17-004851:8k_2_02:83]
(Unaudited, in thousands, except for percentages)

[0001628280-17-004851:8k_2_02:84]
|  | Three Months Ended March 31, 2017 |  | Three Months Ended March 31, 2016 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |  | Automation andAnalytics |  | MedicationAdherence |  | Total |
| Revenues | $ | 124,171 |  |  | $ | 26,383 |  |  | $ | 150,554 |  |  | $ | 148,945 |  |  | $ | 22,059 |  |  | $ | 171,004 |  |
| Cost of revenues | 68,761 |  |  | 17,601 |  |  | 86,362 |  |  | 77,207 |  |  | 13,852 |  |  | 91,059 |  |
| Gross profit | 55,410 |  |  | 8,782 |  |  | 64,192 |  |  | 71,738 |  |  | 8,207 |  |  | 79,945 |  |
| Gross margin % | 44.6% |  | 33.3% |  | 42.6% |  | 48.2% |  | 37.2% |  | 46.8% |
| Operating expenses | 50,747 |  |  | 11,196 |  |  | 61,943 |  |  | 52,205 |  |  | 5,611 |  |  | 57,816 |  |
| Income (loss) from segment operations | $ | 4,663 |  |  | $ | (2,414 | ) |  | $ | 2,249 |  |  | $ | 19,533 |  |  | $ | 2,596 |  |  | $ | 22,129 |  |
| Operating margin % | 3.8% |  | (9.1)% |  | 1.5% |  | 13.1% |  | 11.8% |  | 12.9% |
| Corporate costs |  |  |  |  | 19,485 |  |  |  |  |  |  | 20,277 |  |
| Income (loss) from operations |  |  |  |  | $ | (17,236 | ) |  |  |  |  |  | $ | 1,852 |  |

[0001628280-17-004851:8k_2_02:85]
11

[0001628280-17-004851:8k_2_02:86]
Omnicell, Inc.

[0001628280-17-004851:8k_2_02:87]
Segment Information - Non-GAAP Gross Profit and Non-GAAP Operating Margin

[0001628280-17-004851:8k_2_02:88]
(Unaudited, in thousands, except for percentages)

[0001628280-17-004851:8k_2_02:89]
|  | Three Months Ended March 31, 2017 |  |  |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |
|  | Amount |  | % of GAAP Revenue |  | % of Non-GAAP Revenue |  | Amount |  | % of GAAP Revenue |  | % of Non-GAAP Revenue |  | Amount |  | % of GAAP Revenue |  | % of Non-GAAP Revenue |
| Revenues | $ | 124,171 |  |  |  |  |  |  | $ | 26,383 |  |  |  |  |  |  | $ | 150,554 |  |  |  |  |  |
| Acquisition accounting impact related to deferred revenue | — |  |  | —% |  | —% |  | 313 |  |  | 1.2% |  | 1.2% |  | 313 |  |  | 0.2% |  | 0.2% |
| Non-GAAP Revenues | $ | 124,171 |  |  |  |  |  |  | $ | 26,696 |  |  |  |  |  |  | $ | 150,867 |  |  |  |  |  |
| GAAP Gross profit | $ | 55,410 |  |  | 44.6% |  | 44.6% |  | $ | 8,782 |  |  | 33.3% |  | 32.9% |  | $ | 64,192 |  |  | 42.6% |  | 42.5% |
| Share-based compensation expense | 863 |  |  | 0.7% |  | 0.7% |  | 119 |  |  | 0.5% |  | 0.4% |  | 982 |  |  | 0.7% |  | 0.7% |
| Amortization expense of acquired intangible assets | 2,187 |  |  | 1.8% |  | 1.8% |  | 650 |  |  | 2.5% |  | 2.4% |  | 2,837 |  |  | 1.9% |  | 1.9% |
| Acquisition accounting impact related to deferred revenue | — |  |  | —% |  | —% |  | 313 |  |  | 1.2% |  | 1.2% |  | 313 |  |  | 0.2% |  | 0.2% |
| Severance and other expenses | 1,266 |  |  | 1.0% |  | 1.0% |  | 431 |  |  | 1.6% |  | 1.6% |  | 1,697 |  |  | 1.1% |  | 1.1% |
| Non-GAAP Gross profit | $ | 59,726 |  |  | 48.1% |  | 48.1% |  | $ | 10,295 |  |  | 39.0% |  | 38.6% |  | $ | 70,021 |  |  | 46.5% |  | 46.4% |
| GAAP Operating income | $ | 4,663 |  |  | 3.8% |  | 3.8% |  | $ | (2,414 | ) |  | (9.1)% |  | (9.0)% |  | $ | 2,249 |  |  | 1.5% |  | 1.5% |
| Share-based compensation expense | 2,500 |  |  | 2.0% |  | 2.0% |  | 366 |  |  | 1.4% |  | 1.4% |  | 2,866 |  |  | 1.9% |  | 1.9% |
| Amortization expense of acquired intangible assets | 4,506 |  |  | 3.6% |  | 3.6% |  | 1,984 |  |  | 7.5% |  | 7.4% |  | 6,490 |  |  | 4.3% |  | 4.3% |
| Acquisition accounting impact related to deferred revenue | — |  |  | —% |  | —% |  | 313 |  |  | 1.2% |  | 1.2% |  | 313 |  |  | 0.2% |  | 0.2% |
| Acquisitions related expenses | 18 |  |  | —% |  | —% |  | — |  |  | —% |  | —% |  | 18 |  |  | —% |  | —% |
| Severance and other expenses | 2,752 |  |  | 2.2% |  | 2.2% |  | 596 |  |  | 2.3% |  | 2.2% |  | 3,348 |  |  | 2.2% |  | 2.2% |
| Non-GAAP Operating income | $ | 14,439 |  |  | 11.6% |  | 11.6% |  | $ | 845 |  |  | 3.2% |  | 3.2% |  | $ | 15,284 |  |  | 10.2% |  | 10.1% |
| GAAP Corporate costs |  |  |  |  |  |  |  |  |  |  |  |  | $ | 19,485 |  |  | 12.9% |  | 12.9% |
| Share-based compensation expense |  |  |  |  |  |  |  |  |  |  |  |  | (2,645 | ) |  | (1.8)% |  | (1.8)% |
| Acquisition-related expenses |  |  |  |  |  |  |  |  |  |  |  |  | (108 | ) |  | (0.1)% |  | (0.1)% |
| Severance and other expenses |  |  |  |  |  |  |  |  |  |  |  |  | (681 | ) |  | (0.5)% |  | (0.5)% |
| Non-GAAP Corporate costs |  |  |  |  |  |  |  |  |  |  |  |  | $ | 16,051 |  |  | 10.7% |  | 10.6% |
| Non-GAAP Loss from operations |  |  |  |  |  |  |  |  |  |  |  |  | $ | (767 | ) |  | (0.5)% |  | (0.5)% |

[0001628280-17-004851:8k_2_02:90]
Omnicell, Inc.

[0001628280-17-004851:8k_2_02:91]
Segment Information - Non-GAAP Gross Profit and Non-GAAP Operating Margin

[0001628280-17-004851:8k_2_02:92]
(Unaudited, in thousands, except for percentages)

[0001628280-17-004851:8k_2_02:93]
|  | Three Months Ended March 31, 2016 |  |  |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |
|  | Amount |  | % of GAAP Revenue |  | % of Non-GAAP Revenue |  | Amount |  | % of GAAP Revenue |  | % of Non-GAAP Revenue |  | Amount |  | % of GAAP Revenue |  | % of Non-GAAP Revenue |
| Revenues | $ | 148,945 |  |  |  |  |  |  | $ | 22,059 |  |  |  |  |  |  | $ | 171,004 |  |  |  |  |  |
| Acquisition accounting impact related to deferred revenue | 2,663 |  |  | 1.8 | % |  | 1.8 | % |  | — |  |  | — | % |  | — | % |  | 2,663 |  |  | 1.6 | % |  | 1.5 | % |
| Non-GAAP Revenues | $ | 151,608 |  |  |  |  |  |  | $ | 22,059 |  |  |  |  |  |  | 173,667 |  |  |  |  |  |
| GAAP Gross profit | $ | 71,738 |  |  | 48.2 | % |  | 47.3 | % |  | $ | 8,207 |  |  | 37.2 | % |  | 37.2 | % |  | $ | 79,945 |  |  | 46.8 | % |  | 46.0 | % |
| Stock-based compensation expense | 460 |  |  | 0.3 | % |  | 0.3 | % |  | 89 |  |  | 0.4 | % |  | 0.4 | % |  | 549 |  |  | 0.3 | % |  | 0.3 | % |
| Amortization expense of acquired intangible assets | 4,879 |  |  | 3.3 | % |  | 3.2 | % |  | 332 |  |  | 1.5 | % |  | 1.5 | % |  | 5,211 |  |  | 3.0 | % |  | 3.0 | % |
| Acquisition accounting impact related to deferred revenue | 2,663 |  |  | 1.8 | % |  | 1.8 | % |  | — |  |  | — | % |  | — | % |  | 2,663 |  |  | 1.6 | % |  | 1.5 | % |
| Inventory fair value adjustments | 921 |  |  | 0.6 | % |  | 0.6 | % |  | — |  |  | — | % |  | — | % |  | 921 |  |  | 0.5 | % |  | 0.5 | % |
| Non-GAAP Gross profit | $ | 80,661 |  |  | 54.2 | % |  | 53.2 | % |  | $ | 8,628 |  |  | 39.1 | % |  | 39.1 | % |  | $ | 89,289 |  |  | 52.2 | % |  | 51.4 | % |
| GAAP Operating income | $ | 19,533 |  |  | 13.1 | % |  | 12.9 | % |  | $ | 2,596 |  |  | 11.8 | % |  | 11.8 | % |  | $ | 22,129 |  |  | 12.9 | % |  | 12.7 | % |
| Stock-based compensation expense | 1,623 |  |  | 1.1 | % |  | 1.1 | % |  | 201 |  |  | 0.9 | % |  | 0.9 | % |  | 1,824 |  |  | 1.1 | % |  | 1.1 | % |
| Amortization expense of acquired intangible assets | 7,829 |  |  | 5.3 | % |  | 5.2 | % |  | 1,330 |  |  | 6.0 | % |  | 6.0 | % |  | 9,159 |  |  | 5.4 | % |  | 5.3 | % |
| Acquisition accounting impact related to deferred revenue | 2,663 |  |  | 1.8 | % |  | 1.8 | % |  | — |  |  | — | % |  | — | % |  | 2,663 |  |  | 1.6 | % |  | 1.5 | % |
| Inventory fair value adjustments | 921 |  |  | 0.6 | % |  | 0.6 | % |  | — |  |  | — | % |  | — | % |  | 921 |  |  | 0.5 | % |  | 0.5 | % |
| Acquisitions related expenses | 1,757 |  |  | 1.2 | % |  | 1.2 | % |  | — |  |  | — | % |  | — | % |  | 1,757 |  |  | 1.0 | % |  | 1.0 | % |
| Non-GAAP Operating income | $ | 34,326 |  |  | 23.0 | % |  | 22.6 | % |  | $ | 4,127 |  |  | 18.7 | % |  | 18.7 | % |  | $ | 38,453 |  |  | 22.5 | % |  | 22.1 | % |
| GAAP Corporate costs |  |  |  |  |  |  |  |  |  |  |  |  | $ | 20,277 |  |  | 11.9 | % |  | 11.7 | % |
| Stock-based compensation expense |  |  |  |  |  |  |  |  |  |  |  |  | (2,067 | ) |  | (1.2 | )% |  | (1.2 | )% |
| Acquisition related expenses |  |  |  |  |  |  |  |  |  |  |  |  | (592 | ) |  | (0.3 | )% |  | (0.3 | )% |
| Non-GAAP Corporate costs |  |  |  |  |  |  |  |  |  |  |  |  | $ | 17,618 |  |  | 10.3 | % |  | 10.1 | % |
| Non-GAAP Income from operations |  |  |  |  |  |  |  |  |  |  |  |  | $ | 20,835 |  |  | 12.2 | % |  | 12.0 | % |

[0001628280-17-004851:8k_2_02:94]
13
