# OMCL MD&A — 0001628280-17-005045


## mdna

[0001628280-17-005045:mdna:1]
[same as prior period, unchanged from 0000926326-16-000077:mdna:1]

[0001628280-17-005045:mdna:2]
[same as prior period, unchanged from 0000926326-16-000077:mdna:2]

[0001628280-17-005045:mdna:3]
[same as prior period, unchanged from 0000926326-16-000077:mdna:3]

[0001628280-17-005045:mdna:4]
| • | our ability to acquire companies, businesses, products or technologies on commercially reasonable terms and integrate such acquisitions effectively; |

[0001628280-17-005045:mdna:5]
| • | the extent and timing of future revenues, including the amounts of our current backlog, which represents firm orders that have not completed installation and therefore have not been recognized as revenue; |

[0001628280-17-005045:mdna:6]
[same as prior period, unchanged from 0000926326-16-000077:mdna:5]

[0001628280-17-005045:mdna:7]
[same as prior period, unchanged from 0000926326-16-000077:mdna:6]

[0001628280-17-005045:mdna:8]
[same as prior period, unchanged from 0000926326-16-000077:mdna:7]

[0001628280-17-005045:mdna:9]
[same as prior period, unchanged from 0000926326-16-000077:mdna:8]

[0001628280-17-005045:mdna:10]
| • | our ability to protect our intellectual property and operate our business without infringing upon the intellectual property rights of others; and |

[0001628280-17-005045:mdna:11]
| • | our ability to generate cash from operations and our estimates regarding the sufficiency of our cash resources; |

[0001628280-17-005045:mdna:12]
In some cases, you can identify forward-looking statements by terms such as "anticipates," "believes," "could," "estimates," "expects," "intends," "may," "plans," "potential," "predicts," "projects," "should," "will," "would" and similar expressions intended to identify forward-looking statements. Forward-looking statements reflect our current views with respect to future events, are based on assumptions and are subject to risks and uncertainties. We discuss many of these risks in this annual report in greater detail in Part II - Item 1A. “Risk Factors” below. Given these uncertainties, you should not place undue reliance on these forward-looking statements. Also, forward-looking statements represent our estimates and assumptions only as of the date of this annual report. You should also read this annual report and the documents that we reference in this annual report and have filed as exhibits, completely and with the understanding that our actual future results may be materially different from what we expect. All references in this report to "Omnicell," "our," "us," "we," or the "Company" collectively refer to Omnicell, Inc., a Delaware corporation, and its subsidiaries. The term "Omnicell, Inc.," refers only to Omnicell, Inc., excluding its subsidiaries.

[0001628280-17-005045:mdna:13]
We own various trademarks, copyrights and trade names used in our business, including the following: Omnicell®, the Omnicell logo, OmniRx®, OmniCenter®, OmniSupplier®, OmniBuyer®, SafetyStock®, WorkflowRx™, OmniLinkRx™, Optiflex™, SinglePointe™, AnywhereRN™, Anesthesia Workstation™ , Savvy™, MTS Medication Technologies®, the MTS Medication Technologies logo, Medlocker®, AccuFlex®, Autobond ™, AutoGen ™, easyBLIST™, Pandora®, OnDemand®, Multi-Med™, RxMap®, MTS-350 ™, MTS-400 ™, MTS-500 ™ SureMed, ROBOT-Rx®, MedCarousel®, MedShelf-Rx™, PROmanager-Rx™, PACMED™, NarcStation™, PakPlus-Rx®, i.v.STATION™, i.v.SOFT®, Enterprise Medication Manager™, XT Anesthesia Workstation™, Performance Center™, Time My Meds® and Automation Decision Support™ . This report also includes other trademarks, service marks and trade names of other companies. All other trademarks used in this report are trademarks of their respective holders.

[0001628280-17-005045:mdna:14]
[same as prior period, unchanged from 0000926326-16-000077:mdna:14]

[0001628280-17-005045:mdna:15]
[same as prior period, unchanged from 0000926326-16-000077:mdna:15]

[0001628280-17-005045:mdna:16]
We are a leading provider of comprehensive automation and business analytics software solutions for patient-centric medication and supply management across the entire healthcare continuum, from the acute care hospital setting to post-acute skilled nursing and long-term care facilities to the home. Our Omnicell Automation and Analytic customers worldwide use our medication automation, supply chain and analytics solutions to help enable them to increase operational efficiency, reduce errors, deliver actionable intelligence and improve patient safety.

[0001628280-17-005045:mdna:17]
Omnicell Medication Adherence solutions, including the MTS and Ateb brands, provide innovative medication adherence packaging solutions that can help reduce costly hospital readmissions and enable institutional and retail pharmacies worldwide to maintain high accuracy and quality standards in medication dispensing and administration while optimizing productivity and controlling costs.

[0001628280-17-005045:mdna:18]
We sell our product and consumable solutions together with related service offerings. Revenue generated in the United States represented 88% and 84% of total revenue for the three months ended March 31, 2017 and 2016, respectively. We expect our revenues from international operations to increase in future periods as we continue to grow our international business. We have not sold in the past, and have no future plans to sell our products either directly or indirectly, to customers located in countries that are identified as state sponsors of terrorism by the U.S. Department of State, and are subject to economic sanctions and export controls.

[0001628280-17-005045:mdna:19]
[same as prior period, unchanged from 0000926326-16-000077:mdna:20]

[0001628280-17-005045:mdna:20]
We manage our business as two operating segments, which are the same as our two reportable segments: Automation and Analytics, and Medication Adherence.

[0001628280-17-005045:mdna:21]
[same as prior period, unchanged from 0000926326-16-000077:mdna:23]

[0001628280-17-005045:mdna:22]
The Automation and Analytics segment is organized around the design, manufacturing, selling, and servicing of medication and supply dispensing systems, pharmacy inventory management systems, and related software. Our Automation and Analytics products are designed to enable our customers to enhance and improve the effectiveness of the medication-use process, the efficiency of the medical-surgical supply chain, overall patient care and clinical and financial outcomes of medical facilities. Through modular configuration and upgrades, our systems can be tailored to specific customer needs.

[0001628280-17-005045:mdna:23]
[same as prior period, unchanged from 0000926326-16-000077:mdna:25]

[0001628280-17-005045:mdna:24]
The Medication Adherence segment includes the development manufacturing and selling of consumable medication blister cards, packaging equipment, pharmacy-based patient care software solutions including a medication synchronization platform, and ancillary products and services.  These products are used to manage medication administration outside of the hospital setting and include medication adherence products sold under the brand name MTS, SureMed, Ateb, and the Omnicell brands. MTS products consist of proprietary medication packaging systems and related products for use by institutional pharmacies servicing long-term care and correctional facilities, or retail pharmacies serving patients in their local communities. Recently acquired Ateb is a provider of pharmacy-based patient care solutions and medication synchronization to independent and chain pharmacies.

[0001628280-17-005045:mdna:25]
For further description of our operating segments, refer to Note 13, Segment and Geographical Information, of the Notes to Consolidated Financial Statements in this quarterly report.

[0001628280-17-005045:mdna:26]
[same as prior period, unchanged from 0000926326-16-000077:mdna:28]

[0001628280-17-005045:mdna:27]
The healthcare market is experiencing a period of substantive change. The adoption of electronic healthcare records, new regulatory constraints, and changes in the reimbursement structure have caused healthcare institutions to re-examine their operating structures, re-prioritize their investments, and seek efficiencies. We believe our customers’ evolving operating environment creates challenges for any supplier, but also affords opportunities for suppliers that are able to partner with customers to help them meet the changing demands. We have, and intend to continue to, invest in the strategies which we believe have generated and will continue to generate our revenue and earnings growth, while supporting our customers’ initiatives and needs. These strategies include:

[0001628280-17-005045:mdna:28]
| • | Development of differentiated solutions. We invest in the development of products that we believe bring patient safety and workflow efficiency to our customers’ operations that they cannot get from other competing solutions. These differentiators may be as small as how a transaction operates or information provided on a report or as large as the entire automation of a workflow that would otherwise be completed manually. We intend to continue our |

[0001628280-17-005045:mdna:29]
25

[0001628280-17-005045:mdna:30]
focus on differentiating our products, and we carefully assess our investments regularly as we strive to ensure those investments provide the solutions most valuable to our customers.

[0001628280-17-005045:mdna:31]
[same as prior period, unchanged from 0000926326-16-000077:mdna:31]

[0001628280-17-005045:mdna:32]
[same as prior period, unchanged from 0000926326-16-000077:mdna:32]

[0001628280-17-005045:mdna:33]
Our investments have been consistent with the strategies outlined above. To differentiate our solutions from others available in the market, in December 2016 we introduced the XT Series, our new generation of medication and supply automation that is fully integrated on our Unity enterprise platform. The XT Series includes automated medication and supply dispensing cabinets, the Anesthesia Workstation, and Controlled Substance Manager. The XT Automated Medication Cabinets have been integrated with Connect-Rx® from Aesynt, so customers in the United States who use AcuDose-Rx® cabinets can take advantage of the XT Series hardware without changing their software or server infrastructure. As part of this product introduction, we developed a new hardware and electronics architecture for the XT Series. Additionally, in February 2017 we introduced VBM 200F, an automated pharmacy solution that fills and checks SureMed® multiple medication blister cards utilizing guided light, barcode and RFID technologies to allow the filled tray to be audited throughout the entire packing process. This technology helps ensure that pharmacies have the competitive advantage to easily scale their business to help improve adherence and patient outcomes.

[0001628280-17-005045:mdna:34]
Consistent with our strategy to enter new markets, we have made investments in our selling, general and administrative expenses to expand our sales team and market to new customers. Our international efforts have focused primarily on Western Europe, where we sell solutions through a direct sales team in the United Kingdom, France, and Germany and through resellers in other markets; and in the Middle Eastern countries of the Arabian Peninsula. We have also expanded our sales efforts to medication adherence customers in the United States which has allowed us to sell our automated dispensing solutions and other products to this market.

[0001628280-17-005045:mdna:35]
Expansion of our solutions through acquisitions and partnerships include our acquisition of MTS in 2012, our acquisition of Surgichem in August 2014, our acquisitions of Mach4 and Avantec in April 2015, our acquisition of Aesynt in January 2016, our acquisition of Ateb in December 2016, and most recently, our acquisition of InPharmics in April 2017.  Surgichem is a provider of medication adherence products in the United Kingdom. Mach4 is a provider of automated medication management systems to retail and hospital pharmacy customers primarily in Europe, with additional installations in China, the Middle East and Latin America. Avantec develops medication and supply automation products that complement our solutions for configurations suited to the United Kingdom marketplace, and has been the exclusive United Kingdom distributor for our medication and supply automation solutions since 2005. Aesynt is a provider of automated medication management systems, including dispensing robots with storage solutions, medication storage and dispensing carts and cabinets, I.V. sterile preparation robotics and software, including software related to medication management. Ateb is a provider of pharmacy-based patient care solutions and medication synchronization to independent and chain pharmacies. InPharmics is a technology and services company that provides advanced pharmacy informatics solutions to hospital pharmacies. We have also developed relationships with major providers of hospital information management systems with the goal of enhancing the interoperability of our products with their systems. We believe that enhanced interoperability will help reduce implementation costs, time, and maintenance for shared clients, while providing new clinical workflows designed to enhance efficiency and patient safety.

[0001628280-17-005045:mdna:36]
We believe that the success of our three leg strategy of differentiated products, expansion into new markets and acquisition and partnership in future periods, will be based on, among other factors:

[0001628280-17-005045:mdna:37]
[same as prior period, unchanged from 0000926326-16-000077:mdna:39]

[0001628280-17-005045:mdna:38]
| • | Our expectation that the environment of increased patient safety awareness, increased regulatory control, increased demand for innovative products that improve the care experience and increased need for workflow efficiency through the adoption of technology in the healthcare industry will make our solutions a priority in the capital budgets of healthcare facilities; and |

[0001628280-17-005045:mdna:39]
[same as prior period, unchanged from 0000926326-16-000077:mdna:11]

[0001628280-17-005045:mdna:40]
[same as prior period, unchanged from 0000926326-16-000077:mdna:41]

[0001628280-17-005045:mdna:41]
Among other financial measures, we utilize product bookings to assess the current success of our strategies. Product bookings consist of all firm orders, as evidenced by a contract and purchase order for equipment and software, and by a purchase order for consumables. Equipment and software bookings are installable within twelve months and, other than subscription based sales, generally recorded as revenue upon customer acceptance of the installation. Consumables are recorded as revenue upon shipment to a customer or receipt by the customer, depending upon contract terms. Consumable bookings are generally recorded as revenue within one month.

[0001628280-17-005045:mdna:42]
In addition to product solution sales, we provide services to our customers.  Our healthcare customers expect a high degree of partnership involvement from their technology suppliers throughout their ownership of the products. We provide extensive installation planning and consulting as part of every product sale and included in the initial price of the solution. Our customers' medication control systems are mission critical to their success and our customers require these systems to be functional at all times. To help assure the maximum availability of our systems, our customers typically purchase maintenance and support contracts in one, two or five year increments.  As a result of the growth of our installed base of customers, our service revenues have also grown. We strive to provide the best service possible, as measured by third-party rating agencies and by our own surveys, to assure our customers continue to seek service maintenance from us.

[0001628280-17-005045:mdna:43]
In the future, we expect our strategies to evolve as the business environment of our customers evolves, but for our focus to remain on improving healthcare with solutions that help change the practices in ways that improve patient and provider outcomes. We expect our investment in differentiated products, new markets, and acquisitions and partnerships to continue. In 2017, we also intend to manage our business to operating profit margins similar to those achieved in 2016, bringing our strategies to bear in all the markets in which we participate.

[0001628280-17-005045:mdna:44]
On February 15, 2017, we announced our intention to create Centers of Excellence (“COE”) for product development, engineering and manufacturing, with the Point of Use COE located at our facilities in California, the Robotics and Central Pharmacy COE located at our facilities near Pittsburgh, Pennsylvania, and the Medication Adherence Consumables COE located at our facilities in St. Petersburg, Florida. As part of this initiative, we reduced our workforce by approximately 100 full-time employees, or about 4% of the total headcount, and will be closing our Nashville, Tennessee and Slovenia facilities. Our full-time headcount was approximately 2,361 and 2,444 on March 31, 2017 on December 31, 2016, respectively.

[0001628280-17-005045:mdna:45]
Recent Acquisitions

[0001628280-17-005045:mdna:46]
On January 5, 2016, we completed the acquisition of all of the membership interests of Aesynt. Aesynt is a provider of automated medication management systems, including dispensing robots with storage solutions, medication storage and dispensing carts and cabinets, I.V. sterile preparation robotics and software, including software related to medication management. The purchase price consideration was $271.5 million, net of cash acquired of $8.2 million. The results of Aesynt's operations have been included in our consolidated results of operations since January 6, 2016, and presented as part of the Automation & Analytics segment.

[0001628280-17-005045:mdna:47]
On December 8, 2016, we completed our acquisition of ateb, Inc., and Ateb Canada Ltd. (together, “Ateb”). Ateb is a provider of pharmacy-based patient care solutions and the medication synchronization solutions leader to independent and chain pharmacies with over one million active pharmacy patients.  The purchase price consideration was $40.7 million, net of cash acquired of $0.9 million. The results of Ateb's operations have been included in our consolidated results of operations beginning December 9, 2016, and presented as part of the Medication Adherence segment.

[0001628280-17-005045:mdna:48]
On April 19, 2017, we announced the acquisition of InPharmics, a Mississippi-based technology and services company that provides advanced pharmacy informatics solutions to hospital pharmacies in an all-cash transaction for $5.3 million. The acquisition will expand the capabilities of Omnicell’s Performance Center™.  We are in the process of evaluating the business combination accounting considerations, including the consideration transferred and the initial purchase price allocation.

[0001628280-17-005045:mdna:49]
[same as prior period, unchanged from 0000926326-16-000077:mdna:22]

[0001628280-17-005045:mdna:50]
[same as prior period, unchanged from 0000926326-16-000077:mdna:48]

[0001628280-17-005045:mdna:51]
[same as prior period, unchanged from 0000926326-16-000077:mdna:49]

[0001628280-17-005045:mdna:52]
[same as prior period, unchanged from 0000926326-16-000077:mdna:50]

[0001628280-17-005045:mdna:53]
[same as prior period, unchanged from 0000926326-16-000077:mdna:51]

[0001628280-17-005045:mdna:54]
[same as prior period, unchanged from 0000926326-16-000077:mdna:52]

[0001628280-17-005045:mdna:55]
[same as prior period, unchanged from 0000926326-16-000077:mdna:53]

[0001628280-17-005045:mdna:56]
[same as prior period, unchanged from 0000926326-16-000077:mdna:54]

[0001628280-17-005045:mdna:57]
[same as prior period, unchanged from 0000926326-16-000077:mdna:55]

[0001628280-17-005045:mdna:58]
[same as prior period, unchanged from 0000926326-16-000077:mdna:56]

[0001628280-17-005045:mdna:59]
[same as prior period, unchanged from 0000926326-16-000077:mdna:57]

[0001628280-17-005045:mdna:60]
There have been no material changes in the matters for which we make critical accounting estimates in the preparation of our Condensed Consolidated Financial Statements during the three months ended March 31, 2017 as compared to those disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our annual report on Form 10-K for the year ended December 31, 2016.

[0001628280-17-005045:mdna:61]
[same as prior period, unchanged from 0000926326-16-000077:mdna:59]

[0001628280-17-005045:mdna:62]
[same as prior period, unchanged from 0000926326-16-000077:mdna:60]

[0001628280-17-005045:mdna:63]
[same as prior period, unchanged from 0000926326-16-000077:mdna:61]

[0001628280-17-005045:mdna:64]
[same as prior period, unchanged from 0000926326-16-000077:mdna:62]

[0001628280-17-005045:mdna:65]
|  | Three months ended March 31, |
|  |  |  |  |  | Change in |
|  | 2017 |  | 2016 |  | $ |  | % |
|  | (Dollars in thousands) |
| Product revenues | $ | 98,930 |  |  | $ | 127,895 |  |  | $ | (28,965 | ) |  | (23 | )% |
| Percentage of total revenues | 66 | % |  | 75 | % |  |  |  |  |
| Service and other revenues | 51,624 |  |  | 43,109 |  |  | 8,515 |  |  | 20 | % |
| Percentage of total revenues | 34 | % |  | 25 | % |  |  |  |  |
| Total revenues | $ | 150,554 |  |  | $ | 171,004 |  |  | $ | (20,450 | ) |  | (12 | )% |

[0001628280-17-005045:mdna:66]
Product revenues represented 66% and 75% of total revenues for the three months ended March 31, 2017 and March 31, 2016, respectively. Product revenues decreased by $29.0 million due to decreased sales for the Automation and Analytics segment of $28.1 million, and decreased sales for the Medication Adherence segment of $0.9 million. The decrease in the Automation and Analytics segment was attributed to slower conversion of bookings and backlog into revenue as result of the introduction of the XT series products in the fourth quarter of 2016. The decrease in the Medication Adherence segment was attributed to lower sales in the consumable product sales compared to the three months ended March 31, 2016 primarily due to the timing of orders from several significant customers.

[0001628280-17-005045:mdna:67]
Service and other revenues represented 34% and 25% of total revenues for the three months ended March 31, 2017 and March 31, 2016, respectively. Service and other revenues include revenues from service and maintenance contracts and rentals of automation systems. Service and other revenues increased by $8.5 million primarily due to an increase from our Automation and Analytics segment of $3.4 million attributed to higher service renewal fees driven mainly by an increase in our installed

[0001628280-17-005045:mdna:68]
customer base. Service and other revenues from the Medication Adherence segment increased $5.2 million, primarily attributed to Ateb, acquired in the fourth quarter of 2016, which contributed $5.5 million to the service revenue during the three months ended March 31, 2017.

[0001628280-17-005045:mdna:69]
Our international sales represented 12% and 16% of total revenues for the three months ended March 31, 2017 and 2016, respectively, and are expected to be affected by foreign currency exchange rates fluctuations. The decrease in international sales was primarily related to the recently acquired companies, Aesynt and Ateb, which have a higher market presence in United States compared to international markets. We are unable to predict the extent to which revenue in future periods will be impacted by changes in foreign currency exchange rates.

[0001628280-17-005045:mdna:70]
We anticipate our revenues to increase in 2017 compared to 2016 as we execute on our strategies, fulfill our existing orders and based on our anticipated growth in bookings. Our ability to continue to grow revenue is dependent on our ability to continue to obtain orders from customers, our ability to produce quality consumables to fulfill customer demand, the volume of installations we are able to complete, our ability to meet customer needs by providing a quality installation experience, and our flexibility in manpower allocations among customers to complete installations on a timely basis. The timing of our product revenues for equipment is primarily dependent on when our customers’ schedules allow for installations.

[0001628280-17-005045:mdna:71]
[same as prior period, unchanged from 0000926326-16-000077:mdna:74]

[0001628280-17-005045:mdna:72]
[same as prior period, unchanged from 0000926326-16-000077:mdna:75]

[0001628280-17-005045:mdna:73]
|  | Three months ended March 31, |
|  |  |  |  |  | Change in |
|  | 2017 |  | 2016 |  | $ |  | % |
| Revenues: | (Dollars in thousands) |
| Automation and Analytics | $ | 124,171 |  |  | $ | 148,945 |  |  | $ | (24,774 | ) |  | (17 | )% |
| Percentage of total revenues | 82 | % |  | 87 | % |  |  |  |  |
| Medication Adherence | 26,383 |  |  | 22,059 |  |  | 4,324 |  |  | 20 | % |
| Percentage of total revenues | 18 | % |  | 13 | % |  |  |  |  |
| Total revenues | $ | 150,554 |  |  | $ | 171,004 |  |  | $ | (20,450 | ) |  | (12 | )% |

[0001628280-17-005045:mdna:74]
The $24.8 million decrease in Automation and Analytics revenues for the three months ended March 31, 2017 in comparison to the three months ended March 31, 2016 was due to a decrease in product revenue of $28.1 million, partially offset by an increase in service revenues of $3.4 million. The decrease in the Automation and Analytics segment was attributed to slower conversion of bookings and backlog into revenue as result of the introduction of the XT series products in the fourth quarter of 2016. While we have experienced larger deal sizes, the administrative process of converting our existing bookings of G4 products into XT series products has decelerated the revenue recognition during the three months ended March 31, 2017 compared to the three months ended March 31, 2016. The service revenue increase of $3.4 million was primarily attributed to higher service renewal fees driven mainly by an increase in installed customer base.

[0001628280-17-005045:mdna:75]
Medication Adherence revenues increased by $4.3 million for the three months ended March 31, 2017 in comparison to the three months ended March 31, 2016.  The increase in revenue was primarily due to the increase in service revenue of $5.2 million, partially offset by the decrease of $0.9 million in product revenue attributed to lower consumable revenue due to timing of orders. The service revenue increase of $5.2 million was primarily attributed to Ateb, acquired in the fourth quarter of 2016, which contributed $5.5 million to the service revenue during the three months ended March 31, 2017.

[0001628280-17-005045:mdna:76]
[same as prior period, unchanged from 0000926326-16-000077:mdna:82]

[0001628280-17-005045:mdna:77]
[same as prior period, unchanged from 0000926326-16-000077:mdna:83]

[0001628280-17-005045:mdna:78]
|  | Three months ended March 31, |
|  |  |  |  |  | Change in |
|  | 2017 |  | 2016 |  | $ |  | % |
| Cost of revenues: | (Dollars in thousands) |
| Automation and Analytics | $ | 68,761 |  |  | $ | 77,207 |  |  | $ | (8,446 | ) |  | (11 | )% |
| As a percentage of related revenues | 55 | % |  | 52 | % |  |  |  |  |
| Medication Adherence | 17,601 |  |  | 13,852 |  |  | 3,749 |  |  | 27 | % |
| As a percentage of related revenues | 67 | % |  | 63 | % |  |  |  |  |
| Total cost of revenues | $ | 86,362 |  |  | $ | 91,059 |  |  | $ | (4,697 | ) |  | (5 | )% |
| As a percentage of total revenues | 57 | % |  | 53 | % |  |  |  |  |
| Gross profit: |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 55,410 |  |  | $ | 71,738 |  |  | $ | (16,328 | ) |  | (23 | )% |
| Automation and Analytics gross margin | 45 | % |  | 48 | % |  |  |  |  |
| Medication Adherence | 8,782 |  |  | 8,207 |  |  | 575 |  |  | 7 | % |
| Medication Adherence gross margin | 33 | % |  | 37 | % |  |  |  |  |
| Total gross profit | $ | 64,192 |  |  | $ | 79,945 |  |  | $ | (15,753 | ) |  | (20 | )% |
| Total gross margin | 43 | % |  | 51 | % |  |  |  |  |

[0001628280-17-005045:mdna:79]
Cost of Revenues. The cost of revenues for the three months ended March 31, 2017 compared to the three months ended March 31, 2016 decreased by $4.7 million, of which $8.4 million was attributed to the decrease of cost of revenue in our Automation and Analytics segment, partially offset by $3.7 million of increased cost of revenue in our Medication Adherence segment. The decrease of the cost of revenue in the Automation and Analytics segment was attributed to a decrease of $24.8 million in product revenue, partially offset by severance expense of $1.3 million recognized during the three months ended March 31, 2017 in connection with the restructuring plan. The increase of the cost of revenue in the Medication Adherence segment was attributed to an increase of 20% in product revenue and severance expense of $0.4 million recognized during the three months ended March 31, 2017 in connection with the restructuring plan.  Recently acquired Ateb contributed $3.1 million to the increase in cost of revenue.

[0001628280-17-005045:mdna:80]
Gross Profit. The gross profit for the three months ended March 31, 2017 decreased $15.8 million compared to the three months ended March 31, 2016 as a result of product mix, lower amortization of acquired intangibles of $2.3 million, partially offset by additional expense for restructuring related cost of $1.7 million, and share based compensation expense of $0.2 million.

[0001628280-17-005045:mdna:81]
[same as prior period, unchanged from 0000926326-16-000077:mdna:64]

[0001628280-17-005045:mdna:82]
Operating Expenses and Income (loss) from Operations

[0001628280-17-005045:mdna:83]
|  | Three months ended March 31, |
|  |  |  |  |  | Change in |
|  | 2017 |  | 2016 |  | $ |  | % |
| Operating expenses: | (Dollars in thousands) |
| Research and development | $ | 16,803 |  |  | $ | 13,838 |  |  | $ | 2,965 |  |  | 21 | % |
| As a percentage of total revenues | 11 | % |  | 8 | % |  |  |  |  |
| Selling, general and administrative | 64,625 |  |  | 64,255 |  |  | 370 |  |  | 1 | % |
| As a percentage of total revenues | 43 | % |  | 38 | % |  |  |  |  |
| Total operating expenses | $ | 81,428 |  |  | $ | 78,093 |  |  | $ | 3,335 |  |  | 4 | % |
| As a percentage of total revenues | 54 | % |  | 46 | % |  |  |  |  |
| Income (loss) from operations: |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 4,663 |  |  | $ | 19,533 |  |  | $ | (14,870 | ) |  | (76 | )% |
| Operating margin | 3 | % |  | 13 | % |  |  |  |  |
| Medication Adherence | (2,414 | ) |  | 2,596 |  |  | (5,010 | ) |  | (193 | )% |
| Operating margin | (10 | )% |  | 12 | % |  |  |  |  |
| Corporate Expenses | 19,485 |  |  | 20,277 |  |  | (792 | ) |  | (4 | )% |
| Total income (loss) from operations | $ | (17,236 | ) |  | $ | 1,852 |  |  | $ | (19,088 | ) |  | (1,031 | )% |
| Total operating margin | (11 | )% |  | 1 | % |  |  |  |  |

[0001628280-17-005045:mdna:84]
Research and Development. The $3.0 million increase in research and development expenses for the three months ended March 31, 2017 compared to three months ended March 31, 2016 was primarily driven by an increase in research and development expenses of $1.4 million in our Medication Adherence segment and an increase of $1.2 million for Automation and Analytics segment research and development expenses. The increase in our Medication Adherence segment was attributed to Ateb acquired in fourth quarter of 2016, which accounted for $0.8 million of the increase. The remaining increase was primarily attributed to the restructuring charges of $1.1 million recorded during the three months ended March 31, 2017.

[0001628280-17-005045:mdna:85]
Selling, General and Administrative.  The $0.4 million increase in selling, general and administrative expenses for the three months ended March 31, 2017 compared to the three months ended March 31, 2016 was primarily due to the $4.1 million increase from our Medication Adherence segment, partially offset by the decrease of $2.6 million in our Automation and Analytics segment and the decrease of $1.1 million in corporate expenses. The increase in the Medication Adherence segment is attributed to Ateb, acquired in the fourth quarter of 2016, which contributed $3.6 million. The decrease in the Automation and Analytics segment is due to non-recurrence of the $1.7 million of transaction expenses for the Aesynt acquisition in the first quarter of 2016, lower amortization expense of acquired intangible assets from the Aesynt acquisition of approximately $0.7 million and $0.7 million in other decreased expenses, primarily labor-related, offset by an increase in restructuring charges of approximately $0.5 million.  The decrease in the corporate related charges is due to overall decrease in expenses as part of cost saving initiatives.

[0001628280-17-005045:mdna:86]
Operating Income (Loss). Operating income from our Automation and Analytics segment decreased by $14.9 million due to the lower gross margin of $16.3 million, partially offset by lower research and development and selling, general and administrative costs of $1.5 million. Operating income from our Medication Adherence segment decreased by $5.0 million due to higher research and development and selling, general and administrative costs of $5.5 million primarily attributed to Ateb, partially offset by higher gross margin of $0.5 million.

[0001628280-17-005045:mdna:87]
Provision for (benefit from) Income Taxes

[0001628280-17-005045:mdna:88]
|  | Three months ended |
|  |  |  |  |  | Change in |
|  | March 31, 2017 |  | March 31, 2016 |  | $ |  | % |
|  | (Dollars in thousands) |
| Provision for (benefit from) income taxes | $ | (8,938 | ) |  | $ | 59 |  |  | $ | (8,997 | ) |  | (15,249 | )% |

[0001628280-17-005045:mdna:89]
Our annual effective tax rate before discrete items was 39.1% and 37.0% for the three months ended March 31, 2017 and 2016, respectively. The increase in the estimated annual effective tax rate for the three months ended March 31, 2017

[0001628280-17-005045:mdna:90]
compared to the same period in 2016 was primarily due to an increase in our worldwide income, partially offset by federal research credit benefits.  Additionally, the Company adopted ASU 2019-16 effective January 1, 2017, as described in Note 1.

[0001628280-17-005045:mdna:91]
[same as prior period, unchanged from 0000926326-16-000077:mdna:115]

[0001628280-17-005045:mdna:92]
Our cash position and working capital at March 31, 2017 and December 31, 2016 were as follows:

[0001628280-17-005045:mdna:93]
|  | March 31, 2017 |  | December 31, 2016 |
|  | (In thousands) |
| Cash and cash equivalents | $ | 46,348 |  |  | $ | 54,488 |  |
| Working Capital | $ | 96,899 |  |  | $ | 134,496 |  |

[0001628280-17-005045:mdna:94]
All of our cash and cash equivalents for these periods were invested in bank demand deposits. Our ratio of current assets to current liabilities was 1.5:1 at March 31, 2017 compared to 1.7:1 at December 31, 2016.

[0001628280-17-005045:mdna:95]
[same as prior period, unchanged from 0000926326-16-000077:mdna:116]

[0001628280-17-005045:mdna:96]
On January 5, 2016, we entered into a $400 million secured credit facility pursuant to a credit agreement, by and among us, the lenders from time to time party thereto, Wells Fargo Securities, LLC, as sole lead arranger and Wells Fargo Bank, National Association, as administrative agent (the “Credit Agreement”). The Credit Agreement provides for a $200 million term loan facility (the “Term Loan Facility”) and a $200 million revolving credit facility (the “Revolving Credit Facility” and together with the Term Loan Facility, the “Facilities”). In addition, the Credit Agreement includes a letter of credit sub-limit of up to $10 million and a swing line loan sub-limit of up to $10 million. We expect to use future loans under the Revolving Credit Facility, if any, for general corporate purposes, including acquisitions. The Credit Agreement replaced our Credit Agreement, dated September 25, 2013, by and among the Company, the lenders from time to time party thereto and Wells Fargo Bank, National Association, as administrative agent, as amended.

[0001628280-17-005045:mdna:97]
Loans under the Facilities bear interest, at our option, at a rate equal to either (a) the LIBOR Rate, plus an applicable margin ranging from 1.50% to 2.25% per annum based on the our Consolidated Total Net Leverage Ratio (as defined in the Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) LIBOR for an interest period of one month, plus an applicable margin ranging from 0.50% to 1.25% per annum based on our Consolidated Total Net Leverage Ratio (as defined in the Credit Agreement). Undrawn commitments under the Revolving Credit Facility will be subject to a commitment fee ranging from 0.20% to 0.35% per annum based on our Consolidated Total Net Leverage Ratio on the average daily unused portion of the Revolving Credit Facility. A letter of credit participation fee ranging from 1.50% to 2.25% per annum based on our Consolidated Total Net Leverage Ratio will accrue on the average daily amount of letter of credit exposure.

[0001628280-17-005045:mdna:98]
The Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to us and our subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends and other distributions. The Credit Agreement contains financial covenants that require us and our subsidiaries to not exceed a maximum consolidated total leverage ratio and maintain a minimum fixed charge coverage ratio. The Credit Agreement also includes financial covenants requiring us not to exceed a maximum consolidated total leverage ratio of 3.00:1 (subject to certain exceptions) and to maintain a minimum fixed charge coverage ratio of 1.50:1.

[0001628280-17-005045:mdna:99]
As of March 31, 2017, the outstanding balance from the facilities (before netting deferred issuance cost) was $220.5 million. We were in full compliance with all covenants.

[0001628280-17-005045:mdna:100]
[same as prior period, unchanged from 0000926326-16-000077:mdna:126]

[0001628280-17-005045:mdna:101]
Our future uses of cash are expected to be primarily for working capital, capital expenditures, loan principal and interest payments, and other contractual obligations. We also expect a continued use of cash for potential acquisitions and acquisition assessment activities.

[0001628280-17-005045:mdna:102]
In accordance with the 2015 Avantec share purchase agreement, we agreed to make potential earn-out payments based on the achievement of bookings targets. Payments earned and paid during the year ended December 31, 2016 were $3.0 million and payments earned by but not yet paid to sellers as of March 31, 2017 were $2.4 million.

[0001628280-17-005045:mdna:103]
Our stock repurchase programs have a total of $54.9 million remaining for future repurchases as of March 31, 2017, which may result in additional use of cash.  See "Stock Repurchase Program" under Note 12. Employee Benefits and Share-Based Compensation, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report.

[0001628280-17-005045:mdna:104]
[same as prior period, unchanged from 0000926326-16-000077:mdna:131]

[0001628280-17-005045:mdna:105]
[same as prior period, unchanged from 0000926326-16-000077:mdna:132]

[0001628280-17-005045:mdna:106]
The following table summarizes, for the periods indicated, selected items in our Condensed Consolidated Statements of Cash Flows (as adjusted for adoption of ASU 2016-09):

[0001628280-17-005045:mdna:107]
|  | Three months ended |
|  | March 31, 2017 |  | March 31, 2016 |
|  | (In thousands) |
| Net cash provided by (used in): |  |  |  |
| Operating activities | $ | 28,182 |  |  | $ | 22,007 |  |
| Investing activities | (6,837 | ) |  | (279,863 | ) |
| Financing activities | (30,136 | ) |  | 228,826 |  |
| Effect of exchange rate changes on cash and cash equivalents | 651 |  |  | 300 |  |
| Net decrease in cash and cash equivalents | $ | (8,140 | ) |  | $ | (28,730 | ) |

[0001628280-17-005045:mdna:108]
[same as prior period, unchanged from 0000926326-16-000077:mdna:135]

[0001628280-17-005045:mdna:109]
[same as prior period, unchanged from 0000926326-16-000077:mdna:136]

[0001628280-17-005045:mdna:110]
Net cash provided by operating activities was $28.2 million for the three months ended March 31, 2017, primarily as a result of the net loss of $10.8 million adjusted for non-cash items and changes in assets and liabilities. The non-cash items primarily consisted of depreciation and amortization expense of $12.4 million, and share-based compensation expense of $5.5 million and $0.4 million of amortization of debt financing fees. The net cash inflow which was contributed to changes in assets and liabilities include (i) a decrease in accounts receivable of $18.9 million due to timing of collections, (ii) an increase in accounts payable of $11.1 million primarily due to the increase in inventory and timing of payments, (iii) an increase in accrued compensation of $2.0 million as result of the restructuring plan, (iv) an increase in deferred revenue of $1.9 million due to timing of orders and revenue being recognized for installed product, and (v) a decrease in the net investment in sales-type leases of $1.1 million. These inflows were partially offset by a decrease in deferred income tax liabilities of $9.1 million and an increase in inventories of $6.9 million for inventory build up in support of forecasted sales, particularly for the XT series.

[0001628280-17-005045:mdna:111]
Net cash provided by operating activities was $22.0 million for the three months ended March 31, 2016, primarily as a result of $0.4 million in net loss adjusted for non-cash items and changes in assets and liabilities. The non-cash items primarily consisted of depreciation and amortization expense of $14.5 million, share-based compensation expense of $3.9 million and $0.4 million of amortization of debt financing fees. The cash inflow attributable to changes in assets and liabilities includes (i) an increase in deferred revenue of $12.7 million due to timing of orders and revenue being recognized for installed product, (ii) an increase in accrued liabilities including compensation of $4.5 million due to timing of payments of employee-related liabilities, (iii) a decrease in prepaid expenses of $2.0 million primarily due to prepaid income taxes of $1.8 million, (iv) an increase in accounts payables of $1.6 million due to timing of payments, and (v) decreases in other long term assets of $1.2 million and in other current assets of $0.3 million. These amounts were partially offset by increases in long-term investment in sales-type leases of $8.9 million due to two significant lease transactions entered into during the quarter, an increase in inventories of $5.1 million to support forecasted sales, a decrease in the other-long term liabilities of $2.7 million, an increase in accounts receivable of $1.1 million due to increased product shipments late in the quarter and a decrease in deferred income taxes of $1.0 million.

[0001628280-17-005045:mdna:112]
[same as prior period, unchanged from 0000926326-16-000077:mdna:139]

[0001628280-17-005045:mdna:113]
[same as prior period, unchanged from 0000926326-16-000077:mdna:89]

[0001628280-17-005045:mdna:114]
Net cash used in investing activities was $6.8 million for the three months ended March 31, 2017, which consisted of capital expenditures of $2.5 million for property and equipment, and $4.4 million for costs of software development mainly related to the performance center project and purchase of intangibles.

[0001628280-17-005045:mdna:115]
Net cash used in investing activities was $279.9 million for the three months ended March 31, 2016, $271.5 million of which was attributable to the acquisition of Aesynt, together with capital expenditures of $4.3 million for property and equipment and $4.1 million for costs of software development for external use and for purchases of intangibles.

[0001628280-17-005045:mdna:116]
[same as prior period, unchanged from 0000926326-16-000077:mdna:144]

[0001628280-17-005045:mdna:117]
Net cash used in financing activities was $30.1 million for the three months ended March 31, 2017 primarily from repayment of $40.0 million of the credit facilities and $1.1 million in employees' taxes paid related to restricted stock units, partially offset by $10.9 million in proceeds from employee stock option exercises and employee stock plan purchases.

[0001628280-17-005045:mdna:118]
Net cash provided by financing activities was $228.8 million for the three months ended March 31, 2016 as a result of proceeds from term loan and revolving credit facilities of $247.1 million, net of deferred issuance cost of $7.9 million, and $5.1 million in proceeds from employee stock option exercises and employee stock plan purchases. The increase in cash provided from financing activities was partially offset by repayment of $20.0 million of the revolving credit facility, and payment of contingent consideration of $3.0 million related to the Avantec acquisition.

[0001628280-17-005045:mdna:119]
[same as prior period, unchanged from 0000926326-16-000077:mdna:147]

[0001628280-17-005045:mdna:120]
There have been no significant changes during the three months ended March 31, 2017 to the contractual obligations disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations, set forth in Part II, Item 7, of our annual report on Form 10-K for the year ended December 31, 2016.

[0001628280-17-005045:mdna:121]
We had $331.8 million in contractual commitments to third parties for non-cancelable operating leases, commitments to contract manufacturers and suppliers, other purchase commitments and term loan and revolving credit facility as of March 31, 2017 as follows:

[0001628280-17-005045:mdna:122]
|  | Payments due by period |
|  | Total |  | Remainder of 2017 |  | 2018 and 2019 |  | 2020 and 2021 |  | Thereafter |
|  | (In thousands) |
| Operating leases (1) | $ | 55,654 |  |  | $ | 8,522 |  |  | $ | 22,707 |  |  | $ | 14,083 |  |  | $ | 10,342 |  |
| Purchase obligations (2) | 55,642 |  |  | 53,935 |  |  | 656 |  |  | 753 |  |  | 298 |  |
| Term loan facility (3) | 190,000 |  |  | 7,500 |  |  | 37,500 |  |  | 145,000 |  |  | — |  |
| Revolving credit facility (3) | 30,500 |  |  | — |  |  | — |  |  | 30,500 |  |  | — |  |
| Total (4) | $ | 331,796 |  |  | $ | 69,957 |  |  | $ | 60,863 |  |  | $ | 190,336 |  |  | $ | 10,640 |  |

[0001628280-17-005045:mdna:123]
[same as prior period, unchanged from 0000926326-16-000077:mdna:151]

[0001628280-17-005045:mdna:124]
[same as prior period, unchanged from 0000926326-16-000077:mdna:152]

[0001628280-17-005045:mdna:125]
[same as prior period, unchanged from 0000926326-16-000077:mdna:153]

[0001628280-17-005045:mdna:126]
| (3) | Amounts shown for Term loan and revolving credit facility are principal repayments only. Due to use of interest rate swaps, the cash interest expense is partly variable and partly fixed, and is not reflected in the above table. Refer to Note 8, Debt, of the Notes to the Condensed Consolidated Financial Statements included in this quarterly report. |

[0001628280-17-005045:mdna:127]
| (4) | We have recorded $6.9 million for uncertain tax positions under long-term liabilities as of March 31, 2017 in accordance with U.S. GAAP. As these liabilities do not reflect actual tax assessments, the timing and amount of payments we might be required to make will depend upon a number of factors. Accordingly, as the timing and amount of payment cannot be estimated, the $6.9 million in uncertain tax position liabilities have not been included in the table above. |

[0001628280-17-005045:mdna:128]
34

[0001628280-17-005045:mdna:129]
[same as prior period, unchanged from 0000926326-16-000077:mdna:156]

[0001628280-17-005045:mdna:130]
As of March 31, 2017, we had no off-balance sheet arrangements as defined under Regulation S-K 303(a)(4) of the Securities Exchange Act of 1934, as amended, and the instructions thereto.
