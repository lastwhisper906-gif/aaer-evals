# OMCL note change history — 0000926326-14-000039 → 0000926326-15-000018


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: no_current_note, score: 0.0

- removed (2015-05-08):
[0000926326-14-000039:note_history:1]
Contingencies

- removed (2015-05-08):
[0000926326-14-000039:note_history:2]
Legal Proceedings

- removed (2015-05-08):
[0000926326-14-000039:note_history:3]
On September 12, 2014, MV Circuit Design, Inc., an Ohio company, brought an action to correct the inventorship of certain patents owned by Omnicell, as well as related state-law claims against the Company in the Northern District of Ohio (Case No. 1:14-cv-02028-DAP) regarding allegations of fraud in the filing and prosecution of U.S. Patent Nos. 8,180,485, 8,773,270, 8,812,153, PCT/US2007/003765, PCT/US2011/063597, and PCT/US2011/0635505. Omnicell has been granted an extension to respond to the Original Complaint on  November 14, 2014. No schedule has yet been set by the court. Omnicell is currently evaluating a response to this complaint and intends to defend the matter vigorously.

- removed (2015-05-08):
[0000926326-14-000039:note_history:4]
As required under ASC 450, "Contingencies," we accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss. We have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that any potential loss, while reasonably possible, is not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. We believe that we have valid defenses with respect to legal proceedings pending against us. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of this contingency or because of the diversion of management's attention and the creation of significant expenses.

- removed (2015-05-08):
[0000926326-14-000039:note_history:5]
Guarantees

- removed (2015-05-08):
[0000926326-14-000039:note_history:6]
As permitted under Delaware law and our certificate of incorporation and bylaws, we have agreed to indemnify our directors and officers against certain losses that they may suffer by reason of the fact that such persons are, were or become our directors or officers. The term of the indemnification period is for the director’s or officer’s lifetime and there is no limit on the potential amount of future payments that we could be required to make under these indemnification agreements. We have purchased a directors’ and officers’ liability insurance policy that may enable us to recover a portion of any future payments that we may be required to make under these indemnification agreements. Assuming the applicability of coverage and the willingness of the insurer to assume coverage and subject to certain retention, loss limits and other policy provisions, we believe it is unlikely that we will be required to pay any material amounts pursuant to these indemnification obligations. However, no assurances can be given that the insurers will not attempt to dispute the validity, applicability or amount of coverage without expensive and time-consuming litigation against the insurers.

- removed (2015-05-08):
[0000926326-14-000039:note_history:7]
Additionally, we undertake indemnification obligations in our ordinary course of business in connection with, among other things, the licensing of our products and the provision of our support services. In the ordinary course of our business, we have in the past and may in the future agree to indemnify another party, generally our business affiliates or customers, against certain losses suffered or incurred by the indemnified party in connection with various types of claims, which may include, without limitation, claims of intellectual property infringement, certain tax liabilities, our gross negligence or intentional acts in the performance of support services and violations of laws. The term of these indemnification obligations is generally perpetual. In general, we attempt to limit the maximum potential amount of future payments that we may be required to make under these indemnification obligations to the amounts paid to us by a customer, but in some cases the obligation may not be so limited. In addition, we have in the past and may in the future warrant to our customers that our products will conform to functional specifications for a limited period of time following the date of installation (generally not exceeding 30 days) or that our software media is free from material defects. Sales contracts for certain of our medication packaging systems often include limited warranties for up to six months, but the periodic activity and ending warranty balances we record have historically been immaterial.

- removed (2015-05-08):
[0000926326-14-000039:note_history:8]
From time to time, we may also warrant that our professional services will be performed in a good and workmanlike manner or in a professional manner consistent with industry standards. We generally seek to disclaim most warranties, including any implied or statutory warranties such as warranties of merchantability, fitness for a particular purpose, title, quality and non-infringement, as well as any liability with respect to incidental, consequential, special, exemplary, punitive or similar damages. In some states, such disclaimers may not be enforceable. If necessary, we would provide for the estimated cost of product and service warranties based on specific warranty claims and claim history. We have not been subject to any significant claims for such losses and have not incurred any material costs in defending or settling claims related to these indemnification obligations. Accordingly, we believe it is unlikely that we will be required to pay any material amounts pursuant to these indemnification obligations or potential warranty claims and, therefore, no material liabilities have been recorded for such indemnification obligations as of September 30, 2014 or December 31, 2013.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: title_similarity, score: 0.8317

- changed (2015-05-08):
[0000926326-15-000018:note_history:9]
Summary of Significant Accounting Policies
  (was, 2014-11-10, similarity 0.8317):
[0000926326-14-000039:note_history:9]
Organization and Summary of Significant Accounting Policies

- added (2015-05-08):
[0000926326-15-000018:note_history:10]
Business

- changed (2015-05-08):
[0000926326-15-000018:note_history:11]
Omnicell, Inc. was incorporated in California in 1992 under the name Omnicell Technologies, Inc. and reincorporated in Delaware in 2001 as Omnicell, Inc. Our major products are automated medication, supply control systems and medication adherence solutions which are sold in our principal market, which is the healthcare industry. Our market is primarily located in the United States and Canada. "Omnicell," "our," "us," "we," or the "Company" collectively refer to Omnicell, Inc. and its subsidiaries.
  (was, 2014-11-10, similarity 0.6986):
[0000926326-14-000039:note_history:11]
Description of the Company. Omnicell, Inc. ("Omnicell," "our," "us," "we," or the "Company") was incorporated in California in 1992 under the name Omnicell Technologies, Inc. and reincorporated in Delaware in 2001 as Omnicell, Inc. Our major products are automated medication supply control systems and medical adherence solutions which are sold in our principal market, which is the healthcare industry. Our market is primarily located in the United States and Canada.

- added (2015-05-08):
[0000926326-15-000018:note_history:12]
Basis of presentation

- added (2015-05-08):
[0000926326-15-000018:note_history:13]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of March 31, 2015 and December 31, 2014, the results of their operations, comprehensive income and cash flows for the three months ended March 31, 2015 and March 31, 2014. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in our annual report on Form 10-K for the year ended December 31, 2014. Our results of operations, comprehensive income and cash flows for the three months ended March 31, 2015 are not necessarily indicative of results that may be expected for the year ending December 31, 2015, or for any future period.

- added (2015-05-08):
[0000926326-15-000018:note_history:14]
Principles of consolidation

- added (2015-05-08):
[0000926326-15-000018:note_history:15]
The Condensed Consolidated Financial Statements include the accounts of the Company and its subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.

- added (2015-05-08):
[0000926326-15-000018:note_history:16]
Use of estimates

- added (2015-05-08):
[0000926326-15-000018:note_history:17]
The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in our Condensed Consolidated Financial Statements and accompanying Notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management's best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition, share-based compensation, inventory valuation, valuation of goodwill, purchased intangibles and long-lived assets, and accounting for income taxes.

- added (2015-05-08):
[0000926326-15-000018:note_history:18]
Segment reporting change

- added (2015-05-08):
[0000926326-15-000018:note_history:19]
In the first quarter of 2015, we modified the segment presentation to reflect the changes in how our Chief Operating Decision Maker (“CODM”) reviews the segments and the overall business. With the increase in acquisitions in the last two years the CODM changed how the financial information was reviewed to exclude general corporate-level costs that are not specific to either of the reporting segments when evaluating the operating results of each segment. Corporate-level costs include expenses related to executive management, finance and accounting, human resources, legal, training and development, and certain administrative expenses.

- added (2015-05-08):
[0000926326-15-000018:note_history:20]
The historical information presented has been retrospectively adjusted to reflect the modified segment reporting. Our CODM allocates resources and evaluates the performance of our segments using information about its revenues, gross profit and income from operations, excluding certain costs which are managed separately at the corporate level. We enhanced our segment reporting structure to match our operating structure based on how our Chief Operating Decision Maker (“CODM”) views the business and allocates resources, beginning in the first quarter of 2015. Our CODM is our Chief Executive Officer. Retrospective adjustments of prior period financial information have been made to conform to the current period presentation. This change does not impact previously reported Condensed Consolidated Financial Statements. See Note 15, Segment Information, for additional information on our segment reporting change.

- added (2015-05-08):
[0000926326-15-000018:note_history:21]
Concentration of credit risk

- changed (2015-05-08):
[0000926326-15-000018:note_history:22]
Financial instruments that may potentially subject us to concentrations of credit risk consist principally of cash equivalents and accounts receivable. Cash equivalents are maintained with several financial institutions and may exceed the amount of insurance provided on such balances. The majority of our accounts receivable are derived from sales to customers for commercial applications. We perform ongoing credit evaluations of our customers’ financial condition and limit the amount of credit extended when deemed necessary but generally require no collateral. We maintain reserves for potential credit losses. Our products are broadly distributed and there were no customers that accounted for more than 10% of our accounts receivable as of March 31, 2015 and December 31, 2014. We believe that we have no significant concentrations of credit risk as of March 31, 2015.
  (was, 2014-11-10, similarity 0.806):
[0000926326-14-000039:note_history:22]
Concentration of credit risk. Financial instruments that may potentially subject us to concentrations of credit risk consist principally of cash equivalents and accounts receivable. Cash equivalents are maintained with several financial institutions and may exceed the amount of insurance provided on such balances. The majority of our accounts receivable are derived from sales to customers for commercial applications. We perform ongoing credit evaluations of our customers’ financial condition and limit the amount of credit extended when deemed necessary but generally require no collateral. We maintain reserves for potential credit losses. Our products are broadly distributed and there was no single customer accounting for 10% or more of revenues in the three and nine months ended September 30, 2014 and 2013. Additionally, there was no single customer accounting for 10% or more of accounts receivable at September 30, 2014 or December 31, 2013. We believe that we have no significant concentrations of credit risk at September 30, 2014.

- added (2015-05-08):
[0000926326-15-000018:note_history:23]
Significant accounting policies

- changed (2015-05-08):
[0000926326-15-000018:note_history:24]
There have been no material changes in our significant accounting policies for the three months ended March 31, 2015, as compared to the significant accounting policies described in our annual report on Form 10-K for the year ended December 31, 2014.
  (was, 2014-11-10, similarity 0.8016):
[0000926326-14-000039:note_history:24]
There have been no material changes in our significant accounting policies as of and for the three and nine months ended September 30, 2014, compared to the significant accounting policies described in our Annual Report on Form 10-K for the year ended December 31, 2013.

- changed (2015-05-08):
[0000926326-15-000018:note_history:25]
Recently issued authoritative guidance
  (was, 2014-11-10, similarity 0.6486):
[0000926326-14-000039:note_history:25]
Recently Issued Accounting Standards

- added (2015-05-08):
[0000926326-15-000018:note_history:26]
In May 2014, the FASB issued ASU No. 2014-09, Revenue from Contracts with Customers, which provides new guidance on the recognition of revenue and states that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. This standard will be effective for annual reporting periods beginning after December 15, 2016, including interim periods within that reporting period. Early application is not permitted, however, in April 2015, the FASB tentatively proposed a one-year deferral of the effective date. If the proposed deferral is approved, the new standard will become effective for us in the first quarter of fiscal 2018. We are currently evaluating the impact of the adoption of this accounting standard update on our consolidated financial position or results of operations.

- added (2015-05-08):
[0000926326-15-000018:note_history:27]
There was no other recently issued authoritative guidance that has a material impact on our Condensed Consolidated Financial Statements through the reporting date.

- removed (2015-05-08):
[0000926326-14-000039:note_history:28]
In 2012, we acquired Medication Technologies, Inc. ("MTS"), a provider of automated and semi-automated equipment to assist institutional and retail pharmacists in filling medication orders into blister cards, the primary method of medication control in non-acute care settings. MTS is part of our Medication Adherence segment which consists of all the products we sell to fulfill medication adherence needs through blister cards, blister card packaging equipment, and related software.

- removed (2015-05-08):
[0000926326-14-000039:note_history:29]
In August of 2014, we acquired Surgichem Limited ("Surgichem"), a provider of medication adherence solutions to the non-acute care market in the United Kingdom ("UK"). Surgichem supplies its monitored dosage systems to a network of over 3,200 independent pharmacies and UK pharmacy chains. Surgichem is expected to complement our Medication Adherence segment. For further information, please see Note 7, Business Acquisition.

- removed (2015-05-08):
[0000926326-14-000039:note_history:30]
Basis of presentation. These interim condensed consolidated financial statements are unaudited but reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of Omnicell and our subsidiaries as of September 30, 2014, the results of our operations and comprehensive income for the three and nine months ended September 30, 2014 and 2013 and our cash flows for the nine months ended September 30, 2014 and 2013. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and accompanying notes included in our Annual Report on Form 10-K for the year ended December 31, 2013.

- removed (2015-05-08):
[0000926326-14-000039:note_history:31]
Our results of operations, comprehensive income for the three and nine months ended September 30, 2014 and cash flows for the nine months ended September 30, 2014 are not necessarily indicative of results that may be expected for the year ending December 31, 2014, or for any future period.

- removed (2015-05-08):
[0000926326-14-000039:note_history:32]
Use of estimates. GAAP requires management to make estimates and assumptions that affect the amounts reported in our consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management's best knowledge of current events and actions that may impact the company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition, share-based compensation, inventory valuation, valuation of goodwill and purchased intangibles, valuation of long-lived assets and accounting for income taxes.

- removed (2015-05-08):
[0000926326-14-000039:note_history:33]
Principles of consolidation. The condensed consolidated financial statements include the accounts of our wholly-owned subsidiaries. All significant inter-company accounts and transactions have been eliminated in consolidation.

- removed (2015-05-08):
[0000926326-14-000039:note_history:34]
Dependence on suppliers. We have a supply agreement with one primary supplier for construction and supply of several sub-assemblies and inventory management of sub-assemblies used in our hardware products. There are no minimum purchase requirements. The contract may be terminated by either the supplier or by us without cause and at any time upon delivery of two months’ notice. Purchases from this supplier for the three months ended September 30, 2014 and 2013 totaled approximately $11.0 million and $8.6 million, respectively, and $28.2 million and $22.5 million for the nine months ended September 30, 2014 and 2013, respectively.

- removed (2015-05-08):
[0000926326-14-000039:note_history:35]
Recently Adopted Accounting Standards

- removed (2015-05-08):
[0000926326-14-000039:note_history:36]
In July 2013, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") 2013-11, Income Taxes (Topic 740): Presentation of an Unrecognized Tax Benefit When a Net Operating Loss Carryforward, a Similar Tax Loss, or a Tax Credit Carryforward Exists ("ASU 2013-11"). ASU 2013-11 requires an entity to present an unrecognized tax benefit, or a portion of an unrecognized tax benefit, as a reduction to a deferred tax asset for a net operating loss carryforward, a similar tax loss, or a tax credit carryforward, except as follows: to the extent a net operating loss carryforward, a similar tax loss, or a tax credit carryforward is not available at the reporting date under the tax law of the applicable jurisdiction to settle any additional income taxes that would result from the disallowance of a tax position or the tax law of the applicable jurisdiction does not require the entity to use, and the entity does not intend to use, the deferred tax asset for such purpose, the unrecognized tax benefit should be presented in the financial statements as a liability and should not be combined with deferred tax assets. We adopted the amendments in ASU 2013-11 in the first quarter of 2014. This update did not have a significant impact on our financial position, operating results or cash flows.

- removed (2015-05-08):
[0000926326-14-000039:note_history:37]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers: Topic 606 ("ASU 2014-09").  ASU 2014-09  supersedes nearly all existing revenue recognition guidance under GAAP.  The core principle of ASU 2014-09 is to recognize revenues when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. ASU 2014-09 defines a five step process to achieve this core principle and, in doing so, it is possible more judgment and estimates may be required within the revenue recognition process than required under existing GAAP, including identifying performance obligations in the contract, estimating the amount of variable consideration to include in the transaction price and allocating the transaction price to each separate performance obligation. Companies may use either of two methods: (i) full retrospective application to each prior reporting period presented with the option to elect certain practical expedients defined within ASU 2014-09; or (ii) modified retrospective application with the cumulative effect of initially applying ASU 2014-09 recognized at the date of initial application and providing certain additional disclosures as defined per ASU 2014-09. ASU 2014-09 is effective for us in the first quarter of 2017 and we are currently evaluating the impact of our pending adoption on our consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-05-08):
[0000926326-15-000018:note_history:38]
In September 2013, we entered into a credit agreement (the "Credit Agreement") with Wells Fargo Bank, National Association, as administrative agent, and the lenders from time to time party thereto. The Credit Agreement provides for a $75 million revolving credit facility with a $10 million letter of credit sub-limit. Loans under the Credit Agreement mature on September 25, 2018. The Credit Agreement permits us to request one or more increases in the aggregate commitments provided that such increases do not exceed $25 million in the aggregate. We expect to use the proceeds from any revolving loans under the credit facility for general corporate purposes, including future acquisitions. Our obligations under the Credit Agreement are guaranteed by certain of our domestic subsidiaries and secured by substantially all of our and the subsidiary guarantors’ assets. We have not yet drawn any funds under the credit facility to date.
  (was, 2014-11-10, similarity 0.9588):
[0000926326-14-000039:note_history:38]
In September 2013, we entered into a credit agreement (the "Credit Agreement") with Wells Fargo Bank, National Association, as administrative agent, and the lenders from time to time thereto. The Credit Agreement provides for a $75.0 million revolving credit facility with a $10.0 million letter of credit sub-limit. Loans under the Credit Agreement mature on September 25, 2018. The Credit Agreement permits us to request one or more increases in the aggregate commitments provided that such increases do not exceed $25.0 million in the aggregate. We expect to use the proceeds from any revolving loans under the credit facility for general corporate purposes, including future acquisitions. Our obligations under the Credit Agreement are guaranteed by certain of our domestic subsidiaries and secured by substantially all of our and the subsidiary guarantors’ assets.

- changed (2015-05-08):
[0000926326-15-000018:note_history:39]
Amounts drawn under the Credit Agreement bear interest, at our election, at a Eurodollar rate plus a margin of 1.75% per annum, or an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) LIBOR for an interest period of one month plus 1.75%. We are required to pay a commitment fee of 0.25% per annum on the aggregate undrawn amount of the commitments under the credit facility.
  (was, 2014-11-10, similarity 0.9894):
[0000926326-14-000039:note_history:39]
Amounts drawn under the Credit Agreement bear interest, at our election, at a Eurodollar rate plus a margin of 1.75% per annum, or an alternate base rate equal to the highest of (a) the prime rate, (b) the federal funds rate plus 0.50%, and (c) LIBOR for an interest period of one month plus 1.75%. We are required to pay a commitment fee of 0.25% per annum on the aggregate undrawn amount of the commitments under the credit facility.

- added (2015-05-08):
[0000926326-15-000018:note_history:40]
On November 5, 2014, we entered into Amendment Number One (the “Amendment”) to the Credit Agreement. The Amendment increases the amount of our common stock that may be repurchased by us in open market transactions authorized by our Board of Directors, together with any repurchases of our common stock from any consultants, employees, officers or directors of the Company or any of our subsidiaries following the death, disability, retirement or termination of employment of such employees, officers or directors, from $25 million to $50 million per year.

- changed (2015-05-08):
[0000926326-15-000018:note_history:41]
The Credit Agreement contains customary affirmative and negative covenants, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends and other distributions. The Credit Agreement contains financial covenants that require us to, among other things, maintain a maximum consolidated total leverage ratio and a minimum consolidated fixed charge coverage ratio, in each case, as of the last day of each quarter. We were in full compliance with all covenants as of March 31, 2015.
  (was, 2014-11-10, similarity 0.9307):
[0000926326-14-000039:note_history:41]
The Credit Agreement contains customary affirmative and negative covenants, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends and other distributions. The Credit Agreement contains financial covenants that require us to, among other things, maintain a maximum consolidated total leverage ratio and a minimum consolidated fixed charge coverage ratio, in each case, as of the last day of each fiscal quarter.

- removed (2015-05-08):
[0000926326-14-000039:note_history:42]
To date, we have not yet drawn any funds under the credit facility. We were in full compliance with all covenants at September 30, 2014 and for all periods since the commencement of the Credit Agreement.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2015-05-08):
[0000926326-15-000018:note_history:43]
Subsequent Events

- added (2015-05-08):
[0000926326-15-000018:note_history:44]
On April 21, 2015, Omnicell International, Inc. (“Omnicell International”), a wholly-owned subsidiary of Omnicell, Inc., completed its acquisition of Mach 4 Automatisierungstechnik GmbH (“Mach4”) pursuant to the Agreement, dated February 26, 2015, by and among Apotheka Imedisa 2001 S.A., Holger Wallat, Dirk Rolf Beils and Peter Jansen (collectively, the “Selling Shareholders”) and Omnicell International (the “Share Purchase Agreement”). Pursuant to the Share Purchase Agreement, Omnicell International purchased the entire registered share capital of Mach4 from the Selling Shareholders for aggregate consideration of approximately $16.5 million, of which $2.7 million was placed in an escrow fund, which will ultimately be distributed to the Selling Shareholders (subject to claims that Omnicell International may have against the escrow fund for indemnification and other claims following the closing) (the “Acquisition”). In addition, Omnicell International will pay approximately $0.9 million to Mach4 for the payoff of existing debt of Mach4. The final purchase price remains subject to certain adjustments as provided for in the Share Purchase Agreement.

- added (2015-05-08):
[0000926326-15-000018:note_history:45]
On April 30, 2015, we closed our acquisition of Avantec Healthcare Limited (“Avantec”) pursuant to  a share purchase agreement (the “Avantec Share Purchase Agreement”) among Omnicell, Inc. and the selling shareholders thereto (the “Avantec Selling Shareholders”) for the purchase of the entire issued share capital of Avantec not already owned by Omnicell, Inc. We previously owned 15% of the company and accounted for it under the equity method. Avantec develops medication and supply automation products that complement our solutions for configurations suited to the United Kingdom marketplace, and has been the exclusive distributor of our medication and supply automation solutions since 2005 in the United Kingdom. As a result of the Acquisition, we paid the Avantec Selling Shareholders an amount equal to $10.2 million in cash, subject to certain adjustments provided for in the Avantec Share Purchase Agreement, and retained an additional $1.8 million of the purchase price which will ultimately be distributed to the Avantec Selling Shareholders (subject to claims that we may have against such funds for indemnification and other claims following the closing). In addition, the Avantec Selling Shareholders will be entitled to receive up to an additional $3.0 million upon the achievement of bookings milestones for 2015 and an additional $3.0 million upon the achievement of bookings milestones for 2016.

- added (2015-05-08):
[0000926326-15-000018:note_history:46]
Both of these acquired companies will be in our Automation and Analytics segment. The valuations and related purchase price allocations for these acquisitions have not yet been completed.
