# OMCL notes — 0000926326-15-000018


## omcl:ScheduleofLongTermNetInvestmentinSaleTypeLeasesTableTextBlock

[0000926326-15-000018:notes:1]
Net investment in sales-type leases consist of the following components:

[0000926326-15-000018:notes:2]
|  | March 31, 2015 |  | December 31, 2014 |
|  | (In thousands) |
| Net minimum lease payments to be received | $ | 17,022 |  |  | $ | 17,616 |  |
| Less: unearned interest income portion | (1,068 | ) |  | (1,131 | ) |
| Net investment in sales-type leases | 15,954 |  |  | 16,485 |  |
| Less: short-term portion | (5,511 | ) |  | (5,637 | ) |
| Long-term net investment in sales-type leases | $ | 10,443 |  |  | $ | 10,848 |  |


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0000926326-15-000018:notes:3]
Accrued Liabilities

[0000926326-15-000018:notes:4]
Accrued liabilities consist of the following:

[0000926326-15-000018:notes:5]
|  | March 31, 2015 |  | December 31, 2014 |
|  | (In thousands) |
| Rebates and lease buyouts | $ | 6,234 |  |  | $ | 6,512 |  |
| Advance payments from customers | 4,825 |  |  | 4,834 |  |
| Group purchasing organization fees | 2,989 |  |  | 3,475 |  |
| Taxes payable | 2,827 |  |  | 2,181 |  |
| Other accrued liabilities | 5,238 |  |  | 2,297 |  |
| Total accrued liabilities | $ | 22,113 |  |  | $ | 19,299 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000926326-15-000018:notes:6]
Basis of presentation

[0000926326-15-000018:notes:7]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of March 31, 2015 and December 31, 2014, the results of their operations, comprehensive income and cash flows for the three months ended March 31, 2015 and March 31, 2014. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in our annual report on Form 10-K for the year ended December 31, 2014. Our results of operations, comprehensive income and cash flows for the three months ended March 31, 2015 are not necessarily indicative of results that may be expected for the year ending December 31, 2015, or for any future period.


## us-gaap:CapitalLeasesInFinancialStatementsOfLessorDisclosureTextBlock

[0000926326-15-000018:notes:8]
Net Investment in Sales-Type Leases

[0000926326-15-000018:notes:9]
The terms of our sales-type leases are generally up to five years in length. Sales-type lease receivables are collateralized by the underlying equipment. Net investment in sales-type leases consist of the following components:

[0000926326-15-000018:notes:10]
We evaluate our sales-type leases individually and collectively for impairment, and recorded no collective allowance for credit losses as of March 31, 2015 and $0.2 million as of December 31, 2014.

[0000926326-15-000018:notes:11]
The minimum lease payments under sales-type leases are as follows:

[0000926326-15-000018:notes:12]
|  | March 31, 2015 |
|  | (In thousands) |
| Remainder of 2015 | $ | 4,689 |  |
| 2016 | 5,053 |  |
| 2017 | 4,024 |  |
| 2018 | 2,383 |  |
| 2019 | 844 |  |
| Thereafter | 29 |  |
| Total | $ | 17,022 |  |


## us-gaap:CommitmentsDisclosureTextBlock

[0000926326-15-000018:notes:13]
[same as prior period, unchanged from 0000926326-14-000039:notes:23]

[0000926326-15-000018:notes:14]
Lease commitments

[0000926326-15-000018:notes:15]
We lease our buildings under operating leases. Commitments under operating leases primarily relate to leasehold property and office equipment.

[0000926326-15-000018:notes:16]
The minimum future payments on non-cancelable operating leases are as follows:

[0000926326-15-000018:notes:17]
|  | March 31, 2015 |
|  | (In thousands) |
| Remainder of 2015 | $ | 5,048 |  |
| 2016 | 6,317 |  |
| 2017 | 5,600 |  |
| 2018 | 5,304 |  |
| 2019 | 5,323 |  |
| Thereafter | 14,977 |  |
| Total minimum future lease payments | $ | 42,569 |  |

[0000926326-15-000018:notes:18]
Purchase obligations

[0000926326-15-000018:notes:19]
We purchase components from a variety of suppliers and use contract manufacturers to provide manufacturing services for our products. During the normal course of business, we issue purchase orders with estimates of our requirements several months ahead of the delivery dates. These amounts are associated with agreements that are enforceable and legally binding. Our purchase obligations to our contract manufacturers and suppliers within the next year were $9.8 million as of March 31, 2015.


## us-gaap:ConsolidationPolicyTextBlock

[0000926326-15-000018:notes:20]
Principles of consolidation

[0000926326-15-000018:notes:21]
The Condensed Consolidated Financial Statements include the accounts of the Company and its subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.


## us-gaap:DebtDisclosureTextBlock

[0000926326-15-000018:notes:22]
Credit Agreement

[0000926326-15-000018:notes:23]
In September 2013, we entered into a credit agreement (the "Credit Agreement") with Wells Fargo Bank, National Association, as administrative agent, and the lenders from time to time party thereto. The Credit Agreement provides for a $75 million revolving credit facility with a $10 million letter of credit sub-limit. Loans under the Credit Agreement mature on September 25, 2018. The Credit Agreement permits us to request one or more increases in the aggregate commitments provided that such increases do not exceed $25 million in the aggregate. We expect to use the proceeds from any revolving loans under the credit facility for general corporate purposes, including future acquisitions. Our obligations under the Credit Agreement are guaranteed by certain of our domestic subsidiaries and secured by substantially all of our and the subsidiary guarantors’ assets. We have not yet drawn any funds under the credit facility to date.

[0000926326-15-000018:notes:24]
Amounts drawn under the Credit Agreement bear interest, at our election, at a Eurodollar rate plus a margin of 1.75% per annum, or an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) LIBOR for an interest period of one month plus 1.75%. We are required to pay a commitment fee of 0.25% per annum on the aggregate undrawn amount of the commitments under the credit facility.

[0000926326-15-000018:notes:25]
On November 5, 2014, we entered into Amendment Number One (the “Amendment”) to the Credit Agreement. The Amendment increases the amount of our common stock that may be repurchased by us in open market transactions authorized by our Board of Directors, together with any repurchases of our common stock from any consultants, employees, officers or directors of the Company or any of our subsidiaries following the death, disability, retirement or termination of employment of such employees, officers or directors, from $25 million to $50 million per year.

[0000926326-15-000018:notes:26]
The Credit Agreement contains customary affirmative and negative covenants, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends and other distributions. The Credit Agreement contains financial covenants that require us to, among other things, maintain a maximum consolidated total leverage ratio and a minimum consolidated fixed charge coverage ratio, in each case, as of the last day of each quarter. We were in full compliance with all covenants as of March 31, 2015.


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0000926326-15-000018:notes:27]
Deferred gross profit consists of the following:

[0000926326-15-000018:notes:28]
|  | March 31, 2015 |  | December 31, 2014 |
|  | (In thousands) |
| Sales of medication and supply dispensing systems including packaging equipment (1) | $ | 34,605 |  |  | $ | 36,947 |  |
| Less: cost of revenues, excluding installation costs | (10,271 | ) |  | (8,389 | ) |
| Total deferred gross profit | $ | 24,334 |  |  | $ | 28,558 |  |

[0000926326-15-000018:notes:29]
_________________________________________________

[0000926326-15-000018:notes:30]
| (1) | Delivered and invoiced, pending installation. |


## us-gaap:DeferredRevenueDisclosureTextBlock

[0000926326-15-000018:notes:31]
Deferred Gross Profit


## us-gaap:EarningsPerShareTextBlock

[0000926326-15-000018:notes:32]
Net Income Per Share

[0000926326-15-000018:notes:33]
Basic net income per share is computed by dividing net income for the period by the weighted-average number of shares outstanding during the period, less shares subject to repurchase. Diluted net income per share is computed by dividing net income for the period by the weighted-average number of shares, less shares subject to repurchase, plus, if dilutive, potential common stock outstanding during the period. Potential common stock includes the effect of outstanding dilutive stock options, restricted stock awards and restricted stock units computed using the treasury stock method. Since the impact is anti-dilutive, these shares were excluded from the calculations of diluted net income per share.

[0000926326-15-000018:notes:34]
The calculation of basic and diluted net income per share is as follows:

[0000926326-15-000018:notes:35]
|  | Three Months Ended |
|  | March 31, 2015 |  | March 31, 2014 |
|  | (In thousands, except per share data) |
| Net income | $ | 6,318 |  |  | $ | 6,194 |  |
| Weighted-average shares outstanding — basic | 36,024 |  |  | 35,225 |  |
| Add: Dilutive effect of employee stock plans | 890 |  |  | 1,080 |  |
| Weighted-average shares outstanding — diluted | 36,914 |  |  | 36,305 |  |
| Net income per share — basic | $ | 0.18 |  |  | $ | 0.18 |  |
| Net income per share — diluted | $ | 0.17 |  |  | $ | 0.17 |  |
| Anti-dilutive weighted-average shares related to stock award plans | 484 |  |  | 347 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0000926326-15-000018:notes:36]
The following table summarizes our assets measured at fair value on a recurring basis using Level 1 inputs within the fair value hierarchy:

[0000926326-15-000018:notes:37]
|  | March 31, 2015 |  | December 31, 2014 |
|  | (In thousands) |
| Cash | $ | 59,458 |  |  | $ | 61,311 |  |
| Cash equivalents | 80,095 |  |  | 64,577 |  |
| Total cash and cash equivalents | $ | 139,553 |  |  | $ | 125,888 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000926326-15-000018:notes:38]
Fair Value Measurements

[0000926326-15-000018:notes:39]
For assets and liabilities measured at fair value, such amounts are based on an expected exit price representing the amount that would be received from the sale of an asset or paid to transfer a liability in a transaction between market participants. As such, fair value may be based on assumptions that market participants would use in pricing an asset or liability. The authoritative guidance on fair value measurements establishes a consistent framework for measuring fair value on either a recurring or nonrecurring basis whereby inputs used in valuation techniques are assigned a hierarchical level. The following methods were used to estimate the fair value of each class of financial instruments for which it is practical to estimate that value:

[0000926326-15-000018:notes:40]
| • | Level 1: Observable inputs that reflect quoted prices (unadjusted) for identical assets or liabilities in active markets. |

[0000926326-15-000018:notes:41]
| • | Level 2: Observable inputs that reflect quoted prices for identical assets or liabilities in markets that are not active, quoted prices for similar assets or liabilities in active markets, inputs other than quoted prices that are observable for the assets or liabilities, or inputs that are derived principally from or corroborated by observable market data by correlation or other means. |

[0000926326-15-000018:notes:42]
| • | Level 3: Unobservable inputs reflecting our own assumptions incorporated in valuation techniques used to determine fair value. These assumptions are required to be consistent with market participant assumptions that are reasonably available. |

[0000926326-15-000018:notes:43]
Assets Measured at Fair Value on a Recurring Basis

[0000926326-15-000018:notes:44]
Cash equivalents. Cash equivalents consist of money market funds that are classified as Level 1, and have an original maturity of three months or less, and therefore the carrying amount is a reasonable estimate of fair value due to the short duration to maturity.

[0000926326-15-000018:notes:45]
There have been no transfers between fair value measurement levels during the three months ended March 31, 2015. The following table summarizes our assets measured at fair value on a recurring basis using Level 1 inputs within the fair value hierarchy:

[0000926326-15-000018:notes:46]
Net investment in sales-type leases. The carrying amount of our sales-type lease receivables is a reasonable estimate of fair value as the unearned interest income is immaterial.

[0000926326-15-000018:notes:47]
Foreign Currency Risk Management

[0000926326-15-000018:notes:48]
We operate in foreign countries, which exposes us to market risk associated with foreign currency exchange rate fluctuations between the U.S. dollar and various foreign currencies, the most significant of which is the British Pound. In order to manage foreign currency risk, we enter into foreign exchange forward contracts to mitigate risks associated with changes in spot exchange rates of mainly non-functional currency denominated assets or liabilities of our foreign subsidiaries.  In general, the market risk related to these contracts is offset by corresponding gains and losses on the hedged transactions. By working only with major banks and closely monitoring current market conditions, we seek to limit the risk that counterparties to these contracts may be unable to perform. The foreign exchange forward contracts are measured at fair value and reported as other current assets or accrued liabilities on the Condensed Consolidated Balance Sheets. The derivative instruments we use to hedge this exposure are not designated as hedges. Any gains or losses on the foreign exchange forward contracts are recognized in earnings as Other Income/Expense in the period incurred in the Condensed Consolidated Statements of Operations. We do not enter into derivative contracts for trading purposes.

[0000926326-15-000018:notes:49]
The aggregate notional amounts of the Company’s outstanding foreign exchange contracts as of March 31, 2015 were $3.4 million. We did not have any outstanding foreign exchange contract as of March 31, 2014.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000926326-15-000018:notes:50]
[same as prior period, unchanged from 0000926326-14-000039:notes:70]

[0000926326-15-000018:notes:51]
[same as prior period, unchanged from 0000926326-14-000039:notes:71]

[0000926326-15-000018:notes:52]
The changes in the carrying amount of goodwill are as follows:

[0000926326-15-000018:notes:53]
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |
|  | (In thousands) |
| Net balance as of December 31, 2014 | $ | 28,543 |  |  | $ | 94,177 |  |  | $ | 122,720 |  |
| Foreign currency exchange rate fluctuations | — |  |  | (504 | ) |  | (504 | ) |
| Net balance as of March 31, 2015 | $ | 28,543 |  |  | $ | 93,673 |  |  | $ | 122,216 |  |

[0000926326-15-000018:notes:54]
Intangible assets, net

[0000926326-15-000018:notes:55]
|  | March 31, 2015 |  | December 31, 2014 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Useful Life(Years) |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Useful Life(Years) |
|  | (In thousands, except for years) |  |  |
| Customer relationships | $ | 60,150 |  |  | $ | (8,804 | ) |  | $ | 51,346 |  |  | 5 - 30 |  | $ | 60,150 |  |  | $ | (7,919 | ) |  | $ | 52,231 |  |  | 5 - 30 |
| Acquired technology | 27,580 |  |  | (4,435 | ) |  | 23,145 |  |  | 3 - 20 |  | 27,580 |  |  | (4,068 | ) |  | 23,512 |  |  | 3 - 20 |
| Trade names | 7,110 |  |  | (1,777 | ) |  | 5,333 |  |  | 1 - 12 |  | 7,110 |  |  | (1,576 | ) |  | 5,534 |  |  | 3 - 12 |
| Patents | 1,757 |  |  | (302 | ) |  | 1,455 |  |  | 20 |  | 1,655 |  |  | (265 | ) |  | 1,390 |  |  | 20 |
| Total intangibles assets, net | $ | 96,597 |  |  | $ | (15,318 | ) |  | $ | 81,279 |  |  |  |  | $ | 96,495 |  |  | $ | (13,828 | ) |  | $ | 82,667 |  |  |  |

[0000926326-15-000018:notes:56]
Capitalization of third-party costs associated with internally-developed patents was $0.1 million as of March 31, 2015, and $0.3 million as of December 31, 2014.

[0000926326-15-000018:notes:57]
Amortization expense of intangible assets was $1.3 million and $1.1 million for the three months ended March 31, 2015 and March 31, 2014, respectively.

[0000926326-15-000018:notes:58]
Total future amortization expense for intangible assets is as follows:

[0000926326-15-000018:notes:59]
|  | March 31, 2015 |
|  | (In thousands) |
| Remainder of 2015 | $ | 3,212 |  |
| 2016 | 4,356 |  |
| 2017 | 4,268 |  |
| 2018 | 4,115 |  |
| 2019 | 4,064 |  |
| Thereafter | 61,264 |  |
| Total | $ | 81,279 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000926326-15-000018:notes:60]
[same as prior period, unchanged from 0000926326-14-000039:notes:82]

[0000926326-15-000018:notes:61]
We provide for income taxes for each interim period based on the estimated annual effective tax rate for the year, adjusting for discrete items in the quarter in which they arise. The annual effective tax rate before discrete items was 38.6% and 39.1% for the three months ended March 31, 2015 and March 31, 2014, respectively. The 2015 and 2014 annual effective tax rate differed from the statutory rate of 35.0% primarily due to the unfavorable impact of state income taxes, non-deductible equity charges, and other non-deductible expenditures, which were partially offset by the domestic production activities deduction.


## us-gaap:InventoryDisclosureTextBlock

[0000926326-15-000018:notes:62]
[same as prior period, unchanged from 0000926326-14-000039:notes:85]

[0000926326-15-000018:notes:63]
Inventories consist of the following components:

[0000926326-15-000018:notes:64]
|  | March 31, 2015 |  | December 31, 2014 |
|  | (In thousands) |
| Raw materials | $ | 7,827 |  |  | $ | 8,254 |  |
| Work in process | 461 |  |  | 64 |  |
| Finished goods | 24,902 |  |  | 23,236 |  |
| Total inventories, net | $ | 33,190 |  |  | $ | 31,554 |  |

[0000926326-15-000018:notes:65]
Dependence on suppliers

[0000926326-15-000018:notes:66]
We have a supply agreement with one primary supplier for construction and supply of several sub-assemblies and inventory management of sub-assemblies used in our hardware products. There are no minimum purchase requirements. The contract with our supplier may be terminated by either the supplier or by us without cause and at any time upon delivery of two months' notice. Purchases from this supplier were $10.0 million and $8.9 million for the three months ended March 31, 2015 and March 31, 2014, respectively.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000926326-15-000018:notes:67]
Recently issued authoritative guidance

[0000926326-15-000018:notes:68]
In May 2014, the FASB issued ASU No. 2014-09, Revenue from Contracts with Customers, which provides new guidance on the recognition of revenue and states that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. This standard will be effective for annual reporting periods beginning after December 15, 2016, including interim periods within that reporting period. Early application is not permitted, however, in April 2015, the FASB tentatively proposed a one-year deferral of the effective date. If the proposed deferral is approved, the new standard will become effective for us in the first quarter of fiscal 2018. We are currently evaluating the impact of the adoption of this accounting standard update on our consolidated financial position or results of operations.

[0000926326-15-000018:notes:69]
There was no other recently issued authoritative guidance that has a material impact on our Condensed Consolidated Financial Statements through the reporting date.


## us-gaap:NonvestedRestrictedStockSharesActivityTableTextBlock

[0000926326-15-000018:notes:70]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |
|  | (In thousands, except per share data) |
| Restricted Stock Awards |  |  |  |
| Outstanding at December 31, 2014 | 36 |  |  | $ | 17.49 |  |
| Granted | — |  |  | — |  |
| Vested | — |  |  | — |  |
| Forfeited | — |  |  | — |  |
| Outstanding and unvested at March 31, 2015 | 36 |  |  | $ | 17.49 |  |


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000926326-15-000018:notes:71]
Summary of Significant Accounting Policies

[0000926326-15-000018:notes:72]
Business

[0000926326-15-000018:notes:73]
Omnicell, Inc. was incorporated in California in 1992 under the name Omnicell Technologies, Inc. and reincorporated in Delaware in 2001 as Omnicell, Inc. Our major products are automated medication, supply control systems and medication adherence solutions which are sold in our principal market, which is the healthcare industry. Our market is primarily located in the United States and Canada. "Omnicell," "our," "us," "we," or the "Company" collectively refer to Omnicell, Inc. and its subsidiaries.

[0000926326-15-000018:notes:74]
Use of estimates

[0000926326-15-000018:notes:75]
The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in our Condensed Consolidated Financial Statements and accompanying Notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management's best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition, share-based compensation, inventory valuation, valuation of goodwill, purchased intangibles and long-lived assets, and accounting for income taxes.

[0000926326-15-000018:notes:76]
Segment reporting change

[0000926326-15-000018:notes:77]
In the first quarter of 2015, we modified the segment presentation to reflect the changes in how our Chief Operating Decision Maker (“CODM”) reviews the segments and the overall business. With the increase in acquisitions in the last two years the CODM changed how the financial information was reviewed to exclude general corporate-level costs that are not specific to either of the reporting segments when evaluating the operating results of each segment. Corporate-level costs include expenses related to executive management, finance and accounting, human resources, legal, training and development, and certain administrative expenses.

[0000926326-15-000018:notes:78]
The historical information presented has been retrospectively adjusted to reflect the modified segment reporting. Our CODM allocates resources and evaluates the performance of our segments using information about its revenues, gross profit and income from operations, excluding certain costs which are managed separately at the corporate level. We enhanced our segment reporting structure to match our operating structure based on how our Chief Operating Decision Maker (“CODM”) views the business and allocates resources, beginning in the first quarter of 2015. Our CODM is our Chief Executive Officer. Retrospective adjustments of prior period financial information have been made to conform to the current period presentation. This change does not impact previously reported Condensed Consolidated Financial Statements. See Note 15, Segment Information, for additional information on our segment reporting change.

[0000926326-15-000018:notes:79]
Concentration of credit risk

[0000926326-15-000018:notes:80]
Financial instruments that may potentially subject us to concentrations of credit risk consist principally of cash equivalents and accounts receivable. Cash equivalents are maintained with several financial institutions and may exceed the amount of insurance provided on such balances. The majority of our accounts receivable are derived from sales to customers for commercial applications. We perform ongoing credit evaluations of our customers’ financial condition and limit the amount of credit extended when deemed necessary but generally require no collateral. We maintain reserves for potential credit losses. Our products are broadly distributed and there were no customers that accounted for more than 10% of our accounts receivable as of March 31, 2015 and December 31, 2014. We believe that we have no significant concentrations of credit risk as of March 31, 2015.

[0000926326-15-000018:notes:81]
Significant accounting policies

[0000926326-15-000018:notes:82]
There have been no material changes in our significant accounting policies for the three months ended March 31, 2015, as compared to the significant accounting policies described in our annual report on Form 10-K for the year ended December 31, 2014.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000926326-15-000018:notes:83]
[same as prior period, unchanged from 0000926326-14-000039:notes:109]

[0000926326-15-000018:notes:84]
Property and equipment consist of the following assets:

[0000926326-15-000018:notes:85]
|  | March 31, 2015 |  | December 31, 2014 |
|  | (In thousands) |
| Equipment | $ | 42,124 |  |  | $ | 42,829 |  |
| Furniture and fixtures | 5,712 |  |  | 5,689 |  |
| Leasehold improvements | 8,672 |  |  | 8,701 |  |
| Purchased software | 29,058 |  |  | 28,920 |  |
| Construction in progress | 3,366 |  |  | 1,538 |  |
|  | 88,932 |  |  | 87,677 |  |
| Accumulated depreciation and amortization | (54,559 | ) |  | (51,499 | ) |
| Total property and equipment, net | $ | 34,373 |  |  | $ | 36,178 |  |

[0000926326-15-000018:notes:86]
Depreciation and amortization of property and equipment was $3.1 million and $2.5 million for the three months ended March 31, 2015 and March 31, 2014, respectively.


## us-gaap:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTextBlock

[0000926326-15-000018:notes:87]
The following table sets forth the total share-based compensation expense recognized in our Condensed Consolidated Statements of Income:

[0000926326-15-000018:notes:88]
|  | Three Months Ended |
|  | March 31, 2015 |  | March 31, 2014 |
|  | (In thousands) |
| Cost of product and service revenues | $ | 517 |  |  | $ | 268 |  |
| Research and development | 434 |  |  | 369 |  |
| Selling, general and administrative | 2,714 |  |  | 2,092 |  |
| Total share-based compensation expense | $ | 3,665 |  |  | $ | 2,729 |  |


## us-gaap:ScheduleOfNonvestedRestrictedStockUnitsActivityTableTextBlock

[0000926326-15-000018:notes:89]
A summary of the restricted stock activity under the 2009 Plan is presented below:

[0000926326-15-000018:notes:90]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Restricted Stock Units |  |  |  |  |  |  |  |
| Outstanding at December 31, 2014 | 399 |  |  | $ | 24.00 |  |  | 1.5 |  |  |
| Granted | 44 |  |  | 33.97 |  |  |  |  |  |
| Vested | (26 | ) |  | 22.07 |  |  |  |  |  |
| Forfeited | (6 | ) |  | 21.73 |  |  |  |  |  |
| Outstanding and unvested at March 31, 2015 | 411 |  |  | $ | 25.21 |  |  | 1.4 |  | $ | 14,431 |  |
| Expected to vest at March 31, 2015 | 399 |  |  |  |  | 1.4 |  | $ | 13,997 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000926326-15-000018:notes:91]
The following table summarizes the financial performance of our reporting segments, including a reconciliation of income from segment operations to income from total operations:

[0000926326-15-000018:notes:92]
|  | Three Months Ended |
|  | March 31, 2015 |  | March 31, 2014 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |  | Automation andAnalytics |  | MedicationAdherence |  | Total |
|  | (In thousands) |
| Revenues | $ | 92,779 |  |  | $ | 23,442 |  |  | $ | 116,221 |  |  | $ | 81,499 |  |  | $ | 20,265 |  |  | $ | 101,764 |  |
| Cost of revenues | 38,852 |  |  | 15,684 |  |  | 54,536 |  |  | 34,940 |  |  | 12,329 |  |  | 47,269 |  |
| Gross profit | 53,927 |  |  | 7,758 |  |  | 61,685 |  |  | 46,559 |  |  | 7,936 |  |  | 54,495 |  |
| Operating expenses | 28,589 |  |  | 6,341 |  |  | 34,930 |  |  | 25,102 |  |  | 4,651 |  |  | 29,753 |  |
| Income from segment operations | $ | 25,338 |  |  | $ | 1,417 |  |  | $ | 26,755 |  |  | $ | 21,457 |  |  | $ | 3,285 |  |  | $ | 24,742 |  |
| Corporate costs |  |  |  |  | 16,376 |  |  |  |  |  |  | 14,788 |  |
| Income from operations |  |  |  |  | $ | 10,379 |  |  |  |  |  |  | $ | 9,954 |  |


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0000926326-15-000018:notes:93]
A summary of the stock option activity under the 2009 Plan is presented below:

[0000926326-15-000018:notes:94]
|  | Number ofShares |  | Weighted-AverageExercise Price |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value(1) |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2014 | 2,672 |  |  | $ | 19.02 |  |  | 6.5 |  |  |
| Granted | 151 |  |  | 33.73 |  |  |  |  |  |
| Exercised | (132 | ) |  | 15.69 |  |  |  |  |  |
| Expired | — |  |  | — |  |  |  |  |  |
| Forfeited | (16 | ) |  | 22.60 |  |  |  |  |  |
| Outstanding at March 31, 2015 | 2,675 |  |  | $ | 19.98 |  |  | 6.6 |  | $ | 40,442 |  |
| Exercisable at March 31, 2015 | 1,529 |  |  | $ | 16.11 |  |  | 5.0 |  | $ | 29,042 |  |
| Vested and expected to vest at March 31, 2015 | 2,643 |  |  | $ | 19.88 |  |  | 6.5 |  | $ | 40,234 |  |

[0000926326-15-000018:notes:95]
| (1) | Intrinsic value is calculated as the difference between the market value or closing price of our common stock as of the last trading day of the year as reported by the NASDAQ Global Select Market, and the exercise price of the option. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000926326-15-000018:notes:96]
Segment Information

[0000926326-15-000018:notes:97]
In the first quarter of 2014, we began to manage our business according to two product segments because many of our Acute Care and Non-Acute Care customers were converging to provide services across the continuum of care. We modified our segment reporting structure to match our operating structure based on how our CODM views the business and allocates resources. The two operating segments, which are the same as our reporting segments, are as follows:

[0000926326-15-000018:notes:98]
Automation and Analytics

[0000926326-15-000018:notes:99]
The Automation and Analytics segment is organized around the design, manufacturing, selling and servicing of medication and supply dispensing systems, pharmacy inventory management systems, and related software. Our Automation and Analytics products are designed to enable our customers to enhance and improve the effectiveness of the medication-use process, the efficiency of the medical-surgical supply chain, overall patient care and clinical and financial outcomes of medical facilities. Through modular configuration and upgrades, our systems can be tailored to specific customer needs.

[0000926326-15-000018:notes:100]
Medication Adherence

[0000926326-15-000018:notes:101]
The Medication Adherence segment includes primarily the manufacturing and selling of consumable medication blister cards, packaging equipment and ancillary products and services. These products are used to manage medication administration outside of the hospital setting and include medication adherence products sold under the brand name MTS Medication Technologies ("MTS"), Surgichem Limited ("Surgichem"), and under the Omnicell brand, and dispensing systems sold under the Omnicell brand. MTS products consist of proprietary medication packaging systems and related products for use by institutional pharmacies servicing long-term care, and correctional facilities or retail pharmacies serving patients in their local communities.

[0000926326-15-000018:notes:102]
In the first quarter of 2015, we modified the segment presentation to reflect the changes in how our CODM reviews the segments and the overall business. With the increase in acquisitions in the last two years the CODM changed how the financial information was reviewed to exclude corporate-level costs that are not specific to either of the reporting segments when evaluating the operating results of each segment. Corporate-level costs include expenses related to executive management, finance and accounting, human resources, legal, training and development, and certain administrative expenses.

[0000926326-15-000018:notes:103]
The historical information presented has been retrospectively adjusted to reflect the enhanced segment reporting. Our CODM allocates resources and evaluates the performance of our segments using information about its revenues, gross profit and income from operations, excluding certain costs which are managed separately at the corporate level. Except for goodwill, as discussed in Note 7, our assets are not discretely identified or allocated by segment.

[0000926326-15-000018:notes:104]
Significant customers

[0000926326-15-000018:notes:105]
There were no customers that accounted for more than 10% of our total revenues for the three months ended March 31, 2015 and March 31, 2014.


## us-gaap:ShareBasedCompensationPerformanceSharesAwardUnvestedActivityTableTextBlock

[0000926326-15-000018:notes:106]
A summary of the performance-based restricted stock activity under the 2009 Plan is presented below:

[0000926326-15-000018:notes:107]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value Per Unit |
|  | (In thousands, except per share data) |
| Unvested at December 31, 2014 | 233 |  |  | $ | 17.96 |  |
| Granted | 60 |  |  | 29.56 |  |
| Vested | (33 | ) |  | 21.26 |  |
| Cancelled | — |  |  | — |  |
| Unvested at March 31, 2015 | 260 |  |  | $ | 20.23 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000926326-15-000018:notes:108]
Employee Benefits and Share-Based Compensation

[0000926326-15-000018:notes:109]
Stock purchase plan

[0000926326-15-000018:notes:110]
1997 Employee Stock Purchase Plan

[0000926326-15-000018:notes:111]
We have an Employee Stock Purchase Plan ("ESPP"), under which employees can purchase shares of our common stock based on a percentage of their compensation, but not greater than 15% of their earnings; provided, however, an eligible employees' right to purchase shares of our common stock may not accrue at a rate which exceeds $25,000 of the fair market value of such shares for each calendar year in which such rights are outstanding. The purchase price per share must be equal to the lower of 85% of the fair value of the common stock at the beginning of a 24-month offering period or the end of each six-month purchasing period.

[0000926326-15-000018:notes:112]
At our 2009 Annual Meeting of Stockholders ("2009 Annual Meeting"), the stockholders approved an amendment to the ESPP, which added 2.6 million shares to the reserve for future issuance. There was a total of 0.4 million shares reserved for future issuance under the ESPP as of March 31, 2015. For the three months ended March 31, 2015, 0.2 million shares of common stock were purchased under the ESPP and an aggregate of 4.9 million shares were issued under the ESPP as of March 31, 2015.

[0000926326-15-000018:notes:113]
The unrecognized compensation cost related to the shares to be purchased under our ESPP was approximately $3.1 million, and is expected to be recognized over a weighted-average period of 0.7 years as of March 31, 2015.

[0000926326-15-000018:notes:114]
Stock award plans

[0000926326-15-000018:notes:115]
2009 Equity Incentive Plan

[0000926326-15-000018:notes:116]
There were 1.5 million shares of common stock reserved for future issuance under the 2009 Equity Incentive Plan, as amended (the "2009 Plan") as of March 31, 2015.

[0000926326-15-000018:notes:117]
Performance-based restricted stock units

[0000926326-15-000018:notes:118]
In 2011, we began incorporating performance-based restricted stock units ("PSUs") as an element of our executive compensation plans. In 2014, we granted 132,500 PSUs to our executive officers, all of which became eligible for vesting based on the achievement of a certain level of shareholder return for the period from January 1, 2014 through February 27, 2015. In 2015, we granted 60,000 PSUs to our executive officers, all, none or a portion of which may become eligible for vesting depending on the level of shareholder return for 2015 and eligible for further time-based vesting based on the ranking of our total shareholder return.

[0000926326-15-000018:notes:119]
On March 3, 2015, the Compensation Committee confirmed 74.4% as the percentile rank of our 2014 total stockholder return. This resulted in 100% of the 2014 PSUs, or 132,500 shares, as eligible for further time-based vesting. The eligible performance based restricted stock unit awards will vest as follows: 25% of the eligible shares vested immediately on March 3, 2015 with the remaining eligible awards vesting in equal increments, semi-annually, over the subsequent three-year period beginning on June 15th and December 15th of the year after the date of grant and each subsequent year. Vesting is contingent upon continued service. Of the 132,500 shares eligible for time-based vesting under the 2014 PSUs, 33,124 shares vested during the quarter ended March 31, 2015.

[0000926326-15-000018:notes:120]
On February 6, 2015, the Compensation Committee approved PSUs of 60,000 shares. If the minimum performance threshold is met as determined by the Compensation Committee in 2016, the eligible performance-based restricted stock unit awards will vest as follows: 25% of the eligible shares will vest immediately, with the remaining eligible awards vesting in equal increments, semi-annually, over the subsequent three year period beginning on June 15th and December 15th of the year after the date of grant and each subsequent year. Vesting is contingent upon continued service.

[0000926326-15-000018:notes:121]
Share-based compensation expense

[0000926326-15-000018:notes:122]
We account for share-based awards granted to employees and directors, including employee stock option awards, restricted stock, PSUs and RSUs issued pursuant to the 2009 Plan and employee stock purchases made under our ESPP using the estimate grant date fair value method of accounting in accordance with ASC 718, Stock Compensation. We value options and ESPP shares using the Black-Scholes-Merton option-pricing model. Restricted stock and time-based RSUs are valued at the grant date fair value of the underlying common shares. The PSUs are valued using the Monte Carlo simulation model.

[0000926326-15-000018:notes:123]
Stock options activity

[0000926326-15-000018:notes:124]
The weighted-average fair value per share of options granted during the three months ended March 31, 2015 and March 31, 2014 was $9.82 and $8.29, respectively. The intrinsic value of options exercised during the three months ended March 31, 2015 and March 31, 2014 was $2.4 million and $5.3 million, respectively.

[0000926326-15-000018:notes:125]
As of March 31, 2015, total unrecognized compensation cost related to unvested stock options was $9.2 million, which is expected to be recognized over a weighted-average vesting period of 2.8 years.

[0000926326-15-000018:notes:126]
Restricted stock activity

[0000926326-15-000018:notes:127]
The weighted-average grant date fair value per share of RSUs granted during the three months ended March 31, 2015 and March 31, 2014 was $33.97 and $25.54, respectively. The total fair value of RSUs that vested during the three months ended March 31, 2015 and March 31, 2014 was $0.9 million and $0.9 million, respectively.

[0000926326-15-000018:notes:128]
As of March 31, 2015, total unrecognized compensation expense related to RSUs was $9.0 million, which is expected to be recognized over the remaining weighted-average vesting period of 2.5 years.

[0000926326-15-000018:notes:129]
No RSAs were granted nor vested during the three months ended March 31, 2015 and March 31, 2014.

[0000926326-15-000018:notes:130]
As of March 31, 2015, total unrecognized compensation cost related to RSAs was $0.1 million, which is expected to be recognized over the remaining weighted-average vesting period of 0.2 years.

[0000926326-15-000018:notes:131]
Performance-based restricted stock units activity

[0000926326-15-000018:notes:132]
The weighted-average grant date fair value per share of PSUs granted during the three months ended March 31, 2015 and March 31, 2014 was $29.56 and $16.59, respectively. The total fair value of PSUs that vested during the three months ended March 31, 2015 and March 31, 2014 was $1.2 million and $1.0 million, respectively.

[0000926326-15-000018:notes:133]
As of March 31, 2015, total unrecognized compensation cost related to PSUs was approximately $3.1 million, which is expected to be recognized over the remaining weighted-average period of 1.3 years.

[0000926326-15-000018:notes:134]
Preferred Stock

[0000926326-15-000018:notes:135]
There were 5.0 million preferred shares authorized, and no preferred shares issued or outstanding as of March 31, 2015 and December 31, 2014.


## us-gaap:SubsequentEventsTextBlock

[0000926326-15-000018:notes:136]
Subsequent Events

[0000926326-15-000018:notes:137]
On April 21, 2015, Omnicell International, Inc. (“Omnicell International”), a wholly-owned subsidiary of Omnicell, Inc., completed its acquisition of Mach 4 Automatisierungstechnik GmbH (“Mach4”) pursuant to the Agreement, dated February 26, 2015, by and among Apotheka Imedisa 2001 S.A., Holger Wallat, Dirk Rolf Beils and Peter Jansen (collectively, the “Selling Shareholders”) and Omnicell International (the “Share Purchase Agreement”). Pursuant to the Share Purchase Agreement, Omnicell International purchased the entire registered share capital of Mach4 from the Selling Shareholders for aggregate consideration of approximately $16.5 million, of which $2.7 million was placed in an escrow fund, which will ultimately be distributed to the Selling Shareholders (subject to claims that Omnicell International may have against the escrow fund for indemnification and other claims following the closing) (the “Acquisition”). In addition, Omnicell International will pay approximately $0.9 million to Mach4 for the payoff of existing debt of Mach4. The final purchase price remains subject to certain adjustments as provided for in the Share Purchase Agreement.

[0000926326-15-000018:notes:138]
On April 30, 2015, we closed our acquisition of Avantec Healthcare Limited (“Avantec”) pursuant to  a share purchase agreement (the “Avantec Share Purchase Agreement”) among Omnicell, Inc. and the selling shareholders thereto (the “Avantec Selling Shareholders”) for the purchase of the entire issued share capital of Avantec not already owned by Omnicell, Inc. We previously owned 15% of the company and accounted for it under the equity method. Avantec develops medication and supply automation products that complement our solutions for configurations suited to the United Kingdom marketplace, and has been the exclusive distributor of our medication and supply automation solutions since 2005 in the United Kingdom. As a result of the Acquisition, we paid the Avantec Selling Shareholders an amount equal to $10.2 million in cash, subject to certain adjustments provided for in the Avantec Share Purchase Agreement, and retained an additional $1.8 million of the purchase price which will ultimately be distributed to the Avantec Selling Shareholders (subject to claims that we may have against such funds for indemnification and other claims following the closing). In addition, the Avantec Selling Shareholders will be entitled to receive up to an additional $3.0 million upon the achievement of bookings milestones for 2015 and an additional $3.0 million upon the achievement of bookings milestones for 2016.

[0000926326-15-000018:notes:139]
Both of these acquired companies will be in our Automation and Analytics segment. The valuations and related purchase price allocations for these acquisitions have not yet been completed.


## us-gaap:TreasuryStockTextBlock

[0000926326-15-000018:notes:140]
Stock Repurchases

[0000926326-15-000018:notes:141]
During the three months ended March 31, 2015, we did not repurchase any shares under our stock repurchase programs.

[0000926326-15-000018:notes:142]
In August 2012, our Board of Directors authorized a program to repurchase up to $50.0 million of common stock, of which approximately $45.1 million had been repurchased as of March 31, 2015. In November 2014, our Board of Directors authorized a program to repurchase up to $50.0 million of common stock. We expect to begin repurchasing shares under the 2014 Stock Repurchase Program upon the completion of the 2012 Stock Repurchase Program. Our stock repurchase programs have a total of $54.9 million remaining for future repurchases as of March 31, 2015, and neither program has an expiration date.
