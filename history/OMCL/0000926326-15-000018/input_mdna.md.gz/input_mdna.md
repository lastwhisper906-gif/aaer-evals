# OMCL MD&A — 0000926326-15-000018


## mdna

[0000926326-15-000018:mdna:1]
ITEM 2. MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0000926326-15-000018:mdna:2]
FORWARD-LOOKING STATEMENTS AND FACTORS THAT MAY AFFECT FUTURE RESULTS

[0000926326-15-000018:mdna:3]
This quarterly report on Form 10-Q contains forward-looking statements. The forward-looking statements are contained principally in the sections entitled “Risk Factors” and “Management's Discussion and Analysis of Financial Condition and Results of Operations.” These statements involve known and unknown risks, uncertainties and other factors which may cause our actual results, performance or achievements to be materially different from any future results, performances or achievements expressed or implied by the forward-looking statements. Forward-looking statements include, but are not limited to, statements about:

[0000926326-15-000018:mdna:4]
| • | our expectations regarding our future product bookings, which consist of all firm orders, as evidenced by a contract and purchase order for equipment and software and, generally, by a purchase order for consumables. Equipment and software bookings are installable within 12 months and consumables are generally recorded as revenue within one month; |

[0000926326-15-000018:mdna:5]
| • | the extent and timing of future revenues, including the amounts of our current backlog, which represents firm orders that have not completed installation and therefore have not been recognized as revenue; |

[0000926326-15-000018:mdna:6]
[same as prior period, unchanged from 0000926326-14-000039:mdna:6]

[0000926326-15-000018:mdna:7]
| • | the opportunity presented by new products, emerging markets and international markets; |

[0000926326-15-000018:mdna:8]
[same as prior period, unchanged from 0000926326-14-000039:mdna:8]

[0000926326-15-000018:mdna:9]
[same as prior period, unchanged from 0000926326-14-000039:mdna:9]

[0000926326-15-000018:mdna:10]
[same as prior period, unchanged from 0000926326-14-000039:mdna:10]

[0000926326-15-000018:mdna:11]
[same as prior period, unchanged from 0000926326-14-000039:mdna:11]

[0000926326-15-000018:mdna:12]
[same as prior period, unchanged from 0000926326-14-000039:mdna:12]

[0000926326-15-000018:mdna:13]
In some cases, you can identify forward-looking statements by terms such as "anticipates," "believes," "could," "estimates," "expects," "intends," "may," "plans," "potential," "predicts," "projects," "should," "will," "would" and similar expressions intended to identify forward-looking statements. Forward-looking statements reflect our current views with respect to future events, are based on assumptions and are subject to risks and uncertainties.  We discuss many of these risks in this quarterly report in greater detail in Part II - Section 1A. “Risk Factors” below. Given these uncertainties, you should not place undue reliance on these forward-looking statements. Also, forward-looking statements represent our estimates and assumptions only as of the date of this quarterly report. You should also read this quarterly report and the documents that we reference in this quarterly report and have filed as exhibits, completely and with the understanding that our actual future results may be materially different from what we expect.  All references in this report to "Omnicell," "our," "us," "we," or the "Company" collectively refer to Omnicell, Inc., a Delaware corporation, and its subsidiaries. The term "Omnicell, Inc.," refers only to Omnicell, Inc., excluding its subsidiaries.

[0000926326-15-000018:mdna:14]
OVERVIEW

[0000926326-15-000018:mdna:15]
Our Business

[0000926326-15-000018:mdna:16]
We are a leading provider of comprehensive automation and business analytics software solutions for patient-centric medication and supply management across the entire healthcare continuum, from the acute care hospital setting to post-acute skilled nursing and long-term care facilities to the home. Our Omnicell Automation and Analytic customers worldwide utilize our medication automation, supply chain and analytics solutions to help enable them to increase operational efficiency, reduce errors, deliver actionable intelligence and improve patient safety.

[0000926326-15-000018:mdna:17]
Omnicell Medication Adherence solutions, including the MTS and Surgichem brands, provide innovative medication adherence packaging solutions that can help reduce costly hospital readmissions and enable institutional and retail pharmacies worldwide to maintain high accuracy and quality standards in medication dispensing and administration while optimizing productivity and controlling costs.

[0000926326-15-000018:mdna:18]
We sell our product and consumable solutions together with related service offerings. Revenue generated in the United States represented 84% of our total revenues for the three months ended March 31, 2015, and we expect our revenues from international operations to increase in future periods as we continue to grow our international business. We have not sold in the past, and have no future plans to sell our products either directly or indirectly, to customers located in countries that are identified as state sponsors of terrorism by the U.S. Department of State, and are subject to economic sanctions and export controls.

[0000926326-15-000018:mdna:19]
Operating Segments

[0000926326-15-000018:mdna:20]
Since the first quarter of 2014, we have managed our business according to two product segments, Automation and Analytics and Medication Adherence.

[0000926326-15-000018:mdna:21]
Automation and Analytics

[0000926326-15-000018:mdna:22]
The Automation and Analytics segment is organized around the design, manufacturing, selling and servicing of medication and supply dispensing systems, pharmacy inventory management systems, and related software. Our Automation and Analytics products are designed to enable our customers to enhance and improve the effectiveness of the medication-use process, the efficiency of the medical-surgical supply chain, overall patient care and clinical and financial outcomes of medical facilities. Through modular configuration and upgrades, our systems can be tailored to specific customer needs.

[0000926326-15-000018:mdna:23]
Medication Adherence

[0000926326-15-000018:mdna:24]
The Medication Adherence segment primarily includes the manufacturing and selling of consumable medication blister cards, packaging equipment and ancillary products and services. These products are used to manage medication administration outside of the hospital setting and include medication adherence products sold under the brand name MTS, Surgichem and the Omnicell brand. MTS products consist of proprietary medication packaging systems and related products for use by institutional pharmacies servicing long-term care, and correctional facilities or retail pharmacies serving patients in their local communities. Similarly, Surgichem is a provider of medication adherence packaging systems and solutions to the United Kingdom community and home care markets.

[0000926326-15-000018:mdna:25]
Strategy

[0000926326-15-000018:mdna:26]
The healthcare market is experiencing a period of substantive change. The adoption of electronic healthcare records, new regulatory constraints, and changes in the reimbursement structure have caused healthcare institutions to re-examine their operating structures, re-prioritize their investments, and seek efficiencies. We believe our customers’ evolving operating environment creates challenges for any supplier, but also affords opportunities for suppliers that are able to partner with customers to help them meet the changing demands. We have and intend to continue to invest in the strategies which we believe have generated and will continue to generate our revenue and earnings growth, while supporting our customers’ initiatives and needs. These strategies include:

[0000926326-15-000018:mdna:27]
| • | Development of differentiated products. We invest in the development of products that we believe bring patient safety and workflow efficiency to our customers’ operations that they cannot get from other competing solutions. These differentiators may be as small as how a transaction operates or information provided on a report or as large as the entire automation of a workflow that would otherwise be completed manually. We intend to continue our focus on differentiating our products, and we carefully assess our investments regularly as we strive to ensure those investments provide the solutions most valuable to our customers. |

[0000926326-15-000018:mdna:28]
| • | Deliver our solutions to new markets. Areas of healthcare where work is done manually may benefit from our existing solutions. These areas include hospitals that continue to utilize manual operations, healthcare segments of the U.S. market outside hospitals and markets outside the United States. We weigh the cost of entering these new markets against the expected benefits and focus on the markets that we believe are most likely to adopt our products. |

[0000926326-15-000018:mdna:29]
| • | Expansion of our solutions through acquisitions and partnerships. Our acquisitions have generally been focused on automation of manual workflows or data analytics, which is the enhancement of data for our customers’ decision-making processes. We believe that expansion of our product lines through acquisition and partnerships to meet our customers changing and evolving expectations is a key component to our historical and future success. |

[0000926326-15-000018:mdna:30]
Our investments have been consistent with the strategies outlined above. To differentiate our solutions from others available in the market, we began shipping a refresh of our product line in 2011, which we market as G4. The G4 refresh

[0000926326-15-000018:mdna:31]
included multiple new products and an upgrade product that allowed existing customers to augment their installations to obtain the most current technology that we provide. The G4 product refresh has been a key contributor to our growth, with 65% of our automation and analytics installed base ordering upgrades to their existing systems since the announcement of G4. In addition to enhanced capabilities, we have focused on attaining the highest quality and service measurements for G4 in the industry, while marketing the solution to new and existing customers. Our research and development efforts today are designed to bring new products to market beyond the G4 product line that we believe will meet customer needs in years to come.

[0000926326-15-000018:mdna:32]
Consistent with our strategy to enter new markets, we have made investments in our selling, general and administrative expenses to expand our sales team and market to new customers. Our international efforts have focused primarily on four markets: the United Kingdom where we sell medication adherence products through a direct sales team and automation and analytics products through a distributor, Germany where we sell medication adherence products through a direct sales team, Middle Eastern countries of the Arabian Peninsula where new healthcare facility construction is taking place, and in China, where we launched a Mandarin version of our automated dispensing systems in 2011. In the third quarter of 2012, we purchased 15% of the outstanding equity of Avantec Healthcare Limited ("Avantec"), our United Kingdom automation and analytics products distributor, for approximately $0.9 million in cash to accelerate the adoption of medication and supply automation. In connection with the investment, we have the right, under certain circumstances, to appoint a member to this company's board of directors as well as certain other voting rights and, therefore, we believe we have the ability to exert significant influence over this distributor's operations. Subsequent to March 31, 2015, we acquired the entire issued share capital of Avantec not already owned by the Company. Our proportionate equity share of the income of this distributor, recognized in interest and other income, net, was immaterial for the three months ended March 31, 2015. We have also expanded our sales efforts to medication adherence customers in the United States which has allowed us to sell our automated dispensing solutions and other products to this market.

[0000926326-15-000018:mdna:33]
Expansion of our solutions through acquisitions and partnerships include our acquisition of MTS in 2012, our acquisition of Surgichem in August 2014 and our acquisitions of Mach 4 Automatisierungstechnik GmbH (“Mach4”) and Avantec in April 2015. Surgichem is a provider of medication adherence products in the United Kingdom. Mach4 is a provider of automated medication management systems to retail and hospital pharmacy customers primarily in Europe, with additional installations in China, the Middle East and Latin America. Avantec develops medication and supply automation products that complement our solutions for configurations suited to the United Kingdom marketplace, and has been the exclusive United Kingdom distributor for our medication and supply automation solutions since 2005. We have also developed relationships with major providers of hospital information management systems with the goal of enhancing the interoperability of our products with their systems. We believe that enhanced interoperability will help reduce implementation costs, time, and maintenance for shared clients, while providing new clinical workflows designed to enhance efficiency and patient safety.

[0000926326-15-000018:mdna:34]
[same as prior period, unchanged from 0000926326-14-000039:mdna:29]

[0000926326-15-000018:mdna:35]
| • | Our expectation that the overall market demand for healthcare services will increase as the population grows, life expectancies continue to increase and the quality and availability of healthcare services increases; |

[0000926326-15-000018:mdna:36]
| • | Our expectation that the environment of increased patient safety awareness, increased regulatory control, increased demand for innovative products that improve the care experience and increased need for workflow efficiency through the adoption of technology in the healthcare industry will make our solutions a priority in the capital budgets of healthcare facilities; and |

[0000926326-15-000018:mdna:37]
[same as prior period, unchanged from 0000926326-14-000039:mdna:32]

[0000926326-15-000018:mdna:38]
Among other financial measures, we utilize product bookings to assess the current success of our strategies. Product bookings consist of all firm orders, as evidenced by a contract and purchase order for equipment and software, and by a purchase order for consumables. Equipment and software bookings are installable within twelve months and generally recorded as revenue upon customer acceptance of the installation. Consumables are recorded as revenue upon shipment to a customer or receipt by the customer, depending upon contract terms. Consumable bookings are generally recorded as revenue within one month.

[0000926326-15-000018:mdna:39]
In addition to product solution sales, we provide services to our customers. Our healthcare customers expect a high degree of partnership involvement from their technology suppliers throughout their ownership of the products. We provide extensive installation planning and consulting as part of every product sale and included in the initial price of the solution. Our customers' medication control systems are mission critical to their success and our customers require these systems to be functional at all times. To help assure the maximum availability of our systems, our customers typically purchase maintenance and support contracts in one, two or five year increments.  As a result of the growth of our installed base of customers, our

[0000926326-15-000018:mdna:40]
service revenues have also grown. We strive to provide the best service possible, as measured by third-party rating agencies and by our own surveys, to assure our customers continue to seek service maintenance from us. Our liabilities include current and long-term deferred service revenue of $43.1 million and $45.5 million as of March 31, 2015 and December 31, 2014, respectively. Our deferred service revenue will be amortized to service revenue as the service contracts are executed.

[0000926326-15-000018:mdna:41]
The growth in our Automation and Analytics revenue for the three months ended March 31, 2015 was driven primarily by our success in consistently growing the number of our customer installations. Installed customers in the United States grew from 1,806 hospitals as of March 31, 2014 to 1,955 hospitals as of March 31, 2015. To a lesser extent, but of equal importance, revenue growth was also driven by our success in upgrading installed customers to newer G4 technology, which is in line with our strategy of striving to deliver differentiated innovation in our solutions. Our larger installed base has provided growth opportunities for follow on sales and increased service contracts and, as a result, our service revenues have also grown for the three months ended March 31, 2015.

[0000926326-15-000018:mdna:42]
The growth in our Medication Adherence revenue was driven primarily by increased adoption of multi-medication adherence solutions used by patients in assisted living or home care in Europe for the three months ended March 31, 2015. This growth is in line with our strategy to deliver solutions to markets outside the United States. On a geographic basis, the United States market did not contribute to, nor erode, the growth in our Medication Adherence business as the population of patients living in nursing homes in the United States has remained relatively constant over the past year.

[0000926326-15-000018:mdna:43]
In the future, we expect our strategies to evolve as the business environment of our customers evolves, but for our focus to remain on improving healthcare with solutions that help change the practices in ways that improve patient and provider outcomes. We expect our investment in differentiated products, new markets, and acquisitions and partnerships to continue. In 2015, we also intend to manage our business to operating profit margins similar to those achieved in 2014.

[0000926326-15-000018:mdna:44]
CRITICAL ACCOUNTING POLICIES AND ESTIMATES

[0000926326-15-000018:mdna:45]
Our discussion and analysis of our financial condition and results of operations are based on our Condensed Consolidated Financial Statements, which have been prepared in accordance with U.S. GAAP. The preparation of these financial statements requires us to make certain estimates and assumptions that affect the reported amounts of assets and liabilities, disclosure of any contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. We regularly review our estimates and assumptions, which are based on historical experience and various other factors that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of certain assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates and assumptions. We believe the following critical accounting policies are affected by significant judgments and estimates used in the preparation of our Condensed Consolidated Financial Statements:

[0000926326-15-000018:mdna:46]
| • | Revenue recognition; |

[0000926326-15-000018:mdna:47]
| • | Accounts receivable and notes receivable (net investment in sales-type leases); |

[0000926326-15-000018:mdna:48]
| • | Valuation and impairment of goodwill, intangible assets and other long-lived assets; |

[0000926326-15-000018:mdna:49]
| • | Excess and obsolete inventory reserve; |

[0000926326-15-000018:mdna:50]
| • | Valuation of share-based awards; and |

[0000926326-15-000018:mdna:51]
| • | Accounting for income taxes. |

[0000926326-15-000018:mdna:52]
There have been no material changes in the matters for which we make critical accounting estimates in the preparation of our Condensed Consolidated Financial Statements during the three months ended March 31, 2015 as compared to those disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our annual report on Form 10-K for the year ended December 31, 2014.

[0000926326-15-000018:mdna:53]
Recently issued authoritative guidance

[0000926326-15-000018:mdna:54]
Refer to Note 1, Summary of Significant Accounting Policies, of the Notes to Condensed Consolidated Financial Statements in this quarterly report for a description of recently issued accounting pronouncements, including the expected dates of adoption and estimated effects on our results of operations, financial positions and cash flows.

[0000926326-15-000018:mdna:55]
RESULTS OF OPERATIONS

[0000926326-15-000018:mdna:56]
Total Revenues

[0000926326-15-000018:mdna:57]
|  | Three Months Ended |
|  |  |  | Change in |  |  |
|  | March 31, 2015 |  | $ |  | % |  | March 31, 2014 |
|  | (Dollars in thousands) |
| Product revenues | $ | 94,109 |  |  | $ | 11,529 |  |  | 14 | % |  | $ | 82,580 |  |
| Percentage of total revenues | 81 | % |  |  |  |  |  | 81 | % |
| Service and other revenues | 22,112 |  |  | 2,928 |  |  | 15 | % |  | 19,184 |  |
| Percentage of total revenues | 19 | % |  |  |  |  |  | 19 | % |
| Total revenues | $ | 116,221 |  |  | $ | 14,457 |  |  | 14 | % |  | $ | 101,764 |  |

[0000926326-15-000018:mdna:58]
Product revenues represented 81% of total revenues for both the three months ended March 31, 2015 and March 31, 2014. Product revenues increased due to increased sales for both our Automation and Analytics segment of $8.4 million and Medication Adherence segment of $3.1million. Service and other revenues represented 19% of total revenues for both the three months ended March 31, 2015 and March 31, 2014. Service and other revenues include revenues from service and maintenance contracts and rentals of automation systems. Service and other revenues primarily increased due to an increase from our Automation and Analytics segment of $2.9 million.

[0000926326-15-000018:mdna:59]
Our international sales represented 16% and 8% of total revenues for the three months ended March 31, 2015 and March 31, 2014, respectively, and are expected to be affected by foreign currency exchange rates fluctuations. We are unable to predict the extent to which revenue in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-15-000018:mdna:60]
We anticipate our revenues will continue to increase in 2015 compared to the same periods in 2014, as we fulfill our existing orders, and based on our growth in bookings in 2014, some of which will be recognized as revenue in 2015. Our ability to continue to grow revenue is dependent on our ability to continue to obtain orders from customers, our ability to produce quality consumables to fulfill customer demand, the volume of installations we are able to complete, our ability to meet customer needs by providing a quality installation experience, and our flexibility in manpower allocations among customers to complete installations on a timely basis. The timing of our product revenues for equipment is primarily dependent on when our customers’ schedules allow for installations.

[0000926326-15-000018:mdna:61]
Financial Information by Segment

[0000926326-15-000018:mdna:62]
Revenues

[0000926326-15-000018:mdna:63]
|  | Three Months Ended |
|  |  |  | Change in |  |  |
|  | March 31, 2015 |  | $ |  | % |  | March 31, 2014 |
| Revenues: | (Dollars in thousands) |
| Automation and Analytics | $ | 92,779 |  |  | $ | 11,280 |  |  | 14 | % |  | $ | 81,499 |  |
| Percentage of total revenues | 80 | % |  |  |  |  |  | 80 | % |
| Medication Adherence | 23,442 |  |  | 3,177 |  |  | 16 | % |  | 20,265 |  |
| Percentage of total revenues | 20 | % |  |  |  |  |  | 20 | % |
| Total revenues | $ | 116,221 |  |  | $ | 14,457 |  |  | 14 | % |  | $ | 101,764 |  |

[0000926326-15-000018:mdna:64]
Automation and Analytics revenues increased due to an increase in product revenues of $8.4 million primarily due to the increase of $6.2 million in Automation Dispensing Cabinets and related software sales, and $2.4 million in all other product lines.  Service and other revenues increased by $2.9 million due to higher service renewal fees driven primarily by an increase in installed customer base.

[0000926326-15-000018:mdna:65]
Medication Adherence revenues increased due to an increase in product revenues of $3.2 million primarily driven by the inclusion of Surgichem operations since its acquisition in August 2014. Service and other revenues remained relatively flat compared to the prior year.

[0000926326-15-000018:mdna:66]
26

[0000926326-15-000018:mdna:67]
Cost of Revenues and Gross Profit

[0000926326-15-000018:mdna:68]
|  | Three Months Ended |
|  |  |  | Change in |  |  |
|  | March 31, 2015 |  | $ |  | % |  | March 31, 2014 |
| Cost of revenues: | (Dollars in thousands) |
| Automation and Analytics | $ | 38,852 |  |  | $ | 3,912 |  |  | 11 | % |  | $ | 34,940 |  |
| As a percentage of related revenues | 42 | % |  |  |  |  |  | 43 | % |
| Medication Adherence | 15,684 |  |  | 3,355 |  |  | 27 | % |  | 12,329 |  |
| As a percentage of related revenues | 67 | % |  |  |  |  |  | 61 | % |
| Total cost of revenues | $ | 54,536 |  |  | $ | 7,267 |  |  | 15 | % |  | $ | 47,269 |  |
| As a percentage of total revenues | 47 | % |  |  |  |  |  | 46 | % |
| Gross profit: |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 53,927 |  |  | $ | 7,368 |  |  | 16 | % |  | $ | 46,559 |  |
| Automation and Analytics gross margin | 58 | % |  |  |  |  |  | 57 | % |
| Medication Adherence | 7,758 |  |  | (178 | ) |  | (2 | )% |  | 7,936 |  |
| Medication Adherence gross margin | 33 | % |  |  |  |  |  | 39 | % |
| Total gross profit | $ | 61,685 |  |  | $ | 7,190 |  |  | 13 | % |  | $ | 54,495 |  |
| Total gross margin | 53 | % |  |  |  |  |  | 54 | % |

[0000926326-15-000018:mdna:69]
Cost of revenues is primarily comprised of three general categories: (i) standard product costs which accounts for the majority of the product cost of revenues that are provided to customers, and are inclusive of purchased material, labor to build the product and overhead costs associated with production; (ii) installation costs as we install our equipment at the customer site, and include costs of the field installation personnel, including labor, travel expense, and other expenses; and (iii) other costs including variances in standard costs and overhead, scrap costs, rework, warranty, provisions for excess and obsolete inventory and amortization of software development costs.

[0000926326-15-000018:mdna:70]
Automation and Analytics

[0000926326-15-000018:mdna:71]
Cost of revenues increased by $3.9 million, $3.4 million of which was attributable to product costs and $0.5 million attributable to service costs. Both increases were a result of higher volume of revenue. Of the $3.4 million increase in product costs, $1.8 million is attributed to a different mixture of customers, products and overall growth in product sales, $0.9 million is attributable to more product installation costs associated with higher revenue, and $0.6 million is in other costs, primarily driven by software amortization. Cost of service revenues increased by $0.5 million due to an increase in support headcount to service a larger installed base, in addition to an increase in expenses related to the refurbishment of returned materials.

[0000926326-15-000018:mdna:72]
Gross profit increased due to an increase in product and service revenues while gross margin remained consistent as cost of sales as a percentage of revenues remained consistent with the prior year.

[0000926326-15-000018:mdna:73]
Medication Adherence

[0000926326-15-000018:mdna:74]
Cost of revenues increased by $3.1 million in product costs and $0.3 million in service costs. Product costs increased due to higher levels of revenue and due to higher production scrap rates and higher overtime. Cost of service sales increased by $0.3 million due to the seasonality of some expenses.

[0000926326-15-000018:mdna:75]
Gross profit decreased due to production inefficiencies and the inclusion of Surgichem operations, and gross margin slightly decreased as cost of sales as a percentage of revenues slightly increased driven by higher product costs.

[0000926326-15-000018:mdna:76]
We do not anticipate any significant fluctuations in gross profit and gross margin beyond normal fluctuations caused by changes in product mix for our Automation and Analytics and Medication Adherence segments during 2015.

[0000926326-15-000018:mdna:77]
27

[0000926326-15-000018:mdna:78]
Operating Expenses and Income from Operations

[0000926326-15-000018:mdna:79]
|  | Three Months Ended |
|  |  |  | Change in |  |  |
|  | March 31, 2015 |  | $ |  | % |  | March 31, 2014 |
| Operating expenses: | (Dollars in thousands) |
| Research and development | $ | 8,019 |  |  | $ | 1,898 |  |  | 31 | % |  | $ | 6,121 |  |
| As a percentage of total revenues | 7 | % |  |  |  |  |  | 6 | % |
| Selling, general and administrative | 43,287 |  |  | 4,867 |  |  | 13 | % |  | 38,420 |  |
| As a percentage of total revenues | 37 | % |  |  |  |  |  | 38 | % |
| Total operating expenses | $ | 51,306 |  |  | $ | 6,765 |  |  | 15 | % |  | $ | 44,541 |  |
| As a percentage of total revenues | 44 | % |  |  |  |  |  | 44 | % |
| Income from operations: |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 25,338 |  |  | $ | 3,881 |  |  | 18 | % |  | $ | 21,457 |  |
| Operating margin | 27 | % |  |  |  |  |  | 26 | % |
| Medication Adherence | 1,417 |  |  | (1,868 | ) |  | (57 | )% |  | 3,285 |  |
| Operating margin | 6 | % |  |  |  |  |  | 17 | % |
| Corporate Expenses | 16,376 |  |  | $ | 1,588 |  |  | 11 | % |  | 14,788 |  |
| Total income from operations | $ | 10,379 |  |  | $ | 425 |  |  | 8 | % |  | $ | 9,954 |  |
| Total operating margin | 9 | % |  |  |  |  |  | 10 | % |

[0000926326-15-000018:mdna:80]
The increase in research and development expenses in our Automation and Analytics and Medication Adherence segments was primarily attributable to a $0.8 million increase in head-count and personnel related costs, a $0.5 million increase in consulting expenses and a $0.3 million increase in prototype expenses. In our Medication Adherence segment, research and development increased primarily due to increased consulting in support of product software enhancements of $0.3 million.

[0000926326-15-000018:mdna:81]
We expect research and development expenses to increase in 2015 as we continue to invest in new products and services, and increase as a percentage of total revenues from approximately 6% in 2014 to approximately 8% in 2015. The amount of research and development expenses can fluctuate based on the amount of prototype expenses for hardware and/or the amount of capitalized software development costs.

[0000926326-15-000018:mdna:82]
Selling, general and administrative expenses increased due to increases from our Automation and Analytics segment of $1.9 million, from our Medication Adherence segment of $1.4 million. The increase from our Automation and Analytics segment was primarily attributable to increased headcount in marketing adding $0.3 million and increased headcount in sales adding $1.6 million. The increase from our Medication Adherence segment was the result of $0.3 million from the inclusion of Surgichem operations, with the remainder incurred from clinical studies and an increase in headcount specifically within our marketing and international businesses. The increase in corporate expenses was primarily related to the investigation of a whistleblower claim of $1.2 million with the remainder to support the growing business.

[0000926326-15-000018:mdna:83]
We anticipate selling, general and administrative expenses as a percentage of total revenues to be stable throughout 2015; however this estimate could be impacted by ongoing business development activities and external macro-economic factors.

[0000926326-15-000018:mdna:84]
Operating income from our Automation and Analytics segment increased due to an increase in product and service revenues while operating margin increased as a result of lower cost of sales and operating expenses compared to the overall growth of revenues.

[0000926326-15-000018:mdna:85]
Operating income from our Medication Adherence segment decreased due to production inefficiencies and higher operating expenses.

[0000926326-15-000018:mdna:86]
[same as prior period, unchanged from 0000926326-14-000039:mdna:110]

[0000926326-15-000018:mdna:87]
|  | Three Months Ended |
|  |  |  | Change in |  |  |
|  | March 31, 2015 |  | $ |  | % |  | March 31, 2014 |
|  | (Dollars in thousands) |
| Provision for income taxes | $ | 3,544 |  |  | $ | 40 |  |  | 1 | % |  | $ | 3,504 |  |
| Effective tax rate on earnings | 39 | % |  |  |  |  |  | 39 | % |

[0000926326-15-000018:mdna:88]
Our annual effective tax rate before discrete items was 38.6% and 39.1% for the three months ended March 31, 2015 and March 31, 2014, respectively.

[0000926326-15-000018:mdna:89]
The decrease in the estimated annual effective tax rate for the three months ended March 31, 2015 compared to the same period in 2014 was primarily due to the decrease in the state effective tax rate, offset by an increase in non-deductible equity charges.

[0000926326-15-000018:mdna:90]
LIQUIDITY AND CAPITAL RESOURCES

[0000926326-15-000018:mdna:91]
Sources of Cash

[0000926326-15-000018:mdna:92]
We entered into a Credit Agreement with Wells Fargo Bank, National Association, as administrative agent, and the lenders from time to time which provides for a $75 million revolving credit facility to be used for general corporate purposes, including future acquisitions. The Credit Agreement permits us to request one or more increases in the aggregate commitment provided such increases do not exceed $25 million in the aggregate.

[0000926326-15-000018:mdna:93]
On November 5, 2014, we entered into Amendment Number One (the “Amendment”) to the Credit Agreement. The Amendment increases the amount of our common stock that may be repurchased by us in open market transactions authorized by our Board of Directors, together with any repurchases of our common stock from any consultants, employees, officers or directors of the Company or any of our subsidiaries following the death, disability, retirement or termination of employment of such employees, officers or directors, from $25 million to $50 million per year. The Credit Agreement contains customary affirmative and negative covenants, and financial covenants that require us to, among other things, maintain a maximum consolidated total leverage ratio and a minimum consolidated fixed charge coverage ratio, in each case, as of the last day of each quarter. For additional details, please refer to Note 16, Credit Agreement, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report.

[0000926326-15-000018:mdna:94]
As of March 31, 2015, we were in full compliance with all covenants, and there was no outstanding balance on the credit facility.

[0000926326-15-000018:mdna:95]
Uses of Cash

[0000926326-15-000018:mdna:96]
Our future uses of cash are expected to be primarily for working capital, capital expenditures and other contractual obligations. We also expect a continued use of cash for potential acquisition and acquisition assessment activities.

[0000926326-15-000018:mdna:97]
Our stock repurchase programs have a total of $54.9 million remaining for future repurchases as of March 31, 2015, which may result in additional use of cash. See Note 13, Stock Repurchases, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report. We had cash and cash equivalents of $136.5 million and $125.9 million as of March 31, 2015 and December 31, 2014, respectively.

[0000926326-15-000018:mdna:98]
Based on our current business plan and revenue backlog, we believe that our existing cash and cash equivalents, our anticipated cash flows from operations, cash generated from the exercise of employee stock options and purchases under our employee stock purchase plan, along with the availability of funds under our $75 million Credit Agreement, will be sufficient to meet our cash needs for working capital, capital expenditures, potential acquisitions, and other contractual obligations for at least the next twelve months. For periods beyond the next twelve months, we also anticipate that our net operating cash flows plus existing balances of cash and cash equivalents will suffice to fund the continued growth of our business.

[0000926326-15-000018:mdna:99]
Cash Flows

[0000926326-15-000018:mdna:100]
The following table summarizes, for the periods indicated, selected items in our Condensed Consolidated Statements of Cash Flows:

[0000926326-15-000018:mdna:101]
|  | Three Months Ended |
|  | March 31, 2015 |  | March 31, 2014 |
|  | (In thousands) |
| Net cash provided by (used in): |  |  |  |
| Operating activities | $ | 11,314 |  |  | $ | 1,117 |  |
| Investing activities | (4,108 | ) |  | (5,592 | ) |
| Financing activities | 6,575 |  |  | 7,493 |  |
| Effect of exchange rate changes on cash and cash equivalents | (116 | ) |  | 9 |  |
| Net increase (decrease) in cash and cash equivalents | $ | 13,665 |  |  | $ | 3,027 |  |

[0000926326-15-000018:mdna:102]
Operating activities

[0000926326-15-000018:mdna:103]
We expect cash from our operating activities to fluctuate in future periods as a result of a number of factors, including the timing of our billings and collections, our operating results and the timing of other liability payments.

[0000926326-15-000018:mdna:104]
Net cash provided by operating activities was $11.3 million for the three months ended March 31, 2015, primarily as a result of $6.3 million in net income adjusted for non-cash items, including depreciation and amortization expense of $5.7 million and share-based compensation expense of $3.7 million, and an increase in accrued liabilities of $2.7 million. These amounts were partially offset by an increase in accounts receivable of $5.6 million, an increase in inventories of $1.9 million, a decrease in deferred gross profit of $4.2 million and a decrease in deferred service revenue of $2.3 million.

[0000926326-15-000018:mdna:105]
Net cash provided by operating activities was $1.1 million for the three months ended March 31, 2014, primarily as a result of $6.2 million in net income adjusted for non-cash items, including depreciation and amortization expense of $4.6 million and share-based compensation expense of $2.7 million and an increase in deferred gross profit of $5.1 million. These amounts were partially offset by an increase in accounts receivable, net of $17.1 million.

[0000926326-15-000018:mdna:106]
Investing activities

[0000926326-15-000018:mdna:107]
Net cash used in investing activities was $4.1 million for the three months ended March 31, 2015, primarily due to payments of $1.1 million for property and equipment and $3.0 million to develop software for external use.

[0000926326-15-000018:mdna:108]
Net cash used in investing activities was $5.6 million for the three months ended March 31, 2014 and was due to payments of $2.6 million for property and equipment and $2.9 million to develop software for external use.

[0000926326-15-000018:mdna:109]
Financing activities

[0000926326-15-000018:mdna:110]
Net cash provided by financing activities was $6.6 million for the three months ended March 31, 2015 as a result of $6.2 million in proceeds from employee stock option exercises and $1.2 million in excess tax benefits from employee stock plans, offset by $0.8 million in employees' taxes paid related to restricted stock units.

[0000926326-15-000018:mdna:111]
Net cash provided by financing activities was $7.5 million for the three months ended March 31, 2014 as a result of $9.6 million in net proceeds from sales of common stock through employee stock plans, $2.3 million in tax benefits from employee stock plans, partially offset by $4.1 million in repurchases of our common stock.

[0000926326-15-000018:mdna:112]
[same as prior period, unchanged from 0000926326-14-000039:mdna:126]

[0000926326-15-000018:mdna:113]
There have been no significant changes during the three months ended March 31, 2015 to the contractual obligations disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations, set forth in Part II, Item 7, of our annual report on Form 10-K for the year ended December 31, 2014.

[0000926326-15-000018:mdna:114]
We had $52.4 million in contractual commitments to third parties for non-cancelable operating leases, commitments to contract manufacturers and suppliers and other purchase commitments as of March 31, 2015 as follows:

[0000926326-15-000018:mdna:115]
|  | Payments Due by Period |
|  | Total |  | Remainder of 2015 |  | 2016 and 2017 |  | 2018 and 2019 |  | 2020 and Thereafter |
|  | (In thousands) |
| Operating leases (1) | $ | 42,569 |  |  | $ | 5,048 |  |  | $ | 11,917 |  |  | $ | 10,627 |  |  | $ | 14,977 |  |
| Purchase obligations (2) | 9,838 |  |  | 9,838 |  |  | — |  |  | — |  |  | — |  |
| Total (3) | $ | 52,407 |  |  | $ | 14,886 |  |  | $ | 11,917 |  |  | $ | 10,627 |  |  | $ | 14,977 |  |

[0000926326-15-000018:mdna:116]
_________________________________________________

[0000926326-15-000018:mdna:117]
[same as prior period, unchanged from 0000926326-14-000039:mdna:130]

[0000926326-15-000018:mdna:118]
| (2) | We purchase components from a variety of suppliers and use contract manufacturers to provide manufacturing services for our products. During the normal course of business, we issue purchase orders with estimates of our requirements several months ahead of the delivery dates. These amounts are associated with agreements that are enforceable and legally binding. The amounts under such contracts are included in the table above because we believe that cancellation of these contracts is unlikely and we expect to make future cash payments according to the contract terms or in similar amounts for similar materials. |

[0000926326-15-000018:mdna:119]
| (3) | We have recorded $5.9 million for uncertain tax positions under long-term liabilities as of March 31, 2015 in accordance with U.S. GAAP. As these liabilities do not reflect actual tax assessments, the timing and amount of payments we might be required to make will depend upon a number of factors. Accordingly, as the timing and amount of payment cannot be estimated, $5.9 million in uncertain tax position liabilities have not been included in the table above. |

[0000926326-15-000018:mdna:120]
See Note 10, Commitments, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report.

[0000926326-15-000018:mdna:121]
[same as prior period, unchanged from 0000926326-14-000039:mdna:133]

[0000926326-15-000018:mdna:122]
As of March 31, 2015, we had no off-balance sheet arrangements as defined under Regulation S-K 303(a)(4) of the Securities Exchange Act of 1934, as amended, and the instructions thereto.
