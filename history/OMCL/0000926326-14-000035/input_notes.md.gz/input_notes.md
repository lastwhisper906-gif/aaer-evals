# OMCL notes — 0000926326-14-000035


## us-gaap:AllowanceForCreditLossesOnFinancingReceivablesTableTextBlock

[0000926326-14-000035:notes:1]
[same as prior period, unchanged from 0000926326-14-000010:notes:1]

[0000926326-14-000035:notes:2]
|  | Allowance for Credit Losses |  | Recorded Investmentin Sales-type Leases Gross |  | Recorded Investmentin Sales-type Leases Net |
| Credit loss disclosure for June 30, 2014: |  |  |  |  |  |  |  |  |
| Accounts individually evaluated for impairment | $ | — |  |  | $ | — |  |  | $ | — |  |
| Accounts collectively evaluated for impairment | 157 |  |  | 16,502 |  |  | 16,345 |  |
| Ending balances: June 30, 2014 | $ | 157 |  |  | $ | 16,502 |  |  | $ | 16,345 |  |
| Credit loss disclosure for December 31, 2013: |  |  |  |  |  |  |  |  |
| Accounts individually evaluated for impairment | $ | — |  |  | $ | — |  |  | $ | — |  |
| Accounts collectively evaluated for impairment | 167 |  |  | 16,884 |  |  | 16,717 |  |
| Ending balances: December 31, 2013 | $ | 167 |  |  | 16,884 |  |  | $ | 16,717 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000926326-14-000035:notes:3]
Basis of presentation. These interim condensed consolidated financial statements are unaudited but reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of Omnicell and our subsidiaries as of June 30, 2014, the results of our operations and comprehensive income for the three and six months ended June 30, 2014 and 2013 and our cash flows for the six months ended June 30, 2014 and 2013. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and accompanying notes included in our Annual Report on Form 10-K for the year ended December 31, 2013.

[0000926326-14-000035:notes:4]
Our results of operations, comprehensive income for the three and six months ended June 30, 2014 and cash flows for the six months ended June 30, 2014 are not necessarily indicative of results that may be expected for the year ending December 31, 2014, or for any future period.


## us-gaap:CashAndCashEquivalentsDisclosureTextBlock

[0000926326-14-000035:notes:5]
[same as prior period, unchanged from 0000926326-14-000010:notes:5]

[0000926326-14-000035:notes:6]
Cash and cash equivalents consist of the following significant asset investment classes as of June 30, 2014 and December 31, 2013 (in thousands):

[0000926326-14-000035:notes:7]
|  | June 30, 2014 |  |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | Fair Value |  | Cash / CashEquivalents |  | SecurityClassification |
| Cash | $ | 68,333 |  |  | $ | — |  |  | $ | — |  |  | $ | 68,333 |  |  | $ | 68,333 |  |  | N/A |
| Money market fund | 58,046 |  |  | — |  |  | — |  |  | 58,046 |  |  | 58,046 |  |  | Available for sale |
| Total cash and cash equivalents | $ | 126,379 |  |  | $ | — |  |  | $ | — |  |  | $ | 126,379 |  |  | $ | 126,379 |  |  |  |

[0000926326-14-000035:notes:8]
[same as prior period, unchanged from 0000926326-14-000010:notes:8]

[0000926326-14-000035:notes:9]
The money market fund is a daily-traded cash equivalent with a price of $1.00, making it a Level 1 asset class, and its carrying cost closely approximates fair value. As demand deposit (cash) balances vary with the timing of collections and payments, the money market fund can cover any surplus or deficit, and thus is considered available-for-sale.  We did not hold any Level 2 and Level 3 assets or liabilities as of June 30, 2014 and December 31, 2013.

[0000926326-14-000035:notes:10]
[same as prior period, unchanged from 0000926326-14-000010:notes:10]

[0000926326-14-000035:notes:11]
|  | Quoted Prices in ActiveMarkets for IdenticalInstruments (Level 1) |  | Total FairValue |
| Money market fund at June 30, 2014 | $ | 58,046 |  |  | $ | 58,046 |  |
| Money market fund at December 31, 2013 | $ | 65,708 |  |  | $ | 65,708 |  |


## us-gaap:CommitmentsDisclosureTextBlock

[0000926326-14-000035:notes:12]
[same as prior period, unchanged from 0000926326-14-000010:notes:12]

[0000926326-14-000035:notes:13]
We lease properties in California, Florida, Illinois, Tennessee, and the United Kingdom. We also have smaller rented offices in Ohio, the United Arab Emirates, the People's Republic of China and the Federal Republic of Germany.

[0000926326-14-000035:notes:14]
At June 30, 2014, the minimum payments under our operating leases for each of the five succeeding fiscal years were as follows (in thousands):

[0000926326-14-000035:notes:15]
| Remainder of 2014 | $ | 2,926 |  |
| 2015 | 5,583 |  |
| 2016 | 5,167 |  |
| 2017 | 4,468 |  |
| 2018 | 4,298 |  |
| Thereafter | 16,600 |  |
| Total | $ | 39,042 |  |

[0000926326-14-000035:notes:16]
We purchase components from a variety of suppliers and use contract manufacturers to provide manufacturing services for our products. During the normal course of business, we issue purchase orders with estimates of our requirements several months ahead of the delivery dates. Our near-term commitments to our contract manufacturers and suppliers totaled $11.3 million as of June 30, 2014.


## us-gaap:DebtDisclosureTextBlock

[0000926326-14-000035:notes:17]
Credit Agreement

[0000926326-14-000035:notes:18]
In September 2013, we entered into a credit agreement (the "Credit Agreement") with Wells Fargo Bank, National Association, as administrative agent, and the lenders from time to time thereto. The Credit Agreement provides for a $75.0 million revolving credit facility with a $10.0 million letter of credit sub-limit. Loans under the Credit Agreement mature on September 25, 2018. The Credit Agreement permits us to request one or more increases in the aggregate commitments provided that such increases do not exceed $25.0 million in the aggregate. We expect to use the proceeds from any revolving loans under the credit facility for general corporate purposes, including future acquisitions. Our obligations under the Credit Agreement are guaranteed by certain of our domestic subsidiaries and secured by substantially all of our and the subsidiary guarantors’ assets.

[0000926326-14-000035:notes:19]
Amounts drawn under the Credit Agreement bear interest, at our election, at a Eurodollar rate plus a margin of 1.75% per annum, or an alternate base rate equal to the highest of (a) the prime rate, (b) the federal funds rate plus 0.50%, and (c) LIBOR for an interest period of one month plus 1.75%. We are required to pay a commitment fee of 0.25% per annum on the aggregate undrawn amount of the commitments under the credit facility.

[0000926326-14-000035:notes:20]
The Credit Agreement contains customary affirmative and negative covenants, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends and other distributions. The Credit Agreement contains financial covenants that require us to, among other things, maintain a maximum consolidated total leverage ratio and a minimum consolidated fixed charge coverage ratio, in each case, as of the last day of each fiscal quarter.

[0000926326-14-000035:notes:21]
To date, we have not yet drawn any funds under the credit facility. We were in full compliance with all covenants at June 30, 2014 and for all periods since the commencement of the Credit Agreement.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000926326-14-000035:notes:22]
[same as prior period, unchanged from 0000926326-14-000010:notes:21]

[0000926326-14-000035:notes:23]
Share-Based Plans

[0000926326-14-000035:notes:24]
[same as prior period, unchanged from 0000926326-14-000010:notes:23]

[0000926326-14-000035:notes:25]
For a detailed explanation of our stock plan and subsequent changes please refer to Note 16, Stock Option Plans, Share-Based Compensation and 401(k) Plan, of our Annual Report on Form 10-K for the year ended December 31, 2013.

[0000926326-14-000035:notes:26]
At June 30, 2014, 2,361,284 shares of common stock were reserved for future issuance our 2009 Equity Incentive Plan, as amended (the "2009 Plan"), and $5.9 million of total unrecognized compensation cost related to non-vested stock options was expected to be recognized over a weighted average period of 2.7 years.

[0000926326-14-000035:notes:27]
A summary of option activity under the 2009 Plan for the six months ended June 30, 2014 is presented below:

[0000926326-14-000035:notes:28]
| Options: |  | Number of Shares |  | Weighted-Average Exercise Price |
|  |  | (in thousands) |  |  |
| Outstanding at December 31, 2013 |  | 3,143 |  |  | $15.82 |
| Granted |  | 304 |  |  | $25.75 |
| Exercised |  | (582 | ) |  | $14.29 |
| Forfeited |  | (59 | ) |  | $18.56 |
| Expired |  | (7 | ) |  | $17.47 |
| Outstanding at June 30, 2014 |  | 2,799 |  |  | $17.15 |
| Vested and expected to vest at June 30, 2014 |  | 2,770 |  |  | $17.10 |
| Exercisable at June 30, 2014 |  | 1,727 |  |  | $15.39 |

[0000926326-14-000035:notes:29]
The aggregate intrinsic value of options exercised under our stock plans for the three and six months ended June 30, 2014 was $5.3 million and $7.9 million, respectively, determined as of the date of option exercise.

[0000926326-14-000035:notes:30]
[same as prior period, unchanged from 0000926326-14-000010:notes:28]

[0000926326-14-000035:notes:31]
A summary of activity of both restricted stock and restricted stock units ("RSUs") for the six months ended June 30, 2014 is presented below:

[0000926326-14-000035:notes:32]
|  | Restricted Stock |  | Restricted Stock Units |
|  | Number ofShares |  | Weighted-AverageGrant DateFair Value PerShare |  | Number ofShares |  | Weighted-AverageGrant DateFair Value PerShare |
|  | (in thousands) |  |  |  | (in thousands) |  |  |
| Non-vested, December 31, 2013 | 52 |  |  | $18.43 |  | 362 |  |  | $17.15 |
| Granted | 39 |  |  | $26.46 |  | 98 |  |  | $25.56 |
| Vested | (54 | ) |  | $26.47 |  | (84 | ) |  | $16.54 |
| Forfeited | — |  |  | $0.00 |  | (16 | ) |  | $15.83 |
| Non-vested, June 30, 2014 | 37 |  |  | $26.47 |  | 360 |  |  | $19.64 |

[0000926326-14-000035:notes:33]
The fair value of restricted stock is the product of the number of shares granted and the closing market price of our common stock on the grant date. Our unrecognized compensation cost related to non-vested restricted stock is approximately $6.3 million and is expected to be recognized over a weighted-average period of 2.5 years.

[0000926326-14-000035:notes:34]
[same as prior period, unchanged from 0000926326-14-000010:notes:32]

[0000926326-14-000035:notes:35]
Performance-based restricted stock units ("PSUs") are an element of our executive compensation plans. In 2012, we granted 125,000 PSUs to our executive officer of which 62,500 became eligible for vesting upon the achievement of a certain level of shareholder return for 2012 as described below. In 2013, we granted 137,500 PSUs to our executive officers, all of which became eligible for vesting upon the achievement of a certain level of shareholder return for the period from January 1, 2013 through February 28, 2014, as described below. In 2014, we granted 132,500 PSUs to our executive officers, all, none or a portion of which may become eligible for vesting depending on the level of shareholder return for 2014 and eligibility for further time-based vesting based on the ranking of our total shareholder return. For a more detailed explanation of our PSUs and subsequent changes, please refer to Note 16, Stock Option Plans, Share-Based Compensation and 401(k) Plan on our Annual Report on Form 10-K for the year ended December 31, 2013.

[0000926326-14-000035:notes:36]
Our unrecognized compensation cost related to non-vested performance-based restricted stock units at June 30, 2014 was approximately $2.3 million and is expected to be recognized over a weighted-average period of 1.5 years. For the three months ended June 30, 2014 and 2013, we recognized $0.5 million and $0.4 million, respectively, of compensation expense for the PSUs. For the six months ended June 30, 2014 and 2013, we recognized $1.0 million and $0.8 million, respectively, of compensation expense for the PSUs.

[0000926326-14-000035:notes:37]
[same as prior period, unchanged from 0000926326-14-000010:notes:35]

[0000926326-14-000035:notes:38]
[same as prior period, unchanged from 0000926326-14-000010:notes:36]

[0000926326-14-000035:notes:39]
[same as prior period, unchanged from 0000926326-14-000010:notes:37]

[0000926326-14-000035:notes:40]
[same as prior period, unchanged from 0000926326-14-000010:notes:38]

[0000926326-14-000035:notes:41]
[same as prior period, unchanged from 0000926326-14-000010:notes:39]

[0000926326-14-000035:notes:42]
[same as prior period, unchanged from 0000926326-14-000010:notes:40]

[0000926326-14-000035:notes:43]
A summary of activity of the PSUs for the six months ended June 30, 2014 is presented below:

[0000926326-14-000035:notes:44]
| Performance-based Stock Units | Number of Shares |  | Weighted-AverageGrant Date Fair Value PerShare |
|  | (in thousands) |  |  |
| Non-vested, December 31, 2013 | 225 |  |  | $13.32 |
| Granted | 135 |  |  | $16.49 |
| Vested | (74 | ) |  | $13.66 |
| Forfeited | (8 | ) |  | $10.93 |
| Non-vested, June 30, 2014 | 278 |  |  | $14.72 |

[0000926326-14-000035:notes:45]
[same as prior period, unchanged from 0000926326-14-000010:notes:43]

[0000926326-14-000035:notes:46]
[same as prior period, unchanged from 0000926326-14-000010:notes:44]

[0000926326-14-000035:notes:47]
At the 2009 Annual Meeting of Stockholders, the stockholders approved an amendment to the ESPP, which added 2,622,426 shares to the reserve for future issuance. As of June 30, 2014, there were 846,891 shares reserved for future issuance under the ESPP. For the three months ended June 30, 2014, no shares of common stock were purchased under the ESPP. For the six months ended June 30, 2014, 254,009 shares of common stock were purchased under the ESPP.

[0000926326-14-000035:notes:48]
As of June 30, 2014, our unrecognized compensation cost related to the shares to be purchased under our ESPP was approximately $0.9 million and is expected to be recognized over a weighted average period of approximately 1.0 year.

[0000926326-14-000035:notes:49]
[same as prior period, unchanged from 0000926326-14-000010:notes:47]

[0000926326-14-000035:notes:50]
[same as prior period, unchanged from 0000926326-14-000010:notes:48]

[0000926326-14-000035:notes:51]
[same as prior period, unchanged from 0000926326-14-000010:notes:49]

[0000926326-14-000035:notes:52]
The following table shows a summary of the share-based compensation expense included in the condensed consolidated statements of operations (in thousands):

[0000926326-14-000035:notes:53]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Cost of revenues | $ | 264 |  |  | $ | 324 |  |  | $ | 532 |  |  | $ | 629 |  |
| Research and development | 380 |  |  | 326 |  |  | 749 |  |  | 615 |  |
| Selling, general and administrative | 2,076 |  |  | 2,037 |  |  | 4,168 |  |  | 4,369 |  |
| Total share-based compensation expenses | $ | 2,720 |  |  | $ | 2,687 |  |  | $ | 5,449 |  |  | $ | 5,613 |  |


## us-gaap:EarningsPerSharePolicyTextBlock

[0000926326-14-000035:notes:54]
Basic net income per share is computed by dividing net income for the period by the weighted average number of shares outstanding during the period, less shares subject to repurchase. Diluted net income per share is computed by dividing net income for the period by the weighted average number of shares, less shares subject to repurchase, plus, if dilutive, potential common stock outstanding during the period. Potential common stock includes the effect of outstanding dilutive stock options, restricted stock awards and restricted stock units computed using the treasury stock method. Since their impact is anti-dilutive, we excluded 353,422 and 366,021 shares, respectively, from the calculations of diluted net income per share for the three and six months ended June 30, 2014 and 1,346,561 and 1,581,335 shares, respectively, from the same calculations for the three and six months ended June 30, 2013.


## us-gaap:EarningsPerShareTextBlock

[0000926326-14-000035:notes:55]
[same as prior period, unchanged from 0000926326-14-000010:notes:53]

[0000926326-14-000035:notes:56]
[same as prior period, unchanged from 0000926326-14-000010:notes:54]

[0000926326-14-000035:notes:57]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Basic: |  |  |  |  |  |  |  |  |  |
| Net income | $ | 7,789 |  |  | $ | 6,016 |  |  | $ | 13,983 |  |  | $ | 9,401 |  |
| Weighted average shares outstanding — basic | 35,661 |  |  | 34,450 |  |  | 35,451 |  |  | 34,177 |  |
| Net income per share — basic | $ | 0.22 |  |  | $ | 0.17 |  |  | $ | 0.39 |  |  | $ | 0.28 |  |
| Diluted: |  |  |  |  |  |  |  |  |  |
| Net income | $ | 7,789 |  |  | $ | 6,016 |  |  | $ | 13,983 |  |  | $ | 9,401 |  |
| Weighted average shares outstanding — basic | 35,661 |  |  | 34,450 |  |  | 35,451 |  |  | 34,177 |  |
| Add: Dilutive effect of employee stock plans | 957 |  |  | 924 |  |  | 1,027 |  |  | 922 |  |
| Weighted average shares outstanding — diluted | 36,618 |  |  | 35,374 |  |  | $ | 36,478 |  |  | 35,099 |  |
| Net income per share — diluted | $ | 0.21 |  |  | $ | 0.17 |  |  | $ | 0.38 |  |  | $ | 0.27 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000926326-14-000035:notes:58]
[same as prior period, unchanged from 0000926326-14-000010:notes:56]

[0000926326-14-000035:notes:59]
[same as prior period, unchanged from 0000926326-14-000010:notes:57]

[0000926326-14-000035:notes:60]
Goodwill is tested for impairment at least annually or more frequently if events or circumstances indicate that an impairment loss may have occurred, and we write down these assets when impaired. We perform our annual impairment tests during the fourth quarter of each fiscal year using the closing balance sheet as of the last day of the third quarter.

[0000926326-14-000035:notes:61]
During the six months ended June 30, 2014, we noted no indications of impairment or triggering events to cause us to perform a goodwill impairment analysis.

[0000926326-14-000035:notes:62]
There were no changes in the carrying amount of goodwill for the period from December 31, 2013 to June 30, 2014. Goodwill by reporting unit, which is the same for our operating segments, is as follows (in thousands):

[0000926326-14-000035:notes:63]
|  | Goodwill at December 31, 2013 |  | Adjustments to Goodwill |  | Goodwill at June 30, 2014 |
| Reporting units: |  |  |  |  |  |
| Automation and Analytics | $ | 28,543 |  |  | $ | — |  |  | $ | 28,543 |  |
| Medication Adherence | 82,800 |  |  | — |  |  | 82,800 |  |
| Total | $ | 111,343 |  |  | $ | — |  |  | $ | 111,343 |  |

[0000926326-14-000035:notes:64]
[same as prior period, unchanged from 0000926326-14-000010:notes:62]

[0000926326-14-000035:notes:65]
There were no indefinite-lived intangible assets as of June 30, 2014 or December 31, 2013. Finite-lived intangible assets consist of the following (in thousands):

[0000926326-14-000035:notes:66]
|  | June 30, 2014 |  | December 31, 2013 |  |  |
|  | Gross |  |  |  | Net |  | Gross |  |  |  | Net |  |  |
|  | CarryingAmount |  | AccumulatedAmortization |  | CarryingAmount |  | CarryingAmount |  | AccumulatedAmortization |  | CarryingAmount |  | AmortizationLife |
| Finite-lived intangibles: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships | $ | 54,730 |  |  | $ | 6,314 |  |  | $ | 48,416 |  |  | $ | 54,730 |  |  | $ | 5,236 |  |  | $ | 49,494 |  |  | 5-30 years |
| Acquired technology | 27,580 |  |  | 3,333 |  |  | 24,247 |  |  | 27,580 |  |  | 2,598 |  |  | 24,982 |  |  | 3-20 years |
| Patents | 1,613 |  |  | 319 |  |  | 1,294 |  |  | 1,493 |  |  | 254 |  |  | 1,239 |  |  | 20 years |
| Trade name | 6,890 |  |  | 1,286 |  |  | 5,604 |  |  | 6,890 |  |  | 1,003 |  |  | 5,887 |  |  | 3-12 years |
| Non-compete agreements | — |  |  | — |  |  | — |  |  | 60 |  |  | 60 |  |  | — |  |  | 3 years |
| Total finite-lived intangibles | $ | 90,813 |  |  | $ | 11,252 |  |  | $ | 79,561 |  |  | $ | 90,753 |  |  | $ | 9,151 |  |  | $ | 81,602 |  |  |  |

[0000926326-14-000035:notes:67]
Amortization expense for the intangible assets presented above was $1.1 million for both the three months ended June 30, 2014 and 2013, and $2.2 million and $2.1 million for the six months ended June 30, 2014 and 2013, respectively. The amortization of acquired technology is included within product cost of sales and amortization of other acquired intangibles is included within selling, general and administrative expenses.

[0000926326-14-000035:notes:68]
[same as prior period, unchanged from 0000926326-14-000010:notes:66]

[0000926326-14-000035:notes:69]
| Remainder of 2014 | $ | 2,127 |  |
| 2015 | 4,225 |  |
| 2016 | 3,857 |  |
| 2017 | 3,822 |  |
| 2018 | 3,714 |  |
| Thereafter | 61,816 |  |
| Total | $ | 79,561 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000926326-14-000035:notes:70]
[same as prior period, unchanged from 0000926326-14-000010:notes:68]

[0000926326-14-000035:notes:71]
We provide for income taxes for each interim period based on the estimated annual effective tax rate for the year, adjusting for discrete items in the quarter in which they arise. The annual effective tax rate before discrete items was 39.2% and 38.7% for the six months ended June 30, 2014 and 2013, respectively. The 2014 annual effective tax rate differed from the statutory rate of 35% primarily due to the unfavorable impact of state income taxes, non-deductible equity charges, and other non-deductible expenditures, which were partially offset by the domestic production activities deduction.

[0000926326-14-000035:notes:72]
The 2013 annual effective tax rate differed from the statutory rate of 35% primarily due to the unfavorable impact of state income taxes, non-deductible equity charges, and other non-deductible expenditures, which were partially offset by the federal research and development credit claimed and the domestic production activities deduction.


## us-gaap:InventoryDisclosureTextBlock

[0000926326-14-000035:notes:73]
[same as prior period, unchanged from 0000926326-14-000010:notes:71]

[0000926326-14-000035:notes:74]
[same as prior period, unchanged from 0000926326-14-000010:notes:72]

[0000926326-14-000035:notes:75]
|  | June 30, 2014 |  | December 31, 2013 |
| Raw materials | $ | 11,197 |  |  | $ | 10,765 |  |
| Work in process | 745 |  |  | 534 |  |
| Finished goods | 19,600 |  |  | 20,158 |  |
| Total | $ | 31,542 |  |  | $ | 31,457 |  |


## us-gaap:LegalMattersAndContingenciesTextBlock

[0000926326-14-000035:notes:76]
Contingencies

[0000926326-14-000035:notes:77]
Legal Proceedings

[0000926326-14-000035:notes:78]
We may from time to time become involved in certain legal proceedings in the ordinary course of business. We are not a party to any legal proceedings that management believes may have a material impact on Omnicell's financial position or results of operations.

[0000926326-14-000035:notes:79]
Guarantees

[0000926326-14-000035:notes:80]
As permitted under Delaware law and our certificate of incorporation and bylaws, we have agreed to indemnify our directors and officers against certain losses that they may suffer by reason of the fact that such persons are, were or become our directors or officers. The term of the indemnification period is for the director’s or officer’s lifetime and there is no limit on the potential amount of future payments that we could be required to make under these indemnification agreements. We have purchased a directors’ and officers’ liability insurance policy that may enable us to recover a portion of any future payments that we may be required to make under these indemnification agreements. Assuming the applicability of coverage and the willingness of the insurer to assume coverage and subject to certain retention, loss limits and other policy provisions, we believe it is unlikely that we will be required to pay any material amounts pursuant to these indemnification obligations. However, no assurances can be given that the insurers will not attempt to dispute the validity, applicability or amount of coverage without expensive and time-consuming litigation against the insurers.

[0000926326-14-000035:notes:81]
Additionally, we undertake indemnification obligations in our ordinary course of business in connection with, among other things, the licensing of our products and the provision of our support services. In the ordinary course of our business, we have in the past and may in the future agree to indemnify another party, generally our business affiliates or customers, against certain losses suffered or incurred by the indemnified party in connection with various types of claims, which may include, without limitation, claims of intellectual property infringement, certain tax liabilities, our gross negligence or intentional acts in the performance of support services and violations of laws. The term of these indemnification obligations is generally perpetual. In general, we attempt to limit the maximum potential amount of future payments that we may be required to make under these indemnification obligations to the amounts paid to us by a customer, but in some cases the obligation may not be so limited. In addition, we have in the past and may in the future warrant to our customers that our products will conform to functional specifications for a limited period of time following the date of installation (generally not exceeding 30 days) or that our software media is free from material defects. Sales contracts for certain of our medication packaging systems often include limited warranties for up to six months, but the periodic activity and ending warranty balances we record have historically been immaterial.

[0000926326-14-000035:notes:82]
From time to time, we may also warrant that our professional services will be performed in a good and workmanlike manner or in a professional manner consistent with industry standards. We generally seek to disclaim most warranties, including any implied or statutory warranties such as warranties of merchantability, fitness for a particular purpose, title, quality and non-infringement, as well as any liability with respect to incidental, consequential, special, exemplary, punitive or similar damages. In some states, such disclaimers may not be enforceable. If necessary, we would provide for the estimated cost of product and service warranties based on specific warranty claims and claim history. We have not been subject to any significant claims for such losses and have not incurred any material costs in defending or settling claims related to these indemnification obligations. Accordingly, we believe it is unlikely that we will be required to pay any material amounts pursuant to these indemnification obligations or potential warranty claims and, therefore, no material liabilities have been recorded for such indemnification obligations as of June 30, 2014 or December 31, 2013.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000926326-14-000035:notes:83]
Recently Adopted Accounting Standards

[0000926326-14-000035:notes:84]
In July 2013, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") 2013-11,  Income Taxes (Topic 740): Presentation of an Unrecognized Tax Benefit When a Net Operating Loss Carryforward, a Similar Tax Loss, or a Tax Credit Carryforward Exists. ASU 2013-11 requires an entity to present an unrecognized tax benefit, or a portion of an unrecognized tax benefit, as a reduction to a deferred tax asset for a net operating loss carryforward, a similar tax loss, or a tax credit carryforward, except as follows: to the extent a net operating loss carryforward, a similar tax loss, or a tax credit carryforward is not available at the reporting date under the tax law of the applicable jurisdiction to settle any additional income taxes that would result from the disallowance of a tax position or the tax law of the applicable jurisdiction does not require the entity to use, and the entity does not intend to use, the deferred tax asset for such purpose, the unrecognized tax benefit should be presented in the financial statements as a liability and should not be combined with deferred tax assets. We adopted the amendments in ASU 2013-11 in the first quarter of 2014. This update did not have a significant impact on our financial position, operating results or cash flows.

[0000926326-14-000035:notes:85]
Recently Issued Accounting Standards

[0000926326-14-000035:notes:86]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers: Topic 606.  ASU 2014-09  supersedes nearly all existing revenue recognition guidance under GAAP.  The core principle of ASU 2014-09 is to recognize revenues when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. ASU 2014-09 defines a five step process to achieve this core principle and, in doing so, it is possible more judgment and estimates may be required within the revenue recognition process than required under existing GAAP, including identifying performance obligations in the contract, estimating the amount of variable consideration to include in the transaction price and allocating the transaction price to each separate performance obligation. Companies may use either of two methods: (i) full retrospective application to each prior reporting period presented with the option to elect certain practical expedients defined within ASU 2014-09; or (ii) modified retrospective application with the cumulative effect of initially applying ASU 2014-09 recognized at the date of initial application and providing certain additional disclosures as defined per ASU 2014-09. ASU 2014-09 is effective for us in the first quarter of 2017 and we are currently evaluating the impact of our pending adoption on our consolidated financial statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0000926326-14-000035:notes:87]
[same as prior period, unchanged from 0000926326-14-000010:notes:84]

[0000926326-14-000035:notes:88]
[same as prior period, unchanged from 0000926326-14-000010:notes:85]

[0000926326-14-000035:notes:89]
[same as prior period, unchanged from 0000926326-14-000010:notes:86]

[0000926326-14-000035:notes:90]
[same as prior period, unchanged from 0000926326-14-000010:notes:87]

[0000926326-14-000035:notes:91]
Concentration of credit risk. Financial instruments that may potentially subject us to concentrations of credit risk consist principally of cash equivalents and accounts receivable. Cash equivalents are maintained with several financial institutions and may exceed the amount of insurance provided on such balances. The majority of our accounts receivable are derived from sales to customers for commercial applications. We perform ongoing credit evaluations of our customers’ financial condition and limit the amount of credit extended when deemed necessary but generally require no collateral. We maintain reserves for potential credit losses. Our products are broadly distributed and there was no single customer accounting for 10% or more of revenues in the three and six months ended June 30, 2014 and 2013. Additionally, there was no single customer accounting for 10% or more of accounts receivable at June 30, 2014 or December 31, 2013. We believe that we have no significant concentrations of credit risk at June 30, 2014.

[0000926326-14-000035:notes:92]
Dependence on suppliers. We have a supply agreement with one primary supplier for construction and supply of several sub-assemblies and inventory management of sub-assemblies used in our hardware products. There are no minimum purchase requirements. The contract may be terminated by either the supplier or by us without cause and at any time upon delivery of two months’ notice. Purchases from this supplier for the three months ended June 30, 2014 and 2013 totaled approximately $8.3 million and $6.7 million, respectively, and $17.2 million and $13.9 million for the six months ended June 30, 2014 and 2013, respectively.

[0000926326-14-000035:notes:93]
There have been no material changes in our significant accounting policies as of and for the three and six months ended June 30, 2014, compared to the significant accounting policies described in our Annual Report on Form 10-K for the year ended December 31, 2013.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000926326-14-000035:notes:94]
[same as prior period, unchanged from 0000926326-14-000010:notes:91]

[0000926326-14-000035:notes:95]
[same as prior period, unchanged from 0000926326-14-000010:notes:92]

[0000926326-14-000035:notes:96]
|  | June 30, 2014 |  | December 31, 2013 |
| Equipment | $ | 41,876 |  |  | $ | 40,180 |  |
| Furniture and fixtures | 5,609 |  |  | 5,260 |  |
| Leasehold improvements | 8,070 |  |  | 7,394 |  |
| Purchased software | 25,173 |  |  | 20,199 |  |
| Construction in process | 2,142 |  |  | 2,649 |  |
| Total property and equipment | 82,870 |  |  | 75,682 |  |
| Accumulated depreciation and amortization | (45,613 | ) |  | (40,428 | ) |
| Total property and equipment, net | $ | 37,257 |  |  | $ | 35,254 |  |

[0000926326-14-000035:notes:97]
Depreciation and amortization of property and equipment was approximately $2.7 million and $2.9 million for the three months ended June 30, 2014 and 2013, respectively, and $5.2 million and $5.6 million for the six months ended June 30, 2014 and 2013, respectively.


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0000926326-14-000035:notes:98]
The contributions of our operating segments to net revenues and income from operations, and the reconciliation to total net income, were as follows (amounts in thousands):

[0000926326-14-000035:notes:99]
|  | Three Months Ended June 30, 2014 |  | Three Months Ended June 30, 2013 |
|  | Automation and Analytics |  | Medication Adherence |  | Total |  | Automation and Analytics |  | Medication Adherence |  | Total |
| Total revenues | $ | 84,702 |  |  | $ | 20,350 |  |  | $ | 105,052 |  |  | $ | 73,866 |  |  | $ | 19,820 |  |  | $ | 93,686 |  |
| Cost of revenues | 35,992 |  |  | 13,020 |  |  | 49,012 |  |  | 31,936 |  |  | 12,382 |  |  | 44,318 |  |
| Gross profit | $ | 48,710 |  |  | $ | 7,330 |  |  | $ | 56,040 |  |  | $ | 41,930 |  |  | $ | 7,438 |  |  | $ | 49,368 |  |
| Gross margin % | 57.5 | % |  | 36.0 | % |  | 53.3 | % |  | 56.8 | % |  | 37.5 | % |  | 52.7 | % |
| Operating expenses | 36,508 |  |  | 6,974 |  |  | 43,482 |  |  | 33,808 |  |  | 6,201 |  |  | 40,009 |  |
| Income from operations | $ | 12,202 |  |  | $ | 356 |  |  | $ | 12,558 |  |  | $ | 8,122 |  |  | $ | 1,237 |  |  | $ | 9,359 |  |
| Operating margin % | 14.4 | % |  | 1.7 | % |  | 12.0 | % |  | 11.0 | % |  | 6.2 | % |  | 10.0 | % |
| Interest and other income (expense), net |  |  |  |  | (40 | ) |  |  |  |  |  | 63 |  |
| Income before provision for income taxes |  |  |  |  | 12,518 |  |  |  |  |  |  | 9,422 |  |
| Provision for income taxes |  |  |  |  | 4,729 |  |  |  |  |  |  | 3,406 |  |
| Net income |  |  |  |  | $ | 7,789 |  |  |  |  |  |  | $ | 6,016 |  |

[0000926326-14-000035:notes:100]
|  | Six Months Ended June 30, 2014 |  | Six Months Ended June 30, 2013 |
|  | Automation and Analytics |  | Medication Adherence |  | Total |  | Automation and Analytics |  | Medication Adherence |  | Total |
| Total revenues | $ | 166,201 |  |  | $ | 40,615 |  |  | $ | 206,816 |  |  | $ | 142,579 |  |  | $ | 38,217 |  |  | $ | 180,796 |  |
| Cost of revenues | 70,932 |  |  | 25,349 |  |  | 96,281 |  |  | 62,212 |  |  | 23,849 |  |  | 86,061 |  |
| Gross profit | $ | 95,269 |  |  | $ | 15,266 |  |  | $ | 110,535 |  |  | $ | 80,367 |  |  | $ | 14,368 |  |  | $ | 94,735 |  |
| Gross margin % | 57.3 | % |  | 37.6 | % |  | 53.4 | % |  | 56.4 | % |  | 37.6 | % |  | 52.4 | % |
| Operating expenses | 73,910 |  |  | 14,113 |  |  | 88,023 |  |  | 66,912 |  |  | 14,296 |  |  | 81,208 |  |
| Income from operations | $ | 21,359 |  |  | $ | 1,153 |  |  | $ | 22,512 |  |  | $ | 13,455 |  |  | $ | 72 |  |  | $ | 13,527 |  |
| Operating margin % | 12.9 | % |  | 2.8 | % |  | 10.9 | % |  | 9.4 | % |  | 0.2 | % |  | 7.5 | % |
| Interest and other income (expense), net |  |  |  |  | (296 | ) |  |  |  |  |  | (159 | ) |
| Income before provision for income taxes |  |  |  |  | 22,216 |  |  |  |  |  |  | 13,368 |  |
| Provision for income taxes |  |  |  |  | 8,233 |  |  |  |  |  |  | 3,967 |  |
| Net income |  |  |  |  | $ | 13,983 |  |  |  |  |  |  | $ | 9,401 |  |


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0000926326-14-000035:notes:101]
[same as prior period, unchanged from 0000926326-14-000010:notes:96]

[0000926326-14-000035:notes:102]
|  | June 30, 2014 |  | December 31, 2013 |
| Rebates and lease buyouts | $ | 4,596 |  |  | $ | 1,699 |  |
| Advance payments from customers | 3,656 |  |  | 4,971 |  |
| Accrued Group Purchasing Organization (GPO) fees(1) | 2,848 |  |  | 2,324 |  |
| Technology license purchase obligation, current portion | 500 |  |  | 1,500 |  |
| Taxes payable | 2,719 |  |  | 1,664 |  |
| Other | 1,851 |  |  | 1,588 |  |
| Total | $ | 16,170 |  |  | $ | 13,746 |  |


## us-gaap:ScheduleOfCreditLossesRelatedToFinancingReceivablesNoncurrentTableTextBlock

[0000926326-14-000035:notes:103]
The following table summarizes the activity for the allowance for credit losses for the investment in sales-type leases (in thousands):

[0000926326-14-000035:notes:104]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Allowance for credit losses, beginning of period | $ | 169 |  |  | $ | 190 |  |  | $ | 167 |  |  | $ | 607 |  |
| Current period provision (reversal) | (12 | ) |  | 6 |  |  | (10 | ) |  | 19 |  |
| Direct write-downs charged against the allowance | — |  |  | — |  |  | — |  |  | (413 | ) |
| Recoveries of amounts previously charged off | — |  |  | (12 | ) |  | — |  |  | (29 | ) |
| Allowance for credit losses, end of period | $ | 157 |  |  | $ | 184 |  |  | $ | 157 |  |  | $ | 184 |  |


## us-gaap:ScheduleOfFutureMinimumLeasePaymentsForCapitalLeasesTableTextBlock

[0000926326-14-000035:notes:105]
The minimum lease payments under sales-type leases as of June 30, 2014 were as follows (in thousands):

[0000926326-14-000035:notes:106]
| Remainder of 2014 | $ | 3,137 |  |
| 2015 | 5,438 |  |
| 2016 | 4,102 |  |
| 2017 | 3,154 |  |
| 2018 | 1,576 |  |
| Thereafter | 152 |  |
| Total | $ | 17,559 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000926326-14-000035:notes:107]
Segment depreciation and amortization, and capital expenditures were as follows (amounts in thousands):

[0000926326-14-000035:notes:108]
|  | Three Months Ended June 30, 2014 |  | Three Months Ended June 30, 2013 |
|  | Automation and Analytics |  | Medication Adherence |  | Total |  | Automation and Analytics |  | Medication Adherence |  | Total |
| Depreciation and amortization | $ | 3,044 |  |  | $ | 1,735 |  |  | $ | 4,779 |  |  | $ | 2,963 |  |  | $ | 1,809 |  |  | $ | 4,772 |  |
| Capital expenditures | $ | 4,419 |  |  | $ | 365 |  |  | $ | 4,784 |  |  | $ | 1,018 |  |  | $ | 1,395 |  |  | $ | 2,413 |  |

[0000926326-14-000035:notes:109]
|  | Six Months Ended June 30, 2014 |  | Six Months Ended June 30, 2013 |
|  | Automation and Analytics |  | Medication Adherence |  | Total |  | Automation and Analytics |  | Medication Adherence |  | Total |
| Depreciation and amortization | $ | 5,942 |  |  | $ | 3,449 |  |  | $ | 9,391 |  |  | $ | 5,862 |  |  | $ | 3,382 |  |  | $ | 9,244 |  |
| Capital expenditures | $ | 6,167 |  |  | $ | 1,168 |  |  | $ | 7,335 |  |  | $ | 2,018 |  |  | $ | 3,733 |  |  | $ | 5,751 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000926326-14-000035:notes:110]
[same as prior period, unchanged from 0000926326-14-000010:notes:104]

[0000926326-14-000035:notes:111]
Prior to the first quarter of 2014, we organized our business into two operating business segments, the Acute Care and Non-Acute Care segments, which were based on the products' target customers. The Acute Care segment primarily included products and services sold to hospital customers, and the Non-Acute Care segment primarily included products and services sold to customers outside of hospital settings.

[0000926326-14-000035:notes:112]
In the first quarter of 2014, we realigned our segments based on the products we sell, regardless of who they are sold to because our business has evolved to be managed more on a product basis, rather than on a customer-type basis.  It has become more difficult to determine whether a customer is a hospital or a blend of hospitals and non-acute care facilities. We are at a point where many of our Acute Care and Non-Acute Care customers are converging to provide services across the continuum of care. These customers seek automation and analytics products that function across the various facilities they manage. We find ourselves providing solutions across multiple types of care environments. These customers are also interested in obtaining higher levels of adherence to prescribed medication regimens that our blister card products provide.

[0000926326-14-000035:notes:113]
Our two reportable segments are the Automation and Analytics segment and the Medication Adherence segment.  The Automation and Analytics segment is organized around the design, manufacturing, selling and servicing of medication and supply dispensing systems, pharmacy inventory management systems, and related software. The Medication Adherence segment includes primarily the manufacturing and selling of consumable medication blister cards, packaging equipment and ancillary products and services.

[0000926326-14-000035:notes:114]
Prior period amounts in the tables below have been recast to conform to the way we internally manage and monitor performance at the segment level during the current period.

[0000926326-14-000035:notes:115]
[same as prior period, unchanged from 0000926326-14-000010:notes:109]

[0000926326-14-000035:notes:116]
[same as prior period, unchanged from 0000926326-14-000010:notes:110]

[0000926326-14-000035:notes:117]
Since 1984, MTS has provided medication adherence solutions to the non-acute care market. In 2012, we acquired MTS. The solutions supplied by MTS provide automated and semi-automated equipment to assist institutional and retail pharmacists in filling medication orders into blister cards, the primary method of medication control in non-acute care settings. Completing the product solution are the consumables used by institutional and retail pharmacists to make the medication adherence package. MTS has developed process manufacturing capabilities as well as sales capabilities to market medication adherence solutions to institutional and retail pharmacies. As healthcare evolves, these medication adherence solutions are finding application in acute care settings as well. Our Medication Adherence segment represents all the products we sell to fulfill medication adherence needs through blister cards, blister card packaging equipment, and related software.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000926326-14-000035:notes:118]
[same as prior period, unchanged from 0000926326-14-000010:notes:113]

[0000926326-14-000035:notes:119]
[same as prior period, unchanged from 0000926326-14-000010:notes:114]

[0000926326-14-000035:notes:120]
[same as prior period, unchanged from 0000926326-14-000010:notes:115]

[0000926326-14-000035:notes:121]
[same as prior period, unchanged from 0000926326-14-000010:notes:116]

[0000926326-14-000035:notes:122]
For the six months ended June 30, 2014, we repurchased a total of $4.1 million or 145,737 shares, at an average cost of $27.92, including commissions. For details regarding our 2012 Stock Repurchase Program, please refer to Note 15, Stockholders' Equity, of our Annual Report on Form 10-K for the year ended December 31, 2013.

[0000926326-14-000035:notes:123]
From the inception of the 2012 Repurchase Program, we have repurchased a total of $25.0 million, or 1,030,382 shares at an average cost of $24.29 per share, including commissions. As of June 30, 2014, the maximum dollar value of shares that may yet be purchased under the plan is $25.0 million.


## omcl:AccruedLiabilitiesTextBlock

[0000926326-14-000035:notes:124]
[same as prior period, unchanged from 0000926326-14-000010:notes:119]

[0000926326-14-000035:notes:125]
(1) Fees paid pursuant to GPO agreements. Customers who buy our products pursuant to a GPO agreement obtain pre-negotiated contract terms and pricing.


## omcl:DeferredGrossProfitTableTextBlock

[0000926326-14-000035:notes:126]
[same as prior period, unchanged from 0000926326-14-000010:notes:120]

[0000926326-14-000035:notes:127]
|  | June 30, 2014 |  | December 31, 2013 |
| Sales of medication and supply dispensing systems and packaging equipment(1) | $ | 40,748 |  |  | $ | 29,040 |  |
| Cost of revenues, excluding installation costs | (10,003 | ) |  | (9,083 | ) |
| Deferred gross profit | $ | 30,745 |  |  | $ | 19,957 |  |


## omcl:DeferredGrossProfitTextBlock

[0000926326-14-000035:notes:128]
[same as prior period, unchanged from 0000926326-14-000010:notes:122]

[0000926326-14-000035:notes:129]
(1) Sales that have been delivered and invoiced and not yet installed, or sales that have been shipped and not invoiced and not yet installed.


## omcl:ImpairmentofSoftwareDevelopmentCostsTextBlock

[0000926326-14-000035:notes:130]
Impairment of Software Development Costs

[0000926326-14-000035:notes:131]
2013 Impairment

[0000926326-14-000035:notes:132]
As part of the continuing integration of MTS, in the first quarter of 2013, we reorganized our management team, including the software development department, within the Medication Adherence segment (formerly known as Non-Acute segment). Through the end of the first quarter of 2013, the Medication Adherence segment had capitalized approximately $1.8 million of software development costs associated with a software solution under development which was intended to assist pharmacies in manual packaging of prescriptions. In connection with our financial statement close process for the quarter ended March 31, 2013, our management reassessed the viability of this project and the net realizable value of capitalized costs in light of its decision to change the related product road map and redesign this product based on evolving market demands. As part of this redesign process, new functionality and capabilities will need to be added to the product before commercialization. This redesign is intended to provide a more robust global platform providing larger scalability and significant functionality not contained in our current beta version. As such, we have determined we can no longer support the technological feasibility of this project in conjunction with our software capitalization policy. Therefore, we charged these costs, in the amount of $1.8 million, ($0.03 per diluted share, net of tax), to expense as a component of research and development in the accompanying condensed consolidated statement of operations.


## omcl:NetInvestmentsInSalesTypeLeasesTextBlock

[0000926326-14-000035:notes:133]
[same as prior period, unchanged from 0000926326-14-000010:notes:125]

[0000926326-14-000035:notes:134]
[same as prior period, unchanged from 0000926326-14-000010:notes:126]

[0000926326-14-000035:notes:135]
|  | June 30, 2014 |  | December 31, 2013 |
| Net minimum lease payments to be received | $ | 17,559 |  |  | $ | 18,172 |  |
| Less unearned interest income portion | (1,214 | ) |  | (1,455 | ) |
| Net investment in sales-type leases | 16,345 |  |  | 16,717 |  |
| Less current portion(1) | (5,473 | ) |  | (5,232 | ) |
| Non-current net investment in sales-type leases(2) | $ | 10,872 |  |  | $ | 11,485 |  |

[0000926326-14-000035:notes:136]
(1)     A component of other current assets. This amount is net of an immaterial allowance for doubtful accounts as of June 30, 2014 and December 31, 2013.

[0000926326-14-000035:notes:137]
(2)     This amount is net of an immaterial allowance for doubtful accounts as of June 30, 2014 and December 31, 2013.
