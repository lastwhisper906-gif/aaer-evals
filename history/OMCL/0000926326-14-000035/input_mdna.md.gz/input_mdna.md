# OMCL MD&A — 0000926326-14-000035


## mdna

[0000926326-14-000035:mdna:1]
[same as prior period, unchanged from 0000926326-14-000010:mdna:1]

[0000926326-14-000035:mdna:2]
[same as prior period, unchanged from 0000926326-14-000010:mdna:2]

[0000926326-14-000035:mdna:3]
[same as prior period, unchanged from 0000926326-14-000010:mdna:3]

[0000926326-14-000035:mdna:4]
[same as prior period, unchanged from 0000926326-14-000010:mdna:4]

[0000926326-14-000035:mdna:5]
[same as prior period, unchanged from 0000926326-14-000010:mdna:5]

[0000926326-14-000035:mdna:6]
[same as prior period, unchanged from 0000926326-14-000010:mdna:6]

[0000926326-14-000035:mdna:7]
[same as prior period, unchanged from 0000926326-14-000010:mdna:7]

[0000926326-14-000035:mdna:8]
[same as prior period, unchanged from 0000926326-14-000010:mdna:8]

[0000926326-14-000035:mdna:9]
[same as prior period, unchanged from 0000926326-14-000010:mdna:9]

[0000926326-14-000035:mdna:10]
[same as prior period, unchanged from 0000926326-14-000010:mdna:10]

[0000926326-14-000035:mdna:11]
[same as prior period, unchanged from 0000926326-14-000010:mdna:11]

[0000926326-14-000035:mdna:12]
[same as prior period, unchanged from 0000926326-14-000010:mdna:12]

[0000926326-14-000035:mdna:13]
[same as prior period, unchanged from 0000926326-14-000010:mdna:13]

[0000926326-14-000035:mdna:14]
[same as prior period, unchanged from 0000926326-14-000010:mdna:14]

[0000926326-14-000035:mdna:15]
[same as prior period, unchanged from 0000926326-14-000010:mdna:15]

[0000926326-14-000035:mdna:16]
[same as prior period, unchanged from 0000926326-14-000010:mdna:16]

[0000926326-14-000035:mdna:17]
In the first quarter of 2014, we began to manage our business according to two product segments because many of our Acute Care and Non-Acute Care customers are converging to provide services across the continuum of care. These customers seek Automation and Analytics products that function across the various facilities they manage and we find ourselves providing solutions across multiple types of care environments. These customers are also interested in obtaining higher levels of adherence to prescribed medication regimens that our blister card products provide. Our business has evolved to be managed more on a product basis and it has become more difficult to determine whether a customer is a hospital or a blend of hospitals and non-acute care facilities. Our two product segments are Automation and Analytics and Medication Adherence. The Automation and Analytics segment is organized around the design, manufacturing, selling and servicing of medication and supply dispensing systems, pharmacy inventory management systems, and related software. The Medication Adherence segment includes primarily the manufacturing and selling of consumable medication blister cards, packaging equipment and ancillary products and services.

[0000926326-14-000035:mdna:18]
[same as prior period, unchanged from 0000926326-14-000010:mdna:18]

[0000926326-14-000035:mdna:19]
[same as prior period, unchanged from 0000926326-14-000010:mdna:19]

[0000926326-14-000035:mdna:20]
[same as prior period, unchanged from 0000926326-14-000010:mdna:20]

[0000926326-14-000035:mdna:21]
[same as prior period, unchanged from 0000926326-14-000010:mdna:21]

[0000926326-14-000035:mdna:22]
[same as prior period, unchanged from 0000926326-14-000010:mdna:22]

[0000926326-14-000035:mdna:23]
Our investments have been consistent with the strategies outlined above. To differentiate our solutions from others available in the market, we began shipping a refresh of our product line in 2011 which we market as G4. The G4 refresh included multiple new products and an upgrade product that allowed existing customers to augment their installations to obtain the most current technology that we provide. The G4 product refresh has been a key contributor to our growth, with 46% of our automation and analytics installed base ordering upgrades to their existing systems since the announcement of G4. In addition to enhanced capabilities, we have focused on attaining the highest quality and service measurements for G4 in the industry, while marketing the solution to new and existing customers. Our research and development efforts today are designed to bring new products to market beyond the G4 product line that we believe will meet customer needs in years to come.

[0000926326-14-000035:mdna:24]
[same as prior period, unchanged from 0000926326-14-000010:mdna:24]

[0000926326-14-000035:mdna:25]
27

[0000926326-14-000035:mdna:26]
as well as certain other voting rights and, therefore, we believe we have the ability to exert significant influence over this distributor's operations. Our proportionate equity share of the income of this distributor recognized in our financial statements for the three and six months ended June 30, 2014 was immaterial. We have also expanded our sales efforts to medication adherence customers in the United States which has allowed us to sell our automated dispensing solutions and other products to this market.

[0000926326-14-000035:mdna:27]
[same as prior period, unchanged from 0000926326-14-000010:mdna:27]

[0000926326-14-000035:mdna:28]
[same as prior period, unchanged from 0000926326-14-000010:mdna:28]

[0000926326-14-000035:mdna:29]
[same as prior period, unchanged from 0000926326-14-000010:mdna:29]

[0000926326-14-000035:mdna:30]
[same as prior period, unchanged from 0000926326-14-000010:mdna:30]

[0000926326-14-000035:mdna:31]
[same as prior period, unchanged from 0000926326-14-000010:mdna:31]

[0000926326-14-000035:mdna:32]
[same as prior period, unchanged from 0000926326-14-000010:mdna:32]

[0000926326-14-000035:mdna:33]
In addition to product solution sales, we provide services to our customers. Our healthcare customers expect a high degree of partnership involvement from their technology suppliers throughout their ownership of the products. We provide extensive installation planning and consulting as part of every product sale and included in the initial price of the solution. Our customers' medication control systems are mission critical to their success and our customers require these systems to be functional at all times. To help assure the maximum availability of our systems, our customers typically purchase maintenance and support contracts in one, two or five year increments.

[0000926326-14-000035:mdna:34]
The growth in our Automation and Analytics revenue for the three and six months ended June 30, 2014 was driven primarily by our success in consistently growing the number of our customer installations. Installed customers grew from 1,783 hospitals as of June 30, 2013 to 1,886 hospitals as of June 30, 2014. To a lesser extent, but of equal importance, revenue growth was also driven by our success in upgrading installed customers to newer G4 technology, which is in line with our strategy of striving to deliver differentiated innovation in our solutions. Our larger installed base has provided growth opportunities and, as a result, our service revenues have also grown for the six months ended June 30, 2014.

[0000926326-14-000035:mdna:35]
The growth in our Medication Adherence revenue for the three and six months ended June 30, 2014 was driven primarily by increased sales of our OnDemand medication packaging systems in the United States market and increased adoption of multi-medication adherence solutions used by patients in assisted living or home care in Europe. This growth is in line with our strategy to deliver solutions to markets outside the United States. On a geographic basis, the United States market did not contribute to, nor erode, the growth in our Medication Adherence business as the population of patients living in nursing homes in the United States has remained relatively constant over the past twelve months.

[0000926326-14-000035:mdna:36]
We strive to provide the best service possible, as measured by third party rating agencies and by our own surveys. Our long-term liabilities include long-term deferred service revenue of $21.3 million and $17.8 million as of June 30, 2014 and December 31, 2013, respectively. Our deferred service revenue will be amortized to service revenue as the service contracts are performed upon.

[0000926326-14-000035:mdna:37]
In the future, we expect our strategies to evolve as the business environment of our customers evolves, but our focus will remain on improving healthcare with solutions that improve patient and provider outcomes. We expect our investment in

[0000926326-14-000035:mdna:38]
differentiated products, new markets, and acquisitions and partnerships to continue. For the remainder of 2014, we also intend to continue to manage our business to operating profit margins similar to what we have achieved in the first half of the year.

[0000926326-14-000035:mdna:39]
29

[0000926326-14-000035:mdna:40]
[same as prior period, unchanged from 0000926326-14-000010:mdna:52]

[0000926326-14-000035:mdna:41]
The table below shows the components of our consolidated results of operations as percentages of total revenues for the three and six months ended June 30, 2014 and 2013 (in thousands, except percentages):

[0000926326-14-000035:mdna:42]
|  | Three Months Ended |
|  | June 30, 2014 |  | June 30, 2013 |
|  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |
| Product revenue | $ | 85,244 |  |  | 81.1 | % |  | $ | 75,581 |  |  | 80.7 | % |
| Service and other revenues | 19,808 |  |  | 18.9 | % |  | 18,105 |  |  | 19.3 | % |
| Total revenues | 105,052 |  |  | 100.0 | % |  | 93,686 |  |  | 100.0 | % |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product revenues | 41,003 |  |  | 39.0 | % |  | 36,286 |  |  | 38.7 | % |
| Cost of service and other revenues | 8,009 |  |  | 7.6 | % |  | 8,032 |  |  | 8.6 | % |
| Total cost of revenues | 49,012 |  |  | 46.7 | % |  | 44,318 |  |  | 47.3 | % |
| Gross profit | 56,040 |  |  | 53.3 | % |  | 49,368 |  |  | 52.7 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 6,471 |  |  | 6.2 | % |  | 7,150 |  |  | 7.6 | % |
| Selling, general and administrative | 37,011 |  |  | 35.2 | % |  | 32,859 |  |  | 35.1 | % |
| Total operating expenses | 43,482 |  |  | 41.4 | % |  | 40,009 |  |  | 42.7 | % |
| Income from operations | 12,558 |  |  | 12.0 | % |  | 9,359 |  |  | 10.0 | % |
| Interest and other income (expense), net | (40 | ) |  | — | % |  | 63 |  |  | 0.1 | % |
| Income before provision for income taxes | 12,518 |  |  | 11.9 | % |  | 9,422 |  |  | 10.1 | % |
| Provision for income taxes | 4,729 |  |  | 4.5 | % |  | 3,406 |  |  | 3.6 | % |
| Net income | $ | 7,789 |  |  | 7.4 | % |  | $ | 6,016 |  |  | 6.5 | % |

[0000926326-14-000035:mdna:43]
30

[0000926326-14-000035:mdna:44]
|  | Six Months Ended |
|  | June 30, 2014 |  | June 30, 2013 |
|  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |
| Product revenue | $ | 167,824 |  |  | 81.1 | % |  | $ | 144,817 |  |  | 80.1 | % |
| Service and other revenues | 38,992 |  |  | 18.9 | % |  | 35,979 |  |  | 19.9 | % |
| Total revenues | 206,816 |  |  | 100.0 | % |  | 180,796 |  |  | 100.0 | % |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product revenues | 79,903 |  |  | 38.6 | % |  | 69,833 |  |  | 38.6 | % |
| Cost of service and other revenues | 16,378 |  |  | 7.9 | % |  | 16,228 |  |  | 9.0 | % |
| Total cost of revenues | 96,281 |  |  | 46.6 | % |  | 86,061 |  |  | 47.6 | % |
| Gross profit | 110,535 |  |  | 53.4 | % |  | 94,735 |  |  | 52.4 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 12,592 |  |  | 6.1 | % |  | 15,104 |  |  | 8.4 | % |
| Selling, general and administrative | 75,431 |  |  | 36.5 | % |  | 66,104 |  |  | 36.6 | % |
| Total operating expenses | 88,023 |  |  | 42.6 | % |  | 81,208 |  |  | 45.0 | % |
| Income from operations | 22,512 |  |  | 10.9 | % |  | 13,527 |  |  | 7.5 | % |
| Interest and other income (expense), net | (296 | ) |  | (0.1 | )% |  | (159 | ) |  | (0.1 | )% |
| Income before provision for income taxes | 22,216 |  |  | 10.7 | % |  | 13,368 |  |  | 7.4 | % |
| Provision for income taxes | 8,233 |  |  | 4.0 | % |  | 3,967 |  |  | 2.2 | % |
| Net income | $ | 13,983 |  |  | 6.8 | % |  | $ | 9,401 |  |  | 5.2 | % |

[0000926326-14-000035:mdna:45]
[same as prior period, unchanged from 0000926326-14-000010:mdna:59]

[0000926326-14-000035:mdna:46]
31

[0000926326-14-000035:mdna:47]
Operations by Segment During the Three and Six Months Ended June 30, 2014

[0000926326-14-000035:mdna:48]
|  | Three Months Ended June 30, 2014 |  | Three Months Ended June 30, 2013 |
|  | Automation and Analytics |  | Medication Adherence |  | Total |  | Automation and Analytics |  | Medication Adherence |  | Total |
| Total revenues | $ | 84,702 |  |  | $ | 20,350 |  |  | $ | 105,052 |  |  | $ | 73,866 |  |  | $ | 19,820 |  |  | $ | 93,686 |  |
| Cost of revenues | 35,992 |  |  | 13,020 |  |  | 49,012 |  |  | 31,936 |  |  | 12,382 |  |  | 44,318 |  |
| Gross profit | 48,710 |  |  | 7,330 |  |  | 56,040 |  |  | 41,930 |  |  | 7,438 |  |  | 49,368 |  |
| Gross margin % | 57.5 | % |  | 36.0 | % |  | 53.3 | % |  | 56.8 | % |  | 37.5 | % |  | 52.7 | % |
| Operating expenses | 36,508 |  |  | 6,974 |  |  | 43,482 |  |  | 33,808 |  |  | 6,201 |  |  | 40,009 |  |
| Income (loss) from operations | $ | 12,202 |  |  | $ | 356 |  |  | $ | 12,558 |  |  | $ | 8,122 |  |  | $ | 1,237 |  |  | $ | 9,359 |  |
| Operating margin % | 14.4 | % |  | 1.7 | % |  | 12.0 | % |  | 11.0 | % |  | 6.2 | % |  | 10.0 | % |

[0000926326-14-000035:mdna:49]
Total revenues grew 12.1% for the three months ended June 30, 2014 compared with the same period last year. Overall product and service gross margins increased by 0.6 points for the three months ended June 30, 2014 compared to the same period in 2013 based upon improvement in Automation and Analytics and partially offset by a decline in Medication Adherence. Income from operations increased primarily on the performance of the Automation and Analytics segment.

[0000926326-14-000035:mdna:50]
|  | Six Months Ended June 30, 2014 |  | Six Months Ended June 30, 2013 |
|  | Automation and Analytics |  | Medication Adherence |  | Total |  | Automation and Analytics |  | Medication Adherence |  | Total |
| Total revenues | $ | 166,201 |  |  | $ | 40,615 |  |  | $ | 206,816 |  |  | $ | 142,579 |  |  | $ | 38,217 |  |  | $ | 180,796 |  |
| Cost of revenues | 70,932 |  |  | 25,349 |  |  | 96,281 |  |  | 62,212 |  |  | 23,849 |  |  | 86,061 |  |
| Gross profit | 95,269 |  |  | 15,266 |  |  | 110,535 |  |  | 80,367 |  |  | 14,368 |  |  | 94,735 |  |
| Gross margin % | 57.3 | % |  | 37.6 | % |  | 53.4 | % |  | 56.4 | % |  | 37.6 | % |  | 52.4 | % |
| Operating expenses | 73,910 |  |  | 14,113 |  |  | 88,023 |  |  | 66,912 |  |  | 14,296 |  |  | 81,208 |  |
| Income (loss) from operations | $ | 21,359 |  |  | $ | 1,153 |  |  | $ | 22,512 |  |  | $ | 13,455 |  |  | $ | 72 |  |  | $ | 13,527 |  |
| Operating margin % | 12.9 | % |  | 2.8 | % |  | 10.9 | % |  | 9.4 | % |  | 0.2 | % |  | 7.5 | % |

[0000926326-14-000035:mdna:51]
Total revenues grew 14.4% for the six months ended June 30, 2014 compared with the same period last year. Overall product and service gross margins increased by 1.0 point for the six months ended June 30, 2014 compared to the same period in 2013 from improvement in Automation and Analytics. Income from operations increased by $9.0 million primarily on the performance of Automation and Analytics.

[0000926326-14-000035:mdna:52]
[same as prior period, unchanged from 0000926326-14-000010:mdna:41]

[0000926326-14-000035:mdna:53]
Management's discussion and analysis of our financial condition and results of operations are based on our consolidated financial statements, which have been prepared in accordance with U.S. GAAP. The preparation of these financial statements requires us to make certain estimates and assumptions that affect the reported amounts of assets and liabilities, disclosure of any contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. We regularly review our estimates and assumptions, which are based on historical experience and various other factors that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of certain assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates and assumptions. We believe that the following critical accounting

[0000926326-14-000035:mdna:54]
32

[0000926326-14-000035:mdna:55]
policies are affected by significant judgments and estimates used in the preparation of our condensed consolidated financial statements:

[0000926326-14-000035:mdna:56]
[same as prior period, unchanged from 0000926326-14-000010:mdna:43]

[0000926326-14-000035:mdna:57]
[same as prior period, unchanged from 0000926326-14-000010:mdna:44]

[0000926326-14-000035:mdna:58]
[same as prior period, unchanged from 0000926326-14-000010:mdna:45]

[0000926326-14-000035:mdna:59]
[same as prior period, unchanged from 0000926326-14-000010:mdna:46]

[0000926326-14-000035:mdna:60]
[same as prior period, unchanged from 0000926326-14-000010:mdna:47]

[0000926326-14-000035:mdna:61]
During the six months ended June 30, 2014, there were no significant changes in our critical accounting policies and estimates.

[0000926326-14-000035:mdna:62]
Please refer to Management’s Discussion and Analysis of Financial Condition and Results of Operations contained in Part II, Item 7 of our Annual Report on Form 10-K for our fiscal year ended December 31, 2013 for a discussion of our critical accounting policies and estimates.

[0000926326-14-000035:mdna:63]
Recently Adopted and Issued Accounting Standards

[0000926326-14-000035:mdna:64]
Please refer to Part I, Note 1, Organization and Summary of Significant Accounting Policies, of this Quarterly Report on Form 10-Q for a description of recently adopted and issued accounting standards.

[0000926326-14-000035:mdna:65]
[same as prior period, unchanged from 0000926326-14-000010:mdna:101]

[0000926326-14-000035:mdna:66]
[same as prior period, unchanged from 0000926326-14-000010:mdna:55]

[0000926326-14-000035:mdna:67]
[same as prior period, unchanged from 0000926326-14-000010:mdna:62]

[0000926326-14-000035:mdna:68]
The tables below show our Automation and Analytics segment's results for the periods shown, and the change between those periods (in thousands, except percentages):

[0000926326-14-000035:mdna:69]
|  |  | Three Months Ended June 30, |  | Change in |  |
|  |  | 2014 |  | 2013 |  | $ |  | % |  |
| Product Revenue |  | $ | 65,722 |  |  | $ | 56,552 |  |  | $ | 9,170 |  |  | 16.2 |  | % |
| Service Revenue |  | 18,980 |  |  | 17,314 |  |  | 1,666 |  |  | 9.6 |  | % |
| Total revenues |  | 84,702 |  |  | 73,866 |  |  | 10,836 |  |  | 14.7 |  | % |
| Product Cost |  | 28,580 |  |  | 24,503 |  |  | 4,077 |  |  | 16.6 |  | % |
| Service Cost |  | 7,412 |  |  | 7,433 |  |  | (21 | ) |  | (0.3 | ) | % |
| Total cost of revenues |  | 35,992 |  |  | 31,936 |  |  | 4,056 |  |  | 12.7 |  | % |
| Product Margin |  | 37,142 |  |  | 32,049 |  |  | 5,093 |  |  | 15.9 |  | % |
| Service Margin |  | 11,568 |  |  | 9,881 |  |  | 1,687 |  |  | 17.1 |  | % |
| Gross profit |  | $ | 48,710 |  |  | $ | 41,930 |  |  | $ | 6,780 |  |  | 16.2 |  | % |
| Gross margin % |  | 57.5 | % |  | 56.8 | % |  |  |  | 0.7 |  | pps |

[0000926326-14-000035:mdna:70]
|  |  | Six Months Ended June 30, |  | Change in |  |
|  |  | 2014 |  | 2013 |  | $ |  | % |  |
| Product Revenue |  | $ | 128,842 |  |  | $ | 108,160 |  |  | $ | 20,682 |  |  | 19.1 | % |
| Service Revenue |  | 37,359 |  |  | 34,419 |  |  | 2,940 |  |  | 8.5 | % |
| Total revenues |  | 166,201 |  |  | 142,579 |  |  | 23,622 |  |  | 16.6 | % |
| Product Cost |  | 55,731 |  |  | 47,119 |  |  | 8,612 |  |  | 18.3 | % |
| Service Cost |  | 15,201 |  |  | 15,093 |  |  | 108 |  |  | 0.7 | % |
| Total cost of revenues |  | 70,932 |  |  | 62,212 |  |  | 8,720 |  |  | 14.0 | % |
| Product Margin |  | 73,111 |  |  | 61,041 |  |  | 12,070 |  |  | 19.8 | % |
| Service Margin |  | 22,158 |  |  | 19,326 |  |  | 2,832 |  |  | 14.7 | % |
| Gross profit |  | $ | 95,269 |  |  | $ | 80,367 |  |  | $ | 14,902 |  |  | 18.5 | % |
| Gross margin % |  | 57.3 | % |  | 56.4 | % |  |  |  | 0.9 | pps |

[0000926326-14-000035:mdna:71]
Revenues. We provide our Automation and Analytics customers with customized products that meet a wide variety of needs. These needs may vary significantly from customer to customer. Automation and Analytics products include software and service, highly customizable dispensing cabinets, and non-customized products from third parties such as carousels to store bulk medication.

[0000926326-14-000035:mdna:72]
The year over year growth in total revenues in our Analytics and Automation segment was driven primarily by our success in growing the number of our customer installations. We have historically measured the growth in our customer installations by the number of hospital installations. In the United States, our hospital installations grew from 1,783 as of June 30, 2013 to 1,886 as of June 30, 2014. To a lesser extent, but of equal importance, our segment's revenue growth was driven by success in upgrading installed customers to newer G4 technology, which is in line with our strategy of continually striving to deliver differentiated innovation in our solutions. Our larger installed based has provided growth opportunities and, as a result, our service revenues have also grown for the six months ended June 30, 2014.

[0000926326-14-000035:mdna:73]
The growth in product revenue for the three months ended June 30, 2014 was primarily driven by a $7.6 million increase in installations of medication cabinets and, to a lesser extent, of supply cabinets, a $1.3 million increase in lease renewal revenue attributable to two major customers, and a $0.3 million increase in revenues from other software products. The growth in service revenue for the three months ended June 30, 2014 was a result of increased service revenue due to growth in our installed base.

[0000926326-14-000035:mdna:74]
The $20.7 million growth in product revenue for the six months ended June 30, 2014 was primarily driven by the growth in customer installations of medication cabinets, and to a lesser extent, of supply cabinets. This growth was also attributable to our success in upgrading installed customers to newer G4 technology. Revenue from other software products also grew by $0.7 million due to increased sales. This increase was partly offset by a $0.8 million decrease in lease renewals, which consisted of a decline in the first quarter of 2014, but which was partly offset by an increase in lease renewals in the second quarter of 2014. Most of our five-year leases do not follow a linear pattern. We are seeing a decline in our overall lease business in absolute and annual dollars as new and existing customers are opting to purchase instead of lease. This pattern has driven fluctuations in our quarterly and year over year comparisons. The growth in service revenue for the six months ended June 30, 2014 was a result of the aforementioned increased service renewal revenue due to growth in our installed base.

[0000926326-14-000035:mdna:75]
Cost of Revenues. Cost of revenue and related margins have slight variations between products. Product cost of revenue has three general categories: (i) standard product costs - accounts for the majority of the product cost of revenues that are provided to customers and are inclusive of purchased material, labor to build the product, and overhead costs associated with production; (ii) installation costs - because Omnicell installs its equipment at the customer site, these are costs of the field installation personnel, including labor, travel expense, and other expenses; and (iii) other costs - these costs include variances in standard costs and overhead, scrap costs, rework, warranty, provisions for excess and obsolete inventory and amortization of software development costs as product costs.

[0000926326-14-000035:mdna:76]
The increase in product costs for the three months ended June 30, 2014 was primarily a function of increased revenues driven by the growth in customer installations, which accounted for $3.2 million of the increase. To a lesser extent, the increase in product costs was due to a change in product mix. Installation costs also increased by $0.7 million and amortization of capitalized software increased by $0.2 million. Service costs decreased slightly for the three months ended June 30, 2014 compared to the same period last year.

[0000926326-14-000035:mdna:77]
The increase in product costs for the six months ended June 30, 2014 was primarily a function of increased revenue driven by the growth in customer installations, which accounted for $7.5 million of the increase. To a lesser extent, the increase in product costs was due to a change in product mix. Installation costs also increased by $1.4 million and amortization of capitalized software increased by $0.5 million. This was slightly offset by $0.9 million in improved factory utilization. Service costs remained relatively flat for the six months ended June 30, 2014, as we were able to service a larger installed base with the same resources.

[0000926326-14-000035:mdna:78]
Gross Profit. Gross profit dollars on product revenue increased during the three months ended June 30, 2014 as a result of the overall increase in product revenue. The increase in gross profit on service revenue for the three months ended June 30, 2014 reflects higher service revenues without a consistent increase in service staffing or spare parts usage. This increased efficiency is a result of higher reliability rates of our G4 product platform as compared to previous products.

[0000926326-14-000035:mdna:79]
Gross profit on product revenue increased during the six months ended June 30, 2014 as a result of the aforementioned overall increase in product revenue. The increase in gross profit on service revenue for the six months ended June 30, 2014 reflects higher service revenues due to growth in our installed base, and relatively flat year over year service costs.

[0000926326-14-000035:mdna:80]
[same as prior period, unchanged from 0000926326-14-000010:mdna:69]

[0000926326-14-000035:mdna:81]
The tables below show our Medication Adherence segment's results for the periods shown, and the change between those periods (in thousands, except percentages):

[0000926326-14-000035:mdna:82]
|  |  | Three Months Ended June 30, |  | Change in |  |
|  |  | 2014 |  | 2013 |  | $ |  | % |  |
| Product Revenue |  | $ | 19,522 |  |  | $ | 19,029 |  |  | $ | 493 |  |  | 2.6 |  | % |
| Service Revenue |  | 828 |  |  | 791 |  |  | 37 |  |  | 4.7 |  | % |
| Total revenues |  | 20,350 |  |  | 19,820 |  |  | 530 |  |  | 2.7 |  | % |
| Product Cost |  | 12,423 |  |  | 11,783 |  |  | 640 |  |  | 5.4 |  | % |
| Service Cost |  | 597 |  |  | 599 |  |  | (2 | ) |  | (0.3 | ) | % |
| Total cost of revenues |  | 13,020 |  |  | 12,382 |  |  | 638 |  |  | 5.2 |  | % |
| Product Margin |  | 7,099 |  |  | 7,246 |  |  | (147 | ) |  | (2.0 | ) | % |
| Service Margin |  | 231 |  |  | 192 |  |  | 39 |  |  | 20.3 |  | % |
| Gross profit |  | $ | 7,330 |  |  | $ | 7,438 |  |  | $ | (108 | ) |  | (1.5 | ) | % |
| Gross margin % |  | 36.0 | % |  | 37.5 | % |  |  |  | (1.5 | ) | pps |

[0000926326-14-000035:mdna:83]
|  |  | Six Months Ended June 30, |  | Change in |  |
|  |  | 2014 |  | 2013 |  | $ |  | % |  |
| Product Revenue |  | $ | 38,982 |  |  | $ | 36,657 |  |  | $ | 2,325 |  |  | 6.3 | % |
| Service Revenue |  | 1,633 |  |  | 1,560 |  |  | 73 |  |  | 4.7 | % |
| Total revenues |  | 40,615 |  |  | 38,217 |  |  | 2,398 |  |  | 6.3 | % |
| Product Cost |  | 24,172 |  |  | 22,714 |  |  | 1,458 |  |  | 6.4 | % |
| Service Cost |  | 1,177 |  |  | 1,135 |  |  | 42 |  |  | 3.7 | % |
| Total cost of revenues |  | 25,349 |  |  | 23,849 |  |  | 1,500 |  |  | 6.3 | % |
| Product Margin |  | 14,810 |  |  | 13,943 |  |  | 867 |  |  | 6.2 | % |
| Service Margin |  | 456 |  |  | 425 |  |  | 31 |  |  | 7.3 | % |
| Gross profit |  | $ | 15,266 |  |  | $ | 14,368 |  |  | $ | 898 |  |  | 6.3 | % |
| Gross margin % |  | 37.6 | % |  | 37.6 | % |  |  |  |  | — | pps |

[0000926326-14-000035:mdna:84]
Revenues. The year over year growth in total revenues in our Medication Adherence segment was due to increased sales of OnDemand medication packaging systems in the United States market and increased adoption of our multi-medication consumable products by patients in Europe. Our multi-medication consumable products help to organize multiple oral solid medications by time of day and day of the week, giving patients an instant visual reinforcement of what to take and when. This helps to improve compliance for patients in assisted living, group homes or home care who struggle with complex prescription regimens. On a geographic basis, the United States market had a neutral impact on this segment, neither contributing to nor eroding the growth in our business as the population of patients living in nursing homes who are most likely to use our products has remained relatively constant over the past twelve months.

[0000926326-14-000035:mdna:85]
The increase in product revenue for the three months ended June 30, 2014 was primarily due to a $0.5 million increase in sales of our OnDemand medication packaging systems. Service revenue remained relatively flat and was commensurate with the modest growth in our installed base.

[0000926326-14-000035:mdna:86]
The growth in product revenues for the six months ended June 30, 2014 was primarily due to increased adoption of our OnDemand medication packaging systems in the United States market and increased adoption of our multi-medication consumable products in Europe. Approximately $1.3 million of the increase in product revenue was attributable to increased sales of OnDemand medication packaging systems and $1.0 million was due to increased sales of our multi-medication consumable products. Service revenue remained relatively flat and was commensurate with the modest growth in our installed based.

[0000926326-14-000035:mdna:87]
Cost of Revenues. The increase in product costs for the three and six months ended June 30, 2014 was attributable to product revenue growth, initial costs of ramping up new production equipment and changes in product mix. Service costs remained relatively flat consistent with the revenue trend.

[0000926326-14-000035:mdna:88]
37

[0000926326-14-000035:mdna:89]
Gross Profit. The decrease in gross profit on product revenue for the three months ended June 30, 2014 was primarily due to initial costs of ramping up new production equipment and a product mix shift towards lower margin medication adherence solutions. Gross profit on service revenue for the three and six months ended June 30, 2014 compared to the same period last year remained relatively flat.

[0000926326-14-000035:mdna:90]
Gross profit on product revenue for the six months ended June 30, 2014 compared to the same period last year remained relatively flat.

[0000926326-14-000035:mdna:91]
[same as prior period, unchanged from 0000926326-14-000010:mdna:75]

[0000926326-14-000035:mdna:92]
Automation and Analytics Segment

[0000926326-14-000035:mdna:93]
The tables below show our Automation and Analytics segment's operating expenses for the three and six months ended June 30, 2014 and 2013 and the change between those periods (in thousands, except percentages):

[0000926326-14-000035:mdna:94]
|  | Three Months Ended June 30, |  | Change in |  |
|  | 2014 |  | 2013 |  | $ |  | % |  |
| Gross profit | $ | 48,710 |  |  | $ | 41,930 |  |  | $ | 6,780 |  |  | 16.2 |  | % |
| Research and development | 5,051 |  |  | 6,103 |  |  | (1,052 | ) |  | (17.2 | ) | % |
| Selling, general and administrative | 31,457 |  |  | 27,705 |  |  | 3,752 |  |  | 13.5 |  | % |
| Total operating expenses | 36,508 |  |  | 33,808 |  |  | 2,700 |  |  | 8.0 |  | % |
| Operating income | $ | 12,202 |  |  | $ | 8,122 |  |  | $ | 4,080 |  |  | 50.2 |  | % |
| Operating margin | 14.4 | % |  | 11.0 | % |  |  |  | 3.4 |  | pps |

[0000926326-14-000035:mdna:95]
|  | Six Months Ended June 30, |  | Change in |  |
|  | 2014 |  | 2013 |  | $ |  | % |  |
| Gross profit | $ | 95,269 |  |  | $ | 80,367 |  |  | $ | 14,902 |  |  | 18.5 |  | % |
| Research and development | 10,019 |  |  | 11,334 |  |  | (1,315 | ) |  | (11.6 | ) | % |
| Selling, general and administrative | 63,891 |  |  | 55,578 |  |  | 8,313 |  |  | 15.0 |  | % |
| Total operating expenses | 73,910 |  |  | 66,912 |  |  | 6,998 |  |  | 10.5 |  | % |
| Operating income | $ | 21,359 |  |  | $ | 13,455 |  |  | $ | 7,904 |  |  | 58.7 |  | % |
| Operating margin | 12.9 | % |  | 9.4 | % |  |  |  | 3.5 |  | pps |

[0000926326-14-000035:mdna:96]
Research and Development. The decrease in research and development expenses for the three months ended June 30, 2014 was primarily driven by a $1.3 million increase in capitalized software costs due to the higher level of post-feasibility beta testing which therefore decreases our research and development expenses, partially offset by an increase of $0.2 million in employee-related expenses due to increased staffing and higher year over year benefit costs.

[0000926326-14-000035:mdna:97]
The decrease in research and development expenses for the six months ended June 30, 2014 was primarily driven by a $2.3 million increase in capitalized software costs due to the higher level of post-feasibility beta testing which therefore decreases our research and development expenses,, partially offset by an increase of $0.7 million in employee-related expenses due to increased staffing and higher year over year benefit costs and $0.3 million increase in consulting-related expense.

[0000926326-14-000035:mdna:98]
[same as prior period, unchanged from 0000926326-14-000010:mdna:79]

[0000926326-14-000035:mdna:99]
Selling, General and Administrative. The increase in selling, general and administrative expenses for the three months ended June 30, 2014 was driven by the following: $0.7 million in employee-related expenses due to increased staffing and higher year over year benefit costs, $0.7 million in increased freight costs due to a higher volume of shipments along with expenses associated with inefficiencies switching from one freight vendor to another, $0.6 million in commission expenses associated with increased revenues, $0.6 million in consulting and professional fees driven by merger and acquisition-related activities and increased accounting and auditing fees, $0.4 million in travel and entertainment to support company growth, $0.3 million in Group Purchasing Organization fees due to increased invoicing and collections, $0.2 million in bad debt expense due to an increase in specific reserves and $0.2 million in maintenance contracts for software licenses.

[0000926326-14-000035:mdna:100]
The increase in selling, general and administrative expenses for the six months ended June 30, 2014 was driven primarily by $2.8 million in employee-related expenses due to increased staffing and higher year over year benefit costs, including a $1.1 million increase in variable compensation expense which was due to achieving our company goals in the current year, compared to not achieving our goals in the quarter ended June 30, 2013, $1.4 million in commission expenses associated with increased revenues, $1.4 million in consulting and professional fees driven by merger and acquisition-related activities and increased accounting and auditing fees, $0.8 million in increased freight costs due to a higher volume of shipments along with expenses associated with inefficiencies switching from one freight vendor to another, $0.6 million in travel and entertainment to support company growth, $0.5 million in Group Purchasing Organization fees due to increased

[0000926326-14-000035:mdna:101]
39

[0000926326-14-000035:mdna:102]
invoicing and collections, $0.3 million in bad debt expense due to an increase in specific reserves and $0.2 million in maintenance contracts for software licenses.

[0000926326-14-000035:mdna:103]
[same as prior period, unchanged from 0000926326-14-000010:mdna:81]

[0000926326-14-000035:mdna:104]
Medication Adherence Segment

[0000926326-14-000035:mdna:105]
The tables below show our Medication Adherence segment's operating expenses for the three and six months ended June 30, 2014 and 2013 and the change between those periods (in thousands, except percentages):

[0000926326-14-000035:mdna:106]
|  | Three Months Ended June 30, |  | Change in |  |
|  | 2014 |  | 2013 |  | $ |  | % |  |
| Gross profit | $ | 7,330 |  |  | $ | 7,438 |  |  | $ | (108 | ) |  | (1.5 | ) | % |
| Research and development | 1,420 |  |  | 1,047 |  |  | 373 |  |  | 35.6 |  | % |
| Selling, general and administrative | 5,554 |  |  | 5,154 |  |  | 400 |  |  | 7.8 |  | % |
| Total operating expenses | 6,974 |  |  | 6,201 |  |  | 773 |  |  | 12.5 |  | % |
| Operating income | $ | 356 |  |  | $ | 1,237 |  |  | $ | (881 | ) |  | (71.2 | ) | % |
| Operating margin | 1.7 | % |  | 6.2 | % |  |  |  | (4.5 | ) | pps |

[0000926326-14-000035:mdna:107]
|  | Six Months Ended June 30, |  | Change in |  |
|  | 2014 |  | 2013 |  | $ |  | % |  |
| Gross profit | $ | 15,266 |  |  | $ | 14,368 |  |  | $ | 898 |  |  | 6.3 |  | % |
| Research and development | 2,573 |  |  | 3,770 |  |  | (1,197 | ) |  | (31.8 | ) | % |
| Selling, general and administrative | 11,540 |  |  | 10,526 |  |  | 1,014 |  |  | 9.6 |  | % |
| Total operating expenses | 14,113 |  |  | 14,296 |  |  | (183 | ) |  | (1.3 | ) | % |
| Operating income | $ | 1,153 |  |  | $ | 72 |  |  | $ | 1,081 |  |  | 1,501.4 |  | % |
| Operating margin | 2.8 | % |  | 0.2 | % |  |  |  | 2.6 |  | pps |

[0000926326-14-000035:mdna:108]
Research and Development. The increase in research and development expenses for the three months ended June 30, 2014 was primarily due to a $0.2 million increase in salaries and benefits as a result of an increase in headcount, and $0.2 million increase in project-related consulting and hardware expenses.

[0000926326-14-000035:mdna:109]
The decrease in research and development expenses for the six months ended June 30, 2014 was primarily due to a one-time $1.8 million write-off of previously capitalized software development costs in the first quarter of 2013, partially offset by a $0.4 million increase in headcount and personnel-related costs, which includes salaries for new hires, stock-based compensation and consulting services, and a $0.1 million increase in project-related hardware expenses as we continued our efforts to develop additional functionality to our existing products.

[0000926326-14-000035:mdna:110]
We expect research and development expenses to remain relatively flat as a percentage of our revenue on an annual basis and to grow in absolute dollars in the future as our revenue grows to improve and enhance our existing technologies and to create new technologies in health care automation.

[0000926326-14-000035:mdna:111]
Selling, General and Administrative. The increase in selling, general and administrative expenses for the three months ended June 30, 2014 was primarily attributable to a $0.3 million increase in headcount expenses, and a $0.1 million increase in commissions due to a change in the commission plan.

[0000926326-14-000035:mdna:112]
The increase in selling, general and administrative expenses for the six months ended June 30, 2014 was primarily attributable to a $0.6 million increase in headcount expenses, $0.2 million increase in commissions due to a change in the commission plan, and $0.1 million increase in travel-related expenses.

[0000926326-14-000035:mdna:113]
We expect selling, general, and administrative expenses to remain relatively flat as a percentage of our revenue on an annual basis and to grow in absolute dollars in the future as our revenue grows to support our anticipated growth as well as international expansion efforts.

[0000926326-14-000035:mdna:114]
[same as prior period, unchanged from 0000926326-14-000010:mdna:82]

[0000926326-14-000035:mdna:115]
The annual effective tax rate before discrete items was 39.2% and 38.7% for the six months ended June 30, 2014     and 2013, respectively. The increase in the estimated annual effective tax rate for the six months ended June 30, 2014 compared to the same period in 2013 was primarily due to the expiration of the federal research and development credit as of December 31, 2013.  This increase was partially offset by a decrease in other non-deductible expenditures. The impacts of these amounts were 2.3% and (1.8)%, respectively.

[0000926326-14-000035:mdna:116]
[same as prior period, unchanged from 0000926326-14-000010:mdna:84]

[0000926326-14-000035:mdna:117]
We had cash and cash equivalents of $126.4 million at June 30, 2014, compared to $104.5 million at December 31, 2013. All of our cash and cash equivalents are invested in demand deposits and money market funds.

[0000926326-14-000035:mdna:118]
In September 2013, we entered into a Credit Agreement with Wells Fargo Bank, National Association, as administrative agent, and the lenders from time to time thereto, which provides for a $75.0 million revolving credit facility to be used for general corporate purposes, including future acquisitions. The Credit Agreement permits us to request one or more increases in the aggregate commitment provided such increases do not exceed $25.0 million in the aggregate. The Credit Agreement contains affirmative, negative and financial covenants that require us to, among other things, maintain a maximum consolidated total leverage ratio and a minimum consolidated fixed charge coverage ratio, in each case, as of the last day of each fiscal quarter. We were in full compliance with all covenants at June 30, 2014 and for the all periods since the commencement of the Credit Agreement. For additional details, refer to Note 16, Credit Agreement, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000926326-14-000035:mdna:119]
[same as prior period, unchanged from 0000926326-14-000010:mdna:87]

[0000926326-14-000035:mdna:120]
Cash flows for the six months ended June 30, 2014 and 2013, and the change between those periods, are as follows (in thousands):

[0000926326-14-000035:mdna:121]
|  | Six Months Ended June 30, |  |  |
|  | 2014 |  | 2013 |  | Change |
| Net cash provided by operating activities | $ | 25,421 |  |  | $ | 21,228 |  |  | $ | 4,193 |  |
| Net cash used in investing activities | (13,033 | ) |  | (8,969 | ) |  | (4,064 | ) |
| Net cash provided by financing activities | 9,341 |  |  | 12,807 |  |  | (3,466 | ) |
| Effect of exchange rate changes on cash and cash equivalents | 119 |  |  | (45 | ) |  | 164 |  |
| Net increase in cash and cash equivalents | $ | 21,848 |  |  | $ | 25,021 |  |  | $ | (3,173 | ) |

[0000926326-14-000035:mdna:122]
Operating activities. During the six months ended June 30, 2014, cash provided by operating activities consisted of net income of $14.0 million and non-cash charges of $16.3 million, offset by a $4.9 million decrease in net operating assets and liabilities. Our non-cash charges consisted primarily of depreciation and amortization of $9.4 million, stock-based compensation expense of $5.4 million, income tax benefits from employee stock plans of $3.1 million and deferred income taxes of $0.9 million, offset by $3.3 million in excess tax benefits from employee stock plans. The main drivers in the change in our net operating assets and liabilities were a $24.4 million increase in accounts receivable due to increased billing primarily from increased shipments of medication and supply cabinets, a $3.9 million decrease in accrued compensation primarily due to incentive bonus payouts, and lower accrued commissions due to higher bookings in the fourth quarter of 2013 compared to the current year to date period, offset by $10.8 million increase in deferred gross profit due to increase in products shipped and invoiced but not yet installed, as well as products shipped and uninvoiced and not yet installed, $2.6 million increase in deferred service revenues primarily due to increase in new third-party leases generated and billed, $2.4 million increase primarily in trade accounts payable due to growth in our business activities, $2.4 million increase in accrued liabilities due to growth in business activities, $2.1 million decrease in prepaid expenses primarily due to decrease in commissions driven by higher bookings in the fourth quarter of 2013 compared to the current year to date period, $1.6 million decrease in other current assets and $0.8 million increase in other long-term tax liabilities.

[0000926326-14-000035:mdna:123]
During the six months ended June 30, 2013, cash provided by operating activities consisted of net income of $9.4 million and non-cash charges of $16.8 million, offset by a $5.0 million decrease in net operating assets and liabilities. Our non-cash charges consisted primarily of depreciation and amortization of $9.2 million, stock-based compensation of $5.6 million, $1.8 million asset impairment charges related a software development project, offset by $1.3 million in excess tax benefits of  from employee stock plans. The main drivers in the change in our net operating assets and liabilities were an $8.8 million increase in accounts receivable due to increased billings, $1.3 million decrease in deferred service revenue, $0.8 million decrease in accounts payable, offset by $4.6 million increase in deferred gross profit, and $2.1 million increase in accrued liabilities.

[0000926326-14-000035:mdna:124]
Investing activities. Net cash used in investing activities for the six months ended June 30, 2014 consisted primarily of $7.3 million for purchases of property and equipment, primarily for software license and software upgrades, and $5.5 million expended for capitalized software development costs.

[0000926326-14-000035:mdna:125]
Net cash used in investing activities for the six months ended June 30, 2013 consisted primarily of $5.7 million for purchases of property and equipment, and $3.2 million expended for capitalized software development costs.

[0000926326-14-000035:mdna:126]
Financing activities. Net cash provided by financing activities during the six months ended June 30, 2014 consisted of $11.8 million in proceeds from employee stock option exercises and employee stock plan purchases, $3.3 million in excess tax benefits from employee stock plans, offset by $4.1 million in cash used for stock repurchases under our 2012 Stock Repurchase Program and $1.7 million in employees' taxes paid related to restricted stock units.

[0000926326-14-000035:mdna:127]
Net cash provided by financing activities during the six months ended June 30, 2013 consisted primarily of $11.5 million in proceeds from the employee stock option exercises and employee stock plan purchases, and $1.3 million in excess tax benefits from employee stock plans.

[0000926326-14-000035:mdna:128]
[same as prior period, unchanged from 0000926326-14-000010:mdna:93]

[0000926326-14-000035:mdna:129]
There were no material changes to our contractual obligations during the six months ended June 30, 2014. For a description of our facility leases and contractual obligations, please refer to our Annual Report on Form 10-K for the year ended December 31, 2013 and the Notes to the Consolidated Financial Statements included therein.

[0000926326-14-000035:mdna:130]
The following table summarizes our contractual obligations at June 30, 2014 (in thousands):

[0000926326-14-000035:mdna:131]
|  | Total |  | Less than one year |  | One to three years |  | Four to five years |  | More than five years |
| Operating leases (1) (2) | $ | 39,042 |  |  | $ | 2,926 |  |  | $ | 10,750 |  |  | $ | 8,766 |  |  | $ | 16,600 |  |
| Commitments to contract manufacturers and suppliers (3) | 11,290 |  |  | 11,290 |  |  | — |  |  | — |  |  | — |  |
| Total (4) | $ | 50,332 |  |  | $ | 14,216 |  |  | $ | 10,750 |  |  | $ | 8,766 |  |  | $ | 16,600 |  |

[0000926326-14-000035:mdna:132]
[same as prior period, unchanged from 0000926326-14-000010:mdna:97]

[0000926326-14-000035:mdna:133]
[same as prior period, unchanged from 0000926326-14-000010:mdna:98]

[0000926326-14-000035:mdna:134]
[same as prior period, unchanged from 0000926326-14-000010:mdna:99]

[0000926326-14-000035:mdna:135]
| (4) | At June 30, 2014, we have recorded $5.8 million for uncertain tax positions under long term liabilities, in accordance with U.S. GAAP. As these liabilities do not reflect actual tax assessments, the timing and amount of payments we might be required to make will depend upon a number of factors. Accordingly, as the timing and amount of payment cannot be estimated, a $5.8 million of uncertain tax position liability has not been included in the contractual obligations table. |

[0000926326-14-000035:mdna:136]
42

[0000926326-14-000035:mdna:137]
[same as prior period, unchanged from 0000926326-14-000010:mdna:103]

[0000926326-14-000035:mdna:138]
As of June 30, 2014, we had no off-balance sheet arrangements as defined in Regulation S-K 303(a)(4)(ii) of the Securities Exchange Act of 1934, as amended, and the instructions thereto.
