# OMCL note change history — 0000926326-14-000010 → 0000926326-14-000035


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2014-08-07):
[0000926326-14-000035:note_history:1]
We may from time to time become involved in certain legal proceedings in the ordinary course of business. We are not a party to any legal proceedings that management believes may have a material impact on Omnicell's financial position or results of operations.

- changed (2014-08-07):
[0000926326-14-000035:note_history:2]
From time to time, we may also warrant that our professional services will be performed in a good and workmanlike manner or in a professional manner consistent with industry standards. We generally seek to disclaim most warranties, including any implied or statutory warranties such as warranties of merchantability, fitness for a particular purpose, title, quality and non-infringement, as well as any liability with respect to incidental, consequential, special, exemplary, punitive or similar damages. In some states, such disclaimers may not be enforceable. If necessary, we would provide for the estimated cost of product and service warranties based on specific warranty claims and claim history. We have not been subject to any significant claims for such losses and have not incurred any material costs in defending or settling claims related to these indemnification obligations. Accordingly, we believe it is unlikely that we will be required to pay any material amounts pursuant to these indemnification obligations or potential warranty claims and, therefore, no material liabilities have been recorded for such indemnification obligations as of June 30, 2014 or December 31, 2013.
  (was, 2014-05-12, similarity 0.9962):
[0000926326-14-000010:note_history:2]
From time to time, we may also warrant that our professional services will be performed in a good and workmanlike manner or in a professional manner consistent with industry standards. We generally seek to disclaim most warranties, including any implied or statutory warranties such as warranties of merchantability, fitness for a particular purpose, title, quality and non-infringement, as well as any liability with respect to incidental, consequential, special, exemplary, punitive or similar damages. In some states, such disclaimers may not be enforceable. If necessary, we would provide for the estimated cost of product and service warranties based on specific warranty claims and claim history. We have not been subject to any significant claims for such losses and have not incurred any material costs in defending or settling claims related to these indemnification obligations. Accordingly, we believe it is unlikely that we will be required to pay any material amounts pursuant to these indemnification obligations or potential warranty claims and, therefore, no material liabilities have been recorded for such indemnification obligations as of March 31, 2014 or December 31, 2013.

- removed (2014-08-07):
[0000926326-14-000010:note_history:3]
On March 8, 2013, Bobbi Polanco (“Polanco”) filed a putative class action complaint in the United States District Court for the District of New Jersey (the "Court") against Omnicell and certain of our customers (Case No. 1:13-cv-01417-NLH-KLM) alleging breach of state security notification laws, violations of state consumer fraud laws, fraud, negligence and conspiracy relating to the theft of an Omnicell electronic device containing medication dispensing cabinet log files, including certain patient health information, and subsequent notification of this unauthorized disclosure of personal health information. Polanco is seeking an injunction against the defendants to prevent each of them from committing the acts complained of in the future and monetary damages, costs and expenses. On May 2, 2013, the Court entered an order to show cause which provided, in relevant part, that Polanco is required to show cause as to why the case should not be dismissed for lack of subject matter jurisdiction. On May 13, 2013, Polanco filed an amended complaint. On May 31, 2013, Omnicell filed a motion to dismiss the complaint on the grounds that Polanco failed to satisfy constitutional standing requirements and that she failed to state a claim against Omnicell  for violating  state data breach notification statutes, consumer fraud, common law fraud, negligence and conspiracy. Omnicell also joined in the arguments of the other defendants seeking dismissal. On July 1, 2013, Polanco filed an opposition to the motions to dismiss. On July 15, 2013, Omnicell filed its reply to the opposition from Polanco. In December 2013, the Court granted the defendants' motions to dismiss without prejudice. Polanco failed to file an appeal of the Court's decision by the January 27, 2014 deadline.

- removed (2014-08-07):
[0000926326-14-000010:note_history:4]
As required under ASC 450, Contingencies, we accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss. We did not record any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that any potential loss, while reasonably possible, was not probable. We believe that we have valid defenses with respect to legal proceedings pending against us. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of this contingency or because of the diversion of management's attention and the creation of significant expenses.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2014-08-07):
[0000926326-14-000035:note_history:5]
Basis of presentation. These interim condensed consolidated financial statements are unaudited but reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of Omnicell and our subsidiaries as of June 30, 2014, the results of our operations and comprehensive income for the three and six months ended June 30, 2014 and 2013 and our cash flows for the six months ended June 30, 2014 and 2013. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and accompanying notes included in our Annual Report on Form 10-K for the year ended December 31, 2013.
  (was, 2014-05-12, similarity 0.9207):
[0000926326-14-000010:note_history:5]
Basis of presentation. These interim condensed consolidated financial statements are unaudited but reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of Omnicell and its subsidiaries as of March 31, 2014, the results of their operations, comprehensive income and cash flows for the three months ended March 31, 2014 and 2013. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“GAAP”), have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and accompanying notes included in our Annual Report on Form 10-K for the year ended December 31, 2013.

- added (2014-08-07):
[0000926326-14-000035:note_history:6]
Our results of operations, comprehensive income for the three and six months ended June 30, 2014 and cash flows for the six months ended June 30, 2014 are not necessarily indicative of results that may be expected for the year ending December 31, 2014, or for any future period.

- changed (2014-08-07):
[0000926326-14-000035:note_history:7]
Concentration of credit risk. Financial instruments that may potentially subject us to concentrations of credit risk consist principally of cash equivalents and accounts receivable. Cash equivalents are maintained with several financial institutions and may exceed the amount of insurance provided on such balances. The majority of our accounts receivable are derived from sales to customers for commercial applications. We perform ongoing credit evaluations of our customers’ financial condition and limit the amount of credit extended when deemed necessary but generally require no collateral. We maintain reserves for potential credit losses. Our products are broadly distributed and there was no single customer accounting for 10% or more of revenues in the three and six months ended June 30, 2014 and 2013. Additionally, there was no single customer accounting for 10% or more of accounts receivable at June 30, 2014 or December 31, 2013. We believe that we have no significant concentrations of credit risk at June 30, 2014.
  (was, 2014-05-12, similarity 0.9664):
[0000926326-14-000010:note_history:7]
Concentration of credit risk. Financial instruments that may potentially subject us to concentrations of credit risk consist principally of cash equivalents and accounts receivable. Cash equivalents are maintained with several financial institutions and may exceed the amount of insurance provided on such balances. The majority of our accounts receivable are derived from sales to customers for commercial applications. We perform ongoing credit evaluations of our customers’ financial condition and limit the amount of credit extended when deemed necessary but generally require no collateral. We maintain reserves for potential credit losses. Our products are broadly distributed and there was no single customer accounting for 10% or more of revenues in the three months ended March 31, 2014. Additionally, there was no single customer accounting for 10% or more of accounts receivable at March 31, 2014 or December 31, 2013. We believe that we have no significant concentrations of credit risk at March 31, 2014.

- changed (2014-08-07):
[0000926326-14-000035:note_history:8]
Dependence on suppliers. We have a supply agreement with one primary supplier for construction and supply of several sub-assemblies and inventory management of sub-assemblies used in our hardware products. There are no minimum purchase requirements. The contract may be terminated by either the supplier or by us without cause and at any time upon delivery of two months’ notice. Purchases from this supplier for the three months ended June 30, 2014 and 2013 totaled approximately $8.3 million and $6.7 million, respectively, and $17.2 million and $13.9 million for the six months ended June 30, 2014 and 2013, respectively.
  (was, 2014-05-12, similarity 0.9163):
[0000926326-14-000010:note_history:8]
Dependence on suppliers. We have a supply agreement with one primary supplier for construction and supply of several sub-assemblies and inventory management of sub-assemblies used in our hardware products. There are no minimum purchase requirements. The contract may be terminated by either the supplier or by us without cause and at any time upon delivery of two months’ notice. Purchases from this supplier for the three months ended March 31, 2014 and 2013 totaled approximately $8.9 million and $7.2 million, respectively.

- changed (2014-08-07):
[0000926326-14-000035:note_history:9]
There have been no material changes in our significant accounting policies as of and for the three and six months ended June 30, 2014, compared to the significant accounting policies described in our Annual Report on Form 10-K for the year ended December 31, 2013.
  (was, 2014-05-12, similarity 0.9131):
[0000926326-14-000010:note_history:9]
There have been no material changes in our significant accounting policies as of and for the three months ended March 31, 2014, compared to the significant accounting policies described in our Annual Report on Form 10-K for the year ended December 31, 2013.

- added (2014-08-07):
[0000926326-14-000035:note_history:10]
Recently Issued Accounting Standards

- added (2014-08-07):
[0000926326-14-000035:note_history:11]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers: Topic 606.  ASU 2014-09  supersedes nearly all existing revenue recognition guidance under GAAP.  The core principle of ASU 2014-09 is to recognize revenues when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. ASU 2014-09 defines a five step process to achieve this core principle and, in doing so, it is possible more judgment and estimates may be required within the revenue recognition process than required under existing GAAP, including identifying performance obligations in the contract, estimating the amount of variable consideration to include in the transaction price and allocating the transaction price to each separate performance obligation. Companies may use either of two methods: (i) full retrospective application to each prior reporting period presented with the option to elect certain practical expedients defined within ASU 2014-09; or (ii) modified retrospective application with the cumulative effect of initially applying ASU 2014-09 recognized at the date of initial application and providing certain additional disclosures as defined per ASU 2014-09. ASU 2014-09 is effective for us in the first quarter of 2017 and we are currently evaluating the impact of our pending adoption on our consolidated financial statements.

- removed (2014-08-07):
[0000926326-14-000010:note_history:12]
Our results of operations, comprehensive income and cash flows for the three months ended March 31, 2014 are not necessarily indicative of results that may be expected for the year ending December 31, 2014, or for any future period.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-08-07):
[0000926326-14-000035:note_history:13]
In September 2013, we entered into a credit agreement (the "Credit Agreement") with Wells Fargo Bank, National Association, as administrative agent, and the lenders from time to time thereto. The Credit Agreement provides for a $75.0 million revolving credit facility with a $10.0 million letter of credit sub-limit. Loans under the Credit Agreement mature on September 25, 2018. The Credit Agreement permits us to request one or more increases in the aggregate commitments provided that such increases do not exceed $25.0 million in the aggregate. We expect to use the proceeds from any revolving loans under the credit facility for general corporate purposes, including future acquisitions. Our obligations under the Credit Agreement are guaranteed by certain of our domestic subsidiaries and secured by substantially all of our and the subsidiary guarantors’ assets.
  (was, 2014-05-12, similarity 0.9583):
[0000926326-14-000010:note_history:13]
In September 2013, we entered into a credit agreement (the "Credit Agreement") with Wells Fargo Bank, National Association, as administrative agent, and the lenders from time to time party thereto. The Credit Agreement provides for a $75.0 million revolving credit facility with a $10.0 million letter of credit sub-limit. Loans under the Credit Agreement mature on September 25, 2018. The Credit Agreement permits us to request one or more increases in the aggregate commitments provided that such increases do not exceed $25.0 million in the aggregate. We expect to use the proceeds from any revolving loans under the credit facility for general corporate purposes, including future acquisitions. Our obligations under the Credit Agreement are guaranteed by certain of our domestic subsidiaries and secured by substantially all of our and the subsidiary guarantors’ assets. To date, we have not yet drawn any funds under the credit facility.

- changed (2014-08-07):
[0000926326-14-000035:note_history:14]
The Credit Agreement contains customary affirmative and negative covenants, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends and other distributions. The Credit Agreement contains financial covenants that require us to, among other things, maintain a maximum consolidated total leverage ratio and a minimum consolidated fixed charge coverage ratio, in each case, as of the last day of each fiscal quarter.
  (was, 2014-05-12, similarity 0.9409):
[0000926326-14-000010:note_history:14]
The Credit Agreement contains customary affirmative and negative covenants, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends and other distributions. The Credit Agreement contains financial covenants that require us to, among other things, maintain a maximum consolidated total leverage ratio and a minimum consolidated fixed charge coverage ratio, in each case, as of the last day of each fiscal quarter. We were in full compliance with all covenants at March 31, 2014.

- added (2014-08-07):
[0000926326-14-000035:note_history:15]
To date, we have not yet drawn any funds under the credit facility. We were in full compliance with all covenants at June 30, 2014 and for all periods since the commencement of the Credit Agreement.
