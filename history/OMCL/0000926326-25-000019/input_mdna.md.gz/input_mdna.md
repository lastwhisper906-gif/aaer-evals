# OMCL MD&A — 0000926326-25-000019


## mdna

[0000926326-25-000019:mdna:1]
[same as prior period, unchanged from 0000926326-25-000009:mdna:1]

[0000926326-25-000019:mdna:2]
[same as prior period, unchanged from 0000926326-25-000009:mdna:2]

[0000926326-25-000019:mdna:3]
Forward-looking statements are based on our current expectations and assumptions, and are subject to known and unknown risks and uncertainties, many of which are beyond our control, which may cause our actual results, performance, or achievements to be materially different from those expressed or implied in the forward-looking statements. Such risks and uncertainties include those described throughout this Quarterly Report on Form 10-Q, including in Part I - Item 2 “Management’s Discussion and Analysis of Financial Condition and Results of Operations” and Part II - Item 1A. “Risk Factors,” as well as in our Annual Report on Form 10-K for the year ended December 31, 2024 filed with the U.S. Securities and Exchange Commission (“SEC”) on February 27, 2025. Given these risks and uncertainties, you are cautioned not to place undue reliance on these forward-looking statements. Forward-looking statements should be considered in light of these risks and uncertainties. You should carefully read this Quarterly Report on Form 10-Q and the documents that we reference in this Quarterly Report on Form 10-Q and have filed as exhibits, as well as other documents we file with, or furnish to, the U.S.

[0000926326-25-000019:mdna:4]
[same as prior period, unchanged from 0000926326-25-000009:mdna:3]

[0000926326-25-000019:mdna:5]
[same as prior period, unchanged from 0000926326-25-000009:mdna:4]

[0000926326-25-000019:mdna:6]
•our ability to take advantage of growth opportunities and develop and commercialize new solutions and enhance existing solutions, including incorporating artificial intelligence (“AI”) technology and the use of AI by our vendors and competitors;

[0000926326-25-000019:mdna:7]
[same as prior period, unchanged from 0000926326-25-000009:mdna:6]

[0000926326-25-000019:mdna:8]
[same as prior period, unchanged from 0000926326-25-000009:mdna:7]

[0000926326-25-000019:mdna:9]
[same as prior period, unchanged from 0000926326-25-000009:mdna:8]

[0000926326-25-000019:mdna:10]
[same as prior period, unchanged from 0000926326-25-000009:mdna:9]

[0000926326-25-000019:mdna:11]
[same as prior period, unchanged from 0000926326-25-000009:mdna:10]

[0000926326-25-000019:mdna:12]
[same as prior period, unchanged from 0000926326-25-000009:mdna:11]

[0000926326-25-000019:mdna:13]
[same as prior period, unchanged from 0000926326-25-000009:mdna:12]

[0000926326-25-000019:mdna:14]
[same as prior period, unchanged from 0000926326-25-000009:mdna:13]

[0000926326-25-000019:mdna:15]
[same as prior period, unchanged from 0000926326-25-000009:mdna:14]

[0000926326-25-000019:mdna:16]
[same as prior period, unchanged from 0000926326-25-000009:mdna:15]

[0000926326-25-000019:mdna:17]
[same as prior period, unchanged from 0000926326-25-000009:mdna:16]

[0000926326-25-000019:mdna:18]
•government regulations, legislative changes, fraud and anti-kickback statues, products liability claims, the outcome of legal proceedings, and other legal obligations related to healthcare, privacy, data protection, and information security, and the costs of compliance with, and potential liability associated with, our actual or perceived failure to comply with such obligations;

[0000926326-25-000019:mdna:19]
[same as prior period, unchanged from 0000926326-25-000009:mdna:18]

[0000926326-25-000019:mdna:20]
•operating in foreign countries, including the potential impact of political unrest, terrorism, other potential hostilities, threats of terrorism or potential hostilities, or tariffs;

[0000926326-25-000019:mdna:21]
•covenants in our credit agreement could restrict our business and operations;

[0000926326-25-000019:mdna:22]
[same as prior period, unchanged from 0000926326-25-000009:mdna:21]

[0000926326-25-000019:mdna:23]
[same as prior period, unchanged from 0000926326-25-000009:mdna:22]

[0000926326-25-000019:mdna:24]
[same as prior period, unchanged from 0000926326-25-000009:mdna:23]

[0000926326-25-000019:mdna:25]
[same as prior period, unchanged from 0000926326-25-000009:mdna:24]

[0000926326-25-000019:mdna:26]
[same as prior period, unchanged from 0000926326-25-000009:mdna:25]

[0000926326-25-000019:mdna:27]
[same as prior period, unchanged from 0000926326-25-000009:mdna:26]

[0000926326-25-000019:mdna:28]
[same as prior period, unchanged from 0000926326-25-000009:mdna:27]

[0000926326-25-000019:mdna:29]
[same as prior period, unchanged from 0000926326-25-000009:mdna:28]

[0000926326-25-000019:mdna:30]
[same as prior period, unchanged from 0000926326-25-000009:mdna:29]

[0000926326-25-000019:mdna:31]
[same as prior period, unchanged from 0000926326-25-000009:mdna:30]

[0000926326-25-000019:mdna:32]
[same as prior period, unchanged from 0000926326-25-000009:mdna:31]

[0000926326-25-000019:mdna:33]
[same as prior period, unchanged from 0000926326-25-000009:mdna:32]

[0000926326-25-000019:mdna:34]
[same as prior period, unchanged from 0000926326-25-000009:mdna:33]

[0000926326-25-000019:mdna:35]
[same as prior period, unchanged from 0000926326-25-000009:mdna:34]

[0000926326-25-000019:mdna:36]
Omnicell solutions are helping healthcare facilities worldwide to uncover cost savings, improve labor efficiency, establish new revenue streams, enhance supply chain control, support compliance, and move closer to the industry-defined vision of the Autonomous Pharmacy. We sell our product and consumable solutions together with related service offerings. Revenues generated in the United States represented 91% and 92% of our total revenues for the three months ended June 30, 2025 and 2024, respectively, and 92% and 91% of our total revenues for the six months ended June 30, 2025 and 2024, respectively.

[0000926326-25-000019:mdna:37]
[same as prior period, unchanged from 0000926326-25-000009:mdna:36]

[0000926326-25-000019:mdna:38]
[same as prior period, unchanged from 0000926326-25-000009:mdna:37]

[0000926326-25-000019:mdna:39]
On April 2, 2025, the current U.S. administration imposed significant tariffs on a wide variety of products manufactured in virtually every foreign jurisdiction, which tariffs were subsequently paused for 90 days on April 10, 2025, and such tariffs were then expected to be reinstated on August 7, 2025. In addition, tariffs on all imports from China, which were 145% as of April 10, 2025, were subsequently reduced for 90 days on May 14, 2025, with such tariff rates being 30% as of August 6, 2025. In response, several foreign countries have imposed reciprocal tariffs on goods manufactured in the United States. Furthermore, the current U.S. administration has also announced, as have other foreign governments, that it may implement other tariffs or increase existing tariffs. We are monitoring ongoing developments surrounding the fluid tariff environment. Although we continue to work to mitigate the impact of current or potential tariffs, there can be no assurance that we will be able to offset any increased costs or other adverse impacts. As a result, we may incorrectly anticipate outcomes, forgo or pass up business opportunities, or fail to appropriately adapt or manage our business strategies in response to these changes. As a result of all of these factors, we may experience direct and indirect adverse effects on our business, operating results, cash flow, or financial condition.

[0000926326-25-000019:mdna:40]
[same as prior period, unchanged from 0000926326-25-000009:mdna:39]

[0000926326-25-000019:mdna:41]
[same as prior period, unchanged from 0000926326-25-000009:mdna:40]

[0000926326-25-000019:mdna:42]
[same as prior period, unchanged from 0000926326-25-000009:mdna:41]

[0000926326-25-000019:mdna:43]
[same as prior period, unchanged from 0000926326-25-000009:mdna:42]

[0000926326-25-000019:mdna:44]
As part of most connected devices product sales, we generally provide installation planning and consulting, which is typically included in the initial price of the solution.

[0000926326-25-000019:mdna:45]
[same as prior period, unchanged from 0000926326-25-000009:mdna:44]

[0000926326-25-000019:mdna:46]
We consider revenues generated from our consumables, technical services, and SaaS and Expert Services to be recurring revenues. For the portions of our business which generate recurring revenues, we utilize ARR as a key metric to measure our progress in growing our recurring revenue business. We define ARR at a measurement date as the revenue we expect to receive from our customers over the course of the following year for providing them with products or services. ARR includes expected revenue from all customers who are using our products or services at the reported date. For technical services and SaaS and Expert Services, solutions are generally on a contractual basis, typically with contracts for a period of 12 months or more, with a high probability of renewal. Probability of renewal is based on historic renewal experience of the individual revenue streams or management’s best estimates if historical renewal experience is not available. Consumables orders are placed by customers through our Omnicell Storefront online platform or through written or telephonic orders and are sold to a customer base who utilize the consumable products and place recurring orders when customer inventory is depleted. ARR is generally calculated based on revenues received in the most recent quarter and changes to expected revenues where solutions were added to or removed from the install or customer base in the quarter. Revenues from technical services and SaaS and Expert Services are recorded ratably over the service term. As part of our SaaS and Expert Services offerings, we provide a range of services to our customers including Central Pharmacy Dispensing Service (service portion), IV Compounding Service (service portion), EnlivenHealth, Specialty Pharmacy Services, 340B solutions, Inventory Optimization Service, and other software solutions, which typically are provided over two to seven years. In addition, to help ensure the maximum availability of our systems, our customers typically purchase technical services contracts (support and maintenance) in increments of one to five years. Revenue from consumables are recorded when the product has shipped and title has passed. Our measure of ARR may be different than that used by other companies. Because ARR is based on expected future revenue, it does not represent

[0000926326-25-000019:mdna:47]
revenue recognized during a particular reporting period or revenue to be recognized in future reporting periods. ARR should not be viewed as a substitute for revenues.

[0000926326-25-000019:mdna:48]
[same as prior period, unchanged from 0000926326-25-000009:mdna:46]

[0000926326-25-000019:mdna:49]
[same as prior period, unchanged from 0000926326-25-000009:mdna:47]

[0000926326-25-000019:mdna:50]
[same as prior period, unchanged from 0000926326-25-000009:mdna:48]

[0000926326-25-000019:mdna:51]
[same as prior period, unchanged from 0000926326-25-000009:mdna:49]

[0000926326-25-000019:mdna:52]
[same as prior period, unchanged from 0000926326-25-000009:mdna:50]

[0000926326-25-000019:mdna:53]
[same as prior period, unchanged from 0000926326-25-000009:mdna:51]

[0000926326-25-000019:mdna:54]
[same as prior period, unchanged from 0000926326-25-000009:mdna:52]

[0000926326-25-000019:mdna:55]
Our full-time employee headcount was approximately 3,650 as of June 30, 2025.

[0000926326-25-000019:mdna:56]
[same as prior period, unchanged from 0000926326-25-000009:mdna:54]

[0000926326-25-000019:mdna:57]
In 2023, the United States spent $723 billion on prescription drugs, a 13.6% increase from 2022. This was the largest annual spending increase in 20 years and impacted patients in virtually all settings of care. We believe there are significant challenges facing the practice of pharmacy today including, but not limited to, budget constraints, increased healthcare worker turnover rates, labor shortages, drug shortages, drug diversion, manual and error-prone processes, complex compliance requirements, and limited inventory visibility. Each of these challenges may lead to poor medication management outcomes including, but not limited to, medication errors, adverse drug events, lack of patient adherence, and medication waste. We also recognize that these challenges may impact the timing of contracting for, or implementation of, our products, solutions, or services. However, we believe that over time these significant challenges to the practice of pharmacy will drive demand for increased automation, visibility, insights, and improved medication management outcomes that our solutions are designed to enable. Because of this, we believe that our solutions are well-positioned to address the evolving needs of healthcare institutions and therefore present opportunities for long-term growth.

[0000926326-25-000019:mdna:58]
[same as prior period, unchanged from 0000926326-25-000009:mdna:57]

[0000926326-25-000019:mdna:59]
[same as prior period, unchanged from 0000926326-25-000009:mdna:58]

[0000926326-25-000019:mdna:60]
[same as prior period, unchanged from 0000926326-25-000009:mdna:59]

[0000926326-25-000019:mdna:61]
[same as prior period, unchanged from 0000926326-25-000009:mdna:60]

[0000926326-25-000019:mdna:62]
[same as prior period, unchanged from 0000926326-25-000009:mdna:62]

[0000926326-25-000019:mdna:63]
[same as prior period, unchanged from 0000926326-25-000009:mdna:63]

[0000926326-25-000019:mdna:64]
Our discussion and analysis of our financial condition and results of operations are based on our Condensed Consolidated Financial Statements, which have been prepared in accordance with U.S. Generally Accepted Accounting

[0000926326-25-000019:mdna:65]
Principles (“GAAP”). The preparation of these financial statements requires us to make certain estimates and assumptions that affect the reported amounts of assets and liabilities, disclosure of any contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting periods. We regularly review our estimates and assumptions, which are based on historical experience and various other factors that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of certain assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates and assumptions.

[0000926326-25-000019:mdna:66]
[same as prior period, unchanged from 0000926326-25-000009:mdna:65]

[0000926326-25-000019:mdna:67]
[same as prior period, unchanged from 0000926326-25-000009:mdna:66]

[0000926326-25-000019:mdna:68]
[same as prior period, unchanged from 0000926326-25-000009:mdna:67]

[0000926326-25-000019:mdna:69]
[same as prior period, unchanged from 0000926326-25-000009:mdna:68]

[0000926326-25-000019:mdna:70]
There were no material changes in the matters for which we make critical accounting estimates in the preparation of our Condensed Consolidated Financial Statements during the six months ended June 30, 2025 as compared to those disclosed in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” included in our Annual Report on Form 10-K for the year ended December 31, 2024.

[0000926326-25-000019:mdna:71]
[same as prior period, unchanged from 0000926326-25-000009:mdna:70]

[0000926326-25-000019:mdna:72]
Refer to “Recently Issued Authoritative Guidance” in Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q for a description of recently issued accounting pronouncements, including the expected dates of adoption and estimated effects on our results of operations, financial position, and cash flows.

[0000926326-25-000019:mdna:73]
[same as prior period, unchanged from 0000926326-25-000009:mdna:72]

[0000926326-25-000019:mdna:74]
[same as prior period, unchanged from 0000926326-25-000009:mdna:73]

[0000926326-25-000019:mdna:75]
|  | Three Months Ended June 30, |
|  |  |  |  |  | Change in |
|  | 2025 |  | 2024 |  | $ |  | % |
|  | (Dollars in thousands) |
| Product revenues | $ | 163,172 |  |  | $ | 156,580 |  |  | $ | 6,592 |  |  | 4% |
| Percentage of total revenues | 56% |  | 57% |  |  |  |  |
| Service revenues | 127,390 |  |  | 120,208 |  |  | $ | 7,182 |  |  | 6% |
| Percentage of total revenues | 44% |  | 43% |  |  |  |  |
| Total revenues | $ | 290,562 |  |  | $ | 276,788 |  |  | $ | 13,774 |  |  | 5% |

[0000926326-25-000019:mdna:76]
Product revenues represented 56% and 57% of total revenues for the three months ended June 30, 2025 and 2024, respectively. Product revenues increased by $6.6 million, primarily due to the increase in revenues from our XT Amplify program, partially offset by lower volumes from our XT Series automated dispensing systems business due to the timing of our XT Series systems lifecycle, as we are largely through the replacement cycle.

[0000926326-25-000019:mdna:77]
Service revenues represented 44% and 43% of total revenues for the three months ended June 30, 2025 and 2024. Service revenues include revenues from technical services and SaaS and Expert Services offerings. Service revenues increased by $7.2 million due to an increase of $4.4 million in technical services revenues primarily as a result of growth in our installed customer base and the impact of pricing actions, as well as an increase of $2.7 million in SaaS and Expert Services revenues due to continued customer demand, including an increase in revenues from our Specialty Pharmacy Services offering.

[0000926326-25-000019:mdna:78]
Our international sales represented 9% and 8% of total revenues for the three months ended June 30, 2025 and 2024, respectively, and are expected to be affected by foreign currency exchange rate fluctuations. We are unable to predict the extent to which revenues in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-25-000019:mdna:79]
|  | Six Months Ended June 30, |
|  |  |  |  |  | Change in |
|  | 2025 |  | 2024 |  | $ |  | % |
|  | (Dollars in thousands) |
| Product revenues | $ | 308,340 |  |  | $ | 289,875 |  |  | $ | 18,465 |  |  | 6% |
| Percentage of total revenues | 55% |  | 55% |  |  |  |  |
| Service revenues | 251,890 |  |  | 233,064 |  |  | $ | 18,826 |  |  | 8% |
| Percentage of total revenues | 45% |  | 45% |  |  |  |  |
| Total revenues | $ | 560,230 |  |  | $ | 522,939 |  |  | $ | 37,291 |  |  | 7% |

[0000926326-25-000019:mdna:80]
Product revenues represented 55% of total revenues for both the six months ended June 30, 2025 and 2024. Product revenues increased by $18.5 million, primarily due to the increase in revenues from our XT Amplify program, partially offset by lower volumes from our XT Series automated dispensing systems business due to the timing of our XT Series systems lifecycle, as we are largely through the replacement cycle.

[0000926326-25-000019:mdna:81]
Service revenues represented 45% of total revenues for both the six months ended June 30, 2025 and 2024. Service revenues include revenues from technical services and SaaS and Expert Services offerings. Service revenues increased by $18.8 million due to an increase of $7.3 million in technical services revenues primarily as a result of growth in our installed customer base and the impact of pricing actions, as well as an increase of $11.5 million in SaaS and Expert Services revenues due to continued customer demand, including an increase in revenues from our Specialty Pharmacy Services offering.

[0000926326-25-000019:mdna:82]
Our international sales represented 8% and 9% of total revenues for the six months ended June 30, 2025 and 2024, respectively, and are expected to be affected by foreign currency exchange rate fluctuations. We are unable to predict the extent to which revenues in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-25-000019:mdna:83]
[same as prior period, unchanged from 0000926326-25-000009:mdna:78]

[0000926326-25-000019:mdna:84]
[same as prior period, unchanged from 0000926326-25-000009:mdna:79]

[0000926326-25-000019:mdna:85]
[same as prior period, unchanged from 0000926326-25-000009:mdna:80]

[0000926326-25-000019:mdna:86]
|  | Three Months Ended June 30, |
|  |  |  |  |  | Change in |
|  | 2025 |  | 2024 |  | $ |  | % |
|  | (Dollars in thousands) |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | $ | 91,919 |  |  | $ | 99,381 |  |  | $ | (7,462) |  |  | (8)% |
| As a percentage of related revenues | 56% |  | 63% |  |  |  |  |
| Cost of service revenues | 70,965 |  |  | 63,056 |  |  | $ | 7,909 |  |  | 13% |
| As a percentage of related revenues | 56% |  | 52% |  |  |  |  |
| Total cost of revenues | $ | 162,884 |  |  | $ | 162,437 |  |  | $ | 447 |  |  | —% |
| As a percentage of total revenues | 56% |  | 59% |  |  |  |  |
| Gross profit | $ | 127,678 |  |  | $ | 114,351 |  |  | $ | 13,327 |  |  | 12% |
| Gross margin | 44% |  | 41% |  |  |  |  |

[0000926326-25-000019:mdna:87]
Cost of revenues for the three months ended June 30, 2025 compared to the three months ended June 30, 2024 increased by $0.4 million, primarily driven by a $7.9 million increase in cost of service revenues, partially offset by a $7.5 million decrease in cost of product revenues.

[0000926326-25-000019:mdna:88]
The decrease in cost of product revenues for the three months ended June 30, 2025 compared to the three months ended June 30, 2024 was primarily driven by the impact of more favorable materials costs as well as favorable impact from customer and product mix during the three months ended June 30, 2025, partially offset by an increase in revenues.

[0000926326-25-000019:mdna:89]
The increase in cost of service revenues was primarily driven by the increase in service revenues of $7.2 million for the three months ended June 30, 2025 compared to the three months ended June 30, 2024, including the associated increase in employee-related expenses.

[0000926326-25-000019:mdna:90]
The overall increase in gross margin primarily relates to higher revenues for the three months ended June 30, 2025 compared to the three months ended June 30, 2024, as well as a decrease in cost of product revenues primarily due to the impact of more favorable materials costs as well as favorable impact from customer and product mix during the three months ended June 30, 2025, partially offset by an increase in employee-related expenses. Our gross profit for the three months ended June 30, 2025 was $127.7 million, as compared to $114.4 million for the three months ended June 30, 2024.

[0000926326-25-000019:mdna:91]
|  | Six Months Ended June 30, |
|  |  |  |  |  | Change in |
|  | 2025 |  | 2024 |  | $ |  | % |
|  | (Dollars in thousands) |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | $ | 177,504 |  |  | $ | 191,822 |  |  | $ | (14,318) |  |  | (7)% |
| As a percentage of related revenues | 58% |  | 66% |  |  |  |  |
| Cost of service revenues | 144,112 |  |  | 124,143 |  |  | $ | 19,969 |  |  | 16% |
| As a percentage of related revenues | 57% |  | 53% |  |  |  |  |
| Total cost of revenues | $ | 321,616 |  |  | $ | 315,965 |  |  | $ | 5,651 |  |  | 2% |
| As a percentage of total revenues | 57% |  | 60% |  |  |  |  |
| Gross profit | $ | 238,614 |  |  | $ | 206,974 |  |  | $ | 31,640 |  |  | 15% |
| Gross margin | 43% |  | 40% |  |  |  |  |

[0000926326-25-000019:mdna:92]
Cost of revenues for the six months ended June 30, 2025 compared to the six months ended June 30, 2024 increased by $5.7 million, primarily driven by a $20.0 million increase in cost of service revenues, partially offset by a $14.3 million decrease in cost of product revenues.

[0000926326-25-000019:mdna:93]
The decrease in cost of product revenues for the six months ended June 30, 2025 compared to the six months ended June 30, 2024 was primarily driven by the impact of more favorable materials costs as well as favorable impact from customer and product mix during the six months ended June 30, 2025 and a decrease of $2.6 million of restructuring costs, partially offset by an increase in revenues.

[0000926326-25-000019:mdna:94]
The increase in cost of service revenues was primarily driven by the increase in service revenues of $18.8 million for the six months ended June 30, 2025 compared to the six months ended June 30, 2024, including the associated increase in employee-related expenses, and an increase in certain non-recurring costs, including software upgrade expenses.

[0000926326-25-000019:mdna:95]
The overall increase in gross margin primarily relates to higher revenues for the six months ended June 30, 2025 compared to the six months ended June 30, 2024, as well as a decrease in cost of product revenues primarily due to the impact of more favorable materials costs as well as favorable impact from customer and product mix during the six months ended June 30, 2025 and a decrease in restructuring costs, partially offset by an increase in employee-related expenses and an increase in certain non-recurring costs, including software upgrade expenses. Our gross profit for the six months ended June 30, 2025 was $238.6 million, as compared to $207.0 million for the six months ended June 30, 2024.

[0000926326-25-000019:mdna:96]
[same as prior period, unchanged from 0000926326-25-000009:mdna:86]

[0000926326-25-000019:mdna:97]
|  | Three Months Ended June 30, |
|  |  |  |  |  | Change in |
|  | 2025 |  | 2024 |  | $ |  | % |
|  | (Dollars in thousands) |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | $ | 21,573 |  |  | $ | 21,102 |  |  | $ | 471 |  |  | 2% |
| As a percentage of total revenues | 7% |  | 8% |  |  |  |  |
| Selling, general, and administrative | 97,985 |  |  | 90,025 |  |  | $ | 7,960 |  |  | 9% |
| As a percentage of total revenues | 34% |  | 33% |  |  |  |  |
| Total operating expenses | $ | 119,558 |  |  | $ | 111,127 |  |  | $ | 8,431 |  |  | 8% |
| As a percentage of total revenues | 41% |  | 40% |  |  |  |  |
| Interest and other income (expense), net | $ | 2,333 |  |  | $ | 4,973 |  |  | $ | (2,640) |  |  | (53)% |

[0000926326-25-000019:mdna:98]
Research and Development. Research and development expenses increased by $0.5 million for the three months ended June 30, 2025 compared to the three months ended June 30, 2024.

[0000926326-25-000019:mdna:99]
Selling, General, and Administrative. Selling, general, and administrative expenses increased by $8.0 million for the three months ended June 30, 2025 compared to the three months ended June 30, 2024. The increase was primarily due to an increase of $5.3 million in employee-related expenses for the three months ended June 30, 2025 compared to the three months ended June 30, 2024, as well as an increase of $3.1 million in the allowance for credit losses.

[0000926326-25-000019:mdna:100]
Interest and Other Income (Expense), Net. Interest and other income (expense), net changed by $2.6 million for the three months ended June 30, 2025 compared to the three months ended June 30, 2024, primarily driven by a $2.9 million decrease in other income and a $0.3 million decrease in other expense. The decrease in other income during the three months ended June 30, 2025 as compared to the three months ended June 30, 2024 is primarily attributable to lower interest income received due to lower interest rates and lower cash and cash equivalents balances following the partial repurchase of our convertible senior notes in November 2024.

[0000926326-25-000019:mdna:101]
|  | Six Months Ended June 30, |
|  |  |  |  |  | Change in |
|  | 2025 |  | 2024 |  | $ |  | % |
|  | (Dollars in thousands) |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | $ | 42,099 |  |  | $ | 43,158 |  |  | $ | (1,059) |  |  | (2)% |
| As a percentage of total revenues | 8% |  | 8% |  |  |  |  |
| Selling, general, and administrative | 200,014 |  |  | 182,439 |  |  | $ | 17,575 |  |  | 10% |
| As a percentage of total revenues | 36% |  | 35% |  |  |  |  |
| Total operating expenses | $ | 242,113 |  |  | $ | 225,597 |  |  | $ | 16,516 |  |  | 7% |
| As a percentage of total revenues | 43% |  | 43% |  |  |  |  |
| Interest and other income (expense), net | $ | 4,422 |  |  | $ | 8,989 |  |  | $ | (4,567) |  |  | (51)% |

[0000926326-25-000019:mdna:102]
Research and Development. Research and development expenses decreased by $1.1 million for the six months ended June 30, 2025 compared to the six months ended June 30, 2024.

[0000926326-25-000019:mdna:103]
Selling, General, and Administrative. Selling, general, and administrative expenses increased by $17.6 million for the six months ended June 30, 2025 compared to the six months ended June 30, 2024. The increase was primarily due to an increase of $11.3 million in employee-related expenses primarily as a result of higher headcount, an increase of $3.6 million in the allowance for credit losses, an increase of $2.7 million for legal and regulatory expenses, and an increase of $1.5 million in certain restructuring and severance charges for the six months ended June 30, 2025 compared to the six months ended June 30, 2024, partially offset by a decrease of $1.5 million in rent and facilities expenses as well as other expenses.

[0000926326-25-000019:mdna:104]
Interest and Other Income (Expense), Net. Interest and other income (expense), net changed by $4.6 million for the six months ended June 30, 2025 compared to the six months ended June 30, 2024, primarily driven by a $5.1 million decrease in other income and a $0.5 million decrease in other expense. The decrease in other income during the six months ended June 30, 2025 as compared to the six months ended June 30, 2024 is primarily attributable to lower interest income received due to lower interest rates and lower cash and cash equivalents balances following the partial repurchase of our convertible senior notes in November 2024.

[0000926326-25-000019:mdna:105]
Provision for Income Taxes

[0000926326-25-000019:mdna:106]
|  | Three Months Ended June 30, |
|  |  |  |  |  | Change in |
|  | 2025 |  | 2024 |  | $ |  | % |
|  | (Dollars in thousands) |
| Provision for income taxes | $ | 4,814 |  |  | $ | 4,462 |  |  | $ | 352 |  |  | 8% |

[0000926326-25-000019:mdna:107]
|  | Six Months Ended June 30, |
|  |  |  |  |  | Change in |
|  | 2025 |  | 2024 |  | $ |  | % |
|  | (Dollars in thousands) |
| Provision for income taxes | $ | 2,307 |  |  | $ | 2,307 |  |  | $ | — |  |  | —% |

[0000926326-25-000019:mdna:108]
For both the six months ended June 30, 2025 and June 30, 2024, we recorded a provision for income taxes of $2.3 million by applying our estimated annual effective tax rate to our year-to-date measure of ordinary income and adjusted for $2.0 million and $3.3 million, respectively, of discrete income tax expense primarily from equity compensation. The change in the provision for income taxes for the six months ended June 30, 2025 compared to the provision for income taxes for the same period in 2024 was insignificant, consisting of various offsetting components of annual effective tax rate and discrete income tax expense.

[0000926326-25-000019:mdna:109]
[same as prior period, unchanged from 0000926326-25-000009:mdna:94]

[0000926326-25-000019:mdna:110]
[same as prior period, unchanged from 0000926326-25-000009:mdna:95]

[0000926326-25-000019:mdna:111]
We had cash and cash equivalents of $399.0 million at June 30, 2025 compared to $369.2 million at December 31, 2024. All of our cash and cash equivalents are invested in bank accounts and money market funds held in sweep and asset management accounts with financial institutions of high credit quality.

[0000926326-25-000019:mdna:112]
Our cash position and working capital at June 30, 2025 and December 31, 2024 were as follows:

[0000926326-25-000019:mdna:113]
|  | June 30,2025 |  | December 31,2024 |
|  | (In thousands) |
| Cash and cash equivalents | $ | 399,004 |  |  | $ | 369,201 |  |
| Working capital | $ | 250,384 |  |  | $ | 219,815 |  |

[0000926326-25-000019:mdna:114]
Our ratio of current assets to current liabilities was 1.4:1 at both June 30, 2025 and December 31, 2024.

[0000926326-25-000019:mdna:115]
[same as prior period, unchanged from 0000926326-25-000009:mdna:100]

[0000926326-25-000019:mdna:116]
Revolving Credit Facility

[0000926326-25-000019:mdna:117]
On November 15, 2019, Omnicell, Inc. entered into an Amended and Restated Credit Agreement (as amended, the “Prior A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers, and Wells Fargo Bank, National Association, as administrative agent. The Prior A&R Credit Agreement provided for (a) a five-year revolving credit facility of $500.0 million (the “Prior Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million (the “Prior Incremental Facility”). In addition, the Prior A&R Credit Agreement included a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The Prior A&R Credit Agreement was subsequently amended on September 22, 2020 and March 29, 2023 to permit the issuance of the convertible senior notes and the purchase of the convertible note hedge transactions (as described in Note 11, Convertible Senior Notes, of the Notes to Condensed Consolidated Financial Statements

[0000926326-25-000019:mdna:118]
included in this Quarterly Report on Form 10-Q), expand our flexibility to make restricted payments (including common stock repurchases), and replace the total net leverage covenant, as well as to remove and replace the interest rate benchmark based on the London interbank offered rate (“LIBOR”) and related LIBOR-based mechanics with an interest rate benchmark based on the secured overnight financing rate (“SOFR”) as administered by the Federal Reserve Bank of New York and related SOFR-based mechanics.

[0000926326-25-000019:mdna:119]
On October 10, 2023, Omnicell, Inc. entered into a Second Amended and Restated Credit Agreement (the “Second A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, JPMorgan Chase Bank, N.A., PNC Capital Markets LLC and TD Securities (USA) LLC as joint lead arrangers and Wells Fargo Bank, National Association, as administrative agent. The Second A&R Credit Agreement supersedes the Prior A&R Credit Agreement and provides for (a) a five-year revolving credit facility of $350.0 million (the “Current Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to an amount equal to the sum of (i) the greater of $250.0 million and 100% of the adjusted consolidated EBITDA for the last four quarters and (ii) additional amounts subject to pro forma compliance with certain consolidated secured net leverage ratio (the “Current Incremental Facility”). In addition, the Second A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The Second A&R Credit Agreement has an expiration date of October 10, 2028, subject to acceleration under certain conditions, upon which date all remaining outstanding borrowings will be due and payable.

[0000926326-25-000019:mdna:120]
As of June 30, 2025, we had $350.0 million of funds available under the Current Revolving Credit Facility. As of June 30, 2025, there was no outstanding balance under the Current Revolving Credit Facility and we were in full compliance with all covenants.

[0000926326-25-000019:mdna:121]
Refer to Note 10, Debt and Credit Agreement, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional information. We expect to use future loans under the Current Revolving Credit Facility, if any, for working capital, potential acquisitions, and other general corporate purposes.

[0000926326-25-000019:mdna:122]
[same as prior period, unchanged from 0000926326-25-000009:mdna:106]

[0000926326-25-000019:mdna:123]
On November 22, 2024, Omnicell, Inc. completed a private offering of $172.5 million aggregate principal amount of 1.00% Convertible Senior Notes due 2029 (the “2029 Notes”), including the exercise in full of the initial purchasers’ option to purchase up to an additional $22.5 million aggregate principal amount of the 2029 Notes. Omnicell, Inc. received proceeds from the issuance of the 2029 Notes of $166.3 million, net of $6.2 million of transaction fees and other debt issuance costs. The 2029 Notes bear interest at a rate of 1.00% per year, payable semiannually in arrears on June 1 and December 1 of each year, beginning on June 1, 2025. The 2029 Notes are general senior, unsecured obligations of Omnicell, Inc. and will mature on December 1, 2029, unless earlier redeemed, repurchased, or converted. In connection with the issuance of the 2029 Notes, in November 2024, we entered into warrant transactions and received aggregate proceeds from the sale of the warrants of approximately $25.2 million. Refer to Note 11, Convertible Senior Notes, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional information.

[0000926326-25-000019:mdna:124]
[same as prior period, unchanged from 0000926326-25-000009:mdna:109]

[0000926326-25-000019:mdna:125]
[same as prior period, unchanged from 0000926326-25-000009:mdna:110]

[0000926326-25-000019:mdna:126]
The 2025 Repurchase Program has a total of $62.1 million remaining for future repurchases as of June 30, 2025, which may result in additional use of cash. During the three months ended June 30, 2025, the 2016 Repurchase Program was completed. During the three and six months ended June 30, 2025, we repurchased approximately 536,000 shares of our common stock under the repurchase programs at an average price of $29.24 per share for an aggregate purchase price of approximately $15.7 million. Refer to “Stock Repurchase Programs” under Note 16, Employee Benefits and Share-Based Compensation, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional information.

[0000926326-25-000019:mdna:127]
In November 2024, we completed a partial repurchase of $400.0 million aggregate principal amount of the 2025 Notes for approximately $391.0 million in cash. Refer to Note 11, Convertible Senior Notes, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional information.

[0000926326-25-000019:mdna:128]
[same as prior period, unchanged from 0000926326-25-000009:mdna:113]

[0000926326-25-000019:mdna:129]
Based on our current business plan and backlog, we believe that our existing cash and cash equivalents, our anticipated cash flows from operations, cash generated from the exercise of employee stock options and purchases under our Employee Stock Purchase Plan (“ESPP”), along with the availability of funds under the Current Revolving Credit Facility will be sufficient to meet our cash needs for working capital, capital expenditures, potential acquisitions, outstanding debt, and other contractual obligations for at least the next twelve months. For periods beyond the next twelve months, we also anticipate that our net operating cash flows plus existing balances of cash and cash equivalents will suffice to fund the growth of our business.

[0000926326-25-000019:mdna:130]
[same as prior period, unchanged from 0000926326-25-000009:mdna:115]

[0000926326-25-000019:mdna:131]
[same as prior period, unchanged from 0000926326-25-000009:mdna:116]

[0000926326-25-000019:mdna:132]
|  | Six Months Ended June 30, |
|  | 2025 |  | 2024 |
|  | (In thousands) |
| Net cash provided by (used in): |  |  |  |
| Operating activities | $ | 68,679 |  |  | $ | 108,653 |  |
| Investing activities | (31,662) |  |  | (25,889) |  |
| Financing activities | (7,431) |  |  | (4,702) |  |
| Effect of exchange rate changes on cash and cash equivalents | 3,300 |  |  | (802) |  |
| Net increase in cash, cash equivalents, and restricted cash | $ | 32,886 |  |  | $ | 77,260 |  |

[0000926326-25-000019:mdna:133]
[same as prior period, unchanged from 0000926326-25-000009:mdna:118]

[0000926326-25-000019:mdna:134]
[same as prior period, unchanged from 0000926326-25-000009:mdna:119]

[0000926326-25-000019:mdna:135]
Net cash provided by operating activities was $68.7 million for the six months ended June 30, 2025, primarily consisting of operating inflows of $63.0 million and favorable working capital movements of $5.7 million. Operating inflows consisted of a net loss of $1.4 million, adjusted for non-cash items of $64.4 million, which consisted primarily of depreciation and amortization expense of $39.6 million and share-based compensation expense of $21.3 million. The favorable working capital was primarily due to a decrease in accounts receivable and unbilled receivables of $25.9 million primarily due to the timing of billings, shipments, and collections, an increase in deferred revenues of $15.1 million, due to the timing of billings and customers’ installation schedules, and an increase in accounts payable of $10.7 million primarily due to an increase in inventory spend and timing of payments. These cash inflows were partially offset by an increase in inventories of $15.9 million to support production requirements, including advanced purchases of certain components, a decrease in accrued liabilities of $14.9 million primarily due a decrease in taxes payable, a decrease in accrued compensation of $8.6 million primarily due to a decrease in accrued employee bonuses and commissions, and a decrease in operating lease liabilities of $5.8 million.

[0000926326-25-000019:mdna:136]
Net cash provided by operating activities was $108.7 million for the six months ended June 30, 2024, primarily consisting of operating inflows of $52.4 million and favorable working capital movements of $56.3 million. Operating inflows consisted of a net loss of $11.9 million, adjusted for non-cash items of $64.3 million, which consisted primarily of depreciation and amortization expense of $42.1 million, share-based compensation expense of $18.7 million, and inventory write-down charges of $5.4 million. The favorable working capital was primarily due to an increase in deferred revenues of $22.1 million driven by an increase in billings, a decrease in inventories of $11.2 million resulting from inventory management initiatives, and a decrease in accounts receivable and unbilled receivables of $10.9 million driven by overall business activity and the timing of billings and collections.

[0000926326-25-000019:mdna:137]
[same as prior period, unchanged from 0000926326-25-000009:mdna:123]

[0000926326-25-000019:mdna:138]
Net cash used in investing activities was $31.7 million for the six months ended June 30, 2025, which consisted of capital expenditures of $23.0 million for property and equipment and $8.7 million for external-use software development costs.

[0000926326-25-000019:mdna:139]
Net cash used in investing activities was $25.9 million for the six months ended June 30, 2024, which consisted of capital expenditures of $18.5 million for property and equipment and $7.4 million for external-use software development costs.

[0000926326-25-000019:mdna:140]
[same as prior period, unchanged from 0000926326-25-000009:mdna:126]

[0000926326-25-000019:mdna:141]
Net cash used in financing activities was $7.4 million for the six months ended June 30, 2025, primarily due to $15.7 million paid for repurchases of shares of our common stock, partially offset by $8.3 million in proceeds from employee stock option exercises and ESPP purchases.

[0000926326-25-000019:mdna:142]
Net cash used in financing activities was $4.7 million for the six months ended June 30, 2024, primarily due to a net change in the customer funds balances of $11.6 million, partially offset by $8.1 million in proceeds from employee stock option exercises and ESPP purchases.

[0000926326-25-000019:mdna:143]
[same as prior period, unchanged from 0000926326-25-000009:mdna:129]

[0000926326-25-000019:mdna:144]
There have been no significant changes during the six months ended June 30, 2025 to the contractual obligations disclosed in “Management’s Discussion and Analysis of Financial Condition and Results of Operations,” set forth in Part II, Item 7, of our Annual Report on Form 10-K for the year ended December 31, 2024.

[0000926326-25-000019:mdna:145]
Contractual obligations as of June 30, 2025 were as follows:

[0000926326-25-000019:mdna:146]
|  | Payments Due By Period |
|  | Total |  | Remainder of 2025 |  | 2026-2027 |  | 2028-2029 |  | 2030 and thereafter |
|  | (In thousands) |
| Operating leases (1) | $ | 47,273 |  |  | $ | 6,976 |  |  | $ | 25,238 |  |  | $ | 13,124 |  |  | $ | 1,935 |  |
| Purchase obligations (2) | $ | 139,203 |  |  | 111,370 |  |  | 27,811 |  |  | 22 |  |  | — |  |
| Convertible senior notes (3) | $ | 355,487 |  |  | 176,082 |  |  | 3,450 |  |  | 175,955 |  |  | — |  |
| Total (4) | $ | 541,963 |  |  | $ | 294,428 |  |  | $ | 56,499 |  |  | $ | 189,101 |  |  | $ | 1,935 |  |

[0000926326-25-000019:mdna:147]
[same as prior period, unchanged from 0000926326-25-000009:mdna:133]

[0000926326-25-000019:mdna:148]
[same as prior period, unchanged from 0000926326-25-000009:mdna:134]

[0000926326-25-000019:mdna:149]
[same as prior period, unchanged from 0000926326-25-000009:mdna:135]

[0000926326-25-000019:mdna:150]
[same as prior period, unchanged from 0000926326-25-000009:mdna:136]

[0000926326-25-000019:mdna:151]
(4)Refer to Note 14, Commitments and Contingencies, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional information.
