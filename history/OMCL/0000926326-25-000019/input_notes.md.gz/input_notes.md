# OMCL notes — 0000926326-25-000019


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000926326-25-000019:notes:1]
[same as prior period, unchanged from 0000926326-25-000009:notes:1]

[0000926326-25-000019:notes:2]
[same as prior period, unchanged from 0000926326-25-000009:notes:2]

[0000926326-25-000019:notes:3]
[same as prior period, unchanged from 0000926326-25-000009:notes:3]

[0000926326-25-000019:notes:4]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of June 30, 2025 and December 31, 2024, and the results of operations and comprehensive income (loss) for the three and six months ended June 30, 2025 and 2024, and cash flows for the six months ended June 30, 2025 and 2024. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s Annual Report on Form 10-K for the year ended December 31, 2024, filed with the SEC on February 27, 2025. The Company’s results of operations and comprehensive income (loss) for the three and six months ended June 30, 2025, and cash flows for the six months ended June 30, 2025 are not necessarily indicative of results that may be expected for the year ending December 31, 2025, or for any future period.

[0000926326-25-000019:notes:5]
[same as prior period, unchanged from 0000926326-25-000009:notes:5]

[0000926326-25-000019:notes:6]
[same as prior period, unchanged from 0000926326-25-000009:notes:6]

[0000926326-25-000019:notes:7]
[same as prior period, unchanged from 0000926326-25-000009:notes:7]

[0000926326-25-000019:notes:8]
The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s Condensed Consolidated Financial Statements and accompanying Notes to Condensed Consolidated Financial Statements. These estimates are based on historical experience and various other assumptions that management believes to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. The Company’s critical accounting estimates are those that affect its financial statements materially and involve difficult, subjective, or complex judgments by management. Those estimates are revenue recognition, inventory valuation, and accounting for income taxes. As of June 30, 2025, the Company is not aware of any events or circumstances that would require an update to its estimates, judgments, or revisions to the carrying value of its assets or liabilities.

[0000926326-25-000019:notes:9]
[same as prior period, unchanged from 0000926326-25-000009:notes:9]

[0000926326-25-000019:notes:10]
[same as prior period, unchanged from 0000926326-25-000009:notes:10]

[0000926326-25-000019:notes:11]
[same as prior period, unchanged from 0000926326-25-000009:notes:11]

[0000926326-25-000019:notes:12]
[same as prior period, unchanged from 0000926326-25-000009:notes:12]

[0000926326-25-000019:notes:13]
[same as prior period, unchanged from 0000926326-25-000009:notes:13]

[0000926326-25-000019:notes:14]
In December 2023, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which includes amendments that further enhance income tax disclosures, primarily through standardization and disaggregation of rate reconciliation categories and income taxes paid by jurisdiction. The amendments are effective for the Company’s annual periods beginning January 1, 2025, with early adoption permitted, and should be applied either prospectively or retrospectively. The Company is currently evaluating the impact ASU 2023-09 will have on its consolidated financial statements, which is limited to financial statements disclosures.

[0000926326-25-000019:notes:15]
In March 2024, the SEC issued final rules under SEC Release No. 33-11275, “The Enhancement and Standardization of Climate-Related Disclosures for Investors,” to require registrants to disclose certain climate-related information, including Scope 1 and Scope 2 greenhouse gas emissions and other climate-related topics, if material, in registration statements and annual reports. In April 2024, the SEC voluntarily stayed its climate disclosure rules as a result of pending legal challenges to facilitate an orderly judicial resolution. In March 2025, the SEC stated that it has ended its defense of the rule. The Company will continue to monitor any developments in the SEC’s rule and related litigation to determine what, if any, impact it will have on its consolidated financial statement disclosures.

[0000926326-25-000019:notes:16]
In November 2024, the FASB issued ASU 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosure (Subtopic 220-40): Disaggregation of Income Statement Expenses, which requires disclosures of additional information and disaggregation of certain expenses included in the income statement. The amendments are effective for the Company’s annual periods beginning January 1, 2027, and for interim periods within fiscal years beginning January 1, 2028, with early adoption permitted, and should be applied either prospectively or retrospectively. The Company is currently evaluating the impact ASU 2024-03 will have on its consolidated financial statements.

[0000926326-25-000019:notes:17]
[same as prior period, unchanged from 0000926326-25-000009:notes:17]


## us-gaap:SegmentReportingDisclosureTextBlock

[0000926326-25-000019:notes:18]
[same as prior period, unchanged from 0000926326-25-000009:notes:18]

[0000926326-25-000019:notes:19]
[same as prior period, unchanged from 0000926326-25-000009:notes:19]

[0000926326-25-000019:notes:20]
The CODM is also provided with certain segment assets, primarily those that impact liquidity, such as cash and cash equivalents, accounts receivable and inventories, as well as certain liabilities such as accounts payable and outstanding debt. Assets and liabilities provided to the CODM are consistent with those reported on the Condensed Consolidated Balance Sheets. In addition, the CODM is regularly provided with significant expenses, which are adjusted cost of revenues and adjusted operating expenses. These significant expenses are adjusted for certain non-cash charges and expenses that are unrelated to the Company’s ongoing operations. Adjusted cost of revenues include cost of product revenues and cost of service revenues, and exclude certain items such as share-based compensation expense, amortization of acquired intangibles, and certain restructuring and severance charges. Adjusted operating expenses include research and development, and selling, general and administrative expenses, and exclude certain items such as share-based compensation expense, amortization of acquired intangibles, legal and regulatory expenses, and certain restructuring and severance charges. Depreciation and amortization expense for the Company’s single reportable segment was $19.6 million and $20.8 million for the three months ended June 30, 2025 and 2024, respectively, and $39.6 million and $42.1 million for the six months ended June 30, 2025 and 2024, respectively.

[0000926326-25-000019:notes:21]
The following table summarizes the Company’s reportable segment revenues and significant expenses, reconciled to the Company’s consolidated net income (loss):

[0000926326-25-000019:notes:22]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  | (In thousands) |
| Total revenues | $ | 290,562 |  |  | $ | 276,788 |  |  | $ | 560,230 |  |  | $ | 522,939 |  |
| Less: |  |  |  |  |  |  |  |
| Adjusted cost of revenues | (160,690) |  |  | (154,499) |  |  | (316,697) |  |  | (302,656) |  |
| Adjusted operating expenses | (105,739) |  |  | (97,477) |  |  | (210,093) |  |  | (199,199) |  |
| Other segment items (1) | (16,013) |  |  | (21,588) |  |  | (36,939) |  |  | (39,707) |  |
| Interest and other income (expense), net | 2,333 |  |  | 4,973 |  |  | 4,422 |  |  | 8,989 |  |
| Provision for income taxes | 4,814 |  |  | 4,462 |  |  | 2,307 |  |  | 2,307 |  |
| Net income (loss) | $ | 5,639 |  |  | $ | 3,735 |  |  | $ | (1,384) |  |  | $ | (11,941) |  |

[0000926326-25-000019:notes:23]
[same as prior period, unchanged from 0000926326-25-000009:notes:23]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000926326-25-000019:notes:24]
[same as prior period, unchanged from 0000926326-25-000009:notes:24]

[0000926326-25-000019:notes:25]
[same as prior period, unchanged from 0000926326-25-000009:notes:25]

[0000926326-25-000019:notes:26]
[same as prior period, unchanged from 0000926326-25-000009:notes:26]

[0000926326-25-000019:notes:27]
[same as prior period, unchanged from 0000926326-25-000009:notes:27]

[0000926326-25-000019:notes:28]
[same as prior period, unchanged from 0000926326-25-000009:notes:28]

[0000926326-25-000019:notes:29]
[same as prior period, unchanged from 0000926326-25-000009:notes:29]

[0000926326-25-000019:notes:30]
[same as prior period, unchanged from 0000926326-25-000009:notes:30]

[0000926326-25-000019:notes:31]
[same as prior period, unchanged from 0000926326-25-000009:notes:31]

[0000926326-25-000019:notes:32]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”) and Federal agencies that purchase under a Federal Supply Schedule Contract with the Department of Veterans Affairs (the “GSA Contract”). GPOs are often fully or partially owned by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company also pays the Industrial Funding Fee (“IFF”) to the Department of Veterans Affairs under the GSA Contract. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs and the IFF were $1.6 million and $2.4 million for the three months ended June 30, 2025 and 2024, respectively, and $3.8 million and $4.4 million for the six months ended June 30, 2025 and 2024, respectively.

[0000926326-25-000019:notes:33]
[same as prior period, unchanged from 0000926326-25-000009:notes:33]

[0000926326-25-000019:notes:34]
[same as prior period, unchanged from 0000926326-25-000009:notes:34]

[0000926326-25-000019:notes:35]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  | (In thousands) |
| Connected devices, software licenses, and other | $ | 138,620 |  |  | $ | 134,539 |  |  | $ | 258,697 |  |  | $ | 245,608 |  |
| Consumables | 24,552 |  |  | 22,041 |  |  | 49,643 |  |  | 44,267 |  |
| Technical services | 63,766 |  |  | 59,321 |  |  | 125,145 |  |  | 117,836 |  |
| SaaS and Expert Services | 63,624 |  |  | 60,887 |  |  | 126,745 |  |  | 115,228 |  |
| Total revenues | $ | 290,562 |  |  | $ | 276,788 |  |  | $ | 560,230 |  |  | $ | 522,939 |  |

[0000926326-25-000019:notes:36]
[same as prior period, unchanged from 0000926326-25-000009:notes:36]

[0000926326-25-000019:notes:37]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  | (In thousands) |
| United States | $ | 263,446 |  |  | $ | 255,317 |  |  | $ | 512,710 |  |  | $ | 473,493 |  |
| Rest of world | 27,116 |  |  | 21,471 |  |  | 47,520 |  |  | 49,446 |  |
| Total revenues | $ | 290,562 |  |  | $ | 276,788 |  |  | $ | 560,230 |  |  | $ | 522,939 |  |

[0000926326-25-000019:notes:38]
[same as prior period, unchanged from 0000926326-25-000009:notes:40]

[0000926326-25-000019:notes:39]
[same as prior period, unchanged from 0000926326-25-000009:notes:41]

[0000926326-25-000019:notes:40]
|  | June 30,2025 |  | December 31,2024 |
|  | (In thousands) |
| Short-term unbilled receivables, net (1) | $ | 37,137 |  |  | $ | 32,917 |  |
| Long-term unbilled receivables, net (2) | 5,747 |  |  | 7,873 |  |
| Total contract assets | $ | 42,884 |  |  | $ | 40,790 |  |
| Short-term deferred revenues | $ | 153,597 |  |  | $ | 141,370 |  |
| Long-term deferred revenues | 80,447 |  |  | 76,123 |  |
| Total contract liabilities | $ | 234,044 |  |  | $ | 217,493 |  |

[0000926326-25-000019:notes:41]
[same as prior period, unchanged from 0000926326-25-000009:notes:38]

[0000926326-25-000019:notes:42]
[same as prior period, unchanged from 0000926326-25-000009:notes:43]

[0000926326-25-000019:notes:43]
[same as prior period, unchanged from 0000926326-25-000009:notes:44]

[0000926326-25-000019:notes:44]
[same as prior period, unchanged from 0000926326-25-000009:notes:45]

[0000926326-25-000019:notes:45]
During the three and six months ended June 30, 2025, the Company recognized revenues of $38.6 million and $92.8 million, respectively, that were included in the corresponding gross short-term deferred revenues balance of $141.4 million as of December 31, 2024.

[0000926326-25-000019:notes:46]
Deferred revenues from product sales primarily relate to delivered and invoiced products, pending installation and acceptance. Deferred revenues from service contracts primarily relate to services that have been invoiced, but services have not yet been provided. Short-term deferred revenues are expected to be recognized within the next twelve months. Long-term deferred revenues substantially consist of deferred revenues on long-term technical and SaaS and Expert Services contracts which have been invoiced and are expected to be recognized as revenue beyond twelve months, generally not more than ten years. The Company generally invoices customers for products upon shipment. Invoicing associated with the service portion of agreements is generally periodic and is billed on a monthly, quarterly, or annual basis, and in certain circumstances, multiple years are billed at one time. SaaS and Expert Services agreements are generally invoiced periodically on a monthly, quarterly or annual basis over the life of the agreement. In certain circumstances, portions of these agreements may be invoiced lump sum.

[0000926326-25-000019:notes:47]
In addition, the Company has remaining performance obligations associated with contracts for which the associated products have been accepted or associated services have started, but where invoicing has not yet occurred and therefore are not reflected in deferred revenue. These remaining performance obligations are comprised of the non-variable portions of technical services and SaaS and Expert Services provided under non-cancellable contracts with minimum commitments. Remaining performance obligations which are not included in deferred revenues were $384.1 million as of June 30, 2025. Remaining performance obligations are expected to be recognized ratably over the remaining terms of the associated contracts, which terms vary but are generally not more than ten years. Remaining performance obligations do not include product obligations, services where the associated product has not been accepted, services which have not yet started, variable portions of services, and certain other obligations.

[0000926326-25-000019:notes:48]
[same as prior period, unchanged from 0000926326-25-000009:notes:49]

[0000926326-25-000019:notes:49]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three and six months ended June 30, 2025 and 2024. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable and unbilled receivables balance as of June 30, 2025 and December 31, 2024.


## us-gaap:EarningsPerShareTextBlock

[0000926326-25-000019:notes:50]
Net Income (Loss) Per Share
Basic net income (loss) per share is computed by dividing net income (loss) for the period by the weighted-average number of shares outstanding during the period. In periods of net loss, all potential common shares are anti-dilutive, so diluted net loss per share equals the basic net loss per share. In periods of net income, diluted net income per share is computed by dividing net income for the period by the basic weighted-average number of shares plus any dilutive potential common stock outstanding during the period, using the treasury stock method for share-based awards and warrants, and the if-converted method for convertible senior notes. Potential common stock includes the effect of outstanding dilutive stock options, restricted stock awards, and restricted stock units, as well as shares the Company could be obligated to issue from its convertible senior notes and warrants, as described in Note 11, Convertible Senior Notes. In the event of the conversion of the Company’s convertible senior notes, the principal portion will be settled in cash with any conversion consideration in excess of the principal portion settled in cash and/or shares of the Company’s common stock at the Company’s option, therefore, only the amounts expected to be settled in excess of the principal portion are considered dilutive in calculating earnings per share under the if-converted method. Any anti-dilutive weighted-average dilutive shares related to stock award plans, convertible senior notes, and warrants are excluded from the computation of the diluted net income per share.

[0000926326-25-000019:notes:51]
The basic and diluted net income (loss) per share calculations were as follows:

[0000926326-25-000019:notes:52]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  | (In thousands, except per share data) |
| Net income (loss) | $ | 5,639 |  |  | $ | 3,735 |  |  | $ | (1,384) |  |  | $ | (11,941) |  |
| Weighted-average shares outstanding – basic | 46,788 |  |  | 45,953 |  |  | 46,692 |  |  | 45,842 |  |
| Effect of dilutive securities from stock award plans | 198 |  |  | 83 |  |  | — |  |  | — |  |
| Weighted-average shares outstanding – diluted | 46,986 |  |  | 46,036 |  |  | 46,692 |  |  | 45,842 |  |
| Net income (loss) per share – basic | $ | 0.12 |  |  | $ | 0.08 |  |  | $ | (0.03) |  |  | $ | (0.26) |  |
| Net income (loss) per share – diluted | $ | 0.12 |  |  | $ | 0.08 |  |  | $ | (0.03) |  |  | $ | (0.26) |  |
| Anti-dilutive weighted-average shares related to stock award plans | 2,881 |  |  | 2,719 |  |  | 3,657 |  |  | 3,247 |  |
| Anti-dilutive weighted-average shares related to convertible senior notes and warrants | 9,622 |  |  | 11,816 |  |  | 9,622 |  |  | 11,816 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000926326-25-000019:notes:53]
Cash and Cash Equivalents and Fair Value of Financial Instruments
Cash and cash equivalents of $399.0 million and $369.2 million as of June 30, 2025 and December 31, 2024, respectively, consisted of bank accounts and highly-liquid U.S. Government money market funds held in sweep and asset management accounts with financial institutions of high credit quality. As of June 30, 2025 and December 31, 2024, cash equivalents were $352.2 million and $328.0 million, respectively, which consisted of money market funds held in sweep and asset management accounts. The Company recorded interest income on its cash and cash equivalents of $3.7 million and $6.6 million for the three months ended June 30, 2025 and 2024, respectively, and $7.3 million and $12.6 million for the six months ended June 30, 2025 and 2024, respectively, which is included within interest and other income (expense), net in the Condensed Consolidated Statements of Operations.

[0000926326-25-000019:notes:54]
[same as prior period, unchanged from 0000926326-25-000009:notes:56]

[0000926326-25-000019:notes:55]
The Company measures its financial instruments at fair value. The Company’s cash, cash equivalents, and restricted cash are classified within Level 1 of the fair value hierarchy as they are valued primarily using quoted market prices utilizing market observable inputs. The Company’s credit facility is classified within Level 2 as the valuation inputs are based on quoted prices or market observable data of similar instruments. The Company’s convertible senior notes are classified within Level 2 as the valuation inputs are based on quoted prices in an inactive market on the last day in the reporting period. Refer to Note 10, Debt and Credit Agreement, for further information regarding the Company’s credit facility and Note 11, Convertible Senior Notes, for further information regarding the Company’s convertible senior notes.

[0000926326-25-000019:notes:56]
[same as prior period, unchanged from 0000926326-25-000009:notes:58]

[0000926326-25-000019:notes:57]
|  | June 30,2025 |  | December 31,2024 |
|  | (In thousands) |
| Net carrying amount: |  |  |  |
| 2025 Notes | 174,801 |  |  | 174,324 |  |
| 2029 Notes | 166,994 |  |  | 166,397 |  |
| Total net carrying amount | $ | 341,795 |  |  | $ | 340,721 |  |
| Fair value: |  |  |  |
| 2025 Notes | $ | 172,043 |  |  | $ | 167,129 |  |
| 2029 Notes | 154,560 |  |  | 181,320 |  |
| Total fair value | $ | 326,603 |  |  | $ | 348,449 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000926326-25-000019:notes:58]
[same as prior period, unchanged from 0000926326-25-000009:notes:60]

[0000926326-25-000019:notes:59]
|  | June 30,2025 |  | December 31,2024 |
|  | (In thousands) |
| Inventories: |  |  |  |
| Raw materials | $ | 31,319 |  |  | $ | 33,501 |  |
| Work in process | 2,136 |  |  | 1,515 |  |
| Finished goods | 72,329 |  |  | 53,643 |  |
| Total inventories | $ | 105,784 |  |  | $ | 88,659 |  |
| Other current assets: |  |  |  |
| Funds held for customers, including restricted cash (1) | $ | 45,838 |  |  | $ | 47,846 |  |
| Deferred cost of sales | 10,915 |  |  | 8,704 |  |
| Net investment in sales-type leases, current portion | 12,629 |  |  | 12,475 |  |
| Prepaid income taxes | 2,996 |  |  | 1,334 |  |
| Other current assets | 5,905 |  |  | 4,934 |  |
| Total other current assets | $ | 78,283 |  |  | $ | 75,293 |  |
| Other long-term assets: |  |  |  |
| External-use software development costs, net | $ | 56,229 |  |  | $ | 58,436 |  |
| Unbilled receivables, net | 5,747 |  |  | 7,873 |  |
| Deferred debt issuance costs | 2,553 |  |  | 2,940 |  |
| Other long-term assets | 7,499 |  |  | 10,057 |  |
| Total other long-term assets | $ | 72,028 |  |  | $ | 79,306 |  |
| Accrued liabilities: |  |  |  |
| Operating lease liabilities, current portion | $ | 11,855 |  |  | $ | 10,702 |  |
| Customer fund liabilities | 45,838 |  |  | 47,846 |  |
| Advance payments from customers | 11,773 |  |  | 12,760 |  |
| Rebate liabilities | 48,465 |  |  | 49,300 |  |
| Taxes payable | 3,328 |  |  | 11,443 |  |
| Other accrued liabilities | 30,617 |  |  | 35,844 |  |
| Total accrued liabilities | $ | 151,876 |  |  | $ | 167,895 |  |

[0000926326-25-000019:notes:60]
(1)    Includes restricted cash of $32.5 million and $29.4 million as of June 30, 2025 and December 31, 2024, respectively.

[0000926326-25-000019:notes:61]
The Company capitalizes certain costs associated with cloud computing arrangements that are associated with service contracts, which are amortized using the straight-line method over the term of the arrangement. As of both June 30, 2025 and December 31, 2024, capitalized costs associated with cloud computing arrangements, net of accumulated amortization, were $5.0 million.

[0000926326-25-000019:notes:62]
[same as prior period, unchanged from 0000926326-25-000009:notes:64]

[0000926326-25-000019:notes:63]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  | (In thousands) |
| Beginning balance | $ | (13,807) |  |  | $ | (14,831) |  |  | $ | (17,195) |  |  | $ | (13,432) |  |
| Other comprehensive income (loss): | 6,288 |  |  | (47) |  |  | 9,676 |  |  | (1,446) |  |
| Ending balance | $ | (7,519) |  |  | $ | (14,878) |  |  | $ | (7,519) |  |  | $ | (14,878) |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000926326-25-000019:notes:64]
[same as prior period, unchanged from 0000926326-25-000009:notes:66]

[0000926326-25-000019:notes:65]
|  | June 30,2025 |  | December 31,2024 |
|  | (In thousands) |
| Equipment | $ | 104,472 |  |  | $ | 99,728 |  |
| Furniture and fixtures | 4,934 |  |  | 4,809 |  |
| Leasehold improvements | 18,144 |  |  | 17,722 |  |
| Purchased software and internal-use software development costs | 156,137 |  |  | 146,287 |  |
| Construction in progress | 19,446 |  |  | 12,539 |  |
| Property and equipment, gross | 303,133 |  |  | 281,085 |  |
| Accumulated depreciation and amortization | (184,179) |  |  | (168,393) |  |
| Total property and equipment, net | $ | 118,954 |  |  | $ | 112,692 |  |

[0000926326-25-000019:notes:66]
Depreciation and amortization expense of property and equipment was $8.6 million and $8.7 million for the three months ended June 30, 2025 and 2024, respectively, and $17.2 million and $17.3 million for the six months ended June 30, 2025 and 2024, respectively.

[0000926326-25-000019:notes:67]
[same as prior period, unchanged from 0000926326-25-000009:notes:69]

[0000926326-25-000019:notes:68]
|  | June 30,2025 |  | December 31,2024 |
|  | (In thousands) |
| United States | $ | 115,192 |  |  | $ | 109,534 |  |
| Rest of world | 3,762 |  |  | 3,158 |  |
| Total property and equipment, net | $ | 118,954 |  |  | $ | 112,692 |  |


## us-gaap:ResearchDevelopmentAndComputerSoftwareDisclosureTextBlock

[0000926326-25-000019:notes:69]
[same as prior period, unchanged from 0000926326-25-000009:notes:71]

[0000926326-25-000019:notes:70]
|  | June 30,2025 |  | December 31,2024 |
|  | (In thousands) |
| Gross carrying amount | $ | 258,421 |  |  | $ | 249,335 |  |
| Accumulated amortization | (202,192) |  |  | (190,899) |  |
| External-use software development costs, net (1) | $ | 56,229 |  |  | $ | 58,436 |  |

[0000926326-25-000019:notes:71]
[same as prior period, unchanged from 0000926326-25-000009:notes:73]

[0000926326-25-000019:notes:72]
The Company recorded $5.6 million and $6.4 million to cost of product revenues for amortization of external-use software development costs for the three months ended June 30, 2025 and 2024, respectively, and $11.3 million and $13.1 million for the six months ended June 30, 2025 and 2024, respectively.

[0000926326-25-000019:notes:73]
[same as prior period, unchanged from 0000926326-25-000009:notes:75]

[0000926326-25-000019:notes:74]
|  | June 30,2025 |
|  | (In thousands) |
| Remaining six months of 2025 | $ | 10,498 |  |
| 2026 | 17,961 |  |
| 2027 | 12,098 |  |
| 2028 | 8,241 |  |
| 2029 | 5,614 |  |
| Thereafter | 1,817 |  |
| Total | $ | 56,229 |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000926326-25-000019:notes:75]
[same as prior period, unchanged from 0000926326-25-000009:notes:77]

[0000926326-25-000019:notes:76]
[same as prior period, unchanged from 0000926326-25-000009:notes:78]

[0000926326-25-000019:notes:77]
|  |  |  |  |  | (In thousands) |
| Balance as of December 31, 2024 |  |  |  |  | $ | 734,727 |  |
| Foreign currency exchange rate fluctuations |  |  |  |  | 3,761 |  |
| Balance as of June 30, 2025 |  |  |  |  | $ | 738,488 |  |

[0000926326-25-000019:notes:78]
[same as prior period, unchanged from 0000926326-25-000009:notes:80]

[0000926326-25-000019:notes:79]
[same as prior period, unchanged from 0000926326-25-000009:notes:81]

[0000926326-25-000019:notes:80]
|  | June 30, 2025 |
|  | Gross carryingamount (1) |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 307,418 |  |  | $ | (141,907) |  |  | $ | (1,167) |  |  | $ | 164,344 |  |  | 4 - 30 |
| Acquired technology | 45,379 |  |  | (33,663) |  |  | — |  |  | 11,716 |  |  | 4 - 20 |
| Trade names | 2,400 |  |  | (1,820) |  |  | — |  |  | 580 |  |  | 5 |
| Patents | 1,681 |  |  | (972) |  |  | — |  |  | 709 |  |  | 2 - 20 |
| Total intangible assets, net | $ | 356,878 |  |  | $ | (178,362) |  |  | $ | (1,167) |  |  | $ | 177,349 |  |  |  |

[0000926326-25-000019:notes:81]
[same as prior period, unchanged from 0000926326-25-000009:notes:83]

[0000926326-25-000019:notes:82]
[same as prior period, unchanged from 0000926326-25-000009:notes:84]

[0000926326-25-000019:notes:83]
Amortization expense of intangible assets was $5.3 million and $5.7 million for the three months ended June 30, 2025 and 2024, respectively, and $11.1 million and $11.7 million for the six months ended June 30, 2025 and 2024, respectively.

[0000926326-25-000019:notes:84]
[same as prior period, unchanged from 0000926326-25-000009:notes:86]

[0000926326-25-000019:notes:85]
|  | June 30,2025 |
|  | (In thousands) |
| Remaining six months of 2025 | $ | 10,119 |  |
| 2026 | 18,041 |  |
| 2027 | 16,233 |  |
| 2028 | 15,145 |  |
| 2029 | 13,647 |  |
| Thereafter | 104,164 |  |
| Total | $ | 177,349 |  |


## us-gaap:DebtDisclosureTextBlock

[0000926326-25-000019:notes:86]
Debt and Credit Agreement
On November 15, 2019, Omnicell, Inc. entered into an Amended and Restated Credit Agreement (as amended, the “Prior A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers, and Wells Fargo Bank, National Association, as administrative agent. As referred to in this Note 10, “Omnicell, Inc.” refers only to Omnicell, Inc., excluding its subsidiaries. The Prior A&R Credit Agreement provided for (a) a five-year revolving credit facility of $500.0 million (the “Prior Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million (the “Prior Incremental Facility”). In addition, the Prior A&R Credit Agreement included a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The Prior A&R Credit Agreement was subsequently amended on September 22, 2020 and March 29, 2023, to permit the issuance of the convertible senior notes and the purchase of the convertible note hedge transactions (as described in Note 11, Convertible Senior Notes), expand the Company’s flexibility to make restricted payments (including common stock repurchases), and replace the total net leverage covenant, as well as to remove and replace the interest rate benchmark based on the London interbank offered rate (“LIBOR”) and related LIBOR-based mechanics with an interest rate benchmark based on the secured overnight financing rate (“SOFR”) as administered by the Federal Reserve Bank of New York and related SOFR-based mechanics.

[0000926326-25-000019:notes:87]
Omnicell, Inc. entered into a Second Amended and Restated Credit Agreement (the “Second A&R Credit Agreement”) on October 10, 2023, with the lenders from time to time party thereto, Wells Fargo Securities, LLC, JPMorgan Chase Bank, N.A., PNC Capital Markets LLC and TD Securities (USA) LLC as joint lead arrangers and Wells Fargo Bank, National Association, as administrative agent. The Second A&R Credit Agreement supersedes the Prior A&R Credit Agreement and provides for (a) a five-year revolving credit facility of $350.0 million (the “Current Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to an amount equal to the sum of (i) the greater of $250.0 million and 100% of the adjusted consolidated EBITDA for the last four quarters and (ii) additional amounts subject to pro forma compliance with certain consolidated secured net leverage ratio (the “Current Incremental Facility”). In addition, the Second A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The

[0000926326-25-000019:notes:88]
Second A&R Credit Agreement has an expiration date of October 10, 2028, subject to acceleration under certain conditions, upon which date all remaining outstanding borrowings will be due and payable.

[0000926326-25-000019:notes:89]
Loans under the Current Revolving Credit Facility bear interest, at Omnicell, Inc.’s option, at a rate equal to either (a) the Adjusted Term SOFR (as defined in the Second A&R Credit Agreement), plus an applicable margin ranging from 1.50% to 2.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the Second A&R Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) the Adjusted Term SOFR for an interest period of one month plus 1.00%, plus an applicable margin ranging from 0.50% to 1.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio. Undrawn commitments under the Current Revolving Credit Facility are subject to a commitment fee ranging from 0.20% to 0.35% per annum based on the Company’s Consolidated Total Net Leverage Ratio on the average daily unused portion of the Current Revolving Credit Facility. Subject to the terms and conditions of the Current Revolving Credit Facility or Current Incremental Facility Omnicell, Inc. is permitted to make voluntary prepayments at any time without payment of a premium or penalty. The availability of funds under the Current Revolving Credit Facility may be subject to reduction in order to maintain compliance with the financial covenants under the Second A&R Credit Agreement.

[0000926326-25-000019:notes:90]
The Second A&R Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends, and other distributions. The Second A&R Credit Agreement contains financial covenants that require the Company to not exceed a maximum consolidated secured net leverage ratio (not to exceed 3.00:1) and maintain a minimum consolidated interest coverage ratio (not to be less than 3.00:1). In addition, the Second A&R Credit Agreement contains certain customary events of default including, but not limited to, failure to pay interest, principal, and fees, or other amounts when due, material misrepresentations or misstatements in any representation or warranty, covenant defaults, certain cross defaults to other material indebtedness, certain judgment defaults, and events of bankruptcy.

[0000926326-25-000019:notes:91]
Omnicell, Inc.’s obligations under the Second A&R Credit Agreement and, at the election of Omnicell, Inc. and the contracting counterparty, any secured swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and such subsidiary guarantors’ assets. In connection with entering into the Second A&R Credit Agreement, and as a condition precedent to borrowing loans thereunder, Omnicell, Inc. and certain of Omnicell, Inc.’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a reaffirmation agreement, which amends certain terms of the existing collateral agreement and reaffirms their obligations under the existing guaranty agreement.

[0000926326-25-000019:notes:92]
On November 18, 2024, Omnicell, Inc., as borrower, entered into a First Amendment to Second Amended and Restated Credit Agreement (the “Amendment”) with the lenders party thereto from time to time, and Wells Fargo Bank, National Association, as administrative agent for the lenders. Pursuant to the Amendment, effective as of November 19, 2024, the springing maturity for the revolving credit facility that is tied to the outstanding principal amount of Omnicell, Inc.’s existing 0.25% Convertible Senior Notes due 2025 (the “2025 Notes”) will apply only if more than $200 million in the aggregate principal amount of the 2025 Notes remain outstanding as of 91 days prior to the maturity date of the 2025 Notes.

[0000926326-25-000019:notes:93]
As of both June 30, 2025 and December 31, 2024, the Company had $350.0 million of funds available under the Current Revolving Credit Facility. As of June 30, 2025 and December 31, 2024, the Company had no outstanding balance under the Current Revolving Credit Facility. The Company was in compliance with all covenants as of June 30, 2025.
Convertible Senior Notes
0.25% Convertible Senior Notes due 2025

[0000926326-25-000019:notes:94]
On September 25, 2020, Omnicell, Inc. completed a private offering of $575.0 million aggregate principal amount of 0.25% convertible senior notes (the “2025 Notes”), including the exercise in full of the initial purchasers’ option to purchase up to an additional $75.0 million principal amount of the 2025 Notes. As referred to in this Note 11, “Omnicell, Inc.” or the “Company” refers only to Omnicell, Inc., excluding its subsidiaries. Omnicell, Inc. received proceeds from the issuance of the 2025 Notes of $559.7 million, net of $15.3 million of transaction fees and other debt issuance costs. The 2025 Notes bear interest at a rate of 0.25% per year, payable semiannually in arrears on March 15 and September 15 of each year, beginning on March 15, 2021. The 2025 Notes were issued pursuant to an indenture, dated September 25, 2020 (the “2025 Notes Indenture”), between the Company and U.S. Bank National Association, as trustee. The 2025 Notes are general senior, unsecured obligations of the Company and will mature on September 15, 2025, unless earlier redeemed, repurchased, or converted.

[0000926326-25-000019:notes:95]
During the three months ended June 30, 2025 and December 31, 2024, none of the conditional conversion features of the 2025 Notes were triggered. As of May 15, 2025, until the close of business on the second scheduled trading day immediately preceding the maturity date, holders of the 2025 Notes may convert all or any portion of their 2025 Notes at any

[0000926326-25-000019:notes:96]
time. As the 2025 Notes will mature on September 15, 2025, the Company classified the 2025 Notes as a current liability in its Condensed Consolidated Financial Statements as of both June 30, 2025 and December 31, 2024.

[0000926326-25-000019:notes:97]
Under the original terms of the 2025 Notes Indenture, upon conversion, the Company could satisfy its conversion obligation by paying or delivering cash, shares of its common stock, or a combination thereof, at the Company’s election, in the manner and subject to the terms and conditions provided in the 2025 Notes Indenture. On December 13, 2021, the Company irrevocably elected to fix its settlement method to a combination of cash and shares of the Company’s common stock with the specified cash amount per $1,000 principal amount of 2025 Notes of at least $1,000. As a result, for 2025 Notes converted on or after December 13, 2021, a converting noteholder will receive (i) up to $1,000 in cash per $1,000 principal amount of 2025 Notes and (ii) as of May 15, 2025, a converting noteholder will receive shares of the Company’s common stock for any conversion consideration in excess of $1,000. The initial conversion rate for the 2025 Notes is 10.2751 shares of the Company’s common stock per $1,000 principal amount of 2025 Notes, which is equivalent to an initial conversion price of approximately $97.32 per share of the Company’s common stock, subject to adjustment under certain circumstances in accordance with the terms of the 2025 Notes Indenture. In addition, following certain corporate events that could occur prior to the maturity date of the 2025 Notes or if the Company delivers a notice of redemption in respect of the 2025 Notes, the Company will, under certain circumstances, increase the conversion rate of the 2025 Notes for a holder who elects to convert its 2025 Notes (or any portion thereof) in connection with such a corporate event or convert its 2025 Notes called (or deemed called) for redemption during the related redemption period (as defined in the 2025 Notes Indenture), as the case may be.

[0000926326-25-000019:notes:98]
If the Company undergoes a fundamental change, holders may require, subject to certain exceptions, the Company to repurchase for cash all or any portion of their 2025 Notes at a fundamental change repurchase price equal to 100% of the principal amount of the 2025 Notes to be repurchased, plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date. As of June 30, 2025, none of the criteria for a fundamental change or a conversion rate adjustment had been met.

[0000926326-25-000019:notes:99]
As of June 30, 2025, the Company may redeem for cash all or any portion of the 2025 Notes, at its option, if the last reported sale price of the Company’s common stock has been at least 130% of the conversion price for the 2025 Notes then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which the Company provides notice of redemption at a redemption price equal to 100% of the principal amount of the 2025 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. If the Company redeems less than all of the outstanding 2025 Notes, at least $150.0 million aggregate principal amount of the 2025 Notes must be outstanding and not subject to redemption as of the date of the relevant notice of redemption. No sinking fund is provided for in the 2025 Notes.

[0000926326-25-000019:notes:100]
Partial Repurchase of the 2025 Notes

[0000926326-25-000019:notes:101]
In November 2024, the Company entered into separate, privately negotiated transactions with certain holders of the 2025 Notes to repurchase $400.0 million of aggregate principal amount of the 2025 Notes for approximately $391.0 million of cash. The Company accounted for the partial repurchase of 2025 Notes as a debt extinguishment and recorded a $7.2 million gain on extinguishment, which included a partial write-off of previously deferred debt issuance costs of $1.8 million during the three months ended December 31, 2024.

[0000926326-25-000019:notes:102]
The debt issuance costs associated with the remaining 2025 Notes are being amortized to interest expense over the term of the 2025 Notes using an effective interest rate of 0.80%. As of June 30, 2025, the remaining life of the 2025 Notes and the related issuance cost accretion is approximately 0.2 years.

[0000926326-25-000019:notes:103]
Following the partial repurchase of the 2025 Notes, the maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to other conversion rate adjustments, would be 1.8 million shares. As of June 30, 2025, the if-converted value of the 2025 Notes did not exceed the principal amount.

[0000926326-25-000019:notes:104]
1.00% Convertible Senior Notes due 2029

[0000926326-25-000019:notes:105]
On November 22, 2024, Omnicell, Inc. completed a private offering of $172.5 million aggregate principal amount of 1.00% Convertible Senior Notes due 2029 (the “2029 Notes”), including the exercise in full of the initial purchasers’ option to purchase up to an additional $22.5 million aggregate principal amount of the 2029 Notes. Omnicell, Inc. received proceeds from the issuance of the 2029 Notes of $166.3 million, net of $6.2 million of transaction fees and other debt issuance costs. The 2029 Notes bear interest at a rate of 1.00% per year, payable semiannually in arrears on June 1 and December 1 of each year, beginning on June 1, 2025. The 2029 Notes were issued pursuant to an indenture, dated November 22, 2024 (the “2029 Notes Indenture”), between the Company and U.S. Bank Trust Company, National Association, as trustee. The 2029 Notes are general senior, unsecured obligations of the Company and will mature on December 1, 2029, unless earlier redeemed, purchased, or converted.

[0000926326-25-000019:notes:106]
The 2029 Notes are convertible at any time prior to the close of business on the business day immediately preceding August 1, 2029, only under the following circumstances: (i) during any fiscal quarter commencing after the fiscal quarter ending on March 31, 2025 (and only during such fiscal quarter), if the last reported sale price of the Company’s common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on, and including, the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the 2029 Notes on each applicable trading day; (ii) during the five business day period after any ten consecutive trading day period (the “measurement period”) in which the “trading price” (as defined in the 2029 Notes Indenture) per $1,000 principal amount of the 2029 Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of the Company’s common stock and the conversion rate for the 2029 Notes on each such trading day; (iii) if the Company calls such 2029 Notes for redemption, at any time prior to the close of business on the scheduled trading day immediately preceding the redemption date, but only with respect to the 2029 Notes called (or deemed called) for redemption; or (iv) upon the occurrence of specified corporate events as set forth in the 2029 Notes Indenture. On or after August 1, 2029 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders of the 2029 Notes may convert all or any portion of their 2029 Notes at any time, regardless of the foregoing conditions.

[0000926326-25-000019:notes:107]
During the three months ended June 30, 2025 and December 31, 2024, none of the conditional conversion features of the 2029 Notes were triggered, and therefore, the 2029 Notes are not convertible during the third quarter of 2025, commencing on July 1, 2025, and were not convertible during the first quarter of 2025, commencing on January 1, 2025.

[0000926326-25-000019:notes:108]
Upon conversion, the Company will pay cash up to the aggregate principal amount of the 2029 Notes to be converted and pay or deliver, as the case may be, cash, shares of the Company’s common stock or a combination of cash and shares of the Company’s common stock, at the Company’s election, in respect to the remainder, if any, of the Company’s conversion obligation in excess of the aggregate principal amount of the 2029 Notes being converted, in the manner and subject to the terms and conditions provided in the 2029 Notes Indenture.

[0000926326-25-000019:notes:109]
The initial conversion rate for the 2029 Notes is 17.4662 shares of the Company’s common stock per $1,000 principal amount of the 2029 Notes, which is equivalent to an initial conversion price of approximately $57.25 per share of the Company’s common stock, subject to adjustment under certain circumstances in accordance with the terms of the 2029 Notes Indenture. In addition, following certain corporate events that occur prior to the maturity date of the 2029 Notes or if the Company delivers a notice of redemption in respect of the 2029 Notes, the Company will, under certain circumstances, increase the conversion rate of the 2029 Notes for a holder who elects to convert its 2029 Notes (or any portion thereof) in connection with such a corporate event or convert its 2029 Notes called (or deemed called) for redemption during the related redemption period (as defined in the 2029 Notes Indenture), as the case may be.

[0000926326-25-000019:notes:110]
If the Company undergoes a fundamental change (as defined in the 2029 Notes Indenture), holders may require, subject to certain exceptions, the Company to repurchase for cash all or any portion of their 2029 Notes at a fundamental change repurchase price equal to 100% of the principal amount of the 2029 Notes to be repurchased, plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date. As of June 30, 2025, none of the criteria for a fundamental change or a conversion rate adjustment had been met.

[0000926326-25-000019:notes:111]
The Company may not redeem the 2029 Notes prior to December 6, 2027. The Company may redeem for cash all or any portion of the 2029 Notes, at its option, on or after December 6, 2027, if the last reported sale price of the Company’s common stock has been at least 130% of the conversion price for the 2029 Notes then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which the Company provides notice of redemption at a redemption price equal to 100% of the principal amount of the 2029 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. The Company may not redeem less than all of the outstanding 2029 Notes unless at least $100.0 million aggregate principal amount of 2029 Notes are outstanding and not called for redemption as of the time the Company sends the related notice of redemption. No sinking fund is provided for in the 2029 Notes.

[0000926326-25-000019:notes:112]
The debt issuance costs associated with the 2029 Notes are being amortized to interest expense over the term of the 2029 Notes using an effective interest rate of 1.75%. As of June 30, 2025, the remaining life of the 2029 Notes and the related issuance cost accretion is approximately 4.4 years.

[0000926326-25-000019:notes:113]
The maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to other conversion rate adjustments, would be 3.0 million shares. As of June 30, 2025, the if-converted value of the 2029 Notes did not exceed the principal amount.

[0000926326-25-000019:notes:114]
The 2025 Notes and the 2029 Notes consisted of the following balances:

[0000926326-25-000019:notes:115]
|  | June 30,2025 |  | December 31,2024 |
|  | (In thousands) |
| 2025 Notes: |  |  |  |
| Principal amount | $ | 175,000 |  |  | $ | 175,000 |  |
| Unamortized debt issuance costs | (199) |  |  | (676) |  |
| Convertible senior notes, net, current | $ | 174,801 |  |  | $ | 174,324 |  |
| 2029 Notes: |  |  |  |
| Principal amount | $ | 172,500 |  |  | $ | 172,500 |  |
| Unamortized debt issuance costs | (5,506) |  |  | (6,103) |  |
| Convertible senior notes, net, noncurrent | $ | 166,994 |  |  | $ | 166,397 |  |

[0000926326-25-000019:notes:116]
The following table summarizes the components of interest expense resulting from the 2025 Notes and the 2029 Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations:

[0000926326-25-000019:notes:117]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  | (In thousands) |
| Contractual coupon interest: |  |  |  |  |  |  |  |
| 2025 Notes | $ | 110 |  |  | $ | 359 |  |  | $ | 219 |  |  | $ | 719 |  |
| 2029 Notes | $ | 432 |  |  | $ | — |  |  | 863 |  |  | — |  |
| Amortization of debt issuance costs: |  |  |  |  |  |  |  |
| 2025 Notes | $ | 239 |  |  | $ | 778 |  |  | $ | 477 |  |  | $ | 1,555 |  |
| 2029 Notes | $ | 294 |  |  | $ | — |  |  | 597 |  |  | — |  |

[0000926326-25-000019:notes:118]
Convertible Note Hedge and Warrant Transactions

[0000926326-25-000019:notes:119]
In connection with the issuance of the 2025 Notes in September 2020 and the 2029 Notes in November 2024, the Company entered into convertible note hedges and warrants transactions, respectively, with certain initial purchasers of the 2025 Notes and the 2029 Notes or affiliates thereof and certain other financial institutions (the “option counterparties”).

[0000926326-25-000019:notes:120]
The convertible note hedges related to the 2025 Notes consisted of call options for the Company to purchase, subject to anti-dilution adjustments substantially similar to those applicable to the 2025 Notes, up to approximately 5.9 million shares of the Company’s common stock, which is equal to the number of shares of the Company’s common stock underlying the 2025 Notes at the time of its issuance, at an initial strike price of approximately $97.32 per share. The convertible note hedges related to the 2029 Notes consisted of call options for the Company to purchase up to, subject to anti-dilution adjustments substantially similar to those applicable to the 2029 Notes, approximately 3.0 million shares of the Company’s common stock, which is equal to the number of shares of the Company’s common stock underlying the 2029 Notes at the time of its issuance, at an initial strike price of approximately $57.25 per share. The convertible note hedges will expire upon the maturity of the respective convertible notes, if not earlier exercised or terminated. The cost of the convertible note hedges related to the 2025 Notes and the 2029 Notes was approximately $100.6 million and $40.3 million, respectively, and each was accounted for as an equity instrument, each of which was recorded in additional paid-in capital in the Condensed Consolidated Balance Sheets. In addition, the Company recorded a deferred tax asset of $25.8 million and $10.2 million, respectively, at issuance related to the convertible note hedges for the 2025 Notes and the 2029 Notes. The convertible note hedges are expected generally to reduce the potential dilution to the Company’s common stock upon any conversion of the 2025 Notes or the 2029 Notes and/or offset any cash payments the Company may be required to make in excess of the principal amount of the converted 2025 Notes or the 2029 Notes.

[0000926326-25-000019:notes:121]
Separately from the convertible note hedges, in September 2020 and November 2024, the Company entered into warrant transactions to sell to the respective option counterparties warrants to acquire, subject to customary anti-dilution adjustments, up to approximately 5.9 million shares of its common stock at an initial strike price of approximately $141.56 and approximately 3.0 million shares of its common stock at an initial strike price of approximately $84.82 per share related to the 2025 Notes and the 2029 Notes, respectively. The warrants require net share or net cash settlement upon the Company’s

[0000926326-25-000019:notes:122]
election. The Company received aggregate proceeds of approximately $51.3 million and $25.2 million for the issuance of the warrants related to the 2025 Notes and the 2029 Notes, respectively, which was recorded in additional paid-in capital at issuance in the Condensed Consolidated Balance Sheets. The warrants could separately have a dilutive effect to the Company’s common stock to the extent that the market price per share of its common stock, as measured under the warrants, exceeds the strike price of the warrants.
In November 2024, in connection with the partial repurchase of the 2025 Notes, the Company entered into unwind agreements with the existing option counterparties to the convertible note hedges and warrants related to the 2025 Notes to terminate a portion of the existing convertible note hedges and warrants related to the 2025 Notes at a notional amount corresponding to the amount of the 2025 Notes repurchased, resulting in an immaterial gain


## us-gaap:LessorSalesTypeLeasesTextBlock

[0000926326-25-000019:notes:123]
[same as prior period, unchanged from 0000926326-25-000009:notes:127]

[0000926326-25-000019:notes:124]
[same as prior period, unchanged from 0000926326-25-000009:notes:128]

[0000926326-25-000019:notes:125]
[same as prior period, unchanged from 0000926326-25-000009:notes:129]

[0000926326-25-000019:notes:126]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  | (In thousands) |
| Sales-type lease revenues | $ | 6,631 |  |  | $ | 11,576 |  |  | $ | 12,449 |  |  | $ | 18,612 |  |
| Cost of sales-type lease revenues | (4,102) |  |  | (7,110) |  |  | (7,039) |  |  | (11,297) |  |
| Selling profit on sales-type lease revenues | $ | 2,529 |  |  | $ | 4,466 |  |  | $ | 5,410 |  |  | $ | 7,315 |  |

[0000926326-25-000019:notes:127]
[same as prior period, unchanged from 0000926326-25-000009:notes:131]

[0000926326-25-000019:notes:128]
|  | June 30,2025 |  | December 31,2024 |
|  | (In thousands) |
| Net minimum lease payments to be received | $ | 79,433 |  |  | $ | 77,976 |  |
| Less: Unearned interest income portion | (12,847) |  |  | (12,757) |  |
| Net investment in sales-type leases | 66,586 |  |  | 65,219 |  |
| Less: Current portion (1) | (12,629) |  |  | (12,475) |  |
| Long-term investment in sales-type leases, net | $ | 53,957 |  |  | $ | 52,744 |  |

[0000926326-25-000019:notes:129]
[same as prior period, unchanged from 0000926326-25-000009:notes:133]

[0000926326-25-000019:notes:130]
[same as prior period, unchanged from 0000926326-25-000009:notes:134]

[0000926326-25-000019:notes:131]
[same as prior period, unchanged from 0000926326-25-000009:notes:135]

[0000926326-25-000019:notes:132]
|  | June 30,2025 |
|  | (In thousands) |
| Remaining six months of 2025 | $ | 8,536 |  |
| 2026 | 15,310 |  |
| 2027 | 14,266 |  |
| 2028 | 13,176 |  |
| 2029 | 10,511 |  |
| Thereafter | 17,634 |  |
| Total future minimum sales-type lease payments | 79,433 |  |
| Present value adjustment | (12,847) |  |
| Total net investment in sales-type leases | $ | 66,586 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0000926326-25-000019:notes:133]
Lessee Leases 
The Company has operating leases for office buildings, data centers, office equipment, and vehicles. The Company’s leases have initial terms of one to twelve years. As of June 30, 2025, the Company did not have any additional material operating leases that were entered into, but not yet commenced.

[0000926326-25-000019:notes:134]
[same as prior period, unchanged from 0000926326-25-000009:notes:138]

[0000926326-25-000019:notes:135]
|  | June 30,2025 |
|  | (In thousands) |
| Remaining six months of 2025 | $ | 6,976 |  |
| 2026 | 13,601 |  |
| 2027 | 11,637 |  |
| 2028 | 9,948 |  |
| 2029 | 3,176 |  |
| Thereafter | 1,935 |  |
| Total operating lease payments | 47,273 |  |
| Present value adjustment | (4,658) |  |
| Total operating lease liabilities (1) | $ | 42,615 |  |

[0000926326-25-000019:notes:136]
(1)    Amount consists of a current and long-term portion of operating lease liabilities of $11.9 million and $30.8 million, respectively. The current portion of the operating lease liabilities is included in accrued liabilities in the Condensed Consolidated Balance Sheets.

[0000926326-25-000019:notes:137]
Operating lease costs were $2.7 million and $2.6 million for the three months ended June 30, 2025 and 2024, respectively, and $5.1 million and $5.2 million for the six months ended June 30, 2025 and 2024, respectively. Short-term lease costs and variable lease costs were not material for the three and six months ended June 30, 2025 and 2024.

[0000926326-25-000019:notes:138]
[same as prior period, unchanged from 0000926326-25-000009:notes:142]

[0000926326-25-000019:notes:139]
|  | Six Months Ended June 30, |
|  | 2025 |  | 2024 |
|  | (In thousands) |
| Cash paid for amounts included in the measurement of lease liabilities | $ | 7,012 |  |  | $ | 6,765 |  |
| Right-of-use assets obtained in exchange for new lease liabilities | $ | 6,022 |  |  | $ | 5,509 |  |

[0000926326-25-000019:notes:140]
[same as prior period, unchanged from 0000926326-25-000009:notes:144]

[0000926326-25-000019:notes:141]
|  | June 30,2025 |  | December 31,2024 |
| Weighted-average remaining lease term, years | 3.8 |  | 4.1 |
| Weighted-average discount rate, % | 5.5 | % |  | 5.8 | % |


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000926326-25-000019:notes:142]
Commitments and Contingencies
Purchase Obligations

[0000926326-25-000019:notes:143]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of June 30, 2025, the Company had non-cancelable purchase commitments of $139.2 million, of which $111.4 million are expected to be paid within the year ending December 31, 2025.

[0000926326-25-000019:notes:144]
Legal Proceedings

[0000926326-25-000019:notes:145]
The Company is currently involved in various legal proceedings.

[0000926326-25-000019:notes:146]
In December 2023, Omnicell received a civil request for records issued by the U.S. Attorney’s Office for the Eastern District of Washington (the “Government”) related to the Company’s compliance with the pricing terms and conditions of its previous Federal Supply Schedule (“FSS”) contract with the federal government. In December 2024, the Government presented information identifying certain potential non-compliances with the FSS contract and associated potential violations of the False Claims Act. On May 5, 2025, Omnicell entered into a settlement agreement with the Government to resolve this matter. The settlement, which settled the matter without admission of liability, required payment of approximately $4.6 million to cover damages and other statutorily provided amounts under the False Claims Act, which was paid on May 19, 2025. The Company does not expect further engagement with the federal Government regarding this matter.

[0000926326-25-000019:notes:147]
As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any material accrual for contingent liabilities associated with any current legal proceedings based on its belief that any potential material loss, while reasonably possible, is not probable. Furthermore, any possible range of loss in these matters either cannot be reasonably estimated at this time or is not deemed material. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of legal proceedings or because of the diversion of management’s attention and the creation of significant expenses, regardless of outcome.

[0000926326-25-000019:notes:148]
The Company is not a party to any legal proceedings that management believes may have a material impact on the Company’s financial position or results of operations.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000926326-25-000019:notes:149]
Income Taxes 
The Company generally provides for income taxes in interim periods based on the estimated annual effective tax rate for the year, adjusting for discrete items in the quarter in which they arise. For both the six months ended June 30, 2025 and 2024, the Company recorded a provision for income taxes of $2.3 million by applying its estimated annual effective tax rate to its year-to-date measure of ordinary income and adjusted for $2.0 million and $3.3 million, respectively, of discrete income tax expense primarily from equity compensation.

[0000926326-25-000019:notes:150]
The effective tax rate for the six months ended June 30, 2025 differed from the statutory rate of 21% primarily due to the unfavorable impact of state taxes, non-deductible compensation and equity charges, partially offset by the favorable impact of the research and development credits and a foreign-derived intangible income (“FDII”) deduction. The effective tax rate for the six months ended June 30, 2024 differed from the statutory rate of 21% primarily due to the benefit of the research and development credits and a foreign-derived intangible income benefit deduction, partially offset by the unfavorable impact of the non-deductible compensation, equity charges, and Global Intangible Low-Taxed Income tax inclusion.

[0000926326-25-000019:notes:151]
On July 4, 2025, the One Big Beautiful Bill Act (the “OBBBA”) was enacted in the United States, which includes significant tax reform provisions. Included in the OBBBA are provisions that allow for the immediate expensing of domestic United States research and development expenses, immediate expensing of certain capital expenditures, and other changes to the U.S. taxation of profits derived from foreign operations. The Company is currently evaluating the impact that the OBBBA may have on its consolidated financial statements.

[0000926326-25-000019:notes:152]
The Organization for Economic Co-Operation and Development introduced Base Erosion and Profit Shifting Pillar Two rules that impose a global minimum tax rate of 15% on multi-national corporations. These rules did not have an impact on the Company’s provision for income taxes for the six months ended June 30, 2025.

[0000926326-25-000019:notes:153]
As of June 30, 2025 and December 31, 2024, the Company had gross unrecognized tax benefits of $11.0 million and $10.5 million, respectively. The Company recognizes interest and penalties related to uncertain tax positions in interest and other income (expense), net in the Condensed Consolidated Statements of Operations. Accrued interest and penalties are included within other long-term liabilities on the Condensed Consolidated Balance Sheets. As of June 30, 2025 and December 31, 2024, the amount of accrued interest and penalties was $0.9 million and $0.6 million, respectively.

[0000926326-25-000019:notes:154]
The Company files income tax returns in the United States and various state and foreign jurisdictions. In the normal course of business, the Company is subject to examinations by taxing authorities, including major jurisdictions such as the United States, Germany, Italy, France, the United Kingdom, and India. With few exceptions, as of June 30, 2025, the Company was no longer subject to U.S., state, and foreign tax examinations for years before 2021, 2020, and 2020, respectively.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000926326-25-000019:notes:155]
[same as prior period, unchanged from 0000926326-25-000009:notes:159]

[0000926326-25-000019:notes:156]
[same as prior period, unchanged from 0000926326-25-000009:notes:160]

[0000926326-25-000019:notes:157]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  | (In thousands) |
| Cost of product and service revenues | $ | 1,207 |  |  | $ | 1,620 |  |  | $ | 2,925 |  |  | $ | 3,175 |  |
| Research and development | 1,022 |  |  | 1,139 |  |  | 2,242 |  |  | 2,214 |  |
| Selling, general, and administrative | 8,301 |  |  | 7,272 |  |  | 16,149 |  |  | 13,283 |  |
| Total share-based compensation expense | $ | 10,530 |  |  | $ | 10,031 |  |  | $ | 21,316 |  |  | $ | 18,672 |  |

[0000926326-25-000019:notes:158]
The Company capitalized approximately $0.6 million and $1.0 million during the three months ended June 30, 2025 and 2024, respectively, and $1.4 million and $1.7 million during the six months ended June 30, 2025 and 2024, respectively, of share-based compensation expense to internal-use and external-use software development costs related to internal labor. The Company did not capitalize any material share-based compensation expense to inventory during the three and six months ended June 30, 2025 and 2024.

[0000926326-25-000019:notes:159]
[same as prior period, unchanged from 0000926326-25-000009:notes:163]

[0000926326-25-000019:notes:160]
The following assumptions were used to value shares under the ESPP:

[0000926326-25-000019:notes:161]
|  |  |  | Three and Six Months Ended June 30, |
|  |  |  |  |  | 2025 |  | 2024 |
| Expected life, years |  |  |  |  | 0.5 - 2.0 |  | 0.5 - 2.0 |
| Expected volatility, % |  |  |  |  | 45.8% - 58.7% |  | 33.7% - 57.0% |
| Risk-free interest rate, % |  |  |  |  | 4.1% - 5.2% |  | 1.5% - 5.5% |
| Dividend yield, % |  |  |  |  | — | % |  | — | % |

[0000926326-25-000019:notes:162]
For the six months ended June 30, 2025 and 2024, employees purchased approximately 335,000 and 334,000 shares of common stock, respectively, under the ESPP at a weighted-average price of $24.57 and $24.06, respectively.

[0000926326-25-000019:notes:163]
[same as prior period, unchanged from 0000926326-25-000009:notes:167]

[0000926326-25-000019:notes:164]
[same as prior period, unchanged from 0000926326-25-000009:notes:168]

[0000926326-25-000019:notes:165]
|  | Number ofShares |  | Weighted-AverageExercise Price |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2024 | 1,760 |  |  | $ | 67.51 |  |  | 3.6 |  | $ | 2,619 |  |
| Granted | — |  |  | — |  |  |  |  |  |
| Exercised | (1) |  |  | 30.92 |  |  |  |  |  |
| Expired | (131) |  |  | 70.64 |  |  |  |  |  |
| Forfeited | — |  |  | — |  |  |  |  |  |
| Outstanding at June 30, 2025 | 1,628 |  |  | $ | 67.29 |  |  | 3.2 |  | $ | 84 |  |
| Exercisable at June 30, 2025 | 1,627 |  |  | $ | 67.23 |  |  | 3.2 |  | $ | 84 |  |
| Vested and expected to vest at June 30, 2025 and thereafter | 1,628 |  |  | $ | 67.28 |  |  | 3.2 |  | $ | 84 |  |

[0000926326-25-000019:notes:166]
[same as prior period, unchanged from 0000926326-25-000009:notes:170]

[0000926326-25-000019:notes:167]
[same as prior period, unchanged from 0000926326-25-000009:notes:171]

[0000926326-25-000019:notes:168]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2024 | 1,614 |  |  | $ | 54.58 |  |  | 1.6 |  | $ | 71,849 |  |
| Granted | 186 |  |  | 33.09 |  |  |  |  |  |
| Vested | (186) |  |  | 73.11 |  |  |  |  |  |
| Forfeited | (214) |  |  | 54.66 |  |  |  |  |  |
| Outstanding and unvested at June 30, 2025 | 1,400 |  |  | $ | 49.27 |  |  | 1.3 |  | $ | 41,166 |  |

[0000926326-25-000019:notes:169]
As of June 30, 2025, total unrecognized compensation cost related to RSUs was $41.1 million, which is expected to be recognized over the remaining weighted-average vesting period of 2.6 years.

[0000926326-25-000019:notes:170]
[same as prior period, unchanged from 0000926326-25-000009:notes:174]

[0000926326-25-000019:notes:171]
[same as prior period, unchanged from 0000926326-25-000009:notes:175]

[0000926326-25-000019:notes:172]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2024 | 177 |  |  | $ | 28.67 |  |
| Granted (Awarded) | 139 |  |  | 32.66 |  |
| Additional granted based on performance achievement | 135 |  |  | 28.67 |  |
| Vested (Released) | (97) |  |  | 28.67 |  |
| Forfeited | — |  |  | — |  |
| Outstanding and unvested at June 30, 2025 | 354 |  |  | $ | 30.24 |  |

[0000926326-25-000019:notes:173]
As of June 30, 2025, total unrecognized compensation cost related to PSUs was approximately $4.3 million, which is expected to be recognized over the remaining weighted-average vesting period of 1.3 years.

[0000926326-25-000019:notes:174]
[same as prior period, unchanged from 0000926326-25-000009:notes:178]

[0000926326-25-000019:notes:175]
The Company had the following ordinary shares reserved for future issuance under its equity incentive plans as of June 30, 2025:

[0000926326-25-000019:notes:176]
|  | Number of Shares |
|  | (In thousands) |
| Stock options outstanding | 1,628 |  |
| Non-vested restricted stock awards | 1,808 |  |
| Shares authorized for future issuance | 4,691 |  |
| ESPP shares available for future issuance | 2,391 |  |
| Total shares reserved for future issuance | 10,518 |  |

[0000926326-25-000019:notes:177]
[same as prior period, unchanged from 0000926326-25-000009:notes:181]

[0000926326-25-000019:notes:178]
On May 22, 2025, the Company’s Board of Directors (the “Board”) authorized a new stock repurchase program, which does not expire, providing for the repurchase of up to $75.0 million of the Company’s common stock (the “2025 Repurchase Program”). The 2025 Repurchase Program is in addition to the stock repurchase program approved by the Board on August 2, 2016 providing for the repurchase of up to $50.0 million of the Company’s common stock (the “2016 Repurchase Program”). As of December 31, 2024, the maximum dollar value of shares that may yet be purchased under the 2016 Repurchase Program was $2.7 million and during the three and six months ended June 30, 2025, the 2016 Repurchase Program was completed.

[0000926326-25-000019:notes:179]
The timing, price, and volume of repurchases are to be based on a variety of factors, including market conditions, relevant securities laws and regulatory requirements, and other corporate considerations, as determined by the Company’s management. Stock repurchases may be made from time to time on the open market, through block trades, in privately negotiated transactions, accelerated or other structured stock repurchase programs, or pursuant to a Rule 10b5-1 plan. The 2025 Repurchase Program does not obligate the Company to repurchase any specific number of shares, and the Company may terminate or suspend the 2025 Repurchase Program at any time.

[0000926326-25-000019:notes:180]
During the three and six months ended June 30, 2025, the Company repurchased approximately 536,000 shares of its common stock under the repurchase programs at an average price of $29.24 per share for an aggregate purchase price of approximately $15.7 million. During the three and six months ended June 30, 2024, the Company did not repurchase any of its outstanding common stock under the 2016 Repurchase Program. As of June 30, 2025, the maximum dollar value of shares that may yet be purchased under the 2025 Repurchase Program was $62.1 million.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000926326-25-000019:notes:181]
Restructuring Expenses
On April 26, 2024, the Company’s management committed to the wind down of the Company’s Medimat Robotic Dispensing System (“RDS”) product line, subject to local law and statutory works council consultation requirements. During the six months ended June 30, 2024, the Company incurred approximately $3.3 million of employee severance costs and other expenses related to the RDS product line wind down. During the three months ended June 30, 2024, the Company did not incur any additional employee-related expenses related to the RDS product line wind down. In addition, during the three and six months ended June 30, 2024, the Company incurred $5.4 million of inventory write-down charges related to the RDS product line wind down that were recorded to cost of revenues in the Company’s Condensed Consolidated Statements of Operations. During the three and six months ended June 30, 2025, the Company did not incur any material restructuring expenses.

[0000926326-25-000019:notes:182]
[same as prior period, unchanged from 0000926326-25-000009:notes:187]

[0000926326-25-000019:notes:183]
|  |  |  |  |  | Six Months Ended June 30, |
|  |  |  |  |  |  |  | 2024 |
|  |  |  |  |  |  |  | (In thousands) |
| Cost of product and service revenues |  |  |  |  |  |  | $ | 2,696 |  |
| Research and development |  |  |  |  |  |  | 311 |  |
| Selling, general, and administrative |  |  |  |  |  |  | 156 |  |
| Total restructuring expense |  |  |  |  |  |  | $ | 3,163 |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0000926326-25-000019:notes:184]
During the three months ended June 30, 2025, Corey J. Manley, the Company’s Executive Vice President and Chief Legal and Administrative Officer, adopted a new “Rule 10b5-1 trading arrangement” (as defined in Item 408(a) of Regulation S-K) on June 13, 2025, which is intended to satisfy the Rule 10b5-1(c) affirmative defense. Mr. Manley’s trading plan is effective from September 12, 2025 until the earlier of: (1) June 12, 2026; or (2) the date on which all of the transactions under the trading plan are completed. The trading plan is intended to let Mr. Manley sell up to 46,131 shares of common stock, which represents a combination of previously vested shares and gross amounts of shares that will vest over the duration of the plan (shares that will actually be sold under the plan are net of tax withholding). As of the date of this report, none of the shares were sold and no other adjustments were made to the trading plan during the current reporting period.
