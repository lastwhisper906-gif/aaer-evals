# OMCL 8-K — 0000926326-25-000016 filed 2025-07-31

## item codes, every 8-K on or before 2025-08-06

- 2025-07-31 0000926326-25-000016 — 2.02, 9.01
- 2025-06-05 0001104659-25-056908 — 5.02, 9.01
- 2025-05-23 0001104659-25-052464 — 5.02, 5.07, 9.01
- 2025-05-22 0001104659-25-051854 — 7.01, 9.01
- 2025-05-06 0000926326-25-000006 — 2.02, 9.01
- 2025-03-12 0001104659-25-022797 — 5.02, 7.01, 9.01
- 2025-03-04 0001104659-25-020354 — 5.02, 9.01
- 2025-02-06 0001104659-25-009872 — 2.02, 9.01
- 2024-11-25 0001104659-24-122635 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2024-11-18 0001104659-24-120206 — 1.01, 8.01, 9.01
- 2024-10-30 0000926326-24-000030 — 2.02, 9.01
- 2024-09-25 0001104659-24-102781 — 5.02, 9.01
- 2024-08-01 0000926326-24-000024 — 2.02, 9.01
- 2024-06-04 0000926326-24-000019 — 5.02 — amendment of 0001104659-24-029356
- 2024-05-24 0001104659-24-065130 — 5.02, 5.07, 9.01
- 2024-05-02 0000926326-24-000012 — 2.02, 2.05, 9.01
- 2024-02-29 0001104659-24-029356 — 5.02
- 2024-02-08 0000926326-24-000005 — 2.02, 9.01
- 2024-01-11 0000926326-24-000002 — 5.02, 7.01, 8.01, 9.01
- 2023-11-09 0000926326-23-000043 — 5.02, 9.01
- 2023-11-02 0001104659-23-113604 — 2.02, 2.05, 7.01, 9.01
- 2023-10-16 0000926326-23-000039 — 1.01, 2.03, 9.01
- 2023-10-05 0000926326-23-000037 — 5.02, 9.01
- 2023-08-16 0000926326-23-000035 — 5.02
- 2023-08-10 0000926326-23-000033 — 5.02, 9.01
- 2023-08-03 0000926326-23-000029 — 5.02, 9.01
- 2023-08-01 0000926326-23-000027 — 2.02, 9.01
- 2023-07-11 0000926326-23-000025 — 5.02, 9.01
- 2023-06-26 0000926326-23-000022 — 5.02 — amendment of 0001104659-23-026700
- 2023-05-30 0001104659-23-066011 — 5.02, 9.01
- 2023-05-26 0000926326-23-000020 — 5.02, 5.07, 9.01
- 2023-05-15 0001104659-23-060768 — 5.02, 9.01
- 2023-05-02 0000926326-23-000011 — 2.02, 9.01
- 2023-04-03 0000926326-23-000009 — 1.01, 2.03, 9.01
- 2023-02-28 0001104659-23-026700 — 2.02, 2.05, 5.02, 9.01
- 2022-11-30 0000926326-22-000036 — 2.05
- 2022-11-02 0000926326-22-000031 — 2.02, 9.01
- 2022-10-21 0000926326-22-000029 — 5.03, 9.01
- 2022-09-20 0001104659-22-101566 — 7.01, 9.01
- 2022-09-20 0001104659-22-101360 — 7.01, 9.01
- 2022-08-04 0000926326-22-000025 — 2.02, 8.01, 9.01
- 2022-05-31 0000926326-22-000020 — 5.02, 5.07, 9.01
- 2022-05-24 0000926326-22-000016 — 5.02
- 2022-05-09 0000926326-22-000012 — 8.01
- 2022-04-28 0000926326-22-000009 — 2.02, 9.01
- 2022-03-01 0001104659-22-028681 — 5.02, 8.01, 9.01
- 2022-02-14 0000926326-22-000004 — 2.02, 9.01
- 2022-01-04 0000926326-22-000002 — 7.01, 9.01
- 2021-12-29 0001104659-21-154294 — 7.01, 9.01
- 2021-12-13 0000926326-21-000039 — 8.01
- 2021-12-02 0000926326-21-000037 — 7.01, 9.01
- 2021-11-02 0000926326-21-000031 — 2.02, 9.01
- 2021-09-09 0000926326-21-000028 — 7.01, 9.01
- 2021-07-29 0000926326-21-000024 — 2.02, 9.01
- 2021-07-26 0000926326-21-000022 — 7.01, 9.01
- 2021-07-12 0000926326-21-000019 — 5.02, 9.01
- 2021-05-28 0000926326-21-000015 — 5.07
- 2021-04-29 0000926326-21-000011 — 2.02, 9.01
- 2021-02-01 0000926326-21-000004 — 2.02, 9.01
- 2021-01-26 0000926326-21-000002 — 5.02
- 2021-01-13 0001104659-21-003672 — 2.02, 7.01, 9.01
- 2020-10-27 0000926326-20-000032 — 2.02, 9.01
- 2020-10-01 0000926326-20-000029 — 7.01, 9.01
- 2020-09-25 0001104659-20-108924 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2020-09-22 0001104659-20-107176 — 1.01, 8.01, 9.01
- 2020-08-12 0000926326-20-000027 — 2.03
- 2020-08-12 0000926326-20-000025 — 1.01, 5.03, 7.01, 9.01
- 2020-07-28 0000926326-20-000021 — 2.02, 9.01
- 2020-05-27 0000926326-20-000017 — 5.07
- 2020-05-07 0000926326-20-000012 — 2.02, 9.01
- 2020-02-18 0000926326-20-000007 — 5.02, 9.01
- 2020-02-13 0000926326-20-000005 — 8.01
- 2020-02-06 0000926326-20-000003 — 2.02, 9.01
- 2019-12-06 0001104659-19-070339 — 8.01
- 2019-11-18 0000926326-19-000035 — 1.01, 2.03, 9.01
- 2019-10-24 0000926326-19-000028 — 2.02, 9.01
- 2019-07-25 0000926326-19-000021 — 2.02, 9.01
- 2019-05-15 0000926326-19-000015 — 5.07
- 2019-04-25 0000926326-19-000011 — 2.02, 9.01
- 2019-03-08 0000926326-19-000009 — 5.02, 9.01
- 2019-02-19 0000926326-19-000005 — 5.02, 9.01
- 2019-02-07 0000926326-19-000003 — 2.02, 9.01
- 2018-10-25 0000926326-18-000028 — 2.02, 9.01
- 2018-09-14 0001104659-18-056929 — 5.02, 9.01
- 2018-07-26 0000926326-18-000022 — 2.02, 9.01
- 2018-06-06 0000926326-18-000019 — 5.02, 9.01
- 2018-05-16 0001104659-18-033801 — 5.07
- 2018-04-26 0000926326-18-000013 — 2.02, 9.01
- 2018-03-02 0001104659-18-014497 — 5.02
- 2018-02-08 0000926326-18-000007 — 5.02
- 2018-02-02 0000926326-18-000005 — 5.02
- 2018-02-01 0000926326-18-000003 — 2.02, 9.01
- 2017-12-26 0000926326-17-000041 — 1.01, 2.03, 9.01
- 2017-11-03 0001104659-17-066102 — 1.01, 8.01, 9.01
- 2017-10-26 0000926326-17-000035 — 2.02, 9.01
- 2017-08-03 0000926326-17-000028 — 5.07 — amendment, the index does not say of what
- 2017-07-27 0000926326-17-000026 — 2.02, 9.01
- 2017-07-25 0000926326-17-000023 — 5.02, 9.01
- 2017-05-24 0000926326-17-000019 — 5.07
- 2017-05-04 0001628280-17-004851 — 2.02, 9.01
- 2017-02-15 0000926326-17-000010 — 2.05
- 2017-02-15 0000926326-17-000008 — 2.02, 9.01
- 2017-02-13 0000926326-17-000002 — 5.02
- 2016-12-08 0001104659-16-161330 — 2.01, 2.03, 9.01
- 2016-12-06 0001104659-16-160709 — 7.01
- 2016-11-29 0001104659-16-159456 — 1.01, 7.01, 9.01
- 2016-10-27 0000926326-16-000075 — 2.02, 9.01
- 2016-10-07 0000926326-16-000072 — 5.02, 8.01
- 2016-08-05 0000926326-16-000068 — 8.01
- 2016-07-28 0000926326-16-000066 — 2.02, 9.01
- 2016-06-13 0001104659-16-126854 — 5.02
- 2016-05-25 0000926326-16-000060 — 5.07
- 2016-04-28 0000926326-16-000054 — 2.02, 9.01
- 2016-03-21 0001104659-16-106649 — 8.01, 9.01
- 2016-03-17 0000926326-16-000051 — 7.01, 9.01
- 2016-03-17 0000926326-16-000049 — 9.01 — amendment of 0000926326-16-000051
- 2016-02-10 0001104659-16-095486 — 5.02, 9.01
- 2016-02-04 0000926326-16-000041 — 2.02, 9.01
- 2016-01-06 0001104659-16-088299 — 1.01, 2.01, 2.03, 9.01
- 2015-12-10 0000926326-15-000038 — 8.01, 9.01
- 2015-10-29 0001104659-15-074138 — 1.01, 9.01
- 2015-10-29 0000926326-15-000031 — 2.02, 9.01
- 2015-08-20 0001104659-15-061135 — 5.02, 9.01
- 2015-07-30 0000926326-15-000024 — 2.02, 9.01
- 2015-05-22 0001104659-15-040440 — 5.07
- 2015-05-01 0001104659-15-032846 — 5.02
- 2015-05-01 0001104659-15-032844 — 7.01
- 2015-04-30 0000926326-15-000015 — 9.01
- 2015-04-22 0001104659-15-029356 — 8.01, 9.01
- 2015-03-20 0001104659-15-021435 — 3.01
- 2015-03-18 0001104659-15-020699 — 7.01
- 2015-03-17 0001104659-15-020483 — 8.01, 9.01
- 2015-03-02 0001104659-15-015802 — 1.01, 9.01
- 2015-02-12 0001104659-15-009234 — 5.02, 9.01
- 2015-02-03 0000926326-15-000003 — 9.01
- 2015-01-15 0001104659-15-002635 — 5.02
- 2014-11-07 0001104659-14-078398 — 1.01, 8.01, 9.01
- 2014-10-30 0000926326-14-000037 — 2.02, 9.01
- 2014-08-25 0001104659-14-062772 — 8.01, 9.01
- 2014-07-31 0000926326-14-000032 — 2.02, 9.01
- 2014-05-21 0001104659-14-040744 — 5.07
- 2014-05-01 0000926326-14-000008 — 2.02, 9.01
- 2014-04-08 0001104659-14-026441 — 4.01, 9.01
- 2014-04-02 0001104659-14-025179 — 5.02
- 2014-02-07 0001104659-14-007552 — 5.02, 9.01
- 2014-02-04 0001104659-14-006352 — 2.02, 9.01
- 2013-12-09 0001104659-13-088980 — 1.01, 9.01
- 2013-12-02 0001104659-13-087877 — 5.02
- 2013-10-31 0001104659-13-079660 — 2.02, 9.01
- 2013-09-26 0001104659-13-072435 — 1.01, 2.03, 9.01
- 2013-08-01 0001104659-13-058959 — 2.02, 9.01
- 2013-05-23 0001104659-13-044317 — 5.07
- 2013-05-02 0001104659-13-036605 — 2.02, 9.01
- 2013-03-11 0001104659-13-019143 — 8.01
- 2013-02-07 0001104659-13-008477 — 5.02, 9.01
- 2013-01-31 0001104659-13-006446 — 2.02, 9.01
- 2012-11-02 0001104659-12-073697 — 5.02
- 2012-10-25 0001104659-12-071211 — 2.02, 9.01
- 2012-08-06 0001104659-12-054635 — 8.01
- 2012-08-03 0001104659-12-054214 — 2.01, 9.01 — amendment of 0001104659-12-038888
- 2012-08-01 0001104659-12-053005 — 2.02, 9.01
- 2012-06-12 0001104659-12-042936 — 8.01, 9.01
- 2012-05-23 0001104659-12-039459 — 5.07
- 2012-05-22 0001104659-12-038888 — 2.01, 9.01
- 2012-05-02 0001104659-12-032048 — 2.02, 9.01
- 2012-05-02 0001104659-12-032036 — 1.01, 9.01
- 2012-04-04 0001104659-12-023883 — 5.02, 8.01
- 2012-03-20 0001104659-12-019462 — 1.01, 9.01
- 2012-02-13 0001104659-12-009353 — 5.02, 9.01
- 2012-01-26 0001104659-12-004244 — 2.02, 9.01
- 2011-10-27 0001104659-11-058464 — 2.02, 9.01
- 2011-10-25 0001104659-11-057721 — 1.01
- 2011-07-28 0001104659-11-041505 — 2.02, 9.01
- 2011-05-27 0001104659-11-032006 — 5.07
- 2011-05-02 0001104659-11-024908 — 2.02, 9.01
- 2011-04-15 0001104659-11-020407 — 5.02, 9.01 — amendment of 0001104659-11-005638
- 2011-02-08 0001104659-11-005638 — 5.02, 9.01
- 2011-01-27 0001104659-11-003419 — 2.02, 9.01
- 2010-12-22 0001104659-10-064003 — 5.02, 5.07, 9.01
- 2010-10-27 0001104659-10-054036 — 2.02, 9.01
- 2010-10-05 0001104659-10-051173 — 8.01
- 2010-07-22 0001104659-10-039126 — 2.02, 9.01
- 2010-07-09 0001104659-10-037594 — 2.05
- 2010-05-28 0001104659-10-031607 — 5.07
- 2010-04-26 0001104659-10-021797 — 2.02, 9.01
- 2010-03-17 0001104659-10-014849 — 5.02, 9.01
- 2010-02-08 0001104659-10-005457 — 5.02, 9.01
- 2010-01-28 0001104659-10-003627 — 2.02, 9.01
- 2009-10-22 0001104659-09-059972 — 2.02, 9.01
- 2009-07-23 0001104659-09-044508 — 2.02, 9.01
- 2009-05-20 0001104659-09-033938 — 5.02, 9.01
- 2009-04-30 0001104659-09-027707 — 2.02, 9.01
- 2009-03-10 0001104659-09-016178 — 5.02, 9.01
- 2009-02-09 0001104659-09-007692 — 5.02, 9.01
- 2009-01-29 0001104659-09-005022 — 2.02, 2.05, 9.01
- 2009-01-21 0001104659-09-003180 — 2.02, 8.01, 9.01
- 2009-01-06 0001104659-09-000625 — 5.02
- 2008-10-23 0001104659-08-065475 — 2.02, 9.01
- 2008-07-21 0001104659-08-046690 — 2.02, 9.01
- 2008-05-16 0001104659-08-034035 — 8.01, 9.01
- 2008-04-28 0001104659-08-027379 — 7.01, 9.01
- 2008-04-21 0001104659-08-025616 — 2.02, 9.01
- 2008-03-12 0001104659-08-016939 — 7.01, 9.01
- 2008-02-26 0001104659-08-012840 — 7.01, 9.01
- 2008-02-12 0001104659-08-009382 — 5.02, 9.01
- 2008-01-31 0001104659-08-006199 — 2.02, 9.01
- 2007-12-05 0001104659-07-087191 — 1.01, 9.01
- 2007-10-18 0001104659-07-075654 — 2.02, 9.01
- 2007-07-27 0001104659-07-056886 — 5.03, 9.01
- 2007-07-19 0001104659-07-054924 — 2.02, 9.01
- 2007-05-23 0001104659-07-042287 — 8.01, 9.01
- 2007-05-07 0001104659-07-036172 — 1.01, 5.02, 9.01
- 2007-04-24 0001104659-07-030578 — 2.02, 9.01 — amendment, the index does not say of what
- 2007-04-24 0001104659-07-030547 — 2.02, 9.01
- 2007-04-10 0001104659-07-027465 — 5.02, 9.01
- 2007-03-23 0001104659-07-021969 — 2.02, 4.02, 9.01
- 2007-01-30 0001104659-07-005772 — 2.02, 9.01
- 2007-01-09 0001104659-07-001600 — 5.02, 9.01
- 2006-10-30 0001104659-06-069612 — 1.01
- 2006-10-19 0001104659-06-067549 — 2.02, 9.01
- 2006-07-20 0001104659-06-048020 — 2.02, 4.02, 9.01
- 2006-05-17 0001104659-06-035522 — 1.01, 9.01 — amendment of 0001104659-05-011155
- 2006-05-09 0001104659-06-032706 — 1.01, 9.01
- 2006-04-25 0001104659-06-027438 — 2.02, 9.01
- 2006-04-04 0001104659-06-022204 — 1.01, 9.01
- 2006-03-15 0001104659-06-016861 — 1.01, 9.01
- 2006-01-30 0001104659-06-004749 — 2.02, 9.01
- 2006-01-24 0001104659-06-003504 — 1.01, 5.02, 9.01
- 2005-12-13 0001104659-05-060532 — 1.01, 9.01
- 2005-11-10 0001104659-05-054663 — 2.02, 9.01
- 2005-07-21 0001104659-05-033464 — 2.02, 9.01
- 2005-06-22 0001104659-05-029255 — 1.01
- 2005-05-16 0001104659-05-023473 — 2.02, 9.01 — amendment of 0001104659-05-018173
- 2005-05-16 0001104659-05-023471 — 2.02, 9.01 — amendment of 0001104659-05-017382
- 2005-05-10 0001104659-05-022127 — 1.01
- 2005-04-26 0001104659-05-018173 — 2.02, 9.01
- 2005-04-21 0001104659-05-017382 — 2.02, 9.01
- 2005-04-06 0001104659-05-015401 — 5.02
- 2005-03-15 0001104659-05-011155 — 1.01, 9.01
- 2005-03-08 0001104659-05-009975 — 1.01, 9.01
- 2005-02-03 0001104659-05-003943 — 2.02, 9.01
- 2005-01-13 0001104659-05-001314 — 5.02, 9.01
- 2004-10-21 0001104659-04-031413 — 2.02, 9.01
- 2004-07-22 0001104659-04-020572 — 12, 7
- 2004-04-14 0001104659-04-010039 — 12, 7
- 2004-04-05 0001104659-04-009437 — 12, 7
- 2004-01-26 0001104659-04-001655 — 12, 7
- 2003-10-16 0001104659-03-022990 — 12, 7
- 2003-07-17 0001104659-03-015053 — 9
- 2003-04-18 0001104659-03-006823 — 7, 9
- 2003-02-14 0001104659-03-002607 — 5, 7

## late-filing notifications on or before 2025-08-06

- 2015-03-02 0000926326-15-000006 — NT 10-K, for the period ended 2014-12-31
- 2007-03-16 0001104659-07-020094 — NT 10-K, for the period ended 2006-12-31

## item 2.02 — earnings release, exhibit 99.1

[0000926326-25-000016:8k_2_02:1]
EX-99.1
2
exhibit991q2-25.htm
EX-99.1

[0000926326-25-000016:8k_2_02:2]
Document

[0000926326-25-000016:8k_2_02:3]
Exhibit 99.1

[0000926326-25-000016:8k_2_02:4]
| Contact: |  |  |
| Kathleen Nemeth |  | Omnicell, Inc. |
| Senior Vice President, Investor Relations |  | 4220 North Freeway |
| 650-435-3318 |  | Fort Worth, TX 76137 |
| Kathleen.Nemeth@Omnicell.com |  |  |

[0000926326-25-000016:8k_2_02:5]
Omnicell Announces Second Quarter 2025 Results

[0000926326-25-000016:8k_2_02:6]
Omnicell delivers strong second quarter financial results

[0000926326-25-000016:8k_2_02:7]
Results exceed previously issued second quarter 2025 guidance for revenues, non-GAAP EBITDA and non-GAAP EPS

[0000926326-25-000016:8k_2_02:8]
Raises full year 2025 total revenues, non-GAAP EBITDA and non-GAAP EPS guidance

[0000926326-25-000016:8k_2_02:9]
FORT WORTH, Texas -- July 31, 2025 -- Omnicell, Inc. (NASDAQ:OMCL) (“Omnicell,” “we,” “our,” “us,” “management,” or the “Company”), a leader in transforming the pharmacy and nursing care delivery model, today announced results for its second quarter ended June 30, 2025.

[0000926326-25-000016:8k_2_02:10]
“We are pleased to deliver another quarter of strong financial performance, with total revenues, non-GAAP EPS and non-GAAP EBITDA for second quarter 2025 all exceeding the upper end of our previously provided guidance,” said Randall Lipps, chairman, president, chief executive officer, and founder of Omnicell. “During the quarter, we saw broad demand across our range of solutions, with notable strength coming from our point-of-care connected devices, including our XT Series automated dispensing cabinets and the XTExtend console, a part of our XT Amplify program. In parallel, we continued to work to drive the innovation that our customers have come to expect, most recently with the introduction of our MedTrack RFID Line and MedVision inventory management solution. Our unwavering focus on improving clinical and operational outcomes guides everything we do at Omnicell, and we believe that this continues to resonate with current and prospective customers across the entire continuum of care.”

[0000926326-25-000016:8k_2_02:11]
Financial Results

[0000926326-25-000016:8k_2_02:12]
Total revenues for the second quarter of 2025 were $291 million, up $14 million, or 5%, from the second quarter of 2024. The year-over-year increase in total revenues was driven by strength in our connected devices, technical services, SaaS and Expert Services, and consumables revenues.

[0000926326-25-000016:8k_2_02:13]
Total GAAP net income for the second quarter of 2025 was $6 million, or $0.12 per diluted share. This compares to GAAP net income of $4 million, or $0.08 per diluted share, for the second quarter of 2024.

[0000926326-25-000016:8k_2_02:14]
Total non-GAAP net income for the second quarter of 2025 was $21 million, or $0.45 per diluted share. This compares to non-GAAP net income of $24 million, or $0.51 per diluted share, for the second quarter of 2024.

[0000926326-25-000016:8k_2_02:15]
Total non-GAAP EBITDA for the second quarter of 2025 was $38 million. This compares to non-GAAP EBITDA of $40 million for the second quarter of 2024.

[0000926326-25-000016:8k_2_02:16]
Balance Sheet

[0000926326-25-000016:8k_2_02:17]
As of June 30, 2025, Omnicell’s balance sheet reflected cash and cash equivalents of $399 million, total debt (net of unamortized debt issuance costs) of $342 million, and total assets of $2.1 billion. Cash flows provided by operating activities in the second quarter of 2025 totaled $43 million. This compares to cash flows provided by operating activities totaling $59 million in the second quarter of 2024.

[0000926326-25-000016:8k_2_02:18]
As of June 30, 2025, the Company had $350 million of availability under its revolving credit facility with no outstanding balance.

[0000926326-25-000016:8k_2_02:19]
Corporate Highlights

[0000926326-25-000016:8k_2_02:20]
•In May, we held Omnicell Illuminate 2025, a hybrid in-person and virtual educational and networking event that aims to showcase best practices for technology-driven pharmacy and nursing care, where we announced Omnicell’s latest

[0000926326-25-000016:8k_2_02:21]
outcomes-centric offerings – MedVision and MedTrack/MedTrack - OR. This is our fifth year hosting this important event that is uniquely focused on advancing solutions for pharmacy and nursing care challenges.

[0000926326-25-000016:8k_2_02:22]
•In conjunction with the Illuminate 2025 event, we hosted customers and industry leaders for the grand opening of our new Innovation Lab in Austin, Texas. This dedicated space is intended to allow Omnicell engineers to focus on developing new concepts and allows for quick testing of the feasibility, viability, and potential impact of new solutions that are being designed to solve evolving challenges faced by the healthcare industry.

[0000926326-25-000016:8k_2_02:23]
•We’re pleased to announce that in June 2025, OmniSphere, the Company’s next-generation, cloud native, software workflow engine and data platform, has successfully received HITRUST CSF (Common Security Framework) i1 certification. This certification demonstrates that our cloud platform adheres to the stringent standards and requirements of one of the most trusted security assessment leaders in the healthcare sector and complements our existing HITRUST i1 certification for our suite of medication management solutions.

[0000926326-25-000016:8k_2_02:24]
•In June 2025, we hosted our inaugural IV TRUST Summit (Transforming Robotics for Unifying Safety and Technology), bringing together industry leaders, patient safety advocates, and policy advisors to explore opportunities for improving patient safety through automation. The IV TRUST Summit sought to provide numerous takeaways that are expected to help drive the adoption of IV compounding automation forward.

[0000926326-25-000016:8k_2_02:25]
2025 Guidance

[0000926326-25-000016:8k_2_02:26]
The table below summarizes Omnicell’s third quarter and updated full year 2025 guidance. Given the strength of our first half 2025 performance and visibility into the second half of the year, we are reaffirming our full year 2025 product bookings and Annual Recurring Revenue outlook and modestly increasing our full year 2025 total revenues, non-GAAP EBITDA and non-GAAP EPS guidance.

[0000926326-25-000016:8k_2_02:27]
|  | Q3 2025 |  | 2025 |
| Product Bookings | Not provided |  | $500 million - $550 million |
| Annual Recurring Revenue | Not provided |  | $610 million - $630 million |
| Total Revenues | $290 million - $300 million |  | $1.130 billion - $1.160 billion |
| Product Revenues | $165 million - $170 million |  | $625 million - $640 million |
| Service Revenues | $125 million - $130 million |  | $505 million - $520 million |
| Technical Services Revenues | Not provided |  | $245 million - $250 million |
| SaaS and Expert Service Revenues | Not provided |  | $260 million - $270 million |
| Non-GAAP EBITDA | $28 million - $32 million |  | $130 million - $145 million |
| Non-GAAP Earnings Per Share | $0.30 - $0.37 |  | $1.40 - $1.65 |

[0000926326-25-000016:8k_2_02:28]
The Company does not provide guidance for GAAP net income or GAAP earnings per share, nor a reconciliation of any forward-looking non-GAAP financial measures to the most directly comparable GAAP financial measures on a forward-looking basis, because it is unable to predict certain items contained in the GAAP measures without unreasonable efforts. These forward-looking non-GAAP financial measures do not include certain items, which may be significant, including, but not limited to, unusual gains and losses, costs associated with future restructurings, acquisition-related expenses, and certain tax and litigation outcomes.

[0000926326-25-000016:8k_2_02:29]
Omnicell Conference Call Information

[0000926326-25-000016:8k_2_02:30]
Omnicell will hold a conference call today, Thursday, July 31, 2025, at 8:30 a.m. ET to discuss second quarter 2025 financial results. The conference call can be monitored by dialing (800) 715-9871 in the U.S. or (646) 307-1963 in international locations. The Conference ID is 3131192. A link to the live and archived webcast will also be available on the Investor Relations section of Omnicell’s website at https://ir.omnicell.com/events-and-presentations/.

[0000926326-25-000016:8k_2_02:31]
__________________________________________________

[0000926326-25-000016:8k_2_02:32]
About Omnicell

[0000926326-25-000016:8k_2_02:33]
Since 1992, Omnicell has been committed to transforming pharmacy and nursing care through outcomes-centric solutions designed to deliver clinical and business outcomes across all settings of care. Through a comprehensive portfolio of robotics and smart devices, intelligent software workflows, and data and analytics, all optimized by expert services, Omnicell solutions are helping healthcare facilities worldwide to uncover cost savings, improve labor efficiency, establish new revenue streams, enhance supply chain control, support compliance, and move closer to the industry-defined vision of the Autonomous Pharmacy. To learn more, visit omnicell.com.

[0000926326-25-000016:8k_2_02:34]
From time to time, Omnicell may use the Company’s investor relations website and other online social media channels, including its LinkedIn page www.linkedin.com/company/omnicell, and Facebook page www.facebook.com/omnicellinc, to disclose material non-public information and comply with its disclosure obligations under Regulation Fair Disclosure (“Reg FD”).

[0000926326-25-000016:8k_2_02:35]
OMNICELL and the Omnicell logo are registered trademarks of Omnicell, Inc. or one of its subsidiaries. This press release may also include the trademarks and service marks of other companies. Such trademarks and service marks are the marks of their respective owners.

[0000926326-25-000016:8k_2_02:36]
Forward-Looking Statements

[0000926326-25-000016:8k_2_02:37]
3

[0000926326-25-000016:8k_2_02:38]
Use of Non-GAAP Financial Information

[0000926326-25-000016:8k_2_02:39]
This press release contains financial measures that are not calculated in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”). Management evaluates and makes operating decisions using various performance measures. In addition to Omnicell’s GAAP results, we also consider non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income (loss) from operations, non-GAAP operating margin, non-GAAP net income, non-GAAP net income per diluted share, non-GAAP diluted shares, non-GAAP EBITDA, non-GAAP EBITDA margin, and non-GAAP free cash flow. These non-GAAP results and metrics should not be considered as an alternative to revenues, gross profit, operating expenses, income from operations, net income, net income per diluted share, diluted shares, net cash provided by operating activities, or any other performance measure derived in accordance with GAAP. We present these non-GAAP results and metrics because management considers them to be important supplemental measures of Omnicell’s performance and refers to such measures when analyzing Omnicell’s strategy and operations.

[0000926326-25-000016:8k_2_02:40]
Our non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP operating margin, non-GAAP net income, non-GAAP net income per diluted share, non-GAAP EBITDA, and non-GAAP EBITDA margin are exclusive of certain items to facilitate management’s review of the comparability of Omnicell’s core operating results on a period-to-period basis because such items are not related to Omnicell’s ongoing core operating results as viewed by management. We define our “core operating results” as those revenues recorded in a particular period and the expenses incurred within such period that directly drive operating income in such period. Management uses these non-GAAP financial measures in making operating decisions because, in addition to meaningful supplemental information regarding operating performance, the measures give us a better understanding of how we believe we should invest in research and development, fund infrastructure growth, and evaluate the effectiveness of marketing strategies. In calculating the above non-GAAP results: non-GAAP gross profit and non-GAAP gross margin exclude from their GAAP equivalents items a), b) and e) below; non-GAAP operating expenses excludes from its GAAP equivalents items a), b), c), e), f), g), and h) below; non-GAAP income from operations and non-GAAP operating margin exclude from their GAAP equivalents items a), b), c), e), f), g), and h) below; and non-GAAP net income and non-GAAP net income per diluted share exclude from their GAAP equivalents items a) through h) below. Non-GAAP EBITDA is defined as earnings before interest income and expense, taxes, depreciation, amortization, and share-based compensation, as well as excluding certain other non-GAAP adjustments. Non-GAAP EBITDA and non-GAAP EBITDA margin exclude from their GAAP equivalents items a), c), d), e), f), g), h) below:

[0000926326-25-000016:8k_2_02:41]
a)Share-based compensation expense. We excluded from our non-GAAP results the expense related to equity-based compensation plans as it represents expenses that do not require cash settlement from Omnicell.

[0000926326-25-000016:8k_2_02:42]
b)Amortization of acquired intangible assets. We excluded from our non-GAAP results the intangible assets amortization expense resulting from our past acquisitions. These non-cash charges are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results.

[0000926326-25-000016:8k_2_02:43]
c)Acquisition-related expenses. We excluded from our non-GAAP results the expenses related to recent acquisitions, including amortization of representations and warranties insurance. These expenses are unrelated to our ongoing operations, vary in size and frequency, and are subject to significant fluctuations from period to period due to varying levels of acquisition activity. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of peer companies.

[0000926326-25-000016:8k_2_02:44]
d)Amortization of debt issuance costs. Debt issuance costs represent costs associated with the issuance of revolving credit facilities and convertible senior notes. The costs include underwriting fees, original issue discount, ticking fees, and legal fees. These non-cash expenses are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results.

[0000926326-25-000016:8k_2_02:45]
e)RDS restructuring. We excluded from our non-GAAP results the nonrecurring restructuring charges related to the wind down of the Company’s Medimat Robotic Dispensing System (“RDS”) product line. For the period ended June 30, 2024, those charges consisted primarily of inventory write-down, severance and other related expenses. These expenses are unrelated to our ongoing operations and we believe that excluding these expenses provides more meaningful comparisons

[0000926326-25-000016:8k_2_02:46]
of the financial results to our historical operations and forward-looking guidance, and to the financial results of peer companies.

[0000926326-25-000016:8k_2_02:47]
f)Executives transition costs. We excluded from our non-GAAP results the transition costs associated with the departure of a certain executive officer, primarily consisting of severance expenses. These expenses are unrelated to our ongoing operations and we do not expect them to occur in the ordinary course of business. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of peer companies.

[0000926326-25-000016:8k_2_02:48]
g)Legal and regulatory expenses. We excluded from our non-GAAP results certain non-recurring legal and regulatory expenses, representing settlement amounts, related to certain claims of non-compliance with our government contracts that are outside of the ordinary course of our business. We believe that excluding these amounts provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of peer companies.

[0000926326-25-000016:8k_2_02:49]
h)Management severance costs. We excluded from our non-GAAP results the severance expense of certain senior management associated with the restructuring of our senior leadership team. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of peer companies.

[0000926326-25-000016:8k_2_02:50]
Management adjusts for the above items because management believes that, in general, these items possess one or more of the following characteristics: their magnitude and timing is largely outside of Omnicell’s control; they are unrelated to the ongoing operation of the business in the ordinary course; they are unusual and we do not expect them to occur in the ordinary course of business; or they are non-operational or non-cash expenses involving stock compensation plans or other items.

[0000926326-25-000016:8k_2_02:51]
We believe that the presentation of non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP operating margin, non-GAAP net income, non-GAAP net income per diluted share, non-GAAP EBITDA, and non-GAAP EBITDA margin is warranted for several reasons:

[0000926326-25-000016:8k_2_02:52]
a)Such non-GAAP financial measures provide an additional analytical tool for understanding Omnicell’s financial performance by excluding the impact of items which may obscure trends in the core operating results of the business.

[0000926326-25-000016:8k_2_02:53]
b)Since we have historically reported non-GAAP results to the investment community, we believe the inclusion of non-GAAP numbers provides consistency and enhances investors’ ability to compare our performance across financial reporting periods.

[0000926326-25-000016:8k_2_02:54]
c)These non-GAAP financial measures are employed by management in its own evaluation of performance and are utilized in financial and operational decision-making processes, such as budget planning and forecasting.

[0000926326-25-000016:8k_2_02:55]
d)These non-GAAP financial measures facilitate comparisons to the operating results of other companies in our industry, which also use non-GAAP financial measures to supplement their GAAP results (although these companies may calculate non-GAAP financial measures differently than Omnicell does), thus enhancing the perspective of investors who wish to utilize such comparisons in their analysis of our performance.

[0000926326-25-000016:8k_2_02:56]
Set forth below are additional reasons why share-based compensation expense is excluded from our non-GAAP financial measures:

[0000926326-25-000016:8k_2_02:57]
i)While share-based compensation calculated in accordance with Accounting Standards Codification (“ASC”) 718 constitutes an ongoing and recurring expense of Omnicell, it is not an expense that requires cash settlement by Omnicell. We therefore exclude these charges for purposes of evaluating core operating results. Thus, our non-GAAP measurements are presented exclusive of share-based compensation expense to assist management and investors in evaluating our core operating results.

[0000926326-25-000016:8k_2_02:58]
ii)We present ASC 718 share-based payment compensation expense in our reconciliation of non-GAAP financial measures on a pre-tax basis because the exact tax differences related to the timing and deductibility of share-based compensation under ASC 718 are dependent upon the trading price of Omnicell’s common stock and the timing and exercise by employees of their stock options. As a result of these timing and market uncertainties, the tax effect related to share-based compensation expense would be inconsistent in amount and frequency and is therefore excluded from our non-GAAP results.

[0000926326-25-000016:8k_2_02:59]
Non-GAAP diluted shares is defined as our GAAP diluted shares, excluding the impact of dilutive convertible senior notes for which the Company is economically hedged through its anti-dilutive convertible note hedge transaction. Additionally, in a period of net loss, GAAP diluted shares are further adjusted for certain shares whose effect would be dilutive in a period of net income. We believe non-GAAP diluted shares is a useful non-GAAP metric because it provides insight into the offsetting economic effect of the hedge transaction against potential conversion of the convertible senior notes.

[0000926326-25-000016:8k_2_02:60]
Non-GAAP free cash flow is defined as net cash provided by operating activities less cash used for software development for external use and purchases of property and equipment. We believe free cash flow is important to enable investors to better understand and evaluate our ongoing operating results and allows for greater transparency in the review and understanding of our overall financial, operational, and economic performance, because free cash flow takes into account certain capital expenditures and cash used for software development necessary to operate our business.

[0000926326-25-000016:8k_2_02:61]
As stated above, we present non-GAAP financial measures because we consider them to be important supplemental measures of performance. However, non-GAAP financial measures have limitations as an analytical tool and should not be considered in isolation or as a substitute for Omnicell’s GAAP results. In the future, we expect to incur expenses similar to certain of the non-GAAP adjustments described above and expect to continue reporting non-GAAP financial measures excluding such items. Some of the limitations in relying on non-GAAP financial measures are:

[0000926326-25-000016:8k_2_02:62]
a)Omnicell’s equity incentive plans and stock purchase plans are important components of incentive compensation arrangements and will be reflected as expenses in Omnicell’s GAAP results for the foreseeable future under ASC 718.

[0000926326-25-000016:8k_2_02:63]
b)Other companies, including companies in Omnicell’s industry, may calculate non-GAAP financial measures differently than Omnicell, limiting their usefulness as a comparative measure.

[0000926326-25-000016:8k_2_02:64]
c)A limitation of the utility of free cash flow as a measure of financial performance is that it does not represent the total increase or decrease in Omnicell’s cash balance for the period.

[0000926326-25-000016:8k_2_02:65]
A detailed reconciliation between Omnicell’s non-GAAP and GAAP financial results is set forth in the financial tables at the end of this press release. Investors are advised to carefully review and consider this information strictly as a supplement to the GAAP results that are contained in this press release as well as in Omnicell’s other reports filed with or furnished to the SEC.

[0000926326-25-000016:8k_2_02:66]
6

[0000926326-25-000016:8k_2_02:67]
Omnicell, Inc.

[0000926326-25-000016:8k_2_02:68]
Condensed Consolidated Statements of Operations

[0000926326-25-000016:8k_2_02:69]
(Unaudited, in thousands, except per share data)

[0000926326-25-000016:8k_2_02:70]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Revenues: |  |  |  |  |  |  |  |
| Product revenues | $ | 163,172 |  |  | $ | 156,580 |  |  | $ | 308,340 |  |  | $ | 289,875 |  |
| Service revenues | 127,390 |  |  | 120,208 |  |  | 251,890 |  |  | 233,064 |  |
| Total revenues | 290,562 |  |  | 276,788 |  |  | 560,230 |  |  | 522,939 |  |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | 91,919 |  |  | 99,381 |  |  | 177,504 |  |  | 191,822 |  |
| Cost of service revenues | 70,965 |  |  | 63,056 |  |  | 144,112 |  |  | 124,143 |  |
| Total cost of revenues | 162,884 |  |  | 162,437 |  |  | 321,616 |  |  | 315,965 |  |
| Gross profit | 127,678 |  |  | 114,351 |  |  | 238,614 |  |  | 206,974 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 21,573 |  |  | 21,102 |  |  | 42,099 |  |  | 43,158 |  |
| Selling, general, and administrative | 97,985 |  |  | 90,025 |  |  | 200,014 |  |  | 182,439 |  |
| Total operating expenses | 119,558 |  |  | 111,127 |  |  | 242,113 |  |  | 225,597 |  |
| Income (loss) from operations | 8,120 |  |  | 3,224 |  |  | (3,499) |  |  | (18,623) |  |
| Interest and other income (expense), net | 2,333 |  |  | 4,973 |  |  | 4,422 |  |  | 8,989 |  |
| Income (loss) before income taxes | 10,453 |  |  | 8,197 |  |  | 923 |  |  | (9,634) |  |
| Provision for income taxes | 4,814 |  |  | 4,462 |  |  | 2,307 |  |  | 2,307 |  |
| Net income (loss) | $ | 5,639 |  |  | $ | 3,735 |  |  | $ | (1,384) |  |  | $ | (11,941) |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.12 |  |  | $ | 0.08 |  |  | $ | (0.03) |  |  | $ | (0.26) |  |
| Diluted | $ | 0.12 |  |  | $ | 0.08 |  |  | $ | (0.03) |  |  | $ | (0.26) |  |
| Weighted-average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 46,788 |  |  | 45,953 |  |  | 46,692 |  |  | 45,842 |  |
| Diluted | 46,986 |  |  | 46,036 |  |  | 46,692 |  |  | 45,842 |  |

[0000926326-25-000016:8k_2_02:71]
Omnicell, Inc.

[0000926326-25-000016:8k_2_02:72]
Condensed Consolidated Balance Sheets

[0000926326-25-000016:8k_2_02:73]
(Unaudited, in thousands)

[0000926326-25-000016:8k_2_02:74]
|  | June 30,2025 |  | December 31,2024 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 399,004 |  |  | $ | 369,201 |  |
| Accounts receivable and unbilled receivables, net | 232,682 |  |  | 256,398 |  |
| Inventories | 105,784 |  |  | 88,659 |  |
| Prepaid expenses | 29,023 |  |  | 25,942 |  |
| Other current assets | 78,283 |  |  | 75,293 |  |
| Total current assets | 844,776 |  |  | 815,493 |  |
| Property and equipment, net | 118,954 |  |  | 112,692 |  |
| Long-term investment in sales-type leases, net | 53,957 |  |  | 52,744 |  |
| Operating lease right-of-use assets | 28,255 |  |  | 25,607 |  |
| Goodwill | 738,488 |  |  | 734,727 |  |
| Intangible assets, net | 177,349 |  |  | 188,266 |  |
| Long-term deferred tax assets | 59,805 |  |  | 57,469 |  |
| Prepaid commissions | 51,884 |  |  | 54,656 |  |
| Other long-term assets | 72,028 |  |  | 79,306 |  |
| Total assets | $ | 2,145,496 |  |  | $ | 2,120,960 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 62,414 |  |  | $ | 51,782 |  |
| Accrued compensation | 51,704 |  |  | 60,307 |  |
| Accrued liabilities | 151,876 |  |  | 167,895 |  |
| Deferred revenues | 153,597 |  |  | 141,370 |  |
| Convertible senior notes, net | 174,801 |  |  | 174,324 |  |
| Total current liabilities | 594,392 |  |  | 595,678 |  |
| Long-term deferred revenues | 80,447 |  |  | 76,123 |  |
| Long-term deferred tax liabilities | 1,313 |  |  | 1,108 |  |
| Long-term operating lease liabilities | 30,760 |  |  | 31,123 |  |
| Other long-term liabilities | 7,971 |  |  | 7,218 |  |
| Convertible senior notes, net | 166,994 |  |  | 166,397 |  |
| Total liabilities | 881,877 |  |  | 877,647 |  |
| Total stockholders’ equity | 1,263,619 |  |  | 1,243,313 |  |
| Total liabilities and stockholders’ equity | $ | 2,145,496 |  |  | $ | 2,120,960 |  |

[0000926326-25-000016:8k_2_02:75]
8

[0000926326-25-000016:8k_2_02:76]
Omnicell, Inc.

[0000926326-25-000016:8k_2_02:77]
Condensed Consolidated Statements of Cash Flows

[0000926326-25-000016:8k_2_02:78]
(Unaudited, in thousands)

[0000926326-25-000016:8k_2_02:79]
|  | Six Months Ended June 30, |
|  | 2025 |  | 2024 |
| Operating Activities |  |  |  |
| Net loss | $ | (1,384) |  |  | $ | (11,941) |  |
| Adjustments to reconcile net loss to net cash provided by operating activities: |
| Depreciation and amortization | 39,582 |  |  | 42,090 |  |
| Loss on disposal of assets | 292 |  |  | 221 |  |
| Share-based compensation expense | 21,316 |  |  | 18,672 |  |
| Deferred income taxes | (2,131) |  |  | (7,948) |  |
| Amortization of operating lease right-of-use assets | 3,905 |  |  | 3,900 |  |
| Inventory write-down | — |  |  | 5,393 |  |
| Amortization of debt issuance costs | 1,461 |  |  | 1,943 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable and unbilled receivables | 25,863 |  |  | 10,898 |  |
| Inventories | (15,935) |  |  | 11,160 |  |
| Prepaid expenses | (3,081) |  |  | 3,750 |  |
| Other current assets | (4,526) |  |  | 5,868 |  |
| Investment in sales-type leases | (1,367) |  |  | (8,056) |  |
| Prepaid commissions | 2,772 |  |  | 2,532 |  |
| Other long-term assets | 4,684 |  |  | 1,218 |  |
| Accounts payable | 10,689 |  |  | 4,751 |  |
| Accrued compensation | (8,603) |  |  | (2,814) |  |
| Accrued liabilities | (14,883) |  |  | 9,247 |  |
| Deferred revenues | 15,103 |  |  | 22,085 |  |
| Operating lease liabilities | (5,831) |  |  | (5,512) |  |
| Other long-term liabilities | 753 |  |  | 1,196 |  |
| Net cash provided by operating activities | 68,679 |  |  | 108,653 |  |
| Investing Activities |  |  |  |
| External-use software development costs | (8,709) |  |  | (7,381) |  |
| Purchases of property and equipment | (22,953) |  |  | (18,508) |  |
| Net cash used in investing activities | (31,662) |  |  | (25,889) |  |
| Financing Activities |  |  |  |
| Proceeds from issuances under stock-based compensation plans | 8,266 |  |  | 8,141 |  |
| Employees’ taxes paid related to restricted stock units | (3,352) |  |  | (1,291) |  |
| Common stock repurchases | (15,652) |  |  | — |  |
| Change in customer funds, net | 3,307 |  |  | (11,552) |  |
| Net cash used in financing activities | (7,431) |  |  | (4,702) |  |
| Effect of exchange rate changes on cash and cash equivalents | 3,300 |  |  | (802) |  |
| Net increase in cash, cash equivalents, and restricted cash | 32,886 |  |  | 77,260 |  |
| Cash, cash equivalents, and restricted cash at beginning of period | 398,614 |  |  | 500,979 |  |
| Cash, cash equivalents, and restricted cash at end of period | $ | 431,500 |  |  | $ | 578,239 |  |
| Reconciliation of cash, cash equivalents, and restricted cash to the Condensed Consolidated Balance Sheets: |
| Cash and cash equivalents | $ | 399,004 |  |  | $ | 556,781 |  |
| Restricted cash included in other current assets | 32,496 |  |  | 21,458 |  |
| Cash, cash equivalents, and restricted cash at end of period | $ | 431,500 |  |  | $ | 578,239 |  |

[0000926326-25-000016:8k_2_02:80]
Omnicell, Inc.

[0000926326-25-000016:8k_2_02:81]
Reconciliation of GAAP to Non-GAAP

[0000926326-25-000016:8k_2_02:82]
(Unaudited, in thousands, except per share data and percentage)

[0000926326-25-000016:8k_2_02:83]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Reconciliation of GAAP gross profit to non-GAAP gross profit: |  |  |  |  |  |
| GAAP gross profit | $ | 127,678 |  |  | $ | 114,351 |  |  | $ | 238,614 |  |  | $ | 206,974 |  |
| GAAP gross margin | 43.9% |  | 41.3% |  | 42.6% |  | 39.6% |
| Share-based compensation expense | 1,207 |  |  | 1,620 |  |  | 2,925 |  |  | 3,175 |  |
| Amortization of acquired intangibles | 987 |  |  | 970 |  |  | 1,994 |  |  | 2,090 |  |
| RDS restructuring | — |  |  | 5,348 |  |  | — |  |  | 8,044 |  |
| Non-GAAP gross profit | $ | 129,872 |  |  | $ | 122,289 |  |  | $ | 243,533 |  |  | $ | 220,283 |  |
| Non-GAAP gross margin | 44.7% |  | 44.2% |  | 43.5% |  | 42.1% |
| Reconciliation of GAAP operating expenses to non-GAAP operating expenses: |  |  |  |  |
| GAAP operating expenses | $ | 119,558 |  |  | $ | 111,127 |  |  | $ | 242,113 |  |  | $ | 225,597 |  |
| GAAP operating expenses % to total revenues | 41.1% |  | 40.1% |  | 43.2% |  | 43.1% |
| Share-based compensation expense | (9,323) |  |  | (8,411) |  |  | (18,391) |  |  | (15,497) |  |
| Amortization of acquired intangibles | (4,314) |  |  | (4,702) |  |  | (9,035) |  |  | (9,542) |  |
| Acquisition-related expenses | (182) |  |  | (246) |  |  | (364) |  |  | (492) |  |
| RDS restructuring | — |  |  | (291) |  |  | — |  |  | (867) |  |
| Legal and regulatory expenses | — |  |  | — |  |  | (2,700) |  |  | — |  |
| Management severance costs | — |  |  | — |  |  | (562) |  |  | — |  |
| Executives transition costs | — |  |  | — |  |  | (968) |  |  | — |  |
| Non-GAAP operating expenses | $ | 105,739 |  |  | $ | 97,477 |  |  | $ | 210,093 |  |  | $ | 199,199 |  |
| Non-GAAP operating expenses as a % of total revenues | 36.4% |  | 35.2% |  | 37.5% |  | 38.1% |
| Reconciliation of GAAP income (loss) from operations to non-GAAP income from operations: |
| GAAP income (loss) from operations | $ | 8,120 |  |  | $ | 3,224 |  |  | $ | (3,499) |  |  | $ | (18,623) |  |
| GAAP operating income (loss) % to total revenues | 2.8% |  | 1.2% |  | (0.6)% |  | (3.6)% |
| Share-based compensation expense | 10,530 |  |  | 10,031 |  |  | 21,316 |  |  | 18,672 |  |
| Amortization of acquired intangibles | 5,301 |  |  | 5,672 |  |  | 11,029 |  |  | 11,632 |  |
| Acquisition-related expenses | 182 |  |  | 246 |  |  | 364 |  |  | 492 |  |
| RDS restructuring | — |  |  | 5,639 |  |  | — |  |  | 8,911 |  |
| Legal and regulatory expenses | — |  |  | — |  |  | 2,700 |  |  | — |  |
| Management severance costs | — |  |  | — |  |  | 562 |  |  | — |  |
| Executives transition costs | — |  |  | — |  |  | 968 |  |  | — |  |
| Non-GAAP income from operations | $ | 24,133 |  |  | $ | 24,812 |  |  | $ | 33,440 |  |  | $ | 21,084 |  |
| Non-GAAP operating margin (non-GAAP operating income as a % of total revenues) | 8.3% |  | 9.0% |  | 6.0% |  | 4.0% |

[0000926326-25-000016:8k_2_02:84]
10

[0000926326-25-000016:8k_2_02:85]
Omnicell, Inc.

[0000926326-25-000016:8k_2_02:86]
Reconciliation of GAAP to Non-GAAP

[0000926326-25-000016:8k_2_02:87]
(Unaudited, in thousands, except per share data and percentage)

[0000926326-25-000016:8k_2_02:88]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Reconciliation of GAAP net income (loss) to non-GAAP net income: |
| GAAP net income (loss) | $ | 5,639 |  |  | $ | 3,735 |  |  | $ | (1,384) |  |  | $ | (11,941) |  |
| Share-based compensation expense | 10,530 |  |  | 10,031 |  |  | 21,316 |  |  | 18,672 |  |
| Amortization of acquired intangibles | 5,301 |  |  | 5,672 |  |  | 11,029 |  |  | 11,632 |  |
| Acquisition-related expenses | 182 |  |  | 246 |  |  | 364 |  |  | 492 |  |
| RDS restructuring | — |  |  | 5,639 |  |  | — |  |  | 8,911 |  |
| Legal and regulatory expenses | — |  |  | — |  |  | 2,700 |  |  | — |  |
| Management severance costs | — |  |  | — |  |  | 562 |  |  | — |  |
| Executives transition costs | — |  |  | — |  |  | 968 |  |  | — |  |
| Amortization of debt issuance costs | 726 |  |  | 972 |  |  | 1,461 |  |  | 1,943 |  |
| Tax effect of the adjustments above (a) | (1,304) |  |  | (2,631) |  |  | (3,588) |  |  | (4,825) |  |
| Non-GAAP net income | $ | 21,074 |  |  | $ | 23,664 |  |  | $ | 33,428 |  |  | $ | 24,884 |  |
| Reconciliation of GAAP net income (loss) per share - diluted to non-GAAP net income per share - diluted: |
| Shares - diluted GAAP | 46,986 |  |  | 46,036 |  |  | 46,692 |  |  | 45,842 |  |
| Shares - diluted non-GAAP | 46,986 |  |  | 46,036 |  |  | 47,008 |  |  | 45,905 |  |
| GAAP net income (loss) per share - diluted | $ | 0.12 |  |  | $ | 0.08 |  |  | $ | (0.03) |  |  | $ | (0.26) |  |
| Share-based compensation expense | 0.23 |  |  | 0.22 |  |  | 0.46 |  |  | 0.42 |  |
| Amortization of acquired intangibles | 0.11 |  |  | 0.12 |  |  | 0.23 |  |  | 0.25 |  |
| Acquisition-related expenses | 0.00 |  |  | 0.01 |  |  | 0.01 |  |  | 0.01 |  |
| RDS restructuring | — |  |  | 0.12 |  |  | — |  |  | 0.19 |  |
| Legal and regulatory expenses | — |  |  | — |  |  | 0.06 |  |  | — |  |
| Management severance costs | — |  |  | — |  |  | 0.01 |  |  | — |  |
| Executives transition costs | — |  |  | — |  |  | 0.02 |  |  | — |  |
| Amortization of debt issuance costs | 0.02 |  |  | 0.02 |  |  | 0.03 |  |  | 0.04 |  |
| Tax effect of the adjustments above (a) | (0.03) |  |  | (0.06) |  |  | (0.08) |  |  | (0.11) |  |
| Non-GAAP net income per share - diluted | $ | 0.45 |  |  | $ | 0.51 |  |  | $ | 0.71 |  |  | $ | 0.54 |  |
| Reconciliation of GAAP net income (loss) to non-GAAP EBITDA (b): |
| GAAP net income (loss) | $ | 5,639 |  |  | $ | 3,735 |  |  | $ | (1,384) |  |  | $ | (11,941) |  |
| Share-based compensation expense | 10,530 |  |  | 10,031 |  |  | 21,316 |  |  | 18,672 |  |
| Interest (income) and expense, net | (3,103) |  |  | (6,073) |  |  | (5,908) |  |  | (11,788) |  |
| Depreciation and amortization expense | 19,587 |  |  | 20,837 |  |  | 39,582 |  |  | 42,090 |  |
| Acquisition-related expenses | 182 |  |  | 246 |  |  | 364 |  |  | 492 |  |
| RDS restructuring | — |  |  | 5,639 |  |  | — |  |  | 8,911 |  |
| Legal and regulatory expenses | — |  |  | — |  |  | 2,700 |  |  | — |  |
| Management severance costs | — |  |  | — |  |  | 562 |  |  | — |  |
| Executives transition costs | — |  |  | — |  |  | 968 |  |  | — |  |
| Amortization of debt issuance costs | 726 |  |  | 972 |  |  | 1,461 |  |  | 1,943 |  |
| Provision for income taxes | 4,814 |  |  | 4,462 |  |  | 2,307 |  |  | 2,307 |  |
| Non-GAAP EBITDA | $ | 38,375 |  |  | $ | 39,849 |  |  | $ | 61,968 |  |  | $ | 50,686 |  |
| Non-GAAP EBITDA margin (non-GAAP EBITDA as a % of total revenues) | 13.2% |  | 14.4% |  | 11.1% |  | 9.7% |

[0000926326-25-000016:8k_2_02:89]
______________________________________________

[0000926326-25-000016:8k_2_02:90]
(a)Tax effects calculated for all adjustments except share-based compensation expense, using an estimated annual effective tax rate of 21% for both fiscal years 2025 and 2024.

[0000926326-25-000016:8k_2_02:91]
(b)Defined as earnings before interest income and expense, taxes, depreciation, amortization, and share-based compensation, as well as excluding certain other non-GAAP adjustments.

[0000926326-25-000016:8k_2_02:92]
Omnicell, Inc.

[0000926326-25-000016:8k_2_02:93]
Reconciliation of GAAP to Non-GAAP

[0000926326-25-000016:8k_2_02:94]
(Unaudited, in thousands)

[0000926326-25-000016:8k_2_02:95]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Reconciliation of GAAP net cash provided by operating activities to non-GAAP free cash flow: |
| GAAP net cash provided by operating activities | $ | 42,755 |  |  | $ | 58,700 |  |  | $ | 68,679 |  |  | $ | 108,653 |  |
| External-use software development costs | (4,142) |  |  | (3,998) |  |  | (8,709) |  |  | (7,381) |  |
| Purchases of property and equipment | (11,781) |  |  | (9,551) |  |  | (22,953) |  |  | (18,508) |  |
| Non-GAAP free cash flow | $ | 26,832 |  |  | $ | 45,151 |  |  | $ | 37,017 |  |  | $ | 82,764 |  |

[0000926326-25-000016:8k_2_02:96]
12
