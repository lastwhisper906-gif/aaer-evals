# OMCL 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: 2 candidate headings, none whose body matches 'critical audit matter'.


## item_9a

[0000926326-19-000007:item_9a:1]
| ITEM 9A. | CONTROLS AND PROCEDURES |

[0000926326-19-000007:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0000926326-19-000007:item_9a:3]
Our management, with the participation of our chief executive officer and chief financial officer, evaluated the effectiveness of our disclosure controls and procedures (as defined in Rule 13a-15(e) or 15d-15(e) under the Exchange Act) as of the end of the period covered by this Annual Report on Form 10-K. In designing and evaluating the disclosure controls and procedures, management recognized that any controls and procedures, no matter how well designed and operated, can provide only reasonable assurance of achieving the desired control objectives. In addition, the design of disclosure controls and procedures must reflect the fact that there are resource constraints and that management is required to apply its judgment in evaluating the benefits of possible controls and procedures relative to their costs.

[0000926326-19-000007:item_9a:4]
Based on that evaluation, our chief executive officer and chief financial officer concluded that our disclosure controls and procedures were effective as of December 31, 2018 to provide reasonable assurance that information we are required to disclose in reports that we file or submit under the Exchange Act is recorded, processed, summarized and reported within the time periods specified in SEC rules and forms, and that such information is accumulated and communicated to our management, including our chief executive officer and chief financial officer, as appropriate, to allow timely decisions regarding required disclosure.

[0000926326-19-000007:item_9a:5]
Management’s Report on Internal Control over Financial Reporting

[0000926326-19-000007:item_9a:6]
Our management is responsible for establishing and maintaining adequate internal control over financial reporting (as such term is defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act). Our internal control system is designed to provide reasonable assurance regarding the preparation and fair presentation of financial statements for external purposes in accordance with U.S. generally accepted accounting principles. All internal control systems, no matter how well designed, have inherent limitations and can provide only reasonable assurance that the objectives of the internal control system are met.

[0000926326-19-000007:item_9a:7]
Under the supervision and with the participation of our management, including our principal executive officer and principal financial officer, we conducted an evaluation of the effectiveness of our internal control over financial reporting as of December 31, 2018 using the criteria for effective internal control over financial reporting as described in “Internal Control—Integrated Framework,” issued by the Committee of Sponsoring Organization of the Treadway Commission (2013 framework) (the COSO Criteria). Based on this assessment, management concluded that our internal control over financial reporting was effective as of December 31, 2018.

[0000926326-19-000007:item_9a:8]
Deloitte & Touche LLP, an independent registered public accounting firm, has issued its attestation report on our internal control over financial reporting as of December 31, 2018, which is included in Part IV, Item 15 of this annual report.

[0000926326-19-000007:item_9a:9]
Changes in Internal Control over Financial Reporting

[0000926326-19-000007:item_9a:10]
There have been no changes in our internal control over financial reporting (as such term is defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act) that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting during the year ended December 31, 2018.
