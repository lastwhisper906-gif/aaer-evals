# OMCL 8-K — 0000926326-19-000003 filed 2019-02-07

## item codes, every 8-K on or before 2019-02-27

- 2019-02-19 0000926326-19-000005 — 5.02, 9.01
- 2019-02-07 0000926326-19-000003 — 2.02, 9.01
- 2018-10-25 0000926326-18-000028 — 2.02, 9.01
- 2018-09-14 0001104659-18-056929 — 5.02, 9.01
- 2018-07-26 0000926326-18-000022 — 2.02, 9.01
- 2018-06-06 0000926326-18-000019 — 5.02, 9.01
- 2018-05-16 0001104659-18-033801 — 5.07
- 2018-04-26 0000926326-18-000013 — 2.02, 9.01
- 2018-03-02 0001104659-18-014497 — 5.02
- 2018-02-08 0000926326-18-000007 — 5.02
- 2018-02-02 0000926326-18-000005 — 5.02
- 2018-02-01 0000926326-18-000003 — 2.02, 9.01
- 2017-12-26 0000926326-17-000041 — 1.01, 2.03, 9.01
- 2017-11-03 0001104659-17-066102 — 1.01, 8.01, 9.01
- 2017-10-26 0000926326-17-000035 — 2.02, 9.01
- 2017-08-03 0000926326-17-000028 — 5.07 — amendment, the index does not say of what
- 2017-07-27 0000926326-17-000026 — 2.02, 9.01
- 2017-07-25 0000926326-17-000023 — 5.02, 9.01
- 2017-05-24 0000926326-17-000019 — 5.07
- 2017-05-04 0001628280-17-004851 — 2.02, 9.01
- 2017-02-15 0000926326-17-000010 — 2.05
- 2017-02-15 0000926326-17-000008 — 2.02, 9.01
- 2017-02-13 0000926326-17-000002 — 5.02
- 2016-12-08 0001104659-16-161330 — 2.01, 2.03, 9.01
- 2016-12-06 0001104659-16-160709 — 7.01
- 2016-11-29 0001104659-16-159456 — 1.01, 7.01, 9.01
- 2016-10-27 0000926326-16-000075 — 2.02, 9.01
- 2016-10-07 0000926326-16-000072 — 5.02, 8.01
- 2016-08-05 0000926326-16-000068 — 8.01
- 2016-07-28 0000926326-16-000066 — 2.02, 9.01
- 2016-06-13 0001104659-16-126854 — 5.02
- 2016-05-25 0000926326-16-000060 — 5.07
- 2016-04-28 0000926326-16-000054 — 2.02, 9.01
- 2016-03-21 0001104659-16-106649 — 8.01, 9.01
- 2016-03-17 0000926326-16-000051 — 7.01, 9.01
- 2016-03-17 0000926326-16-000049 — 9.01 — amendment of 0000926326-16-000051
- 2016-02-10 0001104659-16-095486 — 5.02, 9.01
- 2016-02-04 0000926326-16-000041 — 2.02, 9.01
- 2016-01-06 0001104659-16-088299 — 1.01, 2.01, 2.03, 9.01
- 2015-12-10 0000926326-15-000038 — 8.01, 9.01
- 2015-10-29 0001104659-15-074138 — 1.01, 9.01
- 2015-10-29 0000926326-15-000031 — 2.02, 9.01
- 2015-08-20 0001104659-15-061135 — 5.02, 9.01
- 2015-07-30 0000926326-15-000024 — 2.02, 9.01
- 2015-05-22 0001104659-15-040440 — 5.07
- 2015-05-01 0001104659-15-032846 — 5.02
- 2015-05-01 0001104659-15-032844 — 7.01
- 2015-04-30 0000926326-15-000015 — 9.01
- 2015-04-22 0001104659-15-029356 — 8.01, 9.01
- 2015-03-20 0001104659-15-021435 — 3.01
- 2015-03-18 0001104659-15-020699 — 7.01
- 2015-03-17 0001104659-15-020483 — 8.01, 9.01
- 2015-03-02 0001104659-15-015802 — 1.01, 9.01
- 2015-02-12 0001104659-15-009234 — 5.02, 9.01
- 2015-02-03 0000926326-15-000003 — 9.01
- 2015-01-15 0001104659-15-002635 — 5.02
- 2014-11-07 0001104659-14-078398 — 1.01, 8.01, 9.01
- 2014-10-30 0000926326-14-000037 — 2.02, 9.01
- 2014-08-25 0001104659-14-062772 — 8.01, 9.01
- 2014-07-31 0000926326-14-000032 — 2.02, 9.01
- 2014-05-21 0001104659-14-040744 — 5.07
- 2014-05-01 0000926326-14-000008 — 2.02, 9.01
- 2014-04-08 0001104659-14-026441 — 4.01, 9.01
- 2014-04-02 0001104659-14-025179 — 5.02
- 2014-02-07 0001104659-14-007552 — 5.02, 9.01
- 2014-02-04 0001104659-14-006352 — 2.02, 9.01
- 2013-12-09 0001104659-13-088980 — 1.01, 9.01
- 2013-12-02 0001104659-13-087877 — 5.02
- 2013-10-31 0001104659-13-079660 — 2.02, 9.01
- 2013-09-26 0001104659-13-072435 — 1.01, 2.03, 9.01
- 2013-08-01 0001104659-13-058959 — 2.02, 9.01
- 2013-05-23 0001104659-13-044317 — 5.07
- 2013-05-02 0001104659-13-036605 — 2.02, 9.01
- 2013-03-11 0001104659-13-019143 — 8.01
- 2013-02-07 0001104659-13-008477 — 5.02, 9.01
- 2013-01-31 0001104659-13-006446 — 2.02, 9.01
- 2012-11-02 0001104659-12-073697 — 5.02
- 2012-10-25 0001104659-12-071211 — 2.02, 9.01
- 2012-08-06 0001104659-12-054635 — 8.01
- 2012-08-03 0001104659-12-054214 — 2.01, 9.01 — amendment of 0001104659-12-038888
- 2012-08-01 0001104659-12-053005 — 2.02, 9.01
- 2012-06-12 0001104659-12-042936 — 8.01, 9.01
- 2012-05-23 0001104659-12-039459 — 5.07
- 2012-05-22 0001104659-12-038888 — 2.01, 9.01
- 2012-05-02 0001104659-12-032048 — 2.02, 9.01
- 2012-05-02 0001104659-12-032036 — 1.01, 9.01
- 2012-04-04 0001104659-12-023883 — 5.02, 8.01
- 2012-03-20 0001104659-12-019462 — 1.01, 9.01
- 2012-02-13 0001104659-12-009353 — 5.02, 9.01
- 2012-01-26 0001104659-12-004244 — 2.02, 9.01
- 2011-10-27 0001104659-11-058464 — 2.02, 9.01
- 2011-10-25 0001104659-11-057721 — 1.01
- 2011-07-28 0001104659-11-041505 — 2.02, 9.01
- 2011-05-27 0001104659-11-032006 — 5.07
- 2011-05-02 0001104659-11-024908 — 2.02, 9.01
- 2011-04-15 0001104659-11-020407 — 5.02, 9.01 — amendment of 0001104659-11-005638
- 2011-02-08 0001104659-11-005638 — 5.02, 9.01
- 2011-01-27 0001104659-11-003419 — 2.02, 9.01
- 2010-12-22 0001104659-10-064003 — 5.02, 5.07, 9.01
- 2010-10-27 0001104659-10-054036 — 2.02, 9.01
- 2010-10-05 0001104659-10-051173 — 8.01
- 2010-07-22 0001104659-10-039126 — 2.02, 9.01
- 2010-07-09 0001104659-10-037594 — 2.05
- 2010-05-28 0001104659-10-031607 — 5.07
- 2010-04-26 0001104659-10-021797 — 2.02, 9.01
- 2010-03-17 0001104659-10-014849 — 5.02, 9.01
- 2010-02-08 0001104659-10-005457 — 5.02, 9.01
- 2010-01-28 0001104659-10-003627 — 2.02, 9.01
- 2009-10-22 0001104659-09-059972 — 2.02, 9.01
- 2009-07-23 0001104659-09-044508 — 2.02, 9.01
- 2009-05-20 0001104659-09-033938 — 5.02, 9.01
- 2009-04-30 0001104659-09-027707 — 2.02, 9.01
- 2009-03-10 0001104659-09-016178 — 5.02, 9.01
- 2009-02-09 0001104659-09-007692 — 5.02, 9.01
- 2009-01-29 0001104659-09-005022 — 2.02, 2.05, 9.01
- 2009-01-21 0001104659-09-003180 — 2.02, 8.01, 9.01
- 2009-01-06 0001104659-09-000625 — 5.02
- 2008-10-23 0001104659-08-065475 — 2.02, 9.01
- 2008-07-21 0001104659-08-046690 — 2.02, 9.01
- 2008-05-16 0001104659-08-034035 — 8.01, 9.01
- 2008-04-28 0001104659-08-027379 — 7.01, 9.01
- 2008-04-21 0001104659-08-025616 — 2.02, 9.01
- 2008-03-12 0001104659-08-016939 — 7.01, 9.01
- 2008-02-26 0001104659-08-012840 — 7.01, 9.01
- 2008-02-12 0001104659-08-009382 — 5.02, 9.01
- 2008-01-31 0001104659-08-006199 — 2.02, 9.01
- 2007-12-05 0001104659-07-087191 — 1.01, 9.01
- 2007-10-18 0001104659-07-075654 — 2.02, 9.01
- 2007-07-27 0001104659-07-056886 — 5.03, 9.01
- 2007-07-19 0001104659-07-054924 — 2.02, 9.01
- 2007-05-23 0001104659-07-042287 — 8.01, 9.01
- 2007-05-07 0001104659-07-036172 — 1.01, 5.02, 9.01
- 2007-04-24 0001104659-07-030578 — 2.02, 9.01 — amendment, the index does not say of what
- 2007-04-24 0001104659-07-030547 — 2.02, 9.01
- 2007-04-10 0001104659-07-027465 — 5.02, 9.01
- 2007-03-23 0001104659-07-021969 — 2.02, 4.02, 9.01
- 2007-01-30 0001104659-07-005772 — 2.02, 9.01
- 2007-01-09 0001104659-07-001600 — 5.02, 9.01
- 2006-10-30 0001104659-06-069612 — 1.01
- 2006-10-19 0001104659-06-067549 — 2.02, 9.01
- 2006-07-20 0001104659-06-048020 — 2.02, 4.02, 9.01
- 2006-05-17 0001104659-06-035522 — 1.01, 9.01 — amendment of 0001104659-05-011155
- 2006-05-09 0001104659-06-032706 — 1.01, 9.01
- 2006-04-25 0001104659-06-027438 — 2.02, 9.01
- 2006-04-04 0001104659-06-022204 — 1.01, 9.01
- 2006-03-15 0001104659-06-016861 — 1.01, 9.01
- 2006-01-30 0001104659-06-004749 — 2.02, 9.01
- 2006-01-24 0001104659-06-003504 — 1.01, 5.02, 9.01
- 2005-12-13 0001104659-05-060532 — 1.01, 9.01
- 2005-11-10 0001104659-05-054663 — 2.02, 9.01
- 2005-07-21 0001104659-05-033464 — 2.02, 9.01
- 2005-06-22 0001104659-05-029255 — 1.01
- 2005-05-16 0001104659-05-023473 — 2.02, 9.01 — amendment of 0001104659-05-018173
- 2005-05-16 0001104659-05-023471 — 2.02, 9.01 — amendment of 0001104659-05-017382
- 2005-05-10 0001104659-05-022127 — 1.01
- 2005-04-26 0001104659-05-018173 — 2.02, 9.01
- 2005-04-21 0001104659-05-017382 — 2.02, 9.01
- 2005-04-06 0001104659-05-015401 — 5.02
- 2005-03-15 0001104659-05-011155 — 1.01, 9.01
- 2005-03-08 0001104659-05-009975 — 1.01, 9.01
- 2005-02-03 0001104659-05-003943 — 2.02, 9.01
- 2005-01-13 0001104659-05-001314 — 5.02, 9.01
- 2004-10-21 0001104659-04-031413 — 2.02, 9.01
- 2004-07-22 0001104659-04-020572 — 12, 7
- 2004-04-14 0001104659-04-010039 — 12, 7
- 2004-04-05 0001104659-04-009437 — 12, 7
- 2004-01-26 0001104659-04-001655 — 12, 7
- 2003-10-16 0001104659-03-022990 — 12, 7
- 2003-07-17 0001104659-03-015053 — 9
- 2003-04-18 0001104659-03-006823 — 7, 9
- 2003-02-14 0001104659-03-002607 — 5, 7

## late-filing notifications on or before 2019-02-27

- 2015-03-02 0000926326-15-000006 — NT 10-K, for the period ended 2014-12-31
- 2007-03-16 0001104659-07-020094 — NT 10-K, for the period ended 2006-12-31

## item 2.02 — earnings release, exhibit 99.1

[0000926326-19-000003:8k_2_02:1]
EX-99.1
2
exhibit991q4-18.htm
EXHIBIT 99.1

[0000926326-19-000003:8k_2_02:2]
Exhibit

[0000926326-19-000003:8k_2_02:3]
Exhibit 99.1

[0000926326-19-000003:8k_2_02:4]
| Contact: |  |  |
| Peter Kuipers |  | Omnicell, Inc. |
| Chief Financial Officer |  | 590 East Middlefield Road |
| 800-850-6664 |  | Mountain View, CA 94043 |
| Peter.Kuipers@Omnicell.com |  |  |

[0000926326-19-000003:8k_2_02:5]
Omnicell Reports Results for Fiscal Year and Fourth Quarter 2018

[0000926326-19-000003:8k_2_02:6]
Record yearly GAAP revenues of $787.3 million

[0000926326-19-000003:8k_2_02:7]
Record yearly Non-GAAP revenues of $787.3 million

[0000926326-19-000003:8k_2_02:8]
2018 GAAP net income per diluted share of $0.93

[0000926326-19-000003:8k_2_02:9]
Record 2018 Non-GAAP net income per diluted share of $2.09

[0000926326-19-000003:8k_2_02:10]
Record ending product backlog of $478 million

[0000926326-19-000003:8k_2_02:11]
MOUNTAIN VIEW, Calif. -- February 7, 2019 -- Omnicell, Inc. (NASDAQ: OMCL), a leading provider of medication and supply management solutions to healthcare systems, today announced results for its fiscal year and fourth quarter ended December 31, 2018.

[0000926326-19-000003:8k_2_02:12]
GAAP Results

[0000926326-19-000003:8k_2_02:13]
GAAP revenues for the fourth quarter of 2018 were $211.8 million, up $15.4 million, or 7.8% from the fourth quarter of 2017. GAAP revenues for the year ended December 31, 2018 were $787.3 million, up $74.6 million, or 10.5% from the year ended December 31, 2017.

[0000926326-19-000003:8k_2_02:14]
Fourth quarter 2018 GAAP net income as reported was $14.8 million, or $0.36 per diluted share. This compares to GAAP net income of $31.2 million, or $0.79 per diluted share, for the fourth quarter of 2017.

[0000926326-19-000003:8k_2_02:15]
GAAP net income for the year ended December 31, 2018 was $37.7 million, or $0.93 per diluted share. GAAP net income was $30.5 million, or $0.79 per diluted share, for the year ended December 31, 2017.

[0000926326-19-000003:8k_2_02:16]
Non-GAAP Results

[0000926326-19-000003:8k_2_02:17]
Non-GAAP revenues for the fourth quarter of 2018 were $211.8 million, up $15.1 million, or 7.7% from the fourth quarter of 2017.  Non-GAAP revenues for the year ended December 31, 2018 were $787.3 million, up $73.3 million, or 10.3% from the year ended December 31, 2017.

[0000926326-19-000003:8k_2_02:18]
Non-GAAP net income for the fourth quarter of 2018 was $29.1 million, or $0.70 per diluted share. This compares to non-GAAP net income of $21.5 million, or $0.55 per diluted share, for the fourth quarter of 2017.

[0000926326-19-000003:8k_2_02:19]
Non-GAAP net income for the year ended December 31, 2018 was $84.6 million, or $2.09 per diluted share.  This compares to non-GAAP net income of $54.6 million, or $1.41 per diluted share for the year ended December 31, 2017.

[0000926326-19-000003:8k_2_02:20]
Non-GAAP net income for each period excludes, when applicable, the effect of share-based compensation expense, amortization expense of acquired intangible assets, acquisition-related expenses, fair value adjustments related to business acquisitions,

[0000926326-19-000003:8k_2_02:21]
restructuring and severance-related expenses, tax reform and restructuring income tax benefits, contingent gains, and amortization of debt issuance cost.

[0000926326-19-000003:8k_2_02:22]
Total product bookings for the year ended December 31, 2018 were $716 million compared to total bookings of $568 million for the year ended December 31, 2017. Total product backlog for the year ended December 31, 2018 was $478 million compared to $345 million for the year ended December 31, 2017, or an increase of 39% year over year.

[0000926326-19-000003:8k_2_02:23]
“With the launch of our Autonomous Pharmacy vision at ASHP Midyear, health system pharmacists are understanding and embracing the need for radical change in medication management,” said Randall A. Lipps, chairman, president, chief executive officer, and founder of Omnicell. “We continue to partner with our customers to drive this revolutionary, digital approach, which will help allow nurses and pharmacists to move away from manual workflows and operate at the top of their license.”

[0000926326-19-000003:8k_2_02:24]
2018 Business Highlights:

[0000926326-19-000003:8k_2_02:25]
| • | During 2018, the Company continued its cadence of innovation and introduced new products and solutions to the market including: |

[0000926326-19-000003:8k_2_02:26]
| ◦ | the XR2 Automated Central Pharmacy System, a robotic solution that is a significant step towards fully automating central pharmacy operations in a variety of settings; |

[0000926326-19-000003:8k_2_02:27]
| ◦ | IVX Workflow, which operates on IVX Cloud, creating a significant technological advancement for sterile compounding workflow processes and enabling pharmacies to safely and efficiently compound and prepare IV doses; and |

[0000926326-19-000003:8k_2_02:28]
| ◦ | the Patient Engagement Platform, which introduces new medication adherence capabilities and expands the reach of these solutions to Payer networks; |

[0000926326-19-000003:8k_2_02:29]
| • | During the year, the Company has experienced good momentum on new products and has received numerous contractual purchase commitments for multiple products in the Omnicell Platform; |

[0000926326-19-000003:8k_2_02:30]
| • | For the year ended December 31, 2018, the Company’s product backlog was $478 million, an increase of 39% from one year ago; |

[0000926326-19-000003:8k_2_02:31]
| • | For the year ended December 31, 2018, the Company reported record product bookings of $716 million, an increase of 26% from one year ago; and |

[0000926326-19-000003:8k_2_02:32]
| • | In December 2018, the Company announced its vision for the Autonomous Pharmacy. Omnicell’s vision for the Autonomous Pharmacy integrates a comprehensive set of solutions across three key areas: Automation solutions designed to digitize and streamline workflows; Intelligence that provides actionable insights to better understand medication usage and improve pharmacy supply chain management; and Work - expert services that serve as an extension of pharmacy operations to support improved efficiency, regulatory compliance, and patient outcomes. |

[0000926326-19-000003:8k_2_02:33]
2019 Guidance:

[0000926326-19-000003:8k_2_02:34]
For the first quarter of 2019, the Company expects non-GAAP total revenues to be between $196 million and $202 million. The Company expects non-GAAP product revenues to be between $140 million and $145 million, and non-GAAP service revenues to be between $56 million and $57 million. The Company expects first quarter 2019 non-GAAP earnings to be between $0.38 and $0.43 per share.

[0000926326-19-000003:8k_2_02:35]
For the year 2019, the Company expects product bookings to be between $745 million and $780 million.

[0000926326-19-000003:8k_2_02:36]
For the same period, the Company expects non-GAAP total revenues to be between $880 million and $900 million. The Company expects non-GAAP product revenues to be between $652 million and $668 million, and non-GAAP service revenues to be between $228 million and $232 million. The Company expects 2019 non-GAAP earnings to be between $2.40 and $2.60 per share.

[0000926326-19-000003:8k_2_02:37]
The table below summarizes Omnicell's 2019 guidance outlined above:

[0000926326-19-000003:8k_2_02:38]
|  | Q1'19 | Total Year 2019 |
| Product Bookings | Not provided | $745 million - $780 million |
| Non-GAAP Total Revenues | $196 million - $202 million | $880 million - $900 million |
| Non-GAAP Product Revenues | $140 million - $145 million | $652 million - $668 million |
| Non-GAAP Service Revenues | $56 million - $57 million | $228 million - $232 million |
| Non-GAAP EPS | $0.38 - $0.43 | $2.40 - $2.60 |

[0000926326-19-000003:8k_2_02:39]
Omnicell Conference Call Information

[0000926326-19-000003:8k_2_02:40]
Omnicell will hold a conference call today, Thursday, February 7, 2019 at 1:30 p.m. PT to discuss fourth quarter financial results. The conference call can be monitored by dialing 1-800-696-5518 within the U.S. or 1-706-758-4883 for all other locations. The Conference ID # is 4073668. Internet users can access the conference call at http://ir.omnicell.com/communications/events-presentations. A replay of the call will be available today at approximately 4:30 p.m. PT and will be available until 11:59 p.m. PT on March 21, 2019. The replay access numbers are 1-855-859-2056 within the U.S. and 1-404-537-3406 for all other locations, Conference ID # is 4073668.

[0000926326-19-000003:8k_2_02:41]
About Omnicell

[0000926326-19-000003:8k_2_02:42]
Since 1992, Omnicell has been inspired to create safer and more efficient ways to manage medications across all care settings. Through our industry-leading medication management platform that spans the continuum of care, Omnicell is developing a vision for a fully automated infrastructure, powered by a cloud data platform that supports improved patient care, fewer errors, enhanced safety, and new opportunities for growth.

[0000926326-19-000003:8k_2_02:43]
Omnicell’s vision for the Autonomous Pharmacy integrates a comprehensive set of solutions across three key areas:  Automation solutions designed to digitize and streamline workflows; Intelligence that provides actionable insights to better understand medication usage and improve pharmacy supply chain management; and Work - expert services that serve as an extension of pharmacy operations to support improved efficiency, regulatory compliance, and patient outcomes.

[0000926326-19-000003:8k_2_02:44]
Over 5,000 facilities worldwide use Omnicell automation and analytics solutions to help increase operational efficiency, reduce medication errors, deliver actionable intelligence, and improve patient safety. And more than 40,000 institutional and retail pharmacies across North America and the United Kingdom leverage Omnicell's innovative medication adherence solutions to improve patient engagement and adherence to prescriptions, helping to reduce costly hospital readmissions.

[0000926326-19-000003:8k_2_02:45]
For more information about Omnicell, Inc. please visit www.omnicell.com.

[0000926326-19-000003:8k_2_02:46]
Omnicell and the Omnicell logo are registered trademarks of Omnicell, Inc. in the United States and other countries.

[0000926326-19-000003:8k_2_02:47]
Forward-Looking Statements

[0000926326-19-000003:8k_2_02:48]
3

[0000926326-19-000003:8k_2_02:49]
Omnicell’s most recent filings with the Securities and Exchange Commission (“SEC”). Prospective investors are cautioned not to place undue reliance on forward-looking statements. All forward-looking statements contained in this press release speak only as of the date on which they were made. Omnicell undertakes no obligation to update such statements to reflect events that occur or circumstances that exist after the date on which they were made.

[0000926326-19-000003:8k_2_02:50]
Use of Non-GAAP Financial Information

[0000926326-19-000003:8k_2_02:51]
This press release contains financial measures that are not calculated in accordance with GAAP. Our management evaluates and makes operating decisions using various performance measures. In addition to Omnicell’s GAAP results, we also consider non-GAAP revenues, non-GAAP gross profit, non-GAAP operating expenses, non-GAAP net income, and non-GAAP net income per diluted share. Additionally, we calculate adjusted EBITDA (another non-GAAP measure) by means of adjustments to GAAP net income. These non-GAAP results should not be considered as an alternative to gross profit, operating expenses, net income, net income per diluted share, or any other performance measure derived in accordance with GAAP. We present these non-GAAP results because we consider them to be important supplemental measures of Omnicell’s performance.

[0000926326-19-000003:8k_2_02:52]
Our non-GAAP revenues, non-GAAP gross profit, non-GAAP operating expenses, non-GAAP net income, and non-GAAP net income per diluted share are exclusive of certain items to facilitate management’s review of the comparability of Omnicell’s core operating results on a period to period basis because such items are not related to Omnicell’s ongoing core operating results as viewed by management. We define our “core operating results” as those revenues recorded in a particular period and the expenses incurred within that period that directly drive operating income in that period. Management uses these non-GAAP financial measures in making operating decisions because, in addition to meaningful supplemental information regarding operating performance, the measures give us a better understanding of how we should invest in research and development, fund infrastructure growth and evaluate the effectiveness of marketing strategies. In calculating the above non-GAAP results, management specifically adjusted for the following excluded items:

[0000926326-19-000003:8k_2_02:53]
| a) | Share-based compensation expense. We excluded from our non-GAAP results the expense related to equity-based compensation plans as they represent expenses that do not require cash settlement from Omnicell. |

[0000926326-19-000003:8k_2_02:54]
| b) | Amortization of acquired intangible assets. We excluded from our non-GAAP results the intangible assets amortization expense resulting from our past acquisitions. These non-cash charges are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results. |

[0000926326-19-000003:8k_2_02:55]
| c) | Amortization of debt issuance cost. Debt issuance cost represents costs associated with the issuance of Term Loan and Revolving Line of Credit facilities. The cost includes underwriting fees, original issue discount, ticking fee, and legal fees. This non-cash expense is not considered by management to reflect the core cash-generating performance of the business and therefore is excluded from our non-GAAP results. |

[0000926326-19-000003:8k_2_02:56]
| d) | Acquisition accounting impact related to deferred revenues. In connection with recent acquisitions, business combination rules require us to account for the fair values of arrangements for which acceptance has not been obtained, and post installation support has not been provided in our purchase accounting. The non-GAAP adjustment to our revenues is intended to include the full amounts of such revenues. We believe the adjustment to these revenues is useful as a measure of the ongoing performance of our business. |

[0000926326-19-000003:8k_2_02:57]
| e) | Acquisition-related expenses. We excluded from the non-GAAP results the expenses which are related to recent acquisitions. These expenses are unrelated to our ongoing operations and we do not expect them to occur in the ordinary course of business. We believe that excluding these acquisition related expenses provides more meaningful comparisons of the financial results to our historical operations and forward looking guidance and the financial results of less acquisitive peer companies. |

[0000926326-19-000003:8k_2_02:58]
| f) | Severance and other related expenses. We excluded from our non-GAAP results the expenses which are related to restructuring events. These expenses are unrelated to our ongoing operations and we do not expect them to occur in the ordinary course of business. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward looking guidance and the financial results of peer companies. |

[0000926326-19-000003:8k_2_02:59]
| g) | Tax impact from restructuring activity. We excluded from our non-GAAP results the income tax impacts related to restructuring activity. These impacts are unrelated to our ongoing operations, and we do not expect them to occur in the ordinary course of business. We believe that excluding these impacts provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and the financial results of peer companies. |

[0000926326-19-000003:8k_2_02:60]
4

[0000926326-19-000003:8k_2_02:61]
| h) | Contingent gain. We excluded from our non-GAAP results the contingent gain related to a settlement agreement associated with the Ateb acquisition. This contingent gain is unrelated to our ongoing operations, and we do not expect it to occur in the ordinary course of business. We believe that excluding this contingent gain provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and the financial results of peer companies. |

[0000926326-19-000003:8k_2_02:62]
Management adjusts for the above items because management believes that, in general, these items possess one or more of the following characteristics: their magnitude and timing is largely outside of Omnicell’s control; they are unrelated to the ongoing operation of the business in the ordinary course; they are unusual and we do not expect them to occur in the ordinary course of business; or they are non-operational, or non-cash expenses involving stock compensation plans or other items.

[0000926326-19-000003:8k_2_02:63]
We believe that the presentation of these non-GAAP financial measures is warranted for several reasons:

[0000926326-19-000003:8k_2_02:64]
| a) | Such non-GAAP financial measures provide an additional analytical tool for understanding Omnicell’s financial performance by excluding the impact of items which may obscure trends in the core operating results of the business; |

[0000926326-19-000003:8k_2_02:65]
| b) | Since we have historically reported non-GAAP results to the investment community, we believe the inclusion of non-GAAP numbers provides consistency and enhances investors’ ability to compare our performance across financial reporting periods; |

[0000926326-19-000003:8k_2_02:66]
| c) | These non-GAAP financial measures are employed by Omnicell’s management in its own evaluation of performance and are utilized in financial and operational decision making processes, such as budget planning and forecasting; and |

[0000926326-19-000003:8k_2_02:67]
| d) | These non-GAAP financial measures facilitate comparisons to the operating results of other companies in our industry, which use similar financial measures to supplement their GAAP results, thus enhancing the perspective of investors who wish to utilize such comparisons in their analysis of our performance. |

[0000926326-19-000003:8k_2_02:68]
Set forth below are additional reasons why share-based compensation expense is excluded from our non-GAAP financial measures:

[0000926326-19-000003:8k_2_02:69]
| i) | While share-based compensation calculated in accordance with ASC 718 constitutes an ongoing and recurring expense of Omnicell, it is not an expense that requires cash settlement by Omnicell. We therefore exclude these charges for purposes of evaluating core operating results. Thus, our non-GAAP measurements are presented exclusive of stock-based compensation expense to assist management and investors in evaluating our core operating results. |

[0000926326-19-000003:8k_2_02:70]
| ii) | We present ASC 718 share-based payment compensation expense in our reconciliation of non-GAAP financial measures on a pre-tax basis because the exact tax differences related to the timing and deductibility of share-based compensation, under ASC 718 are dependent upon the trading price of Omnicell’s common stock and the timing and exercise by employees of their stock options. As a result of these timing and market uncertainties the tax effect related to share-based compensation expense would be inconsistent in amount and frequency and is therefore excluded from our non-GAAP results. |

[0000926326-19-000003:8k_2_02:71]
Our adjusted EBITDA calculation is defined as earnings before interest income and expense, taxes, depreciation and amortization, and non-cash expenses, including ASC 718 share-based compensation expense, as well as certain non-GAAP adjustments.

[0000926326-19-000003:8k_2_02:72]
As stated above, we present non-GAAP financial measures because we consider them to be important supplemental measures of performance. However, non-GAAP financial measures have limitations as an analytical tool and should not be considered in isolation or as a substitute for Omnicell’s GAAP results. In the future, we expect to incur expenses similar to certain of the non-GAAP adjustments described above and expect to continue reporting non-GAAP financial measures excluding such items. Some of the limitations in relying on non-GAAP financial measures are:

[0000926326-19-000003:8k_2_02:73]
| a) | Omnicell’s stock option and stock purchase plans are important components of incentive compensation arrangements and will be reflected as expenses in Omnicell’s GAAP results for the foreseeable future under ASC 718. |

[0000926326-19-000003:8k_2_02:74]
| b) | Other companies, including companies in Omnicell’s industry, may calculate non-GAAP financial measures differently than Omnicell, limiting their usefulness as a comparative measure. |

[0000926326-19-000003:8k_2_02:75]
Pursuant to the requirements of SEC Regulation G, a detailed reconciliation between Omnicell’s non-GAAP and GAAP financial results is set forth in the financial tables at the end of this press release. Investors are advised to carefully review and consider this information strictly as a supplement to the GAAP results that are contained in this press release and in Omnicell’s SEC filings.

[0000926326-19-000003:8k_2_02:76]
Our 2019 guidance for non-GAAP earnings per share, as well as certain projections to be discussed in the conference call noted above, exclude “certain items,” which include but are not limited to: unusual gains and losses; costs associated with future restructurings; acquisition-related expenses; and certain tax and litigation outcomes. We do not provide a reconciliation of non-GAAP earnings per share guidance to the comparable GAAP measure as these items are inherently uncertain and difficult to estimate, and cannot be predicted without unreasonable effort. We believe such a reconciliation would imply a degree of precision that could be confusing to investors. These items may also have a material impact on GAAP earnings per share in future periods.

[0000926326-19-000003:8k_2_02:77]
6

[0000926326-19-000003:8k_2_02:78]
Omnicell, Inc.

[0000926326-19-000003:8k_2_02:79]
Condensed Consolidated Statements of Operations

[0000926326-19-000003:8k_2_02:80]
(Unaudited, in thousands, except per share data)

[0000926326-19-000003:8k_2_02:81]
|  | Three Months Ended |
|  | December 31, 2018 |  | December 31, 2017 |
|  |  | As Adjusted (a) |  | As Reported |  | Change |
| Revenues: |  |  |  |  |  |  |  |
| Product revenues | $ | 154,591 |  |  | $ | 144,367 |  |  | $ | 144,120 |  |  | $ | 247 |  |
| Services and other revenues | 57,159 |  |  | 52,004 |  |  | 53,824 |  |  | (1,820 | ) |
| Total revenues | 211,750 |  |  | 196,371 |  |  | 197,944 |  |  | (1,573 | ) |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | 82,718 |  |  | 79,791 |  |  | 79,791 |  |  | — |  |
| Cost of services and other revenues | 26,849 |  |  | 23,085 |  |  | 23,085 |  |  | — |  |
| Total cost of revenues | 109,567 |  |  | 102,876 |  |  | 102,876 |  |  | — |  |
| Gross profit | 102,183 |  |  | 93,495 |  |  | 95,068 |  |  | (1,573 | ) |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 16,989 |  |  | 15,894 |  |  | 15,894 |  |  | — |  |
| Selling, general, and administrative (b) | 66,264 |  |  | 61,400 |  |  | 63,494 |  |  | (2,094 | ) |
| Total operating expenses | 83,253 |  |  | 77,294 |  |  | 79,388 |  |  | (2,094 | ) |
| Income from operations | 18,930 |  |  | 16,201 |  |  | 15,680 |  |  | 521 |  |
| Interest and other income (expense), net | (2,314 | ) |  | (1,641 | ) |  | (1,641 | ) |  | — |  |
| Income before provision for income taxes | 16,616 |  |  | 14,560 |  |  | 14,039 |  |  | 521 |  |
| Provision for (benefit from) income taxes | 1,823 |  |  | (16,665 | ) |  | (10,252 | ) |  | (6,413 | ) |
| Net income | $ | 14,793 |  |  | $ | 31,225 |  |  | $ | 24,291 |  |  | $ | 6,934 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.37 |  |  | $ | 0.82 |  |  | $ | 0.64 |  |  | $ | 0.18 |  |
| Diluted | $ | 0.36 |  |  | $ | 0.79 |  |  | $ | 0.62 |  |  | $ | 0.17 |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 39,913 |  |  | 38,127 |  |  | 38,127 |  |  |  |
| Diluted | 41,465 |  |  | 39,482 |  |  | 39,482 |  |  |  |

[0000926326-19-000003:8k_2_02:82]
(a)     As adjusted for full retrospective adoption of Accounting Standards Codification ("ASC") 606, Revenue from Contracts with Customers. The adjustment also includes a $0.3 million reclassification from services and other revenues to product revenues to conform with current-period presentation.

[0000926326-19-000003:8k_2_02:83]
(b)  Three months ended December 31, 2018 includes certain out-of-period adjustments that are not material to any previously issued financial statements.

[0000926326-19-000003:8k_2_02:84]
Omnicell, Inc.

[0000926326-19-000003:8k_2_02:85]
Condensed Consolidated Statements of Operations

[0000926326-19-000003:8k_2_02:86]
(Unaudited, in thousands, except per share data)

[0000926326-19-000003:8k_2_02:87]
|  | Year Ended |
|  | December 31, 2018 (a) |  | December 31, 2017 |
|  |  | As Adjusted (b) |  | As Reported |  | Change |
| Revenues: |  |  |  |  |  |  |  |
| Product revenues | $ | 569,595 |  |  | $ | 510,201 |  |  | $ | 506,209 |  |  | $ | 3,992 |  |
| Services and other revenues | 217,714 |  |  | 202,513 |  |  | 209,956 |  |  | (7,443 | ) |
| Total revenues | 787,309 |  |  | 712,714 |  |  | 716,165 |  |  | (3,451 | ) |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | 312,360 |  |  | 304,842 |  |  | 304,842 |  |  | — |  |
| Cost of services and other revenues | 102,619 |  |  | 89,235 |  |  | 89,235 |  |  | — |  |
| Total cost of revenues | 414,979 |  |  | 394,077 |  |  | 394,077 |  |  | — |  |
| Gross profit | 372,330 |  |  | 318,637 |  |  | 322,088 |  |  | (3,451 | ) |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 64,843 |  |  | 66,022 |  |  | 66,022 |  |  | — |  |
| Selling, general, and administrative (c) | 263,095 |  |  | 241,470 |  |  | 250,312 |  |  | (8,842 | ) |
| Total operating expenses | 327,938 |  |  | 307,492 |  |  | 316,334 |  |  | (8,842 | ) |
| Income from operations | 44,392 |  |  | 11,145 |  |  | 5,754 |  |  | 5,391 |  |
| Interest and other income (expense), net | (8,776 | ) |  | (6,633 | ) |  | (6,633 | ) |  | — |  |
| Income (loss) before provision for income taxes | 35,616 |  |  | 4,512 |  |  | (879 | ) |  | 5,391 |  |
| Provision for (benefit from) income taxes | (2,113 | ) |  | (26,006 | ) |  | (21,484 | ) |  | (4,522 | ) |
| Net income | $ | 37,729 |  |  | $ | 30,518 |  |  | $ | 20,605 |  |  | $ | 9,913 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.96 |  |  | $ | 0.81 |  |  | $ | 0.55 |  |  | $ | 0.26 |  |
| Diluted | $ | 0.93 |  |  | $ | 0.79 |  |  | $ | 0.53 |  |  | $ | 0.26 |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 39,242 |  |  | 37,483 |  |  | 37,483 |  |  |  |
| Diluted | 40,559 |  |  | 38,712 |  |  | 38,712 |  |  |  |

[0000926326-19-000003:8k_2_02:88]
| (a) | Includes a $0.6 million reclassification from services and other revenues to product revenues during the quarter ended June 30, 2018 to conform with current-period presentation. |

[0000926326-19-000003:8k_2_02:89]
| (b) | As adjusted for full retrospective adoption of ASC 606. The adjustment also includes a $0.8 million reclassification from services and other revenues to product revenues to conform with current-period presentation. |

[0000926326-19-000003:8k_2_02:90]
(c)   Twelve months ended December 31, 2018 includes certain out-of-period adjustments that are not material to any previously issued financial statements

[0000926326-19-000003:8k_2_02:91]
8

[0000926326-19-000003:8k_2_02:92]
Omnicell, Inc.

[0000926326-19-000003:8k_2_02:93]
Condensed Consolidated Balance Sheets

[0000926326-19-000003:8k_2_02:94]
(Unaudited, in thousands)

[0000926326-19-000003:8k_2_02:95]
|  | December 31, 2018 |  | December 31, 2017 |
|  |  | As Adjusted (a) |  | As Reported |  | Change |
| ASSETS |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 67,192 |  |  | $ | 32,424 |  |  | $ | 32,424 |  |  | $ | — |  |
| Accounts receivable and unbilled, net | 196,238 |  |  | 190,046 |  |  | 189,227 |  |  | 819 |  |
| Inventories | 100,868 |  |  | 96,137 |  |  | 96,137 |  |  | — |  |
| Prepaid expenses | 20,700 |  |  | 20,392 |  |  | 36,060 |  |  | (15,668 | ) |
| Other current assets | 12,136 |  |  | 13,273 |  |  | 13,273 |  |  | — |  |
| Total current assets | 397,134 |  |  | 352,272 |  |  | 367,121 |  |  | (14,849 | ) |
| Property and equipment, net | 51,500 |  |  | 42,595 |  |  | 42,595 |  |  | — |  |
| Long-term investment in sales-type leases, net | 17,082 |  |  | 15,435 |  |  | 15,435 |  |  | — |  |
| Goodwill | 335,887 |  |  | 337,751 |  |  | 337,751 |  |  | — |  |
| Intangible assets, net | 143,686 |  |  | 168,107 |  |  | 168,107 |  |  | — |  |
| Long-term deferred tax assets | 15,197 |  |  | 9,454 |  |  | 9,454 |  |  | — |  |
| Prepaid commissions | 46,143 |  |  | 41,432 |  |  | — |  |  | 41,432 |  |
| Other long-term assets | 74,613 |  |  | 49,316 |  |  | 39,841 |  |  | 9,475 |  |
| Total assets | $ | 1,081,242 |  |  | $ | 1,016,362 |  |  | $ | 980,304 |  |  | $ | 36,058 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable | $ | 38,038 |  |  | $ | 48,290 |  |  | $ | 48,290 |  |  | $ | — |  |
| Accrued compensation | 41,660 |  |  | 27,241 |  |  | 27,241 |  |  | — |  |
| Accrued liabilities | 43,047 |  |  | 35,693 |  |  | 35,693 |  |  | — |  |
| Long-term debt, current portion, net | — |  |  | 15,208 |  |  | 15,208 |  |  | — |  |
| Deferred revenues, net | 81,835 |  |  | 78,774 |  |  | 86,104 |  |  | (7,330 | ) |
| Total current liabilities | 204,580 |  |  | 205,206 |  |  | 212,536 |  |  | (7,330 | ) |
| Long-term, deferred revenues | 10,582 |  |  | 10,623 |  |  | 17,244 |  |  | (6,621 | ) |
| Long-term deferred tax liabilities | 41,484 |  |  | 41,446 |  |  | 28,579 |  |  | 12,867 |  |
| Other long-term liabilities | 9,562 |  |  | 9,829 |  |  | 9,829 |  |  | — |  |
| Long-term debt, net | 135,417 |  |  | 194,917 |  |  | 194,917 |  |  | — |  |
| Total liabilities | 401,625 |  |  | 462,021 |  |  | 463,105 |  |  | (1,084 | ) |
| Total stockholders’ equity | 679,617 |  |  | 554,341 |  |  | 517,199 |  |  | 37,142 |  |
| Total liabilities and stockholders’ equity | $ | 1,081,242 |  |  | $ | 1,016,362 |  |  | $ | 980,304 |  |  | $ | 36,058 |  |

[0000926326-19-000003:8k_2_02:96]
| (a) | As adjusted for full retrospective adoption of ASC 606. |

[0000926326-19-000003:8k_2_02:97]
Omnicell, Inc.

[0000926326-19-000003:8k_2_02:98]
Condensed Consolidated Statements of Cash Flows

[0000926326-19-000003:8k_2_02:99]
(Unaudited, in thousands)

[0000926326-19-000003:8k_2_02:100]
|  | Year Ended December 31, |
|  | 2018 |  | 2017 (a) |
| Operating Activities |  |  |  |
| Net income | $ | 37,729 |  |  | $ | 30,518 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 51,350 |  |  | 51,511 |  |
| Loss on disposal of fixed assets | 133 |  |  | 512 |  |
| Share-based compensation expense | 28,885 |  |  | 21,857 |  |
| Income tax benefits from employee stock plans | — |  |  | 11 |  |
| Deferred income taxes | (5,705 | ) |  | (31,365 | ) |
| Amortization of debt financing fees | 2,292 |  |  | 1,590 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable and unbilled receivables | (6,192 | ) |  | (40,598 | ) |
| Inventories | (6,763 | ) |  | (26,840 | ) |
| Prepaid expenses | (308 | ) |  | (4,920 | ) |
| Other current assets | 1,170 |  |  | (2,074 | ) |
| Investment in sales-type leases | (1,680 | ) |  | 6,625 |  |
| Prepaid commissions | (4,711 | ) |  | (3,966 | ) |
| Other long-term assets | (7,077 | ) |  | (1,373 | ) |
| Accounts payable | (9,154 | ) |  | 19,709 |  |
| Accrued compensation | 14,419 |  |  | 519 |  |
| Accrued liabilities | 8,223 |  |  | 4,383 |  |
| Deferred revenues | 3,020 |  |  | (2,334 | ) |
| Other long-term liabilities | (1,665 | ) |  | 1,069 |  |
| Net cash provided by operating activities | 103,966 |  |  | 24,834 |  |
| Investing Activities |  |  |  |
| Purchases of intangible assets, intellectual property, and patents | — |  |  | (160 | ) |
| Software development for external use | (30,677 | ) |  | (15,040 | ) |
| Purchases of property and equipment | (23,697 | ) |  | (15,341 | ) |
| Business acquisitions, net of cash acquired | — |  |  | (4,446 | ) |
| Net cash used in investing activities | (54,374 | ) |  | (34,987 | ) |
| Financing Activities |  |  |  |
| Proceeds from debt, net | — |  |  | 56,894 |  |
| Repayment of debt and revolving credit facility | (77,000 | ) |  | (102,500 | ) |
| Payment for contingent consideration | — |  |  | (2,400 | ) |
| At the market offering, net of offering costs | 39,567 |  |  | 13,900 |  |
| Proceeds from issuances under stock-based compensation plans | 30,611 |  |  | 30,121 |  |
| Employees' taxes paid related to restricted stock units | (6,775 | ) |  | (5,892 | ) |
| Net cash used in financing activities | (13,597 | ) |  | (9,877 | ) |
| Effect of exchange rate changes on cash and cash equivalents | (1,227 | ) |  | (2,034 | ) |
| Net increase (decrease) in cash and cash equivalents | 34,768 |  |  | (22,064 | ) |
| Cash and cash equivalents at beginning of period | 32,424 |  |  | 54,488 |  |
| Cash and cash equivalents at end of period | $ | 67,192 |  |  | $ | 32,424 |  |

[0000926326-19-000003:8k_2_02:101]
| (a) | As adjusted for full retrospective adoption of ASC 606. |

[0000926326-19-000003:8k_2_02:102]
10

[0000926326-19-000003:8k_2_02:103]
Omnicell, Inc.

[0000926326-19-000003:8k_2_02:104]
Reconciliation of GAAP to Non-GAAP

[0000926326-19-000003:8k_2_02:105]
(Unaudited, in thousands, except per share data and percentage)

[0000926326-19-000003:8k_2_02:106]
|  |  |  |  |  |  | Three Months Ended |  | Twelve Months Ended |
|  |  |  |  |  |  | December 31, 2018 |  | December 31, 2017 (a) |  | December 31, 2018 |  | December 31, 2017 (a) |
| Reconciliation of GAAP revenues to non-GAAP revenues: |  |  |  |  |  |
| GAAP revenues |  | $ | 211,750 |  |  | $ | 196,371 |  |  | $ | 787,309 |  |  | $ | 712,714 |  |
|  | Acquisition accounting impact related to deferred revenues | — |  |  | 313 |  |  | — |  |  | 1,252 |  |
| Non-GAAP revenues | $ | 211,750 |  |  | $ | 196,684 |  |  | $ | 787,309 |  |  | $ | 713,966 |  |
| Reconciliation of GAAP gross profit to non-GAAP gross profit: |  |  |  |  |  |
| GAAP gross profit | $ | 102,183 |  |  | $ | 93,495 |  |  | $ | 372,330 |  |  | $ | 318,637 |  |
| GAAP gross margin | 48.3% |  | 47.6% |  | 47.3% |  | 44.7% |
|  | Share-based compensation expense | 1,289 |  |  | 834 |  |  | 4,635 |  |  | 3,562 |  |
|  | Amortization of acquired intangibles | 3,091 |  |  | 2,818 |  |  | 11,366 |  |  | 11,488 |  |
|  | Acquisition accounting impact related to deferred revenue | — |  |  | 313 |  |  | — |  |  | 1,252 |  |
|  | Severance and other expenses (b) | 186 |  |  | 234 |  |  | 186 |  |  | 2,001 |  |
| Non-GAAP gross profit | $ | 106,749 |  |  | $ | 97,694 |  |  | $ | 388,517 |  |  | $ | 336,940 |  |
| Non-GAAP gross margin | 50.4% |  | 49.7% |  | 49.3% |  | 47.2% |
| Reconciliation of GAAP operating expenses to non-GAAP operating expenses: |  |  |  |  |
| GAAP operating expenses | $ | 83,253 |  |  | $ | 77,294 |  |  | $ | 327,938 |  |  | $ | 307,492 |  |
| GAAP operating expenses % to total revenues |  | 39.3% |  | 39.4% |  | 41.7% |  | 43.1% |
|  | Share-based compensation expense | (6,745 | ) |  | (4,708 | ) |  | (24,250 | ) |  | (18,295 | ) |
|  | Amortization of acquired intangibles | (2,937 | ) |  | (3,348 | ) |  | (12,330 | ) |  | (14,008 | ) |
|  | Acquisition-related expenses | — |  |  | — |  |  | — |  |  | (126 | ) |
|  | Severance and other expenses (b) | (1,157 | ) |  | (233 | ) |  | (4,337 | ) |  | (3,764 | ) |
| Non-GAAP operating expenses | $ | 72,414 |  |  | $ | 69,005 |  |  | $ | 287,021 |  |  | $ | 271,299 |  |
| Non-GAAP operating expenses % to total non-GAAP revenues | 34.2% |  | 35.1% |  | 36.5% |  | 38.0% |
| Reconciliation of GAAP income from operations to non-GAAP income from operations: |
| GAAP income from operations |  | $ | 18,930 |  |  | $ | 16,201 |  |  | $ | 44,392 |  |  | $ | 11,145 |  |
| GAAP operating income % to total revenues |  | 8.9% |  | 8.3% |  | 5.6% |  | 1.6% |
|  | Share-based compensation expense | 8,034 |  |  | 5,542 |  |  | 28,885 |  |  | 21,857 |  |
|  | Amortization of acquired intangibles | 6,028 |  |  | 6,166 |  |  | 23,696 |  |  | 25,496 |  |
|  | Acquisition accounting impact related to deferred revenue | — |  |  | 313 |  |  | — |  |  | 1,252 |  |
|  | Acquisition-related expenses | — |  |  | — |  |  | — |  |  | 126 |  |
|  | Severance and other expenses | 1,343 |  |  | 467 |  |  | 4,523 |  |  | 5,765 |  |
| Non-GAAP income from operations | $ | 34,335 |  |  | $ | 28,689 |  |  | $ | 101,496 |  |  | $ | 65,641 |  |
| Non-GAAP operating income % to total non-GAAP revenues | 16.2% |  | 14.6% |  | 12.9% |  | 9.2% |

[0000926326-19-000003:8k_2_02:107]
| (a) | As adjusted for full retrospective adoption of ASC 606. |

[0000926326-19-000003:8k_2_02:108]
| (b) | Other expenses include relocation charge of $578, restructuring rent expense of $510, integration consulting expense of $201, and depreciation adjustment related to purchase price allocation from acquisition of $1,013 for the year ended December 31, 2017. |

[0000926326-19-000003:8k_2_02:109]
11

[0000926326-19-000003:8k_2_02:110]
|  |  |  |  |  |  | Three Months Ended |  | Twelve Months Ended |
|  |  |  |  |  |  | December 31, 2018 |  | December 31, 2017 (a) |  | December 31, 2018 |  | December 31, 2017 (a) |
| Reconciliation of GAAP net income to non-GAAP net income: |  |  |  |  |  |
| GAAP net income | $ | 14,793 |  |  | $ | 31,225 |  |  | $ | 37,729 |  |  | $ | 30,518 |  |
|  | Tax reform benefit impact | — |  |  | (20,005 | ) |  | — |  |  | (20,005 | ) |
|  | Tax benefit for restructuring activity | — |  |  | — |  |  | (4,205 | ) |  | — |  |
|  | Share-based compensation expense | 8,034 |  |  | 5,542 |  |  | 28,885 |  |  | 21,857 |  |
|  | Amortization of acquired intangibles | 6,028 |  |  | 6,166 |  |  | 23,696 |  |  | 25,496 |  |
|  | Acquisition accounting impact related to deferred revenue | — |  |  | 313 |  |  | — |  |  | 1,252 |  |
|  | Acquisition related expenses | 397 |  |  | 397 |  |  | 1,589 |  |  | 1,715 |  |
|  | Severance and other expenses | 1,519 |  |  | 467 |  |  | 5,227 |  |  | 5,765 |  |
|  | Contingent gain | — |  |  | — |  |  | (2,456 | ) |  | — |  |
|  | Tax effect of the adjustments above (b) | (1,668 | ) |  | (2,570 | ) |  | (5,891 | ) |  | (11,980 | ) |
| Non-GAAP net income | $ | 29,103 |  |  | $ | 21,535 |  |  | $ | 84,574 |  |  | $ | 54,618 |  |
| Reconciliation of GAAP net income per share - diluted to non-GAAP net income per share - diluted: |  |  |
| Shares - diluted GAAP | 41,465 |  |  | 39,482 |  |  | 40,559 |  |  | 38,712 |  |
| Shares - diluted Non-GAAP | 41,465 |  |  | 39,482 |  |  | 40,559 |  |  | 38,712 |  |
| GAAP net income per share - diluted | $ | 0.36 |  |  | $ | 0.79 |  |  | $ | 0.93 |  |  | $ | 0.79 |  |
|  | Tax reform benefit impact | — |  |  | (0.50 | ) |  | — |  |  | (0.52 | ) |
|  | Tax benefit for restructuring activity | — |  |  | — |  |  | (0.10 | ) |  | — |  |
|  | Share-based compensation expense | 0.18 |  |  | 0.14 |  |  | 0.72 |  |  | 0.56 |  |
|  | Amortization of acquired intangibles | 0.15 |  |  | 0.16 |  |  | 0.58 |  |  | 0.67 |  |
|  | Acquisition accounting impact related to deferred revenue | — |  |  | 0.01 |  |  | — |  |  | 0.03 |  |
|  | Acquisition related expenses | 0.01 |  |  | 0.01 |  |  | 0.04 |  |  | 0.04 |  |
|  | Severance and other expenses | 0.04 |  |  | 0.01 |  |  | 0.13 |  |  | 0.15 |  |
|  | Contingent gain | — |  |  | — |  |  | (0.06 | ) |  | — |  |
|  | Tax effect of the adjustments above (b) | (0.04 | ) |  | (0.07 | ) |  | (0.15 | ) |  | (0.31 | ) |
| Non-GAAP net income per share - diluted | $ | 0.70 |  |  | $ | 0.55 |  |  | $ | 2.09 |  |  | $ | 1.41 |  |
| Reconciliation of GAAP net income to non-GAAP Adjusted EBITDA: |  |  |  |  |  |
| GAAP net income | $ | 14,793 |  |  | $ | 31,225 |  |  | $ | 37,729 |  |  | $ | 30,518 |  |
|  | Share-based compensation expense | 8,034 |  |  | 5,542 |  |  | 28,885 |  |  | 21,857 |  |
|  | Interest (income) and expense, net | 907 |  |  | 1,202 |  |  | 5,855 |  |  | 6,072 |  |
|  | Depreciation and amortization expense | 13,860 |  |  | 12,969 |  |  | 51,350 |  |  | 51,511 |  |
|  | Acquisition accounting impact related to deferred revenue | — |  |  | 313 |  |  | — |  |  | 1,252 |  |
|  | Acquisition related expenses | 397 |  |  | 397 |  |  | 1,589 |  |  | 1,715 |  |
|  | Severance and other expenses | 1,519 |  |  | 213 |  |  | 5,227 |  |  | 4,752 |  |
|  | Contingent gain | — |  |  | — |  |  | (2,456 | ) |  | — |  |
|  | Income tax expense (benefit) | 1,823 |  |  | (16,665 | ) |  | (2,113 | ) |  | (26,006 | ) |
| Non-GAAP Adjusted EBITDA (c) | $ | 41,333 |  |  | $ | 35,196 |  |  | $ | 126,066 |  |  | $ | 91,671 |  |

[0000926326-19-000003:8k_2_02:111]
| (a) | As adjusted for full retrospective adoption of ASC 606. |

[0000926326-19-000003:8k_2_02:112]
| (b) | Tax effects calculated for all adjustments except tax benefits and share-based compensation expense, using an estimated annual effective tax rate of 21% for fiscal year 2018 and 35% for fiscal year 2017. |

[0000926326-19-000003:8k_2_02:113]
| (c) | Defined as earnings before interest income and expense, taxes, depreciation and amortization, share-based compensation expense, as well as excluding certain non-GAAP adjustments. |

[0000926326-19-000003:8k_2_02:114]
12

[0000926326-19-000003:8k_2_02:115]
Omnicell, Inc.

[0000926326-19-000003:8k_2_02:116]
Segmented Information

[0000926326-19-000003:8k_2_02:117]
(Unaudited, in thousands, except for percentages)

[0000926326-19-000003:8k_2_02:118]
|  | Three Months Ended December 31, 2018 |  | Three Months Ended December 31, 2017 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |  | Automation andAnalytics (a) |  | MedicationAdherence |  | Total |
| Revenues | $ | 177,605 |  |  | $ | 34,145 |  |  | $ | 211,750 |  |  | $ | 161,569 |  |  | $ | 34,802 |  |  | $ | 196,371 |  |
| Cost of revenues | 85,157 |  |  | 24,410 |  |  | 109,567 |  |  | 79,225 |  |  | 23,651 |  |  | 102,876 |  |
| Gross profit | 92,448 |  |  | 9,735 |  |  | 102,183 |  |  | 82,344 |  |  | 11,151 |  |  | 93,495 |  |
| Gross margin % | 52.1% |  | 28.5% |  | 48.3% |  | 51.0% |  | 32.0% |  | 47.6% |
| Operating expenses | 45,731 |  |  | 10,311 |  |  | 56,042 |  |  | 44,955 |  |  | 10,539 |  |  | 55,494 |  |
| Income (loss) from segment operations | $ | 46,717 |  |  | $ | (576 | ) |  | $ | 46,141 |  |  | $ | 37,389 |  |  | $ | 612 |  |  | $ | 38,001 |  |
| Operating margin % | 26.3% |  | (1.7)% |  | 21.8% |  | 23.1% |  | 1.8% |  | 19.4% |
| Corporate costs |  |  |  |  | 27,211 |  |  |  |  |  |  | 21,800 |  |
| Income from operations |  |  |  |  | $ | 18,930 |  |  |  |  |  |  | $ | 16,201 |  |

[0000926326-19-000003:8k_2_02:119]
| a) | As adjusted for full retrospective adoption of ASC 606. |

[0000926326-19-000003:8k_2_02:120]
13

[0000926326-19-000003:8k_2_02:121]
Omnicell, Inc.

[0000926326-19-000003:8k_2_02:122]
Segmented Information

[0000926326-19-000003:8k_2_02:123]
(Unaudited, in thousands, except for percentages)

[0000926326-19-000003:8k_2_02:124]
|  | Year Ended December 31, 2018 |  | Year Ended December 31, 2017 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |  | Automation andAnalytics (a) |  | MedicationAdherence |  | Total |
| Revenues | $ | 655,679 |  |  | $ | 131,630 |  |  | $ | 787,309 |  |  | $ | 586,941 |  |  | $ | 125,773 |  |  | $ | 712,714 |  |
| Cost of revenues | 319,257 |  |  | 95,722 |  |  | 414,979 |  |  | 308,443 |  |  | 85,634 |  |  | 394,077 |  |
| Gross profit | 336,422 |  |  | 35,908 |  |  | 372,330 |  |  | 278,498 |  |  | 40,139 |  |  | 318,637 |  |
| Gross margin % | 51.3% |  | 27.3% |  | 47.3% |  | 47.4% |  | 31.9% |  | 44.7% |
| Operating expenses | 188,303 |  |  | 41,430 |  |  | 229,733 |  |  | 184,857 |  |  | 41,735 |  |  | 226,592 |  |
| Income (loss) from segment operations | $ | 148,119 |  |  | $ | (5,522 | ) |  | $ | 142,597 |  |  | $ | 93,641 |  |  | $ | (1,596 | ) |  | $ | 92,045 |  |
| Operating margin % | 22.6% |  | (4.2)% |  | 18.1% |  | 16.0% |  | (1.3)% |  | 12.9% |
| Corporate costs |  |  |  |  | 98,205 |  |  |  |  |  |  | 80,900 |  |
| Income from operations |  |  |  |  | $ | 44,392 |  |  |  |  |  |  | $ | 11,145 |  |

[0000926326-19-000003:8k_2_02:125]
| (a) | As adjusted for full retrospective adoption of ASC 606. |

[0000926326-19-000003:8k_2_02:126]
Omnicell, Inc.

[0000926326-19-000003:8k_2_02:127]
Segment Information - Non-GAAP Gross Profit and Non-GAAP Operating Margin

[0000926326-19-000003:8k_2_02:128]
(Unaudited, in thousands, except for percentages)

[0000926326-19-000003:8k_2_02:129]
|  | Three Months Ended December 31, 2018 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |
|  | Amount |  | % of GAAP Revenue |  | % of Non-GAAP Revenue |  | Amount |  | % of GAAP Revenue |  | % of Non-GAAP Revenue |  | Amount |  | % of GAAP Revenue |  | % of Non-GAAP Revenue |
| Revenues | $ | 177,605 |  |  |  |  |  |  | $ | 34,145 |  |  |  |  |  |  | $ | 211,750 |  |  |  |  |  |
| Non-GAAP Revenues | $ | 177,605 |  |  |  |  |  |  | $ | 34,145 |  |  |  |  |  |  | $ | 211,750 |  |  |  |  |  |
| GAAP Gross profit | $ | 92,448 |  |  | 52.1 | % |  |  |  | $ | 9,735 |  |  | 28.5 | % |  |  |  | $ | 102,183 |  |  | 48.3 | % |  |  |
| Share-based compensation expense | 1,098 |  |  | 0.6 | % |  | 0.6 | % |  | 191 |  |  | 0.6 | % |  | 0.6 | % |  | 1,289 |  |  | 0.6 | % |  | 0.6 | % |
| Amortization expense of acquired intangible assets | 2,603 |  |  | 1.5 | % |  | 1.5 | % |  | 488 |  |  | 1.4 | % |  | 1.4 | % |  | 3,091 |  |  | 1.5 | % |  | 1.5 | % |
| Severance and other expenses | 3 |  |  | — | % |  | — | % |  | 183 |  |  | 0.5 | % |  | 0.5 | % |  | 186 |  |  | 0.1 | % |  | 0.1 | % |
| Non-GAAP Gross profit | $ | 96,152 |  |  |  |  | 54.1 | % |  | $ | 10,597 |  |  |  |  | 31.0 | % |  | $ | 106,749 |  |  |  |  | 50.4 | % |
| GAAP Operating income | $ | 46,717 |  |  | 26.3 | % |  |  |  | $ | (576 | ) |  | (1.7 | )% |  |  |  | $ | 46,141 |  |  | 21.8 | % |  |  |
| Share-based compensation expense | 3,573 |  |  | 2.0 | % |  | 2.0 | % |  | 644 |  |  | 1.9 | % |  | 1.9 | % |  | 4,217 |  |  | 2.0 | % |  | 2.0 | % |
| Amortization expense of acquired intangible assets | 4,438 |  |  | 2.5 | % |  | 2.5 | % |  | 1,590 |  |  | 4.7 | % |  | 4.7 | % |  | 6,028 |  |  | 2.8 | % |  | 2.8 | % |
| Severance and other expenses | 330 |  |  | 0.2 | % |  | 0.2 | % |  | 213 |  |  | 0.6 | % |  | 0.6 | % |  | 543 |  |  | 0.3 | % |  | 0.3 | % |
| Non-GAAP Operating income | $ | 55,058 |  |  |  |  | 31.0 | % |  | $ | 1,871 |  |  |  |  | 5.5 | % |  | $ | 56,929 |  |  |  |  | 26.9 | % |
| GAAP Corporate costs |  |  |  |  |  |  |  |  |  |  |  |  | $ | 27,211 |  |  | 12.9 | % |  |  |
| Share-based compensation expense |  |  |  |  |  |  |  |  |  |  |  |  | (3,817 | ) |  | (1.8 | )% |  | (1.8 | )% |
| Severance and other expenses |  |  |  |  |  |  |  |  |  |  |  |  | (800 | ) |  | (0.4 | )% |  | (0.4 | )% |
| Non-GAAP Corporate costs |  |  |  |  |  |  |  |  |  |  |  |  | $ | 22,594 |  |  |  |  | 10.7 | % |
| Non-GAAP Income from operations |  |  |  |  |  |  |  |  |  |  |  |  | $ | 34,335 |  |  |  |  | 16.2 | % |

[0000926326-19-000003:8k_2_02:130]
15

[0000926326-19-000003:8k_2_02:131]
Omnicell, Inc.

[0000926326-19-000003:8k_2_02:132]
Segment Information - Non-GAAP Gross Profit and Non-GAAP Operating Margin

[0000926326-19-000003:8k_2_02:133]
(Unaudited, in thousands, except for percentages)

[0000926326-19-000003:8k_2_02:134]
|  | Three Months Ended December 31, 2017 |
|  | Automation andAnalytics (a) |  | MedicationAdherence |  | Total |
|  | Amount |  | % of GAAP Revenue |  | % of Non-GAAP Revenue |  | Amount |  | % of GAAP Revenue |  | % of Non-GAAP Revenue |  | Amount |  | % of GAAP Revenue |  | % of Non-GAAP Revenue |
| Revenues | $ | 161,569 |  |  |  |  |  |  | $ | 34,802 |  |  |  |  |  |  | $ | 196,371 |  |  |  |  |  |
| Acquisition accounting impact related to deferred revenue | — |  |  |  |  |  |  | 313 |  |  |  |  |  |  | 313 |  |  |  |  |  |
| Non-GAAP Revenues | $ | 161,569 |  |  |  |  |  |  | $ | 35,115 |  |  |  |  |  |  | $ | 196,684 |  |  |  |  |  |
| GAAP Gross profit | $ | 82,344 |  |  | 51.0 | % |  |  |  | $ | 11,151 |  |  | 32.0 | % |  |  |  | $ | 93,495 |  |  | 47.6 | % |  |  |
| Share-based compensation expense | 704 |  |  | 0.4 | % |  | 0.4 | % |  | 130 |  |  | 0.4 | % |  | 0.4 | % |  | 834 |  |  | 0.4 | % |  | 0.4 | % |
| Amortization expense of acquired intangible assets | 2,251 |  |  | 1.4 | % |  | 1.4 | % |  | 567 |  |  | 1.6 | % |  | 1.6 | % |  | 2,818 |  |  | 1.4 | % |  | 1.4 | % |
| Acquisition accounting impact related to deferred revenue | — |  |  | — | % |  | — | % |  | 313 |  |  | 0.9 | % |  | 0.9 | % |  | 313 |  |  | 0.2 | % |  | 0.2 | % |
| Severance and other expenses | 234 |  |  | 0.1 | % |  | 0.1 | % |  | — |  |  | — | % |  | — | % |  | 234 |  |  | 0.1 | % |  | 0.1 | % |
| Non-GAAP Gross profit | $ | 85,533 |  |  |  |  | 52.9 | % |  | $ | 12,161 |  |  |  |  | 34.6 | % |  | $ | 97,694 |  |  |  |  | 49.7 | % |
| GAAP Operating income | $ | 37,389 |  |  | 23.1 | % |  |  |  | $ | 612 |  |  | 1.8 | % |  |  |  | $ | 38,001 |  |  | 19.4 | % |  |  |
| Share-based compensation expense | 2,184 |  |  | 1.4 | % |  | 1.4 | % |  | 376 |  |  | 1.1 | % |  | 1.1 | % |  | 2,560 |  |  | 1.3 | % |  | 1.3 | % |
| Amortization expense of acquired intangible assets | 4,364 |  |  | 2.7 | % |  | 2.7 | % |  | 1,802 |  |  | 5.2 | % |  | 5.1 | % |  | 6,166 |  |  | 3.1 | % |  | 3.1 | % |
| Acquisition accounting impact related to deferred revenue | — |  |  | — | % |  | — | % |  | 313 |  |  | 0.9 | % |  | 0.9 | % |  | 313 |  |  | 0.2 | % |  | 0.2 | % |
| Severance and other expenses | 204 |  |  | 0.1 | % |  | 0.1 | % |  | — |  |  | — | % |  | — | % |  | 204 |  |  | 0.1 | % |  | 0.1 | % |
| Non-GAAP Operating income | $ | 44,141 |  |  |  |  | 27.3 | % |  | $ | 3,103 |  |  |  |  | 8.8 | % |  | $ | 47,244 |  |  |  |  | 24.0 | % |
| GAAP Corporate costs |  |  |  |  |  |  |  |  |  |  |  |  | $ | 21,800 |  |  | 11.1 | % |  |  |
| Share-based compensation expense |  |  |  |  |  |  |  |  |  |  |  |  | (2,982 | ) |  | (1.5 | )% |  | (1.5 | )% |
| Acquisition-related expenses |  |  |  |  |  |  |  |  |  |  |  |  | (263 | ) |  | (0.1 | )% |  | (0.1 | )% |
| Non-GAAP Corporate costs |  |  |  |  |  |  |  |  |  |  |  |  | $ | 18,555 |  |  |  |  | 9.4 | % |
| Non-GAAP Income from operations |  |  |  |  |  |  |  |  |  |  |  |  | $ | 28,689 |  |  |  |  | 14.6 | % |

[0000926326-19-000003:8k_2_02:135]
| (a) | As adjusted for full retrospective adoption of ASC 606. |
