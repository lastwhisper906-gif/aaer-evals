# OMCL MD&A — 0000926326-19-000007


## mdna

[0000926326-19-000007:mdna:1]
| ITEM 7. | MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |

[0000926326-19-000007:mdna:2]
The following discussion and analysis should be read in conjunction with our Consolidated Financial Statements and related notes in this annual report. This discussion may contain forward-looking statements based upon current expectations that involve risks and uncertainties. Our actual results and the timing of selected events could differ materially from those anticipated in these forward-looking statements as a result of several factors, including those set forth under Item 1A “Risk

[0000926326-19-000007:mdna:3]
Factors” and elsewhere in this annual report. Unless otherwise stated, references in this report to particular years or quarters refer to our fiscal year and the associated quarters of those fiscal years.

[0000926326-19-000007:mdna:4]
OVERVIEW

[0000926326-19-000007:mdna:5]
Our Business

[0000926326-19-000007:mdna:6]
We are a leading provider of medication and supply dispensing automation, central pharmacy automation, analytics software, and medication adherence solutions. As we build on our vision of the Autonomous Pharmacy - a more fully automated and digitized system of medication management - we believe we will further help enable healthcare providers to improve patient safety, increase efficiency, lower costs, tighten regulatory compliance and address population health challenges.

[0000926326-19-000007:mdna:7]
In 2018, we managed our business as two operating segments, Automation and Analytics and Medication Adherence:

[0000926326-19-000007:mdna:8]
| • | Automation and Analytics. The Automation and Analytics segment is organized around the design, manufacturing, selling and servicing of medication and supply dispensing systems, pharmacy inventory management systems and related software and services. Our Automation and Analytics products are designed to enable our customers to improve the effectiveness of the medication-use process and the efficiency of the medical-surgical supply chain, and contribute to better patient care and financial outcomes of medical facilities. The products in this segment are primarily sold to acute care (hospital) facilities. |

[0000926326-19-000007:mdna:9]
| • | Medication Adherence. The Medication Adherence segment primarily includes the development, manufacturing and selling of solutions to assist patients in becoming and remaining adherent to their medication regimens. These solutions comprise a variety of tools and aids that may be directly used by a pharmacist or a healthcare provider in their direct care for a patient, or used by patients themselves. Products include software-based systems, medication adherence packaging, equipment for fulfilling the packaging and ancillary products and services. These products, which are sold under the brand names SureMed® and Omnicell, are used to manage medication administration outside of the hospital setting. |

[0000926326-19-000007:mdna:10]
For further description of our operating segments, please refer to Note 14, Segment and Geographical Information, of the Notes to Consolidated Financial Statements in this annual report.

[0000926326-19-000007:mdna:11]
We sell our product and consumable solutions together with related service offerings. Revenue generated in the United States represented 87% of our total revenues in 2018. We have not sold in the past, and have no future plans to sell our products either directly or indirectly, to customers located in countries that are identified as state sponsors of terrorism by the U.S. Department of State, or those subject to economic sanctions and export controls.

[0000926326-19-000007:mdna:12]
Strategy

[0000926326-19-000007:mdna:13]
The healthcare market is experiencing a period of substantive change. In recent years, healthcare providers and facilities have faced increased spending on medication management, rising pharmaceutical costs and substantial increases in healthcare administration.  These factors, combined with continuing consolidation in the healthcare industry, have increased the need for the efficient delivery of healthcare in order to control costs and improve patient safety, and have elevated the strategic importance of medication management across the continuum of care. Furthermore, the adoption of electronic healthcare records, new regulatory constraints, and changes in the reimbursement structure have caused healthcare institutions to re-examine their operating structures, re-prioritize their investments, and seek efficiencies. We believe our customers’ evolving operating environment creates challenges for any supplier, but also affords opportunities for suppliers that are able to partner with customers to help them meet the changing demands. We have and intend to continue to invest in the strategies which we believe have generated and will continue to generate our revenue and earnings growth, while supporting our customers’ initiatives and needs. These strategies include:

[0000926326-19-000007:mdna:14]
| • | Development of a differentiated platform. We intend to continue our focus on further penetrating existing markets through technological leadership and our differentiated platform by consistently innovating our product and service offerings and maintaining our customer-oriented product installation process. We have developed numerous technologies that solve significant challenges for our customers. For example, our XR2 Automated Central Pharmacy System is designed to allow pharmacies to more fully automate medication dispensing, and help to reduce labor cost, decrease medication waste, and improve patient safety; our IVX Workflow solution is designed to reduce medication compounding errors compared to manual compounding methods; and our Performance Center offering leverages predictive analytics to help pharmacies be more proactive in addressing drug shortages. |

[0000926326-19-000007:mdna:15]
| • | Deliver our solutions to new markets. We seek to increase penetration of new markets, such as non-acute care and international markets by: launching new products and technologies that are specific to the needs of those markets; building and establishing direct sales, distribution or other capabilities when and where it is appropriate; partnering with companies that have sales, distribution, or other capabilities that we do not possess; and increasing customer awareness of safety issues in the administration of medications. Consistent with this strategy, we have made investments in expanding our sales team and marketing to new customers. Our international efforts have focused primarily on two markets: Western Europe and the Middle East. We have also expanded our sales efforts to medication adherence customers in the United States. |

[0000926326-19-000007:mdna:16]
| • | Expansion of our solutions through acquisitions and partnerships. We believe that expansion of our product lines through acquisitions and partnerships to meet our customers’ changing and evolving expectations is a key component to our historical and future success. Building on the successful acquisitions of the past few years, we intend to continue to explore acquisition and partnership opportunities that are a strategic fit for our business, including in support of our Autonomous Pharmacy vision described above. We have also developed relationships with major providers of hospital information management systems with the goal of enhancing the interoperability of our products with their systems. |

[0000926326-19-000007:mdna:17]
Among other financial measures, we utilize product bookings to assess the current success of our strategies. Product bookings consist of all firm orders, as evidenced generally by a non-cancellable contract and purchase order for equipment and software, and by a purchase order for consumables. Equipment and software bookings are generally installable within twelve months and, other than subscription services based sales, generally recorded as revenue upon customer acceptance of the installation. Consumables are recorded as revenue upon shipment to a customer or receipt by the customer, depending upon contract terms. Consumable bookings are generally recorded as revenue within one month. Product bookings increased by 26%, from $568 million in 2017 to $716 million in 2018, driven by the success of our growth strategies in differentiated products, new markets and, by the contributions from our acquisitions of Aesynt, Ateb, and InPharmics.

[0000926326-19-000007:mdna:18]
In addition to product solution sales, we provide services to our customers. We provide installation planning and consulting as part of every product sale which is included in the initial price of the solution. To help assure the maximum availability of our systems, our customers typically purchase maintenance and support contracts in increments of one to five years. As a result of the growth of our installed base of customers, our service revenues have also grown.

[0000926326-19-000007:mdna:19]
The growth in the Medication Adherence revenue was primarily driven by further market penetration and adoption of our automated and semi-automated packaging equipment within the United States and Europe, Middle East and Africa, as well as modest price increases across the product lines.

[0000926326-19-000007:mdna:20]
In the future, we expect our strategies to evolve as the business environment of our customers evolves, but for our focus to remain on improving outcomes for healthcare providers and patients. We expect our investment in differentiated products, new markets, and acquisitions and partnerships to continue.

[0000926326-19-000007:mdna:21]
In fiscal year 2017, we created Centers of Excellence (“COE”) for product development, engineering and manufacturing with the Point of Use COE located at our facilities in California, the Robotics and Central Pharmacy COE located at our facilities near Pittsburgh, Pennsylvania, and the Medication Adherence Consumables COE located at our facilities in St. Petersburg, Florida. As part of this initiative, we reduced our workforce in the first half of 2017 by approximately 100 full-time employees, or about 4% of the total headcount, and closed our Nashville, Tennessee, and Slovenia facilities.

[0000926326-19-000007:mdna:22]
Our full-time headcount of approximately 2,480 on December 31, 2018, an increase of approximately 130 from December 31, 2017, reflects our efforts to drive profitability and optimize resources allocation.

[0000926326-19-000007:mdna:23]
2017 Acquisitions

[0000926326-19-000007:mdna:24]
On April 12, 2017, we completed the acquisition of InPharmics, a technology and services company that provides advanced pharmacy informatics solutions to hospital pharmacies. The purchase price consideration was $5.0 million, net of cash acquired of $0.3 million. The results of InPharmics’ operations have been included in our consolidated results of operations beginning April 13, 2017, and presented as part of the Automation and Analytics segment.

[0000926326-19-000007:mdna:25]
2016 Acquisitions

[0000926326-19-000007:mdna:26]
On January 5, 2016, we completed the acquisition of all of the membership interests of Aesynt. Aesynt is a provider of automated medication management systems, including dispensing robots with storage solutions, medication storage and dispensing carts and cabinets, I.V. sterile preparation robotics and software, including software related to medication management. The purchase price consideration was $271.5 million net of cash acquired of $8.2 million. The results of Aesynt’s

[0000926326-19-000007:mdna:27]
operations have been included in our consolidated results of operations since January 6, 2016, and presented as part of the Automation and Analytics segment.

[0000926326-19-000007:mdna:28]
On December 8, 2016, we completed our acquisition of Ateb, Inc., and Ateb Canada Ltd. (together, “Ateb”). Ateb is a provider of pharmacy-based patient care and medication synchronization solutions to independent and chain pharmacies. The purchase price consideration was $40.7 million, net of cash acquired of $0.9 million. The results of Ateb’s operations have been included in our consolidated results of operations beginning December 9, 2016, and presented as part of the Medication Adherence segment.

[0000926326-19-000007:mdna:29]
CRITICAL ACCOUNTING POLICIES AND ESTIMATES

[0000926326-19-000007:mdna:30]
Our discussion and analysis of our financial condition and results of operations are based on our Consolidated Financial Statements, which have been prepared in accordance with United States Generally Accepted Accounting Principles (“U.S. GAAP”). The preparation of these financial statements requires us to make certain estimates and assumptions that affect the reported amounts of assets and liabilities, disclosure of any contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. We regularly review our estimates and assumptions, which are based on historical experience and various other factors that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of certain assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates and assumptions. We believe the following critical accounting policies are affected by significant judgments and estimates used in the preparation of our Consolidated Financial Statements:

[0000926326-19-000007:mdna:31]
Revenue Recognition

[0000926326-19-000007:mdna:32]
We earn revenues from sales of our medication and supply dispensing automation systems, along with consumables and related services, which are sold in the healthcare industry, our principal market. The transaction price of each contract with a customer is allocated to the identified performance obligations based on the relative fair value of each obligation. Our customer arrangements typically include one or more of the following performance obligations:

[0000926326-19-000007:mdna:33]
Products. Software-enabled equipment that manages and regulates the storage and dispensing of pharmaceuticals, consumable blister cards and packaging equipment and other medical supplies.

[0000926326-19-000007:mdna:34]
Software. Additional software applications that enable incremental functionality of our equipment or services.

[0000926326-19-000007:mdna:35]
Installation. Installation of equipment as integrated systems at customer sites.

[0000926326-19-000007:mdna:36]
Post-installation technical support. Phone support, on-site service, parts, and access to unspecified software updates and enhancements, if and when available.

[0000926326-19-000007:mdna:37]
Professional services. Other customer services, such as training and consulting.

[0000926326-19-000007:mdna:38]
Prior to recognizing revenue, we identify the contract, performance obligations, and transaction price, and allocate the transaction price to the performance obligations. All identified contracts meet the following required criteria:

[0000926326-19-000007:mdna:39]
Parties to the contract have approved the contract (in writing, orally, or in accordance with other customary business practices) and are committed to perform their respective obligations. A majority of our contracts are evidenced by a non-cancelable written agreement. Contracts for consumable products are generally evidenced by an order placed via phone or a manual purchase order.

[0000926326-19-000007:mdna:40]
Entity can identify each party’s rights regarding the goods or services to be transferred. Contract terms are documented within the written agreements. Where a written contract does not exist, such as for consumable products, the rights of each party are understood as following our standard business process and terms.

[0000926326-19-000007:mdna:41]
The entity can identify the payment terms for the goods or services to be transferred. Payment terms are documented within the agreement and are generally net 30 days from shipment of tangible product or services performed. Where a written contract does not exist, our standard payment terms are net 30 day terms.

[0000926326-19-000007:mdna:42]
The contract has commercial substance (that is the risk, timing, or amount of the entity’s future cash flows is expected to change as a result of the contract.) Our agreements are an exchange of cash for a combination of products and services which result in changes in the amount of our future cash flows.

[0000926326-19-000007:mdna:43]
It is probable the entity will collect the consideration to which it will be entitled in exchange for the goods or services that will be transferred to the customer. We perform a credit check for all significant customers or transactions and

[0000926326-19-000007:mdna:44]
where collectability is not probable, payment in full or a substantial down payment is typically required to help assure the full agreed upon contract price will be collected.

[0000926326-19-000007:mdna:45]
We often enter into change orders which modify the product to be received by the customer pursuant to certain contracts. Changes to any contract are accounted for as a modification of the existing contract to the extent the goods and services to be delivered as part of the contract are generally consistent with the nature and type of those to be provided under the terms of the original contract. Examples of such change orders include the addition or removal of units of equipment or changes to the configuration of the equipment where the overall nature of the contract remains intact. Our change orders generally result in the change being accounted for as modifications of existing contracts given the nature of the impacted orders.

[0000926326-19-000007:mdna:46]
Distinct goods or services are identified as performance obligations. A series of distinct goods or services that are substantially the same and that have the same pattern of transfer to the customer are considered a single performance obligation. Where a good or service is determined not to be distinct, we combine the good or service with other promised goods or services until a bundle of goods or services that is distinct is identified. To identify our performance obligations, we consider all of the products or services promised in the contract regardless of whether they are explicitly stated or are implied by customary business practices. When performance obligations are included in separate contracts, we consider an entire customer arrangement to determine if separate contracts should be considered combined for the purposes of revenue recognition. Most of our sales, other than renewals of support and maintenance, contain multiple performance obligations, with a combination of hardware systems, consumables and software products, support and maintenance, and professional services.

[0000926326-19-000007:mdna:47]
The transaction price of a contract is determined based on the fixed consideration, net of an estimate for variable consideration such as various discounts or rebates provided to customers. As a result of our commercial selling practices, contract prices are generally fixed with minimal, if any, variable consideration.

[0000926326-19-000007:mdna:48]
The transaction price is allocated to separate performance obligations proportionally based on the standalone selling price of each performance obligation. Standalone selling price is best evidenced by the price we charge for the good or service when selling it separately in similar circumstances to similar customers. Other than for the renewal of annual support services contracts, our products and services are not generally sold separately. We use an amount discounted from the list price as a best estimated selling price.

[0000926326-19-000007:mdna:49]
We recognize revenue when the performance obligation has been satisfied by transferring a promised good or service to a customer. The good or service is transferred when or as the customer obtains control of the good or service. Determining when control transfers requires management to make judgments that affect the timing of revenues recognized. Generally, for products requiring a complex implementation, control passes when the product is installed and ready for use. For all other products, control generally passes when product has been shipped and title has passed. For maintenance contracts and certain other services provided on a subscription basis, control passes to the customer over time, generally ratably over the service term as we provide a stand-ready service to service the customer’s equipment. Time and material services transfer control to the customer at the time the services are provided. The portion of the transaction price allocated to our unsatisfied performance obligations are recorded as deferred revenues.

[0000926326-19-000007:mdna:50]
Revenues, contract assets, and contract liabilities are recorded net of associated taxes.

[0000926326-19-000007:mdna:51]
The payment terms associated with our contracts vary, however, payment terms for product revenues are generally based on milestones tied to contract signing, shipment of products, and/or customer acceptance. Payment terms associated with the service portion of agreements are generally periodic and can be billed on a monthly, quarterly, or annual basis. In certain circumstances multiple years are billed at one time. The portion of these contract liabilities not expected to be recognized as revenue within twelve months of the balance sheet date are considered long term.

[0000926326-19-000007:mdna:52]
In the normal course of business, we typically do not accept product returns unless the item is defective as manufactured or the configuration of the product is incorrect. We establish provisions for estimated returns based on historical product returns. The allowance for sales returns is not material to our Consolidated Financial Statements for any periods presented.

[0000926326-19-000007:mdna:53]
A portion of our sales are made through multi-year lease agreements. Under sales-type leases, we recognize revenue for our hardware and software products net of lease execution costs, such as post-installation product maintenance and technical support, at the net present value of the lease payment stream once our installation obligations have been met. We optimize cash flows by selling a majority of our non-U.S. government leases to third-party leasing finance companies on a non-recourse basis. We have no obligation to the leasing company once the lease has been sold. Some of our sales-type leases, mostly those relating to U.S. government hospitals which comprise approximately 49% of the lease receivable balance, are retained in-house. Interest income in these leases is recognized in product revenues using the effective interest method.

[0000926326-19-000007:mdna:54]
Contract Assets and Contract Liabilities

[0000926326-19-000007:mdna:55]
A contract asset is a right to consideration in exchange for goods or services that we have transferred to a customer when that right is conditional and is not just subject to the passage of time. A receivable will be recorded on the balance sheet when we have unconditional rights to consideration. A contract liability is an obligation to transfer goods or services for which we have received consideration, or for which an amount of consideration is due from the customer. Contract liabilities include customer deposits under non-cancelable contracts, and current and non-current deferred revenue balances. Our contract balances are reported in a net contract asset or liability position on a contract-by-contract basis at the end of each reporting period.

[0000926326-19-000007:mdna:56]
Contract Costs

[0000926326-19-000007:mdna:57]
We have determined that the incentive portions of our sales commission plans require capitalization since these payments are directly related to sales achieved during a time period. These commissions are earned on the basis of the total purchase order value of new product bookings. Since there are not commensurate commissions earned on renewal of the service bookings, we concluded that the capitalized asset is related to services provided under both the initial contract and renewal periods. We apply a practical expedient to account for the incremental costs of obtaining a contract as part of a portfolio of contracts with similar characteristics as we expect the effect on the financial statements of applying the practical expedient would not differ materially from applying the accounting guidance to the individual contracts within the portfolio. A pool of contracts is defined as all contracts booked in a particular quarter. The amortization for the capitalized asset is an estimate of the pool’s original contract term, generally one to five years, plus an estimate of future customer renewal periods resulting in a total amortization period of ten years. Costs to obtain a contract are allocated amongst performance obligations and recognized as sales and marketing expense consistent with the pattern of revenue recognition. Capitalized costs are periodically reviewed for impairment. A portion of the pool’s capitalized asset is recorded as an expense over the first two quarters after booking, which represents the estimated period during which the product revenue associated with the contract is recorded. The remaining contract cost is recorded as expense ratably over the ten year estimated initial and renewal service periods. The commission expenses paid as of the consolidated balance sheet date to be recognized in future periods are recorded in long-term prepaid commissions on the Consolidated Balance Sheets.

[0000926326-19-000007:mdna:58]
Allowance for Doubtful Accounts and Notes Receivables from Investment in Sales-Type Leases

[0000926326-19-000007:mdna:59]
We maintain an allowance for doubtful accounts for estimated losses resulting from the inability of our customers to make required payments. We record a specific allowance based on an analysis of individual past-due balances. Additionally, based on historical write-offs and our collection experience, we record an additional allowance based on a percentage of outstanding receivables. We perform credit evaluations of our customers’ financial condition. These evaluations require significant judgment and are based on a variety of factors including, but not limited to, current economic trends, payment history and a financial review of the customer. Actual collection losses may differ from management’s estimates, and such differences could be material to our financial position and results of operations.

[0000926326-19-000007:mdna:60]
The retained in-house leases discussed above are considered financing receivables. Our credit policies and our evaluation of credit risk and write-off policies are applied alike to trade receivables and the net investment in sales-type leases. For both, an account is generally past due after thirty days. The financing receivables also have customer-specific reserves for accounts identified for specific impairment and a non-specific reserve applied to the remaining population, based on factors such as current trends, the length of time the receivables are past due and historical collection experience. The retained in-house leases are not stratified by portfolio or class.

[0000926326-19-000007:mdna:61]
Inventory

[0000926326-19-000007:mdna:62]
Inventories are stated at the lower of cost, computed using the first-in, first-out method, and net realizable value. Inbound shipping costs are included in cost of inventory. We regularly monitor inventory quantities on hand and record write-downs for excess and obsolete inventories based on our estimate of demand for our products, potential obsolescence of technology, product life cycles, and whether pricing trends or forecasts indicate that the carrying value of inventory exceeds its estimated selling price. These factors are impacted by market and economic conditions, technology changes, and new product introductions and require estimates that may include elements that are uncertain. Actual demand may differ from forecasted demand and may have a material effect on gross margins. If inventory is written down, a new cost basis is established that cannot be increased in future periods. Shipments from suppliers or contract manufacturers before we receive them are recorded as in-transit inventory when title and the significant risks and rewards of ownership have passed to us.

[0000926326-19-000007:mdna:63]
Software Development Costs

[0000926326-19-000007:mdna:64]
We capitalize software development costs in accordance with Accounting Standards Codification (“ASC”) 985-20, Costs of Software to Be Sold, Leased, or Marketed, under which certain software development costs incurred subsequent to the

[0000926326-19-000007:mdna:65]
establishment of technological feasibility may be capitalized and amortized over the estimated lives of the related products. We establish feasibility when we complete a working model and amortize development costs over the estimated lives of the related products ranging from three to five years. All development costs prior to the completion of a working model are recognized as research and development expense.

[0000926326-19-000007:mdna:66]
Business Combinations

[0000926326-19-000007:mdna:67]
We use the acquisition method of accounting under the authoritative guidance on business combinations. Each acquired company’s operating results are included in our Consolidated Financial Statements starting on the date of acquisition. The purchase price is equivalent to the fair value of consideration transferred. Tangible and identifiable intangible assets acquired and liabilities assumed as of the date of acquisition are recorded at the acquisition date fair value. Goodwill is recognized for the excess of purchase price over the net fair value of assets acquired and liabilities assumed.

[0000926326-19-000007:mdna:68]
Amounts allocated to assets and liabilities are based upon fair values. Such valuations require management to make significant estimates and assumptions, especially with respect to the identifiable intangible assets. Management makes estimates of fair value based upon assumptions believed to be reasonable and that of a market participant. These estimates are based on historical experience and information obtained from the management of the acquired companies and the estimates are inherently uncertain. The separately identifiable intangible assets generally include customer relationships, technology, and trade names.

[0000926326-19-000007:mdna:69]
Goodwill and Acquired Intangible Assets

[0000926326-19-000007:mdna:70]
Goodwill. We review goodwill for impairment on an annual basis on the first day of the fourth quarter of each year at the reporting unit level. This assessment is also performed whenever there is a change in circumstances that indicates the carrying value of goodwill may be impaired. Our reporting units are the same as our operating segments, which are Automation and Analytics and Medication Adherence. A qualitative assessment is initially made to determine whether it is necessary to perform quantitative testing. A qualitative assessment includes, among others, consideration of: (i) past, current and projected future earnings and equity; (ii) recent trends and market conditions; and (iii) valuation metrics involving similar companies that are publicly-traded and acquisitions of similar companies, if available. If this qualitative assessment indicates that it is more likely than not that impairment exists, or if we decide to bypass this option, we proceed to the quantitative assessment. The quantitative assessment involves a comparison between the estimated fair values of our reporting units with their respective carrying amounts including goodwill. If the carrying value exceeds estimated fair value, we will record an impairment charge based on that difference. The impairment charge will be limited to the amount of goodwill allocated to that reporting unit.

[0000926326-19-000007:mdna:71]
To determine each reporting unit’s fair value under the quantitative approach, we use a combination of income and market approaches, equally weighting the two approaches, such as estimated discounted future cash flows of that reporting unit, multiples of earnings or revenues, and analysis of recent sales or offerings of comparable entities. We also consider our market capitalization on the date of the analysis to ensure the reasonableness of the sum of its reporting units’ fair value.

[0000926326-19-000007:mdna:72]
We performed a quantitative impairment analysis as of October 1, 2018 for our Medication Adherence reporting unit. We determined that the fair value of this reporting unit exceeded the carrying value by more than 41%, and thus no impairment was indicated. Additionally, we performed a qualitative impairment assessment analysis as of October 1, 2018 for our Automation and Analytics reporting unit taking into consideration past, current and projected future earnings, recent trends and market conditions; and valuation metrics involving similar companies that are publicly-traded. Based on the result of this analysis, the fair value of this reporting unit exceeded the carrying value, and thus no impairment was indicated.

[0000926326-19-000007:mdna:73]
Intangible assets. In connection with our acquisitions, we generally recognize assets for customer relationships, backlog, developed technology, and trade names. Intangible assets are carried at cost less accumulated amortization. Such amortization is provided on a straight-line basis or on an accelerated basis based on a pattern of economic benefit that is expected to be obtained over the estimated useful lives of the respective assets, generally from one to 30 years. Amortization for developed technology and backlog is recognized in cost of revenues, and amortization for customer relationships, non-compete agreements, and trade names is recognized in selling, general, and administrative expenses.

[0000926326-19-000007:mdna:74]
We assess the impairment of identifiable intangible assets whenever events or changes in circumstances indicate that an asset’s carrying amount may not be recoverable. Recoverability of an asset is measured by the comparison of the carrying amount to the sum of the undiscounted estimated future cash flows the asset is expected to generate, offset by estimated future costs to dispose of the product to which the asset relates. If an asset is considered to be impaired, the amount of such impairment would be measured as the difference between the carrying amount of the asset and its fair value. Our cash flow assumptions are based on historical and forecasted future revenue, operating costs, and other relevant factors. Assumptions and estimates about the remaining useful lives of our intangible assets are subjective and are affected by changes to our business strategies. If management’s estimates of future operating results change, or if there are changes to other assumptions, the

[0000926326-19-000007:mdna:75]
estimate of the fair value of our assets could change significantly. Such change could result in impairment charges in future periods, which could have a significant impact on our operating results and financial condition.

[0000926326-19-000007:mdna:76]
Valuation of Share-Based Compensation

[0000926326-19-000007:mdna:77]
We account for share-based compensation in accordance with ASC 718, Stock Compensation. We recognize compensation expense related to share-based compensation based on the grant date estimated fair value.

[0000926326-19-000007:mdna:78]
The fair value of stock options (“options”) on the grant date is estimated using the Black-Scholes option pricing model, which requires the following inputs: expected life, expected volatility, risk-free interest rate, expected dividend yield rate, exercise price, and closing price of its common stock on the date of grant. The expected volatility is based on a combination of historical and market-based implied volatility, and the expected life of the awards is based on our historical experience of employee stock option exercises, including forfeitures. Expense is recognized on a straight-line basis over the requisite service period.

[0000926326-19-000007:mdna:79]
The fair value of restricted stock units (“RSUs”) is based on the stock price on the grant date. The fair value of restricted stock awards (“RSAs”) is their intrinsic value, which is the difference between the fair value of the underlying stock at the measurement date and the purchase price. The RSUs and RSAs are subject to a service vesting condition and are recognized on a straight-line basis over the requisite service period.

[0000926326-19-000007:mdna:80]
The fair value of performance-based stock unit awards (“PSUs”) with service and market conditions is estimated using a Monte Carlo simulation model applying multiple awards approach. Expense is recognized when it is probable that the performance condition will be met using the accelerated attribution method over the requisite service period.

[0000926326-19-000007:mdna:81]
The valuation assumptions used in estimating the fair value of employee share-based awards may change in future periods.

[0000926326-19-000007:mdna:82]
Accounting for Income Taxes

[0000926326-19-000007:mdna:83]
We record an income tax provision for (benefit from) the anticipated tax consequences of the reported results of operations. In accordance with U.S.GAAP, the provision for (benefit from) income taxes is computed using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been included in the financial statements. Under this method, deferred tax assets and liabilities are determined on the basis of the differences between the financial statement and tax bases of assets and liabilities, and for operating losses and tax credit carryforwards. Deferred tax assets and liabilities are measured using the enacted tax rates in effect for the periods in which those tax assets and liabilities are expected to be realized or settled. In the event that these tax rates change, we will incur a benefit or detriment on our income tax expense in the period of change. If we were to determine that all or part of the net deferred tax assets are not realizable in the future, we will record a valuation allowance that would be charged to earnings in the period such determination is made.

[0000926326-19-000007:mdna:84]
In accordance with ASC 740, Income Taxes, we recognize the tax benefit from an uncertain tax position if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement. The calculation of tax liabilities involves significant judgment in estimating the impact of uncertainties in the application of U.S. GAAP and complex tax laws. Resolution of these uncertainties in a manner inconsistent with management’s expectations could have a material impact on our financial condition and operating results.

[0000926326-19-000007:mdna:85]
Recently Issued Authoritative Guidance

[0000926326-19-000007:mdna:86]
Refer to Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to Consolidated Financial Statements in this annual report for a description of recently issued accounting pronouncements, including the expected dates of adoption and estimated effects on our results of operations, financial position and cash flows.

[0000926326-19-000007:mdna:87]
RESULTS OF OPERATIONS

[0000926326-19-000007:mdna:88]
Total Revenues

[0000926326-19-000007:mdna:89]
|  |  |  | Change in |  |  |  | Change in |  |  |
|  | 2018 |  | $ |  | % |  | 2017 |  | $ |  | % |  | 2016 |
|  | (Dollars in thousands) |
| Product revenues | $ | 569,595 |  |  | $ | 59,394 |  |  | 12% |  | $ | 510,201 |  |  | $ | (17,526 | ) |  | (3)% |  | $ | 527,727 |  |
| Percentage of total revenues | 72% |  |  |  |  |  | 72% |  |  |  |  |  | 76% |
| Service and other revenues | 217,714 |  |  | 15,201 |  |  | 8% |  | 202,513 |  |  | 34,332 |  |  | 20% |  | 168,181 |  |
| Percentage of total revenues | 28% |  |  |  |  |  | 28% |  |  |  |  |  | 24% |
| Total revenues | $ | 787,309 |  |  | $ | 74,595 |  |  | 10% |  | $ | 712,714 |  |  | $ | 16,806 |  |  | 2% |  | $ | 695,908 |  |

[0000926326-19-000007:mdna:90]
2018 compared to 2017

[0000926326-19-000007:mdna:91]
Revenues were $787.3 million for the year ended December 31, 2018 compared to $712.7 million for the year ended December 31, 2017, representing an increase of approximately 10%. The year-over-year revenue increase was primarily attributed to an increase in product revenues of $59.4 million and an increase in service and other revenues of $15.2 million.

[0000926326-19-000007:mdna:92]
Product revenues represented 72% of total revenues for the years ended December 31, 2018 and December 31, 2017. Product revenues increased by $59.4 million due to increased sales of $55.0 million in our Automation and Analytics segment and increased sales of $4.4 million in our Medication Adherence segment. The increase in the Automation and Analytics segment was attributed to an increase in sales of XT series products as the sales for the year ended December 31, 2017 had a slower conversion of bookings and backlog into revenues due to the introduction of the new XT series of products in the fourth quarter of 2016, an increase in sales of Performance Center, and an increase in sales of other products. The increase in the Medication Adherence segment was primarily attributed to higher completed installations of our VBM products compared to the year ended December 31, 2017.

[0000926326-19-000007:mdna:93]
Service and other revenues represented 28% of total revenues for the years ended December 31, 2018 and December 31, 2017. Service and other revenues include revenues from service and maintenance contracts, and rentals of automation systems. The increase in service and other revenues of $15.2 million was attributable to year-over-year increases of $13.8 million and $1.4 million in our Automation and Analytics and Medication Adherence segments, respectively. The increase in revenue growth in our Automation and Analytics segment was a result of higher service renewal fees driven mainly by an increase in our installed customer base. The increase in the Medication Adherence segment was primarily a result of our investing in the acquired Ateb business.

[0000926326-19-000007:mdna:94]
Our international sales represented 13%, 14%, and 15% of total revenues for the years ended December 31, 2018, December 31, 2017, and December 31, 2016, respectively, and are expected to be affected by foreign currency exchange rates fluctuations. The decrease in international revenues as a percentage of our total revenues was primarily related to our acquired companies, Aesynt and Ateb, which have a greater market presence in United States compared to international markets. We are unable to predict the extent to which revenue in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-19-000007:mdna:95]
Our ability to continue to grow revenue is dependent on our ability to continue to obtain orders from customers, our ability to produce quality products and consumables to fulfill customer demand, the volume of installations we are able to complete, our ability to meet customer needs by providing a quality installation experience, and our flexibility in manpower allocations among customers to complete installations on a timely basis. The timing of our product revenues for equipment is primarily dependent on when our customers’ schedules allow for installations.

[0000926326-19-000007:mdna:96]
2017 compared to 2016

[0000926326-19-000007:mdna:97]
Revenues were $712.7 million for the year ended December 31, 2017 compared to $695.9 million for the year ended December 31, 2016, representing an increase of approximately 2%. The year-over-year revenue increase was primarily attributed to an increase in service and other revenues of $34.3 million, offset by a decrease in product revenues of $17.5 million.

[0000926326-19-000007:mdna:98]
Product revenues represented 72% and 76% of total revenues for the years ended December 31, 2017 and December 31, 2016, respectively. Product revenues decreased by $17.5 million due to decreased sales in our Automation and Analytics segment of $26.1 million, offset by increased sales of $8.6 million in our Medication Adherence segment. The decrease in the Automation and Analytics segment was attributed to a slower conversion of bookings and backlog into revenue due to the introduction of the new XT series of products in the fourth quarter of 2016. While we have experienced larger deal sizes, the

[0000926326-19-000007:mdna:99]
administrative process of converting our existing bookings of G4 products into XT series products decreased revenue recognition for the year ended December 31, 2017 compared to the year ended December 31, 2016. The increase in the Medication Adherence segment was partially attributed to Ateb, acquired in the fourth quarter of 2016, which contributed $4.2 million to the increase in the product revenue during the year ended December 31, 2017. The remainder of the increase is primarily attributed to the introduction of the VBM product series in the fourth quarter of 2016.

[0000926326-19-000007:mdna:100]
Service and other revenues represented 28% and 24% of total revenues for the years ended December 31, 2017 and December 31, 2016, respectively. Service and other revenues include revenues from service and maintenance contracts, and rentals of automation systems. The increase in service and other revenues of $34.3 million was attributable to year-over-year increases of $16.1 million and $18.2 million in our Automation and Analytics and Medication Adherence segments, respectively. The increase in revenue growth in our Automation and Analytics segment was a result of higher service renewal fees driven mainly by an increase in installed customer base. The increase in the Medication Adherence segment was primarily attributed to Ateb, which contributed $18.7 million to the increase in the service revenue during the year ended December 31, 2017.

[0000926326-19-000007:mdna:101]
Our ability to continue to grow revenue is dependent on our ability to continue to obtain orders from customers, our ability to produce quality products and consumables to fulfill customer demand, the volume of installations we are able to complete, our ability to meet customer needs by providing a quality installation experience, and our flexibility in manpower allocations among customers to complete installations on a timely basis. The timing of our product revenues for equipment is primarily dependent on when our customers’ schedules allow for installations.

[0000926326-19-000007:mdna:102]
Financial Information by Segment

[0000926326-19-000007:mdna:103]
Revenues

[0000926326-19-000007:mdna:104]
|  |  |  | Change in |  |  |  | Change in |  |  |
|  | 2018 |  | $ |  | % |  | 2017 |  | $ |  | % |  | 2016 |
|  | (Dollars in thousands) |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 655,679 |  |  | $ | 68,738 |  |  | 12% |  | $ | 586,941 |  |  | $ | (9,970 | ) |  | (2)% |  | $ | 596,911 |  |
| Percentage of total revenues | 83% |  |  |  |  |  | 82% |  |  |  |  |  | 86% |
| Medication Adherence | 131,630 |  |  | 5,857 |  |  | 5% |  | 125,773 |  |  | 26,776 |  |  | 27% |  | 98,997 |  |
| Percentage of total revenues | 17% |  |  |  |  |  | 18% |  |  |  |  |  | 14% |
| Total revenues | $ | 787,309 |  |  | $ | 74,595 |  |  | 10% |  | $ | 712,714 |  |  | $ | 16,806 |  |  | 2% |  | $ | 695,908 |  |

[0000926326-19-000007:mdna:105]
2018 compared to 2017

[0000926326-19-000007:mdna:106]
The increase in Automation and Analytics revenues of $68.7 million for the year ended December 31, 2018 as compared to the year ended December 31, 2017 was primarily related to an increase in product revenues of $55.0 million and an increase in service revenue of $13.8 million. The increase in product revenues was attributed to an increase in sales of XT series products as the sales for the year ended December 31, 2017 had a slower conversion of bookings and backlog into revenues due to the introduction of the XT series of products in the fourth quarter of 2016, an increase in sales of Performance Center, and an increase in sales of other product mixes. The increase in service revenues was primarily attributed to higher service renewal fees driven mainly by an increase in our installed customer base.

[0000926326-19-000007:mdna:107]
The increase in Medication Adherence revenues of $5.9 million for the year ended December 31, 2018 as compared to the year ended December 31, 2017 was primarily attributed to increases in product revenues of $4.4 million and service revenues of $1.4 million. The increase in product revenues was primarily attributed to higher completed installations of our VBM products compared to the year ended December 31, 2017. The increase in service revenues was primarily a result of our investing in the acquired Ateb business.

[0000926326-19-000007:mdna:108]
2017 compared to 2016

[0000926326-19-000007:mdna:109]
The decrease in Automation and Analytics revenues of $10.0 million for the year ended December 31, 2017 as compared to the year ended December 31, 2016 was primarily related to a decrease in product revenues of $26.1 million partially offset by an increase in service revenue of $16.1 million. The decrease in revenues in the Automation and Analytics segment was attributed to a slower conversion of bookings and backlog into revenue due to the introduction of the new XT series of products in the fourth quarter of 2016. While we have experienced larger deal sizes, the administrative process of converting our existing bookings of G4 products into XT series products decelerated revenue recognition for the year ended December 31, 2017 compared to the year ended December 31, 2016. The increase in service revenues in the Automation and

[0000926326-19-000007:mdna:110]
Analytics segment was primarily attributed to higher service renewal fees driven mainly by an increase in installed customer base.

[0000926326-19-000007:mdna:111]
The increase in Medication Adherence revenues of $26.8 million for the year ended December 31, 2017 as compared to the year ended December 31, 2016 was primarily attributed to increases in service revenues of $18.2 million and product revenues of $8.6 million. The increase in service revenues was primarily attributed to Ateb, which contributed $18.7 million to the increase during the year ended December 31, 2017. The increase in product revenues was primarily attributed to Ateb, which contributed $4.2 million to the increase, as well as the introduction of the VBM product series in the fourth quarter of 2016.

[0000926326-19-000007:mdna:112]
Cost of Revenues and Gross Profit

[0000926326-19-000007:mdna:113]
Cost of revenues is primarily comprised of three general categories: (i) standard product costs which accounts for the majority of the product cost of revenues that are provided to customers, and are inclusive of purchased material, labor to build the product and overhead costs associated with production; (ii) installation costs as we install our equipment at the customer site and include costs of the field installation personnel, including labor, travel expense, and other expenses; and (iii) other costs, including variances in standard costs and overhead, scrap costs, rework, warranty, provisions for excess and obsolete inventory and amortization of software development costs and intangibles.

[0000926326-19-000007:mdna:114]
|  |  |  | Change in |  |  |  | Change in |  |  |
|  | 2018 |  | $ |  | % |  | 2017 |  | $ |  | % |  | 2016 |
|  | (Dollars in thousands) |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 319,257 |  |  | $ | 10,814 |  |  | 4% |  | $ | 308,443 |  |  | $ | (2,524 | ) |  | (1)% |  | $ | 310,967 |  |
| As a percentage of related revenues | 49% |  |  |  |  |  | 53% |  |  |  |  |  | 52% |
| Medication Adherence | 95,722 |  |  | 10,088 |  |  | 12% |  | 85,634 |  |  | 17,778 |  |  | 26% |  | 67,856 |  |
| As a percentage of related revenues | 73% |  |  |  |  |  | 68% |  |  |  |  |  | 69% |
| Total cost of revenues | $ | 414,979 |  |  | $ | 20,902 |  |  | 5% |  | $ | 394,077 |  |  | $ | 15,254 |  |  | 4% |  | $ | 378,823 |  |
| As a percentage of total revenues | 53% |  |  |  |  |  | 55% |  |  |  |  |  | 54% |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 336,422 |  |  | $ | 57,924 |  |  | 21% |  | $ | 278,498 |  |  | $ | (7,446 | ) |  | (3)% |  | $ | 285,944 |  |
| Automation and Analytics gross margin | 51% |  |  |  |  |  | 47% |  |  |  |  |  | 48% |
| Medication Adherence | 35,908 |  |  | (4,231 | ) |  | (11)% |  | 40,139 |  |  | 8,998 |  |  | 29% |  | 31,141 |  |
| Medication Adherence gross margin | 27% |  |  |  |  |  | 32% |  |  |  |  |  | 31% |
| Total gross profit | $ | 372,330 |  |  | $ | 53,693 |  |  | 17% |  | $ | 318,637 |  |  | $ | 1,552 |  |  | —% |  | $ | 317,085 |  |
| Total gross margin | 47% |  |  |  |  |  | 45% |  |  |  |  |  | 46% |

[0000926326-19-000007:mdna:115]
2018 compared to 2017

[0000926326-19-000007:mdna:116]
Automation and Analytics. Cost of revenues for the year ended December 31, 2018 increased by $10.8 million compared to the year ended December 31, 2017. The increase in cost of revenues is primarily due to the increase in revenues of $68.7 million for the year ended December 31, 2018 compared to the year ended December 31, 2017, partially offset by the efficiencies, economies of scale, and cost savings on the XT series of products, as we ramped up from their introduction in the fourth quarter of 2016, as well as the increase in sales of Performance Center, which have higher gross margins. Our gross profit for the year ended December 31, 2018 was $336.4 million as compared to $278.5 million for the year ended December 31, 2017.

[0000926326-19-000007:mdna:117]
Medication Adherence. Cost of revenues increased by $10.1 million for the year ended December 31, 2018 as compared to the year ended December 31, 2017. The increase in cost of revenues is primarily due to the increase in revenues for the year ended December 31, 2018 compared to the year ended December 31, 2017, and $2.1 million of excess and obsolete reserve for slower moving inventory. Our gross profit for the year ended December 31, 2018 was $35.9 million as compared to $40.1 million for the year ended December 31, 2017.

[0000926326-19-000007:mdna:118]
2017 compared to 2016

[0000926326-19-000007:mdna:119]
Automation and Analytics. Cost of revenues for the year ended December 31, 2017 decreased by $2.5 million compared to the year ended December 31, 2016 primarily due to a decrease in product costs of $9.1 million, partially offset by an increase in service costs of $6.5 million. The decrease in product costs is primarily due to the decrease in product revenues of $26.1 million partially offset by costs attributed to the XT series manufacturing ramp up, including costs related to design refinement and lower overhead absorption due to the decrease of revenues from the XT conversion. The increase in service costs is primarily due to the increase in service revenues of $16.1 million, which is offset by a slight decrease in costs due to efficiencies from scaling and cost saving activities. Our gross profit for the year ended December 31, 2017 was $278.5 million as compared to $285.9 million for the year ended December 31, 2016.

[0000926326-19-000007:mdna:120]
Medication Adherence. Cost of revenues increased by $17.8 million for the year ended December 31, 2017 as compared to the year ended December 31, 2016 primarily due to the increase in product costs and service costs of $11.5 million and $6.3 million, respectively. The increase in product costs was attributed to (i) increase in product revenues of $8.6 million, (ii) increase in product costs of $5.4 million related to Ateb, and (iii) product mix from higher volume of sales of lower margin products. The increase in service costs was primarily attributed to the increase in service costs of $6.3 million related to Ateb. Our gross profit for the year ended December 31, 2017 was $40.1 million as compared to $31.1 million for the year ended December 31, 2016.

[0000926326-19-000007:mdna:121]
Operating Expenses and Income from Operations

[0000926326-19-000007:mdna:122]
|  |  |  | Change in |  |  |  | Change in |  |  |
|  | 2018 |  | $ |  | % |  | 2017 |  | $ |  | % |  | 2016 |
|  | (Dollars in thousands) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 64,843 |  |  | $ | (1,179 | ) |  | (2)% |  | $ | 66,022 |  |  | $ | 8,223 |  |  | 14% |  | $ | 57,799 |  |
| As a percentage of total revenues | 8% |  |  |  |  |  | 9% |  |  |  |  |  | 8% |
| Selling, general, and administrative | 263,095 |  |  | 21,625 |  |  | 9% |  | 241,470 |  |  | 3,589 |  |  | 2% |  | 237,881 |  |
| As a percentage of total revenues | 33% |  |  |  |  |  | 34% |  |  |  |  |  | 34% |
| Total operating expenses | $ | 327,938 |  |  | $ | 20,446 |  |  | 7% |  | $ | 307,492 |  |  | $ | 11,812 |  |  | 4% |  | $ | 295,680 |  |
| As a percentage of total revenues | 42% |  |  |  |  |  | 43% |  |  |  |  |  | 42% |
| Income (loss) from operations: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 148,119 |  |  | $ | 54,478 |  |  | 58% |  | $ | 93,641 |  |  | $ | (5,431 | ) |  | (5)% |  | $ | 99,072 |  |
| Operating margin | 23% |  |  |  |  |  | 16% |  |  |  |  |  | 17% |
| Medication Adherence | (5,522 | ) |  | (3,926 | ) |  | 246% |  | (1,596 | ) |  | (7,894 | ) |  | (125)% |  | 6,298 |  |
| Operating margin | (4)% |  |  |  |  |  | (1)% |  |  |  |  |  | 6% |
| Corporate expenses (“Common”) | (98,205 | ) |  | (17,305 | ) |  | 21% |  | (80,900 | ) |  | 3,065 |  |  | (4)% |  | (83,965 | ) |
| Total income from operations | $ | 44,392 |  |  | $ | 33,247 |  |  | 298% |  | $ | 11,145 |  |  | $ | (10,260 | ) |  | (48)% |  | $ | 21,405 |  |
| Total operating margin | 6% |  |  |  |  |  | 2% |  |  |  |  |  | 3% |
| Interest and other income (expense), net | $ | (8,776 | ) |  | $ | (2,143 | ) |  | 32% |  | $ | (6,633 | ) |  | $ | 1,796 |  |  | (21)% |  | $ | (8,429 | ) |

[0000926326-19-000007:mdna:123]
2018 compared to 2017

[0000926326-19-000007:mdna:124]
Research and Development. Research and development expenses decreased $1.2 million for the year ended December 31, 2018 as compared to year ended December 31, 2017, primarily driven by a decrease in research and development expenses of $3.9 million in our Automation and Analytics segment, offset by an increase in research and development expenses of $0.7 million in our Medication Adherence segment and an increase of $2.0 million in corporate-related research and development expenses. The decrease in the Automation and Analytics segment was primarily attributed to several research and development projects reaching capitalization stage during the period ended December 31, 2018 as we are allocating additional resources to software projects, resulting in lower research and development expenses. The increase in corporate-related expenses was primarily due to an increase in consulting fees related to a key engineering product management project.

[0000926326-19-000007:mdna:125]
Selling, General, and Administrative. Selling, general, and administrative expenses increased $21.6 million for the year ended December 31, 2018 as compared to year ended December 31, 2017, due to overall growth of operations and an increase in employee-related expenses due to the increase in headcount, as well as an increase in commissions of $3.2 million attributable to increases in bookings, and severance and consulting costs related to organizational realignment of $1.3 million, partially offset by out-of-period adjustments of $2.6 million as discussed in Note 1, Organization and Summary of Significant Accounting Policies.

[0000926326-19-000007:mdna:126]
Interest and Other Income (Expense), Net. The $2.1 million increase in interest and other income (expense), net for the year ended December 31, 2018 as compared to year ended December 31, 2017 was due to an increase in expenses related to foreign currency fluctuations, interest, bank charges, and amortization of debt fees and issuance costs, partially offset by a contingent gain of $2.5 million recognized in the second quarter of 2018 related to a settlement agreement associated with the Ateb acquisition.

[0000926326-19-000007:mdna:127]
2017 compared to 2016

[0000926326-19-000007:mdna:128]
Research and Development. Research and development expenses increased $8.2 million for the year ended December 31, 2017 as compared to year ended December 31, 2016, primarily driven by increases of $0.2 million and $6.8 million in our Automation and Analytics and Medication Adherence segments, respectively. In addition, corporate-related research and development expenses increased by $1.2 million. The increase in our Medication and Adherence segment was primarily attributable to Ateb, which contributed $5.5 million to the increase year over year. The remaining increase in the Medication Adherence segment is primarily related to continued investment in the segment. The increase in the corporate-related expenses related to new and ongoing research and development projects.

[0000926326-19-000007:mdna:129]
Selling, General, and Administrative. Selling, general, and administrative expenses increased $3.6 million for the year ended December 31, 2017 as compared to year ended December 31, 2016 due to an increase in our Medication Adherence segment of $10.1 million, offset by decreases from our Automation and Analytics segment of $2.3 million and corporate-related expenses of $4.3 million. The increase from our Medication Adherence segment is primarily attributed to Ateb, which contributed $9.1 million to the increase. The remaining increase is primarily due to normal growth to support the business and attributed to higher commissions, benefits and salaries, and other investment in the business. The decrease in our Automation and Analytics segment was mainly due to lower amortization expense related to intangible assets of $2.4 million and a decrease in professional fees of $1.8 million related to Aesynt. The decreases are offset by normal growth of operations. The decrease in our corporate-related expenses was mainly due to lower integration and acquisition related cost as well as an overall reduction in cost as part of cost saving initiatives.

[0000926326-19-000007:mdna:130]
Interest and Other Income (Expense), Net. The $1.8 million decrease in interest and other income (expense), net for the year ended December 31, 2017 as compared to year ended December 31, 2016 was due to a decrease in expenses related to foreign currency fluctuations, interest and bank charges.

[0000926326-19-000007:mdna:131]
Provision for (Benefit from) Taxes

[0000926326-19-000007:mdna:132]
|  |  |  | Change in |  |  |  | Change in |  |  |
|  | 2018 |  | $ |  | % |  | 2017 |  | $ |  | % |  | 2016 |
|  | (Dollars in thousands) |
| Provision for (benefit from) income taxes | $ | (2,113 | ) |  | $ | 23,893 |  |  | (92)% |  | $ | (26,006 | ) |  | $ | (29,226 | ) |  | (908)% |  | $ | 3,220 |  |
| Effective tax rate on earnings | (6)% |  |  |  |  |  | (576)% |  |  |  |  |  | 25% |

[0000926326-19-000007:mdna:133]
2018 compared to 2017

[0000926326-19-000007:mdna:134]
We recorded a benefit from income taxes of $2.1 million and a negative effective tax rate of 6% for the year ended December 31, 2018, compared to a tax benefit of $26.0 million and a negative effective tax rate of 576% for the year ended December 31, 2017. The 2018 annual effective tax rate differed from the statutory tax rate of 21%, primarily due to a favorable impact from the excess tax benefit from equity-based compensation, favorable impact of research and development credits, and a tax benefit recorded due to restructuring entity reclassification. The increase in the annual effective tax rate in 2018 as compared to 2017 was primarily due to the increase in our earnings and the one-time nature of the $20.0 million benefit from enactment of the U.S. tax reform entitled the 2017 Tax Cuts and Jobs Act (the “Tax Act”) recorded in 2017.

[0000926326-19-000007:mdna:135]
2017 compared to 2016

[0000926326-19-000007:mdna:136]
We recorded a benefit from income taxes of $26.0 million and a negative effective tax rate of 576% for the year ended December 31, 2017, compared to a tax expense of $3.2 million and an effective tax rate of 25% for the year ended

[0000926326-19-000007:mdna:137]
December 31, 2016. The 2017 annual effective tax rate differed from the statutory tax rate of 35%, primarily due to a favorable impact from the U.S. tax reform legislation that resulted in the recognition of a one-time benefit of $20.0 million from the revaluation of deferred tax assets and liabilities, as well as recording of the excess tax benefit from the equity-based compensation within income tax expense effective 2017, and favorable impact of research and development credits, the domestic production activities deduction, offset by unfavorable impact of geographic mix of earnings. The increase in the annual effective tax rate as compared to 2016 was primarily due to the favorable impact from enactment of the Tax Act.

[0000926326-19-000007:mdna:138]
LIQUIDITY AND CAPITAL RESOURCES

[0000926326-19-000007:mdna:139]
We had cash and cash equivalents of $67.2 million at December 31, 2018, compared to $32.4 million at December 31, 2017. All of our cash and cash equivalents are invested in demand deposits only.

[0000926326-19-000007:mdna:140]
Our cash position and working capital at December 31, 2018 and December 31, 2017 were as follows:

[0000926326-19-000007:mdna:141]
|  | December 31, |
|  | 2018 |  | 2017 |
|  | (In thousands) |
| Cash | $ | 67,192 |  |  | $ | 32,424 |  |
| Working Capital | $ | 192,554 |  |  | $ | 147,066 |  |

[0000926326-19-000007:mdna:142]
Our ratio of current assets to current liabilities was 1.9:1 at December 31, 2018 and 1.7:1 at December 31, 2017.

[0000926326-19-000007:mdna:143]
Sources of Cash

[0000926326-19-000007:mdna:144]
On January 5, 2016, we entered into a $400.0 million secured credit facility pursuant to a credit agreement, by and among us, the lenders from time to time party thereto, Wells Fargo Securities, LLC, as sole lead arranger and Wells Fargo Bank, National Association, as administrative agent (the “Credit Agreement”). The Credit Agreement provides for a $200.0 million term loan facility (the “Term Loan Facility”), and prior to the amendment discussed below, a $200.0 million revolving credit facility (the “Revolving Credit Facility” and together with the Term Loan Facility, the “Facilities”). In addition, the Credit Agreement includes a letter of credit sub-limit of up to $10.0 million and a swing line loan sub-limit of up to $10.0 million.

[0000926326-19-000007:mdna:145]
On December 26, 2017 and April 11, 2017, we entered into the amendments to the Credit Agreement. Under these amendments, the Revolving Credit Facility was increased from $200.0 million to $315.0 million and certain other modifications were made. Refer to Note 8, Debt and Credit Agreements, of the Notes to the Consolidated Financial Statements included in this annual report. We expect to use future loans under the Revolving Credit Facility, if any, for general corporate purposes, including acquisitions.

[0000926326-19-000007:mdna:146]
As of December 31, 2018, the outstanding balance from the Facilities was $140.0 million and we were in full compliance with all covenants.

[0000926326-19-000007:mdna:147]
On November 3, 2017, we entered into a Distribution Agreement (the “Distribution Agreement”) with J.P. Morgan Securities LLC, Wells Fargo Securities, LLC, and HSBC Securities (USA) Inc., as our sales agents (collectively, the “Sales Agents”), pursuant to which we may offer and sell from time to time through the Sales Agents up to $125.0 million maximum aggregate offering price of our common stock. Sales of the common stock pursuant to the Distribution Agreement may be made in negotiated transactions or transactions that are deemed to be “at the market” offerings as defined in Rule 415 under the Securities Act of 1933, including sales made directly on the Nasdaq Stock Market, or sales made to or through a market maker other than on an exchange. We intend to use the net proceeds from the sale, if any, of common stock in the offering for general corporate purposes, which may include, without limitation, the acquisition of complementary businesses, the repayment of outstanding indebtedness, capital expenditures and working capital.

[0000926326-19-000007:mdna:148]
For the year ended December 31, 2017, we received gross proceeds of $14.7 million from sales of our common stock under the Distribution Agreement and incurred issuance costs of $0.8 million on sales of approximately 294,000 shares of our common stock at an average price of approximately $49.85 per share.

[0000926326-19-000007:mdna:149]
For the year ended December 31, 2018, we received gross proceeds of $40.3 million from sales of our common stock under the Distribution Agreement and incurred issuance costs of $0.7 million on sales of approximately 557,000 shares of our common stock at an average price of approximately $72.40 per share. As of December 31, 2018, we had an aggregate of $70.0 million available to be offered under the Distribution Agreement.

[0000926326-19-000007:mdna:150]
Uses of Cash

[0000926326-19-000007:mdna:151]
Our future uses of cash are expected to be primarily for working capital, capital expenditures, loan principal and interest payments, and other contractual obligations. We also expect a continued use of cash for potential acquisitions and acquisition-related activities.

[0000926326-19-000007:mdna:152]
On April 12, 2017, we completed the acquisition of all of the membership interest of InPharmics. The total consideration for the transaction was $5.0 million, net of cash on hand at signing of $0.3 million.

[0000926326-19-000007:mdna:153]
On January 5, 2016, we completed the acquisition of all of the membership interests of Aesynt. The purchase price paid by us was $271.5 million, net of cash on hand of $8.2 million.

[0000926326-19-000007:mdna:154]
On December 8, 2016, we completed the acquisition of Ateb. The purchase price paid by us was $40.7 million, net of cash on hand of $0.9 million. These acquisitions were funded with cash-on-hand and borrowings under the Credit Agreement.

[0000926326-19-000007:mdna:155]
In accordance with the share purchase agreement entered into on April 30, 2015 under which we acquired Avantec, we agreed to pay potential earn-out payments of up to $3.0 million payable after December 31, 2015 and an additional $3.0 million payable after December 31, 2016, based on bookings targets. The fair value of these potential earn-out payments as of the acquisition date was $5.6 million. Additionally we retained $1.8 million of the purchase consideration to be held to settle any future indemnification claims within an 18-month period following the closing. During the year ended December 31, 2016, we paid out $3.0 million in earn-out payments, $1.8 million in held back payments for future indemnifications, and recognized $0.6 million of contingent gain as certain booking targets were not met. During the year ended December 31, 2017, we concluded that the final payout had been earned and paid out $2.4 million during the third quarter of 2017.

[0000926326-19-000007:mdna:156]
Our stock repurchase programs have a total of $54.9 million remaining for future repurchases as of December 31, 2018, which may result in additional use of cash. See Note 12, Stock Repurchase Program, of the Notes to Consolidated Financial Statements included in this annual report. There were no stock repurchases during the years ended December 31, 2018, December 31, 2017, and December 31, 2016.

[0000926326-19-000007:mdna:157]
Based on our current business plan and revenue backlog, we believe that our existing cash and cash equivalents, our anticipated cash flows from operations, cash generated from the exercise of employee stock options and purchases under our employee stock purchase plan, along with the availability of funds under the Facilities will be sufficient to meet our cash needs for working capital, capital expenditures, potential acquisitions, and other contractual obligations for at least the next twelve months. For periods beyond the next twelve months, we also anticipate that our net operating cash flows plus existing balances of cash and cash equivalents will suffice to fund the continued growth of our business.

[0000926326-19-000007:mdna:158]
Cash Flows

[0000926326-19-000007:mdna:159]
The following table summarizes, for the periods indicated, selected items in our Consolidated Statements of Cash Flows:

[0000926326-19-000007:mdna:160]
|  | Year Ended December 31, |
|  | 2018 |  | 2017 |  | 2016 |
|  | (In thousands) |
| Net cash provided by (used in): |  |  |  |  |  |
| Operating activities | $ | 103,966 |  |  | $ | 24,834 |  |  | $ | 49,900 |  |
| Investing activities | (54,374 | ) |  | (34,987 | ) |  | (341,323 | ) |
| Financing activities | (13,597 | ) |  | (9,877 | ) |  | 263,752 |  |
| Effect of exchange rate changes on cash and cash equivalents | (1,227 | ) |  | (2,034 | ) |  | (58 | ) |
| Net increase (decrease) in cash and cash equivalents | $ | 34,768 |  |  | $ | (22,064 | ) |  | $ | (27,729 | ) |

[0000926326-19-000007:mdna:161]
Operating activities

[0000926326-19-000007:mdna:162]
We expect cash from our operating activities to fluctuate in future periods as a result of a number of factors, including the timing of our billings and collections, our operating results and the timing of other liability payments.

[0000926326-19-000007:mdna:163]
Net cash provided by operating activities was $104.0 million for 2018, primarily consisting of net income of $37.7 million adjusted for non-cash items of $77.0 million offset by changes in assets and liabilities of $10.7 million. The non-cash items primarily consisted of depreciation and amortization expense of $51.4 million, share-based compensation expense of $28.9 million, $2.3 million of amortization of debt financing fees, and an increase in deferred income taxes of $5.7 million.

[0000926326-19-000007:mdna:164]
Changes in assets and liabilities include cash outflows from (i) a decrease in accounts payables of $9.2 million due to cash conservation efforts in 2017, which resulted in higher payable balances, and timing of payments, (ii) an increase of other long-term assets of $7.1 million due an increase in unbilled receivables, (iii) an increase in inventories of $6.8 million for inventory buildup in support of forecasted sales, (iv) an increase in accounts receivable and unbilled receivables of $6.2 million due to increased billings and the timing of billings and collections, and (v) an increase of prepaid commissions of $4.7 million due to an increase in bookings. These cash outflows were partially offset by an increase of accrued compensation of $14.4 million, an increase in other accrued liabilities of $8.2 million, and an increase in deferred revenue of $3.0 million due to the increased billings and the timing of orders and revenue being recognized for installed product.

[0000926326-19-000007:mdna:165]
Net cash provided by operating activities was $24.8 million for 2017, primarily consisting of net income of $30.5 million adjusted for non-cash items of $44.1 million offset by changes in assets and liabilities of $49.8 million. The non-cash items primarily consisted of depreciation and amortization expense of $51.5 million, share-based compensation expense of $21.9 million, $1.6 million of amortization of debt financing fees, and an increase in deferred income taxes of $31.4 million. Changes in assets and liabilities include cash outflows from (i) an increase in accounts receivable and unbilled receivables of $40.6 million due to the timing of billings and collections, (ii) an increase in inventories of $26.8 million for inventory buildup in support of forecasted sales, (iii) an increase in prepaid expenses of $4.9 million, (iv) an increase in prepaid commissions of $4.0 million, (v) a decrease in deferred revenue of $2.3 million due to the timing of orders and revenue being recognized for installed product, and (vi) an increase in other current assets of $2.1 million. These cash outflows were partially offset by an increase in accounts payable of $19.7 million primarily due to the increase in inventory and timing of payments, a decrease in the investment in sales-type leases of $6.6 million, and an increase in other accrued liabilities of $4.4 million.

[0000926326-19-000007:mdna:166]
Net cash provided by operating activities was $49.9 million for 2016, primarily consisting of net income of $9.8 million adjusted for non-cash items $75.4 million offset by changes in assets and liabilities of $35.3 million. The non-cash items primarily consisted of depreciation and amortization expense of $58.4 million, share-based compensation expense of $19.5 million, and an increase in deferred income taxes of $5.1 million. Changes in assets and liabilities include cash outflows from (i) a $9.6 million increase in investment in sales-type leases due to additional lease transactions entered into during the year, (ii) a $7.2 million increase in prepaid commissions, (iii) a $6.3 million decrease in other long-term liabilities, (iv) a $5.1 million increase in other long-term assets, (v) a $5.0 million decrease in accounts payable due to timing of payments, (vi) a $3.4 million increase in inventories to support sales forecast, and (vii) a decrease in the deferred revenue of $1.9 million. These cash outflows were partially offset by a decrease of $9.9 million in accounts receivable and unbilled receivables as result of higher collections in the fourth quarter of 2016.

[0000926326-19-000007:mdna:167]
Investing activities

[0000926326-19-000007:mdna:168]
Net cash used in investing activities was $54.4 million for 2018, which consisted of capital expenditures of $23.7 million for property and equipment and $30.7 million for costs of software development for external use.

[0000926326-19-000007:mdna:169]
Net cash used in investing activities was $35.0 million for 2017, which consisted of capital expenditures of $15.3 million for property and equipment, $15.0 million for costs of software development for external use, $0.2 million for purchase of intangible assets, and $4.4 million attributable to the acquisition of InPharmics.

[0000926326-19-000007:mdna:170]
Net cash used in investing activities was $341.3 million for 2016, $312.2 million of which was attributable to the acquisitions of Aesynt and Ateb. Capital expenditures related to software development costs for external use, purchases of property and equipment and, purchases of intangibles contributed $14.3 million, $13.4 million, and $1.4 million, respectively.

[0000926326-19-000007:mdna:171]
Financing activities

[0000926326-19-000007:mdna:172]
Net cash used in financing activities was $13.6 million for 2018, primarily due to the repayment of $77.0 million of the Facilities and $6.8 million in employees’ taxes paid related to restricted stock unit vesting, partially offset by $30.6 million in proceeds from employee stock option exercises and employee stock plan purchases, and $39.6 million proceeds from sales of our common stock under the Distribution Agreement.

[0000926326-19-000007:mdna:173]
Net cash used in financing activities was $9.9 million for 2017, primarily due to the repayment of $102.5 million of the Facilities and $5.9 million in employees’ taxes paid related to restricted stock unit vesting, partially offset by $30.1 million in proceeds from employee stock option exercises and employee stock plan purchases, and $56.9 million proceeds from term loan and revolving credit facilities.

[0000926326-19-000007:mdna:174]
Net cash provided by financing activities was $263.8 million for 2016, as a result of $287.1 million of net proceeds from debt, $17.7 million in proceeds from employee stock option exercises and employee stock plan purchases, partially offset by $34.5 million of repayments of debt and revolving credit facility, $3.5 million in employees taxes paid in relation to restricted stock units and $3.0 million of payment for contingent consideration.

[0000926326-19-000007:mdna:175]
Contractual Obligations

[0000926326-19-000007:mdna:176]
Contractual obligations as of December 31, 2018 were as follows:

[0000926326-19-000007:mdna:177]
|  | Payments Due by Period |
|  | Total |  | 2019 |  | 2020-2021 |  | 2022-2023 |  | 2024 and thereafter |
|  | (In thousands) |
| Operating leases (1) | $ | 87,418 |  |  | $ | 14,153 |  |  | $ | 25,833 |  |  | $ | 20,143 |  |  | $ | 27,289 |  |
| Purchase obligations (2) | 52,183 |  |  | 50,185 |  |  | 1,225 |  |  | 764 |  |  | 9 |  |
| Term loan facility (3) | 140,000 |  |  | — |  |  | 140,000 |  |  | — |  |  | — |  |
| Total (4) (5) | $ | 279,601 |  |  | $ | 64,338 |  |  | $ | 167,058 |  |  | $ | 20,907 |  |  | $ | 27,298 |  |

[0000926326-19-000007:mdna:178]
_________________________________________________

[0000926326-19-000007:mdna:179]
| (1) | Commitments under operating leases relate primarily to leased property and office equipment. Rent expense was $12.7 million, $11.5 million and $9.8 million for the years ended December 31, 2018, December 31, 2017, and December 31, 2016, respectively. |

[0000926326-19-000007:mdna:180]
| (2) | We purchase components from a variety of suppliers and use contract manufacturers to provide manufacturing services for our products. During the normal course of business, we issue purchase orders with estimates of our requirements several months ahead of the delivery dates. These amounts are associated with agreements that are enforceable and legally binding. The amounts under such contracts are included in the table above because we believe that cancellation of these contracts is unlikely and we expect to make future cash payments according to the contract terms or in similar amounts for similar materials. |

[0000926326-19-000007:mdna:181]
| (3) | Amounts shown for term loan facility are principal repayments only. Due to use of interest rate swaps, the cash interest expense is partly variable and partly fixed, and is not reflected in the above table. Refer to Note 8, Debt and Credit Agreements, of the Notes to the Consolidated Financial Statements included in this annual report. |

[0000926326-19-000007:mdna:182]
| (4) | We have recorded $5.8 million for uncertain tax positions under long-term liabilities as of December 31, 2018 in accordance with the authoritative guidance summarized in the section entitled “Critical Accounting Policies and Estimates” above. As these liabilities do not reflect actual tax assessments, the timing and amount of payments we might be required to make will depend upon a number of factors. Accordingly, as the timing and amount of payment cannot be estimated, $5.8 million in uncertain tax position liabilities have not been included in the table above. See Note 15, Income Taxes, of the Notes to Consolidated Financial Statements included in this annual report. |

[0000926326-19-000007:mdna:183]
| (5) | See Note 10, Commitments and Contingencies, of the Notes to Consolidated Financial Statements included in this annual report. |

[0000926326-19-000007:mdna:184]
Off-Balance Sheet Arrangements

[0000926326-19-000007:mdna:185]
As of December 31, 2018, we had no off-balance sheet arrangements as defined under Regulation S-K 303(a)(4) of the Securities Exchange Act of 1934, as amended, and the instructions thereto.
