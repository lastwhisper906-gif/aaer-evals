# OMCL note change history — 0000926326-18-000025 → 0000926326-18-000030


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-11-02):
[0000926326-18-000030:note_history:1]
The Company leases office space and office equipment under operating leases. Commitments under operating leases primarily relate to leasehold property and office equipment. At September 30, 2018, the minimum future payments on non-cancelable operating leases were as follows:
  (was, 2018-08-03, similarity 0.7992):
[0000926326-18-000025:note_history:1]
The Company leases office space and office equipment under operating leases. Commitments under operating leases primarily relate to leasehold property and office equipment. At June 30, 2018, the minimum future payments on non-cancelable operating leases were as follows:

- changed (2018-11-02):
[0000926326-18-000030:note_history:2]
|  | (In thousands) |
| Remaining three months of 2018 | $ | 3,392 |  |
| 2019 | 13,329 |  |
| 2020 | 11,416 |  |
| 2021 | 10,458 |  |
| 2022 | 8,655 |  |
| Thereafter | 26,634 |  |
| Total minimum future lease payments | $ | 73,884 |  |
  (was, 2018-08-03, similarity 0.9778):
[0000926326-18-000025:note_history:2]
|  | (In thousands) |
| Remaining six months of 2018 | $ | 6,651 |  |
| 2019 | 13,264 |  |
| 2020 | 11,399 |  |
| 2021 | 10,465 |  |
| 2022 | 8,660 |  |
| Thereafter | 26,707 |  |
| Total minimum future lease payments | $ | 77,146 |  |

- changed (2018-11-02):
[0000926326-18-000030:note_history:3]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. At September 30, 2018, the Company had non-cancelable purchase commitments of $75.9 million, which are expected to be paid within the next twelve months.
  (was, 2018-08-03, similarity 0.9745):
[0000926326-18-000025:note_history:3]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. At June 30, 2018, the Company had non-cancelable purchase commitments of $56.2 million, which are expected to be paid within the next twelve months.

- changed (2018-11-02):
[0000926326-18-000030:note_history:4]
On June 6, 2018, a class-action lawsuit was filed against a customer of the Company, the customer’s parent company and two vendors of medication dispensing systems, one of which is the Company, in the Circuit Court of Cook County, Illinois, Chancery Division, captioned Yana Mazya, individually and on behalf of all others similarly situated v. Northwestern Lake Forest Hospital, Northwestern Memorial Healthcare, Omnicell, Inc. and Becton Dickinson, Case No. 2018-CH-07161. The complaint seeks class certification, monetary damages in the form of statutory damages for willful and/or reckless or, in the alternative, negligent violation of the Illinois Biometric Information Privacy Act (“BIPA”), and certain declaratory, injunctive, and other relief based on causes of action directed to allegations of violation of BIPA and of negligence by the defendants. The complaint was served on the Company on June 15, 2018. The Company’s obligation to respond to the complaint has been held in abeyance pending a decision of the Illinois Supreme Court in a separate case involving BIPA issues. The court has scheduled a status conference in the case for February 20, 2019. The Company intends to defend the lawsuit vigorously.
  (was, 2018-08-03, similarity 0.8109):
[0000926326-18-000025:note_history:4]
On June 6, 2018, a class-action lawsuit was filed against a customer of the Company, the customer’s parent company and two vendors of medication dispensing systems, one of which is the Company, in the Circuit Court of Cook County, Illinois, Chancery Division, captioned Yana Mazya, individually and on behalf of all others similarly situated v. Northwestern Lake Forest Hospital, Northwestern Memorial Healthcare, Omnicell, Inc. and Becton Dickinson, Case No. 2018-CH-07161. The complaint seeks class certification, monetary damages in the form of statutory damages for willful and/or reckless or, in the alternative, negligent violation of the Illinois Biometric Information Privacy Act (“BIPA”), and certain declaratory, injunctive, and other relief based on causes of action directed to allegations of violation of BIPA and of negligence by the defendants. The complaint was served on the Company on June 15, 2018. Counsel for the proposed class filed a motion to certify the class; the court continued the motion and scheduled a status conference for October 4, 2018. The Company’s obligation to respond to the complaint has been held in abeyance until further determination by the court. The Company intends to defend the lawsuit vigorously.

- added (2018-11-02):
[0000926326-18-000030:note_history:5]
A declaratory judgment action was filed against the Company, on August 30, 2018, in the United States District Court for the Northern District of California, captioned Zurich American Insurance Company; American Guarantee & Liability Company v. Omnicell, Inc. and Does 1-10, inclusive, Case No. 3:18-CV-05345. The complaint seeks a declaration that the plaintiffs have no duty to defend or indemnify the Company in connection with the underlying litigation, the Yana Mazya, et al. v. Northwestern Lake Forest Hospital, et al., Case No. 2018-CH-07161 pending in the Circuit Court of Cook County, Illinois, Chancery Division (“Underlying Action”), disclosed above, together with claims for reimbursement and unjust enrichment relating to the defense of the Underlying Action in the form of attorneys’ fees and other related costs. The Company has not yet responded to the complaint. The Company filed a motion to stay proceedings in this litigation pending the outcome of the Underlying Action. The court has granted the Company’s motion to stay the requirement to respond to the complaint pending the resolution of the motion to stay the litigation. The Company intends to defend the lawsuit vigorously.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-11-02):
[0000926326-18-000030:note_history:6]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of September 30, 2018 and December 31, 2017, the results of operations and comprehensive income for the three and nine months ended September 30, 2018 and September 30, 2017, and cash flows for the nine months ended September 30, 2018 and September 30, 2017. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s annual report on Form 10-K for the year ended December 31, 2017 filed with the SEC on February 27, 2018, except as discussed in the section entitled “Revenue Recognition” below. The Company’s results of operations and comprehensive income for the three and nine months ended September 30, 2018 and cash flows for the nine months ended September 30, 2018 are not necessarily indicative of results that may be expected for the year ending December 31, 2018, or for any future period.
  (was, 2018-08-03, similarity 0.781):
[0000926326-18-000025:note_history:6]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of June 30, 2018 and December 31, 2017, and the results of its operations, comprehensive income (loss), and cash flows for the three and six months ended June 30, 2018 and June 30, 2017. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s annual report on Form 10-K for the year ended December 31, 2017 filed with the SEC on February 27, 2018, except as discussed in the section entitled “Revenue Recognition” below. The Company’s results of operations, comprehensive income (loss) and cash flows for the three and six months ended June 30, 2018 are not necessarily indicative of results that may be expected for the year ending December 31, 2018, or for any future period.

- changed (2018-11-02):
[0000926326-18-000030:note_history:7]
Certain prior-year amounts have been reclassified to conform with current-period presentation. These reclassifications include (i) reclassification of revenues from services and other revenues to product revenues of $0.2 million and $0.5 million for the three and nine months ended September 30, 2017, respectively, related to software term-license sales, (ii) a change in inventories presentation related to allocation of inventories obsolete reserve between finished goods, raw materials, and work in progress in the Notes to the Condensed Consolidated Financial Statements, and (iii) a change in intangible assets presentation related to presenting foreign currency impact separately in the Notes to the Condensed Consolidated Financial Statements. In addition, $0.6 million was reclassified from services and other revenues to product revenues for the nine months ended September 30, 2018 in order to conform with the presentation for the three months ended September 30, 2018. These changes were not deemed material and were included to conform with current-period classification and presentation.
  (was, 2018-08-03, similarity 0.7954):
[0000926326-18-000025:note_history:7]
Certain prior-year amounts have been reclassified to conform with current-period presentation. These reclassifications include (i) reclassification of revenues from services and other revenues to product revenues of $0.2 million and $0.3 million for the three and six months ended June 30, 2017, respectively, related to software term-license sales, (ii) change in inventories presentation related to allocation of inventories obsolete reserve between finished goods, raw materials, and work in progress in the Notes to the Condensed Consolidated Financial Statements, and (iii) change in intangible assets presentation related to presenting foreign currency impact separately in the Notes to the Condensed Consolidated Financial Statements. These changes were not deemed material and were included to conform with current-period classification and presentation.

- changed (2018-11-02):
[0000926326-18-000030:note_history:8]
Software. Additional software applications that enable incremental functionality of the Company’s equipment.
  (was, 2018-08-03, similarity 0.9417):
[0000926326-18-000025:note_history:8]
Software. Additional software applications that enable incremental functionality of its equipment.

- changed (2018-11-02):
[0000926326-18-000030:note_history:9]
Installation. Installation of equipment as integrated systems at customer sites.
  (was, 2018-08-03, similarity 0.9877):
[0000926326-18-000025:note_history:9]
Installation. Installation of equipment as integrated systems at customers’ sites.

- changed (2018-11-02):
[0000926326-18-000030:note_history:10]
The transaction price is allocated to separate performance obligations proportionally based on the standalone selling price of each performance obligation. Standalone selling price is best evidenced by the price the Company charges for the good or service when selling it separately in similar circumstances to similar customers. Other than for the renewal of annual support services contracts, the Company’s products and services are not generally sold separately. The Company uses an expected cost plus a margin approach to identify the standalone selling price of goods where separate sales transactions do not exist. For software and services which do not have a specific identifiable product cost, the Company uses an amount discounted from the list price as a best estimated selling price.
  (was, 2018-08-03, similarity 0.9515):
[0000926326-18-000025:note_history:10]
The transaction price is allocated to separate performance obligations proportionally based on the standalone selling price of each performance obligation. Standalone selling price is best evidenced by the price the Company charges for the good or service when selling it separately in similar circumstances to similar customers. Other than for the renewal of annual support services contracts, the Company’s products and services are not generally sold separately. The Company uses an expected cost plus a margin approach to identify the standalone selling price of goods where separate sales transactions do not exist. For software and services which do not have a specific identifiable product cost, the Company uses a discounted from the list price amount as a best estimated selling price.

- changed (2018-11-02):
[0000926326-18-000030:note_history:11]
The Company recognizes revenue when the performance obligation has been satisfied by transferring a promised good or service to a customer. The good or service is transferred when or as the customer obtains control of the good or service. Determining when control transfers requires management to make judgments that affect the timing of revenues recognized. Generally, for products requiring a complex implementation, control passes when the product is installed and ready for use. For all other products, control generally passes when product has been shipped and title has passed. For maintenance contracts and certain other services provided on a subscription basis, control passes to the customer over time, generally ratably over the service term as the Company provides a stand-ready service to service the customer’s equipment. Time and material services transfer control to the customer at the time the services are provided. The portion of the transaction price allocated to the Company’s unsatisfied performance obligations recorded as deferred revenues at September 30, 2018 and December 31, 2017 were $98.4 million and $89.4 million, respectively, of which $87.8 million and $78.8 million, respectively, are expected to be completed within one year. Remaining performance obligations primarily relate to maintenance contracts and are recognized ratably over the remaining term of the contract, generally not more than five years.
  (was, 2018-08-03, similarity 0.9852):
[0000926326-18-000025:note_history:11]
The Company recognizes revenue when the performance obligation has been satisfied by transferring a promised good or service to a customer. The good or service is transferred when or as the customer obtains control of the good or service. Determining when control transfers requires management to make judgments that affect the timing of revenues recognized. Generally, for products requiring a complex implementation, control passes when the product is installed and ready for use. For all other products, control generally passes when product has been shipped and title has passed. For maintenance contracts and certain other services provided on a subscription basis, control passes to the customer over time, generally ratably over the service term as the Company provides a stand-ready service to service the customer’s equipment. Time and material services transfer control to the customer at the time the services are provided. The portion of the transaction price allocated to the Company’s unsatisfied performance obligations recorded as deferred revenues at June 30, 2018 and December 31, 2017 was $94.7 million and $89.4 million, respectively, of which $85.8 million and $78.8 million, respectively, are expected to be completed within one year. Remaining performance obligations primarily relate to maintenance contracts and are recognized ratably over the remaining term of the contract, generally not more than five years.

- changed (2018-11-02):
[0000926326-18-000030:note_history:12]
A portion of the Company's sales are made through multi-year lease agreements. Under sales-type leases, the Company recognizes revenue for its hardware and software products net of lease execution costs, such as post-installation product maintenance and technical support, at the net present value of the lease payment stream once its installation obligations have been met. The Company optimizes cash flows by selling a majority of its non-U.S. government leases to third-party leasing finance companies on a non-recourse basis. The Company has no obligation to the leasing company once the lease has been sold. Some of the Company's sales-type leases, mostly those relating to U.S. government hospitals which comprise approximately 44% of the lease receivable balance, are retained in-house. Revenues from sales-type leases of $11.4 million and $5.9 million for the three months ended September 30, 2018 and 2017, respectively, and $28.8 million and $19.3 million for the nine months ended September 30, 2018 and 2017, respectively, are included in product revenues in the Condensed Consolidated Statements of Operations. Interest income in these leases is recognized in product revenues using the effective interest method.
  (was, 2018-08-03, similarity 0.9744):
[0000926326-18-000025:note_history:12]
A portion of the Company's sales are made through multi-year lease agreements. Under sales-type leases, the Company recognizes revenue for its hardware and software products net of lease execution costs, such as post-installation product maintenance and technical support, at the net present value of the lease payment stream once its installation obligations have been met. The Company optimizes cash flows by selling a majority of its non-U.S. government leases to third-party leasing finance companies on a non-recourse basis. The Company has no obligation to the leasing company once the lease has been sold. Some of the Company's sales-type leases, mostly those relating to U.S. government hospitals which comprise approximately 42% of the lease receivable balance, are retained in-house. Revenues from sales-type leases of $7.6 million and $10.2 million for the three months ended June 30, 2018 and 2017, respectively, and $17.4 million and $13.4 million for the six months ended June 30, 2018 and 2017, respectively, are included in product revenues in the Condensed Consolidated Statements of Operations. Interest income in these leases is recognized in product revenues using the effective interest method.

- changed (2018-11-02):
[0000926326-18-000030:note_history:13]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”). GPOs are often owned fully or in part by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs were $2.2 million and $2.1 million for the three months ended September 30, 2018 and 2017, respectively, and $6.2 million and $5.4 million for the nine months ended September 30, 2018 and 2017, respectively.
  (was, 2018-08-03, similarity 0.9434):
[0000926326-18-000025:note_history:13]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”). GPOs are often owned fully or in part by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs were $2.1 million and $1.2 million for the three months ended June 30, 2018 and 2017, respectively, and $4.0 million and $3.3 million for the six months ended June 30, 2018 and 2017, respectively.

- changed (2018-11-02):
[0000926326-18-000030:note_history:14]
|  | September 30, 2018 |  | December 31, 2017 |
|  | (In thousands) |
| Short-term unbilled receivables - included in accounts receivable and unbilled receivables | $ | 9,475 |  |  | $ | 4,590 |  |
| Long-term unbilled receivables - included in other long-term assets | 15,573 |  |  | 9,475 |  |
| Total contract assets | $ | 25,048 |  |  | $ | 14,065 |  |
| Short-term deferred revenues | $ | 87,777 |  |  | $ | 78,774 |  |
| Long-term deferred revenues | 10,634 |  |  | 10,623 |  |
| Total contract liabilities | $ | 98,411 |  |  | $ | 89,397 |  |
  (was, 2018-08-03, similarity 0.9859):
[0000926326-18-000025:note_history:14]
|  | June 30, 2018 |  | December 31, 2017 |
|  | (In thousands) |
| Short-term unbilled receivables - included in accounts receivable and unbilled receivables | $ | 6,031 |  |  | $ | 4,590 |  |
| Long-term unbilled receivables - included in other long-term assets | 12,150 |  |  | 9,475 |  |
| Total contract assets | $ | 18,181 |  |  | $ | 14,065 |  |
| Short-term deferred revenues | $ | 85,776 |  |  | $ | 78,774 |  |
| Long-term deferred revenues | 8,957 |  |  | 10,623 |  |
| Total contract liabilities | $ | 94,733 |  |  | $ | 89,397 |  |

- changed (2018-11-02):
[0000926326-18-000030:note_history:15]
Significant changes in the contract assets and the contract liabilities balances during the period are the result of the issuance of invoices and recognition of deferred revenues in the normal course of business. Unbilled contract assets which were invoiced during the three and nine months ended September 30, 2018 as a result of the right to invoice for the transaction consideration becoming unconditional were not material. The contract modifications entered into during the three and nine months ended September 30, 2018 did not have a significant impact on the Company’s contract assets or deferred revenues. During the three and nine months ended September 30, 2018, the Company recognized revenues of $10.9 million and $78.9 million, respectively, that was included in the corresponding deferred revenue balance as of December 31, 2017.
  (was, 2018-08-03, similarity 0.8178):
[0000926326-18-000025:note_history:15]
Significant changes in the contract assets and the contract liabilities balances during the period are the result of the issuance of invoices and recognition of deferred revenues in the normal course of business. Unbilled contract assets which were invoiced during the three and six months ended June 30, 2018 as a result of the right to invoice for the transaction consideration becoming unconditional were not material. The contract modifications entered into during the three and six months ended June 30, 2018 did not have a significant impact on the Company’s contract assets or deferred revenues. During the three and six months ended June 30, 2018, the Company recognized revenues of $21.4 million and $68.0 million, respectively, that was included in the corresponding deferred revenue balance as of December 31, 2017.

- changed (2018-11-02):
[0000926326-18-000030:note_history:16]
The Company has determined that the incentive portions of its sales commission plans require capitalization since these payments are directly related to sales achieved during a time period. These commissions are earned on the basis of the total purchase order value of new product bookings. Since there are not commensurate commissions earned on renewal of the service bookings, the Company concluded that the capitalized asset is related to services provided under both the initial contract and renewal periods. The Company applies a practical expedient to account for the incremental costs of obtaining a contract to a portfolio of contracts with similar characteristics as the Company expects the effect on the financial statements of applying the practical expedient would not differ materially from applying the accounting guidance to the individual contracts within the portfolio. A pool of contracts is defined as all contracts booked in a particular quarter. The amortization for the capitalized asset is an estimate of the pool’s original contract term, generally one to five years, plus an estimate of future customer renewal periods resulting in a total amortization period of ten years. Costs to obtain a contract are allocated amongst performance obligations and recognized as sales and marketing expense consistent with the pattern of revenue recognition. Capitalized costs are periodically reviewed for impairment. A portion of the pool’s capitalized asset is recorded as an expense after two quarters, which represents the estimated period during which the product revenue associated with the contract is recorded. The remaining contract cost is recorded as expense ratably over the ten year estimated initial and renewal service periods. The Company recognized contract cost expense of $5.3 million and $4.6 million during the three months ended September 30, 2018 and 2017, respectively, and $16.2 million and $13.3 million during the nine months ended September 30, 2018 and 2017, respectively. The portion of commission expenses paid as of the balance sheet date to be recognized in future periods is recorded in long term prepaid commissions on the Condensed Consolidated Balance Sheets. There was no impairment loss recorded related to capitalized prepaid commissions as of and for the three and nine months ended September 30, 2018.
  (was, 2018-08-03, similarity 0.9503):
[0000926326-18-000025:note_history:16]
The Company has determined that the incentive portions of its sales commission plans require capitalization since these payments are directly related to sales achieved during a time period. These commissions are earned on the basis of the total purchase order value of new product bookings. Since there are not commensurate commissions earned on renewal of the service bookings, the Company concluded that the capitalized asset is related to services provided under both the initial contract and renewal periods. The Company applies a practical expedient to account for the incremental costs of obtaining a contract to a portfolio of contracts with similar characteristics as the Company expects the effect on the financial statements of applying the practical expedient would not differ materially from applying the accounting guidance to the individual contracts within the portfolio. A pool of contracts is defined as all contracts booked in a particular quarter. The amortization for the capitalized asset is an estimate of the pool’s original contract term, generally one to five years, plus an estimate of future customer renewal periods resulting in a total amortization period of ten years. Costs to obtain a contract are allocated amongst performance obligations and recognized as sales and marketing expense consistent with the pattern of revenue recognition. Capitalized costs are periodically reviewed for impairment. A portion of the pool’s capitalized asset is recorded as an expense after two quarters, which represents the estimated period during which the product revenue associated with the contract is recorded. The remaining contract cost is recorded as expense ratably over the ten year estimated initial and renewal service periods. The Company recognized contract cost expense of $5.3 million and $4.6 million during the three months ended June 30, 2018 and 2017, respectively, and $10.9 million and $8.7 million during the six months ended June 30, 2018 and 2017, respectively. The portion of commission expenses paid as of the balance sheet date to be recognized in future periods is recorded in long term prepaid commissions expense on the Condensed Consolidated Balance Sheets. There was no impairment loss in relation to the costs capitalized during the three and six months ended June 30, 2018.

- changed (2018-11-02):
[0000926326-18-000030:note_history:17]
The Company’s Chief Operating Decision Maker (“CODM”) is its Chief Executive Officer. The CODM allocates resources and evaluates the performance of the Company’s segments using information about its revenues, gross profit, and income from operations. Such evaluation excludes general corporate-level costs that are not specific to either of the reportable segments and are managed separately at the corporate level. Corporate-level costs include expenses related to executive management, finance and accounting, human resources, legal, training and development, and certain other administrative expenses. See Note 14, Segment and Geographical Information, for additional information on segment reporting.
  (was, 2018-08-03, similarity 0.698):
[0000926326-18-000025:note_history:17]
The Company’s Chief Operating Decision Maker (“CODM”) is its Chief Executive Officer. The CODM allocates resources and evaluates the performance of the Company’s segments using information about its revenues, gross profit, and income from operations. Such evaluation excludes general corporate-level costs that are not specific to either of the reportable segments and are managed separately at the corporate level. Corporate-level costs include expenses related to executive management; finance and accounting; human resources; legal; training and development; and certain other administrative expenses. See Note 14, Segment and Geographical Information, for additional information on segment reporting.

- changed (2018-11-02):
[0000926326-18-000030:note_history:18]
|  | Three months ended September 30, 2017 |
|  | As reported |  | Adjustment |  | As adjusted |
|  | (In thousands) |
| Revenues |  |  |  |  |  |
| Automation and Analytics | $ | 154,651 |  |  | $ | (34 | ) |  | $ | 154,617 |  |
| Medication Adherence | 32,131 |  |  | — |  |  | 32,131 |  |
| Gross profit |  |  |  |  |  |
| Automation and Analytics | 74,911 |  |  | (34 | ) |  | 74,877 |  |
| Medication Adherence | 9,942 |  |  | — |  |  | 9,942 |  |
| Selling, general, and administrative expenses | 58,725 |  |  | (2,517 | ) |  | 56,208 |  |
| Provision for income taxes | 751 |  |  | 966 |  |  | 1,717 |  |
| Net income | $ | 6,231 |  |  | $ | 1,517 |  |  | $ | 7,748 |  |
| Net income per share - basic | $ | 0.17 |  |  | $ | 0.04 |  |  | $ | 0.21 |  |
| Net income per share - diluted | $ | 0.16 |  |  | $ | 0.04 |  |  | $ | 0.20 |  |
  (was, 2018-08-03, similarity 0.7536):
[0000926326-18-000025:note_history:18]
|  | Three months ended June 30, 2017 |
|  | As reported |  | Adjustment |  | As adjusted |
|  | (In thousands) |
| Revenues |  |  |  |  |  |
| Automation and Analytics | $ | 148,427 |  |  | $ | 157 |  |  | $ | 148,584 |  |
| Medication Adherence | 32,458 |  |  | — |  |  | 32,458 |  |
| Gross profit |  |  |  |  |  |
| Automation and Analytics | 67,711 |  |  | 157 |  |  | 67,868 |  |
| Medication Adherence | 10,264 |  |  | — |  |  | 10,264 |  |
| Selling, general, and administrative expenses | 63,468 |  |  | (1,546 | ) |  | 61,922 |  |
| Provision for (benefit from) income taxes | (3,045 | ) |  | 660 |  |  | (2,385 | ) |
| Net income | $ | 837 |  |  | $ | 1,043 |  |  | $ | 1,880 |  |
| Net income per share | $ | 0.02 |  |  | $ | 0.03 |  |  | $ | 0.05 |  |

- changed (2018-11-02):
[0000926326-18-000030:note_history:19]
|  | Nine months ended September 30, 2017 |
|  | As reported |  | Adjustment |  | As adjusted |
|  | (In thousands) |
| Revenues |  |  |  |  |  |
| Automation and Analytics | $ | 427,249 |  |  | $ | (1,878 | ) |  | $ | 425,371 |  |
| Medication Adherence | 90,972 |  |  | — |  |  | 90,972 |  |
| Gross profit |  |  |  |  |  |
| Automation and Analytics | 198,032 |  |  | (1,878 | ) |  | 196,154 |  |
| Medication Adherence | 28,988 |  |  | — |  |  | 28,988 |  |
| Selling, general, and administrative expenses | 186,818 |  |  | (6,748 | ) |  | 180,070 |  |
| Provision for (benefit from) income taxes | (11,232 | ) |  | 1,891 |  |  | (9,341 | ) |
| Net income (loss) | $ | (3,686 | ) |  | $ | 2,979 |  |  | $ | (707 | ) |
| Net income (loss) per share - basic | $ | (0.10 | ) |  | $ | 0.08 |  |  | $ | (0.02 | ) |
| Net income (loss) per share - diluted | $ | (0.10 | ) |  | $ | 0.08 |  |  | $ | (0.02 | ) |
  (was, 2018-08-03, similarity 0.8017):
[0000926326-18-000025:note_history:19]
|  | Six months ended June 30, 2017 |
|  | As reported |  | Adjustment |  | As adjusted |
|  | (In thousands) |
| Revenues |  |  |  |  |  |
| Automation and Analytics | $ | 272,598 |  |  | $ | (1,844 | ) |  | $ | 270,754 |  |
| Medication Adherence | 58,841 |  |  | — |  |  | 58,841 |  |
| Gross profit |  |  |  |  |  |
| Automation and Analytics | 123,121 |  |  | (1,844 | ) |  | 121,277 |  |
| Medication Adherence | 19,046 |  |  | — |  |  | 19,046 |  |
| Selling, general, and administrative expenses | 128,093 |  |  | (4,231 | ) |  | 123,862 |  |
| Provision for (benefit from) income taxes | (11,983 | ) |  | 925 |  |  | (11,058 | ) |
| Net income (loss) | $ | (9,917 | ) |  | $ | 1,462 |  |  | $ | (8,455 | ) |
| Net income (loss) per share | $ | (0.27 | ) |  | $ | 0.04 |  |  | $ | (0.23 | ) |

- added (2018-11-02):
[0000926326-18-000030:note_history:20]
In August 2018, the FASB issued ASU 2018-13, Fair Value Measurement (Topic 820): Disclosure Framework—Changes to the Disclosure Requirements for Fair Value Measurement, which modifies the disclosure requirements on fair value measurements. ASU 2018-13 is effective for the Company beginning January 1, 2020, with early adoption permitted. The Company early adopted this guidance effective beginning July 1, 2018. The application of this guidance did not have a material effect on the Company’s consolidated financial statements.

- added (2018-11-02):
[0000926326-18-000030:note_history:21]
In February 2016, the FASB issued ASU No. 2016-02, Leases (Topic 842). The FASB amended lease accounting requirements to begin recording assets and liabilities arising from most leases on the balance sheet. The new guidance will also require significant additional disclosures about the amount and timing of cash flows from leases. This new guidance will be effective for the Company beginning January 1, 2019. In July 2018, the FASB issued amendments in ASU No. 2018-11, which provide a transition election to not restate comparative periods for the effects of applying the new standard. This transition election permits entities to change the date of initial application to the beginning of the year of adoption and to recognize the effects of applying the new standard as a cumulative-effect adjustment to the opening balance of retained earnings. The Company expects to elect this transition approach and recognize the cumulative impact of adoption in the opening balance of retained earnings as of January 1, 2019. The Company is in the process of completing a qualitative and quantitative assessment of the lease portfolio, implementing a new lease accounting system and implementing new processes and controls to account for leases in accordance with the new standard. The Company believes the most significant changes to the financial statements will relate to the recognition of right-of-use assets and offsetting lease liabilities in the consolidated balance sheet for operating leases. The actual impact on the consolidated balance sheet will be contingent upon the Company's population of operating leases at adoption, however the Company does not expect the standard to have a material impact on cash flows or results of operations.

- added (2018-11-02):
[0000926326-18-000030:note_history:22]
In August 2018, the FASB issued ASU 2018-15, Intangibles—Goodwill and Other—Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract, to align the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software (and hosting arrangements that include an internal-use software license). ASU 2018-15 will be effective for the Company beginning January 1, 2020. The Company is currently evaluating the impact ASU 2018-15 will have on its consolidated financial statements.

- removed (2018-11-02):
[0000926326-18-000025:note_history:23]
In February 2016, the FASB issued ASU No. 2016-02, Leases (Topic 842). The FASB amended lease accounting requirements to begin recording assets and liabilities arising from most leases on the balance sheet. The new guidance will also require significant additional disclosures about the amount and timing of cash flows from leases. This new guidance will be effective for the Company beginning January 1, 2019 using a modified retrospective approach. The modified retrospective approach includes a number of optional practical expedients that entities may elect to apply. The Company is currently evaluating the impact ASU 2016-02 will have on its consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2018-11-02):
[0000926326-18-000030:note_history:24]
In connection with these Facilities, the Company incurred $10.1 million of debt issuance costs. The debt issuance costs were capitalized and presented as a direct deduction from the carrying amount of that debt liability in accordance with the accounting guidance. The debt issuance costs are being amortized to interest expense using the straight line method from issuance date through 2021. Interest expense (exclusive of fees and issuance cost amortization) was approximately $1.9 million and $1.6 million for the three months ended September 30, 2018 and 2017, respectively, and approximately $5.7 million and $4.6 million for the nine months ended September 30, 2018 and 2017, respectively. Amortization expense related to fees and issuance cost was approximately $0.6 million and $0.4 million for the three months ended September 30, 2018 and 2017, respectively, and approximately $1.7 million and $1.2 million for the nine months ended September 30, 2018 and 2017, respectively. The Company was in compliance with all covenants as of September 30, 2018 and December 31, 2017.

- changed (2018-11-02):
[0000926326-18-000030:note_history:25]
During the nine months ended September 30, 2018, the Company repaid $27.0 million under these Facilities.
  (was, 2018-08-03, similarity 0.914):
[0000926326-18-000025:note_history:25]
During the six months ended June 30, 2018, the Company repaid $12.5 million under these Facilities.

- changed (2018-11-02):
[0000926326-18-000030:note_history:26]
The components of the Company’s debt obligations as of September 30, 2018 and December 31, 2017 were as follows:
  (was, 2018-08-03, similarity 0.9447):
[0000926326-18-000025:note_history:26]
The components of the Company’s debt obligations as of June 30, 2018 and December 31, 2017 were as follows:

- added (2018-11-02):
[0000926326-18-000030:note_history:27]
|  | December 31, 2017 |  | Borrowings |  | Repayment / Amortization |  | September 30, 2018 |
|  | (In thousands) |
| Term loan facility | $ | 182,500 |  |  | $ | — |  |  | $ | (12,500 | ) |  | $ | 170,000 |  |
| Revolving credit facility | 34,500 |  |  | — |  |  | (14,500 | ) |  | 20,000 |  |
| Total debt under the facilities | 217,000 |  |  | — |  |  | (27,000 | ) |  | 190,000 |  |
| Less: Deferred issuance cost | (6,875 | ) |  | — |  |  | 1,718 |  |  | (5,157 | ) |
| Total debt, net of deferred issuance cost | $ | 210,125 |  |  | $ | — |  |  | $ | (25,282 | ) |  | $ | 184,843 |  |
| Long term debt, current portion, net of deferred issuance cost | 15,208 |  |  |  |  |  |  | 17,708 |  |
| Long term debt, net of deferred issuance cost | $ | 194,917 |  |  |  |  |  |  | $ | 167,135 |  |

- changed (2018-11-02):
[0000926326-18-000030:note_history:28]
As of September 30, 2018, the carrying amount of debt of $190.0 million approximates the comparable fair value of $192.6 million. The Company’s debt facilities are classified as a Level 3 in the fair value hierarchy. The calculation of the fair value is based on a discounted cash flow model using observable market inputs and taking into consideration variables such as interest rate changes, comparable instruments and long-term credit ratings. There have been no significant changes in the assumptions used as of September 30, 2018 as compared to the period as of December 31, 2017.
  (was, 2018-08-03, similarity 0.8883):
[0000926326-18-000025:note_history:28]
As of June 30, 2018, the carrying amount of debt of $204.5 million approximates the comparable fair value of $207.4 million. The Company’s debt facilities are classified as a Level 3 in the fair value hierarchy. The calculation of the fair value is based on a discounted cash flow model using observable market inputs and taking into consideration variables such as interest rate changes, comparable instruments and long-term credit ratings. There have been no significant changes in the assumptions used as of June 30, 2018 as compared to the period as of December 31, 2017.

- removed (2018-11-02):
[0000926326-18-000025:note_history:29]
In connection with these Facilities, the Company incurred $10.1 million of debt issuance costs. The debt issuance costs were capitalized and presented as a direct deduction from the carrying amount of that debt liability in accordance with the accounting guidance. The debt issuance costs are being amortized to interest expense using the straight line method from issuance date through 2021. Interest expense (exclusive of fees and issuance cost amortization) was approximately $1.9 million and $1.5 million for the three months ended June 30, 2018 and 2017, respectively, and approximately $3.8 million and $3.0 million for the six months ended June 30, 2018 and 2017, respectively. Amortization expense related to fees and issuance cost was approximately $0.6 million and $0.4 million for the three months ended June 30, 2018 and 2017, respectively, and approximately $1.1 million and $0.8 million for the six months ended June 30, 2018 and 2017, respectively. The Company was in compliance with all covenants as of June 30, 2018 and December 31, 2017.

- removed (2018-11-02):
[0000926326-18-000025:note_history:30]
|  | December 31, 2017 |  | Borrowings |  | Repayment / Amortization |  | June 30, 2018 |
|  | (In thousands) |
| Term loan facility | $ | 182,500 |  |  | $ | — |  |  | $ | (7,500 | ) |  | $ | 175,000 |  |
| Revolving credit facility | 34,500 |  |  | — |  |  | (5,000 | ) |  | 29,500 |  |
| Total debt under the facilities | 217,000 |  |  | — |  |  | (12,500 | ) |  | 204,500 |  |
| Less: Deferred issuance cost | (6,875 | ) |  | — |  |  | 1,145 |  |  | (5,730 | ) |
| Total debt, net of deferred issuance cost | $ | 210,125 |  |  | $ | — |  |  | $ | (11,355 | ) |  | $ | 198,770 |  |
| Long term debt, current portion, net of deferred issuance cost | 15,208 |  |  |  |  |  |  | 17,708 |  |
| Long term debt, net of deferred issuance cost | $ | 194,917 |  |  |  |  |  |  | $ | 181,062 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-11-02):
[0000926326-18-000030:note_history:31]
The components of the Company’s debt obligations as of September 30, 2018 and December 31, 2017 were as follows:
  (was, 2018-08-03, similarity 0.9447):
[0000926326-18-000025:note_history:31]
The components of the Company’s debt obligations as of June 30, 2018 and December 31, 2017 were as follows:

- added (2018-11-02):
[0000926326-18-000030:note_history:32]
|  | December 31, 2017 |  | Borrowings |  | Repayment / Amortization |  | September 30, 2018 |
|  | (In thousands) |
| Term loan facility | $ | 182,500 |  |  | $ | — |  |  | $ | (12,500 | ) |  | $ | 170,000 |  |
| Revolving credit facility | 34,500 |  |  | — |  |  | (14,500 | ) |  | 20,000 |  |
| Total debt under the facilities | 217,000 |  |  | — |  |  | (27,000 | ) |  | 190,000 |  |
| Less: Deferred issuance cost | (6,875 | ) |  | — |  |  | 1,718 |  |  | (5,157 | ) |
| Total debt, net of deferred issuance cost | $ | 210,125 |  |  | $ | — |  |  | $ | (25,282 | ) |  | $ | 184,843 |  |
| Long term debt, current portion, net of deferred issuance cost | 15,208 |  |  |  |  |  |  | 17,708 |  |
| Long term debt, net of deferred issuance cost | $ | 194,917 |  |  |  |  |  |  | $ | 167,135 |  |

- removed (2018-11-02):
[0000926326-18-000025:note_history:33]
|  | December 31, 2017 |  | Borrowings |  | Repayment / Amortization |  | June 30, 2018 |
|  | (In thousands) |
| Term loan facility | $ | 182,500 |  |  | $ | — |  |  | $ | (7,500 | ) |  | $ | 175,000 |  |
| Revolving credit facility | 34,500 |  |  | — |  |  | (5,000 | ) |  | 29,500 |  |
| Total debt under the facilities | 217,000 |  |  | — |  |  | (12,500 | ) |  | 204,500 |  |
| Less: Deferred issuance cost | (6,875 | ) |  | — |  |  | 1,145 |  |  | (5,730 | ) |
| Total debt, net of deferred issuance cost | $ | 210,125 |  |  | $ | — |  |  | $ | (11,355 | ) |  | $ | 198,770 |  |
| Long term debt, current portion, net of deferred issuance cost | 15,208 |  |  |  |  |  |  | 17,708 |  |
| Long term debt, net of deferred issuance cost | $ | 194,917 |  |  |  |  |  |  | $ | 181,062 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2018-11-02):
[0000926326-18-000030:note_history:34]
Software. Additional software applications that enable incremental functionality of the Company’s equipment.
  (was, 2018-08-03, similarity 0.9417):
[0000926326-18-000025:note_history:34]
Software. Additional software applications that enable incremental functionality of its equipment.

- changed (2018-11-02):
[0000926326-18-000030:note_history:35]
Installation. Installation of equipment as integrated systems at customer sites.
  (was, 2018-08-03, similarity 0.9877):
[0000926326-18-000025:note_history:35]
Installation. Installation of equipment as integrated systems at customers’ sites.

- changed (2018-11-02):
[0000926326-18-000030:note_history:36]
The transaction price is allocated to separate performance obligations proportionally based on the standalone selling price of each performance obligation. Standalone selling price is best evidenced by the price the Company charges for the good or service when selling it separately in similar circumstances to similar customers. Other than for the renewal of annual support services contracts, the Company’s products and services are not generally sold separately. The Company uses an expected cost plus a margin approach to identify the standalone selling price of goods where separate sales transactions do not exist. For software and services which do not have a specific identifiable product cost, the Company uses an amount discounted from the list price as a best estimated selling price.
  (was, 2018-08-03, similarity 0.9515):
[0000926326-18-000025:note_history:36]
The transaction price is allocated to separate performance obligations proportionally based on the standalone selling price of each performance obligation. Standalone selling price is best evidenced by the price the Company charges for the good or service when selling it separately in similar circumstances to similar customers. Other than for the renewal of annual support services contracts, the Company’s products and services are not generally sold separately. The Company uses an expected cost plus a margin approach to identify the standalone selling price of goods where separate sales transactions do not exist. For software and services which do not have a specific identifiable product cost, the Company uses a discounted from the list price amount as a best estimated selling price.

- changed (2018-11-02):
[0000926326-18-000030:note_history:37]
The Company recognizes revenue when the performance obligation has been satisfied by transferring a promised good or service to a customer. The good or service is transferred when or as the customer obtains control of the good or service. Determining when control transfers requires management to make judgments that affect the timing of revenues recognized. Generally, for products requiring a complex implementation, control passes when the product is installed and ready for use. For all other products, control generally passes when product has been shipped and title has passed. For maintenance contracts and certain other services provided on a subscription basis, control passes to the customer over time, generally ratably over the service term as the Company provides a stand-ready service to service the customer’s equipment. Time and material services transfer control to the customer at the time the services are provided. The portion of the transaction price allocated to the Company’s unsatisfied performance obligations recorded as deferred revenues at September 30, 2018 and December 31, 2017 were $98.4 million and $89.4 million, respectively, of which $87.8 million and $78.8 million, respectively, are expected to be completed within one year. Remaining performance obligations primarily relate to maintenance contracts and are recognized ratably over the remaining term of the contract, generally not more than five years.
  (was, 2018-08-03, similarity 0.9852):
[0000926326-18-000025:note_history:37]
The Company recognizes revenue when the performance obligation has been satisfied by transferring a promised good or service to a customer. The good or service is transferred when or as the customer obtains control of the good or service. Determining when control transfers requires management to make judgments that affect the timing of revenues recognized. Generally, for products requiring a complex implementation, control passes when the product is installed and ready for use. For all other products, control generally passes when product has been shipped and title has passed. For maintenance contracts and certain other services provided on a subscription basis, control passes to the customer over time, generally ratably over the service term as the Company provides a stand-ready service to service the customer’s equipment. Time and material services transfer control to the customer at the time the services are provided. The portion of the transaction price allocated to the Company’s unsatisfied performance obligations recorded as deferred revenues at June 30, 2018 and December 31, 2017 was $94.7 million and $89.4 million, respectively, of which $85.8 million and $78.8 million, respectively, are expected to be completed within one year. Remaining performance obligations primarily relate to maintenance contracts and are recognized ratably over the remaining term of the contract, generally not more than five years.

- changed (2018-11-02):
[0000926326-18-000030:note_history:38]
A portion of the Company's sales are made through multi-year lease agreements. Under sales-type leases, the Company recognizes revenue for its hardware and software products net of lease execution costs, such as post-installation product maintenance and technical support, at the net present value of the lease payment stream once its installation obligations have been met. The Company optimizes cash flows by selling a majority of its non-U.S. government leases to third-party leasing finance companies on a non-recourse basis. The Company has no obligation to the leasing company once the lease has been sold. Some of the Company's sales-type leases, mostly those relating to U.S. government hospitals which comprise approximately 44% of the lease receivable balance, are retained in-house. Revenues from sales-type leases of $11.4 million and $5.9 million for the three months ended September 30, 2018 and 2017, respectively, and $28.8 million and $19.3 million for the nine months ended September 30, 2018 and 2017, respectively, are included in product revenues in the Condensed Consolidated Statements of Operations. Interest income in these leases is recognized in product revenues using the effective interest method.
  (was, 2018-08-03, similarity 0.9744):
[0000926326-18-000025:note_history:38]
A portion of the Company's sales are made through multi-year lease agreements. Under sales-type leases, the Company recognizes revenue for its hardware and software products net of lease execution costs, such as post-installation product maintenance and technical support, at the net present value of the lease payment stream once its installation obligations have been met. The Company optimizes cash flows by selling a majority of its non-U.S. government leases to third-party leasing finance companies on a non-recourse basis. The Company has no obligation to the leasing company once the lease has been sold. Some of the Company's sales-type leases, mostly those relating to U.S. government hospitals which comprise approximately 42% of the lease receivable balance, are retained in-house. Revenues from sales-type leases of $7.6 million and $10.2 million for the three months ended June 30, 2018 and 2017, respectively, and $17.4 million and $13.4 million for the six months ended June 30, 2018 and 2017, respectively, are included in product revenues in the Condensed Consolidated Statements of Operations. Interest income in these leases is recognized in product revenues using the effective interest method.

- changed (2018-11-02):
[0000926326-18-000030:note_history:39]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”). GPOs are often owned fully or in part by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs were $2.2 million and $2.1 million for the three months ended September 30, 2018 and 2017, respectively, and $6.2 million and $5.4 million for the nine months ended September 30, 2018 and 2017, respectively.
  (was, 2018-08-03, similarity 0.9434):
[0000926326-18-000025:note_history:39]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”). GPOs are often owned fully or in part by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs were $2.1 million and $1.2 million for the three months ended June 30, 2018 and 2017, respectively, and $4.0 million and $3.3 million for the six months ended June 30, 2018 and 2017, respectively.

- changed (2018-11-02):
[0000926326-18-000030:note_history:40]
The Company has determined that the incentive portions of its sales commission plans require capitalization since these payments are directly related to sales achieved during a time period. These commissions are earned on the basis of the total purchase order value of new product bookings. Since there are not commensurate commissions earned on renewal of the service bookings, the Company concluded that the capitalized asset is related to services provided under both the initial contract and renewal periods. The Company applies a practical expedient to account for the incremental costs of obtaining a contract to a portfolio of contracts with similar characteristics as the Company expects the effect on the financial statements of applying the practical expedient would not differ materially from applying the accounting guidance to the individual contracts within the portfolio. A pool of contracts is defined as all contracts booked in a particular quarter. The amortization for the capitalized asset is an estimate of the pool’s original contract term, generally one to five years, plus an estimate of future customer renewal periods resulting in a total amortization period of ten years. Costs to obtain a contract are allocated amongst performance obligations and recognized as sales and marketing expense consistent with the pattern of revenue recognition. Capitalized costs are periodically reviewed for impairment. A portion of the pool’s capitalized asset is recorded as an expense after two quarters, which represents the estimated period during which the product revenue associated with the contract is recorded.
  (was, 2018-08-03, similarity 0.9634):
[0000926326-18-000025:note_history:40]
The Company has determined that the incentive portions of its sales commission plans require capitalization since these payments are directly related to sales achieved during a time period. These commissions are earned on the basis of the total purchase order value of new product bookings. Since there are not commensurate commissions earned on renewal of the service bookings, the Company concluded that the capitalized asset is related to services provided under both the initial contract and renewal periods. The Company applies a practical expedient to account for the incremental costs of obtaining a contract to a portfolio of contracts with similar characteristics as the Company expects the effect on the financial statements of applying the practical expedient would not differ materially from applying the accounting guidance to the individual contracts within the portfolio. A pool of contracts is defined as all contracts booked in a particular quarter. The amortization for the capitalized asset is an estimate of the pool’s original contract term, generally one to five years, plus an estimate of future customer renewal periods resulting in a total amortization period of ten years. Costs to obtain a contract are allocated amongst performance obligations and recognized as sales and marketing expense consistent with the pattern of revenue recognition. Capitalized costs are periodically reviewed for impairment. A portion of the pool’s capitalized asset is recorded as an expense after two quarters, which represents the estimated period during which the product revenue associated with the contract is recorded. The remaining contract cost is recorded as expense ratably over the ten year estimated initial and renewal service periods.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2018-11-02):
[0000926326-18-000030:note_history:41]
Short-term deferred revenues of $87.8 million and $78.8 million include deferred revenues from product sales and service contracts, net of deferred cost of sales of $14.9 million and $16.9 million as of September 30, 2018 and December 31, 2017, respectively. The short-term deferred revenues from product sales relate to delivered and invoiced products, pending installation and acceptance, expected to occur within the next twelve months.
  (was, 2018-08-03, similarity 0.9843):
[0000926326-18-000025:note_history:41]
Short-term deferred revenues of $85.8 million and $78.8 million include deferred revenues from product sales and service contracts, net of deferred cost of sales of $14.6 million and $16.9 million as of June 30, 2018 and December 31, 2017, respectively. The short-term deferred revenues from product sales relate to delivered and invoiced products, pending installation and acceptance, expected to occur within the next twelve months.

- changed (2018-11-02):
[0000926326-18-000030:note_history:42]
Long-term deferred revenues include deferred revenues from service contracts of $10.6 million as of both September 30, 2018 and December 31, 2017.
  (was, 2018-08-03, similarity 0.838):
[0000926326-18-000025:note_history:42]
Long-term deferred revenues include deferred revenues from service contracts of $9.0 million and $10.6 million, as of June 30, 2018 and December 31, 2017, respectively.
