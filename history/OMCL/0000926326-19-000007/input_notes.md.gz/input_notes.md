# OMCL notes — 0000926326-19-000007


## omcl:CostofGoodsandServicesSoldPolicyPolicyTextBlock

[0000926326-19-000007:notes:1]
Shipping Costs

[0000926326-19-000007:notes:2]
Outbound freight billed to customers is recorded as product revenue. The related shipping and handling costs are expensed as part of selling, general, and administrative expense.


## omcl:ScheduleofSharebasedCompensationFutureIssuanceofSharesTableTextBlock

[0000926326-19-000007:notes:3]
The Company had the following ordinary shares reserved for future issuance under its equity incentive plans as of December 31, 2018:

[0000926326-19-000007:notes:4]
|  | Number of Shares |
|  | (In thousands) |
| Share options outstanding | 3,748 |  |
| Non-vested restricted stock awards | 755 |  |
| Shares authorized for future issuance | 2,431 |  |
| ESPP shares available for future issuance | 1,913 |  |
| Total shares reserved for future issuance | 8,847 |  |


## srt:ScheduleOfCondensedBalanceSheetTableTextBlock

[0000926326-19-000007:notes:5]
Balance sheet details as of December 31, 2018 and December 31, 2017 are presented in the tables below:

[0000926326-19-000007:notes:6]
|  | December 31, |
|  | 2018 |  | 2017 |
|  | (In thousands) |
| Inventories: |  |  |  |
| Raw materials | $ | 32,511 |  |  | $ | 31,275 |  |
| Work in process | 8,726 |  |  | 8,718 |  |
| Finished goods | 59,631 |  |  | 56,144 |  |
| Total inventories | $ | 100,868 |  |  | $ | 96,137 |  |
| Property and equipment: |  |  |  |
| Equipment | $ | 75,417 |  |  | $ | 69,550 |  |
| Furniture and fixtures | 7,844 |  |  | 6,534 |  |
| Leasehold improvements | 16,274 |  |  | 10,976 |  |
| Software | 42,048 |  |  | 37,168 |  |
| Construction in progress | 10,706 |  |  | 9,813 |  |
| Property and equipment, gross | 152,289 |  |  | 134,041 |  |
| Accumulated depreciation and amortization | (100,789 | ) |  | (91,446 | ) |
| Total property and equipment, net | $ | 51,500 |  |  | $ | 42,595 |  |
| Other long-term assets: |  |  |  |
| Capitalized software, net | $ | 56,819 |  |  | $ | 38,599 |  |
| Unbilled receivables | 16,481 |  |  | 9,475 |  |
| Other assets | 1,313 |  |  | 1,242 |  |
| Total other long-term assets, net | $ | 74,613 |  |  | $ | 49,316 |  |
| Accrued liabilities: |  |  |  |
| Advance payments from customers | $ | 8,993 |  |  | $ | 7,779 |  |
| Rebates and lease buyouts | 11,076 |  |  | 5,428 |  |
| Group purchasing organization fees | 4,455 |  |  | 3,449 |  |
| Taxes payable | 5,885 |  |  | 9,183 |  |
| Other accrued liabilities | 12,638 |  |  | 9,854 |  |
| Total accrued liabilities | $ | 43,047 |  |  | $ | 35,693 |  |


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000926326-19-000007:notes:7]
SCHEDULE II

[0000926326-19-000007:notes:8]
VALUATION AND QUALIFYING ACCOUNTS

[0000926326-19-000007:notes:9]
|  | Balance atBeginning of Period (1) |  | Charged (Credited) to Costs and Expenses (2) |  | Debited (Credited) to Other Accounts (3) |  | AmountWritten Off (4) |  | Acquisition and Translation Adjustments (5) |  | Balance atEnd of Period (1) |
|  | (In thousands) |
| Year ended December 31, 2016 |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable | $ | 1,240 |  |  | $ | 727 |  |  | $ | 77 |  |  | $ | (369 | ) |  | $ | 3,121 |  |  | $ | 4,796 |  |
| Investment in sales-type leases | 169 |  |  | 85 |  |  | — |  |  | — |  |  | — |  |  | 254 |  |
| Total allowances deducted from assets | $ | 1,409 |  |  | $ | 812 |  |  | $ | 77 |  |  | $ | (369 | ) |  | $ | 3,121 |  |  | $ | 5,050 |  |
| Year ended December 31, 2017 |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable | $ | 4,796 |  |  | $ | 1,008 |  |  | $ | 3 |  |  | $ | (402 | ) |  | $ | 333 |  |  | $ | 5,738 |  |
| Investment in sales-type leases | 254 |  |  | (62 | ) |  | — |  |  | — |  |  | — |  |  | 192 |  |
| Total allowances deducted from assets | $ | 5,050 |  |  | $ | 946 |  |  | $ | 3 |  |  | $ | (402 | ) |  | $ | 333 |  |  | $ | 5,930 |  |
| Year ended December 31, 2018 |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable | $ | 5,738 |  |  | $ | (127 | ) |  | $ | 12 |  |  | $ | (3,010 | ) |  | $ | (31 | ) |  | $ | 2,582 |  |
| Investment in sales-type leases | 192 |  |  | 10 |  |  | 12 |  |  | — |  |  | — |  |  | 214 |  |
| Total allowances deducted from assets | $ | 5,930 |  |  | $ | (117 | ) |  | $ | 24 |  |  | $ | (3,010 | ) |  | $ | (31 | ) |  | $ | 2,796 |  |

[0000926326-19-000007:notes:10]
__________________________________________________

[0000926326-19-000007:notes:11]
| (1) | Allowance for doubtful accounts. |

[0000926326-19-000007:notes:12]
| (2) | Represents amounts charged and credited to bad debt expense. |

[0000926326-19-000007:notes:13]
| (3) | Represents amounts debited to trade accounts receivable as recoveries, increasing the allowance. |

[0000926326-19-000007:notes:14]
| (4) | Represents amounts written-off from the allowance and trade accounts receivable. |

[0000926326-19-000007:notes:15]
| (5) | Represents primarily purchase price adjustments and minor foreign currency translation adjustments. |


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0000926326-19-000007:notes:16]
The pro forma adjustments include the impact of fair value adjustment related to deferred revenues, inventory fair value adjustment, amortization of intangible assets, share-based compensation expense, interest expense and amortization of deferred issuance cost, and certain classification to conform to the Company’s accounting policies.

[0000926326-19-000007:notes:17]
|  | Year Ended December 31, |
|  | 2017 (1) |  | 2016 (1) |
|  | (In thousands, except per share data) |
| Pro forma net revenues | $ | 713,272 |  |  | $ | 723,085 |  |
| Pro forma net income | $ | 30,683 |  |  | $ | 8,109 |  |
| Pro forma net income per share | $ | 0.82 |  |  | $ | 0.22 |  |
| Weighted-average number of shares | 37,483 |  |  | 36,156 |  |

[0000926326-19-000007:notes:18]
___________________________________________

[0000926326-19-000007:notes:19]
| (1) | As adjusted for full retrospective adoption of ASC 606. |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000926326-19-000007:notes:20]
Business Combinations

[0000926326-19-000007:notes:21]
2017 Acquisitions

[0000926326-19-000007:notes:22]
On April 12, 2017, the Company completed the acquisition of all of the membership interest of Dixie Drawl, LLC d/b/a InPharmics (“InPharmics”). InPharmics is a technology and services company that provides advanced pharmacy informatics solutions to hospital pharmacies. The total consideration for the transaction was $5.0 million, net of cash acquired of $0.3 million. Approximately $0.5 million of the total consideration was classified as a long-term liability for potential settlement of performance obligations. The Company accounted for the acquisition of InPharmics in accordance with the authoritative guidance on business combinations; therefore, the tangible and intangible assets acquired and liabilities assumed were recorded at fair value on the acquisition date. The purchase price was allocated to intangible assets in the amount of $1.9 million, which included developed technology and customer contracts, with the remainder allocated to goodwill. The results of the InPharmics’ operations have been included in the consolidated results of operations, and presented as part of the Automation and Analytics segment.

[0000926326-19-000007:notes:23]
2016 Acquisitions

[0000926326-19-000007:notes:24]
On January 5, 2016, the Company completed the acquisition of all of the membership interests of Aesynt. Aesynt is a provider of automated medication management systems, including dispensing robots with storage solutions, medication storage and dispensing carts and cabinets, I.V. sterile preparation robotics and software, including software related to medication management. The total consideration was $271.5 million, net of cash acquired of $8.2 million. The results of Aesynt’s operations have been included in the consolidated results of operations as of the time of the acquisition, and presented as part of the Automation and Analytics segment.

[0000926326-19-000007:notes:25]
On December 8, 2016, the Company completed its acquisition of ateb, Inc., and Ateb Canada Ltd. (together, “Ateb”) for $40.7 million of cash consideration, net of $0.9 million cash on hand. The cash consideration, included the repayment of Ateb indebtedness and other adjustments provided for in the Ateb’s Securities Purchase Agreement. Ateb is a provider of pharmacy-based patient care and medication synchronization solutions to independent and chain pharmacies. The results of Ateb’s operations have been included in the consolidated results of operations as of the time of the acquisition, and presented as part of the Medication Adherence segment.

[0000926326-19-000007:notes:26]
The Company accounted for the acquisitions of Aesynt and Ateb in accordance with the authoritative guidance on business combinations; therefore, the tangible and intangible assets acquired and liabilities assumed were recorded at fair value on the acquisition dates, respectively. The Company incurred approximately $9.3 million in acquisition-related costs related to the Aesynt acquisition of which $6.4 million was recognized in the year ended December 31, 2016. During the year ended December 31, 2016, the Company incurred and expensed approximately $1.7 million of acquisition-related costs for Ateb. These costs are included in selling, general, and administrative expenses in the Company’s Consolidated Statement of Operations.

[0000926326-19-000007:notes:27]
Pro Forma Financial Information

[0000926326-19-000007:notes:28]
The following table presents certain unaudited pro forma information for illustrative purposes only, for the years ended December 31, 2017 and December 31, 2016 as if these acquisitions had been completed on January 1, 2016. The pro forma information is not indicative of what would have occurred had the acquisitions taken place on January 1, 2016. The unaudited pro forma information combines the historical results of the acquisitions with the Company’s consolidated historical results and includes certain adjustments reflecting the estimated impact of fair value adjustments for the respective periods. The pro forma adjustments include the impact of fair value adjustment related to deferred revenues, inventory fair value adjustment, amortization of intangible assets, share-based compensation expense, interest expense and amortization of deferred issuance cost, and certain classification to conform to the Company’s accounting policies.


## us-gaap:CapitalLeasesInFinancialStatementsOfLessorDisclosureTextBlock

[0000926326-19-000007:notes:29]
Net Investment in Sales-Type Leases

[0000926326-19-000007:notes:30]
On a recurring basis, the Company enters into sales-type lease transactions with the majority varying in length from one to five years. The receivables as a result of these types of transactions are collateralized by the underlying equipment leased and consist of the following components at December 31, 2018 and December 31, 2017:

[0000926326-19-000007:notes:31]
|  | December 31, |
|  | 2018 |  | 2017 |
|  | (In thousands) |
| Net minimum lease payments to be received | $ | 28,295 |  |  | $ | 25,899 |  |
| Less: unearned interest income portion | (2,477 | ) |  | (1,695 | ) |
| Net investment in sales-type leases | 25,818 |  |  | 24,204 |  |
| Less: short-term portion(1) | (8,736 | ) |  | (8,769 | ) |
| Long-term net investment in sales-type leases | $ | 17,082 |  |  | $ | 15,435 |  |

[0000926326-19-000007:notes:32]
_________________________________________________

[0000926326-19-000007:notes:33]
| (1) | The short-term portion of the net investment in sales-type leases is included in other current assets in the Consolidated Balance Sheets. |

[0000926326-19-000007:notes:34]
The carrying amount of the Company’s sales-type lease receivables is a reasonable estimate of fair value, as the unearned interest income is immaterial.

[0000926326-19-000007:notes:35]
The Company evaluates its sales-type leases individually and collectively for impairment. The allowance for credit losses was $0.2 million as of both December 31, 2018 and December 31, 2017.

[0000926326-19-000007:notes:36]
At December 31, 2018, the future minimum lease payments under sales-type leases were as follows:

[0000926326-19-000007:notes:37]
|  | December 31, 2018 |
|  | (In thousands) |
| 2019 | $ | 9,899 |  |
| 2020 | 7,018 |  |
| 2021 | 4,779 |  |
| 2022 | 4,084 |  |
| 2023 | 2,178 |  |
| Thereafter | 337 |  |
| Total | $ | 28,295 |  |


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0000926326-19-000007:notes:38]
Cash and Cash Equivalents and Fair Value of Financial Instruments. The Company classifies investments as cash equivalents if their original or remaining contractual maturity is three months or less at the date of purchase. Cash equivalents are carried at amounts that approximate fair value due to the short period of time to maturity. The Company’s cash balances are maintained in demand deposit accounts with financial institutions of high credit quality. The Company continuously monitors the credit worthiness of the financial institutions in which it invests. The Company has not experienced any credit losses from its cash investments.


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000926326-19-000007:notes:39]
Commitments and Contingencies

[0000926326-19-000007:notes:40]
Lease Commitments

[0000926326-19-000007:notes:41]
The Company leases office space and office equipment under operating leases. Commitments under operating leases primarily relate to leasehold property and office equipment. Rent expense was $12.7 million, $11.5 million, and $9.8 million for the years ended December 31, 2018, December 31, 2017, and December 31, 2016, respectively.

[0000926326-19-000007:notes:42]
The minimum future payments on non-cancelable operating leases were as follows:

[0000926326-19-000007:notes:43]
|  | December 31, 2018 |
|  | (In thousands) |
| 2019 | $ | 14,153 |  |
| 2020 | 13,104 |  |
| 2021 | 12,729 |  |
| 2022 | 11,809 |  |
| 2023 | 8,334 |  |
| Thereafter | 27,289 |  |
| Total minimum future lease payments | $ | 87,418 |  |

[0000926326-19-000007:notes:44]
Purchase Obligations

[0000926326-19-000007:notes:45]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of December 31, 2018, the Company had non-cancelable purchase commitments of $52.2 million, of which $50.2 million is expected to be paid within the next twelve months.

[0000926326-19-000007:notes:46]
Legal Proceedings

[0000926326-19-000007:notes:47]
The Company is currently involved in various legal proceedings. As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any accrual for contingent liabilities associated with the legal proceedings described below based on its belief that any potential loss, while reasonably possible, is not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of this contingency or because of the diversion of management’s attention and the creation of significant expenses.

[0000926326-19-000007:notes:48]
On January 10, 2018, a lawsuit was filed against a number of individuals, governmental agencies, and corporate entities, including the Company and one of its subsidiaries, Aesynt Incorporated (“Aesynt”), in the Circuit Court for the City of Richmond, Virginia, captioned Ruth Ann Warner, as Guardian of Jonathan James Brewster Warner v. Centra Health, Inc., et al., Case No. CL18-152-1. The complaint seeks monetary recovery of compensatory and punitive damages in addition to certain declaratory relief based upon, as against the individuals, governmental agencies, and corporate entities other than the Company and Aesynt, allegations of the use of excessive force, unlawful detention, false imprisonment, battery, simple and gross negligence and negligent hiring, detention, and training; and, as against the Company and Aesynt, claims of product liability, negligence, and breach of implied warranties. The Company and Aesynt have not yet been served with the complaint. The Company intends to defend the lawsuit vigorously.

[0000926326-19-000007:notes:49]
On June 6, 2018, a class-action lawsuit was filed against a customer of the Company, the customer’s parent company and two vendors of medication dispensing systems, one of which is the Company, in the Circuit Court of Cook County, Illinois, Chancery Division, captioned Yana Mazya, individually and on behalf of all others similarly situated v. Northwestern Lake Forest Hospital, Northwestern Memorial Healthcare, Omnicell, Inc. and Becton Dickinson, Case No. 2018-CH-07161. The complaint seeks class certification, monetary damages in the form of statutory damages for willful and/or reckless or, in the alternative, negligent violation of the Illinois Biometric Information Privacy Act (“BIPA”), and certain declaratory, injunctive, and other relief based on causes of action directed to allegations of violation of BIPA and of negligence by the defendants. The complaint was served on the Company on June 15, 2018. The Company’s obligation to respond to the complaint was held in abeyance pending a decision of the Illinois Supreme Court in a separate case involving BIPA issues. The Illinois Supreme Court issued its decision in that case on January 25, 2019. In a status conference conducted by the court on February 20, 2019, the court established a deadline of April 12, 2019 for the defendants to answer or otherwise respond to the complaint. The Company intends to defend the lawsuit vigorously.

[0000926326-19-000007:notes:50]
A declaratory judgment action was filed against the Company, on August 30, 2018, in the United States District Court for the Northern District of California, captioned Zurich American Insurance Company; American Guarantee & Liability Company v. Omnicell, Inc. and Does 1-10, inclusive, Case No. 3:18-CV-05345. The complaint seeks a declaration that the plaintiffs have no duty to defend or indemnify the Company in connection with the underlying litigation, the Yana Mazya, et al. v. Northwestern Lake Forest Hospital, et al., Case No. 2018-CH-07161 pending in the Circuit Court of Cook County, Illinois, Chancery Division (“Underlying Action”), disclosed above, together with claims for reimbursement and unjust enrichment relating to the defense of the Underlying Action in the form of attorneys’ fees and other related costs. The Company has not responded to the complaint. On February 12, 2019, the court stayed the action pending the outcome of the Underlying Action and administratively closed the case. The Company intends to defend the lawsuit vigorously.

[0000926326-19-000007:notes:51]
Guarantees

[0000926326-19-000007:notes:52]
As permitted under Delaware law and the Company’s certificate of incorporation and bylaws, the Company has agreed to indemnify its directors and officers against certain losses that they may suffer by reason of the fact that such persons are, were or become its directors or officers. The term of the indemnification period is for the director’s or officer’s lifetime and there is no limit on the potential amount of future payments that the Company could be required to make under these indemnification agreements. The Company has purchased a directors’ and officers’ liability insurance policy that may enable it to recover a portion of any future payments that it may be required to make under these indemnification agreements. Assuming the applicability of coverage and the willingness of the insurer to assume coverage and subject to certain retention, loss limits and other policy provisions, the Company believes it is unlikely that the Company will be required to pay any material amounts pursuant to these indemnification obligations. However, no assurances can be given that the insurers will not attempt to dispute the validity, applicability or amount of coverage without expensive and time-consuming litigation against the insurers.

[0000926326-19-000007:notes:53]
Additionally, the Company undertakes indemnification obligations in its ordinary course of business in connection with, among other things, the licensing of its products and the provision of its support services. In the ordinary course of the Company’s business, the Company has in the past and may in the future agree to indemnify another party, generally its business affiliates or customers, against certain losses suffered or incurred by the indemnified party in connection with various types of claims, which may include, without limitation, claims of intellectual property infringement, certain tax liabilities, its gross negligence or intentional acts in the performance of support services and violations of laws. The term of these indemnification obligations is generally perpetual. In general, the Company attempts to limit the maximum potential amount of future payments that it may be required to make under these indemnification obligations to the amounts paid to it by a customer, but in some cases the obligation may not be so limited. In addition, the Company has in the past and may in the future warrant to its customers that its products will conform to functional specifications for a limited period of time following the date of installation (generally not exceeding 30 days) or that its software media is free from material defects. Sales contracts for certain of the Company’s medication packaging systems often include limited warranties for up to six months, but the periodic activity and ending warranty balances the Company records have historically been immaterial.

[0000926326-19-000007:notes:54]
From time to time, the Company may also warrant that its professional services will be performed in a good and workmanlike manner or in a professional manner consistent with industry standards. The Company generally seeks to disclaim most warranties, including any implied or statutory warranties such as warranties of merchantability, fitness for a particular purpose, title, quality and non-infringement, as well as any liability with respect to incidental, consequential, special, exemplary, punitive or similar damages. In some states, such disclaimers may not be enforceable. If necessary, the Company would provide for the estimated cost of product and service warranties based on specific warranty claims and claim history. The Company has not been subject to any significant claims for such losses and has not incurred any material costs in defending or settling claims related to these indemnification obligations. Accordingly, the Company believes it is unlikely that the Company will be required to pay any material amounts pursuant to these indemnification obligations or potential warranty claims and, therefore, no material liabilities have been recorded for such indemnification obligations as of December 31, 2018 and December 31, 2017.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000926326-19-000007:notes:55]
Employee Benefits and Share-Based Compensation

[0000926326-19-000007:notes:56]
Stock Purchase Plan

[0000926326-19-000007:notes:57]
1997 Employee Stock Purchase Plan

[0000926326-19-000007:notes:58]
The Company has an Employee Stock Purchase Plan (“ESPP”), under which employees can purchase shares of its common stock based on a percentage of their compensation, but not greater than 15% of their earnings; provided, however, an eligible employee’s right to purchase shares of the Company’s common stock may not accrue at a rate which exceeds $25,000 of the fair market value of such shares for each calendar year in which such rights are outstanding. The purchase price per share must be equal to the lower of 85% of the fair value of the common stock at the beginning of a 24-month offering period or the end of each six-month purchasing period.

[0000926326-19-000007:notes:59]
There was a total of 1.9 million shares reserved for future issuance under the ESPP as of December 31, 2018.

[0000926326-19-000007:notes:60]
Stock Award Plans

[0000926326-19-000007:notes:61]
2009 Equity Incentive Plan

[0000926326-19-000007:notes:62]
The 2009 Equity Incentive Plan (“2009 Plan”), as amended, provides for the issuance of incentive stock options, RSAs, RSUs, PSUs, and other stock awards to the Company’s employees, directors, and consultants. There were 6.9 million shares of common stock reserved for future issuance under the 2009 Plan as of December 31, 2018.

[0000926326-19-000007:notes:63]
Options granted under the 2009 Plan generally become exercisable over periods of up to four years, with one-fourth of the shares vesting one year from the vesting commencement date with respect to initial grants, and the remaining shares vesting in 36 equal monthly installments thereafter. The exercise prices of the options is the fair market value of common stock on the date of grant. RSUs generally vest over periods of up to four years, with one-fourth of the shares vesting one year from the vesting commencement date with respect to initial grants, and the remaining shares vesting in 12 equal quarterly installments thereafter. Awards of restricted stock to non-employee directors are granted on the date of the annual meeting of stockholders and vest in full on the date of the next annual meeting of stockholders, provided such non-employee director remains a director on such date. The fair value of the awards on the date of issuance is amortized to expense from the date of grant to the date of vesting and are expensed ratably on a straight-line basis over the vesting period. PSUs granted to the Company’s executives might include performance and market conditions. PSUs become eligible for vesting when certain market or performance conditions are met.

[0000926326-19-000007:notes:64]
Share-Based Compensation Expense

[0000926326-19-000007:notes:65]
The following table sets forth the total share-based compensation expense recognized in the Company’s Consolidated Statements of Operations:

[0000926326-19-000007:notes:66]
|  | Year Ended December 31, |
|  | 2018 |  | 2017 |  | 2016 |
|  | (In thousands) |
| Cost of product and service revenues | $ | 4,634 |  |  | $ | 3,478 |  |  | $ | 2,596 |  |
| Research and development | 5,746 |  |  | 3,590 |  |  | 3,128 |  |
| Selling, general, and administrative | 18,505 |  |  | 14,789 |  |  | 13,776 |  |
| Total share-based compensation expense | $ | 28,885 |  |  | $ | 21,857 |  |  | $ | 19,500 |  |

[0000926326-19-000007:notes:67]
The Company did not capitalize any share-based compensation as inventory as such amounts were not material for the years ended December 31, 2018 and December 31, 2017. Income tax benefits realized from share-based compensation were $6.5 million, $8.2 million, and $5.4 million, for the years ended December 31, 2018, December 31, 2017, and December 31, 2016, respectively.

[0000926326-19-000007:notes:68]
Stock Options and ESPP Shares

[0000926326-19-000007:notes:69]
The following assumptions were used to value stock options and ESPP shares granted pursuant to the Company’s equity incentive plans for the years ended December 31, 2018, December 31, 2017, and December 31, 2016:

[0000926326-19-000007:notes:70]
|  | Year Ended December 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Stock options |  |  |  |  |  |
| Expected life, years | 4.8 |  |  | 4.7 |  |  | 4.9 |  |
| Expected volatility, % | 31.1 | % |  | 29.6 | % |  | 30.6 | % |
| Risk-free interest rate, % | 2.8 | % |  | 1.9 | % |  | 1.5 | % |
| Estimated forfeiture rate, % | 6.9 | % |  | 7.7 | % |  | 8.6 | % |
| Dividend yield, % | — | % |  | — | % |  | — | % |

[0000926326-19-000007:notes:71]
|  | Year Ended December 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Employee stock purchase plan shares |  |  |  |  |  |
| Expected life, years | 0.5 - 2.0 |  |  | 0.5 - 2.0 |  |  | 0.5 - 2.0 |  |
| Expected volatility, % | 28.1% - 33.8% |  |  | 25.8% - 32.8% |  |  | 25.8% - 34.8% |  |
| Risk-free interest rate, % | 0.8% - 2.7% |  |  | 0.5% - 1.4% |  |  | 0.3% - 0.8% |  |
| Dividend yield, % | — | % |  | — | % |  | — | % |

[0000926326-19-000007:notes:72]
Stock Options Activity

[0000926326-19-000007:notes:73]
The following table summarizes the share option activity under the Company’s 2009 Plan during the year ended December 31, 2018:

[0000926326-19-000007:notes:74]
|  | Number ofShares |  | Weighted-AverageExercise Price |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2017 | 3,323 |  |  | $ | 32.72 |  |  | 7.6 |  | $ | 53,953 |  |
| Granted | 1,359 |  |  | 54.00 |  |  |  |  |  |
| Exercised | (672 | ) |  | 25.68 |  |  |  |  |  |
| Expired | (16 | ) |  | 26.54 |  |  |  |  |  |
| Forfeited | (246 | ) |  | 39.60 |  |  |  |  |  |
| Outstanding at December 31, 2018 | 3,748 |  |  | $ | 41.27 |  |  | 7.6 |  | $ | 78,365 |  |
| Exercisable at December 31, 2018 | 1,397 |  |  | 29.69 |  |  | 5.7 |  | 44,084 |  |
| Vested and expected to vest at December 31, 2018 and thereafter | 3,532 |  |  | $ | 40.64 |  |  | 7.6 |  | $ | 75,823 |  |

[0000926326-19-000007:notes:75]
The weighted-average fair value per share of options granted during the years ended December 31, 2018, December 31, 2017, and December 31, 2016 was $17.22, $13.25, and $9.33, respectively. The intrinsic value of options exercised during the years ended December 31, 2018, December 31, 2017, and December 31, 2016 was $20.1 million, $18.2 million, and $5.6 million, respectively.

[0000926326-19-000007:notes:76]
As of December 31, 2018, total unrecognized compensation cost related to unvested stock options was $29.7 million, which is expected to be recognized over a weighted-average vesting period of 2.9 years.

[0000926326-19-000007:notes:77]
Employee Stock Purchase Plan Activity

[0000926326-19-000007:notes:78]
For the year ended December 31, 2018, employees purchased approximately 452,038 shares of common stock under the ESPP and an aggregate of 6.4 million shares were issued under the ESPP as of December 31, 2018. As of December 31, 2018, the unrecognized compensation cost related to the shares to be purchased under the ESPP was approximately $3.9 million and is expected to be recognized over a weighted-average period of 1.3 years.

[0000926326-19-000007:notes:79]
Restricted Stock Units (RSUs) and Restricted Stock Awards (RSAs)

[0000926326-19-000007:notes:80]
Summaries of the restricted stock activity under the 2009 Plan are presented below for the year ended December 31, 2018:

[0000926326-19-000007:notes:81]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Restricted stock units |  |  |  |  |  |  |  |
| Outstanding at December 31, 2017 | 501 |  |  | $ | 38.90 |  |  | 1.5 |  | $ | 24,293 |  |
| Granted (Awarded) | 312 |  |  | 59.52 |  |  |  |  |  |
| Vested (Released) | (213 | ) |  | 37.14 |  |  |  |  |  |
| Forfeited | (62 | ) |  | 39.00 |  |  |  |  |  |
| Outstanding and unvested at December 31, 2018 | 538 |  |  | $ | 51.52 |  |  | 1.6 |  | $ | 32,935 |  |

[0000926326-19-000007:notes:82]
The weighted-average grant date fair value per share of RSUs granted during the years ended December 31, 2018, December 31, 2017, and December 31, 2016 was $59.52, $45.97, and $32.58, respectively. The total fair value of RSUs that vested in the years ended December 31, 2018, December 31, 2017, and December 31, 2016 was $7.9 million, $6.5 million, and $4.8 million, respectively.

[0000926326-19-000007:notes:83]
As of December 31, 2018, total unrecognized compensation cost related to RSUs was $24.1 million, which is expected to be recognized over the remaining weighted-average vesting period of 2.8 years.

[0000926326-19-000007:notes:84]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |
|  | (In thousands, except per share data) |
| Restricted stock awards |  |  |  |
| Outstanding at December 31, 2017 | 23 |  |  | $ | 41.07 |  |
| Granted (Awarded) | 21 |  |  | 46.60 |  |
| Vested (Released) | (23 | ) |  | 41.07 |  |
| Outstanding and unvested at December 31, 2018 | 21 |  |  | $ | 46.60 |  |

[0000926326-19-000007:notes:85]
The weighted-average grant date fair value per share of RSAs granted during the years ended December 31, 2018, December 31, 2017, and December 31, 2016 was $46.60, $41.10, and $31.59, respectively. The total fair value of RSAs that vested in the years ended December 31, 2018, December 31, 2017, and December 31, 2016 was $1.0 million, $1.0 million, and $1.2 million, respectively.

[0000926326-19-000007:notes:86]
As of December 31, 2018, total unrecognized compensation cost related to RSAs was $0.3 million, which is expected to be recognized over the remaining weighted-average vesting period of 0.4 years.

[0000926326-19-000007:notes:87]
Performance-Based Restricted Stock Units (PSUs)

[0000926326-19-000007:notes:88]
In 2017, the Company granted 147,830 PSUs to its executive officers, all of which became eligible for vesting upon the achievement of a certain level of shareholder return. In 2018, the Company granted 110,432 PSUs to its executive officers, all, none, or a portion of which may become eligible for vesting depending on the level of shareholder return for the period from March 1, 2018 through March 1, 2019.

[0000926326-19-000007:notes:89]
The fair value of a PSU award is determined using a Monte Carlo simulation model. The number of shares that vest at the end of the performance period depends on the percentile ranking of the total shareholder return for Omnicell stock over the performance period relative to the total shareholder return of each of the other companies in the NASDAQ Healthcare Index (the “Index”).

[0000926326-19-000007:notes:90]
For PSUs granted on February 6, 2018, stock price appreciation is calculated based on the trailing 20-day average stock price just prior to the first trading day of March 2018, compared to the trailing 20-day average stock price just prior to the first trading day of March 2019. For PSUs granted on February 8, 2017, stock price appreciation is calculated based on the trailing 20-day average stock price just prior to the first trading day of March 2017, compared to the trailing 20-day average stock price just prior to the first trading day of March 2018.

[0000926326-19-000007:notes:91]
On March 7, 2017, the Compensation Committee confirmed 71.5% as the percentile rank of the Company’s 2017 total stockholder return. This resulted in 100% of the 2016 PSUs, or 122,740 shares, as eligible for further time-based vesting. The eligible PSUs will vest as follows: 25% of the shares vested immediately on March 7, 2017 with the remaining shares vesting on a semi-annual basis period of 36 months commencing on June 15, 2017. Vesting is contingent upon continued service. Of the 122,740 shares eligible for time-based vesting under the 2016 PSUs, 89,350 shares have vested as of December 31, 2018.

[0000926326-19-000007:notes:92]
On March 6, 2018, the Compensation Committee confirmed 60.0% as the percentile rank of the Company’s 2017 total stockholder return. This resulted in 100% of the 2017 PSUs, or 147,830 shares, as eligible for further time-based vesting. The eligible PSUs will vest as follows: 25% of the shares vested immediately on March 6, 2018 with the remaining shares vesting on a semi-annual basis period of 36 months commencing on June 15, 2018. Vesting is contingent upon continued service. Of the 147,830 shares eligible for time-based vesting under the 2017 PSUs, 55,860 shares have vested as of December 31, 2018.

[0000926326-19-000007:notes:93]
A summary of the performance-based restricted stock activity under the 2009 Plan is presented below for the year ended December 31, 2018:

[0000926326-19-000007:notes:94]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value Per Unit |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2017 | 225 |  |  | $ | 31.18 |  |
| Granted | 110 |  |  | 38.03 |  |
| Vested | (106 | ) |  | 30.54 |  |
| Forfeited | (32 | ) |  | 34.47 |  |
| Outstanding and unvested at December 31, 2018 | 197 |  |  | $ | 34.83 |  |

[0000926326-19-000007:notes:95]
The weighted-average grant date fair value per share of PSUs granted during the years ended December 31, 2018, December 31, 2017, and December 31, 2016 was $38.03, $34.05, and $24.66, respectively. The total fair value of PSUs that vested in the years ended December 31, 2018, December 31, 2017, and December 31, 2016 was $3.2 million, $2.6 million, and $2.0 million, respectively.

[0000926326-19-000007:notes:96]
As of December 31, 2018, total unrecognized compensation cost related to PSUs was approximately $2.5 million, which is expected to be recognized over the remaining weighted-average period of 1.2 years.

[0000926326-19-000007:notes:97]
Summary of Shares Reserved for Future Issuance under Equity Incentive Plans

[0000926326-19-000007:notes:98]
401(k) Plan

[0000926326-19-000007:notes:99]
The Company has established a pre-tax savings plan under Section 401(k) of the Internal Revenue Code. The 401(k) Plan allows eligible employees in the United States to voluntarily contribute a portion of their pre-tax salary, subject to a maximum limit specified in the Internal Revenue Code. The Company matches 50% of employee contributions up to $3,000, annually. The Company’s contributions under this plan were $4.6 million, $3.8 million, and $1.9 million in the years ended December 31, 2018, December 31, 2017, and December 31, 2016, respectively.


## us-gaap:ConsolidationPolicyTextBlock

[0000926326-19-000007:notes:100]
Principles of Consolidation

[0000926326-19-000007:notes:101]
The accompanying Consolidated Financial Statements have been prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) and include all adjustments necessary for the fair presentation of the Company’s consolidated financial position, results of operations and cash flows for the periods presented. The Consolidated Financial Statements include the Company’s accounts as well as those of its wholly owned subsidiaries after the elimination of intercompany balances and transactions.


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0000926326-19-000007:notes:102]
The following table reflects the Company’s contract assets and contract liabilities:

[0000926326-19-000007:notes:103]
|  | December 31, 2018 |  | December 31, 2017 |
|  | (In thousands) |
| Short-term unbilled receivables - included in accounts receivable and unbilled receivables | $ | 9,191 |  |  | $ | 4,590 |  |
| Long-term unbilled receivables - included in other long-term assets | 16,481 |  |  | 9,475 |  |
| Total contract assets | $ | 25,672 |  |  | $ | 14,065 |  |
| Short-term deferred revenues, net | $ | 81,835 |  |  | $ | 78,774 |  |
| Long-term deferred revenues | 10,582 |  |  | 10,623 |  |
| Total contract liabilities | $ | 92,417 |  |  | $ | 89,397 |  |


## us-gaap:DebtDisclosureTextBlock

[0000926326-19-000007:notes:104]
Debt and Credit Agreements

[0000926326-19-000007:notes:105]
2016 Senior Secured Credit Facility

[0000926326-19-000007:notes:106]
On January 5, 2016, the Company entered into a $400.0 million senior secured credit facility pursuant to a credit agreement with certain lenders, Wells Fargo Securities, LLC as sole lead arranger, and Wells Fargo Bank, National Association as administrative agent (the “Credit Agreement”). The Credit Agreement provides for (a) a five-year revolving credit facility of $200.0 million, which was subsequently increased pursuant to the amendment discussed below (the “Revolving Credit Facility”) and (b) a five-year $200.0 million term loan facility (the “Term Loan Facility” and together with the Revolving Credit Facility, the “Facilities”). In addition, the Credit Agreement includes a letter of credit sub-limit of up to $10.0 million and a swing line loan sub-limit of up to $10.0 million. The Credit Agreement expires on January 5, 2021, upon which date all remaining outstanding borrowings are due and payable.

[0000926326-19-000007:notes:107]
Loans under the Facilities bear interest, at the Company’s option, at a rate equal to either (a) the LIBOR Rate, plus an applicable margin ranging from 1.50% to 2.25% per annum based on the Company’s consolidated total net leverage ratio (as defined in the Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) LIBOR for an interest period of one month, plus an applicable margin ranging from 0.50% to 1.25% per annum based on the Company’s consolidated total net leverage ratio (as defined in the 2016 Credit Agreement). Undrawn commitments under the Revolving Credit Facility will be subject to a commitment fee ranging from 0.20% to 0.35% per annum based on the Company’s consolidated total net leverage ratio on the average daily unused portion of the Revolving Credit Facility. A letter of credit participation fee ranging from 1.50% to 2.25% per annum based on the Company’s consolidated total net leverage ratio will accrue on the average daily amount of letter of credit exposure.

[0000926326-19-000007:notes:108]
The Company is permitted to make voluntary prepayments at any time without payment of a premium or penalty, except for any amounts relating to the LIBOR breakage indemnity described in the Credit Agreement. The Company is required to make mandatory prepayments under the Term Loan Facility with (a) net cash proceeds from any issuances of debt (other than certain permitted debt) and (b) net cash proceeds from certain asset dispositions (other than certain asset dispositions) and insurance and condemnation events (subject to reinvestment rights and certain other exceptions). Loans under the Term Loan Facility will amortize in quarterly installments, equal to 5% per annum of the original principal amount thereof during the first two years, which shall increase to 10% per annum during the third and fourth years, and 15% per annum during the fifth year, with the remaining balance payable on January 5, 2021. The Company is required to make mandatory prepayments under the Revolving Credit Facility if at any time the aggregate outstanding principal amount of loans together with the total amount of outstanding letters of credit exceeds the aggregate commitments, with such mandatory prepayment to be equal to the amount of such excess.

[0000926326-19-000007:notes:109]
The Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends and other distributions. The Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum consolidated total leverage ratio and maintain a minimum fixed charge coverage ratio. The Company’s obligations under the Credit Agreement and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and the subsidiary guarantors’ assets. In connection with entering into the Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a collateral agreement and subsidiary guaranty agreement. The Company was in full compliance with all covenants as of December 31, 2018.

[0000926326-19-000007:notes:110]
On April 11, 2017, the parties entered into the First Amendment to Credit Agreement and Collateral Agreement (the “Amended Credit Agreement”). Under this amendment, (i) the maximum capital expenditures limit in any fiscal year for property, plant and equipment and software development increased from $35.0 million to $45.0 million, and (ii) the maximum limit for non-permitted investments increased from $10.0 million to $20.0 million.

[0000926326-19-000007:notes:111]
On December 26, 2017, the parties entered into another amendment (the “Amendment”) to the Amended Credit Agreement. Pursuant to the Amendment, the Revolving Credit Facility provided for under the Amended Credit Agreement, was increased from $200.0 million to $315.0 million and certain other modifications to the Amended Credit Agreement were made, including amendments to certain negative covenants.

[0000926326-19-000007:notes:112]
In connection with these Facilities, the Company incurred $10.1 million of debt issuance costs, which included an additional $2.1 million of incurred costs in connection with the Amendment signed in December 2017. The debt issuance costs were capitalized and presented as a direct deduction from the carrying amount of that debt liability. The debt issuance costs are being amortized to interest expense using the straight line method from issuance date through 2021. Interest expense (exclusive of fees and issuance cost amortization) was approximately $7.5 million, $6.3 million, and $5.3 million for the years ended December 31, 2018, December 31, 2017, and December 31, 2016, respectively. Amortization expense related to fees and issuance costs was approximately $2.3 million, $1.6 million, and $1.6 million for the years ended December 31, 2018, December 31, 2017, and December 31, 2016, respectively.

[0000926326-19-000007:notes:113]
The components of the Company’s debt obligations as of December 31, 2018 and December 31, 2017 were as follows:

[0000926326-19-000007:notes:114]
|  | December 31, 2017 |  | Borrowings |  | Repayment/ Amortization |  | December 31, 2018 |
|  | (In thousands) |
| Term loan facility | $ | 182,500 |  |  | $ | — |  |  | $ | (42,500 | ) |  | $ | 140,000 |  |
| Revolving credit facility | 34,500 |  |  | — |  |  | (34,500 | ) |  | — |  |
| Total debt under the facilities | 217,000 |  |  | — |  |  | (77,000 | ) |  | 140,000 |  |
| Less: Deferred issuance cost | (6,875 | ) |  | — |  |  | 2,292 |  |  | (4,583 | ) |
| Total debt, net of deferred issuance cost | $ | 210,125 |  |  | $ | — |  |  | $ | (74,708 | ) |  | $ | 135,417 |  |
| Long-term debt, current portion, net of deferred issuance cost | 15,208 |  |  |  |  |  |  | — |  |
| Long-term debt, net of deferred issuance cost | $ | 194,917 |  |  |  |  |  |  | $ | 135,417 |  |

[0000926326-19-000007:notes:115]
As of December 31, 2018, the carrying amount of debt of $140.0 million approximates the comparable fair value of $143.5 million. The Company’s debt facilities are classified as a Level 3 in the fair value hierarchy. The calculation of the fair value is based on a discounted cash flow model using observable market inputs and taking into consideration variables such as interest rate changes, comparable instruments, and long-term credit ratings. There have been no significant changes in the assumptions used as of December 31, 2018 as compared to the period as of December 31, 2017.


## us-gaap:DebtPolicyTextBlock

[0000926326-19-000007:notes:116]
Debt. The Company has entered into a Credit Agreement which provides for (a) a five-year revolving credit facility and (b) a five-year term loan facility (“Facilities”). The amount borrowed under these facilities is recorded at its carrying value at December 31, 2018. The fair value of debt at December 31, 2018 approximates the carrying value.


## us-gaap:DerivativesPolicyTextBlock

[0000926326-19-000007:notes:117]
Foreign currency forward contracts. The Company enters into foreign currency forward contracts to protect its business from the risk that exchange rates may affect the eventual cash flows resulting from intercompany transactions between Omnicell and its foreign subsidiaries. These transactions primarily arise as a result of products manufactured in the United States and sold to foreign subsidiaries in U.S. dollars rather than the subsidiaries’ functional currencies. These forward contracts are considered to be financial derivative instruments and are recorded at fair value. Changes in fair values of these financial derivative instruments are either recognized in other comprehensive income or net income depending on whether the derivative has been designated and qualifies as a hedging instrument. At December 31, 2018 and December 31, 2017, the Company had no outstanding foreign exchange forward contracts.

[0000926326-19-000007:notes:118]
Interest rate swap agreements. During 2016, the Company entered into an interest rate swap agreement. The interest rate swap agreement, at its inception, qualified for and were designated as cash flow hedging instrument. In accordance with the Derivatives and Hedging topic of the Accounting Standards Codification, the Company records its interest rate swaps on its consolidated balance sheet at fair value. The effective portion of changes in fair value are recorded in accumulated other comprehensive loss and are subsequently reclassified into earnings in the period that the hedged forecasted transaction affects earnings. Any ineffective portion is recognized in earnings. On a quarterly basis, the Company performs a qualitative assessment to determine effectiveness.


## us-gaap:EarningsPerShareTextBlock

[0000926326-19-000007:notes:119]
Net Income Per Share

[0000926326-19-000007:notes:120]
Basic net income per share is computed by dividing net income for the period by the weighted-average number of shares outstanding during the period. In periods of net loss, all potential common shares are anti-dilutive, so diluted net loss per share equals the basic net loss per share. In periods of net income, diluted net income per share is computed by dividing net income for the period by the basic weighted-average number of shares plus any dilutive potential common stock outstanding during the period. Potential common stock includes the effect of outstanding dilutive stock options, restricted stock awards and restricted stock units computed using the treasury stock method. Any anti-dilutive weighted-average dilutive shares related to stock award plans are excluded from the computation of the diluted net income per share.

[0000926326-19-000007:notes:121]
The basic and diluted net income per share calculation for the years ended December 31, 2018, December 31, 2017, and December 31, 2016 was as follows:

[0000926326-19-000007:notes:122]
|  | Year Ended December 31, |
|  | 2018 |  | 2017 |  | 2016 |
|  | (In thousands, except per share data) |
| Net income | $ | 37,729 |  |  | $ | 30,518 |  |  | $ | 9,756 |  |
| Weighted-average shares outstanding — basic | 39,242 |  |  | 37,483 |  |  | 36,156 |  |
| Effect of dilutive securities from stock award plans | 1,317 |  |  | 1,229 |  |  | 708 |  |
| Weighted-average shares outstanding — diluted | 40,559 |  |  | 38,712 |  |  | 36,864 |  |
| Net income per share - basic | $ | 0.96 |  |  | $ | 0.81 |  |  | $ | 0.27 |  |
| Net income per share - diluted | $ | 0.93 |  |  | $ | 0.79 |  |  | $ | 0.26 |  |
| Anti-dilutive weighted-average shares related to stock award plans | 1,279 |  |  | 501 |  |  | 1,345 |  |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0000926326-19-000007:notes:123]
The following table represents the fair value hierarchy of the Company’s financial assets measured at fair value as of December 31, 2018:

[0000926326-19-000007:notes:124]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Interest rate swap contracts | $ | — |  |  | $ | 562 |  |  | $ | — |  |  | $ | 562 |  |
| Total financial assets | $ | — |  |  | $ | 562 |  |  | $ | — |  |  | $ | 562 |  |

[0000926326-19-000007:notes:125]
The following table represents the fair value hierarchy of the Company’s financial assets measured at fair value as of December 31, 2017:

[0000926326-19-000007:notes:126]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Interest rate swap contracts | $ | — |  |  | $ | 1,378 |  |  | $ | — |  |  | $ | 1,378 |  |
| Total financial assets | $ | — |  |  | $ | 1,378 |  |  | $ | — |  |  | $ | 1,378 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000926326-19-000007:notes:127]
Cash and Cash Equivalents and Fair Value of Financial Instruments

[0000926326-19-000007:notes:128]
Cash and cash equivalents of $67.2 million and $32.4 million as of December 31, 2018 and December 31, 2017, respectively, consisted of demand deposits only.

[0000926326-19-000007:notes:129]
Fair Value Hierarchy

[0000926326-19-000007:notes:130]
The Company measures its financial instruments at fair value. The Company’s cash equivalents are classified within Level 1 of the fair value hierarchy as they are valued primarily using quoted market prices utilizing market observable inputs. The Company's interest rate swap contracts and foreign currency contracts are classified within Level 2 as the valuation inputs are based on quoted prices and market observable data of similar instruments.

[0000926326-19-000007:notes:131]
There have been no transfers between fair value measurement levels during the years ended December 31, 2018 and December 31, 2017.

[0000926326-19-000007:notes:132]
Interest Rate Swap Contracts

[0000926326-19-000007:notes:133]
The Company uses interest rate swap agreements to protect the Company against adverse fluctuations in interest rates by reducing its exposure to variability in cash flows relating to interest payments on a portion of its outstanding debt. The Company’s interest rate swaps, which are designated as cash flow hedges, involve the receipt of variable amounts from counterparties in exchange for the Company making fixed-rate payments over the life of the agreements. The Company does not hold or issue any derivative financial instruments for speculative trading purposes.

[0000926326-19-000007:notes:134]
During 2016, the Company entered into an interest rate swap agreement with a combined notional amount of $100.0 million with one counterparty that became effective on June 30, 2016 and is maturing on April 30, 2019. The swap agreement requires the Company to pay a fixed rate of 0.8% and provides that the Company will receive a variable rate based on the one month LIBOR rate subject to a LIBOR floor of 0.0%. Amounts payable by or due to the Company will be net settled with the respective counterparty on the last business day of each month, commencing July 31, 2016.

[0000926326-19-000007:notes:135]
The fair value of the interest rate swap agreements at December 31, 2018 and December 31, 2017 was $0.6 million and $1.4 million, respectively. There were no amounts reclassified into current earnings due to ineffectiveness during the periods presented.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0000926326-19-000007:notes:136]
Foreign Currency Translation and Remeasurement

[0000926326-19-000007:notes:137]
Most of the Company’s foreign subsidiaries use the local currency of their respective countries as their functional currency. The Company translates the assets and liabilities of such non-U.S. dollar functional currency subsidiaries into U.S. dollars using exchange rates in effect at the end of each period. Revenue and expenses for these subsidiaries are translated using rates that approximate those in effect during the period. Gains and losses from these translations are recorded as foreign currency translation adjustments and included in accumulated other comprehensive income (loss) in stockholders’ equity.

[0000926326-19-000007:notes:138]
Assets and liabilities denominated in a currency other than the functional currency are remeasured into the respective entity’s functional currency. Monetary assets and liabilities are remeasured at exchange rates in effect at the end of each period, and non-monetary assets and liabilities are remeasured at historical rates. Gains and losses from foreign currency remeasurement of monetary assets and liabilities are recorded in interest and other income (expense).


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000926326-19-000007:notes:139]
Goodwill and Intangible Assets

[0000926326-19-000007:notes:140]
Goodwill

[0000926326-19-000007:notes:141]
The following table represents changes in the carrying amount of goodwill:

[0000926326-19-000007:notes:142]
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |
|  | (In thousands) |
| Net balance as of December 31, 2016 | $ | 215,082 |  |  | $ | 112,642 |  |  | $ | 327,724 |  |
| Additions (1) | 3,113 |  |  | 3,400 |  |  | 6,513 |  |
| Adjustments (2) | 2,656 |  |  | 858 |  |  | 3,514 |  |
| Net balance as of December 31, 2017 | 220,851 |  |  | 116,900 |  |  | 337,751 |  |
| Adjustments (2) | (1,296 | ) |  | (568 | ) |  | (1,864 | ) |
| Net balance as of December 31, 2018 | $ | 219,555 |  |  | $ | 116,332 |  |  | $ | 335,887 |  |

[0000926326-19-000007:notes:143]
| (1) | Additions to goodwill in the Automation and Analytics segment was a result of the InPharmics acquisition in April 2017. Additions to goodwill in the Medication Adherence segment represent adjustments to the preliminary value assigned to goodwill in connection with the Ateb acquisition to reflect measurement period adjustments related to accounts receivable, other non-current assets, and other liabilities of $0.1 million, $0.7 million and $2.6 million, respectively. |

[0000926326-19-000007:notes:144]
| (2) | Adjustments reflect foreign currency exchange rate fluctuations. |

[0000926326-19-000007:notes:145]
Intangible Assets, Net

[0000926326-19-000007:notes:146]
The carrying amounts of intangible assets and useful lives as of December 31, 2018 and December 31, 2017 were as follows:

[0000926326-19-000007:notes:147]
|  | December 31, 2018 |
|  | Grosscarryingamount |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 135,234 |  |  | $ | (45,029 | ) |  | $ | (1,185 | ) |  | $ | 89,020 |  |  | 1 - 30 |
| Acquired technology | 78,122 |  |  | (29,206 | ) |  | 42 |  |  | 48,958 |  |  | 3 - 20 |
| Backlog | 21,350 |  |  | (20,703 | ) |  | — |  |  | 647 |  |  | 1 - 4 |
| Trade names | 7,650 |  |  | (4,361 | ) |  | 17 |  |  | 3,306 |  |  | 1 - 12 |
| Patents | 3,239 |  |  | (1,488 | ) |  | 4 |  |  | 1,755 |  |  | 2 - 20 |
| Non-compete agreements | 1,900 |  |  | (1,900 | ) |  | — |  |  | — |  |  | 3 |
| Total intangibles assets, net | $ | 247,495 |  |  | $ | (102,687 | ) |  | $ | (1,122 | ) |  | $ | 143,686 |  |  |  |

[0000926326-19-000007:notes:148]
|  | December 31, 2017 |
|  | Gross carryingamount |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 135,234 |  |  | $ | (33,988 | ) |  | $ | (787 | ) |  | $ | 100,459 |  |  | 1 - 30 |
| Acquired technology | 74,222 |  |  | (21,345 | ) |  | 221 |  |  | 53,098 |  |  | 3 - 20 |
| Backlog | 21,350 |  |  | (17,182 | ) |  | — |  |  | 4,168 |  |  | 1 - 4 |
| Trade names | 7,650 |  |  | (3,688 | ) |  | 40 |  |  | 4,002 |  |  | 1 - 12 |
| Patents | 3,239 |  |  | (1,369 | ) |  | 10 |  |  | 1,880 |  |  | 2 - 20 |
| Non-compete agreements | 1,900 |  |  | (1,300 | ) |  | — |  |  | 600 |  |  | 3 |
| In-process technology | 3,900 |  |  | — |  |  | — |  |  | 3,900 |  |  | — |
| Total intangibles assets, net | $ | 247,495 |  |  | $ | (78,872 | ) |  | $ | (516 | ) |  | $ | 168,107 |  |  |  |

[0000926326-19-000007:notes:149]
During the year ended December 31, 2018, the Company reclassified in-process research and development intangible assets of $3.9 million to acquired technology due to the completion of a certain project.

[0000926326-19-000007:notes:150]
Amortization expense of intangible assets was $23.8 million, $25.6 million, and $36.1 million for the years ended December 31, 2018, December 31, 2017, and December 31, 2016, respectively.

[0000926326-19-000007:notes:151]
The estimated future amortization expenses for amortizable intangible assets were as follows:

[0000926326-19-000007:notes:152]
|  | December 31, 2018 |
|  | (In thousands) |
| 2019 | $ | 18,832 |  |
| 2020 | 17,625 |  |
| 2021 | 16,279 |  |
| 2022 | 14,926 |  |
| 2023 | 13,793 |  |
| Thereafter | 62,231 |  |
| Total | $ | 143,686 |  |


## us-gaap:GoodwillAndIntangibleAssetsPolicyTextBlock

[0000926326-19-000007:notes:153]
Goodwill and Acquired Intangible Assets

[0000926326-19-000007:notes:154]
Goodwill. The Company reviews goodwill for impairment on an annual basis on the first day of the fourth quarter of each year at the reporting unit level. This assessment is also performed whenever there is a change in circumstances that indicates the carrying value of goodwill may be impaired. The Company’s reporting units are the same as its operating segments, which are Automation and Analytics and Medication Adherence. A qualitative assessment is initially made to determine whether it is necessary to perform quantitative testing. A qualitative assessment includes, among others, consideration of: (i) past, current and projected future earnings and equity; (ii) recent trends and market conditions; and (iii) valuation metrics involving similar companies that are publicly-traded and acquisitions of similar companies, if available. If this qualitative assessment indicates that it is more likely than not that impairment exists, or if the Company decides to bypass this option, it proceeds to the quantitative assessment. The quantitative assessment involves a comparison between the estimated fair values of the Company’s reporting units with their respective carrying amounts including goodwill. If the carrying value exceeds estimated fair value, the Company will record an impairment charge based on that difference. The impairment charge will be limited to the amount of goodwill allocated to that reporting unit.

[0000926326-19-000007:notes:155]
To determine each reporting unit’s fair value under the quantitative approach, the Company uses a combination of income and market approaches, equally weighting the two approaches, such as estimated discounted future cash flows of that reporting unit, multiples of earnings or revenues, and analysis of recent sales or offerings of comparable entities. The Company also considers its market capitalization on the date of the analysis to ensure the reasonableness of the sum of its reporting units’ fair value.

[0000926326-19-000007:notes:156]
The Company performed a quantitative impairment analysis as of October 1, 2018 for its Medication Adherence reporting unit. The Company determined that the fair value of this reporting unit exceeded the carrying value by more than 41%, and thus no impairment was indicated. Additionally, the Company performed a qualitative impairment assessment analysis as of October 1, 2018 for its Automation and Analytics reporting unit taking into consideration past, current and projected future earnings, recent trends and market conditions; and valuation metrics involving similar companies that are publicly-traded. Based on the result of this analysis, an impairment does not exist as of December 31, 2018.

[0000926326-19-000007:notes:157]
Intangible assets. In connection with the Company’s acquisitions, it generally recognizes assets for customer relationships, backlog, developed technology, and trade names. Intangible assets are carried at cost less accumulated amortization. Such amortization is provided on a straight-line basis or on an accelerated basis based on a pattern of economic benefit that is expected to be obtained over the estimated useful lives of the respective assets, generally from one to 30 years. Amortization for developed technology and backlog is recognized in cost of revenues, and amortization for customer relationships, non-compete agreements, and trade names is recognized in selling, general, and administrative expenses.

[0000926326-19-000007:notes:158]
The Company assesses the impairment of identifiable intangible assets whenever events or changes in circumstances indicate that an asset’s carrying amount may not be recoverable. Recoverability of an asset is measured by the comparison of the carrying amount to the sum of the undiscounted estimated future cash flows the asset is expected to generate, offset by estimated future costs to dispose of the product to which the asset relates. If an asset is considered to be impaired, the amount of such impairment would be measured as the difference between the carrying amount of the asset and its fair value. The Company’s cash flow assumptions are based on historical and forecasted future revenue, operating costs, and other relevant factors. Assumptions and estimates about the remaining useful lives of the Company’s intangible assets are subjective and are affected by changes to its business strategies. If management’s estimates of future operating results change, or if there are changes to other assumptions, the estimate of the fair value of the Company’s assets could change significantly. Such change could result in impairment charges in future periods, which could have a significant impact on the Company’s operating results and financial condition. For the years ended December 31, 2018 and December 31, 2017, there were no events or changes in circumstances to indicate that intangible assets carrying amounts may not be recoverable.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000926326-19-000007:notes:159]
Income Taxes

[0000926326-19-000007:notes:160]
The following is a geographical breakdown of income (loss) before the provision for income taxes:

[0000926326-19-000007:notes:161]
|  | Year Ended December 31, |
|  | 2018 |  | 2017 (1) |  | 2016 (1) |
|  | (In thousands) |
| Domestic | $ | 46,528 |  |  | $ | 25,280 |  |  | $ | 16,395 |  |
| Foreign | (10,912 | ) |  | (20,768 | ) |  | (3,419 | ) |
| Income (loss) before provision for income taxes | $ | 35,616 |  |  | $ | 4,512 |  |  | $ | 12,976 |  |

[0000926326-19-000007:notes:162]
The provision for (benefit from) income taxes consisted of the following:

[0000926326-19-000007:notes:163]
|  | Year Ended December 31, |
|  | 2018 |  | 2017 (1) |  | 2016 (1) |
|  | (In thousands) |
| Current: |  |  |  |  |  |
| Federal | $ | 1,404 |  |  | $ | 2,430 |  |  | $ | 6,724 |  |
| State | 1,832 |  |  | 1,852 |  |  | 1,323 |  |
| Foreign | 768 |  |  | 745 |  |  | 46 |  |
| Total current income taxes | 4,004 |  |  | 5,027 |  |  | 8,093 |  |
| Deferred: |  |  |  |  |  |
| Federal | 5,455 |  |  | (19,822 | ) |  | 1,846 |  |
| State | (909 | ) |  | (3,430 | ) |  | (1,255 | ) |
| Foreign | (10,663 | ) |  | (7,781 | ) |  | (5,464 | ) |
| Total deferred income taxes | (6,117 | ) |  | (31,033 | ) |  | (4,873 | ) |
| Total provision for (benefit from) income taxes | $ | (2,113 | ) |  | $ | (26,006 | ) |  | $ | 3,220 |  |

[0000926326-19-000007:notes:164]
The provision for (benefit from) income taxes differs from the amount computed by applying the statutory federal tax rate as follows:

[0000926326-19-000007:notes:165]
|  | Year Ended December 31, |
|  | 2018 |  | 2017 (1) |  | 2016 (1) |
|  | (In thousands) |
| U.S. federal tax provision at statutory rate | $ | 7,479 |  |  | $ | 1,579 |  |  | $ | 4,542 |  |
| State taxes | 651 |  |  | 224 |  |  | 236 |  |
| Non-deductible expenses | 1,424 |  |  | 1,373 |  |  | 1,212 |  |
| Acquisition costs | — |  |  | — |  |  | 845 |  |
| Share-based compensation expense | 414 |  |  | 39 |  |  | 1,941 |  |
| Research tax credits | (3,230 | ) |  | (3,233 | ) |  | (2,075 | ) |
| Domestic production deduction | — |  |  | (621 | ) |  | (890 | ) |
| Restructuring impact | (4,205 | ) |  | — |  |  | — |  |
| Foreign derived intangible income deduction | (349 | ) |  | — |  |  | — |  |
| Tax audit settlement | — |  |  | — |  |  | (2,499 | ) |
| Foreign rate differential | 561 |  |  | 938 |  |  | (154 | ) |
| Stock option tax benefit | (4,419 | ) |  | (5,926 | ) |  | — |  |
| One-time impact of the Tax Act | — |  |  | (20,005 | ) |  | — |  |
| Other | (439 | ) |  | (374 | ) |  | 62 |  |
| Total provision for (benefit from) income taxes | $ | (2,113 | ) |  | $ | (26,006 | ) |  | $ | 3,220 |  |

[0000926326-19-000007:notes:166]
Significant components of the Company’s deferred tax assets (liabilities) were as follows:

[0000926326-19-000007:notes:167]
|  | December 31, 2018 |  | December 31, 2017 (1) |
|  | (In thousands) |
| Deferred tax assets (liabilities): |  |  |  |
| Deferred revenues | $ | 2,943 |  |  | $ | 127 |  |
| Share-based compensation | 5,531 |  |  | 4,460 |  |
| Inventory related items | 2,874 |  |  | 2,441 |  |
| Tax credit carryforwards | 7,413 |  |  | 9,349 |  |
| Reserves and accruals | 5,983 |  |  | 3,960 |  |
| Loss carryforwards | 17,515 |  |  | 8,643 |  |
| Other, net | 81 |  |  | 1,307 |  |
| Gross deferred tax assets | 42,340 |  |  | 30,287 |  |
| Valuation allowance | (1,256 | ) |  | — |  |
| Total net deferred tax assets | 41,084 |  |  | 30,287 |  |
| Intangibles | (32,304 | ) |  | (36,780 | ) |
| Depreciation and amortization | (22,504 | ) |  | (14,338 | ) |
| Prepaid expenses | (12,563 | ) |  | (11,161 | ) |
| Total deferred tax liabilities | (67,371 | ) |  | (62,279 | ) |
| Net deferred tax liabilities | $ | (26,287 | ) |  | $ | (31,992 | ) |

[0000926326-19-000007:notes:168]
Deferred income tax assets (liabilities) are provided for temporary differences that will result in future tax deductions or future taxable income, as well as the future benefit of tax credit carryforwards. The Company recognizes deferred tax assets to the extent that it believes these assets are more likely than not to be realized. In making such a determination, the Company considers all available positive and negative evidence, including future reversals of existing temporary differences, projected future taxable income, tax planning strategies, and results of recent operations. On the basis of this evaluation, as of December 31, 2018, $1.3 million of valuation allowances were recorded on certain foreign net operating losses carried forward, as the Company believes that such deferred tax assets are not more likely than not to be realized.

[0000926326-19-000007:notes:169]
On December 22, 2017, the U.S. government enacted comprehensive tax legislation commonly referred to as the Tax Cuts and Jobs Act (the “Tax Act”). The Tax Act significantly revised the U.S. corporate income tax by, among other things, lowering the statutory corporate income tax rate from 35% to 21%, and as part of the transition to the new territorial tax system, the Tax Act imposes a one-time tax on a deemed repatriation of historical earnings of foreign subsidiaries. In addition, beginning as of January 1, 2018, the Tax Act created new taxes imposed on certain foreign earnings as part of the Global Intangible Low-Taxed Income, Base Erosion and Anti-Abuse Tax, and Foreign Derived Intangible Income. SEC Staff Accounting Bulletin No. 118 ("SAB 118") allowed the use of provisional amounts with reasonable estimates if the analysis of the impacts of the Tax Act have not been completed by when financial statements are issued for the year ended December 31, 2017. We reasonably estimated the effects of the Tax Act and recorded provisional amounts in our financial statements as of December 31, 2017. We recorded a provisional tax benefit of $20.0 million for the impact of the remeasurement of federal net deferred tax assets and liabilities from the permanent reduction in the U.S. statutory rate to 21% from 35% as adjusted for full retrospective adoption of ASC 606. As of December 31, 2018, computations related to the income tax effects of the Tax Act were finalized. As such, in accordance with SAB 118, the Company's accounting for effects of the Tax Act is complete.

[0000926326-19-000007:notes:170]
As of December 31, 2018, the Company has $3.8 million of federal net operating loss carryforwards expiring 2037, $3.0 million of state net operating loss carryforwards expiring at various dates beginning 2023, and $65.2 million of foreign net operating loss carryforwards expiring at various dates beginning 2024. U.S. federal net operating losses generated in 2018 have no expiration. For the year ended December 31, 2018, the Company did not generate net operating loss. For income tax purposes, the Company has federal and California research tax credits carryforwards of $3.1 million and $13.4 million, respectively. Federal research tax credit carryforwards from prior years will begin to expire in 2035. California credits are available indefinitely to reduce cash taxes otherwise payable.

[0000926326-19-000007:notes:171]
It is the Company's practice and intention to reinvest the earnings of its non-U.S. subsidiaries in those operations. As of December 31, 2018, the Company has not made a provision for U.S. federal income, withholding, and state income taxes on the outside basis difference related to certain foreign subsidiaries because earnings are intended to be indefinitely reinvested in operations outside the U.S.

[0000926326-19-000007:notes:172]
The Company files income tax returns in the United States and various states and foreign jurisdictions. In the normal course of business, the Company is subject to examination by taxing authorities, including major jurisdictions such as the United States, Germany, Italy, Netherlands, and the United Kingdom. With few exceptions, as of December 31, 2018, the Company is no longer subject to U.S., state, and foreign examination for years before 2015, 2014, and 2014, respectively.

[0000926326-19-000007:notes:173]
The aggregate change in the balance of gross unrecognized tax benefits, which excludes interest and penalties, for the three years ended December 31, 2018 was as follows:

[0000926326-19-000007:notes:174]
|  | (In thousands) |
| Year Ended December 31, 2015 | $ | 9,150 |  |
| Increases related to tax positions taken during a prior period | 244 |  |
| Decreases related to tax positions taken during the prior period | (1,980 | ) |
| Increases related to tax positions taken during the current period | 6,724 |  |
| Decreases related to settlements | (2,178 | ) |
| Decreases related to expiration of statute of limitations | (344 | ) |
| Year Ended December 31, 2016 | 11,616 |  |
| Increases related to tax positions taken during a prior period | 503 |  |
| Decreases related to tax positions taken during the prior period | (1,782 | ) |
| Increases related to tax positions taken during the current period | 805 |  |
| Decreases related to settlements | — |  |
| Decreases related to expiration of statute of limitations | (401 | ) |
| Year Ended December 31, 2017 | 10,741 |  |
| Increases related to tax positions taken during a prior period | 19 |  |
| Decreases related to tax positions taken during the prior period | (1,257 | ) |
| Increases related to tax positions taken during the current period | 870 |  |
| Decreases related to settlements | — |  |
| Decreases related to expiration of statute of limitations | (412 | ) |
| Year Ended December 31, 2018 | $ | 9,961 |  |

[0000926326-19-000007:notes:175]
As of December 31, 2018, the total amount of gross unrecognized tax benefits, if realized, would decrease the Company’s tax expense by approximately $10.0 million. The Company recognizes interest and/or penalties related to uncertain tax positions in other income/expense in Consolidated Statements of Operations, accruing $0.5 million, $0.3 million, and $0.5 million for the years ended December 31, 2018, December 31, 2017, and December 31, 2016, respectively. Accrued interest and penalties are included within other long-term liabilities on the Consolidated Balance Sheets. The combined amount of cumulative accrued interest and penalties was approximately $1.4 million, $1.4 million, and $1.1 million for the years ended December 31, 2018, December 31, 2017, and December 31, 2016, respectively. The Company does not believe there will be any significant changes in its unrecognized tax positions over the next twelve months.


## us-gaap:IncomeTaxPolicyTextBlock

[0000926326-19-000007:notes:176]
Accounting for Income Taxes

[0000926326-19-000007:notes:177]
The Company records an income tax provision for (benefit from) the anticipated tax consequences of the reported results of operations. In accordance with U.S. GAAP, the provision for (benefit from) income taxes is computed using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been included in the financial statements. Under this method, deferred tax assets and liabilities are determined on the basis of the differences between the financial statement and tax bases of assets and liabilities and for operating losses and tax credit carryforwards. Deferred tax assets and liabilities are measured using the enacted tax rates in effect for the periods in which those tax assets and liabilities are expected to be realized or settled. In the event that these tax rates change, the Company will incur a benefit or detriment on its income tax expense in the period of change. If the Company were to determine that all or part of the net deferred tax assets are not realizable in the future, it will record a valuation allowance that would be charged to earnings in the period such determination is made.

[0000926326-19-000007:notes:178]
In accordance with ASC 740, Income Taxes, the Company recognizes the tax benefit from an uncertain tax position if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement. The calculation of tax liabilities involves significant judgment in estimating the impact of uncertainties in the application of U.S. GAAP and complex tax laws. Resolution of these uncertainties in a manner inconsistent with management’s expectations could have a material impact on the Company’s financial condition and operating results.


## us-gaap:InventoryPolicyTextBlock

[0000926326-19-000007:notes:179]
Inventory

[0000926326-19-000007:notes:180]
Inventories are stated at the lower of cost, computed using the first-in, first-out method, and net realizable value. Inbound shipping costs are included in cost of inventory. The Company regularly monitors inventory quantities on hand and records write-downs for excess and obsolete inventories based on the Company’s estimate of demand for its products, potential obsolescence of technology, product life cycles, and whether pricing trends or forecasts indicate that the carrying value of inventory exceeds its estimated selling price. These factors are impacted by market and economic conditions, technology changes, and new product introductions and require estimates that may include elements that are uncertain. Actual demand may differ from forecasted demand and may have a material effect on gross margins. If inventory is written down, a new cost basis is established that cannot be increased in future periods. Shipments from suppliers or contract manufacturers before the Company receives them are recorded as in-transit inventory when title and the significant risks and rewards of ownership have passed to the Company.


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0000926326-19-000007:notes:181]
Property and Equipment, Net

[0000926326-19-000007:notes:182]
|  | Year Ended December 31, |
|  | 2018 |  | 2017 |  | 2016 |
|  | (In thousands) |
| United States | $ | 44,684 |  |  | $ | 34,899 |  |  | $ | 36,497 |  |
| Rest of world (1) | 6,816 |  |  | 7,696 |  |  | 5,514 |  |
| Total property and equipment, net | $ | 51,500 |  |  | $ | 42,595 |  |  | $ | 42,011 |  |

[0000926326-19-000007:notes:183]
____________________________________________

[0000926326-19-000007:notes:184]
| (1) | No individual country represented more than 10% of the respective totals. |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000926326-19-000007:notes:185]
Recently Adopted Authoritative Guidance

[0000926326-19-000007:notes:186]
In May 2014, the Financial Accounting Standards Board (“FASB”) issued ASC 606, Revenue from Contracts with Customers, a new standard related to revenue recognition. Under the new standard, revenue is recognized when a customer obtains control of promised goods or services in an amount that reflects the consideration the entity expects to receive in exchange for those goods or services. In addition, the standard requires disclosure of the nature, amount, timing, and uncertainty of revenues and cash flows arising from contracts with customers. The guidance permits two methods of adoption: retrospectively to each prior reporting period presented (full retrospective method), or retrospectively with the cumulative effect of initially applying the guidance recognized at the date of initial application (modified retrospective method). The Company adopted the standard using the full retrospective method effective beginning January 1, 2018.

[0000926326-19-000007:notes:187]
Under the ASC 606 guidance, fees paid to GPOs are now presented as a reduction of product revenues, whereas these fees were considered a part of selling, general, and administrative costs under the previous guidance. The majority of the incremental costs incurred to obtain a contract, primarily commission expense, are recognized during the first year with the balance recognized ratably over a period of ten years. Additionally, revenue on term software licenses is recognized upon installation of the license rather than ratably over the life of the term license. Finally, the Company no longer defers the contingent revenue in transactions where the amount charged to the customer for a particular performance obligation is less than the allocation of standalone selling price.

[0000926326-19-000007:notes:188]
Adoption of the standard related to revenue recognition impacted the Company’s reported results as follows:

[0000926326-19-000007:notes:189]
|  | Year Ended December 31, 2017 |
|  | As Reported |  | Adjustment |  | As Adjusted |
|  | (In thousands, except per share data) |
| Revenues |  |  |  |  |  |
| Automation and Analytics | $ | 590,392 |  |  | $ | (3,451 | ) |  | $ | 586,941 |  |
| Medication Adherence | 125,773 |  |  | — |  |  | 125,773 |  |
| Gross profit |  |  |  |  |  |
| Automation and Analytics | 281,949 |  |  | (3,451 | ) |  | 278,498 |  |
| Medication Adherence | 40,139 |  |  | — |  |  | 40,139 |  |
| Selling, general, and administrative expenses | 250,312 |  |  | (8,842 | ) |  | 241,470 |  |
| Provision for (benefit from) income taxes | (21,484 | ) |  | (4,522 | ) |  | (26,006 | ) |
| Net income | $ | 20,605 |  |  | $ | 9,913 |  |  | $ | 30,518 |  |
| Net income per share - basic | $ | 0.55 |  |  | $ | 0.26 |  |  | $ | 0.81 |  |
| Net income per share - diluted | $ | 0.53 |  |  | $ | 0.26 |  |  | $ | 0.79 |  |

[0000926326-19-000007:notes:190]
|  | Year Ended December 31, 2016 |
|  | As Reported |  | Adjustment |  | As Adjusted |
|  | (In thousands, except per share data) |
| Revenues |  |  |  |  |  |
| Automation and Analytics | $ | 593,626 |  |  | $ | 3,285 |  |  | $ | 596,911 |  |
| Medication Adherence | 98,997 |  |  | — |  |  | 98,997 |  |
| Gross profit |  |  |  |  |  |
| Automation and Analytics | 282,659 |  |  | 3,285 |  |  | 285,944 |  |
| Medication Adherence | 31,141 |  |  | — |  |  | 31,141 |  |
| Selling, general, and administrative expenses | 249,520 |  |  | (11,639 | ) |  | 237,881 |  |
| Provision for (benefit from) income taxes | (2,551 | ) |  | 5,771 |  |  | 3,220 |  |
| Net income | $ | 603 |  |  | $ | 9,153 |  |  | $ | 9,756 |  |
| Net income per share - basic | $ | 0.02 |  |  | $ | 0.25 |  |  | $ | 0.27 |  |
| Net income per share - diluted | $ | 0.02 |  |  | $ | 0.24 |  |  | $ | 0.26 |  |

[0000926326-19-000007:notes:191]
|  | December 31, 2017 |
|  | As Reported |  | Adjustment |  | As Adjusted |
|  | (In thousands) |
| Accounts receivable and unbilled receivables, net | $ | 189,227 |  |  | $ | 819 |  |  | $ | 190,046 |  |
| Prepaid expenses | 36,060 |  |  | (15,668 | ) |  | 20,392 |  |
| Prepaid commissions | — |  |  | 41,432 |  |  | 41,432 |  |
| Other long-term assets | 39,841 |  |  | 9,475 |  |  | 49,316 |  |
| Deferred revenues, net | 86,104 |  |  | (7,330 | ) |  | 78,774 |  |
| Long-term, deferred revenues | 17,244 |  |  | (6,621 | ) |  | 10,623 |  |
| Long-term, deferred tax liabilities | 28,579 |  |  | 12,867 |  |  | 41,446 |  |
| Stockholders’ equity | 517,199 |  |  | 37,142 |  |  | 554,341 |  |

[0000926326-19-000007:notes:192]
In August 2018, the FASB issued ASU 2018-13, Fair Value Measurement (Topic 820): Disclosure Framework—Changes to the Disclosure Requirements for Fair Value Measurement, which modifies the disclosure requirements on fair value measurements. ASU 2018-13 is effective for the Company beginning January 1, 2020, with early adoption permitted. The Company early adopted this guidance effective beginning July 1, 2018. The application of this guidance did not have a material effect on the Company’s consolidated financial statements.

[0000926326-19-000007:notes:193]
Recently Issued Authoritative Guidance

[0000926326-19-000007:notes:194]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842). The FASB amended lease accounting requirements to begin recording assets and liabilities arising from most leases on the balance sheet. The new guidance will also require significant additional disclosures about the amount and timing of cash flows from leases. This new guidance will be effective for the Company beginning January 1, 2019. In July 2018, the FASB issued amendments in ASU 2018-11, which provide a transition election to not restate comparative periods for the effects of applying the new standard. This transition election permits entities to change the date of initial application to the beginning of the year of adoption and to recognize the effects of applying the new standard as a cumulative-effect adjustment to the opening balance of retained earnings. The Company will elect this transition approach as well as elect the package of practical expedients permitted under the transition guidance within the new standard, which will allow the Company to carry forward the historical lease classification of contracts entered into prior to January 1, 2019. The Company will also elect to combine lease and non-lease components, and to keep leases with an initial term of 12 months or less off the balance sheet and recognize the associated lease payments in the Consolidated Statements of Operations on a straight-line basis over the lease term.

[0000926326-19-000007:notes:195]
The Company’s adoption of the new standard is estimated to result in the recognition of right-of-use assets and offsetting lease liabilities for operating leases on the Consolidated Balance Sheets of approximately $66.0 million and $70.0 million, respectively, as of January 1, 2019. The difference between the right-of-use assets and lease liabilities is primarily due to the existing deferred rent liabilities balance, resulting from historical straight-lining of operating leases, which was effectively reclassified upon adoption to reduce the measurement of the right-of-use assets. Adoption of the standard is not expected to have an impact on the Company’s stockholders’ equity, and is not expected to materially impact the Consolidated Statements of Operations and Consolidated Statements of Cash Flows.

[0000926326-19-000007:notes:196]
In February 2018, the FASB issued ASU 2018-02, Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income, which permits the reclassification of the income tax effects of the Tax Cuts and Jobs Act of 2017 (the “Tax Act”) on items within accumulated other comprehensive income to retained earnings. These amounts are commonly referred to as “stranded tax effects.” ASU 2018-02 will be effective for the Company beginning January 1, 2019. The Company does not expect application of this guidance to have a material effect on its consolidated financial statements.

[0000926326-19-000007:notes:197]
In August 2018, the FASB issued ASU 2018-15, Intangibles—Goodwill and Other—Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract, to align the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software (and hosting arrangements that include an internal-use software license). ASU 2018-15 will be effective for the Company beginning January 1, 2020. The Company is currently evaluating the impact ASU 2018-15 will have on its consolidated financial statements.

[0000926326-19-000007:notes:198]
There was no other recently issued and effective authoritative guidance that is expected to have a material impact on the Company’s Condensed Consolidated Financial Statements through the reporting date.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000926326-19-000007:notes:199]
Organization and Summary of Significant Accounting Policies

[0000926326-19-000007:notes:200]
Business

[0000926326-19-000007:notes:201]
Omnicell, Inc. was incorporated in California in 1992 under the name Omnicell Technologies, Inc. and reincorporated in Delaware in 2001 as Omnicell, Inc. The Company’s major products are medication and supply dispensing automation solutions, central pharmacy automation solutions, analytics software, and medication adherence solutions which are sold in its principal market, which is the healthcare industry. The Company’s market is primarily located in the United States and Europe. “Omnicell” or the “Company” collectively refer to Omnicell, Inc. and its subsidiaries.

[0000926326-19-000007:notes:202]
On April 12, 2017, the Company completed its acquisition of Dixie Drawl, LLC d/b/a InPharmics (“InPharmics”). On December 8, 2016, the Company completed its acquisition of Ateb, Inc. and Ateb Canada Ltd. (together, “Ateb”). On January 5, 2016, the Company completed its acquisition of Aesynt Holding Cooperatief U.A. (“Aesynt”). The consolidated financial statements include the results of operations of these recently acquired companies, commencing as of their respective acquisition dates. The significant accounting policies of the acquired businesses have been aligned to conform to the accounting policies of Omnicell.

[0000926326-19-000007:notes:203]
Certain prior-year amounts have been adjusted to conform with the adoption of Accounting Standards Codification (“ASC”) 606, Revenue from Contracts with Customers, which became effective for the Company beginning on January 1, 2018. Refer to “Recently Adopted Authoritative Guidance” for the effects of adoption of ASC 606 and the section below for the updated revenue recognition policy.

[0000926326-19-000007:notes:204]
Certain prior-year amounts have been reclassified to conform with current-period presentation. These reclassifications include (i) reclassification of revenues from services and other revenues to product revenues of $0.8 million for the year ended December 31, 2017 related to software term-license sales, (ii) a change in inventories presentation related to allocation of inventories obsolescence reserve between finished goods, raw materials, and work in progress in Note 5, Balance Sheet Components. of the Notes to the Consolidated Financial Statements, and (iii) a change in intangible assets presentation related to presenting foreign currency impact separately in Note 7, Goodwill and Intangible Assets, of the Notes to the Consolidated Financial Statements. These changes were not deemed material and were included to conform with current-period classification and presentation.

[0000926326-19-000007:notes:205]
During 2018, the Company recorded out-of-period adjustments to correct errors originating in previous periods, which resulted in the increase of income before taxes of $3.2 million and net income of $2.5 million for the year ended December 31, 2018. Included in the out-of-period adjustments is a $2.6 million decrease in selling, general, and administrative expenses to correct purchase price accounting and integration activity for businesses acquired prior to 2018 along with other miscellaneous adjustments. The adjustments were not considered material to the fiscal year ended December 31, 2018 or any previously issued interim or annual consolidated financial statements.

[0000926326-19-000007:notes:206]
Use of Estimates

[0000926326-19-000007:notes:207]
The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s Consolidated Financial Statements and accompanying Notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. The Company’s critical accounting policies are those that affect its financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition; accounts receivable and notes receivable from investment in sales-type leases; inventory valuation; capitalized software development costs; impairment of goodwill; purchased intangibles and long-lived assets; fair value of assets acquired and liabilities assumed in business combination; share-based compensation; and accounting for income taxes.

[0000926326-19-000007:notes:208]
Segment Reporting

[0000926326-19-000007:notes:209]
The Company’s Chief Operating Decision Maker (“CODM”) is its Chief Executive Officer. The CODM allocates resources and evaluates the performance of the Company’s segments using information about its revenues, gross profit, and income from operations. Such evaluation excludes general corporate-level costs that are not specific to either of the reportable segments and are managed separately at the corporate level. Corporate-level costs include expenses related to executive management, finance and accounting, human resources, legal, training and development, and certain administrative expenses. See Note 14, Segment and Geographical Information, for additional information on segment reporting.

[0000926326-19-000007:notes:210]
Revenue Recognition

[0000926326-19-000007:notes:211]
The Company earns revenues from sales of its medication and supply dispensing automation systems, along with consumables and related services, which are sold in the healthcare industry, its principal market. The transaction price of each contract with a customer is allocated to the identified performance obligations based on the relative fair value of each obligation. The Company’s customer arrangements typically include one or more of the following performance obligations:

[0000926326-19-000007:notes:212]
Products. Software-enabled equipment that manages and regulates the storage and dispensing of pharmaceuticals, consumable blister cards and packaging equipment and other medical supplies.

[0000926326-19-000007:notes:213]
Software. Additional software applications that enable incremental functionality of the Company’s equipment or services.

[0000926326-19-000007:notes:214]
Installation. Installation of equipment as integrated systems at customer sites.

[0000926326-19-000007:notes:215]
Post-installation technical support. Phone support, on-site service, parts, and access to unspecified software updates and enhancements, if and when available.

[0000926326-19-000007:notes:216]
Professional services. Other customer services, such as training and consulting.

[0000926326-19-000007:notes:217]
Prior to recognizing revenue, the Company identifies the contract, performance obligations, and transaction price, and allocates the transaction price to the performance obligations. All identified contracts meet the following required criteria:

[0000926326-19-000007:notes:218]
Parties to the contract have approved the contract (in writing, orally, or in accordance with other customary business practices) and are committed to perform their respective obligations. A majority of the Company’s contracts are evidenced by a non-cancelable written agreement. Contracts for consumable products are generally evidenced by an order placed via phone or a manual purchase order.

[0000926326-19-000007:notes:219]
Entity can identify each party’s rights regarding the goods or services to be transferred. Contract terms are documented within the written agreements. Where a written contract does not exist, such as for consumable products, the rights of each party are understood as following the Company’s standard business process and terms.

[0000926326-19-000007:notes:220]
The entity can identify the payment terms for the goods or services to be transferred. Payment terms are documented within the agreement and are generally net 30 days from shipment of tangible product or services performed. Where a written contract does not exist, the Company’s standard payment terms are net 30 day terms.

[0000926326-19-000007:notes:221]
The contract has commercial substance (that is the risk, timing, or amount of the entity’s future cash flows is expected to change as a result of the contract.) The Company’s agreements are an exchange of cash for a combination of products and services which result in changes in the amount of the Company’s future cash flows.

[0000926326-19-000007:notes:222]
It is probable the entity will collect the consideration to which it will be entitled in exchange for the goods or services that will be transferred to the customer. The Company performs a credit check for all significant customers or transactions and where collectability is not probable, payment in full or a substantial down payment is typically required to help assure the full agreed upon contract price will be collected.

[0000926326-19-000007:notes:223]
The Company often enters into change orders which modify the product to be received by the customer pursuant to certain contracts. Changes to any contract are accounted for as a modification of the existing contract to the extent the goods and services to be delivered as part of the contract are generally consistent with the nature and type of those to be provided under the terms of the original contract. Examples of such change orders include the addition or removal of units of equipment or changes to the configuration of the equipment where the overall nature of the contract remains intact. The Company’s change orders generally result in the change being accounted for as modifications of existing contracts given the nature of the impacted orders.

[0000926326-19-000007:notes:224]
Distinct goods or services are identified as performance obligations. A series of distinct goods or services that are substantially the same and that have the same pattern of transfer to the customer are considered a single performance obligation. Where a good or service is determined not to be distinct, the Company combines the good or service with other promised goods or services until a bundle of goods or services that is distinct is identified. To identify its performance obligations, the Company considers all of the products or services promised in the contract regardless of whether they are explicitly stated or are implied by customary business practices. When performance obligations are included in separate contracts, the Company considers an entire customer arrangement to determine if separate contracts should be considered combined for the purposes of revenue recognition. Most of the Company’s sales, other than renewals of support and maintenance, contain multiple performance obligations, with a combination of hardware systems, consumables and software products, support and maintenance, and professional services.

[0000926326-19-000007:notes:225]
The transaction price of a contract is determined based on the fixed consideration, net of an estimate for variable consideration such as various discounts or rebates provided to customers. As a result of the Company’s commercial selling practices, contract prices are generally fixed with minimal, if any, variable consideration.

[0000926326-19-000007:notes:226]
The transaction price is allocated to separate performance obligations proportionally based on the standalone selling price of each performance obligation. Standalone selling price is best evidenced by the price the Company charges for the good or service when selling it separately in similar circumstances to similar customers. Other than for the renewal of annual support services contracts, the Company’s products and services are not generally sold separately. The Company uses an amount discounted from the list price as a best estimated selling price.

[0000926326-19-000007:notes:227]
The Company recognizes revenue when the performance obligation has been satisfied by transferring a promised good or service to a customer. The good or service is transferred when or as the customer obtains control of the good or service. Determining when control transfers requires management to make judgments that affect the timing of revenues recognized. Generally, for products requiring a complex implementation, control passes when the product is installed and ready for use. For all other products, control generally passes when product has been shipped and title has passed. For maintenance contracts and certain other services provided on a subscription basis, control passes to the customer over time, generally ratably over the service term as the Company provides a stand-ready service to service the customer’s equipment. Time and material services transfer control to the customer at the time the services are provided. The portion of the transaction price allocated to the Company’s unsatisfied performance obligations recorded as deferred revenues, net of deferred cost of goods sold, at December 31, 2018 and December 31, 2017 were $92.4 million and $89.4 million, respectively, of which $81.8 million and $78.8 million, respectively, are expected to be completed within one year. Remaining performance obligations primarily relate to maintenance contracts and are recognized ratably over the remaining term of the contract, generally not more than five years.

[0000926326-19-000007:notes:228]
Revenues, contract assets, and contract liabilities are recorded net of associated taxes.

[0000926326-19-000007:notes:229]
The payment terms associated with the Company’s contracts vary, however, payment terms for product revenues are generally based on milestones tied to contract signing, shipment of products, and/or customer acceptance. Payment terms associated with the service portion of agreements are generally periodic and can be billed on a monthly, quarterly, or annual basis. In certain circumstances multiple years are billed at one time. The portion of these contract liabilities not expected to be recognized as revenue within twelve months of the balance sheet date are considered long term.

[0000926326-19-000007:notes:230]
In the normal course of business, the Company typically does not accept product returns unless the item is defective as manufactured or the configuration of the product is incorrect. The Company establishes provisions for estimated returns based on historical product returns. The allowance for sales returns is not material to the Consolidated Financial Statements for any periods presented.

[0000926326-19-000007:notes:231]
A portion of the Company's sales are made through multi-year lease agreements. Under sales-type leases, the Company recognizes revenue for its hardware and software products net of lease execution costs, such as post-installation product maintenance and technical support, at the net present value of the lease payment stream once its installation obligations have been met. The Company optimizes cash flows by selling a majority of its non-U.S. government leases to third-party leasing finance companies on a non-recourse basis. The Company has no obligation to the leasing company once the lease has been sold. Some of the Company's sales-type leases, mostly those relating to U.S. government hospitals which comprise approximately 49% of the lease receivable balance, are retained in-house. Revenues from sales-type leases of $39.2 million, $29.6 million, and $34.9 million for the years ended December 31, 2018, December 31, 2017, and December 31, 2016 respectively, are included in product revenues in the Consolidated Statements of Operations. Interest income in these leases is recognized in product revenues using the effective interest method.

[0000926326-19-000007:notes:232]
The Company contracts with Group Purchasing Organizations (“GPOs”), each of which functions as a purchasing agent on behalf of member hospitals and other healthcare providers, as well as with government entities and agencies. Pursuant to the terms of GPO agreements, each member contracts directly with Omnicell and can purchase Company’s product at pre-negotiated contract terms and pricing. GPOs are often owned fully or in part by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs were $8.7 million, $7.4 million, and $8.4 million for the years ended December 31, 2018, December 31, 2017, and December 31, 2016, respectively. The accounts receivable balances are with individual members of the GPOs, and therefore no significant concentration of credit risk exists. During the year ended December 31, 2018, sales to members of the ten largest GPOs accounted for approximately 59% of total consolidated revenue.

[0000926326-19-000007:notes:233]
Contract Assets and Contract Liabilities

[0000926326-19-000007:notes:234]
A contract asset is a right to consideration in exchange for goods or services that the Company has transferred to a customer when that right is conditional and is not just subject to the passage of time. A receivable will be recorded on the balance sheet when the Company has unconditional rights to consideration. A contract liability is an obligation to transfer goods or services for which the Company has received consideration, or for which an amount of consideration is due from the customer. Contract liabilities include customer deposits under non-cancelable contracts, and current and non-current deferred revenue balances. The Company’s contract balances are reported in a net contract asset or liability position on a contract-by-contract basis at the end of each reporting period.

[0000926326-19-000007:notes:235]
Significant changes in the contract assets and the contract liabilities balances during the period are the result of the issuance of invoices and recognition of deferred revenues in the normal course of business. Unbilled contract assets which were invoiced during the year ended December 31, 2018 as a result of the right to invoice for the transaction consideration becoming unconditional were not material. The contract modifications entered into during the year ended December 31, 2018 did not have a significant impact on the Company’s contract assets or deferred revenues. During the year ended December 31, 2018, the Company recognized revenues of $85.7 million that were included in the corresponding gross short-term deferred revenue balance of $95.7 million as of December 31, 2017.

[0000926326-19-000007:notes:236]
Contract Costs

[0000926326-19-000007:notes:237]
The Company has determined that the incentive portions of its sales commission plans require capitalization since these payments are directly related to sales achieved during a time period. These commissions are earned on the basis of the total purchase order value of new product bookings. Since there are not commensurate commissions earned on renewal of the service bookings, the Company concluded that the capitalized asset is related to services provided under both the initial contract and renewal periods. The Company applies a practical expedient to account for the incremental costs of obtaining a contract as part of a portfolio of contracts with similar characteristics as the Company expects the effect on the financial statements of applying the practical expedient would not differ materially from applying the accounting guidance to the individual contracts within the portfolio. A pool of contracts is defined as all contracts booked in a particular quarter. The amortization for the capitalized asset is an estimate of the pool’s original contract term, generally one to five years, plus an estimate of future customer renewal periods resulting in a total amortization period of ten years. Costs to obtain a contract are allocated amongst performance obligations and recognized as sales and marketing expense consistent with the pattern of revenue recognition. Capitalized costs are periodically reviewed for impairment. A portion of the pool’s capitalized asset is recorded as an expense over the first two quarters after booking, which represents the estimated period during which the product revenue associated with the contract is recorded. The remaining contract cost is recorded as expense ratably over the ten year estimated initial and renewal service periods. The Company recognized contract cost expense of $21.1 million, $17.9 million, and $18.8 million during the years ended December 31, 2018, December 31, 2017, and December 31, 2016, respectively. The commission expenses paid as of the consolidated balance sheet date to be recognized in future periods are recorded in long-term prepaid commissions on the Consolidated Balance Sheets. There was no impairment loss recorded related to capitalized prepaid commissions as of and for the year ended December 31, 2018.

[0000926326-19-000007:notes:238]
Financial Instruments

[0000926326-19-000007:notes:239]
For assets and liabilities measured at fair value, the amounts are based on an expected exit price representing the amount that would be received from the sale of an asset or paid to transfer a liability in a transaction between market participants. The fair value may be based on assumptions that market participants would use in pricing an asset or liability. The authoritative guidance on fair value measurements establishes a consistent framework for measuring fair value on either a recurring or nonrecurring basis whereby inputs used in valuation techniques are assigned a hierarchical level. The following methods were used to estimate the fair value of each class of financial instruments for which it is practical to estimate that value:

[0000926326-19-000007:notes:240]
Interest rate swap agreements. During 2016, the Company entered into an interest rate swap agreement. The interest rate swap agreement, at its inception, qualified for and were designated as cash flow hedging instrument. In accordance with the Derivatives and Hedging topic of the Accounting Standards Codification, the Company records its interest rate swaps on its consolidated balance sheet at fair value. The effective portion of changes in fair value are recorded in accumulated other comprehensive loss and are subsequently reclassified into earnings in the period that the hedged forecasted transaction affects earnings. Any ineffective portion is recognized in earnings. On a quarterly basis, the Company performs a qualitative assessment to determine effectiveness. For further information regarding these interest rate swap agreements, please refer to Note 4, Cash and Cash Equivalents and Fair Value of Financial Instruments.

[0000926326-19-000007:notes:241]
Allowance for Doubtful Accounts and Notes Receivables from Investment in Sales-Type Leases

[0000926326-19-000007:notes:242]
The Company maintains an allowance for doubtful accounts for estimated losses resulting from the inability of its customers to make required payments. The Company records a specific allowance based on an analysis of individual past-due balances. Additionally, based on historical write-offs and the Company’s collection experience, the Company records an additional allowance based on a percentage of outstanding receivables. The Company performs credit evaluations of its customers’ financial condition. These evaluations require significant judgment and are based on a variety of factors including, but not limited to, current economic trends, payment history and a financial review of the customer. Actual collection losses may differ from management’s estimates, and such differences could be material to the Company’s financial position and results of operations.

[0000926326-19-000007:notes:243]
There were no customers that accounted for more than 10% of the Company’s accounts receivable balance as of December 31, 2018 and December 31, 2017.

[0000926326-19-000007:notes:244]
The retained in-house leases discussed above are considered financing receivables. The Company’s credit policies and its evaluation of credit risk and write-off policies are applied alike to trade receivables and the net investment in sales-type leases. For both, an account is generally past due after thirty days. The financing receivables also have customer-specific reserves for accounts identified for specific impairment and a non-specific reserve applied to the remaining population, based on factors such as current trends, the length of time the receivables are past due and historical collection experience. The retained in-house leases are not stratified by portfolio or class.

[0000926326-19-000007:notes:245]
Sales of Accounts Receivable

[0000926326-19-000007:notes:246]
The Company records the sale of its accounts receivables as in accordance with accounting guidance for transfers and servicing of financial assets. The Company transferred non-recourse accounts receivable totaling $46.6 million, $40.0 million, and $28.7 million during fiscal years 2018, 2017, and 2016, respectively, which approximated fair value, to leasing companies on a non-recourse basis. Accounts receivable balance included approximately $10.6 million, $0.1 million, and $0.2 million due from third-party leasing companies for transferred non-recourse accounts receivable as of December 31, 2018, December 31, 2017, and December 31, 2016, respectively.

[0000926326-19-000007:notes:247]
The Company has a supply agreement with one primary supplier for construction and supply of several sub-assemblies and inventory management of sub-assemblies used in its hardware products. There were no minimum purchase requirements. The contract with the Company’s supplier may be terminated by either the supplier or by the Company without cause and at any time upon delivery of two months’ notice. Purchases from this supplier were $54.8 million, $64.5 million, and $47.9 million for the years ended December 31, 2018, December 31, 2017, and December 31, 2016, respectively.

[0000926326-19-000007:notes:248]
Property and Equipment

[0000926326-19-000007:notes:249]
Property and equipment less accumulated depreciation are stated at historical cost. The Company’s expenditures for property and equipment are primarily for computer equipment and software used in the administration of its business, and for leasehold improvements to its leased facilities. The Company also develops molds and dies used in long-term manufacturing arrangements with suppliers and for production automation equipment used in the manufacturing of consumable blister card components. Depreciation and amortization is computed by use of the straight-line method over the estimated useful lives of the assets as stated below:

[0000926326-19-000007:notes:250]
| Computer equipment and related software | 3 - 5 years |
| Leasehold and building improvements | Shorter of the lease term or the estimated useful life |
| Furniture and fixtures | 5 - 7 years |
| Equipment | 3 - 12 years |

[0000926326-19-000007:notes:251]
Depreciation and amortization of property and equipment was $15.1 million, $16.2 million, and $15.0 million for the years ended December 31, 2018, December 31, 2017, and December 31, 2016, respectively.

[0000926326-19-000007:notes:252]
The Company capitalizes costs related to computer software developed or obtained for internal use in accordance with ASC 350-40, Internal-Use Software. Software obtained for internal use has generally been enterprise-level business and finance software that the Company customizes to meet its specific operational needs. Costs incurred in the application development phase are capitalized and amortized over their useful lives, which is generally five years. Costs recognized in the preliminary project phase and the post-implementation phase are expensed as incurred. The Company capitalized $1.1 million and $0.4 million of costs related to the application development of enterprise-level software that was included in property and equipment during the years ended December 31, 2018 and December 31, 2017, respectively.

[0000926326-19-000007:notes:253]
Software Development Costs

[0000926326-19-000007:notes:254]
The Company capitalizes software development costs in accordance with ASC 985-20, Costs of Software to Be Sold, Leased, or Marketed, under which certain software development costs incurred subsequent to the establishment of technological feasibility may be capitalized and amortized over the estimated lives of the related products. The Company establishes feasibility when it completes a working model and amortizes development costs over the estimated lives of the related products ranging from three to five years. The Company capitalized software development costs of $30.7 million and $15.0 million, which are included in other assets as of December 31, 2018 and December 31, 2017, respectively. The Company recorded $12.5 million, $9.7 million, and $7.1 million to cost of revenues for amortization of capitalized software development costs for the years ended December 31, 2018, December 31, 2017, and December 31, 2016, respectively. All development costs prior to the completion of a working model are recognized as research and development expense.

[0000926326-19-000007:notes:255]
The Company uses the acquisition method of accounting under the authoritative guidance on business combinations. Each acquired company’s operating results are included in the Company's Consolidated Financial Statements starting on the date of acquisition. The purchase price is equivalent to the fair value of consideration transferred. Tangible and identifiable intangible assets acquired and liabilities assumed as of the date of acquisition are recorded at the acquisition date fair value. Goodwill is recognized for the excess of purchase price over the net fair value of assets acquired and liabilities assumed.

[0000926326-19-000007:notes:256]
Amounts allocated to assets and liabilities are based upon fair values. Such valuations require management to make significant estimates and assumptions, especially with respect to the identifiable intangible assets. Management makes estimates of fair value based upon assumptions believed to be reasonable and that of a market participant. These estimates are based on historical experience and information obtained from the management of the acquired companies and the estimates are inherently uncertain. The separately identifiable intangible assets generally include customer relationships, technology, and trade names.

[0000926326-19-000007:notes:257]
Valuation of Share-Based Compensation

[0000926326-19-000007:notes:258]
The Company accounts for share-based compensation in accordance with ASC 718, Stock Compensation. The Company recognizes compensation expense related to share-based compensation based on the grant date estimated fair value.

[0000926326-19-000007:notes:259]
The fair value of stock options (“options”) on the grant date is estimated using the Black-Scholes option pricing model, which requires the following inputs: expected life, expected volatility, risk-free interest rate, expected dividend yield rate, exercise price, and closing price of its common stock on the date of grant. The expected volatility is based on a combination of historical and market-based implied volatility, and the expected life of the awards is based on the Company’s historical experience of employee stock option exercises, including forfeitures. Expense is recognized on a straight-line basis over the requisite service period.

[0000926326-19-000007:notes:260]
The fair value of restricted stock units (“RSUs”) is based on the stock price on the grant date. The fair value of restricted stock awards (“RSAs”) is their intrinsic value, which is the difference between the fair value of the underlying stock at the measurement date and the purchase price. The RSUs and RSAs are subject to a service vesting condition and are recognized on a straight-line basis over the requisite service period.

[0000926326-19-000007:notes:261]
The fair value of performance-based stock unit awards (“PSUs”) with service and market conditions is estimated using a Monte Carlo simulation model applying multiple awards approach. Expense is recognized when it is probable that the performance condition will be met using the accelerated attribution method over the requisite service period.

[0000926326-19-000007:notes:262]
The valuation assumptions used in estimating the fair value of employee share-based awards may change in future periods.

[0000926326-19-000007:notes:263]
Outbound freight billed to customers is recorded as product revenue. The related shipping and handling costs are expensed as part of selling, general, and administrative expense. Shipping and handling expenses were $14.1 million, $13.6 million, and $12.1 million for the years ended December 31, 2018, December 31, 2017, and December 31, 2016, respectively.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000926326-19-000007:notes:264]
Restructuring Expenses

[0000926326-19-000007:notes:265]
In the fourth quarter of 2018, the Company announced a company-wide organizational realignment initiative in order to ensure the organizational infrastructure is in place for future expected growth. During the year ended December 31, 2018, the Company incurred and accrued for $1.3 million of restructuring expenses, which includes severance and consulting-related expenses.

[0000926326-19-000007:notes:266]
On March 2, 2018, the Company initiated the realignment of its Automation and Analytics commercial group in North America and France. During the year ended December 31, 2018, the Company accrued and paid out $3.0 million of employee severance costs and related expenses.

[0000926326-19-000007:notes:267]
On February 15, 2017, the Company announced its plan to reduce its workforce by approximately 100 full-time employees and close the Company’s Nashville, Tennessee, and Slovenia facilities, which was completed in fiscal year 2017. The total cost for the plan was $4.2 million, which includes employee severance costs of approximately $3.7 million, and facility-related costs of approximately $0.6 million. For the year ended, December 31, 2017, the Company made payments of $4.2 million and the restructuring program was completed.

[0000926326-19-000007:notes:268]
In the second quarter of 2016, the Company integrated its sales and field organizations in North America to better serve its customers which resulted in a reduction in headcount of 36 employees. Accordingly, the Company incurred approximately $1.7 million of restructuring expenses in the year ended December 31, 2016, based on agreements with terminated employees covering salary and benefit continuation. For the year ended December 31, 2016, the Company made payments of $1.7 million and the restructuring program was completed.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000926326-19-000007:notes:269]
Deferred Revenues

[0000926326-19-000007:notes:270]
Short-term deferred revenues of $81.8 million and $78.8 million include deferred revenues from product sales and service contracts, net of deferred cost of sales of $11.1 million and $16.9 million as of December 31, 2018 and December 31, 2017, respectively. The short-term deferred revenues from product sales relate to delivered and invoiced products, pending installation and acceptance, expected to occur within the next twelve months.

[0000926326-19-000007:notes:271]
Long-term deferred revenues include deferred revenues from service contracts of $10.6 million as of both December 31, 2018 and December 31, 2017.


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0000926326-19-000007:notes:272]
Revenues

[0000926326-19-000007:notes:273]
|  | Year Ended December 31, |
|  | 2018 |  | 2017 |  | 2016 |
|  | (In thousands) |
| United States | $ | 685,881 |  |  | $ | 613,817 |  |  | $ | 594,851 |  |
| Rest of world (1) | 101,428 |  |  | 98,897 |  |  | 101,057 |  |
| Total revenues | $ | 787,309 |  |  | $ | 712,714 |  |  | $ | 695,908 |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0000926326-19-000007:notes:274]
The following table summarizes the changes in accumulated balances of other comprehensive income (loss) for the years ended December 31, 2018 and December 31, 2017:

[0000926326-19-000007:notes:275]
|  | Foreign currency translation adjustments |  | Unrealized gain (loss) on interest rate swap hedges |  | Total |
|  | (In thousands) |
| Balance as of December 31, 2016 | $ | (10,764 | ) |  | $ | 1,245 |  |  | $ | (9,519 | ) |
| Other comprehensive income (loss) before reclassifications | 3,810 |  |  | 409 |  |  | 4,219 |  |
| Amounts reclassified from other comprehensive income (loss) | — |  |  | (813 | ) |  | (813 | ) |
| Net current-period other comprehensive income (loss), net of tax | 3,810 |  |  | (404 | ) |  | 3,406 |  |
| Balance as of December 31, 2017 | (6,954 | ) |  | 841 |  |  | (6,113 | ) |
| Other comprehensive income (loss) before reclassifications | (4,320 | ) |  | 777 |  |  | (3,543 | ) |
| Amounts reclassified from other comprehensive income (loss), net of tax | — |  |  | (1,198 | ) |  | (1,198 | ) |
| Net current-period other comprehensive income (loss), net of tax | (4,320 | ) |  | (421 | ) |  | (4,741 | ) |
| Balance as of December 31, 2018 | $ | (11,274 | ) |  | $ | 420 |  |  | $ | (10,854 | ) |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000926326-19-000007:notes:276]
The following table summarizes the financial performance of the Company’s reporting segments, including a reconciliation of income from segment operations to income from total operations:

[0000926326-19-000007:notes:277]
|  | Year Ended December 31, |
|  | 2018 |  | 2017 |  | 2016 |
|  | Automation andAnalytics |  | Medication Adherence |  | Total |  | Automation and Analytics (1) |  | MedicationAdherence |  | Total |  | Automation and Analytics (1) |  | MedicationAdherence |  | Total |
|  | (In thousands) |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product revenues | $ | 462,379 |  |  | $ | 107,216 |  |  | $ | 569,595 |  |  | $ | 407,427 |  |  | $ | 102,774 |  |  | $ | 510,201 |  |  | $ | 433,524 |  |  | $ | 94,203 |  |  | $ | 527,727 |  |
| Services and other revenues | 193,300 |  |  | 24,414 |  |  | 217,714 |  |  | 179,514 |  |  | 22,999 |  |  | 202,513 |  |  | 163,387 |  |  | 4,794 |  |  | 168,181 |  |
| Total revenues | 655,679 |  |  | 131,630 |  |  | 787,309 |  |  | 586,941 |  |  | 125,773 |  |  | 712,714 |  |  | 596,911 |  |  | 98,997 |  |  | 695,908 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product revenues | 231,003 |  |  | 81,357 |  |  | 312,360 |  |  | 230,003 |  |  | 74,839 |  |  | 304,842 |  |  | 239,062 |  |  | 63,375 |  |  | 302,437 |  |
| Cost of services and other revenues | 88,254 |  |  | 14,365 |  |  | 102,619 |  |  | 78,440 |  |  | 10,795 |  |  | 89,235 |  |  | 71,905 |  |  | 4,481 |  |  | 76,386 |  |
| Total cost of revenues | 319,257 |  |  | 95,722 |  |  | 414,979 |  |  | 308,443 |  |  | 85,634 |  |  | 394,077 |  |  | 310,967 |  |  | 67,856 |  |  | 378,823 |  |
| Gross profit | 336,422 |  |  | 35,908 |  |  | 372,330 |  |  | 278,498 |  |  | 40,139 |  |  | 318,637 |  |  | 285,944 |  |  | 31,141 |  |  | 317,085 |  |
| Operating expenses | 188,303 |  |  | 41,430 |  |  | 229,733 |  |  | 184,857 |  |  | 41,735 |  |  | 226,592 |  |  | 186,872 |  |  | 24,843 |  |  | 211,715 |  |
| Income (loss) from operations | $ | 148,119 |  |  | $ | (5,522 | ) |  | $ | 142,597 |  |  | $ | 93,641 |  |  | $ | (1,596 | ) |  | $ | 92,045 |  |  | $ | 99,072 |  |  | $ | 6,298 |  |  | $ | 105,370 |  |
| Corporate costs |  |  |  |  | 98,205 |  |  |  |  |  |  | 80,900 |  |  |  |  |  |  | 83,965 |  |
| Income from operations |  |  |  |  | $ | 44,392 |  |  |  |  |  |  | $ | 11,145 |  |  |  |  |  |  | $ | 21,405 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000926326-19-000007:notes:278]
Segment and Geographical Information

[0000926326-19-000007:notes:279]
Segment Information

[0000926326-19-000007:notes:280]
The Company’s CODM is its Chief Executive Officer. The CODM allocates resources and evaluates the performance of the Company’s segments using information about its revenues, gross profit, and income from operations. Such evaluation excludes general corporate-level costs that are not specific to either of the reportable segments and are managed separately at the corporate level. Corporate-level costs include expenses related to executive management, finance and accounting, human resources, legal, training and development, and certain administrative expenses.

[0000926326-19-000007:notes:281]
The two operating segments, which are the same as the Company’s two reportable segments, are as follows:

[0000926326-19-000007:notes:282]
| • | Automation and Analytics. The Automation and Analytics segment is organized around the design, manufacturing, selling and servicing of medication and supply dispensing systems, pharmacy inventory management systems and related software and services. The Company’s Automation and Analytics products are designed to enable its customers to improve the effectiveness of the medication-use process and the efficiency of the medical-surgical supply chain, and contribute to better patient care and financial outcomes of medical facilities. The products in this segment are sold primarily to acute care (hospital) facilities. The financial results of InPharmics, acquired in the second quarter of 2017, and Aesynt, acquired in the first quarter of 2016, are included in the Automation and Analytics segment. |

[0000926326-19-000007:notes:283]
| • | Medication Adherence. The Medication Adherence segment primarily includes the development, manufacturing and selling of solutions to assist patients in becoming and remaining adherent to their medication regimens. These solutions comprise a variety of tools and aids that may be directly used by a pharmacist or a healthcare provider in their direct care for a patient, or used by patients themselves. Products include software-based systems, medication adherence packaging, equipment for fulfilling the packaging and ancillary products and services. These products, which are sold under the brand names SureMed and Omnicell, are used to manage medication administration outside of the hospital setting. The financial results of Ateb, acquired in the fourth quarter of 2016, is included in the Medication Adherence segment. |

[0000926326-19-000007:notes:284]
Significant Customers

[0000926326-19-000007:notes:285]
There were no customers that accounted for more than 10% of the Company’s total revenues or accounts receivable balance at and for the years ended December 31, 2018, December 31, 2017, and December 31, 2016, respectively.

[0000926326-19-000007:notes:286]
Geographical Information

[0000926326-19-000007:notes:287]
Property and equipment, net is attributed to the geographic location in which it is located.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000926326-19-000007:notes:288]
Equity Offerings

[0000926326-19-000007:notes:289]
On November 3, 2017, the Company entered into a Distribution Agreement (the “Distribution Agreement”) with J.P. Morgan Securities LLC, Wells Fargo Securities, LLC, and HSBC Securities (USA) Inc., as its sales agents, pursuant to which the Company may offer and sell from time to time through the sales agents up to $125.0 million maximum aggregate offering price of the Company’s common stock. Sales of the common stock pursuant to the Distribution Agreement may be made in negotiated transactions or transactions that are deemed to be “at the market” offerings as defined in Rule 415 under the Securities Act of 1933, including sales made directly on the Nasdaq Stock Market, or sales made to or through a market maker other than on an exchange.

[0000926326-19-000007:notes:290]
For the year ended December 31, 2017, the Company received gross proceeds of $14.7 million from sales of its common stock under the Distribution Agreement and incurred issuance costs of $0.8 million on sales of approximately 294,000 shares of its common stock at an average price of approximately $49.85 per share.

[0000926326-19-000007:notes:291]
For the year ended December 31, 2018, the Company received gross proceeds of $40.3 million from sales of its common stock under the Distribution Agreement and incurred issuance costs of $0.7 million on sales of approximately 557,000 shares of its common stock at an average price of approximately $72.40 per share. As of December 31, 2018, the Company had an aggregate of $70.0 million available to be offered under the Distribution Agreement.


## us-gaap:SubsequentEventsTextBlock

[0000926326-19-000007:notes:292]
Subsequent Events

[0000926326-19-000007:notes:293]
Corporate Restructuring

[0000926326-19-000007:notes:294]
During the first quarter of 2019, the Company transferred certain intellectual property that was residing in the Netherlands to the United States, as part of the company-wide organizational realignment initiative described in Note 16, Restructuring Expenses. The Company will record a one-time tax expense on the transaction gain, and the ongoing impact is not expected to be material.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000926326-19-000007:notes:295]
Balance Sheet Components


## us-gaap:TreasuryStockTextBlock

[0000926326-19-000007:notes:296]
Stock Repurchase Program

[0000926326-19-000007:notes:297]
On August 2, 2016, the Company’s Board of Directors (the “Board”) authorized a stock repurchase program providing for the repurchase of up to $50.0 million of the Company’s common stock (the “2016 Repurchase Program”). The 2016 Repurchase Program is in addition to the stock repurchase program approved by the Board on November 4, 2014 (the “2014 Repurchase Program”). As of December 31, 2018, the maximum dollar value of shares that may yet be purchased under the two repurchase programs was $54.9 million.

[0000926326-19-000007:notes:298]
The timing, price, and volume of repurchases are to be based on market conditions, relevant securities laws, and other factors. The stock repurchases may be made from time to time on the open market, in privately negotiated transactions, or pursuant to a Rule 10b-18 plan, subject to the terms and conditions of that certain Amendment of the Amended Credit Agreement, dated as of December 26, 2017, among the Company, the Lenders party thereto, and Wells Fargo Bank, National Association, as administrative agent. The stock repurchase programs do not obligate the Company to repurchase any specific number of shares, and the Company may terminate or suspend the repurchase programs at any time.

[0000926326-19-000007:notes:299]
During the years ended December 31, 2018, December 31, 2017, and December 31, 2016, the Company made no repurchases of its outstanding common stock.
