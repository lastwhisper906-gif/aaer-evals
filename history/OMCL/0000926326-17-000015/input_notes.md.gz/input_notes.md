# OMCL notes — 0000926326-17-000015


## omcl:ScheduleofSharebasedCompensationFutureIssuanceofSharesTableTextBlock

[0000926326-17-000015:notes:1]
The Company had the following ordinary shares reserved for future issuance under its equity incentive plans as of December 31, 2016:

[0000926326-17-000015:notes:2]
|  |  | Number of Shares |
|  |  | (In thousands) |
| Share options outstanding |  | 3,214 |  |
| Non-vested restricted stock awards |  | 719 |  |
| Shares authorized for future issuance |  | 3,143 |  |
| ESPP shares available for future issuance |  | 2,831 |  |
| Total shares reserved for future issuance |  | 9,907 |  |


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0000926326-17-000015:notes:3]
The pro forma adjustments include the impact of fair value adjustment related to deferred revenue, inventory fair value adjustment, amortization of intangible assets, stock-based compensation expense, interest expense and amortization of deferred issuance cost, and certain classification to conform to Omnicell's accounting policies.

[0000926326-17-000015:notes:4]
|  | Twelve months ended December 31, |
|  | 2016 |  | 2015 |
|  | (In thousands, except per share data) |
| Pro forma net revenues | $ | 718,439 |  |  | $ | 522,317 |  |
| Pro forma net income (loss) | $ | (1,330 | ) |  | $ | 1,978 |  |
| Pro forma net income (loss) per share | $ | (0.04 | ) |  | $ | 0.05 |  |
| Weighted average number of shares | 36,156 |  |  | 36,699 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000926326-17-000015:notes:5]
Business Combinations

[0000926326-17-000015:notes:6]
2016 Acquisition Activity

[0000926326-17-000015:notes:7]
On January 5, 2016, the Company completed the acquisition of all of the membership interests of Aesynt pursuant to the Aesynt Securities Purchase Agreement. Aesynt is a provider of automated medication management systems, including dispensing robots with storage solutions, medication storage and dispensing carts and cabinets, I.V. sterile preparation robotics and software, including software related to medication management. The total consideration was $271.5 million, net of cash acquired of $8.2 million. The results of Aesynt's operations have been included in our consolidated results of operations as of the time of the acquisition, and presented as part of the Automation & Analytics segment.

[0000926326-17-000015:notes:8]
On December 8, 2016, the Company completed its acquisition of ateb, Inc., and Ateb Canada Ltd. (together, “Ateb”) pursuant to Ateb's Securities Purchase Agreement for $40.7 million of cash consideration, net of $0.9 million cash acquired. The cash consideration, included the repayment of Ateb indebtedness and other adjustments provided for in the Ateb's Securities Purchase Agreement.  Ateb is a provider of pharmacy-based patient care solutions and the medication synchronization solutions leader to independent and chain pharmacies. The results of Ateb's operations have been included in our consolidated results of operations as of the time of the acquisition, and presented as part of the Medication Adherence segment.

[0000926326-17-000015:notes:9]
The Company accounted for the acquisitions of Aesynt and Ateb in accordance with the authoritative guidance on business combinations; therefore, the tangible and intangible assets acquired and liabilities assumed were recorded at fair value on the acquisition dates, respectively.  The following table represents the allocation of the purchase price to the assets acquired and the liabilities assumed by the Company during each acquisition, respectively, reconciled to the purchase price transferred included in the Company's Consolidated Balance Sheet:

[0000926326-17-000015:notes:10]
|  | Aesynt |  | Ateb(preliminary) |  | Total |
|  | (In thousands) |
| Cash | $ | 8,164 |  |  | $ | 902 |  |  | $ | 9,066 |  |
| Accounts receivable | 43,312 |  |  | 7,905 |  |  | 51,217 |  |
| Inventory | 19,021 |  |  | 225 |  |  | 19,246 |  |
| Other current assets | 3,787 |  |  | 1,239 |  |  | 5,026 |  |
| Total current assets | 74,284 |  |  | 10,271 |  |  | 84,555 |  |
| Property and equipment | 10,389 |  |  | 2,447 |  |  | 12,836 |  |
| Intangible assets | 123,700 |  |  | 12,500 |  |  | 136,200 |  |
| Goodwill | 163,599 |  |  | 20,832 |  |  | 184,431 |  |
| Other non-current assets | 968 |  |  | 1,009 |  |  | 1,977 |  |
| Total assets | 372,940 |  |  | 47,059 |  |  | 419,999 |  |
| Current liabilities | 26,753 |  |  | 2,314 |  |  | 29,067 |  |
| Deferred revenue, net | 25,512 |  |  | 2,776 |  |  | 28,288 |  |
| Non-current deferred tax liabilities | 38,622 |  |  | — |  |  | 38,622 |  |
| Other non-current liabilities | 2,431 |  |  | 367 |  |  | 2,798 |  |
| Total liabilities | 93,318 |  |  | 5,457 |  |  | 98,775 |  |
| Total purchase price | 279,622 |  |  | 41,602 |  |  | 321,224 |  |
| Total purchase price, net of cash received | $ | 271,458 |  |  | $ | 40,700 |  |  | $ | 312,158 |  |

[0000926326-17-000015:notes:11]
The $163.6 million of goodwill arising from the Aesynt acquisition is primarily attributed to sales of future products and services and Aesynt's assembled workforce. The Aesynt acquisition created one of the broadest product portfolio in the industry with significant offerings in automated dispensing systems, central pharmacy robotics, I.V. robotics and enterprise analytics. The goodwill has been assigned to the Automation & Analytics segment and is not deductible for tax purposes.  Since the acquisition, the Company adjusted the preliminary value assigned to goodwill by $1.2 million to reflect measurement period adjustments related to account receivable, inventory, and other assets and liabilities (inclusive of deferred taxes) of $1.6 million, $1.1 million and ($3.9) million respectively.

[0000926326-17-000015:notes:12]
The $20.8 million of goodwill arising from the Ateb acquisition is primarily attributed to sales of future products and services and Ateb's assembled workforce. The Ateb acquisition positions further the Company’s medication adherence portfolio, helping to expand the retail pharmacy footprint.

[0000926326-17-000015:notes:13]
Intangibles eligible for recognition separate from goodwill were those that satisfied either the contractual/legal criterion or the separability criterion in the accounting guidance. The identifiable intangible assets acquired and their estimated useful lives for amortization are as follows:

[0000926326-17-000015:notes:14]
|  | Aesynt |  | Ateb (preliminary) |
|  | Fair value |  | Weightedaverageuseful life |  | Fair value |  | Weightedaverageuseful life |
|  | (In thousands) |  | (In years) |  | (In thousands) |  | (In years) |
| Customer relationships | $ | 58,200 |  |  | 14-16 |  | $ | 8,900 |  |  | 12 |
| Developed technology | 38,800 |  |  | 8 |  | 3,400 |  |  | 5 |
| Backlog | 20,200 |  |  | 1-3 |  | — |  |  | - |
| In-process research and development ("IPR&D") (1) | 3,900 |  |  | - |  | — |  |  | - |
| Non-compete | 1,800 |  |  | 3 |  | 100 |  |  | 1 |
| Trade names | 800 |  |  | 1 |  | 100 |  |  | 1 |
| Total purchased intangible assets | $ | 123,700 |  |  |  |  | $ | 12,500 |  |  |  |

[0000926326-17-000015:notes:15]
(1) The amortization of the in-process R&D assets begins when the in-process R&D projects are complete.

[0000926326-17-000015:notes:16]
Aesynt Acquisition

[0000926326-17-000015:notes:17]
Customer relationships represent the fair value of the underlying relationships and agreements with Aesynt’s customers, acquired developed technology represents the fair value of Aesynt products that have reached technological feasibility and were part of Aesynt’s product offerings at the date of acquisition, backlog represents the fair value of sales order backlog at the date of acquisition, non-compete intangible asset represents the fair value of non-compete agreements with former key members of Aesynt's management, and trade name represents the fair value of brand and name recognition associated with the marketing of Aesynt’s products and services. In-process research and development ("IPR&D") represents the fair value of incomplete Aesynt research and development projects that had not reached technological feasibility as of the date of acquisition. Incremental costs incurred for those projects are expensed as incurred in research and development.

[0000926326-17-000015:notes:18]
The fair value of Aesynt trade names, acquired developed technology, and acquired IPR&D was determined based on an income approach using the relief-from-royalty method at the royalty rates of 0.5%, 4% to 8% and 12.5%, respectively. The fair value of customer relationships, backlog, and non-compete intangible assets were determined based on an income approach using the discounted cash flow method, at the discounted rates of 13%, 10% and13%, respectively. The intangible assets, except customer relationship and IPR&D, are being amortized over their estimated useful lives using the straight line method of amortization. The customer relationship intangible asset is being amortized using a double-declining method of amortization as such method better represents the economic benefits to be obtained. In accordance with authoritative guidance, the IPR&D is accounted for as an indefinite-lived intangible asset until completion or abandonment of the associated research and development efforts. IPR&D is tested for impairment during the period it is considered an indefinite lived asset. IPR&D related projects are expected to be completed in two to three years. As of December 31, 2016, none of the IPR&D projects have been completed, and they have progressed as previously estimated.

[0000926326-17-000015:notes:19]
Ateb Acquisition

[0000926326-17-000015:notes:20]
Customer relationships represent the fair value of the underlying relationships and agreements with Ateb’s customers expected to result in future sales, acquired developed technology represents the fair value of Ateb intellectual property incorporated in their products, non-compete intangible asset represents the fair value of non-compete agreements with former key members of Ateb's management, and trade name represents the fair value of brand and name recognition associated with the marketing of Ateb’s products and services.

[0000926326-17-000015:notes:21]
The fair value of Ateb trade names and acquired developed technology was determined based on an income approach using the relief-from-royalty method at the royalty rates of 0.5% and 5% to 6%, respectively. The fair value of customer relationships, and non-compete intangible assets were determined based on an income approach using the discounted cash flow method, both using a 15% discount rate. The intangible assets for non-compete agreements and trade name are being amortized over their estimated useful lives using the straight line method of amortization. The intangible assets for customer relationship and developed technology are being amortized using a double-declining method of amortization as such method better represents the economic benefits to be obtained.

[0000926326-17-000015:notes:22]
The Company incurred approximately $9.3 million in acquisition-related costs related to the Aesynt acquisition of which $6.4 million and $2.9 million were recognized in the years ended December 31, 2016 and 2015, respectively. These costs are included in selling, general and administrative expenses in the Company's Consolidated Statement of Operations.  During the year ended December 31, 2016, the Company incurred and expensed approximately $1.7 million of acquisition-related costs for Ateb.

[0000926326-17-000015:notes:23]
Revenues and losses from the Aesynt operations since the acquisition date through December 31, 2016 were $155.8 million and $40.5 million, respectively. Losses from operations includes the amortization of intangible assets of $27.3 million for the period presented. Revenues and losses from the Ateb operations since the acquisition date through December 31, 2016 were $1.7 million and $0.1 million, respectively, which included $0.3 million of amortization expense of intangible assets.

[0000926326-17-000015:notes:24]
2015 Acquisition Activity

[0000926326-17-000015:notes:25]
Mach4 Acquisition

[0000926326-17-000015:notes:26]
On April 21, 2015, the Company completed its acquisition of Mach4, a privately held German limited liability company with its registered office in Bochum, Germany pursuant to a share purchase agreement (the “Mach4 Agreement”), under which Omnicell International, Inc., a wholly-owned subsidiary of Omnicell Inc., purchased the entire issued share capital of Mach4 (the “Mach4 Acquisition”). Mach4 manufactures robotic dispensing systems used by retail and hospital pharmacies and the Mach4 acquisition provides the Company with a more robust product offering that is intended to be leveraged to create opportunities to sell additional Omnicell medication cabinets. The robotic storage and dispensing product offering provides the Company with a solution to better compete for international market share.

[0000926326-17-000015:notes:27]
Pursuant to the terms of the Mach4 Agreement, the Company paid approximately $17.3 million in cash after adjustments provided for in the Mach4 Agreement, of which $2.7 million was placed in an escrow fund, which were distributed to Mach4's former stockholders.

[0000926326-17-000015:notes:28]
Avantec Acquisition

[0000926326-17-000015:notes:29]
On April 30, 2015, the Company completed the acquisition of Avantec, the privately-held distributor of the Company’s products in the United Kingdom, pursuant to a share purchase agreement (the “Avantec Agreement”). Pursuant to the Avantec Agreement, the Company acquired the remaining 85% of issued and outstanding ordinary shares of Avantec that was not previously owned by the Company. Avantec develops medication and supply automation products that complement the Company's solutions for configurations suited to the United Kingdom marketplace, and had been the exclusive distributor of the Company's medication and supply automation solutions since 2005 in the United Kingdom.

[0000926326-17-000015:notes:30]
Pursuant to the terms of the Avantec Agreement, the Company agreed to pay $12.0 million in cash (the “Purchase Consideration”) and potential earn-out payments of up to $3.0 million payable after December 31, 2015 and an additional $3.0 million payable after December 31, 2016, based on bookings targets. The fair value of these potential earn-out payments as of the acquisition date was $5.6 million. Pursuant to the terms of the Avantec Agreement, the Company retained $1.8 million of the Purchase Consideration to be held to settle any future indemnification claims within 18 months period that the Company may make following the closing.  During the year 2016, the Company paid out $3.0 million in earn-out payments, $1.8 million in held back payments for future indemnifications, and recognized $0.6 million of contingent gain as certain booking targets were not met.  The Company expects to pay the remaining earn-out amount of $2.4 million in 2017.

[0000926326-17-000015:notes:31]
The fair value of the contingent consideration liability related to Avantec is revalued at each reporting date or more frequently if circumstances dictate. Changes in the fair value of this obligation are recorded as income or expense within other expense in the Company's Consolidated Statements of Operations. The significant unobservable inputs used in the fair value measurement of the contingent consideration are the achievement of booking targets and the discount rate. Significant increases or decreases in any of those inputs in isolation would result in a significantly lower or higher fair value measurement.

[0000926326-17-000015:notes:32]
Prior to the Avantec Acquisition, the Company accounted for its 15% ownership interest in Avantec as an equity-method investment. The Avantec acquisition date carrying book value of the Company's previous equity interest was $1.3 million. This transaction was accounted for as a step acquisition, which required the Company to re-measure its previously held 15% ownership interest to fair value and record the difference between the fair value and carrying value as a gain. The fair value of the equity investment was determined to be $4.7 million which resulted in a gain of $3.4 million.

[0000926326-17-000015:notes:33]
The Company accounted for the acquisitions of March4 and Avantec in accordance with the authoritative guidance on business combinations; therefore, the tangible and intangible assets acquired and liabilities assumed were recorded at fair value on the acquisition dates, respectively. The following table represents the allocation of the purchase price to the assets acquired and the liabilities assumed by the Company during each acquisition, respectively, reconciled to the purchase price transferred included in the Company's Consolidated Balance Sheet.

[0000926326-17-000015:notes:34]
|  | Mach4 |  | Avantec |  | Total |
|  | (In thousands) |
| Cash | $ | 397 |  |  | $ | 3,392 |  |  | $ | 3,789 |  |
| Accounts receivable | 3,743 |  |  | 3,607 |  |  | 7,350 |  |
| Inventory | 3,580 |  |  | 1,428 |  |  | 5,008 |  |
| Deferred tax assets and other current assets | 368 |  |  | 89 |  |  | 457 |  |
| Total current assets | 8,088 |  |  | 8,516 |  |  | 16,604 |  |
| Property and equipment | 463 |  |  | — |  |  | 463 |  |
| Intangibles | 7,710 |  |  | 6,341 |  |  | 14,051 |  |
| Goodwill | 10,591 |  |  | 15,606 |  |  | 26,197 |  |
| Other non-current assets | 52 |  |  | — |  |  | 52 |  |
| Total assets | 26,904 |  |  | 30,463 |  |  | 57,367 |  |
| Current liabilities | 3,684 |  |  | 4,125 |  |  | 7,809 |  |
| Non-current deferred tax liabilities | 2,564 |  |  | 1,269 |  |  | 3,833 |  |
| Deferred service revenue and gross profit | 2,314 |  |  | 928 |  |  | 3,242 |  |
| Other non-current liabilities | 1,056 |  |  | — |  |  | 1,056 |  |
| Total liabilities | 9,618 |  |  | 6,322 |  |  | 15,940 |  |
| Total purchase price | 17,286 |  |  | 24,141 |  |  | 41,427 |  |
| Total purchase price, net of cash received | $ | 16,889 |  |  | $ | 20,749 |  |  | $ | 37,638 |  |

[0000926326-17-000015:notes:35]
The goodwill arising from these acquisitions is primarily attributed to sales of future products and services and the assembled workforce. Goodwill is not deductible for tax purposes. Goodwill is not being amortized but is reviewed annually for impairment or more frequently if impairment indicators arise, in accordance with authoritative guidance.

[0000926326-17-000015:notes:36]
Intangible assets acquired and their respective estimated remaining useful lives over which each asset will be amortized are as follows:

[0000926326-17-000015:notes:37]
|  | Mach4 |  | Avantec |
|  | Fair value |  | Weightedaverageuseful life |  | Fair value |  | Weightedaverageuseful life |
|  | (In thousands) |  | (In years) |  | (In thousands) |  | (In years) |
| Developed technology | $ | 3,290 |  |  | 8 |  | $ | — |  |  | — |
| Trade name | 850 |  |  | 6 |  | 92 |  |  | 2 |
| Customer relationships | 3,570 |  |  | 10 |  | 5,834 |  |  | 12 |
| Backlog | — |  |  | — |  | 415 |  |  | 2 |
| Total purchased intangible assets | $ | 7,710 |  |  |  |  | $ | 6,341 |  |  |  |

[0000926326-17-000015:notes:38]
Pro forma financial information

[0000926326-17-000015:notes:39]
The following table presents certain unaudited pro forma information for illustrative purposes only, for the years ended December 31, 2016 and 2015 as if these acquisitions had been acquired on January 1, 2015. The pro forma information is not indicative of what would have occurred had the acquisitions taken place on January 1, 2015. The unaudited pro forma information combines the historical results of the acquisitions with the Company's consolidated historical results and includes certain adjustments reflecting the estimated impact of fair value adjustments for the respective periods. The pro forma adjustments include the impact of fair value adjustment related to deferred revenue, inventory fair value adjustment, amortization of intangible assets, stock-based compensation expense, interest expense and amortization of deferred issuance cost, and certain classification to conform to Omnicell's accounting policies.


## us-gaap:CapitalLeasesInFinancialStatementsOfLessorDisclosureTextBlock

[0000926326-17-000015:notes:40]
Net Investment in Sales-Type Leases

[0000926326-17-000015:notes:41]
On recurring basis, the Company enters into sales-type lease transactions which vary in length from 1.0 year to 5.0 years. The receivables as a result of these types of transactions are collateralized by the underlying equipment leased and consist of the following components at December 31, 2016 and December 31, 2015:

[0000926326-17-000015:notes:42]
|  | December 31, 2016 |  | December 31, 2015 |
|  | (In thousands) |
| Net minimum lease payments to be received | $ | 33,591 |  |  | $ | 22,255 |  |
| Less: unearned interest income portion | (2,763 | ) |  | (1,014 | ) |
| Net investment in sales-type leases | 30,828 |  |  | 21,241 |  |
| Less: short-term portion(1) | (10,243 | ) |  | (6,757 | ) |
| Long-term net investment in sales-type leases | $ | 20,585 |  |  | $ | 14,484 |  |

[0000926326-17-000015:notes:43]
(1) The short-term portion of the net investments in sales-type leases is included in the other current assets on the Consolidated Balance Sheets.

[0000926326-17-000015:notes:44]
The Company evaluates its sales-type leases individually and collectively for impairment. The allowance for credit losses were $0.3 million and $0.2 million as of December 31, 2016 and December 31, 2015 respectively.

[0000926326-17-000015:notes:45]
At December 31, 2016, the future minimum lease payments to be received under sales-type leases are as follows:

[0000926326-17-000015:notes:46]
| Year ended December 31, | (In thousands) |
| 2017 | $ | 11,172 |  |
| 2018 | 7,934 |  |
| 2019 | 6,240 |  |
| 2020 | 4,303 |  |
| 2021 | 2,396 |  |
| Thereafter | 1,546 |  |
| Total | $ | 33,591 |  |


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0000926326-17-000015:notes:47]
Cash and Cash Equivalents and Fair Value of Financial Instruments. The Company classifies investments as cash equivalents if their original or remaining contractual maturity is three months or less at the date of purchase. Cash equivalents are carried at amounts that approximate fair value due to the short period of time to maturity. The Company's cash equivalents are maintained in demand deposit accounts with financial institutions of high credit quality, and are invested in institutional money market funds, short-term bank time deposits and similar short duration instruments with fixed maturities. The Company continuously monitors the credit worthiness of the financial institutions and institutional money market funds in which it invests. The Company has not experienced any credit losses from its cash investments.


## us-gaap:CommissionsExpensePolicyPolicyTextBlock

[0000926326-17-000015:notes:48]
Commissions

[0000926326-17-000015:notes:49]
Sales commissions are incremental and directly related to customer sales contracts in which revenue is deferred. These commission costs are accrued and recorded in prepaid expenses upon execution of a non-cancelable customer contract and subsequently expensed in the period of revenue recognition.


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000926326-17-000015:notes:50]
Commitments and Contingencies

[0000926326-17-000015:notes:51]
Lease commitments

[0000926326-17-000015:notes:52]
The Company leases office space and office equipment under operating leases. Commitments under operating leases primarily relate to leasehold property and office equipment. Rent expense was $9.8 million, $7.0 million and $6.8 million for the years ended December 31, 2016, December 31, 2015 and December 31, 2014, respectively.

[0000926326-17-000015:notes:53]
The minimum future payments on non-cancelable operating leases are as follows:

[0000926326-17-000015:notes:54]
| For the year ended December 31, | (In thousands) |
| 2017 | $ | 11,300 |  |
| 2018 | 10,994 |  |
| 2019 | 10,995 |  |
| 2020 | 7,358 |  |
| 2021 | 6,719 |  |
| Thereafter | 10,326 |  |
| Total minimum future lease payments | $ | 57,692 |  |

[0000926326-17-000015:notes:55]
Purchase obligations

[0000926326-17-000015:notes:56]
During the course of the business, we issue purchase orders based on our current manufacturing needs. As of December 31, 2016, the Company had non-cancelable purchase commitments of $42.9 million, which are expected to be paid within the next twelve months.

[0000926326-17-000015:notes:57]
Legal proceedings

[0000926326-17-000015:notes:58]
The Company is currently involved in various legal proceedings. As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any accrual for contingent liabilities associated with the legal proceedings described below based on its belief that any potential loss, while reasonably possible, is not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of this contingency or because of the diversion of management's attention and the creation of significant expenses.

[0000926326-17-000015:notes:59]
The Company is not a party to any legal proceedings that management believes may have a material impact on the Company's financial position or results of operations.

[0000926326-17-000015:notes:60]
Guarantees

[0000926326-17-000015:notes:61]
As permitted under Delaware law and the Company's certificate of incorporation and bylaws, the Company has agreed to indemnify its directors and officers against certain losses that they may suffer by reason of the fact that such persons are, were or become its directors or officers. The term of the indemnification period is for the director’s or officer’s lifetime and there is no limit on the potential amount of future payments that the Company could be required to make under these indemnification agreements. The Company has purchased a directors’ and officers’ liability insurance policy that may enable it to recover a portion of any future payments that it may be required to make under these indemnification agreements. Assuming the applicability of coverage and the willingness of the insurer to assume coverage and subject to certain retention, loss limits and other policy provisions, the Company believes it is unlikely that the Company will be required to pay any material amounts pursuant to these indemnification obligations. However, no assurances can be given that the insurers will not attempt to dispute the validity, applicability or amount of coverage without expensive and time-consuming litigation against the insurers.

[0000926326-17-000015:notes:62]
Additionally, the Company undertakes indemnification obligations in its ordinary course of business in connection with, among other things, the licensing of its products and the provision of its support services. In the ordinary course of the Company's business, the Company has in the past and may in the future agree to indemnify another party, generally its business affiliates or customers, against certain losses suffered or incurred by the indemnified party in connection with various types of claims, which may include, without limitation, claims of intellectual property infringement, certain tax liabilities, its gross negligence or intentional acts in the performance of support services and violations of laws. The term of these indemnification obligations is generally perpetual. In general, the Company attempts to limit the maximum potential amount of future payments that it may be required to make under these indemnification obligations to the amounts paid to it by a customer, but in some cases the obligation may not be so limited. In addition, the Company has in the past and may in the future warrant to its customers that its products will conform to functional specifications for a limited period of time following the date of installation (generally not exceeding 30 days) or that its software media is free from material defects. Sales contracts for certain of the Company's medication packaging systems often include limited warranties for up to six months, but the periodic activity and ending warranty balances the Company records have historically been immaterial.

[0000926326-17-000015:notes:63]
From time to time, the Company may also warrant that its professional services will be performed in a good and workmanlike manner or in a professional manner consistent with industry standards. The Company generally seeks to disclaim most warranties, including any implied or statutory warranties such as warranties of merchantability, fitness for a particular purpose, title, quality and non-infringement, as well as any liability with respect to incidental, consequential, special, exemplary, punitive or similar damages. In some states, such disclaimers may not be enforceable. If necessary, the Company would provide for the estimated cost of product and service warranties based on specific warranty claims and claim history. The Company has not been subject to any significant claims for such losses and have not incurred any material costs in defending or settling claims related to these indemnification obligations. Accordingly, the Company believes it is unlikely that the Company will be required to pay any material amounts pursuant to these indemnification obligations or potential warranty claims and, therefore, no material liabilities have been recorded for such indemnification obligations as of December 31, 2016 and December 31, 2015.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000926326-17-000015:notes:64]
Employee Benefits and Share-Based Compensation

[0000926326-17-000015:notes:65]
Stock purchase plan

[0000926326-17-000015:notes:66]
1997 Employee Stock Purchase Plan

[0000926326-17-000015:notes:67]
The Company has an Employee Stock Purchase Plan ("ESPP"), under which employees can purchase shares of its common stock based on a percentage of their compensation, but not greater than 15% of their earnings; provided, however, an eligible employee's right to purchase shares of the Company's common stock may not accrue at a rate which exceeds $25,000 of the fair market value of such shares for each calendar year in which such rights are outstanding. The purchase price per share must be equal to the lower of 85% of the fair value of the common stock at the beginning of a 24-month offering period or the end of each six-month purchasing period.

[0000926326-17-000015:notes:68]
At the Company's 2009 Annual Meeting of Stockholders (the "2009 Annual Meeting"), its stockholders approved an amendment to the ESPP, which added 2.6 million shares to the reserve for future issuance. At the Company's 2015 Annual Meeting of Stockholders (the "2015 Annual Meeting"), its stockholders approved an amendment to the ESPP, which added and additional 3.0 million shares to the reserve for future issuance. There was a total of 2.8 million shares reserved for future issuance under the ESPP as of December 31, 2016.

[0000926326-17-000015:notes:69]
For the year ended December 31, 2016, employees purchased 0.4 million shares of common stock under the ESPP and an aggregate of 5.5 million shares were issued under the ESPP as of December 31, 2016.

[0000926326-17-000015:notes:70]
Stock award plans

[0000926326-17-000015:notes:71]
2009 Equity Incentive Plan

[0000926326-17-000015:notes:72]
On May 19, 2009, at the Company's 2009 Annual Meeting, the stockholders approved the Omnicell, Inc. 2009 Equity Incentive Plan, and as subsequently amended, (the "2009 Plan"). The 2009 Plan provides for the issuance of incentive stock options, non-statutory stock options, stock appreciation rights, restricted stock awards, restricted stock unit awards, performance stock awards, performance cash awards and other stock awards to the Company's employees, directors and consultants. The 2009 Plan succeeded the 1999 Equity Incentive Plan, the 2003 Equity Incentive Plan and the 2004 Equity Incentive Plan (collectively, the "Prior Plans"). No additional awards will be granted under any of the Prior Plans; however, all outstanding stock awards granted under the Prior Plans continue to be subject to the terms and conditions as set forth in the agreements evidencing such stock awards.

[0000926326-17-000015:notes:73]
On December 16, 2010, at a Special Meeting of Stockholders, the Company's stockholders approved an amendment to increase the number of shares of common stock authorized for issuance under the 2009 Plan by 2.6 million shares and to provide that the number of common stock shares available for issuance under the 2009 Plan be reduced by 1.8 shares for each share granted as a full-value award granted on and after October 1, 2010. For each share granted as a full-value award granted prior to October 1, 2010, future shares available for grants under the 2009 Plan were reduced by 1.4 shares. Awards granted as stock options and stock appreciation rights continue to reduce the number of shares available for issuance under the 2009 Plan on a one-for-one basis. At the Company's 2013 Annual Meeting of Stockholders, the Company's stockholders approved an amendment to the 2009 Plan to increase the number of shares of common stock authorized for issuance by 2.5 million shares. At the 2015 Annual Meeting, the Company's stockholders approved an amendment to the 2009 Plan to increase the number of shares of common stock authorized for issuance by 3.2 million shares and to provide that number of common stock shares available for issuance under the 2009 Plan be reduced by 2.15 shares for each share granted as a full value award on or after December 31, 2014. In addition, at the 2015 Annual Meeting, the Company's stockholders approved amendments to the 2009 Plan Stock providing that: (i) awards granted under the 2009 Plan will be subject to recoupment in accordance with any clawback policy that the Company may be required to adopt pursuant to applicable law and listing requirements and (ii) that the 2009 Plan will not expire by its terms but that no incentive stock options may be granted after the ten year anniversary of the earlier of the date that the 2009 Plan was adopted by the Company's Board of Directors or the date that the 2009 Plan was approved by its stockholders. There were 7.1 million shares of common stock reserved for future issuance under the 2009 Plan as of December 31, 2016.

[0000926326-17-000015:notes:74]
Options granted under the 2009 Plan become exercisable over periods of up to four years, with one-fourth of the shares vesting one year from the vesting commencement date with respect to initial grants, and the remaining shares vesting in 36 equal monthly installments thereafter. The Company also grants both restricted stock and restricted stock units to participants under the 2009 Plan. Awards of restricted stock to non-employee directors are granted on the date of the annual meeting of stockholders and vest in full on the date of the next annual meeting of stockholders, provided such non-employee director remains a director on such date. The fair value of the award on the date of issuance is amortized to expense from the date of grant to the date of vesting. RSUs granted to employees vest over a period of four years and are expensed ratably on a straight-line basis over the vesting period.

[0000926326-17-000015:notes:75]
Performance-based Restricted Stock Units

[0000926326-17-000015:notes:76]
In 2011, the Company began incorporating performance-based restricted stock units ("PSUs") as an element of its executive compensation plans. In 2012, the Company granted 125,000 PSUs to its executive officers, of which 62,500 PSUs became eligible for vesting upon the achievement of a certain level of shareholder return. In 2013, the Company granted 137,500 PSUs to its executive officers all of which became eligible for vesting upon the achievement of a certain level of shareholder return. In 2014, the Company granted 132,500 PSUs to its executive officers, a portion became eligible for vesting upon the achievement of a certain level of shareholder return. In 2015, the Company granted 60,000 PSUs to its executive officers, all of which became eligible for vesting upon the achievement of a certain level of shareholder return. In 2016, the Company granted 122,740 PSUs to its executive officers, all, none or a portion of which may become eligible for vesting depending on the level of shareholder return for the period from March 1, 2016 through March 1, 2017.

[0000926326-17-000015:notes:77]
The fair value of a PSU award is determined using a Monte Carlo simulation model. The number of shares that vest at the end of the performance period depends on the percentile ranking of the total shareholder return for Omnicell stock over the performance period relative to the total shareholder return of each of the other companies in the NASDAQ Healthcare Index (the "Index").

[0000926326-17-000015:notes:78]
Vesting for the PSUs is based both on the percentile placement of the Company's total stockholder return among the companies listed in the NASDAQ Health Care Index and time-based vesting. The Company calculates total stockholder return based on the one year annualized rates of return reflecting price appreciation plus reinvestment of dividends. For PSUs granted on February 4, 2016, stock price appreciation is calculated based on the trailing 20-day average stock price just prior the first trading day of March 2016, compared to the trailing 20-day average stock price just prior the first trading day of March 2017. For PSUs granted on February 6, 2015, stock price appreciation is calculated based on the trailing 20-day average stock price just prior the first trading day of March 2015, compared to the trailing 20-day average stock price just prior the first trading day of March 2016.

[0000926326-17-000015:notes:79]
On March 3, 2015, the Compensation Committee confirmed 74.4% as the percentile rank of the Company's 2014 total stockholder return. This resulted in 100% of the 2014 PSUs, or 132,500 shares, as eligible for further time-based vesting. The eligible performance based restricted stock unit awards will vest as follows: 25% of the eligible shares vested immediately on March 3, 2015 with the remaining eligible awards vesting in equal increments, semi-annually, over the subsequent three-year period beginning on June 15th and December 15th of the year after the date of grant and each subsequent year. Vesting is contingent upon continued service. Of the 132,500 shares eligible for time-based vesting under the 2014 PSUs 93,000 shares have vested as of December 31, 2016.

[0000926326-17-000015:notes:80]
On March 7, 2016, the Compensation Committee confirmed 66.0% as the percentile rank of the Company's 2016 total stockholder return. This resulted in 100% of the 2015 PSUs, or 60,000 shares, as eligible for further time-based vesting. The eligible performance based restricted stock unit awards will vest as follows: 25% of the eligible shares vested immediately on March 7, 2016 with the remaining eligible awards vesting in equal increments, semi-annually, over the subsequent three-year period beginning on June 15th and December 15th of the year after the date of grant and each subsequent year. Vesting is contingent upon continued service. Of the 60,000 shares eligible for time-based vesting under the 2015 PSUs, 30,000 shares have vested as of December 31, 2016.

[0000926326-17-000015:notes:81]
Valuation of share-based awards

[0000926326-17-000015:notes:82]
The following assumptions were used to value share options and ESPP shares granted pursuant to our equity incentive

[0000926326-17-000015:notes:83]
plans:

[0000926326-17-000015:notes:84]
|  | Year Ended |
|  | December 31, 2016 |  | December 31, 2015 |  | December 31, 2014 |
| Stock Option Plans |  |  |  |  |  |
| Risk-free interest rate | 1.5 | % |  | 1.7 | % |  | 1.6 | % |
| Dividend yield | — | % |  | — | % |  | — | % |
| Expected volatility | 30.6 | % |  | 32.0 | % |  | 34.9 | % |
| Expected life (in years) | 4.9 years |  |  | 5.0 years |  |  | 4.8 years |  |

[0000926326-17-000015:notes:85]
|  | Year Ended |
|  | December 31, 2016 |  | December 31, 2015 |  | December 31, 2014 |
| Employee Stock Purchase Plan |  |  |  |  |  |
| Risk-free interest rate | 0.34% - 0.79% |  |  | 0.03% - 0.79% |  |  | 0.03% - 0.53% |  |
| Dividend yield | — | % |  | — | % |  | — | % |
| Expected volatility | 25.8% - 34.8% |  |  | 25.7% - 37.5% |  |  | 29.5% - 42.1% |  |
| Expected life (in years) | 0.5 - 2.0 |  |  | 0.5 - 2.0 |  |  | 0.5 - 2.0 |  |

[0000926326-17-000015:notes:86]
Share-based compensation expense

[0000926326-17-000015:notes:87]
The Company accounts for share-based awards granted to employees and directors, including employee stock option awards, restricted stock, PSUs and RSUs issued pursuant to the 2009 Plan and employee stock purchases made under its ESPP using the estimate grant date fair value method of accounting in accordance with ASC 718, Stock Compensation. The Company values options and ESPP shares using the Black-Scholes-Merton option-pricing model. Restricted stock and time-based RSUs are valued at the grant date fair value of the underlying common shares. The PSUs are valued using the Monte Carlo simulation model.

[0000926326-17-000015:notes:88]
The following table sets forth the total share-based compensation expense recognized in the Company's Consolidated Statements of Income:

[0000926326-17-000015:notes:89]
|  | Year Ended |
|  | December 31, 2016 |  | December 31, 2015 |  | December 31, 2014 |
|  | (In thousands) |
| Cost of product and service revenues | $ | 2,596 |  |  | $ | 2,111 |  |  | $ | 1,456 |  |
| Research and development | 3,128 |  |  | 2,060 |  |  | 1,655 |  |
| Selling, general and administrative | 13,776 |  |  | 10,750 |  |  | 9,674 |  |
| Total share-based compensation expense | $ | 19,500 |  |  | $ | 14,921 |  |  | $ | 12,785 |  |

[0000926326-17-000015:notes:90]
The Company did not capitalize any share-based compensation as inventory as such amounts were not material for the years ended December 31, 2016, December 31, 2015 and December 31, 2014. Income tax benefits realized from share-based compensation were $5.4 million, $5.0 million and $4.5 million, for the years ended December 31, 2016, December 31, 2015 and December 31, 2014, respectively.

[0000926326-17-000015:notes:91]
Stock options activity

[0000926326-17-000015:notes:92]
A summary of the stock option activity under the 2009 Plan is presented below:

[0000926326-17-000015:notes:93]
|  | Number ofShares |  | Weighted-AverageExercise Price |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2015 | 2,688 |  |  | $ | 22.89 |  |  | 6.9 |  |  |
| Granted (Awarded) | 1,055 |  |  | 32.11 |  |  |  |  |  |
| Exercised (Released) | (406 | ) |  | 19.58 |  |  |  |  |  |
| Expired | (8 | ) |  | 30.43 |  |  |  |  |  |
| Forfeited | (115 | ) |  | 30.19 |  |  |  |  |  |
| Outstanding at December 31, 2016 | 3,214 |  |  | 26.06 |  |  | 7.3 |  | $ | 26,331 |  |
| Exercisable at December 31, 2016 | 1,487 |  |  | 20.23 |  |  | 5.4 |  | 20,459 |  |
| Vested and expected to vest at December 31, 2016 and thereafter | 3,007 |  |  | 25.66 |  |  | 7.2 |  | $ | 25,778 |  |

[0000926326-17-000015:notes:94]
The weighted-average fair value per share of options granted during 2016, 2015 and 2014 was $9.33, $9.67 and $9.12, respectively. The intrinsic value of options exercised during 2016, 2015 and 2014 was $5.6 million, $11.3 million and $14.1 million, respectively.

[0000926326-17-000015:notes:95]
As of December 31, 2016, total unrecognized compensation cost related to unvested stock options was $13.3 million, which is expected to be recognized over a weighted-average vesting period of 3.0 years.  As of December 31, 2015, total unrecognized compensation cost related to unvested stock options was $11.2 million, which is expected to be recognized over a weighted-average vesting period of 2.9 years.

[0000926326-17-000015:notes:96]
Restricted stock activity

[0000926326-17-000015:notes:97]
Summaries of the restricted stock activity under the 2009 Plan are presented below:

[0000926326-17-000015:notes:98]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Restricted Stock Units |  |  |  |  |  |  |  |
| Non-vested at December 31, 2015 | 417 |  |  | $ | 28.49 |  |  | 1.6 |  |  |
| Granted (Awarded) | 289 |  |  | 32.58 |  |  |  |  |  |
| Vested (Released) | (179 | ) |  | 26.83 |  |  |  |  |  |
| Forfeited | (22 | ) |  | 28.37 |  |  |  |  |  |
| Non-vested at December 31, 2016 | 505 |  |  | 31.42 |  |  | 1.6 |  | $ | 17,135 |  |

[0000926326-17-000015:notes:99]
The weighted-average grant date fair value per share of Restricted Stock Units ("RSUs") granted during 2016, 2015 and 2014 was $32.58, $31.44 and $28.88, respectively. The total fair value of RSUs that vested in 2016, 2015 and 2014 was $4.8 million, $4.7 million and $3.2 million, respectively.

[0000926326-17-000015:notes:100]
As of December 31, 2016, total unrecognized compensation cost related to RSUs was $12.8 million, which is expected to be recognized over the remaining weighted-average vesting period of 2.9 years. As of December 31, 2015, total unrecognized compensation cost related to RSUs was $11.2 million, which is expected to be recognized over the remaining weighted-average vesting period of 2.9 years.

[0000926326-17-000015:notes:101]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |
|  | (In thousands, except per share data) |
| Restricted Stock Awards |  |  |  |
| Non-vested at December 31, 2015 | 31 |  |  | $ | 35.97 |  |
| Granted (Awarded) | 34 |  |  | 31.59 |  |
| Vested (Released) | (35 | ) |  | 35.45 |  |
| Forfeited | — |  | — |  | — |  |
| Non-vested at December 31, 2016 | 30 |  |  | $ | 31.57 |  |

[0000926326-17-000015:notes:102]
The weighted-average grant date fair value per share of Restricted Stock Awards ("RSAs") granted during 2016, 2015 and 2014 was $31.59, $36.05 and $26.42, respectively. The total fair value of RSAs that vested in 2016, 2015 and 2014 was $1.2 million, $1.1 million and $1.0 million, respectively.

[0000926326-17-000015:notes:103]
As of December 31, 2016, total unrecognized compensation cost related to RSAs was $0.4 million, which is expected to be recognized over the remaining weighted-average vesting period of 0.4 years. As of December 31, 2015, total unrecognized compensation cost related to RSAs was $0.4 million, which was expected to be recognized over the remaining weighted-average vesting period of 0.4 years.

[0000926326-17-000015:notes:104]
Performance-based restricted stock unit activity

[0000926326-17-000015:notes:105]
A summary of the performance-based restricted stock activity under the 2009 Plan is presented below:

[0000926326-17-000015:notes:106]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value Per Unit |
|  | (In thousands, except per share data) |
| Non-vested at December 31, 2015 | 151 |  |  | $ | 23.33 |  |
| Granted (Awarded) | 123 |  |  | 24.66 |  |
| Vested (Released) | (90 | ) |  | 21.95 |  |
| Forfeited | — |  |  | — |  |
| Nov-vested at December 31, 2016 | 184 |  |  | $ | 24.89 |  |

[0000926326-17-000015:notes:107]
The weighted-average grant date fair value per share of PSUs granted during 2016, 2015 and 2014 was $24.66, $29.56 and $20.94, respectively. The total fair value of PSUs that vested in 2016, 2015 and 2014 was $2.0 million, $1.9 million and $1.5 million, respectively.

[0000926326-17-000015:notes:108]
As of December 31, 2016, total unrecognized compensation cost related to PSUs was approximately $1.6 million, which is expected to be recognized over the remaining weighted-average period of 1.2 years. As of December 31, 2015, total unrecognized compensation cost related to PSUs was approximately $1.5 million, which was expected to be recognized over the remaining weighted-average period of 1.2 years.

[0000926326-17-000015:notes:109]
Employee Stock Purchase Plan

[0000926326-17-000015:notes:110]
The unrecognized compensation cost related to the shares to be purchased under the ESPP was approximately $3.5 million, and is expected to be recognized over a weighted-average period of 1.2 years as of December 31, 2016.

[0000926326-17-000015:notes:111]
Summary of Shares Reserved for Future Issuance under Equity Incentive Plans

[0000926326-17-000015:notes:112]
401(k) Plan

[0000926326-17-000015:notes:113]
The Company has established a pre-tax savings plan under Section 401(k) of the Internal Revenue Code. The 401(k) Plan allows eligible employees in the United States to voluntarily contribute a portion of their pre-tax salary, subject to a maximum limit specified in the Internal Revenue Code. The Company matches 50% of employee contributions up to $2,000, annually.  The Company's contributions under this plan were $1.9 million, $1.8 million and $1.3 million in 2016, 2015 and 2014, respectively.


## us-gaap:ConsolidationPolicyTextBlock

[0000926326-17-000015:notes:114]
Principles of consolidation

[0000926326-17-000015:notes:115]
The accompanying Consolidated Financial Statements have been prepared in accordance with U.S. GAAP and include all adjustments necessary for the fair presentation of the Company's consolidated financial position, results of operations and cash flows for the periods presented. The Consolidated Financial Statements include the Company's accounts as well as those of its wholly owned subsidiaries after the elimination of intercompany balances and transactions.


## us-gaap:DebtDisclosureTextBlock

[0000926326-17-000015:notes:116]
Debt and Credit Agreement

[0000926326-17-000015:notes:117]
2016 Senior Secured Credit Facility

[0000926326-17-000015:notes:118]
On January 5, 2016, the Company entered into a $400 million senior secured credit facility pursuant to a credit agreement, by and among the Company, the lenders from time to time party thereto, Wells Fargo Securities, LLC, as Sole Lead Arranger and Wells Fargo Bank, National Association, as administrative agent (the “Credit Agreement”). The Credit Agreement provides for (a) a  five-year revolving credit facility of $200 million (the “Revolving Credit Facility”) and (b) a five-year $200 million term loan facility (the “Term Loan Facility” and together with the Revolving Credit Facility, the “Facilities”). In addition, the Credit Agreement includes a letter of credit sub-limit of up to $10 million and a swing line loan sub-limit of up to $10 million. The Credit Agreement expires on January 5, 2021, upon which date all remaining outstanding borrowings are due and payable.

[0000926326-17-000015:notes:119]
Loans under the Facilities bear interest, at the Company’s option, at a rate equal to either (a) the LIBOR Rate, plus an applicable margin ranging from 1.50% to 2.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) LIBOR for an interest period of one month, plus an applicable margin ranging from 0.50% to 1.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the 2016 Credit Agreement). Undrawn commitments under the Revolving Credit Facility will be subject to a commitment fee ranging from 0.20% to 0.35% per annum based on the Company’s Consolidated Total Net Leverage Ratio on the average daily unused portion of the Revolving Credit Facility. A letter of credit participation fee ranging from 1.50% to 2.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio will accrue on the average daily amount of letter of credit exposure.

[0000926326-17-000015:notes:120]
The Company is permitted to make voluntary prepayments at any time without payment of a premium or penalty, except for any amounts relating to the LIBOR breakage indemnity described in the Credit Agreement. The Company is required to make mandatory prepayments under the Term Loan Facility with (a) net cash proceeds from any issuances of debt (other than certain permitted debt) and (b) net cash proceeds from certain asset dispositions (other than certain asset dispositions) and insurance and condemnation events (subject to reinvestment rights and certain other exceptions). Loans under the Term Loan Facility will amortize in quarterly installments, equal to 5% per annum of the original principal amount thereof during the first two years, which shall increase to 10% per annum during the third and fourth years, and 15%  per annum during the fifth year, with the remaining balance payable on January 5, 2021. The Company is required to make mandatory prepayments under the Revolving Credit Facility if at any time the aggregate outstanding principal amount of loans together with the total amount of outstanding letters of credit exceeds the aggregate commitments, with such mandatory prepayment to be equal to the amount of such excess.

[0000926326-17-000015:notes:121]
The Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends and other distributions. The Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum consolidated total leverage ratio and maintain a minimum fixed charge coverage ratio.  The Company’s obligations under the Credit Agreement and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and the subsidiary guarantors’ assets. In connection with entering into the Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a collateral agreement and subsidiary guaranty agreement. The Company was in full compliance with all covenants as of December 31, 2016.

[0000926326-17-000015:notes:122]
On January 5, 2016, the Company borrowed the full $200 million under the Term Loan Facility and $55 million under the Revolving Credit Facility to complete the Aesynt acquisition and pay related fees and expenses. On December 2, 2016, the Company borrowed an additional $40 million under the Revolver Credit Facility to complete the Ateb acquisition and pay related fees and expenses. In connection with these Facilities, the Company incurred $7.9 million of debt issuance costs. The debt issuance costs were capitalized and presented as a direct deduction from the carrying amount of that debt liability in accordance with the accounting guidance. The debt issuance costs are being amortized to interest expense using the straight line method from issuance date through 2021. Interest expense was $5.3 million and $0 for the year ended December 31, 2016 and December 31, 2015, respectively.

[0000926326-17-000015:notes:123]
The components of the Company’s debt obligations as of December 31, 2016 and December 31, 2015 are as follows:

[0000926326-17-000015:notes:124]
|  | December 31, 2015 | Borrowings | Repayment / Amortization | December 31, 2016 |
|  | (In thousands) |
| Term loan facility | $ | — |  | $ | 200,000 |  | $ | (7,500 | ) | $ | 192,500 |  |
| Revolving credit facility | — |  | 95,000 |  | (27,000 | ) | 68,000 |  |
| Total debt under the facilities | — |  | 295,000 |  | (34,500 | ) | 260,500 |  |
| Less: Deferred issuance cost | — |  | (7,949 | ) | 1,590 |  | (6,359 | ) |
| Total Debt, net of deferred issuance cost | $ | — |  | $ | 287,051 |  | $ | (32,910 | ) | $ | 254,141 |  |
| Long term debt, current portion, net of deferred issuance cost |  |  |  | 8,410 |  |
| Long term debt, net of deferred issuance cost |  |  |  | $ | 245,731 |  |

[0000926326-17-000015:notes:125]
As of December 31, 2016, the carrying amount, net of deferred issuance cost of $254.1 million approximates the fair value of $256.5 million. The Company's debt facilities are classified as a Level 3 in the fair value hierarchy. The calculation of the fair value is based on a discounted cash flow model using observable market inputs and taking into consideration variables such as interest rate changes, comparable instruments, and long-term credit ratings.

[0000926326-17-000015:notes:126]
2013 Credit Agreement

[0000926326-17-000015:notes:127]
In September 2013, the Company entered into a credit agreement (the "Credit Agreement") with Wells Fargo Bank, National Association, as administrative agent, and the lenders from time to time party thereto. The Credit Agreement provided for a $75.0 million revolving credit facility with a $10.0 million letter of credit sub-limit. Loans under the Credit Agreement had maturity date of September 25, 2018. The Credit Agreement permitted the Company to request one or more increases in the aggregate commitments provided that such increases do not exceed $25.0 million in the aggregate. The Company expected to use the proceeds from any revolving loans under the credit facility for general corporate purposes, including future acquisitions. The Company's obligations under the Credit Agreement were guaranteed by certain of its domestic subsidiaries and secured by substantially all of the Company's and the subsidiary guarantors’ assets. The Company had not drawn any funds under the credit facility as of December 31, 2015. On January 5, 2016, this Credit Agreement was replaced by the credit facilities discussed above.


## us-gaap:DebtPolicyTextBlock

[0000926326-17-000015:notes:128]
Debt. The Company has entered into a Credit Agreement which provides for (a) a five-year revolving credit facility and (b) a five-year term loan facility (Facilities). The amount borrowed under these facilities is recorded at its carrying value at December 31, 2016. The fair value at December 31, 2016 approximates the carrying value.


## us-gaap:DeferredRevenueDisclosureTextBlock

[0000926326-17-000015:notes:129]
Deferred Revenue

[0000926326-17-000015:notes:130]
Short-term deferred revenue includes deferred revenue from product sales and service contracts, net of deferred cost of sales of $14.2 million and $15.7 million as of December 31, 2016 and December 31, 2015, respectively. The short-term deferred revenues from product sales relate to the delivered and invoiced products, pending installation and acceptance, expected to occur within the next twelve months.

[0000926326-17-000015:notes:131]
Long-term deferred revenue includes deferred revenue from the service contracts of $17.1 million and $18.0 million, as of December 31, 2016 and December 31, 2015, respectively.


## us-gaap:DerivativesPolicyTextBlock

[0000926326-17-000015:notes:132]
Foreign currency forward contracts. The Company enters into foreign currency forward contracts to protect its business from the risk that exchange rates may affect the eventual cash flows resulting from intercompany transactions between Omnicell and its foreign subsidiaries. These transactions primarily arise as a result of products manufactured in the United States ("U.S") and sold to foreign subsidiaries in U.S. dollars rather than the subsidiaries' functional currencies. These forward contracts are considered to be financial derivative instruments and are recorded at fair value. Changes in fair values of these financial derivative instruments are either recognized in other comprehensive income or net income depending on whether the derivative has been designated and qualifies as a hedging instrument.

[0000926326-17-000015:notes:133]
Interest rate swap agreements. During the second quarter of 2016, the Company entered into interest rate swap agreements. The interest rate swap agreements, at their inception, qualified for and were designated as cash flow hedging instruments. In accordance with the Derivatives and Hedging Topic of the Accounting Standards Codification ("ASC"), the Company records its interest rate swaps on its consolidated balance sheet at fair value. The effective portion of changes in fair value are recorded in accumulated other comprehensive loss and are subsequently reclassified into earnings in the period that the hedged forecasted transaction affects earnings. Any ineffective portion is recognized in earnings. Both at inception and on a quarterly basis, the Company performs an effectiveness test. For further information regarding these interest rate swap agreements, please refer to Note 4, "Cash and Cash Equivalents and Fair Value of Financial Instruments".


## us-gaap:EarningsPerShareTextBlock

[0000926326-17-000015:notes:134]
Net Income Per Share

[0000926326-17-000015:notes:135]
Basic net income per share is computed by dividing net income for the period by the weighted-average number of shares outstanding during the period. Diluted net income per share is computed by dividing net income for the period by the weighted-average number of shares, less shares repurchased, plus, if dilutive, potential common stock outstanding during the period. Potential common stock includes the effect of outstanding dilutive stock options, restricted stock awards and restricted stock units computed using the treasury stock method. The anti-dilutive weighted-average dilutive shares related to stock award plans are excluded from the computation of the diluted net income per share.

[0000926326-17-000015:notes:136]
The calculation of basic and diluted net income per share is as follows:

[0000926326-17-000015:notes:137]
|  | Year Ended |
|  | December 31, 2016 |  | December 31, 2015 |  | December 31, 2014 |
|  | (In thousands, except per share data) |
| Net income | $ | 603 |  |  | $ | 30,760 |  |  | $ | 30,518 |  |
| Weighted-average shares outstanding — basic | 36,156 |  |  | 35,857 |  |  | 35,650 |  |
| Add: Dilutive effect of employee stock plans | 708 |  |  | 861 |  |  | 972 |  |
| Weighted-average shares outstanding — diluted | 36,864 |  |  | 36,718 |  |  | 36,622 |  |
| Net income per share — basic | $ | 0.02 |  |  | $ | 0.86 |  |  | $ | 0.86 |  |
| Net income per share — diluted | $ | 0.02 |  |  | $ | 0.84 |  |  | $ | 0.83 |  |
| Anti-dilutive weighted-average shares related to stock award plans | 1,345 |  |  | 555 |  |  | 640 |  |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0000926326-17-000015:notes:138]
The following table represents the fair value hierarchy of the Company’s financial assets measured at fair value as of December 31, 2016:

[0000926326-17-000015:notes:139]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Interest rate swap contracts | $ | — |  |  | $ | 1,245 |  |  | $ | — |  |  | $ | 1,245 |  |
| Total financial assets | $ | — |  |  | $ | 1,245 |  |  | $ | — |  |  | $ | 1,245 |  |
| Contingent consideration liability | $ | — |  |  | $ | — |  |  | $ | 2,400 |  |  | $ | 2,400 |  |
| Total financial liabilities | $ | — |  |  | $ | — |  |  | $ | 2,400 |  |  | $ | 2,400 |  |

[0000926326-17-000015:notes:140]
The following table represents the fair value hierarchy of the Company’s financial assets measured at fair value as of December 31, 2015:

[0000926326-17-000015:notes:141]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Money market funds | $ | 10,114 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,114 |  |
| Forward contracts | — |  |  | 32 |  |  | — |  |  | 32 |  |
| Total financial assets | $ | 10,114 |  |  | $ | 32 |  |  | $ | — |  |  | $ | 10,146 |  |
| Contingent consideration liability | $ | — |  |  | $ | — |  |  | $ | 5,823 |  |  | $ | 5,823 |  |
| Total financial Liabilities | $ | — |  |  | $ | — |  |  | $ | 5,823 |  |  | $ | 5,823 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0000926326-17-000015:notes:142]
Cash and cash equivalents at December 31, 2016 and December 31, 2015 were as follows:

[0000926326-17-000015:notes:143]
|  | December 31, 2016 |  | December 31, 2015 |
|  | (In thousands) |
| Cash | $ | 54,488 |  |  | $ | 72,103 |  |
| Cash equivalents | — |  |  | 10,114 |  |
| Total cash and cash equivalents | $ | 54,488 |  |  | $ | 82,217 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000926326-17-000015:notes:144]
Cash and Cash Equivalents and Fair Value of Financial Instruments

[0000926326-17-000015:notes:145]
Cash and cash equivalents include money market funds, which have original maturities of three months or less.  Due to the short duration to maturity, the carrying value of such financial instruments approximates the estimated fair value.

[0000926326-17-000015:notes:146]
Fair value hierarchy

[0000926326-17-000015:notes:147]
The Company measures its financial instruments at fair value. The Company’s cash equivalents are classified within Level 1 of the fair value hierarchy as they are valued primarily using quoted market prices utilizing market observable inputs. The Company's interest rate swap contracts and foreign currency contracts are classified within Level 2 as the valuation inputs are based on quoted prices and market observable data of similar instruments. The Company's contingent consideration liability related to the Avantec acquisition is classified as Level 3 as valuation inputs are unobservable in the market and significant to the instrument’s valuation. During the year ended December 31, 2016, the Company paid $3.0 million for contingent consideration and recorded $0.2 million for accrued interest. Additionally, the Company determined the final payout amount for the remaining contingent consideration and reduced the liability from $3.0 million to $2.4 million.  The reduction of the contingent liability resulted in a gain of $0.6 million which is disclosed within "Interest and other income (expense), net" capture of the Statement of Operations for the year ended December 31, 2016.

[0000926326-17-000015:notes:148]
The significant unobservable inputs used in the fair value measurement of the contingent consideration classified as level 3 above are the achievement of booking targets and the discount rate. There have been no transfers between fair value measurement levels during the year ended December 31, 2016 and December 31, 2015.

[0000926326-17-000015:notes:149]
Foreign Currency Risk Management

[0000926326-17-000015:notes:150]
The Company operates in foreign countries, which expose it to market risk associated with foreign currency exchange rate fluctuations between the U.S. dollar and various foreign currencies, the most significant of which is the British Pound and Euro. In order to manage foreign currency risk, at times the Company enters into foreign exchange forward contracts to mitigate risks associated with changes in spot exchange rates of mainly non-functional currency denominated assets or liabilities of our foreign subsidiaries.  In general, the market risk related to these contracts is offset by corresponding gains and losses on the hedged transactions. By working only with major banks and closely monitoring current market conditions, the Company seeks to limit the risk that counterparties to these contracts may be unable to perform. The foreign exchange forward contracts are measured at fair value and reported as other current assets or accrued liabilities on the Consolidated Balance Sheets. The derivative instruments the Company uses to hedge this exposure are not designated as hedges. Any gains or losses on the foreign exchange forward contracts are recognized in earnings as Other Income/Expense in the period incurred in the Consolidated Statements of Operations. The Company does not enter into derivative contracts for trading purposes.

[0000926326-17-000015:notes:151]
At December 31, 2016, the Company had no outstanding foreign exchange forward contracts. The aggregate notional value of these outstanding foreign exchange contracts as of December 31, 2015 was $0.4 million.

[0000926326-17-000015:notes:152]
Interest Rate Swap Contracts

[0000926326-17-000015:notes:153]
The Company uses interest rate swap agreements to protect the Company against adverse fluctuations in interest rates by reducing its exposure to variability in cash flows relating to interest payments on a portion of its outstanding debt. The Company's interest rate swaps, which are designated as cash flow hedges, involve the receipt of variable amounts from counterparties in exchange for the Company making fixed-rate payments over the life of the agreements. The Company does not hold or issue any derivative financial instruments for speculative trading purposes.

[0000926326-17-000015:notes:154]
During 2016, the Company entered into an interest rate swap agreement with a combined notional amount of $100.0 million with one counter-party that is effective beginning on June 30, 2016 and maturing on April 30, 2019. The swap agreement requires the Company to pay a fixed rate of 0.8% and provides that the Company will receive a variable rate based on the one month LIBOR rate subject to LIBOR floor of 0.0%. Amounts payable by or due to the Company will be net settled with the respective counter-party on the last business day of each month, commencing July 31, 2016.

[0000926326-17-000015:notes:155]
The fair value of the interest rate swap agreements at December 31, 2016 was $1.2 million. There were no amounts reclassified into current earnings due to ineffectiveness during the periods presented.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0000926326-17-000015:notes:156]
Foreign currency translation and remeasurement

[0000926326-17-000015:notes:157]
Most of the Company's foreign subsidiaries use the local currency of their respective countries as their functional currency. The Company translates the assets and liabilities of such non-U.S. dollar functional currency subsidiaries into U.S. dollars using exchange rates in effect at the end of each period. Revenue and expenses for these subsidiaries are translated using rates that approximate those in effect during the period. Gains and losses from these translations are recorded as foreign currency translation adjustments and included in accumulated other comprehensive income in stockholders’ equity.

[0000926326-17-000015:notes:158]
The Company’s foreign subsidiaries that use the U.S. dollar as their functional currency remeasure monetary assets and liabilities at exchange rates in effect at the end of each period, and inventories, property and non-monetary assets and liabilities at historical rates. Gains and losses from such foreign currency remeasurement is recorded in interest and other income (expense).


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000926326-17-000015:notes:159]
Goodwill and Intangible Assets

[0000926326-17-000015:notes:160]
Goodwill

[0000926326-17-000015:notes:161]
The changes in the carrying amount of goodwill are as follows:

[0000926326-17-000015:notes:162]
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |
|  | (In thousands) |
| Net balance as of December 31, 2014 | $ | 28,543 |  |  | $ | 94,177 |  |  | $ | 122,720 |  |
| Additions (1) | 26,197 |  |  | — |  |  | 26,197 |  |
| Adjustments (2) | (424 | ) |  | (587 | ) |  | (1,011 | ) |
| Net balance as of December 31, 2015 | 54,316 |  |  | 93,590 |  |  | 147,906 |  |
| Additions (3) | 163,599 |  |  | 20,832 |  |  | 184,431 |  |
| Adjustments (2) | (2,833 | ) |  | (1,780 | ) |  | (4,613 | ) |
| Net balance as of December 31, 2016 | $ | 215,082 |  |  | $ | 112,642 |  |  | $ | 327,724 |  |

[0000926326-17-000015:notes:163]
_________________________________________________

[0000926326-17-000015:notes:164]
(1) Additions to goodwill as a result of the Mach4 and Avantec acquisitions in April 2015, including a $0.1 million adjustment to the purchase price in the fourth quarter of 2015 for Mach4.

[0000926326-17-000015:notes:165]
(2)  Adjustments reflect foreign currency exchange rate fluctuations.

[0000926326-17-000015:notes:166]
(3) Additions to goodwill as a result of the Aesynt acquisition in January 2016 and Ateb acquisition in December 2016.

[0000926326-17-000015:notes:167]
Intangible assets, net

[0000926326-17-000015:notes:168]
The carrying amounts of intangibles as of December 31, 2016 were as follows:

[0000926326-17-000015:notes:169]
|  | December 31, 2016 |
|  | Grosscarryingamount |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 133,358 |  |  | $ | (20,930 | ) |  | $ | (596 | ) |  | $ | 111,832 |  |  | 1 - 30 |
| Acquired technology | 73,599 |  |  | (13,287 | ) |  | (159 | ) |  | 60,153 |  |  | 3 - 20 |
| Backlog | 20,550 |  |  | (14,083 | ) |  | — |  |  | 6,467 |  |  | 1 - 3 |
| Trade names | 8,667 |  |  | (3,887 | ) |  | (31 | ) |  | 4,749 |  |  | 1 - 12 |
| Patents | 3,154 |  |  | (1,264 | ) |  | — |  |  | 1,890 |  |  | 2 - 20 |
| Non-compete agreements | 1,900 |  |  | (608 | ) |  | — |  |  | 1,292 |  |  | 3 |
| In process technology | 3,900 |  |  | — |  |  | — |  |  | 3,900 |  |  | - |
| Total intangibles assets, net | $ | 245,128 |  |  | $ | (54,059 | ) |  | $ | (786 | ) |  | $ | 190,283 |  |  |  |

[0000926326-17-000015:notes:170]
The carrying amounts of intangibles as of December 31, 2015 were as follows:

[0000926326-17-000015:notes:171]
|  | December 31, 2015 |
|  | Gross carryingamount |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 69,554 |  |  | $ | (11,315 | ) |  | $ | (719 | ) |  | $ | 57,520 |  |  | 5 - 30 |
| Acquired technology | 30,870 |  |  | (6,088 | ) |  | 59 |  |  | 24,841 |  |  | 3 - 20 |
| Backlog | 415 |  |  | (163 | ) |  | (11 | ) |  | 241 |  |  | 2 |
| Trade names | 8,052 |  |  | (2,551 | ) |  | (14 | ) |  | 5,487 |  |  | 1 - 12 |
| Patents | 1,960 |  |  | (384 | ) |  | — |  |  | 1,576 |  |  | 2 - 20 |
| Total intangibles assets, net | $ | 110,851 |  |  | $ | (20,501 | ) |  | $ | (685 | ) |  | $ | 89,665 |  |  |  |

[0000926326-17-000015:notes:172]
Amortization expense of intangible assets was $36.1 million, $6.9 million and $4.6 million for the years ended December 31, 2016, December 31, 2015 and December 31, 2014, respectively.

[0000926326-17-000015:notes:173]
The estimated future amortization expenses for intangible assets are as follows:

[0000926326-17-000015:notes:174]
| For the year ended December 31, | (In thousands) |
| 2017 | $ | 25,173 |  |
| 2018 | 22,840 |  |
| 2019 | 17,402 |  |
| 2020 | 16,255 |  |
| 2021 | 14,854 |  |
| Thereafter (including IPR&D) | 93,759 |  |
| Total | $ | 190,283 |  |


## us-gaap:GoodwillAndIntangibleAssetsPolicyTextBlock

[0000926326-17-000015:notes:175]
Goodwill and intangible assets

[0000926326-17-000015:notes:176]
Goodwill. The Company reviews goodwill for impairment on an annual basis on the first day of the fourth quarter of each year at the reporting unit level. The Company's reporting units are the same as its operating segments, which are Automation and Analytics and Medication Adherence. A qualitative assessment is initially made to determine whether it is necessary to perform quantitative testing. This initial assessment includes, among others, consideration of: (i) past, current and projected future earnings and equity; (ii) recent trends and market conditions; and (iii) valuation metrics involving similar companies that are publicly-traded and acquisitions of similar companies, if available. If this initial qualitative assessment indicates that it is more likely than not that impairment exists, or if the Company decides to bypass this option, it proceeds to a two-step impairment test. The first step ("Step 1") involves a comparison between the estimated fair values of the Company's reporting units with their respective carrying amounts including goodwill. The methods for estimating reporting unit values include asset and liability fair values and other valuation techniques, such as discounted cash flows and multiples of earnings or revenues. If the carrying value exceeds estimated fair value, there is an indication of potential impairment, and the second step is performed to measure the amount of impairment. The second step involves calculating an implied fair value of goodwill by measuring the excess of the estimated fair value of the reporting units over the aggregate estimated fair values of the individual assets less liabilities. If the carrying value of goodwill exceeds the implied fair value of goodwill, an impairment charge is recorded for the excess.

[0000926326-17-000015:notes:177]
To determine each reporting unit's fair value in the second step, the Company uses the income approach which is based on the estimated discounted future cash flows of that reporting unit. The estimated fair value of each reporting unit under the income approach is corroborated with the market approach, which measures the value of a business through an analysis of recent sales or offerings of a comparable entity. The Company also considers its market capitalization on the date of the analysis to ensure the reasonableness of the sum of its reporting units’ estimated fair value.

[0000926326-17-000015:notes:178]
The Company performed a Step 1 impairment analysis as of October 1, 2016 for its Medication Adherence reporting unit. The Company determined that the fair value of this reporting unit exceeded the carrying value by more than 25%, and thus no impairment was indicated.  Additionally, the Company performed a Step 0 impairment assessment analysis as of October 1, 2016 for its Automation and Analytics reporting unit taking into consideration past, current and projected future earnings, recent trends and market conditions; and valuation metrics involving similar companies that are publicly-traded.  Based on the result of this analysis it is more likely than not an impairment does not exist.

[0000926326-17-000015:notes:179]
Intangible assets. In connection with the Company's acquisitions, it generally recognizes assets for customer relationships, technology and trade names. Intangible assets are carried at cost less accumulated amortization. Such amortization is provided on a straight-line basis or on an accelerated basis based on a pattern of economic benefit that is expected to be obtained over the estimated useful lives of the respective assets, generally from 1 to 30 years. Amortization for developed technology and backlog is recognized in cost of product revenues, and amortization for customer relationships, non-compete agreements, and trade names is recognized in selling, general and administrative expenses.

[0000926326-17-000015:notes:180]
The Company assesses the impairment of identifiable intangible assets whenever events or changes in circumstances indicate that an asset's carrying amount may not be recoverable. Recoverability of an asset is measured by the comparison of the carrying amount to the sum of the undiscounted estimated future cash flows the asset is expected to generate, offset by estimated future costs to dispose of the product to which the asset relates. If an asset is considered to be impaired, the amount of such impairment would be measured as the difference between the carrying amount of the asset and its fair value. The Company's cash flow assumptions are based on historical and forecasted future revenue, operating costs, and other relevant factors. Assumptions and estimates about the remaining useful lives of the Company's intangible assets are subjective and are affected by changes to its business strategies. If management’s estimates of future operating results change, or if there are changes to other assumptions, the estimate of the fair value of the Company's assets could change significantly. Such change could result in impairment charges in future periods, which could have a significant impact on the Company's operating results and financial condition.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000926326-17-000015:notes:181]
Income Taxes

[0000926326-17-000015:notes:182]
The following is a geographical breakdown of income before the provision for (benefit from) income taxes:

[0000926326-17-000015:notes:183]
|  | Year Ended |
|  | December 31, 2016 |  | December 31, 2015 |  | December 31, 2014 |
|  | (In thousands) |
| Domestic | $ | 1,471 |  |  | $ | 51,089 |  |  | $ | 48,327 |  |
| Foreign | (3,419 | ) |  | (4,845 | ) |  | 177 |  |
| Income before provision for (benefit from) income taxes | $ | (1,948 | ) |  | $ | 46,244 |  |  | $ | 48,504 |  |

[0000926326-17-000015:notes:184]
The provision for (benefit from) income taxes consists of the following:

[0000926326-17-000015:notes:185]
|  | Year Ended |
|  | December 31, 2016 |  | December 31, 2015 |  | December 31, 2014 |
|  | (In thousands) |
| Current: |  |  |  |  |  |
| Federal | $ | 6,724 |  |  | $ | 13,840 |  |  | $ | 14,063 |  |
| State | 1,323 |  |  | 2,475 |  |  | 2,274 |  |
| Foreign | 46 |  |  | 203 |  |  | 192 |  |
| Total current income taxes | 8,093 |  |  | 16,518 |  |  | 16,529 |  |
| Deferred: |  |  |  |  |  |
| Federal | (3,378 | ) |  | 846 |  |  | 1,603 |  |
| State | (1,802 | ) |  | (379 | ) |  | 84 |  |
| Foreign | (5,464 | ) |  | (1,501 | ) |  | (230 | ) |
| Total deferred income taxes | (10,644 | ) |  | (1,034 | ) |  | 1,457 |  |
| Total provision for (benefit from) income taxes | $ | (2,551 | ) |  | $ | 15,484 |  |  | $ | 17,986 |  |

[0000926326-17-000015:notes:186]
The provision for (benefit from) income taxes differs from the amount computed by applying the statutory federal tax rate as follows:

[0000926326-17-000015:notes:187]
|  | Year Ended |
|  | December 31, 2016 |  | December 31, 2015 |  | December 31, 2014 |
|  | (In thousands) |
| U.S. federal tax provision at statutory rate | $ | (682 | ) |  | $ | 16,181 |  |  | $ | 16,998 |  |
| State taxes | (311 | ) |  | 1,365 |  |  | 1,533 |  |
| Non-deductible expenses | 1,212 |  |  | 551 |  |  | 809 |  |
| Acquisition costs | 845 |  |  | 239 |  |  | 229 |  |
| Share-based compensation expense | 1,941 |  |  | 748 |  |  | 461 |  |
| Research tax credits | (2,075 | ) |  | (1,324 | ) |  | (818 | ) |
| Domestic production deduction | (890 | ) |  | (1,133 | ) |  | (1,127 | ) |
| Gain on investment | — |  |  | (1,205 | ) |  | — |  |
| Tax audit settlement | (2,499 | ) |  | — |  |  | — |  |
| Other | (92 | ) |  | 62 |  |  | (99 | ) |
| Total provision for (benefit from) income taxes | $ | (2,551 | ) |  | $ | 15,484 |  |  | $ | 17,986 |  |

[0000926326-17-000015:notes:188]
Significant components of the Company's deferred tax assets (liabilities) are as follows:

[0000926326-17-000015:notes:189]
|  | December 31, 2016 |  | December 31, 2015 |
|  | (In thousands) |
| Deferred tax assets (liabilities): |  |  |  |
| Deferred revenue | $ | 5,857 |  |  | $ | 14,020 |  |
| Stock compensation | 6,451 |  |  | 6,034 |  |
| Inventory related items | 2,915 |  |  | 2,541 |  |
| Tax credit carry forwards | 4,871 |  |  | 2,579 |  |
| Reserves and accruals | 929 |  |  | — |  |
| Loss carry forwards | 8,077 |  |  | 667 |  |
| Other, net | 847 |  |  | 697 |  |
| Total net deferred tax assets | 29,947 |  |  | 26,538 |  |
| Intangibles | (57,427 | ) |  | (28,213 | ) |
| Depreciation and amortization | (20,071 | ) |  | (17,185 | ) |
| Reserves and accruals | — |  |  | (601 | ) |
| Other, net | — |  |  | — |  |
| Total deferred tax liabilities | (77,498 | ) |  | (45,999 | ) |
| Net deferred tax liabilities | $ | (47,551 | ) |  | $ | (19,461 | ) |

[0000926326-17-000015:notes:190]
Deferred income tax assets (liabilities) are provided for temporary differences that will result in future tax deductions or future taxable income, as well as the future benefit of tax credit carry forwards. The Company recognizes deferred tax assets to the extent that it believes these assets are more likely than not to be realized. In making such a determination, the Company considers all available positive and negative evidence, including future reversals of existing temporary differences, projected future taxable income, tax planning strategies, and results of recent operations. On the basis of this evaluation, as of December 31, 2016, no valuation allowances have been recorded in any jurisdiction.

[0000926326-17-000015:notes:191]
As of December 31, 2016, the Company has an immaterial amount of state net operating loss carryforwards available for income tax purposes. For income tax purposes, the Company has federal and California research tax credits carryforwards of $1.7 million and $7.2 million, respectively. Federal research tax credit carry forwards from prior years will begin to expire in 2035. California credits are available indefinitely to reduce cash taxes otherwise payable. Pursuant to the requirements of ASC 718, the Company does not include unrealized stock option attributes as components of our gross deferred tax assets. The tax effected amount of gross unrealized net operating loss and business tax credit carry forwards excluded under ASC 718 for the year ended December 31, 2016 is $3.0 million.

[0000926326-17-000015:notes:192]
In general, it is the Company's practice and intention to reinvest the earnings of its non-U.S. subsidiaries in those operations.  As of December 31, 2016, the Company has not made a provision for U.S. federal income and state income taxes on accumulated and current earnings of $2.5 million related to certain foreign subsidiaries because these earnings are intended to be indefinitely reinvested in operations outside the U.S. If the Company expects to distribute those earnings in the form of dividends or otherwise, the Company would be subject to U.S. and state income taxes reported as a component of income tax expense, in the amount of $1.0 million. This amount may be reduced by any foreign tax credits available at the time of repatriation.

[0000926326-17-000015:notes:193]
The Company files income tax returns in the United States and various states and foreign jurisdictions. In the normal course of business, the Company is subject to examination by taxing authorities, including major jurisdictions as the United States, California, the United Kingdom and Germany. In 2012, the Company concluded audits by the IRS and the California Franchise Tax Board for years 2008 and 2009. However, all of the net operating loss and research credit carryforwards that may be used in future years are subject to adjustment, if and when utilized. As such the Company's U.S. federal and California tax years remain open from 1996 and 1992, respectively. During fiscal 2016, the IRS and the Company settled all outstanding items related to the audit of the Company's federal income tax returns for the fiscal years ended December 31, 2014.

[0000926326-17-000015:notes:194]
The aggregate change in the balance of gross unrecognized tax benefits, which excludes interest and penalties, for the three years ended December 31, 2016 is as follows:

[0000926326-17-000015:notes:195]
|  | (In thousands) |
| Year Ended December 31, 2013 | 7,974 |  |
| Increases related to tax positions taken during a prior period | 63 |  |
| Decreases related to tax positions taken during the prior period | (89 | ) |
| Increases related to tax positions taken during the current period | 801 |  |
| Decreases related to settlements | — |  |
| Decreases related to expiration of statute of limitations | (264 | ) |
| Year Ended December 31, 2014 | 8,485 |  |
| Increases related to tax positions taken during a prior period | 37 |  |
| Decreases related to tax positions taken during the prior period | (895 | ) |
| Increases related to tax positions taken during the current period | 1,807 |  |
| Decreases related to settlements | — |  |
| Decreases related to expiration of statute of limitations | (284 | ) |
| Year Ended December 31, 2015 | 9,150 |  |
| Increases related to tax positions taken during a prior period | 244 |  |
| Decreases related to tax positions taken during the prior period | (1,980 | ) |
| Increases related to tax positions taken during the current period | 6,724 |  |
| Decreases related to settlements | (2,178 | ) |
| Decreases related to expiration of statute of limitations | (344 | ) |
| Year Ended December 31, 2016 | $ | 11,616 |  |

[0000926326-17-000015:notes:196]
As of December 31, 2016 the total amount of gross unrecognized tax benefits, if realized, would decrease the Company's tax expense by approximately $7.6 million. The Company recognizes interest and/or penalties related to uncertain tax positions in operating expenses, which for 2016 was immaterial. The Company does not believe there will be any material changes in its unrecognized tax positions over the next twelve months.


## us-gaap:IncomeTaxPolicyTextBlock

[0000926326-17-000015:notes:197]
Accounting for income taxes

[0000926326-17-000015:notes:198]
The Company records an income tax provision (benefit) for the anticipated tax consequences of the reported results of operations. In accordance with U.S. GAAP, the provision for (benefit from income taxes is computed using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been included in the financial statements. Under this method, deferred tax assets and liabilities are determined on the basis of the differences between the financial statement and tax bases of assets and liabilities and for operating losses and tax credit carry forwards. Deferred tax assets and liabilities are measured using the enacted tax rates in effect for the periods in which those tax assets and liabilities are expected to be realized or settled. In the event that these tax rates change, the Company will incur a benefit or detriment on its income tax expense in the period of change. If the Company were to determine that all or part of the net deferred tax assets are not realizable in the future, it will record a valuation allowance that would be charged to earnings in the period such determination is made.

[0000926326-17-000015:notes:199]
In accordance with ASC 740, Income Taxes, the Company recognizes the tax benefit from an uncertain tax position if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement. The calculation of tax liabilities involves significant judgment in estimating the impact of uncertainties in the application of U.S. GAAP and complex tax laws. Resolution of these uncertainties in a manner inconsistent with management’s expectations could have a material impact on our financial condition and operating results.


## us-gaap:InventoryPolicyTextBlock

[0000926326-17-000015:notes:200]
Inventory

[0000926326-17-000015:notes:201]
Inventories for 2016 are stated at the lower of cost (utilizing standard costs, applying the first-in, first-out method) or net realizable value, defined as the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal and transportation. Cost elements included in inventory are direct labor and materials plus applied overhead. The Company routinely assesses on-hand inventory for timely identification and measurement of obsolete, slow-moving or otherwise impaired inventory. The Company writes down its inventory for estimated obsolescence, excess or unmarketable quantities equal to the difference between the cost of the inventory and its estimated market value based on assumptions about future demand and market conditions. If actual future demand or market conditions are less favorable than the Company projected, additional inventory write-downs may be required.


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0000926326-17-000015:notes:202]
Property and equipment, net

[0000926326-17-000015:notes:203]
|  | December 31, 2016 |  | December 31, 2015 |  | December 31, 2014 |
|  | (In thousands) |
| United States | $ | 36,497 |  |  | $ | 29,506 |  |  | $ | 35,335 |  |
| Rest of world (1) | 5,514 |  |  | 2,803 |  |  | 843 |  |
| Total property and equipment, net | $ | 42,011 |  |  | $ | 32,309 |  |  | $ | 36,178 |  |

[0000926326-17-000015:notes:204]
(1)    No individual country represented more than 10% of the respective totals.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000926326-17-000015:notes:205]
Recently adopted accounting standards

[0000926326-17-000015:notes:206]
In April 2015, the Financial Accounting Standards Board ("FASB") issued ASU No. 2015-03, Interest — Imputation of Interest (Subtopic 835-30) — Simplifying the Presentation of Debt Issuance Costs, that requires debt issuance costs related to a recognized debt liability to be presented in the balance sheet as a direct deduction from the debt liability. The guidance is effective for fiscal years beginning after December 15, 2015, and interim periods within those years, with retrospective application required along with certain disclosures about the change in accounting principle, including the effect of the change on the financial statement line items. As required under ASU 2015-03 the Company has presented the deferred issuance cost related to the debt facilities of $7.9 million as a reduction of the debt liability.  Refer to Note 8, Debt and Credit Agreement, for additional information.

[0000926326-17-000015:notes:207]
In April 2015, the FASB issued ASU No. 2015-05, Intangibles-Goodwill and Other-Internal-Use Software - Customer’s Accounting for Fees Paid in a Cloud Computing Arrangement, which provides guidance on determining whether a cloud computing arrangement contains a software license. If a cloud computing arrangement includes a software license, then the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If a cloud computing arrangement does not include a software license, the customer should account for the arrangement as a service contract. The Company adopted ASU 2015-05 on a prospective basis beginning on January 1, 2016. The impact of ASU 2015-05 did not have a material impact on the Company's consolidated financial position or results of operations for the year ended December 31, 2016.

[0000926326-17-000015:notes:208]
In July 2015, the FASB issued ASU No. 2015-11, Simplifying the Measurement of Inventory. This ASU changes the measurement principle for inventory from the lower of cost or market to lower of cost and net realizable value. Net realizable value is the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal and transportation. It applies to entities that measure inventory using a method other than last-in, first-out (LIFO) and the retail inventory method (RIM). The guidance is effective for fiscal years beginning after December 15, 2016. The Company adopted ASU 2015-11 on a prospective basis beginning on January 1, 2016. The impact of ASU 2015-11 did not have a material impact on the Company's consolidated financial position or results of operations for the year ended December 31, 2016.

[0000926326-17-000015:notes:209]
In September 2015, the FASB issued ASU No. 2015-16, Business Combinations (Topic 805): Simplifying the Accounting for Measurement-Period Adjustments. This ASU requires adjustments to provisional amounts that are identified during the measurement period of a business combination to be recognized in the reporting period in which the adjustment amounts are determined. An acquirer is no longer required to revise comparative information for prior periods as if the accounting for the business combination had been completed as of the acquisition date. The provisions of ASU 2015-16 are effective for reporting periods beginning after December 15, 2015. The adoption of this accounting standard update did not have a material impact on the Company's consolidated financial position or results of operations for the year ended December 31, 2016.

[0000926326-17-000015:notes:210]
Recently issued authoritative guidance

[0000926326-17-000015:notes:211]
In May 2014, the FASB issued ASU No. 2014-09, Revenue from Contracts with Customers ("ASU 2014-09"). Under the new guidance, an entity is required to recognize an amount of revenue to which it expects to be entitled for the transfer of promised goods or services to customers. The original effective date for the ASU would have required the Company to adopt the standard beginning in its first quarter of fiscal year 2017. In July 2015, the FASB voted to amend ASU 2014-09 by approving a one-year deferral of the effective date as well as providing the option to early adopt the standard on the original effective date.

[0000926326-17-000015:notes:212]
Additionally, during 2016 the FASB issued several final ASUs to provide clarifications for the new revenue standard. These final ASU's were issued in March 2016, ASU No. 2016-08, Principal versus Agent Considerations (Reporting Revenue Gross versus Net), in April 2016, ASU No. 2016-10, Identifying Performance Obligations and Licensing, in May 2016, ASU No. 2016-12, Narrow-Scope Improvements and Practical Expedients and in December 2016, ASU No. 2016-20, Technical Corrections and Improvements to Topic 606, Revenue from Contracts with Customers. All of these amendments have the same effective date as Topic 606, the new revenue standard. Accordingly, the Company will adopt the standard in its first quarter of fiscal year 2018. The Company is currently in the process of assessing the impact of adopting this new guidance.

[0000926326-17-000015:notes:213]
In February 2016, the FASB issued ASU No. 2016-02, Leases (Topic 842). The FASB amended lease accounting requirements to begin recording assets and liabilities arising from leases on the balance sheet. The new guidance will also require significant additional disclosures about the amount, timing and uncertainty of cash flows from leases. This new guidance will be effective for us beginning on January 1, 2019 using a modified retrospective approach. The modified retrospective approach includes a number of optional practical expedients that entities may elect to apply. The Company is currently evaluating the impact ASU 2016-02 will have on its consolidated financial statements.

[0000926326-17-000015:notes:214]
In March 2016, the FASB issued ASU No. 2016-09, Compensation—Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting. This ASU simplifies several aspects of the accounting for share-based payment transactions, including the income tax consequences, classification of awards as either equity or liabilities, and classification on the statement of cash flows. The provisions of ASU 2016-09 are effective for annual periods beginning after December 15, 2016, and interim periods within those annual periods. Early adoption is permitted for any entity in any interim or annual period. If an entity early adopts the amendments in an interim period, any adjustments are reflected as of the beginning of the fiscal year that includes that interim period. An entity that elects early adoption must adopt all of the amendments in the same period. The Company is currently in the process of evaluating the impact of the adoption of ASU 2016-09 on its consolidated financial statements.

[0000926326-17-000015:notes:215]
In June 2016, the FASB issued ASU No. 2016-13, Financial Instruments — Credit Losses (Topic 326), Measurement of Credit Losses on Financial Instruments, that modifies or replaces existing models for trade and other receivables, debt securities, loans and certain other financial instruments. For instruments measured at amortized cost, including trade and lease receivables, loans and held-to-maturity debt securities, the standard will replace today’s “incurred loss” approach with an “expected loss” model. Entities will be required to estimate expected credit losses over the life of the instrument, considering available relevant information about the collectibility of cash flows, including information about past events, current conditions, and reasonable and supportable forecasts. The new guidance will be effective for fiscal years beginning after December 15, 2019, including interim periods within those fiscal years and will be applied prospectively with a cumulative effect adjustment as of the beginning of the first reporting period for which the guidance is effective. Early adoption is permitted for annual periods beginning after December 15, 2018 and interim periods therein. The Company is currently evaluating the impact ASU 2016-13 will have on its consolidated financial statements.

[0000926326-17-000015:notes:216]
In October 2016, the FASB issued ASU No. 2016-16, Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory, which reduces the complexity in the accounting standards by allowing the recognition of current and deferred income taxes for an intra-entity asset transfer, other than inventory, when the transfer occurs. Historically, recognition of the income tax consequence was not recognized until the asset was sold to an outside party.  This amendment should be applied on a modified retrospective basis through a cumulative-effect adjustment directly to retained earnings as of the beginning of the period of adoption.  ASU 2016-16 is effective for annual periods beginning after December 15, 2017, including interim reporting periods within those annual reporting periods.  Early adoption is permitted for all entities as of the beginning of an annual reporting period for which financial statements (interim or annual) have not been issued or made available for issuance. The Company is currently evaluating the impact ASU 2016-16 will have on its consolidated financial statements.

[0000926326-17-000015:notes:217]
In January 2017, the FASB issued ASU No. 2017-01, Business Combinations (Topic 805): Clarifying the Definition of a Business, which reduces the population of transactions that will be identified as businesses vs. assets for purposes of acquisition and disposal accounting. The standard provides an initial screen which excludes from the business definition any transaction where substantially all of the fair value is concentrated in a single (or group of similar) identifiable assets. Transactions which pass the initial screen must still contain inputs and a substantive process to meet the new business definition. ASU 2017-01 is effective for fiscal years beginning after December 15, 2017, and interim periods within those years, with prospective application. Early adoption is permitted. The Company is currently evaluating the impact ASU 2017-01 will have on its consolidated financial statements.

[0000926326-17-000015:notes:218]
In January 2017, the FASB issued  ASU No. 2017-04, Intangibles — Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment,  that eliminates the requirement to calculate the implied fair value of goodwill (Step 2 of today’s goodwill impairment test) to measure a goodwill impairment charge. Instead, entities will record an impairment charge based on the excess of a reporting unit’s carrying amount over its fair value (measure the charge based on today’s Step 1). There is no change to the optional Step 0 for qualitative assessment of impairment.  ASU 2017-04 is effective for annual and interim impairment tests performed in periods beginning after December 15, 2019. Early adoption is permitted for annual and interim impairment dates after January 1, 2017. The Company is currently evaluating the impact ASU 2017-04 will have on its consolidated financial statements.

[0000926326-17-000015:notes:219]
In February 2017, the FASB issued ASU No. 2017-05, Other Income-Gains and Losses from the Derecognition of Nonfinancial Assets (Subtopic 610-20): Clarifying the Scope of Asset Derecognition Guidance and Accounting for Partial Sales of Nonfinancial Assets. This ASU clarifies the scope and application of ASC 610-20 on the sale or transfer of nonfinancial assets and in substance nonfinancial assets to noncustomers, including partial sales. The effective date of the ASU 2017-05 amendments to the nonfinancial asset guidance must coincide with the adoption of the ASU 2014-09 revenue standard (expected in the first quarter of fiscal year 2018), but the transition method does not have to be the same. Transition can use either the full retrospective approach or the modified retrospective approach. The Company is currently evaluating the impact ASU 2017-05 will have on its consolidated financial statements.

[0000926326-17-000015:notes:220]
There was no other recently issued and effective authoritative guidance that is expected to have a material impact on the Company's Consolidated Financial Statements through the reporting date.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000926326-17-000015:notes:221]
Organization and Summary of Significant Accounting Policies

[0000926326-17-000015:notes:222]
Business

[0000926326-17-000015:notes:223]
Omnicell, Inc. was incorporated in California in 1992 under the name Omnicell Technologies, Inc. and reincorporated in Delaware in 2001 as Omnicell, Inc. The Company's major products are automated medication, supply control systems and medication adherence solutions which are sold in its principal market, which is the healthcare industry. The Company's market is primarily located in the United States, Canada and United Kingdom. "Omnicell" or the "Company" refer to Omnicell, Inc. and its subsidiaries.

[0000926326-17-000015:notes:224]
On January 5, 2016, the Company completed its acquisition of Aesynt Holding Cooperatief U.A. (“Aesynt”).  On December 8, 2016, the Company completed its acquisition of Ateb, Inc. and Ateb Canada Ltd. (together, “Ateb”). On April 21, 2015, the Company completed its acquisition of Mach4 Automatisierungstechnik GmbH (“Mach4”). On April 30, 2015, the Company acquired the remaining 85% of the issued and outstanding ordinary shares of Avantec Healthcare Limited (“Avantec”) not already held by Omnicell. The consolidated financial statements include the results of operations of these recently acquired companies, commencing as of their respective acquisition dates.  The significant accounting policies of the acquired businesses have been aligned to conform to the accounting policies of Omnicell.

[0000926326-17-000015:notes:225]
Certain prior year amounts have been reclassified to conform to 2016 presentation. These reclassifications include; (i) provision for excess and obsolete inventories and provision for receivables allowance have been reclassified/combined with inventories and accounts receivable within net cash provided by operating activities in the Consolidated Statements of Cash Flows, and (ii) the deferred service revenue and deferred gross profit have been combined under deferred revenue, net.

[0000926326-17-000015:notes:226]
Use of estimates

[0000926326-17-000015:notes:227]
The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company's Consolidated Financial Statements and accompanying Notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management's best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. The Company's critical accounting policies are those that affect its financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition, accounts receivable and notes receivable from investment in sales-type leases, inventory valuation, capitalized software development costs, valuation and impairment of goodwill, purchased intangibles and long-lived assets, share-based compensation and accounting for income taxes.

[0000926326-17-000015:notes:228]
Segment reporting

[0000926326-17-000015:notes:229]
The Company's Chief Operating Decision Maker ("CODM") is its Chief Executive Officer. The CODM allocates resources and evaluates the performance of the Company's segments using information about its revenues, gross profit, and income from operations. Such evaluation excludes general corporate-level costs that are not specific to either of the reportable segments and are managed separately at the corporate level. Corporate-level costs include expenses related to executive management, finance and accounting, human resources, legal, training and development, and certain administrative expenses.  See Note 13, Segment and Geographical Information, for addition information on segment reporting.

[0000926326-17-000015:notes:230]
The operating results of the recently acquired Aesynt, Mach4 and Avantec businesses are included in the Company's Automation and Analytics reportable segment. The operating results of the recently acquired Ateb business is included in the Medication Adherence reportable segment.

[0000926326-17-000015:notes:231]
Revenue recognition

[0000926326-17-000015:notes:232]
The Company earns revenues from sales of our medication and medical and surgical supply automation systems along with consumables and related services, which are sold in the healthcare industry, our principal market. Revenues are reported net of discounts and rebates provided to its customers. The Company's customer arrangements typically include one or more of the following deliverables:

[0000926326-17-000015:notes:233]
Products. Software-enabled equipment that manages and regulates the storage and dispensing of pharmaceuticals, consumable blister cards and packaging equipment and other medical supplies.

[0000926326-17-000015:notes:234]
Software. Additional software applications that enable incremental functionality of its equipment.

[0000926326-17-000015:notes:235]
Installation. Installation of equipment as integrated systems at customers' sites.

[0000926326-17-000015:notes:236]
Post-installation technical support. Phone support, on-site service, parts and access to unspecified software upgrades and enhancements, if and when available.

[0000926326-17-000015:notes:237]
Professional services. Other customer services, such as training and consulting.

[0000926326-17-000015:notes:238]
The Company recognizes revenue when the earnings process is complete, based upon its evaluation of whether the following four criteria have been met:

[0000926326-17-000015:notes:239]
Persuasive evidence of an arrangement exists. The Company uses signed customer contracts and signed customer purchase orders as evidence of an arrangement for leases and sales. For service engagements, the Company uses a signed services agreement and a statement of work to evidence an arrangement.

[0000926326-17-000015:notes:240]
Delivery has occurred. Equipment and embedded software product delivery is deemed to occur upon successful installation and receipt of a signed and dated customer confirmation of installation letter, providing evidence that the Company has delivered what a customer ordered. In instances of a customer self-installation, product delivery is deemed to have occurred upon receipt of a signed and dated customer confirmation letter. If a sale does not require installation, the Company recognizes revenue on delivery of products to the customer, including transfer of title and risk of loss, assuming all other revenue criteria are met. For existing distributors, where installation of equipment training has been previously provided and the distributor is certified to install the Company's equipment at the end-user customer facility, the Company recognizes revenue from sales of products to the distributor upon shipment assuming all other revenue criteria are met, net of allowance for rights of return or refund. For new distributors, where the Company has not provided installation of equipment training, revenue on the sales of products to the distributor is deferred until the distributor has completed the Distributor Training Program and has been certified to install the Company's equipment at the end-user facility. For the sale of consumable blister cards, the Company recognizes revenue when title and risk of loss of the products shipped have transferred to the customer, which usually occurs upon shipment from the Company's facilities. Assuming all other revenue criteria are met, the Company recognizes revenue for support services ratably over the related support services contract period. The Company recognizes revenue on training and professional services as they are performed.

[0000926326-17-000015:notes:241]
Fee is fixed or determinable. The Company assesses whether a fee is fixed or determinable at the outset of the arrangement based on the payment terms associated with the transaction. The Company has established a history of collecting under the original contract without providing concessions on payments, products or services.

[0000926326-17-000015:notes:242]
Collection is probable. The Company assesses the probability of collecting from each customer at the outset of the arrangement based on a number of factors, including the customer's payment history and its current creditworthiness. If, in the Company's judgment, collection of a fee is not probable, the Company defers revenue recognition until the uncertainty is removed, which generally means revenue is recognized upon the Company's receipt of cash payment assuming all other revenue criteria are met. The Company's historical experience has been that collection from its customers is generally probable.

[0000926326-17-000015:notes:243]
In arrangements with multiple deliverables, assuming all other revenue criteria are met, the Company recognizes revenue for individual delivered items if they have value to the customer on a standalone basis. The Company allocates arrangement consideration at the inception of the arrangement to all deliverables using the relative selling price method. This method requires the Company to determine the selling price at which each deliverable could be sold if it were sold regularly on a standalone basis. When available, the Company uses vendor-specific objective evidence ("VSOE") of the selling price. VSOE represents the price charged for a deliverable when it is sold separately, or for a deliverable not yet being sold separately, the price established by management with the relevant authority. The Company considers VSOE to exist when approximately 80% or more of its standalone sales of an item are priced within a reasonably narrow pricing range (plus or minus 15% of the median rates). The Company has established VSOE of the selling price for its post-installation technical support services and professional services. When VSOE of selling price is not available, third-party evidence ("TPE") of selling price for similar products and services is acceptable; however, the Company's offerings and market strategy differ from those of its competitors, such that it cannot obtain sufficient comparable information about third parties' prices. If neither VSOE nor TPE are available, the Company uses its best estimates of selling prices ("BESP"). The Company determines BESP considering factors such as market conditions, sales channels, internal costs and product margin objectives and pricing practices. The Company regularly reviews and updates its VSOE and BESP information.

[0000926326-17-000015:notes:244]
The relative selling price method allocates total arrangement consideration proportionally to each deliverable on the basis of its estimated selling price. In addition, the amount recognized for any delivered items cannot exceed that which is not contingent upon delivery of any remaining items in the arrangement.

[0000926326-17-000015:notes:245]
The Company also uses the residual method to allocate revenue between the software products that enable incremental equipment functionality, and thus are not deemed to deliver its essential functionality, and the related post-installation technical support, as these products and services continue to be accounted for under software revenue recognition rules. Under the residual method, the amount allocated to the undelivered elements equals VSOE of fair value of these elements. Any remaining amounts are attributed to the delivered items and are recognized when those items are delivered.

[0000926326-17-000015:notes:246]
A portion of the Company's sales are made through multi-year lease agreements. Under sales-type leases, the Company recognizes revenue for its hardware and software products net of lease execution costs such as post-installation product maintenance and technical support, at the net present value of the lease payment stream once its installation obligations have been met. The Company optimizes cash flows by selling a majority of its non-U.S. government leases to third-party leasing finance companies on a non-recourse basis. The Company has no obligation to the leasing company once the lease has been sold. Some of the Company's sales-type leases, mostly those relating to U.S. government hospitals which comprise approximately 45% of the lease receivable balance, are retained in-house. Interest income in these leases is recognized in product revenue using the effective interest method.

[0000926326-17-000015:notes:247]
Financial Instruments

[0000926326-17-000015:notes:248]
For assets and liabilities measured at fair value, such amounts are based on an expected exit price representing the amount that would be received from the sale of an asset or paid to transfer a liability in a transaction between market participants. As such, fair value may be based on assumptions that market participants would use in pricing an asset or liability. The authoritative guidance on fair value measurements establishes a consistent framework for measuring fair value on either a recurring or nonrecurring basis whereby inputs used in valuation techniques are assigned a hierarchical level. The following methods were used to estimate the fair value of each class of financial instruments for which it is practical to estimate that value:

[0000926326-17-000015:notes:249]
Accounts receivable and notes receivable from investment in sales-type leases

[0000926326-17-000015:notes:250]
The Company actively manages its accounts receivable to minimize credit risk. The Company typically sells to customers for which there is a history of successful collection. New customers are subject to a credit review process, which evaluates that customer's financial position and ability to pay. The Company continually monitors and evaluates the collectability of its trade receivables based on a combination of factors. The Company records specific allowances for doubtful accounts when it becomes aware of a specific customer's impaired ability to meet its financial obligation to the Company, such as in the case of bankruptcy filings or deterioration of financial position. There were no significant customers that accounted for more than 10% of the Company's accounts receivable as of December 31, 2016 and December 31, 2015.

[0000926326-17-000015:notes:251]
Uncollectible amounts are charged off against trade receivables and the allowance for doubtful accounts when the Company makes a final determination that there is no reasonable expectation of recovery. Estimates are used in determining the Company's allowances for all other customers based on factors such as current trends, the length of time the receivables are past due and historical collection experience. While the Company believes that its allowance for doubtful accounts receivable is adequate and that the judgment applied is appropriate, such estimated amounts could differ materially from what will actually be uncollectible in the future.

[0000926326-17-000015:notes:252]
The retained in-house leases discussed above are considered financing receivables. The Company's credit policies and its evaluation of credit risk and write-off policies are applied alike to trade receivables and the net investment in sales-type leases. For both, an account is generally past due after thirty days. The financing receivables also have customer-specific reserves for accounts identified for specific impairment and a non-specific reserve applied to the remaining population, based on factors such as current trends, the length of time the receivables are past due and historical collection experience. The retained in-house leases are not stratified by portfolio or class.

[0000926326-17-000015:notes:253]
Sales of accounts receivable

[0000926326-17-000015:notes:254]
The Company records the sale of its accounts receivables as "true sales" in accordance with accounting guidance for transfers and servicing of financial assets. The Company transferred non-recourse accounts receivable totaling $28.7 million, $38.6 million and $62.0 million during fiscal year 2016, 2015, and 2014, respectively, which approximated fair value, to leasing companies on a non-recourse basis. Accounts receivable included approximately $0.2 million, $0.8 million and $1.1 million due from third-party leasing companies for transferred non-recourse accounts receivable as of December 31, 2016, December 31, 2015 and December 31, 2014, respectively.

[0000926326-17-000015:notes:255]
The Company has a supply agreement with one primary supplier for construction and supply of several sub-assemblies and inventory management of sub-assemblies used in our hardware products. There are no minimum purchase requirements. The contract with the Company's supplier may be terminated by either the supplier or by the Company without cause and at any time upon delivery of two months' notice. Purchases from this supplier were $47.9 million, $41.7 million and $34.5 million for the years ended December 31, 2016, December 31, 2015 and December 31, 2014, respectively.

[0000926326-17-000015:notes:256]
Property and equipment

[0000926326-17-000015:notes:257]
Property and equipment less accumulated depreciation are stated at historical cost. The Company's expenditures for property and equipment primarily are for computer equipment and software used in the administration of its business, and for leasehold improvements to its leased facilities. The Company also develops molds and dies used in long-term manufacturing arrangements with suppliers and for production automation equipment used in the manufacturing of consumable blister card components. Depreciation and amortization of property and equipment are provided over their estimated useful lives, using the straight-line method, as follows:

[0000926326-17-000015:notes:258]
| Computer equipment and related software | 3 - 5 years |
| Leasehold and building improvements | Shorter of the lease term or the estimated useful life |
| Furniture and fixtures | 5 - 7 years |
| Equipment | 3 - 12 years |

[0000926326-17-000015:notes:259]
Depreciation and amortization of property and equipment was $15.0 million, $12.8 million and $11.3 million for the years ended December 31, 2016, December 31, 2015 and December 31, 2014, respectively.

[0000926326-17-000015:notes:260]
The Company capitalizes costs related to computer software developed or obtained for internal use in accordance with ASC 350-40, Internal-Use Software. Software obtained for internal use has generally been enterprise-level business and finance software that the Company customizes to meet its specific operational needs. Costs incurred in the application development phase are capitalized and amortized over their useful lives, which is generally five years. Costs recognized in the preliminary project phase and the post-implementation phase are expensed as incurred. The Company capitalized $2.2 million and $1.2 million of costs related to the application development of enterprise-level software that was included in property and equipment during the years ended December 31, 2016 and December 31, 2015, respectively.

[0000926326-17-000015:notes:261]
Software development costs

[0000926326-17-000015:notes:262]
The Company capitalizes software development costs in accordance with ASC 985-20, Costs of Software to Be Sold, Leased, or Marketed, under which certain software development costs incurred subsequent to the establishment of technological feasibility may be capitalized and amortized over the estimated lives of the related products. The Company establishes feasibility when it completes a working model and amortizes development costs over the estimated lives of the related products ranging from three to five years. The Company capitalized software development costs of $14.3 million and $12.1 million which are included in other assets as of December 31, 2016 and December 31, 2015, respectively. The Company recorded $7.1 million, $5.8 million and $4.4 million to cost of revenues for amortization of capitalized software development costs for the years ended December 31, 2016, December 31, 2015 and December 31, 2014, respectively. All development costs prior to the completion of a working model are recognized as research and development expense.

[0000926326-17-000015:notes:263]
Deferred revenue

[0000926326-17-000015:notes:264]
Deferred revenue arise when customers have been billed and/or have received products and/or services in advance of revenue recognition. The Company's deferred revenue, net, presented as short term consists primarily of (i) unearned revenue on sale of equipment for which installation has not been completed, net of deferred cost of sales for such equipment, and (ii) the current portion of unearned service contracts for which revenue is recognized over their duration.  Long-term deferred revenue includes long term portion of unearned service contracts.

[0000926326-17-000015:notes:265]
Business combinations

[0000926326-17-000015:notes:266]
The Company uses the acquisition method of accounting under the authoritative guidance on business combinations. Each acquired company’s operating results are included in the Company's Consolidated Financial Statements starting on the date of acquisition. The purchase price is equivalent to the fair value of consideration transferred. Tangible and identifiable intangible assets acquired and liabilities assumed as of the date of acquisition are recorded at the acquisition date fair value. Goodwill is recognized for the excess of purchase price over the net fair value of assets acquired and liabilities assumed.

[0000926326-17-000015:notes:267]
Amounts allocated to assets and liabilities are based upon fair values. Such valuations require management to make significant estimates and assumptions, especially with respect to the identifiable intangible assets. Management makes estimates of fair value based upon assumptions believed to be reasonable and that of a market participant. These estimates are based on historical experience and information obtained from the management of the acquired companies and the estimates are inherently uncertain. The separately identifiable intangible assets generally include customer relationships, technology, and trade names.

[0000926326-17-000015:notes:268]
The Company accounts for share-based compensation in accordance with ASC 718, Stock Compensation ("ASC 718"). The Company recognizes compensation expense related to stock-based compensation based on the grant date estimated fair value. The Company amortizes the fair value of the employee stock awards on a straight-line basis over the requisite service period of the award, which is generally the vesting period. The Company estimates the fair value of stock-based compensation awards using the Black-Scholes option pricing model, which requires the following inputs: expected life, expected volatility, risk-free interest rate, expected dividend yield rate, exercise price, and closing price of its common stock on the date of grant. The expected volatility is based on a combination of historical and market-based implied volatility, and the expected life of the awards is based on the Company's historical experience of employee stock option exercises, including forfeitures. The valuation assumptions used in estimating the fair value of employee share-based awards may change in future periods. The Company calculates its pool of excess tax benefits available within additional paid-in capital in accordance with the provisions of ASC 718.

[0000926326-17-000015:notes:269]
Sales commissions are incremental and directly related to customer sales contracts in which revenue is deferred. These commission costs are accrued and recorded in prepaid expenses upon execution of a non-cancelable customer contract and subsequently expensed in the period of revenue recognition. Commission expense was $22.0 million, $13.7 million and $14.0 million for the years ended December 31, 2016, December 31, 2015 and December 31, 2016, respectively.

[0000926326-17-000015:notes:270]
Shipping costs

[0000926326-17-000015:notes:271]
Outbound freight billed to customers is recorded as product revenue. The related shipping and handling costs are expensed as part of selling, general and administrative expense. Shipping and handling expenses were $12.1 million, $8.5 million and $7.4 million for the year ended December 31, 2016, December 31, 2015 and December 31, 2014, respectively.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000926326-17-000015:notes:272]
2016 Restructuring Expenses

[0000926326-17-000015:notes:273]
In second quarter of 2016, the Company integrated its Sales and Field organizations in North America to better serve its customers which resulted in a reduction in headcount of 36 employees. Accordingly, the Company incurred approximately $1.7 million of restructuring expenses in the year ended December 31, 2016, based on agreements with terminated employees covering salary and benefit continuation. For the year ended December 31, 2016, the Company made payments of $1.7 million and the restructuring program was concluded.


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0000926326-17-000015:notes:274]
Revenues

[0000926326-17-000015:notes:275]
|  | Year Ended |
|  | December 31, 2016 |  | December 31, 2015 |  | December 31, 2014 |
|  | (In thousands) |
| United States | $ | 591,566 |  |  | $ | 403,375 |  |  | $ | 394,234 |  |
| Rest of world (1) | 101,057 |  |  | 81,184 |  |  | 46,666 |  |
| Total revenues | $ | 692,623 |  |  | $ | 484,559 |  |  | $ | 440,900 |  |

[0000926326-17-000015:notes:276]
______________________________________________


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0000926326-17-000015:notes:277]
The following table summarizes the changes in accumulated balances of other comprehensive income (loss) for the years ended December 31, 2016 and 2015:

[0000926326-17-000015:notes:278]
|  | Foreign currency translation adjustments |  | Unrealized gain (loss) on interest rate swap hedges |  | Total |
|  | (In thousands) |
| Balance as of December 31, 2014 | $ | (1,361 | ) |  | $ | — |  |  | $ | (1,361 | ) |
| Other comprehensive income (loss) before reclassifications | (1,369 | ) |  | — |  |  | (1,369 | ) |
| Amounts reclassified from other comprehensive income (loss), net of tax | — |  |  | — |  |  | — |  |
| Net current-period other comprehensive income (loss), net of tax | (1,369 | ) |  | — |  |  | (1,369 | ) |
| Balance as of December 31, 2015 | (2,730 | ) |  | — |  |  | (2,730 | ) |
| Other comprehensive income (loss) before reclassifications | (8,034 | ) |  | 1,385 |  |  | (6,649 | ) |
| Amounts reclassified from other comprehensive income (loss), net of tax | — |  | (140 | ) |  | (140 | ) |
| Net current-period other comprehensive income (loss), net of tax | (8,034 | ) |  | 1,245 |  |  | (6,789 | ) |
| Balance as of December 31, 2016 | $ | (10,764 | ) |  | $ | 1,245 |  |  | $ | (9,519 | ) |


## us-gaap:ScheduleOfCondensedBalanceSheetTableTextBlock

[0000926326-17-000015:notes:279]
Balance sheet details as of December 31, 2016 and December 31, 2015 are presented in the tables below:

[0000926326-17-000015:notes:280]
|  | December 31, 2016 |  | December 31, 2015 |
|  | (In thousands) |
| Inventories: |  |  |  |
| Raw materials | $ | 14,322 |  |  | $ | 11,582 |  |
| Work in process | 7,800 |  |  | 1,653 |  |
| Finished goods | 47,175 |  |  | 33,359 |  |
| Total inventories | $ | 69,297 |  |  | $ | 46,594 |  |
| Prepaid expenses |  |  |  |
| Prepaid commissions | $ | 13,176 |  |  | $ | 9,240 |  |
| Other prepaid expenses | 15,470 |  |  | 10,346 |  |
| Total prepaid expense | $ | 28,646 |  |  | $ | 19,586 |  |
| Property and equipment: |  |  |  |
| Equipment | $ | 64,384 |  |  | $ | 43,533 |  |
| Furniture and fixtures | 6,517 |  |  | 5,897 |  |
| Leasehold improvements | 9,778 |  |  | 9,063 |  |
| Software | 35,607 |  |  | 30,693 |  |
| Construction in progress | 7,211 |  |  | 3,651 |  |
| Property and equipment, gross | 123,497 |  |  | 92,837 |  |
| Accumulated depreciation and amortization | (81,486 | ) |  | (60,528 | ) |
| Total property and equipment, net | $ | 42,011 |  |  | $ | 32,309 |  |
| Other long term assets: |  |  |  |
| Capitalized software, net | $ | 33,233 |  |  | $ | 26,011 |  |
| Other assets | 1,818 |  |  | 1,883 |  |
| Total other long term assets, net | $ | 35,051 |  |  | $ | 27,894 |  |
| Accrued liabilities: |  |  |  |
| Advance payments from customers | $ | 7,030 |  |  | $ | 8,327 |  |
| Rebates and lease buyouts | 4,025 |  |  | 4,702 |  |
| Group purchasing organization fees | 3,737 |  |  | 2,983 |  |
| Taxes payable | 4,003 |  |  | 2,768 |  |
| Other accrued liabilities | 12,400 |  |  | 11,353 |  |
| Total accrued liabilities | $ | 31,195 |  |  | $ | 30,133 |  |


## us-gaap:ScheduleOfRecognizedIdentifiedAssetsAcquiredAndLiabilitiesAssumedTableTextBlock

[0000926326-17-000015:notes:281]
The following table represents the allocation of the purchase price to the assets acquired and the liabilities assumed by the Company during each acquisition, respectively, reconciled to the purchase price transferred included in the Company's Consolidated Balance Sheet:


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000926326-17-000015:notes:282]
The following table summarizes the financial performance of the Company's reporting segments:

[0000926326-17-000015:notes:283]
|  | Year Ended |
|  | December 31, 2016 |  | December 31, 2015 |  | December 31, 2014 |
|  | Automation andAnalytics (2) |  | MedicationAdherence (2) |  | Total |  | Automation andAnalytics (1) |  | MedicationAdherence (2) |  | Total |  | Automation andAnalytics |  | MedicationAdherence |  | Total |
|  | (In thousands) |
| Revenues | $ | 593,626 |  |  | $ | 98,997 |  |  | $ | 692,623 |  |  | $ | 390,321 |  |  | $ | 94,238 |  |  | $ | 484,559 |  |  | $ | 354,095 |  |  | $ | 86,805 |  |  | $ | 440,900 |  |
| Cost of revenues | 310,967 |  |  | 67,856 |  |  | 378,823 |  |  | 171,943 |  |  | 64,686 |  |  | 236,629 |  |  | 151,327 |  |  | 55,713 |  |  | 207,040 |  |
| Gross profit | 282,659 |  |  | 31,141 |  |  | 313,800 |  |  | 218,378 |  |  | 29,552 |  |  | 247,930 |  |  | 202,768 |  |  | 31,092 |  |  | 233,860 |  |
| Operating expenses | 198,511 |  |  | 24,843 |  |  | 223,354 |  |  | 114,084 |  |  | 24,258 |  |  | 138,342 |  |  | 105,929 |  |  | 20,586 |  |  | 126,515 |  |
| Income from operations | $ | 84,148 |  |  | $ | 6,298 |  |  | 90,446 |  |  | $ | 104,294 |  |  | $ | 5,294 |  |  | 109,588 |  |  | $ | 96,839 |  |  | $ | 10,506 |  |  | 107,345 |  |
| Corporate costs |  |  |  |  | 83,965 |  |  |  |  |  |  | 60,956 |  |  |  |  |  |  | 57,762 |  |
| Income from operations |  |  |  |  | $ | 6,481 |  |  |  |  |  |  | $ | 48,632 |  |  |  |  |  |  | $ | 49,583 |  |

[0000926326-17-000015:notes:284]
| (1) | Includes Avantec and Mach4 results as of April 2015, the acquisition date. |

[0000926326-17-000015:notes:285]
| (2) | Includes Aesynt and Ateb results as of January and December 2016, respectively, the acquisition dates. |


## us-gaap:ScheduleOfTreasuryStockByClassTextBlock

[0000926326-17-000015:notes:286]
The following table summarizes the Company's stock repurchases during the twelve months ended December 31, 2015 and December 31, 2014, respectively:

[0000926326-17-000015:notes:287]
|  |  | December 31, 2015 |  | December 31, 2014 |
|  |  | (In thousands, except per share data) |
| Total number of shares repurchased |  | 1,424 |  |  | 884 |  |
| Dollar amount of shares repurchased |  | $ | 50,021 |  |  | $ | 24,091 |  |
| Average price paid per share |  | $ | 35.13 |  |  | $ | 27.24 |  |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000926326-17-000015:notes:288]
SCHEDULE II

[0000926326-17-000015:notes:289]
VALUATION AND QUALIFYING ACCOUNTS

[0000926326-17-000015:notes:290]
|  |  |  | Additions |  |  |  |  |  |  |
|  | Balance atBeginning of Period (1) |  | Charged toCosts and Expenses (2) |  | Debited (credited) toOther Accounts (3) |  | AmountWritten Off (4) |  | Acquisition and translation adjustments (5) |  | Balance atEnd of Period (1) |
|  | (In thousands) |
| Year ended December 31, 2014 |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable | $ | 490 |  |  | $ | 941 |  |  | $ | (60 | ) |  | $ | (165 | ) |  | $ | — |  |  | $ | 1,206 |  |
| Investment in sales-type leases | 167 |  |  | — |  |  | (5 | ) |  | — |  |  | — |  |  | 162 |  |
| Total allowances deducted from assets | $ | 657 |  |  | $ | 941 |  |  | $ | (65 | ) |  | $ | (165 | ) |  | $ | — |  |  | $ | 1,368 |  |
| Year ended December 31, 2015 |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable | $ | 1,206 |  |  | $ | 453 |  |  | $ | 28 |  |  | $ | (447 | ) |  | $ | — |  |  | $ | 1,240 |  |
| Investment in sales-type leases | 162 |  |  | (99 | ) |  | 106 |  |  | — |  |  | — |  |  | 169 |  |
| Total allowances deducted from assets | $ | 1,368 |  |  | $ | 354 |  |  | $ | 134 |  |  | $ | (447 | ) |  | $ | — |  |  | $ | 1,409 |  |
| Year ended December 31, 2016 |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable | $ | 1,240 |  |  | $ | 727 |  |  | $ | 77 |  |  | $ | (369 | ) |  | $ | 3,121 |  |  | $ | 4,796 |  |
| Investment in sales-type leases | 169 |  |  | 85 |  |  | — |  |  | — |  |  | — |  |  | 254 |  |
| Total allowances deducted from assets | $ | 1,409 |  |  | $ | 812 |  |  | $ | 77 |  |  | $ | (369 | ) |  | $ | 3,121 |  |  | $ | 5,050 |  |

[0000926326-17-000015:notes:291]
__________________________________________________

[0000926326-17-000015:notes:292]
| (1) | Allowance for doubtful accounts. |

[0000926326-17-000015:notes:293]
| (2) | Represents amounts charged to bad debt expense, increasing the allowance. |

[0000926326-17-000015:notes:294]
| (3) | Represents amounts debited to trade accounts receivable as recoveries, increasing the allowance. |

[0000926326-17-000015:notes:295]
| (4) | Represents amounts written-off from the allowance and trade accounts receivable. |

[0000926326-17-000015:notes:296]
| (5) | Represents primarily purchase price adjustments and minor foreign currency translation adjustments. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000926326-17-000015:notes:297]
Segment and Geographical Information

[0000926326-17-000015:notes:298]
Segment Information

[0000926326-17-000015:notes:299]
The Company's Chief Operating Decision Maker ("CODM") is its Chief Executive Officer. The CODM allocates resources and evaluates the performance of the Company's segments using information about its revenues, gross profit, and income from operations. Such evaluation excludes general corporate-level costs that are not specific to either of the reportable segments and are managed separately at the corporate level. Corporate-level costs include expenses related to executive management, finance and accounting, human resources, legal, training and development, and certain administrative expenses. The two operating segments, which are the same as the Company's two reportable segments, are as follows:

[0000926326-17-000015:notes:300]
Automation and Analytics

[0000926326-17-000015:notes:301]
The Automation and Analytics segment is organized around the design, manufacturing, selling and servicing of medication and supply dispensing systems, pharmacy inventory management systems, and related software. The Automation and Analytics products are designed to enable the Company's customers to enhance and improve the effectiveness of the medication-use process, the efficiency of the medical-surgical supply chain, overall patient care and clinical and financial outcomes of medical facilities. Through modular configuration and upgrades, the Company's systems can be tailored to specific customer needs. The financial results of Aesynt acquired in the first quarter of 2016 are included in the Automation and Analytics segment.

[0000926326-17-000015:notes:302]
Medication Adherence

[0000926326-17-000015:notes:303]
The Medication Adherence segment includes primarily the manufacturing and selling of consumable medication blister cards, packaging equipment and ancillary products and services. These products are used to manage medication administration outside of the hospital setting and include medication adherence products, which consist of proprietary medication packaging systems and related products for use by institutional pharmacies servicing long-term care, and correctional facilities or retail pharmacies serving patients in their local communities. The financial results of Ateb acquired in the fourth quarter of 2016 are included in the Medication Adherence segment.

[0000926326-17-000015:notes:304]
The historical information presented has been retrospectively adjusted to reflect the new segment reporting.

[0000926326-17-000015:notes:305]
Significant customers

[0000926326-17-000015:notes:306]
There were no customers that accounted for more than 10% of the Company's total revenues in 2016, 2015 and 2014.

[0000926326-17-000015:notes:307]
Geographical Information

[0000926326-17-000015:notes:308]
Property and equipment, net is attributed to the geographic location in which it is located.


## us-gaap:SubsequentEventsTextBlock

[0000926326-17-000015:notes:309]
Subsequent Events

[0000926326-17-000015:notes:310]
On February 15, 2017, the Company announced its plan to reduce its workforce by approximately 100 full-time employees, expected to be substantially completed in the first quarter of 2017. In connection with this plan, the Company will close of the Company’s Nashville, Tennessee and Slovenia facilities.  Accordingly, the Company will accrue approximately $8.0 million in 2017 for restructuring related expenses.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000926326-17-000015:notes:311]
Balance Sheet Components


## us-gaap:TreasuryStockTextBlock

[0000926326-17-000015:notes:312]
Stock Repurchases

[0000926326-17-000015:notes:313]
On August 2, 2016, the Board of Directors (the "Board") of the Company authorized a stock repurchase program providing for the repurchase of up to $50.0 million of the Company’s common stock (the “2016 Repurchase Program”). The 2016 Repurchase Program is in addition to the stock repurchase program approved by the Board on November 4, 2014 (the “2014 Repurchase Program”). As of December 31, 2016, the maximum dollar value of shares that may yet be purchased under the two repurchase programs was $54.9 million.

[0000926326-17-000015:notes:314]
The timing, price and volume of repurchases are to be based on market conditions, relevant securities laws and other factors. The stock repurchases may be made from time to time on the open market, in privately negotiated transactions or pursuant to a Rule 10b-18 plan, subject to the terms and conditions of that certain Credit Agreement, dated as of January 5, 2016, among the Company, the Lenders party thereto, and Wells Fargo Bank, National Association, as administrative agent. The stock repurchase program does not obligate the Company to repurchase any specific number of shares, and the Company may terminate or suspend the repurchase program at any time. During the twelve months ended December 31, 2016 the Company made no repurchases of its outstanding common stock.
