# OMCL note change history — 0000926326-16-000070 → 0000926326-16-000077


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-11-07):
[0000926326-16-000077:note_history:1]
The Company leases office space and office equipment under operating leases. Commitments under operating leases primarily relate to leasehold property and office equipment.  At September 30, 2016, the minimum future payments on non-cancelable operating leases were as follows:
  (was, 2016-08-05, similarity 0.7992):
[0000926326-16-000070:note_history:1]
The Company leases office space and office equipment under operating leases. Commitments under operating leases primarily relate to leasehold property and office equipment.  At June 30, 2016, the minimum future payments on non-cancelable operating leases were as follows:

- changed (2016-11-07):
[0000926326-16-000077:note_history:2]
|  | (In thousands) |
| Remaining three months of 2016 | $ | 2,749 |  |
| 2017 | 10,755 |  |
| 2018 | 10,379 |  |
| 2019 | 10,127 |  |
| 2020 | 6,459 |  |
| Thereafter | 11,086 |  |
| Total minimum future lease payments | $ | 51,555 |  |
  (was, 2016-08-05, similarity 0.9778):
[0000926326-16-000070:note_history:2]
|  | (In thousands) |
| Remaining six months of 2016 | $ | 5,343 |  |
| 2017 | 10,549 |  |
| 2018 | 10,141 |  |
| 2019 | 9,897 |  |
| 2020 | 6,270 |  |
| Thereafter | 10,711 |  |
| Total minimum future lease payments | $ | 52,911 |  |

- changed (2016-11-07):
[0000926326-16-000077:note_history:3]
During the course of the business, the Company issues purchase orders based on its current manufacturing needs.  At September 30, 2016, the Company had non-cancelable purchase commitments of $41.0 million, which are expected to be paid within the next twelve months.
  (was, 2016-08-05, similarity 0.9744):
[0000926326-16-000070:note_history:3]
During the course of the business, the Company issues purchase orders based on its current manufacturing needs.  At June 30, 2016, the Company had non-cancelable purchase commitments of $39.6 million, which are expected to be paid within the next twelve months.

- changed (2016-11-07):
[0000926326-16-000077:note_history:4]
The Company is currently involved in various legal proceedings. As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any accrual for contingent liabilities associated with the legal proceedings described below based on its belief that any potential loss, while reasonably possible, is not probable. Further, any possible range of loss in any current matters cannot be reasonably estimated at this time. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of this contingency or because of the diversion of management's attention and the creation of significant expenses.
  (was, 2016-08-05, similarity 0.9917):
[0000926326-16-000070:note_history:4]
The Company is currently involved in various legal proceedings. As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any accrual for contingent liabilities associated with the legal proceedings described below based on its belief that any potential loss, while reasonably possible, is not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of this contingency or because of the diversion of management's attention and the creation of significant expenses.

- changed (2016-11-07):
[0000926326-16-000077:note_history:5]
The Company’s legal proceeding as of September 30, 2016 was as follows:
  (was, 2016-08-05, similarity 0.9134):
[0000926326-16-000070:note_history:5]
The Company’s legal proceeding as of June 30, 2016 was as follows:


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-11-07):
[0000926326-16-000077:note_history:6]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of September 30, 2016 and December 31, 2015, the results of its operations, comprehensive income (loss) and cash flows for the three and nine months ended September 30, 2016 and September 30, 2015. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company's annual report on Form 10-K for the year ended December 31, 2015 filed with the SEC on February 26, 2016. The Company's results of operations, comprehensive income (loss) and cash flows for the three and nine months ended September 30, 2016 are not necessarily indicative of results that may be expected for the year ending December 31, 2016, or for any future period.
  (was, 2016-08-05, similarity 0.8615):
[0000926326-16-000070:note_history:6]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of June 30, 2016 and December 31, 2015, the results of its operations, comprehensive income (loss) and cash flows for the three and six months ended June 30, 2016 and June 30, 2015. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company's annual report on Form 10-K for the year ended December 31, 2015 filed with the SEC on February 26, 2016. The Company's results of operations, comprehensive income (loss) and cash flows for the three and six months ended June 30, 2016 are not necessarily indicative of results that may be expected for the year ending December 31, 2016, or for any future period.

- added (2016-11-07):
[0000926326-16-000077:note_history:7]
Certain prior year amounts for the provision for excess and obsolete inventories and provision for receivables allowance have been reclassified/combined with inventories and accounts receivable within net cash provided by operating activities in the Condensed Consolidated Statements of Cash Flows to conform to 2016 presentation. These changes are not material and do not impact previously disclosed net cash provided by operating activities, net cash used in investing activities, and net cash used by financing activities.

- changed (2016-11-07):
[0000926326-16-000077:note_history:8]
The operating results of the acquired Aesynt business are included in the Company's Automation and Analytics reportable segment.
  (was, 2016-08-05, similarity 0.966):
[0000926326-16-000070:note_history:8]
The operating results of the recently acquired Aesynt business are included in the Company's Automation and Analytics reportable segment.

- changed (2016-11-07):
[0000926326-16-000077:note_history:9]
In April 2015, the Financial Accounting Standards Board ("FASB") issued ASU 2015-05-Intangibles-Goodwill and Other-Internal-Use Software- Customer’s Accounting for Fees Paid in a Cloud Computing Arrangement, which provides guidance on determining whether a cloud computing arrangement contains a software license. If a cloud computing arrangement includes a software license, then the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If a cloud computing arrangement does not include a software license, the customer should account for the arrangement as a service contract. The Company adopted ASU 2015-05 on a prospective basis beginning on January 1, 2016. The impact of ASU 2015-05 did not have a material impact on the Company's consolidated financial position or results of operations for the three and nine months ended September 30, 2016.
  (was, 2016-08-05, similarity 0.969):
[0000926326-16-000070:note_history:9]
In April 2015, the Financial Accounting Standards Board ("FASB") issued ASU 2015-05-Intangibles-Goodwill and Other-Internal-Use Software- Customer’s Accounting for Fees Paid in a Cloud Computing Arrangement, which provides guidance on determining whether a cloud computing arrangement contains a software license. If a cloud computing arrangement includes a software license, then the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If a cloud computing arrangement does not include a software license, the customer should account for the arrangement as a service contract. The Company adopted ASU 2015-05 on a prospective basis beginning on January 1, 2016. The impact of ASU 2015-05 did not have a material impact on the Company's consolidated financial position or results of operations for the three and six months ended June 30, 2016.

- changed (2016-11-07):
[0000926326-16-000077:note_history:10]
In July 2015, the FASB issued ASU No. 2015-11, Simplifying the Measurement of Inventory. This ASU changes the measurement principle for inventory from the lower of cost or market to lower of cost and net realizable value. Net realizable value is the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal and transportation. It applies to entities that measure inventory using a method other than last-in, first-out (LIFO) and the retail inventory method (RIM). The guidance is effective for fiscal years beginning after December 15, 2016. The adoption of this accounting standard update did not have a material impact on the Company's consolidated financial position or results of operations for the three and nine months ended September 30, 2016.
  (was, 2016-08-05, similarity 0.9695):
[0000926326-16-000070:note_history:10]
In July 2015, the FASB issued ASU No. 2015-11, Simplifying the Measurement of Inventory. This ASU changes the measurement principle for inventory from the lower of cost or market to lower of cost and net realizable value. Net realizable value is the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal and transportation. It applies to entities that measure inventory using a method other than last-in, first-out (LIFO) and the retail inventory method (RIM). The guidance is effective for fiscal years beginning after December 15, 2016. The adoption of this accounting standard update did not have a material impact on the Company's consolidated financial position or results of operations for the three and six months ended June 30, 2016.

- changed (2016-11-07):
[0000926326-16-000077:note_history:11]
In September 2015, the FASB issued ASU No. 2015-16, Business Combinations (Topic 805): Simplifying the Accounting for Measurement-Period Adjustments. This ASU requires adjustments to provisional amounts that are identified during the measurement period of a business combination to be recognized in the reporting period in which the adjustment amounts are determined. An acquirer is no longer required to revise comparative information for prior periods as if the accounting for the business combination had been completed as of the acquisition date. The provisions of ASU 2015-16 are effective for reporting periods beginning after December 15, 2015. The adoption of this accounting standard update did not have a material impact on the Company's consolidated financial position or results of operations for the three and nine months ended September 30, 2016.
  (was, 2016-08-05, similarity 0.9663):
[0000926326-16-000070:note_history:11]
In September 2015, the FASB issued ASU No. 2015-16, Business Combinations (Topic 805): Simplifying the Accounting for Measurement-Period Adjustments. This ASU requires adjustments to provisional amounts that are identified during the measurement period of a business combination to be recognized in the reporting period in which the adjustment amounts are determined. An acquirer is no longer required to revise comparative information for prior periods as if the accounting for the business combination had been completed as of the acquisition date. The provisions of ASU 2015-16 are effective for reporting periods beginning after December 15, 2015. The adoption of this accounting standard update did not have a material impact on the Company's consolidated financial position or results of operations for the three and six months ended June 30, 2016.

- changed (2016-11-07):
[0000926326-16-000077:note_history:12]
In March 2016, the FASB issued ASU No. 2016-09, Compensation—Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting. This ASU simplifies several aspects of the accounting for share-based payment transactions, including the income tax consequences, classification of awards as either equity or liabilities, and classification on the statement of cash flows. The provision of ASU No. 2016-09 are effective for annual periods beginning after December 15, 2016, and interim periods within those annual periods. Early adoption is permitted for any entity in any interim or annual period. If an entity early adopts the amendments in an interim period, any adjustments are reflected as of the beginning of the fiscal year that includes that interim period. An entity that elects early adoption must adopt all of the amendments in the same period. The Company is currently in the process of evaluating the impact of the adoption of ASU 2016-09 on its consolidated financial statements.
  (was, 2016-08-05, similarity 0.997):
[0000926326-16-000070:note_history:12]
In March 2016, the FASB issued ASU No. 2016-09, Compensation—Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting. This ASU simplifies several aspects of the accounting for share-based payment transactions, including the income tax consequences, classification of awards as either equity or liabilities, and classification on the statement of cash flows. The provision of ASU No. 2016-09 are effective for annual periods beginning after December 15, 2016, and interim periods within those annual periods. Early adoption is permitted for any entity in any interim or annual period. If an entity early adopts the amendments in an interim period, any adjustments are reflected as of the beginning of the fiscal year that includes that interim period. An entity that elects early adoption must adopt all of the amendments in the same period. The Company is currently in the process of evaluating the impact of the early adoption of ASU 2016-09 on its consolidated financial statements.

- added (2016-11-07):
[0000926326-16-000077:note_history:13]
In August 2016, the FASB issued ASU No. 2016-15, Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments. This ASU requires changes in the presentation of certain items including but not limited to debt prepayment or debt extinguishment costs; contingent consideration payments made after a business combination; proceeds from the settlement of insurance claims; proceeds from the settlement of corporate-owned life insurance policies and distributions received from equity method investees. The new guidance will be effective for fiscal years beginning after December 15, 2017, including interim periods within those fiscal years and should be applied prospectively. Early adoption is permitted as of the beginning of an interim or annual reporting period. The Company is currently evaluating the impact ASU 2016-15 will have on its consolidated financial statements.

- added (2016-11-07):
[0000926326-16-000077:note_history:14]
In October 2016, the FASB issued ASU No. 2016-16, Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory, which reduces the complexity in the accounting standards by allowing the recognition of current and deferred income taxes for an intra-entity asset transfer, other than inventory, when the transfer occurs. Historically, recognition of the income tax consequence was not recognized until the asset was sold to an outside party.  This amendment should be applied on a modified retrospective basis through a cumulative-effect adjustment directly to retained earnings as of the beginning of the period of adoption.  ASU 2016-16 is effective for annual periods beginning after December 15, 2017, including interim reporting periods within those annual reporting periods.  Early adoption is permitted for all entities as of the beginning of an annual reporting period for which financial statements (interim or annual) have not been issued or made available for issuance. The Company is currently evaluating the impact ASU 2016-16 will have on its consolidated financial statements.

- removed (2016-11-07):
[0000926326-16-000070:note_history:15]
Concentration of credit risk

- removed (2016-11-07):
[0000926326-16-000070:note_history:16]
Financial instruments that may potentially subject the Company to concentrations of credit risk consist principally of cash equivalents and accounts receivable. Cash equivalents are maintained with several financial institutions and may exceed the amount of insurance provided on such balances. The majority of the Company's accounts receivable are derived from sales to customers for commercial applications. The Company performs ongoing credit evaluations of its customers’ financial condition and limit the amount of credit extended when deemed necessary but generally require no collateral. The Company maintains reserves for potential credit losses. The Company's products are broadly distributed and there were no customers that accounted for more than 10% of its accounts receivable as of June 30, 2016 and December 31, 2015. The Company believes that it has no significant concentrations of credit risk as of June 30, 2016.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-11-07):
[0000926326-16-000077:note_history:17]
The Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends and other distributions. The Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum consolidated total leverage ratio and maintain a minimum fixed charge coverage ratio.  The Company’s obligations under the Credit Agreement and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and the subsidiary guarantors’ assets. In connection with entering into the Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a collateral agreement and subsidiary guaranty agreement.  The Company was in full compliance with all covenants as of September 30, 2016.
  (was, 2016-08-05, similarity 0.9946):
[0000926326-16-000070:note_history:17]
The Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends and other distributions. The Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum consolidated total leverage ratio and maintain a minimum fixed charge coverage ratio.  The Company’s obligations under the Credit Agreement and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and the subsidiary guarantors’ assets. In connection with entering into the Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a collateral agreement and subsidiary guaranty agreement.  The Company was in full compliance with all covenants as of June 30, 2016.

- changed (2016-11-07):
[0000926326-16-000077:note_history:18]
The components of the Company’s debt obligations as of September 30, 2016 and December 31, 2015 are as follows:
  (was, 2016-08-05, similarity 0.9442):
[0000926326-16-000070:note_history:18]
The components of the Company’s debt obligations as of June 30, 2016 and December 31, 2015 are as follows:

- added (2016-11-07):
[0000926326-16-000077:note_history:19]
|  | December 31, 2015 | Borrowings | Repayment/Amortization | September 30, 2016 |
|  | (In thousands) |
| Term loan facility | $ | — |  | $ | 200,000 |  | $ | (5,000 | ) | $ | 195,000 |  |
| Revolving credit facility | — |  | 55,000 |  | (20,000 | ) | 35,000 |  |
| Total debt under the facilities(1) | — |  | 255,000 |  | (25,000 | ) | 230,000 |  |
| Less: Deferred issuance cost | — |  | (7,949 | ) | 1,193 |  | (6,756 | ) |
| Total Debt, net of deferred issuance cost | $ | — |  | $ | 247,051 |  | $ | (23,807 | ) | 223,244 |  |
| Long term debt, current portion, net of deferred issuance cost |  |  |  | 8,410 |  |
| Long term debt, net of deferred issuance cost |  |  |  | $ | 214,834 |  |

- changed (2016-11-07):
[0000926326-16-000077:note_history:20]
(1) The fair value of total debt under the facilities approximates the book value as of September 30, 2016.
  (was, 2016-08-05, similarity 0.9442):
[0000926326-16-000070:note_history:20]
(1) The fair value of total debt under the facilities approximates the book value as of June 30, 2016.

- removed (2016-11-07):
[0000926326-16-000070:note_history:21]
|  | December 31, 2015 | Borrowings | Repayment/Amortization | June 30, 2016 |
|  | (In thousands) |
| Term loan facility | $ | — |  | $ | 200,000 |  | $ | (2,500 | ) | $ | 197,500 |  |
| Revolving credit facility | — |  | 55,000 |  | (20,000 | ) | 35,000 |  |
| Total debt under the facilities(1) | — |  | 255,000 |  | (22,500 | ) | 232,500 |  |
| Less: Deferred issuance cost | — |  | (7,949 | ) | 795 |  | (7,154 | ) |
| Total Debt, net of deferred issuance cost | $ | — |  | $ | 247,051 |  | $ | (21,705 | ) | 225,346 |  |
| Long term debt, current portion, net of deferred issuance cost |  |  |  | 8,410 |  |
| Long term debt, net of deferred issuance cost |  |  |  | $ | 216,936 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-11-07):
[0000926326-16-000077:note_history:22]
The components of the Company’s debt obligations as of September 30, 2016 and December 31, 2015 are as follows:
  (was, 2016-08-05, similarity 0.9442):
[0000926326-16-000070:note_history:22]
The components of the Company’s debt obligations as of June 30, 2016 and December 31, 2015 are as follows:

- added (2016-11-07):
[0000926326-16-000077:note_history:23]
|  | December 31, 2015 | Borrowings | Repayment/Amortization | September 30, 2016 |
|  | (In thousands) |
| Term loan facility | $ | — |  | $ | 200,000 |  | $ | (5,000 | ) | $ | 195,000 |  |
| Revolving credit facility | — |  | 55,000 |  | (20,000 | ) | 35,000 |  |
| Total debt under the facilities(1) | — |  | 255,000 |  | (25,000 | ) | 230,000 |  |
| Less: Deferred issuance cost | — |  | (7,949 | ) | 1,193 |  | (6,756 | ) |
| Total Debt, net of deferred issuance cost | $ | — |  | $ | 247,051 |  | $ | (23,807 | ) | 223,244 |  |
| Long term debt, current portion, net of deferred issuance cost |  |  |  | 8,410 |  |
| Long term debt, net of deferred issuance cost |  |  |  | $ | 214,834 |  |

- changed (2016-11-07):
[0000926326-16-000077:note_history:24]
(1) The fair value of total debt under the facilities approximates the book value as of September 30, 2016.
  (was, 2016-08-05, similarity 0.9442):
[0000926326-16-000070:note_history:24]
(1) The fair value of total debt under the facilities approximates the book value as of June 30, 2016.

- removed (2016-11-07):
[0000926326-16-000070:note_history:25]
|  | December 31, 2015 | Borrowings | Repayment/Amortization | June 30, 2016 |
|  | (In thousands) |
| Term loan facility | $ | — |  | $ | 200,000 |  | $ | (2,500 | ) | $ | 197,500 |  |
| Revolving credit facility | — |  | 55,000 |  | (20,000 | ) | 35,000 |  |
| Total debt under the facilities(1) | — |  | 255,000 |  | (22,500 | ) | 232,500 |  |
| Less: Deferred issuance cost | — |  | (7,949 | ) | 795 |  | (7,154 | ) |
| Total Debt, net of deferred issuance cost | $ | — |  | $ | 247,051 |  | $ | (21,705 | ) | 225,346 |  |
| Long term debt, current portion, net of deferred issuance cost |  |  |  | 8,410 |  |
| Long term debt, net of deferred issuance cost |  |  |  | $ | 216,936 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2016-11-07):
[0000926326-16-000070:note_history:26]
Subsequent Events

- removed (2016-11-07):
[0000926326-16-000070:note_history:27]
On August 2, 2016, the Board of Directors (the "Board") of Omnicell, Inc. (the “Company”) authorized a stock repurchase program providing for the repurchase of up to $50.0 million of the Company’s common stock (the “2016 Repurchase Program”).

- removed (2016-11-07):
[0000926326-16-000070:note_history:28]
The 2016 Repurchase Program is in addition to the stock repurchase program approved by the Board on November 4, 2014 (the “2014 Repurchase Program”). As of June 30, 2016, the maximum dollar value of shares that may yet be purchased under the 2014 Repurchase Program was $4.9 million.

- removed (2016-11-07):
[0000926326-16-000070:note_history:29]
The timing, price and volume of repurchases are to be based on market conditions, relevant securities laws and other factors. The stock repurchases may be made from time to time on the open market, in privately negotiated transactions or pursuant to a Rule 10b-18 plan, subject to the terms and conditions of that certain Credit Agreement, dated as of January 5, 2016, among the Company, the Lenders party thereto, and Wells Fargo Bank, National Association, as administrative agent. The stock repurchase program does not obligate the Company to repurchase any specific number of shares, and the Company may terminate or suspend the repurchase program at any time.
