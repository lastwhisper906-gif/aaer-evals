# OMCL 8-K — 0000926326-17-000008 filed 2017-02-15

## item codes, every 8-K on or before 2017-02-28

- 2017-02-15 0000926326-17-000010 — 2.05
- 2017-02-15 0000926326-17-000008 — 2.02, 9.01
- 2017-02-13 0000926326-17-000002 — 5.02
- 2016-12-08 0001104659-16-161330 — 2.01, 2.03, 9.01
- 2016-12-06 0001104659-16-160709 — 7.01
- 2016-11-29 0001104659-16-159456 — 1.01, 7.01, 9.01
- 2016-10-27 0000926326-16-000075 — 2.02, 9.01
- 2016-10-07 0000926326-16-000072 — 5.02, 8.01
- 2016-08-05 0000926326-16-000068 — 8.01
- 2016-07-28 0000926326-16-000066 — 2.02, 9.01
- 2016-06-13 0001104659-16-126854 — 5.02
- 2016-05-25 0000926326-16-000060 — 5.07
- 2016-04-28 0000926326-16-000054 — 2.02, 9.01
- 2016-03-21 0001104659-16-106649 — 8.01, 9.01
- 2016-03-17 0000926326-16-000051 — 7.01, 9.01
- 2016-03-17 0000926326-16-000049 — 9.01 — amendment of 0000926326-16-000051
- 2016-02-10 0001104659-16-095486 — 5.02, 9.01
- 2016-02-04 0000926326-16-000041 — 2.02, 9.01
- 2016-01-06 0001104659-16-088299 — 1.01, 2.01, 2.03, 9.01
- 2015-12-10 0000926326-15-000038 — 8.01, 9.01
- 2015-10-29 0001104659-15-074138 — 1.01, 9.01
- 2015-10-29 0000926326-15-000031 — 2.02, 9.01
- 2015-08-20 0001104659-15-061135 — 5.02, 9.01
- 2015-07-30 0000926326-15-000024 — 2.02, 9.01
- 2015-05-22 0001104659-15-040440 — 5.07
- 2015-05-01 0001104659-15-032846 — 5.02
- 2015-05-01 0001104659-15-032844 — 7.01
- 2015-04-30 0000926326-15-000015 — 9.01
- 2015-04-22 0001104659-15-029356 — 8.01, 9.01
- 2015-03-20 0001104659-15-021435 — 3.01
- 2015-03-18 0001104659-15-020699 — 7.01
- 2015-03-17 0001104659-15-020483 — 8.01, 9.01
- 2015-03-02 0001104659-15-015802 — 1.01, 9.01
- 2015-02-12 0001104659-15-009234 — 5.02, 9.01
- 2015-02-03 0000926326-15-000003 — 9.01
- 2015-01-15 0001104659-15-002635 — 5.02
- 2014-11-07 0001104659-14-078398 — 1.01, 8.01, 9.01
- 2014-10-30 0000926326-14-000037 — 2.02, 9.01
- 2014-08-25 0001104659-14-062772 — 8.01, 9.01
- 2014-07-31 0000926326-14-000032 — 2.02, 9.01
- 2014-05-21 0001104659-14-040744 — 5.07
- 2014-05-01 0000926326-14-000008 — 2.02, 9.01
- 2014-04-08 0001104659-14-026441 — 4.01, 9.01
- 2014-04-02 0001104659-14-025179 — 5.02
- 2014-02-07 0001104659-14-007552 — 5.02, 9.01
- 2014-02-04 0001104659-14-006352 — 2.02, 9.01
- 2013-12-09 0001104659-13-088980 — 1.01, 9.01
- 2013-12-02 0001104659-13-087877 — 5.02
- 2013-10-31 0001104659-13-079660 — 2.02, 9.01
- 2013-09-26 0001104659-13-072435 — 1.01, 2.03, 9.01
- 2013-08-01 0001104659-13-058959 — 2.02, 9.01
- 2013-05-23 0001104659-13-044317 — 5.07
- 2013-05-02 0001104659-13-036605 — 2.02, 9.01
- 2013-03-11 0001104659-13-019143 — 8.01
- 2013-02-07 0001104659-13-008477 — 5.02, 9.01
- 2013-01-31 0001104659-13-006446 — 2.02, 9.01
- 2012-11-02 0001104659-12-073697 — 5.02
- 2012-10-25 0001104659-12-071211 — 2.02, 9.01
- 2012-08-06 0001104659-12-054635 — 8.01
- 2012-08-03 0001104659-12-054214 — 2.01, 9.01 — amendment of 0001104659-12-038888
- 2012-08-01 0001104659-12-053005 — 2.02, 9.01
- 2012-06-12 0001104659-12-042936 — 8.01, 9.01
- 2012-05-23 0001104659-12-039459 — 5.07
- 2012-05-22 0001104659-12-038888 — 2.01, 9.01
- 2012-05-02 0001104659-12-032048 — 2.02, 9.01
- 2012-05-02 0001104659-12-032036 — 1.01, 9.01
- 2012-04-04 0001104659-12-023883 — 5.02, 8.01
- 2012-03-20 0001104659-12-019462 — 1.01, 9.01
- 2012-02-13 0001104659-12-009353 — 5.02, 9.01
- 2012-01-26 0001104659-12-004244 — 2.02, 9.01
- 2011-10-27 0001104659-11-058464 — 2.02, 9.01
- 2011-10-25 0001104659-11-057721 — 1.01
- 2011-07-28 0001104659-11-041505 — 2.02, 9.01
- 2011-05-27 0001104659-11-032006 — 5.07
- 2011-05-02 0001104659-11-024908 — 2.02, 9.01
- 2011-04-15 0001104659-11-020407 — 5.02, 9.01 — amendment of 0001104659-11-005638
- 2011-02-08 0001104659-11-005638 — 5.02, 9.01
- 2011-01-27 0001104659-11-003419 — 2.02, 9.01
- 2010-12-22 0001104659-10-064003 — 5.02, 5.07, 9.01
- 2010-10-27 0001104659-10-054036 — 2.02, 9.01
- 2010-10-05 0001104659-10-051173 — 8.01
- 2010-07-22 0001104659-10-039126 — 2.02, 9.01
- 2010-07-09 0001104659-10-037594 — 2.05
- 2010-05-28 0001104659-10-031607 — 5.07
- 2010-04-26 0001104659-10-021797 — 2.02, 9.01
- 2010-03-17 0001104659-10-014849 — 5.02, 9.01
- 2010-02-08 0001104659-10-005457 — 5.02, 9.01
- 2010-01-28 0001104659-10-003627 — 2.02, 9.01
- 2009-10-22 0001104659-09-059972 — 2.02, 9.01
- 2009-07-23 0001104659-09-044508 — 2.02, 9.01
- 2009-05-20 0001104659-09-033938 — 5.02, 9.01
- 2009-04-30 0001104659-09-027707 — 2.02, 9.01
- 2009-03-10 0001104659-09-016178 — 5.02, 9.01
- 2009-02-09 0001104659-09-007692 — 5.02, 9.01
- 2009-01-29 0001104659-09-005022 — 2.02, 2.05, 9.01
- 2009-01-21 0001104659-09-003180 — 2.02, 8.01, 9.01
- 2009-01-06 0001104659-09-000625 — 5.02
- 2008-10-23 0001104659-08-065475 — 2.02, 9.01
- 2008-07-21 0001104659-08-046690 — 2.02, 9.01
- 2008-05-16 0001104659-08-034035 — 8.01, 9.01
- 2008-04-28 0001104659-08-027379 — 7.01, 9.01
- 2008-04-21 0001104659-08-025616 — 2.02, 9.01
- 2008-03-12 0001104659-08-016939 — 7.01, 9.01
- 2008-02-26 0001104659-08-012840 — 7.01, 9.01
- 2008-02-12 0001104659-08-009382 — 5.02, 9.01
- 2008-01-31 0001104659-08-006199 — 2.02, 9.01
- 2007-12-05 0001104659-07-087191 — 1.01, 9.01
- 2007-10-18 0001104659-07-075654 — 2.02, 9.01
- 2007-07-27 0001104659-07-056886 — 5.03, 9.01
- 2007-07-19 0001104659-07-054924 — 2.02, 9.01
- 2007-05-23 0001104659-07-042287 — 8.01, 9.01
- 2007-05-07 0001104659-07-036172 — 1.01, 5.02, 9.01
- 2007-04-24 0001104659-07-030578 — 2.02, 9.01 — amendment, the index does not say of what
- 2007-04-24 0001104659-07-030547 — 2.02, 9.01
- 2007-04-10 0001104659-07-027465 — 5.02, 9.01
- 2007-03-23 0001104659-07-021969 — 2.02, 4.02, 9.01
- 2007-01-30 0001104659-07-005772 — 2.02, 9.01
- 2007-01-09 0001104659-07-001600 — 5.02, 9.01
- 2006-10-30 0001104659-06-069612 — 1.01
- 2006-10-19 0001104659-06-067549 — 2.02, 9.01
- 2006-07-20 0001104659-06-048020 — 2.02, 4.02, 9.01
- 2006-05-17 0001104659-06-035522 — 1.01, 9.01 — amendment of 0001104659-05-011155
- 2006-05-09 0001104659-06-032706 — 1.01, 9.01
- 2006-04-25 0001104659-06-027438 — 2.02, 9.01
- 2006-04-04 0001104659-06-022204 — 1.01, 9.01
- 2006-03-15 0001104659-06-016861 — 1.01, 9.01
- 2006-01-30 0001104659-06-004749 — 2.02, 9.01
- 2006-01-24 0001104659-06-003504 — 1.01, 5.02, 9.01
- 2005-12-13 0001104659-05-060532 — 1.01, 9.01
- 2005-11-10 0001104659-05-054663 — 2.02, 9.01
- 2005-07-21 0001104659-05-033464 — 2.02, 9.01
- 2005-06-22 0001104659-05-029255 — 1.01
- 2005-05-16 0001104659-05-023473 — 2.02, 9.01 — amendment of 0001104659-05-018173
- 2005-05-16 0001104659-05-023471 — 2.02, 9.01 — amendment of 0001104659-05-017382
- 2005-05-10 0001104659-05-022127 — 1.01
- 2005-04-26 0001104659-05-018173 — 2.02, 9.01
- 2005-04-21 0001104659-05-017382 — 2.02, 9.01
- 2005-04-06 0001104659-05-015401 — 5.02
- 2005-03-15 0001104659-05-011155 — 1.01, 9.01
- 2005-03-08 0001104659-05-009975 — 1.01, 9.01
- 2005-02-03 0001104659-05-003943 — 2.02, 9.01
- 2005-01-13 0001104659-05-001314 — 5.02, 9.01
- 2004-10-21 0001104659-04-031413 — 2.02, 9.01
- 2004-07-22 0001104659-04-020572 — 12, 7
- 2004-04-14 0001104659-04-010039 — 12, 7
- 2004-04-05 0001104659-04-009437 — 12, 7
- 2004-01-26 0001104659-04-001655 — 12, 7
- 2003-10-16 0001104659-03-022990 — 12, 7
- 2003-07-17 0001104659-03-015053 — 9
- 2003-04-18 0001104659-03-006823 — 7, 9
- 2003-02-14 0001104659-03-002607 — 5, 7

## late-filing notifications on or before 2017-02-28

- 2015-03-02 0000926326-15-000006 — NT 10-K, for the period ended 2014-12-31
- 2007-03-16 0001104659-07-020094 — NT 10-K, for the period ended 2006-12-31

## item 2.02 — earnings release, exhibit 99.1

[0000926326-17-000008:8k_2_02:1]
EX-99.1
2
exhibit991q416.htm
EXHIBIT 99.1

[0000926326-17-000008:8k_2_02:2]
Exhibit

[0000926326-17-000008:8k_2_02:3]
Exhibit 99.1

[0000926326-17-000008:8k_2_02:4]
| Contact: |  |  |
| Peter Kuipers |  | Omnicell, Inc. |
| Chief Financial Officer |  | 590 East Middlefield Road |
| 800-850-6664, ext. 6180 |  | Mountain View, CA 94043 |
| Peter.kuipers@omnicell.com |  |  |

[0000926326-17-000008:8k_2_02:5]
Omnicell Reports Results for Fiscal Year and Fourth Quarter 2016

[0000926326-17-000008:8k_2_02:6]
Record yearly GAAP revenue of $692.6 million, representing 43% year over year growth

[0000926326-17-000008:8k_2_02:7]
Record yearly Non-GAAP revenue of $703.3 million, representing 45% year over year growth

[0000926326-17-000008:8k_2_02:8]
Record product bookings of $541 million, representing 38% year over year growth

[0000926326-17-000008:8k_2_02:9]
MOUNTAIN VIEW, Calif. -- February 15, 2017 -- Omnicell, Inc. (NASDAQ: OMCL), a leading provider of medication and supply management solutions to healthcare systems, today announced results for its fiscal year and fourth quarter ended December 31, 2016.

[0000926326-17-000008:8k_2_02:10]
GAAP results: Revenue for the fourth quarter of 2016 was $172.0 million, down $4.8 million or 2.7% from the third quarter of 2016, and up $41.7 million or 32.0% from the fourth quarter of 2015. Revenue for the year ended December 31, 2016 was $692.6 million, up $208.1 million or 42.9% from the year ended December 31, 2015.

[0000926326-17-000008:8k_2_02:11]
Fourth quarter 2016 net income as reported in accordance with U.S. generally accepted accounting principles (GAAP) was $0.2 million, or $0.00 per diluted share. This compares to GAAP net income of $2.0 million, or $0.05 per diluted share, for the third quarter of 2016, and GAAP net income of $7.7 million, or $0.21 per diluted share, for the fourth quarter of 2015.

[0000926326-17-000008:8k_2_02:12]
GAAP net income for the year ended December 31, 2016 was $0.6 million, or $0.02 per diluted share. GAAP net income was $30.8 million, or $0.84 per diluted share, for the year ended December 31, 2015, which includes a $3.4 million gain on business combination of an equity investment.

[0000926326-17-000008:8k_2_02:13]
Non-GAAP results:  Non-GAAP revenue for the fourth quarter of 2016 was $174.6 million, down $4.8 million, or 2.7% from the third quarter of 2016, and up $44.3 million or 34.0% from the fourth quarter of 2015.  Non-GAAP revenue for the twelve months ended December 31, 2016 was $703.3 million, up $218.7 million, or 45.1% from December 31, 2015.

[0000926326-17-000008:8k_2_02:14]
Non-GAAP net income for the fourth quarter of 2016 was $13.8 million, or $0.37 per diluted share. This compares to non-GAAP net income of $14.9 million, or $0.40 per diluted share, for the third quarter of 2016 and $14.4 million, or $0.40 per diluted share, for the fourth quarter of 2015.

[0000926326-17-000008:8k_2_02:15]
Non-GAAP net income for the year ended December 31, 2016 was $55.7 million, or $1.51 per diluted share.  This compares to non-GAAP net income of was $48.7 million, or $1.33 per diluted share for the year ended December 31, 2015.  Non-GAAP net income for each period presented excludes, when applicable, the effect of stock-based compensation expense, amortization expense for all intangible assets associated with past acquisitions, acquisition expenses, fair value adjustments related to business acquisition, amortization of debt issuance cost, and gain on business combination of an equity investment in Avantec.

[0000926326-17-000008:8k_2_02:16]
Total bookings for the year ended December 31, 2016 were $541 million compared to total bookings for the year ended December 31, 2015 of $392 million.

[0000926326-17-000008:8k_2_02:17]
"2016 was a successful year for Omnicell with record bookings, revenues and earnings," said Randall Lipps, Omnicell president, CEO and chairman. "We are proud of the company’s financial performance and our strategic execution aimed at supporting health systems in achieving their patient safety, operational and financial goals.''

[0000926326-17-000008:8k_2_02:18]
"Our customers tell us medication management is central to their patient safety and operational strategies.  Our recent wins showcase the strength of our comprehensive and innovative solutions that enable us to be a vital partner.  The company is well positioned to take advantage of the great opportunities ahead in 2017,'' Mr. Lipps added.

[0000926326-17-000008:8k_2_02:19]
2017 Guidance:

[0000926326-17-000008:8k_2_02:20]
The fiscal year 2017 financial results are expected to be characterized by two distinct phases, as revenue and profitability are expected to be impacted by the Company's XT Series product introduction transition and manufacturing ramp up:

[0000926326-17-000008:8k_2_02:21]
| A. | The first phase encompasses the introduction and ramp up of manufacturing for the XT Series in the first quarter of 2017, with anticipated dynamics including: |

[0000926326-17-000008:8k_2_02:22]
| • | Conversion of G4 product bookings and backlog, and sales quotes to XT Series bookings; |

[0000926326-17-000008:8k_2_02:23]
| • | XT Series manufacturing volume ramp up; |

[0000926326-17-000008:8k_2_02:24]
| • | Installation of the XT Series product at launch customers; |

[0000926326-17-000008:8k_2_02:25]
| • | XT Series manufacturing ramp up cost; |

[0000926326-17-000008:8k_2_02:26]
| • | Reduction of workforce by approximately 100 positions, and the closure of the Company's Tennessee office; and |

[0000926326-17-000008:8k_2_02:27]
| • | General hiring delays |

[0000926326-17-000008:8k_2_02:28]
For the first quarter of 2017, the Company expects non-GAAP revenue to be between $150 million and $155 million. Omnicell expects first quarter of 2017 non-GAAP earnings to be between $0.00 and $0.04 per share.

[0000926326-17-000008:8k_2_02:29]
B.     The second phase encompasses the acceleration of installations and conversion of product backlog into revenue during the second through the fourth quarters of 2017, with anticipated dynamics including:

[0000926326-17-000008:8k_2_02:30]
| • | Launch of Acudose on XT Series; |

[0000926326-17-000008:8k_2_02:31]
| • | Improvement of XT Series production cost; |

[0000926326-17-000008:8k_2_02:32]
| • | Above 20% growth rate for product bookings; |

[0000926326-17-000008:8k_2_02:33]
| • | Return to 8%-12% revenue organic growth range rate; |

[0000926326-17-000008:8k_2_02:34]
| • | XT Series cost of sales reductions as revenue ramps up; |

[0000926326-17-000008:8k_2_02:35]
| • | Continuation of cost reduction initiatives; and |

[0000926326-17-000008:8k_2_02:36]
| • | Implement development and manufacturing Centers of Excellence (''COEs") |

[0000926326-17-000008:8k_2_02:37]
As part of the next phase of the integration of the acquisition of Aesynt the Company is creating the following Centers of Excellence (“COEs”) for product development, engineering, and manufacturing:

[0000926326-17-000008:8k_2_02:38]
| • | the Point of Use COE in California; |

[0000926326-17-000008:8k_2_02:39]
| • | the Robotics and Central Pharmacy COE in Pittsburgh, Pennsylvania; and |

[0000926326-17-000008:8k_2_02:40]
| • | the Medication Adherence Consumables COE in St. Petersburg Florida |

[0000926326-17-000008:8k_2_02:41]
The Company today announced a reduction of its workforce by approximately 100 full-time employees, or about 4% of its total headcount, anticipated to be completed in the first quarter of 2017. This reduction in force includes the closure of the Company’s Nashville, Tennessee office, anticipated in the first quarter of 2017, and the closure of the Company’s manufacturing facility in Slovenia, anticipated in the third quarter of 2017. The Company expects to incur approximately $4 million of restructuring expenses in connection with the reduction in force for one-time termination benefits, comprised principally of severance.  The Company expects to incur approximately an additional $4 million of restructuring expenses in connection with facility leases, dilapidation, and other one-time facilities related expense.

[0000926326-17-000008:8k_2_02:42]
For the second through the fourth quarters of 2017, the Company expects non-GAAP revenue to be between $590 million and $605 million representing 8%-12% growth both on a reported and organic basis. For the second through fourth quarters of 2017, the Company expects non-GAAP earnings to be between $1.32 and $1.38 per share, representing above 15% growth, both on a reported and organic basis.

[0000926326-17-000008:8k_2_02:43]
For the year 2017, Omnicell expects product bookings to be between $570 million and $590 million. The Company expects non-GAAP revenue to be between $740 million and $760 million, and non-GAAP earnings to be between $1.32 and $1.42 per share.

[0000926326-17-000008:8k_2_02:44]
The table below summarizes Omnicell's 2017 guidance for the two distinct phases outlined above:

[0000926326-17-000008:8k_2_02:45]
|  | Q1'17 | Q2'17 through Q4'17 | Total Year 2017 |
| Product Bookings | <0% year over year growth | >20% year over year growth | $570 million - $590 million |
| Non-GAAP Revenue | $150 million - $155 million | $590 million - $605 million | $740 million - $760 million |
| Non-GAAP EPS | $0.00 - $0.04 | $1.32 - $1.38 | $1.32 - $1.42 |

[0000926326-17-000008:8k_2_02:46]
Reporting Segments

[0000926326-17-000008:8k_2_02:47]
The Company's Chief Operating Decision Maker (''CODM") is its Chief Executive Officer. The CODM allocates resources and evaluates the performance of the Company's segments using information about its revenues, gross profit, and income from operations. Such evaluation excludes general corporate-level costs that are not specific to either of the reportable segments and are managed separately at the corporate level. Corporate-level costs include expenses related to executive management, finance and accounting, human resources, legal, training and development, and certain administrative expenses. The operating results of the acquired Aesynt business acquired in the first quarter of 2016 are included in the Company's Automation and Analytics reportable segment. The operating results of the Ateb business acquired in the fourth quarter of 2016 are included in the Company's Medication Adherence reportable segment.

[0000926326-17-000008:8k_2_02:48]
Omnicell Conference Call Information

[0000926326-17-000008:8k_2_02:49]
Omnicell will hold a conference call today, Wednesday, February 15, 2017 at 1:30 p.m. PT to discuss fourth quarter financial results. The conference call can be monitored by dialing 1-800-696-5518 within the U.S. or 1-706-758-4883 for all other locations. The Conference ID # is 36561632. Internet users can access the conference call at http://ir.omnicell.com/events.cfm. A replay of the call will be available today at approximately 4:30 p.m. PT and will be available until 11:59 p.m. PT on

[0000926326-17-000008:8k_2_02:50]
March 29, 2017. The replay access numbers are 1-855-859-2056 within the U.S. and 1-404-537-3406 for all other locations, Conference ID # is 36561632.

[0000926326-17-000008:8k_2_02:51]
About Omnicell

[0000926326-17-000008:8k_2_02:52]
Since 1992, Omnicell (NASDAQ: OMCL) has been inspired to create safer and more efficient ways to manage medications and supplies across all care settings. As a leader in medication and supply dispensing automation, central pharmacy automation, IV robotics, analytics software, and medication adherence and packaging systems, Omnicell is focused on improving care across the entire healthcare continuum-from the acute care hospital setting, to post-acute skilled nursing and long-term care facilities, to the patient’s home.

[0000926326-17-000008:8k_2_02:53]
Over 4,000 customers worldwide use Omnicell® automation and analytics solutions to increase operational efficiency, reduce medication errors, deliver actionable intelligence and improve patient safety.

[0000926326-17-000008:8k_2_02:54]
Omnicell’s innovative medication adherence solutions, used by over 32,000 institutional and retail pharmacies in North America and the United Kingdom, are designed to improve patient adherence to prescriptions, helping to reduce costly hospital readmissions.

[0000926326-17-000008:8k_2_02:55]
Recent Omnicell acquisitions, including Ateb, add distinct capabilities, particularly in central pharmacy, IV robotics, and pharmacy software, creating the broadest medication management product portfolio in the industry.

[0000926326-17-000008:8k_2_02:56]
For more information about Omnicell, Inc. please visit www.omnicell.com.

[0000926326-17-000008:8k_2_02:57]
Forward-Looking Statements

[0000926326-17-000008:8k_2_02:58]
growth and acceptance of our products and services, including competitive conversions, and to growth of the clinical automation and workflow automation market generally, the potential of increasing competition, potential regulatory changes, the ability of the company to improve sales productivity to grow product bookings, to develop new products and to acquire and successfully integrate companies. These and other risks and uncertainties are described more fully in Omnicell’s most recent filings with the Securities and Exchange Commission. Prospective investors are cautioned not to place undue reliance on forward-looking statements. All forward-looking statements contained in this press release speak only as of the date on which they were made. Omnicell undertakes no obligation to update such statements to reflect events that occur or circumstances that exist after the date on which they were made.

[0000926326-17-000008:8k_2_02:59]
Use of Non-GAAP Financial Information

[0000926326-17-000008:8k_2_02:60]
This press release contains financial measures that are not calculated in accordance with U.S. generally accepted accounting principles (GAAP). Our management evaluates and makes operating decisions using various performance measures. In addition to Omnicell’s GAAP results, we also consider non-GAAP revenue, non-GAAP gross profit, non-GAAP operating expenses, non-GAAP net income, and non-GAAP net income per diluted share. Additionally, we calculate Adjusted EBITDA (another non-GAAP measure) by means of adjustments to GAAP Net Income. These non-GAAP results should not be considered as an alternative to gross profit, operating expenses, net income, net income per diluted share, or any other performance measure derived in accordance with GAAP. We present these non-GAAP results because we consider them to be important supplemental measures of Omnicell’s performance.

[0000926326-17-000008:8k_2_02:61]
Our non-GAAP revenue, non-GAAP gross profit, non-GAAP operating expenses, non-GAAP net income and non-GAAP net income per diluted share are exclusive of certain items to facilitate management’s review of the comparability of Omnicell’s core operating results on a period to period basis because such items are not related to Omnicell’s ongoing core operating results as viewed by management. We define our “core operating results” as those revenues recorded in a particular period and the expenses incurred within that period that directly drive operating income in that period. Management uses these non-GAAP financial measures in making operating decisions because, in addition to meaningful supplemental information regarding operating performance, the measures give us a better understanding of how we should invest in research and development, fund infrastructure growth and evaluate the effectiveness of marketing strategies. In calculating the above non-GAAP results, management specifically adjusted for the following excluded items:

[0000926326-17-000008:8k_2_02:62]
a)  Stock-based compensation expense. We excluded from our non-GAAP results the expense related to equity-based compensation plans as they represent expenses that do not require cash settlement from Omnicell.

[0000926326-17-000008:8k_2_02:63]
b) Intangible assets amortization from business acquisitions. We excluded from our non-GAAP results the intangible assets amortization expense resulting from our past acquisitions. These non-cash charges are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results.

[0000926326-17-000008:8k_2_02:64]
c) Amortization of debt issuance cost. Debt issuance cost represents costs associated with the issuance of Term Loan and Revolving Line of Credit facilities. The cost includes underwriting fees, original issue discount, ticking fee, and legal fees. This non-cash expense is not considered by management to reflect the core cash-generating performance of the business and therefore is excluded from our non-GAAP results.

[0000926326-17-000008:8k_2_02:65]
d) Acquisition accounting impact related to deferred revenue. In connection with acquisition of Aesynt, business combination rules require us to account for the fair values of arrangements for which acceptance has not been obtained, and post installation support has not been provided in our purchase accounting. The non-GAAP adjustment to our revenues is intended to include the full amounts of such revenues. We believe the adjustment to these revenues is useful as a measure of the ongoing performance of our business.

[0000926326-17-000008:8k_2_02:66]
e) Inventory fair value adjustments. In connection with acquisition of Aesynt, business combination rules require us to account for the fair values of inventory acquired in our purchase accounting. The non-GAAP adjustment to the cost of revenues is intended to include the impact of such adjustment. We believe the adjustment is useful as a measure of the ongoing performance of our business.

[0000926326-17-000008:8k_2_02:67]
f) Acquisition related expenses. We excluded from the non-GAAP results the expenses which are related to the recent acquisitions. These expenses are unrelated to our ongoing operations and we do not expect them to occur in the ordinary course of business. We believe that excluding these acquisition related expenses provides more meaningful comparisons of the financial results to our historical operations and forward looking guidance and the financial results of less acquisitive peer companies.

[0000926326-17-000008:8k_2_02:68]
g) Gain on business combination of an equity investment. We excluded from our non-GAAP results the gain on a minority equity investment in a private company, Avantec, which was recognized in relation to the acquisition by Omnicell of the remainder of the

[0000926326-17-000008:8k_2_02:69]
company. This non-cash gain is not considered by management to reflect the core cash-generating performance of the business and therefore is excluded from our non-GAAP results.

[0000926326-17-000008:8k_2_02:70]
Management adjusts for the above items because management believes that, in general, these items possess one or more of the following characteristics: their magnitude and timing is largely outside of Omnicell’s control; they are unrelated to the ongoing operation of the business in the ordinary course; they are unusual and we do not expect them to occur in the ordinary course of business; or they are non-operational, or non-cash expenses involving stock compensation plans.

[0000926326-17-000008:8k_2_02:71]
We believe that the presentation of these non-GAAP financial measures is warranted for several reasons:

[0000926326-17-000008:8k_2_02:72]
1) Such non-GAAP financial measures provide an additional analytical tool for understanding Omnicell’s financial performance by excluding the impact of items which may obscure trends in the core operating results of the business;

[0000926326-17-000008:8k_2_02:73]
2) Since we have historically reported non-GAAP results to the investment community, we believe the inclusion of non-GAAP numbers provides consistency and enhances investors’ ability to compare our performance across financial reporting periods;

[0000926326-17-000008:8k_2_02:74]
3) These non-GAAP financial measures are employed by Omnicell’s management in its own evaluation of performance and are utilized in financial and operational decision making processes, such as budget planning and forecasting; and

[0000926326-17-000008:8k_2_02:75]
4) These non-GAAP financial measures facilitate comparisons to the operating results of other companies in our industry, which use similar financial measures to supplement their GAAP results, thus enhancing the perspective of investors who wish to utilize such comparisons in their analysis of our performance.

[0000926326-17-000008:8k_2_02:76]
Set forth below are additional reasons why share-based compensation expense is excluded from our non-GAAP financial measures:

[0000926326-17-000008:8k_2_02:77]
i)  While share-based compensation calculated in accordance with ASC 718 constitutes an ongoing and recurring expense of Omnicell, it is not an expense that requires cash settlement by Omnicell. We therefore exclude these charges for purposes of evaluating core operating results. Thus, our non-GAAP measurements are presented exclusive of stock-based compensation expense to assist management and investors in evaluating our core operating results.

[0000926326-17-000008:8k_2_02:78]
ii) We present ASC 718 share-based payment compensation expense in our reconciliation of non-GAAP financial measures on a pre-tax basis because the exact tax differences related to the timing and deductibility of share-based compensation, under ASC 718 are dependent upon the trading price of Omnicell’s common stock and the timing and exercise by employees of their stock options. As a result of these timing and market uncertainties the tax effect related to share-based compensation expense would be inconsistent in amount and frequency and is therefore excluded from our non-GAAP results.

[0000926326-17-000008:8k_2_02:79]
Our Adjusted EBITDA calculation is defined as earnings before interest income and expense, taxes, depreciation and amortization, and non-cash expenses, including ASC 718 stock compensation expense, as well as certain non-GAAP adjustments.

[0000926326-17-000008:8k_2_02:80]
As stated above, we present non-GAAP financial measures because we consider them to be important supplemental measures of performance. However, non-GAAP financial measures have limitations as an analytical tool and should not be considered in isolation or as a substitute for Omnicell’s GAAP results. In the future, we expect to incur expenses similar to certain of the non-GAAP adjustments described above and expect to continue reporting non-GAAP financial measures excluding such items. Some of the limitations in relying on non-GAAP financial measures are:

[0000926326-17-000008:8k_2_02:81]
· Omnicell’s stock option and stock purchase plans are important components of incentive compensation arrangements and will be reflected as expenses in Omnicell’s GAAP results for the foreseeable future under ASC 718.

[0000926326-17-000008:8k_2_02:82]
· Other companies, including companies in Omnicell’s industry, may calculate non-GAAP financial measures differently than Omnicell, limiting their usefulness as a comparative measure.

[0000926326-17-000008:8k_2_02:83]
Pursuant to the requirements of SEC Regulation G, a detailed reconciliation between Omnicell’s non-GAAP and GAAP financial results is set forth in the financial tables at the end of this press release. Investors are advised to carefully review and consider this information strictly as a supplement to the GAAP results that are contained in this press release and in Omnicell’s SEC filings.

[0000926326-17-000008:8k_2_02:84]
5

[0000926326-17-000008:8k_2_02:85]
Omnicell, Inc.

[0000926326-17-000008:8k_2_02:86]
Condensed Consolidated Statements of Operations

[0000926326-17-000008:8k_2_02:87]
(Unaudited, in thousands, except per share data)

[0000926326-17-000008:8k_2_02:88]
|  | Three Months Ended |  | Years Ended |
|  | December 31, 2016 |  | September 30, 2016 |  | December 31, 2015 |  | December 31, 2016 |  | December 31, 2015 |
| Revenues: |  |  |  |  |  |  |  |  |  |
| Product | $ | 125,753 |  |  | $ | 133,621 |  |  | $ | 104,193 |  |  | $ | 517,944 |  |  | $ | 388,397 |  |
| Services and other revenues | 46,221 |  |  | 43,116 |  |  | 26,123 |  |  | 174,679 |  |  | 96,162 |  |
| Total revenues | 171,974 |  |  | 176,737 |  |  | 130,316 |  |  | 692,623 |  |  | 484,559 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |
| Cost of product revenues | 78,024 |  |  | 76,188 |  |  | 55,099 |  |  | 302,437 |  |  | 198,418 |  |
| Cost of services and other revenues | 19,621 |  |  | 19,041 |  |  | 10,137 |  |  | 76,386 |  |  | 38,211 |  |
| Total cost of revenues | 97,645 |  |  | 95,229 |  |  | 65,236 |  |  | 378,823 |  |  | 236,629 |  |
| Gross profit | 74,329 |  |  | 81,508 |  |  | 65,080 |  |  | 313,800 |  |  | 247,930 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | 14,902 |  |  | 15,264 |  |  | 9,219 |  |  | 57,799 |  |  | 35,160 |  |
| Selling, general and administrative | 59,608 |  |  | 61,316 |  |  | 43,891 |  |  | 249,520 |  |  | 167,581 |  |
| Gain on business combination | — |  |  | — |  |  | — |  |  | — |  |  | (3,443 | ) |
| Total operating expenses | 74,510 |  |  | 76,580 |  |  | 53,110 |  |  | 307,319 |  |  | 199,298 |  |
| Income (loss) from operations | (181 | ) |  | 4,928 |  |  | 11,970 |  |  | 6,481 |  |  | 48,632 |  |
| Interest and other income (expense), net | (1,656 | ) |  | (2,721 | ) |  | (753 | ) |  | (8,429 | ) |  | (2,388 | ) |
| Income (loss) before provision for income taxes | (1,837 | ) |  | 2,207 |  |  | 11,217 |  |  | (1,948 | ) |  | 46,244 |  |
| Provision (benefit) for income taxes | (1,994 | ) |  | 224 |  |  | 3,562 |  |  | (2,551 | ) |  | 15,484 |  |
| Net income | $ | 157 |  |  | $ | 1,983 |  |  | $ | 7,655 |  |  | $ | 603 |  |  | $ | 30,760 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |
| Basic | $ | — |  |  | $ | 0.05 |  |  | $ | 0.22 |  |  | $ | 0.02 |  |  | $ | 0.86 |  |
| Diluted | $ | — |  |  | $ | 0.05 |  |  | $ | 0.21 |  |  | $ | 0.02 |  |  | $ | 0.84 |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |  |  |
| Basic | 36,553 |  |  | 36,332 |  |  | 35,482 |  |  | 36,156 |  |  | 35,857 |  |
| Diluted | 37,256 |  |  | 37,079 |  |  | 36,172 |  |  | 36,864 |  |  | 36,718 |  |

[0000926326-17-000008:8k_2_02:89]
6

[0000926326-17-000008:8k_2_02:90]
Omnicell, Inc.

[0000926326-17-000008:8k_2_02:91]
Condensed Consolidated Balance Sheets

[0000926326-17-000008:8k_2_02:92]
(Unaudited, in thousands)

[0000926326-17-000008:8k_2_02:93]
|  | December 31, 2016 |  | December 31, 2015 |
| ASSETS |
| Current assets: |  |  |  |  |
| Cash and cash equivalents | $ | 54,488 |  |  | $ | 82,217 |  |
| Accounts receivable, net | 150,303 |  |  | 107,957 |  |
| Inventories | 69,297 |  |  | 46,594 |  |
| Prepaid expenses | 28,646 |  |  | 19,586 |  |
| Other current assets | 12,674 |  |  | 7,774 |  |
| Total current assets | 315,408 |  |  | 264,128 |  |
| Property and equipment, net | 42,011 |  |  | 32,309 |  |
| Long-term investment in sales-type leases, net | 20,585 |  |  | 14,484 |  |
| Goodwill | 327,724 |  |  | 147,906 |  |
| Intangible assets, net | 190,283 |  |  | 89,665 |  |
| Long-term deferred tax assets | 4,041 |  |  | 2,361 |  |
| Other long-term assets | 35,051 |  |  | 27,894 |  |
| Total assets | $ | 935,103 |  |  | $ | 578,747 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |
| Accounts payable | $ | 27,069 |  |  | $ | 22,646 |  |
| Accrued compensation | 26,722 |  |  | 18,195 |  |
| Accrued liabilities | 31,195 |  |  | 30,133 |  |
| Long-term debt, current portion, net | 8,410 |  |  | — |  |
| Deferred revenue, net | 87,516 |  |  | 53,656 |  |
| Total current liabilities | 180,912 |  |  | 124,630 |  |
| Long-term, deferred revenue | 17,051 |  |  | 17,975 |  |
| Long-term deferred tax liabilities | 51,592 |  |  | 21,822 |  |
| Other long-term liabilities | 8,210 |  |  | 11,932 |  |
| Long-term debt, net | 245,731 |  |  | — |  |
| Total liabilities | 503,496 |  |  | 176,359 |  |
| Stockholders’ equity: |  |  |  |  |  |
| Total stockholders’ equity | 431,607 |  |  | 402,388 |  |
| Total liabilities and stockholders’ equity | $ | 935,103 |  |  | $ | 578,747 |  |

[0000926326-17-000008:8k_2_02:94]
Omnicell, Inc.

[0000926326-17-000008:8k_2_02:95]
Condensed Consolidated Statements of Cash Flows

[0000926326-17-000008:8k_2_02:96]
(Unaudited, in thousands)

[0000926326-17-000008:8k_2_02:97]
|  | Years Ended |
|  | 2016 |  | 2015 |
| Operating Activities |  |  |  |
| Net income | $ | 603 |  |  | $ | 30,760 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 58,362 |  |  | 25,639 |  |
| Loss on disposal of fixed assets | 35 |  |  | 238 |  |
| Gain on business combination | — |  |  | (3,443 | ) |
| Gain related to contingent liability | (600 | ) |  | — |  |
| Share-based compensation expense | 19,500 |  |  | 14,921 |  |
| Income tax benefits from employee stock plans | 1,702 |  |  | 4,535 |  |
| Excess tax benefits from employee stock plans | (1,963 | ) |  | (4,724 | ) |
| Deferred income taxes | (10,882 | ) |  | (1,092 | ) |
| Amortization of debt financing fees | 1,590 |  |  | — |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable | 8,047 |  |  | (17,941 | ) |
| Inventories | (3,362 | ) |  | (10,032 | ) |
| Prepaid expenses | (4,321 | ) |  | 4,049 |  |
| Other current assets | (1,093 | ) |  | 638 |  |
| Investment in sales-type leases | (9,639 | ) |  | (4,661 | ) |
| Other long-term assets | 2,043 |  |  | 496 |  |
| Accounts payable | (4,963 | ) |  | (2,841 | ) |
| Accrued compensation | (2,052 | ) |  | (2,032 | ) |
| Accrued liabilities | (3,287 | ) |  | 5,456 |  |
| Deferred revenue | 4,480 |  |  | (5,521 | ) |
| Other long-term liabilities | (6,263 | ) |  | (683 | ) |
| Net cash provided by operating activities | 47,937 |  |  | 33,762 |  |
| Investing Activities |  |  |  |
| Purchase of intangible assets, intellectual property and patents | (1,372 | ) |  | (415 | ) |
| Software development for external use | (14,348 | ) |  | (12,132 | ) |
| Purchases of property and equipment | (13,445 | ) |  | (7,542 | ) |
| Business acquisitions, net of cash acquired | (312,158 | ) |  | (25,507 | ) |
| Net cash used in investing activities | (341,323 | ) |  | (45,596 | ) |
| Financing Activities |  |  |  |
| Proceeds from debt, net | 287,051 |  |  | — |  |
| Repayment of debt and revolving credit facility | (34,500 | ) |  | — |  |
| Payment for contingent consideration | (3,000 | ) |  | — |  |
| Proceeds from issuances under stock-based compensation plans | 17,691 |  |  | 17,091 |  |
| Employees' taxes paid related to restricted stock units | (3,490 | ) |  | (3,627 | ) |
| Excess tax benefits from employee stock plans | 1,963 |  |  | 4,724 |  |
| Common stock repurchases | — |  |  | (50,021 | ) |
| Net cash provided by (used in) financing activities | 265,715 |  |  | (31,833 | ) |
| Effect of exchange rate changes on cash and cash equivalents | (58 | ) |  | (4 | ) |
| Net decrease in cash and cash equivalents | (27,729 | ) |  | (43,671 | ) |
| Cash and cash equivalents at beginning of period | 82,217 |  |  | 125,888 |  |
| Cash and cash equivalents at end of period | $ | 54,488 |  |  | $ | 82,217 |  |

[0000926326-17-000008:8k_2_02:98]
8

[0000926326-17-000008:8k_2_02:99]
Omnicell, Inc.

[0000926326-17-000008:8k_2_02:100]
Reconciliation of GAAP to Non-GAAP

[0000926326-17-000008:8k_2_02:101]
(Unaudited, in thousands, except per share data and percentages)

[0000926326-17-000008:8k_2_02:102]
|  |  |  |  |  |  | Three Months Ended |  | Twelve Months Ended |
|  |  |  |  |  |  | December 31, 2016 |  | September 30, 2016 |  | December 31, 2015 |  | December 31, 2016 |  | December 31, 2015 |
| Reconciliation of GAAP revenue to non-GAAP revenue: |  |  |  |  |  |  |
| GAAP revenue |  | $ | 171,974 |  |  | $ | 176,737 |  |  | $ | 130,316 |  |  | $ | 692,623 |  |  | $ | 484,559 |  |
|  | Acquisition accounting impact related to deferred revenue | 2,663 |  |  | 2,663 |  |  | — |  |  | 10,652 |  |  | — |  |
| Non-GAAP revenue | $ | 174,637 |  |  | $ | 179,400 |  |  | $ | 130,316 |  |  | $ | 703,275 |  |  | $ | 484,559 |  |
| Reconciliation of GAAP gross profit to non-GAAP gross profit: |  |  |  |  |  |  |
| GAAP gross profit | $ | 74,329 |  |  | $ | 81,508 |  |  | $ | 65,080 |  |  | $ | 313,800 |  |  | $ | 247,930 |  |
| GAAP gross margin | 43.2% |  | 46.1% |  | 49.9% |  | 45.3% |  | 51.2% |
|  | Share-based compensation expense | 776 |  |  | 628 |  |  | 481 |  |  | 2,596 |  |  | 2,111 |  |
|  | Amortization of acquired intangibles | 5,266 |  |  | 5,199 |  |  | 547 |  |  | 20,890 |  |  | 2,016 |  |
|  | Acquisition accounting impact related to deferred revenue | 2,663 |  |  | 2,663 |  |  | — |  |  | 10,652 |  |  | — |  |
|  | Inventory fair value adjustments | 921 |  |  | 920 |  |  | — |  |  | 3,682 |  |  | — |  |
|  | Acquisition related expenses | 5 |  |  | 44 |  |  | — |  |  | 277 |  |  | — |  |
| Non-GAAP gross profit | $ | 83,960 |  |  | $ | 90,962 |  |  | $ | 66,108 |  |  | $ | 351,897 |  |  | $ | 252,057 |  |
| Non-GAAP gross margin | 48.1% |  | 50.7% |  | 50.7% |  | 50.0% |  | 52.0% |
| Reconciliation of GAAP operating expenses to non-GAAP operating expenses: |  |  |  |  |
| GAAP operating expenses | $ | 74,510 |  |  | $ | 76,580 |  |  | $ | 53,110 |  |  | $ | 307,319 |  |  | $ | 199,298 |  |
| GAAP operating expenses % to total revenue |  | 43.3% |  | 43.3% |  | 40.8% |  | 44.4% |  | 41.1% |
|  | Share-based compensation expense | (4,663 | ) |  | (4,049 | ) |  | (3,173 | ) |  | (16,904 | ) |  | (12,810 | ) |
|  | Amortization of acquired intangibles | (3,752 | ) |  | (3,714 | ) |  | (1,354 | ) |  | (15,251 | ) |  | (4,904 | ) |
|  | Acquisition related expenses | (829 | ) |  | (342 | ) |  | (2,898 | ) |  | (5,753 | ) |  | (2,898 | ) |
|  | Gain on business combination | — |  |  | — |  |  | — |  |  | — |  |  | 3,443 |  |
| Non-GAAP operating expenses | $ | 65,266 |  |  | $ | 68,475 |  |  | $ | 45,685 |  |  | $ | 269,411 |  |  | $ | 182,129 |  |
| Non-GAAP operating expenses % to total revenue | 37.4% |  | 38.2% |  | 35.1% |  | 38.3% |  | 37.6% |

[0000926326-17-000008:8k_2_02:103]
|  |  |  |  |  |  | Three Months Ended |  | Twelve Months Ended |
|  |  |  |  |  |  | December 31, 2016 |  | September 30, 2016 |  | December 31, 2015 |  | December 31, 2016 |  | December 31, 2015 |
| Reconciliation of GAAP income (loss) from operations to non-GAAP income from operations: |  |  |  |  |
| GAAP income (loss) from operations |  | $ | (181 | ) |  | $ | 4,928 |  |  | $ | 11,970 |  |  | $ | 6,481 |  |  | $ | 48,632 |  |
| GAAP operating income % to total revenue |  | (0.1)% |  | 2.8% |  | 9.2% |  | 0.9% |  | 10.0% |
|  | Share-based compensation expense | 5,438 |  |  | 4,677 |  |  | 3,654 |  |  | 19,500 |  |  | 14,921 |  |
|  | Amortization of acquired intangibles | 9,017 |  |  | 8,913 |  |  | 1,901 |  |  | 36,141 |  |  | 6,920 |  |
|  | Acquisition accounting impact related to deferred revenue | 2,663 |  |  | 2,663 |  |  | — |  |  | 10,652 |  |  | — |  |
|  | Inventory fair value adjustments | 921 |  |  | 920 |  |  | — |  |  | 3,682 |  |  | — |  |
|  | Acquisition related expenses | 834 |  |  | 386 |  |  | 2,898 |  |  | 6,029 |  |  | 2,898 |  |
|  | Gain on business combination | — |  |  | — |  |  | — |  |  | — |  |  | (3,443 | ) |
| Non-GAAP income from operations | $ | 18,692 |  |  | $ | 22,487 |  |  | $ | 20,423 |  |  | $ | 82,485 |  |  | $ | 69,928 |  |
| Non-GAAP operating income % to total Non-GAAP revenue | 10.7% |  | 12.5% |  | 15.7% |  | 11.7% |  | 14.4% |
| Reconciliation of GAAP net income to non-GAAP net income: |  |  |  |  |  |  |
| GAAP net income | $ | 157 |  |  | $ | 1,983 |  |  | $ | 7,655 |  |  | $ | 603 |  |  | $ | 30,760 |  |
|  | Share-based compensation expense | 5,438 |  |  | 4,677 |  |  | 3,654 |  |  | 19,500 |  |  | 14,921 |  |
|  | Amortization of acquired intangibles | 9,017 |  |  | 8,913 |  |  | 1,901 |  |  | 36,141 |  |  | 6,920 |  |
|  | Acquisition accounting impact related to deferred revenue | 2,663 |  |  | 2,663 |  |  | — |  |  | 10,652 |  |  | — |  |
|  | Inventory fair value adjustments | 921 |  |  | 920 |  |  | — |  |  | 3,682 |  |  | — |  |
|  | Acquisition related expenses | 632 |  |  | 783 |  |  | 2,898 |  |  | 7,019 |  |  | 2,898 |  |
|  | Gain on business combination | — |  |  | — |  |  | — |  |  | — |  |  | (3,443 | ) |
|  | Tax effect of the adjustments above(a) | (5,031 | ) |  | (5,047 | ) |  | (1,665 | ) |  | (21,850 | ) |  | (3,368 | ) |
| Non-GAAP net income | $ | 13,797 |  |  | $ | 14,892 |  |  | $ | 14,443 |  |  | $ | 55,747 |  |  | $ | 48,688 |  |
| Reconciliation of GAAP net income per share - diluted to non-GAAP net income per share - diluted: |  |  |
| Shares - diluted GAAP | 37,256 |  |  | 37,079 |  |  | 36,172 |  |  | 36,864 |  |  | 36,718 |  |
| Shares - diluted Non-GAAP | 37,256 |  |  | 37,079 |  |  | 36,172 |  |  | 36,864 |  |  | 36,718 |  |
| GAAP net income per share - diluted | $ | — |  |  | $ | 0.05 |  |  | $ | 0.21 |  |  | $ | 0.02 |  |  | $ | 0.84 |  |
|  | Share-based compensation expense | 0.15 |  |  | 0.13 |  |  | 0.10 |  |  | 0.53 |  |  | 0.41 |  |
|  | Amortization of acquired intangibles | 0.24 |  |  | 0.24 |  |  | 0.05 |  |  | 0.98 |  |  | 0.18 |  |
|  | Acquisition accounting impact related to deferred revenue | 0.07 |  |  | 0.07 |  |  | — |  |  | 0.29 |  |  | — |  |
|  | Inventory fair value adjustments | 0.02 |  |  | 0.02 |  |  | — |  |  | 0.10 |  |  | — |  |
|  | Acquisition related expenses | 0.02 |  |  | 0.02 |  |  | 0.08 |  |  | 0.19 |  |  | 0.08 |  |
|  | Gain on business combination | — |  |  | — |  |  | — |  |  | — |  |  | (0.09 | ) |
|  | Tax effect of the adjustments above(a) | (0.13 | ) |  | (0.13 | ) |  | (0.04 | ) |  | (0.60 | ) |  | (0.09 | ) |
| Non-GAAP net income per share - diluted | $ | 0.37 |  |  | $ | 0.40 |  |  | $ | 0.40 |  |  | $ | 1.51 |  |  | $ | 1.33 |  |
| Reconciliation of GAAP net income to non-GAAP Adjusted EBITDA: |  |  |  |  |  |  |
| GAAP net income | $ | 157 |  |  | $ | 1,983 |  |  | $ | 7,655 |  |  | $ | 603 |  |  | $ | 30,760 |  |
|  | Share-based compensation expense | 5,438 |  |  | 4,677 |  |  | 3,654 |  |  | 19,500 |  |  | 14,921 |  |
|  | Interest (income) and expense, net | 998 |  |  | 1,523 |  |  | 89 |  |  | 5,616 |  |  | 410 |  |
|  | Depreciation and amortization expense | 14,457 |  |  | 14,702 |  |  | 7,182 |  |  | 58,362 |  |  | 25,639 |  |
|  | Acquisition accounting impact related to deferred revenue | 2,663 |  |  | 2,663 |  |  | — |  |  | 10,652 |  |  | — |  |
|  | Inventory fair value adjustments | 921 |  |  | 920 |  |  | — |  |  | 3,682 |  |  | — |  |
|  | Acquisition related expenses | 632 |  |  | 783 |  |  | 2,898 |  |  | 7,019 |  |  | 2,898 |  |
|  | Gain on business combination | — |  |  | — |  |  | — |  |  | — |  |  | (3,443 | ) |
|  | Income tax expense (benefit) | (1,994 | ) |  | 224 |  |  | 3,562 |  |  | (2,551 | ) |  | 15,484 |  |
| Non-GAAP Adjusted EBITDA (b) | $ | 23,272 |  |  | $ | 27,475 |  |  | $ | 25,040 |  |  | $ | 102,883 |  |  | $ | 86,669 |  |

[0000926326-17-000008:8k_2_02:104]
_____________________

[0000926326-17-000008:8k_2_02:105]
(a)Tax effects calculated for all adjustments except share-based compensation expense, using the tax rate of 38%.

[0000926326-17-000008:8k_2_02:106]
10

[0000926326-17-000008:8k_2_02:107]
(b)Defined as earnings before interest income and expense, taxes, depreciation and amortization, share-based compensation expense, as well as excluding certain non-GAAP adjustments.

[0000926326-17-000008:8k_2_02:108]
11

[0000926326-17-000008:8k_2_02:109]
Omnicell, Inc.

[0000926326-17-000008:8k_2_02:110]
Segmented Information

[0000926326-17-000008:8k_2_02:111]
(Unaudited, in thousands, except for percentages)

[0000926326-17-000008:8k_2_02:112]
|  | Three Months Ended December 31, 2016 |  | Three Months Ended December 31, 2015 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |  | Automation andAnalytics |  | MedicationAdherence |  | Total |
| Revenues | $ | 143,583 |  |  | $ | 28,391 |  |  | $ | 171,974 |  |  | $ | 105,874 |  |  | $ | 24,442 |  |  | $ | 130,316 |  |
| Cost of revenues | 77,566 |  |  | 20,079 |  |  | 97,645 |  |  | 48,020 |  |  | 17,216 |  |  | 65,236 |  |
| Gross profit | 66,017 |  |  | 8,312 |  |  | 74,329 |  |  | 57,854 |  |  | 7,226 |  |  | 65,080 |  |
| Gross margin % | 46.0% |  | 29.3% |  | 43.2% |  | 54.6% |  | 29.6% |  | 49.9% |
| Operating expenses | 47,402 |  |  | 7,325 |  |  | 54,727 |  |  | 28,889 |  |  | 5,937 |  |  | 34,826 |  |
| Income from segment operations | $ | 18,615 |  |  | $ | 987 |  |  | $ | 19,602 |  |  | $ | 28,965 |  |  | $ | 1,289 |  |  | $ | 30,254 |  |
| Operating margin % | 13.0% |  | 3.5% |  | 11.4% |  | 27.4% |  | 5.3% |  | 23.2% |
| Corporate costs |  |  |  |  | 19,783 |  |  |  |  |  |  | 18,284 |  |
| Income (loss) from operations |  |  |  |  | $ | (181 | ) |  |  |  |  |  | $ | 11,970 |  |

[0000926326-17-000008:8k_2_02:113]
Omnicell, Inc.

[0000926326-17-000008:8k_2_02:114]
Segmented Information

[0000926326-17-000008:8k_2_02:115]
(Unaudited, in thousands, except for percentages)

[0000926326-17-000008:8k_2_02:116]
|  | Year Ended December 31, 2016 |  | Year Ended December 31, 2015 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |  | Automation andAnalytics |  | MedicationAdherence |  | Total |
| Revenues | $ | 593,626 |  |  | $ | 98,997 |  |  | $ | 692,623 |  |  | $ | 390,321 |  |  | $ | 94,238 |  |  | $ | 484,559 |  |
| Cost of revenues | 310,967 |  |  | 67,856 |  |  | 378,823 |  |  | 171,943 |  |  | 64,686 |  |  | 236,629 |  |
| Gross profit | 282,659 |  |  | 31,141 |  |  | 313,800 |  |  | 218,378 |  |  | 29,552 |  |  | 247,930 |  |
| Gross margin % | 47.6% |  | 31.5% |  | 45.3% |  | 55.9% |  | 31.4% |  | 51.2% |
| Operating expenses | 198,511 |  |  | 24,843 |  |  | 223,354 |  |  | 114,084 |  |  | 24,258 |  |  | 138,342 |  |
| Income from segment operations | $ | 84,148 |  |  | $ | 6,298 |  |  | $ | 90,446 |  |  | $ | 104,294 |  |  | $ | 5,294 |  |  | $ | 109,588 |  |
| Operating margin % | 14.2% |  | 6.4% |  | 13.1% |  | 26.7% |  | 5.6% |  | 22.6% |
| Corporate costs |  |  |  |  | 83,965 |  |  |  |  |  |  | 60,956 |  |
| Income from operations |  |  |  |  | $ | 6,481 |  |  |  |  |  |  | $ | 48,632 |  |

[0000926326-17-000008:8k_2_02:117]
13

[0000926326-17-000008:8k_2_02:118]
Omnicell, Inc.

[0000926326-17-000008:8k_2_02:119]
Segment Information Non-GAAP Gross Margin and Non-GAAP Operating Margin

[0000926326-17-000008:8k_2_02:120]
(Unaudited, in thousands, except for percentages)

[0000926326-17-000008:8k_2_02:121]
|  | Three Months Ended December 31, 2016 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |
|  | Amount |  | % of GAAP Revenue |  | % of Non-GAAP Revenue |  | Amount |  | % of GAAP Revenue |  | % of Non-GAAP Revenue |  | Amount |  | % of GAAP Revenue |  | % of Non-GAAP Revenue |
| Revenues | $ | 143,583 |  |  |  |  |  |  | $ | 28,391 |  |  |  |  |  |  | $ | 171,974 |  |  |  |  |  |
| Acquisition accounting impact related to deferred revenue | 2,663 |  |  | 1.9 | % |  | 1.8 | % |  | — |  |  | — | % |  | — | % |  | 2,663 |  |  | 1.5 | % |  | 1.5 | % |
| Non-GAAP Revenues | $ | 146,246 |  |  |  |  |  |  | $ | 28,391 |  |  |  |  |  |  | $ | 174,637 |  |  |  |  |  |
| GAAP Gross profit | $ | 66,017 |  |  | 46.0 | % |  | 45.1 | % |  | $ | 8,312 |  |  | 29.3 | % |  | 29.3 | % |  | $ | 74,329 |  |  | 43.2 | % |  | 42.6 | % |
| Stock-based compensation expense | 668 |  |  | 0.5 | % |  | 0.5 | % |  | 108 |  |  | 0.4 | % |  | 0.4 | % |  | 776 |  |  | 0.5 | % |  | 0.4 | % |
| Amortization expense of acquired intangible assets | 4,820 |  |  | 3.4 | % |  | 3.3 | % |  | 446 |  |  | 1.6 | % |  | 1.6 | % |  | 5,266 |  |  | 3.1 | % |  | 3.0 | % |
| Acquisition accounting impact related to deferred revenue | 2,663 |  |  | 1.9 | % |  | 1.8 | % |  | — |  |  | — | % |  | — | % |  | 2,663 |  |  | 1.5 | % |  | 1.5 | % |
| Inventory fair value adjustments | 921 |  |  | 0.6 | % |  | 0.6 | % |  | — |  |  | — | % |  | — | % |  | 921 |  |  | 0.5 | % |  | 0.5 | % |
| Acquisitions related expenses | 5 |  |  | — | % |  | — | % |  | — |  |  | — | % |  | — | % |  | 5 |  |  | — | % |  | — | % |
| Non-GAAP Gross profit | $ | 75,094 |  |  | 52.3 | % |  | 51.3 | % |  | $ | 8,866 |  |  | 31.2 | % |  | 31.2 | % |  | $ | 83,960 |  |  | 48.8 | % |  | 48.1 | % |
| GAAP Operating income | $ | 18,615 |  |  | 13.0 | % |  | 12.7 | % |  | $ | 988 |  |  | 3.5 | % |  | 3.5 | % |  | $ | 19,603 |  |  | 11.4 | % |  | 11.2 | % |
| Stock-based compensation expense | 2,672 |  |  | 1.9 | % |  | 1.8 | % |  | 270 |  |  | 0.95 | % |  | 1.0 | % |  | 2,942 |  |  | 1.7 | % |  | 1.7 | % |
| Amortization expense of acquired intangible assets | 7,494 |  |  | 5.2 | % |  | 5.1 | % |  | 1,523 |  |  | 5.4 | % |  | 5.4 | % |  | 9,017 |  |  | 5.2 | % |  | 5.2 | % |
| Acquisition accounting impact related to deferred revenue | 2,663 |  |  | 1.9 | % |  | 1.8 | % |  | — |  |  | — | % |  | — | % |  | 2,663 |  |  | 1.5 | % |  | 1.5 | % |
| Inventory fair value adjustments | 921 |  |  | 0.6 | % |  | 0.6 | % |  | — |  |  | — | % |  | — | % |  | 921 |  |  | 0.5 | % |  | 0.5 | % |
| Acquisitions related expenses | 23 |  |  | — | % |  | — | % |  | — |  |  | — | % |  | — | % |  | 23 |  |  | — | % |  | — | % |
| Non-GAAP Operating income | $ | 32,388 |  |  | 22.6 | % |  | 22.1 | % |  | $ | 2,781 |  |  | 9.8 | % |  | 9.8 | % |  | $ | 35,169 |  |  | 20.5 | % |  | 20.1 | % |
| GAAP Corporate costs |  |  |  |  |  |  |  |  |  |  |  |  | $ | 19,784 |  |  | 11.5 | % |  | 11.3 | % |
| Less: Stock-based compensation expense |  |  |  |  |  |  |  |  |  |  |  |  | 2,496 |  |  | 1.5 | % |  | 1.4 | % |
| Less: Acquisition-related expenses |  |  |  |  |  |  |  |  |  |  |  |  | 811 |  |  | 0.5 | % |  | 0.5 | % |
| Non-GAAP Corporate costs |  |  |  |  |  |  |  |  |  |  |  |  | $ | 16,477 |  |  | 9.6 | % |  | 9.4 | % |
| Non-GAAP Income from operations |  |  |  |  |  |  |  |  |  |  |  |  | $ | 18,692 |  |  | 10.9 | % |  | 10.7 | % |

[0000926326-17-000008:8k_2_02:122]
|  | Three Months Ended December 31, 2015 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |
|  | Amount |  | % of GAAP Revenue* |  | Amount |  | % of GAAP Revenue* |  | Amount |  | % of GAAP Revenue* |
| Revenues | $ | 105,874 |  |  |  |  | $ | 24,442 |  |  |  |  | $ | 130,316 |  |  |  |
| GAAP Gross profit | 57,854 |  |  | 54.6 | % |  | 7,226 |  |  | 29.6 | % |  | 65,080 |  |  | 49.9 | % |
| Stock-based compensation expense | 411 |  |  | 0.4 | % |  | 70 |  |  | 0.3 | % |  | 481 |  |  | 0.4 | % |
| Amortization expense of acquired intangible assets | 214 |  |  | 0.2 | % |  | 333 |  |  | 1.4 | % |  | 547 |  |  | 0.4 | % |
| Non-GAAP Gross profit | $ | 58,479 |  |  | 55.2 | % |  | $ | 7,629 |  |  | 31.2 | % |  | $ | 66,108 |  |  | 50.7 | % |
| GAAP Operating income | $ | 28,965 |  |  | 27.4 | % |  | $ | 1,289 |  |  | 5.3 | % |  | $ | 30,254 |  |  | 23.2 | % |
| Stock-based compensation expense | 1,472 |  |  | 1.3 | % |  | 196 |  |  | 0.8 | % |  | 1,668 |  |  | 1.3 | % |
| Amortization expense of acquired intangible assets | 828 |  |  | 0.8 | % |  | 1,072 |  |  | 4.4 | % |  | 1,900 |  |  | 1.5 | % |
| Non-GAAP Operating income | $ | 31,265 |  |  | 29.5 | % |  | $ | 2,557 |  |  | 10.5 | % |  | $ | 33,822 |  |  | 26.0 | % |
| GAAP Corporate costs |  |  |  |  |  |  |  |  | $ | 18,284 |  |  | 14.0 | % |
| Less: Stock-based compensation expense |  |  |  |  |  |  |  |  | 1,986 |  |  | 1.5 | % |
| Less: Acquisition related expenses |  |  |  |  |  |  |  |  | 2,898 |  |  | 2.2 | % |
| Non-GAAP Corporate costs |  |  |  |  |  |  |  |  | $ | 13,400 |  |  | 10.3 | % |
| Non-GAAP Income from operations |  |  |  |  |  |  |  |  | $ | 20,422 |  |  | 15.7 | % |

[0000926326-17-000008:8k_2_02:123]
* For the three months ended December 31, 2015, there were no differences between GAAP and non-GAAP revenues.

[0000926326-17-000008:8k_2_02:124]
15
