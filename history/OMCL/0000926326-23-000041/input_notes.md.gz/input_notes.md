# OMCL notes — 0000926326-23-000041


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000926326-23-000041:notes:1]
[same as prior period, unchanged from 0000926326-23-000031:notes:1]

[0000926326-23-000041:notes:2]
[same as prior period, unchanged from 0000926326-23-000031:notes:2]

[0000926326-23-000041:notes:3]
[same as prior period, unchanged from 0000926326-23-000031:notes:3]

[0000926326-23-000041:notes:4]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of September 30, 2023 and December 31, 2022, the results of operations and comprehensive income (loss) for the three and nine months ended September 30, 2023 and 2022, and cash flows for the nine months ended September 30, 2023 and 2022. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s Annual Report on Form 10-K for the year ended December 31, 2022, filed with the SEC on March 1, 2023, except as discussed in the section entitled “Recently Adopted Authoritative Guidance” below. The Company’s results of operations and comprehensive income (loss) for the three and nine months ended September 30, 2023, and cash flows for the nine months ended September 30, 2023 are not necessarily indicative of results that may be expected for the year ending December 31, 2023, or for any future period.

[0000926326-23-000041:notes:5]
[same as prior period, unchanged from 0000926326-23-000031:notes:5]

[0000926326-23-000041:notes:6]
[same as prior period, unchanged from 0000926326-23-000031:notes:6]

[0000926326-23-000041:notes:7]
[same as prior period, unchanged from 0000926326-23-000031:notes:7]

[0000926326-23-000041:notes:8]
[same as prior period, unchanged from 0000926326-23-000031:notes:8]

[0000926326-23-000041:notes:9]
The Company’s critical accounting policies are those that affect its financial statements materially and involve difficult, subjective, or complex judgments by management. As of September 30, 2023, the Company is not aware of any events or circumstances that would require an update to its estimates, judgments, or revisions to the carrying value of its assets or liabilities.

[0000926326-23-000041:notes:10]
[same as prior period, unchanged from 0000926326-23-000031:notes:10]

[0000926326-23-000041:notes:11]
[same as prior period, unchanged from 0000926326-23-000031:notes:11]

[0000926326-23-000041:notes:12]
[same as prior period, unchanged from 0000926326-23-000031:notes:12]

[0000926326-23-000041:notes:13]
In October 2021, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. The update addresses diversity in practice by requiring that an acquirer recognize and measure contract assets and liabilities acquired in a business combination in accordance with Accounting Standards Codification (“ASC”) 606, Revenue from Contracts with Customers. The Company adopted ASU 2021-08 beginning January 1, 2023 and will apply the guidance prospectively to acquisitions occurring on or after the adoption date.

[0000926326-23-000041:notes:14]
[same as prior period, unchanged from 0000926326-23-000031:notes:14]

[0000926326-23-000041:notes:15]
[same as prior period, unchanged from 0000926326-23-000031:notes:15]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000926326-23-000041:notes:16]
[same as prior period, unchanged from 0000926326-23-000031:notes:16]

[0000926326-23-000041:notes:17]
[same as prior period, unchanged from 0000926326-23-000031:notes:17]

[0000926326-23-000041:notes:18]
[same as prior period, unchanged from 0000926326-23-000031:notes:18]

[0000926326-23-000041:notes:19]
[same as prior period, unchanged from 0000926326-23-000031:notes:19]

[0000926326-23-000041:notes:20]
[same as prior period, unchanged from 0000926326-23-000031:notes:20]

[0000926326-23-000041:notes:21]
[same as prior period, unchanged from 0000926326-23-000031:notes:21]

[0000926326-23-000041:notes:22]
[same as prior period, unchanged from 0000926326-23-000031:notes:22]

[0000926326-23-000041:notes:23]
[same as prior period, unchanged from 0000926326-23-000031:notes:23]

[0000926326-23-000041:notes:24]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”) and Federal agencies that purchase under a Federal Supply Schedule Contract with the Department of Veterans Affairs (the “GSA Contract”). GPOs are often fully or partially owned by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company also pays the Industrial Funding Fee (“IFF”) to the Department of Veterans Affairs under the GSA Contract. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs and the IFF were $3.6 million and $4.8 million for the three months ended September 30, 2023 and 2022, respectively, and $9.5 million and $13.3 million for the nine months ended September 30, 2023 and 2022, respectively.

[0000926326-23-000041:notes:25]
[same as prior period, unchanged from 0000926326-23-000031:notes:25]

[0000926326-23-000041:notes:26]
The following table summarizes the Company’s revenues disaggregated by revenue type for the three and nine months ended September 30, 2023 and 2022:

[0000926326-23-000041:notes:27]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  | (In thousands) |
| Connected devices, software licenses, and other | $ | 167,560 |  |  | $ | 226,415 |  |  | $ | 500,182 |  |  | $ | 650,125 |  |
| Consumables | 21,195 |  |  | 20,150 |  |  | 62,724 |  |  | 56,121 |  |
| Technical services | 57,303 |  |  | 53,914 |  |  | 167,851 |  |  | 156,386 |  |
| Advanced Services | 52,605 |  |  | 47,580 |  |  | 157,508 |  |  | 135,641 |  |
| Total revenues | $ | 298,663 |  |  | $ | 348,059 |  |  | $ | 888,265 |  |  | $ | 998,273 |  |

[0000926326-23-000041:notes:28]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location, for the three and nine months ended September 30, 2023 and 2022:

[0000926326-23-000041:notes:29]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  | (In thousands) |
| United States | $ | 272,649 |  |  | $ | 315,755 |  |  | $ | 785,794 |  |  | $ | 898,269 |  |
| Rest of world (1) | 26,014 |  |  | 32,304 |  |  | 102,471 |  |  | 100,004 |  |
| Total revenues | $ | 298,663 |  |  | $ | 348,059 |  |  | $ | 888,265 |  |  | $ | 998,273 |  |

[0000926326-23-000041:notes:30]
[same as prior period, unchanged from 0000926326-23-000031:notes:30]

[0000926326-23-000041:notes:31]
[same as prior period, unchanged from 0000926326-23-000031:notes:31]

[0000926326-23-000041:notes:32]
[same as prior period, unchanged from 0000926326-23-000031:notes:32]

[0000926326-23-000041:notes:33]
[same as prior period, unchanged from 0000926326-23-000031:notes:33]

[0000926326-23-000041:notes:34]
|  | September 30,2023 |  | December 31,2022 |
|  | (In thousands) |
| Short-term unbilled receivables, net (1) | $ | 20,275 |  |  | $ | 25,763 |  |
| Long-term unbilled receivables, net (2) | 13,159 |  |  | 14,744 |  |
| Total contract assets | $ | 33,434 |  |  | $ | 40,507 |  |
| Short-term deferred revenues, net | $ | 124,991 |  |  | $ | 118,947 |  |
| Long-term deferred revenues | 55,053 |  |  | 37,385 |  |
| Total contract liabilities | $ | 180,044 |  |  | $ | 156,332 |  |

[0000926326-23-000041:notes:35]
[same as prior period, unchanged from 0000926326-23-000031:notes:35]

[0000926326-23-000041:notes:36]
[same as prior period, unchanged from 0000926326-23-000031:notes:36]

[0000926326-23-000041:notes:37]
[same as prior period, unchanged from 0000926326-23-000031:notes:37]

[0000926326-23-000041:notes:38]
Short-term deferred revenues of $125.0 million and $118.9 million include deferred revenues from product sales and service contracts, net of deferred cost of sales of $12.4 million and $15.8 million, as of September 30, 2023 and December 31, 2022, respectively. During the three and nine months ended September 30, 2023, the Company recognized revenues of $20.1 million and $106.2 million, respectively, that were included in the corresponding gross short-term deferred revenues balance of $134.7 million as of December 31, 2022. Long-term deferred revenues include deferred revenues from product sales and service contracts of $55.1 million and $37.4 million as of September 30, 2023 and December 31, 2022, respectively. Deferred revenues from product sales primarily relate to delivered and invoiced products, pending installation and acceptance. Deferred revenues from service contracts primarily relate to services that have been invoiced, where services have not yet been provided.

[0000926326-23-000041:notes:39]
Short-term deferred revenues are expected to be recognized within the next twelve months. Long-term deferred revenues substantially consist of deferred revenues on long-term service contracts which have been invoiced and are expected to be recognized as revenue beyond twelve months, generally not more than ten years. The Company generally invoices customers for products upon shipment. Invoicing associated with the service portion of agreements is generally periodic and is billed on a monthly, quarterly, or annual basis, and in certain circumstances, multiple years are billed at one time.

[0000926326-23-000041:notes:40]
In addition, the Company has remaining performance obligations associated with contracts for which the associated products have been accepted or associated services have started, but where invoicing has not yet occurred and therefore are not reflected in deferred revenue. These remaining performance obligations are comprised of the non-variable portions of technical services and Advanced Services provided under non-cancellable contracts with minimum commitments. Remaining performance obligations which are not included in deferred revenues are $344.8 million as of September 30, 2023. Remaining performance obligations are expected to be recognized ratably over the remaining terms of the associated contracts, which terms vary but are generally not more than ten years. Remaining performance obligations do not include product obligations, services where the associated product has not been accepted, services which have not yet started, variable portions of services, and certain other obligations.

[0000926326-23-000041:notes:41]
[same as prior period, unchanged from 0000926326-23-000031:notes:41]

[0000926326-23-000041:notes:42]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three and nine months ended September 30, 2023 and 2022. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable balance as of September 30, 2023 and December 31, 2022.


## us-gaap:EarningsPerShareTextBlock

[0000926326-23-000041:notes:43]
Net Income (Loss) Per Share
The basic and diluted net income (loss) per share calculations for the three and nine months ended September 30, 2023 and 2022 were as follows:

[0000926326-23-000041:notes:44]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  | (In thousands, except per share data) |
| Net income (loss) | $ | 5,553 |  |  | $ | 16,774 |  |  | $ | (5,996) |  |  | $ | 34,056 |  |
| Weighted-average shares outstanding – basic | 45,333 |  |  | 44,441 |  |  | 45,117 |  |  | 44,304 |  |
| Effect of dilutive securities from stock award plans | 262 |  |  | 943 |  |  | — |  |  | 1,293 |  |
| Effect of convertible senior notes | — |  |  | 435 |  |  | — |  |  | 1,162 |  |
| Weighted-average shares outstanding – diluted | 45,595 |  |  | 45,819 |  |  | 45,117 |  |  | 46,759 |  |
| Net income (loss) per share – basic | $ | 0.12 |  |  | $ | 0.38 |  |  | $ | (0.13) |  |  | $ | 0.77 |  |
| Net income (loss) per share – diluted | $ | 0.12 |  |  | $ | 0.37 |  |  | $ | (0.13) |  |  | $ | 0.73 |  |
| Anti-dilutive weighted-average shares related to stock award plans | 2,727 |  |  | 810 |  |  | 3,536 |  |  | 689 |  |
| Anti-dilutive weighted-average shares related to convertible senior notes and warrants | 11,816 |  |  | 5,908 |  |  | 11,816 |  |  | 5,908 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000926326-23-000041:notes:45]
Cash and Cash Equivalents and Fair Value of Financial Instruments
Cash and cash equivalents of $446.8 million and $330.4 million as of September 30, 2023 and December 31, 2022, respectively, consisted of bank accounts and highly-liquid U.S. Government money market funds held in sweep and asset management accounts with financial institutions of high credit quality. As of September 30, 2023 and December 31, 2022, cash equivalents were $429.7 million and $301.0 million, respectively, which consisted of money market funds held in sweep and asset management accounts.

[0000926326-23-000041:notes:46]
[same as prior period, unchanged from 0000926326-23-000031:notes:46]

[0000926326-23-000041:notes:47]
The Company measures its financial instruments at fair value. The Company’s cash, cash equivalents, and restricted cash are classified within Level 1 of the fair value hierarchy as they are valued primarily using quoted market prices utilizing market observable inputs. The Company’s credit facility is classified within Level 2 as the valuation inputs are based on quoted prices or market observable data of similar instruments. The Company’s convertible senior notes are classified within Level 2 as the valuation inputs are based on quoted prices in an inactive market on the last day in the reporting period. As of 
September 30, 2023 and December 31, 2022, the fair value of the convertible senior notes was $518.6 million and $501.4 million, respectively, compared to their carrying values of $568.9 million and $566.6 million, respectively, which are net of unamortized debt issuance costs. Refer to Note 9, Debt and Credit Agreement, for further information regarding the Company’s credit facility and Note 10, Convertible Senior Notes, for further information regarding the Company’s convertible senior notes.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000926326-23-000041:notes:48]
Balance Sheet Components
Balance sheet details as of September 30, 2023 and December 31, 2022 are presented in the tables below:

[0000926326-23-000041:notes:49]
|  | September 30,2023 |  | December 31,2022 |
|  | (In thousands) |
| Inventories: |  |  |  |
| Raw materials | $ | 56,566 |  |  | $ | 75,854 |  |
| Work in process | 2,738 |  |  | 9,280 |  |
| Finished goods | 56,840 |  |  | 62,415 |  |
| Total inventories | $ | 116,144 |  |  | $ | 147,549 |  |
| Other current assets: |  |  |  |
| Funds held for customers, including restricted cash (1) | $ | 30,967 |  |  | $ | 56,703 |  |
| Net investment in sales-type leases, current portion | 11,618 |  |  | 11,486 |  |
| Prepaid income taxes | 125 |  |  | 1,702 |  |
| Other current assets | 7,526 |  |  | 7,471 |  |
| Total other current assets | $ | 50,236 |  |  | $ | 77,362 |  |
| Other long-term assets: |  |  |  |
| External-use software development costs, net | $ | 69,872 |  |  | $ | 80,760 |  |
| Unbilled receivables, net | 13,159 |  |  | 14,744 |  |
| Deferred debt issuance costs | 1,235 |  |  | 2,058 |  |
| Other long-term assets | 6,500 |  |  | 7,455 |  |
| Total other long-term assets | $ | 90,766 |  |  | $ | 105,017 |  |
| Accrued liabilities: |  |  |  |
| Operating lease liabilities, current portion | $ | 10,617 |  |  | $ | 10,761 |  |
| Customer fund liabilities | 30,967 |  |  | 56,703 |  |
| Advance payments from customers | 10,549 |  |  | 11,556 |  |
| Rebate liabilities | 50,878 |  |  | 42,802 |  |
| Group purchasing organization fees | 5,290 |  |  | 7,723 |  |
| Taxes payable | 14,178 |  |  | 9,642 |  |
| Other accrued liabilities | 27,906 |  |  | 33,468 |  |
| Total accrued liabilities | $ | 150,385 |  |  | $ | 172,655 |  |

[0000926326-23-000041:notes:50]
(1)    Includes restricted cash of $15.9 million and $22.5 million as of September 30, 2023 and December 31, 2022, respectively.

[0000926326-23-000041:notes:51]
The following table summarizes the changes in accumulated balances of other comprehensive income (loss), which consisted of foreign currency translation adjustments, for the three and nine months ended September 30, 2023 and 2022:

[0000926326-23-000041:notes:52]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  | (In thousands) |
| Beginning balance | $ | (14,176) |  |  | $ | (17,372) |  |  | $ | (17,087) |  |  | $ | (8,407) |  |
| Other comprehensive loss | (2,953) |  |  | (6,770) |  |  | (42) |  |  | (15,735) |  |
| Ending balance | $ | (17,129) |  |  | $ | (24,142) |  |  | $ | (17,129) |  |  | $ | (24,142) |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000926326-23-000041:notes:53]
Property and Equipment
The following table represents the property and equipment balances as of September 30, 2023 and December 31, 2022:

[0000926326-23-000041:notes:54]
|  | September 30,2023 |  | December 31,2022 |
|  | (In thousands) |
| Equipment | $ | 95,891 |  |  | $ | 91,391 |  |
| Furniture and fixtures | 4,898 |  |  | 5,154 |  |
| Leasehold improvements | 17,821 |  |  | 19,510 |  |
| Purchased software and internal-use software development costs | 97,860 |  |  | 76,327 |  |
| Construction in progress | 28,369 |  |  | 28,223 |  |
| Property and equipment, gross | 244,839 |  |  | 220,605 |  |
| Accumulated depreciation and amortization | (137,959) |  |  | (126,644) |  |
| Total property and equipment, net | $ | 106,880 |  |  | $ | 93,961 |  |

[0000926326-23-000041:notes:55]
Depreciation and amortization expense of property and equipment was $6.7 million and $5.8 million for the three months ended September 30, 2023 and 2022, respectively, and $19.6 million and $16.7 million for the nine months ended September 30, 2023 and 2022, respectively.

[0000926326-23-000041:notes:56]
The geographic location of the Company’s property and equipment, net, is based on the physical location in which it is located. The following table summarizes the geographic information for property and equipment, net, as of September 30, 2023 and December 31, 2022:

[0000926326-23-000041:notes:57]
|  | September 30,2023 |  | December 31,2022 |
|  | (In thousands) |
| United States | $ | 102,729 |  |  | $ | 89,989 |  |
| Rest of world (1) | 4,151 |  |  | 3,972 |  |
| Total property and equipment, net | $ | 106,880 |  |  | $ | 93,961 |  |

[0000926326-23-000041:notes:58]
[same as prior period, unchanged from 0000926326-23-000031:notes:58]


## us-gaap:ResearchDevelopmentAndComputerSoftwareDisclosureTextBlock

[0000926326-23-000041:notes:59]
External-Use Software Development Costs
The carrying amounts of external-use software development costs as of September 30, 2023 and December 31, 2022 were as follows:

[0000926326-23-000041:notes:60]
|  | September 30,2023 |  | December 31,2022 |
|  | (In thousands) |
| Gross carrying amount | $ | 236,024 |  |  | $ | 225,004 |  |
| Accumulated amortization | (166,152) |  |  | (144,244) |  |
| External-use software development costs, net (1) | $ | 69,872 |  |  | $ | 80,760 |  |

[0000926326-23-000041:notes:61]
[same as prior period, unchanged from 0000926326-23-000031:notes:61]

[0000926326-23-000041:notes:62]
The Company recorded $7.1 million and $7.3 million to cost of revenues for amortization of external-use software development costs for the three months ended September 30, 2023 and 2022, respectively, and $21.9 million and $21.5 million for the nine months ended September 30, 2023 and 2022, respectively.

[0000926326-23-000041:notes:63]
[same as prior period, unchanged from 0000926326-23-000031:notes:63]

[0000926326-23-000041:notes:64]
|  | September 30,2023 |
|  | (In thousands) |
| Remaining three months of 2023 | $ | 6,787 |  |
| 2024 | 24,747 |  |
| 2025 | 17,608 |  |
| 2026 | 12,069 |  |
| 2027 | 6,114 |  |
| Thereafter | 2,547 |  |
| Total | $ | 69,872 |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000926326-23-000041:notes:65]
[same as prior period, unchanged from 0000926326-23-000031:notes:65]

[0000926326-23-000041:notes:66]
[same as prior period, unchanged from 0000926326-23-000031:notes:66]

[0000926326-23-000041:notes:67]
|  |  |  |  |  | (In thousands) |
| Balance as of December 31, 2022 |  |  |  |  | $ | 734,274 |  |
| Foreign currency exchange rate fluctuations |  |  |  |  | 54 |  |
| Balance as of September 30, 2023 |  |  |  |  | $ | 734,328 |  |

[0000926326-23-000041:notes:68]
[same as prior period, unchanged from 0000926326-23-000031:notes:68]

[0000926326-23-000041:notes:69]
The carrying amounts and useful lives of intangible assets as of September 30, 2023 and December 31, 2022 were as follows:

[0000926326-23-000041:notes:70]
|  | September 30, 2023 |
|  | Gross carryingamount |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 311,089 |  |  | $ | (113,844) |  |  | $ | (1,482) |  |  | $ | 195,763 |  |  | 4 - 30 |
| Acquired technology | 84,876 |  |  | (64,792) |  |  | — |  |  | 20,084 |  |  | 4 - 20 |
| Backlog | 1,800 |  |  | (1,575) |  |  | — |  |  | 225 |  |  | 2 |
| Trade names | 9,200 |  |  | (7,418) |  |  | — |  |  | 1,782 |  |  | 5 - 12 |
| Patents | 2,430 |  |  | (1,423) |  |  | — |  |  | 1,007 |  |  | 2 - 20 |
| Non-compete agreements | 600 |  |  | (600) |  |  | — |  |  | — |  |  | 3 |
| Total intangibles assets, net | $ | 409,995 |  |  | $ | (189,652) |  |  | $ | (1,482) |  |  | $ | 218,861 |  |  |  |

[0000926326-23-000041:notes:71]
[same as prior period, unchanged from 0000926326-23-000031:notes:71]

[0000926326-23-000041:notes:72]
Amortization expense of intangible assets was $7.7 million and $8.7 million for the three months ended September 30, 2023 and 2022, respectively, and $24.1 million and $26.7 million for the nine months ended September 30, 2023 and 2022, respectively.

[0000926326-23-000041:notes:73]
[same as prior period, unchanged from 0000926326-23-000031:notes:73]

[0000926326-23-000041:notes:74]
|  | September 30,2023 |
|  | (In thousands) |
| Remaining three months of 2023 | $ | 7,483 |  |
| 2024 | 23,093 |  |
| 2025 | 21,056 |  |
| 2026 | 18,061 |  |
| 2027 | 16,754 |  |
| Thereafter | 132,414 |  |
| Total | $ | 218,861 |  |


## us-gaap:DebtDisclosureTextBlock

[0000926326-23-000041:notes:75]
Debt and Credit AgreementOn November 15, 2019, the Company entered into an Amended and Restated Credit Agreement (as amended, the “Prior A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers, and Wells Fargo Bank, National Association, as administrative 
agent. The Prior A&R Credit Agreement provided for (a) a five-year revolving credit facility of $500.0 million (the “Prior Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million (the “Prior Incremental Facility”). In addition, the Prior A&R Credit Agreement included a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The Prior A&R Credit Agreement had an expiration date of November 15, 2024, upon which date all remaining outstanding borrowings would be due and payable.

[0000926326-23-000041:notes:76]
On September 22, 2020 and March 29, 2023, the Company entered into amendments to the Prior A&R Credit Agreement to, among other changes, permit the issuance of the convertible senior notes and the purchase of the convertible note hedge transactions, as described in Note 10, Convertible Senior Notes, expand the Company’s flexibility to repurchase its common stock and make other restricted payments, and replace the total net leverage covenant with a new secured net leverage covenant that requires the Company to maintain a consolidated secured net leverage ratio not to exceed 3.50:1 for the calendar quarters ending September 30, 2020, December 31, 2020, and March 31, 2021 and 3.00:1 for the calendar quarters ending thereafter, as well as to remove and replace the interest rate benchmark based on the London interbank offered rate (“LIBOR”) and related LIBOR-based mechanics applicable to borrowings under the A&R Credit Agreement with an interest rate benchmark based on the secured overnight financing rate (“SOFR”) as administered by the Federal Reserve Bank of New York and related SOFR-based mechanics.

[0000926326-23-000041:notes:77]
Loans under the Prior Revolving Credit Facility bore interest, at the Company’s option, at a rate equal to either (a) the Adjusted Term SOFR (as defined in the Prior A&R Credit Agreement), plus an applicable margin ranging from 1.25% to 2.00% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the Prior A&R Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) Adjusted Term SOFR for a one month tenor plus 1.00%, plus an applicable margin ranging from 0.25% to 1.00% per annum based on the Company’s Consolidated Total Net Leverage Ratio. Undrawn commitments under the Prior Revolving Credit Facility were subject to a commitment fee ranging from 0.15% to 0.30% per annum based on the Company’s Consolidated Total Net Leverage Ratio on the average daily unused portion of the Prior Revolving Credit Facility. The applicable margin for, and certain other terms of, any term loans under the Prior Incremental Facility would be determined prior to the incurrence of such loans. The Company was permitted to make voluntary prepayments at any time without payment of a premium or penalty.

[0000926326-23-000041:notes:78]
The Prior A&R Credit Agreement contained customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends, and other distributions. The Prior A&R Credit Agreement also contained financial covenants that required the Company and its subsidiaries to not exceed a maximum total secured net leverage ratio (as described above) and maintain a minimum interest coverage ratio. In addition, the Prior A&R Credit Agreement contained certain customary events of default including, but not limited to, failure to pay interest, principal, and fees, or other amounts when due, material misrepresentations or misstatements in any representation or warranty, covenant defaults, certain cross defaults to other material indebtedness, certain judgment defaults, and events of bankruptcy.

[0000926326-23-000041:notes:79]
Subsequent to the quarter ended September 30, 2023, the Company entered into a Second Amended and Restated Credit Agreement (the “Second A&R Credit Agreement”) on October 10, 2023, with the lenders from time to time party thereto, Wells Fargo Securities, LLC, JPMorgan Chase Bank, N.A., PNC Capital Markets LLC and TD Securities (USA) LLC as joint lead arrangers and Wells Fargo Bank, National Association, as administrative agent. The Second A&R Credit Agreement supersedes the Prior A&R Credit Agreement and provides for (a) a five-year revolving credit facility of $350.0 million (the “Current Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to an amount equal to the sum of (i) the greater of $250.0 million or 100% of the adjusted consolidated EBITDA for the last four quarters and (ii) additional amounts subject to pro forma compliance with certain consolidated secured net leverage ratio (the “Current Incremental Facility”). In addition, the Second A&R Credit Agreement includes a letter of credit sub-limit of up to $15 million and a swing line loan sub-limit of up to $25 million. The Second A&R Credit Agreement has an expiration date of October 10, 2028, subject to acceleration under certain conditions, upon which date all remaining outstanding borrowings will be due and payable.

[0000926326-23-000041:notes:80]
Loans under the Current Revolving Credit Facility bear interest, at the Company’s option, at a rate equal to either (a) the Adjusted Term SOFR (as defined in the Second A&R Credit Agreement), plus an applicable margin ranging from 1.50% to 2.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the Second A&R Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) the Adjusted Term SOFR for an interest period of one month plus 1.00%, plus an applicable margin ranging from 0.50% to 1.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio. Undrawn commitments under the Current Revolving Credit Facility are subject to a commitment fee ranging from 0.20% to 0.35% per annum based on the Company’s Consolidated Total Net Leverage Ratio on the average daily unused portion of the Current Revolving Credit Facility. Subject to the terms and conditions of the Current Revolving Credit Facility or Current Incremental Facility, the Company is permitted to make voluntary prepayments at any time without payment of a premium or penalty. The availability of funds under the Current

[0000926326-23-000041:notes:81]
Revolving Credit Facility may be subject to reduction in order to maintain compliance with the financial covenants under the Second A&R Credit Agreement.

[0000926326-23-000041:notes:82]
The Second A&R Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends, and other distributions. The Second A&R Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum consolidated secured net leverage ratio (not to exceed 3.00:1) and maintain a minimum consolidated interest coverage ratio (not to be less than 3.00:1). In addition, the Second A&R Credit Agreement contains certain customary events of default including, but not limited to, failure to pay interest, principal and fees, or other amounts when due, material misrepresentations or misstatements in any representation or warranty, covenant defaults, certain cross defaults to other material indebtedness, certain judgment defaults, and events of bankruptcy.

[0000926326-23-000041:notes:83]
The Company’s obligations under the Second A&R Credit Agreement and, at the election of the Company and the contracting counterparty, any secured swap obligations and banking services obligations owing to a lender (or an affiliate of a lender), are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and such subsidiary guarantors’ assets. In connection with entering into the Second A&R Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a reaffirmation agreement, which amends certain terms of the existing collateral agreement and reaffirms their obligations under the existing guaranty agreement.

[0000926326-23-000041:notes:84]
As of both September 30, 2023 and December 31, 2022, the Company had $500.0 million of funds available under the Prior Revolving Credit Facility. As of September 30, 2023 and December 31, 2022, the Company had no outstanding balance under the Prior Revolving Credit Facility. The Company was in compliance with all covenants of the Prior A&R Credit Agreement as of September 30, 2023. Upon entry into the Second A&R Credit Agreement, the Company had $350.0 million of funds available under the Current Revolving Credit Facility. 
Convertible Senior Notes
0.25% Convertible Senior Notes due 2025

[0000926326-23-000041:notes:85]
On September 25, 2020, the Company completed a private offering of $575.0 million aggregate principal amount of 0.25% convertible senior notes (the “Notes”), including the exercise in full of the initial purchasers’ option to purchase up to an additional $75.0 million principal amount of the Notes. The Company received proceeds from the issuance of the Notes of $559.7 million, net of $15.3 million of transaction fees and other debt issuance costs. The Notes bear interest at a rate of 0.25% per year, payable semiannually in arrears on March 15 and September 15 of each year, beginning on March 15, 2021. The Notes were issued pursuant to an indenture, dated September 25, 2020 (the “Indenture”), between the Company and U.S. Bank National Association, as trustee. The Notes are general senior, unsecured obligations of the Company and will mature on September 15, 2025, unless earlier redeemed, repurchased, or converted.

[0000926326-23-000041:notes:86]
The Notes are convertible at the option of the holders at any time prior to the close of business on the business day immediately preceding May 15, 2025, only under the following circumstances: (i) during any fiscal quarter commencing after the fiscal quarter ended on December 31, 2020 (and only during such fiscal quarter), if the last reported sale price of the Company’s common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on, and including, the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the Notes on each applicable trading day; (ii) during the five business day period after any ten consecutive trading day period (the “measurement period”) in which the trading price (as defined in the Indenture) per $1,000 principal amount of the Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of the Company’s common stock and the conversion rate for the Notes on each such trading day; (iii) if the Company calls such Notes for redemption, at any time prior to the close of business on the scheduled trading day immediately preceding the redemption date, but only with respect to the Notes called (or deemed called) for redemption; and (iv) upon the occurrence of specified corporate events, as specified in the Indenture. On or after May 15, 2025 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders of the Notes may convert all or any portion of their Notes at any time, regardless of the foregoing conditions.

[0000926326-23-000041:notes:87]
During the three months ended September 30, 2023 and December 31, 2022, none of the conditional conversion features of the Notes were triggered, and therefore, the Notes are not convertible during the fourth quarter of 2023, commencing on October 1, 2023, and were not convertible during the first quarter of 2023, commencing on January 1, 2023. Accordingly, the Company classified the Notes as a long-term liability in its Condensed Consolidated Financial Statements as of both September 30, 2023 and December 31, 2022. Whether the Notes will be convertible following the fourth fiscal quarter of 2023 will depend on the satisfaction of the conversion conditions in the future.

[0000926326-23-000041:notes:88]
Under the original terms of the Indenture, upon conversion, the Company could satisfy its conversion obligation by paying or delivering cash, shares of its common stock, or a combination thereof, at the Company’s election, in the manner and subject to the terms and conditions provided in the Indenture. On December 13, 2021, the Company irrevocably elected to fix its settlement method to a combination of cash and shares of the Company’s common stock with the specified cash amount per $1,000 principal amount of Notes of at least $1,000. As a result, for Notes converted on or after December 13, 2021, a converting noteholder will receive (i) up to $1,000 in cash per $1,000 principal amount of Notes and (ii) cash and/or shares of the Company’s common stock, at the Company’s option for any conversion consideration in excess of $1,000. In addition, the Company continues to have the ability to set the specified cash amount per $1,000 principal amount of Notes above $1,000. The initial conversion rate for the Notes is 10.2751 shares of the Company’s common stock per $1,000 principal amount of Notes, which is equivalent to an initial conversion price of approximately $97.32 per share of the Company’s common stock, subject to adjustment under certain circumstances in accordance with the terms of the Indenture. In addition, following certain corporate events that could occur prior to the maturity date of the Notes or if the Company delivers a notice of redemption in respect of the Notes, the Company will, under certain circumstances, increase the conversion rate of the Notes for a holder who elects to convert its Notes (or any portion thereof) in connection with such a corporate event or convert its Notes called (or deemed called) for redemption during the related redemption period (as defined in the Indenture), as the case may be.

[0000926326-23-000041:notes:89]
If the Company undergoes a fundamental change, holders may require, subject to certain exceptions, the Company to repurchase for cash all or any portion of their Notes at a fundamental change repurchase price equal to 100% of the principal amount of the Notes to be repurchased, plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date. As of September 30, 2023, none of the criteria for a fundamental change or a conversion rate adjustment had been met.

[0000926326-23-000041:notes:90]
As of September 20, 2023, the Company may redeem for cash all or any portion of the Notes, at its option, if the last reported sale price of the Company’s common stock has been at least 130% of the conversion price for the Notes then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which the Company provides notice of redemption at a redemption price equal to 100% of the principal amount of the Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. If the Company redeems less than all of the outstanding Notes, at least $150.0 million aggregate principal amount of Notes must be outstanding and not subject to redemption as of the date of the relevant notice of redemption. No sinking fund is provided for in the Notes.

[0000926326-23-000041:notes:91]
The debt issuance costs associated with the Notes are being amortized to interest expense over the term of the Notes using an effective interest rate of 0.80%. As of September 30, 2023, the remaining life of the Notes and the related issuance cost accretion is approximately 2.0 years.

[0000926326-23-000041:notes:92]
The maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to other conversion rate adjustments, would be 5.9 million shares. As of September 30, 2023, the if-converted value of the Notes did not exceed the principal amount.

[0000926326-23-000041:notes:93]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of September 30, 2023 and December 31, 2022:

[0000926326-23-000041:notes:94]
|  | September 30,2023 |  | December 31,2022 |
|  | (In thousands) |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized debt issuance costs | (6,113) |  |  | (8,429) |  |
| Convertible senior notes, net | $ | 568,887 |  |  | $ | 566,571 |  |

[0000926326-23-000041:notes:95]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three and nine months ended September 30, 2023 and 2022:

[0000926326-23-000041:notes:96]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  | (In thousands) |
| Contractual coupon interest | $ | 359 |  |  | $ | 359 |  |  | $ | 1,078 |  |  | $ | 1,078 |  |
| Amortization of debt issuance costs | $ | 773 |  |  | $ | 768 |  |  | $ | 2,316 |  |  | $ | 2,298 |  |

[0000926326-23-000041:notes:97]
Convertible Note Hedge and Warrant Transactions

[0000926326-23-000041:notes:98]
In connection with the issuance of the Notes in September 2020, the Company entered into convertible note hedge and warrant transactions with an affiliate of one of the initial purchasers of the Notes and certain other financial institutions (the “option counterparties”) with respect to the Company’s common stock.

[0000926326-23-000041:notes:99]
The convertible note hedge consists of an option for the Company to purchase up to approximately 5.9 million shares of the Company’s common stock, which is equal to the number of shares of the Company’s common stock underlying the Notes, at an initial strike price of approximately $97.32 per share. The convertible note hedge will expire upon the maturity of the Notes, if not earlier exercised or terminated. The cost of the convertible note hedge was approximately $100.6 million and was accounted for as an equity instrument, which was recorded in additional paid-in capital in the Condensed Consolidated Balance Sheets. The Company recorded a deferred tax asset of $25.8 million at issuance related to the convertible note hedge transaction. The convertible note hedge is expected generally to reduce the potential dilution to the Company’s common stock upon any conversion of Notes and/or offset any cash payments the Company is required to make in excess of the principal amount of converted Notes.

[0000926326-23-000041:notes:100]
Separately from the convertible note hedge, the Company entered into warrant transactions to sell to the option counterparties warrants to acquire, subject to customary anti-dilution adjustments, up to approximately 5.9 million shares of its common stock in the aggregate at an initial strike price of $141.56 per share. The warrants require net share or net cash settlement upon the Company’s election. The Company received aggregate proceeds of approximately $51.3 million for the issuance of the warrants, which was recorded in additional paid-in capital at issuance in the Condensed Consolidated Balance Sheets. The warrants could separately have a dilutive effect to the Company’s common stock to the extent that the market price per share of its common stock exceeds the strike price of the warrants.


## us-gaap:LessorSalesTypeLeasesTextBlock

[0000926326-23-000041:notes:101]
[same as prior period, unchanged from 0000926326-23-000031:notes:100]

[0000926326-23-000041:notes:102]
The Company enters into multi-year, sales-type lease agreements, with the leases varying in length from one to ten years. The Company optimizes cash flows by selling a majority of its sales-type leases, other than those relating to U.S. government hospitals and Advanced Services products, including Central Pharmacy Dispensing Service and IV Compounding Service, to third-party leasing finance companies on a non-recourse basis. The Company has no obligation to the leasing company once the lease has been sold.

[0000926326-23-000041:notes:103]
The following table presents the Company’s income recognized from sales-type leases for the three and nine months ended September 30, 2023 and 2022:

[0000926326-23-000041:notes:104]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  | (In thousands) |
| Sales-type lease revenues | $ | 14,388 |  |  | $ | 10,115 |  |  | $ | 27,960 |  |  | $ | 34,033 |  |
| Cost of sales-type lease revenues | (7,141) |  |  | (5,357) |  |  | (14,183) |  |  | (16,963) |  |
| Selling profit on sales-type lease revenues | $ | 7,247 |  |  | $ | 4,758 |  |  | $ | 13,777 |  |  | $ | 17,070 |  |

[0000926326-23-000041:notes:105]
The receivables as a result of these types of transactions are collateralized by the underlying equipment leased and consist of the following components at September 30, 2023 and December 31, 2022:

[0000926326-23-000041:notes:106]
|  | September 30,2023 |  | December 31,2022 |
|  | (In thousands) |
| Net minimum lease payments to be received | $ | 62,470 |  |  | $ | 50,755 |  |
| Less: Unearned interest income portion | (9,221) |  |  | (6,345) |  |
| Net investment in sales-type leases | 53,249 |  |  | 44,410 |  |
| Less: Current portion (1) | (11,618) |  |  | (11,486) |  |
| Long-term investment in sales-type leases, net | $ | 41,631 |  |  | $ | 32,924 |  |

[0000926326-23-000041:notes:107]
[same as prior period, unchanged from 0000926326-23-000031:notes:106]

[0000926326-23-000041:notes:108]
[same as prior period, unchanged from 0000926326-23-000031:notes:107]

[0000926326-23-000041:notes:109]
[same as prior period, unchanged from 0000926326-23-000031:notes:108]

[0000926326-23-000041:notes:110]
|  | September 30,2023 |
|  | (In thousands) |
| Remaining three months of 2023 | $ | 3,828 |  |
| 2024 | 13,431 |  |
| 2025 | 11,351 |  |
| 2026 | 9,053 |  |
| 2027 | 7,286 |  |
| Thereafter | 17,521 |  |
| Total future minimum sales-type lease payments | 62,470 |  |
| Present value adjustment | (9,221) |  |
| Total net investment in sales-type leases | $ | 53,249 |  |

[0000926326-23-000041:notes:111]
[same as prior period, unchanged from 0000926326-23-000031:notes:110]

[0000926326-23-000041:notes:112]
The following table represents the Company’s income recognized from operating leases for the three and nine months ended September 30, 2023 and 2022:

[0000926326-23-000041:notes:113]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  | (In thousands) |
| Rental income | $ | 1,330 |  |  | $ | 2,327 |  |  | $ | 5,459 |  |  | $ | 7,220 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0000926326-23-000041:notes:114]
Lessee Leases 
The Company has operating leases for office buildings, data centers, office equipment, and vehicles. The Company’s leases have initial terms of one to twelve years. As of September 30, 2023, the Company did not have any additional material operating leases that were entered into, but not yet commenced.

[0000926326-23-000041:notes:115]
[same as prior period, unchanged from 0000926326-23-000031:notes:114]

[0000926326-23-000041:notes:116]
|  | September 30,2023 |
|  | (In thousands) |
| Remaining three months of 2023 | $ | 3,340 |  |
| 2024 | 12,266 |  |
| 2025 | 9,604 |  |
| 2026 | 8,942 |  |
| 2027 | 7,334 |  |
| Thereafter | 8,054 |  |
| Total operating lease payments | 49,540 |  |
| Present value adjustment | (6,078) |  |
| Total operating lease liabilities (1) | $ | 43,462 |  |

[0000926326-23-000041:notes:117]
(1)    Amount consists of a current and long-term portion of operating lease liabilities of $10.6 million and $32.8 million, respectively. The current portion of the operating lease liabilities is included in accrued liabilities in the Condensed Consolidated Balance Sheets.

[0000926326-23-000041:notes:118]
Operating lease costs were $2.6 million and $4.0 million for the three months ended September 30, 2023 and 2022, respectively, and $8.2 million and $12.8 million for the nine months ended September 30, 2023 and 2022, respectively. Short-term lease costs and variable lease costs were not material for the three and nine months ended September 30, 2023 and 2022. The Company recorded impairment and abandonment charges to operating lease right-of-use assets of $7.8 million during the nine months ended September 30, 2023, and $0.3 million and $5.4 million during the three and nine months ended September 30, 2022, respectively, in connection with restructuring activities to reduce its real estate footprint and for optimization of certain leased facilities. The impairment and abandonment charges were recorded to selling, general, and administrative expenses on the Company’s Condensed Consolidated Statements of Operations. Refer to Note 16, Restructuring Expenses, for additional information regarding the Company’s restructuring activities.

[0000926326-23-000041:notes:119]
The following table summarizes supplemental cash flow information related to the Company’s operating leases for the nine months ended September 30, 2023 and 2022:

[0000926326-23-000041:notes:120]
|  | Nine Months Ended September 30, |
|  | 2023 |  | 2022 |
|  | (In thousands) |
| Cash paid for amounts included in the measurement of lease liabilities | $ | 10,100 |  |  | $ | 13,178 |  |
| Right-of-use assets obtained in exchange for new lease liabilities | $ | 1,758 |  |  | $ | 12,177 |  |

[0000926326-23-000041:notes:121]
The following table summarizes the weighted-average remaining lease term and weighted-average discount rate related to the Company’s operating leases as of September 30, 2023 and December 31, 2022:

[0000926326-23-000041:notes:122]
|  | September 30,2023 |  | December 31,2022 |
| Weighted-average remaining lease term, years | 4.6 |  | 5.0 |
| Weighted-average discount rate, % | 5.7 | % |  | 5.7 | % |


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000926326-23-000041:notes:123]
Commitments and Contingencies
Purchase Obligations

[0000926326-23-000041:notes:124]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of September 30, 2023, the Company had non-cancelable purchase commitments of $118.7 million, of which $78.1 million are expected to be paid within the year ending December 31, 2023.

[0000926326-23-000041:notes:125]
Ransomware Incident

[0000926326-23-000041:notes:126]
During the nine months ended September 30, 2023, the Company did not incur any material expenses or recoveries related to the previously disclosed ransomware incident. During the three months ended September 30, 2022, the Company incurred $1.0 million of expenses related to the ransomware incident, and during the nine months ended September 30, 2022, the Company incurred $13.5 million of expenses related to the ransomware incident, partially offset by $11.1 million of expected insurance recoveries. Expenses include costs to investigate and remediate the ransomware incident, as well as legal and other professional services, all of which were expensed as incurred. For the three and nine months ended September 30, 2022, the Company included net expenses related to the ransomware incident in cost of revenues of $0.1 million and $0.3 million, respectively; in research and development of $0.2 million and $0.2 million, respectively; and in selling, general, and administrative expenses of $0.7 million and $1.9 million, respectively, in the Company’s Condensed Consolidated Statements of Operations.

[0000926326-23-000041:notes:127]
As of September 30, 2023, the Company has incurred $13.6 million of cumulative expenses related to the ransomware incident since it was detected, partially offset by $11.6 million of insurance recoveries, all of which have been received as of September 30, 2023.

[0000926326-23-000041:notes:128]
Legal Proceedings

[0000926326-23-000041:notes:129]
The Company is currently involved in various legal proceedings.

[0000926326-23-000041:notes:130]
As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any material accrual for contingent liabilities associated with any current legal proceedings based on its belief that any potential material loss, while reasonably possible, is not probable. Furthermore, any possible range of loss in such matters cannot be reasonably estimated at this time. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However,

[0000926326-23-000041:notes:131]
litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of legal proceedings or because of the diversion of management’s attention and the creation of significant expenses, regardless of outcome.

[0000926326-23-000041:notes:132]
The Company is not a party to any legal proceedings that management believes may have a material impact on the Company’s financial position or results of operations.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000926326-23-000041:notes:133]
Income Taxes 
The Company generally provides for income taxes in interim periods based on the estimated annual effective tax rate for the year, adjusting for discrete items in the quarter in which they arise. For the nine months ended September 30, 2023, the Company recorded a provision for income taxes of $4.4 million by applying its estimated annual effective tax rate to its year-to-date measure of ordinary income and adjusted for $5.6 million of discrete income tax expense primarily from equity compensation. For the nine months ended September 30, 2022, the Company recorded a benefit from income taxes of $1.0 million by applying its estimated annual effective tax rate to its year-to-date measure of ordinary income and included a net discrete income tax benefit of $6.9 million, primarily due to a tax benefit from equity compensation.

[0000926326-23-000041:notes:134]
[same as prior period, unchanged from 0000926326-23-000031:notes:134]

[0000926326-23-000041:notes:135]
On August 16, 2022, the Inflation Reduction Act of 2022 (the “IRA”) was signed into law and introduced a 15% corporate alternative minimum tax for tax years beginning after December 31, 2022 and levies a 1% excise tax on net stock repurchases after December 31, 2022. These provisions did not have an impact on the Company’s provision for income taxes for the nine months ended September 30, 2023.

[0000926326-23-000041:notes:136]
As of September 30, 2023 and December 31, 2022, the Company had gross unrecognized tax benefits of $10.1 million and $9.3 million, respectively. The Company recognizes interest and penalties related to uncertain tax positions in interest and other income (expense), net in the Condensed Consolidated Statements of Operations. Accrued interest and penalties are included within other long-term liabilities on the Condensed Consolidated Balance Sheets. As of September 30, 2023 and December 31, 2022, the amount of accrued interest and penalties was $0.4 million and $0.2 million, respectively.

[0000926326-23-000041:notes:137]
The Company files income tax returns in the United States and various state and foreign jurisdictions. In the normal course of business, the Company is subject to examinations by taxing authorities, including major jurisdictions such as the United States, Germany, Italy, France, and the United Kingdom. With few exceptions, as of September 30, 2023, the Company was no longer subject to U.S., state, and foreign tax examinations for years before 2019, 2018, and 2018, respectively.

[0000926326-23-000041:notes:138]
[same as prior period, unchanged from 0000926326-23-000031:notes:138]


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000926326-23-000041:notes:139]
[same as prior period, unchanged from 0000926326-23-000031:notes:139]

[0000926326-23-000041:notes:140]
The following table sets forth the total share-based compensation expense recognized in the Company’s Condensed Consolidated Statements of Operations for the three and nine months ended September 30, 2023 and 2022:

[0000926326-23-000041:notes:141]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  | (In thousands) |
| Cost of product and service revenues | $ | 2,213 |  |  | $ | 2,203 |  |  | $ | 6,489 |  |  | $ | 6,607 |  |
| Research and development | 1,917 |  |  | 3,054 |  |  | 5,220 |  |  | 7,912 |  |
| Selling, general, and administrative | 10,852 |  |  | 12,053 |  |  | 31,404 |  |  | 36,212 |  |
| Total share-based compensation expense | $ | 14,982 |  |  | $ | 17,310 |  |  | $ | 43,113 |  |  | $ | 50,731 |  |

[0000926326-23-000041:notes:142]
During the three and nine months ended September 30, 2023, the Company capitalized approximately $1.1 million and $3.3 million, respectively, of non-cash share-based compensation expense to internal-use and external-use software development costs related to internal labor. The Company did not capitalize any material non-cash share-based compensation expense to inventory during the three and nine months ended September 30, 2023 and 2022, or any material non-cash share-based compensation expense to internal-use and external-use software development costs during the three and nine months ended September 30, 2022.

[0000926326-23-000041:notes:143]
[same as prior period, unchanged from 0000926326-23-000031:notes:143]

[0000926326-23-000041:notes:144]
The following assumptions were used to value shares under the ESPP for the three and nine months ended September 30, 2023 and 2022:

[0000926326-23-000041:notes:145]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Expected life, years | 0.5 - 2.0 |  | 0.5 - 2.0 |  | 0.5 - 2.0 |  | 0.5 - 2.0 |
| Expected volatility, % | 32.0% - 63.9% |  | 28.8% - 44.8% |  | 31.7% - 63.9% |  | 28.8% - 45.6% |
| Risk-free interest rate, % | 0.2% - 5.5% |  | 0.1% - 3.2% |  | 0.1% - 5.5% |  | 0.1% - 3.2% |
| Dividend yield, % | — | % |  | — | % |  | — | % |  | — | % |

[0000926326-23-000041:notes:146]
For the nine months ended September 30, 2023 and 2022, employees purchased approximately 353,000 and 316,000 shares of common stock, respectively, under the ESPP at a weighted-average price of $46.68 and $67.63, respectively. As of September 30, 2023, the unrecognized compensation cost related to the shares to be purchased under the ESPP was approximately $2.0 million and is expected to be recognized over a weighted-average period of 1.6 years.

[0000926326-23-000041:notes:147]
[same as prior period, unchanged from 0000926326-23-000031:notes:147]

[0000926326-23-000041:notes:148]
The following assumptions were used to value stock options granted pursuant to the Company’s 2009 Equity Incentive Plan, as amended, (the “2009 Plan”) for the nine months ended September 30, 2023. There were no stock options granted during the three months ended September 30, 2023, and the three and nine months ended September 30, 2022.

[0000926326-23-000041:notes:149]
|  |  |  |  |  | Nine Months Ended September 30, |
|  |  |  |  |  |  |  | 2023 |
| Expected life, years |  |  |  |  |  |  | 3.2 |
| Expected volatility, % |  |  |  |  |  |  | 44.8 | % |
| Risk-free interest rate, % |  |  |  |  |  |  | 3.7 | % |
| Estimated forfeiture rate, % |  |  |  |  |  |  | 10.0 | % |
| Dividend yield, % |  |  |  |  |  |  | — | % |

[0000926326-23-000041:notes:150]
The following table summarizes the stock option activity under the 2009 Plan during the nine months ended September 30, 2023:

[0000926326-23-000041:notes:151]
|  | Number ofShares |  | Weighted-AverageExercise Price |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2022 | 2,434 |  |  | $ | 68.65 |  |  | 6.1 |  | $ | 7,887 |  |
| Granted | 200 |  |  | 55.60 |  |  |  |  |  |
| Exercised | (157) |  |  | 41.85 |  |  |  |  |  |
| Expired | (177) |  |  | 80.44 |  |  |  |  |  |
| Forfeited | (180) |  |  | 74.17 |  |  |  |  |  |
| Outstanding at September 30, 2023 | 2,120 |  |  | $ | 67.96 |  |  | 5.0 |  | $ | 3,418 |  |
| Exercisable at September 30, 2023 | 1,801 |  |  | $ | 66.84 |  |  | 4.9 |  | $ | 3,418 |  |
| Vested and expected to vest at September 30, 2023 and thereafter | 2,103 |  |  | $ | 67.90 |  |  | 5.0 |  | $ | 3,418 |  |

[0000926326-23-000041:notes:152]
The weighted-average fair value per share of options granted during the nine months ended September 30, 2023 was $19.48. The intrinsic value of options exercised during the three months ended September 30, 2023 and 2022 was $0.5 million and $7.6 million, respectively, and during the nine months ended September 30, 2023 and 2022 was $3.1 million and $23.1 million, respectively.

[0000926326-23-000041:notes:153]
As of September 30, 2023, total unrecognized compensation cost related to unvested stock options was $5.3 million, which is expected to be recognized over a weighted-average vesting period of 0.9 years.

[0000926326-23-000041:notes:154]
[same as prior period, unchanged from 0000926326-23-000031:notes:154]

[0000926326-23-000041:notes:155]
The following table summarizes the RSU activity under the 2009 Plan during the nine months ended September 30, 2023:

[0000926326-23-000041:notes:156]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2022 | 1,117 |  |  | $ | 115.75 |  |  | 1.6 |  | $ | 56,297 |  |
| Granted (Awarded) | 675 |  |  | 64.44 |  |  |  |  |  |
| Vested (Released) | (252) |  |  | 117.13 |  |  |  |  |  |
| Forfeited | (304) |  |  | 112.82 |  |  |  |  |  |
| Outstanding and unvested at September 30, 2023 | 1,236 |  |  | $ | 87.89 |  |  | 1.7 |  | $ | 55,649 |  |

[0000926326-23-000041:notes:157]
As of September 30, 2023, total unrecognized compensation cost related to RSUs was $78.2 million, which is expected to be recognized over the remaining weighted-average vesting period of 3.1 years.

[0000926326-23-000041:notes:158]
[same as prior period, unchanged from 0000926326-23-000031:notes:158]

[0000926326-23-000041:notes:159]
The following table summarizes the RSA activity under the 2009 Plan during the nine months ended September 30, 2023:

[0000926326-23-000041:notes:160]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2022 | 13 |  |  | $ | 109.39 |  |
| Granted (Awarded) | 24 |  |  | 70.96 |  |
| Vested (Released) | (13) |  |  | 109.39 |  |
| Outstanding and unvested at September 30, 2023 | 24 |  |  | $ | 70.96 |  |

[0000926326-23-000041:notes:161]
As of September 30, 2023, total unrecognized compensation cost related to RSAs was $1.0 million, which is expected to be recognized over the remaining weighted-average vesting period of 0.6 years.

[0000926326-23-000041:notes:162]
[same as prior period, unchanged from 0000926326-23-000031:notes:162]

[0000926326-23-000041:notes:163]
The following table summarizes the PSU activity under the 2009 Plan during the nine months ended September 30, 2023:

[0000926326-23-000041:notes:164]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2022 | 135 |  |  | $ | 147.42 |  |
| Granted | 65 |  |  | 122.29 |  |
| Vested | (35) |  |  | 127.40 |  |
| Forfeited | (66) |  |  | 153.68 |  |
| Outstanding and unvested at September 30, 2023 | 99 |  |  | $ | 129.36 |  |

[0000926326-23-000041:notes:165]
As of September 30, 2023, total unrecognized compensation cost related to PSUs was approximately $6.7 million, which is expected to be recognized over the remaining weighted-average vesting period of 1.4 years.

[0000926326-23-000041:notes:166]
[same as prior period, unchanged from 0000926326-23-000031:notes:166]

[0000926326-23-000041:notes:167]
The Company had the following ordinary shares reserved for future issuance under its equity incentive plans as of September 30, 2023:

[0000926326-23-000041:notes:168]
|  | Number of Shares |
|  | (In thousands) |
| Stock options outstanding | 2,120 |  |
| Non-vested restricted stock awards | 1,359 |  |
| Shares authorized for future issuance | 2,417 |  |
| ESPP shares available for future issuance | 3,250 |  |
| Total shares reserved for future issuance | 9,146 |  |

[0000926326-23-000041:notes:169]
[same as prior period, unchanged from 0000926326-23-000031:notes:169]

[0000926326-23-000041:notes:170]
On August 2, 2016, the Company’s Board of Directors (the “Board”) authorized a stock repurchase program providing for the repurchase of up to $50.0 million of the Company’s common stock (the “2016 Repurchase Program”). The 2016 Repurchase Program is in addition to the stock repurchase program approved by the Board on November 4, 2014 providing for the repurchase of up to $50.0 million of the Company’s common stock (the “2014 Repurchase Program”). During the first quarter of 2022, the 2014 Repurchase Program was completed, and as of September 30, 2023, the maximum dollar value of shares that may yet be purchased under the 2016 Repurchase Program was $2.7 million. The 2016 Repurchase Program does not obligate the Company to repurchase any specific number of shares, and the Company may terminate or suspend the 2016 Repurchase Program at any time.

[0000926326-23-000041:notes:171]
During the nine months ended September 30, 2022, the Company repurchased approximately 389,300 shares of its common stock under the repurchase programs at an average price of $134.11 per share for an aggregate purchase price of approximately $52.2 million. During the three and nine months ended September 30, 2023 and the three months ended September 30, 2022, the Company did not repurchase any of its outstanding common stock under the 2016 Repurchase Program.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000926326-23-000041:notes:172]
Restructuring Expenses
During the first quarter of 2022, the Company initiated certain domestic and international restructuring initiatives, in order to enhance and streamline certain engineering functions for its domestic operations, and to realign its international sales organization to better serve its customers in various international markets. During the third quarter of 2022, the Company initiated restructuring initiatives associated with the integration and functionalization of certain acquisitions, primarily the 340B Link business acquisition, to further accelerate the expansion of the Company’s pharmacy inventory management capabilities. During the three and nine months ended September 30, 2022, the restructuring plans incurred $1.8 million and $5.3 million, respectively, of employee severance costs and related expenses. As of September 30, 2023, there was no material unpaid balance related to these restructuring plans.

[0000926326-23-000041:notes:173]
On November 23, 2022, the Company committed to a plan to reduce the Company’s headcount (the “Plan”), as part of the Company’s expense containment efforts being implemented due to ongoing macroeconomic headwinds. During the first quarter of 2023, as a result of continued exploration of expense containment measures, the Company committed to further reduce its headcount across many of its functions, and also committed to reduce its real estate footprint to align with its broader hybrid work strategy and in an effort to further reduce costs. During the three months ended September 30, 2023, the Company recorded an immaterial reversal of previously recognized restructuring expenses associated with the Plan. During the nine months ended September 30, 2023, the Company incurred $5.5 million of employee severance costs and related expenses, net of reversals, in connection with the Plan. As of September 30, 2023, the Company has incurred $22.9 million of cumulative restructuring expense, net of reversals, related to employee severance costs and related expenses since the inception of the Plan. As of September 30, 2023 and December 31, 2022, the unpaid balance related to the Plan was $1.0 million and $18.2 million, respectively.

[0000926326-23-000041:notes:174]
[same as prior period, unchanged from 0000926326-23-000031:notes:174]

[0000926326-23-000041:notes:175]
The following table summarizes the total employee-related restructuring expense recognized in the Company’s Condensed Consolidated Statements of Operations for the three and nine months ended September 30, 2023 and 2022:

[0000926326-23-000041:notes:176]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  | (In thousands) |
| Cost of product and service revenues | $ | (280) |  |  | $ | 444 |  |  | $ | 102 |  |  | $ | 600 |  |
| Research and development | (25) |  |  | 272 |  |  | 467 |  |  | 1,866 |  |
| Selling, general, and administrative | (276) |  |  | 1,078 |  |  | 4,885 |  |  | 2,855 |  |
| Total restructuring expense, net of reversals | $ | (581) |  |  | $ | 1,794 |  |  | $ | 5,454 |  |  | $ | 5,321 |  |


## us-gaap:SubsequentEventsTextBlock

[0000926326-23-000041:notes:177]
Subsequent Events
Second Amended and Restated Credit Agreement

[0000926326-23-000041:notes:178]
On October 10, 2023, the Company entered into the Second A&R Credit Agreement with the lenders from time to time party thereto, Wells Fargo Securities, LLC, JPMorgan Chase Bank, N.A., PNC Capital Markets LLC and TD Securities (USA) LLC as joint lead arrangers and Wells Fargo Bank, National Association, as administrative agent. The Second A&R Credit Agreement supersedes the Company’s Prior A&R Credit Agreement. Refer to Note 9, Debt and Credit Agreement, for additional information.

[0000926326-23-000041:notes:179]
Restructuring Plan

[0000926326-23-000041:notes:180]
On November 2, 2023, the Company announced a plan to reduce the Company’s headcount and real estate footprint (the “2023 Plan”) as part of the Company’s expense containment initiatives and other actions to reduce discretionary spending being implemented due to challenging industry dynamics and macroeconomic conditions. In connection with the 2023 Plan, the Company estimates that it will incur approximately $12 million to $18 million of nonrecurring restructuring and related charges, consisting of (i) approximately $9 million to $12 million of cash-based charges related to the reduction in headcount, which primarily consist of employee severance and benefits costs and (ii) approximately $3 million to $6 million of non-cash charges related to office closure, which the Company expects to incur the majority of charges in the fourth quarter of 2023 with remaining charges incurred in future periods. The Company expects to substantially complete the 2023 Plan, including cash payments, by the end of the second quarter of 2024, subject to local laws and consultation requirements.
