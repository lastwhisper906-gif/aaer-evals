# OMCL 8-K — 0001104659-23-113604 filed 2023-11-02

## item codes, every 8-K on or before 2023-11-03

- 2023-11-02 0001104659-23-113604 — 2.02, 2.05, 7.01, 9.01
- 2023-10-16 0000926326-23-000039 — 1.01, 2.03, 9.01
- 2023-10-05 0000926326-23-000037 — 5.02, 9.01
- 2023-08-16 0000926326-23-000035 — 5.02
- 2023-08-10 0000926326-23-000033 — 5.02, 9.01
- 2023-08-03 0000926326-23-000029 — 5.02, 9.01
- 2023-08-01 0000926326-23-000027 — 2.02, 9.01
- 2023-07-11 0000926326-23-000025 — 5.02, 9.01
- 2023-06-26 0000926326-23-000022 — 5.02 — amendment of 0001104659-23-026700
- 2023-05-30 0001104659-23-066011 — 5.02, 9.01
- 2023-05-26 0000926326-23-000020 — 5.02, 5.07, 9.01
- 2023-05-15 0001104659-23-060768 — 5.02, 9.01
- 2023-05-02 0000926326-23-000011 — 2.02, 9.01
- 2023-04-03 0000926326-23-000009 — 1.01, 2.03, 9.01
- 2023-02-28 0001104659-23-026700 — 2.02, 2.05, 5.02, 9.01
- 2022-11-30 0000926326-22-000036 — 2.05
- 2022-11-02 0000926326-22-000031 — 2.02, 9.01
- 2022-10-21 0000926326-22-000029 — 5.03, 9.01
- 2022-09-20 0001104659-22-101566 — 7.01, 9.01
- 2022-09-20 0001104659-22-101360 — 7.01, 9.01
- 2022-08-04 0000926326-22-000025 — 2.02, 8.01, 9.01
- 2022-05-31 0000926326-22-000020 — 5.02, 5.07, 9.01
- 2022-05-24 0000926326-22-000016 — 5.02
- 2022-05-09 0000926326-22-000012 — 8.01
- 2022-04-28 0000926326-22-000009 — 2.02, 9.01
- 2022-03-01 0001104659-22-028681 — 5.02, 8.01, 9.01
- 2022-02-14 0000926326-22-000004 — 2.02, 9.01
- 2022-01-04 0000926326-22-000002 — 7.01, 9.01
- 2021-12-29 0001104659-21-154294 — 7.01, 9.01
- 2021-12-13 0000926326-21-000039 — 8.01
- 2021-12-02 0000926326-21-000037 — 7.01, 9.01
- 2021-11-02 0000926326-21-000031 — 2.02, 9.01
- 2021-09-09 0000926326-21-000028 — 7.01, 9.01
- 2021-07-29 0000926326-21-000024 — 2.02, 9.01
- 2021-07-26 0000926326-21-000022 — 7.01, 9.01
- 2021-07-12 0000926326-21-000019 — 5.02, 9.01
- 2021-05-28 0000926326-21-000015 — 5.07
- 2021-04-29 0000926326-21-000011 — 2.02, 9.01
- 2021-02-01 0000926326-21-000004 — 2.02, 9.01
- 2021-01-26 0000926326-21-000002 — 5.02
- 2021-01-13 0001104659-21-003672 — 2.02, 7.01, 9.01
- 2020-10-27 0000926326-20-000032 — 2.02, 9.01
- 2020-10-01 0000926326-20-000029 — 7.01, 9.01
- 2020-09-25 0001104659-20-108924 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2020-09-22 0001104659-20-107176 — 1.01, 8.01, 9.01
- 2020-08-12 0000926326-20-000027 — 2.03
- 2020-08-12 0000926326-20-000025 — 1.01, 5.03, 7.01, 9.01
- 2020-07-28 0000926326-20-000021 — 2.02, 9.01
- 2020-05-27 0000926326-20-000017 — 5.07
- 2020-05-07 0000926326-20-000012 — 2.02, 9.01
- 2020-02-18 0000926326-20-000007 — 5.02, 9.01
- 2020-02-13 0000926326-20-000005 — 8.01
- 2020-02-06 0000926326-20-000003 — 2.02, 9.01
- 2019-12-06 0001104659-19-070339 — 8.01
- 2019-11-18 0000926326-19-000035 — 1.01, 2.03, 9.01
- 2019-10-24 0000926326-19-000028 — 2.02, 9.01
- 2019-07-25 0000926326-19-000021 — 2.02, 9.01
- 2019-05-15 0000926326-19-000015 — 5.07
- 2019-04-25 0000926326-19-000011 — 2.02, 9.01
- 2019-03-08 0000926326-19-000009 — 5.02, 9.01
- 2019-02-19 0000926326-19-000005 — 5.02, 9.01
- 2019-02-07 0000926326-19-000003 — 2.02, 9.01
- 2018-10-25 0000926326-18-000028 — 2.02, 9.01
- 2018-09-14 0001104659-18-056929 — 5.02, 9.01
- 2018-07-26 0000926326-18-000022 — 2.02, 9.01
- 2018-06-06 0000926326-18-000019 — 5.02, 9.01
- 2018-05-16 0001104659-18-033801 — 5.07
- 2018-04-26 0000926326-18-000013 — 2.02, 9.01
- 2018-03-02 0001104659-18-014497 — 5.02
- 2018-02-08 0000926326-18-000007 — 5.02
- 2018-02-02 0000926326-18-000005 — 5.02
- 2018-02-01 0000926326-18-000003 — 2.02, 9.01
- 2017-12-26 0000926326-17-000041 — 1.01, 2.03, 9.01
- 2017-11-03 0001104659-17-066102 — 1.01, 8.01, 9.01
- 2017-10-26 0000926326-17-000035 — 2.02, 9.01
- 2017-08-03 0000926326-17-000028 — 5.07 — amendment, the index does not say of what
- 2017-07-27 0000926326-17-000026 — 2.02, 9.01
- 2017-07-25 0000926326-17-000023 — 5.02, 9.01
- 2017-05-24 0000926326-17-000019 — 5.07
- 2017-05-04 0001628280-17-004851 — 2.02, 9.01
- 2017-02-15 0000926326-17-000010 — 2.05
- 2017-02-15 0000926326-17-000008 — 2.02, 9.01
- 2017-02-13 0000926326-17-000002 — 5.02
- 2016-12-08 0001104659-16-161330 — 2.01, 2.03, 9.01
- 2016-12-06 0001104659-16-160709 — 7.01
- 2016-11-29 0001104659-16-159456 — 1.01, 7.01, 9.01
- 2016-10-27 0000926326-16-000075 — 2.02, 9.01
- 2016-10-07 0000926326-16-000072 — 5.02, 8.01
- 2016-08-05 0000926326-16-000068 — 8.01
- 2016-07-28 0000926326-16-000066 — 2.02, 9.01
- 2016-06-13 0001104659-16-126854 — 5.02
- 2016-05-25 0000926326-16-000060 — 5.07
- 2016-04-28 0000926326-16-000054 — 2.02, 9.01
- 2016-03-21 0001104659-16-106649 — 8.01, 9.01
- 2016-03-17 0000926326-16-000051 — 7.01, 9.01
- 2016-03-17 0000926326-16-000049 — 9.01 — amendment of 0000926326-16-000051
- 2016-02-10 0001104659-16-095486 — 5.02, 9.01
- 2016-02-04 0000926326-16-000041 — 2.02, 9.01
- 2016-01-06 0001104659-16-088299 — 1.01, 2.01, 2.03, 9.01
- 2015-12-10 0000926326-15-000038 — 8.01, 9.01
- 2015-10-29 0001104659-15-074138 — 1.01, 9.01
- 2015-10-29 0000926326-15-000031 — 2.02, 9.01
- 2015-08-20 0001104659-15-061135 — 5.02, 9.01
- 2015-07-30 0000926326-15-000024 — 2.02, 9.01
- 2015-05-22 0001104659-15-040440 — 5.07
- 2015-05-01 0001104659-15-032846 — 5.02
- 2015-05-01 0001104659-15-032844 — 7.01
- 2015-04-30 0000926326-15-000015 — 9.01
- 2015-04-22 0001104659-15-029356 — 8.01, 9.01
- 2015-03-20 0001104659-15-021435 — 3.01
- 2015-03-18 0001104659-15-020699 — 7.01
- 2015-03-17 0001104659-15-020483 — 8.01, 9.01
- 2015-03-02 0001104659-15-015802 — 1.01, 9.01
- 2015-02-12 0001104659-15-009234 — 5.02, 9.01
- 2015-02-03 0000926326-15-000003 — 9.01
- 2015-01-15 0001104659-15-002635 — 5.02
- 2014-11-07 0001104659-14-078398 — 1.01, 8.01, 9.01
- 2014-10-30 0000926326-14-000037 — 2.02, 9.01
- 2014-08-25 0001104659-14-062772 — 8.01, 9.01
- 2014-07-31 0000926326-14-000032 — 2.02, 9.01
- 2014-05-21 0001104659-14-040744 — 5.07
- 2014-05-01 0000926326-14-000008 — 2.02, 9.01
- 2014-04-08 0001104659-14-026441 — 4.01, 9.01
- 2014-04-02 0001104659-14-025179 — 5.02
- 2014-02-07 0001104659-14-007552 — 5.02, 9.01
- 2014-02-04 0001104659-14-006352 — 2.02, 9.01
- 2013-12-09 0001104659-13-088980 — 1.01, 9.01
- 2013-12-02 0001104659-13-087877 — 5.02
- 2013-10-31 0001104659-13-079660 — 2.02, 9.01
- 2013-09-26 0001104659-13-072435 — 1.01, 2.03, 9.01
- 2013-08-01 0001104659-13-058959 — 2.02, 9.01
- 2013-05-23 0001104659-13-044317 — 5.07
- 2013-05-02 0001104659-13-036605 — 2.02, 9.01
- 2013-03-11 0001104659-13-019143 — 8.01
- 2013-02-07 0001104659-13-008477 — 5.02, 9.01
- 2013-01-31 0001104659-13-006446 — 2.02, 9.01
- 2012-11-02 0001104659-12-073697 — 5.02
- 2012-10-25 0001104659-12-071211 — 2.02, 9.01
- 2012-08-06 0001104659-12-054635 — 8.01
- 2012-08-03 0001104659-12-054214 — 2.01, 9.01 — amendment of 0001104659-12-038888
- 2012-08-01 0001104659-12-053005 — 2.02, 9.01
- 2012-06-12 0001104659-12-042936 — 8.01, 9.01
- 2012-05-23 0001104659-12-039459 — 5.07
- 2012-05-22 0001104659-12-038888 — 2.01, 9.01
- 2012-05-02 0001104659-12-032048 — 2.02, 9.01
- 2012-05-02 0001104659-12-032036 — 1.01, 9.01
- 2012-04-04 0001104659-12-023883 — 5.02, 8.01
- 2012-03-20 0001104659-12-019462 — 1.01, 9.01
- 2012-02-13 0001104659-12-009353 — 5.02, 9.01
- 2012-01-26 0001104659-12-004244 — 2.02, 9.01
- 2011-10-27 0001104659-11-058464 — 2.02, 9.01
- 2011-10-25 0001104659-11-057721 — 1.01
- 2011-07-28 0001104659-11-041505 — 2.02, 9.01
- 2011-05-27 0001104659-11-032006 — 5.07
- 2011-05-02 0001104659-11-024908 — 2.02, 9.01
- 2011-04-15 0001104659-11-020407 — 5.02, 9.01 — amendment of 0001104659-11-005638
- 2011-02-08 0001104659-11-005638 — 5.02, 9.01
- 2011-01-27 0001104659-11-003419 — 2.02, 9.01
- 2010-12-22 0001104659-10-064003 — 5.02, 5.07, 9.01
- 2010-10-27 0001104659-10-054036 — 2.02, 9.01
- 2010-10-05 0001104659-10-051173 — 8.01
- 2010-07-22 0001104659-10-039126 — 2.02, 9.01
- 2010-07-09 0001104659-10-037594 — 2.05
- 2010-05-28 0001104659-10-031607 — 5.07
- 2010-04-26 0001104659-10-021797 — 2.02, 9.01
- 2010-03-17 0001104659-10-014849 — 5.02, 9.01
- 2010-02-08 0001104659-10-005457 — 5.02, 9.01
- 2010-01-28 0001104659-10-003627 — 2.02, 9.01
- 2009-10-22 0001104659-09-059972 — 2.02, 9.01
- 2009-07-23 0001104659-09-044508 — 2.02, 9.01
- 2009-05-20 0001104659-09-033938 — 5.02, 9.01
- 2009-04-30 0001104659-09-027707 — 2.02, 9.01
- 2009-03-10 0001104659-09-016178 — 5.02, 9.01
- 2009-02-09 0001104659-09-007692 — 5.02, 9.01
- 2009-01-29 0001104659-09-005022 — 2.02, 2.05, 9.01
- 2009-01-21 0001104659-09-003180 — 2.02, 8.01, 9.01
- 2009-01-06 0001104659-09-000625 — 5.02
- 2008-10-23 0001104659-08-065475 — 2.02, 9.01
- 2008-07-21 0001104659-08-046690 — 2.02, 9.01
- 2008-05-16 0001104659-08-034035 — 8.01, 9.01
- 2008-04-28 0001104659-08-027379 — 7.01, 9.01
- 2008-04-21 0001104659-08-025616 — 2.02, 9.01
- 2008-03-12 0001104659-08-016939 — 7.01, 9.01
- 2008-02-26 0001104659-08-012840 — 7.01, 9.01
- 2008-02-12 0001104659-08-009382 — 5.02, 9.01
- 2008-01-31 0001104659-08-006199 — 2.02, 9.01
- 2007-12-05 0001104659-07-087191 — 1.01, 9.01
- 2007-10-18 0001104659-07-075654 — 2.02, 9.01
- 2007-07-27 0001104659-07-056886 — 5.03, 9.01
- 2007-07-19 0001104659-07-054924 — 2.02, 9.01
- 2007-05-23 0001104659-07-042287 — 8.01, 9.01
- 2007-05-07 0001104659-07-036172 — 1.01, 5.02, 9.01
- 2007-04-24 0001104659-07-030578 — 2.02, 9.01 — amendment, the index does not say of what
- 2007-04-24 0001104659-07-030547 — 2.02, 9.01
- 2007-04-10 0001104659-07-027465 — 5.02, 9.01
- 2007-03-23 0001104659-07-021969 — 2.02, 4.02, 9.01
- 2007-01-30 0001104659-07-005772 — 2.02, 9.01
- 2007-01-09 0001104659-07-001600 — 5.02, 9.01
- 2006-10-30 0001104659-06-069612 — 1.01
- 2006-10-19 0001104659-06-067549 — 2.02, 9.01
- 2006-07-20 0001104659-06-048020 — 2.02, 4.02, 9.01
- 2006-05-17 0001104659-06-035522 — 1.01, 9.01 — amendment of 0001104659-05-011155
- 2006-05-09 0001104659-06-032706 — 1.01, 9.01
- 2006-04-25 0001104659-06-027438 — 2.02, 9.01
- 2006-04-04 0001104659-06-022204 — 1.01, 9.01
- 2006-03-15 0001104659-06-016861 — 1.01, 9.01
- 2006-01-30 0001104659-06-004749 — 2.02, 9.01
- 2006-01-24 0001104659-06-003504 — 1.01, 5.02, 9.01
- 2005-12-13 0001104659-05-060532 — 1.01, 9.01
- 2005-11-10 0001104659-05-054663 — 2.02, 9.01
- 2005-07-21 0001104659-05-033464 — 2.02, 9.01
- 2005-06-22 0001104659-05-029255 — 1.01
- 2005-05-16 0001104659-05-023473 — 2.02, 9.01 — amendment of 0001104659-05-018173
- 2005-05-16 0001104659-05-023471 — 2.02, 9.01 — amendment of 0001104659-05-017382
- 2005-05-10 0001104659-05-022127 — 1.01
- 2005-04-26 0001104659-05-018173 — 2.02, 9.01
- 2005-04-21 0001104659-05-017382 — 2.02, 9.01
- 2005-04-06 0001104659-05-015401 — 5.02
- 2005-03-15 0001104659-05-011155 — 1.01, 9.01
- 2005-03-08 0001104659-05-009975 — 1.01, 9.01
- 2005-02-03 0001104659-05-003943 — 2.02, 9.01
- 2005-01-13 0001104659-05-001314 — 5.02, 9.01
- 2004-10-21 0001104659-04-031413 — 2.02, 9.01
- 2004-07-22 0001104659-04-020572 — 12, 7
- 2004-04-14 0001104659-04-010039 — 12, 7
- 2004-04-05 0001104659-04-009437 — 12, 7
- 2004-01-26 0001104659-04-001655 — 12, 7
- 2003-10-16 0001104659-03-022990 — 12, 7
- 2003-07-17 0001104659-03-015053 — 9
- 2003-04-18 0001104659-03-006823 — 7, 9
- 2003-02-14 0001104659-03-002607 — 5, 7

## late-filing notifications on or before 2023-11-03

- 2015-03-02 0000926326-15-000006 — NT 10-K, for the period ended 2014-12-31
- 2007-03-16 0001104659-07-020094 — NT 10-K, for the period ended 2006-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001104659-23-113604:8k_2_02:1]
EX-99.1
2
tm2329352d1_ex99-1.htm
EXHIBIT 99.1

[0001104659-23-113604:8k_2_02:2]
Exhibit 99.1

[0001104659-23-113604:8k_2_02:3]
| Contact: |  |  |
| Kathleen Nemeth |  | Omnicell, Inc. |
| Senior Vice President, Investor Relations |  | 4220 North Freeway |
| 650-435-3318 |  | Fort Worth, TX 76137 |
| Kathleen.Nemeth@Omnicell.com |  |  |

[0001104659-23-113604:8k_2_02:4]
Omnicell Announces
Third Quarter 2023 Results;

[0001104659-23-113604:8k_2_02:5]
Updates Fiscal
Year 2023 Guidance and Announces Reduction in Force

[0001104659-23-113604:8k_2_02:6]
Total GAAP revenues
of $299 million

[0001104659-23-113604:8k_2_02:7]
GAAP net income
per diluted share of $0.

[0001104659-23-113604:8k_2_02:8]
|  | 1 |  |

[0001104659-23-113604:8k_2_02:9]
2

[0001104659-23-113604:8k_2_02:10]
Non-GAAP net
income per diluted share of $0.62

[0001104659-23-113604:8k_2_02:11]
FORT
WORTH, Texas -- November 2, 2023 -- Omnicell, Inc. (NASDAQ:OMCL) (“Omnicell,”
 “we,” “our,” “us,” “management,” or the “Company”), a leader in transforming
the pharmacy care delivery model, today announced results for its third quarter ended September 30, 2023.

[0001104659-23-113604:8k_2_02:12]
Randall Lipps, chairman, president,
chief executive officer, and founder of Omnicell, said, “The team delivered strong cost management and operational discipline this
quarter. However, I am disappointed with the weakness in demand that we are seeing and accordingly, we have updated our near-term
outlook. We are taking actions to manage the business that are intended to reduce our cost structure and to better align with our anticipated
top line performance heading into 2024, while also positioning the Company to continue investing in our innovation agenda. We have taken
steps to strengthen our leadership team and we have already begun to reduce discretionary expenses. We remain encouraged that hospitals,
health systems, and retail pharmacies continue to rely on Omnicell to help them improve patient and health system outcomes — especially
during this dynamic time in the industry. The need for the healthcare industry to automate, optimize, and modernize is more important
than ever and we believe Omnicell is well positioned to deliver value to all of our stakeholders over the long-term.”

[0001104659-23-113604:8k_2_02:13]
Financial Results

[0001104659-23-113604:8k_2_02:14]
Total GAAP revenues for the third quarter
of 2023 were $299 million, down $49 million, or 14%, from the third quarter of 2022. The year-over-year decrease in total GAAP revenues
reflects lower point-of-care revenues primarily as a result of ongoing health systems capital budget and labor constraints.

[0001104659-23-113604:8k_2_02:15]
Total GAAP net income for the third
quarter of 2023 was $6 million, or $0.12 per diluted share. This compares to GAAP net income of $17 million, or $0.37 per diluted share,
for the third quarter of 2022.

[0001104659-23-113604:8k_2_02:16]
Total non-GAAP net income for the third
quarter of 2023 was $28 million, or $0.62 per diluted share. This compares to non-GAAP net income of $45 million, or $1.00 per diluted
share, for the third quarter of 2022.

[0001104659-23-113604:8k_2_02:17]
Total non-GAAP EBITDA for the third
quarter of 2023 was $41 million. This compares to non-GAAP EBITDA of $61 million for the third quarter of 2022.

[0001104659-23-113604:8k_2_02:18]
Balance Sheet

[0001104659-23-113604:8k_2_02:19]
As of September 30, 2023, Omnicell’s
balance sheet reflected cash and cash equivalents of $447 million, total debt (net of unamortized debt issuance costs) of $569 million,
and total assets of $2.22 billion. Cash flows provided by operating activities in the third quarter of 2023 totaled $57 million. This
compares to cash flows provided by operating activities totaling $21 million in the third quarter of 2022.

[0001104659-23-113604:8k_2_02:20]
1

[0001104659-23-113604:8k_2_02:21]
As of September 30, 2023, the Company
had $500 million of availability under its revolving credit facility with no outstanding balance. Subsequent to the quarter end,
on October 10, 2023, the Company refinanced its revolving credit facility to provide for $350 million of funds available, which
availability is subject to reduction in order to maintain compliance with certain financial covenants.

[0001104659-23-113604:8k_2_02:22]
Corporate Highlights

[0001104659-23-113604:8k_2_02:23]
|  | · | Health systems continue to choose Omnicell as a long-term partner for their pharmacy technology strategy, with several customers extending their sole-source agreements and one competitive conversion achieved during the quarter. |

[0001104659-23-113604:8k_2_02:24]
|  | · | Omnicell’s Central Pharmacy Dispensing Service appears to be gaining momentum in the market as many health systems seem to be recognizing the benefits to patient safety and workflow efficiency of automating central pharmacy operations through a comprehensive solution encompassing advanced robotics, dispensing optimization tools, and expert services. |

[0001104659-23-113604:8k_2_02:25]
|  | · | As health systems expand pharmacy care beyond the four walls of the hospital, Omnicell’s Specialty Pharmacy Services offering should provide a revenue-generating opportunity, while helping to support important patient care initiatives. Health systems are choosing Omnicell’s management services expertise to help drive financial and clinical outcomes for this rapidly growing area of healthcare. |

[0001104659-23-113604:8k_2_02:26]
Restructuring

[0001104659-23-113604:8k_2_02:27]
Omnicell plans to take action as it
relates to cost containment across the business, including a headcount reduction across our business functions, and is expecting approximately
$1

[0001104659-23-113604:8k_2_02:28]
|  | 2 |  |

[0001104659-23-113604:8k_2_02:29]
million - $18 million of non-recurring restructuring and related charges related to the cost containment plan. The Company expects
to incur a majority of the charges in fourth quarter of 2023 and substantially complete the plan by end of second quarter of 2024, subject
to local law and consultation requirement. Annualized cost savings of $45 million - $55 million, approximately 75 percent of which are
expected to be in Operating Expenses, are expected. A majority of the benefit from the cost actions is anticipated to be realized beginning
in the first quarter of 2024 with a smaller portion of the savings expected as the year progresses.  The cost actions should be
partially offset by year over year increases in compensation and vendor price increases.

[0001104659-23-113604:8k_2_02:30]
Updated 2023 Guidance

[0001104659-23-113604:8k_2_02:31]
For the full year 2023, the Company
expects bookings to be between $850 million and $950 million. The Company expects full year 2023 total revenues to be between $1.135
billion and $1.155 billion. The Company expects full year 2023 product revenues to be between $705 million and $715 million, and full
year 2023 service revenues to be between $430 million and $440 million. The Company expects full year 2023 technical services revenues
to be between $222 million and $227 million, and full year 2023 Advanced Services revenues to be between $208 million and $213 million.
The Company expects full year 2023 non-GAAP EBITDA to be between $123 million and $133 million. The Company expects full year 2023 non-GAAP
earnings per share to be between $1.65 and $1.80 per share.

[0001104659-23-113604:8k_2_02:32]
For the fourth quarter of 2023, the
Company expects total revenues to be between $247 million and $267 million. The Company expects fourth quarter 2023 product revenues
to be between $142 million and $152 million, and fourth quarter 2023 service revenues to be between $105 million and $115 million. The
Company expects fourth quarter 2023 non-GAAP EBITDA to be between $9 million and $19 million. The Company expects fourth quarter 2023
non-GAAP earnings per share to be between $0.07 and $0.22 per share.

[0001104659-23-113604:8k_2_02:33]
The Company’s fourth quarter and
full year 2023 guidance has been adjusted to include the anticipated effects and expected impact of current macroeconomic headwinds.

[0001104659-23-113604:8k_2_02:34]
2

[0001104659-23-113604:8k_2_02:35]
The table below summarizes Omnicell’s
fourth quarter and updated full year 2023 guidance outlined above.

[0001104659-23-113604:8k_2_02:36]
|  | Q4’23 | 2023 |
| Bookings | Not guided | $850 million - $950 million |
| Total Revenues | $247 million - $267 million | $1.135 billion - $1.155 billion |
| Product Revenues | $142 million - $152 million | $705 million - $715 million |
| Service Revenues | $105 million - $115 million | $430 million - $440 million |
| Technical Services Revenues | Not guided | $222 million - $227 million |
| Advanced Services Revenues | Not guided | $208 million - $213 million |
| Non-GAAP EBITDA | $9 million - $19 million | $123 million - $133 million |
| Non-GAAP Earnings Per Share | $0.07 - $0.22 | $1.65 - $1.80 |

[0001104659-23-113604:8k_2_02:37]
The Company does not provide guidance
for GAAP net income or GAAP earnings per share, nor a reconciliation of these forward-looking non-GAAP financial measures to the most
directly comparable GAAP financial measures on a forward-looking basis because it is unable to predict certain items contained in the
GAAP measures without unreasonable efforts. These forward-looking non-GAAP financial measures do not include certain items, which may
be significant, including, but not limited to, unusual gains and losses, costs associated with future restructurings, acquisition-related
expenses, and certain tax and litigation outcomes.

[0001104659-23-113604:8k_2_02:38]
Omnicell Conference Call Information

[0001104659-23-113604:8k_2_02:39]
Omnicell will hold a conference call
today, Thursday, November 2, 202

[0001104659-23-113604:8k_2_02:40]
|  | 3 |  |

[0001104659-23-113604:8k_2_02:41]
at 8:30 a.m. ET to discuss third quarter 2023 financial results. The conference call
can be monitored by dialing (888) 550-5

[0001104659-23-113604:8k_2_02:42]
|  | 4 |  |

[0001104659-23-113604:8k_2_02:43]
24 in the U.S. or (646) 960-0819 in international locations. The Conference ID is 9581556. A
link to the live and archived webcast will also be available on the Investor Relations section of Omnicell’s website at http://ir.omnicell.com/events-and-presentations/.

[0001104659-23-113604:8k_2_02:44]
About Omnicell

[0001104659-23-113604:8k_2_02:45]
Since 1992, Omnicell has been committed
to transforming the pharmacy care delivery model in an effort to optimize financial and clinical outcomes across all settings of care.
Through a comprehensive portfolio of automation and advanced services, Omnicell is uniquely positioned to address evolving healthcare
challenges, connect settings of care, and streamline the medication management process. Healthcare facilities worldwide partner with
Omnicell to help increase operational efficiency, reduce medication errors, improve patient safety, and enhance patient engagement and
adherence, helping to reduce costly hospital readmissions. To learn more, visit omnicell.com.

[0001104659-23-113604:8k_2_02:46]
From time to time, Omnicell may use
the Company’s investor relations website and other online social media channels, including its Twitter handle www.twitter.com/omnicell,
LinkedIn page www.linkedin.com/company/omnicell, and Facebook page www.facebook.com/omnicellinc, to disclose material non-public
information and comply with its disclosure obligations under Regulation Fair Disclosure (“Reg FD”).

[0001104659-23-113604:8k_2_02:47]
OMNICELL and the Omnicell logo are registered
trademarks of Omnicell, Inc. or one of its subsidiaries.

[0001104659-23-113604:8k_2_02:48]
3

[0001104659-23-113604:8k_2_02:49]
Forward-Looking Statements

[0001104659-23-113604:8k_2_02:50]
Use of Non-GAAP Financial Information

[0001104659-23-113604:8k_2_02:51]
This press release contains financial
measures that are not calculated in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”). Management evaluates
and makes operating decisions using various performance measures. In addition to Omnicell’s GAAP results, we also consider non-GAAP
revenues, non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP operating
margin, non-GAAP net income, non-GAAP net income per diluted share, non-GAAP diluted shares, non-GAAP EBITDA, non-GAAP EBITDA margin,
and non-GAAP free cash flow. These non-GAAP results and metrics should not be considered as an alternative to revenues, gross profit,
operating expenses, income from operations, net income, net income per diluted share, diluted shares, net cash provided by operating
activities, or any other performance measure derived in accordance with GAAP. We present these non-GAAP results and metrics because management
considers them to be important supplemental measures of Omnicell’s performance and refers to such measures when analyzing Omnicell’s
strategy and operations.

[0001104659-23-113604:8k_2_02:52]
4

[0001104659-23-113604:8k_2_02:53]
Our non-GAAP revenues, non-GAAP gross
profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP operating margin, non-GAAP net
income, non-GAAP net income per diluted share, non-GAAP EBITDA, and non-GAAP EBITDA margin are exclusive of certain items to facilitate
management’s review of the comparability of Omnicell’s core operating results on a period-to-period basis because such items
are not related to Omnicell’s ongoing core operating results as viewed by management. We define our “core operating results”
as those revenues recorded in a particular period and the expenses incurred within such period that directly drive operating income in
such period. Management uses these non-GAAP financial measures in making operating decisions because, in addition to meaningful supplemental
information regarding operating performance, the measures give us a better understanding of how we believe we should invest in research
and development, fund infrastructure growth, and evaluate the effectiveness of marketing strategies. In calculating the above non-GAAP
results: non-GAAP revenues excludes from its GAAP equivalent item a) below; non-GAAP gross profit and non-GAAP gross margin exclude from
their GAAP equivalents items a), b), c), f), and h) below; non-GAAP operating expenses excludes from its GAAP equivalents items b), c),
d), e), f), g), h), and j) below; non-GAAP income from operations and non-GAAP operating margin exclude from their GAAP equivalents items
a), b), c), d), e), f), g), h) and j) below; and non-GAAP net income and non-GAAP net income per diluted share exclude from their GAAP
equivalents items a) through j) below. Non-GAAP EBITDA is defined as earnings before interest income and expense, taxes, depreciation,
amortization, and share-based compensation, as well as excluding certain other non-GAAP adjustments. Non-GAAP EBITDA and non-GAAP EBITDA
margin exclude from their GAAP equivalents items a), b), d), e), f), g), h), i), and j) below:

[0001104659-23-113604:8k_2_02:54]
|  | a) | Acquisition accounting impact related to deferred revenues. In connection with the acquisition of FDS Amplicare on September 9, 2021, we recorded a fair value adjustment to acquired deferred revenues as part of the purchase accounting in accordance with GAAP. The adjustment represents revenues that would have been recognized in the normal course of business by FDS Amplicare if the acquisition had not occurred, but was not recognized due to GAAP purchase accounting requirements. The non-GAAP adjustment to our revenues is intended to include the full amounts of such revenues. We believe the adjustment to these revenues is useful as a measure of the ongoing performance of our business. |

[0001104659-23-113604:8k_2_02:55]
|  | b) | Share-based compensation expense. We excluded from our non-GAAP results the expense related to equity-based compensation plans as it represents expenses that do not require cash settlement from Omnicell. |

[0001104659-23-113604:8k_2_02:56]
|  | c) | Amortization of acquired intangible assets. We excluded from our non-GAAP results the intangible assets amortization expense resulting from our past acquisitions. These non-cash charges are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results. |

[0001104659-23-113604:8k_2_02:57]
|  | d) | Acquisition-related expenses. We excluded from our non-GAAP results the expenses related to recent acquisitions, including amortization of representations and warranties insurance. These expenses are unrelated to our ongoing operations, vary in size and frequency, and are subject to significant fluctuations from period to period due to varying levels of acquisition activity. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of less acquisitive peer companies. |

[0001104659-23-113604:8k_2_02:58]
|  | e) | Impairment and abandonment of operating lease right-of-use and other assets related to facilities. We excluded from our non-GAAP results the impairment and abandonment of certain operating lease right-of-use assets, as well as property and equipment, incurred in connection with restructuring activities for optimization of certain leased facilities. These non-cash charges are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results. |

[0001104659-23-113604:8k_2_02:59]
|  | f) | Ransomware-related expenses, net of insurance recoveries. We excluded from our non-GAAP results the net expenses related to the previously disclosed ransomware incident identified by the Company on May 4, 2022. Expenses include costs to investigate and remediate the ransomware incident, as well as legal and other professional services, and are presented net of expected insurance recoveries. These expenses are unrelated to our ongoing operations and would not have otherwise been incurred by us in the normal course of business. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of peer companies. |

[0001104659-23-113604:8k_2_02:60]
|  | 5 |  |

[0001104659-23-113604:8k_2_02:61]
|  | g) | Executives transition costs. We excluded from our non-GAAP results the executives transition costs associated with the departure of certain executive officers, primarily consisting of severance expenses. These expenses are unrelated to our ongoing operations and we do not expect them to occur in the ordinary course of business. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of peer companies. |

[0001104659-23-113604:8k_2_02:62]
|  | h) | Severance-related expenses. We excluded from our non-GAAP results the expenses related to restructuring events, partially offset by reversals of previously recognized severance expenses in subsequent periods. These expenses are unrelated to our ongoing operations, vary in size and frequency, and are subject to significant fluctuations from period to period due to varying levels of restructuring activity. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of peer companies. |

[0001104659-23-113604:8k_2_02:63]
|  | i) | Amortization of debt issuance costs. Debt issuance costs represent costs associated with the issuance of term loan and revolving credit facilities, as well as the issuance of convertible senior notes. The costs include underwriting fees, original issue discount, ticking fees, and legal fees. These non-cash expenses are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results. |

[0001104659-23-113604:8k_2_02:64]
|  | j) | Certain litigation costs. We excluded non-recurring charges and benefits, including litigation expenses and settlements, related to litigation matters that are outside of the ordinary course of our business or that are not representative of those that we historically have incurred. These expenses are unrelated to our ongoing operations and we do not expect them to occur in the ordinary course of business. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of peer companies. |

[0001104659-23-113604:8k_2_02:65]
Management adjusts for the above items
because management believes that, in general, these items possess one or more of the following characteristics: their magnitude and timing
is largely outside of Omnicell’s control; they are unrelated to the ongoing operation of the business in the ordinary course; they
are unusual and we do not expect them to occur in the ordinary course of business; or they are non-operational or non-cash expenses involving
stock compensation plans or other items.

[0001104659-23-113604:8k_2_02:66]
We believe that the presentation of
non-GAAP revenues, non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP
operating margin, non-GAAP net income, non-GAAP net income per diluted share, non-GAAP EBITDA, and non-GAAP EBITDA margin is warranted
for several reasons:

[0001104659-23-113604:8k_2_02:67]
|  | a) | Such non-GAAP financial measures provide an additional analytical tool for understanding Omnicell’s financial performance by excluding the impact of items which may obscure trends in the core operating results of the business. |

[0001104659-23-113604:8k_2_02:68]
|  | b) | Since we have historically reported non-GAAP results to the investment community, we believe the inclusion of non-GAAP numbers provides consistency and enhances investors’ ability to compare our performance across financial reporting periods. |

[0001104659-23-113604:8k_2_02:69]
|  | c) | These non-GAAP financial measures are employed by management in its own evaluation of performance and are utilized in financial and operational decision-making processes, such as budget planning and forecasting. |

[0001104659-23-113604:8k_2_02:70]
|  | d) | These non-GAAP financial measures facilitate comparisons to the operating results of other companies in our industry, which also use non-GAAP financial measures to supplement their GAAP results (although these companies may calculate non-GAAP financial measures differently than Omnicell does), thus enhancing the perspective of investors who wish to utilize such comparisons in their analysis of our performance. |

[0001104659-23-113604:8k_2_02:71]
Set forth below are additional reasons
why share-based compensation expense is excluded from our non-GAAP financial measures:

[0001104659-23-113604:8k_2_02:72]
|  | i) | While share-based compensation calculated in accordance with Accounting Standards Codification (“ASC”) 718 constitutes an ongoing and recurring expense of Omnicell, it is not an expense that requires cash settlement by Omnicell. We therefore exclude these charges for purposes of evaluating core operating results. Thus, our non-GAAP measurements are presented exclusive of share-based compensation expense to assist management and investors in evaluating our core operating results. |

[0001104659-23-113604:8k_2_02:73]
|  | 6 |  |

[0001104659-23-113604:8k_2_02:74]
|  | ii) | We present ASC 718 share-based payment compensation expense in our reconciliation of non-GAAP financial measures on a pre-tax basis because the exact tax differences related to the timing and deductibility of share-based compensation under ASC 718 are dependent upon the trading price of Omnicell’s common stock and the timing and exercise by employees of their stock options. As a result of these timing and market uncertainties, the tax effect related to share-based compensation expense would be inconsistent in amount and frequency and is therefore excluded from our non-GAAP results. |

[0001104659-23-113604:8k_2_02:75]
Non-GAAP diluted shares is defined as
our GAAP diluted shares, excluding the impact of dilutive convertible senior notes for which the Company is economically hedged through
its anti-dilutive convertible note hedge transaction. We believe non-GAAP diluted shares is a useful non-GAAP metric because it provides
insight into the offsetting economic effect of the hedge transaction against potential conversion of the convertible senior notes.

[0001104659-23-113604:8k_2_02:76]
Non-GAAP free cash flow is defined as
net cash provided by operating activities less cash used for software development for external use and purchases of property and equipment.
We believe free cash flow is important to enable investors to better understand and evaluate our ongoing operating results and allows
for greater transparency in the review and understanding of our overall financial, operational, and economic performance, because free
cash flow takes into account certain capital expenditures and cash used for software development necessary to operate our business.

[0001104659-23-113604:8k_2_02:77]
As stated above, we present non-GAAP
financial measures because we consider them to be important supplemental measures of performance. However, non-GAAP financial measures
have limitations as an analytical tool and should not be considered in isolation or as a substitute for Omnicell’s GAAP results.
In the future, we expect to incur expenses similar to certain of the non-GAAP adjustments described above and expect to continue reporting
non-GAAP financial measures excluding such items. Some of the limitations in relying on non-GAAP financial measures are:

[0001104659-23-113604:8k_2_02:78]
|  | a) | Omnicell’s equity incentive plans and stock purchase plans are important components of incentive compensation arrangements and will be reflected as expenses in Omnicell’s GAAP results for the foreseeable future under ASC 718. |

[0001104659-23-113604:8k_2_02:79]
|  | b) | Other companies, including companies in Omnicell’s industry, may calculate non-GAAP financial measures differently than Omnicell, limiting their usefulness as a comparative measure. |

[0001104659-23-113604:8k_2_02:80]
|  | c) | A limitation of the utility of free cash flow as a measure of financial performance is that it does not represent the total increase or decrease in Omnicell’s cash balance for the period. |

[0001104659-23-113604:8k_2_02:81]
A detailed reconciliation between Omnicell’s
non-GAAP and GAAP financial results is set forth in the financial tables at the end of this press release. Investors are advised to carefully
review and consider this information strictly as a supplement to the GAAP results that are contained in this press release as well as
in Omnicell’s other reports filed with or furnished to the SEC.

[0001104659-23-113604:8k_2_02:82]
|  | 7 |  |

[0001104659-23-113604:8k_2_02:83]
Omnicell, Inc.

[0001104659-23-113604:8k_2_02:84]
Condensed Consolidated
Statements of Operations

[0001104659-23-113604:8k_2_02:85]
(Unaudited, in
thousands, except per share data)

[0001104659-23-113604:8k_2_02:86]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product revenues |  | $ | 188,755 |  |  | $ | 246,565 |  |  | $ | 562,906 |  |  | $ | 706,246 |  |
| Services and other revenues |  |  | 109,908 |  |  |  | 101,494 |  |  |  | 325,359 |  |  |  | 292,027 |  |
| Total revenues |  |  | 298,663 |  |  |  | 348,059 |  |  |  | 888,265 |  |  |  | 998,273 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product revenues |  |  | 106,311 |  |  |  | 134,023 |  |  |  | 323,800 |  |  |  | 374,175 |  |
| Cost of services and other revenues |  |  | 60,388 |  |  |  | 54,941 |  |  |  | 173,029 |  |  |  | 156,864 |  |
| Total cost of revenues |  |  | 166,699 |  |  |  | 188,964 |  |  |  | 496,829 |  |  |  | 531,039 |  |
| Gross profit |  |  | 131,964 |  |  |  | 159,095 |  |  |  | 391,436 |  |  |  | 467,234 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 24,281 |  |  |  | 25,171 |  |  |  | 70,296 |  |  |  | 76,556 |  |
| Selling, general, and administrative |  |  | 103,971 |  |  |  | 115,459 |  |  |  | 332,643 |  |  |  | 354,644 |  |
| Total operating expenses |  |  | 128,252 |  |  |  | 140,630 |  |  |  | 402,939 |  |  |  | 431,200 |  |
| Income (loss) from operations |  |  | 3,712 |  |  |  | 18,465 |  |  |  | (11,503 | ) |  |  | 36,034 |  |
| Interest and other income (expense), net |  |  | 3,670 |  |  |  | (1,148 | ) |  |  | 9,912 |  |  |  | (2,973 | ) |
| Income (loss) before income taxes |  |  | 7,382 |  |  |  | 17,317 |  |  |  | (1,591 | ) |  |  | 33,061 |  |
| Provision for (benefit from) income taxes |  |  | 1,829 |  |  |  | 543 |  |  |  | 4,405 |  |  |  | (995 | ) |
| Net income (loss) |  | $ | 5,553 |  |  | $ | 16,774 |  |  | $ | (5,996 | ) |  | $ | 34,056 |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.12 |  |  | $ | 0.38 |  |  | $ | (0.13 | ) |  | $ | 0.77 |  |
| Diluted |  | $ | 0.12 |  |  | $ | 0.37 |  |  | $ | (0.13 | ) |  | $ | 0.73 |  |
| Weighted-average shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 45,333 |  |  |  | 44,441 |  |  |  | 45,117 |  |  |  | 44,304 |  |
| Diluted |  |  | 45,595 |  |  |  | 45,819 |  |  |  | 45,117 |  |  |  | 46,759 |  |

[0001104659-23-113604:8k_2_02:87]
|  | 8 |  |

[0001104659-23-113604:8k_2_02:88]
Omnicell, Inc.

[0001104659-23-113604:8k_2_02:89]
Condensed Consolidated
Balance Sheets

[0001104659-23-113604:8k_2_02:90]
(Unaudited, in
thousands)

[0001104659-23-113604:8k_2_02:91]
|  |  | September 30, 2023 |  |  | December 31, 2022 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 446,840 |  |  | $ | 330,362 |  |
| Accounts receivable and unbilled receivables, net |  |  | 272,584 |  |  |  | 299,469 |  |
| Inventories |  |  | 116,144 |  |  |  | 147,549 |  |
| Prepaid expenses |  |  | 27,947 |  |  |  | 27,070 |  |
| Other current assets |  |  | 50,236 |  |  |  | 77,362 |  |
| Total current assets |  |  | 913,751 |  |  |  | 881,812 |  |
| Property and equipment, net |  |  | 106,880 |  |  |  | 93,961 |  |
| Long-term investment in sales-type leases, net |  |  | 41,631 |  |  |  | 32,924 |  |
| Operating lease right-of-use assets |  |  | 25,444 |  |  |  | 38,052 |  |
| Goodwill |  |  | 734,328 |  |  |  | 734,274 |  |
| Intangible assets, net |  |  | 218,861 |  |  |  | 242,906 |  |
| Long-term deferred tax assets |  |  | 35,964 |  |  |  | 22,329 |  |
| Prepaid commissions |  |  | 53,950 |  |  |  | 59,483 |  |
| Other long-term assets |  |  | 90,766 |  |  |  | 105,017 |  |
| Total assets |  | $ | 2,221,575 |  |  | $ | 2,210,758 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 49,920 |  |  | $ | 63,389 |  |
| Accrued compensation |  |  | 44,065 |  |  |  | 73,455 |  |
| Accrued liabilities |  |  | 150,385 |  |  |  | 172,655 |  |
| Deferred revenues, net |  |  | 124,991 |  |  |  | 118,947 |  |
| Total current liabilities |  |  | 369,361 |  |  |  | 428,446 |  |
| Long-term deferred revenues |  |  | 55,053 |  |  |  | 37,385 |  |
| Long-term deferred tax liabilities |  |  | 1,565 |  |  |  | 2,095 |  |
| Long-term operating lease liabilities |  |  | 32,845 |  |  |  | 39,405 |  |
| Other long-term liabilities |  |  | 6,428 |  |  |  | 6,719 |  |
| Convertible senior notes, net |  |  | 568,887 |  |  |  | 566,571 |  |
| Total liabilities |  |  | 1,034,139 |  |  |  | 1,080,621 |  |
| Total stockholders’ equity |  |  | 1,187,436 |  |  |  | 1,130,137 |  |
| Total liabilities and stockholders’ equity |  | $ | 2,221,575 |  |  | $ | 2,210,758 |  |

[0001104659-23-113604:8k_2_02:92]
|  | 9 |  |

[0001104659-23-113604:8k_2_02:93]
Omnicell, Inc.

[0001104659-23-113604:8k_2_02:94]
Condensed Consolidated
Statements of Cash Flows

[0001104659-23-113604:8k_2_02:95]
(Unaudited, in
thousands)

[0001104659-23-113604:8k_2_02:96]
|  |  | Nine Months Ended September 30, |  |
|  |  | 2023 |  |  | 2022 |  |
| Operating Activities |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | (5,996 | ) |  | $ | 34,056 |  |
| Adjustments to reconcile net income (loss) to net cash provided by (used in) operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 65,596 |  |  |  | 64,843 |  |
| Loss on disposal of property and equipment |  |  | 2,110 |  |  |  | 331 |  |
| Share-based compensation expense |  |  | 43,113 |  |  |  | 50,731 |  |
| Deferred income taxes |  |  | (14,165 | ) |  |  | (17,061 | ) |
| Amortization of operating lease right-of-use assets |  |  | 6,238 |  |  |  | 9,709 |  |
| Impairment and abandonment of operating lease right-of-use assets related to facilities |  |  | 7,815 |  |  |  | 5,390 |  |
| Amortization of debt issuance costs |  |  | 3,139 |  |  |  | 3,121 |  |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable and unbilled receivables |  |  | 27,050 |  |  |  | (116,895 | ) |
| Inventories |  |  | 31,690 |  |  |  | (32,269 | ) |
| Prepaid expenses |  |  | (857 | ) |  |  | (2,602 | ) |
| Other current assets |  |  | 1,521 |  |  |  | 6,692 |  |
| Investment in sales-type leases |  |  | (8,839 | ) |  |  | (17,336 | ) |
| Prepaid commissions |  |  | 5,533 |  |  |  | 8,801 |  |
| Other long-term assets |  |  | 2,539 |  |  |  | 4,189 |  |
| Accounts payable |  |  | (13,358 | ) |  |  | 2,043 |  |
| Accrued compensation |  |  | (29,390 | ) |  |  | (27,940 | ) |
| Accrued liabilities |  |  | 3,749 |  |  |  | 11,678 |  |
| Deferred revenues |  |  | 23,628 |  |  |  | 17,667 |  |
| Operating lease liabilities |  |  | (8,145 | ) |  |  | (10,966 | ) |
| Other long-term liabilities |  |  | (291 | ) |  |  | 1,446 |  |
| Net cash provided by (used in) operating activities |  |  | 142,680 |  |  |  | (4,372 | ) |
| Investing Activities |  |  |  |  |  |  |  |  |
| External-use software development costs |  |  | (10,240 | ) |  |  | (9,648 | ) |
| Purchases of property and equipment |  |  | (32,404 | ) |  |  | (33,861 | ) |
| Business acquisition, net of cash acquired |  |  | — |  |  |  | (3,392 | ) |
| Purchase price adjustments from business acquisitions |  |  | — |  |  |  | 5,484 |  |
| Net cash used in investing activities |  |  | (42,644 | ) |  |  | (41,417 | ) |
| Financing Activities |  |  |  |  |  |  |  |  |
| Proceeds from issuances under stock-based compensation plans |  |  | 23,035 |  |  |  | 39,539 |  |
| Employees’ taxes paid related to restricted stock units |  |  | (6,130 | ) |  |  | (11,442 | ) |
| Change in customer funds, net |  |  | (6,615 | ) |  |  | (402 | ) |
| Stock repurchases |  |  | — |  |  |  | (52,210 | ) |
| Net cash provided by (used in) financing activities |  |  | 10,290 |  |  |  | (24,515 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (464 | ) |  |  | (1,425 | ) |
| Net increase (decrease) in cash, cash equivalents, and restricted cash |  |  | 109,862 |  |  |  | (71,729 | ) |
| Cash, cash equivalents, and restricted cash at beginning of period |  |  | 352,835 |  |  |  | 355,620 |  |
| Cash, cash equivalents, and restricted cash at end of period |  | $ | 462,697 |  |  | $ | 283,891 |  |
| Reconciliation of cash, cash equivalents, and restricted cash to the Condensed Consolidated Balance Sheets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 446,840 |  |  | $ | 266,402 |  |
| Restricted cash included in other current assets |  |  | 15,857 |  |  |  | 17,489 |  |
| Cash, cash equivalents, and restricted cash at end of period |  | $ | 462,697 |  |  | $ | 283,891 |  |

[0001104659-23-113604:8k_2_02:97]
|  | 10 |  |

[0001104659-23-113604:8k_2_02:98]
Omnicell, Inc.

[0001104659-23-113604:8k_2_02:99]
Reconciliation
of GAAP to Non-GAAP

[0001104659-23-113604:8k_2_02:100]
(Unaudited, in
thousands, except per share data and percentage)

[0001104659-23-113604:8k_2_02:101]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Reconciliation of GAAP revenues to non-GAAP revenues: |
| GAAP revenues |  | $ | 298,663 |  |  | $ | 348,059 |  |  | $ | 888,265 |  |  | $ | 998,273 |  |
| Acquisition accounting impact related to deferred revenues |  |  | — |  |  |  | 183 |  |  |  | — |  |  |  | 863 |  |
| Non-GAAP revenues |  | $ | 298,663 |  |  | $ | 348,242 |  |  | $ | 888,265 |  |  | $ | 999,136 |  |
| Reconciliation of GAAP gross profit to non-GAAP gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP gross profit |  | $ | 131,964 |  |  | $ | 159,095 |  |  | $ | 391,436 |  |  | $ | 467,234 |  |
| GAAP gross margin |  |  | 44.2 | % |  |  | 45.7 | % |  |  | 44.1 | % |  |  | 46.8 | % |
| Share-based compensation expense |  |  | 2,213 |  |  |  | 2,203 |  |  |  | 6,489 |  |  |  | 6,607 |  |
| Amortization of acquired intangibles |  |  | 2,633 |  |  |  | 3,238 |  |  |  | 8,558 |  |  |  | 10,089 |  |
| Acquisition accounting impact related to deferred revenues |  |  | — |  |  |  | 183 |  |  |  | — |  |  |  | 863 |  |
| Ransomware-related expenses, net of insurance recoveries |  |  | — |  |  |  | 95 |  |  |  | — |  |  |  | 317 |  |
| Severance-related expenses, net of reversals |  |  | (280 | ) |  |  | 444 |  |  |  | 102 |  |  |  | 600 |  |
| Non-GAAP gross profit |  | $ | 136,530 |  |  | $ | 165,258 |  |  | $ | 406,585 |  |  | $ | 485,710 |  |
| Non-GAAP gross margin |  |  | 45.7 | % |  |  | 47.5 | % |  |  | 45.8 | % |  |  | 48.6 | % |
| Reconciliation of GAAP operating expenses to non-GAAP operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP operating expenses |  | $ | 128,252 |  |  | $ | 140,630 |  |  | $ | 402,939 |  |  | $ | 431,200 |  |
| GAAP operating expenses % to total revenues |  |  | 42.9 | % |  |  | 40.4 | % |  |  | 45.4 | % |  |  | 43.2 | % |
| Share-based compensation expense |  |  | (12,769 | ) |  |  | (15,107 | ) |  |  | (36,624 | ) |  |  | (44,124 | ) |
| Amortization of acquired intangibles |  |  | (5,050 | ) |  |  | (5,507 | ) |  |  | (15,402 | ) |  |  | (16,554 | ) |
| Acquisition-related expenses |  |  | (246 | ) |  |  | (251 | ) |  |  | (738 | ) |  |  | (1,909 | ) |
| Impairment and abandonment of operating lease right-of-use and other assets related to facilities (a) |  |  | — |  |  |  | (297 | ) |  |  | (8,420 | ) |  |  | (5,390 | ) |
| Ransomware-related expenses, net of insurance recoveries |  |  | 184 |  |  |  | (932 | ) |  |  | 184 |  |  |  | (2,084 | ) |
| Executives transition costs |  |  | (1,348 | ) |  |  | — |  |  |  | (2,189 | ) |  |  | — |  |
| Severance-related and other expenses, net of reversals (b) |  |  | 301 |  |  |  | (2,050 | ) |  |  | (5,352 | ) |  |  | (5,421 | ) |
| Non-GAAP operating expenses |  | $ | 109,324 |  |  | $ | 116,486 |  |  | $ | 334,398 |  |  | $ | 355,718 |  |
| Non-GAAP operating expenses as a % of total non-GAAP revenues |  |  | 36.6 | % |  |  | 33.4 | % |  |  | 37.6 | % |  |  | 35.6 | % |
| Reconciliation of GAAP income (loss) from operations to non-GAAP income from operations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP income (loss) from operations |  | $ | 3,712 |  |  | $ | 18,465 |  |  | $ | (11,503 | ) |  | $ | 36,034 |  |
| GAAP operating income (loss) % to total revenues |  |  | 1.2 | % |  |  | 5.3 | % |  |  | (1.3 | )% |  |  | 3.6 | % |
| Share-based compensation expense |  |  | 14,982 |  |  |  | 17,310 |  |  |  | 43,113 |  |  |  | 50,731 |  |
| Amortization of acquired intangibles |  |  | 7,683 |  |  |  | 8,745 |  |  |  | 23,960 |  |  |  | 26,643 |  |
| Acquisition accounting impact related to deferred revenues |  |  | — |  |  |  | 183 |  |  |  | — |  |  |  | 863 |  |
| Acquisition-related expenses |  |  | 246 |  |  |  | 251 |  |  |  | 738 |  |  |  | 1,909 |  |
| Impairment and abandonment of operating lease right-of-use and other assets related to facilities (a) |  |  | — |  |  |  | 297 |  |  |  | 8,420 |  |  |  | 5,390 |  |
| Ransomware-related expenses, net of insurance recoveries |  |  | (184 | ) |  |  | 1,027 |  |  |  | (184 | ) |  |  | 2,401 |  |
| Executives transition costs |  |  | 1,348 |  |  |  | — |  |  |  | 2,189 |  |  |  | — |  |
| Severance-related and other expenses, net of reversals (b) |  |  | (581 | ) |  |  | 2,494 |  |  |  | 5,454 |  |  |  | 6,021 |  |
| Non-GAAP income from operations |  | $ | 27,206 |  |  | $ | 48,772 |  |  | $ | 72,187 |  |  | $ | 129,992 |  |
| Non-GAAP operating margin (non-GAAP operating income as a % of total non-GAAP revenues) |  |  | 9.1 | % |  |  | 14.0 | % |  |  | 8.1 | % |  |  | 13.0 | % |

[0001104659-23-113604:8k_2_02:102]
|  | 11 |  |

[0001104659-23-113604:8k_2_02:103]
Omnicell, Inc.

[0001104659-23-113604:8k_2_02:104]
Reconciliation
of GAAP to Non-GAAP

[0001104659-23-113604:8k_2_02:105]
(Unaudited, in
thousands, except per share data and percentage)

[0001104659-23-113604:8k_2_02:106]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Reconciliation of GAAP net income (loss) to non-GAAP net income: |
| GAAP net income (loss) |  | $ | 5,553 |  |  | $ | 16,774 |  |  | $ | (5,996 | ) |  | $ | 34,056 |  |
| Share-based compensation expense |  |  | 14,982 |  |  |  | 17,310 |  |  |  | 43,113 |  |  |  | 50,731 |  |
| Amortization of acquired intangibles |  |  | 7,683 |  |  |  | 8,745 |  |  |  | 23,960 |  |  |  | 26,643 |  |
| Acquisition accounting impact related to deferred revenues |  |  | — |  |  |  | 183 |  |  |  | — |  |  |  | 863 |  |
| Acquisition-related expenses |  |  | 246 |  |  |  | 251 |  |  |  | 738 |  |  |  | 1,909 |  |
| Impairment and abandonment of operating lease right-of-use and other assets related to facilities (a) |  |  | — |  |  |  | 297 |  |  |  | 8,420 |  |  |  | 5,390 |  |
| Ransomware-related expenses, net of insurance recoveries |  |  | (184 | ) |  |  | 1,027 |  |  |  | (184 | ) |  |  | 2,401 |  |
| Executives transition costs |  |  | 1,348 |  |  |  | — |  |  |  | 2,189 |  |  |  | — |  |
| Severance-related and other expenses, net of reversals (b) |  |  | (581 | ) |  |  | 2,494 |  |  |  | 5,454 |  |  |  | 6,021 |  |
| Amortization of debt issuance costs |  |  | 1,048 |  |  |  | 1,042 |  |  |  | 3,139 |  |  |  | 3,121 |  |
| Tax effect of the adjustments above (c) |  |  | (2,008 | ) |  |  | (2,948 | ) |  |  | (9,181 | ) |  |  | (9,734 | ) |
| Non-GAAP net income |  | $ | 28,087 |  |  | $ | 45,175 |  |  | $ | 71,652 |  |  | $ | 121,401 |  |
| Reconciliation of GAAP net income (loss) per share - diluted to non-GAAP net income per share - diluted: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Shares - diluted GAAP |  |  | 45,595 |  |  |  | 45,819 |  |  |  | 45,117 |  |  |  | 46,759 |  |
| Shares - diluted non-GAAP (d) |  |  | 45,595 |  |  |  | 45,384 |  |  |  | 45,410 |  |  |  | 45,597 |  |
| GAAP net income (loss) per share - diluted |  | $ | 0.12 |  |  | $ | 0.37 |  |  | $ | (0.13 | ) |  | $ | 0.73 |  |
| Share-based compensation expense |  |  | 0.33 |  |  |  | 0.38 |  |  |  | 0.95 |  |  |  | 1.11 |  |
| Amortization of acquired intangibles |  |  | 0.16 |  |  |  | 0.19 |  |  |  | 0.52 |  |  |  | 0.58 |  |
| Acquisition accounting impact related to deferred revenues |  |  | — |  |  |  | 0.00 |  |  |  | — |  |  |  | 0.02 |  |
| Acquisition-related expenses |  |  | 0.01 |  |  |  | 0.01 |  |  |  | 0.02 |  |  |  | 0.04 |  |
| Impairment and abandonment of operating lease right-of-use and other assets related to facilities |  |  | — |  |  |  | 0.01 |  |  |  | 0.18 |  |  |  | 0.12 |  |
| Ransomware-related expenses, net of insurance recoveries |  |  | (0.00 | ) |  |  | 0.02 |  |  |  | (0.00 | ) |  |  | 0.05 |  |
| Executives transition costs |  |  | 0.03 |  |  |  | — |  |  |  | 0.05 |  |  |  | — |  |
| Severance-related and other expenses, net of reversals |  |  | (0.01 | ) |  |  | 0.06 |  |  |  | 0.12 |  |  |  | 0.13 |  |
| Amortization of debt issuance costs |  |  | 0.02 |  |  |  | 0.02 |  |  |  | 0.07 |  |  |  | 0.07 |  |
| Non-GAAP dilutive shares impact from convertible note hedge transaction (d) |  |  | — |  |  |  | 0.00 |  |  |  | — |  |  |  | 0.02 |  |
| Tax effect of the adjustments above (c) |  |  | (0.04 | ) |  |  | (0.06 | ) |  |  | (0.20 | ) |  |  | (0.21 | ) |
| Non-GAAP net income per share - diluted |  | $ | 0.62 |  |  | $ | 1.00 |  |  | $ | 1.58 |  |  | $ | 2.66 |  |
| Reconciliation of GAAP net income (loss) to non-GAAP EBITDA(e): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP net income (loss) |  | $ | 5,553 |  |  | $ | 16,774 |  |  | $ | (5,996 | ) |  | $ | 34,056 |  |
| Share-based compensation expense |  |  | 14,982 |  |  |  | 17,310 |  |  |  | 43,113 |  |  |  | 50,731 |  |
| Interest (income) and expense, net |  |  | (5,247 | ) |  |  | (1,136 | ) |  |  | (12,731 | ) |  |  | (1,311 | ) |
| Depreciation and amortization expense |  |  | 21,542 |  |  |  | 21,826 |  |  |  | 65,596 |  |  |  | 64,843 |  |
| Acquisition accounting impact related to deferred revenues |  |  | — |  |  |  | 183 |  |  |  | — |  |  |  | 863 |  |
| Acquisition-related expenses |  |  | 246 |  |  |  | 251 |  |  |  | 738 |  |  |  | 1,909 |  |
| Impairment and abandonment of operating lease right-of-use and other assets related to facilities (a) |  |  | — |  |  |  | 297 |  |  |  | 8,420 |  |  |  | 5,390 |  |
| Ransomware-related expenses, net of insurance recoveries |  |  | (184 | ) |  |  | 1,027 |  |  |  | (184 | ) |  |  | 2,401 |  |
| Executives transition costs |  |  | 1,348 |  |  |  | — |  |  |  | 2,189 |  |  |  | — |  |
| Severance-related and other expenses, net of reversals (b) |  |  | (581 | ) |  |  | 2,494 |  |  |  | 5,454 |  |  |  | 6,021 |  |
| Amortization of debt issuance costs |  |  | 1,048 |  |  |  | 1,042 |  |  |  | 3,139 |  |  |  | 3,121 |  |
| Provision for (benefit from) income taxes |  |  | 1,829 |  |  |  | 543 |  |  |  | 4,405 |  |  |  | (995 | ) |
| Non-GAAP EBITDA |  | $ | 40,536 |  |  | $ | 60,611 |  |  | $ | 114,143 |  |  | $ | 167,029 |  |
| Non-GAAP EBITDA margin (non-GAAP EBITDA as a % of total non-GAAP revenues) |  |  | 13.6 | % |  |  | 17.4 | % |  |  | 12.9 | % |  |  | 16.7 | % |

[0001104659-23-113604:8k_2_02:107]
|  | 12 |  |

[0001104659-23-113604:8k_2_02:108]
|  | (a) | For the nine months ended September 30, 2023, impairment charges of other assets were approximately $0.6 million related to property and equipment in connection with restructuring activities for optimization of certain leased facilities. |

[0001104659-23-113604:8k_2_02:109]
|  | (b) | For the three and nine months ended September 30, 2022, other expenses included approximately $0.7 million of certain litigation costs. |

[0001104659-23-113604:8k_2_02:110]
|  | (c) | Tax effects calculated for all adjustments except share-based compensation expense, using an estimated annual effective tax rate of 21% for both fiscal years 2023 and 2022. |

[0001104659-23-113604:8k_2_02:111]
|  | (d) | For the three and nine months ended September 30, 2022, non-GAAP diluted shares excluded approximately 0.4 million and 1.2 million shares, respectively, related to the impact of dilutive convertible senior notes for which the Company is economically hedged through its anti-dilutive convertible note hedge transaction. |

[0001104659-23-113604:8k_2_02:112]
|  | (e) | Defined as earnings before interest income and expense, taxes, depreciation, amortization, and share-based compensation, as well as excluding certain other non-GAAP adjustments. |

[0001104659-23-113604:8k_2_02:113]
|  | 13 |  |

[0001104659-23-113604:8k_2_02:114]
Omnicell, Inc.

[0001104659-23-113604:8k_2_02:115]
Reconciliation
of GAAP to Non-GAAP

[0001104659-23-113604:8k_2_02:116]
(Unaudited, in
thousands)

[0001104659-23-113604:8k_2_02:117]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Reconciliation of GAAP net cash provided by (used in) operating activities to non-GAAP free cash flow: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP net cash provided by (used in) operating activities |  | $ | 57,007 |  |  | $ | 21,175 |  |  | $ | 142,680 |  |  | $ | (4,372 | ) |
| External-use software development costs |  |  | (3,555 | ) |  |  | (3,105 | ) |  |  | (10,240 | ) |  |  | (9,648 | ) |
| Purchases of property and equipment |  |  | (10,632 | ) |  |  | (12,762 | ) |  |  | (32,404 | ) |  |  | (33,861 | ) |
| Non-GAAP free cash flow |  | $ | 42,820 |  |  | $ | 5,308 |  |  | $ | 100,036 |  |  | $ | (47,881 | ) |

[0001104659-23-113604:8k_2_02:118]
|  | 14 |  |
