# OMCL MD&A — 0000926326-23-000041


## mdna

[0000926326-23-000041:mdna:1]
[same as prior period, unchanged from 0000926326-23-000031:mdna:1]

[0000926326-23-000041:mdna:2]
[same as prior period, unchanged from 0000926326-23-000031:mdna:2]

[0000926326-23-000041:mdna:3]
[same as prior period, unchanged from 0000926326-23-000031:mdna:3]

[0000926326-23-000041:mdna:4]
[same as prior period, unchanged from 0000926326-23-000031:mdna:4]

[0000926326-23-000041:mdna:5]
[same as prior period, unchanged from 0000926326-23-000031:mdna:5]

[0000926326-23-000041:mdna:6]
[same as prior period, unchanged from 0000926326-23-000031:mdna:6]

[0000926326-23-000041:mdna:7]
[same as prior period, unchanged from 0000926326-23-000031:mdna:7]

[0000926326-23-000041:mdna:8]
[same as prior period, unchanged from 0000926326-23-000031:mdna:8]

[0000926326-23-000041:mdna:9]
[same as prior period, unchanged from 0000926326-23-000031:mdna:9]

[0000926326-23-000041:mdna:10]
[same as prior period, unchanged from 0000926326-23-000031:mdna:10]

[0000926326-23-000041:mdna:11]
[same as prior period, unchanged from 0000926326-23-000031:mdna:11]

[0000926326-23-000041:mdna:12]
[same as prior period, unchanged from 0000926326-23-000031:mdna:12]

[0000926326-23-000041:mdna:13]
[same as prior period, unchanged from 0000926326-23-000031:mdna:13]

[0000926326-23-000041:mdna:14]
[same as prior period, unchanged from 0000926326-23-000031:mdna:14]

[0000926326-23-000041:mdna:15]
[same as prior period, unchanged from 0000926326-23-000031:mdna:15]

[0000926326-23-000041:mdna:16]
[same as prior period, unchanged from 0000926326-23-000031:mdna:16]

[0000926326-23-000041:mdna:17]
[same as prior period, unchanged from 0000926326-23-000031:mdna:17]

[0000926326-23-000041:mdna:18]
[same as prior period, unchanged from 0000926326-23-000031:mdna:18]

[0000926326-23-000041:mdna:19]
[same as prior period, unchanged from 0000926326-23-000031:mdna:19]

[0000926326-23-000041:mdna:20]
[same as prior period, unchanged from 0000926326-23-000031:mdna:20]

[0000926326-23-000041:mdna:21]
[same as prior period, unchanged from 0000926326-23-000031:mdna:21]

[0000926326-23-000041:mdna:22]
[same as prior period, unchanged from 0000926326-23-000031:mdna:22]

[0000926326-23-000041:mdna:23]
[same as prior period, unchanged from 0000926326-23-000031:mdna:23]

[0000926326-23-000041:mdna:24]
[same as prior period, unchanged from 0000926326-23-000031:mdna:24]

[0000926326-23-000041:mdna:25]
[same as prior period, unchanged from 0000926326-23-000031:mdna:25]

[0000926326-23-000041:mdna:26]
[same as prior period, unchanged from 0000926326-23-000031:mdna:26]

[0000926326-23-000041:mdna:27]
Facilities worldwide use our automation and analytics solutions to increase operational efficiency, reduce medication errors, deliver actionable intelligence, and improve patient safety. Institutional and retail pharmacies across North America and the United Kingdom leverage our innovative medication adherence and population health solutions to improve patient engagement and adherence to prescriptions, helping to reduce costly hospital readmissions. We sell our product and consumable solutions together with related service offerings. Revenues generated in the United States represented 91% of our total revenues for both the three months ended September 30, 2023 and 2022, and 88% and 90% for the nine months ended September 30, 2023 and 2022, respectively.

[0000926326-23-000041:mdna:28]
[same as prior period, unchanged from 0000926326-23-000031:mdna:29]

[0000926326-23-000041:mdna:29]
[same as prior period, unchanged from 0000926326-23-000031:mdna:30]

[0000926326-23-000041:mdna:30]
[same as prior period, unchanged from 0000926326-23-000031:mdna:31]

[0000926326-23-000041:mdna:31]
[same as prior period, unchanged from 0000926326-23-000031:mdna:32]

[0000926326-23-000041:mdna:32]
[same as prior period, unchanged from 0000926326-23-000031:mdna:33]

[0000926326-23-000041:mdna:33]
[same as prior period, unchanged from 0000926326-23-000031:mdna:34]

[0000926326-23-000041:mdna:34]
[same as prior period, unchanged from 0000926326-23-000031:mdna:35]

[0000926326-23-000041:mdna:35]
[same as prior period, unchanged from 0000926326-23-000031:mdna:36]

[0000926326-23-000041:mdna:36]
[same as prior period, unchanged from 0000926326-23-000031:mdna:37]

[0000926326-23-000041:mdna:37]
Our full-time employee headcount was approximately 3,890 and 4,230 on September 30, 2023 and December 31, 2022, respectively. The decrease in employee headcount reflects the impact of the restructuring plan announced in November 2022.

[0000926326-23-000041:mdna:38]
[same as prior period, unchanged from 0000926326-23-000031:mdna:39]

[0000926326-23-000041:mdna:39]
[same as prior period, unchanged from 0000926326-23-000031:mdna:40]

[0000926326-23-000041:mdna:40]
[same as prior period, unchanged from 0000926326-23-000031:mdna:41]

[0000926326-23-000041:mdna:41]
The U.S. spent a total of $633.5 billion on prescription drugs that accounted for 14% of National Health Expenditures in 2022, and prescription drugs impact the vast majority of patients in virtually all settings of care. We believe there are significant challenges facing the practice of pharmacy today including, but not limited to, labor shortages, medication errors, drug shortages, medication loss due to drug diversion, significant medication waste and expiration costs, a high level of manual processes, complexity around compliance requirements, high healthcare worker turnover rates affecting tenure and expertise, hospitalizations from adverse drug events in outpatient settings, high variability in outcomes, and limited inventory visibility. Each of these challenges can translate into a major economic impact for hospitals and health systems. We recognize that some of these challenges can create capital budget and labor constraints for our customers in the near-term that may impact the potential timing of contracting for, or implementing, our products, solutions, or services. However, we believe that over time these significant challenges to the practice of pharmacy should drive demand for increased digitization, visibility, and insights that our solutions are designed to enable. Because of this, we find that our solutions are well positioned to address the evolving needs of healthcare institutions and therefore present opportunities for growth over the long-term.

[0000926326-23-000041:mdna:42]
In an effort to address these challenges and deliver solutions to help drive positive medication management outcomes, we continue to make significant investments in our research and development efforts to further advance the industry vision of the Autonomous Pharmacy. Furthermore, we believe a combination of technology, expertise and intelligence is needed in each care setting and across the entire continuum of care. We are focused on delivering solutions to help our customers realize the industry vision of the Autonomous Pharmacy and drive positive medication management outcomes with outstanding customer experience through a mature channel in four market categories:

[0000926326-23-000041:mdna:43]
•Point of Care.  As a market leader, we expect to continue expansion into this product market as customers increase the use of our dispensing systems in more areas within their hospitals. However, we recognize that the current macroeconomic environment, with significant labor constraints, may impact our customers’ considerations in the near term when determining to implement new workflows that may affect those same stressed labor pools. As our XT Series cabinet is largely through the replacement, upgrade, and expansion cycle of older models of automated dispensing systems, we are seeing demand moderate. Over time, we believe that should labor shortages continue to challenge the delivery of healthcare services, deploying solutions and workflows that are intended to save nursing time, such as our XT Series, will be essential. We also believe there is an opportunity for us to expand this offering and define a new standard for dispensing systems in perioperative settings. We believe our

[0000926326-23-000041:mdna:44]
current solutions within the Point of Care market and new innovation and services will continue to help customers drive improved outcomes.

[0000926326-23-000041:mdna:45]
•Central Pharmacy and IV Compounding.  This market represents the beginning of the medication management process in acute care settings, and, we believe, it is a significant automation opportunity for high volumes of manual, repetitive, and error-prone processes that are often common in pharmacies today. Manual medication dispensing processes are usually labor intensive, error-prone, and may lead to excess medication waste and expirations for our healthcare partners. Automating the central pharmacy dispensing process should enable customers to reallocate pharmacy labor, enhance dispensing accuracy and patient safety, and reduce medication waste and expirations. Likewise, the manual compounding of sterile IV preparations can be error-prone and create significant patient safety risks, and outsourcing sterile IV compounding could lead to increased medication costs. As a result, we believe IV automation provides a significant opportunity to enhance patient safety and reduce costs. Because adoption of our Central Pharmacy and IV automation solution is still nascent, we believe that the implementation of new solutions (as well as upgrading older technology) will be accelerated by combining technology, expertise, and intelligence into a comprehensive offering that is designed to deliver improved outcomes. Despite the potential headwinds from the lack of clarity in the current regulatory environment for IV automation, we anticipate that these bundled solutions will become more critical as health systems continue to face labor shortages, increased financial pressure, and supply chain disruptions.

[0000926326-23-000041:mdna:46]
•Specialty Pharmacy and 340B Program.  We believe that health systems will invest in more revenue-generating activities that are intended to improve patient outcomes by utilizing specialty pharmacies and the 340B Drug Pricing Program, which allow hospitals and health systems to stretch federal resources and expand patient access to healthcare by requiring manufacturers participating in Medicaid to sell outpatient drugs at discounted prices to healthcare organizations. Specialty drugs are used for treatment of complex conditions and often require intensive patient management and specialized workflows for dispensing and care coordination. Specialty medications are projected to account for nearly 60% of U.S. total spending on medications, with total spending projected to be approximately $420 billion in 2025. Specialty pharmacies serve as the connection between patients, prescribing physicians, and payers and work to streamline access and adherence to these specialty drugs. We believe a solution that addresses start-up and managed services for health systems that is designed to optimize their specialty pharmacy programs and the related pharmaceutical aspects of patient care will help ensure continuity of care and should contribute to the revenue and profitability of those organizations. We believe that a fully optimized specialty pharmacy operation represents one of the largest economic opportunities for hospitals and health systems.

[0000926326-23-000041:mdna:47]
•Retail, Institutional, and Payer.  We believe the Retail, Institutional, and Payer market represents a significant opportunity as healthcare evolves. A majority of all prescription drugs are distributed in non-hospital settings. The COVID-19 pandemic accelerated the shift of outpatient care from hospitals and physician offices to other, more convenient settings, such as retail pharmacies and the home (including through telehealth technologies). New technologies and updated state board regulations appear to be spurring innovation by retail pharmacies, which, combined with the move to value-based care, we believe will drive the adoption of solutions that are intended to help providers and payers engage patients in new ways that improve patient care, reduce the total cost of care, and lead to more profitable operations. Because of the complexity of relationships between payers and providers, as well as the large number of retail pharmacies, including a significant number of independent pharmacies, we believe a network of established relationships between payers, providers and pharmacies will also be important.

[0000926326-23-000041:mdna:48]
[same as prior period, unchanged from 0000926326-23-000031:mdna:48]

[0000926326-23-000041:mdna:49]
[same as prior period, unchanged from 0000926326-23-000031:mdna:49]

[0000926326-23-000041:mdna:50]
[same as prior period, unchanged from 0000926326-23-000031:mdna:50]

[0000926326-23-000041:mdna:51]
[same as prior period, unchanged from 0000926326-23-000031:mdna:51]

[0000926326-23-000041:mdna:52]
[same as prior period, unchanged from 0000926326-23-000031:mdna:52]

[0000926326-23-000041:mdna:53]
[same as prior period, unchanged from 0000926326-23-000031:mdna:53]

[0000926326-23-000041:mdna:54]
[same as prior period, unchanged from 0000926326-23-000031:mdna:54]

[0000926326-23-000041:mdna:55]
[same as prior period, unchanged from 0000926326-23-000031:mdna:55]

[0000926326-23-000041:mdna:56]
[same as prior period, unchanged from 0000926326-23-000031:mdna:56]

[0000926326-23-000041:mdna:57]
[same as prior period, unchanged from 0000926326-23-000031:mdna:57]

[0000926326-23-000041:mdna:58]
[same as prior period, unchanged from 0000926326-23-000031:mdna:58]

[0000926326-23-000041:mdna:59]
[same as prior period, unchanged from 0000926326-23-000031:mdna:59]

[0000926326-23-000041:mdna:60]
[same as prior period, unchanged from 0000926326-23-000031:mdna:60]

[0000926326-23-000041:mdna:61]
There were no material changes in the matters for which we make critical accounting estimates in the preparation of our Condensed Consolidated Financial Statements during the nine months ended September 30, 2023 as compared to those disclosed in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” included in our Annual Report on Form 10-K for the year ended December 31, 2022, except as discussed in “Recently Adopted Authoritative Guidance” in Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000926326-23-000041:mdna:62]
[same as prior period, unchanged from 0000926326-23-000031:mdna:62]

[0000926326-23-000041:mdna:63]
Refer to “Recently Issued Authoritative Guidance” in Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q for a description of recently issued accounting pronouncements, including the expected dates of adoption and estimated effects on our results of operations, financial position, and cash flows.

[0000926326-23-000041:mdna:64]
[same as prior period, unchanged from 0000926326-23-000031:mdna:64]

[0000926326-23-000041:mdna:65]
[same as prior period, unchanged from 0000926326-23-000031:mdna:65]

[0000926326-23-000041:mdna:66]
|  | Three Months Ended September 30, |
|  |  |  |  |  | Change in |
|  | 2023 |  | 2022 |  | $ |  | % |
|  | (Dollars in thousands) |
| Product revenues | $ | 188,755 |  |  | $ | 246,565 |  |  | $ | (57,810) |  |  | (23)% |
| Percentage of total revenues | 63% |  | 71% |  |  |  |  |
| Services and other revenues | 109,908 |  |  | 101,494 |  |  | 8,414 |  |  | 8% |
| Percentage of total revenues | 37% |  | 29% |  |  |  |  |
| Total revenues | $ | 298,663 |  |  | $ | 348,059 |  |  | $ | (49,396) |  |  | (14)% |

[0000926326-23-000041:mdna:67]
Product revenues represented 63% and 71% of total revenues for the three months ended September 30, 2023 and 2022, respectively. Product revenues decreased by $57.8 million, primarily due to lower volumes from our automated dispensing systems business primarily as a result of ongoing health systems capital budget and labor constraints.

[0000926326-23-000041:mdna:68]
Services and other revenues represented 37% and 29% of total revenues for the three months ended September 30, 2023 and 2022, respectively. Services and other revenues include revenues from technical services and Advanced Services offerings. Services and other revenues increased by $8.4 million, primarily due to increased customer demand for our Advanced Services offerings and continued growth in our installed customer base as well as the impact of pricing actions.

[0000926326-23-000041:mdna:69]
Our international sales represented 9% of total revenues for both the three months ended September 30, 2023 and 2022, and are expected to be affected by foreign currency exchange rate fluctuations. We are unable to predict the extent to which revenues in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-23-000041:mdna:70]
|  | Nine Months Ended September 30, |
|  |  |  |  |  | Change in |
|  | 2023 |  | 2022 |  | $ |  | % |
|  | (Dollars in thousands) |
| Product revenues | $ | 562,906 |  |  | $ | 706,246 |  |  | $ | (143,340) |  |  | (20)% |
| Percentage of total revenues | 63% |  | 71% |  |  |  |  |
| Services and other revenues | 325,359 |  |  | 292,027 |  |  | 33,332 |  |  | 11% |
| Percentage of total revenues | 37% |  | 29% |  |  |  |  |
| Total revenues | $ | 888,265 |  |  | $ | 998,273 |  |  | $ | (110,008) |  |  | (11)% |

[0000926326-23-000041:mdna:71]
Product revenues represented 63% and 71% of total revenues for the nine months ended September 30, 2023 and 2022, respectively. Product revenues decreased by $143.3 million, primarily due to lower volumes from our automated dispensing systems business primarily as a result of ongoing health systems capital budget and labor constraints, partially offset by an increase of $6.6 million in revenues from consumables.

[0000926326-23-000041:mdna:72]
Services and other revenues represented 37% and 29% of total revenues for the nine months ended September 30, 2023 and 2022, respectively. Services and other revenues include revenues from technical services and Advanced Services offerings. Services and other revenues increased by $33.3 million, primarily due to increased customer demand for our Advanced Services offerings and continued growth in our installed customer base as well as the impact of pricing actions.

[0000926326-23-000041:mdna:73]
Our international sales represented 12% and 10% of total revenues for the nine months ended September 30, 2023 and 2022, respectively, and are expected to be affected by foreign currency exchange rate fluctuations. We are unable to predict the extent to which revenues in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-23-000041:mdna:74]
Our ability to grow revenues is dependent on our ability to continue to obtain orders from customers, which may be dependent upon customers’ capital equipment budgets and/or capital equipment approval cycles, our ability to produce quality products and consumables to fulfill customer demand, the volume of installations we are able to complete, our ability to meet customer needs by providing a quality installation experience, our ability to develop new or enhance existing solutions, and our flexibility in workforce allocations among customers to complete installations on a timely basis. The timing of our product revenues for equipment is primarily dependent on when our customers’ schedules and/or staffing levels allow for installations.

[0000926326-23-000041:mdna:75]
[same as prior period, unchanged from 0000926326-23-000031:mdna:76]

[0000926326-23-000041:mdna:76]
[same as prior period, unchanged from 0000926326-23-000031:mdna:77]

[0000926326-23-000041:mdna:77]
|  | Three Months Ended September 30, |
|  |  |  |  |  | Change in |
|  | 2023 |  | 2022 |  | $ |  | % |
|  | (Dollars in thousands) |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | $ | 106,311 |  |  | $ | 134,023 |  |  | $ | (27,712) |  |  | (21)% |
| As a percentage of related revenues | 56% |  | 54% |  |  |  |  |
| Cost of services and other revenues | 60,388 |  |  | 54,941 |  |  | 5,447 |  |  | 10% |
| As a percentage of related revenues | 55% |  | 54% |  |  |  |  |
| Total cost of revenues | $ | 166,699 |  |  | $ | 188,964 |  |  | $ | (22,265) |  |  | (12)% |
| As a percentage of total revenues | 56% |  | 54% |  |  |  |  |
| Gross profit | $ | 131,964 |  |  | $ | 159,095 |  |  | $ | (27,131) |  |  | (17)% |
| Gross margin | 44% |  | 46% |  |  |  |  |

[0000926326-23-000041:mdna:78]
Cost of revenues for the three months ended September 30, 2023 compared to the three months ended September 30, 2022 decreased by $22.3 million, primarily driven by a $27.7 million decrease in cost of product revenues, partially offset by a $5.4 million increase in cost of services and other revenues.

[0000926326-23-000041:mdna:79]
The decrease in cost of product revenues was primarily driven by the decrease in product revenues of $57.8 million for the three months ended September 30, 2023 compared to the three months ended September 30, 2022. The decrease in cost of product revenues has not decreased proportionally with the decrease in product revenues for the three months ended September 30, 2023, primarily due to certain fixed costs, such as labor and overhead. In addition, the decrease in cost of product revenues was also driven by lower inventory-related costs as pricing for semiconductors, steel, freight, and other costs has decreased from the prior period. The increase in cost of services and other revenues was primarily driven by the increase in services and other revenues of $8.4 million for the three months ended September 30, 2023 compared to the three months ended September 30, 2022.

[0000926326-23-000041:mdna:80]
The overall decrease in gross margin primarily relates to lower product revenues for the three months ended September 30, 2023 compared to the three months ended September 30, 2022 whereas the decrease in cost of product revenues has not decreased proportionally with the decrease in product revenues, primarily due to certain fixed costs, such as labor and overhead. The decrease is partially offset by lower inventory-related costs. Our gross profit for the three months ended September 30, 2023 was $132.0 million, as compared to $159.1 million for the three months ended September 30, 2022.

[0000926326-23-000041:mdna:81]
|  | Nine Months Ended September 30, |
|  |  |  |  |  | Change in |
|  | 2023 |  | 2022 |  | $ |  | % |
|  | (Dollars in thousands) |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | $ | 323,800 |  |  | $ | 374,175 |  |  | $ | (50,375) |  |  | (13)% |
| As a percentage of related revenues | 58% |  | 53% |  |  |  |  |
| Cost of services and other revenues | 173,029 |  |  | 156,864 |  |  | 16,165 |  |  | 10% |
| As a percentage of related revenues | 53% |  | 54% |  |  |  |  |
| Total cost of revenues | $ | 496,829 |  |  | $ | 531,039 |  |  | $ | (34,210) |  |  | (6)% |
| As a percentage of total revenues | 56% |  | 53% |  |  |  |  |
| Gross profit | $ | 391,436 |  |  | $ | 467,234 |  |  | $ | (75,798) |  |  | (16)% |
| Gross margin | 44% |  | 47% |  |  |  |  |

[0000926326-23-000041:mdna:82]
Cost of revenues for the nine months ended September 30, 2023 compared to the nine months ended September 30, 2022 decreased by $34.2 million, primarily driven by a $50.4 million decrease in cost of product revenues, partially offset by a $16.2 million increase in cost of services and other revenues.

[0000926326-23-000041:mdna:83]
The decrease in cost of product revenues was primarily driven by the decrease in product revenues of $143.3 million for the nine months ended September 30, 2023 compared to the nine months ended September 30, 2022. The decrease in cost of product revenues has not decreased proportionally with the decrease in product revenues for the nine months ended September 30, 2023, primarily due to certain fixed costs, such as labor and overhead. In addition, the decrease in cost of product revenues was also driven by lower inventory-related costs as pricing for semiconductors, steel, freight, and other costs has decreased from the prior period. The increase in cost of services and other revenues was primarily driven by the increase in services and other revenues of $33.3 million for the nine months ended September 30, 2023 compared to the nine months ended September 30, 2022.

[0000926326-23-000041:mdna:84]
The overall decrease in gross margin primarily relates to lower product revenues for the nine months ended September 30, 2023 compared to the nine months ended September 30, 2022 whereas the decrease in cost of product revenues has not decreased proportionally with the decrease in product revenues, primarily due to certain fixed costs, such as labor and overhead. The decrease is partially offset by lower inventory-related costs. Our gross profit for the nine months ended September 30, 2023 was $391.4 million, as compared to $467.2 million for the nine months ended September 30, 2022.

[0000926326-23-000041:mdna:85]
[same as prior period, unchanged from 0000926326-23-000031:mdna:86]

[0000926326-23-000041:mdna:86]
|  | Three Months Ended September 30, |
|  |  |  |  |  | Change in |
|  | 2023 |  | 2022 |  | $ |  | % |
|  | (Dollars in thousands) |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | $ | 24,281 |  |  | $ | 25,171 |  |  | $ | (890) |  |  | (4)% |
| As a percentage of total revenues | 8% |  | 7% |  |  |  |  |
| Selling, general, and administrative | 103,971 |  |  | 115,459 |  |  | (11,488) |  |  | (10)% |
| As a percentage of total revenues | 35% |  | 33% |  |  |  |  |
| Total operating expenses | $ | 128,252 |  |  | $ | 140,630 |  |  | $ | (12,378) |  |  | (9)% |
| As a percentage of total revenues | 43% |  | 40% |  |  |  |  |
| Interest and other income (expense), net | $ | 3,670 |  |  | $ | (1,148) |  |  | $ | 4,818 |  |  | (420)% |

[0000926326-23-000041:mdna:87]
Research and Development. Research and development expenses decreased by $0.9 million for the three months ended September 30, 2023 compared to the three months ended September 30, 2022. The decrease was primarily driven by cost saving initiatives, including the impact from lower consulting expenses.

[0000926326-23-000041:mdna:88]
Selling, General, and Administrative. Selling, general, and administrative expenses decreased by $11.5 million for the three months ended September 30, 2023 compared to the three months ended September 30, 2022. The decrease was primarily due to a decrease of $3.4 million in consulting expenses, a decrease of $2.7 million in commission expenses, a decrease of $2.2 million in freight out, a decrease of $1.4 million in employee-related expenses for restructuring initiatives, a decrease of $1.4 million in rent expense, and a decrease of $1.2 million of ransomware-related expenses, net of insurance recoveries, incurred during the three months ended September 30, 2022. The decrease was partially offset by $1.3 million of executives transition costs incurred during the three months ended September 30, 2023.

[0000926326-23-000041:mdna:89]
Interest and Other Income (Expense), Net. Interest and other income (expense), net changed by $4.8 million for the three months ended September 30, 2023 compared to the three months ended September 30, 2022, primarily driven by a $4.5 million increase in other income and a $0.3 million decrease in other expense. The increase in other income during the three months ended September 30, 2023 as compared to the three months ended September 30, 2022 is primarily attributable to higher interest income received due to higher interest rates and higher cash and cash equivalents balances.

[0000926326-23-000041:mdna:90]
|  | Nine Months Ended September 30, |
|  |  |  |  |  | Change in |
|  | 2023 |  | 2022 |  | $ |  | % |
|  | (Dollars in thousands) |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | $ | 70,296 |  |  | $ | 76,556 |  |  | $ | (6,260) |  |  | (8)% |
| As a percentage of total revenues | 8% |  | 8% |  |  |  |  |
| Selling, general, and administrative | 332,643 |  |  | 354,644 |  |  | (22,001) |  |  | (6)% |
| As a percentage of total revenues | 37% |  | 36% |  |  |  |  |
| Total operating expenses | $ | 402,939 |  |  | $ | 431,200 |  |  | $ | (28,261) |  |  | (7)% |
| As a percentage of total revenues | 45% |  | 43% |  |  |  |  |
| Interest and other income (expense), net | $ | 9,912 |  |  | $ | (2,973) |  |  | $ | 12,885 |  |  | (433)% |

[0000926326-23-000041:mdna:91]
Research and Development. Research and development expenses decreased by $6.3 million for the nine months ended September 30, 2023 compared to the nine months ended September 30, 2022. The decrease was primarily attributed to a decrease of $5.2 million in consulting expenses, a decrease in employee-related expenses for restructuring initiatives of $1.4 million, a decrease due to the timing of capitalized software projects of $1.3 million and other decreases from cost saving initiatives, partially offset by an increase of $3.8 million in employee-related expenses due to increased headcount.

[0000926326-23-000041:mdna:92]
[same as prior period, unchanged from 0000926326-23-000031:mdna:96]

[0000926326-23-000041:mdna:93]
Selling, General, and Administrative. Selling, general, and administrative expenses decreased by $22.0 million for the nine months ended September 30, 2023 compared to the nine months ended September 30, 2022. The decrease was primarily due to a decrease of $5.8 million in commissions expenses, a decrease of $4.9 million in employee-related expenses, a decrease of $4.5 million in consulting expenses, a decrease of $3.4 million in freight out, a decrease of $3.3 million in travel expenses, and a decrease of $2.6 million in temporary labor expenses. The decrease is also driven by $2.3 million of ransomware-related expenses, net of insurance recoveries, incurred during the nine months ended September 30, 2022. The decrease is partially offset by an increase of $2.0 million in employee-related expenses for restructuring initiatives, an increase of $2.4 million for impairment and abandonment charges of operating lease right-of-use assets in connection with restructuring activities of certain leased facilities, as well as an increase of $2.2 million in executives transition costs incurred during the nine months ended September 30, 2023.

[0000926326-23-000041:mdna:94]
Interest and Other Income (Expense), Net. Interest and other income (expense), net changed by $12.9 million for the nine months ended September 30, 2023 compared to the nine months ended September 30, 2022, primarily driven by a $12.1 million increase in other income and a $0.8 million decrease in other expense. The increase in other income during the nine months ended September 30, 2023 as compared to the nine months ended September 30, 2022 is primarily attributable to higher interest income received due to higher interest rates and higher cash and cash equivalents balances.

[0000926326-23-000041:mdna:95]
[same as prior period, unchanged from 0000926326-23-000031:mdna:97]

[0000926326-23-000041:mdna:96]
|  | Three Months Ended September 30, |
|  |  |  |  |  | Change in |
|  | 2023 |  | 2022 |  | $ |  | % |
|  | (Dollars in thousands) |
| Provision for income taxes | $ | 1,829 |  |  | $ | 543 |  |  | $ | 1,286 |  |  | 237% |

[0000926326-23-000041:mdna:97]
|  | Nine Months Ended September 30, |
|  |  |  |  |  | Change in |
|  | 2023 |  | 2022 |  | $ |  | % |
|  | (Dollars in thousands) |
| Provision for (benefit from) income taxes | $ | 4,405 |  |  | $ | (995) |  |  | $ | 5,400 |  |  | (543)% |

[0000926326-23-000041:mdna:98]
For the nine months ended September 30, 2023, we recorded a provision for income taxes of $4.4 million by applying our estimated annual effective tax rate to our year-to-date measure of ordinary income and adjusted for $5.6 million of discrete income tax expense primarily from equity compensation. For the nine months ended September 30, 2022, we recorded a benefit from income taxes of $1.0 million, and included a net discrete income tax benefit of $6.9 million, primarily due to a $5.1 million tax benefit from equity compensation. The change in the provision for income taxes for the nine months ended September 30, 2023 compared to the benefit from income taxes for the same period in 2022 was primarily due to a decrease in excess tax benefit from equity compensation, as well as the change in income (loss) before income taxes.

[0000926326-23-000041:mdna:99]
[same as prior period, unchanged from 0000926326-23-000031:mdna:101]

[0000926326-23-000041:mdna:100]
[same as prior period, unchanged from 0000926326-23-000031:mdna:102]

[0000926326-23-000041:mdna:101]
We had cash and cash equivalents of $446.8 million at September 30, 2023 compared to $330.4 million at December 31, 2022. All of our cash and cash equivalents are invested in bank accounts and money market funds held in sweep and asset management accounts with financial institutions of high credit quality.

[0000926326-23-000041:mdna:102]
Our cash position and working capital at September 30, 2023 and December 31, 2022 were as follows:

[0000926326-23-000041:mdna:103]
|  | September 30,2023 |  | December 31,2022 |
|  | (In thousands) |
| Cash and cash equivalents | $ | 446,840 |  |  | $ | 330,362 |  |
| Working capital | $ | 544,390 |  |  | $ | 453,366 |  |

[0000926326-23-000041:mdna:104]
Our ratio of current assets to current liabilities was 2.5:1 and 2.1:1 at September 30, 2023 and December 31, 2022, respectively.

[0000926326-23-000041:mdna:105]
[same as prior period, unchanged from 0000926326-23-000031:mdna:107]

[0000926326-23-000041:mdna:106]
Revolving Credit Facility

[0000926326-23-000041:mdna:107]
On November 15, 2019, we entered into an Amended and Restated Credit Agreement (as amended, the “Prior A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers, and Wells Fargo Bank, National Association, as administrative agent. The Prior A&R Credit Agreement provided for (a) a five-year revolving credit facility of $500.0 million (the “Prior Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million (the “Prior Incremental Facility”). In addition, the Prior A&R Credit Agreement included a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million.

[0000926326-23-000041:mdna:108]
On September 22, 2020 and March 29, 2023, we entered into amendments to the Prior A&R Credit Agreement to, among other changes, permit the issuance of the convertible senior notes and the purchase of the convertible note hedge transactions, as described in Note 10, Convertible Senior Notes, expand our flexibility to repurchase our common stock and make other restricted payments, and replace the total net leverage covenant, as well as to remove and replace the interest rate benchmark based on the London interbank offered rate (“LIBOR”) and related LIBOR-based mechanics applicable to borrowings under the A&R Credit Agreement with an interest rate benchmark based on the secured overnight financing rate (“SOFR”) as administered by the Federal Reserve Bank of New York and related SOFR-based mechanics.

[0000926326-23-000041:mdna:109]
On October 10, 2023, we entered into a Second Amended and Restated Credit Agreement (the “Second A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, JPMorgan Chase Bank, N.A., PNC Capital Markets LLC and TD Securities (USA) LLC as joint lead arrangers and Wells Fargo Bank, National Association, as administrative agent. The Second A&R Credit Agreement supersedes the Prior A&R Credit Agreement and provides for (a) a five-year revolving credit facility of $350.0 million (the “Current Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to an amount equal to the sum of (i) the greater of $250.0 million and 100% of the adjusted consolidated EBITDA for the last four quarters and (ii) additional amounts subject to pro forma compliance with certain consolidated secured net leverage ratio (the “Current Incremental Facility”). In addition, the Second A&R Credit Agreement includes a letter of credit sub-limit of up to $15 million and a swing line loan sub-limit of up to $25 million. The Second A&R Credit Agreement has an expiration date of October 10, 2028, subject to acceleration under certain conditions, upon which date all remaining outstanding borrowings will be due and payable.

[0000926326-23-000041:mdna:110]
As of September 30, 2023, we had $500.0 million of funds available and no outstanding balance under the Prior Revolving Credit Facility. As of September 30, 2023, we were in compliance with all covenants under the Prior A&R Credit Agreement. Upon entry into the Second A&R Credit Agreement, we had $350.0 million of funds available under the Current Revolving Credit Facility. Refer to Note 9, Debt and Credit Agreement, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional information. We expect to use future loans under the Current Revolving Credit Facility, if any, for working capital, potential acquisitions, and other general corporate purposes.

[0000926326-23-000041:mdna:111]
[same as prior period, unchanged from 0000926326-23-000031:mdna:114]

[0000926326-23-000041:mdna:112]
[same as prior period, unchanged from 0000926326-23-000031:mdna:115]

[0000926326-23-000041:mdna:113]
The 2016 Repurchase Program has a total of $2.7 million remaining for future repurchases as of September 30, 2023, which may result in additional use of cash. There were no stock repurchases during the nine months ended September 30, 2023. Refer to “Stock Repurchase Programs” under Note 15, Employee Benefits and Share-Based Compensation, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional information.

[0000926326-23-000041:mdna:114]
Based on our current business plan and backlog, we believe that our existing cash and cash equivalents, our anticipated cash flows from operations, cash generated from the exercise of employee stock options and purchases under our Employee Stock Purchase Plan (“ESPP”), along with the availability of funds under the Revolving Credit Facility will be sufficient to meet our cash needs for working capital, capital expenditures, potential acquisitions, and other contractual obligations for at least the next twelve months. For periods beyond the next twelve months, we also anticipate that our net operating cash flows plus existing balances of cash and cash equivalents will suffice to fund the continued growth of our business.

[0000926326-23-000041:mdna:115]
[same as prior period, unchanged from 0000926326-23-000031:mdna:118]

[0000926326-23-000041:mdna:116]
[same as prior period, unchanged from 0000926326-23-000031:mdna:119]

[0000926326-23-000041:mdna:117]
|  | Nine Months Ended September 30, |
|  | 2023 |  | 2022 |
|  | (In thousands) |
| Net cash provided by (used in): |  |  |  |
| Operating activities | $ | 142,680 |  |  | $ | (4,372) |  |
| Investing activities | (42,644) |  |  | (41,417) |  |
| Financing activities | 10,290 |  |  | (24,515) |  |
| Effect of exchange rate changes on cash and cash equivalents | (464) |  |  | (1,425) |  |
| Net increase (decrease) in cash, cash equivalents, and restricted cash | $ | 109,862 |  |  | $ | (71,729) |  |

[0000926326-23-000041:mdna:118]
[same as prior period, unchanged from 0000926326-23-000031:mdna:121]

[0000926326-23-000041:mdna:119]
[same as prior period, unchanged from 0000926326-23-000031:mdna:122]

[0000926326-23-000041:mdna:120]
Net cash provided by operating activities was $142.7 million for the nine months ended September 30, 2023, primarily consisting of a net loss of $6.0 million adjusted for non-cash items of $113.8 million and changes in assets and liabilities of $34.9 million. The non-cash items primarily consisted of depreciation and amortization expense of $65.6 million, share-based compensation expense of $43.1 million, impairment and abandonment of operating lease right-of-use assets related to facilities of $7.8 million, amortization of operating lease right-of-use assets of $6.2 million, amortization of debt issuance costs of $3.1 million, and a change in deferred income taxes of $14.2 million. Changes in assets and liabilities include cash inflows primarily from (i) a decrease in inventories of $31.7 million primarily due to management of inventory levels to align with the current forecasted demand, (ii) a decrease in accounts receivable and unbilled receivables of $27.1 million primarily due to the timing of billings, shipments, and collections, as well as the impacts of lower revenues, (iii) an increase in deferred revenues of $23.6 million primarily due to an increase in billings for certain service and subscription offerings, (iv) a decrease in prepaid commissions of $5.5 million, (v) an increase in accrued liabilities of $3.7 million, (vi) a decrease in other long-term assets of $2.5 million, and (vii) a decrease in other current assets of $1.5 million. These cash inflows were partially offset by (i) a decrease in accrued compensation of $29.4 million primarily due to a decrease in the accrual for restructuring initiatives, lower commissions, as well as timing of payroll and ESPP purchases, (ii) a decrease in accounts payable of $13.4 million primarily due to an overall decrease in spending, as well as timing of payments, (iii) an increase in investment in sales-type leases of $8.8 million primarily due to the acceptance of certain Advanced Services products under sales-type lease arrangements, and (iv) a decrease in operating lease liabilities of $8.1 million.

[0000926326-23-000041:mdna:121]
Net cash used in operating activities was $4.4 million for the nine months ended September 30, 2022, primarily consisting of net income of $34.1 million adjusted for non-cash items of $117.1 million, offset by changes in assets and liabilities of $155.6 million. The non-cash items primarily consisted of depreciation and amortization expense of $64.8 million, share-based compensation expense of $50.7 million, amortization of operating lease right-of-use assets of $9.7 million, impairment and abandonment of operating lease right-of-use assets of $5.4 million, amortization of debt issuance costs of $3.1 million, and a change in deferred income taxes of $17.1 million. Changes in assets and liabilities include cash outflows from (i) an increase in accounts receivable and unbilled receivables of $116.9 million primarily due to an increase in billings driven by overall business growth and the timing of shipments and collections, (ii) an increase in inventories of $32.3 million primarily to support forecasted sales, including advanced purchases of certain components, such as semiconductors, as well as higher costs of inventory and timing of shipments, (iii) a decrease in accrued compensation of $27.9 million primarily due to a decrease in accrued commissions and bonuses, as well as timing of payroll and ESPP purchases, (iv) an increase in investment in sales-type leases of $17.3 million primarily due to the increase in sales-type lease revenues associated with certain Advanced Services products, (v) a decrease in operating lease liabilities of $11.0 million, and (vi) an increase in prepaid expenses of $2.6 million. These cash outflows were partially offset by (i) an increase in deferred revenues of $17.7 million primarily due to an increase in billings driven by the timing of shipments in order to meet customers’ implementation schedules and recognition of revenues for products requiring installation, (ii) an increase in accrued liabilities of $11.7 million primarily due to an increase in taxes payable, (iii) a decrease in prepaid commissions of $8.8 million, (iv) a decrease in other current assets, net of funds held for customers, of $6.7 million primarily due to a decrease in prepaid income taxes, (v) a decrease in other long-term assets of $4.2 million, (vi) an increase in accounts payable of $2.0 million, and (vii) an increase in other long-term liabilities of $1.4 million.

[0000926326-23-000041:mdna:122]
[same as prior period, unchanged from 0000926326-23-000031:mdna:126]

[0000926326-23-000041:mdna:123]
Net cash used in investing activities was $42.6 million for the nine months ended September 30, 2023, which consisted of capital expenditures of $32.4 million for property and equipment, and $10.2 million for external-use software development costs.

[0000926326-23-000041:mdna:124]
Net cash used in investing activities was $41.4 million for the nine months ended September 30, 2022, which consisted of $3.4 million consideration paid for the acquisition of Hub and Spoke Innovations, net of cash acquired, capital expenditures of $33.9 million for property and equipment, and $9.6 million for costs of software development for external use, partially offset by purchase price adjustments from business acquisitions of $5.5 million.

[0000926326-23-000041:mdna:125]
[same as prior period, unchanged from 0000926326-23-000031:mdna:129]

[0000926326-23-000041:mdna:126]
Net cash provided by financing activities was $10.3 million for the nine months ended September 30, 2023, primarily due to $23.0 million in proceeds from employee stock option exercises and ESPP purchases, partially offset by $6.1 million in employees’ taxes paid related to restricted stock unit vesting and a net change in the customer funds balances of $6.6 million.

[0000926326-23-000041:mdna:127]
Net cash used in financing activities was $24.5 million for the nine months ended September 30, 2022, primarily due to $52.2 million for repurchases of our stock, and $11.4 million in employees’ taxes paid related to restricted stock unit vesting, partially offset by $39.5 million in proceeds from employee stock option exercises and ESPP purchases.

[0000926326-23-000041:mdna:128]
[same as prior period, unchanged from 0000926326-23-000031:mdna:132]

[0000926326-23-000041:mdna:129]
There have been no significant changes during the nine months ended September 30, 2023 to the contractual obligations disclosed in “Management’s Discussion and Analysis of Financial Condition and Results of Operations,” set forth in Part II, Item 7, of our Annual Report on Form 10-K for the year ended December 31, 2022.

[0000926326-23-000041:mdna:130]
Contractual obligations as of September 30, 2023 were as follows:

[0000926326-23-000041:mdna:131]
|  | Payments Due By Period |
|  | Total |  | Remainder of 2023 |  | 2024 - 2025 |  | 2026 - 2027 |  | 2028 and thereafter |
|  | (In thousands) |
| Operating leases (1) | $ | 49,540 |  |  | $ | 3,340 |  |  | $ | 21,870 |  |  | $ | 16,276 |  |  | $ | 8,054 |  |
| Purchase obligations (2) | 118,658 |  |  | 78,055 |  |  | 40,471 |  |  | 132 |  |  | — |  |
| Convertible senior notes (3) | 577,875 |  |  | — |  |  | 577,875 |  |  | — |  |  | — |  |
| Total (4) | $ | 746,073 |  |  | $ | 81,395 |  |  | $ | 640,216 |  |  | $ | 16,408 |  |  | $ | 8,054 |  |

[0000926326-23-000041:mdna:132]
[same as prior period, unchanged from 0000926326-23-000031:mdna:136]

[0000926326-23-000041:mdna:133]
[same as prior period, unchanged from 0000926326-23-000031:mdna:137]

[0000926326-23-000041:mdna:134]
[same as prior period, unchanged from 0000926326-23-000031:mdna:138]

[0000926326-23-000041:mdna:135]
[same as prior period, unchanged from 0000926326-23-000031:mdna:139]

[0000926326-23-000041:mdna:136]
(4)Refer to Note 13, Commitments and Contingencies, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional information.
