# OMCL note change history — 0000926326-23-000031 → 0000926326-23-000041


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-11-03):
[0000926326-23-000041:note_history:1]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of September 30, 2023, the Company had non-cancelable purchase commitments of $118.7 million, of which $78.1 million are expected to be paid within the year ending December 31, 2023.
  (was, 2023-08-04, similarity 0.9765):
[0000926326-23-000031:note_history:1]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of June 30, 2023, the Company had non-cancelable purchase commitments of $127.1 million, of which $106.9 million are expected to be paid within the year ending December 31, 2023.

- changed (2023-11-03):
[0000926326-23-000041:note_history:2]
During the nine months ended September 30, 2023, the Company did not incur any material expenses or recoveries related to the previously disclosed ransomware incident. During the three months ended September 30, 2022, the Company incurred $1.0 million of expenses related to the ransomware incident, and during the nine months ended September 30, 2022, the Company incurred $13.5 million of expenses related to the ransomware incident, partially offset by $11.1 million of expected insurance recoveries. Expenses include costs to investigate and remediate the ransomware incident, as well as legal and other professional services, all of which were expensed as incurred. For the three and nine months ended September 30, 2022, the Company included net expenses related to the ransomware incident in cost of revenues of $0.1 million and $0.3 million, respectively; in research and development of $0.2 million and $0.2 million, respectively; and in selling, general, and administrative expenses of $0.7 million and $1.9 million, respectively, in the Company’s Condensed Consolidated Statements of Operations.
  (was, 2023-08-04, similarity 0.7271):
[0000926326-23-000031:note_history:2]
During the six months ended June 30, 2023, the Company did not incur any material expenses related to the previously disclosed ransomware incident. During the three months ended June 30, 2022, the Company incurred $12.5 million of expenses related to the ransomware incident, partially offset by $11.1 million of expected insurance recoveries. Expenses include costs to investigate and remediate the ransomware incident, as well as legal and other professional services, all of which were expensed as incurred. For the three months ended June 30, 2022, the Company included net expenses of $0.2 million in cost of revenues and $1.2 million in selling, general, and administrative expenses in the Company’s Condensed Consolidated Statements of Operations.

- changed (2023-11-03):
[0000926326-23-000041:note_history:3]
As of September 30, 2023, the Company has incurred $13.6 million of cumulative expenses related to the ransomware incident since it was detected, partially offset by $11.6 million of insurance recoveries, all of which have been received as of September 30, 2023.
  (was, 2023-08-04, similarity 0.899):
[0000926326-23-000031:note_history:3]
As of June 30, 2023, the Company has incurred $13.6 million of cumulative expenses related to the ransomware incident since it was detected, partially offset by $11.1 million of insurance recoveries, of which $10.9 million have been received as of June 30, 2023.

- changed (2023-11-03):
[0000926326-23-000041:note_history:4]
As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any material accrual for contingent liabilities associated with any current legal proceedings based on its belief that any potential material loss, while reasonably possible, is not probable. Furthermore, any possible range of loss in such matters cannot be reasonably estimated at this time. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However,
  (was, 2023-08-04, similarity 0.7388):
[0000926326-23-000031:note_history:4]
As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any material accrual for contingent liabilities associated with its current legal proceedings based on its belief that any potential material loss, while

- added (2023-11-03):
[0000926326-23-000041:note_history:5]
litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of legal proceedings or because of the diversion of management’s attention and the creation of significant expenses, regardless of outcome.

- removed (2023-11-03):
[0000926326-23-000031:note_history:6]
A class action lawsuit was filed against the Company, on June 5, 2019, in the Circuit Court of Cook County, Illinois, Chancery Division, captioned Corey Heard, individually and on behalf of all others similarly situated v. Omnicell, Inc., Case No. 2019-CH-06817 (the “Heard Action”). The complaint seeks class certification, monetary damages in the form of statutory damages for willful and/or reckless or, in the alternative, negligent violation of the Illinois Biometric Information Privacy Act (“BIPA”), and certain declaratory, injunctive, and other relief based on causes of action directed to allegations of violation of BIPA by the Company. The complaint was served on the Company on June 13, 2019. On July 31, 2019, the Company filed a motion to stay or consolidate the case with the action Yana Mazya, et al. v. Northwestern Lake Forest Hospital, et al., Case No. 2018-CH-07161, pending in the Circuit Court of Cook County, Illinois, Chancery Division (the “Mazya Action”). The Court subsequently, on October 10, 2019, denied the motion, without prejudice, as being moot in view of the dismissal of the claims against the Company in the Mazya Action. The Company filed a motion to dismiss the complaint in the Heard Action on October 31, 2019. The hearing on the Company’s motion to dismiss was held on September 2, 2020. The Court ruled from the bench and dismissed the complaint without prejudice giving plaintiff leave to file an amended complaint by September 30, 2020. Plaintiff filed an amended complaint on September 30, 2020 and the Company subsequently filed a motion to dismiss the amended complaint on October 28, 2020, which was fully briefed, but the Court had not heard oral argument on the motion. The parties entered into a settlement agreement on January 25, 2022, (the “Settlement Agreement”). On February 1, 2022, the Court granted preliminary approval of the settlement. Following preliminary approval, plaintiff conducted discovery to identify class members and to determine the class size. Pursuant to the terms of the Settlement Agreement, and following class size discovery, the parties participated in non-binding mediation on November 21, 2022. A settlement was reached at the mediation and the parties executed an addendum to the Settlement Agreement (the “Addendum”) reflecting the changes to the original settlement terms. On November 30, 2022, the Court granted preliminary approval of the settlement contemplated by the Settlement Agreement, as amended by the Addendum. The Addendum required Omnicell to make a total settlement payment of $4.3 million. On April 6, 2023, the Court granted final approval of the settlement, including the Addendum, and entered judgment in the matter dismissing all claims against Omnicell with prejudice. The Company made its final required settlement payment installment on or before the April 21, 2023 due date.

- removed (2023-11-03):
[0000926326-23-000031:note_history:7]
reasonably possible, is not probable. Furthermore, any possible range of loss in these matters cannot be reasonably estimated at this time. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of legal proceedings or because of the diversion of management’s attention and the creation of significant expenses, regardless of outcome.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-11-03):
[0000926326-23-000041:note_history:8]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of September 30, 2023 and December 31, 2022, the results of operations and comprehensive income (loss) for the three and nine months ended September 30, 2023 and 2022, and cash flows for the nine months ended September 30, 2023 and 2022. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s Annual Report on Form 10-K for the year ended December 31, 2022, filed with the SEC on March 1, 2023, except as discussed in the section entitled “Recently Adopted Authoritative Guidance” below. The Company’s results of operations and comprehensive income (loss) for the three and nine months ended September 30, 2023, and cash flows for the nine months ended September 30, 2023 are not necessarily indicative of results that may be expected for the year ending December 31, 2023, or for any future period.
  (was, 2023-08-04, similarity 0.8302):
[0000926326-23-000031:note_history:8]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of June 30, 2023 and December 31, 2022, the results of operations and comprehensive income (loss) for the three and six months ended June 30, 2023 and 2022, and cash flows for the six months ended June 30, 2023 and 2022. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s Annual Report on Form 10-K for the year ended December 31, 2022, filed with the SEC on March 1, 2023, except as discussed in the section entitled “Recently Adopted Authoritative Guidance” below. The Company’s results of operations and comprehensive income (loss) for the three and six months ended June 30, 2023, and cash flows for the six months ended June 30, 2023 are not necessarily indicative of results that may be expected for the year ending December 31, 2023, or for any future period.

- added (2023-11-03):
[0000926326-23-000041:note_history:9]
The Company’s critical accounting policies are those that affect its financial statements materially and involve difficult, subjective, or complex judgments by management. As of September 30, 2023, the Company is not aware of any events or circumstances that would require an update to its estimates, judgments, or revisions to the carrying value of its assets or liabilities.

- removed (2023-11-03):
[0000926326-23-000031:note_history:10]
The Company’s critical accounting policies are those that affect its financial statements materially and involve difficult, subjective, or complex judgments by management. As of June 30, 2023, the Company is not aware of any events or circumstances that would require an update to its estimates, judgments, or revisions to the carrying value of its assets or liabilities.


## omcl:ScheduleOfInterestExpenseDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-11-03):
[0000926326-23-000041:note_history:11]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three and nine months ended September 30, 2023 and 2022:
  (was, 2023-08-04, similarity 0.9055):
[0000926326-23-000031:note_history:11]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three and six months ended June 30, 2023 and 2022:

- added (2023-11-03):
[0000926326-23-000041:note_history:12]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  | (In thousands) |
| Contractual coupon interest | $ | 359 |  |  | $ | 359 |  |  | $ | 1,078 |  |  | $ | 1,078 |  |
| Amortization of debt issuance costs | $ | 773 |  |  | $ | 768 |  |  | $ | 2,316 |  |  | $ | 2,298 |  |

- removed (2023-11-03):
[0000926326-23-000031:note_history:13]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  | (In thousands) |
| Contractual coupon interest | $ | 359 |  |  | $ | 359 |  |  | $ | 719 |  |  | $ | 719 |  |
| Amortization of debt issuance costs | $ | 772 |  |  | $ | 766 |  |  | $ | 1,543 |  |  | $ | 1,530 |  |


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-11-03):
[0000926326-23-000041:note_history:14]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of September 30, 2023 and December 31, 2022:
  (was, 2023-08-04, similarity 0.9591):
[0000926326-23-000031:note_history:14]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of June 30, 2023 and December 31, 2022:

- changed (2023-11-03):
[0000926326-23-000041:note_history:15]
|  | September 30,2023 |  | December 31,2022 |
|  | (In thousands) |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized debt issuance costs | (6,113) |  |  | (8,429) |  |
| Convertible senior notes, net | $ | 568,887 |  |  | $ | 566,571 |  |
  (was, 2023-08-04, similarity 0.9189):
[0000926326-23-000031:note_history:15]
|  | June 30,2023 |  | December 31,2022 |
|  | (In thousands) |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized debt issuance costs | (6,886) |  |  | (8,429) |  |
| Convertible senior notes, net | $ | 568,114 |  |  | $ | 566,571 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2023-11-03):
[0000926326-23-000041:note_history:16]
Debt and Credit AgreementOn November 15, 2019, the Company entered into an Amended and Restated Credit Agreement (as amended, the “Prior A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers, and Wells Fargo Bank, National Association, as administrative 
agent. The Prior A&R Credit Agreement provided for (a) a five-year revolving credit facility of $500.0 million (the “Prior Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million (the “Prior Incremental Facility”). In addition, the Prior A&R Credit Agreement included a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The Prior A&R Credit Agreement had an expiration date of November 15, 2024, upon which date all remaining outstanding borrowings would be due and payable.

- changed (2023-11-03):
[0000926326-23-000041:note_history:17]
On September 22, 2020 and March 29, 2023, the Company entered into amendments to the Prior A&R Credit Agreement to, among other changes, permit the issuance of the convertible senior notes and the purchase of the convertible note hedge transactions, as described in Note 10, Convertible Senior Notes, expand the Company’s flexibility to repurchase its common stock and make other restricted payments, and replace the total net leverage covenant with a new secured net leverage covenant that requires the Company to maintain a consolidated secured net leverage ratio not to exceed 3.50:1 for the calendar quarters ending September 30, 2020, December 31, 2020, and March 31, 2021 and 3.00:1 for the calendar quarters ending thereafter, as well as to remove and replace the interest rate benchmark based on the London interbank offered rate (“LIBOR”) and related LIBOR-based mechanics applicable to borrowings under the A&R Credit Agreement with an interest rate benchmark based on the secured overnight financing rate (“SOFR”) as administered by the Federal Reserve Bank of New York and related SOFR-based mechanics.
  (was, 2023-08-04, similarity 0.6879):
[0000926326-23-000031:note_history:17]
On September 22, 2020, the parties entered into a first amendment to the A&R Credit Agreement to, among other changes, permit the issuance of the convertible senior notes and the purchase of the convertible note hedge transactions, as described in Note 10, Convertible Senior Notes, expand the Company’s flexibility to repurchase its common stock and make other restricted payments, and replace the total net leverage covenant with a new secured net leverage covenant that requires the Company to maintain a consolidated secured net leverage ratio not to exceed 3.50:1 for the calendar quarters ending September 30, 2020, December 31, 2020, and March 31, 2021 and 3.00:1 for the calendar quarters ending thereafter. The availability of funds under the Revolving Credit Facility may be subject to reduction in order to maintain compliance with the financial covenants under the A&R Credit Agreement.

- changed (2023-11-03):
[0000926326-23-000041:note_history:18]
Loans under the Prior Revolving Credit Facility bore interest, at the Company’s option, at a rate equal to either (a) the Adjusted Term SOFR (as defined in the Prior A&R Credit Agreement), plus an applicable margin ranging from 1.25% to 2.00% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the Prior A&R Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) Adjusted Term SOFR for a one month tenor plus 1.00%, plus an applicable margin ranging from 0.25% to 1.00% per annum based on the Company’s Consolidated Total Net Leverage Ratio. Undrawn commitments under the Prior Revolving Credit Facility were subject to a commitment fee ranging from 0.15% to 0.30% per annum based on the Company’s Consolidated Total Net Leverage Ratio on the average daily unused portion of the Prior Revolving Credit Facility. The applicable margin for, and certain other terms of, any term loans under the Prior Incremental Facility would be determined prior to the incurrence of such loans. The Company was permitted to make voluntary prepayments at any time without payment of a premium or penalty.
  (was, 2023-08-04, similarity 0.8942):
[0000926326-23-000031:note_history:18]
Following the second amendment to the A&R Credit Agreement, loans under the Revolving Credit Facility bear interest, at the Company’s option, at a rate equal to either (a) the Adjusted Term SOFR (as defined in the A&R Credit Agreement), plus an applicable margin ranging from 1.25% to 2.00% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the A&R Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) Adjusted Term SOFR for a one month tenor plus 1.00%, plus an applicable margin ranging from 0.25% to 1.00% per annum based on the Company’s Consolidated Total Net Leverage Ratio. Undrawn commitments under the Revolving Credit Facility are subject to a commitment fee ranging from 0.15% to 0.30% per annum based on the Company’s Consolidated Total Net Leverage Ratio on the average daily unused portion of the Revolving Credit Facility. The applicable margin for, and certain other terms of, any term loans under the Incremental Facility will be determined prior to the incurrence of such loans. The Company is permitted to make voluntary prepayments at any time without payment of a premium or penalty.

- changed (2023-11-03):
[0000926326-23-000041:note_history:19]
The Prior A&R Credit Agreement contained customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends, and other distributions. The Prior A&R Credit Agreement also contained financial covenants that required the Company and its subsidiaries to not exceed a maximum total secured net leverage ratio (as described above) and maintain a minimum interest coverage ratio. In addition, the Prior A&R Credit Agreement contained certain customary events of default including, but not limited to, failure to pay interest, principal, and fees, or other amounts when due, material misrepresentations or misstatements in any representation or warranty, covenant defaults, certain cross defaults to other material indebtedness, certain judgment defaults, and events of bankruptcy.
  (was, 2023-08-04, similarity 0.6845):
[0000926326-23-000031:note_history:19]
The A&R Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends, and other distributions. The A&R Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum total secured net leverage ratio (as described above) and maintain a minimum interest coverage ratio. In addition, the A&R Credit Agreement contains certain customary events of default including, but not limited to, failure to pay interest, principal, and fees, or other amounts when due, material misrepresentations or misstatements in any representation or warranty, covenant defaults, certain cross defaults to other material indebtedness, certain judgment defaults, and events of bankruptcy. The Company’s obligations under the A&R Credit Agreement and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and such subsidiary guarantors’ assets. In connection with entering into the A&R Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a reaffirmation agreement, which amends certain terms of the existing collateral agreement and reaffirms their obligations under the existing guaranty agreement. The Company was in compliance with all covenants as of June 30, 2023.

- added (2023-11-03):
[0000926326-23-000041:note_history:20]
Subsequent to the quarter ended September 30, 2023, the Company entered into a Second Amended and Restated Credit Agreement (the “Second A&R Credit Agreement”) on October 10, 2023, with the lenders from time to time party thereto, Wells Fargo Securities, LLC, JPMorgan Chase Bank, N.A., PNC Capital Markets LLC and TD Securities (USA) LLC as joint lead arrangers and Wells Fargo Bank, National Association, as administrative agent. The Second A&R Credit Agreement supersedes the Prior A&R Credit Agreement and provides for (a) a five-year revolving credit facility of $350.0 million (the “Current Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to an amount equal to the sum of (i) the greater of $250.0 million or 100% of the adjusted consolidated EBITDA for the last four quarters and (ii) additional amounts subject to pro forma compliance with certain consolidated secured net leverage ratio (the “Current Incremental Facility”). In addition, the Second A&R Credit Agreement includes a letter of credit sub-limit of up to $15 million and a swing line loan sub-limit of up to $25 million. The Second A&R Credit Agreement has an expiration date of October 10, 2028, subject to acceleration under certain conditions, upon which date all remaining outstanding borrowings will be due and payable.

- added (2023-11-03):
[0000926326-23-000041:note_history:21]
Loans under the Current Revolving Credit Facility bear interest, at the Company’s option, at a rate equal to either (a) the Adjusted Term SOFR (as defined in the Second A&R Credit Agreement), plus an applicable margin ranging from 1.50% to 2.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the Second A&R Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) the Adjusted Term SOFR for an interest period of one month plus 1.00%, plus an applicable margin ranging from 0.50% to 1.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio. Undrawn commitments under the Current Revolving Credit Facility are subject to a commitment fee ranging from 0.20% to 0.35% per annum based on the Company’s Consolidated Total Net Leverage Ratio on the average daily unused portion of the Current Revolving Credit Facility. Subject to the terms and conditions of the Current Revolving Credit Facility or Current Incremental Facility, the Company is permitted to make voluntary prepayments at any time without payment of a premium or penalty. The availability of funds under the Current

- added (2023-11-03):
[0000926326-23-000041:note_history:22]
Revolving Credit Facility may be subject to reduction in order to maintain compliance with the financial covenants under the Second A&R Credit Agreement.

- added (2023-11-03):
[0000926326-23-000041:note_history:23]
The Second A&R Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends, and other distributions. The Second A&R Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum consolidated secured net leverage ratio (not to exceed 3.00:1) and maintain a minimum consolidated interest coverage ratio (not to be less than 3.00:1). In addition, the Second A&R Credit Agreement contains certain customary events of default including, but not limited to, failure to pay interest, principal and fees, or other amounts when due, material misrepresentations or misstatements in any representation or warranty, covenant defaults, certain cross defaults to other material indebtedness, certain judgment defaults, and events of bankruptcy.

- added (2023-11-03):
[0000926326-23-000041:note_history:24]
The Company’s obligations under the Second A&R Credit Agreement and, at the election of the Company and the contracting counterparty, any secured swap obligations and banking services obligations owing to a lender (or an affiliate of a lender), are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and such subsidiary guarantors’ assets. In connection with entering into the Second A&R Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a reaffirmation agreement, which amends certain terms of the existing collateral agreement and reaffirms their obligations under the existing guaranty agreement.

- added (2023-11-03):
[0000926326-23-000041:note_history:25]
As of both September 30, 2023 and December 31, 2022, the Company had $500.0 million of funds available under the Prior Revolving Credit Facility. As of September 30, 2023 and December 31, 2022, the Company had no outstanding balance under the Prior Revolving Credit Facility. The Company was in compliance with all covenants of the Prior A&R Credit Agreement as of September 30, 2023. Upon entry into the Second A&R Credit Agreement, the Company had $350.0 million of funds available under the Current Revolving Credit Facility. 
Convertible Senior Notes
0.25% Convertible Senior Notes due 2025

- added (2023-11-03):
[0000926326-23-000041:note_history:26]
During the three months ended September 30, 2023 and December 31, 2022, none of the conditional conversion features of the Notes were triggered, and therefore, the Notes are not convertible during the fourth quarter of 2023, commencing on October 1, 2023, and were not convertible during the first quarter of 2023, commencing on January 1, 2023. Accordingly, the Company classified the Notes as a long-term liability in its Condensed Consolidated Financial Statements as of both September 30, 2023 and December 31, 2022. Whether the Notes will be convertible following the fourth fiscal quarter of 2023 will depend on the satisfaction of the conversion conditions in the future.

- changed (2023-11-03):
[0000926326-23-000041:note_history:27]
If the Company undergoes a fundamental change, holders may require, subject to certain exceptions, the Company to repurchase for cash all or any portion of their Notes at a fundamental change repurchase price equal to 100% of the principal amount of the Notes to be repurchased, plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date. As of September 30, 2023, none of the criteria for a fundamental change or a conversion rate adjustment had been met.
  (was, 2023-08-04, similarity 0.8042):
[0000926326-23-000031:note_history:27]
If the Company undergoes a fundamental change, holders may require, subject to certain exceptions, the Company to repurchase for cash all or any portion of their Notes at a fundamental change repurchase price equal to 100% of the principal amount of the Notes to be repurchased, plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date. As of June 30, 2023, none of the criteria for a fundamental change or a conversion rate adjustment had been met.

- changed (2023-11-03):
[0000926326-23-000041:note_history:28]
As of September 20, 2023, the Company may redeem for cash all or any portion of the Notes, at its option, if the last reported sale price of the Company’s common stock has been at least 130% of the conversion price for the Notes then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which the Company provides notice of redemption at a redemption price equal to 100% of the principal amount of the Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. If the Company redeems less than all of the outstanding Notes, at least $150.0 million aggregate principal amount of Notes must be outstanding and not subject to redemption as of the date of the relevant notice of redemption. No sinking fund is provided for in the Notes.
  (was, 2023-08-04, similarity 0.6706):
[0000926326-23-000031:note_history:28]
The Company may not redeem the Notes prior to September 20, 2023. The Company may redeem for cash all or any portion of the Notes, at its option, on or after September 20, 2023, if the last reported sale price of the Company’s common stock has been at least 130% of the conversion price for the Notes then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which the Company provides notice of redemption at a

- changed (2023-11-03):
[0000926326-23-000041:note_history:29]
The debt issuance costs associated with the Notes are being amortized to interest expense over the term of the Notes using an effective interest rate of 0.80%. As of September 30, 2023, the remaining life of the Notes and the related issuance cost accretion is approximately 2.0 years.
  (was, 2023-08-04, similarity 0.9761):
[0000926326-23-000031:note_history:29]
The debt issuance costs associated with the Notes are being amortized to interest expense over the term of the Notes using an effective interest rate of 0.80%. As of June 30, 2023, the remaining life of the Notes and the related issuance cost accretion is approximately 2.2 years.

- changed (2023-11-03):
[0000926326-23-000041:note_history:30]
The maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to other conversion rate adjustments, would be 5.9 million shares. As of September 30, 2023, the if-converted value of the Notes did not exceed the principal amount.
  (was, 2023-08-04, similarity 0.7317):
[0000926326-23-000031:note_history:30]
The maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to other conversion rate adjustments, would be 5.9 million shares. As of June 30, 2023, the if-converted value of the Notes did not exceed the principal amount.

- changed (2023-11-03):
[0000926326-23-000041:note_history:31]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of September 30, 2023 and December 31, 2022:
  (was, 2023-08-04, similarity 0.9591):
[0000926326-23-000031:note_history:31]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of June 30, 2023 and December 31, 2022:

- changed (2023-11-03):
[0000926326-23-000041:note_history:32]
|  | September 30,2023 |  | December 31,2022 |
|  | (In thousands) |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized debt issuance costs | (6,113) |  |  | (8,429) |  |
| Convertible senior notes, net | $ | 568,887 |  |  | $ | 566,571 |  |
  (was, 2023-08-04, similarity 0.9189):
[0000926326-23-000031:note_history:32]
|  | June 30,2023 |  | December 31,2022 |
|  | (In thousands) |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized debt issuance costs | (6,886) |  |  | (8,429) |  |
| Convertible senior notes, net | $ | 568,114 |  |  | $ | 566,571 |  |

- changed (2023-11-03):
[0000926326-23-000041:note_history:33]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three and nine months ended September 30, 2023 and 2022:
  (was, 2023-08-04, similarity 0.9055):
[0000926326-23-000031:note_history:33]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three and six months ended June 30, 2023 and 2022:

- added (2023-11-03):
[0000926326-23-000041:note_history:34]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  | (In thousands) |
| Contractual coupon interest | $ | 359 |  |  | $ | 359 |  |  | $ | 1,078 |  |  | $ | 1,078 |  |
| Amortization of debt issuance costs | $ | 773 |  |  | $ | 768 |  |  | $ | 2,316 |  |  | $ | 2,298 |  |

- removed (2023-11-03):
[0000926326-23-000031:note_history:35]
Debt and Credit Agreement
2019 Revolving Credit Facility

- removed (2023-11-03):
[0000926326-23-000031:note_history:36]
On November 15, 2019, the Company entered into an Amended and Restated Credit Agreement (as subsequently amended as discussed below, the “A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo

- removed (2023-11-03):
[0000926326-23-000031:note_history:37]
Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers, and Wells Fargo Bank, National Association, as administrative agent. The A&R Credit Agreement superseded the Company’s 2016 secured credit facility and provides for (a) a five-year revolving credit facility of $500.0 million (the “Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million (the “Incremental Facility”). In addition, the A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The A&R Credit Agreement has an expiration date of November 15, 2024, upon which date all remaining outstanding borrowings will be due and payable.

- removed (2023-11-03):
[0000926326-23-000031:note_history:38]
On March 29, 2023, the parties entered into a second amendment to the A&R Credit Agreement to remove and replace the interest rate benchmark based on the London interbank offered rate (“LIBOR”) and related LIBOR-based mechanics applicable to borrowings under the A&R Credit Agreement with an interest rate benchmark based on the secured overnight financing rate (“SOFR”) as administered by the Federal Reserve Bank of New York (including a customary credit spread adjustment of 0.10% per annum) and related SOFR-based mechanics. The replacement of LIBOR did not, and the Company does not anticipate that it will, materially impact its liquidity or financial position.

- removed (2023-11-03):
[0000926326-23-000031:note_history:39]
As of June 30, 2023 and December 31, 2022, the Company had $417.7 million and $500.0 million of funds available under the Revolving Credit Facility, respectively. As of June 30, 2023 and December 31, 2022, the Company had no outstanding balance under the Revolving Credit Facility. 
Convertible Senior Notes
0.25% Convertible Senior Notes due 2025

- removed (2023-11-03):
[0000926326-23-000031:note_history:40]
During the three months ended June 30, 2023 and December 31, 2022, none of the conditional conversion features of the Notes were triggered, and therefore, the Notes are not convertible during the third quarter of 2023, commencing on July 1, 2023, and were not convertible during the first quarter of 2023, commencing on January 1, 2023, respectively. Accordingly, the Company classified the Notes as a long-term liability in its Condensed Consolidated Financial Statements as of both June 30, 2023 and December 31, 2022. Whether the Notes will be convertible following the third fiscal quarter of 2023 will depend on the satisfaction of the conversion conditions in the future.

- removed (2023-11-03):
[0000926326-23-000031:note_history:41]
redemption price equal to 100% of the principal amount of the Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. If the Company redeems less than all of the outstanding Notes, at least $150.0 million aggregate principal amount of Notes must be outstanding and not subject to redemption as of the date of the relevant notice of redemption. No sinking fund is provided for in the Notes.

- removed (2023-11-03):
[0000926326-23-000031:note_history:42]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  | (In thousands) |
| Contractual coupon interest | $ | 359 |  |  | $ | 359 |  |  | $ | 719 |  |  | $ | 719 |  |
| Amortization of debt issuance costs | $ | 772 |  |  | $ | 766 |  |  | $ | 1,543 |  |  | $ | 1,530 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-11-03):
[0000926326-23-000041:note_history:43]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”) and Federal agencies that purchase under a Federal Supply Schedule Contract with the Department of Veterans Affairs (the “GSA Contract”). GPOs are often fully or partially owned by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company also pays the Industrial Funding Fee (“IFF”) to the Department of Veterans Affairs under the GSA Contract. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs and the IFF were $3.6 million and $4.8 million for the three months ended September 30, 2023 and 2022, respectively, and $9.5 million and $13.3 million for the nine months ended September 30, 2023 and 2022, respectively.
  (was, 2023-08-04, similarity 0.9623):
[0000926326-23-000031:note_history:43]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”) and Federal agencies that purchase under a Federal Supply Schedule Contract with the Department of Veterans Affairs (the “GSA Contract”). GPOs are often fully or partially owned by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company also pays the Industrial Funding Fee (“IFF”) to the Department of Veterans Affairs under the GSA Contract. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs and the IFF were $2.8 million and $4.0 million for the three months ended June 30, 2023 and 2022, respectively, and $5.9 million and $8.5 million for the six months ended June 30, 2023 and 2022, respectively.

- changed (2023-11-03):
[0000926326-23-000041:note_history:44]
The following table summarizes the Company’s revenues disaggregated by revenue type for the three and nine months ended September 30, 2023 and 2022:
  (was, 2023-08-04, similarity 0.9416):
[0000926326-23-000031:note_history:44]
The following table summarizes the Company’s revenues disaggregated by revenue type for the three and six months ended June 30, 2023 and 2022:

- changed (2023-11-03):
[0000926326-23-000041:note_history:45]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  | (In thousands) |
| Connected devices, software licenses, and other | $ | 167,560 |  |  | $ | 226,415 |  |  | $ | 500,182 |  |  | $ | 650,125 |  |
| Consumables | 21,195 |  |  | 20,150 |  |  | 62,724 |  |  | 56,121 |  |
| Technical services | 57,303 |  |  | 53,914 |  |  | 167,851 |  |  | 156,386 |  |
| Advanced Services | 52,605 |  |  | 47,580 |  |  | 157,508 |  |  | 135,641 |  |
| Total revenues | $ | 298,663 |  |  | $ | 348,059 |  |  | $ | 888,265 |  |  | $ | 998,273 |  |
  (was, 2023-08-04, similarity 0.9142):
[0000926326-23-000031:note_history:45]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  | (In thousands) |
| Connected devices, software licenses, and other | $ | 167,475 |  |  | $ | 215,632 |  |  | $ | 332,622 |  |  | $ | 423,710 |  |
| Consumables | 20,961 |  |  | 18,174 |  |  | 41,529 |  |  | 35,971 |  |
| Technical services | 57,191 |  |  | 53,303 |  |  | 110,548 |  |  | 102,472 |  |
| Advanced Services | 53,346 |  |  | 44,277 |  |  | 104,903 |  |  | 88,061 |  |
| Total revenues | $ | 298,973 |  |  | $ | 331,386 |  |  | $ | 589,602 |  |  | $ | 650,214 |  |

- changed (2023-11-03):
[0000926326-23-000041:note_history:46]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location, for the three and nine months ended September 30, 2023 and 2022:
  (was, 2023-08-04, similarity 0.9581):
[0000926326-23-000031:note_history:46]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location, for the three and six months ended June 30, 2023 and 2022:

- changed (2023-11-03):
[0000926326-23-000041:note_history:47]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  | (In thousands) |
| United States | $ | 272,649 |  |  | $ | 315,755 |  |  | $ | 785,794 |  |  | $ | 898,269 |  |
| Rest of world (1) | 26,014 |  |  | 32,304 |  |  | 102,471 |  |  | 100,004 |  |
| Total revenues | $ | 298,663 |  |  | $ | 348,059 |  |  | $ | 888,265 |  |  | $ | 998,273 |  |
  (was, 2023-08-04, similarity 0.8752):
[0000926326-23-000031:note_history:47]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  | (In thousands) |
| United States | $ | 257,202 |  |  | $ | 294,937 |  |  | $ | 513,145 |  |  | $ | 582,514 |  |
| Rest of world (1) | 41,771 |  |  | 36,449 |  |  | 76,457 |  |  | 67,700 |  |
| Total revenues | $ | 298,973 |  |  | $ | 331,386 |  |  | $ | 589,602 |  |  | $ | 650,214 |  |

- changed (2023-11-03):
[0000926326-23-000041:note_history:48]
|  | September 30,2023 |  | December 31,2022 |
|  | (In thousands) |
| Short-term unbilled receivables, net (1) | $ | 20,275 |  |  | $ | 25,763 |  |
| Long-term unbilled receivables, net (2) | 13,159 |  |  | 14,744 |  |
| Total contract assets | $ | 33,434 |  |  | $ | 40,507 |  |
| Short-term deferred revenues, net | $ | 124,991 |  |  | $ | 118,947 |  |
| Long-term deferred revenues | 55,053 |  |  | 37,385 |  |
| Total contract liabilities | $ | 180,044 |  |  | $ | 156,332 |  |
  (was, 2023-08-04, similarity 0.983):
[0000926326-23-000031:note_history:48]
|  | June 30,2023 |  | December 31,2022 |
|  | (In thousands) |
| Short-term unbilled receivables, net (1) | $ | 22,111 |  |  | $ | 25,763 |  |
| Long-term unbilled receivables, net (2) | 15,132 |  |  | 14,744 |  |
| Total contract assets | $ | 37,243 |  |  | $ | 40,507 |  |
| Short-term deferred revenues, net | $ | 124,602 |  |  | $ | 118,947 |  |
| Long-term deferred revenues | 48,750 |  |  | 37,385 |  |
| Total contract liabilities | $ | 173,352 |  |  | $ | 156,332 |  |

- changed (2023-11-03):
[0000926326-23-000041:note_history:49]
Short-term deferred revenues of $125.0 million and $118.9 million include deferred revenues from product sales and service contracts, net of deferred cost of sales of $12.4 million and $15.8 million, as of September 30, 2023 and December 31, 2022, respectively. During the three and nine months ended September 30, 2023, the Company recognized revenues of $20.1 million and $106.2 million, respectively, that were included in the corresponding gross short-term deferred revenues balance of $134.7 million as of December 31, 2022. Long-term deferred revenues include deferred revenues from product sales and service contracts of $55.1 million and $37.4 million as of September 30, 2023 and December 31, 2022, respectively. Deferred revenues from product sales primarily relate to delivered and invoiced products, pending installation and acceptance. Deferred revenues from service contracts primarily relate to services that have been invoiced, where services have not yet been provided.
  (was, 2023-08-04, similarity 0.9537):
[0000926326-23-000031:note_history:49]
Short-term deferred revenues of $124.6 million and $118.9 million include deferred revenues from product sales and service contracts, net of deferred cost of sales of $13.6 million and $15.8 million, as of June 30, 2023 and December 31, 2022, respectively. During the three and six months ended June 30, 2023, the Company recognized revenues of $30.6 million and $86.1 million, respectively, that were included in the corresponding gross short-term deferred revenues balance of $134.7 million as of December 31, 2022. Long-term deferred revenues include deferred revenues from product sales and service contracts of $48.8 million and $37.4 million as of June 30, 2023 and December 31, 2022, respectively. Deferred revenues from product sales primarily relate to delivered and invoiced products, pending installation and acceptance. Deferred revenues from service contracts primarily relate to services that have been invoiced, where services have not yet been provided. Short-term

- added (2023-11-03):
[0000926326-23-000041:note_history:50]
Short-term deferred revenues are expected to be recognized within the next twelve months. Long-term deferred revenues substantially consist of deferred revenues on long-term service contracts which have been invoiced and are expected to be recognized as revenue beyond twelve months, generally not more than ten years. The Company generally invoices customers for products upon shipment. Invoicing associated with the service portion of agreements is generally periodic and is billed on a monthly, quarterly, or annual basis, and in certain circumstances, multiple years are billed at one time.

- changed (2023-11-03):
[0000926326-23-000041:note_history:51]
In addition, the Company has remaining performance obligations associated with contracts for which the associated products have been accepted or associated services have started, but where invoicing has not yet occurred and therefore are not reflected in deferred revenue. These remaining performance obligations are comprised of the non-variable portions of technical services and Advanced Services provided under non-cancellable contracts with minimum commitments. Remaining performance obligations which are not included in deferred revenues are $344.8 million as of September 30, 2023. Remaining performance obligations are expected to be recognized ratably over the remaining terms of the associated contracts, which terms vary but are generally not more than ten years. Remaining performance obligations do not include product obligations, services where the associated product has not been accepted, services which have not yet started, variable portions of services, and certain other obligations.
  (was, 2023-08-04, similarity 0.6973):
[0000926326-23-000031:note_history:51]
In addition, the Company has remaining performance obligations associated with contracts for which the associated products have been accepted or associated services have started, but where invoicing has not yet occurred and therefore are not reflected in deferred revenue. These remaining performance obligations are comprised of the non-variable portions of technical services and Advanced Services provided under non-cancellable contracts with minimum commitments. Remaining performance obligations which are not included in deferred revenues are $288.7 million as of June 30, 2023. Remaining performance obligations are expected to be recognized ratably over the remaining term of the contract, which is generally not more than ten years. Remaining performance obligations do not include product obligations, services where the associated product has not been accepted, services which have not yet started, variable portions of services, and certain other obligations.

- changed (2023-11-03):
[0000926326-23-000041:note_history:52]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three and nine months ended September 30, 2023 and 2022. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable balance as of September 30, 2023 and December 31, 2022.
  (was, 2023-08-04, similarity 0.8526):
[0000926326-23-000031:note_history:52]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three and six months ended June 30, 2023 and 2022. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable balance as of June 30, 2023 and December 31, 2022.

- removed (2023-11-03):
[0000926326-23-000031:note_history:53]
deferred revenues are expected to be recognized within the next twelve months. Long-term deferred revenues substantially consist of deferred revenues on long-term service contracts which have been invoiced and are expected to be recognized as revenue beyond twelve months, generally not more than ten years. The Company generally invoices customers for products upon shipment. Invoicing associated with the service portion of agreements is generally periodic and is billed on a monthly, quarterly, or annual basis, and in certain circumstances, multiple years are billed at one time.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2023-11-03):
[0000926326-23-000041:note_history:54]
Subsequent Events
Second Amended and Restated Credit Agreement

- added (2023-11-03):
[0000926326-23-000041:note_history:55]
On October 10, 2023, the Company entered into the Second A&R Credit Agreement with the lenders from time to time party thereto, Wells Fargo Securities, LLC, JPMorgan Chase Bank, N.A., PNC Capital Markets LLC and TD Securities (USA) LLC as joint lead arrangers and Wells Fargo Bank, National Association, as administrative agent. The Second A&R Credit Agreement supersedes the Company’s Prior A&R Credit Agreement. Refer to Note 9, Debt and Credit Agreement, for additional information.

- added (2023-11-03):
[0000926326-23-000041:note_history:56]
Restructuring Plan

- added (2023-11-03):
[0000926326-23-000041:note_history:57]
On November 2, 2023, the Company announced a plan to reduce the Company’s headcount and real estate footprint (the “2023 Plan”) as part of the Company’s expense containment initiatives and other actions to reduce discretionary spending being implemented due to challenging industry dynamics and macroeconomic conditions. In connection with the 2023 Plan, the Company estimates that it will incur approximately $12 million to $18 million of nonrecurring restructuring and related charges, consisting of (i) approximately $9 million to $12 million of cash-based charges related to the reduction in headcount, which primarily consist of employee severance and benefits costs and (ii) approximately $3 million to $6 million of non-cash charges related to office closure, which the Company expects to incur the majority of charges in the fourth quarter of 2023 with remaining charges incurred in future periods. The Company expects to substantially complete the 2023 Plan, including cash payments, by the end of the second quarter of 2024, subject to local laws and consultation requirements.
