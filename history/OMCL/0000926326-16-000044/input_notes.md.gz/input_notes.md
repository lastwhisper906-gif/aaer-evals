# OMCL notes — 0000926326-16-000044


## omcl:ScheduleofSharebasedCompensationFutureIssuanceofSharesTableTextBlock

[0000926326-16-000044:notes:1]
The Company had the following ordinary shares reserved for future issuance under its equity incentive plans as of December 31, 2015:

[0000926326-16-000044:notes:2]
|  |  | Number of Shares |
|  |  | (In thousands) |
| Share options outstanding |  | 2,688 |  |
| Non-vested restricted stock awards |  | 599 |  |
| Shares authorized for future issuance |  | 3,804 |  |
| ESPP shares available for future issuance |  | 3,251 |  |
| Total shares reserved for future issuance |  | 10,342 |  |


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0000926326-16-000044:notes:3]
As a result, actual results will differ from the unaudited pro forma information presented (in thousands, except per share data):

[0000926326-16-000044:notes:4]
|  | Twelve months ended December 31, |
|  | 2015 |  | 2014 |
|  | (In thousands, except per share data) |
| Pro forma net revenues | $ | 491,533 |  |  | $ | 468,147 |  |
| Pro forma net income | 31,397 |  |  | 32,356 |  |
| Pro forma net income per share basic | 0.88 |  |  | 0.91 |  |
| Pro forma net income per share diluted | 0.86 |  |  | 0.88 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000926326-16-000044:notes:5]
Business Combinations

[0000926326-16-000044:notes:6]
2015 Acquisition Activity

[0000926326-16-000044:notes:7]
Mach4 Acquisition

[0000926326-16-000044:notes:8]
On April 21, 2015, the Company completed its acquisition of Mach4, a privately held German limited liability company with its registered office in Bochum, Germany pursuant to a share purchase agreement (the “Mach4 Agreement”), under which Omnicell International, Inc., a wholly-owned subsidiary of Omnicell Inc., purchased the entire issued share capital of Mach4 (the “Mach4 Acquisition”).

[0000926326-16-000044:notes:9]
Mach4 manufactures robotic dispensing systems used by retail and hospital pharmacies and the Mach4 acquisition provides the Company with a more robust product offering that is intended to be leveraged to create opportunities to sell additional Omnicell medication cabinets. The robotic storage and dispensing product offering provides the Company with a solution to better compete for international market share.

[0000926326-16-000044:notes:10]
Pursuant to the terms of the Mach4 Agreement, the Company paid approximately $17.3 million in cash after adjustments provided for in the Mach4 Agreement, of which $2.7 million was placed in an escrow fund, which will be distributed to Mach4's former stockholders subject to claims that we may make against the escrow fund with respect to indemnification and other claims within 18 months after the closing date of this transaction.

[0000926326-16-000044:notes:11]
Avantec Acquisition

[0000926326-16-000044:notes:12]
On April 30, 2015, the Company completed the acquisition of Avantec, the privately-held distributor of the Company’s products in the United Kingdom, pursuant to a share purchase agreement (the “Avantec Agreement”). Pursuant to the Avantec Agreement, the Company acquired the remaining 85% of issued and outstanding ordinary shares of Avantec that was not previously owned by the Company. Avantec develops medication and supply automation products that complement the Company's solutions for configurations suited to the United Kingdom marketplace, and had been the exclusive distributor of the Company's medication and supply automation solutions since 2005 in the United Kingdom.

[0000926326-16-000044:notes:13]
Pursuant to the terms of the Avantec Agreement, the Company agreed to pay $12.0 million in cash (the “Purchase Consideration”) and potential earn-out payments of up to $3.0 million payable after December 31, 2015 and an additional $3.0 million payable after December 31, 2016, based on bookings targets. The fair value of these potential earn-out payments as of the acquisition date was $5.6 million. Pursuant to the terms of the Avantec Agreement, the Company retained $1.8 million of the Purchase Consideration to be held to settle any future indemnification claims within 18 months period that the Company may make following the closing.

[0000926326-16-000044:notes:14]
The fair value of the contingent consideration liability related to Avantec is revalued at each reporting date or more frequently if circumstances dictate. Changes in the fair value of this obligation are recorded as income or expense within other expense in the Company's Consolidated Statements of Operations. The significant unobservable inputs used in the fair value measurement of the contingent consideration are the achievement of booking targets and the discount rate. Significant increases or decreases in any of those inputs in isolation would result in a significantly lower or higher fair value measurement.

[0000926326-16-000044:notes:15]
Prior to the Avantec Acquisition, the Company accounted for its 15% ownership interest in Avantec as an equity-method investment. The Avantec acquisition date carrying book value of the Company's previous equity interest was $1.3 million. This transaction was accounted for as a step acquisition, which required the Company to re-measure its previously held 15% ownership interest to fair value and record the difference between the fair value and carrying value as a gain. The fair value of the equity investment was determined to be $4.7 million which resulted in a gain of $3.4 million.

[0000926326-16-000044:notes:16]
Both of the above acquired companies are included in the Company's Automation and Analytics segment.

[0000926326-16-000044:notes:17]
The Company accounted for the transactions above under the provisions of ASC 805. Accordingly, the estimated fair value of the consideration transferred to purchase the acquired companies is allocated to the assets acquired and the liabilities assumed based on their respective fair values. The Company has made significant estimates and assumptions in determining the allocation of the acquisition consideration.

[0000926326-16-000044:notes:18]
The purchase price allocations are subject to certain post-closing working capital adjustments for the acquired current assets and current liabilities of both acquisitions at their respective acquisition dates. The total consideration and the allocation of consideration to the individual net assets is preliminary, as there are remaining uncertainties to be resolved, including the settlement of the final net working capital adjustment for each.

[0000926326-16-000044:notes:19]
The Company's preliminary allocation of the total purchase price for each transaction is summarized below:

[0000926326-16-000044:notes:20]
|  | Mach4 |  | Avantec |  | Total |
|  | (In thousands) |
| Cash | $ | 397 |  |  | $ | 3,392 |  |  | $ | 3,789 |  |
| Accounts receivable | 3,743 |  |  | 3,607 |  |  | 7,350 |  |
| Inventory | 3,580 |  |  | 1,428 |  |  | 5,008 |  |
| Deferred tax assets and other current assets | 368 |  |  | 89 |  |  | 457 |  |
| Total current assets | 8,088 |  |  | 8,516 |  |  | 16,604 |  |
| Property and equipment | 463 |  |  | — |  |  | 463 |  |
| Intangibles | 7,710 |  |  | 6,341 |  |  | 14,051 |  |
| Goodwill | 10,591 |  |  | 15,606 |  |  | 26,197 |  |
| Other non-current assets | 52 |  |  | — |  |  | 52 |  |
| Total assets | 26,904 |  |  | 30,463 |  |  | 57,367 |  |
| Current liabilities | 3,684 |  |  | 4,125 |  |  | 7,809 |  |
| Non-current deferred tax liabilities | 2,564 |  |  | 1,269 |  |  | 3,833 |  |
| Deferred service revenue and gross profit | 2,314 |  |  | 928 |  |  | 3,242 |  |
| Other non-current liabilities | 1,056 |  |  | — |  |  | 1,056 |  |
| Total purchase price | 17,286 |  |  | 24,141 |  |  | 41,427 |  |
| Total purchase price, net of cash received | $ | 16,889 |  |  | $ | 20,749 |  |  | $ | 37,638 |  |

[0000926326-16-000044:notes:21]
Identifiable intangible assets

[0000926326-16-000044:notes:22]
Intangible assets acquired and their respective estimated remaining useful lives over which each asset will be amortized are as follows:

[0000926326-16-000044:notes:23]
|  | Mach4 |  | Avantec |
|  | Fair value |  | Weightedaverageuseful life |  | Fair value |  | Weightedaverageuseful life |
|  | (In thousands) |  | (In years) |  | (In thousands) |  | (In years) |
| Developed technology | $ | 3,290 |  |  | 8 |  | $ | — |  |  | — |
| Trade name | 850 |  |  | 6 |  | 92 |  |  | 2 |
| Customer relationships | 3,570 |  |  | 10 |  | 5,834 |  |  | 12 |
| Backlog | — |  |  | — |  | 415 |  |  | 2 |
| Total purchased intangible assets | $ | 7,710 |  |  |  |  | $ | 6,341 |  |  |  |

[0000926326-16-000044:notes:24]
Developed technology represents completed technology that has reached the technological feasibility and/or is currently offered for sale to Mach4 customers. The fair value is determined based on the relief from royalty method under the income approach, which requires the Company to estimate a reasonable royalty rate, identify relevant projected revenues and expenses, and select an appropriate discount rate. A royalty rate of 5% was used to value the developed technology. The after-tax cash flows were discounted to present value utilizing a 17.5% discount rate, which is based on the Company's company-wide required return for this acquisition plus a discount of 1.5% to account for the unique riskiness of the asset. The developed technology had a fair value of $3.3 million and had an estimated economic life of eight years based on estimated technological obsolescence and is being amortized on an accelerated basis.

[0000926326-16-000044:notes:25]
Trade name represents the fair value brand recognition that was determined using the relief-from-royalty method under the income approach. A royalty rate of 1% and 2% was used to value the trade names of Avantec and Mach4, respectively. The value of trade names of $0.1 million for Avantec is being amortized on straight-line method and $0.9 million for Mach4 is being amortized on an accelerated basis.

[0000926326-16-000044:notes:26]
Customer relationships represent the fair value of future projected revenues that will be derived from the sale of products to existing customers of the acquired company. The fair value of the customer relationships is determined based on the excess earnings method under the income approach that resulted in a value of $3.6 million for Mach4 and $5.8 million for Avantec and has been amortized over their useful lives on accelerated basis.

[0000926326-16-000044:notes:27]
Backlog represents the fair value of sales order backlog as of the valuation date and its fair value is determined based on the excess earnings method under the income approach and is being amortized on straight-line method.

[0000926326-16-000044:notes:28]
Goodwill

[0000926326-16-000044:notes:29]
The goodwill arising from these acquisitions is primarily attributed to sales of future products and services and the assembled workforce. Goodwill is not deductible for tax purposes. Goodwill is not being amortized but is reviewed annually for impairment or more frequently if impairment indicators arise, in accordance with authoritative guidance.

[0000926326-16-000044:notes:30]
Pro forma financial information

[0000926326-16-000044:notes:31]
The following table presents certain unaudited pro forma information for illustrative purposes only, for fiscal 2015 and fiscal 2014 as if Mach4 and Avantec had been acquired on January 1, 2014. The unaudited estimated pro forma information combines the historical results of Mach4 and Avantec with the Company's consolidated historical results and includes certain adjustments reflecting the estimated impact of fair value adjustments for the respective periods. The pro forma information is not indicative of what would have occurred had the acquisitions taken place on January 1, 2014. Additionally, the pro forma financial information does not include the impact of possible business model changes between Mach4, Avantec and the Company. The Company expects to achieve further business synergies, as a result of the acquisitions that are not reflected in the pro forma amounts that follow. As a result, actual results will differ from the unaudited pro forma information presented (in thousands, except per share data):

[0000926326-16-000044:notes:32]
Total revenues for Mach4 and Avantec recorded in fiscal year 2015 consolidated financial statements since the acquisition date were $11.2 million and $8.7 million, respectively. Total operating losses for Mach4 and Avantec recorded in fiscal year 2015 consolidated financial statements since the acquisition date were $2.2 million and $0.9 million, respectively.

[0000926326-16-000044:notes:33]
2014 Acquisition Activity

[0000926326-16-000044:notes:34]
On August 22, 2014, the Company completed its acquisition of Surgichem, a wholly-owned subsidiary of Bupa Care Homes (CFG) Plc ("Bupa"). In exchange for all of the voting equity interests of the acquired company, the Company paid a total purchase price of $20.7 million in cash, net of $0.2 million of cash acquired. This acquisition will assist U.K. healthcare professionals and caregivers seeking to improve patient outcomes, reduce medication errors and lower costs by effectively managing compliance to prescribed medication regimes in their mission to extend patient health and satisfaction through convenient, effective medication adherence solutions. Surgichem is being integrated with the Company’s existing U.K. business, MTS, a leading supplier of medication adherence packaging solutions.

[0000926326-16-000044:notes:35]
The following table presents the purchase price allocation included in the Company's Consolidated Balance Sheets:

[0000926326-16-000044:notes:36]
|  | (In thousands) |
| Cash | $ | 153 |  |
| Accounts receivable | 2,462 |  |
| Inventory | 2,190 |  |
| Deferred tax assets and other current assets | 361 |  |
| Total current assets | 5,166 |  |
| Property and equipment | 164 |  |
| Intangibles | 5,730 |  |
| Goodwill | 12,112 |  |
| Total assets | 23,172 |  |
| Current liabilities | 1,191 |  |
| Long-term deferred tax liabilities | 1,104 |  |
| Total purchase price | $ | 20,877 |  |

[0000926326-16-000044:notes:37]
Acquired intangible assets. The fair value of $5.4 million for acquired customer relationships was determined based on an income approach using the discounted cash flow method. The fair value of $0.3 million for the trade name was determined using the relief-from-royalty approach. Customer relationships are amortized over their estimated useful lives of 18 years and the trade name is amortized over its estimated useful life of approximately 1 year.

[0000926326-16-000044:notes:38]
Goodwill. The purchase price allocation resulted in goodwill of $12.1 million, which represents sales of future products and services and the assembled workforce of Surgichem. The Company believes the acquisition enhances its offerings and diversifies its revenue mix providing a more robust product and service solution to its current customers while expanding the Company’s international presence. The Company considered these factors as supporting the amount of goodwill recorded. The amortization of intangible assets and goodwill is not deductible for tax purposes.

[0000926326-16-000044:notes:39]
Surgichem generated revenue of $4.6 million and losses from operations of $0.1 million since the acquisition date for the year ended December 31, 2014. Surgichem revenue and losses from operations were $13.3 million (including $4.6 million mentioned above) and $11.9 million for the years ended December 31, 2014 and December 31, 2013, respectively. Results of operations for Surgichem have been included as a part of the Company's Medication Adherence segment, and supplemental pro forma results of operations for the prior periods have not been presented, as the effect of the acquisition was not material to the Company's consolidated financial results.


## us-gaap:CapitalLeasesInFinancialStatementsOfLessorDisclosureTextBlock

[0000926326-16-000044:notes:40]
Net Investment in Sales-Type Leases

[0000926326-16-000044:notes:41]
On recurring basis, the Company enters into sales-type lease transactions which vary in length from 1.0 year to 5.0 years. The receivables as a result of these types of transactions are collateralized by the underlying equipment leased and consist of the following components at December 31, 2015 and December 31, 2014:

[0000926326-16-000044:notes:42]
|  | December 31, 2015 |  | December 31, 2014 |
|  | (In thousands) |
| Net minimum lease payments to be received | $ | 22,255 |  |  | $ | 17,616 |  |
| Less: unearned interest income portion | (1,014 | ) |  | (1,131 | ) |
| Net investment in sales-type leases | 21,241 |  |  | 16,485 |  |
| Less: short-term portion(1) | (6,757 | ) |  | (5,637 | ) |
| Long-term net investment in sales-type leases | $ | 14,484 |  |  | $ | 10,848 |  |

[0000926326-16-000044:notes:43]
(1) The short-term portion of the net investments in sales-type leases are included in the other current assets on the Consolidated Balance Sheets.

[0000926326-16-000044:notes:44]
The Company evaluates its sales-type leases individually and collectively for impairment, and recorded allowance for credit losses of $0.2 million as of December 31, 2015 and December 31, 2014.

[0000926326-16-000044:notes:45]
At December 31, 2015, the future minimum lease payments to be received under sales-type leases are as follows:

[0000926326-16-000044:notes:46]
| Year ended December 31, | (In thousands) |
| 2016 | $ | 7,381 |  |
| 2017 | 6,252 |  |
| 2018 | 4,471 |  |
| 2019 | 2,500 |  |
| 2020 | 1,651 |  |
| Total | $ | 22,255 |  |


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0000926326-16-000044:notes:47]
Cash equivalents. The Company classifies investments as cash equivalents if their original or remaining contractual maturity is three months or less at the date of purchase. Cash equivalents are carried at amounts that approximate fair value due to the short period of time to maturity. The Company's cash equivalents are maintained in demand deposit accounts with financial institutions of high credit quality, and are invested in institutional money market funds, short-term bank time deposits and similar short duration instruments with fixed maturities. The Company continuously monitors the credit worthiness of the financial institutions and institutional money market funds in which it invests. The Company has not experienced any credit losses from its cash investments.


## us-gaap:CommissionsExpensePolicyPolicyTextBlock

[0000926326-16-000044:notes:48]
Commissions

[0000926326-16-000044:notes:49]
Sales commissions are incremental and directly related to customer sales contracts in which revenue is deferred. These commission costs are accrued and recorded in prepaid expenses upon execution of a non-cancelable customer contract and subsequently expensed in the period of revenue recognition.


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000926326-16-000044:notes:50]
Commitments and Contingencies

[0000926326-16-000044:notes:51]
Lease commitments

[0000926326-16-000044:notes:52]
The Company leases office space and office equipment  under operating leases. Commitments under operating leases primarily relate to leasehold property and office equipment. Rent expense was $7.0 million, $6.8 million and $6.9 million for the years ended December 31, 2015, December 31, 2014 and December 31, 2013, respectively.

[0000926326-16-000044:notes:53]
The minimum future payments on non-cancelable operating leases are as follows:

[0000926326-16-000044:notes:54]
| For the year ended December 31, | (In thousands) |
| 2016 | $ | 6,827 |  |
| 2017 | 6,015 |  |
| 2018 | 5,392 |  |
| 2019 | 5,250 |  |
| 2020 | 5,093 |  |
| Thereafter | 10,083 |  |
| Total minimum future lease payments | $ | 38,660 |  |

[0000926326-16-000044:notes:55]
Purchase obligations

[0000926326-16-000044:notes:56]
During the course of the business, we issue purchase orders based on our current manufacturing needs.    As of December 31, 2015, the Company had noncancelable purchase commitments of $28.3 million, which are expected to be paid within the next twelve months.

[0000926326-16-000044:notes:57]
Legal proceedings

[0000926326-16-000044:notes:58]
The Company is currently involved in various legal proceedings. As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any accrual for contingent liabilities associated with the legal proceedings described below based on its belief that any potential loss, while reasonably possible, is not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of this contingency or because of the diversion of management's attention and the creation of significant expenses.

[0000926326-16-000044:notes:59]
The  Company’s pending legal proceeding as of December 31, 2015 is as follows:

[0000926326-16-000044:notes:60]
On September 12, 2014, MV Circuit Design, Inc., an Ohio company ("MV Circuit"), brought an action to correct the inventorship of certain patents owned by the Company, as well as related state-law claims against the Company in the Northern District of Ohio (Case No. 1:14-cv-02028-DAP) regarding allegations of fraud in the filing and prosecution of U.S. Patent Nos. 8,180,485, 8,773,270, 8,812,153, PCT/US2007/003765, PCT/US2011/063597, and PCT/US2011/0635505 (the “Action”). On November 14, 2014, the Company filed a Motion to Dismiss the Action. MV Circuit responded on January 29, 2015, and the Company replied in support of its Motion to Dismiss on February 17, 2015. On March 24, 2015, the Court issued an Order granting in part and denying in part the Motion to Dismiss. Specifically, the Court granted the Company's Motion to Dismiss with respect to Counts 4, 5, and 6 (declaratory judgments regarding PCT/US2007/003765, PCT/US2011/063597, and PCT/US2011/0635505) and count 13 (civil conspiracy).  The Court denied the Company's Motion to Dismiss with respect to Count 9 (fraud), Count 7 (fraudulent concealment) and Count 8 (negligent misrepresentation). The Company filed an Answer to the Complaint on April 8, 2015.  Following an initial Case Management Conference on April 22, 2015, the Court ordered MV Circuit and the Company to make a limited initial production of documents.  The parties completed this initial document production and have held further conference calls with the Court to report on their settlement negotiations.  During a conference call held on February 11, 2016, the Court set a deadline of March 14, 2016 for the parties to either file notification of settlement or a proposed litigation schedule.

[0000926326-16-000044:notes:61]
Guarantees

[0000926326-16-000044:notes:62]
As permitted under Delaware law and the Company's certificate of incorporation and bylaws, the Company has agreed to indemnify its directors and officers against certain losses that they may suffer by reason of the fact that such persons are, were or become its directors or officers. The term of the indemnification period is for the director’s or officer’s lifetime and there is no limit on the potential amount of future payments that the Company could be required to make under these indemnification agreements. The Company has purchased a directors’ and officers’ liability insurance policy that may enable it to recover a portion of any future payments that it may be required to make under these indemnification agreements. Assuming the applicability of coverage and the willingness of the insurer to assume coverage and subject to certain retention, loss limits and other policy provisions, the Company believes it is unlikely that the Company will be required to pay any material amounts pursuant to these indemnification obligations. However, no assurances can be given that the insurers will not attempt to dispute the validity, applicability or amount of coverage without expensive and time-consuming litigation against the insurers.

[0000926326-16-000044:notes:63]
Additionally, the Company undertakes indemnification obligations in its ordinary course of business in connection with, among other things, the licensing of its products and the provision of its support services. In the ordinary course of the Company's business, the Company has in the past and may in the future agree to indemnify another party, generally its business affiliates or customers, against certain losses suffered or incurred by the indemnified party in connection with various types of claims, which may include, without limitation, claims of intellectual property infringement, certain tax liabilities, its gross negligence or intentional acts in the performance of support services and violations of laws. The term of these indemnification obligations is generally perpetual. In general, the Company attempts to limit the maximum potential amount of future payments that it may be required to make under these indemnification obligations to the amounts paid to it by a customer, but in some cases the obligation may not be so limited. In addition, the Company has in the past and may in the future warrant to its customers that its products will conform to functional specifications for a limited period of time following the date of installation (generally not exceeding 30 days) or that its software media is free from material defects. Sales contracts for certain of the Company's medication packaging systems often include limited warranties for up to six months, but the periodic activity and ending warranty balances the Company records have historically been immaterial.

[0000926326-16-000044:notes:64]
From time to time, the Company may also warrant that its professional services will be performed in a good and workmanlike manner or in a professional manner consistent with industry standards. The Company generally seeks to disclaim most warranties, including any implied or statutory warranties such as warranties of merchantability, fitness for a particular purpose, title, quality and non-infringement, as well as any liability with respect to incidental, consequential, special, exemplary, punitive or similar damages. In some states, such disclaimers may not be enforceable. If necessary, the Company would provide for the estimated cost of product and service warranties based on specific warranty claims and claim history. The Company has not been subject to any significant claims for such losses and have not incurred any material costs in defending or settling claims related to these indemnification obligations. Accordingly, the Company believes it is unlikely that the Company will be required to pay any material amounts pursuant to these indemnification obligations or potential warranty claims and, therefore, no material liabilities have been recorded for such indemnification obligations as of December 31, 2015 and December 31, 2014.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000926326-16-000044:notes:65]
Employee Benefits and Share-Based Compensation

[0000926326-16-000044:notes:66]
Stock purchase plan

[0000926326-16-000044:notes:67]
1997 Employee Stock Purchase Plan

[0000926326-16-000044:notes:68]
The Company has an Employee Stock Purchase Plan ("ESPP"), under which employees can purchase shares of its common stock based on a percentage of their compensation, but not greater than 15% of their earnings; provided, however, an eligible employee's right to purchase shares of the Company's common stock may not accrue at a rate which exceeds $25,000 of the fair market value of such shares for each calendar year in which such rights are outstanding. The purchase price per share must be equal to the lower of 85% of the fair value of the common stock at the beginning of a 24-month offering period or the end of each six-month purchasing period.

[0000926326-16-000044:notes:69]
At the Company's 2009 Annual Meeting of Stockholders (the "2009 Annual Meeting"), its stockholders approved an amendment to the ESPP, which added 2.6 million shares to the reserve for future issuance. At the Company's 2015 Annual Meeting of Stockholders (the "2015 Annual Meeting"), its stockholders approved an amendment to the ESPP, which added and additional 3.0 million shares to the reserve for future issuance. There was a total of 3.3 million shares reserved for future issuance under the ESPP as of December 31, 2015.

[0000926326-16-000044:notes:70]
For the year ended December 31, 2015, employees purchased 0.4 million shares of common stock under the ESPP and an aggregate of 5.1 million shares were issued under the ESPP as of December 31, 2015.

[0000926326-16-000044:notes:71]
Stock award plans

[0000926326-16-000044:notes:72]
2009 Equity Incentive Plan

[0000926326-16-000044:notes:73]
On May 19, 2009, at the Company's 2009 Annual Meeting, the stockholders approved the Omnicell, Inc. 2009 Equity Incentive Plan, and as subsequently amended, (the "2009 Plan"). The 2009 Plan provides for the issuance of incentive stock options, non-statutory stock options, stock appreciation rights, restricted stock awards, restricted stock unit awards, performance stock awards, performance cash awards and other stock awards to the Company's employees, directors and consultants. The 2009 Plan succeeded the 1999 Equity Incentive Plan, the 2003 Equity Incentive Plan and the 2004 Equity Incentive Plan (collectively, the "Prior Plans"). No additional awards will be granted under any of the Prior Plans; however, all outstanding stock awards granted under the Prior Plans continue to be subject to the terms and conditions as set forth in the agreements evidencing such stock awards.

[0000926326-16-000044:notes:74]
On December 16, 2010, at a Special Meeting of Stockholders, the Company's stockholders approved an amendment to increase the number of shares of common stock authorized for issuance under the 2009 Plan by 2.6 million shares and to provide that the number of common stock shares available for issuance under the 2009 Plan be reduced by 1.8 shares for each share granted as a full-value award granted on and after October 1, 2010. For each share granted as a full-value award granted prior to October 1, 2010, future shares available for grants under the 2009 Plan were reduced by 1.4 shares. Awards granted as stock options and stock appreciation rights continue to reduce the number of shares available for issuance under the 2009 Plan on a one-for-one basis. At the Company's 2013 Annual Meeting of Stockholders, the Company's stockholders approved an amendment to the 2009 Plan to increase the number of shares of common stock authorized for issuance by 2.5 million shares. At the 2015 Annual Meeting, the Company's stockholders approved an amendment to the 2009 Plan to increase the number of shares of common stock authorized for issuance by 3.2 million shares and to provide that number of common stock shares available for issuance under the 2009 Plan be reduced by 2.15 shares for each share granted as a full value award on or after December 31, 2014. In addition, at the 2015 Annual Meeting, the Company's stockholders approved amendments to the 2009 Plan Stock providing that: (i) awards granted under the 2009 Plan will be subject to recoupment in accordance with any clawback policy that the Company may be required to adopt pursuant to applicable law and listing requirements and (ii) that the 2009 Plan will not expire by its terms but that no incentive stock options may be granted after the ten year anniversary of the earlier of the date that the 2009 Plan was adopted by the Company's Board of Directors or the date that the 2009 Plan was approved by its stockholders. There were 3.8 million shares of common stock reserved for future issuance under the 2009 Plan as of December 31, 2015.

[0000926326-16-000044:notes:75]
Options granted under the 2009 Plan become exercisable over periods of up to four years, with one-fourth of the shares vesting one year from the vesting commencement date with respect to initial grants, and the remaining shares vesting in 36 equal monthly installments thereafter. The Company also grants both restricted stock and restricted stock units to participants under the 2009 Plan. Awards of restricted stock to non-employee directors are granted on the date of the annual meeting of stockholders and vest in full on the date of the next annual meeting of stockholders, provided such non-employee director remains a director on such date. The fair value of the award on the date of issuance is amortized to expense from the date of grant to the date of vesting. RSUs granted to employees vest over a period of four years and are expensed ratably on a straight-line basis over the vesting period.

[0000926326-16-000044:notes:76]
Performance-based Restricted Stock Units

[0000926326-16-000044:notes:77]
In 2011, the Company began incorporating performance-based restricted stock units ("PSUs") as an element of its executive compensation plans. In 2012, the Company granted 125,000 PSUs to its executive officers, of which 62,500 PSUs became eligible for vesting upon the achievement of a certain level of shareholder return for 2012. In 2013, the Company granted 137,500 PSUs to its executive officers all of which became eligible for vesting upon the achievement of a certain level of shareholder return for the period from January 1, 2013 through February 28, 2014. In 2014, the Company granted 132,500 PSUs to its executive officers, all, none or a portion of which may become eligible for vesting depending on the level of shareholder return for 2014 and eligible for further time-based vesting based on the ranking of the Company's total shareholder return for the period from March 1, 2014 through March 1, 2015. In 2015, the Company granted 60,000 PSUs to its executive officers, all, none or a portion of which may become eligible for vesting depending on the level of shareholder return  for the period from March 2, 2015 through March 1, 2016 and eligible for further time-based vesting based on the ranking of the Company's total shareholder return.

[0000926326-16-000044:notes:78]
The fair value of a PSU award is determined using a Monte Carlo simulation model. The number of shares that vest at the end of the performance period depends on the percentile ranking of the total shareholder return for Omnicell stock over the performance period relative to the total shareholder return of each of the other companies in the NASDAQ Healthcare Index (the "Index").

[0000926326-16-000044:notes:79]
Vesting for the PSUs is based both on the percentile placement of the Company's total stockholder return among the companies listed in the NASDAQ Health Care Index and time-based vesting. The Company calculates total stockholder return based on the one year annualized rates of return reflecting price appreciation plus reinvestment of dividends. For PSUs granted on February 6, 2015, stock price appreciation is calculated based on the trailing 20-day average stock price just prior the first trading day of March 2015, compared to the trailing 20-day average stock price just prior the first trading day of March 2016. For PSUs granted on February 4, 2014, stock price appreciation is calculated based on the trailing 20-day average stock price just prior to the first trading day of March 2014, compared to the trailing 20-day average stock price just prior to the first trading day of March 2015.

[0000926326-16-000044:notes:80]
On March 20, 2014, the Compensation Committee confirmed 63.9% as the percentile rank of the Company's 2013 total stockholder return. This resulted in 100% of the 2013 PSUs, or 137,500 shares, as eligible for further time-based vesting. The eligible performance based restricted stock unit awards will vest as follows: 25% of the eligible shares vested immediately on March 20, 2014 with the remaining eligible awards vesting in equal increments, semi-annually, over the subsequent three-year period beginning on June 15th and December 15th of the year after the date of grant and each subsequent year. Vesting is contingent upon continued service. Of the 137,500 shares eligible for time-based vesting under the 2013 PSUs, 68,750 and 34,375 shares vested during the year ended December 31, 2014 and December 31, 2015, respectively.

[0000926326-16-000044:notes:81]
On March 3, 2015, the Compensation Committee confirmed 74.4% as the percentile rank of the Company's 2014 total stockholder return. This resulted in 100% of the 2014 PSUs, or 132,500 shares, as eligible for further time-based vesting. The eligible performance based restricted stock unit awards will vest as follows: 25% of the eligible shares vested immediately on March 3, 2015 with the remaining eligible awards vesting in equal increments, semi-annually, over the subsequent three-year period beginning on June 15th and December 15th of the year after the date of grant and each subsequent year. Vesting is contingent upon continued service. Of the 132,500 shares eligible for time-based vesting under the 2014 PSUs, 66,250 shares vested during the year ended December 31, 2015.

[0000926326-16-000044:notes:82]
Valuation of share-based awards

[0000926326-16-000044:notes:83]
The following assumptions were used to value share options and ESPP shares granted pursuant to our equity incentive plans:

[0000926326-16-000044:notes:84]
|  | Year Ended |
|  | December 31, 2015 |  | December 31, 2014 |  | December 31, 2013 |
| Stock Option Plans |  |  |  |  |  |
| Risk-free interest rate | 1.7 | % |  | 1.6 | % |  | 1.2 | % |
| Dividend yield | — | % |  | — | % |  | — | % |
| Expected volatility | 32.0 | % |  | 34.9 | % |  | 43.1 | % |
| Expected life (in years) | 5.04 |  |  | 4.8 |  |  | 5.3 |  |

[0000926326-16-000044:notes:85]
|  | Year Ended |
|  | December 31, 2015 |  | December 31, 2014 |  | December 31, 2013 |
| Employee Stock Purchase Plan |  |  |  |  |  |
| Risk-free interest rate | 0.03% - 0.79% |  |  | 0.03% - 0.53% |  |  | 0.03% - 0.85% |  |
| Dividend yield | — | % |  | — | % |  | — | % |
| Expected volatility | 25.7% - 37.5% |  |  | 29.5% - 42.1% |  |  | 29.5% - 44.8% |  |
| Expected life (in years) | 0.5 - 2.0 |  |  | 0.5 - 2.0 |  |  | 0.5 - 2.0 |  |

[0000926326-16-000044:notes:86]
Share-based compensation expense

[0000926326-16-000044:notes:87]
The Company accounts for share-based awards granted to employees and directors, including employee stock option awards, restricted stock, PSUs and RSUs issued pursuant to the 2009 Plan and employee stock purchases made under its ESPP using the estimate grant date fair value method of accounting in accordance with ASC 718, Stock Compensation. The Company values options and ESPP shares using the Black-Scholes-Merton option-pricing model. Restricted stock and time-based RSUs are valued at the grant date fair value of the underlying common shares. The PSUs are valued using the Monte Carlo simulation model.

[0000926326-16-000044:notes:88]
The following table sets forth the total share-based compensation expense recognized in the Company's Consolidated Statements of Income:

[0000926326-16-000044:notes:89]
|  | Year Ended |
|  | December 31, 2015 |  | December 31, 2014 |  | December 31, 2013 |
|  | (In thousands) |
| Cost of product and service revenues | $ | 2,111 |  |  | $ | 1,456 |  |  | $ | 1,241 |  |
| Research and development | 2,060 |  |  | 1,655 |  |  | 1,359 |  |
| Selling, general and administrative | 10,750 |  |  | 9,674 |  |  | 8,551 |  |
| Total share-based compensation expense | $ | 14,921 |  |  | $ | 12,785 |  |  | $ | 11,151 |  |

[0000926326-16-000044:notes:90]
The Company did not capitalize any share-based compensation as inventory as such amounts were not material for the years ended December 31, 2015, December 31, 2014 and December 31, 2013. Income tax benefits realized from share-based compensation were $5.0 million, $4.5 million and $2.4 million, for the years ended December 31, 2015, December 31, 2014 and December 31, 2013, respectively.

[0000926326-16-000044:notes:91]
Stock options activity

[0000926326-16-000044:notes:92]
A summary of the stock option activity under the 2009 Plan is presented below:

[0000926326-16-000044:notes:93]
|  | Number ofShares |  | Weighted-AverageExercise Price |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2014 | 2,672 |  |  | $ | 19.02 |  |  | 6.5 |  |  |
| Granted (Awarded) | 728 |  |  | 31.21 |  |  |  |  |  |
| Exercised (Released) | (598 | ) |  | 15.51 |  |  |  |  |  |
| Expired | (5 | ) |  | 16.71 |  |  |  |  |  |
| Forfeited | (109 | ) |  | 24.24 |  |  |  |  |  |
| Outstanding at December 31, 2015 | 2,688 |  |  | 22.89 |  |  | 6.9 |  | $ | 23,418 |  |
| Exercisable at December 31, 2015 | 1,399 |  |  | 17.74 |  |  | 5.1 |  | 18,716 |  |
| Vested and expected to vest at December 31, 2015 and thereafter | 2,648 |  |  | 22.78 |  |  | 6.9 |  | $ | 23,332 |  |

[0000926326-16-000044:notes:94]
The weighted-average fair value per share of options granted during 2015, 2014 and 2013 was $9.67, $9.12 and $8.09, respectively. The intrinsic value of options exercised during 2015, 2014 and 2013 was $11.3 million, $14.1 million and $14.0 million, respectively.

[0000926326-16-000044:notes:95]
As of December 31, 2015, total unrecognized compensation cost related to unvested stock options was $11.2 million, which is expected to be recognized over a weighted-average vesting period of 2.9 years.  As of December 31, 2014, total unrecognized compensation cost related to unvested stock options was $8.8 million, which is expected to be recognized over a weighted-average vesting period of 2.8 years.

[0000926326-16-000044:notes:96]
Restricted stock activity

[0000926326-16-000044:notes:97]
Summaries of the restricted stock activity under the 2009 Plan are presented below:

[0000926326-16-000044:notes:98]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Restricted Stock Units |  |  |  |  |  |  |  |
| Non-vested at December 31, 2014 | 399 |  |  | $ | 24.00 |  |  | 1.5 |  |  |
| Granted (Awarded) | 256 |  |  | 31.44 |  |  |  |  |  |
| Vested (Released) | (196 | ) |  | 23.99 |  |  |  |  |  |
| Forfeited | (42 | ) |  | 24.65 |  |  |  |  |  |
| Non-vested at December 31, 2015 | 417 |  |  | 28.49 |  |  | 1.6 |  | $ | 12,948 |  |

[0000926326-16-000044:notes:99]
The weighted-average grant date fair value per share of Restricted Stock Units ("RSUs") granted during 2015, 2014 and 2013 was $31.44, $28.88 and $19.87, respectively. The total fair value of RSUs that vested in 2015, 2014 and 2013 was $4.7 million, $3.2 million and $4.4 million, respectively.

[0000926326-16-000044:notes:100]
As of December 31, 2015, total unrecognized compensation cost related to RSUs was $11.2 million, which is expected to be recognized over the remaining weighted-average vesting period of 2.9 years. As of December 31, 2014, total unrecognized compensation cost related to RSUs was $8.7 million, which is expected to be recognized over the remaining weighted-average vesting period of  2.6 years.

[0000926326-16-000044:notes:101]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |
|  | (In thousands, except per share data) |
| Restricted Stock Awards |  |  |  |
| Non-vested at December 31, 2014 | 36 |  |  | $ | 26.47 |  |
| Granted (Awarded) | 36 |  |  | 36.05 |  |
| Vested (Released) | (41 | ) |  | 26.48 |  |
| Forfeited | — |  |  | — |  |
| Non-vested at December 31, 2015 | 31 |  |  | $ | 35.97 |  |

[0000926326-16-000044:notes:102]
The weighted-average grant date fair value per share of Restricted Stock Awards ("RSAs") granted during 2015, 2014 and 2013 was $36.05, $26.42 and $18.20, respectively. The total fair value of RSAs that vested in 2015, 2014 and 2013 was $1.1 million, $1.0 million and $1.1 million, respectively.

[0000926326-16-000044:notes:103]
As of December 31, 2015, total unrecognized compensation cost related to RSAs was $0.4 million, which is expected to be recognized over the remaining weighted-average vesting period of 0.4 years. As of December 31, 2014, total unrecognized compensation cost related to RSAs was $0.4 million, which is expected to be recognized over the remaining weighted-average vesting period of 0.5 years.

[0000926326-16-000044:notes:104]
Performance-based restricted stock units activity

[0000926326-16-000044:notes:105]
A summary of the performance-based restricted stock activity under the 2009 Plan is presented below:

[0000926326-16-000044:notes:106]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value Per Unit |
|  | (In thousands, except per share data) |
| Unvested at December 31, 2014 | 233 |  |  | $ | 17.96 |  |
| Granted (Awarded) | 60 |  |  | 29.56 |  |
| Vested (Released) | (107 | ) |  | 18.20 |  |
| Forfeited | (35 | ) |  | 14.08 |  |
| Unvested at December 31, 2015 | 151 |  |  | $ | 23.33 |  |

[0000926326-16-000044:notes:107]
The weighted-average grant date fair value per share of PSUs granted during 2015, 2014 and 2013 was $29.56, $20.94 and $14.68, respectively. The total fair value of PSUs that vested in 2015, 2014 and 2013 was $1.9 million, $1.5 million and $0.7 million, respectively.

[0000926326-16-000044:notes:108]
As of December 31, 2015, total unrecognized compensation cost related to PSUs was approximately $1.5 million, which is expected to be recognized over the remaining weighted-average period of 1.2 years. As of December 31, 2014, total unrecognized compensation cost related to PSUs was approximately $2.0 million, which is expected to be recognized over the remaining weighted-average period of 1.2 years.

[0000926326-16-000044:notes:109]
Employee Stock Purchase Plan

[0000926326-16-000044:notes:110]
The unrecognized compensation cost related to the shares to be purchased under the ESPP was approximately $1.4 million, and is expected to be recognized over a weighted-average period of 0.6 years as of December 31, 2015.

[0000926326-16-000044:notes:111]
Summary of Shares Reserved for Future Issuance Under Equity Incentive Plans

[0000926326-16-000044:notes:112]
401(k) Plan

[0000926326-16-000044:notes:113]
The Company has established a pre-tax savings plan under Section 401(k) of the Internal Revenue Code. The 401(k) Plan allows eligible employees in the United States to voluntarily contribute a portion of their pre-tax salary, subject to a maximum limit specified in the Internal Revenue Code. The Company matches 50% of employee contributions up to $2,000, annually.  The Company's contributions under this plan were $1.8 million, $1.3 million and $1.1 million in 2015, 2014 and 2013, respectively.


## us-gaap:ConsolidationPolicyTextBlock

[0000926326-16-000044:notes:114]
Principles of consolidation

[0000926326-16-000044:notes:115]
The accompanying Consolidated Financial Statements have been prepared in accordance with U.S. GAAP and include all adjustments necessary for the fair presentation of the Company's consolidated financial position, results of operations and cash flows for the periods presented. The Consolidated Financial Statements include the Company's accounts as well as those of its wholly owned subsidiaries after the elimination of intercompany balances and transactions.


## us-gaap:DebtDisclosureTextBlock

[0000926326-16-000044:notes:116]
Credit Agreement

[0000926326-16-000044:notes:117]
In September 2013, the Company entered into a credit agreement (the "Credit Agreement") with Wells Fargo Bank, National Association, as administrative agent, and the lenders from time to time party thereto. The Credit Agreement provides for a $75 million revolving credit facility with a $10 million letter of credit sub-limit. Loans under the Credit Agreement mature on September 25, 2018. The Credit Agreement permits the Company to request one or more increases in the aggregate commitments provided that such increases do not exceed $25 million in the aggregate. The Company expects to use the proceeds from any revolving loans under the credit facility for general corporate purposes, including future acquisitions. The Company's obligations under the Credit Agreement are guaranteed by certain of its domestic subsidiaries and secured by substantially all of the Company's and the subsidiary guarantors’ assets. The Company had not drawn any funds under the credit facility to date.

[0000926326-16-000044:notes:118]
Amounts drawn under the Credit Agreement bear interest, at the Company's election, at a Eurodollar rate plus a margin of 1.75% per annum, or an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) LIBOR for an interest period of one month plus 1.75%. The Company is required to pay a commitment fee of 0.25% per annum on the aggregate undrawn amount of the commitments under the credit facility.

[0000926326-16-000044:notes:119]
On November 5, 2014, the Company entered into Amendment Number One (“Amendment”) to the Credit Agreement. The Amendment increases the amount of the Company's common stock that may be repurchased by the Company in open market transactions authorized by its Board of Directors, together with any repurchases of its common stock from any consultants, employees, officers or directors of the Company or any of its subsidiaries following the death, disability, retirement or termination of employment of such employees, officers or directors, from $25 million to $50 million  per year.

[0000926326-16-000044:notes:120]
The Credit Agreement, as amended, contains customary affirmative and negative covenants, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends and other distributions. The Credit Agreement, as amended, contains financial covenants that require the Company to, among other things, maintain a maximum consolidated total leverage ratio and a minimum consolidated fixed charge coverage ratio, in each case, as of the last day of each quarter. The Company was in full compliance with all covenants as of December 31, 2015. On January 5, 2016, this Credit Agreement was replaced by the below.

[0000926326-16-000044:notes:121]
On January 5, 2016, we entered into a $400 million secured credit facility pursuant to a credit agreement, by and among us, the lenders from time to time party thereto, Wells Fargo Securities, LLC, as sole lead arranger and Wells Fargo Bank, National Association, as administrative agent (the “Credit Agreement”). See Note 14, Subsequent Events, for additional discussion.


## us-gaap:DebtPolicyTextBlock

[0000926326-16-000044:notes:122]
Debt. The Company has a Credit Agreement, dated as of September 25, 2013 comprised of a $75 million revolving credit facility. Borrowings under the Company's revolving credit facility would be recognized at cost plus accrued interest based upon stated interest rates. The Company had not drawn any funds under the credit facility as of December 31, 2015.


## us-gaap:DerivativesPolicyTextBlock

[0000926326-16-000044:notes:123]
Foreign currency forward contracts. The Company enters into foreign currency forward contracts to protect its business from the risk that exchange rates may affect the eventual cash flows resulting from intercompany transactions between Omnicell and its foreign subsidiaries. These transactions primarily arise as a result of products manufactured in the United States ("U.S") and sold to foreign subsidiaries in U.S. dollars rather than the subsidiaries' functional currencies. These forward contracts are considered to be financial derivative instruments and are recorded at fair value. Changes in fair values of these financial derivative instruments are either recognized in other comprehensive income or net income depending on whether the derivative has been designated and qualifies as a hedging instrument.


## us-gaap:EarningsPerShareTextBlock

[0000926326-16-000044:notes:124]
Net Income Per Share

[0000926326-16-000044:notes:125]
Basic net income per share is computed by dividing net income for the period by the weighted-average number of shares outstanding during the period. Diluted net income per share is computed by dividing net income for the period by the weighted-average number of shares, less shares repurchased, plus, if dilutive, potential common stock outstanding during the period. Potential common stock includes the effect of outstanding dilutive stock options, restricted stock awards and restricted stock units computed using the treasury stock method. The anti-dilutive weighted-average dilutive shares related to stock award plans are excluded from the computation of the diluted net income per share because their effect would have been anti-dilutive.

[0000926326-16-000044:notes:126]
The calculation of basic and diluted net income per share is as follows:

[0000926326-16-000044:notes:127]
|  | Year Ended |
|  | December 31, 2015 |  | December 31, 2014 |  | December 31, 2013 |
|  | (In thousands, except per share data) |
| Net income | $ | 30,760 |  |  | $ | 30,518 |  |  | $ | 23,979 |  |
| Weighted-average shares outstanding — basic | 35,857 |  |  | 35,650 |  |  | 34,736 |  |
| Add: Dilutive effect of employee stock plans | 861 |  |  | 972 |  |  | 1,041 |  |
| Weighted-average shares outstanding — diluted | 36,718 |  |  | 36,622 |  |  | 35,777 |  |
| Net income per share — basic | $ | 0.86 |  |  | $ | 0.86 |  |  | $ | 0.69 |  |
| Net income per share — diluted | $ | 0.84 |  |  | $ | 0.83 |  |  | $ | 0.67 |  |
| Anti-dilutive weighted-average shares related to stock award plans | 555 |  |  | 640 |  |  | 850 |  |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0000926326-16-000044:notes:128]
The following table represents the fair value hierarchy of the Company’s financial assets measured at fair value as of December 31, 2015:

[0000926326-16-000044:notes:129]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Money market funds | $ | 10,114 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,114 |  |
| Forward contracts | — |  |  | 32 |  |  | — |  |  | 32 |  |
| Total financial assets | $ | 10,114 |  |  | $ | 32 |  |  | $ | — |  |  | $ | 10,146 |  |
| Contingent consideration liability | $ | — |  |  | $ | — |  |  | $ | 5,823 |  |  | $ | 5,823 |  |
| Total financial Liabilities | $ | — |  |  | $ | — |  |  | $ | 5,823 |  |  | $ | 5,823 |  |

[0000926326-16-000044:notes:130]
The following table represents the fair value hierarchy of the Company’s financial asset measured at fair value as of December 31, 2014:

[0000926326-16-000044:notes:131]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Money market funds | $ | 64,577 |  |  | $ | — |  |  | $ | — |  |  | $ | 64,577 |  |
| Total financial assets | $ | 64,577 |  |  | $ | — |  |  | $ | — |  |  | $ | 64,577 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0000926326-16-000044:notes:132]
Cash and cash equivalents at December 31, 2015 and December 31, 2014 were as follows:

[0000926326-16-000044:notes:133]
|  | December 31, 2015 |  | December 31, 2014 |
|  | (In thousands) |
| Cash | $ | 72,103 |  |  | $ | 61,311 |  |
| Cash equivalents | 10,114 |  |  | 64,577 |  |
| Total cash and cash equivalents | $ | 82,217 |  |  | $ | 125,888 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000926326-16-000044:notes:134]
Cash and Cash Equivalents and Fair Value of Financial Instruments

[0000926326-16-000044:notes:135]
Cash and cash equivalents as of December 31, 2015 and December 31, 2014 includes money market funds, which have original maturities of three months or less.  Due to the short duration to maturity, the carrying value of such financial instruments approximates the estimated fair value.

[0000926326-16-000044:notes:136]
Fair value hierarchy

[0000926326-16-000044:notes:137]
The Company measures its financial instruments at fair value. The Company’s cash equivalents are classified within Level 1 of the fair value hierarchy as they are valued primarily using quoted market prices utilizing market observable inputs. The Company's foreign currency contracts are classified within Level 2 as the valuation inputs are based on quoted prices and market observable data of similar instruments. The Level 3 valuation inputs include the Company’s best estimate of what market participants would use in pricing the asset or liability at the measurement date. The inputs are unobservable in the market and significant to the instrument’s valuation.

[0000926326-16-000044:notes:138]
The significant unobservable inputs used in the fair value measurement of the contingent consideration classified as level 3 above are the achievement of booking targets and the discount rate. There have been no transfers between fair value measurement levels during the year ended December 31, 2015 and December 31, 2014.

[0000926326-16-000044:notes:139]
Net investment in sales-type leases. The carrying amount of the Company's sales-type lease receivables is a reasonable estimate of fair value as the unearned interest income is immaterial.

[0000926326-16-000044:notes:140]
Foreign Currency Risk Management

[0000926326-16-000044:notes:141]
The Company operates in foreign countries, which expose it to market risk associated with foreign currency exchange rate fluctuations between the U.S. dollar and various foreign currencies, the most significant of which is the British Pound and Euro. In order to manage foreign currency risk, the Company enters into foreign exchange forward contracts to mitigate risks associated with changes in spot exchange rates of mainly non-functional currency denominated assets or liabilities of our foreign subsidiaries.  In general, the market risk related to these contracts is offset by corresponding gains and losses on the hedged transactions. By working only with major banks and closely monitoring current market conditions, the Company seeks to limit the risk that counterparties to these contracts may be unable to perform. The foreign exchange forward contracts are measured at fair value and reported as other current assets or accrued liabilities on the Consolidated Balance Sheets. The derivative instruments the Company uses to hedge this exposure are not designated as hedges. Any gains or losses on the foreign exchange forward contracts are recognized in earnings as Other Income/Expense in the period incurred in the Consolidated Statements of Operations. The Company does not enter into derivative contracts for trading purposes.

[0000926326-16-000044:notes:142]
The aggregate notional amounts of the Company's outstanding foreign exchange contracts as of December 31, 2015 were $0.4 million. The aggregate fair value of these outstanding foreign exchange contracts as of December 31, 2015 were less than $0.1 million. The Company did not have any outstanding foreign exchange contracts as of December 31, 2014.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0000926326-16-000044:notes:143]
Foreign currency translation

[0000926326-16-000044:notes:144]
The Company translates the assets and liabilities of its non-U.S. dollar functional currency subsidiaries into U.S. dollars using exchange rates in effect at the end of each period. Revenue and expenses for these subsidiaries are translated using rates that approximate those in effect during the period. Gains and losses from these translations are recorded as foreign currency translation adjustments and included in accumulated other comprehensive income in stockholders’ equity.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000926326-16-000044:notes:145]
Goodwill and Intangible Assets

[0000926326-16-000044:notes:146]
The changes in the carrying amount of goodwill are as follows:

[0000926326-16-000044:notes:147]
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |
|  | (In thousands) |
| Net balance as of December 31, 2013 | $ | 28,543 |  |  | $ | 82,800 |  |  | $ | 111,343 |  |
| Additions (1) | — |  |  | 12,112 |  |  | 12,112 |  |
| Adjustments (2) | — |  |  | (735 | ) |  | (735 | ) |
| Net balance as of December 31, 2014 | 28,543 |  |  | 94,177 |  |  | 122,720 |  |
| Additions (3) | 26,197 |  |  | — |  |  | 26,197 |  |
| Adjustments (2) | (424 | ) |  | (587 | ) |  | (1,011 | ) |
| Net balance as of December 31, 2015 | $ | 54,316 |  |  | $ | 93,590 |  |  | $ | 147,906 |  |

[0000926326-16-000044:notes:148]
_________________________________________________

[0000926326-16-000044:notes:149]
(1) Additions to goodwill as a result of the Surgichem acquisition in August 2014, including a $0.1 million adjustment to the purchase price  in the fourth quarter of 2014.

[0000926326-16-000044:notes:150]
(2)  Adjustments reflect foreign currency exchange rate fluctuations.

[0000926326-16-000044:notes:151]
(3) Additions to goodwill as a result of the Mach4 and Avantec acquisitions in April 2015, including a $0.1 million adjustment to the purchase price in the fourth quarter of 2015 for Mach4.

[0000926326-16-000044:notes:152]
Intangible assets, net

[0000926326-16-000044:notes:153]
The carrying amounts of intangibles as of December 31, 2015 were as follows:

[0000926326-16-000044:notes:154]
|  | December 31, 2015 |
|  | Grosscarryingamount |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 69,554 |  |  | $ | (11,315 | ) |  | $ | (719 | ) |  | $ | 57,520 |  |  | 5 - 30 |
| Acquired technology | 30,870 |  |  | (6,088 | ) |  | 59 |  |  | 24,841 |  |  | 3 - 20 |
| Trade names | 8,052 |  |  | (2,551 | ) |  | (14 | ) |  | 5,487 |  |  | 1 - 12 |
| Patents | 1,960 |  |  | (384 | ) |  | — |  |  | 1,576 |  |  | 2 - 20 |
| Backlog | 415 |  |  | (163 | ) |  | (11 | ) |  | 241 |  |  | 2 |
| Total intangibles assets, net | $ | 110,851 |  |  | $ | (20,501 | ) |  | $ | (685 | ) |  | $ | 89,665 |  |  |  |

[0000926326-16-000044:notes:155]
The carrying amounts of intangibles as of December 31, 2014 were as follows:

[0000926326-16-000044:notes:156]
|  | December 31, 2014 |
|  | Gross carryingamount |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 60,150 |  |  | $ | (7,596 | ) |  | $ | (323 | ) |  | $ | 52,231 |  |  | 5 - 30 |
| Acquired technology | 27,580 |  |  | (4,068 | ) |  | — |  |  | 23,512 |  |  | 3 - 20 |
| Trade names | 7,110 |  |  | (1,559 | ) |  | (17 | ) |  | 5,534 |  |  | 1 - 12 |
| Patents | 1,655 |  |  | (265 | ) |  | — |  |  | 1,390 |  |  | 20 |
| Total intangibles assets, net | $ | 96,495 |  |  | $ | (13,488 | ) |  | $ | (340 | ) |  | $ | 82,667 |  |  |  |

[0000926326-16-000044:notes:157]
Amortization expense of intangible assets was $6.9 million, $4.6 million and $4.3 million for the years ended December 31, 2015, December 31, 2014 and December 31, 2013, respectively.

[0000926326-16-000044:notes:158]
The estimated future amortization expenses for intangible assets are as follows:

[0000926326-16-000044:notes:159]
| For the year ended December 31, | (In thousands) |
| 2016 | $ | 6,798 |  |
| 2017 | 5,996 |  |
| 2018 | 5,517 |  |
| 2019 | 5,244 |  |
| 2020 | 5,088 |  |
| Thereafter | 61,022 |  |
| Total | $ | 89,665 |  |


## us-gaap:GoodwillAndIntangibleAssetsPolicyTextBlock

[0000926326-16-000044:notes:160]
Goodwill and intangible assets

[0000926326-16-000044:notes:161]
Goodwill. The Company reviews goodwill for impairment on an annual basis on the first day of the fourth quarter of each year at the reporting unit level. The Company's reporting units are the same as its operating segments, which are Automation and Analytics and Medication Adherence. A qualitative assessment is initially made to determine whether it is necessary to perform quantitative testing. This initial assessment includes, among others, consideration of: (i) past, current and projected future earnings and equity; (ii) recent trends and market conditions; and (iii) valuation metrics involving similar companies that are publicly-traded and acquisitions of similar companies, if available. If this initial qualitative assessment indicates that it is more likely than not that impairment exists, or if the Company decides to bypass this option, it proceeds to a two-step impairment test. The first step ("Step 1") involves a comparison between the estimated fair values of the Company's reporting units with their respective carrying amounts including goodwill. The methods for estimating reporting unit values include asset and liability fair values and other valuation techniques, such as discounted cash flows and multiples of earnings or revenues. If the carrying value exceeds estimated fair value, there is an indication of potential impairment, and the second step is performed to measure the amount of impairment. The second step involves calculating an implied fair value of goodwill by measuring the excess of the estimated fair value of the reporting units over the aggregate estimated fair values of the individual assets less liabilities. If the carrying value of goodwill exceeds the implied fair value of goodwill, an impairment charge is recorded for the excess.

[0000926326-16-000044:notes:162]
To determine each reporting unit's fair value in the second step, the Company uses the income approach which is based on the estimated discounted future cash flows of that reporting unit. The estimated fair value of each reporting unit under the income approach is corroborated with the market approach, which measures the value of a business through an analysis of recent sales or offerings of a comparable entity. The Company also considers its market capitalization on the date of the analysis to ensure the reasonableness of the sum of its reporting units’ estimated fair value.

[0000926326-16-000044:notes:163]
Intangible assets. In connection with the Company's acquisitions, it generally recognizes assets for customer relationships, technology and trade names. Intangible assets are carried at cost less accumulated amortization. Such amortization is provided on a straight-line basis or on an accelerated basis based on a pattern of economic benefit that is expected to be obtained over the estimated useful lives of the respective assets, generally from 1 to 30 years. Amortization for technology is recognized in cost of product revenues, and amortization for customer relationships and trade names is recognized in selling, general and administrative expenses.

[0000926326-16-000044:notes:164]
The Company assesses the impairment of identifiable intangible assets whenever events or changes in circumstances indicate that an asset's carrying amount may not be recoverable. Recoverability of an asset is measured by the comparison of the carrying amount to the sum of the undiscounted estimated future cash flows the asset is expected to generate, offset by estimated future costs to dispose of the product to which the asset relates. If an asset is considered to be impaired, the amount of such impairment would be measured as the difference between the carrying amount of the asset and its fair value. The Company's cash flow assumptions are based on historical and forecasted future revenue, operating costs, and other relevant factors. Assumptions and estimates about the remaining useful lives of the Company's intangible assets are subjective and are affected by changes to its business strategies. If management’s estimates of future operating results change, or if there are changes to other assumptions, the estimate of the fair value of the Company's assets could change significantly. Such change could result in impairment charges in future periods, which could have a significant impact on the Company's operating results and financial condition.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000926326-16-000044:notes:165]
Income Taxes

[0000926326-16-000044:notes:166]
The following is a geographical breakdown of income before the provision for income taxes:

[0000926326-16-000044:notes:167]
|  | Year Ended |
|  | December 31, 2015 |  | December 31, 2014 |  | December 31, 2013 |
|  | (In thousands) |
| Domestic | $ | 51,089 |  |  | $ | 48,327 |  |  | $ | 34,678 |  |
| Foreign | (4,845 | ) |  | 177 |  |  | 351 |  |
| Income before provision for income taxes | $ | 46,244 |  |  | $ | 48,504 |  |  | $ | 35,029 |  |

[0000926326-16-000044:notes:168]
The provision for income taxes consists of the following:

[0000926326-16-000044:notes:169]
|  | Year Ended |
|  | December 31, 2015 |  | December 31, 2014 |  | December 31, 2013 |
|  | (In thousands) |
| Current: |  |  |  |  |  |
| Federal | $ | 13,840 |  |  | $ | 14,063 |  |  | $ | 8,218 |  |
| State | 2,475 |  |  | 2,274 |  |  | 1,621 |  |
| Foreign | 203 |  |  | 192 |  |  | 447 |  |
| Total current income taxes | 16,518 |  |  | 16,529 |  |  | 10,286 |  |
| Deferred: |  |  |  |  |  |
| Federal | 846 |  |  | 1,603 |  |  | 1,287 |  |
| State | (379 | ) |  | 84 |  |  | (263 | ) |
| Foreign | (1,501 | ) |  | (230 | ) |  | (260 | ) |
| Total deferred income taxes | (1,034 | ) |  | 1,457 |  |  | 764 |  |
| Total provision for income taxes | $ | 15,484 |  |  | $ | 17,986 |  |  | $ | 11,050 |  |

[0000926326-16-000044:notes:170]
The provision for income taxes differs from the amount computed by applying the statutory federal tax rate as follows:

[0000926326-16-000044:notes:171]
|  | Year Ended |
|  | December 31, 2015 |  | December 31, 2014 |  | December 31, 2013 |
|  | (In thousands) |
| U.S. federal tax provision at statutory rate | $ | 16,181 |  |  | $ | 16,998 |  |  | $ | 12,260 |  |
| State taxes | 1,365 |  |  | 1,533 |  |  | 883 |  |
| Non-deductible expenses | 551 |  |  | 809 |  |  | 297 |  |
| Acquisition costs | 239 |  |  | 229 |  |  | — |  |
| Share-based compensation expense | 748 |  |  | 461 |  |  | 407 |  |
| Research tax credits | (1,324 | ) |  | (818 | ) |  | (1,430 | ) |
| Domestic production deduction | (1,133 | ) |  | (1,127 | ) |  | (816 | ) |
| Gain on investment | (1,205 | ) |  | — |  |  | — |  |
| Other | 62 |  |  | (99 | ) |  | (551 | ) |
| Total provision for income taxes | $ | 15,484 |  |  | $ | 17,986 |  |  | $ | 11,050 |  |

[0000926326-16-000044:notes:172]
Significant components of the Company's deferred tax assets (liabilities) are as follows:

[0000926326-16-000044:notes:173]
|  | December 31, 2015 |  | December 31, 2014 |
|  | (In thousands) |
| Deferred tax assets (liabilities): |  |  |  |
| Deferred revenue | $ | 14,020 |  |  | $ | 12,639 |  |
| Stock compensation | 6,034 |  |  | 6,287 |  |
| Inventory related items | 2,541 |  |  | 2,713 |  |
| Tax credit carry forwards | 2,579 |  |  | 2,168 |  |
| Reserves and accruals | — |  |  | 327 |  |
| Loss carry forwards | 667 |  |  | 12 |  |
| Other, net | 697 |  |  | — |  |
| Total net deferred tax assets | 26,538 |  |  | 24,146 |  |
| Intangibles | (28,213 | ) |  | (26,485 | ) |
| Depreciation and amortization | (17,185 | ) |  | (14,331 | ) |
| Reserves and accruals | (601 | ) |  | — |  |
| Other, net | — |  |  | (194 | ) |
| Total deferred tax liabilities | (45,999 | ) |  | (41,010 | ) |
| Net deferred tax liabilities | $ | (19,461 | ) |  | $ | (16,864 | ) |

[0000926326-16-000044:notes:174]
Deferred income tax assets (liabilities) are provided for temporary differences that will result in future tax deductions or future taxable income, as well as the future benefit of tax credit carry forwards. The Company recognizes deferred tax assets to the extent that it believes these assets are more likely than not to be realized. In making such a determination, the Company considers all available positive and negative evidence, including future reversals of existing temporary differences, projected future taxable income, tax planning strategies, and results of recent operations. On the basis of this evaluation, as of December 31, 2015, no valuation allowances have been recorded in any jurisdiction.

[0000926326-16-000044:notes:175]
As of December 31, 2015, the Company has an immaterial amount of state net operating loss carryforwards available for income tax purposes. For income tax purposes, the Company has California research tax credits carryforwards of $9.1 million. Federal research tax credit carryforwards from prior years have been utilized or have expired. California credits are available indefinitely to reduce cash taxes otherwise payable. Pursuant to the requirements of ASC 718, the Company does not include unrealized stock option attributes as components of its gross deferred tax assets. The tax-effected amounts of gross unrealized net operating loss and business tax credit carry forwards excluded under ASC 718 for the year ended December 31, 2015 are immaterial.

[0000926326-16-000044:notes:176]
In general, it is the Company's practice and intention to reinvest the earnings of its non-U.S. subsidiaries in those operations.  As of December 31, 2015, the Company has not made a provision for U.S. federal income and state income taxes on accumulated and current earnings of $1.0 million related to certain foreign subsidiaries because these earnings are intended to be indefinitely reinvested in operations outside the U.S. If the Company expects to distribute those earnings in the form of dividends or otherwise, the Company would be subject to U.S. and state income taxes reported as a component of income tax expense, in the amount of $0.4 million. This amount may be reduced by any foreign tax credits available at the time of repatriation.

[0000926326-16-000044:notes:177]
The Company files income tax returns in the United States and various states and foreign jurisdictions. In the normal course of business, the Company is subject to examination by taxing authorities, including major jurisdictions as the United States, California, the United Kingdom and Germany. In 2012, the Company concluded audits by the IRS and the California Franchise Tax Board for years 2008 and 2009. However, all of the net operating loss and research credit carryforwards that may be used in future years are subject to adjustment, if and when utilized. As such the Company's U.S. federal and California tax years remain open from 1996 and 1992, respectively. In late 2014, the Company was contacted by the IRS for a limited scope audit for tax years 2011 and 2012. In 2015, the audit was expanded to include 2013. At this time, the Company does not believe results of this audit will have a material impact on its financial statements.

[0000926326-16-000044:notes:178]
The aggregate change in the balance of gross unrecognized tax benefits, which excludes interest and penalties, for the three years ended December 31, 2015 is as follows:

[0000926326-16-000044:notes:179]
|  | (In thousands) |
| Year Ended December 31, 2012 | $ | 6,915 |  |
| Increases related to tax positions taken during a prior period | 406 |  |
| Decreases related to tax positions taken during the prior period | (79 | ) |
| Increases related to tax positions taken during the current period | 764 |  |
| Decreases related to settlements | — |  |
| Decreases related to expiration of statute of limitations | (32 | ) |
| Year Ended December 31, 2013 | 7,974 |  |
| Increases related to tax positions taken during a prior period | 63 |  |
| Decreases related to tax positions taken during the prior period | (89 | ) |
| Increases related to tax positions taken during the current period | 801 |  |
| Decreases related to settlements | — |  |
| Decreases related to expiration of statute of limitations | (264 | ) |
| Year Ended December 31, 2014 | 8,485 |  |
| Increases related to tax positions taken during a prior period | 37 |  |
| Decreases related to tax positions taken during the prior period | (895 | ) |
| Increases related to tax positions taken during the current period | 1,807 |  |
| Decreases related to settlements | — |  |
| Decreases related to expiration of statute of limitations | (284 | ) |
| Year Ended December 31, 2015 | $ | 9,150 |  |

[0000926326-16-000044:notes:180]
As of December 31, 2015 the total amount of gross unrecognized tax benefits, if realized, would decrease the Company's tax expense by approximately $6.0 million. The Company recognizes interest and/or penalties related to uncertain tax positions in operating expenses, which for 2015 was immaterial. The Company does not believe there will be any material changes in its unrecognized tax positions over the next twelve months.


## us-gaap:IncomeTaxPolicyTextBlock

[0000926326-16-000044:notes:181]
Accounting for income taxes

[0000926326-16-000044:notes:182]
The Company records an income tax provision for the anticipated tax consequences of the reported results of operations. In accordance with U.S. GAAP, the provision for income taxes is computed using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been included in the financial statements. Under this method, deferred tax assets and liabilities are determined on the basis of the differences between the financial statement and tax bases of assets and liabilities and for operating losses and tax credit carry forwards. Deferred tax assets and liabilities are measured using the enacted tax rates in effect for the periods in which those tax assets and liabilities are expected to be realized or settled. In the event that these tax rates change, the Company will incur a benefit or detriment on its income tax expense in the period of change. If the Company were to determine that all or part of the net deferred tax assets are not realizable in the future, it will record a valuation allowance that would be charged to earnings in the period such determination is made.

[0000926326-16-000044:notes:183]
In accordance with ASC 740, Income Taxes, the Company recognizes the tax benefit from an uncertain tax position if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement. The calculation of tax liabilities involves significant judgment in estimating the impact of uncertainties in the application of U.S. GAAP and complex tax laws. Resolution of these uncertainties in a manner inconsistent with management’s expectations could have a material impact on our financial condition and operating results.


## us-gaap:InventoryPolicyTextBlock

[0000926326-16-000044:notes:184]
Inventory

[0000926326-16-000044:notes:185]
Inventories are stated at the lower of cost (utilizing standard costs, applying the first-in, first-out method) or market. Cost elements included in inventory are direct labor and materials plus applied overhead. The Company routinely assesses on-hand inventory for timely identification and measurement of obsolete, slow-moving or otherwise impaired inventory. The Company writes down its inventory for estimated obsolescence, excess or unmarketable quantities equal to the difference between the cost of the inventory and its estimated market value based on assumptions about future demand and market conditions. If actual future demand or market conditions are less favorable than the Company projected, additional inventory write-downs may be required.


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0000926326-16-000044:notes:186]
Property and equipment, net

[0000926326-16-000044:notes:187]
|  | Year Ended |
|  | December 31, 2015 |  | December 31, 2014 |  | December 31, 2013 |
|  | (In thousands) |
| United States | $ | 29,506 |  |  | $ | 35,335 |  |  | $ | 35,254 |  |
| Rest of world (1) | 2,803 |  |  | 843 |  |  | — |  |
| Total property and equipment, net | $ | 32,309 |  |  | $ | 36,178 |  |  | $ | 35,254 |  |

[0000926326-16-000044:notes:188]
(1)    No individual country represented more than 10% of the respective totals.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000926326-16-000044:notes:189]
Recently adopted accounting standards

[0000926326-16-000044:notes:190]
During November 2015, the FASB issued ASU 2015-17, Balance Sheet Classification of Deferred Taxes ("ASU 2015-17"). ASU 2015-17 requires deferred tax assets and liabilities to be classified as noncurrent in the Consolidated Balance Sheet. The Company early adopted ASU 2015-17 effective December 31, 2015 on a prospective basis. Adoption of ASU 2015-17 resulted in a reclassification of the Company's net current deferred tax assets of $12.5 million to the net non-current deferred tax liabilities in its Consolidated Balance Sheet as of December 31, 2015.

[0000926326-16-000044:notes:191]
Recently issued authoritative guidance

[0000926326-16-000044:notes:192]
In May 2014, the FASB issued ASU No. 2014-09, Revenue from Contracts with Customers ("ASU 2014-09"). Under the new guidance, an entity is required to recognize an amount of revenue to which it expects to be entitled for the transfer of promised goods or services to customers. The original effective date for the ASU would have required the Company to adopt the standard beginning in its first quarter of fiscal year 2017. In July 2015, the FASB voted to amend ASU 2014-09 by approving a one-year deferral of the effective date as well as providing the option to early adopt the standard on the original effective date. Accordingly, the Company may adopt the standard in its first quarter of fiscal year 2018. The new revenue guidance may be applied retrospectively to each prior period presented or retrospectively with the cumulative effect recognized as of the date of adoption. The Company is currently in the process of evaluating the impact of the adoption of ASU 2014-09 on its consolidated financial statements.

[0000926326-16-000044:notes:193]
In September 2015, the FASB issued ASU No. 2015-16, Business Combinations (Topic 805): Simplifying the Accounting for Measurement-Period Adjustments ("ASU 2015-16"). This ASU requires adjustments to provisional amounts that are identified during the measurement period of a business combination to be recognized in the reporting period in which the adjustment amounts are determined. Acquirer are no longer required to revise comparative information for prior periods as if the accounting for the business combination had been completed as of the acquisition date. The provisions of ASU 2015-16 are effective for reporting periods beginning after December 15, 2015. The Company is currently in the process of evaluating the impact of the adoption of ASU 2015-16 on its consolidated financial statements.

[0000926326-16-000044:notes:194]
In February 2016, the FASB issued ASU No. 2016-02, Leases (Topic 842). The FASB amended lease accounting requirements to begin recording assets and liabilities arising from leases on the balance sheet. The new guidance will also require significant additional disclosures about the amount, timing and uncertainty of cash flows from leases. This new guidance will be effective for us beginning on January 1, 2019 using a modified retrospective approach. The modified retrospective approach includes a number of optional practical expedients that entities may elect to apply. The Company is currently evaluating the impact ASU 2016-02 will have on its consolidated financial statements.

[0000926326-16-000044:notes:195]
There was no other recently issued authoritative guidance that has a material impact on the Company's Consolidated Financial Statements through the reporting date.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000926326-16-000044:notes:196]
Organization and Summary of Significant Accounting Policies

[0000926326-16-000044:notes:197]
Business

[0000926326-16-000044:notes:198]
Omnicell, Inc. was incorporated in California in 1992 under the name Omnicell Technologies, Inc. and reincorporated in Delaware in 2001 as Omnicell, Inc. The Company's major products are automated medication, supply control systems and medication adherence solutions which are sold in its principal market, which is the healthcare industry. The Company's market is primarily located in the United States,Canada and United Kingdom. "Omnicell" or the "Company" refer to Omnicell, Inc. and its subsidiaries.

[0000926326-16-000044:notes:199]
On April 21, 2015, the Company completed its acquisition of Mach4 Automatisierungstechnik GmbH (“Mach4”), a privately held German limited liability company with registered office in Bochum, Germany. On April 30, 2015, the Company acquired the remaining 85% of the issued and outstanding ordinary shares of Avantec Healthcare Limited (“Avantec”) not already held by Omnicell. The consolidated financial statements include the results of operations of Mach4 and Avantec commencing as of their respective acquisition dates.

[0000926326-16-000044:notes:200]
Use of estimates

[0000926326-16-000044:notes:201]
The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company's Consolidated Financial Statements and accompanying Notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management's best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. The Company's critical accounting policies are those that affect its financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition, share-based compensation, inventory valuation, accounts receivable and notes receivable (net investment in sales-type leases), capitalized software development costs, valuation of goodwill, purchased intangibles and long-lived assets, and accounting for income taxes.

[0000926326-16-000044:notes:202]
Segment reporting change

[0000926326-16-000044:notes:203]
The Company's Chief Operating Decision Maker (“CODM”) is its Chief Executive Officer. In the first quarter of 2015, the Company modified its segment presentation to reflect the changes in how its CODM reviews the segments and the overall business. With the increase in completed acquisitions in the last two years, the Company changed how the financial information was presented for CODM review to exclude general corporate-level costs that are not specific to either of the reportable segments when evaluating the operating results of each segment. Corporate-level costs include expenses related to executive management, finance and accounting, human resources, legal, training and development, and certain administrative expenses.

[0000926326-16-000044:notes:204]
The Company's CODM allocates resources and evaluates the performance of its segments using information about its revenues, gross profit and income from operations, excluding certain costs which are managed separately at the corporate level. The historical segment financial information has been adjusted to reflect the modified segment reporting.  See Note 12, Segment and Geographical Information, for addition information on the segment reporting change.

[0000926326-16-000044:notes:205]
Revenue recognition

[0000926326-16-000044:notes:206]
The Company earns revenues from sales of our medication and medical and surgical supply automation systems along with consumables and related services, which are sold in the healthcare industry, our principal market. Revenues related to consumable products are reported net of discounts provided to its customers. The Company's customer arrangements typically include one or more of the following deliverables:

[0000926326-16-000044:notes:207]
Products. Software-enabled equipment that manages and regulates the storage and dispensing of pharmaceuticals, consumable blister cards and packaging equipment and other medical supplies.

[0000926326-16-000044:notes:208]
Software. Additional software applications that enable incremental functionality of its equipment.

[0000926326-16-000044:notes:209]
Installation. Installation of equipment as integrated systems at customers' sites.

[0000926326-16-000044:notes:210]
Post-installation technical support. Phone support, on-site service, parts and access to unspecified software upgrades and enhancements, if and when available.

[0000926326-16-000044:notes:211]
Professional services. Other customer services, such as training and consulting.

[0000926326-16-000044:notes:212]
The Company recognizes revenue when the earnings process is complete, based upon its evaluation of whether the following four criteria have been met:

[0000926326-16-000044:notes:213]
Persuasive evidence of an arrangement exists. The Company uses signed customer contracts and signed customer purchase orders as evidence of an arrangement for leases and sales. For service engagements, the Company uses a signed services agreement and a statement of work to evidence an arrangement.

[0000926326-16-000044:notes:214]
Delivery has occurred. Equipment and embedded software product delivery is deemed to occur upon successful installation and receipt of a signed and dated customer confirmation of installation letter, providing evidence that the Company has delivered what a customer ordered. In instances of a customer self-installation, product delivery is deemed to have occurred upon receipt of a signed and dated customer confirmation letter. If a sale does not require installation, the Company recognizes revenue on delivery of products to the customer, including transfer of title and risk of loss, assuming all other revenue criteria are met. For existing distributors, where installation of equipment training has been previously provided and the distributor is certified to install the Company's equipment at the end-user customer facility, the Company recognizes revenue from sales of products to the distributor upon shipment assuming all other revenue criteria are met since it does not allow for rights of return or refund. For new distributors, where the Company has not provided installation of equipment training, revenue on the sales of products to the distributor is deferred until the distributor has completed the Distributor Training Program and has been certified to install the Company's equipment at the end-user facility. For the sale of consumable blister cards, the Company recognizes revenue when title and risk of loss of the products shipped have transferred to the customer, which usually occurs upon shipment from the Company's facilities. Assuming all other revenue criteria are met, the Company recognizes revenue for support services ratably over the related support services contract period. The Company recognizes revenue on training and professional services as they are performed.

[0000926326-16-000044:notes:215]
Fee is fixed or determinable. The Company assesses whether a fee is fixed or determinable at the outset of the arrangement based on the payment terms associated with the transaction. The Company has established a history of collecting under the original contract without providing concessions on payments, products or services.

[0000926326-16-000044:notes:216]
Collection is probable. The Company assesses the probability of collecting from each customer at the outset of the arrangement based on a number of factors, including the customer's payment history and its current creditworthiness. If, in the Company's judgment, collection of a fee is not probable, the Company defers revenue recognition until the uncertainty is removed, which generally means revenue is recognized upon the Company's receipt of cash payment assuming all other revenue criteria are met. The Company's historical experience has been that collection from its customers is generally probable.

[0000926326-16-000044:notes:217]
In arrangements with multiple deliverables, assuming all other revenue criteria are met, the Company recognizes revenue for individual delivered items if they have value to the customer on a standalone basis. The Company allocates arrangement consideration at the inception of the arrangement to all deliverables using the relative selling price method. This method requires the Company to determine the selling price at which each deliverable could be sold if it were sold regularly on a standalone basis. When available, the Company uses vendor-specific objective evidence ("VSOE") of the selling price. VSOE represents the price charged for a deliverable when it is sold separately, or for a deliverable not yet being sold separately, the price established by management with the relevant authority. The Company considers VSOE to exist when approximately 80% or more of its standalone sales of an item are priced within a reasonably narrow pricing range (plus or minus 15% of the median rates). The Company has established VSOE of the selling price for its post-installation technical support services and professional services. When VSOE of selling price is not available, third-party evidence ("TPE") of selling price for similar products and services is acceptable; however, the Company's offerings and market strategy differ from those of its competitors, such that it cannot obtain sufficient comparable information about third parties' prices. If neither VSOE nor TPE are available, the Company uses its best estimates of selling prices ("BESP"). The Company determines BESP considering factors such as market conditions, sales channels, internal costs and product margin objectives and pricing practices. The Company regularly reviews and updates its VSOE and BESP information.

[0000926326-16-000044:notes:218]
The relative selling price method allocates total arrangement consideration proportionally to each deliverable on the basis of its estimated selling price. In addition, the amount recognized for any delivered items cannot exceed that which is not contingent upon delivery of any remaining items in the arrangement.

[0000926326-16-000044:notes:219]
The Company also uses the residual method to allocate revenue between the software products that enable incremental equipment functionality, and thus are not deemed to deliver its essential functionality, and the related post-installation technical support, as these products and services continue to be accounted for under software revenue recognition rules. Under the residual method, the amount allocated to the undelivered elements equals VSOE of fair value of these elements. Any remaining amounts are attributed to the delivered items and are recognized when those items are delivered.

[0000926326-16-000044:notes:220]
A portion of the Company's sales are made through multi-year lease agreements. Under sales-type leases, the Company recognizes revenue for its hardware and software products net of lease execution costs such as post-installation product maintenance and technical support, at the net present value of the lease payment stream once its installation obligations have been met. The Company optimizes cash flows by selling a majority of its non-U.S. government leases to third-party leasing finance companies on a non-recourse basis. The Company has no obligation to the leasing company once the lease has been sold. Some of the Company's sales-type leases, mostly those relating to U.S. government hospitals which comprise approximately 75% of the lease receivable balance, are retained in-house. Interest income in these leases is recognized in product revenue using the effective interest method.

[0000926326-16-000044:notes:221]
Financial Instruments

[0000926326-16-000044:notes:222]
For assets and liabilities measured at fair value, such amounts are based on an expected exit price representing the amount that would be received from the sale of an asset or paid to transfer a liability in a transaction between market participants. As such, fair value may be based on assumptions that market participants would use in pricing an asset or liability. The authoritative guidance on fair value measurements establishes a consistent framework for measuring fair value on either a recurring or nonrecurring basis whereby inputs used in valuation techniques are assigned a hierarchical level. The following methods were used to estimate the fair value of each class of financial instruments for which it is practical to estimate that value:

[0000926326-16-000044:notes:223]
Accounts receivable and notes receivable (net investment in sales-type leases)

[0000926326-16-000044:notes:224]
The Company actively manages its accounts receivable to minimize credit risk. The Company typically sells to customers for which there is a history of successful collection. New customers are subject to a credit review process, which evaluates that customer's financial position and ability to pay. The Company continually monitors and evaluates the collectability of its trade receivables based on a combination of factors. The Company records specific allowances for doubtful accounts when it becomes aware of a specific customer's impaired ability to meet its financial obligation to the Company, such as in the case of bankruptcy filings or deterioration of financial position. There were no significant customers that accounted for more than 10% of the Company's accounts receivable as of December 31, 2015 and December 31, 2014.

[0000926326-16-000044:notes:225]
Uncollectible amounts are charged off against trade receivables and the allowance for doubtful accounts when the Company makes a final determination that there is no reasonable expectation of recovery. Estimates are used in determining the Company's allowances for all other customers based on factors such as current trends, the length of time the receivables are past due and historical collection experience. While the Company believes that its allowance for doubtful accounts receivable is adequate and that the judgment applied is appropriate, such estimated amounts could differ materially from what will actually be uncollectible in the future.

[0000926326-16-000044:notes:226]
The retained in-house leases discussed above are considered financing receivables. The Company's credit policies and its evaluation of credit risk and write-off policies are applied alike to trade receivables and the net investment in sales-type leases. For both, an account is generally past due after thirty days. The financing receivables also have customer-specific reserves for accounts identified for specific impairment and a non-specific reserve applied to the remaining population, based on factors such as current trends, the length of time the receivables are past due and historical collection experience. The retained in-house leases are not stratified by portfolio or class.

[0000926326-16-000044:notes:227]
Sales of accounts receivable

[0000926326-16-000044:notes:228]
The Company records the sale of its accounts receivables as "true sales" in accordance with accounting guidance for transfers and servicing of financial assets. The Company transferred non-recourse accounts receivable totaling $38.6 million, $62.0 million and $41.3 million during fiscal year 2015, 2014, and 2013, respectively, which approximated fair value, to leasing companies on a non-recourse basis. Accounts receivable included approximately $0.8 million, $1.1 million and $0.1 million due from third-party leasing companies for transferred non-recourse accounts receivable as of December 31, 2015, December 31, 2014 and December 31, 2013, respectively.

[0000926326-16-000044:notes:229]
The Company has a supply agreement with one primary supplier for construction and supply of several sub-assemblies and inventory management of sub-assemblies used in our hardware products. There are no minimum purchase requirements. The contract with the Company's supplier may be terminated by either the supplier or by the Company without cause and at any time upon delivery of two months' notice. Purchases from this supplier were $41.7 million, $34.5 million and $29.2 million for the years ended December 31, 2015, December 31, 2014 and December 31, 2013, respectively.

[0000926326-16-000044:notes:230]
Property and equipment

[0000926326-16-000044:notes:231]
Property and equipment less accumulated depreciation are stated at historical cost. The Company's expenditures for property and equipment primarily are for computer equipment and software used in the administration of its business, and for leasehold improvements to its leased facilities. The Company also develops molds and dies used in long-term manufacturing arrangements with suppliers and for production automation equipment used in the manufacturing of consumable blister card components. Depreciation and amortization of property and equipment are provided over their estimated useful lives, using the straight-line method, as follows:

[0000926326-16-000044:notes:232]
| Computer equipment and related software | 3 - 5 years |
| Leasehold and building improvements | Shorter of the lease term or the estimated useful life |
| Furniture and fixtures | 5 - 7 years |
| Equipment | 3 - 12 years |

[0000926326-16-000044:notes:233]
Depreciation and amortization of property and equipment was $12.8 million, $11.3 million and $10.9 million for the years ended December 31, 2015, December 31, 2014 and December 31, 2013, respectively.

[0000926326-16-000044:notes:234]
The Company capitalizes costs related to computer software developed or obtained for internal use in accordance with ASC 350-40, Internal-Use Software. Software obtained for internal use has generally been enterprise-level business and finance software that the Company customizes to meet its specific operational needs. Costs incurred in the application development phase are capitalized and amortized over their useful lives, which is generally five years. Costs recognized in the preliminary project phase and the post-implementation phase are expensed as incurred. The Company capitalized $1.2 million and $3.9 million of costs related to the application development of enterprise-level software that was included in property and equipment during the years ended December 31, 2015 and December 31, 2014, respectively.

[0000926326-16-000044:notes:235]
Software development costs

[0000926326-16-000044:notes:236]
The Company capitalizes software development costs in accordance with ASC 985-20, Costs of Software to Be Sold, Leased, or Marketed, under which certain software development costs incurred subsequent to the establishment of technological feasibility may be capitalized and amortized over the estimated lives of the related products. The Company establishes feasibility when it completes a working model and amortizes development costs over the estimated lives of the related products ranging from three to five years. The Company capitalized software development costs of $12.1 million and $10.4 million which are included in other assets as of December 31, 2015 and December 31, 2014, respectively. The Company recorded $5.8 million, $4.4 million and $3.2 million to cost of revenues for amortization of capitalized software development costs for the years ended December 31, 2015, December 31, 2014 and December 31, 2013, respectively. All development costs prior to the completion of a working model are recognized as research and development expense.

[0000926326-16-000044:notes:237]
Deferred gross profit and deferred service revenue

[0000926326-16-000044:notes:238]
Deferred gross profit and deferred service revenue arise when customers have been billed and/or have received products and/or services in advance of revenue recognition. The Company's deferred gross profit, classified as a current liability, consists primarily of unearned revenue on sale of equipment for which installation has not been completed, net of deferred cost of sales for such equipment, and the unearned revenue for software licenses. The Company's deferred service revenue, separated into current and long-term liabilities, consists of the unearned portion of service contracts for which revenue is recognized over their duration.

[0000926326-16-000044:notes:239]
Business combinations

[0000926326-16-000044:notes:240]
The Company uses the acquisition method of accounting under the authoritative guidance on business combinations. Each acquired company’s operating results are included in the Company's Consolidated Financial Statements starting on the date of acquisition. The purchase price is equivalent to the fair value of consideration transferred. Tangible and identifiable intangible assets acquired and liabilities assumed as of the date of acquisition are recorded at the acquisition date fair value. Goodwill is recognized for the excess of purchase price over the net fair value of assets acquired and liabilities assumed.

[0000926326-16-000044:notes:241]
Amounts allocated to assets and liabilities are based upon fair values. Such valuations require management to make significant estimates and assumptions, especially with respect to the identifiable intangible assets. Management makes estimates of fair value based upon assumptions believed to be reasonable and that of a market participant. These estimates are based on historical experience and information obtained from the management of the acquired companies and the estimates are inherently uncertain. The separately identifiable intangible assets generally include customer relationships, technology, and trade names.

[0000926326-16-000044:notes:242]
The Company accounts for share-based compensation in accordance with ASC 718, Stock Compensation ("ASC 718"). The Company recognizes compensation expense related to stock-based compensation, including the awarding of employee stock awards and restricted stock units, based on the grant date estimated fair value. The Company amortizes the fair value of the employee stock awards on a straight-line basis over the requisite service period of the award, which is generally the vesting period. The Company estimates the fair value of stock-based compensation awards using the Black-Scholes option pricing model, which requires the following inputs: expected life, expected volatility, risk-free interest rate, expected dividend yield rate, exercise price, and closing price of its common stock on the date of grant. The expected volatility is based on a combination of historical and market-based implied volatility, and the expected life of the awards is based on the Company's historical experience of employee stock option exercises, including forfeitures. The valuation assumptions we use in estimating the fair value of employee share-based awards may change in future periods. The Company calculates its pool of excess tax benefits available within additional paid-in capital in accordance with the provisions of ASC 718.

[0000926326-16-000044:notes:243]
Advertising expense

[0000926326-16-000044:notes:244]
Costs related to advertising and promotion of products are charged to sales and marketing expense as incurred. Advertising expense was approximately $0.7 million, $0.8 million and $0.7 millionfor the years ended December 31, 2015, December 31, 2014 and December 31, 2013, respectively.

[0000926326-16-000044:notes:245]
Shipping costs

[0000926326-16-000044:notes:246]
Outbound freight billed to customers is recorded as product revenue. The related shipping and handling costs are expensed as part of selling, general and administrative expense. Shipping and handling expenses were $8.5 million, $7.4 million and $6.1 million for the year ended December 31, 2015, December 31, 2014 and December 31, 2013, respectively.


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0000926326-16-000044:notes:247]
Geographical Information

[0000926326-16-000044:notes:248]
Revenues

[0000926326-16-000044:notes:249]
|  | Year Ended |
|  | December 31, 2015 |  | December 31, 2014 |  | December 31, 2013 |
|  | (In thousands) |
| United States | $ | 403,375 |  |  | $ | 394,234 |  |  | $ | 334,412 |  |
| Rest of world (1) | 81,184 |  |  | 46,666 |  |  | 46,173 |  |
| Total revenues | $ | 484,559 |  |  | $ | 440,900 |  |  | $ | 380,585 |  |


## us-gaap:ScheduleOfCondensedBalanceSheetTableTextBlock

[0000926326-16-000044:notes:250]
|  | December 31, 2015 |  | December 31, 2014 |
|  | (In thousands) |
| Inventories: |  |  |  |
| Raw materials | $ | 11,582 |  |  | $ | 8,254 |  |
| Work in process | 1,653 |  |  | 64 |  |
| Finished goods | 33,359 |  |  | 23,236 |  |
| Total inventories | $ | 46,594 |  |  | $ | 31,554 |  |
| Property and equipment: |  |  |  |
| Equipment | $ | 43,533 |  |  | $ | 42,829 |  |
| Furniture and fixtures | 5,897 |  |  | 5,689 |  |
| Leasehold improvements | 9,063 |  |  | 8,701 |  |
| Software | 30,693 |  |  | 28,920 |  |
| Construction in progress | 3,651 |  |  | 1,538 |  |
| Property and equipment, gross | 92,837 |  |  | 87,677 |  |
| Accumulated depreciation and amortization | (60,528 | ) |  | (51,499 | ) |
| Total property and equipment, net | $ | 32,309 |  |  | $ | 36,178 |  |
| Other long term assets: |  |  |  |
| Capitalized software, net | $ | 26,011 |  |  | $ | 19,643 |  |
| Other assets | 1,883 |  |  | 3,630 |  |
| Total other long term assets, net | $ | 27,894 |  |  | $ | 23,273 |  |
| Accrued liabilities: |  |  |  |
| Advance payments from customers | $ | 8,327 |  |  | $ | 4,834 |  |
| Rebates and lease buyouts | 4,702 |  |  | 6,512 |  |
| Group purchasing organization fees | 2,983 |  |  | 3,475 |  |
| Taxes payable | 2,768 |  |  | 2,181 |  |
| Other accrued liabilities | 11,353 |  |  | 2,297 |  |
| Total accrued liabilities | $ | 30,133 |  |  | $ | 19,299 |  |
| Deferred gross profit: |  |  |  |
| Sales of medication and supply dispensing systems including packaging equipment | $ | 41,396 |  |  | $ | 36,947 |  |
| Less: cost of revenues, excluding installation costs | (15,688 | ) |  | (8,389 | ) |
| Total deferred gross profit | $ | 25,708 |  |  | $ | 28,558 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000926326-16-000044:notes:251]
The following table summarizes the financial performance of the Company's reporting segments:

[0000926326-16-000044:notes:252]
|  | Year Ended |
|  | December 31, 2015 |  | December 31, 2014 |  | December 31, 2013 |
|  | Automation andAnalytics (1) |  | MedicationAdherence (2) |  | Total |  | Automation andAnalytics |  | MedicationAdherence (2) |  | Total |  | Automation andAnalytics |  | MedicationAdherence |  | Total |
|  | (In thousands) |
| Revenues | $ | 390,321 |  |  | $ | 94,238 |  |  | $ | 484,559 |  |  | $ | 354,095 |  |  | $ | 86,805 |  |  | $ | 440,900 |  |  | $ | 302,917 |  |  | $ | 77,668 |  |  | $ | 380,585 |  |
| Cost of revenues | 171,943 |  |  | 64,686 |  |  | 236,629 |  |  | 151,327 |  |  | 55,713 |  |  | 207,040 |  |  | 129,314 |  |  | 47,872 |  |  | 177,186 |  |
| Gross profit | 218,378 |  |  | 29,552 |  |  | 247,930 |  |  | 202,768 |  |  | 31,092 |  |  | 233,860 |  |  | 173,603 |  |  | 29,796 |  |  | 203,399 |  |
| Operating expenses | 114,084 |  |  | 24,258 |  |  | 138,342 |  |  | 105,929 |  |  | 20,586 |  |  | 126,515 |  |  | 140,087 |  |  | 14,905 |  |  | 154,992 |  |
| Income from operations | $ | 104,294 |  |  | $ | 5,294 |  |  | 109,588 |  |  | $ | 96,839 |  |  | $ | 10,506 |  |  | 107,345 |  |  | $ | 33,516 |  |  | $ | 14,891 |  |  | 48,407 |  |
| Corporate costs |  |  |  |  | 60,956 |  |  |  |  |  |  | 57,762 |  |  |  |  |  |  | 13,108 |  |
| Income from operations |  |  |  |  | $ | 48,632 |  |  |  |  |  |  | $ | 49,583 |  |  |  |  |  |  | $ | 35,299 |  |

[0000926326-16-000044:notes:253]
| (1) | Includes Avantec and Mach4 results as of April 2015, the acquisition date. |

[0000926326-16-000044:notes:254]
| (2) | Includes Surgichem results as of August 2014, the acquisition date. |

[0000926326-16-000044:notes:255]
Significant customers

[0000926326-16-000044:notes:256]
There were no significant customers that accounted for more than 10% of the Company's total revenues in 2015, 2014 and 2013.


## us-gaap:ScheduleOfTreasuryStockByClassTextBlock

[0000926326-16-000044:notes:257]
The following table presents a summary of our stock repurchase activity for the year ended December 31, 2015:

[0000926326-16-000044:notes:258]
|  | Total Number of Shares Purchased |  | Average PricePaid per Share |  | Total Amounts of Shares Purchased Under Publicly Announced Programs |
|  | (In thousands, except per share data) |
| During fiscal year ended December 31, 2015: |  |  |  |  |  |
| May 1, 2015 to May 31 2015 | 321 |  |  | $ | 35.91 |  |  | $ | 11,528 |  |
| June 1, 2015 to June 30, 2015 | 360 |  |  | 37.48 |  |  | 13,493 |  |
| August 1, 2015 to August 31, 2015 | 189 |  |  | 33.75 |  |  | 6,378 |  |
| September 1, 2015 to September 30, 2015 | 554 |  |  | 33.61 |  |  | 18,622 |  |
| Total share repurchased during 2015 | 1,424 |  |  | 35.13 |  |  | $ | 50,021 |  |

[0000926326-16-000044:notes:259]
The following table summarizes the Company's stock repurchases during each reporting period:

[0000926326-16-000044:notes:260]
|  | Year Ended |
|  | December 31, 2015 |  | December 31, 2014 |  | December 31, 2013 |
|  | (In thousands, except per share data) |
| Total number of shares repurchased | 1,424 |  |  | 884 |  |  | 885 |  |
| Dollar amount of shares repurchased | $ | 50,021 |  |  | $ | 24,091 |  |  | $ | 20,962 |  |
| Average price paid per share | $ | 35.13 |  |  | $ | 27.24 |  |  | $ | 23.70 |  |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000926326-16-000044:notes:261]
SCHEDULE II

[0000926326-16-000044:notes:262]
VALUATION AND QUALIFYING ACCOUNTS

[0000926326-16-000044:notes:263]
|  |  |  | Additions |  |  |  |  |
|  | Balance atBeginning of Period (1) |  | Charged toCosts and Expenses (2) |  | Credited toOther Accounts (3) |  | AmountWritten Off (4) |  | Balance atEnd of Period (1) |
|  | (In thousands) |
| Year ended December 31, 2013 |  |  |  |  |  |  |  |  |  |
| Accounts receivable | $ | 722 |  |  | $ | 195 |  |  | $ | (67 | ) |  | $ | (360 | ) |  | $ | 490 |  |
| Investment in sales-type leases | 607 |  |  | 49 |  |  | — |  |  | (489 | ) |  | 167 |  |
| Total allowances deducted from assets | $ | 1,329 |  |  | $ | 244 |  |  | $ | (67 | ) |  | $ | (849 | ) |  | $ | 657 |  |
| Year ended December 31, 2014 |  |  |  |  |  |  |  |  |  |
| Accounts receivable | $ | 490 |  |  | $ | 941 |  |  | $ | (60 | ) |  | $ | (165 | ) |  | $ | 1,206 |  |
| Investment in sales-type leases | 167 |  |  | — |  |  | (5 | ) |  | — |  |  | 162 |  |
| Total allowances deducted from assets | $ | 657 |  |  | $ | 941 |  |  | $ | (65 | ) |  | $ | (165 | ) |  | $ | 1,368 |  |
| Year ended December 31, 2015 |  |  |  |  |  |  |  |  |  |
| Accounts receivable | $ | 1,206 |  |  | $ | 453 |  |  | $ | 28 |  |  | $ | (447 | ) |  | $ | 1,240 |  |
| Investment in sales-type leases | 162 |  |  | (99 | ) |  | 106 |  |  | — |  |  | 169 |  |
| Total allowances deducted from assets | $ | 1,368 |  |  | $ | 354 |  |  | $ | 134 |  |  | $ | (447 | ) |  | $ | 1,409 |  |

[0000926326-16-000044:notes:264]
__________________________________________________

[0000926326-16-000044:notes:265]
| (1) | Allowance for doubtful accounts. |

[0000926326-16-000044:notes:266]
| (2) | Represents amounts charged to bad debt expense. |

[0000926326-16-000044:notes:267]
| (3) | Represents amounts credited to bad debt expense. |

[0000926326-16-000044:notes:268]
| (4) | Represents amounts written-off, net of recoveries. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000926326-16-000044:notes:269]
Segment and Geographical Information

[0000926326-16-000044:notes:270]
Segment Information

[0000926326-16-000044:notes:271]
In the first quarter of 2015, the Company modified its segment presentation to reflect the changes in how its Chief Operating Decision Maker (“CODM”) reviews the segments and the overall business. With the increase in completed acquisitions in the last two years, the Company changed how the financial information was presented for CODM review to exclude general corporate-level costs that are not specific to either of the reporting segments when evaluating the operating results of each segment. Corporate-level costs include expenses related to executive management, finance and accounting, human resources, legal, training and development, and certain administrative expenses.

[0000926326-16-000044:notes:272]
The Company's CODM allocates resources and evaluates the performance of its segments using information about its revenues, gross profit and income from operations, excluding certain costs which are managed separately at the corporate level. The Company enhanced its segment reporting structure to match its operating structure based on how its CODM views the business and allocates resources, beginning in the first quarter of 2015. The Company's CODM is its Chief Executive Officer. The historical information presented has been retrospectively adjusted to reflect the modified segment reporting and conform to the current period presentation.

[0000926326-16-000044:notes:273]
The two operating segments, which are the same as the Company's two reportable segments, are as follows:

[0000926326-16-000044:notes:274]
Automation and Analytics

[0000926326-16-000044:notes:275]
The Automation and Analytics segment is organized around the design, manufacturing, selling and servicing of medication and supply dispensing systems, pharmacy inventory management systems, and related software. The Company's Automation and Analytics products are designed to enable its customers to enhance and improve the effectiveness of the medication-use process, the efficiency of the medical-surgical supply chain, overall patient care and clinical and financial outcomes of medical facilities. Through modular configuration and upgrades, the Company's systems can be tailored to specific customer needs. The acquired companies Mach4 and Avantec are included in the Automation and Analytics segment.

[0000926326-16-000044:notes:276]
Medication Adherence

[0000926326-16-000044:notes:277]
The Medication Adherence segment includes primarily the manufacturing and selling of consumable medication blister cards, packaging equipment and ancillary products and services. These products are used to manage medication administration outside of the hospital setting and include medication adherence products sold under the brand name MTS Medication Technologies ("MTS"), Surgichem Limited ("Surgichem"), and under the Omnicell and SureMed brands. MTS products consist of proprietary medication packaging systems and related products for use by institutional pharmacies servicing long-term care, and correctional facilities or retail pharmacies serving patients in their local communities.

[0000926326-16-000044:notes:278]
The historical information presented has been retrospectively adjusted to reflect the new segment reporting.

[0000926326-16-000044:notes:279]
Property and equipment, net is attributed to the geographic location in which it is located.


## us-gaap:SubsequentEventsTextBlock

[0000926326-16-000044:notes:280]
Subsequent Events

[0000926326-16-000044:notes:281]
Acquisition of Aesynt

[0000926326-16-000044:notes:282]
On January 5, 2016, the Company completed its acquisition of all of the membership interests of Aesynt Holding, L.P., Aesynt, Ltd. and Aesynt Coöperatief U.A. (collectively, “Aesynt”) pursuant to that certain securities purchase agreement dated as of October 29, 2015, by and among the Company, Omnicell International, Inc. and Aesynt (the “Securities Purchase Agreement”). The purchase price paid by the Company was approximately $275 million, including the repayment of Aesynt indebtedness and after adjustments provided for in the Securities Purchase Agreement. The acquisition was funded with cash-on-hand and borrowings under the Credit Agreement. The Company is in the process of evaluating the business combination accounting considerations, including the consideration transferred and the initial purchase price allocation.

[0000926326-16-000044:notes:283]
Execution of the Credit Agreement

[0000926326-16-000044:notes:284]
On January 5, 2016, the Company, as borrower, entered into a $400 million senior secured credit facility pursuant to a Credit Agreement, by and among the Company, the lenders from time to time party thereto, Wells Fargo Securities, LLC, as Sole Lead Arranger and Wells Fargo Bank, National Association, as administrative agent (the “Credit Agreement”). The Credit Agreement provides for (a) a five-year revolving credit facility of $200 million (the “Revolving Credit Facility”) and (b) a five-year $200 million term loan facility (the “Term Loan Facility” and together with the Revolving Credit Facility, the “Facilities”). In addition, the Credit Agreement includes a letter of credit sub-limit of up to $10 million and a swing line loan sub-limit of up to $10 million.

[0000926326-16-000044:notes:285]
On January 5, 2016, the Company borrowed the full $200 million under the Term Loan Facility and $55 million under the Revolving Credit Facility to complete the acquisition of all of the membership interests of Aesynt and to pay related fees and expenses. The Company expects to use future loans under the Revolving Credit Facility, if any, for general corporate purposes. The Credit Agreement replaces the Company’s existing Credit Agreement, dated as of September 25, 2013, by and among the Company, the lenders from time to time party thereto and Wells Fargo Bank, National Association, as administrative agent, as amended.

[0000926326-16-000044:notes:286]
Loans under the Facilities bear interest, at the Company’s option, at a rate equal to either (a) the LIBOR Rate, plus an applicable margin ranging from 1.50% to 2.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) LIBOR for an interest period of one month, plus an applicable margin ranging from 0.50% to 1.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the Credit Agreement). Undrawn commitments under the Revolving Credit Facility will be subject to a commitment fee ranging from 0.20% to 0.35% per annum based on the Company’s Consolidated Total Net Leverage Ratio on the average daily unused portion of the Revolving Credit Facility. A letter of credit participation fee ranging from 1.50% to 2.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio will accrue on the average daily amount of letter of credit exposure.

[0000926326-16-000044:notes:287]
The Company is permitted to make voluntary prepayments at any time without payment of a premium or penalty, except for any amounts relating to the LIBOR breakage indemnity described in the Credit Agreement. The Company is required to make mandatory prepayments under the Term Loan Facility with (a) net cash proceeds from any issuances of debt (other than certain permitted debt) and (b) net cash proceeds from certain asset dispositions (other than certain asset dispositions) and insurance and condemnation events (subject to reinvestment rights and certain other exceptions). Loans under the Term Loan Facility will amortize in quarterly installments, equal to 5% per annum of the original principal amount thereof during the first two years, which shall increase to 10% per annum during the third and fourth years, and 15% per annum during the fifth year, with the remaining balance payable on January 5, 2021. The Company is required to make mandatory prepayments under the Revolving Credit Facility if at any time the aggregate outstanding principal amount of loans together with the total amount of outstanding letters of credit exceed the aggregate commitments, with such mandatory prepayment to be equal to the amount of such excess.

[0000926326-16-000044:notes:288]
The Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends and other distributions. The Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum consolidated total leverage ratio and maintain a minimum fixed charge coverage ratio.

[0000926326-16-000044:notes:289]
Events of default under the Credit Agreement include: (a) the failure by the Company or any Credit Party (as such term is defined in the Credit Agreement) to timely make payments due under the Credit Agreement or the other loan documents; (b) misrepresentations or misstatements in any representation or warranty subject to materiality or material adverse effect qualifications by any Credit Party or subsidiary thereof when made; (c) the failure by any Credit Party to comply with the covenants under the Credit Agreement and other related agreements; (d) certain defaults under a specified amount of other indebtedness of the Company; (e) insolvency or bankruptcy-related events with respect to the Company or any of its subsidiaries; (f) certain judgments against the Company or any of its subsidiaries; (g) certain ERISA-related events; (h) the failure by the loan documents to create a valid and perfected security interest in any material portion of the collateral purported to be covered thereby; (i) any material provision of any loan document ceasing to be valid, binding and enforceable; (j) payment defaults and certain performance defaults under material contracts of the Company; and (k) the occurrence of a change in control. If one or more events of default occurs and continues, the administrative agent may, with the consent of the lenders holding a majority of the loans and commitments under the facilities, or will, at the request of such lenders, terminate the commitments of the lenders to make further loans and declare all of the obligations of the credit parties under the Credit Agreement to be immediately due and payable.

[0000926326-16-000044:notes:290]
The Company’s obligations under the Credit Agreement and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and the subsidiary guarantors’ assets. In connection with entering into the Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a collateral agreement and subsidiary guaranty agreement.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000926326-16-000044:notes:291]
Balance Sheet Components


## us-gaap:TreasuryStockTextBlock

[0000926326-16-000044:notes:292]
Stock Repurchases

[0000926326-16-000044:notes:293]
In August 2012, the Company's Board of Directors authorized a program (the "2012 Stock Repurchase Program") to repurchase up to $50.0 million of common stock, of which approximately $45.1 million had been repurchased as of December 31, 2014, and approximately $4.9 million had been repurchased during the second quarter of 2015 at which time the 2012 Stock Repurchase Program was concluded.

[0000926326-16-000044:notes:294]
In November 2014, the Company's Board of Directors authorized a program (the "2014 Stock Repurchase Program") to repurchase up to $50.0 million of common stock of which approximately $45.1 million had been repurchased as of December 31, 2015. The 2014 Stock Repurchase Program has a total of $4.9 million remaining for future repurchases as of December 31, 2015, and the program has no expiration date.
