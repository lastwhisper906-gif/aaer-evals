# OMCL 8-K — 0000926326-16-000041 filed 2016-02-04

## item codes, every 8-K on or before 2016-02-26

- 2016-02-10 0001104659-16-095486 — 5.02, 9.01
- 2016-02-04 0000926326-16-000041 — 2.02, 9.01
- 2016-01-06 0001104659-16-088299 — 1.01, 2.01, 2.03, 9.01
- 2015-12-10 0000926326-15-000038 — 8.01, 9.01
- 2015-10-29 0001104659-15-074138 — 1.01, 9.01
- 2015-10-29 0000926326-15-000031 — 2.02, 9.01
- 2015-08-20 0001104659-15-061135 — 5.02, 9.01
- 2015-07-30 0000926326-15-000024 — 2.02, 9.01
- 2015-05-22 0001104659-15-040440 — 5.07
- 2015-05-01 0001104659-15-032846 — 5.02
- 2015-05-01 0001104659-15-032844 — 7.01
- 2015-04-30 0000926326-15-000015 — 9.01
- 2015-04-22 0001104659-15-029356 — 8.01, 9.01
- 2015-03-20 0001104659-15-021435 — 3.01
- 2015-03-18 0001104659-15-020699 — 7.01
- 2015-03-17 0001104659-15-020483 — 8.01, 9.01
- 2015-03-02 0001104659-15-015802 — 1.01, 9.01
- 2015-02-12 0001104659-15-009234 — 5.02, 9.01
- 2015-02-03 0000926326-15-000003 — 9.01
- 2015-01-15 0001104659-15-002635 — 5.02
- 2014-11-07 0001104659-14-078398 — 1.01, 8.01, 9.01
- 2014-10-30 0000926326-14-000037 — 2.02, 9.01
- 2014-08-25 0001104659-14-062772 — 8.01, 9.01
- 2014-07-31 0000926326-14-000032 — 2.02, 9.01
- 2014-05-21 0001104659-14-040744 — 5.07
- 2014-05-01 0000926326-14-000008 — 2.02, 9.01
- 2014-04-08 0001104659-14-026441 — 4.01, 9.01
- 2014-04-02 0001104659-14-025179 — 5.02
- 2014-02-07 0001104659-14-007552 — 5.02, 9.01
- 2014-02-04 0001104659-14-006352 — 2.02, 9.01
- 2013-12-09 0001104659-13-088980 — 1.01, 9.01
- 2013-12-02 0001104659-13-087877 — 5.02
- 2013-10-31 0001104659-13-079660 — 2.02, 9.01
- 2013-09-26 0001104659-13-072435 — 1.01, 2.03, 9.01
- 2013-08-01 0001104659-13-058959 — 2.02, 9.01
- 2013-05-23 0001104659-13-044317 — 5.07
- 2013-05-02 0001104659-13-036605 — 2.02, 9.01
- 2013-03-11 0001104659-13-019143 — 8.01
- 2013-02-07 0001104659-13-008477 — 5.02, 9.01
- 2013-01-31 0001104659-13-006446 — 2.02, 9.01
- 2012-11-02 0001104659-12-073697 — 5.02
- 2012-10-25 0001104659-12-071211 — 2.02, 9.01
- 2012-08-06 0001104659-12-054635 — 8.01
- 2012-08-03 0001104659-12-054214 — 2.01, 9.01 — amendment of 0001104659-12-038888
- 2012-08-01 0001104659-12-053005 — 2.02, 9.01
- 2012-06-12 0001104659-12-042936 — 8.01, 9.01
- 2012-05-23 0001104659-12-039459 — 5.07
- 2012-05-22 0001104659-12-038888 — 2.01, 9.01
- 2012-05-02 0001104659-12-032048 — 2.02, 9.01
- 2012-05-02 0001104659-12-032036 — 1.01, 9.01
- 2012-04-04 0001104659-12-023883 — 5.02, 8.01
- 2012-03-20 0001104659-12-019462 — 1.01, 9.01
- 2012-02-13 0001104659-12-009353 — 5.02, 9.01
- 2012-01-26 0001104659-12-004244 — 2.02, 9.01
- 2011-10-27 0001104659-11-058464 — 2.02, 9.01
- 2011-10-25 0001104659-11-057721 — 1.01
- 2011-07-28 0001104659-11-041505 — 2.02, 9.01
- 2011-05-27 0001104659-11-032006 — 5.07
- 2011-05-02 0001104659-11-024908 — 2.02, 9.01
- 2011-04-15 0001104659-11-020407 — 5.02, 9.01 — amendment of 0001104659-11-005638
- 2011-02-08 0001104659-11-005638 — 5.02, 9.01
- 2011-01-27 0001104659-11-003419 — 2.02, 9.01
- 2010-12-22 0001104659-10-064003 — 5.02, 5.07, 9.01
- 2010-10-27 0001104659-10-054036 — 2.02, 9.01
- 2010-10-05 0001104659-10-051173 — 8.01
- 2010-07-22 0001104659-10-039126 — 2.02, 9.01
- 2010-07-09 0001104659-10-037594 — 2.05
- 2010-05-28 0001104659-10-031607 — 5.07
- 2010-04-26 0001104659-10-021797 — 2.02, 9.01
- 2010-03-17 0001104659-10-014849 — 5.02, 9.01
- 2010-02-08 0001104659-10-005457 — 5.02, 9.01
- 2010-01-28 0001104659-10-003627 — 2.02, 9.01
- 2009-10-22 0001104659-09-059972 — 2.02, 9.01
- 2009-07-23 0001104659-09-044508 — 2.02, 9.01
- 2009-05-20 0001104659-09-033938 — 5.02, 9.01
- 2009-04-30 0001104659-09-027707 — 2.02, 9.01
- 2009-03-10 0001104659-09-016178 — 5.02, 9.01
- 2009-02-09 0001104659-09-007692 — 5.02, 9.01
- 2009-01-29 0001104659-09-005022 — 2.02, 2.05, 9.01
- 2009-01-21 0001104659-09-003180 — 2.02, 8.01, 9.01
- 2009-01-06 0001104659-09-000625 — 5.02
- 2008-10-23 0001104659-08-065475 — 2.02, 9.01
- 2008-07-21 0001104659-08-046690 — 2.02, 9.01
- 2008-05-16 0001104659-08-034035 — 8.01, 9.01
- 2008-04-28 0001104659-08-027379 — 7.01, 9.01
- 2008-04-21 0001104659-08-025616 — 2.02, 9.01
- 2008-03-12 0001104659-08-016939 — 7.01, 9.01
- 2008-02-26 0001104659-08-012840 — 7.01, 9.01
- 2008-02-12 0001104659-08-009382 — 5.02, 9.01
- 2008-01-31 0001104659-08-006199 — 2.02, 9.01
- 2007-12-05 0001104659-07-087191 — 1.01, 9.01
- 2007-10-18 0001104659-07-075654 — 2.02, 9.01
- 2007-07-27 0001104659-07-056886 — 5.03, 9.01
- 2007-07-19 0001104659-07-054924 — 2.02, 9.01
- 2007-05-23 0001104659-07-042287 — 8.01, 9.01
- 2007-05-07 0001104659-07-036172 — 1.01, 5.02, 9.01
- 2007-04-24 0001104659-07-030578 — 2.02, 9.01 — amendment, the index does not say of what
- 2007-04-24 0001104659-07-030547 — 2.02, 9.01
- 2007-04-10 0001104659-07-027465 — 5.02, 9.01
- 2007-03-23 0001104659-07-021969 — 2.02, 4.02, 9.01
- 2007-01-30 0001104659-07-005772 — 2.02, 9.01
- 2007-01-09 0001104659-07-001600 — 5.02, 9.01
- 2006-10-30 0001104659-06-069612 — 1.01
- 2006-10-19 0001104659-06-067549 — 2.02, 9.01
- 2006-07-20 0001104659-06-048020 — 2.02, 4.02, 9.01
- 2006-05-17 0001104659-06-035522 — 1.01, 9.01 — amendment of 0001104659-05-011155
- 2006-05-09 0001104659-06-032706 — 1.01, 9.01
- 2006-04-25 0001104659-06-027438 — 2.02, 9.01
- 2006-04-04 0001104659-06-022204 — 1.01, 9.01
- 2006-03-15 0001104659-06-016861 — 1.01, 9.01
- 2006-01-30 0001104659-06-004749 — 2.02, 9.01
- 2006-01-24 0001104659-06-003504 — 1.01, 5.02, 9.01
- 2005-12-13 0001104659-05-060532 — 1.01, 9.01
- 2005-11-10 0001104659-05-054663 — 2.02, 9.01
- 2005-07-21 0001104659-05-033464 — 2.02, 9.01
- 2005-06-22 0001104659-05-029255 — 1.01
- 2005-05-16 0001104659-05-023473 — 2.02, 9.01 — amendment of 0001104659-05-018173
- 2005-05-16 0001104659-05-023471 — 2.02, 9.01 — amendment of 0001104659-05-017382
- 2005-05-10 0001104659-05-022127 — 1.01
- 2005-04-26 0001104659-05-018173 — 2.02, 9.01
- 2005-04-21 0001104659-05-017382 — 2.02, 9.01
- 2005-04-06 0001104659-05-015401 — 5.02
- 2005-03-15 0001104659-05-011155 — 1.01, 9.01
- 2005-03-08 0001104659-05-009975 — 1.01, 9.01
- 2005-02-03 0001104659-05-003943 — 2.02, 9.01
- 2005-01-13 0001104659-05-001314 — 5.02, 9.01
- 2004-10-21 0001104659-04-031413 — 2.02, 9.01
- 2004-07-22 0001104659-04-020572 — 12, 7
- 2004-04-14 0001104659-04-010039 — 12, 7
- 2004-04-05 0001104659-04-009437 — 12, 7
- 2004-01-26 0001104659-04-001655 — 12, 7
- 2003-10-16 0001104659-03-022990 — 12, 7
- 2003-07-17 0001104659-03-015053 — 9
- 2003-04-18 0001104659-03-006823 — 7, 9
- 2003-02-14 0001104659-03-002607 — 5, 7

## late-filing notifications on or before 2016-02-26

- 2015-03-02 0000926326-15-000006 — NT 10-K, for the period ended 2014-12-31
- 2007-03-16 0001104659-07-020094 — NT 10-K, for the period ended 2006-12-31

## item 2.02 — earnings release, exhibit 99.1

[0000926326-16-000041:8k_2_02:1]
EX-99.1
2
exhibit991q415.htm
EXHIBIT 99.1

[0000926326-16-000041:8k_2_02:2]
Exhibit

[0000926326-16-000041:8k_2_02:3]
Exhibit 99.1

[0000926326-16-000041:8k_2_02:4]
| Contact: |  |  |
| Peter Kuipers |  | Omnicell, Inc. |
| Chief Financial Officer |  | 590 East Middlefield Road |
| 800-850-6664, ext. 6180 |  | Mountain View, CA 94043 |
| Peter.kuipers@omnicell.com |  |  |

[0000926326-16-000041:8k_2_02:5]
Omnicell Reports Earnings for Fiscal Year and Fourth Quarter 2015

[0000926326-16-000041:8k_2_02:6]
Record quarterly revenue of $130.3 million, representing 7.2% year over year growth

[0000926326-16-000041:8k_2_02:7]
Record yearly revenue of $484.6 million, representing 9.9% year over year growth

[0000926326-16-000041:8k_2_02:8]
Record quarterly Non-GAAP diluted EPS of $0.40, representing 11.1% quarter over quarter growth

[0000926326-16-000041:8k_2_02:9]
MOUNTAIN VIEW, Calif. -- February 4, 2016 -- Omnicell, Inc. (NASDAQ: OMCL), a leading provider of medication and supply management solutions to healthcare systems, today announced results for its fiscal year and fourth quarter ended December 31, 2015.

[0000926326-16-000041:8k_2_02:10]
GAAP results: Revenue for the fourth quarter of 2015 was $130.3 million, up $5.1 million or 4.1% from the third quarter of 2015, and up $8.8 million or 7.2% from the fourth quarter of 2014. Revenue for the year ended December 31, 2015 was $484.6 million, up $43.7 million or 9.9% from the year ended December 31, 2014.

[0000926326-16-000041:8k_2_02:11]
Fourth quarter 2015 net income as reported in accordance with U.S. generally accepted accounting principles (GAAP) was $7.7 million, or $0.21 per diluted share. This compares to GAAP net income of $8.0 million, or $0.22 per diluted share, for the third quarter of 2015, and GAAP net income of $9.2 million, or $0.25 per diluted share, for the fourth quarter of 2014.

[0000926326-16-000041:8k_2_02:12]
GAAP net income for the year ended December 31, 2015 was $30.8 million, or $0.84 per diluted share, which includes a $3.4 million gain on business combination of an equity investment. GAAP net income was $30.5 million, or $0.83 per diluted share, for the year ended December 31, 2014.

[0000926326-16-000041:8k_2_02:13]
Non-GAAP results: Non-GAAP net income for the fourth quarter of 2015 was $14.4 million, or $0.40 per diluted share, excluding $3.7 million of stock-based compensation expense, $1.2 million, net of tax effect of $0.7 million, of amortization expense for all intangible assets associated with past acquisitions and $2.0 million, net of tax effect of $0.9 million, of acquisition expenses associated with the Aesynt acquisition. This compares to non-GAAP net income of $14.3 million, or $0.39 per diluted share, for the fourth quarter of 2014. Non-GAAP net income for the fourth quarter of 2014 excluded $4.2 million of stock-based compensation expense and $0.9 million, net of tax effect of $0.4 million, of amortization expense for all intangible assets associated with past acquisitions. Fourth quarter 2015 results compare to non-GAAP net income of $13.2 million, or $0.36 per diluted share, for the third quarter of 2015. Non-GAAP net income for the third quarter of 2015 excludes $4.0 million of stock-based compensation expense and $1.2 million, net of tax effect of $0.8 million, of amortization expense for all intangible assets associated with past acquisitions.

[0000926326-16-000041:8k_2_02:14]
Non-GAAP net income for the year ended December 31, 2015 was $48.7 million, or $1.33 per diluted share. Non-GAAP net income for the year ended December 31, 2015 excludes $14.9 million of stock-based compensation expense, $4.5 million, net of tax effect of $2.4 million of amortization expense for all intangible assets associated with past acquisitions and $2.0 million net of tax effect of $0.9 million, of acquisition expenses associated with the Aesynt acquisition. Non-GAAP net income for the year ended December 31, 2015 also excludes a $3.4 million gain on business combination of an equity investment in Avantec. Non-GAAP net income for the year ended December 31, 2014 was $46.1 million, or $1.26 per diluted share, excluding $12.8 million of stock-based compensation expense and $2.8 million, net of tax effect of $1.7 million of amortization expense for all intangible assets associated with our business acquisitions.

[0000926326-16-000041:8k_2_02:15]
Total bookings for the year ended December 31, 2015 were $392.3 million and total bookings for the year ended December 31, 2014 were $364.0 million.

[0000926326-16-000041:8k_2_02:16]
“I am pleased with the company’s performance and our consistent track record,” said Randall Lipps, Omnicell president, chairman and CEO. “For eleven consecutive years we have increased our market share and gained new thought leading customers every quarter. Together with our customers, we are consistently delivering state of the art medication management and workflow efficiency for caregivers and better healthcare for patients. These record-setting results provide great momentum for us in 2016.”

[0000926326-16-000041:8k_2_02:17]
2016 Guidance:

[0000926326-16-000041:8k_2_02:18]
The guidance is inclusive of the recently acquired Aesynt business:

[0000926326-16-000041:8k_2_02:19]
For the year 2016, we project product bookings to be between $540 and $560 million, revenue to be between $695 and $715 million. We expect non-GAAP earnings to be between $1.50 and $1.60 per share, and non-GAAP operating margins to be approximately 12.7%. For the year 2016 expected non-GAAP results include approximately $10 million of integration expenses, primarily related to our acquisition of Aesynt, and approximately $6 million of interest expense related to the loan facility used to finance the Aesynt acquisition. We expect our annual effective tax rate to be 38% of GAAP earnings.

[0000926326-16-000041:8k_2_02:20]
For the first quarter of 2016 we expect revenue to be between $165 and $170 million and expected Non-GAAP EPS to be between $0.25 and $0.28 per share.

[0000926326-16-000041:8k_2_02:21]
Reporting Segments

[0000926326-16-000041:8k_2_02:22]
As previously reported, beginning the first quarter of 2015, Omnicell enhanced the management of its business, operating structure and segment reporting structure by excluding certain corporate-level costs from our reporting segments based on how the Chief Operating Decision Maker (“CODM”) reviews the business. Corporate-level costs may include expenses related to executive management, finance and accounting, human resources, legal, training and development, and certain administrative expenses. Omnicell's CODM allocates resources and evaluates the performance of our segments using information about its revenues, gross profit and income from operations, excluding certain costs which are managed separately at the corporate level.

[0000926326-16-000041:8k_2_02:23]
Omnicell Conference Call Information

[0000926326-16-000041:8k_2_02:24]
Omnicell will hold a conference call today, Thursday, February 4, 2016 at 2:30 p.m. PT to discuss fourth quarter financial results. The conference call can be monitored by dialing 1-800-696-5518 within the U.S. or 1-706-758-4883 for all other locations. The Conference ID # is 27500940. Internet users can access the conference call at http://ir.omnicell.com/events.cfm. A replay of the call will be available today at approximately 5:30 p.m. PT and will be available until 11:59 p.m. PT on February 18, 2016. The replay access numbers are 1-855-859-2056 within the U.S. and 1-404-537-3406 for all other locations, Conference ID # is 27500940.

[0000926326-16-000041:8k_2_02:25]
About Omnicell

[0000926326-16-000041:8k_2_02:26]
Since 1992, Omnicell (NASDAQ: OMCL) has been creating innovative solutions to improve patient care, anywhere it is delivered. Omnicell is a leading supplier of comprehensive automation and business analytics software for medication and supply management across the entire health care continuum—from the acute care hospital setting, to post-acute skilled nursing and long-term care facilities, to the patient's home.

[0000926326-16-000041:8k_2_02:27]
Approximately 4,000 customers worldwide use Omnicell automation and analytics solutions to increase operational efficiency, reduce medication errors, deliver actionable intelligence and improve patient safety. The recent acquisition of Aesynt adds distinct capabilities, particularly in central pharmacy and IV robotics, creating the broadest medication management product portfolio in the industry.

[0000926326-16-000041:8k_2_02:28]
The Omnicell SureMed solution provides innovative medication adherence packaging to help reduce costly hospital readmissions. In addition, these solutions enable approximately 7,000 institutional and retail pharmacies worldwide to maintain high accuracy and quality standards in medication dispensing and administration while optimizing productivity and controlling costs.

[0000926326-16-000041:8k_2_02:29]
For more information about Omnicell, Inc. please visit www.omnicell.com.

[0000926326-16-000041:8k_2_02:30]
Forward-Looking Statements

[0000926326-16-000041:8k_2_02:31]
Use of Non-GAAP Financial Information

[0000926326-16-000041:8k_2_02:32]
This press release contains financial measures that are not calculated in accordance with U.S. generally accepted accounting principles (GAAP). Our management evaluates and makes operating decisions using various performance measures. In addition to Omnicell’s GAAP results, we also consider non-GAAP gross profit, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP net income, and non-GAAP net income per diluted share. Additionally, we calculate Adjusted EBITDA (another non-GAAP measure) by means of adjustments to GAAP Net Income. These non-GAAP results should not be considered as an alternative to gross profit, operating expenses, net income, net income per diluted share, or any other performance measure derived in accordance with GAAP. We present these non-GAAP results because we consider them to be important supplemental measures of Omnicell’s performance.

[0000926326-16-000041:8k_2_02:33]
Our non-GAAP gross profit, non-GAAP operating expenses, non-GAAP net income and non-GAAP net income per diluted share are exclusive of certain items to facilitate management’s review of the comparability of Omnicell’s core operating results on a period to period basis because such items are not related to Omnicell’s ongoing core operating results as viewed by management. We define our “core operating results” as those revenues recorded in a particular period and the expenses incurred within that period that directly drive operating income in that period. Management uses these non-GAAP financial measures in making operating decisions because, in addition to meaningful supplemental information regarding operating performance, the measures give us a better understanding of how we should invest in research and development, fund infrastructure growth and evaluate the effectiveness of marketing strategies. In calculating the above non-GAAP results, management specifically adjusted for the following excluded items:

[0000926326-16-000041:8k_2_02:34]
a)  Stock-based compensation expense impact of Accounting Standards Codification (ASC) 718. We recognize equity plan-related compensation expenses, which represent the fair value of all share-based payments to employees, including grants of employee stock options, as required under ASC 718, Compensation - Stock Compensation (ASC 718) as non-GAAP adjustments in each period.

[0000926326-16-000041:8k_2_02:35]
b) Intangible assets amortization from business acquisitions. We excluded from our non-GAAP results the intangible assets amortization expense resulting from our past acquisitions. These non-cash charges are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results.

[0000926326-16-000041:8k_2_02:36]
c) Acquisitions related expenses. We excluded from our non-GAAP results the expenses which are related to the recent acquisitions. These expenses are unrelated to our ongoing operations and we do not expect them to occur in the ordinary course of business. We believe that excluding these acquisition related expenses provides more meaningful comparisons of the financial results to our historical operations and forward looking guidance and the financial results of less acquisitive peer companies. Further, these expenses are not considered by management to reflect the core performance of the business and therefore are excluded from our non-GAAP results.

[0000926326-16-000041:8k_2_02:37]
d) Gain on business combination of an equity investment. We excluded from our non-GAAP results the gain on a minority equity investment in a private company, Avantec, which was recognized in relation to the acquisition by Omnicell of the remainder of the company. This non-cash gain is not considered by management to reflect the core cash-generating performance of the business and therefore is excluded from our non-GAAP results.

[0000926326-16-000041:8k_2_02:38]
Management adjusts for the above items because management believes that, in general, these items possess one or more of the following characteristics: their magnitude and timing is largely outside of Omnicell’s control; they are unrelated to the ongoing operation of the business in the ordinary course; they are unusual and we do not expect them to occur in the ordinary course of business; or they are non-operational, or non-cash expenses involving stock compensation plans.

[0000926326-16-000041:8k_2_02:39]
We believe that the presentation of these non-GAAP financial measures is warranted for several reasons:

[0000926326-16-000041:8k_2_02:40]
1) Such non-GAAP financial measures provide an additional analytical tool for understanding Omnicell’s financial performance by excluding the impact of items which may obscure trends in the core operating results of the business;

[0000926326-16-000041:8k_2_02:41]
2) Since we have historically reported non-GAAP results to the investment community, we believe the inclusion of non-GAAP numbers provides consistency and enhances investors’ ability to compare our performance across financial reporting periods;

[0000926326-16-000041:8k_2_02:42]
3) These non-GAAP financial measures are employed by Omnicell’s management in its own evaluation of performance and are utilized in financial and operational decision making processes, such as budget planning and forecasting; and

[0000926326-16-000041:8k_2_02:43]
4) These non-GAAP financial measures facilitate comparisons to the operating results of other companies in our industry, which use similar financial measures to supplement their GAAP results, thus enhancing the perspective of investors who wish to utilize such comparisons in their analysis of our performance.

[0000926326-16-000041:8k_2_02:44]
Set forth below are additional reasons why share-based compensation expense related to ASC 718 is excluded from our non-GAAP financial measures:

[0000926326-16-000041:8k_2_02:45]
i)  While share-based compensation calculated in accordance with ASC 718 constitutes an ongoing and recurring expense of Omnicell, it is not an expense that requires cash settlement by Omnicell. We therefore exclude these charges for purposes of evaluating core operating results. Thus, our non-GAAP measurements are presented exclusive of stock-based compensation expense to assist management and investors in evaluating our core operating results.

[0000926326-16-000041:8k_2_02:46]
ii)  We present ASC 718 share-based compensation expense in our reconciliation of non-GAAP financial measures on a pre-tax basis because the exact tax differences related to the timing and deductibility of share-based compensation, under ASC 718 are dependent upon the trading price of Omnicell’s common stock and the timing and exercise by employees of their stock options. As a result of these timing and market uncertainties the tax effect related to share-based compensation expense would be inconsistent in amount and frequency and is therefore excluded from our non-GAAP results.

[0000926326-16-000041:8k_2_02:47]
Our Adjusted EBITDA calculation is defined as earnings before interest income and expense, taxes, depreciation and amortization, and non-cash expenses, including ASC 718 stock compensation expense, as well as excluding certain other non-GAAP adjustments.

[0000926326-16-000041:8k_2_02:48]
As stated above, we present non-GAAP financial measures because we consider them to be important supplemental measures of performance. However, non-GAAP financial measures have limitations as an analytical tool and should not be considered in isolation or as a substitute for Omnicell’s GAAP results. In the future, we expect to incur expenses similar to certain of the non-GAAP adjustments described above and expect to continue reporting non-GAAP financial measures excluding such items. Some of the limitations in relying on non-GAAP financial measures are:

[0000926326-16-000041:8k_2_02:49]
·  Omnicell’s stock option and stock purchase plans are important components of incentive compensation arrangements and will be reflected as expenses in Omnicell’s GAAP results for the foreseeable future under ASC 718.

[0000926326-16-000041:8k_2_02:50]
·  Other companies, including companies in Omnicell’s industry, may calculate non-GAAP financial measures differently than Omnicell, limiting their usefulness as a comparative measure.

[0000926326-16-000041:8k_2_02:51]
Pursuant to the requirements of SEC Regulation G, a detailed reconciliation between Omnicell’s non-GAAP and GAAP financial results is set forth in the financial tables at the end of this press release. Investors are advised to carefully review and consider this information strictly as a supplement to the GAAP results that are contained in this press release and in Omnicell’s SEC filings.

[0000926326-16-000041:8k_2_02:52]
Omnicell, Inc.

[0000926326-16-000041:8k_2_02:53]
Condensed Consolidated Statements of Operations

[0000926326-16-000041:8k_2_02:54]
(Unaudited, in thousands, except per share data)

[0000926326-16-000041:8k_2_02:55]
|  | Three Months Ended |  | Years Ended |
|  | December 31, 2015 |  | September 30, 2015 |  | December 31, 2014 |  | December 31, 2015 |  | December 31, 2014 |
| Revenues: |  |  |  |  |  |  |  |  |  |
| Product | $ | 104,193 |  |  | $ | 100,941 |  |  | $ | 100,291 |  |  | $ | 388,397 |  |  | $ | 360,344 |  |
| Services and other revenues | 26,123 |  |  | 24,293 |  |  | 21,250 |  |  | 96,162 |  |  | 80,556 |  |
| Total revenues | 130,316 |  |  | 125,234 |  |  | 121,541 |  |  | 484,559 |  |  | 440,900 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |
| Cost of product revenues | 55,099 |  |  | 51,700 |  |  | 49,005 |  |  | 198,418 |  |  | 173,419 |  |
| Cost of services and other revenues | 10,137 |  |  | 9,831 |  |  | 8,757 |  |  | 38,211 |  |  | 33,621 |  |
| Total cost of revenues | 65,236 |  |  | 61,531 |  |  | 57,762 |  |  | 236,629 |  |  | 207,040 |  |
| Gross profit | 65,080 |  |  | 63,703 |  |  | 63,779 |  |  | 247,930 |  |  | 233,860 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | 9,219 |  |  | 9,176 |  |  | 8,132 |  |  | 35,160 |  |  | 27,802 |  |
| Selling, general and administrative | 43,891 |  |  | 40,668 |  |  | 42,173 |  |  | 167,581 |  |  | 156,475 |  |
| Gain on business combination | — |  |  | — |  |  | — |  |  | (3,443 | ) |  | — |  |
| Total operating expenses | 53,110 |  |  | 49,844 |  |  | 50,305 |  |  | 199,298 |  |  | 184,277 |  |
| Income from operations | 11,970 |  |  | 13,859 |  |  | 13,474 |  |  | 48,632 |  |  | 49,583 |  |
| Interest and other income (expense), net | (753 | ) |  | (646 | ) |  | (77 | ) |  | (2,388 | ) |  | (1,079 | ) |
| Income before provision for income taxes | 11,217 |  |  | 13,213 |  |  | 13,397 |  |  | 46,244 |  |  | 48,504 |  |
| Provision for income taxes | 3,562 |  |  | 5,177 |  |  | 4,162 |  |  | 15,484 |  |  | 17,986 |  |
| Net income | $ | 7,655 |  |  | $ | 8,036 |  |  | $ | 9,235 |  |  | $ | 30,760 |  |  | $ | 30,518 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |
| Basic | $ | 0.22 |  |  | $ | 0.22 |  |  | $ | 0.26 |  |  | $ | 0.86 |  |  | $ | 0.86 |  |
| Diluted | $ | 0.21 |  |  | $ | 0.22 |  |  | $ | 0.25 |  |  | $ | 0.84 |  |  | $ | 0.83 |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |  |  |
| Basic | 35,482 |  |  | 35,806 |  |  | 35,697 |  |  | 35,857 |  |  | 35,650 |  |
| Diluted | 36,172 |  |  | 36,613 |  |  | 36,585 |  |  | 36,718 |  |  | 36,622 |  |

[0000926326-16-000041:8k_2_02:56]
5

[0000926326-16-000041:8k_2_02:57]
Omnicell, Inc.

[0000926326-16-000041:8k_2_02:58]
Condensed Consolidated Balance Sheets

[0000926326-16-000041:8k_2_02:59]
(Unaudited, in thousands)

[0000926326-16-000041:8k_2_02:60]
|  | December 31, 2015 |  | December 31, 2014 |
| ASSETS |
| Current assets: |  |  |  |  |
| Cash and cash equivalents | $ | 82,217 |  |  | $ | 125,888 |  |
| Accounts receivable, net | 107,957 |  |  | 82,763 |  |
| Inventories | 46,594 |  |  | 31,554 |  |
| Prepaid expenses | 19,586 |  |  | 23,518 |  |
| Deferred tax assets* | — |  |  | 12,446 |  |
| Other current assets | 7,774 |  |  | 7,215 |  |
| Total current assets | 264,128 |  |  | 283,384 |  |
| Property and equipment, net | 32,309 |  |  | 36,178 |  |
| Long-term net investment in sales-type leases | 14,484 |  |  | 10,848 |  |
| Goodwill | 147,906 |  |  | 122,720 |  |
| Intangible assets, net | 89,665 |  |  | 82,667 |  |
| Long-term deferred tax assets | 2,361 |  |  | 1,144 |  |
| Other long-term assets | 27,894 |  |  | 23,273 |  |
| Total assets | $ | 578,747 |  |  | $ | 560,214 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |
| Accounts payable | $ | 22,646 |  |  | $ | 19,432 |  |
| Accrued compensation | 18,195 |  |  | 19,874 |  |
| Accrued liabilities | 30,133 |  |  | 19,299 |  |
| Deferred service revenue | 27,948 |  |  | 25,167 |  |
| Deferred gross profit | 25,708 |  |  | 28,558 |  |
| Total current liabilities | 124,630 |  |  | 112,330 |  |
| Deferred service revenue, long-term | 17,975 |  |  | 20,308 |  |
| Long-term deferred tax liabilities | 21,822 |  |  | 30,454 |  |
| Other long-term liabilities | 11,932 |  |  | 7,024 |  |
| Total liabilities | 176,359 |  |  | 170,116 |  |
| Stockholders’ equity: |  |  |  |  |  |
| Total stockholders’ equity | 402,388 |  |  | 390,098 |  |
| Total liabilities and stockholders’ equity | $ | 578,747 |  |  | $ | 560,214 |  |

[0000926326-16-000041:8k_2_02:61]
* In Q4 2015, the Company prospectively adopted ASU No. 2015-17, which required the reclassification of deferred tax assets and liabilities from current to non-current on its Consolidated Balance Sheets.

[0000926326-16-000041:8k_2_02:62]
Omnicell, Inc.

[0000926326-16-000041:8k_2_02:63]
Condensed Consolidated Statements of Cash Flows

[0000926326-16-000041:8k_2_02:64]
(Unaudited, in thousands)

[0000926326-16-000041:8k_2_02:65]
|  | Years Ended |
|  | 2015 |  | 2014 |
| Operating Activities |  |  |  |
| Net income | $ | 30,760 |  |  | $ | 30,518 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 25,639 |  |  | 20,272 |  |
| Loss on disposal of fixed assets | 238 |  |  | 167 |  |
| Impairment of equity investments | — |  |  | 350 |  |
| Gain on business combination | (3,443 | ) |  | — |  |
| Provision for receivable allowance | 354 |  |  | 941 |  |
| Share-based compensation expense | 14,921 |  |  | 12,785 |  |
| Income tax benefits from employee stock plans | 4,535 |  |  | 5,370 |  |
| Excess tax benefits from employee stock plans | (4,724 | ) |  | (5,834 | ) |
| Provision for excess and obsolete inventories | 369 |  |  | 542 |  |
| Deferred income taxes | (1,092 | ) |  | 1,402 |  |
| Changes in operating assets and liabilities: | — |  |  | — |  |
| Accounts receivable, net | (18,295 | ) |  | (22,799 | ) |
| Inventories | (10,401 | ) |  | 1,418 |  |
| Prepaid expenses | 4,049 |  |  | (4,296 | ) |
| Other current assets | 638 |  |  | 53 |  |
| Net investment in sales-type leases | (4,661 | ) |  | 1,048 |  |
| Other long-term assets | 496 |  |  | 297 |  |
| Accounts payable | (2,841 | ) |  | 1,611 |  |
| Accrued compensation | (2,032 | ) |  | 270 |  |
| Accrued liabilities | 5,456 |  |  | 5,512 |  |
| Deferred service revenue | (2,880 | ) |  | 5,086 |  |
| Deferred gross profit | (2,641 | ) |  | 8,601 |  |
| Other long-term liabilities | (683 | ) |  | 1,849 |  |
| Net cash provided by operating activities | 33,762 |  |  | 65,163 |  |
| Investing Activities |  |  |  |
| Acquisition of intangible assets, intellectual property and patents | (415 | ) |  | (327 | ) |
| Software development for external use | (12,132 | ) |  | (10,353 | ) |
| Purchases of property and equipment | (7,542 | ) |  | (11,922 | ) |
| Business acquisition, net of cash acquired | (25,507 | ) |  | (20,723 | ) |
| Net cash used in investing activities | (45,596 | ) |  | (43,325 | ) |
| Financing Activities |  |  |  |
| Proceeds from issuances under stock-based compensation plans | 17,091 |  |  | 21,795 |  |
| Employees' taxes paid related to restricted stock units | (3,627 | ) |  | (3,744 | ) |
| Common stock repurchases | (50,021 | ) |  | (24,091 | ) |
| Excess tax benefits from employee stock plans | 4,724 |  |  | 5,834 |  |
| Net cash used in financing activities | (31,833 | ) |  | (206 | ) |
| Effect of exchange rate changes on cash and cash equivalents | (4 | ) |  | (275 | ) |
| Net (decrease) increase in cash and cash equivalents | (43,671 | ) |  | 21,357 |  |
| Cash and cash equivalents at beginning of period | 125,888 |  |  | 104,531 |  |
| Cash and cash equivalents at end of period | $ | 82,217 |  |  | $ | 125,888 |  |

[0000926326-16-000041:8k_2_02:66]
7

[0000926326-16-000041:8k_2_02:67]
Omnicell, Inc.

[0000926326-16-000041:8k_2_02:68]
Reconciliation of GAAP to Non-GAAP

[0000926326-16-000041:8k_2_02:69]
(Unaudited, in thousands, except per share data and percentages)

[0000926326-16-000041:8k_2_02:70]
|  |  |  |  |  |  | Three Months Ended |  | Years Ended |
|  |  |  |  |  |  | December 31, 2015 |  | September 30, 2015 |  | December 31, 2014 |  | December 31, 2015 |  | December 31, 2014 |
| Reconciliation of GAAP net income to non-GAAP net income: |  |  |  |  |  |  |
| GAAP net income | $ | 7,655 |  |  | $ | 8,036 |  |  | $ | 9,235 |  |  | $ | 30,760 |  |  | $ | 30,518 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
|  | Share-based compensation expense: |  |  |  |  |  |  |  |  |  |
|  |  | Cost of revenues | 481 |  |  | 581 |  |  | 483 |  |  | 2,111 |  |  | 1,456 |  |
|  |  | Operating expenses | 3,173 |  |  | 3,385 |  |  | 3,692 |  |  | 12,810 |  |  | 11,329 |  |
|  |  | Total share-based compensation expense (a) | 3,654 |  |  | 3,966 |  |  | 4,175 |  |  | 14,921 |  |  | 12,785 |  |
|  | Amortization of acquired intangibles: |  |  |  |  |  |  |  |  |  |
|  |  | Cost of revenues | 547 |  |  | 570 |  |  | 368 |  |  | 2,016 |  |  | 1,472 |  |
|  |  | Operating expenses | 1,354 |  |  | 1,408 |  |  | 865 |  |  | 4,904 |  |  | 3,003 |  |
|  |  | Gross amortization of acquired intangibles: | 1,901 |  |  | 1,978 |  |  | 1,233 |  |  | 6,920 |  |  | 4,475 |  |
|  |  | Income tax effect (b) |  | (745 | ) |  | (775 | ) |  | (383 | ) |  | (2,448 | ) |  | (1,654 | ) |
|  |  | Amortization of acquired intangibles, net | 1,156 |  |  | 1,203 |  |  | 850 |  |  | 4,472 |  |  | 2,821 |  |
|  | Acquisition related expenses | 2,898 |  |  | — |  |  | — |  |  | 2,898 |  |  | — |  |
|  |  | Income tax effect (b) |  | (920 | ) |  | — |  |  | — |  |  | (920 | ) |  | — |  |
|  | Acquisition related expenses, net | 1,978 |  |  | — |  |  | — |  |  | 1,978 |  |  | — |  |
|  | Gain on business combination | — |  |  | — |  |  | — |  |  | (3,443 | ) |  | — |  |
| Non-GAAP net income | $ | 14,443 |  |  | $ | 13,205 |  |  | $ | 14,260 |  |  | $ | 48,688 |  |  | $ | 46,124 |  |
| Reconciliation of GAAP gross profit to non-GAAP gross profit: |  |  |  |  |  |  |
|  | Revenues |  | $ | 130,316 |  |  | $ | 125,234 |  |  | $ | 121,541 |  |  | $ | 484,559 |  |  | $ | 440,900 |  |
|  | GAAP gross profit | 65,080 |  |  | 63,703 |  |  | 63,779 |  |  | 247,930 |  |  | 233,860 |  |
|  | GAAP gross margin | 49.9% |  | 50.9% |  | 52.5% |  | 51.2% |  | 53.0% |
|  |  | Share-based compensation expense | 481 |  |  | 581 |  |  | 483 |  |  | 2,111 |  |  | 1,456 |  |
|  |  | Amortization of acquired intangibles | 547 |  |  | 570 |  |  | 368 |  |  | 2,016 |  |  | 1,472 |  |
|  | Non-GAAP gross profit | $ | 66,108 |  |  | $ | 64,854 |  |  | $ | 64,630 |  |  | $ | 252,057 |  |  | $ | 236,788 |  |
|  | Non-GAAP gross margin | 50.7% |  | 51.8% |  | 53.2% |  | 52.0% |  | 53.7% |
| Reconciliation of GAAP operating expenses to non-GAAP operating expenses: |  |  |  |  |
| GAAP operating expenses | $ | 53,110 |  |  | $ | 49,844 |  |  | $ | 50,305 |  |  | $ | 199,298 |  |  | $ | 184,277 |  |
|  | GAAP operating expenses % to total revenue | 40.8% |  | 39.8% |  | 41.4% |  | 41.1% |  | 41.8% |
|  | Share-based compensation expense | (3,173 | ) |  | (3,385 | ) |  | (3,692 | ) |  | (12,810 | ) |  | (11,329 | ) |
|  | Amortization of acquired intangibles | (1,354 | ) |  | (1,408 | ) |  | (865 | ) |  | (4,904 | ) |  | (3,003 | ) |
|  | Acquisition related expenses | (2,898 | ) |  | — |  |  | — |  |  | (2,898 | ) |  | — |  |
|  | Gain on business combination | — |  |  | — |  |  | — |  |  | 3,443 |  |  | — |  |
| Non-GAAP operating expenses | $ | 45,685 |  |  | $ | 45,051 |  |  | $ | 45,748 |  |  | $ | 182,129 |  |  | $ | 169,945 |  |
|  | Non-GAAP operating expenses % to total revenue | 35.1% |  | 36.0% |  | 37.6% |  | 37.6% |  | 38.5% |

[0000926326-16-000041:8k_2_02:71]
8

[0000926326-16-000041:8k_2_02:72]
|  |  |  |  |  |  | Three Months Ended |  | Years Ended |
|  |  |  |  |  |  | December 31, 2015 |  | September 30, 2015 |  | December 31, 2014 |  | December 31, 2015 |  | December 31, 2014 |
| Reconciliation of GAAP income from operations to non-GAAP income from operations: |  |  |  |  |
| GAAP income from operations | $ | 11,970 |  |  | $ | 13,859 |  |  | $ | 13,474 |  |  | $ | 48,632 |  |  | $ | 49,583 |  |
|  | GAAP operating income % to total revenue | 9.2% |  | 11.1% |  | 11.1% |  | 10.0% |  | 11.2% |
|  | Share-based compensation expense | 3,654 |  |  | 3,966 |  |  | 4,175 |  |  | 14,921 |  |  | 12,785 |  |
|  | Amortization of acquired intangibles | 1,901 |  |  | 1,978 |  |  | 1,233 |  |  | 6,920 |  |  | 4,475 |  |
|  | Acquisition related expenses | 2,898 |  |  | — |  |  | — |  |  | 2,898 |  |  | — |  |
|  | Gain on business combination | — |  |  | — |  |  | — |  |  | (3,443 | ) |  | — |  |
| Non-GAAP income from operations | $ | 20,423 |  |  | $ | 19,803 |  |  | $ | 18,882 |  |  | $ | 69,928 |  |  | $ | 66,843 |  |
|  | Non-GAAP operating income % to total revenue | 15.7% |  | 15.8% |  | 15.5% |  | 14.4% |  | 15.2% |
| GAAP shares - diluted | 36,172 |  |  | 36,613 |  |  | 36,585 |  |  | 36,718 |  |  | 36,622 |  |
| GAAP net income per share - diluted | $ | 0.21 |  |  | $ | 0.22 |  |  | $ | 0.25 |  |  | $ | 0.84 |  |  | $ | 0.83 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
|  | Share-based compensation expense | 0.11 |  |  | 0.11 |  |  | 0.12 |  |  | 0.41 |  |  | 0.35 |  |
|  | Amortization of acquired intangibles, net | 0.03 |  |  | 0.03 |  |  | 0.02 |  |  | 0.12 |  |  | 0.08 |  |
|  | Acquisition related expenses, net | 0.05 |  |  | — |  |  | — |  |  | 0.05 |  |  | — |  |
|  | Gain on business combination | — |  |  | — |  |  | — |  |  | (0.09 | ) |  | — |  |
| Non-GAAP net income per share - diluted | $ | 0.40 |  |  | $ | 0.36 |  |  | $ | 0.39 |  |  | $ | 1.33 |  |  | $ | 1.26 |  |
| Reconciliation of GAAP net income to non-GAAP adjusted EBITDA: |  |  |  |  |  |  |
| GAAP net income | $ | 7,655 |  |  | $ | 8,036 |  |  | $ | 9,235 |  |  | $ | 30,760 |  |  | $ | 30,518 |  |
| Add back: |  |  |  |  |  |  |  |  |  |
|  | Share-based compensation expense | 3,654 |  |  | 3,966 |  |  | 4,175 |  |  | 14,921 |  |  | 12,785 |  |
|  | Interest (income) and expense, net | 89 |  |  | 138 |  |  | 18 |  |  | 410 |  |  | 38 |  |
|  | Depreciation and amortization expense | 7,182 |  |  | 6,482 |  |  | 5,566 |  |  | 25,639 |  |  | 20,272 |  |
|  | Income tax expense | 3,562 |  |  | 5,177 |  |  | 4,162 |  |  | 15,484 |  |  | 17,986 |  |
|  | Acquisition related expenses, net | 2,898 |  |  | — |  |  | — |  |  | 2,898 |  |  | — |  |
|  | Gain on business combination | — |  |  | — |  |  | — |  |  | (3,443 | ) |  | — |  |
| Non-GAAP adjusted EBITDA (c) | $ | 25,040 |  |  | $ | 23,799 |  |  | $ | 23,156 |  |  | $ | 86,669 |  |  | $ | 81,599 |  |

[0000926326-16-000041:8k_2_02:73]
____________________________________________

[0000926326-16-000041:8k_2_02:74]
| (a) | This adjustment reflects the accounting impact of non-cash stock-based compensation expense for the periods presented. |

[0000926326-16-000041:8k_2_02:75]
| (b) | Tax effects are calculated using the effective tax rates for the respective periods presented. |

[0000926326-16-000041:8k_2_02:76]
| (c) | Defined as earnings before interest income and expense, taxes, depreciation and amortization, and non-cash expenses, including stock compensation expense, per ASC 718, as well as excluding certain non-GAAP adjustments. |

[0000926326-16-000041:8k_2_02:77]
10

[0000926326-16-000041:8k_2_02:78]
Omnicell, Inc.

[0000926326-16-000041:8k_2_02:79]
Segmented Information

[0000926326-16-000041:8k_2_02:80]
(Unaudited, in thousands, except for percentages)

[0000926326-16-000041:8k_2_02:81]
|  | Three Months Ended December 31, 2015 |  | Three Months Ended December 31, 2014 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |  | Automation andAnalytics |  | MedicationAdherence |  | Total |
| Revenues | $ | 105,874 |  |  | $ | 24,442 |  |  | $ | 130,316 |  |  | $ | 98,347 |  |  | $ | 23,194 |  |  | $ | 121,541 |  |
| Cost of revenues | 48,020 |  |  | 17,216 |  |  | 65,236 |  |  | 41,983 |  |  | 15,779 |  |  | 57,762 |  |
| Gross profit | 57,854 |  |  | 7,226 |  |  | 65,080 |  |  | 56,364 |  |  | 7,415 |  |  | 63,779 |  |
| Gross margin % | 54.6% |  | 29.6% |  | 49.9% |  | 57.3% |  | 32.0% |  | 52.5% |
| Operating expenses | 28,889 |  |  | 5,937 |  |  | 34,826 |  |  | 27,363 |  |  | 6,313 |  |  | 33,676 |  |
| Income from segment operations | $ | 28,965 |  |  | $ | 1,289 |  |  | 30,254 |  |  | $ | 29,001 |  |  | $ | 1,102 |  |  | 30,103 |  |
| Operating margin % | 27.4% |  | 5.3% |  | 23.2% |  | 29.5 | % |  | 4.8 | % |  | 24.8 | % |
| Corporate costs |  |  |  |  | 18,284 |  |  |  |  |  |  | 16,629 |  |
| Income from operations |  |  |  |  | $ | 11,970 |  |  |  |  |  |  | $ | 13,474 |  |

[0000926326-16-000041:8k_2_02:82]
11

[0000926326-16-000041:8k_2_02:83]
Omnicell, Inc.

[0000926326-16-000041:8k_2_02:84]
Segmented Information

[0000926326-16-000041:8k_2_02:85]
(Unaudited, in thousands, except for percentages)

[0000926326-16-000041:8k_2_02:86]
|  | Year Ended December 31, 2015 |  | Year Ended December 31, 2014 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |  | Automation andAnalytics |  | MedicationAdherence |  | Total |
| Revenues | $ | 390,321 |  |  | $ | 94,238 |  |  | $ | 484,559 |  |  | $ | 354,095 |  |  | $ | 86,805 |  |  | $ | 440,900 |  |
| Cost of revenues | 171,943 |  |  | 64,686 |  |  | 236,629 |  |  | 151,327 |  |  | 55,713 |  |  | 207,040 |  |
| Gross profit | 218,378 |  |  | 29,552 |  |  | 247,930 |  |  | 202,768 |  |  | 31,092 |  |  | 233,860 |  |
| Gross margin % | 55.9% |  | 31.4% |  | 51.2% |  | 57.3% |  | 35.8% |  | 53.0% |
| Operating expenses | 114,084 |  |  | 24,258 |  |  | 138,342 |  |  | 105,929 |  |  | 20,586 |  |  | 126,515 |  |
| Income from segment operations | $ | 104,294 |  |  | $ | 5,294 |  |  | 109,588 |  |  | $ | 96,839 |  |  | $ | 10,506 |  |  | 107,345 |  |
| Operating margin % | 26.7% |  | 5.6% |  | 22.6% |  | 27.3% |  | 12.1% |  | 24.3% |
| Corporate costs |  |  |  |  | 60,956 |  |  |  |  |  |  | 57,762 |  |
| Income from operations |  |  |  |  | $ | 48,632 |  |  |  |  |  |  | $ | 49,583 |  |

[0000926326-16-000041:8k_2_02:87]
Omnicell, Inc.

[0000926326-16-000041:8k_2_02:88]
Segment Information Non-GAAP Gross Margin and Non-GAAP Operating Margin

[0000926326-16-000041:8k_2_02:89]
(Unaudited, in thousands, except for percentages)

[0000926326-16-000041:8k_2_02:90]
|  | Three Months Ended December 31, 2015 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |
| Revenues | $ | 105,874 |  |  |  |  | $ | 24,442 |  |  |  |  | $ | 130,316 |  |  |  |
| GAAP Gross profit | $ | 57,854 |  |  | 54.6% |  | $ | 7,226 |  |  | 29.6% |  | $ | 65,080 |  |  | 49.9% |
| Plus: |  |  |  |  |  |  |  |  |  |  |  |
| a) Stock-based compensation expense | 411 |  |  | 0.4% |  | 70 |  |  | 0.3% |  | 481 |  |  | 0.4% |
| b) Amortization expense of acquired intangible assets and other acquisition-related expenses | 214 |  |  | 0.2% |  | 333 |  |  | 1.4% |  | 547 |  |  | 0.4% |
| Non-GAAP Gross profit | $ | 58,479 |  |  | 55.2% |  | $ | 7,629 |  |  | 31.2% |  | $ | 66,108 |  |  | 50.7% |
| GAAP Operating income | $ | 28,965 |  |  | 27.4% |  | $ | 1,289 |  |  | 5.3% |  | $ | 30,254 |  |  | 23.2% |
| Plus: |  |  |  |  |  |  |  |  |  |  |  |
| a) Stock-based compensation expense | 1,472 |  |  | 1.4% |  | 196 |  |  | 0.8% |  | 1,668 |  |  | 1.3% |
| b) Amortization expense of acquired intangible assets and other acquisition-related expenses | 828 |  |  | 0.8% |  | 1,072 |  |  | 4.4% |  | 1,900 |  |  | 1.5% |
| Non-GAAP Operating income | $ | 31,265 |  |  | 29.5% |  | $ | 2,557 |  |  | 10.5% |  | 33,822 |  |  | 26.0% |
| GAAP Corporate costs |  |  |  |  |  |  |  |  | 18,284 |  |  | 14.0% |
| Less: Stock-based compensation expense |  |  |  |  |  |  |  |  | 1,986 |  |  | 1.5% |
| Less: Acquisition related expenses |  |  |  |  |  |  |  |  | 2,898 |  |  | 2.2% |
| Non-GAAP Corporate costs |  |  |  |  |  |  |  |  | 13,400 |  |  | 10.3% |
| Non-GAAP Income from operations |  |  |  |  |  |  |  |  | $ | 20,422 |  |  | 15.7% |

[0000926326-16-000041:8k_2_02:91]
13

[0000926326-16-000041:8k_2_02:92]
|  | Three Months Ended December 31, 2014 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |
| Revenues | $ | 98,347 |  |  |  |  | $ | 23,194 |  |  |  |  | $ | 121,541 |  |  |  |
| GAAP Gross profit | $ | 56,364 |  |  | 57.3% |  | $ | 7,415 |  |  | 32.0% |  | $ | 63,779 |  |  | 52.5% |
| Plus: |  |  |  |  |  |  |  |  |  |  |  |
| a) Stock-based compensation expense | 348 |  |  | 0.4% |  | 135 |  |  | 0.6% |  | 483 |  |  | 0.4% |
| b) Amortization expense of acquired intangible assets and other acquisition-related expenses | 35 |  |  | 0.0% |  | 333 |  |  | 1.4% |  | 368 |  |  | 0.3% |
| Non-GAAP Gross profit | $ | 56,747 |  |  | 57.7% |  | $ | 7,883 |  |  | 34.0% |  | $ | 64,630 |  |  | 53.2% |
| GAAP Operating income | $ | 29,001 |  |  | 29.5% |  | $ | 1,102 |  |  | 4.8% |  | $ | 30,103 |  |  | 24.8% |
| Plus: |  |  |  |  |  |  |  |  |  |  |  |
| a) Stock-based compensation expense | 1,679 |  |  | 1.7% |  | 205 |  |  | 0.9% |  | 1,884 |  |  | 1.6% |
| b) Amortization expense of acquired intangible assets and other acquisition-related expenses | 147 |  |  | 0.1% |  | 1,086 |  |  | 4.7% |  | 1,233 |  |  | 1.0% |
| Non-GAAP Operating income | $ | 30,827 |  |  | 31.3% |  | $ | 2,393 |  |  | 10.3% |  | 33,220 |  |  | 27.3% |
| GAAP Corporate costs |  |  |  |  |  |  |  |  | 16,629 |  |  | 13.7% |
| Less: Stock-based compensation expense |  |  |  |  |  |  |  |  | 2,291 |  |  | 1.9% |
| Non-GAAP Corporate costs |  |  |  |  |  |  |  |  | 14,338 |  |  | 11.8% |
| Non-GAAP Income from operations |  |  |  |  |  |  |  |  | $ | 18,882 |  |  | 15.5% |

[0000926326-16-000041:8k_2_02:93]
14
