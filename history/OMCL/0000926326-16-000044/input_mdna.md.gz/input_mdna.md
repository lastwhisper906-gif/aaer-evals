# OMCL MD&A — 0000926326-16-000044


## mdna

[0000926326-16-000044:mdna:1]
ITEM 7. MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0000926326-16-000044:mdna:2]
The following discussion and analysis should be read in conjunction with our Consolidated Financial Statements and related notes in this annual report. This discussion may contain forward-looking statements based upon current expectations that involve risks and uncertainties. Our actual results and the timing of selected events could differ materially from those anticipated in these forward-looking statements as a result of several factors, including those set forth under Item 1A "Risk

[0000926326-16-000044:mdna:3]
Factors" and elsewhere in this annual report. Unless otherwise stated, references in this report to particular years or quarters refer to our fiscal year and the associated quarters of those fiscal years.

[0000926326-16-000044:mdna:4]
OVERVIEW

[0000926326-16-000044:mdna:5]
Our Business

[0000926326-16-000044:mdna:6]
We are a leading provider of comprehensive automation and business analytics software solutions for patient-centric medication and supply management across the entire healthcare continuum, from the acute care hospital setting to post-acute skilled nursing and long-term care facilities to the home. Our Omnicell Automation and Analytic customers worldwide use our medication automation, supply chain and analytics solutions to help enable them to increase operational efficiency, reduce errors, deliver actionable intelligence and improve patient safety.

[0000926326-16-000044:mdna:7]
Omnicell Medication Adherence solutions, including the MTS and Surgichem brands, provide innovative medication adherence packaging solutions that can help reduce costly hospital readmissions and enable institutional and retail pharmacies worldwide to maintain high accuracy and quality standards in medication dispensing and administration while optimizing productivity and controlling costs.

[0000926326-16-000044:mdna:8]
We sell our product and consumable solutions together with related service offerings. Revenue generated in the United States represented 83% of our total revenues in 2015 and we expect our revenues from international operations to increase in future periods as we continue to grow our international business. We have not sold in the past, and have no future plans to sell our products either directly or indirectly, to customers located in countries that are identified as state sponsors of terrorism by the U.S. Department of State, and are subject to economic sanctions and export controls.

[0000926326-16-000044:mdna:9]
Operating Segments

[0000926326-16-000044:mdna:10]
Beginning in the first quarter of 2015, we have managed our business as two operating segments, Automation and Analytics and Medication Adherence.

[0000926326-16-000044:mdna:11]
Automation and Analytics

[0000926326-16-000044:mdna:12]
The Automation and Analytics segment is organized around the design, manufacturing, selling and servicing of medication and supply dispensing systems, pharmacy inventory management systems, and related software. Our Automation and Analytics products are designed to enable our customers to enhance and improve the effectiveness of the medication-use process, the efficiency of the medical-surgical supply chain, overall patient care and clinical and financial outcomes of medical facilities. Through modular configuration and upgrades, our systems can be tailored to specific customer needs.

[0000926326-16-000044:mdna:13]
Medication Adherence

[0000926326-16-000044:mdna:14]
The Medication Adherence segment primarily includes the design, manufacturing and selling of consumable medication blister cards, packaging equipment and ancillary products and services. These products are used to manage medication administration outside of the hospital setting and include medication adherence products sold under the brand name MTS, Surgichem, SureMed and Omnicell. MTS products consist of proprietary medication packaging systems and related products for use by institutional pharmacies servicing long-term care and correctional facilities or retail pharmacies serving patients in their local communities. Similarly, Surgichem is a provider of medication adherence packaging systems and solutions to the United Kingdom community and home care markets.

[0000926326-16-000044:mdna:15]
For further description of our operating segments, Note 12, Segment and Geographical Information, of the Notes to Consolidated Financial Statements in this annual report.

[0000926326-16-000044:mdna:16]
Strategy

[0000926326-16-000044:mdna:17]
The healthcare market is experiencing a period of substantive change. The adoption of electronic healthcare records, new regulatory constraints, and changes in the reimbursement structure have caused healthcare institutions to re-examine their operating structures, re-prioritize their investments, and seek efficiencies. We believe our customers’ evolving operating environment creates challenges for any supplier, but also affords opportunities for suppliers that are able to partner with customers to help them meet the changing demands. We have and intend to continue to invest in the strategies which we believe have generated and will continue to generate our revenue and earnings growth, while supporting our customers’ initiatives and needs. These strategies include:

[0000926326-16-000044:mdna:18]
| • | Development of differentiated products. We invest in the development of products that we believe bring patient safety and workflow efficiency to our customers’ operations that they cannot get from other competing solutions. These differentiators may be as small as how a transaction operates or information provided on a report or as large as the entire automation of a workflow that would otherwise be completed manually. We intend to continue our focus on differentiating our products, and we carefully assess our investments regularly as we strive to ensure those investments provide the solutions most valuable to our customers. |

[0000926326-16-000044:mdna:19]
| • | Deliver our solutions to new markets. Areas of healthcare where work is done manually may benefit from our existing solutions. These areas include hospitals that continue to employ manual operations, healthcare segments of the U.S. market outside hospitals and markets outside the United States. We weigh the cost of entering these new markets against the expected benefits and focus on the markets that we believe are most likely to adopt our products. |

[0000926326-16-000044:mdna:20]
| • | Expansion of our solutions through acquisitions and partnerships. Our acquisitions have generally been focused on automation of manual workflows or data analytics, which is the enhancement of data for our customers’ decision-making processes. We believe that expansion of our product lines through acquisition and partnerships to meet our customers changing and evolving expectations is a key component to our historical and future success. |

[0000926326-16-000044:mdna:21]
Our investments have been consistent with the strategies outlined above. To differentiate our solutions from others available in the market, we began shipping a refresh of our product line in 2011, which we market as G4. The G4 refresh included multiple new products and an upgrade product that allowed existing customers to augment their installations to obtain the most current technology that we provide. The G4 product is updated regularly every 12-18 months with new software enhancements. Since its introduction in 2011 there have been 4 major software releases. The G4 product refresh has been a key contributor to our growth, with 78% of our automation and analytics installed base ordering upgrades to their existing systems since the announcement of G4. In addition to enhanced capabilities, we have focused on attaining the highest quality and service measurements for G4 in the industry, while marketing the solution to new and existing customers. Our research and development efforts today are designed to bring new products to market beyond the G4 product line that we believe will meet customer needs in years to come.

[0000926326-16-000044:mdna:22]
Consistent with our strategy to enter new markets, we have made investments in our selling, general and administrative expenses to expand our sales team and market to new customers. Our international efforts have focused primarily on four markets: the United Kingdom and Germany where we sell medication adherence products through a direct sales team; Middle Eastern countries of the Arabian Peninsula where new healthcare facility construction is taking place, and in China; where we launched a Mandarin version of our automated dispensing systems. We have also expanded our sales efforts to medication adherence customers in the United States which has allowed us to sell our automated dispensing solutions and other products to this market.

[0000926326-16-000044:mdna:23]
Expansion of our solutions through acquisitions and partnerships include our acquisition of MTS in 2012, our acquisition of Surgichem in August 2014, our acquisitions of Mach4 and Avantec in April 2015, and our acquisition of Aesynt which was consummated in January 2016. Surgichem is a provider of medication adherence products in the United Kingdom. Mach4 is a provider of automated medication management systems to retail and hospital pharmacy customers primarily in Europe, with additional installations in China, the Middle East and Latin America. Avantec develops medication and supply automation products that complement our solutions for configurations suited to the United Kingdom marketplace, and has been the exclusive United Kingdom distributor for our medication and supply automation solutions since 2005. Aesynt is a provider of automated medication management systems, including dispensing robots with storage solutions, medication storage and dispensing carts and cabinets, I.V. sterile preparation robotics and software, including software related to medication management. We have also developed relationships with major providers of hospital information management systems with the goal of enhancing the interoperability of our products with their systems. We believe that enhanced interoperability will help reduce implementation costs, time, and maintenance for shared clients, while providing new clinical workflows designed to enhance efficiency and patient safety.

[0000926326-16-000044:mdna:24]
We believe that the success of our three leg strategy of differentiated products, expansion into new markets and acquisition and partnership in future periods will be based on, among other factors:

[0000926326-16-000044:mdna:25]
| • | Our expectation that the overall market demand for healthcare services will increase as the population grows, life expectancies continue to increase and the quality and availability of healthcare services increases; |

[0000926326-16-000044:mdna:26]
| • | Our expectation that the environment of increased patient safety awareness, increased regulatory control, increased demand for innovative products that improve the care experience and increased need for workflow |

[0000926326-16-000044:mdna:27]
42

[0000926326-16-000044:mdna:28]
efficiency through the adoption of technology in the healthcare industry will make our solutions a priority in the capital budgets of healthcare facilities; and

[0000926326-16-000044:mdna:29]
| • | Our belief that healthcare customers will continue to value a consultative customer experience from their suppliers. |

[0000926326-16-000044:mdna:30]
Among other financial measures, we utilize product bookings to assess the current success of our strategies. Product bookings consist of all firm orders, as evidenced by a contract and purchase order for equipment and software, and by a purchase order for consumables. Equipment and software bookings are installable within twelve months and generally recorded as revenue upon customer acceptance of the installation. Consumables are recorded as revenue upon shipment to a customer or receipt by the customer, depending upon contract terms. Consumable bookings are generally recorded as revenue within one month. Product bookings increased by 8%, from $364.0 million in 2014 to $392.3 million in 2015, driven by the success of our growth strategies in differentiated products and new markets and, to a lesser extent, by the contributions from the acquisitions of Surgichem, Mach4, and Avantec.

[0000926326-16-000044:mdna:31]
In addition to product solution sales, we provide services to our customers.  Our healthcare customers expect a high degree of partnership involvement from their technology suppliers throughout their ownership of the products. We provide extensive installation planning and consulting as part of every product sale and included in the initial price of the solution. Our customers' medication control systems are mission critical to their success and our customers require these systems to be functional at all times. To help assure the maximum availability of our systems, our customers typically purchase maintenance and support contracts in one, two or five year increments.  As a result of the growth of our installed base of customers, our service revenues have also grown. We strive to provide the best service possible, as measured by third-party rating agencies and by our own surveys, to assure our customers continue to seek service maintenance from us. Our liabilities include current and long-term deferred service revenue of $45.9 million and $45.5 million as of December 31, 2015 and December 31, 2014, respectively. Our deferred service revenue will be amortized to service revenue as the service contracts are executed.

[0000926326-16-000044:mdna:32]
The growth in our Automation and Analytics revenue was driven primarily by our success in consistently growing the number of our customer installations for the year ended December 31, 2015. To a lesser extent, but of equal importance, revenue growth was also driven by our success in upgrading installed customers to newer G4 technology, which is in line with our strategy of striving to deliver differentiated innovation in our solutions. Our larger installed base has provided growth opportunities and, as a result, our service revenues have also grown for the year ended December 31, 2015.

[0000926326-16-000044:mdna:33]
The growth in our Medication Adherence revenue was driven primarily by the inclusion of Surgichem operations which was acquired in August 2014 and increased adoption of multi-medication adherence solutions used by patients in assisted living or home care in Europe. This growth is in line with our strategy to deliver solutions to markets outside the United States. On a geographic basis, the United States market did not contribute to, nor erode, the growth in our Medication Adherence business as the population of patients living in nursing homes in the United States has remained relatively constant over the past year.

[0000926326-16-000044:mdna:34]
In the future, we expect our strategies to evolve as the business environment of our customers evolves, but for our focus to remain on improving healthcare with solutions that help change the practices in ways that improve patient and provider outcomes. We expect our investment in differentiated products, new markets, and acquisitions and partnerships to continue. In 2016, we also intend to manage our business to operating profit margins similar to those achieved in 2015. Our full-time headcount of 1,451 on December 31, 2015, an increase of 215 from December 31, 2014, is dedicated to bringing our strategies to bear in all the markets in which we participate.

[0000926326-16-000044:mdna:35]
Aesynt Acquisition

[0000926326-16-000044:mdna:36]
On January 5, 2016, we completed the acquisition of all of the membership interests of Aesynt pursuant to the Securities Purchase Agreement. Aesynt is a provider of automated medication management systems, including dispensing robots with storage solutions, medication storage and dispensing carts and cabinets, I.V. sterile preparation robotics and software, including software related to medication management. The total aggregate consideration is $275.0 million, in cash, plus cash on hand at signing minus indebtedness at close, or approximately $217.5 million, subject to certain adjustments at closing as provided for in the Securities Purchase Agreement. We will record the purchase of Aesynt using the business combination method of accounting and will recognize the assets acquired and liabilities assumed at their fair values as of the date of the acquisition. The results of Aesynt's operations will be included in our consolidated results of operations beginning January 6, 2016. We are currently evaluating the fair values of the consideration transferred, assets acquired and liabilities assumed and will commence our purchase price allocation in the first quarter of fiscal 2016.

[0000926326-16-000044:mdna:37]
CRITICAL ACCOUNTING POLICIES AND ESTIMATES

[0000926326-16-000044:mdna:38]
Our discussion and analysis of our financial condition and results of operations are based on our Consolidated Financial Statements, which have been prepared in accordance with United States Generally Accepted Accounting Principles ("U.S. GAAP"). The preparation of these financial statements requires us to make certain estimates and assumptions that affect the reported amounts of assets and liabilities, disclosure of any contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. We regularly review our estimates and assumptions, which are based on historical experience and various other factors that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of certain assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates and assumptions. We believe the following critical accounting policies are affected by significant judgments and estimates used in the preparation of our Consolidated Financial Statements:

[0000926326-16-000044:mdna:39]
Revenue recognition

[0000926326-16-000044:mdna:40]
We earn revenues from sales of our medication and medical and surgical supply automation systems along with consumables and related services that are sold in the healthcare industry, our principal market. Revenues related to consumable products are reported net of discounts provided to our customers. Our customer arrangements typically include one or more of the following deliverables:

[0000926326-16-000044:mdna:41]
Products. Software-enabled equipment that manages and regulates the storage and dispensing of pharmaceuticals, consumable blister cards and packaging equipment and other medical supplies.

[0000926326-16-000044:mdna:42]
Software. Additional software applications that enable incremental functionality of our equipment.

[0000926326-16-000044:mdna:43]
Installation. Installation of equipment as integrated systems at customers' sites.

[0000926326-16-000044:mdna:44]
Post-installation technical support. Phone support, on-site service, parts and access to unspecified software upgrades and enhancements, if and when available.

[0000926326-16-000044:mdna:45]
Professional services. Other customer services, such as training and consulting.

[0000926326-16-000044:mdna:46]
We recognize revenue when the earnings process is complete, based upon our evaluation of whether the following four criteria have been met:

[0000926326-16-000044:mdna:47]
Persuasive evidence of an arrangement exists. We use signed customer contracts and signed customer purchase orders as evidence of an arrangement for leases and sales. For service engagements, we use a signed services agreement and a statement of work to evidence an arrangement.

[0000926326-16-000044:mdna:48]
Delivery has occurred. Equipment and embedded software product delivery is deemed to occur upon successful installation and receipt of a signed and dated customer confirmation of installation letter, providing evidence that we have delivered what a customer ordered. In instances of a customer self-installation, product delivery is deemed to have occurred upon receipt of a signed and dated customer confirmation letter. If a sale does not require installation, we recognize revenue on delivery of products to the customer, including transfer of title and risk of loss, assuming all other revenue criteria are met. For existing distributors, where installation of equipment training has been previously provided and the distributor is certified to install our equipment at the end-user customer facility, we recognize revenue from sales of products to the distributor upon shipment assuming all other revenue criteria are met, since we do not allow for rights of return or refund. For new distributors, where we have not provided installation of equipment training, revenue on the sales of products to the distributor is deferred until the distributor has completed the Distributor Training Program and has been certified to install our equipment at the end-user facility. For the sale of consumable blister cards, we recognize revenue when title and risk of loss of the products shipped have transferred to the customer, which usually occurs upon shipment from our facilities. Assuming all other revenue criteria are met, we recognize revenue for support services ratably over the related support services contract period. We recognize revenue on training and professional services as they are performed.

[0000926326-16-000044:mdna:49]
Fee is fixed or determinable. We assess whether a fee is fixed or determinable at the outset of the arrangement based on the payment terms associated with the transaction. We have established a history of collecting under the original contract without providing concessions on payments, products or services.

[0000926326-16-000044:mdna:50]
Collection is probable. We assess the probability of collecting from each customer at the outset of the arrangement based on a number of factors, including the customer's payment history and its current creditworthiness. If, in our judgment, collection of a fee is not probable, we defer the revenue until the uncertainty is removed, which generally means revenue is recognized upon our receipt of cash payment assuming all other revenue criteria are met. Our historical experience has been that collection from our customers is generally probable.

[0000926326-16-000044:mdna:51]
In arrangements with multiple deliverables, assuming all other revenue criteria are met, we recognize revenue for individual delivered items if they have value to the customer on a standalone basis. We allocate arrangement consideration at the inception of the arrangement to all deliverables using the relative selling price method. This method requires us to determine the selling price at which each deliverable could be sold if it were sold regularly on a standalone basis. When available, we use vendor-specific objective evidence ("VSOE") of the selling price. VSOE represents the price charged for a deliverable when it is sold separately, or for a deliverable not yet being sold separately, the price established by management with the relevant authority. We consider VSOE to exist when approximately 80% or more of our standalone sales of an item are priced within a reasonably narrow pricing range (plus or minus 15% of the median rates). We have established VSOE of the selling price for our post-installation technical support services and professional services. When VSOE of selling price is not available, third-party evidence ("TPE") of selling price for similar products and services is acceptable; however, our offerings and market strategy differ from those of our competitors, such that we cannot obtain sufficient comparable information about third parties' prices. If neither VSOE nor TPE are available, we use our best estimates of selling prices ("BESP"). We determine BESP considering factors such as market conditions, sales channels, internal costs and product margin objectives and pricing practices. We regularly review and update our VSOE and BESP information.

[0000926326-16-000044:mdna:52]
The relative selling price method allocates total arrangement consideration proportionally to each deliverable (an "Element") on the basis of its estimated selling price. In addition, the amount recognized for any delivered Elements cannot exceed that which is contingent upon delivery of any remaining Elements in the arrangement.

[0000926326-16-000044:mdna:53]
We also use the residual method to allocate revenue between the software products that enable incremental equipment functionality, and thus are not deemed to deliver its essential functionality, and the related post-installation technical support, as these products and services continue to be accounted for under software revenue recognition rules. Under the residual method, the amount allocated to the undelivered elements equals VSOE of fair value of these elements. Any remaining amounts are attributed to the delivered items and are recognized when those items are delivered.

[0000926326-16-000044:mdna:54]
A portion of our sales are made through multi-year lease agreements. Under sales-type leases, we recognize revenue for our hardware and software products net of lease execution costs such as post-installation product maintenance and technical support, at the net present value of the lease payment stream once our installation obligations have been met. We optimize cash flows by selling a majority of our non-U.S. government leases to third-party leasing finance companies on a non-recourse basis. We have no obligation to the leasing company once the lease has been sold. Some of our sales-type leases, mostly those relating to U.S. government hospitals, are retained in-house. Interest income on these leases is recognized as a component of product revenue using the interest method.

[0000926326-16-000044:mdna:55]
Accounts receivable and notes receivable (net investment in sales-type leases)

[0000926326-16-000044:mdna:56]
We actively manage our accounts receivable to minimize credit risk. We typically sell our products to customers for which there is a history of successful collection. New customers are subject to a credit review process, which evaluates that customer's financial position and ability to pay. We continually monitor and evaluate the collectability of our trade receivables based on a combination of factors. We record specific allowances for doubtful accounts when we become aware of a specific customer's impaired ability to meet its financial obligation to us, such as in the case of bankruptcy filings or deterioration of financial position.

[0000926326-16-000044:mdna:57]
Uncollectible amounts are charged off against trade receivables and the allowance for doubtful accounts when we make a final determination that there is no reasonable expectation of recovery. Estimates are used in determining our allowances for all other customers based on factors such as current trends, the length of time the receivables are past due and historical collection experience. While we believe that our allowance for doubtful accounts receivable is adequate and that the judgment applied is appropriate, such estimated amounts could differ materially from what will actually be uncollectible in the future.

[0000926326-16-000044:mdna:58]
The retained in-house leases discussed above are considered financing receivables. Our credit policies and evaluation of credit risk and write-off policies are applied alike to trade receivables and the net investment in sales-type leases. For both, an account is generally past due after thirty days. The financing receivables also have customer-specific reserves for accounts identified for specific impairment and a non-specific reserve applied to the remaining population, based on factors such as current trends, the length of time the receivables are past due and historical collection experience. The retained in-house leases are not stratified by portfolio or class.

[0000926326-16-000044:mdna:59]
Valuation and impairment of goodwill, intangible assets and other long-lived assets

[0000926326-16-000044:mdna:60]
Business combination valuations. When we acquire businesses, we allocate the purchase price to tangible assets and liabilities and identifiable intangible assets acquired. Any residual purchase price is recorded as goodwill. The allocation of the purchase price requires management to make significant estimates in determining the fair values of assets acquired and

[0000926326-16-000044:mdna:61]
liabilities assumed, especially with respect to intangible assets. These estimates are based on information obtained from management of the acquired companies and historical experience. These estimates can include, but are not limited to:

[0000926326-16-000044:mdna:62]
| • | cash flows that an asset is expected to generate in the future; |

[0000926326-16-000044:mdna:63]
| • | the acquired company’s brand and competitive position, as well as assumptions about the period of time the acquired brand will continue to be used in the combined company’s product portfolio; |

[0000926326-16-000044:mdna:64]
| • | cost savings expected to be derived from acquiring an asset; and |

[0000926326-16-000044:mdna:65]
| • | discount rates. |

[0000926326-16-000044:mdna:66]
These estimates are inherently uncertain and unpredictable, and if different estimates were used, the purchase price for the acquisition could be allocated to the acquired assets and liabilities differently from the allocation that we have made. In addition, unanticipated events and circumstances may occur which may affect the accuracy or validity of such estimates, and if such events occur we may be required to record a charge against the value ascribed to an acquired asset or an increase in the amounts recorded for assumed liabilities.

[0000926326-16-000044:mdna:67]
Goodwill impairment. We review goodwill for impairment on an annual basis as of the first day of the fourth quarter of each year at the reporting unit level. Our reporting units are the same as our operating segments, which are Automation and Analytics and Medication Adherence. A qualitative assessment is initially made to determine whether it is necessary to perform quantitative testing. This initial assessment includes, among others, consideration of: (i) past, current and projected future earnings and equity; (ii) recent trends and market conditions; and (iii) valuation metrics involving similar companies that are publicly-traded and acquisitions of similar companies, if available. If this initial qualitative assessment indicates that it is more likely than not that impairment exists, or if we decide to bypass this option, we proceed to a two-step impairment test. The first step ("Step 1") involves a comparison between the estimated fair values of our reporting units with their respective carrying amounts including goodwill. The methods for estimating reporting unit values include asset and liability fair values and other valuation techniques, such as discounted cash flows and multiples of earnings or revenues. If the carrying value exceeds estimated fair value, there is an indication of potential impairment, and the second step is performed to measure the amount of impairment. The second step involves calculating an implied fair value of goodwill by measuring the excess of the estimated fair value of the reporting units over the aggregate estimated fair values of the individual assets less liabilities. If the carrying value of goodwill exceeds the implied fair value of goodwill, an impairment charge is recorded for the excess.

[0000926326-16-000044:mdna:68]
The process of estimating the fair value and carrying value of our reporting units’ equity requires significant judgment at many points during the analysis. Various assets and liabilities are not specifically allocated to an individual reporting unit, and therefore, we apply judgment to allocate the assets and liabilities, and this allocation affects the carrying value of the respective reporting units. Applying the income approach requires that we make a number of important estimates and assumptions. We estimate the future cash flows of each reporting unit based on historical and forecasted revenue and operating costs. This involves further estimates, such as estimates of future revenue and expense growth rates. In addition, we apply a discount rate to the estimated future cash flows for the purpose of the valuation. This discount rate is based on the estimated weighted-average cost of capital for each reporting unit and may change from year to year. Changes in these key estimates and assumptions, or in other assumptions used in this process, could materially affect our impairment analysis for a given year.

[0000926326-16-000044:mdna:69]
Based on a Step 1 impairment analysis performed as of October 1, 2015, we determined that it was more likely than not that the fair value of each of our reporting units exceeded the carrying value by more than 25%, and thus no impairment in our reporting units was recorded.

[0000926326-16-000044:mdna:70]
Intangible assets and other long-lived assets. We assess the impairment of identifiable intangible assets and other long-lived assets whenever events or changes in circumstances indicate that an asset's carrying amount may not be recoverable. Recoverability of an asset is measured by the comparison of the carrying amount to the sum of the undiscounted estimated future cash flows the asset is expected to generate, offset by estimated future costs to dispose of the product to which the asset relates. If an asset is considered to be impaired, the amount of such impairment would be measured as the difference between the carrying amount of the asset and its fair value. Our cash flow assumptions are based on historical and forecasted future revenue, operating costs, and other relevant factors. Assumptions and estimates about the remaining useful lives of our intangible assets and other long-lived assets are subjective and are affected by changes to our business strategies. If management’s estimates of future operating results change, or if there are changes to other assumptions, the estimate of the fair value of our assets could change significantly. Such change could result in impairment charges in future periods, which could have a significant impact on our operating results and financial condition.

[0000926326-16-000044:mdna:71]
Valuation of share-based awards

[0000926326-16-000044:mdna:72]
We account for share-based compensation in accordance with ASC 718, Stock Compensation ("ASC 718"). We recognize compensation expense related to stock-compensation, including the awarding of employee stock options and

[0000926326-16-000044:mdna:73]
restricted stock units, based on the grant date estimated fair value. We amortize the fair value of the employee stock options on a straight-line basis over the requisite service period of the award, which is generally the vesting period. We estimate the fair value of stock-based compensation awards using the Black-Scholes option pricing model, which requires the following inputs: expected life, expected volatility, risk-free interest rate, expected dividend yield rate, exercise price, and closing price of our common stock on the date of grant. The expected volatility is based on a combination of historical and market-based implied volatility, and the expected life of the awards is based on our historical experience of employee stock option exercises, including forfeitures. The valuation assumptions we use in estimating the fair value of employee share-based awards may change in future periods. We calculate our pool of excess tax benefits available within additional paid-in capital in accordance with the provisions of ASC 718.

[0000926326-16-000044:mdna:74]
Accounting for income taxes

[0000926326-16-000044:mdna:75]
We record an income tax provision for the anticipated tax consequences of the reported results of operations. In accordance with ASC 740, Income Taxes ("ASC 740"), the provision for income taxes is computed using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been included in the financial statements. Under this method, deferred tax assets and liabilities are determined on the basis of the differences between the financial statement and tax bases of assets and liabilities, and for operating losses and tax credit carry forwards. Deferred tax assets and liabilities are measured using the enacted tax rates in effect for the periods in which those tax assets and liabilities are expected to be realized or settled. In the event that these tax rates change, we will incur a benefit or detriment on our income tax expense in the period of change. If we were to determine that all or part of the net deferred tax assets are not realizable in the future, we will record a valuation allowance that would be charged to earnings in the period such determination is made.

[0000926326-16-000044:mdna:76]
In accordance with ASC 740, we recognize the tax benefit from an uncertain tax position if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement. The calculation of tax liabilities involves significant judgment in estimating the impact of uncertainties in the application of ASC 740 and complex tax laws. Resolution of these uncertainties in a manner inconsistent with management’s expectations could have a material impact on our financial condition and operating results.

[0000926326-16-000044:mdna:77]
Recently issued authoritative guidance

[0000926326-16-000044:mdna:78]
Refer to Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to Consolidated Financial Statements in this annual report for a description of recently issued accounting pronouncements, including the expected dates of adoption and estimated effects on our results of operations, financial positions and cash flows.

[0000926326-16-000044:mdna:79]
RESULTS OF OPERATIONS

[0000926326-16-000044:mdna:80]
Total Revenues

[0000926326-16-000044:mdna:81]
|  |  |  | Change in |  |  |  | Change in |  |  |
|  | 2015 |  | $ |  | % |  | 2014 |  | $ |  | % |  | 2013 |
|  | (Dollars in thousands) |
| Product revenues | $ | 388,397 |  |  | $ | 28,053 |  |  | 8% |  | $ | 360,344 |  |  | $ | 53,155 |  |  | 17% |  | $ | 307,189 |  |
| Percentage of total revenues | 80% |  |  |  |  |  | 82% |  |  |  |  |  | 81% |
| Service and other revenues | 96,162 |  |  | 15,606 |  |  | 19% |  | 80,556 |  |  | 7,160 |  |  | 10% |  | 73,396 |  |
| Percentage of total revenues | 20% |  |  |  |  |  | 18% |  |  |  |  |  | 19% |
| Total revenues | $ | 484,559 |  |  | $ | 43,659 |  |  | 10% |  | $ | 440,900 |  |  | $ | 60,315 |  |  | 16% |  | $ | 380,585 |  |

[0000926326-16-000044:mdna:82]
2015 compared to 2014:

[0000926326-16-000044:mdna:83]
Revenues were $484.6 million for the year ended December 31, 2015 compared to $440.9 million for the year ended December 31, 2014, representing an increase of approximately 10%. The year-over-year revenue increase was primarily attributed to increases in product revenues of $28.1 million and in services and other revenue of $15.6 million.

[0000926326-16-000044:mdna:84]
Product revenues represented 80% and 82% of total revenues for the years ended 2015 and 2014, respectively. The increase in product revenues of $28.1 million was primarily due to larger transaction sizes, mainly attributable to competitive conversions, and revenue from acquired companies Mach4 and Avantec which contributed $10.0 million to the increase in product revenue. Product revenues increased in both of our segments. The increase in our Automation and Analytics segment

[0000926326-16-000044:mdna:85]
was $20.6 million and in our Medication Adherence segment was $7.4 million. Service and other revenues represented 20% and 18% total revenues for the years ended 2015 and 2014, respectively. Service and other revenues primarily increased due to an increase in our Automation and Analytics segment of $15.6 million, primarily attributed to higher service renewal fees driven mainly by an increase in installed customer base and $5.0 million due to acquired companies Mach4 and Avantec.

[0000926326-16-000044:mdna:86]
Our international sales represented 17%, 11% and 12% of total revenues for the years ended 2015, 2014 and 2013, respectively, and are expected to be affected by foreign currency exchange rates fluctuations. We are unable to predict the extent to which revenue in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-16-000044:mdna:87]
We anticipate our revenues will continue to increase in 2016 compared to 2015, as we fulfill our existing orders, and based on our growth in bookings in 2015, some of which will be recognized as revenue in 2016. Our ability to continue to grow revenue is dependent on our ability to continue to obtain orders from customers, our ability to produce quality consumables to fulfill customer demand, the volume of installations we are able to complete, our ability to meet customer needs by providing a quality installation experience, and our flexibility in manpower allocations among customers to complete installations on a timely basis. The timing of our product revenues for equipment is primarily dependent on when our customers’ schedules allow for installations.

[0000926326-16-000044:mdna:88]
2014 compared to 2013:

[0000926326-16-000044:mdna:89]
Product revenues increased due to increased sales for both Automation and Analytics segment of $44.0 million and Medication Adherence segment of $9.2 million.  Service and other revenues primarily increased due to an increase from our Automation and Analytics segment of $7.1 million, increased primarily as a result of an expansion in our installed base of automation systems and a resulting increase in the number of support service contracts within our Automation and Analytics segment.

[0000926326-16-000044:mdna:90]
Financial Information by Segment Revenues

[0000926326-16-000044:mdna:91]
|  |  |  | Change in |  |  |  | Change in |  |  |
|  | 2015 |  | $ |  | % |  | 2014 |  | $ |  | % |  | 2013 |
| Revenues: | (Dollars in thousands) |
| Automation and Analytics | $ | 390,321 |  |  | $ | 36,226 |  |  | 10% |  | $ | 354,095 |  |  | $ | 51,178 |  |  | 17% |  | $ | 302,917 |  |
| Percentage of total revenues | 81% |  |  |  |  |  | 80% |  |  |  |  |  | 80% |
| Medication Adherence | 94,238 |  |  | 7,433 |  |  | 9% |  | 86,805 |  |  | 9,137 |  |  | 12% |  | 77,668 |  |
| Percentage of total revenues | 19% |  |  |  |  |  | 20% |  |  |  |  |  | 20% |
| Total revenues | $ | 484,559 |  |  | $ | 43,659 |  |  | 10% |  | $ | 440,900 |  |  | $ | 60,315 |  |  | 16% |  | $ | 380,585 |  |

[0000926326-16-000044:mdna:92]
2015 compared to 2014:

[0000926326-16-000044:mdna:93]
The increase in Automation and Analytics revenues for the year ended December 31, 2015 as compared to the year ended December 31, 2014 was primarily related to an increase in product revenues of $20.6 million due to larger transaction sizes, mainly attributable to competitive conversions, and revenue from acquired companies Mach4 and Avantec, which contributed $10.0 million of the increase in product revenue. Service and other revenues increased by $15.6 million primarily from higher service renewal revenue driven mainly by an increase in installed customer base, and $5.0 million due to acquired companies Mach4 and Avantec.

[0000926326-16-000044:mdna:94]
Medication Adherence revenues increased for the year ended December 31, 2015 as compared to the year ended December 31, 2014 was primarily due to an increase in product revenues of $7.4 million. The increase in product revenue was largely driven by the full year inclusion of Surgichem operations for the year ended December 31, 2015 compared to  approximately 4 months for the year ended December 2014. This increase of approximately $8.4 million was partially offset by lower equipment sales in year 2015 in comparison to the same period of 2014. Service and other revenues remained relatively flat compared to the prior year.

[0000926326-16-000044:mdna:95]
2014 compared to 2013:

[0000926326-16-000044:mdna:96]
Automation and Analytics revenues increased due to an increase in product revenues of $44.0 million primarily due to the increase of $40.3 million in Medical Automation Cabinets sales and of $7.4 million in Supply Cabinets and Supply Management software sales, partially offset by a decrease of $3.7 million in revenue related to our leasing business. Service and other revenues increased by $7.1 million due to higher service renewal fees driven primarily by an increase in installed base customers and new customers.

[0000926326-16-000044:mdna:97]
Medication Adherence revenues increased due to an increase in product revenues of $9.1 million primarily as a result of an increase in sales of OnDemand medication packaging systems in the United States and an increase in the adoption of our multi-medication consumable products by patients in Europe, and includes $4.6 million in revenue from our Surgichem operations since its acquisition in August 2014. Service and other revenues remained relatively flat compared to the prior year.

[0000926326-16-000044:mdna:98]
Cost of revenues and Gross profit

[0000926326-16-000044:mdna:99]
|  |  |  | Change in |  |  |  | Change in |  |  |
|  | 2015 |  | $ |  | % |  | 2014 |  | $ |  | % |  | 2013 |
| Cost of revenues: | (Dollars in thousands) |
| Automation and Analytics | $ | 171,943 |  |  | $ | 20,616 |  |  | 14% |  | $ | 151,327 |  |  | $ | 22,013 |  |  | 17% |  | $ | 129,314 |  |
| As a percentage of related revenues | 44% |  |  |  |  |  | 43% |  |  |  |  |  | 43% |
| Medication Adherence | 64,686 |  |  | 8,973 |  |  | 16% |  | 55,713 |  |  | 7,841 |  |  | 16% |  | 47,872 |  |
| As a percentage of related revenues | 69% |  |  |  |  |  | 64% |  |  |  |  |  | 62% |
| Total cost of revenues | $ | 236,629 |  |  | $ | 29,589 |  |  | 14% |  | $ | 207,040 |  |  | $ | 29,854 |  |  | 17% |  | $ | 177,186 |  |
| As a percentage of total revenues | 49% |  |  |  |  |  | 47% |  |  |  |  |  | 47% |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 218,378 |  |  | $ | 15,610 |  |  | 8% |  | $ | 202,768 |  |  | $ | 29,165 |  |  | 17% |  | $ | 173,603 |  |
| Automation and Analytics gross margin | 56% |  |  |  |  |  | 57% |  |  |  |  |  | 57% |
| Medication Adherence | 29,552 |  |  | (1,540 | ) |  | (5)% |  | 31,092 |  |  | 1,296 |  |  | 4% |  | 29,796 |  |
| Medication Adherence gross margin | 31% |  |  |  |  |  | 36% |  |  |  |  |  | 38% |
| Total gross profit | $ | 247,930 |  |  | $ | 14,070 |  |  | 6% |  | $ | 233,860 |  |  | $ | 30,461 |  |  | 15% |  | $ | 203,399 |  |
| Total gross margin | 51% |  |  |  |  |  | 53% |  |  |  |  |  | 53% |

[0000926326-16-000044:mdna:100]
2015 compared to 2014:

[0000926326-16-000044:mdna:101]
Cost of revenues is primarily comprised of three general categories: (i) standard product costs which accounts for the majority of the product cost of revenues that are provided to customers, and are inclusive of purchased material, labor to build the product and overhead costs associated with production; (ii) installation costs as we install our equipment at the customer site, and include costs of the field installation personnel, including labor, travel expense, and other expenses; and (iii) other costs including variances in standard costs and overhead, scrap costs, rework, warranty, provisions for excess and obsolete inventory and amortization of software development costs.

[0000926326-16-000044:mdna:102]
Automation and Analytics

[0000926326-16-000044:mdna:103]
Cost of revenues increased by $20.6 million, primarily due to an increase in product costs of $17.0 million which was mainly attributed to $13.5 million costs associated with acquired companies Mach4 and Avantec in the second quarter of 2015 and to customer and product mixes and overall growth in product sales. Cost of service revenues increased by $3.6 million primarily due to an increase in salaries and wages and other related costs. In addition, the acquired companies accounted for approximately $2.6 million of such increase.

[0000926326-16-000044:mdna:104]
Gross profit was $218.4 million for the year ended December 31, 2015 as compared to $202.8 million for the year ended December 31, 2014, representing an increase of approximately 8%, Gross margin percentage decreased due to lower gross margins from acquired companies Mach4 and Avantec.

[0000926326-16-000044:mdna:105]
Medication Adherence

[0000926326-16-000044:mdna:106]
Cost of revenues increased by $9.0 million, primarily due to an increase in product costs of $8.0 million which was mainly attributed to higher volume of revenues from our Surgichem acquisition and changes in our product mix. Cost of service revenues increased by $1.0 million due to higher cost of service sales.

[0000926326-16-000044:mdna:107]
Gross profit decreased due to changes in our product mix, higher manufacturing cost, and higher cost of service.

[0000926326-16-000044:mdna:108]
We do not anticipate any significant fluctuations in gross profit and gross margin beyond normal fluctuations caused by changes in product mix for our Automation and Analytics and Medication Adherence segments during 2016.

[0000926326-16-000044:mdna:109]
2014 compared to 2013:

[0000926326-16-000044:mdna:110]
Automation and Analytics

[0000926326-16-000044:mdna:111]
Cost of revenues increased due to an increase in product costs of $20.8 million as a result of an increase of $16.4 million attributed to a different mixture of customers, products and overall growth in product sales, and an increase of $2.9 million in product installation costs. Cost of service revenues increased by $1.2 million due to an increase in salaries and wages as support headcount increased, in addition to an increase in expenses related to the refurbishment of returned materials.

[0000926326-16-000044:mdna:112]
Gross profit increased due to an increase in product and service revenues while gross margin remained consistent as cost of sales as a percentage of revenues remained consistent with the prior year.

[0000926326-16-000044:mdna:113]
Medication Adherence

[0000926326-16-000044:mdna:114]
Cost of revenues increased due to an increase in product costs of $7.6 million primarily driven by an increase in product sales and the inclusion of costs from our Surgichem operations. Consistent with the related revenues, cost of service sales remained relatively flat compared to the prior year.

[0000926326-16-000044:mdna:115]
Gross profit increased due to an increase in product revenues and the inclusion of Surgichem operations, and gross margin slightly decreased as cost of sales as a percentage of revenues slightly increased driven by higher product costs.

[0000926326-16-000044:mdna:116]
Operating expenses and Income from operations

[0000926326-16-000044:mdna:117]
|  |  |  | Change in |  |  |  | Change in |  |  |
|  | 2015 |  | $ |  | % |  | 2014 |  | $ |  | % |  | 2013 |
| Operating expenses: | (Dollars in thousands) |
| Research and development | $ | 35,160 |  |  | $ | 7,358 |  |  | 26% |  | $ | 27,802 |  |  | $ | (1,303 | ) |  | (4)% |  | $ | 29,105 |  |
| As a percentage of total revenues | 7% |  |  |  |  |  | 6% |  |  |  |  |  | 8% |
| Selling, general and administrative | 167,581 |  |  | 11,106 |  |  | 7% |  | 156,475 |  |  | 17,480 |  |  | 13% |  | 138,995 |  |
| As a percentage of total revenues | 35% |  |  |  |  |  | 35% |  |  |  |  |  | 37% |
| Gain on business combination | (3,443 | ) |  | (3,443 | ) |  | 100% |  | — |  |  | — |  |  | —% |  | — |  |
| Total operating expenses | $ | 199,298 |  |  | $ | 15,021 |  |  | 8% |  | $ | 184,277 |  |  | $ | 16,177 |  |  | 10% |  | $ | 168,100 |  |
| As a percentage of total revenues | 41% |  |  |  |  |  | 42% |  |  |  |  |  | 38% |
| Income from operations: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 104,294 |  |  | $ | 7,455 |  |  | 8% |  | $ | 96,839 |  |  | $ | 63,323 |  |  | 189% |  | $ | 33,516 |  |
| Operating margin | 27% |  |  |  |  |  | 27% |  |  |  |  |  | 11% |
| Medication Adherence | 5,294 |  |  | (5,212 | ) |  | (50)% |  | 10,506 |  |  | (4,385 | ) |  | (29)% |  | 14,891 |  |
| Operating margin | 6% |  |  |  |  |  | 12% |  |  |  |  |  | 19% |
| Corporate expenses ("Common") | (60,956 | ) |  | (3,194 | ) |  | 6% |  | (57,762 | ) |  | (44,654 | ) |  | 341% |  | (13,108 | ) |
| Total income from operations | $ | 48,632 |  |  | $ | (951 | ) |  | (2)% |  | $ | 49,583 |  |  | $ | 14,284 |  |  | 40% |  | $ | 35,299 |  |
| Total operating margin | 23% |  |  |  |  |  | 11% |  |  |  |  |  | 13% |

[0000926326-16-000044:mdna:118]
2015 compared to 2014:

[0000926326-16-000044:mdna:119]
Research and Development. Research and development expenses increased $7.4 million for the year ended December 31, 2015 as compared to year ended December 31, 2014, primarily driven by an increase of $8.7 million in our Automation and Analytics segment which was partially offset by decreases of $1.3 million in Medication Adherence segment. The increase in our Automation and Analytics segment was primarily attributable to a $2.9 million increase in headcount, a $1.9 million increase in consulting expenses and a $2.4 million increase in tools and equipment expenses, partially offset by an increase in capitalized software costs due to the higher level of post-feasibility beta testing. The decrease in research and development expenses in our Medication Adherence segment was primarily attributable to $1.5 million of additional capitalized software due to post-feasibility beta testing.

[0000926326-16-000044:mdna:120]
We expect research and development expenses to increase in 2016 as we continue to invest in new products and services, and increase as a percentage of total revenues from 7% to approximately 8%. The amount of research and development expenses can fluctuate based on the amount of prototype expenses for hardware and/or the amount of capitalized software development costs.

[0000926326-16-000044:mdna:121]
Selling, General and Administrative. Selling, general and administrative expenses increased $11.1 million for the year ended December 31, 2015 as compared to year ended December 31, 2014 due to increases from our Automation and Analytics segment of $2.9 million, Medication Adherence segment of $5.0 million and increases in corporate expenses of $3.2 million. The increase from our Automation and Analytics segment was attributed to the newly acquired companies Mach4 and Avantec by $4.1 million which was partially offset by decreases primarily in marketing and sales activities. The increase from our Medication Adherence segment was the result of $7.7 million from the inclusion of Surgichem operations for twelve months of 2015 in comparison to three months of 2014, with the remainder attributed to an increase in headcount specifically within our marketing and international departments. The increase in corporate expenses was primarily related to the newly acquired companies Mach4 and Avantec by $2.1 million and increase in acquisition related expenses of $2.9 million mainly due to the Aesynt acquisition.

[0000926326-16-000044:mdna:122]
We anticipate selling, general and administrative expenses as a percentage of total revenues to be stable throughout 2016, however this estimate could be impacted by ongoing business development activities and external macro-economic factors.

[0000926326-16-000044:mdna:123]
Operating Income. Operating income from our Automation and Analytics segment or the year ended December 31, 2015 in comparison to year ended December 31, 2014 due to increased revenues at consistent operating margins.

[0000926326-16-000044:mdna:124]
Operating income from our Medication Adherence segment decreased due to product mix, higher manufacturing costs, higher cost of service, and higher operating expenses.

[0000926326-16-000044:mdna:125]
2014 compared to 2013:

[0000926326-16-000044:mdna:126]
Research and development expenses decreased in our Automation and Analytics and Medication Adherence segments, primarily due to an increase of $3.2 million in the capitalization of software development costs in 2014 compared to 2013, partially offset by increased expenses of $2.7 million to further enhance our Pharmacy and Supply automation products. In our Medication Adherence segment, research and development decreased primarily due to the write-off of $1.8 million of capitalized software development costs in 2013 which did not recur in 2014, partially offset by an increase of $1.0 million in expenses to bring new medication adherence products to market, such as our M5000 packaging system.

[0000926326-16-000044:mdna:127]
Selling, general and administrative expenses increased due to increases from our Automation and Analytics segment of $15.6 million and Medication Adherence segment of $1.9 million. The increase from our Automation and Analytics segment was attributed to increases in salaries and wages of $4.0 million due to an increase in headcount, commission expenses of $1.5 million, facilities and infrastructure costs of $1.5 million, shipping costs of $1.5 million, GPO fees of $1.5 million and bad debt expense of $1.0 million with the remainder consisting of individually insignificant administrative expenses. The increase from our Medication Adherence segment was primarily the result of $1.0 million from the inclusion of Surgichem operations, with the remainder incurred from clinical studies and an increase in headcount specifically within our marketing and international businesses.

[0000926326-16-000044:mdna:128]
Income from our Automation and Analytics operations increased due to an increase in product and service revenues while operating margin increased as a result of lower cost of sales and operating expenses compared to the overall growth of revenues.

[0000926326-16-000044:mdna:129]
Income from our Medication Adherence operations slightly increased due to an increase in product revenues and the inclusion of Surgichem operations, and operating margin remained consistent with the prior year as product costs increased which offset the relative growth in product sales.

[0000926326-16-000044:mdna:130]
Provision for income taxes

[0000926326-16-000044:mdna:131]
|  |  |  | Change in |  |  |  | Change in |  |  |
|  | 2015 |  | $ |  | % |  | 2014 |  | $ |  | % |  | 2013 |
|  | (Dollars in thousands) |
| Provision for income taxes | $ | 15,484 |  |  | $ | (2,502 | ) |  | (14)% |  | $ | 17,986 |  |  | $ | 6,936 |  |  | 63% |  | $ | 11,050 |  |
| Effective tax rate on earnings | 34% |  |  |  |  |  | 37% |  |  |  |  |  | 32% |

[0000926326-16-000044:mdna:132]
2015 compared to 2014:

[0000926326-16-000044:mdna:133]
We recorded a provision for income taxes of $15.5 million and an effective tax rate of 34% for the year ended December 31, 2015, compared to $18.0 million and an effective tax rate of 37% for the year ended December 31, 2014. The 2015 annual effective tax rate differed from the statutory tax rate of 35%, primarily due to the unfavorable impact of state income taxes, non-deductible equity charges under ASC 740-718, and other non-deductible expenditures, including non-deductible acquisition costs, all of which were partially offset by the domestic production activities deduction and the federal

[0000926326-16-000044:mdna:134]
research tax credit, which was reinstated in December 2015, retroactive to the beginning of the year. The decrease in the annual effective tax rate as compared to 2014 was primarily due to the inclusion of the gain on the investment in Avantec recorded in the quarter ended June 30, 2015. This gain attributable to the increase in the fair value of Omnicell's 15% minority interest in Avantec which was revalued in conjunction with our purchase of the remaining 85% of Avantec shares is not included in taxable income.

[0000926326-16-000044:mdna:135]
2014 compared to 2013:

[0000926326-16-000044:mdna:136]
We recorded a provision for income taxes of $18.0 million and an effective tax rate of 37% for the year ended December 31, 2014, compared to $11.1 million and an effective tax rate of 32% for the year ended December 31, 2013. The 2014 annual effective tax rate differed from the statutory tax rate of 35%, primarily due to the unfavorable impact of state income taxes, non-deductible equity charges under ASC 740-718, and other non-deductible expenditures, including non-deductible acquisition costs, all of which were partially offset by the domestic production activities deduction and the federal research tax credit, which was reinstated in December 2014, retroactive to the beginning of the year. The increase in the annual effective tax rate as compared to 2013 was primarily due to non-deductible transaction costs incurred as a result of the Surgichem acquisition, combined with the absence of the impact of the 2013 tax rate reduction in the United Kingdom, as well as reinstatement of the federal research credit in January 2013, retroactive to 2012.

[0000926326-16-000044:mdna:137]
Refer to Note 9, Income Taxes, of the Notes to Consolidated Financial Statements included in this annual report for further discussion about the factors affecting our ability to realize deferred tax assets.

[0000926326-16-000044:mdna:138]
LIQUIDITY AND CAPITAL RESOURCES

[0000926326-16-000044:mdna:139]
Sources of Cash

[0000926326-16-000044:mdna:140]
We had cash and cash equivalents of $82.2 million at December 31, 2015, compared to $125.9 million at December 31, 2014. All of our cash and cash equivalents are invested in demand deposits and money market funds.

[0000926326-16-000044:mdna:141]
Our cash position and working capital at December 31, 2015 and December 31, 2014 were as follows:

[0000926326-16-000044:mdna:142]
|  | December 31, 2015 |  | December 31, 2014 |
|  | (In thousands) |
| Cash | $ | 72,103 |  |  | $ | 61,311 |  |
| Cash equivalents | 10,114 |  |  | 64,577 |  |
| Total | $ | 82,217 |  |  | $ | 125,888 |  |
| Working Capital | $ | 139,498 |  |  | $ | 171,054 |  |

[0000926326-16-000044:mdna:143]
Our ratio of current assets to current liabilities was 2.1:1 at December 31, 2015 compared to 2.5:1 at December 31, 2014.

[0000926326-16-000044:mdna:144]
On January 5, 2016, we entered into a $400 million secured credit facility pursuant to a credit agreement, by and among us, the lenders from time to time party thereto, Wells Fargo Securities, LLC, as sole lead arranger and Wells Fargo Bank, National Association, as administrative agent (the “Credit Agreement”). The Credit Agreement provides for a $200 term loan facility (the “Term Loan Facility”) and a $200 million revolving credit facility (the “Revolving Credit Facility” and together with the Term Loan Facility, the “Facilities”). At the closing of the Aesynt Acquisition, we borrowed $255 million in secured debt under the Credit Agreement, consisting of $200 million of term loans and $55 million of revolving loans to complete the acquisition of Aesynt and to pay related fees and expenses. In addition, the Credit Agreement includes a letter of credit sub-limit of up to $10 million and a swing line loan sub-limit of up to $10 million. We expect to use future loans under the Revolving Credit Facility, if any, for general corporate purposes. The Credit Agreement replaces our existing Credit Agreement, dated as of September 25, 2013, by and among the Company, the lenders from time to time party thereto and Wells Fargo Bank, National Association, as administrative agent, as amended.

[0000926326-16-000044:mdna:145]
Loans under the Facilities bear interest, at our option, at a rate equal to either (a) the LIBOR Rate, plus an applicable margin ranging from 1.50% to 2.25% per annum based on the our Consolidated Total Net Leverage Ratio (as defined in the Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%,

[0000926326-16-000044:mdna:146]
and (iii) LIBOR for an interest period of one month, plus an applicable margin ranging from 0.50% to 1.25% per annum based on our Consolidated Total Net Leverage Ratio (as defined in the Credit Agreement). Undrawn commitments under the Revolving Credit Facility will be subject to a commitment fee ranging from 0.20% to 0.35% per annum based on our Consolidated Total Net Leverage Ratio on the average daily unused portion of the Revolving Credit Facility. A letter of credit participation fee ranging from 1.50% to 2.25% per annum based on our Consolidated Total Net Leverage Ratio will accrue on the average daily amount of letter of credit exposure.

[0000926326-16-000044:mdna:147]
The Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to us and our subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends and other distributions. The Credit Agreement contains financial covenants that require us and our subsidiaries to not exceed a maximum consolidated total leverage ratio and maintain a minimum fixed charge coverage ratio. The Credit Agreement also includes financial covenants requiring us not to exceed a maximum consolidated total leverage ratio of 3.00:1 (subject to certain exceptions) and to maintain a minimum fixed charge coverage ratio of 1.50:1.

[0000926326-16-000044:mdna:148]
As of December 31, 2015, we were in full compliance with all covenants, and there was no outstanding balance on the Facilities.

[0000926326-16-000044:mdna:149]
Uses of Cash

[0000926326-16-000044:mdna:150]
Our future uses of cash are expected to be primarily for working capital, capital expenditures, loan principal and interest payments, and other contractual obligations. We also expect a continued use of cash for potential acquisition and acquisition assessment activities.

[0000926326-16-000044:mdna:151]
On January 5, 2016, we completed the acquisition of all of the membership interests of Aesynt pursuant to the Securities Purchase Agreement. The purchase price paid by us was approximately $280 million, including the repayment of Aesynt indebtedness and after adjustments provided for in the Securities Purchase Agreement. The acquisition was funded with cash-on-hand and borrowings under the Credit Agreement. Upon settling the Aesynt acquisition purchase price, the remaining balance available under the five-year revolving credit facility with Wells Fargo Securities, LLC, was $145 million. In addition, the Credit Agreement includes a letter of credit sub limit of up to $10 million and a swing line loan sub-limit of up to $10 million.

[0000926326-16-000044:mdna:152]
Our stock repurchase programs have a total of $4.9 million remaining for future repurchases as of December 31, 2015, which may result in additional use of cash. See Note 10, Stock Repurchases, of the Notes to Consolidated Financial Statements included in this annual report. In accordance with the Avantec share purchase agreement, we may pay out potential earn-out payments of $3.0 million payable in the first half of 2016 and an additional $3.0 million payable after December 31, 2016, based on booking targets. The fair value of these earn-out payments as of the acquisition date was $5.6 million. Pursuant to the terms of the agreement we also held back $1.8 million from the purchase consideration towards any future indemnification claims that we may release at the end of the 18-month period or in the fourth quarter of 2016.

[0000926326-16-000044:mdna:153]
Based on our current business plan and revenue backlog, we believe that our existing cash and cash equivalents, our anticipated cash flows from operations, cash generated from the exercise of employee stock options and purchases under our employee stock purchase plan, along with the availability of funds under the Facilities will be sufficient to meet our cash needs for working capital, capital expenditures, potential acquisitions, and other contractual obligations for at least the next twelve months. For periods beyond the next twelve months, we also anticipate that our net operating cash flows plus existing balances of cash and cash equivalents will suffice to fund the continued growth of our business.

[0000926326-16-000044:mdna:154]
Cash Flows

[0000926326-16-000044:mdna:155]
The following table summarizes, for the periods indicated, selected items in our Consolidated Statements of Cash Flows:

[0000926326-16-000044:mdna:156]
|  | Year Ended |
|  | December 31, 2015 |  | December 31, 2014 |  | December 31, 2013 |
|  | (In thousands) |
| Net cash provided by (used in): |  |  |  |  |  |
| Operating activities | $ | 33,762 |  |  | $ | 65,163 |  |  | $ | 55,263 |  |
| Investing activities | (45,596 | ) |  | (43,325 | ) |  | (20,452 | ) |
| Financing activities | (31,833 | ) |  | (206 | ) |  | 7,374 |  |
| Effect of exchange rate changes on cash and cash equivalents | (4 | ) |  | (275 | ) |  | 33 |  |
| Net increase (decrease) in cash and cash equivalents | $ | (43,671 | ) |  | $ | 21,357 |  |  | $ | 42,218 |  |

[0000926326-16-000044:mdna:157]
Operating activities

[0000926326-16-000044:mdna:158]
We expect cash from our operating activities to fluctuate in future periods as a result of a number of factors, including the timing of our billings and collections, our operating results and the timing of other liability payments.

[0000926326-16-000044:mdna:159]
Net cash provided by operating activities was $33.8 million for 2015, primarily as a result of $30.8 million in net income adjusted for non-cash items and changes in assets and liabilities, the non-cash items primarily consisted of depreciation and amortization expense of $25.6 million, share-based compensation expense of $14.9 million, and $3.4 million from our investment gain. This was offset by $33.8 million cash outflow from changes in assets and liabilities resulting primarily from i) an increase in accounts receivable of $18.3 million due to increased product shipments late in the quarter, ii) an increase in inventories of $10.4 million to support forecasted sales, iii) increase in long-term net investment in sales-type leases of $4.7 million due to timing,  iv) a decrease in deferred gross profit of $2.6 million due to timing of orders, shipments, and revenue being recognized for installed product, iv) a decrease in deferred service revenue of $2.9 million due to timing of orders and revenue being recognized for installed product, and v) a decrease in accrued compensation of $2.0 million primarily due to lower sales commissions. These amounts were partially offset by an increase in accrued liabilities of $5.5 million primarily due to potential earn-out and contingent payment of $3.0 million related to the Avantec Acquisition, and a decrease in the prepaid expenses of $4.0 million primarily due to commissions driven by higher bookings in the fourth quarter of 2014 compared to the current year to date period.

[0000926326-16-000044:mdna:160]
Net cash provided by operating activities was $65.2 million for 2014, primarily as a result of $30.5 million in net income adjusted for non-cash items, including depreciation and amortization expense of $20.3 million and share-based compensation expense of $12.8 million, an increase in deferred gross profit of $8.6 million, an increase in accrued liabilities of $5.5 million and an increase in deferred service revenue of $5.1 million. These amounts were partially offset by an increase in accounts receivable, net of $22.8 million.

[0000926326-16-000044:mdna:161]
Net cash provided by operating activities was $55.3 million for 2013, primarily as a result of $24.0 million in net income adjusted for non-cash items, including depreciation and amortization expense of $18.4 million and share-based compensation expense of $11.2 million.

[0000926326-16-000044:mdna:162]
Investing activities

[0000926326-16-000044:mdna:163]
Net cash used in investing activities was $45.6 million for 2015,  $25.5 million of which was attributable to the acquisitions of Mach4 and Avantec, and capital expenditures related to purchases of property and equipment and software development of software costs for external use of $7.5 million and $12.1 million, respectively.

[0000926326-16-000044:mdna:164]
Net cash used in investing activities was $43.3 million for 2014, primarily due to payments of $20.7 million for the acquisition of Surgichem, $11.9 million for property and equipment and $10.4 million to develop software for external use.

[0000926326-16-000044:mdna:165]
Net cash used in investing activities was $20.5 million for 2013 and was due to payments of $12.3 million for property and equipment and $7.8 million to develop software for external use.

[0000926326-16-000044:mdna:166]
Financing activities

[0000926326-16-000044:mdna:167]
Net cash used in financing activities was $31.8 million for 2015 as a result of $50.0 million in cash used for stock repurchases under our 2012 and 2014 Stock Repurchase Programs and $3.6 million in employees taxes paid in relation to restricted stock units, partially offset by $17.1 million in proceeds from employee stock option exercises and employee stock plan purchases and $4.7 million in excess tax benefits from employee stock plans.

[0000926326-16-000044:mdna:168]
Net cash used in financing activities was $0.2 million for 2014 as a result of $24.1 million in repurchases of our common stock, partially offset by $21.8 million in net proceeds from sales of common stock through employee stock plans.

[0000926326-16-000044:mdna:169]
Net cash provided by financing activities was $7.4 million for 2013 as a result of $26.9 million in net proceeds from sales of common stock through employee stock plans, partially offset by $21.0 million in repurchases of our common stock.

[0000926326-16-000044:mdna:170]
Contractual Obligations

[0000926326-16-000044:mdna:171]
We had $66.9 million in contractual commitments to third parties for non-cancelable operating leases, commitments to contract manufacturers and suppliers and other purchase commitments as of December 31, 2015 as follows:

[0000926326-16-000044:mdna:172]
|  | Payments Due by Period |
|  | Total |  | 2016 |  | 2017 and 2018 |  | 2019 and 2020 |  | 2021 and Thereafter |
|  | (In thousands) |
| Operating leases (1) | $ | 38,660 |  |  | $ | 6,827 |  |  | $ | 11,407 |  |  | $ | 10,343 |  |  | $ | 10,083 |  |
| Purchase obligations (2) | 28,262 |  |  | 28,262 |  |  | — |  |  | — |  |  | — |  |
| Total (3) | $ | 66,922 |  |  | $ | 35,089 |  |  | $ | 11,407 |  |  | $ | 10,343 |  |  | $ | 10,083 |  |

[0000926326-16-000044:mdna:173]
_________________________________________________

[0000926326-16-000044:mdna:174]
| (1) | Commitments under operating leases relate primarily to leased property and office equipment. Rent expense was $7.0 million, $6.8 million and $6.9 million for the years ended December 31, 2015, December 31, 2014 and December 31, 2013, respectively. |

[0000926326-16-000044:mdna:175]
| (2) | We purchase components from a variety of suppliers and use contract manufacturers to provide manufacturing services for our products. During the normal course of business, we issue purchase orders with estimates of our requirements several months ahead of the delivery dates. These amounts are associated with agreements that are enforceable and legally binding. The amounts under such contracts are included in the table above because we believe that cancellation of these contracts is unlikely and we expect to make future cash payments according to the contract terms or in similar amounts for similar materials. |

[0000926326-16-000044:mdna:176]
| (3) | We have recorded $7.2 million for uncertain tax positions as of December 31, 2015 in accordance with the authoritative guidance summarized in the section entitled "Critical Accounting Policies and Estimates" above. As these liabilities do not reflect actual tax assessments, the timing and amount of payments we might be required to make will depend upon a number of factors. Accordingly, as the timing and amount of payment cannot be estimated, $7.2 million in uncertain tax position liabilities have not been included in the table above. See Note 9, Income Taxes, of the Notes to Consolidated Financial Statements included in this annual report. |

[0000926326-16-000044:mdna:177]
See Note 8, Commitments and Contingencies, of the Notes to Consolidated Financial Statements included in this annual report.

[0000926326-16-000044:mdna:178]
Off-Balance Sheet Arrangements

[0000926326-16-000044:mdna:179]
As of December 31, 2015, we had no off-balance sheet arrangements as defined under Regulation S-K 303(a)(4) of the Securities Exchange Act of 1934, as amended, and the instructions thereto.
