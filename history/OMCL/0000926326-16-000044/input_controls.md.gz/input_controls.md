# OMCL 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: no heading matched.


## item_9a

[0000926326-16-000044:item_9a:1]
ITEM 9A. CONTROLS AND PROCEDURES

[0000926326-16-000044:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0000926326-16-000044:item_9a:3]
Based on such evaluation, our principal executive officer and principal financial officer have concluded that our disclosure controls and procedures were effective at the reasonable assurance level as of December 31, 2015.

[0000926326-16-000044:item_9a:4]
Management's Report on Internal Control Over Financial Reporting

[0000926326-16-000044:item_9a:5]
Our management is responsible for establishing and maintaining adequate internal control over financial reporting (as such term is defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act). Our internal control system is designed to provide reasonable assurance regarding the preparation and fair presentation of financial statements for external purposes in accordance with U.S. generally accepted accounting principles. All internal control systems, no matter how well designed, have inherent limitations and can provide only reasonable assurance that the objectives of the internal control system are met.

[0000926326-16-000044:item_9a:6]
Under the supervision and with the participation of our management, including our principal executive officer and principal financial officer, we conducted an evaluation of the effectiveness of our internal control over financial reporting as of December 31, 2015 using the criteria for effective internal control over financial reporting as described in "Internal Control—Integrated Framework," issued by the Committee of Sponsoring Organization of the Treadway Commission (2013 framework) (the COSO Criteria). Based on this assessment, management concluded that our internal control over financial reporting was effective as of December 31, 2015.

[0000926326-16-000044:item_9a:7]
We have excluded Mach4 Automatisierungstechnik GmbH (“Mach4”) and Avantec Healthcare Limited (“Avantec”), which were acquired by us during fiscal year ended December 31, 2015, from our assessment of internal control over financial reporting as of December 31, 2015. Mach4 and Avantec are wholly-owned by Omnicell with total assets and total revenue representing 9% and 4%, respectively, of the related consolidated financial statement amounts as of and for the year ended December 31, 2015.

[0000926326-16-000044:item_9a:8]
Our independent registered public accounting firm, Deloitte & Touche LLP, has issued its attestation report on our internal control over financial reporting as of December 31, 2015, which is included in Part IV, Item 15 of this annual report.

[0000926326-16-000044:item_9a:9]
Changes in Internal Control Over Financial Reporting

[0000926326-16-000044:item_9a:10]
There have been no changes in our internal control over financial reporting (as such term is defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act) that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting during the year ended December 31, 2015.
