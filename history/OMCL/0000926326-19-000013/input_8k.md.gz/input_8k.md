# OMCL 8-K — 0000926326-19-000011 filed 2019-04-25

## item codes, every 8-K on or before 2019-05-03

- 2019-04-25 0000926326-19-000011 — 2.02, 9.01
- 2019-03-08 0000926326-19-000009 — 5.02, 9.01
- 2019-02-19 0000926326-19-000005 — 5.02, 9.01
- 2019-02-07 0000926326-19-000003 — 2.02, 9.01
- 2018-10-25 0000926326-18-000028 — 2.02, 9.01
- 2018-09-14 0001104659-18-056929 — 5.02, 9.01
- 2018-07-26 0000926326-18-000022 — 2.02, 9.01
- 2018-06-06 0000926326-18-000019 — 5.02, 9.01
- 2018-05-16 0001104659-18-033801 — 5.07
- 2018-04-26 0000926326-18-000013 — 2.02, 9.01
- 2018-03-02 0001104659-18-014497 — 5.02
- 2018-02-08 0000926326-18-000007 — 5.02
- 2018-02-02 0000926326-18-000005 — 5.02
- 2018-02-01 0000926326-18-000003 — 2.02, 9.01
- 2017-12-26 0000926326-17-000041 — 1.01, 2.03, 9.01
- 2017-11-03 0001104659-17-066102 — 1.01, 8.01, 9.01
- 2017-10-26 0000926326-17-000035 — 2.02, 9.01
- 2017-08-03 0000926326-17-000028 — 5.07 — amendment, the index does not say of what
- 2017-07-27 0000926326-17-000026 — 2.02, 9.01
- 2017-07-25 0000926326-17-000023 — 5.02, 9.01
- 2017-05-24 0000926326-17-000019 — 5.07
- 2017-05-04 0001628280-17-004851 — 2.02, 9.01
- 2017-02-15 0000926326-17-000010 — 2.05
- 2017-02-15 0000926326-17-000008 — 2.02, 9.01
- 2017-02-13 0000926326-17-000002 — 5.02
- 2016-12-08 0001104659-16-161330 — 2.01, 2.03, 9.01
- 2016-12-06 0001104659-16-160709 — 7.01
- 2016-11-29 0001104659-16-159456 — 1.01, 7.01, 9.01
- 2016-10-27 0000926326-16-000075 — 2.02, 9.01
- 2016-10-07 0000926326-16-000072 — 5.02, 8.01
- 2016-08-05 0000926326-16-000068 — 8.01
- 2016-07-28 0000926326-16-000066 — 2.02, 9.01
- 2016-06-13 0001104659-16-126854 — 5.02
- 2016-05-25 0000926326-16-000060 — 5.07
- 2016-04-28 0000926326-16-000054 — 2.02, 9.01
- 2016-03-21 0001104659-16-106649 — 8.01, 9.01
- 2016-03-17 0000926326-16-000051 — 7.01, 9.01
- 2016-03-17 0000926326-16-000049 — 9.01 — amendment of 0000926326-16-000051
- 2016-02-10 0001104659-16-095486 — 5.02, 9.01
- 2016-02-04 0000926326-16-000041 — 2.02, 9.01
- 2016-01-06 0001104659-16-088299 — 1.01, 2.01, 2.03, 9.01
- 2015-12-10 0000926326-15-000038 — 8.01, 9.01
- 2015-10-29 0001104659-15-074138 — 1.01, 9.01
- 2015-10-29 0000926326-15-000031 — 2.02, 9.01
- 2015-08-20 0001104659-15-061135 — 5.02, 9.01
- 2015-07-30 0000926326-15-000024 — 2.02, 9.01
- 2015-05-22 0001104659-15-040440 — 5.07
- 2015-05-01 0001104659-15-032846 — 5.02
- 2015-05-01 0001104659-15-032844 — 7.01
- 2015-04-30 0000926326-15-000015 — 9.01
- 2015-04-22 0001104659-15-029356 — 8.01, 9.01
- 2015-03-20 0001104659-15-021435 — 3.01
- 2015-03-18 0001104659-15-020699 — 7.01
- 2015-03-17 0001104659-15-020483 — 8.01, 9.01
- 2015-03-02 0001104659-15-015802 — 1.01, 9.01
- 2015-02-12 0001104659-15-009234 — 5.02, 9.01
- 2015-02-03 0000926326-15-000003 — 9.01
- 2015-01-15 0001104659-15-002635 — 5.02
- 2014-11-07 0001104659-14-078398 — 1.01, 8.01, 9.01
- 2014-10-30 0000926326-14-000037 — 2.02, 9.01
- 2014-08-25 0001104659-14-062772 — 8.01, 9.01
- 2014-07-31 0000926326-14-000032 — 2.02, 9.01
- 2014-05-21 0001104659-14-040744 — 5.07
- 2014-05-01 0000926326-14-000008 — 2.02, 9.01
- 2014-04-08 0001104659-14-026441 — 4.01, 9.01
- 2014-04-02 0001104659-14-025179 — 5.02
- 2014-02-07 0001104659-14-007552 — 5.02, 9.01
- 2014-02-04 0001104659-14-006352 — 2.02, 9.01
- 2013-12-09 0001104659-13-088980 — 1.01, 9.01
- 2013-12-02 0001104659-13-087877 — 5.02
- 2013-10-31 0001104659-13-079660 — 2.02, 9.01
- 2013-09-26 0001104659-13-072435 — 1.01, 2.03, 9.01
- 2013-08-01 0001104659-13-058959 — 2.02, 9.01
- 2013-05-23 0001104659-13-044317 — 5.07
- 2013-05-02 0001104659-13-036605 — 2.02, 9.01
- 2013-03-11 0001104659-13-019143 — 8.01
- 2013-02-07 0001104659-13-008477 — 5.02, 9.01
- 2013-01-31 0001104659-13-006446 — 2.02, 9.01
- 2012-11-02 0001104659-12-073697 — 5.02
- 2012-10-25 0001104659-12-071211 — 2.02, 9.01
- 2012-08-06 0001104659-12-054635 — 8.01
- 2012-08-03 0001104659-12-054214 — 2.01, 9.01 — amendment of 0001104659-12-038888
- 2012-08-01 0001104659-12-053005 — 2.02, 9.01
- 2012-06-12 0001104659-12-042936 — 8.01, 9.01
- 2012-05-23 0001104659-12-039459 — 5.07
- 2012-05-22 0001104659-12-038888 — 2.01, 9.01
- 2012-05-02 0001104659-12-032048 — 2.02, 9.01
- 2012-05-02 0001104659-12-032036 — 1.01, 9.01
- 2012-04-04 0001104659-12-023883 — 5.02, 8.01
- 2012-03-20 0001104659-12-019462 — 1.01, 9.01
- 2012-02-13 0001104659-12-009353 — 5.02, 9.01
- 2012-01-26 0001104659-12-004244 — 2.02, 9.01
- 2011-10-27 0001104659-11-058464 — 2.02, 9.01
- 2011-10-25 0001104659-11-057721 — 1.01
- 2011-07-28 0001104659-11-041505 — 2.02, 9.01
- 2011-05-27 0001104659-11-032006 — 5.07
- 2011-05-02 0001104659-11-024908 — 2.02, 9.01
- 2011-04-15 0001104659-11-020407 — 5.02, 9.01 — amendment of 0001104659-11-005638
- 2011-02-08 0001104659-11-005638 — 5.02, 9.01
- 2011-01-27 0001104659-11-003419 — 2.02, 9.01
- 2010-12-22 0001104659-10-064003 — 5.02, 5.07, 9.01
- 2010-10-27 0001104659-10-054036 — 2.02, 9.01
- 2010-10-05 0001104659-10-051173 — 8.01
- 2010-07-22 0001104659-10-039126 — 2.02, 9.01
- 2010-07-09 0001104659-10-037594 — 2.05
- 2010-05-28 0001104659-10-031607 — 5.07
- 2010-04-26 0001104659-10-021797 — 2.02, 9.01
- 2010-03-17 0001104659-10-014849 — 5.02, 9.01
- 2010-02-08 0001104659-10-005457 — 5.02, 9.01
- 2010-01-28 0001104659-10-003627 — 2.02, 9.01
- 2009-10-22 0001104659-09-059972 — 2.02, 9.01
- 2009-07-23 0001104659-09-044508 — 2.02, 9.01
- 2009-05-20 0001104659-09-033938 — 5.02, 9.01
- 2009-04-30 0001104659-09-027707 — 2.02, 9.01
- 2009-03-10 0001104659-09-016178 — 5.02, 9.01
- 2009-02-09 0001104659-09-007692 — 5.02, 9.01
- 2009-01-29 0001104659-09-005022 — 2.02, 2.05, 9.01
- 2009-01-21 0001104659-09-003180 — 2.02, 8.01, 9.01
- 2009-01-06 0001104659-09-000625 — 5.02
- 2008-10-23 0001104659-08-065475 — 2.02, 9.01
- 2008-07-21 0001104659-08-046690 — 2.02, 9.01
- 2008-05-16 0001104659-08-034035 — 8.01, 9.01
- 2008-04-28 0001104659-08-027379 — 7.01, 9.01
- 2008-04-21 0001104659-08-025616 — 2.02, 9.01
- 2008-03-12 0001104659-08-016939 — 7.01, 9.01
- 2008-02-26 0001104659-08-012840 — 7.01, 9.01
- 2008-02-12 0001104659-08-009382 — 5.02, 9.01
- 2008-01-31 0001104659-08-006199 — 2.02, 9.01
- 2007-12-05 0001104659-07-087191 — 1.01, 9.01
- 2007-10-18 0001104659-07-075654 — 2.02, 9.01
- 2007-07-27 0001104659-07-056886 — 5.03, 9.01
- 2007-07-19 0001104659-07-054924 — 2.02, 9.01
- 2007-05-23 0001104659-07-042287 — 8.01, 9.01
- 2007-05-07 0001104659-07-036172 — 1.01, 5.02, 9.01
- 2007-04-24 0001104659-07-030578 — 2.02, 9.01 — amendment, the index does not say of what
- 2007-04-24 0001104659-07-030547 — 2.02, 9.01
- 2007-04-10 0001104659-07-027465 — 5.02, 9.01
- 2007-03-23 0001104659-07-021969 — 2.02, 4.02, 9.01
- 2007-01-30 0001104659-07-005772 — 2.02, 9.01
- 2007-01-09 0001104659-07-001600 — 5.02, 9.01
- 2006-10-30 0001104659-06-069612 — 1.01
- 2006-10-19 0001104659-06-067549 — 2.02, 9.01
- 2006-07-20 0001104659-06-048020 — 2.02, 4.02, 9.01
- 2006-05-17 0001104659-06-035522 — 1.01, 9.01 — amendment of 0001104659-05-011155
- 2006-05-09 0001104659-06-032706 — 1.01, 9.01
- 2006-04-25 0001104659-06-027438 — 2.02, 9.01
- 2006-04-04 0001104659-06-022204 — 1.01, 9.01
- 2006-03-15 0001104659-06-016861 — 1.01, 9.01
- 2006-01-30 0001104659-06-004749 — 2.02, 9.01
- 2006-01-24 0001104659-06-003504 — 1.01, 5.02, 9.01
- 2005-12-13 0001104659-05-060532 — 1.01, 9.01
- 2005-11-10 0001104659-05-054663 — 2.02, 9.01
- 2005-07-21 0001104659-05-033464 — 2.02, 9.01
- 2005-06-22 0001104659-05-029255 — 1.01
- 2005-05-16 0001104659-05-023473 — 2.02, 9.01 — amendment of 0001104659-05-018173
- 2005-05-16 0001104659-05-023471 — 2.02, 9.01 — amendment of 0001104659-05-017382
- 2005-05-10 0001104659-05-022127 — 1.01
- 2005-04-26 0001104659-05-018173 — 2.02, 9.01
- 2005-04-21 0001104659-05-017382 — 2.02, 9.01
- 2005-04-06 0001104659-05-015401 — 5.02
- 2005-03-15 0001104659-05-011155 — 1.01, 9.01
- 2005-03-08 0001104659-05-009975 — 1.01, 9.01
- 2005-02-03 0001104659-05-003943 — 2.02, 9.01
- 2005-01-13 0001104659-05-001314 — 5.02, 9.01
- 2004-10-21 0001104659-04-031413 — 2.02, 9.01
- 2004-07-22 0001104659-04-020572 — 12, 7
- 2004-04-14 0001104659-04-010039 — 12, 7
- 2004-04-05 0001104659-04-009437 — 12, 7
- 2004-01-26 0001104659-04-001655 — 12, 7
- 2003-10-16 0001104659-03-022990 — 12, 7
- 2003-07-17 0001104659-03-015053 — 9
- 2003-04-18 0001104659-03-006823 — 7, 9
- 2003-02-14 0001104659-03-002607 — 5, 7

## late-filing notifications on or before 2019-05-03

- 2015-03-02 0000926326-15-000006 — NT 10-K, for the period ended 2014-12-31
- 2007-03-16 0001104659-07-020094 — NT 10-K, for the period ended 2006-12-31

## item 2.02 — earnings release, exhibit 99.1

[0000926326-19-000011:8k_2_02:1]
EX-99.1
2
exhibit991q119.htm
EXHIBIT 99.1

[0000926326-19-000011:8k_2_02:2]
Exhibit

[0000926326-19-000011:8k_2_02:3]
Exhibit 99.1

[0000926326-19-000011:8k_2_02:4]
| Contact: |  |  |
| Peter Kuipers |  | Omnicell, Inc. |
| Chief Financial Officer |  | 590 East Middlefield Road |
| 800-850-6664 |  | Mountain View, CA 94043 |
| Peter.Kuipers@Omnicell.com |  |  |

[0000926326-19-000011:8k_2_02:5]
Omnicell Reports Results for First Quarter 2019

[0000926326-19-000011:8k_2_02:6]
GAAP and non-GAAP revenues of $202.5 million, up 10.9% year-over-year

[0000926326-19-000011:8k_2_02:7]
GAAP net income per diluted share of $0.08, up 14.3% year-over-year

[0000926326-19-000011:8k_2_02:8]
Non-GAAP net income per diluted share of $0.61, up 110.3% year-over-year

[0000926326-19-000011:8k_2_02:9]
MOUNTAIN VIEW, Calif. -- April 25, 2019 -- Omnicell, Inc. (NASDAQ: OMCL), a leading provider of medication and supply management solutions to healthcare systems, today announced results for its first quarter ended March 31, 2019.

[0000926326-19-000011:8k_2_02:10]
GAAP Results

[0000926326-19-000011:8k_2_02:11]
GAAP revenues for the first quarter of 2019 were $202.5 million, up $19.9 million, or 10.9% from the first quarter of 2018.

[0000926326-19-000011:8k_2_02:12]
First quarter 2019 GAAP net income as reported was $3.3 million, or $0.08 per diluted share. This compares to GAAP net income of $2.7 million, or $0.07 per diluted share, for the first quarter of 2018.

[0000926326-19-000011:8k_2_02:13]
Non-GAAP Results

[0000926326-19-000011:8k_2_02:14]
Non-GAAP revenues for the first quarter of 2019 were $202.5 million, up $19.9 million, or 10.9%, from the first quarter of 2018.

[0000926326-19-000011:8k_2_02:15]
Non-GAAP net income for the first quarter of 2019 was $25.8 million, or $0.61 per diluted share. This compares to non-GAAP net income of $11.5 million, or $0.29 per diluted share, for the first quarter of 2018.

[0000926326-19-000011:8k_2_02:16]
Non-GAAP net income for each period excludes, when applicable, the effect of share-based compensation expense, amortization expense of acquired intangible assets, acquisition-related expenses, fair value adjustments related to business acquisitions, restructuring and severance-related expenses, tax reform and restructuring income tax benefits and expenses, contingent gains, and amortization of debt issuance cost.

[0000926326-19-000011:8k_2_02:17]
“We believe that customers and the market are embracing our Autonomous Pharmacy vision and the impact that advanced automation, data intelligence, and expert services will have on patient care,” said Randall A. Lipps, chairman, president, chief executive officer, and founder of Omnicell. “Our solutions are designed to drive improvement in patient and provider outcomes in a variety of healthcare settings across the continuum of care, with medication management automation becoming central to their success.”

[0000926326-19-000011:8k_2_02:18]
2019 Guidance

[0000926326-19-000011:8k_2_02:19]
For the second quarter of 2019, the Company expects non-GAAP total revenues to be between $211 million and $217 million. The Company expects non-GAAP product revenues to be between $153 million and $158 million, and non-GAAP service revenues to be between $58 million and $59 million. The Company expects second quarter 2019 non-GAAP earnings to be between $0.61 and $0.66 per share.

[0000926326-19-000011:8k_2_02:20]
For the year 2019, the Company expects product bookings to be between $745 million and $780 million. The Company expects non-GAAP total revenues to be between $880 million and $900 million. The Company expects non-GAAP product revenues to be

[0000926326-19-000011:8k_2_02:21]
between $652 million and $668 million, and non-GAAP service revenues to be between $228 million and $232 million. The Company expects 2019 non-GAAP earnings to be between $2.62 and $2.82 per share.

[0000926326-19-000011:8k_2_02:22]
The table below summarizes 2019 guidance outlined above.

[0000926326-19-000011:8k_2_02:23]
|  | Q2'19 | 2019 |
| Product Bookings | Not provided | $745 million - $780 million |
| Non-GAAP Total Revenues | $211 million - $217 million | $880 million - $900 million |
| Non-GAAP Product Revenues | $153 million - $158 million | $652 million - $668 million |
| Non-GAAP Service Revenues | $58 million - $59 million | $228 million - $232 million |
| Non-GAAP EPS | $0.61 - $0.66 | $2.62 - $2.82 |

[0000926326-19-000011:8k_2_02:24]
Omnicell Conference Call Information

[0000926326-19-000011:8k_2_02:25]
Omnicell will hold a conference call today, Thursday, April 25, 2019 at 1:30 p.m. PT to discuss first quarter financial results. The conference call can be monitored by dialing 1-800-696-5518 within the U.S. or 1-706-758-4883 for all other locations. The Conference ID # is 1788166. Internet users can access the conference call at http://ir.omnicell.com/communications/events-presentations. A replay of the call will be available today at approximately 4:30 p.m. PT and will be available until 11:59 p.m. PT on May 24, 2019. The replay access numbers are 1-855-859-2056 within the U.S. and 1-404-537-3406 for all other locations, Conference ID # is 1788166.

[0000926326-19-000011:8k_2_02:26]
About Omnicell

[0000926326-19-000011:8k_2_02:27]
Since 1992, Omnicell has been inspired to create safer and more efficient ways to manage medications across all care settings. Through our industry-leading medication management platform that spans the continuum of care, Omnicell is developing a vision for a fully automated infrastructure, powered by a cloud data platform that supports improved patient care, fewer errors, enhanced safety, and new opportunities for growth.

[0000926326-19-000011:8k_2_02:28]
Omnicell’s vision for the Autonomous Pharmacy integrates a comprehensive set of solutions across three key areas: Automation solutions designed to digitize and streamline workflows; Intelligence that provides actionable insights to better understand medication usage and improve pharmacy supply chain management; and Work - expert services that serve as an extension of pharmacy operations to support improved efficiency, regulatory compliance, and patient outcomes.

[0000926326-19-000011:8k_2_02:29]
Over 5,500 facilities worldwide use Omnicell automation and analytics solutions to help increase operational efficiency, reduce medication errors, deliver actionable intelligence, and improve patient safety. More than 40,000 institutional and retail pharmacies across North America and the United Kingdom leverage Omnicell's innovative medication adherence solutions designed to improve patient engagement and adherence to prescriptions, helping to reduce costly hospital readmissions.

[0000926326-19-000011:8k_2_02:30]
For more information about Omnicell, Inc. please visit www.omnicell.com.

[0000926326-19-000011:8k_2_02:31]
Omnicell and the Omnicell logo are registered trademarks of Omnicell, Inc. in the United States and other countries.

[0000926326-19-000011:8k_2_02:32]
Forward-Looking Statements

[0000926326-19-000011:8k_2_02:33]
recent filings with the Securities and Exchange Commission (“SEC”). Prospective investors are cautioned not to place undue reliance on forward-looking statements. All forward-looking statements contained in this press release speak only as of the date on which they were made. Omnicell undertakes no obligation to update such statements to reflect events that occur or circumstances that exist after the date on which they were made.

[0000926326-19-000011:8k_2_02:34]
Use of Non-GAAP Financial Information

[0000926326-19-000011:8k_2_02:35]
This press release contains financial measures that are not calculated in accordance with GAAP. Our management evaluates and makes operating decisions using various performance measures. In addition to Omnicell’s GAAP results, we also consider non-GAAP revenues, non-GAAP gross profit, non-GAAP operating expenses, non-GAAP net income, and non-GAAP net income per diluted share. Additionally, we calculate adjusted EBITDA (another non-GAAP measure) by means of adjustments to GAAP net income. These non-GAAP results should not be considered as an alternative to gross profit, operating expenses, net income, net income per diluted share, or any other performance measure derived in accordance with GAAP. We present these non-GAAP results because we consider them to be important supplemental measures of Omnicell’s performance.

[0000926326-19-000011:8k_2_02:36]
Our non-GAAP revenues, non-GAAP gross profit, non-GAAP operating expenses, non-GAAP net income, and non-GAAP net income per diluted share are exclusive of certain items to facilitate management’s review of the comparability of Omnicell’s core operating results on a period-to-period basis because such items are not related to Omnicell’s ongoing core operating results as viewed by management. We define our “core operating results” as those revenues recorded in a particular period and the expenses incurred within that period that directly drive operating income in that period. Management uses these non-GAAP financial measures in making operating decisions because, in addition to meaningful supplemental information regarding operating performance, the measures give us a better understanding of how we should invest in research and development, fund infrastructure growth, and evaluate the effectiveness of marketing strategies. In calculating the above non-GAAP results, management specifically adjusted for the following excluded items:

[0000926326-19-000011:8k_2_02:37]
| a) | Share-based compensation expense. We excluded from our non-GAAP results the expense related to equity-based compensation plans as they represent expenses that do not require cash settlement from Omnicell. |

[0000926326-19-000011:8k_2_02:38]
| b) | Amortization of acquired intangible assets. We excluded from our non-GAAP results the intangible assets amortization expense resulting from our past acquisitions. These non-cash charges are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results. |

[0000926326-19-000011:8k_2_02:39]
| c) | Amortization of debt issuance cost. Debt issuance cost represents costs associated with the issuance of Term Loan and Revolving Line of Credit facilities. The cost includes underwriting fees, original issue discount, ticking fee, and legal fees. This non-cash expense is not considered by management to reflect the core cash-generating performance of the business and therefore is excluded from our non-GAAP results. |

[0000926326-19-000011:8k_2_02:40]
| d) | Severance and other related expenses. We excluded from our non-GAAP results the expenses which are related to restructuring events. These expenses are unrelated to our ongoing operations, and we do not expect them to occur in the ordinary course of business. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and the financial results of peer companies. |

[0000926326-19-000011:8k_2_02:41]
| e) | Tax impact from restructuring activity. We excluded from our non-GAAP results the tax impacts related to restructuring activity. These impacts are unrelated to our ongoing operations, and we do not expect them to occur in the ordinary course of business. We believe that excluding these impacts provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and the financial results of peer companies. |

[0000926326-19-000011:8k_2_02:42]
| f) | Tax impact from intellectual property (“IP”) restructuring. We excluded from our non-GAAP results the tax impacts related to IP restructuring. These impacts are unrelated to our ongoing operations, and we do not expect them to occur in the ordinary course of business. We believe that excluding these impacts provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and the financial results of peer companies. |

[0000926326-19-000011:8k_2_02:43]
Management adjusts for the above items because management believes that, in general, these items possess one or more of the following characteristics: their magnitude and timing is largely outside of Omnicell’s control; they are unrelated to the ongoing operation of the business in the ordinary course; they are unusual and we do not expect them to occur in the ordinary course of business; or they are non-operational, or non-cash expenses involving stock compensation plans or other items.

[0000926326-19-000011:8k_2_02:44]
We believe that the presentation of these non-GAAP financial measures is warranted for several reasons:

[0000926326-19-000011:8k_2_02:45]
| a) | Such non-GAAP financial measures provide an additional analytical tool for understanding Omnicell’s financial performance by excluding the impact of items which may obscure trends in the core operating results of the business. |

[0000926326-19-000011:8k_2_02:46]
3

[0000926326-19-000011:8k_2_02:47]
| b) | Since we have historically reported non-GAAP results to the investment community, we believe the inclusion of non-GAAP numbers provides consistency and enhances investors’ ability to compare our performance across financial reporting periods. |

[0000926326-19-000011:8k_2_02:48]
| c) | These non-GAAP financial measures are employed by Omnicell’s management in its own evaluation of performance and are utilized in financial and operational decision making processes, such as budget planning and forecasting. |

[0000926326-19-000011:8k_2_02:49]
| d) | These non-GAAP financial measures facilitate comparisons to the operating results of other companies in our industry, which use similar financial measures to supplement their GAAP results, thus enhancing the perspective of investors who wish to utilize such comparisons in their analysis of our performance. |

[0000926326-19-000011:8k_2_02:50]
Set forth below are additional reasons why share-based compensation expense is excluded from our non-GAAP financial measures:

[0000926326-19-000011:8k_2_02:51]
| i) | While share-based compensation calculated in accordance with Accounting Standard Codification (“ASC”) 718 constitutes an ongoing and recurring expense of Omnicell, it is not an expense that requires cash settlement by Omnicell. We therefore exclude these charges for purposes of evaluating core operating results. Thus, our non-GAAP measurements are presented exclusive of share-based compensation expense to assist management and investors in evaluating our core operating results. |

[0000926326-19-000011:8k_2_02:52]
| ii) | We present ASC 718 share-based payment compensation expense in our reconciliation of non-GAAP financial measures on a pre-tax basis because the exact tax differences related to the timing and deductibility of share-based compensation under ASC 718 are dependent upon the trading price of Omnicell’s common stock and the timing and exercise by employees of their stock options. As a result of these timing and market uncertainties, the tax effect related to share-based compensation expense would be inconsistent in amount and frequency and is therefore excluded from our non-GAAP results. |

[0000926326-19-000011:8k_2_02:53]
Our adjusted EBITDA calculation is defined as earnings before interest income and expense, taxes, depreciation and amortization, and non-cash expenses, including ASC 718 share-based compensation expense, as well as certain non-GAAP adjustments.

[0000926326-19-000011:8k_2_02:54]
As stated above, we present non-GAAP financial measures because we consider them to be important supplemental measures of performance. However, non-GAAP financial measures have limitations as an analytical tool and should not be considered in isolation or as a substitute for Omnicell’s GAAP results. In the future, we expect to incur expenses similar to certain of the non-GAAP adjustments described above and expect to continue reporting non-GAAP financial measures excluding such items. Some of the limitations in relying on non-GAAP financial measures are:

[0000926326-19-000011:8k_2_02:55]
| a) | Omnicell’s stock option and stock purchase plans are important components of incentive compensation arrangements and will be reflected as expenses in Omnicell’s GAAP results for the foreseeable future under ASC 718. |

[0000926326-19-000011:8k_2_02:56]
| b) | Other companies, including companies in Omnicell’s industry, may calculate non-GAAP financial measures differently than Omnicell, limiting their usefulness as a comparative measure. |

[0000926326-19-000011:8k_2_02:57]
Pursuant to the requirements of SEC Regulation G, a detailed reconciliation between Omnicell’s non-GAAP and GAAP financial results is set forth in the financial tables at the end of this press release. Investors are advised to carefully review and consider this information strictly as a supplement to the GAAP results that are contained in this press release and in Omnicell’s SEC filings.

[0000926326-19-000011:8k_2_02:58]
Our 2019 guidance for non-GAAP earnings per share, as well as certain projections to be discussed in the conference call noted above, exclude “certain items,” which include but are not limited to: unusual gains and losses; costs associated with future restructurings; acquisition-related expenses; and certain tax and litigation outcomes. We do not provide a reconciliation of non-GAAP earnings per share guidance to the comparable GAAP measure as these items are inherently uncertain and difficult to estimate, and cannot be predicted without unreasonable effort. We believe such a reconciliation would imply a degree of precision that could be confusing to investors. These items may also have a material impact on GAAP earnings per share in future periods.

[0000926326-19-000011:8k_2_02:59]
Omnicell, Inc.

[0000926326-19-000011:8k_2_02:60]
Condensed Consolidated Statements of Operations

[0000926326-19-000011:8k_2_02:61]
(Unaudited, in thousands, except per share data)

[0000926326-19-000011:8k_2_02:62]
|  | Three months ended March 31, |
|  | 2019 |  | 2018 (a) |
| Revenues: |  |  |  |
| Product revenues | $ | 145,610 |  |  | $ | 130,659 |  |
| Services and other revenues | 56,907 |  |  | 51,960 |  |
| Total revenues | 202,517 |  |  | 182,619 |  |
| Cost of revenues: |  |  |  |
| Cost of product revenues | 78,811 |  |  | 75,417 |  |
| Cost of services and other revenues | 26,589 |  |  | 24,747 |  |
| Total cost of revenues | 105,400 |  |  | 100,164 |  |
| Gross profit | 97,117 |  |  | 82,455 |  |
| Operating expenses: |  |  |  |
| Research and development | 16,078 |  |  | 16,537 |  |
| Selling, general, and administrative | 68,278 |  |  | 65,285 |  |
| Total operating expenses | 84,356 |  |  | 81,822 |  |
| Income from operations | 12,761 |  |  | 633 |  |
| Interest and other income (expense), net | (1,410 | ) |  | (2,729 | ) |
| Income (loss) before provision for income taxes | 11,351 |  |  | (2,096 | ) |
| Provision for (benefit from) income taxes | 8,067 |  |  | (4,816 | ) |
| Net income | $ | 3,284 |  |  | $ | 2,720 |  |
| Net income per share: |  |  |  |
| Basic | $ | 0.08 |  |  | $ | 0.07 |  |
| Diluted | $ | 0.08 |  |  | $ | 0.07 |  |
| Weighted-average shares outstanding: |  |  |  |
| Basic | 40,692 |  |  | 38,635 |  |
| Diluted | 42,281 |  |  | 39,691 |  |

[0000926326-19-000011:8k_2_02:63]
| (a) | Includes a $0.6 million reclassification from services and other revenues to product revenues to conform with current-period presentation. |

[0000926326-19-000011:8k_2_02:64]
5

[0000926326-19-000011:8k_2_02:65]
Omnicell, Inc.

[0000926326-19-000011:8k_2_02:66]
Condensed Consolidated Balance Sheets

[0000926326-19-000011:8k_2_02:67]
(Unaudited, in thousands)

[0000926326-19-000011:8k_2_02:68]
|  | March 31, 2019 |  | December 31, 2018 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 77,244 |  |  | $ | 67,192 |  |
| Accounts receivable and unbilled receivables, net | 203,489 |  |  | 196,238 |  |
| Inventories | 103,909 |  |  | 100,868 |  |
| Prepaid expenses | 17,048 |  |  | 20,700 |  |
| Other current assets | 12,017 |  |  | 12,136 |  |
| Total current assets | 413,707 |  |  | 397,134 |  |
| Property and equipment, net | 52,039 |  |  | 51,500 |  |
| Long-term investment in sales-type leases, net | 19,469 |  |  | 17,082 |  |
| Operating lease right-of-use assets | 63,851 |  |  | — |  |
| Goodwill | 336,119 |  |  | 335,887 |  |
| Intangible assets, net | 138,893 |  |  | 143,686 |  |
| Long-term deferred tax assets | 32,043 |  |  | 15,197 |  |
| Prepaid commissions | 43,669 |  |  | 46,143 |  |
| Other long-term assets | 77,270 |  |  | 74,613 |  |
| Total assets | $ | 1,177,060 |  |  | $ | 1,081,242 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 38,466 |  |  | $ | 38,038 |  |
| Accrued compensation | 29,056 |  |  | 41,660 |  |
| Accrued liabilities | 52,996 |  |  | 43,047 |  |
| Deferred revenues, net | 90,104 |  |  | 81,835 |  |
| Total current liabilities | 210,622 |  |  | 204,580 |  |
| Long-term deferred revenues | 10,302 |  |  | 10,582 |  |
| Long-term deferred tax liabilities | 61,405 |  |  | 41,484 |  |
| Long-term operating lease liabilities | 57,470 |  |  | — |  |
| Other long-term liabilities | 9,786 |  |  | 9,562 |  |
| Long-term debt, net | 96,990 |  |  | 135,417 |  |
| Total liabilities | 446,575 |  |  | 401,625 |  |
| Total stockholders’ equity | 730,485 |  |  | 679,617 |  |
| Total liabilities and stockholders’ equity | $ | 1,177,060 |  |  | $ | 1,081,242 |  |

[0000926326-19-000011:8k_2_02:69]
Omnicell, Inc.

[0000926326-19-000011:8k_2_02:70]
Condensed Consolidated Statements of Cash Flows

[0000926326-19-000011:8k_2_02:71]
(Unaudited, in thousands)

[0000926326-19-000011:8k_2_02:72]
|  | Three months ended March 31, |
|  | 2019 |  | 2018 |
| Operating Activities |  |  |  |
| Net income | $ | 3,284 |  |  | $ | 2,720 |  |
| Adjustments to reconcile net income to net cash provided by operating activities |  |  |  |
| Depreciation and amortization | 12,637 |  |  | 12,310 |  |
| Loss on disposal of fixed assets | 355 |  |  | — |  |
| Share-based compensation expense | 8,410 |  |  | 6,528 |  |
| Deferred income taxes | 3,075 |  |  | (5,128 | ) |
| Amortization of operating lease right-of-use assets | 2,602 |  |  | — |  |
| Amortization of debt financing fees | 573 |  |  | 573 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable and unbilled receivables | (7,251 | ) |  | (632 | ) |
| Inventories | (2,936 | ) |  | (6,881 | ) |
| Prepaid expenses | 3,652 |  |  | (769 | ) |
| Other current assets | 373 |  |  | (997 | ) |
| Investment in sales-type leases | (2,641 | ) |  | (1,491 | ) |
| Prepaid commissions | 2,474 |  |  | 1,796 |  |
| Other long-term assets | 5,206 |  |  | (1,673 | ) |
| Accounts payable | (233 | ) |  | (9,416 | ) |
| Accrued compensation | (12,604 | ) |  | 2,391 |  |
| Accrued liabilities | 127 |  |  | 4,276 |  |
| Deferred revenues | 7,989 |  |  | 15,118 |  |
| Operating lease liabilities | (2,669 | ) |  | — |  |
| Other long-term liabilities | 4,074 |  |  | 131 |  |
| Net cash provided by operating activities | 26,497 |  |  | 18,856 |  |
| Investing Activities |  |  |  |
| Software development for external use | (11,717 | ) |  | (5,272 | ) |
| Purchases of property and equipment | (4,980 | ) |  | (9,268 | ) |
| Net cash used in investing activities | (16,697 | ) |  | (14,540 | ) |
| Financing Activities |  |  |  |
| Repayment of debt and revolving credit facility | (39,000 | ) |  | (2,500 | ) |
| At the market offering, net of offering costs | 20,216 |  |  | — |  |
| Proceeds from issuances under stock-based compensation plans | 20,526 |  |  | 9,541 |  |
| Employees’ taxes paid related to restricted stock units | (1,920 | ) |  | (1,300 | ) |
| Net cash provided by (used in) financing activities | (178 | ) |  | 5,741 |  |
| Effect of exchange rate changes on cash and cash equivalents | 430 |  |  | 1,292 |  |
| Net increase in cash and cash equivalents | 10,052 |  |  | 11,349 |  |
| Cash and cash equivalents at beginning of period | 67,192 |  |  | 32,424 |  |
| Cash and cash equivalents at end of period | $ | 77,244 |  |  | $ | 43,773 |  |

[0000926326-19-000011:8k_2_02:73]
7

[0000926326-19-000011:8k_2_02:74]
Omnicell, Inc.

[0000926326-19-000011:8k_2_02:75]
Reconciliation of GAAP to Non-GAAP

[0000926326-19-000011:8k_2_02:76]
(Unaudited, in thousands, except per share data and percentage)

[0000926326-19-000011:8k_2_02:77]
|  | Three months ended |
|  | March 31, 2019 |  | March 31, 2018 |
| Reconciliation of GAAP revenues to non-GAAP revenues: |  |  |  |
| GAAP revenues | $ | 202,517 |  |  | $ | 182,619 |  |
| Non-GAAP revenues | $ | 202,517 |  |  | $ | 182,619 |  |
| Reconciliation of GAAP gross profit to non-GAAP gross profit: |  |
| GAAP gross profit | $ | 97,117 |  |  | $ | 82,455 |  |
| GAAP gross margin | 48.0% |  | 45.2% |
| Share-based compensation expense | 1,462 |  |  | 1,019 |  |
| Amortization of acquired intangibles | 2,066 |  |  | 2,791 |  |
| Non-GAAP gross profit | $ | 100,645 |  |  | $ | 86,265 |  |
| Non-GAAP gross margin | 49.7% |  | 47.2% |
| Reconciliation of GAAP operating expenses to non-GAAP operating expenses: |
| GAAP operating expenses | $ | 84,356 |  |  | $ | 81,822 |  |
| GAAP operating expenses % to total revenues | 41.7% |  | 44.8% |
| Share-based compensation expense | (6,948 | ) |  | (5,509 | ) |
| Amortization of acquired intangibles | (2,716 | ) |  | (3,238 | ) |
| Severance and other expenses | (286 | ) |  | (1,512 | ) |
| Non-GAAP operating expenses | $ | 74,406 |  |  | $ | 71,563 |  |
| Non-GAAP operating expenses % to total non-GAAP revenues | 36.7% |  | 39.2% |
| Reconciliation of GAAP income from operations to non-GAAP income from operations: |
| GAAP income from operations | $ | 12,761 |  |  | $ | 633 |  |
| GAAP operating income % to total revenues | 6.3% |  | 0.3% |
| Share-based compensation expense | 8,410 |  |  | 6,528 |  |
| Amortization of acquired intangibles | 4,782 |  |  | 6,029 |  |
| Severance and other expenses | 286 |  |  | 1,512 |  |
| Non-GAAP income from operations | $ | 26,239 |  |  | $ | 14,702 |  |
| Non-GAAP operating income % to total non-GAAP revenues | 13.0% |  | 8.1% |

[0000926326-19-000011:8k_2_02:78]
Omnicell, Inc.

[0000926326-19-000011:8k_2_02:79]
Reconciliation of GAAP to Non-GAAP

[0000926326-19-000011:8k_2_02:80]
(Unaudited, in thousands, except per share data and percentage)

[0000926326-19-000011:8k_2_02:81]
|  | Three months ended |
|  | March 31, 2019 |  | March 31, 2018 |
| Reconciliation of GAAP net income to non-GAAP net income: |
| GAAP net income | $ | 3,284 |  |  | $ | 2,720 |  |
| Tax benefit for restructuring activity | — |  |  | (4,205 | ) |
| Tax impact of IP restructuring | 9,624 |  |  | — |  |
| Share-based compensation expense | 8,410 |  |  | 6,528 |  |
| Amortization of acquired intangibles | 4,782 |  |  | 6,029 |  |
| Severance and other expenses(a) | 859 |  |  | 2,085 |  |
| Tax effect of the adjustments above(b) | (1,184 | ) |  | (1,703 | ) |
| Non-GAAP net income | $ | 25,775 |  |  | $ | 11,454 |  |
| Reconciliation of GAAP net income per share - diluted to non-GAAP net income per share - diluted: |
| Shares - diluted GAAP | 42,281 |  |  | 39,691 |  |
| Shares - diluted Non-GAAP | 42,281 |  |  | 39,691 |  |
| GAAP net income per share - diluted | $ | 0.08 |  |  | $ | 0.07 |  |
| Tax benefit for restructuring activity | — |  |  | (0.10 | ) |
| Tax impact of IP restructuring | 0.23 |  |  | — |  |
| Share-based compensation expense | 0.20 |  |  | 0.16 |  |
| Amortization of acquired intangibles | 0.11 |  |  | 0.15 |  |
| Severance and other expenses | 0.02 |  |  | 0.05 |  |
| Tax effect of the adjustments above(b) | (0.03 | ) |  | (0.04 | ) |
| Non-GAAP net income per share - diluted | $ | 0.61 |  |  | $ | 0.29 |  |
| Reconciliation of GAAP net income to non-GAAP Adjusted EBITDA(c): |
| GAAP net income | $ | 3,284 |  |  | $ | 2,720 |  |
| Share-based compensation expense | 8,410 |  |  | 6,528 |  |
| Interest (income) and expense, net | 706 |  |  | 1,772 |  |
| Depreciation and amortization expense | 12,637 |  |  | 12,310 |  |
| Severance and other expenses | 859 |  |  | 2,085 |  |
| Income tax expense (benefit) | 8,067 |  |  | (4,816 | ) |
| Non-GAAP adjusted EBITDA | $ | 33,963 |  |  | $ | 20,599 |  |

[0000926326-19-000011:8k_2_02:82]
| (a) | For the three months ended March 31, 2019, other expenses include $0.4 million and $0.2 million of amortization of debt issuance costs related to prior acquisitions and credit facilities amendments, respectively, and $0.3 million of IP restructuring costs. For the three months ended March 31, 2018, other expenses include $0.4 million and $0.2 million of amortization of debt issuance costs related to prior acquisitions and credit facilities amendments, respectively. |

[0000926326-19-000011:8k_2_02:83]
| (b) | Tax effects calculated for all adjustments except tax benefits and expenses, and share-based compensation expense, using an estimated annual effective tax rate of 21% for both fiscal years 2019 and 2018. |

[0000926326-19-000011:8k_2_02:84]
| (c) | Defined as earnings before interest income and expense, taxes, depreciation and amortization, share-based compensation, as well as excluding certain non-GAAP adjustments. |

[0000926326-19-000011:8k_2_02:85]
9
