# OMCL notes — 0000926326-19-000013


## omcl:ScheduleofSharebasedCompensationFutureIssuanceofSharesTableTextBlock

[0000926326-19-000013:notes:1]
The Company had the following ordinary shares reserved for future issuance under its equity incentive plans as of March 31, 2019:

[0000926326-19-000013:notes:2]
|  | Number of Shares |
|  | (In thousands) |
| Share options outstanding | 3,544 |  |
| Non-vested restricted share awards | 738 |  |
| Shares authorized for future issuance | 2,140 |  |
| ESPP shares available for future issuance | 1,703 |  |
| Total shares reserved for future issuance | 8,125 |  |


## srt:ScheduleOfCondensedBalanceSheetTableTextBlock

[0000926326-19-000013:notes:3]
Balance sheet details as of March 31, 2019 and December 31, 2018 are presented in the tables below:

[0000926326-19-000013:notes:4]
|  | March 31, 2019 |  | December 31, 2018 |
|  | (In thousands) |
| Inventories: |  |  |  |
| Raw materials | $ | 34,552 |  |  | $ | 32,511 |  |
| Work in process | 8,876 |  |  | 8,726 |  |
| Finished goods | 60,481 |  |  | 59,631 |  |
| Total inventories | $ | 103,909 |  |  | $ | 100,868 |  |
| Other long-term assets: |  |  |  |
| Capitalized software, net | $ | 64,682 |  |  | $ | 56,819 |  |
| Unbilled receivables | 11,423 |  |  | 16,481 |  |
| Other assets | 1,165 |  |  | 1,313 |  |
| Total other long-term assets, net | $ | 77,270 |  |  | $ | 74,613 |  |
| Accrued liabilities: |  |  |  |
| Operating lease liabilities, current portion | $ | 10,373 |  |  | $ | — |  |
| Advance payments from customers | 9,400 |  |  | 8,993 |  |
| Rebates and lease buyouts | 8,111 |  |  | 11,076 |  |
| Group purchasing organization fees | 4,403 |  |  | 4,455 |  |
| Taxes payable | 5,996 |  |  | 5,885 |  |
| Other accrued liabilities | 14,713 |  |  | 12,638 |  |
| Total accrued liabilities | $ | 52,996 |  |  | $ | 43,047 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000926326-19-000013:notes:5]
[same as prior period, unchanged from 0000926326-18-000030:notes:9]

[0000926326-19-000013:notes:6]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of March 31, 2019 and December 31, 2018, and the results of operations, comprehensive income, and cash flows for the three months ended March 31, 2019 and 2018. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s annual report on Form 10-K for the year ended December 31, 2018 filed with the SEC on February 27, 2019, except as discussed in the sections entitled “Lessor Leases”, “Lessee Leases’, and “Recently Adopted Authoritative Guidance” below. The Company’s results of operations, comprehensive income, and cash flows for the three months ended March 31, 2019 are not necessarily indicative of results that may be expected for the year ending December 31, 2019, or for any future period.


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000926326-19-000013:notes:7]
Commitments and Contingencies

[0000926326-19-000013:notes:8]
Purchase Obligations

[0000926326-19-000013:notes:9]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of March 31, 2019, the Company had non-cancelable purchase commitments of $71.0 million, of which $65.5 million are expected to be paid within the year ended December 31, 2019.

[0000926326-19-000013:notes:10]
Legal Proceedings

[0000926326-19-000013:notes:11]
The Company is currently involved in various legal proceedings. As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any accrual for contingent liabilities associated with the legal proceedings described below based on its belief that any potential loss, while reasonably possible, is not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of this contingency or because of the diversion of management’s attention and the creation of significant expenses.

[0000926326-19-000013:notes:12]
On January 10, 2018, a lawsuit was filed against a number of individuals, governmental agencies, and corporate entities, including the Company and one of its subsidiaries, Aesynt Incorporated (“Aesynt”), in the Circuit Court for the City of Richmond, Virginia, captioned Ruth Ann Warner, as Guardian of Jonathan James Brewster Warner v. Centra Health, Inc., et al., Case No. CL18-152-1. The complaint seeks monetary recovery of compensatory and punitive damages in addition to certain declaratory relief based upon, as against the individuals, governmental agencies, and corporate entities other than the Company and Aesynt, allegations of the use of excessive force, unlawful detention, false imprisonment, battery, simple and gross negligence and negligent hiring, detention, and training; and, as against the Company and Aesynt, claims of product liability, negligence, and breach of implied warranties. The Company and Aesynt have not yet been served with the complaint. The Company intends to defend the lawsuit vigorously.

[0000926326-19-000013:notes:13]
On June 6, 2018, a class-action lawsuit was filed against a customer of the Company, the customer’s parent company and two vendors of medication dispensing systems, one of which is the Company, in the Circuit Court of Cook County, Illinois, Chancery Division, captioned Yana Mazya, individually and on behalf of all others similarly situated v. Northwestern Lake Forest Hospital, Northwestern Memorial Healthcare, Omnicell, Inc. and Becton Dickinson, Case No. 2018-CH-07161. The complaint sought class certification, monetary damages in the form of statutory damages for willful and/or reckless or, in the alternative, negligent violation of the Illinois Biometric Information Privacy Act (“BIPA”), and certain declaratory, injunctive, and other relief based on causes of action directed to allegations of violation of BIPA and of negligence by the defendants. The complaint was served on the Company on June 15, 2018. The Company’s obligation to respond to the complaint was held in abeyance pending a decision of the Illinois Supreme Court in a separate case involving BIPA issues. The Illinois Supreme Court issued its decision in that case on January 25, 2019. On April 10, 2019, subsequent to the court’s issuance of an order granting the plaintiff leave to file an amended complaint, the plaintiff filed an amended complaint adding a second named plaintiff and an affiliate of the Company’s customer as an additional defendant and, in addition to making other modifications to the complaint, removing the separate cause of action directed to negligence. The court established a deadline of May 13, 2019 for the defendants to answer or otherwise respond to the amended complaint. The Company intends to defend the lawsuit vigorously.

[0000926326-19-000013:notes:14]
A declaratory judgment action was filed against the Company, on August 30, 2018, in the United States District Court for the Northern District of California, captioned Zurich American Insurance Company; American Guarantee & Liability Company v. Omnicell, Inc. and Does 1-10, inclusive, Case No. 3:18-CV-05345. The complaint seeks a declaration that the plaintiffs have no duty to defend or indemnify the Company in connection with the underlying litigation, the Yana Mazya, et al. v. Northwestern Lake Forest Hospital, et al., Case No. 2018-CH-07161 pending in the Circuit Court of Cook County, Illinois, Chancery Division (“Underlying Action”), disclosed above, together with claims for reimbursement and unjust enrichment relating to the defense of the Underlying Action in the form of attorneys’ fees and other related costs. The Company has not responded to the complaint. On February 12, 2019, the court stayed the action pending the outcome of the Underlying Action and administratively closed the case. The Company intends to defend the lawsuit vigorously.


## us-gaap:ConsolidationPolicyTextBlock

[0000926326-19-000013:notes:15]
[same as prior period, unchanged from 0000926326-18-000030:notes:27]

[0000926326-19-000013:notes:16]
[same as prior period, unchanged from 0000926326-18-000030:notes:28]


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0000926326-19-000013:notes:17]
[same as prior period, unchanged from 0000926326-18-000030:notes:29]

[0000926326-19-000013:notes:18]
|  | March 31, 2019 |  | December 31, 2018 |
|  | (In thousands) |
| Short-term unbilled receivables - included in accounts receivable and unbilled receivables | $ | 8,708 |  |  | $ | 9,191 |  |
| Long-term unbilled receivables - included in other long-term assets | 11,423 |  |  | 16,481 |  |
| Total contract assets | $ | 20,131 |  |  | $ | 25,672 |  |
| Short-term deferred revenues, net | $ | 90,104 |  |  | $ | 81,835 |  |
| Long-term deferred revenues | 10,302 |  |  | 10,582 |  |
| Total contract liabilities | $ | 100,406 |  |  | $ | 92,417 |  |


## us-gaap:DebtDisclosureTextBlock

[0000926326-19-000013:notes:19]
Debt and Credit Agreements

[0000926326-19-000013:notes:20]
On January 5, 2016, the Company entered into a $400.0 million senior secured credit facility pursuant to a credit agreement with certain lenders, Wells Fargo Securities, LLC as sole lead arranger, and Wells Fargo Bank, National Association as administrative agent (the “Credit Agreement”). The Credit Agreement provides for (a) a five-year revolving credit facility of $200.0 million, which was subsequently increased pursuant to the amendment discussed below (the “Revolving Credit Facility”) and (b) a five-year $200.0 million term loan facility (the “Term Loan Facility” and together with the Revolving Credit Facility, the “Facilities”). In addition, the Credit Agreement includes a letter of credit sub-limit of up to $10.0 million and a swing line loan sub-limit of up to $10.0 million. The Credit Agreement expires on January 5, 2021, upon which date all remaining outstanding borrowings are due and payable.

[0000926326-19-000013:notes:21]
Loans under the Facilities bear interest, at the Company’s option, at a rate equal to either (a) the LIBOR Rate, plus an applicable margin ranging from 1.50% to 2.25% per annum based on the Company’s consolidated total net leverage ratio (as defined in the Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) LIBOR for an interest period of one month, plus an applicable margin ranging from 0.50% to 1.25% per annum based on the Company’s consolidated total net leverage ratio (as defined in the Credit Agreement). Undrawn commitments under the Revolving Credit Facility will be subject to a commitment fee ranging from 0.20% to 0.35% per annum based on the Company’s consolidated total net leverage ratio on the average daily unused portion of the Revolving Credit Facility. A letter of credit participation fee ranging from 1.50% to 2.25% per annum based on the Company’s consolidated total net leverage ratio will accrue on the average daily amount of letter of credit exposure.

[0000926326-19-000013:notes:22]
The Company is permitted to make voluntary prepayments at any time without payment of a premium or penalty, except for any amounts relating to the LIBOR breakage indemnity described in the Credit Agreement. The Company is required to make mandatory prepayments under the Term Loan Facility with (a) net cash proceeds from any issuances of debt (other than certain permitted debt) and (b) net cash proceeds from certain asset dispositions (other than certain asset dispositions) and insurance and condemnation events (subject to reinvestment rights and certain other exceptions). Loans under the Term Loan Facility will amortize in quarterly installments, equal to 5% per annum of the original principal amount thereof during the first two years, which shall increase to 10% per annum during the third and fourth years, and 15% per annum during the fifth year, with the remaining balance payable on January 5, 2021. The Company is required to make mandatory prepayments under the Revolving Credit Facility if at any time the aggregate outstanding principal amount of loans together with the total amount of outstanding letters of credit exceeds the aggregate commitments, with such mandatory prepayment to be equal to the amount of such excess.

[0000926326-19-000013:notes:23]
The Credit Agreement contains customary representations and warranties, and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends, and other distributions. The Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum consolidated total leverage ratio and maintain a minimum fixed charge coverage ratio. The Company’s obligations under the Credit Agreement, and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender), are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and the subsidiary guarantors’ assets. In connection with entering into the Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a collateral agreement and subsidiary guaranty agreement.

[0000926326-19-000013:notes:24]
On April 11, 2017, the parties entered into the First Amendment to Credit Agreement and Collateral Agreement (the “Amended Credit Agreement”). Under this amendment, (i) the maximum capital expenditures limit in any fiscal year for property, plant, and equipment and software development increased from $35.0 million to $45.0 million, and (ii) the maximum limit for non-permitted investments increased from $10.0 million to $20.0 million.

[0000926326-19-000013:notes:25]
On December 26, 2017, the parties entered into an amendment (the “Amendment”) to the Amended Credit Agreement. Pursuant to the Amendment, the Revolving Credit Facility provided for under the Amended Credit Agreement, was increased from $200.0 million to $315.0 million, and certain other modifications to the Amended Credit Agreement were made, including amendments to certain negative covenants.

[0000926326-19-000013:notes:26]
In connection with these Facilities, the Company incurred $10.1 million of debt issuance costs. The debt issuance costs were capitalized and presented as a direct deduction from the carrying amount of that debt liability. The debt issuance costs are being amortized to interest expense using the straight line method from issuance date through 2021. Interest expense (exclusive of fees and issuance cost amortization) was approximately $1.3 million and $1.9 million for the three months ended March 31, 2019 and 2018, respectively. Amortization expense related to fees and issuance cost was approximately $0.6 million for both the three months ended March 31, 2019 and 2018. The Company was in compliance with all covenants as of March 31, 2019 and December 31, 2018.

[0000926326-19-000013:notes:27]
During the three months ended March 31, 2019, the Company repaid $39.0 million under these Facilities.

[0000926326-19-000013:notes:28]
The components of the Company’s debt obligations as of March 31, 2019 and December 31, 2018 were as follows:

[0000926326-19-000013:notes:29]
|  | December 31, 2018 |  | Borrowings |  | Repayment / Amortization |  | March 31, 2019 |
|  | (In thousands) |
| Term loan facility | $ | 140,000 |  |  | $ | — |  |  | $ | (39,000 | ) |  | $ | 101,000 |  |
| Revolving credit facility | — |  |  | — |  |  | — |  |  | — |  |
| Total debt under the facilities | 140,000 |  |  | — |  |  | (39,000 | ) |  | 101,000 |  |
| Less: Deferred issuance cost | (4,583 | ) |  | — |  |  | 573 |  |  | (4,010 | ) |
| Total long-term debt, net of deferred issuance cost | $ | 135,417 |  |  | $ | — |  |  | $ | (38,427 | ) |  | $ | 96,990 |  |

[0000926326-19-000013:notes:30]
As of March 31, 2019, the carrying amount of debt of $101.0 million approximates the comparable fair value of $103.5 million. The Company’s debt facilities are classified as a Level 3 in the fair value hierarchy. The calculation of the fair value is based on a discounted cash flow model using observable market inputs and taking into consideration variables such as interest rate changes, comparable instruments and long-term credit ratings. There have been no significant changes in the assumptions used as of March 31, 2019 as compared to December 31, 2018.


## us-gaap:EarningsPerShareTextBlock

[0000926326-19-000013:notes:31]
Net Income Per Share

[0000926326-19-000013:notes:32]
Basic net income per share is computed by dividing net income for the period by the weighted-average number of shares outstanding during the period. In periods of net loss, all potential common shares are anti-dilutive, so diluted net loss per share equals the basic net loss per share. In periods of net income, diluted net income per share is computed by dividing net income for the period by the basic weighted-average number of shares plus any dilutive potential common stock outstanding during the period. Potential common stock includes the effect of outstanding dilutive stock options, restricted stock awards, and restricted stock units computed using the treasury stock method. Any anti-dilutive weighted-average dilutive shares related to stock award plans are excluded from the computation of the diluted net income per share.

[0000926326-19-000013:notes:33]
The basic and diluted net income per share calculation for the three months ended March 31, 2019 and 2018 was as follows:

[0000926326-19-000013:notes:34]
|  | Three months ended March 31, |
|  | 2019 |  | 2018 |
|  | (In thousands, except per share data) |
| Net income | $ | 3,284 |  |  | $ | 2,720 |  |
| Weighted-average shares outstanding — basic | 40,692 |  |  | 38,635 |  |
| Effect of dilutive securities from stock award plans | 1,589 |  |  | 1,056 |  |
| Weighted-average shares outstanding — diluted | 42,281 |  |  | 39,691 |  |
| Net income per share - basic | $ | 0.08 |  |  | $ | 0.07 |  |
| Net income per share - diluted | $ | 0.08 |  |  | $ | 0.07 |  |
| Anti-dilutive weighted-average shares related to stock award plans | 635 |  |  | 1,113 |  |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0000926326-19-000013:notes:35]
The following table represents the fair value hierarchy of the Company’s financial assets and financial liabilities measured at fair value as of March 31, 2019:

[0000926326-19-000013:notes:36]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Interest rate swap contracts | $ | — |  |  | $ | 136 |  |  | $ | — |  |  | $ | 136 |  |
| Total financial assets | $ | — |  |  | $ | 136 |  |  | $ | — |  |  | $ | 136 |  |

[0000926326-19-000013:notes:37]
The following table represents the fair value hierarchy of the Company’s financial assets and financial liabilities measured at fair value as of December 31, 2018:

[0000926326-19-000013:notes:38]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Interest rate swap contracts | $ | — |  |  | $ | 562 |  |  | $ | — |  |  | $ | 562 |  |
| Total financial assets | $ | — |  |  | $ | 562 |  |  | $ | — |  |  | $ | 562 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000926326-19-000013:notes:39]
[same as prior period, unchanged from 0000926326-18-000030:notes:51]

[0000926326-19-000013:notes:40]
Cash and cash equivalents of $77.2 million and $67.2 million as of March 31, 2019 and December 31, 2018, respectively, consisted of bank accounts with major financial institutions.

[0000926326-19-000013:notes:41]
[same as prior period, unchanged from 0000926326-18-000030:notes:57]

[0000926326-19-000013:notes:42]
The Company measures its financial instruments at fair value. The Company’s cash equivalents are classified within Level 1 of the fair value hierarchy as they are valued primarily using quoted market prices utilizing market observable inputs. The Company’s interest rate swap contracts are classified within Level 2 as the valuation inputs are based on quoted prices and market observable data of similar instruments.

[0000926326-19-000013:notes:43]
[same as prior period, unchanged from 0000926326-18-000030:notes:53]

[0000926326-19-000013:notes:44]
[same as prior period, unchanged from 0000926326-18-000030:notes:54]

[0000926326-19-000013:notes:45]
During 2016, the Company entered into an interest rate swap agreement with a combined notional amount of $100.0 million with one counterparty that became effective on June 30, 2016 and is maturing on April 30, 2019. The swap agreement requires the Company to pay a fixed rate of 0.8% and provides that the Company will receive a variable rate based on the one month LIBOR rate subject to a LIBOR floor of 0.0%. Amounts payable by or due to the Company will be net settled with the respective counterparty on the last business day of each month, commencing July 31, 2016.

[0000926326-19-000013:notes:46]
The fair value of the interest rate swap agreements at March 31, 2019 and December 31, 2018 was $0.1 million and $0.6 million, respectively. There were no amounts reclassified into current earnings due to ineffectiveness during the periods presented.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000926326-19-000013:notes:47]
[same as prior period, unchanged from 0000926326-18-000030:notes:60]

[0000926326-19-000013:notes:48]
[same as prior period, unchanged from 0000926326-18-000030:notes:61]

[0000926326-19-000013:notes:49]
[same as prior period, unchanged from 0000926326-18-000030:notes:62]

[0000926326-19-000013:notes:50]
|  | December 31, 2018 |  | Additions |  | Foreign currency exchange rate fluctuations |  | March 31, 2019 |
|  | (In thousands) |
| Goodwill | $ | 335,887 |  |  | $ | — |  |  | $ | 232 |  |  | $ | 336,119 |  |

[0000926326-19-000013:notes:51]
[same as prior period, unchanged from 0000926326-18-000030:notes:64]

[0000926326-19-000013:notes:52]
The carrying amounts and useful lives of intangible assets as of March 31, 2019 and December 31, 2018 were as follows:

[0000926326-19-000013:notes:53]
|  | March 31, 2019 |
|  | Gross carryingamount (1) |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 135,234 |  |  | $ | (47,557 | ) |  | $ | (1,127 | ) |  | $ | 86,550 |  |  | 1 - 30 |
| Acquired technology | 77,142 |  |  | (30,239 | ) |  | 8 |  |  | 46,911 |  |  | 3 - 20 |
| Backlog | 1,150 |  |  | (575 | ) |  | — |  |  | 575 |  |  | 1 - 4 |
| Trade names | 7,650 |  |  | (4,530 | ) |  | 11 |  |  | 3,131 |  |  | 1 - 12 |
| Patents | 3,239 |  |  | (1,515 | ) |  | 2 |  |  | 1,726 |  |  | 2 - 20 |
| Total intangibles assets, net | $ | 224,415 |  |  | $ | (84,416 | ) |  | $ | (1,106 | ) |  | $ | 138,893 |  |  |  |

[0000926326-19-000013:notes:54]
|  | December 31, 2018 |
|  | Gross carryingamount (1) |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 135,234 |  |  | $ | (45,029 | ) |  | $ | (1,185 | ) |  | $ | 89,020 |  |  | 1 - 30 |
| Acquired technology | 78,122 |  |  | (29,206 | ) |  | 42 |  |  | 48,958 |  |  | 3 - 20 |
| Backlog | 21,350 |  |  | (20,703 | ) |  | — |  |  | 647 |  |  | 1 - 4 |
| Trade names | 7,650 |  |  | (4,361 | ) |  | 17 |  |  | 3,306 |  |  | 1 - 12 |
| Patents | 3,239 |  |  | (1,488 | ) |  | 4 |  |  | 1,755 |  |  | 2 - 20 |
| Non-compete agreements | 1,900 |  |  | (1,900 | ) |  | — |  |  | — |  |  | 3 |
| Total intangibles assets, net | $ | 247,495 |  |  | $ | (102,687 | ) |  | $ | (1,122 | ) |  | $ | 143,686 |  |  |  |

[0000926326-19-000013:notes:55]
_________________________________________________

[0000926326-19-000013:notes:56]
| (1) | The differences in gross carrying amounts between periods are due to the write-off of fully amortized intangible assets. |

[0000926326-19-000013:notes:57]
Amortization expense of intangible assets was $4.8 million and $6.0 million for the three months ended March 31, 2019 and 2018, respectively.

[0000926326-19-000013:notes:58]
[same as prior period, unchanged from 0000926326-18-000030:notes:69]

[0000926326-19-000013:notes:59]
|  | March 31, 2019 |
|  | (In thousands) |
| Remaining nine months of 2019 | $ | 13,984 |  |
| 2020 | 17,618 |  |
| 2021 | 16,268 |  |
| 2022 | 14,918 |  |
| 2023 | 13,768 |  |
| Thereafter | 62,337 |  |
| Total | $ | 138,893 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000926326-19-000013:notes:60]
[same as prior period, unchanged from 0000926326-18-000030:notes:71]

[0000926326-19-000013:notes:61]
The Company generally provides for income taxes in interim periods based on the estimated annual effective tax rate for the year, adjusting for discrete items in the quarter in which they arise. The annual effective tax rate before discrete items was 23.3% and 18.3% for the three months ended March 31, 2019 and 2018, respectively.

[0000926326-19-000013:notes:62]
As a result of global operational centralization activities during the three months ended March 31, 2018, the Company recognized $4.2 million of a discrete tax benefit associated with making a check-the-box election to treat Aesynt Coöperatief U.A. (Netherlands) as a US disregarded entity for the three months ended March 31, 2018. Due to continuing global operational centralization activities during the three months ended March 31, 2019, the Company recognized gain on the sale of certain intellectual property rights by Aesynt Coöperatief U.A. to Omnicell, Inc., which resulted in a discrete tax expense in the amount of $9.6 million during the three months ended March 31, 2019. The Company also recognized a discrete benefit related to equity compensation in the amount of $4.6 million and $0.9 million for the three months ended March 31, 2019 and March 31, 2018 respectively.

[0000926326-19-000013:notes:63]
The 2019 annual effective tax rate differed from the statutory rate of 21% primarily due to the unfavorable impact of the state income taxes, non-deductible equity charges, and non-deductible expenses, partially offset by the favorable impact of the research and development credits, foreign rate differential, and foreign derived intangible income (“FDII”) benefit deduction. The 2018 annual effective tax rate differed from the statutory rate of 21% primarily due to the favorable impact of the research and development credits and foreign rate differential, which were partially offset by the unfavorable impact of state income taxes, non-deductible expenses, and non-deductible equity charges.

[0000926326-19-000013:notes:64]
As of March 31, 2019 and December 31, 2018, the Company had gross unrecognized tax benefits of $14.3 million and $10.0 million, respectively. It is the Company’s policy to classify accrued interest and penalties as part of the unrecognized tax benefits, but to record interest and penalties in other income/expense in the consolidated statements of operations. As of March 31, 2019 and December 31, 2018, the amount of accrued interest and penalties was $1.5 million and $1.4 million, respectively.

[0000926326-19-000013:notes:65]
The Company files income tax returns in the United States and various states and foreign jurisdictions. In the normal course of business, the Company is subject to examination by taxing authorities, including major jurisdictions such as the United States, Germany, Italy, Netherlands, and the United Kingdom. With few exceptions, as of March 31, 2019, the Company is no longer subject to U.S., state, and foreign examination for years before 2015, 2014, and 2014, respectively.

[0000926326-19-000013:notes:66]
[same as prior period, unchanged from 0000926326-18-000030:notes:77]


## us-gaap:LeaseCostTableTextBlock

[0000926326-19-000013:notes:67]
The following table summarizes other information related to the Company’s operating leases for the three months ended March 31, 2019:

[0000926326-19-000013:notes:68]
|  | Three months ended March 31, 2019 |
|  | (Dollars in thousands) |
| Cash paid for amounts included in the measurement of lease liabilities | $ | 3,761 |  |
| Right-of-use assets obtained in exchange for new lease liabilities | 431 |  |
| Weighted-average remaining lease term, years | 7.0 |  |
| Weighted-average discount rate, % | 6.4 | % |


## us-gaap:LesseeLeasesPolicyTextBlock

[0000926326-19-000013:notes:69]
Lessee Leases

[0000926326-19-000013:notes:70]
The Company determines if an arrangement is a lease at inception. Operating lease right-of-use assets and liabilities are recognized at the commencement date based on the present value of lease payments over the lease term. As most of our lease contracts do not provide an implicit rate, the Company uses its incremental borrowing rate based on information available at the commencement date in determining the present value of the lease payments.

[0000926326-19-000013:notes:71]
Many of the Company’s operating leases include an option to extend the lease. The specific terms and conditions of the extension options vary from lease to lease, but are consistent with standard industry practices in each area that the Company operates. The Company reviews each of its lease options at a time required by the terms of the lease contract, and notifies the lessor if it chooses to exercise the lease renewal option. Until the Company is reasonably certain that it will extend the lease contract, the renewal option periods will not be recognized as right-of-use assets or lease liabilities.

[0000926326-19-000013:notes:72]
Certain leases include provisions for early termination, which allows the contract parties to terminate their obligations under the lease contract. The terms and conditions of the termination options vary by contract. When the Company has made a decision to exercise an early termination option, the right-of-use assets and associated lease liabilities are remeasured in accordance with the present value of the remaining cash flows under the lease contract.

[0000926326-19-000013:notes:73]
Certain building lease agreements include rental payments subject to change annually based on fluctuations in various indexes (i.e. Consumer Price Index (“CPI”), Retail Price Index, and other international indexes). Certain data center lease agreements include rental payments subject to change based on usage and CPI fluctuations. The changes based on usage and indexes are treated as variable lease costs and recognized in the period in which the obligation for those payments was incurred.

[0000926326-19-000013:notes:74]
The Company’s operating lease agreements do not contain any material residual value guarantees, restrictions, or restriction covenants.


## us-gaap:LesseeOperatingLeaseLiabilityMaturityTableTextBlock

[0000926326-19-000013:notes:75]
The maturity schedule of future minimum lease payments under operating leases and the reconciliation to the operating lease liabilities reported on the Condensed Consolidated Balance Sheets was as follows:

[0000926326-19-000013:notes:76]
|  | March 31, 2019 |
|  | (In thousands) |
| Remaining nine months of 2019 | $ | 10,737 |  |
| 2020 | 13,328 |  |
| 2021 | 12,831 |  |
| 2022 | 11,799 |  |
| 2023 | 8,415 |  |
| Thereafter | 27,832 |  |
| Total operating lease payments | $ | 84,942 |  |
| Present value adjustment | (17,099 | ) |
| Total operating lease liabilities (1) | $ | 67,843 |  |

[0000926326-19-000013:notes:77]
| (1) | Amount consists of a current and long-term portion of operating lease liabilities of $10.4 million and $57.5 million, respectively. The short-term portion of the operating lease liabilities is included in accrued liabilities in the Condensed Consolidated Balance Sheets. |


## us-gaap:LesseeOperatingLeasesTextBlock

[0000926326-19-000013:notes:78]
The Company has operating leases for office buildings, data centers, office equipment, and vehicles. The Company’s leases have initial terms of one to 12 years. As of March 31, 2019, the Company did not have any additional operating leases that were entered into, but not yet commenced.

[0000926326-19-000013:notes:79]
Prior to the adoption of the new lease accounting standard, the maturity schedule of future minimum lease payments under operating leases was as follows:

[0000926326-19-000013:notes:80]
|  | December 31, 2018 |
|  | (In thousands) |
| 2019 | $ | 14,153 |  |
| 2020 | 13,104 |  |
| 2021 | 12,729 |  |
| 2022 | 11,809 |  |
| 2023 | 8,334 |  |
| Thereafter | 27,289 |  |
| Total minimum future lease payments | $ | 87,418 |  |

[0000926326-19-000013:notes:81]
Operating lease costs were $3.7 million for the three months ended March 31, 2019. Short-term lease costs and variable lease costs were immaterial for the three months ended March 31, 2019.


## us-gaap:LessorLeasesPolicyTextBlock

[0000926326-19-000013:notes:82]
Lessor Leases

[0000926326-19-000013:notes:83]
The Company determines if an arrangement is a lease at inception. The transaction price is allocated to separate performance obligations, generally consisting of hardware and software products, installation, and post-installation technical support, proportionally based on the standalone selling price of each performance obligation. Standalone selling price is best evidenced by the price the Company charges for the good or service when selling it separately in similar circumstances to similar customers. Other than for the renewal of annual support services contracts, the Company’s products and services are not generally sold separately. The Company uses an amount discounted from the list price as a best estimated selling price.

[0000926326-19-000013:notes:84]
Sales-Type Leases

[0000926326-19-000013:notes:85]
The Company enters into non-cancelable sales-type lease arrangements, most of which do not have an option to extend the lease term. At the end of the lease term, the customer must either return the equipment or negotiate a new agreement, resulting in a new purchase or lease transaction. Failure of the customer to either return the equipment or negotiate a new agreement results in the contract becoming a month-to-month rental. Certain sales-type leases automatically renew for successive one year periods at the end of each lease term with written notice from the customer. The Company’s sales-type lease agreements do not contain any material residual value guarantees.

[0000926326-19-000013:notes:86]
For sales-type leases, the Company recognizes revenues for its hardware and software products, net of lease execution costs, post-installation product maintenance, and technical support, at the net present value of the lease payment stream upon customer acceptance. The Company recognizes service revenues associated with the sales-type leases ratably over the term of the agreement in service revenues on the Condensed Consolidated Statements of Operations. The Company recognizes interest income from sales-type leases using the effective interest method. Both hardware and software revenues, and interest income from sales-types leases are recorded in product revenues on the Condensed Consolidated Statements of Operations.

[0000926326-19-000013:notes:87]
The Company optimizes cash flows by selling a majority of its non-U.S. government sales-type leases to third-party leasing finance companies on a non-recourse basis. The Company has no obligation to the leasing company once the lease has been sold. Some of the Company's sales-type leases, mostly those relating to U.S. government hospitals which comprise approximately 44% of the lease receivable balance, are retained in-house.

[0000926326-19-000013:notes:88]
Operating Leases

[0000926326-19-000013:notes:89]
The Company entered into certain leasing agreements that were classified as operating leases prior to the adoption of the new lease accounting standard. Those agreements in place prior to January 1, 2019 will continue to be treated as operating leases, however any new leasing agreements entered into on or after January 1, 2019 under these programs are classified and accounted for as sales-type leases in accordance with the new lease accounting standard. The operating lease arrangements entered into prior to January 1, 2019 are non-cancelable, and most automatically renew for successive one year periods at the end of each lease term absent written notice from the customer. The Company’s operating lease agreements do not contain any material residual value guarantees.

[0000926326-19-000013:notes:90]
For operating leases, rental income is generally recognized on a straight-line basis over the term of the associated lease, and recorded in revenues in the Condensed Consolidated Statements of Operations. Leased assets under operating leases are carried at amortized cost net of accumulated depreciation in property and equipment, net on the Condensed Consolidated Balance Sheets. The depreciation expense of the leased assets is recognized on a straight-line basis over the contractual term of the associated lease, and recorded in cost of revenues in the Condensed Consolidated Statements of Operations.


## us-gaap:LessorOperatingLeasePaymentsToBeReceivedMaturityTableTextBlock

[0000926326-19-000013:notes:91]
The maturity schedule of future minimum lease payments under operating leases was as follows:

[0000926326-19-000013:notes:92]
|  | March 31, 2019 |
|  | (In thousands) |
| Remaining nine months of 2019 | 9,124 |  |
| 2020 | 9,349 |  |
| 2021 | 7,244 |  |
| 2022 | 5,205 |  |
| 2023 | 3,026 |  |
| Thereafter | 1,248 |  |
| Total future minimum operating lease payments | $ | 35,196 |  |


## us-gaap:LessorSalesTypeLeasesTextBlock

[0000926326-19-000013:notes:93]
On a recurring basis, the Company enters into multi-year, sales-type lease agreements, with the majority varying in length from one to five years. The following table presents the Company’s income recognized from sales-type leases for the three months ended March 31, 2019 and 2018:

[0000926326-19-000013:notes:94]
|  | Three months ended March 31, |
|  | 2019 |  | 2018 |
|  | (In thousands) |
| Sales-type lease revenues | $ | 11,507 |  |  | $ | 9,857 |  |
| Interest income on sales-type lease receivables | $ | 409 |  |  | $ | 267 |  |

[0000926326-19-000013:notes:95]
The receivables as a result of these types of transactions are collateralized by the underlying equipment leased and consist of the following components at March 31, 2019 and December 31, 2018:

[0000926326-19-000013:notes:96]
|  | March 31, 2019 |  | December 31, 2018 |
|  | (In thousands) |
| Net minimum lease payments to be received | $ | 30,806 |  |  | $ | 28,295 |  |
| Less: Unearned interest income portion | (2,348 | ) |  | (2,477 | ) |
| Net investment in sales-type leases | 28,458 |  |  | 25,818 |  |
| Less: Current portion (1) | (8,989 | ) |  | (8,736 | ) |
| Long-term net investment in sales-type leases | $ | 19,469 |  |  | $ | 17,082 |  |

[0000926326-19-000013:notes:97]
| (1) | The current portion of the net investment in sales-type leases is included in other current assets in the Condensed Consolidated Balance Sheets. |

[0000926326-19-000013:notes:98]
The carrying amount of the Company’s sales-type lease receivables is a reasonable estimate of fair value, as the unearned interest income is immaterial.

[0000926326-19-000013:notes:99]
The Company evaluates its sales-type leases individually and collectively for impairment. The allowance for credit losses was $0.2 million as of both March 31, 2019 and December 31, 2018.

[0000926326-19-000013:notes:100]
The maturity schedule of future minimum lease payments under sales-type leases retained in-house and the reconciliation to the net investment in sales-type leases reported on the Condensed Consolidated Balance Sheets was as follows:

[0000926326-19-000013:notes:101]
|  | March 31, 2019 |
|  | (In thousands) |
| Remaining nine months of 2019 | $ | 8,215 |  |
| 2020 | 8,016 |  |
| 2021 | 5,777 |  |
| 2022 | 5,081 |  |
| 2023 | 3,097 |  |
| Thereafter | 620 |  |
| Total future minimum sales-type lease payments | $ | 30,806 |  |
| Present value adjustment | (2,348 | ) |
| Total net investment in sales-type leases | $ | 28,458 |  |

[0000926326-19-000013:notes:102]
The Company entered into certain leasing agreements that were classified as operating leases prior to the adoption of the new lease accounting standard. These agreements in place prior to January 1, 2019 will continue to be treated as operating leases, however any new leasing agreements entered into on or after January 1, 2019 under these programs are classified and accounted for as sales-type leases in accordance with the new lease accounting standard. The operating lease arrangements have initial terms of one to seven years. The following table represents the Company’s income recognized from operating leases for the three months ended March 31, 2019 and 2018:

[0000926326-19-000013:notes:103]
|  | Three months ended March 31, |
|  | 2019 |  | 2018 |
|  | (In thousands) |
| Rental income | $ | 3,287 |  |  | $ | 2,790 |  |

[0000926326-19-000013:notes:104]
The net carrying value of the leased equipment under operating leases was $2.5 million and $2.6 million, which includes accumulated depreciation of $1.3 million and $1.2 million, as of March 31, 2019 and December 31, 2018, respectively. Depreciation of the leased equipment was $0.1 million for both the three months ended March 31, 2019 and 2018.


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0000926326-19-000013:notes:105]
The following table summarizes the geographic information for property and equipment, net, as of March 31, 2019 and December 31, 2018:

[0000926326-19-000013:notes:106]
|  | March 31, 2019 |  | December 31, 2018 |
|  | (In thousands) |
| United States | $ | 45,656 |  |  | $ | 44,684 |  |
| Rest of world (1) | 6,383 |  |  | 6,816 |  |
| Total property and equipment, net | $ | 52,039 |  |  | $ | 51,500 |  |

[0000926326-19-000013:notes:107]
[same as prior period, unchanged from 0000926326-18-000030:notes:80]


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000926326-19-000013:notes:108]
Recently Adopted Authoritative Guidance

[0000926326-19-000013:notes:109]
In February 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2016-02, Leases (Topic 842). The FASB amended lease accounting requirements to begin recording assets and liabilities arising from most leases on the balance sheet. The new guidance also requires significant additional disclosures about the amount and timing of cash flows from leases. The Company adopted this new guidance on January 1, 2019. In July 2018, the FASB issued amendments in ASU 2018-11, which provide a transition election to not restate comparative periods for the effects of applying the new standard. This transition election permits entities to change the date of initial application to the beginning of the year of adoption and to recognize the effects of applying the new standard as a cumulative-effect adjustment to the opening balance of retained earnings. The Company has elected this transition approach as well as elected the package of practical expedients permitted under the transition guidance within the new standard, which will allow the Company to carry forward the historical lease classification of contracts entered into prior to January 1, 2019. As a result of electing the package of practical expedients described above, existing leases and related initial direct costs have not been reassessed prior to the effective date, and therefore, adoption of the lease standard did not have an impact on the Company’s previously reported consolidated statements.

[0000926326-19-000013:notes:110]
The Company also elected the following practical expedients: (i) combining lease and non-lease components, (ii) leases with an initial term of 12 months or less are not recorded in the Condensed Consolidated Balance Sheets, and the associated lease payments are recognized in the Condensed Consolidated Statements of Operations on a straight-line basis over the lease term, and (iii) applying discount rates to operating leases using a portfolio approach.

[0000926326-19-000013:notes:111]
From a lessor perspective, certain agreements that were previously classified as operating leases are classified as sales-type leases under the new lease accounting standard. The agreements in place prior to the adoption of the new lease accounting standard on January 1, 2019 will continue to be treated as operating leases.

[0000926326-19-000013:notes:112]
The Company’s adoption of the new standard impacted the Condensed Consolidated Balances Sheets at the beginning of the period of adoption as follows:

[0000926326-19-000013:notes:113]
|  | January 1, 2019 |
|  | Pre-ASC 842 Balances |  | ASC 842 Adoption Impact |  | Post-ASC 842 Balances |
|  | (In thousands) |
| Operating lease right-of-use assets | $ | — |  |  | $ | 66,008 |  |  | $ | 66,008 |  |
| Accrued liabilities (1) | 43,047 |  |  | 10,067 |  |  | 53,114 |  |
| Long-term operating lease liabilities | — |  |  | 59,791 |  |  | 59,791 |  |
| Other long-term liabilities (2) | 9,562 |  |  | (3,850 | ) |  | 5,712 |  |

[0000926326-19-000013:notes:114]
| (1) | Adjustment represents the current portion of the operating lease liabilities of $10.3 million, and reclassification of exit cost obligations and deferred rent of $0.1 million and $0.1 million, respectively, to reduce the operating lease right-of-use assets. |

[0000926326-19-000013:notes:115]
| (2) | Adjustment represents the reclassification of deferred rent to reduce the operating lease right-of-use assets. |

[0000926326-19-000013:notes:116]
Adoption of the standard did not have an impact on the Company’s stockholders’ equity, Condensed Consolidated Statements of Operations, and Condensed Consolidated Statements of Cash Flows as of January 1, 2019.

[0000926326-19-000013:notes:117]
In February 2018, the FASB issued ASU 2018-02, Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income, which permits the reclassification of the income tax effects of the Tax Cuts and Jobs Act of 2017 (the “Tax Act”) on items within accumulated other comprehensive income to retained earnings. These amounts are commonly referred to as “stranded tax effects.” ASU 2018-02 is effective for the Company beginning January 1, 2019. The adoption of this guidance did not have a material effect on the Company’s consolidated financial statements and therefore no adjustment to retained earnings was made.

[0000926326-19-000013:notes:118]
Recently Issued Authoritative Guidance

[0000926326-19-000013:notes:119]
In August 2018, the FASB issued ASU 2018-15, Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract, to align the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software (and hosting arrangements that include an internal-use software license). ASU 2018-15 will be effective for the Company beginning January 1, 2020. The Company is currently evaluating the impact ASU 2018-15 will have on its consolidated financial statements.

[0000926326-19-000013:notes:120]
There was no other recently issued and effective authoritative guidance that is expected to have a material impact on the Company’s Condensed Consolidated Financial Statements through the reporting date.


## us-gaap:NonvestedRestrictedStockSharesActivityTableTextBlock

[0000926326-19-000013:notes:121]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |
|  | (In thousands, except per share data) |
| Restricted stock awards |  |  |  |
| Outstanding at December 31, 2018 | 21 |  |  | $ | 46.60 |  |
| Granted (Awarded) | — |  |  | — |  |
| Vested (Released) | — |  |  | — |  |
| Forfeited | — |  |  | — |  |
| Outstanding and unvested at March 31, 2019 | 21 |  |  | $ | 46.60 |  |


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000926326-19-000013:notes:122]
[same as prior period, unchanged from 0000926326-18-000030:notes:99]

[0000926326-19-000013:notes:123]
[same as prior period, unchanged from 0000926326-18-000030:notes:100]

[0000926326-19-000013:notes:124]
Omnicell, Inc. was incorporated in California in 1992 under the name Omnicell Technologies, Inc. and reincorporated in Delaware in 2001 as Omnicell, Inc. The Company’s major products are medication and supply dispensing automation solutions, central pharmacy automation solutions, analytics software, and medication adherence solutions which are sold in its principal market, which is the healthcare industry. The Company’s market is primarily located in the United States and Europe. “Omnicell” or the “Company” collectively refer to Omnicell, Inc. and its subsidiaries.

[0000926326-19-000013:notes:125]
The Company reclassified $0.6 million from services and other revenues to product revenues for the three months ended March 31, 2018 related to software term-license sales to conform with current period presentation. This reclassification did not have a material impact on the condensed consolidated financial statements.

[0000926326-19-000013:notes:126]
[same as prior period, unchanged from 0000926326-18-000030:notes:134]

[0000926326-19-000013:notes:127]
The Company's Chief Operating Decision Maker ("CODM") is its Chief Executive Officer. The CODM allocates resources and evaluates the performance of the Company using information about its revenues, gross profit, income from operations, and other key financial data. The Company previously operated and reported its business in two segments: Automation and Analytics, and Medication Adherence. In the fourth quarter of 2018, the Company introduced its vision of the Autonomous Pharmacy, a more fully automated and digitized system of medication management, in order to address changes in the healthcare industry as the Company executes on its plan to deliver end-to-end solutions with greater emphasis on automating manual processes for its customers. These industry changes include the continuing consolidation of healthcare systems, rising pharmaceutical costs, and increased scrutiny on controlled substances. In an effort to deliver on its strategic vision, the Company initiated a company-wide organizational realignment in the fourth quarter of 2018 to centrally manage its business operations, including the development and marketing of all of the Company’s products, sales and distribution, supply chain and inventory management, as well as regulatory and quality functions. As a result of this organizational realignment, all significant operating decisions are based upon an analysis of the Company as one operating segment. Therefore, effective January 1, 2019, the Company started reporting as only one operating segment, which is the same as the reporting segment. Accordingly, prior period information has been revised to conform with current period presentation.

[0000926326-19-000013:notes:128]
[same as prior period, unchanged from 0000926326-18-000030:notes:132]

[0000926326-19-000013:notes:129]
The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s Condensed Consolidated Financial Statements and accompanying Notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. The Company’s critical accounting policies are those that affect its financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition; accounts receivable and notes receivable from investment in sales-type leases; operating lease right-of-use assets and liabilities; inventory valuation; capitalized software development costs; impairment of goodwill; purchased intangibles and long-lived assets; share-based compensation; and accounting for income taxes.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000926326-19-000013:notes:130]
Property and Equipment

[0000926326-19-000013:notes:131]
The following table represents the property and equipment balances as of March 31, 2019 and December 31, 2018:

[0000926326-19-000013:notes:132]
|  | March 31, 2019 |  | December 31, 2018 |
|  | (In thousands) |
| Equipment | $ | 76,668 |  |  | $ | 75,417 |  |
| Furniture and fixtures | 8,122 |  |  | 7,844 |  |
| Leasehold improvements | 16,381 |  |  | 16,274 |  |
| Software | 42,305 |  |  | 42,048 |  |
| Construction in progress | 11,791 |  |  | 10,706 |  |
| Property and equipment, gross | 155,267 |  |  | 152,289 |  |
| Accumulated depreciation and amortization | (103,228 | ) |  | (100,789 | ) |
| Total property and equipment, net | $ | 52,039 |  |  | $ | 51,500 |  |

[0000926326-19-000013:notes:133]
Depreciation expense of property and equipment was $4.0 million and $3.5 million for the three months ended March 31, 2019 and 2018, respectively.

[0000926326-19-000013:notes:134]
The geographic location of the Company's property and equipment, net, is based on the physical location in which it is located. The following table summarizes the geographic information for property and equipment, net, as of March 31, 2019 and December 31, 2018:


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000926326-19-000013:notes:135]
[same as prior period, unchanged from 0000926326-18-000030:notes:137]

[0000926326-19-000013:notes:136]
In the fourth quarter of 2018, the Company announced a company-wide organizational realignment initiative in order to align its organizational infrastructure for future expected growth. During the year ended December 31, 2018, the Company incurred and accrued for $1.3 million of restructuring expenses, which includes severance and consulting-related expenses. As of March 31, 2019, the unpaid balance related to this restructuring plan was $0.1 million.

[0000926326-19-000013:notes:137]
On March 2, 2018, the Company initiated the realignment of its Automation and Analytics commercial group in North America and France. During the three months ended March 31, 2018, the Company accrued $1.4 million of employee severance cost and related expenses. As of December 31, 2018, there was no unpaid balance related to this restructuring program.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000926326-19-000013:notes:138]
Revenues

[0000926326-19-000013:notes:139]
Revenue Recognition

[0000926326-19-000013:notes:140]
The Company earns revenues from sales of its medication and supply dispensing automation systems, along with consumables and related services, which are sold in the healthcare industry, its principal market. The Company’s customer arrangements typically include one or more of the following performance obligations:

[0000926326-19-000013:notes:141]
Products. Software-enabled equipment that manages and regulates the storage and dispensing of pharmaceuticals, consumable blister cards and packaging equipment and other medical supplies.

[0000926326-19-000013:notes:142]
Software. Additional software applications that enable incremental functionality of the Company’s equipment or services.

[0000926326-19-000013:notes:143]
Installation. Installation of equipment as integrated systems at customer sites.

[0000926326-19-000013:notes:144]
Post-installation technical support. Phone support, on-site service, parts, and access to unspecified software updates and enhancements, if and when available.

[0000926326-19-000013:notes:145]
Professional services. Other customer services, such as training and consulting.

[0000926326-19-000013:notes:146]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”). GPOs are often owned fully or in part by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs were $2.2 million and $1.9 million for the three months ended March 31, 2019 and 2018, respectively.

[0000926326-19-000013:notes:147]
Disaggregation of Revenues

[0000926326-19-000013:notes:148]
The following table summarizes the Company’s product revenues disaggregated by revenue type for the three months ended March 31, 2019 and 2018:

[0000926326-19-000013:notes:149]
|  | Three months ended March 31, |
|  | 2019 |  | 2018 |
|  | (In thousands) |
| Hardware and software | $ | 120,221 |  |  | $ | 107,451 |  |
| Consumables | 21,087 |  |  | 19,438 |  |
| Other | 4,302 |  |  | 3,770 |  |
| Total product revenues | $ | 145,610 |  |  | $ | 130,659 |  |

[0000926326-19-000013:notes:150]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location, for the three months ended March 31, 2019 and 2018:

[0000926326-19-000013:notes:151]
|  | Three months ended March 31, |
|  | 2019 |  | 2018 |
|  | (In thousands) |
| United States | $ | 180,020 |  |  | $ | 158,202 |  |
| Rest of world (1) | 22,497 |  |  | 24,417 |  |
| Total revenues | $ | 202,517 |  |  | $ | 182,619 |  |

[0000926326-19-000013:notes:152]
Contract Assets and Contract Liabilities

[0000926326-19-000013:notes:153]
The portion of the transaction price allocated to the Company’s unsatisfied performance obligations is recorded as deferred revenues.

[0000926326-19-000013:notes:154]
Short-term deferred revenues of $90.1 million and $81.8 million include deferred revenues from product sales and service contracts, net of deferred cost of sales, of $12.2 million and $11.1 million as of March 31, 2019 and December 31, 2018, respectively. The short-term deferred revenues from product sales relate to delivered and invoiced products, pending installation and acceptance, expected to occur within the next twelve months. During the three months ended March 31, 2019, the Company recognized revenues of $39.3 million that were included in the corresponding gross short-term deferred revenues balance of $92.9 million as of December 31, 2018.

[0000926326-19-000013:notes:155]
Long-term deferred revenues include deferred revenues from service contracts of $10.3 million and $10.6 million as of March 31, 2019 and December 31, 2018, respectively. Remaining performance obligations primarily relate to maintenance contracts and are recognized ratably over the remaining term of the contract, generally not more than five years.

[0000926326-19-000013:notes:156]
Significant Customers

[0000926326-19-000013:notes:157]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three months ended March 31, 2019 and 2018. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable as of March 31, 2019 and December 31, 2018.


## us-gaap:SalesTypeLeaseLeaseIncomeTableTextBlock

[0000926326-19-000013:notes:158]
The following table presents the Company’s income recognized from sales-type leases for the three months ended March 31, 2019 and 2018:


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0000926326-19-000013:notes:159]
The following table summarizes the changes in accumulated balances of other comprehensive income (loss) for the three months ended March 31, 2019 and 2018:

[0000926326-19-000013:notes:160]
|  | Three months ended March 31, |
|  | 2019 |  | 2018 |
|  | Foreign currency translation adjustments |  | Unrealized gain (loss) on interest rate swap hedges |  | Total |  | Foreign currency translation adjustments |  | Unrealized gain (loss) on interest rate swap hedges |  | Total |
|  | (In thousands) |
| Beginning balance | $ | (11,274 | ) |  | $ | 420 |  |  | $ | (10,854 | ) |  | $ | (6,954 | ) |  | $ | 841 |  |  | $ | (6,113 | ) |
| Other comprehensive income before reclassifications | 669 |  |  | 100 |  |  | 769 |  |  | 2,472 |  |  | 401 |  |  | 2,873 |  |
| Amounts reclassified from other comprehensive income (loss), net of tax | — |  |  | (417 | ) |  | (417 | ) |  | — |  |  | (199 | ) |  | (199 | ) |
| Net current-period other comprehensive income (loss), net of tax | 669 |  |  | (317 | ) |  | 352 |  |  | 2,472 |  |  | 202 |  |  | 2,674 |  |
| Ending balance | $ | (10,605 | ) |  | $ | 103 |  |  | $ | (10,502 | ) |  | $ | (4,482 | ) |  | $ | 1,043 |  |  | $ | (3,439 | ) |


## us-gaap:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTextBlock

[0000926326-19-000013:notes:161]
The following table sets forth the total share-based compensation expense recognized in the Company’s Condensed Consolidated Statements of Operations for the three months ended March 31, 2019 and 2018:

[0000926326-19-000013:notes:162]
|  | Three months ended |
|  | March 31, 2019 |  | March 31, 2018 |
|  | (In thousands) |
| Cost of product and service revenues | $ | 1,462 |  |  | $ | 1,019 |  |
| Research and development | 1,702 |  |  | 1,234 |  |
| Selling, general, and administrative | 5,246 |  |  | 4,275 |  |
| Total share-based compensation expense | $ | 8,410 |  |  | $ | 6,528 |  |


## us-gaap:ScheduleOfNonvestedRestrictedStockUnitsActivityTableTextBlock

[0000926326-19-000013:notes:163]
Summaries of the restricted stock activity under the Company’s 2009 Equity Incentive Plan, as amended (the “2009 Plan”) are presented below for the three months ended March 31, 2019:

[0000926326-19-000013:notes:164]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Restricted stock units |  |  |  |  |  |  |  |
| Outstanding at December 31, 2018 | 538 |  |  | $ | 51.52 |  |  | 1.6 |  | $ | 32,935 |  |
| Granted (Awarded) | 30 |  |  | 78.23 |  |  |  |  |  |
| Vested (Released) | (36 | ) |  | 39.78 |  |  |  |  |  |
| Forfeited | (27 | ) |  | 44.87 |  |  |  |  |  |
| Outstanding and unvested at March 31, 2019 | 505 |  |  | $ | 54.32 |  |  | 1.5 |  | $ | 40,813 |  |


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0000926326-19-000013:notes:165]
The following table summarizes the share option activity under the Company’s equity incentive plans during the three months ended March 31, 2019:

[0000926326-19-000013:notes:166]
|  | Number ofShares |  | Weighted-AverageExercise Price |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2018 | 3,748 |  |  | $ | 41.27 |  |  | 7.6 |  | $ | 78,365 |  |
| Granted | 292 |  |  | 76.18 |  |  |  |  |  |
| Exercised | (379 | ) |  | 31.83 |  |  |  |  |  |
| Expired | — |  |  | — |  |  |  |  |  |
| Forfeited | (117 | ) |  | 44.18 |  |  |  |  |  |
| Outstanding at March 31, 2019 | 3,544 |  |  | $ | 45.06 |  |  | 7.9 |  | $ | 127,007 |  |
| Exercisable at March 31, 2019 | 1,275 |  |  | $ | 31.24 |  |  | 6.3 |  | $ | 63,241 |  |
| Vested and expected to vest at March 31, 2019 and thereafter | 3,544 |  |  | $ | 45.06 |  |  | 7.9 |  | $ | 127,007 |  |


## us-gaap:ScheduleOfShareBasedPaymentAwardEmployeeStockPurchasePlanValuationAssumptionsTableTextBlock

[0000926326-19-000013:notes:167]
|  | Three months ended |
|  | March 31, 2019 |  | March 31, 2018 |
| Employee stock purchase plan shares |  |  |  |
| Expected life, years | 0.5 - 2.0 |  |  | 0.5 - 2.0 |  |
| Expected volatility, % | 28.2% - 38.4% |  |  | 27.7% - 33.8% |  |
| Risk-free interest rate, % | 1.3% - 2.7% |  |  | 0.7% - 2.3% |  |
| Dividend yield, % | — | % |  | — | % |


## us-gaap:ScheduleOfShareBasedPaymentAwardStockOptionsValuationAssumptionsTableTextBlock

[0000926326-19-000013:notes:168]
The following assumptions were used to value stock options and Employee Stock Purchase Plan (“ESPP”) shares granted pursuant to the Company’s equity incentive plans for the three months ended March 31, 2019 and 2018:

[0000926326-19-000013:notes:169]
|  | Three months ended |
|  | March 31, 2019 |  | March 31, 2018 |
| Stock options |  |  |  |
| Expected life, years | 4.5 |  |  | 4.8 |  |
| Expected volatility, % | 33.1 | % |  | 32.2 | % |
| Risk-free interest rate, % | 2.6 | % |  | 2.6 | % |
| Estimated forfeiture rate, % | 7.2 | % |  | 6.9 | % |
| Dividend yield, % | — | % |  | — | % |


## us-gaap:ShareBasedCompensationPerformanceSharesAwardUnvestedActivityTableTextBlock

[0000926326-19-000013:notes:170]
A summary of the performance-based restricted stock activity under the 2009 Plan is presented below for the three months ended March 31, 2019:

[0000926326-19-000013:notes:171]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value Per Unit |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2018 | 197 |  |  | $ | 34.83 |  |
| Granted | 61 |  |  | 72.02 |  |
| Vested | (26 | ) |  | 38.03 |  |
| Forfeited | (20 | ) |  | 34.37 |  |
| Outstanding and unvested at March 31, 2019 | 212 |  |  | $ | 45.18 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000926326-19-000013:notes:172]
[same as prior period, unchanged from 0000926326-18-000030:notes:174]

[0000926326-19-000013:notes:173]
[same as prior period, unchanged from 0000926326-18-000030:notes:175]

[0000926326-19-000013:notes:174]
For a detailed explanation of the Company's stock plans, please refer to Note 11, Employee Benefits and Share-Based Compensation, of the Company's annual report on Form 10-K for the year ended December 31, 2018 filed with the SEC on February 27, 2019.

[0000926326-19-000013:notes:175]
[same as prior period, unchanged from 0000926326-18-000030:notes:177]

[0000926326-19-000013:notes:176]
In the first quarter of 2019, the Company modified the terms of its stock options by extending the post-employment exercise period for certain employees. The Company recorded share-based compensation expense related to this option modification of approximately $0.2 million during the three months ended March 31, 2019. The Company will incur an additional $0.8 million of share-based compensation expense for the impacted options over the remaining weighted-average vesting periods of 1.9 years.

[0000926326-19-000013:notes:177]
[same as prior period, unchanged from 0000926326-18-000030:notes:178]

[0000926326-19-000013:notes:178]
[same as prior period, unchanged from 0000926326-18-000030:notes:179]

[0000926326-19-000013:notes:179]
The weighted-average fair value per share of options granted during the three months ended March 31, 2019 and 2018 was $24.07 and $14.22, respectively. The intrinsic value of options exercised during the three months ended March 31, 2019 and 2018 was $17.1 million and $2.0 million, respectively.

[0000926326-19-000013:notes:180]
As of March 31, 2019, total unrecognized compensation cost related to unvested stock options was $32.5 million, which is expected to be recognized over a weighted-average vesting period of 2.9 years.

[0000926326-19-000013:notes:181]
[same as prior period, unchanged from 0000926326-18-000030:notes:182]

[0000926326-19-000013:notes:182]
For the three months ended March 31, 2019 and 2018, employees purchased approximately 210,000 and 289,000 shares of common stock, respectively, under the ESPP at weighted average prices of $40.20 and $26.30, respectively. As of March 31, 2019, the unrecognized compensation cost related to the shares to be purchased under the ESPP was approximately $3.9 million and is expected to be recognized over a weighted-average period of 1.5 years.

[0000926326-19-000013:notes:183]
Restricted Stock Units (“RSUs”) and Restricted Stock Awards (“RSAs”)

[0000926326-19-000013:notes:184]
As of March 31, 2019, total unrecognized compensation cost related to RSUs was $23.4 million, which is expected to be recognized over the remaining weighted-average vesting period of 2.7 years.

[0000926326-19-000013:notes:185]
As of March 31, 2019, total unrecognized compensation cost related to RSAs was $0.1 million, which is expected to be recognized over the remaining weighted-average vesting period of 0.1 years.

[0000926326-19-000013:notes:186]
[same as prior period, unchanged from 0000926326-18-000030:notes:187]

[0000926326-19-000013:notes:187]
As of March 31, 2019, total unrecognized compensation cost related to PSUs was approximately $5.3 million, which is expected to be recognized over the remaining weighted-average period of 1.3 years.

[0000926326-19-000013:notes:188]
[same as prior period, unchanged from 0000926326-18-000030:notes:189]

[0000926326-19-000013:notes:189]
[same as prior period, unchanged from 0000926326-18-000030:notes:190]

[0000926326-19-000013:notes:190]
On August 2, 2016, the Company's Board of Directors (the “Board”) authorized a stock repurchase program providing for the repurchase of up to $50.0 million of the Company’s common stock (the “2016 Repurchase Program”). The 2016 Repurchase Program is in addition to the stock repurchase program approved by the Board on November 4, 2014 (the “2014 Repurchase Program”). As of March 31, 2019, the maximum dollar value of shares that may yet be purchased under the two repurchase programs was $54.9 million. The stock repurchase programs do not obligate the Company to repurchase any specific number of shares, and the Company may terminate or suspend the repurchase programs at any time.

[0000926326-19-000013:notes:191]
During the three months ended March 31, 2019 and 2018, the Company did not repurchase any of its outstanding common stock.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000926326-19-000013:notes:192]
[same as prior period, unchanged from 0000926326-18-000030:notes:193]

[0000926326-19-000013:notes:193]
On November 3, 2017, the Company entered into a Distribution Agreement (the “Distribution Agreement”) with J.P. Morgan Securities LLC, Wells Fargo Securities, LLC, and HSBC Securities (USA) Inc., as its sales agents, pursuant to which the Company may offer and sell from time to time through the sales agents up to $125.0 million maximum aggregate offering price of the Company’s common stock. Sales of the common stock pursuant to the Distribution Agreement may be made in negotiated transactions or transactions that are deemed to be “at the market” offerings as defined in Rule 415 under the Securities Act of 1933, including sales made directly on the Nasdaq Stock Market, or sales made to or through a market maker other than on an exchange.

[0000926326-19-000013:notes:194]
For the three months ended March 31, 2019, the Company received gross proceeds of $20.6 million from sales of its common stock under the Distribution Agreement and incurred issuance costs of $0.4 million on sales of approximately 243,000 shares of its common stock at an average price of approximately $84.98 per share. For the three months ended March 31, 2018, the Company did not sell any of its common stock under the Distribution Agreement.

[0000926326-19-000013:notes:195]
As of March 31, 2019, the Company had an aggregate of $49.4 million available to be offered under the Distribution Agreement.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000926326-19-000013:notes:196]
[same as prior period, unchanged from 0000926326-18-000030:notes:196]
