# OMCL MD&A — 0000926326-19-000013


## mdna

[0000926326-19-000013:mdna:1]
[same as prior period, unchanged from 0000926326-18-000030:mdna:1]

[0000926326-19-000013:mdna:2]
[same as prior period, unchanged from 0000926326-18-000030:mdna:2]

[0000926326-19-000013:mdna:3]
This quarterly report on Form 10-Q contains forward-looking statements. The forward-looking statements are contained principally in the sections entitled “Risk Factors” and “Management's Discussion and Analysis of Financial Condition and Results of Operations.” Forward-looking statements include, but are not limited to, statements about:

[0000926326-19-000013:mdna:4]
[same as prior period, unchanged from 0000926326-18-000030:mdna:4]

[0000926326-19-000013:mdna:5]
[same as prior period, unchanged from 0000926326-18-000030:mdna:6]

[0000926326-19-000013:mdna:6]
[same as prior period, unchanged from 0000926326-18-000030:mdna:7]

[0000926326-19-000013:mdna:7]
[same as prior period, unchanged from 0000926326-18-000030:mdna:8]

[0000926326-19-000013:mdna:8]
| • | our continued investment in, and ability to deliver on, our key business strategies of developing differentiated solutions, increasing penetration of new markets, and expanding our solutions through acquisitions and partnerships, as well as our goal of advancing our platform with new product introductions annually; |

[0000926326-19-000013:mdna:9]
| • | our ability to deliver on our vision of the Autonomous Pharmacy and lead a transformation management through this vision, as well as our plans to integrate our current offerings and technologies on cloud infrastructure and invest in certain key areas as we execute on this vision; |

[0000926326-19-000013:mdna:10]
| • | continued investment in our vision of the Autonomous Pharmacy, our beliefs about the anticipated benefits of such investments, and our expectations regarding continued growth in subscription and cloud-based offerings as we execute on this vision; |

[0000926326-19-000013:mdna:11]
| • | our belief that continued investment in our key business strategies will continue to generate our revenue and earnings growth while supporting our customers’ initiatives and needs; |

[0000926326-19-000013:mdna:12]
| • | our belief that our solutions and our vision for the future of medication management automation are strongly aligned with long-term trends in the healthcare market and well-positioned to address the evolving needs of the healthcare institutions; |

[0000926326-19-000013:mdna:13]
[same as prior period, unchanged from 0000926326-18-000030:mdna:12]

[0000926326-19-000013:mdna:14]
[same as prior period, unchanged from 0000926326-18-000030:mdna:13]

[0000926326-19-000013:mdna:15]
[same as prior period, unchanged from 0000926326-18-000030:mdna:14]

[0000926326-19-000013:mdna:16]
[same as prior period, unchanged from 0000926326-18-000030:mdna:15]

[0000926326-19-000013:mdna:17]
[same as prior period, unchanged from 0000926326-18-000030:mdna:16]

[0000926326-19-000013:mdna:18]
| • | the expected impacts of new accounting standards or changes to existing accounting standards; and |

[0000926326-19-000013:mdna:19]
[same as prior period, unchanged from 0000926326-18-000030:mdna:19]

[0000926326-19-000013:mdna:20]
In some cases, you can identify forward-looking statements by terms such as "anticipates," "believes," "could," "estimates," "expects," "intends," "seeks," "may," "plans," "potential," "predicts," "projects," "should," "will," "would" and variations of these terms and similar expressions. Forward-looking statements are based on our current expectations and assumptions and are subject to known and unknown risks and uncertainties, which may cause our actual results, performance, or achievements to be materially different from those expressed or implied in the forward-looking statements.

[0000926326-19-000013:mdna:21]
Such risks and uncertainties include those described throughout this quarterly report, particularly in Part II - Item 1A. “Risk Factors” below. Given these risks and uncertainties, you should not place undue reliance on these forward-looking statements. You should carefully read this quarterly report and the documents that we reference in this quarterly report and have filed as exhibits, as well as other documents we file from time to time with the Securities and Exchange Commission, with the understanding that our actual future results may be materially different from what we expect. All references in this report to "Omnicell," "our," "us," "we," or the "Company" collectively refer to Omnicell, Inc., a Delaware corporation, and its

[0000926326-19-000013:mdna:22]
We own various trademarks and service marks used in our business, including the following registered and unregistered marks which appear in this report: Omnicell®, the Omnicell logo, Ateb®, InPharmics®, Aesynt®, and Performance CenterTM. This report also includes the trademarks and service marks of other companies. All other trademarks and service marks used in this report are the marks of their respective holders.

[0000926326-19-000013:mdna:23]
[same as prior period, unchanged from 0000926326-18-000030:mdna:23]

[0000926326-19-000013:mdna:24]
[same as prior period, unchanged from 0000926326-18-000030:mdna:24]

[0000926326-19-000013:mdna:25]
We are a leading provider of medication and supply dispensing automation, central pharmacy automation, analytics software, and medication adherence solutions. As we build on our vision of the Autonomous Pharmacy - a more fully automated and digitized system of medication management - we believe we will further help enable healthcare providers to improve patient safety, increase efficiency, lower costs, tighten regulatory compliance, and address population health challenges.

[0000926326-19-000013:mdna:26]
Over 5,500 facilities worldwide use our automation and analytics solutions to help increase operational efficiency, reduce medication errors, deliver actionable intelligence, and improve patient safety. More than 40,000 institutional and retail pharmacies across North America and the United Kingdom leverage our innovative medication adherence solutions designed to improve patient engagement and adherence to prescriptions, helping to reduce costly hospital readmissions.

[0000926326-19-000013:mdna:27]
We sell our product and consumable solutions together with related service offerings. Revenues generated in the United States represented 89% and 87% of our total revenues for the three months ended March 31, 2019 and 2018, respectively. We have not in the past sold, and have no future plans to sell, our products, either directly or indirectly, to customers located in countries that are identified as state sponsors of terrorism by the U.S. Department of State, or those subject to economic sanctions and export controls.

[0000926326-19-000013:mdna:28]
[same as prior period, unchanged from 0000926326-18-000030:mdna:26]

[0000926326-19-000013:mdna:29]
Our Chief Operating Decision Maker ("CODM") is our Chief Executive Officer. The CODM allocates resources and evaluates Omnicell’s performance using information about our revenues, gross profit, income from operations, and other key financial data. We previously operated and reported our business in two segments: Automation and Analytics, and Medication Adherence. In the fourth quarter of 2018, we introduced our vision of the Autonomous Pharmacy in order to address changes in the healthcare industry as we execute on our plan to deliver end-to-end solutions with a greater emphasis on automating manual processes for our customers. These industry changes include the continuing consolidation of healthcare systems, rising pharmaceutical costs, and increased scrutiny on controlled substances. In an effort to deliver on our strategic vision, we initiated a company-wide organizational realignment in the fourth quarter of 2018 to centrally manage our business operations, including the development and marketing of all of our products, sales and distribution, supply chain and inventory management, as well as regulatory and quality functions. As a result of this organizational realignment, all significant operating decisions are based upon an analysis of Omnicell as one operating segment. Therefore, effective January 1, 2019, we started reporting as only one operating segment, which is the same as the reporting segment. Accordingly, prior period information has been revised to conform with current period presentation.

[0000926326-19-000013:mdna:30]
[same as prior period, unchanged from 0000926326-18-000030:mdna:32]

[0000926326-19-000013:mdna:31]
The healthcare market is experiencing a period of substantive change. In recent years, healthcare providers and facilities have faced increased spending on medication management, rising pharmaceutical costs, and substantial increases in healthcare administration. These factors, combined with continuing consolidation in the healthcare industry, have increased the need for the efficient delivery of healthcare in order to control costs and improve patient safety, and have elevated the strategic importance of medication management across the continuum of care. Furthermore, the adoption of electronic healthcare records, new regulatory constraints, and changes in reimbursement arrangements have caused healthcare institutions to re-examine their operating structures, re-prioritize their investments, and seek efficiencies. We believe the evolving operating environments of our customers create challenges for any supplier, but also afford opportunities for suppliers that are able to partner with customers to help them meet the changing demands. We have invested, and intend to continue to invest in the strategies that we believe have generated, and will continue to generate, our revenue and earnings growth, while supporting initiatives and needs of our customers. These strategies include:

[0000926326-19-000013:mdna:32]
| • | Development of a differentiated platform. We intend to continue our focus on further penetrating existing markets through technological leadership and our differentiated platform by consistently innovating our product and service offerings and maintaining our customer-oriented product installation process. We have developed numerous technologies that solve significant challenges for our customers. For example, our XR2 Automated Central Pharmacy System is designed to allow pharmacies to more fully automate medication dispensing, and help to reduce labor cost, decrease medication waste, and improve patient safety; our IVX Workflow solution is designed to reduce medication compounding errors compared to manual compounding methods; and our Performance Center offering leverages predictive analytics to help pharmacies be more proactive in addressing drug shortages. |

[0000926326-19-000013:mdna:33]
| • | Delivery of our solutions to new markets. We seek to increase penetration of new markets, such as non-acute care and international markets by: launching new products and technologies that are specific to the needs of those markets; building and establishing direct sales, distribution or other capabilities when and where it is appropriate; partnering with companies that have sales, distribution, or other capabilities that we do not possess; and increasing customer awareness of safety issues in the administration of medications. Consistent with this strategy, we have made investments in expanding our sales team and marketing to new customers. Our international efforts have focused primarily on two markets: Western Europe and the Middle East. We have also expanded our sales efforts to medication adherence customers in the United States. |

[0000926326-19-000013:mdna:34]
| • | Expansion of our solutions through acquisitions and partnerships. We believe that expansion of our product lines through acquisitions and partnerships to meet our customers’ changing and evolving expectations is a key component to our historical and future success. Building on the successful acquisitions of the past few years, we intend to continue to explore acquisition and partnership opportunities that are a strategic fit for our business, including in support of our Autonomous Pharmacy vision. We have also developed relationships with major providers of hospital information management systems with the goal of enhancing the interoperability of our products with their systems. |

[0000926326-19-000013:mdna:35]
Among other financial measures, we utilize product bookings to assess the current success of our strategies. Product bookings consist of all firm orders, as evidenced generally by a non-cancelable contract and purchase order for equipment and software, and by a purchase order for consumables. Equipment and software bookings are generally installable within twelve months and, other than sales based on subscription services, generally recorded as revenue upon customer acceptance of the installation. Consumables are recorded as revenue upon shipment to a customer or receipt by the customer, depending upon contract terms. Consumable bookings are generally recorded as revenue within one month.

[0000926326-19-000013:mdna:36]
[same as prior period, unchanged from 0000926326-18-000030:mdna:47]

[0000926326-19-000013:mdna:37]
In the future, we expect our strategies to evolve as the business environment of our customers evolves, but for our focus to remain on improving outcomes for healthcare providers and patients. We expect our investment in differentiated products, new markets, and acquisitions and partnerships to continue.

[0000926326-19-000013:mdna:38]
Our full-time headcount was approximately 2,470 and 2,480 on March 31, 2019 and December 31, 2018, respectively.

[0000926326-19-000013:mdna:39]
[same as prior period, unchanged from 0000926326-18-000030:mdna:55]

[0000926326-19-000013:mdna:40]
[same as prior period, unchanged from 0000926326-18-000030:mdna:56]

[0000926326-19-000013:mdna:41]
[same as prior period, unchanged from 0000926326-18-000030:mdna:57]

[0000926326-19-000013:mdna:42]
[same as prior period, unchanged from 0000926326-18-000030:mdna:58]

[0000926326-19-000013:mdna:43]
[same as prior period, unchanged from 0000926326-18-000030:mdna:59]

[0000926326-19-000013:mdna:44]
| • | Leases; |

[0000926326-19-000013:mdna:45]
[same as prior period, unchanged from 0000926326-18-000030:mdna:60]

[0000926326-19-000013:mdna:46]
[same as prior period, unchanged from 0000926326-18-000030:mdna:61]

[0000926326-19-000013:mdna:47]
[same as prior period, unchanged from 0000926326-18-000030:mdna:63]

[0000926326-19-000013:mdna:48]
[same as prior period, unchanged from 0000926326-18-000030:mdna:64]

[0000926326-19-000013:mdna:49]
[same as prior period, unchanged from 0000926326-18-000030:mdna:65]

[0000926326-19-000013:mdna:50]
There were no material changes in the matters for which we make critical accounting estimates in the preparation of our Condensed Consolidated Financial Statements during the three months ended March 31, 2019 as compared to those disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our annual report on Form 10-K for the year ended December 31, 2018, except as discussed in “Recently Adopted Authoritative Guidance” in Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report.

[0000926326-19-000013:mdna:51]
[same as prior period, unchanged from 0000926326-18-000030:mdna:68]

[0000926326-19-000013:mdna:52]
Refer to Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to Condensed Consolidated Financial Statements in this quarterly report for a description of recently issued accounting pronouncements, including the expected dates of adoption and estimated effects on our results of operations, financial position, and cash flows.

[0000926326-19-000013:mdna:53]
[same as prior period, unchanged from 0000926326-18-000030:mdna:70]

[0000926326-19-000013:mdna:54]
[same as prior period, unchanged from 0000926326-18-000030:mdna:71]

[0000926326-19-000013:mdna:55]
|  | Three months ended March 31, |
|  |  |  |  |  | Change in |
|  | 2019 |  | 2018 |  | $ |  | % |
|  | (Dollars in thousands) |
| Product revenues | $ | 145,610 |  |  | $ | 130,659 |  |  | $ | 14,951 |  |  | 11% |
| Percentage of total revenues | 72% |  | 72% |  |  |  |  |
| Services and other revenues | 56,907 |  |  | 51,960 |  |  | 4,947 |  |  | 10% |
| Percentage of total revenues | 28% |  | 28% |  |  |  |  |
| Total revenues | $ | 202,517 |  |  | $ | 182,619 |  |  | $ | 19,898 |  |  | 11% |

[0000926326-19-000013:mdna:56]
Product revenues represented 72% of total revenues for both the three months ended March 31, 2019 and 2018. Product revenues increased by $15.0 million primarily due to an increase of $12.8 million in our Automated Dispensing Cabinet business driven primarily by the growth of XT series products, as well as increases in revenues from consumables and other product mixes.

[0000926326-19-000013:mdna:57]
Services and other revenues represented 28% of total revenues for both the three months ended March 31, 2019 and 2018. Services and other revenues include revenues from service and maintenance contracts, and rentals of automation systems. Services and other revenues increased by $4.9 million, primarily due to higher service renewal fees driven mainly by an increase in our installed customer base.

[0000926326-19-000013:mdna:58]
Our international sales represented 11% and 13% of total revenues for the three months ended March 31, 2019 and 2018, respectively, and are expected to be affected by foreign currency exchange rate fluctuations. We are unable to predict the extent to which revenues in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-19-000013:mdna:59]
Our ability to continue to grow revenue is dependent on our ability to continue to obtain orders from customers, our ability to produce quality products and consumables to fulfill customer demand, the volume of installations we are able to complete, our ability to meet customer needs by providing a quality installation experience, and our flexibility in manpower allocations among customers to complete installations on a timely basis. The timing of our product revenues for equipment is primarily dependent on when our customers’ schedules allow for installations.

[0000926326-19-000013:mdna:60]
[same as prior period, unchanged from 0000926326-18-000030:mdna:91]

[0000926326-19-000013:mdna:61]
Cost of revenues is primarily comprised of three general categories: (i) standard product costs which accounts for the majority of the product cost of revenues that are provided to customers, and are inclusive of purchased material, labor to build the product and overhead costs associated with production; (ii) installation costs as we install our equipment at the customer site and include costs of the field installation personnel, including labor, travel expense, and other expenses; and (iii) other costs, including variances in standard costs and overhead, scrap costs, rework, warranty, provisions for excess and obsolete inventory and amortization of software development costs and intangibles.

[0000926326-19-000013:mdna:62]
|  | Three months ended March 31, |
|  |  |  |  |  | Change in |
|  | 2019 |  | 2018 |  | $ |  | % |
|  | (Dollars in thousands) |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | $ | 78,811 |  |  | $ | 75,417 |  |  | $ | 3,394 |  |  | 5% |
| As a percentage of related revenues | 54% |  | 58% |  |  |  |  |
| Cost of services and other revenues | 26,589 |  |  | 24,747 |  |  | 1,842 |  |  | 7% |
| As a percentage of related revenues | 47% |  | 48% |  |  |  |  |
| Total cost of revenues | $ | 105,400 |  |  | $ | 100,164 |  |  | $ | 5,236 |  |  | 5% |
| As a percentage of total revenues | 52% |  | 55% |  |  |  |  |
| Gross profit | $ | 97,117 |  |  | $ | 82,455 |  |  | $ | 14,662 |  |  | 18% |
| Gross margin | 48% |  | 45% |  |  |  |  |

[0000926326-19-000013:mdna:63]
Cost of revenues for the three months ended March 31, 2019 compared to the three months ended March 31, 2018 increased by $5.2 million, of which $3.4 million was attributed to the increase in cost of product revenues and $1.8 million was attributed to the increase in cost of services and other revenues. The increase in cost of product revenues is consistent with the increase in product revenues of $15.0 million for the three months ended March 31, 2019 compared to the three months ended March 31, 2018. The increase in cost of services and other revenues is consistent with the increase in cost of services and other revenues of $4.9 million for the three months ended March 31, 2019 compared to the three months ended March 31, 2018.

[0000926326-19-000013:mdna:64]
The overall increase in gross margin primarily relates to lower costs associated with the XT series manufacturing ramp up, economies of scale, and stabilized service costs. Our gross profit for the three months ended March 31, 2019 was $97.1 million as compared to $82.5 million for the three months ended March 31, 2018.

[0000926326-19-000013:mdna:65]
Operating Expenses, Income from Operations, and Interest and Other Income (Expense), Net

[0000926326-19-000013:mdna:66]
|  | Three months ended March 31, |
|  |  |  |  |  | Change in |
|  | 2019 |  | 2018 |  | $ |  | % |
|  | (Dollars in thousands) |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | $ | 16,078 |  |  | $ | 16,537 |  |  | $ | (459 | ) |  | (3)% |
| As a percentage of total revenues | 8% |  | 9% |  |  |  |  |
| Selling, general, and administrative | 68,278 |  |  | 65,285 |  |  | 2,993 |  |  | 5% |
| As a percentage of total revenues | 34% |  | 36% |  |  |  |  |
| Total operating expenses | $ | 84,356 |  |  | $ | 81,822 |  |  | $ | 2,534 |  |  | 3% |
| As a percentage of total revenues | 42% |  | 45% |  |  |  |  |
| Income from operations | $ | 12,761 |  |  | $ | 633 |  |  | $ | 12,128 |  |  | 1,916% |
| Operating margin | 6% |  | —% |  |  |  |  |
| Interest and other income (expense), net | $ | (1,410 | ) |  | $ | (2,729 | ) |  | $ | 1,319 |  |  | (48)% |

[0000926326-19-000013:mdna:67]
[same as prior period, unchanged from 0000926326-18-000030:mdna:48]

[0000926326-19-000013:mdna:68]
Research and Development. Research and development expenses decreased by $0.5 million for the three months ended March 31, 2019 compared to the three months ended March 31, 2018. The decrease was primarily attributed to several research and development projects reaching capitalization stage during the three months ended March 31, 2019, as we are allocating additional resources to software projects, resulting in lower research and development expenses. The decrease in research and development expenses was partially offset by increased spend on consulting expenses, as well as a higher headcount in the research and development function.

[0000926326-19-000013:mdna:69]
Selling, General, and Administrative. Selling, general, and administrative expenses increased by $3.0 million for the three months ended March 31, 2019 compared to the three months ended March 31, 2018, primarily due to growth of operations and primarily attributed to higher consulting and employee-related expenses.

[0000926326-19-000013:mdna:70]
Interest and Other Income (Expense), Net. Interest and other income (expense), net decreased by $1.3 million for the three months ended March 31, 2019 compared to the three months ended March 31, 2018, primarily driven by lower interest expense due to significant debt repayments during the year ended December 31, 2018 and three months ended March 31, 2019, as well as favorable foreign currency fluctuations during the period.

[0000926326-19-000013:mdna:71]
[same as prior period, unchanged from 0000926326-18-000030:mdna:110]

[0000926326-19-000013:mdna:72]
|  | Three months ended March 31, |
|  |  |  |  |  | Change in |
|  | 2019 |  | 2018 |  | $ |  | % |
|  | (Dollars in thousands) |
| Provision for (benefit from) income taxes | $ | 8,067 |  |  | $ | (4,816 | ) |  | $ | 12,883 |  |  | (268)% |

[0000926326-19-000013:mdna:73]
Effective Tax Rate On Earnings. Our annual effective tax rate before discrete items was 23.3% and 18.3% for the three months ended March 31, 2019 and 2018, respectively. The decrease in the estimated annual effective tax rate for the three months ended March 31, 2019 compared to the same period in 2018 was primarily due to state income taxes and non-deductible equity charges.

[0000926326-19-000013:mdna:74]
[same as prior period, unchanged from 0000926326-18-000030:mdna:114]

[0000926326-19-000013:mdna:75]
We had cash and cash equivalents of $77.2 million at March 31, 2019 compared to $67.2 million at December 31, 2018. All of our cash and cash equivalents are invested in bank accounts with major financial institutions.

[0000926326-19-000013:mdna:76]
Our cash position and working capital at March 31, 2019 and December 31, 2018 were as follows:

[0000926326-19-000013:mdna:77]
|  | March 31, 2019 |  | December 31, 2018 |
|  | (In thousands) |
| Cash | $ | 77,244 |  |  | $ | 67,192 |  |
| Working capital | $ | 203,085 |  |  | $ | 192,554 |  |

[0000926326-19-000013:mdna:78]
Our ratio of current assets to current liabilities was 2.0:1 at March 31, 2019 and 1.9:1 at December 31, 2018.

[0000926326-19-000013:mdna:79]
[same as prior period, unchanged from 0000926326-18-000030:mdna:119]

[0000926326-19-000013:mdna:80]
[same as prior period, unchanged from 0000926326-18-000030:mdna:120]

[0000926326-19-000013:mdna:81]
On January 5, 2016, we entered into a $400.0 million secured credit facility pursuant to a credit agreement with certain lenders, Wells Fargo Securities, LLC as sole lead arranger, and Wells Fargo Bank, National Association as administrative agent (the “Credit Agreement”). The Credit Agreement provides for a $200.0 million term loan facility (the “Term Loan Facility”), and prior to the amendment discussed below, a $200.0 million revolving credit facility (the “Revolving Credit Facility” and together with the Term Loan Facility, the “Facilities”). In addition, the Credit Agreement includes a letter of credit sub-limit of up to $10.0 million and a swing line loan sub-limit of up to $10.0 million.

[0000926326-19-000013:mdna:82]
On December 26, 2017 and April 11, 2017, we entered into amendments to the Credit Agreement. Under these amendments, the Revolving Credit Facility was increased from $200.0 million to $315.0 million and certain other modifications were made. Refer to Note 8, Debt and Credit Agreements, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report. We expect to use future loans under the Revolving Credit Facility, if any, for general corporate purposes, including acquisitions.

[0000926326-19-000013:mdna:83]
As of March 31, 2019, the outstanding balance from the Facilities was $101.0 million and we were in compliance with all covenants.

[0000926326-19-000013:mdna:84]
[same as prior period, unchanged from 0000926326-18-000030:mdna:124]

[0000926326-19-000013:mdna:85]
On November 3, 2017, we entered into a Distribution Agreement (the “Distribution Agreement”) with J.P. Morgan Securities LLC, Wells Fargo Securities, LLC and HSBC Securities (USA) Inc., as our sales agents, pursuant to which we may offer and sell from time to time through the sales agents up to $125.0 million maximum aggregate offering price of our common stock. Sales of the common stock pursuant to the Distribution Agreement may be made in negotiated transactions or transactions that are deemed to be “at the market” offerings as defined in Rule 415 under the Securities Act of 1933, including sales made directly on the Nasdaq Stock Market, or sales made to or through a market maker other than on an exchange. We intend to use the net proceeds from the sale, if any, of common stock in the offering for general corporate purposes, which may include, without limitation, the acquisition of complementary businesses, the repayment of outstanding indebtedness, capital expenditures and working capital.

[0000926326-19-000013:mdna:86]
For the three months ended March 31, 2019, we received gross proceeds of $20.6 million from sales of our common stock under the Distribution Agreement and incurred issuance costs of $0.4 million on sales of approximately 243,000 shares of our common stock at an average price of approximately $84.98 per share. For the three months ended March 31, 2018, we did not sell any of our common stock under the Distribution Agreement.

[0000926326-19-000013:mdna:87]
As of March 31, 2019, we had an aggregate of $49.4 million available to be offered under the Distribution Agreement.

[0000926326-19-000013:mdna:88]
[same as prior period, unchanged from 0000926326-18-000030:mdna:127]

[0000926326-19-000013:mdna:89]
Our future uses of cash are expected to be primarily for working capital, capital expenditures, loan principal and interest payments, and other contractual obligations. We also expect a continued use of cash for potential acquisitions and acquisition-related activities.

[0000926326-19-000013:mdna:90]
Our stock repurchase programs have a total of $54.9 million remaining for future repurchases as of March 31, 2019, which may result in additional use of cash. See “Stock Repurchase Program” under Note 13, Employee Benefits and Share-Based Compensation, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report. There were no stock repurchases during the three months ended March 31, 2019 and 2018.

[0000926326-19-000013:mdna:91]
[same as prior period, unchanged from 0000926326-18-000030:mdna:130]

[0000926326-19-000013:mdna:92]
[same as prior period, unchanged from 0000926326-18-000030:mdna:131]

[0000926326-19-000013:mdna:93]
[same as prior period, unchanged from 0000926326-18-000030:mdna:132]

[0000926326-19-000013:mdna:94]
|  | Three months ended |
|  | March 31, 2019 |  | March 31, 2018 |
|  | (In thousands) |
| Net cash provided by (used in): |  |  |  |
| Operating activities | $ | 26,497 |  |  | $ | 18,856 |  |
| Investing activities | (16,697 | ) |  | (14,540 | ) |
| Financing activities | (178 | ) |  | 5,741 |  |
| Effect of exchange rate changes on cash and cash equivalents | 430 |  |  | 1,292 |  |
| Net increase in cash and cash equivalents | $ | 10,052 |  |  | $ | 11,349 |  |

[0000926326-19-000013:mdna:95]
[same as prior period, unchanged from 0000926326-18-000030:mdna:134]

[0000926326-19-000013:mdna:96]
[same as prior period, unchanged from 0000926326-18-000030:mdna:135]

[0000926326-19-000013:mdna:97]
Net cash provided by operating activities was $26.5 million for the three months ended March 31, 2019, primarily consisting of net income of $3.3 million adjusted for non-cash items of $27.7 million offset by changes in assets and liabilities of $4.5 million. The non-cash items primarily consisted of depreciation and amortization expense of $12.6 million, share-based compensation expense of $8.4 million, amortization of operating lease right-of-use asset amortization of $2.6 million, debt financing fees of $0.6 million, and a decrease in deferred income taxes of $3.1 million. Changes in assets and liabilities include cash outflows from (i) a decrease in accrued compensation of $12.6 million primarily due to a decrease in accrued commissions, as well as timing of payroll and ESPP purchases, (ii) an increase in accounts receivable and unbilled receivables of $7.3 million due to an increase in billings, (iii) an increase in inventories of $2.9 million for inventory buildup in support of forecasted sales, (iv) a decrease in operating lease liabilities of $2.7 million, and (v) an increase in investments in sales-type leases of $2.6 million. These cash outflows were partially offset by (i) an increase in deferred revenues of $8.0 million due to timing of orders and revenues being recognized for installed product, (ii) a decrease in other long-term assets of $5.2 million, (iii) an increase in other long-term liabilities of $4.1 million, (iv) a decrease in prepaid expenses of $3.7 million, and (v) a decrease in prepaid commissions of $2.5 million.

[0000926326-19-000013:mdna:98]
Net cash provided by operating activities was $18.9 million for the three months ended March 31, 2018, primarily consisting of net income of $2.7 million adjusted for non-cash items of $14.3 million and changes in assets and liabilities of $1.9 million. The non-cash items primarily consisted of depreciation and amortization expense of $12.3 million, share-based compensation expense of $6.5 million, amortization of debt financing fees of $0.6 million, and an increase in deferred income taxes of $5.1 million. Changes in assets and liabilities include cash inflows from (i) an increase in deferred revenues of $15.1 million due to timing of orders and revenues being recognized for installed product, (ii) an increase in accrued liabilities of $4.3 million, (iii) an increase in accrued compensation of $2.4 million, and (iv) a decrease in prepaid commissions of $1.8 million. These cash inflows were partially offset by (i) a decrease in accounts payable of $9.4 million primarily due to the timing of payments, (ii) an increase in inventories of $6.9 million due to inventory buildup in support of forecasted sales, (iii) an increase in other long-term assets of $1.7 million, (iv) an increase in investment in sales-type leases of $1.5 million, and (v) an increase in other current assets of $1.0 million.

[0000926326-19-000013:mdna:99]
[same as prior period, unchanged from 0000926326-18-000030:mdna:140]

[0000926326-19-000013:mdna:100]
Net cash used in investing activities was $16.7 million for the three months ended March 31, 2019, which consisted of capital expenditures of $5.0 million for property and equipment, and $11.7 million for costs of software development for external use.

[0000926326-19-000013:mdna:101]
Net cash used in investing activities was $14.5 million for the three months ended March 31, 2018, which consisted of capital expenditures $9.3 million for property and equipment and $5.3 million for costs of software development for external use.

[0000926326-19-000013:mdna:102]
[same as prior period, unchanged from 0000926326-18-000030:mdna:143]

[0000926326-19-000013:mdna:103]
Net cash used in financing activities was $0.2 million for the three months ended March 31, 2019, primarily due to the repayment of $39.0 million of the Facilities and $1.9 million in employees’ taxes paid related to restricted stock unit vesting, partially offset by $20.5 million in proceeds from employee stock option exercises and employee stock plan purchases, and $20.2 million proceeds from sales of our common stock under the Distribution Agreement.

[0000926326-19-000013:mdna:104]
Net cash provided by financing activities was $5.7 million for the three months ended March 31, 2018, primarily from the $9.5 million in proceeds from employee stock option exercises and employee stock plan purchases, partially offset by the repayment of $2.5 million of the Facilities and $1.3 million in employees’ taxes paid related to restricted stock unit vesting.

[0000926326-19-000013:mdna:105]
[same as prior period, unchanged from 0000926326-18-000030:mdna:146]

[0000926326-19-000013:mdna:106]
There have been no significant changes during the three months ended March 31, 2019 to the contractual obligations disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations, set forth in Part II, Item 7, of our annual report on Form 10-K for the year ended December 31, 2018.

[0000926326-19-000013:mdna:107]
Contractual obligations as of March 31, 2019 were as follows:

[0000926326-19-000013:mdna:108]
|  | Payments due by period |
|  | Total |  | Remainder of 2019 |  | 2020 - 2021 |  | 2022 - 2023 |  | 2024 and thereafter |
|  | (In thousands) |
| Operating leases (1) | $ | 84,942 |  |  | $ | 10,737 |  |  | $ | 26,159 |  |  | $ | 20,214 |  |  | $ | 27,832 |  |
| Purchase obligations (2) | 70,970 |  |  | 65,456 |  |  | 5,021 |  |  | 233 |  |  | 260 |  |
| Term loan facility (3) | 101,000 |  |  | — |  |  | 101,000 |  |  | — |  |  | — |  |
| Total (4) (5) | $ | 256,912 |  |  | $ | 76,193 |  |  | $ | 132,180 |  |  | $ | 20,447 |  |  | $ | 28,092 |  |

[0000926326-19-000013:mdna:109]
[same as prior period, unchanged from 0000926326-18-000030:mdna:150]

[0000926326-19-000013:mdna:110]
| (1) | Commitments under operating leases relate primarily to leased office buildings, data centers, office equipment, and vehicles. |

[0000926326-19-000013:mdna:111]
| (2) | We purchase components from a variety of suppliers and use contract manufacturers to provide manufacturing services for our products. During the normal course of business, we issue purchase orders with estimates of our requirements several months ahead of the delivery dates. These amounts are associated with agreements that are enforceable and legally binding. The amounts under such contracts are included in the table above because we believe that cancellation of these contracts is unlikely and we expect to make future cash payments according to the contract terms or in similar amounts for similar materials. |

[0000926326-19-000013:mdna:112]
| (3) | Amount shown for term loan is principal repayments only. Due to use of interest rate swaps, the cash interest expense is partly variable and partly fixed, and is not reflected in the above table. Refer to Note 8, Debt and Credit Agreements, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report. |

[0000926326-19-000013:mdna:113]
| (4) | We have recorded $10.0 million for uncertain tax positions under long-term liabilities as of March 31, 2019 in accordance with U.S. GAAP. As these liabilities do not reflect actual tax assessments, the timing and amount of payments we might be required to make will depend upon a number of factors. Accordingly, as the timing and amount of payment cannot be estimated, the $10.0 million in uncertain tax position liabilities have not been included in the table above. |

[0000926326-19-000013:mdna:114]
| (5) | Refer to Note 11, Commitments and Contingencies, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report. |

[0000926326-19-000013:mdna:115]
[same as prior period, unchanged from 0000926326-18-000030:mdna:158]

[0000926326-19-000013:mdna:116]
As of March 31, 2019, we had no off-balance sheet arrangements as defined under Regulation S-K 303(a)(4) of the Securities Exchange Act of 1934, as amended, and the instructions thereto.
