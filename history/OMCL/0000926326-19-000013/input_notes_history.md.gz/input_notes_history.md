# OMCL note change history — 0000926326-18-000030 → 0000926326-19-000013


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-05-03):
[0000926326-19-000013:note_history:1]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of March 31, 2019, the Company had non-cancelable purchase commitments of $71.0 million, of which $65.5 million are expected to be paid within the year ended December 31, 2019.
  (was, 2018-11-02, similarity 0.855):
[0000926326-18-000030:note_history:1]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. At September 30, 2018, the Company had non-cancelable purchase commitments of $75.9 million, which are expected to be paid within the next twelve months.

- changed (2019-05-03):
[0000926326-19-000013:note_history:2]
On June 6, 2018, a class-action lawsuit was filed against a customer of the Company, the customer’s parent company and two vendors of medication dispensing systems, one of which is the Company, in the Circuit Court of Cook County, Illinois, Chancery Division, captioned Yana Mazya, individually and on behalf of all others similarly situated v. Northwestern Lake Forest Hospital, Northwestern Memorial Healthcare, Omnicell, Inc. and Becton Dickinson, Case No. 2018-CH-07161. The complaint sought class certification, monetary damages in the form of statutory damages for willful and/or reckless or, in the alternative, negligent violation of the Illinois Biometric Information Privacy Act (“BIPA”), and certain declaratory, injunctive, and other relief based on causes of action directed to allegations of violation of BIPA and of negligence by the defendants. The complaint was served on the Company on June 15, 2018. The Company’s obligation to respond to the complaint was held in abeyance pending a decision of the Illinois Supreme Court in a separate case involving BIPA issues. The Illinois Supreme Court issued its decision in that case on January 25, 2019. On April 10, 2019, subsequent to the court’s issuance of an order granting the plaintiff leave to file an amended complaint, the plaintiff filed an amended complaint adding a second named plaintiff and an affiliate of the Company’s customer as an additional defendant and, in addition to making other modifications to the complaint, removing the separate cause of action directed to negligence. The court established a deadline of May 13, 2019 for the defendants to answer or otherwise respond to the amended complaint. The Company intends to defend the lawsuit vigorously.
  (was, 2018-11-02, similarity 0.6559):
[0000926326-18-000030:note_history:2]
On June 6, 2018, a class-action lawsuit was filed against a customer of the Company, the customer’s parent company and two vendors of medication dispensing systems, one of which is the Company, in the Circuit Court of Cook County, Illinois, Chancery Division, captioned Yana Mazya, individually and on behalf of all others similarly situated v. Northwestern Lake Forest Hospital, Northwestern Memorial Healthcare, Omnicell, Inc. and Becton Dickinson, Case No. 2018-CH-07161. The complaint seeks class certification, monetary damages in the form of statutory damages for willful and/or reckless or, in the alternative, negligent violation of the Illinois Biometric Information Privacy Act (“BIPA”), and certain declaratory, injunctive, and other relief based on causes of action directed to allegations of violation of BIPA and of negligence by the defendants. The complaint was served on the Company on June 15, 2018. The Company’s obligation to respond to the complaint has been held in abeyance pending a decision of the Illinois Supreme Court in a separate case involving BIPA issues. The court has scheduled a status conference in the case for February 20, 2019. The Company intends to defend the lawsuit vigorously.

- changed (2019-05-03):
[0000926326-19-000013:note_history:3]
A declaratory judgment action was filed against the Company, on August 30, 2018, in the United States District Court for the Northern District of California, captioned Zurich American Insurance Company; American Guarantee & Liability Company v. Omnicell, Inc. and Does 1-10, inclusive, Case No. 3:18-CV-05345. The complaint seeks a declaration that the plaintiffs have no duty to defend or indemnify the Company in connection with the underlying litigation, the Yana Mazya, et al. v. Northwestern Lake Forest Hospital, et al., Case No. 2018-CH-07161 pending in the Circuit Court of Cook County, Illinois, Chancery Division (“Underlying Action”), disclosed above, together with claims for reimbursement and unjust enrichment relating to the defense of the Underlying Action in the form of attorneys’ fees and other related costs. The Company has not responded to the complaint. On February 12, 2019, the court stayed the action pending the outcome of the Underlying Action and administratively closed the case. The Company intends to defend the lawsuit vigorously.
  (was, 2018-11-02, similarity 0.774):
[0000926326-18-000030:note_history:3]
A declaratory judgment action was filed against the Company, on August 30, 2018, in the United States District Court for the Northern District of California, captioned Zurich American Insurance Company; American Guarantee & Liability Company v. Omnicell, Inc. and Does 1-10, inclusive, Case No. 3:18-CV-05345. The complaint seeks a declaration that the plaintiffs have no duty to defend or indemnify the Company in connection with the underlying litigation, the Yana Mazya, et al. v. Northwestern Lake Forest Hospital, et al., Case No. 2018-CH-07161 pending in the Circuit Court of Cook County, Illinois, Chancery Division (“Underlying Action”), disclosed above, together with claims for reimbursement and unjust enrichment relating to the defense of the Underlying Action in the form of attorneys’ fees and other related costs. The Company has not yet responded to the complaint. The Company filed a motion to stay proceedings in this litigation pending the outcome of the Underlying Action. The court has granted the Company’s motion to stay the requirement to respond to the complaint pending the resolution of the motion to stay the litigation. The Company intends to defend the lawsuit vigorously.

- removed (2019-05-03):
[0000926326-18-000030:note_history:4]
Lease Commitments

- removed (2019-05-03):
[0000926326-18-000030:note_history:5]
The Company leases office space and office equipment under operating leases. Commitments under operating leases primarily relate to leasehold property and office equipment. At September 30, 2018, the minimum future payments on non-cancelable operating leases were as follows:

- removed (2019-05-03):
[0000926326-18-000030:note_history:6]
|  | (In thousands) |
| Remaining three months of 2018 | $ | 3,392 |  |
| 2019 | 13,329 |  |
| 2020 | 11,416 |  |
| 2021 | 10,458 |  |
| 2022 | 8,655 |  |
| Thereafter | 26,634 |  |
| Total minimum future lease payments | $ | 73,884 |  |


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2019-05-03):
[0000926326-19-000013:note_history:7]
Omnicell, Inc. was incorporated in California in 1992 under the name Omnicell Technologies, Inc. and reincorporated in Delaware in 2001 as Omnicell, Inc. The Company’s major products are medication and supply dispensing automation solutions, central pharmacy automation solutions, analytics software, and medication adherence solutions which are sold in its principal market, which is the healthcare industry. The Company’s market is primarily located in the United States and Europe. “Omnicell” or the “Company” collectively refer to Omnicell, Inc. and its subsidiaries.

- changed (2019-05-03):
[0000926326-19-000013:note_history:8]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of March 31, 2019 and December 31, 2018, and the results of operations, comprehensive income, and cash flows for the three months ended March 31, 2019 and 2018. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s annual report on Form 10-K for the year ended December 31, 2018 filed with the SEC on February 27, 2019, except as discussed in the sections entitled “Lessor Leases”, “Lessee Leases’, and “Recently Adopted Authoritative Guidance” below. The Company’s results of operations, comprehensive income, and cash flows for the three months ended March 31, 2019 are not necessarily indicative of results that may be expected for the year ending December 31, 2019, or for any future period.
  (was, 2018-11-02, similarity 0.8422):
[0000926326-18-000030:note_history:8]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of September 30, 2018 and December 31, 2017, the results of operations and comprehensive income for the three and nine months ended September 30, 2018 and September 30, 2017, and cash flows for the nine months ended September 30, 2018 and September 30, 2017. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s annual report on Form 10-K for the year ended December 31, 2017 filed with the SEC on February 27, 2018, except as discussed in the section entitled “Revenue Recognition” below. The Company’s results of operations and comprehensive income for the three and nine months ended September 30, 2018 and cash flows for the nine months ended September 30, 2018 are not necessarily indicative of results that may be expected for the year ending December 31, 2018, or for any future period.

- added (2019-05-03):
[0000926326-19-000013:note_history:9]
The Company reclassified $0.6 million from services and other revenues to product revenues for the three months ended March 31, 2018 related to software term-license sales to conform with current period presentation. This reclassification did not have a material impact on the condensed consolidated financial statements.

- added (2019-05-03):
[0000926326-19-000013:note_history:10]
The Company's Chief Operating Decision Maker ("CODM") is its Chief Executive Officer. The CODM allocates resources and evaluates the performance of the Company using information about its revenues, gross profit, income from operations, and other key financial data. The Company previously operated and reported its business in two segments: Automation and Analytics, and Medication Adherence. In the fourth quarter of 2018, the Company introduced its vision of the Autonomous Pharmacy, a more fully automated and digitized system of medication management, in order to address changes in the healthcare industry as the Company executes on its plan to deliver end-to-end solutions with greater emphasis on automating manual processes for its customers. These industry changes include the continuing consolidation of healthcare systems, rising pharmaceutical costs, and increased scrutiny on controlled substances. In an effort to deliver on its strategic vision, the Company initiated a company-wide organizational realignment in the fourth quarter of 2018 to centrally manage its business operations, including the development and marketing of all of the Company’s products, sales and distribution, supply chain and inventory management, as well as regulatory and quality functions. As a result of this organizational realignment, all significant operating decisions are based upon an analysis of the Company as one operating segment. Therefore, effective January 1, 2019, the Company started reporting as only one operating segment, which is the same as the reporting segment. Accordingly, prior period information has been revised to conform with current period presentation.

- changed (2019-05-03):
[0000926326-19-000013:note_history:11]
The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s Condensed Consolidated Financial Statements and accompanying Notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. The Company’s critical accounting policies are those that affect its financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition; accounts receivable and notes receivable from investment in sales-type leases; operating lease right-of-use assets and liabilities; inventory valuation; capitalized software development costs; impairment of goodwill; purchased intangibles and long-lived assets; share-based compensation; and accounting for income taxes.
  (was, 2018-11-02, similarity 0.7947):
[0000926326-18-000030:note_history:11]
The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s Condensed Consolidated Financial Statements and accompanying Notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. The Company’s critical accounting policies are those that affect its financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition; accounts receivable and notes receivable from investment in sales-type leases; inventory valuation; capitalized software development costs; valuation and impairment of goodwill; purchased intangibles and long-lived assets; fair value of assets acquired and liabilities assumed in business combination; share-based compensation; and accounting for income taxes.

- added (2019-05-03):
[0000926326-19-000013:note_history:12]
Lessor Leases

- added (2019-05-03):
[0000926326-19-000013:note_history:13]
The Company determines if an arrangement is a lease at inception. The transaction price is allocated to separate performance obligations, generally consisting of hardware and software products, installation, and post-installation technical support, proportionally based on the standalone selling price of each performance obligation. Standalone selling price is best evidenced by the price the Company charges for the good or service when selling it separately in similar circumstances to similar customers. Other than for the renewal of annual support services contracts, the Company’s products and services are not generally sold separately. The Company uses an amount discounted from the list price as a best estimated selling price.

- added (2019-05-03):
[0000926326-19-000013:note_history:14]
Sales-Type Leases

- added (2019-05-03):
[0000926326-19-000013:note_history:15]
The Company enters into non-cancelable sales-type lease arrangements, most of which do not have an option to extend the lease term. At the end of the lease term, the customer must either return the equipment or negotiate a new agreement, resulting in a new purchase or lease transaction. Failure of the customer to either return the equipment or negotiate a new agreement results in the contract becoming a month-to-month rental. Certain sales-type leases automatically renew for successive one year periods at the end of each lease term with written notice from the customer. The Company’s sales-type lease agreements do not contain any material residual value guarantees.

- added (2019-05-03):
[0000926326-19-000013:note_history:16]
For sales-type leases, the Company recognizes revenues for its hardware and software products, net of lease execution costs, post-installation product maintenance, and technical support, at the net present value of the lease payment stream upon customer acceptance. The Company recognizes service revenues associated with the sales-type leases ratably over the term of the agreement in service revenues on the Condensed Consolidated Statements of Operations. The Company recognizes interest income from sales-type leases using the effective interest method. Both hardware and software revenues, and interest income from sales-types leases are recorded in product revenues on the Condensed Consolidated Statements of Operations.

- added (2019-05-03):
[0000926326-19-000013:note_history:17]
The Company optimizes cash flows by selling a majority of its non-U.S. government sales-type leases to third-party leasing finance companies on a non-recourse basis. The Company has no obligation to the leasing company once the lease has been sold. Some of the Company's sales-type leases, mostly those relating to U.S. government hospitals which comprise approximately 44% of the lease receivable balance, are retained in-house.

- added (2019-05-03):
[0000926326-19-000013:note_history:18]
Operating Leases

- added (2019-05-03):
[0000926326-19-000013:note_history:19]
The Company entered into certain leasing agreements that were classified as operating leases prior to the adoption of the new lease accounting standard. Those agreements in place prior to January 1, 2019 will continue to be treated as operating leases, however any new leasing agreements entered into on or after January 1, 2019 under these programs are classified and accounted for as sales-type leases in accordance with the new lease accounting standard. The operating lease arrangements entered into prior to January 1, 2019 are non-cancelable, and most automatically renew for successive one year periods at the end of each lease term absent written notice from the customer. The Company’s operating lease agreements do not contain any material residual value guarantees.

- added (2019-05-03):
[0000926326-19-000013:note_history:20]
For operating leases, rental income is generally recognized on a straight-line basis over the term of the associated lease, and recorded in revenues in the Condensed Consolidated Statements of Operations. Leased assets under operating leases are carried at amortized cost net of accumulated depreciation in property and equipment, net on the Condensed Consolidated Balance Sheets. The depreciation expense of the leased assets is recognized on a straight-line basis over the contractual term of the associated lease, and recorded in cost of revenues in the Condensed Consolidated Statements of Operations.

- added (2019-05-03):
[0000926326-19-000013:note_history:21]
Lessee Leases

- added (2019-05-03):
[0000926326-19-000013:note_history:22]
The Company determines if an arrangement is a lease at inception. Operating lease right-of-use assets and liabilities are recognized at the commencement date based on the present value of lease payments over the lease term. As most of our lease contracts do not provide an implicit rate, the Company uses its incremental borrowing rate based on information available at the commencement date in determining the present value of the lease payments.

- added (2019-05-03):
[0000926326-19-000013:note_history:23]
Many of the Company’s operating leases include an option to extend the lease. The specific terms and conditions of the extension options vary from lease to lease, but are consistent with standard industry practices in each area that the Company operates. The Company reviews each of its lease options at a time required by the terms of the lease contract, and notifies the lessor if it chooses to exercise the lease renewal option. Until the Company is reasonably certain that it will extend the lease contract, the renewal option periods will not be recognized as right-of-use assets or lease liabilities.

- added (2019-05-03):
[0000926326-19-000013:note_history:24]
Certain leases include provisions for early termination, which allows the contract parties to terminate their obligations under the lease contract. The terms and conditions of the termination options vary by contract. When the Company has made a decision to exercise an early termination option, the right-of-use assets and associated lease liabilities are remeasured in accordance with the present value of the remaining cash flows under the lease contract.

- added (2019-05-03):
[0000926326-19-000013:note_history:25]
Certain building lease agreements include rental payments subject to change annually based on fluctuations in various indexes (i.e. Consumer Price Index (“CPI”), Retail Price Index, and other international indexes). Certain data center lease agreements include rental payments subject to change based on usage and CPI fluctuations. The changes based on usage and indexes are treated as variable lease costs and recognized in the period in which the obligation for those payments was incurred.

- added (2019-05-03):
[0000926326-19-000013:note_history:26]
The Company’s operating lease agreements do not contain any material residual value guarantees, restrictions, or restriction covenants.

- added (2019-05-03):
[0000926326-19-000013:note_history:27]
In February 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2016-02, Leases (Topic 842). The FASB amended lease accounting requirements to begin recording assets and liabilities arising from most leases on the balance sheet. The new guidance also requires significant additional disclosures about the amount and timing of cash flows from leases. The Company adopted this new guidance on January 1, 2019. In July 2018, the FASB issued amendments in ASU 2018-11, which provide a transition election to not restate comparative periods for the effects of applying the new standard. This transition election permits entities to change the date of initial application to the beginning of the year of adoption and to recognize the effects of applying the new standard as a cumulative-effect adjustment to the opening balance of retained earnings. The Company has elected this transition approach as well as elected the package of practical expedients permitted under the transition guidance within the new standard, which will allow the Company to carry forward the historical lease classification of contracts entered into prior to January 1, 2019. As a result of electing the package of practical expedients described above, existing leases and related initial direct costs have not been reassessed prior to the effective date, and therefore, adoption of the lease standard did not have an impact on the Company’s previously reported consolidated statements.

- added (2019-05-03):
[0000926326-19-000013:note_history:28]
The Company also elected the following practical expedients: (i) combining lease and non-lease components, (ii) leases with an initial term of 12 months or less are not recorded in the Condensed Consolidated Balance Sheets, and the associated lease payments are recognized in the Condensed Consolidated Statements of Operations on a straight-line basis over the lease term, and (iii) applying discount rates to operating leases using a portfolio approach.

- added (2019-05-03):
[0000926326-19-000013:note_history:29]
From a lessor perspective, certain agreements that were previously classified as operating leases are classified as sales-type leases under the new lease accounting standard. The agreements in place prior to the adoption of the new lease accounting standard on January 1, 2019 will continue to be treated as operating leases.

- added (2019-05-03):
[0000926326-19-000013:note_history:30]
The Company’s adoption of the new standard impacted the Condensed Consolidated Balances Sheets at the beginning of the period of adoption as follows:

- added (2019-05-03):
[0000926326-19-000013:note_history:31]
|  | January 1, 2019 |
|  | Pre-ASC 842 Balances |  | ASC 842 Adoption Impact |  | Post-ASC 842 Balances |
|  | (In thousands) |
| Operating lease right-of-use assets | $ | — |  |  | $ | 66,008 |  |  | $ | 66,008 |  |
| Accrued liabilities (1) | 43,047 |  |  | 10,067 |  |  | 53,114 |  |
| Long-term operating lease liabilities | — |  |  | 59,791 |  |  | 59,791 |  |
| Other long-term liabilities (2) | 9,562 |  |  | (3,850 | ) |  | 5,712 |  |

- added (2019-05-03):
[0000926326-19-000013:note_history:32]
_________________________________________________

- added (2019-05-03):
[0000926326-19-000013:note_history:33]
| (1) | Adjustment represents the current portion of the operating lease liabilities of $10.3 million, and reclassification of exit cost obligations and deferred rent of $0.1 million and $0.1 million, respectively, to reduce the operating lease right-of-use assets. |

- added (2019-05-03):
[0000926326-19-000013:note_history:34]
| (2) | Adjustment represents the reclassification of deferred rent to reduce the operating lease right-of-use assets. |

- added (2019-05-03):
[0000926326-19-000013:note_history:35]
Adoption of the standard did not have an impact on the Company’s stockholders’ equity, Condensed Consolidated Statements of Operations, and Condensed Consolidated Statements of Cash Flows as of January 1, 2019.

- changed (2019-05-03):
[0000926326-19-000013:note_history:36]
In February 2018, the FASB issued ASU 2018-02, Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income, which permits the reclassification of the income tax effects of the Tax Cuts and Jobs Act of 2017 (the “Tax Act”) on items within accumulated other comprehensive income to retained earnings. These amounts are commonly referred to as “stranded tax effects.” ASU 2018-02 is effective for the Company beginning January 1, 2019. The adoption of this guidance did not have a material effect on the Company’s consolidated financial statements and therefore no adjustment to retained earnings was made.
  (was, 2018-11-02, similarity 0.8335):
[0000926326-18-000030:note_history:36]
In February 2018, the FASB issued ASU 2018-02, Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income, which permits the reclassification of the income tax effects of the Tax Cuts and Jobs Act of 2017 (the “Tax Act”) on items within accumulated other comprehensive income to retained earnings. These amounts are commonly referred to as “stranded tax effects.” ASU 2018-02 will be effective for the Company beginning January 1, 2019. The Company does not expect application of this guidance to have a material effect on its consolidated financial statements.

- changed (2019-05-03):
[0000926326-19-000013:note_history:37]
In August 2018, the FASB issued ASU 2018-15, Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract, to align the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software (and hosting arrangements that include an internal-use software license). ASU 2018-15 will be effective for the Company beginning January 1, 2020. The Company is currently evaluating the impact ASU 2018-15 will have on its consolidated financial statements.
  (was, 2018-11-02, similarity 0.9972):
[0000926326-18-000030:note_history:37]
In August 2018, the FASB issued ASU 2018-15, Intangibles—Goodwill and Other—Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract, to align the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software (and hosting arrangements that include an internal-use software license). ASU 2018-15 will be effective for the Company beginning January 1, 2020. The Company is currently evaluating the impact ASU 2018-15 will have on its consolidated financial statements.

- removed (2019-05-03):
[0000926326-18-000030:note_history:38]
Omnicell, Inc. was incorporated in California in 1992 under the name Omnicell Technologies, Inc. and reincorporated in Delaware in 2001 as Omnicell, Inc. The Company’s major products are automated medication, supply control systems and medication adherence solutions which are sold in its principal market, which is the healthcare industry. The Company’s market is primarily located in the United States and Europe. “Omnicell” or the “Company” collectively refer to Omnicell, Inc. and its subsidiaries.

- removed (2019-05-03):
[0000926326-18-000030:note_history:39]
Certain prior-year amounts have been adjusted to conform with the adoption of ASC 606, Revenue from Contracts with Customers (“ASC 606”), which became effective for the Company beginning on January 1, 2018. Refer to “Recently Adopted Authoritative Guidance” for the effects of adoption of ASC 606 and the section below for the updated revenue recognition policy.

- removed (2019-05-03):
[0000926326-18-000030:note_history:40]
Certain prior-year amounts have been reclassified to conform with current-period presentation. These reclassifications include (i) reclassification of revenues from services and other revenues to product revenues of $0.2 million and $0.5 million for the three and nine months ended September 30, 2017, respectively, related to software term-license sales, (ii) a change in inventories presentation related to allocation of inventories obsolete reserve between finished goods, raw materials, and work in progress in the Notes to the Condensed Consolidated Financial Statements, and (iii) a change in intangible assets presentation related to presenting foreign currency impact separately in the Notes to the Condensed Consolidated Financial Statements. In addition, $0.6 million was reclassified from services and other revenues to product revenues for the nine months ended September 30, 2018 in order to conform with the presentation for the three months ended September 30, 2018. These changes were not deemed material and were included to conform with current-period classification and presentation.

- removed (2019-05-03):
[0000926326-18-000030:note_history:41]
Revenue Recognition

- removed (2019-05-03):
[0000926326-18-000030:note_history:42]
The Company earns revenues from sales of its medication and medical and surgical supply automation systems, along with consumables and related services, which are sold in the healthcare industry, its principal market. The transaction price of each contract with a customer is allocated to the identified performance obligations based on the relative fair value of each obligation. The Company’s customer arrangements typically include one or more of the following performance obligations:

- removed (2019-05-03):
[0000926326-18-000030:note_history:43]
Products. Software-enabled equipment that manages and regulates the storage and dispensing of pharmaceuticals, consumable blister cards and packaging equipment and other medical supplies.

- removed (2019-05-03):
[0000926326-18-000030:note_history:44]
Software. Additional software applications that enable incremental functionality of the Company’s equipment.

- removed (2019-05-03):
[0000926326-18-000030:note_history:45]
Installation. Installation of equipment as integrated systems at customer sites.

- removed (2019-05-03):
[0000926326-18-000030:note_history:46]
Post-installation technical support. Phone support, on-site service, parts, and access to unspecified software updates and enhancements, if and when available.

- removed (2019-05-03):
[0000926326-18-000030:note_history:47]
Professional services. Other customer services, such as training and consulting.

- removed (2019-05-03):
[0000926326-18-000030:note_history:48]
Prior to recognizing revenue, the Company identifies the contract, performance obligations, and transaction price, and allocates the transaction price to the performance obligations. All identified contracts meet the following required criteria:

- removed (2019-05-03):
[0000926326-18-000030:note_history:49]
Parties to the contract have approved the contract (in writing, orally, or in accordance with other customary business practices) and are committed to perform their respective obligations. A majority of the Company’s contracts are evidenced by a non-cancelable written agreement. Contracts for consumable products are generally evidenced by an order placed via phone or a manual purchase order.

- removed (2019-05-03):
[0000926326-18-000030:note_history:50]
Entity can identify each party’s rights regarding the goods or services to be transferred. Contract terms are documented within the written agreements. Where a written contract does not exist, such as for consumable products, the rights of each party are understood as following the Company’s standard business process and terms.

- removed (2019-05-03):
[0000926326-18-000030:note_history:51]
The entity can identify the payment terms for the goods or services to be transferred. Payment terms are documented within the agreement and are generally net 30 days from shipment of tangible product or services performed. Where a written contract does not exist, the Company’s standard payment terms are net 30 day terms.

- removed (2019-05-03):
[0000926326-18-000030:note_history:52]
The contract has commercial substance (that is the risk, timing, or amount of the entity’s future cash flows is expected to change as a result of the contract.) The Company’s agreements are an exchange of cash for a combination of products and services which result in changes in the amount of the Company’s future cash flows.

- removed (2019-05-03):
[0000926326-18-000030:note_history:53]
It is probable the entity will collect the consideration to which it will be entitled in exchange for the goods or services that will be transferred to the customer. The Company performs a credit check for all significant customers or transactions and where collectability is not probable, payment in full or a substantial down payment is typically required to help assure the full agreed upon contract price will be collected.

- removed (2019-05-03):
[0000926326-18-000030:note_history:54]
The Company often enters into change orders which modify the product to be received by the customer pursuant to certain contracts. Changes to any contract are accounted for as a modification of the existing contract to the extent the goods and services to be delivered as part of the contract are generally consistent with the nature and type of those to be provided under the terms of the original contract. Examples of such change orders include the addition or removal of units of equipment or changes to the configuration of the equipment where the overall nature of the contract remains intact. The Company’s change orders generally result in the change being accounted for as modifications of existing contracts given the nature of the impacted orders.

- removed (2019-05-03):
[0000926326-18-000030:note_history:55]
Distinct goods or services are identified as performance obligations. A series of distinct goods or services that are substantially the same and that have the same pattern of transfer to the customer are considered a single performance obligation. Where a good or service is determined not to be distinct, the Company combines the good or service with other promised goods or services until a bundle of goods or services that is distinct is identified. To identify its performance obligations, the Company considers all of the products or services promised in the contract regardless of whether they are explicitly stated or are implied by customary business practices. When performance obligations are included in separate contracts, the Company considers an entire customer arrangement to determine if separate contracts should be considered combined for the purposes of revenue recognition. Most of the Company’s sales, other than renewals of support and maintenance, contain multiple performance obligations, with a combination of hardware systems, consumables and software products, support and maintenance, and professional services.

- removed (2019-05-03):
[0000926326-18-000030:note_history:56]
The transaction price of a contract is determined based on the fixed consideration, net of an estimate for variable consideration such as various discounts or rebates provided to customers. As a result of the Company’s commercial selling practices, contract prices are generally fixed with minimal, if any, variable consideration.

- removed (2019-05-03):
[0000926326-18-000030:note_history:57]
The transaction price is allocated to separate performance obligations proportionally based on the standalone selling price of each performance obligation. Standalone selling price is best evidenced by the price the Company charges for the good or service when selling it separately in similar circumstances to similar customers. Other than for the renewal of annual support services contracts, the Company’s products and services are not generally sold separately. The Company uses an expected cost plus a margin approach to identify the standalone selling price of goods where separate sales transactions do not exist. For software and services which do not have a specific identifiable product cost, the Company uses an amount discounted from the list price as a best estimated selling price.

- removed (2019-05-03):
[0000926326-18-000030:note_history:58]
The Company recognizes revenue when the performance obligation has been satisfied by transferring a promised good or service to a customer. The good or service is transferred when or as the customer obtains control of the good or service. Determining when control transfers requires management to make judgments that affect the timing of revenues recognized. Generally, for products requiring a complex implementation, control passes when the product is installed and ready for use. For all other products, control generally passes when product has been shipped and title has passed. For maintenance contracts and certain other services provided on a subscription basis, control passes to the customer over time, generally ratably over the service term as the Company provides a stand-ready service to service the customer’s equipment. Time and material services transfer control to the customer at the time the services are provided. The portion of the transaction price allocated to the Company’s unsatisfied performance obligations recorded as deferred revenues at September 30, 2018 and December 31, 2017 were $98.4 million and $89.4 million, respectively, of which $87.8 million and $78.8 million, respectively, are expected to be completed within one year. Remaining performance obligations primarily relate to maintenance contracts and are recognized ratably over the remaining term of the contract, generally not more than five years.

- removed (2019-05-03):
[0000926326-18-000030:note_history:59]
Revenues, contract assets, and contract liabilities are recorded net of associated taxes.

- removed (2019-05-03):
[0000926326-18-000030:note_history:60]
The payment terms associated with the Company’s contracts vary, however, payment terms for product revenues are generally based on milestones tied to contract signing, shipment of products, and/or customer acceptance. Payment terms associated with the service portion of agreements are generally periodic and can be billed on a monthly, quarterly, or annual basis. In certain circumstances multiple years are billed at one time. The portion of these contract liabilities not expected to be recognized as revenue within twelve months of the balance sheet date are considered long term.

- removed (2019-05-03):
[0000926326-18-000030:note_history:61]
In the normal course of business, the Company typically does not accept product returns unless the item is defective as manufactured or the configuration of the product is incorrect. The Company establishes provisions for estimated returns based on historical product returns. The allowance for sales returns is not material to the Condensed Consolidated Financial Statements for any periods presented.

- removed (2019-05-03):
[0000926326-18-000030:note_history:62]
A portion of the Company's sales are made through multi-year lease agreements. Under sales-type leases, the Company recognizes revenue for its hardware and software products net of lease execution costs, such as post-installation product maintenance and technical support, at the net present value of the lease payment stream once its installation obligations have been met. The Company optimizes cash flows by selling a majority of its non-U.S. government leases to third-party leasing finance companies on a non-recourse basis. The Company has no obligation to the leasing company once the lease has been sold. Some of the Company's sales-type leases, mostly those relating to U.S. government hospitals which comprise approximately 44% of the lease receivable balance, are retained in-house. Revenues from sales-type leases of $11.4 million and $5.9 million for the three months ended September 30, 2018 and 2017, respectively, and $28.8 million and $19.3 million for the nine months ended September 30, 2018 and 2017, respectively, are included in product revenues in the Condensed Consolidated Statements of Operations. Interest income in these leases is recognized in product revenues using the effective interest method.

- removed (2019-05-03):
[0000926326-18-000030:note_history:63]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”). GPOs are often owned fully or in part by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs were $2.2 million and $2.1 million for the three months ended September 30, 2018 and 2017, respectively, and $6.2 million and $5.4 million for the nine months ended September 30, 2018 and 2017, respectively.

- removed (2019-05-03):
[0000926326-18-000030:note_history:64]
Contract Assets and Contract Liabilities

- removed (2019-05-03):
[0000926326-18-000030:note_history:65]
A contract asset is a right to consideration in exchange for goods or services that the Company has transferred to a customer when that right is conditional and is not just subject to the passage of time. A receivable will be recorded on the balance sheet when the Company has unconditional rights to consideration. A contract liability is an obligation to transfer goods or services for which the Company has received consideration, or for which an amount of consideration is due from the customer. Contract liabilities include customer deposits under non-cancelable contracts, and current and non-current deferred revenue balances. The Company’s contract balances are reported in a net contract asset or liability position on a contract-by-contract basis at the end of each reporting period.

- removed (2019-05-03):
[0000926326-18-000030:note_history:66]
The following table reflects the Company’s contract assets and contract liabilities:

- removed (2019-05-03):
[0000926326-18-000030:note_history:67]
|  | September 30, 2018 |  | December 31, 2017 |
|  | (In thousands) |
| Short-term unbilled receivables - included in accounts receivable and unbilled receivables | $ | 9,475 |  |  | $ | 4,590 |  |
| Long-term unbilled receivables - included in other long-term assets | 15,573 |  |  | 9,475 |  |
| Total contract assets | $ | 25,048 |  |  | $ | 14,065 |  |
| Short-term deferred revenues | $ | 87,777 |  |  | $ | 78,774 |  |
| Long-term deferred revenues | 10,634 |  |  | 10,623 |  |
| Total contract liabilities | $ | 98,411 |  |  | $ | 89,397 |  |

- removed (2019-05-03):
[0000926326-18-000030:note_history:68]
Significant changes in the contract assets and the contract liabilities balances during the period are the result of the issuance of invoices and recognition of deferred revenues in the normal course of business. Unbilled contract assets which were invoiced during the three and nine months ended September 30, 2018 as a result of the right to invoice for the transaction consideration becoming unconditional were not material. The contract modifications entered into during the three and nine months ended September 30, 2018 did not have a significant impact on the Company’s contract assets or deferred revenues. During the three and nine months ended September 30, 2018, the Company recognized revenues of $10.9 million and $78.9 million, respectively, that was included in the corresponding deferred revenue balance as of December 31, 2017.

- removed (2019-05-03):
[0000926326-18-000030:note_history:69]
Contract Costs

- removed (2019-05-03):
[0000926326-18-000030:note_history:70]
The Company has determined that the incentive portions of its sales commission plans require capitalization since these payments are directly related to sales achieved during a time period. These commissions are earned on the basis of the total purchase order value of new product bookings. Since there are not commensurate commissions earned on renewal of the service bookings, the Company concluded that the capitalized asset is related to services provided under both the initial contract and renewal periods. The Company applies a practical expedient to account for the incremental costs of obtaining a contract to a portfolio of contracts with similar characteristics as the Company expects the effect on the financial statements of applying the practical expedient would not differ materially from applying the accounting guidance to the individual contracts within the portfolio. A pool of contracts is defined as all contracts booked in a particular quarter. The amortization for the capitalized asset is an estimate of the pool’s original contract term, generally one to five years, plus an estimate of future customer renewal periods resulting in a total amortization period of ten years. Costs to obtain a contract are allocated amongst performance obligations and recognized as sales and marketing expense consistent with the pattern of revenue recognition. Capitalized costs are periodically reviewed for impairment. A portion of the pool’s capitalized asset is recorded as an expense after two quarters, which represents the estimated period during which the product revenue associated with the contract is recorded. The remaining contract cost is recorded as expense ratably over the ten year estimated initial and renewal service periods. The Company recognized contract cost expense of $5.3 million and $4.6 million during the three months ended September 30, 2018 and 2017, respectively, and $16.2 million and $13.3 million during the nine months ended September 30, 2018 and 2017, respectively. The portion of commission expenses paid as of the balance sheet date to be recognized in future periods is recorded in long term prepaid commissions on the Condensed Consolidated Balance Sheets. There was no impairment loss recorded related to capitalized prepaid commissions as of and for the three and nine months ended September 30, 2018.

- removed (2019-05-03):
[0000926326-18-000030:note_history:71]
The Company’s Chief Operating Decision Maker (“CODM”) is its Chief Executive Officer. The CODM allocates resources and evaluates the performance of the Company’s segments using information about its revenues, gross profit, and income from operations. Such evaluation excludes general corporate-level costs that are not specific to either of the reportable segments and are managed separately at the corporate level. Corporate-level costs include expenses related to executive management, finance and accounting, human resources, legal, training and development, and certain other administrative expenses. See Note 14, Segment and Geographical Information, for additional information on segment reporting.

- removed (2019-05-03):
[0000926326-18-000030:note_history:72]
In May 2014, the Financial Accounting Standards Board (“FASB”) issued ASC 606, Revenue from Contracts with Customers, a new standard related to revenue recognition. Under the new standard, revenue is recognized when a customer obtains control of promised goods or services in an amount that reflects the consideration the entity expects to receive in exchange for those goods or services. In addition, the standard requires disclosure of the nature, amount, timing, and uncertainty of revenues and cash flows arising from contracts with customers. The guidance permits two methods of adoption: retrospectively to each prior reporting period presented (full retrospective method), or retrospectively with the cumulative effect of initially applying the guidance recognized at the date of initial application (modified retrospective method). The Company adopted the standard using the full retrospective method effective beginning January 1, 2018.

- removed (2019-05-03):
[0000926326-18-000030:note_history:73]
Under the ASC 606 guidance, fees paid to GPOs are now presented as a reduction of product revenues, whereas these fees were considered a part of selling, general, and administrative costs under the previous guidance. The majority of the incremental costs incurred to obtain a contract, primarily commission expense, are recognized during the first year with the balance recognized ratably over a period of ten years. Additionally, revenue on term software licenses is recognized upon installation of the license rather than ratably over the life of the term license. Finally, the Company no longer defers the contingent revenue in transactions where the amount charged to the customer for a particular performance obligation is less than the allocation of standalone selling price.

- removed (2019-05-03):
[0000926326-18-000030:note_history:74]
Adoption of the standard related to revenue recognition impacted the Company’s reported results as follows:

- removed (2019-05-03):
[0000926326-18-000030:note_history:75]
|  | Three months ended September 30, 2017 |
|  | As reported |  | Adjustment |  | As adjusted |
|  | (In thousands) |
| Revenues |  |  |  |  |  |
| Automation and Analytics | $ | 154,651 |  |  | $ | (34 | ) |  | $ | 154,617 |  |
| Medication Adherence | 32,131 |  |  | — |  |  | 32,131 |  |
| Gross profit |  |  |  |  |  |
| Automation and Analytics | 74,911 |  |  | (34 | ) |  | 74,877 |  |
| Medication Adherence | 9,942 |  |  | — |  |  | 9,942 |  |
| Selling, general, and administrative expenses | 58,725 |  |  | (2,517 | ) |  | 56,208 |  |
| Provision for income taxes | 751 |  |  | 966 |  |  | 1,717 |  |
| Net income | $ | 6,231 |  |  | $ | 1,517 |  |  | $ | 7,748 |  |
| Net income per share - basic | $ | 0.17 |  |  | $ | 0.04 |  |  | $ | 0.21 |  |
| Net income per share - diluted | $ | 0.16 |  |  | $ | 0.04 |  |  | $ | 0.20 |  |

- removed (2019-05-03):
[0000926326-18-000030:note_history:76]
|  | Nine months ended September 30, 2017 |
|  | As reported |  | Adjustment |  | As adjusted |
|  | (In thousands) |
| Revenues |  |  |  |  |  |
| Automation and Analytics | $ | 427,249 |  |  | $ | (1,878 | ) |  | $ | 425,371 |  |
| Medication Adherence | 90,972 |  |  | — |  |  | 90,972 |  |
| Gross profit |  |  |  |  |  |
| Automation and Analytics | 198,032 |  |  | (1,878 | ) |  | 196,154 |  |
| Medication Adherence | 28,988 |  |  | — |  |  | 28,988 |  |
| Selling, general, and administrative expenses | 186,818 |  |  | (6,748 | ) |  | 180,070 |  |
| Provision for (benefit from) income taxes | (11,232 | ) |  | 1,891 |  |  | (9,341 | ) |
| Net income (loss) | $ | (3,686 | ) |  | $ | 2,979 |  |  | $ | (707 | ) |
| Net income (loss) per share - basic | $ | (0.10 | ) |  | $ | 0.08 |  |  | $ | (0.02 | ) |
| Net income (loss) per share - diluted | $ | (0.10 | ) |  | $ | 0.08 |  |  | $ | (0.02 | ) |

- removed (2019-05-03):
[0000926326-18-000030:note_history:77]
|  | December 31, 2017 |
|  | As reported |  | Adjustment |  | As adjusted |
|  | (In thousands) |
| Accounts receivable and unbilled receivables, net | $ | 189,227 |  |  | $ | 819 |  |  | $ | 190,046 |  |
| Prepaid expenses | 36,060 |  |  | (15,668 | ) |  | 20,392 |  |
| Prepaid commissions | — |  |  | 41,432 |  |  | 41,432 |  |
| Other long-term assets | 39,841 |  |  | 9,475 |  |  | 49,316 |  |
| Deferred revenues, net | 86,104 |  |  | (7,330 | ) |  | 78,774 |  |
| Long-term, deferred revenues | 17,244 |  |  | (6,621 | ) |  | 10,623 |  |
| Long-term, deferred tax liabilities | 28,579 |  |  | 12,867 |  |  | 41,446 |  |
| Stockholders’ equity | 517,199 |  |  | 37,142 |  |  | 554,341 |  |

- removed (2019-05-03):
[0000926326-18-000030:note_history:78]
In August 2018, the FASB issued ASU 2018-13, Fair Value Measurement (Topic 820): Disclosure Framework—Changes to the Disclosure Requirements for Fair Value Measurement, which modifies the disclosure requirements on fair value measurements. ASU 2018-13 is effective for the Company beginning January 1, 2020, with early adoption permitted. The Company early adopted this guidance effective beginning July 1, 2018. The application of this guidance did not have a material effect on the Company’s consolidated financial statements.

- removed (2019-05-03):
[0000926326-18-000030:note_history:79]
In February 2016, the FASB issued ASU No. 2016-02, Leases (Topic 842). The FASB amended lease accounting requirements to begin recording assets and liabilities arising from most leases on the balance sheet. The new guidance will also require significant additional disclosures about the amount and timing of cash flows from leases. This new guidance will be effective for the Company beginning January 1, 2019. In July 2018, the FASB issued amendments in ASU No. 2018-11, which provide a transition election to not restate comparative periods for the effects of applying the new standard. This transition election permits entities to change the date of initial application to the beginning of the year of adoption and to recognize the effects of applying the new standard as a cumulative-effect adjustment to the opening balance of retained earnings. The Company expects to elect this transition approach and recognize the cumulative impact of adoption in the opening balance of retained earnings as of January 1, 2019. The Company is in the process of completing a qualitative and quantitative assessment of the lease portfolio, implementing a new lease accounting system and implementing new processes and controls to account for leases in accordance with the new standard. The Company believes the most significant changes to the financial statements will relate to the recognition of right-of-use assets and offsetting lease liabilities in the consolidated balance sheet for operating leases. The actual impact on the consolidated balance sheet will be contingent upon the Company's population of operating leases at adoption, however the Company does not expect the standard to have a material impact on cash flows or results of operations.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2019-05-03):
[0000926326-19-000013:note_history:80]
Debt and Credit Agreements

- changed (2019-05-03):
[0000926326-19-000013:note_history:81]
On December 26, 2017, the parties entered into an amendment (the “Amendment”) to the Amended Credit Agreement. Pursuant to the Amendment, the Revolving Credit Facility provided for under the Amended Credit Agreement, was increased from $200.0 million to $315.0 million, and certain other modifications to the Amended Credit Agreement were made, including amendments to certain negative covenants.
  (was, 2018-11-02, similarity 0.9935):
[0000926326-18-000030:note_history:81]
On December 26, 2017, the parties entered into another amendment (the “Amendment”) to the Amended Credit Agreement. Pursuant to the Amendment, the Revolving Credit Facility provided for under the Amended Credit Agreement, was increased from $200.0 million to $315.0 million, and certain other modifications to the Amended Credit Agreement were made, including amendments to certain negative covenants.

- changed (2019-05-03):
[0000926326-19-000013:note_history:82]
In connection with these Facilities, the Company incurred $10.1 million of debt issuance costs. The debt issuance costs were capitalized and presented as a direct deduction from the carrying amount of that debt liability. The debt issuance costs are being amortized to interest expense using the straight line method from issuance date through 2021. Interest expense (exclusive of fees and issuance cost amortization) was approximately $1.3 million and $1.9 million for the three months ended March 31, 2019 and 2018, respectively. Amortization expense related to fees and issuance cost was approximately $0.6 million for both the three months ended March 31, 2019 and 2018. The Company was in compliance with all covenants as of March 31, 2019 and December 31, 2018.
  (was, 2018-11-02, similarity 0.745):
[0000926326-18-000030:note_history:82]
In connection with these Facilities, the Company incurred $10.1 million of debt issuance costs. The debt issuance costs were capitalized and presented as a direct deduction from the carrying amount of that debt liability in accordance with the accounting guidance. The debt issuance costs are being amortized to interest expense using the straight line method from issuance date through 2021. Interest expense (exclusive of fees and issuance cost amortization) was approximately $1.9 million and $1.6 million for the three months ended September 30, 2018 and 2017, respectively, and approximately $5.7 million and $4.6 million for the nine months ended September 30, 2018 and 2017, respectively. Amortization expense related to fees and issuance cost was approximately $0.6 million and $0.4 million for the three months ended September 30, 2018 and 2017, respectively, and approximately $1.7 million and $1.2 million for the nine months ended September 30, 2018 and 2017, respectively. The Company was in compliance with all covenants as of September 30, 2018 and December 31, 2017.

- changed (2019-05-03):
[0000926326-19-000013:note_history:83]
During the three months ended March 31, 2019, the Company repaid $39.0 million under these Facilities.
  (was, 2018-11-02, similarity 0.9101):
[0000926326-18-000030:note_history:83]
During the nine months ended September 30, 2018, the Company repaid $27.0 million under these Facilities.

- changed (2019-05-03):
[0000926326-19-000013:note_history:84]
The components of the Company’s debt obligations as of March 31, 2019 and December 31, 2018 were as follows:
  (was, 2018-11-02, similarity 0.95):
[0000926326-18-000030:note_history:84]
The components of the Company’s debt obligations as of September 30, 2018 and December 31, 2017 were as follows:

- added (2019-05-03):
[0000926326-19-000013:note_history:85]
|  | December 31, 2018 |  | Borrowings |  | Repayment / Amortization |  | March 31, 2019 |
|  | (In thousands) |
| Term loan facility | $ | 140,000 |  |  | $ | — |  |  | $ | (39,000 | ) |  | $ | 101,000 |  |
| Revolving credit facility | — |  |  | — |  |  | — |  |  | — |  |
| Total debt under the facilities | 140,000 |  |  | — |  |  | (39,000 | ) |  | 101,000 |  |
| Less: Deferred issuance cost | (4,583 | ) |  | — |  |  | 573 |  |  | (4,010 | ) |
| Total long-term debt, net of deferred issuance cost | $ | 135,417 |  |  | $ | — |  |  | $ | (38,427 | ) |  | $ | 96,990 |  |

- changed (2019-05-03):
[0000926326-19-000013:note_history:86]
As of March 31, 2019, the carrying amount of debt of $101.0 million approximates the comparable fair value of $103.5 million. The Company’s debt facilities are classified as a Level 3 in the fair value hierarchy. The calculation of the fair value is based on a discounted cash flow model using observable market inputs and taking into consideration variables such as interest rate changes, comparable instruments and long-term credit ratings. There have been no significant changes in the assumptions used as of March 31, 2019 as compared to December 31, 2018.
  (was, 2018-11-02, similarity 0.9005):
[0000926326-18-000030:note_history:86]
As of September 30, 2018, the carrying amount of debt of $190.0 million approximates the comparable fair value of $192.6 million. The Company’s debt facilities are classified as a Level 3 in the fair value hierarchy. The calculation of the fair value is based on a discounted cash flow model using observable market inputs and taking into consideration variables such as interest rate changes, comparable instruments and long-term credit ratings. There have been no significant changes in the assumptions used as of September 30, 2018 as compared to the period as of December 31, 2017.

- removed (2019-05-03):
[0000926326-18-000030:note_history:87]
Debt

- removed (2019-05-03):
[0000926326-18-000030:note_history:88]
|  | December 31, 2017 |  | Borrowings |  | Repayment / Amortization |  | September 30, 2018 |
|  | (In thousands) |
| Term loan facility | $ | 182,500 |  |  | $ | — |  |  | $ | (12,500 | ) |  | $ | 170,000 |  |
| Revolving credit facility | 34,500 |  |  | — |  |  | (14,500 | ) |  | 20,000 |  |
| Total debt under the facilities | 217,000 |  |  | — |  |  | (27,000 | ) |  | 190,000 |  |
| Less: Deferred issuance cost | (6,875 | ) |  | — |  |  | 1,718 |  |  | (5,157 | ) |
| Total debt, net of deferred issuance cost | $ | 210,125 |  |  | $ | — |  |  | $ | (25,282 | ) |  | $ | 184,843 |  |
| Long term debt, current portion, net of deferred issuance cost | 15,208 |  |  |  |  |  |  | 17,708 |  |
| Long term debt, net of deferred issuance cost | $ | 194,917 |  |  |  |  |  |  | $ | 167,135 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-05-03):
[0000926326-19-000013:note_history:89]
The components of the Company’s debt obligations as of March 31, 2019 and December 31, 2018 were as follows:
  (was, 2018-11-02, similarity 0.95):
[0000926326-18-000030:note_history:89]
The components of the Company’s debt obligations as of September 30, 2018 and December 31, 2017 were as follows:

- added (2019-05-03):
[0000926326-19-000013:note_history:90]
|  | December 31, 2018 |  | Borrowings |  | Repayment / Amortization |  | March 31, 2019 |
|  | (In thousands) |
| Term loan facility | $ | 140,000 |  |  | $ | — |  |  | $ | (39,000 | ) |  | $ | 101,000 |  |
| Revolving credit facility | — |  |  | — |  |  | — |  |  | — |  |
| Total debt under the facilities | 140,000 |  |  | — |  |  | (39,000 | ) |  | 101,000 |  |
| Less: Deferred issuance cost | (4,583 | ) |  | — |  |  | 573 |  |  | (4,010 | ) |
| Total long-term debt, net of deferred issuance cost | $ | 135,417 |  |  | $ | — |  |  | $ | (38,427 | ) |  | $ | 96,990 |  |

- removed (2019-05-03):
[0000926326-18-000030:note_history:91]
|  | December 31, 2017 |  | Borrowings |  | Repayment / Amortization |  | September 30, 2018 |
|  | (In thousands) |
| Term loan facility | $ | 182,500 |  |  | $ | — |  |  | $ | (12,500 | ) |  | $ | 170,000 |  |
| Revolving credit facility | 34,500 |  |  | — |  |  | (14,500 | ) |  | 20,000 |  |
| Total debt under the facilities | 217,000 |  |  | — |  |  | (27,000 | ) |  | 190,000 |  |
| Less: Deferred issuance cost | (6,875 | ) |  | — |  |  | 1,718 |  |  | (5,157 | ) |
| Total debt, net of deferred issuance cost | $ | 210,125 |  |  | $ | — |  |  | $ | (25,282 | ) |  | $ | 184,843 |  |
| Long term debt, current portion, net of deferred issuance cost | 15,208 |  |  |  |  |  |  | 17,708 |  |
| Long term debt, net of deferred issuance cost | $ | 194,917 |  |  |  |  |  |  | $ | 167,135 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: no_current_note, score: 0.0

- removed (2019-05-03):
[0000926326-18-000030:note_history:92]
Revenue Recognition

- removed (2019-05-03):
[0000926326-18-000030:note_history:93]
The Company earns revenues from sales of its medication and medical and surgical supply automation systems, along with consumables and related services, which are sold in the healthcare industry, its principal market. The transaction price of each contract with a customer is allocated to the identified performance obligations based on the relative fair value of each obligation. The Company’s customer arrangements typically include one or more of the following performance obligations:

- removed (2019-05-03):
[0000926326-18-000030:note_history:94]
Products. Software-enabled equipment that manages and regulates the storage and dispensing of pharmaceuticals, consumable blister cards and packaging equipment and other medical supplies.

- removed (2019-05-03):
[0000926326-18-000030:note_history:95]
Software. Additional software applications that enable incremental functionality of the Company’s equipment.

- removed (2019-05-03):
[0000926326-18-000030:note_history:96]
Installation. Installation of equipment as integrated systems at customer sites.

- removed (2019-05-03):
[0000926326-18-000030:note_history:97]
Post-installation technical support. Phone support, on-site service, parts, and access to unspecified software updates and enhancements, if and when available.

- removed (2019-05-03):
[0000926326-18-000030:note_history:98]
Professional services. Other customer services, such as training and consulting.

- removed (2019-05-03):
[0000926326-18-000030:note_history:99]
Prior to recognizing revenue, the Company identifies the contract, performance obligations, and transaction price, and allocates the transaction price to the performance obligations. All identified contracts meet the following required criteria:

- removed (2019-05-03):
[0000926326-18-000030:note_history:100]
Parties to the contract have approved the contract (in writing, orally, or in accordance with other customary business practices) and are committed to perform their respective obligations. A majority of the Company’s contracts are evidenced by a non-cancelable written agreement. Contracts for consumable products are generally evidenced by an order placed via phone or a manual purchase order.

- removed (2019-05-03):
[0000926326-18-000030:note_history:101]
Entity can identify each party’s rights regarding the goods or services to be transferred. Contract terms are documented within the written agreements. Where a written contract does not exist, such as for consumable products, the rights of each party are understood as following the Company’s standard business process and terms.

- removed (2019-05-03):
[0000926326-18-000030:note_history:102]
The entity can identify the payment terms for the goods or services to be transferred. Payment terms are documented within the agreement and are generally net 30 days from shipment of tangible product or services performed. Where a written contract does not exist, the Company’s standard payment terms are net 30 day terms.

- removed (2019-05-03):
[0000926326-18-000030:note_history:103]
The contract has commercial substance (that is the risk, timing, or amount of the entity’s future cash flows is expected to change as a result of the contract.) The Company’s agreements are an exchange of cash for a combination of products and services which result in changes in the amount of the Company’s future cash flows.

- removed (2019-05-03):
[0000926326-18-000030:note_history:104]
It is probable the entity will collect the consideration to which it will be entitled in exchange for the goods or services that will be transferred to the customer. The Company performs a credit check for all significant customers or transactions and where collectability is not probable, payment in full or a substantial down payment is typically required to help assure the full agreed upon contract price will be collected.

- removed (2019-05-03):
[0000926326-18-000030:note_history:105]
The Company often enters into change orders which modify the product to be received by the customer pursuant to certain contracts. Changes to any contract are accounted for as a modification of the existing contract to the extent the goods and services to be delivered as part of the contract are generally consistent with the nature and type of those to be provided under the terms of the original contract. Examples of such change orders include the addition or removal of units of equipment or changes to the configuration of the equipment where the overall nature of the contract remains intact. The Company’s change orders generally result in the change being accounted for as modifications of existing contracts given the nature of the impacted orders.

- removed (2019-05-03):
[0000926326-18-000030:note_history:106]
Distinct goods or services are identified as performance obligations. A series of distinct goods or services that are substantially the same and that have the same pattern of transfer to the customer are considered a single performance obligation. Where a good or service is determined not to be distinct, the Company combines the good or service with other promised goods or services until a bundle of goods or services that is distinct is identified. To identify its performance obligations, the Company considers all of the products or services promised in the contract regardless of whether they are explicitly stated or are implied by customary business practices. When performance obligations are included in separate contracts, the Company considers an entire customer arrangement to determine if separate contracts should be considered combined for the purposes of revenue recognition. Most of the Company’s sales, other than renewals of support and maintenance, contain multiple performance obligations, with a combination of hardware systems, consumables and software products, support and maintenance, and professional services.

- removed (2019-05-03):
[0000926326-18-000030:note_history:107]
The transaction price of a contract is determined based on the fixed consideration, net of an estimate for variable consideration such as various discounts or rebates provided to customers. As a result of the Company’s commercial selling practices, contract prices are generally fixed with minimal, if any, variable consideration.

- removed (2019-05-03):
[0000926326-18-000030:note_history:108]
The transaction price is allocated to separate performance obligations proportionally based on the standalone selling price of each performance obligation. Standalone selling price is best evidenced by the price the Company charges for the good or service when selling it separately in similar circumstances to similar customers. Other than for the renewal of annual support services contracts, the Company’s products and services are not generally sold separately. The Company uses an expected cost plus a margin approach to identify the standalone selling price of goods where separate sales transactions do not exist. For software and services which do not have a specific identifiable product cost, the Company uses an amount discounted from the list price as a best estimated selling price.

- removed (2019-05-03):
[0000926326-18-000030:note_history:109]
The Company recognizes revenue when the performance obligation has been satisfied by transferring a promised good or service to a customer. The good or service is transferred when or as the customer obtains control of the good or service. Determining when control transfers requires management to make judgments that affect the timing of revenues recognized. Generally, for products requiring a complex implementation, control passes when the product is installed and ready for use. For all other products, control generally passes when product has been shipped and title has passed. For maintenance contracts and certain other services provided on a subscription basis, control passes to the customer over time, generally ratably over the service term as the Company provides a stand-ready service to service the customer’s equipment. Time and material services transfer control to the customer at the time the services are provided. The portion of the transaction price allocated to the Company’s unsatisfied performance obligations recorded as deferred revenues at September 30, 2018 and December 31, 2017 were $98.4 million and $89.4 million, respectively, of which $87.8 million and $78.8 million, respectively, are expected to be completed within one year. Remaining performance obligations primarily relate to maintenance contracts and are recognized ratably over the remaining term of the contract, generally not more than five years.

- removed (2019-05-03):
[0000926326-18-000030:note_history:110]
Revenues, contract assets, and contract liabilities are recorded net of associated taxes.

- removed (2019-05-03):
[0000926326-18-000030:note_history:111]
The payment terms associated with the Company’s contracts vary, however, payment terms for product revenues are generally based on milestones tied to contract signing, shipment of products, and/or customer acceptance. Payment terms associated with the service portion of agreements are generally periodic and can be billed on a monthly, quarterly, or annual basis. In certain circumstances multiple years are billed at one time. The portion of these contract liabilities not expected to be recognized as revenue within twelve months of the balance sheet date are considered long term.

- removed (2019-05-03):
[0000926326-18-000030:note_history:112]
In the normal course of business, the Company typically does not accept product returns unless the item is defective as manufactured or the configuration of the product is incorrect. The Company establishes provisions for estimated returns based on historical product returns. The allowance for sales returns is not material to the Condensed Consolidated Financial Statements for any periods presented.

- removed (2019-05-03):
[0000926326-18-000030:note_history:113]
A portion of the Company's sales are made through multi-year lease agreements. Under sales-type leases, the Company recognizes revenue for its hardware and software products net of lease execution costs, such as post-installation product maintenance and technical support, at the net present value of the lease payment stream once its installation obligations have been met. The Company optimizes cash flows by selling a majority of its non-U.S. government leases to third-party leasing finance companies on a non-recourse basis. The Company has no obligation to the leasing company once the lease has been sold. Some of the Company's sales-type leases, mostly those relating to U.S. government hospitals which comprise approximately 44% of the lease receivable balance, are retained in-house. Revenues from sales-type leases of $11.4 million and $5.9 million for the three months ended September 30, 2018 and 2017, respectively, and $28.8 million and $19.3 million for the nine months ended September 30, 2018 and 2017, respectively, are included in product revenues in the Condensed Consolidated Statements of Operations. Interest income in these leases is recognized in product revenues using the effective interest method.

- removed (2019-05-03):
[0000926326-18-000030:note_history:114]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”). GPOs are often owned fully or in part by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs were $2.2 million and $2.1 million for the three months ended September 30, 2018 and 2017, respectively, and $6.2 million and $5.4 million for the nine months ended September 30, 2018 and 2017, respectively.

- removed (2019-05-03):
[0000926326-18-000030:note_history:115]
Contract Assets and Contract Liabilities

- removed (2019-05-03):
[0000926326-18-000030:note_history:116]
A contract asset is a right to consideration in exchange for goods or services that the Company has transferred to a customer when that right is conditional and is not just subject to the passage of time. A receivable will be recorded on the balance sheet when the Company has unconditional rights to consideration. A contract liability is an obligation to transfer goods or services for which the Company has received consideration, or for which an amount of consideration is due from the customer. Contract liabilities include customer deposits under non-cancelable contracts, and current and non-current deferred revenue balances. The Company’s contract balances are reported in a net contract asset or liability position on a contract-by-contract basis at the end of each reporting period.

- removed (2019-05-03):
[0000926326-18-000030:note_history:117]
Contract Costs

- removed (2019-05-03):
[0000926326-18-000030:note_history:118]
The Company has determined that the incentive portions of its sales commission plans require capitalization since these payments are directly related to sales achieved during a time period. These commissions are earned on the basis of the total purchase order value of new product bookings. Since there are not commensurate commissions earned on renewal of the service bookings, the Company concluded that the capitalized asset is related to services provided under both the initial contract and renewal periods. The Company applies a practical expedient to account for the incremental costs of obtaining a contract to a portfolio of contracts with similar characteristics as the Company expects the effect on the financial statements of applying the practical expedient would not differ materially from applying the accounting guidance to the individual contracts within the portfolio. A pool of contracts is defined as all contracts booked in a particular quarter. The amortization for the capitalized asset is an estimate of the pool’s original contract term, generally one to five years, plus an estimate of future customer renewal periods resulting in a total amortization period of ten years. Costs to obtain a contract are allocated amongst performance obligations and recognized as sales and marketing expense consistent with the pattern of revenue recognition. Capitalized costs are periodically reviewed for impairment. A portion of the pool’s capitalized asset is recorded as an expense after two quarters, which represents the estimated period during which the product revenue associated with the contract is recorded.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-05-03):
[0000926326-19-000013:note_history:119]
Revenues
  (was, 2018-11-02, similarity 0.64):
[0000926326-18-000030:note_history:119]
Deferred Revenues

- added (2019-05-03):
[0000926326-19-000013:note_history:120]
Revenue Recognition

- added (2019-05-03):
[0000926326-19-000013:note_history:121]
The Company earns revenues from sales of its medication and supply dispensing automation systems, along with consumables and related services, which are sold in the healthcare industry, its principal market. The Company’s customer arrangements typically include one or more of the following performance obligations:

- added (2019-05-03):
[0000926326-19-000013:note_history:122]
Products. Software-enabled equipment that manages and regulates the storage and dispensing of pharmaceuticals, consumable blister cards and packaging equipment and other medical supplies.

- added (2019-05-03):
[0000926326-19-000013:note_history:123]
Software. Additional software applications that enable incremental functionality of the Company’s equipment or services.

- added (2019-05-03):
[0000926326-19-000013:note_history:124]
Installation. Installation of equipment as integrated systems at customer sites.

- added (2019-05-03):
[0000926326-19-000013:note_history:125]
Post-installation technical support. Phone support, on-site service, parts, and access to unspecified software updates and enhancements, if and when available.

- added (2019-05-03):
[0000926326-19-000013:note_history:126]
Professional services. Other customer services, such as training and consulting.

- added (2019-05-03):
[0000926326-19-000013:note_history:127]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”). GPOs are often owned fully or in part by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs were $2.2 million and $1.9 million for the three months ended March 31, 2019 and 2018, respectively.

- added (2019-05-03):
[0000926326-19-000013:note_history:128]
Disaggregation of Revenues

- added (2019-05-03):
[0000926326-19-000013:note_history:129]
The following table summarizes the Company’s product revenues disaggregated by revenue type for the three months ended March 31, 2019 and 2018:

- added (2019-05-03):
[0000926326-19-000013:note_history:130]
|  | Three months ended March 31, |
|  | 2019 |  | 2018 |
|  | (In thousands) |
| Hardware and software | $ | 120,221 |  |  | $ | 107,451 |  |
| Consumables | 21,087 |  |  | 19,438 |  |
| Other | 4,302 |  |  | 3,770 |  |
| Total product revenues | $ | 145,610 |  |  | $ | 130,659 |  |

- added (2019-05-03):
[0000926326-19-000013:note_history:131]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location, for the three months ended March 31, 2019 and 2018:

- added (2019-05-03):
[0000926326-19-000013:note_history:132]
|  | Three months ended March 31, |
|  | 2019 |  | 2018 |
|  | (In thousands) |
| United States | $ | 180,020 |  |  | $ | 158,202 |  |
| Rest of world (1) | 22,497 |  |  | 24,417 |  |
| Total revenues | $ | 202,517 |  |  | $ | 182,619 |  |

- added (2019-05-03):
[0000926326-19-000013:note_history:133]
_________________________________________________

- added (2019-05-03):
[0000926326-19-000013:note_history:134]
| (1) | No individual country represented more than 10% of the respective totals. |

- added (2019-05-03):
[0000926326-19-000013:note_history:135]
Contract Assets and Contract Liabilities

- added (2019-05-03):
[0000926326-19-000013:note_history:136]
The following table reflects the Company’s contract assets and contract liabilities:

- added (2019-05-03):
[0000926326-19-000013:note_history:137]
|  | March 31, 2019 |  | December 31, 2018 |
|  | (In thousands) |
| Short-term unbilled receivables - included in accounts receivable and unbilled receivables | $ | 8,708 |  |  | $ | 9,191 |  |
| Long-term unbilled receivables - included in other long-term assets | 11,423 |  |  | 16,481 |  |
| Total contract assets | $ | 20,131 |  |  | $ | 25,672 |  |
| Short-term deferred revenues, net | $ | 90,104 |  |  | $ | 81,835 |  |
| Long-term deferred revenues | 10,302 |  |  | 10,582 |  |
| Total contract liabilities | $ | 100,406 |  |  | $ | 92,417 |  |

- added (2019-05-03):
[0000926326-19-000013:note_history:138]
The portion of the transaction price allocated to the Company’s unsatisfied performance obligations is recorded as deferred revenues.

- changed (2019-05-03):
[0000926326-19-000013:note_history:139]
Short-term deferred revenues of $90.1 million and $81.8 million include deferred revenues from product sales and service contracts, net of deferred cost of sales, of $12.2 million and $11.1 million as of March 31, 2019 and December 31, 2018, respectively. The short-term deferred revenues from product sales relate to delivered and invoiced products, pending installation and acceptance, expected to occur within the next twelve months. During the three months ended March 31, 2019, the Company recognized revenues of $39.3 million that were included in the corresponding gross short-term deferred revenues balance of $92.9 million as of December 31, 2018.
  (was, 2018-11-02, similarity 0.7895):
[0000926326-18-000030:note_history:139]
Short-term deferred revenues of $87.8 million and $78.8 million include deferred revenues from product sales and service contracts, net of deferred cost of sales of $14.9 million and $16.9 million as of September 30, 2018 and December 31, 2017, respectively. The short-term deferred revenues from product sales relate to delivered and invoiced products, pending installation and acceptance, expected to occur within the next twelve months.

- added (2019-05-03):
[0000926326-19-000013:note_history:140]
Long-term deferred revenues include deferred revenues from service contracts of $10.3 million and $10.6 million as of March 31, 2019 and December 31, 2018, respectively. Remaining performance obligations primarily relate to maintenance contracts and are recognized ratably over the remaining term of the contract, generally not more than five years.

- added (2019-05-03):
[0000926326-19-000013:note_history:141]
Significant Customers

- added (2019-05-03):
[0000926326-19-000013:note_history:142]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three months ended March 31, 2019 and 2018. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable as of March 31, 2019 and December 31, 2018.

- removed (2019-05-03):
[0000926326-18-000030:note_history:143]
Long-term deferred revenues include deferred revenues from service contracts of $10.6 million as of both September 30, 2018 and December 31, 2017.


## us-gaap:RevenueRecognitionMultipleDeliverableArrangementsTableTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2019-05-03):
[0000926326-19-000013:note_history:144]
The following table summarizes the Company’s product revenues disaggregated by revenue type for the three months ended March 31, 2019 and 2018:

- added (2019-05-03):
[0000926326-19-000013:note_history:145]
|  | Three months ended March 31, |
|  | 2019 |  | 2018 |
|  | (In thousands) |
| Hardware and software | $ | 120,221 |  |  | $ | 107,451 |  |
| Consumables | 21,087 |  |  | 19,438 |  |
| Other | 4,302 |  |  | 3,770 |  |
| Total product revenues | $ | 145,610 |  |  | $ | 130,659 |  |
