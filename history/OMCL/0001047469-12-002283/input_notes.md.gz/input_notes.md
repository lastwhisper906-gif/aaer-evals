# OMCL notes — 0001047469-12-002283


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0001047469-12-002283:notes:1]
| Note 17. Facilities Closures and Restructuring During the third quarter of 2010, we implemented a restructuring plan to close our offices in Bangalore, India and The Woodlands, Texas, and consolidate the activities of these two locations with our Mountain View, California and Nashville, Tennessee operations in an effort to increase the efficiency of operations and promote collaboration among our engineering teams. We substantially completed this consolidation by September 30, 2010. The $1.2 million of third quarter 2010 restructuring/impairment charges were recorded primarily in operating expenses, consisting of $0.3 million in severance for departing employees, $0.5 million relocation benefits for transferring employees, $0.2 million of exit and disposal costs related to the closed facilities, and $0.2 million for impairment of leasehold improvements and certain service tax reimbursement claims. The majority of the $0.2 million remaining restructuring accrued liabilities at December 31, 2010 were paid by December 31, 2011, except for the final legal/administrative exit costs for the India operation, which was less than $0.1 million. |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001047469-12-002283:notes:2]
|  |  | Year Ended December 31, |  |
|  |  | 2011 |  | 2010 |  | 2009 |  |
| Cost of revenues |  | $ | 1,398 |  | $ | 1,350 |  | $ | 1,478 |  |
| Research and development |  |  | 1,269 |  |  | 755 |  |  | 1,184 |  |
| Selling, general and administrative |  |  | 6,832 |  |  | 6,910 |  |  | 7,063 |  |
| Total share-based compensation expense |  | $ | 9,499 |  | $ | 9,015 |  | $ | 9,725 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001047469-12-002283:notes:3]
| Note 15. Stockholders' Equity Treasury Stock During 2008, our board of directors authorized a stock repurchase program for the repurchase of up to $90.0 million of our common stock. The timing, price and volume of the repurchases have been and will be based on market conditions, relevant securities laws and other factors. The stock repurchase program does not obligate us to repurchase any specific number of shares, and we may terminate or suspend the repurchase program at any time. Through December 31, 2011, a total of 4,955,807 shares at an average cost of $15.67 per share were repurchased through a combination of open market purchases and pursuant to a 10b18 trading plan. No shares were repurchased during the years ended December 31, 2010 and 2009. For the year ended December 31, 2008, shares with an aggregate value of $65.0 million, excluding broker commissions of $0.1 million, were repurchased. All repurchased shares were recorded as treasury stock and were accounted for under the cost method. No repurchased shares have been retired. As of December 31, 2011, we had $12.4 million of remaining authorized funds to repurchase additional shares under the stock repurchase programs. Additionally, for the years ended December 31, 2011, 2010 and 2009, we withheld 43,174 shares, 25,817 shares and 16,855 shares, respectively from employees to satisfy tax withholding obligations on the vesting of restricted stock. Share Purchase Rights Plan On February 6, 2003, our board of directors approved the adoption of a Share Purchase Rights Plan, or the Rights Plan. Terms of the Rights Plan provide for a dividend distribution of one preferred share purchase right, or a Right, for each outstanding share of our common stock, par value $0.001 per share. The dividend was payable on February 27, 2003 to the stockholders of record on that date. The Rights are not exercisable until the distribution date, which is the earlier of the date of a public announcement that a person, entity or group of affiliated or associated persons have acquired beneficial ownership of 15% or more of the outstanding share of our common stock (an "Acquiring Person") or (ii) 10 business days (or such later date as may be determined by action of the board of directors prior to such time as any person or entity becomes an Acquiring Person) following the commencement of, or announcement of an intention to commence, a tender offer or exchange offer the consummation of which would result in any person or entity becoming an Acquiring Person. In the event that any person or group of affiliated or associated persons becomes an Acquiring Person or a tender offer is commenced or announced to commence, each stockholder holding a Right will thereafter have the right to receive upon exercise of the Right that number of shares of Common Stock having a market value of two times the exercise price of the Right. The description and terms of the Rights are set forth in a Rights Agreement, dated as of February 6, 2003 entered into between us and EquiServe Trust Company, N.A., as rights agent. Sutter Hill Ventures and ABS Capital Partners and their respective affiliated entities will be exempt from the Rights Plan, unless they acquire beneficial ownership of 17.5% or 22.5% or more, respectively, of our common stock. At no time will the Rights have any voting power. The Rights will expire on February 27, 2013, unless the Rights are earlier redeemed or exchanged by Omnicell. |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001047469-12-002283:notes:4]
|  |  | Year Ended December 31, |  |
|  |  | 2011 |  | 2010 |  | 2009 |  |
| Domestic |  | $ | 16,177 |  | $ | 9,551 |  | $ | 844 |  |
| Foreign |  |  | (88 | ) |  | 406 |  |  | 348 |  |
| Total income before provision for income taxes |  | $ | 16,089 |  | $ | 9,957 |  | $ | 1,192 |  |


## us-gaap:CommitmentsDisclosureTextBlock

[0001047469-12-002283:notes:5]
| 2012 |  | $ | 4,220 |  |
| 2013 |  |  | 3,669 |  |
| 2014 |  |  | 3,812 |  |
| 2015 |  |  | 3,743 |  |
| 2016 |  |  | 3,672 |  |
| Thereafter |  |  | 23,718 |  |
| Total |  | $ | 42,834 |  |


## omcl:DeferredGrossProfitTextBlock

[0001047469-12-002283:notes:6]
|  |  | December 31, |  |
|  |  | 2011 |  | 2010 |  |
| Sales of medication and supply dispensing systems, which have been delivered and invoiced but not yet installed |  | $ | 24,181 |  | $ | 18,739 |  |
| Cost of sales, excluding installation costs |  |  | (9,971 | ) |  | (7,020 | ) |
| Deferred gross profit |  | $ | 14,210 |  | $ | 11,719 |  |


## omcl:AccruedLiabilitiesTextBlock

[0001047469-12-002283:notes:7]
|  |  | December 31, |  |
|  |  | 2011 |  | 2010 |  |
| Accrued GPO (Group Purchasing Organization) fees |  | $ | 2,437 |  | $ | 2,272 |  |
| Rebates and lease buyouts |  |  | 1,748 |  |  | 1,923 |  |
| Advance payments from customers |  |  | 1,631 |  |  | 1,978 |  |
| Pre-acquisition contingency |  |  | — |  |  | 1,200 |  |
| Other |  |  | 1,326 |  |  | 1,311 |  |
| Total |  | $ | 7,142 |  | $ | 8,684 |  |


## us-gaap:OtherAssetsDisclosureTextBlock

[0001047469-12-002283:notes:8]
|  |  | December 31, |  |
|  |  | 2011 |  | 2010 |  |
| Capitalized software development costs, net of accumulated amortization of $5,018 and $3,441 in 2011 and 2010, respectively |  | $ | 8,077 |  | $ | 5,462 |  |
| Non-current deferred service billings receivable |  |  | 763 |  |  | 2,162 |  |
| Long-term deposits |  |  | 526 |  |  | 383 |  |
| Other assets |  |  | 350 |  |  | 358 |  |
| Total |  | $ | 9,716 |  | $ | 8,365 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001047469-12-002283:notes:9]
|  |  | December 31, 2011 |  | December 31, 2010 |  |  |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Amortization Life |
| Finite-lived intangibles: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 4,230 |  | $ | 1,591 |  | $ | 2,639 |  | $ | 4,230 |  | $ | 1,142 |  | $ | 3,088 |  | 5 - 16 years |
| Acquired technology |  |  | 980 |  |  | 175 |  |  | 805 |  |  | 980 |  |  | 35 |  |  | 945 |  | 3 - 7 years |
| Patents |  |  | 889 |  |  | 190 |  |  | 699 |  |  | 654 |  |  | 152 |  |  | 502 |  | 20 years |
| Trade name |  |  | 90 |  |  | 37 |  |  | 53 |  |  | 90 |  |  | 8 |  |  | 82 |  | 3 year |
| Non-compete agreements |  |  | 60 |  |  | 25 |  |  | 35 |  |  | 60 |  |  | 5 |  |  | 55 |  | 3 year |
| Total finite-lived intangibles |  |  | 6,249 |  |  | 2,018 |  |  | 4,231 |  |  | 6,014 |  |  | 1,342 |  |  | 4,672 |  |  |
| Goodwill |  |  | 28,543 |  |  | — |  |  | 28,543 |  |  | 28,543 |  |  | — |  |  | 28,543 |  | Indefinite |
| Net other intangible assets & goodwill |  | $ | 34,792 |  | $ | 2,018 |  | $ | 32,774 |  | $ | 34,557 |  | $ | 1,342 |  | $ | 33,215 |  |  |


## omcl:NetInvestmentsInSalesTypeLeasesTextBlock

[0001047469-12-002283:notes:10]
|  |  | December 31, |  |
|  |  | 2011 |  | 2010 |  |
| Net minimum lease payments to be received |  | $ | 15,063 |  | $ | 16,284 |  |
| Less unearned interest income portion |  |  | 1,229 |  |  | 1,843 |  |
| Net investment in sales-type leases |  |  | 13,834 |  |  | 14,441 |  |
| Less current portion(1) |  |  | 5,049 |  |  | 5,217 |  |
| Non-current net investment in sales-type leases(2) |  | $ | 8,785 |  | $ | 9,224 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001047469-12-002283:notes:11]
|  |  | December 31, |  |
|  |  | 2011 |  | 2010 |  |
| Equipment |  | $ | 25,101 |  | $ | 20,045 |  |
| Furniture and fixtures |  |  | 1,811 |  |  | 1,681 |  |
| Leasehold improvements |  |  | 3,692 |  |  | 3,182 |  |
| Purchased software |  |  | 20,641 |  |  | 18,095 |  |
| Capital in process |  |  | 2,283 |  |  | 1,689 |  |
|  |  |  | 53,528 |  |  | 44,692 |  |
| Accumulated depreciation and amortization |  |  | (36,222 | ) |  | (30,341 | ) |
| Property and equipment, net |  | $ | 17,306 |  | $ | 14,351 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001047469-12-002283:notes:12]
|  |  | December 31, |  |
|  |  | 2011 |  | 2010 |  |
| Raw materials |  | $ | 7,666 |  | $ | 4,252 |  |
| Work in process |  |  | 14 |  |  | 153 |  |
| Finished goods |  |  | 10,427 |  |  | 5,380 |  |
| Total |  | $ | 18,107 |  | $ | 9,785 |  |


## us-gaap:CashAndCashEquivalentsDisclosureTextBlock

[0001047469-12-002283:notes:13]
|  |  | December 31, 2011 |  |  |
|  |  |  |  |  |  |  |  |  |  | Net Carrying Amount |  |  |
|  |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |  | Cash / Cash Equivalents |  | Short-Term Investments |  | Security Classification |
| Cash |  | $ | 14,452 |  | $ | — |  | $ | — |  | $ | 14,452 |  | $ | 14,452 |  | $ | — |  | N/A |
| Money market funds |  |  | 177,310 |  |  | — |  |  | — |  |  | 177,310 |  |  | 177,310 |  |  | — |  | Available for sale |
| Non-U.S. government securities |  |  | 8,106 |  |  | 1 |  |  | — |  |  | 8,107 |  |  | — |  |  | 8,107 |  | Available for sale |
| Total cash, cash equivalents and short-term investments |  | $ | 199,868 |  | $ | 1 |  |  | — |  | $ | 199,869 |  | $ | 191,762 |  | $ | 8,107 |  |  |


## us-gaap:EarningsPerShareTextBlock

[0001047469-12-002283:notes:14]
|  |  | Years Ended December 31, |  |
|  |  | 2011 |  | 2010 |  | 2009 |  |
| Basic: |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 10,389 |  | $ | 4,892 |  | $ | 444 |  |
| Weighted average shares outstanding—basic |  |  | 33,123 |  |  | 32,651 |  |  | 31,691 |  |
| Net income per share—basic |  | $ | 0.31 |  | $ | 0.15 |  | $ | 0.01 |  |
| Diluted: |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 10,389 |  | $ | 4,892 |  | $ | 444 |  |
| Weighted average shares outstanding—basic |  |  | 33,123 |  |  | 32,651 |  |  | 31,691 |  |
| Dilutive effect of employee stock plans |  |  | 980 |  |  | 862 |  |  | 372 |  |
| Weighted average shares outstanding—diluted |  |  | 34,103 |  |  | 33,513 |  |  | 32,063 |  |
| Net income per share—diluted |  | $ | 0.30 |  | $ | 0.15 |  | $ | 0.01 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001047469-12-002283:notes:15]
|  |  | Fair Values Acquired |  |
| Cash |  | $ | 297 |  |
| Accounts receivable |  |  | 416 |  |
| Indemnification asset |  |  | 1,000 |  |
| Intangibles |  |  | 2,420 |  |
| Goodwill |  |  | 3,561 |  |
| Deferred tax asset |  |  | 108 |  |
| Total assets |  |  | 7,802 |  |
| Accrued compensation/other |  |  | 292 |  |
| Deferred service revenue |  |  | 510 |  |
| Litigation contingency |  |  | 1,000 |  |
| Total liabilities |  |  | 1,802 |  |
| Net assets acquired |  | $ | 6,000 |  |
| Cash consideration, fair value |  | $ | 6,000 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001047469-12-002283:notes:16]
| Computer equipment and related software |  | 3 - 5 years |
| Leasehold and building improvements |  | Shorter of the lease term or the estimated useful life |
| Furniture and fixtures |  | 5 years |
| Equipment |  | 3 - 5 years |


## us-gaap:LegalMattersAndContingenciesTextBlock

[0001047469-12-002283:notes:17]
| Note 13. Contingencies Legal Proceedings Medacist Solutions Group, LLC. On July 8, 2009, Medacist Solutions Group LLC filed a complaint against Omnicell in U.S. District Court in the Southern District of New York, entitled Medacist Solutions Group LLC v. Omnicell, Inc., case number 09 CV 6128, alleging infringement of Medacist's U.S. Patent Number 6,842,736. The complaint also, among other claims, alleges that Omnicell breached the terms of a nondisclosure agreement it had entered into with Medacist, and that Omnicell misappropriated Medacist's trade secrets and confidential information in violation of the NDA. Medacist sought unspecified monetary damages and an injunction against the Company's infringement of the specified patent and/or misuse of any of Medacist's trade secrets pursuant to the NDA or in violation of California code. On October 20, 2010, Omnicell filed a declaratory judgment complaint against Medacist Solutions Group, LLC in the U.S. District Court in the Northern District of California, entitled Omnicell, Inc. and Pandora Data Systems, Inc. v. Medacist Solutions Group, LLC, Case Number 10-cv-4746 (the "California Action"). Pandora Data Systems, Inc. had entered into a Settlement and License Agreement with Medacist in October 2008 (the "Settlement Agreement") pursuant to which, among other things, Medacist granted to Pandora a non-exclusive license to Medacist's U.S. Patent Number 6,842,736. We sought an order declaring that Omnicell, as now-owner of Pandora Data Systems, Inc., was entitled to certain rights and benefits under the license. On November 12, 2010, Medacist filed a motion to dismiss the California Action, or in the alternative, to transfer venue to the U.S. District Court for the District of Connecticut. Also on November 12, 2010, Medacist filed a motion in the U.S. District Court in the District of Connecticut to reopen a litigation entitled Medacist Solutions Group, LLC v. Pandora Data Systems, Inc., Case Number 3:07-CV-00692(JCH) (the "Connecticut Litigation"), which had been dismissed and administratively closed since October 29, 2008. Medacist sought, among other things, relief from the Stipulation of Dismissal entered on October 29, 2008 dismissing the Connecticut Litigation for the limited purpose of interpreting and enforcing the Settlement Agreement, the entry of a temporary restraining order and preliminary and permanent injunctions prohibiting breaches of the Settlement Agreement, a finding that Pandora breached the Settlement Agreement and an award of monetary damages resulting from Pandora's alleged breaches. On February 10, 2011, the Court granted Medacist's motion and dismissed the California Action without prejudice. On February 14, 2011, Omnicell and Pandora filed a notice of appeal regarding dismissal of the California Action with the U.S. Court of Appeals for the Ninth Circuit. On May 19, 2011, we entered into a final settlement agreement with Medacist, pursuant to which we agreed to pay Medacist $1.0 million in exchange for a fully-paid, perpetual license to Medacist's patented technology and the parties agreed to dismiss all pending lawsuits and fully release each other from all claims. In addition, we agreed that a license transfer fee payment of $0.5 million would be made to Medacist in the event certain change-in-control conditions are met. The $1.0 million loss for this settlement was accrued during the three months ended March 31, 2011 and recorded within selling, general and administrative expenses, and was paid during the quarter ended June 30, 2011. Guarantees As permitted under Delaware law and our certificate of incorporation and bylaws, we have agreed to indemnify our directors and officers against certain losses that they may suffer by reason of the fact that such persons are, were or become our directors or officers. The term of the indemnification period is for the director's or officer's lifetime and there is no limit on the potential amount of future payments that we could be required to make under these indemnification agreements. We have purchased directors' and officers' liability insurance policy that may enable us to recover a portion of any future payments that we may be required to make under these indemnification agreements. Assuming the applicability of coverage and the willingness of the insurer to assume coverage and subject to certain retention, loss limits and other policy provisions, we believe it is unlikely that we will be required to pay any material amounts pursuant to these indemnification obligations. However, no assurances can be given that the insurers will not attempt to dispute the validity, applicability or amount of coverage without expensive and time-consuming litigation against the insurers. Additionally, we undertake indemnification obligations in our ordinary course of business in connection with, among other things, the licensing of our products and the provision of our support services. In the ordinary course of our business, we have in the past and may in the future agree to indemnify another party, generally our business affiliates or customers, against certain losses suffered or incurred by the indemnified party in connection with various types of claims, which may include, without limitation, claims of intellectual property infringement, certain tax liabilities, our gross negligence or intentional acts in the performance of support services and violations of laws. The term of these indemnification obligations is generally perpetual. In general, we attempt to limit the maximum potential amount of future payments that we may be required to make under these indemnification obligations to the amounts paid to us by a customer, but in some cases the obligation may not be so limited. In addition, we have in the past and may in the future warrant to our customers that our products will conform to functional specifications for a limited period of time following the date of installation (generally not exceeding 30 days) or that our software media is free from material defects. From time to time, we may also warrant that our professional services will be performed in a good and workmanlike manner or in a professional manner consistent with industry standards. We generally seek to disclaim most warranties, including any implied or statutory warranties such as warranties of merchantability, fitness for a particular purpose, title, quality and non-infringement, as well as any liability with respect to incidental, consequential, special, exemplary, punitive or similar damages. In some states, such disclaimers may not be enforceable. If necessary, we would provide for the estimated cost of product and service warranties based on specific warranty claims and claim history. We have not been subject to any significant claims for such losses and have not incurred any material costs in defending or settling claims related to these indemnification obligations. Accordingly, we believe it is unlikely that we will be required to pay any material amounts pursuant to these indemnification obligations or potential warranty claims and, therefore, no liabilities have been recorded for such indemnification obligations as of December 31, 2011 or December 31, 2010. |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001047469-12-002283:notes:18]
| Allowances deducted from assets: |  | Balance at beginning of year |  | Additions charged to costs and expenses(2) |  | Charged (credited) to other accounts |  | Describe charged to other accounts |  | Deductions |  | Describe deductions |  | Balance at end of year |  |
| For the year ended December 31, 2009 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable(1) |  | $ | 1,349 |  | $ | 191 |  | $ | (251 | ) | (3) |  | $ | (421 | ) | (4) |  | $ | 868 |  |
| Investment in sales-type leases(1) |  |  | 335 |  |  | 673 |  |  | (438 | ) | (5) |  |  | — |  |  |  |  | 570 |  |
| Total allowances deducted from assets |  | $ | 1,684 |  | $ | 864 |  | $ | (689 | ) |  |  | $ | (421 | ) |  |  | $ | 1,438 |  |
| For the year ended December 31, 2010 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable(1) |  | $ | 868 |  | $ | 297 |  | $ | (484 | ) | (3) |  | $ | (184 | ) | (4) |  | $ | 497 |  |
| Investment in sales-type leases(1) |  |  | 570 |  |  | 3 |  |  | (40 | ) | (5) |  |  | (122 | ) | (4) |  |  | 411 |  |
| Total allowances deducted from assets |  | $ | 1,438 |  | $ | 300 |  | $ | (524 | ) |  |  | $ | (306 | ) |  |  | $ | 908 |  |
| For the year ended December 31, 2011 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable(1) |  | $ | 497 |  | $ | 63 |  | $ | (96 | ) | (3) |  | $ | (21 | ) | (4) |  | $ | 443 |  |
| Investment in sales-type leases(1) |  |  | 411 |  |  | — |  |  | (22 | ) | (3) |  |  | (105 | ) | (4) |  |  | 284 |  |
| Total allowances deducted from assets |  | $ | 908 |  | $ | 63 |  | $ | (118 | ) |  |  | $ | (126 | ) |  |  | $ | 727 |  |
