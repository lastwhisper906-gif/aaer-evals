# OMCL MD&A — 0001047469-12-002283


## mdna

[0001047469-12-002283:mdna:1]
ITEM 7.    MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001047469-12-002283:mdna:2]
The following discussion and analysis should be read in conjunction with our financial statements and related
notes included elsewhere in this Annual Report on Form 10-K. This discussion may contain forward-looking statements based upon current expectations that involve risks and
uncertainties. Our actual results and the timing of selected events could differ materially from those anticipated in these forward-looking statements as a result of several factors, including those
set forth under Item 1A "Risk Factors" and elsewhere in this Annual Report on Form 10-K. Unless otherwise stated, references in this report to particular years or quarters
refer to our fiscal year and the associated quarters of those fiscal years.

[0001047469-12-002283:mdna:3]
Overview

[0001047469-12-002283:mdna:4]
We were incorporated in California in 1992 under the name Omnicell Technologies, Inc. and reincorporated in Delaware in 2001 as
Omnicell, Inc. Our healthcare automation solutions are designed to enable healthcare facilities to acquire, manage, dispense and administer medications and medical and surgical supplies, and
are intended to enhance patient safety, reduce medication errors, improve workflow and increase operational efficiency. We sell our medication dispensing and supply automation systems primarily in the
United States. Approximately 2% of our product revenue is from outside the United States and Canada, although we believe adoption of our products internationally will increase in future years. Our
sales force is organized by geographic region in the United States and Canada. We also sell through distributors in Asia, Australia, Europe, the Middle East and South America. We have not sold and
have no future plans to sell our products either directly or indirectly to customers located in countries that are identified as state sponsors of terrorism by the U.S. Department of State, or those
subject to economic sanctions and export controls. In 2011, we manufactured the majority of our systems in our California facility and refurbishment and spare parts activities were conducted in our
Illinois facility.

[0001047469-12-002283:mdna:5]
In
general, we recognize revenue when our systems are installed. Installation for our products generally takes place two weeks to nine months after our systems are ordered. The
installation process at our customers' sites includes internal procedures associated with integrating large capital expenditures and time associated with adopting new technologies. Given the length of
time necessary for our customers to plan for and complete the installation of our systems, our focus is on shipping products based on the installation dates requested by our customers and working at
the customer's pace. The amount of revenue recognized in future periods may depend on, among other things, the terms and timing of lease contract renewals, timing of customer installations, additional
product sales and the size of such transactions. We believe that future revenue will be affected by the competitiveness of our products and services.

[0001047469-12-002283:mdna:6]
Our
revenue increased by 10.4% from $222.4 million in 2010 to $245.5 million in 2011. Of the $23.1 million increase in revenues from 2010 to 2011,
$14.8 million was attributable to an increase in product revenues for 2011 as compared with 2010, reflecting increased completed installations of our new automation products, increases in lease
renewals from existing customers and a full year of revenues derived from our acquisition of Pandora Data Systems, Inc. at the end of the third quarter of 2010. Service revenues increased by
$8.4 million in 2011 as compared with 2010, primarily due to growth in the installed customer base. We believe that economic conditions are improving and that spending in the healthcare
industry and demand for our products will increase in the future. We believe that demand for our products in future periods will be based on:

[0001047469-12-002283:mdna:7]
•

[0001047469-12-002283:mdna:8]
Our expectation that the overall market demand for healthcare services will increase as the population grows, life
expectancies continue to increase, the quality of healthcare services increases and the availability of healthcare services increases;

[0001047469-12-002283:mdna:9]
•

[0001047469-12-002283:mdna:10]
Our expectation that the environment of increased patient safety awareness, increased regulatory control and increased
need for workflow efficiency through the adoption of technology in the healthcare industry will make our solutions a priority in the capital budgets of healthcare facilities;

[0001047469-12-002283:mdna:11]
•

[0001047469-12-002283:mdna:12]
Our continued ability to differentiate ourselves through a strategy intended to provide the best customer experience in
the healthcare industry; and

[0001047469-12-002283:mdna:13]
•

[0001047469-12-002283:mdna:14]
Our delivery of industry-leading products with differentiated product features that are designed to appeal to nurses,
pharmacists, supply chain managers, chief information officers and hospital management.

[0001047469-12-002283:mdna:15]
We
expect to operate through 2012 with our backlog within our objective of the next six to nine months of product revenue but we believe there will be variation from time to time. Our
product backlog, consisting of orders accepted but not yet installed, increased from $126.8 million as of December 31, 2010 to $133.9 million at December 31, 2011.

[0001047469-12-002283:mdna:16]
Our
key business strategies include:

[0001047469-12-002283:mdna:17]
•

[0001047469-12-002283:mdna:18]
Delivering solutions that are designed to provide our customers with the best experience in the healthcare industry
by:

[0001047469-12-002283:mdna:19]
•

[0001047469-12-002283:mdna:20]
Proactively anticipating and meeting customer product and service requirements;

[0001047469-12-002283:mdna:21]
•

[0001047469-12-002283:mdna:22]
Listening carefully to our customers' prospective issues; and

[0001047469-12-002283:mdna:23]
•

[0001047469-12-002283:mdna:24]
Meeting and exceeding our customers' installation and support needs.

[0001047469-12-002283:mdna:25]
•

[0001047469-12-002283:mdna:26]
Further penetrating the existing market for our products through sustaining technological leadership in our products
by:

[0001047469-12-002283:mdna:27]
•

[0001047469-12-002283:mdna:28]
Consistently innovating our product and service offerings; and

[0001047469-12-002283:mdna:29]
•

[0001047469-12-002283:mdna:30]
Maintaining our flexibility in customer product design and in the installation process.

[0001047469-12-002283:mdna:31]
•

[0001047469-12-002283:mdna:32]
Increasing penetration of the international market by:

[0001047469-12-002283:mdna:33]
•

[0001047469-12-002283:mdna:34]
Bringing new products and technologies to market that are specific to international markets;

[0001047469-12-002283:mdna:35]
•

[0001047469-12-002283:mdna:36]
Partnering with companies that have sales, distribution, or other capabilities that we do not possess in
non-U.S. geographies; and

[0001047469-12-002283:mdna:37]
•

[0001047469-12-002283:mdna:38]
Increasing customer awareness of safety issues in the administration of medications.

[0001047469-12-002283:mdna:39]
•

[0001047469-12-002283:mdna:40]
Expanding our product offering through acquisitions and partnerships.

[0001047469-12-002283:mdna:41]
In
order to implement these strategies during 2011, we did the following:

[0001047469-12-002283:mdna:42]
•

[0001047469-12-002283:mdna:43]
Increased our sales organization to expand coverage of our growing installed base and to expand our reach to new
customers;

[0001047469-12-002283:mdna:44]
•

[0001047469-12-002283:mdna:45]
Introduced eleven new products to market through our G4 launch;

[0001047469-12-002283:mdna:46]
•

[0001047469-12-002283:mdna:47]
Achieved modular certification for "meaningful use" of an EHR, which allows chief information officers to meet new
regulations and take advantage of government incentives; and

[0001047469-12-002283:mdna:48]
•

[0001047469-12-002283:mdna:49]
Expanded into the Chinese market after an extensive trial of our Mandarin language system in Peking Union Medical Center
Hospital in Beijing.

[0001047469-12-002283:mdna:50]
Our
healthcare customers expect a high degree of partnership from their technology suppliers. Omnicell provides extensive installation planning and consulting as part of every product
sale. Our customers medication control systems are mission critical to their success and our customers require

[0001047469-12-002283:mdna:51]
these
systems to be functional at all times. To help assure the maximum availability of our systems, our customers purchase maintenance and support contracts in one, two or five year increments. Our
long-term liabilities, which were $20.3 million as of December 31, 2011 and $19.8 million as of December 31, 2010, are principally composed of
long-term deferred service
revenue, which was $19.0 million as of December 31, 2011, and $19.2 million as of December 31, 2010. Our deferred service revenue will be amortized to service revenue as
the service contracts are executed.

[0001047469-12-002283:mdna:52]
In
2011, we generated positive overall cash flow of $16.1 million. This was primarily due to our $10.4 million of net income, adjusted for non-cash expenses
associated with depreciation and amortization of $8.0 million, share-based compensation of $9.5 million and $6.8 million of proceeds from the issuance of common stock under our
employee stock purchase and stock option plans. Additional factors were strong cash collections, reducing accounts receivable at year end by $5.9 million as compared to 2010 and increases of
$3.6 million of deferred service revenue and $2.5 million of deferred gross profit. These increases to cash were offset by a $9.4 million increase in inventory, primarily related
to the G4 launch, $13.1 million for the acquisition and development of productive long-lived assets and $12.6 million in stock repurchases.

[0001047469-12-002283:mdna:53]
In
2010, we generated positive overall cash flow of $6.4 million, primarily due to improved net income, adjusted for non-cash expenses associated with depreciation,
amortization and share-based compensation, and proceeds from the issuance of common stock under our employee stock purchase and stock option plans. The increases to cash were offset by
$23.0 million in investing cash outflows for purchases of short-term investments, the acquisition of Pandora, and the acquisition and development of productive
long-lived assets.

[0001047469-12-002283:mdna:54]
For
the year ended December 31, 2011, net cash provided by operations continued to be positive at $31.2 million, and our cash and cash equivalents balance plus
short-term investments as of December 31, 2011 was $199.9 million as compared to $183.7 million at December 31, 2010. We expect cash provided by operations to
remain positive in 2012.

[0001047469-12-002283:mdna:55]
Our
full-time headcount of 773 on December 31, 2011 increased by 20 net positions from our full-time headcount on December 31, 2010. The net
increase included rebalancing of the functional mix, with the majority of the net increase in sales and marketing. We record compensation expense from our share-based awards, options and our employee
stock purchase plan in accordance with Account Standards Codification, or ASC, 718, Stock Compensation. Total share-based compensation expense for the
year ended December 31, 2011 was $9.5 million, compared to $9.0 million in 2010.

[0001047469-12-002283:mdna:56]
Our
gross profit increased 15.2% for the year ended December 31, 2011 as compared to the year ended December 31, 2010, with gross margins increasing by
2.3 percentage points to 55.3%. The increases in gross profits and related margins were driven primarily by a shift in product mix to higher margin products including a significant volume of
lease renewal activity, overall manufacturing efficiencies and higher service revenues without a proportional increase in costs. We expect revenues to increase modestly in 2012 and we do not
anticipate any major fluctuations in our gross margin beyond normal fluctuations caused by changes in product mix. Revenues and gross margins may be adversely affected, however, as a result of
unforeseen market price reductions and additional costs to expand our business.

[0001047469-12-002283:mdna:57]
Net
income increased to $10.4 million in 2011 compared to $4.9 million in 2010 due to an increase in gross profit of $17.9 million, which included an
$11.6 million increase in gross profit from product revenues and $6.3 million from service revenues. This increase was partially offset by an $11.2 million increase in operating
expenses primarily due to an increase in selling, general and administrative of $11.3 million and an increase in research and development activities of $1.0 million. Partially offsetting
these increases in 2011 was the absence of pretax restructuring charges compared to $1.2 million in 2010 for facilities consolidation.

[0001047469-12-002283:mdna:58]
39

[0001047469-12-002283:mdna:59]
We
operate in one business segment, the design, manufacturing, selling and servicing of medication and supply dispensing systems. Our chief operating decision maker, who is our chief
executive officer, along with our management team evaluates our profit performance based on company-wide, consolidated results. The September 2010 acquisition of Pandora resulted in
neither the creation of a new reporting unit nor a new operating segment.

[0001047469-12-002283:mdna:60]
Critical Accounting Policies and Estimates

[0001047469-12-002283:mdna:61]
Our discussion and analysis of our financial condition and results of operations are based on our consolidated financial statements,
which have been prepared in accordance with United States generally accepted accounting principles, or GAAP. The preparation of these financial statements requires us to make certain estimates and
assumptions that affect the reported amounts of assets and liabilities, disclosure of any contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues
and expenses during the reporting periods. We regularly review our estimates and assumptions, which are based on historical experience and various other factors that are believed to be reasonable
under the circumstances, the results of which form the basis for making judgments about the carrying values of certain assets and liabilities that are not readily apparent from other sources. Actual
results may differ from these estimates and assumptions. We believe the following critical accounting policies are affected by significant judgments and estimates used in the preparation of our
consolidated financial statements:

[0001047469-12-002283:mdna:62]
Revenue recognition.    We earn revenues from sales of our medication and supply dispensing systems, with related services, sold in our
principal market
the healthcare industry. Our market is primarily located in the United States. Our customer arrangements typically include one or more of the following
deliverables:

[0001047469-12-002283:mdna:63]
•

[0001047469-12-002283:mdna:64]
Products—Software-enabled equipment that manages and regulates
the storage and dispensing of pharmaceuticals and other medical supplies.

[0001047469-12-002283:mdna:65]
•

[0001047469-12-002283:mdna:66]
Software—Additional software applications that enable
incremental functionality of our equipment.

[0001047469-12-002283:mdna:67]
•

[0001047469-12-002283:mdna:68]
Installation—Installation of equipment as integrated systems
at customers' sites.

[0001047469-12-002283:mdna:69]
•

[0001047469-12-002283:mdna:70]
Post-installation technical support—Phone support,
on-site service, parts and access to unspecified software upgrades and enhancements, if and when available.

[0001047469-12-002283:mdna:71]
•

[0001047469-12-002283:mdna:72]
Professional services—Other customer services, such as
training and consulting.

[0001047469-12-002283:mdna:73]
We
recognize revenue when the earnings process is complete, based upon our evaluation of whether the following four criteria have been met:

[0001047469-12-002283:mdna:74]
•

[0001047469-12-002283:mdna:75]
Persuasive evidence of an arrangement
exists.  We use signed customer contracts and signed customer purchase orders as evidence of an arrangement for leases and sales. For
service engagements, we use a signed services agreement and a statement of work to evidence an arrangement.

[0001047469-12-002283:mdna:76]
•

[0001047469-12-002283:mdna:77]
Delivery has
occurred.  Equipment and software product delivery is deemed to occur upon successful installation and receipt of a signed and dated
customer confirmation of installation letter, providing evidence that we have delivered what the customer ordered. In instances of a customer self-installation, product delivery is deemed
to have occurred upon receipt of a signed and dated customer confirmation letter. If a sale does not require installation, we recognize revenue on delivery of products to the customer, including
transfer of title and risk of loss assuming all other revenue criteria are met. We recognize revenue from sales of products to distributors upon delivery assuming all other revenue criteria are met
since we do not allow for rights of return or refund. Assuming all other revenue criteria are met, we recognize revenue for

[0001047469-12-002283:mdna:78]
support
services ratably over the related support services contract period. We recognize revenue on training and professional services as they are performed.

[0001047469-12-002283:mdna:79]
•

[0001047469-12-002283:mdna:80]
Fee is fixed or
determinable.  We assess whether a fee is fixed or determinable at the outset of the arrangement based on the payment terms associated
with the transaction. We have established a history of collecting under the original contract without providing concessions on payments, products or services.

[0001047469-12-002283:mdna:81]
•

[0001047469-12-002283:mdna:82]
Collection is
probable.  We assess the probability of collecting from each customer at the outset of the arrangement based on a number of factors,
including the customer's payment history and its current creditworthiness. If, in our judgment, collection of a fee is not probable, we defer the revenue until the uncertainty is removed, which
generally means revenue is recognized upon our receipt of cash payment assuming all other revenue criteria are met. Our historical experience has been that collection from our customers is generally
probable.

[0001047469-12-002283:mdna:83]
In
arrangements with multiple deliverables, assuming all other revenue criteria are met, we recognize revenue for individual delivered items if they have value to the customer on a
standalone basis. Effective for new or modified arrangements entered into beginning on January 1, 2011, we allocate arrangement consideration at the inception of the arrangement to all
deliverables using the relative selling price method. We adopted the new revenue recognition guidance for arrangements with multiple
deliverables on a prospective basis as of January 1, 2011.This method requires us to determine the selling price at which each deliverable could be sold if it were sold regularly on a
standalone basis. When available, we use vendor-specific objective evidence, or VSOE of fair value as the selling price. VSOE represents the price charged for a deliverable when it is sold separately
or for a deliverable not yet being sold separately, the price established by management with the relevant authority. We consider VSOE to exist when approximately 80% or more of our standalone sales of
an item are priced within a reasonably narrow pricing range (plus or minus 15% of the median rates). We have established VSOE of fair value for our post-installation technical support
services and professional services. When VSOE of fair value is not available, third-party evidence, or TPE, of fair value for similar products and services is acceptable; however, our offerings and
market strategy differ from those of our competitors, such that we cannot obtain sufficient comparable information about third parties' prices. If neither VSOE nor TPE are available, we use our best
estimates of selling prices, or BESP. We determine BESP considering factors such as market conditions, sales channels, internal costs and product margin objectives and pricing practices. We regularly
review and update our VSOE, TPE and BESP information and obtain formal approval by appropriate levels of management.

[0001047469-12-002283:mdna:84]
The
relative selling price method allocates total arrangement consideration proportionally to each deliverable on the basis of its estimated selling price. In addition, the amount
recognized for any delivered items cannot exceed that which is not contingent upon delivery of any remaining items in the arrangement.

[0001047469-12-002283:mdna:85]
We
also use the residual method of allocating the arrangement consideration in certain circumstances. We use the residual method to allocate total arrangement consideration between
delivered and undelivered items for any arrangements entered into prior to January 1, 2011 and not subsequently materially modified. The use of the residual method is required by software
revenue recognition rules that applied to sales of most of our products and services until the adoption of the new revenue recognition guidance. We also use the residual method to allocate revenue
between the software products that enable incremental equipment functionality and thus are not deemed to deliver their essential functionality, and the related post-installation technical
support, as these products and services continue to be accounted for under software revenue recognition rules. Under the residual method, the amount allocated to the undelivered elements equals VSOE
of fair value of these elements. Any remaining amounts are attributed to the delivered items and are recognized when those items are delivered.

[0001047469-12-002283:mdna:86]
The
adoption of the new revenue recognition guidance did not result in changes in what we identify as the individual deliverables to which revenue is allocated, or the timing of revenue
recognition related to these individual deliverables. The change in the allocation method from residual to relative selling price did not have a material impact on our financial statements during year
ended December 31, 2011. In addition, there is a time lag between when we receive a signed customer purchase order or contract and when we install the products, sometimes as long as one year or
more, primarily due to the installation cycles and timing preferences of our customers. As a result, only about half of the product
revenue we recognized during year ended December 31, 2011 was subject to the new revenue recognition guidance. In future periods, we anticipate the cumulative impact of the adoption may
increase, as additional arrangements become subject to the new revenue recognition guidance. However, the specific adjustments for any future period are not predictable, as they depend on the timing
of our backlog shipments and installations and the nature of the orders we receive from new customers.

[0001047469-12-002283:mdna:87]
A
portion of our sales are made through multi-year lease agreements. We recognize product-related revenue under sales-type leases, net of lease execution costs
such as post-installation product maintenance and technical support, at the net present value of the lease payment stream once our installation obligations have been met. We optimize cash
flows by selling a majority of our non-U.S. government leases to third-party leasing finance companies on a non-recourse basis. We have no obligation to the leasing company
once the lease has been sold. Some of our sales-type leases, mostly those relating to U.S. government hospitals, are retained in-house. Interest income in these leases is
recognized in product revenue using the interest method.

[0001047469-12-002283:mdna:88]
Provision for allowances.    We continually monitor and evaluate the collectability of our trade receivables and our net investment in
sales-type leases based on a combination of factors. We record specific allowances for doubtful accounts when we become aware of a specific customer's inability to meet its financial
obligation to us such as in the case of bankruptcy filings or deterioration of financial position. Estimates are used in determining our allowances for all other customers based on factors such as
current trends, the length of time the receivables are past due and historical collection experience.

[0001047469-12-002283:mdna:89]
Valuation and impairment of goodwill, other intangible assets and other long lived assets.    We account for goodwill and other intangible
assets in
accordance with ASC 350, Intangibles—Goodwill and Other. For the initial recognition and measurement of goodwill and intangibles resulting
from business acquisitions, we use the guidance in ASC 805, Business Combinations.

[0001047469-12-002283:mdna:90]
Goodwill
and intangible assets with indefinite lives are not amortized. Rather, they are tested for impairment at least annually or sooner whenever events or changes in circumstances
indicate that they may be impaired. We perform our goodwill impairment tests during the fourth quarter of each year and between annual tests in certain circumstances.

[0001047469-12-002283:mdna:91]
To
perform the goodwill impairment test, we determine the fair value of the reporting unit and compare the fair value to the reporting unit's carrying value. We believe we are one
reporting unit, and therefore, we compare our fair value to the total net asset value on our balance sheet. If our total net asset value were to exceed our fair value, we would perform the second step
of the impairment test. In
the second step, we would compare the implied fair value of our goodwill to our carrying amount, taking a write-down to the extent the carrying amount exceeds the implied fair value. If
our fair value exceeds the carrying value of our net assets under step one, then no impairment is indicated and the test is complete.

[0001047469-12-002283:mdna:92]
We
passed the first step of our annual impairment test for 2011. In addition, there were no indicators of impairment as of December 31, 2011.

[0001047469-12-002283:mdna:93]
We
continually monitor events and changes in circumstances that could indicate carrying amounts of long-lived assets may not be recoverable. We review long-lived
assets and certain purchased intangibles for impairment whenever events or changes in circumstances indicate that we will not be able to recover the asset's carrying amount. Recoverability of an asset
is measured by comparing its carrying amount to the expected future undiscounted cash flows expected to result from the use and eventual disposition of that asset, excluding future interest costs that
would be recognized as an expense when incurred. Any impairment to be recognized is measured by the amount by which the carrying amount of the asset exceeds its fair market value. Significant
management judgment is required in:

[0001047469-12-002283:mdna:94]
•

[0001047469-12-002283:mdna:95]
identifying a triggering event that arises from a change in circumstances;

[0001047469-12-002283:mdna:96]
•

[0001047469-12-002283:mdna:97]
forecasting future operating results; and

[0001047469-12-002283:mdna:98]
•

[0001047469-12-002283:mdna:99]
estimating the proceeds from the disposition of long-lived or intangible assets.

[0001047469-12-002283:mdna:100]
In
future periods, material impairment charges could be necessary should different conditions prevail or different judgments be made.

[0001047469-12-002283:mdna:101]
Significant
management judgment is also required for initial recognition and measurement of goodwill and other intangibles assets resulting from business combinations pursuant ASC 805.
Management must assess the extent to which identified other intangibles assets are properly includable (and with the appropriate fair value) or properly excludable, by applying the recognition
criteria. This judgment affects not only the other intangible assets but the remainder calculation of goodwill. The assessment of useful life for each acquired intangible impacts future financial
position and operating performance through amortization expense.

[0001047469-12-002283:mdna:102]
Inventory.    Inventories are stated at the lower of cost, utilizing standard costs, applying the first-in, first-out method, or
market. We routinely assess our on-hand inventory for timely identification and measurement of obsolete, slow-moving or otherwise impaired inventory. We write down inventory
for estimated obsolescence, excess or unmarketable quantities equal to the difference between the cost of the inventory and its estimated market value based on assumptions about future demand and
market conditions. If actual future demand or market conditions are less favorable than we projected, additional inventory write-downs may be required.

[0001047469-12-002283:mdna:103]
Valuation of share-based awards.    We account for share-based compensation in accordance with ASC 718, Stock
Compensation. We estimate the fair value of our employee stock awards at the date of grant using certain subjective assumptions, such as expected volatility which is based on a
combination of historical and market-based implied volatility, and the expected term of the awards, which is based on our historical experience of employee stock option exercises, including
forfeitures. The valuation assumptions we use in estimating the fair value of employee share-based awards may change in future periods. We recognize the fair value of awards over their vesting period
or requisite service period. In addition, we calculate our pool of excess tax benefits available within additional paid-in capital in accordance with the provisions of ASC 718.

[0001047469-12-002283:mdna:104]
Accounting for income taxes.    We record a tax provision for the anticipated tax consequences of the reported results of operations. In
accordance with
GAAP, the provision for income taxes is computed using the asset and liability method, under which deferred tax assets and liabilities are recognized for the expected future tax consequences of
temporary differences between the financial reporting and tax bases of assets and liabilities, and for operating losses and tax credit carry-forwards. Deferred tax assets and liabilities are measured
using the enacted tax rates expected to apply to taxable income in the periods in which those tax assets and liabilities are expected to be realized or settled. In the event that these tax rates
change, we will incur a benefit or detriment on our income tax expense in the period of change. If we were to determine that all or part of the net deferred tax assets are not

[0001047469-12-002283:mdna:105]
realizable
in the future, we will record a valuation allowance that would be charged to earnings in the period such determination is made.

[0001047469-12-002283:mdna:106]
In
accordance with ASC 740, Income Taxes, we recognize the tax benefit from an uncertain tax position if it is more likely than not that
the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such positions
are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement. The calculation of tax liabilities involves significant judgment in
estimating the impact of uncertainties in the application of GAAP and complex tax laws. Resolution of these uncertainties in a manner inconsistent with management's expectations could have a material
impact on our financial condition and operating results.

[0001047469-12-002283:mdna:107]
Remediation of Prior Year Material Weakness in Internal Control Over Financial Reporting

[0001047469-12-002283:mdna:108]
As previously disclosed in our Annual Report on Form 10-K for the year ended December 31, 2010 and our
quarterly reports on Form 10-Q for the quarters ended September 30, 2011, June 30, 2011 and March 31, 2011, our management concluded that our internal control
over financial reporting, relating to our financial statement close process, was not effective as of December 31, 2010. Our management concluded that, as of December 31, 2010, our
internal control over financial reporting was not effective in providing reasonable assurance that a material misstatement of our financial statements would be prevented or detected on a timely basis.
Our evaluation concluded that we had a material weakness related to accounting for income taxes. Specifically, our processes, procedures and controls related to the preparation and review of the
annual income tax provision were not effective to ensure that amounts recorded for the income tax provision and the related current and deferred income tax asset and liability accounts were accurate
and determined in accordance with U.S. generally accepted accounting principles. Additionally, we did not maintain effective controls over the review and analysis of supporting work papers for such
income tax balances.

[0001047469-12-002283:mdna:109]
During
fiscal 2011, we implemented the following remediation actions designed to address this material weakness:

[0001047469-12-002283:mdna:110]
•

[0001047469-12-002283:mdna:111]
Hired a Senior Tax Manager with knowledge and experience in relevant technical areas;

[0001047469-12-002283:mdna:112]
•

[0001047469-12-002283:mdna:113]
Re-assessed the relationship with our third-party tax consultant to ensure that there is an adequate level of
review of the tax provision performed by the consultant and an appropriate level of oversight and validation by our management;

[0001047469-12-002283:mdna:114]
•

[0001047469-12-002283:mdna:115]
Ensured our internal review processes are carefully executed and the documentation management or version control is
monitored to properly account for changes to the files used for calculation and review of the income tax provision and related balance sheet income tax accounts; and

[0001047469-12-002283:mdna:116]
•

[0001047469-12-002283:mdna:117]
Implemented a more extensive reconciliation process to support our computation of our income tax provision and related
balance sheet income tax accounts, provided more supervision and performed a more thorough review of the work performed by the tax personnel.

[0001047469-12-002283:mdna:118]
We
believe these actions have strengthened our internal control over financial reporting and addressed the material weakness identified above. Based on our testing of these enhanced
procedures, management determined that, as of December 31, 2011, we have remediated the material weakness in internal control over financial reporting as disclosed in the Annual Report on
Form 10-K for December 31, 2010.

[0001047469-12-002283:mdna:119]
Recently Issued and Adopted Accounting Standards

[0001047469-12-002283:mdna:120]
In May 2011, the Financial Accounting Standards Board, or the FASB, issued Accounting Standards Update, or ASU, 2011-04,  Fair Value Measurement, which amends the fair value guidance in ASC 820, thereby completing the joint project to achieve substantially converged fair
value measurement and disclosure requirements for U.S. GAAP and International Financial Reporting Standards , or IFRS. The new guidance changes some fair value measurement principles (such as
extending the Level 1 prohibition of blockage discounts to Levels 2 and 3 in the fair value hierarchy) and expands disclosure requirements, primarily for Level 3 measurements.
This update will be effective for us the first quarter of 2012, applied prospectively with no early adoption permitted. We do not anticipate the requirements of the update will have any significant
impact on our financial position, operating results or cash flows.

[0001047469-12-002283:mdna:121]
In
June 2011, the FASB issued ASU 2011-05, Presentation of Comprehensive Income. This ASU prohibits equity statement
presentation of other comprehensive income, requiring instead either a single continuous operating statement or two separate, but consecutive, statements of net income and other comprehensive income.
The new guidance does not change which components of comprehensive income are recognized in net income or other comprehensive income, or when an item of other comprehensive income must be reclassified
to net income. Also, the earnings-per-share computation based on net income does not change. In December 2011, the FASB issued ASU 2011-12,  Deferral of the Effective Date for Amendments to the Presentation of Reclassifications
of Items Out of Accumulated Other Comprehensive Income in Accounting Standards Update
No. 2011-05, in order to redeliberate the portion of the earlier ASU relating to presentation of reclassifications from other comprehensive income. Both
updates are required for us the first quarter of 2012, applied retrospectively. We have opted for the permitted early adoption, applied retrospectively, of both updates in this Annual Report on
Form 10-K for the year ended December 31, 2011. As ASU 2011-05 and ASU 2011-12 are only presentation standards, their adoption did not have any impact
on our financial position, operating results or cash flows.

[0001047469-12-002283:mdna:122]
In
September 2011, the FASB issued ASU 2011-08, Testing Goodwill for Impairment, giving entities the option to determine
qualitatively whether they can bypass the two-step goodwill impairment test in ASC 350-20, Intangibles, Goodwill and Other.
Under the new guidance, if an entity chooses to perform a qualitative assessment and determines that it is more likely than not (more than 50% likelihood) that the fair value of a reporting unit is
less than its carrying amount, it would then perform Step 1 of the annual goodwill impairment test and, if necessary, proceed to Step 2. Otherwise, no further evaluation would be necessary. Each
reporting period, the entity may choose which reporting units, if any, will use the qualitative assessment for goodwill impairment testing. This update will be effective for us for any 2012 goodwill
impairment tests, with early adoption permitted. We do not anticipate the requirements of the update will have any significant impact on our financial position, operating results or cash flows, as we
currently apply the existing Step 1 test for our single-reporting unit business.

[0001047469-12-002283:mdna:123]
45

[0001047469-12-002283:mdna:124]
Results of Operations

[0001047469-12-002283:mdna:125]
|  |  | Years Ended December 31, |  |
|  |  | 2011 |  | % of Revenue |  | 2010 |  | % of Revenue |  | 2009 |  | % of Revenue |  |
|  |  | (in thousands, except percentages) |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product revenues |  | $ | 185,864 |  |  | 75.7 | % | $ | 171,100 |  |  | 76.9 | % | $ | 170,068 |  |  | 79.7 | % |
| Service and other revenues |  |  | 59,671 |  |  | 24.3 | % |  | 51,307 |  |  | 23.1 | % |  | 43,389 |  |  | 20.3 | % |
| Total revenues |  |  | 245,535 |  |  | 100.0 | % |  | 222,407 |  |  | 100.0 | % |  | 213,457 |  |  | 100.0 | % |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product revenues |  |  | 79,567 |  |  | 32.4 | % |  | 76,372 |  |  | 34.3 | % |  | 80,016 |  |  | 37.5 | % |
| Cost of service and other revenues |  |  | 30,184 |  |  | 12.3 | % |  | 28,079 |  |  | 12.7 | % |  | 27,011 |  |  | 12.7 | % |
| Restructuring charges |  |  | — |  |  | — | % |  | 39 |  |  | 0.0 | % |  | 1,209 |  |  | 0.6 | % |
| Total cost of revenues |  |  | 109,751 |  |  | 44.7 | % |  | 104,490 |  |  | 47.0 | % |  | 108,236 |  |  | 50.7 | % |
| Gross profit |  |  | 135,784 |  |  | 55.3 | % |  | 117,917 |  |  | 53.0 | % |  | 105,221 |  |  | 49.3 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 22,042 |  |  | 9.0 | % |  | 21,007 |  |  | 9.4 | % |  | 17,569 |  |  | 8.2 | % |
| Selling, general and administrative |  |  | 97,520 |  |  | 39.7 | % |  | 86,227 |  |  | 38.8 | % |  | 85,668 |  |  | 40.2 | % |
| Restructuring charges |  |  | — |  |  | — | % |  | 1,157 |  |  | 0.5 | % |  | 1,315 |  |  | 0.6 | % |
| Total operating expenses |  |  | 119,562 |  |  | 48.7 | % |  | 108,391 |  |  | 48.7 | % |  | 104,552 |  |  | 49.0 | % |
| Income from operations |  |  | 16,222 |  |  | 6.6 | % |  | 9,526 |  |  | 4.3 | % |  | 669 |  |  | 0.3 | % |
| Interest and other income (expense), net |  |  | (133 | ) |  | (0.1 | )% |  | 431 |  |  | 0.2 | % |  | 523 |  |  | 0.3 | % |
| Income before provision for income taxes |  |  | 16,089 |  |  | 6.5 | % |  | 9,957 |  |  | 4.5 | % |  | 1,192 |  |  | 0.6 | % |
| Provision for income taxes |  |  | 5,700 |  |  | 2.3 | % |  | 5,065 |  |  | 2.3 | % |  | 748 |  |  | 0.4 | % |
| Net income |  | $ | 10,389 |  |  | 4.2 | % | $ | 4,892 |  |  | 2.2 | % | $ | 444 |  |  | 0.2 | % |

[0001047469-12-002283:mdna:126]
Product Revenues, Cost of Product Revenues and Gross Profit

[0001047469-12-002283:mdna:127]
The table below shows our product revenues, cost of product revenues and gross profit for the years ended December 31, 2011,
2010 and 2009 and the percentage change between those years:

[0001047469-12-002283:mdna:128]
|  |  | Years Ended December 31, |  | Percentage Change |  |
|  |  | 2010 to 2011 |  | 2009 to 2010 |  |
|  |  | 2011 |  | 2010 |  | 2009 |  |
|  |  | (in thousands) |  |  |  |  |  |
| Product revenues |  | $ | 185,864 |  | $ | 171,100 |  | $ | 170,068 |  |  | 8.6 | % |  | 0.6 | % |
| Cost of product revenues |  |  | 79,567 |  |  | 76,372 |  |  | 80,016 |  |  | 4.2 | % |  | (4.6 | )% |
| Restructuring charges |  |  | — |  |  | — |  |  | 1,008 |  |  | n/a |  |  | (100.0 | )% |
| Gross profit |  | $ | 106,297 |  | $ | 94,728 |  | $ | 89,044 |  |  | 12.2 | % |  | 6.4 | % |

[0001047469-12-002283:mdna:129]
2011 compared to 2010

[0001047469-12-002283:mdna:130]
Product revenues increased $14.8 million, or 8.6%, in 2011 as compared to 2010. Our ability to grow revenue is dependent on our
ability to continue to obtain orders from customers, the volume of installations we are able to complete, our ability to meet customer needs and provide a quality

[0001047469-12-002283:mdna:131]
installation
experience and our flexibility in manpower allocations among customers to complete installations on a timely basis. The timing of our product revenues is primarily dependent on when our
customers' schedules allow for installations. The overall increase in product revenues was driven by a combination of increased installations of our new automation products, increases in lease
renewals from existing customers and a full year of revenues derived from our acquisition of Pandora at the end of the third quarter of 2010. We anticipate our revenues will continue to increase in
2012 at approximately 7% to 8%, as we fulfill our existing orders and as we experience a continued high volume of lease renewals that were initiated in 2007.

[0001047469-12-002283:mdna:132]
Cost
of product revenues increased by $3.2 million, or 4.2%, in 2011 as compared to 2010. The increase was primarily a function of revenue growth, partially offset by the
favorable impact of overall product mix and generally lower material costs from our cost reduction efforts during the year. Additionally, during the year we incurred higher product costs related to
the manufacturing cost of the new G4 cabinet console platform, released on May 2, 2011. The early production units of the G4 cabinet console were at a higher product cost than our previous
generation product. This was due to initial production line ramp up and longer production cycles to validate the manufacturability and quality of the new console. The majority of the higher production
line cost was absorbed in the three months ended September 30, 2011 and December 31, 2011. The future cost of product revenues are expected to be more reflective of the previous
generation product, net of any product mix effects.

[0001047469-12-002283:mdna:133]
Gross
profit on product revenue increased by $11.6 million, or 12.2%, in 2011 as compared to 2010 and gross profit as a percentage of product revenues increased to 57.2% in 2011
as compared to 55.4% in
2010. The increase was the result of the previously discussed increase in revenue by 8.6% over the prior year with lower than proportionate increases in related costs by 4.2% over the prior year
primarily as a result of lower material costs due to product mix and from our cost reduction efforts. For 2012, we do not anticipate any significant fluctuations in our gross margin beyond normal
fluctuations caused by changes in product mix.

[0001047469-12-002283:mdna:134]
2010 compared to 2009

[0001047469-12-002283:mdna:135]
Product revenues remained nearly flat in 2010 as compared to 2009.

[0001047469-12-002283:mdna:136]
Cost
of product revenues decreased by $3.6 million, or 4.6%, in 2010 as compared to 2009. The decrease was primarily due to a $1.0 million charge to record an inventory reserve in
the first quarter of 2009 which did not recur in 2010, a $0.4 million favorable timing effect on expenses due to a reduction in accrued vacation in the second quarter of 2010, the overall favorable
shift in product mix to products with lower associated costs along with the favorable results of outsourcing initiatives, ongoing cost reduction programs and general operational efficiencies.

[0001047469-12-002283:mdna:137]
Gross
profit on product revenue increased by $5.7 million, or 6.4%, in 2010 as compared to 2009, primarily as a result of lower product costs. Gross margin as a percent of
revenues was 55.4%, compared to 52.4% in 2009. Product gross margin increased 3.0% due to the aforementioned $1.0 million inventory reserve recorded in the first quarter of 2009 which did not recur in
2010, a $1.0 million restructuring charge in the first quarter of 2009, a $0.4 million favorable timing effect on expenses due to a reduction in accrued vacation in the second quarter of 2010 and the
overall favorable shift in product mix to revenues with lower associated costs along with the favorable results of outsourcing initiatives, ongoing cost reduction programs, and general operational
efficiencies.

[0001047469-12-002283:mdna:138]
Service and Other Revenues, Cost of Service and Other Revenues and Gross Profit

[0001047469-12-002283:mdna:139]
Service and other revenues include revenues from service and maintenance contracts and rentals of automation systems. The table below
shows our service and other revenues, cost of service and other

[0001047469-12-002283:mdna:140]
revenues
and gross profit for the years ended December 31, 2011, 2010 and 2009 and the percentage change between those years:

[0001047469-12-002283:mdna:141]
|  |  | Years Ended December 31, |  | Percentage Change |  |
|  |  | 2010 to 2011 |  | 2009 to 2010 |  |
|  |  | 2011 |  | 2010 |  | 2009 |  |
|  |  | (in thousands) |  |  |  |  |  |
| Service and other revenues |  | $ | 59,671 |  | $ | 51,307 |  | $ | 43,389 |  |  | 16.3 | % |  | 18.2 | % |
| Cost of service and other revenues |  |  | 30,184 |  |  | 28,079 |  |  | 27,011 |  |  | 7.5 | % |  | 4.0 | % |
| Restructuring charges |  |  | — |  |  | 39 |  |  | 201 |  |  | (100.0 | )% |  | (80.6 | )% |
| Gross profit |  | $ | 29,487 |  | $ | 23,189 |  | $ | 16,177 |  |  | 27.2 | % |  | 43.3 | % |

[0001047469-12-002283:mdna:142]
2011 compared to 2010

[0001047469-12-002283:mdna:143]
Service and other revenues increased by $8.4 million, or 16.3%, in 2011 as compared to 2010. The increase in service and other
revenues was primarily the result of an expansion in our installed base of automation systems and a resulting increase in the number of support service contracts.

[0001047469-12-002283:mdna:144]
Cost
of service and other revenues increased by $2.1 million, or 7.5%, in 2011 as compared to 2010. The increase was primarily due to an increase in spending related to salaries
and benefits associated with higher headcount and spare parts expense in support of the expanded service base.

[0001047469-12-002283:mdna:145]
Gross
profit on service and other revenues increased by $6.3 million, or 27.2%, in 2011 as compared to 2010. This increase was due to increased revenues from an expanded installed
base without proportional growth in service cost.

[0001047469-12-002283:mdna:146]
We
expect our service and other revenues and the associated gross profit to continue to increase in 2012 at a similar rate with the continued expansion of our installed base of
automation systems and service and maintenance contracts.

[0001047469-12-002283:mdna:147]
2010 compared to 2009

[0001047469-12-002283:mdna:148]
Service and other revenues increased by $7.9 million, or 18.2%, in 2010 as compared to 2009. The increase was primarily due to
normal growth on an expanded installed base, as well as later than expected receipts of customer purchase orders for service contracts covering service periods starting in 2009, for which service
revenues were recognized retrospectively from their commencement dates.

[0001047469-12-002283:mdna:149]
Cost
of service and other revenues increased by $1.1 million, or 4.0%, in 2010 as compared to 2009. The increase was primarily due to an increase in spending of $1.0 million
primarily related to salaries and related benefits costs and replacement part costs in support of the expanded service base.

[0001047469-12-002283:mdna:150]
Gross
profit on service and other revenues increased by $7.0 million, or 43.3%, in 2010 as compared to 2009. The increase in gross margin on service and other revenues was due to
the aforementioned revenue growth from service contracts initiated in 2009 with purchase orders received in 2010 and from normal growth on an expanded installed base without a proportional growth in
service costs as these were incurred in prior periods.

[0001047469-12-002283:mdna:151]
Operating Expenses

[0001047469-12-002283:mdna:152]
The table below shows our operating expenses for the years ended December 31, 2011, 2010 and 2009 and the percentage change
between those years:

[0001047469-12-002283:mdna:153]
|  |  | Years Ended December 31, |  | Percentage Change |  |
|  |  | 2010 to 2011 |  | 2009 to 2010 |  |
|  |  | 2011 |  | 2010 |  | 2009 |  |
|  |  | (in thousands) |  |  |  |  |  |
| Research and development |  | $ | 22,042 |  | $ | 21,007 |  | $ | 17,569 |  |  | 4.9 | % |  | 19.6 | % |
| Selling, general and administrative |  |  | 97,520 |  |  | 86,227 |  |  | 85,668 |  |  | 13.1 | % |  | 0.7 | % |
| Restructuring charges |  |  | — |  |  | 1,157 |  |  | 1,315 |  |  | (100.0 | )% |  | (12.0 | )% |
| Total operating expenses |  | $ | 119,562 |  | $ | 108,391 |  | $ | 104,552 |  |  | 10.3 | % |  | 3.7 | % |

[0001047469-12-002283:mdna:154]
2011 compared to 2010

[0001047469-12-002283:mdna:155]
Research and development.    Research and development expenses increased by $1.0 million, or 4.9%, in 2011 as compared to 2010. Research
and development
expenses represented 9.0% and 9.4% of total revenues in 2011 and 2010, respectively. The increase was due primarily to a $3.1 million increase in compensation costs and $1.0 million in other
increases, partially offset by decreases of $0.6 million in tools and $0.4 million in outside services. Additional offset was provided by the capitalization of software development costs, increasing
to $4.2 million in 2011 as compared to $2.2 million in 2010 due to the higher level of post-feasibility beta testing that preceded several new product introductions in the
second quarter of 2011.

[0001047469-12-002283:mdna:156]
We
expect research and development expenses to increase slightly in 2012 as we continue to invest in new products and services. The amount of research and development expense can
fluctuate based on the amount of prototype expenses for hardware and or the amount of capitalized software development costs in any given quarter.

[0001047469-12-002283:mdna:157]
Selling, general and administrative.    Selling, general and administrative expenses increased by $11.3 million, or 13.1%, in 2011 as
compared to 2010.
Selling, general and administrative expenses represented 39.7% and 38.8% of total revenues in 2011 and 2010, respectively.

[0001047469-12-002283:mdna:158]
This
increase was primarily due to a $5.0 million increase in compensation costs related to increased sales and marketing staffing, a $1.0 million increase for the settlement of
litigation with Medacist Solutions Group LLC, as described in Note 13 "Legal Proceedings" of the Notes to Consolidated Financial Statements of this Annual Report on
Form 10-K , and a $2.9 million increase in freight, travel, promotional expenses and other costs. Reduced outside service and other spending of $0.6 million partially offset
these increases. Additionally, 2010 expenses were reduced by the $2.4 million benefit from the settlement of a litigation claim with Flo Healthcare LLC in the third quarter of 2010 for less
than the amount previously accrued, as described in our Annual Report on
Form 10-K for the year ended December 31, 2010, and $0.9 million resulting from the favorable timing effect on expenses due to a reduction in accrued vacation.

[0001047469-12-002283:mdna:159]
We
anticipate selling, general and administrative expenses as a percent of revenues to stabilize and reduce throughout 2012 as we have aligned our sales efforts and cost structure to the
current economic and market environments and anticipate a reduction in legal expenses.

[0001047469-12-002283:mdna:160]
2010 compared to 2009

[0001047469-12-002283:mdna:161]
Research and development.    Research and development expenses increased by $3.4 million, or 19.6%, in 2010 as compared to 2009.
Research and
development expenses represented 9.4% and 8.2% of total revenues in 2010 and 2009, respectively.

[0001047469-12-002283:mdna:162]
The
increase in research and development expenses in 2010 was due to an increase of $1.9 million in consulting expenses, an increase of $0.7 million of labor and related costs,
both of which are related to new hardware and software product development, and a decrease of $0.8 million of software capitalization in 2010 compared to 2009 primarily due the release in 2010
of two major software releases used in our products.

[0001047469-12-002283:mdna:163]
Selling, general and administrative.    Selling, general and administrative expenses increased by $0.6 million, or 0.7%, in 2010 as
compared to 2009.
Selling, general and administrative expenses represented 38.8% and 40.2% of total revenues in 2010 and 2009, respectively.

[0001047469-12-002283:mdna:164]
Three
areas of spending increased the selling, general and administrative expenses. These were $1.9 million of fees related to potential acquisition assessment activities,
$1.3 million related to marketing programs to increase brand awareness, and $2.4 million associated with rising costs of operations. This
increase in operations costs includes $1.0 million in employee health and dental benefits, $0.5 million in GPO fees associated with higher sales volume
to GPO-affiliated customers and $0.4 million in travel. These increases were offset by a decrease of $2.9 million in legal fees, which included a $2.4 million benefit
from the settlement of a litigation claim with Flo Healthcare LLC in the third quarter of 2010 for less than the amount previously accrued and a decrease of bad debt expense of
$1.7 million primarily due to the recovery of a fully reserved accounts receivable balance and lower non-specific bad debt reserve requirements based on improved historical experience.

[0001047469-12-002283:mdna:165]
Restructuring charges.    Restructuring charges of $1.2 million incurred in 2010 related to the closure of facilities in The
Woodlands, Texas and
Bangalore, India. Costs recorded related primarily to severance and relocation pay, lease terminations, asset impairment charges, consulting and travel. Restructuring charges of $1.3 million
incurred in 2009 related primarily to severance pay, continuation of benefits and outplacement services associated with reduction in force activities.

[0001047469-12-002283:mdna:166]
Interest Income and Other Expense

[0001047469-12-002283:mdna:167]
The table below shows our interest income and other expense for the years ended December 31, 2011, 2010 and 2009 and the
percentage change between those years:

[0001047469-12-002283:mdna:168]
|  |  | Years Ended December 31, |  | Percentage Change |  |
|  |  | 2010 to 2011 |  | 2009 to 2010 |  |
|  |  | 2011 |  | 2010 |  | 2009 |  |
|  |  | (in thousands) |  |  |  |  |  |
| Interest income |  | $ | 266 |  | $ | 424 |  | $ | 619 |  |  | (37.3 | )% |  | (31.5 | )% |
| Interest expense |  |  | (62 | ) |  | (4 | ) |  | (15 | ) |  | n/a |  |  | (73.3 | )% |
| Other income (expense) |  |  | (337 | ) |  | 11 |  |  | (81 | ) |  | n/a |  |  | n/a |  |

[0001047469-12-002283:mdna:169]
2011 compared to 2010

[0001047469-12-002283:mdna:170]
Although cash, cash equivalents and short-term investments increased by $16.1 million during 2011, continued
reduction in interest rates resulted in a 37.3% decline in interest income earned. The weighted average interest rate of 0.07% in the fourth quarter 2011 compares with 0.18% in the fourth quarter
2010.

[0001047469-12-002283:mdna:171]
Interest
expense was larger in 2011 than 2010, primarily due to installment interest payments on a disputed county property tax issue. Other income, negligible in 2010, reversed to
$0.3 million other expense, primarily for effects of exchange rate changes between Indian rupees and U.S. dollars.

[0001047469-12-002283:mdna:172]
We
expect interest income to remain at approximately 2011 levels during 2012.

[0001047469-12-002283:mdna:173]
2010 compared to 2009

[0001047469-12-002283:mdna:174]
The decrease in interest income for 2010 as compared to 2009 was primarily due to lower interest rates. Although average cash, cash
equivalents and short-term investment balances averaged approximately $45.0 million higher in 2010, average interest rates decreased by 25 basis points compared to 2009 rates,
resulting in $0.2 million lower interest income.

[0001047469-12-002283:mdna:175]
Income Taxes

[0001047469-12-002283:mdna:176]
|  |  | Years Ended December 31, |  |
|  |  | 2011 |  | 2010 |  | 2009 |  |
|  |  | (in thousands) |  |
| Provision for income taxes |  | $ | 5,700 |  | $ | 5,065 |  | $ | 748 |  |

[0001047469-12-002283:mdna:177]
We
recorded a provision for income taxes of approximately $5.7 million and an effective tax rate of 35.43% for the year ended December 31, 2011 compared to
$5.1 million and 50.8% effective tax rate for the year ended December 31, 2010. The 2011 annual tax rate differed from the statutory tax rate of 35%, primarily due to the negative impact
of state income taxes, non-deductible equity charges under ASC 740-718 and non-deductible meals and entertainment expense, which were partially offset by the
benefit of research and development expenditures and the domestic production activity deduction pursuant to Section 199 of the Internal Revenue Code. The decrease in the effective tax rate as
compared to 2010 was primarily a result of the one-time tax adjustment in 2010 for the tax effect of undistributed earnings. The decrease is also attributable to the domestic production
activities deduction, which was not available in 2010, and to a one-time true up to reserves for R&D tax credits that was recorded in 2010.

[0001047469-12-002283:mdna:178]
We
recorded a provision for income taxes of approximately $5.1 million and an effective tax rate of 50.8% for the year ended December 31, 2010 compared to
$0.7 million and 62.8% effective tax rate for the year ended December 31, 2009. The decrease in the effective tax rate was primarily due to the impact of state income taxes and due to a
larger income base upon which to calculate certain permanent items.

[0001047469-12-002283:mdna:179]
Refer
to Note 14 "Income Taxes" to the Notes to Consolidated Financial Statements included in the Annual Report on Form 10-K for discussion of factors affecting
realizability of deferred tax assets.

[0001047469-12-002283:mdna:180]
Liquidity and Capital Resources

[0001047469-12-002283:mdna:181]
Cash Flows

[0001047469-12-002283:mdna:182]
The table below shows our cash flows for the years ended December 31, 2011, 2010 and 2009:

[0001047469-12-002283:mdna:183]
|  |  | Years Ended December 31, |  |
|  |  | 2011 |  | 2010 |  | 2009 |  |
|  |  | (in thousands) |  |
| Net cash provided by operating activities |  | $ | 31,243 |  | $ | 20,598 |  | $ | 46,271 |  |
| Net cash used in investing activities |  |  | (13,066 | ) |  | (23,057 | ) |  | (6,795 | ) |
| Net cash (used in) provided by financing activities |  |  | (1,840 | ) |  | 8,863 |  |  | 9,417 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (210 | ) |  | 1 |  |  | (102 | ) |
| Net increase in cash and cash equivalents |  | $ | 16,127 |  | $ | 6,405 |  | $ | 48,791 |  |

[0001047469-12-002283:mdna:184]
2011 compared to 2010

[0001047469-12-002283:mdna:185]
Net cash provided by operating activities.    Net cash provided by operating activities increased by $10.6 million in 2011 to
$31.2 million from $20.6 million in 2010. The major drivers increasing operating cash flow were $5.5 million higher net income and $7.2 million increased cash from accounts
receivable. Other sources of cash were balance sheet changes in prepaid expenses recorded as current assets, deferred gross profit, accrued liabilities and deferred service revenues, increasing
$4.6 million, $4.5 million, $1.8 million and $1.2 million, respectively, in operating cash flows in 2011 compared to 2010. Partially offsetting these increases in sources
of operating cash flows were the $9.5 million net increase in inventory to support our G4 product launch and the net reduction of $5.1 million in accounts payable.

[0001047469-12-002283:mdna:186]
Net cash used in investing activities.    Net cash used in investing activities decreased by $10.0 million in 2011 to
$13.1 million from
$23.1 million in 2010. This decrease was driven by the 2010 acquisition of Pandora Data Systems for $5.7 million, net of cash acquired, and by the purchases of $8.1 million of
California revenue anticipation notes in both 2010 and 2011, of which the notes purchased in 2010 matured in 2011. These decreases were partially offset by the $3.8 million increase in capital
expenditures for software development and property and equipment.

[0001047469-12-002283:mdna:187]
Net cash (used in) provided by financing activities.    Net cash (used in) provided by financing activities decreased by $10.0 million
in 2011 to
$1.8 million net cash used compared to net cash provided by financing activities of $8.9 million in 2010. This was driven by the $12.6 million use of cash for stock repurchases
and $0.2 million from shares issued under stock option and employee stock purchase plans, partially offset by increase of $2.1 million in excess tax benefits from employee stock plans.

[0001047469-12-002283:mdna:188]
2010 compared to 2009

[0001047469-12-002283:mdna:189]
Net cash provided by operating activities.    Net cash provided by operating activities decreased by $25.7 million in 2010 to
$20.6 million from $46.3 million in 2009. The major driver of this decrease was accounts receivable collections returning to normal trends compared to 2009, resulting in a net change
between the years of $18.5 million. Other uses of cash were balance sheet changes in prepaids, accrued liabilities and deferred service revenue, reducing $3.7 million,
$3.8 million and $5.6 million, respectively, of operating cash flows in 2010 compared to 2009. Offsetting these decreases in sources of operating cash flows were higher net income of
$4.4 million and a combination of tax related operating cash flows that increased cash provided by operating activities between 2010 and 2009 by $7.5 million. The most significant tax
related item was a benefit from employee stock plans which changed from a use of operating cash in 2009 to a source of operating cash in 2010 for a net increase of cash provided of
$7.5 million.

[0001047469-12-002283:mdna:190]
Net cash used in investing activities.    Net cash used in investing activities increased by $16.3 million in 2010 to
$23.1 million from
$6.8 million in 2009. This increase was primarily due to purchases of $8.1 million of California revenue anticipation notes and the acquisition of Pandora Data Systems for
$5.7 million, net of cash acquired. Purchases of capital assets increased $2.5 million primarily due to continued efforts in 2010 to increase information technology capabilities,
including a customer relationship management systems installation project.

[0001047469-12-002283:mdna:191]
Net cash provided by financing activities.    Net cash provided by financing activities decreased by $0.5 million in 2010 to
$8.9 million
from $9.4 million in 2009. This was due to an increase in proceeds from shares issued under stock option and employee stock purchase plans of $3.0 million, offset by a decrease of
$3.5 million in excess tax benefits from employee stock plans.

[0001047469-12-002283:mdna:192]
Liquidity

[0001047469-12-002283:mdna:193]
Our future uses of cash are expected to be primarily for working capital, capital expenditures and other contractual obligations. We
also expect a continued use of cash for potential acquisition assessment activities. Additionally, as described in Note 15 "Stockholders' Equity" to the Notes to Consolidated Financial
Statements included in this Annual Report on Form 10-K, on December 31, 2011, we had $12.4 million of remaining authorized funds to
repurchase additional shares under stock repurchase programs, which may, in the future, result in additional use of cash. We had cash and cash equivalents of $191.8 million at
December 31, 2011 as compared to $175.6 million at December 31, 2010. Additionally, we owned $8.1 million of short-term investments at both December 31,
2011 and 2010. Based on our current business plan and revenue backlog, we believe that our existing cash, cash equivalents and our anticipated cash flows from operations as well as cash generated from
the exercise of employee stock options and purchases under our employee stock purchase plan will be sufficient to meet our cash needs for working capital, capital expenditures, acquisitions, and other
contractual obligations for at least the next twelve months. For periods beyond the next twelve months, we also anticipate that our net operating cash flows plus existing balances of cash, cash
equivalents, and short-term investments will suffice to fund the continued growth of our business.

[0001047469-12-002283:mdna:194]
Off-Balance Sheet Arrangements

[0001047469-12-002283:mdna:195]
As of December 31, 2011, we had no off-balance sheet arrangements as defined under Regulation S-K
303(a)(4) of the Securities Exchange Act of 1934, as amended, and the instructions thereto.

[0001047469-12-002283:mdna:196]
Contractual Obligations

[0001047469-12-002283:mdna:197]
As of December 31, 2011 we had $47.4 million in contractual commitments to third parties for non-cancelable
operating leases, commitments to contract manufacturers and suppliers and other purchase commitments. See Note 12, "Commitments," to the Consolidated Financial Statements included in this
Annual Report on Form 10-K for further information with respect to these commitments.

[0001047469-12-002283:mdna:198]
The
following table summarizes our contractual obligations at December 31, 2011 (in thousands):

[0001047469-12-002283:mdna:199]
|  |  | Total |  | Less than one year |  | One to three years |  | Three to five years |  | More than five years |  |
| Operating leases(1)(2) |  | $ | 42,834 |  | $ | 4,220 |  | $ | 7,481 |  | $ | 7,415 |  | $ | 23,718 |  |
| Commitments to contract manufacturers and suppliers(3) |  |  | 4,613 |  |  | 4,613 |  |  | — |  |  | — |  |  | — |  |
| Total(4) |  | $ | 47,447 |  | $ | 8,833 |  | $ | 7,481 |  | $ | 7,415 |  | $ | 23,718 |  |

[0001047469-12-002283:mdna:200]
(1)

[0001047469-12-002283:mdna:201]
Commitments
under operating leases relate primarily to leasehold property and office equipment. Rent expense was $3.3 million, $3.6 million
and $3.5 million for the years ended December 31, 2011, 2010 and 2009, respectively.

[0001047469-12-002283:mdna:202]
(2)

[0001047469-12-002283:mdna:203]
In
October 2011, we entered into a lease agreement for approximately 100,000 square feet of office space. Pursuant to the lease agreement, the landlord will
construct a single, three-story building of rentable space located at 590 Middlefield Road in Mountain View, California which we will subsequently lease. The term of the lease agreement is for a
period of 120 months, expected to commence November 2012, with a base lease commitment of approximately $40.0 million. We have two options to extend the term of the lease agreement at
market rates; both extensions are for an additional 60 month term.

[0001047469-12-002283:mdna:204]
(3)

[0001047469-12-002283:mdna:205]
We
purchase components from a variety of suppliers and use contract manufacturers to provide manufacturing services for our products. During the normal
course of business, we issue purchase orders with estimates of our requirements several months ahead of the delivery dates.

[0001047469-12-002283:mdna:206]
(4)

[0001047469-12-002283:mdna:207]
At
December 31, 2011, we have recorded $1.2 million for uncertain tax positions under long term liabilities, in accordance with
U.S. GAAP, summarized under "Critical Accounting Policies and Estimates" of this Annual Report on Form 10-K. As these liabilities do not reflect actual tax assessments, the
timing and amount of payments we might be required to make will depend upon a number of factors. Accordingly, as the timing and amount of payment cannot be estimated, the $1.2 million of
uncertain tax position liabilities has not been included in the contractual obligations table above.
