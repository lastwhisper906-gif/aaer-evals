# OMCL 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: 4 candidate headings, none whose body matches 'critical audit matter'.


## item_9a

[0001047469-12-002283:item_9a:1]
ITEM 9A.    CONTROLS AND PROCEDURES

[0001047469-12-002283:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0001047469-12-002283:item_9a:3]
Our management, with the participation of our principal executive officer and principal financial officer, evaluated the effectiveness
of our disclosure controls and procedures (as such term is defined in Rules 13a-15(e) and 15d-15(e) under the Securities Exchange Act of 1934, as amended, or the
Exchange Act) as of the end of the period covered by this Annual Report. These disclosure controls and procedures are designed to ensure that the information required to be disclosed by us in this
Annual Report on Form 10-K was (i) recorded, processed, summarized and reported within the time periods specified in the SEC's rules and regulations and
(ii) accumulated and communicated to our management, including our principal executive officer and principal financial officer, to allow timely decisions regarding required disclosure.

[0001047469-12-002283:item_9a:4]
Based
on such evaluation, our principal executive officer and principal financial officer have concluded that, as of December 31, 2011, our disclosure controls and procedures were
effective at the reasonable assurance level.

[0001047469-12-002283:item_9a:5]
Management's Report on Internal Control Over Financial Reporting

[0001047469-12-002283:item_9a:6]
Our management is responsible for establishing and maintaining adequate internal control over financial reporting (as such term is
defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act). Our internal control system is designed to provide
reasonable assurance regarding the preparation and fair presentation of financial statements for external purposes in accordance with U.S. generally accepted accounting principles. All internal
control systems, no matter how well designed, have inherent limitations and can provide only reasonable assurance that the objectives of the internal control system are met.

[0001047469-12-002283:item_9a:7]
Under
the supervision and with the participation of our management, including our principal executive officer and principal financial officer, we conducted an evaluation of the
effectiveness of our internal control over financial reporting as of December 31, 2011 using the criteria for effective internal control over financial reporting as described in "Internal
Control—Integrated Framework," issued by the Committee of Sponsoring Organization of the Treadway Commission. Based on this assessment, management concluded that, as of December 31,
2011, our internal control over financial reporting was effective.

[0001047469-12-002283:item_9a:8]
Our
independent registered public accounting firm, Ernst & Young LLP, has issued its attestation report on our internal control over financial reporting. Their report
follows this Item 9A in this Annual Report on Form 10-K.

[0001047469-12-002283:item_9a:9]
Remediation of Prior Year Material Weakness in Internal Control Over Financial Reporting

[0001047469-12-002283:item_9a:10]
As previously disclosed in our Annual Report on Form 10-K for the year ended December 31, 2010 and our
quarterly reports on Form 10-Q for the quarters ended September 30, 2011, June 30, 2011 and March 31, 2011, our management concluded that our internal control
over financial reporting, relating to our financial statement close process, was not effective as of December 31, 2010. Our management concluded that, as of December 31, 2010, our
internal control over financial reporting was not effective in providing reasonable assurance that a material misstatement of our financial statements would be prevented or detected on a timely basis.
Our evaluation concluded that we had a material weakness related to accounting for income taxes. Specifically, our processes, procedures and controls related to the preparation and review of the
annual income tax provision were not effective to ensure that amounts recorded for the income tax provision and the related current and deferred income tax asset and liability accounts were accurate
and determined in accordance with U.S. generally accepted accounting principles. Additionally, we did not maintain effective controls over the review and analysis of supporting work papers for such
income tax balances.

[0001047469-12-002283:item_9a:11]
During
fiscal 2011, we implemented the following remediation actions designed to address this material weakness:

[0001047469-12-002283:item_9a:12]
•

[0001047469-12-002283:item_9a:13]
Hired a Senior Tax Manager with knowledge and experience in relevant technical areas;

[0001047469-12-002283:item_9a:14]
•

[0001047469-12-002283:item_9a:15]
Re-assessed the relationship with our third-party tax consultant to ensure that there is an adequate level of
review of the income tax provision performed by the consultant and an appropriate level of oversight and validation by our management;

[0001047469-12-002283:item_9a:16]
•

[0001047469-12-002283:item_9a:17]
Ensured the internal review processes are carefully executed and the documentation management or version control is
monitored to properly account for changes to the files used for calculation and review of the income tax provision and related balance sheet income tax accounts; and

[0001047469-12-002283:item_9a:18]
•

[0001047469-12-002283:item_9a:19]
Implemented a more extensive reconciliation process to support our computation of our income tax provision and related
balance sheet income tax accounts, provided more supervision and performed a more thorough review of the work performed by the tax personnel.

[0001047469-12-002283:item_9a:20]
We believe these actions have strengthened our internal control over financial reporting and addressed the material weakness identified above. Based on our
testing of these enhanced procedures, management determined that, as of December 31, 2011, we have remediated the material weakness in internal control over financial reporting as disclosed in
the Annual Report on Form 10-K for December 31, 2010.

[0001047469-12-002283:item_9a:21]
Changes in Internal Control Over Financial Reporting

[0001047469-12-002283:item_9a:22]
Other than as described above, there have been no changes in our internal control over financial reporting (as such term is defined in
Rules 13a-15(f) and 15d-15(f) under the Exchange Act) during the three months ended December 31, 2011 that have materially affected, or are reasonably likely to
materially affect, our internal control over financial reporting.

[0001047469-12-002283:item_9a:23]
Attestation Report of the Registered Public Accounting Firm

[0001047469-12-002283:item_9a:24]
The report required by this item is set forth below:

[0001047469-12-002283:item_9a:25]
REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

[0001047469-12-002283:item_9a:26]
The Board of Directors and Stockholders of Omnicell, Inc.

[0001047469-12-002283:item_9a:27]
We have audited Omnicell, Inc.'s internal control over financial reporting as of December 31, 2011, based on criteria
established in Internal Control—Integrated Framework issued by the Committee of Sponsoring Organizations of the Treadway Commission (the COSO criteria). Omnicell, Inc.'s management
is responsible for maintaining effective internal control over financial reporting, and for its assessment of the effectiveness of internal control over financial reporting included in the
accompanying Management's Report on Internal Control Over Financial Reporting. Our responsibility is to express an opinion on the company's internal control over financial reporting based on our
audit.

[0001047469-12-002283:item_9a:28]
We
conducted our audit in accordance with the standards of the Public Company Accounting Oversight Board (United States). Those standards require that we plan and perform the audit to
obtain reasonable assurance about whether effective internal control over financial reporting was maintained in all material respects. Our audit included obtaining an understanding of internal control
over financial reporting, assessing the risk that a material weakness exists, testing and evaluating the design and operating effectiveness of internal control based on the assessed risk, and
performing such other procedures as we considered necessary in the circumstances. We believe that our audit provides a reasonable basis for our opinion.

[0001047469-12-002283:item_9a:29]
A
company's internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of
financial statements for external purposes in accordance with generally accepted accounting principles. A company's internal control over financial reporting includes those policies and procedures
that (1) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (2) provide
reasonable assurance that transactions are
recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only
in accordance with authorizations of management and directors of the company; and (3) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use or
disposition of the company's assets that could have a material effect on the financial statements.

[0001047469-12-002283:item_9a:30]
Because
of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future
periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001047469-12-002283:item_9a:31]
In
our opinion, Omnicell Inc., maintained, in all material respects, effective internal control over financial reporting as of December 31, 2011, based on the COSO
criteria.

[0001047469-12-002283:item_9a:32]
We
also have audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States), the consolidated balance sheets of Omnicell, Inc. as of
December 31, 2011 and 2010, and the related consolidated statements of operations, comprehensive income, stockholders' equity, and cash flows for each of the three years in the period ended
December 31, 2011 of Omnicell Inc., and our report dated March 8, 2012 expressed an unqualified opinion thereon.

[0001047469-12-002283:item_9a:33]
/s/
Ernst & Young LLP

[0001047469-12-002283:item_9a:34]
San
Jose, California

[0001047469-12-002283:item_9a:35]
March 8, 2012
