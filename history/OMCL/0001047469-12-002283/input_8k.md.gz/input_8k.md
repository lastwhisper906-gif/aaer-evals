# OMCL 8-K — 0001104659-12-004244 filed 2012-01-26

## item codes, every 8-K on or before 2012-03-08

- 2012-02-13 0001104659-12-009353 — 5.02, 9.01
- 2012-01-26 0001104659-12-004244 — 2.02, 9.01
- 2011-10-27 0001104659-11-058464 — 2.02, 9.01
- 2011-10-25 0001104659-11-057721 — 1.01
- 2011-07-28 0001104659-11-041505 — 2.02, 9.01
- 2011-05-27 0001104659-11-032006 — 5.07
- 2011-05-02 0001104659-11-024908 — 2.02, 9.01
- 2011-04-15 0001104659-11-020407 — 5.02, 9.01 — amendment of 0001104659-11-005638
- 2011-02-08 0001104659-11-005638 — 5.02, 9.01
- 2011-01-27 0001104659-11-003419 — 2.02, 9.01
- 2010-12-22 0001104659-10-064003 — 5.02, 5.07, 9.01
- 2010-10-27 0001104659-10-054036 — 2.02, 9.01
- 2010-10-05 0001104659-10-051173 — 8.01
- 2010-07-22 0001104659-10-039126 — 2.02, 9.01
- 2010-07-09 0001104659-10-037594 — 2.05
- 2010-05-28 0001104659-10-031607 — 5.07
- 2010-04-26 0001104659-10-021797 — 2.02, 9.01
- 2010-03-17 0001104659-10-014849 — 5.02, 9.01
- 2010-02-08 0001104659-10-005457 — 5.02, 9.01
- 2010-01-28 0001104659-10-003627 — 2.02, 9.01
- 2009-10-22 0001104659-09-059972 — 2.02, 9.01
- 2009-07-23 0001104659-09-044508 — 2.02, 9.01
- 2009-05-20 0001104659-09-033938 — 5.02, 9.01
- 2009-04-30 0001104659-09-027707 — 2.02, 9.01
- 2009-03-10 0001104659-09-016178 — 5.02, 9.01
- 2009-02-09 0001104659-09-007692 — 5.02, 9.01
- 2009-01-29 0001104659-09-005022 — 2.02, 2.05, 9.01
- 2009-01-21 0001104659-09-003180 — 2.02, 8.01, 9.01
- 2009-01-06 0001104659-09-000625 — 5.02
- 2008-10-23 0001104659-08-065475 — 2.02, 9.01
- 2008-07-21 0001104659-08-046690 — 2.02, 9.01
- 2008-05-16 0001104659-08-034035 — 8.01, 9.01
- 2008-04-28 0001104659-08-027379 — 7.01, 9.01
- 2008-04-21 0001104659-08-025616 — 2.02, 9.01
- 2008-03-12 0001104659-08-016939 — 7.01, 9.01
- 2008-02-26 0001104659-08-012840 — 7.01, 9.01
- 2008-02-12 0001104659-08-009382 — 5.02, 9.01
- 2008-01-31 0001104659-08-006199 — 2.02, 9.01
- 2007-12-05 0001104659-07-087191 — 1.01, 9.01
- 2007-10-18 0001104659-07-075654 — 2.02, 9.01
- 2007-07-27 0001104659-07-056886 — 5.03, 9.01
- 2007-07-19 0001104659-07-054924 — 2.02, 9.01
- 2007-05-23 0001104659-07-042287 — 8.01, 9.01
- 2007-05-07 0001104659-07-036172 — 1.01, 5.02, 9.01
- 2007-04-24 0001104659-07-030578 — 2.02, 9.01 — amendment, the index does not say of what
- 2007-04-24 0001104659-07-030547 — 2.02, 9.01
- 2007-04-10 0001104659-07-027465 — 5.02, 9.01
- 2007-03-23 0001104659-07-021969 — 2.02, 4.02, 9.01
- 2007-01-30 0001104659-07-005772 — 2.02, 9.01
- 2007-01-09 0001104659-07-001600 — 5.02, 9.01
- 2006-10-30 0001104659-06-069612 — 1.01
- 2006-10-19 0001104659-06-067549 — 2.02, 9.01
- 2006-07-20 0001104659-06-048020 — 2.02, 4.02, 9.01
- 2006-05-17 0001104659-06-035522 — 1.01, 9.01 — amendment of 0001104659-05-011155
- 2006-05-09 0001104659-06-032706 — 1.01, 9.01
- 2006-04-25 0001104659-06-027438 — 2.02, 9.01
- 2006-04-04 0001104659-06-022204 — 1.01, 9.01
- 2006-03-15 0001104659-06-016861 — 1.01, 9.01
- 2006-01-30 0001104659-06-004749 — 2.02, 9.01
- 2006-01-24 0001104659-06-003504 — 1.01, 5.02, 9.01
- 2005-12-13 0001104659-05-060532 — 1.01, 9.01
- 2005-11-10 0001104659-05-054663 — 2.02, 9.01
- 2005-07-21 0001104659-05-033464 — 2.02, 9.01
- 2005-06-22 0001104659-05-029255 — 1.01
- 2005-05-16 0001104659-05-023473 — 2.02, 9.01 — amendment of 0001104659-05-018173
- 2005-05-16 0001104659-05-023471 — 2.02, 9.01 — amendment of 0001104659-05-017382
- 2005-05-10 0001104659-05-022127 — 1.01
- 2005-04-26 0001104659-05-018173 — 2.02, 9.01
- 2005-04-21 0001104659-05-017382 — 2.02, 9.01
- 2005-04-06 0001104659-05-015401 — 5.02
- 2005-03-15 0001104659-05-011155 — 1.01, 9.01
- 2005-03-08 0001104659-05-009975 — 1.01, 9.01
- 2005-02-03 0001104659-05-003943 — 2.02, 9.01
- 2005-01-13 0001104659-05-001314 — 5.02, 9.01
- 2004-10-21 0001104659-04-031413 — 2.02, 9.01
- 2004-07-22 0001104659-04-020572 — 12, 7
- 2004-04-14 0001104659-04-010039 — 12, 7
- 2004-04-05 0001104659-04-009437 — 12, 7
- 2004-01-26 0001104659-04-001655 — 12, 7
- 2003-10-16 0001104659-03-022990 — 12, 7
- 2003-07-17 0001104659-03-015053 — 9
- 2003-04-18 0001104659-03-006823 — 7, 9
- 2003-02-14 0001104659-03-002607 — 5, 7

## late-filing notifications on or before 2012-03-08

- 2007-03-16 0001104659-07-020094 — NT 10-K, for the period ended 2006-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001104659-12-004244:8k_2_02:1]
EX-99.1
2
a12-3477_1ex99d1.htm
EX-99.1

[0001104659-12-004244:8k_2_02:2]
Exhibit 99.1

[0001104659-12-004244:8k_2_02:3]
| Contact: |  |  |
| Rob Seim |  | Omnicell, Inc. |
| Chief Financial Officer |  | 1201 Charleston Road |
| 800-850-6664, ext. 6478 |  | Mountain View, CA 94043 |
| rob.seim@omnicell.com |  |  |

[0001104659-12-004244:8k_2_02:4]
Omnicell Announces Fourth Quarter and Full Year 2011 Results

[0001104659-12-004244:8k_2_02:5]
MOUNTAIN VIEW, Calif. — January 26, 2012— Omnicell, Inc. (NASDAQ: OMCL), a leading provider of system solutions to healthcare facilities, today announced results for its fourth quarter and year ended December 31, 2011.

[0001104659-12-004244:8k_2_02:6]
GAAP results: Revenue for the fourth quarter of 2011 was $62.9 million, up $5.7 million or 9.9% from the fourth quarter of 2010 and down $1.5 million or 2.3% from the third quarter of 2011.  Revenue for the year ended December 31, 2011 was $245.5 million, up $23.1 million or 10.4% from the year ended December 31, 2010.

[0001104659-12-004244:8k_2_02:7]
Fourth quarter 2011 net income as reported in accordance with U.S. generally accepted accounting principles (GAAP) was $4.1 million, or $0.12 per diluted share. This compares to net income of $0.7 million, or $0.02 per diluted share in the fourth quarter of 2010 and net income of $3.0 million, or $0.09 per diluted share in the third quarter of 2011. For the year ended December 31, 2011, net income was $10.4 million, or $0.30 per diluted share. This compares to net income of $4.9 million, or $0.15 per diluted share for the year ended December 31, 2010.

[0001104659-12-004244:8k_2_02:8]
Non-GAAP results: Non-GAAP net income was $6.4 million for the fourth quarter of 2011, or $0.19 per diluted share. Non-GAAP net income for the fourth quarter excludes $2.2 million of stock-based compensation expense. This compares to non-GAAP net income of $3.6 million, or $0.11 per diluted share for the fourth quarter of 2010, excluding $2.6 million of stock-based compensation expense and $0.4 million of income tax expense on the repatriation of profits from India associated with the facilities consolidation announced in the third quarter of 2010. Fourth quarter 2011 results compare to non-GAAP net income of $5.4 million, or $0.16 per diluted share for the third quarter of 2011, excluding $2.4 million of stock-based compensation expense .  Non-GAAP net income was $20.5 million for the year ended December 31, 2011, or $0.60 per diluted share, excluding $9.5 million of stock-based compensation expense and $1.0 million of pre-tax litigation claims settlement expense, net of a $0.4 million tax effect. Non-GAAP net income was $14.5 million for the year ended December 31, 2010, or $0.43 per diluted share, excluding $9.0 million of stock-based compensation expense, a $2.4 million gain ($1.4 million, net of tax) related to the settlement of litigation claims, and $2.7 million of charges ($2.0 million, net of tax) related to restructuring, reduction-in-force and repatriation of profits from India associated with the facilities consolidation.

[0001104659-12-004244:8k_2_02:9]
Product backlog as of December 31, 2011 totaled $134 million, up $7 million or 6% from December 31, 2010.

[0001104659-12-004244:8k_2_02:10]
“Overall, 2011 was a very good year for Omnicell,” said Randall Lipps, Omnicell’s President, CEO, and Chairman of the Board. “Revenue was up 10%, non-GAAP net income was up 42%, and although year ending backlog was lower than expectations, backlog grew 6% from 2010. I’m very happy with our introduction of new products, our growth of the customer base, and our entry into new markets during the year.”

[0001104659-12-004244:8k_2_02:11]
Omnicell Conference Call Information

[0001104659-12-004244:8k_2_02:12]
Omnicell will hold a conference call at 1:30 p.m. PST today to discuss fourth quarter and 2011 year-end financial results. The conference call can be monitored by dialing 1-800-696-5518 within the U.S. or 1-706-758-4883 for all other locations. The Conference ID # is 44215896. Internet users can access the conference call at http://ir.omnicell.com/events.cfm.  A replay of the call will be available today at approximately 4:30 p.m. PST and will be available until 11:45 p.m. PDT on February 3, 2012. The replay access numbers are 1-855-859-2056 within the U.S. and 1-404-537-3406 for all other locations, conference code # 44215896.

[0001104659-12-004244:8k_2_02:13]
About Omnicell

[0001104659-12-004244:8k_2_02:14]
Omnicell, Inc. (NASDAQ: OMCL) is a leading provider of systems that enable healthcare facilities to increase operational efficiency and enhance patient safety and allow clinicians to spend more time with their patients.

[0001104659-12-004244:8k_2_02:15]
Founded in 1992, Omnicell’s medication-use solutions include complete automation systems for the central pharmacy, anesthesia workstations for the operating room, dispensing cabinet systems for nursing units, and safe, secure medication transportation and verification systems to the patient bedside. From a medication’s arrival at the receiving dock to its dosing to the patient, Omnicell systems store it, package it, bar code it, order it, issue it, and provide information and controls on its use and reorder.

[0001104659-12-004244:8k_2_02:16]
Omnicell’s supply product lines provide a healthcare institution with comprehensive supply chain solutions that result in fast, effective control of costs, capture of charges for payer reimbursement, and timely reorder of supplies. Products range from high-security closed-cabinet systems and software to open-shelf and combination solutions in the nursing unit, cath lab and operating room.

[0001104659-12-004244:8k_2_02:17]
For more information, visit www.omnicell.com.

[0001104659-12-004244:8k_2_02:18]
Forward-Looking Statements

[0001104659-12-004244:8k_2_02:19]
To the extent any statements contained in this release deal with information that is not historical, these statements are necessarily forward-looking. As such, they are subject to the occurrence of many events outside Omnicell’s control and are subject to various risk factors that could cause actual results to differ materially from those expressed or implied in any forward-looking statement. The risk factors are described in the Company’s Securities and Exchange Commission (SEC) filings and include, without limitation, the unfavorable general economic and market conditions, volatility in the credit market, risks to growth and acceptance of our products and services and to growth of the clinical automation and workflow automation market generally, the potential of increasing competition, potential regulatory changes, and the ability of the company to improve sales productivity to grow product backlog, retain key personnel, to cut expenses, to manage future changes in revenue levels, to develop new products and integrate acquired companies, products or intellectual property in a timely and cost-effective manner. Prospective investors are cautioned not to place undue reliance on forward-looking statements.

[0001104659-12-004244:8k_2_02:20]
Use of Non-GAAP Financial Information

[0001104659-12-004244:8k_2_02:21]
This press release contains financial measures that are not calculated in accordance with U.S. generally accepted accounting principles (GAAP). Our management evaluates and makes operating decisions using various performance measures. In addition to Omnicell’s GAAP results, we also consider non-GAAP gross profit, non-GAAP operating expenses, non-GAAP net income, and non-GAAP net income per diluted share. Additionally, we calculate Adjusted EBITDA (another non-GAAP measure) by means of adjustments to GAAP Net Income. These non-GAAP results should not be considered as an alternative to gross profit, operating expenses, net income, net income per diluted share, or any other performance measure derived in accordance with GAAP.  We present these non-GAAP results because we consider them to be important supplemental measures of Omnicell’s performance.

[0001104659-12-004244:8k_2_02:22]
Our non-GAAP gross profit, non-GAAP operating expenses, non-GAAP net income, and non-GAAP net income per diluted share are exclusive of certain items to facilitate management’s review of the comparability of Omnicell’s core operating results on a period to period basis because such items are not related to Omnicell’s ongoing core operating results as viewed by management. We define our “core operating results” as those revenues recorded in a particular period and the expenses incurred within that period that directly drive operating income in that period. Management uses these non-GAAP financial measures in making operating decisions because, in addition to meaningful supplemental information regarding operating performance, the measures give us a better understanding of how we should invest in research and development, fund infrastructure growth and evaluate the effectiveness of marketing strategies. In calculating the above non-GAAP results, management specifically adjusted for the following excluded items:

[0001104659-12-004244:8k_2_02:23]
a) Stock-based compensation expense impact of Accounting Standards Codification (ASC) 718. We recognize equity plan-related compensation expenses, which represent the fair value of all share-based payments to employees, including grants of employee stock options, as required under ASC 718, “Stock Compensation” as non-GAAP adjustments in each period.

[0001104659-12-004244:8k_2_02:24]
b) 2011 litigation settlement. We recorded an accrual in the first quarter of 2011 for settlement of litigation with Medacist Solutions Group, LLC for $1.0 million, which was paid in the second quarter of 2011. The net impact was $0.6 million after the $0.4 million income tax effect.

[0001104659-12-004244:8k_2_02:25]
c) 2010 litigation settlement. In the third quarter of 2010 we settled two pending litigation matters with Flo Healthcare LLC (now part of InterMetro Industries Corporation), with payment to InterMetro of $2.7 million. The resulting $2.4 million credit to third quarter 2010 selling general and administrative expense reflected adjustment for the settlement with release of the liability in excess of the amounts settled.

[0001104659-12-004244:8k_2_02:26]
d) 2010 restructuring charges. In the third quarter of 2010 we incurred charges for restructuring and impairment in executing our plan for consolidation of our Bangalore, India and Woodlands, Texas offices with our California and Tennessee facilities. These charges consisted of severance for departing employees and relocation benefits for transferring employees, exit and disposal costs related to the closed facilities, and impairment of abandoned leasehold improvements.

[0001104659-12-004244:8k_2_02:27]
e) 2010 reduction-in-force and other exit related charges. In the third quarter of 2010 we conducted a small reduction-in-force to rebalance the required workforce by function to our current business environment. Additionally, we incurred lease termination costs and leasehold improvement impairment costs (upon abandonment) in connection with merging our Lebanon, Tennessee office with our office in Nashville.

[0001104659-12-004244:8k_2_02:28]
f) 2010 income taxes on repatriated foreign earnings. In the third quarter of 2010, the closure of our Bangalore, India office resulted in a  charge for repatriation taxes and a valuation allowance against related deferred tax assets.

[0001104659-12-004244:8k_2_02:29]
Management adjusts for the above items because management believes that, in general, these items possess one or more of the following characteristics: their magnitude and timing is largely outside of Omnicell’s control; they are unrelated to the ongoing operation of the business in the ordinary course; they are unusual and we do not expect them to occur in the ordinary course of business; or they are non-operational or non-cash expenses involving stock option grants.

[0001104659-12-004244:8k_2_02:30]
We believe that the presentation of these non-GAAP financial measures is warranted for several reasons:

[0001104659-12-004244:8k_2_02:31]
1) Such non-GAAP financial measures provide an additional analytical tool for understanding Omnicell’s financial performance by excluding the impact of items which may obscure trends in the core operating results of the business;

[0001104659-12-004244:8k_2_02:32]
2) Since we have historically reported non-GAAP results to the investment community, we believe the inclusion of non-GAAP numbers provides consistency and enhances investors’ ability to compare our performance across financial reporting periods;

[0001104659-12-004244:8k_2_02:33]
3) These non-GAAP financial measures are employed by Omnicell’s management in its own evaluation of performance and are utilized in financial and operational decision making processes, such as budget planning and forecasting; and

[0001104659-12-004244:8k_2_02:34]
4) These non-GAAP financial measures facilitate comparisons to the operating results of other companies in our industry, which use similar financial measures to supplement their GAAP results, thus enhancing the perspective of investors who wish to utilize such comparisons in their analysis of our performance.

[0001104659-12-004244:8k_2_02:35]
Set forth below are additional reasons why share-based compensation expense related to ASC 718 is excluded from our non-GAAP financial measures:

[0001104659-12-004244:8k_2_02:36]
i)  While share-based compensation calculated in accordance with ASC 718 constitutes an ongoing and recurring expense of Omnicell, it is not an expense that requires cash settlement by Omnicell. We therefore exclude these charges for purposes of evaluating core operating results. Thus, our non-GAAP measurements are presented exclusive of stock-based compensation expense to assist management and investors in evaluating our core operating results.

[0001104659-12-004244:8k_2_02:37]
ii) We present ASC 718 share-based payment compensation expense in our reconciliation of non-GAAP financial measures on a pre-tax basis because the exact tax differences related to the timing and deductibility of share-based compensation, under ASC 718 are dependent upon the trading price of Omnicell’s common stock and the timing and exercise by employees of their stock options.  As a result of these timing and market uncertainties, the tax effect related to share-based compensation expense would be inconsistent in amount and frequency and is therefore excluded from our non-GAAP results.

[0001104659-12-004244:8k_2_02:38]
Our Adjusted EBITDA calculation is defined as earnings before interest income and expense, taxes, depreciation and amortization, and non-cash expenses, including ASC 718 stock compensation expense.

[0001104659-12-004244:8k_2_02:39]
As stated above, we present non-GAAP financial measures because we consider them to be important supplemental measures of performance. However, non-GAAP financial measures have limitations as an analytical tool and should not be considered in isolation or as a substitute for Omnicell’s GAAP results.  In the future, we expect to incur expenses similar to certain of the non-GAAP adjustments described above and expect to continue reporting non-GAAP financial measures excluding such items. Some of the limitations in relying on non-GAAP financial measures are:

[0001104659-12-004244:8k_2_02:40]
· Omnicell’s stock option and stock purchase plans are important components of incentive compensation arrangements and will be reflected as expenses in Omnicell’s GAAP results for the foreseeable future under ASC 718.

[0001104659-12-004244:8k_2_02:41]
· Other companies, including other companies in Omnicell’s industry, may calculate non-GAAP financial measures differently than Omnicell, limiting their usefulness as a comparative measure.

[0001104659-12-004244:8k_2_02:42]
Pursuant to the requirements of SEC Regulation G, a detailed reconciliation between Omnicell’s non-GAAP and GAAP financial results is set forth in the financial tables at the end of this press release. Investors are advised to carefully review and consider this information strictly as a supplement to the GAAP results that are contained in this press release and in Omnicell’s SEC filings.

[0001104659-12-004244:8k_2_02:43]
Omnicell, Inc.
 Condensed Consolidated Statements of Operations
 (in thousands, except per share data)

[0001104659-12-004244:8k_2_02:44]
|  |  | Three Months Ended |  | Year Ended |  |
|  |  | December 31, 2011 (unaudited) |  | September 30, 2011 (unaudited) |  | December 31, 2010 (unaudited) |  | December 31, 2011 (unaudited) |  | December 31, 2010 (1) |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 47,281 |  | $ | 49,790 |  | $ | 43,541 |  | $ | 185,864 |  | $ | 171,100 |  |
| Services and other revenues |  | 15,650 |  | 14,649 |  | 13,727 |  | 59,671 |  | 51,307 |  |
| Total revenue |  | 62,931 |  | 64,439 |  | 57,268 |  | 245,535 |  | 222,407 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product revenues |  | 19,572 |  | 22,429 |  | 18,649 |  | 79,567 |  | 76,372 |  |
| Cost of services and other revenues |  | 7,480 |  | 7,562 |  | 7,256 |  | 30,184 |  | 28,079 |  |
| Restructuring charges |  | — |  | — |  | — |  | — |  | 39 |  |
| Total cost of revenues |  | 27,052 |  | 29,991 |  | 25,905 |  | 109,751 |  | 104,490 |  |
| Gross profit |  | 35,879 |  | 34,448 |  | 31,363 |  | 135,784 |  | 117,917 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  | 5,903 |  | 6,019 |  | 5,403 |  | 22,042 |  | 21,007 |  |
| Selling, general, and administrative |  | 23,807 |  | 23,635 |  | 24,438 |  | 97,520 |  | 86,227 |  |
| Restructuring charges |  | — |  | — |  | — |  | — |  | 1,157 |  |
| Total operating expenses |  | 29,710 |  | 29,654 |  | 29,841 |  | 119,562 |  | 108,391 |  |
| Income from operations |  | 6,169 |  | 4,794 |  | 1,522 |  | 16,222 |  | 9,526 |  |
| Other income (expense), net |  | (67 | ) | (191 | ) | 145 |  | (133 | ) | 431 |  |
| Income before provision for income taxes |  | 6,102 |  | 4,603 |  | 1,667 |  | 16,089 |  | 9,957 |  |
| Provision for income taxes |  | 1,964 |  | 1,609 |  | 995 |  | 5,700 |  | 5,065 |  |
| Net income |  | $ | 4,138 |  | $ | 2,994 |  | $ | 672 |  | $ | 10,389 |  | $ | 4,892 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.13 |  | $ | 0.09 |  | $ | 0.02 |  | $ | 0.31 |  | $ | 0.15 |  |
| Diluted |  | $ | 0.12 |  | $ | 0.09 |  | $ | 0.02 |  | $ | 0.30 |  | $ | 0.15 |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | 33,097 |  | 33,209 |  | 32,997 |  | 33,123 |  | 32,651 |  |
| Diluted |  | 34,114 |  | 34,219 |  | 33,900 |  | 34,103 |  | 33,513 |  |

[0001104659-12-004244:8k_2_02:45]
(1)          Information derived from our December 31, 2010 audited Consolidated Financial Statements.

[0001104659-12-004244:8k_2_02:46]
Omnicell, Inc.
 Condensed Consolidated Balance Sheets
 (In thousands)

[0001104659-12-004244:8k_2_02:47]
|  |  | December 31, |  | December 31, |  |
|  |  | 2011 |  | 2010 |  |
|  |  | (unaudited) |  | (1) |  |
| ASSETS |  |  |  |  |  |
| Current assets: |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 191,762 |  | $ | 175,635 |  |
| Short-term investments |  | 8,107 |  | 8,074 |  |
| Accounts receivable, net |  | 36,902 |  | 42,732 |  |
| Inventories |  | 18,107 |  | 9,785 |  |
| Prepaid expenses |  | 10,495 |  | 11,959 |  |
| Deferred tax assets |  | 7,914 |  | 13,052 |  |
| Other current assets |  | 6,107 |  | 7,266 |  |
| Total current assets |  | 279,394 |  | 268,503 |  |
| Property and equipment, net |  | 17,307 |  | 14,351 |  |
| Non-current net investment in sales-type leases |  | 8,785 |  | 9,224 |  |
| Goodwill |  | 28,543 |  | 28,543 |  |
| Other intangible assets |  | 4,231 |  | 4,672 |  |
| Non-current deferred tax assets |  | 13,992 |  | 9,566 |  |
| Other assets |  | 9,716 |  | 8,365 |  |
| Total assets |  | $ | 361,968 |  | $ | 343,224 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |
| Accounts payable |  | $ | 11,000 |  | $ | 13,242 |  |
| Accrued compensation |  | 7,328 |  | 7,731 |  |
| Accrued liabilities |  | 7,020 |  | 8,684 |  |
| Deferred service revenue |  | 19,191 |  | 16,788 |  |
| Deferred gross profit |  | 14,210 |  | 11,719 |  |
| Total current liabilities |  | 58,749 |  | 58,164 |  |
| Long-term deferred service revenue |  | 18,966 |  | 19,171 |  |
| Other long-term liabilities |  | 1,339 |  | 675 |  |
| Total liabilities |  | 79,054 |  | 78,010 |  |
| Stockholders’ equity: |  |  |  |  |  |
| Total stockholders’ equity |  | 282,914 |  | 265,214 |  |
| Total liabilities and stockholders’ equity |  | $ | 361,968 |  | $ | 343,224 |  |

[0001104659-12-004244:8k_2_02:48]
(1)  Information derived from our December 31, 2010 audited Consolidated Financial Statements.

[0001104659-12-004244:8k_2_02:49]
Omnicell, Inc.
 Reconciliation of GAAP to Non-GAAP
 (In thousands, except per share data, unaudited)

[0001104659-12-004244:8k_2_02:50]
|  |  | Three months ended |  |
|  |  | December 31, 2011 |  | September 30, 2011 |  | December 31, 2010 |  |
|  |  | Net income |  | Net income per share- diluted |  | Net income |  | Net income per share- diluted |  | Net income |  | Net income per share- diluted |  |
| GAAP |  | $ | 4,138 |  | $ | 0.12 |  | $ | 2,994 |  | $ | 0.09 |  | $ | 672 |  | $ | 0.02 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Taxes on repatriated foreign earnings |  | — |  |  |  | — |  |  |  | 383 |  |  |  |
| ASC 718 share-based compensation adjustment (a) |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gross profit |  | 290 |  |  |  | 358 |  |  |  | 356 |  |  |  |
| Operating expenses |  | 1,955 |  |  |  | 2,053 |  |  |  | 2,208 |  |  |  |
| Total after tax adjustments |  | 2,245 |  | 0.07 |  | 2,411 |  | 0.07 |  | 2,947 |  | 0.09 |  |
| Non-GAAP |  | $ | 6,383 |  | $ | 0.19 |  | $ | 5,405 |  | $ | 0.16 |  | $ | 3,619 |  | $ | 0.11 |  |

[0001104659-12-004244:8k_2_02:51]
(a) This adjustment reflects the accounting impact of non-cash stock-based compensation expense related to the impact of ASC 718 (formerly referred to as SFAS No. 123R) for the periods shown.

[0001104659-12-004244:8k_2_02:52]
Omnicell, Inc.
 Reconciliation of GAAP to Non-GAAP
 (In thousands, except per share data, unaudited)

[0001104659-12-004244:8k_2_02:53]
|  |  | Year ended |  |
|  |  | December 31, 2011 |  | December 31, 2010 |  |
|  |  | Net income |  | Net income per share- diluted |  | Net income |  | Net income per share- diluted |  |
| GAAP |  | $ | 10,389 |  | $ | 0.30 |  | $ | 4,892 |  | $ | 0.15 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |
| Restructuring cost |  |  |  |  |  |  |  |  |  |
| Gross profit |  | — |  |  |  | 39 |  |  |  |
| Operating expenses |  | — |  |  |  | 1,157 |  |  |  |
| Reduction-in-force, other exit-related charges |  |  |  |  |  |  |  |  |  |
| Gross profit |  | — |  |  |  | 285 |  |  |  |
| Operating expenses |  | — |  |  |  | 219 |  |  |  |
| Litigation settlement (a) |  | 1,000 |  |  |  | (2,439 | ) |  |  |
| Subtotal pretax adjustments |  | 1,000 |  |  |  | (739 | ) |  |  |
| Income tax effect of non-GAAP adjustments |  | (380 | ) |  |  | 326 |  |  |  |
| Taxes on repatriated foreign earnings |  | — |  |  |  | 957 |  |  |  |
| ASC 718 share-based compensation adjustment (b) |  |  |  |  |  |  |  |  |  |
| Gross profit |  | 1,398 |  |  |  | 1,350 |  |  |  |
| Operating expenses |  | 8,101 |  |  |  | 7,665 |  |  |  |
| Total after tax adjustments |  | 10,119 |  | 0.30 |  | 9,559 |  | 0.28 |  |
| Non-GAAP |  | $ | 20,508 |  | $ | 0.60 |  | $ | 14,451 |  | $ | 0.43 |  |

[0001104659-12-004244:8k_2_02:54]
(a) The 2011 adjustment is for the accrual of a $1.0 million pre-tax litigation settlement in operating expenses ($0.6 million, net of tax effect of $0.4 million) in the first quarter of 2011. The 2010 adjustment reflects the reversal in operating expenses for the settlement of litigation in the third quarter of 2010 for amounts less than accrued.

[0001104659-12-004244:8k_2_02:55]
(b) This adjustment reflects the accounting impact of non-cash stock-based compensation expense related to the impact of ASC 718 (formerly referred to as SFAS No. 123R) for the periods shown.

[0001104659-12-004244:8k_2_02:56]
Omnicell, Inc.
 Calculation of Adjusted EBITDA (1)
 (In thousands, unaudited)

[0001104659-12-004244:8k_2_02:57]
|  |  | Three Months Ended |  | Year Ended |  |
|  |  | December 31, 2011 |  | September 30, 2011 |  | December 31, 2010 |  | December 31, 2011 |  | December 31, 2010 |  |
| GAAP net income |  | $ | 4,138 |  | $ | 2,994 |  | $ | 672 |  | $ | 10,389 |  | $ | 4,892 |  |
| Add back: |  |  |  |  |  |  |  |  |  |  |  |
| ASC 718 stock compensation expense |  | 2,245 |  | 2,411 |  | 2,564 |  | 9,499 |  | 9,015 |  |
| Restructuring charges |  | — |  | — |  | — |  | — |  | 1,196 |  |
| Reduction-in-force, other exit-related charges |  | — |  | — |  | — |  | — |  | 504 |  |
| Litigation settlement |  | — |  | — |  | — |  | 1,000 |  | (2,439 | ) |
| Interest |  | (21 | ) | (34 | ) | (79 | ) | (205 | ) | (420 | ) |
| Depreciation and amortization expense |  | 2,163 |  | 2,027 |  | 2,130 |  | 7,984 |  | 8,619 |  |
| Income tax expense |  | 1,964 |  | 1,609 |  | 995 |  | 5,700 |  | 5,065 |  |
| Non-GAAP adjusted EBITDA (1) |  | $ | 10,489 |  | $ | 9,007 |  | $ | 6,282 |  | $ | 34,367 |  | $ | 26,432 |  |

[0001104659-12-004244:8k_2_02:58]
(1) Defined as earnings before interest income and expense, taxes, depreciation and amortization, and non-cash expenses, including stock compensation expense, per ASC 718, formerly FAS 123R.  Also excludes non-GAAP adjustments for restructuring, reduction-in-force and other exit-related charges, and litigation settlement.
