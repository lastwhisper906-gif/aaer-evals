# OMCL note change history — 0000926326-19-000033 → 0000926326-20-000014


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-05-08):
[0000926326-20-000014:note_history:1]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of March 31, 2020, the Company had non-cancelable purchase commitments of $91.7 million, of which $90.2 million are expected to be paid within the year ending December 31, 2020.
  (was, 2019-11-01, similarity 0.9747):
[0000926326-19-000033:note_history:1]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of September 30, 2019, the Company had non-cancelable purchase commitments of $75.3 million, of which $57.1 million are expected to be paid within the year ending December 31, 2019.

- changed (2020-05-08):
[0000926326-20-000014:note_history:2]
On January 10, 2018, a lawsuit was filed against a number of individuals, governmental agencies, and corporate entities, including the Company and one of its former subsidiaries, Aesynt Incorporated (“Aesynt”), which, through a series of mergers, has been merged into the Company, in the Circuit Court for the City of Richmond, Virginia, captioned Ruth Ann Warner, as Guardian of Jonathan James Brewster Warner v. Centra Health, Inc., et al., Case No. CL18-152-1. The complaint sought monetary recovery of compensatory and punitive damages in addition to certain declaratory relief based upon, as against the individuals, governmental agencies, and corporate entities other than the Company and Aesynt, allegations of the use of excessive force, unlawful detention, false imprisonment, battery, simple and gross negligence and negligent hiring, detention, and training; and, as against the Company and Aesynt, claims of product liability, negligence, and breach of implied warranties. The Company and Aesynt were never served with the complaint. Upon motion of the plaintiff, the Court issued an order on February 21, 2019 nonsuiting (dismissing) the case without prejudice. On August 21, 2019, a new lawsuit was filed against the Company and Aesynt, in the Circuit Court for the County of Albemarle, Virginia, captioned Ruth Ann Warner, as Guardian of Jonathan James Brewster Warner v. Aesynt Incorporated, et al., Case No CL19-1301. The complaint seeks monetary recovery of damages based upon claims of product liability, negligence, and breach of implied warranties. The Company and Aesynt have not been served with the complaint. The Company intends to defend the lawsuit vigorously.
  (was, 2019-11-01, similarity 0.9735):
[0000926326-19-000033:note_history:2]
On January 10, 2018, a lawsuit was filed against a number of individuals, governmental agencies, and corporate entities, including the Company and one of its subsidiaries, Aesynt Incorporated (“Aesynt”), in the Circuit Court for the City of Richmond, Virginia, captioned Ruth Ann Warner, as Guardian of Jonathan James Brewster Warner v. Centra Health, Inc., et al., Case No. CL18-152-1. The complaint seeks monetary recovery of compensatory and punitive damages in addition to certain declaratory relief based upon, as against the individuals, governmental agencies, and corporate entities other than the Company and Aesynt, allegations of the use of excessive force, unlawful detention, false imprisonment, battery, simple and gross negligence and negligent hiring, detention, and training; and, as against the Company and Aesynt, claims of product liability, negligence, and breach of implied warranties. The Company and Aesynt were never served with the complaint. Upon motion of the plaintiff, the Court issued an order on February 21, 2019 nonsuiting (dismissing) the case without prejudice. On August 21, 2019, a new lawsuit was filed against the Company and Aesynt, in the Circuit Court for the County of Albemarle, Virginia, captioned Ruth Ann Warner, as Guardian of Jonathan James Brewster Warner v. Aesynt Incorporated, et al., Case No CL19-1301. The complaint seeks monetary recovery of damages based upon claims of product liability, negligence, and breach of implied warranties. The Company and Aesynt have not been served with the complaint. The Company intends to defend the lawsuit vigorously.

- changed (2020-05-08):
[0000926326-20-000014:note_history:3]
A declaratory judgment action was filed against the Company, on August 30, 2018, in the United States District Court for the Northern District of California, captioned Zurich American Insurance Company; American Guarantee & Liability Company v. Omnicell, Inc. and Does 1-10, inclusive, Case No. 3:18-CV-05345. The complaint seeks a declaration that the plaintiffs have no duty to defend or indemnify the Company in connection with the underlying litigation, Yana Mazya, et al. v. Northwestern Lake Forest Hospital, et al., Case No. 2018-CH-07161 pending in the Circuit Court of Cook County, Illinois, Chancery Division (a class action lawsuit filed against a customer of the Company, the customer’s parent company, and two vendors of medication dispensing systems, one of which is the Company, seeking statutory damages and certain declaratory, injunctive, and other relief based on causes of action directed to allegations of violation of the Illinois Biometric Information Privacy Act (“BIPA”) and of negligence by the defendants from which the Company was subsequently dismissed without prejudice) (“Mazya Action”), together with claims for reimbursement and unjust enrichment relating to the defense of the Mazya Action in the form of attorneys’ fees and other related costs. The Company has not responded to the complaint. On February 12, 2019, the Court stayed the action pending the outcome of the Mazya Action and administratively closed the case. On October 15, 2019, the plaintiffs filed a notice advising the Court of the dismissal of the Company from the Mazya Action and requesting that the Court lift the stay in the case and set dates for filing a responsive pleading by the Company and initial discovery and scheduling matters. By order dated November 13, 2019, the Court (i) lifted the stay in the case, (ii) set a case management conference for February 5, 2020, and (iii) ordered the parties to file a joint case management statement by January 29, 2020. The parties subsequently reached a settlement of the case in principle and the Court, after notice of the parties, continued the case management conference until April 29, 2020. The parties entered into a written settlement agreement on April 9, 2020. Since the conditions precedent in the settlement agreement to dismissing the case had not yet been fulfilled, the Court, upon the petition of the parties, again continued the case management conference until May 27, 2020. Upon fulfillment of the conditions precedent to finalizing the settlement, the plaintiffs filed a notice of dismissal with prejudice on May 4, 2020, thereby finally terminating the action.
  (was, 2019-11-01, similarity 0.6367):
[0000926326-19-000033:note_history:3]
A declaratory judgment action was filed against the Company, on August 30, 2018, in the United States District Court for the Northern District of California, captioned Zurich American Insurance Company; American Guarantee & Liability Company v. Omnicell, Inc. and Does 1-10, inclusive, Case No. 3:18-CV-05345. The complaint seeks a declaration that the plaintiffs have no duty to defend or indemnify the Company in connection with the underlying litigation, the Yana Mazya, et al. v. Northwestern Lake Forest Hospital, et al., Case No. 2018-CH-07161 pending in the Circuit Court of Cook County, Illinois, Chancery Division (“Mazya Action”), disclosed above, together with claims for reimbursement and unjust enrichment relating to the defense of the Mazya Action in the form of attorneys’ fees and other related costs. The Company has not responded to the complaint. On February 12, 2019, the court stayed the action pending the outcome of the Mazya Action and administratively closed the case. On October 15, 2019, the plaintiffs filed a notice advising the Court of the dismissal of the Company from the Mazya Action and requesting that the Court lift the stay in the case and set dates for filing a responsive pleading by the Company and initial discovery and scheduling matters. The Company intends to defend the lawsuit vigorously.

- changed (2020-05-08):
[0000926326-20-000014:note_history:4]
A class action lawsuit was filed against the Company, on June 5, 2019, in the Circuit Court of Cook County, Illinois, Chancery Division, captioned Corey Heard, individually and on behalf of all others similarly situated, v. Omnicell, Inc., Case No. 2019-CH-06817. The complaint seeks class certification, monetary damages in the form of statutory damages for willful and/or reckless or, in the alternative, negligent violation of BIPA, and certain declaratory, injunctive, and other relief based on
  (was, 2019-11-01, similarity 0.6021):
[0000926326-19-000033:note_history:4]
A class action lawsuit was filed against the Company, on June 5, 2019, in the Circuit Court of Cook County, Illinois, Chancery Division, captioned Corey Heard, individually and on behalf of all others similarly situated, v. Omnicell, Inc., Case No. 2019-CH-06817. The complaint seeks class certification, monetary damages in the form of statutory damages for willful and/or reckless or, in the alternative, negligent violation of BIPA, and certain declaratory, injunctive, and other relief based on causes of action directed to allegations of violation of BIPA by the Company. The complaint was served on the Company on June 13, 2019. On July 31, 2019, the Company filed a motion to stay or consolidate the case with the Mazya Action. The Court subsequently, on October 10, 2019, denied the motion, without prejudice, as being moot in view of the Company’s dismissal from the Mazya Action. The Company filed a motion to dismiss the complaint on October 31, 2019. The Court has scheduled a case status conference for November 7, 2019 at which time the Company intends to present its motion to dismiss to the Court. The Company intends to defend the lawsuit vigorously.

- added (2020-05-08):
[0000926326-20-000014:note_history:5]
causes of action directed to allegations of violation of BIPA by the Company. The complaint was served on the Company on June 13, 2019. On July 31, 2019, the Company filed a motion to stay or consolidate the case with the Mazya Action. The Court subsequently, on October 10, 2019, denied the motion, without prejudice, as being moot in view of the Company’s dismissal from the Mazya Action. The Company filed a motion to dismiss the complaint on October 31, 2019. The motion to dismiss is fully-briefed. The hearing on the Company’s motion to dismiss was previously set for March 16, 2020, but has been continued to May 27, 2020. The Company intends to defend the lawsuit vigorously.

- changed (2020-05-08):
[0000926326-20-000014:note_history:6]
In August 2019, the Company received a letter from the Denver office of the SEC seeking information related to the Company’s accounting processes and procedures. The Company responded and fully cooperated with the SEC. On February 12, 2020, the Company received a letter from the SEC confirming that it has concluded its investigation and that the SEC does not intend to recommend any enforcement action against the Company.
  (was, 2019-11-01, similarity 0.6266):
[0000926326-19-000033:note_history:6]
In August 2019, the Company received a letter from the Denver office of the SEC seeking information related to the Company’s accounting processes and procedures. The Company responded and is fully cooperating with the SEC.

- removed (2020-05-08):
[0000926326-19-000033:note_history:7]
On June 6, 2018, a class action lawsuit was filed against a customer of the Company, the customer’s parent company and two vendors of medication dispensing systems, one of which is the Company, in the Circuit Court of Cook County, Illinois, Chancery Division, captioned Yana Mazya, individually and on behalf of all others similarly situated v. Northwestern Lake Forest Hospital, Northwestern Memorial Healthcare, Omnicell, Inc. and Becton Dickinson, Case No. 2018-CH-07161. The complaint sought class certification, monetary damages in the form of statutory damages for willful and/or reckless or, in the alternative, negligent violation of the Illinois Biometric Information Privacy Act (“BIPA”), and certain declaratory, injunctive, and other relief based on causes of action directed to allegations of violation of BIPA and of negligence by the defendants. The complaint was served on the Company on June 15, 2018. The Company’s obligation to respond to the complaint was held in

- removed (2020-05-08):
[0000926326-19-000033:note_history:8]
abeyance pending a decision of the Illinois Supreme Court in a separate case involving BIPA issues. The Illinois Supreme Court issued its decision in that case on January 25, 2019. On April 10, 2019, subsequent to the court’s issuance of an order granting the plaintiff leave to file an amended complaint, the plaintiff filed an amended complaint adding a second named plaintiff and an affiliate of the Company’s customer as an additional defendant and, in addition to making other modifications to the complaint, removing the separate cause of action directed to negligence. The court established a deadline of May 13, 2019 for the defendants to answer or otherwise respond to the amended complaint. On May 10, 2019, defendants Northwestern Lake Forest Hospital, Northwestern Memorial Healthcare, and Northwestern Memorial Hospital removed the case to the United States District Court for the Northern District of Illinois, Eastern Division. Subsequently, on May 17, 2019, the Company and the other defendants in the case each filed a motion to dismiss the complaint for failure to state a cause of action upon which relief could be granted. On June 14, 2019, plaintiffs filed a motion to remand the case to state court. The Court then entered an order, on June 19, 2019, denying plaintiffs’ motion to remand, granting defendants’ motions to dismiss with respect to the additionally-named plaintiff, and continuing the motions to dismiss with respect to the originally-named plaintiff. On July 2, 2019, the Court entered an order remanding the case to state court and denying the defendants’ motions to dismiss without prejudice to renewal of the motions in state court. On September 5, 2019, plaintiff filed a motion to voluntarily dismiss the Company from the case without prejudice. The motion was granted by order of the Court dated October 10, 2019 and, as a result, the Company has been finally dismissed from the case without prejudice to plaintiff refiling the action.

- removed (2020-05-08):
[0000926326-19-000033:note_history:9]
On July 18, 2019, a putative class action lawsuit was filed against the Company and certain of its officers in the U.S. District Court for the Northern District of California. The complaint, captioned Bursick v. Omnicell, Inc. et al., Case No. 3:19-cv-04150, alleges that the defendants violated federal securities laws by making materially false and misleading statements beginning in October 2018 regarding revenue recognition, customer concerns about implementation issues, and a purported need to write off inventory. The plaintiff seeks unspecified monetary damages and other relief. On October 24, 2019, Frank Bursick was appointed Lead Plaintiff. The Court ordered Lead Plaintiff to file an amended complaint by November 28, 2019 and the Company to respond to the amended complaint by January 2, 2020. The Company intends to defend the lawsuit vigorously.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-05-08):
[0000926326-20-000014:note_history:10]
Omnicell, Inc. was incorporated in California in 1992 under the name Omnicell Technologies, Inc. and reincorporated in Delaware in 2001 as Omnicell, Inc. The Company’s major products are medication management automation solutions and adherence tools for healthcare systems and pharmacies, which are sold in its principal market, the healthcare industry. The Company’s market is primarily located in the United States and Europe. “Omnicell” or the “Company” collectively refer to Omnicell, Inc. and its subsidiaries.
  (was, 2019-11-01, similarity 0.7821):
[0000926326-19-000033:note_history:10]
Omnicell, Inc. was incorporated in California in 1992 under the name Omnicell Technologies, Inc. and reincorporated in Delaware in 2001 as Omnicell, Inc. The Company’s major products are medication and supply dispensing automation solutions, central pharmacy automation solutions, analytics software, and medication adherence solutions which are sold in its principal market, which is the healthcare industry. The Company’s market is primarily located in the United States and Europe. “Omnicell” or the “Company” collectively refer to Omnicell, Inc. and its subsidiaries.

- changed (2020-05-08):
[0000926326-20-000014:note_history:11]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of March 31, 2020 and December 31, 2019, the results of operations and comprehensive income for the three months ended March 31, 2020 and 2019, and cash flows for the three months ended March 31, 2020 and 2019. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s annual report on Form 10-K for the year ended December 31, 2019 filed with the SEC on February 26, 2020, except as discussed in the sections entitled “Allowance for Credit Losses” and “Recently Adopted Authoritative Guidance” below. The Company’s results of operations and comprehensive income for the three months ended March 31, 2020 and cash flows for the three months ended March 31, 2020 are not necessarily indicative of results that may be expected for the year ending December 31, 2020, or for any future period.
  (was, 2019-11-01, similarity 0.8924):
[0000926326-19-000033:note_history:11]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of September 30, 2019 and December 31, 2018, the results of operations and comprehensive income for the three and nine months ended September 30, 2019 and 2018, and cash flows for the nine months ended September 30, 2019 and 2018. Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States Generally Accepted Accounting Principles (“U.S. GAAP”) have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s annual report on Form 10-K for the year ended December 31, 2018 filed with the SEC on February 27, 2019, except as discussed in the sections entitled “Lessor Leases”, “Lessee Leases”, and “Recently Adopted Authoritative Guidance” below. The Company’s results of operations and comprehensive income for the three and nine months ended September 30, 2019 and cash flows for the nine months ended September 30, 2019 are not necessarily indicative of results that may be expected for the year ending December 31, 2019, or for any future period.

- changed (2020-05-08):
[0000926326-20-000014:note_history:12]
The Condensed Consolidated Financial Statements include the accounts of the Company and its wholly owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.
  (was, 2019-11-01, similarity 0.9664):
[0000926326-19-000033:note_history:12]
The Condensed Consolidated Financial Statements include the accounts of the Company and its subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.

- added (2020-05-08):
[0000926326-20-000014:note_history:13]
Reclassifications and Adjustments

- added (2020-05-08):
[0000926326-20-000014:note_history:14]
Certain prior-year amounts have been reclassified to conform with current-period presentation. This reclassification was a change in the presentation of certain items in the disaggregation of product revenues for the three months ended March 31, 2019 in Note 2, Revenues, of the Notes to Condensed Consolidated Financial Statements. This change was not deemed material and was included to conform with current-period classification and presentation.

- added (2020-05-08):
[0000926326-20-000014:note_history:15]
The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s Condensed Consolidated Financial Statements and accompanying Notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable, including any potential impacts arising from the novel coronavirus (“COVID-19”) pandemic. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates.

- added (2020-05-08):
[0000926326-20-000014:note_history:16]
The Company’s critical accounting policies are those that affect its financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition; accounts receivable and notes receivable from investment in sales-type leases; operating lease right-of-use assets and liabilities; inventory valuation; capitalized software development costs; impairment of goodwill and purchased intangibles; share-based compensation; and accounting for income taxes. As of March 31, 2020, the Company is not aware of any events or circumstances that would require an update to its estimates, judgments, or revisions to the carrying value of its assets or liabilities. Given the uncertainty surrounding the COVID-19 pandemic, events or circumstances may arise that could result in a change in estimates, judgments, or revisions to the carrying value of the Company’s assets or liabilities.

- added (2020-05-08):
[0000926326-20-000014:note_history:17]
The Company manages its operations as a single segment for the purposes of assessing performance and making operating decisions. The Company's Chief Operating Decision Maker ("CODM") is its Chief Executive Officer. The CODM

- added (2020-05-08):
[0000926326-20-000014:note_history:18]
allocates resources and evaluates the performance of the Company at the consolidated level using information about its revenues, gross profit, income from operations, and other key financial data. All significant operating decisions are based upon an analysis of the Company as one operating segment, which is the same as its reporting segment.

- added (2020-05-08):
[0000926326-20-000014:note_history:19]
Allowance for Credit Losses

- added (2020-05-08):
[0000926326-20-000014:note_history:20]
The Company is exposed to credit losses primarily through sales of its products and services, as well as its sales-type leasing arrangements. The Company performs credit evaluations of its customers’ financial condition in order to assess each customer’s ability to pay. These evaluations require significant judgment and are based on a variety of factors including, but not limited to, current economic trends, payment history, and a financial review of the customer. The Company continues to monitor customers’ creditworthiness on an ongoing basis.

- added (2020-05-08):
[0000926326-20-000014:note_history:21]
The Company maintains an allowance for credit losses for accounts receivable, unbilled receivables, and net investment in sales-type leases based on expected credit losses resulting from the inability of its customers to make required payments. The allowance for credit losses is measured using a loss rate method, considering factors such as customers’ credit risk, historical loss experience, current conditions, and forecasts. The allowance for credit losses is measured on a collective (pool) basis by aggregating customer balances with similar risk characteristics. The Company also records a specific allowance based on an analysis of individual past due balances or customer-specific information, such as a decline in creditworthiness or bankruptcy. Actual collection losses may differ from management’s estimates, and such differences could be material to the Company’s financial position and results of operations.

- added (2020-05-08):
[0000926326-20-000014:note_history:22]
The allowance for credit losses is presented in the Condensed Consolidated Balance Sheets as a deduction from the respective asset balance. The following table summarizes the Company’s allowance for credit losses by asset type:

- added (2020-05-08):
[0000926326-20-000014:note_history:23]
|  | March 31,2020 |  | December 31,2019 |
|  | (In thousands) |  |  |
| Allowance for credit losses: |  |  |  |  |
| Accounts receivable and unbilled receivables |  | $ | 3,869 |  |  | $ | 3,227 |  |
| Long-term unbilled receivables (1) | 33 |  |  | — |  |
| Net investment in sales-type leases (2) | 247 |  |  | 225 |  |

- added (2020-05-08):
[0000926326-20-000014:note_history:24]
(1) Included in other long-term assets in the Condensed Consolidated Balance Sheets.

- added (2020-05-08):
[0000926326-20-000014:note_history:25]
(2) Includes both current and long-term portions presented in other current assets and long-term investment in sales-type leases, net, respectively.

- added (2020-05-08):
[0000926326-20-000014:note_history:26]
Changes in the allowances for credit losses were not significant for the three months ended March 31, 2020 and 2019.

- changed (2020-05-08):
[0000926326-20-000014:note_history:27]
In August 2018, the FASB issued ASU 2018-15, Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract, to align the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software (and hosting arrangements that include an internal-use software license). The Company adopted ASU 2018-15 on January 1, 2020 on a prospective basis. The adoption of this guidance did not have a material impact on the Company’s Condensed Consolidated Financial Statements.
  (was, 2019-11-01, similarity 0.7761):
[0000926326-19-000033:note_history:27]
In August 2018, the FASB issued ASU 2018-15, Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract, to align the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software (and hosting arrangements that include an internal-use software license). ASU 2018-15 will be effective for the Company beginning January 1, 2020. The Company anticipates adopting ASU 2018-15 prospectively and does not expect the standard to have a material impact on its consolidated financial statements.

- added (2020-05-08):
[0000926326-20-000014:note_history:28]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326), Measurement of Credit Losses on Financial Instruments, that modifies or replaces existing models for trade and other receivables, debt securities, loans, and certain other financial instruments. For instruments measured at amortized cost, including trade and lease receivables, loans, and held-to-maturity debt securities, the standard replaced the current “incurred loss” approach with an “expected loss” model. Entities are required to estimate expected credit losses over the life of the instrument, considering available relevant information about the collectibility of cash flows, including information about past events, current conditions, and reasonable and supportable forecasts. The Company adopted the new standard on January 1, 2020 using the modified retrospective transition method, which resulted in the recognition of an immaterial cumulative-effect adjustment to retained earnings.

- changed (2020-05-08):
[0000926326-20-000014:note_history:29]
There was no recently issued and effective authoritative guidance that is expected to have a material impact on the Company’s Condensed Consolidated Financial Statements through the reporting date.
  (was, 2019-11-01, similarity 0.985):
[0000926326-19-000033:note_history:29]
There was no other recently issued and effective authoritative guidance that is expected to have a material impact on the Company’s Condensed Consolidated Financial Statements through the reporting date.

- removed (2020-05-08):
[0000926326-19-000033:note_history:30]
The Company's Chief Operating Decision Maker ("CODM") is its Chief Executive Officer. The CODM allocates resources and evaluates the performance of the Company using information about its revenues, gross profit, income from operations, and other key financial data. The Company previously operated and reported its business in two segments: Automation and Analytics, and Medication Adherence. In the fourth quarter of 2018, the Company introduced its vision of the Autonomous Pharmacy, a more fully automated and digitized system of medication management, in order to address changes in the healthcare industry as the Company executes on its plan to deliver end-to-end solutions with greater emphasis on automating manual processes for its customers. These industry changes include the continuing consolidation of healthcare systems, rising pharmaceutical costs, and increased scrutiny on controlled substances. In an effort to deliver on its strategic vision, the Company initiated a company-wide organizational realignment in the fourth quarter of 2018 to centrally manage its business operations, including the development and marketing of all of the Company’s products, sales and distribution, supply chain and inventory management, as well as regulatory and quality functions. As a result of this organizational realignment, all significant operating decisions are based upon an analysis of the Company as one operating segment. Therefore, effective January 1, 2019, the Company started reporting as only one operating segment, which is the same as the reporting segment. Accordingly, prior period information has been revised to conform with current period presentation.

- removed (2020-05-08):
[0000926326-19-000033:note_history:31]
The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s Condensed Consolidated Financial Statements and accompanying Notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. The Company’s critical accounting policies are those that affect its financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition; accounts receivable and notes receivable from investment in sales-type leases;

- removed (2020-05-08):
[0000926326-19-000033:note_history:32]
operating lease right-of-use assets and liabilities; inventory valuation; capitalized software development costs; impairment of goodwill; purchased intangibles and long-lived assets; share-based compensation; and accounting for income taxes.

- removed (2020-05-08):
[0000926326-19-000033:note_history:33]
Lessor Leases

- removed (2020-05-08):
[0000926326-19-000033:note_history:34]
The Company determines if an arrangement is a lease at inception. The transaction price is allocated to separate performance obligations, generally consisting of hardware and software products, installation, and post-installation technical support, proportionally based on the standalone selling price of each performance obligation. Standalone selling price is best evidenced by the price the Company charges for the good or service when selling it separately in similar circumstances to similar customers. Other than for the renewal of annual support services contracts, the Company’s products and services are not generally sold separately. The Company uses an amount discounted from the list price as a best estimated selling price.

- removed (2020-05-08):
[0000926326-19-000033:note_history:35]
Sales-Type Leases

- removed (2020-05-08):
[0000926326-19-000033:note_history:36]
The Company enters into non-cancelable sales-type lease arrangements, most of which do not have an option to extend the lease term. At the end of the lease term, the customer must either return the equipment or negotiate a new agreement, resulting in a new purchase or lease transaction. Failure of the customer to either return the equipment or negotiate a new agreement results in the contract becoming a month-to-month rental. Certain sales-type leases automatically renew for successive one year periods at the end of each lease term with written notice from the customer. The Company’s sales-type lease agreements do not contain any material residual value guarantees.

- removed (2020-05-08):
[0000926326-19-000033:note_history:37]
For sales-type leases, the Company recognizes revenues for its hardware and software products, net of lease execution costs, post-installation product maintenance, and technical support, at the net present value of the lease payment stream upon customer acceptance. The Company recognizes service revenues associated with the sales-type leases ratably over the term of the agreement in service revenues on the Condensed Consolidated Statements of Operations. The Company recognizes interest income from sales-type leases using the effective interest method. Both hardware and software revenues, and interest income from sales-types leases are recorded in product revenues on the Condensed Consolidated Statements of Operations.

- removed (2020-05-08):
[0000926326-19-000033:note_history:38]
The Company optimizes cash flows by selling a majority of its non-U.S. government sales-type leases to third-party leasing finance companies on a non-recourse basis. The Company has no obligation to the leasing company once the lease has been sold. Some of the Company's sales-type leases, mostly those relating to U.S. government hospitals which comprise approximately 54% of the lease receivable balance, are retained in-house.

- removed (2020-05-08):
[0000926326-19-000033:note_history:39]
Operating Leases

- removed (2020-05-08):
[0000926326-19-000033:note_history:40]
The Company entered into certain leasing agreements that were classified as operating leases prior to the adoption of the new lease accounting standard. Those agreements in place prior to January 1, 2019 will continue to be treated as operating leases, however any new leasing agreements entered into on or after January 1, 2019 under these programs are classified and accounted for as sales-type leases in accordance with the new lease accounting standard. The operating lease arrangements entered into prior to January 1, 2019 are non-cancelable, and most automatically renew for successive one year periods at the end of each lease term absent written notice from the customer. The Company’s operating lease agreements do not contain any material residual value guarantees.

- removed (2020-05-08):
[0000926326-19-000033:note_history:41]
For operating leases, rental income is generally recognized on a straight-line basis over the term of the associated lease, and recorded in services and other revenues in the Condensed Consolidated Statements of Operations. Leased assets under operating leases are carried at amortized cost net of accumulated depreciation in property and equipment, net on the Condensed Consolidated Balance Sheets. The depreciation expense of the leased assets is recognized on a straight-line basis over the contractual term of the associated lease, and recorded in cost of revenues in the Condensed Consolidated Statements of Operations.

- removed (2020-05-08):
[0000926326-19-000033:note_history:42]
Lessee Leases

- removed (2020-05-08):
[0000926326-19-000033:note_history:43]
The Company determines if an arrangement is a lease at inception. Operating lease right-of-use assets and liabilities are recognized at the commencement date based on the present value of lease payments over the lease term. As most of our lease contracts do not provide an implicit rate, the Company uses its incremental borrowing rate based on information available at the commencement date in determining the present value of the lease payments.

- removed (2020-05-08):
[0000926326-19-000033:note_history:44]
Many of the Company’s operating leases include an option to extend the lease. The specific terms and conditions of the extension options vary from lease to lease, but are consistent with standard industry practices in each area that the Company operates. The Company reviews each of its lease options at a time required by the terms of the lease contract, and notifies the lessor if it chooses to exercise the lease renewal option. Until the Company is reasonably certain that it will extend the lease contract, the renewal option periods will not be recognized as right-of-use assets or lease liabilities.

- removed (2020-05-08):
[0000926326-19-000033:note_history:45]
Certain leases include provisions for early termination, which allows the contract parties to terminate their obligations under the lease contract. The terms and conditions of the termination options vary by contract. When the Company has made a decision to exercise an early termination option, the right-of-use assets and associated lease liabilities are remeasured in accordance with the present value of the remaining cash flows under the lease contract.

- removed (2020-05-08):
[0000926326-19-000033:note_history:46]
Certain building lease agreements include rental payments subject to change annually based on fluctuations in various indexes (i.e. Consumer Price Index (“CPI”), Retail Price Index, and other international indexes). Certain data center lease agreements include rental payments subject to change based on usage and CPI fluctuations. The changes based on usage and indexes are treated as variable lease costs and recognized in the period in which the obligation for those payments was incurred.

- removed (2020-05-08):
[0000926326-19-000033:note_history:47]
The Company’s operating lease agreements do not contain any material residual value guarantees, restrictions, or restriction covenants.

- removed (2020-05-08):
[0000926326-19-000033:note_history:48]
In February 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2016-02, Leases (Topic 842). The FASB amended lease accounting requirements to begin recording assets and liabilities arising from most leases on the balance sheet. The new guidance also requires significant additional disclosures about the amount and timing of cash flows from leases. The Company adopted this new guidance on January 1, 2019. In July 2018, the FASB issued amendments in ASU 2018-11, which provide a transition election to not restate comparative periods for the effects of applying the new standard. This transition election permits entities to change the date of initial application to the beginning of the year of adoption and to recognize the effects of applying the new standard as a cumulative-effect adjustment to the opening balance of retained earnings. The Company has elected this transition approach as well as elected the package of practical expedients permitted under the transition guidance within the new standard, which will allow the Company to carry forward the historical lease classification of contracts entered into prior to January 1, 2019. As a result of electing the package of practical expedients described above, existing leases and related initial direct costs have not been reassessed prior to the effective date, and therefore, adoption of the lease standard did not have an impact on the Company’s previously reported consolidated financial statements.

- removed (2020-05-08):
[0000926326-19-000033:note_history:49]
The Company also elected the following practical expedients: (i) combining lease and non-lease components, (ii) leases with an initial term of 12 months or less are not recorded in the Condensed Consolidated Balance Sheets, and the associated lease payments are recognized in the Condensed Consolidated Statements of Operations on a straight-line basis over the lease term, and (iii) applying discount rates to operating leases using a portfolio approach.

- removed (2020-05-08):
[0000926326-19-000033:note_history:50]
From a lessor perspective, certain agreements that were previously classified as operating leases are classified as sales-type leases under the new lease accounting standard. The agreements in place prior to the adoption of the new lease accounting standard on January 1, 2019 will continue to be treated as operating leases.

- removed (2020-05-08):
[0000926326-19-000033:note_history:51]
The Company’s adoption of the new standard impacted the Condensed Consolidated Balance Sheets at the beginning of the period of adoption as follows:

- removed (2020-05-08):
[0000926326-19-000033:note_history:52]
|  | January 1, 2019 |
|  | Pre-ASC 842 Balances |  | ASC 842 Adoption Impact |  | Post-ASC 842 Balances |
|  | (In thousands) |
| Operating lease right-of-use assets | $ | — |  |  | $ | 66,008 |  |  | $ | 66,008 |  |
| Accrued liabilities (1) | 43,047 |  |  | 10,067 |  |  | 53,114 |  |
| Long-term operating lease liabilities | — |  |  | 59,791 |  |  | 59,791 |  |
| Other long-term liabilities (2) | 9,562 |  |  | (3,850 | ) |  | 5,712 |  |

- removed (2020-05-08):
[0000926326-19-000033:note_history:53]
| (1) | Adjustment represents the current portion of the operating lease liabilities of $10.3 million, and reclassification of exit cost obligations and deferred rent of $0.1 million and $0.1 million, respectively, to reduce the operating lease right-of-use assets. |

- removed (2020-05-08):
[0000926326-19-000033:note_history:54]
| (2) | Adjustment represents the reclassification of deferred rent to reduce the operating lease right-of-use assets. |

- removed (2020-05-08):
[0000926326-19-000033:note_history:55]
Adoption of the standard did not have an impact on the Company’s stockholders’ equity, Condensed Consolidated Statements of Operations, and Condensed Consolidated Statements of Cash Flows as of January 1, 2019.

- removed (2020-05-08):
[0000926326-19-000033:note_history:56]
In February 2018, the FASB issued ASU 2018-02, Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income, which permits the reclassification of the income tax effects of the Tax Cuts and Jobs Act of 2017 (the “Tax Act”) on items within accumulated other comprehensive income to retained earnings. These amounts are commonly

- removed (2020-05-08):
[0000926326-19-000033:note_history:57]
referred to as “stranded tax effects.” ASU 2018-02 is effective for the Company beginning January 1, 2019. The adoption of this guidance did not have a material effect on the Company’s consolidated financial statements and therefore no adjustment to retained earnings was made.

- removed (2020-05-08):
[0000926326-19-000033:note_history:58]
In June 2016, the FASB issued ASU No. 2016-13, Financial Instruments-Credit Losses (Topic 326), Measurement of Credit Losses on Financial Instruments, that modifies or replaces existing models for trade and other receivables, debt securities, loans, and certain other financial instruments. For instruments measured at amortized cost, including trade and lease receivables, loans and held-to-maturity debt securities, the standard will replace the current “incurred loss” approach with an “expected loss” model. Entities will be required to estimate expected credit losses over the life of the instrument, considering available relevant information about the collectibility of cash flows, including information about past events, current conditions, and reasonable and supportable forecasts. ASU 2016-13 will be effective for the Company beginning January 1, 2020. The Company is in the process of evaluating the appropriate changes to necessary processes and controls to support the adoption of the new standard. The Company is currently evaluating the impact ASU 2016-13 will have on its consolidated financial statements.


## omcl:ScheduleOfDebtIssuanceCostsNetTableTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2020-05-08):
[0000926326-20-000014:note_history:59]
The following table represents changes in the balance of the Company's deferred debt issuance costs:

- added (2020-05-08):
[0000926326-20-000014:note_history:60]
|  | (In thousands) |
| Balance as of December 31, 2019 | $ | 4,700 |  |
| Additions | — |  |
| Amortization | (241) |  |
| Balance as of March 31, 2020 | $ | 4,459 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2020-05-08):
[0000926326-20-000014:note_history:61]
Debt and Credit Agreements
2016 Senior Credit Facility

- added (2020-05-08):
[0000926326-20-000014:note_history:62]
On January 5, 2016, the Company entered into a $400.0 million senior secured credit facility pursuant to a credit agreement with certain lenders, Wells Fargo Securities, LLC as sole lead arranger, and Wells Fargo Bank, National Association

- changed (2020-05-08):
[0000926326-20-000014:note_history:63]
as administrative agent (as subsequently amended as discussed below, the “Prior Credit Agreement”). The Prior Credit Agreement provided for (a) a five-year revolving credit facility of $200.0 million, which was subsequently increased pursuant to the amendment discussed below (the “Prior Revolving Credit Facility”) and (b) a five-year $200.0 million term loan facility (the “Prior Term Loan Facility” and together with the Prior Revolving Credit Facility, the “Prior Facilities”). In addition, the Prior Credit Agreement included a letter of credit sub-limit of up to $10.0 million and a swing line loan sub-limit of up to $10.0 million. The Prior Credit Agreement had an expiration date of January 5, 2021, upon which date all remaining outstanding borrowings were due and payable.
  (was, 2019-11-01, similarity 0.7044):
[0000926326-19-000033:note_history:63]
Debt and Credit Agreements
On January 5, 2016, the Company entered into a $400.0 million senior secured credit facility pursuant to a credit agreement with certain lenders, Wells Fargo Securities, LLC as sole lead arranger, and Wells Fargo Bank, National Association as administrative agent (the “Credit Agreement”). The Credit Agreement provides for (a) a five-year revolving credit facility of $200.0 million, which was subsequently increased pursuant to the amendment discussed below (the “Revolving Credit Facility”) and (b) a five-year $200.0 million term loan facility (the “Term Loan Facility” and together with the Revolving Credit Facility, the “Facilities”). In addition, the Credit Agreement includes a letter of credit sub-limit of up to $10.0 million and a swing line loan sub-limit of up to $10.0 million. The Credit Agreement expires on January 5, 2021, upon which date all remaining outstanding borrowings are due and payable.

- changed (2020-05-08):
[0000926326-20-000014:note_history:64]
Loans under the Prior Facilities bore interest, at the Company’s option, at a rate equal to either (a) LIBOR, plus an applicable margin ranging from 1.50% to 2.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the Prior Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) LIBOR for an interest period of one month, plus an applicable margin ranging from 0.50% to 1.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the Prior Credit Agreement). Undrawn commitments under the Prior Revolving Credit Facility were subject to a commitment fee ranging from 0.20% to 0.35% per annum based on the Company’s Consolidated Total Net Leverage Ratio on the average daily unused portion of the Prior Revolving Credit Facility.
  (was, 2019-11-01, similarity 0.8501):
[0000926326-19-000033:note_history:64]
Loans under the Facilities bear interest, at the Company’s option, at a rate equal to either (a) the LIBOR Rate, plus an applicable margin ranging from 1.50% to 2.25% per annum based on the Company’s consolidated total net leverage ratio (as defined in the Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) LIBOR for an interest period of one month, plus an applicable margin ranging from 0.50% to 1.25% per annum based on the Company’s consolidated total net leverage ratio (as defined in the Credit Agreement). Undrawn commitments under the Revolving Credit Facility will be subject to a commitment fee ranging from 0.20% to 0.35% per annum based on the Company’s consolidated total net leverage ratio on the average daily unused portion of the Revolving Credit Facility. A letter of credit participation fee ranging from 1.50% to 2.25% per annum based on the Company’s consolidated total net leverage ratio will accrue on the average daily amount of letter of credit exposure.

- added (2020-05-08):
[0000926326-20-000014:note_history:65]
On each of April 11, 2017 and December 26, 2017, the parties entered into amendments to the Prior Credit Agreement. Under these amendments, the Prior Revolving Credit Facility was increased from $200.0 million to $315.0 million, and certain other modifications were made. In connection with the December 2017 amendment, the Company incurred and capitalized an additional $2.1 million of debt issuance costs.

- added (2020-05-08):
[0000926326-20-000014:note_history:66]
2019 Revolving Credit Facility

- added (2020-05-08):
[0000926326-20-000014:note_history:67]
On November 15, 2019, the Company refinanced the Prior Credit Agreement and entered into an Amended and Restated Credit Agreement (the “A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers and Wells Fargo Bank, National Association, as administrative agent. The A&R Credit Agreement replaced the Prior Credit Agreement and provides for (a) a five-year revolving credit facility of $500.0 million (the “Current Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million (the “Incremental Facility”). In addition, the A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The A&R Credit Agreement has an expiration date of November 15, 2024, upon which date all remaining outstanding borrowings will be due and payable.

- added (2020-05-08):
[0000926326-20-000014:note_history:68]
On November 15, 2019, the $80.0 million outstanding term loan balance under the Prior Facilities was transferred to the Current Revolving Credit Facility.

- added (2020-05-08):
[0000926326-20-000014:note_history:69]
Loans under the Current Revolving Credit Facility bear interest, at the Company’s option, at a rate equal to either (a) LIBOR, plus an applicable margin ranging from 1.25% to 2.00% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the A&R Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) LIBOR for an interest period of one month plus 1.00%, plus an applicable margin ranging from 0.25% to 1.00% per annum based on the Company’s Consolidated Total Net Leverage Ratio. Undrawn commitments under the Current Revolving Credit Facility are subject to a commitment fee ranging from 0.15% to 0.30% per annum based on the Company’s Consolidated Total Net Leverage Ratio on the average daily unused portion of the Current Revolving Credit Facility. The applicable margin for and certain other terms of any term loans under the Incremental Facility will be determined prior to the incurrence of such loans. The Company is permitted to make voluntary prepayments at any time without payment of a premium or penalty.

- changed (2020-05-08):
[0000926326-20-000014:note_history:70]
The A&R Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends, and other distributions. The A&R Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum consolidated total net leverage ratio and maintain a minimum interest coverage ratio. In addition, the A&R Credit Agreement contains certain customary events of default including, but not limited to, failure to pay interest, principal and fees or other amounts when due, material misrepresentations or misstatements in any representation or warranty, covenant defaults, certain cross defaults to other material indebtedness, certain judgment defaults and events of bankruptcy. The Company’s obligations under the A&R Credit Agreement and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and such subsidiary guarantors’ assets. In connection with entering into the A&R Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a reaffirmation agreement, which amends certain terms of the existing collateral agreement and
  (was, 2019-11-01, similarity 0.7673):
[0000926326-19-000033:note_history:70]
The Credit Agreement contains customary representations and warranties, and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends, and other distributions. The Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum consolidated total leverage ratio and maintain a minimum fixed charge coverage ratio. The Company’s obligations under the Credit Agreement, and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender), are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and the subsidiary guarantors’ assets. In connection with entering into the Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a collateral agreement and subsidiary guaranty agreement.

- added (2020-05-08):
[0000926326-20-000014:note_history:71]
reaffirms their obligations under the existing guaranty agreement. The Company was in full compliance with all covenants as of March 31, 2020.

- added (2020-05-08):
[0000926326-20-000014:note_history:72]
The refinancing of the Prior Credit Agreement was evaluated in accordance with Accounting Standards Codification (“ASC”) 470-50, Debt - Modifications and Extinguishments. In determining whether the refinancing was to be accounted for as a debt extinguishment or a debt modification, the Company considered whether lenders within the syndicate remained the same or changed and whether the changes in debt terms were substantial. This assessment was performed on an individual lender basis within the syndicate. As a result, the refinancing was accounted for as a modification with the exception of certain lenders that exited the syndicate. The exit of certain lenders resulted in an immaterial write-off of existing unamortized debt issuance costs. The remaining unamortized debt issuance costs related to debt modification, along with the new deferred costs, will be amortized over the remaining term of the A&R Credit Agreement.

- added (2020-05-08):
[0000926326-20-000014:note_history:73]
In connection with the A&R Credit Agreement, the Company incurred and capitalized an additional $2.3 million of debt issuance costs. The debt issuance costs are being amortized to interest expense using the straight-line method through 2024. Amortization expense related to debt issuance costs was approximately $0.2 million and $0.6 million for the three months ended March 31, 2020 and 2019, respectively.

- added (2020-05-08):
[0000926326-20-000014:note_history:74]
Interest expense (exclusive of fees and debt issuance cost amortization) was approximately $0.2 million and $1.3 million for the three months ended March 31, 2020 and 2019, respectively.

- added (2020-05-08):
[0000926326-20-000014:note_history:75]
The following table represents changes in the carrying amount of the Company’s debt obligations:

- added (2020-05-08):
[0000926326-20-000014:note_history:76]
|  | Current Revolving Credit Facility |
|  | (In thousands) |
| Balance as of December 31, 2019 | $ | 50,000 |  |
| Proceeds | — |  |
| Repayments | (50,000) |  |
| Balance as of March 31, 2020 | $ | — |  |

- added (2020-05-08):
[0000926326-20-000014:note_history:77]
The following table represents changes in the balance of the Company's deferred debt issuance costs:

- added (2020-05-08):
[0000926326-20-000014:note_history:78]
|  | (In thousands) |
| Balance as of December 31, 2019 | $ | 4,700 |  |
| Additions | — |  |
| Amortization | (241) |  |
| Balance as of March 31, 2020 | $ | 4,459 |  |

- removed (2020-05-08):
[0000926326-19-000033:note_history:79]
The Company is permitted to make voluntary prepayments at any time without payment of a premium or penalty, except for any amounts relating to the LIBOR breakage indemnity described in the Credit Agreement. The Company is

- removed (2020-05-08):
[0000926326-19-000033:note_history:80]
required to make mandatory prepayments under the Term Loan Facility with (a) net cash proceeds from any issuances of debt (other than certain permitted debt) and (b) net cash proceeds from certain asset dispositions (other than certain permitted asset dispositions) and insurance and condemnation events (subject to reinvestment rights and certain other exceptions). Loans under the Term Loan Facility will amortize in quarterly installments, equal to 5% per annum of the original principal amount thereof during the first two years, which shall increase to 10% per annum during the third and fourth years, and 15% per annum during the fifth year, with the remaining balance payable on January 5, 2021. The Company is required to make mandatory prepayments under the Revolving Credit Facility if at any time the aggregate outstanding principal amount of loans together with the total amount of outstanding letters of credit exceeds the aggregate commitments, with such mandatory prepayment to be equal to the amount of such excess.

- removed (2020-05-08):
[0000926326-19-000033:note_history:81]
On April 11, 2017, the parties entered into the First Amendment to Credit Agreement and Collateral Agreement (the “Amended Credit Agreement”). Under this amendment, (i) the maximum capital expenditures limit in any fiscal year for property, plant, and equipment and software development increased from $35.0 million to $45.0 million, and (ii) the maximum limit for non-permitted investments increased from $10.0 million to $20.0 million.

- removed (2020-05-08):
[0000926326-19-000033:note_history:82]
On December 26, 2017, the parties entered into an amendment (the “Amendment”) to the Amended Credit Agreement. Pursuant to the Amendment, the Revolving Credit Facility provided for under the Amended Credit Agreement, was increased from $200.0 million to $315.0 million, and certain other modifications to the Amended Credit Agreement were made, including amendments to certain negative covenants.

- removed (2020-05-08):
[0000926326-19-000033:note_history:83]
In connection with these Facilities, the Company incurred $10.1 million of debt issuance costs. The debt issuance costs were capitalized and presented as a direct deduction from the carrying amount of that debt liability. The debt issuance costs are being amortized to interest expense using the straight line method from issuance date through 2021. Interest expense (exclusive of fees and issuance cost amortization) was approximately $0.8 million and $1.9 million for the three months ended September 30, 2019 and 2018, respectively, and approximately $3.0 million and $5.7 million for the nine months ended September 30, 2019 and 2018, respectively. Amortization expense related to fees and issuance cost was approximately $0.6 million for both the three months ended September 30, 2019 and 2018, and approximately $1.7 million for both the nine months ended September 30, 2019 and 2018. The Company was in compliance with all covenants as of September 30, 2019 and December 31, 2018.

- removed (2020-05-08):
[0000926326-19-000033:note_history:84]
During the nine months ended September 30, 2019, the Company repaid $60.0 million under these Facilities.

- removed (2020-05-08):
[0000926326-19-000033:note_history:85]
The components of the Company’s debt obligations as of September 30, 2019 and December 31, 2018 were as follows:

- removed (2020-05-08):
[0000926326-19-000033:note_history:86]
|  | December 31, 2018 |  | Borrowings |  | Repayment / Amortization |  | September 30, 2019 |
|  | (In thousands) |
| Term loan facility | $ | 140,000 |  |  | $ | — |  |  | $ | (60,000 | ) |  | $ | 80,000 |  |
| Revolving credit facility | — |  |  | — |  |  | — |  |  | — |  |
| Total debt under the facilities | 140,000 |  |  | — |  |  | (60,000 | ) |  | 80,000 |  |
| Less: Deferred issuance cost | (4,583 | ) |  | — |  |  | 1,718 |  |  | (2,865 | ) |
| Total long-term debt, net of deferred issuance cost | $ | 135,417 |  |  | $ | — |  |  | $ | (58,282 | ) |  | $ | 77,135 |  |

- removed (2020-05-08):
[0000926326-19-000033:note_history:87]
As of September 30, 2019, the carrying amount of debt of $80.0 million approximates the comparable fair value of $79.9 million. The Company’s debt facilities are classified as a Level 3 in the fair value hierarchy. The calculation of the fair value is based on a discounted cash flow model using observable market inputs and taking into consideration variables such as

- removed (2020-05-08):
[0000926326-19-000033:note_history:88]
interest rate changes, comparable instruments and long-term credit ratings. There have been no significant changes in the assumptions used as of September 30, 2019 as compared to December 31, 2018.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2020-05-08):
[0000926326-20-000014:note_history:89]
The following table represents changes in the carrying amount of the Company’s debt obligations:

- added (2020-05-08):
[0000926326-20-000014:note_history:90]
|  | Current Revolving Credit Facility |
|  | (In thousands) |
| Balance as of December 31, 2019 | $ | 50,000 |  |
| Proceeds | — |  |
| Repayments | (50,000) |  |
| Balance as of March 31, 2020 | $ | — |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2020-05-08):
[0000926326-19-000033:note_history:91]
The components of the Company’s debt obligations as of September 30, 2019 and December 31, 2018 were as follows:

- removed (2020-05-08):
[0000926326-19-000033:note_history:92]
|  | December 31, 2018 |  | Borrowings |  | Repayment / Amortization |  | September 30, 2019 |
|  | (In thousands) |
| Term loan facility | $ | 140,000 |  |  | $ | — |  |  | $ | (60,000 | ) |  | $ | 80,000 |  |
| Revolving credit facility | — |  |  | — |  |  | — |  |  | — |  |
| Total debt under the facilities | 140,000 |  |  | — |  |  | (60,000 | ) |  | 80,000 |  |
| Less: Deferred issuance cost | (4,583 | ) |  | — |  |  | 1,718 |  |  | (2,865 | ) |
| Total long-term debt, net of deferred issuance cost | $ | 135,417 |  |  | $ | — |  |  | $ | (58,282 | ) |  | $ | 77,135 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2020-05-08):
[0000926326-20-000014:note_history:93]
Revenue Recognition

- added (2020-05-08):
[0000926326-20-000014:note_history:94]
The Company earns revenues from sales of its products and related services, which are sold in the healthcare industry, its principal market. The Company’s customer arrangements typically include one or more of the following performance obligations:

- added (2020-05-08):
[0000926326-20-000014:note_history:95]
Products. Software-enabled equipment that manages and regulates the storage and dispensing of pharmaceuticals, consumable blister cards and packaging equipment and other medical supplies.

- added (2020-05-08):
[0000926326-20-000014:note_history:96]
Software. Additional software applications that enable incremental functionality of the Company’s equipment or services.

- added (2020-05-08):
[0000926326-20-000014:note_history:97]
Installation. Installation of equipment as integrated systems at customer sites.

- added (2020-05-08):
[0000926326-20-000014:note_history:98]
Post-installation technical support. Phone support, on-site service, parts, and access to unspecified software updates and enhancements, if and when available.

- added (2020-05-08):
[0000926326-20-000014:note_history:99]
Professional services. Other customer services, such as training and consulting.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-05-08):
[0000926326-20-000014:note_history:100]
The Company earns revenues from sales of its products and related services, which are sold in the healthcare industry, its principal market. The Company’s customer arrangements typically include one or more of the following performance obligations:
  (was, 2019-11-01, similarity 0.8561):
[0000926326-19-000033:note_history:100]
The Company earns revenues from sales of its medication and supply dispensing automation systems, along with consumables and related services, which are sold in the healthcare industry, its principal market. The Company’s customer arrangements typically include one or more of the following performance obligations:

- changed (2020-05-08):
[0000926326-20-000014:note_history:101]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”). GPOs are often owned fully or in part by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs were $2.9 million and $2.2 million for the three months ended March 31, 2020 and 2019, respectively.
  (was, 2019-11-01, similarity 0.8954):
[0000926326-19-000033:note_history:101]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”). GPOs are often owned fully or in part by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs were $2.8 million and $2.2 million for the three months ended September 30, 2019 and 2018, respectively, and $7.6 million and $6.2 million for the nine months ended September 30, 2019 and 2018, respectively.

- changed (2020-05-08):
[0000926326-20-000014:note_history:102]
The following table summarizes the Company’s product revenues disaggregated by revenue type for the three months ended March 31, 2020 and 2019:
  (was, 2019-11-01, similarity 0.9329):
[0000926326-19-000033:note_history:102]
The following table summarizes the Company’s product revenues disaggregated by revenue type for the three and nine months ended September 30, 2019 and 2018:

- changed (2020-05-08):
[0000926326-20-000014:note_history:103]
|  | Three Months Ended March 31, |  |  |  |  |  |  |
|  | 2020 |  | 2019 |  |  |  |  |
|  | (In thousands) |  |  |  |  |  |  |
| Hardware and software | $ | 142,433 |  |  | $ | 118,814 |  |  |  |  |  |
| Consumables | 23,270 |  |  | 23,707 |  |  |  |  |  |
| Other | 4,370 |  |  | 3,089 |  |  |  |  |  |
| Total product revenues | $ | 170,073 |  |  | $ | 145,610 |  |  |  |  |  |
  (was, 2019-11-01, similarity 0.6032):
[0000926326-19-000033:note_history:103]
|  | Three months ended September 30, |  | Nine months ended September 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  | (In thousands) |
| Hardware and software | $ | 144,305 |  |  | $ | 125,733 |  |  | $ | 399,548 |  |  | $ | 345,215 |  |
| Consumables | 19,875 |  |  | 19,848 |  |  | 60,378 |  |  | 58,956 |  |
| Other | 4,308 |  |  | 4,128 |  |  | 12,551 |  |  | 10,833 |  |
| Total product revenues | $ | 168,488 |  |  | $ | 149,709 |  |  | $ | 472,477 |  |  | $ | 415,004 |  |

- changed (2020-05-08):
[0000926326-20-000014:note_history:104]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location, for the three months ended March 31, 2020 and 2019:
  (was, 2019-11-01, similarity 0.9493):
[0000926326-19-000033:note_history:104]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location, for the three and nine months ended September 30, 2019 and 2018:

- changed (2020-05-08):
[0000926326-20-000014:note_history:105]
|  | Three Months Ended March 31, |  |  |  |  |  |  |
|  | 2020 |  | 2019 |  |  |  |  |
|  | (In thousands) |  |  |  |  |  |  |
| United States | $ | 207,734 |  |  | $ | 180,020 |  |  |  |  |  |
| Rest of world (1) | 21,952 |  |  | 22,497 |  |  |  |  |  |
| Total revenues | $ | 229,686 |  |  | $ | 202,517 |  |  |  |  |  |
  (was, 2019-11-01, similarity 0.6691):
[0000926326-19-000033:note_history:105]
|  | Three months ended September 30, |  | Nine months ended September 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  | (In thousands) |
| United States | $ | 206,709 |  |  | $ | 180,635 |  |  | $ | 582,540 |  |  | $ | 502,481 |  |
| Rest of world (1) | 22,096 |  |  | 23,632 |  |  | 66,195 |  |  | 73,078 |  |
| Total revenues | $ | 228,805 |  |  | $ | 204,267 |  |  | $ | 648,735 |  |  | $ | 575,559 |  |

- changed (2020-05-08):
[0000926326-20-000014:note_history:106]
(1) No individual country represented more than 10% of total revenues.
  (was, 2019-11-01, similarity 0.8079):
[0000926326-19-000033:note_history:106]
| (1) | No individual country represented more than 10% of the respective totals. |

- added (2020-05-08):
[0000926326-20-000014:note_history:107]
|  | March 31,2020 |  | December 31,2019 |
|  | (In thousands) |  |  |
| Short-term unbilled receivables, net (1) | $ | 10,048 |  |  | $ | 11,707 |  |
| Long-term unbilled receivables, net (2) | 14,338 |  |  | 12,260 |  |
| Total contract assets |  | $ | 24,386 |  |  | $ | 23,967 |  |
| Short-term deferred revenues, net |  | $ | 108,602 |  |  | $ | 90,894 |  |
| Long-term deferred revenues |  | 6,019 |  |  | 7,083 |  |
| Total contract liabilities |  | $ | 114,621 |  |  | $ | 97,977 |  |

- added (2020-05-08):
[0000926326-20-000014:note_history:108]
_________________________________________________

- added (2020-05-08):
[0000926326-20-000014:note_history:109]
(1) Included in accounts receivable and unbilled receivables in the Condensed Consolidated Balance Sheets.

- added (2020-05-08):
[0000926326-20-000014:note_history:110]
(2) Included in other long-term assets in the Condensed Consolidated Balance Sheets.

- changed (2020-05-08):
[0000926326-20-000014:note_history:111]
Short-term deferred revenues of $108.6 million and $90.9 million include deferred revenues from product sales and service contracts, net of deferred cost of sales of $15.4 million and $13.1 million, as of March 31, 2020 and December 31, 2019, respectively. The short-term deferred revenues from product sales relate to delivered and invoiced products, pending installation and acceptance, expected to occur within the next twelve months. During the three months ended March 31, 2020, the Company recognized revenues of $43.4 million that were included in the corresponding gross short-term deferred revenues balance of $104.0 million as of December 31, 2019.
  (was, 2019-11-01, similarity 0.9255):
[0000926326-19-000033:note_history:111]
Short-term deferred revenues of $88.2 million and $81.8 million include deferred revenues from product sales and service contracts, net of deferred cost of sales, of $14.3 million and $11.1 million as of September 30, 2019 and December 31, 2018, respectively. The short-term deferred revenues from product sales relate to delivered and invoiced products, pending installation and acceptance, expected to occur within the next twelve months. During the three and nine months ended September 30, 2019, the Company recognized revenues of $4.8 million and $69.8 million that were included in the corresponding gross short-term deferred revenues balance of $92.9 million as of December 31, 2018.

- added (2020-05-08):
[0000926326-20-000014:note_history:112]
Long-term deferred revenues include deferred revenues from service contracts of $6.0 million and $7.1 million as of March 31, 2020 and December 31, 2019, respectively. Remaining performance obligations primarily relate to maintenance contracts and are recognized ratably over the remaining term of the contract, generally not more than five years.

- changed (2020-05-08):
[0000926326-20-000014:note_history:113]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three months ended March 31, 2020 and 2019. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable balance as of March 31, 2020 and December 31, 2019.
  (was, 2019-11-01, similarity 0.7723):
[0000926326-19-000033:note_history:113]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three and nine months ended September 30, 2019 and 2018. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable as of September 30, 2019 and December 31, 2018.

- removed (2020-05-08):
[0000926326-19-000033:note_history:114]
|  | September 30, 2019 |  | December 31, 2018 |
|  | (In thousands) |
| Short-term unbilled receivables - included in accounts receivable and unbilled receivables | $ | 15,524 |  |  | $ | 9,191 |  |
| Long-term unbilled receivables - included in other long-term assets | 12,794 |  |  | 16,481 |  |
| Total contract assets | $ | 28,318 |  |  | $ | 25,672 |  |
| Short-term deferred revenues, net | $ | 88,205 |  |  | $ | 81,835 |  |
| Long-term deferred revenues | 7,979 |  |  | 10,582 |  |
| Total contract liabilities | $ | 96,184 |  |  | $ | 92,417 |  |

- removed (2020-05-08):
[0000926326-19-000033:note_history:115]
Long-term deferred revenues include deferred revenues from service contracts of $8.0 million and $10.6 million as of September 30, 2019 and December 31, 2018, respectively. Remaining performance obligations primarily relate to maintenance contracts and are recognized ratably over the remaining term of the contract, generally not more than five years.
