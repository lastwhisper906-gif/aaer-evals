# OMCL notes — 0000926326-20-000014


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000926326-20-000014:notes:1]
[same as prior period, unchanged from 0000926326-19-000033:notes:1]

[0000926326-20-000014:notes:2]
Omnicell, Inc. was incorporated in California in 1992 under the name Omnicell Technologies, Inc. and reincorporated in Delaware in 2001 as Omnicell, Inc. The Company’s major products are medication management automation solutions and adherence tools for healthcare systems and pharmacies, which are sold in its principal market, the healthcare industry. The Company’s market is primarily located in the United States and Europe. “Omnicell” or the “Company” collectively refer to Omnicell, Inc. and its subsidiaries.

[0000926326-20-000014:notes:3]
[same as prior period, unchanged from 0000926326-19-000033:notes:3]

[0000926326-20-000014:notes:4]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of March 31, 2020 and December 31, 2019, the results of operations and comprehensive income for the three months ended March 31, 2020 and 2019, and cash flows for the three months ended March 31, 2020 and 2019. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s annual report on Form 10-K for the year ended December 31, 2019 filed with the SEC on February 26, 2020, except as discussed in the sections entitled “Allowance for Credit Losses” and “Recently Adopted Authoritative Guidance” below. The Company’s results of operations and comprehensive income for the three months ended March 31, 2020 and cash flows for the three months ended March 31, 2020 are not necessarily indicative of results that may be expected for the year ending December 31, 2020, or for any future period.

[0000926326-20-000014:notes:5]
[same as prior period, unchanged from 0000926326-19-000033:notes:5]

[0000926326-20-000014:notes:6]
The Condensed Consolidated Financial Statements include the accounts of the Company and its wholly owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.

[0000926326-20-000014:notes:7]
Reclassifications and Adjustments

[0000926326-20-000014:notes:8]
Certain prior-year amounts have been reclassified to conform with current-period presentation. This reclassification was a change in the presentation of certain items in the disaggregation of product revenues for the three months ended March 31, 2019 in Note 2, Revenues, of the Notes to Condensed Consolidated Financial Statements. This change was not deemed material and was included to conform with current-period classification and presentation.

[0000926326-20-000014:notes:9]
[same as prior period, unchanged from 0000926326-19-000033:notes:9]

[0000926326-20-000014:notes:10]
The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s Condensed Consolidated Financial Statements and accompanying Notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable, including any potential impacts arising from the novel coronavirus (“COVID-19”) pandemic. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates.

[0000926326-20-000014:notes:11]
The Company’s critical accounting policies are those that affect its financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition; accounts receivable and notes receivable from investment in sales-type leases; operating lease right-of-use assets and liabilities; inventory valuation; capitalized software development costs; impairment of goodwill and purchased intangibles; share-based compensation; and accounting for income taxes. As of March 31, 2020, the Company is not aware of any events or circumstances that would require an update to its estimates, judgments, or revisions to the carrying value of its assets or liabilities. Given the uncertainty surrounding the COVID-19 pandemic, events or circumstances may arise that could result in a change in estimates, judgments, or revisions to the carrying value of the Company’s assets or liabilities.

[0000926326-20-000014:notes:12]
[same as prior period, unchanged from 0000926326-19-000033:notes:7]

[0000926326-20-000014:notes:13]
The Company manages its operations as a single segment for the purposes of assessing performance and making operating decisions. The Company's Chief Operating Decision Maker ("CODM") is its Chief Executive Officer. The CODM

[0000926326-20-000014:notes:14]
allocates resources and evaluates the performance of the Company at the consolidated level using information about its revenues, gross profit, income from operations, and other key financial data. All significant operating decisions are based upon an analysis of the Company as one operating segment, which is the same as its reporting segment.

[0000926326-20-000014:notes:15]
Allowance for Credit Losses

[0000926326-20-000014:notes:16]
The Company is exposed to credit losses primarily through sales of its products and services, as well as its sales-type leasing arrangements. The Company performs credit evaluations of its customers’ financial condition in order to assess each customer’s ability to pay. These evaluations require significant judgment and are based on a variety of factors including, but not limited to, current economic trends, payment history, and a financial review of the customer. The Company continues to monitor customers’ creditworthiness on an ongoing basis.

[0000926326-20-000014:notes:17]
The Company maintains an allowance for credit losses for accounts receivable, unbilled receivables, and net investment in sales-type leases based on expected credit losses resulting from the inability of its customers to make required payments. The allowance for credit losses is measured using a loss rate method, considering factors such as customers’ credit risk, historical loss experience, current conditions, and forecasts. The allowance for credit losses is measured on a collective (pool) basis by aggregating customer balances with similar risk characteristics. The Company also records a specific allowance based on an analysis of individual past due balances or customer-specific information, such as a decline in creditworthiness or bankruptcy. Actual collection losses may differ from management’s estimates, and such differences could be material to the Company’s financial position and results of operations.

[0000926326-20-000014:notes:18]
The allowance for credit losses is presented in the Condensed Consolidated Balance Sheets as a deduction from the respective asset balance. The following table summarizes the Company’s allowance for credit losses by asset type:

[0000926326-20-000014:notes:19]
|  | March 31,2020 |  | December 31,2019 |
|  | (In thousands) |  |  |
| Allowance for credit losses: |  |  |  |  |
| Accounts receivable and unbilled receivables |  | $ | 3,869 |  |  | $ | 3,227 |  |
| Long-term unbilled receivables (1) | 33 |  |  | — |  |
| Net investment in sales-type leases (2) | 247 |  |  | 225 |  |

[0000926326-20-000014:notes:20]
[same as prior period, unchanged from 0000926326-19-000033:notes:33]

[0000926326-20-000014:notes:21]
(1) Included in other long-term assets in the Condensed Consolidated Balance Sheets.

[0000926326-20-000014:notes:22]
(2) Includes both current and long-term portions presented in other current assets and long-term investment in sales-type leases, net, respectively.

[0000926326-20-000014:notes:23]
Changes in the allowances for credit losses were not significant for the three months ended March 31, 2020 and 2019.

[0000926326-20-000014:notes:24]
[same as prior period, unchanged from 0000926326-19-000033:notes:27]

[0000926326-20-000014:notes:25]
In August 2018, the FASB issued ASU 2018-15, Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract, to align the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software (and hosting arrangements that include an internal-use software license). The Company adopted ASU 2018-15 on January 1, 2020 on a prospective basis. The adoption of this guidance did not have a material impact on the Company’s Condensed Consolidated Financial Statements.

[0000926326-20-000014:notes:26]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326), Measurement of Credit Losses on Financial Instruments, that modifies or replaces existing models for trade and other receivables, debt securities, loans, and certain other financial instruments. For instruments measured at amortized cost, including trade and lease receivables, loans, and held-to-maturity debt securities, the standard replaced the current “incurred loss” approach with an “expected loss” model. Entities are required to estimate expected credit losses over the life of the instrument, considering available relevant information about the collectibility of cash flows, including information about past events, current conditions, and reasonable and supportable forecasts. The Company adopted the new standard on January 1, 2020 using the modified retrospective transition method, which resulted in the recognition of an immaterial cumulative-effect adjustment to retained earnings.

[0000926326-20-000014:notes:27]
[same as prior period, unchanged from 0000926326-19-000033:notes:39]

[0000926326-20-000014:notes:28]
There was no recently issued and effective authoritative guidance that is expected to have a material impact on the Company’s Condensed Consolidated Financial Statements through the reporting date.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000926326-20-000014:notes:29]
[same as prior period, unchanged from 0000926326-19-000033:notes:43]

[0000926326-20-000014:notes:30]
The Company earns revenues from sales of its products and related services, which are sold in the healthcare industry, its principal market. The Company’s customer arrangements typically include one or more of the following performance obligations:

[0000926326-20-000014:notes:31]
[same as prior period, unchanged from 0000926326-19-000033:notes:45]

[0000926326-20-000014:notes:32]
[same as prior period, unchanged from 0000926326-19-000033:notes:46]

[0000926326-20-000014:notes:33]
[same as prior period, unchanged from 0000926326-19-000033:notes:47]

[0000926326-20-000014:notes:34]
[same as prior period, unchanged from 0000926326-19-000033:notes:48]

[0000926326-20-000014:notes:35]
[same as prior period, unchanged from 0000926326-19-000033:notes:49]

[0000926326-20-000014:notes:36]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”). GPOs are often owned fully or in part by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs were $2.9 million and $2.2 million for the three months ended March 31, 2020 and 2019, respectively.

[0000926326-20-000014:notes:37]
[same as prior period, unchanged from 0000926326-19-000033:notes:51]

[0000926326-20-000014:notes:38]
The following table summarizes the Company’s product revenues disaggregated by revenue type for the three months ended March 31, 2020 and 2019:

[0000926326-20-000014:notes:39]
|  | Three Months Ended March 31, |  |  |  |  |  |  |
|  | 2020 |  | 2019 |  |  |  |  |
|  | (In thousands) |  |  |  |  |  |  |
| Hardware and software | $ | 142,433 |  |  | $ | 118,814 |  |  |  |  |  |
| Consumables | 23,270 |  |  | 23,707 |  |  |  |  |  |
| Other | 4,370 |  |  | 3,089 |  |  |  |  |  |
| Total product revenues | $ | 170,073 |  |  | $ | 145,610 |  |  |  |  |  |

[0000926326-20-000014:notes:40]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location, for the three months ended March 31, 2020 and 2019:

[0000926326-20-000014:notes:41]
|  | Three Months Ended March 31, |  |  |  |  |  |  |
|  | 2020 |  | 2019 |  |  |  |  |
|  | (In thousands) |  |  |  |  |  |  |
| United States | $ | 207,734 |  |  | $ | 180,020 |  |  |  |  |  |
| Rest of world (1) | 21,952 |  |  | 22,497 |  |  |  |  |  |
| Total revenues | $ | 229,686 |  |  | $ | 202,517 |  |  |  |  |  |

[0000926326-20-000014:notes:42]
(1) No individual country represented more than 10% of total revenues.

[0000926326-20-000014:notes:43]
[same as prior period, unchanged from 0000926326-19-000033:notes:57]

[0000926326-20-000014:notes:44]
[same as prior period, unchanged from 0000926326-19-000033:notes:58]

[0000926326-20-000014:notes:45]
|  | March 31,2020 |  | December 31,2019 |
|  | (In thousands) |  |  |
| Short-term unbilled receivables, net (1) | $ | 10,048 |  |  | $ | 11,707 |  |
| Long-term unbilled receivables, net (2) | 14,338 |  |  | 12,260 |  |
| Total contract assets |  | $ | 24,386 |  |  | $ | 23,967 |  |
| Short-term deferred revenues, net |  | $ | 108,602 |  |  | $ | 90,894 |  |
| Long-term deferred revenues |  | 6,019 |  |  | 7,083 |  |
| Total contract liabilities |  | $ | 114,621 |  |  | $ | 97,977 |  |

[0000926326-20-000014:notes:46]
(1) Included in accounts receivable and unbilled receivables in the Condensed Consolidated Balance Sheets.

[0000926326-20-000014:notes:47]
(2) Included in other long-term assets in the Condensed Consolidated Balance Sheets.

[0000926326-20-000014:notes:48]
[same as prior period, unchanged from 0000926326-19-000033:notes:60]

[0000926326-20-000014:notes:49]
Short-term deferred revenues of $108.6 million and $90.9 million include deferred revenues from product sales and service contracts, net of deferred cost of sales of $15.4 million and $13.1 million, as of March 31, 2020 and December 31, 2019, respectively. The short-term deferred revenues from product sales relate to delivered and invoiced products, pending installation and acceptance, expected to occur within the next twelve months. During the three months ended March 31, 2020, the Company recognized revenues of $43.4 million that were included in the corresponding gross short-term deferred revenues balance of $104.0 million as of December 31, 2019.

[0000926326-20-000014:notes:50]
Long-term deferred revenues include deferred revenues from service contracts of $6.0 million and $7.1 million as of March 31, 2020 and December 31, 2019, respectively. Remaining performance obligations primarily relate to maintenance contracts and are recognized ratably over the remaining term of the contract, generally not more than five years.

[0000926326-20-000014:notes:51]
[same as prior period, unchanged from 0000926326-19-000033:notes:63]

[0000926326-20-000014:notes:52]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three months ended March 31, 2020 and 2019. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable balance as of March 31, 2020 and December 31, 2019.


## us-gaap:EarningsPerShareTextBlock

[0000926326-20-000014:notes:53]
Net Income Per ShareBasic net income per share is computed by dividing net income for the period by the weighted-average number of shares outstanding during the period. In periods of net loss, all potential common shares are anti-dilutive, so diluted net loss per share equals the basic net loss per share. In periods of net income, diluted net income per share is computed by dividing net income for the period by the basic weighted-average number of shares plus any dilutive potential common stock outstanding during the period. Potential common stock includes the effect of outstanding dilutive stock options, restricted stock awards, and restricted stock units computed using the treasury stock method. Any anti-dilutive weighted-average dilutive shares related to stock award plans are excluded from the computation of the diluted net income per share. 
The basic and diluted net income per share calculations for the three months ended March 31, 2020 and 2019 were as follows:

[0000926326-20-000014:notes:54]
|  | Three Months Ended March 31, |  |  |  |  |  |  |
|  | 2020 |  | 2019 |  |  |  |  |
|  | (In thousands, except per share data) |  |  |  |  |  |  |
| Net income | $ | 11,311 |  |  | $ | 3,284 |  |  |  |  |  |
| Weighted-average shares outstanding — basic | 42,357 |  |  | 40,692 |  |  |  |  |  |
| Effect of dilutive securities from stock award plans | 1,264 |  |  | 1,589 |  |  |  |  |  |
| Weighted-average shares outstanding — diluted | 43,621 |  |  | 42,281 |  |  |  |  |  |
| Net income per share - basic | $ | 0.27 |  |  | $ | 0.08 |  |  |  |  |  |
| Net income per share - diluted | $ | 0.26 |  |  | $ | 0.08 |  |  |  |  |  |
| Anti-dilutive weighted-average shares related to stock award plans | 1,744 |  |  | 635 |  |  |  |  |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000926326-20-000014:notes:55]
Cash and Cash Equivalents and Fair Value of Financial Instruments
Cash and cash equivalents of $104.1 million and $127.2 million as of March 31, 2020 and December 31, 2019, respectively, consisted of bank accounts with major financial institutions.

[0000926326-20-000014:notes:56]
[same as prior period, unchanged from 0000926326-19-000033:notes:69]

[0000926326-20-000014:notes:57]
The Company measures its financial instruments at fair value. The Company’s cash and cash equivalents are classified within Level 1 of the fair value hierarchy as they are valued primarily using quoted market prices utilizing market observable inputs. The Company's interest rate swap contracts and debt are classified within Level 2 as the valuation inputs are based on quoted prices or market observable data of similar instruments. Refer to Note 8, Debt and Credit Agreements, of the Notes to Condensed Consolidated Financial Statements for further information regarding the Company’s credit facilities.

[0000926326-20-000014:notes:58]
[same as prior period, unchanged from 0000926326-19-000033:notes:74]

[0000926326-20-000014:notes:59]
The Company uses interest rate swap agreements to protect the Company against adverse fluctuations in interest rates by reducing its exposure to variability in cash flows relating to interest payments on a portion of its outstanding debt. The Company’s interest rate swaps, which are designated as cash flow hedges, involve the receipt of variable amounts from counterparties in exchange for the Company making fixed-rate payments over the life of the agreements. The Company does not hold or issue any derivative financial instruments for speculative trading purposes.

[0000926326-20-000014:notes:60]
During 2016, the Company entered into an interest rate swap agreement with a combined notional amount of $100.0 million with one counterparty that became effective on June 30, 2016 and matured on April 30, 2019. The swap agreement required the Company to pay a fixed rate of 0.8% and provided that the Company received a variable rate based on the one month London Interbank Offered Rate (“LIBOR”), subject to a LIBOR floor of 0.0%. Amounts payable by or due to the Company were net settled with the respective counterparty on the last business day of each month, commencing July 31, 2016.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000926326-20-000014:notes:61]
Balance Sheet Components
Balance sheet details as of March 31, 2020 and December 31, 2019 are presented in the tables below:

[0000926326-20-000014:notes:62]
|  | March 31,2020 |  | December 31,2019 |
|  | (In thousands) |  |  |
| Inventories: |  |  |  |
| Raw materials |  | $ | 33,945 |  |  | $ | 31,331 |  |
| Work in process |  | 11,957 |  |  | 7,620 |  |
| Finished goods |  | 66,883 |  |  | 69,060 |  |
| Total inventories |  | $ | 112,785 |  |  | $ | 108,011 |  |
| Other long-term assets: |  |  |  |
| Capitalized software, net |  | $ | 90,395 |  |  | $ | 85,070 |  |
| Unbilled receivables, net |  | 14,338 |  |  | 12,260 |  |
| Deferred debt issuance costs |  | 4,459 |  |  | 4,700 |  |
| Other assets |  | 1,739 |  |  | 1,006 |  |
| Total other long-term assets |  | $ | 110,931 |  |  | $ | 103,036 |  |
| Accrued liabilities: |  |  |  |
| Operating lease liabilities, current portion | $ | 9,986 |  |  | $ | 10,058 |  |
| Advance payments from customers | 6,442 |  |  | 4,006 |  |
| Rebates and lease buyouts |  | 15,156 |  |  | 14,911 |  |
| Group purchasing organization fees | 5,382 |  |  | 5,934 |  |
| Taxes payable | 5,974 |  |  | 3,744 |  |
| Other accrued liabilities |  | 15,120 |  |  | 16,914 |  |
| Total accrued liabilities |  | $ | 58,060 |  |  | $ | 55,567 |  |

[0000926326-20-000014:notes:63]
The following table summarizes the changes in accumulated balances of other comprehensive income (loss) for the three months ended March 31, 2020 and 2019:

[0000926326-20-000014:notes:64]
|  | Three Months Ended March 31, |  |  |  |  |  |  |  |  |  |  |
|  | 2020 |  |  |  |  |  | 2019 |  |  |  |  |
|  | Foreign currency translation adjustments |  | Unrealized gain (loss) on interest rate swap hedges |  | Total |  | Foreign currency translation adjustments |  | Unrealized gain (loss) on interest rate swap hedges |  | Total |
|  | (In thousands) |  |  |  |  |  |  |  |  |  |  |
| Beginning balance | $ | (9,446) |  |  | $ | — |  |  | $ | (9,446) |  |  | $ | (11,274) |  |  | $ | 420 |  |  | $ | (10,854) |  |
| Other comprehensive income (loss) before reclassifications | (4,694) |  |  | — |  |  | (4,694) |  |  | 669 |  |  | 100 |  |  | 769 |  |
| Amounts reclassified from other comprehensive income (loss), net of tax | — |  |  | — |  |  | — |  |  | — |  |  | (417) |  |  | (417) |  |
| Net current-period other comprehensive income (loss), net of tax | (4,694) |  |  | — |  |  | (4,694) |  |  | 669 |  |  | (317) |  |  | 352 |  |
| Ending balance | $ | (14,140) |  |  | $ | — |  |  | $ | (14,140) |  |  | $ | (10,605) |  |  | $ | 103 |  |  | $ | (10,502) |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000926326-20-000014:notes:65]
Property and Equipment 
The following table represents the property and equipment balances as of March 31, 2020 and December 31, 2019:

[0000926326-20-000014:notes:66]
|  | March 31,2020 |  | December 31,2019 |
|  | (In thousands) |  |  |
| Equipment |  | $ | 90,128 |  |  | $ | 88,569 |  |
| Furniture and fixtures |  | 7,828 |  |  | 7,925 |  |
| Leasehold improvements |  | 19,767 |  |  | 18,979 |  |
| Software |  | 48,885 |  |  | 48,309 |  |
| Construction in progress |  | 6,106 |  |  | 6,179 |  |
| Property and equipment, gross |  | 172,714 |  |  | 169,961 |  |
| Accumulated depreciation and amortization |  | (119,717) |  |  | (115,715) |  |
| Total property and equipment, net |  | $ | 52,997 |  |  | $ | 54,246 |  |

[0000926326-20-000014:notes:67]
Depreciation and amortization expense of property and equipment was $4.3 million and $4.0 million for the three months ended March 31, 2020 and 2019, respectively.

[0000926326-20-000014:notes:68]
The geographic location of the Company's property and equipment, net, is based on the physical location in which it is located. The following table summarizes the geographic information for property and equipment, net, as of March 31, 2020 and December 31, 2019:

[0000926326-20-000014:notes:69]
|  | March 31,2020 |  | December 31,2019 |
|  | (In thousands) |  |  |
| United States | $ | 47,955 |  |  | $ | 48,769 |  |
| Rest of world (1) | 5,042 |  |  | 5,477 |  |
| Total property and equipment, net | $ | 52,997 |  |  | $ | 54,246 |  |

[0000926326-20-000014:notes:70]
(1) No individual country represented more than 10% of total property and equipment, net.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000926326-20-000014:notes:71]
[same as prior period, unchanged from 0000926326-19-000033:notes:90]

[0000926326-20-000014:notes:72]
[same as prior period, unchanged from 0000926326-19-000033:notes:91]

[0000926326-20-000014:notes:73]
|  | December 31,2019 |  | Additions |  | Foreign currency exchange rate fluctuations |  | March 31,2020 |
|  | (In thousands) |  |  |  |  |  |  |
| Goodwill | $ | 336,539 |  |  | $ | — |  |  | $ | (1,697) |  |  | $ | 334,842 |  |

[0000926326-20-000014:notes:74]
[same as prior period, unchanged from 0000926326-19-000033:notes:93]

[0000926326-20-000014:notes:75]
The carrying amounts and useful lives of intangible assets as of March 31, 2020 and December 31, 2019 were as follows:

[0000926326-20-000014:notes:76]
|  | March 31, 2020 |  |  |  |  |  |  |  |  |
|  | Gross carryingamount (1) |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |  |  |  |  |  |  |  |  |
| Customer relationships | $ | 134,889 |  |  | $ | (56,727) |  |  | $ | (1,398) |  |  | $ | 76,764 |  |  | 10 - 30 |
| Acquired technology | 77,029 |  |  | (38,058) |  |  | 4 |  |  | 38,975 |  |  | 5 - 20 |
| Backlog | 1,150 |  |  | (863) |  |  | — |  |  | 287 |  |  | 4 |
| Trade names | 7,650 |  |  | (5,206) |  |  | 9 |  |  | 2,453 |  |  | 6 - 12 |
| Patents | 3,217 |  |  | (1,633) |  |  | — |  |  | 1,584 |  |  | 2 - 20 |
| Total intangibles assets, net | $ | 223,935 |  |  | $ | (102,487) |  |  | $ | (1,385) |  |  | $ | 120,063 |  |  |  |

[0000926326-20-000014:notes:77]
|  | December 31, 2019 |  |  |  |  |  |  |  |  |
|  | Gross carryingamount (1) |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |  |  |  |  |  |  |  |  |
| Customer relationships | $ | 135,234 |  |  | $ | (54,860) |  |  | $ | (1,058) |  |  | $ | 79,316 |  |  | 10 - 30 |
| Acquired technology | 77,142 |  |  | (36,194) |  |  | 5 |  |  | 40,953 |  |  | 3 - 20 |
| Backlog | 1,150 |  |  | (791) |  |  | — |  |  | 359 |  |  | 4 |
| Trade names | 7,650 |  |  | (5,037) |  |  | 11 |  |  | 2,624 |  |  | 6 - 12 |
| Patents | 3,217 |  |  | (1,603) |  |  | 1 |  |  | 1,615 |  |  | 2 - 20 |
| Total intangibles assets, net | $ | 224,393 |  |  | $ | (98,485) |  |  | $ | (1,041) |  |  | $ | 124,867 |  |  |  |

[0000926326-20-000014:notes:78]
(1) The differences in gross carrying amounts between periods are primarily due to the write-off of certain fully amortized intangible assets.

[0000926326-20-000014:notes:79]
Amortization expense of intangible assets was $4.5 million and $4.8 million for the three months ended March 31, 2020 and 2019, respectively.

[0000926326-20-000014:notes:80]
[same as prior period, unchanged from 0000926326-19-000033:notes:99]

[0000926326-20-000014:notes:81]
|  | March 31,2020 |
|  | (In thousands) |
| Remaining nine months of 2020 | $ | 12,987 |  |
| 2021 | 16,123 |  |
| 2022 | 14,775 |  |
| 2023 | 13,679 |  |
| 2024 | 7,920 |  |
| Thereafter |  | 54,579 |  |
| Total |  | $ | 120,063 |  |


## us-gaap:DebtDisclosureTextBlock

[0000926326-20-000014:notes:82]
Debt and Credit Agreements
2016 Senior Credit Facility

[0000926326-20-000014:notes:83]
On January 5, 2016, the Company entered into a $400.0 million senior secured credit facility pursuant to a credit agreement with certain lenders, Wells Fargo Securities, LLC as sole lead arranger, and Wells Fargo Bank, National Association

[0000926326-20-000014:notes:84]
as administrative agent (as subsequently amended as discussed below, the “Prior Credit Agreement”). The Prior Credit Agreement provided for (a) a five-year revolving credit facility of $200.0 million, which was subsequently increased pursuant to the amendment discussed below (the “Prior Revolving Credit Facility”) and (b) a five-year $200.0 million term loan facility (the “Prior Term Loan Facility” and together with the Prior Revolving Credit Facility, the “Prior Facilities”). In addition, the Prior Credit Agreement included a letter of credit sub-limit of up to $10.0 million and a swing line loan sub-limit of up to $10.0 million. The Prior Credit Agreement had an expiration date of January 5, 2021, upon which date all remaining outstanding borrowings were due and payable.

[0000926326-20-000014:notes:85]
Loans under the Prior Facilities bore interest, at the Company’s option, at a rate equal to either (a) LIBOR, plus an applicable margin ranging from 1.50% to 2.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the Prior Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) LIBOR for an interest period of one month, plus an applicable margin ranging from 0.50% to 1.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the Prior Credit Agreement). Undrawn commitments under the Prior Revolving Credit Facility were subject to a commitment fee ranging from 0.20% to 0.35% per annum based on the Company’s Consolidated Total Net Leverage Ratio on the average daily unused portion of the Prior Revolving Credit Facility.

[0000926326-20-000014:notes:86]
On each of April 11, 2017 and December 26, 2017, the parties entered into amendments to the Prior Credit Agreement. Under these amendments, the Prior Revolving Credit Facility was increased from $200.0 million to $315.0 million, and certain other modifications were made. In connection with the December 2017 amendment, the Company incurred and capitalized an additional $2.1 million of debt issuance costs.

[0000926326-20-000014:notes:87]
2019 Revolving Credit Facility

[0000926326-20-000014:notes:88]
On November 15, 2019, the Company refinanced the Prior Credit Agreement and entered into an Amended and Restated Credit Agreement (the “A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers and Wells Fargo Bank, National Association, as administrative agent. The A&R Credit Agreement replaced the Prior Credit Agreement and provides for (a) a five-year revolving credit facility of $500.0 million (the “Current Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million (the “Incremental Facility”). In addition, the A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The A&R Credit Agreement has an expiration date of November 15, 2024, upon which date all remaining outstanding borrowings will be due and payable.

[0000926326-20-000014:notes:89]
On November 15, 2019, the $80.0 million outstanding term loan balance under the Prior Facilities was transferred to the Current Revolving Credit Facility.

[0000926326-20-000014:notes:90]
Loans under the Current Revolving Credit Facility bear interest, at the Company’s option, at a rate equal to either (a) LIBOR, plus an applicable margin ranging from 1.25% to 2.00% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the A&R Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) LIBOR for an interest period of one month plus 1.00%, plus an applicable margin ranging from 0.25% to 1.00% per annum based on the Company’s Consolidated Total Net Leverage Ratio. Undrawn commitments under the Current Revolving Credit Facility are subject to a commitment fee ranging from 0.15% to 0.30% per annum based on the Company’s Consolidated Total Net Leverage Ratio on the average daily unused portion of the Current Revolving Credit Facility. The applicable margin for and certain other terms of any term loans under the Incremental Facility will be determined prior to the incurrence of such loans. The Company is permitted to make voluntary prepayments at any time without payment of a premium or penalty.

[0000926326-20-000014:notes:91]
The A&R Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends, and other distributions. The A&R Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum consolidated total net leverage ratio and maintain a minimum interest coverage ratio. In addition, the A&R Credit Agreement contains certain customary events of default including, but not limited to, failure to pay interest, principal and fees or other amounts when due, material misrepresentations or misstatements in any representation or warranty, covenant defaults, certain cross defaults to other material indebtedness, certain judgment defaults and events of bankruptcy. The Company’s obligations under the A&R Credit Agreement and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and such subsidiary guarantors’ assets. In connection with entering into the A&R Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a reaffirmation agreement, which amends certain terms of the existing collateral agreement and

[0000926326-20-000014:notes:92]
reaffirms their obligations under the existing guaranty agreement. The Company was in full compliance with all covenants as of March 31, 2020.

[0000926326-20-000014:notes:93]
The refinancing of the Prior Credit Agreement was evaluated in accordance with Accounting Standards Codification (“ASC”) 470-50, Debt - Modifications and Extinguishments. In determining whether the refinancing was to be accounted for as a debt extinguishment or a debt modification, the Company considered whether lenders within the syndicate remained the same or changed and whether the changes in debt terms were substantial. This assessment was performed on an individual lender basis within the syndicate. As a result, the refinancing was accounted for as a modification with the exception of certain lenders that exited the syndicate. The exit of certain lenders resulted in an immaterial write-off of existing unamortized debt issuance costs. The remaining unamortized debt issuance costs related to debt modification, along with the new deferred costs, will be amortized over the remaining term of the A&R Credit Agreement.

[0000926326-20-000014:notes:94]
In connection with the A&R Credit Agreement, the Company incurred and capitalized an additional $2.3 million of debt issuance costs. The debt issuance costs are being amortized to interest expense using the straight-line method through 2024. Amortization expense related to debt issuance costs was approximately $0.2 million and $0.6 million for the three months ended March 31, 2020 and 2019, respectively.

[0000926326-20-000014:notes:95]
Interest expense (exclusive of fees and debt issuance cost amortization) was approximately $0.2 million and $1.3 million for the three months ended March 31, 2020 and 2019, respectively.

[0000926326-20-000014:notes:96]
The following table represents changes in the carrying amount of the Company’s debt obligations:

[0000926326-20-000014:notes:97]
|  | Current Revolving Credit Facility |
|  | (In thousands) |
| Balance as of December 31, 2019 | $ | 50,000 |  |
| Proceeds | — |  |
| Repayments | (50,000) |  |
| Balance as of March 31, 2020 | $ | — |  |

[0000926326-20-000014:notes:98]
The following table represents changes in the balance of the Company's deferred debt issuance costs:

[0000926326-20-000014:notes:99]
|  | (In thousands) |
| Balance as of December 31, 2019 | $ | 4,700 |  |
| Additions | — |  |
| Amortization | (241) |  |
| Balance as of March 31, 2020 | $ | 4,459 |  |


## us-gaap:LessorSalesTypeLeasesTextBlock

[0000926326-20-000014:notes:100]
[same as prior period, unchanged from 0000926326-19-000033:notes:114]

[0000926326-20-000014:notes:101]
On a recurring basis, the Company enters into multi-year, sales-type lease agreements, with the majority varying in length from one to five years. The Company optimizes cash flows by selling a majority of its non-U.S. government sales-type leases to third-party leasing finance companies on a non-recourse basis. The Company has no obligation to the leasing company once the lease has been sold. Some of the Company's sales-type leases, mostly those relating to U.S. government hospitals which comprise approximately 61% of the lease receivable balance, are retained in-house.

[0000926326-20-000014:notes:102]
The following table presents the Company’s income recognized from sales-type leases for the three months ended March 31, 2020 and 2019:

[0000926326-20-000014:notes:103]
|  | Three Months Ended March 31, |  |  |  |  |  |  |
|  | 2020 |  | 2019 |  |  |  |  |
|  | (In thousands) |  |  |  |  |  |  |
| Sales-type lease revenues | $ | 6,392 |  |  | $ | 11,507 |  |  |  |  |  |
| Cost of sales-type lease revenues | (2,569) |  |  | (4,820) |  |  |  |  |  |
| Selling profit on sales-type lease revenues | $ | 3,823 |  |  | $ | 6,687 |  |  |  |  |  |
| Interest income on sales-type lease receivables | $ | 461 |  |  | $ | 409 |  |  |  |  |  |

[0000926326-20-000014:notes:104]
The receivables as a result of these types of transactions are collateralized by the underlying equipment leased and consist of the following components at March 31, 2020 and December 31, 2019:

[0000926326-20-000014:notes:105]
|  | March 31,2020 |  | December 31,2019 |
|  | (In thousands) |  |  |
| Net minimum lease payments to be received | $ | 32,681 |  |  | $ | 32,360 |  |
| Less: Unearned interest income portion | (2,893) |  |  | (2,840) |  |
| Net investment in sales-type leases | 29,788 |  |  | 29,520 |  |
| Less: Current portion (1) | (9,796) |  |  | (9,770) |  |
| Long-term investment in sales-type leases, net | $ | 19,992 |  |  | $ | 19,750 |  |

[0000926326-20-000014:notes:106]
(1) The current portion of the net investment in sales-type leases is included in other current assets in the Condensed Consolidated Balance Sheets.

[0000926326-20-000014:notes:107]
[same as prior period, unchanged from 0000926326-19-000033:notes:120]

[0000926326-20-000014:notes:108]
[same as prior period, unchanged from 0000926326-19-000033:notes:122]

[0000926326-20-000014:notes:109]
|  | March 31,2020 |
|  | (In thousands) |
| Remaining nine months of 2020 | $ | 8,838 |  |
| 2021 | 8,048 |  |
| 2022 | 7,283 |  |
| 2023 | 5,110 |  |
| 2024 | 2,393 |  |
| Thereafter |  | 1,009 |  |
| Total future minimum sales-type lease payments |  | 32,681 |  |
| Present value adjustment |  | (2,893) |  |
| Total net investment in sales-type leases |  | $ | 29,788 |  |

[0000926326-20-000014:notes:110]
Operating Leases

[0000926326-20-000014:notes:111]
The Company entered into certain leasing agreements that were classified as operating leases prior to the adoption of ASC 842, Leases, on January 1, 2019. These agreements in place prior to January 1, 2019 will continue to be treated as operating leases, however any new leasing agreements entered into on or after January 1, 2019 under these programs are classified and accounted for as sales-type leases in accordance with ASC 842. The operating lease arrangements generally have initial terms of one to seven years.

[0000926326-20-000014:notes:112]
The following table represents the Company’s income recognized from operating leases for the three months ended March 31, 2020 and 2019:

[0000926326-20-000014:notes:113]
|  | Three Months Ended March 31, |  |  |  |  |  |  |
|  | 2020 |  | 2019 |  |  |  |  |
|  | (In thousands) |  |  |  |  |  |  |
| Rental income | $ | 2,977 |  |  | $ | 3,287 |  |  |  |  |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0000926326-20-000014:notes:114]
Lessee Leases 
The Company has operating leases for office buildings, data centers, office equipment, and vehicles. The Company’s leases have initial terms of one to 12 years. As of March 31, 2020, the Company did not have any additional material operating leases that were entered into, but not yet commenced.

[0000926326-20-000014:notes:115]
[same as prior period, unchanged from 0000926326-19-000033:notes:130]

[0000926326-20-000014:notes:116]
|  | March 31,2020 |
|  | (In thousands) |
| Remaining nine months of 2020 | $ | 10,076 |  |
| 2021 | 13,274 |  |
| 2022 | 12,157 |  |
| 2023 | 8,595 |  |
| 2024 | 8,014 |  |
| Thereafter |  | 20,100 |  |
| Total operating lease payments |  | 72,216 |  |
| Present value adjustment |  | (13,379) |  |
| Total operating lease liabilities (1) | $ | 58,837 |  |

[0000926326-20-000014:notes:117]
(1) Amount consists of a current and long-term portion of operating lease liabilities of $10.0 million and $48.9 million, respectively. The short-term portion of the operating lease liabilities is included in accrued liabilities in the Condensed Consolidated Balance Sheets.

[0000926326-20-000014:notes:118]
Operating lease costs were $3.6 million and $3.7 million for the three months ended March 31, 2020 and 2019, respectively. Short-term lease costs and variable lease costs were immaterial for the three months ended March 31, 2020 and 2019.

[0000926326-20-000014:notes:119]
The following table summarizes supplemental cash flow information related to the Company’s operating leases for the three months ended March 31, 2020 and 2019:

[0000926326-20-000014:notes:120]
|  | Three Months Ended March 31, |  |  |  |  |
|  | 2020 |  | 2019 |  |  |
|  | (In thousands) |  |  |  |  |
| Cash paid for amounts included in the measurement of lease liabilities | $ | 3,735 |  |  | $ | 3,761 |  |  |  |
| Right-of-use assets obtained in exchange for new lease liabilities | $ | 792 |  |  | $ | 431 |  |  |  |

[0000926326-20-000014:notes:121]
The following table summarizes the weighted-average remaining lease term and weighted-average discount rate related to the Company’s operating leases as of March 31, 2020 and 2019:

[0000926326-20-000014:notes:122]
|  | March 31,2020 |  | December 31,2019 |  |  |
| Weighted-average remaining lease term, years | 6.3 |  | 6.4 |  |  |
| Weighted-average discount rate, % | 6.4 | % |  | 6.4 | % |  |  |


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000926326-20-000014:notes:123]
Commitments and Contingencies
Purchase Obligations

[0000926326-20-000014:notes:124]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of March 31, 2020, the Company had non-cancelable purchase commitments of $91.7 million, of which $90.2 million are expected to be paid within the year ending December 31, 2020.

[0000926326-20-000014:notes:125]
Legal Proceedings

[0000926326-20-000014:notes:126]
The Company is currently involved in various legal proceedings. As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any accrual for contingent liabilities associated with the legal proceedings described below based on its belief that any potential loss, while reasonably possible, is not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of this contingency or because of the diversion of management’s attention and the creation of significant expenses.

[0000926326-20-000014:notes:127]
On January 10, 2018, a lawsuit was filed against a number of individuals, governmental agencies, and corporate entities, including the Company and one of its former subsidiaries, Aesynt Incorporated (“Aesynt”), which, through a series of mergers, has been merged into the Company, in the Circuit Court for the City of Richmond, Virginia, captioned Ruth Ann Warner, as Guardian of Jonathan James Brewster Warner v. Centra Health, Inc., et al., Case No. CL18-152-1. The complaint sought monetary recovery of compensatory and punitive damages in addition to certain declaratory relief based upon, as against the individuals, governmental agencies, and corporate entities other than the Company and Aesynt, allegations of the use of excessive force, unlawful detention, false imprisonment, battery, simple and gross negligence and negligent hiring, detention, and training; and, as against the Company and Aesynt, claims of product liability, negligence, and breach of implied warranties. The Company and Aesynt were never served with the complaint. Upon motion of the plaintiff, the Court issued an order on February 21, 2019 nonsuiting (dismissing) the case without prejudice. On August 21, 2019, a new lawsuit was filed against the Company and Aesynt, in the Circuit Court for the County of Albemarle, Virginia, captioned Ruth Ann Warner, as Guardian of Jonathan James Brewster Warner v. Aesynt Incorporated, et al., Case No CL19-1301. The complaint seeks monetary recovery of damages based upon claims of product liability, negligence, and breach of implied warranties. The Company and Aesynt have not been served with the complaint. The Company intends to defend the lawsuit vigorously.

[0000926326-20-000014:notes:128]
A declaratory judgment action was filed against the Company, on August 30, 2018, in the United States District Court for the Northern District of California, captioned Zurich American Insurance Company; American Guarantee & Liability Company v. Omnicell, Inc. and Does 1-10, inclusive, Case No. 3:18-CV-05345. The complaint seeks a declaration that the plaintiffs have no duty to defend or indemnify the Company in connection with the underlying litigation, Yana Mazya, et al. v. Northwestern Lake Forest Hospital, et al., Case No. 2018-CH-07161 pending in the Circuit Court of Cook County, Illinois, Chancery Division (a class action lawsuit filed against a customer of the Company, the customer’s parent company, and two vendors of medication dispensing systems, one of which is the Company, seeking statutory damages and certain declaratory, injunctive, and other relief based on causes of action directed to allegations of violation of the Illinois Biometric Information Privacy Act (“BIPA”) and of negligence by the defendants from which the Company was subsequently dismissed without prejudice) (“Mazya Action”), together with claims for reimbursement and unjust enrichment relating to the defense of the Mazya Action in the form of attorneys’ fees and other related costs. The Company has not responded to the complaint. On February 12, 2019, the Court stayed the action pending the outcome of the Mazya Action and administratively closed the case. On October 15, 2019, the plaintiffs filed a notice advising the Court of the dismissal of the Company from the Mazya Action and requesting that the Court lift the stay in the case and set dates for filing a responsive pleading by the Company and initial discovery and scheduling matters. By order dated November 13, 2019, the Court (i) lifted the stay in the case, (ii) set a case management conference for February 5, 2020, and (iii) ordered the parties to file a joint case management statement by January 29, 2020. The parties subsequently reached a settlement of the case in principle and the Court, after notice of the parties, continued the case management conference until April 29, 2020. The parties entered into a written settlement agreement on April 9, 2020. Since the conditions precedent in the settlement agreement to dismissing the case had not yet been fulfilled, the Court, upon the petition of the parties, again continued the case management conference until May 27, 2020. Upon fulfillment of the conditions precedent to finalizing the settlement, the plaintiffs filed a notice of dismissal with prejudice on May 4, 2020, thereby finally terminating the action.

[0000926326-20-000014:notes:129]
A class action lawsuit was filed against the Company, on June 5, 2019, in the Circuit Court of Cook County, Illinois, Chancery Division, captioned Corey Heard, individually and on behalf of all others similarly situated, v. Omnicell, Inc., Case No. 2019-CH-06817. The complaint seeks class certification, monetary damages in the form of statutory damages for willful and/or reckless or, in the alternative, negligent violation of BIPA, and certain declaratory, injunctive, and other relief based on

[0000926326-20-000014:notes:130]
causes of action directed to allegations of violation of BIPA by the Company. The complaint was served on the Company on June 13, 2019. On July 31, 2019, the Company filed a motion to stay or consolidate the case with the Mazya Action. The Court subsequently, on October 10, 2019, denied the motion, without prejudice, as being moot in view of the Company’s dismissal from the Mazya Action. The Company filed a motion to dismiss the complaint on October 31, 2019. The motion to dismiss is fully-briefed. The hearing on the Company’s motion to dismiss was previously set for March 16, 2020, but has been continued to May 27, 2020. The Company intends to defend the lawsuit vigorously.

[0000926326-20-000014:notes:131]
In August 2019, the Company received a letter from the Denver office of the SEC seeking information related to the Company’s accounting processes and procedures. The Company responded and fully cooperated with the SEC. On February 12, 2020, the Company received a letter from the SEC confirming that it has concluded its investigation and that the SEC does not intend to recommend any enforcement action against the Company.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000926326-20-000014:notes:132]
Income Taxes 
The Company generally provides for income taxes in interim periods based on the estimated annual effective tax rate for the year, adjusting for discrete items in the quarter in which they arise. The annual effective tax rate before discrete items was 26.6% and 23.3% for the three months ended March 31, 2020 and 2019, respectively. The Company’s effective tax rate for the three months ended March 31, 2020 was based on best estimates, which may fluctuate through the remainder of the year due to the volatility and uncertainty of global economic conditions in connection with the COVID-19 pandemic.

[0000926326-20-000014:notes:133]
Due to continuing global operational centralization activities and legal entity rationalization, the Company recognized gain on the sale of certain intellectual property rights by Aesynt B.V. to Omnicell, Inc., which resulted in a tax expense, net of tax benefit, of $9.6 million during the three months ended March 31, 2019. The Company did not recognize a gain or loss from such activities during the three months ended March 31, 2020. The Company also recognized a discrete tax benefit related to equity compensation in the amount of $2.8 million and $4.6 million for the three months ended March 31, 2020 and 2019, respectively.

[0000926326-20-000014:notes:134]
The 2020 annual effective tax rate differed from the statutory rate of 21% primarily due to the unfavorable impact of state income taxes, non-deductible compensation and equity charges, and non-deductible expenses, partially offset by the favorable impact of research and development credits and foreign derived intangible income (“FDII”) benefit deduction. The 2019 annual effective tax rate differed from the statutory rate of 21% primarily due to the unfavorable impact of state income taxes, non-deductible equity charges, and non-deductible expenses, partially offset by the favorable impact of research and development credits, foreign rate differential, and FDII benefit deduction.

[0000926326-20-000014:notes:135]
On March 27, 2020, the Coronavirus Aid, Relief and Economic Security Act (the “CARES Act”) was signed into law in response to the COVID-19 pandemic. The CARES Act, among other provisions, includes provisions related to refundable payroll tax credits, deferment of the employer portion of certain payroll taxes, net operation losses carryback periods, alternative minimum tax credit refunds, modification to net interest expense deduction limitation, and technical amendments to tax depreciation methods for qualified improvement property placed in service after December 31, 2017. The Company does not expect these provisions of the CARES Act to have a material impact on income taxes.

[0000926326-20-000014:notes:136]
As of March 31, 2020 and December 31, 2019, the Company had gross unrecognized tax benefits of $17.0 million and $16.8 million, respectively. It is the Company’s policy to classify accrued interest and penalties as part of the unrecognized tax benefits, but to record interest and penalties in interest and other income (expense), net in the Condensed Consolidated Statements of Operations. As of March 31, 2020 and December 31, 2019, the amount of accrued interest and penalties was $1.1 million and $1.0 million, respectively.

[0000926326-20-000014:notes:137]
The Company files income tax returns in the United States and various states and foreign jurisdictions. In the normal course of business, the Company is subject to examination by taxing authorities, including major jurisdictions such as the United States, Germany, Italy, Netherlands, and the United Kingdom. With few exceptions, as of March 31, 2020, the Company was no longer subject to United States, state, and foreign examination for years before 2016, 2015, and 2015, respectively.

[0000926326-20-000014:notes:138]
[same as prior period, unchanged from 0000926326-19-000033:notes:157]


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000926326-20-000014:notes:139]
Employee Benefits and Share-Based Compensation
Stock-Based Plans

[0000926326-20-000014:notes:140]
For a detailed explanation of the Company's stock plans, refer to Note 13, Employee Benefits and Share-Based Compensation, of the Company's annual report on Form 10-K for the year ended December 31, 2019 filed with the SEC on February 26, 2020.

[0000926326-20-000014:notes:141]
Share-Based Compensation Expense

[0000926326-20-000014:notes:142]
The following table sets forth the total share-based compensation expense recognized in the Company’s Condensed Consolidated Statements of Operations for the three months ended March 31, 2020 and 2019:

[0000926326-20-000014:notes:143]
|  | Three Months Ended March 31, |  |  |  |  |  |  |
|  | 2020 |  | 2019 |  |  |  |  |
|  | (In thousands) |  |  |  |  |  |  |
| Cost of product and service revenues | $ | 1,770 |  |  | $ | 1,462 |  |  |  |  |  |
| Research and development | 1,768 |  |  | 1,702 |  |  |  |  |  |
| Selling, general, and administrative | 7,121 |  |  | 5,246 |  |  |  |  |  |
| Total share-based compensation expense | $ | 10,659 |  |  | $ | 8,410 |  |  |  |  |  |

[0000926326-20-000014:notes:144]
Stock Options and ESPP Shares

[0000926326-20-000014:notes:145]
The following assumptions were used to value stock options and Employee Stock Purchase Plan (“ESPP”) shares granted pursuant to the Company’s equity incentive plans for the three months ended March 31, 2020 and 2019:

[0000926326-20-000014:notes:146]
|  | Three Months Ended March 31, |  |  |  |  |  |  |
|  | 2020 |  | 2019 |  |  |  |  |
| Stock options |  |  |  |  |  |  |  |
| Expected life, years | 4.7 |  | 4.5 |  |  |  |  |
| Expected volatility, % | 33.6 | % |  | 33.1 | % |  |  |  |  |
| Risk-free interest rate, % | 1.4 | % |  | 2.6 | % |  |  |  |  |
| Estimated forfeiture rate, % | 5.7 | % |  | 7.2 | % |  |  |  |  |
| Dividend yield, % | — | % |  | — | % |  |  |  |  |

[0000926326-20-000014:notes:147]
|  | Three Months Ended March 31, |  |  |  |  |  |  |
|  | 2020 |  | 2019 |  |  |  |  |
| Employee stock purchase plan shares |  |  |  |  |  |  |  |
| Expected life, years | 0.5 - 2.0 |  | 0.5 - 2.0 |  |  |  |  |
| Expected volatility, % | 30.4% - 39.9% |  | 28.2% - 38.4% |  |  |  |  |
| Risk-free interest rate, % | 1.4% - 2.7% |  | 1.3% - 2.7% |  |  |  |  |
| Dividend yield, % | — | % |  | — | % |  |  |  |  |

[0000926326-20-000014:notes:148]
Stock Options Activity

[0000926326-20-000014:notes:149]
The following table summarizes the share option activity under the Company’s equity incentive plans during the three months ended March 31, 2020:

[0000926326-20-000014:notes:150]
|  | Number ofShares |  | Weighted-AverageExercise Price |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |  |  |  |  |  |  |
| Outstanding at December 31, 2019 | 3,902 |  |  | $ | 52.75 |  |  | 7.7 |  | $ | 113,198 |  |
| Granted | 430 |  |  | 85.32 |  |  |  |  |  |
| Exercised | (227) |  |  | 36.20 |  |  |  |  |  |
| Expired | (2) |  |  | 51.50 |  |  |  |  |  |
| Forfeited | (65) |  |  | 64.06 |  |  |  |  |  |
| Outstanding at March 31, 2020 | 4,038 |  |  | $ | 56.96 |  |  | 7.8 |  | $ | 57,180 |  |
| Exercisable at March 31, 2020 | 1,586 |  |  | $ | 39.38 |  |  | 6.3 |  | $ | 42,826 |  |
| Vested and expected to vest at March 31, 2020 and thereafter | 3,846 |  |  | $ | 56.18 |  |  | 7.7 |  | $ | 56,526 |  |

[0000926326-20-000014:notes:151]
The weighted-average fair value per share of options granted during the three months ended March 31, 2020 and 2019 was $26.31 and $24.07, respectively. The intrinsic value of options exercised during the three months ended March 31, 2020 and 2019 was $9.9 million and $17.1 million, respectively.

[0000926326-20-000014:notes:152]
As of March 31, 2020, total unrecognized compensation cost related to unvested stock options was $46.6 million, which is expected to be recognized over a weighted-average vesting period of 2.9 years.

[0000926326-20-000014:notes:153]
Employee Stock Purchase Plan Activity

[0000926326-20-000014:notes:154]
For the three months ended March 31, 2020 and 2019, employees purchased approximately 217,000 and 210,000 shares of common stock, respectively, under the ESPP at weighted average prices of $43.51 and $40.20, respectively. As of March 31, 2020, the unrecognized compensation cost related to the shares to be purchased under the ESPP was approximately $7.7 million and is expected to be recognized over a weighted-average period of 1.4 years.

[0000926326-20-000014:notes:155]
Restricted Stock Units (“RSUs”) and Restricted Stock Awards (“RSAs”)

[0000926326-20-000014:notes:156]
Summaries of the restricted stock activity under the Company’s 2009 Equity Incentive Plan, as amended (the “2009 Plan”) are presented below for the three months ended March 31, 2020:

[0000926326-20-000014:notes:157]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |  |  |  |  |  |  |
| Restricted stock units |  |  |  |  |  |  |  |
| Outstanding at December 31, 2019 | 544 |  |  | $ | 66.65 |  |  | 1.6 |  | $ | 44,492 |  |
| Granted (Awarded) | 62 |  |  | 85.05 |  |  |  |  |  |
| Vested (Released) | (33) |  |  | 54.41 |  |  |  |  |  |
| Forfeited | (17) |  |  | 66.06 |  |  |  |  |  |
| Outstanding and unvested at March 31, 2020 | 556 |  |  | $ | 69.44 |  |  | 1.6 |  | $ | 36,482 |  |

[0000926326-20-000014:notes:158]
As of March 31, 2020, total unrecognized compensation cost related to RSUs was $34.1 million, which is expected to be recognized over the remaining weighted-average vesting period of 3.0 years.

[0000926326-20-000014:notes:159]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |
|  | (In thousands, except per share data) |  |  |
| Restricted stock awards |  |  |  |
| Outstanding at December 31, 2019 | 17 |  |  | $ | 81.92 |  |
| Granted (Awarded) | — |  |  | — |  |
| Vested (Released) | — |  |  | — |  |
| Outstanding and unvested at March 31, 2020 | 17 |  |  | $ | 81.92 |  |

[0000926326-20-000014:notes:160]
As of March 31, 2020, total unrecognized compensation cost related to RSAs was $0.2 million, which is expected to be recognized over the remaining weighted-average vesting period of 0.1 years.

[0000926326-20-000014:notes:161]
Performance-Based Restricted Stock Units (“PSUs”)

[0000926326-20-000014:notes:162]
A summary of the performance-based restricted stock activity under the 2009 Plan is presented below for the three months ended March 31, 2020:

[0000926326-20-000014:notes:163]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value Per Unit |
|  | (In thousands, except per share data) |  |  |
| Outstanding at December 31, 2019 | 134 |  |  | $ | 55.82 |  |
| Granted | 63 |  |  | 82.41 |  |
| Vested | (15) |  |  | 72.02 |  |
| Forfeited | — |  |  | — |  |
| Outstanding and unvested at March 31, 2020 | 182 |  |  | $ | 63.63 |  |

[0000926326-20-000014:notes:164]
As of March 31, 2020, total unrecognized compensation cost related to PSUs was approximately $6.7 million, which is expected to be recognized over the remaining weighted-average vesting period of 1.5 years.

[0000926326-20-000014:notes:165]
Summary of Shares Reserved for Future Issuance under Equity Incentive Plans

[0000926326-20-000014:notes:166]
The Company had the following ordinary shares reserved for future issuance under its equity incentive plans as of March 31, 2020:

[0000926326-20-000014:notes:167]
|  | Number of Shares |
|  | (In thousands) |
| Share options outstanding | 4,038 |  |
| Non-vested restricted stock awards | 755 |  |
| Shares authorized for future issuance | 2,252 |  |
| ESPP shares available for future issuance | 1,322 |  |
| Total shares reserved for future issuance |  | 8,367 |  |

[0000926326-20-000014:notes:168]
Stock Repurchase Program

[0000926326-20-000014:notes:169]
On August 2, 2016, the Company's Board of Directors (the “Board”) authorized a stock repurchase program providing for the repurchase of up to $50.0 million of the Company’s common stock (the “2016 Repurchase Program”). The 2016 Repurchase Program is in addition to the stock repurchase program approved by the Board on November 4, 2014. As of March 31, 2020, the maximum dollar value of shares that may yet be purchased under the two repurchase programs was $54.9 million. The stock repurchase programs do not obligate the Company to repurchase any specific number of shares, and the Company may terminate or suspend the repurchase programs at any time. 
During the three months ended March 31, 2020 and 2019, the Company did not repurchase any of its outstanding common stock.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000926326-20-000014:notes:170]
[same as prior period, unchanged from 0000926326-19-000033:notes:190]

[0000926326-20-000014:notes:171]
For the three months ended March 31, 2020, the Company did not sell any of its common stock under the Distribution Agreement.

[0000926326-20-000014:notes:172]
For the three months ended March 31, 2019, the Company received gross proceeds of $20.6 million from sales of its common stock under the Distribution Agreement and incurred issuance costs of $0.4 million on sales of approximately 243,000 shares of its common stock at an average price of approximately $84.98 per share. 
As of March 31, 2020, the Company had an aggregate of $31.5 million available to be offered under the Distribution Agreement.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000926326-20-000014:notes:173]
Restructuring ExpensesIn the first quarter of 2020, the Company announced a company-wide organizational realignment initiative in order to more effectively align its organizational infrastructure and operations with the strategic vision of the autonomous pharmacy. During the three months ended March 31, 2020, the Company incurred and accrued $3.5 million of employee severance costs and related expenses. As of March 31, 2020, the unpaid balance related to this restructuring plan was $1.7 million.
