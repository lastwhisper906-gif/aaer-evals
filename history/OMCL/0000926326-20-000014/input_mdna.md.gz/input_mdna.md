# OMCL MD&A — 0000926326-20-000014


## mdna

[0000926326-20-000014:mdna:1]
[same as prior period, unchanged from 0000926326-19-000033:mdna:1]

[0000926326-20-000014:mdna:2]
[same as prior period, unchanged from 0000926326-19-000033:mdna:2]

[0000926326-20-000014:mdna:3]
•our expectations about the impact of the ongoing global novel coronavirus (COVID-19) pandemic (including efforts to contain the spread of the pandemic) on our workforce and operations, as well as the impacts on our customers and suppliers, and the anticipated effects of the pandemic and associated containment measures on our business, financial condition, liquidity, and results of operations;

[0000926326-20-000014:mdna:4]
•our expectations regarding our future pipeline and product bookings;

[0000926326-20-000014:mdna:5]
•the extent and timing of future revenues, including the amounts of our current backlog;

[0000926326-20-000014:mdna:6]
•the size or growth of our market or market share;

[0000926326-20-000014:mdna:7]
•our beliefs about drivers of demand for our solutions, market opportunities in certain product categories and continued expansion in these product categories, as well as our belief that our technology, services, and solutions within these categories position us well to address the needs of retail, acute, and post-acute pharmacy providers;

[0000926326-20-000014:mdna:8]
•our ability to acquire companies, businesses, products or technologies on commercially reasonable terms and integrate such acquisitions effectively;

[0000926326-20-000014:mdna:9]
•our goal of advancing our platform with new product introductions annually;

[0000926326-20-000014:mdna:10]
•our ability to deliver on the autonomous pharmacy vision, as well as our plan to integrate our current offerings and technologies on a cloud infrastructure and invest in broadening our solutions across certain key areas as we execute on this vision;

[0000926326-20-000014:mdna:11]
•continued investment in the autonomous pharmacy vision, our beliefs about the anticipated benefits of such investments, and our expectations regarding continued growth in subscription and cloud-based offerings as we execute on this vision;

[0000926326-20-000014:mdna:12]
•our belief that our solutions and vision for fully autonomous medication management are strongly aligned with long-term trends in the healthcare market and well-positioned to address the evolving needs of the healthcare institutions;

[0000926326-20-000014:mdna:13]
•planned new products and services;

[0000926326-20-000014:mdna:14]
•the bookings, revenue, and margin opportunities presented by new products, emerging markets, and international markets;

[0000926326-20-000014:mdna:15]
•our ability to align our cost structure and headcount with our current business expectations;

[0000926326-20-000014:mdna:16]
•the operating margins or earnings per share goals we may set;

[0000926326-20-000014:mdna:17]
•the outcome of any legal proceedings to which we are a party;

[0000926326-20-000014:mdna:18]
•our projected target long-term revenues and revenue growth rate, long-term operating margins, and free cash flow conversion;

[0000926326-20-000014:mdna:19]
•our ability to protect our intellectual property and operate our business without infringing the intellectual property rights of others;

[0000926326-20-000014:mdna:20]
•the expected impacts of new accounting standards or changes to existing accounting standards;

[0000926326-20-000014:mdna:21]
•our expected future uses of cash and the sufficiency of our sources of funding; and

[0000926326-20-000014:mdna:22]
•our ability to generate cash from operations and our estimates regarding the sufficiency of our cash resources.

[0000926326-20-000014:mdna:23]
In some cases, you can identify forward-looking statements by terms such as "anticipates," "believes," "could," "estimates," "expects," "intends," "seeks," "may," "plans," "potential," "predicts," "projects," "should," "will," "would," and variations of these terms and similar expressions. Forward-looking statements are based on our current expectations and assumptions and are subject to known and unknown risks and uncertainties, which may cause our actual results, performance, or achievements to be materially different from those expressed or implied in the forward-looking statements.

[0000926326-20-000014:mdna:24]
All references in this report to "Omnicell," "our," "us," "we," or the "Company" collectively refer to Omnicell, Inc., a Delaware corporation, and its subsidiaries. The term "Omnicell, Inc.," refers only to Omnicell, Inc., excluding its subsidiaries.

[0000926326-20-000014:mdna:25]
[same as prior period, unchanged from 0000926326-19-000033:mdna:21]

[0000926326-20-000014:mdna:26]
[same as prior period, unchanged from 0000926326-19-000033:mdna:22]

[0000926326-20-000014:mdna:27]
[same as prior period, unchanged from 0000926326-19-000033:mdna:23]

[0000926326-20-000014:mdna:28]
We are a leading provider of medication management automation solutions and adherence tools for healthcare systems and pharmacies. As we build on the vision of the autonomous pharmacy - a more fully automated and digitized system of medication management - we believe we will further help enable healthcare providers to improve patient safety, increase efficiency, lower costs, tighten regulatory compliance, and address population health challenges.

[0000926326-20-000014:mdna:29]
Over 6,000 facilities worldwide use our automation and analytics solutions to help increase operational efficiency, reduce medication errors, deliver actionable intelligence, and improve patient safety. More than 40,000 institutional and retail pharmacies across North America and the United Kingdom leverage our innovative medication adherence and population health solutions to improve patient engagement and adherence to prescriptions, helping to reduce costly hospital readmissions. We sell our product and consumable solutions together with related service offerings. Revenues generated in the United States represented 90% and 89% of our total revenues for the three months ended March 31, 2020 and 2019, respectively.

[0000926326-20-000014:mdna:30]
Over the past several years, our business has expanded from a single-point solution to a platform of products and services that will help to further the vision of the autonomous pharmacy. This has resulted in larger deal sizes across multiple products and installations for customers and, we believe, more comprehensive, valuable, and enduring relationships.

[0000926326-20-000014:mdna:31]
We utilize product bookings as an indicator of the success of our business. Product bookings consist of all firm orders, as evidenced generally by a non-cancelable contract and purchase order for equipment and software products, and by a purchase order for consumables. Equipment and software product bookings are generally installable within twelve months of booking, and other than sales based on subscription services, generally recorded as revenue upon customer receipts of goods or acceptance of the installation.

[0000926326-20-000014:mdna:32]
In addition to product solution sales, we provide services to our customers. We provide installation planning and consulting as part of most product sales which is included in the initial price of the solution. To help assure the maximum

[0000926326-20-000014:mdna:33]
availability of our systems, our customers typically purchase maintenance and support contracts in increments of one to five years. As a result of the growth of our installed base of customers, our service revenues have also grown.

[0000926326-20-000014:mdna:34]
Our full-time headcount was approximately 2,750 and 2,700 on March 31, 2020 and December 31, 2019, respectively.

[0000926326-20-000014:mdna:35]
We have not in the past sold, and have no future plans to sell, our products, either directly or indirectly, to customers located in countries that are identified as state sponsors of terrorism by the U.S. Department of State, or those subject to economic sanctions and export controls.

[0000926326-20-000014:mdna:36]
[same as prior period, unchanged from 0000926326-19-000033:mdna:27]

[0000926326-20-000014:mdna:37]
We manage our operations as a single segment for the purposes of assessing performance and making operating decisions. Our Chief Operating Decision Maker ("CODM") is our Chief Executive Officer. The CODM allocates resources and evaluates the performance of Omnicell at the consolidated level using information about its revenues, gross profit, income from operations, and other key financial data. All significant operating decisions are based upon an analysis of Omnicell as one operating segment, which is the same as our reporting segment.

[0000926326-20-000014:mdna:38]
[same as prior period, unchanged from 0000926326-19-000033:mdna:29]

[0000926326-20-000014:mdna:39]
We are committed to being the care provider’s most trusted partner and executing on the vision of the autonomous pharmacy by delivering automation, intelligence, and services designed to transform the pharmacy care delivery model, helping to dramatically improve outcomes and lower costs for our healthcare partners. We believe there are significant challenges in pharmacy that drive the demand for our solutions and represent large market opportunities in three product categories:

[0000926326-20-000014:mdna:40]
•Point of Care.  As a market leader, we expect to continue expansion of this product category as customers increase use of our dispensing systems in more areas within their hospitals. In addition, we are early in the replacement cycle of our XT Series automated dispensing systems which we believe is a significant market opportunity and we expect to continue to focus on further penetrating markets through competitive conversion. We believe our current portfolio within the Point of Care market and new innovation and services will continue to drive improved outcomes and lower costs for our customers.

[0000926326-20-000014:mdna:41]
•Central Pharmacy.  This market represents the beginning of the medication management process in Acute Care Settings, and, we believe, the next big automation opportunity to replace manual and repetitive processes which are common in the pharmacy today. Manual processes are prone to significant errors, and products such as our IV sterile compounding solutions and XR2 Automated Central Pharmacy system automate these manual processes and are designed to reduce the risk of error for our healthcare partners. We believe new products and innovation in the Central Pharmacy market create opportunities to replace prior generation Central Pharmacy robotics and carousels. The Central Pharmacy also represents an opportunity to provide technology enabled services designed to reduce the administrative burden on the pharmacy and allow clinicians to operate at the top of their license.

[0000926326-20-000014:mdna:42]
•Retail, Institutional, and Payer.  We believe the Retail, Institutional, and Payer market represents a large opportunity as the majority of drugs are distributed in the non-acute sector. New technology is leading to innovation at traditional retail providers, which combined with the move to value-based care results, we believe will incentivize the market to adopt solutions to help providers and payers engage patients in new ways that lower the total cost of care. We believe adoption of our Population Health Solutions portfolio of software products and services, along with medication adherence packaging, will increase adherence performance rates, increase prescription volume for our customers and reduce hospital and emergency room visits due to improved adherence.

[0000926326-20-000014:mdna:43]
We believe our technology, services, and solutions within these three product categories position us well to address the needs of retail, acute, and post-acute pharmacy providers.

[0000926326-20-000014:mdna:44]
Omnicell’s Response to Coronavirus (COVID-19)

[0000926326-20-000014:mdna:45]
In March 2020, the COVID-19 outbreak was declared a global pandemic by the World Health Organization and a U.S national emergency. Efforts to contain the spread of COVID-19 have intensified, with the implementation of travel restrictions, shelter-in-place orders, business closures and suspensions, cancelled events, and social distancing.

[0000926326-20-000014:mdna:46]
Keeping in mind our role in the healthcare industry, we are closely monitoring the COVID-19 pandemic. Our top priorities are protecting the health and well-being of our customers, their patients, and our employees, while maintaining business continuity to meet the needs of our customers. In order to operate in a safe manner, we are following the health and safety guidelines of the U.S. Centers for Disease Control and Prevention, and local and state public health departments in each of the regions where we operate. All of our manufacturing, distribution, and other facilities are operating under these guidelines. Manufacturing and distribution facilities have remained open due to our qualification as an essential business and we continue

[0000926326-20-000014:mdna:47]
to manufacture our products with limited disruptions. In addition to increased cleaning and disinfection processes at our manufacturing facilities, we have implemented alternative scheduling procedures to enhance social distancing protocols. We have also procured and distributed personal protective equipment (“PPE”) to our customer-facing and manufacturing personnel consistent with guidelines we developed to help ensure proper distribution and use of such PPE. The vast majority of our non-manufacturing and non-customer facing personnel have transitioned to a work from home environment.

[0000926326-20-000014:mdna:48]
To support the needs of our customers on the frontline of the pandemic, we have launched a Rapid Response program to fast-track production and deployment of our XT Series automated dispensing systems to our customers. We have streamlined our ordering and installation processes with preconfigured XT Series medication and supply dispensing systems that are designed to offer our customers flexibility and maximum emergency impact. We believe these models have ample capacity and flexibility to meet a wide variety of needs of our customers, while maintaining security, safety, and workflow efficiency. In addition, to minimize the need for onsite visits and respect social distancing protocols, we are providing remote service options, training programs, and product demonstrations for our customers, and leveraging technology to enable our sales team to operate in a remote sales environment.

[0000926326-20-000014:mdna:49]
From a supply chain perspective, we are working closely with our vendors to help ensure we are able to source key components and maintain appropriate inventory levels to meet customer demand. To date, we have experienced very little disruption in our supply chain, which has enabled us to continue operating our factories at full capacity to serve our customer base. However, we cannot predict how long the pandemic and measures intended to contain the spread of COVID-19 will continue and what effect COVID-19 and the associated containment measures will have on our suppliers and vendors, in particular for any of our suppliers and vendors that may not qualify as essential businesses and suffer more significant disruptions to their business operations.

[0000926326-20-000014:mdna:50]
Health systems are facing increased costs due to large surge expenditures to cover COVID-19 caseload and increasing prices for needed equipment, decreased revenue due to cancelled or postponed elective procedures and other reduced demand, as well as cash flow challenges. We believe these financial pressures have led our customers to delay or defer purchasing decisions and/or implementation of our solutions and expect that our customers will continue such delays and deferrals for the near to medium-term future. Moreover, the COVID-19 pandemic and measures to contain its impact have caused material disruptions in both national and global financial markets and economies. During the second half of March 2020 and into May 2020, we started to see a slowdown of product bookings and expect to see lower product bookings and revenues during the fiscal year 2020 compared to management’s expectations prior to the COVID-19 outbreak. With respect to bookings for new sales, beginning in the second half of March, we have seen hospitals begin to slow purchasing decisions. Additionally, our ability to access hospitals in order to perform implementations of capital equipment will likely be delayed in many cases, as many hospitals are consumed with treating sick patients. As a result of the slowdown in purchasing decisions and our reduced interactions with our customers due to social distancing protocols, our bookings are behind our internal estimates as of this time. In response to the COVID-19 pandemic, we have implemented and continue to focus on cost reduction initiatives in all aspects of our business, including, but not limited to, reduced travel costs, decreases in employee-related expenses, negotiating discounts with vendors, and delayed hiring and capital expenditures.

[0000926326-20-000014:mdna:51]
In addition, on March 27, 2020, the Coronavirus Aid, Relief and Economic Security Act (the “CARES Act”) was signed into law in response to the COVID-19 pandemic, and provides tax relief to businesses. The CARES Act includes deferral of certain payroll taxes, relief for retaining employees, and certain other provisions. We are evaluating the impact of the CARES Act and currently expect to benefit from the deferral of certain payroll taxes through the end of fiscal year 2020.

[0000926326-20-000014:mdna:52]
While our fiscal year 2020 results will be impacted by the challenges and opportunities brought on by the COVID-19 pandemic, we remain confident in the overall health of our business and in our ability to continue to execute on our long-term strategy and navigate through these unusual times. However, the impact of the COVID-19 pandemic and related containment measures cannot be predicted and may adversely affect, perhaps materially, our business, results of operations, financial condition, and liquidity.

[0000926326-20-000014:mdna:53]
[same as prior period, unchanged from 0000926326-19-000033:mdna:39]

[0000926326-20-000014:mdna:54]
Our discussion and analysis of our financial condition and results of operations are based on our Condensed Consolidated Financial Statements, which have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”). The preparation of these financial statements requires us to make certain estimates and assumptions that affect the reported amounts of assets and liabilities, disclosure of any contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting periods. We regularly review our estimates and assumptions, which are based on historical experience and various other factors that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of certain assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates and assumptions.

[0000926326-20-000014:mdna:55]
[same as prior period, unchanged from 0000926326-19-000033:mdna:42]

[0000926326-20-000014:mdna:56]
•Revenue recognition;

[0000926326-20-000014:mdna:57]
•Allowance for credit losses for accounts receivable, unbilled receivables, and net investment in sales-type leases;

[0000926326-20-000014:mdna:58]
•Leases;

[0000926326-20-000014:mdna:59]
•Inventory;

[0000926326-20-000014:mdna:60]
•Software development costs;

[0000926326-20-000014:mdna:61]
•Impairment of goodwill and intangible assets;

[0000926326-20-000014:mdna:62]
•Share-based compensation; and

[0000926326-20-000014:mdna:63]
•Accounting for income taxes.

[0000926326-20-000014:mdna:64]
There were no material changes in the matters for which we make critical accounting estimates in the preparation of our Condensed Consolidated Financial Statements during the three months ended March 31, 2020 as compared to those disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our annual report on Form 10-K for the year ended December 31, 2019, except as discussed in “Recently Adopted Authoritative Guidance” in Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report.

[0000926326-20-000014:mdna:65]
[same as prior period, unchanged from 0000926326-19-000033:mdna:52]

[0000926326-20-000014:mdna:66]
Refer to Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to Condensed Consolidated Financial Statements in this quarterly report for a description of recently issued accounting pronouncements, including the expected dates of adoption and estimated effects on our results of operations, financial position, and cash flows.

[0000926326-20-000014:mdna:67]
[same as prior period, unchanged from 0000926326-19-000033:mdna:54]

[0000926326-20-000014:mdna:68]
[same as prior period, unchanged from 0000926326-19-000033:mdna:55]

[0000926326-20-000014:mdna:69]
|  | Three Months Ended March 31, |  |  |  |  |  |  |
|  |  |  |  |  | Change in |  |  |
|  | 2020 |  | 2019 |  | $ |  | % |
|  | (Dollars in thousands) |  |  |  |  |  |  |
| Product revenues | $ | 170,073 |  |  | $ | 145,610 |  |  | $ | 24,463 |  |  | 17% |
| Percentage of total revenues | 74% |  | 72% |  |  |  |  |
| Services and other revenues | 59,613 |  |  | 56,907 |  |  | 2,706 |  |  | 5% |
| Percentage of total revenues | 26% |  | 28% |  |  |  |  |
| Total revenues | $ | 229,686 |  |  | $ | 202,517 |  |  | $ | 27,169 |  |  | 13% |

[0000926326-20-000014:mdna:70]
Product revenues represented 74% and 72% of total revenues for the three months ended March 31, 2020 and 2019, respectively. Product revenues increased by $24.5 million, primarily driven by the growth of XT Series automated dispensing systems due to increased XT Series upgrades from the previous generation of product, competitive conversions, and other add-on equipment.

[0000926326-20-000014:mdna:71]
Services and other revenues represented 26% and 28% of total revenues for the three months ended March 31, 2020 and 2019, respectively. Services and other revenues include revenues from service and maintenance contracts, and rentals of automation systems. Services and other revenues increased by $2.7 million, primarily due to an increase in our installed customer base, as well as an increase in revenues from Population Health Solutions and IV solutions.

[0000926326-20-000014:mdna:72]
Our international sales represented 10% and 11% of total revenues for the three months ended March 31, 2020 and 2019, respectively, and are expected to be affected by foreign currency exchange rate fluctuations. We are unable to predict the extent to which revenues in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-20-000014:mdna:73]
Our ability to continue to grow revenues is dependent on our ability to continue to obtain orders from customers, our ability to produce quality products and consumables to fulfill customer demand, the volume of installations we are able to complete, our ability to meet customer needs by providing a quality installation experience, and our flexibility in manpower

[0000926326-20-000014:mdna:74]
allocations among customers to complete installations on a timely basis. The timing of our product revenues for equipment is primarily dependent on when our customers’ schedules allow for installations.

[0000926326-20-000014:mdna:75]
The COVID-19 pandemic has not had a significant impact on our revenues for the three months ended March 31, 2020. The pandemic creates uncertainties related to delays in installations and potential reductions in hospitals’ capital and overall spending in the near to medium-term future, and depending on the duration of the COVID-19 pandemic and related containment measures, potentially into the longer-term. During the second half of March 2020 and into May 2020, we started to see a slowdown of product bookings and expect to see lower product bookings and revenues during the fiscal year 2020 compared to management’s expectations prior to the COVID-19 outbreak. These reductions are expected to be partially offset by revenues generated from the Rapid Response program. We cannot estimate the extent to which the COVID-19 pandemic will impact our revenues in future periods.

[0000926326-20-000014:mdna:76]
[same as prior period, unchanged from 0000926326-19-000033:mdna:65]

[0000926326-20-000014:mdna:77]
Cost of revenues is primarily comprised of three general categories: (i) standard product costs, which account for the majority of the product cost of revenues that are provided to customers, and are inclusive of purchased material, labor to build the product and overhead costs associated with production; (ii) installation costs as we install our equipment at the customer site and include costs of the field installation personnel, including labor, travel expenses, and other expenses; and (iii) other costs, including variances in standard costs and overhead, scrap costs, rework, warranty, provisions for excess and obsolete inventory, and amortization of software development costs and intangibles.

[0000926326-20-000014:mdna:78]
|  | Three Months Ended March 31, |  |  |  |  |  |  |
|  |  |  |  |  | Change in |  |  |
|  | 2020 |  | 2019 |  | $ |  | % |
|  | (Dollars in thousands) |  |  |  |  |  |  |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | $ | 90,272 |  |  | $ | 78,811 |  |  | $ | 11,461 |  |  | 15% |
| As a percentage of related revenues | 53% |  | 54% |  |  |  |  |
| Cost of services and other revenues | 29,792 |  |  | 26,589 |  |  | 3,203 |  |  | 12% |
| As a percentage of related revenues | 50% |  | 47% |  |  |  |  |
| Total cost of revenues | $ | 120,064 |  |  | $ | 105,400 |  |  | $ | 14,664 |  |  | 14% |
| As a percentage of total revenues | 52% |  | 52% |  |  |  |  |
| Gross profit | $ | 109,622 |  |  | $ | 97,117 |  |  | $ | 12,505 |  |  | 13% |
| Gross margin | 48% |  | 48% |  |  |  |  |

[0000926326-20-000014:mdna:79]
Cost of revenues for the three months ended March 31, 2020 compared to the three months ended March 31, 2019 increased by $14.7 million, of which $11.5 million was attributed to the increase in cost of product revenues and $3.2 million was attributed to the increase in cost of services and other revenues. The increase in cost of product revenues was primarily driven by the increase in product revenues of $24.5 million for the three months ended March 31, 2020 compared to the three months ended March 31, 2019, partially offset by sales of product portfolios with higher margins, lower costs associated with the XT Series supply chain and manufacturing cost-saving initiatives, as well as economies of scale. The increase in cost of services and other revenues was primarily driven by the increase in services and other revenues of $2.7 million for the three months ended March 31, 2020 compared to the three months ended March 31, 2019, as well as additional investments in our service business to support new product offerings.

[0000926326-20-000014:mdna:80]
The overall gross margin remained relatively consistent due to lower costs associated with the XT Series supply chain and manufacturing cost-saving initiatives, economies of scale, and product mix, offset by additional investments in our service business. Our gross profit for the three months ended March 31, 2020 was $109.6 million, as compared to $97.1 million for the three months ended March 31, 2019.

[0000926326-20-000014:mdna:81]
While there has not been a significant impact to cost of revenues and gross margins due to the COVID-19 pandemic during the three months ended March 31, 2020, we expect to incur additional costs related to the COVID-19 pandemic including, but not limited to, higher delivery costs to expedite shipments, additional compensation for certain essential employees, and the purchase of personal protective equipment for our customer-facing and manufacturing personnel. However, the impact the COVID-19 pandemic will have on gross margins cannot be estimated.

[0000926326-20-000014:mdna:82]
[same as prior period, unchanged from 0000926326-19-000033:mdna:74]

[0000926326-20-000014:mdna:83]
|  | Three Months Ended March 31, |  |  |  |  |  |  |
|  |  |  |  |  | Change in |  |  |
|  | 2020 |  | 2019 |  | $ |  | % |
|  | (Dollars in thousands) |  |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | $ | 18,652 |  |  | $ | 16,078 |  |  | $ | 2,574 |  |  | 16% |
| As a percentage of total revenues | 8% |  | 8% |  |  |  |  |
| Selling, general, and administrative | 78,819 |  |  | 68,278 |  |  | 10,541 |  |  | 15% |
| As a percentage of total revenues | 34% |  | 34% |  |  |  |  |
| Total operating expenses | $ | 97,471 |  |  | $ | 84,356 |  |  | $ | 13,115 |  |  | 16% |
| As a percentage of total revenues | 42% |  | 42% |  |  |  |  |
| Interest and other income (expense), net | $ | (822) |  |  | $ | (1,410) |  |  | $ | 588 |  |  | (42)% |

[0000926326-20-000014:mdna:84]
Research and Development. Research and development expenses increased by $2.6 million for the three months ended March 31, 2020 compared to the three months ended March 31, 2019. The increase was primarily attributed to increases in employee-related expenses due to the higher headcount in the research and development function as well as employee-related expenses related to a restructuring initiative. The increased spend is a result of our continued investments into automation, intelligence, and the cloud data platform.

[0000926326-20-000014:mdna:85]
Selling, General, and Administrative. Selling, general, and administrative expenses increased by $10.5 million for the three months ended March 31, 2020 compared to the three months ended March 31, 2019, primarily due to overall growth of operations and increase in overall headcount. The increase was primarily due to an increase of $6.1 million in employee-related expenses primarily related to increased headcount, an increase of $2.7 million related to a restructuring initiative, and an increase of $1.4 million in consulting expenses.

[0000926326-20-000014:mdna:86]
In response to the COVID-19 pandemic, we have implemented and continue to focus on cost reduction initiatives in all aspects of our business, including, but not limited to, reduced travel costs, decreases in employee-related expenses, negotiating discounts with vendors, and delayed hiring and capital expenditures. However, we cannot predict the full impact of the COVID-19 pandemic on our operating expenses.

[0000926326-20-000014:mdna:87]
Interest and Other Income (Expense), Net. Interest and other income (expense), net decreased by $0.6 million for the three months ended March 31, 2020 compared to the three months ended March 31, 2019, primarily driven by a $0.5 million increase in other income and a $0.1 million decrease in other expenses. The increase in other income was primarily attributable to rebates and benefits from certain arrangements outside of our normal course of business. The decrease in other expenses was primarily due to lower interest expense as a result of lower outstanding debt balance during the three months ended March 31, 2020 as compared to the three months ended March 31, 2019, partially offset by unfavorable foreign currency fluctuations during the period.

[0000926326-20-000014:mdna:88]
[same as prior period, unchanged from 0000926326-19-000033:mdna:83]

[0000926326-20-000014:mdna:89]
|  | Three Months Ended March 31, |  |  |  |  |  |  |
|  |  |  |  |  | Change in |  |  |
|  | 2020 |  | 2019 |  | $ |  | % |
|  | (Dollars in thousands) |  |  |  |  |  |  |
| Provision for income taxes | $ | 18 |  |  | $ | 8,067 |  |  | $ | (8,049) |  |  | (100)% |

[0000926326-20-000014:mdna:90]
Our annual effective tax rate before discrete items was 26.6% and 23.3% for the three months ended March 31, 2020 and 2019, respectively. The increase in the estimated annual effective tax rate for the three months ended March 31, 2020 compared to the same period in 2019 was primarily due to state income taxes and non-deductible equity charges.

[0000926326-20-000014:mdna:91]
Provision for income taxes for the three months ended March 31, 2020 included net discrete income tax benefit of $3.0 million, primarily due to a $2.8 million tax benefit from equity compensation.

[0000926326-20-000014:mdna:92]
Provision for income taxes for the three months ended March 31, 2019 included net discrete income tax expense of $5.4 million. The net discrete income tax expense was primarily due to a recognized gain on the sale of certain intellectual

[0000926326-20-000014:mdna:93]
property rights by Aesynt B.V. to Omnicell, Inc., which resulted in a tax expense, net of tax benefit, of $9.6 million, partially offset by a $4.6 million tax benefit from equity compensation benefit.

[0000926326-20-000014:mdna:94]
[same as prior period, unchanged from 0000926326-19-000033:mdna:89]

[0000926326-20-000014:mdna:95]
[same as prior period, unchanged from 0000926326-19-000033:mdna:90]

[0000926326-20-000014:mdna:96]
We had cash and cash equivalents of $104.1 million at March 31, 2020 compared to $127.2 million at December 31, 2019. All of our cash and cash equivalents are invested in bank accounts with major financial institutions.

[0000926326-20-000014:mdna:97]
Our cash position and working capital at March 31, 2020 and December 31, 2019 were as follows:

[0000926326-20-000014:mdna:98]
|  | March 31,2020 |  | December 31,2019 |
|  | (In thousands) |  |  |
| Cash | $ | 104,080 |  |  | $ | 127,210 |  |
| Working Capital | $ | 229,883 |  |  | $ | 246,242 |  |

[0000926326-20-000014:mdna:99]
Our ratio of current assets to current liabilities was 1.9:1 at March 31, 2020 and 2.0:1 at December 31, 2019.

[0000926326-20-000014:mdna:100]
[same as prior period, unchanged from 0000926326-19-000033:mdna:95]

[0000926326-20-000014:mdna:101]
Credit Agreements

[0000926326-20-000014:mdna:102]
On January 5, 2016, we entered into a $400.0 million senior secured credit facility pursuant to a credit agreement with certain lenders, Wells Fargo Securities, LLC as sole lead arranger, and Wells Fargo Bank, National Association, as administrative agent (as subsequently amended as discussed below, the “Prior Credit Agreement”). The Prior Credit Agreement provided for a $200.0 million term loan facility (the “Prior Term Loan Facility”), and prior to the amendment discussed below, a $200.0 million revolving credit facility (the “Prior Revolving Credit Facility” and together with the Prior Term Loan Facility, the “Prior Facilities”). In addition, the Prior Credit Agreement included a letter of credit sub-limit of up to $10.0 million and a swing line loan sub-limit of up to $10.0 million.

[0000926326-20-000014:mdna:103]
On April 11, 2017 and December 26, 2017, we entered into amendments to the Prior Credit Agreement. Under these amendments, the Prior Revolving Credit Facility was increased from $200.0 million to $315.0 million and certain other modifications were made.

[0000926326-20-000014:mdna:104]
On November 15, 2019, we refinanced the Prior Credit Agreement and entered into an Amended and Restated Credit Agreement (the “A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers and Wells Fargo Bank, National Association, as administrative agent. The A&R Credit Agreement replaced the Prior Credit Agreement and provides for (a) a five-year revolving credit facility of $500.0 million (the “Current Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million. In addition, the A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. On November 15, 2019, the $80.0 million outstanding term loan balance under the Prior Facilities was transferred to the Current Revolving Credit Facility.

[0000926326-20-000014:mdna:105]
As of March 31, 2020, there was no outstanding loan balance for the Current Revolving Credit Facility and we were in full compliance with all covenants. Refer to Note 8, Debt and Credit Agreements, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report. We expect to use future loans under the Current Revolving Credit Facility, if any, for working capital, potential acquisitions, and other general corporate purposes.

[0000926326-20-000014:mdna:106]
[same as prior period, unchanged from 0000926326-19-000033:mdna:100]

[0000926326-20-000014:mdna:107]
[same as prior period, unchanged from 0000926326-19-000033:mdna:101]

[0000926326-20-000014:mdna:108]
For the three months ended March 31, 2020, we did not sell any of our common stock under the Distribution Agreement.

[0000926326-20-000014:mdna:109]
For the three months ended March 31, 2019, we received gross proceeds of $20.6 million from sales of our common stock under the Distribution Agreement and incurred issuance costs of $0.4 million on sales of approximately 243,000 shares of our common stock at an average price of approximately $84.98 per share.

[0000926326-20-000014:mdna:110]
As of March 31, 2020, we had an aggregate of $31.5 million available to be offered under the Distribution Agreement.

[0000926326-20-000014:mdna:111]
[same as prior period, unchanged from 0000926326-19-000033:mdna:106]

[0000926326-20-000014:mdna:112]
Our future uses of cash are expected to be primarily for working capital, capital expenditures, and other contractual obligations. We also expect a continued use of cash for potential acquisitions and acquisition-related activities.

[0000926326-20-000014:mdna:113]
Our stock repurchase programs have a total of $54.9 million remaining for future repurchases as of March 31, 2020, which may result in additional use of cash. Refer to “Stock Repurchase Program” under Note 13, Employee Benefits and Share-Based Compensation, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report. There were no stock repurchases during the three months ended March 31, 2020 and 2019.

[0000926326-20-000014:mdna:114]
Based on our current business plan and revenue backlog, we believe that our existing cash and cash equivalents, our anticipated cash flows from operations, cash generated from the exercise of employee stock options and purchases under our employee stock purchase plan, along with the availability of funds under the Current Revolving Credit Facility will be sufficient to meet our cash needs for working capital, capital expenditures, potential acquisitions, and other contractual obligations for at least the next twelve months. For periods beyond the next twelve months, we also anticipate that our net operating cash flows plus existing balances of cash and cash equivalents will suffice to fund the continued growth of our business.

[0000926326-20-000014:mdna:115]
We believe that our current financial position and resources will allow us to manage the anticipated impact of the COVID-19 pandemic on our business for the foreseeable future, including any potential changes in timing of revenue recognition or potential extensions in customer payments. However, COVID-19 and related measures to contain its impact have caused material disruptions in both national and global financial markets and economies. The future impact of COVID-19 and these containment measures cannot be predicted with certainty and may increase our borrowing costs and other costs of capital and otherwise adversely affect our business, results of operations, financial condition, and liquidity, and we cannot assure that we will have access to external financing at times and on terms we consider acceptable, or at all, or that we will not experience other liquidity issues going forward.

[0000926326-20-000014:mdna:116]
[same as prior period, unchanged from 0000926326-19-000033:mdna:111]

[0000926326-20-000014:mdna:117]
[same as prior period, unchanged from 0000926326-19-000033:mdna:112]

[0000926326-20-000014:mdna:118]
|  | Three Months Ended March 31, |  |  |
|  | 2020 |  | 2019 |
|  | (In thousands) |  |  |
| Net cash provided by (used in): |  |  |  |
| Operating activities | $ | 25,231 |  |  | $ | 26,497 |  |
| Investing activities | (13,775) |  |  | (16,697) |  |
| Financing activities | (33,766) |  |  | (178) |  |
| Effect of exchange rate changes on cash and cash equivalents | (820) |  |  | 430 |  |
| Net increase (decrease) in cash and cash equivalents | $ | (23,130) |  |  | $ | 10,052 |  |

[0000926326-20-000014:mdna:119]
[same as prior period, unchanged from 0000926326-19-000033:mdna:114]

[0000926326-20-000014:mdna:120]
[same as prior period, unchanged from 0000926326-19-000033:mdna:115]

[0000926326-20-000014:mdna:121]
Net cash provided by operating activities was $25.2 million for the three months ended March 31, 2020, primarily consisting of net income of $11.3 million adjusted for non-cash items of $26.5 million, offset by changes in assets and liabilities of $12.6 million. The non-cash items primarily consisted of depreciation and amortization expense of $14.0 million, share-based compensation expense of $10.7 million, amortization of operating lease right-of-use assets of $2.7 million, amortization of debt issuance costs of $0.2 million, and a change in deferred income taxes of $1.1 million. Changes in assets and liabilities

[0000926326-20-000014:mdna:122]
include cash outflows from (i) an increase in accounts receivable and unbilled receivables of $16.1 million primarily due to an increase in billings late in the quarter as well as timing of collections, (ii) a decrease in accrued compensation of $9.2 million primarily due to a decrease in accrued commissions and bonuses, as well as timing of payroll and ESPP purchases, (iii) an increase in inventories of $5.7 million to support higher production for forecasted sales and to fulfill order backlog, (iv) an increase in other long-term assets of $2.8 million; and (v) a decrease in operating lease liabilities of $2.8 million. These cash outflows were partially offset by (i) an increase in deferred revenues of $16.9 million primarily due to the timing of order shipments and recognition of revenues for product requiring installation, (ii) a decrease in prepaid commissions of $2.9 million, (iii) an increase in accrued liabilities of $2.7 million, and (iv) a decrease in other current assets of $1.0 million.

[0000926326-20-000014:mdna:123]
Net cash provided by operating activities was $26.5 million for the three months ended March 31, 2019, primarily consisting of net income of $3.3 million adjusted for non-cash items of $27.7 million, offset by changes in assets and liabilities of $4.5 million. The non-cash items primarily consisted of depreciation and amortization expense of $12.6 million, share-based compensation expense of $8.4 million, amortization of operating lease right-of-use assets of $2.6 million, amortization of debt issuance costs of $0.6 million, and a change in deferred income taxes of $3.1 million. Changes in assets and liabilities include cash outflows from (i) a decrease in accrued compensation of $12.6 million primarily due to a decrease in accrued commissions, as well as timing of payroll and ESPP purchases, (ii) an increase in accounts receivable and unbilled receivables of $7.3 million primarily due to an increase in billings, (iii) an increase in inventories of $2.9 million due to inventory buildup in support of forecasted sales, (iv) a decrease in operating lease liabilities of $2.7 million, and (v) an increase in investment in sales-type leases of $2.6 million. These cash outflows were partially offset by (i) an increase in deferred revenues of $8.0 million primarily due to timing of orders and revenues being recognized for installed product, (ii) a decrease in other long-term assets of $5.2 million, (iii) an increase in other long-term liabilities of $4.1 million, (iv) a decrease in prepaid expenses of $3.7 million, and (v) a decrease in prepaid commissions of $2.5 million.

[0000926326-20-000014:mdna:124]
[same as prior period, unchanged from 0000926326-19-000033:mdna:118]

[0000926326-20-000014:mdna:125]
Net cash used in investing activities was $13.8 million for the three months ended March 31, 2020, which consisted of capital expenditures of $3.2 million for property and equipment, and $10.6 million for costs of software development for external use.

[0000926326-20-000014:mdna:126]
Net cash used in investing activities was $16.7 million for the three months ended March 31, 2019, which consisted of capital expenditures of $5.0 million for property and equipment, and $11.7 million for costs of software development for external use.

[0000926326-20-000014:mdna:127]
[same as prior period, unchanged from 0000926326-19-000033:mdna:121]

[0000926326-20-000014:mdna:128]
Net cash used in financing activities was $33.8 million for the three months ended March 31, 2020, primarily due to the repayment of $50.0 million of the Current Revolving Credit Facility and $1.4 million in employees’ taxes paid related to restricted stock unit vesting, partially offset by $17.7 million in proceeds from employee stock option exercises and employee stock plan purchases.

[0000926326-20-000014:mdna:129]
Net cash used in financing activities was $0.2 million for the three months ended March 31, 2019, primarily due to the repayment of $39.0 million of the Prior Facilities and $1.9 million in employees’ taxes paid related to restricted stock unit vesting, partially offset by $20.5 million of proceeds from employee stock option exercises and employee stock plan purchases, and $20.2 million of proceeds from sales of our common stock under the Distribution Agreement.

[0000926326-20-000014:mdna:130]
[same as prior period, unchanged from 0000926326-19-000033:mdna:124]

[0000926326-20-000014:mdna:131]
There have been no significant changes during the three months ended March 31, 2020 to the contractual obligations disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations, set forth in Part II, Item 7, of our annual report on Form 10-K for the year ended December 31, 2019.

[0000926326-20-000014:mdna:132]
Contractual obligations as of March 31, 2020 were as follows:

[0000926326-20-000014:mdna:133]
|  | Payments due by period |  |  |  |  |  |  |  |  |
|  | Total |  | Remainder of 2020 |  | 2021 - 2022 |  | 2023 - 2024 |  | 2025 and thereafter |
|  | (In thousands) |  |  |  |  |  |  |  |  |
| Operating leases (1) | $ | 72,216 |  |  | $ | 10,076 |  |  | $ | 25,431 |  |  | $ | 16,609 |  |  | $ | 20,100 |  |
| Purchase obligations (2) | 91,668 |  |  | 90,196 |  |  | 821 |  |  | 608 |  |  | 43 |  |
| Total (3) | $ | 163,884 |  |  | $ | 100,272 |  |  | $ | 26,252 |  |  | $ | 17,217 |  |  | $ | 20,143 |  |

[0000926326-20-000014:mdna:134]
[same as prior period, unchanged from 0000926326-19-000033:mdna:128]

[0000926326-20-000014:mdna:135]
(1)Commitments under operating leases relate primarily to leased office buildings, data centers, office equipment, and vehicles. Refer to Note 10, Lessee Leases, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report.

[0000926326-20-000014:mdna:136]
(2)We purchase components from a variety of suppliers and use contract manufacturers to provide manufacturing services for our products. During the normal course of business, we issue purchase orders with estimates of our requirements several months ahead of the delivery dates. These amounts are associated with agreements that are enforceable and legally binding. The amounts under such contracts are included in the table above because we believe that cancellation of these contracts is unlikely and we expect to make future cash payments according to the contract terms or in similar amounts for similar materials.

[0000926326-20-000014:mdna:137]
(3)Refer to Note 11, Commitments and Contingencies, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report.

[0000926326-20-000014:mdna:138]
[same as prior period, unchanged from 0000926326-19-000033:mdna:134]

[0000926326-20-000014:mdna:139]
As of March 31, 2020, we had no off-balance sheet arrangements as defined under Regulation S-K 303(a)(4) of the Exchange Act and the instructions thereto.
