# OMCL MD&A — 0000926326-14-000005


## mdna

[0000926326-14-000005:mdna:1]
ITEM 7.    MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0000926326-14-000005:mdna:2]
The following discussion and analysis should be read in conjunction with our financial statements and related notes included elsewhere in this Annual Report on Form 10-K. This discussion may contain forward-looking statements based upon current expectations that involve risks and uncertainties. Our actual results and the timing of selected events could differ materially from those anticipated in these forward-looking statements as a result of several factors, including those set forth under Item 1A "Risk Factors" and elsewhere in this Annual Report on Form 10-K. Unless otherwise stated, references in this report to particular years or quarters refer to our fiscal year and the associated quarters of those fiscal years.

[0000926326-14-000005:mdna:3]
Overview

[0000926326-14-000005:mdna:4]
We are a leading provider of automated solutions for medication and supply management in healthcare. We believe our products improve healthcare for everyone, and it is our mission to continue improving healthcare with solutions that change the practice of healthcare in ways that improve patient and provider outcomes. Our automation and analytics solutions are designed to enable healthcare facilities to acquire, manage, dispense and administer medications and medical-surgical supplies and are intended to enhance patient safety, reduce medication errors, reduce operating costs, improve workflow and increase operational efficiency. We sell our medication control systems together with related consumables and services, and medical and surgical supply control systems. We generate approximately 89% of our product revenue in the United States and Canada. However, we expect our revenue from international operations to increase in future periods as we continue to grow our international business. We have not sold in the past, and have no future plans to sell our products either directly or indirectly to customers located in countries that are identified as state sponsors of terrorism by the U.S. Department of State, and are subject to economic sanctions and export controls.

[0000926326-14-000005:mdna:5]
We manage our business in two segments defined by customer type: products and services sold to hospital customers are designated as our Acute Care segment, and products and services sold outside the hospital setting are designated as our Non-Acute Care segment. Our Acute Care segment has been the predominant market for our products since the founding of the company in 1992 and today comprises approximately 75% of our overall business. The Non-Acute Care segment became a significant portion of our business in May 2012, when we completed our acquisition of MedPak Holdings, Inc. ("MedPak"). MedPak is the parent company of MTS Medication Technologies, Inc. ("MTS"), a worldwide provider of medication adherence packaging systems. The acquisition aligns us with the long-term trends of the healthcare market to manage the health of patients across the continuum of care. The combination of Omnicell and MTS brought capabilities to each other that strengthened the product lines and expanded the medication management coverage of both companies. In addition to MTS medication adherence packaging systems, we now also sell other products into non-acute care customers as a result of increased access to these customers through the acquisition. Please refer to Note 2, Business Acquisitions, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K for more information regarding the acquisition transaction and Note 17, Segments, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K for more information regarding the results for both the Acute Care and Non-Acute Care segments.

[0000926326-14-000005:mdna:6]
The healthcare market we sell to is experiencing a period of substantive change. The adoption of electronic healthcare records, new regulatory constraints, and changes in the reimbursement structure have caused healthcare institutions to re-examine their operating structures, re-prioritize their investments, and seek efficiencies. We believe our customers’ evolving operating environment creates challenges for any supplier, but also affords opportunities for suppliers that are able to partner with customers to help them meet the changing demands. We have invested in strategies which we believe have generated our revenue and earnings growth by directly supporting our customers’ initiatives. These strategies include:

[0000926326-14-000005:mdna:7]
| • | Development of differentiated products. We invest in the development of products that we believe bring patient safety and workflow efficiency to our customers’ operations that they cannot get from other competing solutions. These differentiators may be as small as how a transaction operates or information provided on a report or as large as the entire automation of a workflow that would otherwise be completed manually. We intend to continue our focus on differentiating our products, and we carefully assess our investments regularly as we strive to assure those investments provide the solutions most valuable to our customers. |

[0000926326-14-000005:mdna:8]
| • | Deliver our solutions to new markets. Areas of healthcare where work is done manually may benefit from our existing solutions. These areas include hospitals that continue to utilize manual operations, healthcare segments of the US market outside hospitals, and markets outside the US. We weigh the cost of entering these new markets against the expected benefits and focus on the markets that we believe are most likely to adopt our products. |

[0000926326-14-000005:mdna:9]
| • | Expansion of our solutions through acquisitions and partnerships. Our acquisitions have generally been focused on automation of manual workflows or data analytics, which is the enhancement of data for our customers’ decision- |

[0000926326-14-000005:mdna:10]
making processes. We believe that expansion of our product lines through acquisition and partnerships to meet our customers changing and evolving expectations is a key aspect to our historical and future success.

[0000926326-14-000005:mdna:11]
Since the sales cycle for many of our products can be as long as two years, and the installation cycle can be up to another year, the results of operations in 2013 were heavily influenced by our investment decisions that were made several years ago. We believe those investments are directly attributable to our revenue growth of 21% and our net income growth of 48% in 2013 as compared to 2012. Our investments have been consistent with the strategies outlined above.  To differentiate our solutions from others available in the market, we began shipping a refresh of our product line in 2011 which we market as G4. The G4 refresh included multiple new products and an upgrade product that allowed existing customers to augment their installations to obtain the most current technology that we provide. The G4 product refresh has been a key contributor to our growth, with 37.0% of our acute care installed base ordering upgrades to their existing systems since the announcement of G4. In addition to enhanced capabilities, we have focused on attaining the highest quality and service measurements for G4 in the industry, while marketing the solution to new and existing customers.  Our research and development efforts today are designed to bring new products to market beyond the G4 product line that we believe will meet customer needs in years to come.

[0000926326-14-000005:mdna:12]
Consistent with our strategy to enter new markets, we have made investments in our Sales, General, and Administrative expenses to expand our sales team and market to new customers. Our international efforts have focused primarily on three markets:  China, where we made a Mandarin version of our automated dispensing systems available in 2011, the Middle Eastern countries of the Arabian Peninsula where new healthcare facility construction is taking place, and in the United Kingdom where, in the third quarter of 2012, we purchased 15% of our United Kingdom distributor’s outstanding equity for approximately $0.9 million in cash to accelerate the adoption of medication and supply automation. In connection with the investment, we have the right, under certain circumstances, to appoint a member to this company's board of directors as well as certain other voting rights and, therefore, we believe we have the ability to exert significant influence over this distributor's operations. Our proportionate equity share of the income of this distributor recognized in our financial statements for the year ended December 31, 2013 was immaterial. We have also expanded our sales efforts to non-acute care customers in the United States which has allowed us to sell our automated dispensing solutions and other products to this market.

[0000926326-14-000005:mdna:13]
Expansion of our solutions through acquisitions and partnerships include our acquisition of MTS in 2012 and a recently announced, but not completed, potential acquisition of Surgichem Limited from Bupa Care Homes (CFG) Plc. Surgichem is a provider of medication adherence products in the United Kingdom. If completed, the combination of Surgichem with Omnicell is expected to enable both entities to sell their lines of proven multi- and single-dose products across a broader medication adherence packaging market in the United Kingdom. We have also developed relationships with major providers of hospital information management systems with the goal of enhancing the interoperability of our products with their systems. We believe that enhanced interoperability will help reduce implementation costs, time, and maintenance for shared clients, while providing new clinical workflows designed to enhance efficiency and patient safety.

[0000926326-14-000005:mdna:14]
We believe that the success of our three leg strategy of differentiated products, expansion into new markets, and acquisition and partnership in future periods will be based on, among other factors:

[0000926326-14-000005:mdna:15]
| • | Our expectation that the overall market demand for healthcare services will increase as the population grows, life expectancies continue to increase, the quality and availability of healthcare services increases; |

[0000926326-14-000005:mdna:16]
| • | Our expectation that the environment of increased patient safety awareness, increased regulatory control and increased need for workflow efficiency through the adoption of technology in the healthcare industry will make our solutions a priority in the capital budgets of healthcare facilities; and |

[0000926326-14-000005:mdna:17]
| • | Our belief that healthcare customers will continue to value a consultative customer experience from their suppliers. |

[0000926326-14-000005:mdna:18]
Among other financial measures, we utilize product bookings and product backlog to assess the current success of our strategies.  Product bookings consist of all firm orders, as evidenced by a contract and purchase order for equipment and software, and by a purchase order for consumables.  Equipment and software bookings are installable within 12 months and generally recorded as revenue upon customer acceptance of the installation. Consumables are recorded as revenue upon shipment to a customer or receipt by the customer, depending upon contract terms. Consumable bookings are generally recorded as revenue within one month. Product bookings increased 23%, from $266 million in 2012 to $328 million in 2013, driven in part by a full year of contribution from the acquisition of MTS and the success of our growth strategies in differentiated products and new markets. As a result of our bookings performance, our product backlog, consisting of orders accepted but not yet installed, increased $25 million, or 16.0%, to $180 million at December 31, 2013 from $155 million as of December 31, 2012. The increase in backlog is primarily attributable to our Acute Care segment.

[0000926326-14-000005:mdna:19]
In addition to product solution sales, we provide services to our customers.  Our healthcare customers expect a high degree of partnership involvement from their technology suppliers throughout their ownership of the products. We provide extensive installation planning and consulting as part of every product sale and included in the initial price of the solution. Our

[0000926326-14-000005:mdna:20]
customers' medication control systems are mission critical to their success and our customers require these systems to be functional at all times. To help assure the maximum availability of our systems, our customers typically purchase maintenance and support contracts in one, two or five year increments.  As a result of the growth of our installed base of customers, our service revenues have also grown. We strive to provide the best service possible, as measured by third party rating agencies and by our own surveys, to assure our customers continue to seek service maintenance from us. Our long-term liabilities include long-term deferred service revenue of $18 million as of December 31, 2013, and $20 million as of December 31, 2012. Our deferred service revenue will be amortized to service revenue as the service contracts are executed.

[0000926326-14-000005:mdna:21]
In the future, we expect our strategies to evolve as the business environment of our customers evolves, but for our focus to remain on improving healthcare with solutions that help change the practice of healthcare in ways that improve patient and provider outcomes.  We expect our investment in differentiated products, new markets, and acquisitions and partnerships to continue.  In 2014, we also intend to manage our business to operating profit margins similar to those achieved in 2013.  Our full time headcount of 1,134 on December 31, 2013, which is an increase of 45 from 2012, is dedicated to bringing our strategies to bear in all the markets we participate in.

[0000926326-14-000005:mdna:22]
Critical Accounting Policies and Estimates

[0000926326-14-000005:mdna:23]
Our discussion and analysis of our financial condition and results of operations are based on our consolidated financial statements, which have been prepared in accordance with United States generally accepted accounting principles, or GAAP. The preparation of these financial statements requires us to make certain estimates and assumptions that affect the reported amounts of assets and liabilities, disclosure of any contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. We regularly review our estimates and assumptions, which are based on historical experience and various other factors that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of certain assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates and assumptions. We believe the following critical accounting policies are affected by significant judgments and estimates used in the preparation of our consolidated financial statements:

[0000926326-14-000005:mdna:24]
Revenue recognition.  We earn revenues from sales of our medication and medical and surgical supply automation systems along with consumables and related services that are sold in the healthcare industry, our principal market. Revenues related to consumable products are reported net of discounts provided to our customers. Our customer arrangements typically include one or more of the following deliverables:

[0000926326-14-000005:mdna:25]
| • | Products—Software-enabled equipment that manages and regulates the storage and dispensing of pharmaceuticals, consumable blister cards and packaging equipment and other medical supplies. |

[0000926326-14-000005:mdna:26]
| • | Software—Additional software applications that enable incremental functionality of our equipment. |

[0000926326-14-000005:mdna:27]
| • | Installation—Installation of equipment as integrated systems at customers' sites. |

[0000926326-14-000005:mdna:28]
| • | Post-installation technical support—Phone support, on-site service, parts and access to unspecified software upgrades and enhancements, if and when available. |

[0000926326-14-000005:mdna:29]
| • | Professional services—Other customer services, such as training and consulting. |

[0000926326-14-000005:mdna:30]
We recognize revenue when the earnings process is complete, based upon our evaluation of whether the following four criteria have been met:

[0000926326-14-000005:mdna:31]
| • | Persuasive evidence of an arrangement exists. We use signed customer contracts and signed customer purchase orders as evidence of an arrangement for leases and sales. For service engagements, we use a signed services agreement and a statement of work to evidence an arrangement. |

[0000926326-14-000005:mdna:32]
| • | Delivery has occurred. Equipment and embedded software product delivery is deemed to occur upon successful installation and receipt of a signed and dated customer confirmation of installation letter, providing evidence that we have delivered what a customer ordered. In instances of a customer self-installation, product delivery is deemed to have occurred upon receipt of a signed and dated customer confirmation letter. If a sale does not require installation, we recognize revenue on delivery of products to the customer, including transfer of title and risk of loss, assuming all other revenue criteria are met. For existing distributors, where installation of equipment training has been previously provided and the distributor is certified to install our equipment at end user customer facility, we recognize revenue from sales of products to the distributor upon shipment assuming all other revenue criteria are met since we do not allow for rights of return or refund. For new distributors, where we have not provided installation of equipment training, revenue on the sales of products to the distributor is deferred until the distributor has completed the Distributor Training Program and has been certified to install our equipment at the |

[0000926326-14-000005:mdna:33]
end user facility. For the sale of consumable blister cards, we recognize revenue when title and risk of loss of the products shipped have transferred to the customer, which usually occurs upon shipment from our facilities. Assuming all other revenue criteria are met, we recognize revenue for support services ratably over the related support services contract period. We recognize revenue on training and professional services as they are performed.

[0000926326-14-000005:mdna:34]
| • | Fee is fixed or determinable. We assess whether a fee is fixed or determinable at the outset of the arrangement based on the payment terms associated with the transaction. We have established a history of collecting under the original contract without providing concessions on payments, products or services. |

[0000926326-14-000005:mdna:35]
| • | Collection is probable. We assess the probability of collecting from each customer at the outset of the arrangement based on a number of factors, including the customer's payment history and its current creditworthiness. If, in our judgment, collection of a fee is not probable, we defer the revenue until the uncertainty is removed, which generally means revenue is recognized upon our receipt of cash payment assuming all other revenue criteria are met. Our historical experience has been that collection from our customers is generally probable. |

[0000926326-14-000005:mdna:36]
In arrangements with multiple deliverables, assuming all other revenue criteria are met, we recognize revenue for individual delivered items if they have value to the customer on a standalone basis.We allocate arrangement consideration at the inception of the arrangement to all deliverables using the relative selling price method. This method requires us to determine the selling price at which each deliverable could be sold if it were sold regularly on a standalone basis. When available, we use vendor-specific objective evidence ("VSOE") of the selling price. VSOE represents the price charged for a deliverable when it is sold separately, or for a deliverable not yet being sold separately, the price established by management with the relevant authority. We consider VSOE to exist when approximately 80% or more of our standalone sales of an item are priced within a reasonably narrow pricing range (plus or minus 15% of the median rates). We have established VSOE of the selling price for our post-installation technical support services and professional services. When VSOE of selling price is not available, third-party evidence ("TPE") of selling price for similar products and services is acceptable; however, our offerings and market strategy differ from those of our competitors, such that we cannot obtain sufficient comparable information about third parties' prices. If neither VSOE nor TPE are available, we use our best estimates of selling prices ("BESP"). We determine BESP considering factors such as market conditions, sales channels, internal costs and product margin objectives and pricing practices. We regularly review and update our VSOE and BESP information.

[0000926326-14-000005:mdna:37]
The relative selling price method allocates total arrangement consideration proportionally to each deliverable (an "Element") on the basis of its estimated selling price. In addition, the amount recognized for any delivered Elements cannot exceed that which is contingent upon delivery of any remaining Elements in the arrangement.

[0000926326-14-000005:mdna:38]
We also use the residual method to allocate revenue between the software products that enable incremental equipment functionality, and thus are not deemed to deliver its essential functionality, and the related post-installation technical support, as these products and services continue to be accounted for under software revenue recognition rules. Under the residual method, the amount allocated to the undelivered elements equals VSOE of fair value of these elements. Any remaining amounts are attributed to the delivered items and are recognized when those items are delivered.

[0000926326-14-000005:mdna:39]
A portion of our sales are made through multi-year lease agreements. Under sales-type leases, we recognize revenue for our hardware and software products net of lease execution costs such as post-installation product maintenance and technical support, at the net present value of the lease payment stream once our installation obligations have been met. We optimize cash flows by selling a majority of our non-U.S. government leases to third-party leasing finance companies on a non-recourse basis. We have no obligation to the leasing company once the lease has been sold. Some of our sales-type leases, mostly those relating to U.S. government hospitals, are retained in-house. Interest income on these leases is recognized as a component of  product revenue using the interest method.

[0000926326-14-000005:mdna:40]
Accounts receivable and notes receivable (net investment in sales type leases). We actively manage our accounts receivable to minimize credit risk. We typically sell our products to customers for which there is a history of successful collection. New customers are subject to a credit review process, which evaluates that customer's financial position and ability to pay. We continually monitor and evaluate the collectability of our trade receivables based on a combination of factors. We record specific allowances for doubtful accounts when we become aware of a specific customer's impaired ability to meet its financial obligation to us, such as in the case of bankruptcy filings or deterioration of financial position.

[0000926326-14-000005:mdna:41]
Uncollectible amounts are charged off against trade receivables and the allowance for doubtful accounts when we make a final determination that there is no reasonable expectation of recovery. Estimates are used in determining our allowances for all other customers based on factors such as current trends, the length of time the receivables are past due and historical collection experience. While we believe that our allowance for doubtful accounts receivable is adequate and that the

[0000926326-14-000005:mdna:42]
judgment applied is appropriate, such estimated amounts could differ materially from what will actually be uncollectible in the future.

[0000926326-14-000005:mdna:43]
The retained in-house leases discussed above are considered financing receivables. Our credit policies and evaluation of credit risk and write-off policies are applied alike to trade receivables and the net-investment in sales-type leases. For both, an account is generally past due after thirty days. The financing receivables also have customer-specific reserves for accounts identified for specific impairment and a non-specific reserve applied to the remaining population, based on factors such as current trends, the length of time the receivables are past due and historical collection experience. The retained in-house leases are not stratified by portfolio or class. Financing receivables which are reserved are generally transferred to cash-basis accounting so that revenue is recognized only as cash is received. However, the cash basis accounts continue to accrue interest.

[0000926326-14-000005:mdna:44]
Valuation and impairment of goodwill, other intangible assets and other long lived assets. We account for goodwill and other intangible assets in accordance with ASC 350, Intangibles—Goodwill and Other ("ASC 350"). For the initial recognition and measurement of Goodwill and Intangibles resulting from acquisitions, we use the guidance in ASC 805, Business Combinations.

[0000926326-14-000005:mdna:45]
Under ASC 350, goodwill and intangible assets with an indefinite life are not subject to amortization but are tested for impairment at least annually or more frequently if indicators of impairment warrant. ASC 350 defines impairment as the condition that exists when the carrying amount of goodwill exceeds its implied fair value. The provisions of ASC 350 require that an entity assign its recorded goodwill to each of its reporting units and test each reporting unit's goodwill for impairment. We have determined that we have two reporting units: the Acute Care and the Non-Acute Care segments.

[0000926326-14-000005:mdna:46]
In accordance with ASC 350, we have the option, in any period, to first assess qualitative factors to determine whether it is more likely than not (that is, a likelihood of more than 50%) that the fair value of a reporting unit is less than its carrying amount, including goodwill, or bypass this qualitative assessment and proceed directly to performing the two-step goodwill impairment test. The first step ("step 1") involves comparing each reporting unit's estimated fair value to its carrying value, including goodwill, to identify potential impairment. If the estimated fair value of a reporting unit exceeds its carrying value, there is no indication of impairment and no further test is required. If the carrying value exceeds estimated fair value, there is an indication of potential impairment and the second step is required to be performed to measure the amount of impairment.

[0000926326-14-000005:mdna:47]
In the fourth quarter of 2013, we elected to perform step 1 to determine whether it is more likely than not that the fair values of our reporting units are less than their carrying amounts. While the ultimate responsibility rests with management, we engaged the services of an independent, third-party valuation specialist to assist in determining the fair values of our reporting units. We used a combination of a discounted cash flow model (“DCF”) which utilizes the present value of cash flows to estimate fair value (also known as the income approach) and comparisons to publicly traded companies’ market multiples (also known as the market approach).

[0000926326-14-000005:mdna:48]
Under the DCF model, the future cash flows for our reporting units were projected based on management’s projections, at that time, of future revenues, operating income and other factors such as working capital and capital expenditures. We also took into account market factors and industry conditions affecting our business. We used significant judgment to estimate the amount and timing of future cash flows from our reporting units and the relative risk of achieving those cash flows. Forecasts of future operations require management to make assumptions and are based, in part, on operating results and our expectations as to future market conditions. The discount rate used in our DCF model was based on a weighted-average cost of capital determined from relevant market comparisons and adjusted for specific reporting unit risks (primarily the risk of achieving projected operating cash flows). A terminal value growth rate was applied to the final year of the respective cash flows for both reporting units to arrive at estimates of fair value under the income approach. The estimated fair values of our reporting units determined under the income approach exceeded their carrying values.

[0000926326-14-000005:mdna:49]
We used the market approach to corroborate the values estimated under the income approach. Under the market approach, we estimated the fair values of our reporting units based on financial information on companies that we deemed were comparable to our business. We made judgments about the comparability of publicly traded companies engaged in similar businesses. We based our judgments on factors such as size, growth rates, profitability, and risk. Based on publicly available information, we calculated the comparable companies’ market multiples of earnings before interest, taxes, depreciation and amortization, and stock option expense and factored in a control premium. The estimated fair values of our reporting units determined under the market approach exceeded their carrying values.

[0000926326-14-000005:mdna:50]
Finally, we compared the estimated fair values of our reporting units to our September 30, 2013 total public market capitalization and assessed implied control premiums. Based on the aforementioned, we concluded that the estimated fair value determined for both our reporting units was reasonable. In each case, the estimated fair values of our reporting units exceeded their respective carrying values and, as such, we concluded that goodwill assigned to our Acute Care and Non-Acute Care segments was not impaired. In addition, we did not note any indications of goodwill impairment as of December 31, 2013.

[0000926326-14-000005:mdna:51]
In 2012, we opted to perform a qualitative assessment of factors to determine if goodwill had been impaired as of December 31, 2012. For both the Acute Care and Non-Acute Care segments, we considered the following qualitative factors:

[0000926326-14-000005:mdna:52]
| • | Macroeconomic conditions such as general economic conditions, limitations on accessing capital, fluctuations in foreign exchange rates or other developments in equity and credit markets; |

[0000926326-14-000005:mdna:53]
| • | Industry and market considerations such as changes in the environment in which we operate, an increased competitive environment, a decline in market-dependent multiples or metrics (consider in both absolute terms and relative to peers), a change in the market for our products or services, or a regulatory or political development; |

[0000926326-14-000005:mdna:54]
| • | Cost factors such as increases in raw materials, labor, or other costs that have a negative effect on earnings and cash flows; |

[0000926326-14-000005:mdna:55]
| • | Overall financial performance such as negative or declining cash flows or a decline in actual or planned revenue or earnings compared with actual and projected results of relevant prior periods; |

[0000926326-14-000005:mdna:56]
| • | Other relevant entity-specific events such as changes in management, key personnel, strategy, or customers; contemplation of bankruptcy or litigation; and |

[0000926326-14-000005:mdna:57]
| • | Events affecting a reporting unit such as a change in the composition or carrying amount of its net assets, a more-likely-than-not expectation of selling or disposing all, or a portion, of a reporting unit, the testing for recoverability of a significant asset group within a reporting unit or recognition of a goodwill impairment loss in the financial statements of a subsidiary that is a component of a reporting unit. |

[0000926326-14-000005:mdna:58]
Upon completion of our qualitative assessment conducted in the fourth quarter of 2012, we concluded that it was more likely than not that the fair values of both the Acute Care and Non-Acute Care segments exceeded their carrying values including the respective amounts of goodwill. In addition, management did not note any other indicators of goodwill impairment as of December 31, 2012.

[0000926326-14-000005:mdna:59]
We continually monitor events and changes in circumstances that could indicate carrying amounts of long-lived assets may not be recoverable. We review long-lived assets and certain purchased intangibles for impairment whenever events or changes in circumstances indicate that we will not be able to recover the asset's carrying amount. Recoverability of an asset is measured by comparing its carrying amount to the expected future undiscounted cash flows expected to result from the use and eventual disposition of that asset, excluding future interest costs that would be recognized as an expense when incurred. Any impairment to be recognized is measured by the amount by which the carrying amount of the asset exceeds its fair market value. Significant management judgment is required in:

[0000926326-14-000005:mdna:60]
| • | identifying a triggering event that arises from a change in circumstances; |

[0000926326-14-000005:mdna:61]
| • | forecasting future operating results; and |

[0000926326-14-000005:mdna:62]
| • | estimating the proceeds from the disposition of long-lived or intangible assets. |

[0000926326-14-000005:mdna:63]
In future periods, material impairment charges could be necessary should different conditions prevail or different judgments be made.

[0000926326-14-000005:mdna:64]
Significant management judgment is also required for initial recognition and measurement of goodwill and other intangibles assets resulting from business combinations pursuant ASC 805, Business Combinations. Management must assess the extent to which identified other intangibles assets are properly includable (and with the appropriate fair value) or properly excludable, by applying the recognition criteria. This judgment affects not only the other intangible assets but the remainder calculation of goodwill. The assessment of useful life for each acquired intangible asset impacts future financial position and operating performance through amortization expense.

[0000926326-14-000005:mdna:65]
Inventory.    Inventories are stated at the lower of cost (utilizing standard costs), applying the first-in, first-out method, or market. We routinely assess our on-hand inventory for timely identification and measurement of obsolete, slow-moving or otherwise impaired inventory. We write down inventory for estimated obsolescence, excess or unmarketable quantities equal to the difference between the cost of the inventory and its estimated market value based on assumptions about future demand and market conditions. If actual future demand or market conditions are less favorable than we projected, additional inventory write-downs may be required.

[0000926326-14-000005:mdna:66]
Valuation of share-based awards.    We account for share-based compensation in accordance with ASC 718, Stock Compensation. We estimate the fair value of our employee stock awards at the date of grant using certain subjective assumptions, such as expected volatility, which is based on a combination of historical and market-based implied volatility, and the expected term of the awards, which is based on our historical experience of employee stock option exercises, including

[0000926326-14-000005:mdna:67]
forfeitures. The valuation assumptions we use in estimating the fair value of employee share-based awards may change in future periods. We recognize the fair value of awards over their vesting period or requisite service period. In addition, we calculate our pool of excess tax benefits available within additional paid-in capital in accordance with the provisions of ASC 718.

[0000926326-14-000005:mdna:68]
Accounting for income taxes.    We record an income tax provision for the anticipated tax consequences of the reported results of operations. In accordance with GAAP, the provision for income taxes is computed using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been included in the financial statements. Under this method, deferred tax assets and liabilities are determined on the basis of the differences between the financial statement and tax bases of assets and liabilities, and for operating losses and tax credit carry forwards. Deferred tax assets and liabilities are measured using the enacted tax rates in effect for the periods in which those tax assets and liabilities are expected to be realized or settled. In the event that these tax rates change, we will incur a benefit or detriment on our income tax expense in the period of change. If we were to determine that all or part of the net deferred tax assets are not realizable in the future, we will record a valuation allowance that would be charged to earnings in the period such determination is made.

[0000926326-14-000005:mdna:69]
In accordance with ASC 740, Income Taxes, we recognize the tax benefit from an uncertain tax position if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement. The calculation of tax liabilities involves significant judgment in estimating the impact of uncertainties in the application of GAAP and complex tax laws. Resolution of these uncertainties in a manner inconsistent with management's expectations could have a material impact on our financial condition and operating results.

[0000926326-14-000005:mdna:70]
Recently Adopted Accounting Standards

[0000926326-14-000005:mdna:71]
In February 2013, the FASB issued ASU 2013-02, Comprehensive Income (Topic 220): Reporting of Amounts Reclassified Out of Accumulated Other Comprehensive Income ("AOCI"), which aims to improve the reporting of reclassifications out of AOCI. This update requires an entity to report the effect of significant reclassifications out of AOCI on the respective line items in net income if the amount being reclassified is required under GAAP to be reclassified in its entirety to net income. For other amounts that are not required under GAAP to be reclassified in their entirety to net income in the same reporting period, an entity is required to cross-reference other disclosures required under GAAP that provide additional detail about those amounts.  The amendments do not change the current requirements for reporting net income or other comprehensive income in financial statements. We adopted this guidance in the first quarter of 2013, without any impact to our financial position, operating results or cash flows.

[0000926326-14-000005:mdna:72]
Recently Issued Accounting Standards

[0000926326-14-000005:mdna:73]
In July 2013, the FASB issued ASU 2013-11,  Income Taxes (Topic 740): Presentation of an Unrecognized Tax Benefit When a Net Operating Loss Carryforward, a Similar Tax Loss, or a Tax Credit Carryforward Exists. ASU 2013-11 requires an entity to present an unrecognized tax benefit, or a portion of an unrecognized tax benefit, as a reduction to a deferred tax asset for a net operating loss carryforward, a similar tax loss, or a tax credit carryforward, except as follows: to the extent a net operating loss carryforward, a similar tax loss, or a tax credit carryforward is not available at the reporting date under the tax law of the applicable jurisdiction to settle any additional income taxes that would result from the disallowance of a tax position or the tax law of the applicable jurisdiction does not require the entity to use, and the entity does not intend to use, the deferred tax asset for such purpose, the unrecognized tax benefit should be presented in the financial statements as a liability and should not be combined with deferred tax assets. We will adopt the amendments in ASU 2013-11 in the first quarter of 2014, and do not expect the adoption to have a material impact on our financial position, operating results or cash flows.

[0000926326-14-000005:mdna:74]
Results of Operations

[0000926326-14-000005:mdna:75]
|  | Years Ended December 31, |
|  | 2013 |  | % of Revenue |  | 2012 |  | % of Revenue |  | 2011 |  | % of Revenue |
|  | (in thousands, except percentages) |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |
| Product revenues | $ | 307,189 |  |  | 80.7 | % |  | $ | 247,654 |  |  | 78.9 | % |  | $ | 185,864 |  |  | 75.7 | % |
| Service and other revenues | 73,396 |  |  | 19.3 | % |  | 66,373 |  |  | 21.1 | % |  | 59,671 |  |  | 24.3 | % |
| Total revenues | 380,585 |  |  | 100.0 | % |  | 314,027 |  |  | 100.0 | % |  | 245,535 |  |  | 100.0 | % |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product revenues | 144,997 |  |  | 38.1 | % |  | 112,369 |  |  | 35.8 | % |  | 79,567 |  |  | 32.4 | % |
| Cost of service and other revenues | 32,189 |  |  | 8.5 | % |  | 31,070 |  |  | 9.9 | % |  | 30,184 |  |  | 12.3 | % |
| Total cost of revenues | 177,186 |  |  | 46.6 | % |  | 143,439 |  |  | 45.7 | % |  | 109,751 |  |  | 44.7 | % |
| Gross profit | 203,399 |  |  | 53.4 | % |  | 170,588 |  |  | 54.3 | % |  | 135,784 |  |  | 55.3 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 29,105 |  |  | 7.6 | % |  | 23,726 |  |  | 7.6 | % |  | 22,042 |  |  | 9.0 | % |
| Selling, general and administrative | 138,995 |  |  | 36.5 | % |  | 119,736 |  |  | 38.1 | % |  | 97,520 |  |  | 39.7 | % |
| Income from operations | 35,299 |  |  | 9.3 | % |  | 27,126 |  |  | 8.6 | % |  | 16,222 |  |  | 6.6 | % |
| Interest and other income (expense), net | (270 | ) |  | (0.1 | )% |  | (51 | ) |  | — | % |  | (133 | ) |  | (0.1 | )% |
| Income before provision for income taxes | 35,029 |  |  | 9.2 | % |  | 27,075 |  |  | 8.6 | % |  | 16,089 |  |  | 6.6 | % |
| Provision for income taxes | 11,050 |  |  | 2.9 | % |  | 10,897 |  |  | 3.5 | % |  | 5,700 |  |  | 2.3 | % |
| Net income | $ | 23,979 |  |  | 6.3 | % |  | $ | 16,178 |  |  | 5.2 | % |  | $ | 10,389 |  |  | 4.2 | % |

[0000926326-14-000005:mdna:76]
The consolidated operating results presented above include the operating results of MTS since May 21, 2012, the date of acquisition, and are included as part of the Non-Acute Care segment.

[0000926326-14-000005:mdna:77]
Product Revenues, Cost of Product Revenues and Gross Profit

[0000926326-14-000005:mdna:78]
The table below shows our product revenues, cost of product revenues and gross profit for the years ended December 31, 2013, 2012 and 2011 and the change between those years (in thousands, except percentages):

[0000926326-14-000005:mdna:79]
|  | Years Ended December 31, |  | 2013 to 2012 |  | 2012 to 2011 |
|  | Change in |  | Change in |
|  | 2013 |  | 2012 |  | 2011 |  | $ |  | % |  | $ |  | % |
| Product revenues | $ | 307,189 |  |  | $ | 247,654 |  |  | $ | 185,864 |  |  | $ | 59.5 |  |  | 24.0 | % |  | $ | 61.8 |  |  | 33.2 | % |
| Cost of product revenues | 144,997 |  |  | 112,369 |  |  | 79,567 |  |  | 32.6 |  |  | 29.0 | % |  | 32.8 |  |  | 41.2 | % |
| Gross profit | $ | 162,192 |  |  | $ | 135,285 |  |  | $ | 106,297 |  |  | $ | 26.9 |  |  | 19.9 | % |  | $ | 29.0 |  |  | 27.3 | % |

[0000926326-14-000005:mdna:80]
2013 compared to 2012

[0000926326-14-000005:mdna:81]
Product revenues.   The overall increase in product revenues was primarily driven by a full twelve month contribution of MTS activities as a part of our Non-Acute Care segment, which contributed $91.0 million during the period. This compared

[0000926326-14-000005:mdna:82]
to $50.3 million in the same twelve month period in 2012 in which we owned MTS only after May 21, 2012. Our Acute Care segment contributed $216.2 million in product revenues in 2013 compared to $197.4 million in 2012. The growth in our Acute-Care segment was driven by increased customer receptivity to our products due to product differentiation and entrance into new markets.

[0000926326-14-000005:mdna:83]
We anticipate our revenues will continue to increase in 2014 compared to the same periods in 2013, as we fulfill our existing orders. Our ability to continue to grow revenue is dependent on our ability to continue to obtain orders from customers, our ability to produce quality consumables to fulfill customer demand, the volume of installations we are able to complete and our ability to meet customer needs by providing a quality installation experience and our flexibility in manpower allocations among customers to complete installations on a timely basis. The timing of our product revenues for equipment is primarily dependent on when our customers’ schedules allow for installations.

[0000926326-14-000005:mdna:84]
Cost of product revenues.   The increase in cost of product revenues was primarily a result of a full year of Non-Acute Care product costs of $52.0 million as compared to $30.6 million in the same period a year ago. Our Acute Care product cost increased by $11.2 million primarily driven by increased revenues and unfavorable changes in product mix.

[0000926326-14-000005:mdna:85]
Gross profit.   The increase in gross profit on product revenue was primarily a result of the contribution from our Non-Acute Care segment described above, as well as increased gross profits in our Acute Care segment, driven primarily by increased customer installations as a result of increased customer acceptance of our product differentiation . Gross profit as a percentage of product revenues decreased to 52.8% in 2013 as compared to 54.6% in 2012. The decrease in gross profit as a percentage of product revenue was primarily due to the increased mix of Non-Acute Care segment, which carries a lower gross profit as a percentage of revenue, for the entire year of 2013 versus a portion of 2012.

[0000926326-14-000005:mdna:86]
For 2014, we do not anticipate any significant fluctuations in our gross profit and gross profit as a percentage of revenue beyond normal fluctuations caused by changes in product mix.

[0000926326-14-000005:mdna:87]
2012 compared to 2011

[0000926326-14-000005:mdna:88]
Product revenues.   The overall increase in product revenues was driven by revenue derived from MTS subsequent to its acquisition by Omnicell during the second quarter of 2012 and by the increased installations of automation products, including customer product upgrades using our G4 platform.

[0000926326-14-000005:mdna:89]
Cost of product revenues.   The increase in cost of product revenues was primarily a result of Non-Acute Care product costs of $30.6 million, which included $1.7 million of acquisition-related charges primarily associated with the step-up to the estimated fair value of inventory acquired from MTS and consumed in the normal manufacturing cycle of our business. The increase in Acute Care product revenue and favorable change in product mix resulted in a modest increase of $2.2 million in costs.

[0000926326-14-000005:mdna:90]
Gross profit.   The increase in gross profit on product revenue was primarily a result of the contribution from our Non-Acute Care segment described above, as well as increased gross profits in our Acute Care segment, which was driven by revenue growth and by favorable product mix. In addition, gross profit as a percentage of product revenues decreased to 54.6% in 2012 as compared to 57.2% in 2011. The decrease in gross profit as a percentage of product revenue was due to the addition of lower Non-Acute Care segment gross profit as a percent of revenue following the acquisition of MTS, which drove the overall gross profit as a percentage of revenue down. The Non-Acute Care segment information was immaterial in the periods ended December 31, 2011 and, accordingly, has not been discussed separately.

[0000926326-14-000005:mdna:91]
Service and Other Revenues, Cost of Service and Other Revenues and Gross Profit

[0000926326-14-000005:mdna:92]
Service and other revenues include revenues from service and maintenance contracts and rentals of automation systems. The table below shows our service and other revenues, cost of service and other revenues and gross profit for the years ended December 31, 2013, 2012 and 2011 and the change between those years (in thousands, except percentages):

[0000926326-14-000005:mdna:93]
|  | Years Ended December 31, |  | 2013 to 2012 |  | 2012 to 2011 |
|  | Change in |  | Change in |
|  | 2013 |  | 2012 |  | 2011 |  | $ |  | % |  | $ |  | % |
| Service and other revenues | $ | 73,396 |  |  | $ | 66,373 |  |  | $ | 59,671 |  |  | $ | 7.0 |  |  | 10.6 | % |  | $ | 6.7 |  |  | 11.2 | % |
| Cost of service and other revenues | 32,189 |  |  | 31,070 |  |  | 30,184 |  |  | 1.1 |  |  | 3.6 | % |  | 0.9 |  |  | 2.9 | % |
| Gross profit | $ | 41,207 |  |  | $ | 35,303 |  |  | $ | 29,487 |  |  | $ | 5.9 |  |  | 16.7 | % |  | $ | 5.8 |  |  | 19.7 | % |

[0000926326-14-000005:mdna:94]
2013 compared to 2012

[0000926326-14-000005:mdna:95]
Service and other revenues.   The increase in service and other revenues was primarily the result of an expansion in our installed base of automation systems and a resulting increase in the number of support service contracts, as well as a $1.3 million increase attributable to the Non-Acute segment. Our Non-Acute Care segment contributed $4.9 million to services and other revenues in 2013 compared to $3.6 million in 2012 driven by services for MTS branded products after the acquisition of MTS in 2012. Our Acute Care segment contributed $68.5 million in service and other revenues in 2013 compared to $62.8 million in 2012.

[0000926326-14-000005:mdna:96]
Cost of service and other revenues.   The increase in cost of service and other revenues was primarily a result of the aforementioned addition of our Non-Acute Care segment of $2.3 million, which increased $1.1 million due to twelve full months of costs. The Acute Care segment service costs stayed flat as compared to 2012.

[0000926326-14-000005:mdna:97]
Gross profit.   The increase in gross profit and gross margin percentage on service and other revenues was due to increased revenues from an expanded installed base attributable to our Acute Care segment with nominal growth in service costs as a result of service cost reduction efforts throughout 2013.

[0000926326-14-000005:mdna:98]
We expect our service and other revenues and the associated costs to continue to increase in 2014 with the continued expansion of our installed base of automation systems and service and maintenance contracts.

[0000926326-14-000005:mdna:99]
2012 compared to 2011

[0000926326-14-000005:mdna:100]
Service and other revenues.   The increase in service and other revenues was primarily the result of an expansion in our installed base of automation systems and a resulting increase in the number of support service contracts and, in addition, a $1.9 million increase attributable to the Non-Acute segment.

[0000926326-14-000005:mdna:101]
Cost of service and other revenues.   The increase in cost of service and other revenues were primarily a result of the aforementioned addition of our Non-Acute Care segment of $1.2 million, offset by a $0.3 million decrease in the Acute Care segment service costs due to lower costs incurred related to advance replacement of material covered under maintenance contracts.

[0000926326-14-000005:mdna:102]
Gross profit.   The increase in gross profit on service and other revenues was due to increased revenues from an expanded installed base attributable to our Acute Care segment with nominal growth in service costs as a result of service cost reduction efforts throughout 2012.

[0000926326-14-000005:mdna:103]
The Non-Acute Care segment information was immaterial in the periods ended December 31, 2011 and, accordingly, has not been discussed separately.

[0000926326-14-000005:mdna:104]
Operating Expenses

[0000926326-14-000005:mdna:105]
The table below shows our operating expenses for the years ended December 31, 2013, 2012 and 2011 and the change between those years (in thousands, except percentages):

[0000926326-14-000005:mdna:106]
|  | Years Ended December 31, |  | 2013 to 2012 |  | 2012 to 2011 |
|  | Change in |  | Change in |
|  | 2013 |  | 2012 |  | 2011 |  | $ |  | % |  | $ |  | % |
| Research and development | $ | 29,105 |  |  | $ | 23,726 |  |  | $ | 22,042 |  |  | $ | 5.4 |  |  | 22.7 | % |  | $ | 1.7 |  |  | 7.6 | % |
| Selling, general and administrative | 138,995 |  |  | 119,736 |  |  | 97,520 |  |  | 19.3 |  |  | 16.1 | % |  | 22.2 |  |  | 22.8 | % |
| Total operating expenses | $ | 168,100 |  |  | $ | 143,462 |  |  | $ | 119,562 |  |  | $ | 24.6 |  |  | 17.2 | % |  | $ | 23.9 |  |  | 20.0 | % |

[0000926326-14-000005:mdna:107]
2013 compared to 2012

[0000926326-14-000005:mdna:108]
Research and development.    Research and development expenses represented 7.6% of total revenues for both years 2013 and 2012. The overall increase in research and development expense reflects an increase of $6.0 million mainly attributable to the Non-Acute Care segment and includes a $1.8 million write-off of previously capitalized software development costs, discussed further in Note 18, "Asset Impairment" of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K, a $0.3 million charge related to a management reorganization within the Non-Acute Care segment in the first quarter of 2013, and the inclusion of MTS headcount, consulting and other related activities for a full twelve months in the 2013 period as compared with the prior period. Research and development expenses attributable to the Acute Care segment were relatively flat as compared with the year-ago period.

[0000926326-14-000005:mdna:109]
We expect research and development expenses to increase in 2014 as we continue to invest in new products and services, but stay relatively flat as a percentage of revenues. The amount of research and development expenses can fluctuate based on the amount of prototype expenses for hardware and/or the amount of capitalized software development costs in any given quarter.

[0000926326-14-000005:mdna:110]
Selling, general and administrative.    Selling, general and administrative expenses represented 36.5% and 38.1% of total revenues in 2013 and 2012, respectively. The increase in selling, general and administrative expenses was primarily due to an increase in the Non-Acute Care selling, general and administrative expenses of $14.3 million representing the overall expenses incurred due to the inclusion of MTS activities for a full twelve months in 2013 as compared with 2012. 2013 also includes higher expenses associated with medication dispensing cabinet sales to Non-Acute Care customers. The Acute Care segment increase of $5.0 million was primarily due to $5.0 million in headcount-related expenses including higher commissions as a result of higher revenues, $2.9 million in facility and depreciation expenses for our new corporate headquarters and manufacturing buildings occupied in late 2012, $1.8 million increase in consulting and professional fees, $0.6 million in travel, entertainment, promotional, office and trade show related expenses, $0.4 million in GPO fees associated with higher collections and sales volume for GPO-affiliated customers, partially offset by a decrease of $2.3 million of costs associated with the acquisition of MTS in 2012 that did not repeat in 2013 and a decrease of $3.7 million in allocations due to higher corporate allocation to the Non-Acute segment noted above.

[0000926326-14-000005:mdna:111]
We anticipate selling, general and administrative expenses as a percent of revenues to be stable for the full year of 2014, but this estimate could be impacted by ongoing business development activities and external, macro-economic factors.

[0000926326-14-000005:mdna:112]
2012 compared to 2011

[0000926326-14-000005:mdna:113]
Research and development.    Research and development expenses represented 7.6% and 9.0% of total revenues in 2012 and 2011, respectively.

[0000926326-14-000005:mdna:114]
The overall increase in research and development expenses was due to an increase of $1.8 million attributable to the Non-Acute Care segment since the acquisition of MTS in the second quarter of 2012, partially offset by an overall decrease of $0.1 million attributable to the Acute Care segment.

[0000926326-14-000005:mdna:115]
Selling, general and administrative.    Selling, general and administrative expenses represented 38.1% and 39.7% of total revenues in 2012 and 2011, respectively.

[0000926326-14-000005:mdna:116]
This increase in selling, general and administrative expenses was primarily due to the addition of Non-Acute Care selling, general and administrative expenses of $13.2 million since the acquisition of MTS in the second quarter of 2012. Increases in Acute Care segment selling, general and administrative expenses were primarily due to a $7.5 million increase in costs associated with compensation and related benefits, $2.3 million in transaction and integration expenses related to the acquisition of MTS, $1.6 million in facility expenses due the relocation to our new buildings late in 2012 and an increase of $1.2 million in bad debt expense primarily related to a $0.6 million recovery in 2011 as compared to a $0.6 million expense in 2012. These increases were partially offset by a $1.4 million decrease in third party consulting expenses and a $1.0 million decrease in legal expenses primarily related to the settlement of litigation in 2011.

[0000926326-14-000005:mdna:117]
The Non-Acute Care segment information was immaterial in the periods ended December 31, 2011 and, accordingly, has not been discussed separately.

[0000926326-14-000005:mdna:118]
Interest and other income (expense), net

[0000926326-14-000005:mdna:119]
The table below shows our interest income and other expense for the years ended December 31, 2013, 2012 and 2011 and the change between those years (in thousands, except percentages):

[0000926326-14-000005:mdna:120]
|  | Years Ended December 31, |  | 2013 to 2012 |  | 2012 to 2011 |
|  | Change in |  | Change in |
|  | 2013 |  | 2012 |  | 2011 |  | $ |  | % |  | $ |  | % |
| Interest income | $ | 30 |  |  | $ | 77 |  |  | $ | 266 |  |  | $ | (47.0 | ) |  | (61.0 | )% |  | $ | (189.0 | ) |  | (71.1 | )% |
| Interest expense | (122 | ) |  | (29 | ) |  | (62 | ) |  | 93.0 |  |  | 320.7 | % |  | 33.0 |  |  | (53.2 | )% |
| Other income (expense) | (178 | ) |  | (99 | ) |  | (337 | ) |  | 79.0 |  |  | 79.8 | % |  | (238.0 | ) |  | (70.6 | )% |
| Interest and other income (expense), net | $ | (270 | ) |  | $ | (51 | ) |  | $ | (133 | ) |  | $ | 219.0 |  |  | 429.4 | % |  | $ | 82.0 |  |  | (61.7 | )% |

[0000926326-14-000005:mdna:121]
2013 compared to 2012

[0000926326-14-000005:mdna:122]
Other income (expense) increased in 2013 primarily due to unfavorable effects of exchange rate fluctuations in 2013 between the Canadian and U.S. dollar as compared to a lesser impact in 2012.

[0000926326-14-000005:mdna:123]
2012 compared to 2011

[0000926326-14-000005:mdna:124]
Cash, cash equivalents and short-term investments decreased by $137.6 million during 2012, primarily due to our acquisition of MTS. This and the continued reduction in interest rates resulted in a 71.1% decline in interest income earned compared to 2011.

[0000926326-14-000005:mdna:125]
Other income (expense) decreased in 2012 primarily due to unfavorable effects of exchange rate in 2011 between Indian rupees and U.S. dollars as compared to an immaterial impact in 2012.

[0000926326-14-000005:mdna:126]
Income Taxes

[0000926326-14-000005:mdna:127]
The table below shows the provision for income taxes for the years ended December 31, 2013, 2012 and 2011 and the changes between those years (in thousands, except percentages).

[0000926326-14-000005:mdna:128]
|  | Years Ended December 31, |  | 2013 to 2012 |  | 2012 to 2011 |
|  |  | Change in |  | Change in |
|  | 2013 |  | 2012 |  | 2011 |  | $ |  | % |  | $ |  | % |
| Provision for income taxes | $ | 11,050 |  |  | $ | 10,897 |  |  | $ | 5,700 |  |  | $ | 153 |  |  | 1.4 | % |  | $ | 5,197 |  |  | 91.2 | % |

[0000926326-14-000005:mdna:129]
We recorded a provision for income taxes of approximately $11.1 million and an effective tax rate of 31.6% for the year ended December 31, 2013 compared to $10.9 million and an effective tax rate of 40.3% for the year ended December 31, 2012. The 2013 annual tax rate differed from the statutory tax rate of 35% primarily due to the favorable impact of the Section 199 domestic production activity deduction, as well as the reinstatement of the federal research credit in January 2013, retroactive to 2012. The decrease in the annual effective tax rate as compared to 2012 was primarily due to the aforementioned reinstatement of the federal research credit, a favorable mix in our domestic sales which decreased state apportionment factors in certain states, and the absence of non-deductible acquisition costs in 2013 that were incurred in 2012 as a result of the MTS acquisition.

[0000926326-14-000005:mdna:130]
We recorded a provision for income taxes of approximately $10.9 million and an effective tax rate of 40.3% for the year ended December 31, 2012 compared to $5.7 million and an effective tax rate of 35.4% for the year ended December 31, 2011. The increase in the annual effective tax rate as compared to 2011 was primarily due to the expiration of the federal research and development credit after 2011 and non-deductible acquisition costs and equity charges, partially offset by an increase in the domestic production activity deduction.

[0000926326-14-000005:mdna:131]
Refer to Note 14, Income Taxes, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K for a discussion of factors affecting our ability to realize deferred tax assets.

[0000926326-14-000005:mdna:132]
Liquidity and Capital Resources

[0000926326-14-000005:mdna:133]
Cash Flows

[0000926326-14-000005:mdna:134]
The table below shows our cash flows for the years ended December 31, 2013, 2012 and 2011:

[0000926326-14-000005:mdna:135]
|  | Years Ended December 31, |
|  | 2013 |  | 2012 |  | 2011 |
|  | (in thousands) |
| Net cash provided by operating activities | $ | 55,263 |  |  | $ | 39,484 |  |  | $ | 31,243 |  |
| Net cash used in investing activities | (20,452 | ) |  | (168,711 | ) |  | (13,066 | ) |
| Net cash provided by (used in) financing activities | 7,374 |  |  | (232 | ) |  | (1,840 | ) |
| Effect of exchange rate changes on cash and cash equivalents | 33 |  |  | 10 |  |  | (210 | ) |
| Net increase (decrease) in cash and cash equivalents | $ | 42,218 |  |  | $ | (129,449 | ) |  | $ | 16,127 |  |

[0000926326-14-000005:mdna:136]
2013 compared to 2012

[0000926326-14-000005:mdna:137]
Net cash provided by operating activities.    Net cash provided by operating activities increased by $15.8 million in 2013 as compared to 2012. The major drivers increasing operating cash flow were an increase of $7.8 million in net income, a decrease of $5.9 million in sales-type leases, a decrease of $5.7 million in accounts receivable as a result of collection efforts, an increase of $5.0 million in non-cash expenses for depreciation and amortization primarily due to our new corporate headquarters and manufacturing site, and a decrease of $4.5 million in other assets. Partially offsetting these increases in sources of operating cash flows were an increase of $7.9 million in inventories, and a decrease of $7.4 million in deferred gross profit.

[0000926326-14-000005:mdna:138]
Net cash used in investing activities.    Net cash used in investing activities decreased by $148.3 million in 2013 as compared to 2012, primarily due to a decrease in acquisition activity in 2013.

[0000926326-14-000005:mdna:139]
Net cash provided by financing activities.    Net cash provided by financing activities represented an increase in cash of  $7.6 million in 2013 as compared to 2012. The increase was primarily driven by an increase of $15.7 million in cash provided from shares issued under employee stock option exercises and stock purchase plans which was partially offset by an increase of $8.6 million cash used in stock repurchases.

[0000926326-14-000005:mdna:140]
2012 compared to 2011

[0000926326-14-000005:mdna:141]
Net cash provided by operating activities.    Net cash provided by operating activities increased by $8.2 million in 2012 to $39.5 million from $31.2 million in 2011. The major drivers increasing operating cash flow were $5.8 million higher net income and a reduction of inventory of $12.0 million, as well as increases in accrued compensation of $4.7 million, deferred gross profit of $4.1 million and accounts payable of $4.0 million, between 2012 and 2011. Partially offsetting these increases in sources of operating cash flows were a net increase of $6.4 million in prepaid expenses and the increase of $5.2 million in sales type leases.

[0000926326-14-000005:mdna:142]
Net cash used in investing activities.    Net cash used in investing activities increased by $155.6 million in 2012 to $168.7 million from $13.1 million in 2011. This increase was primarily driven by $158.3 million of cash paid to complete the 2012 acquisition of MTS in the second quarter of 2012.

[0000926326-14-000005:mdna:143]
Net cash used in financing activities.    Net cash used in financing activities decreased by $1.6 million in 2012 to $0.2 million net cash used compared to net cash used by financing activities of $1.8 million in 2011. Stock repurchases decreased by $0.2 million to $12.4 million in 2012 from $12.6 million in 2011. In 2012 cash generated from shares issued under stock option and employee stock purchase plans increased by $2.2 million to $8.9 million from $6.8 million in 2011, offset by a decrease of $0.7 million in excess tax benefits from employee stock plans to $3.2 million in 2012 from $3.9 million in 2011.

[0000926326-14-000005:mdna:144]
Liquidity

[0000926326-14-000005:mdna:145]
Our future uses of cash are expected to be primarily for working capital, capital expenditures and other contractual obligations. We also expect a continued use of cash for potential acquisition and acquisition assessment activities.

[0000926326-14-000005:mdna:146]
As described in Note 15, Stockholders' Equity, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K, on December 31, 2013, we had $29.0 million of remaining authorized funds to repurchase shares of our common stock under our stock repurchase program, which may, in the future, result in additional use of cash. We had cash and cash equivalents of $104.5 million at December 31, 2013 as compared to $62.3 million at December 31, 2012. As of December 31, 2013 and 2012, we had no short-term investments.

[0000926326-14-000005:mdna:147]
In September 2013, we entered into a Credit Agreement with Wells Fargo Bank, National Association, as administrative agent, and the lenders from time to time which provides for a $75.0 million revolving credit facility to be used for general corporate purposes, including future acquisitions. The Credit Agreement permits us to request one or more increases in the aggregate commitment provided such increases do not exceed $25.0 million in the aggregate. The Credit Agreement contains customary affirmative and negative covenants, and financial covenants that require us to, among other things, maintain a maximum consolidated total leverage ratio and a minimum consolidated fixed charge coverage ratio, in each case, as of the last day of each fiscal quarter. We were in full compliance with all covenants at December 31, 2013. For additional details, please refer to Note 17, Credit Agreement, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0000926326-14-000005:mdna:148]
Based on our current business plan and revenue backlog, we believe that our existing cash, cash equivalents, our anticipated cash flows from operations, cash generated from the exercise of employee stock options and purchases under our employee stock purchase plan, along with the availability of funds under our $75.0 million Credit Agreement, will be sufficient to meet our cash needs for working capital, capital expenditures, potential acquisitions, and other contractual obligations for at

[0000926326-14-000005:mdna:149]
least the next twelve months. For periods beyond the next twelve months, we also anticipate that our net operating cash flows plus existing balances of cash, and cash equivalents will suffice to fund the continued growth of our business.

[0000926326-14-000005:mdna:150]
Off-Balance Sheet Arrangements

[0000926326-14-000005:mdna:151]
As of December 31, 2013, we had no off-balance sheet arrangements as defined under Regulation S-K 303(a)(4) of the Securities Exchange Act of 1934, as amended, and the instructions thereto.

[0000926326-14-000005:mdna:152]
Contractual Obligations

[0000926326-14-000005:mdna:153]
As of December 31, 2013, we had $49.2 million in contractual commitments to third parties for non-cancelable operating leases, commitments to contract manufacturers and suppliers and other purchase commitments. See Note 12, "Commitments," to the Consolidated Financial Statements included in this Annual Report on Form 10-K for further information with respect to these commitments.

[0000926326-14-000005:mdna:154]
The following table summarizes our contractual obligations at December 31, 2013 (in thousands):

[0000926326-14-000005:mdna:155]
|  | Total |  | Less thanone year |  | One tothree years |  | Three tofive years |  | More thanfive years |
| Operating leases(1)(2) | $ | 41,779 |  |  | $ | 5,787 |  |  | $ | 10,625 |  |  | $ | 8,765 |  |  | $ | 16,602 |  |
| Commitments to contract manufacturers and suppliers(3) | 7,382 |  |  | 7,382 |  |  | — |  |  | — |  |  | — |  |
| Total(4) | $ | 49,161 |  |  | $ | 13,169 |  |  | $ | 10,625 |  |  | $ | 8,765 |  |  | $ | 16,602 |  |

[0000926326-14-000005:mdna:156]
_______________________________________________________________________________

[0000926326-14-000005:mdna:157]
| (1) | Commitments under operating leases relate primarily to leasehold property and office equipment. Rent expense was $8.1 million, $5.7 million and $3.3 million for the years ended December 31, 2013, 2012 and 2011, respectively. |

[0000926326-14-000005:mdna:158]
| (2) | In October 2011, we entered into a lease agreement for approximately 100,000 square feet of office space. Pursuant to the lease agreement, the landlord has constructed a single, three-story building of rentable space in Mountain View, California which we now lease and which serves as our headquarters. The term of the lease agreement, which commenced in November 2012, is for a period of 10 years, with a base lease commitment of approximately $40.0 million. We have two options to extend the term of the lease agreement at market rates. Each extension is for an additional 60 month term. |

[0000926326-14-000005:mdna:159]
| (3) | We purchase components from a variety of suppliers and use contract manufacturers to provide manufacturing services for our products. During the normal course of business, we issue purchase orders with estimates of our requirements several months ahead of the delivery dates. |

[0000926326-14-000005:mdna:160]
| (4) | At December 31, 2013, we have recorded $5.0 million for uncertain tax positions under long term liabilities, in accordance with U.S. GAAP, summarized under the section entitled "Critical Accounting Policies and Estimates" of this Annual Report on Form 10-K. As these liabilities do not reflect actual tax assessments, the timing and amount of payments we might be required to make will depend upon a number of factors. Accordingly, as the timing and amount of payment cannot be estimated, the $5.0 million of uncertain tax position liabilities has not been included in the contractual obligations table above. |
