# OMCL notes — 0000926326-14-000005


## us-gaap:AllowanceForCreditLossesOnFinancingReceivablesTableTextBlock

[0000926326-14-000005:notes:1]
The following table summarizes the credit losses and recorded investment in sales-type leases, excluding unearned interest, as of December 31, 2013 and December 31, 2012 (in thousands):

[0000926326-14-000005:notes:2]
|  | Allowance for Credit Losses |  | Recorded Investmentin Sales-type Leases Gross |  | Recorded Investmentin Sales-type Leases Net |
| Credit loss disclosure for December 31, 2013: |  |  |  |  |  |  |  |  |
| Accounts individually evaluated for impairment | $ | — |  |  | $ | — |  |  | $ | — |  |
| Accounts collectively evaluated for impairment | 167 |  |  | 16,884 |  |  | 16,717 |  |
| Ending balances: December 31, 2013 | $ | 167 |  |  | $ | 16,884 |  |  | $ | 16,717 |  |
| Credit loss disclosure for December 31, 2012: |  |  |  |  |  |  |  |  |
| Accounts individually evaluated for impairment | $ | 489 |  |  | $ | 489 |  |  | $ | — |  |
| Accounts collectively evaluated for impairment | 118 |  |  | 18,578 |  |  | 18,460 |  |
| Ending balances: December 31, 2012 | $ | 607 |  |  | $ | 19,067 |  |  | $ | 18,460 |  |


## us-gaap:AssetImpairmentChargesTextBlock

[0000926326-14-000005:notes:3]
Asset Impairment

[0000926326-14-000005:notes:4]
As part of the continuing integration of MTS, during the first quarter of 2013, we reorganized our management team, including the software development department, within the Non-Acute Care segment. Through the end of the first quarter of 2013, the Non-Acute Care segment had capitalized approximately $1.8 million of software development costs associated with a software solution under development which was intended to assist pharmacies in manual packaging of prescriptions. In connection with our financial statement close process for the quarter ended March 31, 2013, our management reassessed the viability of this project and the net realizable value of capitalized costs in light of its decision to change the related product road map and redesign this product based on evolving market demands. As part of this redesign process, new functionality and capabilities will need to be added to the product before commercialization. This redesign is intended to provide a more robust global platform providing larger scalability and significant functionality not contained in our current beta version. As such, we have determined we could no longer support the technological feasibility of this project in conjunction with our software capitalization policy. Therefore, we charged these costs, in the amount of $1.8 million, or $0.03 per diluted share, net of tax, to expense as a component of research and development in the accompanying consolidated statements of operations.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0000926326-14-000005:notes:5]
Organization and Summary of Significant Accounting Policies

[0000926326-14-000005:notes:6]
Description of the Company.  Omnicell, Inc. ("Omnicell," "our," "us," "we," or the "Company") was incorporated in California in 1992 under the name Omnicell Technologies, Inc. and reincorporated in Delaware in 2001 as Omnicell, Inc. Our major products are automated medication, supply control systems and medication adherence solutions which are sold in our principal market, which is the healthcare industry. Our market is primarily located in the United States and Canada.

[0000926326-14-000005:notes:7]
Principles of consolidation.  The consolidated financial statements include the accounts of our wholly-owned subsidiaries. All significant inter-company accounts and transactions have been eliminated in consolidation.

[0000926326-14-000005:notes:8]
Use of estimates.  The preparation of financial statements in accordance with U.S. generally accepted accounting principles ("GAAP") requires management to make estimates and assumptions that affect the amounts reported in our consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management's best knowledge of current events and actions that may impact the company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition, share-based compensation, inventory valuation, valuation of goodwill and purchased intangibles, valuation of long-lived assets and accounting for income taxes.

[0000926326-14-000005:notes:9]
Cash and cash equivalents. We classify investments as cash equivalents if their original or remaining contractual maturity is three months or less at the date of purchase. Cash equivalents are stated at cost, which approximates fair value. Our cash and cash equivalents are maintained in demand deposit accounts with financial institutions of high credit quality and are invested in institutional money market funds, short-term bank time deposits and similar short duration instruments with fixed maturities from overnight to three months. We continuously monitor the creditworthiness of the financial institutions and institutional money market funds in which we invest our surplus funds. We have not experienced any credit losses from our cash investments.

[0000926326-14-000005:notes:10]
Fair value of financial instruments.  We value our financial assets and liabilities on a recurring basis using the fair value hierarchy established in Accounting Standards Codification ("ASC") 820, Fair Value Measurements and Disclosures.

[0000926326-14-000005:notes:11]
ASC 820 describes three levels of inputs that may be used to measure fair value, as follows:

[0000926326-14-000005:notes:12]
Level 1 inputs, which include quoted prices in active markets for identical assets or liabilities;

[0000926326-14-000005:notes:13]
Level 2 inputs, which include observable inputs other than Level 1 inputs, such as quoted prices for similar assets or liabilities, quoted prices for identical or similar assets or liabilities in markets that are not active; or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the asset or liability; and

[0000926326-14-000005:notes:14]
Level 3 inputs, which include unobservable inputs that are supported by little or no market activity and that are significant to the fair value of the underlying asset or liability. Level 3 assets and liabilities include those whose fair value measurements are determined using pricing models, discounted cash flow methodologies or similar valuation techniques, as well as significant management judgment or estimation.

[0000926326-14-000005:notes:15]
At December 31, 2013 and December 31, 2012, our financial assets utilizing Level 1 inputs included cash equivalents. For these items, quoted market prices are readily available and fair value approximates carrying value. We do not currently have any material financial instruments utilizing Level 2 or Level 3 inputs.

[0000926326-14-000005:notes:16]
Classification of marketable securities. Marketable securities for which we have the intent and ability to hold to maturity are classified as held-to-maturity, with carrying value at amortized cost, including accrued interest. We do not hold securities for purposes of trading. However, securities held as investments for the indefinite future, pending future spending requirements are classified as available-for-sale, with carrying value at fair value and any unrealized gain or loss recorded to other comprehensive income until realized. We held $65.7 million and $38.9 million of money market mutual funds as available-for-sale cash equivalents as of December 31, 2013 and 2012, respectively.

[0000926326-14-000005:notes:17]
Revenue recognition.    We earn revenues from sales of our medication and medical and surgical supply automation systems along with consumables and related services, which are sold in the healthcare industry, our principal market. Revenues related to consumable products are reported net of discounts provided to our customers. Our customer arrangements typically include one or more of the following deliverables:

[0000926326-14-000005:notes:18]
| • | Products—Software-enabled equipment that manages and regulates the storage and dispensing of pharmaceuticals, consumable blister cards and packaging equipment and other medical supplies. |

[0000926326-14-000005:notes:19]
| • | Software—Additional software applications that enable incremental functionality of our equipment. |

[0000926326-14-000005:notes:20]
| • | Installation—Installation of equipment as integrated systems at customers' sites. |

[0000926326-14-000005:notes:21]
| • | Post-installation technical support—Phone support, on-site service, parts and access to unspecified software upgrades and enhancements, if and when available. |

[0000926326-14-000005:notes:22]
| • | Professional services—Other customer services such as training and consulting. |

[0000926326-14-000005:notes:23]
We recognize revenue when the earnings process is complete, based upon our evaluation of whether the following four criteria have been met:

[0000926326-14-000005:notes:24]
| • | Persuasive evidence of an arrangement exists. We use signed customer contracts and signed customer purchase orders as evidence of an arrangement for leases and sales. For service engagements, we use a signed services agreement and a statement of work to evidence an arrangement. |

[0000926326-14-000005:notes:25]
| • | Delivery has occurred. Equipment and embedded software product delivery is deemed to occur upon successful installation and receipt of a signed and dated customer confirmation of installation letter, providing evidence that we have delivered what a customer ordered. In instances of a customer self-installation, product delivery is deemed to have occurred upon receipt of a signed and dated customer confirmation letter. If a sale does not require installation, we recognize revenue on delivery of products to the customer, including transfer of title and risk of loss, assuming all other revenue criteria are met. For existing distributors, where installation of equipment training has been previously provided and the distributor is certified to install our equipment at end user customer facility, we recognize revenue from sales of products to the distributor upon shipment assuming all other revenue criteria are met since we do not allow for rights of return or refund. For new distributors, where we have not provided installation of equipment training, revenue on the sales of products to the distributor is deferred until the distributor has completed the Distributor Training Program and has been certified to install our equipment at the end user facility. For the sale of consumable blister cards, we recognize revenue when title and risk of loss of the products shipped have transferred to the customer, which usually occurs upon shipment from our facilities. Assuming all other revenue criteria are met, we recognize revenue for support services ratably over the related support services contract period. We recognize revenue on training and professional services as they are performed. |

[0000926326-14-000005:notes:26]
| • | Fee is fixed or determinable. We assess whether a fee is fixed or determinable at the outset of the arrangement based on the payment terms associated with the transaction. We have established a history of collecting under the original contract without providing concessions on payments, products or services. |

[0000926326-14-000005:notes:27]
| • | Collection is probable. We assess the probability of collecting from each customer at the outset of the arrangement based on a number of factors, including the customer's payment history and its current creditworthiness. If, in our judgment, collection of a fee is not probable, we defer the revenue until the uncertainty is removed, which generally means revenue is recognized upon our receipt of cash payment assuming all other revenue criteria are met. Our historical experience has been that collection from our customers is generally probable. |

[0000926326-14-000005:notes:28]
In arrangements with multiple deliverables, assuming all other revenue criteria are met, we recognize revenue for individual delivered items if they have value to the customer on a standalone basis.We allocate arrangement consideration at the inception of the arrangement to all deliverables using the relative selling price method. This method requires us to determine the selling price at which each deliverable could be sold if it were sold regularly on a standalone basis. When available, we use vendor-specific objective evidence ("VSOE") of the selling price. VSOE represents the price charged for a deliverable when it is sold separately, or for a deliverable not yet being sold separately, the price established by management with the relevant authority. We consider VSOE to exist when approximately 80% or more of our standalone sales of an item are priced within a reasonably narrow pricing range (plus or minus 15% of the median rates). We have established VSOE of the selling price for our post-installation technical support services and professional services. When VSOE of selling price is not available, third-party evidence ("TPE") of selling price for similar products and services is acceptable; however, our offerings and market strategy differ from those of our competitors, such that we cannot obtain sufficient comparable information about third parties' prices. If neither VSOE nor TPE are available, we use our best estimates of selling prices ("BESP"). We determine BESP considering factors such as market conditions, sales channels, internal costs and product margin objectives and pricing practices. We regularly review and update our VSOE and BESP information.

[0000926326-14-000005:notes:29]
The relative selling price method allocates total arrangement consideration proportionally to each deliverable on the basis of its estimated selling price. In addition, the amount recognized for any delivered items cannot exceed that which is not contingent upon delivery of any remaining items in the arrangement.

[0000926326-14-000005:notes:30]
We also use the residual method to allocate revenue between the software products that enable incremental equipment functionality, and thus are not deemed to deliver its essential functionality, and the related post-installation technical support, as these products and services continue to be accounted for under software revenue recognition rules. Under the residual method, the amount allocated to the undelivered elements equals VSOE of fair value of these elements. Any remaining amounts are attributed to the delivered items and are recognized when those items are delivered.

[0000926326-14-000005:notes:31]
A portion of our sales are made through multi-year lease agreements. Under sales-type leases, we recognize revenue for our hardware and software products net of lease execution costs such as post-installation product maintenance and technical support, at the net present value of the lease payment stream once our installation obligations have been met. We optimize cash flows by selling a majority of our non-U.S. government leases to third-party leasing finance companies on a non-recourse basis. We have no obligation to the leasing company once the lease has been sold. Some of our sales-type leases, mostly those relating to U.S. government hospitals, are retained in-house. Interest income in these leases is recognized in product revenue using the effective interest method.

[0000926326-14-000005:notes:32]
Accounts receivable and notes receivable (net investment in sales type leases). We actively manage our accounts receivable to minimize credit risk. We typically sell to customers for which there is a history of successful collection. New customers are subject to a credit review process, which evaluates that customer's financial position and ability to pay. We continually monitor and evaluate the collectability of our trade receivables based on a combination of factors. We record specific allowances for doubtful accounts when we become aware of a specific customer's impaired ability to meet its financial obligation to us, such as in the case of bankruptcy filings or deterioration of financial position.

[0000926326-14-000005:notes:33]
Uncollectible amounts are charged off against trade receivables and the allowance for doubtful accounts when we make a final determination that there is no reasonable expectation of recovery. Estimates are used in determining our allowances for all other customers based on factors such as current trends, the length of time the receivables are past due and historical collection experience. While we believe that our allowance for doubtful accounts receivable is adequate and that the judgment applied is appropriate, such estimated amounts could differ materially from what will actually be uncollectible in the future.

[0000926326-14-000005:notes:34]
The retained in-house leases discussed above are considered financing receivables. Our credit policies and evaluation of credit risk and write-off policies are applied alike to trade receivables and the net-investment in sales-type leases. For both, an account is generally past due after thirty days. The financing receivables also have customer-specific reserves for accounts identified for specific impairment and a non-specific reserve applied to the remaining population, based on factors such as current trends, the length of time the receivables are past due and historical collection experience. The retained in-house leases are not stratified by portfolio or class. Financing receivables which are reserved are generally transferred to cash-basis accounting so that revenue is recognized only as cash is received. However, the cash basis accounts continue to accrue interest.

[0000926326-14-000005:notes:35]
Sales of accounts receivable.  We record the sale of our accounts receivables as "true sales" in accordance with accounting guidance for transfers and servicing of financial assets. During the years ended 2013, 2012 and 2011, we transferred non-recourse accounts receivable totaling $41.3 million, $60.9 million and $46.9 million, respectively, which approximated fair value, to leasing companies on a non-recourse basis. At December 31, 2013, 2012 and 2011, accounts receivable included approximately $0.1 million, $0.7 million and $0.2 million, respectively, due from third-party leasing companies for transferred non-recourse accounts receivable.

[0000926326-14-000005:notes:36]
Concentration in revenues and in accounts receivable. There were no customers accounting for 10% or more of revenues for the years ended December 31, 2013, 2012 or 2011. At December 31, 2013, 2012 and 2011, no single customer accounted for more than 10% of our accounts receivable balance.

[0000926326-14-000005:notes:37]
Geographic risk. For the years ended December 31, 2013, 2012 and 2011, 11.2%, 7.5% and 2.0%, respectively, of our product revenue was from foreign countries.

[0000926326-14-000005:notes:38]
Commissions. Sales commissions generally are earned by and paid to our sales team upon order receipt, but are recognized in expense at the time of revenue recognition. Before they are recognized as expense they are recorded as prepaid commissions, which are a component of prepaid expenses.

[0000926326-14-000005:notes:39]
Dependence on suppliers. We have a supply agreement with one primary supplier for construction and supply of several sub-assemblies and inventory management of sub-assemblies used in our hardware products. There are no minimum purchase requirements. The contract with our supplier may be terminated by either the supplier or by us without cause and at any time upon delivery of two months' notice. Purchases from this supplier for the years ended December 31, 2013, 2012 and 2011 were approximately $29.2 million, $23.8 million and $21.1 million, respectively.

[0000926326-14-000005:notes:40]
Inventory. Inventories are stated at the lower of cost (utilizing standard costs, applying the first-in, first-out method) or market. Cost elements included in inventory are direct labor and materials plus applied overhead. We routinely assess on-hand inventory for timely identification and measurement of obsolete, slow-moving or otherwise impaired inventory. We write down our inventory for estimated obsolescence, excess or unmarketable quantities equal to the difference between the cost of the inventory and its estimated market value based on assumptions about future demand and market conditions. If actual future demand or market conditions are less favorable than we projected, additional inventory write-downs may be required.

[0000926326-14-000005:notes:41]
Property and equipment. Property and equipment less accumulated depreciation are stated at historical cost. Our expenditures for property and equipment are for computer equipment and software used in the administration of our business, and for leasehold improvements to our leased facilities. We also develop molds and dies used in long-term manufacturing arrangements with suppliers, and for production automation equipment used in the manufacturing of consumable blister card components. Depreciation and amortization of property and equipment are provided over their estimated useful lives, using the straight-line method, as follows:

[0000926326-14-000005:notes:42]
| Computer equipment and related software | 3 - 5 years |
| Leasehold and building improvements | Shorter of the lease term or the estimated useful life |
| Furniture and fixtures | 5 years |
| Equipment | 3 - 5 years |

[0000926326-14-000005:notes:43]
We capitalize costs related to computer software developed or obtained for internal use in accordance with ASC 350-40, Internal-Use Software. Software obtained for internal use has generally been enterprise-level business and finance software that we customize to meet our specific operational needs. Costs incurred in the application development phase are capitalized and amortized over their useful lives, which is generally five years. Costs recognized in the preliminary project phase and the post-implementation phase are expensed as incurred. At December 31, 2013 and December 31, 2012, we had $4.8 million and $5.4 million, respectively, of costs related to application development of enterprise-level software included in property and equipment.

[0000926326-14-000005:notes:44]
Software development costs. We capitalize software development costs in accordance with ASC 985-20, Costs of Software to Be Sold, Leased, or Marketed, under which certain software development costs incurred subsequent to the establishment of technological feasibility may be capitalized and amortized over the estimated lives of the related products. We establish feasibility when we complete a working model and amortize development costs over the estimated lives of the related products ranging from three to five years. During 2013 and 2012, we capitalized software development costs of $7.8 million and $5.0 million, respectively, which are included in other assets. For the years ended December 31, 2013, 2012 and 2011, we charged to cost of revenues $3.2 million, $2.3 million, and $1.6 million, respectively, for amortization of capitalized software development costs. All development costs prior to the completion of a working model are recognized as research and development expense.

[0000926326-14-000005:notes:45]
Valuation and impairment of goodwill, other intangible assets and other long lived assets. We account for goodwill and other intangible assets in accordance with ASC 350, Intangibles—Goodwill and Other ("ASC 350). For the initial recognition and measurement of Goodwill and Intangibles resulting from acquisitions, we use the guidance in ASC 805, Business Combinations.

[0000926326-14-000005:notes:46]
Under ASC 350, Intangibles - Goodwill and Other, goodwill and intangible assets with an indefinite life are not subject to amortization but are tested for impairment at least annually or more frequently if indicators of impairment exist. ASC 350 defines impairment as the condition that exists when the carrying amount of goodwill exceeds its implied fair value. The provisions of ASC 350 require that an entity assign its recorded goodwill to each of its reporting units and test each reporting unit's goodwill for impairment. We have determined that we have two reporting units: the Acute Care and the Non-Acute Care segments.

[0000926326-14-000005:notes:47]
In accordance with ASC 350, we have the option, in any period, to first assess qualitative factors to determine whether it is more likely than not (that is, a likelihood of more than 50%) that the fair value of a reporting unit is less than its carrying amount, including goodwill, or bypass the qualitative assessment and proceed directly to performing the two-step quantitative goodwill impairment test. The first step ("step 1") involves comparing each reporting unit's estimated fair value to its carrying value, including goodwill, to identify potential impairment. If the estimated fair value of a reporting unit exceeds its carrying value, there is no indication of impairment and no further test is required. If the carrying value exceeds the estimated fair value, there is an indication of potential impairment and the second step is required to be performed to measure the amount of impairment.

[0000926326-14-000005:notes:48]
In the fourth quarter of 2013, we elected to perform step 1 to determine whether it is more likely than not that the fair values of our reporting units are less than their carrying amounts. While the ultimate responsibility rests with management, we engaged the services of an independent, third-party valuation specialist to assist in determining the fair values of our reporting units. We used a combination of a discounted cash flow model (“DCF”) which utilizes the present value of cash flows to estimate fair value (also known as the income approach) and comparisons to publicly traded companies’ market multiples (also known as the market approach).

[0000926326-14-000005:notes:49]
Under the DCF model, the future cash flows for our reporting units were projected based on management’s projections, at that time, of future revenues, operating income and other factors such as working capital and capital expenditures. We also took into account market factors and industry conditions affecting our business. We used significant judgment to estimate the amount and timing of future cash flows from our reporting units and the relative risk of achieving those cash flows. Forecasts of future operations are based, in part, on operating results and our expectations as to future market conditions. The discount rate used in our DCF model was based on a weighted-average cost of capital determined from relevant market comparisons and adjusted for specific reporting unit risks (primarily the risk of achieving projected operating cash flows). A terminal value growth rate was applied to the final year of the respective cash flows for both reporting units to arrive at an estimate of fair value under the income approach. The estimated fair values of our reporting units determined under the income approach exceeded their carrying values.

[0000926326-14-000005:notes:50]
We used the market approach to corroborate the values estimated under the income approach. Under the market approach, we estimated the fair values of our reporting units based on financial information on companies that we deemed were comparable to our business. Based on publicly available information, we calculated the comparable companies’ market multiples of earnings before interest, taxes, depreciation and amortization, and stock option expense and factored in a control premium. The estimated fair values of our reporting units determined under the market approach exceeded their carrying values.

[0000926326-14-000005:notes:51]
Finally, we compared the estimated fair values of our reporting units to our September 30, 2013 total public market capitalization and assessed implied control premiums. Based on the aforementioned, we concluded that the estimated fair value determined for both our reporting units was reasonable. In each case, the estimated fair values of our reporting units exceeded their respective carrying values and, as such, we concluded that goodwill assigned to our Acute Care and Non-Acute Care segments was not impaired. In addition, we did not note any indications of goodwill impairment as of December 31, 2013

[0000926326-14-000005:notes:52]
In 2012, we opted to perform a qualitative assessment of factors to determine if goodwill had been impaired as of December 31, 2012. For both the Acute Care and Non-Acute Care segments, we considered the following qualitative factors:

[0000926326-14-000005:notes:53]
| • | Macroeconomic conditions such as general economic conditions, limitations on accessing capital, fluctuations in foreign exchange rates or other developments in equity and credit markets; |

[0000926326-14-000005:notes:54]
| • | Industry and market considerations such as changes in the environment in which we operate, an increased competitive environment, a decline in market-dependent multiples or metrics (consider in both absolute terms and relative to peers), a change in the market for our products or services, or a regulatory or political development; |

[0000926326-14-000005:notes:55]
| • | Cost factors such as increases in raw materials, labor, or other costs that have a negative effect on earnings and cash flows; |

[0000926326-14-000005:notes:56]
| • | Overall financial performance such as negative or declining cash flows or a decline in actual or planned revenue or earnings compared with actual and projected results of relevant prior periods; |

[0000926326-14-000005:notes:57]
| • | Other relevant entity-specific events such as changes in management, key personnel, strategy, or customers; contemplation of bankruptcy or litigation; and |

[0000926326-14-000005:notes:58]
| • | Events affecting a reporting unit such as a change in the composition or carrying amount of its net assets, a more-likely-than-not expectation of selling or disposing all, or a portion, of a reporting unit, the testing for recoverability of a significant asset group within a reporting unit or recognition of a goodwill impairment loss in the financial statements of a subsidiary that is a component of a reporting unit. |

[0000926326-14-000005:notes:59]
Upon completion of our qualitative assessment conducted in the fourth quarter of 2012, management concluded that it was more likely than not the fair values of both the Acute and Non-Acute reporting units exceeded their carrying values including the respective amounts of goodwill. In addition, management did not note any other indicators of goodwill  impairment as of December 31, 2012.

[0000926326-14-000005:notes:60]
We continually monitor events and changes in circumstances that could indicate carrying amounts of long-lived assets may not be recoverable. We review long-lived assets and certain purchased intangibles for impairment whenever events or changes in circumstances indicate that we will not be able to recover the asset's carrying amount. Recoverability of an asset is measured by comparing its carrying amount to the expected future undiscounted cash flows expected to result from the use and eventual disposition of that asset, excluding future interest costs that would be recognized as an expense when incurred. Any impairment to be recognized is measured by the amount by which the carrying amount of the asset exceeds its fair market value. Significant management judgment is required in:

[0000926326-14-000005:notes:61]
| • | identifying a triggering event that arises from a change in circumstances; |

[0000926326-14-000005:notes:62]
| • | forecasting future operating results; and |

[0000926326-14-000005:notes:63]
| • | estimating the proceeds from the disposition of long-lived or intangible assets. |

[0000926326-14-000005:notes:64]
Significant management judgment is also required for initial recognition and measurement of goodwill and other intangibles assets resulting from business combinations in accordance with ASC 805. Management must assess the extent to which identified other intangibles assets are properly includable (and with the appropriate fair value) or properly excludable, by applying the recognition criteria. This judgment affects not only the other intangible assets but the remainder calculation of goodwill. The assessment of useful life for each acquired intangible impacts future financial position and operating performance through amortization expense.

[0000926326-14-000005:notes:65]
Deferred service revenue and deferred gross profit. Deferred service revenue and deferred gross profit arise when customers are billed for products and/or services in advance of revenue recognition. Our deferred gross profit, classified as a current liability, consists primarily of unearned revenue on sale of equipment for which installation has not been completed, net of deferred cost of sales for such equipment, and the unearned revenue for software licenses. Our deferred service revenue, separated into current and long-term liabilities, consists of the unearned portion of service contracts for which revenue is recognized over their duration.

[0000926326-14-000005:notes:66]
Valuation of share-based awards. We account for share-based compensation plans in accordance to the provisions of ASC 718, Stock Compensation. We estimate the fair value of our employee stock awards at the date of grant using certain subjective assumptions, such as expected volatility, which is based on a combination of historical and market- based implied volatility, and the expected term of the awards which is based on our historical experience of employee stock option exercises including forfeitures. Our valuation assumptions used in estimating the fair value of share-based awards may change in future periods. We recognize the fair value of awards over their vesting period or requisite service period. In addition, we calculate our pool of excess tax benefits available within additional paid-in capital in accordance with the provisions of ASC 718.

[0000926326-14-000005:notes:67]
Accounting for income taxes. We record an income tax provision for the anticipated tax consequences of the reported results of operations. In accordance with GAAP, the provision for income taxes is computed using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been included in the financial statements. Under this method, deferred tax assets and liabilities are determined on the basis of the differences between the financial statement and tax bases of assets and liabilities, and for operating losses and tax credit carry forwards. Deferred tax assets and liabilities are measured using the enacted tax rates in effect for the periods in which those tax assets and liabilities are expected to be realized or settled. In the event that these tax rates change, we will incur a benefit or detriment on our income tax expense in the period of change. If we were to determine that all or part of the net deferred tax assets are not realizable in the future, we will record a valuation allowance that would be charged to earnings in the period such determination is made.

[0000926326-14-000005:notes:68]
In accordance with ASC 740, Income Taxes, we recognize the tax benefit from an uncertain tax position if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement. The calculation of tax liabilities involves significant judgment in estimating the impact of uncertainties in the application of GAAP and complex tax laws. Resolution of these uncertainties in a manner inconsistent with management's expectations could have a material impact on our financial condition and operating results.

[0000926326-14-000005:notes:69]
Please refer to Note 14, Income Taxes, for further information.

[0000926326-14-000005:notes:70]
Shipping costs. Outbound freight billed to customers is recorded as product revenue. The related shipping and handling costs are expensed as part of selling, general and administrative expense. Such shipping and handling expenses totaled $6.1 million, $4.1 million, and $2.7 million for the years ended December 31, 2013, 2012 and 2011, respectively.

[0000926326-14-000005:notes:71]
Advertising. Advertising costs are expensed as incurred and amounted to $0.5 million, $0.5 million, and $0.9 million for the years ended December 31, 2013, 2012 and 2011, respectively.

[0000926326-14-000005:notes:72]
Operating leases. We lease our buildings under operating leases accounted for in accordance with ASC 840, Leases.

[0000926326-14-000005:notes:73]
Sales taxes. Sales taxes collected from customers and remitted to governmental authorities are not included in our revenue.

[0000926326-14-000005:notes:74]
Foreign currency translation. We translate the assets and liabilities of our non-U.S. dollar functional currency subsidiaries into U.S. dollars using exchange rates in effect at the end of each period. Revenue and expenses for these subsidiaries are translated using rates that approximate those in effect during the period. Gains and losses from these translations are recorded as foreign currency translation adjustments and included in accumulated other comprehensive income in stockholders’ equity.

[0000926326-14-000005:notes:75]
Currency forward contracts. From time to time we enter into foreign currency forward contracts to protect our business from the risk that exchange rates may affect the eventual cash flows resulting from intercompany transactions between Omnicell and our foreign subsidiaries. These transactions primarily arise as a result of products manufactured in the United States and sold to foreign subsidiaries in U.S. dollars rather than the subsidiaries' functional currencies. These forward contracts are considered to be financial derivative instruments and are recorded at fair value in the balance sheet. Changes in fair values of these financial derivative instruments are either recognized in other comprehensive income (a component of stockholders' equity) or net income depending on whether the derivative has been designated and qualifies as a hedging instrument. As of December 31, 2013 and 2012, we had no foreign currency forward contracts which qualify for hedge accounting.

[0000926326-14-000005:notes:76]
Total comprehensive income. The largest components of total comprehensive income for the year ended December 31, 2013 and 2012 were foreign currency translation adjustments and changes in fair value of foreign currency forward hedges.

[0000926326-14-000005:notes:77]
Segment information. Prior to the acquisition of MTS, we managed our business on the basis of a single operating segment, and a single reporting unit within that segment per ASC 280, Segment Reporting. Beginning with the acquisition of MTS, which was completed in May 2012, we have organized our business into two operating business segments: Acute Care, which primarily includes products and services sold to hospital customers and Non-Acute Care, which primarily includes products and services sold to customers outside of the hospital settings.

[0000926326-14-000005:notes:78]
The Acute Care segment is organized around the design, manufacturing, selling and servicing of medication and supply dispensing systems. The Non-Acute Care segment includes primarily the manufacturing and selling of consumable medication blister cards, packaging equipment and ancillary products and services, but also includes medication dispensing systems sold to non-acute care pharmacies and facilities. We report segment information based on the management approach. The management approach designates the internal reporting used by the Chief Operating Decision Maker (the "CODM") for making decisions and assessing performance as the source of our operating segments. The CODM is our Chief Executive Officer. The CODM allocates resources to and assesses the performance of each operating segment, using information about its revenues, gross profit and income (loss) from operations.

[0000926326-14-000005:notes:79]
Since 1992, Omnicell has provided automation and business information solutions to acute care hospitals. We have developed product solutions that help optimize various workflows utilized in hospitals. We have also developed sophisticated sales, installation, and service capabilities to serve the specific and special needs of the acute care environment in hospitals. As the acute care market evolves, we see opportunities to provide medication adherence solutions, which were added to our product line through the acquisition of MTS. A portion of our organization structure and management processes will continue to be structured to optimize sales and service of solutions to the acute care market.

[0000926326-14-000005:notes:80]
Since 1984, MTS has provided medication adherence solutions to the non-acute care market. These solutions provide automated and semi-automated equipment to assist institutional and retail pharmacists in filling medication orders into blister cards, the primary method of medication control in non-acute care settings. Completing the product solution are the consumables used by institutional and retail pharmacists to make the medication adherence package. MTS has developed process manufacturing capabilities as well as sales capabilities to market medication adherence solutions to institutional and retail pharmacies. A portion of our organization structure and management processes will continue to be structured to optimize the product, sales, and service of solutions to the non-acute care market.

[0000926326-14-000005:notes:81]
In 2012, we realigned our management reporting structure to report sales of Omnicell's dispensing systems and other related business transactions to long-term care pharmacies and facilities. Accordingly, the operations of this portion of our activities are now being reflected as a part of the Non-Acute Care segment for the year ended December 31, 2012. Non-Acute Care segment operating results were immaterial for the year ended December 31, 2011.

[0000926326-14-000005:notes:82]
Effective in the second quarter of 2013, our management changed its methodology for allocating certain expenses to our reportable segments. The impact of this change in methodology in our 2012 segment operating results was immaterial.

[0000926326-14-000005:notes:83]
Substantially all of our long-lived assets are located in the United States. For the years ended December 31, 2013 and 2012, all of our total revenues and gross profits were generated by both our Acute Care and Non-Acute Care segments and no one customer accounted for greater than 10% of our revenues. For the year ended December 31, 2011, all of our total revenues and gross profits were generated by the Acute Care segment and no one customer accounted for greater than 10% of our revenues.

[0000926326-14-000005:notes:84]
Recently Adopted Accounting Standards

[0000926326-14-000005:notes:85]
In February 2013, the FASB issued ASU 2013-02, Comprehensive Income (Topic 220): Reporting of Amounts Reclassified Out of Accumulated Other Comprehensive Income ("AOCI"), which aims to improve the reporting of reclassifications out of AOCI. This update requires an entity to report the effect of significant reclassifications out of AOCI on the respective line items in net income if the amount being reclassified is required under GAAP to be reclassified in its entirety to net income. For other amounts that are not required under GAAP to be reclassified in their entirety to net income in the same reporting period, an entity is required to cross-reference other disclosures required under GAAP that provide additional detail about those amounts.  The amendments do not change the current requirements for reporting net income or other comprehensive income in financial statements. We adopted this guidance in the first quarter of 2013, without any impact to our financial position, operating results or cash flows.

[0000926326-14-000005:notes:86]
Recently Issued Accounting Standards

[0000926326-14-000005:notes:87]
In July 2013, the FASB issued ASU 2013-11,  Income Taxes (Topic 740): Presentation of an Unrecognized Tax Benefit When a Net Operating Loss Carryforward, a Similar Tax Loss, or a Tax Credit Carryforward Exists. ASU 2013-11 requires an entity to present an unrecognized tax benefit, or a portion of an unrecognized tax benefit, as a reduction to a deferred tax asset for a net operating loss carryforward, a similar tax loss, or a tax credit carryforward, except as follows: to the extent a net operating loss carryforward, a similar tax loss, or a tax credit carryforward is not available at the reporting date under the tax law of the applicable jurisdiction to settle any additional income taxes that would result from the disallowance of a tax position or the tax law of the applicable jurisdiction does not require the entity to use, and the entity does not intend to use, the deferred tax asset for such purpose, the unrecognized tax benefit should be presented in the financial statements as a liability and should not be combined with deferred tax assets. We will adopt the amendments in ASU 2013-11 in the first quarter of 2014, and do not expect the adoption to have a material impact on our financial position, operating results or cash flows.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000926326-14-000005:notes:88]
Business Acquisition

[0000926326-14-000005:notes:89]
MTS Medication Technologies, Inc.

[0000926326-14-000005:notes:90]
On May 21, 2012, we completed our acquisition of MedPak Holdings, Inc. ("MedPak") pursuant to an Agreement and Plan of Merger (the "Merger Agreement") under which Mercury Acquisition Corp, a newly formed Omnicell subsidiary, was merged with and into MedPak, with MedPak surviving the merger as a wholly-owned subsidiary of Omnicell. MedPak is the parent company of MTS Medication Technologies, Inc. ("MTS").

[0000926326-14-000005:notes:91]
The MTS acquisition primarily was to align Omnicell with the long term trends of the healthcare market to manage the health of patients across the continuum of care. We can now better serve both the acute care and non-acute care markets. Omnicell and MTS bring capabilities to each other that strengthen the product lines and expand the medication management coverage of both companies.

[0000926326-14-000005:notes:92]
We accounted for the acquisition in accordance with the provisions of FASB ASC Topic 805, Business Combinations. Under the acquisition method, the estimated fair value of the consideration transferred to purchase the acquired company is allocated to the assets acquired and the liabilities assumed based on their fair values. We have made significant estimates and assumptions in determining the allocation of the acquisition consideration.

[0000926326-14-000005:notes:93]
Pursuant to the terms of the Merger Agreement, we paid approximately $158.3 million in cash after adjustments provided for in the Merger Agreement, of which approximately $13.5 million was placed in an escrow fund, to be distributed to MedPak's stockholders (subject to claims that we may make against the escrow fund for indemnification and other claims following the closing). The revised acquisition consideration of $158.3 million is comprised entirely of cash at closing. In October 2012, a portion of the escrow fund set aside for the working capital adjustment was disbursed, with Omnicell receiving $0.3 million and MedPak's former stockholders receiving the remainder. In November of 2013, the remainder of the escrow fund was disbursed to the former MedPak stockholders.

[0000926326-14-000005:notes:94]
During the first quarter of 2013, we reduced goodwill by $0.1 million due to an adjustment in stockholder's equity.

[0000926326-14-000005:notes:95]
The total acquisition price was approximately $158.3 million and was allocated as follows (in thousands):

[0000926326-14-000005:notes:96]
|  |  | Fair value acquired |  |  |
| Cash including restricted cash |  | $ | 2,000 |  |  |
| Accounts receivable |  | 7,403 |  |  |
| Inventory |  | 11,726 |  |  |
| Deferred tax assets and other current assets |  | 2,894 |  |  |
| Total current assets |  | 24,023 |  |  |
| Property and equipment |  | 9,807 |  |  |
| Intangible assets |  | 83,900 |  |  |
| Goodwill |  | 82,800 |  |  |
| Other non-current assets |  | 308 |  |  |
| Total assets |  | 200,838 |  |  |
| Current liabilities |  | (7,917 | ) |  |
| Non-current deferred tax liabilities |  | (33,386 | ) |  |
| Other non-current liabilities |  | (1,223 | ) |  |
| Net assets acquired |  | $ | 158,312 |  |  |
| Cash consideration, fair value |  | $ | 158,312 |  |  |

[0000926326-14-000005:notes:97]
Identifiable intangible assets. Acquired technology relates to MTS’ products across all of its product lines that have reached technological feasibility, primarily the OnDemand technology. Trade name is primarily related to the MTS and OnDemand brand names. Customer relationships represent existing contracted relationships with pharmacies, institutional care facilities and others. Acquired technology, customer relationships, and trade names will be amortized on a straight-line basis over their estimated useful lives, which range from 12 to 30 years.

[0000926326-14-000005:notes:98]
The estimated fair values of the acquired technology, trade names and customer relationships were primarily determined using either the relief-from-royalty or excess earnings methods. The interest rates utilized to discount net cash flows to their present values were determined after consideration of the overall enterprise rate of return and the relative risk and importance of the assets to the generation of future cash flows.

[0000926326-14-000005:notes:99]
For income tax purposes, the historical tax bases of the acquired assets and assumed liabilities, along with the tax attributes of the MTS companies, will carry over. Because the transaction was a cash-for-stock transaction, there is no tax basis in the newly acquired intangible assets. Accordingly, the acquisition accounting includes the establishment of net deferred tax liabilities of $33.4 million, resulting from book tax basis differences related to the intangible assets acquired, as well as to the step up in the value of fixed assets and inventory to their estimated fair values at the time of acquisition.

[0000926326-14-000005:notes:100]
Details of acquired intangibles are as follows (in thousands, except for years):

[0000926326-14-000005:notes:101]
|  |  | Fair value acquired |  |  | Useful Life (years) |  | First year amortization expense |  |  |
| Trade name |  | $ | 6,800 |  |  | 12 |  | $ | 567 |  |  |
| Customer relationships |  | 50,500 |  |  | 28 to 30 |  | 1,707 |  |  |
| Acquired technology |  | 26,600 |  |  | 20 |  | 1,330 |  |  |
| Intangibles acquired |  | $ | 83,900 |  |  |  |  | $ | 3,604 |  |  |
| Weighted average life of intangibles |  |  |  | 25.14 |  |  |  |

[0000926326-14-000005:notes:102]
Goodwill. Approximately $82.8 million has been allocated to goodwill. Goodwill represents the excess of the fair value of the consideration transferred over the fair value of the underlying net tangible and identifiable intangible assets on the acquisition date. In accordance with ASC Topic 350, Intangibles - Goodwill and Other, goodwill will not be amortized, but instead will be tested for impairment at least annually or more frequently if certain indicators are present. We believe the MTS acquisition enhances our offerings and diversifies our revenue mix, providing a more robust product and service solution to our current customers while expanding Omnicell’s international presence. We consider these factors as supporting the amount of goodwill recorded.

[0000926326-14-000005:notes:103]
For the year ended December 31, 2012, we incurred approximately $3.2 million in acquisition-related costs in connection with the MTS acquisition. These costs are included primarily in selling, general and administrative expenses on our Consolidated Statement of Operations.

[0000926326-14-000005:notes:104]
During the year ended December 31, 2012, the acquired MTS operations (consolidated since the May 21, 2012 acquisition date) generated revenue of approximately $47.2 million and net income of $2.9 million.


## us-gaap:CashAndCashEquivalentsDisclosureTextBlock

[0000926326-14-000005:notes:105]
Cash and Cash Equivalents and Fair Value of Financial Instruments

[0000926326-14-000005:notes:106]
Cash and cash equivalents consist of the following significant investment asset classes, with disclosure of amortized cost, gross unrealized gains and losses, and fair value as of December 31, 2013 and December 31, 2012 (in thousands):

[0000926326-14-000005:notes:107]
|  | December 31, 2013 |  |  |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | Fair Value |  | Cash / CashEquivalents |  |  | SecurityClassification |
| Cash | $ | 38,823 |  |  | $ | — |  |  | $ | — |  |  | $ | 38,823 |  |  | $ | 38,823 |  |  |  | N/A |
| Money market funds | 65,708 |  |  | — |  |  | — |  |  | 65,708 |  |  | 65,708 |  |  |  | Available for sale |
| Total cash and cash equivalents | $ | 104,531 |  |  | $ | — |  |  | $ | — |  |  | $ | 104,531 |  |  | $ | 104,531 |  |  |  |  |

[0000926326-14-000005:notes:108]
|  | December 31, 2012 |  |  |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | Fair Value |  | Cash / CashEquivalents |  |  | SecurityClassification |
| Cash | $ | 23,422 |  |  | $ | — |  |  | $ | — |  |  | $ | 23,422 |  |  | $ | 23,422 |  |  |  | N/A |
| Money market funds | 38,892 |  |  | — |  |  | 1 |  |  | 38,891 |  |  | 38,891 |  |  |  | Available for sale |
| Total cash and cash equivalents | $ | 62,314 |  |  | $ | — |  |  | $ | 1 |  |  | $ | 62,313 |  |  | $ | 62,313 |  |  |  |  |

[0000926326-14-000005:notes:109]
The money market fund is a daily-traded cash equivalent with a price of $1.00, making it a Level 1 asset class, and its carrying cost closely approximates fair value. As demand deposit (cash) balances vary with the timing of collections and payments, the money market fund can cover any surplus or deficit, and thus is considered Available-for-sale.

[0000926326-14-000005:notes:110]
The following table displays the financial assets measured at fair value, on a recurring basis, with money market funds recorded within cash and cash equivalents (in thousands):

[0000926326-14-000005:notes:111]
|  | Quoted Prices in ActiveMarkets for IdenticalInstruments (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant UnobservableInputs(Level 3) |  | Total FairValue |
| At December 31, 2013 | $ | — |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 65,708 |  |  | $ | — |  |  | $ | — |  |  | $ | 65,708 |  |
| Total | $ | 65,708 |  |  | $ | — |  |  | $ | — |  |  | $ | 65,708 |  |
| At December 31, 2012 |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 38,891 |  |  | $ | — |  |  | $ | — |  |  | $ | 38,891 |  |
| Total | $ | 38,891 |  |  | $ | — |  |  | $ | — |  |  | $ | 38,891 |  |

[0000926326-14-000005:notes:112]
Current assets and current liabilities are recorded at amortized cost, which approximates fair value due to the short-term maturities implied.


## us-gaap:CommitmentsDisclosureTextBlock

[0000926326-14-000005:notes:113]
Commitments

[0000926326-14-000005:notes:114]
At December 31, 2013, the minimum payments under our operating leases for each of the five succeeding fiscal years were as follows (in thousands):

[0000926326-14-000005:notes:115]
| 2014 | $ | 5,787 |  |
| 2015 | 5,476 |  |
| 2016 | 5,150 |  |
| 2017 | 4,468 |  |
| 2018 | 4,298 |  |
| Thereafter | 16,601 |  |
| Total | $ | 41,780 |  |

[0000926326-14-000005:notes:116]
Commitments under operating leases relate primarily to leasehold property and office equipment. Rent expense totaled $8.1 million, $5.7 million and $3.3 million for the years ended December 31, 2013, 2012 and 2011, respectively. For 2011,we had $0.5 million of non-cancelable sublease income.

[0000926326-14-000005:notes:117]
In October 2011, we entered into a lease agreement for approximately 100,000 square feet of office space. Pursuant to the lease agreement, the landlord constructed a single, three-story building of rentable space in Mountain View, California which we now lease and which serves as our headquarters. The term of the lease agreement, which commenced in November 2012, is for a period of 10 years, with a base lease commitment of approximately $40.0 million. We have two options to extend the term of the lease agreement at market rates. Each extension is for an additional 60 month term.

[0000926326-14-000005:notes:118]
In March 2012, we entered into a lease agreement for approximately 46,000 square feet of manufacturing, distribution and office space located in Milpitas, California which commenced in October, 2012. The term of the lease agreement is for a period of 60 months, with a base lease commitment of approximately $1.8 million and a single 60 month extension option.

[0000926326-14-000005:notes:119]
In connection with the acquisition of MTS, we assumed responsibility for its 132,500 square feet of manufacturing, warehousing and office space in St. Petersburg, Florida. The remaining term of the original twelve year lease agreement, which expires in September 2016 and at the time of the MTS acquisition, had a remaining base lease commitment of approximately $3.9 million. We have two options to extend the term of the lease agreement at market rates. Each extension is for an additional 60 month term.

[0000926326-14-000005:notes:120]
In Leeds, United Kingdom, we lease an office and distribution center of approximately 16,500 square feet. The remaining term of the original ten year lease agreement is through June 8, 2021, with no extension options. The base lease commitment at the time of the MTS acquisition, converted from British Pounds at the conversion rate then in effect, was approximately $1.2 million.

[0000926326-14-000005:notes:121]
We also have smaller rented offices in Strongsville, Ohio, Nashville, Tennessee, Waukegan, Illinois, the United Arab Emirates, the People's Republic of China and the Federal Republic of Germany.

[0000926326-14-000005:notes:122]
We purchase components from a variety of suppliers and use contract manufacturers to provide manufacturing services for our products. During the normal course of business, we issue purchase orders with estimates of our requirements several months ahead of the delivery dates. Our near-term commitments to our contract manufacturers and suppliers totaled $7.4 million as of December 31, 2013.


## us-gaap:DebtDisclosureTextBlock

[0000926326-14-000005:notes:123]
Credit Agreement

[0000926326-14-000005:notes:124]
In September 2013, we entered into a credit agreement (the "Credit Agreement") with Wells Fargo Bank, National Association, as administrative agent, and the lenders from time to time party thereto. The Credit Agreement provides for a $75.0 million revolving credit facility with a $10.0 million letter of credit sub-limit. Loans under the Credit Agreement mature on September 25, 2018. The Credit Agreement permits us to request one or more increases in the aggregate commitments provided that such increases do not exceed $25.0 million in the aggregate. We expect to use the proceeds from any revolving loans under the credit facility for general corporate purposes, including future acquisitions. Our obligations under the Credit Agreement are guaranteed by certain of our domestic subsidiaries and secured by substantially all of our and the subsidiary guarantors’ assets. To date, we have not yet drawn any funds under the credit facility.

[0000926326-14-000005:notes:125]
Amounts drawn under the Credit Agreement bear interest, at our election, at a Eurodollar rate plus a margin of 1.75% per annum, or an alternate base rate equal to the highest of (a) the prime rate, (b) the federal funds rate plus 0.50%, and (c) LIBOR for an interest period of one month plus 1.75%. We are required to pay a commitment fee of 0.25% per annum on the aggregate undrawn amount of the commitments under the credit facility.

[0000926326-14-000005:notes:126]
The Credit Agreement contains customary affirmative and negative covenants, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends and other distributions. The Credit Agreement contains financial covenants that require us to, among other things, maintain a maximum consolidated total leverage ratio and a minimum consolidated fixed charge coverage ratio, in each case, as of the last day of each fiscal quarter. We were in full compliance with all covenants at December 31, 2013.


## us-gaap:DeferredCostsCapitalizedPrepaidAndOtherAssetsDisclosureTextBlock

[0000926326-14-000005:notes:127]
Other assets consist of the following (in thousands):

[0000926326-14-000005:notes:128]
|  | December 31, |
|  | 2013 |  | 2012 |
| Capitalized software development costs, net of accumulated amortization of $10,547 and $7,329 in 2013 and 2012, respectively | $ | 13,660 |  |  | $ | 11,037 |  |
| Technology license | 2,350 |  |  | 2,800 |  |
| Long-term deposits | 682 |  |  | 694 |  |
| Other assets | 1,245 |  |  | 1,247 |  |
| Total | $ | 17,937 |  |  | $ | 15,778 |  |


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0000926326-14-000005:notes:129]
Deferred gross profit consists of the following (in thousands):

[0000926326-14-000005:notes:130]
|  | December 31, 2013 |  | December 31, 2012 |
| Sales of medication and supply dispensing systems and packaging equipment, which have been delivered and invoiced but not yet installed | $ | 29,040 |  |  | $ | 30,138 |  |
| Cost of revenues, excluding installation costs | (9,083 | ) |  | (9,366 | ) |
| Deferred gross profit | $ | 19,957 |  |  | $ | 20,772 |  |


## us-gaap:DeferredRevenueDisclosureTextBlock

[0000926326-14-000005:notes:131]
Deferred Gross Profit


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000926326-14-000005:notes:132]
Stock Option Plans, Share-Based Compensation and 401(k) Plan

[0000926326-14-000005:notes:133]
Description of Share-Based Plans

[0000926326-14-000005:notes:134]
Equity Incentive Plan. On May 19, 2009, at our 2009 Annual Meeting of Stockholders (the "2009 Annual Meeting") our stockholders approved the Omnicell, Inc. 2009 Equity Incentive Plan (the "2009 Plan") which authorized 2,100,000 shares to be issued. The 2009 Plan provides for the issuance of incentive stock options, non-statutory stock options, stock appreciation rights, restricted stock awards, restricted stock unit awards, performance stock awards, performance cash awards and other stock awards to our employees, directors and consultants.

[0000926326-14-000005:notes:135]
The 2009 Plan succeeded the 1999 Equity Incentive Plan, as amended, the 2003 Equity Incentive Plan, as amended, and the 2004 Equity Incentive Plan (collectively, the "Prior Plans"). No additional awards will be granted under any of the Prior Plans; however, all outstanding stock awards granted under the Prior Plans continue to be subject to the terms and conditions as set forth in the agreements evidencing such stock awards. For purposes of determining future common shares available for grant, for each share granted as a full-value award, including restricted stock and restricted stock units ("RSUs") performance stock awards, the shares available for grant were reduced by 1.4 shares. Equity awards granted as stock options and stock appreciation rights reduce the shares available for grant by one share.

[0000926326-14-000005:notes:136]
On December 16, 2010, at a Special Meeting of Stockholders, our stockholders approved an amendment to increase the number of shares of common stock authorized for issuance under the 2009 Plan by 2,600,000 shares and to provide that the number of common stock shares available for issuance under the 2009 Plan be reduced by 1.8 shares for each share granted as a full-value award granted on and after October 1, 2010. For each share granted as a full-value award granted prior to October 1, 2010, future shares available for grants under the 2009 Plan were reduced by 1.4 shares. Awards granted as stock options and stock appreciation rights continue to reduce the number of shares available for issuance under the 2009 Plan on a one-for-one basis. On May 21, 2013, at our Annual Meeting of Stockholders, our stockholders approved an amendment to increase the number of shares of common stock authorized for issuance under the 2009 Plan by 2,500,000 shares.

[0000926326-14-000005:notes:137]
Options granted under the 2009 Plan generally become exercisable over periods of up to 4 years, generally with one-fourth of the shares vesting one year from the vesting commencement date with respect to initial grants, and the remaining shares vesting in 36 equal monthly installments thereafter; however our Board of Directors may impose different vesting terms at its discretion on any award. Options under the 2009 Plan generally expire 10 years from the date of grant. We also grant both restricted stock and restricted stock units to participants under the 2009 Plan. The Board of Directors determines the award amount, the vesting provisions and the expiration period (not to exceed ten years) for each grant. Grants of restricted stock to non-employee directors are granted on the date of our annual meeting of stockholders and vest in full on the date of our next annual meeting of stockholders, provided such non-employee director remains a director on such date. The fair value of the stock on the date of issuance is amortized to expense from the date of grant to the date of vesting. RSUs granted to employees generally vest over a period of four years and are expensed ratably on a straight-line basis over the vesting period. We consider the dilutive impact of options, restricted stock and restricted stock units in our diluted net income per share calculation.

[0000926326-14-000005:notes:138]
The Board of Directors shall administer the 2009 Plan unless and until the Board of Directors delegates administration to a committee. Our Board of Directors has delegated administration of the 2009 Plan to the Compensation Committee of the Board and the 2009 Plan is generally administered by such committee. The Board of Directors may suspend or terminate the 2009 Plan at any time. The Board of Directors may also amend the 2009 Plan at any time or from time to time. However, no amendment will be effective unless approved by our stockholders after its adoption by the Board of Directors to the extent stockholder approval is necessary to satisfy the applicable listing requirements of NASDAQ.

[0000926326-14-000005:notes:139]
If we sell, lease or dispose of all or substantially all of our assets, or we are acquired pursuant to a merger or consolidation, then the surviving entity may assume or substitute all outstanding awards under the 2009 Plan. If the surviving entity does not assume or substitute these awards, then generally the stock awards will immediately and fully vest.

[0000926326-14-000005:notes:140]
At December 31, 2013, 3,060,505 shares of common stock were reserved for future issuance under the 2009 Plan. At December 31, 2013, $7.1 million of total unrecognized compensation cost related to non-vested stock options was expected to be recognized over a weighted average period of 2.7 years.

[0000926326-14-000005:notes:141]
1997 Employee Stock Purchase Plan

[0000926326-14-000005:notes:142]
We have an Employee Stock Purchase Plan (the "ESPP"), under which employees can purchase shares of our common stock based on a percentage of their compensation, but not greater than 15% of their earnings, up to a maximum of $25,000 of fair value per year. The purchase price per share must be equal to the lower of 85% of the fair value of the common stock at the beginning of a 24-month offering period or the end of each six-month purchasing period.

[0000926326-14-000005:notes:143]
At our 2009 Annual Meeting, the stockholders approved an amendment to the ESPP, which added 2,622,426 shares to the reserve for future issuance. As of December 31, 2013, there was a total of 1,097,998 shares reserved for future issuance under the ESPP. During the year ended December 31, 2013, 450,713 shares of common stock were purchased under the ESPP. As of December 31, 2013, 4,233,557 shares had been issued under the ESPP.

[0000926326-14-000005:notes:144]
As of December 31, 2013, our unrecognized compensation cost related to the shares to be purchased under our ESPP was approximately $1.2 million and is expected to be recognized over a weighted average period of 0.6 years.

[0000926326-14-000005:notes:145]
Share-Based Compensation—Measurement and Disclosure

[0000926326-14-000005:notes:146]
We account for share-based awards granted to employees and directors, including employee stock option awards, restricted stock, PSUs and RSUs issued pursuant to the 2009 Plan and employee stock purchases made under our ESPP using the estimate grant date fair value method of accounting in accordance with ASC 718, Stock Compensation. We value options and ESPP shares using the Black-Scholes-Merton option-pricing model. Restricted stock and time-based RSUs are valued at the grant date fair value of the underlying common shares. The PSUs are valued using the Monte Carlo simulation model.

[0000926326-14-000005:notes:147]
The impact on our results for share-based compensation was as follows (in thousands):

[0000926326-14-000005:notes:148]
|  | Years Ended December 31, |
|  | 2013 |  | 2012 |  | 2011 |
| Cost of product and service revenues | $ | 1,241 |  |  | $ | 1,011 |  |  | $ | 1,398 |  |
| Research and development | 1,359 |  |  | 889 |  |  | 1,269 |  |
| Selling, general and administrative | 8,551 |  |  | 7,314 |  |  | 6,832 |  |
| Total share-based compensation expense | $ | 11,151 |  |  | $ | 9,214 |  |  | $ | 9,499 |  |

[0000926326-14-000005:notes:149]
We did not capitalize any share-based compensation into inventory during 2013, 2012 and 2011 as it was not material. Income tax (charges) benefits realized from share-based compensation and resulting increases (decreases) to additional paid in capital during 2013, 2012 and 2011 were $2.4 million, $2.6 million and $2.9 million, respectively.

[0000926326-14-000005:notes:150]
Valuation Assumptions

[0000926326-14-000005:notes:151]
The fair value of each option grant is estimated on the date of grant using the Black-Scholes-Merton option-pricing model. The fair value of shares issued under the employee stock purchase plans is estimated on the date of issuance using the Black-Scholes-Merton model. The weighted average assumptions used for options granted and ESPP in 2013, 2012 and 2011  were as follows:

[0000926326-14-000005:notes:152]
|  | Years Ended December 31, |
| Stock Option Plans | 2013 |  | 2012 |  | 2011 |
| Risk-free interest rate(1) | 1.2 | % |  | 0.9 | % |  | 1.6 | % |
| Dividend yield | — | % |  | — | % |  | — | % |
| Volatility(2) | 43.1 | % |  | 45.8 | % |  | 48.5 | % |
| Expected life(3) | 5.3 yrs |  |  | 5.2 yrs |  |  | 5.2 yrs |  |

[0000926326-14-000005:notes:153]
|  | Years Ended December 31, |
| Employee Stock Purchase Plan | 2013 |  | 2012 |  | 2011 |
| Risk-free interest rate(1) | 0.2 | % |  | 0.2 | % |  | 0.5 | % |
| Dividend yield | — | % |  | — | % |  | — | % |
| Volatility(2) | 35.1 | % |  | 38.5 | % |  | 40.2 | % |
| Expected life(3) | 0.5 - 2 yrs |  |  | 0.5 - 2 yrs |  |  | 0.5 - 2 yrs |  |

[0000926326-14-000005:notes:154]
_______________________________________________________________________________

[0000926326-14-000005:notes:155]
| (1) | The risk-free interest rate for both stock options and the ESPP is based on the zero-coupon U.S. Treasury rate curve in effect at the time of the option grant or at the beginning of the ESPP offering period. |

[0000926326-14-000005:notes:156]
| (2) | Expected volatility for both stock options and the ESPP reflects a combination of historical and market-based implied volatility consistent with ASC 718 and SEC Staff Accounting Bulletin 107. We determined that the combination of historical and market-based implied volatility provides a more accurate reflection of our market conditions and is more representative of future stock price trends than employing solely historical volatility. |

[0000926326-14-000005:notes:157]
| (3) | Represents the period of time that options granted are expected to be outstanding, which is derived from historical data on employee exercise and post-vesting employment termination behavior. |

[0000926326-14-000005:notes:158]
Share-Based Payment Award Activity

[0000926326-14-000005:notes:159]
A summary of option activity under the 2009 Plan for the years ended December 31, 2013, 2012 and 2011 is presented below:

[0000926326-14-000005:notes:160]
| Options: | Number of Shares |  | Weighted AverageExercise Price |
|  | (in thousands) |  |  |
| Outstanding at December 31, 2010 | 4,740 |  |  | $ | 12.86 |  |
| Granted | 494 |  |  | $ | 14.57 |  |
| Exercised | (413 | ) |  | $ | 8.30 |  |
| Expired | (86 | ) |  | $ | 13.59 |  |
| Forfeited | (42 | ) |  | $ | 20.76 |  |
| Outstanding at December 31, 2011 | 4,693 |  |  | $ | 13.36 |  |
| Granted | 645 |  |  | $ | 14.85 |  |
| Exercised | (669 | ) |  | $ | 8.65 |  |
| Expired | (84 | ) |  | $ | 14.02 |  |
| Forfeited | (115 | ) |  | $ | 21.44 |  |
| Outstanding at December 31, 2012 | 4,470 |  |  | $ | 14.06 |  |
| Granted | 502 |  |  | $ | 20.25 |  |
| Exercised | (1,686 | ) |  | $ | 12.53 |  |
| Expired | (56 | ) |  | $ | 15.66 |  |
| Forfeited | (87 | ) |  | $ | 14.68 |  |
| Outstanding at December 31, 2013 | 3,143 |  |  | $ | 15.82 |  |
| Vested and expected to vest at December 31, 2013 | 3,114 |  |  | $ | 15.79 |  |
| Exercisable at December 31, 2013 | 2,078 |  |  | $ | 15.11 |  |

[0000926326-14-000005:notes:161]
Outstanding options at December 31, 2013 had a weighted-average remaining contractual life of 5.6 years and an aggregate intrinsic value of $30.8 million. Vested and expected to vest options had a weighted-average remaining contractual life of 5.6 years  and an aggregate intrinsic value of $30.6 million. Exercisable options at December 31, 2013 had a weighted-average remaining contractual life of 4.1 years and an aggregate intrinsic value of $22.0 million.

[0000926326-14-000005:notes:162]
The ranges of outstanding and exercisable options for equity share-based payment awards as of December 31, 2013 were as follows:

[0000926326-14-000005:notes:163]
| Range of Exercise Prices | NumberOutstanding |  | WeightedAverage ExercisePrice ofOutstandingOptions |  | NumberExercisable |  | WeightedAverage ExercisePrice ofExercisableOptions |
|  | (in thousands) |  |  |  | (in thousands) |  |  |
| $6.40 - $10.41 | 332 |  |  | $ | 8.71 |  |  | 332 |  |  | $ | 8.71 |  |
| $10.58 - $10.75 | 384 |  |  | $ | 10.65 |  |  | 384 |  |  | $ | 10.65 |  |
| $11.27 - $13.53 | 347 |  |  | $ | 12.84 |  |  | 291 |  |  | $ | 12.77 |  |
| $13.67 - $14.10 | 358 |  |  | $ | 13.86 |  |  | 143 |  |  | $ | 13.94 |  |
| $14.16 - $15.04 | 364 |  |  | $ | 14.58 |  |  | 167 |  |  | $ | 14.67 |  |
| $15.06 - $17.29 | 382 |  |  | $ | 16.79 |  |  | 106 |  |  | $ | 16.51 |  |
| $17.49 - $20.95 | 434 |  |  | $ | 19.84 |  |  | 369 |  |  | $ | 20.12 |  |
| $21.07 - $23.19 | 330 |  |  | $ | 22.52 |  |  | 104 |  |  | $ | 21.50 |  |
| $23.41 - $26.99 | 136 |  |  | $ | 24.61 |  |  | 106 |  |  | $ | 24.76 |  |
| $29.16 - $29.16 | 76 |  |  | $ | 29.16 |  |  | 76 |  |  | $ | 29.16 |  |
| $6.40 - $29.16 | 3,143 |  |  | $ | 15.82 |  |  | 2,078 |  |  | $ | 15.11 |  |

[0000926326-14-000005:notes:164]
As of December 31, 2013, we expect $7.1 million of total unrecognized compensation costs related to unvested options to be recognized over a weighted average period of 2.7 years. The weighted average fair value of options granted was $8.09, $6.13 and $6.47 during 2013, 2012 and 2011, respectively. The intrinsic value of options exercised during 2013, 2012 and 2011 was $14.0 million, $2.8 million and $2.9 million, respectively.

[0000926326-14-000005:notes:165]
Restricted Stock and Restricted Stock Units

[0000926326-14-000005:notes:166]
A summary of activity of restricted stock and restricted stock units ("RSUs") granted under the 2009 Plan as of December 31, 2013 is presented below:

[0000926326-14-000005:notes:167]
|  | Shares ofRestricted Stock |  | Weighted-Average GrantDate Fair Value Per Share | Restricted Stock Units |  | Weighted-Average GrantDate Fair Value |
|  | (in thousands) |  |  | (in thousands) |  |  |
| Nonvested at December 31, 2010 | 77 |  |  | $ | 12.91 |  | 308 |  |  | $ | 12.98 |  |
| Granted | 68 |  |  | $ | 14.71 |  | 145 |  |  | $ | 14.39 |  |
| Vested | (77 | ) |  | $ | 12.91 |  | (152 | ) |  | $ | 14.26 |  |
| Forfeited | — |  |  | — |  | (14 | ) |  | $ | 12.82 |  |
| Nonvested at December 31, 2011 | 68 |  |  | $ | 14.71 |  | 287 |  |  | $ | 13.03 |  |
| Granted | 67 |  |  | $ | 14.19 |  | 274 |  |  | $ | 14.58 |  |
| Vested | (78 | ) |  | $ | 14.64 |  | (153 | ) |  | $ | 12.90 |  |
| Forfeited | — |  |  | — |  | (19 | ) |  | $ | 14.55 |  |
| Nonvested at December 31, 2012 | 58 |  |  | $ | 14.19 |  | 389 |  |  | $ | 14.09 |  |
| Granted | $ | 55 |  |  | $ | 18.20 |  | 190 |  |  | 19.87 |  |
| Vested | $ | (61 | ) |  | $ | 14.23 |  | (195 | ) |  | 14.31 |  |
| Forfeited | — |  |  | — |  | (22 | ) |  | 14.08 |
| Nonvested at December 31, 2013 | $ | 52 |  |  | $ | 18.43 |  | 362 |  |  | 17.15 |  |

[0000926326-14-000005:notes:168]
The fair value of restricted stock is the product of the number of shares granted and the closing market price of our common stock on the grant date. The total fair value of restricted stock grants vested in 2013, 2012 and 2011was $1.1 million, $1.1 million and $1.1 million, respectively. Our unrecognized compensation cost related to nonvested restricted stock is approximately 0.4 million and is expected to be recognized over a weighted average period of 2.0 years .

[0000926326-14-000005:notes:169]
The fair value of RSUs is the product of the number of shares granted and the closing market price of our common stock on the grant date. The total fair value of RSUs vested in 2013, 2012 and 2011 was $4.4 million, $2.3 million and $2.4 million, respectively. Expected future compensation expense relating to RSUs outstanding on December 31, 2013 is $5.5 million over a weighted- average period of 2.5 years.

[0000926326-14-000005:notes:170]
Performance-Based Restricted Stock Units

[0000926326-14-000005:notes:171]
In 2011, we began incorporating performance-based restricted stock units ("PSUs") as an element of our executive compensation plans. For 2011, we granted 100,000 PSUs; however, pursuant to their terms, 120,000 PSUs ultimately became eligible for vesting upon the achievement of a certain level of shareholder return for 2011 as described below. In 2012, we granted 125,000 PSUs of which 62,500 became eligible for vesting upon the achievement of a certain level of shareholder return for 2012 as described below. In 2013, we granted 125,000  PSUs to our executive officers.

[0000926326-14-000005:notes:172]
Our unrecognized compensation cost related to non-vested performance-based restricted stock units at December 31, 2013 was approximately $1.1 million and is expected to be recognized over a weighted-average period of 1.1 years . For the year ended December 31, 2012, we recognized $1.0 million of compensation expense for the performance-based restricted stock units. For the year ended December 31, 2011, we recognized $0.6 million of compensation expense for the performance-based restricted stock units.

[0000926326-14-000005:notes:173]
The accounting guidance for awards with market conditions differs from that for awards with service conditions only or service and performance conditions. Because the grant date fair value of an award containing market conditions is calculated as the expected value, averaging over all possible outcomes, the measured expense is amortized over the service period, regardless of whether the market condition is ever actually met.

[0000926326-14-000005:notes:174]
The fair value of a PSU award is the average of trial-specific values of the award over each of one million Monte Carlo trials. Each trial-specific value is the market value of the award at the end of the one-year performance period discounted back to the grant date. The market value of the award for each trial at the end of the performance period is the product of (a) the per share value of Omnicell stock at the end of the performance period and (b) the number of shares that vest. The number of shares that vest at the end of the performance period depends on the percentile ranking of the total shareholder return for Omnicell stock over the performance period relative to the total shareholder return of each of the other companies in the NASDAQ Healthcare Index (the "Index") as shown in the tables below.

[0000926326-14-000005:notes:175]
Vesting for the PSU awards is based on the percentile placement of our total stockholder return among the companies listed in the Index and time-based vesting. We calculate total stockholder return based on the one year annualized rates of return reflecting price appreciation plus reinvestment of dividends. For PSU awards granted on February 5, 2013 and on March 5, 2013, stock price appreciation is calculated based on the average closing prices of our common stock for the last 20 trading days leading to March 1, 2014 compared to the average closing prices for the 20 trading days ended on the last trading day of 2012. For PSU awards granted in 2011 and 2012, stock price appreciation is calculated based on the average closing prices of the applicable company's common stock for the 20 trading days ending on the last trading day of the year prior to the date of grant as compared to the average closing prices for the 20 trading days ended on the last trading day of the year of grant.

[0000926326-14-000005:notes:176]
The following table shows the percent of PSUs granted in 2011 and eligible for further time-based vesting based on our percentile placement:

[0000926326-14-000005:notes:177]
| Percentile Placement of Our Total Shareholder Return |  | % of PSUs Eligible for Time-Based Vesting |
| Below the 35th percentile |  | —% |
| At least the 35th percentile, but below the 50th percentile |  | 50% |
| At least the 50th percentile, but below the 65th percentile |  | 100% |
| At least the 65th percentile, but below the 75th percentile (1) |  | 110% to 119% |
| At or above the 75th percentile |  | 120% |

[0000926326-14-000005:notes:178]
(1)               The actual percentage of PSUs eligible for further time-based vesting is based on straight-line interpolation, where, for example, if the ranking is the 70th percentile, then the vesting percentage is 115%.

[0000926326-14-000005:notes:179]
On January 17, 2012, the Compensation Committee of our Board of Directors confirmed 76.3% as the percentile rank of Omnicell’s 2011 total stockholder return. This resulted in 120% of the 2011 PSU awards, or 120,000 shares, becoming eligible for further time-based vesting. The eligible PSU awards will vest as follows: 25% of the eligible awards for the first year vested immediately on January 17, 2012 with the remaining eligible awards vesting in equal increments, semi-annually, over the subsequent three year period beginning on June 15th and December 15th of the year after the date of grant and each subsequent year. Vesting is contingent upon continued service. Of the 120,000 shares eligible for time-based vesting under the 2011 PSU awards, 30,000 shares vested during the year ended December 31, 2013.

[0000926326-14-000005:notes:180]
The following table shows the percent of PSUs granted in 2012 eligible for further time-based vesting based on our percentile placement:

[0000926326-14-000005:notes:181]
| Percentile Placement of Our Total Shareholder Return | % of PSUs Eligible for Time-Based Vesting |
| Below the 35th percentile | —% |
| At least the 35th percentile, but below the 50th percentile | 50% |
| At least the 50th percentile | 100% |

[0000926326-14-000005:notes:182]
On January 22, 2013, the Compensation Committee of our Board of Directors confirmed 35.3% as the percentile rank of Omnicell's 2012 total stockholder return. This resulted in 50% of the 2012 PSU awards, or 62,500 shares, as eligible for further time-based vesting. The eligible performance-based restricted stock unit awards will vest as follows: 25% of the eligible shares vested immediately on January 22, 2013 with the remaining eligible awards vesting in equal increments, semi-annually, over the subsequent three year period beginning on June 15th and December 15th of the year after the date of grant and each subsequent year. Vesting is contingent upon continued service. Of the 62,500 shares eligible for time-based vesting under the 2012 PSU awards, 31,244 shares vested during the year ended December 31, 2013.

[0000926326-14-000005:notes:183]
On February 5 and March 5 2013, the Compensation Committee approved PSU awards of 125,000 shares and 12,500 shares, respectively. If the minimum performance threshold is met as determined by the Compensation Committee of the Board of Directors in 2014, the eligible performance-based restricted stock unit awards will vest as follows: 25% of the eligible shares will vest immediately, with the remaining eligible awards vesting in equal increments, semi-annually, over the subsequent three year period beginning on June 15th and December 15th of the year after the date of grant and each subsequent year. Vesting is contingent upon continued service.

[0000926326-14-000005:notes:184]
A summary of activity of the PSUs for the years ended December 31, 2013 and 2012 is presented below:

[0000926326-14-000005:notes:185]
| Performance-based Stock Units | Number of Units |  | Weighted-AverageGrant DateFair Value PerUnit |
|  | (in thousands) |  |  |
| Non-vested, December 31, 2011 | 100 |  |  | $ | 11.15 |  |
| Granted | 135 |  |  | $ | 10.94 |  |
| Vested | (60 | ) |  | $ | 11.15 |  |
| Forfeited | — |  |  | $ | — |  |
| Non-vested, December 31, 2012 | 175 |  |  | $ | 11.00 |  |
| Granted | 142 |  |  | $ | 14.68 |  |
| Vested | (57 | ) |  | $ | 11.15 |  |
| Forfeited | (35 | ) |  | $ | 10.93 |  |
| Non-vested, December 31, 2013 | 225 |  |  | $ | 13.32 |  |

[0000926326-14-000005:notes:186]
401(k) Plan

[0000926326-14-000005:notes:187]
We have established a 401(k) tax-deferred savings plan (the "Omnicell Plan"), whereby eligible employees may contribute a percentage of their eligible compensation, but not greater than 75% of their earnings, up to the maximum as required by law. On January 1, 2009, we began matching 401(k) contributions, up to 3% maximum of employee contributions or $1,000, whichever is lower. During the fourth quarter of 2012, the MTS 401(k) tax-deferred savings plan was merged with the Omnicell Plan. For the years ended December 31, 2013, 2012 and 2011, our total 401(k) contributions were $1.1 million, $0.8 million and $0.6 million, respectively.


## us-gaap:EarningsPerSharePolicyTextBlock

[0000926326-14-000005:notes:188]
Basic net income per share is computed by dividing net income for the period by the weighted average number of shares outstanding during the period, less shares subject to repurchase. Diluted net income per share is computed by dividing net income for the period by the weighted average number of shares, less shares subject to repurchase, plus, if dilutive, potential common stock outstanding during the period. Potential common stock includes the effect of outstanding dilutive stock options, restricted stock awards and restricted stock units computed using the treasury stock method.


## us-gaap:EarningsPerShareTextBlock

[0000926326-14-000005:notes:189]
Net Income Per Share

[0000926326-14-000005:notes:190]
Basic net income per share is computed by dividing net income for the period by the weighted average number of shares outstanding during the period, less shares subject to repurchase. Diluted net income per share is computed by dividing net income for the period by the weighted average number of shares, less shares subject to repurchase, plus, if dilutive, potential common stock outstanding during the period. Potential common stock includes the effect of outstanding dilutive stock options, restricted stock awards and restricted stock units computed using the treasury stock method.  Since their impact is anti-dilutive, the total number of shares excluded from the calculations of diluted net income per share for the years ended December 31, 2013, 2012 and 2011 were 850,133, 2,149,044 and 1,833,574 shares, respectively.

[0000926326-14-000005:notes:191]
The calculation of basic and diluted net income per share is as follows (in thousands, except per share amounts):

[0000926326-14-000005:notes:192]
|  | Years Ended December 31 |  |
|  | 2013 |  | 2012 |  | 2011 |  |
| Basic: |  |  |  |  |  |  |  |  |  |
| Net income | $ | 23,979 |  |  | $ | 16,178 |  |  | $ | 10,389 |  |  |
| Weighted average shares outstanding — basic | 34,736 |  |  | 33,307 |  |  | 33,123 |  |  |
| Net income per share — basic | $ | 0.69 |  |  | $ | 0.49 |  |  | $ | 0.31 |  |  |
| Diluted: |  |  |  |  |  |  |  |  |  |
| Net income | $ | 23,979 |  |  | $ | 16,178 |  |  | $ | 10,389 |  |  |
| Weighted average shares outstanding — basic | 34,736 |  |  | 33,307 |  |  | 33,123 |  |  |
| Add: Dilutive effect of employee stock plans | 1,041 |  |  | 906 |  |  | 980 |  |  |
| Weighted average shares outstanding — diluted | 35,777 |  |  | 34,213 |  |  | 34,103 |  |  |
| Net income per share — diluted | $ | 0.67 |  |  | $ | 0.47 |  |  | $ | 0.30 |  |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000926326-14-000005:notes:193]
Goodwill and Other Intangible Assets

[0000926326-14-000005:notes:194]
Activity in goodwill by reporting units, which are the same as our operating segments, for the year ended December 31, 2013 consists of the following (in thousands):

[0000926326-14-000005:notes:195]
|  | Goodwill at December 31, 2012 |  | Adjustments to Goodwill |  | Goodwill at December 31, 2013 |
| Reporting units: |  |  |  |  |  |
| Acute Care | $ | 28,543 |  |  | $ | — |  |  | $ | 28,543 |  |
| Non-Acute Care | 82,864 |  |  | (64 | ) |  | 82,800 |  |
| Total | $ | 111,407 |  |  | $ | (64 | ) |  | $ | 111,343 |  |

[0000926326-14-000005:notes:196]
Goodwill reflects the May 2012 acquisition of MedPak by Omnicell. MedPak is the parent company of MTS, a worldwide provider of medication adherence packaging systems. The acquired goodwill was assigned to the Non-Acute Care segment, created as a result of the MTS acquisition. During the first quarter of 2013, we reduced goodwill by approximately $0.1 million due to the adjustment to the fair value of an acquired foreign currency forward contract previously carried in a component of stockholder's equity.

[0000926326-14-000005:notes:197]
There were no indefinite-life intangibles at either December 31, 2013 or December 31, 2012. Finite-life intangible assets at these dates consist of the following (in thousands):

[0000926326-14-000005:notes:198]
|  | December 31, 2013 |  | December 31, 2012 |  |  |
|  | Gross |  |  |  | Net |  | Gross |  |  |  | Net |  |  |
|  | CarryingAmount |  | AccumulatedAmortization |  | CarryingAmount |  | CarryingAmount |  | AccumulatedAmortization |  | CarryingAmount |  | AmortizationLife |
| Finite-lived intangibles: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships | 54,730 |  |  | 5,236 |  |  | 49,494 |  |  | 54,730 |  |  | 3,081 |  |  | 51,649 |  |  | 5-30 years |
| Acquired technology | 27,580 |  |  | 2,598 |  |  | 24,982 |  |  | 27,580 |  |  | 1,128 |  |  | 26,452 |  |  | 3-20 years |
| Patents | 1,493 |  |  | 254 |  |  | 1,239 |  |  | 1,217 |  |  | 259 |  |  | 958 |  |  | 20 years |
| Trade name | 6,890 |  |  | 1,003 |  |  | 5,887 |  |  | 6,890 |  |  | 414 |  |  | 6,476 |  |  | 3-12 years |
| Non-compete agreements | 60 |  |  | 60 |  |  | — |  |  | 60 |  |  | 45 |  |  | 15 |  |  | 3 years |
| Total finite-lived intangibles | 90,753 |  |  | 9,151 |  |  | 81,602 |  |  | 90,477 |  |  | 4,927 |  |  | 85,550 |  |  |  |

[0000926326-14-000005:notes:199]
During 2013, 2012 and 2011, we capitalized third-party costs associated with internally-developed patents  of $0.4 million, $0.4 million and $0.2 million, respectively.

[0000926326-14-000005:notes:200]
Amortization expense of other intangible assets totaled $4.3 million, $2.9 million and $0.7 million for the years ended December 31, 2013, 2012 and 2011, respectively. The amortization of acquired technology is included within product cost of sales; other acquired intangibles are usually amortized within selling, general and administrative expenses.

[0000926326-14-000005:notes:201]
Estimated annual expected amortization expense of the finite-lived intangible assets at December 31, 2013 was as follows (in thousands):

[0000926326-14-000005:notes:202]
| 2014 | 4,229 |  |
| 2015 | 4,204 |  |
| 2016 | 3,854 |  |
| 2017 | 3,818 |  |
| 2018 | 3,711 |  |
| Thereafter | 61,786 |  |
| Total | $ | 81,602 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000926326-14-000005:notes:203]
Income Taxes

[0000926326-14-000005:notes:204]
The following is a geographical breakdown of income before the provision for income taxes (in thousands):

[0000926326-14-000005:notes:205]
|  | Years Ended December 31, |
|  | 2013 |  | 2012 |  | 2011 |
| Domestic | $ | 34,678 |  |  | $ | 25,794 |  |  | $ | 16,177 |  |
| Foreign | 351 |  |  | 1,281 |  |  | (88 | ) |
| Total income before provision for income taxes | $ | 35,029 |  |  | $ | 27,075 |  |  | $ | 16,089 |  |

[0000926326-14-000005:notes:206]
The provision for income taxes consists of the following (in thousands):

[0000926326-14-000005:notes:207]
|  | Years Ended December 31, |
|  | 2013 |  | 2012 |  | 2011 |
| Current: |  |  |  |  |  |
| Federal | $ | 8,218 |  |  | $ | 7,181 |  |  | $ | 4,285 |  |
| State | 1,621 |  |  | 1,006 |  |  | 896 |  |
| Foreign | 447 |  |  | 154 |  |  | (70 | ) |
| Total current | 10,286 |  |  | 8,341 |  |  | 5,111 |  |
| Deferred: |  |  |  |  |  |
| Federal | 1,287 |  |  | 2,169 |  |  | 1,116 |  |
| State | (263 | ) |  | 651 |  |  | (527 | ) |
| Foreign | (260 | ) |  | (264 | ) |  | — |  |
| Total deferred | 764 |  |  | 2,556 |  |  | 589 |  |
| Total provision for income taxes | $ | 11,050 |  |  | $ | 10,897 |  |  | $ | 5,700 |  |

[0000926326-14-000005:notes:208]
The provision for income taxes differs from the amount computed by applying the statutory federal tax rate as follows (in thousands):

[0000926326-14-000005:notes:209]
|  | Years Ended December 31, |
|  | 2013 |  | 2012 |  | 2011 |
| U.S. federal tax provision at statutory rate | $ | 12,260 |  |  | $ | 9,476 |  |  | $ | 5,631 |  |
| State taxes | 883 |  |  | 1,077 |  |  | 240 |  |
| Non-deductible expenses | 297 |  |  | 530 |  |  | 481 |  |
| Acquisition costs | — |  |  | 431 |  |  | — |  |
| Share-based compensation expense | 407 |  |  | 403 |  |  | 443 |  |
| Research tax credits | (1,430 | ) |  | — |  |  | (755 | ) |
| Domestic production deduction | (816 | ) |  | (601 | ) |  | (271 | ) |
| Other | (551 | ) |  | (419 | ) |  | (69 | ) |
| Total | $ | 11,050 |  |  | $ | 10,897 |  |  | $ | 5,700 |  |

[0000926326-14-000005:notes:210]
Significant components of our deferred tax assets (liabilities) are as follows (in thousands):

[0000926326-14-000005:notes:211]
|  | December 31, |
|  | 2013 |  | 2012 |
| Deferred tax assets (liabilities): |  |  |  |
| Tax credit carry forwards | $ | 3,160 |  |  | $ | 2,990 |  |
| Inventory related items | 2,947 |  |  | 2,900 |  |
| Deferred revenue | 11,074 |  |  | 11,497 |  |
| Stock compensation | 7,447 |  |  | 9,331 |  |
| Loss carry forwards | 64 |  |  | 53 |  |
| Other, net | 5 |  |  | 69 |  |
| Subtotal | 24,697 |  |  | 26,840 |  |
| Less: valuation allowance | (39 | ) |  | (39 | ) |
| Total net deferred tax assets | 24,658 |  |  | 26,801 |  |
| Reserves and accruals | (353 | ) |  | (573 | ) |
| Depreciation and amortization | (38,681 | ) |  | (39,840 | ) |
| Total deferred tax liabilities | (39,034 | ) |  | (40,413 | ) |
| Net deferred tax liabilities | $ | (14,376 | ) |  | $ | (13,612 | ) |

[0000926326-14-000005:notes:212]
Deferred income tax assets (liabilities) are provided for temporary differences that will result in future tax deductions or future taxable income, as well as the future benefit of tax credit carry forwards. We recognize deferred tax assets to the extent that we believe these assets are more likely than not to be realized. In making such a determination, we consider all available positive and negative evidence, including future reversals of existing taxable temporary differences, projected future taxable income, tax-planning strategies, and results of recent operations. On the basis of this evaluation, as of December 31, 2013, no significant valuation allowances have been recorded in any jurisdiction.

[0000926326-14-000005:notes:213]
As of December 31, 2013, we had state net operating loss carry forwards available for state income tax purposes of approximately $2.2 million. If not utilized, these carry forwards will begin to expire in 2026. In addition, as of December 31, 2013 we had federal and California research credit carry forwards of approximately $1.5 million and $7.2 million, respectively. If not utilized the federal credit carry forwards will begin to expire in 2022, while the California credits can be carried forward indefinitely. Pursuant to the requirements of ASC 718, we do not include unrealized stock option attributes as components of our deferred tax assets. The tax effected amounts of gross unrealized net operating loss and business tax credit carry forwards excluded under ASC 718 for the year ended December 31, 2013 are approximately $2.6 million, which will result in increases to additional paid in capital if and when realized as a reduction in income taxes otherwise paid.

[0000926326-14-000005:notes:214]
In general, it is our practice and intention to reinvest the earnings of our non-U.S. subsidiaries in those operations. As of December 31, 2013, we have not made a provision for U.S. federal income and state income taxes on accumulated and current earnings of $2.8 million related to our U.K. and German subsidiaries because these earnings are intended to be indefinitely reinvested in operations outside the United States. If we expect to distribute those earnings in the form of dividends or otherwise, we would be subject to U.S. and state income taxes reported as a component of income tax expense, in the amount of $1.1 million. This amount may be  reduced by any foreign tax credits available at the time of repatriation.

[0000926326-14-000005:notes:215]
We file income tax returns in the U.S. and various states and foreign jurisdictions. In the normal course of business, we are subject to examination by tax authorities, including in major jurisdictions in the United States, California, UK and Germany. In 2012, we concluded audits by the Internal Revenue Service and California Franchise Tax Board for tax years 2008 and 2009. However, all of the net operating loss and research credit carry forwards that may be used in future years are subject to adjustment, if and when utilized. As such our federal and California tax years remain open from 1996 and 1992, respectively.

[0000926326-14-000005:notes:216]
The aggregate changes in the balance of gross unrecognized tax benefits, which excludes interest and penalties, for the three years ended December 31, 2013 is as follows (in thousands):

[0000926326-14-000005:notes:217]
| Balance as of December 31, 2010 | $ | 5,431 |  |
| Decreases related to tax positions taken during the prior period | (88 | ) |
| Increases related to tax positions taken during the current period | 453 |  |
| Balance as of December 31, 2011 | $ | 5,796 |  |
| Increases related to tax positions taken during a prior period | 43 |  |
| Increases related to tax positions related to MTS | 1,066 |
| Increases related to tax positions taken during the current period | 422 |  |
| Decreases related to settlements | (33 | ) |
| Decreases related to expiration of statute of limitations | (379 | ) |
| Balance as of December 31, 2012 | $ | 6,915 |  |
| Increases related to tax positions taken during a prior period | 406 |
| Decreases related to tax positions taken during the prior period | (79 | ) |
| Increases related to tax positions taken during the current period | 764 |  |
| Decreases related to expiration of statute of limitations | (32 | ) |
| Balance as of December 31, 2013 | $ | 7,974 |  |

[0000926326-14-000005:notes:218]
As of December 31, 2013, the total amount of gross unrecognized tax benefits, if realized, would affect our tax expense by approximately $7.0 million. Our policy is to recognize interest and penalties related to unrecognized tax benefits in operating expenses. The total amount of interest and penalties recorded in 2013 was not significant. We do not expect any material changes to our unrecognized tax benefits over the next twelve months.


## us-gaap:InventoryDisclosureTextBlock

[0000926326-14-000005:notes:219]
Inventories

[0000926326-14-000005:notes:220]
Inventories consist of the following (in thousands):

[0000926326-14-000005:notes:221]
|  | December 31, 2013 |  | December 31, 2012 |
| Raw materials | $ | 10,765 |  |  | $ | 9,994 |  |
| Work in process | 534 |  |  | 385 |  |
| Finished goods | 20,158 |  |  | 16,524 |  |
| Total | $ | 31,457 |  |  | $ | 26,903 |  |


## us-gaap:LegalMattersAndContingenciesTextBlock

[0000926326-14-000005:notes:222]
Contingencies

[0000926326-14-000005:notes:223]
Legal Proceedings

[0000926326-14-000005:notes:224]
On March 8, 2013, Bobbi Polanco (“Polanco”) filed a putative class action complaint in the United States District Court for the District of New Jersey (the "Court") against Omnicell and certain of our customers (Case No. 1:13-cv-01417-NLH-KLM) alleging breach of state security notification laws, violations of state consumer fraud laws, fraud, negligence and conspiracy relating to the theft of an Omnicell electronic device containing medication dispensing cabinet log files, including certain patient health information, and subsequent notification of this unauthorized disclosure of personal health information. Polanco is seeking an injunction against the defendants to prevent each of them from committing the acts complained of in the future and monetary damages, costs and expenses. On May 2, 2013, the Court entered an order to show cause which provided, in relevant part, that Polanco is required to show cause as to why the case should not be dismissed for lack of subject matter jurisdiction. On May 13, 2013, Polanco filed an amended complaint. On May 31, 2013, Omnicell filed a motion to dismiss the complaint on the grounds that Polanco failed to satisfy constitutional standing requirements and that she failed to state a claim against Omnicell  for violating  state data breach notification statutes, consumer fraud, common law fraud, negligence and conspiracy. Omnicell also joined in the arguments of the other defendants seeking dismissal. On July 1, 2013, Polanco filed an opposition to the motions to dismiss. On July 15, 2013, Omnicell filed its reply to the opposition from Polanco. In December 2013, the Court granted the defendants' motions to dismiss without prejudice. Polanco failed to file an appeal of the Court's decision by the January 27, 2014 deadline.

[0000926326-14-000005:notes:225]
As required under ASC 450, Contingencies, we accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss. We have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that any potential loss, while reasonably possible, is not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. We believe that we have valid defenses with respect to legal proceedings pending against us. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of this contingency or because of the diversion of management's attention and the creation of significant expenses.

[0000926326-14-000005:notes:226]
Guarantees

[0000926326-14-000005:notes:227]
As permitted under Delaware law and our certificate of incorporation and bylaws, we have agreed to indemnify our directors and officers against certain losses that they may suffer by reason of the fact that such persons are, were or become our directors or officers. The term of the indemnification period is for the director’s or officer’s lifetime and there is no limit on the potential amount of future payments that we could be required to make under these indemnification agreements. We have purchased a directors’ and officers’ liability insurance policy that may enable us to recover a portion of any future payments that we may be required to make under these indemnification agreements. Assuming the applicability of coverage and the willingness of the insurer to assume coverage and subject to certain retention, loss limits and other policy provisions, we believe it is unlikely that we will be required to pay any material amounts pursuant to these indemnification obligations. However, no assurances can be given that the insurers will not attempt to dispute the validity, applicability or amount of coverage without expensive and time-consuming litigation against the insurers.

[0000926326-14-000005:notes:228]
Additionally, we undertake indemnification obligations in our ordinary course of business in connection with, among other things, the licensing of our products and the provision of our support services. In the ordinary course of our business, we have in the past and may in the future agree to indemnify another party, generally our business affiliates or customers, against certain losses suffered or incurred by the indemnified party in connection with various types of claims, which may include, without limitation, claims of intellectual property infringement, certain tax liabilities, our gross negligence or intentional acts in the performance of support services and violations of laws. The term of these indemnification obligations is generally perpetual. In general, we attempt to limit the maximum potential amount of future payments that we may be required to make under these indemnification obligations to the amounts paid to us by a customer, but in some cases the obligation may not be so limited. In addition, we have in the past and may in the future warrant to our customers that our products will conform to functional specifications for a limited period of time following the date of installation (generally not exceeding 30 days) or that our software media is free from material defects. Sales contracts for certain of our medication packaging systems often include limited warranties for up to six months, but the periodic activity and ending warranty balances we record have historically been immaterial.

[0000926326-14-000005:notes:229]
From time to time, we may also warrant that our professional services will be performed in a good and workmanlike manner or in a professional manner consistent with industry standards. We generally seek to disclaim most warranties, including any implied or statutory warranties such as warranties of merchantability, fitness for a particular purpose, title, quality and non-infringement, as well as any liability with respect to incidental, consequential, special, exemplary, punitive or similar damages. In some states, such disclaimers may not be enforceable. If necessary, we would provide for the estimated cost of product and service warranties based on specific warranty claims and claim history. We have not been subject to any significant claims for such losses and have not incurred any material costs in defending or settling claims related to these indemnification obligations. Accordingly, we believe it is unlikely that we will be required to pay any material amounts pursuant to these indemnification obligations or potential warranty claims and, therefore, no material liabilities have been recorded for such indemnification obligations as of December 31, 2013 or December 31, 2012.


## us-gaap:OtherAssetsDisclosureTextBlock

[0000926326-14-000005:notes:230]
Other Assets


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000926326-14-000005:notes:231]
Property and Equipment

[0000926326-14-000005:notes:232]
Property and equipment consist of the following (in thousands):

[0000926326-14-000005:notes:233]
|  | December 31, 2013 |  | December 31, 2012 |
| Equipment | $ | 40,180 |  |  | $ | 32,528 |  |
| Furniture and fixtures | 5,260 |  |  | 5,126 |  |
| Leasehold improvements | 7,394 |  |  | 6,992 |  |
| Purchased software | 20,199 |  |  | 19,870 |  |
| Construction in process | 2,649 |  |  | 2,693 |  |
|  | 75,682 |  |  | 67,209 |  |
| Accumulated depreciation and amortization | (40,428 | ) |  | (33,102 | ) |
| Property and equipment, net | $ | 35,254 |  |  | $ | 34,107 |  |

[0000926326-14-000005:notes:234]
Depreciation and amortization of property and equipment was approximately $10.9 million, $8.0 million, and $5.7 million for the years ended December 31, 2013, 2012 and 2011, respectively.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0000926326-14-000005:notes:235]
Depreciation and amortization of property and equipment are provided over their estimated useful lives, using the straight-line method, as follows:


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0000926326-14-000005:notes:236]
For the years ended December 31, 2013, 2012 and 2011 the contributions of our segments to net revenues and income from operations, and the reconciliation to total net income, were as follows (amounts in thousands):

[0000926326-14-000005:notes:237]
|  | December 31, |  | December 31, |  | December 31, |
|  | 2013 |  | 2012 |  | 2011 |
|  | Acute Care |  | Non-Acute Care |  | Total |  | Acute Care |  | Non-Acute Care (1) |  | Total |  | Acute Care |  | Total |
| Net revenues from external customers | $ | 284,666 |  |  | $ | 95,919 |  |  | $ | 380,585 |  |  | $ | 260,160 |  |  | $ | 53,867 |  |  | $ | 314,027 |  |  | $ | 245,535 |  |  | $ | 245,535 |  |
| Cost of revenues | 122,816 |  |  | 54,370 |  |  | 177,186 |  |  | 111,599 |  |  | 31,840 |  |  | 143,439 |  |  | 109,751 |  |  | 109,751 |  |
| Gross profit | $ | 161,850 |  |  | $ | 41,549 |  |  | $ | 203,399 |  |  | $ | 148,561 |  |  | $ | 22,027 |  |  | $ | 170,588 |  |  | $ | 135,784 |  |  | $ | 135,784 |  |
| Gross margin % | 56.9 | % |  | 43.3 | % |  | 53.4 | % |  | 57.1 | % |  | 40.9 | % |  | 54.3 | % |  | 55.3 | % |  | 55.3 | % |
| Operating expenses | 131,811 |  |  | 36,289 |  |  | 168,100 |  |  | 127,467 |  |  | 15,995 |  |  | 143,462 |  |  | 119,562 |  |  | 119,562 |  |
| Income from operations | $ | 30,039 |  |  | $ | 5,260 |  |  | $ | 35,299 |  |  | $ | 21,094 |  |  | $ | 6,032 |  |  | $ | 27,126 |  |  | $ | 16,222 |  |  | $ | 16,222 |  |
| Operating margin % | 10.6 | % |  | 5.5 | % |  | 9.3 | % |  | 8.1 | % |  | 11.2 | % |  | 8.6 | % |  | 6.6 | % |  | 6.6 | % |
| Interest and other income (expense), net |  |  |  |  | (270 | ) |  |  |  |  |  | (51 | ) |  |  |  | (133 | ) |
| Income before provision for income taxes |  |  |  |  | 35,029 |  |  |  |  |  |  | 27,075 |  |  |  |  | 16,089 |  |
| Provision for income taxes |  |  |  |  | 11,050 |  |  |  |  |  |  | 10,897 |  |  |  |  | 5,700 |  |
| Net income |  |  |  |  | $ | 23,979 |  |  |  |  |  |  | $ | 16,178 |  |  |  |  | $ | 10,389 |  |
| (1) Non-Acute Care segment includes MTS results from May 21, 2012, the closing date of acquisition. |


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0000926326-14-000005:notes:238]
Accrued liabilities consist of the following (in thousands):

[0000926326-14-000005:notes:239]
|  | December 31, 2013 |  | December 31, 2012 |
| Rebates and lease buyouts | $ | 1,699 |  |  | $ | 3,179 |  |
| Advance payments from customers | 4,971 |  |  | 2,829 |  |
| Accrued Group Purchasing Organization (GPO) fees | 2,324 |  |  | 2,278 |  |
| Technology license purchase obligation, current portion | 1,500 |  |  | 1,750 |  |
| Taxes payable | 1,664 |  |  | 555 |  |
| Other | 1,588 |  |  | 1,397 |  |
| Total | $ | 13,746 |  |  | $ | 11,988 |  |


## us-gaap:ScheduleOfCreditLossesRelatedToFinancingReceivablesNoncurrentTableTextBlock

[0000926326-14-000005:notes:240]
The following table summarizes the activity for the allowance for credit losses account for the investment in sales-type leases for the year ended December 31, 2013 (in thousands):

[0000926326-14-000005:notes:241]
|  | Year EndedDecember 31, 2013 |
| Allowance for credit losses, December 31, 2012 | 607 |  |
| Current period provision (reversal) | 49 |  |
| Direct write-downs charged against the allowance | (413 | ) |
| Recoveries of amounts previously charged off | (76 | ) |
| Allowance for credit losses at December 31, 2013 | 167 |  |


## us-gaap:ScheduleOfFutureMinimumLeasePaymentsForCapitalLeasesTableTextBlock

[0000926326-14-000005:notes:242]
The minimum lease payments under sales-type leases as of December 31, 2013 were as follows (in thousands):

[0000926326-14-000005:notes:243]
| 2014 | $5,851 |  |
| 2015 | 4,857 |  |  |
| 2016 | 3,618 |  |  |
| 2017 | 2,710 |  |  |
| 2018 | 1,136 |  |  |
| Total | $18,172 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000926326-14-000005:notes:244]
At December 31, 2013, 2012, and 2011 segment assets, depreciation and amortization, and capital expenditures were as follows (amounts in thousands):

[0000926326-14-000005:notes:245]
|  | December 31, |  | December 31, |  | December 31, |
|  | 2013 |  | 2012 |  | 2011 |
|  | Acute Care |  | Non-Acute Care (1) |  | Total |  | Acute Care |  | Non-Acute Care (1) |  | Total |  | Acute Care |  | Total |
| Segment Assets | $ | 263,154 |  |  | $ | 229,347 |  |  | $ | 492,501 |  |  | $ | 235,186 |  |  | $ | 206,633 |  |  | $ | 441,819 |  |  | $ | 363,849 |  |  | $ | 363,849 |  |
| Depreciation/Amortization | $ | 11,236 |  |  | $ | 7,129 |  |  | $ | 18,365 |  |  | $ | 9,017 |  |  | $ | 4,308 |  |  | 13,325 |  |  | 7,983 |  |  | 7,983 |  |
| Capital Expenditures | $ | 4,392 |  |  | $ | 7,943 |  |  | $ | 12,335 |  |  | $ | 13,234 |  |  | $ | 1,953 |  |  | $ | 15,187 |  |  | $ | 8,685 |  |  | $ | 8,685 |  |
| (1) Non-Acute Care segment includes MTS results from May 21, 2012, the date of acquisition. |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000926326-14-000005:notes:246]
SCHEDULE II

[0000926326-14-000005:notes:247]
VALUATION AND QUALIFYING ACCOUNTS

[0000926326-14-000005:notes:248]
(in thousands)

[0000926326-14-000005:notes:249]
| Allowances deducted from assets: |  | Balance atbeginning ofyear |  | Additionscharged tocosts andexpenses (2) |  | Charged(credited)to otheraccounts |  | Describecharged tootheraccounts |  | Deductions |  | Describedeductions |  | Balance atend of year |
| For the year ended December 31, 2011 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable(1) |  | $ | 497 |  |  | $ | 63 |  |  | $ | (96 | ) |  | (3) |  | $ | (21 | ) |  | (4) |  | $ | 443 |  |
| Investment in sales-type leases(1) |  | 411 |  |  | — |  |  | (22 | ) |  | (5) |  | (105 | ) |  | (4) |  | 284 |  |
| Total allowances deducted from assets |  | $ | 908 |  |  | $ | 63 |  |  | $ | (118 | ) |  |  |  | $ | (126 | ) |  |  |  | $ | 727 |  |
| For the year ended December 31, 2012 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable(1) |  | $ | 443 |  |  | $ | 316 |  |  | $ | (57 | ) |  | (3) |  | $ | 20 |  |  | (4) |  | $ | 722 |  |
| Investment in sales-type leases(1) |  | 284 |  |  | 425 |  |  | — |  |  | (3) |  | (102 | ) |  | (4) |  | 607 |  |
| Total allowances deducted from assets |  | $ | 727 |  |  | $ | 741 |  |  | $ | (57 | ) |  |  |  | $ | (82 | ) |  |  |  | $ | 1,329 |  |
| For the year ended December 31, 2013 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable(1) |  | $ | 722 |  |  | 195 |  |  | (67 | ) |  | (3) |  | (360 | ) |  | (4) |  | 490 |  |
| Investment in sales-type leases (1) |  | 607 |  |  | 49 |  |  | — |  |  |  |  | (489 | ) |  | (4) |  | 167 |
| Total allowances deducted from assets |  | $ | 1,329 |  |  | $ | 244 |  |  | $ | (67 | ) |  |  |  | $ | (849 | ) |  |  |  | $ | 657 |  |

[0000926326-14-000005:notes:250]
| (1) | Allowance for doubtful accounts. |

[0000926326-14-000005:notes:251]
| (2) | Represents amounts charged to bad debt expense. |

[0000926326-14-000005:notes:252]
| (3) | Represents amounts credited to bad debt expense. |

[0000926326-14-000005:notes:253]
| (4) | Represents amounts written-off, net of recoveries. |

[0000926326-14-000005:notes:254]
| (5) | Represents amounts credited to bad debt expense and lease receivable adjustment. |


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0000926326-14-000005:notes:255]
Finite-life intangible assets at these dates consist of the following (in thousands):


## us-gaap:SegmentReportingDisclosureTextBlock

[0000926326-14-000005:notes:256]
Segments

[0000926326-14-000005:notes:257]
Beginning with the acquisition of MTS, which was completed on May 21, 2012, we have organized our business into two operating business segments: Acute Care, which primarily includes products and services sold to hospital customers and Non-Acute Care, which primarily includes products and services sold to customers outside of hospital settings.

[0000926326-14-000005:notes:258]
Since 1992, Omnicell has provided automation and business information solutions to acute care hospitals. We have developed product solutions that help optimize various workflows utilized in hospitals. We have also developed sophisticated sales, installation, and service capabilities to serve the specific and special needs of the acute care environment in hospitals. As the acute care market evolves, we see opportunities to provide medication adherence solutions, which were added to our product line through the acquisition of MTS, to the acute care market as well. A portion of our organization structure and management processes will continue to be structured to optimize sales and service of solutions to the acute care market.

[0000926326-14-000005:notes:259]
In 2012, we realigned our management reporting structure to report sales of Omnicell's dispensing systems and other related business transactions into long-term care pharmacies and facilities. Accordingly, the operations of this portion of our activities are now being reflected as a part of the Non-Acute Care segment for the year ended December 31, 2012 and 2013. The impact of this reporting structure change on the year ended December 31, 2011 was immaterial to our overall reported results.

[0000926326-14-000005:notes:260]
We believe that legislative changes and economic pressures to manage costs will cause healthcare organizations to manage the health of patients across the continuum of care regardless of the setting in which the care is provided. We believe we have the capabilities and market position to provide the tools needed by our customers to manage medications across the continuum of care. But we also believe that the inherent differences between medication management workflows in acute care settings and non-acute care settings will cause our product solutions and marketing strategies to be managed separately for these two customer segments.

[0000926326-14-000005:notes:261]
In the second quarter of 2013, our management changed its methodology for allocating certain expenses to our reportable segments. We have reclassified segment operating results for the years ended December 31, 2012 to conform to the 2013 presentation. For the years ended December 31, 2013, 2012 and 2011 the contributions of our segments to net revenues and income from operations, and the reconciliation to total net income, were as follows (amounts in thousands):

[0000926326-14-000005:notes:262]
For the year ended December 31, 2012, the Non-Acute Care cost of revenues included $1.7 million of acquisition-related charges primarily associated with the step-up to the estimated fair value of inventory acquired from MTS and consumed in the normal sales cycle of our business. The Non-Acute Care operating expenses included $0.9 million of acquisition-related charges primarily associated with severance expenses. For the year ended December 31, 2012, the Acute Care operating expenses included $2.3 million of acquisition-related charges for transaction costs, required to be expensed under ASC 805, Business Combinations.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000926326-14-000005:notes:263]
Stockholders’ Equity

[0000926326-14-000005:notes:264]
Treasury Stock

[0000926326-14-000005:notes:265]
2008 Stock Repurchase Program

[0000926326-14-000005:notes:266]
In February 2008, our Board of Directors authorized a stock repurchase program, (the "2008 Repurchase Program") for the repurchase of up to $90.0 million of our common stock. The timing, price and volume of the repurchases have been based on market conditions, relevant securities laws and other factors.

[0000926326-14-000005:notes:267]
For the year ended December 31, 2012, we repurchased 898,168 shares at an average cost of $13.76 per share, including commissions. For the year ended December 31, 2011, we repurchased 889,511 shares at an average cost of $14.13 per share, including commissions. All repurchased shares were recorded as treasury stock and were accounted for under the cost method. No repurchased shares have been retired. Additionally, for the years ended December 31, 2013, 2012 and 2011, we withheld 103,229 shares, 79,968 shares and 43,174 shares, respectively, from employees to satisfy tax withholding obligations on the vesting of restricted stock.

[0000926326-14-000005:notes:268]
From the inception of the 2008 Repurchase Program in February 2008 through December 31, 2012, we repurchased a total of 5,853,975 shares at an average cost of $15.37 per share through open market purchases. As of December 31, 2012, we have completed the 2008 Repurchase Program having repurchased $90.0 million of our common stock.

[0000926326-14-000005:notes:269]
2012 Stock Repurchase Program

[0000926326-14-000005:notes:270]
On August 1, 2012, our Board of Directors established a new stock repurchase program (the "2012 Repurchase Program") authorizing share repurchases of up to $50.0 million of our common stock, with no termination date. The timing, price and volume of repurchases will be based on market conditions, relevant securities laws and other factors. The stock repurchases may be made from time to time on the open market, in privately negotiated transactions or pursuant to a Rule 10b-18 plan. The stock repurchase program does not obligate us to repurchase any specific number of shares, and Omnicell may terminate or suspend the repurchase program at any time

[0000926326-14-000005:notes:271]
For the year ended December 31, 2013, and from the inception of the 2012 Repurchase Program, we have repurchased a total of $21.0 million, or 884,645 shares at an average cost of $23.70 per share, including commissions. As of December 31, 2013, the maximum dollar value of shares that may yet be purchased under the plan is $29.1 million.


## omcl:AccruedLiabilitiesTextBlock

[0000926326-14-000005:notes:272]
Accrued Liabilities


## omcl:NetInvestmentsInSalesTypeLeasesTextBlock

[0000926326-14-000005:notes:273]
Net Investment in Sales-Type Leases

[0000926326-14-000005:notes:274]
Our sales-type leases are for terms generally ranging up to five years. Sales-type lease receivables are collateralized by the underlying equipment. The components of our net investment in sales-type leases are as follows (in thousands):

[0000926326-14-000005:notes:275]
|  | December 31, 2013 |  | December 31, 2012 |
| Net minimum lease payments to be received | $ | 18,172 |  |  | $ | 19,665 |  |
| Less unearned interest income portion | 1,455 |  |  | 1,205 |  |
| Net investment in sales-type leases | 16,717 |  |  | 18,460 |  |
| Less current portion(1) | 5,232 |  |  | 5,232 |  |
| Non-current net investment in sales-type leases(2) | $ | 11,485 |  |  | $ | 13,228 |  |

[0000926326-14-000005:notes:276]
(1)     A component of other current assets. This amount is net of allowance for doubtful accounts of $0.1 million as of December 31, 2013 and $0.5 million as of December 31, 2012.

[0000926326-14-000005:notes:277]
(2)     Net of allowance for doubtful accounts of $0.1 million as of December 31, 2013 and $0.1 million as of December 31, 2012.
