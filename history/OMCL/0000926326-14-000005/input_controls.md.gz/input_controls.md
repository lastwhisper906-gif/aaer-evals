# OMCL 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: 4 candidate headings, none whose body matches 'critical audit matter'.


## item_9a

[0000926326-14-000005:item_9a:1]
ITEM 9A.    CONTROLS AND PROCEDURES

[0000926326-14-000005:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0000926326-14-000005:item_9a:3]
Our management, with the participation of our principal executive officer and principal financial officer, evaluated the effectiveness of our disclosure controls and procedures (as such term is defined in Rules 13a-15(e) and 15d-15(e) under the Securities Exchange Act of 1934, as amended, or the Exchange Act) as of the end of the period covered by this Annual Report. These disclosure controls and procedures are designed to ensure that the information required to be disclosed by us in this Annual Report on Form 10-K was (i) recorded, processed, summarized and reported within the time periods specified in the SEC's rules and regulations and (ii) accumulated and communicated to our management, including our principal executive officer and principal financial officer, to allow timely decisions regarding required disclosure.

[0000926326-14-000005:item_9a:4]
Based on such evaluation, our principal executive officer and principal financial officer have concluded that, as of December 31, 2013, our disclosure controls and procedures were effective at the reasonable assurance level.

[0000926326-14-000005:item_9a:5]
Management's Report on Internal Control Over Financial Reporting

[0000926326-14-000005:item_9a:6]
Our management is responsible for establishing and maintaining adequate internal control over financial reporting (as such term is defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act). Our internal control system is designed to provide reasonable assurance regarding the preparation and fair presentation of financial statements for external purposes in accordance with U.S. generally accepted accounting principles. All internal control systems, no matter how well designed, have inherent limitations and can provide only reasonable assurance that the objectives of the internal control system are met.

[0000926326-14-000005:item_9a:7]
Under the supervision and with the participation of our management, including our principal executive officer and principal financial officer, we conducted an evaluation of the effectiveness of our internal control over financial reporting as of December 31, 2013 using the criteria for effective internal control over financial reporting as described in "Internal Control—Integrated Framework," issued by the Committee of Sponsoring Organization of the Treadway Commission (1992 framework) (the COSO Criteria). Based on this assessment, management concluded that, as of December 31, 2013, our internal control over financial reporting was effective.

[0000926326-14-000005:item_9a:8]
Our independent registered public accounting firm, Ernst & Young LLP, has issued its attestation report on our internal control over financial reporting. Their report follows this Item 9A in this Annual Report on Form 10-K.

[0000926326-14-000005:item_9a:9]
Changes in Internal Control Over Financial Reporting

[0000926326-14-000005:item_9a:10]
There have been no changes in our internal control over financial reporting (as such term is defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act) during the year ended December 31, 2013 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0000926326-14-000005:item_9a:11]
Attestation Report of the Registered Public Accounting Firm

[0000926326-14-000005:item_9a:12]
The report required by this item is set forth below:

[0000926326-14-000005:item_9a:13]
49

[0000926326-14-000005:item_9a:14]
REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

[0000926326-14-000005:item_9a:15]
The Board of Directors and Stockholders of Omnicell, Inc.

[0000926326-14-000005:item_9a:16]
We have audited Omnicell, Inc.'s internal control over financial reporting as of December 31, 2013, based on criteria established in Internal Control—Integrated Framework issued by the Committee of Sponsoring Organizations of the Treadway Commission (1992 framework) (the COSO Criteria). Omnicell, Inc.'s management is responsible for maintaining effective internal control over financial reporting, and for its assessment of the effectiveness of internal control over financial reporting included in the accompanying Management's Report on Internal Control Over Financial Reporting. Our responsibility is to express an opinion on the company's internal control over financial reporting based on our audit.

[0000926326-14-000005:item_9a:17]
We conducted our audit in accordance with the standards of the Public Company Accounting Oversight Board (United States). Those standards require that we plan and perform the audit to obtain reasonable assurance about whether effective internal control over financial reporting was maintained in all material respects. Our audit included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, testing and evaluating the design and operating effectiveness of internal control based on the assessed risk, and performing such other procedures as we considered necessary in the circumstances. We believe that our audit provides a reasonable basis for our opinion.

[0000926326-14-000005:item_9a:18]
A company's internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company's internal control over financial reporting includes those policies and procedures that (1) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (2) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (3) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use or disposition of the company's assets that could have a material effect on the financial statements.

[0000926326-14-000005:item_9a:19]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0000926326-14-000005:item_9a:20]
In our opinion, Omnicell Inc., maintained, in all material respects, effective internal control over financial reporting as of December 31, 2013, based on the COSO criteria.

[0000926326-14-000005:item_9a:21]
We also have audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States), the consolidated balance sheets of Omnicell, Inc. as of December 31, 2013 and 2012, and the related consolidated statements of operations, comprehensive income, stockholders' equity, and cash flows for each of the three years in the period ended December 31, 2013 of Omnicell Inc., and our report dated March 17, 2014 expressed an unqualified opinion thereon.

[0000926326-14-000005:item_9a:22]
/s/ Ernst & Young LLP

[0000926326-14-000005:item_9a:23]
San Jose, California

[0000926326-14-000005:item_9a:24]
March 17, 2014
