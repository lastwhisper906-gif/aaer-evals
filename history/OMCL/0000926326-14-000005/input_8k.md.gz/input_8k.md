# OMCL 8-K — 0001104659-14-006352 filed 2014-02-04

## item codes, every 8-K on or before 2014-03-17

- 2014-02-07 0001104659-14-007552 — 5.02, 9.01
- 2014-02-04 0001104659-14-006352 — 2.02, 9.01
- 2013-12-09 0001104659-13-088980 — 1.01, 9.01
- 2013-12-02 0001104659-13-087877 — 5.02
- 2013-10-31 0001104659-13-079660 — 2.02, 9.01
- 2013-09-26 0001104659-13-072435 — 1.01, 2.03, 9.01
- 2013-08-01 0001104659-13-058959 — 2.02, 9.01
- 2013-05-23 0001104659-13-044317 — 5.07
- 2013-05-02 0001104659-13-036605 — 2.02, 9.01
- 2013-03-11 0001104659-13-019143 — 8.01
- 2013-02-07 0001104659-13-008477 — 5.02, 9.01
- 2013-01-31 0001104659-13-006446 — 2.02, 9.01
- 2012-11-02 0001104659-12-073697 — 5.02
- 2012-10-25 0001104659-12-071211 — 2.02, 9.01
- 2012-08-06 0001104659-12-054635 — 8.01
- 2012-08-03 0001104659-12-054214 — 2.01, 9.01 — amendment of 0001104659-12-038888
- 2012-08-01 0001104659-12-053005 — 2.02, 9.01
- 2012-06-12 0001104659-12-042936 — 8.01, 9.01
- 2012-05-23 0001104659-12-039459 — 5.07
- 2012-05-22 0001104659-12-038888 — 2.01, 9.01
- 2012-05-02 0001104659-12-032048 — 2.02, 9.01
- 2012-05-02 0001104659-12-032036 — 1.01, 9.01
- 2012-04-04 0001104659-12-023883 — 5.02, 8.01
- 2012-03-20 0001104659-12-019462 — 1.01, 9.01
- 2012-02-13 0001104659-12-009353 — 5.02, 9.01
- 2012-01-26 0001104659-12-004244 — 2.02, 9.01
- 2011-10-27 0001104659-11-058464 — 2.02, 9.01
- 2011-10-25 0001104659-11-057721 — 1.01
- 2011-07-28 0001104659-11-041505 — 2.02, 9.01
- 2011-05-27 0001104659-11-032006 — 5.07
- 2011-05-02 0001104659-11-024908 — 2.02, 9.01
- 2011-04-15 0001104659-11-020407 — 5.02, 9.01 — amendment of 0001104659-11-005638
- 2011-02-08 0001104659-11-005638 — 5.02, 9.01
- 2011-01-27 0001104659-11-003419 — 2.02, 9.01
- 2010-12-22 0001104659-10-064003 — 5.02, 5.07, 9.01
- 2010-10-27 0001104659-10-054036 — 2.02, 9.01
- 2010-10-05 0001104659-10-051173 — 8.01
- 2010-07-22 0001104659-10-039126 — 2.02, 9.01
- 2010-07-09 0001104659-10-037594 — 2.05
- 2010-05-28 0001104659-10-031607 — 5.07
- 2010-04-26 0001104659-10-021797 — 2.02, 9.01
- 2010-03-17 0001104659-10-014849 — 5.02, 9.01
- 2010-02-08 0001104659-10-005457 — 5.02, 9.01
- 2010-01-28 0001104659-10-003627 — 2.02, 9.01
- 2009-10-22 0001104659-09-059972 — 2.02, 9.01
- 2009-07-23 0001104659-09-044508 — 2.02, 9.01
- 2009-05-20 0001104659-09-033938 — 5.02, 9.01
- 2009-04-30 0001104659-09-027707 — 2.02, 9.01
- 2009-03-10 0001104659-09-016178 — 5.02, 9.01
- 2009-02-09 0001104659-09-007692 — 5.02, 9.01
- 2009-01-29 0001104659-09-005022 — 2.02, 2.05, 9.01
- 2009-01-21 0001104659-09-003180 — 2.02, 8.01, 9.01
- 2009-01-06 0001104659-09-000625 — 5.02
- 2008-10-23 0001104659-08-065475 — 2.02, 9.01
- 2008-07-21 0001104659-08-046690 — 2.02, 9.01
- 2008-05-16 0001104659-08-034035 — 8.01, 9.01
- 2008-04-28 0001104659-08-027379 — 7.01, 9.01
- 2008-04-21 0001104659-08-025616 — 2.02, 9.01
- 2008-03-12 0001104659-08-016939 — 7.01, 9.01
- 2008-02-26 0001104659-08-012840 — 7.01, 9.01
- 2008-02-12 0001104659-08-009382 — 5.02, 9.01
- 2008-01-31 0001104659-08-006199 — 2.02, 9.01
- 2007-12-05 0001104659-07-087191 — 1.01, 9.01
- 2007-10-18 0001104659-07-075654 — 2.02, 9.01
- 2007-07-27 0001104659-07-056886 — 5.03, 9.01
- 2007-07-19 0001104659-07-054924 — 2.02, 9.01
- 2007-05-23 0001104659-07-042287 — 8.01, 9.01
- 2007-05-07 0001104659-07-036172 — 1.01, 5.02, 9.01
- 2007-04-24 0001104659-07-030578 — 2.02, 9.01 — amendment, the index does not say of what
- 2007-04-24 0001104659-07-030547 — 2.02, 9.01
- 2007-04-10 0001104659-07-027465 — 5.02, 9.01
- 2007-03-23 0001104659-07-021969 — 2.02, 4.02, 9.01
- 2007-01-30 0001104659-07-005772 — 2.02, 9.01
- 2007-01-09 0001104659-07-001600 — 5.02, 9.01
- 2006-10-30 0001104659-06-069612 — 1.01
- 2006-10-19 0001104659-06-067549 — 2.02, 9.01
- 2006-07-20 0001104659-06-048020 — 2.02, 4.02, 9.01
- 2006-05-17 0001104659-06-035522 — 1.01, 9.01 — amendment of 0001104659-05-011155
- 2006-05-09 0001104659-06-032706 — 1.01, 9.01
- 2006-04-25 0001104659-06-027438 — 2.02, 9.01
- 2006-04-04 0001104659-06-022204 — 1.01, 9.01
- 2006-03-15 0001104659-06-016861 — 1.01, 9.01
- 2006-01-30 0001104659-06-004749 — 2.02, 9.01
- 2006-01-24 0001104659-06-003504 — 1.01, 5.02, 9.01
- 2005-12-13 0001104659-05-060532 — 1.01, 9.01
- 2005-11-10 0001104659-05-054663 — 2.02, 9.01
- 2005-07-21 0001104659-05-033464 — 2.02, 9.01
- 2005-06-22 0001104659-05-029255 — 1.01
- 2005-05-16 0001104659-05-023473 — 2.02, 9.01 — amendment of 0001104659-05-018173
- 2005-05-16 0001104659-05-023471 — 2.02, 9.01 — amendment of 0001104659-05-017382
- 2005-05-10 0001104659-05-022127 — 1.01
- 2005-04-26 0001104659-05-018173 — 2.02, 9.01
- 2005-04-21 0001104659-05-017382 — 2.02, 9.01
- 2005-04-06 0001104659-05-015401 — 5.02
- 2005-03-15 0001104659-05-011155 — 1.01, 9.01
- 2005-03-08 0001104659-05-009975 — 1.01, 9.01
- 2005-02-03 0001104659-05-003943 — 2.02, 9.01
- 2005-01-13 0001104659-05-001314 — 5.02, 9.01
- 2004-10-21 0001104659-04-031413 — 2.02, 9.01
- 2004-07-22 0001104659-04-020572 — 12, 7
- 2004-04-14 0001104659-04-010039 — 12, 7
- 2004-04-05 0001104659-04-009437 — 12, 7
- 2004-01-26 0001104659-04-001655 — 12, 7
- 2003-10-16 0001104659-03-022990 — 12, 7
- 2003-07-17 0001104659-03-015053 — 9
- 2003-04-18 0001104659-03-006823 — 7, 9
- 2003-02-14 0001104659-03-002607 — 5, 7

## late-filing notifications on or before 2014-03-17

- 2007-03-16 0001104659-07-020094 — NT 10-K, for the period ended 2006-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001104659-14-006352:8k_2_02:1]
EX-99.1
2
a14-4939_1ex99d1.htm
EX-99.1

[0001104659-14-006352:8k_2_02:2]
Exhibit 99.1

[0001104659-14-006352:8k_2_02:3]
| Contact: |  |  |
| Rob Seim |  | Omnicell, Inc. |
| Chief Financial Officer |  | 590 East Middlefield Road |
| 800-850-6664, ext. 6478 |  | Mountain View, CA 94043 |
| rob.seim@omnicell.com |  |  |

[0001104659-14-006352:8k_2_02:4]
Omnicell Achieves Record Revenues and Earnings in 2013

[0001104659-14-006352:8k_2_02:5]
Extends Four-Year Trajectory of Company Growth

[0001104659-14-006352:8k_2_02:6]
MOUNTAIN VIEW, Calif. — February 4, 2014— Omnicell, Inc. (NASDAQ: OMCL), a leading provider of medication and supply management solutions to healthcare systems, today announced results for its fourth quarter and year ended December 31, 2013.

[0001104659-14-006352:8k_2_02:7]
GAAP results: Revenue for the fourth quarter of 2013 was $105.8 million, up $11.7 million or 12.5% from the third quarter of 2013, and up $15.6 million or 17.3% from the fourth quarter of 2012. Revenue for the year ended December 31, 2013 was $380.6 million, up $66.6 million or 21.2% from the year ended December 31, 2012.

[0001104659-14-006352:8k_2_02:8]
Fourth quarter 2013 net income as reported in accordance with U.S. generally accepted accounting principles (GAAP) was $6.8 million, or $0.19 per diluted share. This compares to net income of $7.8 million, or $0.21 per diluted share, in the third quarter of 2013 and net income of $5.5 million, or $0.16 per diluted share, in the fourth quarter of 2012. For the year ended December 31, 2013, net income was $24.0 million, or $0.67 per diluted share. This compares to net income of $16.2 million, or $0.47 per diluted share, for the year ended December 31, 2012.

[0001104659-14-006352:8k_2_02:9]
Non-GAAP results: Non-GAAP net income was $10.5 million for the fourth quarter of 2013, or $0.29 per diluted share. Non-GAAP net income for the fourth quarter excludes $2.7 million of stock-based compensation expense, $1.0 million ($0.6 million net of the $0.4 million tax effect) of amortization expense for all intangible assets associated with acquisitions made by Omnicell in 2012 and earlier and $0.6 million ($0.4 million net of the $0.2 million tax effect) of non-recurring charges incurred in connection with the previously announced agreement to acquire Surgichem Limited, a wholly-owned subsidiary of Bupa Care Homes plc. This compares to non-GAAP net income of $8.6 million, or $0.25 per diluted share, for the fourth quarter of 2012. Non-GAAP net income for the fourth quarter of 2012 excluded $2.4 million of stock-based compensation expense and $1.1 million ($0.7 million net of the $0.4 million tax effect) of amortization expense for all intangible assets associated with acquisitions made by Omnicell in 2012 and earlier. Fourth quarter results compare to non-GAAP net income of $11.3 million, or $0.31 per diluted share, for the third quarter of 2013. Non-GAAP net income for the third quarter excluded $2.8 million of stock-based compensation expense and $1.1 million ($0.8 million net of $0.3 million tax effect) of amortization expense for all intangible assets associated with acquisitions made by Omnicell in 2012 and earlier.

[0001104659-14-006352:8k_2_02:10]
For the year ended December 31, 2013, non-GAAP net income was $38.6 million, or $1.08 per diluted share. Non-GAAP net income for the year ended December 31, 2013 excludes $11.2 million of stock-based compensation expense, $0.7 million ($0.4 million net of $0.3 million tax effect) of reorganization costs incurred in the first quarter of 2013 related to the integration of MTS Medication Technologies, $0.6 million ($0.4 million net of the $0.2 million tax effect) of non-recurring charges incurred in connection with the previously announced agreement to acquire Surgichem Limited, a wholly-owned subsidiary of Bupa Care Homes plc and $4.2 million ($2.7 million net of the $1.5 million tax effect) of amortization expense for all intangible assets associated with acquisitions made by Omnicell in 2012 and earlier. For the year ended December 31, 2012, non-GAAP net income was $29.8 million, or $0.87 per diluted share. Non-GAAP net income for the year ended December 31, 2012 excluded $9.2 million of stock-based compensation expense, $4.9 million of acquisition transaction and integration costs ($2.9 million net of the $2.0 million tax effect), and $2.7 million ($1.6 million net of the $1.1 million tax effect) of amortization expense for all intangible assets associated with acquisitions made by Omnicell in 2012 and earlier.

[0001104659-14-006352:8k_2_02:11]
“With a strong fourth quarter, Omnicell closed a fiscal 2013 that exceeded the high end of our guidance,” said Randall Lipps, president, CEO and chairman. “We are proud of the company’s performance. Omnicell achieved record revenues in the fourth quarter, and the full year 2013 was a record for both revenues and earnings.”

[0001104659-14-006352:8k_2_02:12]
“More telling is Omnicell’s growth over the past four years, in which we increased revenue over 75% and tripled our profit,” he added. “These are the results of successfully broadening our product portfolio, expanding the markets where we participate, and partnering with our customers to address medication management across the full continuum of patient care. We are well positioned to take advantage of the great opportunities ahead.”

[0001104659-14-006352:8k_2_02:13]
Omnicell Conference Call Information

[0001104659-14-006352:8k_2_02:14]
Omnicell will hold a conference call today at 2:30 p.m. PT to discuss fourth quarter financial results. The conference call can be monitored by dialing 1-866-830-5685 within the U.S. or 1-706-758-4883 for all other locations. The Conference ID # is 40292991. Internet users can access the conference call at http://ir.omnicell.com/events.cfm. A replay of the call will be available today at approximately 7:30 p.m. PT and will be available until 12:00 p.m. PT on February 28. The replay access numbers are 1-855-859-2056 within the U.S. and 1-404-537-3406 for all other locations, Conference ID # is 40292991.

[0001104659-14-006352:8k_2_02:15]
About Omnicell

[0001104659-14-006352:8k_2_02:16]
For over 20 years, the mission of Omnicell (NASDAQ: OMCL) has been creating new efficiencies to help improve patient care, anywhere it is delivered. Omnicell is a leading supplier of comprehensive automation and business analytics software solutions for patient-centric medication and supply management across the entire healthcare continuum, from the acute care hospital setting to post-acute skilled nursing and long-term care facilities to the home.

[0001104659-14-006352:8k_2_02:17]
Since 1992, more than 2,800 Acute Care customers worldwide have utilized Omnicell’s medication automation, supply chain and analytics solutions to enable them to increase operational efficiency, reduce errors, deliver actionable intelligence and improve patient safety. Omnicell Non-Acute Care solutions, including its MTS Medication Technologies brand, provide innovative medication adherence packaging solutions that can help reduce costly hospital readmissions and enable approximately 6,000 institutional and retail pharmacies worldwide to maintain high accuracy and quality standards in medication dispensing and administration while optimizing productivity and controlling costs.

[0001104659-14-006352:8k_2_02:18]
For more information about Omnicell, please visit www.omnicell.com.

[0001104659-14-006352:8k_2_02:19]
Forward-Looking Statements

[0001104659-14-006352:8k_2_02:20]
Use of Non-GAAP Financial Information

[0001104659-14-006352:8k_2_02:21]
This press release contains financial measures that are not calculated in accordance with U.S. generally accepted accounting principles (GAAP). Our management evaluates and makes operating decisions using various performance measures. In addition to Omnicell’s GAAP results, we also consider non-GAAP gross profit, non-GAAP operating expenses, non-GAAP net income, and non-GAAP net income per diluted share. Additionally, we calculate Adjusted EBITDA (another non-GAAP measure) by means of adjustments to GAAP Net Income. These non-GAAP results should not be considered as an alternative to gross profit, operating expenses, net income, net income per diluted share, or any other performance measure derived in accordance with GAAP. We present these non-GAAP results because we consider them to be important supplemental measures of Omnicell’s performance.

[0001104659-14-006352:8k_2_02:22]
Our non-GAAP gross profit, non-GAAP operating expenses, non-GAAP net income and non-GAAP net income per diluted share are exclusive of certain items to facilitate management’s review of the comparability of Omnicell’s core operating results on a period to period basis because such items are not related to Omnicell’s ongoing core operating results as viewed by management. We define our “core operating results” as those revenues recorded in a particular period and the expenses incurred within that period that directly drive operating income in that period. Management uses these non-GAAP financial measures in making operating decisions because, in addition to meaningful supplemental information regarding operating performance, the measures give us a better understanding of how we should invest in research and development, fund infrastructure growth and evaluate the effectiveness of marketing strategies. In calculating the above non-GAAP results, management specifically adjusted for the following excluded items:

[0001104659-14-006352:8k_2_02:23]
a)  Stock-based compensation expense impact of Accounting Standards Codification (ASC) 718. We recognize equity plan-related compensation expenses, which represent the fair value of all share-based payments to employees, including grants of employee stock options, as required under ASC 718, “Stock Compensation” as non-GAAP adjustments in each period.

[0001104659-14-006352:8k_2_02:24]
b)  Reorganization costs. During the year ended December 31, 2013, we recorded $0.7 million of reorganization costs related to our Non-Acute Care segment ($0.4 million net of the $0.3 million tax effect). This charge is not expected to be recurring and, as such, the financial impact is excluded from our non-GAAP results.

[0001104659-14-006352:8k_2_02:25]
c) Acquisition-related transaction and integration expenses. In connection with the previously announced agreement to acquire Surgichem Limited, we recorded $0.6 million of pre-acquisition costs ($0.4 million net of $0.2 million tax effect) in the fourth quarter of 2013.  In the second quarter of 2012, we recorded $4.9 million of acquisition-related transaction and integration costs ($2.9 million net of the $2.0 million tax effect). These charges are not expected to be recurring and, as such, the financial impact of these costs is excluded from our non-GAAP results.

[0001104659-14-006352:8k_2_02:26]
d)  Intangible assets amortization from business acquisitions. We excluded from our non-GAAP results the intangible assets amortization expense resulting from the MTS acquisition as well as earlier Omnicell acquisitions. This impacts the fourth quarter of fiscal 2013 non-GAAP results by $1.0 million ($0.6 million net of $0.4 million tax effect) and December 31, 2013 year-to-date non-GAAP results by $4.2 million ($2.7 million net of $1.5 million tax effect). This impacted December 31, 2012 fourth quarter results by $1.1 million ($0.7 million net of $0.4 million tax effect) and December 31, 2012 year-to-date results by $2.7 million ($1.6 million net of the $1.1 million tax effect).These non-cash charges are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results.

[0001104659-14-006352:8k_2_02:27]
Management adjusts for the above items because management believes that, in general, these items possess one or more of the following characteristics: their magnitude and timing is largely outside of Omnicell’s control; they are unrelated to the ongoing operation of the business in the ordinary course; they are unusual and we do not expect them to occur in the ordinary course of business; or they are non-operational, or non-cash expenses involving stock option grants.

[0001104659-14-006352:8k_2_02:28]
We believe that the presentation of these non-GAAP financial measures is warranted for several reasons:

[0001104659-14-006352:8k_2_02:29]
1) Such non-GAAP financial measures provide an additional analytical tool for understanding Omnicell’s financial performance by excluding the impact of items which may obscure trends in the core operating results of the business;

[0001104659-14-006352:8k_2_02:30]
2) Since we have historically reported non-GAAP results to the investment community, we believe the inclusion of non-GAAP numbers provides consistency and enhances investors’ ability to compare our performance across financial reporting periods;

[0001104659-14-006352:8k_2_02:31]
3) These non-GAAP financial measures are employed by Omnicell’s management in its own evaluation of performance and are utilized in financial and operational decision making processes, such as budget planning and forecasting; and

[0001104659-14-006352:8k_2_02:32]
4) These non-GAAP financial measures facilitate comparisons to the operating results of other companies in our industry, which use similar financial measures to supplement their GAAP results, thus enhancing the perspective of investors who wish to utilize such comparisons in their analysis of our performance.

[0001104659-14-006352:8k_2_02:33]
Set forth below are additional reasons why share-based compensation expense related to ASC 718 is excluded from our non-GAAP financial measures:

[0001104659-14-006352:8k_2_02:34]
i)  While share-based compensation calculated in accordance with ASC 718 constitutes an ongoing and recurring expense of Omnicell, it is not an expense that requires cash settlement by Omnicell. We therefore exclude these charges for purposes of evaluating core operating results. Thus, our non-GAAP measurements are presented exclusive of stock-based compensation expense to assist management and investors in evaluating our core operating results.

[0001104659-14-006352:8k_2_02:35]
ii)  We present ASC 718 share-based payment compensation expense in our reconciliation of non-GAAP financial measures on a pre-tax basis because the exact tax differences related to the timing and deductibility of share-based compensation, under ASC 718 are dependent upon the trading price of Omnicell’s common stock and the timing and exercise by employees of their stock options. As a result of these timing and market uncertainties the tax effect related to share-based compensation expense would be inconsistent in amount and frequency and is therefore excluded from our non-GAAP results.

[0001104659-14-006352:8k_2_02:36]
Our Adjusted EBITDA calculation is defined as earnings before interest income and expense, taxes, depreciation and amortization, and non-cash expenses, including ASC 718 stock compensation expense, as well as excluding certain non-GAAP adjustments.

[0001104659-14-006352:8k_2_02:37]
As stated above, we present non-GAAP financial measures because we consider them to be important supplemental measures of performance. However, non-GAAP financial measures have limitations as an analytical tool and should not be considered in isolation or as a substitute for Omnicell’s GAAP results. In the future, we expect to incur expenses similar to certain of the non-GAAP adjustments described above and expect to continue reporting non-GAAP financial measures excluding such items. Some of the limitations in relying on non-GAAP financial measures are:

[0001104659-14-006352:8k_2_02:38]
· Omnicell’s stock option and stock purchase plans are important components of incentive compensation arrangements and will be reflected as expenses in Omnicell’s GAAP results for the foreseeable future under ASC 718.

[0001104659-14-006352:8k_2_02:39]
· Other companies, including companies in Omnicell’s industry, may calculate non-GAAP financial measures differently than Omnicell, limiting their usefulness as a comparative measure.

[0001104659-14-006352:8k_2_02:40]
Pursuant to the requirements of SEC Regulation G, a detailed reconciliation between Omnicell’s non-GAAP and GAAP financial results is set forth in the financial tables at the end of this press release. Investors are advised to carefully review and consider this information strictly as a supplement to the GAAP results that are contained in this press release and in Omnicell’s SEC filings.

[0001104659-14-006352:8k_2_02:41]
Omnicell, Inc.

[0001104659-14-006352:8k_2_02:42]
Condensed Consolidated Statements of Operations

[0001104659-14-006352:8k_2_02:43]
(In thousands, except per share data, unaudited)

[0001104659-14-006352:8k_2_02:44]
|  |  | Three Months Ended |  | Year Ended |  |
|  |  | December 31, 2013 |  | September 30, 2013 |  | December 31, 2012 |  | December 31, 2013 |  | December 31, 2012 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 86,864 |  | $ | 75,508 |  | $ | 72,415 |  | $ | 307,189 |  | $ | 247,654 |  |
| Services and other revenues |  | 18,886 |  | 18,531 |  | 17,754 |  | 73,396 |  | 66,373 |  |
| Total revenue |  | 105,750 |  | 94,039 |  | 90,169 |  | 380,585 |  | 314,027 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product revenues |  | 41,187 |  | 33,977 |  | 32,837 |  | 144,997 |  | 112,369 |  |
| Cost of services and other revenues |  | 7,939 |  | 8,022 |  | 7,956 |  | 32,189 |  | 31,070 |  |
| Total cost of revenues |  | 49,126 |  | 41,999 |  | 40,793 |  | 177,186 |  | 143,439 |  |
| Gross profit |  | 56,624 |  | 52,040 |  | 49,376 |  | 203,399 |  | 170,588 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  | 7,440 |  | 6,561 |  | 6,188 |  | 29,105 |  | 23,726 |  |
| Selling, general and administrative |  | 38,129 |  | 34,762 |  | 33,354 |  | 138,995 |  | 119,736 |  |
| Total operating expenses |  | 45,569 |  | 41,323 |  | 39,542 |  | 168,100 |  | 143,462 |  |
| Income from operations |  | 11,055 |  | 10,717 |  | 9,834 |  | 35,299 |  | 27,126 |  |
| Other income and (expense), net |  | (136 | ) | 25 |  | (108 | ) | (270 | ) | (51 | ) |
| Income before provision for income taxes |  | 10,919 |  | 10,742 |  | 9,726 |  | 35,029 |  | 27,075 |  |
| Provision for income taxes |  | 4,096 |  | 2,987 |  | 4,194 |  | 11,050 |  | 10,897 |  |
| Net income |  | $ | 6,823 |  | $ | 7,755 |  | $ | 5,532 |  | $ | 23,979 |  | $ | 16,178 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.19 |  | $ | 0.22 |  | $ | 0.17 |  | $ | 0.69 |  | $ | 0.49 |  |
| Diluted |  | $ | 0.19 |  | $ | 0.21 |  | $ | 0.16 |  | $ | 0.67 |  | $ | 0.47 |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | 35,495 |  | 35,133 |  | 33,282 |  | 34,736 |  | 33,307 |  |
| Diluted |  | 36,610 |  | 36,190 |  | 34,128 |  | 35,774 |  | 34,213 |  |

[0001104659-14-006352:8k_2_02:45]
Omnicell, Inc.

[0001104659-14-006352:8k_2_02:46]
Condensed Consolidated Balance Sheets

[0001104659-14-006352:8k_2_02:47]
(In thousands)

[0001104659-14-006352:8k_2_02:48]
|  |  | December 31, |  | December 31, |  |
|  |  | 2013 |  | 2012 |  |
|  |  | (unaudited) |  | (1) |  |
| ASSETS |  |  |  |  |  |
| Current assets: |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 104,531 |  | $ | 62,313 |  |
| Accounts receivable, net |  | 58,597 |  | 55,116 |  |
| Inventories |  | 31,457 |  | 26,903 |  |
| Prepaid expenses |  | 18,883 |  | 15,392 |  |
| Deferred tax assets |  | 12,635 |  | 11,860 |  |
| Other current assets |  | 7,674 |  | 9,172 |  |
| Total current assets |  | 233,777 |  | 180,756 |  |
| Property and equipment, net |  | 35,254 |  | 34,107 |  |
| Non-current net investment in sales-type leases |  | 11,485 |  | 13,228 |  |
| Goodwill |  | 111,343 |  | 111,407 |  |
| Other intangible assets |  | 81,602 |  | 85,550 |  |
| Non-current deferred tax assets |  | 1,102 |  | 993 |  |
| Other assets |  | 17,938 |  | 15,778 |  |
| Total assets |  | $ | 492,501 |  | $ | 441,819 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |
| Accounts payable |  | $ | 16,471 |  | $ | 18,255 |  |
| Accrued compensation |  | 20,266 |  | 11,613 |  |
| Accrued liabilities |  | 13,746 |  | 11,988 |  |
| Deferred service revenue |  | 22,626 |  | 20,449 |  |
| Deferred gross profit |  | 19,957 |  | 20,772 |  |
| Total current liabilities |  | 93,066 |  | 83,077 |  |
| Non-current deferred service revenue |  | 17,763 |  | 19,892 |  |
| Non-current deferred tax liabilities |  | 28,162 |  | 26,491 |  |
| Other long-term liabilities |  | 5,176 |  | 4,809 |  |
| Total liabilities |  | 144,167 |  | 134,269 |  |
| Stockholders’ equity: |  |  |  |  |  |
| Total stockholders’ equity |  | 348,334 |  | 307,550 |  |
| Total liabilities and stockholders’ equity |  | $ | 492,501 |  | $ | 441,819 |  |

[0001104659-14-006352:8k_2_02:49]
(1)    Information derived from our December 31, 2012 audited Consolidated Financial Statements.

[0001104659-14-006352:8k_2_02:50]
Omnicell, Inc.

[0001104659-14-006352:8k_2_02:51]
Reconciliation of GAAP to Non-GAAP

[0001104659-14-006352:8k_2_02:52]
(In thousands, except per share data, unaudited)

[0001104659-14-006352:8k_2_02:53]
|  |  | Three months ended |  |
|  |  | December 31, 2013 |  | September 30, 2013 |  | December 31, 2012 |  |
|  |  | Net income |  | Net income per share- diluted |  | Net income |  | Net income per share- diluted |  | Net income |  | Net income per share- diluted |  |
| GAAP |  | $ | 6,823 |  | $ | 0.19 |  | $ | 7,755 |  | $ | 0.21 |  | $ | 5,532 |  | $ | 0.16 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Pre-acquisition, transaction and integration costs for acquisitions |  | 605 |  |  |  | — |  |  |  | — |  |  |  |
| Amortization of intangible assets acquired by acquisition |  | 1,049 |  |  |  | 1,060 |  |  |  | 1,057 |  |  |  |
| Subtotal pretax adjustments |  | 1,654 |  |  |  | 1,060 |  |  |  | 1,057 |  |  |  |
| Income tax effect of non-GAAP adjustments (a) |  | (662 | ) |  |  | (295 | ) |  |  | (423 | ) |  |  |
| Subtotal after-tax adjustments |  | 992 |  |  |  | 765 |  |  |  | 634 |  |  |  |
| ASC 718 share-based compensation adjustment (b) |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gross profit |  | 287 |  |  |  | 325 |  |  |  | 236 |  |  |  |
| Operating expenses |  | 2,442 |  |  |  | 2,485 |  |  |  | 2,197 |  |  |  |
| Total after-tax adjustments |  | 3,721 |  | 0.10 |  | 3,575 |  | 0.10 |  | 3,067 |  | 0.09 |  |
| Non-GAAP |  | $ | 10,544 |  | $ | 0.29 |  | $ | 11,330 |  | $ | 0.31 |  | $ | 8,599 |  | $ | 0.25 |  |

[0001104659-14-006352:8k_2_02:54]
(a)         Tax effects are calculated using the effective tax rates for the respective periods presented.

[0001104659-14-006352:8k_2_02:55]
(b)         This adjustment reflects the accounting impact of non-cash stock-based compensation expense related to the impact of ASC 718 for the periods shown.

[0001104659-14-006352:8k_2_02:56]
Omnicell, Inc.

[0001104659-14-006352:8k_2_02:57]
Reconciliation of GAAP to Non-GAAP

[0001104659-14-006352:8k_2_02:58]
(In thousands, except per share data, unaudited)

[0001104659-14-006352:8k_2_02:59]
|  |  | Year Ended |  |
|  |  | December 31, 2013 |  | December 31, 2012 |  |
|  |  | Net income |  | Net income per share- diluted |  | Net income |  | Net income per share- diluted |  |
| GAAP |  | $ | 23,979 |  | $ | 0.67 |  | $ | 16,161 |  | $ | 0.47 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |
| Business acquisition costs |  |  |  |  |  |  |  |  |  |
| Reorganization costs (a) |  | 732 |  |  |  | — |  |  |  |
| Pre-acquisition, transaction and integration costs for acquisitions (b) |  | 605 |  |  |  | 4,855 |  |  |  |
| Amortization of intangible assets acquired by acquisition (c) |  | 4,229 |  |  |  | 2,672 |  |  |  |
| Subtotal pretax adjustments |  | 5,566 |  |  |  | 7,527 |  |  |  |
| Income tax effect of non-GAAP adjustments (d) |  | (2,057 | ) |  |  | (3,086 | ) |  |  |
| Subtotal after-tax adjustments |  | 3,509 |  |  |  | 4,441 |  |  |  |
| ASC 718 share-based compensation adjustment (e) |  |  |  |  |  |  |  |  |  |
| Gross profit |  | 1,241 |  |  |  | 1,012 |  |  |  |
| Operating expenses |  | 9,911 |  |  |  | 8,202 |  |  |  |
| Total after tax adjustments |  | 14,661 |  | 0.41 |  | 13,655 |  | 0.40 |  |
| Non-GAAP |  | $ | 38,640 |  | $ | 1.08 |  | $ | 29,816 |  | $ | 0.87 |  |

[0001104659-14-006352:8k_2_02:60]
(a)         This adjustment is for reorganization costs related to our Non-Acute Care segment for the twelve months ended December 31, 2013.

[0001104659-14-006352:8k_2_02:61]
(b)         This adjustment is for the incurrence of pre-acquisition costs related to our previously announced agreement to acquire Surgichem Limited in December 2013 and transaction and integration costs related to our acquisition of MTS in May 2012.

[0001104659-14-006352:8k_2_02:62]
(c)          Beginning with the second quarter of 2012, we are recognizing the amortization expense resulting from certain intangible assets recorded from business acquisitions as a non-GAAP adjustment, including MTS and prior acquisitions.

[0001104659-14-006352:8k_2_02:63]
(d)         Tax effects are calculated using the effective tax rates for the respective periods presented.

[0001104659-14-006352:8k_2_02:64]
(e)          This adjustment reflects the accounting impact of non-cash stock-based compensation expense related to the impact of ASC 718 for the periods shown.

[0001104659-14-006352:8k_2_02:65]
Omnicell, Inc.

[0001104659-14-006352:8k_2_02:66]
Calculation of Adjusted EBITDA (1)

[0001104659-14-006352:8k_2_02:67]
(In thousands, unaudited)

[0001104659-14-006352:8k_2_02:68]
|  |  | Three Months Ended |  | Year ended |  |
|  |  | December 31, 2013 |  | September 30, 2013 |  | December 31, 2012 |  | December 31, 2013 |  | December 31, 2012 |  |
| GAAP net income |  | $ | 6,823 |  | $ | 7,755 |  | $ | 5,532 |  | $ | 23,979 |  | $ | 16,161 |  |
| Add back: |  |  |  |  |  |  |  |  |  |  |  |
| ASC 718 stock compensation expense |  | 2,729 |  | 2,810 |  | 2,433 |  | 11,152 |  | 9,214 |  |
| Reorganization costs |  | — |  | — |  | — |  | 732 |  | — |  |
| Transaction and integration costs for acquisitions, pre-tax |  | 605 |  | — |  | — |  | 605 |  | 4,855 |  |
| Interest |  | 7 |  | (14 | ) | (2 | ) | 92 |  | (48 | ) |
| Depreciation and amortization expense |  | 4,633 |  | 4,488 |  | 4,077 |  | 18,365 |  | 13,323 |  |
| Income tax expense |  | 4,096 |  | 2,987 |  | 4,168 |  | 11,050 |  | 10,871 |  |
| Non-GAAP adjusted EBITDA (1) |  | $ | 18,893 |  | $ | 18,025 |  | $ | 16,208 |  | $ | 65,975 |  | $ | 54,376 |  |

[0001104659-14-006352:8k_2_02:69]
(1)         Defined as earnings before interest income and expense, taxes, depreciation and amortization, and non-cash expenses, including stock compensation expense, per ASC 718, as well as excluding certain non-GAAP adjustments. The non-GAAP adjustments for the twelve months ended December 31, 2013 and 2012 exclude transaction and integration costs for MTS, acquired in May 2012.
