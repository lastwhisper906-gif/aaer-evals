# OMCL notes — 0000926326-23-000003


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000926326-23-000003:notes:1]
Portions of the registrant’s definitive Proxy Statement for the 2023 Annual Meeting of Stockholders to be filed with the United States Securities and Exchange Commission pursuant to Regulation 14A not later than 120 days after the end of the fiscal year covered by this Form 10-K are incorporated by reference in Part III, Items 10-14 of this Form 10-K.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000926326-23-000003:notes:2]
Organization and Summary of Significant Accounting Policies
Business

[0000926326-23-000003:notes:3]
Omnicell, Inc. was incorporated in California in 1992 under the name Omnicell Technologies, Inc. and reincorporated in Delaware in 2001 as Omnicell, Inc. The Company’s major products and related services are medication management solutions and adherence tools for healthcare systems and pharmacies, which are sold in its principal market, the healthcare industry. The Company’s market is primarily located in the United States and Europe. “Omnicell” or the “Company” refer to Omnicell, Inc. and its subsidiaries, collectively.

[0000926326-23-000003:notes:4]
Basis of Presentation

[0000926326-23-000003:notes:5]
The accompanying Consolidated Financial Statements have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) and include all adjustments necessary for the fair presentation of the Company’s consolidated financial position, results of operations, and cash flows for the periods presented.

[0000926326-23-000003:notes:6]
Principles of Consolidation

[0000926326-23-000003:notes:7]
The Consolidated Financial Statements include the accounts of the Company and its wholly-owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.

[0000926326-23-000003:notes:8]
On January 10, 2022, the Company completed its acquisition of Hub and Spoke Innovations Limited (“Hub and Spoke Innovations”). The Consolidated Financial Statements include the results of operations of this recently acquired company, commencing as of the acquisition date. The significant accounting policies of the acquired business have been aligned to conform to the accounting policies of Omnicell.

[0000926326-23-000003:notes:9]
Use of Estimates

[0000926326-23-000003:notes:10]
The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s Consolidated Financial Statements and accompanying Notes. These estimates are based on historical experience and various other assumptions that management believes to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. The Company’s critical accounting policies are those that affect its financial statements materially and involve difficult, subjective, or complex judgments by management. Those policies are revenue recognition; allowance for credit losses for accounts receivable and unbilled receivables; notes receivable from investment in sales-type leases; operating lease right-of-use assets and liabilities; inventory valuation; capitalized software development costs for internal and external use; impairment of goodwill; purchased intangibles and long-lived assets; fair value of assets acquired and liabilities assumed in business combinations; share-based compensation; and accounting for income taxes. As of December 31, 2022, the Company is not aware of any events or circumstances that would require an update to its estimates, judgments, or revisions to the carrying value of its assets or liabilities.

[0000926326-23-000003:notes:11]
Segment Reporting

[0000926326-23-000003:notes:12]
The Company manages its operations as a single segment for the purposes of assessing performance and making operating decisions. The Company’s Chief Operating Decision Maker (“CODM”) is its Chief Executive Officer. The CODM allocates resources and evaluates the performance of the Company at the consolidated level using information about its revenues, gross profit, income from operations, and other key financial data. All significant operating decisions are based upon an analysis of the Company as one operating segment, which is the same as its reporting segment.

[0000926326-23-000003:notes:13]
Foreign Currency Translation and Remeasurement

[0000926326-23-000003:notes:14]
Most of the Company’s foreign subsidiaries use the local currency of their respective countries as their functional currency. The Company translates the assets and liabilities of such non-U.S. dollar functional currency subsidiaries into U.S. dollars using exchange rates in effect at the end of each period. Revenue and expenses for these subsidiaries are translated using rates that approximate those in effect during the period. Gains and losses from these translations are recorded as foreign currency translation adjustments and included in accumulated other comprehensive income (loss) in stockholders’ equity.

[0000926326-23-000003:notes:15]
Assets and liabilities denominated in a currency other than the functional currency are remeasured into the respective entity’s functional currency. Monetary assets and liabilities are remeasured at exchange rates in effect at the end of each period,

[0000926326-23-000003:notes:16]
and non-monetary assets and liabilities are remeasured at historical rates. Gains and losses from foreign currency remeasurement of monetary assets and liabilities are recorded in interest and other income (expense), net.

[0000926326-23-000003:notes:17]
Revenue Recognition

[0000926326-23-000003:notes:18]
The Company earns revenues from sales of its products and related services, which are sold in the healthcare industry, its principal market. The Company’s customer arrangements typically include one or more of the following revenue categories:

[0000926326-23-000003:notes:19]
Connected devices, software licenses, and other. Software-enabled connected devices and software licenses that manage and regulate the storage and dispensing of pharmaceuticals, consumables blister cards, and packaging equipment and other supplies. This revenue category is often sold through long-term, sole-source agreements. Solutions in this category include, but are not limited to, XT Series automated dispensing systems and products related to the Central Pharmacy Dispensing Service and IV Compounding Service.

[0000926326-23-000003:notes:20]
Consumables. Medication adherence packaging, labeling, and other one-time use packaging including multimed adherence packaging and single dose blister cards, which are used by retail, community, and outpatient pharmacies, as well as by institutional pharmacies serving long-term care and other sites outside the acute care hospital, are designed to improve patient engagement and adherence to prescriptions.

[0000926326-23-000003:notes:21]
Technical services. Post-installation technical support and other related services, including phone support, on-site service, parts, and access to unspecified software updates and enhancements, if and when available. This revenue category is often supported by multi-year or annual contractual agreements.

[0000926326-23-000003:notes:22]
Advanced Services. Emerging software and service solutions which are offered on a subscription basis with fees typically based either on transaction volume or a fee over a specified period of time. Solutions in this category include, but are not limited to, EnlivenHealth, Specialty Pharmacy Services, 340B solutions, Inventory Optimization Service, other software solutions, and services related to the Central Pharmacy Dispensing Service and IV Compounding Service.

[0000926326-23-000003:notes:23]
The following table summarizes revenue recognition for each revenue category:

[0000926326-23-000003:notes:24]
| Revenue Category |  |  |  | Timing of Revenue Recognition |  | Income Statement Classification |
| Connected devices, software licenses, and other |  |  |  | Point in time, as transfer of control occurs, generally upon installation and acceptance by the customer |  | Product |
| Consumables |  |  |  | Point in time, as transfer of control occurs, generally upon shipment to or receipt by customer |  | Product |
| Technical services |  |  |  | Over time, as services are provided, typically ratably over the service term |  | Service |
| Advanced Services |  |  |  | Over time, as services are provided |  | Service |

[0000926326-23-000003:notes:25]
Prior to recognizing revenue, the Company identifies the contract, performance obligations, and transaction price, and allocates the transaction price to the performance obligations. All identified contracts meet the following required criteria:

[0000926326-23-000003:notes:26]
Parties to the contract have approved the contract (in writing, orally, or in accordance with other customary business practices) and are committed to perform their respective obligations. A majority of the Company’s contracts are evidenced by a non-cancelable written agreement. Contracts for consumable products are generally evidenced by an order placed via phone or a purchase order.

[0000926326-23-000003:notes:27]
Entity can identify each party’s rights regarding the goods or services to be transferred. Contract terms are documented within the written agreements. Where a written contract does not exist, such as for consumable products, the rights of each party are understood as following the Company’s standard business process and terms.

[0000926326-23-000003:notes:28]
The entity can identify the payment terms for the goods or services to be transferred. Payment terms are documented within the agreement and are generally net 30 to 60 days from shipment of tangible product or services performed for customers in the United States. Where a written contract does not exist, the Company’s standard payment terms are net 30 day terms.

[0000926326-23-000003:notes:29]
The contract has commercial substance (that is the risk, timing, or amount of the entity’s future cash flows is expected to change as a result of the contract). The Company’s agreements are an exchange of cash for a combination of products and services which result in changes in the amount of the Company’s future cash flows.

[0000926326-23-000003:notes:30]
It is probable the entity will collect the consideration to which it will be entitled in exchange for the goods or services that will be transferred to the customer. The Company performs a credit check for all significant customers or transactions and where collectability is not probable, payment in full or a substantial down payment prior to shipment is typically required to help ensure the full agreed upon contract price will be collected.

[0000926326-23-000003:notes:31]
Distinct goods or services are identified as performance obligations. A series of distinct goods or services that are substantially the same and that have the same pattern of transfer to the customer are considered a single performance obligation. Where a good or service is determined not to be distinct, the Company combines the good or service with other promised goods or services until a bundle of goods or services that is distinct is identified. To identify its performance obligations, the Company considers all products or services promised in the contract regardless of whether they are explicitly stated or are implied by customary business practices. When performance obligations are included in separate contracts, the Company considers an entire customer arrangement to determine if separate contracts should be considered combined for the purposes of revenue recognition. Most of the Company’s sales, other than renewals of support and maintenance, contain multiple performance obligations, with a combination of hardware systems, software products, consumables, support and maintenance, and professional services.

[0000926326-23-000003:notes:32]
The transaction price of a contract is determined based on the fixed consideration, net of an estimate for variable consideration such as various discounts or rebates provided to customers. As a result of the Company’s commercial selling practices, contract prices are generally fixed with minimal, if any, variable consideration.

[0000926326-23-000003:notes:33]
The transaction price is allocated to separate performance obligations proportionally based on the standalone selling price of each performance obligation. Standalone selling price is best evidenced by the price the Company charges for the good or service when selling it separately in similar circumstances to similar customers. Other than for the renewal of annual support services contracts, the Company’s products and services are not generally sold separately. The Company uses an amount discounted from the list price as a best estimated selling price.

[0000926326-23-000003:notes:34]
The Company recognizes revenue when the performance obligation has been satisfied by transferring a promised good or service to a customer. The good or service is transferred when or as the customer obtains control of the good or service. Determining when control transfers requires management to make judgments that affect the timing of revenues recognized. Generally, for products requiring a complex implementation, control passes when the product is installed and ready for use. For all other products, control generally passes when product has been shipped and title has passed. For maintenance contracts and certain other services, including Advanced Services provided on a subscription basis, control passes to the customer over time, generally ratably over the service term as the Company provides a stand-ready service for the customer’s equipment. Time and material services transfer control to the customer at the time the services are provided. The portion of the transaction price allocated to the Company’s unsatisfied performance obligations recorded as deferred revenues, net of deferred cost of goods sold, at December 31, 2022 and 2021 were $156.3 million and $132.4 million, respectively, of which $118.9 million and $112.2 million, respectively, are expected to be completed within one year and are presented as current deferred revenues, net on the Consolidated Balance Sheets. Remaining performance obligations are primarily recognized ratably over the remaining term of the contract, generally not more than ten years.

[0000926326-23-000003:notes:35]
Revenues, contract assets, and contract liabilities are recorded net of associated taxes.

[0000926326-23-000003:notes:36]
The Company generally invoices customers for products upon shipment. Invoicing associated with the service portion of agreements are generally periodic and are billed on a monthly, quarterly, or annual basis. In certain circumstances, multiple years are billed at one time.

[0000926326-23-000003:notes:37]
The amount invoiced for equipment and software is typically reflected in both accounts receivable and deferred revenues, net. The Company typically recognizes product revenue, and correspondingly reduces deferred revenues, net, for equipment and on-premise software upon written customer acceptance of installation. Consumables are recorded as revenue upon shipment to or receipt by the customer, depending upon contract terms. The portion of deferred revenues, net, not expected to be recognized as revenue within twelve months of the balance sheet date are included in long-term deferred revenues on the Consolidated Balance Sheets.

[0000926326-23-000003:notes:38]
From time to time, the Company enters into change orders which modify the product to be received by the customer pursuant to certain contracts. Changes to any contract are accounted for as a modification of the existing contract to the extent the goods and services to be delivered as part of the contract are generally consistent with the nature and type of those to be provided under the terms of the original contract. Examples of such change orders include the addition or removal of units of equipment or changes to the configuration of the equipment where the overall nature of the contract remains intact. The Company’s change orders generally result in the change being accounted for as modifications of existing contracts given the nature of the impacted orders.

[0000926326-23-000003:notes:39]
In the normal course of business, the Company typically does not accept product returns unless the item is defective as manufactured or the configuration of the product is incorrect. The Company establishes provisions for estimated returns based on historical product returns. The allowance for sales returns is not material to the Consolidated Financial Statements for any periods presented.

[0000926326-23-000003:notes:40]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”), each of which functions as a purchasing agent on behalf of member hospitals and other healthcare providers. The Company also has a Federal Supply Schedule Contract with the Department of Veterans Affairs (the “GSA Contract”), allowing the Department of Veterans Affairs, the Department of Defense, and other Federal government customers to purchase the Company’s products. Pursuant to the terms of GPO agreements and the GSA Contract, each member or agency contracts directly with Omnicell and can purchase the Company’s products at pre-negotiated contract terms and pricing. GPOs are often fully or partially owned by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company also pays the Industrial Funding Fee (“IFF”) to the Department of Veterans Affairs under the GSA Contract. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs and the IFF were $17.6 million, $17.5 million, and $9.7 million for the years ended December 31, 2022, 2021, and 2020, respectively. The accounts receivable balances are with individual members of the GPOs and Federal agencies that purchase under the GSA Contract, and therefore no significant concentration of credit risk exists. During the year ended December 31, 2022, sales to members of the ten largest GPOs and Federal agencies that purchase under the GSA Contract accounted for approximately 68% of the Company’s total consolidated revenues.

[0000926326-23-000003:notes:41]
Contract Assets and Contract Liabilities

[0000926326-23-000003:notes:42]
A contract asset is a right to consideration in exchange for goods or services that the Company has transferred to a customer when that right is conditional and is not just subject to the passage of time. A receivable will be recorded on the balance sheet when the Company has unconditional rights to consideration. A contract liability is an obligation to transfer goods or services for which the Company has received consideration, or for which an amount of consideration is due from the customer. Contract liabilities include customer deposits under non-cancelable contracts, and current and non-current deferred revenue balances. The Company’s contract balances are reported in a net contract asset or liability position on a contract-by-contract basis at the end of each reporting period.

[0000926326-23-000003:notes:43]
Significant changes in the contract assets and the contract liabilities balances during the period are the result of the issuance of invoices and recognition of deferred revenues in the normal course of business. The contract modifications entered into during the year ended December 31, 2022 did not have a significant impact on the Company’s contract assets or deferred revenues.

[0000926326-23-000003:notes:44]
Contract Costs

[0000926326-23-000003:notes:45]
The Company has determined that certain incentive portions of its sales commission plans require capitalization since these payments are directly related to sales achieved during a time period. These commissions are earned on the basis of: (i) the  value of new bookings for connected devices, software products, and Advanced Services, provided that for Advanced Services a commission will only be paid on the amount that represents the minimum commitment and (ii) the value of new orders for consumables. Since there are no commensurate commissions earned on renewal of the service bookings, the Company concluded that the capitalized asset is related to services provided under both the initial contract and renewal periods. The Company applies a practical expedient to account for the incremental costs of obtaining a contract as part of a portfolio of contracts with similar characteristics as the Company expects the effect on the financial statements of applying the practical expedient would not differ materially from applying the accounting guidance to the individual contracts within the portfolio. A pool of contracts is defined as all contracts booked in a particular quarter. The amortization for the capitalized asset is an estimate of the pool’s original contract term, generally one to five years, plus an estimate of future customer renewal periods resulting in a total amortization period of ten years. Costs to obtain a contract are allocated amongst performance obligations and recognized as sales and marketing expense consistent with the pattern of revenue recognition. In accordance with GAAP, while certain compensation elements are expensed as incurred, a portion of the pool’s capitalized asset is recorded as an expense over the first seven quarters after booking, which represents the estimated period during which the product revenue associated with the contract is recorded. The remaining capitalized contract costs are recorded as expense ratably over the ten year estimated initial and renewal service periods. The Company recognized contract cost expense of $30.6 million, $25.8 million, and $22.1 million during the years ended December 31, 2022, 2021, and 2020, respectively. The commission expenses paid or due to be paid as of the consolidated balance sheet date to be recognized in future periods are recorded in long-term prepaid commissions on the Consolidated Balance Sheets. Capitalized costs are periodically reviewed for impairment. There was no impairment loss recorded related to capitalized prepaid commissions as of and for the year ended December 31, 2022.

[0000926326-23-000003:notes:46]
Lessor Leases

[0000926326-23-000003:notes:47]
The Company determines if an arrangement is a lease at inception. The transaction price is allocated to separate performance obligations, generally consisting of a combination of hardware systems, software products, support and maintenance, and professional services, proportionally based on the standalone selling price of each performance obligation. Standalone selling price is best evidenced by the price the Company charges for the good or service when selling it separately in similar circumstances to similar customers. Other than for the renewal of annual support services contracts, the Company’s products and services are not generally sold separately. The Company uses an amount discounted from the list price as a best estimated selling price.

[0000926326-23-000003:notes:48]
Sales-Type Leases

[0000926326-23-000003:notes:49]
The Company enters into non-cancelable sales-type lease arrangements, most of which do not have an option to extend the lease term. At the end of the lease term, the customer must either return the equipment or negotiate a new agreement, resulting in a new purchase or lease transaction. Failure of the customer to either return the equipment or negotiate a new agreement results in the contract becoming a month-to-month rental. Certain sales-type leases automatically renew for successive one-year periods at the end of each lease term without written notice from the customer. The Company’s sales-type lease agreements do not contain any material residual value guarantees.

[0000926326-23-000003:notes:50]
For sales-type leases, the Company recognizes revenues for its hardware and software products, net of lease execution costs, post-installation product maintenance, and technical support, at the net present value of the lease payment stream upon customer acceptance. The Company recognizes service revenues associated with sales-type leases ratably over the term of the agreement in service revenues in the Consolidated Statements of Operations. The Company recognizes interest income from sales-type leases using the effective interest method. Both hardware and software revenues, and interest income from sales-types leases are recorded in product revenues in the Consolidated Statements of Operations.

[0000926326-23-000003:notes:51]
The Company optimizes cash flows by selling a majority of its non-U.S. government sales-type leases, other than Advanced Services sales-type leases, to third-party leasing finance companies on a non-recourse basis. The Company has no obligation to the leasing company once the lease has been sold. Some of the Company’s sales-type leases, mostly those relating to U.S. government hospitals which comprise approximately 38% of the lease receivable balance, and those associated with financed service contracts related to certain Advanced Services products, including Central Pharmacy Dispensing Service and IV Compounding Service, are retained in-house.

[0000926326-23-000003:notes:52]
Operating Leases

[0000926326-23-000003:notes:53]
The Company entered into certain leasing agreements that were classified as operating leases prior to the adoption of Accounting Standards Codification (“ASC”) 842, Leases. Those agreements in place prior to January 1, 2019 continue to be treated as operating leases, however, any leasing agreements entered into on or after January 1, 2019 under these programs are classified and accounted for as sales-type leases in accordance with ASC 842. The operating lease arrangements entered into prior to January 1, 2019 are non-cancelable, and most automatically renew for successive one-year periods at the end of each lease term absent written notice from the customer. The Company’s operating lease agreements do not contain any material residual value guarantees.

[0000926326-23-000003:notes:54]
For operating leases, rental income is generally recognized on a straight-line basis over the term of the associated lease, and recorded in services and other revenues in the Consolidated Statements of Operations. Leased assets under operating leases are carried at amortized cost net of accumulated depreciation in property and equipment, net on the Consolidated Balance Sheets. The depreciation expense of the leased assets is recognized on a straight-line basis over the contractual term of the associated lease, and recorded in cost of revenues in the Consolidated Statements of Operations.

[0000926326-23-000003:notes:55]
Allowance for Credit Losses

[0000926326-23-000003:notes:56]
The Company is exposed to credit losses primarily through sales of its products and services, as well as its sales-type leasing arrangements. The Company performs credit evaluations of its customers’ financial condition in order to assess each customer’s ability to pay. These evaluations require significant judgment and are based on a variety of factors including, but not limited to, current economic trends, payment history, and a financial review of the customer. The Company continues to monitor customers’ creditworthiness on an ongoing basis.

[0000926326-23-000003:notes:57]
The Company maintains an allowance for credit losses for accounts receivable, unbilled receivables, and net investment in sales-type leases based on expected credit losses resulting from the inability of its customers to make required payments. The allowance for credit losses is measured using a loss rate method, considering factors such as customers’ credit risk, historical loss experience, current conditions, and forecasts. The allowance for credit losses is measured on a collective (pool) basis by aggregating customer balances with similar risk characteristics. The Company also records a specific allowance

[0000926326-23-000003:notes:58]
based on an analysis of individual past due balances or customer-specific information, such as a decline in creditworthiness or bankruptcy. Actual collection losses may differ from management’s estimates, and such differences could be material to the Company’s financial position and results of operations.

[0000926326-23-000003:notes:59]
The allowance for credit losses is presented in the Consolidated Balance Sheets as a deduction from the respective asset balance. As of December 31, 2022 and 2021, the allowance for credit losses for long-term unbilled receivables and net investment in sales-type leases were not material.

[0000926326-23-000003:notes:60]
Funds Held for Customers and Customer Fund Liabilities

[0000926326-23-000003:notes:61]
With the acquisition of the 340B Link Business and ReCept Holdings, Inc., (“ReCept”), which was subsequently renamed Omnicell Specialty Pharmacy Services, Inc., the Company offers certain products and services in which it is customary for pharmacies or insurance payors to owe funds to the Company which are collected on behalf of, and, after a short holding period, disbursed to, the Company’s customers. The Company presents amounts due from pharmacies and amounts due to be disbursed to customers on a gross basis within other current assets and accrued liabilities, respectively, in the Consolidated Balance Sheets, as such amounts are expected to be settled within one year. Generally, any funds received from the pharmacies or insurance payors that are held by the Company are segregated from its other corporate cash accounts. These funds are classified as restricted cash as the Company is contractually obligated to disburse these amounts to customers.

[0000926326-23-000003:notes:62]
Sales of Accounts Receivable

[0000926326-23-000003:notes:63]
The Company records the sale of its accounts receivables in accordance with accounting guidance for transfers and servicing of financial assets. The Company transferred non-recourse accounts receivable totaling $45.3 million, $46.7 million, and $58.8 million during the years ended December 31, 2022, 2021, and 2020, respectively, which approximated fair value, to leasing companies on a non-recourse basis. Accounts receivable balance included approximately $6.7 million and $5.6 million due from third-party leasing companies for transferred non-recourse accounts receivable as of December 31, 2022 and 2021, respectively.

[0000926326-23-000003:notes:64]
Cash and Cash Equivalents

[0000926326-23-000003:notes:65]
The Company classifies all highly-liquid investments with original maturities of three months or less as cash equivalents. The Company’s cash and cash equivalent balances include bank accounts and highly-liquid U.S. Government money market funds held in sweep and asset management accounts with financial institutions of high credit quality. The Company continuously monitors the credit worthiness of the financial institutions in which it invests. The Company has not experienced any credit losses from its cash equivalents. Cash and cash equivalents were $330.4 million and $349.1 million as of December 31, 2022 and 2021, respectively. As of December 31, 2022 and 2021, cash equivalents were $301.0 million and $320.2 million, respectively, which consisted of money market funds held in sweep and asset management accounts.

[0000926326-23-000003:notes:66]
Financial Instruments

[0000926326-23-000003:notes:67]
For assets and liabilities measured at fair value, the amounts are based on an expected exit price representing the amount that would be received from the sale of an asset or paid to transfer a liability in a transaction between market participants. The fair value may be based on assumptions that market participants would use in pricing an asset or liability. ASC 820, Fair Value Measurement, establishes a consistent framework for measuring fair value on either a recurring or nonrecurring basis whereby inputs used in valuation techniques are assigned a hierarchical level, as follows:

[0000926326-23-000003:notes:68]
Level 1 – Observable inputs, such as quoted prices in active markets for identical instruments;

[0000926326-23-000003:notes:69]
Level 2 – Quoted prices for similar instruments in active markets, or quoted prices for identical instruments in inactive markets; and

[0000926326-23-000003:notes:70]
Level 3 – Unobservable inputs for financial instruments reflecting Company’s assumptions.

[0000926326-23-000003:notes:71]
Inventory

[0000926326-23-000003:notes:72]
Inventories are stated at the lower of cost, computed using the first-in, first-out method, and net realizable value. Inbound shipping costs are included in cost of inventory. The Company regularly monitors inventory quantities on hand and records write-downs for excess and obsolete inventories based on the Company’s estimate of demand for its products, potential obsolescence of technology, product life cycles, and whether pricing trends or forecasts indicate that the carrying value of inventory exceeds its estimated selling price. These factors are impacted by market and economic conditions, technology changes, and new product introductions and require estimates that may include elements that are uncertain. Actual demand may differ from forecasted demand and may have a material effect on gross margins. If inventory is written down, a new cost basis is established that cannot be increased in future periods. Shipments from suppliers or contract manufacturers before the

[0000926326-23-000003:notes:73]
Company receives them are recorded as in-transit inventory when title and the significant risks and rewards of ownership have passed to the Company.

[0000926326-23-000003:notes:74]
The Company has a supply agreement with one primary supplier for construction and supply of several sub-assemblies and inventory management of sub-assemblies used in its hardware products. There are no minimum purchase requirements. The contract with the Company’s supplier may be terminated by either the supplier or by the Company without cause and at any time upon delivery of six months’ notice. Purchases from this supplier were $105.7 million, $103.2 million, and $76.3 million for the years ended December 31, 2022, 2021, and 2020, respectively.

[0000926326-23-000003:notes:75]
Shipping Costs

[0000926326-23-000003:notes:76]
Outbound freight billed to customers is recorded as product revenue. The related shipping and handling costs are expensed as part of selling, general, and administrative expense. Shipping and handling expenses were $24.5 million, $18.2 million, and $15.6 million for the years ended December 31, 2022, 2021, and 2020, respectively.

[0000926326-23-000003:notes:77]
Property and Equipment

[0000926326-23-000003:notes:78]
Property and equipment less accumulated depreciation are stated at historical cost. The Company’s expenditures for property and equipment are primarily for computer equipment and software used in the administration of its business, and for leasehold improvements to its leased facilities. The Company also develops molds and dies used in long-term manufacturing arrangements with suppliers and for production automation equipment used in the manufacturing of consumable blister card components.

[0000926326-23-000003:notes:79]
Depreciation and amortization is computed by use of the straight-line method over the estimated useful lives of the assets as stated below:

[0000926326-23-000003:notes:80]
| Computer equipment and related software | 3 - 5 years |
| Leasehold and building improvements | Shorter of the lease term or the estimated useful life |
| Furniture and fixtures | 5 - 7 years |
| Equipment | 2 - 12 years |

[0000926326-23-000003:notes:81]
The Company capitalizes costs related to computer software developed or obtained for internal use in accordance with ASC 350-40, Internal-Use Software. Software developed or obtained for internal use includes certain costs for the development of the Company’s subscription and cloud-based offerings sold to its customers, as well as enterprise-level business and finance software that the Company customizes to meet its specific operational needs. Costs incurred in the application development phase are capitalized and amortized over their useful lives, which is generally five years. Costs recognized in the preliminary project phase and the post-implementation phase are expensed as incurred. The Company capitalized $33.0 million and $12.7 million of costs related to the application development of enterprise-level software and its subscription and cloud-based offerings, which were included in property and equipment during the years ended December 31, 2022 and 2021, respectively. Capitalized costs related to computer software developed or obtained for internal use were included in purchases of property and equipment in the Consolidated Statements of Cash Flows.

[0000926326-23-000003:notes:82]
Software Development Costs for External Use

[0000926326-23-000003:notes:83]
The Company capitalizes certain software development costs in accordance with ASC 985-20, Costs of Software to Be Sold, Leased, or Marketed, under which those costs incurred subsequent to the establishment of technological feasibility may be capitalized and amortized over the estimated lives of the related products. The Company establishes technological feasibility when it completes a detail program design or a working model. The Company amortizes development costs over the estimated lives of the related products, which is generally five years. All development costs prior to the completion of a detail program design or a working model are recognized as research and development expense. The Company capitalized software development costs of $13.2 million and $29.4 million, that were included in other long-term assets as of December 31, 2022 and 2021, respectively.

[0000926326-23-000003:notes:84]
Lessee Leases

[0000926326-23-000003:notes:85]
The Company determines if an arrangement is a lease at inception. Operating lease right-of-use assets and liabilities are recognized at the commencement date based on the present value of lease payments over the lease term. As most of its lease contracts do not provide an implicit rate, the Company uses its incremental borrowing rate based on information available at the commencement date in determining the present value of the lease payments. Lease expense is recognized on a straight-line basis over the lease term. The Company does not recognize a right-of-use asset and a lease liability for leases with an initial

[0000926326-23-000003:notes:86]
term of twelve months or less. The Company elected the practical expedient to not separate lease components from nonlease components and applied that practical expedient to all material classes of leased assets.

[0000926326-23-000003:notes:87]
Many of the Company’s operating leases include an option to extend the lease. The specific terms and conditions of the extension options vary from lease to lease, but are consistent with standard industry practices in each area that the Company operates. The Company reviews each of its lease options at a time required by the terms of the lease contract, and notifies the lessor if it chooses to exercise the lease renewal option. Until the Company is reasonably certain that it will extend the lease contract, the renewal option periods will not be recognized as right-of-use assets or lease liabilities.

[0000926326-23-000003:notes:88]
Certain leases include provisions for early termination, which allow the contract parties to terminate their obligations under the lease contract. The terms and conditions of the termination options vary by contract. When the Company has made a decision to exercise an early termination option, the right-of-use assets and associated lease liabilities are remeasured in accordance with the present value of the remaining cash flows under the lease contract.

[0000926326-23-000003:notes:89]
Certain building lease agreements include rental payments subject to change annually based on fluctuations in various indexes (i.e., Consumer Price Index (“CPI”), Retail Price Index, and other international indexes). Certain data center lease agreements include rental payments subject to change based on usage and CPI fluctuations. The changes based on usage and indexes are treated as variable lease costs and recognized in the period in which the obligation for those payments was incurred.

[0000926326-23-000003:notes:90]
The Company’s operating lease agreements do not contain any material residual value guarantees, restrictions, or restriction covenants.

[0000926326-23-000003:notes:91]
Business Combinations

[0000926326-23-000003:notes:92]
The Company uses the acquisition method of accounting under ASC 805, Business Combinations. Each acquired company’s operating results are included in the Company’s Consolidated Financial Statements starting on the acquisition date. The purchase price is equivalent to the fair value of consideration transferred. Tangible and identifiable intangible assets acquired and liabilities assumed as of the acquisition date are recorded at the acquisition date fair value. Goodwill is recognized for the excess of purchase price over the net fair value of assets acquired and liabilities assumed.

[0000926326-23-000003:notes:93]
Amounts allocated to assets and liabilities are based upon fair values. Such valuations require management to make significant estimates and assumptions, especially with respect to the identifiable intangible assets. Management makes estimates of fair value based upon assumptions believed to be reasonable and that of a market participant. These estimates are based on available historical information as well as future expectations, and the estimates are inherently uncertain. The separately identifiable intangible assets generally include customer relationships, acquired technology, backlog, trade names, and non-compete agreements.

[0000926326-23-000003:notes:94]
Goodwill and Acquired Intangible Assets

[0000926326-23-000003:notes:95]
Goodwill

[0000926326-23-000003:notes:96]
The Company assesses goodwill for impairment on an annual basis on the first day of the fourth quarter of each year at the reporting unit level. This assessment is also performed whenever there is a change in circumstances that indicates the carrying value of goodwill may be impaired. The Company has one reporting unit, which is the same as its operating segment. A qualitative assessment is initially made to determine whether it is necessary to perform quantitative testing. A qualitative assessment includes, among others, consideration of: (i) past, current, and projected future earnings and equity; (ii) recent trends and market conditions; and (iii) valuation metrics involving similar companies that are publicly-traded and acquisitions of similar companies, if available. If this qualitative assessment indicates that it is more likely than not that impairment exists, or if the Company decides to bypass this option, it proceeds to the quantitative assessment. The quantitative assessment involves a comparison between the estimated fair value of the Company’s reporting unit with its carrying amount including goodwill. If the carrying value exceeds estimated fair value, the Company will record an impairment charge based on that difference. The impairment charge will be limited to the amount of goodwill.

[0000926326-23-000003:notes:97]
To determine the reporting unit’s fair value under the quantitative approach, the Company uses a combination of income and market approaches, such as estimated discounted future cash flows of the reporting unit, multiples of earnings or revenues, and analysis of recent sales or offerings of comparable entities. The Company also considers its market capitalization on the date of the analysis to ensure the reasonableness of its reporting unit’s fair value.

[0000926326-23-000003:notes:98]
The Company elected to perform a quantitative impairment assessment analysis as of October 1, 2022 for its reporting unit. The Company determined that the fair value of the reporting unit exceeded the carrying value and thus no impairment was indicated. Based on the result of this analysis, an impairment does not exist as of December 31, 2022, and there were no accumulated impairment losses.

[0000926326-23-000003:notes:99]
Intangible Assets

[0000926326-23-000003:notes:100]
In connection with its acquisitions, the Company generally recognizes assets for customer relationships, acquired technology, backlog, trade names, and non-compete agreements. Intangible assets are carried at cost less accumulated amortization. Such amortization is provided on a straight-line basis or on an accelerated basis based on a pattern of economic benefit that is expected to be obtained over the estimated useful lives of the respective assets. Amortization for acquired technology and backlog is recognized in cost of revenues, and amortization for customer relationships, trade names, non-compete agreements, and patents is recognized in selling, general, and administrative expenses.

[0000926326-23-000003:notes:101]
The Company assesses the impairment of identifiable intangible assets whenever events or changes in circumstances indicate that an asset’s carrying amount may not be recoverable. Recoverability of an asset is measured by the comparison of the carrying amount to the sum of the undiscounted estimated future cash flows the asset is expected to generate, offset by estimated future costs to dispose of the product to which the asset relates. If an asset is considered to be impaired, the amount of such impairment would be measured as the difference between the carrying amount of the asset and its fair value. The Company’s cash flow assumptions are based on historical and forecasted future revenue, operating costs, and other relevant factors. Assumptions and estimates about the remaining useful lives of the Company’s intangible assets are subjective and are affected by changes to its business strategies. If management’s estimates of future operating results change, or if there are changes to other assumptions, the estimate of the fair value of the Company’s assets could change significantly. Such change could result in impairment charges in future periods, which could have a significant impact on the Company’s operating results and financial condition. For the years ended December 31, 2022 and 2021, there were no events or changes in circumstances to indicate that intangible assets carrying amounts may not be recoverable.

[0000926326-23-000003:notes:102]
Convertible Debt

[0000926326-23-000003:notes:103]
The Company accounts for convertible debt and related transactions in accordance with ASC 470-20, Debt with Conversion and Other Options, ASC 815, Derivatives and Hedging, and ASC 480, Distinguishing Liabilities from Equity. The Company evaluates convertible debt instruments and related transactions at inception to determine if those contracts or embedded components of those contracts qualify as derivatives to be separately accounted for.

[0000926326-23-000003:notes:104]
Prior to the adoption of Accounting Standards Update (“ASU”) 2020-06, Debt-Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging-Contracts in Entity’s Own Equity (Subtopic 815-40), convertible debt instruments that could be settled in cash were required to be separated into liability and equity components. The allocation to the liability component was based on the fair value of a similar instrument that did not contain an equity conversion option. Based on this debt-to-equity ratio, debt issuance costs were then allocated to the liability and equity components in a similar manner. The difference between the principal amount of the convertible senior notes and the liability component, inclusive of issuance costs, represented the debt discount, which the Company amortized to interest expense over the term of the convertible senior notes. The determination of the discount rate required certain estimates and assumptions.

[0000926326-23-000003:notes:105]
Upon adoption of ASU 2020-06, effective January 1, 2022, the convertible senior notes are no longer separated into liability and equity components, and are accounted for as a single liability, measured at amortized cost in the Consolidated Balance Sheets. Issuance costs are amortized using the effective interest method over the term of the convertible senior notes. Refer to “Recently Adopted Authoritative Guidance” section below for further information regarding the Company’s adoption of ASU 2020-06.

[0000926326-23-000003:notes:106]
Convertible note hedge and warrant transactions associated with convertible debt instruments are accounted for as equity instruments, and are recorded in additional paid-in capital in the Consolidated Balance Sheets.

[0000926326-23-000003:notes:107]
Valuation of Share-Based Compensation

[0000926326-23-000003:notes:108]
The Company accounts for share-based compensation in accordance with ASC 718, Stock Compensation. The Company recognizes compensation expense related to share-based compensation based on the grant date estimated fair value.

[0000926326-23-000003:notes:109]
The fair value of stock options (“options”) on the grant date is estimated using the Black-Scholes option pricing model, which requires the following inputs: expected life, expected volatility, risk-free interest rate, expected dividend yield rate, exercise price, and closing price of its common stock on the date of grant. The expected volatility is based on a combination of historical and market-based implied volatility, and the expected life of the awards is based on the Company’s historical experience of employee stock option exercises, including forfeitures. Expense is recognized on a straight-line basis over the requisite service period.

[0000926326-23-000003:notes:110]
The fair value of restricted stock units (“RSUs”) and restricted stock awards (“RSAs”) is based on the stock price on the grant date. The RSUs and RSAs are subject to a service vesting condition and are recognized on a straight-line basis over the requisite service period.

[0000926326-23-000003:notes:111]
The fair value of performance-based stock unit awards (“PSUs”) with service and market conditions is estimated using a Monte Carlo simulation model applying a multiple awards approach. Expense is recognized when it is probable that the performance condition will be met using the accelerated attribution method over the requisite service period.

[0000926326-23-000003:notes:112]
Forfeiture rates are estimated based on the Company’s historical experience with equity awards that were granted and forfeited prior to vesting. The valuation assumptions used in estimating the fair value of employee share-based awards may change in future periods.

[0000926326-23-000003:notes:113]
Accounting for Income Taxes

[0000926326-23-000003:notes:114]
The Company records an income tax provision for (benefit from) the anticipated tax consequences of the reported results of operations. In accordance with ASC 740, Income Taxes, the provision for (benefit from) income taxes is computed using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been included in the financial statements. Under this method, deferred tax assets and liabilities are determined on the basis of the differences between the financial statement and tax bases of assets and liabilities and for operating losses and tax credit carryforwards. Deferred tax assets and liabilities are measured using the enacted tax rates in effect for the periods in which those tax assets and liabilities are expected to be realized or settled. In the event that these tax rates change, the Company will incur a benefit or detriment on its income tax expense in the period of enactment. If the Company were to determine that all or part of the net deferred tax assets are not realizable in the future, it will record a valuation allowance that would be charged to earnings in the period such determination is made.

[0000926326-23-000003:notes:115]
In accordance with ASC 740, the Company recognizes the tax benefit from an uncertain tax position if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement. The calculation of tax liabilities involves significant judgment in estimating the impact of uncertainties in the application of ASC 740 and complex tax laws. Resolution of these uncertainties in a manner inconsistent with management’s expectations could have a material impact on the Company’s financial condition and operating results.

[0000926326-23-000003:notes:116]
Recently Adopted Authoritative Guidance

[0000926326-23-000003:notes:117]
In August 2020, the Financial Accounting Standards Board (“FASB”) issued ASU 2020-06, Debt-Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging-Contracts in Entity’s Own Equity (Subtopic 815-40). The update simplifies the accounting for convertible debt instruments by reducing the number of accounting models and the number of embedded conversion features that could be recognized separately from the primary contract. ASU 2020-06 also enhances transparency and improves disclosures for convertible instruments and earnings per share guidance. ASU 2020-06 also requires the application of the if-converted method for calculating diluted earnings per share and the treasury stock method is no longer permitted for convertible instruments. This update permits the use of either the modified retrospective or fully retrospective method of transition. The Company adopted ASU 2020-06 on January 1, 2022, using the modified retrospective method of transition. Upon adoption of ASU 2020-06, the previously separated equity component and associated debt issuance costs for the Company’s outstanding convertible senior notes were reclassified to the liability component, thereby eliminating the subsequent amortization of the debt discount as interest expense. In addition, the Company derecognized the deferred tax liability related to the equity component.

[0000926326-23-000003:notes:118]
The Company’s adoption of ASU 2020-06 impacted the Consolidated Balance Sheets at the beginning of the period of adoption as follows:

[0000926326-23-000003:notes:119]
|  | January 1, 2022 |
|  | Pre-ASU 2020-06 Balances |  | ASU 2020-06 Adoption Impact |  | Post-ASU 2020-06 Balances |
|  | (In thousands) |
| Long-term deferred tax assets | $ | 15,883 |  |  | $ | (452) |  |  | $ | 15,431 |  |
| Convertible senior notes, net | 488,152 |  |  | 75,353 |  |  | 563,505 |  |
| Long-term deferred tax liabilities | 51,705 |  |  | (19,572) |  |  | 32,133 |  |
| Additional paid-in capital | 1,024,580 |  |  | (72,742) |  |  | 951,838 |  |
| Retained earnings | 368,571 |  |  | 16,509 |  |  | 385,080 |  |

[0000926326-23-000003:notes:120]
Adoption of ASU 2020-06 did not have an impact on the Company’s Consolidated Statements of Operations or Consolidated Statements of Cash Flows as of January 1, 2022. Refer to Note 11, Convertible Senior Notes, for further information regarding the Company’s convertible senior notes.

[0000926326-23-000003:notes:121]
Recently Issued Authoritative Guidance

[0000926326-23-000003:notes:122]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. The update addresses diversity in practice by requiring that an acquirer recognize and measure contract assets and liabilities acquired in a business combination in accordance with ASC 606, Revenue from Contracts with Customers. The Company will apply the guidance prospectively to acquisitions occurring on or after the effective date. ASU 2021-08 will be effective for the Company beginning January 1, 2023. The Company does not anticipate that the adoption of ASU 2021-08 will have a material impact on its Consolidated Financial Statements.

[0000926326-23-000003:notes:123]
No other recently issued and effective authoritative guidance is expected to have a material impact on the Company’s Consolidated Financial Statements through the reporting date.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0000926326-23-000003:notes:124]
Contract Costs
The Company has determined that certain incentive portions of its sales commission plans require capitalization since these payments are directly related to sales achieved during a time period. These commissions are earned on the basis of: (i) the  value of new bookings for connected devices, software products, and Advanced Services, provided that for Advanced Services a commission will only be paid on the amount that represents the minimum commitment and (ii) the value of new orders for consumables. Since there are no commensurate commissions earned on renewal of the service bookings, the Company concluded that the capitalized asset is related to services provided under both the initial contract and renewal periods. The Company applies a practical expedient to account for the incremental costs of obtaining a contract as part of a portfolio of contracts with similar characteristics as the Company expects the effect on the financial statements of applying the practical expedient would not differ materially from applying the accounting guidance to the individual contracts within the portfolio. A pool of contracts is defined as all contracts booked in a particular quarter. The amortization for the capitalized asset is an estimate of the pool’s original contract term, generally one to five years, plus an estimate of future customer renewal periods resulting in a total amortization period of ten years. Costs to obtain a contract are allocated amongst performance obligations and recognized as sales and marketing expense consistent with the pattern of revenue recognition. In accordance with GAAP, while certain compensation elements are expensed as incurred, a portion of the pool’s capitalized asset is recorded as an expense over the first seven quarters after booking, which represents the estimated period during which the product revenue associated with the contract is recorded. The remaining capitalized contract costs are recorded as expense ratably over the ten year estimated initial and renewal service periods.Shipping CostsOutbound freight billed to customers is recorded as product revenue. The related shipping and handling costs are expensed as part of selling, general, and administrative expense.


## us-gaap:LessorLeasesPolicyTextBlock

[0000926326-23-000003:notes:125]
For operating leases, rental income is generally recognized on a straight-line basis over the term of the associated lease, and recorded in services and other revenues in the Consolidated Statements of Operations. Leased assets under operating leases are carried at amortized cost net of accumulated depreciation in property and equipment, net on the Consolidated Balance Sheets. The depreciation expense of the leased assets is recognized on a straight-line basis over the contractual term of the associated lease, and recorded in cost of revenues in the Consolidated Statements of Operations.
The Company entered into certain leasing agreements that were classified as operating leases prior to the adoption of ASC 842, Leases. These agreements in place prior to January 1, 2019 continue to be treated as operating leases, however any leasing agreements entered into on or after January 1, 2019 under these programs are classified and accounted for as sales-type leases in accordance with ASC 842.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0000926326-23-000003:notes:126]
The following table represents the property and equipment balances as of December 31, 2022 and 2021:

[0000926326-23-000003:notes:127]
|  | December 31, |
|  | 2022 |  | 2021 |
|  | (In thousands) |
| Equipment | $ | 91,391 |  |  | $ | 89,272 |  |
| Furniture and fixtures | 5,154 |  |  | 7,580 |  |
| Leasehold improvements | 19,510 |  |  | 20,623 |  |
| Software | 76,327 |  |  | 60,856 |  |
| Construction in progress | 28,223 |  |  | 14,757 |  |
| Property and equipment, gross | 220,605 |  |  | 193,088 |  |
| Accumulated depreciation and amortization | (126,644) |  |  | (121,947) |  |
| Total property and equipment, net | $ | 93,961 |  |  | $ | 71,141 |  |

[0000926326-23-000003:notes:128]
The following table summarizes the geographic information for property and equipment, net, as of December 31, 2022 and 2021:

[0000926326-23-000003:notes:129]
|  | December 31, |
|  | 2022 |  | 2021 |
|  | (In thousands) |
| United States | $ | 89,989 |  |  | $ | 66,788 |  |
| Rest of world (1) | 3,972 |  |  | 4,353 |  |
| Total property and equipment, net | $ | 93,961 |  |  | $ | 71,141 |  |

[0000926326-23-000003:notes:130]
_________________________________________________

[0000926326-23-000003:notes:131]
(1)    No individual country represented more than 10% of total property and equipment, net.


## us-gaap:DebtPolicyTextBlock

[0000926326-23-000003:notes:132]
Convertible note hedge and warrant transactions associated with convertible debt instruments are accounted for as equity instruments, and are recorded in additional paid-in capital in the Consolidated Balance Sheets.
Prior to the adoption of ASU 2020-06, convertible debt instruments that could be settled in cash were required to be separated into liability and equity components. The allocation to the liability component was based on the fair value of a similar instrument that did not contain an equity conversion option. Based on this debt-to-equity ratio, debt issuance costs were then allocated to the liability and equity components in a similar manner.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000926326-23-000003:notes:133]
In August 2020, the Financial Accounting Standards Board (“FASB”) issued ASU 2020-06, Debt-Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging-Contracts in Entity’s Own Equity (Subtopic 815-40). The update simplifies the accounting for convertible debt instruments by reducing the number of accounting models and the number of embedded conversion features that could be recognized separately from the primary contract. ASU 2020-06 also enhances transparency and improves disclosures for convertible instruments and earnings per share guidance. ASU 2020-06 also requires the application of the if-converted method for calculating diluted earnings per share and the treasury stock method is no longer permitted for convertible instruments. This update permits the use of either the modified retrospective or fully retrospective method of transition. The Company adopted ASU 2020-06 on January 1, 2022, using the modified retrospective method of transition. Upon adoption of ASU 2020-06, the previously separated equity component and associated debt issuance costs for the Company’s outstanding convertible senior notes were reclassified to the liability component, thereby eliminating the subsequent amortization of the debt discount as interest expense. In addition, the Company derecognized the deferred tax liability related to the equity component.
Adoption of ASU 2020-06 did not have an impact on the Company’s Consolidated Statements of Operations or Consolidated Statements of Cash Flows as of January 1, 2022. Refer to Note 11, Convertible Senior Notes, for further information regarding the Company’s convertible senior notes.
Recently Issued Authoritative Guidance


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000926326-23-000003:notes:134]
Business Combinations
The Company accounted for its acquisitions in accordance with ASC 805, Business Combinations. The tangible and intangible assets acquired and liabilities assumed were recorded at fair value on the respective acquisition dates. Intangible assets eligible for recognition separate from goodwill were those that satisfied either the contractual or legal criterion or the separability criterion, each as set forth in the accounting guidance. The Company believes that the fair values assigned to the assets acquired and liabilities assumed are based on reasonable assumptions and estimates that market participants would use.

[0000926326-23-000003:notes:135]
The Company’s Consolidated Financial Statements include the results of operations of each acquired company, commencing as of their respective acquisition dates. Acquisition-related costs were expensed as incurred, and are included in selling, general, and administrative expenses in the Company’s Consolidated Statements of Operations.

[0000926326-23-000003:notes:136]
2022 Acquisition

[0000926326-23-000003:notes:137]
Hub and Spoke Innovations

[0000926326-23-000003:notes:138]
On January 10, 2022, the Company completed the acquisition of all of the outstanding equity interests in Hub and Spoke Innovations pursuant to the terms and conditions of the Share Purchase Agreement, dated January 10, 2022, by and among Omnicell Limited (a wholly-owned subsidiary of the Company), Hub and Spoke Innovations Limited, and certain beneficial stockholders specified therein for a base purchase price of £2.5 million (approximately $3.4 million based on the exchange rate in effect at the acquisition date), prior to customary adjustments for closing cash, net working capital, and assumed indebtedness. The purchase price transferred for the transaction, net of cash acquired, was £2.5 million (approximately $3.4 million based on the exchange rate in effect at the acquisition date). Of the purchase price transferred, £1.9 million (approximately $2.5 million based on the exchange rate in effect at the acquisition date) was allocated to goodwill; £0.8 million (approximately $1.1 million based on the exchange rate in effect at the acquisition date) was allocated to intangible assets, which included customer relationships; and the remainder was allocated to net assets acquired. The Hub and Spoke Innovations acquisition is expected to complement Omnicell’s total solution technology portfolio for retail pharmacy in the United Kingdom to help pharmacies improve workflows, offer patients 24/7 access to their medications and provide enhanced patient care.

[0000926326-23-000003:notes:139]
2021 Acquisitions

[0000926326-23-000003:notes:140]
MarkeTouch Media

[0000926326-23-000003:notes:141]
On December 31, 2021, the Company completed the acquisition of all of the outstanding equity interests in MarkeTouch Media, LLC (“MarkeTouch Media”) pursuant to the terms and conditions of the Unit Purchase Agreement, dated December 31, 2021, by and among ateb, Inc. (a wholly-owned subsidiary of the Company), MarkeTouch Media, LLC, MarkeTouch Holdings, Inc., Toucan Enterprises, Inc., and certain beneficial stockholders specified therein for a base purchase price of $82.0 million, prior to customary adjustments for closing cash, net working capital, and assumed indebtedness. The MarkeTouch Media acquisition adds mobile and web-based technology and patient engagement solutions, which is expected to expand the footprint of EnlivenHealth® across the retail pharmacy sector, while enhancing potential growth opportunities in new market segments like specialty pharmacy and pharmacy benefits management.

[0000926326-23-000003:notes:142]
ReCept

[0000926326-23-000003:notes:143]
On December 29, 2021, the Company completed the acquisition of all outstanding equity securities of ReCept pursuant to the terms and conditions of the Agreement and Plan of Merger, dated December 1, 2021, by and among Omnicell, Inc., ReCept Holdings, Inc., Redfish Acquisition Corp, and the representative of the securityholders for a base purchase price of $100.0 million, prior to customary adjustments for closing cash, net working capital, and assumed indebtedness. The addition of ReCept’s specialty pharmacy management services, now a part of the Company’s Specialty Pharmacy Services, for health

[0000926326-23-000003:notes:144]
systems, provider groups, and federally qualified health centers expands Omnicell’s Advanced Services portfolio in an effort to address the growing and complex specialty pharmacy market.

[0000926326-23-000003:notes:145]
FDS Amplicare

[0000926326-23-000003:notes:146]
On September 9, 2021, the Company completed the acquisition of all of the outstanding equity interests in RxInnovation, Inc., operating as FDS Amplicare® (“FDS Amplicare”), pursuant to the terms and conditions of the Agreement and Plan of Merger, dated July 25, 2021, by and among RxInnovation Inc., Omnicell, Inc., Fleming Acquisition Corp., and the representative of the securityholders for a base purchase price of $177.0 million, prior to customary adjustments for closing cash, net working capital, and assumed indebtedness. The FDS Amplicare acquisition adds a comprehensive and complementary suite of software-as-a-service (“SaaS”) financial management, analytics, and population health solutions to the Company’s EnlivenHealth offering.

[0000926326-23-000003:notes:147]
The Company incurred approximately $7.0 million in acquisition-related costs related to the FDS Amplicare acquisition during the year ended December 31, 2021. Revenues and net losses from the FDS Amplicare operations since the acquisition date through December 31, 2021 were $11.3 million and $0.9 million, respectively.

[0000926326-23-000003:notes:148]
The following tables represent the allocation of the respective purchase price to the assets acquired and the liabilities assumed by the Company as part of each acquisition included in the Company’s Consolidated Balance Sheets, and is reconciled to the respective purchase price transferred:

[0000926326-23-000003:notes:149]
|  | FDS Amplicare (1) |  | ReCept (2) (3) |  | MarkeTouch Media (4) |
|  | (In thousands) |
| Purchase price transferred: |  |  |  |  |  |
| Base purchase price | $ | 177,000 |  |  | $ | 100,000 |  |  | $ | 82,000 |  |
| Add: Closing cash | 465 |  |  | 6,569 |  |  | 237 |  |
| Add: Net working capital adjustment | 1,654 |  |  | (7,357) |  |  | 147 |  |
| Less: Assumed indebtedness | (653) |  |  | (1,973) |  |  | (15) |  |
| Total purchase price transferred | $ | 178,466 |  |  | $ | 97,239 |  |  | $ | 82,369 |  |
|  | FDS Amplicare (1) |  | ReCept (2) (3) |  | MarkeTouch Media (4) |
| Fair value of assets acquired and liabilities assumed: |  |  |  |  |  |
| Cash and cash equivalents | $ | 465 |  |  | $ | — |  |  | $ | 237 |  |
| Accounts receivable and unbilled receivables | 5,330 |  |  | 2,383 |  |  | 2,302 |  |
| Prepaid expenses | 506 |  |  | 192 |  |  | 96 |  |
| Other current assets | 45 |  |  | 12,223 |  |  | — |  |
| Total current assets | 6,346 |  |  | 14,798 |  |  | 2,635 |  |
| Property and equipment | 444 |  |  | 172 |  |  | 177 |  |
| Operating lease right-of-use assets | 2,252 |  |  | 773 |  |  | 602 |  |
| Goodwill | 117,784 |  |  | 77,644 |  |  | 42,273 |  |
| Intangible assets | 70,000 |  |  | 28,100 |  |  | 38,000 |  |
| Other long-term assets | 51 |  |  | 195 |  |  | 2,850 |  |
| Total assets | 196,877 |  |  | 121,682 |  |  | 86,537 |  |
| Accounts payable | 950 |  |  | 219 |  |  | 473 |  |
| Accrued compensation | 1,312 |  |  | 1,756 |  |  | — |  |
| Accrued liabilities | 1,497 |  |  | 18,249 |  |  | 292 |  |
| Deferred revenues | 1,916 |  |  | 222 |  |  | 347 |  |
| Long-term deferred tax liabilities | 11,686 |  |  | 3,383 |  |  | — |  |
| Long-term operating lease liabilities | 920 |  |  | 614 |  |  | 206 |  |
| Other long-term liabilities | 130 |  |  | — |  |  | 2,850 |  |
| Total liabilities | 18,411 |  |  | 24,443 |  |  | 4,168 |  |
| Total purchase price | $ | 178,466 |  |  | $ | 97,239 |  |  | $ | 82,369 |  |
| Total purchase price, net of cash acquired | $ | 178,001 |  |  | $ | 90,670 |  |  | $ | 82,132 |  |

[0000926326-23-000003:notes:150]
(1)    During the year ended December 31, 2021, the Company recorded measurement period adjustments of $1.5 million to goodwill, consisting of an increase in intangible assets, accounts receivable and unbilled receivables, and long-term deferred tax liabilities of $0.4 million, $1.1 million, and $0.1 million, respectively, and a net working capital adjustment of $0.1 million. During the year ended December 31, 2022, the Company recorded a measurement period adjustments of $0.4 million to goodwill, consisting of an increase in long-term deferred tax liabilities and accrued liabilities of $0.3 million and $0.1 million, respectively.

[0000926326-23-000003:notes:151]
(2)    Closing cash is included in other current assets due to its restrictive nature as cash held for customers.

[0000926326-23-000003:notes:152]
(3)    During the year ended December 31, 2022, the Company recorded measurement period adjustments of $3.9 million to goodwill, consisting of a purchase price adjustment of $5.2 million, a decrease in long-term deferred tax liabilities of $0.2 million and a decrease in accrued liabilities of $0.3 million, partially offset by a decrease to other current assets of $1.7 million.

[0000926326-23-000003:notes:153]
(4)    During the year ended December 31, 2022, the Company recorded a measurement period adjustment of $0.3 million to goodwill related to a purchase price adjustment.

[0000926326-23-000003:notes:154]
The $117.8 million of goodwill arising from the FDS Amplicare acquisition is primarily attributed to future sales of SaaS solutions and FDS Amplicare’s assembled workforce. The $77.6 million of goodwill arising from the ReCept acquisition is primarily attributed to future sales of its offerings and services and ReCept’s assembled workforce. None of the FDS Amplicare and ReCept goodwill is expected to be deductible for tax purposes as these acquisitions were treated as stock acquisitions for U.S. tax purposes. The $42.3 million of goodwill arising from the MarkeTouch Media acquisition is primarily attributed to future sales of SaaS solutions and MarkeTouch Media’s assembled workforce. The full amount of the MarkeTouch Media goodwill is expected to be deductible for tax purposes as this acquisition was treated as an asset acquisition for U.S. tax purposes.

[0000926326-23-000003:notes:155]
The identifiable intangible assets acquired and their estimated useful lives for amortization are as follows:

[0000926326-23-000003:notes:156]
|  | FDS Amplicare (1) |  | ReCept |  | MarkeTouch Media |
|  | Fair value |  | Useful life(years) |  | Fair value |  | Useful life(years) |  | Fair value |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 59,900 |  |  | 23 |  | $ | 28,100 |  |  | 23 |  | $ | 34,100 |  |  | 26 |
| Acquired technology | 7,700 |  |  | 5 - 7 |  | — |  |  | — |  | 2,100 |  |  | 4 |
| Backlog | — |  |  | — |  | — |  |  | — |  | 1,800 |  |  | 2 |
| Trade names | 2,400 |  |  | 5 |  | — |  |  | — |  | — |  |  | — |
| Total purchased intangible assets | $ | 70,000 |  |  |  |  | $ | 28,100 |  |  |  |  | $ | 38,000 |  |  |  |

[0000926326-23-000003:notes:157]
(1)    During the year ended December 31, 2021, the Company recorded a measurement period adjustment of $0.4 million in customer relationships.

[0000926326-23-000003:notes:158]
The customer relationships intangible assets represent the fair values of the underlying relationships and agreements with each acquired company’s customers. The acquired technology intangible assets represent the fair values of the portfolio of SaaS solutions that have reached technological feasibility and were part of the respective acquired company’s offerings at their respective acquisition dates. The backlog intangible asset represents contractually committed future billings associated with MarkeTouch Media customer contracts. The trade names intangible asset represents the fair value of brand and name recognition associated with the marketing of certain FDS Amplicare SaaS solutions.

[0000926326-23-000003:notes:159]
The fair values of the customer relationships and backlog intangible assets were determined based on the excess earnings method, and the fair values of the acquired technology and trade names intangible assets were determined based on the relief-from-royalty method. The key assumptions used in estimating the fair values of intangible assets included forecasted financial information; customer attrition rates; royalty rate of 10.0% for the acquired technology intangible assets for both FDS Amplicare and MarkeTouch Media; royalty rate of 2.0% for the FDS Amplicare trade names intangible asset; discount rate of 13.0% for the FDS Amplicare acquisition; discount rate of 15.0% for the ReCept acquisition; discount rate of 11.5% for the MarkeTouch Media acquisition; and certain other assumptions.

[0000926326-23-000003:notes:160]
The customer relationships and acquired technology intangible assets are being amortized using a double-declining method of amortization as such method better represents the economic benefits to be obtained. The backlog and trade names intangible assets are being amortized over their respective estimated useful lives using the straight-line method of amortization.

[0000926326-23-000003:notes:161]
2020 Acquisition

[0000926326-23-000003:notes:162]
340B Link Business

[0000926326-23-000003:notes:163]
On October 1, 2020, the Company completed the acquisition of all of the outstanding equity of the 340B Link Business pursuant to the terms and conditions of the Equity Purchase Agreement, dated August 11, 2020, as amended, by and among the Company, PSGH, LLC, BW Apothecary Holdings, LLC, the sellers identified therein and the sellers’ representative for total cash consideration of $225.0 million. The 340B Link Business acquisition adds a comprehensive and differentiated suite of software-enabled services and solutions used by certain eligible hospitals, health systems, clinics, and entities to manage compliance and capture 340B drug cost savings on outpatient prescriptions filled through the eligible entity’s pharmacy or a contracted pharmacy partner.

[0000926326-23-000003:notes:164]
The Company incurred approximately $6.5 million in acquisition-related costs related to the 340B Link Business acquisition during the year ended December 31, 2020. Revenues and earnings from the 340B Link Business operations since the acquisition date through December 31, 2020 were $10.2 million and $1.3 million, respectively.

[0000926326-23-000003:notes:165]
The following table represents the allocation of the purchase price to the assets acquired and the liabilities assumed by the Company as part of the acquisition included in the Company’s Consolidated Balance Sheets, and is reconciled to the purchase price transferred:

[0000926326-23-000003:notes:166]
|  | 340B Link Business (1) |
|  | (In thousands) |
| Accounts receivable and unbilled receivables | $ | 8,197 |  |
| Prepaid expenses | 232 |  |
| Other current assets | 23,040 |  |
| Total current assets | 31,469 |  |
| Property and equipment | 531 |  |
| Operating lease right-of-use assets | 3,138 |  |
| Goodwill | 160,268 |  |
| Intangible assets | 62,800 |  |
| Total assets | 258,206 |  |
| Accounts payable | 568 |  |
| Accrued liabilities | 23,715 |  |
| Long-term deferred tax liabilities | 6,334 |  |
| Long-term operating lease liabilities | 2,589 |  |
| Total liabilities | 33,206 |  |
| Total purchase price | $ | 225,000 |  |

[0000926326-23-000003:notes:167]
(1)    During the third quarter of 2021, the Company recorded measurement period adjustments of $0.9 million to goodwill, consisting of an increase in other current assets, a decrease in accrued liabilities, and a decrease in long-term deferred tax liabilities of $0.3 million, $0.1 million, and $0.5 million, respectively.

[0000926326-23-000003:notes:168]
The $160.3 million of goodwill arising from the 340B Link Business acquisition is primarily attributed to sales of future software-enabled services and solutions and the 340B Link Business’s assembled workforce. Approximately $93.7 million of the 340B Link Business goodwill is expected to be deductible for tax purposes. Tax deductible goodwill for U.S. tax purposes is attributable to the asset acquisition portion of the transaction.

[0000926326-23-000003:notes:169]
|  | 340B Link Business |
|  | Fair value |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 53,000 |  |  | 21 |
| Acquired technology | 9,000 |  |  | 5 |
| Trade names | 200 |  |  | 1 |
| Non-compete agreements | 600 |  |  | 3 |
| Total purchased intangible assets | $ | 62,800 |  |  |  |

[0000926326-23-000003:notes:170]
The customer relationships intangible asset represents the fair value of the underlying relationships and agreements with the 340B Link Business’s customers. The acquired technology intangible asset represents the fair value of the 340B Link Business’s portfolio of software and solutions that have reached technological feasibility and were part of the 340B Link Business’s offerings at the acquisition date. The trade names intangible asset represents the fair value of brand and name recognition associated with the marketing of the 340B Link Business’s software-enabled services and solutions. The non-compete agreements intangible asset represents the fair value of non-compete agreements with former key members of the 340B Link Business’s management.

[0000926326-23-000003:notes:171]
The fair value of the customer relationships intangible asset was determined based on the excess earnings method; the fair values of the acquired technology and trade names intangible assets were determined based on the relief-from-royalty

[0000926326-23-000003:notes:172]
method; and the fair value of the non-compete agreements intangible asset was determined based on the lost profits method. The key assumptions used in estimating the fair values of intangible assets included forecasted financial information; customer attrition rates; royalty rates of 10.0% and 0.5% for the acquired technology and trade names intangible assets, respectively; discount rate of 14.0% for all intangible assets; and certain other assumptions.

[0000926326-23-000003:notes:173]
The customer relationships and acquired technology intangible assets are being amortized using a double-declining method of amortization as such method better represents the economic benefits to be obtained. The trade names and non-compete agreements are being amortized over their estimated useful lives using the straight-line method of amortization.

[0000926326-23-000003:notes:174]
Pro Forma Financial Information

[0000926326-23-000003:notes:175]
The following table presents certain unaudited pro forma consolidated financial information for the years ended December 31, 2021 and 2020 as if the FDS Amplicare, ReCept, and MarkeTouch Media acquisitions had been completed on January 1, 2020 and the 340B Link Business acquisition had been completed on January 1, 2019. The pro forma effects of the Hub and Spoke Innovations acquisition were not material to the Company’s consolidated results of operations. The unaudited pro forma financial information is presented for informational purposes only, and is not indicative of what would have occurred had the acquisitions taken place on those respective dates. The unaudited pro forma financial information combines the historical results of the acquisitions with the Company’s consolidated historical results and includes certain adjustments including, but not limited to, amortization and depreciation of intangible assets and property and equipment acquired; imputed interest, interest expense, and amortization of debt issuance costs related to acquisitions, as applicable; and certain acquisition-related costs incurred.

[0000926326-23-000003:notes:176]
|  |  |  | Year Ended December 31, |
|  |  |  | 2021 |  | 2020 |
|  |  |  | (In thousands) |
| Pro forma revenues |  |  | $ | 1,195,473 |  |  | $ | 986,310 |  |
| Pro forma net income |  |  | $ | 79,981 |  |  | $ | 22,615 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000926326-23-000003:notes:177]
Revenues
Disaggregation of Revenues

[0000926326-23-000003:notes:178]
The following table summarizes the Company’s revenues disaggregated by revenue type for the years ended December 31, 2022, 2021, and 2020:

[0000926326-23-000003:notes:179]
|  | Year Ended December 31, |
|  | 2022 |  | 2021 |  | 2020 |
|  | (In thousands) |
| Connected devices, software licenses, and other | $ | 827,917 |  |  | $ | 739,074 |  |  | $ | 560,368 |  |
| Consumables | 75,305 |  |  | 73,438 |  |  | 75,663 |  |
| Technical services | 206,687 |  |  | 206,989 |  |  | 202,383 |  |
| Advanced Services | 186,038 |  |  | 112,517 |  |  | 53,794 |  |
| Total revenues | $ | 1,295,947 |  |  | $ | 1,132,018 |  |  | $ | 892,208 |  |

[0000926326-23-000003:notes:180]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location, for the years ended December 31, 2022, 2021, and 2020:

[0000926326-23-000003:notes:181]
|  | Year Ended December 31, |
|  | 2022 |  | 2021 |  | 2020 |
|  | (In thousands) |
| United States | $ | 1,168,202 |  | $ | 1,020,788 |  | $ | 797,602 |
| Rest of world (1) | 127,745 |  | 111,230 |  | 94,606 |
| Total revenues | $ | 1,295,947 |  | $ | 1,132,018 |  | $ | 892,208 |

[0000926326-23-000003:notes:182]
(1)    No individual country represented more than 10% of total revenues.

[0000926326-23-000003:notes:183]
The following table reflects the Company’s contract assets and contract liabilities:

[0000926326-23-000003:notes:184]
|  | December 31, |
|  | 2022 |  | 2021 |
|  | (In thousands) |
| Short-term unbilled receivables, net (1) | $ | 25,763 |  |  | $ | 17,208 |  |
| Long-term unbilled receivables, net (2) | 14,744 |  |  | 18,084 |  |
| Total contract assets | $ | 40,507 |  |  | $ | 35,292 |  |
| Short-term deferred revenues, net | $ | 118,947 |  |  | $ | 112,196 |  |
| Long-term deferred revenues | 37,385 |  |  | 20,194 |  |
| Total contract liabilities | $ | 156,332 |  |  | $ | 132,390 |  |

[0000926326-23-000003:notes:185]
(1)     Included in accounts receivable and unbilled receivables in the Consolidated Balance Sheets.

[0000926326-23-000003:notes:186]
(2)    Included in other long-term assets in the Consolidated Balance Sheets.

[0000926326-23-000003:notes:187]
Short-term deferred revenues of $118.9 million and $112.2 million include deferred revenues from product sales and service contracts, net of deferred cost of sales of $15.8 million and $22.4 million, as of December 31, 2022 and 2021, respectively. The short-term deferred revenues from product sales relate to delivered and invoiced products, pending installation and acceptance, expected to occur within the next twelve months. During the year ended December 31, 2022, the Company recognized revenues of $112.6 million that were included in the corresponding gross short-term deferred revenues balance of $134.6 million as of December 31, 2021.

[0000926326-23-000003:notes:188]
Long-term deferred revenues include deferred revenues from product and service contracts of $37.4 million and $20.2 million as of December 31, 2022 and 2021, respectively. Remaining performance obligations are primarily recognized ratably over the remaining term of the contract, generally not more than ten years.

[0000926326-23-000003:notes:189]
Significant Customers

[0000926326-23-000003:notes:190]
There were no customers that accounted for more than 10% of the Company’s total revenues for the years ended December 31, 2022, 2021, and 2020. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable balance as of December 31, 2022 and 2021.


## us-gaap:EarningsPerShareTextBlock

[0000926326-23-000003:notes:191]
Net Income Per ShareBasic net income (loss) per share is computed by dividing net income (loss) for the period by the weighted-average number of shares outstanding during the period. In periods of net loss, all potential common shares are anti-dilutive, so diluted net loss per share equals the basic net loss per share. In periods of net income, diluted net income per share is computed by dividing net income for the period by the basic weighted-average number of shares plus any dilutive potential common stock outstanding during the period, using the treasury stock method for share-based awards and warrants, and the if-converted method for convertible senior notes. Potential common stock includes the effect of outstanding dilutive stock options, restricted stock awards, and restricted stock units, as well as shares the Company could be obligated to issue from its convertible senior notes and warrants, as described in Note 11, Convertible Senior Notes. For periods prior to the adoption of ASU 2020-06 on January 1, 2022, the Company applied the treasury stock method to calculate the dilutive impact of the convertible senior notes. Upon adoption of ASU 2020-06, effective January 1, 2022, the Company applies the if-converted method for calculating the dilutive impact of the convertible senior notes. Refer to Note 1, Organization and Summary of Significant Accounting Policies, for further information. Following the Company’s irrevocable election in December 2021 to settle the principal portion of the convertible senior notes in cash with any conversion consideration in excess of the principal portion in cash and/or shares of the Company’s common stock at the Company’s option upon conversion, only the amounts expected to be settled in excess of the principal portion are considered dilutive in calculating earnings per share under the if-converted method. Any anti-dilutive weighted-average dilutive shares related to stock award plans, convertible senior notes, and warrants are excluded from the computation of the diluted net income per share.The basic and diluted net income per share calculations for the years ended December 31, 2022, 2021, and 2020 were as follows:

[0000926326-23-000003:notes:192]
|  | Year Ended December 31, |
|  | 2022 |  | 2021 |  | 2020 |
|  | (In thousands, except per share data) |
| Net income | $ | 5,648 |  |  | $ | 77,849 |  |  | $ | 32,194 |  |
| Weighted-average shares outstanding – basic | 44,398 |  |  | 43,475 |  |  | 42,583 |  |
| Effect of dilutive securities from stock award plans | 1,019 |  |  | 2,136 |  |  | 1,160 |  |
| Effect of convertible senior notes | 474 |  |  | 2,044 |  |  | — |  |
| Effect of warrants | — |  |  | 288 |  |  | — |  |
| Weighted-average shares outstanding – diluted | 45,891 |  |  | 47,943 |  |  | 43,743 |  |
| Net income per share – basic | $ | 0.13 |  |  | $ | 1.79 |  |  | $ | 0.76 |  |
| Net income per share – diluted | $ | 0.12 |  |  | $ | 1.62 |  |  | $ | 0.74 |  |
| Anti-dilutive weighted-average shares related to stock award plans | 725 |  |  | 156 |  |  | 2,054 |  |
| Anti-dilutive weighted-average shares related to convertible senior notes and warrants | 5,908 |  |  | — |  |  | 11,816 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000926326-23-000003:notes:193]
Fair Value of Financial InstrumentsThe Company measures its financial instruments at fair value. The Company’s cash, cash equivalents, and restricted cash are classified within Level 1 of the fair value hierarchy as they are valued primarily using quoted market prices utilizing market observable inputs. The Company’s credit facility is classified within Level 2 as the valuation inputs are based on quoted prices or market observable data of similar instruments. The Company’s convertible senior notes are classified within Level 2 as the valuation inputs are based on quoted prices in an inactive market on the last day in the reporting period. As of December 31, 2022, the fair value of the convertible senior notes was $501.4 million, compared to their carrying value of $566.6 million, which is net of unamortized debt issuance costs (subsequent to the adoption of ASU 2020-06). As of December 31, 2021, the fair value of the convertible senior notes was $1.085 billion, compared to their carrying value of $488.2 million, which is net of unamortized discount and debt issuance costs and excludes amounts classified within additional paid-in capital (prior to the adoption of ASU 2020-06). Refer to Note 10, Debt and Credit Agreement, for further information regarding the Company’s credit facility and Note 11, Convertible Senior Notes, for further information regarding the Company’s convertible senior notes. Refer to Note 1, Organization and Summary of Significant Accounting Policies, for further information regarding the adoption of ASU 2020-06.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000926326-23-000003:notes:194]
Balance Sheet Components
Balance sheet details as of December 31, 2022 and 2021 are presented in the tables below:

[0000926326-23-000003:notes:195]
|  | December 31, |
|  | 2022 |  | 2021 |
|  | (In thousands) |
| Inventories: |  |  |  |
| Raw materials | $ | 75,854 |  |  | $ | 48,215 |  |
| Work in process | 9,280 |  |  | 11,009 |  |
| Finished goods | 62,415 |  |  | 60,700 |  |
| Total inventories | $ | 147,549 |  |  | $ | 119,924 |  |
| Other current assets: |  |  |  |
| Funds held for customers, including restricted cash (1) | $ | 56,703 |  |  | $ | 20,405 |  |
| Net investment in sales-type leases, current portion | 11,486 |  |  | 10,665 |  |
| Prepaid income taxes | 1,702 |  |  | 6,656 |  |
| Other current assets | 7,471 |  |  | 10,608 |  |
| Total other current assets | $ | 77,362 |  |  | $ | 48,334 |  |
| Other long-term assets: |  |  |  |
| Capitalized software, net | $ | 80,760 |  |  | $ | 96,995 |  |
| Unbilled receivables, net | 14,744 |  |  | 18,084 |  |
| Deferred debt issuance costs | 2,058 |  |  | 3,156 |  |
| Other long-term assets | 7,455 |  |  | 9,284 |  |
| Total other long-term assets | $ | 105,017 |  |  | $ | 127,519 |  |
| Accrued liabilities: |  |  |  |
| Operating lease liabilities, current portion | $ | 10,761 |  |  | $ | 12,947 |  |
| Customer fund liabilities | 56,703 |  |  | 31,727 |  |
| Advance payments from customers | 11,556 |  |  | 8,191 |  |
| Rebate liabilities | 42,802 |  |  | 44,644 |  |
| Group purchasing organization fees | 7,723 |  |  | 7,115 |  |
| Taxes payable | 9,642 |  |  | 3,771 |  |
| Other accrued liabilities | 33,468 |  |  | 24,772 |  |
| Total accrued liabilities | $ | 172,655 |  |  | $ | 133,167 |  |

[0000926326-23-000003:notes:196]
(1)    Includes restricted cash of $22.5 million and $6.6 million as of December 31, 2022 and 2021, respectively.

[0000926326-23-000003:notes:197]
The following table summarizes the changes in accumulated balances of other comprehensive loss, which consisted of foreign currency translation adjustments, for the years ended December 31, 2022 and 2021:

[0000926326-23-000003:notes:198]
|  | (In thousands) |  |
| Balance as of December 31, 2020 | $ | (5,522) |  |  |  |  |  |  |
| Other comprehensive loss | (2,885) |  |  |  |  |  |  |
| Balance as of December 31, 2021 | (8,407) |  |  |  |  |  |  |
| Other comprehensive loss | (8,680) |  |  |  |  |  |  |
| Balance as of December 31, 2022 | $ | (17,087) |  |  |  |  |  |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000926326-23-000003:notes:199]
Property and Equipment
The following table represents the property and equipment balances as of December 31, 2022 and 2021:

[0000926326-23-000003:notes:200]
Depreciation and amortization expense of property and equipment was $22.8 million, $20.1 million, and $18.3 million for the years ended December 31, 2022, 2021, and 2020, respectively.

[0000926326-23-000003:notes:201]
The geographic location of the Company’s property and equipment, net, is based on the physical location in which it is located. The following table summarizes the geographic information for property and equipment, net, as of December 31, 2022 and 2021:


## us-gaap:ResearchDevelopmentAndComputerSoftwareDisclosureTextBlock

[0000926326-23-000003:notes:202]
Software Development Costs for External Use 
The carrying amounts of capitalized software as of December 31, 2022 and 2021 were as follows:

[0000926326-23-000003:notes:203]
|  | December 31, |
|  | 2022 |  | 2021 |
|  | (In thousands) |
| Gross carrying amount | $ | 225,004 |  |  | $ | 214,362 |  |
| Accumulated amortization | (144,244) |  |  | (117,367) |  |
| Capitalized software, net (1) | $ | 80,760 |  |  | $ | 96,995 |  |

[0000926326-23-000003:notes:204]
(1)     Included in other long-term assets in the Consolidated Balance Sheets.

[0000926326-23-000003:notes:205]
The Company recorded $29.0 million, $26.4 million, and $23.1 million to cost of revenues for amortization of capitalized software development costs for the years ended December 31, 2022, 2021, and 2020, respectively.

[0000926326-23-000003:notes:206]
The estimated future amortization expenses for capitalized software were as follows:

[0000926326-23-000003:notes:207]
|  | December 31, 2022 |
|  | (In thousands) |
| 2023 | $ | 28,600 |  |
| 2024 | 22,792 |  |
| 2025 | 15,404 |  |
| 2026 | 9,865 |  |
| 2027 | 3,910 |  |
| Thereafter | 189 |  |
| Total | $ | 80,760 |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000926326-23-000003:notes:208]
Goodwill and Intangible Assets
Goodwill

[0000926326-23-000003:notes:209]
The following table represents changes in the carrying amount of goodwill:

[0000926326-23-000003:notes:210]
|  |  |  |  |  | (In thousands) |
| Balance as of December 31, 2020 |  |  |  |  | $ | 499,309 |  |
| Additions (1) |  |  |  |  | 242,964 |  |
| Measurement period adjustments (1) |  |  |  |  | (2,321) |  |
| Foreign currency exchange rate fluctuations |  |  |  |  | (1,052) |  |
| Balance as of December 31, 2021 |  |  |  |  | 738,900 |  |
| Additions (1) |  |  |  |  | 2,549 |  |
| Measurement period adjustments (1) |  |  |  |  | (3,770) |  |
| Foreign currency exchange rate fluctuations |  |  |  |  | (3,405) |  |
| Balance as of December 31, 2022 |  |  |  |  | $ | 734,274 |  |

[0000926326-23-000003:notes:211]
(1)     Refer to Note 2, Business Combinations, for further information.

[0000926326-23-000003:notes:212]
Intangible Assets, Net

[0000926326-23-000003:notes:213]
The carrying amounts and useful lives of intangible assets as of December 31, 2022 and 2021 were as follows:

[0000926326-23-000003:notes:214]
|  | December 31, 2022 |
|  | Gross carryingamount (1) |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 311,089 |  |  | $ | (99,177) |  |  | $ | (1,514) |  |  | $ | 210,398 |  |  | 4 - 30 |
| Acquired technology | 92,066 |  |  | (64,299) |  |  | — |  |  | 27,767 |  |  | 4 - 20 |
| Backlog | 1,800 |  |  | (900) |  |  | — |  |  | 900 |  |  | 2 |
| Trade names | 9,200 |  |  | (6,633) |  |  | — |  |  | 2,567 |  |  | 5 - 12 |
| Patents | 2,430 |  |  | (1,306) |  |  | — |  |  | 1,124 |  |  | 2 - 20 |
| Non-compete agreements | 600 |  |  | (450) |  |  | — |  |  | 150 |  |  | 3 |
| Total intangibles assets, net | $ | 417,185 |  |  | $ | (172,765) |  |  | $ | (1,514) |  |  | $ | 242,906 |  |  |  |

[0000926326-23-000003:notes:215]
|  | December 31, 2021 |
|  | Gross carryingamount (1) |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 309,989 |  |  | $ | (78,093) |  |  | $ | (933) |  |  | $ | 230,963 |  |  | 10 - 30 |
| Acquired technology | 95,466 |  |  | (55,859) |  |  | 6 |  |  | 39,613 |  |  | 4 - 20 |
| Backlog | 1,800 |  |  | — |  |  | — |  |  | 1,800 |  |  | 2 |
| Trade names | 9,200 |  |  | (5,600) |  |  | 14 |  |  | 3,614 |  |  | 5 - 12 |
| Patents | 2,462 |  |  | (1,186) |  |  | — |  |  | 1,276 |  |  | 2 - 20 |
| Non-compete agreements | 600 |  |  | (250) |  |  | — |  |  | 350 |  |  | 3 |
| Total intangibles assets, net | $ | 419,517 |  |  | $ | (140,988) |  |  | $ | (913) |  |  | $ | 277,616 |  |  |  |

[0000926326-23-000003:notes:216]
(1)     The differences in gross carrying amounts between periods are primarily due to the write-off of certain fully amortized intangible assets, partially offset by additions of intangible assets in connection with the Hub and Spoke Innovations acquisition.

[0000926326-23-000003:notes:217]
Amortization expense of intangible assets was $35.2 million, $26.5 million, and $19.7 million for the years ended December 31, 2022, 2021, and 2020, respectively.

[0000926326-23-000003:notes:218]
The estimated future amortization expenses for amortizable intangible assets were as follows:

[0000926326-23-000003:notes:219]
|  | December 31,2022 |
|  | (In thousands) |
| 2023 | $ | 31,467 |  |
| 2024 | 23,019 |  |
| 2025 | 21,035 |  |
| 2026 | 18,069 |  |
| 2027 | 16,384 |  |
| Thereafter | 132,932 |  |
| Total | $ | 242,906 |  |


## us-gaap:DebtDisclosureTextBlock

[0000926326-23-000003:notes:220]
Debt and Credit Agreement 
2019 Revolving Credit Facility

[0000926326-23-000003:notes:221]
On November 15, 2019, the Company entered into an Amended and Restated Credit Agreement (as subsequently amended as discussed below, the “A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers, and Wells Fargo Bank, National Association, as administrative agent. The A&R Credit Agreement superseded the Company’s 2016 secured credit facility and provides for (a) a five-year revolving credit facility of $500.0 million (the “Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million (the “Incremental Facility”). In addition, the A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The A&R Credit Agreement has an expiration date of November 15, 2024, upon which date all remaining outstanding borrowings will be due and payable.

[0000926326-23-000003:notes:222]
Loans under the Revolving Credit Facility bear interest, at the Company’s option, at a rate equal to either (a) the LIBOR Rate, plus an applicable margin ranging from 1.25% to 2.00% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the A&R Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) LIBOR for an interest period of one month plus 1.00%, plus an applicable margin ranging from 0.25% to 1.00% per annum based on the Company’s Consolidated Total Net Leverage Ratio. As of December 31, 2021, LIBOR has started being phased out and LIBOR is expected to be entirely discontinued on June 30, 2023. The A&R Credit Agreement provides that upon the occurrence of certain triggering events related to the end of LIBOR, the Company and the administrative agent will select an alternative benchmark rate to replace the LIBOR Rate. Upon the phasing out of LIBOR, the Company will work with its lenders to establish an alternative benchmark rate (such as the Secured Overnight Financing Rate) taking into account any relevant governmental body’s selection or recommendation of a replacement rate and/or the then-prevailing market convention for determining an alternative benchmark rate. The Company does not anticipate that the discontinuance or phasing out of the LIBOR Rate will materially impact its liquidity or financial position. Undrawn commitments under the Revolving Credit Facility are subject to a commitment fee ranging from 0.15% to 0.30% per annum based on the Company’s Consolidated Total Net Leverage Ratio on the average daily unused portion of the Revolving Credit Facility. The applicable margin for, and certain other terms of, any term loans under the Incremental Facility will be determined prior to the incurrence of such loans. The Company is permitted to make voluntary prepayments at any time without payment of a premium or penalty.

[0000926326-23-000003:notes:223]
On September 22, 2020, the parties entered into an amendment to the A&R Credit Agreement to, among other changes, permit the issuance of the convertible senior notes and the purchase of the convertible note hedge transactions, as described in Note 11, Convertible Senior Notes, expand the Company’s flexibility to repurchase its common stock and make other restricted payments, and replace the total net leverage covenant with a new secured net leverage covenant that requires the Company to maintain a consolidated secured net leverage ratio not to exceed 3.50:1 for the calendar quarters ending September 30, 2020, December 31, 2020, and March 31, 2021 and 3.00:1 for the calendar quarters ending thereafter.

[0000926326-23-000003:notes:224]
The A&R Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends, and other distributions. The A&R Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum total secured net leverage ratio (as described above) and maintain a minimum interest coverage ratio. In addition, the A&R Credit Agreement contains certain customary events of default including, but not limited to, failure to pay interest, principal, and fees, or other amounts when due, material misrepresentations or misstatements in any representation or warranty, covenant defaults, certain cross defaults to other material indebtedness, certain judgment defaults, and events of bankruptcy. The Company’s obligations under the A&R Credit Agreement and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and such subsidiary guarantors’ assets. In connection with entering into the A&R Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a reaffirmation agreement, which amends certain terms of the existing collateral agreement and reaffirms their obligations under the existing guaranty agreement. The Company was in compliance with all covenants as of December 31, 2022.

[0000926326-23-000003:notes:225]
As of December 31, 2022 and 2021, there was no outstanding balance for the Revolving Credit Facility.
Convertible Senior Notes
0.25% Convertible Senior Notes due 2025

[0000926326-23-000003:notes:226]
On September 25, 2020, the Company completed a private offering of $575.0 million aggregate principal amount of 0.25% convertible senior notes (the “Notes”), including the exercise in full of the initial purchasers’ option to purchase up to an additional $75.0 million principal amount of the Notes. The Company received proceeds from the issuance of the Notes of $559.7 million, net of $15.3 million of transaction fees and other debt issuance costs. The Notes bear interest at a rate of 0.25% per year, payable semiannually in arrears on March 15 and September 15 of each year, beginning on March 15, 2021. The Notes were issued pursuant to an indenture, dated September 25, 2020 (the “Indenture”), between the Company and U.S. Bank National Association, as trustee. The Notes are general senior, unsecured obligations of the Company and will mature on September 15, 2025, unless earlier redeemed, repurchased, or converted.

[0000926326-23-000003:notes:227]
The Notes are convertible at the option of the holders at any time prior to the close of business on the business day immediately preceding May 15, 2025, only under the following circumstances: (i) during any fiscal quarter commencing after the fiscal quarter ended on December 31, 2020 (and only during such fiscal quarter), if the last reported sale price of the Company’s common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on, and including, the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the Notes on each applicable trading day; (ii) during the five business day period after any ten consecutive trading day period (the “measurement period”) in which the trading price (as defined in the Indenture) per $1,000 principal amount of the Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of the Company’s common stock and the conversion rate for the Notes on each such trading day; (iii) if the Company calls such Notes for redemption, at any time prior to the close of business on the scheduled trading day immediately preceding the redemption date, but only with respect to the Notes called (or deemed called) for redemption; and (iv) upon the occurrence of specified corporate events, as specified in the Indenture. On or after May 15, 2025 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders of the Notes may convert all or any portion of their Notes at any time, regardless of the foregoing conditions.

[0000926326-23-000003:notes:228]
During the three months ended December 31, 2021, the conditional conversion feature of the Notes was triggered, based on the price of the Company’s common stock, as the last reported sale price of the Company’s common stock was greater than or equal to 130% of the then applicable conversion price for the Notes for at least 20 trading days during the period of 30 consecutive trading days ending on December 31, 2021, the last trading day of the respective fiscal quarter. Accordingly, the Notes were convertible during the first quarter of 2022 and were classified as a current liability in the Consolidated Financial Statements as of December 31, 2021. During the three months ended December 31, 2022, none of the conditional conversion features of the Notes were triggered, and therefore, the Notes are not convertible during the first quarter of 2023, commencing on January 1, 2023. Accordingly, the Company classified the Notes as a long-term liability in its Consolidated Financial Statements as of December 31, 2022. Whether the Notes will be convertible following the first fiscal quarter of 2023 will depend on the satisfaction of the conversion conditions in the future.

[0000926326-23-000003:notes:229]
Under the original terms of the Indenture, upon conversion, the Company could satisfy its conversion obligation by paying or delivering cash, shares of its common stock, or a combination thereof, at the Company’s election, in the manner and subject to the terms and conditions provided in the Indenture. On December 13, 2021, the Company irrevocably elected to fix its settlement method to a combination of cash and shares of the Company’s common stock with the specified cash amount per $1,000 principal amount of Notes of at least $1,000. As a result, for Notes converted on or after December 13, 2021, a converting noteholder will receive (i) up to $1,000 in cash per $1,000 principal amount of Notes and (ii) cash and/or shares of the Company’s common stock, at the Company’s option for any conversion consideration in excess of $1,000. In addition, the Company continues to have the ability to set the specified cash amount per $1,000 principal amount of Notes above $1,000. The initial conversion rate for the Notes is 10.2751 shares of the Company’s common stock per $1,000 principal amount of Notes, which is equivalent to an initial conversion price of approximately $97.32 per share of the Company’s common stock, subject to adjustment under certain circumstances in accordance with the terms of the Indenture. In addition, following certain corporate events that could occur prior to the maturity date of the Notes or if the Company delivers a notice of redemption in respect of the Notes, the Company will, under certain circumstances, increase the conversion rate of the Notes for a holder who elects to convert its Notes (or any portion thereof) in connection with such a corporate event or convert its Notes called (or deemed called) for redemption during the related redemption period (as defined in the Indenture), as the case may be.

[0000926326-23-000003:notes:230]
If the Company undergoes a fundamental change, holders may require, subject to certain exceptions, the Company to repurchase for cash all or any portion of their Notes at a fundamental change repurchase price equal to 100% of the principal amount of the Notes to be repurchased, plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date. As of December 31, 2022, none of the criteria for a fundamental change or a conversion rate adjustment had been met.

[0000926326-23-000003:notes:231]
The Company may not redeem the Notes prior to September 20, 2023. The Company may redeem for cash all or any portion of the Notes, at its option, on or after September 20, 2023, if the last reported sale price of the Company’s common stock has been at least 130% of the conversion price for the Notes then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which the Company provides notice of redemption at a redemption price equal to 100% of the principal amount of the Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. If the Company redeems less than all of the outstanding Notes, at least $150.0 million aggregate principal amount of Notes must be outstanding and not subject to redemption as of the date of the relevant notice of redemption. No sinking fund is provided for in the Notes.

[0000926326-23-000003:notes:232]
Prior to the adoption of ASU 2020-06, convertible debt instruments that could be settled in cash were required to be separated into liability and equity components. The allocation to the liability component was based on the fair value of a similar instrument that did not contain an equity conversion option. Based on this debt-to-equity ratio, debt issuance costs were then allocated to the liability and equity components in a similar manner. Accordingly, at issuance, the Company allocated $461.8 million to the debt liability and $72.7 million to additional paid-in capital, net of applicable issuance costs and deferred taxes. The difference between the principal amount of the Notes and the liability component, inclusive of issuance costs, represented the debt discount, which the Company amortized to interest expense over the term of the Notes using an effective interest rate of 4.18%. The determination of the discount rate required certain estimates and assumptions.

[0000926326-23-000003:notes:233]
Upon adoption of ASU 2020-06, effective January 1, 2022, the Notes are no longer separated into liability and equity components, and are accounted for as a single liability measured at its amortized cost. Refer to Note 1, Organization and Summary of Significant Accounting Policies, for further information.

[0000926326-23-000003:notes:234]
As of December 31, 2022, the remaining life of the Notes and the related issuance cost accretion is approximately 2.7 years.

[0000926326-23-000003:notes:235]
The maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to other conversion rate adjustments, would be 5.9 million shares. As of December 31, 2022, the if-converted value of the Notes did not exceed the principal amount.

[0000926326-23-000003:notes:236]
The Notes consisted of the following balances reported in the Consolidated Balance Sheets as of December 31, 2022 and 2021:

[0000926326-23-000003:notes:237]
|  | December 31, |
|  | 2022 (2) |  | 2021 |
|  | (In thousands) |
| Liability: |  |  |  |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized discount | — |  |  | (77,136) |  |
| Unamortized debt issuance costs | (8,429) |  |  | (9,712) |  |
| Convertible senior notes, liability component (1) | $ | 566,571 |  |  | $ | 488,152 |  |
| Convertible senior notes, equity component | $ | — |  |  | $ | 72,732 |  |

[0000926326-23-000003:notes:238]
(1)    Classified as a long-term liability as of December 31, 2022, and a current liability as of December 31, 2021, in the Consolidated Balance Sheets.

[0000926326-23-000003:notes:239]
(2)    Refer to Note 1, Organization and Summary of Significant Accounting Policies, for further information regarding the impact of the adoption of ASU 2020-06, effective January 1, 2022.

[0000926326-23-000003:notes:240]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Consolidated Statements of Operations for the years ended December 31, 2022, 2021 and 2020:

[0000926326-23-000003:notes:241]
|  | Year Ended December 31, |  |  |
|  | 2022 (1) |  | 2021 |  | 2020 |  |  |
|  | (In thousands) |
| Contractual coupon interest | $ | 1,438 |  |  | $ | 1,438 |  |  | $ | 379 |  |  |  |
| Amortization of discount | $ | — |  |  | $ | 18,608 |  |  | $ | 4,766 |  |  |  |
| Amortization of debt issuance costs | $ | 3,066 |  |  | $ | 2,343 |  |  | $ | 600 |  |  |  |

[0000926326-23-000003:notes:242]
(1)    Refer to Note 1, Organization and Summary of Significant Accounting Policies, for further information regarding the impact of the adoption of ASU 2020-06, effective January 1, 2022.

[0000926326-23-000003:notes:243]
Convertible Note Hedge and Warrant Transactions

[0000926326-23-000003:notes:244]
In connection with the issuance of the Notes in September 2020, the Company entered into convertible note hedge and warrant transactions with an affiliate of one of the initial purchasers of the Notes and certain other financial institutions (the “option counterparties”) with respect to the Company’s common stock.

[0000926326-23-000003:notes:245]
The convertible note hedge consists of an option for the Company to purchase up to approximately 5.9 million shares of the Company’s common stock, which is equal to the number of shares of the Company’s common stock underlying the Notes, at an initial strike price of approximately $97.32 per share. The convertible note hedge will expire upon the maturity of the Notes, if not earlier exercised or terminated. The cost of the convertible note hedge was approximately $100.6 million and was accounted for as an equity instrument, which was recorded in additional paid-in capital in the Consolidated Balance Sheets. The Company recorded a deferred tax asset of $25.8 million at issuance related to the convertible note hedge transaction. The convertible note hedge is expected generally to reduce the potential dilution to the Company’s common stock upon any conversion of Notes and/or offset any cash payments the Company is required to make in excess of the principal amount of converted Notes.
Separately from the convertible note hedge, the Company entered into warrant transactions to sell to the option counterparties warrants to acquire, subject to customary anti-dilution adjustments, up to approximately 5.9 million shares of its common stock in the aggregate at an initial strike price of $141.56 per share. The warrants require net share or net cash settlement upon the Company’s election. The Company received aggregate proceeds of approximately $51.3 million for the issuance of the warrants, which was recorded in additional paid-in capital at issuance in the Consolidated Balance Sheets. The warrants could separately have a dilutive effect to the Company’s common stock to the extent that the market price per share of its common stock exceeds the strike price of the warrants.


## us-gaap:LessorSalesTypeLeasesTextBlock

[0000926326-23-000003:notes:246]
Lessor Leases
Sales-Type Leases

[0000926326-23-000003:notes:247]
On a recurring basis, the Company enters into multi-year, sales-type lease agreements with the majority of such leases varying in length from one to five years. The following table presents the Company’s income recognized from sales-type leases for the years ended December 31, 2022, 2021, and 2020:

[0000926326-23-000003:notes:248]
|  | Year Ended December 31, |
|  | 2022 |  | 2021 |  | 2020 |
|  | (In thousands) |
| Sales-type lease revenues | $ | 38,959 |  |  | $ | 21,887 |  |  | $ | 26,040 |  |
| Cost of sales-type lease revenues | (19,359) |  |  | (8,918) |  |  | (10,624) |  |
| Selling profit on sales-type lease revenues | $ | 19,600 |  |  | $ | 12,969 |  |  | $ | 15,416 |  |
| Interest income on sales-type lease receivables | $ | 2,106 |  |  | $ | 1,869 |  |  | $ | 1,933 |  |

[0000926326-23-000003:notes:249]
The receivables as a result of these types of transactions are collateralized by the underlying equipment leased and consist of the following components at December 31, 2022 and 2021:

[0000926326-23-000003:notes:250]
|  | December 31, |
|  | 2022 |  | 2021 |
|  | (In thousands) |
| Net minimum lease payments to be received | $ | 50,755 |  |  | $ | 31,444 |  |
| Less: Unearned interest income portion | (6,345) |  |  | (2,388) |  |
| Net investment in sales-type leases | 44,410 |  |  | 29,056 |  |
| Less: Current portion (1) | (11,486) |  |  | (10,665) |  |
| Long-term investment in sales-type leases, net | $ | 32,924 |  |  | $ | 18,391 |  |

[0000926326-23-000003:notes:251]
(1)    The current portion of the net investment in sales-type leases is included in other current assets in the Consolidated Balance Sheets.

[0000926326-23-000003:notes:252]
The carrying amount of the Company’s sales-type lease receivables is a reasonable estimate of fair value.

[0000926326-23-000003:notes:253]
The maturity schedule of future minimum lease payments under sales-type leases retained in-house and the reconciliation to the net investment in sales-type leases reported on the Consolidated Balance Sheets was as follows:

[0000926326-23-000003:notes:254]
|  | December 31,2022 |
|  | (In thousands) |
| 2023 | $ | 13,296 |  |
| 2024 | 10,343 |  |
| 2025 | 8,465 |  |
| 2026 | 6,684 |  |
| 2027 | 5,718 |  |
| Thereafter | 6,249 |  |
| Total future minimum sales-type lease payments | 50,755 |  |
| Present value adjustment | (6,345) |  |
| Total net investment in sales-type leases | $ | 44,410 |  |

[0000926326-23-000003:notes:255]
The Company entered into certain leasing agreements that were classified as operating leases prior to the adoption of ASC 842, Leases. These agreements in place prior to January 1, 2019 continue to be treated as operating leases, however any leasing agreements entered into on or after January 1, 2019 under these programs are classified and accounted for as sales-type leases in accordance with ASC 842. The operating lease arrangements generally have initial terms of one to seven years.

[0000926326-23-000003:notes:256]
The following table represents the Company’s income recognized from operating leases for the years ended December 31, 2022, 2021, and 2020:

[0000926326-23-000003:notes:257]
|  | Year Ended December 31, |
|  | 2022 |  | 2021 |  | 2020 |
|  | (In thousands) |
| Rental income | $ | 9,460 |  |  | $ | 10,467 |  |  | $ | 11,668 |  |

[0000926326-23-000003:notes:258]
The maturity schedule of future minimum lease payments under operating leases was as follows:

[0000926326-23-000003:notes:259]
|  | December 31, 2022 |
|  | (In thousands) |
| 2023 | $ | 5,091 |  |
| 2024 | 866 |  |
| 2025 | 256 |  |
| 2026 | 89 |  |
| 2027 | — |  |
| Thereafter | — |  |
| Total future minimum operating lease payments | $ | 6,302 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0000926326-23-000003:notes:260]
Lessee Leases
The Company has operating leases for office buildings, data centers, office equipment, and vehicles. The Company’s leases have initial terms of one to 12 years. As of December 31, 2022, the Company did not have any additional material operating leases that were entered into, but not yet commenced.

[0000926326-23-000003:notes:261]
The maturity schedule of future minimum lease payments under operating leases and the reconciliation to the operating lease liabilities reported on the Consolidated Balance Sheets was as follows:

[0000926326-23-000003:notes:262]
|  | December 31, 2022 |
|  | (In thousands) |
| 2023 | $ | 13,280 |  |
| 2024 | 12,136 |  |
| 2025 | 9,350 |  |
| 2026 | 8,769 |  |
| 2027 | 7,167 |  |
| Thereafter | 7,140 |  |
| Total operating lease payments | 57,842 |  |
| Present value adjustment | (7,676) |  |
| Total operating lease liabilities (1) | $ | 50,166 |  |

[0000926326-23-000003:notes:263]
(1)    Amount consists of a current and long-term portion of operating lease liabilities of $10.8 million and $39.4 million, respectively. The current portion of the operating lease liabilities is included in accrued liabilities in the Consolidated Balance Sheets.

[0000926326-23-000003:notes:264]
Operating lease costs were $18.9 million, $15.0 million, and $14.3 million for the years ended December 31, 2022, 2021, and 2020, respectively. Short-term lease costs and variable lease costs were not material for the years ended December 31, 2022, 2021, and 2020. During the year ended December 31, 2022, the Company recorded impairment and abandonment charges to operating lease right-of-use assets of $9.4 million, in connection with restructuring activities for optimization of certain leased facilities. The impairment and abandonment charges were recorded to selling, general, and administrative expenses on the Company’s Consolidated Statements of Operations.

[0000926326-23-000003:notes:265]
The following table summarizes supplemental cash flow information related to the Company’s operating leases for the years ended December 31, 2022, 2021, and 2020:

[0000926326-23-000003:notes:266]
|  | Year Ended December 31, |
|  | 2022 |  | 2021 |  | 2020 |
|  | (In thousands) |
| Cash paid for amounts included in the measurement of lease liabilities | $ | 16,452 |  |  | $ | 15,625 |  |  | $ | 14,490 |  |
| Right-of-use assets obtained in exchange for new lease liabilities | $ | 12,372 |  |  | $ | 5,503 |  |  | $ | 10,025 |  |

[0000926326-23-000003:notes:267]
The following table summarizes the weighted-average remaining lease term and weighted-average discount rate related to the Company’s operating leases as of December 31, 2022 and 2021:

[0000926326-23-000003:notes:268]
|  | December 31, |
|  | 2022 |  | 2021 |
| Weighted-average remaining lease term, years | 5.0 |  | 5.2 |
| Weighted-average discount rate, % | 5.7 | % |  | 5.5 | % |


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000926326-23-000003:notes:269]
Commitments and Contingencies
Purchase Obligations

[0000926326-23-000003:notes:270]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of December 31, 2022, the Company had non-cancelable purchase commitments of $159.7 million, of which $146.3 million are expected to be paid within the next twelve months.

[0000926326-23-000003:notes:271]
Ransomware Incident

[0000926326-23-000003:notes:272]
On May 4, 2022, the Company determined that certain of its information technology systems were affected by ransomware impacting certain internal systems. Upon detecting the security event, the Company took immediate steps designed to contain the incident and implement its business continuity plans to restore and support continued operations. The Company has contained the incident and restored substantially all of its critical information technology systems.

[0000926326-23-000003:notes:273]
During the year ended December 31, 2022, the Company incurred $13.6 million of expenses related to the ransomware incident, partially offset by $11.1 million of expected insurance recoveries. Expenses include costs to investigate and remediate the ransomware incident, as well as legal and other professional services, all of which were expensed as incurred. For the year ended December 31, 2022, the Company included net expenses related to the ransomware incident in cost of revenues of $0.3 million, in research and development of $0.2 million, and in selling general and administrative expenses of $2.0 million, in the Company’s Consolidated Statements of Operations.

[0000926326-23-000003:notes:274]
Legal Proceedings

[0000926326-23-000003:notes:275]
The Company is currently involved in various legal proceedings.

[0000926326-23-000003:notes:276]
A class action lawsuit was filed against the Company, on June 5, 2019, in the Circuit Court of Cook County, Illinois, Chancery Division, captioned Corey Heard, individually and on behalf of all others similarly situated v. Omnicell, Inc., Case No. 2019-CH-06817 (the “Heard Action”). The complaint seeks class certification, monetary damages in the form of statutory damages for willful and/or reckless or, in the alternative, negligent violation of the Illinois Biometric Information Privacy Act (“BIPA”), and certain declaratory, injunctive, and other relief based on causes of action directed to allegations of violation of BIPA by the Company. The complaint was served on the Company on June 13, 2019. On July 31, 2019, the Company filed a motion to stay or consolidate the case with the action Yana Mazya, et al. v. Northwestern Lake Forest Hospital, et al., Case No. 2018-CH-07161, pending in the Circuit Court of Cook County, Illinois, Chancery Division (the “Mazya Action”). The Court subsequently, on October 10, 2019, denied the motion, without prejudice, as being moot in view of the dismissal of the claims against the Company in the Mazya Action. The Company filed a motion to dismiss the complaint in the Heard Action on October 31, 2019. The hearing on the Company’s motion to dismiss was held on September 2, 2020. The Court ruled from the bench and dismissed the complaint without prejudice giving plaintiff leave to file an amended complaint by September 30, 2020. Plaintiff filed an amended complaint on September 30, 2020 and the Company subsequently filed a motion to dismiss the amended complaint on October 28, 2020, which was fully briefed, but the Court had not heard oral argument on the motion. The parties entered into a settlement agreement on January 25, 2022, (the “Settlement Agreement”). On February 1, 2022, the Court granted preliminary approval of the settlement. Following preliminary approval, plaintiff conducted discovery to identify class members and to determine the class size. Pursuant to the terms of the Settlement Agreement, and following class size discovery, the parties participated in non-binding mediation on November 21, 2022. A settlement was reached at the mediation and the parties executed an addendum to the Settlement Agreement (the “Addendum”) reflecting the changes to the original settlement terms. On November 30, 2022, the Court granted preliminary approval of the settlement including the Addendum. The hearing on final approval of the settlement is currently set for April 6, 2023. Subject to final approval of the settlement, the Company intends to defend the lawsuit vigorously.

[0000926326-23-000003:notes:277]
As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any material accrual for contingent liabilities associated with the legal proceeding described above based on its belief that any potential material loss, while reasonably possible, is not probable. Further, the estimated range of loss in this matter is not deemed material. The

[0000926326-23-000003:notes:278]
Company believes that it has valid defenses with respect to the legal proceeding pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of the legal proceeding or because of the diversion of management’s attention and the creation of significant expenses.

[0000926326-23-000003:notes:279]
Guarantees

[0000926326-23-000003:notes:280]
Under the Company’s certificate of incorporation and bylaws, the Company has agreed to indemnify its directors and executive officers to the fullest extent not prohibited by Delaware and other applicable law, subject to certain exceptions. The Company has entered into individual indemnification agreements with its directors and officers. The term of the indemnification period is for the entirety of the director’s or officer’s service to the Company and continues so long as the director or officer may be subject to any claim, action, or proceeding, and there is no limit on the potential amount of future payments that the Company could be required to make under these indemnification agreements. The Company has purchased a directors’ and officers’ liability insurance policy that may enable it to recover a portion of any future payments that it may be required to make under these indemnification agreements. Assuming the applicability of coverage and the willingness of the insurer to assume coverage and subject to certain retention, loss limits, and other policy provisions, the Company believes it is unlikely that the Company will be required to pay any material amounts pursuant to these indemnification obligations. However, no assurances can be given that the insurers will not attempt to dispute the validity, applicability, or amount of coverage without expensive and time-consuming litigation against the insurers.

[0000926326-23-000003:notes:281]
Additionally, the Company undertakes indemnification obligations in its ordinary course of business in connection with, among other things, the licensing of its products and the provision of its support services. In the ordinary course of the Company’s business, the Company has in the past and may in the future agree to indemnify another party, generally its business affiliates or customers, against certain losses suffered or incurred by the indemnified party in connection with various types of claims, which may include, without limitation, claims of intellectual property infringement, certain tax liabilities, its gross negligence or intentional acts in the performance of support services, and violations of laws. The term of these indemnification obligations is generally perpetual. In general, the Company attempts to limit the maximum potential amount of future payments that it may be required to make under these indemnification obligations to the amounts paid to it by a customer, but in some cases the obligation may not be so limited.

[0000926326-23-000003:notes:282]
In addition, the Company has in the past and may in the future warrant to its customers that its products will conform to functional specifications for a limited period of time following the date of installation (generally not exceeding 30 days) or that its software media is free from material defects. Sales contracts for certain of the Company’s medication packaging systems may have in the past and may in the future include limited warranties for up to six months, but the periodic activity and ending warranty balances the Company records have historically not been material.

[0000926326-23-000003:notes:283]
From time to time, the Company may also warrant that its professional services will be performed in a good and workmanlike manner or in a professional manner consistent with industry standards. The Company generally seeks to disclaim most warranties, including any implied or statutory warranties such as warranties of merchantability, fitness for a particular purpose, title, quality, and non-infringement, as well as any liability with respect to incidental, consequential, special, exemplary, punitive, or similar damages. In some states, such disclaimers may not be enforceable. If necessary, the Company would provide for the estimated cost of product and service warranties based on specific warranty claims and claim history. The Company has not been subject to any significant claims for such losses and has not incurred any material costs in defending or settling claims related to these indemnification obligations. Accordingly, the Company believes it is unlikely that the Company will be required to pay any material amounts pursuant to these indemnification obligations or potential warranty claims and, therefore, no material liabilities have been recorded for such indemnification obligations as of December 31, 2022 and 2021.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000926326-23-000003:notes:284]
Employee Benefits and Share-Based Compensation
Stock Purchase Plan

[0000926326-23-000003:notes:285]
1997 Employee Stock Purchase Plan

[0000926326-23-000003:notes:286]
The Company has an Employee Stock Purchase Plan (“ESPP”), under which employees can purchase shares of its common stock based on a percentage of their compensation, but not greater than 15% of their earnings; provided, however, an eligible employee’s right to purchase shares of the Company’s common stock may not accrue at a rate which exceeds $25,000 of the fair market value of such shares for each calendar year in which such rights are outstanding. The purchase price per share must be equal to the lower of 85% of the fair value of the common stock at the beginning of a 24-month offering period or the end of each six-month purchasing period.

[0000926326-23-000003:notes:287]
There was a total of 0.6 million shares reserved for future issuance under the ESPP as of December 31, 2022.

[0000926326-23-000003:notes:288]
Stock Award Plans

[0000926326-23-000003:notes:289]
2009 Equity Incentive Plan

[0000926326-23-000003:notes:290]
The 2009 Equity Incentive Plan (“2009 Plan”), as amended, provides for the issuance of incentive stock options, RSAs, RSUs, PSUs, and other stock awards to the Company’s employees, directors, and consultants. There were 5.1 million shares of common stock reserved for future issuance under the 2009 Plan as of December 31, 2022.

[0000926326-23-000003:notes:291]
Options granted under the 2009 Plan generally become exercisable over periods of up to four years, with one-fourth of the shares vesting one year from the vesting commencement date with respect to initial grants, and the remaining shares vesting in 36 equal monthly installments thereafter. The exercise prices of the options is the fair market value of common stock on the date of grant. RSUs generally vest over periods of up to four years, with one-fourth of the shares vesting one year from the vesting commencement date with respect to initial grants, and the remaining shares vesting in 12 equal quarterly installments thereafter. Awards of restricted stock to non-employee directors are granted on the date of the annual meeting of stockholders and vest in full on the date of the next annual meeting of stockholders, provided such non-employee director remains a director on such date. The fair value of the awards on the date of issuance is amortized to expense from the date of grant to the date of vesting and are expensed ratably on a straight-line basis over the vesting period. PSUs granted to the Company’s executives may include performance and market conditions. PSUs become eligible for vesting when certain market or performance conditions are met.

[0000926326-23-000003:notes:292]
Share-Based Compensation Expense

[0000926326-23-000003:notes:293]
The following table sets forth the total share-based compensation expense recognized in the Company’s Consolidated Statements of Operations:

[0000926326-23-000003:notes:294]
|  | Year Ended December 31, |
|  | 2022 |  | 2021 |  | 2020 |
|  | (In thousands) |
| Cost of product and service revenues | $ | 9,067 |  |  | $ | 7,994 |  |  | $ | 7,469 |  |
| Research and development | 11,368 |  |  | 7,663 |  |  | 6,497 |  |
| Selling, general, and administrative | 47,812 |  |  | 37,503 |  |  | 30,731 |  |
| Total share-based compensation expense | $ | 68,247 |  |  | $ | 53,160 |  |  | $ | 44,697 |  |

[0000926326-23-000003:notes:295]
The Company did not capitalize any material share-based compensation amounts to inventory, capitalized software, or internal-use software for the years ended December 31, 2022 and 2021. Income tax benefits realized from share-based compensation were $5.2 million, $26.6 million, and $10.3 million, for the years ended December 31, 2022, 2021, and 2020, respectively.

[0000926326-23-000003:notes:296]
Employee Stock Purchase Plan (“ESPP”)

[0000926326-23-000003:notes:297]
The following assumptions were used to value shares granted under the ESPP for the years ended December 31, 2022, 2021, and 2020:

[0000926326-23-000003:notes:298]
|  | Year Ended December 31, |
|  | 2022 |  | 2021 |  | 2020 |
| Expected life, years | 0.5 - 2.0 |  | 0.5 - 2.0 |  | 0.5 - 2.0 |
| Expected volatility, % | 28.8% - 45.6% |  | 27.4% - 53.5% |  | 30.4% - 53.5% |
| Risk-free interest rate, % | 0.1% - 3.2% |  | 0.1% - 2.6% |  | 0.1% - 2.7% |
| Dividend yield, % | — | % |  | — | % |  | — | % |

[0000926326-23-000003:notes:299]
For the years ended December 31, 2022 and 2021, employees purchased approximately 316,000 and 287,000 shares of common stock, respectively, under the ESPP at a weighted-average price of $67.63 and $62.14, respectively. As of December 31, 2022, the unrecognized compensation cost related to the shares to be purchased under the ESPP was approximately $2.5 million and is expected to be recognized over a weighted-average period of 1.3 years.

[0000926326-23-000003:notes:300]
Stock Options

[0000926326-23-000003:notes:301]
The following assumptions were used to value stock options granted pursuant to the 2009 Plan for the years ended December 31, 2021 and 2020. There were no stock options granted during the year ended December 31, 2022:

[0000926326-23-000003:notes:302]
|  |  |  | Year Ended December 31, |
|  |  |  | 2021 |  | 2020 |
| Expected life, years |  |  | 4.9 |  | 4.7 |
| Expected volatility, % |  |  | 31.5 | % |  | 39.4 | % |
| Risk-free interest rate, % |  |  | 0.9 | % |  | 0.7 | % |
| Estimated forfeiture rate, % |  |  | 7.9 | % |  | 5.7 | % |
| Dividend yield, % |  |  | — | % |  | — | % |

[0000926326-23-000003:notes:303]
The following table summarizes the stock option activity under the 2009 Plan during the year ended December 31, 2022:

[0000926326-23-000003:notes:304]
|  | Number ofShares |  | Weighted-AverageExercise Price |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2021 | 2,954 |  |  | $ | 67.35 |  |  | 6.9 |  | $ | 334,119 |  |
| Granted | — |  |  | — |  |  |  |  |  |
| Exercised | (367) |  |  | 51.20 |  |  |  |  |  |
| Expired | (35) |  |  | 86.92 |  |  |  |  |  |
| Forfeited | (118) |  |  | 84.92 |  |  |  |  |  |
| Outstanding at December 31, 2022 | 2,434 |  |  | $ | 68.65 |  |  | 6.1 |  | $ | 7,887 |  |
| Exercisable at December 31, 2022 | 1,866 |  |  | $ | 63.81 |  |  | 5.8 |  | $ | 7,887 |  |
| Vested and expected to vest at December 31, 2022 and thereafter | 2,396 |  |  | $ | 68.35 |  |  | 6.1 |  | $ | 7,887 |  |

[0000926326-23-000003:notes:305]
The weighted-average fair value per share of options granted during the years ended December 31, 2021 and 2020 was $35.17 and $26.48, respectively. The intrinsic value of options exercised during the years ended December 31, 2022, 2021, and 2020 was $23.9 million, $88.0 million, and $39.8 million, respectively. The tax benefit realized from stock options exercised was $4.4 million, $18.3 million, and $7.1 million, for the years ended December 31, 2022, 2021, and 2020, respectively.

[0000926326-23-000003:notes:306]
As of December 31, 2022, total unrecognized compensation cost related to unvested stock options was $16.4 million, which is expected to be recognized over a weighted-average vesting period of 1.4 years.

[0000926326-23-000003:notes:307]
Restricted Stock Units (“RSUs”)

[0000926326-23-000003:notes:308]
The following table summarizes the RSU activity under the 2009 Plan during the year ended December 31, 2022:

[0000926326-23-000003:notes:309]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2021 | 763 |  |  | $ | 119.93 |  |  | 1.6 |  | $ | 137,696 |  |
| Granted (Awarded) | 746 |  |  | 111.12 |  |  |  |  |  |
| Vested (Released) | (276) |  |  | 111.17 |  |  |  |  |  |
| Forfeited | (116) |  |  | 124.29 |  |  |  |  |  |
| Outstanding and unvested at December 31, 2022 | 1,117 |  |  | $ | 115.75 |  |  | 1.6 |  | $ | 56,297 |  |

[0000926326-23-000003:notes:310]
The weighted-average grant date fair value per share of RSUs granted during the years ended December 31, 2022, 2021, and 2020 was $111.12, $149.65, and $74.52, respectively. The total fair value of RSUs that vested in the years ended December 31, 2022, 2021, and 2020 was $30.7 million, $16.7 million, and $11.2 million, respectively.

[0000926326-23-000003:notes:311]
As of December 31, 2022, total unrecognized compensation cost related to RSUs was $104.7 million, which is expected to be recognized over the remaining weighted-average vesting period of 3.1 years.

[0000926326-23-000003:notes:312]
Restricted Stock Awards (“RSAs”)

[0000926326-23-000003:notes:313]
The following table summarizes the RSA activity under the 2009 Plan during the year ended December 31, 2022:

[0000926326-23-000003:notes:314]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |  |  |  |  |  |  |  |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2021 | 11 |  |  | $ | 137.36 |  |  |  |  |  |  |  |  |
| Granted (Awarded) | 13 |  |  | 109.39 |  |  |  |  |  |  |  |  |
| Vested (Released) | (11) |  |  | 137.36 |  |  |  |  |  |  |  |  |
| Outstanding and unvested at December 31, 2022 | 13 |  |  | $ | 109.39 |  |  |  |  |  |  |  |  |

[0000926326-23-000003:notes:315]
The weighted-average grant date fair value per share of RSAs granted during the years ended December 31, 2022, 2021, and 2020 was $109.39, $137.36, and $68.11, respectively. The total fair value of RSAs that vested in the years ended December 31, 2022, 2021, and 2020 was $1.6 million, $1.4 million, and $1.4 million, respectively.

[0000926326-23-000003:notes:316]
As of December 31, 2022, total unrecognized compensation cost related to RSAs was $0.5 million, which is expected to be recognized over the remaining weighted-average vesting period of 0.4 years.

[0000926326-23-000003:notes:317]
Performance-Based Stock Unit Awards (“PSUs”)

[0000926326-23-000003:notes:318]
During the year ended December 31, 2021, the Company granted 51,110 PSUs to its executive officers, all of which became eligible for vesting upon the achievement of a certain level of shareholder return. During the year ended December 31, 2022, the Company granted 56,237 PSUs to its executive officers, of which 0% to 200% may become eligible for vesting depending on the level of shareholder return for the period from March 1, 2022 through March 1, 2023.

[0000926326-23-000003:notes:319]
The number of shares that vest at the end of the performance period depends on the percentile ranking of the total shareholder return for Omnicell stock over the performance period relative to the total shareholder return of each of the other companies in the NASDAQ Health Care Index. Stock price appreciation is calculated based on the trailing 20-day average stock price just prior to the first trading day of March in the grant year, compared to the trailing 20-day average stock price just prior to the first trading day of March in the year subsequent to the grant year. The fair value of PSU awards to executive officers is determined using a Monte Carlo simulation model.

[0000926326-23-000003:notes:320]
PSUs generally vest over periods of up to four years, with one-fourth of the shares vesting approximately one year from the vesting commencement date with respect to initial grants and upon confirmation by the Compensation Committee that the performance target has been met, and the remaining shares vesting in six equal semi-annual installments thereafter. Vesting is contingent upon continued service.

[0000926326-23-000003:notes:321]
In addition to executive officers’ PSU awards, from time to time, the Company may grant PSUs with specific performance and service conditions to certain employees on an ad hoc basis.

[0000926326-23-000003:notes:322]
The following table summarizes the PSU activity under the 2009 Plan during the year ended December 31, 2022:

[0000926326-23-000003:notes:323]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value Per Unit |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2021 | 144 |  |  | $ | 118.71 |  |
| Granted | 78 |  |  | 155.27 |  |
| Additional granted based on performance achievement | 51 |  |  | 156.79 |  |
| Vested | (123) |  |  | 122.50 |  |
| Forfeited | (15) |  |  | 148.79 |  |
| Outstanding and unvested at December 31, 2022 | 135 |  |  | $ | 147.42 |  |

[0000926326-23-000003:notes:324]
The weighted-average grant date fair value per share of PSUs granted during the years ended December 31, 2022, 2021, and 2020 was $155.27, $162.16, and $82.17, respectively. The total fair value of PSUs that vested in the years ended December 31, 2022, 2021, and 2020 was $15.0 million, $4.4 million, and $3.7 million, respectively.

[0000926326-23-000003:notes:325]
As of December 31, 2022, total unrecognized compensation cost related to PSUs was approximately $5.8 million, which is expected to be recognized over the remaining weighted-average vesting period of 1.1 years.

[0000926326-23-000003:notes:326]
Summary of Shares Reserved for Future Issuance under Equity Incentive Plans

[0000926326-23-000003:notes:327]
The Company had the following ordinary shares reserved for future issuance under its equity incentive plans as of December 31, 2022:

[0000926326-23-000003:notes:328]
|  | Number of Shares |
|  | (In thousands) |
| Share options outstanding | 2,434 |  |
| Non-vested restricted stock awards | 1,265 |  |
| Shares authorized for future issuance | 1,359 |  |
| ESPP shares available for future issuance | 603 |  |
| Total shares reserved for future issuance | 5,661 |  |

[0000926326-23-000003:notes:329]
401(k) Plan
The Company has established a pre-tax savings plan under Section 401(k) of the Internal Revenue Code of 1986, as amended. The 401(k) Plan allows eligible employees in the United States to voluntarily contribute a portion of their pre-tax salary, subject to a maximum limit specified in the Internal Revenue Code. The Company generally matches 50% of employee contributions up to $3,000, annually. The Company’s contributions under this plan were $8.1 million, $6.8 million, and $5.7 million in the years ended December 31, 2022, 2021, and 2020, respectively.


## us-gaap:TreasuryStockTextBlock

[0000926326-23-000003:notes:330]
Stock Repurchase Programs
On August 2, 2016, the Company’s Board of Directors (the “Board”) authorized a stock repurchase program providing for the repurchase of up to $50.0 million of the Company’s common stock (the “2016 Repurchase Program”). The 2016 Repurchase Program is in addition to the stock repurchase program approved by the Board on November 4, 2014 providing for the repurchase of up to $50.0 million of the Company’s common stock (the “2014 Repurchase Program”). During the year ended December 31, 2022, the 2014 Repurchase Program was completed, and as of December 31, 2022, the maximum dollar value of shares that may yet be purchased under the 2016 Repurchase Program was $2.7 million.

[0000926326-23-000003:notes:331]
The timing, price, and volume of repurchases are to be based on market conditions, relevant securities laws, and other factors. The stock repurchases may be made from time to time on the open market, in privately negotiated transactions, or pursuant to a Rule 10b-18 plan, subject to the terms and conditions of that certain A&R Credit Agreement, as amended. The stock repurchase programs do not obligate the Company to repurchase any specific number of shares, and the Company may terminate or suspend the repurchase programs at any time.

[0000926326-23-000003:notes:332]
On September 17, 2020, the Board authorized a one-time stock repurchase transaction providing for the repurchase of up to $75.0 million of the Company’s common stock in privately negotiated transactions concurrently with the issuance of the Notes, described in Note 11, Convertible Senior Notes. In September 2020, the Company repurchased 749,300 shares of its common stock from purchasers of the Notes in the offering in privately negotiated transactions effected through one of the initial purchasers or its affiliate at an average price of $70.78 per share for an aggregate purchase price of approximately $53.0 million. There will be no further repurchases under this one-time authorization.

[0000926326-23-000003:notes:333]
During the year ended December 31, 2022, the Company repurchased approximately 389,300 shares of its common stock under the repurchase programs at an average price of $134.11 per share for an aggregate purchase price of approximately $52.2 million. During the years ended December 31, 2021 and 2020, the Company did not repurchase any of its outstanding common stock under the repurchase programs other than the separately-authorized one-time stock repurchase concurrent with the offering of the Notes in September 2020.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000926326-23-000003:notes:334]
Income Taxes
The following is a geographical breakdown of income (loss) before the provision for income taxes:

[0000926326-23-000003:notes:335]
|  | Year Ended December 31, |
|  | 2022 |  | 2021 |  | 2020 |
|  | (In thousands) |
| Domestic | $ | 369 |  |  | $ | 67,103 |  |  | $ | 34,714 |  |
| Foreign | (2,822) |  |  | (1,096) |  |  | (5,365) |  |
| Income (loss) before provision for income taxes | $ | (2,453) |  |  | $ | 66,007 |  |  | $ | 29,349 |  |

[0000926326-23-000003:notes:336]
The benefit from income taxes consisted of the following:

[0000926326-23-000003:notes:337]
|  | Year Ended December 31, |
|  | 2022 |  | 2021 |  | 2020 |
|  | (In thousands) |
| Current: |  |  |  |  |  |
| Federal | $ | 17,973 |  |  | $ | (7,841) |  |  | $ | 1,874 |  |
| State | 8,024 |  |  | 187 |  |  | 1,733 |  |
| Foreign | 192 |  |  | (234) |  |  | 647 |  |
| Total current income taxes | 26,189 |  |  | (7,888) |  |  | 4,254 |  |
| Deferred: |  |  |  |  |  |
| Federal | (25,753) |  |  | (2,708) |  |  | (3,868) |  |
| State | (7,976) |  |  | (1,217) |  |  | (2,494) |  |
| Foreign | (561) |  |  | (29) |  |  | (737) |  |
| Total deferred income taxes | (34,290) |  |  | (3,954) |  |  | (7,099) |  |
| Total benefit from income taxes | $ | (8,101) |  |  | $ | (11,842) |  |  | $ | (2,845) |  |

[0000926326-23-000003:notes:338]
The benefit from income taxes differs from the amount computed by applying the statutory federal tax rate as follows:

[0000926326-23-000003:notes:339]
|  | Year Ended December 31, |
|  | 2022 |  | 2021 |  | 2020 |
|  | (In thousands) |
| U.S. federal tax provision at statutory rate | $ | (515) |  |  | $ | 13,861 |  |  | $ | 6,163 |  |
| State taxes | 38 |  |  | (814) |  |  | (601) |  |
| Section 162(m) limitation | 3,071 |  |  | 6,382 |  |  | 2,550 |  |
| Non-deductible expenses | 102 |  |  | 363 |  |  | 325 |  |
| Uncertain tax positions | (776) |  |  | (835) |  |  | (394) |  |
| Share-based compensation tax benefit | (3,264) |  |  | (20,717) |  |  | (6,929) |  |
| Research tax credits | (6,948) |  |  | (5,170) |  |  | (4,038) |  |
| Restructuring impact | — |  |  | (6,116) |  |  | — |  |
| Foreign derived intangible income deduction | (753) |  |  | (68) |  |  | (204) |  |
| Global intangible low-taxed income inclusion | 960 |  |  | 195 |  |  | 157 |  |
| Foreign rate differential | 186 |  |  | 17 |  |  | (102) |  |
| Foreign branch taxes | (51) |  |  | (9) |  |  | 288 |  |
| Transaction cost | 68 |  |  | 1,097 |  |  | 422 |  |
| Other | (219) |  |  | (28) |  |  | (482) |  |
| Total benefit from income taxes | $ | (8,101) |  |  | $ | (11,842) |  |  | $ | (2,845) |  |

[0000926326-23-000003:notes:340]
The Company has executed various global operational centralization activities and legal entity rationalization in recent years. During the year ended December 31, 2022, the Company underwent legal entity rationalization through tax free reorganizations. During the year ended December 31, 2021, the Company recognized a benefit on the release of previously recorded uncertain tax positions related to the sale of certain intellectual property rights by Aesynt B.V. to Omnicell, Inc. and a gain on the transfer of certain assets to Omnicell Pty Ltd, which resulted in a tax benefit, net of tax expense, of $6.1 million.

[0000926326-23-000003:notes:341]
On August 16, 2022, the Inflation Reduction Act of 2022, (the “IRA”), was signed into law. Among other things, the IRA imposes a 15% corporate alternative minimum tax for tax years beginning after December 31, 2022, levies a 1% excise tax on net stock repurchases after December 31, 2022, and provides tax incentives to promote clean energy. The Company is in the process of analyzing the potential impacts of the IRA’s provisions on its business. However, these provisions are not currently expected to have a material impact on the Company’s results of operations or financial position.

[0000926326-23-000003:notes:342]
On March 11, 2021, the President of the United States signed into law the “American Rescue Plan Act of 2021” (the “ARP Act”), which provides additional economic stimulus and tax credits, including the expansion and modification of the employee retention tax credit enacted by the Coronavirus Aid, Relief and Economic Security Act and the refundable tax credits for COVID-related paid sick and family leave enacted by the Family First Act. The ARP Act further expands the “covered employees” definition for purposes of Section 162(m) of the Internal Revenue Code of 1986, as amended, used in determining the limitation on the deduction for excessive employee remuneration rules to be applicable for taxable years beginning after December 31, 2026. The provisions of the ARP Act did not have a material impact on the Company’s income taxes.

[0000926326-23-000003:notes:343]
Significant components of the Company’s deferred tax assets (liabilities) were as follows:

[0000926326-23-000003:notes:344]
|  | December 31, |
|  | 2022 |  | 2021 |
|  | (In thousands) |
| Deferred tax assets (liabilities): |  |  |  |
| Deferred revenues | $ | 13,514 |  |  | $ | 6,892 |  |
| Share-based compensation | 12,064 |  |  | 9,265 |  |
| Inventory-related items | 4,567 |  |  | 4,834 |  |
| Tax credit carryforwards | 12,173 |  |  | 15,311 |  |
| Reserves and accruals | 6,244 |  |  | 8,699 |  |
| Loss carryforwards | 10,255 |  |  | 14,451 |  |
| Lease liability | 12,884 |  |  | 13,179 |  |
| Convertible debt | 15,037 |  |  | 543 |  |
| Capitalized research and development | 30,881 |  |  | — |  |
| Other, net | 1,557 |  |  | 1,281 |  |
| Gross deferred tax assets | 119,176 |  |  | 74,455 |  |
| Valuation allowance | — |  |  | — |  |
| Total net deferred tax assets | 119,176 |  |  | 74,455 |  |
| Intangibles | (36,357) |  |  | (41,158) |  |
| Depreciation and amortization | (37,286) |  |  | (38,924) |  |
| Prepaid expenses | (15,574) |  |  | (17,775) |  |
| Right-of-use assets | (9,725) |  |  | (12,039) |  |
| Other, net | — |  |  | (381) |  |
| Total deferred tax liabilities | (98,942) |  |  | (110,277) |  |
| Net deferred tax assets (liabilities) | $ | 20,234 |  |  | $ | (35,822) |  |

[0000926326-23-000003:notes:345]
Deferred income tax assets (liabilities) are provided for temporary differences that will result in future tax deductions or future taxable income, as well as the future benefit of tax credit carryforwards. The Company recognizes deferred tax assets to the extent that it believes these assets are more likely than not to be realized. In making such a determination, the Company considers all available positive and negative evidence, including future reversals of existing temporary differences, projected future taxable income, tax planning strategies, and results of recent operations. As of December 31, 2022 and 2021, the Company does not have a valuation allowance against any of its deferred tax assets.

[0000926326-23-000003:notes:346]
As of December 31, 2022, the Company had $10.9 million of federal net operating losses and $15.0 million of state net operating loss carryforwards expiring at various dates beginning in 2024, and $22.2 million of foreign net operating losses carried forward indefinitely. For income tax purposes, the Company has no federal research tax credit carryforward and a California research tax credit carryforward of $20.0 million. California credits are carried forward indefinitely to reduce cash taxes payable.

[0000926326-23-000003:notes:347]
It is the Company’s practice and intention to reinvest the earnings of its non-U.S. subsidiaries in those operations. As of December 31, 2022, the Company has not made a provision for U.S. federal income, withholding, and state income taxes on the outside basis difference related to certain foreign subsidiaries because earnings are intended to be indefinitely reinvested in operations outside the U.S.

[0000926326-23-000003:notes:348]
The Company files income tax returns in the United States and various state and foreign jurisdictions. In the normal course of business, the Company is subject to examinations by taxing authorities, including major jurisdictions such as the United States, Germany, Italy, France, and the United Kingdom. With few exceptions, as of December 31, 2022, the Company was no longer subject to U.S., state, and foreign tax examinations for years before 2019, 2018, and 2018, respectively.

[0000926326-23-000003:notes:349]
The aggregate change in the balance of gross unrecognized tax benefit, which excludes interest and penalties, for the years ended December 31, 2022, 2021, and 2020:

[0000926326-23-000003:notes:350]
|  | (In thousands) |
| Balance as of December 31, 2019 | $ | 16,775 |  |
| Increases related to tax positions taken during a prior period | 88 |  |
| Decreases related to tax positions taken during the prior period | — |  |
| Increases related to tax positions taken during the current period | 2,294 |  |
| Decreases related to settlements | — |  |
| Decreases related to expiration of statute of limitations | (911) |  |
| Balance as of December 31, 2020 | 18,246 |  |
| Increases related to tax positions taken during a prior period | 40 |  |
| Decreases related to tax positions taken during the prior period | (8,908) |  |
| Increases related to tax positions taken during the current period | 1,219 |  |
| Decreases related to settlements | — |  |
| Decreases related to expiration of statute of limitations | (1,636) |  |
| Balance as of December 31, 2021 | 8,961 |  |
| Increases related to tax positions taken during a prior period | 3 |  |
| Decreases related to tax positions taken during the prior period | (59) |  |
| Increases related to tax positions taken during the current period | 1,629 |  |
| Decreases related to settlements | — |  |
| Decreases related to expiration of statute of limitations | (1,238) |  |
| Balance as of December 31, 2022 | $ | 9,296 |  |

[0000926326-23-000003:notes:351]
The total amount of gross unrecognized tax benefit that, if realized, would favorably affect the Company’s effective income tax rate in future periods, was $9.3 million and $9.0 million as of December 31, 2022 and 2021, respectively. The Company recognizes interest and penalties related to uncertain tax positions in interest and other income (expense), net in the Consolidated Statements of Operations, accruing $0.2 million, $0.3 million, and $0.4 million for the years ended December 31, 2022, 2021, and 2020, respectively. Accrued interest and penalties are included within other long-term liabilities on the Consolidated Balance Sheets. The combined amount of cumulative accrued interest and penalties was approximately $0.2 million, $0.6 million, and $1.4 million for the years ended December 31, 2022, 2021, and 2020, respectively. The Company does not believe there will be any significant changes in its unrecognized tax positions over the next twelve months.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000926326-23-000003:notes:352]
Restructuring Expenses
During 2020, the Company announced a company-wide organizational realignment initiative in order to more effectively align its organizational infrastructure and operations with the industry vision of the Autonomous Pharmacy. The Company also initiated a restructuring plan to help mitigate the adverse impact of the COVID-19 pandemic on its business and financial results. During the year ended December 31, 2020, the Company incurred $10.0 million of employee severance costs and related expenses.

[0000926326-23-000003:notes:353]
During the first quarter of 2021, the Company continued its organizational realignment initiative, incurring $2.0 million of employee severance costs and related expenses.

[0000926326-23-000003:notes:354]
During the first quarter of 2022, the Company initiated certain domestic and international restructuring initiatives in order to enhance and streamline certain engineering functions for its domestic operations and to realign its international sales organization to better serve its customers in various international markets. During the third quarter of 2022, the Company initiated restructuring initiatives associated with the integration and functionalization of certain acquisitions, primarily the 340B Link business acquisition, to further accelerate the expansion of the Company’s pharmacy inventory management capabilities. On November 23, 2022, the Company committed to a plan to reduce the Company’s headcount as part of the Company’s expense containment efforts being implemented due to ongoing macroeconomic headwinds, primarily consisting of employee severance and benefits costs.

[0000926326-23-000003:notes:355]
During the year ended December 31, 2022, the restructuring plans incurred $22.8 million of employee severance costs and related expenses. As of December 31, 2022, the unpaid balance related to these restructuring plans was $18.2 million.

[0000926326-23-000003:notes:356]
Refer to Note 13, Lessee Leases for information regarding the Company’s restructuring activities for optimization of certain leased facilities.

[0000926326-23-000003:notes:357]
The following table summarizes the total restructuring expenses recognized in the Company’s Consolidated Statements of Operations for the years ended December 31, 2022, 2021, and 2020:

[0000926326-23-000003:notes:358]
|  | Year Ended December 31, |
|  | 2022 |  | 2021 |  | 2020 |
|  | (In thousands) |
| Cost of product and service revenues | $ | 8,018 |  |  | $ | 389 |  |  | $ | 2,564 |  |
| Research and development | 3,615 |  |  | 105 |  |  | 3,716 |  |
| Selling, general, and administrative | 11,170 |  |  | 1,526 |  |  | 3,681 |  |
| Total restructuring expense | $ | 22,803 |  |  | $ | 2,020 |  |  | $ | 9,961 |  |


## us-gaap:SubsequentEventsTextBlock

[0000926326-23-000003:notes:359]
Subsequent Events
As previously disclosed, on November 23, 2022, the Company committed to a plan to reduce the Company’s headcount (the “Plan”), as part of the Company’s expense containment efforts being implemented due to ongoing macroeconomic headwinds. As a result of continued exploration of expense containment measures, on February 28, 2023, the Company committed to further reduce its headcount as part of the Plan. The Company expects to further reduce its workforce across many of its functions affecting approximately 60 additional employees. As part of the Plan, on February 28, 2023, the Company also committed to reduce its real estate footprint to align with its broader hybrid work strategy and in an effort to further reduce costs.

[0000926326-23-000003:notes:360]
The Company estimates that the additional headcount reductions and office closures will result in additional incremental nonrecurring restructuring and related charges of approximately $13.0 million in 2023.


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000926326-23-000003:notes:361]
SCHEDULE II

[0000926326-23-000003:notes:362]
VALUATION AND QUALIFYING ACCOUNTS

[0000926326-23-000003:notes:363]
|  | Balance atBeginning of Period (1) |  | Charged (Credited) toCosts and Expenses (2) |  |  |  | AmountsWritten Off (3) |  | Other Adjustments (4) |  | Balance atEnd of Period (1) |
|  | (In thousands) |
| Year ended December 31, 2020 |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable and unbilled receivables | $ | 3,227 |  |  | $ | 1,095 |  |  |  |  | $ | (535) |  |  | $ | 499 |  |  | $ | 4,286 |  |
| Long-term unbilled receivables | — |  |  | — |  |  |  |  | — |  |  | 30 |  |  | 30 |  |
| Net investment in sales-type leases | 225 |  |  | 40 |  |  |  |  | — |  |  | — |  |  | 265 |  |
| Total allowances deducted from assets | $ | 3,452 |  |  | $ | 1,135 |  |  |  |  | $ | (535) |  |  | $ | 529 |  |  | $ | 4,581 |  |
| Year ended December 31, 2021 |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable and unbilled receivables | $ | 4,286 |  |  | $ | 2,130 |  |  |  |  | $ | (2,079) |  |  | $ | 935 |  |  | $ | 5,272 |  |
| Long-term unbilled receivables | 30 |  |  | (4) |  |  |  |  | — |  |  | — |  |  | 26 |  |
| Net investment in sales-type leases | 265 |  |  | (37) |  |  |  |  | — |  |  | — |  |  | 228 |  |
| Total allowances deducted from assets | $ | 4,581 |  |  | $ | 2,089 |  |  |  |  | $ | (2,079) |  |  | $ | 935 |  |  | $ | 5,526 |  |
| Year ended December 31, 2022 |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable and unbilled receivables | $ | 5,272 |  |  | $ | 2,658 |  |  |  |  | $ | (2,551) |  |  | $ | (226) |  |  | $ | 5,153 |  |
| Long-term unbilled receivables | 26 |  |  | 9 |  |  |  |  | — |  |  |  |  | 35 |  |
| Net investment in sales-type leases | 228 |  |  | 80 |  |  |  |  | — |  |  | — |  |  | 308 |  |
| Total allowances deducted from assets | $ | 5,526 |  |  | $ | 2,747 |  |  |  |  | $ | (2,551) |  |  | $ | (226) |  |  | $ | 5,496 |  |

[0000926326-23-000003:notes:364]
__________________________________________________

[0000926326-23-000003:notes:365]
(1)Allowance for credit losses.

[0000926326-23-000003:notes:366]
(2)Represents amounts charged and credited for provisions for credit losses.

[0000926326-23-000003:notes:367]
(3)Represents amounts written off from the allowance and receivable.

[0000926326-23-000003:notes:368]
(4)Represents other adjustments, such as foreign currency translation, adoption of new accounting guidance, and purchase price accounting adjustments in connection with acquisitions.
