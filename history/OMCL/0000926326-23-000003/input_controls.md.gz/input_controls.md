# OMCL 10-K controls and the auditor's report


## auditors_report

[0000926326-23-000003:auditors_report:1]
REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

[0000926326-23-000003:auditors_report:2]
To the Stockholders and the Board of Directors of Omnicell, Inc.

[0000926326-23-000003:auditors_report:3]
Opinion on the Financial Statements

[0000926326-23-000003:auditors_report:4]
We have audited the accompanying consolidated balance sheets of Omnicell, Inc. and subsidiaries (the “Company”) as of December 31, 2022 and 2021, the related consolidated statements of operations, comprehensive income (loss), stockholders’ equity, and cash flows, for each of the three years in the period ended December 31, 2022, and the related notes and the schedule listed in the Index at Item 15 (collectively referred to as the “financial statements”). In our opinion, the financial statements present fairly, in all material respects, the financial position of the Company as of December 31, 2022 and 2021, and the results of its operations and its cash flows for each of the three years in the period ended December 31, 2022, in conformity with accounting principles generally accepted in the United States of America.

[0000926326-23-000003:auditors_report:5]
We have also audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (PCAOB), the Company’s internal control over financial reporting as of December 31, 2022, based on criteria established in Internal Control — Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission and our report dated March 1, 2023, expressed an unqualified opinion on the Company’s internal control over financial reporting.

[0000926326-23-000003:auditors_report:6]
Basis for Opinion

[0000926326-23-000003:auditors_report:7]
These financial statements are the responsibility of the Company’s management. Our responsibility is to express an opinion on the Company’s financial statements based on our audits. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0000926326-23-000003:auditors_report:8]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether the financial statements are free of material misstatement, whether due to error or fraud. Our audits included performing procedures to assess the risks of material misstatement of the financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the financial statements. We believe that our audits provide a reasonable basis for our opinion.

[0000926326-23-000003:auditors_report:9]
Critical Audit Matters

[0000926326-23-000003:auditors_report:10]
The critical audit matters communicated below are matters arising from the current-period audit of the financial statements that were communicated or required to be communicated to the audit committee and that (1) relate to accounts or disclosures that are material to the financial statements and (2) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the financial statements, taken as a whole, and we are not, by communicating the critical audit matters below, providing separate opinions on the critical audit matters or on the accounts or disclosures to which they relate.

[0000926326-23-000003:auditors_report:11]
Inventory Valuation — Refer to Note 1 to the financial statements

[0000926326-23-000003:auditors_report:12]
Critical Audit Matter Description

[0000926326-23-000003:auditors_report:13]
The Company records write-downs for excess and slow-moving inventory based on the Company’s estimate of demand for its products, potential obsolescence of technology, product life cycles, and whether pricing trends or forecasts indicate that the carrying value of inventory exceeds its estimated selling price. These estimates require management judgment and are impacted by market and economic conditions, technology changes, and new product introductions. The Company’s consolidated inventory balance is $147.5 million as of December 31, 2022.

[0000926326-23-000003:auditors_report:14]
We identified the inventory valuation as a critical audit matter because of the assumptions and judgments made by management to estimate the excess and slow-moving inventory, especially considering the presence of various inventory types and evolving product life cycles, which includes new product development. The analysis of inventory valuation required a high degree of auditor judgment when performing audit procedures to evaluate qualitative and quantitative factors considered and the reasonableness of the relevant management judgments.

[0000926326-23-000003:auditors_report:15]
How the Critical Audit Matter Was Addressed in the Audit

[0000926326-23-000003:auditors_report:16]
Our audit procedures over the inventory valuation included the following, among others:

[0000926326-23-000003:auditors_report:17]
F-1

[0000926326-23-000003:auditors_report:18]
•    We tested the effectiveness of controls over inventory for valuation.

[0000926326-23-000003:auditors_report:19]
•    We evaluated the appropriateness of management’s method, assumptions, and judgments used in developing their estimate of the excess and slow-moving inventory, which included consideration of demand for its products, potential obsolescence of technology, product life cycles, and pricing trends.

[0000926326-23-000003:auditors_report:20]
•    We tested certain underlying data used and considered in the excess and obsolete inventory assessment, including the amount of inventory on hand, forecasted demand, and historical sales.

[0000926326-23-000003:auditors_report:21]
•    We compared actual inventory usage and write-off activity in the current year to the excess and obsolete estimate by management in the prior year to evaluate management’s ability to make accurate estimates.

[0000926326-23-000003:auditors_report:22]
•    We evaluated the valuation of excess and obsolete inventory for understatement by making selections of individual inventory items and evaluating the appropriateness of the inventory valuation and management judgments based on relevant product specific information. These procedures also included certain inquiries of production planning and supply chain employees.

[0000926326-23-000003:auditors_report:23]
•    We evaluated whether the excess and obsolete inventory may be understated by evaluating write-off activity of inventory subsequent to December 31, 2022.

[0000926326-23-000003:auditors_report:24]
Capitalized Software - Internal Software Development Costs — Refer to Notes 1 and 7 to the financial statements

[0000926326-23-000003:auditors_report:25]
Critical Audit Matter Description

[0000926326-23-000003:auditors_report:26]
The Company capitalizes certain costs related to computer software developed or obtained for internal use when costs are incurred in the application development phase and amortizes these costs over the estimated lives of the software. The determination of whether a project’s software development costs are capitalized or expensed could have a significant impact on the financial statements. The Company capitalized $33.0 million of costs related to the application development of enterprise-level software and its subscription and cloud-based offerings in the year ended December 31, 2022.

[0000926326-23-000003:auditors_report:27]
We identified management’s determination of internal capitalized software development costs to be a critical audit matter. Evaluating the Company’s determination of the project and related software development activities to be capitalized under relevant accounting guidance, including the extent to which software development costs incurred were capitalized, required subjective auditor judgment.

[0000926326-23-000003:auditors_report:28]
How the Critical Audit Matter Was Addressed in the Audit

[0000926326-23-000003:auditors_report:29]
Our audit procedures to assess the appropriateness of capitalized software development costs included the following, among others:

[0000926326-23-000003:auditors_report:30]
•    We tested the effectiveness of management’s capitalized software development cost controls.

[0000926326-23-000003:auditors_report:31]
•    We obtained an understanding of management’s process for evaluating software development costs and the nature of software development costs capitalized.

[0000926326-23-000003:auditors_report:32]
•    We tested management’s method of calculating capitalized software development costs. For a sample of projects, we performed audit procedures to agree capitalized labor costs to time records and made certain inquiries of project members to further assess the reasonableness of time allocated to the selected projects.

[0000926326-23-000003:auditors_report:33]
•    For a sample of software development projects, we obtained an understanding of the new software enhancements and features planned for development by reviewing management’s project documentation and inquiring of project managers and engineers.

[0000926326-23-000003:auditors_report:34]
•    For a sample of software development projects, we tested the timing of software development cost recognition as either a capitalized or an expensed development cost. We also inquired of project managers and engineers regarding when application development was reached and observed the new features developed in the working model.

[0000926326-23-000003:auditors_report:35]
/s/ Deloitte & Touche LLP

[0000926326-23-000003:auditors_report:36]
San Jose, California

[0000926326-23-000003:auditors_report:37]
March 1, 2023

[0000926326-23-000003:auditors_report:38]
We have served as the Company’s auditor since 2014.

[0000926326-23-000003:auditors_report:39]
F-2

[0000926326-23-000003:auditors_report:40]
REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

[0000926326-23-000003:auditors_report:41]
To the stockholders and the Board of Directors of Omnicell, Inc.

[0000926326-23-000003:auditors_report:42]
Opinion on Internal Control over Financial Reporting

[0000926326-23-000003:auditors_report:43]
We have audited the internal control over financial reporting of Omnicell, Inc. and subsidiaries (the “Company”) as of December 31, 2022, based on criteria established in Internal Control — Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO). In our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of December 31, 2022, based on criteria established in Internal Control — Integrated Framework (2013) issued by COSO.

[0000926326-23-000003:auditors_report:44]
We have also audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (PCAOB), the consolidated financial statements as of and for the year ended December 31, 2022, of the Company and our report dated March 1, 2023, expressed an unqualified opinion on those financial statements.

[0000926326-23-000003:auditors_report:45]
Basis for Opinion

[0000926326-23-000003:auditors_report:46]
The Company’s management is responsible for maintaining effective internal control over financial reporting and for its assessment of the effectiveness of internal control over financial reporting, included in the accompanying Management’s Report on Internal Control Over Financial Reporting. Our responsibility is to express an opinion on the Company’s internal control over financial reporting based on our audit. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0000926326-23-000003:auditors_report:47]
We conducted our audit in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether effective internal control over financial reporting was maintained in all material respects. Our audit included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, testing and evaluating the design and operating effectiveness of internal control based on the assessed risk, and performing such other procedures as we considered necessary in the circumstances. We believe that our audit provides a reasonable basis for our opinion.

[0000926326-23-000003:auditors_report:48]
Definition and Limitations of Internal Control over Financial Reporting

[0000926326-23-000003:auditors_report:49]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (1) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (2) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (3) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0000926326-23-000003:auditors_report:50]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0000926326-23-000003:auditors_report:51]
/s/ Deloitte & Touche LLP

[0000926326-23-000003:auditors_report:52]
San Jose, California

[0000926326-23-000003:auditors_report:53]
March 1, 2023

[0000926326-23-000003:auditors_report:54]
F-3

[0000926326-23-000003:auditors_report:55]
OMNICELL, INC.


## item_9a

[0000926326-23-000003:item_9a:1]
ITEM 9A.    CONTROLS AND PROCEDURES

[0000926326-23-000003:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0000926326-23-000003:item_9a:3]
Our management, with the participation of our principal executive officer and principal financial officer, evaluated the effectiveness of our disclosure controls and procedures (as such term is defined in Rules 13a-15(e) and 15d-15(e) under the Exchange Act) as of the end of the period covered by this Annual Report on Form 10-K. In designing and evaluating the disclosure controls and procedures, management recognized that any controls and procedures, no matter how well designed and operated, can provide only reasonable assurance of achieving the desired control objectives. In addition, the design of disclosure controls and procedures must reflect the fact that there are resource constraints and that management is required to apply its judgment in evaluating the benefits of possible controls and procedures relative to their costs.

[0000926326-23-000003:item_9a:4]
Based on that evaluation, our principal executive officer and principal financial officer concluded that our disclosure controls and procedures were effective as of December 31, 2022 to provide reasonable assurance that information we are required to disclose in reports that we file or submit under the Exchange Act is recorded, processed, summarized and reported within the time periods specified in SEC rules and forms, and that such information is accumulated and communicated to our management, including our principal executive officer and principal financial officer, as appropriate, to allow timely decisions regarding required disclosure.

[0000926326-23-000003:item_9a:5]
Management’s Report on Internal Control Over Financial Reporting

[0000926326-23-000003:item_9a:6]
Our management is responsible for establishing and maintaining adequate internal control over financial reporting (as such term is defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act). Our internal control system is designed to provide reasonable assurance regarding the preparation and fair presentation of financial statements for external purposes in accordance with U.S. generally accepted accounting principles. All internal control systems, no matter how well designed, have inherent limitations and can provide only reasonable assurance that the objectives of the internal control system are met.

[0000926326-23-000003:item_9a:7]
Under the supervision and with the participation of our management, including our principal executive officer and principal financial officer, we conducted an evaluation of the effectiveness of our internal control over financial reporting as of December 31, 2022 using the criteria for effective internal control over financial reporting as described in “Internal Control—Integrated Framework,” issued by the Committee of Sponsoring Organizations of the Treadway Commission (2013 framework) (the COSO Criteria). Based on this assessment, management concluded that our internal control over financial reporting was effective as of December 31, 2022.

[0000926326-23-000003:item_9a:8]
Deloitte & Touche LLP, an independent registered public accounting firm, has issued its attestation report on our internal control over financial reporting as of December 31, 2022, which is included in Part IV, Item 15 of this Annual Report on Form 10-K.

[0000926326-23-000003:item_9a:9]
Changes in Internal Control over Financial Reporting

[0000926326-23-000003:item_9a:10]
There have been no changes in our internal control over financial reporting (as such term is defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act) that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting during the year ended December 31, 2022.
