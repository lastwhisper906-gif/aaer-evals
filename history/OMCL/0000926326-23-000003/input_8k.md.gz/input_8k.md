# OMCL 8-K — 0001104659-23-026700 filed 2023-02-28

## item codes, every 8-K on or before 2023-03-01

- 2023-02-28 0001104659-23-026700 — 2.02, 2.05, 5.02, 9.01
- 2022-11-30 0000926326-22-000036 — 2.05
- 2022-11-02 0000926326-22-000031 — 2.02, 9.01
- 2022-10-21 0000926326-22-000029 — 5.03, 9.01
- 2022-09-20 0001104659-22-101566 — 7.01, 9.01
- 2022-09-20 0001104659-22-101360 — 7.01, 9.01
- 2022-08-04 0000926326-22-000025 — 2.02, 8.01, 9.01
- 2022-05-31 0000926326-22-000020 — 5.02, 5.07, 9.01
- 2022-05-24 0000926326-22-000016 — 5.02
- 2022-05-09 0000926326-22-000012 — 8.01
- 2022-04-28 0000926326-22-000009 — 2.02, 9.01
- 2022-03-01 0001104659-22-028681 — 5.02, 8.01, 9.01
- 2022-02-14 0000926326-22-000004 — 2.02, 9.01
- 2022-01-04 0000926326-22-000002 — 7.01, 9.01
- 2021-12-29 0001104659-21-154294 — 7.01, 9.01
- 2021-12-13 0000926326-21-000039 — 8.01
- 2021-12-02 0000926326-21-000037 — 7.01, 9.01
- 2021-11-02 0000926326-21-000031 — 2.02, 9.01
- 2021-09-09 0000926326-21-000028 — 7.01, 9.01
- 2021-07-29 0000926326-21-000024 — 2.02, 9.01
- 2021-07-26 0000926326-21-000022 — 7.01, 9.01
- 2021-07-12 0000926326-21-000019 — 5.02, 9.01
- 2021-05-28 0000926326-21-000015 — 5.07
- 2021-04-29 0000926326-21-000011 — 2.02, 9.01
- 2021-02-01 0000926326-21-000004 — 2.02, 9.01
- 2021-01-26 0000926326-21-000002 — 5.02
- 2021-01-13 0001104659-21-003672 — 2.02, 7.01, 9.01
- 2020-10-27 0000926326-20-000032 — 2.02, 9.01
- 2020-10-01 0000926326-20-000029 — 7.01, 9.01
- 2020-09-25 0001104659-20-108924 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2020-09-22 0001104659-20-107176 — 1.01, 8.01, 9.01
- 2020-08-12 0000926326-20-000027 — 2.03
- 2020-08-12 0000926326-20-000025 — 1.01, 5.03, 7.01, 9.01
- 2020-07-28 0000926326-20-000021 — 2.02, 9.01
- 2020-05-27 0000926326-20-000017 — 5.07
- 2020-05-07 0000926326-20-000012 — 2.02, 9.01
- 2020-02-18 0000926326-20-000007 — 5.02, 9.01
- 2020-02-13 0000926326-20-000005 — 8.01
- 2020-02-06 0000926326-20-000003 — 2.02, 9.01
- 2019-12-06 0001104659-19-070339 — 8.01
- 2019-11-18 0000926326-19-000035 — 1.01, 2.03, 9.01
- 2019-10-24 0000926326-19-000028 — 2.02, 9.01
- 2019-07-25 0000926326-19-000021 — 2.02, 9.01
- 2019-05-15 0000926326-19-000015 — 5.07
- 2019-04-25 0000926326-19-000011 — 2.02, 9.01
- 2019-03-08 0000926326-19-000009 — 5.02, 9.01
- 2019-02-19 0000926326-19-000005 — 5.02, 9.01
- 2019-02-07 0000926326-19-000003 — 2.02, 9.01
- 2018-10-25 0000926326-18-000028 — 2.02, 9.01
- 2018-09-14 0001104659-18-056929 — 5.02, 9.01
- 2018-07-26 0000926326-18-000022 — 2.02, 9.01
- 2018-06-06 0000926326-18-000019 — 5.02, 9.01
- 2018-05-16 0001104659-18-033801 — 5.07
- 2018-04-26 0000926326-18-000013 — 2.02, 9.01
- 2018-03-02 0001104659-18-014497 — 5.02
- 2018-02-08 0000926326-18-000007 — 5.02
- 2018-02-02 0000926326-18-000005 — 5.02
- 2018-02-01 0000926326-18-000003 — 2.02, 9.01
- 2017-12-26 0000926326-17-000041 — 1.01, 2.03, 9.01
- 2017-11-03 0001104659-17-066102 — 1.01, 8.01, 9.01
- 2017-10-26 0000926326-17-000035 — 2.02, 9.01
- 2017-08-03 0000926326-17-000028 — 5.07 — amendment, the index does not say of what
- 2017-07-27 0000926326-17-000026 — 2.02, 9.01
- 2017-07-25 0000926326-17-000023 — 5.02, 9.01
- 2017-05-24 0000926326-17-000019 — 5.07
- 2017-05-04 0001628280-17-004851 — 2.02, 9.01
- 2017-02-15 0000926326-17-000010 — 2.05
- 2017-02-15 0000926326-17-000008 — 2.02, 9.01
- 2017-02-13 0000926326-17-000002 — 5.02
- 2016-12-08 0001104659-16-161330 — 2.01, 2.03, 9.01
- 2016-12-06 0001104659-16-160709 — 7.01
- 2016-11-29 0001104659-16-159456 — 1.01, 7.01, 9.01
- 2016-10-27 0000926326-16-000075 — 2.02, 9.01
- 2016-10-07 0000926326-16-000072 — 5.02, 8.01
- 2016-08-05 0000926326-16-000068 — 8.01
- 2016-07-28 0000926326-16-000066 — 2.02, 9.01
- 2016-06-13 0001104659-16-126854 — 5.02
- 2016-05-25 0000926326-16-000060 — 5.07
- 2016-04-28 0000926326-16-000054 — 2.02, 9.01
- 2016-03-21 0001104659-16-106649 — 8.01, 9.01
- 2016-03-17 0000926326-16-000051 — 7.01, 9.01
- 2016-03-17 0000926326-16-000049 — 9.01 — amendment of 0000926326-16-000051
- 2016-02-10 0001104659-16-095486 — 5.02, 9.01
- 2016-02-04 0000926326-16-000041 — 2.02, 9.01
- 2016-01-06 0001104659-16-088299 — 1.01, 2.01, 2.03, 9.01
- 2015-12-10 0000926326-15-000038 — 8.01, 9.01
- 2015-10-29 0001104659-15-074138 — 1.01, 9.01
- 2015-10-29 0000926326-15-000031 — 2.02, 9.01
- 2015-08-20 0001104659-15-061135 — 5.02, 9.01
- 2015-07-30 0000926326-15-000024 — 2.02, 9.01
- 2015-05-22 0001104659-15-040440 — 5.07
- 2015-05-01 0001104659-15-032846 — 5.02
- 2015-05-01 0001104659-15-032844 — 7.01
- 2015-04-30 0000926326-15-000015 — 9.01
- 2015-04-22 0001104659-15-029356 — 8.01, 9.01
- 2015-03-20 0001104659-15-021435 — 3.01
- 2015-03-18 0001104659-15-020699 — 7.01
- 2015-03-17 0001104659-15-020483 — 8.01, 9.01
- 2015-03-02 0001104659-15-015802 — 1.01, 9.01
- 2015-02-12 0001104659-15-009234 — 5.02, 9.01
- 2015-02-03 0000926326-15-000003 — 9.01
- 2015-01-15 0001104659-15-002635 — 5.02
- 2014-11-07 0001104659-14-078398 — 1.01, 8.01, 9.01
- 2014-10-30 0000926326-14-000037 — 2.02, 9.01
- 2014-08-25 0001104659-14-062772 — 8.01, 9.01
- 2014-07-31 0000926326-14-000032 — 2.02, 9.01
- 2014-05-21 0001104659-14-040744 — 5.07
- 2014-05-01 0000926326-14-000008 — 2.02, 9.01
- 2014-04-08 0001104659-14-026441 — 4.01, 9.01
- 2014-04-02 0001104659-14-025179 — 5.02
- 2014-02-07 0001104659-14-007552 — 5.02, 9.01
- 2014-02-04 0001104659-14-006352 — 2.02, 9.01
- 2013-12-09 0001104659-13-088980 — 1.01, 9.01
- 2013-12-02 0001104659-13-087877 — 5.02
- 2013-10-31 0001104659-13-079660 — 2.02, 9.01
- 2013-09-26 0001104659-13-072435 — 1.01, 2.03, 9.01
- 2013-08-01 0001104659-13-058959 — 2.02, 9.01
- 2013-05-23 0001104659-13-044317 — 5.07
- 2013-05-02 0001104659-13-036605 — 2.02, 9.01
- 2013-03-11 0001104659-13-019143 — 8.01
- 2013-02-07 0001104659-13-008477 — 5.02, 9.01
- 2013-01-31 0001104659-13-006446 — 2.02, 9.01
- 2012-11-02 0001104659-12-073697 — 5.02
- 2012-10-25 0001104659-12-071211 — 2.02, 9.01
- 2012-08-06 0001104659-12-054635 — 8.01
- 2012-08-03 0001104659-12-054214 — 2.01, 9.01 — amendment of 0001104659-12-038888
- 2012-08-01 0001104659-12-053005 — 2.02, 9.01
- 2012-06-12 0001104659-12-042936 — 8.01, 9.01
- 2012-05-23 0001104659-12-039459 — 5.07
- 2012-05-22 0001104659-12-038888 — 2.01, 9.01
- 2012-05-02 0001104659-12-032048 — 2.02, 9.01
- 2012-05-02 0001104659-12-032036 — 1.01, 9.01
- 2012-04-04 0001104659-12-023883 — 5.02, 8.01
- 2012-03-20 0001104659-12-019462 — 1.01, 9.01
- 2012-02-13 0001104659-12-009353 — 5.02, 9.01
- 2012-01-26 0001104659-12-004244 — 2.02, 9.01
- 2011-10-27 0001104659-11-058464 — 2.02, 9.01
- 2011-10-25 0001104659-11-057721 — 1.01
- 2011-07-28 0001104659-11-041505 — 2.02, 9.01
- 2011-05-27 0001104659-11-032006 — 5.07
- 2011-05-02 0001104659-11-024908 — 2.02, 9.01
- 2011-04-15 0001104659-11-020407 — 5.02, 9.01 — amendment of 0001104659-11-005638
- 2011-02-08 0001104659-11-005638 — 5.02, 9.01
- 2011-01-27 0001104659-11-003419 — 2.02, 9.01
- 2010-12-22 0001104659-10-064003 — 5.02, 5.07, 9.01
- 2010-10-27 0001104659-10-054036 — 2.02, 9.01
- 2010-10-05 0001104659-10-051173 — 8.01
- 2010-07-22 0001104659-10-039126 — 2.02, 9.01
- 2010-07-09 0001104659-10-037594 — 2.05
- 2010-05-28 0001104659-10-031607 — 5.07
- 2010-04-26 0001104659-10-021797 — 2.02, 9.01
- 2010-03-17 0001104659-10-014849 — 5.02, 9.01
- 2010-02-08 0001104659-10-005457 — 5.02, 9.01
- 2010-01-28 0001104659-10-003627 — 2.02, 9.01
- 2009-10-22 0001104659-09-059972 — 2.02, 9.01
- 2009-07-23 0001104659-09-044508 — 2.02, 9.01
- 2009-05-20 0001104659-09-033938 — 5.02, 9.01
- 2009-04-30 0001104659-09-027707 — 2.02, 9.01
- 2009-03-10 0001104659-09-016178 — 5.02, 9.01
- 2009-02-09 0001104659-09-007692 — 5.02, 9.01
- 2009-01-29 0001104659-09-005022 — 2.02, 2.05, 9.01
- 2009-01-21 0001104659-09-003180 — 2.02, 8.01, 9.01
- 2009-01-06 0001104659-09-000625 — 5.02
- 2008-10-23 0001104659-08-065475 — 2.02, 9.01
- 2008-07-21 0001104659-08-046690 — 2.02, 9.01
- 2008-05-16 0001104659-08-034035 — 8.01, 9.01
- 2008-04-28 0001104659-08-027379 — 7.01, 9.01
- 2008-04-21 0001104659-08-025616 — 2.02, 9.01
- 2008-03-12 0001104659-08-016939 — 7.01, 9.01
- 2008-02-26 0001104659-08-012840 — 7.01, 9.01
- 2008-02-12 0001104659-08-009382 — 5.02, 9.01
- 2008-01-31 0001104659-08-006199 — 2.02, 9.01
- 2007-12-05 0001104659-07-087191 — 1.01, 9.01
- 2007-10-18 0001104659-07-075654 — 2.02, 9.01
- 2007-07-27 0001104659-07-056886 — 5.03, 9.01
- 2007-07-19 0001104659-07-054924 — 2.02, 9.01
- 2007-05-23 0001104659-07-042287 — 8.01, 9.01
- 2007-05-07 0001104659-07-036172 — 1.01, 5.02, 9.01
- 2007-04-24 0001104659-07-030578 — 2.02, 9.01 — amendment, the index does not say of what
- 2007-04-24 0001104659-07-030547 — 2.02, 9.01
- 2007-04-10 0001104659-07-027465 — 5.02, 9.01
- 2007-03-23 0001104659-07-021969 — 2.02, 4.02, 9.01
- 2007-01-30 0001104659-07-005772 — 2.02, 9.01
- 2007-01-09 0001104659-07-001600 — 5.02, 9.01
- 2006-10-30 0001104659-06-069612 — 1.01
- 2006-10-19 0001104659-06-067549 — 2.02, 9.01
- 2006-07-20 0001104659-06-048020 — 2.02, 4.02, 9.01
- 2006-05-17 0001104659-06-035522 — 1.01, 9.01 — amendment of 0001104659-05-011155
- 2006-05-09 0001104659-06-032706 — 1.01, 9.01
- 2006-04-25 0001104659-06-027438 — 2.02, 9.01
- 2006-04-04 0001104659-06-022204 — 1.01, 9.01
- 2006-03-15 0001104659-06-016861 — 1.01, 9.01
- 2006-01-30 0001104659-06-004749 — 2.02, 9.01
- 2006-01-24 0001104659-06-003504 — 1.01, 5.02, 9.01
- 2005-12-13 0001104659-05-060532 — 1.01, 9.01
- 2005-11-10 0001104659-05-054663 — 2.02, 9.01
- 2005-07-21 0001104659-05-033464 — 2.02, 9.01
- 2005-06-22 0001104659-05-029255 — 1.01
- 2005-05-16 0001104659-05-023473 — 2.02, 9.01 — amendment of 0001104659-05-018173
- 2005-05-16 0001104659-05-023471 — 2.02, 9.01 — amendment of 0001104659-05-017382
- 2005-05-10 0001104659-05-022127 — 1.01
- 2005-04-26 0001104659-05-018173 — 2.02, 9.01
- 2005-04-21 0001104659-05-017382 — 2.02, 9.01
- 2005-04-06 0001104659-05-015401 — 5.02
- 2005-03-15 0001104659-05-011155 — 1.01, 9.01
- 2005-03-08 0001104659-05-009975 — 1.01, 9.01
- 2005-02-03 0001104659-05-003943 — 2.02, 9.01
- 2005-01-13 0001104659-05-001314 — 5.02, 9.01
- 2004-10-21 0001104659-04-031413 — 2.02, 9.01
- 2004-07-22 0001104659-04-020572 — 12, 7
- 2004-04-14 0001104659-04-010039 — 12, 7
- 2004-04-05 0001104659-04-009437 — 12, 7
- 2004-01-26 0001104659-04-001655 — 12, 7
- 2003-10-16 0001104659-03-022990 — 12, 7
- 2003-07-17 0001104659-03-015053 — 9
- 2003-04-18 0001104659-03-006823 — 7, 9
- 2003-02-14 0001104659-03-002607 — 5, 7

## late-filing notifications on or before 2023-03-01

- 2015-03-02 0000926326-15-000006 — NT 10-K, for the period ended 2014-12-31
- 2007-03-16 0001104659-07-020094 — NT 10-K, for the period ended 2006-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001104659-23-026700:8k_2_02:1]
EX-99.1
2
tm237595d1_ex99-1.htm
EXHIBIT 99.1

[0001104659-23-026700:8k_2_02:2]
Exhibit 99.1

[0001104659-23-026700:8k_2_02:3]
| Contact: |  |  |
| Kathleen Nemeth |  | Omnicell, Inc. |
| Senior Vice President, Investor Relations |  | 2625 Augustine Drive, Suite 301 |
| 650-435-3318 |  | Santa Clara, CA 95054 |
| Kathleen.Nemeth@Omnicell.com |  |  |

[0001104659-23-026700:8k_2_02:4]
Omnicell Announces Fiscal Year and Fourth Quarter
2022 Results

[0001104659-23-026700:8k_2_02:5]
2022 Total Bookings of $1.054 billion

[0001104659-23-026700:8k_2_02:6]
Full Year 2022 GAAP Revenues of $1.296 and non-GAAP
Revenues of $1.297 billion

[0001104659-23-026700:8k_2_02:7]
Ended Year with Over 150 Long-Term, Sole-Source
Agreements with the Top 300 U.S. Health Systems

[0001104659-23-026700:8k_2_02:8]
Year End 2022 Backlog of $1.215 billion

[0001104659-23-026700:8k_2_02:9]
Chief Financial Officer to Step Down effective
July 1, 2023

[0001104659-23-026700:8k_2_02:10]
SANTA CLARA, Calif. -- February 28, 2023 -- Omnicell, Inc.
(NASDAQ:OMCL) (“Omnicell,” “we,” “our,” “us,” “management,” or the “Company”),
a leading provider of medication management solutions and adherence tools for healthcare systems and pharmacies, today announced results
for fiscal year and fourth quarter ended December 31, 2022.

[0001104659-23-026700:8k_2_02:11]
“Omnicell delivered results generally exceeding our revised outlook
for the fourth quarter and full year 2022 in the face of continued headwinds and macroeconomic uncertainty” said Randall Lipps,
Founder, Chairman, President and Chief Executive Officer of Omnicell. “Omnicell has strong customer relationships, unique expertise
within medication management, and compelling Advanced Services offerings that we believe are helping our customers meet critical care
needs, improve patient outcomes and realize return on their investments – and we think our long-term opportunities remain robust
as we continue to transform the pharmacy care delivery model. We will continue to manage our business in a way that we believe is prudent,
while we focus on integrating our recent acquisitions and strengthening our operational efficiencies. We remain confident in our strategy
and our ability to drive long-term value creation for all of our stakeholders.”

[0001104659-23-026700:8k_2_02:12]
Omnicell also announced today that Peter J. Kuipers will step down
from his role as Executive Vice President, Chief Financial Officer, effective July 1, 2023. Pending his departure, Mr. Kuipers
will continue to serve as Executive Vice President, Chief Financial Officer while the Company searches for a new Chief Financial Officer
and will assist with the transition of his role and responsibilities. The Company has commenced a national search for his successor, and
Peter will help to assist in a smooth transition. The Company would like to thank Mr. Kuipers for his contributions to the Company
throughout his employment, and for playing an important role in the Company’s growth.

[0001104659-23-026700:8k_2_02:13]
Randall Lipps added “I would like to thank Peter for his contributions
to Omnicell over the last seven years. Peter has played an important role in scaling the company from nearly $500 million in annual revenue
to $1.3 billion in 2022. Peter also made significant contributions leading our international operations. I wish Peter the best as he transitions
to the next chapter in his career.”

[0001104659-23-026700:8k_2_02:14]
GAAP Results

[0001104659-23-026700:8k_2_02:15]
Total GAAP revenues for the fourth quarter of 2022 were $298 million,
down $13 million, or 4%, from the fourth quarter of 2021. The decrease in GAAP revenues reflects ongoing macroeconomic challenges and
health systems capital budget freezes and delays, as well as ongoing customer labor shortages.

[0001104659-23-026700:8k_2_02:16]
Total GAAP revenues for the year ended December 31, 2022 were
$1.296 billion, up $164 million, or 14%, from the year ended December 31, 2021.

[0001104659-23-026700:8k_2_02:17]
GAAP net loss for the fourth quarter 2022 was $28 million, or $0.64
per diluted share. This compares to GAAP net income of $14 million, or $0.28 per diluted share, for the fourth quarter of 2021.

[0001104659-23-026700:8k_2_02:18]
GAAP net income for the year ended December 31, 2022 was $6 million,
or $0.12 per diluted share. This compares to GAAP net income of $78 million, or $1.62 per diluted share, for the year ended December 31,
2021.

[0001104659-23-026700:8k_2_02:19]
Non-GAAP Results

[0001104659-23-026700:8k_2_02:20]
Total non-GAAP revenues for the fourth quarter of 2022 were $298 million,
down $14 million, or 4%, from the fourth quarter of 2021. The decrease in non-GAAP revenues reflects ongoing macroeconomic challenges
and health systems capital budget freezes and delays, as well as ongoing customer labor shortages.

[0001104659-23-026700:8k_2_02:21]
Total non-GAAP revenues for the year ended December 31, 2022 were
$1.297 billion, up $164 million, or 14%, from the year ended December 31, 2021.

[0001104659-23-026700:8k_2_02:22]
Total non-GAAP net income for the fourth quarter of 2022 was $15 million,
or $0.33 per diluted share. This compares to non-GAAP net income of $44 million, or $0.92 per diluted share, for the fourth quarter of
2021.

[0001104659-23-026700:8k_2_02:23]
Total non-GAAP net income for the year ended December 31, 2022
was $136 million, or $3.00 per diluted share. This compares to non-GAAP net income of $175 million, or $3.81 per diluted share, for the
year ended December 31, 2021.

[0001104659-23-026700:8k_2_02:24]
Total non-GAAP EBITDA for the fourth quarter of 2022 was $26 million.
This compares to non-GAAP EBITDA of $52 million for the fourth quarter of 2021.

[0001104659-23-026700:8k_2_02:25]
Total non-GAAP EBITDA for the year ended December 31, 2022 was
$193 million. This compares to non-GAAP EBITDA of $230 million for the year ended December 31, 2021.

[0001104659-23-026700:8k_2_02:26]
Bookings and Backlog

[0001104659-23-026700:8k_2_02:27]
Total bookings (1) for the year ended December 31,
2022 were $1.054 billion compared to $1.217 billion for the year ended December 31, 2021, or a decrease of 13% year-over-year,
primarily driven by reduced demand for connected devices, partially offset by strong demand for Advanced Services offerings and the impact
of acquisitions.

[0001104659-23-026700:8k_2_02:28]
Total backlog (2) for the years ended December 31,
2022 and 2021 was as follows:

[0001104659-23-026700:8k_2_02:29]
|  |  | December 31, |  |
|  |  | 2022 |  |  | 2021 |  |
|  |  | (In thousands) |  |
| Total backlog |  | $ | 1,215,462 |  |  | $ | 1,253,801 |  |
| By type: |  |  |  |  |  |  |  |  |
| Product backlog |  | $ | 796,967 |  |  | $ | 976,734 |  |
| Advanced Services backlog (3) |  | $ | 418,495 |  |  | $ | 277,067 |  |
| By duration and type: |  |  |  |  |  |  |  |  |
| Short-term product backlog |  | $ | 503,303 |  |  | $ | 744,303 |  |
| Long-term product backlog |  | $ | 293,664 |  |  | $ | 232,431 |  |
| Short-term Advanced Services backlog (3) |  | $ | 49,567 |  |  | $ | 36,925 |  |
| Long-term Advanced Services backlog (3) |  | $ | 368,928 |  |  | $ | 240,142 |  |

[0001104659-23-026700:8k_2_02:30]
|  | (1) | We define bookings generally as: (i) the value of non-cancelable contracts for our connected devices, software products, and Advanced Services (although, for those Advanced Services contracts without a minimum commitment, bookings only include the amount of revenue that has been recognized once the services have been provided); and (ii) for our consumables, the value of orders placed through our Omnicell Storefront online platform or through written or telephonic orders. We typically exclude technical services and other less significant items ancillary to our products and services, such as freight revenue from bookings. We utilize bookings as an indicator of the success of our business. |

[0001104659-23-026700:8k_2_02:31]
|  | (2) | Backlog is the dollar amount of bookings that have not yet been recognized as revenue. Bookings for those Advanced Services contracts without a minimum commitment are not included in backlog. A majority of our connected devices and software license products are installable and recognized as revenues within twelve months of booking, while service revenues from Advanced Services are recorded over the contractual term. We consider backlog that is expected to be converted to revenues in more than twelve months to be long-term backlog. We believe a majority of long-term product backlog will be convertible into revenues in 12-24 months. Long-term Advanced Services backlog typically represents multi-year subscription agreements (usually with contractual terms of 2-7 years, some of which have not yet been implemented) that will be converted to revenue ratably over the contractual term. Due to industry practice that allows customers to change order configurations with limited advance notice prior to shipment and as customer installation schedules may change, backlog as of any particular date may not necessarily indicate the timing of future revenue. However, we do believe that backlog is an indication of a customer’s willingness to install our solutions and revenue we expect to generate over time. |

[0001104659-23-026700:8k_2_02:32]
|  | (3) | Includes only the value of Advanced Services non-cancelable contracts with minimum commitments. |

[0001104659-23-026700:8k_2_02:33]
Balance Sheet

[0001104659-23-026700:8k_2_02:34]
As of December 31, 2022, Omnicell’s balance sheet reflected
cash and cash equivalents of $330 million, total debt (net of unamortized debt issuance costs) of $567 million, and total assets of $2.21
billion. Cash flows provided by operating activities in the fourth quarter of 2022 totaled $82 million. This compares to cash flows provided
by operating activities totaling $60 million in the fourth quarter of 2021.

[0001104659-23-026700:8k_2_02:35]
As of December 31, 2022, the Company had $500 million of availability
under its revolving credit facility.

[0001104659-23-026700:8k_2_02:36]
Business Highlights

[0001104659-23-026700:8k_2_02:37]
|  | • | With the launch of Specialty Pharmacy Services in 2022, along with new technology advancements in IV compounding robotics and Inventory Optimization, Omnicell’s Advanced Services are designed to deliver a comprehensive offering that is expected to drive enhanced clinical and business outcomes for our customers across all settings of care. |

[0001104659-23-026700:8k_2_02:38]
|  | • | Market demand for our Advanced Services offerings appeared to continue to gain momentum in 2022, with health systems using these technologies to help enable them to achieve significant benefits and improved outcomes for their pharmacy care. |

[0001104659-23-026700:8k_2_02:39]
|  | • | Recognizing our belief that a combination of technology, expertise and intelligence are key to supporting safe medication management, Omnicell has entered into a strategic alliance with Long Island University (“LIU”) to launch a center for innovative medication management. This immersive experience, which is expected to open this Spring, is intended to help expand technological and analytical expertise for LIU Pharmacy students and support the continuing transformation of the pharmacy care delivery model. |

[0001104659-23-026700:8k_2_02:40]
|  | • | Continuous improvement for our environmental, social, and corporate governance (“ESG”) program: Omnicell was ranked in the 4th percentile for the healthcare IT services subindustry for ESG risk management (4) and was ranked in the highest score range relative to global peers for Corporate Governance (5). |

[0001104659-23-026700:8k_2_02:41]
(4)  Sustainalytics ESG Risk Rating Report published on
1/24/2023.

[0001104659-23-026700:8k_2_02:42]
(5)  MSCI report published on
02/14/2023.

[0001104659-23-026700:8k_2_02:43]
2023 Guidance

[0001104659-23-026700:8k_2_02:44]
For the full year 2023, the Company expects bookings to be between
$1.000 billion and $1.100 billion. The Company expects full year 2023 total revenues to be between $1.150 billion and $1.190 billion.
The Company expects full year 2023 product revenues to be between $740 million and $760 million, and full year 2023 service revenues to
be between $410 million and $430 million. The Company expects full year 2023 technical services revenues to be between $210 million and
$220 million, and full year 2023 Advanced Services revenues to be between $200 million and $210 million. The Company expects full year
2023 non-GAAP EBITDA to be between $120 million and $135 million. The Company expects full year 2023 non-GAAP earnings per share to be
between $1.55 and $1.80 per share.

[0001104659-23-026700:8k_2_02:45]
For the first quarter of 2023, the Company expects total revenues to
be between $273 million and $283 million. The Company expects first quarter 2023 product revenues to be between $179 million and $184
million, and first quarter 2023 service revenues to be between $94 million and $99 million. The Company expects first quarter 2023 non-GAAP
EBITDA to be between $6 million and $12 million. The Company expects first quarter 2023 non-GAAP earnings per share to be between $0.04
and $0.14 per share.

[0001104659-23-026700:8k_2_02:46]
The table below summarizes Omnicell’s 2023 guidance outlined
above.

[0001104659-23-026700:8k_2_02:47]
|  |  | Q1 2023 |  | 2023 |
| Bookings |  | Not provided |  | $1.000 billion - $1.100 billion |
| Total Revenues |  | $273 million - $283 million |  | $1.150 billion - $1.190 billion |
| Product Revenues |  | $179 million - $184 million |  | $740 million - $760 million |
| Service Revenues |  | $94 million - $99 million |  | $410 million - $430 million |
| Technical Services Revenues |  | Not provided |  | $210 million - $220 million |
| Advanced Services Revenues |  | Not provided |  | $200 million - $210 million |
| Non-GAAP EBITDA |  | $6 million - $12 million |  | $120 million - $135 million |
| Non-GAAP Earnings Per Share |  | $0.04 - $0.14 |  | $1.55 - $1.80 |

[0001104659-23-026700:8k_2_02:48]
The Company does not provide guidance for GAAP net income or GAAP earnings
per share, nor a reconciliation of these forward-looking non-GAAP financial measures to the most directly comparable GAAP financial measures
on a forward-looking basis because it is unable to predict certain items contained in the GAAP measures without unreasonable efforts.
These forward-looking non-GAAP financial measures do not include certain items, which may be significant, including, but not limited to,
unusual gains and losses, costs associated with future restructurings, acquisition-related expenses, and certain tax and litigation outcomes.

[0001104659-23-026700:8k_2_02:49]
Omnicell Conference Call Information

[0001104659-23-026700:8k_2_02:50]
Omnicell will hold a conference call today, Tuesday, February 28,
2023 at 4:30 p.m. ET to discuss fourth quarter and year end 2022 financial results. The conference call can be monitored by dialing
1-888-550-5424 within the U.S. or 1-646-960-0819 for all other locations. A link to the live and archived webcast will also be available
on the Investor Relations section of Omnicell’s website at https://ir.omnicell.com/events-and-presentations/.

[0001104659-23-026700:8k_2_02:51]
About Omnicell

[0001104659-23-026700:8k_2_02:52]
Since 1992, Omnicell has been committed to transforming the pharmacy
care delivery model to dramatically improve outcomes and lower costs. Through the industry vision of the Autonomous Pharmacy, a combination
of automation, intelligence, and technology-enabled services, powered by a cloud data platform, Omnicell supports more efficient ways
to manage medications across all care settings. Healthcare facilities worldwide use Omnicell automation and analytics solutions to help
increase operational efficiency, reduce medication errors, deliver actionable intelligence, and improve patient safety. Institutional
and retail pharmacies across North America and the United Kingdom leverage Omnicell’s innovative medication adherence and population
health solutions to improve patient engagement and adherence to prescriptions, helping to reduce costly hospital readmissions.

[0001104659-23-026700:8k_2_02:53]
To learn more, visit www.omnicell.com. From time to time, Omnicell
may use the Company’s investor relations website and other online social media channels, including its Twitter handle www.twitter.com/omnicell,
LinkedIn page www.linkedin.com/company/omnicell, and Facebook page www.facebook.com/omnicellinc, to disclose material non-public
information and comply with its disclosure obligations under Regulation Fair Disclosure (“Reg FD”).

[0001104659-23-026700:8k_2_02:54]
OMNICELL and the Omnicell logo are registered trademarks of Omnicell, Inc.
or one of its subsidiaries.

[0001104659-23-026700:8k_2_02:55]
Forward-Looking Statements

[0001104659-23-026700:8k_2_02:56]
Use of Non-GAAP Financial Information

[0001104659-23-026700:8k_2_02:57]
This press release contains financial measures that are not calculated
in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”). Management evaluates and makes operating decisions
using various performance measures. In addition to Omnicell’s GAAP results, we also consider non-GAAP revenues, non-GAAP gross profit,
non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP operating margin, non-GAAP net income, non-GAAP
net income per diluted share, non-GAAP diluted shares, non-GAAP EBITDA, non-GAAP EBITDA margin, and non-GAAP free cash flow. These non-GAAP
results and metrics should not be considered as an alternative to revenues, gross profit, operating expenses, income from operations,
net income, net income per diluted share, diluted shares, net cash provided by operating activities, or any other performance measure
derived in accordance with GAAP. We present these non-GAAP results and metrics because management considers them to be important supplemental
measures of Omnicell’s performance and refers to such measures when analyzing Omnicell’s strategy and operations.

[0001104659-23-026700:8k_2_02:58]
5

[0001104659-23-026700:8k_2_02:59]
Our non-GAAP revenues, non-GAAP gross profit, non-GAAP gross margin,
non-GAAP operating expenses, non-GAAP income from operations, non-GAAP operating margin, non-GAAP net income, non-GAAP net income per
diluted share, non-GAAP EBITDA, and non-GAAP EBITDA margin are exclusive of certain items to facilitate management’s review of the
comparability of Omnicell’s core operating results on a period-to-period basis because such items are not related to Omnicell’s
ongoing core operating results as viewed by management. We define our “core operating results” as those revenues recorded
in a particular period and the expenses incurred within such period that directly drive operating income in such period. Management uses
these non-GAAP financial measures in making operating decisions because, in addition to meaningful supplemental information regarding
operating performance, the measures give us a better understanding of how we believe we should invest in research and development, fund
infrastructure growth, and evaluate the effectiveness of marketing strategies. In calculating the above non-GAAP results: non-GAAP revenues
excludes from its GAAP equivalent item a) below; non-GAAP gross profit and non-GAAP gross margin exclude from their GAAP equivalents items
a), b), c), f), and g) below; non-GAAP operating expenses excludes from its GAAP equivalents items b), c), d), e), f), g), and j) below;
non-GAAP income from operations and non-GAAP operating margin exclude from their GAAP equivalents items a), b), c), d), e), f), g), and
j) below; and non-GAAP net income and non-GAAP net income per diluted share exclude from their GAAP equivalents items a) through k) below.
Non-GAAP EBITDA is defined as earnings before interest income and expense, taxes, depreciation, amortization, and share-based compensation,
as well as excluding certain other non-GAAP adjustments. Non-GAAP EBITDA and non-GAAP EBITDA margin exclude from their GAAP equivalents
items a), b), d), e), f), g), h), i), and j) below:

[0001104659-23-026700:8k_2_02:60]
|  | a) | Acquisition accounting impact related to deferred revenues. In connection with the recent acquisition of FDS Amplicare, we recorded a fair value adjustment to acquired deferred revenues as part of the purchase accounting in accordance with GAAP. The adjustment represents revenues that would have been recognized in the normal course of business by FDS Amplicare if the acquisition had not occurred, but was not recognized due to GAAP purchase accounting requirements. The non-GAAP adjustment to our revenues is intended to include the full amounts of such revenues. We believe the adjustment to these revenues is useful as a measure of the ongoing performance of our business. |

[0001104659-23-026700:8k_2_02:61]
|  | b) | Share-based compensation expense. We excluded from our non-GAAP results the expense related to equity-based compensation plans as it represents expenses that do not require cash settlement from Omnicell. |

[0001104659-23-026700:8k_2_02:62]
|  | c) | Amortization of acquired intangible assets. We excluded from our non-GAAP results the intangible assets amortization expense resulting from our past acquisitions. These non-cash charges are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results. |

[0001104659-23-026700:8k_2_02:63]
|  | d) | Acquisition-related expenses. We excluded from our non-GAAP results the expenses related to recent acquisitions, including amortization of representations and warranties insurance. These expenses are unrelated to our ongoing operations, vary in size and frequency, and are subject to significant fluctuations from period to period due to varying levels of acquisition activity. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of less acquisitive peer companies. |

[0001104659-23-026700:8k_2_02:64]
|  | e) | Impairment and abandonment of operating lease right-of-use assets related to facilities. We excluded from our non-GAAP results the impairment and abandonment of operating lease right-of-use assets incurred in connection with restructuring activities for optimization of certain leased facilities. These non-cash charges are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results. |

[0001104659-23-026700:8k_2_02:65]
|  | f) | Ransomware-related expenses, net of insurance recoveries. We excluded from our non-GAAP results the net expenses related to the previously disclosed ransomware incident identified by the Company on May 4, 2022. Expenses include costs to investigate and remediate the ransomware incident, as well as legal and other professional services, and are presented net of expected insurance recoveries. These expenses are unrelated to our ongoing operations and would not have otherwise been incurred by us in the normal course of business. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of peer companies. |

[0001104659-23-026700:8k_2_02:66]
6

[0001104659-23-026700:8k_2_02:67]
|  | g) | Severance-related expenses. We excluded from our non-GAAP results the expenses related to restructuring events. These expenses are unrelated to our ongoing operations, vary in size and frequency, and are subject to significant fluctuations from period to period due to varying levels of restructuring activity. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of peer companies. |

[0001104659-23-026700:8k_2_02:68]
|  | h) | Amortization of debt issuance costs. Debt issuance costs represent costs associated with the issuance of term loan and revolving credit facilities, as well as the issuance of convertible senior notes. The costs include underwriting fees, original issue discount, ticking fees, and legal fees. These non-cash expenses are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results. |

[0001104659-23-026700:8k_2_02:69]
|  | i) | Amortization of discount on convertible senior notes. We excluded from our non-GAAP results the amortization of the imputed discount on our convertible senior notes. Under GAAP (prior to the adoption of Accounting Standards Update 2020-06, effective January 1, 2022), certain convertible debt instruments that may be settled in cash upon conversion were required to be bifurcated into separate liability and equity components in a manner that reflects the issuer’s assumed non-convertible debt borrowing rate. For GAAP purposes, we were required to recognize the imputed interest expense on the difference between our assumed non-convertible debt borrowing rate and the coupon rate on our convertible senior notes. This non-cash expense is not considered by management to reflect the core cash-generating performance of the business and therefore is excluded from our non-GAAP results. |

[0001104659-23-026700:8k_2_02:70]
|  | j) | Certain litigation costs. We excluded non-recurring charges and benefits, including litigation expenses and settlements, related to litigation matters that are outside of the ordinary course of our business or that are not representative of those that we historically have incurred. These expenses are unrelated to our ongoing operations and we do not expect them to occur in the ordinary course of business. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of peer companies. |

[0001104659-23-026700:8k_2_02:71]
|  | k) | Tax impact of IP restructuring. We excluded from our non-GAAP results the tax impact related to the release of a net uncertain tax benefit as a result of effective settlement with the tax authorities related to prior IP restructuring. This impact is unrelated to our ongoing operations, and we do not expect it to occur in the ordinary course of business. We believe that excluding this impact provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of peer companies. |

[0001104659-23-026700:8k_2_02:72]
Management adjusts for the above items because management believes
that, in general, these items possess one or more of the following characteristics: their magnitude and timing is largely outside of Omnicell’s
control; they are unrelated to the ongoing operation of the business in the ordinary course; they are unusual and we do not expect them
to occur in the ordinary course of business; or they are non-operational or non-cash expenses involving stock compensation plans or other
items.

[0001104659-23-026700:8k_2_02:73]
We believe that the presentation of non-GAAP revenues, non-GAAP gross
profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP operating margin, non-GAAP net income,
non-GAAP net income per diluted share, non-GAAP EBITDA, and non-GAAP EBITDA margin is warranted for several reasons:

[0001104659-23-026700:8k_2_02:74]
|  | a) | Such non-GAAP financial measures provide an additional analytical tool for understanding Omnicell’s financial performance by excluding the impact of items which may obscure trends in the core operating results of the business. |

[0001104659-23-026700:8k_2_02:75]
|  | b) | Since we have historically reported non-GAAP results to the investment community, we believe the inclusion of non-GAAP numbers provides consistency and enhances investors’ ability to compare our performance across financial reporting periods. |

[0001104659-23-026700:8k_2_02:76]
|  | c) | These non-GAAP financial measures are employed by management in its own evaluation of performance and are utilized in financial and operational decision-making processes, such as budget planning and forecasting. |

[0001104659-23-026700:8k_2_02:77]
|  | d) | These non-GAAP financial measures facilitate comparisons to the operating results of other companies in our industry, which also use non-GAAP financial measures to supplement their GAAP results (although these companies may calculate non-GAAP financial measures differently than Omnicell does), thus enhancing the perspective of investors who wish to utilize such comparisons in their analysis of our performance. |

[0001104659-23-026700:8k_2_02:78]
Set forth below are additional reasons why share-based compensation
expense is excluded from our non-GAAP financial measures:

[0001104659-23-026700:8k_2_02:79]
|  | i) | While share-based compensation calculated in accordance with Accounting Standards Codification (“ASC”) 718 constitutes an ongoing and recurring expense of Omnicell, it is not an expense that requires cash settlement by Omnicell. We therefore exclude these charges for purposes of evaluating core operating results. Thus, our non-GAAP measurements are presented exclusive of share-based compensation expense to assist management and investors in evaluating our core operating results. |

[0001104659-23-026700:8k_2_02:80]
|  | ii) | We present ASC 718 share-based payment compensation expense in our reconciliation of non-GAAP financial measures on a pre-tax basis because the exact tax differences related to the timing and deductibility of share-based compensation under ASC 718 are dependent upon the trading price of Omnicell’s common stock and the timing and exercise by employees of their stock options. As a result of these timing and market uncertainties, the tax effect related to share-based compensation expense would be inconsistent in amount and frequency and is therefore excluded from our non-GAAP results. |

[0001104659-23-026700:8k_2_02:81]
Non-GAAP diluted shares is defined as our GAAP diluted shares, excluding
the impact of dilutive convertible senior notes for which the Company is economically hedged through its anti-dilutive convertible note
hedge transaction. We believe non-GAAP diluted shares is a useful non-GAAP metric because it provides insight into the offsetting economic
effect of the hedge transaction against potential conversion of the convertible senior notes.

[0001104659-23-026700:8k_2_02:82]
Non-GAAP free cash flow is defined as net cash provided by operating
activities less cash used for software development for external use and purchases of property and equipment. We believe free cash flow
is important to enable investors to better understand and evaluate our ongoing operating results and allows for greater transparency in
the review and understanding of our overall financial, operational, and economic performance, because free cash flow takes into account
certain capital expenditures and cash used for software development necessary to operate our business.

[0001104659-23-026700:8k_2_02:83]
As stated above, we present non-GAAP financial measures because we
consider them to be important supplemental measures of performance. However, non-GAAP financial measures have limitations as an analytical
tool and should not be considered in isolation or as a substitute for Omnicell’s GAAP results. In the future, we expect to incur
expenses similar to certain of the non-GAAP adjustments described above and expect to continue reporting non-GAAP financial measures excluding
such items. Some of the limitations in relying on non-GAAP financial measures are:

[0001104659-23-026700:8k_2_02:84]
|  | a) | Omnicell’s equity incentive plans and stock purchase plans are important components of incentive compensation arrangements and will be reflected as expenses in Omnicell’s GAAP results for the foreseeable future under ASC 718. |

[0001104659-23-026700:8k_2_02:85]
|  | b) | Other companies, including companies in Omnicell’s industry, may calculate non-GAAP financial measures differently than Omnicell, limiting their usefulness as a comparative measure. |

[0001104659-23-026700:8k_2_02:86]
|  | c) | A limitation of the utility of free cash flow as a measure of financial performance is that it does not represent the total increase or decrease in Omnicell’s cash balance for the period. |

[0001104659-23-026700:8k_2_02:87]
A detailed reconciliation between Omnicell’s non-GAAP and GAAP
financial results is set forth in the financial tables at the end of this press release. Investors are advised to carefully review and
consider this information strictly as a supplement to the GAAP results that are contained in this press release as well as in Omnicell’s
other reports filed with or furnished to the SEC.

[0001104659-23-026700:8k_2_02:88]
8

[0001104659-23-026700:8k_2_02:89]
Omnicell, Inc.

[0001104659-23-026700:8k_2_02:90]
Condensed Consolidated Statements of Operations

[0001104659-23-026700:8k_2_02:91]
(Unaudited, in thousands, except per share data)

[0001104659-23-026700:8k_2_02:92]
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product revenues |  | $ | 196,976 |  |  | $ | 223,506 |  |  | $ | 903,222 |  |  | $ | 812,512 |  |
| Services and other revenues |  |  | 100,698 |  |  |  | 87,528 |  |  |  | 392,725 |  |  |  | 319,506 |  |
| Total revenues |  |  | 297,674 |  |  |  | 311,034 |  |  |  | 1,295,947 |  |  |  | 1,132,018 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product revenues |  |  | 119,451 |  |  |  | 119,258 |  |  |  | 493,626 |  |  |  | 422,855 |  |
| Cost of services and other revenues |  |  | 56,470 |  |  |  | 42,483 |  |  |  | 213,334 |  |  |  | 154,510 |  |
| Total cost of revenues |  |  | 175,921 |  |  |  | 161,741 |  |  |  | 706,960 |  |  |  | 577,365 |  |
| Gross profit |  |  | 121,753 |  |  |  | 149,293 |  |  |  | 588,987 |  |  |  | 554,653 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 28,413 |  |  |  | 21,946 |  |  |  | 104,969 |  |  |  | 75,716 |  |
| Selling, general, and administrative |  |  | 131,697 |  |  |  | 115,758 |  |  |  | 486,341 |  |  |  | 389,430 |  |
| Total operating expenses |  |  | 160,110 |  |  |  | 137,704 |  |  |  | 591,310 |  |  |  | 465,146 |  |
| Income (loss) from operations |  |  | (38,357 | ) |  |  | 11,589 |  |  |  | (2,323 | ) |  |  | 89,507 |  |
| Interest and other income (expense), net |  |  | 2,843 |  |  |  | (4,785 | ) |  |  | (130 | ) |  |  | (23,500 | ) |
| Income (loss) before provision for income taxes |  |  | (35,514 | ) |  |  | 6,804 |  |  |  | (2,453 | ) |  |  | 66,007 |  |
| Benefit from income taxes |  |  | (7,106 | ) |  |  | (7,177 | ) |  |  | (8,101 | ) |  |  | (11,842 | ) |
| Net income (loss) |  | $ | (28,408 | ) |  | $ | 13,981 |  |  | $ | 5,648 |  |  | $ | 77,849 |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | (0.64 | ) |  | $ | 0.32 |  |  | $ | 0.13 |  |  | $ | 1.79 |  |
| Diluted |  | $ | (0.64 | ) |  | $ | 0.28 |  |  | $ | 0.12 |  |  | $ | 1.62 |  |
| Weighted-average shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 44,678 |  |  |  | 44,015 |  |  |  | 44,398 |  |  |  | 43,475 |  |
| Diluted |  |  | 44,678 |  |  |  | 49,849 |  |  |  | 45,891 |  |  |  | 47,943 |  |

[0001104659-23-026700:8k_2_02:93]
Omnicell, Inc.

[0001104659-23-026700:8k_2_02:94]
Condensed Consolidated Balance Sheets

[0001104659-23-026700:8k_2_02:95]
(Unaudited, in thousands)

[0001104659-23-026700:8k_2_02:96]
|  |  | December 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| ASSETS |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 330,362 |  |  | $ | 349,051 |  |
| Accounts receivable and unbilled receivables, net |  |  | 299,469 |  |  |  | 240,894 |  |
| Inventories |  |  | 147,549 |  |  |  | 119,924 |  |
| Prepaid expenses |  |  | 27,070 |  |  |  | 22,499 |  |
| Other current assets |  |  | 77,362 |  |  |  | 48,334 |  |
| Total current assets |  |  | 881,812 |  |  |  | 780,702 |  |
| Property and equipment, net |  |  | 93,961 |  |  |  | 71,141 |  |
| Long-term investment in sales-type leases, net |  |  | 32,924 |  |  |  | 18,391 |  |
| Operating lease right-of-use assets |  |  | 38,052 |  |  |  | 48,549 |  |
| Goodwill |  |  | 734,274 |  |  |  | 738,900 |  |
| Intangible assets, net |  |  | 242,906 |  |  |  | 277,616 |  |
| Long-term deferred tax assets |  |  | 22,329 |  |  |  | 15,883 |  |
| Prepaid commissions |  |  | 59,483 |  |  |  | 63,795 |  |
| Other long-term assets |  |  | 105,017 |  |  |  | 127,519 |  |
| Total assets |  | $ | 2,210,758 |  |  | $ | 2,142,496 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 63,389 |  |  | $ | 71,513 |  |
| Accrued compensation |  |  | 73,455 |  |  |  | 71,130 |  |
| Accrued liabilities |  |  | 172,655 |  |  |  | 133,167 |  |
| Deferred revenues, net |  |  | 118,947 |  |  |  | 112,196 |  |
| Convertible senior notes, net |  |  | — |  |  |  | 488,152 |  |
| Total current liabilities |  |  | 428,446 |  |  |  | 876,158 |  |
| Long-term deferred revenues |  |  | 37,385 |  |  |  | 20,194 |  |
| Long-term deferred tax liabilities |  |  | 2,095 |  |  |  | 51,705 |  |
| Long-term operating lease liabilities |  |  | 39,405 |  |  |  | 39,911 |  |
| Other long-term liabilities |  |  | 6,719 |  |  |  | 7,839 |  |
| Convertible senior notes, net |  |  | 566,571 |  |  |  | — |  |
| Total liabilities |  |  | 1,080,621 |  |  |  | 995,807 |  |
| Total stockholders’ equity |  |  | 1,130,137 |  |  |  | 1,146,689 |  |
| Total liabilities and stockholders’ equity |  | $ | 2,210,758 |  |  | $ | 2,142,496 |  |

[0001104659-23-026700:8k_2_02:97]
10

[0001104659-23-026700:8k_2_02:98]
Omnicell, Inc.

[0001104659-23-026700:8k_2_02:99]
Condensed Consolidated Statements of Cash Flows

[0001104659-23-026700:8k_2_02:100]
(Unaudited, in thousands)

[0001104659-23-026700:8k_2_02:101]
|  |  | Year Ended December 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Operating Activities |  |  |  |  |  |  |  |  |
| Net income |  | $ | 5,648 |  |  | $ | 77,849 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 86,931 |  |  |  | 72,990 |  |
| Loss on disposal of property and equipment |  |  | 678 |  |  |  | 433 |  |
| Share-based compensation expense |  |  | 68,247 |  |  |  | 53,160 |  |
| Deferred income taxes |  |  | (37,316 | ) |  |  | (3,272 | ) |
| Amortization of operating lease right-of-use assets |  |  | 12,238 |  |  |  | 11,941 |  |
| Impairment and abandonment of operating lease right-of-use assets related to facilities |  |  | 9,382 |  |  |  | — |  |
| Impairment of externally and internally developed capitalized software, net |  |  | 1,275 |  |  |  | — |  |
| Amortization of debt issuance costs |  |  | 4,164 |  |  |  | 3,440 |  |
| Amortization of discount on convertible senior notes |  |  | — |  |  |  | 18,608 |  |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable and unbilled receivables |  |  | (60,357 | ) |  |  | (40,973 | ) |
| Inventories |  |  | (30,115 | ) |  |  | (25,695 | ) |
| Prepaid expenses |  |  | (4,671 | ) |  |  | (5,678 | ) |
| Other current assets |  |  | 6,360 |  |  |  | 2,801 |  |
| Investment in sales-type leases |  |  | (15,354 | ) |  |  | 3,346 |  |
| Prepaid commissions |  |  | 4,312 |  |  |  | (6,876 | ) |
| Other long-term assets |  |  | 5,027 |  |  |  | (3,258 | ) |
| Accounts payable |  |  | (7,754 | ) |  |  | 29,084 |  |
| Accrued compensation |  |  | 2,446 |  |  |  | 12,312 |  |
| Accrued liabilities |  |  | 16,651 |  |  |  | 34,859 |  |
| Deferred revenues |  |  | 24,469 |  |  |  | 24,179 |  |
| Operating lease liabilities |  |  | (13,781 | ) |  |  | (12,503 | ) |
| Other long-term liabilities |  |  | (699 | ) |  |  | (14,938 | ) |
| Net cash provided by operating activities |  |  | 77,781 |  |  |  | 231,809 |  |
| Investing Activities |  |  |  |  |  |  |  |  |
| Software development for external use |  |  | (13,204 | ) |  |  | (29,368 | ) |
| Purchases of property and equipment |  |  | (47,536 | ) |  |  | (28,967 | ) |
| Business acquisitions, net of cash acquired |  |  | (3,392 | ) |  |  | (354,163 | ) |
| Purchase price adjustments from business acquisitions |  |  | 5,463 |  |  |  | — |  |
| Net cash used in investing activities |  |  | (58,669 | ) |  |  | (412,498 | ) |
| Financing Activities |  |  |  |  |  |  |  |  |
| Proceeds from issuances under stock-based compensation plans |  |  | 40,182 |  |  |  | 67,348 |  |
| Employees’ taxes paid related to restricted stock units |  |  | (13,506 | ) |  |  | (16,286 | ) |
| Stock repurchases |  |  | (52,210 | ) |  |  | — |  |
| Change in customer funds, net |  |  | 4,581 |  |  |  | (3,699 | ) |
| Net cash provided by (used in) financing activities |  |  | (20,953 | ) |  |  | 47,363 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (944 | ) |  |  | (974 | ) |
| Net decrease in cash, cash equivalents, and restricted cash |  |  | (2,785 | ) |  |  | (134,300 | ) |
| Cash, cash equivalents, and restricted cash at beginning of period |  |  | 355,620 |  |  |  | 489,920 |  |
| Cash, cash equivalents, and restricted cash at end of period |  | $ | 352,835 |  |  | $ | 355,620 |  |
| Reconciliation of cash, cash equivalents, and restricted cash to the Condensed Consolidated Balance Sheets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 330,362 |  |  | $ | 349,051 |  |
| Restricted cash included in other current assets |  |  | 22,473 |  |  |  | 6,569 |  |
| Cash, cash equivalents, and restricted cash at end of period |  | $ | 352,835 |  |  | $ | 355,620 |  |

[0001104659-23-026700:8k_2_02:102]
Omnicell, Inc.

[0001104659-23-026700:8k_2_02:103]
Reconciliation of GAAP to Non-GAAP

[0001104659-23-026700:8k_2_02:104]
(Unaudited, in thousands, except per share data
and percentage)

[0001104659-23-026700:8k_2_02:105]
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Reconciliation of GAAP revenues to non-GAAP revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP revenues |  | $ | 297,674 |  |  | $ | 311,034 |  |  | $ | 1,295,947 |  |  | $ | 1,132,018 |  |
| Acquisition accounting impact related to deferred revenues |  |  | 40 |  |  |  | 685 |  |  |  | 903 |  |  |  | 780 |  |
| Non-GAAP revenues |  | $ | 297,714 |  |  | $ | 311,719 |  |  | $ | 1,296,850 |  |  | $ | 1,132,798 |  |
| Reconciliation of GAAP gross profit to non-GAAP gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP gross profit |  | $ | 121,753 |  |  | $ | 149,293 |  |  | $ | 588,987 |  |  | $ | 554,653 |  |
| GAAP gross margin |  |  | 40.9 | % |  |  | 48.0 | % |  |  | 45.4 | % |  |  | 49.0 | % |
| Share-based compensation expense |  |  | 2,460 |  |  |  | 2,104 |  |  |  | 9,067 |  |  |  | 7,994 |  |
| Amortization of acquired intangibles |  |  | 3,115 |  |  |  | 3,228 |  |  |  | 13,204 |  |  |  | 11,438 |  |
| Acquisition accounting impact related to deferred revenues |  |  | 40 |  |  |  | 685 |  |  |  | 903 |  |  |  | 780 |  |
| Ransomware-related expenses, net of insurance recoveries |  |  | — |  |  |  | — |  |  |  | 317 |  |  |  | — |  |
| Severance-related expenses |  |  | 7,418 |  |  |  | — |  |  |  | 8,018 |  |  |  | 389 |  |
| Non-GAAP gross profit |  | $ | 134,786 |  |  | $ | 155,310 |  |  | $ | 620,496 |  |  | $ | 575,254 |  |
| Non-GAAP gross margin |  |  | 45.3 | % |  |  | 49.8 | % |  |  | 47.8 | % |  |  | 50.8 | % |
| Reconciliation of GAAP operating expenses to non-GAAP operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP operating expenses |  | $ | 160,110 |  |  | $ | 137,704 |  |  | $ | 591,310 |  |  | $ | 465,146 |  |
| GAAP operating expenses % to total revenues |  |  | 53.8 | % |  |  | 44.3 | % |  |  | 45.6 | % |  |  | 41.1 | % |
| Share-based compensation expense |  |  | (15,056 | ) |  |  | (12,579 | ) |  |  | (59,180 | ) |  |  | (45,166 | ) |
| Amortization of acquired intangibles |  |  | (5,319 | ) |  |  | (4,560 | ) |  |  | (21,873 | ) |  |  | (14,900 | ) |
| Acquisition-related expenses |  |  | (246 | ) |  |  | (4,392 | ) |  |  | (2,155 | ) |  |  | (11,150 | ) |
| Impairment and abandonment of operating lease right-of-use assets related to facilities |  |  | (3,992 | ) |  |  | — |  |  |  | (9,382 | ) |  |  | — |  |
| Ransomware-related expenses, net of insurance recoveries |  |  | (73 | ) |  |  | — |  |  |  | (2,157 | ) |  |  | — |  |
| Severance-related and other expenses (a) |  |  | (11,364 | ) |  |  | (350 | ) |  |  | (16,785 | ) |  |  | (2,932 | ) |
| Non-GAAP operating expenses |  | $ | 124,060 |  |  | $ | 115,823 |  |  | $ | 479,778 |  |  | $ | 390,998 |  |
| Non-GAAP operating expenses as a % of total non-GAAP revenues |  |  | 41.7 | % |  |  | 37.2 | % |  |  | 37.0 | % |  |  | 34.5 | % |
| Reconciliation of GAAP income (loss) from operations to non-GAAP income from operations: |  |  |  |  |  |  |  |  |  |  |  |
| GAAP income (loss) from operations |  | $ | (38,357 | ) |  | $ | 11,589 |  |  | $ | (2,323 | ) |  | $ | 89,507 |  |
| GAAP operating income (loss) % to total revenues |  |  | (12.9 | )% |  |  | 3.7 | % |  |  | (0.2 | )% |  |  | 7.9 | % |
| Share-based compensation expense |  |  | 17,516 |  |  |  | 14,683 |  |  |  | 68,247 |  |  |  | 53,160 |  |
| Amortization of acquired intangibles |  |  | 8,434 |  |  |  | 7,788 |  |  |  | 35,077 |  |  |  | 26,338 |  |
| Acquisition accounting impact related to deferred revenues |  |  | 40 |  |  |  | 685 |  |  |  | 903 |  |  |  | 780 |  |
| Acquisition-related expenses |  |  | 246 |  |  |  | 4,392 |  |  |  | 2,155 |  |  |  | 11,150 |  |
| Impairment and abandonment of operating lease right-of-use assets related to facilities |  |  | 3,992 |  |  |  | — |  |  |  | 9,382 |  |  |  | — |  |
| Ransomware-related expenses, net of insurance recoveries |  |  | 73 |  |  |  | — |  |  |  | 2,474 |  |  |  | — |  |
| Severance-related and other expenses (a) |  |  | 18,782 |  |  |  | 350 |  |  |  | 24,803 |  |  |  | 3,321 |  |
| Non-GAAP income from operations |  | $ | 10,726 |  |  | $ | 39,487 |  |  | $ | 140,718 |  |  | $ | 184,256 |  |
| Non-GAAP operating margin (non-GAAP operating income as a % of total non-GAAP revenues) |  |  | 3.6 | % |  |  | 12.7 | % |  |  | 10.9 | % |  |  | 16.3 | % |

[0001104659-23-026700:8k_2_02:106]
12

[0001104659-23-026700:8k_2_02:107]
Omnicell, Inc.

[0001104659-23-026700:8k_2_02:108]
Reconciliation of GAAP to Non-GAAP

[0001104659-23-026700:8k_2_02:109]
(Unaudited, in thousands, except per share data
and percentage)

[0001104659-23-026700:8k_2_02:110]
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Reconciliation of GAAP net income (loss) to non-GAAP net income: |  |  |  |  |  |  |  |  |  |
| GAAP net income (loss) |  | $ | (28,408 | ) |  | $ | 13,981 |  |  | $ | 5,648 |  |  | $ | 77,849 |  |
| Tax impact of IP restructuring |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (6,202 | ) |
| Share-based compensation expense |  |  | 17,516 |  |  |  | 14,683 |  |  |  | 68,247 |  |  |  | 53,160 |  |
| Amortization of acquired intangibles |  |  | 8,434 |  |  |  | 7,788 |  |  |  | 35,077 |  |  |  | 26,338 |  |
| Acquisition accounting impact related to deferred revenues |  |  | 40 |  |  |  | 685 |  |  |  | 903 |  |  |  | 780 |  |
| Acquisition-related expenses |  |  | 246 |  |  |  | 4,392 |  |  |  | 2,155 |  |  |  | 11,150 |  |
| Impairment and abandonment of operating lease right-of-use assets related to facilities |  |  | 3,992 |  |  |  | — |  |  |  | 9,382 |  |  |  | — |  |
| Ransomware-related expenses, net of insurance recoveries |  |  | 73 |  |  |  | — |  |  |  | 2,474 |  |  |  | — |  |
| Severance-related and other expenses (a) |  |  | 18,782 |  |  |  | 350 |  |  |  | 24,803 |  |  |  | 3,321 |  |
| Amortization of debt issuance costs |  |  | 1,043 |  |  |  | 870 |  |  |  | 4,164 |  |  |  | 3,440 |  |
| Amortization of discount on convertible senior notes |  |  | — |  |  |  | 4,734 |  |  |  | — |  |  |  | 18,608 |  |
| Tax effect of the adjustments above (b) |  |  | (6,848 | ) |  |  | (3,949 | ) |  |  | (16,582 | ) |  |  | (13,360 | ) |
| Non-GAAP net income |  | $ | 14,870 |  |  | $ | 43,534 |  |  | $ | 136,271 |  |  | $ | 175,084 |  |
| Reconciliation of GAAP net income (loss) per share - diluted to non-GAAP net income per share - diluted: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Shares - diluted GAAP |  |  | 44,678 |  |  |  | 49,849 |  |  |  | 45,891 |  |  |  | 47,943 |  |
| Shares - diluted non-GAAP (c) |  |  | 44,993 |  |  |  | 47,256 |  |  |  | 45,417 |  |  |  | 45,899 |  |
| GAAP net income (loss) per share - diluted |  | $ | (0.64 | ) |  | $ | 0.28 |  |  | $ | 0.12 |  |  | $ | 1.62 |  |
| Tax impact of IP restructuring |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (0.14 | ) |
| Share-based compensation expense |  |  | 0.39 |  |  |  | 0.31 |  |  |  | 1.51 |  |  |  | 1.16 |  |
| Amortization of acquired intangibles |  |  | 0.19 |  |  |  | 0.16 |  |  |  | 0.77 |  |  |  | 0.58 |  |
| Acquisition accounting impact related to deferred revenues |  |  | 0.00 |  |  |  | 0.01 |  |  |  | 0.02 |  |  |  | 0.02 |  |
| Acquisition-related expenses |  |  | 0.01 |  |  |  | 0.09 |  |  |  | 0.05 |  |  |  | 0.24 |  |
| Impairment and abandonment of operating lease right-of-use assets related to facilities |  |  | 0.09 |  |  |  | — |  |  |  | 0.21 |  |  |  | — |  |
| Ransomware-related expenses, net of insurance recoveries |  |  | 0.00 |  |  |  | — |  |  |  | 0.05 |  |  |  | — |  |
| Severance-related and other expenses |  |  | 0.42 |  |  |  | 0.01 |  |  |  | 0.55 |  |  |  | 0.07 |  |
| Amortization of debt issuance costs |  |  | 0.02 |  |  |  | 0.02 |  |  |  | 0.09 |  |  |  | 0.07 |  |
| Amortization of discount on convertible senior notes |  |  | — |  |  |  | 0.10 |  |  |  | — |  |  |  | 0.41 |  |
| Non-GAAP dilutive shares impact from convertible note hedge transaction (c) |  |  | — |  |  |  | 0.02 |  |  |  | 0.00 |  |  |  | 0.07 |  |
| Tax effect of the adjustments above (b) |  |  | (0.15 | ) |  |  | (0.08 | ) |  |  | (0.37 | ) |  |  | (0.29 | ) |
| Non-GAAP net income per share - diluted |  | $ | 0.33 |  |  | $ | 0.92 |  |  | $ | 3.00 |  |  | $ | 3.81 |  |
| Reconciliation of GAAP net income (loss) to non-GAAP EBITDA (d): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP net income (loss) |  | $ | (28,408 | ) |  | $ | 13,981 |  |  | $ | 5,648 |  |  | $ | 77,849 |  |
| Share-based compensation expense |  |  | 17,516 |  |  |  | 14,683 |  |  |  | 68,247 |  |  |  | 53,160 |  |
| Interest (income) and expense, net |  |  | (2,410 | ) |  |  | (359 | ) |  |  | (3,721 | ) |  |  | 161 |  |
| Depreciation and amortization expense |  |  | 22,088 |  |  |  | 19,850 |  |  |  | 86,931 |  |  |  | 72,990 |  |
| Acquisition accounting impact related to deferred revenues |  |  | 40 |  |  |  | 685 |  |  |  | 903 |  |  |  | 780 |  |
| Acquisition-related expenses |  |  | 246 |  |  |  | 4,392 |  |  |  | 2,155 |  |  |  | 11,150 |  |
| Impairment and abandonment of operating lease right-of-use assets related to facilities |  |  | 3,992 |  |  |  | — |  |  |  | 9,382 |  |  |  | — |  |
| Ransomware-related expenses, net of insurance recoveries |  |  | 73 |  |  |  | — |  |  |  | 2,474 |  |  |  | — |  |
| Severance-related and other expenses (a) |  |  | 18,782 |  |  |  | 350 |  |  |  | 24,803 |  |  |  | 3,321 |  |
| Amortization of debt issuance costs |  |  | 1,043 |  |  |  | 870 |  |  |  | 4,164 |  |  |  | 3,440 |  |
| Amortization of discount on convertible senior notes |  |  | — |  |  |  | 4,734 |  |  |  | — |  |  |  | 18,608 |  |
| Benefit from income taxes |  |  | (7,106 | ) |  |  | (7,177 | ) |  |  | (8,101 | ) |  |  | (11,842 | ) |
| Non-GAAP EBITDA |  | $ | 25,856 |  |  | $ | 52,009 |  |  | $ | 192,885 |  |  | $ | 229,617 |  |
| Non-GAAP EBITDA margin (non-GAAP EBITDA as a % of total non-GAAP revenues) |  |  | 8.7 | % |  |  | 16.7 | % |  |  | 14.9 | % |  |  | 20.3 | % |

[0001104659-23-026700:8k_2_02:111]
|  | (a) | For the three months and year ended December 31, 2022, other expenses included approximately $1.3 million and $2.0 million of certain litigation costs, respectively. For the three months and year ended December 31, 2021, other expenses included approximately $0.3 million and $1.3 million of certain litigation costs, respectively. |

[0001104659-23-026700:8k_2_02:112]
|  | (b) | Tax effects calculated for all adjustments except share-based compensation expense, using an estimated annual effective tax rate of 21% for both fiscal years 2022 and 2021. |

[0001104659-23-026700:8k_2_02:113]
|  | (c) | For the year ended December 31, 2022, non-GAAP diluted shares exclude approximately 0.5 million shares related to the impact of dilutive convertible senior notes for which the Company is economically hedged through its anti-dilutive convertible note hedge transaction. For the three months and year ended December 31, 2021, non-GAAP diluted shares exclude approximately 2.6 million and 2.0 million shares, respectively. |

[0001104659-23-026700:8k_2_02:114]
|  | (d) | Defined as earnings before interest income and expense, taxes, depreciation, amortization, and share-based compensation, as well as excluding certain other non-GAAP adjustments. |

[0001104659-23-026700:8k_2_02:115]
14

[0001104659-23-026700:8k_2_02:116]
Omnicell, Inc.

[0001104659-23-026700:8k_2_02:117]
Reconciliation of GAAP to Non-GAAP

[0001104659-23-026700:8k_2_02:118]
(Unaudited, in thousands)

[0001104659-23-026700:8k_2_02:119]
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Reconciliation of GAAP net cash provided by operating activities to non-GAAP free cash flow: |  |  |
| GAAP net cash provided by operating activities |  | $ | 82,153 |  |  | $ | 59,632 |  |  | $ | 77,781 |  |  | $ | 231,809 |  |
| Software development for external use |  |  | (3,556 | ) |  |  | (5,227 | ) |  |  | (13,204 | ) |  |  | (29,368 | ) |
| Purchases of property and equipment |  |  | (13,675 | ) |  |  | (11,075 | ) |  |  | (47,536 | ) |  |  | (28,967 | ) |
| Non-GAAP free cash flow |  | $ | 64,922 |  |  | $ | 43,330 |  |  | $ | 17,041 |  |  | $ | 173,474 |  |

[0001104659-23-026700:8k_2_02:120]
15

## item 5.02 — body, verbatim

[0001104659-23-026700:8k_body:1]
Item 5.02. Departure of Directors or Certain
Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers.

[0001104659-23-026700:8k_body:2]
Chief Financial Officer Departure

[0001104659-23-026700:8k_body:3]
On February 28, 2023, the Company announced that
Peter J. Kuipers will step down from his role as Executive Vice President, Chief Financial Officer, effective July 1, 2023. Pending his
departure, Mr. Kuipers will continue to serve as Executive Vice President, Chief Financial Officer while the Company searches for a new
Chief Financial Officer and will assist with the transition of his role and responsibilities.

[0001104659-23-026700:8k_body:4]
In connection with Mr. Kuipers’ departure,
it is expected that the Company and Mr. Kuipers will enter into a separation agreement, the material terms of which have not been finalized
as of the date of this Current Report on Form 8-K.

[0001104659-23-026700:8k_body:5]
The departure of Mr. Kuipers is not due to any
disagreement with the Company on any matter relating to the Company’s operations, policies or practices (financial reporting, accounting
or otherwise).

[0001104659-23-026700:8k_body:6]
The Company would like to thank Mr. Kuipers for
his contributions to the Company throughout his employment, and for playing an important role in the Company’s growth.
