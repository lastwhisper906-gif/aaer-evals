# OMCL MD&A — 0000926326-23-000003


## mdna

[0000926326-23-000003:mdna:1]
ITEM 7.    MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0000926326-23-000003:mdna:2]
The following discussion and analysis should be read in conjunction with our Consolidated Financial Statements and related Notes in this Annual Report on Form 10-K. This discussion and analysis may contain forward-looking statements based upon our current expectations and assumptions that involve risks and uncertainties. Our actual results and the timing of selected events could differ materially from those anticipated in these forward-looking statements as a result of several factors, including those set forth under Item 1A, “Risk Factors,” and elsewhere in this Annual Report on Form 10-K. Unless otherwise stated, references in this Annual Report to particular years or quarters refer to our fiscal year and the associated quarters of those fiscal years.

[0000926326-23-000003:mdna:3]
We have elected to omit discussion of the earliest of the three years covered by the Consolidated Financial Statements presented. Such omitted discussion can be found under Item 7, Management’s Discussion and Analysis of Financial Condition and Results of Operations, located in our Annual Report on Form 10-K for the fiscal year ended December 31, 2021, filed with the SEC on February 25, 2022, for reference to discussion of the fiscal year ended December 31, 2020, the earliest of the three fiscal years presented.

[0000926326-23-000003:mdna:4]
OVERVIEW

[0000926326-23-000003:mdna:5]
Our Business

[0000926326-23-000003:mdna:6]
Omnicell, a leader in transforming the pharmacy care delivery model, is committed to solving the critical challenges inherent in medication management and elevating the role of clinicians within healthcare as an essential component of care delivery. Omnicell is focused on not only helping its customers optimize medication management in each setting of care, but also placing the patient at the center and helping its customers optimize medication management across all care settings from inpatient to outpatient. We are doing so with an industry-leading medication management intelligent infrastructure to equip and empower pharmacists and pharmacies with the ability to focus on clinical care rather than administrative tasks. This intelligent infrastructure provides the critical foundation for customers to realize the industry vision of the Autonomous Pharmacy, a vision defined by pharmacy leaders for improving operational efficiencies and ultimately targeting zero-error medication management.

[0000926326-23-000003:mdna:7]
Facilities worldwide use our automation and analytics solutions to increase operational efficiency, reduce medication errors, deliver actionable intelligence, and improve patient safety. Institutional and retail pharmacies across North America and the United Kingdom leverage our innovative medication adherence and population health solutions to improve patient engagement and adherence to prescriptions, helping to reduce costly hospital readmissions. We sell our product and consumable solutions together with related service offerings. Revenues generated in the United States represented 90% of our total revenues for the year ended December 31, 2022.

[0000926326-23-000003:mdna:8]
Over the past several years, our business has expanded from a single-point solution to a platform of products and services that will help to further advance the industry vision of the Autonomous Pharmacy. This expansion has resulted in larger deal sizes across multiple products, services, and implementations for customers and, we believe, more comprehensive, valuable, and enduring relationships. As our business evolves, we continue to evaluate the metrics and methods we use to measure the success of our business.

[0000926326-23-000003:mdna:9]
We utilize bookings as an indicator of the success of our business. We define bookings generally as: (i) the value of non-cancelable contracts for our connected devices, software products, and Advanced Services (although, for those Advanced Services contracts without a minimum commitment, bookings only include the amount of revenue that has been recognized once the services have been provided); and (ii) for our consumables, the value of orders placed through our Omnicell Storefront online platform or through written or telephonic orders. We typically exclude technical services and other less significant items ancillary to our products and services, such as freight revenue from bookings. As noted, the portfolio of products, solutions and services we offer has evolved. As a result, the ordering process for certain of our solutions has also evolved. For example, orders for certain of our solutions may not include a purchase order. Connected devices and software license bookings are recorded as revenue upon customer acceptance of the installation or receipt of goods. Revenues from Advanced Services bookings are recorded over the contractual term. Bookings decreased by 13%, from $1.217 billion in 2021 to $1.054 billion in 2022, primarily driven by reduced demand for connected devices, partially offset by strong demand for Advanced Services offerings and the impact of acquisitions.

[0000926326-23-000003:mdna:10]
We generally provide installation planning and consulting as part of most connected device product sales, which is typically included in the initial price of the solution. To help ensure the maximum availability of our systems, our customers typically purchase technical services contracts (maintenance and support) in increments of one to five years. In addition to connected device product sales, we provide a range of services to our customers. We also provide Advanced Services such as Central Pharmacy Dispensing Service (service portion), IV Compounding Service (service portion), EnlivenHealth, Specialty

[0000926326-23-000003:mdna:11]
Pharmacy Services, 340B solutions, Inventory Optimization Service, and other software solutions, which typically are provided over 2-7 years.

[0000926326-23-000003:mdna:12]
The following table summarizes each revenue category:

[0000926326-23-000003:mdna:13]
| Revenue Category |  | Revenue Type |  | Income Statement Classification |  | Included in Bookings |
| Connected devices, software licenses, and other |  | Nonrecurring |  | Product |  | Yes (1) |
| Consumables |  | Recurring |  | Product |  | Yes |
| Technical services |  | Recurring |  | Service |  | No |
| Advanced Services (2) (3) |  | Recurring |  | Service |  | Yes |

[0000926326-23-000003:mdna:14]
_________________________________________________

[0000926326-23-000003:mdna:15]
(1)    Certain other insignificant revenue streams ancillary to our products and services, such as freight revenue, are not included in bookings.

[0000926326-23-000003:mdna:16]
(2)    Includes Central Pharmacy Dispensing Service (service portion), IV Compounding Service (service portion), EnlivenHealth, Specialty Pharmacy Services, 340B solutions, Inventory Optimization Service, and other software solutions.

[0000926326-23-000003:mdna:17]
(3)    For those Advanced Services contracts without a minimum commitment, bookings only include the amount of revenue that has been recognized once the services have been provided.

[0000926326-23-000003:mdna:18]
Our full-time employee headcount was approximately 4,230 on December 31, 2022, an increase of approximately 430 employees since December 31, 2021. In November 2022, we announced a restructuring plan intended to reduce our global workforce across a majority of our functions affecting approximately 350 employees. The majority of employees impacted by this restructuring event were included in our headcount as of December 31, 2022 with termination dates in early 2023.

[0000926326-23-000003:mdna:19]
Operating Segments

[0000926326-23-000003:mdna:20]
We manage our operations as a single segment for the purposes of assessing performance and making operating decisions. Our Chief Operating Decision Maker (“CODM”) is our Chief Executive Officer. The CODM allocates resources and evaluates the performance of Omnicell at the consolidated level using information about our revenues, gross profit, income from operations, and other key financial data. All significant operating decisions are based upon an analysis of Omnicell as one operating segment, which is the same as our reporting segment.

[0000926326-23-000003:mdna:21]
Business Strategy

[0000926326-23-000003:mdna:22]
The U.S. spent a total of $577 billion on prescription drugs that accounted for 14% of National Health Expenditures in 2021, and prescription drugs impact the vast majority of patients in virtually all settings of care. We believe there are significant challenges facing the practice of pharmacy today including, but not limited to, labor shortages, medication errors, drug shortages, medication loss due to drug diversion, significant medication waste and expiration costs, a high level of manual processes, complexity around compliance requirements, high healthcare worker turnover rates affecting tenure and expertise, hospitalizations from adverse drug events in outpatient settings, high variability in outcomes, and limited inventory visibility. Each of these challenges can translate into a major economic impact for hospitals and health systems. We believe that these significant challenges to the practice of pharmacy drive demand for increased digitization, visibility, and insights that our solutions enable, and that our solutions therefore present large opportunities.

[0000926326-23-000003:mdna:23]
In an effort to address these challenges and deliver solutions to help drive positive medication management outcomes, we believe a combination of technology, expertise and intelligence is needed in each care setting and across the entire continuum of care. We are focused on delivering solutions to help drive these medication management outcomes with outstanding customer experience through a mature channel in four market categories:

[0000926326-23-000003:mdna:24]
•Point of Care.  As a market leader, we expect to continue expansion into this product market as customers increase use of our dispensing systems in more areas within their hospitals. Should labor shortages continue to challenge the delivery of healthcare services, we believe that deploying solutions and workflows that are intended to save nursing time is essential. We are more than halfway through the replacement, upgrade, and expansion cycle of older models of automated dispensing systems with our XT Series within our customer base, which we believe remains a significant market opportunity. We have been successful in market expansion through competitive conversions and we expect this success to continue. We also believe there is an opportunity for us to expand the offering and define a new standard for dispensing systems in perioperative settings. We believe our current solutions within the Point of Care market and new innovation and services will continue to help customers drive improved outcomes.

[0000926326-23-000003:mdna:25]
•Central Pharmacy and IV Compounding.  This market represents the beginning of the medication management process in acute care settings, and, we believe, it is a significant automation opportunity for high volumes of manual,

[0000926326-23-000003:mdna:26]
repetitive, and error-prone processes that are often common in pharmacies today. Manual medication dispensing processes are usually labor intensive, error-prone, and may lead to excess medication waste and expirations for our healthcare partners. Automating the central pharmacy dispensing process should enable customers to reallocate pharmacy labor, enhance dispensing accuracy and patient safety, and reduce medication waste and expirations. Likewise, the manual compounding of sterile IV preparations can be error-prone and create significant patient safety risks, and outsourcing sterile IV compounding could lead to increased medication costs. As a result, we believe IV automation provides a significant opportunity to enhance patient safety and reduce costs. Because adoption of our Central Pharmacy and IV automation solution is still nascent, we believe that the implementation of new solutions (as well as upgrading older technology) will be accelerated by combining technology, expertise, and intelligence into a comprehensive offering that is designed to deliver improved outcomes. We anticipate that these bundled solutions will become more critical as health systems continue to face labor shortages, increased financial pressure, and supply chain disruptions.

[0000926326-23-000003:mdna:27]
•Specialty Pharmacy and 340B Program.  We believe that health systems will invest in more revenue-generating activities that are intended to improve patient outcomes by utilizing specialty pharmacies and the 340B Drug Pricing Program, which allow hospitals and health systems to stretch federal resources and expand patient access to healthcare by requiring manufacturers participating in Medicaid to sell outpatient drugs at discounted prices to healthcare organizations. Specialty drugs are used for treatment of complex conditions and often require intensive patient management and specialized workflows for dispensing and care coordination. Specialty medications are projected to account for 60% of U.S. total spending on medications, with total spending projected to be approximately $420 billion in 2025. Specialty pharmacies serve as the connection between patients, prescribing physicians, and payers and work to streamline access and adherence to these specialty drugs. We believe a solution that addresses start-up and managed services for health systems that is designed to optimize their specialty pharmacy programs and the related pharmaceutical aspects of patient care will help ensure continuity of care and should contribute to the revenue and profitability of those organizations. We believe that a fully optimized specialty pharmacy operation represents one of the largest economic opportunities for hospitals and health systems.

[0000926326-23-000003:mdna:28]
•Retail, Institutional, and Payer.  We believe the Retail, Institutional, and Payer market represents a significant opportunity as healthcare evolves. A majority of all prescription drugs are distributed in the non-acute sector. The COVID-19 pandemic accelerated the shift of certain primary care from hospitals and physician offices to other, more convenient settings, such as retail pharmacies and the home (including through telehealth technologies). New technologies and updated state board regulations appear to be spurring innovation by retail pharmacies, which, combined with the move to value-based care, we believe will drive the adoption of solutions that are intended to help providers and payers engage patients in new ways that improve patient care, reduce the total cost of care, and lead to more profitable operations. Because of the complexity of relationships between payers and providers, as well as the large number of retail pharmacies, including a significant number of independent pharmacies, we believe a network of established relationships between payers, providers and pharmacies will also be important.

[0000926326-23-000003:mdna:29]
COVID-19 Update

[0000926326-23-000003:mdna:30]
We continue to monitor the COVID-19 pandemic and ongoing impacts on the Company. At the outset of the COVID-19 pandemic, many health systems faced financial and operational pressures which we believe led our customers to delay or defer purchasing decisions and/or implementation of our solutions. However, it currently appears that the COVID-19 pandemic is no longer directly impacting our customers’ buying patterns. We believe that the challenges our customers have faced during the COVID-19 pandemic, including the need for robust visibility throughout their pharmacy supply chains, have increased the strategic relevance of our products and services.

[0000926326-23-000003:mdna:31]
The COVID-19 pandemic continues to evolve and there remains uncertainty regarding the continuing impact of the pandemic, including the impact of new variants of the COVID-19 virus, on the U.S. and world economies, as well as on our business. We continue to monitor this dynamic situation and may adjust our outlook as appropriate. The ongoing impact of the COVID-19 pandemic, and the resulting increased economic and demand uncertainty, may adversely affect our business, operating results, cash flow, financial condition, and liquidity (including increased borrowing costs or other costs of capital). However, under current circumstances, we believe that our financial position and resources will allow us to manage the anticipated impact of the COVID-19 pandemic on our business for the foreseeable future.

[0000926326-23-000003:mdna:32]
Ransomware Incident

[0000926326-23-000003:mdna:33]
On May 4, 2022, we determined that certain of our information technology systems were affected by ransomware impacting certain internal systems. Upon detecting the security event, we took immediate steps designed to contain the incident and implement our business continuity plans to restore and support continued operations. We have contained the incident and restored substantially all of our critical information technology systems. As a result of the ransomware incident, (i) invoicing

[0000926326-23-000003:mdna:34]
was delayed, which impacted the timing of cash collections and free cash flow within the year, and (ii) we experienced customer implementation delays during the year as we recovered from the impacts of the ransomware incident. Substantially all delayed implementations due to the ransomware incident have been completed as of the end of the year. Furthermore, any delayed or impacted processes have returned to normal operations. We do not believe the security event will have a material adverse effect on our business, operating results, cash flow, or financial condition.

[0000926326-23-000003:mdna:35]
Acquisitions

[0000926326-23-000003:mdna:36]
On January 10, 2022, we completed the acquisition of Hub and Spoke Innovations Limited (“Hub and Spoke Innovations”), pursuant to the terms and conditions of the Share Purchase Agreement, dated January 10, 2022, by and among Omnicell Limited (a wholly-owned subsidiary of the Company), Hub and Spoke Innovations Limited, and certain beneficial stockholders specified therein for a base purchase price of £2.5 million (approximately $3.4 million based on the exchange rate in effect at the acquisition date), prior to customary adjustments for closing cash, net working capital, and assumed indebtedness. The Hub and Spoke Innovations acquisition is expected to complement Omnicell’s total solution technology portfolio for retail pharmacy in the United Kingdom to help pharmacies improve workflows, offer patients 24/7 access to their medications and provide enhanced patient care. The results of the operations of Hub and Spoke Innovations have been included in our consolidated results of operations beginning January 10, 2022.

[0000926326-23-000003:mdna:37]
On December 31, 2021, we completed the acquisition of MarkeTouch Media pursuant to the terms and conditions of the Unit Purchase Agreement, dated December 31, 2021, by and among ateb, Inc. (a wholly-owned subsidiary of the Company), MarkeTouch Media, LLC, MarkeTouch Holdings, Inc., Toucan Enterprises, Inc., and certain beneficial stockholders specified therein for a base purchase price of $82.0 million, prior to customary adjustments for closing cash, net working capital, and assumed indebtedness. The MarkeTouch Media acquisition adds mobile and web-based technology and patient engagement solutions, which is expected to expand the footprint of EnlivenHealth across the retail pharmacy sector, while enhancing potential growth opportunities in new market segments like specialty pharmacy and pharmacy benefits management. The results of the operations of MarkeTouch Media have been included in our consolidated results of operations beginning December 31, 2021.

[0000926326-23-000003:mdna:38]
On December 29, 2021, we completed the acquisition of ReCept Holdings, Inc., (“ReCept”), which was subsequently renamed Omnicell Specialty Pharmacy Services, Inc., pursuant to the terms and conditions of the Agreement and Plan of Merger, dated December 1, 2021, by and among Omnicell, Inc., ReCept Holdings, Inc., Redfish Acquisition Corp, and the representative of the securityholders for a base purchase price of $100.0 million, prior to customary adjustments for closing cash, net working capital, and assumed indebtedness. The addition of ReCept’s specialty pharmacy management services, now a part of the Company’s Specialty Pharmacy Services, for health systems, provider groups, and federally qualified health centers expands Omnicell’s Advanced Services portfolio in an effort to address the growing and complex specialty pharmacy market. The results of the operations of ReCept have been included in our consolidated results of operations beginning December 29, 2021.

[0000926326-23-000003:mdna:39]
On September 9, 2021, we completed the acquisition of FDS Amplicare pursuant to the terms and conditions of the Agreement and Plan of Merger, dated July 25, 2021, by and among RxInnovation Inc., Omnicell, Inc., Fleming Acquisition Corp., and the representative of the securityholders for a base purchase price of $177.0 million, prior to customary adjustments for closing cash, net working capital, and assumed indebtedness. The FDS Amplicare acquisition adds a comprehensive and complementary suite of SaaS financial management, analytics, and population health solutions to our EnlivenHealth offering. The results of the operations of FDS Amplicare have been included in our consolidated results of operations beginning September 9, 2021.

[0000926326-23-000003:mdna:40]
CRITICAL ACCOUNTING POLICIES AND ESTIMATES

[0000926326-23-000003:mdna:41]
Our discussion and analysis of our financial condition and results of operations are based on our Consolidated Financial Statements, which have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”). The preparation of these financial statements requires us to make certain estimates and assumptions that affect the reported amounts of assets and liabilities, disclosure of any contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting periods. We regularly review our estimates and assumptions, which are based on historical experience and various other factors that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of certain assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates and assumptions. We believe the following critical accounting policies are affected by significant judgments and estimates used in the preparation of our Consolidated Financial Statements:

[0000926326-23-000003:mdna:42]
Revenue Recognition

[0000926326-23-000003:mdna:43]
We earn revenues from sales of our products and related services, which are sold in the healthcare industry, our principal market.

[0000926326-23-000003:mdna:44]
Prior to recognizing revenue, we identify the contract, performance obligations, and transaction price, and allocate the transaction price to the performance obligations. All identified contracts meet the following required criteria:

[0000926326-23-000003:mdna:45]
Parties to the contract have approved the contract (in writing, orally, or in accordance with other customary business practices) and are committed to perform their respective obligations. A majority of our contracts are evidenced by a non-cancelable written agreement. Contracts for consumable products are generally evidenced by an order placed via phone or a purchase order.

[0000926326-23-000003:mdna:46]
Entity can identify each party’s rights regarding the goods or services to be transferred. Contract terms are documented within the written agreements. Where a written contract does not exist, such as for consumable products, the rights of each party are understood as following our standard business process and terms.

[0000926326-23-000003:mdna:47]
The entity can identify the payment terms for the goods or services to be transferred. Payment terms are documented within the agreement and are generally net 30 to 60 days from shipment of tangible product or services performed for customers in the United States. Where a written contract does not exist, our standard payment terms are net 30 day terms.

[0000926326-23-000003:mdna:48]
The contract has commercial substance (that is the risk, timing, or amount of the entity’s future cash flows is expected to change as a result of the contract). Our agreements are an exchange of cash for a combination of products and services which result in changes in the amount of our future cash flows.

[0000926326-23-000003:mdna:49]
It is probable the entity will collect the consideration to which it will be entitled in exchange for the goods or services that will be transferred to the customer. We perform a credit check for all significant customers or transactions and where collectability is not probable, payment in full or a substantial down payment prior to shipment is typically required to help ensure the full agreed upon contract price will be collected.

[0000926326-23-000003:mdna:50]
Distinct goods or services are identified as performance obligations. A series of distinct goods or services that are substantially the same and that have the same pattern of transfer to the customer are considered a single performance obligation. Where a good or service is determined not to be distinct, we combine the good or service with other promised goods or services until a bundle of goods or services that is distinct is identified. To identify our performance obligations, we consider all products or services promised in the contract regardless of whether they are explicitly stated or are implied by customary business practices. When performance obligations are included in separate contracts, we consider an entire customer arrangement to determine if separate contracts should be considered combined for the purposes of revenue recognition. Most of our sales, other than renewals of support and maintenance, contain multiple performance obligations, with a combination of hardware systems, software products, consumables, support and maintenance, and professional services.

[0000926326-23-000003:mdna:51]
The transaction price of a contract is determined based on the fixed consideration, net of an estimate for variable consideration such as various discounts or rebates provided to customers. As a result of our commercial selling practices, contract prices are generally fixed with minimal, if any, variable consideration.

[0000926326-23-000003:mdna:52]
The transaction price is allocated to separate performance obligations proportionally based on the standalone selling price of each performance obligation. Standalone selling price is best evidenced by the price we charge for the good or service when selling it separately in similar circumstances to similar customers. Other than for the renewal of annual support services contracts, our products and services are not generally sold separately. We use an amount discounted from the list price as a best estimated selling price.

[0000926326-23-000003:mdna:53]
We recognize revenue when the performance obligation has been satisfied by transferring a promised good or service to a customer. The good or service is transferred when or as the customer obtains control of the good or service. Determining when control transfers requires management to make judgments that affect the timing of revenues recognized. Generally, for products requiring a complex implementation, control passes when the product is installed and ready for use. For all other products, control generally passes when product has been shipped and title has passed. For maintenance contracts and certain other services, including Advanced Services provided on a subscription basis, control passes to the customer over time, generally ratably over the service term as we provide a stand-ready service for the customer’s equipment. Time and material services transfer control to the customer at the time the services are provided. The portion of the transaction price allocated to our unsatisfied performance obligations are recorded as deferred revenues.

[0000926326-23-000003:mdna:54]
Revenues, contract assets, and contract liabilities are recorded net of associated taxes.

[0000926326-23-000003:mdna:55]
From time to time, we enter into change orders which modify the product to be received by the customer pursuant to certain contracts. Changes to any contract are accounted for as a modification of the existing contract to the extent the goods and services to be delivered as part of the contract are generally consistent with the nature and type of those to be provided under the terms of the original contract. Examples of such change orders include the addition or removal of units of equipment or changes to the configuration of the equipment where the overall nature of the contract remains intact. Our change orders generally result in the change being accounted for as modifications of existing contracts given the nature of the impacted orders.

[0000926326-23-000003:mdna:56]
In the normal course of business, we typically do not accept product returns unless the item is defective as manufactured or the configuration of the product is incorrect. We establish provisions for estimated returns based on historical product returns. The allowance for sales returns is not material to our Consolidated Financial Statements for any periods presented.

[0000926326-23-000003:mdna:57]
Lessor Leases

[0000926326-23-000003:mdna:58]
We determine if an arrangement is a lease at inception. The transaction price is allocated to separate performance obligations, generally consisting of a combination of hardware systems, software products, support and maintenance, and professional services, proportionally based on the standalone selling price of each performance obligation. Standalone selling price is best evidenced by the price we charge for the good or service when selling it separately in similar circumstances to similar customers. Other than for the renewal of annual support services contracts, our products and services are not generally sold separately. We use an amount discounted from the list price as a best estimated selling price.

[0000926326-23-000003:mdna:59]
Sales-Type Leases

[0000926326-23-000003:mdna:60]
We enter into non-cancelable sales-type lease arrangements, most of which do not have an option to extend the lease term. At the end of the lease term, the customer must either return the equipment or negotiate a new agreement, resulting in a new purchase or lease transaction. Failure of the customer to either return the equipment or negotiate a new agreement results in the contract becoming a month-to-month rental. Certain sales-type leases automatically renew for successive one-year periods at the end of each lease term without written notice from the customer. Our sales-type lease agreements do not contain any material residual value guarantees.

[0000926326-23-000003:mdna:61]
For sales-type leases, we recognize revenues for our hardware and software products, net of lease execution costs, post-installation product maintenance, and technical support, at the net present value of the lease payment stream upon customer acceptance. We recognize service revenues associated with sales-type leases ratably over the term of the agreement in service revenues in the Consolidated Statements of Operations. We recognize interest income from sales-type leases using the effective interest method. Both hardware and software revenues, and interest income from sales-types leases are recorded in product revenues in the Consolidated Statements of Operations.

[0000926326-23-000003:mdna:62]
We optimize cash flows by selling a majority of our non-U.S. government sales-type leases, other than Advanced Services sales-type leases, to third-party leasing finance companies on a non-recourse basis. We have no obligation to the leasing company once the lease has been sold. Some of our sales-type leases, mostly those relating to U.S. government hospitals, and those associated with financed service contracts related to certain Advanced Services products, including Central Pharmacy Dispensing Service and IV Compounding Service, are retained in-house.

[0000926326-23-000003:mdna:63]
Allowance for Credit Losses

[0000926326-23-000003:mdna:64]
We are exposed to credit losses primarily through sales of our products and services, as well as our sales-type leasing arrangements. We perform credit evaluations of our customers’ financial condition in order to assess each customer’s ability to pay. These evaluations require significant judgment and are based on a variety of factors including, but not limited to, current economic trends, payment history, and a financial review of the customer. We continue to monitor customers’ creditworthiness on an ongoing basis.

[0000926326-23-000003:mdna:65]
We maintain an allowance for credit losses for accounts receivable, unbilled receivables, and net investment in sales-type leases based on expected credit losses resulting from the inability of our customers to make required payments. The allowance for credit losses is measured using a loss rate method, considering factors such as customers’ credit risk, historical loss experience, current conditions, and forecasts. The allowance for credit losses is measured on a collective (pool) basis by aggregating customer balances with similar risk characteristics. We also record a specific allowance based on an analysis of individual past due balances or customer-specific information, such as a decline in creditworthiness or bankruptcy. Actual collection losses may differ from management’s estimates, and such differences could be material to our financial position and results of operations.

[0000926326-23-000003:mdna:66]
Inventory

[0000926326-23-000003:mdna:67]
Inventories are stated at the lower of cost, computed using the first-in, first-out method, and net realizable value. Inbound shipping costs are included in cost of inventory. We regularly monitor inventory quantities on hand and record write-downs for excess and obsolete inventories based on our estimate of demand for our products, potential obsolescence of technology, product life cycles, and whether pricing trends or forecasts indicate that the carrying value of inventory exceeds its estimated selling price. These factors are impacted by market and economic conditions, technology changes, and new product introductions and require estimates that may include elements that are uncertain. Actual demand may differ from forecasted demand and may have a material effect on gross margins. If inventory is written down, a new cost basis is established that cannot be increased in future periods. Shipments from suppliers or contract manufacturers before we receive them are recorded as in-transit inventory when title and the significant risks and rewards of ownership have passed to us.

[0000926326-23-000003:mdna:68]
Software Development Costs for Internal Use

[0000926326-23-000003:mdna:69]
We capitalize costs related to computer software developed or obtained for internal use in accordance with Accounting Standards Codification (“ASC”) 350-40, Internal-Use Software. Software developed or obtained for internal use includes certain costs for the development of our subscription and cloud-based offerings sold to customers, as well as enterprise-level business and finance software customized to meet specific operational needs. Costs incurred in the application development phase are capitalized and amortized over their useful lives, which is generally five years. Costs recognized in the preliminary project phase and the post-implementation phase are expensed as incurred.

[0000926326-23-000003:mdna:70]
Software Development Costs for External Use

[0000926326-23-000003:mdna:71]
We capitalize certain software development costs in accordance with ASC 985-20, Costs of Software to Be Sold, Leased, or Marketed, under which those costs incurred subsequent to the establishment of technological feasibility may be capitalized and amortized over the estimated lives of the related products. We establish technological feasibility when we complete a detail program design or a working model. We amortize development costs over the estimated lives of the related products, which is generally five years. All development costs prior to the completion of a detail program design or a working model are recognized as research and development expense.

[0000926326-23-000003:mdna:72]
Lessee Leases

[0000926326-23-000003:mdna:73]
We determine if an arrangement is a lease at inception. Operating lease right-of-use assets and liabilities are recognized at the commencement date based on the present value of lease payments over the lease term. As most of our lease contracts do not provide an implicit rate, we use our incremental borrowing rate based on information available at the commencement date in determining the present value of the lease payments. Lease expense is recognized on a straight-line basis over the lease term. We do not recognize a right-of-use asset and a lease liability for leases with an initial term of twelve months or less. We elected the practical expedient to not separate lease components from nonlease components and applied that practical expedient to all material classes of leased assets.

[0000926326-23-000003:mdna:74]
Many of our operating leases include an option to extend the lease. The specific terms and conditions of the extension options vary from lease to lease, but are consistent with standard industry practices in each area that we operate. We review each of our lease options at a time required by the terms of the lease contract, and notify the lessor if we choose to exercise the lease renewal option. Until we are reasonably certain that we will extend the lease contract, the renewal option periods will not be recognized as right-of-use assets or lease liabilities.

[0000926326-23-000003:mdna:75]
Certain leases include provisions for early termination, which allow the contract parties to terminate their obligations under the lease contract. The terms and conditions of the termination options vary by contract. When we have made a decision to exercise an early termination option, the right-of-use assets and associated lease liabilities are remeasured in accordance with the present value of the remaining cash flows under the lease contract.

[0000926326-23-000003:mdna:76]
Certain building lease agreements include rental payments subject to change annually based on fluctuations in various indexes (i.e., Consumer Price Index (“CPI”), Retail Price Index, and other international indexes). Certain data center lease agreements include rental payments subject to change based on usage and CPI fluctuations. The changes based on usage and indexes are treated as variable lease costs and recognized in the period in which the obligation for those payments was incurred.

[0000926326-23-000003:mdna:77]
Business Combinations

[0000926326-23-000003:mdna:78]
We use the acquisition method of accounting under ASC 805, Business Combinations. Each acquired company’s operating results are included in our Consolidated Financial Statements starting on the acquisition date. The purchase price is equivalent to the fair value of consideration transferred. Tangible and identifiable intangible assets acquired and liabilities

[0000926326-23-000003:mdna:79]
assumed as of the acquisition date are recorded at the acquisition date fair value. Goodwill is recognized for the excess of purchase price over the net fair value of assets acquired and liabilities assumed.

[0000926326-23-000003:mdna:80]
Amounts allocated to assets and liabilities are based upon fair values. Such valuations require management to make significant estimates and assumptions, especially with respect to the identifiable intangible assets. Management makes estimates of fair value based upon assumptions believed to be reasonable and that of a market participant. These estimates are based on available historical information as well as future expectations, and the estimates are inherently uncertain. The separately identifiable intangible assets generally include customer relationships, acquired technology, backlog, trade names, and non-compete agreements.

[0000926326-23-000003:mdna:81]
Goodwill and Acquired Intangible Assets

[0000926326-23-000003:mdna:82]
Goodwill

[0000926326-23-000003:mdna:83]
We assess goodwill for impairment on an annual basis on the first day of the fourth quarter of each year at the reporting unit level. This assessment is also performed whenever there is a change in circumstances that indicates the carrying value of goodwill may be impaired. We have one reporting unit, which is the same as our operating segment. A qualitative assessment is initially made to determine whether it is necessary to perform quantitative testing. A qualitative assessment includes, among others, consideration of: (i) past, current, and projected future earnings and equity; (ii) recent trends and market conditions; and (iii) valuation metrics involving similar companies that are publicly-traded and acquisitions of similar companies, if available. If this qualitative assessment indicates that it is more likely than not that impairment exists, or if we decide to bypass this option, we proceed to the quantitative assessment. The quantitative assessment involves a comparison between the estimated fair value of our reporting unit with its carrying amount including goodwill. If the carrying value exceeds estimated fair value, we will record an impairment charge based on that difference. The impairment charge will be limited to the amount of goodwill.

[0000926326-23-000003:mdna:84]
To determine the reporting unit’s fair value under the quantitative approach, we use a combination of income and market approaches, such as estimated discounted future cash flows of the reporting unit, multiples of earnings or revenues, and analysis of recent sales or offerings of comparable entities. We also consider our market capitalization on the date of the analysis to ensure the reasonableness of our reporting unit’s fair value.

[0000926326-23-000003:mdna:85]
Intangible Assets

[0000926326-23-000003:mdna:86]
In connection with our acquisitions, we generally recognize assets for customer relationships, acquired technology, backlog, trade names, and non-compete agreements. Intangible assets are carried at cost less accumulated amortization. Such amortization is provided on a straight-line basis or on an accelerated basis based on a pattern of economic benefit that is expected to be obtained over the estimated useful lives of the respective assets. Amortization for acquired technology and backlog is recognized in cost of revenues, and amortization for customer relationships, trade names, non-compete agreements, and patents is recognized in selling, general, and administrative expenses.

[0000926326-23-000003:mdna:87]
We assess the impairment of identifiable intangible assets whenever events or changes in circumstances indicate that an asset’s carrying amount may not be recoverable. Recoverability of an asset is measured by the comparison of the carrying amount to the sum of the undiscounted estimated future cash flows the asset is expected to generate, offset by estimated future costs to dispose of the product to which the asset relates. If an asset is considered to be impaired, the amount of such impairment would be measured as the difference between the carrying amount of the asset and its fair value. Our cash flow assumptions are based on historical and forecasted future revenue, operating costs, and other relevant factors. Assumptions and estimates about the remaining useful lives of our intangible assets are subjective and are affected by changes to our business strategies. If management’s estimates of future operating results change, or if there are changes to other assumptions, the estimate of the fair value of our assets could change significantly. Such change could result in impairment charges in future periods, which could have a significant impact on our operating results and financial condition.

[0000926326-23-000003:mdna:88]
Valuation of Share-Based Compensation

[0000926326-23-000003:mdna:89]
We account for share-based compensation in accordance with ASC 718, Stock Compensation. We recognize compensation expense related to share-based compensation based on the grant date estimated fair value.

[0000926326-23-000003:mdna:90]
The fair value of stock options (“options”) on the grant date is estimated using the Black-Scholes option pricing model, which requires the following inputs: expected life, expected volatility, risk-free interest rate, expected dividend yield rate, exercise price, and closing price of our common stock on the date of grant. The expected volatility is based on a combination of historical and market-based implied volatility, and the expected life of the awards is based on our historical experience of employee stock option exercises, including forfeitures. Expense is recognized on a straight-line basis over the requisite service period.

[0000926326-23-000003:mdna:91]
The fair value of restricted stock units (“RSUs”) and restricted stock awards (“RSAs”) is based on the stock price on the grant date. The RSUs and RSAs are subject to a service vesting condition and are recognized on a straight-line basis over the requisite service period.

[0000926326-23-000003:mdna:92]
The fair value of performance-based stock unit awards (“PSUs”) with service and market conditions is estimated using a Monte Carlo simulation model applying a multiple awards approach. Expense is recognized when it is probable that the performance condition will be met using the accelerated attribution method over the requisite service period.

[0000926326-23-000003:mdna:93]
Forfeiture rates are estimated based on our historical experience with equity awards that were granted and forfeited prior to vesting. The valuation assumptions used in estimating the fair value of employee share-based awards may change in future periods.

[0000926326-23-000003:mdna:94]
Accounting for Income Taxes

[0000926326-23-000003:mdna:95]
We record an income tax provision for (benefit from) the anticipated tax consequences of the reported results of operations. In accordance with ASC 740, Income Taxes, the provision for (benefit from) income taxes is computed using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been included in the financial statements. Under this method, deferred tax assets and liabilities are determined on the basis of the differences between the financial statement and tax bases of assets and liabilities, and for operating losses and tax credit carryforwards. Deferred tax assets and liabilities are measured using the enacted tax rates in effect for the periods in which those tax assets and liabilities are expected to be realized or settled. In the event that these tax rates change, we will incur a benefit or detriment on our income tax expense in the period of enactment. If we were to determine that all or part of the net deferred tax assets are not realizable in the future, we will record a valuation allowance that would be charged to earnings in the period such determination is made.

[0000926326-23-000003:mdna:96]
In accordance with ASC 740, we recognize the tax benefit from an uncertain tax position if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement. The calculation of tax liabilities involves significant judgment in estimating the impact of uncertainties in the application of ASC 740 and complex tax laws. Resolution of these uncertainties in a manner inconsistent with management’s expectations could have a material impact on our financial condition and operating results.

[0000926326-23-000003:mdna:97]
Recently Issued Authoritative Guidance

[0000926326-23-000003:mdna:98]
Refer to “Recently Issued Authoritative Guidance” in Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to Consolidated Financial Statements in this Annual Report on Form 10-K for a description of recently issued accounting pronouncements, including the expected dates of adoption and estimated effects on our results of operations, financial position, and cash flows.

[0000926326-23-000003:mdna:99]
RESULTS OF OPERATIONS

[0000926326-23-000003:mdna:100]
Total Revenues

[0000926326-23-000003:mdna:101]
|  | Year Ended December 31, |  | Change in |  |  |  |  |
|  | 2022 |  | 2021 |  | $ |  | % |  |  |  |  |  |  |
|  | (Dollars in thousands) |
| Product revenues | $ | 903,222 |  |  | $ | 812,512 |  |  | $ | 90,710 |  |  | 11% |  |  |  |  |  |  |
| Percentage of total revenues | 70% |  | 72% |  |  |  |  |  |  |  |  |  |  |
| Services and other revenues | 392,725 |  |  | 319,506 |  |  | 73,219 |  |  | 23% |  |  |  |  |  |  |
| Percentage of total revenues | 30% |  | 28% |  |  |  |  |  |  |  |  |  |  |
| Total revenues | $ | 1,295,947 |  |  | $ | 1,132,018 |  |  | $ | 163,929 |  |  | 14% |  |  |  |  |  |  |

[0000926326-23-000003:mdna:102]
Product revenues represented 70% and 72% of total revenues for the years ended December 31, 2022 and 2021, respectively. Product revenues increased by $90.7 million, due to increased customer demand, primarily within our automated dispensing systems business, as well as increased revenues from our IV Compounding Service and Central Pharmacy Dispensing Service.

[0000926326-23-000003:mdna:103]
Services and other revenues represented 30% and 28% of total revenues for the years ended December 31, 2022 and 2021, respectively. Services and other revenues include revenues from technical services and Advanced Services offerings. Services and other revenues increased by $73.2 million, primarily due to growth in our Advanced Services, including

[0000926326-23-000003:mdna:104]
incremental Advanced Services revenues from our recent acquisitions of FDS Amplicare, ReCept, and MarkeTouch Media. The increase was partially offset by a decrease in revenues from 340B solutions primarily due to impacts from decreasing provider utilization of the 340B program as a result of recent drug manufacturer actions.

[0000926326-23-000003:mdna:105]
Our international sales represented 10% of total revenues for both of the years ended December 31, 2022 and 2021, and are expected to be affected by foreign currency exchange rate fluctuations. We are unable to predict the extent to which revenues in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-23-000003:mdna:106]
Our ability to continue to grow revenues is dependent on our ability to continue to obtain orders from customers, which may be dependent upon customers’ capital equipment budgets and/or capital equipment approval cycles, our ability to produce quality products and consumables to fulfill customer demand, the volume of installations we are able to complete, our ability to meet customer needs by providing a quality installation experience, our ability to develop new or enhance existing solutions, and our flexibility in workforce allocations among customers to complete installations on a timely basis. The timing of our product revenues for equipment is primarily dependent on when our customers’ schedules and/or staffing levels allow for installations.

[0000926326-23-000003:mdna:107]
Cost of Revenues and Gross Profit

[0000926326-23-000003:mdna:108]
Cost of revenues is primarily comprised of three general categories: (i) standard product costs which account for the majority of the product cost of revenues that are provided to customers, and are inclusive of purchased material, labor to build the product, and overhead costs associated with production; (ii) costs of providing services and installation costs, including costs of personnel and other expenses; and (iii) other costs, including variances in standard costs and overhead, scrap costs, rework, warranty, provisions for excess and obsolete inventory, and amortization of software development costs and intangibles.

[0000926326-23-000003:mdna:109]
|  | Year Ended December 31, |  | Change in |  |  |  |  |
|  | 2022 |  | 2021 |  | $ |  | % |  |  |  |  |  |  |
|  | (Dollars in thousands) |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product revenues | $ | 493,626 |  |  | $ | 422,855 |  |  | $ | 70,771 |  |  | 17% |  |  |  |  |  |  |
| As a percentage of related revenues | 55% |  | 52% |  |  |  |  |  |  |  |  |  |  |
| Cost of services and other revenues | 213,334 |  |  | 154,510 |  |  | 58,824 |  |  | 38% |  |  |  |  |  |  |
| As a percentage of related revenues | 54% |  | 48% |  |  |  |  |  |  |  |  |  |  |
| Total cost of revenues | $ | 706,960 |  |  | $ | 577,365 |  |  | $ | 129,595 |  |  | 22% |  |  |  |  |  |  |
| As a percentage of total revenues | 55% |  | 51% |  |  |  |  |  |  |  |  |  |  |
| Gross profit | $ | 588,987 |  |  | $ | 554,653 |  |  | $ | 34,334 |  |  | 6% |  |  |  |  |  |  |
| Gross margin | 45% |  | 49% |  |  |  |  |  |  |  |  |  |  |

[0000926326-23-000003:mdna:110]
Cost of revenues for the year ended December 31, 2022 compared to the year ended December 31, 2021 increased by $129.6 million, of which $70.8 million was attributed to the increase in cost of product revenues and $58.8 million was attributed to the increase in cost of services and other revenues.

[0000926326-23-000003:mdna:111]
The increase in cost of product revenues was primarily driven by the increase in product revenues of $90.7 million for the year ended December 31, 2022 compared to the year ended December 31, 2021. The increase was also driven by inventory-related costs due to inflationary impacts, higher employee-related and travel expenses due to increased headcount, as well as an increase in employee-related expenses for restructuring initiatives. This increase was partially offset by the benefits associated with economies of scale due to higher volumes during the year ended December 31, 2022 compared to the year ended December 31, 2021.

[0000926326-23-000003:mdna:112]
The increase in cost of services and other revenues was primarily driven by the increase in services and other revenues of $73.2 million, including incremental revenues from our recent acquisitions, for the year ended December 31, 2022 compared to the year ended December 31, 2021. The cost of service and other revenues grew at a faster pace than our service and other revenues primarily due to additional investments in our service business to support new service solutions, the impact of lower 340B solutions revenues, and the mix of service revenues recognized during the year ended December 31, 2022.

[0000926326-23-000003:mdna:113]
The overall decrease in gross margin primarily relates to additional investments in our business, including our service solutions, the impact of lower 340B solutions revenues, and the mix of service revenues recognized in the quarter, as well as inflationary impacts on inventory-related costs and higher employee-related and travel expenses. The decrease is partially offset

[0000926326-23-000003:mdna:114]
by higher revenues for the year ended December 31, 2022 due to increased customer demand as well as benefits associated with economies of scale due to higher volumes. Our gross profit for the year ended December 31, 2022 was $589.0 million, as compared to $554.7 million for the year ended December 31, 2021.

[0000926326-23-000003:mdna:115]
Operating Expenses and Interest and Other Income (Expense), Net

[0000926326-23-000003:mdna:116]
|  | Year Ended December 31, |  | Change in |  |  |  |  |  |  |
|  | 2022 |  | 2021 |  | $ |  | % |  |  |  |  |  |  |  |  |
|  | (Dollars in thousands) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 104,969 |  |  | $ | 75,716 |  |  | $ | 29,253 |  |  | 39% |  |  |  |  |  |  |  |  |
| As a percentage of total revenues | 8% |  | 7% |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | 486,341 |  |  | 389,430 |  |  | 96,911 |  |  | 25% |  |  |  |  |  |  |  |  |
| As a percentage of total revenues | 38% |  | 34% |  |  |  |  |  |  |  |  |  |  |  |  |
| Total operating expenses | $ | 591,310 |  |  | $ | 465,146 |  |  | $ | 126,164 |  |  | 27% |  |  |  |  |  |  |  |  |
| As a percentage of total revenues | 46% |  | 41% |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other income (expense), net | $ | (130) |  |  | $ | (23,500) |  |  | $ | 23,370 |  |  | (99)% |  |  |  |  |  |  |  |  |

[0000926326-23-000003:mdna:117]
Research and Development. Research and development expenses increased by $29.3 million for the year ended December 31, 2022 compared to the year ended December 31, 2021. The increase was primarily attributed to an increase in employee-related expenses of approximately $19.6 million due to increased headcount to support the continued development of our intelligent infrastructure and incremental headcount from recent acquisitions, as well as an increase of $3.5 million in employee-related expenses for restructuring initiatives.

[0000926326-23-000003:mdna:118]
Selling, General, and Administrative. Selling, general, and administrative expenses increased by $96.9 million for the year ended December 31, 2022 compared to the year ended December 31, 2021. The increase was primarily due to an increase of approximately $42.4 million in employee-related expenses primarily related to increased headcount, including the incremental headcount from recent acquisitions, as well as an increase of $9.6 million in employee-related expenses for restructuring initiatives. The increase was also driven by an increase in spending on travel and meetings of $7.6 million, an increase in intangible asset amortization expense of $7.0 million, an increase in shipping and handling costs of $6.4 million, an increase in consulting expenses of $3.5 million, an increase in spending on software of $4.1 million, an increase in trade show expenses of $4.0 million, and increases in other operating expenses. In addition, we incurred impairment and abandonment charges to operating lease right-of-use assets of $9.4 million and ransomware-related expenses, net of insurance recoveries, of $2.0 million during the year ended December 31, 2022. The increase was partially offset by a decrease of $10.6 million in acquisition related expenses.

[0000926326-23-000003:mdna:119]
Interest and Other Income (Expense), Net. Interest and other income (expense), net, changed by $23.4 million for the year ended December 31, 2022 compared to the year ended December 31, 2021, primarily driven by a $18.1 million decrease in other expenses and a $5.3 million increase in other income. The decrease in other expenses during the year ended December 31, 2022 compared to the year ended December 31, 2021 is primarily due to the adoption of Accounting Standards Update (“ASU”) 2020-06, effective January 1, 2022, which eliminated the imputed interest expense recognized on our convertible senior notes (refer to Note 1, Organization and Summary of Significant Accounting Policies of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K for additional information). The increase in other income during the year ended December 31, 2022 compared to the year ended December 31, 2021 is primarily attributable to benefits from certain arrangements outside of our normal course of business, as well as higher interest income received due to higher interest rates.

[0000926326-23-000003:mdna:120]
55

[0000926326-23-000003:mdna:121]
Benefit from Income Taxes

[0000926326-23-000003:mdna:122]
|  | Year Ended December 31, |  | Change in |  |  |  |  |
|  | 2022 |  | 2021 |  | $ |  | % |  |  |  |  |  |  |
|  | (Dollars in thousands) |
| Benefit from income taxes | $ | (8,101) |  |  | $ | (11,842) |  |  | $ | 3,741 |  |  | (32)% |  |  |  |  |  |  |
| Effective tax rate on earnings | 330% |  | (18)% |  |  |  |  |  |  |  |  |  |  |

[0000926326-23-000003:mdna:123]
We recorded an income tax benefit of $8.1 million on a loss before provision for income taxes of $2.5 million, which resulted in an effective tax rate of 330% for the year ended December 31, 2022 compared to an income tax benefit of $11.8 million on income before provision for income taxes of $66.0 million, which resulted in a negative effective tax rate of 18% for the year ended December 31, 2021. The 2022 annual effective tax rate differed from the statutory tax rate of 21%, primarily due to a favorable impact of the research and development credits, excess tax benefit from share-based compensation, and foreign-derived intangible income (“FDII”) deduction, partially offset by an unfavorable impact from non-deductible compensation charges and global intangible low-taxed income (“GILTI”) inclusion.

[0000926326-23-000003:mdna:124]
Effective January 1, 2022, the Tax Cuts and Jobs Act of 2017 eliminated the ability to deduct research and development expenditures and required those expenditures to be amortized. While this change has not materially impacted our effective tax rate, the provision has impacted our cash flows and increased the amount of cash taxes we pay.

[0000926326-23-000003:mdna:125]
Refer to Note 17, Income Taxes, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K for additional information.

[0000926326-23-000003:mdna:126]
LIQUIDITY AND CAPITAL RESOURCES

[0000926326-23-000003:mdna:127]
We had cash and cash equivalents of $330.4 million at December 31, 2022, compared to $349.1 million at December 31, 2021. All of our cash and cash equivalents are invested in bank accounts and money market funds held in sweep and asset management accounts with major financial institutions.

[0000926326-23-000003:mdna:128]
Our cash position and working capital at December 31, 2022 and 2021 were as follows:

[0000926326-23-000003:mdna:129]
|  | December 31, |
|  | 2022 |  | 2021 |
|  | (In thousands) |
| Cash and cash equivalents | $ | 330,362 |  |  | $ | 349,051 |  |
| Working capital (deficit) (1) | $ | 453,366 |  |  | $ | (95,456) |  |

[0000926326-23-000003:mdna:130]
_________________________________________________

[0000926326-23-000003:mdna:131]
(1)    The working capital deficit balance as of December 31, 2021 was primarily due to the classification of our convertible senior notes as a current rather than long-term liability. Refer to Note 11, Convertible Senior Notes, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K for additional information.

[0000926326-23-000003:mdna:132]
Our ratio of current assets to current liabilities was 2.1:1 and 0.9:1 at December 31, 2022 and 2021, respectively.

[0000926326-23-000003:mdna:133]
Sources of Cash

[0000926326-23-000003:mdna:134]
Revolving Credit Facility

[0000926326-23-000003:mdna:135]
On November 15, 2019, we entered into an Amended and Restated Credit Agreement (as subsequently amended, as discussed below, the “A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers and Wells Fargo Bank, National Association, as administrative agent. The A&R Credit Agreement superseded our 2016 senior secured credit facility and provides for (a) a five-year revolving credit facility of $500.0 million (the “Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million. In addition, the A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million.

[0000926326-23-000003:mdna:136]
On September 22, 2020, the parties entered into an amendment to the A&R Credit Agreement to, among other changes, permit the issuance of the convertible senior notes and the purchase of the convertible note hedge transactions described below, expand our flexibility to repurchase our common stock and make other restricted payments, and replace the total net leverage covenant with a new secured net leverage covenant that required us to maintain a consolidated secured net leverage ratio not to exceed 3.50:1 for the calendar quarters ending September 30, 2020, December 31, 2020, and March 31,

[0000926326-23-000003:mdna:137]
2021 and requires us to maintain a consolidated secured net leverage ratio not to exceed 3.00:1 for the calendar quarters ending thereafter.

[0000926326-23-000003:mdna:138]
As of December 31, 2022, there was no outstanding balance for the Revolving Credit Facility and we were in full compliance with all covenants. Refer to Note 10, Debt and Credit Agreement, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K for additional information. We expect to use future loans under the Revolving Credit Facility, if any, for working capital, potential acquisitions, and other general corporate purposes.

[0000926326-23-000003:mdna:139]
Uses of Cash

[0000926326-23-000003:mdna:140]
Our future uses of cash are expected to be primarily for working capital, capital expenditures, and other contractual obligations. We also expect a continued use of cash for potential acquisitions and acquisition-related activities, as well as repurchases of our common stock.

[0000926326-23-000003:mdna:141]
The 2016 Repurchase Program has a total of $2.7 million remaining for future repurchases as of December 31, 2022, which may result in additional use of cash. During the first quarter of 2022, the 2014 Repurchase Program was completed. During the year ended December 31, 2022, we repurchased approximately 389,300 shares of our common stock under the repurchase programs at an average price of $134.11 per share for an aggregate purchase price of approximately $52.2 million. There were no stock repurchases during the year ended December 31, 2021. Refer to Note 16, Stock Repurchase Programs, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K for additional information.

[0000926326-23-000003:mdna:142]
Based on our current business plan and backlog, we believe that our existing cash and cash equivalents, our anticipated cash flows from operations, cash generated from the exercise of employee stock options and purchases under our Employee Stock Purchase Plan (“ESPP”), along with the availability of funds under the Revolving Credit Facility will be sufficient to meet our cash needs for working capital, capital expenditures, potential acquisitions, and other contractual obligations for at least the next twelve months. For periods beyond the next twelve months, we also anticipate that our net operating cash flows plus existing balances of cash and cash equivalents will suffice to fund the continued growth of our business.

[0000926326-23-000003:mdna:143]
Cash Flows

[0000926326-23-000003:mdna:144]
The following table summarizes, for the periods indicated, selected items in our Consolidated Statements of Cash Flows:

[0000926326-23-000003:mdna:145]
|  | Year Ended December 31, |
|  | 2022 |  | 2021 |  |  |
|  | (In thousands) |
| Net cash provided by (used in): |  |  |  |  |  |
| Operating activities | $ | 77,781 |  |  | $ | 231,809 |  |  |  |
| Investing activities | (58,669) |  |  | (412,498) |  |  |  |
| Financing activities | (20,953) |  |  | 47,363 |  |  |  |
| Effect of exchange rate changes on cash and cash equivalents | (944) |  |  | (974) |  |  |  |
| Net decrease in cash, cash equivalents, and restricted cash | $ | (2,785) |  |  | $ | (134,300) |  |  |  |

[0000926326-23-000003:mdna:146]
Operating Activities

[0000926326-23-000003:mdna:147]
We expect cash from our operating activities to fluctuate in future periods as a result of a number of factors, including the timing of our billings and collections, our operating results, and the timing of other liability payments.

[0000926326-23-000003:mdna:148]
Net cash provided by operating activities was $77.8 million for the year ended December 31, 2022, primarily consisting of net income of $5.6 million adjusted for non-cash items of $145.6 million, offset by changes in assets and liabilities of $73.5 million. The non-cash items primarily consisted of depreciation and amortization expense of $86.9 million, share-based compensation expense of $68.2 million, amortization of operating lease right-of-use assets of $12.2 million, impairment and abandonment of operating lease right-of-use assets related to facilities of $9.4 million, amortization of debt issuance costs of $4.2 million, and a change in deferred income taxes of $37.3 million. Changes in assets and liabilities include cash outflows from (i) an increase in accounts receivable and unbilled receivables of $60.4 million primarily due to an increase in billings driven by overall business growth and the timing of shipments as well as collections, (ii) an increase in inventories of $30.1 million primarily to support forecasted sales, including advanced purchases of certain components, such as semiconductors, as well as higher costs of inventory and timing of shipments, (iii) an increase in investment in sales-type leases of $15.4 million primarily due to the increase in sales-type lease revenues associated with certain Advanced Services products, (iv) a decrease in operating lease liabilities of $13.8 million, (v) a decrease in accounts payables of $7.8 million primarily due to

[0000926326-23-000003:mdna:149]
an overall decrease in spending during the fourth quarter of 2022, including inventory spending, as well as timing of payments, and (vi) an increase in prepaid expenses of $4.7 million. These cash outflows were partially offset by (i) an increase in deferred revenues of $24.5 million primarily due to an increase in billings for certain service and subscription offerings, (ii) an increase in accrued liabilities of $16.7 million primarily due to an increase in taxes payable and an increase in general liabilities, (iii) a decrease in other current assets of $6.4 million, (iv) a decrease in other long-term assets of $5.0 million, (v) a decrease in prepaid commissions of $4.3 million, and (vi) an increase in accrued compensation of $2.4 million.

[0000926326-23-000003:mdna:150]
Net cash provided by operating activities was $231.8 million for the year ended December 31, 2021, primarily consisting of net income of $77.8 million adjusted for non-cash items of $157.3 million, offset by changes in assets and liabilities of $3.3 million. The non-cash items primarily consisted of depreciation and amortization expense of $73.0 million, share-based compensation expense of $53.2 million, amortization of discount on convertible senior notes of $18.6 million, amortization of operating lease right-of-use assets of $11.9 million, amortization of debt issuance costs of $3.4 million, and a change in deferred income taxes of $3.3 million. Changes in assets and liabilities include cash outflows from (i) an increase in accounts receivable and unbilled receivables of $41.0 million primarily due to an increase in billings driven by overall business growth and the timing of shipments as well as collections, (ii) an increase in inventories of $25.7 million to support forecasted sales, including advanced purchases of certain components, and higher costs of inventory, (iii) a decrease in other long-term liabilities of $14.9 million primarily due to a $6.2 million release of a certain net unrecognized tax benefit as a result of effective settlement with the tax authorities, as well as the release of deferral of certain payroll taxes related to the Coronavirus Aid, Relief and Economic Security Act, (iv) a decrease in operating lease liabilities of $12.5 million, (v) an increase in prepaid commissions of $6.9 million primarily due to timing of bookings and revenue recognition due to larger deal sizes across multiple products, services, and implementations for customers, (vi) an increase in prepaid expenses of $5.7 million, and (vii) an increase in other long-term assets of $3.3 million. These cash outflows were partially offset by (i) an increase in accrued liabilities of $34.9 million primarily due to an increase in rebates and lease buyout liabilities, (ii) an increase in accounts payables of $29.1 million primarily due to an overall increase in spending, including inventory spending, as well as timing of payments, (iii) an increase in deferred revenues of $24.2 million primarily due to an increase in billings driven by the timing of shipments in order to meet customers’ implementation schedules and recognition of revenues for products requiring installation, (iv) an increase in accrued compensation of $12.3 million primarily due to an increase in accrued commissions, as well as timing of payroll, (v) a decrease in investment in sales-type leases of $3.3 million, and (vi) a decrease in other current assets of $2.8 million.

[0000926326-23-000003:mdna:151]
Investing Activities

[0000926326-23-000003:mdna:152]
Net cash used in investing activities was $58.7 million for the year ended December 31, 2022, which consisted of capital expenditures of $47.5 million for property and equipment, $13.2 million for costs of software development for external use, and $3.4 million consideration paid for the acquisition of Hub and Spoke Innovations, net of cash acquired, partially offset by purchase price adjustments from business acquisitions of $5.5 million.

[0000926326-23-000003:mdna:153]
Net cash used in investing activities was $412.5 million for the year ended December 31, 2021, which consisted of $354.2 million consideration paid for our 2021 acquisitions, net of cash acquired, capital expenditures of $29.0 million for property and equipment, and $29.4 million for costs of software development for external use.

[0000926326-23-000003:mdna:154]
Financing Activities

[0000926326-23-000003:mdna:155]
Net cash used in financing activities was $21.0 million for the year ended December 31, 2022, primarily due to $52.2 million for repurchases of our stock and $13.5 million in employees’ taxes paid related to restricted stock unit vesting, partially offset by $40.2 million in proceeds from employee stock option exercises and ESPP purchases and a net increase in the customer funds balances of $4.6 million.

[0000926326-23-000003:mdna:156]
Net cash provided by financing activities was $47.4 million for the year ended December 31, 2021, primarily due to $67.3 million in proceeds from employee stock option exercises and ESPP purchases, partially offset by $16.3 million in employees’ taxes paid related to restricted stock unit vesting and a net decrease in the customer funds balances of $3.7 million.

[0000926326-23-000003:mdna:157]
Contractual Obligations

[0000926326-23-000003:mdna:158]
Contractual obligations as of December 31, 2022 were as follows:

[0000926326-23-000003:mdna:159]
|  | Payments Due By Period |
|  | Total |  | 2023 |  | 2024 - 2025 |  | 2026 - 2027 |  | 2028 and thereafter |
|  | (In thousands) |
| Operating leases (1) | $ | 57,842 |  |  | $ | 13,280 |  |  | $ | 21,486 |  |  | $ | 15,936 |  |  | $ | 7,140 |  |
| Purchase obligations (2) | 159,710 |  |  | 146,301 |  |  | 13,251 |  |  | 150 |  |  | 8 |  |
| Convertible senior notes (3) | 579,313 |  |  | 1,438 |  |  | 577,875 |  |  | — |  |  | — |  |
| Total (4) | $ | 796,865 |  |  | $ | 161,019 |  |  | $ | 612,612 |  |  | $ | 16,086 |  |  | $ | 7,148 |  |

[0000926326-23-000003:mdna:160]
_________________________________________________

[0000926326-23-000003:mdna:161]
(1)Commitments under operating leases relate primarily to leased office buildings, data centers, office equipment, and vehicles. Refer to Note 13, Lessee Leases, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K for additional information.

[0000926326-23-000003:mdna:162]
(2)We purchase components from a variety of suppliers and use contract manufacturers to provide manufacturing services for our products. During the normal course of business, we issue purchase orders with estimates of our requirements several months ahead of the delivery dates. These amounts are associated with agreements that are enforceable and legally binding. The amounts under such contracts are included in the table above because we believe that cancellation of these contracts is unlikely and we expect to make future cash payments according to the contract terms or in similar amounts for similar materials.

[0000926326-23-000003:mdna:163]
(3)We issued convertible senior notes in September 2020 that are due in September 2025. The obligations presented above include both principal and interest for these notes. Although these notes mature in 2025, they may be converted into cash and shares of our common stock prior to maturity if certain conditions are met. Any conversion prior to maturity can result in repayment of the principal amounts sooner than the scheduled repayment as indicated in the table above. Refer to Note 11, Convertible Senior Notes, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K for additional information.

[0000926326-23-000003:mdna:164]
(4)Refer to Note 14, Commitments and Contingencies, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K for additional information.
