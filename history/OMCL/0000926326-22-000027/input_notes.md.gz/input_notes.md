# OMCL notes — 0000926326-22-000027


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000926326-22-000027:notes:1]
[same as prior period, unchanged from 0000926326-22-000014:notes:1]

[0000926326-22-000027:notes:2]
[same as prior period, unchanged from 0000926326-22-000014:notes:2]

[0000926326-22-000027:notes:3]
[same as prior period, unchanged from 0000926326-22-000014:notes:3]

[0000926326-22-000027:notes:4]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of June 30, 2022 and December 31, 2021, the results of operations and comprehensive income for the three and six months ended June 30, 2022 and 2021, and cash flows for the six months ended June 30, 2022 and 2021. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s Annual Report on Form 10-K for the year ended December 31, 2021, filed with the SEC on February 25, 2022, except as discussed in the section entitled “Recently Adopted Authoritative Guidance” below. The Company’s results of operations and comprehensive income for the three and six months ended June 30, 2022, and cash flows for the six months ended June 30, 2022 are not necessarily indicative of results that may be expected for the year ending December 31, 2022, or for any future period.

[0000926326-22-000027:notes:5]
[same as prior period, unchanged from 0000926326-22-000014:notes:5]

[0000926326-22-000027:notes:6]
[same as prior period, unchanged from 0000926326-22-000014:notes:6]

[0000926326-22-000027:notes:7]
[same as prior period, unchanged from 0000926326-22-000014:notes:7]

[0000926326-22-000027:notes:8]
[same as prior period, unchanged from 0000926326-22-000014:notes:8]

[0000926326-22-000027:notes:9]
[same as prior period, unchanged from 0000926326-22-000014:notes:9]

[0000926326-22-000027:notes:10]
The Company’s critical accounting policies are those that affect its financial statements materially and involve difficult, subjective, or complex judgments by management. As of June 30, 2022, the Company is not aware of any events or circumstances that would require an update to its estimates, judgments, or revisions to the carrying value of its assets or liabilities.

[0000926326-22-000027:notes:11]
[same as prior period, unchanged from 0000926326-22-000014:notes:11]

[0000926326-22-000027:notes:12]
[same as prior period, unchanged from 0000926326-22-000014:notes:12]

[0000926326-22-000027:notes:13]
[same as prior period, unchanged from 0000926326-22-000014:notes:13]

[0000926326-22-000027:notes:14]
In August 2020, the Financial Accounting Standards Board (“FASB“) issued Accounting Standards Update (“ASU“) 2020-06, Debt-Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging-Contracts in Entity’s Own Equity (Subtopic 815-40). The update simplifies the accounting for convertible debt instruments by reducing the number of accounting models and the number of embedded conversion features that could be recognized separately from the primary contract. ASU 2020-06 also enhances transparency and improves disclosures for convertible instruments and earnings per share guidance. ASU 2020-06 also requires the application of the if-converted method for calculating diluted earnings per share and the treasury stock method is no longer permitted for convertible instruments. This update permits the use of either the modified retrospective or fully retrospective method of transition. The Company adopted ASU 2020-06 on January 1, 2022, using the modified retrospective method of transition. Upon adoption of ASU 2020-06, the previously separated equity component and associated debt issuance costs for the Company’s outstanding convertible senior notes were reclassified to the liability component, thereby eliminating the subsequent amortization of the debt discount as interest expense. In addition, the Company derecognized the deferred tax liability related to the equity component.

[0000926326-22-000027:notes:15]
In December 2021, the Company made an irrevocable election under the indenture to require the principal portion of the Company’s convertible senior notes to be settled in cash and any conversion consideration in excess of the principal portion in cash and/or shares of the Company’s common stock at the Company’s option upon conversion. Following the irrevocable election, only the amounts expected to be settled in excess of the principal portion are considered dilutive in calculating earnings per share under the if-converted method.

[0000926326-22-000027:notes:16]
[same as prior period, unchanged from 0000926326-22-000014:notes:16]

[0000926326-22-000027:notes:17]
|  | January 1, 2022 |
|  | Pre-ASU 2020-06 Balances |  | ASU 2020-06 Adoption Impact |  | Post-ASU 2020-06 Balances |
|  | (In thousands) |
| Long-term deferred tax assets | $ | 15,883 |  |  | $ | (452) |  |  | $ | 15,431 |  |
| Convertible senior notes, net | 488,152 |  |  | 75,353 |  |  | 563,505 |  |
| Long-term deferred tax liabilities | 51,705 |  |  | (19,572) |  |  | 32,133 |  |
| Additional paid-in capital | 1,024,580 |  |  | (72,742) |  |  | 951,838 |  |
| Retained earnings | 368,571 |  |  | 16,509 |  |  | 385,080 |  |

[0000926326-22-000027:notes:18]
[same as prior period, unchanged from 0000926326-22-000014:notes:18]

[0000926326-22-000027:notes:19]
[same as prior period, unchanged from 0000926326-22-000014:notes:19]

[0000926326-22-000027:notes:20]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. The update addresses diversity in practice by requiring that an acquirer recognize and measure contract assets and liabilities acquired in a business combination in accordance with Accounting Standards Codification (“ASC”) 606, Revenue from Contracts with Customers. The guidance will be applied prospectively to acquisitions occurring on or after the effective date. ASU 2021-08 will be effective for the Company beginning January 1, 2023, and early adoption is permitted. The Company is currently evaluating the impact ASU 2021-08 will have on its Condensed Consolidated Financial Statements.

[0000926326-22-000027:notes:21]
[same as prior period, unchanged from 0000926326-22-000014:notes:21]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000926326-22-000027:notes:22]
[same as prior period, unchanged from 0000926326-22-000014:notes:22]

[0000926326-22-000027:notes:23]
[same as prior period, unchanged from 0000926326-22-000014:notes:23]

[0000926326-22-000027:notes:24]
[same as prior period, unchanged from 0000926326-22-000014:notes:24]

[0000926326-22-000027:notes:25]
[same as prior period, unchanged from 0000926326-22-000014:notes:25]

[0000926326-22-000027:notes:26]
[same as prior period, unchanged from 0000926326-22-000014:notes:26]

[0000926326-22-000027:notes:27]
[same as prior period, unchanged from 0000926326-22-000014:notes:27]

[0000926326-22-000027:notes:28]
[same as prior period, unchanged from 0000926326-22-000014:notes:28]

[0000926326-22-000027:notes:29]
[same as prior period, unchanged from 0000926326-22-000014:notes:29]

[0000926326-22-000027:notes:30]
[same as prior period, unchanged from 0000926326-22-000014:notes:30]

[0000926326-22-000027:notes:31]
[same as prior period, unchanged from 0000926326-22-000014:notes:31]

[0000926326-22-000027:notes:32]
[same as prior period, unchanged from 0000926326-22-000014:notes:32]

[0000926326-22-000027:notes:33]
[same as prior period, unchanged from 0000926326-22-000014:notes:33]

[0000926326-22-000027:notes:34]
[same as prior period, unchanged from 0000926326-22-000014:notes:34]

[0000926326-22-000027:notes:35]
|  | FDS Amplicare (1) |  | ReCept (2) (3) |  | MarkeTouch Media (4) |
|  | (In thousands) |
| Purchase price transferred: |  |  |  |  |  |
| Base purchase price | $ | 177,000 |  |  | $ | 100,000 |  |  | $ | 82,000 |  |
| Add: Closing cash | 465 |  |  | 6,569 |  |  | 237 |  |
| Add: Net working capital adjustment | 1,654 |  |  | (7,357) |  |  | 147 |  |
| Less: Assumed indebtedness | (653) |  |  | (1,973) |  |  | (15) |  |
| Total purchase price transferred | $ | 178,466 |  |  | $ | 97,239 |  |  | $ | 82,369 |  |
|  | FDS Amplicare(Preliminary) (1) |  | ReCept(Preliminary) (2) (3) |  | MarkeTouch Media(Preliminary) (4) |
| Fair value of assets acquired and liabilities assumed: |  |  |  |  |  |
| Cash and cash equivalents | $ | 465 |  |  | $ | — |  |  | $ | 237 |  |
| Accounts receivable and unbilled receivables | 5,330 |  |  | 2,383 |  |  | 2,302 |  |
| Prepaid expenses | 506 |  |  | 192 |  |  | 96 |  |
| Other current assets | 45 |  |  | 12,223 |  |  | — |  |
| Total current assets | 6,346 |  |  | 14,798 |  |  | 2,635 |  |
| Property and equipment | 444 |  |  | 172 |  |  | 177 |  |
| Operating lease right-of-use assets | 2,252 |  |  | 773 |  |  | 602 |  |
| Goodwill | 117,675 |  |  | 78,098 |  |  | 42,273 |  |
| Intangible assets | 70,000 |  |  | 28,100 |  |  | 38,000 |  |
| Other long-term assets | 51 |  |  | 195 |  |  | 2,850 |  |
| Total assets | 196,768 |  |  | 122,136 |  |  | 86,537 |  |
| Accounts payable | 950 |  |  | 219 |  |  | 473 |  |
| Accrued compensation | 1,312 |  |  | 1,756 |  |  | — |  |
| Accrued liabilities | 1,396 |  |  | 18,499 |  |  | 292 |  |
| Deferred revenues | 1,916 |  |  | 222 |  |  | 347 |  |
| Long-term deferred tax liabilities | 11,678 |  |  | 3,587 |  |  | — |  |
| Long-term operating lease liabilities | 920 |  |  | 614 |  |  | 206 |  |
| Other long-term liabilities | 130 |  |  | — |  |  | 2,850 |  |
| Total liabilities | 18,302 |  |  | 24,897 |  |  | 4,168 |  |
| Total purchase price | $ | 178,466 |  |  | $ | 97,239 |  |  | $ | 82,369 |  |
| Total purchase price, net of cash acquired | $ | 178,001 |  |  | $ | 90,670 |  |  | $ | 82,132 |  |

[0000926326-22-000027:notes:36]
[same as prior period, unchanged from 0000926326-22-000014:notes:36]

[0000926326-22-000027:notes:37]
(1)    During the fourth quarter of 2021, the Company recorded measurement period adjustments of $1.5 million to goodwill, consisting of an increase in intangible assets, accounts receivable and unbilled receivables, and long-term deferred tax liabilities of $0.4 million, $1.1 million, and $0.1 million, respectively, and a net working capital adjustment of $0.1 million. During the second quarter of 2022, the Company recorded a measurement period adjustment of $0.3 million to goodwill, consisting of an increase in long-term deferred tax liabilities.

[0000926326-22-000027:notes:38]
[same as prior period, unchanged from 0000926326-22-000014:notes:38]

[0000926326-22-000027:notes:39]
(3)    During the second quarter of 2022, the Company recorded measurement period adjustments of $3.5 million to goodwill, consisting of a purchase price adjustment of $5.2 million, partially offset by a decrease to other current assets of $1.7 million.

[0000926326-22-000027:notes:40]
(4)    During the second quarter of 2022, the Company recorded a measurement period adjustment of $0.3 million to goodwill related to a purchase price adjustment.

[0000926326-22-000027:notes:41]
The $117.7 million of goodwill arising from the FDS Amplicare acquisition is primarily attributed to future sales of SaaS solutions and FDS Amplicare’s assembled workforce. The $78.1 million of goodwill arising from the ReCept acquisition is primarily attributed to future sales of its offerings and services and ReCept’s assembled workforce. None of the FDS Amplicare and ReCept goodwill is expected to be deductible for tax purposes as these acquisitions were treated as stock acquisitions for U.S. Federal tax purposes. The $42.3 million of goodwill arising from the MarkeTouch Media acquisition is primarily attributed to future sales of SaaS solutions and MarkeTouch Media’s assembled workforce. The full amount of the MarkeTouch Media goodwill is expected to be deductible for tax purposes as this acquisition was treated as an asset acquisition for U.S. Federal tax purposes.

[0000926326-22-000027:notes:42]
[same as prior period, unchanged from 0000926326-22-000014:notes:40]

[0000926326-22-000027:notes:43]
[same as prior period, unchanged from 0000926326-22-000014:notes:41]

[0000926326-22-000027:notes:44]
[same as prior period, unchanged from 0000926326-22-000014:notes:42]

[0000926326-22-000027:notes:45]
[same as prior period, unchanged from 0000926326-22-000014:notes:43]

[0000926326-22-000027:notes:46]
[same as prior period, unchanged from 0000926326-22-000014:notes:44]

[0000926326-22-000027:notes:47]
[same as prior period, unchanged from 0000926326-22-000014:notes:45]

[0000926326-22-000027:notes:48]
[same as prior period, unchanged from 0000926326-22-000014:notes:46]

[0000926326-22-000027:notes:49]
The following table presents certain unaudited pro forma consolidated financial information for the three and six months ended June 30, 2021 as if the FDS Amplicare, ReCept, and MarkeTouch Media acquisitions had been completed on January 1, 2020. The pro forma effects of the Hub and Spoke Innovations acquisition were not material to the Company’s consolidated results of operations. The unaudited pro forma financial information is presented for informational purposes only, and is not indicative of what would have occurred had the acquisitions taken place on those respective dates. The unaudited pro forma financial information combines the historical results of the acquisitions with the Company’s consolidated historical results and includes certain adjustments including, but not limited to, amortization and depreciation of intangible assets and property and equipment acquired; and certain acquisition-related costs incurred.

[0000926326-22-000027:notes:50]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2021 |  |  |  | 2021 |  |  |
|  | (In thousands) |
| Pro forma revenues | $ | 290,970 |  |  |  |  | $ | 559,891 |  |  |  |
| Pro forma net income | $ | 20,827 |  |  |  |  | $ | 33,893 |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000926326-22-000027:notes:51]
[same as prior period, unchanged from 0000926326-22-000014:notes:49]

[0000926326-22-000027:notes:52]
[same as prior period, unchanged from 0000926326-22-000014:notes:50]

[0000926326-22-000027:notes:53]
Connected devices, software licenses, and other. Software-enabled connected devices and software licenses that manage and regulate the storage and dispensing of pharmaceuticals, consumables blister cards, and packaging equipment and other supplies. This revenue category is often sold through long-term, sole-source agreements with multi-year co-development plans. Solutions in this category include, but are not limited to, XT Series automated dispensing systems, the XR2 Automated Central Pharmacy System, IVX Station and IV compounding automation solutions.

[0000926326-22-000027:notes:54]
[same as prior period, unchanged from 0000926326-22-000014:notes:52]

[0000926326-22-000027:notes:55]
[same as prior period, unchanged from 0000926326-22-000014:notes:53]

[0000926326-22-000027:notes:56]
SaaS, subscription software, and technology-enabled services. Emerging software and service solutions which are offered on a subscription basis with fees typically based either on transaction volume or a fee over a specified period of time. Solutions in this category include, but are not limited to, EnlivenHealth inclusive of FDS Amplicare and MarkeTouch Media, 340B solutions, ReCept management services, and services associated with Omnicell One™, Central Pharmacy Dispensing Services, including the XR2 Automated Central Pharmacy System, and Central Pharmacy Compounding Services, including IVX Station and IV compounding automation solutions.

[0000926326-22-000027:notes:57]
[same as prior period, unchanged from 0000926326-22-000014:notes:55]

[0000926326-22-000027:notes:58]
[same as prior period, unchanged from 0000926326-22-000014:notes:56]

[0000926326-22-000027:notes:59]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”) and Federal agencies that purchase under a Federal Supply Schedule Contract with the Department of Veterans Affairs (the “GSA Contract”). GPOs are often fully or partially owned by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company also pays the Industrial Funding Fee (“IFF”) to the Department of Veterans Affairs under the GSA Contract. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs and the IFF were $4.0 million and $4.2 million for the three months ended June 30, 2022 and 2021, respectively, and $8.5 million and $7.6 million for the six months ended June 30, 2022 and 2021, respectively.

[0000926326-22-000027:notes:60]
[same as prior period, unchanged from 0000926326-22-000014:notes:58]

[0000926326-22-000027:notes:61]
The following table summarizes the Company’s revenues disaggregated by revenue type for the three and six months ended June 30, 2022 and 2021:

[0000926326-22-000027:notes:62]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
|  | (In thousands) |
| Connected devices, software licenses, and other | $ | 215,632 |  |  | $ | 179,044 |  |  | $ | 423,710 |  |  | $ | 338,762 |  |
| Technical services | 53,303 |  |  | 51,932 |  |  | 102,472 |  |  | 102,792 |  |
| Consumables | 18,174 |  |  | 17,867 |  |  | 35,971 |  |  | 36,274 |  |
| SaaS, subscription software, and technology-enabled services | 44,277 |  |  | 23,896 |  |  | 88,061 |  |  | 46,754 |  |
| Total revenues | $ | 331,386 |  |  | $ | 272,739 |  |  | $ | 650,214 |  |  | $ | 524,582 |  |

[0000926326-22-000027:notes:63]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location, for the three and six months ended June 30, 2022 and 2021:

[0000926326-22-000027:notes:64]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
|  | (In thousands) |
| United States | $ | 294,937 |  |  | $ | 242,859 |  |  | $ | 582,514 |  |  | $ | 467,135 |  |
| Rest of world (1) | 36,449 |  |  | 29,880 |  |  | 67,700 |  |  | 57,447 |  |
| Total revenues | $ | 331,386 |  |  | $ | 272,739 |  |  | $ | 650,214 |  |  | $ | 524,582 |  |

[0000926326-22-000027:notes:65]
[same as prior period, unchanged from 0000926326-22-000014:notes:63]

[0000926326-22-000027:notes:66]
[same as prior period, unchanged from 0000926326-22-000014:notes:64]

[0000926326-22-000027:notes:67]
[same as prior period, unchanged from 0000926326-22-000014:notes:65]

[0000926326-22-000027:notes:68]
|  | June 30,2022 |  | December 31,2021 |
|  | (In thousands) |
| Short-term unbilled receivables, net (1) | $ | 19,567 |  |  | $ | 17,208 |  |
| Long-term unbilled receivables, net (2) | 16,185 |  |  | 18,084 |  |
| Total contract assets | $ | 35,752 |  |  | $ | 35,292 |  |
| Short-term deferred revenues, net | $ | 108,579 |  |  | $ | 112,196 |  |
| Long-term deferred revenues | 24,187 |  |  | 20,194 |  |
| Total contract liabilities | $ | 132,766 |  |  | $ | 132,390 |  |

[0000926326-22-000027:notes:69]
[same as prior period, unchanged from 0000926326-22-000014:notes:67]

[0000926326-22-000027:notes:70]
[same as prior period, unchanged from 0000926326-22-000014:notes:68]

[0000926326-22-000027:notes:71]
[same as prior period, unchanged from 0000926326-22-000014:notes:69]

[0000926326-22-000027:notes:72]
Short-term deferred revenues of $108.6 million and $112.2 million include deferred revenues from product sales and service contracts, net of deferred cost of sales of $13.6 million and $22.4 million, as of June 30, 2022 and December 31, 2021, respectively. The short-term deferred revenues from product sales relate to delivered and invoiced products, pending installation and acceptance, expected to occur within the next twelve months. During the three and six months ended June 30, 2022, the Company recognized revenues of $22.4 million and $89.0 million, respectively, that were included in the corresponding gross short-term deferred revenues balance of $134.6 million as of December 31, 2021.

[0000926326-22-000027:notes:73]
Long-term deferred revenues include deferred revenues from product and service contracts of $24.2 million and $20.2 million as of June 30, 2022 and December 31, 2021, respectively. Remaining performance obligations are primarily recognized ratably over the remaining term of the contract, generally not more than ten years.

[0000926326-22-000027:notes:74]
[same as prior period, unchanged from 0000926326-22-000014:notes:72]

[0000926326-22-000027:notes:75]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three and six months ended June 30, 2022 and 2021. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable balance as of June 30, 2022 and December 31, 2021.


## us-gaap:EarningsPerShareTextBlock

[0000926326-22-000027:notes:76]
Net Income Per Share
Basic net income (loss) per share is computed by dividing net income (loss) for the period by the weighted-average number of shares outstanding during the period. In periods of net loss, all potential common shares are anti-dilutive, so diluted net loss per share equals the basic net loss per share. In periods of net income, diluted net income per share is computed by dividing net income for the period by the basic weighted-average number of shares plus any dilutive potential common stock outstanding during the period, using the treasury stock method. Potential common stock includes the effect of outstanding dilutive stock options, restricted stock awards, and restricted stock units, as well as shares the Company could be obligated to issue from its convertible senior notes and warrants, as described in Note 10, Convertible Senior Notes (pre-ASU 2020-06 adoption). For periods prior to the adoption of ASU 2020-06 on January 1, 2022, the Company applied the treasury stock method to calculate the dilutive impact of the convertible senior notes. Upon adoption of ASU 2020-06, effective January 1, 2022, the Company is required to apply the if-converted method for calculating the dilutive impact of the convertible senior notes. Refer to Note 1, Organization and Summary of Significant Accounting Policies, for further information. Any anti-dilutive weighted-average dilutive shares related to stock award plans, convertible senior notes, and warrants are excluded from the computation of the diluted net income per share.

[0000926326-22-000027:notes:77]
The basic and diluted net income per share calculations for the three and six months ended June 30, 2022 and 2021 were as follows:

[0000926326-22-000027:notes:78]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
|  | (In thousands, except per share data) |
| Net income | $ | 9,069 |  |  | $ | 20,424 |  |  | $ | 17,282 |  |  | $ | 34,551 |  |
| Weighted-average shares outstanding – basic | 44,219 |  |  | 43,262 |  |  | 44,234 |  |  | 43,113 |  |
| Effect of dilutive securities from stock award plans | 1,142 |  |  | 2,066 |  |  | 1,421 |  |  | 2,040 |  |
| Effect of convertible senior notes | 899 |  |  | 1,778 |  |  | 1,466 |  |  | 1,612 |  |
| Weighted-average shares outstanding – diluted | 46,260 |  |  | 47,106 |  |  | 47,121 |  |  | 46,765 |  |
| Net income per share – basic | $ | 0.21 |  |  | $ | 0.47 |  |  | $ | 0.39 |  |  | $ | 0.80 |  |
| Net income per share – diluted | $ | 0.20 |  |  | $ | 0.43 |  |  | $ | 0.37 |  |  | $ | 0.74 |  |
| Anti-dilutive weighted-average shares related to stock award plans | 865 |  |  | 199 |  |  | 473 |  |  | 290 |  |
| Anti-dilutive weighted-average shares related to convertible senior notes and warrants | 5,908 |  |  | 5,908 |  |  | 5,908 |  |  | 5,908 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000926326-22-000027:notes:79]
Cash and Cash Equivalents and Fair Value of Financial Instruments
Cash and cash equivalents of $245.0 million and $349.1 million as of June 30, 2022 and December 31, 2021, respectively, consisted of bank accounts and highly-liquid U.S. Government money market funds held in sweep and asset management accounts with major financial institutions. As of June 30, 2022 and December 31, 2021, cash equivalents were $207.3 million and $320.2 million, respectively, which consisted of money market funds held in sweep and asset management accounts.

[0000926326-22-000027:notes:80]
[same as prior period, unchanged from 0000926326-22-000014:notes:78]

[0000926326-22-000027:notes:81]
The Company measures its financial instruments at fair value. The Company’s cash, cash equivalents, and restricted cash are classified within Level 1 of the fair value hierarchy as they are valued primarily using quoted market prices utilizing market observable inputs. The Company’s credit facility is classified within Level 2 as the valuation inputs are based on quoted prices or market observable data of similar instruments. The Company’s convertible senior notes are classified within Level 2 as the valuation inputs are based on quoted prices in an inactive market on the last day in the reporting period. As of June 30, 2022, the fair value of the convertible senior notes was $731.7 million, compared to their carrying value of $565.0 million, which is net of unamortized debt issuance costs (subsequent to the adoption of ASU 2020-06). As of December 31, 2021, the fair value of the convertible senior notes was $1.085 billion, compared to their carrying value of $488.2 million, which is net of unamortized discount and debt issuance costs and excludes amounts classified within additional paid-in capital (prior to the adoption of ASU 2020-06). Refer to Note 9, Debt and Credit Agreement, for further information regarding the Company’s credit facility and Note 10, Convertible Senior Notes, for further information regarding the Company’s convertible senior notes. Refer to Note 1, Organization and Summary of Significant Accounting Policies, for further information regarding the adoption of ASU 2020-06.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000926326-22-000027:notes:82]
Balance Sheet Components
Balance sheet details as of June 30, 2022 and December 31, 2021 are presented in the tables below:

[0000926326-22-000027:notes:83]
|  | June 30,2022 |  | December 31,2021 |
|  | (In thousands) |
| Inventories: |  |  |  |
| Raw materials | $ | 65,452 |  |  | $ | 48,215 |  |
| Work in process | 11,264 |  |  | 11,009 |  |
| Finished goods | 73,745 |  |  | 60,700 |  |
| Total inventories | $ | 150,461 |  |  | $ | 119,924 |  |
| Other current assets: |  |  |  |
| Funds held for customers, including restricted cash (1) | $ | 31,140 |  |  | $ | 20,405 |  |
| Net investment in sales-type leases, current portion | 12,312 |  |  | 10,665 |  |
| Prepaid income taxes | 2,615 |  |  | 6,656 |  |
| Other current assets | 14,913 |  |  | 10,608 |  |
| Total other current assets | $ | 60,980 |  |  | $ | 48,334 |  |
| Other long-term assets: |  |  |  |
| Capitalized software, net | $ | 89,348 |  |  | $ | 96,995 |  |
| Unbilled receivables, net | 16,185 |  |  | 18,084 |  |
| Deferred debt issuance costs | 2,607 |  |  | 3,156 |  |
| Other long-term assets | 9,723 |  |  | 9,284 |  |
| Total other long-term assets | $ | 117,863 |  |  | $ | 127,519 |  |
| Accrued liabilities: |  |  |  |
| Operating lease liabilities, current portion | $ | 11,884 |  |  | $ | 12,947 |  |
| Customer fund liabilities | 31,140 |  |  | 31,727 |  |
| Advance payments from customers | 11,032 |  |  | 8,191 |  |
| Rebate liabilities | 39,359 |  |  | 44,644 |  |
| Group purchasing organization fees | 6,513 |  |  | 7,115 |  |
| Taxes payable | 5,248 |  |  | 3,771 |  |
| Other accrued liabilities | 31,347 |  |  | 24,772 |  |
| Total accrued liabilities | $ | 136,523 |  |  | $ | 133,167 |  |

[0000926326-22-000027:notes:84]
(1)    Includes restricted cash of $23.9 million and $6.6 million as of June 30, 2022 and December 31, 2021, respectively.

[0000926326-22-000027:notes:85]
The following table summarizes the changes in accumulated balances of other comprehensive income (loss), which consisted of foreign currency translation adjustments, for the three and six months ended June 30, 2022 and 2021:

[0000926326-22-000027:notes:86]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
|  | (In thousands) |
| Beginning balance | $ | (10,962) |  |  | $ | (6,143) |  |  | $ | (8,407) |  |  | $ | (5,522) |  |
| Other comprehensive income (loss) | (6,410) |  |  | 652 |  |  | (8,965) |  |  | 31 |  |
| Ending balance | $ | (17,372) |  |  | $ | (5,491) |  |  | $ | (17,372) |  |  | $ | (5,491) |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000926326-22-000027:notes:87]
Property and Equipment
The following table represents the property and equipment balances as of June 30, 2022 and December 31, 2021:

[0000926326-22-000027:notes:88]
|  | June 30,2022 |  | December 31,2021 |
|  | (In thousands) |
| Equipment | $ | 91,457 |  |  | $ | 89,272 |  |
| Furniture and fixtures | 7,025 |  |  | 7,580 |  |
| Leasehold improvements | 21,973 |  |  | 20,623 |  |
| Software | 69,015 |  |  | 60,856 |  |
| Construction in progress | 22,272 |  |  | 14,757 |  |
| Property and equipment, gross | 211,742 |  |  | 193,088 |  |
| Accumulated depreciation and amortization | (129,908) |  |  | (121,947) |  |
| Total property and equipment, net | $ | 81,834 |  |  | $ | 71,141 |  |

[0000926326-22-000027:notes:89]
Depreciation and amortization expense of property and equipment was $5.6 million and $4.9 million for the three months ended June 30, 2022 and 2021, respectively, and $10.9 million and $9.7 million for the six months ended June 30, 2022 and 2021, respectively.

[0000926326-22-000027:notes:90]
The geographic location of the Company’s property and equipment, net, is based on the physical location in which it is located. The following table summarizes the geographic information for property and equipment, net, as of June 30, 2022 and December 31, 2021:

[0000926326-22-000027:notes:91]
|  | June 30,2022 |  | December 31,2021 |
|  | (In thousands) |
| United States | $ | 77,893 |  |  | $ | 66,788 |  |
| Rest of world (1) | 3,941 |  |  | 4,353 |  |
| Total property and equipment, net | $ | 81,834 |  |  | $ | 71,141 |  |

[0000926326-22-000027:notes:92]
[same as prior period, unchanged from 0000926326-22-000014:notes:90]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000926326-22-000027:notes:93]
[same as prior period, unchanged from 0000926326-22-000014:notes:91]

[0000926326-22-000027:notes:94]
[same as prior period, unchanged from 0000926326-22-000014:notes:92]

[0000926326-22-000027:notes:95]
|  | December 31,2021 |  | Additions (1) |  | Measurement Period Adjustments (1) |  | Foreign currency exchange rate fluctuations |  | June 30,2022 |
|  | (In thousands) |
| Goodwill | $ | 738,900 |  |  | 2,549 |  |  | (3,446) |  |  | (3,516) |  |  | $ | 734,487 |  |

[0000926326-22-000027:notes:96]
[same as prior period, unchanged from 0000926326-22-000014:notes:94]

[0000926326-22-000027:notes:97]
[same as prior period, unchanged from 0000926326-22-000014:notes:95]

[0000926326-22-000027:notes:98]
The carrying amounts and useful lives of intangible assets as of June 30, 2022 and December 31, 2021 were as follows:

[0000926326-22-000027:notes:99]
|  | June 30, 2022 |
|  | Gross carryingamount (1) |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 311,089 |  |  | $ | (88,832) |  |  | $ | (1,499) |  |  | $ | 220,758 |  |  | 4 - 30 |
| Acquired technology | 92,066 |  |  | (58,539) |  |  | — |  |  | 33,527 |  |  | 4 - 20 |
| Backlog | 1,800 |  |  | (450) |  |  | — |  |  | 1,350 |  |  | 2 |
| Trade names | 9,200 |  |  | (6,110) |  |  | — |  |  | 3,090 |  |  | 5 - 12 |
| Patents | 2,430 |  |  | (1,246) |  |  | — |  |  | 1,184 |  |  | 2 - 20 |
| Non-compete agreements | 600 |  |  | (350) |  |  | — |  |  | 250 |  |  | 3 |
| Total intangibles assets, net | $ | 417,185 |  |  | $ | (155,527) |  |  | $ | (1,499) |  |  | $ | 260,159 |  |  |  |

[0000926326-22-000027:notes:100]
[same as prior period, unchanged from 0000926326-22-000014:notes:98]

[0000926326-22-000027:notes:101]
[same as prior period, unchanged from 0000926326-22-000014:notes:99]

[0000926326-22-000027:notes:102]
Amortization expense of intangible assets was $8.9 million and $6.1 million for the three months ended June 30, 2022 and 2021, respectively, and $18.0 million and $12.4 million for the six months ended June 30, 2022 and 2021, respectively.

[0000926326-22-000027:notes:103]
[same as prior period, unchanged from 0000926326-22-000014:notes:101]

[0000926326-22-000027:notes:104]
|  | June 30,2022 |
|  | (In thousands) |
| Remaining six months of 2022 | $ | 17,275 |  |
| 2023 | 31,527 |  |
| 2024 | 23,075 |  |
| 2025 | 21,027 |  |
| 2026 | 18,063 |  |
| Thereafter | 149,192 |  |
| Total | $ | 260,159 |  |


## us-gaap:DebtDisclosureTextBlock

[0000926326-22-000027:notes:105]
Debt and Credit Agreement
2019 Revolving Credit Facility

[0000926326-22-000027:notes:106]
On November 15, 2019, the Company entered into an Amended and Restated Credit Agreement (as subsequently amended as discussed below, the “A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers, and Wells Fargo Bank, National Association, as administrative agent. The A&R Credit Agreement superseded the Company’s 2016 secured credit facility and provides for (a) a five-year revolving credit facility of $500.0 million (the “Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million (the “Incremental Facility”). In addition, the A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The A&R Credit Agreement has an expiration date of November 15, 2024, upon which date all remaining outstanding borrowings will be due and payable.

[0000926326-22-000027:notes:107]
Loans under the Revolving Credit Facility bear interest, at the Company’s option, at a rate equal to either (a) the LIBOR Rate, plus an applicable margin ranging from 1.25% to 2.00% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the A&R Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) LIBOR for an interest period of one month plus 1.00%, plus an applicable margin ranging from 0.25% to 1.00% per annum based on the Company’s Consolidated Total Net Leverage Ratio. Undrawn commitments under the Revolving Credit Facility are subject to a commitment fee ranging from 0.15% to 0.30% per annum based on the Company’s Consolidated Total Net Leverage Ratio on the average daily unused portion of the Revolving Credit Facility. The applicable margin for, and certain other terms of, any term loans under the Incremental Facility will be determined prior to the incurrence of such loans. The Company is permitted to make voluntary prepayments at any time without payment of a premium or penalty.

[0000926326-22-000027:notes:108]
On September 22, 2020, the parties entered into an amendment to the A&R Credit Agreement to, among other changes, permit the issuance of the convertible senior notes and the purchase of the convertible note hedge transactions, as described in Note 10, Convertible Senior Notes, expand the Company’s flexibility to repurchase its common stock and make other restricted payments, and replace the total net leverage covenant with a new secured net leverage covenant that requires the Company to maintain a consolidated secured net leverage ratio not to exceed 3.50:1 for the calendar quarters ending September 30, 2020, December 31, 2020, and March 31, 2021 and 3.00:1 for the calendar quarters ending thereafter.

[0000926326-22-000027:notes:109]
The A&R Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends, and other distributions. The A&R Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum total secured net leverage ratio (as described above) and maintain a minimum interest coverage ratio. In addition, the A&R Credit Agreement contains certain customary events of default including, but not limited to, failure to pay interest, principal, and fees, or other amounts when due, material misrepresentations or misstatements in any representation or warranty, covenant defaults, certain cross defaults to other material indebtedness, certain judgment defaults, and events of bankruptcy. The Company’s obligations under the A&R Credit Agreement and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and such subsidiary guarantors’ assets. In connection with entering into the A&R Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a reaffirmation agreement, which amends certain terms of the existing collateral agreement and reaffirms their obligations under the existing guaranty agreement. The Company was in compliance with all covenants as of June 30, 2022.

[0000926326-22-000027:notes:110]
As of each of June 30, 2022 and December 31, 2021, there was no outstanding balance for the Revolving Credit Facility.
Convertible Senior Notes
0.25% Convertible Senior Notes due 2025

[0000926326-22-000027:notes:111]
On September 25, 2020, the Company completed a private offering of $575.0 million aggregate principal amount of 0.25% convertible senior notes (the “Notes”), including the exercise in full of the initial purchasers’ option to purchase up to an additional $75.0 million principal amount of the Notes. The Company received proceeds from the issuance of the Notes of $559.7 million, net of $15.3 million of transaction fees and other debt issuance costs. The Notes bear interest at a rate of 0.25% per year, payable semiannually in arrears on March 15 and September 15 of each year, beginning on March 15, 2021. The Notes were issued pursuant to an indenture, dated September 25, 2020 (the “Indenture”), between the Company and U.S. Bank

[0000926326-22-000027:notes:112]
National Association, as trustee. The Notes are general senior, unsecured obligations of the Company and will mature on September 15, 2025, unless earlier redeemed, repurchased, or converted.

[0000926326-22-000027:notes:113]
The Notes are convertible at the option of the holders at any time prior to the close of business on the business day immediately preceding May 15, 2025, only under the following circumstances: (i) during any fiscal quarter commencing after the fiscal quarter ended on December 31, 2020 (and only during such fiscal quarter), if the last reported sale price of the Company’s common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on, and including, the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the Notes on each applicable trading day; (ii) during the five business day period after any ten consecutive trading day period (the “measurement period”) in which the trading price (as defined in the Indenture) per $1,000 principal amount of the Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of the Company’s common stock and the conversion rate for the Notes on each such trading day; (iii) if the Company calls such Notes for redemption, at any time prior to the close of business on the scheduled trading day immediately preceding the redemption date, but only with respect to the Notes called (or deemed called) for redemption; and (iv) upon the occurrence of specified corporate events, as specified in the Indenture. On or after May 15, 2025 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders of the Notes may convert all or any portion of their Notes at any time, regardless of the foregoing conditions.

[0000926326-22-000027:notes:114]
During the three months ended December 31, 2021 and March 31, 2022, the conditional conversion feature of the Notes was triggered, based on the price of the Company’s common stock, as the last reported sale price of the Company’s common stock was greater than or equal to 130% of the then applicable conversion price for the Notes for at least 20 trading days during the period of 30 consecutive trading days ending on December 31, 2021 and March 31, 2022, the last trading day of the respective fiscal quarters. Accordingly, the Notes were convertible during the first two quarters of 2022 and were classified as a current liability in the Consolidated Financial Statements as of December 31, 2021 and March 31, 2022. During the three months ended June 30, 2022, none of the conditional conversion features of the Notes were triggered, and therefore, the Notes are not convertible during the third quarter of 2022, commencing on July 1, 2022. Accordingly, the Company classified the Notes as a long-term liability in its Condensed Consolidated Financial Statements as of June 30, 2022. Whether the Notes will be convertible following the third fiscal quarter of 2022 will depend on the satisfaction of the conversion conditions in the future.

[0000926326-22-000027:notes:115]
Under the original terms of the Indenture, upon conversion, the Company could satisfy its conversion obligation by paying or delivering cash, shares of its common stock, or a combination thereof, at the Company’s election, in the manner and subject to the terms and conditions provided in the Indenture. On December 13, 2021, the Company irrevocably elected to fix its settlement method to a combination of cash and shares of the Company’s common stock with the specified cash amount per $1,000 principal amount of Notes of at least $1,000. As a result, for Notes converted on or after December 13, 2021, a converting noteholder will receive (i) up to $1,000 in cash per $1,000 principal amount of Notes and (ii) cash and/or shares of the Company’s common stock, at the Company’s option for any conversion consideration in excess of $1,000. In addition, the Company continues to have the ability to set the specified cash amount per $1,000 principal amount of Notes above $1,000. The initial conversion rate for the Notes is 10.2751 shares of the Company’s common stock per $1,000 principal amount of Notes, which is equivalent to an initial conversion price of approximately $97.32 per share of the Company’s common stock, subject to adjustment under certain circumstances in accordance with the terms of the Indenture. In addition, following certain corporate events that occur prior to the maturity date of the Notes or if the Company delivers a notice of redemption in respect of the Notes, the Company will, under certain circumstances, increase the conversion rate of the Notes for a holder who elects to convert its Notes (or any portion thereof) in connection with such a corporate event or convert its Notes called (or deemed called) for redemption during the related redemption period (as defined in the Indenture), as the case may be.

[0000926326-22-000027:notes:116]
If the Company undergoes a fundamental change, holders may require, subject to certain exceptions, the Company to repurchase for cash all or any portion of their Notes at a fundamental change repurchase price equal to 100% of the principal amount of the Notes to be repurchased, plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date. As of June 30, 2022, none of the criteria for a fundamental change or a conversion rate adjustment had been met.

[0000926326-22-000027:notes:117]
The Company may not redeem the Notes prior to September 20, 2023. The Company may redeem for cash all or any portion of the Notes, at its option, on or after September 20, 2023, if the last reported sale price of the Company’s common stock has been at least 130% of the conversion price for the Notes then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which the Company provides notice of redemption at a redemption price equal to 100% of the principal amount of the Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. If the Company redeems less than all of the outstanding Notes, at least $150.0 million aggregate principal amount of Notes must be outstanding and not subject to redemption as of the date of the relevant notice of redemption. No sinking fund is provided for in the Notes.

[0000926326-22-000027:notes:118]
Prior to the adoption of ASU 2020-06, convertible debt instruments that could be settled in cash were required to be separated into liability and equity components. The allocation to the liability component was based on the fair value of a similar instrument that did not contain an equity conversion option. Based on this debt-to-equity ratio, debt issuance costs were then allocated to the liability and equity components in a similar manner. Accordingly, at issuance, the Company allocated $461.8 million to the debt liability and $72.7 million to additional paid-in capital, net of applicable issuance costs and deferred taxes. The difference between the principal amount of the Notes and the liability component, inclusive of issuance costs, represented the debt discount, which the Company amortized to interest expense over the term of the Notes using an effective interest rate of 4.18%. The determination of the discount rate required certain estimates and assumptions.

[0000926326-22-000027:notes:119]
Upon adoption of ASU 2020-06, effective January 1, 2022, the Notes are no longer separated into liability and equity components, and are accounted for as a single liability measured at its amortized cost. Refer to Note 1, Organization and Summary of Significant Accounting Policies, for further information.

[0000926326-22-000027:notes:120]
As of June 30, 2022, the remaining life of the Notes and the related issuance cost accretion is approximately 3.2 years.

[0000926326-22-000027:notes:121]
The maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to other conversion rate adjustments, would be 5.9 million shares. As of June 30, 2022, the if-converted value of the Notes exceeded the principal amount by $97.1 million.

[0000926326-22-000027:notes:122]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of June 30, 2022 and December 31, 2021:

[0000926326-22-000027:notes:123]
|  | June 30,2022 (2) |  | December 31,2021 |
|  | (In thousands) |
| Liability: |  |  |  |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized discount | — |  |  | (77,136) |  |
| Unamortized debt issuance costs | (9,965) |  |  | (9,712) |  |
| Convertible senior notes, liability component (1) | $ | 565,035 |  |  | $ | 488,152 |  |
| Convertible senior notes, equity component | $ | — |  |  | $ | 72,732 |  |

[0000926326-22-000027:notes:124]
(1)    Classified as a long-term liability as of June 30, 2022, and a current liability as of December 31, 2021, in the Condensed Consolidated Balance Sheets.

[0000926326-22-000027:notes:125]
(2)    Refer to Note 1, Organization and Summary of Significant Accounting Policies, for further information regarding the impact of the adoption of ASU 2020-06, effective January 1, 2022.

[0000926326-22-000027:notes:126]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three and six months ended June 30, 2022 and 2021:

[0000926326-22-000027:notes:127]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2022 (1) |  | 2021 |  | 2022 (1) |  | 2021 |
|  | (In thousands) |
| Contractual coupon interest | $ | 359 |  |  | $ | 359 |  |  | $ | 719 |  |  | $ | 719 |  |
| Amortization of discount | $ | — |  |  | $ | 4,624 |  |  | $ | — |  |  | $ | 9,195 |  |
| Amortization of debt issuance costs | $ | 766 |  |  | $ | 583 |  |  | $ | 1,530 |  |  | $ | 1,158 |  |

[0000926326-22-000027:notes:128]
(1)    Refer to Note 1, Organization and Summary of Significant Accounting Policies, for further information regarding the impact of the adoption of ASU 2020-06, effective January 1, 2022.

[0000926326-22-000027:notes:129]
Convertible Note Hedge and Warrant Transactions

[0000926326-22-000027:notes:130]
In connection with the issuance of the Notes, the Company entered into convertible note hedge and warrant transactions with an affiliate of one of the initial purchasers of the Notes and certain other financial institutions (the “option counterparties”) with respect to the Company’s common stock.

[0000926326-22-000027:notes:131]
The convertible note hedge consists of an option for the Company to purchase up to approximately 5.9 million shares of the Company’s common stock, which is equal to the number of shares of the Company’s common stock underlying the Notes, at an initial strike price of approximately $97.32 per share. The convertible note hedge will expire upon the maturity of the Notes, if not earlier exercised or terminated. The cost of the convertible note hedge was approximately $100.6 million and was accounted for as an equity instrument, which was recorded in additional paid-in capital in the Condensed Consolidated Balance Sheets. The Company recorded a deferred tax asset of $25.8 million at issuance related to the convertible note hedge transaction. The convertible note hedge is expected generally to reduce the potential dilution to the Company’s common stock upon any conversion of Notes and/or offset any cash payments the Company is required to make in excess of the principal amount of converted Notes.

[0000926326-22-000027:notes:132]
Separately from the convertible note hedge, the Company entered into warrant transactions to sell to the option counterparties warrants to acquire, subject to customary anti-dilution adjustments, up to approximately 5.9 million shares of its common stock in the aggregate at an initial strike price of $141.56 per share. The warrants require net share or net cash settlement upon the Company’s election. The Company received aggregate proceeds of approximately $51.3 million for the issuance of the warrants, which was recorded in additional paid-in capital at issuance in the Condensed Consolidated Balance Sheets. The warrants could separately have a dilutive effect to the Company’s common stock to the extent that the market price per share of its common stock exceeds the strike price of the warrants.


## us-gaap:DebtPolicyTextBlock

[0000926326-22-000027:notes:133]
Prior to the adoption of ASU 2020-06, convertible debt instruments that could be settled in cash were required to be separated into liability and equity components. The allocation to the liability component was based on the fair value of a similar instrument that did not contain an equity conversion option. Based on this debt-to-equity ratio, debt issuance costs were then allocated to the liability and equity components in a similar manner.Upon adoption of ASU 2020-06, effective January 1, 2022, the Notes are no longer separated into liability and equity components, and are accounted for as a single liability measured at its amortized cost.


## us-gaap:OperatingLeasesOfLessorDisclosureTextBlock

[0000926326-22-000027:notes:134]
Lessor Leases
Sales-Type Leases

[0000926326-22-000027:notes:135]
On a recurring basis, the Company enters into multi-year, sales-type lease agreements, with the majority of such leases varying in length from one to five years. Some of the Company’s sales-type leases, mostly those relating to U.S. government hospitals which comprise approximately 46% of the lease receivable balance, and those associated with financed service contracts related to Advanced Services products, are retained in-house. The Company optimizes cash flows by selling many of its sales-type leases to third-party leasing finance companies on a non-recourse basis. The Company has no obligation to the leasing company once the lease has been sold.

[0000926326-22-000027:notes:136]
The following table presents the Company’s income recognized from sales-type leases for the three and six months ended June 30, 2022 and 2021:

[0000926326-22-000027:notes:137]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
|  | (In thousands) |
| Sales-type lease revenues | $ | 17,413 |  |  | $ | 4,648 |  |  | $ | 23,918 |  |  | $ | 10,611 |  |
| Cost of sales-type lease revenues | (8,528) |  |  | (1,613) |  |  | (11,606) |  |  | (3,979) |  |
| Selling profit on sales-type lease revenues | $ | 8,885 |  |  | $ | 3,035 |  |  | $ | 12,312 |  |  | $ | 6,632 |  |

[0000926326-22-000027:notes:138]
The receivables as a result of these types of transactions are collateralized by the underlying equipment leased and consist of the following components at June 30, 2022 and December 31, 2021:

[0000926326-22-000027:notes:139]
|  | June 30,2022 |  | December 31,2021 |
|  | (In thousands) |
| Net minimum lease payments to be received | $ | 46,482 |  |  | $ | 31,444 |  |
| Less: Unearned interest income portion | (4,961) |  |  | (2,388) |  |
| Net investment in sales-type leases | 41,521 |  |  | 29,056 |  |
| Less: Current portion (1) | (12,312) |  |  | (10,665) |  |
| Long-term investment in sales-type leases, net | $ | 29,209 |  |  | $ | 18,391 |  |

[0000926326-22-000027:notes:140]
(1)    The current portion of the net investment in sales-type leases is included in other current assets in the Condensed Consolidated Balance Sheets.

[0000926326-22-000027:notes:141]
The carrying amount of the Company’s sales-type lease receivables is a reasonable estimate of fair value.

[0000926326-22-000027:notes:142]
The maturity schedule of future minimum lease payments under sales-type leases retained in-house and the reconciliation to the net investment in sales-type leases reported on the Condensed Consolidated Balance Sheets was as follows:

[0000926326-22-000027:notes:143]
|  | June 30,2022 |
|  | (In thousands) |
| Remaining six months of 2022 | $ | 7,014 |  |
| 2023 | 11,852 |  |
| 2024 | 8,774 |  |
| 2025 | 6,882 |  |
| 2026 | 4,047 |  |
| Thereafter | 7,913 |  |
| Total future minimum sales-type lease payments | 46,482 |  |
| Present value adjustment | (4,961) |  |
| Total net investment in sales-type leases | $ | 41,521 |  |

[0000926326-22-000027:notes:144]
Operating Leases

[0000926326-22-000027:notes:145]
The Company entered into certain leasing agreements that were classified as operating leases prior to the adoption of ASC 842, Leases. These agreements in place prior to January 1, 2019 continue to be treated as operating leases; however, any leasing agreements entered into on or after January 1, 2019 under these programs are classified and accounted for as sales-type leases in accordance with ASC 842. The operating lease arrangements generally have initial terms of one to seven years.

[0000926326-22-000027:notes:146]
The following table represents the Company’s income recognized from operating leases for the three and six months ended June 30, 2022 and 2021:

[0000926326-22-000027:notes:147]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
|  | (In thousands) |
| Rental income | $ | 2,421 |  |  | $ | 3,193 |  |  | $ | 4,893 |  |  | $ | 5,804 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0000926326-22-000027:notes:148]
Lessee Leases 
The Company has operating leases for office buildings, data centers, office equipment, and vehicles. The Company’s leases have initial terms of one to 12 years. As of June 30, 2022, the Company did not have any additional material operating leases that were entered into, but not yet commenced.

[0000926326-22-000027:notes:149]
[same as prior period, unchanged from 0000926326-22-000014:notes:149]

[0000926326-22-000027:notes:150]
|  | June 30,2022 |
|  | (In thousands) |
| Remaining six months of 2022 | $ | 7,778 |  |
| 2023 | 13,182 |  |
| 2024 | 11,672 |  |
| 2025 | 8,774 |  |
| 2026 | 8,302 |  |
| Thereafter | 14,222 |  |
| Total operating lease payments | 63,930 |  |
| Present value adjustment | (8,675) |  |
| Total operating lease liabilities (1) | $ | 55,255 |  |

[0000926326-22-000027:notes:151]
(1)    Amount consists of a current and long-term portion of operating lease liabilities of $11.9 million and $43.4 million, respectively. The current portion of the operating lease liabilities is included in accrued liabilities in the Condensed Consolidated Balance Sheets.

[0000926326-22-000027:notes:152]
Operating lease costs were $4.7 million and $3.6 million for the three months ended June 30, 2022 and 2021, respectively, and $8.8 million and $7.3 million for the six months ended June 30, 2022 and 2021, respectively. Short-term lease costs and variable lease costs were immaterial for the three and six months ended June 30, 2022 and 2021. During the three and six months ended June 30, 2022, the Company recorded impairment and abandonment charges to operating lease right-of-use assets of $3.3 million and $5.1 million, respectively, in connection with restructuring activities for optimization of certain leased facilities. The impairment and abandonment charges were recorded to selling, general, and administrative expenses on the Company’s Condensed Consolidated Statements of Operations.

[0000926326-22-000027:notes:153]
The following table summarizes supplemental cash flow information related to the Company’s operating leases for the six months ended June 30, 2022 and 2021:

[0000926326-22-000027:notes:154]
|  | Six Months Ended June 30, |
|  | 2022 |  | 2021 |
|  | (In thousands) |
| Cash paid for amounts included in the measurement of lease liabilities | $ | 8,607 |  |  | $ | 7,863 |  |
| Right-of-use assets obtained in exchange for new lease liabilities | $ | 10,685 |  |  | $ | 906 |  |

[0000926326-22-000027:notes:155]
The following table summarizes the weighted-average remaining lease term and weighted-average discount rate related to the Company’s operating leases as of June 30, 2022 and December 31, 2021:

[0000926326-22-000027:notes:156]
|  | June 30,2022 |  | December 31,2021 |
| Weighted-average remaining lease term, years | 5.3 |  | 5.2 |
| Weighted-average discount rate, % | 5.6 | % |  | 5.5 | % |


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000926326-22-000027:notes:157]
Commitments and Contingencies
Purchase Obligations

[0000926326-22-000027:notes:158]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of June 30, 2022, the Company had non-cancelable purchase commitments of $226.5 million, of which $175.8 million are expected to be paid within the year ending December 31, 2022.

[0000926326-22-000027:notes:159]
Ransomware Incident

[0000926326-22-000027:notes:160]
On May 4, 2022, the Company determined that certain of its information technology systems were affected by ransomware impacting certain internal systems. Upon detecting the security event, the Company took immediate steps designed to contain the incident and implement its business continuity plans to restore and support continued operations. The Company has contained the incident and restored substantially all of its critical information technology systems.

[0000926326-22-000027:notes:161]
During the three months ended June 30, 2022, the Company incurred $12.5 million of expenses related to the ransomware incident, partially offset by $11.1 million of expected insurance recoveries. Expenses include costs to investigate and remediate the ransomware incident, as well as legal and other professional services, all of which were expensed as incurred. For the three months ended June 30, 2022, the Company included net expenses of $0.2 million in cost of revenues and $1.2 million in selling, general, and administrative expenses in the Company’s Condensed Consolidated Statements of Operations.

[0000926326-22-000027:notes:162]
Legal Proceedings

[0000926326-22-000027:notes:163]
The Company is currently involved in various legal proceedings.

[0000926326-22-000027:notes:164]
A class action lawsuit was filed against the Company, on June 5, 2019, in the Circuit Court of Cook County, Illinois, Chancery Division, captioned Corey Heard, individually and on behalf of all others similarly situated v. Omnicell, Inc., Case No. 2019-CH-06817 (the “Heard Action”). The complaint seeks class certification, monetary damages in the form of statutory damages for willful and/or reckless or, in the alternative, negligent violation of the Illinois Biometric Information Privacy Act (“BIPA”), and certain declaratory, injunctive, and other relief based on causes of action directed to allegations of violation of BIPA by the Company. The complaint was served on the Company on June 13, 2019. On July 31, 2019, the Company filed a motion to stay or consolidate the case with the action Yana Mazya, et al. v. Northwestern Lake Forest Hospital, et al., Case No. 2018-CH-07161, pending in the Circuit Court of Cook County, Illinois, Chancery Division (the “Mazya Action”). The Court subsequently, on October 10, 2019, denied the motion, without prejudice, as being moot in view of the dismissal of the claims against the Company in the Mazya Action. The Company filed a motion to dismiss the complaint in the Heard Action on

[0000926326-22-000027:notes:165]
October 31, 2019. The hearing on the Company’s motion to dismiss was held on September 2, 2020. The Court ruled from the bench and dismissed the complaint without prejudice giving plaintiff leave to file an amended complaint by September 30, 2020. Plaintiff filed an amended complaint on September 30, 2020 and the Company subsequently filed a motion to dismiss the amended complaint on October 28, 2020, which was fully briefed, but the Court had not heard oral argument on the motion. The parties entered into a settlement agreement on January 25, 2022. On February 1, 2022, the Court granted preliminary approval of the settlement. The Court has scheduled an interim status conference for September 2, 2022. Subject to final approval of the settlement, the Company intends to defend the lawsuit vigorously.

[0000926326-22-000027:notes:166]
On December 21, 2020, Becton, Dickinson and Company (“BD”) filed a complaint against the Company in the United States District Court for the Middle District of North Carolina, asserting claims of misappropriation under the Defend Trade Secrets Act, misappropriation under the North Carolina Trade Secrets Protection Act, unfair competition, and unfair/deceptive trade practices in violation of North Carolina law (the “BD Complaint”). This action (the “BD Action”) was commenced in relation to another action brought by BD, in the same Court (the “Related Matter”) against a former BD employee who is also a former Company employee (the “Former Employee”) alleging that the Former Employee had violated the Former Employee’s legal obligations to BD regarding BD’s confidential and trade secret information when the Former Employee allegedly downloaded certain documents from BD’s information technology system following the end of the Former Employee’s employment with BD. In connection with the Related Matter, BD, the Former Employee, and the Company entered into a protocol with the purpose of facilitating the return to BD of any BD documents that may have been resident, as a result of the Former Employee’s actions, on any devices belonging to the Former Employee or the Company. The BD Complaint seeks injunctive relief and monetary damages in the form of compensatory, punitive, and exemplary damages, attorneys’ fees and costs, and pre-judgment and post-judgment interest. On March 8, 2022, the parties entered into a confidential settlement agreement. On May 23, 2022, the parties filed a stipulation to dismiss the case with prejudice. On May 24, 2022, the case was dismissed with prejudice.

[0000926326-22-000027:notes:167]
As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any material accrual for contingent liabilities associated with the legal proceedings described above based on its belief that any potential material loss, while reasonably possible, is not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time or is not deemed material. The Company believes that it has valid defenses with respect to these legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of any of these legal proceedings or because of the diversion of management’s attention and the creation of significant expenses.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000926326-22-000027:notes:168]
Income Taxes 
The Company generally provides for income taxes in interim periods based on the estimated annual effective tax rate for the year, adjusting for discrete items in the quarter in which they arise. The annual effective tax rate before discrete items was 24.1% and 27.8% for the six months ended June 30, 2022 and 2021, respectively.

[0000926326-22-000027:notes:169]
The Company has executed various global operational centralization activities and legal entity rationalization in recent years. The Company did not recognize any gains or losses from such activities during the six months ended June 30, 2022, and recognized an immaterial gain from such activities during the six months ended June 30, 2021. The Company recognized a discrete tax benefit related to equity compensation in the amount of $5.1 million and $8.2 million for the six months ended June 30, 2022 and 2021, respectively.

[0000926326-22-000027:notes:170]
[same as prior period, unchanged from 0000926326-22-000014:notes:167]

[0000926326-22-000027:notes:171]
[same as prior period, unchanged from 0000926326-22-000014:notes:168]

[0000926326-22-000027:notes:172]
As of June 30, 2022 and December 31, 2021, the Company had gross unrecognized tax benefits of $9.6 million and $9.0 million, respectively. It is the Company’s policy to classify accrued interest and penalties as part of unrecognized tax benefits, but to record interest and penalties in interest and other income (expense), net in the Condensed Consolidated Statements of Operations. As of both June 30, 2022 and December 31, 2021, the amount of accrued interest and penalties was $0.6 million.

[0000926326-22-000027:notes:173]
The Company files income tax returns in the United States and various state and foreign jurisdictions. In the normal course of business, the Company is subject to examinations by taxing authorities, including major jurisdictions such as the United States, Germany, Italy, Netherlands, and the United Kingdom. With few exceptions, as of June 30, 2022, the Company was no longer subject to U.S., state, and foreign tax examinations for years before 2018, 2017, and 2017, respectively.

[0000926326-22-000027:notes:174]
[same as prior period, unchanged from 0000926326-22-000014:notes:171]


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000926326-22-000027:notes:175]
[same as prior period, unchanged from 0000926326-22-000014:notes:172]

[0000926326-22-000027:notes:176]
[same as prior period, unchanged from 0000926326-22-000014:notes:173]

[0000926326-22-000027:notes:177]
[same as prior period, unchanged from 0000926326-22-000014:notes:174]

[0000926326-22-000027:notes:178]
The following table sets forth the total share-based compensation expense recognized in the Company’s Condensed Consolidated Statements of Operations for the three and six months ended June 30, 2022 and 2021:

[0000926326-22-000027:notes:179]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
|  | (In thousands) |
| Cost of product and service revenues | $ | 2,160 |  |  | $ | 2,044 |  |  | $ | 4,404 |  |  | $ | 3,981 |  |
| Research and development | 2,594 |  |  | 1,731 |  |  | 4,858 |  |  | 3,431 |  |
| Selling, general, and administrative | 12,459 |  |  | 9,264 |  |  | 24,159 |  |  | 17,399 |  |
| Total share-based compensation expense | $ | 17,213 |  |  | $ | 13,039 |  |  | $ | 33,421 |  |  | $ | 24,811 |  |

[0000926326-22-000027:notes:180]
[same as prior period, unchanged from 0000926326-22-000014:notes:177]

[0000926326-22-000027:notes:181]
The following assumptions were used to value shares under the ESPP for the three and six months ended June 30, 2022 and 2021:

[0000926326-22-000027:notes:182]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Expected life, years | 0.5 - 2.0 |  | 0.5 - 2.0 |  | 0.5 - 2.0 |  | 0.5 - 2.0 |
| Expected volatility, % | 28.8% - 45.6% |  | 27.4% - 53.5% |  | 28.8% - 45.6% |  | 27.4% - 53.5% |
| Risk-free interest rate, % | 0.1% - 1.5% |  | 0.1% - 2.6% |  | 0.1% - 1.5% |  | 0.1% - 2.6% |
| Dividend yield, % | — | % |  | — | % |  | — | % |  | — | % |

[0000926326-22-000027:notes:183]
For the six months ended June 30, 2022 and 2021, employees purchased approximately 175,000 and 156,000 shares of common stock, respectively, under the ESPP at a weighted-average price of $66.81 and $59.75, respectively. As of June 30, 2022, the unrecognized compensation cost related to the shares to be purchased under the ESPP was approximately $2.5 million and is expected to be recognized over a weighted-average period of 1.2 years.

[0000926326-22-000027:notes:184]
[same as prior period, unchanged from 0000926326-22-000014:notes:181]

[0000926326-22-000027:notes:185]
The following assumptions were used to value stock options granted pursuant to the Company’s 2009 Equity Incentive Plan, as amended, (the “2009 Plan”) for the six months ended June 30, 2021. There were no stock options granted during the three and six months ended June 30, 2022, and the three months ended June 30, 2021.

[0000926326-22-000027:notes:186]
|  |  |  |  |  | Six Months Ended June 30, |
|  |  |  |  |  |  |  | 2021 |
| Expected life, years |  |  |  |  |  |  | 4.9 |
| Expected volatility, % |  |  |  |  |  |  | 30.1 | % |
| Risk-free interest rate, % |  |  |  |  |  |  | 0.6 | % |
| Estimated forfeiture rate, % |  |  |  |  |  |  | 7.9 | % |
| Dividend yield, % |  |  |  |  |  |  | — | % |

[0000926326-22-000027:notes:187]
The following table summarizes the stock option activity during the six months ended June 30, 2022:

[0000926326-22-000027:notes:188]
|  | Number ofShares |  | Weighted-AverageExercise Price |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2021 | 2,954 |  |  | $ | 67.35 |  |  | 6.9 |  | $ | 334,119 |  |
| Granted | — |  |  | — |  |  |  |  |  |
| Exercised | (184) |  |  | 51.25 |  |  |  |  |  |
| Expired | (4) |  |  | 73.01 |  |  |  |  |  |
| Forfeited | (69) |  |  | 85.82 |  |  |  |  |  |
| Outstanding at June 30, 2022 | 2,697 |  |  | $ | 67.96 |  |  | 6.5 |  | $ | 125,696 |  |
| Exercisable at June 30, 2022 | 1,813 |  |  | $ | 60.51 |  |  | 5.9 |  | $ | 97,069 |  |
| Vested and expected to vest at June 30, 2022 and thereafter | 2,625 |  |  | $ | 67.46 |  |  | 6.4 |  | $ | 123,496 |  |

[0000926326-22-000027:notes:189]
The weighted-average fair value per share of options granted during the six months ended June 30, 2021 was $33.89. The intrinsic value of options exercised during the three months ended June 30, 2022 and 2021 was $2.8 million and $16.8 million, respectively, and during the six months ended June 30, 2022 and 2021 was $15.5 million and $30.8 million, respectively.

[0000926326-22-000027:notes:190]
As of June 30, 2022, total unrecognized compensation cost related to unvested stock options was $24.2 million, which is expected to be recognized over a weighted-average vesting period of 1.8 years.

[0000926326-22-000027:notes:191]
[same as prior period, unchanged from 0000926326-22-000014:notes:188]

[0000926326-22-000027:notes:192]
The following table summarizes the RSU activity under the 2009 Plan during the six months ended June 30, 2022:

[0000926326-22-000027:notes:193]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2021 | 763 |  |  | $ | 119.93 |  |  | 1.6 |  | $ | 137,696 |  |
| Granted (Awarded) | 571 |  |  | 119.58 |  |  |  |  |  |
| Vested (Released) | (111) |  |  | 96.01 |  |  |  |  |  |
| Forfeited | (53) |  |  | 125.46 |  |  |  |  |  |
| Outstanding and unvested at June 30, 2022 | 1,170 |  |  | $ | 121.78 |  |  | 1.7 |  | $ | 133,143 |  |

[0000926326-22-000027:notes:194]
As of June 30, 2022, total unrecognized compensation cost related to RSUs was $113.6 million, which is expected to be recognized over the remaining weighted-average vesting period of 3.3 years.

[0000926326-22-000027:notes:195]
[same as prior period, unchanged from 0000926326-22-000014:notes:192]

[0000926326-22-000027:notes:196]
The following table summarizes the RSA activity under the 2009 Plan during the six months ended June 30, 2022:

[0000926326-22-000027:notes:197]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2021 | 11 |  |  | $ | 137.36 |  |
| Granted (Awarded) | 13 |  |  | 109.39 |  |
| Vested (Released) | (11) |  |  | 137.36 |  |
| Outstanding and unvested at June 30, 2022 | 13 |  |  | $ | 109.39 |  |

[0000926326-22-000027:notes:198]
As of June 30, 2022, total unrecognized compensation cost related to RSAs was $1.1 million, which is expected to be recognized over the remaining weighted-average vesting period of 0.9 years.

[0000926326-22-000027:notes:199]
[same as prior period, unchanged from 0000926326-22-000014:notes:196]

[0000926326-22-000027:notes:200]
The following table summarizes the PSU activity under the 2009 Plan during the six months ended June 30, 2022:

[0000926326-22-000027:notes:201]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value Per Unit |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2021 | 144 |  |  | $ | 118.71 |  |
| Granted | 78 |  |  | 155.27 |  |
| Additional granted based on performance achievement | 51 |  |  | 156.79 |  |
| Vested | (84) |  |  | 117.37 |  |
| Forfeited | (1) |  |  | 178.81 |  |
| Outstanding and unvested at June 30, 2022 | 188 |  |  | $ | 144.76 |  |

[0000926326-22-000027:notes:202]
As of June 30, 2022, total unrecognized compensation cost related to PSUs was approximately $11.4 million, which is expected to be recognized over the remaining weighted-average vesting period of 1.4 years.

[0000926326-22-000027:notes:203]
[same as prior period, unchanged from 0000926326-22-000014:notes:200]

[0000926326-22-000027:notes:204]
The Company had the following ordinary shares reserved for future issuance under its equity incentive plans as of June 30, 2022:

[0000926326-22-000027:notes:205]
|  | Number of Shares |
|  | (In thousands) |
| Share options outstanding | 2,697 |  |
| Non-vested restricted stock awards | 1,371 |  |
| Shares authorized for future issuance | 1,467 |  |
| ESPP shares available for future issuance | 744 |  |
| Total shares reserved for future issuance | 6,279 |  |

[0000926326-22-000027:notes:206]
[same as prior period, unchanged from 0000926326-22-000014:notes:203]

[0000926326-22-000027:notes:207]
On August 2, 2016, the Company’s Board of Directors (the “Board”) authorized a stock repurchase program providing for the repurchase of up to $50.0 million of the Company’s common stock (the “2016 Repurchase Program”). The 2016 Repurchase Program is in addition to the stock repurchase program approved by the Board on November 4, 2014 providing for the repurchase of up to $50.0 million of the Company’s common stock (the “2014 Repurchase Program”). During the first quarter of 2022, the 2014 Repurchase Program was completed, and as of June 30, 2022, the maximum dollar value of shares that may yet be purchased under the 2016 Repurchase Program was $2.7 million. The 2016 Repurchase Program does not obligate the Company to repurchase any specific number of shares, and the Company may terminate or suspend the 2016 Repurchase Program at any time.
During the six months ended June 30, 2022, the Company repurchased approximately 389,300 shares of its common stock under the repurchase programs at an average price of $134.11 per share for an aggregate purchase price of approximately $52.2 million. During the three months ended June 30, 2022 and three and six months ended June 30, 2021, the Company did not repurchase any of its outstanding common stock under the repurchase programs.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000926326-22-000027:notes:208]
[same as prior period, unchanged from 0000926326-22-000014:notes:205]

[0000926326-22-000027:notes:209]
During the first quarter of 2022, the Company initiated certain domestic and international restructuring initiatives, in order to enhance and streamline certain engineering functions for its domestic operations, and to realign its international sales organization to better serve its customers in various international markets. During the first quarter of 2022, the restructuring plans incurred $3.5 million of employee severance costs and related expenses. As of June 30, 2022, the unpaid balance related to these restructuring plans was $1.1 million.

[0000926326-22-000027:notes:210]
The following table summarizes the total restructuring expense recognized in the Company’s Condensed Consolidated Statements of Operations for the six months ended June 30, 2022 and 2021:

[0000926326-22-000027:notes:211]
|  |  |  | Six Months Ended June 30, |
|  |  |  |  |  | 2022 |  | 2021 |
|  |  |  |  |  | (In thousands) |
| Cost of product and service revenues |  |  |  |  | $ | 156 |  |  | $ | 389 |  |
| Research and development |  |  |  |  | 1,594 |  |  | 105 |  |
| Selling, general, and administrative |  |  |  |  | 1,777 |  |  | 1,526 |  |
| Total restructuring expense |  |  |  |  | $ | 3,527 |  |  | $ | 2,020 |  |
