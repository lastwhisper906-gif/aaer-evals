# OMCL MD&A — 0000926326-22-000027


## mdna

[0000926326-22-000027:mdna:1]
[same as prior period, unchanged from 0000926326-22-000014:mdna:1]

[0000926326-22-000027:mdna:2]
[same as prior period, unchanged from 0000926326-22-000014:mdna:2]

[0000926326-22-000027:mdna:3]
[same as prior period, unchanged from 0000926326-22-000014:mdna:3]

[0000926326-22-000027:mdna:4]
•our statements relating to the Company’s containment of the impacts of the recent ransomware incident and any further impact on the Company;

[0000926326-22-000027:mdna:5]
[same as prior period, unchanged from 0000926326-22-000014:mdna:4]

[0000926326-22-000027:mdna:6]
[same as prior period, unchanged from 0000926326-22-000014:mdna:5]

[0000926326-22-000027:mdna:7]
[same as prior period, unchanged from 0000926326-22-000014:mdna:6]

[0000926326-22-000027:mdna:8]
[same as prior period, unchanged from 0000926326-22-000014:mdna:7]

[0000926326-22-000027:mdna:9]
[same as prior period, unchanged from 0000926326-22-000014:mdna:8]

[0000926326-22-000027:mdna:10]
[same as prior period, unchanged from 0000926326-22-000014:mdna:9]

[0000926326-22-000027:mdna:11]
[same as prior period, unchanged from 0000926326-22-000014:mdna:10]

[0000926326-22-000027:mdna:12]
[same as prior period, unchanged from 0000926326-22-000014:mdna:11]

[0000926326-22-000027:mdna:13]
[same as prior period, unchanged from 0000926326-22-000014:mdna:12]

[0000926326-22-000027:mdna:14]
[same as prior period, unchanged from 0000926326-22-000014:mdna:13]

[0000926326-22-000027:mdna:15]
[same as prior period, unchanged from 0000926326-22-000014:mdna:14]

[0000926326-22-000027:mdna:16]
[same as prior period, unchanged from 0000926326-22-000014:mdna:15]

[0000926326-22-000027:mdna:17]
[same as prior period, unchanged from 0000926326-22-000014:mdna:16]

[0000926326-22-000027:mdna:18]
[same as prior period, unchanged from 0000926326-22-000014:mdna:17]

[0000926326-22-000027:mdna:19]
[same as prior period, unchanged from 0000926326-22-000014:mdna:18]

[0000926326-22-000027:mdna:20]
[same as prior period, unchanged from 0000926326-22-000014:mdna:19]

[0000926326-22-000027:mdna:21]
[same as prior period, unchanged from 0000926326-22-000014:mdna:20]

[0000926326-22-000027:mdna:22]
[same as prior period, unchanged from 0000926326-22-000014:mdna:21]

[0000926326-22-000027:mdna:23]
[same as prior period, unchanged from 0000926326-22-000014:mdna:22]

[0000926326-22-000027:mdna:24]
[same as prior period, unchanged from 0000926326-22-000014:mdna:23]

[0000926326-22-000027:mdna:25]
[same as prior period, unchanged from 0000926326-22-000014:mdna:24]

[0000926326-22-000027:mdna:26]
[same as prior period, unchanged from 0000926326-22-000014:mdna:25]

[0000926326-22-000027:mdna:27]
[same as prior period, unchanged from 0000926326-22-000014:mdna:26]

[0000926326-22-000027:mdna:28]
Facilities worldwide use our automation and analytics solutions to increase operational efficiency, reduce medication errors, deliver actionable intelligence, and improve patient safety. Institutional and retail pharmacies across North America, the United Kingdom, Germany, and Australia leverage our innovative medication adherence and population health solutions to improve patient engagement and adherence to prescriptions, helping to reduce costly hospital readmissions. We sell our product and consumable solutions together with related service offerings. Revenues generated in the United States represented 89% of our total revenues for both the three months ended June 30, 2022 and 2021, and 90% and 89% of our total revenues for the six months ended June 30, 2022 and 2021, respectively.

[0000926326-22-000027:mdna:29]
[same as prior period, unchanged from 0000926326-22-000014:mdna:29]

[0000926326-22-000027:mdna:30]
[same as prior period, unchanged from 0000926326-22-000014:mdna:30]

[0000926326-22-000027:mdna:31]
In addition to product solution sales, we provide a range of services to our customers. We provide installation planning and consulting as part of most product sales which is generally included in the initial price of the solution. We also provide Advanced Services such as Omnicell One, EnlivenHealth, 340B solutions, ReCept management services, Central Pharmacy Dispensing Services, and Central Pharmacy Compounding Services. To help assure the maximum availability of our systems, our customers typically purchase maintenance and support contracts in increments of one to five years. As a result of the growth of our installed base of customers and expanded service offerings, our service revenues have also grown.

[0000926326-22-000027:mdna:32]
[same as prior period, unchanged from 0000926326-22-000014:mdna:32]

[0000926326-22-000027:mdna:33]
[same as prior period, unchanged from 0000926326-22-000014:mdna:33]

[0000926326-22-000027:mdna:34]
[same as prior period, unchanged from 0000926326-22-000014:mdna:34]

[0000926326-22-000027:mdna:35]
[same as prior period, unchanged from 0000926326-22-000014:mdna:35]

[0000926326-22-000027:mdna:36]
[same as prior period, unchanged from 0000926326-22-000014:mdna:36]

[0000926326-22-000027:mdna:37]
Our full-time employee headcount was approximately 4,000 and 3,800 on June 30, 2022 and December 31, 2021, respectively.

[0000926326-22-000027:mdna:38]
[same as prior period, unchanged from 0000926326-22-000014:mdna:38]

[0000926326-22-000027:mdna:39]
[same as prior period, unchanged from 0000926326-22-000014:mdna:39]

[0000926326-22-000027:mdna:40]
[same as prior period, unchanged from 0000926326-22-000014:mdna:40]

[0000926326-22-000027:mdna:41]
We are committed to being the care providers’ and retail pharmacies’ most trusted partner and executing on the industry vision of the Autonomous Pharmacy by developing and delivering an intelligent medication management infrastructure composed of devices, digital workflows, analytics, and experts, all powered by the cloud. We believe there are significant challenges facing the pharmacy practice today including, but not limited to, labor shortages, medication errors, drug shortages, medication loss due to drug diversion, significant medication waste and expiration costs, a high level of manual steps in the medication management process, complexity around compliance requirements, high pharmacy employee turnover rates affecting tenure and expertise, hospitalizations from adverse drug events in outpatient settings, high variability in outcomes, and limited inventory visibility. We believe that these significant challenges to the pharmacy practice drive the demand for increased digitization, visibility, and insights that our solutions enable, and represent large opportunities in four market categories:

[0000926326-22-000027:mdna:42]
[same as prior period, unchanged from 0000926326-22-000014:mdna:43]

[0000926326-22-000027:mdna:43]
[same as prior period, unchanged from 0000926326-22-000014:mdna:44]

[0000926326-22-000027:mdna:44]
[same as prior period, unchanged from 0000926326-22-000014:mdna:45]

[0000926326-22-000027:mdna:45]
[same as prior period, unchanged from 0000926326-22-000014:mdna:46]

[0000926326-22-000027:mdna:46]
[same as prior period, unchanged from 0000926326-22-000014:mdna:47]

[0000926326-22-000027:mdna:47]
•Retail, Institutional, and Payer.  We believe the retail, institutional, and payer market represents a significant opportunity as healthcare evolves. A majority of all prescription drugs are distributed in the non-acute sector. The COVID-19 pandemic accelerated the shift of primary healthcare settings from hospitals and doctors’ offices to other convenient channels like the home, digital, and retail pharmacies. New technology and updated state board regulations are leading to innovation at traditional retail providers, which, combined with the move to value-based care, we believe will incentivize the market to adopt solutions to help providers and payers engage patients in new ways that improve patient care and reduce the total cost of care. We believe adoption of our EnlivenHealth portfolio of software products and services, along with medication adherence packaging, will increase adherence performance rates, increase prescription volume for our customers, and reduce hospital and emergency room visits due to improved adherence. Our EnlivenHealth portfolio has been expanded with two recent acquisitions that will assist in adoption and drive innovation. RxInnovation Inc., operating as FDS Amplicare (“FDS Amplicare”), is a leading provider of financial management, analytics, and population health solutions to the retail pharmacy industry, including independent pharmacies. MarkeTouch Media, LLC (“MarkeTouch Media”) has longstanding pharmacy chain relationships that further broaden EnlivenHealth’s national pharmacy network.

[0000926326-22-000027:mdna:48]
[same as prior period, unchanged from 0000926326-22-000014:mdna:50]

[0000926326-22-000027:mdna:49]
[same as prior period, unchanged from 0000926326-22-000014:mdna:51]

[0000926326-22-000027:mdna:50]
[same as prior period, unchanged from 0000926326-22-000014:mdna:52]

[0000926326-22-000027:mdna:51]
[same as prior period, unchanged from 0000926326-22-000014:mdna:53]

[0000926326-22-000027:mdna:52]
Ransomware Incident

[0000926326-22-000027:mdna:53]
On May 4, 2022, we determined that certain of our information technology systems were affected by ransomware impacting certain internal systems. Upon detecting the security event, we took immediate steps designed to contain the incident and implement our business continuity plans to restore and support continued operations. We have contained the incident and restored substantially all of our critical information technology systems. As a result of the ransomware incident, invoicing was delayed, which impacted the timing of cash collections and free cash flow in the second quarter of 2022. In addition, total revenues were slightly below expectations for the second quarter of 2022 as customer implementations were delayed due to the ransomware incident, but those customer implementations are expected to occur in the second half of 2022. We do not believe the security event will have a material adverse effect on our business, results of operations, or financial condition.

[0000926326-22-000027:mdna:54]
[same as prior period, unchanged from 0000926326-22-000014:mdna:54]

[0000926326-22-000027:mdna:55]
On January 10, 2022, we completed the acquisition of Hub and Spoke Innovations, pursuant to the terms and conditions of the Share Purchase Agreement, dated January 10, 2022, by and among Omnicell Limited (a wholly-owned subsidiary of the Company), Hub and Spoke Innovations Limited, and certain beneficial stockholders specified therein for a base purchase price of £2.5 million (approximately $3.4 million based on the exchange rate in effect at the acquisition date), prior to customary adjustments for closing cash, net working capital, and assumed indebtedness. The Hub and Spoke

[0000926326-22-000027:mdna:56]
Innovations acquisition is expected to complement Omnicell’s total solution technology portfolio for retail pharmacy in the United Kingdom to help pharmacies improve workflows, offer patients 24/7 access to their medications and provide enhanced patient care. The results of the operations of Hub and Spoke Innovations have been included in our consolidated results of operations beginning January 10, 2022.

[0000926326-22-000027:mdna:57]
[same as prior period, unchanged from 0000926326-22-000014:mdna:56]

[0000926326-22-000027:mdna:58]
[same as prior period, unchanged from 0000926326-22-000014:mdna:57]

[0000926326-22-000027:mdna:59]
On September 9, 2021, we completed the acquisition of FDS Amplicare pursuant to the terms and conditions of the Agreement and Plan of Merger, dated July 25, 2021, by and among RxInnovation Inc., Omnicell, Inc., Fleming Acquisition Corp., and the representative of the securityholders for a base purchase price of $177.0 million, prior to customary adjustments for closing cash, net working capital, and assumed indebtedness. The FDS Amplicare acquisition adds a comprehensive and complementary suite of SaaS financial management, analytics, and population health solutions to our EnlivenHealth offering. The results of the operations of FDS Amplicare have been included in our consolidated results of operations beginning September 9, 2021.

[0000926326-22-000027:mdna:60]
[same as prior period, unchanged from 0000926326-22-000014:mdna:60]

[0000926326-22-000027:mdna:61]
[same as prior period, unchanged from 0000926326-22-000014:mdna:61]

[0000926326-22-000027:mdna:62]
[same as prior period, unchanged from 0000926326-22-000014:mdna:62]

[0000926326-22-000027:mdna:63]
[same as prior period, unchanged from 0000926326-22-000014:mdna:63]

[0000926326-22-000027:mdna:64]
[same as prior period, unchanged from 0000926326-22-000014:mdna:64]

[0000926326-22-000027:mdna:65]
[same as prior period, unchanged from 0000926326-22-000014:mdna:65]

[0000926326-22-000027:mdna:66]
[same as prior period, unchanged from 0000926326-22-000014:mdna:66]

[0000926326-22-000027:mdna:67]
[same as prior period, unchanged from 0000926326-22-000014:mdna:67]

[0000926326-22-000027:mdna:68]
[same as prior period, unchanged from 0000926326-22-000014:mdna:68]

[0000926326-22-000027:mdna:69]
[same as prior period, unchanged from 0000926326-22-000014:mdna:69]

[0000926326-22-000027:mdna:70]
[same as prior period, unchanged from 0000926326-22-000014:mdna:70]

[0000926326-22-000027:mdna:71]
[same as prior period, unchanged from 0000926326-22-000014:mdna:71]

[0000926326-22-000027:mdna:72]
[same as prior period, unchanged from 0000926326-22-000014:mdna:72]

[0000926326-22-000027:mdna:73]
There were no material changes in the matters for which we make critical accounting estimates in the preparation of our Condensed Consolidated Financial Statements during the six months ended June 30, 2022 as compared to those disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our Annual Report on Form 10-K for the year ended December 31, 2021, except as discussed in “Recently Adopted Authoritative Guidance” in Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000926326-22-000027:mdna:74]
[same as prior period, unchanged from 0000926326-22-000014:mdna:74]

[0000926326-22-000027:mdna:75]
Refer to “Recently Issued Authoritative Guidance” in Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q for a description of recently issued accounting pronouncements, including the expected dates of adoption and estimated effects on our results of operations, financial position, and cash flows.

[0000926326-22-000027:mdna:76]
[same as prior period, unchanged from 0000926326-22-000014:mdna:77]

[0000926326-22-000027:mdna:77]
[same as prior period, unchanged from 0000926326-22-000014:mdna:78]

[0000926326-22-000027:mdna:78]
|  | Three Months Ended June 30, |
|  |  |  |  |  | Change in |
|  | 2022 |  | 2021 |  | $ |  | % |
|  | (Dollars in thousands) |
| Product revenues | $ | 233,806 |  |  | $ | 196,911 |  |  | $ | 36,895 |  |  | 19% |
| Percentage of total revenues | 71% |  | 72% |  |  |  |  |
| Services and other revenues | 97,580 |  |  | 75,828 |  |  | 21,752 |  |  | 29% |
| Percentage of total revenues | 29% |  | 28% |  |  |  |  |
| Total revenues | $ | 331,386 |  |  | $ | 272,739 |  |  | $ | 58,647 |  |  | 22% |

[0000926326-22-000027:mdna:79]
Product revenues represented 71% and 72% of total revenues for the three months ended June 30, 2022 and 2021, respectively. Product revenues increased by $36.9 million, due to increased customer demand, primarily within our automated dispensing systems business, as well as increases in revenues from IV solutions.

[0000926326-22-000027:mdna:80]
Services and other revenues represented 29% and 28% of total revenues for the three months ended June 30, 2022 and 2021, respectively. Services and other revenues include revenues from technical services; SaaS, subscription software, and technology-enabled services; and other services. Services and other revenues increased by $21.8 million, primarily due to incremental revenues from our recent acquisitions of FDS Amplicare, ReCept, and MarkeTouch Media, as well as continued growth in our installed customer base and our expanded portfolio of services and solutions. The increase was partially offset by a decrease in revenues from 340B solutions primarily due to impacts from decreasing provider utilization of the 340B program as a result of recent drug manufacturer actions.

[0000926326-22-000027:mdna:81]
Our international sales represented 11% of total revenues for both the three months ended June 30, 2022 and 2021, and are expected to be affected by foreign currency exchange rate fluctuations. We are unable to predict the extent to which revenues in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-22-000027:mdna:82]
|  | Six Months Ended June 30, |
|  |  |  |  |  | Change in |
|  | 2022 |  | 2021 |  | $ |  | % |
|  | (Dollars in thousands) |
| Product revenues | $ | 459,681 |  |  | $ | 375,036 |  |  | $ | 84,645 |  |  | 23% |
| Percentage of total revenues | 71% |  | 71% |  |  |  |  |
| Services and other revenues | 190,533 |  |  | 149,546 |  |  | 40,987 |  |  | 27% |
| Percentage of total revenues | 29% |  | 29% |  |  |  |  |
| Total revenues | $ | 650,214 |  |  | $ | 524,582 |  |  | $ | 125,632 |  |  | 24% |

[0000926326-22-000027:mdna:83]
Product revenues represented 71% of total revenues for both the six months ended June 30, 2022 and 2021. Product revenues increased by $84.6 million, due to increased customer demand, primarily within our automated dispensing systems business, as well as increases in revenues from IV solutions.

[0000926326-22-000027:mdna:84]
Services and other revenues represented 29% of total revenues for both the six months ended June 30, 2022 and 2021. Services and other revenues include revenues from technical services; SaaS, subscription software, and technology-enabled services; and other services. Services and other revenues increased by $41.0 million, primarily due to incremental revenues from our recent acquisitions of FDS Amplicare, ReCept, and MarkeTouch Media, as well as continued growth in our installed customer base and our expanded portfolio of services and solutions. The increase was partially offset by a decrease in revenues from 340B solutions primarily due to impacts from decreasing provider utilization of the 340B program as a result of recent drug manufacturer actions.

[0000926326-22-000027:mdna:85]
Our international sales represented 10% and 11% of total revenues for the six months ended June 30, 2022 and 2021, respectively, and are expected to be affected by foreign currency exchange rate fluctuations. We are unable to predict the extent to which revenues in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-22-000027:mdna:86]
[same as prior period, unchanged from 0000926326-22-000014:mdna:83]

[0000926326-22-000027:mdna:87]
[same as prior period, unchanged from 0000926326-22-000014:mdna:84]

[0000926326-22-000027:mdna:88]
[same as prior period, unchanged from 0000926326-22-000014:mdna:85]

[0000926326-22-000027:mdna:89]
|  | Three Months Ended June 30, |
|  |  |  |  |  | Change in |
|  | 2022 |  | 2021 |  | $ |  | % |
|  | (Dollars in thousands) |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | $ | 121,814 |  |  | $ | 100,227 |  |  | $ | 21,587 |  |  | 22% |
| As a percentage of related revenues | 52% |  | 51% |  |  |  |  |
| Cost of services and other revenues | 51,480 |  |  | 36,214 |  |  | 15,266 |  |  | 42% |
| As a percentage of related revenues | 53% |  | 48% |  |  |  |  |
| Total cost of revenues | $ | 173,294 |  |  | $ | 136,441 |  |  | $ | 36,853 |  |  | 27% |
| As a percentage of total revenues | 52% |  | 50% |  |  |  |  |
| Gross profit | $ | 158,092 |  |  | $ | 136,298 |  |  | $ | 21,794 |  |  | 16% |
| Gross margin | 48% |  | 50% |  |  |  |  |

[0000926326-22-000027:mdna:90]
Cost of revenues for the three months ended June 30, 2022 compared to the three months ended June 30, 2021 increased by $36.9 million, of which $21.6 million was attributed to the increase in cost of product revenues and $15.3 million was attributed to the increase in cost of services and other revenues.

[0000926326-22-000027:mdna:91]
The increase in cost of product revenues was primarily driven by the increase in product revenues of $36.9 million for the three months ended June 30, 2022 compared to the three months ended June 30, 2021. The increase was also driven by inventory-related costs due to inflationary impacts, and was partially offset by the benefits associated with economies of scale due to higher volumes during the three months ended June 30, 2022 compared to the three months ended June 30, 2021.

[0000926326-22-000027:mdna:92]
The increase in cost of services and other revenues was primarily driven by the increase in services and other revenues of $21.8 million, including incremental revenues from our recent acquisitions, for the three months ended June 30, 2022 compared to the three months ended June 30, 2021. The cost of service and other revenues grew at a faster pace than our service and other revenues primarily due to additional investments in our service business to support new service solutions, the impact of lower 340B solutions revenues, and the mix of service revenues recognized in the quarter.

[0000926326-22-000027:mdna:93]
The overall decrease in gross margin primarily relates to additional investments in our business, including our service solutions, the impact of lower 340B solutions revenues, and the mix of service revenues recognized in the quarter, as well as inflationary impacts on inventory-related costs. The decrease is partially offset by higher revenues for the three months ended June 30, 2022 due to increased customer demand as well as benefits associated with economies of scale due to higher volumes. Our gross profit for the three months ended June 30, 2022 was $158.1 million, as compared to $136.3 million for the three months ended June 30, 2021.

[0000926326-22-000027:mdna:94]
|  | Six Months Ended June 30, |
|  |  |  |  |  | Change in |
|  | 2022 |  | 2021 |  | $ |  | % |
|  | (Dollars in thousands) |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | $ | 240,152 |  |  | $ | 192,854 |  |  | $ | 47,298 |  |  | 25% |
| As a percentage of related revenues | 52% |  | 51% |  |  |  |  |
| Cost of services and other revenues | 101,923 |  |  | 73,147 |  |  | 28,776 |  |  | 39% |
| As a percentage of related revenues | 53% |  | 49% |  |  |  |  |
| Total cost of revenues | $ | 342,075 |  |  | $ | 266,001 |  |  | $ | 76,074 |  |  | 29% |
| As a percentage of total revenues | 53% |  | 51% |  |  |  |  |
| Gross profit | $ | 308,139 |  |  | $ | 258,581 |  |  | $ | 49,558 |  |  | 19% |
| Gross margin | 47% |  | 49% |  |  |  |  |

[0000926326-22-000027:mdna:95]
Cost of revenues for the six months ended June 30, 2022 compared to the six months ended June 30, 2021 increased by $76.1 million, of which $47.3 million was attributed to the increase in cost of product revenues and $28.8 million was attributed to the increase in cost of services and other revenues.

[0000926326-22-000027:mdna:96]
The increase in cost of product revenues was primarily driven by the increase in product revenues of $84.6 million for the six months ended June 30, 2022 compared to the six months ended June 30, 2021. The increase was also driven by increased inventory-related costs due to inflationary impacts, and was partially offset by the benefits associated with economies of scale due to higher volumes during the six months ended June 30, 2022 compared to the six months ended June 30, 2021.

[0000926326-22-000027:mdna:97]
The increase in cost of services and other revenues was primarily driven by the increase in services and other revenues of $41.0 million, including incremental revenues from our recent acquisitions, for the six months ended June 30, 2022 compared to the six months ended June 30, 2021. The cost of service and other revenues grew at a faster pace than our service and other revenues primarily due to additional investments in our service business to support new service solutions, the impact of lower 340B solutions revenues, and the mix of service revenues recognized in the six months ended June 30, 2022.

[0000926326-22-000027:mdna:98]
The overall decrease in gross margin primarily relates to additional investments in our business, including our service solutions, the impact of lower 340B solutions revenues, and the mix of service revenues recognized in the quarter, as well as inflationary impacts on inventory-related costs. The decrease is partially offset by higher revenues for the six months ended June 30, 2022 due to increased customer demand as well as benefits associated with economies of scale due to higher volumes. Our gross profit for the six months ended June 30, 2022 was $308.1 million, as compared to $258.6 million for the six months ended June 30, 2021.

[0000926326-22-000027:mdna:99]
39

[0000926326-22-000027:mdna:100]
[same as prior period, unchanged from 0000926326-22-000014:mdna:91]

[0000926326-22-000027:mdna:101]
|  | Three Months Ended June 30, |
|  |  |  |  |  | Change in |
|  | 2022 |  | 2021 |  | $ |  | % |
|  | (Dollars in thousands) |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | $ | 26,355 |  |  | $ | 18,213 |  |  | $ | 8,142 |  |  | 45% |
| As a percentage of total revenues | 8% |  | 7% |  |  |  |  |
| Selling, general, and administrative | 119,252 |  |  | 89,169 |  |  | 30,083 |  |  | 34% |
| As a percentage of total revenues | 36% |  | 33% |  |  |  |  |
| Total operating expenses | $ | 145,607 |  |  | $ | 107,382 |  |  | $ | 38,225 |  |  | 36% |
| As a percentage of total revenues | 44% |  | 39% |  |  |  |  |
| Interest and other income (expense), net | $ | (1,711) |  |  | $ | (5,959) |  |  | $ | 4,248 |  |  | (71)% |

[0000926326-22-000027:mdna:102]
Research and Development. Research and development expenses increased by $8.1 million for the three months ended June 30, 2022 compared to the three months ended June 30, 2021. The increase was primarily attributed to an increase in employee-related expenses of approximately $6.7 million due to increased headcount to support the continued development of our intelligent infrastructure and incremental headcount from recent acquisitions.

[0000926326-22-000027:mdna:103]
Selling, General, and Administrative. Selling, general, and administrative expenses increased by $30.1 million for the three months ended June 30, 2022 compared to the three months ended June 30, 2021. The increase was primarily due to an increase of approximately $16.1 million in employee-related expenses primarily related to increased headcount, including the incremental headcount from recent acquisitions, as well as an increase in intangible asset amortization expense of $1.9 million, impairment and abandonment charges to operating lease right-of-use assets of $3.3 million, and ransomware-related expenses, net of insurance recoveries, of $1.2 million. The increase was also driven by higher spending related to travel and meetings, and other operating expenses. The increase was partially offset by a decrease of $2.0 million in acquisition-related expenses.

[0000926326-22-000027:mdna:104]
Interest and Other Income (Expense), Net. Interest and other income (expense), net changed by $4.2 million for the three months ended June 30, 2022 compared to the three months ended June 30, 2021, primarily driven by a $4.3 million decrease in other expenses. The decrease in other expenses during the three months ended June 30, 2022 as compared to the three months ended June 30, 2021 is primarily due to the adoption of ASU 2020-06, effective January 1, 2022, which eliminated the imputed interest expense recognized on our convertible senior notes (refer to Note 1, Organization and Summary of Significant Accounting Policies, for additional information).

[0000926326-22-000027:mdna:105]
|  | Six Months Ended June 30, |
|  |  |  |  |  | Change in |
|  | 2022 |  | 2021 |  | $ |  | % |
|  | (Dollars in thousands) |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | $ | 51,385 |  |  | $ | 34,293 |  |  | $ | 17,092 |  |  | 50% |
| As a percentage of total revenues | 8% |  | 7% |  |  |  |  |
| Selling, general, and administrative | 239,185 |  |  | 175,762 |  |  | 63,423 |  |  | 36% |
| As a percentage of total revenues | 37% |  | 34% |  |  |  |  |
| Total operating expenses | $ | 290,570 |  |  | $ | 210,055 |  |  | $ | 80,515 |  |  | 38% |
| As a percentage of total revenues | 45% |  | 40% |  |  |  |  |
| Interest and other income (expense), net | $ | (1,825) |  |  | $ | (12,650) |  |  | $ | 10,825 |  |  | (86)% |

[0000926326-22-000027:mdna:106]
Research and Development. Research and development expenses increased by $17.1 million for the six months ended June 30, 2022 compared to the six months ended June 30, 2021. The increase was primarily attributed to an increase in employee-related expenses of approximately $13.4 million due to increased headcount to support the continued development of

[0000926326-22-000027:mdna:107]
[same as prior period, unchanged from 0000926326-22-000014:mdna:94]

[0000926326-22-000027:mdna:108]
Selling, General, and Administrative. Selling, general, and administrative expenses increased by $63.4 million for the six months ended June 30, 2022 compared to the six months ended June 30, 2021. The increase was primarily due to an increase of approximately $33.6 million in employee-related expenses primarily related to increased headcount, including the incremental headcount from recent acquisitions, as well as an increase in spending on travel and meetings of $5.4 million, an increase in intangible asset amortization expense of $4.2 million, impairment and abandonment charges to operating lease right-of-use assets of $5.1 million, ransomware-related expenses, net of insurance recoveries, of $1.2 million, and increases in other operating expenses. The increase was partially offset by a decrease of $2.0 million in acquisition-related expenses.

[0000926326-22-000027:mdna:109]
Interest and Other Income (Expense), Net. Interest and other income (expense), net changed by $10.8 million for the six months ended June 30, 2022 compared to the six months ended June 30, 2021, primarily driven by a $9.5 million decrease in other expenses and a $1.3 million increase in other income. The decrease in other expenses during the six months ended June 30, 2022 as compared to the six months ended June 30, 2021 is primarily due to the adoption of ASU 2020-06, effective January 1, 2022, which eliminated the imputed interest expense recognized on our convertible senior notes (refer to Note 1, Organization and Summary of Significant Accounting Policies, for additional information). The increase in other income during the six months ended June 30, 2022 as compared to the six months ended June 30, 2021 is primarily attributable to benefits from certain arrangements outside of our normal course of business.

[0000926326-22-000027:mdna:110]
[same as prior period, unchanged from 0000926326-22-000014:mdna:97]

[0000926326-22-000027:mdna:111]
|  | Three Months Ended June 30, |
|  |  |  |  |  | Change in |
|  | 2022 |  | 2021 |  | $ |  | % |
|  | (Dollars in thousands) |
| Provision for income taxes | $ | 1,705 |  |  | $ | 2,533 |  |  | $ | (828) |  |  | (33)% |

[0000926326-22-000027:mdna:112]
|  | Six Months Ended June 30, |
|  |  |  |  |  | Change in |
|  | 2022 |  | 2021 |  | $ |  | % |
|  | (Dollars in thousands) |
| Provision for (benefit from) income taxes | $ | (1,538) |  |  | $ | 1,325 |  |  | $ | (2,863) |  |  | (216)% |

[0000926326-22-000027:mdna:113]
Our annual effective tax rate before discrete items was 24.1% and 27.8% for the six months ended June 30, 2022 and 2021, respectively. The decrease in the estimated annual effective tax rate for the six months ended June 30, 2022 compared to the same period in 2021 was primarily due to a decrease in non-deductible expenses, and an increase in research and development credits and FDII benefit.

[0000926326-22-000027:mdna:114]
Benefit from income taxes for the six months ended June 30, 2022 included net discrete income tax benefit of $5.3 million, primarily due to a $5.1 million tax benefit from equity compensation.

[0000926326-22-000027:mdna:115]
Provision for income taxes for the six months ended June 30, 2021 included net discrete income tax benefit of $8.6 million, primarily due to a $8.2 million tax benefit from equity compensation.

[0000926326-22-000027:mdna:116]
[same as prior period, unchanged from 0000926326-22-000014:mdna:102]

[0000926326-22-000027:mdna:117]
[same as prior period, unchanged from 0000926326-22-000014:mdna:103]

[0000926326-22-000027:mdna:118]
[same as prior period, unchanged from 0000926326-22-000014:mdna:104]

[0000926326-22-000027:mdna:119]
We had cash and cash equivalents of $245.0 million at June 30, 2022 compared to $349.1 million at December 31, 2021. All of our cash and cash equivalents are invested in bank accounts and money market funds held in sweep and asset management accounts with major financial institutions.

[0000926326-22-000027:mdna:120]
Our cash position and working capital at June 30, 2022 and December 31, 2021 were as follows:

[0000926326-22-000027:mdna:121]
|  | June 30,2022 |  | December 31,2021 |
|  | (In thousands) |
| Cash and cash equivalents | $ | 244,953 |  |  | $ | 349,051 |  |
| Working capital (deficit) (1) | $ | 414,256 |  |  | $ | (95,456) |  |

[0000926326-22-000027:mdna:122]
[same as prior period, unchanged from 0000926326-22-000014:mdna:108]

[0000926326-22-000027:mdna:123]
(1)    The working capital deficit balance as of December 31, 2021 was primarily due to the classification of our convertible senior notes as a current rather than long-term liability. Refer to Note 10, Convertible Senior Notes, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional information.

[0000926326-22-000027:mdna:124]
Our ratio of current assets to current liabilities was 2.1:1 and 0.9:1 at June 30, 2022 and December 31, 2021, respectively.

[0000926326-22-000027:mdna:125]
[same as prior period, unchanged from 0000926326-22-000014:mdna:111]

[0000926326-22-000027:mdna:126]
Revolving Credit Facility

[0000926326-22-000027:mdna:127]
On November 15, 2019, we entered into an Amended and Restated Credit Agreement (as subsequently amended, as discussed below, the “A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers, and Wells Fargo Bank, National Association, as administrative agent. The A&R Credit Agreement superseded our 2016 senior secured credit facility and provides for (a) a five-year revolving credit facility of $500.0 million (the “Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million. In addition, the A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million.

[0000926326-22-000027:mdna:128]
On September 22, 2020, the parties entered into an amendment to the A&R Credit Agreement to, among other changes, permit the issuance of the convertible senior notes and the purchase of the convertible note hedge transactions described below, expand our flexibility to repurchase our common stock and make other restricted payments, and replace the total net leverage covenant with a new secured net leverage covenant that required us to maintain a consolidated secured net leverage ratio not to exceed 3.50:1 for the calendar quarters ending September 30, 2020, December 31, 2020, and March 31, 2021 and requires us to maintain a consolidated secured net leverage ratio not to exceed 3.00:1 for the calendar quarters ending thereafter.

[0000926326-22-000027:mdna:129]
As of June 30, 2022, there was no outstanding balance for the Revolving Credit Facility and we were in compliance with all covenants. Refer to Note 9, Debt and Credit Agreement, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional information. We expect to use future loans under the Revolving Credit Facility, if any, for working capital, potential acquisitions, and other general corporate purposes.

[0000926326-22-000027:mdna:130]
[same as prior period, unchanged from 0000926326-22-000014:mdna:116]

[0000926326-22-000027:mdna:131]
[same as prior period, unchanged from 0000926326-22-000014:mdna:117]

[0000926326-22-000027:mdna:132]
The 2016 Repurchase Program has a total of $2.7 million remaining for future repurchases as of June 30, 2022, which may result in additional use of cash. During the first quarter of 2022, the 2014 Repurchase Program was completed. During the six months ended June 30, 2022, we repurchased approximately 389,300 shares of our common stock under our repurchase programs at an average price of $134.11 per share for an aggregate purchase price of approximately $52.2 million. Refer to “Stock Repurchase Programs” under Note 15, Employee Benefits and Share-Based Compensation, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional information.

[0000926326-22-000027:mdna:133]
Based on our current business plan and product backlog, we believe that our existing cash and cash equivalents, our anticipated cash flows from operations, cash generated from the exercise of employee stock options and purchases under our Employee Stock Purchase Plan (“ESPP”), along with the availability of funds under the Revolving Credit Facility will be sufficient to meet our cash needs for working capital, capital expenditures, potential acquisitions, and other contractual obligations for at least the next twelve months. For periods beyond the next twelve months, we also anticipate that our net operating cash flows plus existing balances of cash and cash equivalents will suffice to fund the continued growth of our business.

[0000926326-22-000027:mdna:134]
[same as prior period, unchanged from 0000926326-22-000014:mdna:120]

[0000926326-22-000027:mdna:135]
[same as prior period, unchanged from 0000926326-22-000014:mdna:121]

[0000926326-22-000027:mdna:136]
|  | Six Months Ended June 30, |
|  | 2022 |  | 2021 |
|  | (In thousands) |
| Net cash provided by (used in): |  |  |  |
| Operating activities | $ | (25,547) |  |  | $ | 129,188 |  |
| Investing activities | (25,550) |  |  | (26,482) |  |
| Financing activities | (33,571) |  |  | 22,413 |  |
| Effect of exchange rate changes on cash and cash equivalents | (2,123) |  |  | (74) |  |
| Net increase (decrease) in cash, cash equivalents, and restricted cash | $ | (86,791) |  |  | $ | 125,045 |  |

[0000926326-22-000027:mdna:137]
[same as prior period, unchanged from 0000926326-22-000014:mdna:123]

[0000926326-22-000027:mdna:138]
[same as prior period, unchanged from 0000926326-22-000014:mdna:124]

[0000926326-22-000027:mdna:139]
Net cash used in operating activities was $25.5 million for the six months ended June 30, 2022, primarily consisting of net income of $17.3 million adjusted for non-cash items of $80.9 million, offset by changes in assets and liabilities of $123.7 million. The non-cash items primarily consisted of depreciation and amortization expense of $43.0 million, share-based compensation expense of $33.4 million, amortization of operating lease right-of-use assets of $6.8 million, impairment and abandonment of operating lease right-of-use assets of $5.1 million, amortization of debt issuance costs of $2.1 million, and a change in deferred income taxes of $9.5 million. Changes in assets and liabilities include cash outflows from (i) an increase in accounts receivable and unbilled receivables of $71.4 million primarily due to an increase in billings driven by overall business growth and the timing of shipments and collections, as well as the timing of invoicing due to the previously disclosed ransomware incident, (ii) an increase in inventories of $32.6 million primarily to support forecasted sales, including advanced purchases of certain components, such as semiconductors, as well as higher costs of inventory and timing of shipments, (iii) an increase in investment in sales-type leases of $12.5 million primarily due to the increase in sales-type lease revenues associated with Advanced Services products, (iv) a decrease in accrued compensation of $11.1 million primarily due to a decrease in accrued commissions and bonuses, (v) a decrease in operating lease liabilities of $7.2 million, (vi) a decrease in accounts payable of $3.1 million, and (vii) an increase in other current assets, net of funds held for customers, of $2.0 million. These cash outflows were partially offset by (i) a decrease in prepaid commissions of $6.0 million, (ii) an increase in accrued liabilities of $4.7 million, (iii) a decrease in prepaid expenses of $1.7 million, (iv) a decrease in other long-term assets of $1.5 million, (v) an increase in deferred revenues of $1.4 million, and (vi) an increase in other long-term liabilities of $1.0 million.

[0000926326-22-000027:mdna:140]
Net cash provided by operating activities was $129.2 million for the six months ended June 30, 2021, primarily consisting of net income of $34.6 million adjusted for non-cash items of $76.9 million and changes in assets and liabilities of $17.7 million. The non-cash items primarily consisted of depreciation and amortization expense of $35.0 million, share-based compensation expense of $24.8 million, amortization of discount on convertible senior notes of $9.2 million, amortization of operating lease right-of-use assets of $5.8 million, amortization of debt issuance costs of $1.7 million, and a change in deferred income taxes of $0.5 million. Changes in assets and liabilities include cash inflows from (i) an increase in deferred revenues of $27.5 million primarily due to an increase in billings driven by the timing of shipments in order to meet customers’ implementation schedules and recognition of revenues for products requiring installation, (ii) an increase in accounts payable of $15.7 million primarily due to an overall increase in spending, as well as timing of payments, (iii) an increase in accrued liabilities of $10.1 million primarily due to an increase in rebates and buyout liabilities, (iv) a decrease in investment in sales-type leases of $2.4 million, (v) a decrease in prepaid commissions of $1.9 million, and (vi) a decrease in other long-term assets of $1.6 million. These cash inflows were partially offset by (i) an increase in accounts receivable and unbilled receivables of $19.7 million primarily due to an increase in billings driven by the timing of shipments as well as collections, (ii) a decrease in accrued compensation of $7.3 million primarily due to a decrease in accrued commissions and bonuses, (iii) an increase in inventories of $6.6 million to support forecasted sales, (iv) a decrease in operating lease liabilities of $6.2 million, and (v) an increase in prepaid expenses of $1.4 million.

[0000926326-22-000027:mdna:141]
[same as prior period, unchanged from 0000926326-22-000014:mdna:127]

[0000926326-22-000027:mdna:142]
Net cash used in investing activities was $25.6 million for the six months ended June 30, 2022, which consisted of $3.4 million consideration paid for the acquisition of Hub and Spoke Innovations, net of cash acquired, capital expenditures of

[0000926326-22-000027:mdna:143]
$21.1 million for property and equipment, and $6.5 million for costs of software development for external use, partially offset by working capital adjustments from acquisitions of $5.5 million.

[0000926326-22-000027:mdna:144]
Net cash used in investing activities was $26.5 million for the six months ended June 30, 2021, which consisted of capital expenditures of $11.1 million for property and equipment, and $15.4 million for costs of software development for external use.

[0000926326-22-000027:mdna:145]
[same as prior period, unchanged from 0000926326-22-000014:mdna:130]

[0000926326-22-000027:mdna:146]
Net cash used in financing activities was $33.6 million for the six months ended June 30, 2022, primarily due to $52.2 million for repurchases of our stock and $8.5 million in employees’ taxes paid related to restricted stock unit vesting, partially offset by $21.1 million in proceeds from employee stock option exercises and ESPP purchases, and a net increase in the customer funds balances of $6.0 million.

[0000926326-22-000027:mdna:147]
Net cash provided by financing activities was $22.4 million for the six months ended June 30, 2021, primarily due to $32.3 million in proceeds from employee stock option exercises and ESPP purchases, partially offset by $6.7 million in employees’ taxes paid related to restricted stock unit vesting, and a net decrease in the customer funds balances of $3.3 million.

[0000926326-22-000027:mdna:148]
[same as prior period, unchanged from 0000926326-22-000014:mdna:133]

[0000926326-22-000027:mdna:149]
There have been no significant changes during the six months ended June 30, 2022 to the contractual obligations disclosed in “Management’s Discussion and Analysis of Financial Condition and Results of Operations,” set forth in Part II, Item 7, of our Annual Report on Form 10-K for the year ended December 31, 2021.

[0000926326-22-000027:mdna:150]
Contractual obligations as of June 30, 2022 were as follows:

[0000926326-22-000027:mdna:151]
|  | Payments Due By Period |
|  | Total |  | Remainder of 2022 |  | 2023 - 2024 |  | 2025 - 2026 |  | 2027 and thereafter |
|  | (In thousands) |
| Operating leases (1) | $ | 63,930 |  |  | $ | 7,778 |  |  | $ | 24,854 |  |  | $ | 17,076 |  |  | $ | 14,222 |  |
| Purchase obligations (2) | 226,473 |  |  | 175,758 |  |  | 50,429 |  |  | 257 |  |  | 29 |  |
| Convertible senior notes (3) | 580,032 |  |  | 719 |  |  | 2,875 |  |  | 576,438 |  |  | — |  |
| Other (4) | 818 |  |  | 130 |  |  | 440 |  |  | 248 |  |  | — |  |
| Total (5) | $ | 871,253 |  |  | $ | 184,385 |  |  | $ | 78,598 |  |  | $ | 594,019 |  |  | $ | 14,251 |  |

[0000926326-22-000027:mdna:152]
[same as prior period, unchanged from 0000926326-22-000014:mdna:137]

[0000926326-22-000027:mdna:153]
[same as prior period, unchanged from 0000926326-22-000014:mdna:138]

[0000926326-22-000027:mdna:154]
[same as prior period, unchanged from 0000926326-22-000014:mdna:139]

[0000926326-22-000027:mdna:155]
[same as prior period, unchanged from 0000926326-22-000014:mdna:140]

[0000926326-22-000027:mdna:156]
[same as prior period, unchanged from 0000926326-22-000014:mdna:141]

[0000926326-22-000027:mdna:157]
(5)Refer to Note 13, Commitments and Contingencies, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional information.
