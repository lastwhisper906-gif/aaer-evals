# OMCL 8-K — 0000926326-22-000025 filed 2022-08-04

## item codes, every 8-K on or before 2022-08-09

- 2022-08-04 0000926326-22-000025 — 2.02, 8.01, 9.01
- 2022-05-31 0000926326-22-000020 — 5.02, 5.07, 9.01
- 2022-05-24 0000926326-22-000016 — 5.02
- 2022-05-09 0000926326-22-000012 — 8.01
- 2022-04-28 0000926326-22-000009 — 2.02, 9.01
- 2022-03-01 0001104659-22-028681 — 5.02, 8.01, 9.01
- 2022-02-14 0000926326-22-000004 — 2.02, 9.01
- 2022-01-04 0000926326-22-000002 — 7.01, 9.01
- 2021-12-29 0001104659-21-154294 — 7.01, 9.01
- 2021-12-13 0000926326-21-000039 — 8.01
- 2021-12-02 0000926326-21-000037 — 7.01, 9.01
- 2021-11-02 0000926326-21-000031 — 2.02, 9.01
- 2021-09-09 0000926326-21-000028 — 7.01, 9.01
- 2021-07-29 0000926326-21-000024 — 2.02, 9.01
- 2021-07-26 0000926326-21-000022 — 7.01, 9.01
- 2021-07-12 0000926326-21-000019 — 5.02, 9.01
- 2021-05-28 0000926326-21-000015 — 5.07
- 2021-04-29 0000926326-21-000011 — 2.02, 9.01
- 2021-02-01 0000926326-21-000004 — 2.02, 9.01
- 2021-01-26 0000926326-21-000002 — 5.02
- 2021-01-13 0001104659-21-003672 — 2.02, 7.01, 9.01
- 2020-10-27 0000926326-20-000032 — 2.02, 9.01
- 2020-10-01 0000926326-20-000029 — 7.01, 9.01
- 2020-09-25 0001104659-20-108924 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2020-09-22 0001104659-20-107176 — 1.01, 8.01, 9.01
- 2020-08-12 0000926326-20-000027 — 2.03
- 2020-08-12 0000926326-20-000025 — 1.01, 5.03, 7.01, 9.01
- 2020-07-28 0000926326-20-000021 — 2.02, 9.01
- 2020-05-27 0000926326-20-000017 — 5.07
- 2020-05-07 0000926326-20-000012 — 2.02, 9.01
- 2020-02-18 0000926326-20-000007 — 5.02, 9.01
- 2020-02-13 0000926326-20-000005 — 8.01
- 2020-02-06 0000926326-20-000003 — 2.02, 9.01
- 2019-12-06 0001104659-19-070339 — 8.01
- 2019-11-18 0000926326-19-000035 — 1.01, 2.03, 9.01
- 2019-10-24 0000926326-19-000028 — 2.02, 9.01
- 2019-07-25 0000926326-19-000021 — 2.02, 9.01
- 2019-05-15 0000926326-19-000015 — 5.07
- 2019-04-25 0000926326-19-000011 — 2.02, 9.01
- 2019-03-08 0000926326-19-000009 — 5.02, 9.01
- 2019-02-19 0000926326-19-000005 — 5.02, 9.01
- 2019-02-07 0000926326-19-000003 — 2.02, 9.01
- 2018-10-25 0000926326-18-000028 — 2.02, 9.01
- 2018-09-14 0001104659-18-056929 — 5.02, 9.01
- 2018-07-26 0000926326-18-000022 — 2.02, 9.01
- 2018-06-06 0000926326-18-000019 — 5.02, 9.01
- 2018-05-16 0001104659-18-033801 — 5.07
- 2018-04-26 0000926326-18-000013 — 2.02, 9.01
- 2018-03-02 0001104659-18-014497 — 5.02
- 2018-02-08 0000926326-18-000007 — 5.02
- 2018-02-02 0000926326-18-000005 — 5.02
- 2018-02-01 0000926326-18-000003 — 2.02, 9.01
- 2017-12-26 0000926326-17-000041 — 1.01, 2.03, 9.01
- 2017-11-03 0001104659-17-066102 — 1.01, 8.01, 9.01
- 2017-10-26 0000926326-17-000035 — 2.02, 9.01
- 2017-08-03 0000926326-17-000028 — 5.07 — amendment, the index does not say of what
- 2017-07-27 0000926326-17-000026 — 2.02, 9.01
- 2017-07-25 0000926326-17-000023 — 5.02, 9.01
- 2017-05-24 0000926326-17-000019 — 5.07
- 2017-05-04 0001628280-17-004851 — 2.02, 9.01
- 2017-02-15 0000926326-17-000010 — 2.05
- 2017-02-15 0000926326-17-000008 — 2.02, 9.01
- 2017-02-13 0000926326-17-000002 — 5.02
- 2016-12-08 0001104659-16-161330 — 2.01, 2.03, 9.01
- 2016-12-06 0001104659-16-160709 — 7.01
- 2016-11-29 0001104659-16-159456 — 1.01, 7.01, 9.01
- 2016-10-27 0000926326-16-000075 — 2.02, 9.01
- 2016-10-07 0000926326-16-000072 — 5.02, 8.01
- 2016-08-05 0000926326-16-000068 — 8.01
- 2016-07-28 0000926326-16-000066 — 2.02, 9.01
- 2016-06-13 0001104659-16-126854 — 5.02
- 2016-05-25 0000926326-16-000060 — 5.07
- 2016-04-28 0000926326-16-000054 — 2.02, 9.01
- 2016-03-21 0001104659-16-106649 — 8.01, 9.01
- 2016-03-17 0000926326-16-000051 — 7.01, 9.01
- 2016-03-17 0000926326-16-000049 — 9.01 — amendment of 0000926326-16-000051
- 2016-02-10 0001104659-16-095486 — 5.02, 9.01
- 2016-02-04 0000926326-16-000041 — 2.02, 9.01
- 2016-01-06 0001104659-16-088299 — 1.01, 2.01, 2.03, 9.01
- 2015-12-10 0000926326-15-000038 — 8.01, 9.01
- 2015-10-29 0001104659-15-074138 — 1.01, 9.01
- 2015-10-29 0000926326-15-000031 — 2.02, 9.01
- 2015-08-20 0001104659-15-061135 — 5.02, 9.01
- 2015-07-30 0000926326-15-000024 — 2.02, 9.01
- 2015-05-22 0001104659-15-040440 — 5.07
- 2015-05-01 0001104659-15-032846 — 5.02
- 2015-05-01 0001104659-15-032844 — 7.01
- 2015-04-30 0000926326-15-000015 — 9.01
- 2015-04-22 0001104659-15-029356 — 8.01, 9.01
- 2015-03-20 0001104659-15-021435 — 3.01
- 2015-03-18 0001104659-15-020699 — 7.01
- 2015-03-17 0001104659-15-020483 — 8.01, 9.01
- 2015-03-02 0001104659-15-015802 — 1.01, 9.01
- 2015-02-12 0001104659-15-009234 — 5.02, 9.01
- 2015-02-03 0000926326-15-000003 — 9.01
- 2015-01-15 0001104659-15-002635 — 5.02
- 2014-11-07 0001104659-14-078398 — 1.01, 8.01, 9.01
- 2014-10-30 0000926326-14-000037 — 2.02, 9.01
- 2014-08-25 0001104659-14-062772 — 8.01, 9.01
- 2014-07-31 0000926326-14-000032 — 2.02, 9.01
- 2014-05-21 0001104659-14-040744 — 5.07
- 2014-05-01 0000926326-14-000008 — 2.02, 9.01
- 2014-04-08 0001104659-14-026441 — 4.01, 9.01
- 2014-04-02 0001104659-14-025179 — 5.02
- 2014-02-07 0001104659-14-007552 — 5.02, 9.01
- 2014-02-04 0001104659-14-006352 — 2.02, 9.01
- 2013-12-09 0001104659-13-088980 — 1.01, 9.01
- 2013-12-02 0001104659-13-087877 — 5.02
- 2013-10-31 0001104659-13-079660 — 2.02, 9.01
- 2013-09-26 0001104659-13-072435 — 1.01, 2.03, 9.01
- 2013-08-01 0001104659-13-058959 — 2.02, 9.01
- 2013-05-23 0001104659-13-044317 — 5.07
- 2013-05-02 0001104659-13-036605 — 2.02, 9.01
- 2013-03-11 0001104659-13-019143 — 8.01
- 2013-02-07 0001104659-13-008477 — 5.02, 9.01
- 2013-01-31 0001104659-13-006446 — 2.02, 9.01
- 2012-11-02 0001104659-12-073697 — 5.02
- 2012-10-25 0001104659-12-071211 — 2.02, 9.01
- 2012-08-06 0001104659-12-054635 — 8.01
- 2012-08-03 0001104659-12-054214 — 2.01, 9.01 — amendment of 0001104659-12-038888
- 2012-08-01 0001104659-12-053005 — 2.02, 9.01
- 2012-06-12 0001104659-12-042936 — 8.01, 9.01
- 2012-05-23 0001104659-12-039459 — 5.07
- 2012-05-22 0001104659-12-038888 — 2.01, 9.01
- 2012-05-02 0001104659-12-032048 — 2.02, 9.01
- 2012-05-02 0001104659-12-032036 — 1.01, 9.01
- 2012-04-04 0001104659-12-023883 — 5.02, 8.01
- 2012-03-20 0001104659-12-019462 — 1.01, 9.01
- 2012-02-13 0001104659-12-009353 — 5.02, 9.01
- 2012-01-26 0001104659-12-004244 — 2.02, 9.01
- 2011-10-27 0001104659-11-058464 — 2.02, 9.01
- 2011-10-25 0001104659-11-057721 — 1.01
- 2011-07-28 0001104659-11-041505 — 2.02, 9.01
- 2011-05-27 0001104659-11-032006 — 5.07
- 2011-05-02 0001104659-11-024908 — 2.02, 9.01
- 2011-04-15 0001104659-11-020407 — 5.02, 9.01 — amendment of 0001104659-11-005638
- 2011-02-08 0001104659-11-005638 — 5.02, 9.01
- 2011-01-27 0001104659-11-003419 — 2.02, 9.01
- 2010-12-22 0001104659-10-064003 — 5.02, 5.07, 9.01
- 2010-10-27 0001104659-10-054036 — 2.02, 9.01
- 2010-10-05 0001104659-10-051173 — 8.01
- 2010-07-22 0001104659-10-039126 — 2.02, 9.01
- 2010-07-09 0001104659-10-037594 — 2.05
- 2010-05-28 0001104659-10-031607 — 5.07
- 2010-04-26 0001104659-10-021797 — 2.02, 9.01
- 2010-03-17 0001104659-10-014849 — 5.02, 9.01
- 2010-02-08 0001104659-10-005457 — 5.02, 9.01
- 2010-01-28 0001104659-10-003627 — 2.02, 9.01
- 2009-10-22 0001104659-09-059972 — 2.02, 9.01
- 2009-07-23 0001104659-09-044508 — 2.02, 9.01
- 2009-05-20 0001104659-09-033938 — 5.02, 9.01
- 2009-04-30 0001104659-09-027707 — 2.02, 9.01
- 2009-03-10 0001104659-09-016178 — 5.02, 9.01
- 2009-02-09 0001104659-09-007692 — 5.02, 9.01
- 2009-01-29 0001104659-09-005022 — 2.02, 2.05, 9.01
- 2009-01-21 0001104659-09-003180 — 2.02, 8.01, 9.01
- 2009-01-06 0001104659-09-000625 — 5.02
- 2008-10-23 0001104659-08-065475 — 2.02, 9.01
- 2008-07-21 0001104659-08-046690 — 2.02, 9.01
- 2008-05-16 0001104659-08-034035 — 8.01, 9.01
- 2008-04-28 0001104659-08-027379 — 7.01, 9.01
- 2008-04-21 0001104659-08-025616 — 2.02, 9.01
- 2008-03-12 0001104659-08-016939 — 7.01, 9.01
- 2008-02-26 0001104659-08-012840 — 7.01, 9.01
- 2008-02-12 0001104659-08-009382 — 5.02, 9.01
- 2008-01-31 0001104659-08-006199 — 2.02, 9.01
- 2007-12-05 0001104659-07-087191 — 1.01, 9.01
- 2007-10-18 0001104659-07-075654 — 2.02, 9.01
- 2007-07-27 0001104659-07-056886 — 5.03, 9.01
- 2007-07-19 0001104659-07-054924 — 2.02, 9.01
- 2007-05-23 0001104659-07-042287 — 8.01, 9.01
- 2007-05-07 0001104659-07-036172 — 1.01, 5.02, 9.01
- 2007-04-24 0001104659-07-030578 — 2.02, 9.01 — amendment, the index does not say of what
- 2007-04-24 0001104659-07-030547 — 2.02, 9.01
- 2007-04-10 0001104659-07-027465 — 5.02, 9.01
- 2007-03-23 0001104659-07-021969 — 2.02, 4.02, 9.01
- 2007-01-30 0001104659-07-005772 — 2.02, 9.01
- 2007-01-09 0001104659-07-001600 — 5.02, 9.01
- 2006-10-30 0001104659-06-069612 — 1.01
- 2006-10-19 0001104659-06-067549 — 2.02, 9.01
- 2006-07-20 0001104659-06-048020 — 2.02, 4.02, 9.01
- 2006-05-17 0001104659-06-035522 — 1.01, 9.01 — amendment of 0001104659-05-011155
- 2006-05-09 0001104659-06-032706 — 1.01, 9.01
- 2006-04-25 0001104659-06-027438 — 2.02, 9.01
- 2006-04-04 0001104659-06-022204 — 1.01, 9.01
- 2006-03-15 0001104659-06-016861 — 1.01, 9.01
- 2006-01-30 0001104659-06-004749 — 2.02, 9.01
- 2006-01-24 0001104659-06-003504 — 1.01, 5.02, 9.01
- 2005-12-13 0001104659-05-060532 — 1.01, 9.01
- 2005-11-10 0001104659-05-054663 — 2.02, 9.01
- 2005-07-21 0001104659-05-033464 — 2.02, 9.01
- 2005-06-22 0001104659-05-029255 — 1.01
- 2005-05-16 0001104659-05-023473 — 2.02, 9.01 — amendment of 0001104659-05-018173
- 2005-05-16 0001104659-05-023471 — 2.02, 9.01 — amendment of 0001104659-05-017382
- 2005-05-10 0001104659-05-022127 — 1.01
- 2005-04-26 0001104659-05-018173 — 2.02, 9.01
- 2005-04-21 0001104659-05-017382 — 2.02, 9.01
- 2005-04-06 0001104659-05-015401 — 5.02
- 2005-03-15 0001104659-05-011155 — 1.01, 9.01
- 2005-03-08 0001104659-05-009975 — 1.01, 9.01
- 2005-02-03 0001104659-05-003943 — 2.02, 9.01
- 2005-01-13 0001104659-05-001314 — 5.02, 9.01
- 2004-10-21 0001104659-04-031413 — 2.02, 9.01
- 2004-07-22 0001104659-04-020572 — 12, 7
- 2004-04-14 0001104659-04-010039 — 12, 7
- 2004-04-05 0001104659-04-009437 — 12, 7
- 2004-01-26 0001104659-04-001655 — 12, 7
- 2003-10-16 0001104659-03-022990 — 12, 7
- 2003-07-17 0001104659-03-015053 — 9
- 2003-04-18 0001104659-03-006823 — 7, 9
- 2003-02-14 0001104659-03-002607 — 5, 7

## late-filing notifications on or before 2022-08-09

- 2015-03-02 0000926326-15-000006 — NT 10-K, for the period ended 2014-12-31
- 2007-03-16 0001104659-07-020094 — NT 10-K, for the period ended 2006-12-31

## item 2.02 — earnings release, exhibit 99.1

[0000926326-22-000025:8k_2_02:1]
EX-99.1
2
exhibit991q2-22.htm
EX-99.1

[0000926326-22-000025:8k_2_02:2]
Document

[0000926326-22-000025:8k_2_02:3]
Exhibit 99.1

[0000926326-22-000025:8k_2_02:4]
| Contact: |  |  |
| Kathleen Nemeth |  | Omnicell, Inc. |
| Senior Vice President, Investor Relations |  | 2625 Augustine Drive, Suite 301 |
| 650-435-3318 |  | Santa Clara, CA 95054 |
| Kathleen.Nemeth@Omnicell.com |  |  |

[0000926326-22-000025:8k_2_02:5]
Omnicell Announces Financial Results for Second Quarter 2022

[0000926326-22-000025:8k_2_02:6]
GAAP revenues of $331 million and non-GAAP revenues of $332 million

[0000926326-22-000025:8k_2_02:7]
GAAP net income per diluted share of $0.20

[0000926326-22-000025:8k_2_02:8]
Non-GAAP net income per diluted share of $0.84

[0000926326-22-000025:8k_2_02:9]
Second quarter results reflect an impact from the previously disclosed ransomware incident; full year 2022 outlook is unchanged

[0000926326-22-000025:8k_2_02:10]
SANTA CLARA, Calif. -- August 4, 2022 -- Omnicell, Inc. (NASDAQ:OMCL) (“Omnicell,” “we,” “our,” “us,” “management,” or the “Company”), a leading provider of medication management solutions and adherence tools for healthcare systems and pharmacies, today announced results for its second quarter ended June 30, 2022.

[0000926326-22-000025:8k_2_02:11]
Randall Lipps, Chairman, President, Chief Executive Officer, and founder of Omnicell, said, “We delivered a solid performance in the second quarter and continue to see strength in our overall business as we further advance our strategy to transform the pharmacy care delivery model and provide what we believe are mission critical medication management solutions to our customers. We are pleased to reaffirm our full year 2022 guidance for Product Bookings, Total GAAP and non-GAAP Revenues, Non-GAAP EPS, and Non-GAAP EBITDA, which reflects our commercial momentum, a healthy backlog, and our expectation for continued demand in the second half of the year, along with our ongoing focus on cost management. While the ransomware incident modestly impacted our second quarter results, we remain confident in our full year 2022 outlook given the demand we expect to see for our products and services in the second half of the year. I am proud of our Omnicell team members for their efforts in navigating what continues to be a dynamic macro-environment and I remain excited about the opportunities in front of us. We believe Omnicell is uniquely positioned to enable the digital transformation across the entire medication management continuum, which we expect will continue to drive profitable growth and long-term value creation.”

[0000926326-22-000025:8k_2_02:12]
GAAP Results

[0000926326-22-000025:8k_2_02:13]
Total GAAP revenues for the second quarter of 2022 were $331 million, up $59 million, or 22%, from the second quarter of 2021. The increase in GAAP revenues reflects continued strong demand for Omnicell’s mission critical medication management solutions, as well as the contribution of revenues from recent acquisitions.

[0000926326-22-000025:8k_2_02:14]
GAAP net income for the second quarter of 2022 was $9 million, or $0.20 per diluted share. This compares to GAAP net income of $20 million, or $0.43 per diluted share, for the second quarter of 2021.

[0000926326-22-000025:8k_2_02:15]
Non-GAAP Results

[0000926326-22-000025:8k_2_02:16]
Total non-GAAP revenues for the second quarter of 2022 were $332 million, up $59 million, or 22%, from the second quarter of 2021. The increase in non-GAAP revenues reflects strong demand for Omnicell’s mission critical medication management solutions, as well as the contribution of revenues from recent acquisitions.

[0000926326-22-000025:8k_2_02:17]
Non-GAAP net income for the second quarter of 2022 was $38 million, or $0.84 per diluted share. This compares to non-GAAP net income of $44 million, or $0.97 per diluted share, for the second quarter of 2021.

[0000926326-22-000025:8k_2_02:18]
Non-GAAP EBITDA for the second quarter of 2022 was $56 million. This compares to non-GAAP EBITDA of $61 million for the second quarter of 2021.

[0000926326-22-000025:8k_2_02:19]
Balance Sheet

[0000926326-22-000025:8k_2_02:20]
As of June 30, 2022, Omnicell’s balance sheet reflected cash and cash equivalents of $245 million, total debt (net of unamortized debt issuance costs) of $565 million, and total assets of $2.13 billion. Cash flows used in operating activities in the second quarter of 2022 totaled $10 million. This compares to cash flows provided by operating activities totaling $72 million in the second quarter of 2021.

[0000926326-22-000025:8k_2_02:21]
As of June 30, 2022, the Company had $500 million of availability under its revolving credit facility.

[0000926326-22-000025:8k_2_02:22]
Business Highlights

[0000926326-22-000025:8k_2_02:23]
•Robust Demand for IV Sterile Compounding Service (including IV Robotics): Omnicell recently launched the IVX Station and is seeing strong customer demand. This innovative solution is designed to scale the benefits of IV robotic technology and make it accessible to the mainstream market. The new solutions and capabilities are intended to automate workflows, optimize operations and help improve patient care in a complex regulatory environment, that should provide additional value for our customers.

[0000926326-22-000025:8k_2_02:24]
•2022 Investor Day: Omnicell expects to host an Investor Day on Tuesday, September 20, 2022. The event will feature presentations from members of Omnicell’s executive leadership team who will discuss the Company’s strategy, ongoing execution of its initiatives and an in-depth review of the broader market opportunities and outlook. Additional details regarding this event will be provided at a later date.

[0000926326-22-000025:8k_2_02:25]
Ransomware Update

[0000926326-22-000025:8k_2_02:26]
As Omnicell previously disclosed, certain of its information technology systems were affected by ransomware during the second quarter of 2022. Total GAAP and non-GAAP revenues in the second quarter of 2022 were slightly below the Company’s previously communicated guidance range primarily due to a delay in expected customer implementations as a result of the ransomware incident, although these implementations are expected to occur in the second half of 2022. In addition, as a result of the ransomware incident, invoicing was delayed, which impacted the timing of cash collections and free cash flow in the second quarter of 2022. Additional information can be found in the Company’s Current Report on Form 8-K filed with the SEC on August 4, 2022.

[0000926326-22-000025:8k_2_02:27]
2022 Guidance

[0000926326-22-000025:8k_2_02:28]
Consistent with the Company’s previously issued guidance, for the full year 2022, the Company expects product bookings to be between $1.370 billion and $1.430 billion. The Company expects full year 2022 total GAAP and non-GAAP revenues to be between $1.385 billion and $1.410 billion. Omnicell now expects full year 2022 GAAP and non-GAAP product revenues to be between $980 million and $995 million, and full year 2022 GAAP and non-GAAP service revenues to be between $405 million and $415 million. The Company continues to expect full year 2022 non-GAAP EBITDA to be between $243 million and $255 million. The Company expects full year 2022 non-GAAP earnings to be between $3.85 and $4.05 per share.

[0000926326-22-000025:8k_2_02:29]
For the third quarter of 2022, the Company expects total GAAP and non-GAAP revenues to be between $360 million and $366 million. The Company expects third quarter 2022 GAAP and non-GAAP product revenues to be between $261 million and $264 million, and third quarter 2022 GAAP and non-GAAP service revenues to be between $99 million and $102 million. The Company expects third quarter 2022 non-GAAP EBITDA to be between $60 million and $64 million. The Company expects third quarter 2022 non-GAAP earnings to be between $0.93 and $1.00 per share.

[0000926326-22-000025:8k_2_02:30]
The Company’s third quarter and full year 2022 guidance includes the anticipated contributions and integration costs of recent acquisitions, as well as the anticipated effects of the current inflationary environment.

[0000926326-22-000025:8k_2_02:31]
The table below summarizes Omnicell’s 2022 guidance outlined above.

[0000926326-22-000025:8k_2_02:32]
|  | Q3 2022 | FY 2022 |
| Product Bookings | Not provided | $1.370 billion - $1.430 billion |
| Total GAAP and Non-GAAP Revenues | $360 million - $366 million | $1.385 billion - $1.410 billion |
| GAAP and Non-GAAP Product Revenues | $261 million - $264 million | $980 million - $995 million |
| GAAP and Non-GAAP Service Revenues | $99 million - $102 million | $405 million - $415 million |
| Non-GAAP EBITDA | $60 million - $64 million | $243 million - $255 million |
| Non-GAAP Earnings Per Share | $0.93 - $1.00 | $3.85 - $4.05 |

[0000926326-22-000025:8k_2_02:33]
The Company does not provide guidance for GAAP net income or GAAP earnings per share, nor a reconciliation of these forward-looking non-GAAP financial measures to the most directly comparable GAAP financial measures on a forward-looking basis because it is unable to predict certain items contained in the GAAP measures without unreasonable efforts. These forward-looking non-GAAP financial measures do not include certain items, which may be significant, including, but not limited to, unusual gains and losses, costs associated with future restructurings, acquisition-related expenses, and certain tax and litigation outcomes.

[0000926326-22-000025:8k_2_02:34]
Omnicell Conference Call Information

[0000926326-22-000025:8k_2_02:35]
Omnicell will hold a conference call today, Thursday, August 4, 2022 at 1:30 p.m. PT to discuss its second quarter 2022 financial results. The conference call can be accessed by dialing 1-888-550-5424 within the U.S. or 1-646-960-0819 for all other locations. The Conference ID # is 5370673. A link to the live and archived webcast will also be available on the Investor Relations section of Omnicell’s website at http://ir.omnicell.com/events-and-presentations/.

[0000926326-22-000025:8k_2_02:36]
About Omnicell

[0000926326-22-000025:8k_2_02:37]
Since 1992, Omnicell has been committed to transforming the pharmacy care delivery model to dramatically improve outcomes and lower costs. Through the industry vision of the Autonomous Pharmacy, a combination of automation, intelligence, and technology-enabled services, powered by a cloud data platform, Omnicell supports more efficient ways to manage medications across all care settings.

[0000926326-22-000025:8k_2_02:38]
Facilities worldwide use our automation and analytics solutions to increase operational efficiency, reduce medication errors, deliver actionable intelligence, and improve patient safety. Institutional and retail pharmacies across North America, the United Kingdom, Germany, and Australia leverage our innovative medication adherence and population health solutions to improve patient engagement and adherence to prescriptions, helping to reduce costly hospital readmissions.

[0000926326-22-000025:8k_2_02:39]
To learn more, visit www.omnicell.com. From time to time, Omnicell may use the Company’s investor relations website and other online social media channels, including its Twitter handle www.twitter.com/omnicell, LinkedIn page www.linkedin.com/company/omnicell, and Facebook page www.facebook.com/omnicellinc, to disclose material non-public information and comply with its disclosure obligations under Regulation Fair Disclosure (“Reg FD”).

[0000926326-22-000025:8k_2_02:40]
OMNICELL and the Omnicell logo are registered trademarks of Omnicell, Inc. or one of its subsidiaries.

[0000926326-22-000025:8k_2_02:41]
Forward-Looking Statements

[0000926326-22-000025:8k_2_02:42]
Use of Non-GAAP Financial Information

[0000926326-22-000025:8k_2_02:43]
This press release contains financial measures that are not calculated in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”). Management evaluates and makes operating decisions using various performance measures. In addition to Omnicell’s GAAP results, we also consider non-GAAP revenues, non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP operating margin, non-GAAP net income, non-GAAP net income per diluted share, non-GAAP diluted shares, non-GAAP EBITDA, non-GAAP EBITDA margin, and non-GAAP free cash flow. These non-GAAP results and metrics should not be considered as an alternative to revenues, gross profit, operating expenses, income from operations, net income, net income per diluted share, diluted shares, net cash provided by operating activities, or any other performance measure derived in accordance with GAAP. We present these non-GAAP results and metrics because management considers them to be important supplemental measures of Omnicell’s performance and refers to such measures when analyzing Omnicell’s strategy and operations.

[0000926326-22-000025:8k_2_02:44]
Our non-GAAP revenues, non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP operating margin, non-GAAP net income, non-GAAP net income per diluted share, non-GAAP EBITDA, and non-GAAP EBITDA margin are exclusive of certain items to facilitate management’s review of the comparability of Omnicell’s core operating results on a period-to-period basis because such items are not related to Omnicell’s ongoing core operating results as viewed by management. We define our “core operating results” as those revenues recorded in a particular period and the expenses incurred within such period that directly drive operating income in such period. Management uses these non-GAAP financial measures in making operating decisions because, in addition to meaningful supplemental information regarding operating performance, the measures give us a better understanding of how we believe we should invest in research and development, fund infrastructure growth, and evaluate the effectiveness of marketing strategies. In calculating the above non-GAAP results: non-GAAP revenues excludes from its GAAP equivalent item a) below; non-GAAP gross profit and non-GAAP gross margin exclude from their GAAP equivalents items a), b), c), f), and g) below; non-GAAP operating expenses excludes from its GAAP equivalents items b), c), d), e), f), g), and j) below; non-GAAP income from operations and non-GAAP operating margin exclude from their GAAP equivalents items a), b), c), d), e), f), g), and j) below; and non-GAAP net income and non-GAAP net income per diluted share exclude from their GAAP equivalents items a) through j) below. Non-GAAP EBITDA is defined as earnings before interest income and expense, taxes, depreciation, amortization, and share-based compensation, as well as excluding certain other non-GAAP adjustments. Non-GAAP EBITDA and non-GAAP EBITDA margin exclude from their GAAP equivalents items a), b), d), e), f), g), h), i), and j) below:

[0000926326-22-000025:8k_2_02:45]
a)Acquisition accounting impact related to deferred revenues. In connection with the recent acquisition of FDS Amplicare, we recorded a fair value adjustment to acquired deferred revenues as part of the purchase accounting in accordance with GAAP. The adjustment represents revenues that would have been recognized in the normal course of business by FDS Amplicare if the acquisition had not occurred, but was not recognized due to GAAP purchase accounting requirements. The non-GAAP adjustment to our revenues is intended to include the full amounts of such revenues. We believe the adjustment to these revenues is useful as a measure of the ongoing performance of our business.

[0000926326-22-000025:8k_2_02:46]
b)Share-based compensation expense. We excluded from our non-GAAP results the expense related to equity-based compensation plans as it represents expenses that do not require cash settlement from Omnicell.

[0000926326-22-000025:8k_2_02:47]
c)Amortization of acquired intangible assets. We excluded from our non-GAAP results the intangible assets amortization expense resulting from our past acquisitions. These non-cash charges are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results.

[0000926326-22-000025:8k_2_02:48]
d)Acquisition-related expenses. We excluded from our non-GAAP results the expenses related to recent acquisitions, including amortization of representations and warranties insurance. These expenses are unrelated to our ongoing operations, vary in size and frequency, and are subject to significant fluctuations from period to period due to varying levels of acquisition activity. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of less acquisitive peer companies.

[0000926326-22-000025:8k_2_02:49]
e)Impairment and abandonment of operating lease right-of-use assets related to facilities. We excluded from our non-GAAP results the impairment and abandonment of operating lease right-of-use assets incurred in connection with restructuring activities for optimization of certain leased facilities. These non-cash charges are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results.

[0000926326-22-000025:8k_2_02:50]
f)Ransomware-related expenses, net of insurance recoveries. We excluded from our non-GAAP results the net expenses related to the previously disclosed ransomware incident identified by the Company on May 4, 2022. Expenses include costs to investigate and remediate the ransomware incident, as well as legal and other professional services, and are presented net of expected insurance recoveries. These expenses are unrelated to our ongoing operations and would not have otherwise been incurred by us in the normal course of business. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of peer companies.

[0000926326-22-000025:8k_2_02:51]
g)Severance-related expenses. We excluded from our non-GAAP results the expenses related to restructuring events. These expenses are unrelated to our ongoing operations, vary in size and frequency, and are subject to significant fluctuations from period to period due to varying levels of restructuring activity. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of peer companies.

[0000926326-22-000025:8k_2_02:52]
h)Amortization of debt issuance costs. Debt issuance costs represent costs associated with the issuance of term loan and revolving credit facilities, as well as the issuance of convertible senior notes. The costs include underwriting fees, original issue discount, ticking fees, and legal fees. These non-cash expenses are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results.

[0000926326-22-000025:8k_2_02:53]
i)Amortization of discount on convertible senior notes. We excluded from our non-GAAP results the amortization of the imputed discount on our convertible senior notes. Under GAAP (prior to the adoption of Accounting Standards Update 2020-06, effective January 1, 2022), certain convertible debt instruments that may be settled in cash upon conversion were required to be bifurcated into separate liability and equity components in a manner that reflects the issuer’s assumed non-convertible debt borrowing rate. For GAAP purposes, we were required to recognize the imputed interest expense on the difference between our assumed non-convertible debt borrowing rate and the coupon rate on our convertible senior notes. This non-cash expense is not considered by management to reflect the core cash-generating performance of the business and therefore is excluded from our non-GAAP results.

[0000926326-22-000025:8k_2_02:54]
j)Certain litigation costs. We excluded non-recurring charges and benefits, including litigation expenses and settlements, related to litigation matters that are outside of the ordinary course of our business or that are not representative of those that we historically have incurred. These expenses are unrelated to our ongoing operations and we do not expect them to occur in the ordinary course of business. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of peer companies.

[0000926326-22-000025:8k_2_02:55]
Management adjusts for the above items because management believes that, in general, these items possess one or more of the following characteristics: their magnitude and timing is largely outside of Omnicell’s control; they are unrelated to the ongoing operation of the business in the ordinary course; they are unusual and we do not expect them to occur in the ordinary course of business; or they are non-operational or non-cash expenses involving stock compensation plans or other items.

[0000926326-22-000025:8k_2_02:56]
We believe that the presentation of non-GAAP revenues, non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP operating margin, non-GAAP net income, non-GAAP net income per diluted share, non-GAAP EBITDA, and non-GAAP EBITDA margin is warranted for several reasons:

[0000926326-22-000025:8k_2_02:57]
a)Such non-GAAP financial measures provide an additional analytical tool for understanding Omnicell’s financial performance by excluding the impact of items which may obscure trends in the core operating results of the business.

[0000926326-22-000025:8k_2_02:58]
b)Since we have historically reported non-GAAP results to the investment community, we believe the inclusion of non-GAAP numbers provides consistency and enhances investors’ ability to compare our performance across financial reporting periods.

[0000926326-22-000025:8k_2_02:59]
c)These non-GAAP financial measures are employed by management in its own evaluation of performance and are utilized in financial and operational decision-making processes, such as budget planning and forecasting.

[0000926326-22-000025:8k_2_02:60]
d)These non-GAAP financial measures facilitate comparisons to the operating results of other companies in our industry, which also use non-GAAP financial measures to supplement their GAAP results (although these companies may calculate non-GAAP financial measures differently than Omnicell does), thus enhancing the perspective of investors who wish to utilize such comparisons in their analysis of our performance.

[0000926326-22-000025:8k_2_02:61]
Set forth below are additional reasons why share-based compensation expense is excluded from our non-GAAP financial measures:

[0000926326-22-000025:8k_2_02:62]
i)While share-based compensation calculated in accordance with Accounting Standards Codification (“ASC”) 718 constitutes an ongoing and recurring expense of Omnicell, it is not an expense that requires cash settlement by Omnicell. We therefore exclude these charges for purposes of evaluating core operating results. Thus, our non-GAAP measurements are presented exclusive of share-based compensation expense to assist management and investors in evaluating our core operating results.

[0000926326-22-000025:8k_2_02:63]
ii)We present ASC 718 share-based payment compensation expense in our reconciliation of non-GAAP financial measures on a pre-tax basis because the exact tax differences related to the timing and deductibility of share-based compensation under ASC 718 are dependent upon the trading price of Omnicell’s common stock and the timing and exercise by employees of their stock options. As a result of these timing and market uncertainties, the tax effect related to share-based compensation expense would be inconsistent in amount and frequency and is therefore excluded from our non-GAAP results.

[0000926326-22-000025:8k_2_02:64]
Non-GAAP diluted shares is defined as our GAAP diluted shares, excluding the impact of dilutive convertible senior notes for which the Company is economically hedged through its anti-dilutive convertible note hedge transaction. We believe non-GAAP diluted shares is a useful non-GAAP metric because it provides insight into the offsetting economic effect of the hedge transaction against potential conversion of the convertible senior notes.

[0000926326-22-000025:8k_2_02:65]
Non-GAAP free cash flow is defined as net cash provided by operating activities less cash used for software development for external use and purchases of property and equipment. We believe free cash flow is important to enable investors to better understand and evaluate our ongoing operating results and allows for greater transparency in the review and understanding of our overall financial, operational, and economic performance, because free cash flow takes into account certain capital expenditures and cash used for software development necessary to operate our business.

[0000926326-22-000025:8k_2_02:66]
As stated above, we present non-GAAP financial measures because we consider them to be important supplemental measures of performance. However, non-GAAP financial measures have limitations as an analytical tool and should not be considered in isolation or as a substitute for Omnicell’s GAAP results. In the future, we expect to incur expenses similar to certain of the non-GAAP adjustments described above and expect to continue reporting non-GAAP financial measures excluding such items. Some of the limitations in relying on non-GAAP financial measures are:

[0000926326-22-000025:8k_2_02:67]
a)Omnicell’s stock option and stock purchase plans are important components of incentive compensation arrangements and will be reflected as expenses in Omnicell’s GAAP results for the foreseeable future under ASC 718.

[0000926326-22-000025:8k_2_02:68]
b)Other companies, including companies in Omnicell’s industry, may calculate non-GAAP financial measures differently than Omnicell, limiting their usefulness as a comparative measure.

[0000926326-22-000025:8k_2_02:69]
c)A limitation of the utility of free cash flow as a measure of financial performance is that it does not represent the total increase or decrease in Omnicell’s cash balance for the period.

[0000926326-22-000025:8k_2_02:70]
A detailed reconciliation between Omnicell’s non-GAAP and GAAP financial results is set forth in the financial tables at the end of this press release. Investors are advised to carefully review and consider this information strictly as a supplement to the GAAP results that are contained in this press release as well as in Omnicell’s other reports filed with or furnished to the SEC.

[0000926326-22-000025:8k_2_02:71]
Omnicell, Inc.

[0000926326-22-000025:8k_2_02:72]
Condensed Consolidated Statements of Operations

[0000926326-22-000025:8k_2_02:73]
(Unaudited, in thousands, except per share data)

[0000926326-22-000025:8k_2_02:74]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Revenues: |  |  |  |  |  |  |  |
| Product revenues | $ | 233,806 |  |  | $ | 196,911 |  |  | $ | 459,681 |  |  | $ | 375,036 |  |
| Services and other revenues | 97,580 |  |  | 75,828 |  |  | 190,533 |  |  | 149,546 |  |
| Total revenues | 331,386 |  |  | 272,739 |  |  | 650,214 |  |  | 524,582 |  |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | 121,814 |  |  | 100,227 |  |  | 240,152 |  |  | 192,854 |  |
| Cost of services and other revenues | 51,480 |  |  | 36,214 |  |  | 101,923 |  |  | 73,147 |  |
| Total cost of revenues | 173,294 |  |  | 136,441 |  |  | 342,075 |  |  | 266,001 |  |
| Gross profit | 158,092 |  |  | 136,298 |  |  | 308,139 |  |  | 258,581 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 26,355 |  |  | 18,213 |  |  | 51,385 |  |  | 34,293 |  |
| Selling, general, and administrative | 119,252 |  |  | 89,169 |  |  | 239,185 |  |  | 175,762 |  |
| Total operating expenses | 145,607 |  |  | 107,382 |  |  | 290,570 |  |  | 210,055 |  |
| Income from operations | 12,485 |  |  | 28,916 |  |  | 17,569 |  |  | 48,526 |  |
| Interest and other income (expense), net | (1,711) |  |  | (5,959) |  |  | (1,825) |  |  | (12,650) |  |
| Income before provision for income taxes | 10,774 |  |  | 22,957 |  |  | 15,744 |  |  | 35,876 |  |
| Provision for (benefit from) income taxes | 1,705 |  |  | 2,533 |  |  | (1,538) |  |  | 1,325 |  |
| Net income | $ | 9,069 |  |  | $ | 20,424 |  |  | $ | 17,282 |  |  | $ | 34,551 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.21 |  |  | $ | 0.47 |  |  | $ | 0.39 |  |  | $ | 0.80 |  |
| Diluted | $ | 0.20 |  |  | $ | 0.43 |  |  | $ | 0.37 |  |  | $ | 0.74 |  |
| Weighted-average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 44,219 |  |  | 43,262 |  |  | 44,234 |  |  | 43,113 |  |
| Diluted | 46,260 |  |  | 47,106 |  |  | 47,121 |  |  | 46,765 |  |

[0000926326-22-000025:8k_2_02:75]
7

[0000926326-22-000025:8k_2_02:76]
Omnicell, Inc.

[0000926326-22-000025:8k_2_02:77]
Condensed Consolidated Balance Sheets

[0000926326-22-000025:8k_2_02:78]
(Unaudited, in thousands)

[0000926326-22-000025:8k_2_02:79]
|  | June 30,2022 |  | December 31,2021 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 244,953 |  |  | $ | 349,051 |  |
| Accounts receivable and unbilled receivables, net | 310,520 |  |  | 240,894 |  |
| Inventories | 150,461 |  |  | 119,924 |  |
| Prepaid expenses | 20,856 |  |  | 22,499 |  |
| Other current assets | 60,980 |  |  | 48,334 |  |
| Total current assets | 787,770 |  |  | 780,702 |  |
| Property and equipment, net | 81,834 |  |  | 71,141 |  |
| Long-term investment in sales-type leases, net | 29,209 |  |  | 18,391 |  |
| Operating lease right-of-use assets | 46,240 |  |  | 48,549 |  |
| Goodwill | 734,487 |  |  | 738,900 |  |
| Intangible assets, net | 260,159 |  |  | 277,616 |  |
| Long-term deferred tax assets | 16,134 |  |  | 15,883 |  |
| Prepaid commissions | 57,762 |  |  | 63,795 |  |
| Other long-term assets | 117,863 |  |  | 127,519 |  |
| Total assets | $ | 2,131,458 |  |  | $ | 2,142,496 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 68,400 |  |  | $ | 71,513 |  |
| Accrued compensation | 60,012 |  |  | 71,130 |  |
| Accrued liabilities | 136,523 |  |  | 133,167 |  |
| Deferred revenues, net | 108,579 |  |  | 112,196 |  |
| Convertible senior notes, net | — |  |  | 488,152 |  |
| Total current liabilities | 373,514 |  |  | 876,158 |  |
| Long-term deferred revenues | 24,187 |  |  | 20,194 |  |
| Long-term deferred tax liabilities | 23,906 |  |  | 51,705 |  |
| Long-term operating lease liabilities | 43,371 |  |  | 39,911 |  |
| Other long-term liabilities | 8,808 |  |  | 7,839 |  |
| Convertible senior notes, net | 565,035 |  |  | — |  |
| Total liabilities | 1,038,821 |  |  | 995,807 |  |
| Total stockholders’ equity | 1,092,637 |  |  | 1,146,689 |  |
| Total liabilities and stockholders’ equity | $ | 2,131,458 |  |  | $ | 2,142,496 |  |

[0000926326-22-000025:8k_2_02:80]
Omnicell, Inc.

[0000926326-22-000025:8k_2_02:81]
Condensed Consolidated Statements of Cash Flows

[0000926326-22-000025:8k_2_02:82]
(Unaudited, in thousands)

[0000926326-22-000025:8k_2_02:83]
|  | Six Months Ended June 30, |
|  | 2022 |  | 2021 |
| Operating Activities |  |  |  |
| Net income | $ | 17,282 |  |  | $ | 34,551 |  |
| Adjustments to reconcile net income to net cash provided by (used in) operating activities: |  |  |  |
| Depreciation and amortization | 43,017 |  |  | 34,965 |  |
| Share-based compensation expense | 33,421 |  |  | 24,811 |  |
| Deferred income taxes | (9,506) |  |  | 453 |  |
| Amortization of operating lease right-of-use assets | 6,801 |  |  | 5,791 |  |
| Impairment and abandonment of operating lease right-of-use assets related to facilities | 5,093 |  |  | — |  |
| Amortization of debt issuance costs | 2,079 |  |  | 1,707 |  |
| Amortization of discount on convertible senior notes | — |  |  | 9,195 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable and unbilled receivables | (71,418) |  |  | (19,662) |  |
| Inventories | (32,625) |  |  | (6,569) |  |
| Prepaid expenses | 1,660 |  |  | (1,415) |  |
| Other current assets | (1,996) |  |  | 188 |  |
| Investment in sales-type leases | (12,465) |  |  | 2,423 |  |
| Prepaid commissions | 6,033 |  |  | 1,852 |  |
| Other long-term assets | 1,455 |  |  | 1,559 |  |
| Accounts payable | (3,130) |  |  | 15,684 |  |
| Accrued compensation | (11,118) |  |  | (7,263) |  |
| Accrued liabilities | 4,682 |  |  | 10,142 |  |
| Deferred revenues | 1,395 |  |  | 27,454 |  |
| Operating lease liabilities | (7,176) |  |  | (6,247) |  |
| Other long-term liabilities | 969 |  |  | (431) |  |
| Net cash provided by (used in) operating activities | (25,547) |  |  | 129,188 |  |
| Investing Activities |  |  |  |
| Software development for external use | (6,543) |  |  | (15,415) |  |
| Purchases of property and equipment | (21,099) |  |  | (11,067) |  |
| Business acquisition, net of cash acquired | (3,392) |  |  | — |  |
| Purchase price adjustments from business acquisitions | 5,484 |  |  | — |  |
| Net cash used in investing activities | (25,550) |  |  | (26,482) |  |
| Financing Activities |  |  |  |
| Proceeds from issuances under stock-based compensation plans | 21,123 |  |  | 32,343 |  |
| Employees’ taxes paid related to restricted stock units | (8,470) |  |  | (6,667) |  |
| Change in customer funds, net | 5,986 |  |  | (3,263) |  |
| Stock repurchases | (52,210) |  |  | — |  |
| Net cash provided by (used in) financing activities | (33,571) |  |  | 22,413 |  |
| Effect of exchange rate changes on cash and cash equivalents | (2,123) |  |  | (74) |  |
| Net increase (decrease) in cash, cash equivalents, and restricted cash | (86,791) |  |  | 125,045 |  |
| Cash, cash equivalents, and restricted cash at beginning of period | 355,620 |  |  | 489,920 |  |
| Cash, cash equivalents, and restricted cash at end of period | $ | 268,829 |  |  | $ | 614,965 |  |
| Reconciliation of cash, cash equivalents, and restricted cash to the Condensed Consolidated Balance Sheets: |
| Cash and cash equivalents | $ | 244,953 |  |  | $ | 614,236 |  |
| Restricted cash included in Other current assets | 23,876 |  |  | 729 |  |
| Cash, cash equivalents, and restricted cash at end of period | $ | 268,829 |  |  | $ | 614,965 |  |

[0000926326-22-000025:8k_2_02:84]
9

[0000926326-22-000025:8k_2_02:85]
Omnicell, Inc.

[0000926326-22-000025:8k_2_02:86]
Reconciliation of GAAP to Non-GAAP

[0000926326-22-000025:8k_2_02:87]
(Unaudited, in thousands, except per share data and percentage)

[0000926326-22-000025:8k_2_02:88]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Reconciliation of GAAP revenues to non-GAAP revenues: |
| GAAP revenues | $ | 331,386 |  |  | $ | 272,739 |  |  | $ | 650,214 |  |  | $ | 524,582 |  |
| Acquisition accounting impact related to deferred revenues | 302 |  |  | — |  |  | 680 |  |  | — |  |
| Non-GAAP revenues | $ | 331,688 |  |  | $ | 272,739 |  |  | $ | 650,894 |  |  | $ | 524,582 |  |
| Reconciliation of GAAP gross profit to non-GAAP gross profit: |  |  |  |  |  |
| GAAP gross profit | $ | 158,092 |  |  | $ | 136,298 |  |  | $ | 308,139 |  |  | $ | 258,581 |  |
| GAAP gross margin | 47.7% |  | 50.0% |  | 47.4% |  | 49.3% |
| Share-based compensation expense | 2,160 |  |  | 2,044 |  |  | 4,404 |  |  | 3,981 |  |
| Amortization of acquired intangibles | 3,537 |  |  | 2,667 |  |  | 6,851 |  |  | 5,483 |  |
| Acquisition accounting impact related to deferred revenues | 302 |  |  | — |  |  | 680 |  |  | — |  |
| Ransomware-related expenses, net of insurance recoveries | 222 |  |  | — |  |  | 222 |  |  | — |  |
| Severance-related expenses | — |  |  | — |  |  | 156 |  |  | 389 |  |
| Non-GAAP gross profit | $ | 164,313 |  |  | $ | 141,009 |  |  | $ | 320,452 |  |  | $ | 268,434 |  |
| Non-GAAP gross margin | 49.5% |  | 51.7% |  | 49.2% |  | 51.2% |
| Reconciliation of GAAP operating expenses to non-GAAP operating expenses: |  |  |  |  |
| GAAP operating expenses | $ | 145,607 |  |  | $ | 107,382 |  |  | $ | 290,570 |  |  | $ | 210,055 |  |
| GAAP operating expenses % to total revenues | 43.9% |  | 39.4% |  | 44.7% |  | 40.0% |
| Share-based compensation expense | (15,053) |  |  | (10,995) |  |  | (29,017) |  |  | (20,830) |  |
| Amortization of acquired intangibles | (5,308) |  |  | (3,366) |  |  | (11,047) |  |  | (6,822) |  |
| Acquisition-related expenses | (263) |  |  | (1,986) |  |  | (1,658) |  |  | (1,986) |  |
| Impairment and abandonment of operating lease right-of-use assets related to facilities | (3,340) |  |  | — |  |  | (5,093) |  |  | — |  |
| Ransomware-related expenses, net of insurance recoveries | (1,152) |  |  | — |  |  | (1,152) |  |  | — |  |
| Severance-related and other expenses (a) | — |  |  | — |  |  | (3,371) |  |  | (2,582) |  |
| Non-GAAP operating expenses | $ | 120,491 |  |  | $ | 91,035 |  |  | $ | 239,232 |  |  | $ | 177,835 |  |
| Non-GAAP operating expenses as a % of total non-GAAP revenues | 36.3% |  | 33.4% |  | 36.8% |  | 33.9% |
| Reconciliation of GAAP income from operations to non-GAAP income from operations: |
| GAAP income from operations | $ | 12,485 |  |  | $ | 28,916 |  |  | $ | 17,569 |  |  | $ | 48,526 |  |
| GAAP operating income % to total revenues | 3.8% |  | 10.6% |  | 2.7% |  | 9.3% |
| Share-based compensation expense | 17,213 |  |  | 13,039 |  |  | 33,421 |  |  | 24,811 |  |
| Amortization of acquired intangibles | 8,845 |  |  | 6,033 |  |  | 17,898 |  |  | 12,305 |  |
| Acquisition accounting impact related to deferred revenues | 302 |  |  | — |  |  | 680 |  |  | — |  |
| Acquisition-related expenses | 263 |  |  | 1,986 |  |  | 1,658 |  |  | 1,986 |  |
| Impairment and abandonment of operating lease right-of-use assets related to facilities | 3,340 |  |  | — |  |  | 5,093 |  |  | — |  |
| Ransomware-related expenses, net of insurance recoveries | 1,374 |  |  | — |  |  | 1,374 |  |  | — |  |
| Severance-related and other expenses (a) | — |  |  | — |  |  | 3,527 |  |  | 2,971 |  |
| Non-GAAP income from operations | $ | 43,822 |  |  | $ | 49,974 |  |  | $ | 81,220 |  |  | $ | 90,599 |  |
| Non-GAAP operating margin (non-GAAP operating income as a % of total non-GAAP revenues) | 13.2% |  | 18.3% |  | 12.5% |  | 17.3% |

[0000926326-22-000025:8k_2_02:89]
Omnicell, Inc.

[0000926326-22-000025:8k_2_02:90]
Reconciliation of GAAP to Non-GAAP

[0000926326-22-000025:8k_2_02:91]
(Unaudited, in thousands, except per share data and percentage)

[0000926326-22-000025:8k_2_02:92]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Reconciliation of GAAP net income to non-GAAP net income: |
| GAAP net income | $ | 9,069 |  |  | $ | 20,424 |  |  | $ | 17,282 |  |  | $ | 34,551 |  |
| Share-based compensation expense | 17,213 |  |  | 13,039 |  |  | 33,421 |  |  | 24,811 |  |
| Amortization of acquired intangibles | 8,845 |  |  | 6,033 |  |  | 17,898 |  |  | 12,305 |  |
| Acquisition accounting impact related to deferred revenues | 302 |  |  | — |  |  | 680 |  |  | — |  |
| Acquisition-related expenses | 263 |  |  | 1,986 |  |  | 1,658 |  |  | 1,986 |  |
| Impairment and abandonment of operating lease right-of-use assets related to facilities | 3,340 |  |  | — |  |  | 5,093 |  |  | — |  |
| Ransomware-related expenses, net of insurance recoveries | 1,374 |  |  | — |  |  | 1,374 |  |  | — |  |
| Severance-related and other expenses (a) | — |  |  | — |  |  | 3,527 |  |  | 2,971 |  |
| Amortization of debt issuance costs | 1,041 |  |  | 858 |  |  | 2,079 |  |  | 1,707 |  |
| Amortization of discount on convertible senior notes | — |  |  | 4,624 |  |  | — |  |  | 9,195 |  |
| Tax effect of the adjustments above (b) | (3,185) |  |  | (2,835) |  |  | (6,786) |  |  | (5,914) |  |
| Non-GAAP net income | $ | 38,262 |  |  | $ | 44,129 |  |  | $ | 76,226 |  |  | $ | 81,612 |  |
| Reconciliation of GAAP net income per share - diluted to non-GAAP net income per share - diluted: |
| Shares - diluted GAAP | 46,260 |  |  | 47,106 |  |  | 47,121 |  |  | 46,765 |  |
| Shares - diluted non-GAAP (c) | 45,361 |  |  | 45,328 |  |  | 45,655 |  |  | 45,153 |  |
| GAAP net income per share - diluted | $ | 0.20 |  |  | $ | 0.43 |  |  | $ | 0.37 |  |  | $ | 0.74 |  |
| Share-based compensation expense | 0.38 |  |  | 0.30 |  |  | 0.73 |  |  | 0.57 |  |
| Amortization of acquired intangibles | 0.19 |  |  | 0.14 |  |  | 0.39 |  |  | 0.28 |  |
| Acquisition accounting impact related to deferred revenues | 0.01 |  |  | — |  |  | 0.01 |  |  | — |  |
| Acquisition-related expenses | 0.01 |  |  | 0.04 |  |  | 0.04 |  |  | 0.04 |  |
| Impairment and abandonment of operating lease right-of-use assets related to facilities | 0.07 |  |  | — |  |  | 0.11 |  |  | — |  |
| Ransomware-related expenses, net of insurance recoveries | 0.03 |  |  | — |  |  | 0.03 |  |  | — |  |
| Severance-related and other expenses | — |  |  | — |  |  | 0.08 |  |  | 0.07 |  |
| Amortization of debt issuance costs | 0.02 |  |  | 0.02 |  |  | 0.05 |  |  | 0.04 |  |
| Amortization of discount on convertible senior notes | — |  |  | 0.10 |  |  | — |  |  | 0.20 |  |
| Non-GAAP dilutive shares impact from convertible note hedge transaction (c) | — |  |  | — |  |  | 0.01 |  |  | — |  |
| Tax effect of the adjustments above (b) | (0.07) |  |  | (0.06) |  |  | (0.15) |  |  | (0.13) |  |
| Non-GAAP net income per share - diluted | $ | 0.84 |  |  | $ | 0.97 |  |  | $ | 1.67 |  |  | $ | 1.81 |  |
| Reconciliation of GAAP net income to non-GAAP EBITDA(d): |
| GAAP net income | $ | 9,069 |  |  | $ | 20,424 |  |  | $ | 17,282 |  |  | $ | 34,551 |  |
| Share-based compensation expense | 17,213 |  |  | 13,039 |  |  | 33,421 |  |  | 24,811 |  |
| Interest (income) and expense, net | (142) |  |  | 190 |  |  | (175) |  |  | 160 |  |
| Depreciation and amortization expense | 21,893 |  |  | 17,390 |  |  | 43,017 |  |  | 34,965 |  |
| Acquisition accounting impact related to deferred revenues | 302 |  |  | — |  |  | 680 |  |  | — |  |
| Acquisition-related expenses | 263 |  |  | 1,986 |  |  | 1,658 |  |  | 1,986 |  |
| Impairment and abandonment of operating lease right-of-use assets related to facilities | 3,340 |  |  | — |  |  | 5,093 |  |  | — |  |
| Ransomware-related expenses, net of insurance recoveries | 1,374 |  |  | — |  |  | 1,374 |  |  | — |  |
| Severance-related and other expenses (a) | — |  |  | — |  |  | 3,527 |  |  | 2,971 |  |
| Amortization of debt issuance costs | 1,041 |  |  | 858 |  |  | 2,079 |  |  | 1,707 |  |
| Amortization of discount on convertible senior notes | — |  |  | 4,624 |  |  | — |  |  | 9,195 |  |
| Income tax expense (benefit) | 1,705 |  |  | 2,533 |  |  | (1,538) |  |  | 1,325 |  |
| Non-GAAP EBITDA | $ | 56,058 |  |  | $ | 61,044 |  |  | $ | 106,418 |  |  | $ | 111,671 |  |
| Non-GAAP EBITDA margin (non-GAAP EBITDA as a % of total non-GAAP revenues) | 16.9% |  | 22.4% |  | 16.3% |  | 21.3% |

[0000926326-22-000025:8k_2_02:93]
11

[0000926326-22-000025:8k_2_02:94]
_________________________________________________

[0000926326-22-000025:8k_2_02:95]
(a)For the six months ended June 30, 2021, other expenses included approximately $1.0 million of certain litigation costs.

[0000926326-22-000025:8k_2_02:96]
(b)Tax effects calculated for all adjustments except share-based compensation expense, using an estimated annual effective tax rate of 21% for both fiscal years 2022 and 2021.

[0000926326-22-000025:8k_2_02:97]
(c)For the three months ended June 30, 2022 and 2021, non-GAAP diluted shares exclude approximately 0.9 million and 1.8 million shares, respectively, related to the impact of dilutive convertible senior notes for which the Company is economically hedged through its anti-dilutive convertible note hedge transaction. For the six months ended June 30, 2022 and 2021, non-GAAP diluted shares exclude approximately 1.5 million and 1.6 million shares, respectively.

[0000926326-22-000025:8k_2_02:98]
(d)Defined as earnings before interest income and expense, taxes, depreciation, amortization, and share-based compensation, as well as excluding certain other non-GAAP adjustments.

[0000926326-22-000025:8k_2_02:99]
Omnicell, Inc.

[0000926326-22-000025:8k_2_02:100]
Reconciliation of GAAP to Non-GAAP

[0000926326-22-000025:8k_2_02:101]
(Unaudited, in thousands)

[0000926326-22-000025:8k_2_02:102]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Reconciliation of GAAP net cash provided by (used in) operating activities to non-GAAP free cash flow: |
| GAAP net cash provided by (used in) operating activities | $ | (9,551) |  |  | $ | 71,773 |  |  | $ | (25,547) |  |  | $ | 129,188 |  |
| Software development for external use | (2,691) |  |  | (7,372) |  |  | (6,543) |  |  | (15,415) |  |
| Purchases of property and equipment | (9,610) |  |  | (5,978) |  |  | (21,099) |  |  | (11,067) |  |
| Non-GAAP free cash flow | $ | (21,852) |  |  | $ | 58,423 |  |  | $ | (53,189) |  |  | $ | 102,706 |  |

[0000926326-22-000025:8k_2_02:103]
13
