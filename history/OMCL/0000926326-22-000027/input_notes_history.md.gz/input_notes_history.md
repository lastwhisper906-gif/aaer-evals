# OMCL note change history — 0000926326-22-000014 → 0000926326-22-000027


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-08-09):
[0000926326-22-000027:note_history:1]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of June 30, 2022, the Company had non-cancelable purchase commitments of $226.5 million, of which $175.8 million are expected to be paid within the year ending December 31, 2022.
  (was, 2022-05-09, similarity 0.9836):
[0000926326-22-000014:note_history:1]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of March 31, 2022, the Company had non-cancelable purchase commitments of $227.1 million, of which $194.5 million are expected to be paid within the year ending December 31, 2022.

- added (2022-08-09):
[0000926326-22-000027:note_history:2]
Ransomware Incident

- added (2022-08-09):
[0000926326-22-000027:note_history:3]
On May 4, 2022, the Company determined that certain of its information technology systems were affected by ransomware impacting certain internal systems. Upon detecting the security event, the Company took immediate steps designed to contain the incident and implement its business continuity plans to restore and support continued operations. The Company has contained the incident and restored substantially all of its critical information technology systems.

- added (2022-08-09):
[0000926326-22-000027:note_history:4]
During the three months ended June 30, 2022, the Company incurred $12.5 million of expenses related to the ransomware incident, partially offset by $11.1 million of expected insurance recoveries. Expenses include costs to investigate and remediate the ransomware incident, as well as legal and other professional services, all of which were expensed as incurred. For the three months ended June 30, 2022, the Company included net expenses of $0.2 million in cost of revenues and $1.2 million in selling, general, and administrative expenses in the Company’s Condensed Consolidated Statements of Operations.

- changed (2022-08-09):
[0000926326-22-000027:note_history:5]
A class action lawsuit was filed against the Company, on June 5, 2019, in the Circuit Court of Cook County, Illinois, Chancery Division, captioned Corey Heard, individually and on behalf of all others similarly situated v. Omnicell, Inc., Case No. 2019-CH-06817 (the “Heard Action”). The complaint seeks class certification, monetary damages in the form of statutory damages for willful and/or reckless or, in the alternative, negligent violation of the Illinois Biometric Information Privacy Act (“BIPA”), and certain declaratory, injunctive, and other relief based on causes of action directed to allegations of violation of BIPA by the Company. The complaint was served on the Company on June 13, 2019. On July 31, 2019, the Company filed a motion to stay or consolidate the case with the action Yana Mazya, et al. v. Northwestern Lake Forest Hospital, et al., Case No. 2018-CH-07161, pending in the Circuit Court of Cook County, Illinois, Chancery Division (the “Mazya Action”). The Court subsequently, on October 10, 2019, denied the motion, without prejudice, as being moot in view of the dismissal of the claims against the Company in the Mazya Action. The Company filed a motion to dismiss the complaint in the Heard Action on
  (was, 2022-05-09, similarity 0.7608):
[0000926326-22-000014:note_history:5]
A class action lawsuit was filed against the Company, on June 5, 2019, in the Circuit Court of Cook County, Illinois, Chancery Division, captioned Corey Heard, individually and on behalf of all others similarly situated v. Omnicell, Inc., Case No. 2019-CH-06817 (the “Heard Action”). The complaint seeks class certification, monetary damages in the form of statutory damages for willful and/or reckless or, in the alternative, negligent violation of the Illinois Biometric Information Privacy Act (“BIPA”), and certain declaratory, injunctive, and other relief based on causes of action directed to allegations of violation of BIPA by the Company. The complaint was served on the Company on June 13, 2019. On July 31, 2019, the Company filed a motion to stay or consolidate the case with the action Yana Mazya, et al. v. Northwestern Lake Forest Hospital, et al., Case No. 2018-CH-07161, pending in the Circuit Court of Cook County, Illinois, Chancery Division (the “Mazya Action”). The Court subsequently, on October 10, 2019, denied the motion, without prejudice, as being moot in view of the dismissal of the claims against the Company in the Mazya Action. The Company filed a motion to dismiss the complaint in the Heard Action on October 31, 2019. The hearing on the Company’s motion to dismiss was held on September 2, 2020. The Court ruled from the bench and dismissed the complaint without prejudice giving plaintiff leave to file an amended complaint by September 30, 2020. Plaintiff filed an amended complaint on September 30, 2020 and the Company subsequently filed a motion to dismiss the amended complaint on October 28, 2020, which was fully briefed, but the Court had not heard oral argument on the motion. The parties entered into a settlement agreement on January 25, 2022. On February 1, 2022, the Court granted preliminary approval of the settlement. The Court has scheduled a status conference for June 1, 2022. Subject to final approval of the settlement, the Company intends to defend the lawsuit vigorously.

- added (2022-08-09):
[0000926326-22-000027:note_history:6]
October 31, 2019. The hearing on the Company’s motion to dismiss was held on September 2, 2020. The Court ruled from the bench and dismissed the complaint without prejudice giving plaintiff leave to file an amended complaint by September 30, 2020. Plaintiff filed an amended complaint on September 30, 2020 and the Company subsequently filed a motion to dismiss the amended complaint on October 28, 2020, which was fully briefed, but the Court had not heard oral argument on the motion. The parties entered into a settlement agreement on January 25, 2022. On February 1, 2022, the Court granted preliminary approval of the settlement. The Court has scheduled an interim status conference for September 2, 2022. Subject to final approval of the settlement, the Company intends to defend the lawsuit vigorously.

- changed (2022-08-09):
[0000926326-22-000027:note_history:7]
On December 21, 2020, Becton, Dickinson and Company (“BD”) filed a complaint against the Company in the United States District Court for the Middle District of North Carolina, asserting claims of misappropriation under the Defend Trade Secrets Act, misappropriation under the North Carolina Trade Secrets Protection Act, unfair competition, and unfair/deceptive trade practices in violation of North Carolina law (the “BD Complaint”). This action (the “BD Action”) was commenced in relation to another action brought by BD, in the same Court (the “Related Matter”) against a former BD employee who is also a former Company employee (the “Former Employee”) alleging that the Former Employee had violated the Former Employee’s legal obligations to BD regarding BD’s confidential and trade secret information when the Former Employee allegedly downloaded certain documents from BD’s information technology system following the end of the Former Employee’s employment with BD. In connection with the Related Matter, BD, the Former Employee, and the Company entered into a protocol with the purpose of facilitating the return to BD of any BD documents that may have been resident, as a result of the Former Employee’s actions, on any devices belonging to the Former Employee or the Company. The BD Complaint seeks injunctive relief and monetary damages in the form of compensatory, punitive, and exemplary damages, attorneys’ fees and costs, and pre-judgment and post-judgment interest. On March 8, 2022, the parties entered into a confidential settlement agreement. On May 23, 2022, the parties filed a stipulation to dismiss the case with prejudice. On May 24, 2022, the case was dismissed with prejudice.
  (was, 2022-05-09, similarity 0.6637):
[0000926326-22-000014:note_history:7]
On December 21, 2020, Becton, Dickinson and Company (“BD”) filed a complaint against the Company in the United States District Court for the Middle District of North Carolina, asserting claims of misappropriation under the Defend Trade Secrets Act, misappropriation under the North Carolina Trade Secrets Protection Act, unfair competition, and unfair/deceptive trade practices in violation of North Carolina law (the “BD Complaint”). This action (the “BD Action”) was commenced in relation to another action brought by BD, in the same Court (the “Related Matter”) against a former BD employee who is also a former Company employee (the “Former Employee”) alleging that the Former Employee had violated the Former Employee’s legal obligations to BD regarding BD’s confidential and trade secret information when the Former Employee allegedly

- removed (2022-08-09):
[0000926326-22-000014:note_history:8]
downloaded certain documents from BD’s information technology system following the end of the Former Employee’s employment with BD. In connection with the Related Matter, BD, the Former Employee, and the Company entered into a protocol with the purpose of facilitating the return to BD of any BD documents that may have been resident, as a result of the Former Employee’s actions, on any devices belonging to the Former Employee or the Company. The BD Complaint seeks injunctive relief and monetary damages in the form of compensatory, punitive, and exemplary damages, attorneys’ fees and costs, and pre-judgment and post-judgment interest. On March 8, 2022, the parties entered into a confidential settlement agreement. Omnicell is currently in the process of effectuating certain obligations under the agreement prior to dismissal of the BD Complaint.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-08-09):
[0000926326-22-000027:note_history:9]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of June 30, 2022 and December 31, 2021, the results of operations and comprehensive income for the three and six months ended June 30, 2022 and 2021, and cash flows for the six months ended June 30, 2022 and 2021. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s Annual Report on Form 10-K for the year ended December 31, 2021, filed with the SEC on February 25, 2022, except as discussed in the section entitled “Recently Adopted Authoritative Guidance” below. The Company’s results of operations and comprehensive income for the three and six months ended June 30, 2022, and cash flows for the six months ended June 30, 2022 are not necessarily indicative of results that may be expected for the year ending December 31, 2022, or for any future period.
  (was, 2022-05-09, similarity 0.8178):
[0000926326-22-000014:note_history:9]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of March 31, 2022 and December 31, 2021, and the results of operations, comprehensive income, and cash flows for the three months ended March 31, 2022 and 2021. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s Annual Report on Form 10-K for the year ended December 31, 2021, filed with the SEC on February 25, 2022, except as discussed in the section entitled “Recently Adopted Authoritative Guidance” below. The Company’s results of operations, comprehensive income, and cash flows for the three months ended March 31, 2022 are not necessarily indicative of results that may be expected for the year ending December 31, 2022, or for any future period.

- changed (2022-08-09):
[0000926326-22-000027:note_history:10]
The Company’s critical accounting policies are those that affect its financial statements materially and involve difficult, subjective, or complex judgments by management. As of June 30, 2022, the Company is not aware of any events or circumstances that would require an update to its estimates, judgments, or revisions to the carrying value of its assets or liabilities.
  (was, 2022-05-09, similarity 0.6758):
[0000926326-22-000014:note_history:10]
The Company’s critical accounting policies are those that affect its financial statements materially and involve difficult, subjective, or complex judgments by management. As of March 31, 2022, the Company is not aware of any events or circumstances that would require an update to its estimates, judgments, or revisions to the carrying value of its assets or liabilities.


## omcl:ScheduleOfInterestExpenseDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-08-09):
[0000926326-22-000027:note_history:11]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three and six months ended June 30, 2022 and 2021:
  (was, 2022-05-09, similarity 0.9131):
[0000926326-22-000014:note_history:11]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three months ended March 31, 2022 and 2021:

- changed (2022-08-09):
[0000926326-22-000027:note_history:12]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2022 (1) |  | 2021 |  | 2022 (1) |  | 2021 |
|  | (In thousands) |
| Contractual coupon interest | $ | 359 |  |  | $ | 359 |  |  | $ | 719 |  |  | $ | 719 |  |
| Amortization of discount | $ | — |  |  | $ | 4,624 |  |  | $ | — |  |  | $ | 9,195 |  |
| Amortization of debt issuance costs | $ | 766 |  |  | $ | 583 |  |  | $ | 1,530 |  |  | $ | 1,158 |  |
  (was, 2022-05-09, similarity 0.7496):
[0000926326-22-000014:note_history:12]
|  | Three Months Ended March 31, |  |  |
|  | 2022 (1) |  | 2021 |  |  |  |  |
|  | (In thousands) |
| Contractual coupon interest | $ | 359 |  |  | $ | 359 |  |  |  |  |  |
| Amortization of discount | $ | — |  |  | $ | 4,571 |  |  |  |  |  |
| Amortization of debt issuance costs | $ | 764 |  |  | $ | 575 |  |  |  |  |  |


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-08-09):
[0000926326-22-000027:note_history:13]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of June 30, 2022 and December 31, 2021:
  (was, 2022-05-09, similarity 0.966):
[0000926326-22-000014:note_history:13]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of March 31, 2022 and December 31, 2021:

- changed (2022-08-09):
[0000926326-22-000027:note_history:14]
|  | June 30,2022 (2) |  | December 31,2021 |
|  | (In thousands) |
| Liability: |  |  |  |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized discount | — |  |  | (77,136) |  |
| Unamortized debt issuance costs | (9,965) |  |  | (9,712) |  |
| Convertible senior notes, liability component (1) | $ | 565,035 |  |  | $ | 488,152 |  |
| Convertible senior notes, equity component | $ | — |  |  | $ | 72,732 |  |
  (was, 2022-05-09, similarity 0.9874):
[0000926326-22-000014:note_history:14]
|  | March 31,2022 (2) |  | December 31,2021 |
|  | (In thousands) |
| Liability: |  |  |  |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized discount | — |  |  | (77,136) |  |
| Unamortized debt issuance costs | (10,731) |  |  | (9,712) |  |
| Convertible senior notes, liability component (1) | $ | 564,269 |  |  | $ | 488,152 |  |
| Convertible senior notes, equity component | $ | — |  |  | $ | 72,732 |  |

- changed (2022-08-09):
[0000926326-22-000027:note_history:15]
(1)    Classified as a long-term liability as of June 30, 2022, and a current liability as of December 31, 2021, in the Condensed Consolidated Balance Sheets.
  (was, 2022-05-09, similarity 0.7727):
[0000926326-22-000014:note_history:15]
(1)    Classified as a current liability as of both March 31, 2022 and December 31, 2021 in the Condensed Consolidated Balance Sheets.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-08-09):
[0000926326-22-000027:note_history:16]
The A&R Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends, and other distributions. The A&R Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum total secured net leverage ratio (as described above) and maintain a minimum interest coverage ratio. In addition, the A&R Credit Agreement contains certain customary events of default including, but not limited to, failure to pay interest, principal, and fees, or other amounts when due, material misrepresentations or misstatements in any representation or warranty, covenant defaults, certain cross defaults to other material indebtedness, certain judgment defaults, and events of bankruptcy. The Company’s obligations under the A&R Credit Agreement and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and such subsidiary guarantors’ assets. In connection with entering into the A&R Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a reaffirmation agreement, which amends certain terms of the existing collateral agreement and reaffirms their obligations under the existing guaranty agreement. The Company was in compliance with all covenants as of June 30, 2022.
  (was, 2022-05-09, similarity 0.996):
[0000926326-22-000014:note_history:16]
The A&R Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends, and other distributions. The A&R Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum total secured net leverage ratio (as described above) and maintain a minimum interest coverage ratio. In addition, the A&R Credit Agreement contains certain customary events of default including, but not limited to, failure to pay interest, principal, and fees, or other amounts when due, material misrepresentations or misstatements in any representation or warranty, covenant defaults, certain cross defaults to other material indebtedness, certain judgment defaults, and events of bankruptcy. The Company’s obligations under the A&R Credit Agreement and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and such subsidiary guarantors’ assets. In connection with entering into the A&R Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a reaffirmation agreement, which amends certain terms of the existing collateral agreement and reaffirms their obligations under the existing guaranty agreement. The Company was in full compliance with all covenants as of March 31, 2022.

- changed (2022-08-09):
[0000926326-22-000027:note_history:17]
As of each of June 30, 2022 and December 31, 2021, there was no outstanding balance for the Revolving Credit Facility.
Convertible Senior Notes
0.25% Convertible Senior Notes due 2025
  (was, 2022-05-09, similarity 0.973):
[0000926326-22-000014:note_history:17]
As of each of March 31, 2022 and December 31, 2021, there was no outstanding balance for the Revolving Credit Facility.
Convertible Senior Notes
0.25% Convertible Senior Notes due 2025

- added (2022-08-09):
[0000926326-22-000027:note_history:18]
During the three months ended December 31, 2021 and March 31, 2022, the conditional conversion feature of the Notes was triggered, based on the price of the Company’s common stock, as the last reported sale price of the Company’s common stock was greater than or equal to 130% of the then applicable conversion price for the Notes for at least 20 trading days during the period of 30 consecutive trading days ending on December 31, 2021 and March 31, 2022, the last trading day of the respective fiscal quarters. Accordingly, the Notes were convertible during the first two quarters of 2022 and were classified as a current liability in the Consolidated Financial Statements as of December 31, 2021 and March 31, 2022. During the three months ended June 30, 2022, none of the conditional conversion features of the Notes were triggered, and therefore, the Notes are not convertible during the third quarter of 2022, commencing on July 1, 2022. Accordingly, the Company classified the Notes as a long-term liability in its Condensed Consolidated Financial Statements as of June 30, 2022. Whether the Notes will be convertible following the third fiscal quarter of 2022 will depend on the satisfaction of the conversion conditions in the future.

- changed (2022-08-09):
[0000926326-22-000027:note_history:19]
If the Company undergoes a fundamental change, holders may require, subject to certain exceptions, the Company to repurchase for cash all or any portion of their Notes at a fundamental change repurchase price equal to 100% of the principal amount of the Notes to be repurchased, plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date. As of June 30, 2022, none of the criteria for a fundamental change or a conversion rate adjustment had been met.
  (was, 2022-05-09, similarity 0.8349):
[0000926326-22-000014:note_history:19]
If the Company undergoes a fundamental change, holders may require, subject to certain exceptions, the Company to repurchase for cash all or any portion of their Notes at a fundamental change repurchase price equal to 100% of the principal amount of the Notes to be repurchased, plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date. As of March 31, 2022, none of the criteria for a fundamental change or a conversion rate adjustment had been met.

- changed (2022-08-09):
[0000926326-22-000027:note_history:20]
Prior to the adoption of ASU 2020-06, convertible debt instruments that could be settled in cash were required to be separated into liability and equity components. The allocation to the liability component was based on the fair value of a similar instrument that did not contain an equity conversion option. Based on this debt-to-equity ratio, debt issuance costs were then allocated to the liability and equity components in a similar manner. Accordingly, at issuance, the Company allocated $461.8 million to the debt liability and $72.7 million to additional paid-in capital, net of applicable issuance costs and deferred taxes. The difference between the principal amount of the Notes and the liability component, inclusive of issuance costs, represented the debt discount, which the Company amortized to interest expense over the term of the Notes using an effective interest rate of 4.18%. The determination of the discount rate required certain estimates and assumptions.
  (was, 2022-05-09, similarity 0.8556):
[0000926326-22-000014:note_history:20]
instrument that did not contain an equity conversion option. Based on this debt-to-equity ratio, debt issuance costs were then allocated to the liability and equity components in a similar manner. Accordingly, at issuance, the Company allocated $461.8 million to the debt liability and $72.7 million to additional paid-in capital, net of applicable issuance costs and deferred taxes. The difference between the principal amount of the Notes and the liability component, inclusive of issuance costs, represented the debt discount, which the Company amortized to interest expense over the term of the Notes using an effective interest rate of 4.18%. The determination of the discount rate required certain estimates and assumptions.

- changed (2022-08-09):
[0000926326-22-000027:note_history:21]
As of June 30, 2022, the remaining life of the Notes and the related issuance cost accretion is approximately 3.2 years.
  (was, 2022-05-09, similarity 0.96):
[0000926326-22-000014:note_history:21]
As of March 31, 2022, the remaining life of the Notes and the related issuance cost accretion is approximately 3.5 years.

- changed (2022-08-09):
[0000926326-22-000027:note_history:22]
The maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to other conversion rate adjustments, would be 5.9 million shares. As of June 30, 2022, the if-converted value of the Notes exceeded the principal amount by $97.1 million.
  (was, 2022-05-09, similarity 0.9835):
[0000926326-22-000014:note_history:22]
The maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to other conversion rate adjustments, would be 5.9 million shares. As of March 31, 2022, the if-converted value of the Notes exceeded the principal amount by $190.1 million.

- changed (2022-08-09):
[0000926326-22-000027:note_history:23]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of June 30, 2022 and December 31, 2021:
  (was, 2022-05-09, similarity 0.966):
[0000926326-22-000014:note_history:23]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of March 31, 2022 and December 31, 2021:

- changed (2022-08-09):
[0000926326-22-000027:note_history:24]
|  | June 30,2022 (2) |  | December 31,2021 |
|  | (In thousands) |
| Liability: |  |  |  |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized discount | — |  |  | (77,136) |  |
| Unamortized debt issuance costs | (9,965) |  |  | (9,712) |  |
| Convertible senior notes, liability component (1) | $ | 565,035 |  |  | $ | 488,152 |  |
| Convertible senior notes, equity component | $ | — |  |  | $ | 72,732 |  |
  (was, 2022-05-09, similarity 0.9874):
[0000926326-22-000014:note_history:24]
|  | March 31,2022 (2) |  | December 31,2021 |
|  | (In thousands) |
| Liability: |  |  |  |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized discount | — |  |  | (77,136) |  |
| Unamortized debt issuance costs | (10,731) |  |  | (9,712) |  |
| Convertible senior notes, liability component (1) | $ | 564,269 |  |  | $ | 488,152 |  |
| Convertible senior notes, equity component | $ | — |  |  | $ | 72,732 |  |

- changed (2022-08-09):
[0000926326-22-000027:note_history:25]
(1)    Classified as a long-term liability as of June 30, 2022, and a current liability as of December 31, 2021, in the Condensed Consolidated Balance Sheets.
  (was, 2022-05-09, similarity 0.7727):
[0000926326-22-000014:note_history:25]
(1)    Classified as a current liability as of both March 31, 2022 and December 31, 2021 in the Condensed Consolidated Balance Sheets.

- changed (2022-08-09):
[0000926326-22-000027:note_history:26]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three and six months ended June 30, 2022 and 2021:
  (was, 2022-05-09, similarity 0.9131):
[0000926326-22-000014:note_history:26]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three months ended March 31, 2022 and 2021:

- changed (2022-08-09):
[0000926326-22-000027:note_history:27]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2022 (1) |  | 2021 |  | 2022 (1) |  | 2021 |
|  | (In thousands) |
| Contractual coupon interest | $ | 359 |  |  | $ | 359 |  |  | $ | 719 |  |  | $ | 719 |  |
| Amortization of discount | $ | — |  |  | $ | 4,624 |  |  | $ | — |  |  | $ | 9,195 |  |
| Amortization of debt issuance costs | $ | 766 |  |  | $ | 583 |  |  | $ | 1,530 |  |  | $ | 1,158 |  |
  (was, 2022-05-09, similarity 0.7496):
[0000926326-22-000014:note_history:27]
|  | Three Months Ended March 31, |  |  |
|  | 2022 (1) |  | 2021 |  |  |  |  |
|  | (In thousands) |
| Contractual coupon interest | $ | 359 |  |  | $ | 359 |  |  |  |  |  |
| Amortization of discount | $ | — |  |  | $ | 4,571 |  |  |  |  |  |
| Amortization of debt issuance costs | $ | 764 |  |  | $ | 575 |  |  |  |  |  |

- added (2022-08-09):
[0000926326-22-000027:note_history:28]
The convertible note hedge consists of an option for the Company to purchase up to approximately 5.9 million shares of the Company’s common stock, which is equal to the number of shares of the Company’s common stock underlying the Notes, at an initial strike price of approximately $97.32 per share. The convertible note hedge will expire upon the maturity of the Notes, if not earlier exercised or terminated. The cost of the convertible note hedge was approximately $100.6 million and was accounted for as an equity instrument, which was recorded in additional paid-in capital in the Condensed Consolidated Balance Sheets. The Company recorded a deferred tax asset of $25.8 million at issuance related to the convertible note hedge transaction. The convertible note hedge is expected generally to reduce the potential dilution to the Company’s common stock upon any conversion of Notes and/or offset any cash payments the Company is required to make in excess of the principal amount of converted Notes.

- removed (2022-08-09):
[0000926326-22-000014:note_history:29]
During the three months ended March 31, 2022, the conditional conversion feature of the Notes was triggered, based on the price of the Company’s common stock, as the last reported sale price of the Company’s common stock was greater than or equal to 130% of the then applicable conversion price for the Notes for at least 20 trading days during the period of 30 consecutive trading days ending on March 31, 2022, the last trading day of the fiscal quarter. Accordingly, the Notes are convertible, in whole or in part, at the option of the holders during the second quarter of 2022. Whether the Notes will be convertible following the second fiscal quarter of 2022 will depend on the continued satisfaction of this condition or another conversion condition in the future. The Company continues to classify the Notes as a current liability in its Condensed Consolidated Financial Statements as of March 31, 2022 based on its irrevocable election to settle the principal amount in cash as discussed below.

- removed (2022-08-09):
[0000926326-22-000014:note_history:30]
Prior to the adoption of ASU 2020-06, convertible debt instruments that could be settled in cash were required to be separated into liability and equity components. The allocation to the liability component was based on the fair value of a similar

- removed (2022-08-09):
[0000926326-22-000014:note_history:31]
The convertible note hedge consists of an option for the Company to purchase up to approximately 5.9 million shares of the Company’s common stock, which is equal to the number of shares of the Company’s common stock underlying the Notes, at an initial strike price of approximately $97.32 per share. The convertible note hedge will expire upon the maturity of

- removed (2022-08-09):
[0000926326-22-000014:note_history:32]
the Notes, if not earlier exercised or terminated. The cost of the convertible note hedge was approximately $100.6 million and was accounted for as an equity instrument, which was recorded in additional paid-in capital in the Condensed Consolidated Balance Sheets. The Company recorded a deferred tax asset of $25.8 million at issuance related to the convertible note hedge transaction. The convertible note hedge is expected generally to reduce the potential dilution to the Company’s common stock upon any conversion of Notes and/or offset any cash payments the Company is required to make in excess of the principal amount of converted Notes.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-08-09):
[0000926326-22-000027:note_history:33]
Connected devices, software licenses, and other. Software-enabled connected devices and software licenses that manage and regulate the storage and dispensing of pharmaceuticals, consumables blister cards, and packaging equipment and other supplies. This revenue category is often sold through long-term, sole-source agreements with multi-year co-development plans. Solutions in this category include, but are not limited to, XT Series automated dispensing systems, the XR2 Automated Central Pharmacy System, IVX Station and IV compounding automation solutions.
  (was, 2022-05-09, similarity 0.9819):
[0000926326-22-000014:note_history:33]
Connected devices, software licenses, and other. Software-enabled connected devices and software licenses that manage and regulate the storage and dispensing of pharmaceuticals, consumables blister cards, and packaging equipment and other supplies. This revenue category is often sold through long-term, sole-source agreements with multi-year co-development plans. Solutions in this category include, but are not limited to, XT Series automated dispensing systems, the XR2 Automated Central Pharmacy System, and IV compounding automation solutions.

- changed (2022-08-09):
[0000926326-22-000027:note_history:34]
SaaS, subscription software, and technology-enabled services. Emerging software and service solutions which are offered on a subscription basis with fees typically based either on transaction volume or a fee over a specified period of time. Solutions in this category include, but are not limited to, EnlivenHealth inclusive of FDS Amplicare and MarkeTouch Media, 340B solutions, ReCept management services, and services associated with Omnicell One™, Central Pharmacy Dispensing Services, including the XR2 Automated Central Pharmacy System, and Central Pharmacy Compounding Services, including IVX Station and IV compounding automation solutions.
  (was, 2022-05-09, similarity 0.9875):
[0000926326-22-000014:note_history:34]
SaaS, subscription software, and technology-enabled services. Emerging software and service solutions which are offered on a subscription basis with fees typically based either on transaction volume or a fee over a specified period of time. Solutions in this category include, but are not limited to, EnlivenHealth inclusive of FDS Amplicare and MarkeTouch Media, 340B solutions, ReCept management services, and services associated with Omnicell One™, Central Pharmacy Dispensing Services, including the XR2 Automated Central Pharmacy System, and Central Pharmacy Compounding Services, including IV compounding automation solutions.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-08-09):
[0000926326-22-000027:note_history:35]
Connected devices, software licenses, and other. Software-enabled connected devices and software licenses that manage and regulate the storage and dispensing of pharmaceuticals, consumables blister cards, and packaging equipment and other supplies. This revenue category is often sold through long-term, sole-source agreements with multi-year co-development plans. Solutions in this category include, but are not limited to, XT Series automated dispensing systems, the XR2 Automated Central Pharmacy System, IVX Station and IV compounding automation solutions.
  (was, 2022-05-09, similarity 0.9819):
[0000926326-22-000014:note_history:35]
Connected devices, software licenses, and other. Software-enabled connected devices and software licenses that manage and regulate the storage and dispensing of pharmaceuticals, consumables blister cards, and packaging equipment and other supplies. This revenue category is often sold through long-term, sole-source agreements with multi-year co-development plans. Solutions in this category include, but are not limited to, XT Series automated dispensing systems, the XR2 Automated Central Pharmacy System, and IV compounding automation solutions.

- changed (2022-08-09):
[0000926326-22-000027:note_history:36]
SaaS, subscription software, and technology-enabled services. Emerging software and service solutions which are offered on a subscription basis with fees typically based either on transaction volume or a fee over a specified period of time. Solutions in this category include, but are not limited to, EnlivenHealth inclusive of FDS Amplicare and MarkeTouch Media, 340B solutions, ReCept management services, and services associated with Omnicell One™, Central Pharmacy Dispensing Services, including the XR2 Automated Central Pharmacy System, and Central Pharmacy Compounding Services, including IVX Station and IV compounding automation solutions.
  (was, 2022-05-09, similarity 0.9875):
[0000926326-22-000014:note_history:36]
SaaS, subscription software, and technology-enabled services. Emerging software and service solutions which are offered on a subscription basis with fees typically based either on transaction volume or a fee over a specified period of time. Solutions in this category include, but are not limited to, EnlivenHealth inclusive of FDS Amplicare and MarkeTouch Media, 340B solutions, ReCept management services, and services associated with Omnicell One™, Central Pharmacy Dispensing Services, including the XR2 Automated Central Pharmacy System, and Central Pharmacy Compounding Services, including IV compounding automation solutions.

- changed (2022-08-09):
[0000926326-22-000027:note_history:37]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”) and Federal agencies that purchase under a Federal Supply Schedule Contract with the Department of Veterans Affairs (the “GSA Contract”). GPOs are often fully or partially owned by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company also pays the Industrial Funding Fee (“IFF”) to the Department of Veterans Affairs under the GSA Contract. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs and the IFF were $4.0 million and $4.2 million for the three months ended June 30, 2022 and 2021, respectively, and $8.5 million and $7.6 million for the six months ended June 30, 2022 and 2021, respectively.
  (was, 2022-05-09, similarity 0.9389):
[0000926326-22-000014:note_history:37]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”) and Federal agencies that purchase under a Federal Supply Schedule Contract with the Department of Veterans Affairs (the “GSA Contract”). GPOs are often fully or partially owned by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company also pays the Industrial Funding Fee (“IFF”) to the Department of Veterans Affairs under the GSA Contract. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs and the IFF were $4.5 million and $3.4 million for the three months ended March 31, 2022 and 2021, respectively.

- changed (2022-08-09):
[0000926326-22-000027:note_history:38]
The following table summarizes the Company’s revenues disaggregated by revenue type for the three and six months ended June 30, 2022 and 2021:
  (was, 2022-05-09, similarity 0.9349):
[0000926326-22-000014:note_history:38]
The following table summarizes the Company’s revenues disaggregated by revenue type for the three months ended March 31, 2022 and 2021:

- changed (2022-08-09):
[0000926326-22-000027:note_history:39]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
|  | (In thousands) |
| Connected devices, software licenses, and other | $ | 215,632 |  |  | $ | 179,044 |  |  | $ | 423,710 |  |  | $ | 338,762 |  |
| Technical services | 53,303 |  |  | 51,932 |  |  | 102,472 |  |  | 102,792 |  |
| Consumables | 18,174 |  |  | 17,867 |  |  | 35,971 |  |  | 36,274 |  |
| SaaS, subscription software, and technology-enabled services | 44,277 |  |  | 23,896 |  |  | 88,061 |  |  | 46,754 |  |
| Total revenues | $ | 331,386 |  |  | $ | 272,739 |  |  | $ | 650,214 |  |  | $ | 524,582 |  |
  (was, 2022-05-09, similarity 0.7687):
[0000926326-22-000014:note_history:39]
|  | Three Months Ended March 31, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
|  | (In thousands) |
| Connected devices, software licenses, and other | $ | 208,078 |  |  | $ | 159,718 |  |  |  |  |  |
| Technical services | 49,169 |  |  | 50,860 |  |  |  |  |  |
| Consumables | 17,797 |  |  | 18,407 |  |  |  |  |  |
| SaaS, subscription software, and technology-enabled services | 43,784 |  |  | 22,858 |  |  |  |  |  |
| Total revenues | $ | 318,828 |  |  | $ | 251,843 |  |  |  |  |  |

- changed (2022-08-09):
[0000926326-22-000027:note_history:40]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location, for the three and six months ended June 30, 2022 and 2021:
  (was, 2022-05-09, similarity 0.9539):
[0000926326-22-000014:note_history:40]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location, for the three months ended March 31, 2022 and 2021:

- changed (2022-08-09):
[0000926326-22-000027:note_history:41]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
|  | (In thousands) |
| United States | $ | 294,937 |  |  | $ | 242,859 |  |  | $ | 582,514 |  |  | $ | 467,135 |  |
| Rest of world (1) | 36,449 |  |  | 29,880 |  |  | 67,700 |  |  | 57,447 |  |
| Total revenues | $ | 331,386 |  |  | $ | 272,739 |  |  | $ | 650,214 |  |  | $ | 524,582 |  |
  (was, 2022-05-09, similarity 0.714):
[0000926326-22-000014:note_history:41]
|  | Three Months Ended March 31, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
|  | (In thousands) |
| United States | $ | 287,577 |  |  | $ | 224,276 |  |  |  |  |  |
| Rest of world (1) | 31,251 |  |  | 27,567 |  |  |  |  |  |
| Total revenues | $ | 318,828 |  |  | $ | 251,843 |  |  |  |  |  |

- changed (2022-08-09):
[0000926326-22-000027:note_history:42]
|  | June 30,2022 |  | December 31,2021 |
|  | (In thousands) |
| Short-term unbilled receivables, net (1) | $ | 19,567 |  |  | $ | 17,208 |  |
| Long-term unbilled receivables, net (2) | 16,185 |  |  | 18,084 |  |
| Total contract assets | $ | 35,752 |  |  | $ | 35,292 |  |
| Short-term deferred revenues, net | $ | 108,579 |  |  | $ | 112,196 |  |
| Long-term deferred revenues | 24,187 |  |  | 20,194 |  |
| Total contract liabilities | $ | 132,766 |  |  | $ | 132,390 |  |
  (was, 2022-05-09, similarity 0.9882):
[0000926326-22-000014:note_history:42]
|  | March 31,2022 |  | December 31,2021 |
|  | (In thousands) |
| Short-term unbilled receivables, net (1) | $ | 17,348 |  |  | $ | 17,208 |  |
| Long-term unbilled receivables, net (2) | 16,316 |  |  | 18,084 |  |
| Total contract assets | $ | 33,664 |  |  | $ | 35,292 |  |
| Short-term deferred revenues, net | $ | 127,998 |  |  | $ | 112,196 |  |
| Long-term deferred revenues | 24,037 |  |  | 20,194 |  |
| Total contract liabilities | $ | 152,035 |  |  | $ | 132,390 |  |

- changed (2022-08-09):
[0000926326-22-000027:note_history:43]
Short-term deferred revenues of $108.6 million and $112.2 million include deferred revenues from product sales and service contracts, net of deferred cost of sales of $13.6 million and $22.4 million, as of June 30, 2022 and December 31, 2021, respectively. The short-term deferred revenues from product sales relate to delivered and invoiced products, pending installation and acceptance, expected to occur within the next twelve months. During the three and six months ended June 30, 2022, the Company recognized revenues of $22.4 million and $89.0 million, respectively, that were included in the corresponding gross short-term deferred revenues balance of $134.6 million as of December 31, 2021.
  (was, 2022-05-09, similarity 0.7703):
[0000926326-22-000014:note_history:43]
Short-term deferred revenues of $128.0 million and $112.2 million include deferred revenues from product sales and service contracts, net of deferred cost of sales of $20.3 million and $22.4 million, as of March 31, 2022 and December 31, 2021, respectively. The short-term deferred revenues from product sales relate to delivered and invoiced products, pending installation and acceptance, expected to occur within the next twelve months. During the three months ended March 31, 2022, the Company recognized revenues of $66.6 million, that were included in the corresponding gross short-term deferred revenues balance of $134.6 million as of December 31, 2021.

- changed (2022-08-09):
[0000926326-22-000027:note_history:44]
Long-term deferred revenues include deferred revenues from product and service contracts of $24.2 million and $20.2 million as of June 30, 2022 and December 31, 2021, respectively. Remaining performance obligations are primarily recognized ratably over the remaining term of the contract, generally not more than ten years.
  (was, 2022-05-09, similarity 0.9853):
[0000926326-22-000014:note_history:44]
Long-term deferred revenues include deferred revenues from product and service contracts of $24.0 million and $20.2 million as of March 31, 2022 and December 31, 2021, respectively. Remaining performance obligations are primarily recognized ratably over the remaining term of the contract, generally not more than ten years.

- changed (2022-08-09):
[0000926326-22-000027:note_history:45]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three and six months ended June 30, 2022 and 2021. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable balance as of June 30, 2022 and December 31, 2021.
  (was, 2022-05-09, similarity 0.9048):
[0000926326-22-000014:note_history:45]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three months ended March 31, 2022 and 2021. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable balance as of March 31, 2022 and December 31, 2021.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2022-08-09):
[0000926326-22-000014:note_history:46]
Subsequent EventsOn May 4, 2022, the Company determined that certain of its information technology systems were affected by ransomware impacting certain internal systems. There is an impact on certain of the Company’s products and services, as well as certain of its internal systems. Upon detecting the security event, the Company took immediate steps designed to contain the incident and implement its business continuity plans to restore and support continued operations. The Company has notified appropriate law enforcement authorities. The Company is also working closely with cybersecurity experts and legal counsel. The Company is in the early stages of its investigation and assessment of the security event and cannot determine, at this time, the extent of the impact from such event on our business, results of operations or financial condition or whether such impact will have a material adverse effect.
