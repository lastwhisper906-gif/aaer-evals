# OMCL 8-K — 0000926326-24-000024 filed 2024-08-01

## item codes, every 8-K on or before 2024-08-06

- 2024-08-01 0000926326-24-000024 — 2.02, 9.01
- 2024-06-04 0000926326-24-000019 — 5.02 — amendment of 0001104659-24-029356
- 2024-05-24 0001104659-24-065130 — 5.02, 5.07, 9.01
- 2024-05-02 0000926326-24-000012 — 2.02, 2.05, 9.01
- 2024-02-29 0001104659-24-029356 — 5.02
- 2024-02-08 0000926326-24-000005 — 2.02, 9.01
- 2024-01-11 0000926326-24-000002 — 5.02, 7.01, 8.01, 9.01
- 2023-11-09 0000926326-23-000043 — 5.02, 9.01
- 2023-11-02 0001104659-23-113604 — 2.02, 2.05, 7.01, 9.01
- 2023-10-16 0000926326-23-000039 — 1.01, 2.03, 9.01
- 2023-10-05 0000926326-23-000037 — 5.02, 9.01
- 2023-08-16 0000926326-23-000035 — 5.02
- 2023-08-10 0000926326-23-000033 — 5.02, 9.01
- 2023-08-03 0000926326-23-000029 — 5.02, 9.01
- 2023-08-01 0000926326-23-000027 — 2.02, 9.01
- 2023-07-11 0000926326-23-000025 — 5.02, 9.01
- 2023-06-26 0000926326-23-000022 — 5.02 — amendment of 0001104659-23-026700
- 2023-05-30 0001104659-23-066011 — 5.02, 9.01
- 2023-05-26 0000926326-23-000020 — 5.02, 5.07, 9.01
- 2023-05-15 0001104659-23-060768 — 5.02, 9.01
- 2023-05-02 0000926326-23-000011 — 2.02, 9.01
- 2023-04-03 0000926326-23-000009 — 1.01, 2.03, 9.01
- 2023-02-28 0001104659-23-026700 — 2.02, 2.05, 5.02, 9.01
- 2022-11-30 0000926326-22-000036 — 2.05
- 2022-11-02 0000926326-22-000031 — 2.02, 9.01
- 2022-10-21 0000926326-22-000029 — 5.03, 9.01
- 2022-09-20 0001104659-22-101566 — 7.01, 9.01
- 2022-09-20 0001104659-22-101360 — 7.01, 9.01
- 2022-08-04 0000926326-22-000025 — 2.02, 8.01, 9.01
- 2022-05-31 0000926326-22-000020 — 5.02, 5.07, 9.01
- 2022-05-24 0000926326-22-000016 — 5.02
- 2022-05-09 0000926326-22-000012 — 8.01
- 2022-04-28 0000926326-22-000009 — 2.02, 9.01
- 2022-03-01 0001104659-22-028681 — 5.02, 8.01, 9.01
- 2022-02-14 0000926326-22-000004 — 2.02, 9.01
- 2022-01-04 0000926326-22-000002 — 7.01, 9.01
- 2021-12-29 0001104659-21-154294 — 7.01, 9.01
- 2021-12-13 0000926326-21-000039 — 8.01
- 2021-12-02 0000926326-21-000037 — 7.01, 9.01
- 2021-11-02 0000926326-21-000031 — 2.02, 9.01
- 2021-09-09 0000926326-21-000028 — 7.01, 9.01
- 2021-07-29 0000926326-21-000024 — 2.02, 9.01
- 2021-07-26 0000926326-21-000022 — 7.01, 9.01
- 2021-07-12 0000926326-21-000019 — 5.02, 9.01
- 2021-05-28 0000926326-21-000015 — 5.07
- 2021-04-29 0000926326-21-000011 — 2.02, 9.01
- 2021-02-01 0000926326-21-000004 — 2.02, 9.01
- 2021-01-26 0000926326-21-000002 — 5.02
- 2021-01-13 0001104659-21-003672 — 2.02, 7.01, 9.01
- 2020-10-27 0000926326-20-000032 — 2.02, 9.01
- 2020-10-01 0000926326-20-000029 — 7.01, 9.01
- 2020-09-25 0001104659-20-108924 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2020-09-22 0001104659-20-107176 — 1.01, 8.01, 9.01
- 2020-08-12 0000926326-20-000027 — 2.03
- 2020-08-12 0000926326-20-000025 — 1.01, 5.03, 7.01, 9.01
- 2020-07-28 0000926326-20-000021 — 2.02, 9.01
- 2020-05-27 0000926326-20-000017 — 5.07
- 2020-05-07 0000926326-20-000012 — 2.02, 9.01
- 2020-02-18 0000926326-20-000007 — 5.02, 9.01
- 2020-02-13 0000926326-20-000005 — 8.01
- 2020-02-06 0000926326-20-000003 — 2.02, 9.01
- 2019-12-06 0001104659-19-070339 — 8.01
- 2019-11-18 0000926326-19-000035 — 1.01, 2.03, 9.01
- 2019-10-24 0000926326-19-000028 — 2.02, 9.01
- 2019-07-25 0000926326-19-000021 — 2.02, 9.01
- 2019-05-15 0000926326-19-000015 — 5.07
- 2019-04-25 0000926326-19-000011 — 2.02, 9.01
- 2019-03-08 0000926326-19-000009 — 5.02, 9.01
- 2019-02-19 0000926326-19-000005 — 5.02, 9.01
- 2019-02-07 0000926326-19-000003 — 2.02, 9.01
- 2018-10-25 0000926326-18-000028 — 2.02, 9.01
- 2018-09-14 0001104659-18-056929 — 5.02, 9.01
- 2018-07-26 0000926326-18-000022 — 2.02, 9.01
- 2018-06-06 0000926326-18-000019 — 5.02, 9.01
- 2018-05-16 0001104659-18-033801 — 5.07
- 2018-04-26 0000926326-18-000013 — 2.02, 9.01
- 2018-03-02 0001104659-18-014497 — 5.02
- 2018-02-08 0000926326-18-000007 — 5.02
- 2018-02-02 0000926326-18-000005 — 5.02
- 2018-02-01 0000926326-18-000003 — 2.02, 9.01
- 2017-12-26 0000926326-17-000041 — 1.01, 2.03, 9.01
- 2017-11-03 0001104659-17-066102 — 1.01, 8.01, 9.01
- 2017-10-26 0000926326-17-000035 — 2.02, 9.01
- 2017-08-03 0000926326-17-000028 — 5.07 — amendment, the index does not say of what
- 2017-07-27 0000926326-17-000026 — 2.02, 9.01
- 2017-07-25 0000926326-17-000023 — 5.02, 9.01
- 2017-05-24 0000926326-17-000019 — 5.07
- 2017-05-04 0001628280-17-004851 — 2.02, 9.01
- 2017-02-15 0000926326-17-000010 — 2.05
- 2017-02-15 0000926326-17-000008 — 2.02, 9.01
- 2017-02-13 0000926326-17-000002 — 5.02
- 2016-12-08 0001104659-16-161330 — 2.01, 2.03, 9.01
- 2016-12-06 0001104659-16-160709 — 7.01
- 2016-11-29 0001104659-16-159456 — 1.01, 7.01, 9.01
- 2016-10-27 0000926326-16-000075 — 2.02, 9.01
- 2016-10-07 0000926326-16-000072 — 5.02, 8.01
- 2016-08-05 0000926326-16-000068 — 8.01
- 2016-07-28 0000926326-16-000066 — 2.02, 9.01
- 2016-06-13 0001104659-16-126854 — 5.02
- 2016-05-25 0000926326-16-000060 — 5.07
- 2016-04-28 0000926326-16-000054 — 2.02, 9.01
- 2016-03-21 0001104659-16-106649 — 8.01, 9.01
- 2016-03-17 0000926326-16-000051 — 7.01, 9.01
- 2016-03-17 0000926326-16-000049 — 9.01 — amendment of 0000926326-16-000051
- 2016-02-10 0001104659-16-095486 — 5.02, 9.01
- 2016-02-04 0000926326-16-000041 — 2.02, 9.01
- 2016-01-06 0001104659-16-088299 — 1.01, 2.01, 2.03, 9.01
- 2015-12-10 0000926326-15-000038 — 8.01, 9.01
- 2015-10-29 0001104659-15-074138 — 1.01, 9.01
- 2015-10-29 0000926326-15-000031 — 2.02, 9.01
- 2015-08-20 0001104659-15-061135 — 5.02, 9.01
- 2015-07-30 0000926326-15-000024 — 2.02, 9.01
- 2015-05-22 0001104659-15-040440 — 5.07
- 2015-05-01 0001104659-15-032846 — 5.02
- 2015-05-01 0001104659-15-032844 — 7.01
- 2015-04-30 0000926326-15-000015 — 9.01
- 2015-04-22 0001104659-15-029356 — 8.01, 9.01
- 2015-03-20 0001104659-15-021435 — 3.01
- 2015-03-18 0001104659-15-020699 — 7.01
- 2015-03-17 0001104659-15-020483 — 8.01, 9.01
- 2015-03-02 0001104659-15-015802 — 1.01, 9.01
- 2015-02-12 0001104659-15-009234 — 5.02, 9.01
- 2015-02-03 0000926326-15-000003 — 9.01
- 2015-01-15 0001104659-15-002635 — 5.02
- 2014-11-07 0001104659-14-078398 — 1.01, 8.01, 9.01
- 2014-10-30 0000926326-14-000037 — 2.02, 9.01
- 2014-08-25 0001104659-14-062772 — 8.01, 9.01
- 2014-07-31 0000926326-14-000032 — 2.02, 9.01
- 2014-05-21 0001104659-14-040744 — 5.07
- 2014-05-01 0000926326-14-000008 — 2.02, 9.01
- 2014-04-08 0001104659-14-026441 — 4.01, 9.01
- 2014-04-02 0001104659-14-025179 — 5.02
- 2014-02-07 0001104659-14-007552 — 5.02, 9.01
- 2014-02-04 0001104659-14-006352 — 2.02, 9.01
- 2013-12-09 0001104659-13-088980 — 1.01, 9.01
- 2013-12-02 0001104659-13-087877 — 5.02
- 2013-10-31 0001104659-13-079660 — 2.02, 9.01
- 2013-09-26 0001104659-13-072435 — 1.01, 2.03, 9.01
- 2013-08-01 0001104659-13-058959 — 2.02, 9.01
- 2013-05-23 0001104659-13-044317 — 5.07
- 2013-05-02 0001104659-13-036605 — 2.02, 9.01
- 2013-03-11 0001104659-13-019143 — 8.01
- 2013-02-07 0001104659-13-008477 — 5.02, 9.01
- 2013-01-31 0001104659-13-006446 — 2.02, 9.01
- 2012-11-02 0001104659-12-073697 — 5.02
- 2012-10-25 0001104659-12-071211 — 2.02, 9.01
- 2012-08-06 0001104659-12-054635 — 8.01
- 2012-08-03 0001104659-12-054214 — 2.01, 9.01 — amendment of 0001104659-12-038888
- 2012-08-01 0001104659-12-053005 — 2.02, 9.01
- 2012-06-12 0001104659-12-042936 — 8.01, 9.01
- 2012-05-23 0001104659-12-039459 — 5.07
- 2012-05-22 0001104659-12-038888 — 2.01, 9.01
- 2012-05-02 0001104659-12-032048 — 2.02, 9.01
- 2012-05-02 0001104659-12-032036 — 1.01, 9.01
- 2012-04-04 0001104659-12-023883 — 5.02, 8.01
- 2012-03-20 0001104659-12-019462 — 1.01, 9.01
- 2012-02-13 0001104659-12-009353 — 5.02, 9.01
- 2012-01-26 0001104659-12-004244 — 2.02, 9.01
- 2011-10-27 0001104659-11-058464 — 2.02, 9.01
- 2011-10-25 0001104659-11-057721 — 1.01
- 2011-07-28 0001104659-11-041505 — 2.02, 9.01
- 2011-05-27 0001104659-11-032006 — 5.07
- 2011-05-02 0001104659-11-024908 — 2.02, 9.01
- 2011-04-15 0001104659-11-020407 — 5.02, 9.01 — amendment of 0001104659-11-005638
- 2011-02-08 0001104659-11-005638 — 5.02, 9.01
- 2011-01-27 0001104659-11-003419 — 2.02, 9.01
- 2010-12-22 0001104659-10-064003 — 5.02, 5.07, 9.01
- 2010-10-27 0001104659-10-054036 — 2.02, 9.01
- 2010-10-05 0001104659-10-051173 — 8.01
- 2010-07-22 0001104659-10-039126 — 2.02, 9.01
- 2010-07-09 0001104659-10-037594 — 2.05
- 2010-05-28 0001104659-10-031607 — 5.07
- 2010-04-26 0001104659-10-021797 — 2.02, 9.01
- 2010-03-17 0001104659-10-014849 — 5.02, 9.01
- 2010-02-08 0001104659-10-005457 — 5.02, 9.01
- 2010-01-28 0001104659-10-003627 — 2.02, 9.01
- 2009-10-22 0001104659-09-059972 — 2.02, 9.01
- 2009-07-23 0001104659-09-044508 — 2.02, 9.01
- 2009-05-20 0001104659-09-033938 — 5.02, 9.01
- 2009-04-30 0001104659-09-027707 — 2.02, 9.01
- 2009-03-10 0001104659-09-016178 — 5.02, 9.01
- 2009-02-09 0001104659-09-007692 — 5.02, 9.01
- 2009-01-29 0001104659-09-005022 — 2.02, 2.05, 9.01
- 2009-01-21 0001104659-09-003180 — 2.02, 8.01, 9.01
- 2009-01-06 0001104659-09-000625 — 5.02
- 2008-10-23 0001104659-08-065475 — 2.02, 9.01
- 2008-07-21 0001104659-08-046690 — 2.02, 9.01
- 2008-05-16 0001104659-08-034035 — 8.01, 9.01
- 2008-04-28 0001104659-08-027379 — 7.01, 9.01
- 2008-04-21 0001104659-08-025616 — 2.02, 9.01
- 2008-03-12 0001104659-08-016939 — 7.01, 9.01
- 2008-02-26 0001104659-08-012840 — 7.01, 9.01
- 2008-02-12 0001104659-08-009382 — 5.02, 9.01
- 2008-01-31 0001104659-08-006199 — 2.02, 9.01
- 2007-12-05 0001104659-07-087191 — 1.01, 9.01
- 2007-10-18 0001104659-07-075654 — 2.02, 9.01
- 2007-07-27 0001104659-07-056886 — 5.03, 9.01
- 2007-07-19 0001104659-07-054924 — 2.02, 9.01
- 2007-05-23 0001104659-07-042287 — 8.01, 9.01
- 2007-05-07 0001104659-07-036172 — 1.01, 5.02, 9.01
- 2007-04-24 0001104659-07-030578 — 2.02, 9.01 — amendment, the index does not say of what
- 2007-04-24 0001104659-07-030547 — 2.02, 9.01
- 2007-04-10 0001104659-07-027465 — 5.02, 9.01
- 2007-03-23 0001104659-07-021969 — 2.02, 4.02, 9.01
- 2007-01-30 0001104659-07-005772 — 2.02, 9.01
- 2007-01-09 0001104659-07-001600 — 5.02, 9.01
- 2006-10-30 0001104659-06-069612 — 1.01
- 2006-10-19 0001104659-06-067549 — 2.02, 9.01
- 2006-07-20 0001104659-06-048020 — 2.02, 4.02, 9.01
- 2006-05-17 0001104659-06-035522 — 1.01, 9.01 — amendment of 0001104659-05-011155
- 2006-05-09 0001104659-06-032706 — 1.01, 9.01
- 2006-04-25 0001104659-06-027438 — 2.02, 9.01
- 2006-04-04 0001104659-06-022204 — 1.01, 9.01
- 2006-03-15 0001104659-06-016861 — 1.01, 9.01
- 2006-01-30 0001104659-06-004749 — 2.02, 9.01
- 2006-01-24 0001104659-06-003504 — 1.01, 5.02, 9.01
- 2005-12-13 0001104659-05-060532 — 1.01, 9.01
- 2005-11-10 0001104659-05-054663 — 2.02, 9.01
- 2005-07-21 0001104659-05-033464 — 2.02, 9.01
- 2005-06-22 0001104659-05-029255 — 1.01
- 2005-05-16 0001104659-05-023473 — 2.02, 9.01 — amendment of 0001104659-05-018173
- 2005-05-16 0001104659-05-023471 — 2.02, 9.01 — amendment of 0001104659-05-017382
- 2005-05-10 0001104659-05-022127 — 1.01
- 2005-04-26 0001104659-05-018173 — 2.02, 9.01
- 2005-04-21 0001104659-05-017382 — 2.02, 9.01
- 2005-04-06 0001104659-05-015401 — 5.02
- 2005-03-15 0001104659-05-011155 — 1.01, 9.01
- 2005-03-08 0001104659-05-009975 — 1.01, 9.01
- 2005-02-03 0001104659-05-003943 — 2.02, 9.01
- 2005-01-13 0001104659-05-001314 — 5.02, 9.01
- 2004-10-21 0001104659-04-031413 — 2.02, 9.01
- 2004-07-22 0001104659-04-020572 — 12, 7
- 2004-04-14 0001104659-04-010039 — 12, 7
- 2004-04-05 0001104659-04-009437 — 12, 7
- 2004-01-26 0001104659-04-001655 — 12, 7
- 2003-10-16 0001104659-03-022990 — 12, 7
- 2003-07-17 0001104659-03-015053 — 9
- 2003-04-18 0001104659-03-006823 — 7, 9
- 2003-02-14 0001104659-03-002607 — 5, 7

## late-filing notifications on or before 2024-08-06

- 2015-03-02 0000926326-15-000006 — NT 10-K, for the period ended 2014-12-31
- 2007-03-16 0001104659-07-020094 — NT 10-K, for the period ended 2006-12-31

## item 2.02 — earnings release, exhibit 99.1

[0000926326-24-000024:8k_2_02:1]
EX-99.1
2
exhibit991q2-24.htm
EX-99.1

[0000926326-24-000024:8k_2_02:2]
Document

[0000926326-24-000024:8k_2_02:3]
Exhibit 99.1

[0000926326-24-000024:8k_2_02:4]
| Contact: |  |  |
| Kathleen Nemeth |  | Omnicell, Inc. |
| Senior Vice President, Investor Relations |  | 4220 North Freeway |
| 650-435-3318 |  | Fort Worth, TX 76137 |
| Kathleen.Nemeth@Omnicell.com |  |  |

[0000926326-24-000024:8k_2_02:5]
Omnicell Announces Second Quarter 2024 Results

[0000926326-24-000024:8k_2_02:6]
Results exceed previously issued second quarter guidance across all metrics

[0000926326-24-000024:8k_2_02:7]
Total revenues of $277 million

[0000926326-24-000024:8k_2_02:8]
GAAP net income per diluted share of $0.08

[0000926326-24-000024:8k_2_02:9]
Non-GAAP net income per diluted share of $0.51

[0000926326-24-000024:8k_2_02:10]
Raises 2024 non-GAAP EBITDA and non-GAAP earnings per share guidance

[0000926326-24-000024:8k_2_02:11]
FORT WORTH, Texas -- August 1, 2024 -- Omnicell, Inc. (NASDAQ:OMCL) (“Omnicell,” “we,” “our,” “us,” “management,” or the “Company”), a leader in transforming the pharmacy care delivery model, today announced results for its second quarter ended June 30, 2024.

[0000926326-24-000024:8k_2_02:12]
Randall Lipps, chairman, president, chief executive officer, and founder of Omnicell, said, “We are pleased with the second quarter results that we announced today, which exceeded our previously issued guidance across all key metrics, including revenue, non-GAAP EBITDA and non-GAAP earnings per share. The strong results this quarter reflect improving macro trends and solid execution by the Omnicell team.”

[0000926326-24-000024:8k_2_02:13]
“We have concluded a holistic review of our business and have identified several potential areas across our operations where we believe we can drive synergies, streamline processes, and optimize our cost structure. We are investing in innovation to support our XT fleet and other areas of pharmacy automation, and it appears to be resonating well with our customers. The holistic business review validates our confidence in our refreshed strategy with an emphasis on connected devices, while also continuing to offer services that are expected to increase our recurring revenue. We are excited about our multiyear journey focused on bringing outcomes-centric solutions to the market. We remain confident in Omnicell’s long-term opportunities and intend to remain focused on strong execution and enhancing stockholders returns.” Mr. Lipps concluded.

[0000926326-24-000024:8k_2_02:14]
Financial Results

[0000926326-24-000024:8k_2_02:15]
Total revenues for the second quarter of 2024 were $277 million, down $22 million, or 7%, from the second quarter of 2023. The year-over-year decrease in total revenues reflects the impact of a continued challenging environment for some of our health system customers and the timing of our XT Series automated dispensing systems lifecycle, as we are largely through the replacement cycle.

[0000926326-24-000024:8k_2_02:16]
Total GAAP net income for the second quarter of 2024 was $4 million, or $0.08 per diluted share. This compares to GAAP net income of $3 million, or $0.08 per diluted share, for the second quarter of 2023.

[0000926326-24-000024:8k_2_02:17]
Total non-GAAP net income for the second quarter of 2024 was $24 million, or $0.51 per diluted share. This compares to non-GAAP net income of $26 million, or $0.57 per diluted share, for the second quarter of 2023.

[0000926326-24-000024:8k_2_02:18]
Total non-GAAP EBITDA for the second quarter of 2024 was $40 million. This compares to non-GAAP EBITDA of $47 million for the second quarter of 2023.

[0000926326-24-000024:8k_2_02:19]
Balance Sheet

[0000926326-24-000024:8k_2_02:20]
As of June 30, 2024, Omnicell’s balance sheet reflected cash and cash equivalents of $557 million, total debt (net of unamortized debt issuance costs) of $571 million, and total assets of $2.29 billion. Cash flows provided by operating activities in the second

[0000926326-24-000024:8k_2_02:21]
quarter of 2024 totaled $59 million. This compares to cash flows provided by operating activities totaling $73 million in the second quarter of 2023.

[0000926326-24-000024:8k_2_02:22]
As of June 30, 2024, the Company had $350 million of availability under its revolving credit facility with no outstanding balance.

[0000926326-24-000024:8k_2_02:23]
Corporate Highlights

[0000926326-24-000024:8k_2_02:24]
•Omnicell Central Pharmacy Dispensing Services are a cornerstone of Kentucky-based Baptist Health’s new Central Pharmacy Services Center, a 102,000-square-foot facility that will support medication management for its nine hospitals across Kentucky and surrounding states. Baptist Health selected Omnicell’s robotics and services in an effort to alleviate staffing challenges while focusing on improving quality, patient safety, and efficiency, which should allow them to advance closer to the industry-defined vision of the Autonomous Pharmacy.

[0000926326-24-000024:8k_2_02:25]
•XT Amplify is gaining market momentum as health systems are provided the opportunity to maximize value for their XT Series automated dispensing system technology through solutions like XTExtend, a comprehensive console swap that is intended to provide a high level of security while enhancing the nurse user experience. XT Amplify, launched earlier this year, is a multi-year innovation program focused on continuous innovation intended to drive enhanced clinical and operational outcomes at the points of care and within pharmacies.

[0000926326-24-000024:8k_2_02:26]
•Later today EnlivenHealth® will be issuing a press release announcing a strategic partnership for a new Scope of Practice and Reimbursement Snapshot, a first-of-its-kind solution that will give the strategic partner’s independent pharmacy members access to up-to-date information regarding clinical services they can provide in their state and reimbursement details for those services. We believe that providing this new service emphasizes EnlivenHealth’s commitment to elevating pharmacies to the forefront of healthcare by contributing to clinical service expansion and providing greater access to patient care through local independent pharmacies across the U.S.

[0000926326-24-000024:8k_2_02:27]
•Omnicell Specialty Pharmacy Services continues to enhance pharmacy performance and clinical outcomes for our customers. At the recent Healthcare Financial Management Association conference, the Administrative Director of Pharmacy and Supply Chain for Blessing Health System shared how an optimized approach to Specialty Pharmacy supports best-in-class patient care while driving growth.

[0000926326-24-000024:8k_2_02:28]
•Omnicell announced continued support for the global charity Mercy Ships with the donation of solutions from the recently announced XT Amplify program. Mercy Ships travels to developing nations to provide sorely needed, quality healthcare for underserved patients. With the recent donation of XTExtend, Omnicell will provide a comprehensive console swap for previously implemented XT Series automated dispensing systems to enhance security and improve the user experience.

[0000926326-24-000024:8k_2_02:29]
2024 Guidance

[0000926326-24-000024:8k_2_02:30]
Based on strong first half performance and current visibility of the business, the Company is updating the previously provided 2024 annual guidance metrics. For the full year 2024, the Company expects bookings to be between $775 million and $875 million. The Company expects full year 2024 total revenues to be between $1.070 billion and $1.110 billion. The Company expects full year 2024 product revenues to be between $610 million and $630 million, and full year 2024 service revenues to be between $460 million and $480 million. The Company expects full year 2024 technical services revenues to be between $230 million and $240 million, and full year 2024 Advanced Services revenues to be between $230 million and $240 million. The Company expects full year 2024 non-GAAP EBITDA to be between $105 million and $125 million. The Company expects full year 2024 non-GAAP earnings per share to be between $1.20 and $1.50 per share.

[0000926326-24-000024:8k_2_02:31]
For the third quarter of 2024, the Company expects total revenues to be between $275 million and $285 million. The Company expects third quarter 2024 product revenues to be between $159 million and $164 million, and third quarter 2024 service revenues to be between $116 million and $121 million. The Company expects third quarter 2024 non-GAAP EBITDA to be between $28 million and $34 million. The Company expects third quarter 2024 non-GAAP earnings per share to be between $0.34 and $0.44 per share.

[0000926326-24-000024:8k_2_02:32]
The table below summarizes Omnicell’s third quarter and full year 2024 guidance outlined above.

[0000926326-24-000024:8k_2_02:33]
|  | Q3 2024 |  | 2024 |
| Bookings | Not provided |  | $775 million - $875 million |
| Total Revenues | $275 million - $285 million |  | $1.070 billion - $1.110 billion |
| Product Revenues | $159 million - $164 million |  | $610 million - $630 million |
| Service Revenues | $116 million - $121 million |  | $460 million - $480 million |
| Technical Services Revenues | Not provided |  | $230 million - $240 million |
| Advanced Services Revenues | Not provided |  | $230 million - $240 million |
| Non-GAAP EBITDA | $28 million - $34 million |  | $105 million - $125 million |
| Non-GAAP Earnings Per Share | $0.34 - $0.44 |  | $1.20 - $1.50 |

[0000926326-24-000024:8k_2_02:34]
The Company does not provide guidance for GAAP net income or GAAP earnings per share, nor a reconciliation of these forward-looking non-GAAP financial measures to the most directly comparable GAAP financial measures on a forward-looking basis, because it is unable to predict certain items contained in the GAAP measures without unreasonable efforts. These forward-looking non-GAAP financial measures do not include certain items, which may be significant, including, but not limited to, unusual gains and losses, costs associated with future restructurings, acquisition-related expenses, and certain tax and litigation outcomes.

[0000926326-24-000024:8k_2_02:35]
Omnicell Conference Call Information

[0000926326-24-000024:8k_2_02:36]
Omnicell will hold a conference call today, Thursday, August 1, 2024 at 8:30 a.m. ET to discuss second quarter 2024 financial results. The conference call can be monitored by dialing (800) 715-9871 in the U.S. or (646) 307-1963 in international locations. The Conference ID is 3278878. A link to the live and archived webcast will also be available on the Investor Relations section of Omnicell’s website at http://ir.omnicell.com/events-and-presentations/.

[0000926326-24-000024:8k_2_02:37]
__________________________________________________

[0000926326-24-000024:8k_2_02:38]
About Omnicell

[0000926326-24-000024:8k_2_02:39]
Since 1992, Omnicell has been committed to transforming pharmacy care through outcomes-centric innovation designed to optimize clinical and business outcomes across all settings of care. Through a comprehensive portfolio of robotics, smart devices, intelligent software, and expert services, Omnicell solutions are helping healthcare facilities worldwide to reduce costs, improve labor efficiency, establish new revenue streams, enhance supply chain control, support compliance, and move closer to the industry vision of the Autonomous Pharmacy. To learn more, visit omnicell.com.

[0000926326-24-000024:8k_2_02:40]
From time to time, Omnicell may use the Company’s investor relations website and other online social media channels, including its LinkedIn page www.linkedin.com/company/omnicell and Facebook page www.facebook.com/omnicellinc, to disclose material non-public information and comply with its disclosure obligations under Regulation Fair Disclosure (“Reg FD”).

[0000926326-24-000024:8k_2_02:41]
OMNICELL, the Omnicell logo, and ENLIVENHEALTH are registered trademarks of Omnicell, Inc. or one of its subsidiaries.

[0000926326-24-000024:8k_2_02:42]
Forward-Looking Statements

[0000926326-24-000024:8k_2_02:43]
Use of Non-GAAP Financial Information

[0000926326-24-000024:8k_2_02:44]
This press release contains financial measures that are not calculated in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”). Management evaluates and makes operating decisions using various performance measures. In addition to Omnicell’s GAAP results, we also consider non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP operating margin, non-GAAP net income, non-GAAP net income per diluted share, non-GAAP diluted shares, non-GAAP EBITDA, non-GAAP EBITDA margin, and non-GAAP free cash flow. These non-GAAP results and metrics should not be considered as an alternative to revenues, gross profit, operating expenses, income from operations, net income, net income per diluted share, diluted shares, net cash provided by operating activities, or any other performance measure derived in accordance with GAAP. We present these non-GAAP results and metrics because management considers them to be important supplemental measures of Omnicell’s performance and refers to such measures when analyzing Omnicell’s strategy and operations.

[0000926326-24-000024:8k_2_02:45]
Our non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP operating margin, non-GAAP net income, non-GAAP net income per diluted share, non-GAAP EBITDA, and non-GAAP EBITDA margin are exclusive of certain items to facilitate management’s review of the comparability of Omnicell’s core operating results on a period-to-period basis because such items are not related to Omnicell’s ongoing core operating results as viewed by management. We define our “core operating results” as those revenues recorded in a particular period and the expenses incurred within such period that directly drive operating income in such period. Management uses these non-GAAP financial measures in making operating decisions because, in addition to meaningful supplemental information regarding operating performance, the measures give us a better understanding of how we believe we should invest in research and development, fund infrastructure growth, and evaluate the effectiveness of marketing strategies. In calculating the above non-GAAP results: non-GAAP gross profit and non-GAAP gross margin exclude from their GAAP equivalents items a), b), e), and g) below; non-GAAP operating expenses excludes from its GAAP equivalents items a), b), c), d), e), g and h) below; non-GAAP income from operations and non-GAAP operating margin exclude from their GAAP equivalents items a), b), c), d), e), g and h) below; and non-GAAP net income and non-GAAP net income per diluted share exclude from their GAAP equivalents items a) through h) below. Non-GAAP EBITDA is defined as earnings before interest income and expense, taxes, depreciation, amortization, and share-based compensation, as well as excluding certain other non-GAAP adjustments. Non-GAAP EBITDA and non-GAAP EBITDA margin exclude from their GAAP equivalents items a), c), d), e), f), g and h) below:

[0000926326-24-000024:8k_2_02:46]
a)Share-based compensation expense. We excluded from our non-GAAP results the expense related to equity-based compensation plans as it represents expenses that do not require cash settlement from Omnicell.

[0000926326-24-000024:8k_2_02:47]
4

[0000926326-24-000024:8k_2_02:48]
b)Amortization of acquired intangible assets. We excluded from our non-GAAP results the intangible assets amortization expense resulting from our past acquisitions. These non-cash charges are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results.

[0000926326-24-000024:8k_2_02:49]
c)Acquisition-related expenses. We excluded from our non-GAAP results the expenses related to recent acquisitions, including amortization of representations and warranties insurance. These expenses are unrelated to our ongoing operations, vary in size and frequency, and are subject to significant fluctuations from period to period due to varying levels of acquisition activity. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of peer companies.

[0000926326-24-000024:8k_2_02:50]
d)Impairment and abandonment of operating lease right-of-use and other assets related to facilities. We excluded from our non-GAAP results the impairment and abandonment of certain operating lease right-of-use assets, as well as property and equipment, incurred in connection with restructuring activities for optimization of certain leased facilities. These non-cash charges are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results.

[0000926326-24-000024:8k_2_02:51]
e)Severance-related expenses. We excluded from our non-GAAP results the expenses related to restructuring events. These expenses are unrelated to our ongoing operations, vary in size and frequency, and are subject to significant fluctuations from period to period due to varying levels of restructuring activity. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of peer companies.

[0000926326-24-000024:8k_2_02:52]
f)Amortization of debt issuance costs. Debt issuance costs represent costs associated with the issuance of revolving credit facilities and convertible senior notes. The costs include underwriting fees, original issue discount, ticking fees, and legal fees. These non-cash expenses are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results.

[0000926326-24-000024:8k_2_02:53]
g)RDS restructuring. We excluded from our non-GAAP results the nonrecurring restructuring charges related to the wind down of the Company’s Medimat Robotic Dispensing System (“RDS”) product line. For the period ended June 30, 2024, those charges consisted primarily of inventory write-down, severance and other related expenses. These expenses are unrelated to our ongoing operations and we believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of peer companies.

[0000926326-24-000024:8k_2_02:54]
h)Executives transition costs. We excluded from our non-GAAP results the executives transition costs associated with the departure of certain executive officers, primarily consisting of severance expenses. These expenses are unrelated to our ongoing operations and we do not expect them to occur in the ordinary course of business. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of peer companies.

[0000926326-24-000024:8k_2_02:55]
Management adjusts for the above items because management believes that, in general, these items possess one or more of the following characteristics: their magnitude and timing is largely outside of Omnicell’s control; they are unrelated to the ongoing operation of the business in the ordinary course; they are unusual and we do not expect them to occur in the ordinary course of business; or they are non-operational or non-cash expenses involving stock compensation plans or other items.

[0000926326-24-000024:8k_2_02:56]
We believe that the presentation of non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP operating margin, non-GAAP net income, non-GAAP net income per diluted share, non-GAAP EBITDA, and non-GAAP EBITDA margin is warranted for several reasons:

[0000926326-24-000024:8k_2_02:57]
a)Such non-GAAP financial measures provide an additional analytical tool for understanding Omnicell’s financial performance by excluding the impact of items which may obscure trends in the core operating results of the business.

[0000926326-24-000024:8k_2_02:58]
b)Since we have historically reported non-GAAP results to the investment community, we believe the inclusion of non-GAAP numbers provides consistency and enhances investors’ ability to compare our performance across financial reporting periods.

[0000926326-24-000024:8k_2_02:59]
c)These non-GAAP financial measures are employed by management in its own evaluation of performance and are utilized in financial and operational decision-making processes, such as budget planning and forecasting.

[0000926326-24-000024:8k_2_02:60]
d)These non-GAAP financial measures facilitate comparisons to the operating results of other companies in our industry, which also use non-GAAP financial measures to supplement their GAAP results (although these companies may calculate non-GAAP financial measures differently than Omnicell does), thus enhancing the perspective of investors who wish to utilize such comparisons in their analysis of our performance.

[0000926326-24-000024:8k_2_02:61]
Set forth below are additional reasons why share-based compensation expense is excluded from our non-GAAP financial measures:

[0000926326-24-000024:8k_2_02:62]
i)While share-based compensation calculated in accordance with Accounting Standards Codification (“ASC”) 718 constitutes an ongoing and recurring expense of Omnicell, it is not an expense that requires cash settlement by Omnicell. We therefore exclude these charges for purposes of evaluating core operating results. Thus, our non-GAAP measurements are presented exclusive of share-based compensation expense to assist management and investors in evaluating our core operating results.

[0000926326-24-000024:8k_2_02:63]
ii)We present ASC 718 share-based payment compensation expense in our reconciliation of non-GAAP financial measures on a pre-tax basis because the exact tax differences related to the timing and deductibility of share-based compensation under ASC 718 are dependent upon the trading price of Omnicell’s common stock and the timing and exercise by employees of their stock options. As a result of these timing and market uncertainties, the tax effect related to share-based compensation expense would be inconsistent in amount and frequency and is therefore excluded from our non-GAAP results.

[0000926326-24-000024:8k_2_02:64]
Non-GAAP diluted shares is defined as our GAAP diluted shares, excluding the impact of dilutive convertible senior notes for which the Company is economically hedged through its anti-dilutive convertible note hedge transaction. We believe non-GAAP diluted shares is a useful non-GAAP metric because it provides insight into the offsetting economic effect of the hedge transaction against potential conversion of the convertible senior notes.

[0000926326-24-000024:8k_2_02:65]
Non-GAAP free cash flow is defined as net cash provided by operating activities less cash used for software development for external use and purchases of property and equipment. We believe free cash flow is important to enable investors to better understand and evaluate our ongoing operating results and allows for greater transparency in the review and understanding of our overall financial, operational, and economic performance, because free cash flow takes into account certain capital expenditures and cash used for software development necessary to operate our business.

[0000926326-24-000024:8k_2_02:66]
As stated above, we present non-GAAP financial measures because we consider them to be important supplemental measures of performance. However, non-GAAP financial measures have limitations as an analytical tool and should not be considered in isolation or as a substitute for Omnicell’s GAAP results. In the future, we expect to incur expenses similar to certain of the non-GAAP adjustments described above and expect to continue reporting non-GAAP financial measures excluding such items. Some of the limitations in relying on non-GAAP financial measures are:

[0000926326-24-000024:8k_2_02:67]
a)Omnicell’s equity incentive plans and stock purchase plans are important components of incentive compensation arrangements and will be reflected as expenses in Omnicell’s GAAP results for the foreseeable future under ASC 718.

[0000926326-24-000024:8k_2_02:68]
b)Other companies, including companies in Omnicell’s industry, may calculate non-GAAP financial measures differently than Omnicell, limiting their usefulness as a comparative measure.

[0000926326-24-000024:8k_2_02:69]
c)A limitation of the utility of free cash flow as a measure of financial performance is that it does not represent the total increase or decrease in Omnicell’s cash balance for the period.

[0000926326-24-000024:8k_2_02:70]
A detailed reconciliation between Omnicell’s non-GAAP and GAAP financial results is set forth in the financial tables at the end of this press release. Investors are advised to carefully review and consider this information strictly as a supplement to the GAAP results that are contained in this press release as well as in Omnicell’s other reports filed with or furnished to the SEC.

[0000926326-24-000024:8k_2_02:71]
Omnicell, Inc.

[0000926326-24-000024:8k_2_02:72]
Condensed Consolidated Statements of Operations

[0000926326-24-000024:8k_2_02:73]
(Unaudited, in thousands, except per share data)

[0000926326-24-000024:8k_2_02:74]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Revenues: |  |  |  |  |  |  |  |
| Product revenues | $ | 156,580 |  |  | $ | 188,436 |  |  | $ | 289,875 |  |  | $ | 374,151 |  |
| Service revenues | 120,208 |  |  | 110,537 |  |  | 233,064 |  |  | 215,451 |  |
| Total revenues | 276,788 |  |  | 298,973 |  |  | 522,939 |  |  | 589,602 |  |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | 99,381 |  |  | 107,962 |  |  | 191,822 |  |  | 217,489 |  |
| Cost of service revenues | 63,056 |  |  | 56,568 |  |  | 124,143 |  |  | 112,641 |  |
| Total cost of revenues | 162,437 |  |  | 164,530 |  |  | 315,965 |  |  | 330,130 |  |
| Gross profit | 114,351 |  |  | 134,443 |  |  | 206,974 |  |  | 259,472 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 21,102 |  |  | 23,137 |  |  | 43,158 |  |  | 46,015 |  |
| Selling, general, and administrative | 90,025 |  |  | 103,558 |  |  | 182,439 |  |  | 228,672 |  |
| Total operating expenses | 111,127 |  |  | 126,695 |  |  | 225,597 |  |  | 274,687 |  |
| Income (loss) from operations | 3,224 |  |  | 7,748 |  |  | (18,623) |  |  | (15,215) |  |
| Interest and other income (expense), net | 4,973 |  |  | 4,461 |  |  | 8,989 |  |  | 6,242 |  |
| Income (loss) before income taxes | 8,197 |  |  | 12,209 |  |  | (9,634) |  |  | (8,973) |  |
| Provision for income taxes | 4,462 |  |  | 8,758 |  |  | 2,307 |  |  | 2,576 |  |
| Net income (loss) | $ | 3,735 |  |  | $ | 3,451 |  |  | $ | (11,941) |  |  | $ | (11,549) |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.08 |  |  | $ | 0.08 |  |  | $ | (0.26) |  |  | $ | (0.26) |  |
| Diluted | $ | 0.08 |  |  | $ | 0.08 |  |  | $ | (0.26) |  |  | $ | (0.26) |  |
| Weighted-average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 45,953 |  |  | 45,125 |  |  | 45,842 |  |  | 45,007 |  |
| Diluted | 46,036 |  |  | 45,472 |  |  | 45,842 |  |  | 45,007 |  |

[0000926326-24-000024:8k_2_02:75]
7

[0000926326-24-000024:8k_2_02:76]
Omnicell, Inc.

[0000926326-24-000024:8k_2_02:77]
Condensed Consolidated Balance Sheets

[0000926326-24-000024:8k_2_02:78]
(Unaudited, in thousands)

[0000926326-24-000024:8k_2_02:79]
|  | June 30,2024 |  | December 31,2023 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 556,781 |  |  | $ | 467,972 |  |
| Accounts receivable and unbilled receivables, net | 241,127 |  |  | 252,025 |  |
| Inventories | 93,262 |  |  | 110,099 |  |
| Prepaid expenses | 22,216 |  |  | 25,966 |  |
| Other current assets | 82,282 |  |  | 71,509 |  |
| Total current assets | 995,668 |  |  | 927,571 |  |
| Property and equipment, net | 110,982 |  |  | 108,601 |  |
| Long-term investment in sales-type leases, net | 50,302 |  |  | 42,954 |  |
| Operating lease right-of-use assets | 26,438 |  |  | 24,988 |  |
| Goodwill | 735,351 |  |  | 735,810 |  |
| Intangible assets, net | 199,425 |  |  | 211,173 |  |
| Long-term deferred tax assets | 40,555 |  |  | 32,901 |  |
| Prepaid commissions | 49,882 |  |  | 52,414 |  |
| Other long-term assets | 83,054 |  |  | 90,466 |  |
| Total assets | $ | 2,291,657 |  |  | $ | 2,226,878 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 49,747 |  |  | $ | 45,028 |  |
| Accrued compensation | 48,940 |  |  | 51,754 |  |
| Accrued liabilities | 158,119 |  |  | 149,276 |  |
| Deferred revenues | 150,316 |  |  | 121,734 |  |
| Total current liabilities | 407,122 |  |  | 367,792 |  |
| Long-term deferred revenues | 67,931 |  |  | 58,622 |  |
| Long-term deferred tax liabilities | 1,326 |  |  | 1,620 |  |
| Long-term operating lease liabilities | 33,739 |  |  | 33,910 |  |
| Other long-term liabilities | 7,514 |  |  | 6,318 |  |
| Convertible senior notes, net | 571,217 |  |  | 569,662 |  |
| Total liabilities | 1,088,849 |  |  | 1,037,924 |  |
| Total stockholders’ equity | 1,202,808 |  |  | 1,188,954 |  |
| Total liabilities and stockholders’ equity | $ | 2,291,657 |  |  | $ | 2,226,878 |  |

[0000926326-24-000024:8k_2_02:80]
Omnicell, Inc.

[0000926326-24-000024:8k_2_02:81]
Condensed Consolidated Statements of Cash Flows

[0000926326-24-000024:8k_2_02:82]
(Unaudited, in thousands)

[0000926326-24-000024:8k_2_02:83]
|  | Six Months Ended June 30, |
|  | 2024 |  | 2023 |
| Operating Activities |  |  |  |
| Net loss | $ | (11,941) |  |  | $ | (11,549) |  |
| Adjustments to reconcile net loss to net cash provided by operating activities: |
| Depreciation and amortization | 42,090 |  |  | 44,054 |  |
| Loss on disposal of assets | 221 |  |  | 993 |  |
| Share-based compensation expense | 18,672 |  |  | 28,131 |  |
| Deferred income taxes | (7,948) |  |  | (11,019) |  |
| Amortization of operating lease right-of-use assets | 3,900 |  |  | 4,225 |  |
| Impairment and abandonment of operating lease right-of-use assets related to facilities | — |  |  | 7,815 |  |
| Inventory write-down | 5,393 |  |  | — |  |
| Amortization of debt issuance costs | 1,943 |  |  | 2,091 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable and unbilled receivables | 10,898 |  |  | 26,463 |  |
| Inventories | 11,160 |  |  | 17,820 |  |
| Prepaid expenses | 3,750 |  |  | 3,576 |  |
| Other current assets | 5,868 |  |  | 773 |  |
| Investment in sales-type leases | (8,056) |  |  | (1,707) |  |
| Prepaid commissions | 2,532 |  |  | 4,706 |  |
| Other long-term assets | 1,218 |  |  | 43 |  |
| Accounts payable | 4,751 |  |  | (15,806) |  |
| Accrued compensation | (2,814) |  |  | (20,980) |  |
| Accrued liabilities | 9,247 |  |  | (4,646) |  |
| Deferred revenues | 22,085 |  |  | 16,540 |  |
| Operating lease liabilities | (5,512) |  |  | (5,396) |  |
| Other long-term liabilities | 1,196 |  |  | (454) |  |
| Net cash provided by operating activities | 108,653 |  |  | 85,673 |  |
| Investing Activities |  |  |  |
| External-use software development costs | (7,381) |  |  | (6,685) |  |
| Purchases of property and equipment | (18,508) |  |  | (21,772) |  |
| Net cash used in investing activities | (25,889) |  |  | (28,457) |  |
| Financing Activities |  |  |  |
| Proceeds from issuances under stock-based compensation plans | 8,141 |  |  | 15,203 |  |
| Employees’ taxes paid related to restricted stock units | (1,291) |  |  | (3,465) |  |
| Change in customer funds, net | (11,552) |  |  | (4,273) |  |
| Net cash provided by (used in) financing activities | (4,702) |  |  | 7,465 |  |
| Effect of exchange rate changes on cash and cash equivalents | (802) |  |  | 148 |  |
| Net increase in cash, cash equivalents, and restricted cash | 77,260 |  |  | 64,829 |  |
| Cash, cash equivalents, and restricted cash at beginning of period | 500,979 |  |  | 352,835 |  |
| Cash, cash equivalents, and restricted cash at end of period | $ | 578,239 |  |  | $ | 417,664 |  |
| Reconciliation of cash, cash equivalents, and restricted cash to the Condensed Consolidated Balance Sheets: |
| Cash and cash equivalents | $ | 556,781 |  |  | $ | 399,464 |  |
| Restricted cash included in other current assets | 21,458 |  |  | 18,200 |  |
| Cash, cash equivalents, and restricted cash at end of period | $ | 578,239 |  |  | $ | 417,664 |  |

[0000926326-24-000024:8k_2_02:84]
9

[0000926326-24-000024:8k_2_02:85]
Omnicell, Inc.

[0000926326-24-000024:8k_2_02:86]
Reconciliation of GAAP to Non-GAAP

[0000926326-24-000024:8k_2_02:87]
(Unaudited, in thousands, except per share data and percentage)

[0000926326-24-000024:8k_2_02:88]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Reconciliation of GAAP gross profit to non-GAAP gross profit: |  |  |  |  |  |
| GAAP gross profit | $ | 114,351 |  |  | $ | 134,443 |  |  | $ | 206,974 |  |  | $ | 259,472 |  |
| GAAP gross margin | 41.3% |  | 45.0% |  | 39.6% |  | 44.0% |
| Share-based compensation expense | 1,620 |  |  | 2,268 |  |  | 3,175 |  |  | 4,276 |  |
| Amortization of acquired intangibles | 970 |  |  | 2,900 |  |  | 2,090 |  |  | 5,925 |  |
| RDS restructuring | 5,348 |  |  | — |  |  | 8,044 |  |  | — |  |
| Severance-related expenses | — |  |  | 238 |  |  | — |  |  | 382 |  |
| Non-GAAP gross profit | $ | 122,289 |  |  | $ | 139,849 |  |  | $ | 220,283 |  |  | $ | 270,055 |  |
| Non-GAAP gross margin | 44.2% |  | 46.8% |  | 42.1% |  | 45.8% |
| Reconciliation of GAAP operating expenses to non-GAAP operating expenses: |  |  |  |  |
| GAAP operating expenses | $ | 111,127 |  |  | $ | 126,695 |  |  | $ | 225,597 |  |  | $ | 274,687 |  |
| GAAP operating expenses % to total revenues | 40.1% |  | 42.4% |  | 43.1% |  | 46.6% |
| Share-based compensation expense | (8,411) |  |  | (11,821) |  |  | (15,497) |  |  | (23,855) |  |
| Amortization of acquired intangibles | (4,702) |  |  | (5,135) |  |  | (9,542) |  |  | (10,352) |  |
| Acquisition-related expenses | (246) |  |  | (246) |  |  | (492) |  |  | (492) |  |
| Impairment and abandonment of operating lease right-of-use and other assets related to facilities | — |  |  | — |  |  | — |  |  | (8,420) |  |
| RDS restructuring | (291) |  |  | — |  |  | (867) |  |  | — |  |
| Executives transition costs | — |  |  | (841) |  |  | — |  |  | (841) |  |
| Severance-related expenses | — |  |  | (483) |  |  | — |  |  | (5,653) |  |
| Non-GAAP operating expenses | $ | 97,477 |  |  | $ | 108,169 |  |  | $ | 199,199 |  |  | $ | 225,074 |  |
| Non-GAAP operating expenses as a % of total revenues | 35.2% |  | 36.2% |  | 38.1% |  | 38.2% |
| Reconciliation of GAAP income (loss) from operations to non-GAAP income from operations: |
| GAAP income (loss) from operations | $ | 3,224 |  |  | $ | 7,748 |  |  | $ | (18,623) |  |  | $ | (15,215) |  |
| GAAP operating loss % to total revenues | 1.2% |  | 2.6% |  | (3.6)% |  | (2.6)% |
| Share-based compensation expense | 10,031 |  |  | 14,089 |  |  | 18,672 |  |  | 28,131 |  |
| Amortization of acquired intangibles | 5,672 |  |  | 8,035 |  |  | 11,632 |  |  | 16,277 |  |
| Acquisition-related expenses | 246 |  |  | 246 |  |  | 492 |  |  | 492 |  |
| Impairment and abandonment of operating lease right-of-use and other assets related to facilities | — |  |  | — |  |  | — |  |  | 8,420 |  |
| RDS restructuring | 5,639 |  |  | — |  |  | 8,911 |  |  | — |  |
| Executives transition costs | — |  |  | 841 |  |  | — |  |  | 841 |  |
| Severance-related expenses | — |  |  | 721 |  |  | — |  |  | 6,035 |  |
| Non-GAAP income from operations | $ | 24,812 |  |  | $ | 31,680 |  |  | $ | 21,084 |  |  | $ | 44,981 |  |
| Non-GAAP operating margin (non-GAAP operating income as a % of total revenues) | 9.0% |  | 10.6% |  | 4.0% |  | 7.6% |

[0000926326-24-000024:8k_2_02:89]
Omnicell, Inc.

[0000926326-24-000024:8k_2_02:90]
Reconciliation of GAAP to Non-GAAP

[0000926326-24-000024:8k_2_02:91]
(Unaudited, in thousands, except per share data and percentage)

[0000926326-24-000024:8k_2_02:92]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Reconciliation of GAAP net income (loss) to non-GAAP net income: |
| GAAP net income (loss) | $ | 3,735 |  |  | $ | 3,451 |  |  | $ | (11,941) |  |  | $ | (11,549) |  |
| Share-based compensation expense | 10,031 |  |  | 14,089 |  |  | 18,672 |  |  | 28,131 |  |
| Amortization of acquired intangibles | 5,672 |  |  | 8,035 |  |  | 11,632 |  |  | 16,277 |  |
| Acquisition-related expenses | 246 |  |  | 246 |  |  | 492 |  |  | 492 |  |
| Impairment and abandonment of operating lease right-of-use and other assets related to facilities | — |  |  | — |  |  | — |  |  | 8,420 |  |
| RDS restructuring | 5,639 |  |  | — |  |  | 8,911 |  |  | — |  |
| Executives transition costs | — |  |  | 841 |  |  | — |  |  | 841 |  |
| Severance-related expenses | — |  |  | 721 |  |  | — |  |  | 6,035 |  |
| Amortization of debt issuance costs | 972 |  |  | 1,046 |  |  | 1,943 |  |  | 2,091 |  |
| Tax effect of the adjustments above (a) | (2,631) |  |  | (2,287) |  |  | (4,825) |  |  | (7,173) |  |
| Non-GAAP net income | $ | 23,664 |  |  | $ | 26,142 |  |  | $ | 24,884 |  |  | $ | 43,565 |  |
| Reconciliation of GAAP net income (loss) per share - diluted to non-GAAP net income per share - diluted: |
| Shares - diluted GAAP | 46,036 |  |  | 45,472 |  |  | 45,842 |  |  | 45,007 |  |
| Shares - diluted non-GAAP | 46,036 |  |  | 45,472 |  |  | 45,905 |  |  | 45,306 |  |
| GAAP net income (loss) per share - diluted | $ | 0.08 |  |  | $ | 0.08 |  |  | $ | (0.26) |  |  | $ | (0.26) |  |
| Share-based compensation expense | 0.22 |  |  | 0.31 |  |  | 0.42 |  |  | 0.62 |  |
| Amortization of acquired intangibles | 0.12 |  |  | 0.17 |  |  | 0.25 |  |  | 0.36 |  |
| Acquisition-related expenses | 0.01 |  |  | 0.01 |  |  | 0.01 |  |  | 0.01 |  |
| Impairment and abandonment of operating lease right-of-use and other assets related to facilities | — |  |  | — |  |  | — |  |  | 0.19 |  |
| RDS restructuring | 0.12 |  |  | — |  |  | 0.19 |  |  | — |  |
| Executives transition costs | — |  |  | 0.02 |  |  | — |  |  | 0.02 |  |
| Severance-related expenses | — |  |  | 0.02 |  |  | — |  |  | 0.13 |  |
| Amortization of debt issuance costs | 0.02 |  |  | 0.02 |  |  | 0.04 |  |  | 0.05 |  |
| Tax effect of the adjustments above (a) | (0.06) |  |  | (0.06) |  |  | (0.11) |  |  | (0.16) |  |
| Non-GAAP net income per share - diluted | $ | 0.51 |  |  | $ | 0.57 |  |  | $ | 0.54 |  |  | $ | 0.96 |  |
| Reconciliation of GAAP net income (loss) to non-GAAP EBITDA (b): |
| GAAP net income (loss) | $ | 3,735 |  |  | $ | 3,451 |  |  | $ | (11,941) |  |  | $ | (11,549) |  |
| Share-based compensation expense | 10,031 |  |  | 14,089 |  |  | 18,672 |  |  | 28,131 |  |
| Interest (income) and expense, net | (6,073) |  |  | (4,410) |  |  | (11,788) |  |  | (7,484) |  |
| Depreciation and amortization expense | 20,837 |  |  | 22,080 |  |  | 42,090 |  |  | 44,054 |  |
| Acquisition-related expenses | 246 |  |  | 246 |  |  | 492 |  |  | 492 |  |
| Impairment and abandonment of operating lease right-of-use and other assets related to facilities | — |  |  | — |  |  | — |  |  | 8,420 |  |
| RDS restructuring | 5,639 |  |  | — |  |  | 8,911 |  |  | — |  |
| Executives transition costs | — |  |  | 841 |  |  | — |  |  | 841 |  |
| Severance-related expenses | — |  |  | 721 |  |  | — |  |  | 6,035 |  |
| Amortization of debt issuance costs | 972 |  |  | 1,046 |  |  | 1,943 |  |  | 2,091 |  |
| Benefit from income taxes | 4,462 |  |  | 8,758 |  |  | 2,307 |  |  | 2,576 |  |
| Non-GAAP EBITDA | $ | 39,849 |  |  | $ | 46,822 |  |  | $ | 50,686 |  |  | $ | 73,607 |  |
| Non-GAAP EBITDA margin (non-GAAP EBITDA as a % of total revenues) | 14.4% |  | 15.7% |  | 9.7% |  | 12.5% |

[0000926326-24-000024:8k_2_02:93]
_________________________________________________

[0000926326-24-000024:8k_2_02:94]
(a)Tax effects calculated for all adjustments except share-based compensation expense, using an estimated annual effective tax rate of 21% for both fiscal years 2024 and 2023.

[0000926326-24-000024:8k_2_02:95]
(b)Defined as earnings before interest income and expense, taxes, depreciation, amortization, and share-based compensation, as well as excluding certain other non-GAAP adjustments.

[0000926326-24-000024:8k_2_02:96]
11

[0000926326-24-000024:8k_2_02:97]
Omnicell, Inc.

[0000926326-24-000024:8k_2_02:98]
Reconciliation of GAAP to Non-GAAP

[0000926326-24-000024:8k_2_02:99]
(Unaudited, in thousands)

[0000926326-24-000024:8k_2_02:100]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Reconciliation of GAAP net cash provided by operating activities to non-GAAP free cash flow: |
| GAAP net cash provided by operating activities | $ | 58,700 |  |  | $ | 72,903 |  |  | $ | 108,653 |  |  | $ | 85,673 |  |
| External-use software development costs | (3,998) |  |  | (3,186) |  |  | (7,381) |  |  | (6,685) |  |
| Purchases of property and equipment | (9,551) |  |  | (11,631) |  |  | (18,508) |  |  | (21,772) |  |
| Non-GAAP free cash flow | $ | 45,151 |  |  | $ | 58,086 |  |  | $ | 82,764 |  |  | $ | 57,216 |  |
