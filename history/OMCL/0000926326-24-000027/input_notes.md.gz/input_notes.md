# OMCL notes — 0000926326-24-000027


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000926326-24-000027:notes:1]
[same as prior period, unchanged from 0000926326-24-000015:notes:1]

[0000926326-24-000027:notes:2]
[same as prior period, unchanged from 0000926326-24-000015:notes:2]

[0000926326-24-000027:notes:3]
[same as prior period, unchanged from 0000926326-24-000015:notes:3]

[0000926326-24-000027:notes:4]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of June 30, 2024 and December 31, 2023, the results of operations and comprehensive income (loss) for the three and six months ended June 30, 2024 and 2023, and cash flows for the six months ended June 30, 2024 and 2023. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s Annual Report on Form 10-K for the year ended December 31, 2023, filed with the SEC on February 28, 2024. The Company’s results of operations and comprehensive income (loss) for the three and six months ended June 30, 2024, and cash flows for the six months ended June 30, 2024 are not necessarily indicative of results that may be expected for the year ending December 31, 2024, or for any future period.

[0000926326-24-000027:notes:5]
[same as prior period, unchanged from 0000926326-24-000015:notes:5]

[0000926326-24-000027:notes:6]
[same as prior period, unchanged from 0000926326-24-000015:notes:6]

[0000926326-24-000027:notes:7]
[same as prior period, unchanged from 0000926326-24-000015:notes:7]

[0000926326-24-000027:notes:8]
[same as prior period, unchanged from 0000926326-24-000015:notes:8]

[0000926326-24-000027:notes:9]
The Company’s critical accounting policies are those that affect its financial statements materially and involve difficult, subjective, or complex judgments by management. As of June 30, 2024, the Company is not aware of any events or circumstances that would require an update to its estimates, judgments, or revisions to the carrying value of its assets or liabilities.

[0000926326-24-000027:notes:10]
[same as prior period, unchanged from 0000926326-24-000015:notes:10]

[0000926326-24-000027:notes:11]
[same as prior period, unchanged from 0000926326-24-000015:notes:11]

[0000926326-24-000027:notes:12]
[same as prior period, unchanged from 0000926326-24-000015:notes:12]

[0000926326-24-000027:notes:13]
[same as prior period, unchanged from 0000926326-24-000015:notes:13]

[0000926326-24-000027:notes:14]
[same as prior period, unchanged from 0000926326-24-000015:notes:14]

[0000926326-24-000027:notes:15]
In November 2023, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures, which requires public entities to disclose significant segment expenses that are regularly provided to the CODM. Public entities with a single reportable segment are required to apply the disclosure requirements in ASU 2023-07, as well as all existing segment disclosures and reconciliation requirements in ASC 280, on an interim and annual basis. The amendments are effective for the Company’s annual periods beginning January 1, 2024, and for interim periods within fiscal years beginning January 1, 2025. Retrospective application is required, with early adoption permitted. The Company is currently evaluating the impact ASU 2023-07 will have on its consolidated financial statements.

[0000926326-24-000027:notes:16]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which includes amendments that further enhance income tax disclosures, primarily through standardization and disaggregation of rate reconciliation categories and income taxes paid by jurisdiction. The amendments are effective for the Company’s annual periods beginning January 1, 2025, with early adoption permitted, and should be applied either prospectively or retrospectively. The Company is currently evaluating the impact ASU 2023-09 will have on its consolidated financial statements.

[0000926326-24-000027:notes:17]
In March 2024, the SEC issued final rules under SEC Release No. 33-11275, “The Enhancement and Standardization of Climate-Related Disclosures for Investors,” to require registrants to disclose certain climate-related information, including Scope 1 and Scope 2 greenhouse gas emissions and other climate-related topics, if material, in registration statements and annual reports. In April 2024, the SEC voluntarily stayed its climate disclosure rules as a result of pending legal challenges to facilitate an orderly judicial resolution. The Company is currently evaluating the impact the SEC’s rule will have on its consolidated financial statements.

[0000926326-24-000027:notes:18]
[same as prior period, unchanged from 0000926326-24-000015:notes:17]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000926326-24-000027:notes:19]
[same as prior period, unchanged from 0000926326-24-000015:notes:18]

[0000926326-24-000027:notes:20]
[same as prior period, unchanged from 0000926326-24-000015:notes:19]

[0000926326-24-000027:notes:21]
[same as prior period, unchanged from 0000926326-24-000015:notes:20]

[0000926326-24-000027:notes:22]
[same as prior period, unchanged from 0000926326-24-000015:notes:21]

[0000926326-24-000027:notes:23]
[same as prior period, unchanged from 0000926326-24-000015:notes:22]

[0000926326-24-000027:notes:24]
[same as prior period, unchanged from 0000926326-24-000015:notes:23]

[0000926326-24-000027:notes:25]
[same as prior period, unchanged from 0000926326-24-000015:notes:24]

[0000926326-24-000027:notes:26]
| Revenue Category |  |  |  | Timing of Revenue Recognition |  | Income Statement Classification |
| Connected devices, software licenses, and other |  |  |  | Point in time, as transfer of control occurs, generally upon installation and acceptance by the customer |  | Product |
| Consumables |  |  |  | Point in time, as transfer of control occurs, generally upon shipment to, or receipt by, the customer |  | Product |
| Technical services |  |  |  | Over time, as services are provided, typically ratably over the service term |  | Service |
| Advanced Services |  |  |  | Over time, as services are provided |  | Service |

[0000926326-24-000027:notes:27]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”) and Federal agencies that purchase under a Federal Supply Schedule Contract with the Department of Veterans Affairs (the “GSA Contract”). GPOs are often fully or partially owned by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company also pays the Industrial Funding Fee (“IFF”) to the Department of Veterans Affairs under the GSA Contract. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs and the IFF were $2.4 million and $2.8 million for the three months ended June 30, 2024 and 2023, respectively, and $4.4 million and $5.9 million for the six months ended June 30, 2024 and 2023, respectively.

[0000926326-24-000027:notes:28]
[same as prior period, unchanged from 0000926326-24-000015:notes:28]

[0000926326-24-000027:notes:29]
The following table summarizes the Company’s revenues disaggregated by revenue type for the three and six months ended June 30, 2024 and 2023:

[0000926326-24-000027:notes:30]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  | (In thousands) |
| Connected devices, software licenses, and other | $ | 134,539 |  |  | $ | 167,475 |  |  | $ | 245,608 |  |  | $ | 332,622 |  |
| Consumables | 22,041 |  |  | 20,961 |  |  | 44,267 |  |  | 41,529 |  |
| Technical services | 59,321 |  |  | 57,191 |  |  | 117,836 |  |  | 110,548 |  |
| Advanced Services | 60,887 |  |  | 53,346 |  |  | 115,228 |  |  | 104,903 |  |
| Total revenues | $ | 276,788 |  |  | $ | 298,973 |  |  | $ | 522,939 |  |  | $ | 589,602 |  |

[0000926326-24-000027:notes:31]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location, for the three and six months ended June 30, 2024 and 2023:

[0000926326-24-000027:notes:32]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  | (In thousands) |
| United States | $ | 255,317 |  |  | $ | 257,202 |  |  | $ | 473,493 |  |  | $ | 513,145 |  |
| Rest of world (1) | 21,471 |  |  | 41,771 |  |  | 49,446 |  |  | 76,457 |  |
| Total revenues | $ | 276,788 |  |  | $ | 298,973 |  |  | $ | 522,939 |  |  | $ | 589,602 |  |

[0000926326-24-000027:notes:33]
[same as prior period, unchanged from 0000926326-24-000015:notes:33]

[0000926326-24-000027:notes:34]
[same as prior period, unchanged from 0000926326-24-000015:notes:34]

[0000926326-24-000027:notes:35]
[same as prior period, unchanged from 0000926326-24-000015:notes:35]

[0000926326-24-000027:notes:36]
[same as prior period, unchanged from 0000926326-24-000015:notes:36]

[0000926326-24-000027:notes:37]
|  | June 30,2024 |  | December 31,2023 |
|  | (In thousands) |
| Short-term unbilled receivables, net (1) | $ | 25,122 |  |  | $ | 22,524 |  |
| Long-term unbilled receivables, net (2) | 9,901 |  |  | 11,850 |  |
| Total contract assets | $ | 35,023 |  |  | $ | 34,374 |  |
| Short-term deferred revenues | $ | 150,316 |  |  | $ | 121,734 |  |
| Long-term deferred revenues | 67,931 |  |  | 58,622 |  |
| Total contract liabilities | $ | 218,247 |  |  | $ | 180,356 |  |

[0000926326-24-000027:notes:38]
[same as prior period, unchanged from 0000926326-24-000015:notes:38]

[0000926326-24-000027:notes:39]
[same as prior period, unchanged from 0000926326-24-000015:notes:39]

[0000926326-24-000027:notes:40]
[same as prior period, unchanged from 0000926326-24-000015:notes:40]

[0000926326-24-000027:notes:41]
Short-term deferred revenues of $121.7 million as of December 31, 2023 include deferred revenues from product sales and service contracts, net of deferred cost of sales of $12.4 million. During the three and six months ended June 30, 2024, the Company recognized revenues of $34.8 million and $85.0 million, respectively, that were included in the corresponding gross short-term deferred revenues balance of $134.1 million as of December 31, 2023.

[0000926326-24-000027:notes:42]
Deferred revenues from product sales primarily relate to delivered and invoiced products, pending installation and acceptance. Deferred revenues from service contracts primarily relate to services that have been invoiced, where services have not yet been provided. Short-term deferred revenues are expected to be recognized within the next twelve months. Long-term deferred revenues substantially consist of deferred revenues on long-term technical and Advanced Services contracts which have been invoiced and are expected to be recognized as revenue beyond twelve months, generally not more than ten years. The Company generally invoices customers for products upon shipment. Invoicing associated with the service portion of agreements is generally periodic and is billed on a monthly, quarterly, or annual basis, and in certain circumstances, multiple years are billed at one time. Advanced Services agreements are generally invoiced periodically on a monthly, quarterly or annual basis over the life of the agreement. In certain circumstances, portions of these agreements may be invoiced as a lump sum.

[0000926326-24-000027:notes:43]
In addition, the Company has remaining performance obligations associated with contracts for which the associated products have been accepted or associated services have started, but where invoicing has not yet occurred and therefore are not reflected in deferred revenue. These remaining performance obligations are comprised of the non-variable portions of technical services and Advanced Services provided under non-cancellable contracts with minimum commitments. Remaining performance obligations which are not included in deferred revenues were $387.7 million as of June 30, 2024. Remaining performance obligations are expected to be recognized ratably over the remaining terms of the associated contracts, which terms vary but are generally not more than ten years. Remaining performance obligations do not include product obligations, services where the associated product has not been accepted, services which have not yet started, variable portions of services, and certain other obligations.

[0000926326-24-000027:notes:44]
[same as prior period, unchanged from 0000926326-24-000015:notes:45]

[0000926326-24-000027:notes:45]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three and six months ended June 30, 2024 and 2023. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable balance as of June 30, 2024 and December 31, 2023.


## us-gaap:EarningsPerShareTextBlock

[0000926326-24-000027:notes:46]
Net Income (Loss) Per Share
The basic and diluted net income (loss) per share calculations for the three and six months ended June 30, 2024 and 2023 were as follows:

[0000926326-24-000027:notes:47]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  | (In thousands, except per share data) |
| Net income (loss) | $ | 3,735 |  |  | $ | 3,451 |  |  | $ | (11,941) |  |  | $ | (11,549) |  |
| Weighted-average shares outstanding – basic | 45,953 |  |  | 45,125 |  |  | 45,842 |  |  | 45,007 |  |
| Effect of dilutive securities from stock award plans | 83 |  |  | 347 |  |  | — |  |  | — |  |
| Weighted-average shares outstanding – diluted | 46,036 |  |  | 45,472 |  |  | 45,842 |  |  | 45,007 |  |
| Net income (loss) per share – basic | $ | 0.08 |  |  | $ | 0.08 |  |  | $ | (0.26) |  |  | $ | (0.26) |  |
| Net income (loss) per share – diluted | $ | 0.08 |  |  | $ | 0.08 |  |  | $ | (0.26) |  |  | $ | (0.26) |  |
| Anti-dilutive weighted-average shares related to stock award plans | 2,719 |  |  | 2,512 |  |  | 3,247 |  |  | 3,530 |  |
| Anti-dilutive weighted-average shares related to convertible senior notes and warrants | 11,816 |  |  | 11,816 |  |  | 11,816 |  |  | 11,816 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000926326-24-000027:notes:48]
Cash and Cash Equivalents and Fair Value of Financial Instruments
Cash and cash equivalents of $556.8 million and $468.0 million as of June 30, 2024 and December 31, 2023, respectively, consisted of bank accounts and highly-liquid U.S. Government money market funds held in sweep and asset management accounts with financial institutions of high credit quality. As of June 30, 2024 and December 31, 2023, cash equivalents were $529.3 million and $451.0 million, respectively, which consisted of money market funds held in sweep and asset management accounts.

[0000926326-24-000027:notes:49]
Fair Value Hierarchy
The Company measures its financial instruments at fair value. The Company’s cash, cash equivalents, and restricted cash are classified within Level 1 of the fair value hierarchy as they are valued primarily using quoted market prices utilizing market observable inputs. The Company’s credit facility is classified within Level 2 as the valuation inputs are based on quoted prices or market observable data of similar instruments. The Company’s convertible senior notes are classified within Level 2 as the valuation inputs are based on quoted prices in an inactive market on the last day in the reporting period. As of June 30, 2024 and December 31, 2023, the fair value of the convertible senior notes was $539.8 million and $527.2 million, respectively, compared to their carrying values of $571.2 million and $569.7 million, respectively, which are net of unamortized debt issuance costs. Refer to Note 9, Debt and Credit Agreement, for further information regarding the Company’s credit facility and Note 10, Convertible Senior Notes, for further information regarding the Company’s convertible senior notes.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000926326-24-000027:notes:50]
Balance Sheet Components
Balance sheet details as of June 30, 2024 and December 31, 2023 are presented in the tables below:

[0000926326-24-000027:notes:51]
|  | June 30,2024 |  | December 31,2023 |
|  | (In thousands) |
| Inventories: |  |  |  |
| Raw materials | $ | 39,162 |  |  | $ | 51,439 |  |
| Work in process | 2,077 |  |  | 1,327 |  |
| Finished goods | 52,023 |  |  | 57,333 |  |
| Total inventories | $ | 93,262 |  |  | $ | 110,099 |  |
| Other current assets: |  |  |  |
| Funds held for customers, including restricted cash (1) | $ | 43,488 |  |  | $ | 43,649 |  |
| Net investment in sales-type leases, current portion | 12,575 |  |  | 11,867 |  |
| Prepaid income taxes | 2,568 |  |  | 8,279 |  |
| Other current assets (2) | 23,651 |  |  | 7,714 |  |
| Total other current assets | $ | 82,282 |  |  | $ | 71,509 |  |
| Other long-term assets: |  |  |  |
| External-use software development costs, net | $ | 60,853 |  |  | $ | 66,659 |  |
| Unbilled receivables, net | 9,901 |  |  | 11,850 |  |
| Deferred debt issuance costs | 3,328 |  |  | 3,718 |  |
| Other long-term assets | 8,972 |  |  | 8,239 |  |
| Total other long-term assets | $ | 83,054 |  |  | $ | 90,466 |  |
| Accrued liabilities: |  |  |  |
| Operating lease liabilities, current portion | $ | 10,465 |  |  | $ | 10,518 |  |
| Customer fund liabilities | 43,488 |  |  | 43,649 |  |
| Advance payments from customers | 10,542 |  |  | 10,551 |  |
| Rebate liabilities | 57,056 |  |  | 51,277 |  |
| Group purchasing organization fees | 4,409 |  |  | 4,445 |  |
| Taxes payable | 4,594 |  |  | 2,191 |  |
| Other accrued liabilities | 27,565 |  |  | 26,645 |  |
| Total accrued liabilities | $ | 158,119 |  |  | $ | 149,276 |  |

[0000926326-24-000027:notes:52]
(1)    Includes restricted cash of $21.5 million and $33.0 million as of June 30, 2024 and December 31, 2023, respectively.

[0000926326-24-000027:notes:53]
(2)    Includes deferred cost of sales of $16.1 million as of June 30, 2024.

[0000926326-24-000027:notes:54]
The following table summarizes the changes in accumulated balances of other comprehensive income (loss), which consisted of foreign currency translation adjustments, for the three and six months ended June 30, 2024 and 2023:

[0000926326-24-000027:notes:55]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  | (In thousands) |
| Beginning balance | $ | (14,831) |  |  | $ | (15,608) |  |  | $ | (13,432) |  |  | $ | (17,087) |  |
| Other comprehensive income (loss) | (47) |  |  | 1,432 |  |  | (1,446) |  |  | 2,911 |  |
| Ending balance | $ | (14,878) |  |  | $ | (14,176) |  |  | $ | (14,878) |  |  | $ | (14,176) |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000926326-24-000027:notes:56]
Property and Equipment
The following table represents the property and equipment balances as of June 30, 2024 and December 31, 2023:

[0000926326-24-000027:notes:57]
|  | June 30,2024 |  | December 31,2023 |
|  | (In thousands) |
| Equipment | $ | 102,044 |  |  | $ | 95,996 |  |
| Furniture and fixtures | 5,191 |  |  | 4,500 |  |
| Leasehold improvements | 17,859 |  |  | 17,919 |  |
| Purchased software and internal-use software development costs | 138,030 |  |  | 118,004 |  |
| Construction in progress | 8,184 |  |  | 11,614 |  |
| Property and equipment, gross | 271,308 |  |  | 248,033 |  |
| Accumulated depreciation and amortization | (160,326) |  |  | (139,432) |  |
| Total property and equipment, net | $ | 110,982 |  |  | $ | 108,601 |  |

[0000926326-24-000027:notes:58]
Depreciation and amortization expense of property and equipment was $8.7 million and $6.6 million for the three months ended June 30, 2024 and 2023, respectively, and $17.3 million and $12.9 million for the six months ended June 30, 2024 and 2023, respectively.

[0000926326-24-000027:notes:59]
The geographic location of the Company’s property and equipment, net, is based on the physical location in which it is located. The following table summarizes the geographic information for property and equipment, net, as of June 30, 2024 and December 31, 2023:

[0000926326-24-000027:notes:60]
|  | June 30,2024 |  | December 31,2023 |
|  | (In thousands) |
| United States | $ | 106,685 |  |  | $ | 104,312 |  |
| Rest of world | 4,297 |  |  | 4,289 |  |
| Total property and equipment, net | $ | 110,982 |  |  | $ | 108,601 |  |


## us-gaap:ResearchDevelopmentAndComputerSoftwareDisclosureTextBlock

[0000926326-24-000027:notes:61]
External-Use Software Development Costs
The carrying amounts of external-use software development costs as of June 30, 2024 and December 31, 2023 were as follows:

[0000926326-24-000027:notes:62]
|  | June 30,2024 |  | December 31,2023 |
|  | (In thousands) |
| Gross carrying amount | $ | 240,466 |  |  | $ | 239,038 |  |
| Accumulated amortization | (179,613) |  |  | (172,379) |  |
| External-use software development costs, net (1) | $ | 60,853 |  |  | $ | 66,659 |  |

[0000926326-24-000027:notes:63]
[same as prior period, unchanged from 0000926326-24-000015:notes:65]

[0000926326-24-000027:notes:64]
The Company recorded $6.4 million and $7.4 million to cost of revenues for amortization of external-use software development costs for the three months ended June 30, 2024 and 2023, respectively, and $13.1 million and $14.8 million for the six months ended June 30, 2024 and 2023, respectively.

[0000926326-24-000027:notes:65]
[same as prior period, unchanged from 0000926326-24-000015:notes:67]

[0000926326-24-000027:notes:66]
|  | June 30,2024 |
|  | (In thousands) |
| Remaining six months of 2024 | $ | 11,975 |  |
| 2025 | 19,772 |  |
| 2026 | 14,331 |  |
| 2027 | 8,398 |  |
| 2028 | 4,541 |  |
| Thereafter | 1,836 |  |
| Total | $ | 60,853 |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000926326-24-000027:notes:67]
[same as prior period, unchanged from 0000926326-24-000015:notes:69]

[0000926326-24-000027:notes:68]
[same as prior period, unchanged from 0000926326-24-000015:notes:70]

[0000926326-24-000027:notes:69]
|  |  |  |  |  | (In thousands) |
| Balance as of December 31, 2023 |  |  |  |  | $ | 735,810 |  |
| Foreign currency exchange rate fluctuations |  |  |  |  | (459) |  |
| Balance as of June 30, 2024 |  |  |  |  | $ | 735,351 |  |

[0000926326-24-000027:notes:70]
[same as prior period, unchanged from 0000926326-24-000015:notes:72]

[0000926326-24-000027:notes:71]
The carrying amounts and useful lives of intangible assets as of June 30, 2024 and December 31, 2023 were as follows:

[0000926326-24-000027:notes:72]
|  | June 30, 2024 |
|  | Gross carryingamount (1) |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 307,418 |  |  | $ | (124,314) |  |  | $ | (1,352) |  |  | $ | 181,752 |  |  | 4 - 30 |
| Acquired technology | 46,134 |  |  | (30,380) |  |  | — |  |  | 15,754 |  |  | 4 - 20 |
| Trade names | 9,200 |  |  | (8,140) |  |  | — |  |  | 1,060 |  |  | 5 - 12 |
| Patents | 2,322 |  |  | (1,463) |  |  | — |  |  | 859 |  |  | 2 - 20 |
| Total intangible assets, net | $ | 365,074 |  |  | $ | (164,297) |  |  | $ | (1,352) |  |  | $ | 199,425 |  |  |  |

[0000926326-24-000027:notes:73]
[same as prior period, unchanged from 0000926326-24-000015:notes:75]

[0000926326-24-000027:notes:74]
[same as prior period, unchanged from 0000926326-24-000015:notes:76]

[0000926326-24-000027:notes:75]
Amortization expense of intangible assets was $5.7 million and $8.1 million for the three months ended June 30, 2024 and 2023, respectively, and $11.7 million and $16.4 million for the six months ended June 30, 2024 and 2023, respectively.

[0000926326-24-000027:notes:76]
[same as prior period, unchanged from 0000926326-24-000015:notes:78]

[0000926326-24-000027:notes:77]
|  | June 30,2024 |
|  | (In thousands) |
| Remaining six months of 2024 | $ | 11,066 |  |
| 2025 | 21,063 |  |
| 2026 | 18,076 |  |
| 2027 | 16,225 |  |
| 2028 | 15,184 |  |
| Thereafter | 117,811 |  |
| Total | $ | 199,425 |  |


## us-gaap:DebtDisclosureTextBlock

[0000926326-24-000027:notes:78]
Debt and Credit Agreement
On November 15, 2019, Omnicell, Inc. entered into an Amended and Restated Credit Agreement (as amended, the “Prior A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers, and Wells Fargo Bank, National Association, as administrative agent. As referred to herein, “Omnicell, Inc.” refers only to Omnicell, Inc., excluding its subsidiaries. The Prior A&R Credit Agreement provided for (a) a five-year revolving credit facility of $500.0 million (the “Prior Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million (the “Prior Incremental Facility”). In addition, the Prior A&R Credit Agreement included a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The Prior A&R Credit Agreement was subsequently amended on September 22, 2020 and March 29, 2023, to permit the issuance of the convertible senior notes and the purchase of the convertible note hedge transactions (as described in Note 10, Convertible Senior Notes, of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q), expand the Company’s flexibility to make restricted payments (including common stock repurchases), and replace the total net leverage covenant, as well as to remove and replace the interest rate benchmark based on the London interbank offered rate (“LIBOR”) and related LIBOR-based mechanics with an interest rate benchmark based on the secured overnight financing rate (“SOFR”) as administered by the Federal Reserve Bank of New York and related SOFR-based mechanics.

[0000926326-24-000027:notes:79]
Omnicell, Inc. entered into a Second Amended and Restated Credit Agreement (the “Second A&R Credit Agreement”) on October 10, 2023, with the lenders from time to time party thereto, Wells Fargo Securities, LLC, JPMorgan Chase Bank, N.A., PNC Capital Markets LLC and TD Securities (USA) LLC as joint lead arrangers and Wells Fargo Bank, National Association, as administrative agent. The Second A&R Credit Agreement supersedes the Prior A&R Credit Agreement and provides for (a) a five-year revolving credit facility of $350.0 million (the “Current Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to an amount equal to the sum of (i) the greater of $250.0 million and 100% of the adjusted consolidated EBITDA for the last four quarters and (ii) additional amounts subject to pro forma compliance with certain consolidated secured net leverage ratio (the “Current Incremental Facility”). In addition, the Second A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The Second A&R Credit Agreement has an expiration date of October 10, 2028, subject to acceleration under certain conditions, upon which date all remaining outstanding borrowings will be due and payable.

[0000926326-24-000027:notes:80]
Loans under the Current Revolving Credit Facility bear interest, at Omnicell, Inc.’s option, at a rate equal to either (a) the Adjusted Term SOFR (as defined in the Second A&R Credit Agreement), plus an applicable margin ranging from 1.50% to 2.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the Second A&R Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) the Adjusted Term SOFR for an interest period of one month plus 1.00%, plus an applicable margin ranging from 0.50% to 1.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio. Undrawn commitments under the Current Revolving Credit Facility are subject to a commitment fee ranging from 0.20% to 0.35% per annum based on the Company’s Consolidated Total Net Leverage Ratio on the average daily unused portion of the Current Revolving Credit Facility. Subject to the terms and conditions of the Current Revolving Credit Facility or Current Incremental Facility Omnicell, Inc. is permitted to make voluntary prepayments at any time without payment of a premium or penalty. The availability of funds under the Current

[0000926326-24-000027:notes:81]
Revolving Credit Facility may be subject to reduction in order to maintain compliance with the financial covenants under the Second A&R Credit Agreement.

[0000926326-24-000027:notes:82]
The Second A&R Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends, and other distributions. The Second A&R Credit Agreement contains financial covenants that require the Company to not exceed a maximum consolidated secured net leverage ratio (not to exceed 3.00:1) and maintain a minimum consolidated interest coverage ratio (not to be less than 3.00:1). In addition, the Second A&R Credit Agreement contains certain customary events of default including, but not limited to, failure to pay interest, principal, and fees, or other amounts when due, material misrepresentations or misstatements in any representation or warranty, covenant defaults, certain cross defaults to other material indebtedness, certain judgment defaults, and events of bankruptcy.

[0000926326-24-000027:notes:83]
Omnicell, Inc.’s obligations under the Second A&R Credit Agreement and, at the election of Omnicell, Inc. and the contracting counterparty, any secured swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and such subsidiary guarantors’ assets. In connection with entering into the Second A&R Credit Agreement, and as a condition precedent to borrowing loans thereunder, Omnicell, Inc. and certain of Omnicell, Inc.’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a reaffirmation agreement, which amends certain terms of the existing collateral agreement and reaffirms their obligations under the existing guaranty agreement.

[0000926326-24-000027:notes:84]
The refinancing of the Prior Credit Agreement on October 10, 2023 was evaluated in accordance with ASC 470-50, Debt - Modifications and Extinguishments. In determining whether the refinancing was to be accounted for as a debt extinguishment or a debt modification, the Company considered whether lenders within the syndicate remained the same or changed and whether the changes in debt terms were substantial. This assessment was performed on an individual lender basis within the syndicate. As a result, the refinancing was accounted for as a modification with the exception of certain lenders that exited the syndicate. The exit of certain lenders resulted in an immaterial write-off of existing unamortized debt issuance costs. The remaining unamortized debt issuance costs related to debt modification, along with the new deferred costs, will be amortized over the remaining term of the Second A&R Credit Agreement. The Company incurred and capitalized an additional $3.0 million of debt issuance costs which are being amortized to interest expense using the straight-line method through 2028.

[0000926326-24-000027:notes:85]
As of both June 30, 2024 and December 31, 2023, the Company had $350.0 million of funds available under the Current Revolving Credit Facility. As of June 30, 2024 and December 31, 2023, the Company had no outstanding balance under the Current Revolving Credit Facility. The Company was in compliance with all covenants as of June 30, 2024.
Convertible Senior Notes
0.25% Convertible Senior Notes due 2025

[0000926326-24-000027:notes:86]
On September 25, 2020, the Company completed a private offering of $575.0 million aggregate principal amount of 0.25% convertible senior notes (the “Notes”), including the exercise in full of the initial purchasers’ option to purchase up to an additional $75.0 million principal amount of the Notes. The Company received proceeds from the issuance of the Notes of $559.7 million, net of $15.3 million of transaction fees and other debt issuance costs. The Notes bear interest at a rate of 0.25% per year, payable semiannually in arrears on March 15 and September 15 of each year, beginning on March 15, 2021. The Notes were issued pursuant to an indenture, dated September 25, 2020 (the “Indenture”), between the Company and U.S. Bank National Association, as trustee. The Notes are general senior, unsecured obligations of the Company and will mature on September 15, 2025, unless earlier redeemed, repurchased, or converted.

[0000926326-24-000027:notes:87]
The Notes are convertible at the option of the holders at any time prior to the close of business on the business day immediately preceding May 15, 2025, only under the following circumstances: (i) during any fiscal quarter commencing after the fiscal quarter ended on December 31, 2020 (and only during such fiscal quarter), if the last reported sale price of the Company’s common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on, and including, the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the Notes on each applicable trading day; (ii) during the five business day period after any ten consecutive trading day period (the “measurement period”) in which the trading price (as defined in the Indenture) per $1,000 principal amount of the Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of the Company’s common stock and the conversion rate for the Notes on each such trading day; (iii) if the Company calls such Notes for redemption, at any time prior to the close of business on the scheduled trading day immediately preceding the redemption date, but only with respect to the Notes called (or deemed called) for redemption; and (iv) upon the occurrence of specified corporate events, as specified in the Indenture. On or after May 15, 2025 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders of the Notes may convert all or any portion of their Notes at any time, regardless of the foregoing conditions.

[0000926326-24-000027:notes:88]
During the three months ended June 30, 2024 and December 31, 2023, none of the conditional conversion features of the Notes were triggered, and therefore, the Notes are not convertible during the third quarter of 2024, commencing on July 1, 2024, and were not convertible during the first quarter of 2024, commencing on January 1, 2024. Accordingly, the Company classified the Notes as a long-term liability in its Condensed Consolidated Financial Statements as of both June 30, 2024 and December 31, 2023. Whether the Notes will be convertible following the third fiscal quarter of 2024 will depend on the satisfaction of the conversion conditions in the future.

[0000926326-24-000027:notes:89]
Under the original terms of the Indenture, upon conversion, the Company could satisfy its conversion obligation by paying or delivering cash, shares of its common stock, or a combination thereof, at the Company’s election, in the manner and subject to the terms and conditions provided in the Indenture. On December 13, 2021, the Company irrevocably elected to fix its settlement method to a combination of cash and shares of the Company’s common stock with the specified cash amount per $1,000 principal amount of Notes of at least $1,000. As a result, for Notes converted on or after December 13, 2021, a converting noteholder will receive (i) up to $1,000 in cash per $1,000 principal amount of Notes and (ii) cash and/or shares of the Company’s common stock, at the Company’s option for any conversion consideration in excess of $1,000. In addition, the Company continues to have the ability to set the specified cash amount per $1,000 principal amount of Notes above $1,000. The initial conversion rate for the Notes is 10.2751 shares of the Company’s common stock per $1,000 principal amount of Notes, which is equivalent to an initial conversion price of approximately $97.32 per share of the Company’s common stock, subject to adjustment under certain circumstances in accordance with the terms of the Indenture. In addition, following certain corporate events that could occur prior to the maturity date of the Notes or if the Company delivers a notice of redemption in respect of the Notes, the Company will, under certain circumstances, increase the conversion rate of the Notes for a holder who elects to convert its Notes (or any portion thereof) in connection with such a corporate event or convert its Notes called (or deemed called) for redemption during the related redemption period (as defined in the Indenture), as the case may be.

[0000926326-24-000027:notes:90]
If the Company undergoes a fundamental change, holders may require, subject to certain exceptions, the Company to repurchase for cash all or any portion of their Notes at a fundamental change repurchase price equal to 100% of the principal amount of the Notes to be repurchased, plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date. As of June 30, 2024, none of the criteria for a fundamental change or a conversion rate adjustment had been met.

[0000926326-24-000027:notes:91]
As of June 30, 2024, the Company may redeem for cash all or any portion of the Notes, at its option, if the last reported sale price of the Company’s common stock has been at least 130% of the conversion price for the Notes then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which the Company provides notice of redemption at a redemption price equal to 100% of the principal amount of the Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. If the Company redeems less than all of the outstanding Notes, at least $150.0 million aggregate principal amount of Notes must be outstanding and not subject to redemption as of the date of the relevant notice of redemption. No sinking fund is provided for in the Notes.

[0000926326-24-000027:notes:92]
The debt issuance costs associated with the Notes are being amortized to interest expense over the term of the Notes using an effective interest rate of 0.80%. As of June 30, 2024, the remaining life of the Notes and the related issuance cost accretion is approximately 1.2 years.

[0000926326-24-000027:notes:93]
The maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to other conversion rate adjustments, would be 5.9 million shares. As of June 30, 2024, the if-converted value of the Notes did not exceed the principal amount.

[0000926326-24-000027:notes:94]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of June 30, 2024 and December 31, 2023:

[0000926326-24-000027:notes:95]
|  | June 30,2024 |  | December 31,2023 |
|  | (In thousands) |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized debt issuance costs | (3,783) |  |  | (5,338) |  |
| Convertible senior notes, net | $ | 571,217 |  |  | $ | 569,662 |  |

[0000926326-24-000027:notes:96]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three and six months ended June 30, 2024 and 2023:

[0000926326-24-000027:notes:97]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  | (In thousands) |
| Contractual coupon interest | $ | 359 |  |  | $ | 359 |  |  | $ | 719 |  |  | $ | 719 |  |
| Amortization of debt issuance costs | $ | 778 |  |  | $ | 772 |  |  | $ | 1,555 |  |  | $ | 1,543 |  |

[0000926326-24-000027:notes:98]
Convertible Note Hedge and Warrant Transactions

[0000926326-24-000027:notes:99]
In connection with the issuance of the Notes in September 2020, the Company entered into convertible note hedge and warrant transactions with an affiliate of one of the initial purchasers of the Notes and certain other financial institutions (the “option counterparties”) with respect to the Company’s common stock.

[0000926326-24-000027:notes:100]
The convertible note hedge consists of an option for the Company to purchase up to approximately 5.9 million shares of the Company’s common stock, which is equal to the number of shares of the Company’s common stock underlying the Notes, at an initial strike price of approximately $97.32 per share. The convertible note hedge will expire upon the maturity of the Notes, if not earlier exercised or terminated. The cost of the convertible note hedge was approximately $100.6 million and was accounted for as an equity instrument, which was recorded in additional paid-in capital in the Condensed Consolidated Balance Sheets. The Company recorded a deferred tax asset of $25.8 million at issuance related to the convertible note hedge transaction. The convertible note hedge is expected generally to reduce the potential dilution to the Company’s common stock upon any conversion of Notes and/or offset any cash payments the Company is required to make in excess of the principal amount of converted Notes.

[0000926326-24-000027:notes:101]
Separately from the convertible note hedge, in September 2020, the Company entered into warrant transactions to sell to the option counterparties warrants to acquire, subject to customary anti-dilution adjustments, up to approximately 5.9 million shares of its common stock in the aggregate at an initial strike price of $141.56 per share. The warrants require net share or net cash settlement upon the Company’s election. The Company received aggregate proceeds of approximately $51.3 million for the issuance of the warrants, which was recorded in additional paid-in capital at issuance in the Condensed Consolidated Balance Sheets. The warrants could separately have a dilutive effect to the Company’s common stock to the extent that the market price per share of its common stock exceeds the strike price of the warrants.


## us-gaap:LessorSalesTypeLeasesTextBlock

[0000926326-24-000027:notes:102]
Lessor Leases
Sales-Type Leases

[0000926326-24-000027:notes:103]
The Company enters into non-cancelable sales-type lease arrangements with the leases varying in length from one to ten years. The Company optimizes cash flows by selling a majority of its sales-type leases, other than those relating to U.S. government hospitals and Advanced Services products, including Central Pharmacy Dispensing Service and IV Compounding Service, to third-party leasing finance companies on a non-recourse basis. The Company has no obligation to the leasing company once the lease has been sold.

[0000926326-24-000027:notes:104]
The following table presents the Company’s income recognized from sales-type leases for the three and six months ended June 30, 2024 and 2023:

[0000926326-24-000027:notes:105]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  | (In thousands) |
| Sales-type lease revenues | $ | 11,576 |  |  | $ | 7,856 |  |  | $ | 18,612 |  |  | $ | 13,572 |  |
| Cost of sales-type lease revenues | (7,110) |  |  | (4,380) |  |  | (11,297) |  |  | (7,042) |  |
| Selling profit on sales-type lease revenues | $ | 4,466 |  |  | $ | 3,476 |  |  | $ | 7,315 |  |  | $ | 6,530 |  |

[0000926326-24-000027:notes:106]
The receivables as a result of these types of transactions are collateralized by the underlying equipment leased and consist of the following components at June 30, 2024 and December 31, 2023:

[0000926326-24-000027:notes:107]
|  | June 30,2024 |  | December 31,2023 |
|  | (In thousands) |
| Net minimum lease payments to be received | $ | 75,410 |  |  | $ | 65,017 |  |
| Less: Unearned interest income portion | (12,533) |  |  | (10,196) |  |
| Net investment in sales-type leases | 62,877 |  |  | 54,821 |  |
| Less: Current portion (1) | (12,575) |  |  | (11,867) |  |
| Long-term investment in sales-type leases, net | 50,302 |  |  | 42,954 |  |

[0000926326-24-000027:notes:108]
(1)    The current portion of the net investment in sales-type leases is included in other current assets in the Condensed Consolidated Balance Sheets.

[0000926326-24-000027:notes:109]
The carrying amount of the Company’s sales-type lease receivables is a reasonable estimate of fair value.

[0000926326-24-000027:notes:110]
The maturity schedule of future minimum lease payments under sales-type leases retained in-house and the reconciliation to the net investment in sales-type leases reported on the Condensed Consolidated Balance Sheets was as follows:

[0000926326-24-000027:notes:111]
|  | June 30,2024 |
|  | (In thousands) |
| Remaining six months of 2024 | $ | 8,163 |  |
| 2025 | 14,493 |  |
| 2026 | 12,431 |  |
| 2027 | 10,780 |  |
| 2028 | 9,692 |  |
| Thereafter | 19,851 |  |
| Total future minimum sales-type lease payments | 75,410 |  |
| Present value adjustment | (12,533) |  |
| Total net investment in sales-type leases | $ | 62,877 |  |

[0000926326-24-000027:notes:112]
Operating Leases

[0000926326-24-000027:notes:113]
The following table represents the Company’s income recognized from operating leases for the three and six months ended June 30, 2024 and 2023:

[0000926326-24-000027:notes:114]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  | (In thousands) |
| Rental income | $ | 711 |  |  | $ | 1,870 |  |  | $ | 1,567 |  |  | $ | 4,129 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0000926326-24-000027:notes:115]
Lessee Leases 
The Company has operating leases for office buildings, data centers, office equipment, and vehicles. The Company’s leases have initial terms of one to twelve years. As of June 30, 2024, the Company did not have any additional material operating leases that were entered into, but not yet commenced.

[0000926326-24-000027:notes:116]
[same as prior period, unchanged from 0000926326-24-000015:notes:121]

[0000926326-24-000027:notes:117]
|  | June 30,2024 |
|  | (In thousands) |
| Remaining six months of 2024 | $ | 6,354 |  |
| 2025 | 12,278 |  |
| 2026 | 11,426 |  |
| 2027 | 9,478 |  |
| 2028 | 8,174 |  |
| Thereafter | 2,242 |  |
| Total operating lease payments | 49,952 |  |
| Present value adjustment | (5,748) |  |
| Total operating lease liabilities (1) | $ | 44,204 |  |

[0000926326-24-000027:notes:118]
(1)    Amount consists of a current and long-term portion of operating lease liabilities of $10.5 million and $33.7 million, respectively. The current portion of the operating lease liabilities is included in accrued liabilities in the Condensed Consolidated Balance Sheets.

[0000926326-24-000027:notes:119]
Operating lease costs were $2.6 million and $2.6 million for the three months ended June 30, 2024 and 2023, respectively, and $5.2 million and $5.6 million for the six months ended June 30, 2024 and 2023, respectively. Short-term lease costs and variable lease costs were not material for the three and six months ended June 30, 2024 and 2023. The Company recorded impairment and abandonment charges to operating lease right-of-use assets of $7.8 million during the six months ended June 30, 2023, in connection with restructuring activities to reduce its real estate footprint and for optimization of certain leased facilities. The impairment and abandonment charges were recorded to selling, general, and administrative expenses on the Company’s Condensed Consolidated Statements of Operations. Refer to Note 16, Restructuring Expenses, for additional information regarding the Company’s restructuring activities.

[0000926326-24-000027:notes:120]
The following table summarizes supplemental cash flow information related to the Company’s operating leases for the six months ended June 30, 2024 and 2023:

[0000926326-24-000027:notes:121]
|  | Six Months Ended June 30, |
|  | 2024 |  | 2023 |
|  | (In thousands) |
| Cash paid for amounts included in the measurement of lease liabilities | $ | 6,765 |  |  | $ | 6,725 |  |
| Right-of-use assets obtained in exchange for new lease liabilities | $ | 5,509 |  |  | $ | 1,608 |  |

[0000926326-24-000027:notes:122]
The following table summarizes the weighted-average remaining lease term and weighted-average discount rate related to the Company’s operating leases as of June 30, 2024 and December 31, 2023:

[0000926326-24-000027:notes:123]
|  | June 30,2024 |  | December 31,2023 |
| Weighted-average remaining lease term, years | 4.2 |  | 4.6 |
| Weighted-average discount rate, % | 5.8 | % |  | 5.8 | % |


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000926326-24-000027:notes:124]
Commitments and Contingencies
Purchase Obligations

[0000926326-24-000027:notes:125]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of June 30, 2024, the Company had non-cancelable purchase commitments of $107.9 million, of which $87.3 million are expected to be paid within the year ending December 31, 2024.

[0000926326-24-000027:notes:126]
Legal Proceedings

[0000926326-24-000027:notes:127]
The Company is currently involved in various legal proceedings.

[0000926326-24-000027:notes:128]
As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any material accrual for contingent liabilities associated with any current legal proceedings based on its belief that any potential material loss, while reasonably possible, is not probable. Furthermore, any possible range of loss in such matters cannot be reasonably estimated at this time. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of legal proceedings or because of the diversion of management’s attention and the creation of significant expenses, regardless of outcome.

[0000926326-24-000027:notes:129]
The Company is not a party to any legal proceedings that management believes may have a material impact on the Company’s financial position or results of operations.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000926326-24-000027:notes:130]
Income Taxes 
The Company generally provides for income taxes in interim periods based on the estimated annual effective tax rate for the year, adjusting for discrete items in the quarter in which they arise. For the six months ended June 30, 2024 and June 30, 2023, the Company recorded a provision for income taxes of $2.3 million and $2.6 million, respectively, by applying its estimated annual effective tax rate to its year-to-date measure of ordinary income and adjusted for $3.3 million and $2.7 million, respectively, of discrete income tax expense primarily from equity compensation.

[0000926326-24-000027:notes:131]
The effective tax rate for the six months ended June 30, 2024 and 2023, differed from the statutory rate of 21% primarily due to the benefit of the research and development credits and a foreign-derived intangible income benefit deduction, partially offset by the unfavorable impact of the non-deductible compensation, equity charges, and Global Intangible Low-Taxed Income tax inclusion.

[0000926326-24-000027:notes:132]
The Organization for Economic Co-Operation and Development introduced Base Erosion and Profit Shifting Pillar Two rules that impose a global minimum tax rate of 15% on multi-national corporations. The rules are effective for the Company’s financial year beginning January 1, 2024. These rules did not have an impact on the Company’s provision for income taxes for the six months ended June 30, 2024.

[0000926326-24-000027:notes:133]
As of June 30, 2024 and December 31, 2023, the Company had gross unrecognized tax benefits of $11.4 million and $10.7 million, respectively. The Company recognizes interest and penalties related to uncertain tax positions in interest and other income (expense), net in the Condensed Consolidated Statements of Operations. Accrued interest and penalties are included within other long-term liabilities on the Condensed Consolidated Balance Sheets. As of June 30, 2024 and December 31, 2023, the amount of accrued interest and penalties was $0.6 million and $0.4 million, respectively.

[0000926326-24-000027:notes:134]
The Company files income tax returns in the United States and various state and foreign jurisdictions. In the normal course of business, the Company is subject to examinations by taxing authorities, including major jurisdictions such as the United States, Germany, Italy, France, and the United Kingdom. With few exceptions, as of June 30, 2024, the Company was no longer subject to U.S., state, and foreign tax examinations for years before 2020, 2019, and 2019, respectively.

[0000926326-24-000027:notes:135]
[same as prior period, unchanged from 0000926326-24-000015:notes:140]


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000926326-24-000027:notes:136]
[same as prior period, unchanged from 0000926326-24-000015:notes:141]

[0000926326-24-000027:notes:137]
The following table sets forth the total share-based compensation expense recognized in the Company’s Condensed Consolidated Statements of Operations for the three and six months ended June 30, 2024 and 2023:

[0000926326-24-000027:notes:138]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  | (In thousands) |
| Cost of product and service revenues | $ | 1,620 |  |  | $ | 2,268 |  |  | $ | 3,175 |  |  | $ | 4,276 |  |
| Research and development | 1,139 |  |  | 1,697 |  |  | 2,214 |  |  | 3,303 |  |
| Selling, general, and administrative | 7,272 |  |  | 10,124 |  |  | 13,283 |  |  | 20,552 |  |
| Total share-based compensation expense | $ | 10,031 |  |  | $ | 14,089 |  |  | $ | 18,672 |  |  | $ | 28,131 |  |

[0000926326-24-000027:notes:139]
The Company capitalized approximately $1.0 million and $1.1 million during the three months ended June 30, 2024 and 2023, respectively, and $1.7 million and $2.2 million during the six months ended June 30, 2024 and 2023, respectively, of non-cash share-based compensation expense to internal-use and external-use software development costs related to internal labor. The Company did not capitalize any material share-based compensation expense to inventory during the three and six months ended June 30, 2024 and 2023.

[0000926326-24-000027:notes:140]
[same as prior period, unchanged from 0000926326-24-000015:notes:145]

[0000926326-24-000027:notes:141]
The following assumptions were used to value shares under the ESPP for the three and six months ended June 30, 2024 and 2023:

[0000926326-24-000027:notes:142]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Expected life, years | 0.5 - 2.0 |  | 0.5 - 2.0 |  | 0.5 - 2.0 |  | 0.5 - 2.0 |
| Expected volatility, % | 33.7% - 57.0% |  | 31.7% - 63.9% |  | 33.7% - 57.0% |  | 31.7% - 63.9% |
| Risk-free interest rate, % | 1.5% - 5.5% |  | 0.1% - 5.1% |  | 1.5% - 5.5% |  | 0.1% - 5.1% |
| Dividend yield, % | — | % |  | — | % |  | — | % |  | — | % |

[0000926326-24-000027:notes:143]
For the six months ended June 30, 2024 and 2023, employees purchased approximately 334,000 and 209,000 shares of common stock, respectively, under the ESPP at a weighted-average price of $24.06 and $46.96, respectively. As of June 30, 2024, the unrecognized compensation cost related to the shares to be purchased under the ESPP was approximately $0.9 million and is expected to be recognized over a weighted-average period of 1.4 years.

[0000926326-24-000027:notes:144]
[same as prior period, unchanged from 0000926326-24-000015:notes:149]

[0000926326-24-000027:notes:145]
The following assumptions were used to value stock options granted pursuant to the Company’s 2009 Equity Incentive Plan, as amended (the “2009 Plan”) for the six months ended June 30, 2023. There were no stock options granted during the three and six months ended June 30, 2024, and three months ended June 30, 2023.

[0000926326-24-000027:notes:146]
|  |  | Six Months Ended June 30, |  |  |
|  |  |  | 2023 |  |  |  |  |
| Expected life, years |  |  | 3.2 |  |  |  |  |
| Expected volatility, % |  |  | 44.8 | % |  |  |  |  |
| Risk-free interest rate, % |  |  | 3.7 | % |  |  |  |  |
| Estimated forfeiture rate, % |  |  | 10.0 | % |  |  |  |  |
| Dividend yield, % |  |  | — | % |  |  |  |  |

[0000926326-24-000027:notes:147]
The following table summarizes the stock option activity under the 2009 Plan during the six months ended June 30, 2024:

[0000926326-24-000027:notes:148]
|  | Number ofShares |  | Weighted-AverageExercise Price |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2023 | 2,023 |  |  | $ | 67.68 |  |  | 4.6 |  | $ | 1,013 |  |
| Granted | — |  |  | — |  |  |  |  |  |
| Exercised | (4) |  |  | 27.82 |  |  |  |  |  |
| Expired | (163) |  |  | 73.51 |  |  |  |  |  |
| Forfeited | (23) |  |  | 63.91 |  |  |  |  |  |
| Outstanding at June 30, 2024 | 1,833 |  |  | $ | 67.29 |  |  | 4.3 |  | $ | — |  |
| Exercisable at June 30, 2024 | 1,744 |  |  | $ | 66.98 |  |  | 4.2 |  | $ | — |  |
| Vested and expected to vest at June 30, 2024 and thereafter | 1,830 |  |  | $ | 67.26 |  |  | 4.2 |  | $ | — |  |

[0000926326-24-000027:notes:149]
As of June 30, 2024, total unrecognized compensation cost related to unvested stock options was $0.8 million, which is expected to be recognized over a weighted-average vesting period of 0.3 years.

[0000926326-24-000027:notes:150]
[same as prior period, unchanged from 0000926326-24-000015:notes:155]

[0000926326-24-000027:notes:151]
The following table summarizes the RSU activity under the 2009 Plan during the six months ended June 30, 2024:

[0000926326-24-000027:notes:152]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2023 | 1,078 |  |  | $ | 84.66 |  |  | 1.5 |  | $ | 40,551 |  |
| Granted (Awarded) | 192 |  |  | 27.55 |  |  |  |  |  |
| Vested (Released) | (130) |  |  | 101.33 |  |  |  |  |  |
| Forfeited | (105) |  |  | 80.79 |  |  |  |  |  |
| Outstanding and unvested at June 30, 2024 | 1,035 |  |  | $ | 72.37 |  |  | 1.3 |  | $ | 28,026 |  |

[0000926326-24-000027:notes:153]
As of June 30, 2024, total unrecognized compensation cost related to RSUs was $44.4 million, which is expected to be recognized over the remaining weighted-average vesting period of 2.8 years.

[0000926326-24-000027:notes:154]
[same as prior period, unchanged from 0000926326-24-000015:notes:159]

[0000926326-24-000027:notes:155]
The following table summarizes the RSA activity under the 2009 Plan during the six months ended June 30, 2024:

[0000926326-24-000027:notes:156]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2023 | 24 |  |  | $ | 70.96 |  |
| Granted (Awarded) | 51 |  |  | 31.94 |  |
| Vested (Released) | (26) |  |  | 67.32 |  |
| Outstanding and unvested at June 30, 2024 | 49 |  |  | $ | 31.91 |  |

[0000926326-24-000027:notes:157]
As of June 30, 2024, total unrecognized compensation cost related to RSAs was $1.2 million, which is expected to be recognized over the remaining weighted-average vesting period of 0.9 years.

[0000926326-24-000027:notes:158]
[same as prior period, unchanged from 0000926326-24-000015:notes:163]

[0000926326-24-000027:notes:159]
The following table summarizes the PSU activity under the 2009 Plan during the six months ended June 30, 2024:

[0000926326-24-000027:notes:160]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2023 | 75 |  |  | $ | 127.14 |  |
| Granted | 177 |  |  | 28.67 |  |
| Vested | (5) |  |  | 157.56 |  |
| Forfeited | (65) |  |  | 122.29 |  |
| Outstanding and unvested at June 30, 2024 | 182 |  |  | $ | 32.33 |  |

[0000926326-24-000027:notes:161]
As of June 30, 2024, total unrecognized compensation cost related to PSUs was approximately $5.2 million, which is expected to be recognized over the remaining weighted-average vesting period of 1.8 years.

[0000926326-24-000027:notes:162]
[same as prior period, unchanged from 0000926326-24-000015:notes:167]

[0000926326-24-000027:notes:163]
The Company had the following ordinary shares reserved for future issuance under its equity incentive plans as of June 30, 2024:

[0000926326-24-000027:notes:164]
|  | Number of Shares |
|  | (In thousands) |
| Stock options outstanding | 1,833 |  |
| Non-vested restricted stock awards | 1,266 |  |
| Shares authorized for future issuance | 4,848 |  |
| ESPP shares available for future issuance | 2,916 |  |
| Total shares reserved for future issuance | 10,863 |  |

[0000926326-24-000027:notes:165]
[same as prior period, unchanged from 0000926326-24-000015:notes:170]

[0000926326-24-000027:notes:166]
On August 2, 2016, the Company’s Board of Directors (the “Board”) authorized a stock repurchase program, which does not expire, providing for the repurchase of up to $50.0 million of the Company’s common stock (the “2016 Repurchase Program”). As of June 30, 2024, the maximum dollar value of shares that may yet be purchased under the 2016 Repurchase Program was $2.7 million.

[0000926326-24-000027:notes:167]
[same as prior period, unchanged from 0000926326-24-000015:notes:172]

[0000926326-24-000027:notes:168]
During the three and six months ended June 30, 2024 and 2023, the Company did not repurchase any of its outstanding common stock under the 2016 Repurchase Program.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000926326-24-000027:notes:169]
Restructuring Expenses
On November 23, 2022, the Company committed to a plan to reduce the Company’s headcount (the “2022 Plan”), as part of the Company’s expense containment efforts being implemented due to ongoing macroeconomic headwinds. During the first quarter of 2023, as a result of continued exploration of expense containment measures, the Company committed to further reduce its headcount across many of its functions, and also committed to reduce its real estate footprint to align with its broader hybrid work strategy and in an effort to further reduce costs. During the three and six months ended June 30, 2023, the Company incurred $0.7 million and $6.0 million, respectively, of employee severance costs and related expenses in connection with the 2022 Plan. As of June 30, 2024, there was no unpaid balance related to the 2022 Plan.

[0000926326-24-000027:notes:170]
On November 2, 2023, the Company committed to a plan to reduce the Company’s headcount and real estate footprint (the “2023 Plan”) as part of the Company’s expense containment initiatives and other actions to reduce discretionary spending being implemented due to challenging industry dynamics and macroeconomic conditions. The Company did not incur any material expenses related to the 2023 Plan during the three and six months ended June 30, 2024. As of June 30, 2024 and December 31, 2023, the unpaid balance related to the 2023 Plan was $1.0 million and $8.9 million, respectively.

[0000926326-24-000027:notes:171]
On April 26, 2024, the Company’s management committed to the wind down of the Company’s Medimat Robotic Dispensing System (“RDS”) product line, subject to local law and statutory works council consultation requirements. During the six months ended June 30, 2024, the Company incurred approximately $3.3 million of employee severance costs and other expenses related to the planned RDS product line wind down, which were unpaid as of June 30, 2024. During the three months ended June 30, 2024, the Company did not incur any additional employee-related expenses related to the planned RDS product line wind down. In addition, during the three and six months ended June 30, 2024, the Company incurred $5.4 million of inventory write-down charges related to the planned RDS product line wind down that were recorded to cost of revenues in the Company’s Condensed Consolidated Statements of Operations.

[0000926326-24-000027:notes:172]
[same as prior period, unchanged from 0000926326-24-000015:notes:177]

[0000926326-24-000027:notes:173]
The following table summarizes the total employee-related restructuring expense recognized in the Company’s Condensed Consolidated Statements of Operations for the three and six months ended June 30, 2024 and 2023:

[0000926326-24-000027:notes:174]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  | (In thousands) |
| Cost of product and service revenues | $ | — |  |  | $ | 238 |  |  | $ | 2,696 |  |  | $ | 382 |  |
| Research and development | — |  |  | 7 |  |  | 311 |  |  | 492 |  |
| Selling, general, and administrative | — |  |  | 476 |  |  | 156 |  |  | 5,161 |  |
| Total restructuring expense | $ | — |  |  | $ | 721 |  |  | $ | 3,163 |  |  | $ | 6,035 |  |
