# OMCL note change history — 0000926326-24-000015 → 0000926326-24-000027


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-08-06):
[0000926326-24-000027:note_history:1]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of June 30, 2024, the Company had non-cancelable purchase commitments of $107.9 million, of which $87.3 million are expected to be paid within the year ending December 31, 2024.
  (was, 2024-05-07, similarity 0.9836):
[0000926326-24-000015:note_history:1]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of March 31, 2024, the Company had non-cancelable purchase commitments of $103.0 million, of which $90.0 million are expected to be paid within the year ending December 31, 2024.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-08-06):
[0000926326-24-000027:note_history:2]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of June 30, 2024 and December 31, 2023, the results of operations and comprehensive income (loss) for the three and six months ended June 30, 2024 and 2023, and cash flows for the six months ended June 30, 2024 and 2023. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s Annual Report on Form 10-K for the year ended December 31, 2023, filed with the SEC on February 28, 2024. The Company’s results of operations and comprehensive income (loss) for the three and six months ended June 30, 2024, and cash flows for the six months ended June 30, 2024 are not necessarily indicative of results that may be expected for the year ending December 31, 2024, or for any future period.
  (was, 2024-05-07, similarity 0.7916):
[0000926326-24-000015:note_history:2]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of March 31, 2024 and December 31, 2023, and the results of operations, comprehensive loss, and cash flows for the three months ended March 31, 2024 and 2023. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s Annual Report on Form 10-K for the year ended December 31, 2023, filed with the SEC on February 28, 2024. The Company’s results of operations, comprehensive loss, and cash flows for the three months ended March 31, 2024 are not necessarily indicative of results that may be expected for the year ending December 31, 2024, or for any future period.

- changed (2024-08-06):
[0000926326-24-000027:note_history:3]
The Company’s critical accounting policies are those that affect its financial statements materially and involve difficult, subjective, or complex judgments by management. As of June 30, 2024, the Company is not aware of any events or circumstances that would require an update to its estimates, judgments, or revisions to the carrying value of its assets or liabilities.
  (was, 2024-05-07, similarity 0.6758):
[0000926326-24-000015:note_history:3]
The Company’s critical accounting policies are those that affect its financial statements materially and involve difficult, subjective, or complex judgments by management. As of March 31, 2024, the Company is not aware of any events or circumstances that would require an update to its estimates, judgments, or revisions to the carrying value of its assets or liabilities.

- added (2024-08-06):
[0000926326-24-000027:note_history:4]
In March 2024, the SEC issued final rules under SEC Release No. 33-11275, “The Enhancement and Standardization of Climate-Related Disclosures for Investors,” to require registrants to disclose certain climate-related information, including Scope 1 and Scope 2 greenhouse gas emissions and other climate-related topics, if material, in registration statements and annual reports. In April 2024, the SEC voluntarily stayed its climate disclosure rules as a result of pending legal challenges to facilitate an orderly judicial resolution. The Company is currently evaluating the impact the SEC’s rule will have on its consolidated financial statements.


## omcl:ScheduleOfInterestExpenseDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-08-06):
[0000926326-24-000027:note_history:5]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three and six months ended June 30, 2024 and 2023:
  (was, 2024-05-07, similarity 0.9131):
[0000926326-24-000015:note_history:5]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three months ended March 31, 2024 and 2023:

- changed (2024-08-06):
[0000926326-24-000027:note_history:6]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  | (In thousands) |
| Contractual coupon interest | $ | 359 |  |  | $ | 359 |  |  | $ | 719 |  |  | $ | 719 |  |
| Amortization of debt issuance costs | $ | 778 |  |  | $ | 772 |  |  | $ | 1,555 |  |  | $ | 1,543 |  |
  (was, 2024-05-07, similarity 0.7193):
[0000926326-24-000015:note_history:6]
|  | Three Months Ended March 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
|  | (In thousands) |
| Contractual coupon interest | $ | 359 |  |  | $ | 359 |  |  |  |  |  |
| Amortization of debt issuance costs | $ | 777 |  |  | $ | 771 |  |  |  |  |  |


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-08-06):
[0000926326-24-000027:note_history:7]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of June 30, 2024 and December 31, 2023:
  (was, 2024-05-07, similarity 0.966):
[0000926326-24-000015:note_history:7]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of March 31, 2024 and December 31, 2023:

- changed (2024-08-06):
[0000926326-24-000027:note_history:8]
|  | June 30,2024 |  | December 31,2023 |
|  | (In thousands) |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized debt issuance costs | (3,783) |  |  | (5,338) |  |
| Convertible senior notes, net | $ | 571,217 |  |  | $ | 569,662 |  |
  (was, 2024-05-07, similarity 0.9777):
[0000926326-24-000015:note_history:8]
|  | March 31,2024 |  | December 31,2023 |
|  | (In thousands) |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized debt issuance costs | (4,561) |  |  | (5,338) |  |
| Convertible senior notes, net | $ | 570,439 |  |  | $ | 569,662 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-08-06):
[0000926326-24-000027:note_history:9]
Debt and Credit Agreement
On November 15, 2019, Omnicell, Inc. entered into an Amended and Restated Credit Agreement (as amended, the “Prior A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers, and Wells Fargo Bank, National Association, as administrative agent. As referred to herein, “Omnicell, Inc.” refers only to Omnicell, Inc., excluding its subsidiaries. The Prior A&R Credit Agreement provided for (a) a five-year revolving credit facility of $500.0 million (the “Prior Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million (the “Prior Incremental Facility”). In addition, the Prior A&R Credit Agreement included a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The Prior A&R Credit Agreement was subsequently amended on September 22, 2020 and March 29, 2023, to permit the issuance of the convertible senior notes and the purchase of the convertible note hedge transactions (as described in Note 10, Convertible Senior Notes, of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q), expand the Company’s flexibility to make restricted payments (including common stock repurchases), and replace the total net leverage covenant, as well as to remove and replace the interest rate benchmark based on the London interbank offered rate (“LIBOR”) and related LIBOR-based mechanics with an interest rate benchmark based on the secured overnight financing rate (“SOFR”) as administered by the Federal Reserve Bank of New York and related SOFR-based mechanics.
  (was, 2024-05-07, similarity 0.6194):
[0000926326-24-000015:note_history:9]
Debt and Credit Agreement
On November 15, 2019, the Company entered into an Amended and Restated Credit Agreement (as amended, the “Prior A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers, and Wells Fargo Bank, National Association, as administrative agent. The Prior A&R Credit Agreement provided for (a) a five-year revolving credit facility of $500.0 million (the “Prior Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million (the “Prior Incremental Facility”). In addition, the Prior A&R Credit Agreement included a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million.

- changed (2024-08-06):
[0000926326-24-000027:note_history:10]
Omnicell, Inc. entered into a Second Amended and Restated Credit Agreement (the “Second A&R Credit Agreement”) on October 10, 2023, with the lenders from time to time party thereto, Wells Fargo Securities, LLC, JPMorgan Chase Bank, N.A., PNC Capital Markets LLC and TD Securities (USA) LLC as joint lead arrangers and Wells Fargo Bank, National Association, as administrative agent. The Second A&R Credit Agreement supersedes the Prior A&R Credit Agreement and provides for (a) a five-year revolving credit facility of $350.0 million (the “Current Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to an amount equal to the sum of (i) the greater of $250.0 million and 100% of the adjusted consolidated EBITDA for the last four quarters and (ii) additional amounts subject to pro forma compliance with certain consolidated secured net leverage ratio (the “Current Incremental Facility”). In addition, the Second A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The Second A&R Credit Agreement has an expiration date of October 10, 2028, subject to acceleration under certain conditions, upon which date all remaining outstanding borrowings will be due and payable.
  (was, 2024-05-07, similarity 0.6971):
[0000926326-24-000015:note_history:10]
The Company entered into a Second Amended and Restated Credit Agreement (the “Second A&R Credit Agreement”) on October 10, 2023, with the lenders from time to time party thereto, Wells Fargo Securities, LLC, JPMorgan Chase Bank, N.A., PNC Capital Markets LLC and TD Securities (USA) LLC as joint lead arrangers and Wells Fargo Bank, National Association, as administrative agent. The Second A&R Credit Agreement supersedes the Prior A&R Credit Agreement and provides for (a) a five-year revolving credit facility of $350.0 million (the “Current Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to an amount equal to the sum of (i) the greater of $250.0 million or 100% of the

- changed (2024-08-06):
[0000926326-24-000027:note_history:11]
Loans under the Current Revolving Credit Facility bear interest, at Omnicell, Inc.’s option, at a rate equal to either (a) the Adjusted Term SOFR (as defined in the Second A&R Credit Agreement), plus an applicable margin ranging from 1.50% to 2.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the Second A&R Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) the Adjusted Term SOFR for an interest period of one month plus 1.00%, plus an applicable margin ranging from 0.50% to 1.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio. Undrawn commitments under the Current Revolving Credit Facility are subject to a commitment fee ranging from 0.20% to 0.35% per annum based on the Company’s Consolidated Total Net Leverage Ratio on the average daily unused portion of the Current Revolving Credit Facility. Subject to the terms and conditions of the Current Revolving Credit Facility or Current Incremental Facility Omnicell, Inc. is permitted to make voluntary prepayments at any time without payment of a premium or penalty. The availability of funds under the Current
  (was, 2024-05-07, similarity 0.8174):
[0000926326-24-000015:note_history:11]
Loans under the Current Revolving Credit Facility bear interest, at the Company’s option, at a rate equal to either (a) the Adjusted Term SOFR (as defined in the Second A&R Credit Agreement), plus an applicable margin ranging from 1.50% to 2.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the Second A&R Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) the Adjusted Term SOFR for an interest period of one month plus 1.00%, plus an applicable margin ranging from 0.50% to 1.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio. Undrawn commitments under the Current Revolving Credit Facility are subject to a commitment fee ranging from 0.20% to 0.35% per annum based on the Company’s Consolidated Total Net Leverage Ratio on the average daily unused portion of the Current Revolving Credit Facility. Subject to the terms and conditions of the Current Revolving Credit Facility or Current Incremental Facility the Company is permitted to make voluntary prepayments at any time without payment of a premium or penalty. The availability of funds under the Current Revolving Credit Facility may be subject to reduction in order to maintain compliance with the financial covenants under the Second A&R Credit Agreement.

- added (2024-08-06):
[0000926326-24-000027:note_history:12]
Revolving Credit Facility may be subject to reduction in order to maintain compliance with the financial covenants under the Second A&R Credit Agreement.

- changed (2024-08-06):
[0000926326-24-000027:note_history:13]
The Second A&R Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends, and other distributions. The Second A&R Credit Agreement contains financial covenants that require the Company to not exceed a maximum consolidated secured net leverage ratio (not to exceed 3.00:1) and maintain a minimum consolidated interest coverage ratio (not to be less than 3.00:1). In addition, the Second A&R Credit Agreement contains certain customary events of default including, but not limited to, failure to pay interest, principal, and fees, or other amounts when due, material misrepresentations or misstatements in any representation or warranty, covenant defaults, certain cross defaults to other material indebtedness, certain judgment defaults, and events of bankruptcy.
  (was, 2024-05-07, similarity 0.8432):
[0000926326-24-000015:note_history:13]
The Second A&R Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends, and other distributions. The Second A&R Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum consolidated secured net leverage ratio (not to exceed 3.00:1) and maintain a minimum consolidated interest coverage ratio (not to be less than 3.00:1). In addition, the Second A&R Credit Agreement contains certain customary events of default including, but not limited to, failure to pay interest, principal, and fees, or other amounts when due, material misrepresentations or misstatements in any representation or warranty, covenant defaults, certain cross defaults to other material indebtedness, certain judgment defaults, and events of bankruptcy.

- added (2024-08-06):
[0000926326-24-000027:note_history:14]
Omnicell, Inc.’s obligations under the Second A&R Credit Agreement and, at the election of Omnicell, Inc. and the contracting counterparty, any secured swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and such subsidiary guarantors’ assets. In connection with entering into the Second A&R Credit Agreement, and as a condition precedent to borrowing loans thereunder, Omnicell, Inc. and certain of Omnicell, Inc.’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a reaffirmation agreement, which amends certain terms of the existing collateral agreement and reaffirms their obligations under the existing guaranty agreement.

- changed (2024-08-06):
[0000926326-24-000027:note_history:15]
The refinancing of the Prior Credit Agreement on October 10, 2023 was evaluated in accordance with ASC 470-50, Debt - Modifications and Extinguishments. In determining whether the refinancing was to be accounted for as a debt extinguishment or a debt modification, the Company considered whether lenders within the syndicate remained the same or changed and whether the changes in debt terms were substantial. This assessment was performed on an individual lender basis within the syndicate. As a result, the refinancing was accounted for as a modification with the exception of certain lenders that exited the syndicate. The exit of certain lenders resulted in an immaterial write-off of existing unamortized debt issuance costs. The remaining unamortized debt issuance costs related to debt modification, along with the new deferred costs, will be amortized over the remaining term of the Second A&R Credit Agreement. The Company incurred and capitalized an additional $3.0 million of debt issuance costs which are being amortized to interest expense using the straight-line method through 2028.
  (was, 2024-05-07, similarity 0.9054):
[0000926326-24-000015:note_history:15]
The refinancing of the Prior Credit Agreement was evaluated in accordance with ASC 470-50, Debt - Modifications and Extinguishments. In determining whether the refinancing was to be accounted for as a debt extinguishment or a debt modification, the Company considered whether lenders within the syndicate remained the same or changed and whether the changes in debt terms were substantial. This assessment was performed on an individual lender basis within the syndicate. As a result, the refinancing was accounted for as a modification with the exception of certain lenders that exited the syndicate. The exit of certain lenders resulted in an immaterial write-off of existing unamortized debt issuance costs. The remaining unamortized debt issuance costs related to debt modification, along with the new deferred costs, will be amortized over the remaining term of the Second A&R Credit Agreement.

- changed (2024-08-06):
[0000926326-24-000027:note_history:16]
As of both June 30, 2024 and December 31, 2023, the Company had $350.0 million of funds available under the Current Revolving Credit Facility. As of June 30, 2024 and December 31, 2023, the Company had no outstanding balance under the Current Revolving Credit Facility. The Company was in compliance with all covenants as of June 30, 2024.
Convertible Senior Notes
0.25% Convertible Senior Notes due 2025
  (was, 2024-05-07, similarity 0.9633):
[0000926326-24-000015:note_history:16]
As of both March 31, 2024 and December 31, 2023, the Company had $350.0 million of funds available under the Current Revolving Credit Facility. As of March 31, 2024 and December 31, 2023, the Company had no outstanding balance under the Current Revolving Credit Facility. The Company was in compliance with all covenants as of March 31, 2024.
Convertible Senior Notes
0.25% Convertible Senior Notes due 2025

- changed (2024-08-06):
[0000926326-24-000027:note_history:17]
On September 25, 2020, the Company completed a private offering of $575.0 million aggregate principal amount of 0.25% convertible senior notes (the “Notes”), including the exercise in full of the initial purchasers’ option to purchase up to an additional $75.0 million principal amount of the Notes. The Company received proceeds from the issuance of the Notes of $559.7 million, net of $15.3 million of transaction fees and other debt issuance costs. The Notes bear interest at a rate of 0.25% per year, payable semiannually in arrears on March 15 and September 15 of each year, beginning on March 15, 2021. The Notes were issued pursuant to an indenture, dated September 25, 2020 (the “Indenture”), between the Company and U.S. Bank National Association, as trustee. The Notes are general senior, unsecured obligations of the Company and will mature on September 15, 2025, unless earlier redeemed, repurchased, or converted.
  (was, 2024-05-07, similarity 0.6938):
[0000926326-24-000015:note_history:17]
On September 25, 2020, the Company completed a private offering of $575.0 million aggregate principal amount of 0.25% convertible senior notes (the “Notes”), including the exercise in full of the initial purchasers’ option to purchase up to an additional $75.0 million principal amount of the Notes. The Company received proceeds from the issuance of the Notes of $559.7 million, net of $15.3 million of transaction fees and other debt issuance costs. The Notes bear interest at a rate of 0.25%

- changed (2024-08-06):
[0000926326-24-000027:note_history:18]
During the three months ended June 30, 2024 and December 31, 2023, none of the conditional conversion features of the Notes were triggered, and therefore, the Notes are not convertible during the third quarter of 2024, commencing on July 1, 2024, and were not convertible during the first quarter of 2024, commencing on January 1, 2024. Accordingly, the Company classified the Notes as a long-term liability in its Condensed Consolidated Financial Statements as of both June 30, 2024 and December 31, 2023. Whether the Notes will be convertible following the third fiscal quarter of 2024 will depend on the satisfaction of the conversion conditions in the future.
  (was, 2024-05-07, similarity 0.9639):
[0000926326-24-000015:note_history:18]
During the three months ended March 31, 2024 and December 31, 2023, none of the conditional conversion features of the Notes were triggered, and therefore, the Notes are not convertible during the second quarter of 2024, commencing on April 1, 2024, and were not convertible during the first quarter of 2024, commencing on January 1, 2024. Accordingly, the Company classified the Notes as a long-term liability in its Condensed Consolidated Financial Statements as of both March 31, 2024 and December 31, 2023. Whether the Notes will be convertible following the second fiscal quarter of 2024 will depend on the satisfaction of the conversion conditions in the future.

- changed (2024-08-06):
[0000926326-24-000027:note_history:19]
If the Company undergoes a fundamental change, holders may require, subject to certain exceptions, the Company to repurchase for cash all or any portion of their Notes at a fundamental change repurchase price equal to 100% of the principal amount of the Notes to be repurchased, plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date. As of June 30, 2024, none of the criteria for a fundamental change or a conversion rate adjustment had been met.
  (was, 2024-05-07, similarity 0.8349):
[0000926326-24-000015:note_history:19]
If the Company undergoes a fundamental change, holders may require, subject to certain exceptions, the Company to repurchase for cash all or any portion of their Notes at a fundamental change repurchase price equal to 100% of the principal amount of the Notes to be repurchased, plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date. As of March 31, 2024, none of the criteria for a fundamental change or a conversion rate adjustment had been met.

- changed (2024-08-06):
[0000926326-24-000027:note_history:20]
As of June 30, 2024, the Company may redeem for cash all or any portion of the Notes, at its option, if the last reported sale price of the Company’s common stock has been at least 130% of the conversion price for the Notes then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which the Company provides notice of redemption at a redemption price equal to 100% of the principal amount of the Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. If the Company redeems less than all of the outstanding Notes, at least $150.0 million aggregate principal amount of Notes must be outstanding and not subject to redemption as of the date of the relevant notice of redemption. No sinking fund is provided for in the Notes.
  (was, 2024-05-07, similarity 0.9952):
[0000926326-24-000015:note_history:20]
As of March 31, 2024, the Company may redeem for cash all or any portion of the Notes, at its option, if the last reported sale price of the Company’s common stock has been at least 130% of the conversion price for the Notes then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which the Company provides notice of redemption at a redemption price equal to 100% of the principal amount of the Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. If the Company redeems less than all of the outstanding Notes, at least $150.0 million aggregate principal amount of Notes must be outstanding and not subject to redemption as of the date of the relevant notice of redemption. No sinking fund is provided for in the Notes.

- changed (2024-08-06):
[0000926326-24-000027:note_history:21]
The debt issuance costs associated with the Notes are being amortized to interest expense over the term of the Notes using an effective interest rate of 0.80%. As of June 30, 2024, the remaining life of the Notes and the related issuance cost accretion is approximately 1.2 years.
  (was, 2024-05-07, similarity 0.9833):
[0000926326-24-000015:note_history:21]
The debt issuance costs associated with the Notes are being amortized to interest expense over the term of the Notes using an effective interest rate of 0.80%. As of March 31, 2024, the remaining life of the Notes and the related issuance cost accretion is approximately 1.5 years.

- changed (2024-08-06):
[0000926326-24-000027:note_history:22]
The maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to other conversion rate adjustments, would be 5.9 million shares. As of June 30, 2024, the if-converted value of the Notes did not exceed the principal amount.
  (was, 2024-05-07, similarity 0.983):
[0000926326-24-000015:note_history:22]
The maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to other conversion rate adjustments, would be 5.9 million shares. As of March 31, 2024, the if-converted value of the Notes did not exceed the principal amount.

- changed (2024-08-06):
[0000926326-24-000027:note_history:23]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of June 30, 2024 and December 31, 2023:
  (was, 2024-05-07, similarity 0.966):
[0000926326-24-000015:note_history:23]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of March 31, 2024 and December 31, 2023:

- changed (2024-08-06):
[0000926326-24-000027:note_history:24]
|  | June 30,2024 |  | December 31,2023 |
|  | (In thousands) |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized debt issuance costs | (3,783) |  |  | (5,338) |  |
| Convertible senior notes, net | $ | 571,217 |  |  | $ | 569,662 |  |
  (was, 2024-05-07, similarity 0.9777):
[0000926326-24-000015:note_history:24]
|  | March 31,2024 |  | December 31,2023 |
|  | (In thousands) |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized debt issuance costs | (4,561) |  |  | (5,338) |  |
| Convertible senior notes, net | $ | 570,439 |  |  | $ | 569,662 |  |

- changed (2024-08-06):
[0000926326-24-000027:note_history:25]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three and six months ended June 30, 2024 and 2023:
  (was, 2024-05-07, similarity 0.9131):
[0000926326-24-000015:note_history:25]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three months ended March 31, 2024 and 2023:

- changed (2024-08-06):
[0000926326-24-000027:note_history:26]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  | (In thousands) |
| Contractual coupon interest | $ | 359 |  |  | $ | 359 |  |  | $ | 719 |  |  | $ | 719 |  |
| Amortization of debt issuance costs | $ | 778 |  |  | $ | 772 |  |  | $ | 1,555 |  |  | $ | 1,543 |  |
  (was, 2024-05-07, similarity 0.7193):
[0000926326-24-000015:note_history:26]
|  | Three Months Ended March 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
|  | (In thousands) |
| Contractual coupon interest | $ | 359 |  |  | $ | 359 |  |  |  |  |  |
| Amortization of debt issuance costs | $ | 777 |  |  | $ | 771 |  |  |  |  |  |

- changed (2024-08-06):
[0000926326-24-000027:note_history:27]
Separately from the convertible note hedge, in September 2020, the Company entered into warrant transactions to sell to the option counterparties warrants to acquire, subject to customary anti-dilution adjustments, up to approximately 5.9 million shares of its common stock in the aggregate at an initial strike price of $141.56 per share. The warrants require net share or net cash settlement upon the Company’s election. The Company received aggregate proceeds of approximately $51.3 million for the issuance of the warrants, which was recorded in additional paid-in capital at issuance in the Condensed Consolidated Balance Sheets. The warrants could separately have a dilutive effect to the Company’s common stock to the extent that the market price per share of its common stock exceeds the strike price of the warrants.
  (was, 2024-05-07, similarity 0.9907):
[0000926326-24-000015:note_history:27]
Separately from the convertible note hedge, the Company entered into warrant transactions to sell to the option counterparties warrants to acquire, subject to customary anti-dilution adjustments, up to approximately 5.9 million shares of its common stock in the aggregate at an initial strike price of $141.56 per share. The warrants require net share or net cash settlement upon the Company’s election. The Company received aggregate proceeds of approximately $51.3 million for the issuance of the warrants, which was recorded in additional paid-in capital at issuance in the Condensed Consolidated Balance Sheets. The warrants could separately have a dilutive effect to the Company’s common stock to the extent that the market price per share of its common stock exceeds the strike price of the warrants.

- removed (2024-08-06):
[0000926326-24-000015:note_history:28]
On September 22, 2020 and March 29, 2023, the Company entered into amendments to the Prior A&R Credit Agreement to, among other changes, permit the issuance of the convertible senior notes and the purchase of the convertible note hedge transactions, as described in Note 10, Convertible Senior Notes, expand the Company’s flexibility to repurchase its common stock and make other restricted payments, and replace the total net leverage covenant as well as to remove and replace the interest rate benchmark based on the London interbank offered rate (“LIBOR”) and related LIBOR-based mechanics applicable to borrowings under the Prior A&R Credit Agreement with an interest rate benchmark based on the secured overnight financing rate (“SOFR”) as administered by the Federal Reserve Bank of New York and related SOFR-based mechanics.

- removed (2024-08-06):
[0000926326-24-000015:note_history:29]
adjusted consolidated EBITDA for the last four quarters and (ii) additional amounts subject to pro forma compliance with certain consolidated secured net leverage ratio (the “Current Incremental Facility”). In addition, the Second A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The Second A&R Credit Agreement has an expiration date of October 10, 2028, subject to acceleration under certain conditions, upon which date all remaining outstanding borrowings will be due and payable.

- removed (2024-08-06):
[0000926326-24-000015:note_history:30]
The Company’s obligations under the Second A&R Credit Agreement and, at the election of the Company and the contracting counterparty, any secured swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and such subsidiary guarantors’ assets. In connection with entering into the Second A&R Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a reaffirmation agreement, which amends certain terms of the existing collateral agreement and reaffirms their obligations under the existing guaranty agreement.

- removed (2024-08-06):
[0000926326-24-000015:note_history:31]
In connection with entering into the Second A&R Credit Agreement on October 10, 2023, the Company incurred and capitalized an additional $3.0 million of debt issuance costs. The debt issuance costs are being amortized to interest expense using the straight-line method through 2028.

- removed (2024-08-06):
[0000926326-24-000015:note_history:32]
per year, payable semiannually in arrears on March 15 and September 15 of each year, beginning on March 15, 2021. The Notes were issued pursuant to an indenture, dated September 25, 2020 (the “Indenture”), between the Company and U.S. Bank National Association, as trustee. The Notes are general senior, unsecured obligations of the Company and will mature on September 15, 2025, unless earlier redeemed, repurchased, or converted.


## omcl:RevenueFromContractWithCustomerTimingAndClassificationOfRevenueCategoriesTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-08-06):
[0000926326-24-000027:note_history:33]
| Revenue Category |  |  |  | Timing of Revenue Recognition |  | Income Statement Classification |
| Connected devices, software licenses, and other |  |  |  | Point in time, as transfer of control occurs, generally upon installation and acceptance by the customer |  | Product |
| Consumables |  |  |  | Point in time, as transfer of control occurs, generally upon shipment to, or receipt by, the customer |  | Product |
| Technical services |  |  |  | Over time, as services are provided, typically ratably over the service term |  | Service |
| Advanced Services |  |  |  | Over time, as services are provided |  | Service |
  (was, 2024-05-07, similarity 0.6325):
[0000926326-24-000015:note_history:33]
| Revenue Category |  |  |  | Timing of Revenue Recognition |  | Income Statement Classification |
| Connected devices, software licenses, and other |  |  |  | Point in time, as transfer of control occurs, generally upon installation and acceptance by the customer |  | Product |
| Consumables |  |  |  | Point in time, as transfer of control occurs, generally upon shipment to or receipt by customer |  | Product |
| Technical services |  |  |  | Over time, as services are provided, typically ratably over the service term |  | Service |
| Advanced Services |  |  |  | Over time, as services are provided |  | Service |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-08-06):
[0000926326-24-000027:note_history:34]
| Revenue Category |  |  |  | Timing of Revenue Recognition |  | Income Statement Classification |
| Connected devices, software licenses, and other |  |  |  | Point in time, as transfer of control occurs, generally upon installation and acceptance by the customer |  | Product |
| Consumables |  |  |  | Point in time, as transfer of control occurs, generally upon shipment to, or receipt by, the customer |  | Product |
| Technical services |  |  |  | Over time, as services are provided, typically ratably over the service term |  | Service |
| Advanced Services |  |  |  | Over time, as services are provided |  | Service |
  (was, 2024-05-07, similarity 0.6325):
[0000926326-24-000015:note_history:34]
| Revenue Category |  |  |  | Timing of Revenue Recognition |  | Income Statement Classification |
| Connected devices, software licenses, and other |  |  |  | Point in time, as transfer of control occurs, generally upon installation and acceptance by the customer |  | Product |
| Consumables |  |  |  | Point in time, as transfer of control occurs, generally upon shipment to or receipt by customer |  | Product |
| Technical services |  |  |  | Over time, as services are provided, typically ratably over the service term |  | Service |
| Advanced Services |  |  |  | Over time, as services are provided |  | Service |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-08-06):
[0000926326-24-000027:note_history:35]
| Revenue Category |  |  |  | Timing of Revenue Recognition |  | Income Statement Classification |
| Connected devices, software licenses, and other |  |  |  | Point in time, as transfer of control occurs, generally upon installation and acceptance by the customer |  | Product |
| Consumables |  |  |  | Point in time, as transfer of control occurs, generally upon shipment to, or receipt by, the customer |  | Product |
| Technical services |  |  |  | Over time, as services are provided, typically ratably over the service term |  | Service |
| Advanced Services |  |  |  | Over time, as services are provided |  | Service |
  (was, 2024-05-07, similarity 0.6325):
[0000926326-24-000015:note_history:35]
| Revenue Category |  |  |  | Timing of Revenue Recognition |  | Income Statement Classification |
| Connected devices, software licenses, and other |  |  |  | Point in time, as transfer of control occurs, generally upon installation and acceptance by the customer |  | Product |
| Consumables |  |  |  | Point in time, as transfer of control occurs, generally upon shipment to or receipt by customer |  | Product |
| Technical services |  |  |  | Over time, as services are provided, typically ratably over the service term |  | Service |
| Advanced Services |  |  |  | Over time, as services are provided |  | Service |

- changed (2024-08-06):
[0000926326-24-000027:note_history:36]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”) and Federal agencies that purchase under a Federal Supply Schedule Contract with the Department of Veterans Affairs (the “GSA Contract”). GPOs are often fully or partially owned by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company also pays the Industrial Funding Fee (“IFF”) to the Department of Veterans Affairs under the GSA Contract. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs and the IFF were $2.4 million and $2.8 million for the three months ended June 30, 2024 and 2023, respectively, and $4.4 million and $5.9 million for the six months ended June 30, 2024 and 2023, respectively.
  (was, 2024-05-07, similarity 0.7579):
[0000926326-24-000015:note_history:36]
Affairs (the “GSA Contract”). GPOs are often fully or partially owned by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company also pays the Industrial Funding Fee (“IFF”) to the Department of Veterans Affairs under the GSA Contract. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs and the IFF were $2.0 million and $3.1 million for the three months ended March 31, 2024 and 2023, respectively.

- changed (2024-08-06):
[0000926326-24-000027:note_history:37]
The following table summarizes the Company’s revenues disaggregated by revenue type for the three and six months ended June 30, 2024 and 2023:
  (was, 2024-05-07, similarity 0.9349):
[0000926326-24-000015:note_history:37]
The following table summarizes the Company’s revenues disaggregated by revenue type for the three months ended March 31, 2024 and 2023:

- changed (2024-08-06):
[0000926326-24-000027:note_history:38]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  | (In thousands) |
| Connected devices, software licenses, and other | $ | 134,539 |  |  | $ | 167,475 |  |  | $ | 245,608 |  |  | $ | 332,622 |  |
| Consumables | 22,041 |  |  | 20,961 |  |  | 44,267 |  |  | 41,529 |  |
| Technical services | 59,321 |  |  | 57,191 |  |  | 117,836 |  |  | 110,548 |  |
| Advanced Services | 60,887 |  |  | 53,346 |  |  | 115,228 |  |  | 104,903 |  |
| Total revenues | $ | 276,788 |  |  | $ | 298,973 |  |  | $ | 522,939 |  |  | $ | 589,602 |  |
  (was, 2024-05-07, similarity 0.6288):
[0000926326-24-000015:note_history:38]
|  | Three Months Ended March 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
|  | (In thousands) |
| Connected devices, software licenses, and other | $ | 111,069 |  |  | $ | 165,147 |  |  |  |  |  |
| Consumables | 22,226 |  |  | 20,568 |  |  |  |  |  |
| Technical services | 58,515 |  |  | 53,357 |  |  |  |  |  |
| Advanced Services | 54,341 |  |  | 51,557 |  |  |  |  |  |
| Total revenues | $ | 246,151 |  |  | $ | 290,629 |  |  |  |  |  |

- changed (2024-08-06):
[0000926326-24-000027:note_history:39]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location, for the three and six months ended June 30, 2024 and 2023:
  (was, 2024-05-07, similarity 0.9539):
[0000926326-24-000015:note_history:39]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location, for the three months ended March 31, 2024 and 2023:

- changed (2024-08-06):
[0000926326-24-000027:note_history:40]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  | (In thousands) |
| United States | $ | 255,317 |  |  | $ | 257,202 |  |  | $ | 473,493 |  |  | $ | 513,145 |  |
| Rest of world (1) | 21,471 |  |  | 41,771 |  |  | 49,446 |  |  | 76,457 |  |
| Total revenues | $ | 276,788 |  |  | $ | 298,973 |  |  | $ | 522,939 |  |  | $ | 589,602 |  |
  (was, 2024-05-07, similarity 0.714):
[0000926326-24-000015:note_history:40]
|  | Three Months Ended March 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
|  | (In thousands) |
| United States | $ | 218,176 |  |  | $ | 255,943 |  |  |  |  |  |
| Rest of world (1) | 27,975 |  |  | 34,686 |  |  |  |  |  |
| Total revenues | $ | 246,151 |  |  | $ | 290,629 |  |  |  |  |  |

- changed (2024-08-06):
[0000926326-24-000027:note_history:41]
|  | June 30,2024 |  | December 31,2023 |
|  | (In thousands) |
| Short-term unbilled receivables, net (1) | $ | 25,122 |  |  | $ | 22,524 |  |
| Long-term unbilled receivables, net (2) | 9,901 |  |  | 11,850 |  |
| Total contract assets | $ | 35,023 |  |  | $ | 34,374 |  |
| Short-term deferred revenues | $ | 150,316 |  |  | $ | 121,734 |  |
| Long-term deferred revenues | 67,931 |  |  | 58,622 |  |
| Total contract liabilities | $ | 218,247 |  |  | $ | 180,356 |  |
  (was, 2024-05-07, similarity 0.988):
[0000926326-24-000015:note_history:41]
|  | March 31,2024 |  | December 31,2023 |
|  | (In thousands) |
| Short-term unbilled receivables, net (1) | $ | 22,661 |  |  | $ | 22,524 |  |
| Long-term unbilled receivables, net (2) | 10,360 |  |  | 11,850 |  |
| Total contract assets | $ | 33,021 |  |  | $ | 34,374 |  |
| Short-term deferred revenues | $ | 164,586 |  |  | $ | 121,734 |  |
| Long-term deferred revenues | 65,195 |  |  | 58,622 |  |
| Total contract liabilities | $ | 229,781 |  |  | $ | 180,356 |  |

- changed (2024-08-06):
[0000926326-24-000027:note_history:42]
Short-term deferred revenues of $121.7 million as of December 31, 2023 include deferred revenues from product sales and service contracts, net of deferred cost of sales of $12.4 million. During the three and six months ended June 30, 2024, the Company recognized revenues of $34.8 million and $85.0 million, respectively, that were included in the corresponding gross short-term deferred revenues balance of $134.1 million as of December 31, 2023.
  (was, 2024-05-07, similarity 0.6086):
[0000926326-24-000015:note_history:42]
Short-term deferred revenues of $121.7 million as of December 31, 2023 include deferred revenues from product sales and service contracts, net of deferred cost of sales of $12.4 million. During the three months ended March 31, 2024, the

- changed (2024-08-06):
[0000926326-24-000027:note_history:43]
Deferred revenues from product sales primarily relate to delivered and invoiced products, pending installation and acceptance. Deferred revenues from service contracts primarily relate to services that have been invoiced, where services have not yet been provided. Short-term deferred revenues are expected to be recognized within the next twelve months. Long-term deferred revenues substantially consist of deferred revenues on long-term technical and Advanced Services contracts which have been invoiced and are expected to be recognized as revenue beyond twelve months, generally not more than ten years. The Company generally invoices customers for products upon shipment. Invoicing associated with the service portion of agreements is generally periodic and is billed on a monthly, quarterly, or annual basis, and in certain circumstances, multiple years are billed at one time. Advanced Services agreements are generally invoiced periodically on a monthly, quarterly or annual basis over the life of the agreement. In certain circumstances, portions of these agreements may be invoiced as a lump sum.
  (was, 2024-05-07, similarity 0.9973):
[0000926326-24-000015:note_history:43]
Deferred revenues from product sales primarily relate to delivered and invoiced products, pending installation and acceptance. Deferred revenues from service contracts primarily relate to services that have been invoiced, where services have not yet been provided. Short-term deferred revenues are expected to be recognized within the next twelve months. Long-term deferred revenues substantially consist of deferred revenues on long-term technical and Advanced Services contracts which have been invoiced and are expected to be recognized as revenue beyond twelve months, generally not more than ten years. The Company generally invoices customers for products upon shipment. Invoicing associated with the service portion of agreements is generally periodic and is billed on a monthly, quarterly, or annual basis, and in certain circumstances, multiple years are billed at one time. Advanced Services agreements are generally invoiced periodically on a monthly, quarterly or annual basis over the life of the agreement. In certain circumstances portions of these agreements may be invoiced lump sum.

- changed (2024-08-06):
[0000926326-24-000027:note_history:44]
In addition, the Company has remaining performance obligations associated with contracts for which the associated products have been accepted or associated services have started, but where invoicing has not yet occurred and therefore are not reflected in deferred revenue. These remaining performance obligations are comprised of the non-variable portions of technical services and Advanced Services provided under non-cancellable contracts with minimum commitments. Remaining performance obligations which are not included in deferred revenues were $387.7 million as of June 30, 2024. Remaining performance obligations are expected to be recognized ratably over the remaining terms of the associated contracts, which terms vary but are generally not more than ten years. Remaining performance obligations do not include product obligations, services where the associated product has not been accepted, services which have not yet started, variable portions of services, and certain other obligations.
  (was, 2024-05-07, similarity 0.9939):
[0000926326-24-000015:note_history:44]
In addition, the Company has remaining performance obligations associated with contracts for which the associated products have been accepted or associated services have started, but where invoicing has not yet occurred and therefore are not reflected in deferred revenue. These remaining performance obligations are comprised of the non-variable portions of technical services and Advanced Services provided under non-cancellable contracts with minimum commitments. Remaining performance obligations which are not included in deferred revenues are $359.0 million as of March 31, 2024. Remaining performance obligations are expected to be recognized ratably over the remaining terms of the associated contracts, which terms vary but are generally not more than ten years. Remaining performance obligations do not include product obligations, services where the associated product has not been accepted, services which have not yet started, variable portions of services, and certain other obligations.

- changed (2024-08-06):
[0000926326-24-000027:note_history:45]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three and six months ended June 30, 2024 and 2023. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable balance as of June 30, 2024 and December 31, 2023.
  (was, 2024-05-07, similarity 0.9048):
[0000926326-24-000015:note_history:45]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three months ended March 31, 2024 and 2023. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable balance as of March 31, 2024 and December 31, 2023.

- removed (2024-08-06):
[0000926326-24-000015:note_history:46]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”) and Federal agencies that purchase under a Federal Supply Schedule Contract with the Department of Veterans

- removed (2024-08-06):
[0000926326-24-000015:note_history:47]
Company recognized revenues of $50.2 million, that were included in the corresponding gross short-term deferred revenues balance of $134.1 million as of December 31, 2023.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2024-08-06):
[0000926326-24-000015:note_history:48]
Subsequent Events
On May 2, 2024, the Company announced management’s commitment to the wind down of the Company’s RDS product line, subject to local law and statutory works council consultation requirements. The Company estimates that it will incur approximately $15 million to $20 million of aggregate nonrecurring charges related to the expected reduction in headcount and real estate footprint, and expects that the remaining charges will be incurred in the remainder of 2024 and 2025. Refer to Note 16, Restructuring Expenses, for additional information.
