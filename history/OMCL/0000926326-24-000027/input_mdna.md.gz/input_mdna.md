# OMCL MD&A — 0000926326-24-000027


## mdna

[0000926326-24-000027:mdna:1]
[same as prior period, unchanged from 0000926326-24-000015:mdna:1]

[0000926326-24-000027:mdna:2]
[same as prior period, unchanged from 0000926326-24-000015:mdna:2]

[0000926326-24-000027:mdna:3]
[same as prior period, unchanged from 0000926326-24-000015:mdna:3]

[0000926326-24-000027:mdna:4]
[same as prior period, unchanged from 0000926326-24-000015:mdna:4]

[0000926326-24-000027:mdna:5]
[same as prior period, unchanged from 0000926326-24-000015:mdna:5]

[0000926326-24-000027:mdna:6]
[same as prior period, unchanged from 0000926326-24-000015:mdna:6]

[0000926326-24-000027:mdna:7]
[same as prior period, unchanged from 0000926326-24-000015:mdna:7]

[0000926326-24-000027:mdna:8]
[same as prior period, unchanged from 0000926326-24-000015:mdna:8]

[0000926326-24-000027:mdna:9]
[same as prior period, unchanged from 0000926326-24-000015:mdna:9]

[0000926326-24-000027:mdna:10]
[same as prior period, unchanged from 0000926326-24-000015:mdna:10]

[0000926326-24-000027:mdna:11]
[same as prior period, unchanged from 0000926326-24-000015:mdna:11]

[0000926326-24-000027:mdna:12]
[same as prior period, unchanged from 0000926326-24-000015:mdna:12]

[0000926326-24-000027:mdna:13]
•our belief that our solutions that support the industry vision of the Autonomous Pharmacy are strongly aligned with trends in the healthcare market and are well-positioned to address the evolving needs of healthcare institutions;

[0000926326-24-000027:mdna:14]
[same as prior period, unchanged from 0000926326-24-000015:mdna:14]

[0000926326-24-000027:mdna:15]
[same as prior period, unchanged from 0000926326-24-000015:mdna:15]

[0000926326-24-000027:mdna:16]
•our information technology systems or solutions susceptibility to disruptions, breaches, or cyber-attacks; and

[0000926326-24-000027:mdna:17]
•our ability to generate cash from operations, expected future uses of cash, and estimates regarding, and the sufficiency of, our sources of funding and cash resources.

[0000926326-24-000027:mdna:18]
[same as prior period, unchanged from 0000926326-24-000015:mdna:19]

[0000926326-24-000027:mdna:19]
[same as prior period, unchanged from 0000926326-24-000015:mdna:20]

[0000926326-24-000027:mdna:20]
[same as prior period, unchanged from 0000926326-24-000015:mdna:21]

[0000926326-24-000027:mdna:21]
[same as prior period, unchanged from 0000926326-24-000015:mdna:22]

[0000926326-24-000027:mdna:22]
[same as prior period, unchanged from 0000926326-24-000015:mdna:23]

[0000926326-24-000027:mdna:23]
[same as prior period, unchanged from 0000926326-24-000015:mdna:24]

[0000926326-24-000027:mdna:24]
[same as prior period, unchanged from 0000926326-24-000015:mdna:25]

[0000926326-24-000027:mdna:25]
Omnicell solutions are helping healthcare facilities worldwide to reduce costs, improve labor efficiency, establish new revenue streams, enhance supply chain control, support compliance, and move closer to the industry vision of the Autonomous Pharmacy. We sell our product and consumable solutions together with related service offerings. Revenues generated in the United States represented 92% and 86% of our total revenues for the three months ended June 30, 2024 and 2023, respectively, and 91% and 87% of our total revenues for the six months ended June 30, 2024 and 2023, respectively.

[0000926326-24-000027:mdna:26]
Over the past several years, our business has expanded from a single-point solution to a platform of products and services that will help to further advance the industry vision of the Autonomous Pharmacy. This expansion has resulted in larger deal sizes across multiple products, services, and implementations for customers and, we believe, more comprehensive,

[0000926326-24-000027:mdna:27]
valuable, and enduring relationships. As our business evolves, we continue to evaluate the metrics and methods we use to measure the success of our business.

[0000926326-24-000027:mdna:28]
We utilize bookings as an indicator of the success of our business. We define bookings generally as: (i) the value of non-cancelable contracts for our connected devices, software products, and Advanced Services (although, for those Advanced Services contracts without a minimum commitment, bookings only include the amount of revenue that has been recognized once the services have been provided); and (ii) for our consumables, the value of orders placed through our Omnicell Storefront online platform or through written or telephonic orders. We typically exclude technical services and other less significant items ancillary to our products and services, such as freight revenue, from bookings. In addition, dependent upon counterparty or credit risk, which is evaluated at the time of contract signing, for a given multi-year subscription contract we may reduce the portion of the contractual commitment booked at a given time. As noted, the portfolio of products, solutions and services we offer has evolved. As a result, the ordering process for certain of our solutions has also evolved. For example, orders for certain solutions may not include a purchase order. Connected devices and software license bookings are recorded as revenue upon customer acceptance of the installation or receipt of goods. Revenues from Advanced Services bookings are recorded over the contractual term.

[0000926326-24-000027:mdna:29]
We generally provide installation planning and consulting as part of most connected device product sales, which is typically included in the initial price of the solution. To help ensure the maximum availability of our systems, our customers typically purchase technical services contracts (maintenance and support) in increments of one to five years. In addition to connected device product sales, we provide a range of services to our customers. We also provide Advanced Services such as Central Pharmacy Dispensing Service (service portion), IV Compounding Service (service portion), EnlivenHealth, Specialty Pharmacy Services, 340B solutions, Inventory Optimization Service, and other software solutions, which typically are provided over two to seven years.

[0000926326-24-000027:mdna:30]
[same as prior period, unchanged from 0000926326-24-000015:mdna:30]

[0000926326-24-000027:mdna:31]
[same as prior period, unchanged from 0000926326-24-000015:mdna:31]

[0000926326-24-000027:mdna:32]
[same as prior period, unchanged from 0000926326-24-000015:mdna:32]

[0000926326-24-000027:mdna:33]
[same as prior period, unchanged from 0000926326-24-000015:mdna:33]

[0000926326-24-000027:mdna:34]
[same as prior period, unchanged from 0000926326-24-000015:mdna:34]

[0000926326-24-000027:mdna:35]
[same as prior period, unchanged from 0000926326-24-000015:mdna:35]

[0000926326-24-000027:mdna:36]
Our full-time employee headcount was approximately 3,630 and 3,650 on June 30, 2024 and December 31, 2023, respectively.

[0000926326-24-000027:mdna:37]
[same as prior period, unchanged from 0000926326-24-000015:mdna:37]

[0000926326-24-000027:mdna:38]
[same as prior period, unchanged from 0000926326-24-000015:mdna:38]

[0000926326-24-000027:mdna:39]
[same as prior period, unchanged from 0000926326-24-000015:mdna:39]

[0000926326-24-000027:mdna:40]
The U.S. spent a total of $634 billion on prescription drugs in 2022, an increase of 9% compared to 2021, and prescription drugs impact the vast majority of patients in virtually all settings of care. We believe there are significant challenges facing the practice of pharmacy today including, but not limited to, budget constraints, increased healthcare worker turnover rates, labor shortages, drug shortages, drug diversion, manual and error-prone processes, complex compliance requirements, and limited inventory visibility. Each of these challenges may lead to poor medication management outcomes including, but not limited to, medication errors, adverse drug events, lack of patient adherence, and medication waste. We also recognize that these challenges may impact the timing of contracting for, or implementing, our products, solutions, or services. However, we believe that over time these significant challenges to the practice of pharmacy will drive demand for increased

[0000926326-24-000027:mdna:41]
automation, visibility, insights, and improved medication management outcomes that our solutions are designed to enable. Because of this, we believe that our solutions are well-positioned to address the evolving needs of healthcare institutions and therefore present opportunities for long-term growth.

[0000926326-24-000027:mdna:42]
[same as prior period, unchanged from 0000926326-24-000015:mdna:41]

[0000926326-24-000027:mdna:43]
•Point of Care.  As a market leader, we expect to continue expansion into this product market as customers increase the use of our dispensing systems in more areas within their hospitals and increasingly in ambulatory care settings. While the macroeconomic environment is showing some signs of improvement, we recognize that some health system customers may still be facing budgetary or labor constraints, which may impact our customers’ considerations in the near term when they are determining whether to implement new solutions and workflows. As we are largely through the replacement cycle of our previous generation of automated dispensing systems, we are seeing demand moderate. With the launch of next-generation enhancements and solutions for points of care, we believe we are providing a path for customers to maximize the value of their existing technology investments through upgrades and acquisitions of new program offerings for their current installed base. We also believe there is an opportunity for us to expand this offering and define a new standard for dispensing systems in ambulatory settings. We believe our current solutions within the Point of Care market and new innovation and services will continue to help customers drive improved clinical and financial outcomes.

[0000926326-24-000027:mdna:44]
[same as prior period, unchanged from 0000926326-24-000015:mdna:43]

[0000926326-24-000027:mdna:45]
[same as prior period, unchanged from 0000926326-24-000015:mdna:44]

[0000926326-24-000027:mdna:46]
[same as prior period, unchanged from 0000926326-24-000015:mdna:46]

[0000926326-24-000027:mdna:47]
[same as prior period, unchanged from 0000926326-24-000015:mdna:45]

[0000926326-24-000027:mdna:48]
[same as prior period, unchanged from 0000926326-24-000015:mdna:47]

[0000926326-24-000027:mdna:49]
[same as prior period, unchanged from 0000926326-24-000015:mdna:48]

[0000926326-24-000027:mdna:50]
[same as prior period, unchanged from 0000926326-24-000015:mdna:49]

[0000926326-24-000027:mdna:51]
[same as prior period, unchanged from 0000926326-24-000015:mdna:50]

[0000926326-24-000027:mdna:52]
[same as prior period, unchanged from 0000926326-24-000015:mdna:51]

[0000926326-24-000027:mdna:53]
[same as prior period, unchanged from 0000926326-24-000015:mdna:52]

[0000926326-24-000027:mdna:54]
[same as prior period, unchanged from 0000926326-24-000015:mdna:53]

[0000926326-24-000027:mdna:55]
[same as prior period, unchanged from 0000926326-24-000015:mdna:54]

[0000926326-24-000027:mdna:56]
[same as prior period, unchanged from 0000926326-24-000015:mdna:55]

[0000926326-24-000027:mdna:57]
[same as prior period, unchanged from 0000926326-24-000015:mdna:56]

[0000926326-24-000027:mdna:58]
[same as prior period, unchanged from 0000926326-24-000015:mdna:57]

[0000926326-24-000027:mdna:59]
[same as prior period, unchanged from 0000926326-24-000015:mdna:58]

[0000926326-24-000027:mdna:60]
[same as prior period, unchanged from 0000926326-24-000015:mdna:59]

[0000926326-24-000027:mdna:61]
There were no material changes in the matters for which we make critical accounting estimates in the preparation of our Condensed Consolidated Financial Statements during the six months ended June 30, 2024 as compared to those disclosed in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” included in our Annual Report on Form 10-K for the year ended December 31, 2023.

[0000926326-24-000027:mdna:62]
[same as prior period, unchanged from 0000926326-24-000015:mdna:61]

[0000926326-24-000027:mdna:63]
Refer to “Recently Issued Authoritative Guidance” in Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q for a description of recently issued accounting pronouncements, including the expected dates of adoption and estimated effects on our results of operations, financial position, and cash flows.

[0000926326-24-000027:mdna:64]
[same as prior period, unchanged from 0000926326-24-000015:mdna:63]

[0000926326-24-000027:mdna:65]
[same as prior period, unchanged from 0000926326-24-000015:mdna:64]

[0000926326-24-000027:mdna:66]
|  | Three Months Ended June 30, |
|  |  |  |  |  | Change in |
|  | 2024 |  | 2023 |  | $ |  | % |
|  | (Dollars in thousands) |
| Product revenues | $ | 156,580 |  |  | $ | 188,436 |  |  | $ | (31,856) |  |  | (17)% |
| Percentage of total revenues | 57% |  | 63% |  |  |  |  |
| Service revenues | 120,208 |  |  | 110,537 |  |  | $ | 9,671 |  |  | 9% |
| Percentage of total revenues | 43% |  | 37% |  |  |  |  |
| Total revenues | $ | 276,788 |  |  | $ | 298,973 |  |  | $ | (22,185) |  |  | (7)% |

[0000926326-24-000027:mdna:67]
Product revenues represented 57% and 63% of total revenues for the three months ended June 30, 2024 and 2023, respectively. Product revenues decreased by $31.9 million, primarily due to lower volumes from our automated dispensing systems business primarily as a result of the impact of a continued challenging environment for some of our health system customers and the timing of our XT Series systems lifecycle, as we are largely through the replacement cycle.

[0000926326-24-000027:mdna:68]
Service revenues represented 43% and 37% of total revenues for the three months ended June 30, 2024 and 2023, respectively. Service revenues include revenues from technical services and Advanced Services offerings. Service revenues increased by $9.7 million, primarily due to an increase of $2.1 million in technical services revenues as a result of growth in our installed customer base and the impact of pricing actions, as well as an increase of $7.5 million in Advanced Services revenues due to continued customer demand.

[0000926326-24-000027:mdna:69]
Our international sales represented 8% and 14% of total revenues for the three months ended June 30, 2024 and 2023, respectively, and are expected to be affected by foreign currency exchange rate fluctuations. We are unable to predict the extent to which revenues in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-24-000027:mdna:70]
|  | Six Months Ended June 30, |
|  |  |  |  |  | Change in |
|  | 2024 |  | 2023 |  | $ |  | % |
|  | (Dollars in thousands) |
| Product revenues | $ | 289,875 |  |  | $ | 374,151 |  |  | $ | (84,276) |  |  | (23)% |
| Percentage of total revenues | 55% |  | 63% |  |  |  |  |
| Service revenues | 233,064 |  |  | 215,451 |  |  | 17,613 |  |  | 8% |
| Percentage of total revenues | 45% |  | 37% |  |  |  |  |
| Total revenues | $ | 522,939 |  |  | $ | 589,602 |  |  | $ | (66,663) |  |  | (11)% |

[0000926326-24-000027:mdna:71]
Product revenues represented 55% and 63% of total revenues for the six months ended June 30, 2024 and 2023, respectively. Product revenues decreased by $84.3 million, due to lower volumes from our automated dispensing systems business primarily as a result of the impact of a continued challenging environment for some of our health system customers and the timing of our XT Series systems lifecycle, as we are largely through the replacement cycle.

[0000926326-24-000027:mdna:72]
Service revenues represented 45% and 37% of total revenues for the six months ended June 30, 2024 and 2023, respectively. Service revenues include revenues from technical services and Advanced Services offerings. Service revenues increased by $17.6 million, primarily due to an increase of $7.3 million in technical services revenues as a result of growth in our installed customer base and the impact of pricing actions, as well as an increase of $10.3 million in Advanced Services revenues due to continued customer demand.

[0000926326-24-000027:mdna:73]
Our international sales represented 9% and 13% of total revenues for the six months ended June 30, 2024 and 2023, respectively, and are expected to be affected by foreign currency exchange rate fluctuations. We are unable to predict the extent to which revenues in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-24-000027:mdna:74]
Our ability to continue to grow revenues is dependent on our ability to continue to obtain orders from customers, which may be dependent upon customers’ capital equipment budgets and/or capital equipment approval cycles, our ability to produce quality products and consumables to fulfill customer demand, the volume of installations we are able to complete, our ability to meet customer needs by providing a quality installation experience, our ability to develop new or enhance existing

[0000926326-24-000027:mdna:75]
solutions, and our flexibility in workforce allocations among customers to complete installations on a timely basis. The timing of our product revenues for equipment is primarily dependent on when our customers’ schedules and/or staffing levels allow for installations.

[0000926326-24-000027:mdna:76]
[same as prior period, unchanged from 0000926326-24-000015:mdna:70]

[0000926326-24-000027:mdna:77]
[same as prior period, unchanged from 0000926326-24-000015:mdna:71]

[0000926326-24-000027:mdna:78]
|  | Three Months Ended June 30, |
|  |  |  |  |  | Change in |
|  | 2024 |  | 2023 |  | $ |  | % |
|  | (Dollars in thousands) |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | $ | 99,381 |  |  | $ | 107,962 |  |  | $ | (8,581) |  |  | (8)% |
| As a percentage of related revenues | 63% |  | 57% |  |  |  |  |
| Cost of service revenues | 63,056 |  |  | 56,568 |  |  | $ | 6,488 |  |  | 11% |
| As a percentage of related revenues | 52% |  | 51% |  |  |  |  |
| Total cost of revenues | $ | 162,437 |  |  | $ | 164,530 |  |  | $ | (2,093) |  |  | (1)% |
| As a percentage of total revenues | 59% |  | 55% |  |  |  |  |
| Gross profit | $ | 114,351 |  |  | $ | 134,443 |  |  | $ | (20,092) |  |  | (15)% |
| Gross margin | 41% |  | 45% |  |  |  |  |

[0000926326-24-000027:mdna:79]
Cost of revenues for the three months ended June 30, 2024 compared to the three months ended June 30, 2023 decreased by $2.1 million, primarily driven by a $8.6 million decrease in cost of product revenues, partially offset by a $6.5 million increase in cost of service revenues.

[0000926326-24-000027:mdna:80]
The decrease in cost of product revenues was primarily driven by the decrease in product revenues of $31.9 million for the three months ended June 30, 2024 compared to the three months ended June 30, 2023. The decrease in cost of product revenues has not decreased proportionally with the decrease in product revenues for the three months ended June 30, 2024, primarily due to the decrease in revenues of higher margin products as well as the impact of certain fixed costs, such as labor and overhead. In addition, the decrease in cost of product revenues was partially offset by $5.4 million of inventory write-down charges related to the planned RDS product line wind down incurred during the three months ended June 30, 2024. The increase in cost of service revenues was primarily driven by the increase in service revenues of $9.7 million for the three months ended June 30, 2024 compared to the three months ended June 30, 2023.

[0000926326-24-000027:mdna:81]
The overall decrease in gross margin primarily relates to lower product revenues for the three months ended June 30, 2024 compared to the three months ended June 30, 2023, whereas the decrease in cost of product revenues has not decreased proportionally with the decrease in product revenues, primarily due to the decrease in revenues of higher margin products as well as the impact of certain fixed costs, such as labor and overhead. The decrease is partially offset by inventory write-down charges related to the planned RDS product line wind down incurred during the three months ended June 30, 2024. Our gross profit for the three months ended June 30, 2024 was $114.4 million, as compared to $134.4 million for the three months ended June 30, 2023.

[0000926326-24-000027:mdna:82]
|  | Six Months Ended June 30, |
|  |  |  |  |  | Change in |
|  | 2024 |  | 2023 |  | $ |  | % |
|  | (Dollars in thousands) |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | $ | 191,822 |  |  | $ | 217,489 |  |  | $ | (25,667) |  |  | (12)% |
| As a percentage of related revenues | 66% |  | 58% |  |  |  |  |
| Cost of service revenues | 124,143 |  |  | 112,641 |  |  | $ | 11,502 |  |  | 10% |
| As a percentage of related revenues | 53% |  | 52% |  |  |  |  |
| Total cost of revenues | $ | 315,965 |  |  | $ | 330,130 |  |  | $ | (14,165) |  |  | (4)% |
| As a percentage of total revenues | 60% |  | 56% |  |  |  |  |
| Gross profit | $ | 206,974 |  |  | $ | 259,472 |  |  | $ | (52,498) |  |  | (20)% |
| Gross margin | 40% |  | 44% |  |  |  |  |

[0000926326-24-000027:mdna:83]
Cost of revenues for the six months ended June 30, 2024 compared to the six months ended June 30, 2023 decreased by $14.2 million, primarily driven by a $25.7 million decrease in cost of product revenues, partially offset by a $11.5 million increase in cost of service revenues.

[0000926326-24-000027:mdna:84]
The decrease in cost of product revenues was primarily driven by the decrease in product revenues of $84.3 million for the six months ended June 30, 2024 compared to the six months ended June 30, 2023. The decrease in cost of product revenues has not decreased proportionally with the decrease in product revenues for the six months ended June 30, 2024, primarily due to the decrease in revenues of higher margin products as well as the impact of certain fixed costs, such as labor and overhead. In addition, the decrease in cost of product revenues was partially offset by $5.4 million of inventory write-down charges related to the planned RDS product line wind down and an increase of $2.0 million of restructuring costs incurred during the six months ended June 30, 2024. The increase in cost of service revenues was primarily driven by the increase in service revenues of $17.6 million for the six months ended June 30, 2024 compared to the six months ended June 30, 2023.

[0000926326-24-000027:mdna:85]
The overall decrease in gross margin primarily relates to lower product revenues for the six months ended June 30, 2024 compared to the six months ended June 30, 2023, whereas the decrease in cost of product revenues has not decreased proportionally with the decrease in product revenues, primarily due to the decrease in revenues of higher margin products as well as the impact of certain fixed costs, such as labor and overhead. The decrease is partially offset by inventory write-down charges related to the planned RDS product line wind down and restructuring costs incurred during the six months ended June 30, 2024. Our gross profit for the six months ended June 30, 2024 was $207.0 million, as compared to $259.5 million for the six months ended June 30, 2023.

[0000926326-24-000027:mdna:86]
[same as prior period, unchanged from 0000926326-24-000015:mdna:76]

[0000926326-24-000027:mdna:87]
|  | Three Months Ended June 30, |
|  |  |  |  |  | Change in |
|  | 2024 |  | 2023 |  | $ |  | % |
|  | (Dollars in thousands) |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | $ | 21,102 |  |  | $ | 23,137 |  |  | $ | (2,035) |  |  | (9)% |
| As a percentage of total revenues | 8% |  | 8% |  |  |  |  |
| Selling, general, and administrative | 90,025 |  |  | 103,558 |  |  | $ | (13,533) |  |  | (13)% |
| As a percentage of total revenues | 33% |  | 35% |  |  |  |  |
| Total operating expenses | $ | 111,127 |  |  | $ | 126,695 |  |  | $ | (15,568) |  |  | (12)% |
| As a percentage of total revenues | 40% |  | 42% |  |  |  |  |
| Interest and other income (expense), net | $ | 4,973 |  |  | $ | 4,461 |  |  | $ | 512 |  |  | 11% |

[0000926326-24-000027:mdna:88]
34

[0000926326-24-000027:mdna:89]
Research and Development. Research and development expenses decreased by $2.0 million for the three months ended June 30, 2024 compared to the three months ended June 30, 2023. The decrease was primarily attributed to a decrease in employee-related expenses as a result of lower headcount.

[0000926326-24-000027:mdna:90]
Selling, General, and Administrative. Selling, general, and administrative expenses decreased by $13.5 million for the three months ended June 30, 2024 compared to the three months ended June 30, 2023. The decrease was primarily due to a decrease of $9.8 million in employee-related expenses as a result of lower headcount and a decrease of $2.0 million in commissions expenses.

[0000926326-24-000027:mdna:91]
Interest and Other Income (Expense), Net. Interest and other income (expense), net changed by $0.5 million for the three months ended June 30, 2024 compared to the three months ended June 30, 2023, primarily driven by a $0.8 million increase in other income and a $0.3 million increase in other expense. The increase in other income during the three months ended June 30, 2024 as compared to the three months ended June 30, 2023 is primarily attributable to higher interest income received due to higher interest rates and higher cash and cash equivalents balances.

[0000926326-24-000027:mdna:92]
|  | Six Months Ended June 30, |
|  |  |  |  |  | Change in |
|  | 2024 |  | 2023 |  | $ |  | % |
|  | (Dollars in thousands) |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | $ | 43,158 |  |  | $ | 46,015 |  |  | $ | (2,857) |  |  | (6)% |
| As a percentage of total revenues | 8% |  | 8% |  |  |  |  |
| Selling, general, and administrative | 182,439 |  |  | 228,672 |  |  | $ | (46,233) |  |  | (20)% |
| As a percentage of total revenues | 35% |  | 39% |  |  |  |  |
| Total operating expenses | $ | 225,597 |  |  | $ | 274,687 |  |  | $ | (49,090) |  |  | (18)% |
| As a percentage of total revenues | 43% |  | 47% |  |  |  |  |
| Interest and other income (expense), net | $ | 8,989 |  |  | $ | 6,242 |  |  | $ | 2,747 |  |  | 44% |

[0000926326-24-000027:mdna:93]
Research and Development. Research and development expenses decreased by $2.9 million for the six months ended June 30, 2024 compared to the six months ended June 30, 2023. The decrease was primarily attributed to a decrease in employee-related expenses as a result of lower headcount.

[0000926326-24-000027:mdna:94]
Selling, General, and Administrative. Selling, general, and administrative expenses decreased by $46.2 million for the six months ended June 30, 2024 compared to the six months ended June 30, 2023. The decrease was primarily due to a decrease of $22.6 million in employee-related expenses as a result of lower headcount, a decrease of $8.4 million in impairment and abandonment charges of operating lease right-of-use and other assets in connection with restructuring activities of certain leased facilities, a decrease of $5.0 million in restructuring costs, a decrease of $3.2 million in commissions expenses, and a decrease of $1.5 million in freight out.

[0000926326-24-000027:mdna:95]
Interest and Other Income (Expense), Net. Interest and other income (expense), net changed by $2.7 million for the six months ended June 30, 2024 compared to the six months ended June 30, 2023, primarily driven by a $3.6 million increase in other income and a $0.9 million increase in other expense. The increase in other income during the six months ended June 30, 2024 as compared to the six months ended June 30, 2023 is primarily attributable to higher interest income received due to higher interest rates and higher cash and cash equivalents balances.

[0000926326-24-000027:mdna:96]
Provision for Income Taxes

[0000926326-24-000027:mdna:97]
|  | Three Months Ended June 30, |
|  |  |  |  |  | Change in |
|  | 2024 |  | 2023 |  | $ |  | % |
|  | (Dollars in thousands) |
| Provision for income taxes | $ | 4,462 |  |  | $ | 8,758 |  |  | $ | (4,296) |  |  | (49)% |

[0000926326-24-000027:mdna:98]
|  | Six Months Ended June 30, |
|  |  |  |  |  | Change in |
|  | 2024 |  | 2023 |  | $ |  | % |
|  | (Dollars in thousands) |
| Provision for income taxes | $ | 2,307 |  |  | $ | 2,576 |  |  | $ | (269) |  |  | (10)% |

[0000926326-24-000027:mdna:99]
For the six months ended June 30, 2024 and 2023, we recorded a provision for income taxes of $2.3 million and $2.6 million, respectively, by applying our estimated annual effective tax rate to our year-to-date measure of ordinary income and adjusted for $3.3 million and $2.7 million, respectively, of discrete income tax expense primarily from equity compensation. The change in the provision for income taxes for the six months ended June 30, 2024 compared to the provision for income taxes for the same period in 2023 was insignificant, comprising of various offsetting components of annual effective tax rate and discrete income tax expense.

[0000926326-24-000027:mdna:100]
[same as prior period, unchanged from 0000926326-24-000015:mdna:85]

[0000926326-24-000027:mdna:101]
[same as prior period, unchanged from 0000926326-24-000015:mdna:86]

[0000926326-24-000027:mdna:102]
We had cash and cash equivalents of $556.8 million at June 30, 2024 compared to $468.0 million at December 31, 2023. All of our cash and cash equivalents are invested in bank accounts and money market funds held in sweep and asset management accounts with financial institutions of high credit quality.

[0000926326-24-000027:mdna:103]
Our cash position and working capital at June 30, 2024 and December 31, 2023 were as follows:

[0000926326-24-000027:mdna:104]
|  | June 30,2024 |  | December 31,2023 |
|  | (In thousands) |
| Cash and cash equivalents | $ | 556,781 |  |  | $ | 467,972 |  |
| Working capital | $ | 588,546 |  |  | $ | 559,779 |  |

[0000926326-24-000027:mdna:105]
Our ratio of current assets to current liabilities was 2.4:1 and 2.5:1 at June 30, 2024 and December 31, 2023, respectively.

[0000926326-24-000027:mdna:106]
[same as prior period, unchanged from 0000926326-24-000015:mdna:91]

[0000926326-24-000027:mdna:107]
Revolving Credit Facility

[0000926326-24-000027:mdna:108]
On November 15, 2019, Omnicell, Inc. entered into an Amended and Restated Credit Agreement (as amended, the “Prior A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers, and Wells Fargo Bank, National Association, as administrative agent. The Prior A&R Credit Agreement provided for (a) a five-year revolving credit facility of $500.0 million (the “Prior Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million (the “Prior Incremental Facility”). In addition, the Prior A&R Credit Agreement included a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The Prior A&R Credit Agreement was subsequently amended on September 22, 2020 and March 29, 2023 to permit the issuance of the convertible senior notes and the purchase of the convertible note hedge transactions (as described in Note 10, Convertible Senior Notes, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q), expand our flexibility to make restricted payments (including common stock repurchases), and replace the total net leverage covenant, as well as to remove and replace the interest rate benchmark based on the London interbank offered rate (“LIBOR”) and related LIBOR-based mechanics with an interest rate benchmark based on

[0000926326-24-000027:mdna:109]
the secured overnight financing rate (“SOFR”) as administered by the Federal Reserve Bank of New York and related SOFR-based mechanics.

[0000926326-24-000027:mdna:110]
On October 10, 2023, Omnicell, Inc. entered into a Second Amended and Restated Credit Agreement (the “Second A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, JPMorgan Chase Bank, N.A., PNC Capital Markets LLC and TD Securities (USA) LLC as joint lead arrangers and Wells Fargo Bank, National Association, as administrative agent. The Second A&R Credit Agreement supersedes the Prior A&R Credit Agreement and provides for (a) a five-year revolving credit facility of $350.0 million (the “Current Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to an amount equal to the sum of (i) the greater of $250.0 million and 100% of the adjusted consolidated EBITDA for the last four quarters and (ii) additional amounts subject to pro forma compliance with certain consolidated secured net leverage ratio (the “Current Incremental Facility”). In addition, the Second A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The Second A&R Credit Agreement has an expiration date of October 10, 2028, subject to acceleration under certain conditions, upon which date all remaining outstanding borrowings will be due and payable.

[0000926326-24-000027:mdna:111]
As of June 30, 2024, we had $350.0 million of funds available under the Current Revolving Credit Facility. As of June 30, 2024, there was no outstanding balance under the Current Revolving Credit Facility and we were in full compliance with all covenants. Refer to Note 9, Debt and Credit Agreement, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional information. We expect to use future loans under the Current Revolving Credit Facility, if any, for working capital, potential acquisitions, and other general corporate purposes.

[0000926326-24-000027:mdna:112]
[same as prior period, unchanged from 0000926326-24-000015:mdna:98]

[0000926326-24-000027:mdna:113]
Our future uses of cash are expected to be primarily for working capital, capital expenditures, and other contractual obligations. We also expect a continued use of cash for potential acquisitions and acquisition-related activities, as well as repurchases of our common stock. In addition, we may also use a portion of our cash as we consider various options related to our outstanding debt.

[0000926326-24-000027:mdna:114]
The 2016 Repurchase Program has a total of $2.7 million remaining for future repurchases as of June 30, 2024, which may result in additional use of cash. There were no stock repurchases during the six months ended June 30, 2024. Refer to “Stock Repurchase Programs” under Note 15, Employee Benefits and Share-Based Compensation, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional information.

[0000926326-24-000027:mdna:115]
Based on our current business plan and backlog, we believe that our existing cash and cash equivalents, our anticipated cash flows from operations, cash generated from the exercise of employee stock options and purchases under our Employee Stock Purchase Plan (“ESPP”), along with the availability of funds under the Current Revolving Credit Facility will be sufficient to meet our cash needs for working capital, capital expenditures, potential acquisitions, and other contractual obligations for at least the next twelve months. For periods beyond the next twelve months, we also anticipate that our net operating cash flows plus existing balances of cash and cash equivalents will suffice to fund the growth of our business.

[0000926326-24-000027:mdna:116]
[same as prior period, unchanged from 0000926326-24-000015:mdna:102]

[0000926326-24-000027:mdna:117]
[same as prior period, unchanged from 0000926326-24-000015:mdna:103]

[0000926326-24-000027:mdna:118]
|  | Six Months Ended June 30, |
|  | 2024 |  | 2023 |
|  | (In thousands) |
| Net cash provided by (used in): |  |  |  |
| Operating activities | $ | 108,653 |  |  | $ | 85,673 |  |
| Investing activities | (25,889) |  |  | (28,457) |  |
| Financing activities | (4,702) |  |  | 7,465 |  |
| Effect of exchange rate changes on cash and cash equivalents | (802) |  |  | 148 |  |
| Net increase in cash, cash equivalents, and restricted cash | $ | 77,260 |  |  | $ | 64,829 |  |

[0000926326-24-000027:mdna:119]
[same as prior period, unchanged from 0000926326-24-000015:mdna:105]

[0000926326-24-000027:mdna:120]
[same as prior period, unchanged from 0000926326-24-000015:mdna:106]

[0000926326-24-000027:mdna:121]
Net cash provided by operating activities was $108.7 million for the six months ended June 30, 2024, primarily consisting of operating inflows of $52.4 million and favorable working capital movements of $56.3 million. Operating inflows consisted of a net loss of $11.9 million, adjusted for non-cash items of $64.3 million, which consisted primarily of depreciation and amortization expense of $42.1 million, share-based compensation expense of $18.7 million, and inventory write-down charges of $5.4 million. The favorable working capital was primarily due to an increase in deferred revenues of $22.1 million driven by an increase in billings, a decrease in inventories of $11.2 million resulting from inventory management initiatives, and a decrease in accounts receivable and unbilled receivables of $10.9 million driven by overall business activity and the timing of billings and collections.

[0000926326-24-000027:mdna:122]
Net cash provided by operating activities was $85.7 million for the six months ended June 30, 2023, primarily consisting of operating inflows of $64.8 million and favorable working capital movements of $20.9 million. Operating inflows consisted of a net loss of $11.5 million, adjusted for non-cash items of $76.3 million, which consisted primarily of depreciation and amortization expense of $44.1 million, share-based compensation expense of $28.1 million, and impairment and abandonment charges on operating lease right-of-use assets of $7.8 million. The favorable working capital was primarily due to a decrease in accounts receivable and unbilled receivables of $26.5 million due to the timing of billings and collections, a decrease in inventories of $17.8 million resulting from inventory management initiatives, and an increase in deferred revenues of $16.5 million driven by increased billings. These cash inflows were partially offset by a decrease in accrued compensation of $21.0 million and a decrease in accounts payable of $15.8 million, due to an overall decrease in spending and the timing of payments.

[0000926326-24-000027:mdna:123]
[same as prior period, unchanged from 0000926326-24-000015:mdna:109]

[0000926326-24-000027:mdna:124]
Net cash used in investing activities was $25.9 million for the six months ended June 30, 2024, which consisted of capital expenditures of $18.5 million for property and equipment and $7.4 million for external-use software development costs.

[0000926326-24-000027:mdna:125]
Net cash used in investing activities was $28.5 million for the six months ended June 30, 2023, which consisted of capital expenditures of $21.8 million for property and equipment, and $6.7 million for external-use software development costs.

[0000926326-24-000027:mdna:126]
[same as prior period, unchanged from 0000926326-24-000015:mdna:112]

[0000926326-24-000027:mdna:127]
Net cash used in financing activities was $4.7 million for the six months ended June 30, 2024, primarily due to a net change in the customer funds balances of $11.6 million, partially offset by $8.1 million in proceeds from employee stock option exercises and ESPP purchases.

[0000926326-24-000027:mdna:128]
Net cash provided by financing activities was $7.5 million for the six months ended June 30, 2023, primarily due to $15.2 million in proceeds from employee stock option exercises and ESPP purchases, partially offset by $3.5 million in employees’ taxes paid related to restricted stock unit vesting and a net change in the customer funds balances of $4.3 million.

[0000926326-24-000027:mdna:129]
[same as prior period, unchanged from 0000926326-24-000015:mdna:115]

[0000926326-24-000027:mdna:130]
There have been no significant changes during the six months ended June 30, 2024 to the contractual obligations disclosed in “Management’s Discussion and Analysis of Financial Condition and Results of Operations,” set forth in Part II, Item 7, of our Annual Report on Form 10-K for the year ended December 31, 2023.

[0000926326-24-000027:mdna:131]
Contractual obligations as of June 30, 2024 were as follows:

[0000926326-24-000027:mdna:132]
|  | Payments Due By Period |
|  | Total |  | Remainder of 2024 |  | 2025 - 2026 |  | 2027 - 2028 |  | 2029 and thereafter |
|  | (In thousands) |
| Operating leases (1) | $ | 49,952 |  |  | $ | 6,354 |  |  | $ | 23,704 |  |  | $ | 17,652 |  |  | $ | 2,242 |  |
| Purchase obligations (2) | $ | 107,913 |  |  | 87,293 |  |  | 20,545 |  |  | 75 |  |  | — |  |
| Convertible senior notes (3) | $ | 577,157 |  |  | 719 |  |  | 576,438 |  |  | — |  |  | — |  |
| Total (4) | $ | 735,022 |  |  | $ | 94,366 |  |  | $ | 620,687 |  |  | $ | 17,727 |  |  | $ | 2,242 |  |

[0000926326-24-000027:mdna:133]
[same as prior period, unchanged from 0000926326-24-000015:mdna:119]

[0000926326-24-000027:mdna:134]
[same as prior period, unchanged from 0000926326-24-000015:mdna:120]

[0000926326-24-000027:mdna:135]
[same as prior period, unchanged from 0000926326-24-000015:mdna:121]

[0000926326-24-000027:mdna:136]
[same as prior period, unchanged from 0000926326-24-000015:mdna:122]

[0000926326-24-000027:mdna:137]
(4)Refer to Note 13, Commitments and Contingencies, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional information.
