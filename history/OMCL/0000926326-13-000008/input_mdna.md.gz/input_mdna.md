# OMCL MD&A — 0000926326-13-000008


## mdna

[0000926326-13-000008:mdna:1]
ITEM 7.    MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0000926326-13-000008:mdna:2]
The following discussion and analysis should be read in conjunction with our financial statements and related notes included elsewhere in this Annual Report on Form 10-K. This discussion may contain forward-looking statements based upon current expectations that involve risks and uncertainties. Our actual results and the timing of selected events could differ materially from those anticipated in these forward-looking statements as a result of several factors, including those set forth under Item 1A "Risk Factors" and elsewhere in this Annual Report on Form 10-K. Unless otherwise stated, references in this report to particular years or quarters refer to our fiscal year and the associated quarters of those fiscal years.

[0000926326-13-000008:mdna:3]
Overview

[0000926326-13-000008:mdna:4]
We were incorporated in California in 1992 under the name Omnicell Technologies, Inc. and reincorporated in Delaware in 2001 as Omnicell, Inc. We are a leading provider of automated solutions for medication and supply management in healthcare. Our automation and analytics solutions are designed to enable healthcare facilities to acquire, manage, dispense and administer medications and medical-surgical supplies and are intended to enhance patient safety, reduce medication errors, reduce operating costs, improve workflow and increase operational efficiency. Approximately 2,700 hospitals utilize one or more of our products, of which more than 1,700 hospitals in the United States have installed our automated hardware/software solutions for controlling, dispensing, acquiring, verifying, tracking and analyzing medications and medical and surgical supplies. Approximately 6,000 institutional and retail pharmacies utilize our medication adherence packaging solutions.

[0000926326-13-000008:mdna:5]
We sell our medication control systems together with related consumables and services, and medical and surgical supply control systems and generate the majority of our revenue in the United States. However, we expect our revenue from our international operations to increase in future periods as we continue to grow our international business. Our sales force is organized by geographic region in the United States and Canada, and for a portion of our products in the United Kingdom and Germany. We also sell through distributors in Asia, Australia, Europe, the Middle East and South America. We have not sold in the past, and have no future plans to sell our products either directly or indirectly to customers located in countries that are identified as state sponsors of terrorism by the U.S. Department of State, and are subject to economic sanctions and export controls.

[0000926326-13-000008:mdna:6]
In May 2012, we completed our acquisition of MedPak Holdings, Inc. ("MedPak"). MedPak is the parent company of MTS Medication Technologies, Inc. ("MTS"), a worldwide provider of medication adherence packaging systems. This acquisition aligns us with the long-term trends of the healthcare market to manage the health of patients across the continuum of care giving us the ability to serve both the acute and non-acute markets. Omnicell and MTS bring capabilities to each other that strengthen the product lines and expand the medication management coverage of both companies. Please refer to Note 2, "Business Acquisition" to the Notes to Consolidated Financial Statements included elsewhere in this Annual Report on Form 10-K for more information regarding the transaction.

[0000926326-13-000008:mdna:7]
In connection with this acquisition, we realigned our management reporting structure to identify those dispensing systems and other related business transactions that are sold into long-term care pharmacies and facilities. Accordingly, the operations of this portion of our activities are now being reflected as a part of the Non-Acute Care segment for the year ended December 31, 2012. Please refer to Note 17, "Segments" to the Notes to Consolidated Financial Statements included elsewhere in this Annual Report on Form 10-K for more information regarding the results for both the Acute Care and Non-Acute Care segments.

[0000926326-13-000008:mdna:8]
In the third quarter of 2012, we entered into an agreement with our distributor in the United Kingdom to purchase 15% of its outstanding equity for approximately $0.9 million in cash to accelerate the adoption of medication and supply automation in the United Kingdom. In connection with the investment, we have the right, under certain circumstances, to appoint a member to this company's board of directors as well as certain other voting rights. As a result of these and other factors, we are accounting for this investment using the equity method. Our proportionate equity share of the income of this distributor recognized in our financial statements for the year ended December 31, 2012 was immaterial.

[0000926326-13-000008:mdna:9]
We are working to develop relationships with major providers of hospital information management systems with the goal of enhancing the interoperability of our products with their systems. We believe that enhanced interoperability will help reduce implementation costs, time, and maintenance for shared clients, while providing new clinical workflows designed to enhance efficiency and patient safety.

[0000926326-13-000008:mdna:10]
Our revenue increased by 27.9% to $314.0 million in the twelve month period ended December 31, 2012 from $245.5 million for the year ended December 31, 2011. Of the $68.5 million increase in revenues from 2011 to 2012, $61.8 million was attributable to an increase in product revenues for 2012 as compared with 2011, reflecting increased completed installations of

[0000926326-13-000008:mdna:11]
our new automation products, increases in lease renewals from existing customers, and revenue derived from our acquisition of MTS, during the second quarter of 2012, which comprises the predominant portion of our Non-Acute Care segment. Service revenues increased by $6.7 million in 2012 as compared with 2011, primarily due to growth in the installed customer base.

[0000926326-13-000008:mdna:12]
For the year ended December 31, 2012, our Acute Care segment contributed $197.4 million and $62.8 million in product and service revenue, respectively. This compares to product and service revenue of $185.9 million and $59.7 million for the Acute Care segment in 2011. For the year ended December 31, 2012, the Non-Acute Care segment contributed $50.3 million and $3.6 million in product and service revenue, respectively. Non-Acute Care revenues were not significant for the year ended December 31, 2011 and, accordingly, have been included in the Acute Care segment for that period.

[0000926326-13-000008:mdna:13]
We believe that demand for our products in future periods will be based on:

[0000926326-13-000008:mdna:14]
| • | Our expectation that the overall market demand for healthcare services will increase as the population grows, life expectancies continue to increase, the quality of healthcare services increases and the availability of healthcare services increases; |

[0000926326-13-000008:mdna:15]
| • | Our expectation that the environment of increased patient safety awareness, increased regulatory control and increased need for workflow efficiency through the adoption of technology in the healthcare industry will make our solutions a priority in the capital budgets of healthcare facilities; |

[0000926326-13-000008:mdna:16]
| • | Our continued ability to differentiate ourselves through a strategy intended to provide the best customer experience in the healthcare industry; and |

[0000926326-13-000008:mdna:17]
| • | Our delivery of industry-leading products with differentiated product features that are designed to appeal to nurses, pharmacists, supply chain managers, chief information officers and hospital management. |

[0000926326-13-000008:mdna:18]
Our product backlog, consisting of orders accepted but not yet installed, increased $21 million, to $155 million at December 31, 2012 from $134 million as of December 31, 2011. This backlog is primarily attributable to our Acute Care segment. We expect to operate through 2013 with our backlog within our objective of the next six to nine months, but we believe there will be variation from time to time. We expect Non-Acute Care product backlog to be minimal.

[0000926326-13-000008:mdna:19]
Our key business strategies include:

[0000926326-13-000008:mdna:20]
| • | Further penetrating the existing market for our products through sustaining technological leadership in our products by: |

[0000926326-13-000008:mdna:21]
| • | Consistently innovating our product and service offerings; and |

[0000926326-13-000008:mdna:22]
| • | Maintaining our flexibility in customer product design and in the installation process. |

[0000926326-13-000008:mdna:23]
| • | Increasing penetration of the international market by: |

[0000926326-13-000008:mdna:24]
| • | Bringing new products and technologies to market that are specific to international markets; |

[0000926326-13-000008:mdna:25]
•Building direct sales, distribution or other capabilities when and where it is appropriate;

[0000926326-13-000008:mdna:26]
| • | Partnering with companies that have sales, distribution, or other capabilities that we do not possess in non-U.S. geographies; and |

[0000926326-13-000008:mdna:27]
| • | Increasing customer awareness of safety issues in the administration of medications. |

[0000926326-13-000008:mdna:28]
| • | Expanding our product offering through acquisitions and partnerships. |

[0000926326-13-000008:mdna:29]
Our healthcare customers expect a high degree of partnership involvement from their technology suppliers. We provide extensive installation planning and consulting as part of every product sale. Our customers' medication control systems are mission critical to their success and our customers require these systems to be functional at all times. To help assure the maximum availability of our systems, our customers typically purchase maintenance and support contracts in one, two or five year increments. Our long-term liabilities include long-term deferred service revenue of $19.9 million as of December 31, 2012, and $19.0 million as of December 31, 2011. Our deferred service revenue will be amortized to service revenue as the service contracts are executed.

[0000926326-13-000008:mdna:30]
In 2012, our overall cash flow decreased $129.4 million. This was primarily due to our acquisition of MTS for $156.3 million, and offset by a $16.2 million increase in net income, adjusted for non-cash expenses associated with depreciation and amortization of $13.3 million, and share-based compensation of $9.2 million and $8.9 million of proceeds from the issuance of common stock under our employee stock purchase and stock option plans. Other factors during the year ended December 31,

[0000926326-13-000008:mdna:31]
2012 impacting the change in cash were increases in accounts receivable of $9.3 million, deferred service revenues of $2.9 million, deferred gross profit of $6.6 million, prepaid expenses of $4.9 million and net investment in sales-type leases of $4.2 million. Additional uses of cash during the year ended December 31, 2012 included $20.6 million for the acquisition and development of productive long-lived assets and $12.4 million for stock repurchase activities.

[0000926326-13-000008:mdna:32]
In 2011, we generated positive overall cash flow of $16.1 million. This was primarily due to our $10.4 million of net income, adjusted for non-cash expenses associated with depreciation and amortization of $8.0 million, and share-based compensation of $9.5 million, and $6.8 million of proceeds from the issuance of common stock under our employee stock purchase and stock option plans. Additional factors were strong cash collections, reducing accounts receivable at year end by $5.9 million as compared to 2010 and increases of $3.6 million of deferred service revenue and $2.5 million of deferred gross profit. These increases to cash were offset by a $9.4 million increase in inventory, primarily related to the G4 launch, $13.1 million for the acquisition and development of productive long-lived assets and $12.6 million in stock repurchase activities.

[0000926326-13-000008:mdna:33]
For the year ended December 31, 2012, net cash provided by operations was $39.5 million, and our cash and cash equivalents as of December 31, 2012 was $62.3 million as compared to $199.9 million at December 31, 2011. We expect cash provided by operations to remain positive in 2013.

[0000926326-13-000008:mdna:34]
Our full-time headcount of 1,089 on December 31, 2012 increased by 316 from our full-time headcount on December 31, 2011, primarily due to the addition of 292 employees in connection with the acquisition of MTS.

[0000926326-13-000008:mdna:35]
We record compensation expense from our share-based awards, options and our employee stock purchase plan in accordance with Accounting Standards Codification, or ASC 718, Stock Compensation. Total share-based compensation expense for the year ended December 31, 2012 was $9.2 million, as compared to $9.5 million in 2011.

[0000926326-13-000008:mdna:36]
Gross profit from product revenues increased by $29.0 million and gross profit from service revenues increased by $5.8 million. Our gross profit increased 25.6% for the year ended December 31, 2012, as compared to the year ended December 31, 2011, with gross profit as a percentage of revenue decreasing by 1.0% to 54.3%. The increase in gross profits was attributable to our Non-Acute Care segment activities since the acquisition of MTS in the second quarter of 2012. The decrease in margins were primarily attributable to lower margins associated with our Non-Acute Care segment, primarily a reflection of lower margins on the MTS product lines.

[0000926326-13-000008:mdna:37]
We expect revenues to increase significantly in 2013 due to a full year of contribution from the acquired MTS entity. We do not anticipate any major fluctuations in our gross margins beyond normal fluctuations caused by changes in product mix. Revenues and gross margins may be adversely affected, however, as a result of unforeseen market price reductions and additional costs to expand our business.

[0000926326-13-000008:mdna:38]
Net income increased to $16.2 million in 2012 compared to $10.4 million in 2011 due to an increase in gross profit of $34.8 million, partially offset by a $23.9 million increase in operating expenses primarily due to an increase in selling, general and administrative expenses of $22.2 million and an increase in research and development activities of $1.7 million. These increases were primarily driven by the acquisition of MTS.

[0000926326-13-000008:mdna:39]
With the acquisition of MTS, we have organized our business into two operating business segments: Acute Care, which primarily includes products and services sold to hospital customers, and Non-Acute Care, which primarily includes products and services sold to customers outside of hospital settings.

[0000926326-13-000008:mdna:40]
The Acute Care segment is organized around the design, manufacturing, selling and servicing of medication and supply dispensing systems. The Non-Acute Care segment includes primarily the manufacturing and selling of consumable medication blister cards, packaging equipment and ancillary products and services, but also includes medication dispensing systems sold to non-acute care pharmacies and facilities. We report segment information based on the management approach. The management approach designates the internal reporting used by the Chief Operating Decision Maker (the "CODM"), for making decisions and assessing performance as the source of our operating segments. The CODM is our Chief Executive Officer. The CODM allocates resources to and assesses the performance of each operating segment, using information about its revenues, gross profit and income (loss) from operations.

[0000926326-13-000008:mdna:41]
Critical Accounting Policies and Estimates

[0000926326-13-000008:mdna:42]
Our discussion and analysis of our financial condition and results of operations are based on our consolidated financial statements, which have been prepared in accordance with United States generally accepted accounting principles, or GAAP. The preparation of these financial statements requires us to make certain estimates and assumptions that affect the reported amounts of assets and liabilities, disclosure of any contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. We regularly review our estimates and assumptions, which are based on historical experience and various other factors that are believed to be reasonable under the circumstances,

[0000926326-13-000008:mdna:43]
the results of which form the basis for making judgments about the carrying values of certain assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates and assumptions. We believe the following critical accounting policies are affected by significant judgments and estimates used in the preparation of our consolidated financial statements:

[0000926326-13-000008:mdna:44]
Revenue recognition.  We earn revenues from sales of our medication control systems, together with related consumables and services, and medical/surgical supply control systems with related services, which are sold in our principal market, which is the healthcare industry. Revenues related to consumable products are reported net of discounts provided to our customers. Our customer arrangements typically include one or more of the following deliverables:

[0000926326-13-000008:mdna:45]
| • | Products—Software-enabled equipment that manages and regulates the storage and dispensing of pharmaceuticals, consumable blister cards and packaging equipment and other medical supplies. |

[0000926326-13-000008:mdna:46]
| • | Software—Additional software applications that enable incremental functionality of our equipment. |

[0000926326-13-000008:mdna:47]
| • | Installation—Installation of equipment as integrated systems at customers' sites. |

[0000926326-13-000008:mdna:48]
| • | Post-installation technical support—Phone support, on-site service, parts and access to unspecified software upgrades and enhancements, if and when available. |

[0000926326-13-000008:mdna:49]
| • | Professional services—Other customer services, such as training and consulting. |

[0000926326-13-000008:mdna:50]
We recognize revenue when the earnings process is complete, based upon our evaluation of whether the following four criteria have been met:

[0000926326-13-000008:mdna:51]
| • | Persuasive evidence of an arrangement exists. We use signed customer contracts and signed customer purchase orders as evidence of an arrangement for leases and sales. For service engagements, we use a signed services agreement and a statement of work to evidence an arrangement. |

[0000926326-13-000008:mdna:52]
| • | Delivery has occurred. Equipment and embedded software product delivery is deemed to occur upon successful installation and receipt of a signed and dated customer confirmation of installation letter, providing evidence that we have delivered what a customer ordered. In instances of a customer self-installation, product delivery is deemed to have occurred upon receipt of a signed and dated customer confirmation letter. If a sale does not require installation, we recognize revenue on delivery of products to the customer, including transfer of title and risk of loss, assuming all other revenue criteria are met. We recognize revenue from sales of products to distributors upon delivery, assuming all other revenue criteria are met since we do not allow for rights of return or refund. For the sale of consumable blister cards, we recognize revenue when title and risk of loss of the products shipped have transferred to the customer, which usually occurs upon shipment from our facilities. Assuming all other revenue criteria are met, we recognize revenue for support services ratably over the related support services contract period. We recognize revenue on training and professional services as they are performed. |

[0000926326-13-000008:mdna:53]
| • | Fee is fixed or determinable. We assess whether a fee is fixed or determinable at the outset of the arrangement based on the payment terms associated with the transaction. We have established a history of collecting under the original contract without providing concessions on payments, products or services. |

[0000926326-13-000008:mdna:54]
| • | Collection is probable. We assess the probability of collecting from each customer at the outset of the arrangement based on a number of factors, including the customer's payment history and its current creditworthiness. If, in our judgment, collection of a fee is not probable, we defer the revenue until the uncertainty is removed, which generally means revenue is recognized upon our receipt of cash payment assuming all other revenue criteria are met. Our historical experience has been that collection from our customers is generally probable. |

[0000926326-13-000008:mdna:55]
In arrangements with multiple deliverables, assuming all other revenue criteria are met, we recognize revenue for individual delivered items if they have value to the customer on a standalone basis. Effective for new or modified arrangements entered into beginning on January 1, 2011, the date we adopted the revised revenue recognition guidance for arrangements with multiple deliverables on a prospective basis, we allocate arrangement consideration at the inception of the arrangement to all deliverables using the relative selling price method. This method requires us to determine the selling price at which each deliverable could be sold if it were sold regularly on a standalone basis. When available, we use vendor-specific objective evidence ("VSOE") of fair value as the selling price. VSOE represents the price charged for a deliverable when it is sold separately, or for a deliverable not yet being sold separately, the price established by management with the relevant authority. We consider VSOE to exist when approximately 80% or more of our standalone sales of an item are priced within a reasonably narrow pricing range (plus or minus 15% of the median rates). We have established VSOE of fair value for our post-installation technical support services and professional services. When VSOE of fair value is not available, third-party evidence ("TPE") of

[0000926326-13-000008:mdna:56]
38

[0000926326-13-000008:mdna:57]
fair value for similar products and services is acceptable; however, our offerings and market strategy differ from those of our competitors, such that we cannot obtain sufficient comparable information about third parties' prices. If neither VSOE nor TPE are available, we use our best estimates of selling prices ("BESP"). We determine BESP considering factors such as market conditions, sales channels, internal costs and product margin objectives and pricing practices. We regularly review and update our VSOE and BESP information and obtain formal approval by appropriate levels of management.

[0000926326-13-000008:mdna:58]
The relative selling price method allocates total arrangement consideration proportionally to each deliverable (an "Element") on the basis of its estimated selling price. In addition, the amount recognized for any delivered Elements cannot exceed that which is not contingent upon delivery of any remaining Elements in the arrangement.

[0000926326-13-000008:mdna:59]
We also use the residual method of allocating the arrangement consideration in certain circumstances. We use the residual method to allocate total arrangement consideration between delivered and undelivered items for any arrangements entered into prior to January 1, 2011 and not subsequently materially-modified. The use of the residual method is required by software revenue recognition rules that applied to sales of most of our products and services until the adoption of the new revenue recognition guidance. We also use the residual method to allocate revenue between the software products that enable incremental equipment functionality, and thus are not deemed to deliver its essential functionality, and the related post-installation technical support, as these products and services continue to be accounted for under software revenue recognition rules. Under the residual method, the amount allocated to the undelivered elements equals VSOE of fair value of these elements. Any remaining amounts are attributed to the delivered items and are recognized when those items are delivered.

[0000926326-13-000008:mdna:60]
A portion of our sales are made through multi-year lease agreements. Under sales-type leases, we recognize revenue for our hardware and software products net of lease execution costs such as post-installation product maintenance and technical support, at the net present value of the lease payment stream once our installation obligations have been met. We optimize cash flows by selling a majority of our non-U.S. government leases to third-party leasing finance companies on a non-recourse basis. We have no obligation to the leasing company once the lease has been sold. Some of our sales-type leases, mostly those relating to U.S. government hospitals, are retained in-house. Interest income on these leases is recognized as a component of  product revenue using the interest method.

[0000926326-13-000008:mdna:61]
Accounts receivable and notes receivable (net investment in sales type leases). We actively manage our accounts receivable to minimize credit risk. We typically sell our products to customers for which there is a history of successful collection. New customers are subject to a credit review process, which evaluates that customer's financial position and ability to pay. We continually monitor and evaluate the collectability of our trade receivables based on a combination of factors. We record specific allowances for doubtful accounts when we become aware of a specific customer's impaired ability to meet its financial obligation to us, such as in the case of bankruptcy filings or deterioration of financial position.

[0000926326-13-000008:mdna:62]
Uncollectible amounts are charged off against trade receivables and the allowance for doubtful accounts when we make a final determination that there is no reasonable expectation of recovery. Estimates are used in determining our allowances for all other customers based on factors such as current trends, the length of time the receivables are past due and historical collection experience. While we believe that our allowance for doubtful accounts receivable is adequate and that the judgment applied is appropriate, such estimated amounts could differ materially from what will actually be uncollectible in the future.

[0000926326-13-000008:mdna:63]
The retained in-house leases discussed above are considered financing receivables. Our credit policies and evaluation of credit risk and write-off policies are applied alike to trade receivables and the net-investment in sales-type leases. For both, an account is generally past due after thirty days. The financing receivables also have customer-specific reserves for accounts identified for specific impairment and a non-specific reserve applied to the remaining population, based on factors such as current trends, the length of time the receivables are past due and historical collection experience. The retained in-house leases are not stratified by portfolio or class. Financing receivables which are reserved are generally transferred to cash-basis accounting so that revenue is recognized only as cash is received. However, the cash basis accounts continue to accrue interest.

[0000926326-13-000008:mdna:64]
Valuation and impairment of goodwill, other intangible assets and other long lived assets. We account for goodwill and other intangible assets in accordance with ASC 350, Intangibles—Goodwill and Other. For the initial recognition and measurement of Goodwill and Intangibles resulting from acquisitions, we use the guidance in ASC 805, Business Combinations.

[0000926326-13-000008:mdna:65]
Under ASC 350, Intangibles - Goodwill and Other, goodwill and intangible assets with an indefinite life are not subject to amortization. Impairment is the condition that exists when the carrying amount of goodwill exceeds its implied fair value. Under the provisions of ASC 350-20, Goodwill and Other, the recorded goodwill is subject to annual impairment testing. In addition, the provisions of ASC 350-20, require that an entity assign its recorded goodwill to each of its reporting units and test each reporting unit's goodwill for impairment at least annually or earlier in circumstances whereby certain events might trigger a decrease in the carrying value of goodwill. We complete our annual goodwill impairment assessment as of the first day of our fourth quarter. In

[0000926326-13-000008:mdna:66]
39

[0000926326-13-000008:mdna:67]
accordance with ASC 350-20, we have the option to assess qualitative factors to determine whether it is more likely than not (that is, a likelihood of more than 50%) that the fair value of a reporting unit is less than its carrying amount, including goodwill, or bypass the qualitative assessment and proceed directly to performing the goodwill impairment test. We have elected to perform a qualitative assessment to determine whether it more likely than not that the fair value of each reporting unit is less than its carrying amount.

[0000926326-13-000008:mdna:68]
For both our reporting units, the Acute Care and Non-Acute Care segments, we considered the following qualitative factors when assessing if goodwill had been impaired for the year ended December 31, 2012:

[0000926326-13-000008:mdna:69]
| • | Macroeconomic conditions such as a deterioration in general economic conditions, limitations on accessing capital, fluctuations in foreign exchange rates or other developments in equity and credit markets; |

[0000926326-13-000008:mdna:70]
| • | Industry and market considerations such as a deterioration in the environment in which we operate, an increased competitive environment, a decline in market-dependent multiples or metrics (consider in both absolute terms and relative to peers), a change in the market for our products or services, or a regulatory or political development; |

[0000926326-13-000008:mdna:71]
| • | Cost factors such as increases in raw materials, labor, or other costs that have a negative effect on earnings and cash flows; |

[0000926326-13-000008:mdna:72]
| • | Overall financial performance such as negative or declining cash flows or a decline in actual or planned revenue or earnings compared with actual and projected results of relevant prior periods; |

[0000926326-13-000008:mdna:73]
| • | Other relevant entity-specific events such as changes in management, key personnel, strategy, or customers; contemplation of bankruptcy or litigation; and |

[0000926326-13-000008:mdna:74]
| • | Events affecting a reporting unit such as a change in the composition or carrying amount of its net assets, a more-likely-than-not expectation of selling or disposing all, or a portion, of a reporting unit, the testing for recoverability of a significant asset group within a reporting unit or recognition of a goodwill impairment loss in the financial statements of a subsidiary that is a component of a reporting unit. |

[0000926326-13-000008:mdna:75]
Upon completion of our qualitative assessment conducted in the fourth quarter of 2012, we concluded that it was more likely than not the fair values of both the Acute Care and Non-Acute Care segments exceeded their carrying values including the respective amounts of goodwill. In addition, we did not note any other indicators of goodwill  impairment as of December 31, 2012.

[0000926326-13-000008:mdna:76]
We continually monitor events and changes in circumstances that could indicate carrying amounts of long-lived assets may not be recoverable. We review long-lived assets and certain purchased intangibles for impairment whenever events or changes in circumstances indicate that we will not be able to recover the asset's carrying amount. Recoverability of an asset is measured by comparing its carrying amount to the expected future undiscounted cash flows expected to result from the use and eventual disposition of that asset, excluding future interest costs that would be recognized as an expense when incurred. Any impairment to be recognized is measured by the amount by which the carrying amount of the asset exceeds its fair market value. Significant management judgment is required in:

[0000926326-13-000008:mdna:77]
| • | identifying a triggering event that arises from a change in circumstances; |

[0000926326-13-000008:mdna:78]
| • | forecasting future operating results; and |

[0000926326-13-000008:mdna:79]
| • | estimating the proceeds from the disposition of long-lived or intangible assets. |

[0000926326-13-000008:mdna:80]
In future periods, material impairment charges could be necessary should different conditions prevail or different judgments be made.

[0000926326-13-000008:mdna:81]
Significant management judgment is also required for initial recognition and measurement of goodwill and other intangibles assets resulting from business combinations pursuant ASC 805, Business Combinations. Management must assess the extent to which identified other intangibles assets are properly includable (and with the appropriate fair value) or properly excludable, by applying the recognition criteria. This judgment affects not only the other intangible assets but the remainder calculation of goodwill. The assessment of useful life for each acquired intangible asset impacts future financial position and operating performance through amortization expense.

[0000926326-13-000008:mdna:82]
Inventory.    Inventories are stated at the lower of cost (utilizing standard costs), applying the first-in, first-out method, or market. We routinely assess our on-hand inventory for timely identification and measurement of obsolete, slow-moving or otherwise impaired inventory. We write down inventory for estimated obsolescence, excess or unmarketable quantities equal to the difference between the cost of the inventory and its estimated market value based on assumptions about

[0000926326-13-000008:mdna:83]
future demand and market conditions. If actual future demand or market conditions are less favorable than we projected, additional inventory write-downs may be required.

[0000926326-13-000008:mdna:84]
Valuation of share-based awards.    We account for share-based compensation in accordance with ASC 718, Stock Compensation. We estimate the fair value of our employee stock awards at the date of grant using certain subjective assumptions, such as expected volatility, which is based on a combination of historical and market-based implied volatility, and the expected term of the awards, which is based on our historical experience of employee stock option exercises, including forfeitures. The valuation assumptions we use in estimating the fair value of employee share-based awards may change in future periods. We recognize the fair value of awards over their vesting period or requisite service period. In addition, we calculate our pool of excess tax benefits available within additional paid-in capital in accordance with the provisions of ASC 718.

[0000926326-13-000008:mdna:85]
Accounting for income taxes.    We record a tax provision for the anticipated tax consequences of the reported results of operations. In accordance with GAAP, the provision for income taxes is computed using the liability method, under which deferred tax assets and liabilities are recognized for the expected future tax consequences of temporary differences between the financial reporting and tax bases of assets and liabilities, and for operating losses and tax credit carry-forwards. Deferred tax assets and liabilities are measured using the enacted tax rates expected to apply to taxable income in the periods in which those tax assets and liabilities are expected to be realized or settled. In the event that these tax rates change, we will incur a benefit or detriment with respect to our income tax expense in the period of change. If we were to determine that all or part of the net deferred tax assets are not realizable in the future, we will record a valuation allowance that would be charged to earnings in the period such determination is made.

[0000926326-13-000008:mdna:86]
In accordance with ASC 740, Income Taxes, we recognize the tax benefit from an uncertain tax position if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement. The calculation of tax liabilities involves significant judgment in estimating the impact of uncertainties in the application of GAAP and complex tax laws. Resolution of these uncertainties in a manner inconsistent with management's expectations could have a material impact on our financial condition and operating results.

[0000926326-13-000008:mdna:87]
Recently Adopted Accounting Standards

[0000926326-13-000008:mdna:88]
In May 2011, FASB issued ASU 2011-04, Fair Value Measurement, amending the fair value guidance in ASC 820, and thereby achieving substantially converged fair value measurement and disclosure requirements for GAAP and International Financial Reporting Standards ("IFRS"). The new guidance clarified some fair value measurement principles and expanded certain disclosure requirements. We adopted this guidance in the first quarter of 2012, without any impact to our financial position, operating results or cash flows.

[0000926326-13-000008:mdna:89]
In July 2012, FASB issued ASU 2012-02, Intangibles - Goodwill and Other (Topic 350): Testing Indefinite-lived Intangible Assets for Impairment, which amends the guidance in ASC 350-30 on impairment testing of intangible assets with indefinite lives other than goodwill. This guidance gives an entity the option to first assess qualitative factors to determine whether the existence of events or circumstances leads to a determination that it is more likely than not that an indefinite-lived asset is impaired. An entity has the option to bypass the qualitative assessment and proceed directly to calculating the fair value of an intangible asset with an indefinite life. We adopted this guidance in the fourth quarter of 2012, earlier than required, without any significant impact on our financial position, operating results or cash flows, as this update does not change how we calculate impairment loss.

[0000926326-13-000008:mdna:90]
Recently Issued Accounting Standards

[0000926326-13-000008:mdna:91]
In February 2013, FASB issued 2013-02, Comprehensive Income (Topic 220): Reporting of Amounts Reclassified Out of Accumulated Other Comprehensive Income ("AOCI"), which aims to improve the reporting of reclassifications out of AOCI. This update requires an entity to report the effect of significant reclassifications out of AOCI on the respective line items in net income if the amount being reclassified is required under GAAP to be reclassified in its entirety to net income. For other amounts that are not required under GAAP to be reclassified in their entirety to net income in the same reporting period, an entity is required to cross-reference other disclosures required under GAAP that provide additional detail about those amounts.  The amendments do not change the current requirements for reporting net income or other comprehensive income in financial statements. For public entities, the amendments are effective prospectively for reporting periods beginning after December 15, 2012. We intend to adopt this guidance in the first quarter of 2013. We do not anticipate this update will have any significant impact on our financial position, operating results or cash flows.

[0000926326-13-000008:mdna:92]
Results of Operations

[0000926326-13-000008:mdna:93]
|  | Years Ended December 31, |
|  | 2012 |  | % of Revenue |  | 2011 |  | % of Revenue |  | 2010 |  | % of Revenue |
|  | (in thousands, except percentages) |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |
| Product revenues | $ | 247,654 |  |  | 78.9 | % |  | $ | 185,864 |  |  | 75.7 | % |  | $ | 171,100 |  |  | 76.9 | % |
| Service and other revenues | 66,373 |  |  | 21.1 | % |  | 59,671 |  |  | 24.3 | % |  | 51,307 |  |  | 23.1 | % |
| Total revenues | 314,027 |  |  | 100.0 | % |  | 245,535 |  |  | 100.0 | % |  | 222,407 |  |  | 100.0 | % |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product revenues | 112,369 |  |  | 35.8 | % |  | 79,567 |  |  | 32.4 | % |  | 76,372 |  |  | 34.3 | % |
| Cost of service and other revenues | 31,070 |  |  | 9.9 | % |  | 30,184 |  |  | 12.3 | % |  | 28,079 |  |  | 12.6 | % |
| Restructuring charges | — |  |  | — | % |  | — |  |  | — | % |  | 39 |  |  | — | % |
| Total cost of revenues | 143,439 |  |  | 45.7 | % |  | 109,751 |  |  | 44.7 | % |  | 104,490 |  |  | 47.0 | % |
| Gross profit | 170,588 |  |  | 54.3 | % |  | 135,784 |  |  | 55.3 | % |  | 117,917 |  |  | 53.0 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 23,726 |  |  | 7.6 | % |  | 22,042 |  |  | 9.0 | % |  | 21,007 |  |  | 9.4 | % |
| Selling, general and administrative | 119,736 |  |  | 38.1 | % |  | 97,520 |  |  | 39.7 | % |  | 86,227 |  |  | 38.8 | % |
| Restructuring charges | — |  |  | — | % |  | — |  |  | — | % |  | 1,157 |  |  | 0.5 | % |
| Total operating expenses | 143,462 |  |  | 45.7 | % |  | 119,562 |  |  | 48.7 | % |  | 108,391 |  |  | 48.7 | % |
| Income from operations | 27,126 |  |  | 8.6 | % |  | 16,222 |  |  | 6.6 | % |  | 9,526 |  |  | 4.3 | % |
| Interest and other income (expense), net | (51 | ) |  | — | % |  | (133 | ) |  | (0.1 | )% |  | 431 |  |  | 0.2 | % |
| Income before provision for income taxes | 27,075 |  |  | 8.6 | % |  | 16,089 |  |  | 6.6 | % |  | 9,957 |  |  | 4.5 | % |
| Provision for income taxes | 10,897 |  |  | 3.5 | % |  | 5,700 |  |  | 2.3 | % |  | 5,065 |  |  | 2.3 | % |
| Net income | $ | 16,178 |  |  | 5.2 | % |  | $ | 10,389 |  |  | 4.2 | % |  | $ | 4,892 |  |  | 2.2 | % |

[0000926326-13-000008:mdna:94]
Product Revenues, Cost of Product Revenues and Gross Profit

[0000926326-13-000008:mdna:95]
The table below shows our product revenues, cost of product revenues and gross profit for the years ended December 31, 2012, 2011 and 2010 and the percentage change between those years:

[0000926326-13-000008:mdna:96]
|  | Years EndedDecember 31, |  | Percentage Change |
|  | 2012 |  | 2011 |  | 2010 |  | 2011 to 2012 |  | 2010 to 2011 |
|  | (in thousands) |  |  |  |  |
| Product revenues | $ | 247,654 |  |  | $ | 185,864 |  |  | $ | 171,100 |  |  | 33.2 | % |  | 8.6 | % |
| Cost of product revenues | 112,369 |  |  | 79,567 |  |  | 76,372 |  |  | 41.2 | % |  | 4.2 | % |
| Restructuring charges | — |  |  | — |  |  | — |  |  | n/a |  |  | n/a |  |
| Gross profit | $ | 135,285 |  |  | $ | 106,297 |  |  | $ | 94,728 |  |  | 27.3 | % |  | 12.2 | % |

[0000926326-13-000008:mdna:97]
2012 compared to 2011

[0000926326-13-000008:mdna:98]
Product revenues increased $61.8 million, or 33.2%, in 2012 as compared to 2011. Our ability to grow revenue is dependent on our ability to continue to obtain orders from customers, the volume of installations we are able to complete, our

[0000926326-13-000008:mdna:99]
42

[0000926326-13-000008:mdna:100]
ability to meet customer needs and provide a quality installation experience and our flexibility in manpower allocations among customers to complete installations on a timely basis. The timing of our Acute Care product revenues is primarily dependent on when our customers' schedules allow for installations. The overall increase in product revenues was driven by the increased installations of our new automation products, including customer product upgrades using our G4 platform and revenue derived from MTS subsequent to its acquisition by Omnicell during the second quarter of 2012.We anticipate that our revenues will continue to increase in 2013 as we fulfill our existing backlog of orders and as we experience higher customer product upgrades to the G4 platform in addition to having a full year of Non-Acute Care revenues from the acquisition of MTS.

[0000926326-13-000008:mdna:101]
Cost of product revenues increased by $32.8 million, or 41.2%, in 2012 as compared to 2011. This increase was primarily a result of Non-Acute Care product costs of $30.6 million, which included $1.7 million of acquisition-related charges primarily associated with the step-up to the estimated fair value of inventory acquired from MTS and consumed in the normal manufacturing cycle of our business. The increase in Acute Care product revenue and change in product mix resulted in an increase of $2.2 million in costs.

[0000926326-13-000008:mdna:102]
Gross profit on product revenue increased by $29.0 million, or 27.3%, in 2012 as compared to 2011 and gross profit as a percentage of product revenues decreased to 54.6% in 2012 as compared to 57.2% in 2011. The increase in gross profit on product revenue was primarily a result of the contribution from our Non-Acute Care segment described above, as well as increased gross profits in our Acute Care segment, which was driven primarily by product mix. The decrease in gross profit as a percentage of product revenue was due to the lower Non-Acute Care segment gross profit as a percent of revenue, which drove the overall gross profit as a percentage of revenue down. For 2013, we do not anticipate any significant fluctuations in our gross profit and gross profit as a percentage of revenue beyond normal fluctuations caused by changes in product mix and the impact of a full year of Non-Acute Care revenues from MTS.

[0000926326-13-000008:mdna:103]
2011 compared to 2010

[0000926326-13-000008:mdna:104]
Product revenues increased $14.8 million, or 8.6%, in 2011 as compared to 2010. The overall increase in product revenues was driven by a combination of increased installations of our new automation products, increases in lease renewals from existing customers and a full year of revenues derived from our acquisition of Pandora at the end of the third quarter of 2010.

[0000926326-13-000008:mdna:105]
Cost of product revenues increased by $3.2 million, or 4.2%, in 2011 as compared to 2010. The increase was primarily a function of revenue growth, partially offset by the favorable impact of overall product mix and generally lower material costs from our cost reduction efforts during the year. Additionally, during the year we incurred higher product costs related to the manufacturing cost of the new G4 cabinet console platform, released in May 2011. The early production units of the G4 cabinet console were at a higher product cost than our previous generation product. This was due to initial production line ramp up and longer production cycles to validate the manufacturability and quality of the new console. The majority of the higher production line cost was absorbed in the three month periods ended September 30, 2011 and December 31, 2011.

[0000926326-13-000008:mdna:106]
Gross profit on product revenue increased by $11.6 million, or 12.2%, in 2011 as compared to 2010 and gross profit as a percentage of product revenues increased to 57.2% in 2011 as compared to 55.4% in 2010. The increase was the result of the previously discussed increase in revenue by 8.6% over the prior year with lower than proportionate increases in related costs by 4.2% over the prior year primarily as a result of lower material costs due to product mix and from our cost reduction efforts.

[0000926326-13-000008:mdna:107]
The Non-Acute Care segment information was immaterial in the periods ended December 31, 2011 and 2010 and, accordingly, has not been discussed separately.

[0000926326-13-000008:mdna:108]
Service and Other Revenues, Cost of Service and Other Revenues and Gross Profit

[0000926326-13-000008:mdna:109]
Service and other revenues include revenues from service and maintenance contracts and rentals of automation systems. The table below shows our service and other revenues, cost of service and other revenues and gross profit for the years ended December 31, 2012, 2011 and 2010 and the percentage change between those years:

[0000926326-13-000008:mdna:110]
|  | Years EndedDecember 31, |  | Percentage Change |
|  | 2012 |  | 2011 |  | 2010 |  | 2011 to 2012 |  | 2010 to 2011 |
|  | (in thousands) |  |  |  |  |
| Service and other revenues | $ | 66,373 |  |  | $ | 59,671 |  |  | $ | 51,307 |  |  | 11.2 | % |  | 16.3 | % |
| Cost of service and other revenues | 31,070 |  |  | 30,184 |  |  | 28,079 |  |  | 2.9 | % |  | 7.5 | % |
| Restructuring charges | — |  |  | — |  |  | 39 |  |  | — |  |  | (100.0 | )% |
| Gross profit | $ | 35,303 |  |  | $ | 29,487 |  |  | $ | 23,189 |  |  | 19.7 | % |  | 27.2 | % |

[0000926326-13-000008:mdna:111]
2012 compared to 2011

[0000926326-13-000008:mdna:112]
Service and other revenues increased by $6.7 million, or 11.2%, in 2012 as compared to 2011. The increase in service and other revenues was primarily the result of an expansion in our installed base of automation systems and a resulting increase in the number of support service contracts and, in addition, a $1.9 million increase attributable to the Non-Acute segment.

[0000926326-13-000008:mdna:113]
Cost of service and other revenues increased by $0.9 million, or 2.9%, in 2012 as compared to 2011. These increases were primarily a result of the aforementioned addition of our Non-Acute Care segment of $1.2 million, offset by a $0.3 million decrease in the Acute Care segment service costs due to lower costs incurred related to advance replacement of material covered under maintenance contracts.

[0000926326-13-000008:mdna:114]
Gross profit on service and other revenues increased by $5.8 million, or 19.7%, in 2012 as compared to 2011. This increase was due to increased revenues from an expanded installed base attributable to our Acute Care segment with nominal growth in service costs as a result of service cost reduction efforts throughout 2012.

[0000926326-13-000008:mdna:115]
We expect our service and other revenues and the associated gross profit to continue to increase in 2013 with the continued expansion of our installed base of automation systems and service and maintenance contracts.

[0000926326-13-000008:mdna:116]
2011 compared to 2010

[0000926326-13-000008:mdna:117]
Service and other revenues increased by $8.4 million, or 16.3%, in 2011 as compared to 2010. The increase in service and other revenues was primarily the result of an expansion in our installed base of automation systems and a resulting increase in the number of support service contracts.

[0000926326-13-000008:mdna:118]
Cost of service and other revenues increased by $2.1 million, or 7.5%, in 2011 as compared to 2010. The increase was primarily due to an increase in spending related to salaries and benefits associated with higher headcount and spare parts expense in support of the expanded service base.

[0000926326-13-000008:mdna:119]
Gross profit on service and other revenues increased by $6.3 million, or 27.2%, in 2011 as compared to 2010. This increase was due to increased revenues from an expanded installed base without proportional growth in service cost.

[0000926326-13-000008:mdna:120]
The Non-Acute Care segment information was immaterial in the periods ended December 31, 2011 and 2010 and, accordingly, has not been discussed separately.

[0000926326-13-000008:mdna:121]
Operating Expenses

[0000926326-13-000008:mdna:122]
The table below shows our operating expenses for the years ended December 31, 2012, 2011 and 2010 and the percentage change between those years:

[0000926326-13-000008:mdna:123]
|  | Years EndedDecember 31, |  | Percentage Change |
|  | 2012 |  | 2011 |  | 2010 |  | 2012 to 2011 |  | 2010 to 2011 |
|  | (in thousands) |  |  |  |  |
| Research and development | $ | 23,726 |  |  | $ | 22,042 |  |  | $ | 21,007 |  |  | 7.6 | % |  | 4.9 | % |
| Selling, general and administrative | 119,736 |  |  | 97,520 |  |  | 86,227 |  |  | 22.8 | % |  | 13.1 | % |
| Restructuring charges | — |  |  | — |  |  | 1,157 |  |  | — | % |  | (100.0 | )% |
| Total operating expenses | $ | 143,462 |  |  | $ | 119,562 |  |  | $ | 108,391 |  |  | 20.0 | % |  | 10.3 | % |

[0000926326-13-000008:mdna:124]
2012 compared to 2011

[0000926326-13-000008:mdna:125]
Research and development.    Research and development expenses increased by $1.7 million, or 7.6%, in the years ended December 31, 2012 as compared to 2011. Research and development expenses represented 7.6% and 9.0% of total revenues in 2012 and 2011, respectively. The overall increase in research and development expenses reflects an increase of $1.8 million attributable to the Non-Acute Care segment since the acquisition of MTS in the second quarter of 2012, partially offset by an overall decrease of $0.1 million attributable to the Acute Care segment.

[0000926326-13-000008:mdna:126]
We expect research and development expenses to increase in 2013 as we continue to invest in new products and services, but stay relatively flat as a percentage of revenues. The amount of research and development expense can fluctuate based on the amount of prototype expenses for hardware and or the amount of capitalized software development costs in any given quarter.

[0000926326-13-000008:mdna:127]
Selling, general and administrative.    Selling, general and administrative expenses increased by $22.2 million, or 22.8%, in 2012 as compared to 2011. Selling, general and administrative expenses represented 38.1% and 39.7% of total revenues in 2012 and 2011, respectively.

[0000926326-13-000008:mdna:128]
This increase was primarily due to the addition of Non-Acute Care selling, general and administrative expenses of $13.2 million since the acquisition of MTS in the second quarter of 2012. Increases in Acute Care segment selling, general and administrative expenses were primarily due to a $7.5 million increase in costs associated with compensation and related benefits, $2.3 million in transaction and integration expenses related to the acquisition of MTS, $1.6 million in facility expenses due the relocation to our new buildings late in 2012 and an increase of $1.2 million in bad debt expense primarily related to a $0.6 million recovery in 2011 as compared to a $0.6 million expense in 2012, partially offset by a $1.4 million decrease in third party consulting expenses and a $1.0 million decrease in legal expenses primarily related to the settlement of litigation in 2011.

[0000926326-13-000008:mdna:129]
We anticipate selling, general and administrative expenses as a percent of revenues to stabilize and decrease throughout 2013, but this estimate could be impacted by ongoing business development activities and external, macro-economic factors.

[0000926326-13-000008:mdna:130]
2011 compared to 2010

[0000926326-13-000008:mdna:131]
Research and development.    Research and development expenses increased by $1.0 million, or 4.9%, in 2011 as compared to 2010. Research and development expenses represented 9.0% and 9.4% of total revenues in 2011 and 2010, respectively. The increase was due primarily to a $3.1 million increase in compensation costs and $1.0 million in other increases, partially offset by decreases of $0.6 million in tools and $0.4 million in outside services. Additional offset was provided by the capitalization of software development costs, increasing to $4.2 million in 2011 as compared to $2.2 million in 2010 due to the higher level of post-feasibility beta testing that preceded several new product introductions in the second quarter of 2011.

[0000926326-13-000008:mdna:132]
Selling, general and administrative.    Selling, general and administrative expenses increased by $11.3 million, or 13.1%, in 2011 as compared to 2010. Selling, general and administrative expenses represented 39.7% and 38.8% of total revenues in 2011 and 2010, respectively.

[0000926326-13-000008:mdna:133]
This increase was primarily due to a $5.0 million increase in compensation costs related to increased sales and marketing staffing, a $1.0 million increase for the settlement of litigation with Medacist Solutions Group LLC, as described in  our Annual Report on Form 10-K for the year ended December 31, 2011, and a $2.9 million increase in freight, travel, promotional expenses and other costs. Reduced outside service and other spending of $0.6 million partially offset these increases. Additionally, 2010 expenses were reduced by the $2.4 million benefit from the settlement of a litigation claim with Flo Healthcare LLC in the third quarter of 2010 for less than the amount previously accrued, as described in our Annual Report on Form 10-K for the year ended December 31, 2010, and $0.9 million resulting from the favorable timing effect on expenses due to a reduction in accrued vacation.

[0000926326-13-000008:mdna:134]
The Non-Acute Care segment information was immaterial in the periods ended December 31, 2011 and 2010 and, accordingly, has not been discussed separately.

[0000926326-13-000008:mdna:135]
Interest Income and Other Expense

[0000926326-13-000008:mdna:136]
The table below shows our interest income and other expense for the years ended December 31, 2012, 2011 and 2010 and the percentage change between those years:

[0000926326-13-000008:mdna:137]
|  | Years EndedDecember 31, |  |  |
|  | Percentage Change |
|  | 2012 |  | 2011 |  | 2010 |  | 2011 to 2012 |  | 2010 to 2011 |
|  | (in thousands) |  |  |  |  |
| Interest income | $ | 77 |  |  | $ | 266 |  |  | $ | 424 |  |  | (71.1 | )% |  | (37.3 | )% |
| Interest expense | (29 | ) |  | (62 | ) |  | (4 | ) |  | (53.2 | )% |  | n/a |  |
| Other income (expense) | (99 | ) |  | (337 | ) |  | 11 |  |  | (70.6 | )% |  | n/a |  |

[0000926326-13-000008:mdna:138]
2012 compared to 2011

[0000926326-13-000008:mdna:139]
Cash, cash equivalents and short-term investments decreased by $137.6 million during 2012, primarily due to our acquisition of MTS. This and the continued reduction in interest rates resulted in a 71.1% decline in interest income earned compared to 2011.

[0000926326-13-000008:mdna:140]
Other income (expense), decreased in 2012, primarily due to unfavorable effects of exchange rate in 2011 between Indian rupees and U.S. dollars as compared to an immaterial impact in 2012.

[0000926326-13-000008:mdna:141]
We expect interest income to remain at approximately 2012 levels during 2013.

[0000926326-13-000008:mdna:142]
2011 compared to 2010

[0000926326-13-000008:mdna:143]
Although cash, cash equivalents and short-term investments increased by $16.1 million during 2011, continued reduction in interest rates resulted in a 37.3% decline in interest income earned. The weighted average interest rate of 0.07% in the fourth quarter 2011 compares with 0.18% in the fourth quarter 2010.

[0000926326-13-000008:mdna:144]
Interest expense was greater in 2011 than 2010, primarily due to installment interest payments on a disputed county property tax issue. Other income, negligible in 2010, reversed to a $0.3 million other expense, primarily for effects of exchange rate changes between Indian rupees and U.S. dollars.

[0000926326-13-000008:mdna:145]
Income Taxes

[0000926326-13-000008:mdna:146]
|  | Years Ended December 31, |
|  | 2012 |  | 2011 |  | 2010 |
|  | (in thousands) |
| Provision for income taxes | $ | 10,897 |  |  | $ | 5,700 |  |  | $ | 5,065 |  |

[0000926326-13-000008:mdna:147]
We recorded a provision for income taxes of approximately $10.9 million and an effective tax rate of 40.25% for the year ended December 31, 2012 compared to $5.7 million and an effective tax rate of 35.4% for the year ended December 31, 2011. The 2012 annual tax rate differed from the statutory tax rate of 35%, primarily due to the unfavorable impact of state income taxes, non-deductible equity charges under ASC 740-718, and other non-deductible expenditures, including non-deductible acquisition costs, all of which were partially offset by the domestic production activities deduction. The increase in the annual effective tax rate as compared to 2011 was primarily due to the expiration of the federal research and development credit after 2011 and non-deductible acquisition costs and equity charges, partially offset by an increase in the domestic production activity deduction.

[0000926326-13-000008:mdna:148]
Our 2012 tax provision did not include the benefit of the 2012 federal R&D tax credit. The federal R&D tax credit expired as of December 31, 2011. In January 2013, it was retroactively extended through the end of 2013. The tax benefit of the 2012 federal R&D tax credit will be recognized as a discrete item in the first quarter of 2013 when the reenactment occurred. We expect this amount to be in the range of $0.6 million to $0.8 million.

[0000926326-13-000008:mdna:149]
We recorded a provision for income taxes of approximately $5.7 million and an effective tax rate of 35.4% for the year ended December 31, 2011 compared to $5.1 million and an effective tax rate of 50.8% for the year ended December 31, 2010. The decrease in the effective tax rate was primarily a result of the one-time tax adjustment in 2010 for the tax effect of undistributed earnings associated with the closure of our offices in India. The decrease is also attributable to the domestic production activities deduction, which we could not claim in 2010 due to our net operating loss utilization, and to a one-time adjustment to reserves for R&D tax credits that was recorded in 2010. Refer to Note 14, "Income Taxes" to the Notes to Consolidated Financial Statements included in the Annual Report on Form 10-K for discussion of factors affecting the ability to realize the deferred tax assets.

[0000926326-13-000008:mdna:150]
Liquidity and Capital Resources

[0000926326-13-000008:mdna:151]
Cash Flows

[0000926326-13-000008:mdna:152]
The table below shows our cash flows for the years ended December 31, 2012, 2011 and 2010:

[0000926326-13-000008:mdna:153]
|  | Years Ended December 31, |
|  | 2012 |  | 2011 |  | 2010 |
|  | (in thousands) |
| Net cash provided by operating activities | $ | 39,484 |  |  | $ | 31,243 |  |  | $ | 20,598 |  |
| Net cash used in investing activities | (168,711 | ) |  | (13,066 | ) |  | (23,057 | ) |
| Net cash (used in) provided by financing activities | (232 | ) |  | (1,840 | ) |  | 8,863 |  |
| Effect of exchange rate changes on cash and cash equivalents | 10 |  |  | (210 | ) |  | 1 |  |
| Net increase (decrease) in cash and cash equivalents | $ | (129,449 | ) |  | $ | 16,127 |  |  | $ | 6,405 |  |

[0000926326-13-000008:mdna:154]
2012 compared to 2011

[0000926326-13-000008:mdna:155]
Net cash provided by operating activities.    Net cash provided by operating activities increased by $8.2 million in 2012 to $39.5 million from $31.2 million in 2011. The major drivers increasing operating cash flow were $5.8 million higher net income and a reduction of inventory of $12.0 million, as well as increases in accrued compensation of $4.7 million, deferred gross profit of $4.1 million and accounts payable of $4.0 million, between 2012 and 2011. Partially offsetting these increases in sources of operating cash flows were a net increase of $6.4 million in prepaid expenses and the increase of $5.2 million in sales type leases.

[0000926326-13-000008:mdna:156]
Net cash used in investing activities.    Net cash used in investing activities increased by $155.6 million in 2012 to $168.7 million from $13.1 million in 2011. This increase was primarily driven by $158.3 million of cash paid to complete the 2012 acquisition of MTS in the second quarter of 2012.

[0000926326-13-000008:mdna:157]
Net cash used in financing activities.    Net cash used in financing activities decreased by $1.6 million in 2012 to $0.2 million net cash used compared to net cash used by financing activities of $1.8 million in 2011. Stock repurchases decreased by $0.2 million to $12.4 million in 2012 from $12.6 million in 2011. In 2012 cash generated from shares issued under stock option and employee stock purchase plans increased by $2.2 million to $8.9 million from $6.8 million in 2011, offset by a decrease of $0.7 million in excess tax benefits from employee stock plans to $3.2 million in 2012 from $3.9 million in 2011.

[0000926326-13-000008:mdna:158]
2011 compared to 2010

[0000926326-13-000008:mdna:159]
Net cash provided by operating activities.    Net cash provided by operating activities increased by $10.6 million in 2011 to $31.2 million from $20.6 million in 2010. The major drivers increasing operating cash flow were higher net income of $5.5 million higher net income and $7.2 million greater cash from accounts receivable. Other sources of cash were balance sheet changes in prepaid expenses recorded as current assets, deferred gross profit, accrued liabilities and deferred service revenues, increasing $4.6 million, $4.5 million, $1.8 million and $1.2 million, respectively, in operating cash flows in 2011 compared to 2010. Partially offsetting these increases in sources of operating cash flows were the $9.5 million net increase in inventory to support our G4 product launch and the net reduction of $5.1 million in accounts payable.

[0000926326-13-000008:mdna:160]
Net cash used in investing activities.    Net cash used in investing activities decreased by $10.0 million in 2011 to $13.1 million from $23.1 million in 2010. This decrease was driven by the 2010 acquisition of Pandora for $5.7 million, net of cash acquired, and by the purchases of $8.1 million of California revenue anticipation notes in both 2010 and 2011, of which the notes purchased in 2010 matured in 2011. These decreases were partially offset by the $3.8 million increase in capital expenditures for software development and property and equipment.

[0000926326-13-000008:mdna:161]
Net cash (used in) provided by financing activities.    Net cash (used in) provided by financing activities decreased by $10.0 million in 2011 to $1.8 million net cash used compared to net cash provided by financing activities of $8.9 million in 2010. This was driven by the $12.6 million use of cash for stock repurchases and $0.2 million from shares issued under stock option and employee stock purchase plans, partially offset by an increase of $2.1 million in excess tax benefits from employee stock plans.

[0000926326-13-000008:mdna:162]
Liquidity

[0000926326-13-000008:mdna:163]
Our future uses of cash are expected to be primarily for working capital, capital expenditures and other contractual obligations. We also expect a continued use of cash for potential acquisition and acquisition assessment activities. Additionally, as described in Note 15, "Stockholders' Equity" to the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K, on December 31, 2012, we had $50.0 million of remaining authorized funds to repurchase shares of our common stock under stock repurchase programs, which may, in the future, result in additional use of cash. We had cash and cash equivalents of $62.3 million at December 31, 2012 as compared to $191.8 million at December 31, 2011. As of December 31, 2012, we had no short-term investments, compared to $8.1 million in 2011. Based on our current business plan

[0000926326-13-000008:mdna:164]
and revenue backlog, we believe that our existing cash, cash equivalents and our anticipated cash flows from operations as well as cash generated from the exercise of employee stock options and purchases under our employee stock purchase plan will be sufficient to meet our cash needs for working capital, capital expenditures, acquisitions, and other contractual obligations for at least the next twelve months. For periods beyond the next twelve months, we also anticipate that our net operating cash flows plus existing balances of cash, and cash equivalents will suffice to fund the continued growth of our business.

[0000926326-13-000008:mdna:165]
Off-Balance Sheet Arrangements

[0000926326-13-000008:mdna:166]
As of December 31, 2012, we had no off-balance sheet arrangements as defined under Regulation S-K 303(a)(4) of the Securities Exchange Act of 1934, as amended, and the instructions thereto.

[0000926326-13-000008:mdna:167]
Contractual Obligations

[0000926326-13-000008:mdna:168]
As of December 31, 2012, we had $52.6 million in contractual commitments to third parties for non-cancelable operating leases, commitments to contract manufacturers and suppliers and other purchase commitments. See Note 12, "Commitments," to the Consolidated Financial Statements included in this Annual Report on Form 10-K for further information with respect to these commitments.

[0000926326-13-000008:mdna:169]
The following table summarizes our contractual obligations at December 31, 2012 (in thousands):

[0000926326-13-000008:mdna:170]
|  | Total |  | Less thanone year |  | One tothree years |  | Three tofive years |  | More thanfive years |
| Operating leases(1)(2) | $ | 45,587 |  |  | $ | 5,601 |  |  | $ | 10,555 |  |  | $ | 9,127 |  |  | $ | 20,304 |  |
| Commitments to contract manufacturers and suppliers(3) | 7,058 |  |  | 7,058 |  |  | — |  |  | — |  |  | — |  |
| Total(4) | $ | 52,645 |  |  | $ | 12,659 |  |  | $ | 10,555 |  |  | $ | 9,127 |  |  | $ | 20,304 |  |

[0000926326-13-000008:mdna:171]
_______________________________________________________________________________

[0000926326-13-000008:mdna:172]
| (1) | Commitments under operating leases relate primarily to leasehold property and office equipment. Rent expense was $5.7 million, $3.3 million and $3.6 million for the years ended December 31, 2012, 2011 and 2010, respectively. |

[0000926326-13-000008:mdna:173]
| (2) | In October 2011, we entered into a lease agreement for approximately 100,000 square feet of office space. Pursuant to the lease agreement, the landlord has constructed a single, three-story building of rentable space in Mountain View, California which we now lease and which serves as our headquarters. The term of the lease agreement, which commenced in November 2012, is for a period of 10 years, with a base lease commitment of approximately $40.0 million. We have two options to extend the term of the lease agreement at market rates. Each extension is for an additional 60 month term. |

[0000926326-13-000008:mdna:174]
| (3) | We purchase components from a variety of suppliers and use contract manufacturers to provide manufacturing services for our products. During the normal course of business, we issue purchase orders with estimates of our requirements several months ahead of the delivery dates. |

[0000926326-13-000008:mdna:175]
| (4) | At December 31, 2012, we have recorded $3.3 million for uncertain tax positions under long term liabilities, in accordance with U.S. GAAP, summarized under the section entitled "Critical Accounting Policies and Estimates" of this Annual Report on Form 10-K. As these liabilities do not reflect actual tax assessments, the timing and amount of payments we might be required to make will depend upon a number of factors. Accordingly, as the timing and amount of payment cannot be estimated, the $3.3 million of uncertain tax position liabilities has not been included in the contractual obligations table above. |
