# OMCL 8-K — 0001104659-13-006446 filed 2013-01-31

## item codes, every 8-K on or before 2013-03-11

- 2013-03-11 0001104659-13-019143 — 8.01
- 2013-02-07 0001104659-13-008477 — 5.02, 9.01
- 2013-01-31 0001104659-13-006446 — 2.02, 9.01
- 2012-11-02 0001104659-12-073697 — 5.02
- 2012-10-25 0001104659-12-071211 — 2.02, 9.01
- 2012-08-06 0001104659-12-054635 — 8.01
- 2012-08-03 0001104659-12-054214 — 2.01, 9.01 — amendment of 0001104659-12-038888
- 2012-08-01 0001104659-12-053005 — 2.02, 9.01
- 2012-06-12 0001104659-12-042936 — 8.01, 9.01
- 2012-05-23 0001104659-12-039459 — 5.07
- 2012-05-22 0001104659-12-038888 — 2.01, 9.01
- 2012-05-02 0001104659-12-032048 — 2.02, 9.01
- 2012-05-02 0001104659-12-032036 — 1.01, 9.01
- 2012-04-04 0001104659-12-023883 — 5.02, 8.01
- 2012-03-20 0001104659-12-019462 — 1.01, 9.01
- 2012-02-13 0001104659-12-009353 — 5.02, 9.01
- 2012-01-26 0001104659-12-004244 — 2.02, 9.01
- 2011-10-27 0001104659-11-058464 — 2.02, 9.01
- 2011-10-25 0001104659-11-057721 — 1.01
- 2011-07-28 0001104659-11-041505 — 2.02, 9.01
- 2011-05-27 0001104659-11-032006 — 5.07
- 2011-05-02 0001104659-11-024908 — 2.02, 9.01
- 2011-04-15 0001104659-11-020407 — 5.02, 9.01 — amendment of 0001104659-11-005638
- 2011-02-08 0001104659-11-005638 — 5.02, 9.01
- 2011-01-27 0001104659-11-003419 — 2.02, 9.01
- 2010-12-22 0001104659-10-064003 — 5.02, 5.07, 9.01
- 2010-10-27 0001104659-10-054036 — 2.02, 9.01
- 2010-10-05 0001104659-10-051173 — 8.01
- 2010-07-22 0001104659-10-039126 — 2.02, 9.01
- 2010-07-09 0001104659-10-037594 — 2.05
- 2010-05-28 0001104659-10-031607 — 5.07
- 2010-04-26 0001104659-10-021797 — 2.02, 9.01
- 2010-03-17 0001104659-10-014849 — 5.02, 9.01
- 2010-02-08 0001104659-10-005457 — 5.02, 9.01
- 2010-01-28 0001104659-10-003627 — 2.02, 9.01
- 2009-10-22 0001104659-09-059972 — 2.02, 9.01
- 2009-07-23 0001104659-09-044508 — 2.02, 9.01
- 2009-05-20 0001104659-09-033938 — 5.02, 9.01
- 2009-04-30 0001104659-09-027707 — 2.02, 9.01
- 2009-03-10 0001104659-09-016178 — 5.02, 9.01
- 2009-02-09 0001104659-09-007692 — 5.02, 9.01
- 2009-01-29 0001104659-09-005022 — 2.02, 2.05, 9.01
- 2009-01-21 0001104659-09-003180 — 2.02, 8.01, 9.01
- 2009-01-06 0001104659-09-000625 — 5.02
- 2008-10-23 0001104659-08-065475 — 2.02, 9.01
- 2008-07-21 0001104659-08-046690 — 2.02, 9.01
- 2008-05-16 0001104659-08-034035 — 8.01, 9.01
- 2008-04-28 0001104659-08-027379 — 7.01, 9.01
- 2008-04-21 0001104659-08-025616 — 2.02, 9.01
- 2008-03-12 0001104659-08-016939 — 7.01, 9.01
- 2008-02-26 0001104659-08-012840 — 7.01, 9.01
- 2008-02-12 0001104659-08-009382 — 5.02, 9.01
- 2008-01-31 0001104659-08-006199 — 2.02, 9.01
- 2007-12-05 0001104659-07-087191 — 1.01, 9.01
- 2007-10-18 0001104659-07-075654 — 2.02, 9.01
- 2007-07-27 0001104659-07-056886 — 5.03, 9.01
- 2007-07-19 0001104659-07-054924 — 2.02, 9.01
- 2007-05-23 0001104659-07-042287 — 8.01, 9.01
- 2007-05-07 0001104659-07-036172 — 1.01, 5.02, 9.01
- 2007-04-24 0001104659-07-030578 — 2.02, 9.01 — amendment, the index does not say of what
- 2007-04-24 0001104659-07-030547 — 2.02, 9.01
- 2007-04-10 0001104659-07-027465 — 5.02, 9.01
- 2007-03-23 0001104659-07-021969 — 2.02, 4.02, 9.01
- 2007-01-30 0001104659-07-005772 — 2.02, 9.01
- 2007-01-09 0001104659-07-001600 — 5.02, 9.01
- 2006-10-30 0001104659-06-069612 — 1.01
- 2006-10-19 0001104659-06-067549 — 2.02, 9.01
- 2006-07-20 0001104659-06-048020 — 2.02, 4.02, 9.01
- 2006-05-17 0001104659-06-035522 — 1.01, 9.01 — amendment of 0001104659-05-011155
- 2006-05-09 0001104659-06-032706 — 1.01, 9.01
- 2006-04-25 0001104659-06-027438 — 2.02, 9.01
- 2006-04-04 0001104659-06-022204 — 1.01, 9.01
- 2006-03-15 0001104659-06-016861 — 1.01, 9.01
- 2006-01-30 0001104659-06-004749 — 2.02, 9.01
- 2006-01-24 0001104659-06-003504 — 1.01, 5.02, 9.01
- 2005-12-13 0001104659-05-060532 — 1.01, 9.01
- 2005-11-10 0001104659-05-054663 — 2.02, 9.01
- 2005-07-21 0001104659-05-033464 — 2.02, 9.01
- 2005-06-22 0001104659-05-029255 — 1.01
- 2005-05-16 0001104659-05-023473 — 2.02, 9.01 — amendment of 0001104659-05-018173
- 2005-05-16 0001104659-05-023471 — 2.02, 9.01 — amendment of 0001104659-05-017382
- 2005-05-10 0001104659-05-022127 — 1.01
- 2005-04-26 0001104659-05-018173 — 2.02, 9.01
- 2005-04-21 0001104659-05-017382 — 2.02, 9.01
- 2005-04-06 0001104659-05-015401 — 5.02
- 2005-03-15 0001104659-05-011155 — 1.01, 9.01
- 2005-03-08 0001104659-05-009975 — 1.01, 9.01
- 2005-02-03 0001104659-05-003943 — 2.02, 9.01
- 2005-01-13 0001104659-05-001314 — 5.02, 9.01
- 2004-10-21 0001104659-04-031413 — 2.02, 9.01
- 2004-07-22 0001104659-04-020572 — 12, 7
- 2004-04-14 0001104659-04-010039 — 12, 7
- 2004-04-05 0001104659-04-009437 — 12, 7
- 2004-01-26 0001104659-04-001655 — 12, 7
- 2003-10-16 0001104659-03-022990 — 12, 7
- 2003-07-17 0001104659-03-015053 — 9
- 2003-04-18 0001104659-03-006823 — 7, 9
- 2003-02-14 0001104659-03-002607 — 5, 7

## late-filing notifications on or before 2013-03-11

- 2007-03-16 0001104659-07-020094 — NT 10-K, for the period ended 2006-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001104659-13-006446:8k_2_02:1]
EX-99.1
2
a13-3972_1ex99d1.htm
EX-99.1

[0001104659-13-006446:8k_2_02:2]
Exhibit 99.1

[0001104659-13-006446:8k_2_02:3]
| Contact: |  |
| Rob Seim | Omnicell, Inc. |
| Chief Financial Officer | 590 East Middlefield Road |
| 800-850-6664, ext. 6478 | Mountain View, CA 94043 |
| rob.seim@omnicell.com |  |

[0001104659-13-006446:8k_2_02:4]
Omnicell Announces Record Setting Fourth Quarter 2012 and Full Year 2012 Results

[0001104659-13-006446:8k_2_02:5]
MOUNTAIN VIEW, Calif. — January 31, 2013 — Omnicell, Inc. (NASDAQ: OMCL), a leading provider of medication and supply management solutions to healthcare systems, today announced results for its fourth quarter and year ended December 31, 2012, which includes results of MTS Medication Technologies, Inc. (“MTS”), acquired by Omnicell in May 2012.

[0001104659-13-006446:8k_2_02:6]
GAAP results: Revenue for the fourth quarter of 2012 was $90.2 million, up $27.2 million or 43.3% from the fourth quarter of 2011 and up $5.8 million or 6.9% from the third quarter of 2012. Revenue for the year ended December 31, 2012 was $314.0 million, up $68.5 million or 27.9% from the year ended December 31, 2011.

[0001104659-13-006446:8k_2_02:7]
Fourth quarter 2012 net income as reported in accordance with U.S. generally accepted accounting principles (GAAP) was $5.5 million, or $0.16 per diluted share. This compares to net income of $4.1 million, or $0.12 per diluted share in the fourth quarter of 2011 and net income of $6.9 million, or $0.20 per diluted share  in the third quarter of 2012. For the year ended December 31, 2012, net income was $16.2 million, or $0.47 per diluted share. This compares to net income of $10.4 million, or $0.30 per diluted share for the year ended December 31, 2011.

[0001104659-13-006446:8k_2_02:8]
Non-GAAP results: Non-GAAP net income was $8.6 million for the fourth quarter of 2012, or $0.25 per diluted share. Non-GAAP net income for the fourth quarter excludes $2.4 million of stock-based compensation expense and the $0.6 million after-tax effect of amortization expense for all intangible assets acquired in connection with the acquisition of MTS in May 2012, and earlier Omnicell acquisitions. This compares to non-GAAP net income of $6.4 million, or $0.19 per diluted share for the fourth quarter of 2011, excluding $2.2 million of stock-based compensation expense. Fourth quarter 2012 results compare to non-GAAP net income of $9.9 million, or $0.29 per diluted share for the third quarter of 2011. Non-GAAP net income for the third quarter excludes $2.4 million of stock-based compensation expense and the $0.7 million after-tax effect of amortization expense for all intangible assets acquired in connection with the acquisition of MTS and earlier Omnicell acquisitions. Non-GAAP net income was $29.8 million for the year ended December 31, 2012, or $0.87 per diluted share, which excluded $9.2 million of stock-based compensation expense and the $4.4 million after-tax effect of acquisition costs and amortization expense. Non-GAAP net income was $20.5 million for the year ended December 31, 2011, or $0.60 per diluted share, excluding $9.5 million of stock-based compensation expense and $1.0 million of pre-tax litigation claims settlement expense, net of a $0.4 million tax effect.

[0001104659-13-006446:8k_2_02:9]
Product backlog as of December 31, 2012 totaled $155 million, up $21 million or 16% from December 31, 2011.

[0001104659-13-006446:8k_2_02:10]
“We are very pleased with the company’s performance in the fourth quarter and fiscal 2012. For a year in which we celebrated Omnicell’s twentieth anniversary as a company, it is extremely rewarding to report record bookings and revenue for our Acute Care segment,” said Randall Lipps, Omnicell president, chairman and CEO.

[0001104659-13-006446:8k_2_02:11]
“We close 2012 having achieved annual revenue exceeding $300 million, a major milestone in the progress of Omnicell. One of the highlights of the year was the acquisition of MTS Medication Technologies,” added Mr. Lipps, “which significantly broadens our automated medication management offerings across the patient care delivery continuum to include both Acute and Non-Acute Care settings.”

[0001104659-13-006446:8k_2_02:12]
“These record-setting results, combined with our inspired people and customer-centric innovation strategy, provide us great momentum to carry into 2013,” he said.

[0001104659-13-006446:8k_2_02:13]
Omnicell Conference Call Information

[0001104659-13-006446:8k_2_02:14]
Omnicell will hold a conference call today at 1:15 p.m. PT to discuss fourth quarter and year-end financial results. The conference call can be monitored by dialing 1-800-696-5518 within the U.S. or 1-706-758-4883 for all other locations. The Conference ID # is 91533597. Internet users can access the conference call at http://ir.omnicell.com/events.cfm. A replay of the call will be available today at approximately 3:30 p.m. PT and will be available until 8:59 p.m. PT on February 8, 2013. The replay access numbers are 1-855-859-2056 within the U.S. and 1-404-537-3406 for all other locations, conference code # 91533597.

[0001104659-13-006446:8k_2_02:15]
About Omnicell

[0001104659-13-006446:8k_2_02:16]
Omnicell, Inc. (NASDAQ: OMCL) is a leading provider of automation and business information solutions enabling hospitals and other healthcare organizations to streamline the medication administration process and manage costly medical supplies for increased operational efficiency and enhanced patient safety. Through seamless integration with a customer’s existing IT infrastructure, Omnicell solutions empower healthcare facilities to achieve comprehensive automation of medication and supply management from the arrival at the loading dock to the patient’s bedside. Omnicell also provides healthcare facilities with business analytics software designed to improve medication diversion detection and regulatory compliance.

[0001104659-13-006446:8k_2_02:17]
Since 1992, more than 2,700 hospital customers worldwide have utilized Omnicell’s medication automation, supply chain and analytics solutions to enable them to increase patient safety, improve efficiency and address changing healthcare regulations while providing effective control of costs, charge capture for payer reimbursement and inventory management of medications and supplies.

[0001104659-13-006446:8k_2_02:18]
MTS Medication Technologies, Inc., a wholly-owned Omnicell subsidiary, is a leader in medication adherence packaging systems designed to improve medication dispensing and administration. MTS enables approximately 6,000 institutional and retail pharmacies worldwide to maintain high accuracy and quality standards while optimizing productivity and controlling costs. The MTS product line includes more than 20 packaging machines and 50 types of consumable products.

[0001104659-13-006446:8k_2_02:19]
For more information about Omnicell, please visit www.omnicell.com. Visit www.mts-mt.com for more information about MTS.

[0001104659-13-006446:8k_2_02:20]
Forward-Looking Statements

[0001104659-13-006446:8k_2_02:21]
To the extent any statements contained in this release deal with information that is not historical, these statements are necessarily forward-looking. As such, they are subject to the occurrence of many events outside Omnicell’s control and are subject to various risk factors that could cause actual results to differ materially from those expressed or implied in any forward-looking statement. The risk factors are described in the Company’s Securities and Exchange Commission (SEC) filings and include, the potential failure to realize the anticipated benefits of the MTS acquisition, unfavorable general economic and market conditions, risks to growth and acceptance of our products and services and to growth of the clinical automation and workflow automation market generally, the potential of increasing competition, potential regulatory changes, and the ability of the company to improve sales productivity to grow product backlog, retain key personnel, to cut expenses, to manage future changes in revenue levels, to develop new products and integrate acquired companies, products or intellectual property in a timely and cost-effective manner. Prospective investors are cautioned not to place undue reliance on forward-looking statements.

[0001104659-13-006446:8k_2_02:22]
Use of Non-GAAP Financial Information

[0001104659-13-006446:8k_2_02:23]
This press release contains financial measures that are not calculated in accordance with U.S. generally accepted accounting principles (GAAP). Our management evaluates and makes operating decisions using various performance measures. In addition to Omnicell’s GAAP results, we also consider non-GAAP gross profit, non-GAAP operating expenses, non-GAAP net income, and non-GAAP net income per diluted share. Additionally, we calculate Adjusted EBITDA (another non-GAAP measure) by means of adjustments to GAAP Net Income. These non-GAAP results should not be considered as an alternative to gross profit, operating expenses, net income, net income per diluted share, or any other performance measure derived in accordance with GAAP. We present these non-GAAP results because we consider them to be important supplemental measures of Omnicell’s performance.

[0001104659-13-006446:8k_2_02:24]
Our non-GAAP gross profit, non-GAAP operating expenses, non-GAAP net income and non-GAAP net income per diluted share are exclusive of certain items to facilitate management’s review of the comparability of Omnicell’s core operating results on a period to period basis because such items are not related to Omnicell’s ongoing core operating results as viewed by management. We define our “core operating results” as those revenues recorded in a particular period and the expenses incurred within that period that directly drive operating income in that period. Management uses these non-GAAP financial measures in making operating decisions because, in addition to meaningful supplemental information regarding operating performance, the measures give us a better understanding of how we should invest in research and development, fund infrastructure growth and evaluate the effectiveness of marketing strategies. In calculating the above non-GAAP results, management specifically adjusted for the following excluded items:

[0001104659-13-006446:8k_2_02:25]
a) Stock-based compensation expense impact of Accounting Standards Codification (ASC) 718 . We recognize equity plan-related compensation expenses, which represent the fair value of all share-based payments to employees, including grants of employee stock options, as required under ASC 718, “Stock Compensation” as non-GAAP adjustments in each period.

[0001104659-13-006446:8k_2_02:26]
b) Litigation settlement (net of tax).  We recorded an accrual in the first quarter of 2011 for settlement of litigation claims for $1.0 million ($0.6 million net of the $0.4 million income tax effect). This charge is not expected to be recurring and, as such, the financial impact is excluded from our non-GAAP results.

[0001104659-13-006446:8k_2_02:27]
c) Acquisition-related transaction and integration expenses. In connection with our acquisition of MTS, we recorded $4.9 million of acquisition transaction and integration costs ($2.9 million net of the $2.0 million tax effect) in the second quarter of 2012. This charge is not expected to be recurring and, as such, the financial impact is excluded from our non-GAAP results.

[0001104659-13-006446:8k_2_02:28]
d) Intangible assets amortization from business acquisitions. Beginning in the second quarter of 2012 (without revising prior periods), we are also excluding from our non-GAAP results the amortization expense resulting from the MTS acquisition as well as earlier Omnicell acquisitions. This impacts the fourth quarter non-GAAP results by $1.1 million ($0.6 million net of the $0.5 million tax effect). This also impacts the second quarter and third quarter non-GAAP results by $0.5 million ($0.3 million net of the $0.2 million tax effect) and $1.1 million ($0.7 million net of the $0.4 million tax effect), respectively. The year-ended December 31, 2012 non-GAAP results are affected by $2.7 million ($1.6 million net of $1.1 million tax effect). These non-cash charges are not, considered by management, to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results.

[0001104659-13-006446:8k_2_02:29]
Management adjusts for the above items because management believes that, in general, these items possess one or more of the following characteristics: their magnitude and timing is largely outside of Omnicell’s control; they are unrelated to the ongoing operation of the business in the ordinary course; they are unusual and we do not expect them to occur in the ordinary course of business; or they are non-operational, or non-cash expenses involving stock option grants.

[0001104659-13-006446:8k_2_02:30]
We believe that the presentation of these non-GAAP financial measures is warranted for several reasons:

[0001104659-13-006446:8k_2_02:31]
1) Such non-GAAP financial measures provide an additional analytical tool for understanding Omnicell’s financial performance by excluding the impact of items which may obscure trends in the core operating results of the business;

[0001104659-13-006446:8k_2_02:32]
2) Since we have historically reported non-GAAP results to the investment community, we believe the inclusion of non-GAAP numbers provides consistency and enhances investors’ ability to compare our performance across financial reporting periods;

[0001104659-13-006446:8k_2_02:33]
3) These non-GAAP financial measures are employed by Omnicell’s management in its own evaluation of performance and are utilized in financial and operational decision making processes, such as budget planning and forecasting; and

[0001104659-13-006446:8k_2_02:34]
4) These non-GAAP financial measures facilitate comparisons to the operating results of other companies in our industry, which use similar financial measures to supplement their GAAP results, thus enhancing the perspective of investors who wish to utilize such comparisons in their analysis of our performance.

[0001104659-13-006446:8k_2_02:35]
Set forth below are additional reasons why share-based compensation expense related to ASC 718 is excluded from our non-GAAP financial measures:

[0001104659-13-006446:8k_2_02:36]
i) While share-based compensation calculated in accordance with ASC 718 constitutes an ongoing and recurring expense of Omnicell, it is not an expense that requires cash settlement by Omnicell. We therefore exclude these charges for purposes of evaluating core operating results. Thus, our non-GAAP measurements are presented exclusive of stock-based compensation expense to assist management and investors in evaluating our core operating results.

[0001104659-13-006446:8k_2_02:37]
ii) We present ASC 718 share-based payment compensation expense in our reconciliation of non-GAAP financial measures on a pre-tax basis because the exact tax differences related to the timing and deductibility of share-based compensation, under ASC 718 are dependent upon the trading price of Omnicell’s common stock and the timing and exercise by employees of their stock options.  As a result of these timing and market uncertainties the tax effect related to share-based compensation expense would be inconsistent in amount and frequency and is therefore excluded from our non-GAAP results.

[0001104659-13-006446:8k_2_02:38]
Our Adjusted EBITDA calculation is defined as earnings before interest income and expense, taxes, depreciation and amortization, and non-cash expenses, including ASC 718 stock compensation expense. In addition, we are excluding the transaction and integration costs from the May 2012 MTS acquisition from the results for the year ending December 31, 2012.

[0001104659-13-006446:8k_2_02:39]
As stated above, we present non-GAAP financial measures because we consider them to be important supplemental measures of performance. However, non-GAAP financial measures have limitations as an analytical tool and should not be considered in isolation or as a substitute for Omnicell’s GAAP results. In the future, we expect to incur expenses similar to certain of the non-GAAP adjustments described above and expect to continue reporting non-GAAP financial measures excluding such items. Some of the limitations in relying on non-GAAP financial measures are:

[0001104659-13-006446:8k_2_02:40]
· Omnicell’s stock option and stock purchase plans are important components of incentive compensation arrangements and will be reflected as expenses in Omnicell’s GAAP results for the foreseeable future under ASC 718.

[0001104659-13-006446:8k_2_02:41]
· Other companies, including companies in Omnicell’s industry, may calculate non-GAAP financial measures differently than Omnicell, limiting their usefulness as a comparative measure.

[0001104659-13-006446:8k_2_02:42]
Pursuant to the requirements of SEC Regulation G, a detailed reconciliation between Omnicell’s non-GAAP and GAAP financial results is set forth in the financial tables at the end of this press release. Investors are advised to carefully review and consider this information strictly as a supplement to the GAAP results that are contained in this press release and in Omnicell’s SEC filings.

[0001104659-13-006446:8k_2_02:43]
Omnicell, Inc.

[0001104659-13-006446:8k_2_02:44]
Condensed Consolidated Statements of Operations

[0001104659-13-006446:8k_2_02:45]
(in thousands, except per share data)

[0001104659-13-006446:8k_2_02:46]
|  |  | Three Months Ended |  | Year Ended |  |
|  |  | December 31, 2012 |  | September 30, 2012 |  | December 31, 2011 |  | December 31, 2012 |  | December 31, 2011 (1) |  |
|  |  | (unaudited) |  | (unaudited) |  | (unaudited) |  | (unaudited) |  |  |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 72,415 |  | $ | 67,446 |  | $ | 47,281 |  | $ | 247,654 |  | $ | 185,864 |  |
| Services and other revenues |  | 17,754 |  | 16,885 |  | 15,650 |  | 66,373 |  | 59,671 |  |
| Total revenue |  | 90,169 |  | 84,331 |  | 62,931 |  | 314,027 |  | 245,535 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product revenues |  | 32,871 |  | 30,636 |  | 19,572 |  | 112,403 |  | 79,567 |  |
| Cost of services and other revenues |  | 7,956 |  | 7,608 |  | 7,480 |  | 31,070 |  | 30,184 |  |
| Total cost of revenues |  | 40,827 |  | 38,244 |  | 27,052 |  | 143,473 |  | 109,751 |  |
| Gross profit |  | 49,342 |  | 46,087 |  | 35,879 |  | 170,554 |  | 135,784 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  | 6,188 |  | 5,545 |  | 5,903 |  | 23,726 |  | 22,042 |  |
| Selling, general, and administrative |  | 33,363 |  | 29,316 |  | 23,807 |  | 119,745 |  | 97,520 |  |
| Total operating expenses |  | 39,551 |  | 34,861 |  | 29,710 |  | 143,471 |  | 119,562 |  |
| Income from operations |  | 9,791 |  | 11,226 |  | 6,169 |  | 27,083 |  | 16,222 |  |
| Other income and (expense), net |  | (108 | ) | 34 |  | (67 | ) | (51 | ) | (133 | ) |
| Income before provision for income taxes |  | 9,683 |  | 11,260 |  | 6,102 |  | 27,032 |  | 16,089 |  |
| Provision for income taxes |  | 4,168 |  | 4,340 |  | 1,964 |  | 10,871 |  | 5,700 |  |
| Net income |  | $ | 5,515 |  | $ | 6,920 |  | $ | 4,138 |  | $ | 16,161 |  | $ | 10,389 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.17 |  | $ | 0.21 |  | $ | 0.13 |  | $ | 0.49 |  | $ | 0.31 |  |
| Diluted |  | $ | 0.16 |  | $ | 0.20 |  | $ | 0.12 |  | $ | 0.47 |  | $ | 0.30 |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | 33,282 |  | 33,193 |  | 33,097 |  | 33,307 |  | 33,123 |  |
| Diluted |  | 34,128 |  | 34,068 |  | 34,114 |  | 34,213 |  | 34,103 |  |

[0001104659-13-006446:8k_2_02:47]
(1)  Information derived from our December 31, 2011 audited Consolidated Financial Statements.

[0001104659-13-006446:8k_2_02:48]
Omnicell, Inc.

[0001104659-13-006446:8k_2_02:49]
Condensed Consolidated Balance Sheets

[0001104659-13-006446:8k_2_02:50]
(In thousands)

[0001104659-13-006446:8k_2_02:51]
|  |  | December 31, |  | December 31, |  |
|  |  | 2012 |  | 2011 |  |
|  |  | (unaudited) |  | (1) |  |
| ASSETS |  |  |  |  |  |
| Current assets: |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 62,313 |  | $ | 191,762 |  |
| Short-term investments |  | — |  | 8,107 |  |
| Accounts receivable, net |  | 55,116 |  | 38,661 |  |
| Inventories |  | 26,903 |  | 18,107 |  |
| Prepaid expenses |  | 15,392 |  | 10,495 |  |
| Deferred tax assets |  | 12,108 |  | 10,352 |  |
| Other current assets |  | 9,052 |  | 6,107 |  |
| Total current assets |  | 180,884 |  | 283,591 |  |
| Property and equipment, net |  | 34,260 |  | 17,306 |  |
| Non-current net investment in sales-type leases |  | 13,229 |  | 8,785 |  |
| Goodwill |  | 113,404 |  | 28,543 |  |
| Other intangible assets |  | 85,158 |  | 4,231 |  |
| Non-current deferred tax assets |  | 1,018 |  | 11,677 |  |
| Other assets |  | 15,778 |  | 9,716 |  |
| Total assets |  | $ | 443,731 |  | $ | 363,849 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |
| Accounts payable |  | $ | 18,256 |  | $ | 11,000 |  |
| Accrued compensation |  | 11,613 |  | 7,328 |  |
| Accrued liabilities |  | 13,895 |  | 8,901 |  |
| Deferred service revenue |  | 20,449 |  | 19,191 |  |
| Deferred gross profit |  | 20,772 |  | 14,210 |  |
| Total current liabilities |  | 84,985 |  | 60,630 |  |
| Non-current deferred service revenue |  | 19,892 |  | 18,966 |  |
| Non-current deferred tax liabilities |  | 26,404 |  | — |  |
| Other long-term liabilities |  | 4,866 |  | 1,339 |  |
| Total liabilities |  | 136,147 |  | 80,935 |  |
| Stockholders’ equity: |  |  |  |  |  |
| Total stockholders’ equity |  | 307,584 |  | 282,914 |  |
| Total liabilities and stockholders’ equity |  | $ | 443,731 |  | $ | 363,849 |  |

[0001104659-13-006446:8k_2_02:52]
(1)  Information derived from our December 31, 2011 audited Consolidated Financial Statements.

[0001104659-13-006446:8k_2_02:53]
Omnicell, Inc.

[0001104659-13-006446:8k_2_02:54]
Reconciliation of GAAP to Non-GAAP

[0001104659-13-006446:8k_2_02:55]
(In thousands, except per share data, unaudited)

[0001104659-13-006446:8k_2_02:56]
|  |  | Three Months Ended |  |
|  |  | December 31, 2012 |  | September 30, 2012 |  | December 31, 2011 |  |
|  |  | Net income |  | Net income per share- diluted |  | Net income |  | Net income per share- diluted |  | Net income |  | Net income per share- diluted |  |
| GAAP |  | $ | 5,515 |  | $ | 0.16 |  | $ | 6,920 |  | $ | 0.20 |  | $ | 4,138 |  | $ | 0.12 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Business acquisition costs |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets acquired by acquisition (a) |  | 1,057 |  |  |  | 1,057 |  |  |  | — |  |  |  |
| Subtotal pretax adjustments |  | 1,057 |  |  |  | 1,057 |  |  |  | — |  |  |  |
| Income tax effect of non-GAAP adjustments (b) |  | (423 | ) |  |  | (407 | ) |  |  | — |  |  |  |
| Subtotal after-tax adjustments |  | 634 |  |  |  | 650 |  |  |  | — |  |  |  |
| ASC 718 share-based compensation adjustment (c) |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gross profit |  | 236 |  |  |  | 275 |  |  |  | 290 |  |  |  |
| Operating expenses |  | 2,197 |  |  |  | 2,086 |  |  |  | 1,955 |  |  |  |
| Total after-tax adjustments |  | 3,067 |  | 0.09 |  | 3,011 |  | 0.09 |  | 2,245 |  | 0.07 |  |
| Non-GAAP |  | $ | 8,582 |  | $ | 0.25 |  | $ | 9,931 |  | $ | 0.29 |  | $ | 6,383 |  | $ | 0.19 |  |

[0001104659-13-006446:8k_2_02:57]
(a)  Beginning with the second quarter of 2012, we are recognizing the amortization expense resulting from all intangible assets recorded from business acquisitions as a non-GAAP adjustment, including MTS and prior acquisitions.

[0001104659-13-006446:8k_2_02:58]
(b)  Tax effects are calculated using the effective tax rates for the respective periods presented.

[0001104659-13-006446:8k_2_02:59]
(c)  This adjustment reflects the accounting impact of non-cash stock-based compensation expense related to the impact of ASC 718 for the periods shown.

[0001104659-13-006446:8k_2_02:60]
Omnicell, Inc.

[0001104659-13-006446:8k_2_02:61]
Reconciliation of GAAP to Non-GAAP

[0001104659-13-006446:8k_2_02:62]
(In thousands, except per share data, unaudited)

[0001104659-13-006446:8k_2_02:63]
|  |  | Year Ended |  |
|  |  | December 31, 2012 |  | December 31, 2011 |  |
|  |  | Net income |  | Net income per share- diluted |  | Net income |  | Net income per share- diluted |  |
| GAAP |  | $ | 16,161 |  | $ | 0.47 |  | $ | 10,389 |  | $ | 0.30 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |
| Business acquisition costs |  |  |  |  |  |  |  |  |  |
| Transaction and integration costs for acquisitions (a) |  | 4,855 |  |  |  |  |  |  |  |
| Amortization of intangible assets acquired by acquisition (b) |  | 2,672 |  |  |  |  |  |  |  |
| Litigation settlement (c) |  | — |  |  |  | 1,000 |  |  |  |
| Subtotal pretax adjustments |  | 7,527 |  |  |  | 1,000 |  |  |  |
| Income tax effect of non-GAAP adjustments (d) |  | (3,086 | ) |  |  | (380 | ) |  |  |
| Subtotal after-tax adjustments |  | 4,441 |  |  |  | 620 |  |  |  |
| ASC 718 share-based compensation adjustment (e) |  |  |  |  |  |  |  |  |  |
| Gross profit |  | 1,012 |  |  |  | 1,398 |  |  |  |
| Operating expenses |  | 8,202 |  |  |  | 8,101 |  |  |  |
| Total after tax adjustments |  | 13,655 |  | 0.40 |  | 10,119 |  | 0.30 |  |
| Non-GAAP |  | $ | 29,816 |  | $ | 0.87 |  | $ | 20,508 |  | $ | 0.60 |  |

[0001104659-13-006446:8k_2_02:64]
(a)  This adjustment is for the incurrence of transaction and integration costs related to our acquisition of MTS in May 2012.

[0001104659-13-006446:8k_2_02:65]
(b)  Beginning with the second quarter of 2012, we are recognizing the amortization expense resulting from all intangible assets recorded from business acquisitions as a non-GAAP adjustment, including MTS and prior acquisitions.

[0001104659-13-006446:8k_2_02:66]
(c)  The 2011 adjustment is for the accrual of a $1.0 million pre-tax litigation settlement in operating expenses ($0.6 million, net of tax effect of $0.4 million) in the first quarter of 2011.

[0001104659-13-006446:8k_2_02:67]
(d)  Tax effects are calculated using the effective tax rates for the respective periods presented.

[0001104659-13-006446:8k_2_02:68]
(e)  This adjustment reflects the accounting impact of non-cash stock-based compensation expense related to the impact of ASC 718 for the periods shown.

[0001104659-13-006446:8k_2_02:69]
Omnicell, Inc.

[0001104659-13-006446:8k_2_02:70]
Calculation of Adjusted EBITDA (1)

[0001104659-13-006446:8k_2_02:71]
(In thousands, unaudited)

[0001104659-13-006446:8k_2_02:72]
|  |  | Three Months Ended |  | Year Ended |  |
|  |  | December 31, 2012 |  | September 30, 2012 |  | December 31, 2011 |  | December 31, 2012 |  | December 31, 2011 |  |
| GAAP net income |  | $ | 5,515 |  | $ | 6,920 |  | $ | 4,138 |  | $ | 16,161 |  | $ | 10,389 |  |
| Add back: |  |  |  |  |  |  |  |  |  |  |  |
| ASC 718 stock compensation expense |  | 2,433 |  | 2,361 |  | 2,245 |  | 9,214 |  | 9,499 |  |
| Transaction and integration costs for acquisitions, pre-tax |  | — |  | — |  | — |  | 4,855 |  | — |  |
| Litigation settlement, pre-tax |  | — |  | — |  | — |  |  |  | 1,000 |  |
| Interest |  | (2 | ) | 9 |  | (21 | ) | (48 | ) | (205 | ) |
| Depreciation and amortization expense |  | 4,077 |  | 3,913 |  | 2,163 |  | 13,323 |  | 7,984 |  |
| Income tax expense |  | 4,168 |  | 4,340 |  | 1,964 |  | 10,871 |  | 5,700 |  |
| Non-GAAP adjusted EBITDA (1) |  | $ | 16,191 |  | $ | 17,543 |  | $ | 10,489 |  | $ | 54,376 |  | $ | 34,367 |  |

[0001104659-13-006446:8k_2_02:73]
(1) Defined as earnings before interest income and expense, taxes, depreciation and amortization, and non-cash expenses, including stock compensation expense, per ASC 718, as well excluding certain non-GAAP adjustments.  The non-GAAP adjustments for the year ended December 31, 2012 also exclude transaction and integration costs for MTS, acquired in May 2012. The non-GAAP adjustments for the year ended December 31, 2011 also exclude first quarter 2011 expense for a pre-tax litigation settlement.
