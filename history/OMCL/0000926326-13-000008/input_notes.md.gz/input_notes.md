# OMCL notes — 0000926326-13-000008


## us-gaap:AllowanceForCreditLossesOnFinancingReceivablesTableTextBlock

[0000926326-13-000008:notes:1]
The following table summarizes the credit losses and recorded investment in sales-type leases, excluding unearned interest, as of December 31, 2012 and December 31, 2011 (in thousands):

[0000926326-13-000008:notes:2]
|  | Allowance for Credit Losses |  | Recorded Investmentin Sales-type Leases Gross |  | Recorded Investmentin Sales-type Leases Net |
| Credit loss disclosure for December 31, 2012: |  |  |  |  |  |  |  |  |
| Accounts individually evaluated for impairment | $ | 489 |  |  | $ | 489 |  |  | $ | — |  |
| Accounts collectively evaluated for impairment | 118 |  |  | 18,578 |  |  | 18,460 |  |
| Ending balances: December 31, 2012 | $ | 607 |  |  | $ | 19,067 |  |  | $ | 18,460 |  |
| Credit loss disclosure for December 31, 2011: |  |  |  |  |  |  |  |  |
| Accounts individually evaluated for impairment | $ | 178 |  |  | $ | 178 |  |  | $ | — |  |
| Accounts collectively evaluated for impairment | 106 |  |  | 13,940 |  |  | 13,834 |  |
| Ending balances: December 31, 2011 | $ | 284 |  |  | $ | 14,118 |  |  | $ | 13,834 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0000926326-13-000008:notes:3]
Organization and Summary of Significant Accounting Policies

[0000926326-13-000008:notes:4]
Description of the Company.  Omnicell, Inc. ("Omnicell," "our," "us," "we," or the "Company") was incorporated in California in 1992 under the name Omnicell Technologies, Inc. and reincorporated in Delaware in 2001 as Omnicell, Inc. Our major products are automated medication and supply control systems which are sold in our principal market, which is the healthcare industry. Our market is primarily located in the United States.

[0000926326-13-000008:notes:5]
On May 21, 2012, we completed our acquisition of MedPak Holdings, Inc. ("MedPak"). MedPak is the parent company of MTS Medication Technologies, Inc. ("MTS"), a worldwide provider of medication adherence packaging systems. This acquisition aligns us with the long-term trends of the healthcare market to manage the health of patients across the continuum of care.  We can now serve both the acute care and non-acute markets. Omnicell and MTS bring capabilities to each other that strengthen the product lines and expand the medication management coverage of both companies. Please refer to Note 2, "Business Acquisition" for more information regarding the transaction.

[0000926326-13-000008:notes:6]
In 2010, we completed an acquisition of Pandora Data Systems ("Pandora"). The consolidated financial statements include the results of operations from this business combination from September 29, 2010, the date of acquisition. Additional disclosure related to the acquisition is provided in Note 2, "Business Acquisition."

[0000926326-13-000008:notes:7]
Principles of consolidation.  The consolidated financial statements include the accounts of our wholly-owned subsidiaries. All significant inter-company accounts and transactions have been eliminated in consolidation.

[0000926326-13-000008:notes:8]
Reclassifications.  A reclassification has been made to the prior year consolidated balance sheet to conform to the current period presentation. We reclassified customer net receivable credit balances from accounts receivable to accrued liabilities. This reclassification was immaterial to the consolidated financial statements.

[0000926326-13-000008:notes:9]
Use of estimates.  The preparation of financial statements in accordance with U.S. generally accepted accounting principles ("GAAP") requires management to make estimates and assumptions that affect the amounts reported in our consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management's best knowledge of current events and actions that may impact the company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition, share-based compensation, inventory valuation, valuation of goodwill and purchased intangibles, valuation of long-lived assets and accounting for income taxes.

[0000926326-13-000008:notes:10]
Cash and cash equivalents. We classify investments as cash equivalents if their original or remaining contractual maturity is three months or less at the date of purchase. Cash equivalents are stated at cost, which approximates fair value. Our cash and cash equivalents are maintained in demand deposit accounts with financial institutions of high credit quality and are invested in institutional money market funds, short-term bank time deposits and similar short duration instruments with fixed maturities from overnight to three months. We continuously monitor the creditworthiness of the financial institutions and institutional money market funds in which we invest our surplus funds. We have not experienced any credit losses from our cash investments.

[0000926326-13-000008:notes:11]
We classify investments as short-term investments if their original or remaining maturities at purchase are greater than three months and their remaining maturities are one year or less.

[0000926326-13-000008:notes:12]
Fair value of financial instruments.  We value our financial assets and liabilities on a recurring basis using the fair value hierarchy established in Accounting Standards Codification ("ASC") 820, Fair Value Measurements and Disclosures.

[0000926326-13-000008:notes:13]
ASC 820 describes three levels of inputs that may be used to measure fair value, as follows:

[0000926326-13-000008:notes:14]
Level 1 inputs, which include quoted prices in active markets for identical assets or liabilities;

[0000926326-13-000008:notes:15]
Level 2 inputs, which include observable inputs other than Level 1 inputs, such as quoted prices for similar assets or liabilities, quoted prices for identical or similar assets or liabilities in markets that are not active; or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the asset or liability; and

[0000926326-13-000008:notes:16]
Level 3 inputs, which include unobservable inputs that are supported by little or no market activity and that are significant to the fair value of the underlying asset or liability. Level 3 assets and liabilities include those whose fair value measurements are determined using pricing models, discounted cash flow methodologies or similar valuation techniques, as well as significant management judgment or estimation.

[0000926326-13-000008:notes:17]
At December 31, 2012 and December 31, 2011, our financial assets utilizing Level 1 inputs included cash equivalents. For these items, quoted market prices are readily available and fair value approximates carrying value. At December 31, 2011 we had a short term investment in California revenue anticipation notes the valuation inputs of which are classified as Level 2. We do not currently have any material financial instruments utilizing Level 3 inputs.

[0000926326-13-000008:notes:18]
Classification of marketable securities. Marketable securities for which we have the intent and ability to hold to maturity are classified as held-to-maturity, with carrying value at amortized cost, including accrued interest. We do not hold securities for purposes of trading. However, securities held as investments for the indefinite future, pending future spending requirements are classified as available-for-sale, with carrying value at fair value and any unrealized gain or loss recorded to other comprehensive income until realized. We held $38.9 million of money market mutual funds as available-for-sale cash equivalents as of December 31, 2012. As of December 31, 2011, we held $177.3 million of money market mutual funds as available-for-sale cash equivalents and $8.1 million of non-U.S. Government securities as an available-for-sale short-term investments.

[0000926326-13-000008:notes:19]
Revenue recognition.    We earn revenues from sales of our medication control systems together with related consumables and services, and medical/surgical supply control systems with related services, which are sold in our principal market, which is the healthcare industry. Revenues related to consumable products are reported net of discounts provided to our customers. Our customer arrangements typically include one or more of the following deliverables:

[0000926326-13-000008:notes:20]
| • | Products—Software-enabled equipment that manages and regulates the storage and dispensing of pharmaceuticals, consumable blister cards and packaging equipment and other medical supplies. |

[0000926326-13-000008:notes:21]
| • | Software—Additional software applications that enable incremental functionality of our equipment. |

[0000926326-13-000008:notes:22]
| • | Installation—Installation of equipment as integrated systems at customers' sites. |

[0000926326-13-000008:notes:23]
| • | Post-installation technical support—Phone support, on-site service, parts and access to unspecified software upgrades and enhancements, if and when available. |

[0000926326-13-000008:notes:24]
| • | Professional services—Other customer services such as training and consulting. |

[0000926326-13-000008:notes:25]
We recognize revenue when the earnings process is complete, based upon our evaluation of whether the following four criteria have been met:

[0000926326-13-000008:notes:26]
| • | Persuasive evidence of an arrangement exists. We use signed customer contracts and signed customer purchase orders as evidence of an arrangement for leases and sales. For service engagements, we use a signed services agreement and a statement of work to evidence an arrangement. |

[0000926326-13-000008:notes:27]
| • | Delivery has occurred. Equipment and software product delivery is deemed to occur upon successful installation and receipt of a signed and dated customer confirmation of installation letter, providing evidence that we have delivered what a customer ordered. In instances of a customer self-installed installation, product delivery is deemed to have occurred upon receipt of a signed and dated customer confirmation letter. If a sale does not require installation, we recognize revenue on delivery of products to the customer, including transfer of title and risk of loss, assuming all other revenue criteria are met. We recognize revenue from sales of products to distributors upon delivery assuming all other revenue criteria are met since we do not allow for rights of return or refund. For the sale of consumable blister cards, we recognize revenue when title and risk of loss of the products shipped have transferred to the customer, which usually occurs upon shipment from our facilities. Assuming all other revenue criteria are met, we recognize revenue for support services ratably over the related support services contract period. We recognize revenue on training and professional services as they are performed. |

[0000926326-13-000008:notes:28]
| • | Fee is fixed or determinable. We assess whether a fee is fixed or determinable at the outset of the arrangement based on the payment terms associated with the transaction. We have established a history of collecting under the original contract without providing concessions on payments, products or services. |

[0000926326-13-000008:notes:29]
| • | Collection is probable. We assess the probability of collecting from each customer at the outset of the arrangement based on a number of factors, including the customer's payment history and its current creditworthiness. If, in our judgment, collection of a fee is not probable, we defer the revenue until the uncertainty is removed, which generally means revenue is recognized upon our receipt of cash payment assuming all other revenue criteria are met. Our historical experience has been that collection from our customers is generally probable. |

[0000926326-13-000008:notes:30]
In arrangements with multiple deliverables, assuming all other revenue criteria are met, we recognize revenue for individual delivered items if they have value to the customer on a standalone basis. Effective for new or modified arrangements entered into beginning on January 1, 2011, the date we adopted the revised revenue recognition guidance for arrangements with multiple deliverables on a prospective basis, we allocate arrangement consideration at the inception of the arrangement to all deliverables using the relative selling price method. This method requires us to determine the selling price at which each deliverable could be sold if it were sold regularly on a standalone basis. When available, we use vendor-specific objective evidence ("VSOE") of fair value as the selling price. VSOE represents the price charged for a deliverable when it is sold separately or for a deliverable not yet being sold separately, the price established by management with the relevant authority. We consider VSOE to exist when approximately 80% or more of our standalone sales of an item are priced within a reasonably narrow pricing range (plus or minus 15% of the median rates). We have established VSOE of fair value for our post-installation technical support services and professional services. When VSOE of fair value is not available, third-party evidence ("TPE") of fair value for similar products and services is acceptable; however, our offerings and market strategy differ from those of our competitors, such that we cannot obtain sufficient comparable information about third parties' prices. If neither VSOE nor TPE are available, we use our best estimates of selling prices ("BESP"). We determine BESP considering factors such as market conditions, sales channels, internal costs and product margin objectives and pricing practices. We regularly review and update our VSOE, TPE and BESP information and obtain formal approval by appropriate levels of management.

[0000926326-13-000008:notes:31]
The relative selling price method allocates total arrangement consideration proportionally to each deliverable on the basis of its estimated selling price. In addition, the amount recognized for any delivered items cannot exceed that which is not contingent upon delivery of any remaining items in the arrangement.

[0000926326-13-000008:notes:32]
We also use the residual method of allocating the arrangement consideration in certain circumstances. We use the residual method to allocate total arrangement consideration between delivered and undelivered items for any arrangements entered into prior to January 1, 2011 and not subsequently materially-modified. The use of the residual method is required by software revenue recognition rules that applied to sales of most of our products and services until the adoption of the new revenue recognition guidance. We also use the residual method to allocate revenue between the software products that enable incremental equipment functionality and thus are not deemed to deliver its essential functionality, and the related post-installation technical support, as these products and services continue to be accounted for under software revenue recognition rules. Under the residual method, the amount allocated to the undelivered elements equals VSOE of fair value of these elements. Any remaining amounts are attributed to the delivered items and are recognized when those items are delivered.

[0000926326-13-000008:notes:33]
A portion of our sales are made through multi-year lease agreements. Under sales-type leases, we recognize revenue for our hardware and software products net of lease execution costs such as post-installation product maintenance and technical support, at the net present value of the lease payment stream once our installation obligations have been met. We optimize cash flows by selling a majority of our non-U.S. government leases to third-party leasing finance companies on a non-recourse basis. We have no obligation to the leasing company once the lease has been sold. Some of our sales-type leases, mostly those relating to U.S. government hospitals, are retained in-house. Interest income in these leases is recognized in product revenue using the effective interest method.

[0000926326-13-000008:notes:34]
Accounts receivable and notes receivable (net investment in sales type leases). We actively manage our accounts receivable to minimize credit risk. We typically sell to customers for which there is a history of successful collection. New customers are subject to a credit review process, which evaluates that customer's financial position and ability to pay. We continually monitor and evaluate the collectability of our trade receivables based on a combination of factors. We record specific allowances for doubtful accounts when we become aware of a specific customer's impaired ability to meet its financial obligation to us, such as in the case of bankruptcy filings or deterioration of financial position.

[0000926326-13-000008:notes:35]
Uncollectible amounts are charged off against trade receivables and the allowance for doubtful accounts when we make a final determination that there is no reasonable expectation of recovery. Estimates are used in determining our allowances for all other customers based on factors such as current trends, the length of time the receivables are past due and historical collection experience. While we believe that our allowance for doubtful accounts receivable is adequate and that the judgment applied is appropriate, such estimated amounts could differ materially from what will actually be uncollectible in the future.

[0000926326-13-000008:notes:36]
The retained in-house leases discussed above are considered financing receivables. Our credit policies and evaluation of credit risk and write-off policies are applied alike to trade receivables and the net-investment in sales-type leases. For both, an account is generally past due after thirty days. The financing receivables also have customer-specific reserves for accounts identified for specific impairment and a non-specific reserve applied to the remaining population, based on factors such as current trends, the length of time the receivables are past due and historical collection experience. The retained in-house leases are not stratified by portfolio or class. Financing receivables which are reserved are generally transferred to cash-basis accounting so that revenue is recognized only as cash is received. However, the cash basis accounts continue to accrue interest.

[0000926326-13-000008:notes:37]
Sales of accounts receivable.  We record the sale of our accounts receivables as "true sales" in accordance with accounting guidance for transfers and servicing of financial assets. During the years ended 2012, 2011 and 2010, we transferred non-recourse accounts receivable totaling $60.9 million, $46.9 million and $51.4 million, respectively, which approximated fair value, to leasing companies on a non-recourse basis. At December 31, 2012 and 2011, accounts receivable included approximately $0.7 million and $0.2 million, respectively, due from third-party leasing companies for transferred non-recourse accounts receivable.

[0000926326-13-000008:notes:38]
Concentration in revenues and in accounts receivable. There were no customers accounting for 10% or more of revenues for the years ended December 30, 2012, 2011 or 2010. At December 31, 2012 and 2011, no single customer accounted for more than 10% of our accounts receivable balance.

[0000926326-13-000008:notes:39]
Geographic risk. For the years ended December 31, 2012, 2011 and 2010, 7.5%, 2.0%, and 2.6%, respectively, of our product revenue was from foreign countries.

[0000926326-13-000008:notes:40]
Commissions. Sales commissions generally are earned by our sales team upon order receipt, but are recognized in expense at the time of revenue recognition. Before they are recognized as expense they are recorded as prepaid commissions, which are a component of prepaid expenses.

[0000926326-13-000008:notes:41]
Dependence on suppliers. We have a supply agreement with one primary supplier for construction and supply of several sub-assemblies and inventory management of sub-assemblies used in our hardware products. There are no minimum purchase requirements. The contract with our supplier may be terminated by either the supplier or by us without cause and at any time upon delivery of two months' notice. Purchases from this supplier for the years ended December 31, 2012, 2011 and 2010 were approximately $23.8 million, $21.1 million and $19.1 million, respectively.

[0000926326-13-000008:notes:42]
Inventory. Inventories are stated at the lower of cost (utilizing standard costs, applying the first-in, first-out method) or market. Cost elements included in inventory are direct labor and materials plus applied overhead. We routinely assess on-hand inventory for timely identification and measurement of obsolete, slow-moving or otherwise impaired inventory. We write down our inventory for estimated obsolescence, excess or unmarketable quantities equal to the difference between the cost of the inventory and its estimated market value based on assumptions about future demand and market conditions. If actual future demand or market conditions are less favorable than we projected, additional inventory write-downs may be required.

[0000926326-13-000008:notes:43]
Property and equipment. Property and equipment less accumulated depreciation are stated at historical cost. Our expenditures for property and equipment are for computer equipment and software used in the administration of our business, and for leasehold improvements to our leased facilities. We also develop molds and dies used in long-term manufacturing arrangements with suppliers, and for production automation equipment used in the manufacturing of consumable blister card components. Depreciation and amortization of property and equipment are provided over their estimated useful lives, using the straight-line method, as follows:

[0000926326-13-000008:notes:44]
| Computer equipment and related software | 3 - 5 years |
| Leasehold and building improvements | Shorter of the lease term or the estimated useful life |
| Furniture and fixtures | 5 years |
| Equipment | 3 - 5 years |

[0000926326-13-000008:notes:45]
We capitalize costs related to computer software developed or obtained for internal use in accordance with ASC 350-40, Internal-Use Software. Software obtained for internal use has generally been enterprise-level business and finance software that we customize to meet our specific operational needs. Costs incurred in the application development phase are capitalized and amortized over their useful lives, which is generally five years. Costs recognized in the preliminary project phase and the post-implementation phase are expensed as incurred. At December 31, 2012 and December 31, 2011, we had $5.4 million and $7.4 million of costs related to application development of enterprise-level software included in property and equipment, respectively.

[0000926326-13-000008:notes:46]
Software development costs. We capitalize software development costs in accordance with ASC 985-20, Costs of Software to Be Sold, Leased, or Marketed, under which certain software development costs incurred subsequent to the establishment of technological feasibility may be capitalized and amortized over the estimated lives of the related products. We establish feasibility when we complete a working model and amortize development costs over the estimated lives of the related products ranging from three to five years. During 2012 and 2011, we capitalized software development costs of $5.0 million and $4.2 million, respectively, which are included in other assets. For the years ended December 31, 2012, 2011 and 2010, we charged to cost of revenues $2.3 million, $1.6 million and $0.9 million, respectively, for amortization of capitalized software development costs. All development costs prior to the completion of a working model are recognized as research and development expense.

[0000926326-13-000008:notes:47]
Valuation and impairment of goodwill, other intangible assets and other long lived assets. We account for goodwill and other intangible assets in accordance with ASC 350, Intangibles—Goodwill and Other. For the initial recognition and measurement of Goodwill and Intangibles resulting from acquisitions, we use the guidance in ASC 805, Business Combinations.

[0000926326-13-000008:notes:48]
Under ASC 350, Intangibles - Goodwill and Other, goodwill and intangible assets with an indefinite life are not subject to amortization. Impairment is the condition that exists when the carrying amount of goodwill exceeds its implied fair value. Under the provisions of ASC 350-20, Goodwill and Other, the recorded goodwill is subject to annual impairment testing. In addition, the provisions of ASC 350-20, require that an entity assign its recorded goodwill to each of its reporting units and test each reporting unit's goodwill for impairment at least annually or earlier in circumstances whereby certain events might trigger a decrease in the carrying value of goodwill. We complete our annual goodwill impairment assessment as of the first day of our fourth quarter. In accordance with ASC 350-20, we have the option to assess qualitative factors to determine whether it is more likely than not (that is, a likelihood of more than 50%) that the fair value of a reporting unit is less than its carrying amount, including goodwill, or bypass the qualitative assessment and proceed directly to performing the goodwill impairment test. We have elected to perform a qualitative assessment to determine whether it more likely than not that the fair value of each reporting unit is less than its carrying amount.

[0000926326-13-000008:notes:49]
For both the Acute Care and Non-Acute Care segments, we considered the following qualitative factors when assessing if goodwill had been impaired for the year ended December 31, 2012:

[0000926326-13-000008:notes:50]
| • | Macroeconomic conditions such as a deterioration in general economic conditions, limitations on accessing capital, fluctuations in foreign exchange rates or other developments in equity and credit markets; |

[0000926326-13-000008:notes:51]
| • | Industry and market considerations such as a deterioration in the environment in which we operate, an increased competitive environment, a decline in market-dependent multiples or metrics (consider in both absolute terms and relative to peers), a change in the market for our products or services, or a regulatory or political development; |

[0000926326-13-000008:notes:52]
| • | Cost factors such as increases in raw materials, labor, or other costs that have a negative effect on earnings and cash flows; |

[0000926326-13-000008:notes:53]
| • | Overall financial performance such as negative or declining cash flows or a decline in actual or planned revenue or earnings compared with actual and projected results of relevant prior periods; |

[0000926326-13-000008:notes:54]
| • | Other relevant entity-specific events such as changes in management, key personnel, strategy, or customers; contemplation of bankruptcy or litigation; and |

[0000926326-13-000008:notes:55]
| • | Events affecting a reporting unit such as a change in the composition or carrying amount of its net assets, a more-likely-than-not expectation of selling or disposing all, or a portion, of a reporting unit, the testing for recoverability of a significant asset group within a reporting unit or recognition of a goodwill impairment loss in the financial statements of a subsidiary that is a component of a reporting unit. |

[0000926326-13-000008:notes:56]
Upon completion of our qualitative assessment conducted in the fourth quarter of 2012, management concluded that it was more likely than not the fair values of both the Acute and Non-Acute reporting units exceeded their carrying values including the respective amounts of goodwill. In addition, management did not note any other  indicators of goodwill  impairment as of December 31, 2012.

[0000926326-13-000008:notes:57]
We continually monitor events and changes in circumstances that could indicate carrying amounts of long-lived assets may not be recoverable. We review long-lived assets and certain purchased intangibles for impairment whenever events or changes in circumstances indicate that we will not be able to recover the asset's carrying amount. Recoverability of an asset is measured by comparing its carrying amount to the expected future undiscounted cash flows expected to result from the use and eventual disposition of that asset, excluding future interest costs that would be recognized as an expense when incurred. Any impairment to be recognized is measured by the amount by which the carrying amount of the asset exceeds its fair market value. Significant management judgment is required in:

[0000926326-13-000008:notes:58]
| • | identifying a triggering event that arises from a change in circumstances; |

[0000926326-13-000008:notes:59]
| • | forecasting future operating results; and |

[0000926326-13-000008:notes:60]
| • | estimating the proceeds from the disposition of long-lived or intangible assets. |

[0000926326-13-000008:notes:61]
Significant management judgment is also required for initial recognition and measurement of goodwill and other intangibles assets resulting from business combinations in accordance with ASC 805. Management must assess the extent to which identified other intangibles assets are properly includable (and with the appropriate fair value) or properly excludable, by applying the recognition criteria. This judgment affects not only the other intangible assets but the remainder calculation of goodwill. The assessment of useful life for each acquired intangible impacts future financial position and operating performance through amortization expense.

[0000926326-13-000008:notes:62]
Deferred service revenue and deferred gross profit. Deferred service revenue and deferred gross profit arise when customers are billed for products and/or services in advance of revenue recognition. Our deferred gross profit, classified as a current liability, consists primarily of unearned revenue on sale of equipment for which installation has not been completed, net of deferred cost of sales for such equipment, and the unearned revenue for software licenses. Our deferred service revenue, separated into current and long-term liabilities, consists of the unearned portion of service contracts for which revenue is recognized over their duration.

[0000926326-13-000008:notes:63]
Valuation of share-based awards. We account for share-based compensation plans in accordance to the provisions of ASC 718, Stock Compensation. We estimate the fair value of our employee stock awards at the date of grant using certain subjective assumptions, such as expected volatility, which is based on a combination of historical and market- based implied volatility, and the expected term of the awards which is based on our historical experience of employee stock option exercises including forfeitures. Our valuation assumptions used in estimating the fair value of share-based awards may change in future periods. We recognize the fair value of awards over their vesting period or requisite service period. In addition, we calculate our pool of excess tax benefits available within additional paid-in capital in accordance with the provisions of ASC 718.

[0000926326-13-000008:notes:64]
Accounting for income taxes. We record a tax provision for the anticipated tax consequences of the reported results of operations. In accordance with GAAP, the provision for income taxes is computed using the liability method, under which deferred tax assets and liabilities are recognized for the expected future tax consequences of temporary differences between the financial reporting and tax bases of assets and liabilities, and for operating losses and tax credit carry forwards. Deferred tax assets and liabilities are measured using the enacted tax rates expected to apply to taxable income in the periods in which those tax assets and liabilities are expected to be realized or settled. In the event that these tax rates change, we will record a benefit or detriment to our income tax expense in the period of change. If we were to determine that all or part of the net deferred tax assets are not realizable in the future, we will record a valuation allowance that would be charged to earnings in the period such determination is made.

[0000926326-13-000008:notes:65]
In accordance with ASC 740, Income Taxes, we recognize the tax benefit from an uncertain tax position if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement. The calculation of tax liabilities involves significant judgment in estimating the impact of uncertainties in the application of GAAP and complex tax laws. Resolution of these uncertainties in a manner inconsistent with management's expectations could have a material impact on our financial condition and operating results.

[0000926326-13-000008:notes:66]
Please refer to Note 14, "Income Taxes" for further information.

[0000926326-13-000008:notes:67]
Shipping costs. Outbound freight billed to customers is recorded as product revenue. The related shipping and handling costs are expensed as part of selling, general and administrative expense. Such shipping and handling expenses totaled $4.1 million, $2.7 million and $2.1 million for the years ended December 31, 2012, 2011 and 2010, respectively.

[0000926326-13-000008:notes:68]
Advertising. Advertising costs are expensed as incurred and amounted to $0.5 million, $0.9 million and $1.1 million for the years ended December 31, 2012, 2011 and 2010, respectively.

[0000926326-13-000008:notes:69]
Operating leases. We lease our buildings under operating leases accounted for in accordance with ASC 840, Leases.

[0000926326-13-000008:notes:70]
Sales taxes. Sales taxes collected from customers and remitted to governmental authorities are not included in our revenue.

[0000926326-13-000008:notes:71]
Foreign currency translation. We translate the assets and liabilities of our non-U.S. dollar functional currency subsidiaries into U.S. dollars using exchange rates in effect at the end of each period. Revenue and expenses for these subsidiaries are translated using rates that approximate those in effect during the period. Gains and losses from these translations are recorded as foreign currency translation adjustments and included in accumulated other comprehensive income in stockholders’ equity.

[0000926326-13-000008:notes:72]
Currency forward contracts. From time to time we enter into foreign currency forward contracts to protect our business from the risk that exchange rates may affect the eventual cash flows resulting from intercompany transactions between Omnicell and our foreign subsidiaries. These transactions primarily arise as a result of products manufactured in the U.S. and sold to foreign subsidiaries in U.S. dollars rather than the subsidiaries' functional currencies. These forward contracts are considered to be financial derivative instruments and are recorded at fair value in the balance sheet. Changes in fair values of these financial derivative instruments are either recognized in other comprehensive income (a component of stockholders' equity) or net income depending on whether the derivative has been designated and qualifies as a hedging instrument. As of December 31, 2012, we had no foreign currency forward contracts which qualify for hedge accounting.

[0000926326-13-000008:notes:73]
Total comprehensive income. The largest components of total comprehensive income for the year ended December 31, 2012 were foreign currency translation adjustments and changes in fair value of foreign currency forward hedges. The only difference included in total comprehensive income for the year ended December 31, 2011 was the tax-effected unrealized gain on available-for-sale securities for the holding period September 22, 2011 to December 31, 2011, which was immaterial. There was no difference due to other comprehensive income for the year ended December 31, 2010.

[0000926326-13-000008:notes:74]
Segment information. Prior to the acquisition of MTS, we managed our business on the basis of a single operating segment, and a single reporting unit within that segment per ASC 280, Segment Reporting. Beginning with the acquisition of MTS, which was completed in May 2012, we have organized our business into two operating business segments: Acute Care, which primarily includes products and services sold to hospital customers and Non-Acute Care, which primarily includes products and services sold to customers outside of the hospital settings.

[0000926326-13-000008:notes:75]
The Acute Care segment is organized around the design, manufacturing, selling and servicing of medication and supply dispensing systems. The Non-Acute Care segment includes primarily the manufacturing and selling of consumable medication blister cards, packaging equipment and ancillary products and services, but also includes medication dispensing systems sold to non-acute care pharmacies and facilities. We report segment information based on the management approach. The management approach designates the internal reporting used by the Chief Operating Decision Maker (the "CODM") for making decisions and assessing performance as the source of our operating segments. The CODM is our Chief Executive Officer. The CODM allocates resources to and assesses the performance of each operating segment, using information about its revenues, gross profit and income (loss) from operations.

[0000926326-13-000008:notes:76]
Substantially all of our long-lived assets are located in the United States. For the year ended December 31, 2012, all of our total revenues and gross profits were generated by both our Acute Care and Non-Acute Care segments and no one customer accounted for greater than 10% of our revenues. For the years ended December 31, 2011 and 2010, all of our total revenues and gross profits were generated by the Acute Care segment and no one customer accounted for greater than 10% of our revenues.

[0000926326-13-000008:notes:77]
Recently Adopted Accounting Standards

[0000926326-13-000008:notes:78]
In May 2011, FASB issued ASU 2011-04, Fair Value Measurement, amending the fair value guidance in ASC 820, and thereby achieving substantially converged fair value measurement and disclosure requirements for GAAP and IFRS. The new guidance clarified some fair value measurement principles and expanded certain disclosure requirements. We adopted this guidance in the first quarter of 2012, without any impact to our financial position, operating results or cash flows.

[0000926326-13-000008:notes:79]
In July 2012, FASB issued ASU 2012-02, Intangibles - Goodwill and Other (Topic 350): Testing Indefinite-lived Intangible Assets for Impairment, which amends the guidance in ASC 350-30 on impairment testing of intangible assets with indefinite lives other than goodwill. This guidance gives an entity the option to first assess qualitative factors to determine whether the existence of events or circumstances leads to a determination that it is more likely than not that an indefinite-lived asset is impaired. An entity has the option to bypass the qualitative assessment and proceed directly to calculating the fair value of an intangible asset with an indefinite life. We adopted this guidance in the fourth quarter of 2012, earlier than required, without any significant impact on our financial position, operating results or cash flows, as this update does not change how we calculate impairment loss.

[0000926326-13-000008:notes:80]
Recently Issued Accounting Standards

[0000926326-13-000008:notes:81]
In February 2013, FASB issued 2013-02, Comprehensive Income (Topic 220): Reporting of Amounts Reclassified Out of Accumulated Other Comprehensive Income (AOCI), which aims to improve the reporting of reclassifications out of AOCI. This update requires an entity to report the effect of significant reclassifications out of AOCI on the respective line items in net income if the amount being reclassified is required under GAAP to be reclassified in its entirety to net income. For other amounts that are not required under GAAP to be reclassified in their entirety to net income in the same reporting period, an entity is required to cross-reference other disclosures required under GAAP that provide additional detail about those amounts.  The amendments do not change the current requirements for reporting net income or other comprehensive income in financial statements. For public entities, the amendments are effective prospectively for reporting periods beginning after December 15, 2012. We intend to adopt this guidance in the first quarter of 2013. We do not anticipate this update will have any significant impact on our financial position, operating results or cash flows.


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0000926326-13-000008:notes:82]
The following represents unaudited pro forma revenue and net income as if MTS had been included in our consolidated results from January 1, 2011 (in thousands):

[0000926326-13-000008:notes:83]
|  | Year Ended December 31, |  |
|  | 2012 |  | 2011 |  |
| Revenues | $ | 342,770 |  |  | $ | 320,771 |  |  |
| Net income | $ | 19,030 |  |  | $ | 14,842 |  |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000926326-13-000008:notes:84]
Business Acquisition

[0000926326-13-000008:notes:85]
MTS Medication Technologies, Inc.

[0000926326-13-000008:notes:86]
On May 21, 2012, we completed our acquisition of MedPak Holdings, Inc. ("MedPak") pursuant to an Agreement and Plan of Merger (the "Merger Agreement") under which Mercury Acquisition Corp, a newly formed Omnicell subsidiary, was merged with and into MedPak, with MedPak surviving the merger as a wholly-owned subsidiary of Omnicell. MedPak is the parent company of MTS Medication Technologies, Inc. ("MTS").

[0000926326-13-000008:notes:87]
The MTS acquisition primarily was to align Omnicell with the long term trends of the healthcare market to manage the health of patients across the continuum of care. We can now better serve both the acute care and non-acute care markets. Omnicell and MTS bring capabilities to each other that strengthen the product lines and expand the medication management coverage of both companies.

[0000926326-13-000008:notes:88]
We are accounting for the transaction under the acquisition method of accounting in accordance with the provisions of FASB ASC Topic 805, Business Combinations. Under the acquisition method, the estimated fair value of the consideration transferred to purchase the acquired company is allocated to the assets acquired and the liabilities assumed based on their fair values. We have made significant estimates and assumptions in determining the allocation of the acquisition consideration.

[0000926326-13-000008:notes:89]
Pursuant to the terms of the Merger Agreement, we paid approximately $158.3 million in cash after adjustments provided for in the Merger Agreement, of which approximately $13.5 million was placed in an escrow fund, which will be distributed to MedPak's stockholders (subject to claims that we may make against the escrow fund for indemnification and other claims following the closing). The revised acquisition consideration of $158.3 million is comprised entirely of cash at closing.

[0000926326-13-000008:notes:90]
At date of acquisition, we also recorded a $1.8 million liability based on expected additional working capital adjustments. In October 2012, a portion of the escrow fund set aside for the working capital adjustment was disbursed, with Omnicell receiving $0.3 million and MedPak's former stockholders receiving the remainder. As of December 31, 2012, the working capital adjustment was reversed, with a resulting reduction in goodwill of $1.8 million and a corresponding reduction in accrued liabilities. Accounts receivable acquired were recorded at their estimated fair value, comprised of total contractual obligations due of $7.6 million, of which $0.2 million was not expected to be collected. Based on an acquisition date valuation, the preliminary estimated fair values of acquired inventory and property and equipment exceeded their historical carrying values. We recorded a preliminary step-up to the estimated fair value of acquired inventory in the amount of $1.6 million, which resulted in subsequent related charges of $1.6 million to cost of product revenues.

[0000926326-13-000008:notes:91]
In the fourth quarter of 2012, subsequent to the initial acquisition price allocation, we revised our preliminary determination of the fair value of fixed assets and intangible assets acquired from MTS, resulting in a decrease in the carrying value of acquired fixed assets of $1.3 million, and increase in the carrying value of intangibles of $0.4 million and a net increase in recorded goodwill of $0.9 million.

[0000926326-13-000008:notes:92]
The total consideration and the allocation of the consideration to the individual net assets is considered preliminary as there are remaining uncertainties to be resolved, including the completion of an analysis of potential contingent payroll tax withholding obligations.

[0000926326-13-000008:notes:93]
The total revised acquisition price was approximately $158.3 million and the  preliminary allocation is comprised of the following (in thousands):

[0000926326-13-000008:notes:94]
|  |  | Fair value acquired |  |  |
| Cash including restricted cash |  | $ | 2,000 |  |  |
| Accounts receivable |  | 7,403 |  |  |
| Inventory |  | 11,726 |  |  |
| Deferred tax assets and other current assets |  | 2,894 |  |  |
| Total current assets |  | 24,023 |  |  |
| Property and equipment |  | 9,807 |  |  |
| Intangible assets |  | 83,900 |  |  |
| Goodwill |  | 82,864 |  |  |
| Other non-current assets |  | 244 |  |  |
| Total assets |  | 200,838 |  |  |
| Current liabilities |  | (7,917 | ) |  |
| Non-current deferred tax liabilities |  | (33,386 | ) |  |
| Other non-current liabilities |  | (1,223 | ) |  |
| Net assets acquired |  | $ | 158,312 |  |  |
| Cash consideration, fair value |  | $ | 158,312 |  |  |

[0000926326-13-000008:notes:95]
Identifiable intangible assets. Acquired technology relates to MTS’ products across all of its product lines that have reached technological feasibility, primarily the OnDemand technology. Trade name is primarily related to the MTS and OnDemand brand names. Customer relationships represent existing contracted relationships with pharmacies, institutional care facilities and others. Acquired technology, customer relationships, and trade names will be amortized on a straight-line basis over their estimated useful lives, which range from 12 to 30 years.

[0000926326-13-000008:notes:96]
The estimated fair values of the acquired technology, trade names and customer relationships were primarily determined using either the relief-from-royalty or excess earnings methods. The interest rates utilized to discount net cash flows to their present values were determined after consideration of the overall enterprise rate of return and the relative risk and importance of the assets to the generation of future cash flows.

[0000926326-13-000008:notes:97]
For income tax purposes, the historical tax bases of the acquired assets and assumed liabilities, along with the tax attributes of the MTS companies, will carry over. Because the transaction was a cash-for-stock transaction, there is no tax basis in the newly acquired intangible assets. Accordingly, the acquisition accounting includes the establishment of net deferred tax liabilities of $33.4 million, resulting from book tax basis differences related to the intangible assets acquired, as well as to the step up in the value of fixed assets and inventory to their estimated fair values at the time of acquisition.

[0000926326-13-000008:notes:98]
Goodwill. Approximately $82.9 million has been allocated to goodwill. Goodwill represents the excess of the fair value of the consideration transferred over the fair value of the underlying net tangible and identifiable intangible assets on the acquisition date. In accordance with ASC Topic 350, Intangibles - Goodwill and Other, goodwill will not be amortized, but instead will be tested for impairment at least annually or more frequently if certain indicators are present. We believe the MTS acquisition enhances our offerings and diversifies our revenue mix, providing a more robust product and service solution to our current customers while expanding Omnicell’s international presence. We consider these factors as supporting the amount of goodwill recorded.

[0000926326-13-000008:notes:99]
Details of acquired intangibles are as follows (in thousands, except for years):

[0000926326-13-000008:notes:100]
|  |  | Fair value acquired |  |  | Useful Life (years) |  | First year amortization expense |  |  |
| Trade name |  | $ | 6,800 |  |  | 12 |  | $ | 567 |  |  |
| Customer relationships |  | 50,500 |  |  | 28 to 30 |  | 1,707 |  |  |
| Acquired technology |  | 26,600 |  |  | 20 |  | 1,330 |  |  |
| Intangibles acquired |  | $ | 83,900 |  |  |  |  | $ | 3,604 |  |  |
| Weighted average life of intangibles |  |  |  | 25.14 |  |  |  |

[0000926326-13-000008:notes:101]
For the year ended December 31, 2012, we incurred approximately $3.2 million in acquisition-related costs in connection with the MTS acquisition. These costs are included primarily in selling, general and administrative expenses on our Consolidated Statement of Operations.

[0000926326-13-000008:notes:102]
During the year ended December 31, 2012, the acquired MTS operations (consolidated since the May 21, 2012 acquisition date) generated revenue of approximately $47.2 million and net income of $2.9 million.

[0000926326-13-000008:notes:103]
The pro forma unaudited condensed consolidated operating results presented above were calculated after applying Omnicell's accounting policies and by adding together the historical operating statements of MTS and Omnicell, with certain adjustments, assuming an acquisition date of January 1, 2011. Based on the estimated fair values and useful lives determined from the allocation of total MTS acquisition consideration, MTS historical depreciation and amortization expense was replaced with acquisition-accounting depreciation and amortization expense. Also reflected is the interest expense elimination effect of MTS on its debt (since it would have been paid off at acquisition) and the elimination of certain management fees to an affiliated party, offset in part by interest income foregone by Omnicell, by no longer having the acquisition consideration available as interest-bearing cash, cash equivalents and short-term investments.

[0000926326-13-000008:notes:104]
The pro forma operating results do not include actual direct acquisition-related expenses incurred by MTS and Omnicell as such amounts are considered nonrecurring. The total of all adjustments were tax effected using an estimated federal and state effective income tax rate.

[0000926326-13-000008:notes:105]
The pro forma operating results do not include any assumption of operating synergies for the combined companies. These pro forma results are provided as required disclosures and should not be considered as a forecast for any future period, nor as representing what the actual operating results would have been if the acquisition, in fact, had occurred on January 1, 2011.

[0000926326-13-000008:notes:106]
Pandora Data Systems, Inc.

[0000926326-13-000008:notes:107]
On September 29, 2010, we completed the acquisition of all of the outstanding capital stock of Pandora Data Systems, Inc. ("Pandora"), a provider of analytical software for medication diversion detection and regulatory compliance, for $6.0 million in cash.

[0000926326-13-000008:notes:108]
In connection with the acquisition, we recorded $3.6 million of goodwill, equal to the excess of the fair value of the purchase consideration over the fair values of the net tangible and intangible assets acquired, which is tax deductible over a fifteen-year period. The following table summarizes the fair value acquisition accounting for Pandora on the September 29, 2010 purchase date (in thousands):

[0000926326-13-000008:notes:109]
|  |  | Fair value acquired |  |
| Cash |  | $ | 297 |  |  |
| Accounts receivable |  | 416 |  |  |
| Indemnification asset |  | 1,000 |  |  |
| Intangibles |  | 2,420 |  |  |
| Goodwill |  | 3,561 |  |  |
| Deferred tax asset |  | 108 |  |  |
| Total assets |  | 7,802 |  |  |
| Accrued compensation/other |  | (292 | ) |  |
| Deferred service revenue |  | (510 | ) |  |
| Litigation contingency |  | (1,000 | ) |  |
| Total liabilities |  | (1,802 | ) |  |
| Net assets acquired |  | $ | 6,000 |  |  |
| Cash consideration, fair value |  | $ | 6,000 |  |  |

[0000926326-13-000008:notes:110]
The $0.4 million fair value of accounts receivable consists of gross contractual commitments from customers less the amount not expected to be collected. The $0.5 million of deferred service revenue represents the fair value, using estimated discounted cash flows, of acquired remaining performance obligations under service contracts.

[0000926326-13-000008:notes:111]
Additionally, an acquired legal contingency related to a contractual dispute between Pandora and a third party resulted in a liability accrual of $1.0 million, measured under ASC 450, Contingencies, guidance. An indemnification asset of $1.0 million was also recorded, since the former shareholders of Pandora had agreed to indemnify Omnicell against losses related to the litigation and a portion of the purchase price was placed in escrow to secure the indemnification obligations of the former Pandora shareholders.

[0000926326-13-000008:notes:112]
This lawsuit was settled on February 17, 2011 for $1.2 million, the settlement amount of which was paid entirely from the selling shareholders' escrow account. As this is considered a new development, rather than evidence of conditions existing at the September 29, 2010 acquisition date, the disclosure of this dispute in the original purchase price allocation was not adjusted. However, as a recognized subsequent event, on our balance sheet as of December 31, 2010 we recorded the updated $1.2 million values for the acquired legal contingency and the indemnification asset. Furthermore, during the three months ended March 31, 2011, the $1.2 million asset and $1.2 million liability were reversed after settlement from the seller's escrow account. There was no impact on net income for either 2010 or 2011.

[0000926326-13-000008:notes:113]
Operating results of Pandora have been combined with our operating results from the date of acquisition. Pro forma combined operating results for Omnicell and Pandora for the year ended December 31, 2010 has been omitted since the results of operations of Pandora were not material.


## us-gaap:CashAndCashEquivalentsDisclosureTextBlock

[0000926326-13-000008:notes:114]
Cash and Cash Equivalents, Short-term Investments and Fair Value of Financial Instruments

[0000926326-13-000008:notes:115]
Cash and cash equivalents and short-term investments consist of the following significant investment asset classes, with disclosure of amortized cost, gross unrealized gains and losses, and fair value as of December 31, 2012 and December 31, 2011 (in thousands):

[0000926326-13-000008:notes:116]
|  | December 31, 2012 |  |  |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | Fair Value |  | Cash / CashEquivalents |  | Short-termInvestments |  | SecurityClassification |
| Cash | $ | 23,422 |  |  | $ | — |  |  | $ | — |  |  | $ | 23,422 |  |  | $ | 23,422 |  |  | $ | — |  |  | N/A |
| Money market funds | 38,892 |  |  | — |  |  | 1 |  |  | 38,891 |  |  | 38,891 |  |  | — |  |  | Available for sale |
| Total cash, cash equivalents and short-term investments | $ | 62,314 |  |  | $ | — |  |  | $ | 1 |  |  | $ | 62,313 |  |  | $ | 62,313 |  |  | $ | — |  |  |  |

[0000926326-13-000008:notes:117]
|  | December 31, 2011 |  |  |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | Fair Value |  | Cash / CashEquivalents |  | Short-termInvestments |  | SecurityClassification |
| Cash | $ | 14,452 |  |  | $ | — |  |  | $ | — |  |  | $ | 14,452 |  |  | $ | 14,452 |  |  | $ | — |  |  | N/A |
| Money market funds | 177,310 |  |  | — |  |  | — |  |  | 177,310 |  |  | 177,310 |  |  | — |  |  | Available for sale |
| Non-U.S. government securities | 8,106 |  |  | 1 |  |  | — |  |  | 8,107 |  |  | — |  |  | 8,107 |  |  | Available for sale |
| Total cash, cash equivalents and short-term investments | $ | 199,868 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 199,869 |  |  | $ | 191,762 |  |  | $ | 8,107 |  |  |  |

[0000926326-13-000008:notes:118]
The money market fund is a daily-traded cash equivalent with a price of $1.00, making it a Level 1 asset class, and its carrying cost closely approximates fair value. As demand deposit (cash) balances vary with the timing of collections and payments, the money market fund can cover any surplus or deficit, and thus is considered Available-for-sale.

[0000926326-13-000008:notes:119]
The short term investments purchased in September 2011 were comprised of California revenue anticipation notes, which matured in June 2012. As this is the initial investment in a broader portfolio strategy for yield management, these are considered Available-for-sale. The notes were considered a Level 2 asset class, because their pricing is drawn from multiple market-related inputs, but in general not from same-day, same-security trades.

[0000926326-13-000008:notes:120]
The following table displays the financial assets measured at fair value, on a recurring basis, with money market funds recorded within cash and cash equivalents and non-U.S Government securities in short-term investments (in thousands):

[0000926326-13-000008:notes:121]
|  | Quoted Prices in ActiveMarkets for IdenticalInstruments (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant UnobservableInputs(Level 3) |  | Total FairValue |
| At December 31, 2012 |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 38,891 |  |  | $ | — |  |  | — |  |  | $ | 38,891 |  |
| Total | $ | 38,891 |  |  | $ | — |  |  | — |  |  | $ | 38,891 |  |
| At December 31, 2011 |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 177,310 |  |  | — |  |  | — |  |  | $ | 177,310 |  |
| Non U.S. Government securities | — |  |  | $ | 8,107 |  |  | — |  |  | 8,107 |  |
| Total | $ | 177,310 |  |  | $ | 8,107 |  |  | — |  |  | $ | 185,417 |  |

[0000926326-13-000008:notes:122]
Current assets and current liabilities are recorded at amortized cost, which approximates fair value due to the short-term maturities implied.


## us-gaap:CommitmentsDisclosureTextBlock

[0000926326-13-000008:notes:123]
Commitments

[0000926326-13-000008:notes:124]
At December 31, 2012, the minimum payments under our operating leases for each of the five succeeding fiscal years were as follows (in thousands):

[0000926326-13-000008:notes:125]
| 2013 | $ | 5,602 |  |
| 2014 | 5,367 |  |
| 2015 | 5,188 |  |
| 2016 | 4,909 |  |
| 2017 | 4,218 |  |
| Thereafter | 20,303 |  |
| Total | $ | 45,587 |  |

[0000926326-13-000008:notes:126]
Commitments under operating leases relate primarily to leasehold property and office equipment. Rent expense totaled $5.7 million, $3.3 million and $3.6 million for the years ended December 31, 2012, 2011 and 2010, respectively. For 2011, we had $0.5 million of non-cancelable sublease income.

[0000926326-13-000008:notes:127]
In October 2011, we entered into a lease agreement for approximately 100,000 square feet of office space. Pursuant to the lease agreement, the landlord has constructed a single, three-story building of rentable space in Mountain View, California which we now lease and which serves as our headquarters. The term of the lease agreement, which commenced in November 2012, is for a period of 10 years, with a base lease commitment of approximately $40.0 million. We have two options to extend the term of the lease agreement at market rates. Each extension is for an additional 60 month term.

[0000926326-13-000008:notes:128]
In March 2012, we entered into a lease agreement for approximately 46,000 square feet of manufacturing, distribution and office space located in Milpitas, California which commenced in October, 2012. The term of the lease agreement is for a period of 60 months, with a base lease commitment of approximately $1.8 million and a single 60 month extension option.

[0000926326-13-000008:notes:129]
In connection with the acquisition of MTS, we assumed responsibility for its 132,500 square feet of manufacturing, warehousing and office space in St. Petersburg, Florida. The remaining term of the original twelve year lease agreement, which expires in September 2016 and at the time of the MTS acquisition, had a remaining base lease commitment of approximately $3.9 million. We have two options to extend the term of the lease agreement at market rates. Each extension is for an additional 60 month term.

[0000926326-13-000008:notes:130]
In Leeds, United Kingdom, we lease an office and distribution center. The remaining term of the original ten year lease agreement is through June 8, 2021, with no extension options. The remaining base lease commitment at the time of the MTS acquisition, converted from British Pounds at the conversion rate then in effect, was approximately $1.2 million.

[0000926326-13-000008:notes:131]
We also have smaller rented offices in Strongsville, Ohio, the United Arab Emirates, the People's Republic of China and Germany.

[0000926326-13-000008:notes:132]
We purchase components from a variety of suppliers and use contract manufacturers to provide manufacturing services for our products. During the normal course of business, we issue purchase orders with estimates of our requirements several months ahead of the delivery dates. Our near-term commitments to our contract manufacturers and suppliers totaled $7.1 million as of December 31, 2012.


## us-gaap:DeferredCostsCapitalizedPrepaidAndOtherAssetsDisclosureTextBlock

[0000926326-13-000008:notes:133]
Other assets consist of the following (in thousands):

[0000926326-13-000008:notes:134]
|  | December 31, |
|  | 2012 |  | 2011 |
| Capitalized software development costs, net of accumulated amortization of $7,329 and $5,018 in 2012 and 2011, respectively | $ | 11,037 |  |  | $ | 8,077 |  |
| Technology license | 2,800 |  |  | — |  |
| Long-term deposits | 694 |  |  | 526 |  |
| Non-current deferred service billings receivable | 34 |  |  | 763 |  |
| Other assets | 1,213 |  |  | 350 |  |
| Total | $ | 15,778 |  |  | $ | 9,716 |  |


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0000926326-13-000008:notes:135]
Deferred gross profit consists of the following (in thousands):

[0000926326-13-000008:notes:136]
|  | December 31, 2012 |  | December 31, 2011 |
| Sales of medication and supply dispensing systems and packaging equipment, which have been delivered and invoiced but not yet installed | $ | 30,138 |  |  | $ | 24,181 |  |
| Cost of revenues, excluding installation costs | (9,366 | ) |  | (9,971 | ) |
| Deferred gross profit | $ | 20,772 |  |  | $ | 14,210 |  |


## us-gaap:DeferredRevenueDisclosureTextBlock

[0000926326-13-000008:notes:137]
Deferred Gross Profit


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000926326-13-000008:notes:138]
Stock Option Plans, Share-Based Compensation and 401(k) Plan

[0000926326-13-000008:notes:139]
Description of Share-Based Plans

[0000926326-13-000008:notes:140]
Equity Incentive Plan. On May 19, 2009, at our 2009 Annual Meeting of Stockholders (the "2009 Annual Meeting") our stockholders approved the Omnicell, Inc. 2009 Equity Incentive Plan (the "2009 Plan") which authorized 2,100,000 shares to be issued. The 2009 Plan provides for the issuance of incentive stock options, non-statutory stock options, stock appreciation rights, restricted stock awards, restricted stock unit awards, performance stock awards, performance cash awards and other stock awards to our employees, directors and consultants.

[0000926326-13-000008:notes:141]
The 2009 Plan succeeded the 1999 Equity Incentive Plan, as amended, the 2003 Equity Incentive Plan, as amended, and the 2004 Equity Incentive Plan (collectively, the "Prior Plans"). No additional awards will be granted under any of the Prior Plans; however, all outstanding stock awards granted under the Prior Plans continue to be subject to the terms and conditions as set forth in the agreements evidencing such stock awards. For purposes of determining future common shares available for grant, for each share granted as a full-value award, including restricted stock and restricted stock units ("RSUs") performance stock awards, the shares available for grant were reduced by 1.4 shares. Equity awards granted as stock options and stock appreciation rights reduce the shares available for grant by one share.

[0000926326-13-000008:notes:142]
On December 16, 2010, at a Special Meeting of Stockholders, our stockholders approved an amendment to increase the number of shares of common stock authorized for issuance under the 2009 Plan by 2,600,000 shares and to provide that the number of common stock shares available for issuance under the 2009 Plan be reduced by 1.8 shares for each share granted as a full-value award granted on and after October 1, 2010. For each share granted as a full-value award granted prior to October 1, 2010, future shares available for grants under the 2009 Plan were reduced by 1.4 shares. Awards granted as stock options and stock appreciation rights continue to reduce the number of shares available for issuance under the 2009 Plan on a one-for-one basis. At December 31, 2012, 1,636,329 shares of common stock were reserved for future issuance under the 2009 Plan.

[0000926326-13-000008:notes:143]
Options granted under the 2009 Plan generally become exercisable over periods of up to 4 years, generally with one-fourth of the shares vesting one year from the vesting commencement date with respect to initial grants, and the remaining shares vesting in 36 equal monthly installments thereafter; however our board of directors may impose different vesting terms at its discretion on any award. Options under the 2009 Plan generally expire 10 years from the date of grant. We also grant both restricted stock and restricted stock units to participants under the 2009 Plan. The board of directors determines the award amount, the vesting provisions and the expiration period (not to exceed ten years) for each grant. Grants of restricted stock to non-employee directors are granted on the date of our annual meeting of stockholders and vest in full on the date of our next annual meeting of stockholders, provided such non-employee director remains a director on such date. The fair value of the stock on the date of issuance is amortized to expense from the date of grant to the date of vesting. RSUs granted to employees generally vest over a period of four years and are expensed ratably on a straight-line basis over the vesting period. We consider the dilutive impact of options, restricted stock and restricted stock units in our diluted net income per share calculation.

[0000926326-13-000008:notes:144]
The board of directors shall administer the 2009 Plan unless and until the board of directors delegates administration to a committee. Our board of directors has delegated administration of the 2009 Plan to the compensation committee of the board and the 2009 Plan is generally administered by such committee. The board of directors may suspend or terminate the 2009 Plan at any time. The board of directors may also amend the 2009 Plan at any time or from time to time. However, no amendment will be effective unless approved by our stockholders after its adoption by the board of directors to the extent stockholder approval is necessary to satisfy the applicable listing requirements of NASDAQ.

[0000926326-13-000008:notes:145]
If we sell, lease or dispose of all or substantially all of our assets, or we are acquired pursuant to a merger or consolidation, then the surviving entity may assume or substitute all outstanding awards under the 2009 Plan. If the surviving entity does not assume or substitute these awards, then generally the stock awards will immediately and fully vest.

[0000926326-13-000008:notes:146]
1997 Employee Stock Purchase Plan

[0000926326-13-000008:notes:147]
We have an Employee Stock Purchase Plan (the "ESPP"), under which employees can purchase shares of our common stock based on a percentage of their compensation, but not greater than 15% of their earnings, up to a maximum of $25,000 of fair value per year. The purchase price per share must be equal to the lower of 85% of the fair value of the common stock at the beginning of a 24-month offering period or the end of each six-month purchasing period.

[0000926326-13-000008:notes:148]
At our 2009 Annual Meeting, the stockholders approved an amendment to the ESPP, which added 2,622,426 shares to the reserve for future issuance. As of December 31, 2012, there was a total of 1,548,711 shares reserved for future issuance under the ESPP. During the year ended December 31, 2012, 377,849 shares of common stock were purchased under the ESPP. As of December 31, 2012, 3,782,844 shares had been issued under the ESPP.

[0000926326-13-000008:notes:149]
As of December 31, 2012, our unrecognized compensation cost related to the shares to be purchased under our ESPP was approximately $0.5 million and is expected to be recognized over a weighted average period of 1.8 years.

[0000926326-13-000008:notes:150]
401(k) Plan

[0000926326-13-000008:notes:151]
We have established a 401(k) tax-deferred savings plan (the "Omnicell Plan"), whereby eligible employees may contribute a percentage of their eligible compensation, but not greater than 75% of their earnings, up to the maximum as required by law. On January 1, 2009, we began matching 401(k) contributions, up to 3% maximum of employee contributions or $1,000, whichever is lower. During the fourth quarter of 2012, the MTS 401(k) tax-deferred savings plan was merged with the Omnicell Plan. For the years ended December 31, 2012, 2011 and 2010, our total 401(k) contributions were $0.8 million, $0.6 million and $0.5 million, respectively.

[0000926326-13-000008:notes:152]
Share-Based Compensation—Measurement and Disclosure

[0000926326-13-000008:notes:153]
We have recognized compensation expense based on the estimated grant date fair value method required under ASC 718 using straight-line amortization method. As ASC 718 requires that share-based compensation expense be based on awards that are ultimately expected to vest, estimated share-based compensation in 2012, 2011 and 2010 has been reduced for estimated forfeitures.

[0000926326-13-000008:notes:154]
Total share-based compensation resulting from stock option grants, restricted stock awards, restricted stock units and shares purchased under our ESPP were included in our consolidated statements of operations as follows (in thousands, except per share data):

[0000926326-13-000008:notes:155]
|  | Years Ended December 31, |
|  | 2012 |  | 2011 |  | 2010 |
| Cost of revenues | $ | 1,011 |  |  | $ | 1,398 |  |  | $ | 1,350 |  |
| Research and development | 889 |  |  | 1,269 |  |  | 755 |  |
| Selling, general and administrative | 7,314 |  |  | 6,832 |  |  | 6,910 |  |
| Total share-based compensation expense | $ | 9,214 |  |  | $ | 9,499 |  |  | $ | 9,015 |  |

[0000926326-13-000008:notes:156]
We did not capitalize any share-based compensation into inventory during 2012, 2011 and 2010 as it was not material. Income tax (charges) benefits realized from share-based compensation and resulting increases (decreases) to additional paid in capital during 2012, 2011 and 2010 were $2.6 million, $2.9 million and $2.0 million, respectively.

[0000926326-13-000008:notes:157]
Valuation Assumptions

[0000926326-13-000008:notes:158]
The fair value of each option grant is estimated on the date of grant using the Black-Scholes-Merton option-pricing model. The fair value of shares issued under the employee stock purchase plans is estimated on the date of issuance using the Black-Scholes-Merton model. The weighted average assumptions used for options granted and ESPP in 2012, 2011 and 2010 were as follows:

[0000926326-13-000008:notes:159]
|  | Years Ended December 31, |
| Stock Option Plans | 2012 |  | 2011 |  | 2010 |
| Risk-free interest rate(1) | 0.9 | % |  | 1.6 | % |  | 2.3 | % |
| Dividend yield | — | % |  | — | % |  | — | % |
| Volatility(2) | 45.8 | % |  | 48.5 | % |  | 50.3 | % |
| Expected life(3) | 5.2 yrs |  |  | 5.2 yrs |  |  | 5.2 yrs |  |

[0000926326-13-000008:notes:160]
|  | Years Ended December 31, |
| Employee Stock Purchase Plan | 2012 |  | 2011 |  | 2010 |
| Risk-free interest rate(1) | 0.2 | % |  | 0.5 | % |  | 0.4 | % |
| Dividend yield | — | % |  | — | % |  | — | % |
| Volatility(2) | 38.5 | % |  | 40.2 | % |  | 48.5 | % |
| Expected life(3) | 0.5 - 2 yrs |  |  | 0.5 - 2 yrs |  |  | 0.5 - 2 yrs |  |

[0000926326-13-000008:notes:161]
_______________________________________________________________________________

[0000926326-13-000008:notes:162]
| (1) | The risk-free interest rate for both stock options and the ESPP is based on the zero-coupon U.S. Treasury rate curve in effect at the time of the option grant or at the beginning of the ESPP offering period. |

[0000926326-13-000008:notes:163]
| (2) | Expected volatility for both stock options and the ESPP reflects a combination of historical and market-based implied volatility consistent with ASC 718 and SEC Staff Accounting Bulletin 107. We determined that the combination of historical and market-based implied volatility provides a more accurate reflection of our market conditions and is more representative of future stock price trends than employing solely historical volatility. |

[0000926326-13-000008:notes:164]
| (3) | Represents the period of time that options granted are expected to be outstanding, which is derived from historical data on employee exercise and post-vesting employment termination behavior. |

[0000926326-13-000008:notes:165]
Share-Based Payment Award Activity

[0000926326-13-000008:notes:166]
A summary of option activity under the 2009 Plan for the years ended December 31, 2012, 2011 and 2010 is presented below:

[0000926326-13-000008:notes:167]
| Options: | Number of Shares |  | Weighted AverageExercise Price |
|  | (in thousands) |  |  |
| Outstanding at December 31, 2009 | 4,748 |  |  | $ | 12.61 |  |
| Granted | 666 |  |  | $ | 12.99 |  |
| Exercised | (431 | ) |  | $ | 8.46 |  |
| Expired | (164 | ) |  | $ | 16.50 |  |
| Forfeited | (79 | ) |  | $ | 14.80 |  |
| Outstanding at December 31, 2010 | 4,740 |  |  | $ | 12.86 |  |
| Granted | 494 |  |  | $ | 14.57 |  |
| Exercised | (413 | ) |  | $ | 8.30 |  |
| Expired | (86 | ) |  | $ | 13.59 |  |
| Forfeited | (42 | ) |  | $ | 20.76 |  |
| Outstanding at December 31, 2011 | 4,693 |  |  | $ | 13.36 |  |
| Granted | 645 |  |  | $ | 14.85 |  |
| Exercised | (669 | ) |  | $ | 8.65 |  |
| Expired | (84 | ) |  | $ | 14.02 |  |
| Forfeited | (115 | ) |  | $ | 21.44 |  |
| Outstanding at December 31, 2012 | 4,470 |  |  | $ | 14.06 |  |
| Vested and expected to vest at December 31, 2012 | 4,439 |  |  | $ | 14.06 |  |
| Exercisable at December 31, 2012 | 3,331 |  |  | $ | 13.98 |  |

[0000926326-13-000008:notes:168]
Outstanding options at December 31, 2012 had a weighted-average remaining contractual life of 5.3 years and an aggregate intrinsic value of $10.4 million. Vested and expected to vest options had a weighted-average remaining contractual life of 5.3 years and an aggregate intrinsic value of $10.4 million. Exercisable options at December 31, 2012 had a weighted-average remaining contractual life of 4.2 years and an aggregate intrinsic value of $9.3 million.

[0000926326-13-000008:notes:169]
The ranges of outstanding and exercisable options for equity share-based payment awards as of December 31, 2012 were as follows:

[0000926326-13-000008:notes:170]
| Range of Exercise Prices | NumberOutstanding |  | WeightedAverage ExercisePrice ofOutstandingOptions |  | NumberExercisable |  | WeightedAverage ExercisePrice ofExercisableOptions |
|  | (in thousands) |  |  |  | (in thousands) |  |  |
| $2.70 - $9.25 | 518 |  |  | $ | 7.46 |  |  | 508 |  |  | $ | 7.45 |  |
| $9.34- $10.58 | 587 |  |  | $ | 10.32 |  |  | 579 |  |  | $ | 10.33 |  |
| $10.60 - $11.58 | 476 |  |  | $ | 11.05 |  |  | 461 |  |  | $ | 11.06 |  |
| $11.66- $13.16 | 518 |  |  | $ | 12.61 |  |  | 413 |  |  | $ | 12.63 |  |
| $13.33 - $13.74 | 455 |  |  | $ | 13.63 |  |  | 103 |  |  | $ | 13.50 |  |
| $13.88 - $14.38 | 453 |  |  | $ | 14.18 |  |  | 168 |  |  | $ | 14.14 |  |
| $14.42 - $16.70 | 495 |  |  | $ | 15.66 |  |  | 157 |  |  | $ | 15.22 |  |
| $16.73 - $20.95 | 608 |  |  | $ | 19.76 |  |  | 582 |  |  | $ | 19.90 |  |
| $21.07 - $26.99 | 280 |  |  | $ | 22.88 |  |  | 280 |  |  | $ | 22.88 |  |
| $29.16 - $29.16 | 80 |  |  | $ | 29.16 |  |  | 80 |  |  | $ | 29.16 |  |
| $2.70 - $29.16 | 4,470 |  |  | $ | 14.06 |  |  | 3,331 |  |  | $ | 13.98 |  |

[0000926326-13-000008:notes:171]
As of December 31, 2012, we expect $6.6 million of total unrecognized compensation costs related to unvested options to be recognized over a weighted average period of 2.8 years. The weighted average fair value of options granted was $6.13, $6.47, and $6.13 during 2012, 2011 and 2010, respectively. The intrinsic value of options exercised during 2012, 2011 and 2010 was $2.8 million, $2.9 million and $2.1 million, respectively. The total fair value of shares vested during 2012, 2011 and 2010 was $3.0 million, $4.0 million, $4.9 million, respectively.

[0000926326-13-000008:notes:172]
Restricted Stock and Restricted Stock Units

[0000926326-13-000008:notes:173]
A summary of activity of restricted stock granted under the 2009 Plan as of December 31, 2012 is presented below:

[0000926326-13-000008:notes:174]
|  | Shares ofRestricted Stock |  | Weighted-Average GrantDate Fair Value Per Share |
|  | (in thousands) |  |  |
| Nonvested at December 31, 2009 | 52 |  |  | $ | 9.25 |  |
| Granted | 79 |  |  | $ | 12.91 |  |
| Vested | (54 | ) |  | $ | 9.40 |  |
| Nonvested at December 31, 2010 | 77 |  |  | $ | 12.91 |  |
| Granted | 68 |  |  | $ | 14.71 |  |
| Vested | (77 | ) |  | $ | 12.91 |  |
| Nonvested at December 31, 2011 | 68 |  |  | $ | 14.71 |  |
| Granted | 67 |  |  | $ | 14.19 |  |
| Vested | (78 | ) |  | $ | 14.64 |  |
| Nonvested at December 31, 2012 | 58 |  |  | $ | 14.19 |  |

[0000926326-13-000008:notes:175]
The fair value of restricted stock is the product of the number of shares granted and the closing market price of our common stock on the grant date. The total fair value of restricted stock grants vested in 2012, 2011 and 2010 was $1.1 million, $1.1 million and $0.7 million, respectively. Our unrecognized compensation cost related to nonvested restricted stock is approximately $0.3 million and is expected to be recognized over a weighted average period of 0.4 years.

[0000926326-13-000008:notes:176]
A summary of activity of restricted stock units ("RSUs") granted under the 2009 Plan as of December 31, 2012 is presented below:

[0000926326-13-000008:notes:177]
|  | Restricted Stock Units |  | Weighted-Average GrantDate Fair Value |
|  | (in thousands) |  |  |
| Nonvested at December 31, 2009 | 264 |  |  | $ | 14.32 |  |
| Granted | 195 |  |  | $ | 12.83 |  |
| Vested | (140 | ) |  | $ | 15.10 |  |
| Forfeited | (11 | ) |  | $ | 15.34 |  |
| Nonvested at December 31, 2010 | 308 |  |  | $ | 12.98 |  |
| Granted | 145 |  |  | $ | 14.39 |  |
| Vested | (152 | ) |  | $ | 14.26 |  |
| Forfeited | (14 | ) |  | $ | 12.82 |  |
| Nonvested at December 31, 2011 | 287 |  |  | $ | 13.03 |  |
| Granted | 274 |  |  | $ | 14.58 |  |
| Vested | (153 | ) |  | $ | 12.90 |  |
| Forfeited | (19 | ) |  | $ | 14.55 |  |
| Nonvested at December 31, 2012 | 389 |  |  | $ | 14.09 |  |

[0000926326-13-000008:notes:178]
The fair value of RSUs is the product of the number of shares granted and the closing market price of our common stock on the grant date. The total fair value of RSUs vested in 2012, 2011 and 2010 was $2.3 million, $2.4 million and $1.9 million, respectively. Expected future compensation expense relating to RSUs outstanding on December 31, 2012 is $5.1 million over a weighted- average period of 2.2 years.

[0000926326-13-000008:notes:179]
Performance-Based Restricted Stock Units

[0000926326-13-000008:notes:180]
In 2011, we began incorporating performance-based restricted stock units ("PSUs") as an element of our executive compensation plans. For 2011, we granted 100,000 PSUs; however, pursuant to their terms, 120,000 PSUs ultimately become eligible for vesting upon the achievement of a certain level of shareholder return for 2011 as described below. In 2012, we granted 125,000 PSUs of which 62,500 became eligible for vesting upon the achievement of a certain level of shareholder return for 2012 as described below.

[0000926326-13-000008:notes:181]
Our unrecognized compensation cost related to non-vested performance-based restricted stock units at December 31, 2012 was approximately $0.8 million and is expected to be recognized over a weighted-average period of 1.3 years. For the year ended December 31, 2012, we recognized $1.0 million of compensation expense for the performance-based restricted stock units. For the year ended December 31, 2011, we recognized $0.6 million of compensation expense for the performance-based restricted stock units.

[0000926326-13-000008:notes:182]
The accounting guidance for awards with market conditions differs from that for awards with service conditions only or service and performance conditions. Because the grant date fair value of an award containing market conditions is calculated as the expected value, averaging over all possible outcomes, the measured expense is amortized over the service period, regardless of whether the market condition is ever actually met.

[0000926326-13-000008:notes:183]
The fair value of a PSU award is the average of trial-specific values of the award over each of one million Monte Carlo trials. Each trial-specific value is the market value of the award at the end of the one-year performance period discounted back to the grant date. The market value of the award for each trial at the end of the performance period is the product of (a) the per share value of Omnicell stock at the end of the performance period and (b) the number of shares that vest. The number of shares that vest at the end of the performance period depends on the percentile ranking of the total shareholder return for Omnicell stock over the performance period relative to the total shareholder return of each of the other companies in the NASDAQ Healthcare Index (the "Index") as shown in the tables below.

[0000926326-13-000008:notes:184]
Vesting for the PSU awards is based on the percentile placement of our total shareholder return among the companies listed in the Index and time-based vesting. We calculate total stockholder return based on the one year annualized rates of return reflecting price appreciation plus reinvestment of dividends. Stock price appreciation is calculated based on the average closing prices of the applicable company's common stock for the 20 trading days ending on the last trading day of the year prior to the date of grant as compared to the average closing prices for the 20 trading days ended on the last trading day of the year of grant.

[0000926326-13-000008:notes:185]
The following table shows the percent of PSUs granted in 2011 and eligible for further time-based vesting based on our percentile placement:

[0000926326-13-000008:notes:186]
| Percentile Placement of Our Total Shareholder Return |  | % of PSUs Eligible for Time-Based Vesting |
| Below the 35th percentile |  | —% |
| At least the 35th percentile, but below the 50th percentile |  | 50% |
| At least the 50th percentile, but below the 65th percentile |  | 100% |
| At least the 65th percentile, but below the 75th percentile (1) |  | 110% to 119% |
| At or above the 75th percentile |  | 120% |

[0000926326-13-000008:notes:187]
(1)               The actual percentage of PSUs eligible for further time-based vesting is based on straight-line interpolation, where, for example, if the ranking is the 70th percentile, then the vesting percentage is 115%.

[0000926326-13-000008:notes:188]
On January 17, 2012, the Compensation Committee of our Board of Directors confirmed 76.3% as the percentile rank of Omnicell’s 2011 total stockholder return. This resulted in 120% of the 2011 PSU awards, or 120,000 shares, becoming eligible for further time-based vesting. The eligible PSU awards will vest as follows: 25% of the eligible awards for the first year vested immediately on January 17, 2012 with the remaining eligible awards vesting in equal increments, semi-annually, over the subsequent three year period beginning on June 15th and December 15th of the year after the date of grant and each subsequent year. Vesting is contingent upon continued service.

[0000926326-13-000008:notes:189]
The following table shows the percent of PSUs granted in 2012 eligible for further time-based vesting based on our percentile placement:

[0000926326-13-000008:notes:190]
| Percentile Placement of Our Total Shareholder Return | % of PSUs Eligible for Time-Based Vesting |
| Below the 35th percentile | —% |
| At least the 35th percentile, but below the 50th percentile | 50% |
| At least the 50th percentile | 100% |

[0000926326-13-000008:notes:191]
On January 22, 2013, the Compensation Committee of our Board of Directors confirmed 35.3% as the percentile rank of Omnicell's 2012 total stockholder return. This resulted in 50% of the 2012 PSU awards, or 62,500 shares, as eligible for further time-based vesting. The eligible performance-based restricted stock unit awards will vest as follows: 25% of the eligible shares vested immediately on January 22, 2013 with the remaining eligible awards vesting in equal increments, semi-annually, over the subsequent three year period beginning on June 15th and December 15th of the year after the date of grant and each subsequent year. Vesting is contingent upon continued service.

[0000926326-13-000008:notes:192]
For the year ended December 31, 2012, in addition to the 125,000 PSUs granted in 2012, an additional 10,000  PSUs were deemed granted and vested as a result of Omnicell’s 2011 total stockholder return which caused 120% of the 2011 PSUs to become eligible for further time-based vesting.

[0000926326-13-000008:notes:193]
A summary of activity of the PSUs for the years ended December 31, 2012 and 2011 is presented below:

[0000926326-13-000008:notes:194]
| Performance-based Stock Units | Number of Units |  | Weighted-AverageGrant DateFair Value PerUnit |
|  | (in thousands) |  |  |
| Non-vested, December 31, 2010 | — |  |  | $ | — |  |
| Granted | 100 |  |  | $ | 11.15 |  |
| Vested | — |  |  | $ | — |  |
| Forfeited | — |  |  | $ | — |  |
| Non-vested, December 31, 2011 | 100 |  |  | $ | 11.15 |  |
| Granted | 135 |  |  | $ | 10.94 |  |
| Vested | (60 | ) |  | $ | 11.15 |  |
| Forfeited | — |  |  | $ | — |  |
| Non-vested, December 31, 2012 | 175 |  |  | $ | 11.00 |  |


## us-gaap:EarningsPerSharePolicyTextBlock

[0000926326-13-000008:notes:195]
Basic net income per share is computed by dividing net income for the period by the weighted average number of shares outstanding during the period, less shares subject to repurchase. Diluted net income per share is computed by dividing net income for the period by the weighted average number of shares, less shares subject to repurchase, plus, if dilutive, potential common stock outstanding during the period. Potential common stock includes the effect of outstanding dilutive stock options, restricted stock awards and restricted stock units computed using the treasury stock method.


## us-gaap:EarningsPerShareTextBlock

[0000926326-13-000008:notes:196]
Net Income Per Share

[0000926326-13-000008:notes:197]
Basic net income per share is computed by dividing net income for the period by the weighted average number of shares outstanding during the period, less shares subject to repurchase. Diluted net income per share is computed by dividing net income for the period by the weighted average number of shares, less shares subject to repurchase, plus, if dilutive, potential common stock outstanding during the period. Potential common stock includes the effect of outstanding dilutive stock options, restricted stock awards and restricted stock units computed using the treasury stock method.  Since their impact is anti-dilutive, the total number of shares excluded from the calculations of diluted net income per share for the years ended December 31, 2012, 2011 and 2010 were 2,149,044 shares, 1,833,574 shares and 2,005,642 shares, respectively.

[0000926326-13-000008:notes:198]
The calculation of basic and diluted net income per share is as follows (in thousands, except per share amounts):

[0000926326-13-000008:notes:199]
|  | Years Ended December 31 |  |
|  | 2012 |  | 2011 |  | 2010 |  |
| Basic: |  |  |  |  |  |  |  |  |  |
| Net income | $ | 16,178 |  |  | $ | 10,389 |  |  | $ | 4,892 |  |  |
| Weighted average shares outstanding — basic | 33,307 |  |  | 33,123 |  |  | 32,651 |  |  |
| Net income per share — basic | $ | 0.49 |  |  | $ | 0.31 |  |  | $ | 0.15 |  |  |
| Diluted: |  |  |  |  |  |  |  |  |  |
| Net income | $ | 16,178 |  |  | $ | 10,389 |  |  | $ | 4,892 |  |  |
| Weighted average shares outstanding — basic | 33,307 |  |  | 33,123 |  |  | 32,651 |  |  |
| Add: Dilutive effect of employee stock plans | 906 |  |  | 980 |  |  | 862 |  |  |
| Weighted average shares outstanding — diluted | 34,213 |  |  | 34,103 |  |  | 33,513 |  |  |
| Net income per share — diluted | $ | 0.47 |  |  | $ | 0.30 |  |  | $ | 0.15 |  |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000926326-13-000008:notes:200]
Goodwill and Other Intangible Assets

[0000926326-13-000008:notes:201]
Under ASC 350, Intangibles—Goodwill and Other, goodwill is not subject to amortization. We evaluate goodwill for impairment at least annually or more frequently if events and changes in circumstances suggest that the carrying amount may not be recoverable. During 2012, we adopted the qualitative approach for assessing goodwill impairment. For additional details on our policy regarding the valuation and impairment of goodwill, other intangible assets and other long lived assets, see Note 1, "Organization and Summary of Significant Accounting Policies" to the Notes to Consolidated Financial Statements included elsewhere in this Annual Report on Form 10-K.

[0000926326-13-000008:notes:202]
Activity in goodwill by reporting units, which are the same as our operating segments, for the year ended December 31, 2012 consists of the following (in thousands):

[0000926326-13-000008:notes:203]
|  | Goodwill at December 31, 2011 |  | Goodwill acquired |  | Goodwill at December 31, 2012 |
| Reporting units: |  |  |  |  |  |
| Acute Care | $ | 28,543 |  |  | $ | — |  |  | $ | 28,543 |  |
| Non-Acute Care | — |  |  | 82,864 |  |  | 82,864 |  |
| Total | $ | 28,543 |  |  | $ | 82,864 |  |  | $ | 111,407 |  |

[0000926326-13-000008:notes:204]
The goodwill acquired reflects the May 2012 acquisition of MedPak by Omnicell. MedPak is the parent company of MTS, a worldwide provider of medication adherence packaging systems. The acquired goodwill was assigned to the Non-Acute Care segment, created as a result of the MTS acquisition.

[0000926326-13-000008:notes:205]
There were no indefinite-life intangibles at either December 31, 2012 or December 31, 2011. Finite-life intangible assets at these dates consist of the following (in thousands):

[0000926326-13-000008:notes:206]
|  | December 31, 2012 |  | December 31, 2011 |  |  |
|  | Gross |  |  |  | Net |  | Gross |  |  |  | Net |  |  |
|  | CarryingAmount |  | AccumulatedAmortization |  | CarryingAmount |  | CarryingAmount |  | AccumulatedAmortization |  | CarryingAmount |  | AmortizationLife |
| Finite-lived intangibles: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships | $ | 54,730 |  |  | $ | 3,081 |  |  | $ | 51,649 |  |  | $ | 4,230 |  |  | $ | 1,591 |  |  | $ | 2,639 |  |  | 5-30 years |
| Acquired technology | 27,580 |  |  | 1,128 |  |  | 26,452 |  |  | 980 |  |  | 175 |  |  | 805 |  |  | 3-20 years |
| Patents | 1,217 |  |  | 259 |  |  | 958 |  |  | 889 |  |  | 190 |  |  | 699 |  |  | 20 years |
| Trade name | 6,890 |  |  | 414 |  |  | 6,476 |  |  | 90 |  |  | 37 |  |  | 53 |  |  | 3-12 years |
| Non-compete agreements | 60 |  |  | 45 |  |  | 15 |  |  | 60 |  |  | 25 |  |  | 35 |  |  | 3 years |
| Total finite-lived intangibles | $ | 90,477 |  |  | $ | 4,927 |  |  | $ | 85,550 |  |  | $ | 6,249 |  |  | $ | 2,018 |  |  | $ | 4,231 |  |  |  |

[0000926326-13-000008:notes:207]
During 2012, 2011 and 2010, we capitalized third-party costs associated with internally-developed patent costs of $0.4 million, $0.2 million and $0.2 million, respectively.

[0000926326-13-000008:notes:208]
Amortization expense of other intangible assets totaled $2.9 million, $0.7 million and $2.2 million for the years ended December 31, 2012, 2011 and 2010, respectively. The amortization of acquired technology is included within product cost of sales; other acquired intangibles are usually amortized within selling, general and administrative expenses.

[0000926326-13-000008:notes:209]
Estimated annual expected amortization expense of the finite-lived intangible assets at December 31, 2012 was as follows (in thousands):

[0000926326-13-000008:notes:210]
| 2013 | $ | 4,265 |  |
| 2014 | 4,224 |  |
| 2015 | 4,200 |  |
| 2016 | 3,850 |  |
| 2017 | 3,814 |  |
| Thereafter | 65,197 |  |
| Total | $ | 85,550 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000926326-13-000008:notes:211]
Income Taxes

[0000926326-13-000008:notes:212]
The following is a geographical breakdown of income before the provision for income taxes (in thousands):

[0000926326-13-000008:notes:213]
|  | Years Ended December 31, |
|  | 2012 |  | 2011 |  | 2010 |
| Domestic | $ | 25,794 |  |  | $ | 16,177 |  |  | $ | 9,551 |  |
| Foreign | 1,281 |  |  | (88 | ) |  | 406 |  |
| Total income before provision for income taxes | $ | 27,075 |  |  | $ | 16,089 |  |  | $ | 9,957 |  |

[0000926326-13-000008:notes:214]
The provision for income taxes consists of the following (in thousands):

[0000926326-13-000008:notes:215]
|  | Years Ended December 31, |
|  | 2012 |  | 2011 |  | 2010 |
| Current: |  |  |  |  |  |
| Federal | $ | 7,181 |  |  | $ | 4,285 |  |  | $ | 196 |  |
| State | 1,006 |  |  | 896 |  |  | 207 |  |
| Foreign | 154 |  |  | (70 | ) |  | 368 |  |
| Total current | 8,341 |  |  | 5,111 |  |  | 771 |  |
| Deferred: |  |  |  |  |  |
| Federal | 2,169 |  |  | 1,116 |  |  | 3,757 |  |
| State | 651 |  |  | (527 | ) |  | 473 |  |
| Foreign | (264 | ) |  | — |  |  | 64 |  |
| Total deferred | 2,556 |  |  | 589 |  |  | 4,294 |  |
| Total provision for income taxes | $ | 10,897 |  |  | $ | 5,700 |  |  | $ | 5,065 |  |

[0000926326-13-000008:notes:216]
The provision for income taxes differs from the amount computed by applying the statutory federal tax rate as follows (in thousands):

[0000926326-13-000008:notes:217]
|  | Years Ended December 31, |
|  | 2012 |  | 2011 |  | 2010 |
| U.S. federal tax provision at statutory rate | $ | 9,476 |  |  | $ | 5,631 |  |  | $ | 3,485 |  |
| State taxes | 1,077 |  |  | 240 |  |  | 543 |  |
| Non-deductible expenses | 530 |  |  | 481 |  |  | 350 |  |
| Acquisition costs | 431 |  |  | — |  |  | — |  |
| Share-based compensation expense | 403 |  |  | 443 |  |  | 244 |  |
| Research tax credits | — |  |  | (755 | ) |  | (137 | ) |
| Repatriation of foreign earnings | — |  |  | (77 | ) |  | 560 |  |
| Domestic production deduction | (601 | ) |  | (271 | ) |  | — |  |
| Other | (419 | ) |  | 8 |  |  | 20 |  |
| Total | $ | 10,897 |  |  | $ | 5,700 |  |  | $ | 5,065 |  |

[0000926326-13-000008:notes:218]
Significant components of our deferred tax assets (liabilities) are as follows (in thousands):

[0000926326-13-000008:notes:219]
|  | December 31, |
|  | 2012 |  | 2011 |
| Deferred tax assets (liabilities): |  |  |  |
| Tax credit carry forwards | $ | 2,990 |  |  | $ | 3,066 |  |
| Inventory related items | 2,900 |  |  | 3,032 |  |
| Deferred revenue | 11,497 |  |  | 11,979 |  |
| Stock compensation | 9,331 |  |  | 9,187 |  |
| Loss carry forwards | 53 |  |  | — |  |
| Other, net | 69 |  |  | 82 |  |
| Subtotal | 26,840 |  |  | 27,346 |  |
| Less: valuation allowance | (39 | ) |  | — |  |
| Total net deferred tax assets | 26,801 |  |  | 27,346 |  |
| Reserves and accruals | (573 | ) |  | (1,277 | ) |
| Depreciation and amortization | (39,840 | ) |  | (4,040 | ) |
| Total deferred tax assets (liabilities) | (40,413 | ) |  | (5,317 | ) |
| Net deferred tax assets (liabilities) | $ | (13,612 | ) |  | $ | 22,029 |  |

[0000926326-13-000008:notes:220]
Deferred income tax assets (liabilities) are provided for temporary differences that will result in future tax deductions or future taxable income, as well as the future benefit of tax credit carry forwards. In assessing our ability to realize the deferred tax assets, management considers whether it is more likely than not that some portion or all of the deferred tax assets will be realized by assessing the available positive and negative evidence to estimate if sufficient future taxable income will be generated in order to realize the existing deferred tax assets. On the basis of this evaluation, as of December 31, 2012, management concluded that deferred tax assets are more likely than not to be realized, and therefore no material valuation allowances have been recorded in any jurisdiction.

[0000926326-13-000008:notes:221]
In 2012, we recorded approximately $33.1 million of additional net deferred tax liabilities related to our acquisition of MTS during the second quarter. This amount was primarily comprised of increased book basis in fixed assets and intangible assets as a result of the acquisition with no corresponding increase in tax basis.

[0000926326-13-000008:notes:222]
As of December 31, 2012, state net operating loss carry forwards available for income tax purposes is approximately $1.5 million. These net operating losses begin to expire in the year 2026. For income tax purposes, we have federal and California research tax credit carry forwards of approximately $3.0 million and $6.7 million, respectively. Federal research tax credit carry forwards will expire in years 2022 through 2031. California credits are available indefinitely to reduce cash taxes otherwise payable. Pursuant to the requirements of ASC 718, we do not include unrealized stock option attributes as components of our gross deferred tax assets. The tax effected amounts of gross unrealized net operating loss and business tax credit carry forwards excluded under ASC 718 for the year ended December 31, 2012 are approximately $3.2 million, which will result in increases to additional paid in capital if and when realized as a reduction in income taxes otherwise paid.

[0000926326-13-000008:notes:223]
We file income tax returns in the U.S. Federal jurisdiction, various states and foreign jurisdictions. In the normal course of business, we are subject to examination by taxing authorities, including major jurisdictions such as the United States, California, India, and the United Kingdom. We have recently concluded audits by the Internal Revenue Service and California Franchise Tax Board for years 2008 and 2009. However, since we have tax attribute carry forwards from these years that could be subject to adjustment, if and when utilized, federal and California remain open from 1996 and 1992, respectively. The India statute of limitations remains open for years 2007 through 2011.

[0000926326-13-000008:notes:224]
We have not provided U.S. income taxes and foreign withholding taxes on approximately $2.2 million of undistributed earnings of its foreign subsidiaries as of December 31, 2012 because we intend to permanently reinvest such earnings outside the U.S. If we expect to distribute those earnings in the form of dividends or otherwise, we would be subject to U.S. federal and state income taxes, which may be reduced by any foreign income taxes previously paid on these earnings, and would then be recorded as a component of income tax expense. It is not practicable for us to estimate the amount of deferred tax liability related to our investments in these foreign subsidiaries.

[0000926326-13-000008:notes:225]
The aggregate changes in the balance of gross unrecognized tax benefits, which excludes interest and penalties, for the three years ended December 31, 2012 is as follows (in thousands):

[0000926326-13-000008:notes:226]
| Balance as of December 31, 2009 | $ | 4,295 |  |
| Increases related to tax positions taken during a prior period | 795 |  |
| Decreases related to tax positions taken during the prior period | (80 | ) |
| Increases related to tax positions taken during the current period | 421 |  |
| Balance as of December 31, 2010 | 5,431 |  |
| Increases related to tax positions taken during a prior period | — |  |
| Decreases related to tax positions taken during the prior period | (88 | ) |
| Increases related to tax positions taken during the current period | 453 |  |
| Balance as of December 31, 2011 | 5,796 |  |
| Increases related to tax positions taken during a prior period | 43 |  |
| Increases related to tax positions related to MTS | 1,066 |
| Decreases related to tax positions taken during the prior period | — |  |
| Increases related to tax positions taken during the current period | 422 |  |
| Decreases related to settlements | (33 | ) |
| Decreases related to expiration of statute of limitations | (379 | ) |
| Balance as of December 31, 2012 | $ | 6,915 |  |

[0000926326-13-000008:notes:227]
As of December 31, 2012, the total amount of gross unrecognized tax benefits, if realized, would affect our tax expense by approximately $6.1 million. We recognize interest and/or penalties related to uncertain tax positions in operating expenses, which for 2012 was immaterial. We do not believe there will be any material changes in our unrecognized tax positions over the next twelve months.


## us-gaap:InventoryDisclosureTextBlock

[0000926326-13-000008:notes:228]
Inventories

[0000926326-13-000008:notes:229]
Inventories consist of the following (in thousands):

[0000926326-13-000008:notes:230]
|  | December 31, 2012 |  | December 31, 2011 |
| Raw materials | $ | 9,994 |  |  | $ | 7,666 |  |
| Work in process | 385 |  |  | 14 |  |
| Finished goods | 16,524 |  |  | 10,427 |  |
| Total | $ | 26,903 |  |  | $ | 18,107 |  |


## us-gaap:LegalMattersAndContingenciesTextBlock

[0000926326-13-000008:notes:231]
Contingencies

[0000926326-13-000008:notes:232]
Legal Proceedings

[0000926326-13-000008:notes:233]
We may from time to time become involved in certain legal proceedings in the ordinary course of business. We are not a party to any legal proceedings that management believes may have a material impact on Omnicell’s financial position or results of operations.

[0000926326-13-000008:notes:234]
Guarantees

[0000926326-13-000008:notes:235]
As permitted under Delaware law and our certificate of incorporation and bylaws, we have agreed to indemnify our directors and officers against certain losses that they may suffer by reason of the fact that such persons are, were or become our directors or officers. The term of the indemnification period is for the director’s or officer’s lifetime and there is no limit on the potential amount of future payments that we could be required to make under these indemnification agreements. We have purchased a directors’ and officers’ liability insurance policy that may enable us to recover a portion of any future payments that we may be required to make under these indemnification agreements. Assuming the applicability of coverage and the willingness of the insurer to assume coverage and subject to certain retention, loss limits and other policy provisions, we believe it is unlikely that we will be required to pay any material amounts pursuant to these indemnification obligations. However, no assurances can be given that the insurers will not attempt to dispute the validity, applicability or amount of coverage without expensive and time-consuming litigation against the insurers.

[0000926326-13-000008:notes:236]
Additionally, we undertake indemnification obligations in our ordinary course of business in connection with, among other things, the licensing of our products and the provision of our support services. In the ordinary course of our business, we have in the past and may in the future agree to indemnify another party, generally our business affiliates or customers, against certain losses suffered or incurred by the indemnified party in connection with various types of claims, which may include, without limitation, claims of intellectual property infringement, certain tax liabilities, our gross negligence or intentional acts in the performance of support services and violations of laws. The term of these indemnification obligations is generally perpetual. In general, we attempt to limit the maximum potential amount of future payments that we may be required to make under these indemnification obligations to the amounts paid to us by a customer, but in some cases the obligation may not be so limited. In addition, we have in the past and may in the future warrant to our customers that our products will conform to functional specifications for a limited period of time following the date of installation (generally not exceeding 30 days) or that our software media is free from material defects. Sales contracts for certain of our medication packaging systems often include limited warranties for up to six months, but the periodic activity and ending warranty balances we record have historically been immaterial.

[0000926326-13-000008:notes:237]
From time to time, we may also warrant that our professional services will be performed in a good and workmanlike manner or in a professional manner consistent with industry standards. We generally seek to disclaim most warranties, including any implied or statutory warranties such as warranties of merchantability, fitness for a particular purpose, title, quality and non-infringement, as well as any liability with respect to incidental, consequential, special, exemplary, punitive or similar damages. In some states, such disclaimers may not be enforceable. If necessary, we would provide for the estimated cost of product and service warranties based on specific warranty claims and claim history. We have not been subject to any significant claims for such losses and have not incurred any material costs in defending or settling claims related to these indemnification obligations. Accordingly, we believe it is unlikely that we will be required to pay any material amounts pursuant to these indemnification obligations or potential warranty claims and, therefore, no material liabilities have been recorded for such indemnification obligations as of December 31, 2012 or December 31, 2011.


## us-gaap:OtherAssetsDisclosureTextBlock

[0000926326-13-000008:notes:238]
Other Assets


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000926326-13-000008:notes:239]
Property and Equipment

[0000926326-13-000008:notes:240]
Property and equipment consist of the following (in thousands):

[0000926326-13-000008:notes:241]
|  | December 31, 2012 |  | December 31, 2011 |
| Equipment | $ | 32,528 |  |  | $ | 25,101 |  |
| Furniture and fixtures | 5,126 |  |  | 1,811 |  |
| Leasehold improvements | 6,992 |  |  | 3,692 |  |
| Purchased software | 19,870 |  |  | 20,641 |  |
| Capital in process | 2,693 |  |  | 2,283 |  |
|  | 67,209 |  |  | 53,528 |  |
| Accumulated depreciation and amortization | (33,102 | ) |  | (36,222 | ) |
| Property and equipment, net | $ | 34,107 |  |  | $ | 17,306 |  |

[0000926326-13-000008:notes:242]
Depreciation and amortization of property and equipment was approximately $8.0 million, $5.7 million and $5.6 million for the years ended December 31, 2012, 2011 and 2010, respectively.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0000926326-13-000008:notes:243]
Depreciation and amortization of property and equipment are provided over their estimated useful lives, using the straight-line method, as follows:


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0000926326-13-000008:notes:244]
For the years ended December 31, 2012, 2011 and 2010 the contributions of our segments to net revenues and income from operations, and the reconciliation to total net income, were as follows (amounts in thousands):

[0000926326-13-000008:notes:245]
|  | December 31, |  | December 31, |  | December 31, |
|  | 2012 |  | 2011 |  | 2010 |
|  | Acute Care |  | Non-Acute Care (1) |  | Total |  | Acute Care |  | Total |  | Acute Care |  | Total |
| Net revenues from external customers | $ | 260,160 |  |  | $ | 53,867 |  |  | $ | 314,027 |  |  | $ | 245,535 |  |  | $ | 245,535 |  |  | $ | 222,407 |  |  | $ | 222,407 |  |
| Cost of revenues | 111,599 |  |  | 31,840 |  |  | 143,439 |  |  | 109,751 |  |  | 109,751 |  |  | 104,490 |  |  | 104,490 |  |
| Gross profit | $ | 148,561 |  |  | $ | 22,027 |  |  | $ | 170,588 |  |  | $ | 135,784 |  |  | $ | 135,784 |  |  | $ | 117,917 |  |  | $ | 117,917 |  |
| Gross margin % | 57.1 | % |  | 40.9 | % |  | 54.3 | % |  | 55.3 | % |  | 55.3 | % |  | 53.0 | % |  | 53.0 | % |
| Operating expenses | 127,467 |  |  | 15,995 |  |  | 143,462 |  |  | 119,562 |  |  | 119,562 |  |  | 108,391 |  |  | 108,391 |  |
| Income from operations | $ | 21,094 |  |  | $ | 6,032 |  |  | $ | 27,126 |  |  | $ | 16,222 |  |  | $ | 16,222 |  |  | $ | 9,526 |  |  | $ | 9,526 |  |
| Operating margin % | 8.1 | % |  | 11.2 | % |  | 8.6 | % |  | 6.6 | % |  | 6.6 | % |  | 4.3 | % |  | 4.3 | % |
| Interest and other income (expense), net |  |  |  |  | (51 | ) |  |  |  | (133 | ) |  |  |  | 431 |  |
| Income before provision for income taxes |  |  |  |  | 27,075 |  |  |  |  | 16,089 |  |  |  |  | 9,957 |  |
| Provision for income taxes |  |  |  |  | 10,897 |  |  |  |  | 5,700 |  |  |  |  | 5,065 |  |
| Net income |  |  |  |  | $ | 16,178 |  |  |  |  | $ | 10,389 |  |  |  |  | $ | 4,892 |  |
| (1) Non-Acute Care segment includes MTS results from May 21, 2012, the closing date of acquisition. |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000926326-13-000008:notes:246]
Facilities Closures and Restructuring

[0000926326-13-000008:notes:247]
During the third quarter of 2010, we implemented a restructuring plan to close our offices in Bangalore, India and The Woodlands, Texas, and consolidate the activities of these two locations with our Mountain View, California and Nashville, Tennessee operations in an effort to increase the efficiency of operations and promote collaboration among our engineering teams. We substantially completed this consolidation by September 30, 2010.

[0000926326-13-000008:notes:248]
The $1.2 million of third quarter 2010 restructuring/impairment charges were recorded primarily in operating expenses, consisting of $0.3 million in severance for departing employees, $0.5 million in relocation benefits for transferring employees, $0.2 million of exit and disposal costs related to the closed facilities, and $0.2 million for impairment of leasehold improvements and certain service tax reimbursement claims. The majority of the $0.2 million remaining restructuring accrued liabilities at December 31, 2010 were paid by December 31, 2011, except for the final legal/administrative exit costs for the India operation, which was less than $0.1 million. As of December 31, 2012, the closure of the office in Bangalore, India was substantially complete.


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0000926326-13-000008:notes:249]
Accrued liabilities consist of the following (in thousands):

[0000926326-13-000008:notes:250]
|  | December 31, 2012 |  | December 31, 2011 |
| Rebates and lease buyouts | $ | 3,179 |  |  | $ | 1,748 |  |
| Advance payments from customers | 2,829 |  |  | 3,390 |  |
| Accrued Group Purchasing Organization (GPO) fees | 2,278 |  |  | 2,437 |  |
| Technology license purchase obligation, current portion | 1,750 |  |  | — |  |
| Taxes payable | 555 |  |  | 925 |  |
| Other | 1,397 |  |  | 401 |  |
| Total | $ | 11,988 |  |  | $ | 8,901 |  |


## us-gaap:ScheduleOfCreditLossesRelatedToFinancingReceivablesNoncurrentTableTextBlock

[0000926326-13-000008:notes:251]
The following table summarizes the activity for the allowance for credit losses account for the investment in sales-type leases for the year ended December 31, 2012 (in thousands):

[0000926326-13-000008:notes:252]
|  | Year EndedDecember 31, 2012 |
| Allowance for credit losses, December 31, 2011 | $ | 284 |  |
| Current period provision (reversal) | 425 |  |
| Recoveries of amounts previously charged off | (102 | ) |
| Allowance for credit losses at December 31, 2012 | $ | 607 |  |


## us-gaap:ScheduleOfFutureMinimumLeasePaymentsForCapitalLeasesTableTextBlock

[0000926326-13-000008:notes:253]
The minimum lease payments under sales-type leases as of December 31, 2012 were as follows (in thousands):

[0000926326-13-000008:notes:254]
| 2013 | $ | 5,778 |  |  |
| 2014 | 5,034 |  |  |
| 2015 | 3,955 |  |  |
| 2016 | 2,712 |  |  |
| 2017 | 2,015 |  |  |
| Thereafter | 171 |  |  |
| Total | $ | 19,665 |  |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000926326-13-000008:notes:255]
At December 31, 2012, 2011, and 2010 segment assets, depreciation/amortization, and capital expenditures were as follows (amounts in thousands):

[0000926326-13-000008:notes:256]
|  | December 31, |  | December 31, |  | December 31, |
|  | 2012 |  | 2011 |  | 2010 |
|  | Acute Care |  | Non-Acute Care (1) |  | Total |  | Acute Care |  | Total |  | Acute Care |  | Total |
| Segment Assets | $ | 235,186 |  |  | $ | 206,633 |  |  | $ | 441,819 |  |  | $ | 363,849 |  |  | $ | 363,849 |  |  | $ | 343,224 |  |  | $ | 343,224 |  |
| Depreciation/Amortization | 9,657 |  |  | 3,668 |  |  | 13,325 |  |  | 7,983 |  |  | 7,983 |  |  | 8,619 |  |  | 8,619 |  |
| Capital Expenditures | $ | 13,889 |  |  | $ | 1,298 |  |  | $ | 15,187 |  |  | $ | 8,685 |  |  | $ | 8,685 |  |  | $ | 6,890 |  |  | $ | 6,890 |  |
| (1) Non-Acute Care segment includes MTS results from May 21, 2012, the date of acquisition. |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000926326-13-000008:notes:257]
| Allowances deducted from assets: |  | Balance atbeginning ofyear |  | Additionscharged tocosts andexpenses (2) |  | Charged(credited)to otheraccounts |  | Describecharged tootheraccounts |  | Deductions |  | Describedeductions |  | Balance atend of year |
| For the year ended December 31, 2010 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable(1) |  | $ | 868 |  |  | $ | 297 |  |  | $ | (484 | ) |  | (3) |  | $ | (184 | ) |  | (4) |  | $ | 497 |  |
| Investment in sales-type leases(1) |  | 570 |  |  | 3 |  |  | (40 | ) |  | (5) |  | (122 | ) |  | (4) |  | 411 |  |
| Total allowances deducted from assets |  | $ | 1,438 |  |  | $ | 300 |  |  | $ | (524 | ) |  |  |  | $ | (306 | ) |  |  |  | $ | 908 |  |
| For the year ended December 31, 2011 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable(1) |  | $ | 497 |  |  | $ | 63 |  |  | $ | (96 | ) |  | (3) |  | $ | (21 | ) |  | (4) |  | $ | 443 |  |
| Investment in sales-type leases (1) |  | 411 |  |  | — |  |  | (22 | ) |  | (5) |  | (105 | ) |  | (4) |  | 284 |  |
| Total allowances deducted from assets |  | $ | 908 |  |  | $ | 63 |  |  | $ | (118 | ) |  |  |  | $ | (126 | ) |  |  |  | $ | 727 |  |
| For the year ended December 31, 2012 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable(1) |  | $ | 443 |  |  | $ | 316 |  |  | $ | (57 | ) |  | (3) |  | $ | 20 |  |  | (4) |  | $ | 722 |  |
| Investment in sales-type leases (1) |  | 284 |  |  | 425 |  |  | — |  |  | (3) |  | (102 | ) |  | (4) |  | 607 |  |
| Total allowances deducted from assets |  | $ | 727 |  |  | $ | 741 |  |  | $ | (57 | ) |  |  |  | $ | (82 | ) |  |  |  | $ | 1,329 |  |

[0000926326-13-000008:notes:258]
| (1) | Allowance for doubtful accounts. |

[0000926326-13-000008:notes:259]
| (2) | Represents amounts charged to bad debt expense. |

[0000926326-13-000008:notes:260]
| (3) | Represents amounts credited to bad debt expense. |

[0000926326-13-000008:notes:261]
| (4) | Represents amounts written-off, net of recoveries. |

[0000926326-13-000008:notes:262]
| (5) | Represents amounts credited to bad debt expense and lease receivable adjustment. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000926326-13-000008:notes:263]
Segments

[0000926326-13-000008:notes:264]
Beginning with the acquisition of MTS, which was completed on May 21, 2012, we have organized our business into two operating business segments: Acute Care, which primarily includes products and services sold to hospital customers and Non-Acute Care, which primarily includes products and services sold to customers outside of hospital settings.

[0000926326-13-000008:notes:265]
Since 1992, Omnicell has provided automation and business information solutions to acute care hospitals. We have developed product solutions that help optimize various workflows utilized in hospitals. We have also developed sophisticated sales, installation, and service capabilities to serve the specific and special needs of the acute care environment in hospitals. As the acute care market evolves, we see opportunities to provide medication adherence solutions, which were added to our product line through the acquisition of MTS, to the acute care market as well. A portion of our organization structure and management processes will continue to be structured to optimize sales and service of solutions to the acute care market.

[0000926326-13-000008:notes:266]
Since 1984, MTS has provided medication adherence solutions to the non-acute care market. These solutions provide automated and semi-automated equipment to assist institutional and retail pharmacists in filling medication orders into blister cards, the primary method of medication control in non-acute care settings. Completing the product solution are the consumables used by institutional and retail pharmacists to make the medication adherence package. MTS has developed process manufacturing capabilities as well as sales capabilities to market medication adherence solutions to institutional and retail pharmacies. A portion of our organization structure and management processes will continue to be structured to optimize the product, sales, and service of solutions to the non-acute care market.

[0000926326-13-000008:notes:267]
During 2012, we realigned our management reporting structure to report sales of Omnicell's dispensing systems and other related business transactions into long-term care pharmacies and facilities. Accordingly, the operations of this portion of our activities are now being reflected as a part of the Non-Acute Care segment for the year ended December 31, 2012. The impact of this reporting structure change on the years ended December 31, 2011 and 2010 was immaterial to our overall reported results.

[0000926326-13-000008:notes:268]
We believe that legislative changes and economic pressures to manage costs will cause healthcare organizations to manage the health of patients across the continuum of care regardless of the setting in which the care is provided. We believe we have the capabilities and market position to provide the tools needed by our customers to manage medications across the continuum of care. But we also believe that the inherent differences between medication management workflows in acute care settings and non-acute care settings will cause our product solutions and marketing strategies to be managed separately for these two customer segments.

[0000926326-13-000008:notes:269]
For the year ended December 31, 2012, the Non-Acute Care cost of revenues included $1.7 million of acquisition-related charges primarily associated with the step-up to the estimated fair value of inventory acquired from MTS and consumed in the normal sales cycle of our business. The Non-Acute Care operating expenses included $0.9 million of acquisition-related charges primarily associated with severance expenses. For the year ended December 31, 2012, the Acute Care operating expenses included $2.3 million of acquisition-related charges for transaction costs, required to be expensed under ASC 805, Business Combinations.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000926326-13-000008:notes:270]
Stockholders’ Equity

[0000926326-13-000008:notes:271]
Treasury Stock

[0000926326-13-000008:notes:272]
2008 Stock Repurchase Program

[0000926326-13-000008:notes:273]
In February 2008, our Board of Directors authorized a stock repurchase program, (the "2008 Repurchase Program,") for the repurchase of up to $90.0 million of our common stock. The timing, price and volume of the repurchases have been based on market conditions, relevant securities laws and other factors.

[0000926326-13-000008:notes:274]
For the year ended December 31, 2012, we repurchased 898,168 shares at an average cost of $13.76 per share, including commissions under the 2008 Repurchase Program. For the year ended December 31, 2011, a total of 889,511 shares at an average cost of $14.13 per share were repurchased under the 2008 Repurchase Program. No shares were repurchased during the year ended December 31, 2010 under the 2008 Repurchase Program. All repurchased shares were recorded as treasury stock and were accounted for under the cost method. No repurchased shares have been retired. Additionally, for the years ended December 31, 2012, 2011 and 2010, we withheld 79,968 shares, 43,174 shares and 25,817 shares, respectively from employees to satisfy tax withholding obligations on the vesting of restricted stock.

[0000926326-13-000008:notes:275]
From the inception of the 2008 Repurchase Program in February 2008 through December 31, 2012, we repurchased a total of 5,853,975 shares at an average cost of $15.37 per share through open market purchases. As of December 31, 2012, we have completed the 2008 Repurchase Program having repurchased $90.0 million of our common stock.

[0000926326-13-000008:notes:276]
2012 Stock Repurchase Program

[0000926326-13-000008:notes:277]
On August 1, 2012, our Board of Directors established a new stock repurchase program (the "2012 Repurchase Program") authorizing share repurchases of up to $50.0 million of our common stock, with no termination date. The timing, price and volume of repurchases will be based on market conditions, relevant securities laws and other factors. The stock repurchases may be made from time to time on the open market, in privately negotiated transactions or pursuant to a Rule 10b-18 plan. The stock repurchase program does not obligate us to repurchase any specific number of shares, and Omnicell may terminate or suspend the repurchase program at any time

[0000926326-13-000008:notes:278]
Through December 31, 2012, we have not repurchased any shares through the 2012 Repurchase Program and therefore had $50.0 million of authorized funds to repurchase shares under the 2012 Repurchase Program.


## omcl:AccruedLiabilitiesTextBlock

[0000926326-13-000008:notes:279]
Accrued Liabilities


## omcl:NetInvestmentsInSalesTypeLeasesTextBlock

[0000926326-13-000008:notes:280]
Net Investment in Sales-Type Leases

[0000926326-13-000008:notes:281]
Our sales-type leases are for terms generally ranging up to five years. Sales-type lease receivables are collateralized by the underlying equipment. The components of our net investment in sales-type leases are as follows (in thousands):

[0000926326-13-000008:notes:282]
|  | December 31, 2012 |  | December 31, 2011 |
| Net minimum lease payments to be received | $ | 19,665 |  |  | $ | 15,063 |  |
| Less unearned interest income portion | 1,205 |  |  | 1,229 |  |
| Net investment in sales-type leases | 18,460 |  |  | 13,834 |  |
| Less current portion(1) | 5,232 |  |  | 5,049 |  |
| Non-current net investment in sales-type leases(2) | $ | 13,228 |  |  | $ | 8,785 |  |

[0000926326-13-000008:notes:283]
(1)     A component of other current assets. This amount is net of allowance for doubtful accounts of $0.5 million as of December 31, 2012 and $0.1 million as of December 31, 2011.

[0000926326-13-000008:notes:284]
(2)     Net of allowance for doubtful accounts of $0.1 million as of December 31, 2012 and $0.1 million as of December 31, 2011.
