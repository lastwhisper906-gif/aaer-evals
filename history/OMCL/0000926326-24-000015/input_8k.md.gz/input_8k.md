# OMCL 8-K — 0000926326-24-000012 filed 2024-05-02

## item codes, every 8-K on or before 2024-05-07

- 2024-05-02 0000926326-24-000012 — 2.02, 2.05, 9.01
- 2024-02-29 0001104659-24-029356 — 5.02
- 2024-02-08 0000926326-24-000005 — 2.02, 9.01
- 2024-01-11 0000926326-24-000002 — 5.02, 7.01, 8.01, 9.01
- 2023-11-09 0000926326-23-000043 — 5.02, 9.01
- 2023-11-02 0001104659-23-113604 — 2.02, 2.05, 7.01, 9.01
- 2023-10-16 0000926326-23-000039 — 1.01, 2.03, 9.01
- 2023-10-05 0000926326-23-000037 — 5.02, 9.01
- 2023-08-16 0000926326-23-000035 — 5.02
- 2023-08-10 0000926326-23-000033 — 5.02, 9.01
- 2023-08-03 0000926326-23-000029 — 5.02, 9.01
- 2023-08-01 0000926326-23-000027 — 2.02, 9.01
- 2023-07-11 0000926326-23-000025 — 5.02, 9.01
- 2023-06-26 0000926326-23-000022 — 5.02 — amendment of 0001104659-23-026700
- 2023-05-30 0001104659-23-066011 — 5.02, 9.01
- 2023-05-26 0000926326-23-000020 — 5.02, 5.07, 9.01
- 2023-05-15 0001104659-23-060768 — 5.02, 9.01
- 2023-05-02 0000926326-23-000011 — 2.02, 9.01
- 2023-04-03 0000926326-23-000009 — 1.01, 2.03, 9.01
- 2023-02-28 0001104659-23-026700 — 2.02, 2.05, 5.02, 9.01
- 2022-11-30 0000926326-22-000036 — 2.05
- 2022-11-02 0000926326-22-000031 — 2.02, 9.01
- 2022-10-21 0000926326-22-000029 — 5.03, 9.01
- 2022-09-20 0001104659-22-101566 — 7.01, 9.01
- 2022-09-20 0001104659-22-101360 — 7.01, 9.01
- 2022-08-04 0000926326-22-000025 — 2.02, 8.01, 9.01
- 2022-05-31 0000926326-22-000020 — 5.02, 5.07, 9.01
- 2022-05-24 0000926326-22-000016 — 5.02
- 2022-05-09 0000926326-22-000012 — 8.01
- 2022-04-28 0000926326-22-000009 — 2.02, 9.01
- 2022-03-01 0001104659-22-028681 — 5.02, 8.01, 9.01
- 2022-02-14 0000926326-22-000004 — 2.02, 9.01
- 2022-01-04 0000926326-22-000002 — 7.01, 9.01
- 2021-12-29 0001104659-21-154294 — 7.01, 9.01
- 2021-12-13 0000926326-21-000039 — 8.01
- 2021-12-02 0000926326-21-000037 — 7.01, 9.01
- 2021-11-02 0000926326-21-000031 — 2.02, 9.01
- 2021-09-09 0000926326-21-000028 — 7.01, 9.01
- 2021-07-29 0000926326-21-000024 — 2.02, 9.01
- 2021-07-26 0000926326-21-000022 — 7.01, 9.01
- 2021-07-12 0000926326-21-000019 — 5.02, 9.01
- 2021-05-28 0000926326-21-000015 — 5.07
- 2021-04-29 0000926326-21-000011 — 2.02, 9.01
- 2021-02-01 0000926326-21-000004 — 2.02, 9.01
- 2021-01-26 0000926326-21-000002 — 5.02
- 2021-01-13 0001104659-21-003672 — 2.02, 7.01, 9.01
- 2020-10-27 0000926326-20-000032 — 2.02, 9.01
- 2020-10-01 0000926326-20-000029 — 7.01, 9.01
- 2020-09-25 0001104659-20-108924 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2020-09-22 0001104659-20-107176 — 1.01, 8.01, 9.01
- 2020-08-12 0000926326-20-000027 — 2.03
- 2020-08-12 0000926326-20-000025 — 1.01, 5.03, 7.01, 9.01
- 2020-07-28 0000926326-20-000021 — 2.02, 9.01
- 2020-05-27 0000926326-20-000017 — 5.07
- 2020-05-07 0000926326-20-000012 — 2.02, 9.01
- 2020-02-18 0000926326-20-000007 — 5.02, 9.01
- 2020-02-13 0000926326-20-000005 — 8.01
- 2020-02-06 0000926326-20-000003 — 2.02, 9.01
- 2019-12-06 0001104659-19-070339 — 8.01
- 2019-11-18 0000926326-19-000035 — 1.01, 2.03, 9.01
- 2019-10-24 0000926326-19-000028 — 2.02, 9.01
- 2019-07-25 0000926326-19-000021 — 2.02, 9.01
- 2019-05-15 0000926326-19-000015 — 5.07
- 2019-04-25 0000926326-19-000011 — 2.02, 9.01
- 2019-03-08 0000926326-19-000009 — 5.02, 9.01
- 2019-02-19 0000926326-19-000005 — 5.02, 9.01
- 2019-02-07 0000926326-19-000003 — 2.02, 9.01
- 2018-10-25 0000926326-18-000028 — 2.02, 9.01
- 2018-09-14 0001104659-18-056929 — 5.02, 9.01
- 2018-07-26 0000926326-18-000022 — 2.02, 9.01
- 2018-06-06 0000926326-18-000019 — 5.02, 9.01
- 2018-05-16 0001104659-18-033801 — 5.07
- 2018-04-26 0000926326-18-000013 — 2.02, 9.01
- 2018-03-02 0001104659-18-014497 — 5.02
- 2018-02-08 0000926326-18-000007 — 5.02
- 2018-02-02 0000926326-18-000005 — 5.02
- 2018-02-01 0000926326-18-000003 — 2.02, 9.01
- 2017-12-26 0000926326-17-000041 — 1.01, 2.03, 9.01
- 2017-11-03 0001104659-17-066102 — 1.01, 8.01, 9.01
- 2017-10-26 0000926326-17-000035 — 2.02, 9.01
- 2017-08-03 0000926326-17-000028 — 5.07 — amendment, the index does not say of what
- 2017-07-27 0000926326-17-000026 — 2.02, 9.01
- 2017-07-25 0000926326-17-000023 — 5.02, 9.01
- 2017-05-24 0000926326-17-000019 — 5.07
- 2017-05-04 0001628280-17-004851 — 2.02, 9.01
- 2017-02-15 0000926326-17-000010 — 2.05
- 2017-02-15 0000926326-17-000008 — 2.02, 9.01
- 2017-02-13 0000926326-17-000002 — 5.02
- 2016-12-08 0001104659-16-161330 — 2.01, 2.03, 9.01
- 2016-12-06 0001104659-16-160709 — 7.01
- 2016-11-29 0001104659-16-159456 — 1.01, 7.01, 9.01
- 2016-10-27 0000926326-16-000075 — 2.02, 9.01
- 2016-10-07 0000926326-16-000072 — 5.02, 8.01
- 2016-08-05 0000926326-16-000068 — 8.01
- 2016-07-28 0000926326-16-000066 — 2.02, 9.01
- 2016-06-13 0001104659-16-126854 — 5.02
- 2016-05-25 0000926326-16-000060 — 5.07
- 2016-04-28 0000926326-16-000054 — 2.02, 9.01
- 2016-03-21 0001104659-16-106649 — 8.01, 9.01
- 2016-03-17 0000926326-16-000051 — 7.01, 9.01
- 2016-03-17 0000926326-16-000049 — 9.01 — amendment of 0000926326-16-000051
- 2016-02-10 0001104659-16-095486 — 5.02, 9.01
- 2016-02-04 0000926326-16-000041 — 2.02, 9.01
- 2016-01-06 0001104659-16-088299 — 1.01, 2.01, 2.03, 9.01
- 2015-12-10 0000926326-15-000038 — 8.01, 9.01
- 2015-10-29 0001104659-15-074138 — 1.01, 9.01
- 2015-10-29 0000926326-15-000031 — 2.02, 9.01
- 2015-08-20 0001104659-15-061135 — 5.02, 9.01
- 2015-07-30 0000926326-15-000024 — 2.02, 9.01
- 2015-05-22 0001104659-15-040440 — 5.07
- 2015-05-01 0001104659-15-032846 — 5.02
- 2015-05-01 0001104659-15-032844 — 7.01
- 2015-04-30 0000926326-15-000015 — 9.01
- 2015-04-22 0001104659-15-029356 — 8.01, 9.01
- 2015-03-20 0001104659-15-021435 — 3.01
- 2015-03-18 0001104659-15-020699 — 7.01
- 2015-03-17 0001104659-15-020483 — 8.01, 9.01
- 2015-03-02 0001104659-15-015802 — 1.01, 9.01
- 2015-02-12 0001104659-15-009234 — 5.02, 9.01
- 2015-02-03 0000926326-15-000003 — 9.01
- 2015-01-15 0001104659-15-002635 — 5.02
- 2014-11-07 0001104659-14-078398 — 1.01, 8.01, 9.01
- 2014-10-30 0000926326-14-000037 — 2.02, 9.01
- 2014-08-25 0001104659-14-062772 — 8.01, 9.01
- 2014-07-31 0000926326-14-000032 — 2.02, 9.01
- 2014-05-21 0001104659-14-040744 — 5.07
- 2014-05-01 0000926326-14-000008 — 2.02, 9.01
- 2014-04-08 0001104659-14-026441 — 4.01, 9.01
- 2014-04-02 0001104659-14-025179 — 5.02
- 2014-02-07 0001104659-14-007552 — 5.02, 9.01
- 2014-02-04 0001104659-14-006352 — 2.02, 9.01
- 2013-12-09 0001104659-13-088980 — 1.01, 9.01
- 2013-12-02 0001104659-13-087877 — 5.02
- 2013-10-31 0001104659-13-079660 — 2.02, 9.01
- 2013-09-26 0001104659-13-072435 — 1.01, 2.03, 9.01
- 2013-08-01 0001104659-13-058959 — 2.02, 9.01
- 2013-05-23 0001104659-13-044317 — 5.07
- 2013-05-02 0001104659-13-036605 — 2.02, 9.01
- 2013-03-11 0001104659-13-019143 — 8.01
- 2013-02-07 0001104659-13-008477 — 5.02, 9.01
- 2013-01-31 0001104659-13-006446 — 2.02, 9.01
- 2012-11-02 0001104659-12-073697 — 5.02
- 2012-10-25 0001104659-12-071211 — 2.02, 9.01
- 2012-08-06 0001104659-12-054635 — 8.01
- 2012-08-03 0001104659-12-054214 — 2.01, 9.01 — amendment of 0001104659-12-038888
- 2012-08-01 0001104659-12-053005 — 2.02, 9.01
- 2012-06-12 0001104659-12-042936 — 8.01, 9.01
- 2012-05-23 0001104659-12-039459 — 5.07
- 2012-05-22 0001104659-12-038888 — 2.01, 9.01
- 2012-05-02 0001104659-12-032048 — 2.02, 9.01
- 2012-05-02 0001104659-12-032036 — 1.01, 9.01
- 2012-04-04 0001104659-12-023883 — 5.02, 8.01
- 2012-03-20 0001104659-12-019462 — 1.01, 9.01
- 2012-02-13 0001104659-12-009353 — 5.02, 9.01
- 2012-01-26 0001104659-12-004244 — 2.02, 9.01
- 2011-10-27 0001104659-11-058464 — 2.02, 9.01
- 2011-10-25 0001104659-11-057721 — 1.01
- 2011-07-28 0001104659-11-041505 — 2.02, 9.01
- 2011-05-27 0001104659-11-032006 — 5.07
- 2011-05-02 0001104659-11-024908 — 2.02, 9.01
- 2011-04-15 0001104659-11-020407 — 5.02, 9.01 — amendment of 0001104659-11-005638
- 2011-02-08 0001104659-11-005638 — 5.02, 9.01
- 2011-01-27 0001104659-11-003419 — 2.02, 9.01
- 2010-12-22 0001104659-10-064003 — 5.02, 5.07, 9.01
- 2010-10-27 0001104659-10-054036 — 2.02, 9.01
- 2010-10-05 0001104659-10-051173 — 8.01
- 2010-07-22 0001104659-10-039126 — 2.02, 9.01
- 2010-07-09 0001104659-10-037594 — 2.05
- 2010-05-28 0001104659-10-031607 — 5.07
- 2010-04-26 0001104659-10-021797 — 2.02, 9.01
- 2010-03-17 0001104659-10-014849 — 5.02, 9.01
- 2010-02-08 0001104659-10-005457 — 5.02, 9.01
- 2010-01-28 0001104659-10-003627 — 2.02, 9.01
- 2009-10-22 0001104659-09-059972 — 2.02, 9.01
- 2009-07-23 0001104659-09-044508 — 2.02, 9.01
- 2009-05-20 0001104659-09-033938 — 5.02, 9.01
- 2009-04-30 0001104659-09-027707 — 2.02, 9.01
- 2009-03-10 0001104659-09-016178 — 5.02, 9.01
- 2009-02-09 0001104659-09-007692 — 5.02, 9.01
- 2009-01-29 0001104659-09-005022 — 2.02, 2.05, 9.01
- 2009-01-21 0001104659-09-003180 — 2.02, 8.01, 9.01
- 2009-01-06 0001104659-09-000625 — 5.02
- 2008-10-23 0001104659-08-065475 — 2.02, 9.01
- 2008-07-21 0001104659-08-046690 — 2.02, 9.01
- 2008-05-16 0001104659-08-034035 — 8.01, 9.01
- 2008-04-28 0001104659-08-027379 — 7.01, 9.01
- 2008-04-21 0001104659-08-025616 — 2.02, 9.01
- 2008-03-12 0001104659-08-016939 — 7.01, 9.01
- 2008-02-26 0001104659-08-012840 — 7.01, 9.01
- 2008-02-12 0001104659-08-009382 — 5.02, 9.01
- 2008-01-31 0001104659-08-006199 — 2.02, 9.01
- 2007-12-05 0001104659-07-087191 — 1.01, 9.01
- 2007-10-18 0001104659-07-075654 — 2.02, 9.01
- 2007-07-27 0001104659-07-056886 — 5.03, 9.01
- 2007-07-19 0001104659-07-054924 — 2.02, 9.01
- 2007-05-23 0001104659-07-042287 — 8.01, 9.01
- 2007-05-07 0001104659-07-036172 — 1.01, 5.02, 9.01
- 2007-04-24 0001104659-07-030578 — 2.02, 9.01 — amendment, the index does not say of what
- 2007-04-24 0001104659-07-030547 — 2.02, 9.01
- 2007-04-10 0001104659-07-027465 — 5.02, 9.01
- 2007-03-23 0001104659-07-021969 — 2.02, 4.02, 9.01
- 2007-01-30 0001104659-07-005772 — 2.02, 9.01
- 2007-01-09 0001104659-07-001600 — 5.02, 9.01
- 2006-10-30 0001104659-06-069612 — 1.01
- 2006-10-19 0001104659-06-067549 — 2.02, 9.01
- 2006-07-20 0001104659-06-048020 — 2.02, 4.02, 9.01
- 2006-05-17 0001104659-06-035522 — 1.01, 9.01 — amendment of 0001104659-05-011155
- 2006-05-09 0001104659-06-032706 — 1.01, 9.01
- 2006-04-25 0001104659-06-027438 — 2.02, 9.01
- 2006-04-04 0001104659-06-022204 — 1.01, 9.01
- 2006-03-15 0001104659-06-016861 — 1.01, 9.01
- 2006-01-30 0001104659-06-004749 — 2.02, 9.01
- 2006-01-24 0001104659-06-003504 — 1.01, 5.02, 9.01
- 2005-12-13 0001104659-05-060532 — 1.01, 9.01
- 2005-11-10 0001104659-05-054663 — 2.02, 9.01
- 2005-07-21 0001104659-05-033464 — 2.02, 9.01
- 2005-06-22 0001104659-05-029255 — 1.01
- 2005-05-16 0001104659-05-023473 — 2.02, 9.01 — amendment of 0001104659-05-018173
- 2005-05-16 0001104659-05-023471 — 2.02, 9.01 — amendment of 0001104659-05-017382
- 2005-05-10 0001104659-05-022127 — 1.01
- 2005-04-26 0001104659-05-018173 — 2.02, 9.01
- 2005-04-21 0001104659-05-017382 — 2.02, 9.01
- 2005-04-06 0001104659-05-015401 — 5.02
- 2005-03-15 0001104659-05-011155 — 1.01, 9.01
- 2005-03-08 0001104659-05-009975 — 1.01, 9.01
- 2005-02-03 0001104659-05-003943 — 2.02, 9.01
- 2005-01-13 0001104659-05-001314 — 5.02, 9.01
- 2004-10-21 0001104659-04-031413 — 2.02, 9.01
- 2004-07-22 0001104659-04-020572 — 12, 7
- 2004-04-14 0001104659-04-010039 — 12, 7
- 2004-04-05 0001104659-04-009437 — 12, 7
- 2004-01-26 0001104659-04-001655 — 12, 7
- 2003-10-16 0001104659-03-022990 — 12, 7
- 2003-07-17 0001104659-03-015053 — 9
- 2003-04-18 0001104659-03-006823 — 7, 9
- 2003-02-14 0001104659-03-002607 — 5, 7

## late-filing notifications on or before 2024-05-07

- 2015-03-02 0000926326-15-000006 — NT 10-K, for the period ended 2014-12-31
- 2007-03-16 0001104659-07-020094 — NT 10-K, for the period ended 2006-12-31

## item 2.02 — earnings release, exhibit 99.1

[0000926326-24-000012:8k_2_02:1]
EX-99.1
2
exhibit991q1-24.htm
EX-99.1

[0000926326-24-000012:8k_2_02:2]
Document

[0000926326-24-000012:8k_2_02:3]
Exhibit 99.1

[0000926326-24-000012:8k_2_02:4]
| Contact: |  |  |
| Kathleen Nemeth |  | Omnicell, Inc. |
| Senior Vice President, Investor Relations |  | 4220 North Freeway |
| 650-435-3318 |  | Fort Worth, TX 76137 |
| Kathleen.Nemeth@Omnicell.com |  |  |

[0000926326-24-000012:8k_2_02:5]
Omnicell Announces First Quarter 2024 Results

[0000926326-24-000012:8k_2_02:6]
Results exceed prior first quarter guidance across all metrics

[0000926326-24-000012:8k_2_02:7]
Total GAAP revenues of $246 million

[0000926326-24-000012:8k_2_02:8]
FORT WORTH, Texas -- May 2, 2024 -- Omnicell, Inc. (NASDAQ:OMCL) (“Omnicell,” “we,” “our,” “us,” “management,” or the “Company”), a leader in transforming the pharmacy care delivery model, today announced results for its first quarter ended March 31, 2024.

[0000926326-24-000012:8k_2_02:9]
Randall Lipps, chairman, president, chief executive officer, and founder of Omnicell, said, “We are pleased with the first quarter results that we announced today, which exceeded our previously issued guidance across all key metrics, including revenue, non-GAAP EBITDA and non-GAAP earnings per share.”

[0000926326-24-000012:8k_2_02:10]
“As we have navigated through a challenging customer environment, we have continued to place a priority on innovation. Reflecting this, we recently hosted our customer event, Illuminate 2024, during which we announced new and exciting outcomes-based solutions for our XT automated dispensing systems platform. Key among these is XTExtend, among other recently introduced enhancements for our XT automated dispensing systems that are part of our comprehensive XTAmplify offering, which appears to be resonating very well with our customers,” Mr. Lipps continued.

[0000926326-24-000012:8k_2_02:11]
“Finally, last quarter, we announced that we initiated a holistic review of our business in an effort to identify areas for financial or operational improvement intended to enhance stockholder value. That work is underway, and we are optimistic that when completed, the results of this review will positively impact our performance. We remain confident in Omnicell’s long-term opportunities as we work to transform the pharmacy care delivery model across the continuum of care,” Mr. Lipps concluded.

[0000926326-24-000012:8k_2_02:12]
Financial Results

[0000926326-24-000012:8k_2_02:13]
Total GAAP revenues for the first quarter of 2024 were $246 million, down $44 million, or 15%, from the first quarter of 2023. The year-over-year decrease in total GAAP revenues reflects the impact of a continued challenging environment for some of our health system customers and the timing of our XT Series systems lifecycle, as we are largely through the replacement cycle and seeing demand moderate.

[0000926326-24-000012:8k_2_02:14]
Total GAAP net loss for the first quarter of 2024 was $16 million, or $0.34 per diluted share. This compares to GAAP net loss of $15 million, or $0.33 per diluted share, for the first quarter of 2023.

[0000926326-24-000012:8k_2_02:15]
Total non-GAAP net income for the first quarter of 2024 was $1 million, or $0.03 per diluted share. This compares to non-GAAP net income of $17 million, or $0.39 per diluted share, for the first quarter of 2023.

[0000926326-24-000012:8k_2_02:16]
Total non-GAAP EBITDA for the first quarter of 2024 was $11 million. This compares to non-GAAP EBITDA of $27 million for the first quarter of 2023.

[0000926326-24-000012:8k_2_02:17]
Balance Sheet

[0000926326-24-000012:8k_2_02:18]
As of March 31, 2024, Omnicell’s balance sheet reflected cash and cash equivalents of $512 million, total debt (net of unamortized debt issuance costs) of $570 million, and total assets of $2.28 billion. Cash flows provided by operating activities in the first quarter of 2024 totaled $50 million. This compares to cash flows provided by operating activities totaling $13 million in the first quarter of 2023.

[0000926326-24-000012:8k_2_02:19]
As of March 31, 2024, the Company had $350 million of availability under its revolving credit facility with no outstanding balance.

[0000926326-24-000012:8k_2_02:20]
Corporate Highlights

[0000926326-24-000012:8k_2_02:21]
•Introduced XT Amplify, innovative solutions designed to enhance pharmacy and nursing efficiency, reduce medication errors and waste, and ultimately maximize the value of the XT automated dispensing system

[0000926326-24-000012:8k_2_02:22]
•Hosted Illuminate 2024 educational and networking event for customers and prospective customers to learn more about Omnicell’s outcomes-centric innovation, including the recently launched XT Amplify program

[0000926326-24-000012:8k_2_02:23]
•Published our 2023 Environmental, Social, and Governance Report (ESG), highlighting the Company’s commitment to leveraging ESG opportunities to enhance our performance and maximize positive business impact

[0000926326-24-000012:8k_2_02:24]
•Further progressed holistic review of business in an effort to identify areas for operational and financial improvement that have the potential to create sustained stockholder value

[0000926326-24-000012:8k_2_02:25]
•Launched our refreshed corporate website, www.omnicell.com, that reflects our new brand promise and focus on Defining. Delivering. Outcomes.

[0000926326-24-000012:8k_2_02:26]
2024 Guidance

[0000926326-24-000012:8k_2_02:27]
The Company’s full year 2024 guidance is unchanged. For the full year 2024, the Company expects bookings to be between $750 million and $875 million. The Company expects full year 2024 total revenues to be between $1.045 billion and $1.120 billion. The Company expects full year 2024 product revenues to be between $605 million and $650 million, and full year 2024 service revenues to be between $440 million and $470 million. The Company expects full year 2024 technical services revenues to be between $220 million and $235 million, and full year 2024 Advanced Services revenues to be between $220 million and $235 million. The Company expects full year 2024 non-GAAP EBITDA to be between $90 million and $120 million. The Company expects full year 2024 non-GAAP earnings per share to be between $0.90 and $1.40 per share.

[0000926326-24-000012:8k_2_02:28]
For the second quarter of 2024, the Company expects total revenues to be between $250 million and $260 million. The Company expects second quarter 2024 product revenues to be between $140 million and $145 million, and second quarter 2024 service revenues to be between $110 million and $115 million. The Company expects second quarter 2024 non-GAAP EBITDA to be between $14 million and $20 million. The Company expects second quarter 2024 non-GAAP earnings per share to be between $0.10 and $0.20 per share.

[0000926326-24-000012:8k_2_02:29]
The table below summarizes Omnicell’s second quarter and full year 2024 guidance outlined above.

[0000926326-24-000012:8k_2_02:30]
|  | Q2 2024 |  | 2024 |
| Bookings | Not provided |  | $750 million - $875 million |
| Total Revenues | $250 million - $260 million |  | $1.045 billion - $1.120 billion |
| Product Revenues | $140 million - $145 million |  | $605 million - $650 million |
| Service Revenues | $110 million - $115 million |  | $440 million - $470 million |
| Technical Services Revenues | Not provided |  | $220 million - $235 million |
| Advanced Services Revenues | Not provided |  | $220 million - $235 million |
| Non-GAAP EBITDA | $14 million - $20 million |  | $90 million - $120 million |
| Non-GAAP Earnings Per Share | $0.10 - $0.20 |  | $0.90 - $1.40 |

[0000926326-24-000012:8k_2_02:31]
The Company does not provide guidance for GAAP net income or GAAP earnings per share, nor a reconciliation of these forward-looking non-GAAP financial measures to the most directly comparable GAAP financial measures on a forward-looking basis because it is unable to predict certain items contained in the GAAP measures without unreasonable efforts. These forward-looking non-GAAP financial measures do not include certain items, which may be significant, including, but not limited to, unusual gains and losses, costs associated with future restructurings, acquisition-related expenses, and certain tax and litigation outcomes.

[0000926326-24-000012:8k_2_02:32]
Omnicell Conference Call Information

[0000926326-24-000012:8k_2_02:33]
Omnicell will hold a conference call today, Thursday, May 2, 2024 at 8:30 a.m. ET to discuss first quarter 2024 financial results. The conference call can be monitored by dialing (888) 550-5424 in the U.S. or (646) 960-0819 in international locations. The Conference ID is 9581556. A link to the live and archived webcast will also be available on the Investor Relations section of Omnicell’s website at http://ir.omnicell.com/events-and-presentations/.

[0000926326-24-000012:8k_2_02:34]
__________________________________________________

[0000926326-24-000012:8k_2_02:35]
About Omnicell

[0000926326-24-000012:8k_2_02:36]
Since 1992, Omnicell has been committed to transforming pharmacy care through outcomes-centric innovation designed to optimize clinical and business outcomes across all settings of care. Through a comprehensive portfolio of robotics, smart devices, intelligent software, and expert services, Omnicell solutions are helping healthcare facilities worldwide to reduce costs, improve labor efficiency, establish new revenue streams, enhance supply chain control, support compliance, and move closer to the industry vision of the Autonomous Pharmacy. To learn more, visit omnicell.com.

[0000926326-24-000012:8k_2_02:37]
From time to time, Omnicell may use the Company’s investor relations website and other online social media channels, including its LinkedIn page www.linkedin.com/company/omnicell and Facebook page www.facebook.com/omnicellinc, to disclose material non-public information and comply with its disclosure obligations under Regulation Fair Disclosure (“Reg FD”).

[0000926326-24-000012:8k_2_02:38]
OMNICELL and the Omnicell logo are registered trademarks of Omnicell, Inc. or one of its subsidiaries.

[0000926326-24-000012:8k_2_02:39]
Forward-Looking Statements

[0000926326-24-000012:8k_2_02:40]
Use of Non-GAAP Financial Information

[0000926326-24-000012:8k_2_02:41]
This press release contains financial measures that are not calculated in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”). Management evaluates and makes operating decisions using various performance measures. In addition to Omnicell’s GAAP results, we also consider non-GAAP revenues, non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP operating margin, non-GAAP net income, non-GAAP net income per diluted share, non-GAAP diluted shares, non-GAAP EBITDA, non-GAAP EBITDA margin, and non-GAAP free cash flow. These non-GAAP results and metrics should not be considered as an alternative to revenues, gross profit, operating expenses, income from operations, net income, net income per diluted share, diluted shares, net cash provided by operating activities, or any other performance measure derived in accordance with GAAP. We present these non-GAAP results and metrics because management considers them to be important supplemental measures of Omnicell’s performance and refers to such measures when analyzing Omnicell’s strategy and operations.

[0000926326-24-000012:8k_2_02:42]
Our non-GAAP revenues, non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP operating margin, non-GAAP net income, non-GAAP net income per diluted share, non-GAAP EBITDA, and non-GAAP EBITDA margin are exclusive of certain items to facilitate management’s review of the comparability of Omnicell’s core operating results on a period-to-period basis because such items are not related to Omnicell’s ongoing core operating results as viewed by management. We define our “core operating results” as those revenues recorded in a particular period and the expenses incurred within such period that directly drive operating income in such period. Management uses these non-GAAP financial measures in making operating decisions because, in addition to meaningful supplemental information regarding operating performance, the measures give us a better understanding of how we believe we should invest in research and development, fund infrastructure growth, and evaluate the effectiveness of marketing strategies. In calculating the above non-GAAP results: non-GAAP gross profit and non-GAAP gross margin exclude from their GAAP equivalents items a), b), e), and g) below; non-GAAP operating expenses excludes from its GAAP equivalents items a), b), c), d), e), and g) below; non-GAAP income from operations and non-GAAP operating margin exclude from their GAAP equivalents items a), b), c), d), e), and g) below; and non-GAAP net income and non-GAAP net income per diluted share exclude from their GAAP equivalents items a) through g) below. Non-GAAP EBITDA is defined as earnings before interest income and expense, taxes, depreciation, amortization, and share-based compensation, as well as excluding certain other non-GAAP adjustments. Non-GAAP EBITDA and non-GAAP EBITDA margin exclude from their GAAP equivalents items a), c), d), e), f), and g) below:

[0000926326-24-000012:8k_2_02:43]
a)Share-based compensation expense. We excluded from our non-GAAP results the expense related to equity-based compensation plans as it represents expenses that do not require cash settlement from Omnicell.

[0000926326-24-000012:8k_2_02:44]
b)Amortization of acquired intangible assets. We excluded from our non-GAAP results the intangible assets amortization expense resulting from our past acquisitions. These non-cash charges are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results.

[0000926326-24-000012:8k_2_02:45]
c)Acquisition-related expenses. We excluded from our non-GAAP results the expenses related to recent acquisitions, including amortization of representations and warranties insurance. These expenses are unrelated to our ongoing operations, vary in size and frequency, and are subject to significant fluctuations from period to period due to varying levels of acquisition activity. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of less acquisitive peer companies.

[0000926326-24-000012:8k_2_02:46]
d)Impairment and abandonment of operating lease right-of-use and other assets related to facilities. We excluded from our non-GAAP results the impairment and abandonment of certain operating lease right-of-use assets, as well as property and equipment, incurred in connection with restructuring activities for optimization of certain leased facilities. These non-cash charges are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results.

[0000926326-24-000012:8k_2_02:47]
e)Severance-related expenses. We excluded from our non-GAAP results the expenses related to restructuring events, partially offset by reversals of previously recognized severance expenses in subsequent periods. These expenses are unrelated to our ongoing operations, vary in size and frequency, and are subject to significant fluctuations from period to period due to varying levels of restructuring activity. We believe that excluding these expenses provides more meaningful

[0000926326-24-000012:8k_2_02:48]
comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of peer companies.

[0000926326-24-000012:8k_2_02:49]
f)Amortization of debt issuance costs. Debt issuance costs represent costs associated with the issuance of term loan and revolving credit facilities, as well as the issuance of convertible senior notes. The costs include underwriting fees, original issue discount, ticking fees, and legal fees. These non-cash expenses are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results.

[0000926326-24-000012:8k_2_02:50]
g)RDS restructuring. We excluded from our non-GAAP results the nonrecurring restructuring charges related to the wind down of the Company’s Medimat Robotic Dispensing System (“RDS”) product line. For the quarter ended March 31, 2024, those charges consisted primarily of severance and other related expenses. These expenses are unrelated to our ongoing operations and we believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of peer companies.

[0000926326-24-000012:8k_2_02:51]
Management adjusts for the above items because management believes that, in general, these items possess one or more of the following characteristics: their magnitude and timing is largely outside of Omnicell’s control; they are unrelated to the ongoing operation of the business in the ordinary course; they are unusual and we do not expect them to occur in the ordinary course of business; or they are non-operational or non-cash expenses involving stock compensation plans or other items.

[0000926326-24-000012:8k_2_02:52]
We believe that the presentation of non-GAAP revenues, non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP operating margin, non-GAAP net income, non-GAAP net income per diluted share, non-GAAP EBITDA, and non-GAAP EBITDA margin is warranted for several reasons:

[0000926326-24-000012:8k_2_02:53]
a)Such non-GAAP financial measures provide an additional analytical tool for understanding Omnicell’s financial performance by excluding the impact of items which may obscure trends in the core operating results of the business.

[0000926326-24-000012:8k_2_02:54]
b)Since we have historically reported non-GAAP results to the investment community, we believe the inclusion of non-GAAP numbers provides consistency and enhances investors’ ability to compare our performance across financial reporting periods.

[0000926326-24-000012:8k_2_02:55]
c)These non-GAAP financial measures are employed by management in its own evaluation of performance and are utilized in financial and operational decision-making processes, such as budget planning and forecasting.

[0000926326-24-000012:8k_2_02:56]
d)These non-GAAP financial measures facilitate comparisons to the operating results of other companies in our industry, which also use non-GAAP financial measures to supplement their GAAP results (although these companies may calculate non-GAAP financial measures differently than Omnicell does), thus enhancing the perspective of investors who wish to utilize such comparisons in their analysis of our performance.

[0000926326-24-000012:8k_2_02:57]
Set forth below are additional reasons why share-based compensation expense is excluded from our non-GAAP financial measures:

[0000926326-24-000012:8k_2_02:58]
i)While share-based compensation calculated in accordance with Accounting Standards Codification (“ASC”) 718 constitutes an ongoing and recurring expense of Omnicell, it is not an expense that requires cash settlement by Omnicell. We therefore exclude these charges for purposes of evaluating core operating results. Thus, our non-GAAP measurements are presented exclusive of share-based compensation expense to assist management and investors in evaluating our core operating results.

[0000926326-24-000012:8k_2_02:59]
ii)We present ASC 718 share-based payment compensation expense in our reconciliation of non-GAAP financial measures on a pre-tax basis because the exact tax differences related to the timing and deductibility of share-based compensation under ASC 718 are dependent upon the trading price of Omnicell’s common stock and the timing and exercise by employees of their stock options. As a result of these timing and market uncertainties, the tax effect related to share-based compensation expense would be inconsistent in amount and frequency and is therefore excluded from our non-GAAP results.

[0000926326-24-000012:8k_2_02:60]
Non-GAAP diluted shares is defined as our GAAP diluted shares, excluding the impact of dilutive convertible senior notes for which the Company is economically hedged through its anti-dilutive convertible note hedge transaction. We believe non-GAAP diluted shares is a useful non-GAAP metric because it provides insight into the offsetting economic effect of the hedge transaction against potential conversion of the convertible senior notes.

[0000926326-24-000012:8k_2_02:61]
Non-GAAP free cash flow is defined as net cash provided by operating activities less cash used for software development for external use and purchases of property and equipment. We believe free cash flow is important to enable investors to better understand and evaluate our ongoing operating results and allows for greater transparency in the review and understanding of our overall financial, operational, and economic performance, because free cash flow takes into account certain capital expenditures and cash used for software development necessary to operate our business.

[0000926326-24-000012:8k_2_02:62]
As stated above, we present non-GAAP financial measures because we consider them to be important supplemental measures of performance. However, non-GAAP financial measures have limitations as an analytical tool and should not be considered in isolation or as a substitute for Omnicell’s GAAP results. In the future, we expect to incur expenses similar to certain of the non-GAAP adjustments described above and expect to continue reporting non-GAAP financial measures excluding such items. Some of the limitations in relying on non-GAAP financial measures are:

[0000926326-24-000012:8k_2_02:63]
a)Omnicell’s equity incentive plans and stock purchase plans are important components of incentive compensation arrangements and will be reflected as expenses in Omnicell’s GAAP results for the foreseeable future under ASC 718.

[0000926326-24-000012:8k_2_02:64]
b)Other companies, including companies in Omnicell’s industry, may calculate non-GAAP financial measures differently than Omnicell, limiting their usefulness as a comparative measure.

[0000926326-24-000012:8k_2_02:65]
c)A limitation of the utility of free cash flow as a measure of financial performance is that it does not represent the total increase or decrease in Omnicell’s cash balance for the period.

[0000926326-24-000012:8k_2_02:66]
A detailed reconciliation between Omnicell’s non-GAAP and GAAP financial results is set forth in the financial tables at the end of this press release. Investors are advised to carefully review and consider this information strictly as a supplement to the GAAP results that are contained in this press release as well as in Omnicell’s other reports filed with or furnished to the SEC.

[0000926326-24-000012:8k_2_02:67]
6

[0000926326-24-000012:8k_2_02:68]
Omnicell, Inc.

[0000926326-24-000012:8k_2_02:69]
Condensed Consolidated Statements of Operations

[0000926326-24-000012:8k_2_02:70]
(Unaudited, in thousands, except per share data)

[0000926326-24-000012:8k_2_02:71]
|  | Three Months Ended March 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Revenues: |  |  |  |  |  |  |  |
| Product revenues | $ | 133,295 |  |  | $ | 185,715 |  |  |  |  |  |
| Services and other revenues | 112,856 |  |  | 104,914 |  |  |  |  |  |
| Total revenues | 246,151 |  |  | 290,629 |  |  |  |  |  |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | 92,441 |  |  | 109,527 |  |  |  |  |  |
| Cost of services and other revenues | 61,087 |  |  | 56,073 |  |  |  |  |  |
| Total cost of revenues | 153,528 |  |  | 165,600 |  |  |  |  |  |
| Gross profit | 92,623 |  |  | 125,029 |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 22,056 |  |  | 22,878 |  |  |  |  |  |
| Selling, general, and administrative | 92,414 |  |  | 125,114 |  |  |  |  |  |
| Total operating expenses | 114,470 |  |  | 147,992 |  |  |  |  |  |
| Loss from operations | (21,847) |  |  | (22,963) |  |  |  |  |  |
| Interest and other income (expense), net | 4,016 |  |  | 1,781 |  |  |  |  |  |
| Loss before income taxes | (17,831) |  |  | (21,182) |  |  |  |  |  |
| Benefit from income taxes | (2,155) |  |  | (6,182) |  |  |  |  |  |
| Net loss | $ | (15,676) |  |  | $ | (15,000) |  |  |  |  |  |
| Net loss per share: |  |  |  |  |  |  |  |
| Basic | $ | (0.34) |  |  | $ | (0.33) |  |  |  |  |  |
| Diluted | $ | (0.34) |  |  | $ | (0.33) |  |  |  |  |  |
| Weighted-average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 45,732 |  |  | 44,887 |  |  |  |  |  |
| Diluted | 45,732 |  |  | 44,887 |  |  |  |  |  |

[0000926326-24-000012:8k_2_02:72]
Omnicell, Inc.

[0000926326-24-000012:8k_2_02:73]
Condensed Consolidated Balance Sheets

[0000926326-24-000012:8k_2_02:74]
(Unaudited, in thousands)

[0000926326-24-000012:8k_2_02:75]
|  | March 31,2024 |  | December 31,2023 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 512,364 |  |  | $ | 467,972 |  |
| Accounts receivable and unbilled receivables, net | 248,512 |  |  | 252,025 |  |
| Inventories | 103,466 |  |  | 110,099 |  |
| Prepaid expenses | 26,585 |  |  | 25,966 |  |
| Other current assets | 98,991 |  |  | 71,509 |  |
| Total current assets | 989,918 |  |  | 927,571 |  |
| Property and equipment, net | 109,034 |  |  | 108,601 |  |
| Long-term investment in sales-type leases, net | 43,909 |  |  | 42,954 |  |
| Operating lease right-of-use assets | 26,531 |  |  | 24,988 |  |
| Goodwill | 735,357 |  |  | 735,810 |  |
| Intangible assets, net | 205,115 |  |  | 211,173 |  |
| Long-term deferred tax assets | 37,383 |  |  | 32,901 |  |
| Prepaid commissions | 50,191 |  |  | 52,414 |  |
| Other long-term assets | 86,317 |  |  | 90,466 |  |
| Total assets | $ | 2,283,755 |  |  | $ | 2,226,878 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 43,145 |  |  | $ | 45,028 |  |
| Accrued compensation | 41,446 |  |  | 51,754 |  |
| Accrued liabilities | 167,187 |  |  | 149,276 |  |
| Deferred revenues | 164,586 |  |  | 121,734 |  |
| Total current liabilities | 416,364 |  |  | 367,792 |  |
| Long-term deferred revenues | 65,195 |  |  | 58,622 |  |
| Long-term deferred tax liabilities | 1,493 |  |  | 1,620 |  |
| Long-term operating lease liabilities | 34,568 |  |  | 33,910 |  |
| Other long-term liabilities | 7,099 |  |  | 6,318 |  |
| Convertible senior notes, net | 570,439 |  |  | 569,662 |  |
| Total liabilities | 1,095,158 |  |  | 1,037,924 |  |
| Total stockholders’ equity | 1,188,597 |  |  | 1,188,954 |  |
| Total liabilities and stockholders’ equity | $ | 2,283,755 |  |  | $ | 2,226,878 |  |

[0000926326-24-000012:8k_2_02:76]
8

[0000926326-24-000012:8k_2_02:77]
Omnicell, Inc.

[0000926326-24-000012:8k_2_02:78]
Condensed Consolidated Statements of Cash Flows

[0000926326-24-000012:8k_2_02:79]
(Unaudited, in thousands)

[0000926326-24-000012:8k_2_02:80]
|  | Three Months Ended March 31, |
|  | 2024 |  | 2023 |
| Operating Activities |  |  |  |
| Net loss | $ | (15,676) |  |  | $ | (15,000) |  |
| Adjustments to reconcile net loss to net cash provided by operating activities: |
| Depreciation and amortization | 21,253 |  |  | 21,974 |  |
| Loss on disposal of assets | 39 |  |  | 802 |  |
| Share-based compensation expense | 8,641 |  |  | 14,042 |  |
| Deferred income taxes | (4,609) |  |  | (7,770) |  |
| Amortization of operating lease right-of-use assets | 1,930 |  |  | 2,248 |  |
| Impairment and abandonment of operating lease right-of-use assets related to facilities | — |  |  | 7,815 |  |
| Amortization of debt issuance costs | 971 |  |  | 1,045 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable and unbilled receivables | 3,393 |  |  | (22,156) |  |
| Inventories | 6,302 |  |  | 6,760 |  |
| Prepaid expenses | (619) |  |  | (873) |  |
| Other current assets | 928 |  |  | 34 |  |
| Investment in sales-type leases | (1,125) |  |  | 613 |  |
| Prepaid commissions | 2,223 |  |  | 2,574 |  |
| Other long-term assets | 836 |  |  | 628 |  |
| Accounts payable | (1,443) |  |  | 20 |  |
| Accrued compensation | (10,278) |  |  | (25,171) |  |
| Accrued liabilities | 5,063 |  |  | (689) |  |
| Deferred revenues | 34,121 |  |  | 29,135 |  |
| Operating lease liabilities | (2,778) |  |  | (2,678) |  |
| Other long-term liabilities | 781 |  |  | (583) |  |
| Net cash provided by operating activities | 49,953 |  |  | 12,770 |  |
| Investing Activities |  |  |  |
| External-use software development costs | (3,383) |  |  | (3,499) |  |
| Purchases of property and equipment | (8,957) |  |  | (10,141) |  |
| Net cash used in investing activities | (12,340) |  |  | (13,640) |  |
| Financing Activities |  |  |  |
| Proceeds from issuances under stock-based compensation plans | 8,042 |  |  | 12,114 |  |
| Employees’ taxes paid related to restricted stock units | (705) |  |  | (1,369) |  |
| Change in customer funds, net | 4,589 |  |  | (6,883) |  |
| Net cash provided by financing activities | 11,926 |  |  | 3,862 |  |
| Effect of exchange rate changes on cash and cash equivalents | (556) |  |  | 176 |  |
| Net increase in cash, cash equivalents, and restricted cash | 48,983 |  |  | 3,168 |  |
| Cash, cash equivalents, and restricted cash at beginning of period | 500,979 |  |  | 352,835 |  |
| Cash, cash equivalents, and restricted cash at end of period | $ | 549,962 |  |  | $ | 356,003 |  |
| Reconciliation of cash, cash equivalents, and restricted cash to the Condensed Consolidated Balance Sheets: |
| Cash and cash equivalents | $ | 512,364 |  |  | $ | 340,413 |  |
| Restricted cash included in other current assets | 37,598 |  |  | 15,590 |  |
| Cash, cash equivalents, and restricted cash at end of period | $ | 549,962 |  |  | $ | 356,003 |  |

[0000926326-24-000012:8k_2_02:81]
Omnicell, Inc.

[0000926326-24-000012:8k_2_02:82]
Reconciliation of GAAP to Non-GAAP

[0000926326-24-000012:8k_2_02:83]
(Unaudited, in thousands, except per share data and percentage)

[0000926326-24-000012:8k_2_02:84]
|  | Three Months Ended March 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Reconciliation of GAAP revenues to non-GAAP revenues: |
| GAAP revenues | $ | 246,151 |  |  | $ | 290,629 |  |  |  |  |  |
| Non-GAAP revenues | $ | 246,151 |  |  | $ | 290,629 |  |  |  |  |  |
| Reconciliation of GAAP gross profit to non-GAAP gross profit: |  |  |  |  |  |
| GAAP gross profit | $ | 92,623 |  |  | $ | 125,029 |  |  |  |  |  |
| GAAP gross margin | 37.6% |  | 43.0% |  |  |  |  |
| Share-based compensation expense | 1,555 |  |  | 2,008 |  |  |  |  |  |
| Amortization of acquired intangibles | 1,120 |  |  | 3,025 |  |  |  |  |  |
| RDS restructuring | 2,696 |  |  | — |  |  |  |  |  |
| Severance-related expenses | — |  |  | 144 |  |  |  |  |  |
| Non-GAAP gross profit | $ | 97,994 |  |  | $ | 130,206 |  |  |  |  |  |
| Non-GAAP gross margin | 39.8% |  | 44.8% |  |  |  |  |
| Reconciliation of GAAP operating expenses to non-GAAP operating expenses: |  |  |  |  |
| GAAP operating expenses | $ | 114,470 |  |  | $ | 147,992 |  |  |  |  |  |
| GAAP operating expenses % to total revenues | 46.5% |  | 50.9% |  |  |  |  |
| Share-based compensation expense | (7,086) |  |  | (12,034) |  |  |  |  |  |
| Amortization of acquired intangibles | (4,840) |  |  | (5,217) |  |  |  |  |  |
| Acquisition-related expenses | (246) |  |  | (246) |  |  |  |  |  |
| Impairment and abandonment of operating lease right-of-use and other assets related to facilities | — |  |  | (8,420) |  |  |  |  |  |
| RDS restructuring | (576) |  |  | — |  |  |  |  |  |
| Severance-related expenses | — |  |  | (5,170) |  |  |  |  |  |
| Non-GAAP operating expenses | $ | 101,722 |  |  | $ | 116,905 |  |  |  |  |  |
| Non-GAAP operating expenses as a % of total non-GAAP revenues | 41.3% |  | 40.2% |  |  |  |  |
| Reconciliation of GAAP loss from operations to non-GAAP income (loss) from operations: |
| GAAP loss from operations | $ | (21,847) |  |  | $ | (22,963) |  |  |  |  |  |
| GAAP operating loss % to total revenues | (8.9)% |  | (7.9)% |  |  |  |  |
| Share-based compensation expense | 8,641 |  |  | 14,042 |  |  |  |  |  |
| Amortization of acquired intangibles | 5,960 |  |  | 8,242 |  |  |  |  |  |
| Acquisition-related expenses | 246 |  |  | 246 |  |  |  |  |  |
| Impairment and abandonment of operating lease right-of-use and other assets related to facilities | — |  |  | 8,420 |  |  |  |  |  |
| RDS restructuring | 3,272 |  |  | — |  |  |  |  |  |
| Severance-related expenses | — |  |  | 5,314 |  |  |  |  |  |
| Non-GAAP income (loss) from operations | $ | (3,728) |  |  | $ | 13,301 |  |  |  |  |  |
| Non-GAAP operating margin (non-GAAP operating income (loss) as a % of total non-GAAP revenues) | (1.5)% |  | 4.6% |  |  |  |  |

[0000926326-24-000012:8k_2_02:85]
10

[0000926326-24-000012:8k_2_02:86]
Omnicell, Inc.

[0000926326-24-000012:8k_2_02:87]
Reconciliation of GAAP to Non-GAAP

[0000926326-24-000012:8k_2_02:88]
(Unaudited, in thousands, except per share data and percentage)

[0000926326-24-000012:8k_2_02:89]
|  | Three Months Ended March 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Reconciliation of GAAP net loss to non-GAAP net income: |
| GAAP net loss | $ | (15,676) |  |  | $ | (15,000) |  |  |  |  |  |
| Share-based compensation expense | 8,641 |  |  | 14,042 |  |  |  |  |  |
| Amortization of acquired intangibles | 5,960 |  |  | 8,242 |  |  |  |  |  |
| Acquisition-related expenses | 246 |  |  | 246 |  |  |  |  |  |
| Impairment and abandonment of operating lease right-of-use and other assets related to facilities | — |  |  | 8,420 |  |  |  |  |  |
| RDS restructuring | 3,272 |  |  | — |  |  |  |  |  |
| Severance-related expenses | — |  |  | 5,314 |  |  |  |  |  |
| Amortization of debt issuance costs | 971 |  |  | 1,045 |  |  |  |  |  |
| Tax effect of the adjustments above (a) | (2,194) |  |  | (4,886) |  |  |  |  |  |
| Non-GAAP net income | $ | 1,220 |  |  | $ | 17,423 |  |  |  |  |  |
| Reconciliation of GAAP net loss per share - diluted to non-GAAP net income per share - diluted: |
| Shares - diluted GAAP | 45,732 |  |  | 44,887 |  |  |  |  |  |
| Shares - diluted non-GAAP | 45,768 |  |  | 45,120 |  |  |  |  |  |
| GAAP net loss per share - diluted | $ | (0.34) |  |  | $ | (0.33) |  |  |  |  |  |
| Share-based compensation expense | 0.19 |  |  | 0.31 |  |  |  |  |  |
| Amortization of acquired intangibles | 0.13 |  |  | 0.18 |  |  |  |  |  |
| Acquisition-related expenses | 0.01 |  |  | 0.01 |  |  |  |  |  |
| Impairment and abandonment of operating lease right-of-use and other assets related to facilities | — |  |  | 0.19 |  |  |  |  |  |
| RDS restructuring | 0.07 |  |  | — |  |  |  |  |  |
| Severance-related expenses | — |  |  | 0.12 |  |  |  |  |  |
| Amortization of debt issuance costs | 0.02 |  |  | 0.02 |  |  |  |  |  |
| Tax effect of the adjustments above (a) | (0.05) |  |  | (0.11) |  |  |  |  |  |
| Non-GAAP net income per share - diluted | $ | 0.03 |  |  | $ | 0.39 |  |  |  |  |  |
| Reconciliation of GAAP net loss to non-GAAP EBITDA (b): |
| GAAP net loss | $ | (15,676) |  |  | $ | (15,000) |  |  |  |  |  |
| Share-based compensation expense | 8,641 |  |  | 14,042 |  |  |  |  |  |
| Interest (income) and expense, net | (5,715) |  |  | (3,074) |  |  |  |  |  |
| Depreciation and amortization expense | 21,253 |  |  | 21,974 |  |  |  |  |  |
| Acquisition-related expenses | 246 |  |  | 246 |  |  |  |  |  |
| Impairment and abandonment of operating lease right-of-use and other assets related to facilities | — |  |  | 8,420 |  |  |  |  |  |
| RDS restructuring | 3,272 |  |  | — |  |  |  |  |  |
| Severance-related expenses | — |  |  | 5,314 |  |  |  |  |  |
| Amortization of debt issuance costs | 971 |  |  | 1,045 |  |  |  |  |  |
| Benefit from income taxes | (2,155) |  |  | (6,182) |  |  |  |  |  |
| Non-GAAP EBITDA | $ | 10,837 |  |  | $ | 26,785 |  |  |  |  |  |
| Non-GAAP EBITDA margin (non-GAAP EBITDA as a % of total non-GAAP revenues) | 4.4% |  | 9.2% |  |  |  |  |

[0000926326-24-000012:8k_2_02:90]
_________________________________________________

[0000926326-24-000012:8k_2_02:91]
(a)Tax effects calculated for all adjustments except share-based compensation expense, using an estimated annual effective tax rate of 21% for both fiscal years 2024 and 2023.

[0000926326-24-000012:8k_2_02:92]
(b)Defined as earnings before interest income and expense, taxes, depreciation, amortization, and share-based compensation, as well as excluding certain other non-GAAP adjustments.

[0000926326-24-000012:8k_2_02:93]
Omnicell, Inc.

[0000926326-24-000012:8k_2_02:94]
Reconciliation of GAAP to Non-GAAP

[0000926326-24-000012:8k_2_02:95]
(Unaudited, in thousands)

[0000926326-24-000012:8k_2_02:96]
|  | Three Months Ended March 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Reconciliation of GAAP net cash provided by operating activities to non-GAAP free cash flow: |
| GAAP net cash provided by operating activities | $ | 49,953 |  |  | $ | 12,770 |  |  |  |  |  |
| External-use software development costs | (3,383) |  |  | (3,499) |  |  |  |  |  |
| Purchases of property and equipment | (8,957) |  |  | (10,141) |  |  |  |  |  |
| Non-GAAP free cash flow | $ | 37,613 |  |  | $ | (870) |  |  |  |  |  |

[0000926326-24-000012:8k_2_02:97]
12
