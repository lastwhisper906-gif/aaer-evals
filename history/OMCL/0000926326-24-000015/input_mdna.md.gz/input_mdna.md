# OMCL MD&A — 0000926326-24-000015


## mdna

[0000926326-24-000015:mdna:1]
[same as prior period, unchanged from 0000926326-23-000041:mdna:1]

[0000926326-24-000015:mdna:2]
[same as prior period, unchanged from 0000926326-23-000041:mdna:2]

[0000926326-24-000015:mdna:3]
[same as prior period, unchanged from 0000926326-23-000041:mdna:3]

[0000926326-24-000015:mdna:4]
[same as prior period, unchanged from 0000926326-23-000041:mdna:4]

[0000926326-24-000015:mdna:5]
[same as prior period, unchanged from 0000926326-23-000041:mdna:5]

[0000926326-24-000015:mdna:6]
[same as prior period, unchanged from 0000926326-23-000041:mdna:6]

[0000926326-24-000015:mdna:7]
[same as prior period, unchanged from 0000926326-23-000041:mdna:7]

[0000926326-24-000015:mdna:8]
[same as prior period, unchanged from 0000926326-23-000041:mdna:8]

[0000926326-24-000015:mdna:9]
[same as prior period, unchanged from 0000926326-23-000041:mdna:9]

[0000926326-24-000015:mdna:10]
[same as prior period, unchanged from 0000926326-23-000041:mdna:10]

[0000926326-24-000015:mdna:11]
•our ability to align our medication management infrastructure development and global workforce headcount with our current business expectations;

[0000926326-24-000015:mdna:12]
[same as prior period, unchanged from 0000926326-23-000041:mdna:12]

[0000926326-24-000015:mdna:13]
[same as prior period, unchanged from 0000926326-23-000041:mdna:13]

[0000926326-24-000015:mdna:14]
[same as prior period, unchanged from 0000926326-23-000041:mdna:14]

[0000926326-24-000015:mdna:15]
[same as prior period, unchanged from 0000926326-23-000041:mdna:15]

[0000926326-24-000015:mdna:16]
[same as prior period, unchanged from 0000926326-23-000041:mdna:16]

[0000926326-24-000015:mdna:17]
•our expected future uses of cash and the sufficiency of our sources of funding; and

[0000926326-24-000015:mdna:18]
•our ability to generate cash from operations and our estimates regarding the sufficiency of our cash resources;

[0000926326-24-000015:mdna:19]
[same as prior period, unchanged from 0000926326-23-000041:mdna:20]

[0000926326-24-000015:mdna:20]
[same as prior period, unchanged from 0000926326-23-000041:mdna:21]

[0000926326-24-000015:mdna:21]
[same as prior period, unchanged from 0000926326-23-000041:mdna:22]

[0000926326-24-000015:mdna:22]
[same as prior period, unchanged from 0000926326-23-000041:mdna:23]

[0000926326-24-000015:mdna:23]
[same as prior period, unchanged from 0000926326-23-000041:mdna:24]

[0000926326-24-000015:mdna:24]
[same as prior period, unchanged from 0000926326-23-000041:mdna:25]

[0000926326-24-000015:mdna:25]
Omnicell, a leader in transforming the pharmacy care delivery model, is committed to solving the critical challenges inherent in medication management and elevating the role of clinicians within healthcare as an essential component of care delivery. Omnicell is focused on helping its customers to define and deliver a cost effective medication management strategy that is designed to equip and empower pharmacists and nurses to focus on patient care rather than administrative tasks, and to drive improved clinical, operational, and financial outcomes across all care settings. We are doing this with an industry-leading medication management infrastructure which includes robotics, smart devices, intelligent software, and expert services. This comprehensive set of solutions provides the critical foundation for customers to realize the industry vision of the Autonomous Pharmacy, a vision defined by pharmacy leaders for improving operational efficiencies and ultimately targeting zero-error medication management.

[0000926326-24-000015:mdna:26]
Omnicell solutions are helping healthcare facilities worldwide to reduce costs, improve labor efficiency, establish new revenue streams, enhance supply chain control, support compliance, and move closer to the industry vision of the Autonomous Pharmacy. We sell our product and consumable solutions together with related service offerings. Revenues generated in the United States represented 89% and 88% of our total revenues for the three months ended March 31, 2024 and 2023, respectively.

[0000926326-24-000015:mdna:27]
[same as prior period, unchanged from 0000926326-23-000041:mdna:28]

[0000926326-24-000015:mdna:28]
We utilize bookings as an indicator of the success of our business. We define bookings generally as: (i) the value of non-cancelable contracts for our connected devices, software products, and Advanced Services (although, for those Advanced Services contracts without a minimum commitment, bookings only include the amount of revenue that has been recognized once the services have been provided); and (ii) for our consumables, the value of orders placed through our Omnicell Storefront online platform or through written or telephonic orders. We typically exclude technical services and other less significant items ancillary to our products and services, such as freight revenue from bookings. In addition, dependent upon counterparty or credit risk, which is evaluated at the time of contract signing, for a given multi-year subscription contract we may reduce the portion of the contractual commitment booked at a given time. As noted, the portfolio of products, solutions and services we offer has evolved. As a result, the ordering process for certain of our solutions has also evolved. For example, orders for certain solutions may not include a purchase order. Connected devices and software license bookings are recorded as revenue upon customer acceptance of the installation or receipt of goods. Revenues from Advanced Services bookings are recorded over the contractual term.

[0000926326-24-000015:mdna:29]
[same as prior period, unchanged from 0000926326-23-000041:mdna:30]

[0000926326-24-000015:mdna:30]
[same as prior period, unchanged from 0000926326-23-000041:mdna:31]

[0000926326-24-000015:mdna:31]
[same as prior period, unchanged from 0000926326-23-000041:mdna:32]

[0000926326-24-000015:mdna:32]
[same as prior period, unchanged from 0000926326-23-000041:mdna:33]

[0000926326-24-000015:mdna:33]
[same as prior period, unchanged from 0000926326-23-000041:mdna:34]

[0000926326-24-000015:mdna:34]
[same as prior period, unchanged from 0000926326-23-000041:mdna:35]

[0000926326-24-000015:mdna:35]
[same as prior period, unchanged from 0000926326-23-000041:mdna:36]

[0000926326-24-000015:mdna:36]
Our full-time employee headcount was approximately 3,590 and 3,650 on March 31, 2024 and December 31, 2023, respectively.

[0000926326-24-000015:mdna:37]
[same as prior period, unchanged from 0000926326-23-000041:mdna:38]

[0000926326-24-000015:mdna:38]
[same as prior period, unchanged from 0000926326-23-000041:mdna:39]

[0000926326-24-000015:mdna:39]
[same as prior period, unchanged from 0000926326-23-000041:mdna:40]

[0000926326-24-000015:mdna:40]
The U.S. spent a total of $634 billion on prescription drugs in 2022, an increase of 9% compared to 2021, and prescription drugs impact the vast majority of patients in virtually all settings of care. We believe there are significant challenges facing the practice of pharmacy today including, but not limited to, budget constraints, increased healthcare worker turnover rates, labor shortages, drug shortages, drug diversion, manual and error-prone processes, complex compliance requirements, and limited inventory visibility. Each of these challenges may lead to poor medication management outcomes including, but not limited to, medication errors, adverse drug events, lack of patient adherence, and medication waste. We also recognize that these challenges may impact the timing of contracting for, or implementing, our products, solutions, or services. However, we believe that over time these significant challenges to the practice of pharmacy will drive demand for increased automation, visibility, insights, and improved medication management outcomes that our solutions are designed to enable. Because of this, we believe that our solutions are well-positioned to address the evolving needs of healthcare institutions and therefore present opportunities for long-term growth.

[0000926326-24-000015:mdna:41]
In an effort to address these challenges and deliver solutions to help drive positive medication management outcomes, we continue to make significant investments in our research and development efforts to further advance the industry vision of the Autonomous Pharmacy. Furthermore, we believe a combination of robotics, smart devices, intelligent software, and expert services is needed in every care setting where medications are managed. We are focused on delivering solutions to help our customers realize the industry vision of the Autonomous Pharmacy and drive positive medication management outcomes with outstanding customer experience through a mature channel in four market categories:

[0000926326-24-000015:mdna:42]
•Point of Care.  As a market leader, we expect to continue expansion into this product market as customers increase the use of our dispensing systems in more areas within their hospitals and increasingly in ambulatory care settings. However, we recognize that the current macroeconomic environment, with significant labor constraints, may impact our customers’ considerations in the near term when they are determining whether to implement new workflows that may affect those same stressed labor pools. As we are largely through the replacement cycle of our previous generation of automated dispensing systems, we are seeing demand moderate. With the launch of next-generation enhancements and solutions for points of care, we believe we are providing a path for customers to maximize the value of their existing technology investments through upgrades and acquisitions of new program offerings for their current installed base. We also believe there is an opportunity for us to expand this offering and define a new standard for dispensing systems in ambulatory settings. We believe our current solutions within the Point of Care market and new innovation and services will continue to help customers drive improved clinical and financial outcomes.

[0000926326-24-000015:mdna:43]
•Central Pharmacy and IV Compounding.  This market represents the beginning of the medication management process in acute care settings, and we believe it is a significant automation opportunity for high volumes of manual, repetitive, and error-prone processes that are often common in pharmacies today. Manual medication dispensing processes are usually labor intensive, error-prone, and may lead to excess medication waste and expirations for our healthcare partners. Automating the central pharmacy dispensing process should enable customers to reallocate pharmacy labor, enhance dispensing accuracy and patient safety, and reduce medication waste and expirations. Likewise, the manual compounding of sterile IV preparations can be error-prone and create significant patient safety risks, and outsourcing sterile IV compounding could lead to increased medication costs and lack of access to needed medications as a result of being unable to source medications when they are required. As a result, we believe IV automation provides a significant opportunity to enhance patient safety and reduce costs. We anticipate that these technology-enabled services will become more critical as health systems continue to face labor shortages, increased financial pressure, and supply chain disruptions.

[0000926326-24-000015:mdna:44]
•Specialty Pharmacy and 340B Program.  We believe that health systems will continue to invest in programs that are intended to improve patient outcomes and drive cost savings by utilizing specialty pharmacies and the federal 340B Drug Pricing Program (the “340B Program”). The 340B Program allows qualifying hospitals and health systems to stretch federal resources and expand patient access to healthcare by requiring manufacturers participating in Medicaid to sell outpatient drugs at discounted prices to eligible healthcare organizations and covered entities. Specialty drugs are used for treatment of complex conditions and often require intensive patient management and specialized workflows for dispensing and care coordination. Specialty medications are projected to account for nearly 60% of U.S. total spending on medications, with total spending projected to be approximately $420 billion in 2025. Specialty pharmacies serve as the connection between patients, prescribing physicians, and payers and work to streamline access and adherence to these specialty drugs. We believe a solution that is designed to help health systems start or optimize their specialty pharmacy programs and the related pharmaceutical aspects of patient care will help ensure continuity of care and should contribute to the revenue and profitability of those organizations. We believe that a fully optimized specialty pharmacy operation represents one of the largest economic opportunities for hospitals and health systems.

[0000926326-24-000015:mdna:45]
•Retail, Institutional, and Payer.  We believe the Retail, Institutional, and Payer market represents a significant opportunity as healthcare evolves. Retail drug prescriptions represent 85% of all prescription drugs dispensed in the U.S., growing at a rate of 1.7% annually through 2022. Additionally, the COVID-19 pandemic accelerated the shift of outpatient care from hospitals and physician offices to other, more convenient settings, such as retail pharmacies and the home (including through telehealth technologies). New technologies and increased scope of practice for pharmacists appear to be spurring innovation and expansion of the provision of clinical services by retail pharmacies, which, combined with the move to value-based care, we believe will drive the adoption of our patient engagement solutions, that are intended to help providers (including pharmacists) and payers engage patients in new ways that are expected to improve outcomes, reduce the total cost of care, and lead to more profitable operations. Because of the complexity of relationships between payers and providers, as well as the large number of retail pharmacies, including a significant number of independent pharmacies, we believe a network of established relationships between payers, providers and pharmacies will continue to be important.

[0000926326-24-000015:mdna:46]
30

[0000926326-24-000015:mdna:47]
[same as prior period, unchanged from 0000926326-23-000041:mdna:48]

[0000926326-24-000015:mdna:48]
[same as prior period, unchanged from 0000926326-23-000041:mdna:49]

[0000926326-24-000015:mdna:49]
[same as prior period, unchanged from 0000926326-23-000041:mdna:50]

[0000926326-24-000015:mdna:50]
[same as prior period, unchanged from 0000926326-23-000041:mdna:51]

[0000926326-24-000015:mdna:51]
[same as prior period, unchanged from 0000926326-23-000041:mdna:52]

[0000926326-24-000015:mdna:52]
[same as prior period, unchanged from 0000926326-23-000041:mdna:53]

[0000926326-24-000015:mdna:53]
[same as prior period, unchanged from 0000926326-23-000041:mdna:54]

[0000926326-24-000015:mdna:54]
[same as prior period, unchanged from 0000926326-23-000041:mdna:55]

[0000926326-24-000015:mdna:55]
[same as prior period, unchanged from 0000926326-23-000041:mdna:56]

[0000926326-24-000015:mdna:56]
[same as prior period, unchanged from 0000926326-23-000041:mdna:58]

[0000926326-24-000015:mdna:57]
[same as prior period, unchanged from 0000926326-23-000041:mdna:57]

[0000926326-24-000015:mdna:58]
[same as prior period, unchanged from 0000926326-23-000041:mdna:59]

[0000926326-24-000015:mdna:59]
[same as prior period, unchanged from 0000926326-23-000041:mdna:60]

[0000926326-24-000015:mdna:60]
There were no material changes in the matters for which we make critical accounting estimates in the preparation of our Condensed Consolidated Financial Statements during the three months ended March 31, 2024 as compared to those disclosed in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” included in our Annual Report on Form 10-K for the year ended December 31, 2023.

[0000926326-24-000015:mdna:61]
[same as prior period, unchanged from 0000926326-23-000041:mdna:62]

[0000926326-24-000015:mdna:62]
Refer to “Recently Issued Authoritative Guidance” in Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q for a description of recently issued accounting pronouncements, including the expected dates of adoption and estimated effects on our results of operations, financial position, and cash flows.

[0000926326-24-000015:mdna:63]
[same as prior period, unchanged from 0000926326-23-000041:mdna:64]

[0000926326-24-000015:mdna:64]
[same as prior period, unchanged from 0000926326-23-000041:mdna:65]

[0000926326-24-000015:mdna:65]
|  | Three Months Ended March 31, |
|  |  |  |  |  | Change in |
|  | 2024 |  | 2023 |  | $ |  | % |
|  | (Dollars in thousands) |
| Product revenues | $ | 133,295 |  |  | $ | 185,715 |  |  | $ | (52,420) |  |  | (28)% |
| Percentage of total revenues | 54% |  | 64% |  |  |  |  |
| Services and other revenues | 112,856 |  |  | 104,914 |  |  | $ | 7,942 |  |  | 8% |
| Percentage of total revenues | 46% |  | 36% |  |  |  |  |
| Total revenues | $ | 246,151 |  |  | $ | 290,629 |  |  | $ | (44,478) |  |  | (15)% |

[0000926326-24-000015:mdna:66]
Product revenues represented 54% and 64% of total revenues for the three months ended March 31, 2024 and 2023, respectively. Product revenues decreased by $52.4 million, primarily due to lower volumes from our automated dispensing systems business primarily as a result of the impact of a continued challenging environment for some of our health system customers and the timing of our XT Series systems lifecycle, as we are largely through the replacement cycle and seeing demand moderate.

[0000926326-24-000015:mdna:67]
Services and other revenues represented 46% and 36% of total revenues for the three months ended March 31, 2024 and 2023, respectively. Services and other revenues include revenues from technical services and Advanced Services offerings. Services and other revenues increased by $7.9 million, primarily due to an increase of $5.2 million in technical services revenues as a result of growth in our installed customer base as well as the impact of pricing actions and an increase of $2.8 million in Advanced Services revenues due to continued customer demand.

[0000926326-24-000015:mdna:68]
Our international sales represented 11% and 12% of total revenues for the three months ended March 31, 2024 and 2023, respectively, and are expected to be affected by foreign currency exchange rate fluctuations. We are unable to predict the extent to which revenues in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-24-000015:mdna:69]
Our ability to continue to grow revenues is dependent on our ability to continue to obtain orders from customers, which may be dependent upon customers’ capital equipment budgets and/or capital equipment approval cycles, our ability to produce quality products and consumables to fulfill customer demand, the volume of installations we are able to complete, our ability to meet customer needs by providing a quality installation experience, our ability to develop new or enhance existing solutions, and our flexibility in workforce allocations among customers to complete installations on a timely basis. The timing of our product revenues for equipment is primarily dependent on when our customers’ schedules and/or staffing levels allow for installations.

[0000926326-24-000015:mdna:70]
[same as prior period, unchanged from 0000926326-23-000041:mdna:75]

[0000926326-24-000015:mdna:71]
[same as prior period, unchanged from 0000926326-23-000041:mdna:76]

[0000926326-24-000015:mdna:72]
|  | Three Months Ended March 31, |
|  |  |  |  |  | Change in |
|  | 2024 |  | 2023 |  | $ |  | % |
|  | (Dollars in thousands) |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | $ | 92,441 |  |  | $ | 109,527 |  |  | $ | (17,086) |  |  | (16)% |
| As a percentage of related revenues | 69% |  | 59% |  |  |  |  |
| Cost of services and other revenues | 61,087 |  |  | 56,073 |  |  | $ | 5,014 |  |  | 9% |
| As a percentage of related revenues | 54% |  | 53% |  |  |  |  |
| Total cost of revenues | $ | 153,528 |  |  | $ | 165,600 |  |  | $ | (12,072) |  |  | (7)% |
| As a percentage of total revenues | 62% |  | 57% |  |  |  |  |
| Gross profit | $ | 92,623 |  |  | $ | 125,029 |  |  | $ | (32,406) |  |  | (26)% |
| Gross margin | 38% |  | 43% |  |  |  |  |

[0000926326-24-000015:mdna:73]
Cost of revenues for the three months ended March 31, 2024 compared to the three months ended March 31, 2023 decreased by $12.1 million, primarily driven by a $17.1 million decrease in cost of product revenues, partially offset by a $5.0 million increase in cost of services and other revenues.

[0000926326-24-000015:mdna:74]
The decrease in cost of product revenues was primarily driven by the decrease in product revenues of $52.4 million for the three months ended March 31, 2024 compared to the three months ended March 31, 2023. The decrease in cost of product revenues has not decreased proportionally with the decrease in product revenues for the three months ended March 31, 2024, primarily due to the decrease in revenues of higher margin products as well as the impact of certain fixed costs, such as labor and overhead. In addition, the decrease in cost of product revenues was partially offset by an increase of $2.6 million of restructuring costs incurred during the three months ended March 31, 2024. The increase in cost of services and other revenues was primarily driven by the increase in services and other revenues of $7.9 million for the three months ended March 31, 2024 compared to the three months ended March 31, 2023.

[0000926326-24-000015:mdna:75]
The overall decrease in gross margin primarily relates to lower product revenues for the three months ended March 31, 2024 compared to the three months ended March 31, 2023 whereas the decrease in cost of product revenues has not decreased proportionally with the decrease in product revenues, primarily due to the decrease in revenues of higher margin products as well as the impact of certain fixed costs, such as labor and overhead. The decrease is partially offset by restructuring costs incurred during the three months ended March 31, 2024. Our gross profit for the three months ended March 31, 2024 was $92.6 million, as compared to $125.0 million for the three months ended March 31, 2023.

[0000926326-24-000015:mdna:76]
[same as prior period, unchanged from 0000926326-23-000041:mdna:85]

[0000926326-24-000015:mdna:77]
|  | Three Months Ended March 31, |
|  |  |  |  |  | Change in |
|  | 2024 |  | 2023 |  | $ |  | % |
|  | (Dollars in thousands) |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | $ | 22,056 |  |  | $ | 22,878 |  |  | $ | (822) |  |  | (4)% |
| As a percentage of total revenues | 9% |  | 8% |  |  |  |  |
| Selling, general, and administrative | 92,414 |  |  | 125,114 |  |  | $ | (32,700) |  |  | (26)% |
| As a percentage of total revenues | 38% |  | 43% |  |  |  |  |
| Total operating expenses | $ | 114,470 |  |  | $ | 147,992 |  |  | $ | (33,522) |  |  | (23)% |
| As a percentage of total revenues | 47% |  | 51% |  |  |  |  |
| Interest and other income (expense), net | $ | 4,016 |  |  | $ | 1,781 |  |  | $ | 2,235 |  |  | 125% |

[0000926326-24-000015:mdna:78]
Research and Development. Research and development expenses decreased by $0.8 million for the three months ended March 31, 2024 compared to the three months ended March 31, 2023. The decrease was primarily attributed to a decrease in employee-related expenses as a result of lower headcount.

[0000926326-24-000015:mdna:79]
33

[0000926326-24-000015:mdna:80]
Selling, General, and Administrative. Selling, general, and administrative expenses decreased by $32.7 million for the three months ended March 31, 2024 compared to the three months ended March 31, 2023. The decrease was primarily due to a decrease of $12.9 million in employee-related expenses as a result of lower headcount, a decrease of $8.4 million in impairment and abandonment charges of operating lease right-of-use and other assets in connection with restructuring activities of certain leased facilities, a decrease of $4.5 million in restructuring costs, a decrease of $3.8 million in consulting expenses, a decrease of $1.4 million in freight out, and a decrease of $1.1 million in commissions expenses.

[0000926326-24-000015:mdna:81]
Interest and Other Income (Expense), Net. Interest and other income (expense), net changed by $2.2 million for the three months ended March 31, 2024 compared to the three months ended March 31, 2023, primarily driven by a $2.9 million increase in other income and a $0.7 million increase in other expense. The increase in other income during the three months ended March 31, 2024 as compared to the three months ended March 31, 2023 is primarily attributable to higher interest income received due to higher interest rates and higher cash and cash equivalents balances.

[0000926326-24-000015:mdna:82]
Benefit from Income Taxes

[0000926326-24-000015:mdna:83]
|  | Three Months Ended March 31, |
|  |  |  |  |  | Change in |
|  | 2024 |  | 2023 |  | $ |  | % |
|  | (Dollars in thousands) |
| Benefit from income taxes | $ | (2,155) |  |  | $ | (6,182) |  |  | $ | 4,027 |  |  | (65)% |

[0000926326-24-000015:mdna:84]
For the three months ended March 31, 2024 and 2023, we recorded a benefit from income taxes of $2.2 million and $6.2 million, respectively. The change in the benefit from income taxes for the three months ended March 31, 2024 compared to the benefit from income taxes for the same period in 2023 was primarily due to a decrease in research and development credits, foreign-derived intangible income deduction and benefit from state taxes.

[0000926326-24-000015:mdna:85]
[same as prior period, unchanged from 0000926326-23-000041:mdna:99]

[0000926326-24-000015:mdna:86]
[same as prior period, unchanged from 0000926326-23-000041:mdna:100]

[0000926326-24-000015:mdna:87]
We had cash and cash equivalents of $512.4 million at March 31, 2024 compared to $468.0 million at December 31, 2023. All of our cash and cash equivalents are invested in bank accounts and money market funds held in sweep and asset management accounts with financial institutions of high credit quality.

[0000926326-24-000015:mdna:88]
Our cash position and working capital at March 31, 2024 and December 31, 2023 were as follows:

[0000926326-24-000015:mdna:89]
|  | March 31,2024 |  | December 31,2023 |
|  | (In thousands) |
| Cash and cash equivalents | $ | 512,364 |  |  | $ | 467,972 |  |
| Working capital | $ | 573,554 |  |  | $ | 559,779 |  |

[0000926326-24-000015:mdna:90]
Our ratio of current assets to current liabilities was 2.4:1 and 2.5:1 at March 31, 2024 and December 31, 2023, respectively.

[0000926326-24-000015:mdna:91]
[same as prior period, unchanged from 0000926326-23-000041:mdna:105]

[0000926326-24-000015:mdna:92]
Revolving Credit Facility

[0000926326-24-000015:mdna:93]
On November 15, 2019, we entered into an Amended and Restated Credit Agreement (as amended, the “Prior A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers, and Wells Fargo Bank, National Association, as administrative agent. The Prior A&R Credit Agreement provided for (a) a five-year revolving credit facility of $500.0 million (the “Prior Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million (the “Prior Incremental Facility”). In addition, the Prior A&R Credit Agreement included a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million.

[0000926326-24-000015:mdna:94]
On September 22, 2020 and March 29, 2023, we entered into amendments to the Prior A&R Credit Agreement to, among other changes, permit the issuance of the convertible senior notes and the purchase of the convertible note hedge transactions, as described in Note 10, Convertible Senior Notes, expand our flexibility to repurchase our common stock and

[0000926326-24-000015:mdna:95]
make other restricted payments, and replace the total net leverage covenant, as well as to remove and replace the interest rate benchmark based on the London interbank offered rate (“LIBOR”) and related LIBOR-based mechanics applicable to borrowings under the Prior A&R Credit Agreement with an interest rate benchmark based on the secured overnight financing rate (“SOFR”) as administered by the Federal Reserve Bank of New York and related SOFR-based mechanics.

[0000926326-24-000015:mdna:96]
On October 10, 2023, we entered into a Second Amended and Restated Credit Agreement (the “Second A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, JPMorgan Chase Bank, N.A., PNC Capital Markets LLC and TD Securities (USA) LLC as joint lead arrangers and Wells Fargo Bank, National Association, as administrative agent. The Second A&R Credit Agreement supersedes the Prior A&R Credit Agreement and provides for (a) a five-year revolving credit facility of $350.0 million (the “Current Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to an amount equal to the sum of (i) the greater of $250.0 million and 100% of the adjusted consolidated EBITDA for the last four quarters and (ii) additional amounts subject to pro forma compliance with certain consolidated secured net leverage ratio (the “Current Incremental Facility”). In addition, the Second A&R Credit Agreement includes a letter of credit sub-limit of up to $15 million and a swing line loan sub-limit of up to $25 million. The Second A&R Credit Agreement has an expiration date of October 10, 2028, subject to acceleration under certain conditions, upon which date all remaining outstanding borrowings will be due and payable.

[0000926326-24-000015:mdna:97]
As of March 31, 2024, we had $350.0 million of funds available under the Current Revolving Credit Facility. As of March 31, 2024, there was no outstanding balance under the Current Revolving Credit Facility and we were in full compliance with all covenants. Refer to Note 9, Debt and Credit Agreement, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional information. We expect to use future loans under the Current Revolving Credit Facility, if any, for working capital, potential acquisitions, and other general corporate purposes.

[0000926326-24-000015:mdna:98]
[same as prior period, unchanged from 0000926326-23-000041:mdna:111]

[0000926326-24-000015:mdna:99]
Our future uses of cash are expected to be primarily for working capital, capital expenditures, and other contractual obligations. We also expect a continued use of cash for potential acquisitions and acquisition-related activities, as well as repurchases of our common stock. In addition, we may also use a portion of our cash, as we consider various options related to our outstanding debt.

[0000926326-24-000015:mdna:100]
The 2016 Repurchase Program has a total of $2.7 million remaining for future repurchases as of March 31, 2024, which may result in additional use of cash. There were no stock repurchases during the three months ended March 31, 2024. Refer to “Stock Repurchase Programs” under Note 15, Employee Benefits and Share-Based Compensation, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional information.

[0000926326-24-000015:mdna:101]
Based on our current business plan and backlog, we believe that our existing cash and cash equivalents, our anticipated cash flows from operations, cash generated from the exercise of employee stock options and purchases under our Employee Stock Purchase Plan (“ESPP”), along with the availability of funds under the Current Revolving Credit Facility will be sufficient to meet our cash needs for working capital, capital expenditures, potential acquisitions, and other contractual obligations for at least the next twelve months. For periods beyond the next twelve months, we also anticipate that our net operating cash flows plus existing balances of cash and cash equivalents will suffice to fund the growth of our business.

[0000926326-24-000015:mdna:102]
[same as prior period, unchanged from 0000926326-23-000041:mdna:115]

[0000926326-24-000015:mdna:103]
[same as prior period, unchanged from 0000926326-23-000041:mdna:116]

[0000926326-24-000015:mdna:104]
|  | Three Months Ended March 31, |
|  | 2024 |  | 2023 |
|  | (In thousands) |
| Net cash provided by (used in): |  |  |  |
| Operating activities | $ | 49,953 |  |  | $ | 12,770 |  |
| Investing activities | (12,340) |  |  | (13,640) |  |
| Financing activities | 11,926 |  |  | 3,862 |  |
| Effect of exchange rate changes on cash and cash equivalents | (556) |  |  | 176 |  |
| Net increase in cash, cash equivalents, and restricted cash | $ | 48,983 |  |  | $ | 3,168 |  |

[0000926326-24-000015:mdna:105]
[same as prior period, unchanged from 0000926326-23-000041:mdna:118]

[0000926326-24-000015:mdna:106]
[same as prior period, unchanged from 0000926326-23-000041:mdna:119]

[0000926326-24-000015:mdna:107]
Net cash provided by operating activities was $50.0 million for the three months ended March 31, 2024, primarily consisting of a net loss of $15.7 million adjusted for non-cash items of $28.2 million and changes in assets and liabilities of $37.4 million. The non-cash items primarily consisted of depreciation and amortization expense of $21.3 million, share-based compensation expense of $8.6 million, amortization of operating lease right-of-use assets of $1.9 million, amortization of debt issuance costs of $1.0 million, and a change in deferred income taxes of $4.6 million. Changes in assets and liabilities include cash inflows primarily from (i) an increase in deferred revenues of $34.1 million primarily due to an increase in billings for certain technical service and Advanced Service offerings, (ii) a decrease in inventories of $6.3 million, primarily due to management of inventory levels to align with the current forecasted demand as well as inventory management efforts, (iii) an increase in accrued liabilities of $5.1 million, (iv) a decrease in accounts receivable and unbilled receivables of $3.4 million driven by overall business activity and the timing of billings, shipments, and collections, as well as the impacts of lower revenues, (v) a decrease in prepaid commissions of $2.2 million, (vi) a decrease in other current assets of $0.9 million, (vii) a decrease in other long-term assets of $0.8 million, and (viii) an increase in other long-term liabilities $0.8 million. These cash inflows were partially offset by (i) a decrease in accrued compensation of $10.3 million, primarily due to a decrease in the accrual for restructuring initiatives, as well as timing of payroll and ESPP purchases, (ii) a decrease in operating lease liabilities of $2.8 million, (iii) a decrease in accounts payables of $1.4 million, (iv) an increase in investment in sales-type leases of $1.1 million, and (v) an increase in prepaid expenses of $0.6 million.

[0000926326-24-000015:mdna:108]
Net cash provided by operating activities was $12.8 million for the three months ended March 31, 2023, primarily consisting of a net loss of $15.0 million and changes in assets and liabilities of $12.4 million, offset by non-cash items of $40.2 million. The non-cash items primarily consisted of depreciation and amortization expense of $22.0 million, share-based compensation expense of $14.0 million, amortization of operating lease right-of-use assets of $2.2 million, impairment and abandonment of operating lease right-of-use assets related to facilities of $7.8 million, amortization of debt issuance costs of $1.0 million, and a change in deferred income taxes of $7.8 million. Changes in assets and liabilities include cash outflows primarily from (i) a decrease in accrued compensation of $25.2 million, primarily due to a decrease in the accrual for restructuring initiatives, lower commissions, as well as timing of payroll and ESPP purchases, (ii) an increase in accounts receivable and unbilled receivables of $22.2 million, primarily due to the timing of billings, shipments and collections, and (iii) a decrease in operating lease liabilities of $2.7 million. These cash outflows were partially offset by (i) an increase in deferred revenues of $29.1 million, primarily due to an increase in billings for certain service and subscription offerings, (ii) a decrease in inventories of $6.8 million, primarily due to management of inventory levels to align with the current forecasted demand, and (iii) a decrease in prepaid commissions of $2.6 million.

[0000926326-24-000015:mdna:109]
[same as prior period, unchanged from 0000926326-23-000041:mdna:122]

[0000926326-24-000015:mdna:110]
Net cash used in investing activities was $12.3 million for the three months ended March 31, 2024, which consisted of capital expenditures of $9.0 million for property and equipment and $3.4 million for external-use software development costs.

[0000926326-24-000015:mdna:111]
Net cash used in investing activities was $13.6 million for the three months ended March 31, 2023, which consisted of capital expenditures of $10.1 million for property and equipment, and $3.5 million for external-use software development costs.

[0000926326-24-000015:mdna:112]
[same as prior period, unchanged from 0000926326-23-000041:mdna:125]

[0000926326-24-000015:mdna:113]
Net cash provided by financing activities was $11.9 million for the three months ended March 31, 2024, primarily due to $8.0 million in proceeds from employee stock option exercises and ESPP purchases and a net change in the customer funds balances of $4.6 million, partially offset by $0.7 million in employees’ taxes paid related to restricted stock unit vesting.

[0000926326-24-000015:mdna:114]
Net cash provided by financing activities was $3.9 million for the three months ended March 31, 2023, primarily due to $12.1 million in proceeds from employee stock option exercises and ESPP purchases, partially offset by $1.4 million in employees’ taxes paid related to restricted stock unit vesting and a net change in the customer funds balances of $6.9 million.

[0000926326-24-000015:mdna:115]
[same as prior period, unchanged from 0000926326-23-000041:mdna:128]

[0000926326-24-000015:mdna:116]
There have been no significant changes during the three months ended March 31, 2024 to the contractual obligations disclosed in “Management’s Discussion and Analysis of Financial Condition and Results of Operations,” set forth in Part II, Item 7, of our Annual Report on Form 10-K for the year ended December 31, 2023.

[0000926326-24-000015:mdna:117]
Contractual obligations as of March 31, 2024 were as follows:

[0000926326-24-000015:mdna:118]
|  | Payments Due By Period |
|  | Total |  | Remainder of 2024 |  | 2025 - 2026 |  | 2027 - 2028 |  | 2029 and thereafter |
|  | (In thousands) |
| Operating leases (1) | $ | 51,213 |  |  | $ | 9,688 |  |  | $ | 22,854 |  |  | $ | 16,806 |  |  | $ | 1,865 |  |
| Purchase obligations (2) | $ | 103,043 |  |  | 89,995 |  |  | 13,007 |  |  | 41 |  |  | — |  |
| Convertible senior notes (3) | $ | 577,157 |  |  | 719 |  |  | 576,438 |  |  | — |  |  | — |  |
| Total (4) | $ | 731,413 |  |  | $ | 100,402 |  |  | $ | 612,299 |  |  | $ | 16,847 |  |  | $ | 1,865 |  |

[0000926326-24-000015:mdna:119]
[same as prior period, unchanged from 0000926326-23-000041:mdna:132]

[0000926326-24-000015:mdna:120]
[same as prior period, unchanged from 0000926326-23-000041:mdna:133]

[0000926326-24-000015:mdna:121]
[same as prior period, unchanged from 0000926326-23-000041:mdna:134]

[0000926326-24-000015:mdna:122]
[same as prior period, unchanged from 0000926326-23-000041:mdna:135]

[0000926326-24-000015:mdna:123]
(4)Refer to Note 13, Commitments and Contingencies, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional information.
