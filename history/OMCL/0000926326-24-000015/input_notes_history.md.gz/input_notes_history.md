# OMCL note change history — 0000926326-23-000041 → 0000926326-24-000015


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-05-07):
[0000926326-24-000015:note_history:1]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of March 31, 2024, the Company had non-cancelable purchase commitments of $103.0 million, of which $90.0 million are expected to be paid within the year ending December 31, 2024.
  (was, 2023-11-03, similarity 0.9747):
[0000926326-23-000041:note_history:1]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of September 30, 2023, the Company had non-cancelable purchase commitments of $118.7 million, of which $78.1 million are expected to be paid within the year ending December 31, 2023.

- changed (2024-05-07):
[0000926326-24-000015:note_history:2]
As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any material accrual for contingent liabilities associated with any current legal proceedings based on its belief that any potential material loss, while reasonably possible, is not probable. Furthermore, any possible range of loss in such matters cannot be reasonably estimated at this time. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of legal proceedings or because of the diversion of management’s attention and the creation of significant expenses, regardless of outcome.
  (was, 2023-11-03, similarity 0.7915):
[0000926326-23-000041:note_history:2]
As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any material accrual for contingent liabilities associated with any current legal proceedings based on its belief that any potential material loss, while reasonably possible, is not probable. Furthermore, any possible range of loss in such matters cannot be reasonably estimated at this time. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However,

- removed (2024-05-07):
[0000926326-23-000041:note_history:3]
Ransomware Incident

- removed (2024-05-07):
[0000926326-23-000041:note_history:4]
During the nine months ended September 30, 2023, the Company did not incur any material expenses or recoveries related to the previously disclosed ransomware incident. During the three months ended September 30, 2022, the Company incurred $1.0 million of expenses related to the ransomware incident, and during the nine months ended September 30, 2022, the Company incurred $13.5 million of expenses related to the ransomware incident, partially offset by $11.1 million of expected insurance recoveries. Expenses include costs to investigate and remediate the ransomware incident, as well as legal and other professional services, all of which were expensed as incurred. For the three and nine months ended September 30, 2022, the Company included net expenses related to the ransomware incident in cost of revenues of $0.1 million and $0.3 million, respectively; in research and development of $0.2 million and $0.2 million, respectively; and in selling, general, and administrative expenses of $0.7 million and $1.9 million, respectively, in the Company’s Condensed Consolidated Statements of Operations.

- removed (2024-05-07):
[0000926326-23-000041:note_history:5]
As of September 30, 2023, the Company has incurred $13.6 million of cumulative expenses related to the ransomware incident since it was detected, partially offset by $11.6 million of insurance recoveries, all of which have been received as of September 30, 2023.

- removed (2024-05-07):
[0000926326-23-000041:note_history:6]
litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of legal proceedings or because of the diversion of management’s attention and the creation of significant expenses, regardless of outcome.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-05-07):
[0000926326-24-000015:note_history:7]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of March 31, 2024 and December 31, 2023, and the results of operations, comprehensive loss, and cash flows for the three months ended March 31, 2024 and 2023. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s Annual Report on Form 10-K for the year ended December 31, 2023, filed with the SEC on February 28, 2024. The Company’s results of operations, comprehensive loss, and cash flows for the three months ended March 31, 2024 are not necessarily indicative of results that may be expected for the year ending December 31, 2024, or for any future period.
  (was, 2023-11-03, similarity 0.8294):
[0000926326-23-000041:note_history:7]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of September 30, 2023 and December 31, 2022, the results of operations and comprehensive income (loss) for the three and nine months ended September 30, 2023 and 2022, and cash flows for the nine months ended September 30, 2023 and 2022. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s Annual Report on Form 10-K for the year ended December 31, 2022, filed with the SEC on March 1, 2023, except as discussed in the section entitled “Recently Adopted Authoritative Guidance” below. The Company’s results of operations and comprehensive income (loss) for the three and nine months ended September 30, 2023, and cash flows for the nine months ended September 30, 2023 are not necessarily indicative of results that may be expected for the year ending December 31, 2023, or for any future period.

- changed (2024-05-07):
[0000926326-24-000015:note_history:8]
The Company’s critical accounting policies are those that affect its financial statements materially and involve difficult, subjective, or complex judgments by management. As of March 31, 2024, the Company is not aware of any events or circumstances that would require an update to its estimates, judgments, or revisions to the carrying value of its assets or liabilities.
  (was, 2023-11-03, similarity 0.981):
[0000926326-23-000041:note_history:8]
The Company’s critical accounting policies are those that affect its financial statements materially and involve difficult, subjective, or complex judgments by management. As of September 30, 2023, the Company is not aware of any events or circumstances that would require an update to its estimates, judgments, or revisions to the carrying value of its assets or liabilities.

- changed (2024-05-07):
[0000926326-24-000015:note_history:9]
There was no recently adopted authoritative guidance that is expected to have a material impact on the Company’s Condensed Consolidated Financial Statements through the reporting date.
  (was, 2023-11-03, similarity 0.9396):
[0000926326-23-000041:note_history:9]
There was no recently issued and effective authoritative guidance that is expected to have a material impact on the Company’s Condensed Consolidated Financial Statements through the reporting date.

- added (2024-05-07):
[0000926326-24-000015:note_history:10]
In November 2023, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures, which requires public entities to disclose significant segment expenses that are regularly provided to the CODM. Public entities with a single reportable segment are required to apply the disclosure requirements in ASU 2023-07, as well as all existing segment disclosures and reconciliation requirements in ASC 280, on an interim and annual basis. The amendments are effective for the Company’s annual periods beginning January 1, 2024, and for interim periods within fiscal years beginning January 1, 2025. Retrospective application is required, with early adoption permitted. The Company is currently evaluating the impact ASU 2023-07 will have on its consolidated financial statements.

- added (2024-05-07):
[0000926326-24-000015:note_history:11]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which includes amendments that further enhance income tax disclosures, primarily through standardization and disaggregation of rate reconciliation categories and income taxes paid by jurisdiction. The amendments are effective for the Company’s annual periods beginning January 1, 2025, with early adoption permitted, and should be applied either prospectively or retrospectively. The Company is currently evaluating the impact ASU 2023-09 will have on its consolidated financial statements.

- added (2024-05-07):
[0000926326-24-000015:note_history:12]
There was no other recently issued and effective authoritative guidance that is expected to have a material impact on the Company’s Condensed Consolidated Financial Statements through the reporting date.

- removed (2024-05-07):
[0000926326-23-000041:note_history:13]
In October 2021, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. The update addresses diversity in practice by requiring that an acquirer recognize and measure contract assets and liabilities acquired in a business combination in accordance with Accounting Standards Codification (“ASC”) 606, Revenue from Contracts with Customers. The Company adopted ASU 2021-08 beginning January 1, 2023 and will apply the guidance prospectively to acquisitions occurring on or after the adoption date.


## omcl:ScheduleOfInterestExpenseDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-05-07):
[0000926326-24-000015:note_history:14]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three months ended March 31, 2024 and 2023:
  (was, 2023-11-03, similarity 0.9022):
[0000926326-23-000041:note_history:14]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three and nine months ended September 30, 2023 and 2022:

- changed (2024-05-07):
[0000926326-24-000015:note_history:15]
|  | Three Months Ended March 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
|  | (In thousands) |
| Contractual coupon interest | $ | 359 |  |  | $ | 359 |  |  |  |  |  |
| Amortization of debt issuance costs | $ | 777 |  |  | $ | 771 |  |  |  |  |  |
  (was, 2023-11-03, similarity 0.6992):
[0000926326-23-000041:note_history:15]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  | (In thousands) |
| Contractual coupon interest | $ | 359 |  |  | $ | 359 |  |  | $ | 1,078 |  |  | $ | 1,078 |  |
| Amortization of debt issuance costs | $ | 773 |  |  | $ | 768 |  |  | $ | 2,316 |  |  | $ | 2,298 |  |


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-05-07):
[0000926326-24-000015:note_history:16]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of March 31, 2024 and December 31, 2023:
  (was, 2023-11-03, similarity 0.963):
[0000926326-23-000041:note_history:16]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of September 30, 2023 and December 31, 2022:

- added (2024-05-07):
[0000926326-24-000015:note_history:17]
|  | March 31,2024 |  | December 31,2023 |
|  | (In thousands) |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized debt issuance costs | (4,561) |  |  | (5,338) |  |
| Convertible senior notes, net | $ | 570,439 |  |  | $ | 569,662 |  |

- removed (2024-05-07):
[0000926326-23-000041:note_history:18]
|  | September 30,2023 |  | December 31,2022 |
|  | (In thousands) |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized debt issuance costs | (6,113) |  |  | (8,429) |  |
| Convertible senior notes, net | $ | 568,887 |  |  | $ | 566,571 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-05-07):
[0000926326-24-000015:note_history:19]
Debt and Credit Agreement
On November 15, 2019, the Company entered into an Amended and Restated Credit Agreement (as amended, the “Prior A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers, and Wells Fargo Bank, National Association, as administrative agent. The Prior A&R Credit Agreement provided for (a) a five-year revolving credit facility of $500.0 million (the “Prior Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million (the “Prior Incremental Facility”). In addition, the Prior A&R Credit Agreement included a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million.
  (was, 2023-11-03, similarity 0.9121):
[0000926326-23-000041:note_history:19]
Debt and Credit AgreementOn November 15, 2019, the Company entered into an Amended and Restated Credit Agreement (as amended, the “Prior A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers, and Wells Fargo Bank, National Association, as administrative 
agent. The Prior A&R Credit Agreement provided for (a) a five-year revolving credit facility of $500.0 million (the “Prior Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million (the “Prior Incremental Facility”). In addition, the Prior A&R Credit Agreement included a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The Prior A&R Credit Agreement had an expiration date of November 15, 2024, upon which date all remaining outstanding borrowings would be due and payable.

- changed (2024-05-07):
[0000926326-24-000015:note_history:20]
On September 22, 2020 and March 29, 2023, the Company entered into amendments to the Prior A&R Credit Agreement to, among other changes, permit the issuance of the convertible senior notes and the purchase of the convertible note hedge transactions, as described in Note 10, Convertible Senior Notes, expand the Company’s flexibility to repurchase its common stock and make other restricted payments, and replace the total net leverage covenant as well as to remove and replace the interest rate benchmark based on the London interbank offered rate (“LIBOR”) and related LIBOR-based mechanics applicable to borrowings under the Prior A&R Credit Agreement with an interest rate benchmark based on the secured overnight financing rate (“SOFR”) as administered by the Federal Reserve Bank of New York and related SOFR-based mechanics.
  (was, 2023-11-03, similarity 0.8565):
[0000926326-23-000041:note_history:20]
On September 22, 2020 and March 29, 2023, the Company entered into amendments to the Prior A&R Credit Agreement to, among other changes, permit the issuance of the convertible senior notes and the purchase of the convertible note hedge transactions, as described in Note 10, Convertible Senior Notes, expand the Company’s flexibility to repurchase its common stock and make other restricted payments, and replace the total net leverage covenant with a new secured net leverage covenant that requires the Company to maintain a consolidated secured net leverage ratio not to exceed 3.50:1 for the calendar quarters ending September 30, 2020, December 31, 2020, and March 31, 2021 and 3.00:1 for the calendar quarters ending thereafter, as well as to remove and replace the interest rate benchmark based on the London interbank offered rate (“LIBOR”) and related LIBOR-based mechanics applicable to borrowings under the A&R Credit Agreement with an interest rate benchmark based on the secured overnight financing rate (“SOFR”) as administered by the Federal Reserve Bank of New York and related SOFR-based mechanics.

- changed (2024-05-07):
[0000926326-24-000015:note_history:21]
The Company entered into a Second Amended and Restated Credit Agreement (the “Second A&R Credit Agreement”) on October 10, 2023, with the lenders from time to time party thereto, Wells Fargo Securities, LLC, JPMorgan Chase Bank, N.A., PNC Capital Markets LLC and TD Securities (USA) LLC as joint lead arrangers and Wells Fargo Bank, National Association, as administrative agent. The Second A&R Credit Agreement supersedes the Prior A&R Credit Agreement and provides for (a) a five-year revolving credit facility of $350.0 million (the “Current Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to an amount equal to the sum of (i) the greater of $250.0 million or 100% of the
  (was, 2023-11-03, similarity 0.6954):
[0000926326-23-000041:note_history:21]
Subsequent to the quarter ended September 30, 2023, the Company entered into a Second Amended and Restated Credit Agreement (the “Second A&R Credit Agreement”) on October 10, 2023, with the lenders from time to time party thereto, Wells Fargo Securities, LLC, JPMorgan Chase Bank, N.A., PNC Capital Markets LLC and TD Securities (USA) LLC as joint lead arrangers and Wells Fargo Bank, National Association, as administrative agent. The Second A&R Credit Agreement supersedes the Prior A&R Credit Agreement and provides for (a) a five-year revolving credit facility of $350.0 million (the “Current Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to an amount equal to the sum of (i) the greater of $250.0 million or 100% of the adjusted consolidated EBITDA for the last four quarters and (ii) additional amounts subject to pro forma compliance with certain consolidated secured net leverage ratio (the “Current Incremental Facility”). In addition, the Second A&R Credit Agreement includes a letter of credit sub-limit of up to $15 million and a swing line loan sub-limit of up to $25 million. The Second A&R Credit Agreement has an expiration date of October 10, 2028, subject to acceleration under certain conditions, upon which date all remaining outstanding borrowings will be due and payable.

- added (2024-05-07):
[0000926326-24-000015:note_history:22]
adjusted consolidated EBITDA for the last four quarters and (ii) additional amounts subject to pro forma compliance with certain consolidated secured net leverage ratio (the “Current Incremental Facility”). In addition, the Second A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The Second A&R Credit Agreement has an expiration date of October 10, 2028, subject to acceleration under certain conditions, upon which date all remaining outstanding borrowings will be due and payable.

- changed (2024-05-07):
[0000926326-24-000015:note_history:23]
Loans under the Current Revolving Credit Facility bear interest, at the Company’s option, at a rate equal to either (a) the Adjusted Term SOFR (as defined in the Second A&R Credit Agreement), plus an applicable margin ranging from 1.50% to 2.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the Second A&R Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) the Adjusted Term SOFR for an interest period of one month plus 1.00%, plus an applicable margin ranging from 0.50% to 1.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio. Undrawn commitments under the Current Revolving Credit Facility are subject to a commitment fee ranging from 0.20% to 0.35% per annum based on the Company’s Consolidated Total Net Leverage Ratio on the average daily unused portion of the Current Revolving Credit Facility. Subject to the terms and conditions of the Current Revolving Credit Facility or Current Incremental Facility the Company is permitted to make voluntary prepayments at any time without payment of a premium or penalty. The availability of funds under the Current Revolving Credit Facility may be subject to reduction in order to maintain compliance with the financial covenants under the Second A&R Credit Agreement.
  (was, 2023-11-03, similarity 0.9391):
[0000926326-23-000041:note_history:23]
Loans under the Current Revolving Credit Facility bear interest, at the Company’s option, at a rate equal to either (a) the Adjusted Term SOFR (as defined in the Second A&R Credit Agreement), plus an applicable margin ranging from 1.50% to 2.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the Second A&R Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) the Adjusted Term SOFR for an interest period of one month plus 1.00%, plus an applicable margin ranging from 0.50% to 1.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio. Undrawn commitments under the Current Revolving Credit Facility are subject to a commitment fee ranging from 0.20% to 0.35% per annum based on the Company’s Consolidated Total Net Leverage Ratio on the average daily unused portion of the Current Revolving Credit Facility. Subject to the terms and conditions of the Current Revolving Credit Facility or Current Incremental Facility, the Company is permitted to make voluntary prepayments at any time without payment of a premium or penalty. The availability of funds under the Current

- changed (2024-05-07):
[0000926326-24-000015:note_history:24]
The Second A&R Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends, and other distributions. The Second A&R Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum consolidated secured net leverage ratio (not to exceed 3.00:1) and maintain a minimum consolidated interest coverage ratio (not to be less than 3.00:1). In addition, the Second A&R Credit Agreement contains certain customary events of default including, but not limited to, failure to pay interest, principal, and fees, or other amounts when due, material misrepresentations or misstatements in any representation or warranty, covenant defaults, certain cross defaults to other material indebtedness, certain judgment defaults, and events of bankruptcy.
  (was, 2023-11-03, similarity 0.9995):
[0000926326-23-000041:note_history:24]
The Second A&R Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends, and other distributions. The Second A&R Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum consolidated secured net leverage ratio (not to exceed 3.00:1) and maintain a minimum consolidated interest coverage ratio (not to be less than 3.00:1). In addition, the Second A&R Credit Agreement contains certain customary events of default including, but not limited to, failure to pay interest, principal and fees, or other amounts when due, material misrepresentations or misstatements in any representation or warranty, covenant defaults, certain cross defaults to other material indebtedness, certain judgment defaults, and events of bankruptcy.

- changed (2024-05-07):
[0000926326-24-000015:note_history:25]
The Company’s obligations under the Second A&R Credit Agreement and, at the election of the Company and the contracting counterparty, any secured swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and such subsidiary guarantors’ assets. In connection with entering into the Second A&R Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a reaffirmation agreement, which amends certain terms of the existing collateral agreement and reaffirms their obligations under the existing guaranty agreement.
  (was, 2023-11-03, similarity 0.9994):
[0000926326-23-000041:note_history:25]
The Company’s obligations under the Second A&R Credit Agreement and, at the election of the Company and the contracting counterparty, any secured swap obligations and banking services obligations owing to a lender (or an affiliate of a lender), are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and such subsidiary guarantors’ assets. In connection with entering into the Second A&R Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a reaffirmation agreement, which amends certain terms of the existing collateral agreement and reaffirms their obligations under the existing guaranty agreement.

- added (2024-05-07):
[0000926326-24-000015:note_history:26]
The refinancing of the Prior Credit Agreement was evaluated in accordance with ASC 470-50, Debt - Modifications and Extinguishments. In determining whether the refinancing was to be accounted for as a debt extinguishment or a debt modification, the Company considered whether lenders within the syndicate remained the same or changed and whether the changes in debt terms were substantial. This assessment was performed on an individual lender basis within the syndicate. As a result, the refinancing was accounted for as a modification with the exception of certain lenders that exited the syndicate. The exit of certain lenders resulted in an immaterial write-off of existing unamortized debt issuance costs. The remaining unamortized debt issuance costs related to debt modification, along with the new deferred costs, will be amortized over the remaining term of the Second A&R Credit Agreement.

- added (2024-05-07):
[0000926326-24-000015:note_history:27]
In connection with entering into the Second A&R Credit Agreement on October 10, 2023, the Company incurred and capitalized an additional $3.0 million of debt issuance costs. The debt issuance costs are being amortized to interest expense using the straight-line method through 2028.

- changed (2024-05-07):
[0000926326-24-000015:note_history:28]
As of both March 31, 2024 and December 31, 2023, the Company had $350.0 million of funds available under the Current Revolving Credit Facility. As of March 31, 2024 and December 31, 2023, the Company had no outstanding balance under the Current Revolving Credit Facility. The Company was in compliance with all covenants as of March 31, 2024.
Convertible Senior Notes
0.25% Convertible Senior Notes due 2025
  (was, 2023-11-03, similarity 0.7174):
[0000926326-23-000041:note_history:28]
As of both September 30, 2023 and December 31, 2022, the Company had $500.0 million of funds available under the Prior Revolving Credit Facility. As of September 30, 2023 and December 31, 2022, the Company had no outstanding balance under the Prior Revolving Credit Facility. The Company was in compliance with all covenants of the Prior A&R Credit Agreement as of September 30, 2023. Upon entry into the Second A&R Credit Agreement, the Company had $350.0 million of funds available under the Current Revolving Credit Facility. 
Convertible Senior Notes
0.25% Convertible Senior Notes due 2025

- changed (2024-05-07):
[0000926326-24-000015:note_history:29]
On September 25, 2020, the Company completed a private offering of $575.0 million aggregate principal amount of 0.25% convertible senior notes (the “Notes”), including the exercise in full of the initial purchasers’ option to purchase up to an additional $75.0 million principal amount of the Notes. The Company received proceeds from the issuance of the Notes of $559.7 million, net of $15.3 million of transaction fees and other debt issuance costs. The Notes bear interest at a rate of 0.25%
  (was, 2023-11-03, similarity 0.6938):
[0000926326-23-000041:note_history:29]
On September 25, 2020, the Company completed a private offering of $575.0 million aggregate principal amount of 0.25% convertible senior notes (the “Notes”), including the exercise in full of the initial purchasers’ option to purchase up to an additional $75.0 million principal amount of the Notes. The Company received proceeds from the issuance of the Notes of $559.7 million, net of $15.3 million of transaction fees and other debt issuance costs. The Notes bear interest at a rate of 0.25% per year, payable semiannually in arrears on March 15 and September 15 of each year, beginning on March 15, 2021. The Notes were issued pursuant to an indenture, dated September 25, 2020 (the “Indenture”), between the Company and U.S. Bank National Association, as trustee. The Notes are general senior, unsecured obligations of the Company and will mature on September 15, 2025, unless earlier redeemed, repurchased, or converted.

- added (2024-05-07):
[0000926326-24-000015:note_history:30]
per year, payable semiannually in arrears on March 15 and September 15 of each year, beginning on March 15, 2021. The Notes were issued pursuant to an indenture, dated September 25, 2020 (the “Indenture”), between the Company and U.S. Bank National Association, as trustee. The Notes are general senior, unsecured obligations of the Company and will mature on September 15, 2025, unless earlier redeemed, repurchased, or converted.

- changed (2024-05-07):
[0000926326-24-000015:note_history:31]
During the three months ended March 31, 2024 and December 31, 2023, none of the conditional conversion features of the Notes were triggered, and therefore, the Notes are not convertible during the second quarter of 2024, commencing on April 1, 2024, and were not convertible during the first quarter of 2024, commencing on January 1, 2024. Accordingly, the Company classified the Notes as a long-term liability in its Condensed Consolidated Financial Statements as of both March 31, 2024 and December 31, 2023. Whether the Notes will be convertible following the second fiscal quarter of 2024 will depend on the satisfaction of the conversion conditions in the future.
  (was, 2023-11-03, similarity 0.9492):
[0000926326-23-000041:note_history:31]
During the three months ended September 30, 2023 and December 31, 2022, none of the conditional conversion features of the Notes were triggered, and therefore, the Notes are not convertible during the fourth quarter of 2023, commencing on October 1, 2023, and were not convertible during the first quarter of 2023, commencing on January 1, 2023. Accordingly, the Company classified the Notes as a long-term liability in its Condensed Consolidated Financial Statements as of both September 30, 2023 and December 31, 2022. Whether the Notes will be convertible following the fourth fiscal quarter of 2023 will depend on the satisfaction of the conversion conditions in the future.

- changed (2024-05-07):
[0000926326-24-000015:note_history:32]
If the Company undergoes a fundamental change, holders may require, subject to certain exceptions, the Company to repurchase for cash all or any portion of their Notes at a fundamental change repurchase price equal to 100% of the principal amount of the Notes to be repurchased, plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date. As of March 31, 2024, none of the criteria for a fundamental change or a conversion rate adjustment had been met.
  (was, 2023-11-03, similarity 0.9854):
[0000926326-23-000041:note_history:32]
If the Company undergoes a fundamental change, holders may require, subject to certain exceptions, the Company to repurchase for cash all or any portion of their Notes at a fundamental change repurchase price equal to 100% of the principal amount of the Notes to be repurchased, plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date. As of September 30, 2023, none of the criteria for a fundamental change or a conversion rate adjustment had been met.

- changed (2024-05-07):
[0000926326-24-000015:note_history:33]
As of March 31, 2024, the Company may redeem for cash all or any portion of the Notes, at its option, if the last reported sale price of the Company’s common stock has been at least 130% of the conversion price for the Notes then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which the Company provides notice of redemption at a redemption price equal to 100% of the principal amount of the Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. If the Company redeems less than all of the outstanding Notes, at least $150.0 million aggregate principal amount of Notes must be outstanding and not subject to redemption as of the date of the relevant notice of redemption. No sinking fund is provided for in the Notes.
  (was, 2023-11-03, similarity 0.9925):
[0000926326-23-000041:note_history:33]
As of September 20, 2023, the Company may redeem for cash all or any portion of the Notes, at its option, if the last reported sale price of the Company’s common stock has been at least 130% of the conversion price for the Notes then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which the Company provides notice of redemption at a redemption price equal to 100% of the principal amount of the Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. If the Company redeems less than all of the outstanding Notes, at least $150.0 million aggregate principal amount of Notes must be outstanding and not subject to redemption as of the date of the relevant notice of redemption. No sinking fund is provided for in the Notes.

- changed (2024-05-07):
[0000926326-24-000015:note_history:34]
The debt issuance costs associated with the Notes are being amortized to interest expense over the term of the Notes using an effective interest rate of 0.80%. As of March 31, 2024, the remaining life of the Notes and the related issuance cost accretion is approximately 1.5 years.
  (was, 2023-11-03, similarity 0.9743):
[0000926326-23-000041:note_history:34]
The debt issuance costs associated with the Notes are being amortized to interest expense over the term of the Notes using an effective interest rate of 0.80%. As of September 30, 2023, the remaining life of the Notes and the related issuance cost accretion is approximately 2.0 years.

- changed (2024-05-07):
[0000926326-24-000015:note_history:35]
The maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to other conversion rate adjustments, would be 5.9 million shares. As of March 31, 2024, the if-converted value of the Notes did not exceed the principal amount.
  (was, 2023-11-03, similarity 0.9738):
[0000926326-23-000041:note_history:35]
The maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to other conversion rate adjustments, would be 5.9 million shares. As of September 30, 2023, the if-converted value of the Notes did not exceed the principal amount.

- changed (2024-05-07):
[0000926326-24-000015:note_history:36]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of March 31, 2024 and December 31, 2023:
  (was, 2023-11-03, similarity 0.963):
[0000926326-23-000041:note_history:36]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of September 30, 2023 and December 31, 2022:

- added (2024-05-07):
[0000926326-24-000015:note_history:37]
|  | March 31,2024 |  | December 31,2023 |
|  | (In thousands) |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized debt issuance costs | (4,561) |  |  | (5,338) |  |
| Convertible senior notes, net | $ | 570,439 |  |  | $ | 569,662 |  |

- changed (2024-05-07):
[0000926326-24-000015:note_history:38]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three months ended March 31, 2024 and 2023:
  (was, 2023-11-03, similarity 0.9022):
[0000926326-23-000041:note_history:38]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three and nine months ended September 30, 2023 and 2022:

- changed (2024-05-07):
[0000926326-24-000015:note_history:39]
|  | Three Months Ended March 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
|  | (In thousands) |
| Contractual coupon interest | $ | 359 |  |  | $ | 359 |  |  |  |  |  |
| Amortization of debt issuance costs | $ | 777 |  |  | $ | 771 |  |  |  |  |  |
  (was, 2023-11-03, similarity 0.6992):
[0000926326-23-000041:note_history:39]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  | (In thousands) |
| Contractual coupon interest | $ | 359 |  |  | $ | 359 |  |  | $ | 1,078 |  |  | $ | 1,078 |  |
| Amortization of debt issuance costs | $ | 773 |  |  | $ | 768 |  |  | $ | 2,316 |  |  | $ | 2,298 |  |

- removed (2024-05-07):
[0000926326-23-000041:note_history:40]
Loans under the Prior Revolving Credit Facility bore interest, at the Company’s option, at a rate equal to either (a) the Adjusted Term SOFR (as defined in the Prior A&R Credit Agreement), plus an applicable margin ranging from 1.25% to 2.00% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the Prior A&R Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) Adjusted Term SOFR for a one month tenor plus 1.00%, plus an applicable margin ranging from 0.25% to 1.00% per annum based on the Company’s Consolidated Total Net Leverage Ratio. Undrawn commitments under the Prior Revolving Credit Facility were subject to a commitment fee ranging from 0.15% to 0.30% per annum based on the Company’s Consolidated Total Net Leverage Ratio on the average daily unused portion of the Prior Revolving Credit Facility. The applicable margin for, and certain other terms of, any term loans under the Prior Incremental Facility would be determined prior to the incurrence of such loans. The Company was permitted to make voluntary prepayments at any time without payment of a premium or penalty.

- removed (2024-05-07):
[0000926326-23-000041:note_history:41]
The Prior A&R Credit Agreement contained customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends, and other distributions. The Prior A&R Credit Agreement also contained financial covenants that required the Company and its subsidiaries to not exceed a maximum total secured net leverage ratio (as described above) and maintain a minimum interest coverage ratio. In addition, the Prior A&R Credit Agreement contained certain customary events of default including, but not limited to, failure to pay interest, principal, and fees, or other amounts when due, material misrepresentations or misstatements in any representation or warranty, covenant defaults, certain cross defaults to other material indebtedness, certain judgment defaults, and events of bankruptcy.

- removed (2024-05-07):
[0000926326-23-000041:note_history:42]
Revolving Credit Facility may be subject to reduction in order to maintain compliance with the financial covenants under the Second A&R Credit Agreement.

- removed (2024-05-07):
[0000926326-23-000041:note_history:43]
|  | September 30,2023 |  | December 31,2022 |
|  | (In thousands) |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized debt issuance costs | (6,113) |  |  | (8,429) |  |
| Convertible senior notes, net | $ | 568,887 |  |  | $ | 566,571 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2024-05-07):
[0000926326-24-000015:note_history:44]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”) and Federal agencies that purchase under a Federal Supply Schedule Contract with the Department of Veterans

- changed (2024-05-07):
[0000926326-24-000015:note_history:45]
Affairs (the “GSA Contract”). GPOs are often fully or partially owned by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company also pays the Industrial Funding Fee (“IFF”) to the Department of Veterans Affairs under the GSA Contract. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs and the IFF were $2.0 million and $3.1 million for the three months ended March 31, 2024 and 2023, respectively.
  (was, 2023-11-03, similarity 0.7515):
[0000926326-23-000041:note_history:45]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”) and Federal agencies that purchase under a Federal Supply Schedule Contract with the Department of Veterans Affairs (the “GSA Contract”). GPOs are often fully or partially owned by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company also pays the Industrial Funding Fee (“IFF”) to the Department of Veterans Affairs under the GSA Contract. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs and the IFF were $3.6 million and $4.8 million for the three months ended September 30, 2023 and 2022, respectively, and $9.5 million and $13.3 million for the nine months ended September 30, 2023 and 2022, respectively.

- changed (2024-05-07):
[0000926326-24-000015:note_history:46]
The following table summarizes the Company’s revenues disaggregated by revenue type for the three months ended March 31, 2024 and 2023:
  (was, 2023-11-03, similarity 0.9288):
[0000926326-23-000041:note_history:46]
The following table summarizes the Company’s revenues disaggregated by revenue type for the three and nine months ended September 30, 2023 and 2022:

- changed (2024-05-07):
[0000926326-24-000015:note_history:47]
|  | Three Months Ended March 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
|  | (In thousands) |
| Connected devices, software licenses, and other | $ | 111,069 |  |  | $ | 165,147 |  |  |  |  |  |
| Consumables | 22,226 |  |  | 20,568 |  |  |  |  |  |
| Technical services | 58,515 |  |  | 53,357 |  |  |  |  |  |
| Advanced Services | 54,341 |  |  | 51,557 |  |  |  |  |  |
| Total revenues | $ | 246,151 |  |  | $ | 290,629 |  |  |  |  |  |
  (was, 2023-11-03, similarity 0.7708):
[0000926326-23-000041:note_history:47]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  | (In thousands) |
| Connected devices, software licenses, and other | $ | 167,560 |  |  | $ | 226,415 |  |  | $ | 500,182 |  |  | $ | 650,125 |  |
| Consumables | 21,195 |  |  | 20,150 |  |  | 62,724 |  |  | 56,121 |  |
| Technical services | 57,303 |  |  | 53,914 |  |  | 167,851 |  |  | 156,386 |  |
| Advanced Services | 52,605 |  |  | 47,580 |  |  | 157,508 |  |  | 135,641 |  |
| Total revenues | $ | 298,663 |  |  | $ | 348,059 |  |  | $ | 888,265 |  |  | $ | 998,273 |  |

- changed (2024-05-07):
[0000926326-24-000015:note_history:48]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location, for the three months ended March 31, 2024 and 2023:
  (was, 2023-11-03, similarity 0.9493):
[0000926326-23-000041:note_history:48]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location, for the three and nine months ended September 30, 2023 and 2022:

- changed (2024-05-07):
[0000926326-24-000015:note_history:49]
|  | Three Months Ended March 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
|  | (In thousands) |
| United States | $ | 218,176 |  |  | $ | 255,943 |  |  |  |  |  |
| Rest of world (1) | 27,975 |  |  | 34,686 |  |  |  |  |  |
| Total revenues | $ | 246,151 |  |  | $ | 290,629 |  |  |  |  |  |
  (was, 2023-11-03, similarity 0.695):
[0000926326-23-000041:note_history:49]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  | (In thousands) |
| United States | $ | 272,649 |  |  | $ | 315,755 |  |  | $ | 785,794 |  |  | $ | 898,269 |  |
| Rest of world (1) | 26,014 |  |  | 32,304 |  |  | 102,471 |  |  | 100,004 |  |
| Total revenues | $ | 298,663 |  |  | $ | 348,059 |  |  | $ | 888,265 |  |  | $ | 998,273 |  |

- changed (2024-05-07):
[0000926326-24-000015:note_history:50]
|  | March 31,2024 |  | December 31,2023 |
|  | (In thousands) |
| Short-term unbilled receivables, net (1) | $ | 22,661 |  |  | $ | 22,524 |  |
| Long-term unbilled receivables, net (2) | 10,360 |  |  | 11,850 |  |
| Total contract assets | $ | 33,021 |  |  | $ | 34,374 |  |
| Short-term deferred revenues | $ | 164,586 |  |  | $ | 121,734 |  |
| Long-term deferred revenues | 65,195 |  |  | 58,622 |  |
| Total contract liabilities | $ | 229,781 |  |  | $ | 180,356 |  |
  (was, 2023-11-03, similarity 0.975):
[0000926326-23-000041:note_history:50]
|  | September 30,2023 |  | December 31,2022 |
|  | (In thousands) |
| Short-term unbilled receivables, net (1) | $ | 20,275 |  |  | $ | 25,763 |  |
| Long-term unbilled receivables, net (2) | 13,159 |  |  | 14,744 |  |
| Total contract assets | $ | 33,434 |  |  | $ | 40,507 |  |
| Short-term deferred revenues, net | $ | 124,991 |  |  | $ | 118,947 |  |
| Long-term deferred revenues | 55,053 |  |  | 37,385 |  |
| Total contract liabilities | $ | 180,044 |  |  | $ | 156,332 |  |

- added (2024-05-07):
[0000926326-24-000015:note_history:51]
Short-term deferred revenues of $121.7 million as of December 31, 2023 include deferred revenues from product sales and service contracts, net of deferred cost of sales of $12.4 million. During the three months ended March 31, 2024, the

- added (2024-05-07):
[0000926326-24-000015:note_history:52]
Company recognized revenues of $50.2 million, that were included in the corresponding gross short-term deferred revenues balance of $134.1 million as of December 31, 2023.

- added (2024-05-07):
[0000926326-24-000015:note_history:53]
Deferred revenues from product sales primarily relate to delivered and invoiced products, pending installation and acceptance. Deferred revenues from service contracts primarily relate to services that have been invoiced, where services have not yet been provided. Short-term deferred revenues are expected to be recognized within the next twelve months. Long-term deferred revenues substantially consist of deferred revenues on long-term technical and Advanced Services contracts which have been invoiced and are expected to be recognized as revenue beyond twelve months, generally not more than ten years. The Company generally invoices customers for products upon shipment. Invoicing associated with the service portion of agreements is generally periodic and is billed on a monthly, quarterly, or annual basis, and in certain circumstances, multiple years are billed at one time. Advanced Services agreements are generally invoiced periodically on a monthly, quarterly or annual basis over the life of the agreement. In certain circumstances portions of these agreements may be invoiced lump sum.

- changed (2024-05-07):
[0000926326-24-000015:note_history:54]
In addition, the Company has remaining performance obligations associated with contracts for which the associated products have been accepted or associated services have started, but where invoicing has not yet occurred and therefore are not reflected in deferred revenue. These remaining performance obligations are comprised of the non-variable portions of technical services and Advanced Services provided under non-cancellable contracts with minimum commitments. Remaining performance obligations which are not included in deferred revenues are $359.0 million as of March 31, 2024. Remaining performance obligations are expected to be recognized ratably over the remaining terms of the associated contracts, which terms vary but are generally not more than ten years. Remaining performance obligations do not include product obligations, services where the associated product has not been accepted, services which have not yet started, variable portions of services, and certain other obligations.
  (was, 2023-11-03, similarity 0.993):
[0000926326-23-000041:note_history:54]
In addition, the Company has remaining performance obligations associated with contracts for which the associated products have been accepted or associated services have started, but where invoicing has not yet occurred and therefore are not reflected in deferred revenue. These remaining performance obligations are comprised of the non-variable portions of technical services and Advanced Services provided under non-cancellable contracts with minimum commitments. Remaining performance obligations which are not included in deferred revenues are $344.8 million as of September 30, 2023. Remaining performance obligations are expected to be recognized ratably over the remaining terms of the associated contracts, which terms vary but are generally not more than ten years. Remaining performance obligations do not include product obligations, services where the associated product has not been accepted, services which have not yet started, variable portions of services, and certain other obligations.

- changed (2024-05-07):
[0000926326-24-000015:note_history:55]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three months ended March 31, 2024 and 2023. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable balance as of March 31, 2024 and December 31, 2023.
  (was, 2023-11-03, similarity 0.8115):
[0000926326-23-000041:note_history:55]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three and nine months ended September 30, 2023 and 2022. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable balance as of September 30, 2023 and December 31, 2022.

- removed (2024-05-07):
[0000926326-23-000041:note_history:56]
Short-term deferred revenues of $125.0 million and $118.9 million include deferred revenues from product sales and service contracts, net of deferred cost of sales of $12.4 million and $15.8 million, as of September 30, 2023 and December 31, 2022, respectively. During the three and nine months ended September 30, 2023, the Company recognized revenues of $20.1 million and $106.2 million, respectively, that were included in the corresponding gross short-term deferred revenues balance of $134.7 million as of December 31, 2022. Long-term deferred revenues include deferred revenues from product sales and service contracts of $55.1 million and $37.4 million as of September 30, 2023 and December 31, 2022, respectively. Deferred revenues from product sales primarily relate to delivered and invoiced products, pending installation and acceptance. Deferred revenues from service contracts primarily relate to services that have been invoiced, where services have not yet been provided.

- removed (2024-05-07):
[0000926326-23-000041:note_history:57]
Short-term deferred revenues are expected to be recognized within the next twelve months. Long-term deferred revenues substantially consist of deferred revenues on long-term service contracts which have been invoiced and are expected to be recognized as revenue beyond twelve months, generally not more than ten years. The Company generally invoices customers for products upon shipment. Invoicing associated with the service portion of agreements is generally periodic and is billed on a monthly, quarterly, or annual basis, and in certain circumstances, multiple years are billed at one time.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2024-05-07):
[0000926326-24-000015:note_history:58]
Subsequent Events
On May 2, 2024, the Company announced management’s commitment to the wind down of the Company’s RDS product line, subject to local law and statutory works council consultation requirements. The Company estimates that it will incur approximately $15 million to $20 million of aggregate nonrecurring charges related to the expected reduction in headcount and real estate footprint, and expects that the remaining charges will be incurred in the remainder of 2024 and 2025. Refer to Note 16, Restructuring Expenses, for additional information.

- removed (2024-05-07):
[0000926326-23-000041:note_history:59]
Subsequent Events
Second Amended and Restated Credit Agreement

- removed (2024-05-07):
[0000926326-23-000041:note_history:60]
On October 10, 2023, the Company entered into the Second A&R Credit Agreement with the lenders from time to time party thereto, Wells Fargo Securities, LLC, JPMorgan Chase Bank, N.A., PNC Capital Markets LLC and TD Securities (USA) LLC as joint lead arrangers and Wells Fargo Bank, National Association, as administrative agent. The Second A&R Credit Agreement supersedes the Company’s Prior A&R Credit Agreement. Refer to Note 9, Debt and Credit Agreement, for additional information.

- removed (2024-05-07):
[0000926326-23-000041:note_history:61]
Restructuring Plan

- removed (2024-05-07):
[0000926326-23-000041:note_history:62]
On November 2, 2023, the Company announced a plan to reduce the Company’s headcount and real estate footprint (the “2023 Plan”) as part of the Company’s expense containment initiatives and other actions to reduce discretionary spending being implemented due to challenging industry dynamics and macroeconomic conditions. In connection with the 2023 Plan, the Company estimates that it will incur approximately $12 million to $18 million of nonrecurring restructuring and related charges, consisting of (i) approximately $9 million to $12 million of cash-based charges related to the reduction in headcount, which primarily consist of employee severance and benefits costs and (ii) approximately $3 million to $6 million of non-cash charges related to office closure, which the Company expects to incur the majority of charges in the fourth quarter of 2023 with remaining charges incurred in future periods. The Company expects to substantially complete the 2023 Plan, including cash payments, by the end of the second quarter of 2024, subject to local laws and consultation requirements.
