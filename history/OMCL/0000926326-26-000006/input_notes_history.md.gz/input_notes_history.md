# OMCL note change history — 0000926326-25-000019 → 0000926326-25-000031


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-11-05):
[0000926326-25-000031:note_history:1]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of September 30, 2025, the Company had non-cancelable purchase commitments of $135.0 million, of which $82.1 million are expected to be paid within the year ending December 31, 2025.
  (was, 2025-08-06, similarity 0.9765):
[0000926326-25-000019:note_history:1]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of June 30, 2025, the Company had non-cancelable purchase commitments of $139.2 million, of which $111.4 million are expected to be paid within the year ending December 31, 2025.

- removed (2025-11-05):
[0000926326-25-000019:note_history:2]
In December 2023, Omnicell received a civil request for records issued by the U.S. Attorney’s Office for the Eastern District of Washington (the “Government”) related to the Company’s compliance with the pricing terms and conditions of its previous Federal Supply Schedule (“FSS”) contract with the federal government. In December 2024, the Government presented information identifying certain potential non-compliances with the FSS contract and associated potential violations of the False Claims Act. On May 5, 2025, Omnicell entered into a settlement agreement with the Government to resolve this matter. The settlement, which settled the matter without admission of liability, required payment of approximately $4.6 million to cover damages and other statutorily provided amounts under the False Claims Act, which was paid on May 19, 2025. The Company does not expect further engagement with the federal Government regarding this matter.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-11-05):
[0000926326-25-000031:note_history:3]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of September 30, 2025 and December 31, 2024, and the results of operations and comprehensive income (loss) for the three and nine months ended September 30, 2025 and 2024, and cash flows for the nine months ended September 30, 2025 and 2024. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s Annual Report on Form 10-K for the year ended December 31, 2024, filed with the SEC on February 27, 2025. The Company’s results of operations and comprehensive income (loss) for the three and nine months ended September 30, 2025, and cash flows for the nine months ended September 30, 2025 are not necessarily indicative of results that may be expected for the year ending December 31, 2025, or for any future period.
  (was, 2025-08-06, similarity 0.826):
[0000926326-25-000019:note_history:3]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of June 30, 2025 and December 31, 2024, and the results of operations and comprehensive income (loss) for the three and six months ended June 30, 2025 and 2024, and cash flows for the six months ended June 30, 2025 and 2024. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s Annual Report on Form 10-K for the year ended December 31, 2024, filed with the SEC on February 27, 2025. The Company’s results of operations and comprehensive income (loss) for the three and six months ended June 30, 2025, and cash flows for the six months ended June 30, 2025 are not necessarily indicative of results that may be expected for the year ending December 31, 2025, or for any future period.

- changed (2025-11-05):
[0000926326-25-000031:note_history:4]
The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s Condensed Consolidated Financial Statements and accompanying Notes to Condensed Consolidated Financial Statements. These estimates are based on historical experience and various other assumptions that management believes to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. The Company’s critical accounting estimates are those that affect its financial statements materially and involve difficult, subjective, or complex judgments by management. Those estimates are revenue recognition, inventory valuation, and accounting for income taxes. As of September 30, 2025, the Company is not aware of any events or circumstances that would require an update to its estimates, judgments, or revisions to the carrying value of its assets or liabilities.
  (was, 2025-08-06, similarity 0.83):
[0000926326-25-000019:note_history:4]
The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s Condensed Consolidated Financial Statements and accompanying Notes to Condensed Consolidated Financial Statements. These estimates are based on historical experience and various other assumptions that management believes to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. The Company’s critical accounting estimates are those that affect its financial statements materially and involve difficult, subjective, or complex judgments by management. Those estimates are revenue recognition, inventory valuation, and accounting for income taxes. As of June 30, 2025, the Company is not aware of any events or circumstances that would require an update to its estimates, judgments, or revisions to the carrying value of its assets or liabilities.

- changed (2025-11-05):
[0000926326-25-000031:note_history:5]
In December 2023, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which includes amendments that further enhance income tax disclosures, primarily through standardization and disaggregation of rate reconciliation categories and income taxes paid by jurisdiction. The amendments are effective for the Company’s annual periods beginning January 1, 2025, with early adoption permitted, and should be applied either prospectively or retrospectively. The Company plans to adopt ASU 2023-09 on a prospective basis for its fiscal year beginning January 1, 2025. Because the standard only affects disclosure requirements and not recognition or measurement of income taxes, the Company does not expect adoption to have a material impact on its consolidated financial condition, results of operations, or cash flows. The Company is currently evaluating the impact of the required disclosures on its consolidated financial statement disclosures.
  (was, 2025-08-06, similarity 0.6682):
[0000926326-25-000019:note_history:5]
In December 2023, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which includes amendments that further enhance income tax disclosures, primarily through standardization and disaggregation of rate reconciliation categories and income taxes paid by jurisdiction. The amendments are effective for the Company’s annual periods beginning January 1, 2025, with early adoption permitted, and should be applied either prospectively or retrospectively. The Company is currently evaluating the impact ASU 2023-09 will have on its consolidated financial statements, which is limited to financial statements disclosures.

- added (2025-11-05):
[0000926326-25-000031:note_history:6]
In September 2025, the FASB issued ASU 2025-06, Intangibles—Goodwill and Other—Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal Use Software, which removes all references to software development project stages, and requires capitalization of software costs to begin when (i) management has authorized and committed to funding the software project, and (ii) it is probable the project will be completed and the software will be used to perform its intended function. The amendments are effective for the Company’s annual periods beginning January 1, 2028, and for interim periods within fiscal years beginning January 1, 2028, with early adoption permitted, and can be applied prospectively, retrospectively, or utilizing a modified transition approach. The Company is currently evaluating the impact ASU 2025-06 will have on its consolidated financial statements.


## omcl:ScheduleOfInterestExpenseDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2025-11-05):
[0000926326-25-000031:note_history:7]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  | (In thousands) |
| Contractual coupon interest: |  |  |  |  |  |  |  |
| 2025 Notes | $ | 91 |  |  | $ | 359 |  |  | $ | 310 |  |  | $ | 1,078 |  |
| 2029 Notes | $ | 431 |  |  | $ | — |  |  | 1,294 |  |  | — |  |
| Amortization of debt issuance costs: |  |  |  |  |  |  |  |
| 2025 Notes | $ | 199 |  |  | $ | 780 |  |  | $ | 676 |  |  | $ | 2,335 |  |
| 2029 Notes | $ | 300 |  |  | $ | — |  |  | 897 |  |  | — |  |

- removed (2025-11-05):
[0000926326-25-000019:note_history:8]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  | (In thousands) |
| Contractual coupon interest: |  |  |  |  |  |  |  |
| 2025 Notes | $ | 110 |  |  | $ | 359 |  |  | $ | 219 |  |  | $ | 719 |  |
| 2029 Notes | $ | 432 |  |  | $ | — |  |  | 863 |  |  | — |  |
| Amortization of debt issuance costs: |  |  |  |  |  |  |  |
| 2025 Notes | $ | 239 |  |  | $ | 778 |  |  | $ | 477 |  |  | $ | 1,555 |  |
| 2029 Notes | $ | 294 |  |  | $ | — |  |  | 597 |  |  | — |  |


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-11-05):
[0000926326-25-000031:note_history:9]
|  | September 30,2025 |  | December 31,2024 |
|  | (In thousands) |
| 2025 Notes: |  |  |  |
| Principal amount | $ | — |  |  | $ | 175,000 |  |
| Unamortized debt issuance costs | — |  |  | (676) |  |
| Convertible senior notes, net, current | $ | — |  |  | $ | 174,324 |  |
| 2029 Notes: |  |  |  |
| Principal amount | $ | 172,500 |  |  | $ | 172,500 |  |
| Unamortized debt issuance costs | (5,206) |  |  | (6,103) |  |
| Convertible senior notes, net, noncurrent | $ | 167,294 |  |  | $ | 166,397 |  |
  (was, 2025-08-06, similarity 0.6876):
[0000926326-25-000019:note_history:9]
|  | June 30,2025 |  | December 31,2024 |
|  | (In thousands) |
| 2025 Notes: |  |  |  |
| Principal amount | $ | 175,000 |  |  | $ | 175,000 |  |
| Unamortized debt issuance costs | (199) |  |  | (676) |  |
| Convertible senior notes, net, current | $ | 174,801 |  |  | $ | 174,324 |  |
| 2029 Notes: |  |  |  |
| Principal amount | $ | 172,500 |  |  | $ | 172,500 |  |
| Unamortized debt issuance costs | (5,506) |  |  | (6,103) |  |
| Convertible senior notes, net, noncurrent | $ | 166,994 |  |  | $ | 166,397 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-11-05):
[0000926326-25-000031:note_history:10]
Omnicell, Inc. entered into a Second Amended and Restated Credit Agreement (the “Second A&R Credit Agreement”) on October 10, 2023, with the lenders from time to time party thereto, Wells Fargo Securities, LLC, JPMorgan Chase Bank, N.A., PNC Capital Markets LLC and TD Securities (USA) LLC as joint lead arrangers and Wells Fargo Bank, National Association, as administrative agent. The Second A&R Credit Agreement supersedes the Prior A&R Credit Agreement and provides for (a) a five-year revolving credit facility of $350.0 million (the “Current Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to an amount equal to the sum of (i) the greater of $250.0 million and 100% of the adjusted consolidated EBITDA for the last four quarters and (ii) additional amounts subject to pro forma compliance with certain consolidated secured net leverage ratio (the “Current Incremental Facility”). In addition, the Second A&R Credit
  (was, 2025-08-06, similarity 0.9376):
[0000926326-25-000019:note_history:10]
Omnicell, Inc. entered into a Second Amended and Restated Credit Agreement (the “Second A&R Credit Agreement”) on October 10, 2023, with the lenders from time to time party thereto, Wells Fargo Securities, LLC, JPMorgan Chase Bank, N.A., PNC Capital Markets LLC and TD Securities (USA) LLC as joint lead arrangers and Wells Fargo Bank, National Association, as administrative agent. The Second A&R Credit Agreement supersedes the Prior A&R Credit Agreement and provides for (a) a five-year revolving credit facility of $350.0 million (the “Current Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to an amount equal to the sum of (i) the greater of $250.0 million and 100% of the adjusted consolidated EBITDA for the last four quarters and (ii) additional amounts subject to pro forma compliance with certain consolidated secured net leverage ratio (the “Current Incremental Facility”). In addition, the Second A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The

- changed (2025-11-05):
[0000926326-25-000031:note_history:11]
Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The Second A&R Credit Agreement has an expiration date of October 10, 2028, subject to acceleration under certain conditions, upon which date all remaining outstanding borrowings will be due and payable.
  (was, 2025-08-06, similarity 0.7554):
[0000926326-25-000019:note_history:11]
Second A&R Credit Agreement has an expiration date of October 10, 2028, subject to acceleration under certain conditions, upon which date all remaining outstanding borrowings will be due and payable.

- added (2025-11-05):
[0000926326-25-000031:note_history:12]
As of both September 30, 2025 and December 31, 2024, the Company had $350.0 million of funds available under the Current Revolving Credit Facility. As of September 30, 2025 and December 31, 2024, the Company had no outstanding balance under the Current Revolving Credit Facility. The Company was in compliance with all covenants as of September 30, 2025.
Convertible Senior Notes
0.25% Convertible Senior Notes due 2025

- changed (2025-11-05):
[0000926326-25-000031:note_history:13]
On September 25, 2020, Omnicell, Inc. completed a private offering of $575.0 million aggregate principal amount of 0.25% convertible senior notes (the “2025 Notes”), including the exercise in full of the initial purchasers’ option to purchase up to an additional $75.0 million principal amount of the 2025 Notes. As referred to in this Note 11, “Omnicell, Inc.” or the “Company” refers only to Omnicell, Inc., excluding its subsidiaries. Omnicell, Inc. received proceeds from the issuance of the 2025 Notes of $559.7 million, net of $15.3 million of transaction fees and other debt issuance costs. The 2025 Notes were issued pursuant to an indenture, dated September 25, 2020 (the “2025 Notes Indenture”), between the Company and U.S. Bank National Association, as trustee. Prior to maturity, the 2025 Notes were general senior, unsecured obligations of the Company and bore interest at a rate of 0.25% per year, payable semiannually in arrears on March 15 and September 15 of each year, beginning on March 15, 2021.
  (was, 2025-08-06, similarity 0.7368):
[0000926326-25-000019:note_history:13]
On September 25, 2020, Omnicell, Inc. completed a private offering of $575.0 million aggregate principal amount of 0.25% convertible senior notes (the “2025 Notes”), including the exercise in full of the initial purchasers’ option to purchase up to an additional $75.0 million principal amount of the 2025 Notes. As referred to in this Note 11, “Omnicell, Inc.” or the “Company” refers only to Omnicell, Inc., excluding its subsidiaries. Omnicell, Inc. received proceeds from the issuance of the 2025 Notes of $559.7 million, net of $15.3 million of transaction fees and other debt issuance costs. The 2025 Notes bear interest at a rate of 0.25% per year, payable semiannually in arrears on March 15 and September 15 of each year, beginning on March 15, 2021. The 2025 Notes were issued pursuant to an indenture, dated September 25, 2020 (the “2025 Notes Indenture”), between the Company and U.S. Bank National Association, as trustee. The 2025 Notes are general senior, unsecured obligations of the Company and will mature on September 15, 2025, unless earlier redeemed, repurchased, or converted.

- added (2025-11-05):
[0000926326-25-000031:note_history:14]
The 2025 Notes matured on September 15, 2025 and the Company repaid the remaining principal balance of $175.0 million and $0.2 million of accrued interest in cash.

- changed (2025-11-05):
[0000926326-25-000031:note_history:15]
During the three months ended September 30, 2025 and December 31, 2024, none of the conditional conversion features of the 2029 Notes were triggered, and therefore, the 2029 Notes are not convertible during the fourth quarter of 2025, commencing on October 1, 2025, and were not convertible during the first quarter of 2025, commencing on January 1, 2025.
  (was, 2025-08-06, similarity 0.9445):
[0000926326-25-000019:note_history:15]
During the three months ended June 30, 2025 and December 31, 2024, none of the conditional conversion features of the 2029 Notes were triggered, and therefore, the 2029 Notes are not convertible during the third quarter of 2025, commencing on July 1, 2025, and were not convertible during the first quarter of 2025, commencing on January 1, 2025.

- changed (2025-11-05):
[0000926326-25-000031:note_history:16]
If the Company undergoes a fundamental change (as defined in the 2029 Notes Indenture), holders may require, subject to certain exceptions, the Company to repurchase for cash all or any portion of their 2029 Notes at a fundamental change repurchase price equal to 100% of the principal amount of the 2029 Notes to be repurchased, plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date. As of September 30, 2025, none of the criteria for a fundamental change or a conversion rate adjustment had been met.
  (was, 2025-08-06, similarity 0.82):
[0000926326-25-000019:note_history:16]
If the Company undergoes a fundamental change (as defined in the 2029 Notes Indenture), holders may require, subject to certain exceptions, the Company to repurchase for cash all or any portion of their 2029 Notes at a fundamental change repurchase price equal to 100% of the principal amount of the 2029 Notes to be repurchased, plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date. As of June 30, 2025, none of the criteria for a fundamental change or a conversion rate adjustment had been met.

- changed (2025-11-05):
[0000926326-25-000031:note_history:17]
The debt issuance costs associated with the 2029 Notes are being amortized to interest expense over the term of the 2029 Notes using an effective interest rate of 1.75%. As of September 30, 2025, the remaining life of the 2029 Notes and the related issuance cost accretion is approximately 4.2 years.
  (was, 2025-08-06, similarity 0.9766):
[0000926326-25-000019:note_history:17]
The debt issuance costs associated with the 2029 Notes are being amortized to interest expense over the term of the 2029 Notes using an effective interest rate of 1.75%. As of June 30, 2025, the remaining life of the 2029 Notes and the related issuance cost accretion is approximately 4.4 years.

- added (2025-11-05):
[0000926326-25-000031:note_history:18]
The maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to other conversion rate adjustments, would be approximately 3.0 million shares. As of September 30, 2025, the if-converted value of the 2029 Notes did not exceed the principal amount.

- changed (2025-11-05):
[0000926326-25-000031:note_history:19]
|  | September 30,2025 |  | December 31,2024 |
|  | (In thousands) |
| 2025 Notes: |  |  |  |
| Principal amount | $ | — |  |  | $ | 175,000 |  |
| Unamortized debt issuance costs | — |  |  | (676) |  |
| Convertible senior notes, net, current | $ | — |  |  | $ | 174,324 |  |
| 2029 Notes: |  |  |  |
| Principal amount | $ | 172,500 |  |  | $ | 172,500 |  |
| Unamortized debt issuance costs | (5,206) |  |  | (6,103) |  |
| Convertible senior notes, net, noncurrent | $ | 167,294 |  |  | $ | 166,397 |  |
  (was, 2025-08-06, similarity 0.6876):
[0000926326-25-000019:note_history:19]
|  | June 30,2025 |  | December 31,2024 |
|  | (In thousands) |
| 2025 Notes: |  |  |  |
| Principal amount | $ | 175,000 |  |  | $ | 175,000 |  |
| Unamortized debt issuance costs | (199) |  |  | (676) |  |
| Convertible senior notes, net, current | $ | 174,801 |  |  | $ | 174,324 |  |
| 2029 Notes: |  |  |  |
| Principal amount | $ | 172,500 |  |  | $ | 172,500 |  |
| Unamortized debt issuance costs | (5,506) |  |  | (6,103) |  |
| Convertible senior notes, net, noncurrent | $ | 166,994 |  |  | $ | 166,397 |  |

- added (2025-11-05):
[0000926326-25-000031:note_history:20]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  | (In thousands) |
| Contractual coupon interest: |  |  |  |  |  |  |  |
| 2025 Notes | $ | 91 |  |  | $ | 359 |  |  | $ | 310 |  |  | $ | 1,078 |  |
| 2029 Notes | $ | 431 |  |  | $ | — |  |  | 1,294 |  |  | — |  |
| Amortization of debt issuance costs: |  |  |  |  |  |  |  |
| 2025 Notes | $ | 199 |  |  | $ | 780 |  |  | $ | 676 |  |  | $ | 2,335 |  |
| 2029 Notes | $ | 300 |  |  | $ | — |  |  | 897 |  |  | — |  |

- changed (2025-11-05):
[0000926326-25-000031:note_history:21]
The convertible note hedges related to the 2025 Notes consisted of call options for the Company to purchase, subject to anti-dilution adjustments substantially similar to those applicable to the 2025 Notes, up to approximately 5.9 million shares of the Company’s common stock, which is equal to the number of shares of the Company’s common stock underlying the 2025 Notes at the time of its issuance, at an initial strike price of approximately $97.32 per share. The convertible note hedges related to the 2029 Notes consisted of call options for the Company to purchase up to, subject to anti-dilution adjustments substantially similar to those applicable to the 2029 Notes, approximately 3.0 million shares of the Company’s common stock, which is equal to the number of shares of the Company’s common stock underlying the 2029 Notes at the time of its issuance, at an initial strike price of approximately $57.25 per share. The convertible note hedges expire upon the maturity of the respective convertible notes, if not earlier exercised or terminated. The cost of the convertible note hedges related to the 2025 Notes and the 2029 Notes was approximately $100.6 million and $40.3 million, respectively, and each was accounted for as an equity instrument, each of which was recorded in additional paid-in capital in the Condensed Consolidated Balance Sheets. In addition, the Company recorded a deferred tax asset of $25.8 million and $10.2 million, respectively, at issuance related to the convertible note hedges for the 2025 Notes and the 2029 Notes. The 2029 Notes convertible note hedges are expected generally
  (was, 2025-08-06, similarity 0.9202):
[0000926326-25-000019:note_history:21]
The convertible note hedges related to the 2025 Notes consisted of call options for the Company to purchase, subject to anti-dilution adjustments substantially similar to those applicable to the 2025 Notes, up to approximately 5.9 million shares of the Company’s common stock, which is equal to the number of shares of the Company’s common stock underlying the 2025 Notes at the time of its issuance, at an initial strike price of approximately $97.32 per share. The convertible note hedges related to the 2029 Notes consisted of call options for the Company to purchase up to, subject to anti-dilution adjustments substantially similar to those applicable to the 2029 Notes, approximately 3.0 million shares of the Company’s common stock, which is equal to the number of shares of the Company’s common stock underlying the 2029 Notes at the time of its issuance, at an initial strike price of approximately $57.25 per share. The convertible note hedges will expire upon the maturity of the respective convertible notes, if not earlier exercised or terminated. The cost of the convertible note hedges related to the 2025 Notes and the 2029 Notes was approximately $100.6 million and $40.3 million, respectively, and each was accounted for as an equity instrument, each of which was recorded in additional paid-in capital in the Condensed Consolidated Balance Sheets. In addition, the Company recorded a deferred tax asset of $25.8 million and $10.2 million, respectively, at issuance related to the convertible note hedges for the 2025 Notes and the 2029 Notes. The convertible note hedges are expected generally to reduce the potential dilution to the Company’s common stock upon any conversion of the 2025 Notes or the 2029 Notes and/or offset any cash payments the Company may be required to make in excess of the principal amount of the converted 2025 Notes or the 2029 Notes.

- added (2025-11-05):
[0000926326-25-000031:note_history:22]
to reduce the potential dilution to the Company’s common stock upon any conversion of the 2029 Notes and/or offset any cash payments the Company may be required to make in excess of the principal amount of the converted 2029 Notes.

- changed (2025-11-05):
[0000926326-25-000031:note_history:23]
Separately from the convertible note hedges, in September 2020 and November 2024, the Company entered into warrant transactions to sell to the respective option counterparties warrants to acquire, subject to customary anti-dilution adjustments, up to approximately 5.9 million shares of its common stock at an initial strike price of approximately $141.56 and approximately 3.0 million shares of its common stock at an initial strike price of approximately $84.82 per share related to the 2025 Notes and the 2029 Notes, respectively. The warrants require net share or net cash settlement upon the Company’s election. The Company received aggregate proceeds of approximately $51.3 million and $25.2 million for the issuance of the warrants related to the 2025 Notes and the 2029 Notes, respectively, which was recorded in additional paid-in capital at issuance in the Condensed Consolidated Balance Sheets. The warrants could separately have a dilutive effect to the Company’s common stock to the extent that the market price per share of its common stock, as measured under the warrants, exceeds the strike price of the warrants.
  (was, 2025-08-06, similarity 0.6942):
[0000926326-25-000019:note_history:23]
Separately from the convertible note hedges, in September 2020 and November 2024, the Company entered into warrant transactions to sell to the respective option counterparties warrants to acquire, subject to customary anti-dilution adjustments, up to approximately 5.9 million shares of its common stock at an initial strike price of approximately $141.56 and approximately 3.0 million shares of its common stock at an initial strike price of approximately $84.82 per share related to the 2025 Notes and the 2029 Notes, respectively. The warrants require net share or net cash settlement upon the Company’s

- added (2025-11-05):
[0000926326-25-000031:note_history:24]
In November 2024, in connection with the partial repurchase of the 2025 Notes, the Company entered into unwind agreements with the existing option counterparties to the convertible note hedges and warrants related to the 2025 Notes to terminate a portion of the existing convertible note hedges and warrants related to the 2025 Notes at a notional amount corresponding to the amount of the 2025 Notes repurchased, resulting in an immaterial gain.
On September 15, 2025, the convertible note hedges related to the remaining 2025 Notes expired concurrently with the maturity of the 2025 Notes. No settlement was required as the Company’s stock price remained below the strike price at that time. In addition, following maturity of the 2025 Notes, the warrants issued in connection with the 2025 Notes will terminate between December 15, 2025 and June 8, 2026.

- removed (2025-11-05):
[0000926326-25-000019:note_history:25]
On November 18, 2024, Omnicell, Inc., as borrower, entered into a First Amendment to Second Amended and Restated Credit Agreement (the “Amendment”) with the lenders party thereto from time to time, and Wells Fargo Bank, National Association, as administrative agent for the lenders. Pursuant to the Amendment, effective as of November 19, 2024, the springing maturity for the revolving credit facility that is tied to the outstanding principal amount of Omnicell, Inc.’s existing 0.25% Convertible Senior Notes due 2025 (the “2025 Notes”) will apply only if more than $200 million in the aggregate principal amount of the 2025 Notes remain outstanding as of 91 days prior to the maturity date of the 2025 Notes.

- removed (2025-11-05):
[0000926326-25-000019:note_history:26]
As of both June 30, 2025 and December 31, 2024, the Company had $350.0 million of funds available under the Current Revolving Credit Facility. As of June 30, 2025 and December 31, 2024, the Company had no outstanding balance under the Current Revolving Credit Facility. The Company was in compliance with all covenants as of June 30, 2025.
Convertible Senior Notes
0.25% Convertible Senior Notes due 2025

- removed (2025-11-05):
[0000926326-25-000019:note_history:27]
During the three months ended June 30, 2025 and December 31, 2024, none of the conditional conversion features of the 2025 Notes were triggered. As of May 15, 2025, until the close of business on the second scheduled trading day immediately preceding the maturity date, holders of the 2025 Notes may convert all or any portion of their 2025 Notes at any

- removed (2025-11-05):
[0000926326-25-000019:note_history:28]
time. As the 2025 Notes will mature on September 15, 2025, the Company classified the 2025 Notes as a current liability in its Condensed Consolidated Financial Statements as of both June 30, 2025 and December 31, 2024.

- removed (2025-11-05):
[0000926326-25-000019:note_history:29]
Under the original terms of the 2025 Notes Indenture, upon conversion, the Company could satisfy its conversion obligation by paying or delivering cash, shares of its common stock, or a combination thereof, at the Company’s election, in the manner and subject to the terms and conditions provided in the 2025 Notes Indenture. On December 13, 2021, the Company irrevocably elected to fix its settlement method to a combination of cash and shares of the Company’s common stock with the specified cash amount per $1,000 principal amount of 2025 Notes of at least $1,000. As a result, for 2025 Notes converted on or after December 13, 2021, a converting noteholder will receive (i) up to $1,000 in cash per $1,000 principal amount of 2025 Notes and (ii) as of May 15, 2025, a converting noteholder will receive shares of the Company’s common stock for any conversion consideration in excess of $1,000. The initial conversion rate for the 2025 Notes is 10.2751 shares of the Company’s common stock per $1,000 principal amount of 2025 Notes, which is equivalent to an initial conversion price of approximately $97.32 per share of the Company’s common stock, subject to adjustment under certain circumstances in accordance with the terms of the 2025 Notes Indenture. In addition, following certain corporate events that could occur prior to the maturity date of the 2025 Notes or if the Company delivers a notice of redemption in respect of the 2025 Notes, the Company will, under certain circumstances, increase the conversion rate of the 2025 Notes for a holder who elects to convert its 2025 Notes (or any portion thereof) in connection with such a corporate event or convert its 2025 Notes called (or deemed called) for redemption during the related redemption period (as defined in the 2025 Notes Indenture), as the case may be.

- removed (2025-11-05):
[0000926326-25-000019:note_history:30]
If the Company undergoes a fundamental change, holders may require, subject to certain exceptions, the Company to repurchase for cash all or any portion of their 2025 Notes at a fundamental change repurchase price equal to 100% of the principal amount of the 2025 Notes to be repurchased, plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date. As of June 30, 2025, none of the criteria for a fundamental change or a conversion rate adjustment had been met.

- removed (2025-11-05):
[0000926326-25-000019:note_history:31]
As of June 30, 2025, the Company may redeem for cash all or any portion of the 2025 Notes, at its option, if the last reported sale price of the Company’s common stock has been at least 130% of the conversion price for the 2025 Notes then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which the Company provides notice of redemption at a redemption price equal to 100% of the principal amount of the 2025 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. If the Company redeems less than all of the outstanding 2025 Notes, at least $150.0 million aggregate principal amount of the 2025 Notes must be outstanding and not subject to redemption as of the date of the relevant notice of redemption. No sinking fund is provided for in the 2025 Notes.

- removed (2025-11-05):
[0000926326-25-000019:note_history:32]
Partial Repurchase of the 2025 Notes

- removed (2025-11-05):
[0000926326-25-000019:note_history:33]
The debt issuance costs associated with the remaining 2025 Notes are being amortized to interest expense over the term of the 2025 Notes using an effective interest rate of 0.80%. As of June 30, 2025, the remaining life of the 2025 Notes and the related issuance cost accretion is approximately 0.2 years.

- removed (2025-11-05):
[0000926326-25-000019:note_history:34]
Following the partial repurchase of the 2025 Notes, the maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to other conversion rate adjustments, would be 1.8 million shares. As of June 30, 2025, the if-converted value of the 2025 Notes did not exceed the principal amount.

- removed (2025-11-05):
[0000926326-25-000019:note_history:35]
The maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to other conversion rate adjustments, would be 3.0 million shares. As of June 30, 2025, the if-converted value of the 2029 Notes did not exceed the principal amount.

- removed (2025-11-05):
[0000926326-25-000019:note_history:36]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  | (In thousands) |
| Contractual coupon interest: |  |  |  |  |  |  |  |
| 2025 Notes | $ | 110 |  |  | $ | 359 |  |  | $ | 219 |  |  | $ | 719 |  |
| 2029 Notes | $ | 432 |  |  | $ | — |  |  | 863 |  |  | — |  |
| Amortization of debt issuance costs: |  |  |  |  |  |  |  |
| 2025 Notes | $ | 239 |  |  | $ | 778 |  |  | $ | 477 |  |  | $ | 1,555 |  |
| 2029 Notes | $ | 294 |  |  | $ | — |  |  | 597 |  |  | — |  |

- removed (2025-11-05):
[0000926326-25-000019:note_history:37]
election. The Company received aggregate proceeds of approximately $51.3 million and $25.2 million for the issuance of the warrants related to the 2025 Notes and the 2029 Notes, respectively, which was recorded in additional paid-in capital at issuance in the Condensed Consolidated Balance Sheets. The warrants could separately have a dilutive effect to the Company’s common stock to the extent that the market price per share of its common stock, as measured under the warrants, exceeds the strike price of the warrants.
In November 2024, in connection with the partial repurchase of the 2025 Notes, the Company entered into unwind agreements with the existing option counterparties to the convertible note hedges and warrants related to the 2025 Notes to terminate a portion of the existing convertible note hedges and warrants related to the 2025 Notes at a notional amount corresponding to the amount of the 2025 Notes repurchased, resulting in an immaterial gain


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2025-11-05):
[0000926326-25-000031:note_history:38]
|  | September 30,2025 |  | December 31,2024 |
|  | (In thousands) |
| Net carrying amount: |  |  |  |
| 2025 Notes | — |  |  | 174,324 |  |
| 2029 Notes | 167,294 |  |  | 166,397 |  |
| Total net carrying amount | $ | 167,294 |  |  | $ | 340,721 |  |
| Fair value: |  |  |  |
| 2025 Notes | $ | — |  |  | $ | 167,129 |  |
| 2029 Notes | 159,908 |  |  | 181,320 |  |
| Total fair value | $ | 159,908 |  |  | $ | 348,449 |  |

- removed (2025-11-05):
[0000926326-25-000019:note_history:39]
|  | June 30,2025 |  | December 31,2024 |
|  | (In thousands) |
| Net carrying amount: |  |  |  |
| 2025 Notes | 174,801 |  |  | 174,324 |  |
| 2029 Notes | 166,994 |  |  | 166,397 |  |
| Total net carrying amount | $ | 341,795 |  |  | $ | 340,721 |  |
| Fair value: |  |  |  |
| 2025 Notes | $ | 172,043 |  |  | $ | 167,129 |  |
| 2029 Notes | 154,560 |  |  | 181,320 |  |
| Total fair value | $ | 326,603 |  |  | $ | 348,449 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-11-05):
[0000926326-25-000031:note_history:40]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  | (In thousands) |
| Connected devices, software licenses, and other | $ | 152,561 |  |  | $ | 135,672 |  |  | $ | 411,258 |  |  | $ | 381,280 |  |
| Consumables | 24,937 |  |  | 22,689 |  |  | 74,580 |  |  | 66,956 |  |
| Technical services | 67,275 |  |  | 59,583 |  |  | 192,420 |  |  | 177,419 |  |
| SaaS and Expert Services | 65,858 |  |  | 64,476 |  |  | 192,603 |  |  | 179,704 |  |
| Total revenues | $ | 310,631 |  |  | $ | 282,420 |  |  | $ | 870,861 |  |  | $ | 805,359 |  |
  (was, 2025-08-06, similarity 0.9156):
[0000926326-25-000019:note_history:40]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  | (In thousands) |
| Connected devices, software licenses, and other | $ | 138,620 |  |  | $ | 134,539 |  |  | $ | 258,697 |  |  | $ | 245,608 |  |
| Consumables | 24,552 |  |  | 22,041 |  |  | 49,643 |  |  | 44,267 |  |
| Technical services | 63,766 |  |  | 59,321 |  |  | 125,145 |  |  | 117,836 |  |
| SaaS and Expert Services | 63,624 |  |  | 60,887 |  |  | 126,745 |  |  | 115,228 |  |
| Total revenues | $ | 290,562 |  |  | $ | 276,788 |  |  | $ | 560,230 |  |  | $ | 522,939 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-11-05):
[0000926326-25-000031:note_history:41]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”) and Federal agencies that purchase under a Federal Supply Schedule Contract with the Department of Veterans Affairs (the “GSA Contract”). GPOs are often fully or partially owned by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company also pays the Industrial Funding Fee (“IFF”) to the Department of Veterans Affairs under the GSA Contract. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs and the IFF were $2.8 million and $2.5 million for the three months ended September 30, 2025 and 2024, respectively, and $6.6 million and $6.9 million for the nine months ended September 30, 2025 and 2024, respectively.
  (was, 2025-08-06, similarity 0.9623):
[0000926326-25-000019:note_history:41]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”) and Federal agencies that purchase under a Federal Supply Schedule Contract with the Department of Veterans Affairs (the “GSA Contract”). GPOs are often fully or partially owned by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company also pays the Industrial Funding Fee (“IFF”) to the Department of Veterans Affairs under the GSA Contract. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs and the IFF were $1.6 million and $2.4 million for the three months ended June 30, 2025 and 2024, respectively, and $3.8 million and $4.4 million for the six months ended June 30, 2025 and 2024, respectively.

- changed (2025-11-05):
[0000926326-25-000031:note_history:42]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  | (In thousands) |
| Connected devices, software licenses, and other | $ | 152,561 |  |  | $ | 135,672 |  |  | $ | 411,258 |  |  | $ | 381,280 |  |
| Consumables | 24,937 |  |  | 22,689 |  |  | 74,580 |  |  | 66,956 |  |
| Technical services | 67,275 |  |  | 59,583 |  |  | 192,420 |  |  | 177,419 |  |
| SaaS and Expert Services | 65,858 |  |  | 64,476 |  |  | 192,603 |  |  | 179,704 |  |
| Total revenues | $ | 310,631 |  |  | $ | 282,420 |  |  | $ | 870,861 |  |  | $ | 805,359 |  |
  (was, 2025-08-06, similarity 0.9156):
[0000926326-25-000019:note_history:42]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  | (In thousands) |
| Connected devices, software licenses, and other | $ | 138,620 |  |  | $ | 134,539 |  |  | $ | 258,697 |  |  | $ | 245,608 |  |
| Consumables | 24,552 |  |  | 22,041 |  |  | 49,643 |  |  | 44,267 |  |
| Technical services | 63,766 |  |  | 59,321 |  |  | 125,145 |  |  | 117,836 |  |
| SaaS and Expert Services | 63,624 |  |  | 60,887 |  |  | 126,745 |  |  | 115,228 |  |
| Total revenues | $ | 290,562 |  |  | $ | 276,788 |  |  | $ | 560,230 |  |  | $ | 522,939 |  |

- changed (2025-11-05):
[0000926326-25-000031:note_history:43]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  | (In thousands) |
| United States | $ | 278,195 |  |  | $ | 258,177 |  |  | $ | 790,905 |  |  | $ | 731,670 |  |
| Rest of world (1) | 32,436 |  |  | 24,243 |  |  | 79,956 |  |  | 73,689 |  |
| Total revenues | $ | 310,631 |  |  | $ | 282,420 |  |  | $ | 870,861 |  |  | $ | 805,359 |  |
  (was, 2025-08-06, similarity 0.8675):
[0000926326-25-000019:note_history:43]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  | (In thousands) |
| United States | $ | 263,446 |  |  | $ | 255,317 |  |  | $ | 512,710 |  |  | $ | 473,493 |  |
| Rest of world | 27,116 |  |  | 21,471 |  |  | 47,520 |  |  | 49,446 |  |
| Total revenues | $ | 290,562 |  |  | $ | 276,788 |  |  | $ | 560,230 |  |  | $ | 522,939 |  |

- added (2025-11-05):
[0000926326-25-000031:note_history:44]
________________________________________________

- added (2025-11-05):
[0000926326-25-000031:note_history:45]
(1)    No individual country represented more than 10% of total revenues.

- changed (2025-11-05):
[0000926326-25-000031:note_history:46]
|  | September 30,2025 |  | December 31,2024 |
|  | (In thousands) |
| Short-term unbilled receivables, net (1) | $ | 46,414 |  |  | $ | 32,917 |  |
| Long-term unbilled receivables, net (2) | 3,355 |  |  | 7,873 |  |
| Total contract assets | $ | 49,769 |  |  | $ | 40,790 |  |
| Short-term deferred revenues | $ | 178,777 |  |  | $ | 141,370 |  |
| Long-term deferred revenues | 66,723 |  |  | 76,123 |  |
| Total contract liabilities | $ | 245,500 |  |  | $ | 217,493 |  |
  (was, 2025-08-06, similarity 0.9828):
[0000926326-25-000019:note_history:46]
|  | June 30,2025 |  | December 31,2024 |
|  | (In thousands) |
| Short-term unbilled receivables, net (1) | $ | 37,137 |  |  | $ | 32,917 |  |
| Long-term unbilled receivables, net (2) | 5,747 |  |  | 7,873 |  |
| Total contract assets | $ | 42,884 |  |  | $ | 40,790 |  |
| Short-term deferred revenues | $ | 153,597 |  |  | $ | 141,370 |  |
| Long-term deferred revenues | 80,447 |  |  | 76,123 |  |
| Total contract liabilities | $ | 234,044 |  |  | $ | 217,493 |  |

- changed (2025-11-05):
[0000926326-25-000031:note_history:47]
During the three and nine months ended September 30, 2025, the Company recognized revenues of $20.7 million and $113.5 million, respectively, that were included in the corresponding short-term deferred revenues balance of $141.4 million as of December 31, 2024.
  (was, 2025-08-06, similarity 0.8866):
[0000926326-25-000019:note_history:47]
During the three and six months ended June 30, 2025, the Company recognized revenues of $38.6 million and $92.8 million, respectively, that were included in the corresponding gross short-term deferred revenues balance of $141.4 million as of December 31, 2024.

- changed (2025-11-05):
[0000926326-25-000031:note_history:48]
In addition, the Company has remaining performance obligations associated with contracts for which the associated products have been accepted or associated services have started, but where invoicing has not yet occurred and therefore are not reflected in deferred revenue. These remaining performance obligations are comprised of the non-variable portions of technical services and SaaS and Expert Services provided under non-cancellable contracts with minimum commitments. Remaining performance obligations which are not included in deferred revenues were $379.0 million as of September 30, 2025. Remaining performance obligations are expected to be recognized ratably over the remaining terms of the associated contracts, which terms vary but are generally not more than ten years. Remaining performance obligations do not include product obligations, services where the associated product has not been accepted, services which have not yet started, variable portions of services, and certain other obligations.
  (was, 2025-08-06, similarity 0.9935):
[0000926326-25-000019:note_history:48]
In addition, the Company has remaining performance obligations associated with contracts for which the associated products have been accepted or associated services have started, but where invoicing has not yet occurred and therefore are not reflected in deferred revenue. These remaining performance obligations are comprised of the non-variable portions of technical services and SaaS and Expert Services provided under non-cancellable contracts with minimum commitments. Remaining performance obligations which are not included in deferred revenues were $384.1 million as of June 30, 2025. Remaining performance obligations are expected to be recognized ratably over the remaining terms of the associated contracts, which terms vary but are generally not more than ten years. Remaining performance obligations do not include product obligations, services where the associated product has not been accepted, services which have not yet started, variable portions of services, and certain other obligations.

- changed (2025-11-05):
[0000926326-25-000031:note_history:49]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three and nine months ended September 30, 2025 and 2024. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable and unbilled receivables balance as of September 30, 2025 and December 31, 2024.
  (was, 2025-08-06, similarity 0.8352):
[0000926326-25-000019:note_history:49]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three and six months ended June 30, 2025 and 2024. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable and unbilled receivables balance as of June 30, 2025 and December 31, 2024.
