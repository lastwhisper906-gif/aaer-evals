# OMCL MD&A — 0000926326-26-000006


## mdna

[0000926326-26-000006:mdna:1]
ITEM 7.    MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0000926326-26-000006:mdna:2]
The following discussion and analysis should be read in conjunction with our Consolidated Financial Statements and related Notes to Consolidated Financial Statements in this Annual Report on Form 10-K. This discussion and analysis may contain forward-looking statements based upon our current expectations and assumptions that involve risks and uncertainties. Our actual results and the timing of selected events could differ materially from those anticipated in these forward-looking statements as a result of several factors, including those set forth under Item 1A, “Risk Factors,” and elsewhere in this Annual Report on Form 10-K. Unless otherwise stated, references in this Annual Report to particular years or quarters refer to our fiscal year and the associated quarters of those fiscal years.

[0000926326-26-000006:mdna:3]
We have elected to omit discussion of the earliest of the three years covered by the Consolidated Financial Statements presented. Such omitted discussion can be found under Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations,” located in our Annual Report on Form 10-K for the fiscal year ended December 31, 2024, filed with the SEC on February 27, 2025, for reference to discussion of the fiscal year ended December 31, 2023, the earliest of the three fiscal years presented.

[0000926326-26-000006:mdna:4]
OVERVIEW

[0000926326-26-000006:mdna:5]
Our Business

[0000926326-26-000006:mdna:6]
Omnicell, a leading healthcare technology provider focused on empowering autonomous medication management, is committed to solving the critical challenges inherent in medication management and elevating the role of clinicians within healthcare as an essential component of care delivery. Omnicell is focused on helping its customers define and deliver a cost-effective medication management strategy designed to equip and empower pharmacists and nurses to focus on patient care rather than administrative tasks, and to drive improved clinical, operational, and financial outcomes across all care settings. We are doing this with an industry-leading medication management infrastructure which includes storage and dispensing automation powered by an intelligence ecosystem. Our comprehensive set of solutions provides the critical foundation for customers to realize the Autonomous Pharmacy, an industry-wide vision defined by pharmacy leaders for improving operational efficiencies and ultimately targeting zero-error medication management alongside 5 other outcomes laid out in the Autonomous Pharmacy framework.

[0000926326-26-000006:mdna:7]
Omnicell solutions are helping healthcare facilities worldwide to uncover cost savings, improve labor efficiency, establish new revenue streams, enhance supply chain control, support compliance, and move closer to the industry-defined vision of the Autonomous Pharmacy. We sell our hardware, software, and consumable solutions together with related service offerings. Revenues generated in the United States represented 90% of our total revenues for the year ended December 31, 2025.

[0000926326-26-000006:mdna:8]
Our business has expanded from a single-point solution to a platform of products and services that will help further advance the industry-defined vision of the Autonomous Pharmacy. This expansion has resulted in larger deal sizes across multiple products, services, and implementations for customers and, we believe, more comprehensive, valuable, and enduring relationships. As our business evolves, we continue to evaluate the metrics and methods we use to measure the success of our business.

[0000926326-26-000006:mdna:9]
Global Trade Relations

[0000926326-26-000006:mdna:10]
In recent years, the U.S. government has advocated for greater restrictions on trade generally. For example, in 2025, the U.S. imposed tariffs on a wide variety of products manufactured in multiple foreign jurisdictions, including China, Mexico, and Malaysia. In response to the ongoing changes in tariffs, several foreign countries have imposed reciprocal tariffs on goods manufactured in the United States. These tariff rates have fluctuated and may continue to fluctuate going forward. In an effort to address these actions, we have implemented various mitigation measures, including dual-sourcing of components and nearshoring manufacturing. While these actions have effectively mitigated some of the impact of these costs, there can be no assurance that we will be able to offset future increased costs or other adverse impacts. Although we continue to work to mitigate the impact of current or potential tariffs, we may incorrectly anticipate outcomes, forgo or pass up business opportunities, or fail to appropriately adapt or manage our business strategies in response to these changes. As a result of these factors, we may experience direct and indirect adverse effects on our business, operating results, cash flow, or financial condition.

[0000926326-26-000006:mdna:11]
In addition, on February 20, 2026, the U.S. Supreme Court struck down certain tariffs imposed under the International Emergency Powers Act. It is unclear at this time what impact this decision will have on our business or future operating results, including whether we will be able to obtain refunds of amounts previously collected for such tariffs or the level of replacement tariffs the current U.S. Administration may impose through other means.

[0000926326-26-000006:mdna:12]
Product Bookings and Annual Recurring Revenue

[0000926326-26-000006:mdna:13]
We utilize product bookings and Annual Recurring Revenue (“ARR”), each as further described below, as key performance metrics for our business. We view product bookings as an indicator of the success of certain portions of our business that generate nonrecurring revenue and we view ARR as an indicator of the success of the portions of our business that generate recurring revenues. The definitions and descriptions included below are relevant to these key performance metrics.

[0000926326-26-000006:mdna:14]
Product Bookings

[0000926326-26-000006:mdna:15]
We utilize product bookings as an indicator of the success of certain portions of our business that generate non-recurring revenue. We define product bookings generally as the value of non-cancelable contracts for our connected devices and software licenses. We typically exclude freight revenue and other less significant items ancillary to our products from product bookings. In addition, dependent upon counterparty or credit risk, which is evaluated at the time of contract signing, for a given multi-year subscription contract we may reduce the value of the contractual commitment booked at a given time. Connected devices and software license bookings are recorded as revenue upon customer acceptance of the installation or receipt of goods. As part of most connected device product sales, we generally provide installation planning and consulting, which is typically included in the initial price of the solution. Product bookings were $535 million and $558 million during the years ended December 31, 2025 and 2024, respectively.

[0000926326-26-000006:mdna:16]
Annual Recurring Revenue

[0000926326-26-000006:mdna:17]
We consider revenues generated from our consumables, technical services, and SaaS and Expert Services to be recurring revenues. For the portions of our business which generate recurring revenues, we utilize ARR as a key metric to measure our progress in growing our recurring revenue business. We define ARR at a measurement date as the revenue we expect to receive from our customers over the course of the following year for providing them with products or services. ARR includes expected revenue from all customers who are using our products or services at the reported date. For technical services and SaaS and Expert Services, solutions are generally on a contractual basis, typically with contracts for a period of 12 months or more, with a high probability of renewal. Probability of renewal is based on historic renewal experience of the individual revenue streams or management’s best estimates if historical renewal experience is not available. Consumables orders are placed by customers through our Omnicell Storefront online platform or through written or telephonic orders and are sold to a customer base who utilize the consumable product and place recurring orders when customer inventory is depleted. ARR is generally calculated based on revenues received in the most recent quarter and changes to expected revenues where solutions were added to or removed from the install or customer base in the quarter. Revenues from technical services and SaaS and Expert Services are generally recorded ratably over the service term. As part of our SaaS and Expert Services offerings, we provide a range of services to our customers including Central Pharmacy Dispensing Service (service portion), IV Compounding Service (service portion), EnlivenHealth, Specialty Pharmacy Services, 340B solutions, Inventory Optimization Service, and other software solutions, which typically are provided over two to seven years. In addition, to help ensure the maximum availability of our systems, our customers typically purchase technical services contracts (support and maintenance) in increments of one to five years. Revenue from consumables are recorded when the product has shipped and title has passed. Our measure of ARR may be different than that used by other companies. Because ARR is based on expected future revenue, it does not represent revenue recognized during a particular reporting period or revenue to be recognized in future reporting

[0000926326-26-000006:mdna:18]
periods. ARR should not be viewed as a substitute for revenues. ARR was $636 million and $580 million as of December 31, 2025 and 2024, respectively.

[0000926326-26-000006:mdna:19]
The following table summarizes each revenue category:

[0000926326-26-000006:mdna:20]
| Revenue Category |  | Revenue Type |  | Income Statement Classification |  | Included in Product Bookings |  | Included in ARR |
| Connected devices, software licenses, and other |  | Nonrecurring |  | Product |  | Yes (1) |  | No |
| Consumables |  | Recurring |  | Product |  | No |  | Yes |
| Technical services |  | Recurring |  | Service |  | No |  | Yes |
| SaaS and Expert Services (2) |  | Recurring |  | Service |  | No |  | Yes |

[0000926326-26-000006:mdna:21]
_________________________________________________

[0000926326-26-000006:mdna:22]
(1)    Certain other insignificant revenue streams ancillary to our products and services, such as freight revenue, are not included in bookings.

[0000926326-26-000006:mdna:23]
(2)    Includes Central Pharmacy Dispensing Service (service portion), IV Compounding Service (service portion), EnlivenHealth, Specialty Pharmacy Services, 340B solutions, Inventory Optimization Service, and other software solutions.

[0000926326-26-000006:mdna:24]
Operating Segments

[0000926326-26-000006:mdna:25]
We manage our operations as a single segment for the purposes of assessing performance and making operating decisions. Our Chief Operating Decision Maker (“CODM”) is our Chief Executive Officer. The CODM allocates resources and evaluates the performance of Omnicell at the consolidated level using our consolidated net income (loss). In addition, the CODM is provided with certain segment assets and liabilities, primarily those that impact liquidity, as well as certain significant expenses. All significant operating decisions are based upon an analysis of Omnicell as one operating segment, which is the same as our reporting segment.

[0000926326-26-000006:mdna:26]
Our full-time employee headcount was approximately 3,580 on December 31, 2025.

[0000926326-26-000006:mdna:27]
Business Strategy

[0000926326-26-000006:mdna:28]
In 2024, the United States spent $806 billion on prescription drugs, a 10.2% increase from 2023. We believe there are significant challenges facing the practice of pharmacy today. These challenges include, but are not limited to, budget constraints and acute workforce shortages, where 88% of hospitals report technician deficits and 92% lack sufficient sterile compounding expertise. In addition, health systems face rising liability related to drug diversion, with a 61% increase in the average number of investigations per hospital since the beginning of 2023. We also recognize that these challenges may impact the timing of contracting for, or implementation of, our products, solutions, or services. However, we believe that over time these significant challenges facing pharmacists will drive demand for increased automation, visibility, insights, and improved medication management outcomes that our solutions are designed to enable. Because of this, we believe that our solutions are well-positioned to address the evolving needs of healthcare institutions and therefore present opportunities for long-term growth.

[0000926326-26-000006:mdna:29]
In an effort to address these challenges and deliver solutions to help drive positive medication management outcomes, we continue to make significant investments in our research and development efforts to further advance the industry-defined vision of the Autonomous Pharmacy. Furthermore, we believe a combination of dispensing automation and an intelligence ecosystem is needed in every care setting where medications are managed. We are focused on delivering solutions to help our customers realize the industry-defined vision of the Autonomous Pharmacy and driving positive medication management outcomes with superior customer experience in two core market categories through:

[0000926326-26-000006:mdna:30]
•Hospital and Health System Solutions: This category enables the end-to-end medication process across the entire continuum of care. It unifies Central Pharmacy automation, robotics, and IV sterile compounding with Point of Care automated dispensing in Nursing Units and Operating Room/Procedural areas. From the loading dock to the bedside, this is designed to provide for medication safety, availability, and workflow efficiency. This category also supports Consolidated Pharmacy Service Center operations.

[0000926326-26-000006:mdna:31]
•Points of Care.  As a market leader, we anticipate continued expansion into this product market as customers increasingly utilize our dispensing systems in more areas within hospitals and ambulatory care settings. The 2025–2028 healthcare landscape, however, faces significant fiscal headwinds driven by sweeping changes in health policy, specifically the One Big Beautiful Bill Act (“OBBBA”), which is expected to result in a $910 billion Medicaid spending reduction across states. Coupled with rising input costs from tariffs and acute labor shortages, these pressures are likely to further compress operating margins. We believe this financial strain makes the status quo unsustainable, which we anticipate compelling health systems to focus on capital efficiency and operational resilience through accelerated investments in pharmacy modernization, especially automation to address labor shortages and advanced analytics to manage rising costs of drug diversion and non-adherence. As hospitals navigate this liquidity challenge, we expect a critical shift in purchasing behavior from traditional capital expenditures to flexible payment models, such as leasing, subscriptions, and “as-a-service” structures, enabling institutions to adopt essential regulatory compliance and safety technologies while preserving operating cash flow.

[0000926326-26-000006:mdna:32]
•Central Pharmacy.  This market represents the beginning of medication management in acute care settings. Given the current environment, we believe there is a significant opportunity for automation as many health systems aim to eliminate manual, repetitive, and error-prone processes to address acute workforce shortages. With hospitals facing technician shortages and often lacking adequate sterile compounding expertise, we think automating central pharmacy dispensing and compounding is crucial for reallocating limited labor, enhancing patient safety, and enabling compliance with the new Drug Supply Chain Security Act (“DSCSA”) requirements. Manual compounding of sterile IV preparations poses safety risks and, when outsourced, can increase costs and supply volatility. Therefore, IV automation offers a key opportunity to standardize sterile workflows, offset the resources currently used for managing drug shortages, and reduce the annual cost of non-optimized medication therapy. We expect these technology-driven services to become increasingly vital as health systems focus on operational resilience amid severe financial pressures.

[0000926326-26-000006:mdna:33]
•Consolidated Pharmacy Service Center Automation and Robotics.  Health Systems are increasingly realizing savings from a Consolidated Pharmacy Service Center (“CPSC”) model. The CPSC serves as a strategic hub for centralized inventory management and sterile compounding. By implementing industrial-grade robotics and carousels at the CPSC, health systems can achieve economies of scale, streamlining the serialized receiving process required for DSCSA compliance before inventory reaches hospitals. This centralized approach should help preserve margins by optimizing supply chains and reducing waste across the network.

[0000926326-26-000006:mdna:34]
•Outpatient Pharmacy Solutions: Focused on extending care beyond the hospital walls, this category supports outpatient and retail pharmacy growth. It combines Specialty Pharmacy and 340B Third-Party Administrator (“TPA”) services, Medication Adherence technologies (automation and consumables), and the EnlivenHealth platform to help drive better clinical outcomes and medication compliance for clinicians and patients.

[0000926326-26-000006:mdna:35]
•Specialty Pharmacy and 340B Program.  We believe that health systems will continue to accelerate investment in programs to improve patient outcomes by utilizing specialty pharmacies and the federal 340B Drug Pricing Program. The 340B Program allows qualified hospitals to stretch federal resources, a critical capability as the program is on track to exceed $200 billion in gross sales by 2026, surpassing the entire Medicare Part B market. In 2024, specialty drugs used for treatment of complex conditions constituted the majority (51.7%) of total prescription expenditures. This sector continues to grow at a higher rate than other drug classes. However, regulatory pressures are intensifying with site-neutral payment cuts. Specialty pharmacies serve as the connection between patients, providers, and payers to streamline access and adherence. We believe a solution designed to help health systems optimize their Health System-Owned

[0000926326-26-000006:mdna:36]
Specialty Pharmacy (“HSSP”) and navigate these compliance-complexities will help ensure continuity of care. We believe that a fully optimized specialty pharmacy operation represents one of the largest economic opportunities for hospitals and health systems.

[0000926326-26-000006:mdna:37]
•Institutional Pharmacy.  The U.S. institutional pharmacy industry provides closed-door medication dispensing, clinical support, and medication adherence services for long-term care (“LTC”), correctional, rehabilitation and behavioral health, and hospice facilities. The market size of the institutional pharmacies industry in the U.S. is $24 billion with 1,100 businesses servicing this sector and characterized by a high concentration in national operators. LTC facilities comprise skilled nursing facilities, assisted living communities, senior living centers, and home and community-based care settings. LTC pharmacies typically operate under more stringent regulatory, packaging, and labor requirements than retail pharmacies, which may result in structurally higher operating costs. As a result of projected demographic aging and the increasing complexity of managing chronic disease across LTC populations, we expect market demand to continue to rise. The LTC industry is currently undergoing a transition driven by reimbursement pressures, regulatory expansion, and workforce shortages. Legislative and pricing reforms, including updates to Medicare Part D, have increased financial strain on smaller LTC providers, which we believe will accelerate a shift toward centralized, automation-enabled fulfillment models that are designed to improve efficiency, standardize quality, and support compliance with evolving documentation and oversight requirements. Through our outpatient pharmacy solutions, we also serve adjacent outpatient institutional markets, including correctional facilities’ pharmacy providers. Additionally, we provide pharmacy services to individuals with intellectual and developmental disabilities (“IDD”), a market currently experiencing rising demand due to increased prevalence. IDD pharmacy services require specialized packaging, adherence technologies, and close coordination with caregivers and community-based support organizations.

[0000926326-26-000006:mdna:38]
•Retail.  Total U.S. prescription dispensing revenues across retail, mail-order, long-term care, and specialty pharmacies reached approximately $683 billion in 2024, up 9% from 2023, a surge driven primarily by the rapid adoption of GLP-1 agonists and specialty immunotherapies rather than volume alone. Additionally, the shift of outpatient care from hospitals and physician offices to other more convenient settings, such as retail pharmacies and the home, continues to be a growing trend. New technologies and increased scope of practice for pharmacists appear to be spurring innovation and expansion of the provision of clinical services by retail pharmacies. We believe this development, combined with the move to value-based care, will drive the adoption of our patient engagement offerings. These solutions are intended to help providers (including pharmacists) engage patients in new ways that are expected to improve outcomes, reduce the total cost of care, and lead to more profitable operations.

[0000926326-26-000006:mdna:39]
CRITICAL ACCOUNTING ESTIMATES

[0000926326-26-000006:mdna:40]
Our discussion and analysis of our financial condition and results of operations are based on our Consolidated Financial Statements, which have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”). The preparation of these financial statements requires us to make certain estimates and assumptions that affect the reported amounts of assets and liabilities, disclosure of any contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting periods. We regularly review our estimates and assumptions, which are based on historical experience and various other factors that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of certain assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates and assumptions. We believe the following critical accounting estimates are affected by significant judgments used in the preparation of our Consolidated Financial Statements:

[0000926326-26-000006:mdna:41]
Revenue Recognition

[0000926326-26-000006:mdna:42]
We earn revenues from sales of our products and related services, which are sold in the healthcare industry, our principal market. Many of our sales contain multiple performance obligations, with a combination of hardware systems, software products, support and maintenance, and professional services.

[0000926326-26-000006:mdna:43]
A significant level of judgment is involved in contractual arrangements with multiple performance obligations to determine appropriate allocation of the transaction price. We allocate the transaction price to separate performance obligations based on the estimated standalone selling price of each performance obligation. Standalone selling price is best evidenced by the price we would charge for the good or service when selling it separately in similar circumstances to similar customers. Other than for the renewal of annual technical services contracts, our products and services are not generally sold separately. We use an amount discounted from the list price as a best estimated standalone selling price.

[0000926326-26-000006:mdna:44]
Additionally, judgment is required to determine the timing of revenue recognition for each performance obligation based upon when control transfers to a customer. We review our performance obligations in a contract and evaluate when transfer of control occurs. Generally, for products requiring a complex implementation, control passes when the product is installed and functionally ready for use. For all other products, control generally passes when product has been shipped and title has passed. For support and maintenance contracts and certain other services, including SaaS and Expert Services provided on a subscription basis, control passes to the customer over time, generally ratably over the service term. Time and material services transfer control to the customer at the time the services are provided.

[0000926326-26-000006:mdna:45]
These judgments have been applied consistently for all periods presented. Changes in the assumptions or judgments used in determining the standalone selling price or timing of revenue recognition could impact the amount and timing of revenue reported in a particular period.

[0000926326-26-000006:mdna:46]
Inventory

[0000926326-26-000006:mdna:47]
Inventories are stated at the lower of cost, computed using the first-in, first-out method, and net realizable value. We regularly monitor inventory quantities on hand and record write-downs for excess and obsolete inventories based on our estimate of demand for our products, potential obsolescence of technology, product life cycles, and whether pricing trends or forecasts indicate that the carrying value of inventory exceeds its estimated selling price. These factors are impacted by market and economic conditions, technology changes, and new product introductions and require estimates that may include elements that are uncertain. Actual demand may differ from forecasted demand and may have a material effect on gross margins. If inventory is written down, a new cost basis is established that cannot be increased in future periods. Changes in our assumptions, judgments, or estimates could impact future financial results if additional write-downs for excess and obsolete inventories are needed.

[0000926326-26-000006:mdna:48]
Accounting for Income Taxes

[0000926326-26-000006:mdna:49]
We make certain estimates and judgments in determining income tax expense or benefit for financial statement purposes. These estimates and judgments occur in the calculation of income tax credits, uncertain tax positions, and in the calculation of certain tax assets and liabilities, which arise from differences in the timing of the recognition of certain income and expenses for tax and financial statement purposes. We assess the likelihood of the realization of deferred tax assets and the need for a valuation allowance in each reporting period. As of December 31, 2025, we do not maintain a valuation allowance against deferred tax assets based on our assessment that it is more likely than not these assets will be realized. In reaching our conclusion, we evaluate certain relevant criteria as provided in ASC 740, Income Taxes, including having sufficient taxable income of the appropriate character in future years. Our judgment regarding future taxable income may change due to future changes in the company’s profitability as a result of changes in market conditions, changes in U.S. or international tax laws, and other factors. Changes in judgment may require material adjustments to deferred tax assets, which may result in an increase or decrease to our income tax provision in the period of adjustment. For additional details, refer to Note 17, Income Taxes, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K for additional information.

[0000926326-26-000006:mdna:50]
As a global company, we use significant judgment to calculate and provide for income taxes in each of the tax jurisdictions in which we operate. In the ordinary course of business, transactions and calculations occur whose ultimate tax outcome cannot be certain. Some of these uncertainties arise due to transfer pricing for transactions with our subsidiaries and the determination of tax nexus. We also monitor global tax developments, including the OECD Pillar Two Framework, which may impact our effective tax rate in future periods.

[0000926326-26-000006:mdna:51]
We account for uncertain tax positions in accordance with ASC 740. We estimate and recognize the tax benefit from an uncertain tax position if it is more likely than not that the tax position will be sustained upon examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement. The calculation of tax liabilities involves significant judgment in estimating the impact of uncertainties in the application of ASC 740 and complex tax laws. Due to the inherent uncertainties in tax regulations and the complexity of our global operations, it is impracticable to provide a detailed quantitative analysis of our uncertain tax positions.

[0000926326-26-000006:mdna:52]
Although we believe our estimates are reasonable, there is no guarantee that the final tax outcome will not differ from what is reflected in our historical income tax provisions, returns, and accruals. Such differences, or changes in estimates relating to potential differences, could have a material impact on our income tax provision and operating results in the period such determination is made.

[0000926326-26-000006:mdna:53]
Recently Issued Authoritative Guidance

[0000926326-26-000006:mdna:54]
Refer to “Recently Issued Authoritative Guidance” in Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to Consolidated Financial Statements in this Annual Report on Form 10-K for a description of recently

[0000926326-26-000006:mdna:55]
issued accounting pronouncements, including the expected dates of adoption and estimated effects on our results of operations, financial position, and cash flows.

[0000926326-26-000006:mdna:56]
RESULTS OF OPERATIONS

[0000926326-26-000006:mdna:57]
Total Revenues

[0000926326-26-000006:mdna:58]
|  | Year Ended December 31, |  | Change in |  |  |  |  |
|  | 2025 |  | 2024 |  | $ |  | % |  |  |  |  |  |  |
|  | (Dollars in thousands) |
| Product revenues | $ | 665,697 |  |  | $ | 630,507 |  |  | $ | 35,190 |  |  | 6% |  |  |  |  |  |  |
| Percentage of total revenues | 56% |  | 57% |  |  |  |  |  |  |  |  |  |  |
| Service revenues | 519,148 |  |  | 481,731 |  |  | 37,417 |  |  | 8% |  |  |  |  |  |  |
| Percentage of total revenues | 44% |  | 43% |  |  |  |  |  |  |  |  |  |  |
| Total revenues | $ | 1,184,845 |  |  | $ | 1,112,238 |  |  | $ | 72,607 |  |  | 7% |  |  |  |  |  |  |

[0000926326-26-000006:mdna:59]
Product revenues represented 56% and 57% of total revenues for the years ended December 31, 2025 and 2024, respectively. Product revenues increased by $35.2 million, primarily due to the increase in revenues from our XTExtend offering, partially offset by lower volumes from our XT Series automated dispensing systems business due to the timing of our XT Series systems lifecycle, as we are largely through the replacement cycle, as well as the decrease in revenues from products related to our Central Pharmacy Dispensing Service offering.

[0000926326-26-000006:mdna:60]
Service revenues represented 44% and 43% of total revenues for the years ended December 31, 2025 and 2024, respectively. Service revenues include revenues from technical services and SaaS and Expert Services offerings. Service revenues increased by $37.4 million, due to an increase of $21.9 million in technical services revenues primarily as a result of growth in our installed customer base and the impact of pricing actions. The increase is also driven by an increase of $15.6 million in SaaS and Expert Services revenues due to continued customer demand, including an increase in revenues from our Specialty Pharmacy Services offering, partially offset by lower revenues from the EnlivenHealth portfolio.

[0000926326-26-000006:mdna:61]
Our international sales represented 10% and 9% of total revenues for the years ended December 31, 2025 and 2024, respectively. In future periods, we expect our revenues to be affected by foreign currency exchange rate fluctuations. We are unable to predict the extent to which revenues in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-26-000006:mdna:62]
Our ability to grow product and service revenues is dependent on our ability to continue to obtain orders from customers, including contract renewals, which may be dependent upon customers’ capital equipment budgets and/or capital equipment approval cycles, our ability to produce quality products and consumables to fulfill customer demand, the volume of implementations we are able to complete, our ability to meet customer needs by providing a quality implementation experience and solutions that meet expected service levels, our ability to develop new or enhance existing solutions, and our flexibility in workforce allocations among customers to complete implementations on a timely basis. The timing of our revenues is primarily dependent on when our customers’ schedules and/or staffing levels allow for implementations.

[0000926326-26-000006:mdna:63]
Cost of Revenues and Gross Profit

[0000926326-26-000006:mdna:64]
Cost of revenues is primarily comprised of three general categories: (i) standard product costs which account for the majority of the product cost of revenues that are provided to customers, and are inclusive of purchased material, labor to build the product, and overhead costs associated with production; (ii) costs of providing services and installation costs, including costs of personnel and other expenses; and (iii) other costs, including variances in standard costs and overhead, scrap costs, rework, provisions for excess and obsolete inventory, and amortization of software development costs and intangibles.

[0000926326-26-000006:mdna:65]
|  | Year Ended December 31, |  | Change in |
|  | 2025 |  | 2024 |  | $ |  | % |
|  | (Dollars in thousands) |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | $ | 379,162 |  |  | $ | 383,025 |  |  | $ | (3,863) |  |  | (1)% |
| As a percentage of related revenues | 57% |  | 61% |  |  |  |  |
| Cost of service revenues | 302,241 |  |  | 258,210 |  |  | 44,031 |  |  | 17% |
| As a percentage of related revenues | 58% |  | 54% |  |  |  |  |
| Total cost of revenues | $ | 681,403 |  |  | $ | 641,235 |  |  | $ | 40,168 |  |  | 6% |
| As a percentage of total revenues | 58% |  | 58% |  |  |  |  |
| Gross profit | $ | 503,442 |  |  | $ | 471,003 |  |  | $ | 32,439 |  |  | 7% |
| Gross margin | 42% |  | 42% |  |  |  |  |

[0000926326-26-000006:mdna:66]
Cost of revenues for the year ended December 31, 2025 compared to the year ended December 31, 2024 increased by $40.2 million, primarily driven by a $44.0 million increase in cost of service revenues, partially offset by a $3.9 million decrease in cost of product revenues.

[0000926326-26-000006:mdna:67]
The decrease in cost of product revenues for the year ended December 31, 2025 compared to the year ended December 31, 2024 was primarily driven by the impact of more favorable materials costs as well as favorable impact from product and customer mix during the year ended December 31, 2025 and a decrease of $9.6 million of restructuring costs, including inventory write-down charges, partially offset by an increase in product revenues and the impact of tariffs incurred during the year ended December 31, 2025.

[0000926326-26-000006:mdna:68]
The increase in cost of service revenues was primarily driven by the increase in service revenues of $37.4 million for the year ended December 31, 2025 compared to the year ended December 31, 2024, including the associated increase in employee-related expenses, an increase in certain non-recurring costs, including software upgrade expenses, and an increase of $4.3 million in restructuring costs.

[0000926326-26-000006:mdna:69]
The overall gross margin remained relatively consistent for the year ended December 31, 2025 compared to the year ended December 31, 2024 primarily due to the impact of more favorable materials costs as well as favorable impact from product and customer mix and a decrease in restructuring costs, including inventory write-down charges, partially offset by the impact of tariffs and an increase in employee-related and certain non-recurring software upgrade expenses. Our gross profit for the year ended December 31, 2025 was $503.4 million, as compared to $471.0 million for the year ended December 31, 2024.

[0000926326-26-000006:mdna:70]
Operating Expenses and Interest and Other Income (Expense), Net

[0000926326-26-000006:mdna:71]
|  | Year Ended December 31, |  | Change in |  |  |  |  |  |  |
|  | 2025 |  | 2024 |  | $ |  | % |  |  |  |  |  |  |  |  |
|  | (Dollars in thousands) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 88,672 |  |  | $ | 90,412 |  |  | $ | (1,740) |  |  | (2)% |  |  |  |  |  |  |  |  |
| As a percentage of total revenues | 7% |  | 8% |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | 409,610 |  |  | 380,254 |  |  | 29,356 |  |  | 8% |  |  |  |  |  |  |  |  |
| As a percentage of total revenues | 35% |  | 34% |  |  |  |  |  |  |  |  |  |  |  |  |
| Total operating expenses | $ | 498,282 |  |  | $ | 470,666 |  |  | $ | 27,616 |  |  | 6% |  |  |  |  |  |  |  |  |
| As a percentage of total revenues | 42% |  | 42% |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other income (expense), net | $ | 6,165 |  |  | $ | 25,256 |  |  | $ | (19,091) |  |  | (76)% |  |  |  |  |  |  |  |  |

[0000926326-26-000006:mdna:72]
Research and Development. Research and development expenses decreased by $1.7 million for the year ended December 31, 2025 compared to the year ended December 31, 2024.

[0000926326-26-000006:mdna:73]
Selling, General, and Administrative. Selling, general, and administrative expenses increased by $29.4 million for the year ended December 31, 2025 compared to the year ended December 31, 2024. The increase was primarily due to an increase

[0000926326-26-000006:mdna:74]
of $19.8 million in employee-related expenses, which included an increase of $7.3 million in share-based compensation expense. The increase in employee-related expenses was primarily due to higher headcount, annual merit increases, and the timing of share-based compensation expense recognition. The increase in selling, general, and administrative expenses was also attributable to an increase in commissions of $3.9 million, an increase in consulting expenses of $2.6 million, and an increase of $2.7 million in the allowance for credit losses for the year ended December 31, 2025 compared to the year ended December 31, 2024.

[0000926326-26-000006:mdna:75]
Interest and Other Income (Expense), Net. Interest and other income (expense), net, changed by $19.1 million for the year ended December 31, 2025 compared to the year ended December 31, 2024, primarily driven by a $20.6 million decrease in other income and a $1.5 million decrease in other expense. The decrease in other income during the year ended December 31, 2025 compared to the year ended December 31, 2024 is primarily attributable to a $7.5 million gain on extinguishment of the 2025 convertible senior notes and related unwind of note hedges and warrants during the year ended December 31, 2024, as well as lower interest income received. The decrease in interest income received was primarily due to lower interest rates and lower cash and cash equivalents balances following the partial repurchase of the 2025 convertible senior notes in November 2024 and maturity of the remaining 2025 Notes in September 2025, and repurchases of our common stock during the second and third quarters of 2025.

[0000926326-26-000006:mdna:76]
Provision for Income Taxes

[0000926326-26-000006:mdna:77]
|  | Year Ended December 31, |  | Change in |  |  |  |  |
|  | 2025 |  | 2024 |  | $ |  | % |  |  |  |  |  |  |
|  | (Dollars in thousands) |
| Provision for income taxes | $ | 9,273 |  |  | $ | 13,062 |  |  | $ | (3,789) |  |  | (29)% |  |  |  |  |  |  |
| Effective tax rate on earnings | 82% |  | 51% |  |  |  |  |  |  |  |  |  |  |

[0000926326-26-000006:mdna:78]
We recorded an income tax expense of $9.3 million on an income before income taxes of $11.3 million, which resulted in an effective tax rate of 82% for the year ended December 31, 2025, compared to an income tax expense of $13.1 million on an income before income taxes of $25.6 million, which resulted in an effective tax rate of 51% for the year ended December 31, 2024. The 2025 annual effective tax rate differed from the statutory tax rate of 21%, primarily due to the unfavorable impact of state taxes and non-deductible equity compensation charges, partially offset by a favorable impact of research and development credits.

[0000926326-26-000006:mdna:79]
Refer to Note 17, Income Taxes, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K for additional information.

[0000926326-26-000006:mdna:80]
LIQUIDITY AND CAPITAL RESOURCES

[0000926326-26-000006:mdna:81]
We had cash and cash equivalents of $196.5 million at December 31, 2025, compared to $369.2 million at December 31, 2024. All of our cash and cash equivalents are invested in bank accounts and money market funds held in sweep and asset management accounts with financial institutions of high credit quality. As of December 31, 2025, a substantial portion of the Company’s cash and cash equivalents were held with a limited number of financial institutions and money market funds, which may expose the Company to concentration risk in the event of a failure or adverse condition affecting those entities.

[0000926326-26-000006:mdna:82]
Our cash position and working capital at December 31, 2025 and 2024 were as follows:

[0000926326-26-000006:mdna:83]
|  | December 31, |
|  | 2025 |  | 2024 |
|  | (In thousands) |
| Cash and cash equivalents | $ | 196,520 |  |  | $ | 369,201 |  |
| Working capital | $ | 203,460 |  |  | $ | 219,815 |  |

[0000926326-26-000006:mdna:84]
Our ratio of current assets to current liabilities was 1.4:1 at both December 31, 2025 and 2024.

[0000926326-26-000006:mdna:85]
Sources of Cash

[0000926326-26-000006:mdna:86]
Revolving Credit Facility

[0000926326-26-000006:mdna:87]
On November 15, 2019, Omnicell, Inc. entered into an Amended and Restated Credit Agreement (as amended, the “Prior A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers, and Wells Fargo Bank, National Association, as administrative

[0000926326-26-000006:mdna:88]
agent. The Prior A&R Credit Agreement provided for (a) a five-year revolving credit facility of $500.0 million (the “Prior Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million (the “Prior Incremental Facility”). In addition, the Prior A&R Credit Agreement included a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The Prior A&R Credit Agreement was subsequently amended on September 22, 2020 and March 29, 2023 to permit the issuance of the convertible senior notes and the purchase of the convertible note hedge transactions (as described in Note 11, Convertible Senior Notes, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K), expand our flexibility to make restricted payments (including common stock repurchases), and replace the total net leverage covenant, as well as to remove and replace the interest rate benchmark based on the London interbank offered rate (“LIBOR”) and related LIBOR-based mechanics with an interest rate benchmark based on the secured overnight financing rate (“SOFR”) as administered by the Federal Reserve Bank of New York and related SOFR-based mechanics.

[0000926326-26-000006:mdna:89]
On October 10, 2023, Omnicell, Inc. entered into a Second Amended and Restated Credit Agreement (the “Second A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, JPMorgan Chase Bank, N.A., PNC Capital Markets LLC and TD Securities (USA) LLC as joint lead arrangers and Wells Fargo Bank, National Association, as administrative agent. The Second A&R Credit Agreement supersedes the Prior A&R Credit Agreement and provides for (a) a five-year revolving credit facility of $350.0 million (the “Current Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to an amount equal to the sum of (i) the greater of $250.0 million and 100% of the adjusted consolidated EBITDA for the last four quarters and (ii) additional amounts subject to pro forma compliance with certain consolidated secured net leverage ratio (the “Current Incremental Facility”). In addition, the Second A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The Second A&R Credit Agreement has an expiration date of October 10, 2028, subject to acceleration under certain conditions, upon which date all remaining outstanding borrowings will be due and payable.

[0000926326-26-000006:mdna:90]
As of December 31, 2025, we had $350.0 million of funds available under the Current Revolving Credit Facility. As of December 31, 2025, there was no outstanding balance under the Current Revolving Credit Facility and we were in full compliance with all covenants.

[0000926326-26-000006:mdna:91]
Refer to Note 10, Debt and Credit Agreement, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K for additional information. We expect to use future loans under the Current Revolving Credit Facility, if any, for working capital, potential acquisitions, and other general corporate purposes.

[0000926326-26-000006:mdna:92]
Convertible Senior Notes

[0000926326-26-000006:mdna:93]
On November 22, 2024, Omnicell, Inc. completed a private offering of $172.5 million aggregate principal amount of 1.00% Convertible Senior Notes due 2029 (the “2029 Notes”), including the exercise in full of the initial purchasers’ option to purchase up to an additional $22.5 million aggregate principal amount of the 2029 Notes. Omnicell, Inc. received proceeds from the issuance of the 2029 Notes of $166.3 million, net of $6.2 million of transaction fees and other debt issuance costs. The 2029 Notes bear interest at a rate of 1.00% per year, payable semiannually in arrears on June 1 and December 1 of each year, beginning on June 1, 2025. The 2029 Notes are general senior, unsecured obligations of Omnicell, Inc. and will mature on December 1, 2029, unless earlier redeemed, repurchased, or converted. In connection with the issuance of the 2029 Notes, in November 2024, we entered into warrant transactions and received aggregate proceeds from the sale of the warrants of approximately $25.2 million. Refer to Note 11, Convertible Senior Notes, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K for additional information.

[0000926326-26-000006:mdna:94]
Uses of Cash

[0000926326-26-000006:mdna:95]
Our future uses of cash are expected to be primarily for working capital, capital expenditures, and other contractual obligations. We may also use cash for potential acquisitions and acquisition-related activities, as well as repurchases of our common stock.

[0000926326-26-000006:mdna:96]
During the year ended December 31, 2025, we repurchased approximately 2,523,000 shares of our common stock under the 2016 and 2025 repurchase programs at an average price of $30.74 per share for an aggregate purchase price of approximately $77.6 million, which completed the 2016 Repurchase Program and substantially completed the 2025 Repurchase Program. Refer to Note 16, Stock Repurchase Programs, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K for additional information.

[0000926326-26-000006:mdna:97]
In November 2024, we completed a partial repurchase of $400.0 million aggregate principal amount of the 2025 Notes for approximately $391.0 million in cash. The 2025 Notes matured on September 15, 2025 and we repaid the remaining principal balance of $175.0 million in cash. Refer to Note 11, Convertible Senior Notes, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K for additional information.

[0000926326-26-000006:mdna:98]
In connection with the issuance of the 2029 Notes, in November 2024, we entered into convertible note hedge transactions and used approximately $40.3 million of the net proceeds from the offering to pay the cost of the convertible note hedges.

[0000926326-26-000006:mdna:99]
Based on our current business plan and backlog, we believe that our existing cash and cash equivalents, our anticipated cash flows from operations, cash generated from the exercise of employee stock options and purchases under our Employee Stock Purchase Plan (“ESPP”), along with the availability of funds under the Current Revolving Credit Facility will be sufficient to meet our cash needs for working capital, capital expenditures, potential acquisitions, and other contractual obligations for at least the next twelve months. For periods beyond the next twelve months, we also anticipate that our net operating cash flows plus existing balances of cash and cash equivalents will suffice to fund the growth of our business.

[0000926326-26-000006:mdna:100]
Cash Flows

[0000926326-26-000006:mdna:101]
The following table summarizes, for the periods indicated, selected items in our Consolidated Statements of Cash Flows:

[0000926326-26-000006:mdna:102]
|  | Year Ended December 31, |
|  | 2025 |  | 2024 |  |  |
|  | (In thousands) |
| Net cash provided by (used in): |  |  |  |  |  |
| Operating activities | $ | 127,300 |  |  | $ | 187,722 |  |  |  |
| Investing activities | (60,363) |  |  | (52,793) |  |  |  |
| Financing activities | (218,317) |  |  | (235,578) |  |  |  |
| Effect of exchange rate changes on cash and cash equivalents | 3,798 |  |  | (1,716) |  |  |  |
| Net increase (decrease) in cash, cash equivalents, and restricted cash | $ | (147,582) |  |  | $ | (102,365) |  |  |  |

[0000926326-26-000006:mdna:103]
Operating Activities

[0000926326-26-000006:mdna:104]
We expect cash from our operating activities to fluctuate in future periods as a result of a number of factors, including the timing of our billings and collections, our operating results, and the timing of other liability payments.

[0000926326-26-000006:mdna:105]
Net cash provided by operating activities was $127.3 million for the year ended December 31, 2025, primarily consisting of operating inflows of $135.6 million and unfavorable working capital movements of $8.3 million. Operating inflows consisted of net income of $2.1 million, adjusted for non-cash items of $133.6 million, which consisted primarily of depreciation and amortization expense of $78.8 million, share-based compensation expense of $44.5 million, and amortization of operating lease right-of-use assets of $7.8 million. The unfavorable working capital was primarily due to a decrease in accrued liabilities of $19.0 million primarily due to a decrease in taxes payable and rebate liabilities, a decrease in operating lease liabilities of $11.7 million, an increase in inventories of $11.2 million to support production requirements, including advanced purchases of certain components, as well as the impact of tariffs, an increase in investment in sales-type leases of $10.2 million primarily due to the acceptance of certain SaaS and Expert Services products under sales-type lease arrangements, a decrease in accounts payable of $9.3 million and an increase in prepaid expenses of $7.8 million. These cash outflows were partially offset by a decrease in accounts receivable and unbilled receivables of $41.4 million primarily due to the timing of billings, shipments, and collections and an increase in deferred revenues of $16.4 million due to the timing of billings and customers’ installation schedules.

[0000926326-26-000006:mdna:106]
Net cash provided by operating activities was $187.7 million for the year ended December 31, 2024, primarily consisting of operating inflows of $129.4 million and favorable working capital movements of $58.3 million. Operating inflows consisted of net income of $12.5 million, adjusted for non-cash items of $116.9 million, which consisted primarily of depreciation and amortization expense of $82.2 million, share-based compensation expense of $39.3 million, amortization of operating lease right-of-use assets of $7.5 million, a net gain on extinguishment of convertible senior notes of $7.5 million, inventory write-down charges of $5.4 million, and a change in deferred income taxes of $14.9 million. The favorable working capital was primarily due to an increase in deferred revenues of $29.0 million driven by an increase in billings for certain technical service and SaaS and Expert Services offerings, a decrease in inventories of $15.6 million resulting from inventory management initiatives, an increase in accrued liabilities of $13.9 million due to an increase in taxes payable, a decrease in other current assets of $9.3 million due to a decrease in income taxes receivable, an increase in accrued compensation of $8.6 million, and an increase in accounts payables of $7.2 million. These cash inflows were partially offset by a decrease in operating lease liabilities of $10.7 million, an increase in investment in sales-type leases of $10.4 million primarily due to the acceptance of certain SaaS and Expert Services products under sales-type lease arrangements, and an increase in accounts receivable and unbilled receivables of $5.0 million primarily due to the timing of billings, shipments, and collections.

[0000926326-26-000006:mdna:107]
Investing Activities

[0000926326-26-000006:mdna:108]
Net cash used in investing activities was $60.4 million for the year ended December 31, 2025, which primarily consisted of capital expenditures of $40.4 million for property and equipment and $17.5 million for external-use software development costs.

[0000926326-26-000006:mdna:109]
Net cash used in investing activities was $52.8 million for the year ended December 31, 2024, which consisted of capital expenditures of $36.5 million for property and equipment and $16.3 million for external-use software development costs.

[0000926326-26-000006:mdna:110]
Financing Activities

[0000926326-26-000006:mdna:111]
Net cash used in financing activities was $218.3 million for the year ended December 31, 2025, due to the repayment of the remaining principal balance of our 2025 Notes of $175.0 million, repurchases of shares of our common stock of $77.6 million, and $7.7 million in employees’ taxes paid related to restricted stock unit vesting, partially offset by a net change in the customer funds balances of $25.1 million and $16.9 million in proceeds from employee stock option exercises and ESPP purchases.

[0000926326-26-000006:mdna:112]
Net cash used in financing activities was $235.6 million for the year ended December 31, 2024, primarily due to the partial repurchase of $400.0 million of aggregate principal amount of the 2025 Notes for approximately $391.0 million and the net cash used in the purchase of the convertible note hedge and sale of warrants in connection with the 2029 Notes of $15.1 million, partially offset by net proceeds from the issuance of the 2029 Notes of $166.3 million and $13.4 million in proceeds from employee stock option exercises and ESPP purchases.

[0000926326-26-000006:mdna:113]
Contractual Obligations

[0000926326-26-000006:mdna:114]
Contractual obligations as of December 31, 2025 were as follows:

[0000926326-26-000006:mdna:115]
|  | Payments Due By Period |
|  | Total |  | 2026 |  | 2027 - 2028 |  | 2029 - 2030 |  | 2031 and thereafter |
|  | (In thousands) |
| Operating leases (1) | $ | 40,314 |  |  | $ | 13,645 |  |  | $ | 21,621 |  |  | $ | 3,772 |  |  | $ | 1,276 |  |
| Purchase obligations (2) | 130,546 |  |  | 123,147 |  |  | 7,376 |  |  | 23 |  |  | — |  |
| Convertible senior notes (3) | 179,405 |  |  | 1,725 |  |  | 3,450 |  |  | 174,230 |  |  | — |  |
| Total (4) | $ | 350,265 |  |  | $ | 138,517 |  |  | $ | 32,447 |  |  | $ | 178,025 |  |  | $ | 1,276 |  |

[0000926326-26-000006:mdna:116]
_________________________________________________

[0000926326-26-000006:mdna:117]
(1)Commitments under operating leases relate primarily to leased office buildings, data centers, office equipment, and vehicles. Refer to Note 13, Lessee Leases, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K for additional information.

[0000926326-26-000006:mdna:118]
(2)We purchase components from a variety of suppliers and use contract manufacturers to provide manufacturing services for our products. During the normal course of business, we issue purchase orders with estimates of our requirements several months ahead of the delivery dates. These amounts are associated with agreements that are enforceable and legally binding. The amounts under such contracts are included in the table above because we believe that cancellation of these contracts is unlikely and we expect to make future cash payments according to the contract terms or in similar amounts for similar materials.

[0000926326-26-000006:mdna:119]
(3)We issued the 2029 Notes in November 2024 that are due in December 2029. The obligations presented above include both principal and interest on these notes. Although these notes mature in 2029, they may be converted into cash and shares of our common stock prior to maturity if certain conditions are met. Any conversion prior to maturity can result in repayment of the principal amounts sooner than the scheduled repayment as indicated in the table above. Refer to Note 11, Convertible Senior Notes, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K for additional information.

[0000926326-26-000006:mdna:120]
(4)Refer to Note 14, Commitments and Contingencies, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K for additional information.
