# OMCL 8-K — 0000926326-26-000003 filed 2026-02-05

## item codes, every 8-K on or before 2026-02-26

- 2026-02-05 0000926326-26-000003 — 2.02, 9.01
- 2025-12-08 0001104659-25-119083 — 7.01, 9.01
- 2025-10-30 0000926326-25-000029 — 2.02, 9.01
- 2025-10-06 0000926326-25-000026 — 5.03, 9.01
- 2025-08-25 0001104659-25-082526 — 5.02, 9.01
- 2025-07-31 0000926326-25-000016 — 2.02, 9.01
- 2025-06-05 0001104659-25-056908 — 5.02, 9.01
- 2025-05-23 0001104659-25-052464 — 5.02, 5.07, 9.01
- 2025-05-22 0001104659-25-051854 — 7.01, 9.01
- 2025-05-06 0000926326-25-000006 — 2.02, 9.01
- 2025-03-12 0001104659-25-022797 — 5.02, 7.01, 9.01
- 2025-03-04 0001104659-25-020354 — 5.02, 9.01
- 2025-02-06 0001104659-25-009872 — 2.02, 9.01
- 2024-11-25 0001104659-24-122635 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2024-11-18 0001104659-24-120206 — 1.01, 8.01, 9.01
- 2024-10-30 0000926326-24-000030 — 2.02, 9.01
- 2024-09-25 0001104659-24-102781 — 5.02, 9.01
- 2024-08-01 0000926326-24-000024 — 2.02, 9.01
- 2024-06-04 0000926326-24-000019 — 5.02 — amendment of 0001104659-24-029356
- 2024-05-24 0001104659-24-065130 — 5.02, 5.07, 9.01
- 2024-05-02 0000926326-24-000012 — 2.02, 2.05, 9.01
- 2024-02-29 0001104659-24-029356 — 5.02
- 2024-02-08 0000926326-24-000005 — 2.02, 9.01
- 2024-01-11 0000926326-24-000002 — 5.02, 7.01, 8.01, 9.01
- 2023-11-09 0000926326-23-000043 — 5.02, 9.01
- 2023-11-02 0001104659-23-113604 — 2.02, 2.05, 7.01, 9.01
- 2023-10-16 0000926326-23-000039 — 1.01, 2.03, 9.01
- 2023-10-05 0000926326-23-000037 — 5.02, 9.01
- 2023-08-16 0000926326-23-000035 — 5.02
- 2023-08-10 0000926326-23-000033 — 5.02, 9.01
- 2023-08-03 0000926326-23-000029 — 5.02, 9.01
- 2023-08-01 0000926326-23-000027 — 2.02, 9.01
- 2023-07-11 0000926326-23-000025 — 5.02, 9.01
- 2023-06-26 0000926326-23-000022 — 5.02 — amendment of 0001104659-23-026700
- 2023-05-30 0001104659-23-066011 — 5.02, 9.01
- 2023-05-26 0000926326-23-000020 — 5.02, 5.07, 9.01
- 2023-05-15 0001104659-23-060768 — 5.02, 9.01
- 2023-05-02 0000926326-23-000011 — 2.02, 9.01
- 2023-04-03 0000926326-23-000009 — 1.01, 2.03, 9.01
- 2023-02-28 0001104659-23-026700 — 2.02, 2.05, 5.02, 9.01
- 2022-11-30 0000926326-22-000036 — 2.05
- 2022-11-02 0000926326-22-000031 — 2.02, 9.01
- 2022-10-21 0000926326-22-000029 — 5.03, 9.01
- 2022-09-20 0001104659-22-101566 — 7.01, 9.01
- 2022-09-20 0001104659-22-101360 — 7.01, 9.01
- 2022-08-04 0000926326-22-000025 — 2.02, 8.01, 9.01
- 2022-05-31 0000926326-22-000020 — 5.02, 5.07, 9.01
- 2022-05-24 0000926326-22-000016 — 5.02
- 2022-05-09 0000926326-22-000012 — 8.01
- 2022-04-28 0000926326-22-000009 — 2.02, 9.01
- 2022-03-01 0001104659-22-028681 — 5.02, 8.01, 9.01
- 2022-02-14 0000926326-22-000004 — 2.02, 9.01
- 2022-01-04 0000926326-22-000002 — 7.01, 9.01
- 2021-12-29 0001104659-21-154294 — 7.01, 9.01
- 2021-12-13 0000926326-21-000039 — 8.01
- 2021-12-02 0000926326-21-000037 — 7.01, 9.01
- 2021-11-02 0000926326-21-000031 — 2.02, 9.01
- 2021-09-09 0000926326-21-000028 — 7.01, 9.01
- 2021-07-29 0000926326-21-000024 — 2.02, 9.01
- 2021-07-26 0000926326-21-000022 — 7.01, 9.01
- 2021-07-12 0000926326-21-000019 — 5.02, 9.01
- 2021-05-28 0000926326-21-000015 — 5.07
- 2021-04-29 0000926326-21-000011 — 2.02, 9.01
- 2021-02-01 0000926326-21-000004 — 2.02, 9.01
- 2021-01-26 0000926326-21-000002 — 5.02
- 2021-01-13 0001104659-21-003672 — 2.02, 7.01, 9.01
- 2020-10-27 0000926326-20-000032 — 2.02, 9.01
- 2020-10-01 0000926326-20-000029 — 7.01, 9.01
- 2020-09-25 0001104659-20-108924 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2020-09-22 0001104659-20-107176 — 1.01, 8.01, 9.01
- 2020-08-12 0000926326-20-000027 — 2.03
- 2020-08-12 0000926326-20-000025 — 1.01, 5.03, 7.01, 9.01
- 2020-07-28 0000926326-20-000021 — 2.02, 9.01
- 2020-05-27 0000926326-20-000017 — 5.07
- 2020-05-07 0000926326-20-000012 — 2.02, 9.01
- 2020-02-18 0000926326-20-000007 — 5.02, 9.01
- 2020-02-13 0000926326-20-000005 — 8.01
- 2020-02-06 0000926326-20-000003 — 2.02, 9.01
- 2019-12-06 0001104659-19-070339 — 8.01
- 2019-11-18 0000926326-19-000035 — 1.01, 2.03, 9.01
- 2019-10-24 0000926326-19-000028 — 2.02, 9.01
- 2019-07-25 0000926326-19-000021 — 2.02, 9.01
- 2019-05-15 0000926326-19-000015 — 5.07
- 2019-04-25 0000926326-19-000011 — 2.02, 9.01
- 2019-03-08 0000926326-19-000009 — 5.02, 9.01
- 2019-02-19 0000926326-19-000005 — 5.02, 9.01
- 2019-02-07 0000926326-19-000003 — 2.02, 9.01
- 2018-10-25 0000926326-18-000028 — 2.02, 9.01
- 2018-09-14 0001104659-18-056929 — 5.02, 9.01
- 2018-07-26 0000926326-18-000022 — 2.02, 9.01
- 2018-06-06 0000926326-18-000019 — 5.02, 9.01
- 2018-05-16 0001104659-18-033801 — 5.07
- 2018-04-26 0000926326-18-000013 — 2.02, 9.01
- 2018-03-02 0001104659-18-014497 — 5.02
- 2018-02-08 0000926326-18-000007 — 5.02
- 2018-02-02 0000926326-18-000005 — 5.02
- 2018-02-01 0000926326-18-000003 — 2.02, 9.01
- 2017-12-26 0000926326-17-000041 — 1.01, 2.03, 9.01
- 2017-11-03 0001104659-17-066102 — 1.01, 8.01, 9.01
- 2017-10-26 0000926326-17-000035 — 2.02, 9.01
- 2017-08-03 0000926326-17-000028 — 5.07 — amendment, the index does not say of what
- 2017-07-27 0000926326-17-000026 — 2.02, 9.01
- 2017-07-25 0000926326-17-000023 — 5.02, 9.01
- 2017-05-24 0000926326-17-000019 — 5.07
- 2017-05-04 0001628280-17-004851 — 2.02, 9.01
- 2017-02-15 0000926326-17-000010 — 2.05
- 2017-02-15 0000926326-17-000008 — 2.02, 9.01
- 2017-02-13 0000926326-17-000002 — 5.02
- 2016-12-08 0001104659-16-161330 — 2.01, 2.03, 9.01
- 2016-12-06 0001104659-16-160709 — 7.01
- 2016-11-29 0001104659-16-159456 — 1.01, 7.01, 9.01
- 2016-10-27 0000926326-16-000075 — 2.02, 9.01
- 2016-10-07 0000926326-16-000072 — 5.02, 8.01
- 2016-08-05 0000926326-16-000068 — 8.01
- 2016-07-28 0000926326-16-000066 — 2.02, 9.01
- 2016-06-13 0001104659-16-126854 — 5.02
- 2016-05-25 0000926326-16-000060 — 5.07
- 2016-04-28 0000926326-16-000054 — 2.02, 9.01
- 2016-03-21 0001104659-16-106649 — 8.01, 9.01
- 2016-03-17 0000926326-16-000051 — 7.01, 9.01
- 2016-03-17 0000926326-16-000049 — 9.01 — amendment of 0000926326-16-000051
- 2016-02-10 0001104659-16-095486 — 5.02, 9.01
- 2016-02-04 0000926326-16-000041 — 2.02, 9.01
- 2016-01-06 0001104659-16-088299 — 1.01, 2.01, 2.03, 9.01
- 2015-12-10 0000926326-15-000038 — 8.01, 9.01
- 2015-10-29 0001104659-15-074138 — 1.01, 9.01
- 2015-10-29 0000926326-15-000031 — 2.02, 9.01
- 2015-08-20 0001104659-15-061135 — 5.02, 9.01
- 2015-07-30 0000926326-15-000024 — 2.02, 9.01
- 2015-05-22 0001104659-15-040440 — 5.07
- 2015-05-01 0001104659-15-032846 — 5.02
- 2015-05-01 0001104659-15-032844 — 7.01
- 2015-04-30 0000926326-15-000015 — 9.01
- 2015-04-22 0001104659-15-029356 — 8.01, 9.01
- 2015-03-20 0001104659-15-021435 — 3.01
- 2015-03-18 0001104659-15-020699 — 7.01
- 2015-03-17 0001104659-15-020483 — 8.01, 9.01
- 2015-03-02 0001104659-15-015802 — 1.01, 9.01
- 2015-02-12 0001104659-15-009234 — 5.02, 9.01
- 2015-02-03 0000926326-15-000003 — 9.01
- 2015-01-15 0001104659-15-002635 — 5.02
- 2014-11-07 0001104659-14-078398 — 1.01, 8.01, 9.01
- 2014-10-30 0000926326-14-000037 — 2.02, 9.01
- 2014-08-25 0001104659-14-062772 — 8.01, 9.01
- 2014-07-31 0000926326-14-000032 — 2.02, 9.01
- 2014-05-21 0001104659-14-040744 — 5.07
- 2014-05-01 0000926326-14-000008 — 2.02, 9.01
- 2014-04-08 0001104659-14-026441 — 4.01, 9.01
- 2014-04-02 0001104659-14-025179 — 5.02
- 2014-02-07 0001104659-14-007552 — 5.02, 9.01
- 2014-02-04 0001104659-14-006352 — 2.02, 9.01
- 2013-12-09 0001104659-13-088980 — 1.01, 9.01
- 2013-12-02 0001104659-13-087877 — 5.02
- 2013-10-31 0001104659-13-079660 — 2.02, 9.01
- 2013-09-26 0001104659-13-072435 — 1.01, 2.03, 9.01
- 2013-08-01 0001104659-13-058959 — 2.02, 9.01
- 2013-05-23 0001104659-13-044317 — 5.07
- 2013-05-02 0001104659-13-036605 — 2.02, 9.01
- 2013-03-11 0001104659-13-019143 — 8.01
- 2013-02-07 0001104659-13-008477 — 5.02, 9.01
- 2013-01-31 0001104659-13-006446 — 2.02, 9.01
- 2012-11-02 0001104659-12-073697 — 5.02
- 2012-10-25 0001104659-12-071211 — 2.02, 9.01
- 2012-08-06 0001104659-12-054635 — 8.01
- 2012-08-03 0001104659-12-054214 — 2.01, 9.01 — amendment of 0001104659-12-038888
- 2012-08-01 0001104659-12-053005 — 2.02, 9.01
- 2012-06-12 0001104659-12-042936 — 8.01, 9.01
- 2012-05-23 0001104659-12-039459 — 5.07
- 2012-05-22 0001104659-12-038888 — 2.01, 9.01
- 2012-05-02 0001104659-12-032048 — 2.02, 9.01
- 2012-05-02 0001104659-12-032036 — 1.01, 9.01
- 2012-04-04 0001104659-12-023883 — 5.02, 8.01
- 2012-03-20 0001104659-12-019462 — 1.01, 9.01
- 2012-02-13 0001104659-12-009353 — 5.02, 9.01
- 2012-01-26 0001104659-12-004244 — 2.02, 9.01
- 2011-10-27 0001104659-11-058464 — 2.02, 9.01
- 2011-10-25 0001104659-11-057721 — 1.01
- 2011-07-28 0001104659-11-041505 — 2.02, 9.01
- 2011-05-27 0001104659-11-032006 — 5.07
- 2011-05-02 0001104659-11-024908 — 2.02, 9.01
- 2011-04-15 0001104659-11-020407 — 5.02, 9.01 — amendment of 0001104659-11-005638
- 2011-02-08 0001104659-11-005638 — 5.02, 9.01
- 2011-01-27 0001104659-11-003419 — 2.02, 9.01
- 2010-12-22 0001104659-10-064003 — 5.02, 5.07, 9.01
- 2010-10-27 0001104659-10-054036 — 2.02, 9.01
- 2010-10-05 0001104659-10-051173 — 8.01
- 2010-07-22 0001104659-10-039126 — 2.02, 9.01
- 2010-07-09 0001104659-10-037594 — 2.05
- 2010-05-28 0001104659-10-031607 — 5.07
- 2010-04-26 0001104659-10-021797 — 2.02, 9.01
- 2010-03-17 0001104659-10-014849 — 5.02, 9.01
- 2010-02-08 0001104659-10-005457 — 5.02, 9.01
- 2010-01-28 0001104659-10-003627 — 2.02, 9.01
- 2009-10-22 0001104659-09-059972 — 2.02, 9.01
- 2009-07-23 0001104659-09-044508 — 2.02, 9.01
- 2009-05-20 0001104659-09-033938 — 5.02, 9.01
- 2009-04-30 0001104659-09-027707 — 2.02, 9.01
- 2009-03-10 0001104659-09-016178 — 5.02, 9.01
- 2009-02-09 0001104659-09-007692 — 5.02, 9.01
- 2009-01-29 0001104659-09-005022 — 2.02, 2.05, 9.01
- 2009-01-21 0001104659-09-003180 — 2.02, 8.01, 9.01
- 2009-01-06 0001104659-09-000625 — 5.02
- 2008-10-23 0001104659-08-065475 — 2.02, 9.01
- 2008-07-21 0001104659-08-046690 — 2.02, 9.01
- 2008-05-16 0001104659-08-034035 — 8.01, 9.01
- 2008-04-28 0001104659-08-027379 — 7.01, 9.01
- 2008-04-21 0001104659-08-025616 — 2.02, 9.01
- 2008-03-12 0001104659-08-016939 — 7.01, 9.01
- 2008-02-26 0001104659-08-012840 — 7.01, 9.01
- 2008-02-12 0001104659-08-009382 — 5.02, 9.01
- 2008-01-31 0001104659-08-006199 — 2.02, 9.01
- 2007-12-05 0001104659-07-087191 — 1.01, 9.01
- 2007-10-18 0001104659-07-075654 — 2.02, 9.01
- 2007-07-27 0001104659-07-056886 — 5.03, 9.01
- 2007-07-19 0001104659-07-054924 — 2.02, 9.01
- 2007-05-23 0001104659-07-042287 — 8.01, 9.01
- 2007-05-07 0001104659-07-036172 — 1.01, 5.02, 9.01
- 2007-04-24 0001104659-07-030578 — 2.02, 9.01 — amendment, the index does not say of what
- 2007-04-24 0001104659-07-030547 — 2.02, 9.01
- 2007-04-10 0001104659-07-027465 — 5.02, 9.01
- 2007-03-23 0001104659-07-021969 — 2.02, 4.02, 9.01
- 2007-01-30 0001104659-07-005772 — 2.02, 9.01
- 2007-01-09 0001104659-07-001600 — 5.02, 9.01
- 2006-10-30 0001104659-06-069612 — 1.01
- 2006-10-19 0001104659-06-067549 — 2.02, 9.01
- 2006-07-20 0001104659-06-048020 — 2.02, 4.02, 9.01
- 2006-05-17 0001104659-06-035522 — 1.01, 9.01 — amendment of 0001104659-05-011155
- 2006-05-09 0001104659-06-032706 — 1.01, 9.01
- 2006-04-25 0001104659-06-027438 — 2.02, 9.01
- 2006-04-04 0001104659-06-022204 — 1.01, 9.01
- 2006-03-15 0001104659-06-016861 — 1.01, 9.01
- 2006-01-30 0001104659-06-004749 — 2.02, 9.01
- 2006-01-24 0001104659-06-003504 — 1.01, 5.02, 9.01
- 2005-12-13 0001104659-05-060532 — 1.01, 9.01
- 2005-11-10 0001104659-05-054663 — 2.02, 9.01
- 2005-07-21 0001104659-05-033464 — 2.02, 9.01
- 2005-06-22 0001104659-05-029255 — 1.01
- 2005-05-16 0001104659-05-023473 — 2.02, 9.01 — amendment of 0001104659-05-018173
- 2005-05-16 0001104659-05-023471 — 2.02, 9.01 — amendment of 0001104659-05-017382
- 2005-05-10 0001104659-05-022127 — 1.01
- 2005-04-26 0001104659-05-018173 — 2.02, 9.01
- 2005-04-21 0001104659-05-017382 — 2.02, 9.01
- 2005-04-06 0001104659-05-015401 — 5.02
- 2005-03-15 0001104659-05-011155 — 1.01, 9.01
- 2005-03-08 0001104659-05-009975 — 1.01, 9.01
- 2005-02-03 0001104659-05-003943 — 2.02, 9.01
- 2005-01-13 0001104659-05-001314 — 5.02, 9.01
- 2004-10-21 0001104659-04-031413 — 2.02, 9.01
- 2004-07-22 0001104659-04-020572 — 12, 7
- 2004-04-14 0001104659-04-010039 — 12, 7
- 2004-04-05 0001104659-04-009437 — 12, 7
- 2004-01-26 0001104659-04-001655 — 12, 7
- 2003-10-16 0001104659-03-022990 — 12, 7
- 2003-07-17 0001104659-03-015053 — 9
- 2003-04-18 0001104659-03-006823 — 7, 9
- 2003-02-14 0001104659-03-002607 — 5, 7

## late-filing notifications on or before 2026-02-26

- 2015-03-02 0000926326-15-000006 — NT 10-K, for the period ended 2014-12-31
- 2007-03-16 0001104659-07-020094 — NT 10-K, for the period ended 2006-12-31

## item 2.02 — earnings release, exhibit 99.1

[0000926326-26-000003:8k_2_02:1]
EX-99.1
2
exhibit991q4-25.htm
EX-99.1

[0000926326-26-000003:8k_2_02:2]
Document

[0000926326-26-000003:8k_2_02:3]
Exhibit 99.1

[0000926326-26-000003:8k_2_02:4]
| Contact: |  |  |
| Kathleen Nemeth |  | Omnicell, Inc. |
| Senior Vice President, Investor Relations |  | 4220 North Freeway |
| 650-435-3318 |  | Fort Worth, TX 76137 |
| Kathleen.Nemeth@Omnicell.com |  |  |

[0000926326-26-000003:8k_2_02:5]
Omnicell Announces Fiscal Year and Fourth Quarter 2025 Financial Results

[0000926326-26-000003:8k_2_02:6]
Omnicell delivers solid fourth quarter 2025 financial results

[0000926326-26-000003:8k_2_02:7]
Announces major step toward autonomous medication management with the launch of its next generation dispensing system, Titan XT, at the American Society of Health-System Pharmacists (ASHP) 2025 Midyear Clinical Meeting & Exhibition

[0000926326-26-000003:8k_2_02:8]
FORT WORTH, Texas. -- February 5, 2026 -- Omnicell, Inc. (NASDAQ:OMCL) (“Omnicell,” “we,” “our,” “us,” “management,” or the “Company”), a leading healthcare technology provider focused on empowering autonomous medication management, today announced results for its fiscal year and fourth quarter ended December 31, 2025.

[0000926326-26-000003:8k_2_02:9]
“We finished 2025 with solid fourth quarter financial results, delivering full year 2025 total revenues, product bookings and annual recurring revenues (“ARR”) all above the mid-point of our previously issued guidance ranges,” stated Randall Lipps, chairman, president, chief executive officer, and founder of Omnicell. “As we look ahead, we are focused on delivering long-term, sustainable, and profitable growth. The launch of Titan XT intends to address a significant need for an enhanced and more efficient medication management experience that combines proven automation with powerful intelligence and extends beyond the pharmacy into nursing care areas. We believe that our innovation roadmap continues to resonate with our customers, and I am optimistic for what the future holds for Omnicell in 2026 and beyond.”

[0000926326-26-000003:8k_2_02:10]
Financial Results

[0000926326-26-000003:8k_2_02:11]
Total revenues for the fourth quarter of 2025 were $314 million, up $7 million, or 2%, from the fourth quarter of 2024. The quarter-over-quarter increase in total revenues was driven by strength in our technical service offerings and SaaS and Expert Services revenues, as well as increases in our consumables revenues. Total revenues for the year ended December 31, 2025 were $1.185 billion, up $73 million, or 7%, from the year ended December 31, 2024. The year-over-year increase in total revenues was driven by strength in our connected devices and technical service offerings, as well as increases in our SaaS and Expert Services and consumables revenues.

[0000926326-26-000003:8k_2_02:12]
Total GAAP net loss for the fourth quarter of 2025 was $2 million, or $0.05 per diluted share. This compares to GAAP net income of $16 million, or $0.34 per diluted share, for the fourth quarter of 2024. Total GAAP net income for the year ended December 31, 2025 was $2 million, or $0.04 per diluted share. This compares to GAAP net income of $13 million, or $0.27 per diluted share, for the year ended December 31, 2024.

[0000926326-26-000003:8k_2_02:13]
Total non-GAAP net income for the fourth quarter of 2025 was $18 million, or $0.40 per diluted share. This compares to non-GAAP net income of $28 million, or $0.60 per diluted share, for the fourth quarter of 2024. Total non-GAAP net income for the year ended December 31, 2025 was $75 million, or $1.62 per diluted share. This compares to non-GAAP net income of $79 million, or $1.71 per diluted share, for the year ended December 31, 2024.

[0000926326-26-000003:8k_2_02:14]
Total non-GAAP EBITDA for the fourth quarter of 2025 was $37 million. This compares to non-GAAP EBITDA of $46 million for the fourth quarter of 2024. Total non-GAAP EBITDA for the year ended December 31, 2025 was $140 million. This compares to non-GAAP EBITDA of $136 million for the year ended December 31, 2024.

[0000926326-26-000003:8k_2_02:15]
Product Bookings, Product Backlog and Annual Recurring Revenue

[0000926326-26-000003:8k_2_02:16]
We utilize product bookings(1) and Annual Recurring Revenue (“ARR”), each as further described below, as key performance metrics for our business. For the year ended December 31, 2025, product bookings were $535 million compared to $558 million for the year ended December 31, 2024, or a decrease of 4% year-over-year, as we are in the late stage of the XT upgrade cycle. The chart below summarizes our total product backlog (2) and ARR (3):

[0000926326-26-000003:8k_2_02:17]
|  | December 31, |
|  | 2025 |  | 2024 |
|  | (In thousands) |
| Total product backlog (2) | $ | 640,301 |  |  | $ | 646,440 |  |
| By duration: |  |  |  |
| Short-term product backlog | $ | 435,151 |  |  | $ | 447,344 |  |
| Long-term product backlog | 205,150 |  |  | 199,096 |  |
| Annual Recurring Revenue (3) | $ | 635,555 |  |  | $ | 580,025 |  |

[0000926326-26-000003:8k_2_02:18]
________________________________________________

[0000926326-26-000003:8k_2_02:19]
(1)    We define product bookings generally as the value of non-cancelable contracts for our connected devices and software licenses. We typically exclude freight revenue and other less significant items ancillary to our products from product bookings. In addition, dependent upon counterparty or credit risk, which is evaluated at the time of contract signing, for a given multi-year subscription contract we may reduce the value of the contractual commitment booked at a given time. Connected devices and software license bookings are recorded as revenue upon customer acceptance of the installation or receipt of goods. We utilize product bookings as an indicator of the success of certain portions of our business that generate non-recurring revenue.

[0000926326-26-000003:8k_2_02:20]
(2)    Product backlog is the dollar amount of product bookings related to connected devices and software licenses that have not yet been recognized as revenue. A majority of our connected devices and software license products are installable and recognized as revenues within twelve months of booking. Larger or more complex implementations such as software-enabled connected devices for Central Pharmacy, including, but not limited to, our Central Pharmacy Dispensing Service and IV Compounding Service, are often installed and recognized as revenue between 12 and 24 months after booking. Due to industry practice that allows customers to change order configurations with limited advance notice prior to shipment and as customer installation schedules may change, backlog as of any particular date may not necessarily indicate the timing of future revenue. However, we do believe that backlog is an indication of a customer’s willingness to install our solutions and revenue we expect to generate over time. We consider backlog that is expected to be converted to revenues in more than twelve months to be long-term backlog. We believe a majority of long-term product backlog will be convertible into revenues in 12-24 months.

[0000926326-26-000003:8k_2_02:21]
(3)    We consider revenues generated from our consumables, technical services, and SaaS and Expert Services to be recurring revenues. For the portions of our business which generate recurring revenues, we utilize ARR as a key metric to measure our progress in growing our recurring revenue business. We define ARR at a measurement date as the revenue we expect to receive from our customers over the course of the following year for providing them with products or services. ARR includes expected revenue from all customers who are using our products or services at the reported date. For technical services and SaaS and Expert Services, solutions are generally on a contractual basis, typically with contracts for a period of 12 months or more, with a high probability of renewal. Probability of renewal is based on historic renewal experience of the individual revenue streams or management’s best estimates if historical renewal experience is not available. Consumables orders are placed by customers through our Omnicell Storefront online platform or through written or telephonic orders and are sold to a customer base who utilize the consumable product and place recurring orders when customer inventory is depleted. ARR is generally calculated based on revenues received in the most recent quarter and changes to expected revenues where solutions were added to or removed from the install or customer base in the quarter. Revenues from technical services and SaaS and Expert Services are generally recorded ratably over the service term. As part of our SaaS and Expert Services offerings, we provide a range of services to our customers including Central Pharmacy Dispensing Service (service portion), IV Compounding Service (service portion), EnlivenHealth, Specialty Pharmacy Services, 340B solutions, Inventory Optimization Service, and other software solutions, which typically are provided over two to seven years. In addition, to help ensure the maximum availability of our systems, our customers typically purchase technical services contracts (support and maintenance) in increments of one to five years. Revenue from consumables are recorded when the product has shipped and title has passed. Our measure of ARR may be different than that used by other companies. Because ARR is based on expected future revenue, it does not represent revenue recognized during a particular reporting period or revenue to be recognized in future reporting periods. ARR should not be viewed as a substitute for GAAP revenues.

[0000926326-26-000003:8k_2_02:22]
2

[0000926326-26-000003:8k_2_02:23]
Balance Sheet

[0000926326-26-000003:8k_2_02:24]
As of December 31, 2025, Omnicell’s balance sheet reflected cash and cash equivalents of $197 million, total debt (net of unamortized debt issuance costs) of $168 million, and total assets of $1.97 billion. Cash flows provided by operating activities in the fourth quarter of 2025 totaled $30 million. This compares to cash flows provided by operating activities totaling $56 million in the fourth quarter of 2024.

[0000926326-26-000003:8k_2_02:25]
As of December 31, 2025, the Company had $350 million of availability under its revolving credit facility with no outstanding balance.

[0000926326-26-000003:8k_2_02:26]
Corporate Highlights

[0000926326-26-000003:8k_2_02:27]
•In December 2025, the Company announced Omnicell Titan XT, a transformational, enterprise version of automated dispensing systems (ADS). Designed to unify proven automation and powerful intelligence, Titan XT is built to deliver an enhanced and more efficient medication management experience to support a growing health system. With this launch, the power of OmniSphere is meant to extend to nursing care areas, designed to deliver greater control of medication inventory management for pharmacy, while providing nurses with more confidence when administering medications.

[0000926326-26-000003:8k_2_02:28]
•More than 4,000 pharmacy leaders connected with Omnicell during December’s American Society of Health-System Pharmacists (ASHP) Midyear 2025 Clinical Meeting and Exhibition, where they had the opportunity to explore how Omnicell is working to empower autonomous medication management to drive intelligent outcomes, deliver a better clinician experience, expand visibility and oversight for pharmacy enterprise, enhance safety and accuracy in the IV cleanroom, and transform outpatient care delivery.

[0000926326-26-000003:8k_2_02:29]
•Omnicell was once again recognized as one of the Top 50 Healthcare Technology Companies by the Healthcare Technology Report for continuous focus on innovation designed to help healthcare organizations deliver better, more precise care. Randall Lipps was also named one of the Top Healthcare Technology CEOs of 2025 by the Healthcare Technology Report.

[0000926326-26-000003:8k_2_02:30]
2026 Guidance

[0000926326-26-000003:8k_2_02:31]
The table below summarizes Omnicell’s first quarter and full year 2026 guidance:

[0000926326-26-000003:8k_2_02:32]
|  | Q1 2026 |  | 2026 |
| Product Bookings | Not provided |  | $510 million - $560 million |
| Annual Recurring Revenue | Not provided |  | $680 million - $700 million |
| Total Revenues | $300 million - $310 million |  | $1.215 billion - $1.255 billion |
| Product Revenues | $171 million - $176 million |  | $690 million - $710 million |
| Service Revenues | $129 million - $134 million |  | $525 million - $545 million |
| Technical Services Revenues | Not provided |  | $260 million - $270 million |
| SaaS and Expert Service Revenues | Not provided |  | $265 million - $275 million |
| Non-GAAP EBITDA | $27 million - $33 million |  | $145 million - $160 million |
| Non-GAAP Earnings Per Share | $0.26 - $0.36 |  | $1.65 - $1.85 |

[0000926326-26-000003:8k_2_02:33]
The Company does not provide guidance for GAAP net income or GAAP earnings per share, nor a reconciliation of any forward-looking non-GAAP financial measures to the most directly comparable GAAP financial measures on a forward-looking basis because it is unable to predict certain items contained in the GAAP measures without unreasonable efforts. These forward-looking non-GAAP financial measures do not include certain items, which may be significant, including, but not limited to, unusual gains and losses, costs associated with future restructurings, acquisition-related expenses, and certain tax and litigation outcomes.

[0000926326-26-000003:8k_2_02:34]
Omnicell Conference Call Information

[0000926326-26-000003:8k_2_02:35]
Omnicell will hold a conference call today, Thursday, February 5, 2026, at 8:30 a.m. ET to discuss fiscal year and fourth quarter 2025 financial results. The conference call can be monitored by dialing (800) 715-9871 in the U.S. or (646) 307-1963 in international locations. The Conference ID is 4203777. A link to the live and archived webcast will also be available on the Investor Relations section of Omnicell’s website at https://ir.omnicell.com/events-and-presentations/.

[0000926326-26-000003:8k_2_02:36]
3

[0000926326-26-000003:8k_2_02:37]
About Omnicell

[0000926326-26-000003:8k_2_02:38]
Since 1992, Omnicell has been committed to delivering innovative, outcomes-centric pharmacy and nursing solutions for all settings of care. As an intelligent medication management technology company, Omnicell empowers autonomous medication management by unifying automation and AI-enabled intelligence, optimized by expert services, to drive clinical and business outcomes that are helping to improve efficiency and enhance patient safety for healthcare facilities worldwide. Learn more at omnicell.com.

[0000926326-26-000003:8k_2_02:39]
From time to time, Omnicell may use the Company’s investor relations website and other online social media channels, including its LinkedIn page www.linkedin.com/company/omnicell, and Facebook page www.facebook.com/omnicellinc, to disclose material non-public information and comply with its disclosure obligations under Regulation Fair Disclosure (“Reg FD”).

[0000926326-26-000003:8k_2_02:40]
OMNICELL and the Omnicell logo are registered trademarks of Omnicell, Inc. or one of its subsidiaries. This press release may also include the trademarks and service marks of other companies. Such trademarks and service marks are the marks of their respective owners.

[0000926326-26-000003:8k_2_02:41]
Forward-Looking Statements

[0000926326-26-000003:8k_2_02:42]
4

[0000926326-26-000003:8k_2_02:43]
Use of Non-GAAP Financial Information

[0000926326-26-000003:8k_2_02:44]
This press release contains financial measures that are not calculated in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”). Management evaluates and makes operating decisions using various performance measures. In addition to Omnicell’s GAAP results, we also consider non-GAAP product gross profit, non-GAAP product gross margin, non-GAAP service gross profit, non-GAAP service gross margin, non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP operating margin, non-GAAP net income, non-GAAP net income per diluted share, non-GAAP diluted shares, non-GAAP EBITDA, non-GAAP EBITDA margin, and non-GAAP free cash flow. These non-GAAP results and metrics should not be considered as an alternative to revenues, product gross profit, service gross profit, gross profit, operating expenses, income from operations, net income, net income per diluted share, diluted shares, net cash provided by operating activities, or any other performance measure derived in accordance with GAAP. We present these non-GAAP results and metrics because management considers them to be important supplemental measures of Omnicell’s performance and refers to such measures when analyzing Omnicell’s strategy and operations.

[0000926326-26-000003:8k_2_02:45]
Our non-GAAP product gross profit, non-GAAP product gross margin, non-GAAP service gross profit, non-GAAP service gross margin, non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP operating margin, non-GAAP net income, non-GAAP net income per diluted share, non-GAAP EBITDA, and non-GAAP EBITDA margin are exclusive of certain items to facilitate management’s review of the comparability of Omnicell’s core operating results on a period-to-period basis because such items are not related to Omnicell’s ongoing core operating results as viewed by management. We define our “core operating results” as those revenues recorded in a particular period and the expenses incurred within such period that directly drive operating income in such period. Management uses these non-GAAP financial measures in making operating decisions because, in addition to meaningful supplemental information regarding operating performance, the measures give us a better understanding of how we believe we should invest in research and development, fund infrastructure growth, and evaluate the effectiveness of marketing strategies. In calculating the above non-GAAP results: non-GAAP product gross profit and non-GAAP product gross margin exclude from their GAAP equivalents items a), b), and f) below; non-GAAP service gross profit, non-GAAP service gross margin, non-GAAP gross profit and non-GAAP gross margin exclude from their GAAP equivalents items a), b), e), and f) below; non-GAAP operating expenses, non-GAAP income from operations and non-GAAP operating margin exclude from their GAAP equivalents items a), b), c), e), f), g), h), and i) below; and non-GAAP net income and non-GAAP net income per diluted share exclude from their GAAP equivalents items a) through j) below. Non-GAAP EBITDA is defined as earnings before interest income and expense, taxes, depreciation, amortization, and share-based compensation, as well as excluding certain other non-GAAP adjustments. Non-GAAP EBITDA and non-GAAP EBITDA margin exclude from their GAAP equivalents items a), c), d), e), f), g), h), i), and j) below:

[0000926326-26-000003:8k_2_02:46]
a)Share-based compensation expense. We excluded from our non-GAAP results the expense related to equity-based compensation plans as it represents expenses that do not require cash settlement from Omnicell.

[0000926326-26-000003:8k_2_02:47]
b)Amortization of acquired intangible assets. We excluded from our non-GAAP results the intangible assets amortization expense resulting from our past acquisitions. These non-cash charges are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results.

[0000926326-26-000003:8k_2_02:48]
c)Acquisition-related expenses. We excluded from our non-GAAP results the expenses related to recent acquisitions, including amortization of representations and warranties insurance. These expenses are unrelated to our ongoing operations, vary in size and frequency, and are subject to significant fluctuations from period to period due to varying levels of acquisition activity. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of peer companies.

[0000926326-26-000003:8k_2_02:49]
d)Amortization of debt issuance costs. Debt issuance costs represent costs associated with the issuance of revolving credit facilities and convertible senior notes. The costs include underwriting fees, original issue discount, ticking fees, and legal fees. These non-cash expenses are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results.

[0000926326-26-000003:8k_2_02:50]
e)EnlivenHealth restructuring. We excluded from our non-GAAP results the nonrecurring charges primarily related to restructuring within the EnlivenHealth business as we seek to gain operational efficiency and synergy, and adapt to the

[0000926326-26-000003:8k_2_02:51]
recent industry dynamics within the retail pharmacy space. These charges consisted primarily of severance and other related expenses. These expenses are unrelated to our ongoing operations and we believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of peer companies.

[0000926326-26-000003:8k_2_02:52]
f)RDS restructuring. We excluded from our non-GAAP results the nonrecurring restructuring charges related to the wind down of the Company’s Medimat Robotic Dispensing System (“RDS”) product line, partially offset by reversals of previously recognized expenses in subsequent periods. These charges consisted primarily of inventory write-down, severance and other related expenses. These expenses are unrelated to our ongoing operations and we believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of peer companies.

[0000926326-26-000003:8k_2_02:53]
g)Legal and regulatory expenses. We excluded from our non-GAAP results certain non-recurring legal and regulatory expenses, representing settlement amounts, related to certain claims of non-compliance with our government contracts that are outside of the ordinary course of our business. We believe that excluding these amounts provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of peer companies.

[0000926326-26-000003:8k_2_02:54]
h)Management severance costs. We excluded from our non-GAAP results the severance expense of certain senior management associated with the restructuring of our senior leadership team. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of peer companies.

[0000926326-26-000003:8k_2_02:55]
i)Executives transition costs. We excluded from our non-GAAP results the transition costs associated with the departure of a certain executive officer, primarily consisting of severance expenses. These expenses are unrelated to our ongoing operations and we do not expect them to occur in the ordinary course of business. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of peer companies.

[0000926326-26-000003:8k_2_02:56]
j)Gain on extinguishment of convertible senior notes, net. We excluded from our non-GAAP results the gain on the partial repurchase of the Company’s Convertible Senior Notes due 2025 as well as the related unwinding of the convertible note hedge and warrants. We believe that excluding this gain provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of peer companies.

[0000926326-26-000003:8k_2_02:57]
Management adjusts for the above items because management believes that, in general, these items possess one or more of the following characteristics: their magnitude and timing is largely outside of Omnicell’s control; they are unrelated to the ongoing operation of the business in the ordinary course; they are unusual and we do not expect them to occur in the ordinary course of business; or they are non-operational or non-cash expenses involving stock compensation plans or other items.

[0000926326-26-000003:8k_2_02:58]
We believe that the presentation of non-GAAP product gross profit, non-GAAP product gross margin, non-GAAP service gross profit, non-GAAP service gross margin, non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP operating margin, non-GAAP net income, non-GAAP net income per diluted share, non-GAAP EBITDA, and non-GAAP EBITDA margin is warranted for several reasons:

[0000926326-26-000003:8k_2_02:59]
a)Such non-GAAP financial measures provide an additional analytical tool for understanding Omnicell’s financial performance by excluding the impact of items which may obscure trends in the core operating results of the business.

[0000926326-26-000003:8k_2_02:60]
b)Since we have historically reported non-GAAP results to the investment community, we believe the inclusion of non-GAAP numbers provides consistency and enhances investors’ ability to compare our performance across financial reporting periods.

[0000926326-26-000003:8k_2_02:61]
c)These non-GAAP financial measures are employed by management in its own evaluation of performance and are utilized in financial and operational decision-making processes, such as budget planning and forecasting.

[0000926326-26-000003:8k_2_02:62]
d)These non-GAAP financial measures facilitate comparisons to the operating results of other companies in our industry, which also use non-GAAP financial measures to supplement their GAAP results (although these companies may calculate non-GAAP financial measures differently than Omnicell does), thus enhancing the perspective of investors who wish to utilize such comparisons in their analysis of our performance.

[0000926326-26-000003:8k_2_02:63]
Set forth below are additional reasons why share-based compensation expense is excluded from our non-GAAP financial measures:

[0000926326-26-000003:8k_2_02:64]
i)While share-based compensation calculated in accordance with Accounting Standards Codification (“ASC”) 718 constitutes an ongoing and recurring expense of Omnicell, it is not an expense that requires cash settlement by Omnicell. We therefore exclude these charges for purposes of evaluating core operating results. Thus, our non-GAAP measurements

[0000926326-26-000003:8k_2_02:65]
are presented exclusive of share-based compensation expense to assist management and investors in evaluating our core operating results.

[0000926326-26-000003:8k_2_02:66]
ii)We present ASC 718 share-based payment compensation expense in our reconciliation of non-GAAP financial measures on a pre-tax basis because the exact tax differences related to the timing and deductibility of share-based compensation under ASC 718 are dependent upon the trading price of Omnicell’s common stock and the timing and exercise by employees of their stock options. As a result of these timing and market uncertainties, the tax effect related to share-based compensation expense would be inconsistent in amount and frequency and is therefore excluded from our non-GAAP results.

[0000926326-26-000003:8k_2_02:67]
Non-GAAP diluted shares is defined as our GAAP diluted shares, excluding the impact of dilutive convertible senior notes for which the Company is economically hedged through its anti-dilutive convertible note hedge transaction. Additionally, in a period of net loss, GAAP diluted shares are further adjusted for certain shares whose effect would be dilutive in a period of net income. We believe non-GAAP diluted shares is a useful non-GAAP metric because it provides insight into the offsetting economic effect of the hedge transaction against potential conversion of the convertible senior notes.

[0000926326-26-000003:8k_2_02:68]
Non-GAAP free cash flow is defined as net cash provided by operating activities less cash used for software development for external use and purchases of property and equipment. We believe free cash flow is important to enable investors to better understand and evaluate our ongoing operating results and allows for greater transparency in the review and understanding of our overall financial, operational, and economic performance, because free cash flow takes into account certain capital expenditures and cash used for software development necessary to operate our business.

[0000926326-26-000003:8k_2_02:69]
As stated above, we present non-GAAP financial measures because we consider them to be important supplemental measures of performance. However, non-GAAP financial measures have limitations as an analytical tool and should not be considered in isolation or as a substitute for Omnicell’s GAAP results. In the future, we expect to incur expenses similar to certain of the non-GAAP adjustments described above and expect to continue reporting non-GAAP financial measures excluding such items. Some of the limitations in relying on non-GAAP financial measures are:

[0000926326-26-000003:8k_2_02:70]
a)Omnicell’s equity incentive plans and stock purchase plans are important components of incentive compensation arrangements and will be reflected as expenses in Omnicell’s GAAP results for the foreseeable future under ASC 718.

[0000926326-26-000003:8k_2_02:71]
b)Other companies, including companies in Omnicell’s industry, may calculate non-GAAP financial measures differently than Omnicell, limiting their usefulness as a comparative measure.

[0000926326-26-000003:8k_2_02:72]
c)A limitation of the utility of free cash flow as a measure of financial performance is that it does not represent the total increase or decrease in Omnicell’s cash balance for the period.

[0000926326-26-000003:8k_2_02:73]
A detailed reconciliation between Omnicell’s non-GAAP and GAAP financial results is set forth in the financial tables at the end of this press release. Investors are advised to carefully review and consider this information strictly as a supplement to the GAAP results that are contained in this press release as well as in Omnicell’s other reports filed with or furnished to the SEC.

[0000926326-26-000003:8k_2_02:74]
Omnicell, Inc.

[0000926326-26-000003:8k_2_02:75]
Condensed Consolidated Statements of Operations

[0000926326-26-000003:8k_2_02:76]
(Unaudited, in thousands, except per share data)

[0000926326-26-000003:8k_2_02:77]
|  | Three Months Ended December 31, |  | Year Ended December 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Revenues: |  |  |  |  |  |  |  |
| Product revenues | $ | 179,859 |  |  | $ | 182,271 |  |  | $ | 665,697 |  |  | $ | 630,507 |  |
| Service revenues | 134,125 |  |  | 124,608 |  |  | 519,148 |  |  | 481,731 |  |
| Total revenues | 313,984 |  |  | 306,879 |  |  | 1,184,845 |  |  | 1,112,238 |  |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | 104,917 |  |  | 96,755 |  |  | 379,162 |  |  | 383,025 |  |
| Cost of service revenues | 78,742 |  |  | 68,363 |  |  | 302,241 |  |  | 258,210 |  |
| Total cost of revenues | 183,659 |  |  | 165,118 |  |  | 681,403 |  |  | 641,235 |  |
| Gross profit | 130,325 |  |  | 141,761 |  |  | 503,442 |  |  | 471,003 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 22,552 |  |  | 26,040 |  |  | 88,672 |  |  | 90,412 |  |
| Selling, general, and administrative | 107,358 |  |  | 103,325 |  |  | 409,610 |  |  | 380,254 |  |
| Total operating expenses | 129,910 |  |  | 129,365 |  |  | 498,282 |  |  | 470,666 |  |
| Income from operations | 415 |  |  | 12,396 |  |  | 5,160 |  |  | 337 |  |
| Interest and other income (expense), net | 284 |  |  | 11,204 |  |  | 6,165 |  |  | 25,256 |  |
| Income before income taxes | 699 |  |  | 23,600 |  |  | 11,325 |  |  | 25,593 |  |
| Provision for income taxes | 2,725 |  |  | 7,758 |  |  | 9,273 |  |  | 13,062 |  |
| Net income (loss) | $ | (2,026) |  |  | $ | 15,842 |  |  | $ | 2,052 |  |  | $ | 12,531 |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |
| Basic | $ | (0.05) |  |  | $ | 0.34 |  |  | $ | 0.04 |  |  | $ | 0.27 |  |
| Diluted | $ | (0.05) |  |  | $ | 0.34 |  |  | $ | 0.04 |  |  | $ | 0.27 |  |
| Weighted-average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 44,959 |  |  | 46,345 |  |  | 45,965 |  |  | 46,047 |  |
| Diluted | 44,959 |  |  | 46,854 |  |  | 46,362 |  |  | 46,255 |  |

[0000926326-26-000003:8k_2_02:78]
8

[0000926326-26-000003:8k_2_02:79]
Omnicell, Inc.

[0000926326-26-000003:8k_2_02:80]
Condensed Consolidated Balance Sheets

[0000926326-26-000003:8k_2_02:81]
(Unaudited, in thousands)

[0000926326-26-000003:8k_2_02:82]
|  | December 31, |
|  | 2025 |  | 2024 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 196,520 |  |  | $ | 369,201 |  |
| Accounts receivable and unbilled receivables, net | 216,858 |  |  | 256,398 |  |
| Inventories | 100,905 |  |  | 88,659 |  |
| Prepaid expenses | 33,709 |  |  | 25,942 |  |
| Other current assets | 132,077 |  |  | 75,293 |  |
| Total current assets | 680,069 |  |  | 815,493 |  |
| Property and equipment, net | 120,111 |  |  | 112,692 |  |
| Long-term investment in sales-type leases, net | 60,742 |  |  | 52,744 |  |
| Operating lease right-of-use assets | 24,366 |  |  | 25,607 |  |
| Goodwill | 737,946 |  |  | 734,727 |  |
| Intangible assets, net | 170,105 |  |  | 188,266 |  |
| Long-term deferred tax assets | 58,337 |  |  | 57,469 |  |
| Prepaid commissions | 52,840 |  |  | 54,656 |  |
| Other long-term assets | 70,204 |  |  | 79,306 |  |
| Total assets | $ | 1,974,720 |  |  | $ | 2,120,960 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 43,990 |  |  | $ | 51,782 |  |
| Accrued compensation | 57,172 |  |  | 60,307 |  |
| Accrued liabilities | 203,586 |  |  | 167,895 |  |
| Deferred revenues | 171,861 |  |  | 141,370 |  |
| Convertible senior notes, net | — |  |  | 174,324 |  |
| Total current liabilities | 476,609 |  |  | 595,678 |  |
| Long-term deferred revenues | 63,254 |  |  | 76,123 |  |
| Long-term deferred tax liabilities | 683 |  |  | 1,108 |  |
| Long-term operating lease liabilities | 24,794 |  |  | 31,123 |  |
| Other long-term liabilities | 9,970 |  |  | 7,218 |  |
| Convertible senior notes, net | 167,596 |  |  | 166,397 |  |
| Total liabilities | 742,906 |  |  | 877,647 |  |
| Total stockholders’ equity | 1,231,814 |  |  | 1,243,313 |  |
| Total liabilities and stockholders’ equity | $ | 1,974,720 |  |  | $ | 2,120,960 |  |

[0000926326-26-000003:8k_2_02:83]
Omnicell, Inc.

[0000926326-26-000003:8k_2_02:84]
Condensed Consolidated Statements of Cash Flows

[0000926326-26-000003:8k_2_02:85]
(Unaudited, in thousands)

[0000926326-26-000003:8k_2_02:86]
|  | Year Ended December 31, |
|  | 2025 |  | 2024 |
| Operating Activities |  |  |  |
| Net income | $ | 2,052 |  |  | $ | 12,531 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 78,795 |  |  | 82,232 |  |
| Loss on disposal of assets | 488 |  |  | 978 |  |
| Share-based compensation expense | 44,502 |  |  | 39,316 |  |
| Deferred income taxes | (1,293) |  |  | (14,855) |  |
| Amortization of operating lease right-of-use assets | 7,839 |  |  | 7,523 |  |
| Impairment of external-use software development costs | 599 |  |  | — |  |
| Inventory write-down | — |  |  | 5,393 |  |
| Amortization of debt issuance costs | 2,651 |  |  | 3,788 |  |
| Gain on extinguishment of convertible senior notes, net | — |  |  | (7,517) |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable and unbilled receivables | 41,424 |  |  | (5,002) |  |
| Inventories | (11,225) |  |  | 15,633 |  |
| Prepaid expenses | (7,767) |  |  | 24 |  |
| Other current assets | (774) |  |  | 9,337 |  |
| Investment in sales-type leases | (10,171) |  |  | (10,398) |  |
| Prepaid commissions | 1,816 |  |  | (2,242) |  |
| Other long-term assets | 4,087 |  |  | 2,161 |  |
| Accounts payable | (9,283) |  |  | 7,210 |  |
| Accrued compensation | (4,009) |  |  | 8,553 |  |
| Accrued liabilities | (18,957) |  |  | 13,942 |  |
| Deferred revenues | 16,379 |  |  | 28,952 |  |
| Operating lease liabilities | (11,725) |  |  | (10,737) |  |
| Other long-term liabilities | 1,872 |  |  | 900 |  |
| Net cash provided by operating activities | 127,300 |  |  | 187,722 |  |
| Investing Activities |  |  |  |
| Asset acquisition | (2,430) |  |  | — |  |
| External-use software development costs | (17,518) |  |  | (16,330) |  |
| Purchases of property and equipment | (40,415) |  |  | (36,463) |  |
| Net cash used in investing activities | (60,363) |  |  | (52,793) |  |
| Financing Activities |  |  |  |
| Repayment of convertible senior notes due 2025 | (175,000) |  |  | — |  |
| Proceeds from issuance of convertible senior notes, net of issuance costs | — |  |  | 166,272 |  |
| Partial repurchase of convertible senior notes | — |  |  | (391,000) |  |
| Purchase of convertible note hedge | — |  |  | (40,279) |  |
| Proceeds from sale of warrants | — |  |  | 25,168 |  |
| Partial unwind of convertible note hedge and warrants | — |  |  | (727) |  |
| Proceeds from issuances under stock-based compensation plans | 16,868 |  |  | 13,411 |  |
| Employees’ taxes paid related to restricted stock units | (7,684) |  |  | (4,827) |  |
| Common stock repurchases | (77,600) |  |  | — |  |
| Change in customer funds, net | 25,099 |  |  | (3,596) |  |
| Net cash used in financing activities | (218,317) |  |  | (235,578) |  |
| Effect of exchange rate changes on cash and cash equivalents | 3,798 |  |  | (1,716) |  |
| Net decrease in cash, cash equivalents, and restricted cash | (147,582) |  |  | (102,365) |  |
| Cash, cash equivalents, and restricted cash at beginning of period | 398,614 |  |  | 500,979 |  |
| Cash, cash equivalents, and restricted cash at end of period | $ | 251,032 |  |  | $ | 398,614 |  |
| Reconciliation of cash, cash equivalents, and restricted cash to the Condensed Consolidated Balance Sheets: |
| Cash and cash equivalents | $ | 196,520 |  |  | $ | 369,201 |  |
| Restricted cash included in other current assets | 54,512 |  |  | 29,413 |  |
| Cash, cash equivalents, and restricted cash at end of period | $ | 251,032 |  |  | $ | 398,614 |  |

[0000926326-26-000003:8k_2_02:87]
10

[0000926326-26-000003:8k_2_02:88]
Omnicell, Inc.

[0000926326-26-000003:8k_2_02:89]
Reconciliation of GAAP to Non-GAAP

[0000926326-26-000003:8k_2_02:90]
(Unaudited, in thousands, except per share data and percentage)

[0000926326-26-000003:8k_2_02:91]
|  |  | Three Months Ended December 31, |  | Year Ended December 31, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Reconciliation of GAAP product gross profit to non-GAAP product gross profit: |  |  |  |  |  |  |  |
| GAAP product revenues | $ | 179,859 |  |  | $ | 182,271 |  |  | $ | 665,697 |  |  | $ | 630,507 |  |
| GAAP cost of product revenues | 104,917 |  |  | 96,755 |  |  | 379,162 |  |  | 383,025 |  |
| GAAP product gross profit | $ | 74,942 |  |  | $ | 85,516 |  |  | $ | 286,535 |  |  | $ | 247,482 |  |
| GAAP product gross margin | 41.7% |  | 46.9% |  | 43.0% |  | 39.3% |
|  | Share-based compensation expense | 410 |  |  | 932 |  |  | 2,131 |  |  | 4,096 |  |
|  | Amortization of acquired intangibles | 332 |  |  | 350 |  |  | 1,346 |  |  | 1,397 |  |
|  | RDS restructuring, net of reversals | 322 |  |  | 1,197 |  |  | 322 |  |  | 9,894 |  |
| Non-GAAP product gross profit | $ | 76,006 |  |  | $ | 87,995 |  |  | $ | 290,334 |  |  | $ | 262,869 |  |
| Non-GAAP product gross margin | 42.3% |  | 48.3% |  | 43.6% |  | 41.7% |
| Reconciliation of GAAP service gross profit to non-GAAP service gross profit: |  |  |  |  |  |  |
| GAAP service revenues | $ | 134,125 |  |  | $ | 124,608 |  |  | $ | 519,148 |  |  | $ | 481,731 |  |
| GAAP cost of service revenues | 78,742 |  |  | 68,363 |  |  | 302,241 |  |  | 258,210 |  |
| GAAP service gross profit | $ | 55,383 |  |  | $ | 56,245 |  |  | $ | 216,907 |  |  | $ | 223,521 |  |
| GAAP service gross margin | 41.3% |  | 45.1% |  | 41.8% |  | 46.4% |
|  | Share-based compensation expense | 565 |  |  | 557 |  |  | 2,765 |  |  | 2,277 |  |
|  | Amortization of acquired intangibles | 379 |  |  | 667 |  |  | 2,345 |  |  | 2,734 |  |
|  | EnlivenHealth restructuring | — |  |  | — |  |  | 892 |  |  | — |  |
|  | RDS restructuring, net of reversals | 3,386 |  |  | 14 |  |  | 3,386 |  |  | 3 |  |
| Non-GAAP service gross profit | $ | 59,713 |  |  | $ | 57,483 |  |  | $ | 226,295 |  |  | $ | 228,535 |  |
| Non-GAAP service gross margin | 44.5% |  | 46.1% |  | 43.6% |  | 47.4% |
| Reconciliation of GAAP gross profit to non-GAAP gross profit: |  |  |  |  |  |  |  |
| GAAP gross profit | $ | 130,325 |  |  | $ | 141,761 |  |  | $ | 503,442 |  |  | $ | 471,003 |  |
| GAAP gross margin | 41.5% |  | 46.2% |  | 42.5% |  | 42.3% |
|  | Share-based compensation expense | 975 |  |  | 1,489 |  |  | 4,896 |  |  | 6,373 |  |
|  | Amortization of acquired intangibles | 711 |  |  | 1,017 |  |  | 3,691 |  |  | 4,131 |  |
|  | EnlivenHealth restructuring | — |  |  | — |  |  | 892 |  |  | — |  |
|  | RDS restructuring, net of reversals | 3,708 |  |  | 1,211 |  |  | 3,708 |  |  | 9,897 |  |
| Non-GAAP gross profit | $ | 135,719 |  |  | $ | 145,478 |  |  | $ | 516,629 |  |  | $ | 491,404 |  |
| Non-GAAP gross margin | 43.2% |  | 47.4% |  | 43.6% |  | 44.2% |

[0000926326-26-000003:8k_2_02:92]
Omnicell, Inc.

[0000926326-26-000003:8k_2_02:93]
Reconciliation of GAAP to Non-GAAP

[0000926326-26-000003:8k_2_02:94]
(Unaudited, in thousands, except per share data and percentage)

[0000926326-26-000003:8k_2_02:95]
|  |  | Three Months Ended December 31, |  | Year Ended December 31, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Reconciliation of GAAP operating expenses to non-GAAP operating expenses: |  |  |  |  |
| GAAP operating expenses | $ | 129,910 |  |  | $ | 129,365 |  |  | $ | 498,282 |  |  | $ | 470,666 |  |
| GAAP operating expenses % to total revenues | 41.4% |  | 42.2% |  | 42.1% |  | 42.3% |
|  | Share-based compensation expense | (11,001) |  |  | (7,550) |  |  | (39,606) |  |  | (32,943) |  |
|  | Amortization of acquired intangibles | (4,522) |  |  | (4,480) |  |  | (17,805) |  |  | (18,578) |  |
|  | Acquisition-related expenses | (182) |  |  | (182) |  |  | (728) |  |  | (898) |  |
|  | EnlivenHealth restructuring | — |  |  | — |  |  | (1,674) |  |  | — |  |
|  | RDS restructuring, net of reversals | (231) |  |  | (1,223) |  |  | (231) |  |  | (2,056) |  |
|  | Legal and regulatory expenses | — |  |  | (2,000) |  |  | (2,700) |  |  | (2,000) |  |
|  | Management severance costs | (585) |  |  | (911) |  |  | (1,147) |  |  | (911) |  |
|  | Executives transition costs | — |  |  | — |  |  | (968) |  |  | — |  |
| Non-GAAP operating expenses | $ | 113,389 |  |  | $ | 113,019 |  |  | $ | 433,423 |  |  | $ | 413,280 |  |
| Non-GAAP operating expenses as a % of total revenues | 36.1% |  | 36.8% |  | 36.6% |  | 37.2% |
| Reconciliation of GAAP income from operations to non-GAAP income from operations: |
| GAAP income from operations | $ | 415 |  |  | $ | 12,396 |  |  | $ | 5,160 |  |  | $ | 337 |  |
| GAAP operating income % to total revenues | 0.1% |  | 4.0% |  | 0.4% |  | 0.0% |
|  | Share-based compensation expense | 11,976 |  |  | 9,039 |  |  | 44,502 |  |  | 39,316 |  |
|  | Amortization of acquired intangibles | 5,233 |  |  | 5,497 |  |  | 21,496 |  |  | 22,709 |  |
|  | Acquisition-related expenses | 182 |  |  | 182 |  |  | 728 |  |  | 898 |  |
|  | EnlivenHealth restructuring | — |  |  | — |  |  | 2,566 |  |  | — |  |
|  | RDS restructuring, net of reversals | 3,939 |  |  | 2,434 |  |  | 3,939 |  |  | 11,953 |  |
|  | Legal and regulatory expenses | — |  |  | 2,000 |  |  | 2,700 |  |  | 2,000 |  |
|  | Management severance costs | 585 |  |  | 911 |  |  | 1,147 |  |  | 911 |  |
|  | Executives transition costs | — |  |  | — |  |  | 968 |  |  | — |  |
| Non-GAAP income from operations | $ | 22,330 |  |  | $ | 32,459 |  |  | $ | 83,206 |  |  | $ | 78,124 |  |
| Non-GAAP operating margin (non-GAAP operating income as a % of total revenues) | 7.1% |  | 10.6% |  | 7.0% |  | 7.0% |
| Reconciliation of GAAP net income (loss) to non-GAAP net income: |  |  |  |  |  |
| GAAP net income (loss) | $ | (2,026) |  |  | $ | 15,842 |  |  | $ | 2,052 |  |  | $ | 12,531 |  |
|  | Share-based compensation expense | 11,976 |  |  | 9,039 |  |  | 44,502 |  |  | 39,316 |  |
|  | Amortization of acquired intangibles | 5,233 |  |  | 5,497 |  |  | 21,496 |  |  | 22,709 |  |
|  | Acquisition-related expenses | 182 |  |  | 182 |  |  | 728 |  |  | 898 |  |
|  | EnlivenHealth restructuring | — |  |  | — |  |  | 2,566 |  |  | — |  |
|  | RDS restructuring, net of reversals | 3,939 |  |  | 2,434 |  |  | 3,939 |  |  | 11,953 |  |
|  | Legal and regulatory expenses | — |  |  | 2,000 |  |  | 2,700 |  |  | 2,000 |  |
|  | Management severance costs | 585 |  |  | 911 |  |  | 1,147 |  |  | 911 |  |
|  | Executives transition costs | — |  |  | — |  |  | 968 |  |  | — |  |
|  | Amortization of debt issuance costs | 496 |  |  | 871 |  |  | 2,651 |  |  | 3,788 |  |
|  | Gain on extinguishment of convertible senior notes, net | — |  |  | (7,517) |  |  | — |  |  | (7,517) |  |
|  | Tax effect of the adjustments above (a) | (2,191) |  |  | (919) |  |  | (7,601) |  |  | (7,295) |  |
| Non-GAAP net income | $ | 18,194 |  |  | $ | 28,340 |  |  | $ | 75,148 |  |  | $ | 79,294 |  |

[0000926326-26-000003:8k_2_02:96]
12

[0000926326-26-000003:8k_2_02:97]
Omnicell, Inc.

[0000926326-26-000003:8k_2_02:98]
Reconciliation of GAAP to Non-GAAP

[0000926326-26-000003:8k_2_02:99]
(Unaudited, in thousands, except per share data and percentage)

[0000926326-26-000003:8k_2_02:100]
|  |  | Three Months Ended December 31, |  | Year Ended December 31, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Reconciliation of GAAP net income (loss) per share - diluted to non-GAAP net income per share - diluted: |  |  |
| Shares - diluted GAAP | 44,959 |  |  | 46,854 |  |  | 46,362 |  |  | 46,255 |  |
| Shares - diluted non-GAAP | 45,486 |  |  | 46,854 |  |  | 46,362 |  |  | 46,255 |  |
| GAAP net income (loss) per share - diluted | $ | (0.05) |  |  | $ | 0.34 |  |  | $ | 0.04 |  |  | $ | 0.27 |  |
|  | Share-based compensation expense | 0.27 |  |  | 0.19 |  |  | 0.96 |  |  | 0.85 |  |
|  | Amortization of acquired intangibles | 0.12 |  |  | 0.12 |  |  | 0.46 |  |  | 0.49 |  |
|  | Acquisition-related expenses | 0.00 |  |  | 0.00 |  |  | 0.02 |  |  | 0.02 |  |
|  | EnlivenHealth restructuring | — |  |  | — |  |  | 0.06 |  |  | — |  |
|  | RDS restructuring, net of reversals | 0.09 |  |  | 0.05 |  |  | 0.08 |  |  | 0.26 |  |
|  | Legal and regulatory expenses | — |  |  | 0.04 |  |  | 0.06 |  |  | 0.04 |  |
|  | Management severance costs | 0.01 |  |  | 0.02 |  |  | 0.02 |  |  | 0.02 |  |
|  | Executives transition costs | — |  |  | — |  |  | 0.02 |  |  | — |  |
|  | Amortization of debt issuance costs | 0.01 |  |  | 0.02 |  |  | 0.06 |  |  | 0.08 |  |
|  | Gain on extinguishment of convertible senior notes, net | — |  |  | (0.16) |  |  | — |  |  | (0.16) |  |
|  | Tax effect of the adjustments above (a) | (0.05) |  |  | (0.02) |  |  | (0.16) |  |  | (0.16) |  |
| Non-GAAP net income per share - diluted | $ | 0.40 |  |  | $ | 0.60 |  |  | $ | 1.62 |  |  | $ | 1.71 |  |
| Reconciliation of GAAP net income (loss) to non-GAAP EBITDA (b): |  |  |  |  |  |
| GAAP net income (loss) | $ | (2,026) |  |  | $ | 15,842 |  |  | $ | 2,052 |  |  | $ | 12,531 |  |
|  | Share-based compensation expense | 11,976 |  |  | 9,039 |  |  | 44,502 |  |  | 39,316 |  |
|  | Interest (income) and expense, net | (894) |  |  | (5,062) |  |  | (9,427) |  |  | (23,399) |  |
|  | Depreciation and amortization expense | 19,811 |  |  | 19,966 |  |  | 78,795 |  |  | 82,232 |  |
|  | Acquisition-related expenses | 182 |  |  | 182 |  |  | 728 |  |  | 898 |  |
|  | EnlivenHealth restructuring | — |  |  | — |  |  | 2,566 |  |  | — |  |
|  | RDS restructuring, net of reversals | 3,939 |  |  | 2,434 |  |  | 3,939 |  |  | 11,953 |  |
|  | Legal and regulatory expenses | — |  |  | 2,000 |  |  | 2,700 |  |  | 2,000 |  |
|  | Management severance costs | 585 |  |  | 911 |  |  | 1,147 |  |  | 911 |  |
|  | Executives transition costs | — |  |  | — |  |  | 968 |  |  | — |  |
|  | Amortization of debt issuance costs | 496 |  |  | 871 |  |  | 2,651 |  |  | 3,788 |  |
|  | Gain on extinguishment of convertible senior notes, net | — |  |  | (7,517) |  |  | — |  |  | (7,517) |  |
|  | Provision for income taxes | 2,725 |  |  | 7,758 |  |  | 9,273 |  |  | 13,062 |  |
| Non-GAAP EBITDA | $ | 36,794 |  |  | $ | 46,424 |  |  | $ | 139,894 |  |  | $ | 135,775 |  |
| Non-GAAP EBITDA margin (non-GAAP EBITDA as a % of total revenues) | 11.7% |  | 15.1% |  | 11.8% |  | 12.2% |

[0000926326-26-000003:8k_2_02:101]
_________________________________________________

[0000926326-26-000003:8k_2_02:102]
(a)Tax effects calculated for all adjustments except share-based compensation expense, using an estimated annual effective tax rate of 21% for both fiscal years 2025 and 2024.

[0000926326-26-000003:8k_2_02:103]
(b)Defined as earnings before interest income and expense, taxes, depreciation, amortization, and share-based compensation, as well as excluding certain other non-GAAP adjustments.

[0000926326-26-000003:8k_2_02:104]
Omnicell, Inc.

[0000926326-26-000003:8k_2_02:105]
Reconciliation of GAAP to Non-GAAP

[0000926326-26-000003:8k_2_02:106]
(Unaudited, in thousands)

[0000926326-26-000003:8k_2_02:107]
|  |  | Three Months Ended December 31, |  | Year Ended December 31, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Reconciliation of GAAP net cash provided by operating activities to non-GAAP free cash flow: |  |
| GAAP net cash provided by operating activities | $ | 30,354 |  |  | $ | 56,315 |  |  | $ | 127,300 |  |  | $ | 187,722 |  |
|  | External-use software development costs | (4,281) |  |  | (4,481) |  |  | (17,518) |  |  | (16,330) |  |
|  | Purchases of property and equipment | (7,709) |  |  | (9,087) |  |  | (40,415) |  |  | (36,463) |  |
| Non-GAAP free cash flow | $ | 18,364 |  |  | $ | 42,747 |  |  | $ | 69,367 |  |  | $ | 134,929 |  |

[0000926326-26-000003:8k_2_02:108]
14
