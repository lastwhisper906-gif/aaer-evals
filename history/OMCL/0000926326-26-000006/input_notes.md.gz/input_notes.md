# OMCL notes — 0000926326-26-000006


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000926326-26-000006:notes:1]
Portions of the registrant’s definitive Proxy Statement for the 2026 Annual Meeting of Stockholders to be filed with the United States Securities and Exchange Commission pursuant to Regulation 14A not later than 120 days after the end of the fiscal year covered by this Form 10-K are incorporated by reference in Part III, Items 10-14 of this Form 10-K.


## cyd:CybersecurityRiskManagementPositionsOrCommitteesResponsibleTextBlock

[0000926326-26-000006:notes:2]
As part of its risk oversight function, the Audit Committee of the Company’s Board of Directors is primarily responsible for overseeing and reviewing the Company’s information security and technology risks, including cybersecurity. In this role, the Audit Committee monitors the prevention, detection, mitigation and remediation of cybersecurity incidents through the regular receipt of reports from management on the effectiveness of its cybersecurity programs. These reports include quarterly cybersecurity updates from the Company’s Chief Information Security Officer and quarterly reports from the Company’s risk management personnel on the progress of the Company’s broader Enterprise Risk Management (“ERM”) risk mitigation activities. As part of the ERM process, the Audit Committee provides input on key risks for the Company to consider. The Board also provides quarterly input on its views regarding potential emerging risk areas for the Company. The Audit Committee then reports to the full Board on a quarterly basis regarding its oversight activities and the risk management activities of the Company. In addition, the full Board receives semiannual updates from the Chief Information Security Officer and periodically participates in cybersecurity-related tabletop exercises and receives incident reports from the SIRT (as defined herein) as significant matters may arise.

[0000926326-26-000006:notes:3]
The Company’s cybersecurity strategy and implementation is overseen by a dedicated Chief Information Security Officer with over 20 years of experience in the field, having most recently served as Senior Vice President and Global Chief Information Security Officer, with a leading diversified healthcare services company where he led enterprise-wide cybersecurity strategy and governance. He holds a Bachelor of Science from the University of Illinois Urbana-Champaign and an MBA from Northwestern University’s Kellogg School of Management.


## cyd:CybersecurityRiskManagementProcessesForAssessingIdentifyingAndManagingThreatsTextBlock

[0000926326-26-000006:notes:4]
Enterprise Risk Management

[0000926326-26-000006:notes:5]
The Company utilizes a structured, biennial ERM process to identify, assess, and address material risks facing the Company, including cybersecurity risks, during which business leaders across the Company are surveyed about current and emerging risk areas. After the ERM survey is completed and risk areas are identified, the results are discussed with the relevant management personnel across the organization in the key risk areas, root causes are analyzed, risk mitigation plans are developed, and key risk indicators are utilized to monitor mitigation efforts. The Chief Information Security Officer works closely with the Company’s management team in all facets of its ERM risk mitigation activities related to cybersecurity and information security risks.

[0000926326-26-000006:notes:6]
Ongoing Mitigation Efforts

[0000926326-26-000006:notes:7]
The Company has implemented a number of security measures designed to protect its systems and data, including firewalls, antivirus and malware detection tools, patches, log monitors, routine back-ups, system audits, system hardening, penetration testing and privileged access session management. In addition, the Company has continued its efforts to migrate its platforms to cloud-based computing, which is designed to further strengthen its security posture. The Company has continued to focus on maturing its incident response procedures and has retained a leading cybersecurity forensic firm. The Company also continues to strive to enhance its disaster recovery procedures. The Company’s solutions incorporate cybersecurity features that are routinely analyzed. In addition, the Company maintains insurance that responds to cyber-attacks, which coverage limit and cost is discussed and reviewed with the Audit Committee annually.

[0000926326-26-000006:notes:8]
The Company has what it believes are appropriate physical, technical, and administrative controls in place that are designed to protect customers’ data. The Company uses a three-pronged approach focused on further reducing exposure, raising greater security awareness, and further strengthening the Company’s cybersecurity defenses. This approach resulted in the Company further hardening its identity computing environments as part of its progress to a zero trust environment, heightened cybersecurity awareness efforts through increased comprehensive information security awareness training for employees on a quarterly basis, and the strengthening of the Company’s cybersecurity defenses through implementation of multifactor authentication for Privileged Access Management and Endpoint Detection and Response solutions across the Company’s computing environment.

[0000926326-26-000006:notes:9]
Previous cybersecurity incidents have not materially affected us, including our business strategy, results of operations or financial condition. However, risks from cybersecurity threats, including but not limited to exploitation of vulnerabilities, ransomware, denial of service, supply chain attacks, or other similar threats may materially affect us, including our execution of business strategy, reputation, results of operations and/or financial condition. See ITEM 1A. “Risk Factors - “We are subject to laws, regulations, and other legal obligations related to privacy, data protection, and information security, and the costs of compliance with, and potential liability associated with, our actual or perceived failure to comply with such obligations could

[0000926326-26-000006:notes:10]
harm our business” and “Significant disruptions in our information technology systems, breaches of data security, or cyber-attacks on our systems or solutions, could adversely impact our business” for a discussion of cybersecurity risks.

[0000926326-26-000006:notes:11]
Incident Response

[0000926326-26-000006:notes:12]
In the event of a cybersecurity incident, dependent upon the nature of the incident, the Company has a Security Incident Response Team (“SIRT”) that is comprised of employees who have responsibility and authority to act during a cyber incident without delay, including, dependent upon the nature of the incident, the Company’s Chief Legal and Administrative Officer or Chief Information Security Officer. The SIRT includes individuals responsible for assessing, containing, and responding to incidents, as well as those responsible for assessing the business and legal impacts, reporting incidents as appropriate, communicating to internal and external stakeholders, and engaging with industry and government partners to coordinate information and resource sharing when needed. During a cybersecurity incident, as warranted, the SIRT keeps the Company’s senior leadership and Board apprised of the response to the incident, any material operational or business impacts, and any material internal or external communications regarding the incident. The SIRT will also seek the input of the Company’s senior leadership and Board, as needed, when addressing a cybersecurity incident. Upon resolution of a cybersecurity incident, generally, the Audit Committee will review the incident, the impact and the mitigation efforts and remediation actions the Company will implement. The Audit Committee then monitors the completion of the remediation actions and mitigation efforts.

[0000926326-26-000006:notes:13]
Cybersecurity Leader

[0000926326-26-000006:notes:14]
Third Parties

[0000926326-26-000006:notes:15]
The Company utilizes third-party service providers, such as cloud services, in connection with its operations, and its information security department implements a third-party risk assessment and review process in connection with those services to evaluate security posture and risk. The Company also engages third parties to assist in its cybersecurity management efforts, such as the leading cybersecurity forensic firm mentioned above and another provider to perform continuous monitoring and regular penetration testing of its information security systems and environment. The Company and its personnel also actively engage with a number of other key vendors, industry participants and intelligence and law enforcement communities as part of its information security and cybersecurity efforts.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000926326-26-000006:notes:16]
Organization and Summary of Significant Accounting Policies
Business

[0000926326-26-000006:notes:17]
Omnicell, Inc. was incorporated in California in 1992 under the name Omnicell Technologies, Inc. and reincorporated in Delaware in 2001 as Omnicell, Inc. The Company’s major products and related services are medication management solutions and adherence tools for healthcare systems and pharmacies, which are sold in its principal market, the healthcare industry. The Company’s market is primarily located in the United States. “Omnicell” or the “Company” refer to Omnicell, Inc. and its subsidiaries, collectively.

[0000926326-26-000006:notes:18]
Basis of Presentation

[0000926326-26-000006:notes:19]
The accompanying Consolidated Financial Statements have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) and include all adjustments necessary for the fair presentation of the Company’s consolidated financial position, results of operations, and cash flows for the periods presented.

[0000926326-26-000006:notes:20]
Principles of Consolidation

[0000926326-26-000006:notes:21]
The Consolidated Financial Statements include the accounts of the Company and its wholly-owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.

[0000926326-26-000006:notes:22]
Use of Estimates

[0000926326-26-000006:notes:23]
The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s Consolidated Financial Statements and accompanying Notes to Consolidated Financial Statements. These estimates are based on historical experience and various other assumptions that management believes to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. The Company’s critical accounting estimates are those that affect its financial statements materially and involve difficult, subjective, or complex judgments by management. Those estimates are revenue recognition, inventory valuation, and accounting for income taxes. As of December 31, 2025, the Company is not aware of any events or circumstances that would require an update to its estimates, judgments, or revisions to the carrying value of its assets or liabilities.

[0000926326-26-000006:notes:24]
Segment Reporting

[0000926326-26-000006:notes:25]
The Company manages its operations as a single segment for the purposes of assessing performance and making operating decisions. The Company’s Chief Operating Decision Maker (“CODM”) is its Chief Executive Officer. The CODM allocates resources and evaluates the performance of the Company at the consolidated level using the Company’s consolidated net income (loss). In addition, the CODM is provided with certain segment assets and liabilities, primarily those that impact liquidity, as well as certain significant expenses. All significant operating decisions are based upon an analysis of the Company as one operating segment, which is the same as its reporting segment. Refer to Note 2, Segment Information, for further information regarding the Company’s segment disclosures.

[0000926326-26-000006:notes:26]
Foreign Currency Translation and Remeasurement

[0000926326-26-000006:notes:27]
Most of the Company’s foreign subsidiaries use the local currency of their respective countries as their functional currency. The Company translates the assets and liabilities of such non-U.S. dollar functional currency subsidiaries into U.S. dollars using exchange rates in effect at the end of each period. Revenue and expenses for these subsidiaries are translated using rates that approximate those in effect during the period. Gains and losses from these translations are recorded as foreign currency translation adjustments and included in accumulated other comprehensive income (loss) in stockholders’ equity.

[0000926326-26-000006:notes:28]
Assets and liabilities denominated in a currency other than the functional currency are remeasured into the respective entity’s functional currency. Monetary assets and liabilities are remeasured at exchange rates in effect at the end of each period, and non-monetary assets and liabilities are remeasured at historical rates. Gains and losses from foreign currency remeasurement of monetary assets and liabilities are recorded in interest and other income (expense), net.

[0000926326-26-000006:notes:29]
Revenue Recognition

[0000926326-26-000006:notes:30]
The Company earns revenues from sales of its products and related services, which are sold in the healthcare industry, its principal market. The Company’s customer arrangements typically include one or more of the following revenue categories:

[0000926326-26-000006:notes:31]
Connected devices, software licenses, and other. Software-enabled connected devices and software licenses that manage and regulate the storage and dispensing of pharmaceuticals, consumables blister cards, and packaging equipment and other supplies. This revenue category is often sold through long-term, sole-source agreements. Solutions in this category include, but are not limited to, XT Series automated dispensing systems and products related to the Central Pharmacy Dispensing Service and IV Compounding Service.

[0000926326-26-000006:notes:32]
Consumables. Medication adherence packaging, labeling, and other one-time use packaging including multi-medication adherence packaging and single-dose blister cards, which are used by retail, community, and outpatient pharmacies, as well as by institutional pharmacies serving long-term care and other non-acute healthcare facilities, and are designed to improve patient engagement and adherence to prescriptions.

[0000926326-26-000006:notes:33]
Technical services. Post-installation technical support and other related services (support and maintenance), including phone and/or web support, on-site service, parts, and access to unspecified software updates and enhancements, if and when available. This revenue category is often supported by multi-year or annual contractual agreements.

[0000926326-26-000006:notes:34]
Software as a Service (“SaaS”) and Expert Services. Software and service solutions which are offered on a subscription basis with fees typically based either on transaction volume or a fee over a specified period of time. Solutions in this category include, but are not limited to, EnlivenHealth®, Specialty Pharmacy Services, 340B solutions, Inventory Optimization Service, other software solutions, and services related to the Central Pharmacy Dispensing Service and IV Compounding Service.

[0000926326-26-000006:notes:35]
The following table summarizes revenue recognition for each revenue category:

[0000926326-26-000006:notes:36]
| Revenue Category |  |  |  | Timing of Revenue Recognition |  | Income Statement Classification |
| Connected devices, software licenses, and other |  |  |  | Point in time, as transfer of control occurs, generally upon installation and acceptance by the customer |  | Product |
| Consumables |  |  |  | Point in time, as transfer of control occurs, generally upon shipment to, or receipt by, customer |  | Product |
| Technical services |  |  |  | Over time, as services are provided, typically ratably over the service term |  | Service |
| SaaS and Expert Services |  |  |  | Over time, as services are provided |  | Service |

[0000926326-26-000006:notes:37]
Prior to recognizing revenue, the Company identifies the contract, performance obligations, and transaction price, and allocates the transaction price to the performance obligations. All identified contracts meet the following required criteria:

[0000926326-26-000006:notes:38]
Parties to the contract have approved the contract (in writing, orally, or in accordance with other customary business practices) and are committed to perform their respective obligations. A majority of the Company’s contracts are evidenced by a non-cancelable written agreement. Contracts for consumable products are generally evidenced by an order placed via our online portal, phone, or a purchase order.

[0000926326-26-000006:notes:39]
Entity can identify each party’s rights regarding the goods or services to be transferred. Contract terms are documented within the written agreements. Where a written contract does not exist, such as for consumable products, the rights of each party are understood as following the Company’s standard business process and terms.

[0000926326-26-000006:notes:40]
The entity can identify the payment terms for the goods or services to be transferred. Payment terms are documented within the agreement and are generally net 30 to 60 days from shipment of tangible product or services performed for customers in the United States. Where a written contract does not exist, the Company’s standard payment terms are net 30 day terms.

[0000926326-26-000006:notes:41]
The contract has commercial substance (that is the risk, timing, or amount of the entity’s future cash flows is expected to change as a result of the contract). The Company’s agreements are an exchange of cash for a combination of products and services which result in changes in the amount of the Company’s future cash flows.

[0000926326-26-000006:notes:42]
It is probable the entity will collect the consideration to which it will be entitled in exchange for the goods or services that will be transferred to the customer. The Company performs a credit check for all significant customers or

[0000926326-26-000006:notes:43]
transactions and where collectability is not probable, payment in full or a substantial down payment prior to shipment is typically required to help ensure the full agreed upon contract price will be collected.

[0000926326-26-000006:notes:44]
Distinct goods or services are identified as performance obligations. A series of distinct goods or services that are substantially the same and that have the same pattern of transfer to the customer are considered a single performance obligation. Where a good or service is determined not to be distinct, the Company combines the good or service with other promised goods or services until a bundle of goods or services that is distinct is identified. To identify its performance obligations, the Company considers all products or services promised in the contract regardless of whether they are explicitly stated or are implied by customary business practices. When performance obligations are included in separate contracts, the Company considers an entire customer arrangement to determine if separate contracts should be considered combined for the purposes of revenue recognition. Many of the Company’s sales contain multiple performance obligations, with a combination of hardware systems, software products, support and maintenance, and professional services.

[0000926326-26-000006:notes:45]
The transaction price of a contract is determined based on the fixed consideration, net of an estimate for variable consideration such as various discounts or rebates provided to customers. As a result of the Company’s commercial selling practices, contract prices are generally fixed with minimal, if any, variable consideration.

[0000926326-26-000006:notes:46]
The transaction price is allocated to separate performance obligations proportionally based on the standalone selling price of each performance obligation. Standalone selling price is best evidenced by the price the Company charges for the good or service when selling it separately in similar circumstances to similar customers. Other than for the renewal of annual technical services contracts, the Company’s products and services are not generally sold separately. The Company uses an amount discounted from the list price as a best estimated standalone selling price.

[0000926326-26-000006:notes:47]
The Company recognizes revenue when the performance obligation has been satisfied by transferring a promised good or service to a customer. The good or service is transferred when or as the customer obtains control of the good or service. Determining when control transfers requires management to make judgments that affect the timing of revenues recognized. Generally, for products requiring a complex implementation, control passes when the product is installed and functionally ready for use. For all other products, control generally passes when product has been shipped and title has passed. For support and maintenance contracts and certain other services, including SaaS and Expert Services provided on a subscription basis, control passes to the customer over time, generally ratably over the service term. Time and material services transfer control to the customer at the time the services are provided.

[0000926326-26-000006:notes:48]
The portion of the transaction price allocated to the Company’s unsatisfied performance obligations for which invoicing has occurred is recorded as deferred revenues. Deferred revenues from product sales primarily relate to delivered and invoiced products, pending installation and acceptance. Deferred revenues from service contracts primarily relate to services that have been invoiced, but services have not yet been provided. Short-term deferred revenues are expected to be recognized within the next twelve months. Long-term deferred revenues substantially consist of deferred revenues on long-term technical and SaaS and Expert Services contracts which have been invoiced and are expected to be recognized as revenue beyond twelve months, generally not more than ten years.

[0000926326-26-000006:notes:49]
In addition, the Company has remaining performance obligations associated with contracts for which the associated products have been accepted or associated services have started, but where invoicing has not yet occurred and therefore are not reflected in deferred revenue. These remaining performance obligations are comprised of the non-variable portions of technical services and SaaS and Expert Services provided under non-cancellable contracts with minimum commitments. Remaining performance obligations which are not included in deferred revenues were $388.0 million as of December 31, 2025. Remaining performance obligations are expected to be recognized ratably over the remaining terms of the associated contracts, which terms vary but are generally not more than ten years. Remaining performance obligations do not include product obligations, services where the associated product has not been accepted, services which have not yet started, variable portions of services, and certain other obligations.

[0000926326-26-000006:notes:50]
Revenues, contract assets, and contract liabilities are recorded net of associated taxes.

[0000926326-26-000006:notes:51]
The Company generally invoices customers for products upon shipment. Invoicing associated with the service portion of agreements is generally periodic and is billed on a monthly, quarterly, or annual basis, and in certain circumstances, multiple years are billed at one time. SaaS and Expert Services agreements are generally invoiced periodically on a monthly, quarterly or annual basis over the life of the agreement. In certain circumstances, portions of these agreements may be invoiced lump sum.

[0000926326-26-000006:notes:52]
The amount invoiced for equipment and software is typically reflected in both accounts receivable and deferred revenues. The Company typically recognizes product revenue, and correspondingly reduces deferred revenues, for equipment and on-premise software upon written customer acceptance of installation. Consumables are recorded as revenue upon shipment to or receipt by the customer, depending upon contract terms.

[0000926326-26-000006:notes:53]
From time to time, the Company enters into change orders which modify the product to be received by the customer pursuant to certain contracts. Changes to any contract are accounted for as a modification of the existing contract to the extent the goods and services to be delivered as part of the contract are generally consistent with the nature and type of those to be provided under the terms of the original contract. Examples of such change orders include the addition or removal of units of equipment or changes to the configuration of the equipment where the overall nature of the contract remains intact. The Company’s change orders generally result in the change being accounted for as modifications of existing contracts given the nature of the impacted orders.

[0000926326-26-000006:notes:54]
In the normal course of business, the Company typically does not accept product returns unless the item is defective as manufactured or the configuration of the product is incorrect. The Company establishes provisions for estimated returns based on historical product returns. The allowance for sales returns is not material to the Consolidated Financial Statements for any periods presented.

[0000926326-26-000006:notes:55]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”), each of which functions as a purchasing agent on behalf of member hospitals and other healthcare providers. The Company also has a Federal Supply Schedule Contract with the Department of Veterans Affairs (the “GSA Contract”), allowing the Department of Veterans Affairs, the Department of Defense, and other federal government customers to purchase the Company’s products. Pursuant to the terms of GPO agreements and the GSA Contract, each member or agency contracts directly with Omnicell and can purchase the Company’s products at pre-negotiated contract terms and pricing. GPOs are often fully or partially owned by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company also pays the Industrial Funding Fee (“IFF”) to the Department of Veterans Affairs under the GSA Contract. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs and the IFF were $8.8 million, $9.6 million, and $11.2 million for the years ended December 31, 2025, 2024, and 2023, respectively. The accounts receivable balances are with individual members of the GPOs and federal agencies that purchase under the GSA Contract, and therefore no significant concentration of credit risk exists. During the year ended December 31, 2025, sales to members of the ten largest GPOs and federal agencies that purchase under the GSA Contract collectively accounted for approximately 61% of the Company’s total consolidated revenues.

[0000926326-26-000006:notes:56]
Contract Assets and Contract Liabilities

[0000926326-26-000006:notes:57]
A contract asset is a right to consideration in exchange for goods or services that the Company has transferred to a customer when that right is conditioned on something other than the passage of time. A receivable will be recorded on the balance sheet when the Company has unconditional rights to consideration. A contract liability is an obligation to transfer goods or services for which the Company has received consideration, or for which an amount of consideration is due from the customer. Contract liabilities include customer deposits under non-cancelable contracts, and current and non-current deferred revenue balances. The Company’s contract balances are reported in a net contract asset or liability position on a contract-by-contract basis at the end of each reporting period.

[0000926326-26-000006:notes:58]
Significant changes in the contract assets and the contract liabilities balances during the period are the result of the issuance of invoices and recognition of deferred revenues in the normal course of business. The contract modifications entered into during the year ended December 31, 2025 did not have a significant impact on the Company’s contract assets or deferred revenues.

[0000926326-26-000006:notes:59]
Contract Costs

[0000926326-26-000006:notes:60]
The Company has determined that certain incentive portions of its sales commission plans require capitalization since these payments are directly related to sales achieved during a time period. These commissions are earned on the basis of: (i) the value of new bookings for connected devices, software products, and SaaS and Expert Services, provided that for SaaS and Expert Services a commission will only be paid on the amount that represents the minimum commitment and (ii) the value of new orders for consumables. Since there are no commensurate commissions earned on renewal of the service bookings, the Company concluded that the capitalized asset is related to services provided under both the initial contract and renewal periods.

[0000926326-26-000006:notes:61]
The Company applies a practical expedient to account for the incremental costs of obtaining a contract as part of a portfolio of contracts with similar characteristics as the Company expects the effect on the financial statements of applying the practical expedient would not differ materially from applying the accounting guidance to the individual contracts within the portfolio. A pool of contracts is defined as all contracts booked in a particular quarter. The amortization for the capitalized asset is an estimate of the pool’s original contract term, generally one to five years, plus an estimate of future customer renewal periods resulting in a total amortization period of ten years.

[0000926326-26-000006:notes:62]
Costs to obtain a contract are allocated amongst performance obligations and recognized as sales and marketing expense consistent with the pattern of revenue recognition. In accordance with GAAP, while certain compensation elements are expensed as incurred, a portion of the pool’s capitalized asset is recorded as an expense over the first seven quarters after booking, which represents the estimated period during which the product revenue associated with the contract is recorded. The remaining capitalized contract costs are recorded as expense ratably over the ten year estimated initial and renewal service periods. The Company recognized contract cost expense of $22.9 million, $19.1 million, and $23.3 million during the years ended December 31, 2025, 2024, and 2023, respectively. The commission expenses paid or due to be paid as of the consolidated balance sheet date, to be recognized in future periods, are recorded in long-term prepaid commissions on the Consolidated Balance Sheets. Capitalized costs are periodically reviewed for impairment. There was no impairment loss recorded related to capitalized prepaid commissions as of and for the year ended December 31, 2025.

[0000926326-26-000006:notes:63]
Lessor Leases

[0000926326-26-000006:notes:64]
The Company determines if an arrangement is or contains a lease at inception. The transaction price is allocated to separate performance obligations, generally consisting of a combination of hardware systems, software products, support and maintenance, and professional services, proportionally based on the standalone selling price of each performance obligation. Standalone selling price is best evidenced by the price the Company charges for the good or service when selling it separately in similar circumstances to similar customers. Other than for the renewal of annual technical services contracts, the Company’s products and services are not generally sold separately. The Company uses an amount discounted from the list price as a best estimated standalone selling price.

[0000926326-26-000006:notes:65]
Sales-Type Leases

[0000926326-26-000006:notes:66]
The Company enters into non-cancelable sales-type lease arrangements with the leases varying in length from one to ten years, most of which do not have an option to extend the lease term. At the end of the lease term, the customer must either return the equipment or negotiate a new agreement, resulting in a new purchase or lease transaction. Failure of the customer to either return the equipment or negotiate a new agreement results in the contract becoming a month-to-month rental. Certain sales-type leases automatically renew for successive one-year periods at the end of each lease term without written notice from the customer. The Company’s sales-type lease agreements do not contain any material residual value guarantees.

[0000926326-26-000006:notes:67]
For sales-type leases, the Company recognizes revenues for its hardware and software products, net of lease execution costs, post-installation support and maintenance, professional services associated with SaaS and Expert Services offerings, and technical support, at the net present value of the lease payment stream upon customer acceptance. The Company recognizes service revenues associated with sales-type leases ratably over the term of the agreement in service revenues in the Consolidated Statements of Operations. The Company recognizes interest income from sales-type leases using the effective interest method. Both hardware and software revenues, and interest income from sales-types leases are recorded in product revenues in the Consolidated Statements of Operations.

[0000926326-26-000006:notes:68]
The Company optimizes cash flows by selling a majority of its sales-type leases, other than those relating to U.S. government hospitals and SaaS and Expert Services products, including Central Pharmacy Dispensing Service and IV Compounding Service, to third-party leasing finance companies on a non-recourse basis. The Company generally has no obligation to the leasing company once the lease has been sold.

[0000926326-26-000006:notes:69]
Allowance for Credit Losses

[0000926326-26-000006:notes:70]
The Company is exposed to credit losses primarily through sales of its products and services, as well as its sales-type leasing arrangements. The Company performs credit evaluations of its customers’ financial condition in order to assess each customer’s ability to pay. These evaluations require significant judgment and are based on a variety of factors including, but not limited to, current economic trends, payment history, and a financial review of the customer. The Company continues to monitor customers’ creditworthiness on an ongoing basis.

[0000926326-26-000006:notes:71]
The Company maintains an allowance for credit losses for accounts receivable, unbilled receivables, and net investment in sales-type leases based on expected credit losses resulting from the inability of its customers to make required payments. The allowance for credit losses is measured using a loss rate method, considering factors such as customers’ credit risk, historical loss experience, current conditions, and forecasts. The allowance for credit losses is measured on a collective (pool) basis by aggregating customer balances with similar risk characteristics. The Company also records a specific allowance based on an analysis of individual past due balances or customer-specific information, such as a decline in creditworthiness or bankruptcy. Actual collection losses may differ from management’s estimates, and such differences could be material to the Company’s financial position and results of operations.

[0000926326-26-000006:notes:72]
The allowance for credit losses is presented in the Consolidated Balance Sheets as a deduction from the respective asset balance. As of December 31, 2025 and 2024, the allowance for credit losses for long-term unbilled receivables and net investment in sales-type leases were not material.

[0000926326-26-000006:notes:73]
Funds Held for Customers and Customer Fund Liabilities

[0000926326-26-000006:notes:74]
The Company offers certain products and services in which it is customary for insurance payors to submit funds to the Company which are collected on behalf of, and, after a short holding period, disbursed to, the Company’s customers. The Company presents amounts collected from insurance payors and amounts due to be disbursed to customers on a gross basis within other current assets and accrued liabilities, respectively, in the Consolidated Balance Sheets, as such amounts are expected to be settled within one year. Generally, any funds received from the pharmacies or insurance payors that are held by the Company are segregated from its other corporate cash accounts. These funds are classified as restricted cash as the Company is contractually obligated to disburse these amounts to customers.

[0000926326-26-000006:notes:75]
Sales of Accounts Receivable

[0000926326-26-000006:notes:76]
The Company records the sale of its accounts receivables in accordance with accounting guidance for transfers and servicing of financial assets. The Company transferred non-recourse accounts receivable totaling $15.0 million, $17.3 million, and $5.7 million during the years ended December 31, 2025, 2024, and 2023, respectively, which approximated fair value, to leasing companies on a non-recourse basis.

[0000926326-26-000006:notes:77]
Cash and Cash Equivalents

[0000926326-26-000006:notes:78]
The Company classifies all highly-liquid investments with original maturities of three months or less as cash equivalents. The Company’s cash and cash equivalent balances include bank accounts and highly-liquid U.S. Government money market funds held in sweep and asset management accounts with financial institutions of high credit quality. As of December 31, 2025, a substantial portion of the Company’s cash and cash equivalents were held with a limited number of financial institutions and money market funds, which may expose the Company to concentration risk in the event of a failure or adverse condition affecting those entities. The Company continuously monitors the credit worthiness of the financial institutions in which it invests. The Company has not experienced any credit losses from its cash equivalents. Cash and cash equivalents were $196.5 million and $369.2 million as of December 31, 2025 and 2024, respectively. As of December 31, 2025 and 2024, cash equivalents were $148.6 million and $328.0 million, respectively, which consisted of money market funds held in sweep and asset management accounts. The Company recorded interest income on its cash and cash equivalents of $11.9 million, $24.9 million, and $18.8 million for the years ended December 31, 2025, 2024, and 2023, respectively, which is included within interest and other income (expense), net in the Consolidated Statements of Operations.

[0000926326-26-000006:notes:79]
Financial Instruments

[0000926326-26-000006:notes:80]
For assets and liabilities measured at fair value, the amounts are based on an expected exit price representing the amount that would be received from the sale of an asset or paid to transfer a liability in a transaction between market participants. The fair value may be based on assumptions that market participants would use in pricing an asset or liability. ASC 820, Fair Value Measurement, establishes a consistent framework for measuring fair value on either a recurring or nonrecurring basis whereby inputs used in valuation techniques are assigned a hierarchical level, as follows:

[0000926326-26-000006:notes:81]
Level 1 – Observable inputs, such as quoted prices in active markets for identical instruments;

[0000926326-26-000006:notes:82]
Level 2 – Quoted prices for similar instruments in active markets, or quoted prices for identical instruments in inactive markets; and

[0000926326-26-000006:notes:83]
Level 3 – Unobservable inputs for financial instruments reflecting Company’s assumptions.

[0000926326-26-000006:notes:84]
Inventory

[0000926326-26-000006:notes:85]
Inventories are stated at the lower of cost, computed using the first-in, first-out method, and net realizable value. The Company regularly monitors inventory quantities on hand and records write-downs for excess and obsolete inventories based on the Company’s estimate of demand for its products, potential obsolescence of technology, product life cycles, and whether pricing trends or forecasts indicate that the carrying value of inventory exceeds its estimated selling price. These factors are impacted by market and economic conditions, technology changes, and new product introductions and require estimates that may include elements that are uncertain. Actual demand may differ from forecasted demand and may have a material effect on gross margins. If inventory is written down, a new cost basis is established that cannot be increased in future periods. Shipments from suppliers or contract manufacturers before the Company receives them are recorded as in-transit inventory when title and the significant risks and rewards of ownership have passed to the Company.

[0000926326-26-000006:notes:86]
The Company has a supply agreement with one primary supplier for construction and supply of several sub-assemblies and inventory management of sub-assemblies used in its hardware products. There are no minimum purchase requirements. The contract with the Company’s supplier may be terminated by either the supplier or by the Company without cause and at any time upon delivery of six months’ notice. Purchases from this supplier were $93.9 million, $59.1 million, and $65.8 million for the years ended December 31, 2025, 2024, and 2023, respectively.

[0000926326-26-000006:notes:87]
Shipping Costs

[0000926326-26-000006:notes:88]
Outbound freight billed to customers is recorded as product revenue. The related shipping and handling costs are expensed as part of selling, general, and administrative expense. Shipping and handling expenses were $18.0 million, $15.7 million, and $18.6 million for the years ended December 31, 2025, 2024, and 2023, respectively.

[0000926326-26-000006:notes:89]
Property and Equipment

[0000926326-26-000006:notes:90]
Property and equipment less accumulated depreciation are stated at historical cost. The Company’s expenditures for property and equipment are primarily for computer equipment and software used in the administration of its business, and for leasehold improvements to its leased facilities. The Company also develops molds and dies used in long-term manufacturing arrangements with suppliers and for production automation equipment used in the manufacturing of consumable blister card components.

[0000926326-26-000006:notes:91]
The Company capitalizes costs related to computer software developed or obtained for internal-use in accordance with ASC 350-40, Internal-Use Software. Software developed or obtained for internal-use includes certain costs for the development of the Company’s subscription and cloud-based offerings sold to its customers, as well as enterprise-level business and finance software that the Company customizes to meet its specific operational needs. Costs incurred in the application development phase are capitalized and amortized over their useful lives, which is generally five years. Costs incurred in the preliminary project phase and the post-implementation phase are expensed as incurred. During the years ended December 31, 2025 and 2024, the Company capitalized $28.3 million and $28.5 million, respectively, of costs related to the application development of enterprise-level software and its subscription and cloud-based offerings, which are included in property and equipment. Capitalized costs related to computer software developed or obtained for internal-use are included in purchases of property and equipment in the Consolidated Statements of Cash Flows.

[0000926326-26-000006:notes:92]
Depreciation and amortization is computed by use of the straight-line method over the estimated useful lives of the assets as stated below:

[0000926326-26-000006:notes:93]
| Purchased software and internal-use software development costs | 3 - 5 years |
| Leasehold and building improvements | Shorter of the lease term or the estimated useful life |
| Furniture and fixtures | 5 - 7 years |
| Equipment | 2 - 12 years |

[0000926326-26-000006:notes:94]
External-Use Software Development Costs

[0000926326-26-000006:notes:95]
The Company capitalizes certain software development costs in accordance with ASC 985-20, Costs of Software to Be Sold, Leased, or Marketed, under which those costs incurred subsequent to the establishment of technological feasibility may be capitalized and amortized over the estimated lives of the related products. The Company establishes technological feasibility when it completes a detail program design or a working model. The Company amortizes development costs over the estimated lives of the related products, which is generally five years. All development costs prior to the completion of a detail program design or a working model are recognized as research and development expense. The Company capitalized external-use software development costs of $18.1 million and $17.2 million that were included in other long-term assets as of December 31, 2025 and 2024, respectively.

[0000926326-26-000006:notes:96]
Cloud Computing Costs

[0000926326-26-000006:notes:97]
The Company capitalizes certain costs associated with cloud computing arrangements that are associated with service contracts, which are amortized using the straight-line method over the term of the arrangement. As of December 31, 2025 and 2024, capitalized costs associated with cloud computing arrangements, net of accumulated amortization, were $4.6 million and $5.0 million, respectively.

[0000926326-26-000006:notes:98]
Lessee Leases

[0000926326-26-000006:notes:99]
The Company determines if an arrangement is or contains a lease at inception. Operating lease right-of-use assets and liabilities are recognized at the commencement date based on the present value of lease payments over the lease term. As most of its lease contracts do not provide an implicit rate, the Company uses its incremental borrowing rate based on information available at the commencement date in determining the present value of the lease payments. Lease expense is recognized on a straight-line basis over the lease term. The Company does not recognize a right-of-use asset and a lease liability for leases with an initial term of twelve months or less. The Company elected the practical expedient to not separate lease components from nonlease components and applied that practical expedient to all material classes of leased assets.

[0000926326-26-000006:notes:100]
Many of the Company’s operating leases include an option to extend the lease. The specific terms and conditions of the extension options vary from lease to lease, but are consistent with standard industry practices in each area that the Company operates. The Company reviews each of its lease options at a time required by the terms of the lease contract, and notifies the lessor if it chooses to exercise the lease renewal option. Until the Company is reasonably certain that it will extend the lease contract, the renewal option periods will not be recognized as right-of-use assets or lease liabilities.

[0000926326-26-000006:notes:101]
Certain leases include provisions for early termination, which allow the contract parties to terminate their obligations under the lease contract. The terms and conditions of the termination options vary by contract. When the Company has made a decision to exercise an early termination option, the right-of-use assets and associated lease liabilities are remeasured in accordance with the present value of the remaining cash flows under the lease contract.

[0000926326-26-000006:notes:102]
Certain building lease agreements include rental payments subject to change annually based on fluctuations in various indexes (i.e., Consumer Price Index (“CPI”), Retail Price Index, and other international indexes). Certain data center lease agreements include rental payments subject to change based on usage and CPI fluctuations. The changes based on usage and indexes are treated as variable lease costs and recognized in the period in which the obligation for those payments was incurred.

[0000926326-26-000006:notes:103]
The Company’s operating lease agreements do not contain any material residual value guarantees, restrictions, or restriction covenants.

[0000926326-26-000006:notes:104]
Goodwill and Acquired Intangible Assets

[0000926326-26-000006:notes:105]
Goodwill

[0000926326-26-000006:notes:106]
The Company assesses goodwill for impairment on an annual basis on the first day of the fourth quarter of each year at the reporting unit level. This assessment is also performed whenever there is a change in circumstances that indicates the carrying value of goodwill may be impaired. The Company has one reporting unit, which is the same as its operating segment. A qualitative assessment is initially made to determine whether it is necessary to perform quantitative testing. A qualitative assessment includes, among others, consideration of: (i) past, current, and projected future earnings and equity; (ii) recent trends and market conditions; and (iii) valuation metrics involving similar companies that are publicly-traded and acquisitions of similar companies, if available. If this qualitative assessment indicates that it is more likely than not that impairment exists, or if the Company decides to bypass this option, it proceeds to the quantitative assessment. The quantitative assessment involves a comparison between the estimated fair value of the Company’s reporting unit with its carrying amount including goodwill. If the carrying value exceeds estimated fair value, the Company will record an impairment charge based on that difference. The impairment charge will be limited to the amount of goodwill.

[0000926326-26-000006:notes:107]
To determine the reporting unit’s fair value under the quantitative approach, the Company uses a combination of income and market approaches, such as estimated discounted future cash flows of the reporting unit, multiples of earnings or revenues, and analysis of recent sales or offerings of comparable entities. The Company also considers its market capitalization on the date of the analysis to ensure the reasonableness of its reporting unit’s fair value.

[0000926326-26-000006:notes:108]
The Company performed a qualitative impairment assessment analysis as of October 1, 2025 for its reporting unit taking into consideration past, current, and projected future earnings, recent trends and market conditions, and valuation metrics involving similar companies that are publicly-traded. Based on the result of this analysis, an impairment does not exist as of December 31, 2025, and there were no accumulated impairment losses.

[0000926326-26-000006:notes:109]
Intangible Assets

[0000926326-26-000006:notes:110]
In connection with its acquisitions, the Company generally recognizes assets for customer relationships, acquired technology, backlog, trade names, and non-compete agreements. Intangible assets are carried at cost less accumulated amortization. Such amortization is provided on a straight-line basis or on an accelerated basis based on a pattern of economic benefit that is expected to be obtained over the estimated useful lives of the respective assets. Amortization for acquired technology and backlog is recognized in cost of revenues, and amortization for customer relationships, trade names, non-compete agreements, and patents is recognized in selling, general, and administrative expenses.

[0000926326-26-000006:notes:111]
The Company assesses the impairment of identifiable intangible assets whenever events or changes in circumstances indicate that an asset’s carrying amount may not be recoverable. Recoverability of an asset is measured by the comparison of the carrying amount to the sum of the undiscounted estimated future cash flows the asset is expected to generate, offset by estimated future costs to dispose of the product to which the asset relates. If an asset is considered to be impaired, the amount of such impairment would be measured as the difference between the carrying amount of the asset and its fair value. The Company’s cash flow assumptions are based on historical and forecasted future revenue, operating costs, and other relevant factors. Assumptions and estimates about the remaining useful lives of the Company’s intangible assets are subjective and are affected by changes to its business strategies. If management’s estimates of future operating results change, or if there are changes to other assumptions, the estimate of the fair value of the Company’s assets could change significantly. Such change could result in impairment charges in future periods, which could have a significant impact on the Company’s operating results and financial condition. For the years ended December 31, 2025 and 2024, there were no events or changes in circumstances to indicate that intangible assets carrying amounts may not be recoverable.

[0000926326-26-000006:notes:112]
Convertible Debt

[0000926326-26-000006:notes:113]
The Company accounts for convertible debt and related transactions in accordance with ASC 470-20, Debt with Conversion and Other Options, ASC 815, Derivatives and Hedging, and ASC 480, Distinguishing Liabilities from Equity. The Company evaluates convertible debt instruments and related transactions at inception to determine if those contracts or embedded components of those contracts qualify as derivatives to be separately accounted for.

[0000926326-26-000006:notes:114]
The Company’s convertible senior notes are accounted for as a single liability at face value less unamortized debt issuance costs. Issuance costs are amortized using the effective interest method over the term of the convertible senior notes.

[0000926326-26-000006:notes:115]
Convertible note hedge and warrant transactions associated with convertible debt instruments are accounted for as equity instruments, and are recorded in additional paid-in capital in the Consolidated Balance Sheets.

[0000926326-26-000006:notes:116]
Valuation of Share-Based Compensation

[0000926326-26-000006:notes:117]
The Company accounts for share-based compensation in accordance with ASC 718, Stock Compensation. The Company recognizes compensation expense related to share-based compensation based on the grant date estimated fair value.

[0000926326-26-000006:notes:118]
The fair value of restricted stock units (“RSUs”) and restricted stock awards (“RSAs”) is based on the stock price on the grant date. The RSUs and RSAs are subject to a service vesting condition and are recognized on a straight-line basis over the requisite service period.

[0000926326-26-000006:notes:119]
The fair value of performance-based stock unit awards (“PSUs”) with service and market conditions is estimated using a Monte Carlo simulation model applying a multiple awards approach. Expense is recognized using the accelerated attribution method over the requisite service period.

[0000926326-26-000006:notes:120]
Forfeiture rates are estimated based on the Company’s historical experience with equity awards that were granted and forfeited prior to vesting. The valuation assumptions used in estimating the fair value of employee share-based awards may change in future periods.

[0000926326-26-000006:notes:121]
Accounting for Income Taxes

[0000926326-26-000006:notes:122]
The Company records an income tax provision for (benefit from) the anticipated tax consequences of the reported results of operations. In accordance with ASC 740, Income Taxes, the provision for (benefit from) income taxes is computed using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been included in the financial statements. Under this method, deferred tax assets and liabilities are determined on the basis of the differences between the financial statement and tax bases of assets and liabilities and for operating losses and tax credit carryforwards. Deferred tax assets and liabilities are measured using the enacted tax rates in effect for the periods in which those tax assets and liabilities are expected to be realized or settled. In the event that these tax rates change, the Company will incur a benefit or detriment on its income tax expense in the period of enactment. If the

[0000926326-26-000006:notes:123]
Company were to determine that all or part of the net deferred tax assets are not realizable in the future, it will record a valuation allowance that would be charged to earnings in the period such determination is made.

[0000926326-26-000006:notes:124]
In accordance with ASC 740, the Company recognizes the tax benefit from an uncertain tax position if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement. The calculation of tax liabilities involves significant judgment in estimating the impact of uncertainties in the application of ASC 740 and complex tax laws. Resolution of these uncertainties in a manner inconsistent with management’s expectations could have a material impact on the Company’s financial condition and operating results.

[0000926326-26-000006:notes:125]
Recently Adopted Authoritative Guidance

[0000926326-26-000006:notes:126]
In December 2023, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which includes amendments that further enhance income tax disclosures, primarily through standardization and disaggregation of rate reconciliation categories and income taxes paid by jurisdiction. The Company adopted ASU 2023-09 for the year ended December 31, 2025 on a prospective basis. Refer to Note 17, Income Taxes, for further information regarding the Company’s income tax disclosures.

[0000926326-26-000006:notes:127]
Recently Issued Authoritative Guidance

[0000926326-26-000006:notes:128]
In November 2024, the FASB issued ASU 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosure (Subtopic 220-40): Disaggregation of Income Statement Expenses, which requires disclosures of additional information and disaggregation of certain expenses included in the income statement. The amendments are effective for the Company’s annual periods beginning January 1, 2027, and for interim periods within fiscal years beginning January 1, 2028, with early adoption permitted, and should be applied either prospectively or retrospectively. The Company is currently evaluating the impact ASU 2024-03 will have on its consolidated financial statements.

[0000926326-26-000006:notes:129]
In September 2025, the FASB issued ASU 2025-06, Intangibles—Goodwill and Other—Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal Use Software, which removes all references to software development project stages, and requires capitalization of software costs to begin when (i) management has authorized and committed to funding the software project, and (ii) it is probable the project will be completed and the software will be used to perform its intended function. The amendments are effective for the Company’s annual periods beginning January 1, 2028, and for interim periods within fiscal years beginning January 1, 2028, with early adoption permitted, and can be applied prospectively, retrospectively, or utilizing a modified transition approach. The Company is currently evaluating the impact ASU 2025-06 will have on its consolidated financial statements.

[0000926326-26-000006:notes:130]
There was no other recently issued and effective authoritative guidance that is expected to have a material impact on the Company’s Consolidated Financial Statements through the reporting date.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0000926326-26-000006:notes:131]
The Company applies a practical expedient to account for the incremental costs of obtaining a contract as part of a portfolio of contracts with similar characteristics as the Company expects the effect on the financial statements of applying the practical expedient would not differ materially from applying the accounting guidance to the individual contracts within the portfolio. A pool of contracts is defined as all contracts booked in a particular quarter. The amortization for the capitalized asset is an estimate of the pool’s original contract term, generally one to five years, plus an estimate of future customer renewal periods resulting in a total amortization period of ten years. 
Costs to obtain a contract are allocated amongst performance obligations and recognized as sales and marketing expense consistent with the pattern of revenue recognition. In accordance with GAAP, while certain compensation elements are expensed as incurred, a portion of the pool’s capitalized asset is recorded as an expense over the first seven quarters after booking, which represents the estimated period during which the product revenue associated with the contract is recorded. The remaining capitalized contract costs are recorded as expense ratably over the ten year estimated initial and renewal service periods.Outbound freight billed to customers is recorded as product revenue. The related shipping and handling costs are expensed as part of selling, general, and administrative expense.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0000926326-26-000006:notes:132]
The following table represents the property and equipment balances:

[0000926326-26-000006:notes:133]
|  | December 31, |
|  | 2025 |  | 2024 |
|  | (In thousands) |
| Equipment | $ | 104,071 |  |  | $ | 99,728 |  |
| Furniture and fixtures | 4,672 |  |  | 4,809 |  |
| Leasehold improvements | 18,606 |  |  | 17,722 |  |
| Purchased software and internal-use software development costs | 165,885 |  |  | 146,287 |  |
| Construction in progress | 23,426 |  |  | 12,539 |  |
| Property and equipment, gross | 316,660 |  |  | 281,085 |  |
| Accumulated depreciation and amortization | (196,549) |  |  | (168,393) |  |
| Total property and equipment, net | $ | 120,111 |  |  | $ | 112,692 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000926326-26-000006:notes:134]
Segment Information 
The Company’s one reportable segment derives revenues from sales of its products and related services, as described in Note 1, Organization and Summary of Significant Accounting Policies, which are sold in its principal market, the healthcare industry. The accounting policies of the Company’s one reportable segment are the same as those described in the summary of significant accounting policies in Note 1.

[0000926326-26-000006:notes:135]
As the Company has a single reportable segment and is managed on a consolidated basis, the measure of segment profit or loss that the CODM uses to allocate resources and assess performance is consolidated net income (loss) as reported on the Consolidated Statements of Operations. The CODM uses this key measure to evaluate income generated from segment assets in deciding how to reinvest profits as well as monitor budget versus actual results.

[0000926326-26-000006:notes:136]
The CODM is also provided with certain segment assets, primarily those that impact liquidity, such as cash and cash equivalents, accounts receivable and inventories, as well as certain liabilities such as accounts payable and outstanding debt. Assets and liabilities provided to the CODM are consistent with those reported on the Consolidated Balance Sheets. In addition, the CODM is regularly provided with significant expenses, which are adjusted cost of product and service revenues and adjusted operating expenses. These significant expenses are adjusted for certain non-cash charges and expenses that are unrelated to the Company’s ongoing operations. Adjusted cost of product revenues and adjusted cost of service revenues exclude certain items such as share-based compensation expense, amortization of acquired intangibles, and certain restructuring and severance charges. Adjusted operating expenses include research and development, and selling, general and administrative expenses, and exclude certain items such as share-based compensation expense, amortization of acquired intangibles, legal and regulatory expenses, and certain restructuring and severance charges. To align with the significant expenses provided to the

[0000926326-26-000006:notes:137]
CODM for the year ended December 31, 2025, certain prior-year significant expenses have been recast to conform with current-period presentation. Depreciation and amortization expense for the Company’s single reportable segment was $78.8 million, $82.2 million, and $87.3 million for the years ended December 31, 2025, 2024, and 2023, respectively.

[0000926326-26-000006:notes:138]
The following table summarizes the Company’s reportable segment revenues and significant expenses, reconciled to the Company’s consolidated net income (loss):

[0000926326-26-000006:notes:139]
|  | Year Ended December 31, |
|  | 2025 |  | 2024 |  | 2023 |
|  | (In thousands) |
| Total revenues | $ | 1,184,845 |  |  | $ | 1,112,238 |  |  | $ | 1,147,112 |  |
| Less: |  |  |  |  |  |
| Adjusted cost of product revenues | (375,363) |  |  | (367,638) |  |  | (400,226) |  |
| Adjusted cost of service revenues | (292,853) |  |  | (253,196) |  |  | (227,504) |  |
| Adjusted operating expenses | (433,423) |  |  | (413,280) |  |  | (437,857) |  |
| Other segment items (1) | (78,046) |  |  | (77,787) |  |  | (116,393) |  |
| Interest and other income (expense), net | 6,165 |  |  | 25,256 |  |  | 14,760 |  |
| Provision for income taxes | 9,273 |  |  | 13,062 |  |  | 263 |  |
| Net income (loss) | $ | 2,052 |  |  | $ | 12,531 |  |  | $ | (20,371) |  |

[0000926326-26-000006:notes:140]
_________________________________________________
(1)    Other segment items include certain non-cash charges and expenses that are unrelated to the Company’s ongoing operations. Such charges and expenses consist of items such as share-based compensation, amortization of acquired intangible assets, legal and regulatory expenses, and certain restructuring and severance charges.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000926326-26-000006:notes:141]
Revenues
Disaggregation of Revenues

[0000926326-26-000006:notes:142]
The following table summarizes the Company’s revenues disaggregated by revenue type:

[0000926326-26-000006:notes:143]
|  | Year Ended December 31, |
|  | 2025 |  | 2024 |  | 2023 |
|  | (In thousands) |
| Connected devices, software licenses, and other | $ | 565,475 |  |  | $ | 539,168 |  |  | $ | 623,584 |  |
| Consumables | 100,222 |  |  | 91,339 |  |  | 84,977 |  |
| Technical services | 260,063 |  |  | 238,211 |  |  | 225,831 |  |
| SaaS and Expert Services | 259,085 |  |  | 243,520 |  |  | 212,720 |  |
| Total revenues | $ | 1,184,845 |  |  | $ | 1,112,238 |  |  | $ | 1,147,112 |  |

[0000926326-26-000006:notes:144]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location:

[0000926326-26-000006:notes:145]
|  | Year Ended December 31, |
|  | 2025 |  | 2024 |  | 2023 |
|  | (In thousands) |
| United States | $ | 1,065,071 |  | $ | 1,012,373 |  | $ | 1,011,380 |
| Rest of world (1) | 119,774 |  | 99,865 |  | 135,732 |
| Total revenues | $ | 1,184,845 |  | $ | 1,112,238 |  | $ | 1,147,112 |

[0000926326-26-000006:notes:146]
_________________________________________________

[0000926326-26-000006:notes:147]
(1)    No individual country represented more than 10% of total revenues.

[0000926326-26-000006:notes:148]
The following table reflects the Company’s contract assets and contract liabilities:

[0000926326-26-000006:notes:149]
|  | December 31, |
|  | 2025 |  | 2024 |
|  | (In thousands) |
| Short-term unbilled receivables, net (1) | $ | 28,396 |  |  | $ | 32,917 |  |
| Long-term unbilled receivables, net (2) | 3,521 |  |  | 7,873 |  |
| Total contract assets | $ | 31,917 |  |  | $ | 40,790 |  |
| Short-term deferred revenues | $ | 171,861 |  |  | $ | 141,370 |  |
| Long-term deferred revenues | 63,254 |  |  | 76,123 |  |
| Total contract liabilities | $ | 235,115 |  |  | $ | 217,493 |  |

[0000926326-26-000006:notes:150]
(1)    Included in accounts receivable and unbilled receivables in the Consolidated Balance Sheets.

[0000926326-26-000006:notes:151]
(2)    Included in other long-term assets in the Consolidated Balance Sheets.

[0000926326-26-000006:notes:152]
During the year ended December 31, 2025, the Company recognized revenues of $124.9 million that were included in the corresponding short-term deferred revenues balance of $141.4 million as of December 31, 2024.

[0000926326-26-000006:notes:153]
Significant Customers

[0000926326-26-000006:notes:154]
There were no customers that accounted for more than 10% of the Company’s total revenues for the years ended December 31, 2025, 2024, and 2023. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable and unbilled receivables balance as of December 31, 2025 and 2024.


## us-gaap:EarningsPerShareTextBlock

[0000926326-26-000006:notes:155]
Net Income (Loss) Per Share
Basic net income (loss) per share is computed by dividing net income (loss) for the period by the weighted-average number of shares outstanding during the period. In periods of net loss, all potential common shares are anti-dilutive, so diluted net loss per share equals the basic net loss per share. In periods of net income, diluted net income per share is computed by dividing net income for the period by the basic weighted-average number of shares plus any dilutive potential common stock outstanding during the period, using the treasury stock method for share-based awards and warrants, and the if-converted method for convertible senior notes. Potential common stock includes the effect of outstanding dilutive stock options, restricted stock awards, and restricted stock units, as well as shares the Company could be obligated to issue from its convertible senior notes and warrants, as described in Note 11, Convertible Senior Notes. In the event of the conversion of the Company’s convertible senior notes, the principal portion will be settled in cash with any conversion consideration in excess of the principal portion settled in cash and/or shares of the Company’s common stock at the Company’s option, therefore, only the amounts expected to be settled in excess of the principal portion are considered dilutive in calculating earnings per share under the if-converted method. Any anti-dilutive weighted-average dilutive shares related to stock award plans, convertible senior notes, and warrants are excluded from the computation of the diluted net income per share.

[0000926326-26-000006:notes:156]
The basic and diluted net income (loss) per share calculations were as follows:

[0000926326-26-000006:notes:157]
|  | Year Ended December 31, |
|  | 2025 |  | 2024 |  | 2023 |
|  | (In thousands, except per share data) |
| Net income (loss) | $ | 2,052 |  |  | $ | 12,531 |  |  | $ | (20,371) |  |
| Weighted-average shares outstanding – basic | 45,965 |  |  | 46,047 |  |  | 45,212 |  |
| Effect of dilutive securities from stock award plans | 397 |  |  | 208 |  |  | — |  |
| Weighted-average shares outstanding – diluted | 46,362 |  |  | 46,255 |  |  | 45,212 |  |
| Net income (loss) per share – basic | $ | 0.04 |  |  | $ | 0.27 |  |  | $ | (0.45) |  |
| Net income (loss) per share – diluted | $ | 0.04 |  |  | $ | 0.27 |  |  | $ | (0.45) |  |
| Anti-dilutive weighted-average shares related to stock award plans | 2,377 |  |  | 2,793 |  |  | 3,368 |  |
| Anti-dilutive weighted-average shares related to convertible senior notes and warrants | 6,026 |  |  | 9,622 |  |  | 11,816 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000926326-26-000006:notes:158]
Fair Value of Financial Instruments
The Company measures its financial instruments at fair value. The Company’s cash, cash equivalents, and restricted cash are classified within Level 1 of the fair value hierarchy as they are valued primarily using quoted market prices utilizing market observable inputs. The Company’s credit facility is classified within Level 2 as the valuation inputs are based on quoted prices or market observable data of similar instruments. The Company’s convertible senior notes are classified within Level 2 as the valuation inputs are based on quoted prices in an inactive market on the last day in the reporting period. Refer to Note 10, Debt and Credit Agreement, for further information regarding the Company’s credit facility and Note 11, Convertible Senior Notes, for further information regarding the Company’s convertible senior notes.

[0000926326-26-000006:notes:159]
The following table summarizes the carrying amounts, net of unamortized debt issuance costs, and fair values of the convertible senior notes:

[0000926326-26-000006:notes:160]
|  | As of December 31, |
|  | 2025 |  | 2024 |
|  | (In thousands) |
| Net carrying amount: |  |  |  |
| 2025 Notes | $ | — |  |  | $ | 174,324 |  |
| 2029 Notes | 167,596 |  |  | 166,397 |  |
| Total net carrying amount | $ | 167,596 |  |  | $ | 340,721 |  |
| Fair value: |  |  |  |
| 2025 Notes | $ | — |  |  | $ | 167,129 |  |
| 2029 Notes | 185,869 |  |  | 181,320 |  |
| Total fair value | $ | 185,869 |  |  | $ | 348,449 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000926326-26-000006:notes:161]
Balance Sheet Components
Balance sheet details are presented in the tables below:

[0000926326-26-000006:notes:162]
|  | December 31, |
|  | 2025 |  | 2024 |
|  | (In thousands) |
| Inventories: |  |  |  |
| Raw materials | $ | 26,245 |  |  | $ | 33,501 |  |
| Work in process | 1,321 |  |  | 1,515 |  |
| Finished goods | 73,339 |  |  | 53,643 |  |
| Total inventories | $ | 100,905 |  |  | $ | 88,659 |  |
| Other current assets: |  |  |  |
| Funds held for customers, including restricted cash (1) | $ | 101,104 |  |  | $ | 47,846 |  |
| Deferred cost of sales | 10,819 |  |  | 8,704 |  |
| Net investment in sales-type leases, current portion | 14,648 |  |  | 12,475 |  |
| Prepaid income taxes | 1,836 |  |  | 1,334 |  |
| Other current assets | 3,670 |  |  | 4,934 |  |
| Total other current assets | $ | 132,077 |  |  | $ | 75,293 |  |
| Other long-term assets: |  |  |  |
| External-use software development costs, net | $ | 54,197 |  |  | $ | 58,436 |  |
| Unbilled receivables, net | 3,521 |  |  | 7,873 |  |
| Deferred debt issuance costs | 2,164 |  |  | 2,940 |  |
| Other long-term assets | 10,322 |  |  | 10,057 |  |
| Total other long-term assets | $ | 70,204 |  |  | $ | 79,306 |  |
| Accrued liabilities: |  |  |  |
| Operating lease liabilities, current portion | $ | 11,955 |  |  | $ | 10,702 |  |
| Customer fund liabilities | 101,104 |  |  | 47,846 |  |
| Advance payments from customers | 10,514 |  |  | 12,760 |  |
| Rebate liabilities | 44,722 |  |  | 49,300 |  |
| Taxes payable | 4,017 |  |  | 11,443 |  |
| Other accrued liabilities | 31,274 |  |  | 35,844 |  |
| Total accrued liabilities | $ | 203,586 |  |  | $ | 167,895 |  |

[0000926326-26-000006:notes:163]
(1)    Includes restricted cash of $54.5 million and $29.4 million as of December 31, 2025 and 2024, respectively.

[0000926326-26-000006:notes:164]
The following table summarizes the changes in accumulated balances of other comprehensive income (loss), which consisted of foreign currency translation adjustments:

[0000926326-26-000006:notes:165]
|  | (In thousands) |  |
| Balance as of December 31, 2023 | $ | (13,432) |  |  |  |  |  |  |
| Other comprehensive loss | (3,763) |  |  |  |  |  |  |
| Balance as of December 31, 2024 | (17,195) |  |  |  |  |  |  |
| Other comprehensive income | 8,341 |  |  |  |  |  |  |
| Balance as of December 31, 2025 | $ | (8,854) |  |  |  |  |  |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000926326-26-000006:notes:166]
Property and Equipment
The following table represents the property and equipment balances:

[0000926326-26-000006:notes:167]
Depreciation and amortization expense of property and equipment was $35.4 million, $34.5 million, and $27.0 million for the years ended December 31, 2025, 2024, and 2023, respectively, of which amortization expense related to purchased software and internal-use software development costs was $23.1 million, $19.4 million, and $10.8 million for the years ended December 31, 2025, 2024, and 2023, respectively.

[0000926326-26-000006:notes:168]
The geographic location of the Company’s property and equipment, net, is based on the physical location in which it is located. The following table summarizes the geographic information for property and equipment, net:

[0000926326-26-000006:notes:169]
|  | December 31, |
|  | 2025 |  | 2024 |
|  | (In thousands) |
| United States | $ | 116,102 |  |  | $ | 109,534 |  |
| Rest of world | 4,009 |  |  | 3,158 |  |
| Total property and equipment, net | $ | 120,111 |  |  | $ | 112,692 |  |


## omcl:CapitalizedComputerSoftwareDisclosureTextBlock

[0000926326-26-000006:notes:170]
External-Use Software Development Costs 
The carrying amounts of external-use software development costs were as follows:

[0000926326-26-000006:notes:171]
|  | December 31, |
|  | 2025 |  | 2024 |
|  | (In thousands) |
| Gross carrying amount | $ | 266,523 |  |  | $ | 249,335 |  |
| Accumulated amortization | (212,326) |  |  | (190,899) |  |
| External-use software development costs, net (1) | $ | 54,197 |  |  | $ | 58,436 |  |

[0000926326-26-000006:notes:172]
(1)     Included in other long-term assets in the Consolidated Balance Sheets.

[0000926326-26-000006:notes:173]
The Company recorded $21.8 million, $24.9 million, and $28.7 million to cost of product revenues for amortization of external-use software development costs for the years ended December 31, 2025, 2024, and 2023, respectively.

[0000926326-26-000006:notes:174]
The estimated future amortization expenses for external-use software development costs were as follows:

[0000926326-26-000006:notes:175]
|  | December 31, 2025 |
|  | (In thousands) |
| 2026 | $ | 18,896 |  |
| 2027 | 13,791 |  |
| 2028 | 9,933 |  |
| 2029 | 7,306 |  |
| 2030 | 3,443 |  |
| Thereafter | 828 |  |
| Total | $ | 54,197 |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000926326-26-000006:notes:176]
Goodwill and Intangible Assets
Goodwill

[0000926326-26-000006:notes:177]
The following table represents changes in the carrying amount of goodwill:

[0000926326-26-000006:notes:178]
|  | (In thousands) |
| Balance as of December 31, 2023 | $ | 735,810 |  |
| Foreign currency exchange rate fluctuations | (1,083) |  |
| Balance as of December 31, 2024 | 734,727 |  |
| Foreign currency exchange rate fluctuations | 3,219 |  |
| Balance as of December 31, 2025 | $ | 737,946 |  |

[0000926326-26-000006:notes:179]
Intangible Assets, Net

[0000926326-26-000006:notes:180]
The carrying amounts and useful lives of intangible assets were as follows:

[0000926326-26-000006:notes:181]
|  | December 31, 2025 |
|  | Gross carryingamount (1) |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 306,419 |  |  | $ | (148,990) |  |  | $ | (1,317) |  |  | $ | 156,112 |  |  | 10 - 30 |
| Acquired technology | 39,715 |  |  | (26,358) |  |  | — |  |  | 13,357 |  |  | 4 - 20 |
| Trade names | 2,400 |  |  | (2,400) |  |  | — |  |  | — |  |  | 5 |
| Patents | 1,656 |  |  | (1,020) |  |  | — |  |  | 636 |  |  | 2 - 20 |
| Total intangible assets, net | $ | 350,190 |  |  | $ | (178,768) |  |  | $ | (1,317) |  |  | $ | 170,105 |  |  |  |

[0000926326-26-000006:notes:182]
|  | December 31, 2024 |
|  | Gross carryingamount (1) |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 307,418 |  |  | $ | (133,111) |  |  | $ | (1,373) |  |  | $ | 172,934 |  |  | 4 - 30 |
| Acquired technology | 46,134 |  |  | (32,421) |  |  | — |  |  | 13,713 |  |  | 4 - 20 |
| Trade names | 2,400 |  |  | (1,580) |  |  | — |  |  | 820 |  |  | 5 |
| Patents | 2,291 |  |  | (1,492) |  |  | — |  |  | 799 |  |  | 2 - 20 |
| Total intangible assets, net | $ | 358,243 |  |  | $ | (168,604) |  |  | $ | (1,373) |  |  | $ | 188,266 |  |  |  |

[0000926326-26-000006:notes:183]
(1)    The differences in gross carrying amounts between periods are primarily due to the write-off of certain fully amortized intangible assets.

[0000926326-26-000006:notes:184]
Amortization expense of intangible assets was $21.6 million, $22.8 million, and $31.6 million for the years ended December 31, 2025, 2024, and 2023, respectively.

[0000926326-26-000006:notes:185]
The estimated future amortization expenses for amortizable intangible assets were as follows:

[0000926326-26-000006:notes:186]
|  | December 31,2025 |
|  | (In thousands) |
| 2026 | $ | 17,998 |  |
| 2027 | 16,516 |  |
| 2028 | 15,448 |  |
| 2029 | 13,950 |  |
| 2030 | 10,443 |  |
| Thereafter | 95,750 |  |
| Total | $ | 170,105 |  |


## us-gaap:DebtDisclosureTextBlock

[0000926326-26-000006:notes:187]
Debt and Credit Agreement 
On November 15, 2019, Omnicell, Inc. entered into an Amended and Restated Credit Agreement (as amended, the “Prior A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers, and Wells Fargo Bank, National Association, as administrative agent. As referred to in this Note 10, “Omnicell, Inc.” refers only to Omnicell, Inc., excluding its subsidiaries. The Prior A&R Credit Agreement provided for (a) a five-year revolving credit facility of $500.0 million (the “Prior Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million (the “Prior Incremental Facility”). In addition, the Prior A&R Credit Agreement included a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The Prior A&R Credit Agreement was subsequently amended on September 22, 2020 and March 29, 2023, to permit the issuance of the convertible senior notes and the purchase of the convertible note hedge transactions (as described in Note 11, Convertible Senior Notes), expand the Company’s flexibility to make restricted payments (including common stock repurchases), and replace the total net leverage covenant, as well as to remove and replace the interest rate benchmark based on the London interbank offered rate (“LIBOR”) and related LIBOR-based mechanics with an interest rate benchmark based on the secured overnight financing rate (“SOFR”) as administered by the Federal Reserve Bank of New York and related SOFR-based mechanics.

[0000926326-26-000006:notes:188]
Omnicell, Inc. entered into a Second Amended and Restated Credit Agreement (the “Second A&R Credit Agreement”) on October 10, 2023, with the lenders from time to time party thereto, Wells Fargo Securities, LLC, JPMorgan Chase Bank, N.A., PNC Capital Markets LLC and TD Securities (USA) LLC as joint lead arrangers and Wells Fargo Bank, National Association, as administrative agent. The Second A&R Credit Agreement supersedes the Prior A&R Credit Agreement and provides for (a) a five-year revolving credit facility of $350.0 million (the “Current Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to an amount equal to the sum of (i) the greater of $250.0 million and 100% of the adjusted consolidated EBITDA for the last four quarters and (ii) additional amounts subject to pro forma compliance with certain consolidated secured net leverage ratio (the “Current Incremental Facility”). In addition, the Second A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The

[0000926326-26-000006:notes:189]
Second A&R Credit Agreement has an expiration date of October 10, 2028, subject to acceleration under certain conditions, upon which date all remaining outstanding borrowings will be due and payable.

[0000926326-26-000006:notes:190]
Loans under the Current Revolving Credit Facility bear interest, at Omnicell, Inc.’s option, at a rate equal to either (a) the Adjusted Term SOFR (as defined in the Second A&R Credit Agreement), plus an applicable margin ranging from 1.50% to 2.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the Second A&R Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) the Adjusted Term SOFR for an interest period of one month plus 1.00%, plus an applicable margin ranging from 0.50% to 1.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio. Undrawn commitments under the Current Revolving Credit Facility are subject to a commitment fee ranging from 0.20% to 0.35% per annum based on the Company’s Consolidated Total Net Leverage Ratio on the average daily unused portion of the Current Revolving Credit Facility. Subject to the terms and conditions of the Current Revolving Credit Facility or Current Incremental Facility Omnicell, Inc. is permitted to make voluntary prepayments at any time without payment of a premium or penalty. The availability of funds under the Current Revolving Credit Facility may be subject to reduction in order to maintain compliance with the financial covenants under the Second A&R Credit Agreement.

[0000926326-26-000006:notes:191]
The Second A&R Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends, and other distributions. The Second A&R Credit Agreement contains financial covenants that require the Company to not exceed a maximum consolidated secured net leverage ratio (not to exceed 3.00:1) and maintain a minimum consolidated interest coverage ratio (not to be less than 3.00:1). In addition, the Second A&R Credit Agreement contains certain customary events of default including, but not limited to, failure to pay interest, principal, and fees, or other amounts when due, material misrepresentations or misstatements in any representation or warranty, covenant defaults, certain cross defaults to other material indebtedness, certain judgment defaults, and events of bankruptcy.

[0000926326-26-000006:notes:192]
Omnicell, Inc.’s obligations under the Second A&R Credit Agreement and, at the election of Omnicell, Inc. and the contracting counterparty, any secured swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and such subsidiary guarantors’ assets. In connection with entering into the Second A&R Credit Agreement, and as a condition precedent to borrowing loans thereunder, Omnicell, Inc. and certain of Omnicell, Inc.’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a reaffirmation agreement, which amends certain terms of the existing collateral agreement and reaffirms their obligations under the existing guaranty agreement.

[0000926326-26-000006:notes:193]
As of both December 31, 2025 and December 31, 2024, the Company had $350.0 million of funds available under the Current Revolving Credit Facility. As of December 31, 2025 and 2024, the Company had no outstanding balance under the Current Revolving Credit Facility. The Company was in compliance with all covenants as of December 31, 2025. 
Convertible Senior Notes
0.25% Convertible Senior Notes due 2025

[0000926326-26-000006:notes:194]
On September 25, 2020, Omnicell, Inc. completed a private offering of $575.0 million aggregate principal amount of 0.25% convertible senior notes (the “2025 Notes”), including the exercise in full of the initial purchasers’ option to purchase up to an additional $75.0 million principal amount of the 2025 Notes. As referred to in this Note 11, “Omnicell, Inc.” or the “Company” refers only to Omnicell, Inc., excluding its subsidiaries. Omnicell, Inc. received proceeds from the issuance of the 2025 Notes of $559.7 million, net of $15.3 million of transaction fees and other debt issuance costs. The 2025 Notes were issued pursuant to an indenture, dated September 25, 2020 (the “2025 Notes Indenture”), between the Company and U.S. Bank National Association, as trustee. Prior to maturity, the 2025 Notes were general senior, unsecured obligations of the Company and bore interest at a rate of 0.25% per year, payable semiannually in arrears on March 15 and September 15 of each year, beginning on March 15, 2021.

[0000926326-26-000006:notes:195]
In November 2024, the Company entered into separate, privately negotiated transactions with certain holders of the 2025 Notes to repurchase $400.0 million of aggregate principal amount of the 2025 Notes for approximately $391.0 million of cash. The Company accounted for the partial repurchase of 2025 Notes as a debt extinguishment and recorded a $7.2 million gain on extinguishment, which included a partial write-off of previously deferred debt issuance costs of $1.8 million during the year ended December 31, 2024.

[0000926326-26-000006:notes:196]
The 2025 Notes matured on September 15, 2025 and the Company repaid the remaining principal balance of $175.0 million and $0.2 million of accrued interest in cash.

[0000926326-26-000006:notes:197]
1.00% Convertible Senior Notes due 2029

[0000926326-26-000006:notes:198]
On November 22, 2024, Omnicell, Inc. completed a private offering of $172.5 million aggregate principal amount of 1.00% Convertible Senior Notes due 2029 (the “2029 Notes”), including the exercise in full of the initial purchasers’ option to purchase up to an additional $22.5 million aggregate principal amount of the 2029 Notes. Omnicell, Inc. received proceeds from the issuance of the 2029 Notes of $166.3 million, net of $6.2 million of transaction fees and other debt issuance costs. The 2029 Notes bear interest at a rate of 1.00% per year, payable semiannually in arrears on June 1 and December 1 of each year, beginning on June 1, 2025. The 2029 Notes were issued pursuant to an indenture, dated November 22, 2024 (the “2029 Notes Indenture”), between the Company and U.S. Bank Trust Company, National Association, as trustee. The 2029 Notes are general senior, unsecured obligations of the Company and will mature on December 1, 2029, unless earlier redeemed, purchased, or converted.

[0000926326-26-000006:notes:199]
The 2029 Notes are convertible at any time prior to the close of business on the business day immediately preceding August 1, 2029, only under the following circumstances: (i) during any fiscal quarter commencing after the fiscal quarter ending on March 31, 2025 (and only during such fiscal quarter), if the last reported sale price of the Company’s common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on, and including, the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the 2029 Notes on each applicable trading day; (ii) during the five business day period after any ten consecutive trading day period (the “measurement period”) in which the “trading price” (as defined in the 2029 Notes Indenture) per $1,000 principal amount of the 2029 Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of the Company’s common stock and the conversion rate for the 2029 Notes on each such trading day; (iii) if the Company calls such 2029 Notes for redemption, at any time prior to the close of business on the scheduled trading day immediately preceding the redemption date, but only with respect to the 2029 Notes called (or deemed called) for redemption; or (iv) upon the occurrence of specified corporate events as set forth in the 2029 Notes Indenture. On or after August 1, 2029 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders of the 2029 Notes may convert all or any portion of their 2029 Notes at any time, regardless of the foregoing conditions.

[0000926326-26-000006:notes:200]
During the three months ended December 31, 2025 and 2024, none of the conditional conversion features of the 2029 Notes were triggered, and therefore, the 2029 Notes are not convertible during the first quarter of 2026, commencing on January 1, 2026, and were not convertible during the first quarter of 2025, commencing on January 1, 2025.

[0000926326-26-000006:notes:201]
Upon conversion, the Company will pay cash up to the aggregate principal amount of the 2029 Notes to be converted and pay or deliver, as the case may be, cash, shares of the Company’s common stock or a combination of cash and shares of the Company’s common stock, at the Company’s election, in respect to the remainder, if any, of the Company’s conversion obligation in excess of the aggregate principal amount of the 2029 Notes being converted, in the manner and subject to the terms and conditions provided in the 2029 Notes Indenture.

[0000926326-26-000006:notes:202]
The initial conversion rate for the 2029 Notes is 17.4662 shares of the Company’s common stock per $1,000 principal amount of the 2029 Notes, which is equivalent to an initial conversion price of approximately $57.25 per share of the Company’s common stock, subject to adjustment under certain circumstances in accordance with the terms of the 2029 Notes Indenture. In addition, following certain corporate events that occur prior to the maturity date of the 2029 Notes or if the Company delivers a notice of redemption in respect of the 2029 Notes, the Company will, under certain circumstances, increase the conversion rate of the 2029 Notes for a holder who elects to convert its 2029 Notes (or any portion thereof) in connection with such a corporate event or convert its 2029 Notes called (or deemed called) for redemption during the related redemption period (as defined in the 2029 Notes Indenture), as the case may be.

[0000926326-26-000006:notes:203]
If the Company undergoes a fundamental change (as defined in the 2029 Notes Indenture), holders may require, subject to certain exceptions, the Company to repurchase for cash all or any portion of their 2029 Notes at a fundamental change repurchase price equal to 100% of the principal amount of the 2029 Notes to be repurchased, plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date. As of December 31, 2025, none of the criteria for a fundamental change or a conversion rate adjustment had been met.

[0000926326-26-000006:notes:204]
The Company may not redeem the 2029 Notes prior to December 6, 2027. The Company may redeem for cash all or any portion of the 2029 Notes, at its option, on or after December 6, 2027, if the last reported sale price of the Company’s common stock has been at least 130% of the conversion price for the 2029 Notes then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which the Company provides notice of redemption at a redemption price equal to 100% of the principal amount of the 2029 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. The Company may not redeem less than all of the outstanding 2029 Notes unless at least $100.0 million aggregate principal amount of 2029 Notes are outstanding and not called for redemption as of the time the Company sends the related notice of redemption. No sinking fund is provided for in the 2029 Notes.

[0000926326-26-000006:notes:205]
The debt issuance costs associated with the 2029 Notes are being amortized to interest expense over the term of the 2029 Notes using an effective interest rate of 1.75%. As of December 31, 2025, the remaining life of the 2029 Notes and the related issuance cost accretion is approximately 3.9 years.

[0000926326-26-000006:notes:206]
The maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to other conversion rate adjustments, would be approximately 3.0 million shares. As of December 31, 2025, the if-converted value of the 2029 Notes did not exceed the principal amount.

[0000926326-26-000006:notes:207]
The 2025 Notes and the 2029 Notes consisted of the following balances:

[0000926326-26-000006:notes:208]
|  | December 31, |
|  | 2025 |  | 2024 |
|  | (In thousands) |
| 2025 Notes: |  |  |  |
| Principal amount | $ | — |  |  | $ | 175,000 |  |
| Unamortized debt issuance costs | — |  |  | (676) |  |
| Convertible senior notes, net, current | $ | — |  |  | $ | 174,324 |  |
| 2029 Notes: |  |  |  |
| Principal amount | $ | 172,500 |  |  | $ | 172,500 |  |
| Unamortized debt issuance costs | (4,904) |  |  | (6,103) |  |
| Convertible senior notes, net, noncurrent | $ | 167,596 |  |  | $ | 166,397 |  |

[0000926326-26-000006:notes:209]
The following table summarizes the components of interest expense resulting from the 2025 Notes and the 2029 Notes recognized in interest and other income (expense), net in the Consolidated Statements of Operations:

[0000926326-26-000006:notes:210]
|  | Year Ended December 31, |  |  |
|  | 2025 |  | 2024 |  | 2023 |  |  |
|  | (In thousands) |
| Contractual coupon interest: |  |  |  |  |  |  |  |
| 2025 Notes | $ | 310 |  |  | $ | 1,332 |  |  | $ | 1,438 |  |  |  |
| 2029 Notes | $ | 1,725 |  |  | $ | 182 |  |  | $ | — |  |  |  |
| Amortization of debt issuance costs: |  |  |  |  |  |  |  |
| 2025 Notes | $ | 676 |  |  | $ | 2,886 |  |  | $ | 3,091 |  |  |  |
| 2029 Notes | $ | 1,199 |  |  | $ | 125 |  |  | $ | — |  |  |  |

[0000926326-26-000006:notes:211]
Convertible Note Hedge and Warrant Transactions

[0000926326-26-000006:notes:212]
In connection with the issuance of the 2025 Notes in September 2020 and the 2029 Notes in November 2024, the Company entered into convertible note hedges and warrants transactions, respectively, with certain initial purchasers of the 2025 Notes and the 2029 Notes or affiliates thereof and certain other financial institutions (the “option counterparties”).

[0000926326-26-000006:notes:213]
The convertible note hedges related to the 2025 Notes consisted of call options for the Company to purchase, subject to anti-dilution adjustments substantially similar to those applicable to the 2025 Notes, up to approximately 5.9 million shares of the Company’s common stock, which is equal to the number of shares of the Company’s common stock underlying the 2025 Notes at the time of its issuance, at an initial strike price of approximately $97.32 per share. The convertible note hedges related to the 2029 Notes consisted of call options for the Company to purchase up to, subject to anti-dilution adjustments substantially similar to those applicable to the 2029 Notes, approximately 3.0 million shares of the Company’s common stock, which is equal to the number of shares of the Company’s common stock underlying the 2029 Notes at the time of its issuance, at an initial strike price of approximately $57.25 per share. The convertible note hedges expire upon the maturity of the respective convertible notes, if not earlier exercised or terminated. The cost of the convertible note hedges related to the 2025 Notes and the 2029 Notes was approximately $100.6 million and $40.3 million, respectively, and each was accounted for as an equity instrument, each of which was recorded in additional paid-in capital in the Consolidated Balance Sheets. In addition, the Company recorded a deferred tax asset of $25.8 million and $10.2 million, respectively, at issuance related to the convertible note hedges for the 2025 Notes and the 2029 Notes. The 2029 Notes convertible note hedges are expected generally to reduce

[0000926326-26-000006:notes:214]
the potential dilution to the Company’s common stock upon any conversion of the 2029 Notes and/or offset any cash payments the Company may be required to make in excess of the principal amount of the converted 2029 Notes.

[0000926326-26-000006:notes:215]
Separately from the convertible note hedges, in September 2020 and November 2024, the Company entered into warrant transactions to sell to the respective option counterparties warrants to acquire, subject to customary anti-dilution adjustments, up to approximately 5.9 million shares of its common stock at an initial strike price of approximately $141.56 and approximately 3.0 million shares of its common stock at an initial strike price of approximately $84.82 per share related to the 2025 Notes and the 2029 Notes, respectively. The warrants require net share or net cash settlement upon the Company’s election. The Company received aggregate proceeds of approximately $51.3 million and $25.2 million for the issuance of the warrants related to the 2025 Notes and the 2029 Notes, respectively, which was recorded in additional paid-in capital at issuance in the Consolidated Balance Sheets. The warrants could separately have a dilutive effect to the Company’s common stock to the extent that the market price per share of its common stock, as measured under the warrants, exceeds the strike price of the warrants.

[0000926326-26-000006:notes:216]
In November 2024, in connection with the partial repurchase of the 2025 Notes, the Company entered into unwind agreements with the existing option counterparties to the convertible note hedges and warrants related to the 2025 Notes to terminate a portion of the existing convertible note hedges and warrants related to the 2025 Notes at a notional amount corresponding to the amount of the 2025 Notes repurchased, resulting in an immaterial gain.

[0000926326-26-000006:notes:217]
On September 15, 2025, the convertible note hedges related to the remaining 2025 Notes expired concurrently with the maturity of the 2025 Notes. No settlement was required as the Company’s stock price remained below the strike price at that time. In addition, following maturity of the 2025 Notes, the warrants issued in connection with the 2025 Notes will terminate between December 15, 2025 and June 8, 2026.


## us-gaap:LessorSalesTypeLeasesTextBlock

[0000926326-26-000006:notes:218]
Lessor Leases
Sales-Type Leases

[0000926326-26-000006:notes:219]
The following table presents the Company’s income recognized from sales-type leases:

[0000926326-26-000006:notes:220]
|  | Year Ended December 31, |
|  | 2025 |  | 2024 |  | 2023 |
|  | (In thousands) |
| Sales-type lease revenues | $ | 26,903 |  |  | $ | 31,624 |  |  | $ | 36,208 |  |
| Cost of sales-type lease revenues | (14,242) |  |  | (18,518) |  |  | (18,093) |  |
| Selling profit on sales-type lease revenues | $ | 12,661 |  |  | $ | 13,106 |  |  | $ | 18,115 |  |

[0000926326-26-000006:notes:221]
The receivables as a result of these types of transactions are collateralized by the underlying equipment leased and consist of the following components:

[0000926326-26-000006:notes:222]
|  | December 31, |
|  | 2025 |  | 2024 |
|  | (In thousands) |
| Net minimum lease payments to be received | $ | 88,372 |  |  | $ | 77,976 |  |
| Less: Unearned interest income portion | (12,982) |  |  | (12,757) |  |
| Net investment in sales-type leases | 75,390 |  |  | 65,219 |  |
| Less: Current portion (1) | (14,648) |  |  | (12,475) |  |
| Long-term investment in sales-type leases, net | $ | 60,742 |  |  | $ | 52,744 |  |

[0000926326-26-000006:notes:223]
(1)    The current portion of the net investment in sales-type leases is included in other current assets in the Consolidated Balance Sheets.

[0000926326-26-000006:notes:224]
The carrying amount of the Company’s sales-type lease receivables is a reasonable estimate of fair value.

[0000926326-26-000006:notes:225]
The maturity schedule of future minimum lease payments under sales-type leases retained in-house and the reconciliation to the net investment in sales-type leases reported on the Consolidated Balance Sheets was as follows:

[0000926326-26-000006:notes:226]
|  | December 31,2025 |
|  | (In thousands) |
| 2026 | $ | 17,859 |  |
| 2027 | 17,052 |  |
| 2028 | 15,968 |  |
| 2029 | 13,375 |  |
| 2030 | 10,181 |  |
| Thereafter | 13,937 |  |
| Total future minimum sales-type lease payments | 88,372 |  |
| Present value adjustment | (12,982) |  |
| Total net investment in sales-type leases | $ | 75,390 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0000926326-26-000006:notes:227]
Lessee Leases
The Company has operating leases for office buildings, data centers, office equipment, and vehicles. The Company’s leases have initial terms of one to twelve years. As of December 31, 2025, the Company did not have any additional material operating leases that were entered into, but not yet commenced.

[0000926326-26-000006:notes:228]
The maturity schedule of future minimum lease payments under operating leases and the reconciliation to the operating lease liabilities reported on the Consolidated Balance Sheets was as follows:

[0000926326-26-000006:notes:229]
|  | December 31, 2025 |
|  | (In thousands) |
| 2026 | $ | 13,645 |  |
| 2027 | 11,665 |  |
| 2028 | 9,956 |  |
| 2029 | 3,154 |  |
| 2030 | 618 |  |
| Thereafter | 1,276 |  |
| Total operating lease payments | 40,314 |  |
| Present value adjustment | (3,565) |  |
| Total operating lease liabilities (1) | $ | 36,749 |  |

[0000926326-26-000006:notes:230]
(1)    Amount consists of a current and long-term portion of operating lease liabilities of $12.0 million and $24.8 million, respectively. The current portion of the operating lease liabilities is included in accrued liabilities in the Consolidated Balance Sheets.

[0000926326-26-000006:notes:231]
Operating lease costs were $10.1 million, $10.3 million, and $10.8 million for the years ended December 31, 2025, 2024, and 2023, respectively. Short-term lease costs and variable lease costs were not material for the years ended December 31, 2025, 2024, and 2023. During the year ended December 31, 2023, the Company recorded impairment and abandonment charges to operating lease right-of-use assets of $10.0 million, in connection with restructuring activities to reduce its real estate footprint and for optimization of certain leased facilities. The impairment and abandonment charges were recorded to selling, general, and administrative expenses on the Company’s Consolidated Statements of Operations. Refer to Note 18, Restructuring Expenses, for additional information regarding the Company’s restructuring activities.

[0000926326-26-000006:notes:232]
The following table summarizes supplemental cash flow information related to the Company’s operating leases:

[0000926326-26-000006:notes:233]
|  | Year Ended December 31, |
|  | 2025 |  | 2024 |  | 2023 |
|  | (In thousands) |
| Cash paid for amounts included in the measurement of lease liabilities | $ | 13,954 |  |  | $ | 13,193 |  |  | $ | 13,469 |  |
| Right-of-use assets obtained in exchange for new lease liabilities | $ | 6,353 |  |  | $ | 9,002 |  |  | $ | 6,431 |  |

[0000926326-26-000006:notes:234]
The following table summarizes the weighted-average remaining lease term and weighted-average discount rate related to the Company’s operating leases:

[0000926326-26-000006:notes:235]
|  | December 31, |
|  | 2025 |  | 2024 |
| Weighted-average remaining lease term, years | 3.4 |  | 4.1 |
| Weighted-average discount rate, % | 5.5 | % |  | 5.8 | % |


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000926326-26-000006:notes:236]
Commitments and Contingencies
Purchase Obligations

[0000926326-26-000006:notes:237]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of December 31, 2025, the Company had non-cancelable purchase commitments of $130.5 million, of which $123.1 million are expected to be paid within the next twelve months.

[0000926326-26-000006:notes:238]
Legal Proceedings

[0000926326-26-000006:notes:239]
The Company is currently involved in various legal proceedings.

[0000926326-26-000006:notes:240]
As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any material accrual for contingent liabilities associated with any current legal proceedings based on its belief that any potential material loss, while reasonably possible, is not probable. Furthermore, any possible range of loss in these matters either cannot be reasonably estimated at this time or is not deemed material. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of legal proceedings or because of the diversion of management’s attention and the creation of significant expenses, regardless of outcome.

[0000926326-26-000006:notes:241]
The Company is not a party to any legal proceedings that management believes may have a material impact on the Company’s financial position or results of operations.

[0000926326-26-000006:notes:242]
Guarantees

[0000926326-26-000006:notes:243]
Under the Company’s certificate of incorporation and bylaws, the Company has agreed to indemnify its directors and executive officers to the fullest extent not prohibited by Delaware and other applicable law, subject to certain exceptions. The Company has entered into individual indemnification agreements with its directors and officers. The term of the indemnification period is for the entirety of the director’s or officer’s service to the Company and continues so long as the director or officer may be subject to any claim, action, or proceeding, and there is no limit on the potential amount of future payments that the Company could be required to make under these indemnification agreements. The Company has purchased a directors’ and officers’ liability insurance policy that may enable it to recover a portion of any future payments that it may be required to make under these indemnification agreements. Assuming the applicability of coverage and the willingness of the insurer to assume coverage and subject to certain retention, loss limits, and other policy provisions, the Company believes it is unlikely that the Company will be required to pay any material amounts pursuant to these indemnification obligations. However, no assurances can be given that the insurers will not attempt to dispute the validity, applicability, or amount of coverage without expensive and time-consuming litigation against the insurers.

[0000926326-26-000006:notes:244]
Additionally, the Company undertakes indemnification obligations in its ordinary course of business in connection with, among other things, the sale or licensing of its products and the provision of its support services. In the ordinary course of the Company’s business, the Company has in the past and may in the future agree to indemnify another party, generally its business affiliates or customers, against certain losses suffered or incurred by the indemnified party in connection with various types of claims, which may include, without limitation, claims of intellectual property infringement, certain tax liabilities, its gross negligence or intentional acts in the performance of services, and violations of laws. The term of these indemnification

[0000926326-26-000006:notes:245]
obligations is generally perpetual, but typically will not extend beyond the applicable statute of limitation pursuant to applicable law. In general, the Company attempts to limit the maximum potential amount of future payments that it may be required to make under these indemnification obligations to the amounts paid to it by a customer, but in some cases the obligation may not be so limited.

[0000926326-26-000006:notes:246]
In addition, the Company has in the past and may in the future warrant to its customers that its products will conform to certain representations, which may include functional specifications for a limited period of time following the date of installation (generally not exceeding 30 days) or that its software media is free from material defects. Sales contracts for certain of the Company’s medication packaging systems may have in the past and may in the future include limited warranties for up to six months, but the periodic activity and ending warranty balances the Company records have historically not been material.

[0000926326-26-000006:notes:247]
From time to time, the Company may also warrant that its professional services will conform to certain representations, which may include that such services will be performed in a good and workmanlike manner or in a professional manner consistent with industry standards. The Company generally seeks to disclaim most warranties, including any implied or statutory warranties such as warranties of merchantability, fitness for a particular purpose, title, quality, and non-infringement, as well as any liability with respect to incidental, consequential, special, exemplary, punitive, or similar damages. In some states, such disclaimers may not be enforceable. If necessary, the Company would provide for the estimated cost of product and service warranties based on specific warranty claims and claim history. The Company has not been subject to any significant claims for such losses and has not incurred any material costs in defending or settling claims related to these indemnification obligations. Accordingly, the Company believes it is unlikely that the Company will be required to pay any material amounts pursuant to these indemnification obligations or potential warranty claims and, therefore, no material liabilities have been recorded for such indemnification obligations as of December 31, 2025 and 2024.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000926326-26-000006:notes:248]
Employee Benefits and Share-Based Compensation
Equity Incentive Plans

[0000926326-26-000006:notes:249]
1997 Employee Stock Purchase Plan

[0000926326-26-000006:notes:250]
The Company has an Employee Stock Purchase Plan (“ESPP”), under which employees can purchase shares of its common stock based on a percentage of their compensation, but not greater than 15% of their earnings; provided, however, an eligible employee’s right to purchase shares of the Company’s common stock may not accrue at a rate which exceeds $25,000 of the fair market value of such shares for each calendar year in which such rights are outstanding. The purchase price per share must be equal to the lower of 85% of the fair value of the common stock at the beginning of a 24-month offering period or the end of each six-month purchasing period.

[0000926326-26-000006:notes:251]
2009 Equity Incentive Plan

[0000926326-26-000006:notes:252]
The 2009 Equity Incentive Plan (“2009 Plan”), as amended, provides for the issuance of incentive stock options, RSAs, RSUs, PSUs, and other stock awards to the Company’s employees, directors, and consultants.

[0000926326-26-000006:notes:253]
RSUs generally vest over periods of up to four years, with one-fourth of the shares vesting one year from the vesting commencement date with respect to initial grants, and the remaining shares vesting in 12 equal quarterly installments thereafter. Awards of restricted stock to non-employee directors are granted on the date of the annual meeting of stockholders and vest in full on the date of the next annual meeting of stockholders, provided such non-employee director remains a director on such date. PSUs granted to the Company’s executives may include performance and market conditions. PSUs become eligible for vesting when certain market or performance conditions are met. PSUs generally vest over periods of up to four years, with one-fourth of the shares vesting approximately one year from the vesting commencement date with respect to initial grants and upon confirmation by the Compensation Committee that the performance target has been met, and the remaining shares generally vesting in equal semi-annual or quarterly installments over the remaining three years. Vesting is contingent upon continued service.

[0000926326-26-000006:notes:254]
Share-Based Compensation Expense

[0000926326-26-000006:notes:255]
The following table sets forth the total share-based compensation expense:

[0000926326-26-000006:notes:256]
|  | Year Ended December 31, |
|  | 2025 |  | 2024 |  | 2023 |
|  | (In thousands) |
| Cost of product and service revenues | $ | 4,896 |  |  | $ | 6,373 |  |  | $ | 8,288 |  |
| Research and development | 3,765 |  |  | 4,441 |  |  | 6,941 |  |
| Selling, general, and administrative | 35,841 |  |  | 28,502 |  |  | 40,071 |  |
| Total share-based compensation expense | $ | 44,502 |  |  | $ | 39,316 |  |  | $ | 55,300 |  |

[0000926326-26-000006:notes:257]
During the years ended December 31, 2025 and 2024, the Company capitalized approximately $2.4 million and $3.6 million, respectively, of non-cash share-based compensation expense to internal-use and external-use software development costs related to internal labor. The Company did not capitalize any material non-cash share-based compensation expense to inventory during the years ended December 31, 2025 and 2024. Income tax expense realized from share-based compensation was $4.4 million, $5.4 million, and $6.5 million for the years ended December 31, 2025, 2024, and 2023, respectively.

[0000926326-26-000006:notes:258]
Employee Stock Purchase Plan (“ESPP”)

[0000926326-26-000006:notes:259]
The following assumptions were used to value shares under the ESPP:

[0000926326-26-000006:notes:260]
|  | Year Ended December 31, |
|  | 2025 |  | 2024 |  | 2023 |
| Expected life, years | 0.5 - 2.0 |  | 0.5 - 2.0 |  | 0.5 - 2.0 |
| Expected volatility, % | 45.8% - 58.7% |  | 33.7% - 58.7% |  | 31.7% - 63.9% |
| Risk-free interest rate, % | 3.9% -5.2% |  | 1.5% -5.5% |  | 0.1% - 5.5% |
| Dividend yield, % | — | % |  | — | % |  | — | % |

[0000926326-26-000006:notes:261]
For the years ended December 31, 2025 and 2024, employees purchased approximately 612,000 and 524,000 shares of common stock, respectively, under the ESPP at a weighted-average price of $24.55 and $24.14, respectively.

[0000926326-26-000006:notes:262]
Stock Options

[0000926326-26-000006:notes:263]
There were no stock options granted during the years ended December 31, 2025 and 2024. During the year ended December 31, 2023, the Company granted 200,000 shares of options at the weighted-average fair value per share of options of $19.48.

[0000926326-26-000006:notes:264]
The following table summarizes the stock option activity under the 2009 Plan:

[0000926326-26-000006:notes:265]
|  | Number ofShares |  | Weighted-AverageExercise Price |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2024 | 1,760 |  |  | $ | 67.51 |  |  | 3.6 |  | $ | 2,619 |  |
| Granted | — |  |  | — |  |  |  |  |  |
| Exercised | (63) |  |  | 29.13 |  |  |  |  |  |
| Expired | (344) |  |  | 72.55 |  |  |  |  |  |
| Forfeited | — |  |  | — |  |  |  |  |  |
| Outstanding at December 31, 2025 | 1,353 |  |  | $ | 68.10 |  |  | 3.2 |  | $ | 1,787 |  |
| Exercisable at December 31, 2025 | 1,353 |  |  | $ | 68.10 |  |  | 3.2 |  | $ | 1,787 |  |
| Vested and expected to vest at December 31, 2025 and thereafter | 1,353 |  |  | $ | 68.10 |  |  | 3.2 |  | $ | 1,787 |  |

[0000926326-26-000006:notes:266]
Restricted Stock Units (“RSUs”)

[0000926326-26-000006:notes:267]
The following table summarizes the RSU activity under the 2009 Plan:

[0000926326-26-000006:notes:268]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2024 | 1,614 |  |  | $ | 54.58 |  |  | 1.6 |  | $ | 71,849 |  |
| Granted | 994 |  |  | 32.13 |  |  |  |  |  |
| Vested | (534) |  |  | 62.70 |  |  |  |  |  |
| Forfeited | (413) |  |  | 49.86 |  |  |  |  |  |
| Outstanding and unvested at December 31, 2025 | 1,661 |  |  | $ | 39.65 |  |  | 1.5 |  | $ | 75,261 |  |

[0000926326-26-000006:notes:269]
The weighted-average grant date fair value per share of RSUs granted during the years ended December 31, 2025, 2024, and 2023 was $32.13, $40.35, and $63.74, respectively. The total fair value of RSUs that vested in the years ended December 31, 2025, 2024, and 2023 was $33.5 million, $34.1 million, and $38.0 million, respectively.

[0000926326-26-000006:notes:270]
As of December 31, 2025, total unrecognized compensation cost related to RSUs was $44.9 million, which is expected to be recognized over the remaining weighted-average vesting period of 2.7 years.

[0000926326-26-000006:notes:271]
Performance-Based Stock Unit Awards (“PSUs”)

[0000926326-26-000006:notes:272]
During the year ended December 31, 2024, the Company granted 177,069 PSUs to its executive officers, of which 176% became eligible for vesting upon the achievement of a certain level of shareholder return. During the year ended December 31, 2025, the Company granted 139,348 PSUs to its executive officers, of which 0% to 200% may become eligible for vesting depending on the level of shareholder return for the period from March 1, 2025 through March 1, 2026.

[0000926326-26-000006:notes:273]
The number of shares that vest at the end of the performance period depends on the percentile ranking of the total shareholder return for Omnicell stock over the performance period relative to the total shareholder return of certain companies in the healthcare sector of the S&P 400 and S&P 600 indexes. Stock price appreciation is calculated based on the trailing 20-day average stock price just prior to the first trading day of March in the grant year, compared to the trailing 20-day average stock price just prior to the first trading day of March in the year subsequent to the grant year.

[0000926326-26-000006:notes:274]
The following table summarizes the PSU activity under the 2009 Plan:

[0000926326-26-000006:notes:275]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2024 | 177 |  |  | $ | 28.67 |  |
| Granted (Awarded) | 139 |  |  | 32.66 |  |
| Additional granted based on performance achievement | 135 |  |  | 28.67 |  |
| Vested (Released) | (136) |  |  | 28.67 |  |
| Forfeited | (21) |  |  | 28.67 |  |
| Outstanding and unvested at December 31, 2025 | 294 |  |  | $ | 30.56 |  |

[0000926326-26-000006:notes:276]
The weighted-average grant date fair value per share of PSUs granted during the years ended December 31, 2025, 2024, and 2023 was $32.66, $28.67, and $122.29, respectively. The total fair value of PSUs that vested in the years ended December 31, 2025, 2024, and 2023 was $3.9 million, $1.6 million, and $6.1 million, respectively.

[0000926326-26-000006:notes:277]
As of December 31, 2025, total unrecognized compensation cost related to PSUs was approximately $2.3 million, which is expected to be recognized over the remaining weighted-average vesting period of 2.1 years.

[0000926326-26-000006:notes:278]
Summary of Shares Reserved for Future Issuance under Equity Incentive Plans

[0000926326-26-000006:notes:279]
The Company had the following ordinary shares reserved for future issuance under its equity incentive plans as of December 31, 2025:

[0000926326-26-000006:notes:280]
|  | Number of Shares |
|  | (In thousands) |
| Stock options outstanding | 1,353 |  |
| Non-vested restricted stock awards | 2,009 |  |
| Shares authorized for future issuance | 3,857 |  |
| ESPP shares available for future issuance | 2,114 |  |
| Total shares reserved for future issuance | 9,333 |  |

[0000926326-26-000006:notes:281]
401(k) Plan
The Company has established a pre-tax savings plan under Section 401(k) of the Internal Revenue Code of 1986, as amended. The 401(k) Plan allows eligible employees in the United States to voluntarily contribute a portion of their pre-tax salary, subject to a maximum limit specified in the Internal Revenue Code. The Company generally matches 50% of employee contributions up to $3,000, annually. The Company’s contributions under this plan were $7.9 million, $7.5 million, and $7.9 million in the years ended December 31, 2025, 2024, and 2023, respectively.


## us-gaap:TreasuryStockTextBlock

[0000926326-26-000006:notes:282]
Stock Repurchase Programs
On May 22, 2025, the Company’s Board of Directors (the “Board”) authorized a new stock repurchase program, which does not expire, providing for the repurchase of up to $75.0 million of the Company’s common stock (the “2025 Repurchase Program”). The 2025 Repurchase Program is in addition to the stock repurchase program approved by the Board on August 2, 2016 providing for the repurchase of up to $50.0 million of the Company’s common stock (the “2016 Repurchase Program”).

[0000926326-26-000006:notes:283]
As of December 31, 2024, the maximum dollar value of shares that may yet be purchased under the 2016 Repurchase Program was $2.7 million and during the second quarter of 2025, the 2016 Repurchase Program was completed. As of December 31, 2025, the 2025 Repurchase Program was substantially completed.

[0000926326-26-000006:notes:284]
The timing, price, and volume of repurchases are to be based on a variety of factors, including market conditions, relevant securities laws and regulatory requirements, and other corporate considerations, as determined by the Company’s management. Stock repurchases may be made from time to time on the open market, through block trades, in privately negotiated transactions, accelerated or other structured stock repurchase programs, or pursuant to a Rule 10b5-1 plan. The 2025 Repurchase Program does not obligate the Company to repurchase any specific number of shares, and the Company may terminate or suspend the 2025 Repurchase Program at any time.

[0000926326-26-000006:notes:285]
During the year ended December 31, 2025, the Company repurchased approximately 2,523,000 shares of its common stock under the repurchase programs at an average price of $30.74 per share for an aggregate purchase price of approximately $77.6 million. During the years ended December 31, 2023 and 2024, the Company did not repurchase any of its outstanding common stock under the 2016 Repurchase Program.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000926326-26-000006:notes:286]
Income Taxes
The following is a geographical breakdown of income (loss) before income taxes:

[0000926326-26-000006:notes:287]
|  | Year Ended December 31, |
|  | 2025 |  | 2024 |  | 2023 |
|  | (In thousands) |
| Domestic | $ | 10,154 |  |  | $ | 19,757 |  |  | $ | (28,105) |  |
| Foreign | 1,171 |  |  | 5,836 |  |  | 7,997 |  |
| Income (loss) before income taxes | $ | 11,325 |  |  | $ | 25,593 |  |  | $ | (20,108) |  |

[0000926326-26-000006:notes:288]
The provision for income taxes consisted of the following:

[0000926326-26-000006:notes:289]
|  | Year Ended December 31, |
|  | 2025 |  | 2024 |  | 2023 |
|  | (In thousands) |
| Current: |  |  |  |  |  |
| Federal | $ | 3,309 |  |  | $ | 21,805 |  |  | $ | 8,556 |  |
| State | 5,490 |  |  | 4,964 |  |  | 1,471 |  |
| Foreign | 982 |  |  | 846 |  |  | 840 |  |
| Total current income taxes | 9,781 |  |  | 27,615 |  |  | 10,867 |  |
| Deferred: |  |  |  |  |  |
| Federal | 2,215 |  |  | (14,416) |  |  | (8,002) |  |
| State | (2,023) |  |  | 115 |  |  | (2,261) |  |
| Foreign | (700) |  |  | (252) |  |  | (341) |  |
| Total deferred income taxes | (508) |  |  | (14,553) |  |  | (10,604) |  |
| Total provision for income taxes | $ | 9,273 |  |  | $ | 13,062 |  |  | $ | 263 |  |

[0000926326-26-000006:notes:290]
The following table provides the updated disclosure requirements under ASU 2023-09, which the Company adopted prospectively for annual periods beginning in 2025. The provision for income taxes differs from the amount computed by applying the statutory federal tax rate as follows:

[0000926326-26-000006:notes:291]
|  | Year Ended December 31, |
|  | 2025 |
|  | (In thousands) |  | % |
| U.S. federal tax provision at statutory rate | $ | 2,378 |  |  | 21 | % |
| State income taxes, net of federal benefit (1) | 2,313 |  |  | 20 | % |
| Foreign rate differential: |  |  |  |
| Germany |  |  |  |
| Statutory rate difference between Germany and U.S. | 22 |  |  | — | % |
| Effect of changes in tax laws or rates enacted in the current period | 850 |  |  | 8 | % |
| Net operating loss (“NOL”) adjustment due to audit settlement | (1,083) |  |  | (10) | % |
| Other | 218 |  |  | 2 | % |
| Other | (229) |  |  | (2) | % |
| Effect of cross-border tax laws: |  |  |  |
| Global intangible low-taxed income | 1,499 |  |  | 13 | % |
| Foreign derived intangible income (“FDII”) | (1,146) |  |  | (10) | % |
| Other | 105 |  |  | 1 | % |
| Tax credits: |  |  |  |
| Research and development (“R&D”) credits | (3,795) |  |  | (34) | % |
| Non-taxable or non-deductible items: |  |  |  |
| Share-based compensation expense | 4,520 |  |  | 41 | % |
| Non-deductible officer compensation (Section 162(m)) | 2,320 |  |  | 20 | % |
| Meals and entertainment | 567 |  |  | 5 | % |
| Other adjustments | (13) |  |  | — | % |
| Changes in unrecognized tax benefits | 747 |  |  | 7 | % |
| Total provision for income taxes | $ | 9,273 |  |  | 82 | % |

[0000926326-26-000006:notes:292]
(1)    State taxes in New York, Texas, Pennsylvania, Florida and Minnesota made up the majority (greater than 50%) of the tax effect in this category.

[0000926326-26-000006:notes:293]
As previously disclosed for the years ended December 31, 2024 and 2023, prior to the adoption of ASU 2023-09, the provision for income taxes differs from the amount computed by applying the statutory federal tax rate as follows:

[0000926326-26-000006:notes:294]
|  | Year Ended December 31, |
|  | 2024 |  | 2023 |
|  | (In thousands) |
| U.S. federal tax provision at statutory rate | $ | 5,375 |  |  | $ | (4,223) |  |
| State taxes | 4,037 |  |  | (624) |  |
| Section 162(m) limitation | 531 |  |  | 1,286 |  |
| Non-deductible expenses | 510 |  |  | 531 |  |
| Uncertain tax positions | (881) |  |  | (620) |  |
| Share-based compensation tax expense | 6,078 |  |  | 7,384 |  |
| Research tax credits | (3,531) |  |  | (4,587) |  |
| Gain on extinguishment of debt | 477 |  |  | — |  |
| Foreign-derived intangible income deduction | (229) |  |  | (325) |  |
| Global intangible low-taxed income inclusion | 826 |  |  | — |  |
| Foreign rate differential | 122 |  |  | 219 |  |
| Foreign branch taxes | (7) |  |  | 6 |  |
| Transaction cost | — |  |  | — |  |
| Provision to return true up | (244) |  |  | 697 |  |
| State rate true up | — |  |  | 528 |  |
| Other | (2) |  |  | (9) |  |
| Total provision for income taxes | $ | 13,062 |  |  | $ | 263 |  |

[0000926326-26-000006:notes:295]
The amount of cash income taxes paid, net of refunds received, consisted of the following:

[0000926326-26-000006:notes:296]
|  | Year Ended December 31, |
|  | 2025 |
|  | (In thousands) |
| U.S. Federal (1) | $ | 11,500 |  |
| U.S. State and Local | 6,279 |  |
| Foreign | 631 |  |
| Total cash paid for income taxes, net of refunds received | $ | 18,410 |  |

[0000926326-26-000006:notes:297]
(1)    Individual jurisdictions equaling 5% or more of the total income taxes paid, net of refunds received, for the year ended December 31, 2025 include U.S. Federal of $11.5 million.

[0000926326-26-000006:notes:298]
The amount of cash income taxes paid, net of refunds received, by the Company during the years ended December 31, 2024 and 2023 was $11.3 million and $20.2 million, respectively.

[0000926326-26-000006:notes:299]
The Organization for Economic Co-Operation and Development (“OECD”) introduced Base Erosion and Profit Shifting (“BEPS”) Pillar Two rules that impose a global minimum tax rate of 15% on multi-national corporations. These rules did not have an impact on the Company’s provision for income taxes for the year ended December 31, 2025. The Company continues to monitor evolving tax legislation in the jurisdictions in which it operates.

[0000926326-26-000006:notes:300]
Significant components of the Company’s deferred tax assets (liabilities) were as follows:

[0000926326-26-000006:notes:301]
|  | December 31, |
|  | 2025 |  | 2024 |
|  | (In thousands) |
| Deferred tax assets: |  |  |  |
| Deferred revenues | $ | 40,549 |  |  | $ | 23,550 |  |
| Share-based compensation | 8,992 |  |  | 9,915 |  |
| Inventory-related items | 6,424 |  |  | 6,055 |  |
| Tax credit carryforwards | 12,531 |  |  | 12,843 |  |
| Reserves and accruals | 10,575 |  |  | 8,384 |  |
| Loss carryforwards | 6,802 |  |  | 6,493 |  |
| Lease liability | 9,111 |  |  | 10,615 |  |
| Convertible debt | 8,318 |  |  | 11,276 |  |
| Capitalized research and development | 40,788 |  |  | 49,380 |  |
| Other, net | 1,139 |  |  | 1,580 |  |
| Gross deferred tax assets | 145,229 |  |  | 140,091 |  |
| Valuation allowance | — |  |  | — |  |
| Total net deferred tax assets | 145,229 |  |  | 140,091 |  |
| Deferred tax liabilities: |  |  |  |
| Intangibles | (23,837) |  |  | (27,057) |  |
| Depreciation and amortization | (43,388) |  |  | (35,759) |  |
| Prepaid expenses | (14,224) |  |  | (14,466) |  |
| Right-of-use assets | (6,126) |  |  | (6,448) |  |
| Total deferred tax liabilities | (87,575) |  |  | (83,730) |  |
| Net deferred tax assets | $ | 57,654 |  |  | $ | 56,361 |  |

[0000926326-26-000006:notes:302]
Deferred income tax assets (liabilities) are provided for temporary differences that will result in future tax deductions or future taxable income, as well as the future benefit of tax credit carryforwards. The Company recognizes deferred tax assets to the extent that it believes these assets are more likely than not to be realized. In making such a determination, the Company considers all available positive and negative evidence, including future reversals of existing temporary differences, projected future taxable income, tax planning strategies, and results of recent operations. As of December 31, 2025 and 2024, the Company does not have a valuation allowance against any of its deferred tax assets.

[0000926326-26-000006:notes:303]
As of December 31, 2025, the Company had no federal net operating loss carryforward and $9.5 million of state net operating loss carryforwards. The Company also has $22.4 million of foreign net operating losses carried forward indefinitely. For income tax purposes, the Company had no federal research tax credit carryforward and a California research tax credit carryforward of $21.2 million. California research tax credits are carried forward indefinitely to reduce cash taxes payable.

[0000926326-26-000006:notes:304]
It is the Company’s practice and intention to reinvest the earnings of its non-U.S. subsidiaries in those operations. As of December 31, 2025, the Company has not made a provision for U.S. federal income, withholding, and state income taxes on the outside basis difference related to certain foreign subsidiaries because earnings are intended to be indefinitely reinvested in operations outside the U.S.

[0000926326-26-000006:notes:305]
The Company files income tax returns in the United States and various state and foreign jurisdictions. In the normal course of business, the Company is subject to examinations by taxing authorities, including major jurisdictions such as the United States, Germany, Italy, France, the United Kingdom and India. With few exceptions, as of December 31, 2025, the Company was no longer subject to federal U.S., state, and foreign tax examinations for years before 2022, 2021, and 2021, respectively.

[0000926326-26-000006:notes:306]
The following table summarizes the aggregate change in the balance of gross unrecognized tax benefit, which excludes interest and penalties:

[0000926326-26-000006:notes:307]
|  | (In thousands) |
| Balance as of December 31, 2022 | $ | 9,296 |  |
| Increases related to tax positions taken during a prior period | 750 |  |
| Decreases related to tax positions taken during the prior period | (161) |  |
| Increases related to tax positions taken during the current period | 1,566 |  |
| Decreases related to expiration of statute of limitations | (703) |  |
| Balance as of December 31, 2023 | 10,748 |  |
| Increases related to tax positions taken during a prior period | 4 |  |
| Decreases related to tax positions taken during the prior period | (138) |  |
| Increases related to tax positions taken during the current period | 1,163 |  |
| Decreases related to settlements | (333) |  |
| Decreases related to expiration of statute of limitations | (952) |  |
| Balance as of December 31, 2024 | 10,492 |  |
| Increases related to tax positions taken during a prior period | 4 |  |
| Decreases related to tax positions taken during the prior period | (32) |  |
| Increases related to tax positions taken during the current period | 997 |  |
| Decreases related to expiration of statute of limitations | (197) |  |
| Balance as of December 31, 2025 | $ | 11,264 |  |

[0000926326-26-000006:notes:308]
The total amount of gross unrecognized tax benefit that, if realized, would favorably affect the Company’s effective income tax rate in future periods, was $11.3 million and $10.5 million as of December 31, 2025 and 2024, respectively. The Company recognizes interest and penalties related to uncertain tax positions in interest and other income (expense), net in the Consolidated Statements of Operations, accruing $0.5 million, $0.3 million, and $0.2 million for the years ended December 31, 2025, 2024, and 2023, respectively. Accrued interest and penalties are included within other long-term liabilities on the Consolidated Balance Sheets. The combined amount of cumulative accrued interest and penalties was approximately $1.1 million, $0.6 million, and $0.4 million for the years ended December 31, 2025, 2024, and 2023, respectively.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000926326-26-000006:notes:309]
Restructuring Expenses
During 2023, due to challenging industry dynamics and macroeconomic conditions, the Company underwent several expense containment measures such as a reduction of its headcount across many of its functions and a reduction of its real estate footprint. During the year ended December 31, 2023, the restructuring initiatives incurred $15.5 million of employee severance costs and related expenses, net of reversals. Refer to Note 13, Lessee Leases for information regarding the Company’s restructuring activities for the reduction of its real estate footprint and optimization of certain leased facilities.

[0000926326-26-000006:notes:310]
On April 26, 2024, the Company’s management committed to the wind down of the Company’s Medimat Robotic Dispensing System (“RDS”) product line, subject to local law and statutory works council consultation requirements. During the year ended December 31, 2024, the Company incurred approximately $6.6 million of employee severance costs and other expenses related to the RDS product line wind down, net of immaterial reversals of previously recognized restructuring expenses. The Company also incurred $5.4 million of inventory write-down charges during the year ended December 31, 2024 related to the RDS product line wind down that were recorded to cost of revenues in the Company’s Consolidated Statements of Operations. Further, during the fourth quarter of 2025, the Company incurred additional charges related to the wind down of the Company’s RDS product line. During the year ended December 31, 2025, the Company incurred approximately $3.9 million of employee severance costs and other expenses in connection with this initiative.

[0000926326-26-000006:notes:311]
During the third quarter of 2025, the Company underwent a restructuring initiative within the EnlivenHealth business in order to gain operational efficiency and synergy, and adapt to the recent industry dynamics within the retail pharmacy space. During the year ended December 31, 2025, the Company incurred approximately $2.6 million of employee severance and other related expenses in connection with this initiative.

[0000926326-26-000006:notes:312]
As of December 31, 2025, the unpaid balance related to these restructuring plans was $3.9 million.

[0000926326-26-000006:notes:313]
The following table summarizes the total employee-related restructuring expense, net of reversals:

[0000926326-26-000006:notes:314]
|  | Year Ended December 31, |
|  | 2025 |  | 2024 |  | 2023 |
|  | (In thousands) |
| Cost of product and service revenues | $ | 4,601 |  |  | $ | 4,504 |  |  | $ | 3,089 |  |
| Research and development | 937 |  |  | 419 |  |  | 3,829 |  |
| Selling, general, and administrative | 967 |  |  | 230 |  |  | 8,621 |  |
| Total restructuring expenses, net of reversals | $ | 6,505 |  |  | $ | 5,153 |  |  | $ | 15,539 |  |


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000926326-26-000006:notes:315]
SCHEDULE II

[0000926326-26-000006:notes:316]
VALUATION AND QUALIFYING ACCOUNTS

[0000926326-26-000006:notes:317]
|  | Balance atBeginning of Period (1) |  | Charged (Credited) toCosts and Expenses (2) |  | AmountsWritten Off (3) |  | Other Adjustments (4) |  | Balance atEnd of Period (1) |
|  | (In thousands) |
| Year ended December 31, 2023 |  |  |  |  |  |  |  |  |  |
| Accounts receivable and unbilled receivables | $ | 5,153 |  |  | $ | 2,726 |  |  | $ | (2,441) |  |  | $ | 126 |  |  | $ | 5,564 |  |
| Long-term unbilled receivables | 35 |  |  | (4) |  |  | — |  |  | — |  |  | 31 |  |
| Net investment in sales-type leases | 308 |  |  | (51) |  |  | — |  |  | — |  |  | 257 |  |
| Total allowances deducted from assets | $ | 5,496 |  |  | $ | 2,671 |  |  | $ | (2,441) |  |  | $ | 126 |  |  | $ | 5,852 |  |
| Year ended December 31, 2024 |  |  |  |  |  |  |  |  |  |
| Accounts receivable and unbilled receivables | $ | 5,564 |  |  | $ | 3,943 |  |  | $ | (2,691) |  |  | $ | (171) |  |  | $ | 6,645 |  |
| Long-term unbilled receivables | 31 |  |  | 48 |  |  | — |  |  | — |  |  | 79 |  |
| Net investment in sales-type leases | 257 |  |  | (116) |  |  | — |  |  | — |  |  | 141 |  |
| Total allowances deducted from assets | $ | 5,852 |  |  | $ | 3,875 |  |  | $ | (2,691) |  |  | $ | (171) |  |  | $ | 6,865 |  |
| Year ended December 31, 2025 |  |  |  |  |  |  |  |  |  |
| Accounts receivable and unbilled receivables | $ | 6,645 |  |  | $ | 7,004 |  |  | $ | (4,918) |  |  | $ | 137 |  |  | $ | 8,868 |  |
| Long-term unbilled receivables | 79 |  |  | (18) |  |  | — |  |  | — |  |  | 61 |  |
| Net investment in sales-type leases | 141 |  |  | (3) |  |  | — |  |  | — |  |  | 138 |  |
| Total allowances deducted from assets | $ | 6,865 |  |  | $ | 6,983 |  |  | $ | (4,918) |  |  | $ | 137 |  |  | $ | 9,067 |  |

[0000926326-26-000006:notes:318]
__________________________________________________

[0000926326-26-000006:notes:319]
(1)Allowance for credit losses.

[0000926326-26-000006:notes:320]
(2)Represents amounts charged and credited for provisions for credit losses.

[0000926326-26-000006:notes:321]
(3)Represents amounts written off from the allowance and receivable.

[0000926326-26-000006:notes:322]
(4)Represents other adjustments, such as foreign currency translation adjustments.
