# OMCL 8-K — 0000926326-20-000003 filed 2020-02-06

## item codes, every 8-K on or before 2020-02-26

- 2020-02-18 0000926326-20-000007 — 5.02, 9.01
- 2020-02-13 0000926326-20-000005 — 8.01
- 2020-02-06 0000926326-20-000003 — 2.02, 9.01
- 2019-12-06 0001104659-19-070339 — 8.01
- 2019-11-18 0000926326-19-000035 — 1.01, 2.03, 9.01
- 2019-10-24 0000926326-19-000028 — 2.02, 9.01
- 2019-07-25 0000926326-19-000021 — 2.02, 9.01
- 2019-05-15 0000926326-19-000015 — 5.07
- 2019-04-25 0000926326-19-000011 — 2.02, 9.01
- 2019-03-08 0000926326-19-000009 — 5.02, 9.01
- 2019-02-19 0000926326-19-000005 — 5.02, 9.01
- 2019-02-07 0000926326-19-000003 — 2.02, 9.01
- 2018-10-25 0000926326-18-000028 — 2.02, 9.01
- 2018-09-14 0001104659-18-056929 — 5.02, 9.01
- 2018-07-26 0000926326-18-000022 — 2.02, 9.01
- 2018-06-06 0000926326-18-000019 — 5.02, 9.01
- 2018-05-16 0001104659-18-033801 — 5.07
- 2018-04-26 0000926326-18-000013 — 2.02, 9.01
- 2018-03-02 0001104659-18-014497 — 5.02
- 2018-02-08 0000926326-18-000007 — 5.02
- 2018-02-02 0000926326-18-000005 — 5.02
- 2018-02-01 0000926326-18-000003 — 2.02, 9.01
- 2017-12-26 0000926326-17-000041 — 1.01, 2.03, 9.01
- 2017-11-03 0001104659-17-066102 — 1.01, 8.01, 9.01
- 2017-10-26 0000926326-17-000035 — 2.02, 9.01
- 2017-08-03 0000926326-17-000028 — 5.07 — amendment, the index does not say of what
- 2017-07-27 0000926326-17-000026 — 2.02, 9.01
- 2017-07-25 0000926326-17-000023 — 5.02, 9.01
- 2017-05-24 0000926326-17-000019 — 5.07
- 2017-05-04 0001628280-17-004851 — 2.02, 9.01
- 2017-02-15 0000926326-17-000010 — 2.05
- 2017-02-15 0000926326-17-000008 — 2.02, 9.01
- 2017-02-13 0000926326-17-000002 — 5.02
- 2016-12-08 0001104659-16-161330 — 2.01, 2.03, 9.01
- 2016-12-06 0001104659-16-160709 — 7.01
- 2016-11-29 0001104659-16-159456 — 1.01, 7.01, 9.01
- 2016-10-27 0000926326-16-000075 — 2.02, 9.01
- 2016-10-07 0000926326-16-000072 — 5.02, 8.01
- 2016-08-05 0000926326-16-000068 — 8.01
- 2016-07-28 0000926326-16-000066 — 2.02, 9.01
- 2016-06-13 0001104659-16-126854 — 5.02
- 2016-05-25 0000926326-16-000060 — 5.07
- 2016-04-28 0000926326-16-000054 — 2.02, 9.01
- 2016-03-21 0001104659-16-106649 — 8.01, 9.01
- 2016-03-17 0000926326-16-000051 — 7.01, 9.01
- 2016-03-17 0000926326-16-000049 — 9.01 — amendment of 0000926326-16-000051
- 2016-02-10 0001104659-16-095486 — 5.02, 9.01
- 2016-02-04 0000926326-16-000041 — 2.02, 9.01
- 2016-01-06 0001104659-16-088299 — 1.01, 2.01, 2.03, 9.01
- 2015-12-10 0000926326-15-000038 — 8.01, 9.01
- 2015-10-29 0001104659-15-074138 — 1.01, 9.01
- 2015-10-29 0000926326-15-000031 — 2.02, 9.01
- 2015-08-20 0001104659-15-061135 — 5.02, 9.01
- 2015-07-30 0000926326-15-000024 — 2.02, 9.01
- 2015-05-22 0001104659-15-040440 — 5.07
- 2015-05-01 0001104659-15-032846 — 5.02
- 2015-05-01 0001104659-15-032844 — 7.01
- 2015-04-30 0000926326-15-000015 — 9.01
- 2015-04-22 0001104659-15-029356 — 8.01, 9.01
- 2015-03-20 0001104659-15-021435 — 3.01
- 2015-03-18 0001104659-15-020699 — 7.01
- 2015-03-17 0001104659-15-020483 — 8.01, 9.01
- 2015-03-02 0001104659-15-015802 — 1.01, 9.01
- 2015-02-12 0001104659-15-009234 — 5.02, 9.01
- 2015-02-03 0000926326-15-000003 — 9.01
- 2015-01-15 0001104659-15-002635 — 5.02
- 2014-11-07 0001104659-14-078398 — 1.01, 8.01, 9.01
- 2014-10-30 0000926326-14-000037 — 2.02, 9.01
- 2014-08-25 0001104659-14-062772 — 8.01, 9.01
- 2014-07-31 0000926326-14-000032 — 2.02, 9.01
- 2014-05-21 0001104659-14-040744 — 5.07
- 2014-05-01 0000926326-14-000008 — 2.02, 9.01
- 2014-04-08 0001104659-14-026441 — 4.01, 9.01
- 2014-04-02 0001104659-14-025179 — 5.02
- 2014-02-07 0001104659-14-007552 — 5.02, 9.01
- 2014-02-04 0001104659-14-006352 — 2.02, 9.01
- 2013-12-09 0001104659-13-088980 — 1.01, 9.01
- 2013-12-02 0001104659-13-087877 — 5.02
- 2013-10-31 0001104659-13-079660 — 2.02, 9.01
- 2013-09-26 0001104659-13-072435 — 1.01, 2.03, 9.01
- 2013-08-01 0001104659-13-058959 — 2.02, 9.01
- 2013-05-23 0001104659-13-044317 — 5.07
- 2013-05-02 0001104659-13-036605 — 2.02, 9.01
- 2013-03-11 0001104659-13-019143 — 8.01
- 2013-02-07 0001104659-13-008477 — 5.02, 9.01
- 2013-01-31 0001104659-13-006446 — 2.02, 9.01
- 2012-11-02 0001104659-12-073697 — 5.02
- 2012-10-25 0001104659-12-071211 — 2.02, 9.01
- 2012-08-06 0001104659-12-054635 — 8.01
- 2012-08-03 0001104659-12-054214 — 2.01, 9.01 — amendment of 0001104659-12-038888
- 2012-08-01 0001104659-12-053005 — 2.02, 9.01
- 2012-06-12 0001104659-12-042936 — 8.01, 9.01
- 2012-05-23 0001104659-12-039459 — 5.07
- 2012-05-22 0001104659-12-038888 — 2.01, 9.01
- 2012-05-02 0001104659-12-032048 — 2.02, 9.01
- 2012-05-02 0001104659-12-032036 — 1.01, 9.01
- 2012-04-04 0001104659-12-023883 — 5.02, 8.01
- 2012-03-20 0001104659-12-019462 — 1.01, 9.01
- 2012-02-13 0001104659-12-009353 — 5.02, 9.01
- 2012-01-26 0001104659-12-004244 — 2.02, 9.01
- 2011-10-27 0001104659-11-058464 — 2.02, 9.01
- 2011-10-25 0001104659-11-057721 — 1.01
- 2011-07-28 0001104659-11-041505 — 2.02, 9.01
- 2011-05-27 0001104659-11-032006 — 5.07
- 2011-05-02 0001104659-11-024908 — 2.02, 9.01
- 2011-04-15 0001104659-11-020407 — 5.02, 9.01 — amendment of 0001104659-11-005638
- 2011-02-08 0001104659-11-005638 — 5.02, 9.01
- 2011-01-27 0001104659-11-003419 — 2.02, 9.01
- 2010-12-22 0001104659-10-064003 — 5.02, 5.07, 9.01
- 2010-10-27 0001104659-10-054036 — 2.02, 9.01
- 2010-10-05 0001104659-10-051173 — 8.01
- 2010-07-22 0001104659-10-039126 — 2.02, 9.01
- 2010-07-09 0001104659-10-037594 — 2.05
- 2010-05-28 0001104659-10-031607 — 5.07
- 2010-04-26 0001104659-10-021797 — 2.02, 9.01
- 2010-03-17 0001104659-10-014849 — 5.02, 9.01
- 2010-02-08 0001104659-10-005457 — 5.02, 9.01
- 2010-01-28 0001104659-10-003627 — 2.02, 9.01
- 2009-10-22 0001104659-09-059972 — 2.02, 9.01
- 2009-07-23 0001104659-09-044508 — 2.02, 9.01
- 2009-05-20 0001104659-09-033938 — 5.02, 9.01
- 2009-04-30 0001104659-09-027707 — 2.02, 9.01
- 2009-03-10 0001104659-09-016178 — 5.02, 9.01
- 2009-02-09 0001104659-09-007692 — 5.02, 9.01
- 2009-01-29 0001104659-09-005022 — 2.02, 2.05, 9.01
- 2009-01-21 0001104659-09-003180 — 2.02, 8.01, 9.01
- 2009-01-06 0001104659-09-000625 — 5.02
- 2008-10-23 0001104659-08-065475 — 2.02, 9.01
- 2008-07-21 0001104659-08-046690 — 2.02, 9.01
- 2008-05-16 0001104659-08-034035 — 8.01, 9.01
- 2008-04-28 0001104659-08-027379 — 7.01, 9.01
- 2008-04-21 0001104659-08-025616 — 2.02, 9.01
- 2008-03-12 0001104659-08-016939 — 7.01, 9.01
- 2008-02-26 0001104659-08-012840 — 7.01, 9.01
- 2008-02-12 0001104659-08-009382 — 5.02, 9.01
- 2008-01-31 0001104659-08-006199 — 2.02, 9.01
- 2007-12-05 0001104659-07-087191 — 1.01, 9.01
- 2007-10-18 0001104659-07-075654 — 2.02, 9.01
- 2007-07-27 0001104659-07-056886 — 5.03, 9.01
- 2007-07-19 0001104659-07-054924 — 2.02, 9.01
- 2007-05-23 0001104659-07-042287 — 8.01, 9.01
- 2007-05-07 0001104659-07-036172 — 1.01, 5.02, 9.01
- 2007-04-24 0001104659-07-030578 — 2.02, 9.01 — amendment, the index does not say of what
- 2007-04-24 0001104659-07-030547 — 2.02, 9.01
- 2007-04-10 0001104659-07-027465 — 5.02, 9.01
- 2007-03-23 0001104659-07-021969 — 2.02, 4.02, 9.01
- 2007-01-30 0001104659-07-005772 — 2.02, 9.01
- 2007-01-09 0001104659-07-001600 — 5.02, 9.01
- 2006-10-30 0001104659-06-069612 — 1.01
- 2006-10-19 0001104659-06-067549 — 2.02, 9.01
- 2006-07-20 0001104659-06-048020 — 2.02, 4.02, 9.01
- 2006-05-17 0001104659-06-035522 — 1.01, 9.01 — amendment of 0001104659-05-011155
- 2006-05-09 0001104659-06-032706 — 1.01, 9.01
- 2006-04-25 0001104659-06-027438 — 2.02, 9.01
- 2006-04-04 0001104659-06-022204 — 1.01, 9.01
- 2006-03-15 0001104659-06-016861 — 1.01, 9.01
- 2006-01-30 0001104659-06-004749 — 2.02, 9.01
- 2006-01-24 0001104659-06-003504 — 1.01, 5.02, 9.01
- 2005-12-13 0001104659-05-060532 — 1.01, 9.01
- 2005-11-10 0001104659-05-054663 — 2.02, 9.01
- 2005-07-21 0001104659-05-033464 — 2.02, 9.01
- 2005-06-22 0001104659-05-029255 — 1.01
- 2005-05-16 0001104659-05-023473 — 2.02, 9.01 — amendment of 0001104659-05-018173
- 2005-05-16 0001104659-05-023471 — 2.02, 9.01 — amendment of 0001104659-05-017382
- 2005-05-10 0001104659-05-022127 — 1.01
- 2005-04-26 0001104659-05-018173 — 2.02, 9.01
- 2005-04-21 0001104659-05-017382 — 2.02, 9.01
- 2005-04-06 0001104659-05-015401 — 5.02
- 2005-03-15 0001104659-05-011155 — 1.01, 9.01
- 2005-03-08 0001104659-05-009975 — 1.01, 9.01
- 2005-02-03 0001104659-05-003943 — 2.02, 9.01
- 2005-01-13 0001104659-05-001314 — 5.02, 9.01
- 2004-10-21 0001104659-04-031413 — 2.02, 9.01
- 2004-07-22 0001104659-04-020572 — 12, 7
- 2004-04-14 0001104659-04-010039 — 12, 7
- 2004-04-05 0001104659-04-009437 — 12, 7
- 2004-01-26 0001104659-04-001655 — 12, 7
- 2003-10-16 0001104659-03-022990 — 12, 7
- 2003-07-17 0001104659-03-015053 — 9
- 2003-04-18 0001104659-03-006823 — 7, 9
- 2003-02-14 0001104659-03-002607 — 5, 7

## late-filing notifications on or before 2020-02-26

- 2015-03-02 0000926326-15-000006 — NT 10-K, for the period ended 2014-12-31
- 2007-03-16 0001104659-07-020094 — NT 10-K, for the period ended 2006-12-31

## item 2.02 — earnings release, exhibit 99.1

[0000926326-20-000003:8k_2_02:1]
EX-99.1
2
exhibit991q4-19.htm
EX-99.1

[0000926326-20-000003:8k_2_02:2]
Document

[0000926326-20-000003:8k_2_02:3]
Exhibit 99.1

[0000926326-20-000003:8k_2_02:4]
| Contact: |  |  |
| Peter Kuipers |  | Omnicell, Inc. |
| Chief Financial Officer |  | 590 East Middlefield Road |
| 800-850-6664 |  | Mountain View, CA 94043 |
| Peter.Kuipers@Omnicell.com |  |  |

[0000926326-20-000003:8k_2_02:5]
Omnicell Reports Fiscal Year and Fourth Quarter 2019 Results

[0000926326-20-000003:8k_2_02:6]
Record annual GAAP and non-GAAP revenues of $897.0 million

[0000926326-20-000003:8k_2_02:7]
Record 2019 GAAP net income per diluted share of $1.43

[0000926326-20-000003:8k_2_02:8]
Record 2019 non-GAAP net income per diluted share of $2.81

[0000926326-20-000003:8k_2_02:9]
Record ending product backlog of $588 million

[0000926326-20-000003:8k_2_02:10]
MOUNTAIN VIEW, Calif. -- February 6, 2020 -- Omnicell, Inc. (NASDAQ:OMCL), a leading provider of medication management solutions and adherence tools for healthcare systems and pharmacies, today announced results for its fiscal year and fourth quarter ended December 31, 2019.

[0000926326-20-000003:8k_2_02:11]
GAAP Results

[0000926326-20-000003:8k_2_02:12]
GAAP revenues for the fourth quarter of 2019 were $248.3 million, up $36.5 million, or 17% from the fourth quarter of 2018. GAAP revenues for the year ended December 31, 2019 were $897.0 million, up $109.7 million, or 14% from the year ended December 31, 2018.

[0000926326-20-000003:8k_2_02:13]
Fourth quarter 2019 GAAP net income was $22.1 million, or $0.51 per diluted share. This compares to GAAP net income of $14.8 million, or $0.36 per diluted share, for the fourth quarter of 2018.

[0000926326-20-000003:8k_2_02:14]
GAAP net income for the year ended December 31, 2019 was $61.3 million, or $1.43 per diluted share. This compares to GAAP net income of $37.7 million, or $0.93 per diluted share, for the year ended December 31, 2018.

[0000926326-20-000003:8k_2_02:15]
Non-GAAP Results

[0000926326-20-000003:8k_2_02:16]
Non-GAAP revenues for the fourth quarter of 2019 were $248.3 million, up $36.5 million, or 17% from the fourth quarter of 2018. Non-GAAP revenues for the year ended December 31, 2019 were $897.0 million, up $109.7 million, or 14% from the year ended December 31, 2018.

[0000926326-20-000003:8k_2_02:17]
Non-GAAP net income for the fourth quarter of 2019 was $33.5 million, or $0.77 per diluted share. This compares to non-GAAP net income of $29.1 million, or $0.70 per diluted share, for the fourth quarter of 2018.

[0000926326-20-000003:8k_2_02:18]
Non-GAAP net income for the year ended December 31, 2019 was $120.7 million, or $2.81 per diluted share. This compares to non-GAAP net income of $84.6 million, or $2.09 per diluted share for the year ended December 31, 2018.

[0000926326-20-000003:8k_2_02:19]
Non-GAAP net income for each period excludes, when applicable, the effect of share-based compensation expense, amortization expense of acquired intangible assets, acquisition-related expenses, fair value adjustments related to business acquisitions, restructuring and severance-related expenses, tax reform and restructuring income tax benefits and expenses, certain contingent gains, and amortization of debt issuance cost.

[0000926326-20-000003:8k_2_02:20]
Total product bookings for the year ended December 31, 2019 were $813 million compared to $716 million for the year ended December 31, 2018. Total product backlog for the year ended December 31, 2019 was $588 million compared to $478 million for the year ended December 31, 2018, or an increase of 23% year over year.

[0000926326-20-000003:8k_2_02:21]
“We believe the strong growth in our business over the past year is a testament that the vision of the autonomous pharmacy is resonating with our customers,” said Randall Lipps, chairman, president, chief executive officer, and founder of Omnicell. “I am excited to see the strides we are making to advance this vision and the way we are helping to improve medication management by driving toward a zero-error, fully automated and digitized infrastructure across the continuum of care.”

[0000926326-20-000003:8k_2_02:22]
2020 Guidance

[0000926326-20-000003:8k_2_02:23]
For the first quarter of 2020, the Company expects non-GAAP total revenues to be between $221 million and $227 million. The Company expects non-GAAP product revenues to be between $163 million and $168 million, and non-GAAP service revenues to be between $58 million and $59 million. The Company expects first quarter 2020 non-GAAP earnings to be between $0.52 and $0.57 per share.

[0000926326-20-000003:8k_2_02:24]
For the full year 2020, the Company expects product bookings to be between $865 million and $900 million. The Company expects non-GAAP total revenues to be between $1 billion and $1.02 billion. The Company expects non-GAAP product revenues to be between $752 million and $768 million, and non-GAAP service revenues to be between $248 million and $252 million. The Company expects 2020 non-GAAP earnings to be between $2.96 and $3.16 per share.

[0000926326-20-000003:8k_2_02:25]
The table below summarizes Omnicell's 2020 guidance outlined above.

[0000926326-20-000003:8k_2_02:26]
|  | Q1'20 | 2020 |
| Product Bookings | Not provided | $865 million - $900 million |
| Non-GAAP Total Revenues | $221 million - $227 million | $1 billion - $1.02 billion |
| Non-GAAP Product Revenues | $163 million - $168 million | $752 million - $768 million |
| Non-GAAP Service Revenues | $58 million - $59 million | $248 million - $252 million |
| Non-GAAP EPS | $0.52 - $0.57 | $2.96 - $3.16 |

[0000926326-20-000003:8k_2_02:27]
Omnicell Conference Call Information

[0000926326-20-000003:8k_2_02:28]
Omnicell will hold a conference call today, Thursday, February 6, 2020 at 1:30 p.m. PT to discuss fourth quarter financial results. The conference call can be monitored by dialing 1-800-696-5518 within the U.S. or 1-706-758-4883 for all other locations. The Conference ID # is 5679705. Internet users can access the conference call at http://ir.omnicell.com/communications/events-presentations. A replay of the call will be available today at approximately 4:30 p.m. PT and will be available until 11:59 p.m. PT on March 19, 2020. The replay access numbers are 1-855-859-2056 within the U.S. and 1-404-537-3406 for all other locations, Conference ID # is 5679705.

[0000926326-20-000003:8k_2_02:29]
About Omnicell

[0000926326-20-000003:8k_2_02:30]
Since 1992, Omnicell has been committed to transforming the pharmacy care delivery model to dramatically improve outcomes and lower costs. Through the vision of the autonomous pharmacy, a combination of automation, intelligence, and expert services, powered by a cloud data platform, Omnicell supports more efficient ways to manage medications across all care settings.

[0000926326-20-000003:8k_2_02:31]
Over 6,000 facilities worldwide use Omnicell automation and analytics solutions to help increase operational efficiency, reduce medication errors, deliver actionable intelligence, and improve patient safety. More than 40,000 institutional and retail pharmacies across North America and the United Kingdom leverage Omnicell's innovative medication adherence and population health solutions to improve patient engagement and adherence to prescriptions, helping to reduce costly hospital readmissions.

[0000926326-20-000003:8k_2_02:32]
To learn more, visit www.omnicell.com.

[0000926326-20-000003:8k_2_02:33]
Omnicell and the Omnicell logo are registered trademarks of Omnicell, Inc. in the United States and other countries.

[0000926326-20-000003:8k_2_02:34]
Forward-Looking Statements

[0000926326-20-000003:8k_2_02:35]
the autonomous pharmacy and the impact that advanced automation, data intelligence, and expert services will have on patient care, (iv) unfavorable general economic and market conditions, (v) risks to growth and acceptance of Omnicell's products and services, including competitive conversions, and growth in the overall demand for medication management and supply chain solutions and medication adherence solutions generally, (vi) risks presented by the transition to selling more products and services on a subscription basis, (vii) potential of increasing competition, (viii) potential regulatory changes, (ix) Omnicell's ability to improve sales productivity to grow product bookings, and (x) Omnicell's ability to acquire companies, businesses, or technologies and successfully integrate such acquisitions. These and other risks and uncertainties are described more fully in Omnicell’s most recent filings with the Securities and Exchange Commission (“SEC”). Prospective investors are cautioned not to place undue reliance on forward-looking statements. All forward-looking statements contained in this press release speak only as of the date on which they were made. Omnicell undertakes no obligation to update such statements to reflect events that occur or circumstances that exist after the date on which they were made.

[0000926326-20-000003:8k_2_02:36]
Use of Non-GAAP Financial Information

[0000926326-20-000003:8k_2_02:37]
This press release contains financial measures that are not calculated in accordance with GAAP. Our management evaluates and makes operating decisions using various performance measures. In addition to Omnicell’s GAAP results, we also consider non-GAAP revenues, non-GAAP gross profit, non-GAAP operating expenses, non-GAAP net income, and non-GAAP net income per diluted share. Additionally, we calculate adjusted EBITDA (another non-GAAP measure) by means of adjustments to GAAP net income. These non-GAAP results should not be considered as an alternative to gross profit, operating expenses, net income, net income per diluted share, or any other performance measure derived in accordance with GAAP. We present these non-GAAP results because we consider them to be important supplemental measures of Omnicell’s performance.

[0000926326-20-000003:8k_2_02:38]
Our non-GAAP revenues, non-GAAP gross profit, non-GAAP operating expenses, non-GAAP net income, and non-GAAP net income per diluted share are exclusive of certain items to facilitate management’s review of the comparability of Omnicell’s core operating results on a period to period basis because such items are not related to Omnicell’s ongoing core operating results as viewed by management. We define our “core operating results” as those revenues recorded in a particular period and the expenses incurred within that period that directly drive operating income in that period. Management uses these non-GAAP financial measures in making operating decisions because, in addition to meaningful supplemental information regarding operating performance, the measures give us a better understanding of how we should invest in research and development, fund infrastructure growth and evaluate the effectiveness of marketing strategies. In calculating the above non-GAAP results, management specifically adjusted for the following excluded items:

[0000926326-20-000003:8k_2_02:39]
a)Share-based compensation expense.  We excluded from our non-GAAP results the expense related to equity-based compensation plans as they represent expenses that do not require cash settlement from Omnicell.

[0000926326-20-000003:8k_2_02:40]
b)Amortization of acquired intangible assets.  We excluded from our non-GAAP results the intangible assets amortization expense resulting from our past acquisitions. These non-cash charges are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results.

[0000926326-20-000003:8k_2_02:41]
c)Amortization of debt issuance costs.  Debt issuance costs represent costs associated with the issuance of Term Loan and Revolving Line of Credit facilities. The costs include underwriting fees, original issue discount, ticking fee, and legal fees. This non-cash expense is not considered by management to reflect the core cash-generating performance of the business and therefore is excluded from our non-GAAP results.

[0000926326-20-000003:8k_2_02:42]
d)Severance and other related expenses.  We excluded from our non-GAAP results the expenses which are related to restructuring events. These expenses are unrelated to our ongoing operations, and we do not expect them to occur in the ordinary course of business. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and the financial results of peer companies.

[0000926326-20-000003:8k_2_02:43]
e)Tax impact from restructuring activity.  We excluded from our non-GAAP results the income tax impacts related to restructuring activity. These impacts are unrelated to our ongoing operations, and we do not expect them to occur in the ordinary course of business. We believe that excluding these impacts provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and the financial results of peer companies.

[0000926326-20-000003:8k_2_02:44]
f)Tax impact from intellectual property (“IP”) restructuring.  We excluded from our non-GAAP results the tax impacts related to IP restructuring. These impacts are unrelated to our ongoing operations, and we do not expect them to occur in the ordinary course of business. We believe that excluding these impacts provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and the financial results of peer companies.

[0000926326-20-000003:8k_2_02:45]
g)Tax restructuring costs.  We excluded from our non-GAAP results the expenses which are related to restructuring events. These expenses are unrelated to our ongoing operations, vary in size and frequency, and are subject to significant fluctuations from period to period due to varying levels of restructuring activity. We believe that excluding these expenses

[0000926326-20-000003:8k_2_02:46]
provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and the financial results of peer companies.

[0000926326-20-000003:8k_2_02:47]
h)Contingent gain.  We excluded from our non-GAAP results the contingent gain related to a settlement agreement associated with the Ateb acquisition. This contingent gain is unrelated to our ongoing operations, and we do not expect it to occur in the ordinary course of business. We believe that excluding this contingent gain provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and the financial results of peer companies.

[0000926326-20-000003:8k_2_02:48]
Management adjusts for the above items because management believes that, in general, these items possess one or more of the following characteristics: their magnitude and timing is largely outside of Omnicell’s control; they are unrelated to the ongoing operation of the business in the ordinary course; they are unusual and we do not expect them to occur in the ordinary course of business; or they are non-operational, or non-cash expenses involving stock compensation plans or other items.

[0000926326-20-000003:8k_2_02:49]
We believe that the presentation of these non-GAAP financial measures is warranted for several reasons:

[0000926326-20-000003:8k_2_02:50]
a)Such non-GAAP financial measures provide an additional analytical tool for understanding Omnicell’s financial performance by excluding the impact of items which may obscure trends in the core operating results of the business.

[0000926326-20-000003:8k_2_02:51]
b)Since we have historically reported non-GAAP results to the investment community, we believe the inclusion of non-GAAP numbers provides consistency and enhances investors’ ability to compare our performance across financial reporting periods.

[0000926326-20-000003:8k_2_02:52]
c)These non-GAAP financial measures are employed by Omnicell’s management in its own evaluation of performance and are utilized in financial and operational decision making processes, such as budget planning and forecasting.

[0000926326-20-000003:8k_2_02:53]
d)These non-GAAP financial measures facilitate comparisons to the operating results of other companies in our industry, which use similar financial measures to supplement their GAAP results, thus enhancing the perspective of investors who wish to utilize such comparisons in their analysis of our performance.

[0000926326-20-000003:8k_2_02:54]
Set forth below are additional reasons why share-based compensation expense is excluded from our non-GAAP financial measures:

[0000926326-20-000003:8k_2_02:55]
i)While share-based compensation calculated in accordance with Accounting Standard Codification ("ASC") 718 constitutes an ongoing and recurring expense of Omnicell, it is not an expense that requires cash settlement by Omnicell. We therefore exclude these charges for purposes of evaluating core operating results. Thus, our non-GAAP measurements are presented exclusive of share-based compensation expense to assist management and investors in evaluating our core operating results.

[0000926326-20-000003:8k_2_02:56]
ii)We present ASC 718 share-based payment compensation expense in our reconciliation of non-GAAP financial measures on a pre-tax basis because the exact tax differences related to the timing and deductibility of share-based compensation under ASC 718 are dependent upon the trading price of Omnicell’s common stock and the timing and exercise by employees of their stock options. As a result of these timing and market uncertainties, the tax effect related to share-based compensation expense would be inconsistent in amount and frequency and is therefore excluded from our non-GAAP results.

[0000926326-20-000003:8k_2_02:57]
Our adjusted EBITDA calculation is defined as earnings before interest income and expense, taxes, depreciation and amortization, and non-cash expenses, including ASC 718 share-based compensation expense, as well as certain non-GAAP adjustments.

[0000926326-20-000003:8k_2_02:58]
As stated above, we present non-GAAP financial measures because we consider them to be important supplemental measures of performance. However, non-GAAP financial measures have limitations as an analytical tool and should not be considered in isolation or as a substitute for Omnicell’s GAAP results. In the future, we expect to incur expenses similar to certain of the non-GAAP adjustments described above and expect to continue reporting non-GAAP financial measures excluding such items. Some of the limitations in relying on non-GAAP financial measures are:

[0000926326-20-000003:8k_2_02:59]
a)Omnicell’s stock option and stock purchase plans are important components of incentive compensation arrangements and will be reflected as expenses in Omnicell’s GAAP results for the foreseeable future under ASC 718.

[0000926326-20-000003:8k_2_02:60]
b)Other companies, including companies in Omnicell’s industry, may calculate non-GAAP financial measures differently than Omnicell, limiting their usefulness as a comparative measure.

[0000926326-20-000003:8k_2_02:61]
Pursuant to the requirements of SEC Regulation G, a detailed reconciliation between Omnicell’s non-GAAP and GAAP financial results is set forth in the financial tables at the end of this press release. Investors are advised to carefully review and consider this information strictly as a supplement to the GAAP results that are contained in this press release and in Omnicell’s SEC filings.

[0000926326-20-000003:8k_2_02:62]
Our 2020 guidance for non-GAAP earnings per share, as well as certain projections to be discussed in the conference call noted above, exclude “certain items,” which include but are not limited to: unusual gains and losses; costs associated with future restructurings; acquisition-related expenses; and certain tax and litigation outcomes. We do not provide a reconciliation of non-GAAP earnings per share guidance to the comparable GAAP measure as these items are inherently uncertain and difficult to estimate, and cannot be predicted without unreasonable effort. We believe such a reconciliation would imply a degree of precision that could be confusing to investors. These items may also have a material impact on GAAP earnings per share in future periods.

[0000926326-20-000003:8k_2_02:63]
5

[0000926326-20-000003:8k_2_02:64]
Omnicell, Inc.

[0000926326-20-000003:8k_2_02:65]
Condensed Consolidated Statements of Operations

[0000926326-20-000003:8k_2_02:66]
(Unaudited, in thousands, except per share data)

[0000926326-20-000003:8k_2_02:67]
|  | Three Months Ended December 31, |  |  |  | Year Ended December 31, |  |  |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Revenues: |  |  |  |  |  |  |  |
| Product revenues | $ | 187,125 |  |  | $ | 154,591 |  |  | $ | 659,602 |  |  | $ | 569,595 |  |
| Services and other revenues | 61,167 |  |  | 57,159 |  |  | 237,425 |  |  | 217,714 |  |
| Total revenues | 248,292 |  |  | 211,750 |  |  | 897,027 |  |  | 787,309 |  |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | 94,825 |  |  | 82,718 |  |  | 344,914 |  |  | 312,360 |  |
| Cost of services and other revenues | 29,864 |  |  | 26,849 |  |  | 115,201 |  |  | 102,619 |  |
| Total cost of revenues | 124,689 |  |  | 109,567 |  |  | 460,115 |  |  | 414,979 |  |
| Gross profit | 123,603 |  |  | 102,183 |  |  | 436,912 |  |  | 372,330 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 19,093 |  |  | 16,989 |  |  | 68,644 |  |  | 64,843 |  |
| Selling, general, and administrative | 82,328 |  |  | 66,264 |  |  | 289,916 |  |  | 263,095 |  |
| Total operating expenses | 101,421 |  |  | 83,253 |  |  | 358,560 |  |  | 327,938 |  |
| Income from operations | 22,182 |  |  | 18,930 |  |  | 78,352 |  |  | 44,392 |  |
| Interest and other income (expense), net | (212) |  |  | (2,314) |  |  | (4,419) |  |  | (8,776) |  |
| Income before provision for income taxes | 21,970 |  |  | 16,616 |  |  | 73,933 |  |  | 35,616 |  |
| Provision for (benefit from) income taxes | (125) |  |  | 1,823 |  |  | 12,595 |  |  | (2,113) |  |
| Net income | $ | 22,095 |  |  | $ | 14,793 |  |  | $ | 61,338 |  |  | $ | 37,729 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.53 |  |  | $ | 0.37 |  |  | $ | 1.48 |  |  | $ | 0.96 |  |
| Diluted | $ | 0.51 |  |  | $ | 0.36 |  |  | $ | 1.43 |  |  | $ | 0.93 |  |
| Weighted-average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 41,993 |  |  | 39,913 |  |  | 41,462 |  |  | 39,242 |  |
| Diluted | 43,327 |  |  | 41,465 |  |  | 42,943 |  |  | 40,559 |  |

[0000926326-20-000003:8k_2_02:68]
6

[0000926326-20-000003:8k_2_02:69]
Omnicell, Inc.

[0000926326-20-000003:8k_2_02:70]
Condensed Consolidated Balance Sheets

[0000926326-20-000003:8k_2_02:71]
(Unaudited, in thousands)

[0000926326-20-000003:8k_2_02:72]
|  | December 31, |  |  |
|  | 2019 |  | 2018 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 127,210 |  |  | $ | 67,192 |  |
| Accounts receivable and unbilled receivables, net | 218,362 |  |  | 196,238 |  |
| Inventories | 108,011 |  |  | 100,868 |  |
| Prepaid expenses | 14,478 |  |  | 20,700 |  |
| Other current assets | 15,177 |  |  | 12,136 |  |
| Total current assets | 483,238 |  |  | 397,134 |  |
| Property and equipment, net | 54,246 |  |  | 51,500 |  |
| Long-term investment in sales-type leases, net | 19,750 |  |  | 17,082 |  |
| Operating lease right-of-use assets | 56,130 |  |  | — |  |
| Goodwill | 336,539 |  |  | 335,887 |  |
| Intangible assets, net | 124,867 |  |  | 143,686 |  |
| Long-term deferred tax assets | 14,142 |  |  | 15,197 |  |
| Prepaid commissions | 48,862 |  |  | 46,143 |  |
| Other long-term assets | 103,036 |  |  | 74,613 |  |
| Total assets | $ | 1,240,810 |  |  | $ | 1,081,242 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 46,380 |  |  | $ | 38,038 |  |
| Accrued compensation | 44,155 |  |  | 41,660 |  |
| Accrued liabilities | 55,567 |  |  | 43,047 |  |
| Deferred revenues, net | 90,894 |  |  | 81,835 |  |
| Total current liabilities | 236,996 |  |  | 204,580 |  |
| Long-term deferred revenues | 7,083 |  |  | 10,582 |  |
| Long-term deferred tax liabilities | 39,090 |  |  | 41,484 |  |
| Long-term operating lease liabilities | 50,669 |  |  | — |  |
| Other long-term liabilities | 11,718 |  |  | 9,562 |  |
| Long-term debt | 50,000 |  |  | 135,417 |  |
| Total liabilities | 395,556 |  |  | 401,625 |  |
| Total stockholders’ equity | 845,254 |  |  | 679,617 |  |
| Total liabilities and stockholders’ equity | $ | 1,240,810 |  |  | $ | 1,081,242 |  |

[0000926326-20-000003:8k_2_02:73]
Omnicell, Inc.

[0000926326-20-000003:8k_2_02:74]
Condensed Consolidated Statements of Cash Flows

[0000926326-20-000003:8k_2_02:75]
(Unaudited, in thousands)

[0000926326-20-000003:8k_2_02:76]
|  | Year Ended December 31, |  |  |
|  | 2019 |  | 2018 |
| Operating Activities |  |  |  |
| Net income | $ | 61,338 |  |  | $ | 37,729 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 53,559 |  |  | 51,350 |  |
| Loss on disposal of property and equipment | 445 |  |  | 133 |  |
| Share-based compensation expense | 34,049 |  |  | 28,885 |  |
| Deferred income taxes | (1,339) |  |  | (5,705) |  |
| Amortization of operating lease right-of-use assets | 10,562 |  |  | — |  |
| Amortization of debt issuance costs | 2,204 |  |  | 2,292 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable and unbilled receivables | (21,540) |  |  | (6,192) |  |
| Inventories | (8,123) |  |  | (6,763) |  |
| Prepaid expenses | 2,909 |  |  | (308) |  |
| Other current assets | (2,010) |  |  | 1,170 |  |
| Investment in sales-type leases | (3,699) |  |  | (1,680) |  |
| Prepaid commissions | (2,719) |  |  | (4,711) |  |
| Other long-term assets | 4,528 |  |  | (7,077) |  |
| Accounts payable | 7,893 |  |  | (9,154) |  |
| Accrued compensation | 2,495 |  |  | 14,419 |  |
| Accrued liabilities | 3,045 |  |  | 8,223 |  |
| Deferred revenues | 5,445 |  |  | 3,020 |  |
| Operating lease liabilities | (10,040) |  |  | — |  |
| Other long-term liabilities | 6,006 |  |  | (1,665) |  |
| Net cash provided by operating activities |  | 145,008 |  |  | 103,966 |  |
| Investing Activities |  |  |  |
| Software development for external use | (45,770) |  |  | (30,677) |  |
| Purchases of property and equipment | (15,894) |  |  | (23,697) |  |
| Net cash used in investing activities |  | (61,664) |  |  | (54,374) |  |
| Financing Activities |  |  |  |
| Repayment of debt and revolving credit facility | (90,000) |  |  | (77,000) |  |
| Payments for debt issuance costs | (2,321) |  |  | — |  |
| At the market offering, net of offering costs | 37,806 |  |  | 39,567 |  |
| Proceeds from issuances under stock-based compensation plans | 40,706 |  |  | 30,611 |  |
| Employees' taxes paid related to restricted stock units | (9,670) |  |  | (6,775) |  |
| Net cash used in financing activities |  | (23,479) |  |  | (13,597) |  |
| Effect of exchange rate changes on cash and cash equivalents | 153 |  |  | (1,227) |  |
| Net increase in cash and cash equivalents |  | 60,018 |  |  | 34,768 |  |
| Cash and cash equivalents at beginning of period | 67,192 |  |  | 32,424 |  |
| Cash and cash equivalents at end of period | $ | 127,210 |  |  | $ | 67,192 |  |

[0000926326-20-000003:8k_2_02:77]
8

[0000926326-20-000003:8k_2_02:78]
Omnicell, Inc.

[0000926326-20-000003:8k_2_02:79]
Reconciliation of GAAP to Non-GAAP

[0000926326-20-000003:8k_2_02:80]
(Unaudited, in thousands, except per share data and percentage)

[0000926326-20-000003:8k_2_02:81]
|  |  | Three Months Ended December 31, |  |  |  | Year Ended December 31, |  |  |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Reconciliation of GAAP revenues to non-GAAP revenues: |  |  |  |  |  |  |  |  |
| GAAP revenues |  | $ | 248,292 |  |  | $ | 211,750 |  |  | $ | 897,027 |  |  | $ | 787,309 |  |
| Non-GAAP revenues |  | $ | 248,292 |  |  | $ | 211,750 |  |  | $ | 897,027 |  |  | $ | 787,309 |  |
| Reconciliation of GAAP gross profit to non-GAAP gross profit: |  |  |  |  |  |  |  |  |
| GAAP gross profit |  | $ | 123,603 |  |  | $ | 102,183 |  |  | $ | 436,912 |  |  | $ | 372,330 |  |
| GAAP gross margin |  | 49.8% |  |  | 48.3% |  |  | 48.7% |  |  | 47.3% |  |
|  | Share-based compensation expense | 1,454 |  |  | 1,289 |  |  | 5,648 |  |  | 4,635 |  |
|  | Amortization of acquired intangibles | 2,035 |  |  | 3,091 |  |  | 8,182 |  |  | 11,366 |  |
|  | Severance and other expenses | — |  |  | 186 |  |  | — |  |  | 186 |  |
| Non-GAAP gross profit |  | $ | 127,092 |  |  | $ | 106,749 |  |  | $ | 450,742 |  |  | $ | 388,517 |  |
| Non-GAAP gross margin |  | 51.2% |  |  | 50.4% |  |  | 50.2% |  |  | 49.3% |  |
| Reconciliation of GAAP operating expenses to non-GAAP operating expenses: |  |  |  |  |  |  |  |  |
| GAAP operating expenses |  | $ | 101,421 |  |  | $ | 83,253 |  |  | $ | 358,560 |  |  | $ | 327,938 |  |
| GAAP operating expenses % to total revenues |  | 40.8% |  |  | 39.3% |  |  | 40.0% |  |  | 41.7% |  |
|  | Share-based compensation expense | (7,420) |  |  | (6,745) |  |  | (28,401) |  |  | (24,250) |  |
|  | Amortization of acquired intangibles | (2,690) |  |  | (2,937) |  |  | (10,581) |  |  | (12,330) |  |
|  | Severance and other expenses | (795) |  |  | (1,157) |  |  | (1,715) |  |  | (4,337) |  |
| Non-GAAP operating expenses |  | $ | 90,516 |  |  | $ | 72,414 |  |  | $ | 317,863 |  |  | $ | 287,021 |  |
| Non-GAAP operating expenses % to total non-GAAP revenues |  | 36.5% |  |  | 34.2% |  |  | 35.4% |  |  | 36.5% |  |
| Reconciliation of GAAP income from operations to non-GAAP income from operations: |  |  |  |  |  |  |  |  |
| GAAP income from operations |  | $ | 22,182 |  |  | $ | 18,930 |  |  | $ | 78,352 |  |  | $ | 44,392 |  |
| GAAP operating income % to total revenues |  | 8.9% |  |  | 8.9% |  |  | 8.7% |  |  | 5.6% |  |
|  | Share-based compensation expense | 8,874 |  |  | 8,034 |  |  | 34,049 |  |  | 28,885 |  |
|  | Amortization of acquired intangibles | 4,725 |  |  | 6,028 |  |  | 18,763 |  |  | 23,696 |  |
|  | Severance and other expenses | 795 |  |  | 1,343 |  |  | 1,715 |  |  | 4,523 |  |
| Non-GAAP income from operations |  | $ | 36,576 |  |  | $ | 34,335 |  |  | $ | 132,879 |  |  | $ | 101,496 |  |
| Non-GAAP operating income % to total non-GAAP revenues |  | 14.7% |  |  | 16.2% |  |  | 14.8% |  |  | 12.9% |  |

[0000926326-20-000003:8k_2_02:82]
Omnicell, Inc.

[0000926326-20-000003:8k_2_02:83]
Reconciliation of GAAP to Non-GAAP

[0000926326-20-000003:8k_2_02:84]
(Unaudited, in thousands, except per share data and percentage)

[0000926326-20-000003:8k_2_02:85]
|  |  | Three Months Ended December 31, |  |  |  | Year Ended December 31, |  |  |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Reconciliation of GAAP net income to non-GAAP net income: |  |  |  |  |  |  |  |  |
| GAAP net income |  | $ | 22,095 |  |  | $ | 14,793 |  |  | $ | 61,338 |  |  | $ | 37,729 |  |
|  | Tax benefit for restructuring activity | — |  |  | — |  |  | — |  |  | (4,205) |  |
|  | Tax impact of IP restructuring | (2,192) |  |  | — |  |  | 7,432 |  |  | — |  |
|  | Share-based compensation expense | 8,874 |  |  | 8,034 |  |  | 34,049 |  |  | 28,885 |  |
|  | Amortization of acquired intangibles | 4,725 |  |  | 6,028 |  |  | 18,763 |  |  | 23,696 |  |
|  | Severance and other expenses (a) | 1,281 |  |  | 1,916 |  |  | 3,920 |  |  | 6,816 |  |
|  | Contingent gain |  | — |  |  | — |  |  | — |  |  | (2,456) |  |
|  | Tax effect of the adjustments above (b) | (1,261) |  |  | (1,668) |  |  | (4,762) |  |  | (5,891) |  |
| Non-GAAP net income |  | $ | 33,522 |  |  | $ | 29,103 |  |  | $ | 120,740 |  |  | $ | 84,574 |  |
| Reconciliation of GAAP net income per share - diluted to non-GAAP net income per share - diluted: |  |  |  |  |  |  |  |  |
| Shares - diluted GAAP |  | 43,327 |  |  | 41,465 |  |  | 42,943 |  |  | 40,559 |  |
| Shares - diluted Non-GAAP |  | 43,327 |  |  | 41,465 |  |  | 42,943 |  |  | 40,559 |  |
| GAAP net income per share - diluted |  | $ | 0.51 |  |  | $ | 0.36 |  |  | $ | 1.43 |  |  | $ | 0.93 |  |
|  | Tax benefit for restructuring activity | — |  |  | — |  |  | — |  |  | (0.10) |  |
|  | Tax impact of IP restructuring | (0.05) |  |  | — |  |  | 0.17 |  |  | — |  |
|  | Share-based compensation expense | 0.20 |  |  | 0.18 |  |  | 0.79 |  |  | 0.72 |  |
|  | Amortization of acquired intangibles | 0.11 |  |  | 0.15 |  |  | 0.44 |  |  | 0.58 |  |
|  | Severance and other expenses | 0.03 |  |  | 0.05 |  |  | 0.09 |  |  | 0.17 |  |
|  | Contingent gain | — |  |  | — |  |  | — |  |  | (0.06) |  |
|  | Tax effect of the adjustments above (b) | (0.03) |  |  | (0.04) |  |  | (0.11) |  |  | (0.15) |  |
| Non-GAAP net income per share - diluted |  | $ | 0.77 |  |  | $ | 0.70 |  |  | $ | 2.81 |  |  | $ | 2.09 |  |
| Reconciliation of GAAP net income to non-GAAP Adjusted EBITDA(c): |  |  |  |  |  |  |  |  |
| GAAP net income |  | $ | 22,095 |  |  | $ | 14,793 |  |  | $ | 61,338 |  |  | $ | 37,729 |  |
|  | Share-based compensation expense | 8,874 |  |  | 8,034 |  |  | 34,049 |  |  | 28,885 |  |
|  | Interest (income) and expense, net | (587) |  |  | 907 |  |  | 1,378 |  |  | 5,855 |  |
|  | Depreciation and amortization expense | 14,034 |  |  | 13,860 |  |  | 53,559 |  |  | 51,350 |  |
|  | Severance and other expenses | 1,281 |  |  | 1,916 |  |  | 3,920 |  |  | 6,816 |  |
|  | Contingent gain | — |  |  | — |  |  | — |  |  | (2,456) |  |
|  | Income tax expense (benefit) | (125) |  |  | 1,823 |  |  | 12,595 |  |  | (2,113) |  |
| Non-GAAP Adjusted EBITDA |  | $ | 45,572 |  |  | $ | 41,333 |  |  | $ | 166,839 |  |  | $ | 126,066 |  |

[0000926326-20-000003:8k_2_02:86]
(a)For the three months ended December 31, 2019, other expenses include $0.4 million and $0.1 million of amortization of debt issuance cost related to prior acquisitions and credit facilities amendments, respectively, and $0.8 million of tax restructuring costs. For the year ended December 31, 2019, other expenses include $1.6 million and $0.6 million of amortization of debt issuance cost related to prior acquisitions and credit facilities amendments, respectively, and $1.7 million of tax restructuring costs. For the three months ended December 31, 2018, other expenses included $0.4 million and $0.2 million of amortization of debt issuance cost related to prior acquisitions and credit facilities amendments, respectively, and $0.4 million of tax restructuring costs. For the year ended December 31, 2018, other expenses included $1.6 million and $0.7 million of amortization of debt issuance cost related to prior acquisitions and credit facilities amendments, respectively, and $0.9 million of tax restructuring costs.

[0000926326-20-000003:8k_2_02:87]
(b)Tax effects calculated for all adjustments except tax benefits and expenses, and share-based compensation expense, using an estimated annual effective tax rate of 21% for both fiscal years 2019 and 2018.

[0000926326-20-000003:8k_2_02:88]
(c)Defined as earnings before interest income and expense, taxes, depreciation and amortization, share-based compensation, as well as excluding certain non-GAAP adjustments.

[0000926326-20-000003:8k_2_02:89]
10
