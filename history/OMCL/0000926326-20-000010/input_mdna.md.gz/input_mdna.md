# OMCL MD&A — 0000926326-20-000010


## mdna

[0000926326-20-000010:mdna:1]
ITEM 7. MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0000926326-20-000010:mdna:2]
The following discussion and analysis should be read in conjunction with our Consolidated Financial Statements and related Notes in this annual report. This discussion may contain forward-looking statements based upon current expectations that involve risks and uncertainties. Our actual results and the timing of selected events could differ materially from those anticipated in these forward-looking statements as a result of several factors, including those set forth under Item 1A “Risk Factors” and elsewhere in this annual report. Unless otherwise stated, references in this report to particular years or quarters refer to our fiscal year and the associated quarters of those fiscal years.

[0000926326-20-000010:mdna:3]
We have elected to omit discussion of the earliest of the three years covered by the Consolidated Financial Statements presented. Such omitted discussion can be found under Item 7, Management’s Discussion and Analysis of Financial Condition and Results of Operations, located in our annual report on Form 10-K for the fiscal year ended December 31, 2018, filed with the SEC on February 27, 2019, for reference to discussion of the fiscal year ended December 31, 2017, the earliest of the three fiscal years presented.

[0000926326-20-000010:mdna:4]
OVERVIEW

[0000926326-20-000010:mdna:5]
Our Business

[0000926326-20-000010:mdna:6]
We are a leading provider of medication management automation solutions and adherence tools for healthcare systems and pharmacies. As we build on the vision of the autonomous pharmacy - a more fully automated and digitized system of medication management - we believe we will further help enable healthcare providers to improve patient safety, increase efficiency, lower costs, tighten regulatory compliance, and address population health challenges.

[0000926326-20-000010:mdna:7]
Over 6,000 facilities worldwide use our automation and analytics solutions to help increase operational efficiency, reduce medication errors, deliver actionable intelligence, and improve patient safety. More than 40,000 institutional and retail pharmacies across North America and the United Kingdom leverage our innovative medication adherence and population health solutions to improve patient engagement and adherence to prescriptions, helping to reduce costly hospital readmissions. We sell our product and consumable solutions together with related service offerings. Revenues generated in the United States represented 90% of our total revenues for the year ended December 31, 2019.

[0000926326-20-000010:mdna:8]
Over the past several years, our business has expanded from a single-point solution to a platform of products and services that will help to further the vision of the autonomous pharmacy. This has resulted in larger deal sizes across multiple products and installations for customers and, we believe, more comprehensive, valuable, and enduring relationships.

[0000926326-20-000010:mdna:9]
We utilize product bookings as an indicator of the success of our business. Product bookings consist of all firm orders, as evidenced generally by a non-cancelable contract and purchase order for equipment and software products, and by a purchase order for consumables. Equipment and software product bookings are generally installable within twelve months of booking, and other than sales based on subscription services, generally recorded as revenue upon customer receipts of goods or acceptance of the installation. Product bookings increased by 14%, from $716 million in 2018 to $813 million in 2019, driven by the success of our growth strategies in our comprehensive platform and differentiated products, as well as expanding our customer portfolio.

[0000926326-20-000010:mdna:10]
In addition to product solution sales, we provide services to our customers. We provide installation planning and consulting as part of most product sales which is included in the initial price of the solution. To help assure the maximum availability of our systems, our customers typically purchase maintenance and support contracts in increments of one to five years. As a result of the growth of our installed base of customers, our service revenues have also grown.

[0000926326-20-000010:mdna:11]
Our full-time headcount of approximately 2,700 on December 31, 2019, an increase of approximately 220 from December 31, 2018, reflects our efforts to drive profitability and optimize resources allocation.

[0000926326-20-000010:mdna:12]
We have not in the past sold, and have no future plans to sell, our products either directly or indirectly, to customers located in countries that are identified as state sponsors of terrorism by the U.S. Department of State, or those subject to economic sanctions and export controls.

[0000926326-20-000010:mdna:13]
Operating Segments

[0000926326-20-000010:mdna:14]
We previously operated and reported our business in two segments: Automation and Analytics, and Medication Adherence. In an effort to deliver on the strategic vision of the autonomous pharmacy and address industry changes including the continuing consolidation of healthcare systems, rising pharmaceutical costs, and increased scrutiny on controlled substances, we initiated a company-wide organizational realignment in the fourth quarter of 2018 to centrally manage our business operations, including the development and marketing of all of our products, sales and distribution, supply chain and inventory management, as well as regulatory and quality functions. As a result of this organizational realignment, all significant operating decisions are based upon an analysis of Omnicell as one operating segment. Therefore, effective January 1, 2019, we started reporting as only one operating segment, which is the same as the reporting segment. Accordingly, prior period segment information has been revised to conform with current period presentation.

[0000926326-20-000010:mdna:15]
Strategy

[0000926326-20-000010:mdna:16]
We are committed to being the care provider’s most trusted partner and executing on the vision of the autonomous pharmacy by delivering automation, intelligence, and services designed to transform the pharmacy care delivery model, helping

[0000926326-20-000010:mdna:17]
to dramatically improve outcomes and lower costs for our healthcare partners. We believe there are significant challenges in pharmacy that drive the demand for our solutions and represent large market opportunities in three product categories:

[0000926326-20-000010:mdna:18]
•Point of Care.  As a market leader, we expect to continue expansion of this product category as customers increase use of our dispensing systems in more areas within their hospitals. In addition, we are early in the replacement cycle of our XT Series automated dispensing systems which we believe is a significant market opportunity and we expect to continue to focus on further penetrating markets through competitive conversion. We believe our current portfolio within the Point of Care market and new innovation and services will continue to drive improved outcomes and lower costs for our customers.

[0000926326-20-000010:mdna:19]
•Central Pharmacy.  This market represents the beginning of the medication management process in Acute Care Settings, and, we believe, the next big automation opportunity to replace manual and repetitive processes which are common in the pharmacy today. Manual processes are prone to significant errors, and products such as our IV sterile compounding solutions and XR2 Automated Central Pharmacy system automate these manual processes and are designed to reduce the risk of error for our healthcare partners. We believe new products and innovation in the Central Pharmacy market create opportunities to replace prior generation Central Pharmacy robotics and carousels. The Central Pharmacy also represents an opportunity to provide technology enabled services designed to reduce the administrative burden on the pharmacy and allow clinicians to operate at the top of their license.

[0000926326-20-000010:mdna:20]
•Retail, Institutional, and Payer.  We believe the Retail, Institutional, and Payer market represents a large opportunity as the majority of drugs are distributed in the non-acute sector. New technology is leading to innovation at traditional retail providers, which combined with the move to value-based care results, we believe will incentivize the market to adopt solutions to help providers and payers engage patients in new ways that lower the total cost of care. We believe adoption of our Population Health Solutions portfolio of software products and services, along with medication adherence packaging, will increase adherence performance rates, increase prescription volume for our customers and reduce hospital and emergency room visits due to improved adherence.

[0000926326-20-000010:mdna:21]
We believe our technology, services, and solutions within these three product categories position us well to address the needs of retail, acute, and post-acute pharmacy providers.

[0000926326-20-000010:mdna:22]
Acquisitions

[0000926326-20-000010:mdna:23]
On April 12, 2017, we completed the acquisition of InPharmics, a technology and services company that provides advanced pharmacy informatics solutions to hospital pharmacies. The purchase price consideration was $5.0 million, net of cash acquired of $0.3 million. The results of InPharmics’ operations have been included in our consolidated results of operations beginning April 13, 2017.

[0000926326-20-000010:mdna:24]
CRITICAL ACCOUNTING POLICIES AND ESTIMATES

[0000926326-20-000010:mdna:25]
Our discussion and analysis of our financial condition and results of operations are based on our Consolidated Financial Statements, which have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”). The preparation of these financial statements requires us to make certain estimates and assumptions that affect the reported amounts of assets and liabilities, disclosure of any contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. We regularly review our estimates and assumptions, which are based on historical experience and various other factors that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of certain assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates and assumptions. We believe the following critical accounting policies are affected by significant judgments and estimates used in the preparation of our Consolidated Financial Statements:

[0000926326-20-000010:mdna:26]
Revenue Recognition

[0000926326-20-000010:mdna:27]
We earn revenues from sales of our products and related services, which are sold in the healthcare industry, our principal market. The transaction price of each contract with a customer is allocated to the identified performance obligations based on the relative fair value of each obligation. Our customer arrangements typically include one or more of the following performance obligations:

[0000926326-20-000010:mdna:28]
Products. Software-enabled equipment that manages and regulates the storage and dispensing of pharmaceuticals, consumable blister cards and packaging equipment and other medical supplies.

[0000926326-20-000010:mdna:29]
Software. Additional software applications that enable incremental functionality of our equipment or services.

[0000926326-20-000010:mdna:30]
Installation. Installation of equipment as integrated systems at customer sites.

[0000926326-20-000010:mdna:31]
Post-installation technical support. Phone support, on-site service, parts, and access to unspecified software updates and enhancements, if and when available.

[0000926326-20-000010:mdna:32]
Professional services. Other customer services, such as training and consulting.

[0000926326-20-000010:mdna:33]
Prior to recognizing revenue, we identify the contract, performance obligations, and transaction price, and allocate the transaction price to the performance obligations. All identified contracts meet the following required criteria:

[0000926326-20-000010:mdna:34]
Parties to the contract have approved the contract (in writing, orally, or in accordance with other customary business practices) and are committed to perform their respective obligations. A majority of our contracts are evidenced by a non-cancelable written agreement. Contracts for consumable products are generally evidenced by an order placed via phone or a manual purchase order.

[0000926326-20-000010:mdna:35]
Entity can identify each party’s rights regarding the goods or services to be transferred. Contract terms are documented within the written agreements. Where a written contract does not exist, such as for consumable products, the rights of each party are understood as following our standard business process and terms.

[0000926326-20-000010:mdna:36]
The entity can identify the payment terms for the goods or services to be transferred. Payment terms are documented within the agreement and are generally net 30 to 60 days from shipment of tangible product or services performed for customers in the United States. Where a written contract does not exist, our standard payment terms are net 30 day terms.

[0000926326-20-000010:mdna:37]
The contract has commercial substance (that is the risk, timing, or amount of the entity’s future cash flows is expected to change as a result of the contract.) Our agreements are an exchange of cash for a combination of products and services which result in changes in the amount of our future cash flows.

[0000926326-20-000010:mdna:38]
It is probable the entity will collect the consideration to which it will be entitled in exchange for the goods or services that will be transferred to the customer. We perform a credit check for all significant customers or transactions and where collectability is not probable, payment in full or a substantial down payment is typically required to help assure the full agreed upon contract price will be collected.

[0000926326-20-000010:mdna:39]
We often enter into change orders which modify the product to be received by the customer pursuant to certain contracts. Changes to any contract are accounted for as a modification of the existing contract to the extent the goods and services to be delivered as part of the contract are generally consistent with the nature and type of those to be provided under the terms of the original contract. Examples of such change orders include the addition or removal of units of equipment or changes to the configuration of the equipment where the overall nature of the contract remains intact. Our change orders generally result in the change being accounted for as modifications of existing contracts given the nature of the impacted orders.

[0000926326-20-000010:mdna:40]
Distinct goods or services are identified as performance obligations. A series of distinct goods or services that are substantially the same and that have the same pattern of transfer to the customer are considered a single performance obligation. Where a good or service is determined not to be distinct, we combine the good or service with other promised goods or services until a bundle of goods or services that is distinct is identified. To identify our performance obligations, we consider all of the products or services promised in the contract regardless of whether they are explicitly stated or are implied by customary business practices. When performance obligations are included in separate contracts, we consider an entire customer arrangement to determine if separate contracts should be considered combined for the purposes of revenue recognition. Most of our sales, other than renewals of support and maintenance, contain multiple performance obligations, with a combination of hardware systems, consumables and software products, support and maintenance, and professional services.

[0000926326-20-000010:mdna:41]
The transaction price of a contract is determined based on the fixed consideration, net of an estimate for variable consideration such as various discounts or rebates provided to customers. As a result of our commercial selling practices, contract prices are generally fixed with minimal, if any, variable consideration.

[0000926326-20-000010:mdna:42]
The transaction price is allocated to separate performance obligations proportionally based on the standalone selling price of each performance obligation. Standalone selling price is best evidenced by the price we charge for the good or service when selling it separately in similar circumstances to similar customers. Other than for the renewal of annual support services contracts, our products and services are not generally sold separately. We use an amount discounted from the list price as a best estimated selling price.

[0000926326-20-000010:mdna:43]
We recognize revenue when the performance obligation has been satisfied by transferring a promised good or service to a customer. The good or service is transferred when or as the customer obtains control of the good or service. Determining when control transfers requires management to make judgments that affect the timing of revenues recognized. Generally, for products requiring a complex implementation, control passes when the product is installed and ready for use. For all other products, control generally passes when product has been shipped and title has passed. For maintenance contracts and certain

[0000926326-20-000010:mdna:44]
other services provided on a subscription basis, control passes to the customer over time, generally ratably over the service term as we provide a stand-ready service to service the customer’s equipment. Time and material services transfer control to the customer at the time the services are provided. The portion of the transaction price allocated to our unsatisfied performance obligations are recorded as deferred revenues.

[0000926326-20-000010:mdna:45]
Revenues, contract assets, and contract liabilities are recorded net of associated taxes.

[0000926326-20-000010:mdna:46]
We generally invoice customers for products upon shipment. Invoicing associated with the service portion of agreements are generally periodic and are billed on a monthly, quarterly, or annual basis. In certain circumstances, multiple years are billed at one time.

[0000926326-20-000010:mdna:47]
The amount invoiced for equipment and software is typically reflected in both accounts receivable and deferred revenues, net. We typically recognize product revenue, and correspondingly reduce deferred revenues, net, for equipment and software upon written customer acceptance of installation. Consumables are recorded as revenue upon shipment to or receipt by the customer, depending upon contract terms. The portion of deferred revenues, net, not expected to be recognized as revenue within twelve months of the balance sheet date are included in long-term deferred revenues on the Consolidated Balance Sheets.

[0000926326-20-000010:mdna:48]
In the normal course of business, we typically do not accept product returns unless the item is defective as manufactured or the configuration of the product is incorrect. We establish provisions for estimated returns based on historical product returns. The allowance for sales returns is not material to our Consolidated Financial Statements for any periods presented.

[0000926326-20-000010:mdna:49]
Contract Assets and Contract Liabilities

[0000926326-20-000010:mdna:50]
A contract asset is a right to consideration in exchange for goods or services that we have transferred to a customer when that right is conditional and is not just subject to the passage of time. A receivable will be recorded on the balance sheet when we have unconditional rights to consideration. A contract liability is an obligation to transfer goods or services for which we have received consideration, or for which an amount of consideration is due from the customer. Contract liabilities include customer deposits under non-cancelable contracts, and current and non-current deferred revenue balances. Our contract balances are reported in a net contract asset or liability position on a contract-by-contract basis at the end of each reporting period.

[0000926326-20-000010:mdna:51]
Contract Costs

[0000926326-20-000010:mdna:52]
We have determined that the incentive portions of our sales commission plans require capitalization since these payments are directly related to sales achieved during a time period. These commissions are earned on the basis of the total purchase order value of new product bookings. Since there are no commensurate commissions earned on renewal of the service bookings, we concluded that the capitalized asset is related to services provided under both the initial contract and renewal periods. We apply a practical expedient to account for the incremental costs of obtaining a contract as part of a portfolio of contracts with similar characteristics as we expect the effect on the financial statements of applying the practical expedient would not differ materially from applying the accounting guidance to the individual contracts within the portfolio. A pool of contracts is defined as all contracts booked in a particular quarter. The amortization for the capitalized asset is an estimate of the pool’s original contract term, generally one to five years, plus an estimate of future customer renewal periods resulting in a total amortization period of ten years. Costs to obtain a contract are allocated amongst performance obligations and recognized as sales and marketing expense consistent with the pattern of revenue recognition. Capitalized costs are periodically reviewed for impairment. A portion of the pool’s capitalized asset is recorded as an expense over the first two quarters after booking, which represents the estimated period during which the product revenue associated with the contract is recorded. The remaining contract cost is recorded as expense ratably over the ten year estimated initial and renewal service periods. The commission expenses paid or due to be paid as of the consolidated balance sheet date to be recognized in future periods are recorded in long-term prepaid commissions on the Consolidated Balance Sheets.

[0000926326-20-000010:mdna:53]
Lessor Leases

[0000926326-20-000010:mdna:54]
We determine if an arrangement is a lease at inception. The transaction price is allocated to separate performance obligations, generally consisting of hardware and software products, installation, and post-installation technical support, proportionally based on the standalone selling price of each performance obligation. Standalone selling price is best evidenced by the price we charge for the good or service when selling it separately in similar circumstances to similar customers. Other than for the renewal of annual support services contracts, our products and services are not generally sold separately. We use an amount discounted from the list price as a best estimated selling price.

[0000926326-20-000010:mdna:55]
Sales-Type Leases

[0000926326-20-000010:mdna:56]
We enter into non-cancelable sales-type lease arrangements, most of which do not have an option to extend the lease term. At the end of the lease term, the customer must either return the equipment or negotiate a new agreement, resulting in a new purchase or lease transaction. Failure of the customer to either return the equipment or negotiate a new agreement results in the contract becoming a month-to-month rental. Certain sales-type leases automatically renew for successive one year periods at the end of each lease term with written notice from the customer. Our sales-type lease agreements do not contain any material residual value guarantees.

[0000926326-20-000010:mdna:57]
For sales-type leases, we recognize revenues for our hardware and software products, net of lease execution costs, post-installation product maintenance, and technical support, at the net present value of the lease payment stream upon customer acceptance. We recognize service revenues associated with sales-type leases ratably over the term of the agreement in service revenues in the Consolidated Statements of Operations. We recognize interest income from sales-type leases using the effective interest method. Both hardware and software revenues, and interest income from sales-types leases are recorded in product revenues in the Consolidated Statements of Operations.

[0000926326-20-000010:mdna:58]
We optimize cash flows by selling a majority of our non-U.S. government sales-type leases to third-party leasing finance companies on a non-recourse basis. We have no obligation to the leasing company once the lease has been sold. Some of our sales-type leases, mostly those relating to U.S. government hospitals, are retained in-house.

[0000926326-20-000010:mdna:59]
Operating Leases

[0000926326-20-000010:mdna:60]
We entered into certain leasing agreements that were classified as operating leases prior to the adoption of the new lease accounting standard. Those agreements in place prior to January 1, 2019 will continue to be treated as operating leases, however, any new leasing agreements entered into on or after January 1, 2019 under these programs are classified and accounted for as sales-type leases in accordance with the new lease accounting standard. The operating lease arrangements entered into prior to January 1, 2019 are non-cancelable, and most automatically renew for successive one year periods at the end of each lease term absent written notice from the customer.

[0000926326-20-000010:mdna:61]
For operating leases, rental income is generally recognized on a straight-line basis over the term of the associated lease, and recorded in services and other revenues in the Consolidated Statements of Operations. Leased assets under operating leases are carried at amortized cost net of accumulated depreciation in property and equipment, net on the Consolidated Balance Sheets. The depreciation expense of the leased assets is recognized on a straight-line basis over the contractual term of the associated lease, and recorded in cost of revenues in the Consolidated Statements of Operations.

[0000926326-20-000010:mdna:62]
Allowance for Doubtful Accounts and Notes Receivables from Investment in Sales-Type Leases

[0000926326-20-000010:mdna:63]
We maintain an allowance for doubtful accounts for estimated losses resulting from the inability of our customers to make required payments. We record a specific allowance based on an analysis of individual past-due balances. Additionally, based on historical write-offs and our collection experience, we record an additional allowance based on a percentage of outstanding receivables. We perform credit evaluations of our customers’ financial condition. These evaluations require significant judgment and are based on a variety of factors including, but not limited to, current economic trends, payment history, and a financial review of the customer. Actual collection losses may differ from management’s estimates, and such differences could be material to our financial position and results of operations.

[0000926326-20-000010:mdna:64]
The retained in-house leases discussed above are considered financing receivables. Our credit policies and our evaluation of credit risk and write-off policies are applied alike to trade receivables and the net investment in sales-type leases. For both, an account is generally past due after thirty days. The financing receivables also have customer-specific reserves for accounts identified for specific impairment and a non-specific reserve applied to the remaining population, based on factors such as current trends, the length of time the receivables are past due and historical collection experience. The retained in-house leases are not stratified by portfolio or class.

[0000926326-20-000010:mdna:65]
Inventory

[0000926326-20-000010:mdna:66]
Inventories are stated at the lower of cost, computed using the first-in, first-out method, and net realizable value. Inbound shipping costs are included in cost of inventory. We regularly monitor inventory quantities on hand and record write-downs for excess and obsolete inventories based on our estimate of demand for our products, potential obsolescence of technology, product life cycles, and whether pricing trends or forecasts indicate that the carrying value of inventory exceeds its estimated selling price. These factors are impacted by market and economic conditions, technology changes, and new product introductions and require estimates that may include elements that are uncertain. Actual demand may differ from forecasted demand and may have a material effect on gross margins. If inventory is written down, a new cost basis is established that

[0000926326-20-000010:mdna:67]
cannot be increased in future periods. Shipments from suppliers or contract manufacturers before we receive them are recorded as in-transit inventory when title and the significant risks and rewards of ownership have passed to us.

[0000926326-20-000010:mdna:68]
Software Development Costs

[0000926326-20-000010:mdna:69]
We capitalize software development costs in accordance with Accounting Standards Codification (“ASC”) 985-20, Costs of Software to Be Sold, Leased, or Marketed, under which certain software development costs incurred subsequent to the establishment of technological feasibility may be capitalized and amortized over the estimated lives of the related products. We establish technological feasibility when we complete a detail program design or a working model. We amortize development costs over the estimated lives of the related products ranging from three to five years. All development costs prior to the completion of a detail program design or a working model are recognized as research and development expense.

[0000926326-20-000010:mdna:70]
Lessee Leases

[0000926326-20-000010:mdna:71]
We determine if an arrangement is a lease at inception. Operating lease right-of-use assets and liabilities are recognized at the commencement date based on the present value of lease payments over the lease term. As most of our lease contracts do not provide an implicit rate, we use our incremental borrowing rate based on information available at the commencement date in determining the present value of the lease payments.

[0000926326-20-000010:mdna:72]
Many of our operating leases include an option to extend the lease. The specific terms and conditions of the extension options vary from lease to lease, but are consistent with standard industry practices in each area that we operate. We review each of our lease options at a time required by the terms of the lease contract, and notify the lessor if we choose to exercise the lease renewal option. Until we are reasonably certain that we will extend the lease contract, the renewal option periods will not be recognized as right-of-use assets or lease liabilities.

[0000926326-20-000010:mdna:73]
Certain leases include provisions for early termination, which allow the contract parties to terminate their obligations under the lease contract. The terms and conditions of the termination options vary by contract. When we have made a decision to exercise an early termination option, the right-of-use assets and associated lease liabilities are remeasured in accordance with the present value of the remaining cash flows under the lease contract.

[0000926326-20-000010:mdna:74]
Certain building lease agreements include rental payments subject to change annually based on fluctuations in various indexes (i.e. Consumer Price Index (“CPI”), Retail Price Index, and other international indexes). Certain data center lease agreements include rental payments subject to change based on usage and CPI fluctuations. The changes based on usage and indexes are treated as variable lease costs and recognized in the period in which the obligation for those payments was incurred.

[0000926326-20-000010:mdna:75]
Goodwill and Acquired Intangible Assets

[0000926326-20-000010:mdna:76]
Goodwill

[0000926326-20-000010:mdna:77]
We review goodwill for impairment on an annual basis on the first day of the fourth quarter of each year at the reporting unit level. This assessment is also performed whenever there is a change in circumstances that indicates the carrying value of goodwill may be impaired. We have one reporting unit, which is the same as our operating segment. A qualitative assessment is initially made to determine whether it is necessary to perform quantitative testing. A qualitative assessment includes, among others, consideration of: (i) past, current, and projected future earnings and equity; (ii) recent trends and market conditions; and (iii) valuation metrics involving similar companies that are publicly-traded and acquisitions of similar companies, if available. If this qualitative assessment indicates that it is more likely than not that impairment exists, or if we decide to bypass this option, we proceed to the quantitative assessment. The quantitative assessment involves a comparison between the estimated fair value of our reporting unit with its carrying amount including goodwill. If the carrying value exceeds estimated fair value, we will record an impairment charge based on that difference. The impairment charge will be limited to the amount of goodwill.

[0000926326-20-000010:mdna:78]
To determine the reporting unit’s fair value under the quantitative approach, we use a combination of income and market approaches, equally weighting the two approaches, such as estimated discounted future cash flows of the reporting unit, multiples of earnings or revenues, and analysis of recent sales or offerings of comparable entities. We also consider our market capitalization on the date of the analysis to ensure the reasonableness of our reporting unit's fair value.

[0000926326-20-000010:mdna:79]
Intangible Assets

[0000926326-20-000010:mdna:80]
In connection with our acquisitions, we generally recognize assets for customer relationships, backlog, developed technology, and trade names. Intangible assets are carried at cost less accumulated amortization. Such amortization is provided on a straight-line basis or on an accelerated basis based on a pattern of economic benefit that is expected to be obtained over the estimated useful lives of the respective assets, generally from one to 30 years. Amortization for developed technology and

[0000926326-20-000010:mdna:81]
backlog is recognized in cost of revenues, and amortization for customer relationships, non-compete agreements, trade names, and patents is recognized in selling, general, and administrative expenses.

[0000926326-20-000010:mdna:82]
We assess the impairment of identifiable intangible assets whenever events or changes in circumstances indicate that an asset’s carrying amount may not be recoverable. Recoverability of an asset is measured by the comparison of the carrying amount to the sum of the undiscounted estimated future cash flows the asset is expected to generate, offset by estimated future costs to dispose of the product to which the asset relates. If an asset is considered to be impaired, the amount of such impairment would be measured as the difference between the carrying amount of the asset and its fair value. Our cash flow assumptions are based on historical and forecasted future revenue, operating costs, and other relevant factors. Assumptions and estimates about the remaining useful lives of our intangible assets are subjective and are affected by changes to our business strategies. If management’s estimates of future operating results change, or if there are changes to other assumptions, the estimate of the fair value of our assets could change significantly. Such change could result in impairment charges in future periods, which could have a significant impact on our operating results and financial condition.

[0000926326-20-000010:mdna:83]
Valuation of Share-Based Compensation

[0000926326-20-000010:mdna:84]
We account for share-based compensation in accordance with ASC 718, Stock Compensation. We recognize compensation expense related to share-based compensation based on the grant date estimated fair value.

[0000926326-20-000010:mdna:85]
The fair value of stock options (“options”) on the grant date is estimated using the Black-Scholes option pricing model, which requires the following inputs: expected life, expected volatility, risk-free interest rate, expected dividend yield rate, exercise price, and closing price of our common stock on the date of grant. The expected volatility is based on a combination of historical and market-based implied volatility, and the expected life of the awards is based on our historical experience of employee stock option exercises, including forfeitures. Expense is recognized on a straight-line basis over the requisite service period.

[0000926326-20-000010:mdna:86]
The fair value of restricted stock units (“RSUs”) is based on the stock price on the grant date. The fair value of restricted stock awards (“RSAs”) is their intrinsic value, which is the difference between the fair value of the underlying stock at the measurement date and the purchase price. The RSUs and RSAs are subject to a service vesting condition and are recognized on a straight-line basis over the requisite service period.

[0000926326-20-000010:mdna:87]
The fair value of performance-based stock unit awards (“PSUs”) with service and market conditions is estimated using a Monte Carlo simulation model applying multiple awards approach. Expense is recognized when it is probable that the performance condition will be met using the accelerated attribution method over the requisite service period.

[0000926326-20-000010:mdna:88]
The valuation assumptions used in estimating the fair value of employee share-based awards may change in future periods.

[0000926326-20-000010:mdna:89]
Accounting for Income Taxes

[0000926326-20-000010:mdna:90]
We record an income tax provision for (benefit from) the anticipated tax consequences of the reported results of operations. In accordance with U.S. GAAP, the provision for (benefit from) income taxes is computed using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been included in the financial statements. Under this method, deferred tax assets and liabilities are determined on the basis of the differences between the financial statement and tax bases of assets and liabilities, and for operating losses and tax credit carryforwards. Deferred tax assets and liabilities are measured using the enacted tax rates in effect for the periods in which those tax assets and liabilities are expected to be realized or settled. In the event that these tax rates change, we will incur a benefit or detriment on our income tax expense in the period of change. If we were to determine that all or part of the net deferred tax assets are not realizable in the future, we will record a valuation allowance that would be charged to earnings in the period such determination is made.

[0000926326-20-000010:mdna:91]
In accordance with ASC 740, Income Taxes, we recognize the tax benefit from an uncertain tax position if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement. The calculation of tax liabilities involves significant judgment in estimating the impact of uncertainties in the application of U.S. GAAP and complex tax laws. Resolution of these uncertainties in a manner inconsistent with management’s expectations could have a material impact on our financial condition and operating results.

[0000926326-20-000010:mdna:92]
Recently Issued Authoritative Guidance

[0000926326-20-000010:mdna:93]
Refer to Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to Consolidated Financial Statements in this annual report for a description of recently issued accounting pronouncements, including the expected dates of adoption and estimated effects on our results of operations, financial position, and cash flows.

[0000926326-20-000010:mdna:94]
RESULTS OF OPERATIONS

[0000926326-20-000010:mdna:95]
Total Revenues

[0000926326-20-000010:mdna:96]
|  | Year Ended December 31, |  |  |  | Change in |  |  |  |  |  |  |  |  |
|  | 2019 |  | 2018 |  | $ |  | % |  |  |  |  |  |  |
|  | (Dollars in thousands) |  |  |  |  |  |  |  |  |  |  |  |  |
| Product revenues | $ | 659,602 |  |  | $ | 569,595 |  |  | $ | 90,007 |  |  | 16% |  |  |  |  |  |  |  |
| Percentage of total revenues | 74% |  |  | 72% |  |  |  |  |  |  |  |  |  |  |  |
| Services and other revenues | 237,425 |  |  | 217,714 |  |  | 19,711 |  |  | 9% |  |  |  |  |  |  |  |
| Percentage of total revenues | 26% |  |  | 28% |  |  |  |  |  |  |  |  |  |  |  |
| Total revenues | $ | 897,027 |  |  | $ | 787,309 |  |  | $ | 109,718 |  |  | 14% |  |  |  |  |  |  |  |

[0000926326-20-000010:mdna:97]
Product revenues represented 74% and 72% of total revenues for the years ended December 31, 2019 and 2018, respectively. Product revenues increased by $90.0 million, driven primarily by the growth of XT Series automated dispensing systems and to a lesser extent the growth of XR2 Automated Central Pharmacy system, partially offset by a decrease in revenues of Performance Center primarily due to a large installation during the year ended December 31, 2018.

[0000926326-20-000010:mdna:98]
Services and other revenues represented 26% and 28% of total revenues for the years ended December 31, 2019 and 2018, respectively. Services and other revenues include revenues from service and maintenance contracts, and rentals of automation systems. Services and other revenues increased by $19.7 million, primarily due to an increase in our installed customer base, as well as an increase in revenues from Population Health Solutions, Performance Center, and subscription-based leasing arrangements for robotic equipment.

[0000926326-20-000010:mdna:99]
Our international sales represented 10% and 13% of total revenues for the years ended December 31, 2019 and 2018, respectively. We expect our international sales to be affected by foreign currency exchange rate fluctuations. We are unable to predict the extent to which revenues in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-20-000010:mdna:100]
Our ability to continue to grow revenues is dependent on our ability to continue to obtain orders from customers, our ability to produce quality products and consumables to fulfill customer demand, the volume of installations we are able to complete, our ability to meet customer needs by providing a quality installation experience, and our flexibility in manpower allocations among customers to complete installations on a timely basis. The timing of our product revenues for equipment is primarily dependent on when our customers’ schedules allow for installations.

[0000926326-20-000010:mdna:101]
Cost of Revenues and Gross Profit

[0000926326-20-000010:mdna:102]
Cost of revenues is primarily comprised of three general categories: (i) standard product costs which accounts for the majority of the product cost of revenues that are provided to customers, and are inclusive of purchased material, labor to build the product and overhead costs associated with production; (ii) installation costs as we install our equipment at the customer site and include costs of the field installation personnel, including labor, travel expense, and other expenses; and (iii) other costs, including variances in standard costs and overhead, scrap costs, rework, warranty, provisions for excess and obsolete inventory, and amortization of software development costs and intangibles.

[0000926326-20-000010:mdna:103]
|  | Year Ended December 31, |  |  |  | Change in |  |  |  |  |  |  |  |  |
|  | 2019 |  | 2018 |  | $ |  | % |  |  |  |  |  |  |
|  | (Dollars in thousands) |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product revenues | $ | 344,914 |  |  | $ | 312,360 |  |  | $ | 32,554 |  |  | 10% |  |  |  |  |  |  |  |
| As a percentage of related revenues | 52% |  |  | 55% |  |  |  |  |  |  |  |  |  |  |  |
| Cost of services and other revenues | 115,201 |  |  | 102,619 |  |  | 12,582 |  |  | 12% |  |  |  |  |  |  |  |
| As a percentage of related revenues | 49% |  |  | 47% |  |  |  |  |  |  |  |  |  |  |  |
| Total cost of revenues | $ | 460,115 |  |  | $ | 414,979 |  |  | $ | 45,136 |  |  | 11% |  |  |  |  |  |  |  |
| As a percentage of total revenues | 51% |  |  | 53% |  |  |  |  |  |  |  |  |  |  |  |
| Gross profit | $ | 436,912 |  |  | $ | 372,330 |  |  | $ | 64,582 |  |  | 17% |  |  |  |  |  |  |  |
| Gross margin | 49% |  |  | 47% |  |  |  |  |  |  |  |  |  |  |  |

[0000926326-20-000010:mdna:104]
Cost of revenues for the year ended December 31, 2019 compared to the year ended December 31, 2018 increased by $45.1 million, of which $32.6 million was attributed to the increase in cost of product revenues and $12.6 million was attributed to the increase in cost of services and other revenues. The increase in cost of product revenues was primarily driven by the increase in product revenues of $90.0 million for the year ended December 31, 2019 compared to the year ended December 31, 2018, partially offset by sales of product portfolios with higher margins as well as lower costs associated with the XT Series manufacturing ramp up and economies of scale. The increase in cost of services and other revenues was primarily driven by increase in services and other revenues of $19.7 million for the year ended December 31, 2019 compared to the year ended December 31, 2018, as well as product mix with lower margins and investments to support new products.

[0000926326-20-000010:mdna:105]
The overall increase in gross margin primarily relates to lower costs associated with the XT Series manufacturing ramp up and economies of scale. Our gross profit for the year ended December 31, 2019 was $436.9 million compared to $372.3 million for the year ended December 31, 2018.

[0000926326-20-000010:mdna:106]
Operating Expenses and Interest and Other Income (Expense), Net

[0000926326-20-000010:mdna:107]
|  | Year Ended December 31, |  |  |  | Change in |  |  |  |  |  |  |  |  |  |  |
|  | 2019 |  | 2018 |  | $ |  | % |  |  |  |  |  |  |  |  |
|  | (Dollars in thousands) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 68,644 |  |  | $ | 64,843 |  |  | $ | 3,801 |  |  | 6% |  |  |  |  |  |  |  |  |  |
| As a percentage of total revenues | 8% |  |  | 8% |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | 289,916 |  |  | 263,095 |  |  | 26,821 |  |  | 10% |  |  |  |  |  |  |  |  |  |
| As a percentage of total revenues | 32% |  |  | 33% |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total operating expenses | $ | 358,560 |  |  | $ | 327,938 |  |  | $ | 30,622 |  |  | 9% |  |  |  |  |  |  |  |  |  |
| As a percentage of total revenues | 40% |  |  | 42% |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other income (expense), net | $ | (4,419) |  |  | $ | (8,776) |  |  | $ | 4,357 |  |  | (50)% |  |  |  |  |  |  |  |  |  |

[0000926326-20-000010:mdna:108]
Research and Development. Research and development expenses increased by $3.8 million for the year ended December 31, 2019 compared to the year ended December 31, 2018. The increase was primarily attributed to increases in consulting expenses and higher headcount in the research and development function, offset by higher capitalized software. The increased spend is a result of our continued investments into automation, intelligence, and the cloud data platform.

[0000926326-20-000010:mdna:109]
Selling, General, and Administrative. Selling, general, and administrative expenses increased $26.8 million for the year ended December 31, 2019 compared to the year ended December 31, 2018, due to overall growth of operations and increase in overall headcount. The increase is primarily due to an increase of $11.8 million in employee-related expenses primarily related to increased headcount, an increase of $5.5 million in consulting expenses, and an increase of $3.3 million in commissions expense primarily related to increased bookings. The increase is also driven by out-of-period adjustments of $2.6 million that reduced selling, general, and administrative expenses for the year ended December 31, 2018, as discussed in our annual report on Form 10-K for the year ended December 31, 2018 filed with the SEC on February 27, 2019. The increases are partially offset by $3.6 million related to realignment initiatives during the year ended December 31, 2018.

[0000926326-20-000010:mdna:110]
43

[0000926326-20-000010:mdna:111]
Interest and Other Income (Expense), Net. Interest and other income (expense), net, decreased by $4.4 million for the year ended December 31, 2019 compared to the year ended December 31, 2018, primarily driven by a $5.5 million decrease in other expenses, partially offset by a $1.1 million decrease in other income. The decrease in other expenses is primarily due to lower interest expense as a result of significant debt repayments during the year ended December 31, 2019, as well as favorable foreign currency fluctuations during the period. The decrease in other income is primarily due to the $2.5 million contingent gain recognized during the year ended December 31, 2018 related to a settlement agreement associated with the Ateb acquisition, partially offset by higher interest income received due to higher cash balances we maintained during 2019.

[0000926326-20-000010:mdna:112]
Provision for (Benefit from) Income Taxes

[0000926326-20-000010:mdna:113]
|  | Year Ended December 31, |  |  |  | Change in |  |  |  |  |  |  |  |  |
|  | 2019 |  | 2018 |  | $ |  | % |  |  |  |  |  |  |
|  | (Dollars in thousands) |  |  |  |  |  |  |  |  |  |  |  |  |
| Provision for (benefit from) income taxes | $ | 12,595 |  |  | $ | (2,113) |  |  | $ | 14,708 |  |  | (696)% |  |  |  |  |  |  |  |
| Effective tax rate on earnings | 17% |  |  | (6)% |  |  |  |  |  |  |  |  |  |  |  |

[0000926326-20-000010:mdna:114]
We recorded a provision for income taxes of $12.6 million and had an effective tax rate of 17% for the year ended December 31, 2019 compared to an income tax benefit of $2.1 million and had a negative effective tax rate of 6% for the year ended December 31, 2018. The 2019 annual effective tax rate differed from the statutory tax rate of 21%, primarily due to a favorable impact from the excess tax benefit from equity-based compensation and favorable impact of research and development credits. The increase in the annual effective tax rate in 2019 as compared to 2018 was primarily due to the increase in the our earnings and the impact of the internal legal entity restructuring.

[0000926326-20-000010:mdna:115]
Refer to Note 16, Income Taxes, of the Notes to Consolidated Financial Statements included in this annual report for more details.

[0000926326-20-000010:mdna:116]
LIQUIDITY AND CAPITAL RESOURCES

[0000926326-20-000010:mdna:117]
We had cash and cash equivalents of $127.2 million at December 31, 2019, compared to $67.2 million at December 31, 2018. All of our cash and cash equivalents are invested in bank accounts with major financial institutions.

[0000926326-20-000010:mdna:118]
Our cash position and working capital at December 31, 2019 and 2018 were as follows:

[0000926326-20-000010:mdna:119]
|  | December 31, |  |  |
|  | 2019 |  | 2018 |
|  | (In thousands) |  |  |
| Cash | $ | 127,210 |  |  | $ | 67,192 |  |
| Working Capital | $ | 246,242 |  |  | $ | 192,554 |  |

[0000926326-20-000010:mdna:120]
Our ratio of current assets to current liabilities was 2.0:1 at December 31, 2019 and 1.9:1 at December 31, 2018.

[0000926326-20-000010:mdna:121]
Sources of Cash

[0000926326-20-000010:mdna:122]
Credit Agreements

[0000926326-20-000010:mdna:123]
On January 5, 2016, we entered into a $400.0 million senior secured credit facility pursuant to a credit agreement with certain lenders, Wells Fargo Securities, LLC as sole lead arranger, and Wells Fargo Bank, National Association, as administrative agent (as subsequently amended as discussed below, the “Prior Credit Agreement”). The Prior Credit Agreement provided for a $200.0 million term loan facility (the “Prior Term Loan Facility”), and prior to the amendment discussed below, a $200.0 million revolving credit facility (the “Prior Revolving Credit Facility” and together with the Prior Term Loan Facility, the “Prior Facilities”). In addition, the Prior Credit Agreement included a letter of credit sub-limit of up to $10.0 million and a swing line loan sub-limit of up to $10.0 million.

[0000926326-20-000010:mdna:124]
On April 11, 2017 and December 26, 2017, we entered into amendments to the Prior Credit Agreement. Under these amendments, the Prior Revolving Credit Facility was increased from $200.0 million to $315.0 million and certain other modifications were made.

[0000926326-20-000010:mdna:125]
On November 15, 2019, we refinanced the Prior Credit Agreement and entered into an Amended and Restated Credit Agreement (the “A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers and Wells Fargo Bank, National Association, as administrative agent. The A&R Credit Agreement replaced the Prior Credit Agreement and provides for (a) a five-year

[0000926326-20-000010:mdna:126]
revolving credit facility of $500.0 million (the “Current Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million. In addition, the A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. On November 15, 2019, the $80.0 million outstanding term loan balance under the Prior Facilities was transferred to the Current Revolving Credit Facility.

[0000926326-20-000010:mdna:127]
As of December 31, 2019, the outstanding balance of the Current Revolving Credit Facility was $50.0 million and we were in full compliance with all covenants. Refer to Note 9, Debt and Credit Agreements, of the Notes to Consolidated Financial Statements included in this annual report. We expect to use future loans under the Current Revolving Credit Facility, if any, for working capital, potential acquisitions, and other general corporate purposes.

[0000926326-20-000010:mdna:128]
Distribution Agreement

[0000926326-20-000010:mdna:129]
On November 3, 2017, we entered into a Distribution Agreement (the “Distribution Agreement”) with J.P. Morgan Securities LLC, Wells Fargo Securities, LLC, and HSBC Securities (USA) Inc., as our sales agents, pursuant to which we may offer and sell from time to time through the sales agents up to $125.0 million maximum aggregate offering price of our common stock. Sales of the common stock pursuant to the Distribution Agreement may be made in negotiated transactions or transactions that are deemed to be “at the market” offerings as defined in Rule 415 under the Securities Act of 1933, including sales made directly on the Nasdaq Stock Market, or sales made to or through a market maker other than on an exchange. We intend to use the net proceeds from the sale, if any, of common stock in the offering for general corporate purposes, which may include, without limitation, the acquisition of complementary businesses, the repayment of outstanding indebtedness, capital expenditures and working capital.

[0000926326-20-000010:mdna:130]
For the year ended December 31, 2018, we received gross proceeds of $40.3 million from sales of our common stock under the Distribution Agreement and incurred issuance costs of $0.7 million on sales of approximately 557,000 shares of our common stock at an average price of approximately $72.40 per share.

[0000926326-20-000010:mdna:131]
For the year ended December 31, 2019, we received gross proceeds of $38.5 million from sales of our common stock under the Distribution Agreement and incurred issuance costs of $0.7 million on sales of approximately 460,000 shares of our common stock at an average price of approximately $83.81 per share. As of December 31, 2019, we had an aggregate of $31.5 million available to be offered under the Distribution Agreement.

[0000926326-20-000010:mdna:132]
Uses of Cash

[0000926326-20-000010:mdna:133]
Our future uses of cash are expected to be primarily for working capital, capital expenditures, loan principal and interest payments, and other contractual obligations. We also expect a continued use of cash for potential acquisitions and acquisition-related activities.

[0000926326-20-000010:mdna:134]
Our stock repurchase programs have a total of $54.9 million remaining for future repurchases as of December 31, 2019, which may result in additional use of cash. Refer to Note 14, Stock Repurchase Program, of the Notes to Consolidated Financial Statements included in this annual report. There were no stock repurchases during the years ended December 31, 2019 and 2018.

[0000926326-20-000010:mdna:135]
Based on our current business plan and revenue backlog, we believe that our existing cash and cash equivalents, our anticipated cash flows from operations, cash generated from the exercise of employee stock options and purchases under our employee stock purchase plan, along with the availability of funds under the Current Revolving Credit Facility will be sufficient to meet our cash needs for working capital, capital expenditures, potential acquisitions, and other contractual obligations for at least the next twelve months. For periods beyond the next twelve months, we also anticipate that our net operating cash flows plus existing balances of cash and cash equivalents will suffice to fund the continued growth of our business.

[0000926326-20-000010:mdna:136]
Cash Flows

[0000926326-20-000010:mdna:137]
The following table summarizes, for the periods indicated, selected items in our Consolidated Statements of Cash Flows:

[0000926326-20-000010:mdna:138]
|  | Year Ended December 31, |  |  |  |  |
|  | 2019 |  | 2018 |  |  |
|  | (In thousands) |  |  |  |  |
| Net cash provided by (used in): |  |  |  |  |  |
| Operating activities | $ | 145,008 |  |  | $ | 103,966 |  |  |  |
| Investing activities | (61,664) |  |  | (54,374) |  |  |  |
| Financing activities | (23,479) |  |  | (13,597) |  |  |  |
| Effect of exchange rate changes on cash and cash equivalents | 153 |  |  | (1,227) |  |  |  |
| Net increase in cash and cash equivalents | $ | 60,018 |  |  | $ | 34,768 |  |  |  |

[0000926326-20-000010:mdna:139]
Operating Activities

[0000926326-20-000010:mdna:140]
We expect cash from our operating activities to fluctuate in future periods as a result of a number of factors, including the timing of our billings and collections, our operating results and the timing of other liability payments.

[0000926326-20-000010:mdna:141]
Net cash provided by operating activities was $145.0 million for 2019, primarily consisting of net income of $61.3 million adjusted for non-cash items of $99.5 million offset by changes in assets and liabilities of $15.8 million. The non-cash items primarily consisted of depreciation and amortization expense of $53.6 million, share-based compensation expense of $34.0 million, amortization of operating lease right-of-use assets of $10.6 million, amortization of debt issuance costs of $2.2 million, and a change in deferred income taxes of $1.3 million. Changes in assets and liabilities include cash outflows from (i) an increase in accounts receivable and unbilled receivables of $21.5 million due to increased billings and the timing of billings and collections, (ii) a decrease in operating lease liabilities of $10.0 million, (iii) an increase in inventories of $8.1 million for inventory buildup in support of forecasted sales, (iv) an increase in investment in sales-type leases of $3.7 million, (v) an increase in prepaid commissions of $2.7 million, and (vi) an increase in other current assets of $2.0 million. These cash outflows were partially offset by (i) an increase in accounts payables of $7.9 million due to increased spending with vendors and increased consulting costs, (ii) an increase in other long-term liabilities of $6.0 million, (iii) an increase in deferred revenues of $5.4 million, (iv) a decrease in other long-term assets of $4.5 million, (v) an increase in accrued liabilities of $3.0 million, (vi) a decrease in prepaid expenses of $2.9 million, and (vii) an increase in accrued compensation of $2.5 million.

[0000926326-20-000010:mdna:142]
Net cash provided by operating activities was $104.0 million for 2018, primarily consisting of net income of $37.7 million adjusted for non-cash items of $77.0 million offset by changes in assets and liabilities of $10.7 million. The non-cash items primarily consisted of depreciation and amortization expense of $51.4 million, share-based compensation expense of $28.9 million, amortization of debt issuance costs of $2.3 million, and a change in deferred income taxes of $5.7 million. Changes in assets and liabilities include cash outflows from (i) a decrease in accounts payable of $9.2 million due to cash conservation efforts in 2017, which resulted in high payable balances, and timing of payments, (ii) an increase in other long-term assets of $7.1 million due to an increase in unbilled receivables, (iii) an increase in inventories of $6.8 million for inventory buildup in support of forecasted sales, (iv) an increase in accounts receivable and unbilled receivables of $6.2 million due to increased billings and the timing of billings and collections, and (v) an increase in prepaid commissions of $4.7 million due to an increase in bookings. These cash outflows were partially offset by an increase in accrued compensation of $14.4 million, an increase in other accrued liabilities of $8.2 million, and an increase in deferred revenues of $3.0 million due to the increased billings and the timing of orders and revenues being recognized for installed products.

[0000926326-20-000010:mdna:143]
Investing Activities

[0000926326-20-000010:mdna:144]
Net cash used in investing activities was $61.7 million for 2019, which consisted of capital expenditures of $15.9 million for property and equipment and $45.8 million for costs of software development for external use.

[0000926326-20-000010:mdna:145]
Net cash used in investing activities was $54.4 million for 2018, which consisted of capital expenditures of $23.7 million for property and equipment, and $30.7 million for costs of software development for external use.

[0000926326-20-000010:mdna:146]
Financing Activities

[0000926326-20-000010:mdna:147]
Net cash used in financing activities was $23.5 million for 2019, primarily due to the repayment of $90.0 million of the Prior Facilities and the Current Revolving Credit Facility, $9.7 million in employees’ taxes paid related to restricted stock unit vesting, and payments of debt issuance costs of $2.3 million, partially offset by $40.7 million in proceeds from employee

[0000926326-20-000010:mdna:148]
stock option exercises and employee stock plan purchases, and $37.8 million proceeds from sales of our common stock under the Distribution Agreement.

[0000926326-20-000010:mdna:149]
Net cash used in financing activities was $13.6 million for 2018, primarily due to the repayment of $77.0 million of the Prior Facilities and $6.8 million in employees’ taxes paid related to restricted stock unit vesting, partially offset by $30.6 million in proceeds from employee stock option exercises and employee stock plan purchases, and $39.6 million proceeds from sales of our common stock under the Distribution Agreement.

[0000926326-20-000010:mdna:150]
Contractual Obligations

[0000926326-20-000010:mdna:151]
Contractual obligations as of December 31, 2019 were as follows:

[0000926326-20-000010:mdna:152]
|  | Payments Due by Period |  |  |  |  |  |  |  |  |
|  | Total |  | 2020 |  | 2021 - 2022 |  | 2023-2024 |  | 2025 and thereafter |
|  | (In thousands) |  |  |  |  |  |  |  |  |  |
| Operating leases (1) | $ | 74,830 |  |  | $ | 13,573 |  |  | $ | 25,041 |  |  | $ | 16,448 |  |  | $ | 19,768 |  |
| Purchase obligations (2) | 65,913 |  |  | 63,804 |  |  | 1,821 |  |  | 233 |  |  | 55 |  |
| Revolving credit facility (3) | 50,000 |  |  | — |  |  | — |  |  | 50,000 |  |  | — |  |
| Total (4) | $ | 190,743 |  |  | $ | 77,377 |  |  | $ | 26,862 |  |  | $ | 66,681 |  |  | $ | 19,823 |  |

[0000926326-20-000010:mdna:153]
_________________________________________________

[0000926326-20-000010:mdna:154]
(1)Commitments under operating leases relate primarily to leased office buildings, data centers, office equipment, and vehicles. Refer to Note 11, Lessee Leases, of the Notes to Consolidated Financial Statements included in this annual report.

[0000926326-20-000010:mdna:155]
(2)We purchase components from a variety of suppliers and use contract manufacturers to provide manufacturing services for our products. During the normal course of business, we issue purchase orders with estimates of our requirements several months ahead of the delivery dates. These amounts are associated with agreements that are enforceable and legally binding. The amounts under such contracts are included in the table above because we believe that cancellation of these contracts is unlikely and we expect to make future cash payments according to the contract terms or in similar amounts for similar materials.

[0000926326-20-000010:mdna:156]
(3)Amounts shown for the revolving credit facility are principal repayments only. The cash interest expense payments are not reflected in the above table. Refer to Note 9, Debt and Credit Agreements, of the Notes to Consolidated Financial Statements included in this annual report.

[0000926326-20-000010:mdna:157]
(4)Refer to Note 12, Commitments and Contingencies, of the Notes to Consolidated Financial Statements included in this annual report.

[0000926326-20-000010:mdna:158]
Off-Balance Sheet Arrangements

[0000926326-20-000010:mdna:159]
As of December 31, 2019, we had no off-balance sheet arrangements as defined under Regulation S-K 303(a)(4) of the Exchange Act and the instructions thereto.
