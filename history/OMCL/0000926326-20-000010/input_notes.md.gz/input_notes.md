# OMCL notes — 0000926326-20-000010


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000926326-20-000010:notes:1]
Portions of the registrant’s definitive Proxy Statement for the 2020 Annual Meeting of Stockholders to be filed with the Securities and Exchange Commission pursuant to Regulation 14A not later than 120 days after the end of the fiscal year covered by this Form 10-K are incorporated by reference in Part III, Items 10-14 of this Form 10-K.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000926326-20-000010:notes:2]
Organization and Summary of Significant Accounting Policies
Business

[0000926326-20-000010:notes:3]
Omnicell, Inc. was incorporated in California in 1992 under the name Omnicell Technologies, Inc. and reincorporated in Delaware in 2001 as Omnicell, Inc. The Company’s major products are medication management automation solutions and adherence tools for healthcare systems and pharmacies, which are sold in its principal market, the healthcare industry. The Company’s market is primarily located in the United States and Europe. “Omnicell” or the “Company” collectively refer to Omnicell, Inc. and its subsidiaries.

[0000926326-20-000010:notes:4]
Basis of Presentation

[0000926326-20-000010:notes:5]
The accompanying Consolidated Financial Statements have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) and include all adjustments necessary for the fair presentation of the Company’s consolidated financial position, results of operations, and cash flows for the periods presented.

[0000926326-20-000010:notes:6]
During 2019, the Company completed a series of intercompany transactions in connection with an internal legal entity restructuring to simplify its organizational structure as described below.

[0000926326-20-000010:notes:7]
In November 2019, Aesynt Holding B.V. sold its shares in Aesynt Holdings, Inc. ("Aesynt Holdings") to Omnicell International, Inc. (which was subsequently converted into a limited liability company and renamed Omnicell International, LLC) ("Omnicell International"). Omnicell International subsequently distributed the Aesynt Holdings shares to its parent company, Omnicell, Inc. On December 31, 2019, the following series of mergers occurred: (i) Dixie Drawl, LLC d/b/a InPharmics ("InPharmics") merged with and into its parent company, Aesynt Incorporated ("Aesynt"), with Aesynt as the surviving entity; (ii) Aesynt merged with and into its parent company, Aesynt Holdings, with Aesynt Holdings as the surviving entity; and (iii) Aesynt Holdings merged with and into its parent company, Omnicell, Inc., with Omnicell, Inc. as the surviving entity.

[0000926326-20-000010:notes:8]
On November 25, 2019, Aesynt Canada, Inc. ("Aesynt Canada") entered into an asset purchase agreement with Omnicell, Inc., under which Omnicell, Inc. acquired all assets of Aesynt Canada. On November 29, 2019, Aesynt Canada liquidated into its parent company, Aruba S.r.l ("Aruba"). Prior to the liquidation, all liabilities of Aesynt Canada were settled.

[0000926326-20-000010:notes:9]
On November 21, 2019, Ateb Canada Ltd. ("Ateb Canada") entered into an asset purchase agreement with Ateb, Inc. ("Ateb"), under which Ateb acquired all assets of Ateb Canada. On November 25, 2019, Ateb Canada liquidated into its parent company, Omnicell, Inc. Prior to the liquidation, all liabilities of Ateb Canada were settled.

[0000926326-20-000010:notes:10]
The transactions described above were accounted for as transactions between entities under common control as all entities involved were wholly owned subsidiaries of Omnicell, Inc. The transactions did not have a material impact to the Company's Consolidated Financial Statements.

[0000926326-20-000010:notes:11]
Principles of Consolidation

[0000926326-20-000010:notes:12]
The Consolidated Financial Statements include the accounts of the Company and its wholly owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.

[0000926326-20-000010:notes:13]
On April 12, 2017, the Company completed its acquisition of InPharmics. The Consolidated Financial Statements include the results of operations of this recently acquired company, commencing as of its acquisition date. The significant accounting policies of the acquired business have been aligned to conform to the accounting policies of Omnicell.

[0000926326-20-000010:notes:14]
Reclassifications and Adjustments

[0000926326-20-000010:notes:15]
Certain prior-year amounts have been reclassified to conform with current-period presentation. These reclassifications include (i) a change in the presentation of proceeds from debt and revolving credit facility and payments for debt issuance costs in the Consolidated Statements of Cash Flows for the year ended December 31, 2017, and (ii) a change in the presentation of certain items in the reconciliation of the provision for income taxes for the years ended December 31, 2018 and 2017 in Note 16, Income Taxes, of the Notes to Consolidated Financial Statements. These changes were not deemed material and were included to conform with current-period classification and presentation.

[0000926326-20-000010:notes:16]
Use of Estimates

[0000926326-20-000010:notes:17]
The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s Consolidated Financial Statements and accompanying Notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. The Company’s critical accounting policies are those that affect its financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition; accounts receivable and notes receivable from investment in sales-type leases; operating lease right-of-use assets and liabilities; inventory valuation; capitalized software development costs; impairment of goodwill; purchased intangibles and long-lived assets; fair value of assets acquired and liabilities assumed in business combinations; share-based compensation; and accounting for income taxes.

[0000926326-20-000010:notes:18]
Segment Reporting

[0000926326-20-000010:notes:19]
The Company's Chief Operating Decision Maker ("CODM") is its Chief Executive Officer. The CODM allocates resources and evaluates the performance of the Company using information about its revenues, gross profit, income from operations, and other key financial data. The Company previously operated and reported its business in two segments: Automation and Analytics, and Medication Adherence. In the fourth quarter of 2018, the Company introduced the vision of the autonomous pharmacy, a more fully automated and digitized system of medication management, in order to address changes in the healthcare industry as the Company executes on its plan to deliver end-to-end solutions with greater emphasis on automating manual processes for its customers. These industry changes include the continuing consolidation of healthcare systems, rising pharmaceutical costs, and increased scrutiny on controlled substances. In an effort to deliver on its strategic vision, the Company initiated a company-wide organizational realignment in the fourth quarter of 2018 to centrally manage its business operations, including the development and marketing of all of the Company’s products, sales and distribution, supply chain and inventory management, as well as regulatory and quality functions. As a result of this organizational realignment, all significant operating decisions are based upon an analysis of the Company as one operating segment. Therefore, effective January 1, 2019, the Company started reporting as only one operating segment, which is the same as the reporting segment. Accordingly, prior period segment information has been revised to conform with current period presentation.

[0000926326-20-000010:notes:20]
Foreign Currency Translation and Remeasurement

[0000926326-20-000010:notes:21]
Most of the Company’s foreign subsidiaries use the local currency of their respective countries as their functional currency. The Company translates the assets and liabilities of such non-U.S. dollar functional currency subsidiaries into U.S. dollars using exchange rates in effect at the end of each period. Revenue and expenses for these subsidiaries are translated using rates that approximate those in effect during the period. Gains and losses from these translations are recorded as foreign currency translation adjustments and included in accumulated other comprehensive income (loss) in stockholders’ equity.

[0000926326-20-000010:notes:22]
Assets and liabilities denominated in a currency other than the functional currency are remeasured into the respective entity’s functional currency. Monetary assets and liabilities are remeasured at exchange rates in effect at the end of each period, and non-monetary assets and liabilities are remeasured at historical rates. Gains and losses from foreign currency remeasurement of monetary assets and liabilities are recorded in interest and other income (expense), net.

[0000926326-20-000010:notes:23]
Revenue Recognition

[0000926326-20-000010:notes:24]
The Company earns revenues from sales of its products and related services, which are sold in the healthcare industry, its principal market. The transaction price of each contract with a customer is allocated to the identified performance obligations based on the relative fair value of each obligation. The Company’s customer arrangements typically include one or more of the following performance obligations:

[0000926326-20-000010:notes:25]
Products. Software-enabled equipment that manages and regulates the storage and dispensing of pharmaceuticals, consumable blister cards and packaging equipment and other medical supplies.

[0000926326-20-000010:notes:26]
Software. Additional software applications that enable incremental functionality of the Company’s equipment or services.

[0000926326-20-000010:notes:27]
Installation. Installation of equipment as integrated systems at customer sites.

[0000926326-20-000010:notes:28]
Post-installation technical support. Phone support, on-site service, parts, and access to unspecified software updates and enhancements, if and when available.

[0000926326-20-000010:notes:29]
Professional services. Other customer services, such as training and consulting.

[0000926326-20-000010:notes:30]
Prior to recognizing revenue, the Company identifies the contract, performance obligations, and transaction price, and allocates the transaction price to the performance obligations. All identified contracts meet the following required criteria:

[0000926326-20-000010:notes:31]
Parties to the contract have approved the contract (in writing, orally, or in accordance with other customary business practices) and are committed to perform their respective obligations. A majority of the Company’s contracts are evidenced by a non-cancelable written agreement. Contracts for consumable products are generally evidenced by an order placed via phone or a manual purchase order.

[0000926326-20-000010:notes:32]
Entity can identify each party’s rights regarding the goods or services to be transferred. Contract terms are documented within the written agreements. Where a written contract does not exist, such as for consumable products, the rights of each party are understood as following the Company’s standard business process and terms.

[0000926326-20-000010:notes:33]
The entity can identify the payment terms for the goods or services to be transferred. Payment terms are documented within the agreement and are generally net 30 to 60 days from shipment of tangible product or services performed for customers in the United States. Where a written contract does not exist, the Company’s standard payment terms are net 30 day terms.

[0000926326-20-000010:notes:34]
The contract has commercial substance (that is the risk, timing, or amount of the entity’s future cash flows is expected to change as a result of the contract.) The Company’s agreements are an exchange of cash for a combination of products and services which result in changes in the amount of the Company’s future cash flows.

[0000926326-20-000010:notes:35]
It is probable the entity will collect the consideration to which it will be entitled in exchange for the goods or services that will be transferred to the customer. The Company performs a credit check for all significant customers or transactions and where collectability is not probable, payment in full or a substantial down payment is typically required to help assure the full agreed upon contract price will be collected.

[0000926326-20-000010:notes:36]
The Company often enters into change orders which modify the product to be received by the customer pursuant to certain contracts. Changes to any contract are accounted for as a modification of the existing contract to the extent the goods and services to be delivered as part of the contract are generally consistent with the nature and type of those to be provided under the terms of the original contract. Examples of such change orders include the addition or removal of units of equipment or changes to the configuration of the equipment where the overall nature of the contract remains intact. The Company’s change orders generally result in the change being accounted for as modifications of existing contracts given the nature of the impacted orders.

[0000926326-20-000010:notes:37]
Distinct goods or services are identified as performance obligations. A series of distinct goods or services that are substantially the same and that have the same pattern of transfer to the customer are considered a single performance obligation. Where a good or service is determined not to be distinct, the Company combines the good or service with other promised goods or services until a bundle of goods or services that is distinct is identified. To identify its performance obligations, the Company considers all of the products or services promised in the contract regardless of whether they are explicitly stated or are implied by customary business practices. When performance obligations are included in separate contracts, the Company considers an entire customer arrangement to determine if separate contracts should be considered combined for the purposes of revenue recognition. Most of the Company’s sales, other than renewals of support and maintenance, contain multiple performance obligations, with a combination of hardware systems, consumables and software products, support and maintenance, and professional services.

[0000926326-20-000010:notes:38]
The transaction price of a contract is determined based on the fixed consideration, net of an estimate for variable consideration such as various discounts or rebates provided to customers. As a result of the Company’s commercial selling practices, contract prices are generally fixed with minimal, if any, variable consideration.

[0000926326-20-000010:notes:39]
The transaction price is allocated to separate performance obligations proportionally based on the standalone selling price of each performance obligation. Standalone selling price is best evidenced by the price the Company charges for the good or service when selling it separately in similar circumstances to similar customers. Other than for the renewal of annual support services contracts, the Company’s products and services are not generally sold separately. The Company uses an amount discounted from the list price as a best estimated selling price.

[0000926326-20-000010:notes:40]
The Company recognizes revenue when the performance obligation has been satisfied by transferring a promised good or service to a customer. The good or service is transferred when or as the customer obtains control of the good or service. Determining when control transfers requires management to make judgments that affect the timing of revenues recognized. Generally, for products requiring a complex implementation, control passes when the product is installed and ready for use. For all other products, control generally passes when product has been shipped and title has passed. For maintenance contracts and certain other services provided on a subscription basis, control passes to the customer over time, generally ratably over the service term as the Company provides a stand-ready service to service the customer’s equipment. Time and material services

[0000926326-20-000010:notes:41]
transfer control to the customer at the time the services are provided. The portion of the transaction price allocated to the Company’s unsatisfied performance obligations recorded as deferred revenues, net of deferred cost of goods sold, at December 31, 2019 and 2018 were $98.0 million and $92.4 million, respectively, of which $90.9 million and $81.8 million, respectively, are expected to be completed within one year and are presented as current deferred revenues, net on the Consolidated Balance Sheets. Remaining performance obligations primarily relate to maintenance contracts and are recognized ratably over the remaining term of the contract, generally not more than five years.

[0000926326-20-000010:notes:42]
Revenues, contract assets, and contract liabilities are recorded net of associated taxes.

[0000926326-20-000010:notes:43]
The Company generally invoices customers for products upon shipment. Invoicing associated with the service portion of agreements are generally periodic and are billed on a monthly, quarterly, or annual basis. In certain circumstances, multiple years are billed at one time.

[0000926326-20-000010:notes:44]
The amount invoiced for equipment and software is typically reflected in both accounts receivable and deferred revenues, net. The Company typically recognizes product revenue, and correspondingly reduces deferred revenues, net, for equipment and software upon written customer acceptance of installation. Consumables are recorded as revenue upon shipment to or receipt by the customer, depending upon contract terms. The portion of deferred revenues, net, not expected to be recognized as revenue within twelve months of the balance sheet date are included in long-term deferred revenues on the Consolidated Balance Sheets.

[0000926326-20-000010:notes:45]
In the normal course of business, the Company typically does not accept product returns unless the item is defective as manufactured or the configuration of the product is incorrect. The Company establishes provisions for estimated returns based on historical product returns. The allowance for sales returns is not material to the Consolidated Financial Statements for any periods presented.

[0000926326-20-000010:notes:46]
The Company contracts with Group Purchasing Organizations (“GPOs”), each of which functions as a purchasing agent on behalf of member hospitals and other healthcare providers, as well as with government entities and agencies. Pursuant to the terms of GPO agreements, each member contracts directly with Omnicell and can purchase the Company’s product at pre-negotiated contract terms and pricing. GPOs are often owned fully or in part by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs were $11.1 million, $8.7 million, and $7.4 million for the years ended December 31, 2019, 2018, and 2017, respectively. The accounts receivable balances are with individual members of the GPOs, and therefore no significant concentration of credit risk exists. During the year ended December 31, 2019, sales to members of the ten largest GPOs accounted for approximately 64% of total consolidated revenues.

[0000926326-20-000010:notes:47]
Contract Assets and Contract Liabilities

[0000926326-20-000010:notes:48]
A contract asset is a right to consideration in exchange for goods or services that the Company has transferred to a customer when that right is conditional and is not just subject to the passage of time. A receivable will be recorded on the balance sheet when the Company has unconditional rights to consideration. A contract liability is an obligation to transfer goods or services for which the Company has received consideration, or for which an amount of consideration is due from the customer. Contract liabilities include customer deposits under non-cancelable contracts, and current and non-current deferred revenue balances. The Company’s contract balances are reported in a net contract asset or liability position on a contract-by-contract basis at the end of each reporting period.

[0000926326-20-000010:notes:49]
Significant changes in the contract assets and the contract liabilities balances during the period are the result of the issuance of invoices and recognition of deferred revenues in the normal course of business. Unbilled contract assets which were invoiced during the year ended December 31, 2019 as a result of the right to invoice for the transaction consideration becoming unconditional were not material. The contract modifications entered into during the year ended December 31, 2019 did not have a significant impact on the Company’s contract assets or deferred revenues.

[0000926326-20-000010:notes:50]
Contract Costs

[0000926326-20-000010:notes:51]
The Company has determined that the incentive portions of its sales commission plans require capitalization since these payments are directly related to sales achieved during a time period. These commissions are earned on the basis of the total purchase order value of new product bookings. Since there are no commensurate commissions earned on renewal of the service bookings, the Company concluded that the capitalized asset is related to services provided under both the initial contract and renewal periods. The Company applies a practical expedient to account for the incremental costs of obtaining a contract as part of a portfolio of contracts with similar characteristics as the Company expects the effect on the financial statements of applying the practical expedient would not differ materially from applying the accounting guidance to the individual contracts within the portfolio. A pool of contracts is defined as all contracts booked in a particular quarter. The amortization for the capitalized asset is an estimate of the pool’s original contract term, generally one to five years, plus an estimate of future

[0000926326-20-000010:notes:52]
customer renewal periods resulting in a total amortization period of ten years. Costs to obtain a contract are allocated amongst performance obligations and recognized as sales and marketing expense consistent with the pattern of revenue recognition. Capitalized costs are periodically reviewed for impairment. A portion of the pool’s capitalized asset is recorded as an expense over the first two quarters after booking, which represents the estimated period during which the product revenue associated with the contract is recorded. The remaining contract cost is recorded as expense ratably over the ten year estimated initial and renewal service periods. The Company recognized contract cost expense of $24.4 million, $21.1 million, and $17.9 million during the years ended December 31, 2019, 2018, and 2017, respectively. The commission expenses paid or due to be paid as of the consolidated balance sheet date to be recognized in future periods are recorded in long-term prepaid commissions on the Consolidated Balance Sheets. There was no impairment loss recorded related to capitalized prepaid commissions as of and for the year ended December 31, 2019.

[0000926326-20-000010:notes:53]
Lessor Leases

[0000926326-20-000010:notes:54]
The Company determines if an arrangement is a lease at inception. The transaction price is allocated to separate performance obligations, generally consisting of hardware and software products, installation, and post-installation technical support, proportionally based on the standalone selling price of each performance obligation. Standalone selling price is best evidenced by the price the Company charges for the good or service when selling it separately in similar circumstances to similar customers. Other than for the renewal of annual support services contracts, the Company’s products and services are not generally sold separately. The Company uses an amount discounted from the list price as a best estimated selling price.

[0000926326-20-000010:notes:55]
Sales-Type Leases

[0000926326-20-000010:notes:56]
The Company enters into non-cancelable sales-type lease arrangements, most of which do not have an option to extend the lease term. At the end of the lease term, the customer must either return the equipment or negotiate a new agreement, resulting in a new purchase or lease transaction. Failure of the customer to either return the equipment or negotiate a new agreement results in the contract becoming a month-to-month rental. Certain sales-type leases automatically renew for successive one year periods at the end of each lease term with written notice from the customer. The Company’s sales-type lease agreements do not contain any material residual value guarantees.

[0000926326-20-000010:notes:57]
For sales-type leases, the Company recognizes revenues for its hardware and software products, net of lease execution costs, post-installation product maintenance, and technical support, at the net present value of the lease payment stream upon customer acceptance. The Company recognizes service revenues associated with sales-type leases ratably over the term of the agreement in service revenues in the Consolidated Statements of Operations. The Company recognizes interest income from sales-type leases using the effective interest method. Both hardware and software revenues, and interest income from sales-types leases are recorded in product revenues in the Consolidated Statements of Operations.

[0000926326-20-000010:notes:58]
The Company optimizes cash flows by selling a majority of its non-U.S. government sales-type leases to third-party leasing finance companies on a non-recourse basis. The Company has no obligation to the leasing company once the lease has been sold. Some of the Company's sales-type leases, mostly those relating to U.S. government hospitals which comprise approximately 53% of the lease receivable balance, are retained in-house.

[0000926326-20-000010:notes:59]
Operating Leases

[0000926326-20-000010:notes:60]
The Company entered into certain leasing agreements that were classified as operating leases prior to the adoption of the new lease accounting standard. Those agreements in place prior to January 1, 2019 will continue to be treated as operating leases, however, any new leasing agreements entered into on or after January 1, 2019 under these programs are classified and accounted for as sales-type leases in accordance with the new lease accounting standard. The operating lease arrangements entered into prior to January 1, 2019 are non-cancelable, and most automatically renew for successive one year periods at the end of each lease term absent written notice from the customer. The Company’s operating lease agreements do not contain any material residual value guarantees.

[0000926326-20-000010:notes:61]
For operating leases, rental income is generally recognized on a straight-line basis over the term of the associated lease, and recorded in services and other revenues in the Consolidated Statements of Operations. Leased assets under operating leases are carried at amortized cost net of accumulated depreciation in property and equipment, net on the Consolidated Balance Sheets. The depreciation expense of the leased assets is recognized on a straight-line basis over the contractual term of the associated lease, and recorded in cost of revenues in the Consolidated Statements of Operations.

[0000926326-20-000010:notes:62]
Financial Instruments

[0000926326-20-000010:notes:63]
For assets and liabilities measured at fair value, the amounts are based on an expected exit price representing the amount that would be received from the sale of an asset or paid to transfer a liability in a transaction between market participants. The fair value may be based on assumptions that market participants would use in pricing an asset or liability. The

[0000926326-20-000010:notes:64]
authoritative guidance on fair value measurements establishes a consistent framework for measuring fair value on either a recurring or nonrecurring basis whereby inputs used in valuation techniques are assigned a hierarchical level. The following methods were used to estimate the fair value of each class of financial instruments for which it is practical to estimate that value:

[0000926326-20-000010:notes:65]
Cash and Cash Equivalents and Fair Value of Financial Instruments

[0000926326-20-000010:notes:66]
The Company classifies investments as cash equivalents if their original or remaining contractual maturity is three months or less at the date of purchase. Cash equivalents are carried at amounts that approximate fair value due to the short period of time to maturity. The Company’s cash balances are maintained in demand deposit accounts with financial institutions of high credit quality. The Company continuously monitors the credit worthiness of the financial institutions in which it invests. The Company has not experienced any credit losses from its cash investments.

[0000926326-20-000010:notes:67]
Interest Rate Swap Agreements

[0000926326-20-000010:notes:68]
The Company uses interest rate swap agreements to protect the Company against adverse fluctuations in interest rates by reducing its exposure to variability in cash flows relating to interest payments on a portion of its outstanding debt. The Company does not hold or issue any derivative financial instruments for speculative trading purposes.

[0000926326-20-000010:notes:69]
The Company's interest rate swap agreements qualify as cash flow hedging instruments in accordance with the Derivatives and Hedging topic of the Accounting Standards Codification. The Company records its interest rate swap agreements on its Consolidated Balance Sheets at fair value. The effective portion of changes in fair value are recorded in accumulated other comprehensive loss and subsequently reclassified into earnings in the period that the hedged forecasted transaction affects earnings. Any ineffective portion is recognized in earnings. On a quarterly basis, the Company performs a qualitative assessment to determine effectiveness. For further information, refer to Note 5, Cash and Cash Equivalents and Fair Value of Financial Instruments. As of December 31, 2019, the Company did not have any outstanding interest rate swap agreements.

[0000926326-20-000010:notes:70]
Debt

[0000926326-20-000010:notes:71]
On November 15, 2019, the Company entered into an amended and restated credit agreement which provides for a five-year revolving credit facility. The amount borrowed under this facility is recorded at its carrying value at December 31, 2019. The fair value of debt at December 31, 2019 approximates the carrying value.

[0000926326-20-000010:notes:72]
Allowance for Doubtful Accounts and Notes Receivables from Investment in Sales-Type Leases

[0000926326-20-000010:notes:73]
The Company maintains an allowance for doubtful accounts for estimated losses resulting from the inability of its customers to make required payments. The Company records a specific allowance based on an analysis of individual past-due balances. Additionally, based on historical write-offs and the Company’s collection experience, the Company records an additional allowance based on a percentage of outstanding receivables. The Company performs credit evaluations of its customers’ financial condition. These evaluations require significant judgment and are based on a variety of factors including, but not limited to, current economic trends, payment history, and a financial review of the customer. Actual collection losses may differ from management’s estimates, and such differences could be material to the Company’s financial position and results of operations.

[0000926326-20-000010:notes:74]
The retained in-house leases discussed above are considered financing receivables. The Company’s credit policies and its evaluation of credit risk and write-off policies are applied alike to trade receivables and the net investment in sales-type leases. For both, an account is generally past due after thirty days. The financing receivables also have customer-specific reserves for accounts identified for specific impairment and a non-specific reserve applied to the remaining population, based on factors such as current trends, the length of time the receivables are past due, and historical collection experience. The retained in-house leases are not stratified by portfolio or class.

[0000926326-20-000010:notes:75]
Sales of Accounts Receivable

[0000926326-20-000010:notes:76]
The Company records the sale of its accounts receivables in accordance with accounting guidance for transfers and servicing of financial assets. The Company transferred non-recourse accounts receivable totaling $48.3 million, $46.6 million, and $40.0 million during the years ended December 31, 2019, 2018, and 2017, respectively, which approximated fair value, to leasing companies on a non-recourse basis. Accounts receivable balance included approximately $4.6 million and $10.6 million due from third-party leasing companies for transferred non-recourse accounts receivable as of December 31, 2019 and 2018, respectively.

[0000926326-20-000010:notes:77]
Inventory

[0000926326-20-000010:notes:78]
Inventories are stated at the lower of cost, computed using the first-in, first-out method, and net realizable value. Inbound shipping costs are included in cost of inventory. The Company regularly monitors inventory quantities on hand and records write-downs for excess and obsolete inventories based on the Company’s estimate of demand for its products, potential obsolescence of technology, product life cycles, and whether pricing trends or forecasts indicate that the carrying value of inventory exceeds its estimated selling price. These factors are impacted by market and economic conditions, technology changes, and new product introductions and require estimates that may include elements that are uncertain. Actual demand may differ from forecasted demand and may have a material effect on gross margins. If inventory is written down, a new cost basis is established that cannot be increased in future periods. Shipments from suppliers or contract manufacturers before the Company receives them are recorded as in-transit inventory when title and the significant risks and rewards of ownership have passed to the Company.

[0000926326-20-000010:notes:79]
The Company has a supply agreement with one primary supplier for construction and supply of several sub-assemblies and inventory management of sub-assemblies used in its hardware products. There are no minimum purchase requirements. The contract with the Company’s supplier may be terminated by either the supplier or by the Company without cause and at any time upon delivery of six months’ notice. Purchases from this supplier were $75.1 million, $54.8 million, and $64.5 million for the years ended December 31, 2019, 2018, and 2017, respectively.

[0000926326-20-000010:notes:80]
Shipping Costs

[0000926326-20-000010:notes:81]
Outbound freight billed to customers is recorded as product revenue. The related shipping and handling costs are expensed as part of selling, general, and administrative expense. Shipping and handling expenses were $15.9 million, $14.1 million, and $13.6 million for the years ended December 31, 2019, 2018, and 2017, respectively.

[0000926326-20-000010:notes:82]
Property and Equipment

[0000926326-20-000010:notes:83]
Property and equipment less accumulated depreciation are stated at historical cost. The Company’s expenditures for property and equipment are primarily for computer equipment and software used in the administration of its business, and for leasehold improvements to its leased facilities. The Company also develops molds and dies used in long-term manufacturing arrangements with suppliers and for production automation equipment used in the manufacturing of consumable blister card components. Depreciation and amortization is computed by use of the straight-line method over the estimated useful lives of the assets as stated below:

[0000926326-20-000010:notes:84]
| Computer equipment and related software | 3 - 5 years |
| Leasehold and building improvements | Shorter of the lease term or the estimated useful life |
| Furniture and fixtures | 5 - 7 years |
| Equipment | 3 - 12 years |

[0000926326-20-000010:notes:85]
The Company capitalizes costs related to computer software developed or obtained for internal use in accordance with ASC 350-40, Internal-Use Software. Software obtained for internal use has generally been enterprise-level business and finance software that the Company customizes to meet its specific operational needs. Costs incurred in the application development phase are capitalized and amortized over their useful lives, which is generally five years. Costs recognized in the preliminary project phase and the post-implementation phase are expensed as incurred. The Company capitalized $0.3 million and $1.1 million of costs related to the application development of enterprise-level software that were included in property and equipment during the years ended December 31, 2019 and 2018, respectively.

[0000926326-20-000010:notes:86]
Software Development Costs

[0000926326-20-000010:notes:87]
The Company capitalizes software development costs in accordance with ASC 985-20, Costs of Software to Be Sold, Leased, or Marketed, under which certain software development costs incurred subsequent to the establishment of technological feasibility may be capitalized and amortized over the estimated lives of the related products. The Company establishes technological feasibility when it completes a detail program design or a working model. The Company amortizes development costs over the estimated lives of the related products ranging from three to five years. The Company capitalized software development costs of $45.8 million and $30.7 million, which are included in other long-term assets as of December 31, 2019 and 2018, respectively. The Company recorded $17.5 million, $12.5 million, and $9.7 million to cost of revenues for amortization of capitalized software development costs for the years ended December 31, 2019, 2018, and 2017, respectively. All development costs prior to the completion of a detail program design or a working model are recognized as research and development expense.

[0000926326-20-000010:notes:88]
Lessee Leases

[0000926326-20-000010:notes:89]
The Company determines if an arrangement is a lease at inception. Operating lease right-of-use assets and liabilities are recognized at the commencement date based on the present value of lease payments over the lease term. As most of its lease contracts do not provide an implicit rate, the Company uses its incremental borrowing rate based on information available at the commencement date in determining the present value of the lease payments.

[0000926326-20-000010:notes:90]
Many of the Company’s operating leases include an option to extend the lease. The specific terms and conditions of the extension options vary from lease to lease, but are consistent with standard industry practices in each area that the Company operates. The Company reviews each of its lease options at a time required by the terms of the lease contract, and notifies the lessor if it chooses to exercise the lease renewal option. Until the Company is reasonably certain that it will extend the lease contract, the renewal option periods will not be recognized as right-of-use assets or lease liabilities.

[0000926326-20-000010:notes:91]
Certain leases include provisions for early termination, which allow the contract parties to terminate their obligations under the lease contract. The terms and conditions of the termination options vary by contract. When the Company has made a decision to exercise an early termination option, the right-of-use assets and associated lease liabilities are remeasured in accordance with the present value of the remaining cash flows under the lease contract.

[0000926326-20-000010:notes:92]
Certain building lease agreements include rental payments subject to change annually based on fluctuations in various indexes (i.e. Consumer Price Index (“CPI”), Retail Price Index, and other international indexes). Certain data center lease agreements include rental payments subject to change based on usage and CPI fluctuations. The changes based on usage and indexes are treated as variable lease costs and recognized in the period in which the obligation for those payments was incurred.

[0000926326-20-000010:notes:93]
The Company’s operating lease agreements do not contain any material residual value guarantees, restrictions, or restriction covenants.

[0000926326-20-000010:notes:94]
Business Combinations

[0000926326-20-000010:notes:95]
The Company uses the acquisition method of accounting under the authoritative guidance on business combinations. Each acquired company’s operating results are included in the Company's Consolidated Financial Statements starting on the date of acquisition. The purchase price is equivalent to the fair value of consideration transferred. Tangible and identifiable intangible assets acquired and liabilities assumed as of the date of acquisition are recorded at the acquisition date fair value. Goodwill is recognized for the excess of purchase price over the net fair value of assets acquired and liabilities assumed.

[0000926326-20-000010:notes:96]
Amounts allocated to assets and liabilities are based upon fair values. Such valuations require management to make significant estimates and assumptions, especially with respect to the identifiable intangible assets. Management makes estimates of fair value based upon assumptions believed to be reasonable and that of a market participant. These estimates are based on historical experience and information obtained from the management of the acquired companies and the estimates are inherently uncertain. The separately identifiable intangible assets generally include customer relationships, backlog, acquired technology, and trade names.

[0000926326-20-000010:notes:97]
Goodwill and Acquired Intangible Assets

[0000926326-20-000010:notes:98]
Goodwill

[0000926326-20-000010:notes:99]
The Company reviews goodwill for impairment on an annual basis on the first day of the fourth quarter of each year at the reporting unit level. This assessment is also performed whenever there is a change in circumstances that indicates the carrying value of goodwill may be impaired. The Company has one reporting unit, which is the same as its operating segment. A qualitative assessment is initially made to determine whether it is necessary to perform quantitative testing. A qualitative assessment includes, among others, consideration of: (i) past, current, and projected future earnings and equity; (ii) recent trends and market conditions; and (iii) valuation metrics involving similar companies that are publicly-traded and acquisitions of similar companies, if available. If this qualitative assessment indicates that it is more likely than not that impairment exists, or if the Company decides to bypass this option, it proceeds to the quantitative assessment. The quantitative assessment involves a comparison between the estimated fair value of the Company’s reporting unit with its carrying amount including goodwill. If the carrying value exceeds estimated fair value, the Company will record an impairment charge based on that difference. The impairment charge will be limited to the amount of goodwill.

[0000926326-20-000010:notes:100]
To determine the reporting unit’s fair value under the quantitative approach, the Company uses a combination of income and market approaches, equally weighting the two approaches, such as estimated discounted future cash flows of the reporting unit, multiples of earnings or revenues, and analysis of recent sales or offerings of comparable entities. The Company also considers its market capitalization on the date of the analysis to ensure the reasonableness of its reporting unit's fair value.

[0000926326-20-000010:notes:101]
The Company performed a qualitative impairment assessment analysis as of October 1, 2019 for its reporting unit taking into consideration past, current, and projected future earnings, recent trends and market conditions, and valuation metrics involving similar companies that are publicly-traded. Based on the result of this analysis, an impairment does not exist as of December 31, 2019, and there were no accumulated impairment losses.

[0000926326-20-000010:notes:102]
Intangible Assets

[0000926326-20-000010:notes:103]
In connection with its acquisitions, the Company generally recognizes assets for customer relationships, backlog, developed technology, and trade names. Intangible assets are carried at cost less accumulated amortization. Such amortization is provided on a straight-line basis or on an accelerated basis based on a pattern of economic benefit that is expected to be obtained over the estimated useful lives of the respective assets, generally from one to 30 years. Amortization for developed technology and backlog is recognized in cost of revenues, and amortization for customer relationships, non-compete agreements, trade names, and patents is recognized in selling, general, and administrative expenses.

[0000926326-20-000010:notes:104]
The Company assesses the impairment of identifiable intangible assets whenever events or changes in circumstances indicate that an asset’s carrying amount may not be recoverable. Recoverability of an asset is measured by the comparison of the carrying amount to the sum of the undiscounted estimated future cash flows the asset is expected to generate, offset by estimated future costs to dispose of the product to which the asset relates. If an asset is considered to be impaired, the amount of such impairment would be measured as the difference between the carrying amount of the asset and its fair value. The Company’s cash flow assumptions are based on historical and forecasted future revenue, operating costs, and other relevant factors. Assumptions and estimates about the remaining useful lives of the Company’s intangible assets are subjective and are affected by changes to its business strategies. If management’s estimates of future operating results change, or if there are changes to other assumptions, the estimate of the fair value of the Company’s assets could change significantly. Such change could result in impairment charges in future periods, which could have a significant impact on the Company’s operating results and financial condition. For the years ended December 31, 2019 and 2018, there were no events or changes in circumstances to indicate that intangible assets carrying amounts may not be recoverable.

[0000926326-20-000010:notes:105]
Valuation of Share-Based Compensation

[0000926326-20-000010:notes:106]
The Company accounts for share-based compensation in accordance with ASC 718, Stock Compensation. The Company recognizes compensation expense related to share-based compensation based on the grant date estimated fair value.

[0000926326-20-000010:notes:107]
The fair value of stock options (“options”) on the grant date is estimated using the Black-Scholes option pricing model, which requires the following inputs: expected life, expected volatility, risk-free interest rate, expected dividend yield rate, exercise price, and closing price of its common stock on the date of grant. The expected volatility is based on a combination of historical and market-based implied volatility, and the expected life of the awards is based on the Company’s historical experience of employee stock option exercises, including forfeitures. Expense is recognized on a straight-line basis over the requisite service period.

[0000926326-20-000010:notes:108]
The fair value of restricted stock units (“RSUs”) is based on the stock price on the grant date. The fair value of restricted stock awards (“RSAs”) is their intrinsic value, which is the difference between the fair value of the underlying stock at the measurement date and the purchase price. The RSUs and RSAs are subject to a service vesting condition and are recognized on a straight-line basis over the requisite service period.

[0000926326-20-000010:notes:109]
The fair value of performance-based stock unit awards (“PSUs”) with service and market conditions is estimated using a Monte Carlo simulation model applying multiple awards approach. Expense is recognized when it is probable that the performance condition will be met using the accelerated attribution method over the requisite service period.

[0000926326-20-000010:notes:110]
The valuation assumptions used in estimating the fair value of employee share-based awards may change in future periods.

[0000926326-20-000010:notes:111]
Accounting for Income Taxes

[0000926326-20-000010:notes:112]
The Company records an income tax provision for (benefit from) the anticipated tax consequences of the reported results of operations. In accordance with U.S. GAAP, the provision for (benefit from) income taxes is computed using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been included in the financial statements. Under this method, deferred tax assets and liabilities are determined on the basis of the differences between the financial statement and tax bases of assets and liabilities and for operating losses and tax credit carryforwards. Deferred tax assets and liabilities are measured using the enacted tax rates in effect for the periods in which those tax assets and liabilities are expected to be realized or settled. In the event that these tax rates change, the Company will incur a benefit or detriment on its income tax expense in the period of change. If the Company were to determine that all or part of the net deferred tax assets are not realizable in the future, it will record a valuation allowance that would be charged to earnings in the period such determination is made.

[0000926326-20-000010:notes:113]
In accordance with ASC 740, Income Taxes, the Company recognizes the tax benefit from an uncertain tax position if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement. The calculation of tax liabilities involves significant judgment in estimating the impact of uncertainties in the application of U.S. GAAP and complex tax laws. Resolution of these uncertainties in a manner inconsistent with management’s expectations could have a material impact on the Company’s financial condition and operating results.

[0000926326-20-000010:notes:114]
Recently Adopted Authoritative Guidance

[0000926326-20-000010:notes:115]
In February 2016, the FASB issued Accounting Standards Update (“ASU”) 2016-02, Leases (Topic 842). The FASB amended lease accounting requirements to begin recording assets and liabilities arising from most leases on the balance sheet. The new guidance also requires significant additional disclosures about the amount and timing of cash flows from leases. The Company adopted this new guidance on January 1, 2019. In July 2018, the FASB issued amendments in ASU 2018-11, which provide a transition election to not restate comparative periods for the effects of applying the new standard. This transition election permits entities to change the date of initial application to the beginning of the year of adoption and to recognize the effects of applying the new standard as a cumulative-effect adjustment to the opening balance of retained earnings. The Company has elected this transition approach as well as the package of practical expedients permitted under the transition guidance within the new standard, which allowed the Company to carry forward the historical lease classification of contracts entered into prior to January 1, 2019. As a result of electing the package of practical expedients described above, existing leases and related initial direct costs have not been reassessed prior to the effective date, and therefore, adoption of the lease standard did not have an impact on the Company’s previously reported consolidated financial statements.

[0000926326-20-000010:notes:116]
The Company also elected the following practical expedients: (i) combining lease and non-lease components for all asset classes, (ii) leases with an initial term of 12 months or less are not recorded in the Consolidated Balance Sheets, and the associated lease payments are recognized in the Consolidated Statements of Operations on a straight-line basis over the lease term, and (iii) applying discount rates to operating leases using a portfolio approach.

[0000926326-20-000010:notes:117]
From a lessor perspective, certain agreements that were previously classified as operating leases are classified as sales-type leases under the new lease accounting standard. The agreements in place prior to the adoption of the new lease accounting standard on January 1, 2019 will continue to be treated as operating leases.

[0000926326-20-000010:notes:118]
The Company’s adoption of the new standard impacted the Consolidated Balance Sheets at the beginning of the period of adoption as follows:

[0000926326-20-000010:notes:119]
|  | January 1, 2019 |  |  |  |  |
|  | Pre-ASC 842 Balances |  | ASC 842 Adoption Impact |  | Post-ASC 842 Balances |
|  | (In thousands) |  |  |  |  |
| Operating lease right-of-use-assets | $ | — |  |  | $ | 66,008 |  |  | $ | 66,008 |  |
| Accrued liabilities (1) | 43,047 |  |  | 10,067 |  |  | 53,114 |  |
| Long-term operating lease liabilities | — |  |  | 59,791 |  |  | 59,791 |  |
| Other long-term liabilities (2) | 9,562 |  |  | (3,850) |  |  | 5,712 |  |

[0000926326-20-000010:notes:120]
_________________________________________________

[0000926326-20-000010:notes:121]
(1)  Adjustment represents the current portion of the operating lease liabilities of $10.3 million, and reclassification of exit cost obligations and deferred rent of $0.1 million and $0.1 million, respectively, to reduce the operating lease right-of-use assets.

[0000926326-20-000010:notes:122]
(2) Adjustment represents the reclassification of deferred rent to reduce the operating lease right-of-use assets.

[0000926326-20-000010:notes:123]
Adoption of the standard did not have an impact on the Company’s stockholders’ equity, Consolidated Statements of Operations, and Consolidated Statements of Cash Flows as of January 1, 2019.

[0000926326-20-000010:notes:124]
In February 2018, the FASB issued ASU 2018-02, Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income, which permits the reclassification of the income tax effects of the Tax Cuts and Jobs Act of 2017 (the “Tax Act”) on items within accumulated other comprehensive income to retained earnings. These amounts are commonly referred to as “stranded tax effects.” ASU 2018-02 was effective for the Company beginning January 1, 2019. The adoption of this guidance did not have a material effect on the Company’s Consolidated Financial Statements and therefore no adjustment to retained earnings was made.

[0000926326-20-000010:notes:125]
Recently Issued Authoritative Guidance

[0000926326-20-000010:notes:126]
In August 2018, the FASB issued ASU 2018-15, Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract, to align the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software (and hosting arrangements that include an internal-use software license). ASU 2018-15 will be effective for the Company beginning January 1, 2020. The Company anticipates adopting ASU 2018-15 prospectively and does not expect the standard to have a material impact on its Consolidated Financial Statements.

[0000926326-20-000010:notes:127]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326), Measurement of Credit Losses on Financial Instruments, that modifies or replaces existing models for trade and other receivables, debt securities, loans, and certain other financial instruments. For instruments measured at amortized cost, including trade and lease receivables, loans and held-to-maturity debt securities, the standard will replace the current “incurred loss” approach with an “expected loss” model. Entities will be required to estimate expected credit losses over the life of the instrument, considering available relevant information about the collectibility of cash flows, including information about past events, current conditions, and reasonable and supportable forecasts. ASU 2016-13 will be effective for the Company beginning January 1, 2020. In preparation for adoption of the standard, the Company made appropriate changes to necessary processes and controls. The Company’s adoption of the new standard is estimated to result in the recognition of an immaterial cumulative-effect adjustment to retained earnings, using the modified retrospective transition method.

[0000926326-20-000010:notes:128]
There was no other recently issued and effective authoritative guidance that is expected to have a material impact on the Company’s Consolidated Financial Statements through the reporting date.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0000926326-20-000010:notes:129]
The Company has determined that the incentive portions of its sales commission plans require capitalization since these payments are directly related to sales achieved during a time period. These commissions are earned on the basis of the total purchase order value of new product bookings. Since there are no commensurate commissions earned on renewal of the service bookings, the Company concluded that the capitalized asset is related to services provided under both the initial contract and renewal periods. The Company applies a practical expedient to account for the incremental costs of obtaining a contract as part of a portfolio of contracts with similar characteristics as the Company expects the effect on the financial statements of applying the practical expedient would not differ materially from applying the accounting guidance to the individual contracts within the portfolio. A pool of contracts is defined as all contracts booked in a particular quarter. The amortization for the capitalized asset is an estimate of the pool’s original contract term, generally one to five years, plus an estimate of future 
customer renewal periods resulting in a total amortization period of ten years. Costs to obtain a contract are allocated amongst performance obligations and recognized as sales and marketing expense consistent with the pattern of revenue recognition. Capitalized costs are periodically reviewed for impairment. A portion of the pool’s capitalized asset is recorded as an expense over the first two quarters after booking, which represents the estimated period during which the product revenue associated with the contract is recorded. The remaining contract cost is recorded as expense ratably over the ten year estimated initial and renewal service periodsShipping CostsOutbound freight billed to customers is recorded as product revenue. The related shipping and handling costs are expensed as part of selling, general, and administrative expense.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0000926326-20-000010:notes:130]
Property and EquipmentProperty and equipment less accumulated depreciation are stated at historical cost. The Company’s expenditures for property and equipment are primarily for computer equipment and software used in the administration of its business, and for leasehold improvements to its leased facilities. The Company also develops molds and dies used in long-term manufacturing arrangements with suppliers and for production automation equipment used in the manufacturing of consumable blister card components.The Company capitalizes costs related to computer software developed or obtained for internal use in accordance with ASC 350-40, Internal-Use Software. Software obtained for internal use has generally been enterprise-level business and finance software that the Company customizes to meet its specific operational needs. Costs incurred in the application development phase are capitalized and amortized over their useful lives, which is generally five years. Costs recognized in the preliminary project phase and the post-implementation phase are expensed as incurred.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0000926326-20-000010:notes:131]
Depreciation and amortization is computed by use of the straight-line method over the estimated useful lives of the assets as stated below:

[0000926326-20-000010:notes:132]
The following table represents the property and equipment balances as of December 31, 2019 and 2018:

[0000926326-20-000010:notes:133]
|  | December 31, |  |  |
|  | 2019 |  | 2018 |
|  | (In thousands) |  |  |
| Equipment |  | $ | 88,569 |  |  | $ | 75,417 |  |
| Furniture and fixtures |  | 7,925 |  |  | 7,844 |  |
| Leasehold improvements |  | 18,979 |  |  | 16,274 |  |
| Software |  | 48,309 |  |  | 42,048 |  |
| Construction in progress |  | 6,179 |  |  | 10,706 |  |
| Property and equipment, gross |  | 169,961 |  |  | 152,289 |  |
| Accumulated depreciation and amortization |  | (115,715) |  |  | (100,789) |  |
| Total property and equipment, net |  | $ | 54,246 |  |  | $ | 51,500 |  |

[0000926326-20-000010:notes:134]
The following table summarizes the geographic information for property and equipment, net, as of December 31, 2019 and 2018:

[0000926326-20-000010:notes:135]
|  | December 31, |  |  |
|  | 2019 |  | 2018 |
|  | (In thousands) |  |  |
| United States | $ | 48,769 |  |  | $ | 44,684 |  |
| Rest of world (1) | 5,477 |  |  | 6,816 |  |
| Total property and equipment, net | $ | 54,246 |  |  | $ | 51,500 |  |

[0000926326-20-000010:notes:136]
(1) No individual country represented more than 10% of the total property and equipment, net.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000926326-20-000010:notes:137]
Business Combinations
2017 Acquisitions

[0000926326-20-000010:notes:138]
On April 12, 2017, the Company completed the acquisition of all of the membership interest of InPharmics, a technology and services company that provides advanced pharmacy informatics solutions to hospital pharmacies. The total consideration for the transaction was $5.0 million, net of cash acquired of $0.3 million. Approximately $0.5 million of the total consideration was classified as a long-term liability for potential settlement of performance obligations. The Company accounted for the acquisition of InPharmics in accordance with the authoritative guidance on business combinations; therefore, the tangible and intangible assets acquired and liabilities assumed were recorded at fair value on the acquisition date. The purchase price was allocated to intangible assets in the amount of $1.9 million, which included developed technology and customer contracts, with the remainder allocated to goodwill. The results of the InPharmics’ operations have been included in the consolidated results of operations.

[0000926326-20-000010:notes:139]
Pro Forma Financial Information

[0000926326-20-000010:notes:140]
The following table presents certain unaudited pro forma information for illustrative purposes only, for the year ended December 31, 2017 as if this acquisition had been completed on January 1, 2017. The pro forma information is not indicative of what would have occurred had the acquisition taken place on January 1, 2017. The unaudited pro forma information combines the historical results of the acquisition with the Company’s consolidated historical results and includes certain adjustments reflecting the estimated impact of fair value adjustments.

[0000926326-20-000010:notes:141]
|  |  |  | Year Ended December 31, 2017 |
|  |  |  | (In thousands, except per share data) |
| Pro forma net revenues |  |  | $ | 713,272 |  |
| Pro forma net income |  |  | $ | 30,683 |  |
| Pro forma net income per share |  |  | $ | 0.82 |  |
| Weighted-average number of shares |  |  | 37,483 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000926326-20-000010:notes:142]
Revenues
Disaggregation of Revenues

[0000926326-20-000010:notes:143]
The following table summarizes the Company’s product revenues disaggregated by revenue type for the years ended December 31, 2019, 2018, and 2017:

[0000926326-20-000010:notes:144]
|  | Year Ended December 31, |  |  |  |  |
|  | 2019 |  | 2018 |  | 2017 |
|  | (In thousands) |  |  |  |  |  |
| Hardware and software | $ | 553,039 |  |  |  | $ | 464,500 |  |  |  | $ | 406,095 |  |
| Consumables | 88,876 |  |  |  | 89,529 |  |  |  | 88,100 |  |
| Other | 17,687 |  |  |  | 15,566 |  |  |  | 16,006 |  |
| Total product revenues | $ | 659,602 |  |  |  | $ | 569,595 |  |  |  | $ | 510,201 |  |

[0000926326-20-000010:notes:145]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location, for the years ended December 31, 2019, 2018, and 2017:

[0000926326-20-000010:notes:146]
|  | Year Ended December 31, |  |  |  |  |
|  | 2019 |  | 2018 |  | 2017 |
|  | (In thousands) |  |  |  |  |
| United States | $ | 806,900 |  |  | $ | 685,881 |  |  | $ | 613,817 |  |
| Rest of world (1) | 90,127 |  |  | 101,428 |  |  | 98,897 |  |
| Total revenues | $ | 897,027 |  |  | $ | 787,309 |  |  | $ | 712,714 |  |

[0000926326-20-000010:notes:147]
(1) No individual country represented more than 10% of total revenues.

[0000926326-20-000010:notes:148]
The following table reflects the Company’s contract assets and contract liabilities:

[0000926326-20-000010:notes:149]
|  | December 31, |  |  |
|  | 2019 |  | 2018 |
|  | (In thousands) |  |  |
| Short-term unbilled receivables (1) | $ | 11,707 |  |  | $ | 9,191 |  |
| Long-term unbilled receivables (2) | 12,260 |  |  | 16,481 |  |
| Total contract assets |  | $ | 23,967 |  |  | $ | 25,672 |  |
| Short-term deferred revenues, net | $ | 90,894 |  |  | $ | 81,835 |  |
| Long-term deferred revenues | 7,083 |  |  | 10,582 |  |
| Total contract liabilities |  | $ | 97,977 |  |  | $ | 92,417 |  |

[0000926326-20-000010:notes:150]
(1)  Included in accounts receivable and unbilled receivables in the Consolidated Balance Sheets.

[0000926326-20-000010:notes:151]
(2) Included in other long-term assets in the Consolidated Balance Sheets.

[0000926326-20-000010:notes:152]
Short-term deferred revenues of $90.9 million and $81.8 million include deferred revenues from product sales and service contracts, net of deferred cost of sales of $13.1 million and $11.1 million, as of December 31, 2019 and 2018, respectively. The short-term deferred revenues from product sales relate to delivered and invoiced products, pending installation and acceptance, expected to occur within the next twelve months. During the year ended December 31, 2019, the Company recognized revenues of $80.4 million that were included in the corresponding gross short-term deferred revenue balance of $92.9 million as of December 31, 2018.

[0000926326-20-000010:notes:153]
Long-term deferred revenues include deferred revenues from service contracts of $7.1 million and $10.6 million as of December 31, 2019 and 2018, respectively. Remaining performance obligations primarily relate to maintenance contracts and are recognized ratably over the remaining term of the contract, generally not more than five years.

[0000926326-20-000010:notes:154]
Significant Customers

[0000926326-20-000010:notes:155]
There were no customers that accounted for more than 10% of the Company’s total revenues for the years ended December 31, 2019, 2018, and 2017. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable balance as of December 31, 2019 and 2018.


## us-gaap:EarningsPerShareTextBlock

[0000926326-20-000010:notes:156]
Net Income Per Share
Basic net income per share is computed by dividing net income for the period by the weighted-average number of shares outstanding during the period. In periods of net loss, all potential common shares are anti-dilutive, so diluted net loss per share equals the basic net loss per share. In periods of net income, diluted net income per share is computed by dividing net income for the period by the basic weighted-average number of shares plus any dilutive potential common stock outstanding during the period. Potential common stock includes the effect of outstanding dilutive stock options, restricted stock awards and restricted stock units computed using the treasury stock method. Any anti-dilutive weighted-average dilutive shares related to stock award plans are excluded from the computation of the diluted net income per share.

[0000926326-20-000010:notes:157]
The basic and diluted net income per share calculations for the years ended December 31, 2019, 2018, and 2017 were as follows:

[0000926326-20-000010:notes:158]
|  | Year Ended December 31, |  |  |  |  |
|  | 2019 |  | 2018 |  | 2017 |
|  | (In thousands, except per share data) |  |  |  |  |  |
| Net income | $ | 61,338 |  |  | $ | 37,729 |  |  | $ | 30,518 |  |
| Weighted-average shares outstanding — basic | 41,462 |  |  | 39,242 |  |  | 37,483 |  |
| Effect of dilutive securities from stock award plans | 1,481 |  |  | 1,317 |  |  | 1,229 |  |
| Weighted-average shares outstanding — diluted | 42,943 |  |  | 40,559 |  |  | 38,712 |  |
| Net income per share - basic | $ | 1.48 |  |  | $ | 0.96 |  |  | $ | 0.81 |  |
| Net income per share - diluted | $ | 1.43 |  |  | $ | 0.93 |  |  | $ | 0.79 |  |
| Anti-dilutive weighted-average shares related to stock award plans | 926 |  |  | 1,279 |  |  | 501 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000926326-20-000010:notes:159]
Cash and Cash Equivalents and Fair Value of Financial Instruments
Cash and cash equivalents of $127.2 million and $67.2 million as of December 31, 2019 and 2018, respectively, consisted of bank accounts with major financial institutions.

[0000926326-20-000010:notes:160]
Fair Value Hierarchy

[0000926326-20-000010:notes:161]
The Company measures its financial instruments at fair value. The Company’s cash equivalents are classified within Level 1 of the fair value hierarchy as they are valued primarily using quoted market prices utilizing market observable inputs. The Company's interest rate swap contracts are classified within Level 2 as the valuation inputs are based on quoted prices and market observable data of similar instruments.

[0000926326-20-000010:notes:162]
The following table represents the fair value hierarchy of the Company’s financial assets measured at fair value as of December 31, 2018:

[0000926326-20-000010:notes:163]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |  |  |  |  |  |  |
| Interest rate swap contracts | $ | — |  |  | $ | 562 |  |  | $ | — |  |  | $ | 562 |  |
| Total financial assets | $ | — |  |  | $ | 562 |  |  | $ | — |  |  | $ | 562 |  |

[0000926326-20-000010:notes:164]
The Company’s interest rate swap agreement matured during the second quarter of 2019, and as of December 31, 2019, the Company did not have any outstanding interest rate swap agreements.

[0000926326-20-000010:notes:165]
Interest Rate Swap Contracts

[0000926326-20-000010:notes:166]
The Company’s interest rate swaps, which are designated as cash flow hedges, involve the receipt of variable amounts from counterparties in exchange for the Company making fixed-rate payments over the life of the agreements.

[0000926326-20-000010:notes:167]
During 2016, the Company entered into an interest rate swap agreement with a combined notional amount of $100.0 million with one counterparty that became effective on June 30, 2016 and matured on April 30, 2019. The swap agreement required the Company to pay a fixed rate of 0.8% and provided that the Company receive a variable rate based on the one month LIBOR rate subject to a LIBOR floor of 0.0%. Amounts payable by or due to the Company were net settled with the respective counterparty on the last business day of each month, commencing July 31, 2016.

[0000926326-20-000010:notes:168]
The interest rate swap agreement, at its inception, qualified for and was designated as a cash flow hedging instrument, and was recorded on the Company's Consolidated Balance Sheets at fair value. The fair value of the interest rate swap agreement at December 31, 2018 was $0.6 million. There were no amounts reclassified into current earnings due to ineffectiveness during the periods presented.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000926326-20-000010:notes:169]
Balance Sheet Components
Balance sheet details as of December 31, 2019 and 2018 are presented in the tables below:

[0000926326-20-000010:notes:170]
|  | December 31, |  |  |
|  | 2019 |  | 2018 |
|  | (In thousands) |  |  |
| Inventories: |  |  |  |
| Raw materials |  | $ | 31,331 |  |  | $ | 32,511 |  |
| Work in process |  | 7,620 |  |  | 8,726 |  |
| Finished goods |  | 69,060 |  |  | 59,631 |  |
| Total inventories |  | $ | 108,011 |  |  | $ | 100,868 |  |
| Other long-term assets: |  |  |  |
| Capitalized software, net |  | $ | 85,070 |  |  | $ | 56,819 |  |
| Unbilled receivables |  | 12,260 |  |  | 16,481 |  |
| Deferred debt issuance costs | 4,700 |  |  | — |  |
| Other assets |  | 1,006 |  |  | 1,313 |  |
| Total other long-term assets |  | $ | 103,036 |  |  | $ | 74,613 |  |
| Accrued liabilities: |  |  |  |
| Operating lease liabilities, current portion |  | $ | 10,058 |  |  | $ | — |  |
| Advance payments from customers |  | 4,006 |  |  | 8,993 |  |
| Rebates and lease buyouts |  | 14,911 |  |  | 11,076 |  |
| Group purchasing organization fees | 5,934 |  |  | 4,455 |  |
| Taxes payable | 3,744 |  |  | 5,885 |  |
| Other accrued liabilities |  | 16,914 |  |  | 12,638 |  |
| Total accrued liabilities |  | $ | 55,567 |  |  | $ | 43,047 |  |

[0000926326-20-000010:notes:171]
The following table summarizes the changes in accumulated balances of other comprehensive income (loss) for the years ended December 31, 2019 and 2018:

[0000926326-20-000010:notes:172]
|  | Foreign currency translation adjustments |  | Unrealized gain (loss) on interest rate swap hedges |  | Total |  |
|  | (In thousands) |  |  |  |  |  |  |
| Balance as of December 31, 2017 | $ | (6,954) |  |  | $ | 841 |  |  | $ | (6,113) |  |  |
| Other comprehensive income (loss) before reclassifications | (4,320) |  |  | 777 |  |  | (3,543) |  |  |
| Amounts reclassified from other comprehensive income (loss), net of tax | — |  |  | (1,198) |  |  | (1,198) |  |  |
| Net current-period other comprehensive income (loss), net of tax | (4,320) |  |  | (421) |  |  | (4,741) |  |  |
| Balance as of December 31, 2018 | (11,274) |  |  | 420 |  |  | (10,854) |  |  |
| Other comprehensive income (loss) before reclassifications | 1,828 |  |  | 148 |  |  | 1,976 |  |  |
| Amounts reclassified from other comprehensive income (loss), net of tax | — |  |  | (568) |  |  | (568) |  |  |
| Net current-period other comprehensive income (loss), net of tax | 1,828 |  |  | (420) |  |  | 1,408 |  |  |
| Balance as of December 31, 2019 | $ | (9,446) |  |  | $ | — |  |  | $ | (9,446) |  |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000926326-20-000010:notes:173]
Property and Equipment
The following table represents the property and equipment balances as of December 31, 2019 and 2018:

[0000926326-20-000010:notes:174]
Depreciation and amortization expense of property and equipment was $17.2 million, $15.1 million, and $16.2 million for the years ended December 31, 2019, 2018, and 2017, respectively.

[0000926326-20-000010:notes:175]
The geographic location of the Company's property and equipment, net, is based on the physical location in which it is located. The following table summarizes the geographic information for property and equipment, net, as of December 31, 2019 and 2018:


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000926326-20-000010:notes:176]
Goodwill and Intangible Assets
Goodwill

[0000926326-20-000010:notes:177]
The following table represents changes in the carrying amount of goodwill:

[0000926326-20-000010:notes:178]
|  |  |  |  |  | (In thousands) |
| Balance as of December 31, 2017 |  |  |  |  | $ | 337,751 |  |
| Additions |  |  |  |  | — |  |
| Foreign currency exchange rate fluctuations |  |  |  |  | (1,864) |  |
| Balance as of December 31, 2018 |  |  |  |  | 335,887 |  |
| Additions |  |  |  |  | — |  |
| Foreign currency exchange rate fluctuations |  |  |  |  | 652 |  |
| Balance as of December 31, 2019 |  |  |  |  | $ | 336,539 |  |

[0000926326-20-000010:notes:179]
Intangible Assets, Net

[0000926326-20-000010:notes:180]
The carrying amounts and useful lives of intangible assets as of December 31, 2019 and 2018 were as follows:

[0000926326-20-000010:notes:181]
|  | December 31, 2019 |  |  |  |  |  |  |  |  |
|  | Gross carryingamount (1) |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |  |  |  |  |  |  |  |  |
| Customer relationships | $ | 135,234 |  |  | $ | (54,860) |  |  | $ | (1,058) |  |  | $ | 79,316 |  |  | 10 - 30 |
| Acquired technology | 77,142 |  |  | (36,194) |  |  | 5 |  |  | 40,953 |  |  | 3 - 20 |
| Backlog | 1,150 |  |  | (791) |  |  | — |  |  | 359 |  |  | 4 |
| Trade names | 7,650 |  |  | (5,037) |  |  | 11 |  |  | 2,624 |  |  | 6 - 12 |
| Patents | 3,217 |  |  | (1,603) |  |  | 1 |  |  | 1,615 |  |  | 2 - 20 |
| Total intangibles assets, net | $ | 224,393 |  |  | $ | (98,485) |  |  | $ | (1,041) |  |  | $ | 124,867 |  |  |  |

[0000926326-20-000010:notes:182]
|  | December 31, 2018 |  |  |  |  |  |  |  |  |
|  | Gross carryingamount (1) |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |  |  |  |  |  |  |  |  |
| Customer relationships | $ | 135,234 |  |  | $ | (45,029) |  |  | $ | (1,185) |  |  | $ | 89,020 |  |  | 10 - 30 |
| Acquired technology | 78,122 |  |  | (29,206) |  |  | 42 |  |  | 48,958 |  |  | 3 - 20 |
| Backlog | 21,350 |  |  | (20,703) |  |  | — |  |  | 647 |  |  | 1 - 4 |
| Trade names | 7,650 |  |  | (4,361) |  |  | 17 |  |  | 3,306 |  |  | 6 - 12 |
| Patents | 3,239 |  |  | (1,488) |  |  | 4 |  |  | 1,755 |  |  | 2 - 20 |
| Non-compete agreements | 1,900 |  |  | (1,900) |  |  | — |  |  | — |  |  | 3 |
| Total intangibles assets, net | $ | 247,495 |  |  | $ | (102,687) |  |  | $ | (1,122) |  |  | $ | 143,686 |  |  |  |

[0000926326-20-000010:notes:183]
(1)  The differences in gross carrying amounts between periods are primarily due to the write-off of certain fully amortized intangible assets.

[0000926326-20-000010:notes:184]
Amortization expense of intangible assets was $18.9 million, $23.8 million, and $25.6 million for the years ended December 31, 2019, 2018, and 2017, respectively.

[0000926326-20-000010:notes:185]
The estimated future amortization expenses for amortizable intangible assets were as follows:

[0000926326-20-000010:notes:186]
|  | December 31, 2019 |
|  | (In thousands) |
| 2020 | $ | 17,502 |  |
| 2021 | 16,180 |  |
| 2022 | 14,832 |  |
| 2023 | 13,724 |  |
| 2024 | 7,972 |  |
| Thereafter |  | 54,657 |  |
| Total |  | $ | 124,867 |  |


## us-gaap:DebtDisclosureTextBlock

[0000926326-20-000010:notes:187]
Debt and Credit Agreements 
2016 Senior Credit Facility

[0000926326-20-000010:notes:188]
On January 5, 2016, the Company entered into a $400.0 million senior secured credit facility pursuant to a credit agreement with certain lenders, Wells Fargo Securities, LLC as sole lead arranger, and Wells Fargo Bank, National Association as administrative agent (as subsequently amended as discussed below, the “Prior Credit Agreement”). The Prior Credit Agreement provided for (a) a five-year revolving credit facility of $200.0 million, which was subsequently increased pursuant to the amendment discussed below (the “Prior Revolving Credit Facility”) and (b) a five-year $200.0 million term loan facility (the “Prior Term Loan Facility” and together with the Prior Revolving Credit Facility, the “Prior Facilities”). In addition, the Prior Credit Agreement included a letter of credit sub-limit of up to $10.0 million and a swing line loan sub-limit of up to $10.0 million. The Prior Credit Agreement had an expiration date of January 5, 2021, upon which date all remaining outstanding borrowings were due and payable.

[0000926326-20-000010:notes:189]
Loans under the Prior Facilities bore interest, at the Company’s option, at a rate equal to either (a) the LIBOR Rate, plus an applicable margin ranging from 1.50% to 2.25% per annum based on the Company’s consolidated total net leverage ratio (as defined in the Prior Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) LIBOR for an interest period of one month, plus an applicable margin ranging from 0.50% to 1.25% per annum based on the Company’s consolidated total net leverage ratio (as defined in the Prior Credit Agreement). Undrawn commitments under the Prior Revolving Credit Facility were subject to a commitment fee ranging from 0.20% to 0.35% per annum based on the Company’s consolidated total net leverage ratio on the average daily unused portion of the Prior Revolving Credit Facility.

[0000926326-20-000010:notes:190]
On each of April 11, 2017 and December 26, 2017, the parties entered into amendments to the Prior Credit Agreement. Under these amendments, the Prior Revolving Credit Facility was increased from $200.0 million to $315.0 million and certain other modifications were made. In connection with the December 2017 amendment, the Company incurred and capitalized an additional $2.1 million of debt issuance costs.

[0000926326-20-000010:notes:191]
2019 Revolving Credit Facility

[0000926326-20-000010:notes:192]
On November 15, 2019, the Company refinanced the Prior Credit Agreement and entered into an Amended and Restated Credit Agreement (the “A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers and Wells Fargo Bank, National Association, as administrative agent. The A&R Credit Agreement replaced the Prior Credit Agreement and provides for (a) a five-year revolving credit facility of $500.0 million (the “Current Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million (the “Incremental Facility”). In addition, the A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The A&R Credit Agreement has an expiration date of November 15, 2024, upon which date all remaining outstanding borrowings will be due and payable.

[0000926326-20-000010:notes:193]
On November 15, 2019, the $80.0 million outstanding term loan balance under the Prior Facilities was transferred to the Current Revolving Credit Facility.

[0000926326-20-000010:notes:194]
Loans under the Current Revolving Credit Facility bear interest, at the Company’s option, at a rate equal to either (a) the LIBOR Rate, plus an applicable margin ranging from 1.25% to 2.00% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the A&R Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the

[0000926326-20-000010:notes:195]
prime rate, (ii) the federal funds rate plus 0.50%, and (iii) LIBOR for an interest period of one month plus 1.00%, plus an applicable margin ranging from 0.25% to 1.00% per annum based on the Company’s Consolidated Total Net Leverage Ratio. Undrawn commitments under the Current Revolving Credit Facility are subject to a commitment fee ranging from 0.15% to 0.30% per annum based on the Company’s Consolidated Total Net Leverage Ratio on the average daily unused portion of the Current Revolving Credit Facility. The applicable margin for and certain other terms of any term loans under the Incremental Facility will be determined prior to the incurrence of such loans. The Company is permitted to make voluntary prepayments at any time without payment of a premium or penalty.

[0000926326-20-000010:notes:196]
The A&R Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends, and other distributions. The A&R Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum consolidated total net leverage ratio and maintain a minimum interest coverage ratio. In addition, the A&R Credit Agreement contains certain customary events of default including, but not limited to, failure to pay interest, principal and fees or other amounts when due, material misrepresentations or misstatements in any representation or warranty, covenant defaults, certain cross defaults to other material indebtedness, certain judgment defaults and events of bankruptcy. The Company’s obligations under the A&R Credit Agreement and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and such subsidiary guarantors’ assets. In connection with entering into the A&R Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a reaffirmation agreement, which amends certain terms of the existing collateral agreement and reaffirms their obligations under the existing guaranty agreement. The Company was in full compliance with all covenants as of December 31, 2019.

[0000926326-20-000010:notes:197]
The refinancing of the Prior Credit Agreement was evaluated in accordance with ASC 470-50, Debt - Modifications and Extinguishments. In determining whether the refinancing was to be accounted for as a debt extinguishment or a debt modification, the Company considered whether lenders within the syndicate remained the same or changed and whether the changes in debt terms were substantial. This assessment was performed on an individual lender basis within the syndicate. As a result, the refinancing was accounted for as a modification with the exception of certain lenders that exited the syndicate. The exit of certain lenders resulted in an immaterial write-off of existing unamortized debt issuance costs. The remaining unamortized debt issuance costs related to debt modification, along with the new deferred costs, will be amortized over the remaining term of the A&R Credit Agreement.

[0000926326-20-000010:notes:198]
In connection with the A&R Credit Agreement, the Company incurred and capitalized an additional $2.3 million of debt issuance costs. The debt issuance costs are being amortized to interest expense using the straight-line method through 2024. Amortization expense related to debt issuance costs was approximately $2.2 million, $2.3 million, and $1.6 million for the years ended December 31, 2019, 2018, and 2017, respectively.

[0000926326-20-000010:notes:199]
Interest expense (exclusive of fees and debt issuance cost amortization) was approximately $3.6 million, $7.5 million, and $6.3 million for the years ended December 31, 2019, 2018, and 2017, respectively.

[0000926326-20-000010:notes:200]
The following table represents changes in the carrying amount of the Company's debt obligations:

[0000926326-20-000010:notes:201]
|  | Prior Term Loan Facility |  | Current Revolving Credit Facility |  | Total |
|  | (In thousands) |  |  |  |  |
| Balance as of December 31, 2018 | $ | 140,000 |  |  |  | $ | — |  |  |  | $ | 140,000 |  |
| Proceeds | — |  |  |  | — |  |  |  | — |  |
| Repayments | (60,000) |  |  |  | (30,000) |  |  |  | (90,000) |  |
| Balance transfer | (80,000) |  |  |  | 80,000 |  |  |  | — |  |
| Balance as of December 31, 2019 | $ | — |  |  |  | $ | 50,000 |  |  |  | $ | 50,000 |  |

[0000926326-20-000010:notes:202]
The following table represents changes in the balance of the Company's deferred debt issuance costs:

[0000926326-20-000010:notes:203]
|  | (In thousands) |
| Balance as of December 31, 2018 (1) | $ | 4,583 |  |
| Additions | 2,321 |  |
| Amortization | (2,204) |  |
| Balance as of December 31, 2019 (2) | $ | 4,700 |  |

[0000926326-20-000010:notes:204]
(1)  Presented as a direct deduction from the carrying amount of the debt liability in the Consolidated Balance Sheets.

[0000926326-20-000010:notes:205]
(2)  Presented in other long-term assets in the Consolidated Balance Sheets.
As of December 31, 2019, the carrying value of debt of $50.0 million approximates its fair value. The fair value of the outstanding balance of the Current Revolving Credit Facility was calculated using a discounted cash flow model based on current market interest rates available to the Company. The Company's debt is classified within Level 2 in the fair value hierarchy as the valuation inputs are based on market observable data of similar instruments.


## us-gaap:OperatingLeasesOfLessorDisclosureTextBlock

[0000926326-20-000010:notes:206]
Lessor Leases
Sales-Type Leases

[0000926326-20-000010:notes:207]
On a recurring basis, the Company enters into multi-year, sales-type lease agreements with the majority varying in length from one to five years. The following table presents the Company’s income recognized from sales-type leases for the years ended December 31, 2019, 2018, and 2017:

[0000926326-20-000010:notes:208]
|  | Year Ended December 31, |  |  |  |  |
|  | 2019 |  | 2018 |  | 2017 |
|  | (In thousands) |  |  |  |  |
| Sales-type lease revenues | $ | 37,175 |  |  | $ | 39,167 |  |  | $ | 29,675 |  |
| Cost of sales-type lease revenues | (14,985) |  |  | (16,185) |  |  | (12,395) |  |
| Selling profit on sales-type lease revenues | $ | 22,190 |  |  | $ | 22,982 |  |  | $ | 17,280 |  |
| Interest income on sales-type lease receivables | $ | 1,756 |  |  | $ | 1,296 |  |  | $ | 992 |  |

[0000926326-20-000010:notes:209]
The receivables as a result of these types of transactions are collateralized by the underlying equipment leased and consist of the following components at December 31, 2019 and 2018:

[0000926326-20-000010:notes:210]
|  | December 31, |  |  |
|  | 2019 |  | 2018 |
|  | (In thousands) |  |  |  |
| Net minimum lease payments to be received | $ | 32,360 |  |  | $ | 28,295 |  |
| Less: Unearned interest income portion | (2,840) |  |  | (2,477) |  |
| Net investment in sales-type leases | 29,520 |  |  | 25,818 |  |
| Less: Current portion (1) | (9,770) |  |  | (8,736) |  |
| Long-term investment in sales-type leases, net | $ | 19,750 |  |  | $ | 17,082 |  |

[0000926326-20-000010:notes:211]
(1) The current portion of the net investment in sales-type leases is included in other current assets in the Consolidated Balance Sheets.

[0000926326-20-000010:notes:212]
The carrying amount of the Company’s sales-type lease receivables is a reasonable estimate of fair value.

[0000926326-20-000010:notes:213]
The Company evaluates its sales-type leases individually and collectively for impairment. The allowance for credit losses was $0.2 million as of both December 31, 2019 and 2018.

[0000926326-20-000010:notes:214]
The maturity schedule of future minimum lease payments under sales-type leases retained in-house and the reconciliation to the net investment in sales-type leases reported on the Consolidated Balance Sheets was as follows:

[0000926326-20-000010:notes:215]
|  | December 31, 2019 |
|  | (In thousands) |
| 2020 | $ | 10,690 |  |
| 2021 | 7,473 |  |
| 2022 | 6,768 |  |
| 2023 | 4,754 |  |
| 2024 | 1,852 |  |
| Thereafter | 823 |  |
| Total future minimum sales-type lease payments |  | 32,360 |  |
| Present value adjustment |  | (2,840) |  |
| Total net investment in sales-type leases |  | $ | 29,520 |  |

[0000926326-20-000010:notes:216]
The Company entered into certain leasing agreements that were classified as operating leases prior to the adoption of the new lease accounting standard. These agreements in place prior to January 1, 2019 will continue to be treated as operating leases, however any new leasing agreements entered into on or after January 1, 2019 under these programs are classified and accounted for as sales-type leases in accordance with the new lease accounting standard. The operating lease arrangements generally have initial terms of one to seven years. The following table represents the Company’s income recognized from operating leases for the years ended December 31, 2019, 2018, and 2017:

[0000926326-20-000010:notes:217]
|  | Year Ended December 31, |  |  |  |  |
|  | 2019 |  | 2018 |  | 2017 |
|  | (In thousands) |  |  |  |  |
| Rental income | $ | 12,660 |  |  | $ | 12,207 |  |  | $ | 10,993 |  |

[0000926326-20-000010:notes:218]
The net carrying value of the leased equipment under operating leases was $2.1 million and $2.6 million, which includes accumulated depreciation of $1.6 million and $1.2 million, as of December 31, 2019 and 2018, respectively. Depreciation expense of the leased equipment for the years ended December 31, 2019, 2018, and 2017 was $0.7 million, $0.5 million, and $0.3 million, respectively.

[0000926326-20-000010:notes:219]
The maturity schedule of future minimum lease payments under operating leases was as follows:

[0000926326-20-000010:notes:220]
|  | December 31, 2019 |
|  | (In thousands) |
| 2020 | $ | 10,415 |  |
| 2021 | 6,829 |  |
| 2022 | 4,941 |  |
| 2023 | 2,914 |  |
| 2024 | 884 |  |
| Thereafter | 345 |  |
| Total future minimum operating lease payments |  | $ | 26,328 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0000926326-20-000010:notes:221]
Lessee LeasesThe Company has operating leases for office buildings, data centers, office equipment, and vehicles. The Company’s leases have initial terms of one to 12 years. As of December 31, 2019, the Company did not have any additional material operating leases that were entered into, but not yet commenced. 
The maturity schedule of future minimum lease payments under operating leases and the reconciliation to the operating lease liabilities reported on the Consolidated Balance Sheets was as follows:

[0000926326-20-000010:notes:222]
|  | December 31, 2019 |
|  | (In thousands) |
| 2020 | $ | 13,573 |  |
| 2021 | 13,071 |  |
| 2022 | 11,970 |  |
| 2023 | 8,487 |  |
| 2024 | 7,961 |  |
| Thereafter |  | 19,768 |  |
| Total operating lease payments |  | 74,830 |  |
| Present value adjustment |  | (14,103) |  |
| Total operating lease liabilities (1) | $ | 60,727 |  |

[0000926326-20-000010:notes:223]
(1) Amount consists of a current and long-term portion of operating lease liabilities of $10.1 million and $50.7 million, respectively. The short-term portion of the operating lease liabilities is included in accrued liabilities in the Consolidated Balance Sheets.

[0000926326-20-000010:notes:224]
Prior to the adoption of the new lease accounting standard, the maturity schedule of future minimum lease payments under operating leases was as follows:

[0000926326-20-000010:notes:225]
|  | December 31, 2018 |
|  | (In thousands) |
| 2019 | $ | 14,153 |  |
| 2020 | 13,104 |  |
| 2021 | 12,729 |  |
| 2022 | 11,809 |  |
| 2023 | 8,334 |  |
| Thereafter | 27,289 |  |
| Total minimum future lease payments |  | $ | 87,418 |  |

[0000926326-20-000010:notes:226]
Operating lease costs were $14.6 million for the year ended December 31, 2019. Short-term lease costs and variable lease costs were immaterial for the year ended December 31, 2019.

[0000926326-20-000010:notes:227]
Prior to the adoption of the new lease accounting standard, rent expense was $12.7 million and $11.5 million for the years ended December 31, 2018 and 2017.

[0000926326-20-000010:notes:228]
The following table summarizes supplemental cash flow information related to the Company’s operating leases for the year ended December 31, 2019:

[0000926326-20-000010:notes:229]
|  | Year EndedDecember 31, 2019 |
|  | (In thousands) |  |
| Cash paid for amounts included in the measurement of lease liabilities | $ | 14,636 |  |
| Right-of-use assets obtained in exchange for new lease liabilities | $ | 1,204 |  |

[0000926326-20-000010:notes:230]
The following table summarizes the weighted-average remaining lease term and weighted-average discount rate related to the Company’s operating leases as of December 31, 2019:

[0000926326-20-000010:notes:231]
|  | December 31,2019 |
|  | (In thousands) |  |
| Weighted-average remaining lease term, years | 6.4 |
| Weighted-average discount rate, % | 6.4 | % |


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000926326-20-000010:notes:232]
Commitments and Contingencies
Purchase Obligations

[0000926326-20-000010:notes:233]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of December 31, 2019, the Company had non-cancelable purchase commitments of $65.9 million, of which $63.8 million are expected to be paid within the next twelve months.

[0000926326-20-000010:notes:234]
Legal Proceedings

[0000926326-20-000010:notes:235]
The Company is currently involved in various legal proceedings. As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any accrual for contingent liabilities associated with the legal proceedings described below based on its belief that any potential loss, while reasonably possible, is not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of this contingency or because of the diversion of management’s attention and the creation of significant expenses.

[0000926326-20-000010:notes:236]
On January 10, 2018, a lawsuit was filed against a number of individuals, governmental agencies, and corporate entities, including the Company and one of its former subsidiaries, Aesynt Incorporated (“Aesynt”), which, through a series of mergers, has been merged into the Company, in the Circuit Court for the City of Richmond, Virginia, captioned Ruth Ann Warner, as Guardian of Jonathan James Brewster Warner v. Centra Health, Inc., et al., Case No. CL18-152-1. The complaint sought monetary recovery of compensatory and punitive damages in addition to certain declaratory relief based upon, as against the individuals, governmental agencies, and corporate entities other than the Company and Aesynt, allegations of the use of excessive force, unlawful detention, false imprisonment, battery, simple and gross negligence and negligent hiring, detention, and training; and, as against the Company and Aesynt, claims of product liability, negligence, and breach of implied warranties. The Company and Aesynt were never served with the complaint. Upon motion of the plaintiff, the Court issued an order on February 21, 2019 nonsuiting (dismissing) the case without prejudice. On August 21, 2019, a new lawsuit was filed against the Company and Aesynt, in the Circuit Court for the County of Albemarle, Virginia, captioned Ruth Ann Warner, as Guardian of Jonathan James Brewster Warner v. Aesynt Incorporated, et al., Case No CL19-1301. The complaint seeks monetary recovery of damages based upon claims of product liability, negligence, and breach of implied warranties. The Company and Aesynt have not been served with the complaint. The Company intends to defend the lawsuit vigorously.

[0000926326-20-000010:notes:237]
On June 6, 2018, a class action lawsuit was filed against a customer of the Company, the customer’s parent company, and two vendors of medication dispensing systems, one of which is the Company, in the Circuit Court of Cook County, Illinois, Chancery Division, captioned Yana Mazya, individually and on behalf of all others similarly situated v. Northwestern Lake Forest Hospital, Northwestern Memorial Healthcare, Omnicell, Inc. and Becton Dickinson, Case No. 2018-CH-07161. The complaint sought class certification, monetary damages in the form of statutory damages for willful and/or reckless or, in the alternative, negligent violation of the Illinois Biometric Information Privacy Act (“BIPA”), and certain declaratory, injunctive, and other relief based on causes of action directed to allegations of violation of BIPA and of negligence by the defendants. The complaint was served on the Company on June 15, 2018. The Company’s obligation to respond to the complaint was held in abeyance pending a decision of the Illinois Supreme Court in a separate case involving BIPA issues. The Illinois Supreme Court issued its decision in that case on January 25, 2019. On April 10, 2019, subsequent to the Court’s issuance of an order granting the plaintiff leave to file an amended complaint, the plaintiff filed an amended complaint adding a second named plaintiff and an affiliate of the Company’s customer as an additional defendant and, in addition to making other modifications to the complaint, removing the separate cause of action directed to negligence. The Court established a deadline of May 13, 2019 for the defendants to answer or otherwise respond to the amended complaint. On May 10, 2019, defendants Northwestern Lake Forest Hospital, Northwestern Memorial Healthcare, and Northwestern Memorial Hospital removed the case to the United States District Court for the Northern District of Illinois, Eastern Division. Subsequently, on May 17, 2019, the Company and the other defendants in the case each filed a motion to dismiss the complaint for failure to state a cause of action upon which relief could be granted. On June 14, 2019, plaintiffs filed a motion to remand the case to state court. The Court then entered an order, on June 19, 2019, denying plaintiffs’ motion to remand, granting defendants’ motions to dismiss with respect to the additionally-named plaintiff, and continuing the motions to dismiss with respect to the originally-named plaintiff. On July 2, 2019, the Court entered an order remanding the case to state court and denying the defendants’ motions to dismiss without prejudice to renewal of the motions in state court. On September 5, 2019, plaintiff filed a motion to voluntarily dismiss the Company from the case without prejudice. The motion was granted by order of the Court dated October 10, 2019 and, as a result, the Company has been finally dismissed from the case without prejudice to plaintiff refiling the action.

[0000926326-20-000010:notes:238]
A declaratory judgment action was filed against the Company, on August 30, 2018, in the United States District Court for the Northern District of California, captioned Zurich American Insurance Company; American Guarantee & Liability Company v. Omnicell, Inc. and Does 1-10, inclusive, Case No. 3:18-CV-05345. The complaint seeks a declaration that the plaintiffs have no duty to defend or indemnify the Company in connection with the underlying litigation, the Yana Mazya, et al. v. Northwestern Lake Forest Hospital, et al., Case No. 2018-CH-07161 pending in the Circuit Court of Cook County, Illinois, Chancery Division (“Mazya Action”), disclosed above, together with claims for reimbursement and unjust enrichment relating to the defense of the Mazya Action in the form of attorneys’ fees and other related costs. The Company has not responded to the complaint. On February 12, 2019, the Court stayed the action pending the outcome of the Mazya Action and administratively closed the case. On October 15, 2019, the plaintiffs filed a notice advising the Court of the dismissal of the Company from the Mazya Action and requesting that the Court lift the stay in the case and set dates for filing a responsive pleading by the Company and initial discovery and scheduling matters. By order dated November 13, 2019, the Court (i) lifted the stay in the case, (ii) set a case management conference for February 5, 2020, and (iii) ordered the parties to file a joint case management statement by January 29, 2020. The parties subsequently reached a settlement of the case in principle and the Court, after notice of the parties, continued the case management conference until April 29, 2020 and ordered the parties to file a joint case management statement by April 22, 2020. The Company intends to defend the lawsuit vigorously.

[0000926326-20-000010:notes:239]
A class action lawsuit was filed against the Company, on June 5, 2019, in the Circuit Court of Cook County, Illinois, Chancery Division, captioned Corey Heard, individually and on behalf of all others similarly situated, v. Omnicell, Inc., Case No. 2019-CH-06817. The complaint seeks class certification, monetary damages in the form of statutory damages for willful and/or reckless or, in the alternative, negligent violation of BIPA, and certain declaratory, injunctive, and other relief based on causes of action directed to allegations of violation of BIPA by the Company. The complaint was served on the Company on June 13, 2019. On July 31, 2019, the Company filed a motion to stay or consolidate the case with the Mazya Action. The Court subsequently, on October 10, 2019, denied the motion, without prejudice, as being moot in view of the Company’s dismissal from the Mazya Action. The Company filed a motion to dismiss the complaint on October 31, 2019. The motion to dismiss is fully-briefed and the Court has scheduled a hearing on the motion for March 16, 2020. The Company intends to defend the lawsuit vigorously.

[0000926326-20-000010:notes:240]
On July 18, 2019, a putative class action lawsuit was filed against the Company and certain of its officers in the U.S. District Court for the Northern District of California. The complaint, captioned Bursick v. Omnicell, Inc. et al., Case No. 3:19-cv-04150, alleged that the defendants violated federal securities laws by making materially false and misleading statements beginning in October 2018 regarding revenue recognition, customer concerns about implementation issues, and a purported need to write off inventory. The plaintiff sought unspecified monetary damages and other relief. On October 24, 2019, Frank Bursick was appointed Lead Plaintiff. On December 5, 2019, Lead Plaintiff filed a Notice of Voluntary Dismissal of this action as to all defendants, instead of filing an amended complaint. This action is now concluded.

[0000926326-20-000010:notes:241]
In August 2019, the Company received a letter from the Denver office of the SEC seeking information related to the Company’s accounting processes and procedures. The Company responded and fully cooperated with the SEC. On February 12, 2020, the Company received a letter from the SEC confirming that it has concluded its investigation and that the SEC does not intend to recommend any enforcement action against the Company.

[0000926326-20-000010:notes:242]
Guarantees

[0000926326-20-000010:notes:243]
As permitted under Delaware law and the Company’s certificate of incorporation and bylaws, the Company has agreed to indemnify its directors and officers against certain losses that they may suffer by reason of the fact that such persons are, were or become its directors or officers. The term of the indemnification period is for the director’s or officer’s lifetime and there is no limit on the potential amount of future payments that the Company could be required to make under these indemnification agreements. The Company has purchased a directors’ and officers’ liability insurance policy that may enable it to recover a portion of any future payments that it may be required to make under these indemnification agreements. Assuming the applicability of coverage and the willingness of the insurer to assume coverage and subject to certain retention, loss limits and other policy provisions, the Company believes it is unlikely that the Company will be required to pay any material amounts pursuant to these indemnification obligations. However, no assurances can be given that the insurers will not attempt to dispute the validity, applicability or amount of coverage without expensive and time-consuming litigation against the insurers.

[0000926326-20-000010:notes:244]
Additionally, the Company undertakes indemnification obligations in its ordinary course of business in connection with, among other things, the licensing of its products and the provision of its support services. In the ordinary course of the Company’s business, the Company has in the past and may in the future agree to indemnify another party, generally its business affiliates or customers, against certain losses suffered or incurred by the indemnified party in connection with various types of claims, which may include, without limitation, claims of intellectual property infringement, certain tax liabilities, its gross negligence or intentional acts in the performance of support services and violations of laws. The term of these indemnification obligations is generally perpetual. In general, the Company attempts to limit the maximum potential amount of future payments that it may be required to make under these indemnification obligations to the amounts paid to it by a customer, but in some

[0000926326-20-000010:notes:245]
cases the obligation may not be so limited. In addition, the Company has in the past and may in the future warrant to its customers that its products will conform to functional specifications for a limited period of time following the date of installation (generally not exceeding 30 days) or that its software media is free from material defects. Sales contracts for certain of the Company’s medication packaging systems often include limited warranties for up to six months, but the periodic activity and ending warranty balances the Company records have historically been immaterial.

[0000926326-20-000010:notes:246]
From time to time, the Company may also warrant that its professional services will be performed in a good and workmanlike manner or in a professional manner consistent with industry standards. The Company generally seeks to disclaim most warranties, including any implied or statutory warranties such as warranties of merchantability, fitness for a particular purpose, title, quality and non-infringement, as well as any liability with respect to incidental, consequential, special, exemplary, punitive or similar damages. In some states, such disclaimers may not be enforceable. If necessary, the Company would provide for the estimated cost of product and service warranties based on specific warranty claims and claim history. The Company has not been subject to any significant claims for such losses and has not incurred any material costs in defending or settling claims related to these indemnification obligations. Accordingly, the Company believes it is unlikely that the Company will be required to pay any material amounts pursuant to these indemnification obligations or potential warranty claims and, therefore, no material liabilities have been recorded for such indemnification obligations as of December 31, 2019 and 2018.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000926326-20-000010:notes:247]
Employee Benefits and Share-Based Compensation
Stock Purchase Plan

[0000926326-20-000010:notes:248]
1997 Employee Stock Purchase Plan

[0000926326-20-000010:notes:249]
The Company has an Employee Stock Purchase Plan (“ESPP”), under which employees can purchase shares of its common stock based on a percentage of their compensation, but not greater than 15% of their earnings; provided, however, an eligible employee’s right to purchase shares of the Company’s common stock may not accrue at a rate which exceeds $25,000 of the fair market value of such shares for each calendar year in which such rights are outstanding. The purchase price per share must be equal to the lower of 85% of the fair value of the common stock at the beginning of a 24-month offering period or the end of each six-month purchasing period.

[0000926326-20-000010:notes:250]
There was a total of 1.5 million shares reserved for future issuance under the ESPP as of December 31, 2019.

[0000926326-20-000010:notes:251]
Stock Award Plans

[0000926326-20-000010:notes:252]
2009 Equity Incentive Plan

[0000926326-20-000010:notes:253]
The 2009 Equity Incentive Plan (“2009 Plan”), as amended, provides for the issuance of incentive stock options, RSAs, RSUs, PSUs, and other stock awards to the Company’s employees, directors, and consultants. There were 7.5 million shares of common stock reserved for future issuance under the 2009 Plan as of December 31, 2019.

[0000926326-20-000010:notes:254]
Options granted under the 2009 Plan generally become exercisable over periods of up to four years, with one-fourth of the shares vesting one year from the vesting commencement date with respect to initial grants, and the remaining shares vesting in 36 equal monthly installments thereafter. The exercise prices of the options is the fair market value of common stock on the date of grant. RSUs generally vest over periods of up to four years, with one-fourth of the shares vesting one year from the vesting commencement date with respect to initial grants, and the remaining shares vesting in 12 equal quarterly installments thereafter. Awards of restricted stock to non-employee directors are granted on the date of the annual meeting of stockholders and vest in full on the date of the next annual meeting of stockholders, provided such non-employee director remains a director on such date. The fair value of the awards on the date of issuance is amortized to expense from the date of grant to the date of vesting and are expensed ratably on a straight-line basis over the vesting period. PSUs granted to the Company’s executives might include performance and market conditions. PSUs become eligible for vesting when certain market or performance conditions are met.

[0000926326-20-000010:notes:255]
Share-Based Compensation Expense

[0000926326-20-000010:notes:256]
The following table sets forth the total share-based compensation expense recognized in the Company’s Consolidated Statements of Operations:

[0000926326-20-000010:notes:257]
|  | Year Ended December 31, |  |  |  |  |
|  | 2019 |  | 2018 |  | 2017 |
|  | (In thousands) |  |  |  |  |
| Cost of product and service revenues | $ | 5,648 |  |  | $ | 4,634 |  |  | $ | 3,478 |  |
| Research and development | 6,604 |  |  | 5,746 |  |  | 3,590 |  |
| Selling, general, and administrative | 21,797 |  |  | 18,505 |  |  | 14,789 |  |
| Total share-based compensation expense | $ | 34,049 |  |  | $ | 28,885 |  |  | $ | 21,857 |  |

[0000926326-20-000010:notes:258]
The Company did not capitalize any share-based compensation as inventory as such amounts were not material for the years ended December 31, 2019 and December 31, 2018. Income tax benefits realized from share-based compensation were $11.0 million, $6.5 million, and $8.2 million, for the years ended December 31, 2019, 2018, and 2017, respectively.

[0000926326-20-000010:notes:259]
In the first quarter of 2019, the Company modified the terms of its stock options by extending the post-employment exercise period for certain employees. The Company recorded share-based compensation expense related to this modification of approximately $0.2 million on the stock options modification date. As of December 31, 2019, share-based compensation expense related to unvested stock options impacted by the modification was approximately $0.6 million, which is expected to be recognized over the remaining weighted-average vesting period of 1.9 years.

[0000926326-20-000010:notes:260]
Stock Options and ESPP Shares

[0000926326-20-000010:notes:261]
The following assumptions were used to value stock options and ESPP shares granted pursuant to the Company’s equity incentive plans for the years ended December 31, 2019, 2018, and 2017:

[0000926326-20-000010:notes:262]
|  | Year Ended December 31, |  |  |  |  |
|  | 2019 |  | 2018 |  | 2017 |
| Stock options |  |  |  |  |  |
| Expected life, years | 4.4 |  | 4.8 |  | 4.7 |
| Expected volatility, % | 33.7 | % |  | 31.1 | % |  | 29.6 | % |
| Risk-free interest rate, % | 2.0 | % |  | 2.8 | % |  | 1.9 | % |
| Estimated forfeiture rate, % | 7.2 | % |  | 6.9 | % |  | 7.7 | % |
| Dividend yield, % | — | % |  | — | % |  | — | % |

[0000926326-20-000010:notes:263]
|  | Year Ended December 31, |  |  |  |  |
|  | 2019 |  | 2018 |  | 2017 |
| Employee stock purchase plan shares |  |  |  |  |  |
| Expected life, years | 0.5 - 2.0 |  | 0.5 - 2.0 |  | 0.5 - 2.0 |
| Expected volatility, % | 28.2% - 39.9% |  | 28.1% - 33.8% |  | 25.8% - 32.8% |
| Risk-free interest rate, % | 1.3% - 2.7% |  | 0.8% - 2.7% |  | 0.5% - 1.4% |
| Dividend yield, % | — | % |  | — | % |  | — | % |

[0000926326-20-000010:notes:264]
Stock Options Activity

[0000926326-20-000010:notes:265]
The following table summarizes the share option activity under the Company’s 2009 Plan during the year ended December 31, 2019:

[0000926326-20-000010:notes:266]
|  | Number ofShares |  | Weighted-AverageExercise Price |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |  |  |  |  |  |  |
| Outstanding at December 31, 2018 | 3,748 |  |  | $ | 41.27 |  |  | 7.6 |  | $ | 78,365 |  |
| Granted | 1,169 |  |  | 76.44 |  |  |  |  |  |
| Exercised | (744) |  |  | 33.83 |  |  |  |  |  |
| Expired | (10) |  |  | 37.79 |  |  |  |  |  |
| Forfeited | (261) |  |  | 48.57 |  |  |  |  |  |
| Outstanding at December 31, 2019 | 3,902 |  |  | $ | 52.75 |  |  | 7.7 |  | $ | 113,198 |  |
| Exercisable at December 31, 2019 | 1,580 |  |  | $ | 36.48 |  |  | 6.2 |  | $ | 71,485 |  |
| Vested and expected to vest at December 31, 2019 and thereafter | 3,677 |  |  | $ | 51.83 |  |  | 7.7 |  | $ | 110,048 |  |

[0000926326-20-000010:notes:267]
The weighted-average fair value per share of options granted during the years ended December 31, 2019, 2018, and 2017 was $23.54, $17.22, and $13.25, respectively. The intrinsic value of options exercised during the years ended December 31, 2019, 2018, and 2017 was $32.8 million, $20.1 million, and $18.2 million, respectively.

[0000926326-20-000010:notes:268]
As of December 31, 2019, total unrecognized compensation cost related to unvested stock options was $39.5 million, which is expected to be recognized over a weighted-average vesting period of 2.8 years.

[0000926326-20-000010:notes:269]
Employee Stock Purchase Plan Activity

[0000926326-20-000010:notes:270]
For the year ended December 31, 2019, employees purchased approximately 374,000 shares of common stock under the ESPP at a weighted-average price of $41.44. As of December 31, 2019, the unrecognized compensation cost related to the shares to be purchased under the ESPP was approximately $1.6 million and is expected to be recognized over a weighted-average period of 1.3 years.

[0000926326-20-000010:notes:271]
Restricted Stock Units (RSUs) and Restricted Stock Awards (RSAs)

[0000926326-20-000010:notes:272]
Summaries of the restricted stock activity under the 2009 Plan are presented below for the year ended December 31, 2019:

[0000926326-20-000010:notes:273]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |  |  |  |  |  |  |
| Restricted stock units |  |  |  |  |  |  |  |
| Outstanding at December 31, 2018 | 538 |  |  | $ | 51.52 |  |  | 1.6 |  | $ | 32,935 |  |
| Granted (Awarded) | 277 |  |  | 78.49 |  |  |  |  |  |
| Vested (Released) | (216) |  |  | 48.88 |  |  |  |  |  |
| Forfeited | (55) |  |  | 48.40 |  |  |  |  |  |
| Outstanding and unvested at December 31, 2019 | 544 |  |  | $ | 66.65 |  |  | 1.6 |  | $ | 44,492 |  |

[0000926326-20-000010:notes:274]
The weighted-average grant date fair value per share of RSUs granted during the years ended December 31, 2019, 2018, and 2017 was $78.49, $59.52, and $45.97, respectively. The total fair value of RSUs that vested in the years ended December 31, 2019, 2018, and 2017 was $10.6 million, $7.9 million, and $6.5 million, respectively.

[0000926326-20-000010:notes:275]
As of December 31, 2019, total unrecognized compensation cost related to RSUs was $31.5 million, which is expected to be recognized over the remaining weighted-average vesting period of 3.0 years.

[0000926326-20-000010:notes:276]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |  |  |  |  |  |  |  |
|  | (In thousands, except per share data) |  |  |  |  |  |  |  |  |  |
| Restricted stock awards |  |  |  |  |  |  |  |  |  |  |
| Outstanding at December 31, 2018 | 21 |  |  | $ | 46.60 |  |  |  |  |  |  |  |  |
| Granted (Awarded) | 17 |  |  | 81.86 |  |  |  |  |  |  |  |  |
| Vested (Released) | (21) |  |  | 46.96 |  |  |  |  |  |  |  |  |
| Outstanding and unvested at December 31, 2019 | 17 |  |  | $ | 81.92 |  |  |  |  |  |  |  |  |

[0000926326-20-000010:notes:277]
The weighted-average grant date fair value per share of RSAs granted during the years ended December 31, 2019, 2018, and 2017 was $81.86, $46.60, and $41.10, respectively. The total fair value of RSAs that vested in the years ended December 31, 2019, 2018, and 2017 was $1.0 million, for each period.

[0000926326-20-000010:notes:278]
As of December 31, 2019, total unrecognized compensation cost related to RSAs was $0.5 million, which is expected to be recognized over the remaining weighted-average vesting period of 0.4 years.

[0000926326-20-000010:notes:279]
Performance-Based Restricted Stock Units (PSUs)

[0000926326-20-000010:notes:280]
In 2018, the Company granted 110,432 PSUs to its executive officers, all of which became eligible for vesting upon the achievement of a certain level of shareholder return. In 2019, the Company granted 61,098 PSUs to its executive officers, all, none, or a portion of which may become eligible for vesting depending on the level of shareholder return for the period from March 1, 2019 through March 1, 2020.

[0000926326-20-000010:notes:281]
The fair value of a PSU award is determined using a Monte Carlo simulation model. The number of shares that vest at the end of the performance period depends on the percentile ranking of the total shareholder return for Omnicell stock over the performance period relative to the total shareholder return of each of the other companies in the NASDAQ Healthcare Index (the “Index”).

[0000926326-20-000010:notes:282]
For PSUs granted on February 13, 2019, stock price appreciation is calculated based on the trailing 20-day average stock price just prior to the first trading day of March 2019, compared to the trailing 20-day average stock price just prior to the first trading day of March 2020. For PSUs granted on February 6, 2018, stock price appreciation is calculated based on the trailing 20-day average stock price just prior to the first trading day of March 2018, compared to the trailing 20-day average stock price just prior to the first trading day of March 2019.

[0000926326-20-000010:notes:283]
On March 6, 2018, the Compensation Committee confirmed the Company's total stockholder return at the 60th percentile rank of the Index. This resulted in 100% of the 2017 PSUs, or 147,830 shares, as eligible for further time-based vesting. The eligible PSUs will vest as follows: 25% of the shares vested immediately on March 6, 2018 with the remaining shares vesting on a semi-annual basis period of 36 months commencing on June 15, 2018. Vesting is contingent upon continued service. Of the 147,830 shares eligible for time-based vesting under the 2017 PSUs, 81,322 shares, net of forfeitures, have vested as of December 31, 2019.

[0000926326-20-000010:notes:284]
On March 5, 2019, the Compensation Committee confirmed the Company's total stockholder return at the 90th percentile rank of the Index. This resulted in 100% of the 2018 PSUs, or 110,432 shares, as eligible for further time-based vesting. The eligible PSUs will vest as follows: 25% of the shares vested immediately on March 5, 2019 with the remaining shares vesting on a semi-annual basis period of 36 months commencing on June 15, 2019. Vesting is contingent upon continued service. Of the 110,432 shares eligible for time-based vesting under the 2018 PSUs, 46,376 shares, net of forfeitures, have vested as of December 31, 2019.

[0000926326-20-000010:notes:285]
A summary of the performance-based restricted stock activity under the 2009 Plan is presented below for the year ended December 31, 2019:

[0000926326-20-000010:notes:286]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value Per Unit |
|  | (In thousands, except per share data) |  |  |
| Outstanding at December 31, 2018 | 197 |  |  | $ | 34.83 |  |
| Granted | 71 |  |  | 73.38 |  |
| Vested | (101) |  |  | 34.37 |  |
| Forfeited | (33) |  |  | 33.84 |  |
| Outstanding and unvested at December 31, 2019 | 134 |  |  | $ | 55.82 |  |

[0000926326-20-000010:notes:287]
The weighted-average grant date fair value per share of PSUs granted during the years ended December 31, 2019, 2018, and 2017 was $73.38, $38.03, and $34.05, respectively. The total fair value of PSUs that vested in the years ended December 31, 2019, 2018, and 2017 was $3.5 million, $3.2 million, and $2.6 million, respectively.

[0000926326-20-000010:notes:288]
As of December 31, 2019, total unrecognized compensation cost related to PSUs was approximately $3.1 million, which is expected to be recognized over the remaining weighted-average period of 1.3 years.

[0000926326-20-000010:notes:289]
Summary of Shares Reserved for Future Issuance under Equity Incentive Plans

[0000926326-20-000010:notes:290]
The Company had the following ordinary shares reserved for future issuance under its equity incentive plans as of December 31, 2019:

[0000926326-20-000010:notes:291]
|  | Number of Shares |
|  | (In thousands) |
| Share options outstanding | 3,902 |  |
| Non-vested restricted stock awards | 696 |  |
| Shares authorized for future issuance | 2,873 |  |
| ESPP shares available for future issuance | 1,539 |  |
| Total shares reserved for future issuance |  | 9,010 |  |

[0000926326-20-000010:notes:292]
401(k) Plan
The Company has established a pre-tax savings plan under Section 401(k) of the Internal Revenue Code. The 401(k) Plan allows eligible employees in the United States to voluntarily contribute a portion of their pre-tax salary, subject to a maximum limit specified in the Internal Revenue Code. The Company matches 50% of employee contributions up to $3,000, annually. The Company’s contributions under this plan were $5.1 million, $4.6 million, and $3.8 million in the years ended December 31, 2019, 2018, and 2017, respectively.


## us-gaap:TreasuryStockTextBlock

[0000926326-20-000010:notes:293]
Stock Repurchase Program
On August 2, 2016, the Company’s Board of Directors (the “Board”) authorized a stock repurchase program providing for the repurchase of up to $50.0 million of the Company’s common stock (the “2016 Repurchase Program”). The 2016 Repurchase Program is in addition to the stock repurchase program approved by the Board on November 4, 2014 (the “2014 Repurchase Program”). As of December 31, 2019, the maximum dollar value of shares that may yet be purchased under the two repurchase programs was $54.9 million.

[0000926326-20-000010:notes:294]
The timing, price, and volume of repurchases are to be based on market conditions, relevant securities laws, and other factors. The stock repurchases may be made from time to time on the open market, in privately negotiated transactions, or pursuant to a Rule 10b-18 plan, subject to the terms and conditions of that certain A&R Credit Agreement, dated as of November 15, 2019, among the Company, the Lenders party thereto, and Wells Fargo Bank, National Association, as administrative agent. The stock repurchase programs do not obligate the Company to repurchase any specific number of shares, and the Company may terminate or suspend the repurchase programs at any time.

[0000926326-20-000010:notes:295]
During the years ended December 31, 2019, 2018, and 2017, the Company did not repurchase any of its outstanding common stock.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000926326-20-000010:notes:296]
Equity Offerings
On November 3, 2017, the Company entered into a Distribution Agreement (the “Distribution Agreement”) with J.P. Morgan Securities LLC, Wells Fargo Securities, LLC, and HSBC Securities (USA) Inc., as its sales agents, pursuant to which the Company may offer and sell from time to time through the sales agents up to $125.0 million maximum aggregate offering price of the Company’s common stock. Sales of the common stock pursuant to the Distribution Agreement may be made in negotiated transactions or transactions that are deemed to be “at the market” offerings as defined in Rule 415 under the Securities Act of 1933, including sales made directly on the Nasdaq Stock Market, or sales made to or through a market maker other than on an exchange.

[0000926326-20-000010:notes:297]
For the year ended December 31, 2017, the Company received gross proceeds of $14.7 million from sales of its common stock under the Distribution Agreement and incurred issuance costs of $0.8 million on sales of approximately 294,000 shares of its common stock at an average price of approximately $49.85 per share.

[0000926326-20-000010:notes:298]
For the year ended December 31, 2018, the Company received gross proceeds of $40.3 million from sales of its common stock under the Distribution Agreement and incurred issuance costs of $0.7 million on sales of approximately 557,000 shares of its common stock at an average price of approximately $72.40 per share.

[0000926326-20-000010:notes:299]
For the year ended December 31, 2019, the Company received gross proceeds of $38.5 million from sales of its common stock under the Distribution Agreement and incurred issuance costs of $0.7 million on sales of approximately 460,000 shares of its common stock at an average price of approximately $83.81 per share. As of December 31, 2019, the Company had an aggregate of $31.5 million available to be offered under the Distribution Agreement.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000926326-20-000010:notes:300]
Income Taxes
The following is a geographical breakdown of income (loss) before the provision for income taxes:

[0000926326-20-000010:notes:301]
|  | Year Ended December 31, |  |  |  |  |
|  | 2019 |  | 2018 |  | 2017 |
|  | (In thousands) |  |  |  |  |  |
| Domestic | $ | 81,641 |  |  | $ | 46,528 |  |  | $ | 25,280 |  |
| Foreign | (7,708) |  |  | (10,912) |  |  | (20,768) |  |
| Income (loss) before provision for income taxes | $ | 73,933 |  |  | $ | 35,616 |  |  | $ | 4,512 |  |

[0000926326-20-000010:notes:302]
The provision for (benefit from) income taxes consisted of the following:

[0000926326-20-000010:notes:303]
|  | Year Ended December 31, |  |  |  |  |
|  | 2019 |  | 2018 |  | 2017 |
|  | (In thousands) |  |  |  |  |  |
| Current: |  |  |  |  |  |
| Federal | $ | 8,006 |  |  | $ | 1,404 |  |  | $ | 2,430 |  |
| State | 4,549 |  |  | 1,832 |  |  | 1,852 |  |
| Foreign | 1,240 |  |  | 768 |  |  | 745 |  |
| Total current income taxes | 13,795 |  |  | 4,004 |  |  | 5,027 |  |
| Deferred: |  |  |  |  |  |
| Federal | (1,292) |  |  | 5,455 |  |  | (19,822) |  |
| State | (1,609) |  |  | (909) |  |  | (3,430) |  |
| Foreign | 1,701 |  |  | (10,663) |  |  | (7,781) |  |
| Total deferred income taxes | (1,200) |  |  | (6,117) |  |  | (31,033) |  |
| Total provision for (benefit from) income taxes | $ | 12,595 |  |  | $ | (2,113) |  |  | $ | (26,006) |  |

[0000926326-20-000010:notes:304]
The provision for (benefit from) income taxes differs from the amount computed by applying the statutory federal tax rate as follows:

[0000926326-20-000010:notes:305]
|  | Year Ended December 31, |  |  |  |  |
|  | 2019 |  | 2018 |  | 2017 |
|  | (In thousands) |  |  |  |  |  |
| U.S. federal tax provision at statutory rate | $ | 15,525 |  |  | $ | 7,479 |  |  | $ | 1,579 |  |
| State taxes | 2,258 |  |  | 651 |  |  | 224 |  |
| Non-deductible expenses | 2,898 |  |  | 1,424 |  |  | 1,373 |  |
| Uncertain tax positions | (2,472) |  |  | (412) |  |  | (295) |  |
| Share-based compensation tax benefit | (7,892) |  |  | (4,005) |  |  | (5,887) |  |
| Research tax credits | (3,805) |  |  | (3,230) |  |  | (3,233) |  |
| Domestic production deduction | — |  |  | — |  |  | (621) |  |
| Restructuring impact | 7,432 |  |  | (4,205) |  |  | — |  |
| Foreign derived intangible income deduction | (449) |  |  | (349) |  |  | — |  |
| Foreign rate differential | (1,424) |  |  | 561 |  |  | 938 |  |
| One-time impact of the Tax Act | — |  |  | — |  |  | (20,005) |  |
| Other | 524 |  |  | (27) |  |  | (79) |  |
| Total provision for (benefit from) income taxes | $ | 12,595 |  |  | $ | (2,113) |  |  | $ | (26,006) |  |

[0000926326-20-000010:notes:306]
Due to continuing global operational centralization activities during the year ended December 31, 2019, the Company recognized gain on the sale of certain intellectual property rights by Aesynt B.V. to Omnicell, Inc. and by Mach4 Automatisierungstechnik GmbH to Omnicell, Inc., which resulted in a tax expense, net of tax benefit, of $7.4 million. As a result of global operational centralization activities during the year ended December 31, 2018, the Company recognized $4.2 million of tax benefit associated with making a check-the-box election to treat Aesynt Holding Coöperatief U.A. (Netherlands) as a U.S. disregarded entity beginning in the first quarter of 2018.

[0000926326-20-000010:notes:307]
Significant components of the Company’s deferred tax assets (liabilities) were as follows:

[0000926326-20-000010:notes:308]
|  | December 31, |  |  |
|  | 2019 |  | 2018 |
|  | (In thousands) |  |  |
| Deferred tax assets (liabilities): |  |  |  |
| Deferred revenues | $ | 4,129 |  |  | $ | 2,943 |  |
| Share-based compensation | 6,483 |  |  | 5,531 |  |
| Inventory related items | 3,507 |  |  | 2,874 |  |
| Tax credit carryforwards | 13,472 |  |  | 7,413 |  |
| Reserves and accruals | 5,712 |  |  | 5,983 |  |
| Loss carryforwards | 9,484 |  |  | 17,515 |  |
| Lease liability | 15,471 |  |  | — |  |
| Other, net | 543 |  |  | 81 |  |
| Gross deferred tax assets | 58,801 |  |  | 42,340 |  |
| Valuation allowance | (1,186) |  |  | (1,256) |  |
| Total net deferred tax assets | 57,615 |  |  | 41,084 |  |
| Intangibles | (18,941) |  |  | (32,304) |  |
| Depreciation and amortization | (35,941) |  |  | (22,504) |  |
| Prepaid expenses | (13,395) |  |  | (12,563) |  |
| Right-of-use assets | (14,286) |  |  | — |  |
| Total deferred tax liabilities | (82,563) |  |  | (67,371) |  |
| Net deferred tax liabilities | $ | (24,948) |  |  | $ | (26,287) |  |

[0000926326-20-000010:notes:309]
Deferred income tax assets (liabilities) are provided for temporary differences that will result in future tax deductions or future taxable income, as well as the future benefit of tax credit carryforwards. The Company recognizes deferred tax assets to the extent that it believes these assets are more likely than not to be realized. In making such a determination, the Company considers all available positive and negative evidence, including future reversals of existing temporary differences, projected future taxable income, tax planning strategies, and results of recent operations. On the basis of this evaluation, as of December 31, 2019, $1.2 million of valuation allowance was recorded on certain foreign net operating losses carried forward, as the Company believes that such deferred tax assets are not more likely than not to be realized.

[0000926326-20-000010:notes:310]
As of December 31, 2019, the Company had $3.2 million of federal net operating loss carryforwards expiring 2037, $7.4 million of state net operating loss carryforwards expiring at various dates beginning 2023, and $29.5 million of foreign net operating loss carryforwards expiring at various dates beginning 2024. For the year ended December 31, 2019, the Company did not generate a net operating loss. For income tax purposes, the Company has federal and California research tax credits carryforwards of $3.1 million and $15.0 million, respectively. Federal research tax credit carryforwards from prior years will begin to expire in 2035. California credits are available indefinitely to reduce cash taxes payable.

[0000926326-20-000010:notes:311]
It is the Company's practice and intention to reinvest the earnings of its non-U.S. subsidiaries in those operations. As of December 31, 2019, the Company has not made a provision for U.S. federal income, withholding, and state income taxes on the outside basis difference related to certain foreign subsidiaries because earnings are intended to be indefinitely reinvested in operations outside the U.S.

[0000926326-20-000010:notes:312]
The Company files income tax returns in the United States and various states and foreign jurisdictions. In the normal course of business, the Company is subject to examination by taxing authorities, including major jurisdictions such as the United States, Germany, Italy, Netherlands, and the United Kingdom. With few exceptions, as of December 31, 2019, the Company was no longer subject to U.S., state, and foreign examination for years before 2016, 2015, and 2015, respectively.

[0000926326-20-000010:notes:313]
The aggregate change in the balance of gross unrecognized tax benefits, which excludes interest and penalties, for the three years ended December 31, 2019 was as follows:

[0000926326-20-000010:notes:314]
|  | (In thousands) |  |
| Balance as of December 31, 2016 | $ | 11,616 |  |
| Increases related to tax positions taken during a prior period | 503 |  |
| Decreases related to tax positions taken during the prior period | (1,782) |  |
| Increases related to tax positions taken during the current period | 805 |  |
| Decreases related to settlements | — |  |
| Decreases related to expiration of statute of limitations | (401) |  |
| Balance as of December 31, 2017 | 10,741 |  |
| Increases related to tax positions taken during a prior period | 19 |  |
| Decreases related to tax positions taken during the prior period | (1,257) |  |
| Increases related to tax positions taken during the current period | 870 |  |
| Decreases related to settlements | — |  |
| Decreases related to expiration of statute of limitations | (412) |  |
| Balance as of December 31, 2018 | 9,961 |  |
| Increases related to tax positions taken during a prior period | 10 |  |
| Decreases related to tax positions taken during the prior period | (6) |  |
| Increases related to tax positions taken during the current period | 9,282 |  |
| Decreases related to settlements | — |  |
| Decreases related to expiration of statute of limitations | (2,472) |  |
| Balance as of December 31, 2019 | $ | 16,775 |  |

[0000926326-20-000010:notes:315]
The total amounts of gross unrecognized tax benefit that, if realized, would favorably affect the Company's effective income tax rate in future periods, was $16.8 million as of December 31, 2019. The Company recognizes interest and/or penalties related to uncertain tax positions in interest and other income (expense), net in Consolidated Statements of Operations, accruing $0.5 million, $0.5 million, and $0.3 million for the years ended December 31, 2019, 2018, and 2017, respectively. Accrued interest and penalties are included within other long-term liabilities on the Consolidated Balance Sheets. The combined amount of cumulative accrued interest and penalties was approximately $1.0 million, $1.4 million, and $1.4 million for the years ended December 31, 2019, 2018, and 2017, respectively. The Company does not believe there will be any significant changes in its unrecognized tax positions over the next twelve months.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000926326-20-000010:notes:316]
Restructuring Expenses
In the fourth quarter of 2018, the Company announced a company-wide organizational realignment initiative in order to align its organizational infrastructure for future expected growth. During the year ended December 31, 2018, the Company incurred and accrued for $1.3 million of restructuring expenses, which includes severance and consulting-related expenses. As of December 31, 2019, there was no unpaid balance related to this realignment initiative.

[0000926326-20-000010:notes:317]
On March 2, 2018, the Company initiated the realignment of its Automation and Analytics commercial group in North America and France. During the year ended December 31, 2018, the Company accrued and paid out $3.0 million of employee severance costs and related expenses. 
On February 15, 2017, the Company announced its plan to reduce its workforce by approximately 100 full-time employees and close the Company’s Nashville, Tennessee, and Slovenia facilities, which was completed in fiscal year 2017. The total cost for the plan was $4.2 million, which includes employee severance costs of approximately $3.7 million, and facility-related costs of approximately $0.6 million. For the year ended December 31, 2017, the Company made payments of $4.2 million and the restructuring program was completed.


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000926326-20-000010:notes:318]
SCHEDULE II

[0000926326-20-000010:notes:319]
VALUATION AND QUALIFYING ACCOUNTS

[0000926326-20-000010:notes:320]
|  | Balance atBeginning of Period (1) |  | Charged (Credited) to Costs and Expenses (2) |  | Debited (Credited) to Other Accounts (3) |  | AmountsWritten Off (4) |  | Translation Adjustments (5) |  | Balance atEnd of Period (1) |
|  | (In thousands) |  |  |  |  |  |  |  |  |  |  |
| Year ended December 31, 2017 |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable | $ | 4,796 |  |  | $ | 1,008 |  |  | $ | 3 |  |  | $ | (402) |  |  | $ | 333 |  |  | $ | 5,738 |  |
| Investment in sales-type leases | 254 |  |  | (62) |  |  | — |  |  | — |  |  | — |  |  | 192 |  |
| Total allowances deducted from assets | $ | 5,050 |  |  | $ | 946 |  |  | $ | 3 |  |  | $ | (402) |  |  | $ | 333 |  |  | $ | 5,930 |  |
| Year ended December 31, 2018 |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable | $ | 5,738 |  |  | $ | (127) |  |  | $ | 12 |  |  | $ | (3,010) |  |  | $ | (31) |  |  | $ | 2,582 |  |
| Investment in sales-type leases | 192 |  |  | 10 |  |  | 12 |  |  | — |  |  | — |  |  | 214 |  |
| Total allowances deducted from assets | $ | 5,930 |  |  | $ | (117) |  |  | $ | 24 |  |  | $ | (3,010) |  |  | $ | (31) |  |  | $ | 2,796 |  |
| Year ended December 31, 2019 |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable | $ | 2,582 |  |  | $ | 2,488 |  |  | $ | — |  |  | $ | (1,986) |  |  | $ | 143 |  |  | $ | 3,227 |  |
| Investment in sales-type leases | 214 |  |  | 11 |  |  | — |  |  | — |  |  | — |  |  | 225 |  |
| Total allowances deducted from assets | $ | 2,796 |  |  | $ | 2,499 |  |  | $ | — |  |  | $ | (1,986) |  |  | $ | 143 |  |  | $ | 3,452 |  |

[0000926326-20-000010:notes:321]
__________________________________________________

[0000926326-20-000010:notes:322]
(1)Allowance for doubtful accounts.

[0000926326-20-000010:notes:323]
(2)Represents amounts charged and credited to bad debt expense.

[0000926326-20-000010:notes:324]
(3)Represents amounts debited to trade accounts receivable as recoveries, increasing the allowance.

[0000926326-20-000010:notes:325]
(4)Represents amounts written-off from the allowance and accounts receivable.

[0000926326-20-000010:notes:326]
(5)Represents foreign currency translation adjustments.
