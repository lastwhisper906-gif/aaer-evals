# OMCL MD&A — 0000926326-13-000016


## mdna

[0000926326-13-000016:mdna:1]
[same as prior period, unchanged from 0000926326-13-000013:mdna:1]

[0000926326-13-000016:mdna:2]
[same as prior period, unchanged from 0000926326-13-000013:mdna:2]

[0000926326-13-000016:mdna:3]
[same as prior period, unchanged from 0000926326-13-000013:mdna:3]

[0000926326-13-000016:mdna:4]
[same as prior period, unchanged from 0000926326-13-000013:mdna:4]

[0000926326-13-000016:mdna:5]
[same as prior period, unchanged from 0000926326-13-000013:mdna:5]

[0000926326-13-000016:mdna:6]
[same as prior period, unchanged from 0000926326-13-000013:mdna:6]

[0000926326-13-000016:mdna:7]
[same as prior period, unchanged from 0000926326-13-000013:mdna:7]

[0000926326-13-000016:mdna:8]
[same as prior period, unchanged from 0000926326-13-000013:mdna:8]

[0000926326-13-000016:mdna:9]
[same as prior period, unchanged from 0000926326-13-000013:mdna:9]

[0000926326-13-000016:mdna:10]
[same as prior period, unchanged from 0000926326-13-000013:mdna:10]

[0000926326-13-000016:mdna:11]
[same as prior period, unchanged from 0000926326-13-000013:mdna:11]

[0000926326-13-000016:mdna:12]
[same as prior period, unchanged from 0000926326-13-000013:mdna:12]

[0000926326-13-000016:mdna:13]
In some cases, you can identify forward-looking statements by terms such as "anticipates," "believes," "could," "estimates," "expects," "intends," "may," "plans," "potential," "predicts," "projects," "should," "will," "would" and similar expressions intended to identify forward-looking statements. Forward-looking statements reflect our current views with respect to future events, are based on assumptions and are subject to risks and uncertainties.  We discuss many of these risks in this Quarterly Report on Form 10-Q in greater detail in Part II - Section 1A. “Risk Factors” below. Given these uncertainties, you should not place undue reliance on these forward-looking statements. Also, forward-looking statements represent our estimates and assumptions only as of the date of this Quarterly Report on Form 10-Q. You should also read our Annual Report on Form 10-K and the documents that we reference in the Annual Report on Form 10-K and have filed as exhibits, completely and with the understanding that our actual future results may be materially different from what we expect.  All references in this report to "Omnicell, Inc.," "Omnicell," "our," "us," "we," or the "Company" collectively refer to Omnicell, Inc., a Delaware corporation, and its subsidiaries.

[0000926326-13-000016:mdna:14]
[same as prior period, unchanged from 0000926326-13-000013:mdna:15]

[0000926326-13-000016:mdna:15]
We are a leading provider of automation and business information solutions enabling healthcare systems to streamline the medication administration process and manage costly medical supplies for increased operational efficiency and enhanced patient safety. Our automation, analytics and medication adherence solutions are designed to enable healthcare facilities to acquire, manage, dispense and administer medications and medical-surgical supplies and are intended to enhance patient safety, reduce medication errors, reduce operating costs, improve workflow, and increase operational efficiency.

[0000926326-13-000016:mdna:16]
Approximately 2,800 hospitals use one or more of our products, of which more than 1,800 hospitals in the United States have installed our automated hardware/software solutions for controlling, dispensing, acquiring, verifying, tracking and analyzing medications and medical and surgical supplies. Approximately 6,000 institutional and retail pharmacies use our medication adherence packaging solutions.

[0000926326-13-000016:mdna:17]
[same as prior period, unchanged from 0000926326-13-000013:mdna:18]

[0000926326-13-000016:mdna:18]
[same as prior period, unchanged from 0000926326-13-000013:mdna:19]

[0000926326-13-000016:mdna:19]
[same as prior period, unchanged from 0000926326-13-000013:mdna:20]

[0000926326-13-000016:mdna:20]
[same as prior period, unchanged from 0000926326-13-000013:mdna:21]

[0000926326-13-000016:mdna:21]
[same as prior period, unchanged from 0000926326-13-000013:mdna:22]

[0000926326-13-000016:mdna:22]
[same as prior period, unchanged from 0000926326-13-000013:mdna:23]

[0000926326-13-000016:mdna:23]
[same as prior period, unchanged from 0000926326-13-000013:mdna:24]

[0000926326-13-000016:mdna:24]
Similar to our medication solutions, our medical and surgical supply systems provide acute care hospitals control over consumable supplies critical to providing quality healthcare. Our solutions provide inventory control software that is designed to ensure critical supplies are always stocked in the right locations. At the same time, usage tracking helps hospital administrators to ensure that money is not wasted on excessive stores of supplies and helps optimize reimbursement by improving charge capture. Our systems automate the tracking of activities in perioperative areas such as the operating room and catheter lab, including tracking implantable tissue grafts for additional patient safety and regulatory compliance.

[0000926326-13-000016:mdna:25]
[same as prior period, unchanged from 0000926326-13-000013:mdna:27]

[0000926326-13-000016:mdna:26]
[same as prior period, unchanged from 0000926326-13-000013:mdna:28]

[0000926326-13-000016:mdna:27]
Our Non-Acute Care product lines were primarily added to our solutions through the acquisition of MTS Medication Technologies, Inc. ("MTS"), a worldwide provider of medication adherence packaging systems, and a wholly-owned Omnicell subsidiary. MTS manufactures proprietary medication dispensing systems and related products for use by institutional pharmacies servicing long-term care and correctional facilities and retail pharmacies servicing patients caring for themselves at home. These systems use consumable medication punch cards and specialized machines that allow the pharmacies to automatically or semi-automatically assemble, fill and seal drugs into medication punch cards representing a weekly or monthly supply of a patient's medication. The use of these cards and machines provides a cost-effective customized package personalized to the patient. The punch card medication dispensing system provides tamper evident packaging and promotes medication compliance.

[0000926326-13-000016:mdna:28]
[same as prior period, unchanged from 0000926326-13-000013:mdna:30]

[0000926326-13-000016:mdna:29]
Our Non-Acute Care segment manufactures and sells consumable medication blister cards, packaging equipment and ancillary products, as well as automated dispensing equipment used in long term care facilities throughout the United States, Canada, Europe and Australia. This segment's customers are predominantly institutional and independent retail pharmacies that supply nursing homes, assisted living and correctional facilities with prescription medications for their patients. We manufacture our proprietary consumable blister cards and most of our packaging equipment in our own facilities. This manufacturing process uses integrated equipment for manufacturing the consumable medication blister cards. In addition, we utilize the services of contract manufacturers for some of our packaging equipment. We distribute products directly in the United Kingdom and in Germany through our subsidiaries in those countries.

[0000926326-13-000016:mdna:30]
[same as prior period, unchanged from 0000926326-13-000013:mdna:32]

[0000926326-13-000016:mdna:31]
[same as prior period, unchanged from 0000926326-13-000013:mdna:33]

[0000926326-13-000016:mdna:32]
[same as prior period, unchanged from 0000926326-13-000013:mdna:34]

[0000926326-13-000016:mdna:33]
[same as prior period, unchanged from 0000926326-13-000013:mdna:35]

[0000926326-13-000016:mdna:34]
[same as prior period, unchanged from 0000926326-13-000013:mdna:36]

[0000926326-13-000016:mdna:35]
[same as prior period, unchanged from 0000926326-13-000013:mdna:37]

[0000926326-13-000016:mdna:36]
29

[0000926326-13-000016:mdna:37]
[same as prior period, unchanged from 0000926326-13-000013:mdna:38]

[0000926326-13-000016:mdna:38]
[same as prior period, unchanged from 0000926326-13-000013:mdna:39]

[0000926326-13-000016:mdna:39]
[same as prior period, unchanged from 0000926326-13-000013:mdna:40]

[0000926326-13-000016:mdna:40]
[same as prior period, unchanged from 0000926326-13-000013:mdna:41]

[0000926326-13-000016:mdna:41]
[same as prior period, unchanged from 0000926326-13-000013:mdna:42]

[0000926326-13-000016:mdna:42]
[same as prior period, unchanged from 0000926326-13-000013:mdna:43]

[0000926326-13-000016:mdna:43]
Operations During the Three and Nine Months Ended September 30, 2013

[0000926326-13-000016:mdna:44]
The consolidated operating results presented for the nine months ended September 30, 2013 and the nine months ended September 30, 2012, reflect the impact of the acquisition of MTS since May 21, 2012 as a part of the Non-Acute Care segment.

[0000926326-13-000016:mdna:45]
Revenues grew year-over-year for both product and services, with overall revenue growth of 11.5%, comparing $94.0 million for the third quarter of 2013 with $84.3 million for the third quarter of 2012. Overall revenue growth was 22.8% for the nine months ended September 30, 2013 comparing $274.8 million with $223.9 million for the same period in 2012. Much of the growth was a result of the acquisition of MTS, which now comprises a substantial portion of the Non-Acute Care segment, and whose prior year operating results were not included in our consolidated operating results prior to the date of acquisition.

[0000926326-13-000016:mdna:46]
For the three months ended September 30, 2013, the Non-Acute Care segment contributed $22.2 million and $1.2 million to the product and service revenue, respectively as compared to $18.7 million and $1.2 million during the same period in 2012. The Acute Care segment contributed revenues of $53.3 million and $17.3 million to product and service revenue respectively, for the three months ended September 30, 2013 as compared to $48.8 million and $15.6 million during the same period in 2012. Overall product and service gross margins increased by $6.0 million, or 12.9% for the three months ended September 30, 2013 as compared to the same period in 2012.

[0000926326-13-000016:mdna:47]
For the nine months ended September 30, 2013, the Non-Acute Care segment contributed $66.4 million and $3.7 million, respectively, to the overall product and service revenue as compared to $30.2 million and $2.3 million during the same period in 2012. The Acute Care segment contributed revenues of $153.9 million and $50.8 million to product and service revenue, respectively, for the nine months ended September 30, 2013 as compared to $145.0 million and $46.3 million during the same period in 2012. Overall product and service gross margins increased by $25.6 million, or 21.1% for the nine months ended September 30, 2013 as compared to the same period in 2012.

[0000926326-13-000016:mdna:48]
During the three months ended September 30, 2013, total revenue remained relatively flat at $94.0 million as compared with $93.7 million for the three months ended June 30, 2013 with service revenues accounting for the majority of this increase. Overall gross margins for the third quarter of 2013 increased to 55.3% from 52.7% in the three months ended June 30, 2013. Product gross margins increased to 55.0% on revenue of $75.5 million for the three months ended September 30, 2013 as compared with 52.0% on revenue of $75.6 million during the second quarter of 2013. Service gross margins also increased, to 56.7% on revenue of $18.5 million as compared to 55.6% on $18.1 million in revenue during the second quarter of 2013.

[0000926326-13-000016:mdna:49]
Cash, cash equivalents and short-term investments increased by $53.9 million during the nine months ended September 30, 2013, to $116.2 million from $62.3 million at December 31, 2012 primarily due to increased profitability, working capital improvements and cash received for shares issued under our stock option and employee stock purchase plans.

[0000926326-13-000016:mdna:50]
During the nine months ended September 30, 2013, we implemented a reorganization within our Non-Acute Care segment. This reorganization reduced headcount slightly and as a result, we incurred $0.7 million in severance and related expenses and an additional $0.4 million related to accelerated stock option vesting in the first quarter of 2013. This reorganization is intended to promote a stronger integration strategy, customer and segment focus, and future growth. As our business evolves, we will continue to assess our segments which could result in future modifications to the current presentation.

[0000926326-13-000016:mdna:51]
[same as prior period, unchanged from 0000926326-13-000013:mdna:52]

[0000926326-13-000016:mdna:52]
Management's discussion and analysis of our financial condition and results of operations are based on our consolidated financial statements, which have been prepared in accordance with U.S. GAAP. The preparation of these financial statements requires us to make certain estimates and assumptions that affect the reported amounts of assets and liabilities, disclosure of any contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues

[0000926326-13-000016:mdna:53]
and expenses during the reporting periods. We regularly review our estimates and assumptions, which are based on historical experience and various other factors that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of certain assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates and assumptions. We believe that the following critical accounting policies are affected by significant judgments and estimates used in the preparation of our condensed consolidated financial statements:

[0000926326-13-000016:mdna:54]
[same as prior period, unchanged from 0000926326-13-000013:mdna:54]

[0000926326-13-000016:mdna:55]
[same as prior period, unchanged from 0000926326-13-000013:mdna:55]

[0000926326-13-000016:mdna:56]
[same as prior period, unchanged from 0000926326-13-000013:mdna:56]

[0000926326-13-000016:mdna:57]
[same as prior period, unchanged from 0000926326-13-000013:mdna:57]

[0000926326-13-000016:mdna:58]
[same as prior period, unchanged from 0000926326-13-000013:mdna:58]

[0000926326-13-000016:mdna:59]
[same as prior period, unchanged from 0000926326-13-000013:mdna:59]

[0000926326-13-000016:mdna:60]
During the nine months ended September 30, 2013, there were no significant changes in our critical accounting policies and estimates.

[0000926326-13-000016:mdna:61]
[same as prior period, unchanged from 0000926326-13-000013:mdna:61]

[0000926326-13-000016:mdna:62]
Recently Adopted Accounting Standards

[0000926326-13-000016:mdna:63]
[same as prior period, unchanged from 0000926326-13-000013:mdna:63]

[0000926326-13-000016:mdna:64]
[same as prior period, unchanged from 0000926326-13-000013:mdna:64]

[0000926326-13-000016:mdna:65]
The table below shows the components of our consolidated results of operations as percentages of total revenues for the three months and nine months ended September 30, 2013 and 2012 (in thousands, except percentages):

[0000926326-13-000016:mdna:66]
|  | Three Months Ended September 30, |  |
|  | 2013 |  | 2012 |  |
|  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product revenue | $ | 75,508 |  |  | 80.3 | % |  | $ | 67,446 |  |  | 80.0 | % |  |
| Service and other revenues | 18,531 |  |  | 19.7 | % |  | 16,885 |  |  | 20.0 | % |  |
| Total revenues | 94,039 |  |  | 100.0 | % |  | 84,331 |  |  | 100.0 | % |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product revenues | 33,977 |  |  | 36.1 | % |  | 30,636 |  |  | 36.3 | % |  |
| Cost of service and other revenues | 8,022 |  |  | 8.5 | % |  | 7,608 |  |  | 9.0 | % |  |
| Total cost of revenues | 41,999 |  |  | 44.6 | % |  | 38,244 |  |  | 45.3 | % |  |
| Gross profit | 52,040 |  |  | 55.4 | % |  | 46,087 |  |  | 54.7 | % |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 6,561 |  |  | 7.0 | % |  | 5,545 |  |  | 6.6 | % |  |
| Selling, general and administrative | 34,762 |  |  | 37.0 | % |  | 29,316 |  |  | 34.8 | % |  |
| Total operating expenses | 41,323 |  |  | 44.0 | % |  | 34,861 |  |  | 41.4 | % |  |
| Income from operations | 10,717 |  |  | 11.4 | % |  | 11,226 |  |  | 13.3 | % |  |
| Interest and other income (expense), net | 25 |  |  | — | % |  | 34 |  |  | — | % |  |
| Income before provision for income taxes | 10,742 |  |  | 11.4 | % |  | 11,260 |  |  | 13.3 | % |  |
| Provision for income taxes | 2,987 |  |  | 3.2 | % |  | 4,340 |  |  | 5.1 | % |  |
| Net income | $ | 7,755 |  |  | 8.2 | % |  | $ | 6,920 |  |  | 8.2 | % |  |

[0000926326-13-000016:mdna:67]
32

[0000926326-13-000016:mdna:68]
|  | Nine Months Ended September 30, |
|  | 2013 |  | 2012 |
|  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |
| Product revenue | $ | 220,325 |  |  | 80.2 | % |  | $ | 175,239 |  |  | 78.3 | % |
| Service and other revenues | 54,510 |  |  | 19.8 | % |  | 48,619 |  |  | 21.7 | % |
| Total revenues | 274,835 |  |  | 100.0 | % |  | 223,858 |  |  | 100.0 | % |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product revenues | 103,810 |  |  | 37.8 | % |  | 79,532 |  |  | 35.5 | % |
| Cost of service and other revenues | 24,250 |  |  | 8.8 | % |  | 23,114 |  |  | 10.3 | % |
| Total cost of revenues | 128,060 |  |  | 46.6 | % |  | 102,646 |  |  | 45.8 | % |
| Gross profit | 146,775 |  |  | 53.4 | % |  | 121,212 |  |  | 54.2 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 21,665 |  |  | 7.9 | % |  | 17,538 |  |  | 7.8 | % |
| Selling, general and administrative | 100,866 |  |  | 36.7 | % |  | 86,382 |  |  | 38.6 | % |
| Total operating expenses | 122,531 |  |  | 44.6 | % |  | 103,920 |  |  | 46.4 | % |
| Income from operations | 24,244 |  |  | 8.9 | % |  | 17,292 |  |  | 7.8 | % |
| Interest and other income (expense), net | (134 | ) |  | — | % |  | 57 |  |  | — | % |
| Income before provision for income taxes | 24,110 |  |  | 8.9 | % |  | 17,349 |  |  | 7.8 | % |
| Provision for income taxes | 6,954 |  |  | 2.5 | % |  | 6,703 |  |  | 3.0 | % |
| Net income | $ | 17,156 |  |  | 6.4 | % |  | $ | 10,646 |  |  | 4.8 | % |

[0000926326-13-000016:mdna:69]
[same as prior period, unchanged from 0000926326-13-000013:mdna:70]

[0000926326-13-000016:mdna:70]
Effective in the second quarter of 2013, our management changed its methodology for allocating certain expenses to its reportable segments. We have reclassified segment operating results for the three and nine months ended September 30, 2012 to conform to the 2013 presentation.

[0000926326-13-000016:mdna:71]
[same as prior period, unchanged from 0000926326-13-000013:mdna:71]

[0000926326-13-000016:mdna:72]
The table below shows our consolidated product revenues, cost of product revenues and gross profit for the three months and nine months ended September 30, 2013 and 2012 and the percentage changes between those periods (in thousands, except percentages):

[0000926326-13-000016:mdna:73]
|  | Three Months Ended September 30, |
|  | 2013 |  | 2012 |  | % Change |
| Product revenues | $ | 75,508 |  |  | $ | 67,446 |  |  | 12.0 | % |
| Cost of product revenues | 33,977 |  |  | 30,636 |  |  | 10.9 | % |
| Gross profit | $ | 41,531 |  |  | $ | 36,810 |  |  | 12.8 | % |
| Gross margin | 55.0 | % |  | 54.6 | % |  | 0.4 | % |

[0000926326-13-000016:mdna:74]
|  | Nine Months Ended September 30, |
|  | 2013 |  | 2012 |  | % Change |
| Product revenues | $ | 220,325 |  |  | $ | 175,239 |  |  | 25.7 | % |
| Cost of product revenues | 103,810 |  |  | 79,532 |  |  | 30.5 | % |
| Gross profit | $ | 116,515 |  |  | $ | 95,707 |  |  | 21.7 | % |
| Gross margin | 52.9 | % |  | 54.6 | % |  | (1.7 | )% |

[0000926326-13-000016:mdna:75]
Product revenues increased by $8.1 million, or 12.0%, in the three months ended September 30, 2013 as compared to the same period in 2012. Product revenues increased by $45.1 million, or 25.7%, in the nine months ended September 30, 2013 as compared to the same period in 2012.

[0000926326-13-000016:mdna:76]
The overall increase in product revenues for the three months ended September 30, 2013 was primarily driven by increased installations of our automation products in both the Non-Acute Care and Acute Care segments. The Non-Acute Care segment contributed $22.2 million as compared with $18.7 million for the same period last year. Our Acute Care segment contributed $53.3 million in product revenue for the three months ended September 30, 2013 as compared to $48.8 million for the same period in 2012.

[0000926326-13-000016:mdna:77]
The overall increase in product revenues for the nine months ended September 30, 2013 was primarily driven by a full nine month contribution of MTS activities as a part of our Non-Acute Care segment, which contributed $66.4 million during the period. This compared to $30.2 million in the same nine month period in 2012. Our Acute Care segment contributed $153.9 million in product revenue for the nine months ended September 30, 2013 compared to $145.0 million in the same nine month period in 2012.

[0000926326-13-000016:mdna:78]
We anticipate our revenues will continue to increase in 2013 compared to the same periods in 2012, as we fulfill our existing orders. Additionally, year over year revenue growth for the remainder of 2013 will continue to benefit from the contribution of our Non-Acute Care segment, including those of MTS, which we began to consolidate on May 21, 2012. Our ability to continue to grow revenue is dependent on our ability to continue to obtain orders from customers, our ability to produce quality consumables to fulfill customer demand, the volume of installations we are able to complete and our ability to meet customer needs by providing a quality installation experience and our flexibility in manpower allocations among customers to complete installations on a timely basis. The timing of our product revenues for equipment is primarily dependent on when our customers’ schedules allow for installations.

[0000926326-13-000016:mdna:79]
Cost of product revenues increased by $3.3 million, or 10.9%, in the three months ended September 30, 2013 as compared to the same period in 2012. Cost of product revenues increased by $24.3 million, or 30.5%, in the nine months ended September 30, 2013 as compared to the same period in 2012.

[0000926326-13-000016:mdna:80]
The Non-Acute Care segment contributed product costs of $12.8 million for the three months ended September 30, 2013. Our Acute Care product cost increased by $1.4 million to $21.2 million, which is primarily a function of changes in revenue and product mix.

[0000926326-13-000016:mdna:81]
The increase in cost of product revenues for the nine months ended September 30, 2013 was primarily a result of a full nine months of Non-Acute Care product costs of $38.6 million. Our Acute Care product cost increased by $4.8 million to $65.2 million for the nine months ended September 30, 2013 as a result of changes in revenue and product mix.

[0000926326-13-000016:mdna:82]
Gross profit on product revenue increased by $4.7 million, or 12.8%, in the three months ended September 30, 2013 as compared to the same period in 2012. Gross profit on product revenue increased by $20.8 million, or 21.7%, in the nine months ended September 30, 2013 as compared to the same period in 2012. Our Non-Acute Care segment gross profit on product revenue increased $1.6 million and $16.7 million for the three months and nine months ended September 30, 2013, respectively. Our Acute Care gross profit on product revenue increased by $3.2 million and $4.1 million for the three months and nine months ended September 30, 2013, respectively, as compared to the same period in 2012 primarily due to changes in product mix.

[0000926326-13-000016:mdna:83]
[same as prior period, unchanged from 0000926326-13-000013:mdna:80]

[0000926326-13-000016:mdna:84]
The table below shows our service and other revenues, cost of service and other revenues and gross profit for the three months and nine months ended September 30, 2013 and 2012 and the percentage change between those periods (in thousands, except percentages):

[0000926326-13-000016:mdna:85]
|  | Three Months Ended September 30, |
|  | 2013 |  | 2012 |  | % Change |
| Service and other revenues | $ | 18,531 |  |  | $ | 16,885 |  |  | 9.7 | % |
| Cost of service and other revenues | 8,022 |  |  | 7,608 |  |  | 5.4 | % |
| Gross profit | $ | 10,509 |  |  | $ | 9,277 |  |  | 13.3 | % |
| Gross margin | 56.7 | % |  | 54.9 | % |  | 1.8 | % |

[0000926326-13-000016:mdna:86]
34

[0000926326-13-000016:mdna:87]
|  | Nine Months Ended September 30, |
|  | 2013 |  | 2012 |  | % Change |
| Service and other revenues | $ | 54,510 |  |  | $ | 48,619 |  |  | 12.1 | % |
| Cost of service and other revenues | 24,250 |  |  | 23,114 |  |  | 4.9 | % |
| Gross profit | $ | 30,260 |  |  | $ | 25,505 |  |  | 18.6 | % |
| Gross margin | 55.5 | % |  | 52.5 | % |  | 3.0 | % |

[0000926326-13-000016:mdna:88]
Service and other revenues include revenues from service and maintenance contracts, rentals of automation systems, and training and professional services. Service and other revenues increased by $1.6 million, or 9.7%, in the three months ended September 30, 2013 as compared to the same period in 2012. Service and other revenues increased by $5.9 million, or 12.1%, in the nine months ended September 30, 2013 as compared to the same period in 2012. These increases in service and other revenues were primarily the result of our installation of automation systems during the year which increases the installed base, adding more automation systems under service contracts.

[0000926326-13-000016:mdna:89]
Our Non-Acute Care segment contributed services and other revenues of $1.2 million for the three months ended September 30, 2013 consistent with the same period in 2012. Our Acute Care segment contributed $17.3 million in services and other revenues for the three months ended September 30, 2013 as compared to $15.6 million for the same period in 2012.

[0000926326-13-000016:mdna:90]
Our Non-Acute Care segment contributed services and other revenues of $3.7 million for the nine months ended September 30, 2013 compared to $2.3 million for the same period in 2012 driven by services for MTS branded products after the acquisition of MTS in 2012. Our Acute Care segment contributed $50.8 million in service and other revenues for the nine months ended September 30, 2013 and $46.3 million for the same period in 2012.

[0000926326-13-000016:mdna:91]
Cost of service and other revenues increased by $0.4 million, or 5.4%, in the three months ended September 30, 2013 as compared to the same period in 2012. The increase in cost of service and other revenues was primarily the result of an increase in the costs associated with increased service revenues as a result of expansion in our Acute Care segment installed base of automation systems. Cost of service and other revenues increased by $1.1 million, or 4.9%, in the nine months ended September 30, 2013 as compared to the same period in 2012, primarily driven by a full nine months of costs attributable to our Non-Acute Care segment of $1.7 million. Our Acute Care cost of service and other revenues was relatively flat as compared with the same period a year ago as a result of cost reduction efforts that resulted in revenues growing at a faster rate than costs.

[0000926326-13-000016:mdna:92]
Gross profit on service and other revenues increased by $1.2 million, or 13.3%, in the three months ended September 30, 2013 as compared to the same period in 2012. Gross profit on service and other revenues increased by $4.8 million, or 18.6%, in the nine months ended September 30, 2013 as compared to the same period in 2012. The increase in gross profit on service and other revenues was primarily due to increased revenues from an expanded installed base with only a slight increase in associated service costs. Gross profit on service and other revenues from our Non-Acute Care segment was $0.6 million and from our Acute Care segment was $9.9 million in the three months ended September 30, 2013. Our Acute Care gross profit on service and other revenues increased by $1.3 million and $4.5 million for the three months and nine months ended September 30, 2013, respectively as compared to the same period in 2012.

[0000926326-13-000016:mdna:93]
[same as prior period, unchanged from 0000926326-13-000013:mdna:87]

[0000926326-13-000016:mdna:94]
[same as prior period, unchanged from 0000926326-13-000013:mdna:88]

[0000926326-13-000016:mdna:95]
The table below shows our operating expenses for the three and nine months ended September 30, 2013 and 2012 and the percentage changes between those periods (in thousands, except percentages):

[0000926326-13-000016:mdna:96]
|  | Three Months Ended September 30, |
|  | 2013 |  | 2012 |  | % Change |
| Research and development | $ | 6,561 |  |  | $ | 5,545 |  |  | 18.3 | % |
| Selling, general and administrative | 34,762 |  |  | 29,316 |  |  | 18.5 | % |
| Total operating expenses | $ | 41,323 |  |  | $ | 34,861 |  |  | 18.5 | % |

[0000926326-13-000016:mdna:97]
|  | Nine Months Ended September 30, |
|  | 2013 |  | 2012 |  | % Change |
| Research and development | 21,665 |  |  | 17,538 |  |  | 23.5 | % |
| Selling, general and administrative | 100,866 |  |  | 86,382 |  |  | 16.8 | % |
| Total operating expenses | $ | 122,531 |  |  | $ | 103,920 |  |  | 17.9 | % |

[0000926326-13-000016:mdna:98]
Research and Development. Research and development expenses increased by $1.0 million, or 18.3%, in the three months ended September 30, 2013 as compared to the same period in 2012 and represented 7.0% and 6.6% of total revenues in the three months ended September 30, 2013 and 2012, respectively. The overall increase in research and development expenses is primarily due to a $0.8 million increase in research and development expenses attributable to the Non-Acute Care segment including $0.3 million related to medication cabinets, $0.2 million increase in consulting related expense and $0.3 million decrease in capitalization software effort.

[0000926326-13-000016:mdna:99]
Research and development expenses increased by $4.1 million, or 23.5%, in the nine months ended September 30, 2013 as compared to the same period in 2012 and represented 7.9% and 7.8% of total revenues in the nine months ended September 30, 2013 and 2012, respectively. The overall increase in research and development expenses reflects a $5.0 million increase in research and development expenses attributable to the Non-Acute Care segment, which includes a $1.8 million  write-off of previously capitalized software development costs, discussed further in Note 16, "Asset Impairment" a $0.3 million charge related to the previously mentioned reorganization, and the inclusion of MTS headcount, consulting and other related activities for a full nine months in the 2013 period as compared with the prior period, which included MTS activities only since the date of the MTS acquisition in May 2012. These increases were offset by a $0.9 million decrease in the Acute Care segment which was comprised primarily of an increase of capitalized software costs of $2.7 million in connection with a higher level of post-feasibility beta testing and $0.6 million decrease in consulting related expense, offset by approximately $2.5 million increases in headcount related expenses.

[0000926326-13-000016:mdna:100]
[same as prior period, unchanged from 0000926326-13-000013:mdna:95]

[0000926326-13-000016:mdna:101]
Selling, General and Administrative. Selling, general and administrative expenses increased by $5.4 million, or 18.5%, in the three months ended September 30, 2013 as compared to the same period in 2012. Selling, general and administrative expenses represented 37.0% and 34.8% of total revenues in the three months ended September 30, 2013 and 2012, respectively. The overall increase in selling, general and administrative expenses reflects a $1.9 million increase in selling, general and administrative expenses attributable to the Non-Acute Care segment. The Acute Care segment increase of $3.6 million was primarily due to $1.3 million in commission expenses associated with increased revenue, $0.6 million in facility and depreciation expenses for our new headquarters and manufacturing buildings occupied late in 2012, $0.5 million in professional fees, $0.6 million employee related expenses and $0.6 million in other compensation expenses related to long term incentive bonuses.

[0000926326-13-000016:mdna:102]
Selling, general and administrative expenses increased by $14.5 million, or 16.8% in the nine months ended September 30, 2013 as compared to the same period in 2012. Selling, general and administrative expenses represented 36.7% and 38.6% of total revenues in the nine months ended September 30, 2013 and 2012, respectively. The increase was primarily due to an increase in the Non-Acute Care selling, general and administrative expenses of $11.7 million representing the overall expenses incurred due to the inclusion of MTS activities for a full nine months in the 2013 period as compared with the prior period, which included MTS activities only since the date of the MTS acquisition in May 2012, included in this increase is $3.0 million of corporate allocation related to the Non-Acute cabinet segment. The Acute Care segment increase of $2.8 million was primarily due to $2.9 million in facility and depreciation expenses for our new headquarters and manufacturing buildings occupied late in 2012, $2.4 million in headcount-related expenses, $1.4 million increase in consulting and professional fees, $0.6 million in travel, entertainment, promotional and tradeshow related expenses, $0.5 million in GPO fees associated with higher collections and sales volume for GPO-affiliated customers,  partially offset by $2.3 million of MTS acquisition related costs incurred in the 2012 period and a decrease of $2.8 million in allocations and miscellaneous general expenses of which the primary decrease was due to higher corporate allocation to the Non-Acute segment noted above.

[0000926326-13-000016:mdna:103]
We expect selling, general and administrative expenses to grow at a nominal rate in order to support our anticipated growth as well as international expansion efforts, but anticipate that increased efficiencies will result in a lower selling, general and administrative expense relative to total revenue growth in the future.

[0000926326-13-000016:mdna:104]
Share-based Compensation. The effect of share-based compensation on functional expenses within our operating results for the three months and nine months ended September 30, 2013 and 2012 is presented in Note 13, “Stock Option Plans and Share-Based Compensation.”

[0000926326-13-000016:mdna:105]
[same as prior period, unchanged from 0000926326-13-000013:mdna:101]

[0000926326-13-000016:mdna:106]
The annual effective tax rate before discrete items was 38.1% and 41.5% for the nine months ended September 30, 2013 and 2012, respectively. The decrease in the estimated annual effective tax rate for the nine months ended September 30, 2013 as compared to the same period in 2012 was primarily due to the reinstatement of the federal research and development credit in January of 2013 along with a decrease in other non-deductible expenditures. The impact of these amounts was 2.2%  and1.2%, respectively.

[0000926326-13-000016:mdna:107]
[same as prior period, unchanged from 0000926326-13-000013:mdna:103]

[0000926326-13-000016:mdna:108]
We had cash and cash equivalents of $116.2 million at September 30, 2013, as compared to $62.3 million at December 31, 2012. All of our cash is invested in short term money market funds or demand deposits. We did not hold any short or long term investments as of September 30, 2013.

[0000926326-13-000016:mdna:109]
In September 2013, we entered into a Credit Agreement with Wells Fargo Bank, National Association, as administrative agent, and the lenders from time to time which provides for a $75.0 million revolving credit facility to be used for general corporate purposes, including future acquisitions. The Credit Agreement permits us to request one or more increases in the aggregate commitment provided such increases do not exceed $25.0 million in the aggregate. Please review details discussed in Note 17, “Credit Agreement.”

[0000926326-13-000016:mdna:110]
We believe our current cash and cash equivalent balances and cash flows generated by operations, along with the availability of funds under our $75.0 million Credit Agreement, will be sufficient to satisfy our anticipated cash needs for working capital and capital expenditures for at least the next twelve months.

[0000926326-13-000016:mdna:111]
Cash flows for the nine months ended September 30, 2013 and 2012 consisted of the following (in thousands):

[0000926326-13-000016:mdna:112]
|  | Nine Months Ended September 30, |
|  | 2013 |  | 2012 |
| Net cash provided by operating activities | $ | 40,737 |  |  | $ | 27,477 |  |
| Net cash used in investing activities | (13,736 | ) |  | (161,171 | ) |
| Net cash provided by (used in) financing activities | 26,847 |  |  | (3,250 | ) |
| Effect of exchange rate changes on cash and cash equivalents | 29 |  |  | — |  |
| Net increase in cash and cash equivalents | $ | 53,877 |  |  | $ | (136,944 | ) |

[0000926326-13-000016:mdna:113]
Operating activities provided $40.7 million of cash during the nine months ended September 30, 2013 as compared to $27.5 million for the same period in 2012. The main drivers of this increase were a $6.5 million increase in net income, a $4.3 million increase in accounts payable due to timing of payments, a $3.8 million increase in accrued liabilities, and a $2.8 million decrease in net investments in sales-types leases. These amounts were partially offset by a $7.6 million increase in inventory due to increased production to meet future demands, a $2.5 million decrease in deferred service revenue, and a $1.9 million increase in accounts receivable due to increased sales. Also impacting operating cash flows are non-cash adjustments which include a $4.5 million increase in depreciation and amortization, a $1.8 million asset impairment charge related to a software development project and a $1.6 million increase in share-based compensation expense.

[0000926326-13-000016:mdna:114]
Cash used in investing activities totaled $13.7 million during the nine months ended September 30, 2013, as compared to $161.2 million cash used in investing activities during the same period in 2012. This $147.4 million decrease in cash used primarily reflects a decrease of $156.3 million of net cash used to acquire MTS in May of 2012 and a decrease of $1.7 million for purchases of property and equipment. This was offset in part by a decrease of $8.1 million in proceeds from short-term investments and an increase of $2.6 million of capitalized software development costs during the nine months ended September 30, 2013.

[0000926326-13-000016:mdna:115]
Cash provided by financing activities was $26.8 million during the nine months ended September 30, 2013, as compared to $3.3 million used during the same period in 2012. The increase of $30.1 million is primarily due to an increase of $17.2 million in cash generated from shares issued under stock option and employee stock purchase plans during the nine months ended September 30, 2013 as compared to the same period in 2012 combined with no stock repurchase activity during

[0000926326-13-000016:mdna:116]
the nine months ended September 30, 2013 as compared to the $12.4 million of cash used in stock repurchase activities during the nine months ended September 30, 2012.

[0000926326-13-000016:mdna:117]
[same as prior period, unchanged from 0000926326-13-000013:mdna:110]

[0000926326-13-000016:mdna:118]
There have been no material changes to our contractual obligations during the nine months ended September 30, 2013. Please refer to our Annual Report on Form 10-K for the year ended December 31, 2012 for a description of our facility leases and contractual obligations and the Notes to the consolidated financial statements included therein.

[0000926326-13-000016:mdna:119]
The following table summarizes our contractual obligations at September 30, 2013 (in thousands):

[0000926326-13-000016:mdna:120]
|  | Total |  | Less than one year |  | One to three years |  | Three to five years |  | More than five years |
| Operating leases (1) (2) | $ | 43,176 |  |  | $ | 5,772 |  |  | $ | 10,727 |  |  | $ | 8,980 |  |  | $ | 17,697 |  |
| Commitments to contract manufacturers and suppliers (3) | 7,520 |  |  | 7,520 |  |  |  |  |  |  |  |  |  |  |
| Total (4) | $ | 50,696 |  |  | $ | 13,292 |  |  | $ | 10,727 |  |  | $ | 8,980 |  |  | $ | 17,697 |  |

[0000926326-13-000016:mdna:121]
[same as prior period, unchanged from 0000926326-13-000013:mdna:114]

[0000926326-13-000016:mdna:122]
| (2) | In October 2011, we entered into a lease agreement for approximately 100,000 square feet of office space. Pursuant to the lease agreement, the landlord constructed a single, three-story building of rentable space in Mountain View, California which we lease and which serves as our headquarters. The term of the lease agreement, which commenced in November 2012, is for a period of 10 years, with a base lease commitment of approximately $40.0 million. We have two options to extend the term of the lease agreement at market rates. Each extension is for an additional 60 month term. |

[0000926326-13-000016:mdna:123]
[same as prior period, unchanged from 0000926326-13-000013:mdna:116]

[0000926326-13-000016:mdna:124]
| (4) | At September 30, 2013, we have recorded $4.7 million for uncertain tax positions under long term liabilities, in accordance with GAAP, summarized under Note 1, “Organization and Summary of Significant Accounting Policies.” As these liabilities do not reflect actual tax assessments, the timing and amount of payments we might be required to make will depend upon a number of factors. Accordingly, as the timing and amount of payment cannot be estimated, the current balance of the uncertain tax position liabilities has not been included in the table of commitments above. |

[0000926326-13-000016:mdna:125]
[same as prior period, unchanged from 0000926326-13-000013:mdna:118]

[0000926326-13-000016:mdna:126]
As of September 30, 2013, we had no off-balance sheet arrangements as defined in Regulation S-K 303(a)(4)(ii) of the Securities Exchange Act of 1934, as amended, and the instructions thereto.
