# OMCL notes — 0000926326-13-000016


## us-gaap:AllowanceForCreditLossesOnFinancingReceivablesTableTextBlock

[0000926326-13-000016:notes:1]
[same as prior period, unchanged from 0000926326-13-000013:notes:1]

[0000926326-13-000016:notes:2]
|  | Allowance for Credit Losses |  | Recorded Investmentin Sales-type Leases Gross |  | Recorded Investmentin Sales-type Leases Net |
| Credit loss disclosure for September 30, 2013: |  |  |  |  |  |  |  |  |
| Accounts individually evaluated for impairment | $ | 22 |  |  | $ | 22 |  |  | $ | — |  |
| Accounts collectively evaluated for impairment | 152 |  |  | 17,783 |  |  | 17,631 |  |
| Ending balances: September 30, 2013 | $ | 174 |  |  | $ | 17,805 |  |  | $ | 17,631 |  |
| Credit loss disclosure for December 31, 2012: |  |  |  |  |  |  |  |  |
| Accounts individually evaluated for impairment | $ | 489 |  |  | $ | 489 |  |  | $ | — |  |
| Accounts collectively evaluated for impairment | 118 |  |  | 18,578 |  |  | 18,460 |  |
| Ending balances: December 31, 2012 | $ | 607 |  |  | $ | 19,067 |  |  | $ | 18,460 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000926326-13-000016:notes:3]
Basis of presentation. These interim condensed consolidated financial statements are unaudited but reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of Omnicell and its subsidiaries as of September 30, 2013, the results of their operations and comprehensive income for the three and nine months ended September 30, 2013 and 2012 and their cash flows for the nine months ended September 30, 2013 and 2012. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“GAAP”), have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and accompanying notes included in our Annual Report on Form 10-K for the year ended December 31, 2012.

[0000926326-13-000016:notes:4]
Our results of operations, comprehensive income and cash flows for the three and nine months ended September 30, 2013 are not necessarily indicative of results that may be expected for the year ending December 31, 2013, or for any future period.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000926326-13-000016:notes:5]
[same as prior period, unchanged from 0000926326-13-000013:notes:5]

[0000926326-13-000016:notes:6]
[same as prior period, unchanged from 0000926326-13-000013:notes:6]

[0000926326-13-000016:notes:7]
[same as prior period, unchanged from 0000926326-13-000013:notes:7]

[0000926326-13-000016:notes:8]
[same as prior period, unchanged from 0000926326-13-000013:notes:8]

[0000926326-13-000016:notes:9]
[same as prior period, unchanged from 0000926326-13-000013:notes:9]

[0000926326-13-000016:notes:10]
[same as prior period, unchanged from 0000926326-13-000013:notes:10]

[0000926326-13-000016:notes:11]
[same as prior period, unchanged from 0000926326-13-000013:notes:11]

[0000926326-13-000016:notes:12]
[same as prior period, unchanged from 0000926326-13-000013:notes:12]

[0000926326-13-000016:notes:13]
[same as prior period, unchanged from 0000926326-13-000013:notes:13]

[0000926326-13-000016:notes:14]
[same as prior period, unchanged from 0000926326-13-000013:notes:14]

[0000926326-13-000016:notes:15]
[same as prior period, unchanged from 0000926326-13-000013:notes:15]

[0000926326-13-000016:notes:16]
[same as prior period, unchanged from 0000926326-13-000013:notes:16]

[0000926326-13-000016:notes:17]
[same as prior period, unchanged from 0000926326-13-000013:notes:17]

[0000926326-13-000016:notes:18]
[same as prior period, unchanged from 0000926326-13-000013:notes:18]

[0000926326-13-000016:notes:19]
[same as prior period, unchanged from 0000926326-13-000013:notes:19]

[0000926326-13-000016:notes:20]
[same as prior period, unchanged from 0000926326-13-000013:notes:20]

[0000926326-13-000016:notes:21]
For the three and nine months ended September 30, 2013, we did not incur any acquisition-related costs in connection with the MTS acquisition. For the nine months ended September 30, 2012, we incurred approximately $3.2 million in acquisition related costs related to the MTS acquisition. These costs are included in selling, general and administrative expenses on our Condensed Consolidated Statement of Operations.


## us-gaap:CashAndCashEquivalentsDisclosureTextBlock

[0000926326-13-000016:notes:22]
Cash and Cash Equivalents and Fair Value of Financial Instruments

[0000926326-13-000016:notes:23]
Cash and cash equivalents consist of the following significant investment asset classes, with disclosure of amortized cost, gross unrealized gains and losses and fair value as of September 30, 2013 and December 31, 2012 (in thousands):

[0000926326-13-000016:notes:24]
|  | September 30, 2013 |  |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | Fair Value |  | Cash / CashEquivalents |  | SecurityClassification |
| Cash | $ | 51,415 |  |  | $ | — |  |  | $ | — |  |  | $ | 51,415 |  |  | $ | 51,415 |  |  | N/A |
| Money market fund | 64,775 |  |  | — |  |  | — |  |  | 64,775 |  |  | 64,775 |  |  | Available for sale |
| Total cash and cash equivalents | $ | 116,190 |  |  | $ | — |  |  | $ | — |  |  | $ | 116,190 |  |  | $ | 116,190 |  |  |  |

[0000926326-13-000016:notes:25]
| c | December 31, 2012 |  |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | Fair Value |  | Cash / CashEquivalents |  | SecurityClassification |
| Cash | $ | 23,422 |  |  | $ | — |  |  | $ | — |  |  | $ | 23,422 |  |  | $ | 23,422 |  |  | N/A |
| Money market fund | 38,892 |  |  | — |  |  | 1 |  |  | 38,891 |  |  | 38,891 |  |  | Available for sale |
| Total cash and cash equivalents | $ | 62,314 |  |  | $ | — |  |  | $ | 1 |  |  | $ | 62,313 |  |  | $ | 62,313 |  |  |  |

[0000926326-13-000016:notes:26]
[same as prior period, unchanged from 0000926326-13-000013:notes:26]

[0000926326-13-000016:notes:27]
[same as prior period, unchanged from 0000926326-13-000013:notes:27]

[0000926326-13-000016:notes:28]
|  | Quoted Prices in ActiveMarkets for IdenticalInstruments (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant UnobservableInputs(Level 3) |  | Total FairValue |
| At September 30, 2013 |  |  |  |  |  |  |  |  |  |  |  |
| Money market fund | $ | 64,775 |  |  | $ | — |  |  | $ | — |  |  | $ | 64,775 |  |
| Total | $ | 64,775 |  |  | $ | — |  |  | $ | — |  |  | $ | 64,775 |  |
| At December 31, 2012 |  |  |  |  |  |  |  |  |  |  |  |
| Money market fund | $ | 38,891 |  |  | $ | — |  |  | $ | — |  |  | $ | 38,891 |  |
| Total | $ | 38,891 |  |  | $ | — |  |  | $ | — |  |  | $ | 38,891 |  |

[0000926326-13-000016:notes:29]
[same as prior period, unchanged from 0000926326-13-000013:notes:29]


## us-gaap:CommitmentsDisclosureTextBlock

[0000926326-13-000016:notes:30]
[same as prior period, unchanged from 0000926326-13-000013:notes:30]

[0000926326-13-000016:notes:31]
At September 30, 2013, the minimum payments under our operating leases for each of the five succeeding fiscal years were as follows (in thousands):

[0000926326-13-000016:notes:32]
| 2013 (remaining three months) | $ | 1,462 |  |
| 2014 | 5,722 |  |
| 2015 | 5,476 |  |
| 2016 | 5,150 |  |
| 2017 | 4,468 |  |
| 2018 | 4,298 |  |
| Thereafter | 16,600 |  |
| Total | $ | 43,176 |  |

[0000926326-13-000016:notes:33]
[same as prior period, unchanged from 0000926326-13-000013:notes:33]

[0000926326-13-000016:notes:34]
[same as prior period, unchanged from 0000926326-13-000013:notes:34]

[0000926326-13-000016:notes:35]
In connection with the acquisition of MTS, we assumed responsibility for 132,500 square feet of manufacturing, warehousing and office space in St. Petersburg, Florida. The remaining term of the original lease agreement was for a period of 12 years, which expires in September 2016 and at the time of the MTS acquisition, with a base lease commitment of approximately $3.9 million. We have two options to extend the term of the lease agreement at market rates. Each extension is for an additional 60 month term.

[0000926326-13-000016:notes:36]
[same as prior period, unchanged from 0000926326-13-000013:notes:36]

[0000926326-13-000016:notes:37]
[same as prior period, unchanged from 0000926326-13-000013:notes:37]

[0000926326-13-000016:notes:38]
We purchase components from a variety of suppliers and use contract manufacturers to provide manufacturing services for our products. During the normal course of business, we issue purchase orders with estimates of our requirements several months ahead of the delivery dates. Our near-term commitments to our contract manufacturers and suppliers totaled $7.5 million as of September 30, 2013.

[0000926326-13-000016:notes:39]
At September 30, 2013, we have recorded $4.7 million for uncertain tax positions under long term liabilities in accordance with GAAP, summarized under Note 1, “Organization and Summary of Significant Accounting Policies.” As these liabilities do not reflect actual tax assessments, the timing and amount of payments we might be required to make will depend upon a number of factors. Accordingly, as the timing and amount of payment cannot be estimated, we do not present this in a commitments table.


## us-gaap:DebtDisclosureTextBlock

[0000926326-13-000016:notes:40]
Credit Agreement

[0000926326-13-000016:notes:41]
In September 2013, we entered into a credit agreement (the "Credit Agreement") with Wells Fargo Bank, National Association, as administrative agent, and the lenders from time to time party thereto. The Credit Agreement provides for a $75.0 million revolving credit facility with a $10.0 million letter of credit sub-limit. Loans under the Credit Agreement mature on September 25, 2018. The Credit Agreement permits us to request one or more increases in the aggregate commitments provided that such increases do not exceed $25.0 million in the aggregate. We expect to use the proceeds from any revolving loans under the credit facility for general corporate purposes, including future acquisitions. Our obligations under the Credit Agreement are guaranteed by certain of our domestic subsidiaries and secured by substantially all of our and the subsidiary guarantors’ assets. To date, we have not yet drawn any funds under the credit facility.

[0000926326-13-000016:notes:42]
Amounts drawn under the Credit Agreement bear interest, at our election, at a Eurodollar rate plus a margin of 1.75% per annum, or an alternate base rate equal to the highest of (a) the prime rate, (b) the federal funds rate plus 0.50%, and (c) LIBOR for an interest period of one month plus 1.75%. We are required to pay a commitment fee of 0.25% per annum on the aggregate undrawn amount of the commitments under the credit facility.

[0000926326-13-000016:notes:43]
The Credit Agreement contains customary affirmative and negative covenants, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends and other distributions. The Credit Agreement contains financial covenants that require us to, among other things, maintain a maximum consolidated total leverage ratio and a minimum consolidated fixed charge coverage ratio, in each case,  as of the last day of each fiscal quarter. We were in full compliance with all covenants at September 30, 2013.


## us-gaap:DerivativesPolicyTextBlock

[0000926326-13-000016:notes:44]
Currency forward contracts. From time to time we enter into foreign currency forward contracts to protect our business from the risk that exchange rates may affect the eventual cash flows resulting from intercompany transactions between Omnicell and our foreign subsidiaries. These transactions primarily arise as a result of products manufactured in the U.S. and sold to foreign subsidiaries in U.S. dollars rather than the subsidiaries' functional currencies. These forward contracts are considered to be financial derivative instruments and are recorded at fair value in the balance sheet. Changes in fair value of these financial derivative instruments are either recognized in other comprehensive income (a component of stockholders' equity) or net income depending on whether the derivative has been designated and qualifies as a highly effective hedging instrument. At September 30, 2013 and December 31, 2012, we had no foreign currency forward contracts which qualify for hedge accounting.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000926326-13-000016:notes:45]
[same as prior period, unchanged from 0000926326-13-000013:notes:41]

[0000926326-13-000016:notes:46]
[same as prior period, unchanged from 0000926326-13-000013:notes:42]

[0000926326-13-000016:notes:47]
[same as prior period, unchanged from 0000926326-13-000013:notes:43]

[0000926326-13-000016:notes:48]
[same as prior period, unchanged from 0000926326-13-000013:notes:44]

[0000926326-13-000016:notes:49]
[same as prior period, unchanged from 0000926326-13-000013:notes:45]

[0000926326-13-000016:notes:50]
[same as prior period, unchanged from 0000926326-13-000013:notes:46]

[0000926326-13-000016:notes:51]
[same as prior period, unchanged from 0000926326-13-000013:notes:47]

[0000926326-13-000016:notes:52]
Options granted under the 2009 Plan generally become exercisable over periods of up to 4 years , generally with one-fourth of the shares vesting one year from the vesting commencement date with respect to initial grants, and the remaining shares vesting in 36 equal monthly installments thereafter; however our board of directors may impose different vesting terms at its discretion on any award. Options under the 2009 Plan generally expire 10 years from the date of grant. We also grant both restricted stock and restricted stock units to participants under the 2009 Plan. The Board of Directors determines the award amount, the vesting provisions and the expiration period (not to exceed ten years) for each grant. Grants of restricted stock to non-employee directors are granted on the date of our annual meeting of stockholders and vest in full on the date of our next annual meeting of stockholders, provided such non-employee director remains a director on such date. The fair value of the stock on the date of issuance is amortized to expense from the date of grant to the date of vesting. RSUs granted to employees generally vest over a period of four years and are expensed ratably on a straight-line basis over the vesting period. We consider the dilutive impact of options, restricted stock and restricted stock units in our diluted net income per share calculation.

[0000926326-13-000016:notes:53]
The Board of Directors shall administer the 2009 Plan unless and until the Board of Directors delegates administration to a committee. Our Board of Directors has delegated administration of the 2009 Plan to the Compensation Committee of the Board of Directors and the 2009 Plan is generally administered by such committee. The Board of Directors may suspend or terminate the 2009 Plan at any time. The Board of Directors may also amend the 2009 Plan at any time or from time to time. However, no amendment will be effective unless approved by our stockholders after its adoption by our Board of Directors to the extent stockholder approval is necessary to satisfy the applicable listing requirements of NASDAQ.

[0000926326-13-000016:notes:54]
[same as prior period, unchanged from 0000926326-13-000013:notes:50]

[0000926326-13-000016:notes:55]
At September 30, 2013, a total of 3,353,608 shares of common stock were reserved for future issuance under the 2009 Plan. At September 30, 2013, $6.0 million of total unrecognized compensation cost related to non-vested stock options was expected to be recognized over a weighted average period of 2.6 years.

[0000926326-13-000016:notes:56]
A summary of aggregate option activity for the nine months ended September 30, 2013 is presented below:

[0000926326-13-000016:notes:57]
| Options: |  | Number of Shares |  | Weighted- Average Exercise Price |
|  |  | (in thousands) |  |  |
| Outstanding at December 31, 2012 |  | 4,470 |  |  | $ | 14.06 |  |
| Granted |  | 296 |  |  | $ | 18.10 |  |
| Exercised |  | (1,450 | ) |  | $ | 12.59 |  |
| Forfeited |  | (75 | ) |  | $ | 14.40 |  |
| Expired |  | (56 | ) |  | $ | 15.68 |  |
| Outstanding at September 30, 2013 |  | 3,185 |  |  | $ | 15.07 |  |
| Exercisable at September 30, 2013 |  | 2,186 |  |  | $ | 14.85 |  |

[0000926326-13-000016:notes:58]
[same as prior period, unchanged from 0000926326-13-000013:notes:54]

[0000926326-13-000016:notes:59]
The non-employee members of our Board of Directors are granted restricted stock on the day of our annual meeting of stockholders and such shares of restricted stock vest on the date of the subsequent year’s annual meeting of stockholders, provided such non-employee director remains a director on such date.

[0000926326-13-000016:notes:60]
Restricted stock units (“RSUs”) are granted to certain of our employees and generally vest over a period of four years and are expensed ratably on a straight-line basis over the vesting period. The fair value of both restricted stock and RSUs granted pursuant to our stock option plans is the product of the number of shares granted and the grant date fair value of our common stock. Our unrecognized compensation cost related to non-vested restricted stock at September 30, 2013 was approximately $0.6 million and is expected to be recognized over a weighted-average period of 0.6 years. Expected future compensation expense relating to RSUs outstanding on September 30, 2013 is $4.8 million over a weighted-average period of 2.2 years.

[0000926326-13-000016:notes:61]
A summary of activity of both restricted stock and RSUs for the nine months ended September 30, 2013 is presented below:

[0000926326-13-000016:notes:62]
|  | Restricted Stock |  | Restricted Stock Units |
|  | Number ofShares |  | Weighted-AverageGrant DateFair Value PerShare |  | Number ofShares |  | Weighted-AverageGrant DateFair Value PerShare |
|  | (in thousands) |  |  |  | (in thousands) |  |  |
| Non-vested, December 31, 2012 | 58 |  |  | $ | 14.19 |  |  | 389 |  |  | $ | 14.09 |  |
| Granted | 55 |  |  | $ | 18.20 |  |  | 125 |  |  | $ | 18.12 |  |
| Vested | (61 | ) |  | $ | 14.23 |  |  | (98 | ) |  | $ | 13.90 |  |
| Forfeited | — |  |  | $ | — |  |  | (21 | ) |  | $ | 14.07 |  |
| Non-vested, September 30, 2013 | 52 |  |  | $ | 18.43 |  |  | 395 |  |  | $ | 15.41 |  |

[0000926326-13-000016:notes:63]
[same as prior period, unchanged from 0000926326-13-000013:notes:58]

[0000926326-13-000016:notes:64]
[same as prior period, unchanged from 0000926326-13-000013:notes:59]

[0000926326-13-000016:notes:65]
Our unrecognized compensation cost related to non-vested performance-based restricted stock units at September 30, 2013 was approximately $1.5 million and is expected to be recognized over a weighted-average period of 1.3 years. For the three months ended September 30, 2013 and 2012, we recognized $0.4 million and $0.2 million, respectively, of compensation expense for the performance-based restricted stock units. For the nine months ended September 30, 2013 and 2012, we recognized $1.2 million and $0.8 million, respectively, of compensation expense for the performance-based restricted stock units.

[0000926326-13-000016:notes:66]
[same as prior period, unchanged from 0000926326-13-000013:notes:61]

[0000926326-13-000016:notes:67]
[same as prior period, unchanged from 0000926326-13-000013:notes:62]

[0000926326-13-000016:notes:68]
[same as prior period, unchanged from 0000926326-13-000013:notes:63]

[0000926326-13-000016:notes:69]
[same as prior period, unchanged from 0000926326-13-000013:notes:64]

[0000926326-13-000016:notes:70]
[same as prior period, unchanged from 0000926326-13-000013:notes:65]

[0000926326-13-000016:notes:71]
[same as prior period, unchanged from 0000926326-13-000013:notes:67]

[0000926326-13-000016:notes:72]
On January 17, 2012, the Compensation Committee of our Board of Directors confirmed 76.3% as the percentile rank of Omnicell’s 2011 total stockholder return. This resulted in 120% of the 2011 PSU awards, or 120,000 shares, becoming eligible for further time-based vesting. The eligible PSU awards will vest as follows: 25% of the eligible awards for the first year vested immediately on January 17, 2012 with the remaining eligible awards vesting in equal increments, semi-annually, over the subsequent three year period beginning on June 15th and December 15th of the year after the date of grant and each subsequent year. Vesting is contingent upon continued service. Of the 120,000 shares eligible for time-based vesting under the 2011 PSU awards, 10,000 shares vested during the year ended December 31, 2012.

[0000926326-13-000016:notes:73]
[same as prior period, unchanged from 0000926326-13-000013:notes:69]

[0000926326-13-000016:notes:74]
[same as prior period, unchanged from 0000926326-13-000013:notes:70]

[0000926326-13-000016:notes:75]
[same as prior period, unchanged from 0000926326-13-000013:notes:71]

[0000926326-13-000016:notes:76]
[same as prior period, unchanged from 0000926326-13-000013:notes:73]

[0000926326-13-000016:notes:77]
A summary of activity of the PSUs for the nine months ended September 30, 2013 is presented below:

[0000926326-13-000016:notes:78]
| Performance-based Stock Units | Number of Units |  | Weighted-AverageGrant DateFair Value PerUnit |
|  | (in thousands) |  |  |
| Non-vested, December 31, 2012 | 175 |  |  | $ | 11.00 |  |
| Granted | 140 |  |  | $ | 14.74 |  |
| Vested | (38 | ) |  | $ | 11.02 |  |
| Forfeited | (24 | ) |  | $ | — |  |
| Non-vested, September 30, 2013 | 253 |  |  | $ | 13.07 |  |

[0000926326-13-000016:notes:79]
[same as prior period, unchanged from 0000926326-13-000013:notes:76]

[0000926326-13-000016:notes:80]
We have an Employee Stock Purchase Plan (“ESPP”) under which employees can purchase shares of our common stock based on a percentage of their compensation, but not greater than 15% of their earnings, up to a maximum of $25,000 of fair value per year. The purchase price per share must be equal to the lower of 85% of the fair value of the common stock at the beginning of a 24-month offering period or the end of each six-month purchasing period. As of September 30, 2013, 4,233,557 shares had been issued under the ESPP. As of September 30, 2013 there were a total of 1,097,998 shares reserved for future issuance under the ESPP. For the three months and nine months ended September 30, 2013, 193,719 and 450,713 shares, respectively, of common stock were purchased under the ESPP.

[0000926326-13-000016:notes:81]
[same as prior period, unchanged from 0000926326-13-000013:notes:78]

[0000926326-13-000016:notes:82]
[same as prior period, unchanged from 0000926326-13-000013:notes:79]

[0000926326-13-000016:notes:83]
The impact on our results for share-based compensation for the three and nine months ended September 30, 2013 and 2012 was as follows (in thousands):

[0000926326-13-000016:notes:84]
|  | Three Months Ended September 30, | Nine Months Ended September 30, |
|  | 2013 |  | 2012 | 2013 |  | 2012 |
| Cost of product and service revenues | $ | 325 |  |  | $ | 275 |  | $ | 955 |  |  | $ | 776 |  |
| Research and development expenses | 405 |  |  | 232 |  | 1,019 |  |  | 686 |  |
| Selling, general and administrative expenses | 2,080 |  |  | 1,854 |  | 6,449 |  |  | 5,319 |  |
| Total share-based compensation expenses | $ | 2,810 |  |  | $ | 2,361 |  | $ | 8,423 |  |  | $ | 6,781 |  |


## us-gaap:EarningsPerSharePolicyTextBlock

[0000926326-13-000016:notes:85]
[same as prior period, unchanged from 0000926326-13-000013:notes:82]


## us-gaap:EarningsPerShareTextBlock

[0000926326-13-000016:notes:86]
[same as prior period, unchanged from 0000926326-13-000013:notes:83]

[0000926326-13-000016:notes:87]
Basic net income per share is computed by dividing net income for the period by the weighted average number of shares outstanding during the period, less shares subject to repurchase. Diluted net income per share is computed by dividing net income for the period by the weighted average number of shares, less shares subject to repurchase, plus, if dilutive, potential common stock outstanding during the period. Potential common stock includes the effect of outstanding dilutive stock options, restricted stock awards and restricted stock units computed using the treasury stock method. Since their impact is anti-dilutive, we excluded 1,178,755 and 2,067,273 shares from the calculations of diluted net income per share for the nine months ended September 30, 2013 and 2012, respectively.

[0000926326-13-000016:notes:88]
[same as prior period, unchanged from 0000926326-13-000013:notes:85]

[0000926326-13-000016:notes:89]
|  | Three Months Ended September 30, | Nine Months Ended September 30, |
|  | 2013 |  | 2012 | 2013 |  | 2012 |
| Basic: |  |  |  |  |  |  |  |  |  |  |
| Net income | $ | 7,755 |  |  | $ | 6,920 |  | $ | 17,156 |  |  | $ | 10,646 |  |
| Weighted average shares outstanding — basic | 35,133 |  |  | 33,193 |  | 34,499 |  |  | 33,316 |  |
| Net income per share — basic | $ | 0.22 |  |  | $ | 0.21 |  | $ | 0.50 |  |  | $ | 0.32 |  |
| Diluted: |  |  |  |  |  |  |  |  |  |  |
| Net income | $ | 7,755 |  |  | $ | 6,920 |  | $ | 17,156 |  |  | $ | 10,646 |  |
| Weighted average shares outstanding — basic | 35,133 |  |  | 33,193 |  | 34,499 |  |  | 33,316 |  |
| Add: Dilutive effect of employee stock plans | 1,057 |  |  | 875 |  | 967 |  |  | 925 |  |
| Weighted average shares outstanding — diluted | 36,190 |  |  | 34,068 |  | 35,466 |  |  | 34,241 |  |
| Net income per share — diluted | $ | 0.21 |  |  | $ | 0.20 |  | $ | 0.48 |  |  | $ | 0.31 |  |


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0000926326-13-000016:notes:90]
[same as prior period, unchanged from 0000926326-13-000013:notes:87]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000926326-13-000016:notes:91]
[same as prior period, unchanged from 0000926326-13-000013:notes:88]

[0000926326-13-000016:notes:92]
[same as prior period, unchanged from 0000926326-13-000013:notes:89]

[0000926326-13-000016:notes:93]
Activity in goodwill by reporting unit, which is the same for our operating segments, for the nine months ended September 30, 2013 consists of the following (in thousands):

[0000926326-13-000016:notes:94]
|  | Goodwill at December 31, 2012 |  | Adjustments to Goodwill |  | Goodwill at September 30, 2013 |
| Reporting units: |  |  |  |  |  |
| Acute Care | $ | 28,543 |  |  | $ | — |  |  | $ | 28,543 |  |
| Non-Acute Care | 82,864 |  |  | (64 | ) |  | 82,800 |  |
| Total | $ | 111,407 |  |  | $ | (64 | ) |  | $ | 111,343 |  |

[0000926326-13-000016:notes:95]
Goodwill acquired reflects the May 21, 2012 acquisition of MedPak by Omnicell. MedPak is the parent company of MTS, a worldwide provider of medication adherence packaging systems. The acquired goodwill was assigned to our new reporting unit called Non-Acute Care, created as a result of the MTS acquisition. During the first quarter of 2013, we reduced goodwill by approximately $0.1 million due to the adjustment to the fair value of an acquired foreign currency forward contract previously carried in a component of stockholder's equity.

[0000926326-13-000016:notes:96]
There were no indefinite-life intangibles at either September 30, 2013 or December 31, 2012. Finite-life intangible assets consist of the following (in thousands):

[0000926326-13-000016:notes:97]
|  | September 30, 2013 |  | December 31, 2012 |  |  |
|  | Gross |  |  |  | Net |  | Gross |  |  |  | Net |  |  |
|  | CarryingAmount |  | AccumulatedAmortization |  | CarryingAmount |  | CarryingAmount |  | AccumulatedAmortization |  | CarryingAmount |  | AmortizationLife |
| Finite-lived intangibles: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships | $ | 54,730 |  |  | $ | 4,698 |  |  | $ | 50,032 |  |  | $ | 54,730 |  |  | $ | 3,081 |  |  | $ | 51,649 |  |  | 5-30 years |
| Acquired technology | 27,580 |  |  | 2,230 |  |  | 25,350 |  |  | 27,580 |  |  | 1,128 |  |  | 26,452 |  |  | 3-20 years |
| Patents | 1,363 |  |  | 244 |  |  | 1,119 |  |  | 1,217 |  |  | 259 |  |  | 958 |  |  | 20 years |
| Trade name | 6,890 |  |  | 861 |  |  | 6,029 |  |  | 6,890 |  |  | 414 |  |  | 6,476 |  |  | 3-12 years |
| Non-compete agreements | 60 |  |  | 60 |  |  | — |  |  | 60 |  |  | 45 |  |  | 15 |  |  | 3 years |
| Total finite-lived intangibles | $ | 90,623 |  |  | $ | 8,093 |  |  | $ | 82,530 |  |  | $ | 90,477 |  |  | $ | 4,927 |  |  | $ | 85,550 |  |  |  |

[0000926326-13-000016:notes:98]
Amortization expense totaled $1.1 million and $1.1 million for the three months ended September 30, 2013 and 2012, respectively. Amortization expense totaled $3.2 million and $1.8 million for the nine months ended September 30, 2013 and 2012, respectively. The amortization of acquired technology is included within product cost of sales; other acquired intangibles are usually amortized within selling, general and administrative expenses.

[0000926326-13-000016:notes:99]
Estimated annual expected amortization expense of the finite-lived intangible assets at September 30, 2013 was as follows (in thousands):

[0000926326-13-000016:notes:100]
| 2013 (remaining three months) | $ | 1,059 |  |
| 2014 | 4,229 |  |
| 2015 | 4,204 |  |
| 2016 | 3,854 |  |
| 2017 | 3,818 |  |
| 2018 | 3,711 |  |
| Thereafter | 61,655 |  |
| Total | $ | 82,530 |  |


## us-gaap:IncomeTaxPolicyTextBlock

[0000926326-13-000016:notes:101]
[same as prior period, unchanged from 0000926326-13-000013:notes:98]

[0000926326-13-000016:notes:102]
[same as prior period, unchanged from 0000926326-13-000013:notes:99]

[0000926326-13-000016:notes:103]
We provide for income taxes for each interim period based on the estimated annual effective tax rate for the year, adjusting for discrete items in the quarter in which they arise. The annual effective tax rate before discrete items was 38.1% and 41.5% for the nine months ended September 30, 2013 and 2012, respectively. The 2013 annual effective tax rate differed from the statutory rate of 35.0% primarily due to the unfavorable impact of state income taxes, non-deductible equity charges, and other non-deductible expenditures, which were partially offset by the federal research and development credit claimed and the domestic production activities deduction.

[0000926326-13-000016:notes:104]
The 2012 annual effective tax rate differed from the statutory rate of 35.0% primarily due to the unfavorable impact of state income taxes, non-deductible equity charges, and other non-deductible expenditures, which were partially offset by the domestic production activities deduction.


## us-gaap:InventoryDisclosureTextBlock

[0000926326-13-000016:notes:105]
[same as prior period, unchanged from 0000926326-13-000013:notes:101]

[0000926326-13-000016:notes:106]
[same as prior period, unchanged from 0000926326-13-000013:notes:102]

[0000926326-13-000016:notes:107]
|  | September 30, 2013 | December 31, 2012 |
| Raw materials | $ | 11,120 |  | $ | 9,994 |  |
| Work in process | 963 |  | 385 |  |
| Finished goods | 18,622 |  | 16,524 |  |
| Total | $ | 30,705 |  | $ | 26,903 |  |


## us-gaap:LegalMattersAndContingenciesTextBlock

[0000926326-13-000016:notes:108]
Contingencies

[0000926326-13-000016:notes:109]
Legal Proceedings

[0000926326-13-000016:notes:110]
On March 8, 2013, Bobbi Polanco (“Polanco”) filed a putative class action complaint in the United States District Court for the District of New Jersey against Omnicell and certain of our customers (Case No. 1:13-cv-01417-NLH-KLM) alleging breach of state security notification laws, violations of state consumer fraud laws, fraud, negligence and conspiracy relating to the theft of an Omnicell electronic device containing medication dispensing cabinet log files, including certain patient health information, and subsequent notification of this unauthorized disclosure of personal health information. Polanco is seeking an injunction against the defendants to prevent each of them from committing the acts complained of in the future and monetary damages, costs and expenses. On May 2, 2013, the United States District Court for the District of New Jersey entered an order to show cause which provided, in relevant part, that Polanco is required to show cause as to why the case should not be dismissed for lack of subject matter jurisdiction. On May 13, 2013, Polanco filed an amended complaint. On May 31, 2013, Omnicell filed a motion to dismiss the complaint on the grounds that Polanco failed to satisfy constitutional standing requirements and that she failed to state a claim against Omnicell  for violating  state data breach notification statutes, consumer fraud, common law fraud, negligence and conspiracy. Omnicell also joined in the arguments of the other defendants seeking dismissal. On July 1, 2013, Polanco filed an opposition to the motions to dismiss. On July 15, 2013, Omnicell filed its reply to the opposition from Polanco. Omnicell is currently awaiting a decision from the court and intends to defend the matter vigorously.

[0000926326-13-000016:notes:111]
As required under ASC 450, Contingencies, we accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss. We have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that any potential loss, while reasonably possible, is not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. We believe that we have valid defenses with respect to legal proceedings pending against us. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of this contingency or because of the diversion of management's attention and the creation of significant expenses.

[0000926326-13-000016:notes:112]
Guarantees

[0000926326-13-000016:notes:113]
As permitted under Delaware law and our certificate of incorporation and bylaws, we have agreed to indemnify our directors and officers against certain losses that they may suffer by reason of the fact that such persons are, were or become our directors or officers. The term of the indemnification period is for the director’s or officer’s lifetime and there is no limit on the potential amount of future payments that we could be required to make under these indemnification agreements. We have purchased a directors’ and officers’ liability insurance policy that may enable us to recover a portion of any future payments that we may be required to make under these indemnification agreements. Assuming the applicability of coverage and the willingness of the insurer to assume coverage and subject to certain retention, loss limits and other policy provisions, we believe it is unlikely that we will be required to pay any material amounts pursuant to these indemnification obligations. However, no assurances can be given that the insurers will not attempt to dispute the validity, applicability or amount of coverage without expensive and time-consuming litigation against the insurers.

[0000926326-13-000016:notes:114]
Additionally, we undertake indemnification obligations in our ordinary course of business in connection with, among other things, the licensing of our products and the provision of our support services. In the ordinary course of our business, we have in the past and may in the future agree to indemnify another party, generally our business affiliates or customers, against certain losses suffered or incurred by the indemnified party in connection with various types of claims, which may include, without limitation, claims of intellectual property infringement, certain tax liabilities, our gross negligence or intentional acts in the performance of support services and violations of laws. The term of these indemnification obligations is generally perpetual. In general, we attempt to limit the maximum potential amount of future payments that we may be required to make under these indemnification obligations to the amounts paid to us by a customer, but in some cases the obligation may not be so limited. In addition, we have in the past and may in the future warrant to our customers that our products will conform to functional specifications for a limited period of time following the date of installation (generally not exceeding 30 days) or that our software media is free from material defects. Sales contracts for certain of our medication packaging systems often include limited warranties for up to six months, but the periodic activity and ending warranty balances we record have historically been immaterial.

[0000926326-13-000016:notes:115]
From time to time, we may also warrant that our professional services will be performed in a good and workmanlike manner or in a professional manner consistent with industry standards. We generally seek to disclaim most warranties, including any implied or statutory warranties such as warranties of merchantability, fitness for a particular purpose, title, quality and non-infringement, as well as any liability with respect to incidental, consequential, special, exemplary, punitive or similar damages. In some states, such disclaimers may not be enforceable. If necessary, we would provide for the estimated cost of product and service warranties based on specific warranty claims and claim history. We have not been subject to any significant claims for such losses and have not incurred any material costs in defending or settling claims related to these indemnification obligations. Accordingly, we believe it is unlikely that we will be required to pay any material amounts pursuant to these indemnification obligations or potential warranty claims and, therefore, no material liabilities have been recorded for such indemnification obligations as of September 30, 2013 or December 31, 2012.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000926326-13-000016:notes:116]
Recently Adopted Accounting Standards

[0000926326-13-000016:notes:117]
In February 2013, the Financial Accounting Standards Board ("FASB") issued ASU 2013-02, Comprehensive Income (Topic 220): Reporting of Amounts Reclassified Out of Accumulated Other Comprehensive Income (AOCI), which aims to improve the reporting of reclassifications out of AOCI. This update requires an entity to report the effect of significant reclassifications out of AOCI on the respective line items in net income if the amount being reclassified is required under GAAP to be reclassified in its entirety to net income. For other amounts that are not required under GAAP to be reclassified in their entirety to net income in the same reporting period, an entity is required to cross-reference other disclosures required under GAAP that provide additional detail about those amounts. The amendments do not change the current requirements for reporting net income or other comprehensive income in financial statements. For public entities, the amendments are effective prospectively for reporting periods beginning after December 15, 2012. We adopted this guidance in the first quarter of 2013. This update did not have any significant impact on our financial position, operating results or cash flows.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0000926326-13-000016:notes:118]
[same as prior period, unchanged from 0000926326-13-000013:notes:114]

[0000926326-13-000016:notes:119]
Description of the Company. Omnicell, Inc. ("Omnicell," "our," "us," "we," or the "Company") was incorporated in California in 1992 under the name Omnicell Technologies, Inc. and reincorporated in Delaware in 2001 as Omnicell, Inc. Our major products are automated medication and supply control systems which are sold in our principal market, which is the healthcare industry. Our market is primarily located in the United States. On May 21, 2012, we completed our acquisition of MedPak Holdings, Inc. ("MedPak"). MedPak is the parent company of MTS Medication Technologies, Inc. ("MTS"), a worldwide provider of medication adherence packaging systems. This acquisition aligns us with the long-term trends of the healthcare market to manage the health of patients across the continuum of care. We now serve both the acute care and non-acute care markets. Please refer to Note 14, "Business Acquisition" for more information regarding the transaction.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000926326-13-000016:notes:120]
[same as prior period, unchanged from 0000926326-13-000013:notes:116]

[0000926326-13-000016:notes:121]
[same as prior period, unchanged from 0000926326-13-000013:notes:117]

[0000926326-13-000016:notes:122]
|  | September 30, 2013 |  | December 31, 2012 |
| Equipment | $ | 35,483 |  |  | $ | 32,528 |  |
| Furniture and fixtures | 5,149 |  |  | 5,126 |  |
| Leasehold improvements | 7,356 |  |  | 6,992 |  |
| Purchased software | 19,800 |  |  | 19,870 |  |
| Capital in process | 3,491 |  |  | 2,693 |  |
|  | 71,279 |  |  | 67,209 |  |
| Accumulated depreciation and amortization | (37,787 | ) |  | (33,102 | ) |
| Property and equipment, net | $ | 33,492 |  |  | $ | 34,107 |  |

[0000926326-13-000016:notes:123]
Depreciation and amortization of property and equipment totaled approximately $2.6 million and $2.2 million for the three months ended September 30, 2013 and 2012, respectively. Depreciation and amortization of property and equipment totaled approximately $8.2 million and $5.7 million for the nine months ended September 30, 2013 and 2012, respectively.


## us-gaap:ReceivablesPolicyTextBlock

[0000926326-13-000016:notes:124]
[same as prior period, unchanged from 0000926326-13-000013:notes:120]

[0000926326-13-000016:notes:125]
[same as prior period, unchanged from 0000926326-13-000013:notes:121]


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0000926326-13-000016:notes:126]
For the three and nine months ended September 30, 2013 and 2012, the contributions of our segments to net revenues and income from operations, and the reconciliation to total net income, were as follows (amounts in thousands):

[0000926326-13-000016:notes:127]
|  | Three Months Ended September 30, 2013 |  | Three Months Ended September 30, 2012 |
|  | Acute Care |  | Non-Acute Care |  | Total |  | Acute Care |  | Non-Acute Care (1) |  | Total |
| Net revenues from external customers | $ | 70,640 |  |  | $ | 23,399 |  |  | $ | 94,039 |  |  | $ | 64,394 |  |  | 19,937 |  |  | $ | 84,331 |  |
| Cost of revenues | 28,662 |  |  | 13,337 |  |  | 41,999 |  |  | 26,920 |  |  | 11,324 |  |  | 38,244 |  |
| Gross profit | $ | 41,978 |  |  | $ | 10,062 |  |  | $ | 52,040 |  |  | $ | 37,474 |  |  | $ | 8,613 |  |  | $ | 46,087 |  |
| Gross margin % | 59.4 | % |  | 43.0 | % |  | 55.3 | % |  | 58.2 | % |  | 43.2 | % |  | 54.7 | % |
| Operating expenses | 32,908 |  |  | 8,415 |  |  | 41,323 |  |  | 29,070 |  |  | 5,791 |  |  | 34,861 |  |
| Income from operations | $ | 9,070 |  |  | $ | 1,647 |  |  | $ | 10,717 |  |  | $ | 8,404 |  |  | 2,822 |  |  | $ | 11,226 |  |
| Operating margin % | 12.8 | % |  | 7.0 | % |  | 11.4 | % |  | 13.1 | % |  | 14.2 | % |  | 13.3 | % |
| Interest and other income (expense), net |  |  |  |  | 25 |  |  |  |  |  |  | 34 |  |
| Income before provision for income taxes |  |  |  |  | 10,742 |  |  |  |  |  |  | 11,260 |  |
| Provision for income taxes |  |  |  |  | 2,987 |  |  |  |  |  |  | 4,340 |  |
| Net income |  |  |  |  | $ | 7,755 |  |  |  |  |  |  | $ | 6,920 |  |
| (1) Non-Acute Care segment includes MTS results from May 21, 2012, the date of acquisition. |


## us-gaap:RevenueRecognitionPolicyTextBlock

[0000926326-13-000016:notes:128]
[same as prior period, unchanged from 0000926326-13-000013:notes:124]

[0000926326-13-000016:notes:129]
[same as prior period, unchanged from 0000926326-13-000013:notes:125]

[0000926326-13-000016:notes:130]
[same as prior period, unchanged from 0000926326-13-000013:notes:126]

[0000926326-13-000016:notes:131]
[same as prior period, unchanged from 0000926326-13-000013:notes:127]

[0000926326-13-000016:notes:132]
[same as prior period, unchanged from 0000926326-13-000013:notes:128]

[0000926326-13-000016:notes:133]
[same as prior period, unchanged from 0000926326-13-000013:notes:129]

[0000926326-13-000016:notes:134]
[same as prior period, unchanged from 0000926326-13-000013:notes:130]

[0000926326-13-000016:notes:135]
[same as prior period, unchanged from 0000926326-13-000013:notes:131]

[0000926326-13-000016:notes:136]
[same as prior period, unchanged from 0000926326-13-000013:notes:132]

[0000926326-13-000016:notes:137]
[same as prior period, unchanged from 0000926326-13-000013:notes:133]

[0000926326-13-000016:notes:138]
[same as prior period, unchanged from 0000926326-13-000013:notes:134]

[0000926326-13-000016:notes:139]
[same as prior period, unchanged from 0000926326-13-000013:notes:135]

[0000926326-13-000016:notes:140]
[same as prior period, unchanged from 0000926326-13-000013:notes:136]

[0000926326-13-000016:notes:141]
[same as prior period, unchanged from 0000926326-13-000013:notes:137]

[0000926326-13-000016:notes:142]
A portion of our sales are made through multi-year lease agreements. Under sales-type leases, we recognize revenue for our hardware and software products net of lease execution costs, such as post-installation product maintenance and technical support, at the net present value of the lease payment stream once our installation obligations have been met. We optimize cash flows by selling a majority of our non-U.S. government leases to third-party leasing finance companies on a non-recourse basis. We have no obligation to the leasing company once the lease has been sold. Some of our sales-type leases, mostly those relating to U.S. government hospitals, are retained in-house. Interest income in these leases is recognized in product revenue using the effective interest method.


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0000926326-13-000016:notes:143]
[same as prior period, unchanged from 0000926326-13-000013:notes:139]

[0000926326-13-000016:notes:144]
|  | September 30, 2013 | December 31, 2012 |
| Rebates and lease buyouts | $ | 3,379 |  | $ | 3,179 |  |
| Advance payments from customers | 4,272 |  | 2,829 |  |
| Accrued Group Purchasing Organization (GPO) fees | 2,492 |  | 2,278 |  |
| Technology license purchase obligation, current portion | 1,500 |  | 1,750 |  |
| Taxes payable (receivable) | 774 |  | 555 |  |
| Other | 1,602 |  | 1,397 |  |
| Total | $ | 14,019 |  | $ | 11,988 |  |


## us-gaap:ScheduleOfCreditLossesRelatedToFinancingReceivablesNoncurrentTableTextBlock

[0000926326-13-000016:notes:145]
The following table summarizes the activity for the allowance for credit losses for the investment in sales-type leases for the three and nine months ended September 30, 2013 and 2012 (in thousands):

[0000926326-13-000016:notes:146]
|  | Three Months Ended September 30, | Nine Months Ended September 30, |
|  | 2013 |  | 2012 | 2013 |  | 2012 |
| Allowance for credit losses, beginning of period | $ | 184 |  |  | $ | 659 |  | $ | 607 |  |  | $ | 284 |  |
| Current period provision | 15 |  |  | 4 |  | 34 |  |  | 426 |  |
| Direct write-downs charged against the allowance | — |  |  | — |  | (413 | ) |  | — |  |
| Recoveries of amounts previously charged off | (25 | ) |  | (26 | ) | (54 | ) |  | (73 | ) |
| Allowance for credit losses, end of period | $ | 174 |  |  | $ | 637 |  | $ | 174 |  |  | $ | 637 |  |


## us-gaap:ScheduleOfFutureMinimumLeasePaymentsForCapitalLeasesTableTextBlock

[0000926326-13-000016:notes:147]
The minimum lease payments under sales-type leases as of September 30, 2013 were as follows (in thousands):

[0000926326-13-000016:notes:148]
| 2013 (remaining three months) | $ | 1,640 |  |
| 2014 | 5,495 |  |
| 2015 | 4,536 |  |
| 2016 | 3,341 |  |
| 2017 | 2,603 |  |
| Thereafter | 1,173 |  |
| Total | $ | 18,788 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000926326-13-000016:notes:149]
At September 30, 2013, segment assets were as follows (amounts in thousands):

[0000926326-13-000016:notes:150]
|  | September 30, 2013 |  | December 31, 2012 |
|  | Acute Care |  | Non-Acute Care |  | Total |  | Acute Care |  | Non-Acute Care (1) |  | Total |
| Segment Assets | $ | 284,067 |  |  | $ | 221,917 |  |  | $ | 505,984 |  |  | $ | 235,186 |  |  | $ | 206,633 |  |  | $ | 441,819 |  |

[0000926326-13-000016:notes:151]
At three and nine months ended September 30, 2013 and 2012, segment depreciation/amortization, and capital expenditures were as follows (amounts in thousands):

[0000926326-13-000016:notes:152]
|  | Three Months Ended September 30, 2013 |  | Three Months Ended September 30, 2012 |
|  | Acute Care |  | Non-Acute Care |  | Total |  | Acute Care |  | Non-Acute Care (1) | Total |
| Depreciation/Amortization | $ | 2,805 |  |  | $ | 1,683 |  |  | $ | 4,488 |  |  | $ | 2,072 |  |  | $ | 1,842 |  | $ | 3,914 |  |
| Capital Expenditures | 1,311 |  |  | 745 |  |  | 2,056 |  |  | $ | 4,940 |  |  | $ | 532 |  | $ | 5,472 |  |
| (1) Non-Acute Care segment includes MTS results from May 21, 2012, the date of acquisition. |  |

[0000926326-13-000016:notes:153]
|  | Nine Months Ended September 30, 2013 |  | Nine Months Ended September 30, 2012 |
|  | Acute Care |  | Non-Acute Care |  | Total |  | Acute Care |  | Non-Acute Care (1) | Total |
| Depreciation/Amortization | $ | 8,351 |  |  | $ | 5,381 |  |  | $ | 13,732 |  |  | $ | 6,538 |  |  | $ | 2,709 |  | 9,247 |  |
| Capital Expenditures | 3,329 |  |  | 4,478 |  |  | 7,807 |  |  | $ | 8,947 |  |  | $ | 612 |  | $ | 9,559 |  |
| (1) Non-Acute Care segment includes MTS results from May 21, 2012, the date of acquisition. |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000926326-13-000016:notes:154]
Segments

[0000926326-13-000016:notes:155]
Beginning with the acquisition of MTS in May, 2012, we have organized our business into two operating business segments: Acute Care, which primarily includes products and services sold to hospital customers and Non-Acute Care, which primarily includes products and services sold to customers outside of hospital settings.

[0000926326-13-000016:notes:156]
[same as prior period, unchanged from 0000926326-13-000013:notes:152]

[0000926326-13-000016:notes:157]
[same as prior period, unchanged from 0000926326-13-000013:notes:153]

[0000926326-13-000016:notes:158]
[same as prior period, unchanged from 0000926326-13-000013:notes:154]

[0000926326-13-000016:notes:159]
During 2012, we realigned our management reporting structure to report sales of Omnicell's dispensing systems and other related business transactions to long-term care pharmacies and facilities. Accordingly, the operations of this portion of our activities are now being reflected as a part of the Non-Acute Care segment for three and nine months ended September 30, 2013.

[0000926326-13-000016:notes:160]
[same as prior period, unchanged from 0000926326-13-000013:notes:156]

[0000926326-13-000016:notes:161]
Effective in the second quarter of 2013, our management changed its methodology for allocating certain expenses to our reportable segments. We have reclassified segment operating results for the three and nine months ended September 30, 2012 to conform to the 2013 presentation. For the three and nine months ended September 30, 2013 and 2012, the contributions of our segments to net revenues and income from operations, and the reconciliation to total net income, were as follows (amounts in thousands):

[0000926326-13-000016:notes:162]
|  | Nine Months Ended September 30, 2013 |  | Nine Months Ended September 30, 2012 |
|  | Acute Care |  | Non-Acute Care |  | Total |  | Acute Care |  | Non-Acute Care (1) |  | Total |
| Net revenues from external customers | $ | 204,750 |  |  | $ | 70,085 |  |  | $ | 274,835 |  |  | $ | 191,295 |  |  | $ | 32,563 |  |  | $ | 223,858 |  |
| Cost of revenues | 87,784 |  |  | 40,276 |  |  | 128,060 |  |  | 82,859 |  |  | 19,787 |  |  | 102,646 |  |
| Gross profit | $ | 116,966 |  |  | $ | 29,809 |  |  | $ | 146,775 |  |  | $ | 108,436 |  |  | $ | 12,776 |  |  | $ | 121,212 |  |
| Gross margin % | 57.1 | % |  | 42.5 | % |  | 53.4 | % |  | 56.7 | % |  | 39.2 | % |  | 54.1 | % |
| Operating expenses | 96,048 |  |  | 26,483 |  |  | 122,531 |  |  | 94,167 |  |  | 9,753 |  |  | 103,920 |  |
| Income from operations | $ | 20,918 |  |  | $ | 3,326 |  |  | $ | 24,244 |  |  | $ | 14,269 |  |  | 3,023 |  |  | $ | 17,292 |  |
| Operating margin % | 10.2 | % |  | 4.7 | % |  | 8.8 | % |  | 7.5 | % |  | 9.3 | % |  | 7.7 | % |
| Interest and other income (expense), net |  |  |  |  | (134 | ) |  |  |  |  |  | 57 |  |
| Income before provision for income taxes |  |  |  |  | 24,110 |  |  |  |  |  |  | 17,349 |  |
| Provision for income taxes |  |  |  |  | 6,954 |  |  |  |  |  |  | 6,703 |  |
| Net income |  |  |  |  | $ | 17,156 |  |  |  |  |  |  | $ | 10,646 |  |
| (1) Non-Acute Care segment includes MTS results from May 21, 2012, the date of acquisition. |


## us-gaap:SegmentReportingPolicyPolicyTextBlock

[0000926326-13-000016:notes:163]
Segment information. Prior to the acquisition of MTS, we managed our business on the basis of a single operating segment, and a single reporting unit within that segment in accordance with ASC 280, Segment Reporting. Beginning with the acquisition of MTS in May 2012, we have organized our business into two operating business segments: Acute Care, which includes primarily products and services sold to hospital customers, and Non-Acute Care, which includes primarily products and services sold to customers outside of the hospital setting.


## us-gaap:ShippingAndHandlingCostPolicyTextBlock

[0000926326-13-000016:notes:164]
[same as prior period, unchanged from 0000926326-13-000013:notes:160]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000926326-13-000016:notes:165]
[same as prior period, unchanged from 0000926326-13-000013:notes:161]

[0000926326-13-000016:notes:166]
[same as prior period, unchanged from 0000926326-13-000013:notes:162]

[0000926326-13-000016:notes:167]
[same as prior period, unchanged from 0000926326-13-000013:notes:163]

[0000926326-13-000016:notes:168]
[same as prior period, unchanged from 0000926326-13-000013:notes:164]

[0000926326-13-000016:notes:169]
There were no shares repurchased during both the three and nine months ended September 30, 2013 under the 2008 Repurchase Program. During the three months ended September 30, 2012, we repurchased 393,031 shares through the 2008 Repurchase Program at an average cost of $13.49 per share, including commissions, compared to 505,137 shares repurchased in the three months ended June 30, 2012 at an average cost of $13.98 per share, including commissions. For the nine months ended September 30, 2012, we repurchased 898,168 shares at an average cost of 13.76 per share, including commissions.

[0000926326-13-000016:notes:170]
From the inception of the 2008 Repurchase Program in February 2008 through September 30, 2013, we have repurchased a total of 5,853,975 shares at an average cost of $15.37 per share through open market purchases. As of September 30, 2013, we have completed the 2008 Repurchase Program having repurchased $90.0 million of our common stock.

[0000926326-13-000016:notes:171]
[same as prior period, unchanged from 0000926326-13-000013:notes:167]

[0000926326-13-000016:notes:172]
[same as prior period, unchanged from 0000926326-13-000013:notes:168]

[0000926326-13-000016:notes:173]
Through September 30, 2013, we have not repurchased any shares through the 2012 Repurchase Program.


## omcl:AccruedLiabilitiesTextBlock

[0000926326-13-000016:notes:174]
[same as prior period, unchanged from 0000926326-13-000013:notes:170]


## omcl:DeferredGrossProfitTableTextBlock

[0000926326-13-000016:notes:175]
[same as prior period, unchanged from 0000926326-13-000013:notes:171]

[0000926326-13-000016:notes:176]
|  | September 30, 2013 |  | December 31, 2012 |
| Sales of medication and supply dispensing systems and packaging equipment, which have been delivered and invoiced but not yet installed | $ | 40,919 |  |  | $ | 30,138 |  |
| Cost of revenues, excluding installation costs | (15,713 | ) |  | (9,366 | ) |
| Deferred gross profit | $ | 25,206 |  |  | $ | 20,772 |  |


## omcl:DeferredGrossProfitTextBlock

[0000926326-13-000016:notes:177]
[same as prior period, unchanged from 0000926326-13-000013:notes:173]


## omcl:ImpairmentOfSoftwareDevelopmentCostsTableTextBlock

[0000926326-13-000016:notes:178]
Asset Impairment

[0000926326-13-000016:notes:179]
[same as prior period, unchanged from 0000926326-13-000013:notes:175]

[0000926326-13-000016:notes:180]
As part of the continuing integration of MTS, during the first quarter of 2013, we reorganized our management team, including the software development department, within the Non-Acute Care segment. Through the end of the first quarter of 2013, the Non-Acute Care segment had capitalized approximately $1.8 million of software development costs. associated with a software solution under development which was intended to assist pharmacies in manual packaging of prescriptions. In connection with our financial statement close process for the quarter ended March 31, 2013, our management reassessed the viability of this project and the net realizable value of capitalized costs in light of its decision to change the related product road map and redesign this product based on evolving market demands. As part of this redesign process, new functionality and capabilities will need to be added to the product before commercialization. This redesign is intended to provide a more robust global platform providing larger scalability and significant functionality not contained in our current beta version. As such, we have determined we can no longer support the technological feasibility of this project in conjunction with our software capitalization policy. Therefore, we charged these costs, in the amount of $1.8 million ($0.03 per diluted share, net of tax), to expense as a component of research and development in the accompanying consolidated condensed statement of operations.


## omcl:NetInvestmentsInSalesTypeLeasesTextBlock

[0000926326-13-000016:notes:181]
[same as prior period, unchanged from 0000926326-13-000013:notes:177]

[0000926326-13-000016:notes:182]
[same as prior period, unchanged from 0000926326-13-000013:notes:178]

[0000926326-13-000016:notes:183]
|  | September 30, 2013 |  | December 31, 2012 |
| Net minimum lease payments to be received | $ | 18,788 |  |  | $ | 19,665 |  |
| Less unearned interest income portion | 1,157 |  |  | 1,205 |  |
| Net investment in sales-type leases | 17,631 |  |  | 18,460 |  |
| Less current portion(1) | 5,233 |  |  | 5,232 |  |
| Non-current net investment in sales-type leases(2) | $ | 12,398 |  |  | $ | 13,228 |  |

[0000926326-13-000016:notes:184]
(1)     A component of other current assets. This amount is net of allowance for doubtful accounts of $0.1 million as of September 30, 2013 and $0.5 million as of December 31, 2012.

[0000926326-13-000016:notes:185]
(2)     This amount is net of allowance for doubtful accounts of $0.1 million as of September 30, 2013 and $0.1 million as of December 31, 2012.
