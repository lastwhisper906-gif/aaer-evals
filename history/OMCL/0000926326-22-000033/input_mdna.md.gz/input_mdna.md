# OMCL MD&A — 0000926326-22-000033


## mdna

[0000926326-22-000033:mdna:1]
[same as prior period, unchanged from 0000926326-22-000027:mdna:1]

[0000926326-22-000033:mdna:2]
[same as prior period, unchanged from 0000926326-22-000027:mdna:2]

[0000926326-22-000033:mdna:3]
[same as prior period, unchanged from 0000926326-22-000027:mdna:3]

[0000926326-22-000033:mdna:4]
[same as prior period, unchanged from 0000926326-22-000027:mdna:4]

[0000926326-22-000033:mdna:5]
[same as prior period, unchanged from 0000926326-22-000027:mdna:5]

[0000926326-22-000033:mdna:6]
[same as prior period, unchanged from 0000926326-22-000027:mdna:6]

[0000926326-22-000033:mdna:7]
[same as prior period, unchanged from 0000926326-22-000027:mdna:7]

[0000926326-22-000033:mdna:8]
[same as prior period, unchanged from 0000926326-22-000027:mdna:8]

[0000926326-22-000033:mdna:9]
[same as prior period, unchanged from 0000926326-22-000027:mdna:9]

[0000926326-22-000033:mdna:10]
[same as prior period, unchanged from 0000926326-22-000027:mdna:10]

[0000926326-22-000033:mdna:11]
[same as prior period, unchanged from 0000926326-22-000027:mdna:11]

[0000926326-22-000033:mdna:12]
[same as prior period, unchanged from 0000926326-22-000027:mdna:12]

[0000926326-22-000033:mdna:13]
[same as prior period, unchanged from 0000926326-22-000027:mdna:13]

[0000926326-22-000033:mdna:14]
[same as prior period, unchanged from 0000926326-22-000027:mdna:14]

[0000926326-22-000033:mdna:15]
[same as prior period, unchanged from 0000926326-22-000027:mdna:15]

[0000926326-22-000033:mdna:16]
[same as prior period, unchanged from 0000926326-22-000027:mdna:16]

[0000926326-22-000033:mdna:17]
[same as prior period, unchanged from 0000926326-22-000027:mdna:17]

[0000926326-22-000033:mdna:18]
[same as prior period, unchanged from 0000926326-22-000027:mdna:18]

[0000926326-22-000033:mdna:19]
[same as prior period, unchanged from 0000926326-22-000027:mdna:19]

[0000926326-22-000033:mdna:20]
[same as prior period, unchanged from 0000926326-22-000027:mdna:20]

[0000926326-22-000033:mdna:21]
[same as prior period, unchanged from 0000926326-22-000027:mdna:21]

[0000926326-22-000033:mdna:22]
[same as prior period, unchanged from 0000926326-22-000027:mdna:22]

[0000926326-22-000033:mdna:23]
[same as prior period, unchanged from 0000926326-22-000027:mdna:23]

[0000926326-22-000033:mdna:24]
[same as prior period, unchanged from 0000926326-22-000027:mdna:24]

[0000926326-22-000033:mdna:25]
[same as prior period, unchanged from 0000926326-22-000027:mdna:25]

[0000926326-22-000033:mdna:26]
[same as prior period, unchanged from 0000926326-22-000027:mdna:26]

[0000926326-22-000033:mdna:27]
[same as prior period, unchanged from 0000926326-22-000027:mdna:27]

[0000926326-22-000033:mdna:28]
Facilities worldwide use our automation and analytics solutions to increase operational efficiency, reduce medication errors, deliver actionable intelligence, and improve patient safety. Institutional and retail pharmacies across North America, the United Kingdom, Germany, and Australia leverage our innovative medication adherence and population health solutions to improve patient engagement and adherence to prescriptions, helping to reduce costly hospital readmissions. We sell our product and consumable solutions together with related service offerings. Revenues generated in the United States represented 91% and 92% of our total revenues for the three months ended September 30, 2022 and 2021, respectively, and 90% of our total revenues for both the nine months ended September 30, 2022 and 2021.

[0000926326-22-000033:mdna:29]
Over the past several years, our business has expanded from a single-point solution to a platform of products and services that we believe will help to further advance the industry vision of the Autonomous Pharmacy. This expansion has resulted in larger deal sizes across multiple products, services, and implementations for customers and, we believe, more comprehensive, valuable, and enduring relationships.

[0000926326-22-000033:mdna:30]
We utilize product bookings as an indicator of the success of our business. Product bookings generally consist of firm orders other than for technical services and other less significant items, as evidenced generally by a non-cancelable contract and purchase order for equipment, software products, and Advanced Services, and by a purchase order or through our Omnicell Storefront online ordering platform for consumables. A significant portion of our connected devices and software license product bookings are installable within twelve months of booking, and are recorded as revenue upon customer acceptance of the installation or receipt of goods. Revenues from software-as-a-service (“SaaS”), subscription software, and technology-enabled services product bookings are recorded over the contractual term.

[0000926326-22-000033:mdna:31]
In addition to product solution sales, we provide a range of services to our customers. We provide installation planning and consulting as part of most product sales, which is generally included in the initial price of the solution. We also provide Advanced Services such as Omnicell One, EnlivenHealth, 340B solutions, Specialty Pharmacy Services, Central Pharmacy Dispensing Services, and Central Pharmacy Compounding Services. To help assure the maximum availability of our systems, our customers typically purchase maintenance and support contracts in increments of one to five years. As a result of the growth of our installed base of customers and expanded service offerings, our service revenues have also grown.

[0000926326-22-000033:mdna:32]
[same as prior period, unchanged from 0000926326-22-000027:mdna:32]

[0000926326-22-000033:mdna:33]
[same as prior period, unchanged from 0000926326-22-000027:mdna:33]

[0000926326-22-000033:mdna:34]
[same as prior period, unchanged from 0000926326-22-000027:mdna:34]

[0000926326-22-000033:mdna:35]
[same as prior period, unchanged from 0000926326-22-000027:mdna:35]

[0000926326-22-000033:mdna:36]
[same as prior period, unchanged from 0000926326-22-000027:mdna:36]

[0000926326-22-000033:mdna:37]
Our full-time employee headcount was approximately 4,160 and 3,800 on September 30, 2022 and December 31, 2021, respectively.

[0000926326-22-000033:mdna:38]
[same as prior period, unchanged from 0000926326-22-000027:mdna:38]

[0000926326-22-000033:mdna:39]
[same as prior period, unchanged from 0000926326-22-000027:mdna:39]

[0000926326-22-000033:mdna:40]
[same as prior period, unchanged from 0000926326-22-000027:mdna:40]

[0000926326-22-000033:mdna:41]
[same as prior period, unchanged from 0000926326-22-000027:mdna:41]

[0000926326-22-000033:mdna:42]
[same as prior period, unchanged from 0000926326-22-000027:mdna:42]

[0000926326-22-000033:mdna:43]
•Central Pharmacy.  This market represents the beginning of the medication management process in acute care settings, and, we believe, the next big automation opportunity to replace high volumes of manual and repetitive processes that are common in pharmacies today. Manual processes are prone to significant errors, and products such as IVX Workflow, our IV Sterile Compounding Service (including IV robotics), and our Central Pharmacy Dispensing Service (including the XR2 Automated Central Pharmacy System), automate these manual processes and are designed to reduce the risk of error for our healthcare partners. Because automation adoption in the Central Pharmacy is still nascent, we believe that the adoption of solutions will be accelerated by bundling those solutions with technology-enabled services that are designed to deliver specific outcomes and leverage intelligence across the enterprise for more actionable insights, and are expected to reduce administrative burden, allowing clinicians to operate at the top of their license. We think that these bundled solutions are becoming more critical than ever as health systems continue to face increasing labor shortages and supply chain disruptions. Additionally, we believe new products, innovations and our expertise in the Central Pharmacy market create opportunities to replace prior generation Central Pharmacy robotics, especially when combining those robotics with carousels and technology-enabled services to increase the percentage of medication managed through the intelligent infrastructure.

[0000926326-22-000033:mdna:44]
[same as prior period, unchanged from 0000926326-22-000027:mdna:44]

[0000926326-22-000033:mdna:45]
Studies have shown that specialty medications represent over 50% of the country’s total spending on retail, mail-order, and provider-administered drugs. Used for treatment of complex conditions, these medications often require intensive patient management and specialized workflows for dispensing and care coordination. Specialty pharmacies serve as the connection between patients, prescribing physicians, and payors to ensure streamlined access and adherence to these specialty drugs, helping to maintain continuity of care throughout the process, and are expected to improve margin and profitability for the health system. Specialty Pharmacy Services is a turnkey offering with dedicated services to set up, operate, and optimize a specialty pharmacy program, and is designed to help health systems launch and/or optimize a fully managed, hospital-owned specialty pharmacy. Our Specialty

[0000926326-22-000033:mdna:46]
Pharmacy Services solution is intended to deliver: (i) improved access to specialty medications to enhance care and support patient outcomes; (ii) financial outcomes for customers through a ‘value-based’ service model that is expected to drive financial results and (iii) a single vendor that provides the technology, services, and broad expertise to support medication management needs from hospital to home.

[0000926326-22-000033:mdna:47]
The 340B market is targeted to covered entities participating in Section 340B of the Public Health Services Act. The Public Health Services Act requires pharmaceutical manufacturers participating in Medicaid to sell outpatient drugs at discounted prices to healthcare organizations that care for many uninsured and low-income patients and creates a complex compliance environment. According to the Health Resources and Services Administration, which is responsible for administering the 340B program, enrolled hospitals and other covered entities can achieve an average savings of 25% to 50% in pharmaceutical purchases. Due to the complexities of adhering to the administrative process of the 340B program, as well as potential drug manufacturer actions further complicating the 340B program landscape, we believe that there are significant opportunities for health systems to improve participation benefits and maximize program savings through our 340B technology-enabled services.

[0000926326-22-000033:mdna:48]
[same as prior period, unchanged from 0000926326-22-000027:mdna:47]

[0000926326-22-000033:mdna:49]
[same as prior period, unchanged from 0000926326-22-000027:mdna:48]

[0000926326-22-000033:mdna:50]
[same as prior period, unchanged from 0000926326-22-000027:mdna:49]

[0000926326-22-000033:mdna:51]
[same as prior period, unchanged from 0000926326-22-000027:mdna:50]

[0000926326-22-000033:mdna:52]
[same as prior period, unchanged from 0000926326-22-000027:mdna:51]

[0000926326-22-000033:mdna:53]
[same as prior period, unchanged from 0000926326-22-000027:mdna:52]

[0000926326-22-000033:mdna:54]
On May 4, 2022, we determined that certain of our information technology systems were affected by ransomware impacting certain internal systems. Upon detecting the security event, we took immediate steps designed to contain the incident and implement our business continuity plans to restore and support continued operations. We have contained the incident and restored substantially all of our critical information technology systems. As a result of the ransomware incident, invoicing was delayed, which impacted the timing of cash collections and free cash flow in the second quarter of 2022. In addition, total revenues were slightly below expectations for the second quarter of 2022 as customer implementations were delayed due to the ransomware incident. During the third quarter of 2022, we continued to experience implementation delays as we recovered from the impacts of the ransomware incident. As of the end of the third quarter of 2022, a majority of the delayed implementations from the second quarter of 2022 have been implemented or are expected to be implemented in the fourth

[0000926326-22-000033:mdna:55]
quarter of 2022. Furthermore, as of the end of the third quarter of 2022, any delayed or impacted processes have returned to normal operations. We do not believe the security event will have a material adverse effect on our business, results of operations, or financial condition.

[0000926326-22-000033:mdna:56]
[same as prior period, unchanged from 0000926326-22-000027:mdna:54]

[0000926326-22-000033:mdna:57]
On January 10, 2022, we completed the acquisition of Hub and Spoke Innovations, pursuant to the terms and conditions of the Share Purchase Agreement, dated January 10, 2022, by and among Omnicell Limited (a wholly-owned subsidiary of the Company), Hub and Spoke Innovations Limited, and certain beneficial stockholders specified therein for a base purchase price of £2.5 million (approximately $3.4 million based on the exchange rate in effect at the acquisition date), prior to customary adjustments for closing cash, net working capital, and assumed indebtedness. The Hub and Spoke Innovations acquisition is expected to complement Omnicell’s total solution technology portfolio for retail pharmacy in the United Kingdom to help pharmacies improve workflows, offer patients 24/7 access to their medications and provide enhanced patient care. The results of the operations of Hub and Spoke Innovations have been included in our consolidated results of operations beginning January 10, 2022.

[0000926326-22-000033:mdna:58]
[same as prior period, unchanged from 0000926326-22-000027:mdna:57]

[0000926326-22-000033:mdna:59]
On December 29, 2021, we completed the acquisition of ReCept pursuant to the terms and conditions of the Agreement and Plan of Merger, dated December 1, 2021, by and among Omnicell, Inc., ReCept Holdings, Inc., Redfish Acquisition Corp, and the representative of the securityholders for a base purchase price of $100.0 million, prior to customary adjustments for closing cash, net working capital, and assumed indebtedness. The addition of ReCept’s specialty pharmacy management services, now a part of the Company’s Specialty Pharmacy Services, for health systems, provider groups, and federally qualified health centers expands Omnicell’s Advanced Services portfolio in an effort to address the growing and complex specialty pharmacy market. The results of the operations of ReCept have been included in our consolidated results of operations beginning December 29, 2021.

[0000926326-22-000033:mdna:60]
[same as prior period, unchanged from 0000926326-22-000027:mdna:59]

[0000926326-22-000033:mdna:61]
[same as prior period, unchanged from 0000926326-22-000027:mdna:60]

[0000926326-22-000033:mdna:62]
[same as prior period, unchanged from 0000926326-22-000027:mdna:61]

[0000926326-22-000033:mdna:63]
[same as prior period, unchanged from 0000926326-22-000027:mdna:62]

[0000926326-22-000033:mdna:64]
[same as prior period, unchanged from 0000926326-22-000027:mdna:63]

[0000926326-22-000033:mdna:65]
[same as prior period, unchanged from 0000926326-22-000027:mdna:64]

[0000926326-22-000033:mdna:66]
[same as prior period, unchanged from 0000926326-22-000027:mdna:65]

[0000926326-22-000033:mdna:67]
[same as prior period, unchanged from 0000926326-22-000027:mdna:66]

[0000926326-22-000033:mdna:68]
[same as prior period, unchanged from 0000926326-22-000027:mdna:67]

[0000926326-22-000033:mdna:69]
[same as prior period, unchanged from 0000926326-22-000027:mdna:68]

[0000926326-22-000033:mdna:70]
[same as prior period, unchanged from 0000926326-22-000027:mdna:69]

[0000926326-22-000033:mdna:71]
[same as prior period, unchanged from 0000926326-22-000027:mdna:70]

[0000926326-22-000033:mdna:72]
[same as prior period, unchanged from 0000926326-22-000027:mdna:71]

[0000926326-22-000033:mdna:73]
[same as prior period, unchanged from 0000926326-22-000027:mdna:72]

[0000926326-22-000033:mdna:74]
There were no material changes in the matters for which we make critical accounting estimates in the preparation of our Condensed Consolidated Financial Statements during the nine months ended September 30, 2022 as compared to those disclosed in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” included in our Annual Report on Form 10-K for the year ended December 31, 2021, except as discussed in “Recently Adopted Authoritative Guidance” in Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000926326-22-000033:mdna:75]
[same as prior period, unchanged from 0000926326-22-000027:mdna:74]

[0000926326-22-000033:mdna:76]
Refer to “Recently Issued Authoritative Guidance” in Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q for a description of recently issued accounting pronouncements, including the expected dates of adoption and estimated effects on our results of operations, financial position, and cash flows.

[0000926326-22-000033:mdna:77]
[same as prior period, unchanged from 0000926326-22-000027:mdna:76]

[0000926326-22-000033:mdna:78]
[same as prior period, unchanged from 0000926326-22-000027:mdna:77]

[0000926326-22-000033:mdna:79]
|  | Three Months Ended September 30, |
|  |  |  |  |  | Change in |
|  | 2022 |  | 2021 |  | $ |  | % |
|  | (Dollars in thousands) |
| Product revenues | $ | 246,565 |  |  | $ | 213,970 |  |  | $ | 32,595 |  |  | 15% |
| Percentage of total revenues | 71% |  | 72% |  |  |  |  |
| Services and other revenues | 101,494 |  |  | 82,432 |  |  | 19,062 |  |  | 23% |
| Percentage of total revenues | 29% |  | 28% |  |  |  |  |
| Total revenues | $ | 348,059 |  |  | $ | 296,402 |  |  | $ | 51,657 |  |  | 17% |

[0000926326-22-000033:mdna:80]
Product revenues represented 71% and 72% of total revenues for the three months ended September 30, 2022 and 2021, respectively. Product revenues increased by $32.6 million, due to increased customer demand, primarily within our automated dispensing systems business, and increased revenues from our XR2 Automated Central Pharmacy Systems.

[0000926326-22-000033:mdna:81]
Services and other revenues represented 29% and 28% of total revenues for the three months ended September 30, 2022 and 2021, respectively. Services and other revenues include revenues from technical services; SaaS, subscription software, and technology-enabled services; and other services. Services and other revenues increased by $19.1 million, primarily due to incremental revenues from our recent acquisitions of FDS Amplicare, ReCept, and MarkeTouch Media, as well as continued growth in our installed customer base and our expanded portfolio of services and solutions. The increase was partially offset by a decrease in revenues from 340B solutions primarily due to impacts from decreasing provider utilization of the 340B program as a result of recent drug manufacturer actions.

[0000926326-22-000033:mdna:82]
Our international sales represented 9% and 8% of total revenues for the three months ended September 30, 2022 and 2021, respectively, and are expected to be affected by foreign currency exchange rate fluctuations. We are unable to predict the extent to which revenues in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-22-000033:mdna:83]
|  | Nine Months Ended September 30, |
|  |  |  |  |  | Change in |
|  | 2022 |  | 2021 |  | $ |  | % |
|  | (Dollars in thousands) |
| Product revenues | $ | 706,246 |  |  | $ | 589,006 |  |  | $ | 117,240 |  |  | 20% |
| Percentage of total revenues | 71% |  | 72% |  |  |  |  |
| Services and other revenues | 292,027 |  |  | 231,978 |  |  | 60,049 |  |  | 26% |
| Percentage of total revenues | 29% |  | 28% |  |  |  |  |
| Total revenues | $ | 998,273 |  |  | $ | 820,984 |  |  | $ | 177,289 |  |  | 22% |

[0000926326-22-000033:mdna:84]
Product revenues represented 71% and 72% of total revenues for the nine months ended September 30, 2022 and 2021, respectively. Product revenues increased by $117.2 million, due to increased customer demand, primarily within our automated dispensing systems business, as well as increased revenues from our IV solutions and XR2 Automated Central Pharmacy Systems.

[0000926326-22-000033:mdna:85]
Services and other revenues represented 29% and 28% of total revenues for the nine months ended September 30, 2022 and 2021, respectively. Services and other revenues include revenues from technical services; SaaS, subscription software, and technology-enabled services; and other services. Services and other revenues increased by $60.0 million, primarily due to incremental revenues from our recent acquisitions of FDS Amplicare, ReCept, and MarkeTouch Media, as well as continued growth in our installed customer base and our expanded portfolio of services and solutions. The increase was partially offset by a decrease in revenues from 340B solutions primarily due to impacts from decreasing provider utilization of the 340B program as a result of recent drug manufacturer actions.

[0000926326-22-000033:mdna:86]
Our international sales represented 10% of total revenues for both the nine months ended September 30, 2022 and 2021, and are expected to be affected by foreign currency exchange rate fluctuations. We are unable to predict the extent to which revenues in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-22-000033:mdna:87]
Our ability to continue to grow revenues is dependent on our ability to continue to obtain orders from customers, which may be dependent upon customers’ capital equipment budgets and/or capital equipment approval cycles, our ability to produce quality products and consumables to fulfill customer demand, the volume of installations we are able to complete, our ability to meet customer needs by providing a quality installation experience, our ability to develop new or enhance existing solutions, and our flexibility in workforce allocations among customers to complete installations on a timely basis. The timing of our product revenues for equipment is primarily dependent on when our customers’ schedules and/or staffing levels allow for installations.

[0000926326-22-000033:mdna:88]
[same as prior period, unchanged from 0000926326-22-000027:mdna:87]

[0000926326-22-000033:mdna:89]
[same as prior period, unchanged from 0000926326-22-000027:mdna:88]

[0000926326-22-000033:mdna:90]
|  | Three Months Ended September 30, |
|  |  |  |  |  | Change in |
|  | 2022 |  | 2021 |  | $ |  | % |
|  | (Dollars in thousands) |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | $ | 134,023 |  |  | $ | 110,743 |  |  | $ | 23,280 |  |  | 21% |
| As a percentage of related revenues | 54% |  | 52% |  |  |  |  |
| Cost of services and other revenues | 54,941 |  |  | 38,880 |  |  | 16,061 |  |  | 41% |
| As a percentage of related revenues | 54% |  | 47% |  |  |  |  |
| Total cost of revenues | $ | 188,964 |  |  | $ | 149,623 |  |  | $ | 39,341 |  |  | 26% |
| As a percentage of total revenues | 54% |  | 50% |  |  |  |  |
| Gross profit | $ | 159,095 |  |  | $ | 146,779 |  |  | $ | 12,316 |  |  | 8% |
| Gross margin | 46% |  | 50% |  |  |  |  |

[0000926326-22-000033:mdna:91]
Cost of revenues for the three months ended September 30, 2022 compared to the three months ended September 30, 2021 increased by $39.3 million, of which $23.3 million was attributed to the increase in cost of product revenues and $16.1 million was attributed to the increase in cost of services and other revenues.

[0000926326-22-000033:mdna:92]
The increase in cost of product revenues was primarily driven by the increase in product revenues of $32.6 million for the three months ended September 30, 2022 compared to the three months ended September 30, 2021. The increase was also driven by inventory-related costs due to inflationary impacts, as well as higher employee-related and travel expenses due to increased headcount. This increase was partially offset by the benefits associated with economies of scale due to higher volumes during the three months ended September 30, 2022 compared to the three months ended September 30, 2021.

[0000926326-22-000033:mdna:93]
The increase in cost of services and other revenues was primarily driven by the increase in services and other revenues of $19.1 million, including incremental revenues from our recent acquisitions, for the three months ended September 30, 2022 compared to the three months ended September 30, 2021. The cost of service and other revenues grew at a faster pace than our service and other revenues primarily due to additional investments in our service business to support new service solutions, the impact of lower 340B solutions revenues, and the mix of service revenues recognized in the quarter.

[0000926326-22-000033:mdna:94]
The overall decrease in gross margin primarily relates to additional investments in our business, including our service solutions, the impact of lower 340B solutions revenues, and the mix of service revenues recognized in the quarter, as well as inflationary impacts on inventory-related costs and higher employee-related and travel expenses. The decrease is partially offset by higher revenues for the three months ended September 30, 2022 due to increased customer demand as well as benefits associated with economies of scale due to higher volumes. Our gross profit for the three months ended September 30, 2022 was $159.1 million, as compared to $146.8 million for the three months ended September 30, 2021.

[0000926326-22-000033:mdna:95]
|  | Nine Months Ended September 30, |
|  |  |  |  |  | Change in |
|  | 2022 |  | 2021 |  | $ |  | % |
|  | (Dollars in thousands) |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | $ | 374,175 |  |  | $ | 303,597 |  |  | $ | 70,578 |  |  | 23% |
| As a percentage of related revenues | 53% |  | 52% |  |  |  |  |
| Cost of services and other revenues | 156,864 |  |  | 112,027 |  |  | 44,837 |  |  | 40% |
| As a percentage of related revenues | 54% |  | 48% |  |  |  |  |
| Total cost of revenues | $ | 531,039 |  |  | $ | 415,624 |  |  | $ | 115,415 |  |  | 28% |
| As a percentage of total revenues | 53% |  | 51% |  |  |  |  |
| Gross profit | $ | 467,234 |  |  | $ | 405,360 |  |  | $ | 61,874 |  |  | 15% |
| Gross margin | 47% |  | 49% |  |  |  |  |

[0000926326-22-000033:mdna:96]
[same as prior period, unchanged from 0000926326-22-000027:mdna:99]

[0000926326-22-000033:mdna:97]
Cost of revenues for the nine months ended September 30, 2022 compared to the nine months ended September 30, 2021 increased by $115.4 million, of which $70.6 million was attributed to the increase in cost of product revenues and $44.8 million was attributed to the increase in cost of services and other revenues.

[0000926326-22-000033:mdna:98]
The increase in cost of product revenues was primarily driven by the increase in product revenues of $117.2 million for the nine months ended September 30, 2022 compared to the nine months ended September 30, 2021. The increase was also driven by increased inventory-related costs due to inflationary impacts, as well as higher employee-related and travel expenses due to increased headcount. This increase was partially offset by the benefits associated with economies of scale due to higher volumes during the nine months ended September 30, 2022 compared to the nine months ended September 30, 2021.

[0000926326-22-000033:mdna:99]
The increase in cost of services and other revenues was primarily driven by the increase in services and other revenues of $60.0 million, including incremental revenues from our recent acquisitions, for the nine months ended September 30, 2022 compared to the nine months ended September 30, 2021. The cost of service and other revenues grew at a faster pace than our service and other revenues primarily due to additional investments in our service business to support new service solutions, the impact of lower 340B solutions revenues, and the mix of service revenues recognized in the nine months ended September 30, 2022.

[0000926326-22-000033:mdna:100]
The overall decrease in gross margin primarily relates to additional investments in our business, including our service solutions, the impact of lower 340B solutions revenues, and the mix of service revenues recognized in the quarter, as well as inflationary impacts on inventory-related costs and higher employee-related and travel expenses. The decrease is partially offset by higher revenues for the nine months ended September 30, 2022 due to increased customer demand as well as benefits associated with economies of scale due to higher volumes. Our gross profit for the nine months ended September 30, 2022 was $467.2 million, as compared to $405.4 million for the nine months ended September 30, 2021.

[0000926326-22-000033:mdna:101]
[same as prior period, unchanged from 0000926326-22-000027:mdna:100]

[0000926326-22-000033:mdna:102]
|  | Three Months Ended September 30, |
|  |  |  |  |  | Change in |
|  | 2022 |  | 2021 |  | $ |  | % |
|  | (Dollars in thousands) |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | $ | 25,171 |  |  | $ | 19,477 |  |  | $ | 5,694 |  |  | 29% |
| As a percentage of total revenues | 7% |  | 7% |  |  |  |  |
| Selling, general, and administrative | 115,459 |  |  | 97,910 |  |  | 17,549 |  |  | 18% |
| As a percentage of total revenues | 33% |  | 33% |  |  |  |  |
| Total operating expenses | $ | 140,630 |  |  | $ | 117,387 |  |  | $ | 23,243 |  |  | 20% |
| As a percentage of total revenues | 40% |  | 40% |  |  |  |  |
| Interest and other income (expense), net | $ | (1,148) |  |  | $ | (6,065) |  |  | $ | 4,917 |  |  | (81)% |

[0000926326-22-000033:mdna:103]
Research and Development. Research and development expenses increased by $5.7 million for the three months ended September 30, 2022 compared to the three months ended September 30, 2021. The increase was primarily attributed to an increase in employee-related expenses of approximately $4.0 million due to increased headcount to support the continued development of our intelligent infrastructure and incremental headcount from recent acquisitions.

[0000926326-22-000033:mdna:104]
Selling, General, and Administrative. Selling, general, and administrative expenses increased by $17.5 million for the three months ended September 30, 2022 compared to the three months ended September 30, 2021. The increase was primarily due to an increase of approximately $8.3 million in employee-related expenses primarily related to increased headcount, including the incremental headcount from recent acquisitions, as well as an increase of $1.1 million of employee-related expenses related to restructuring initiatives. The increase was also driven by an increase in shipping and handling costs of $2.5 million, an increase in intangible asset amortization expense of $2.0 million, an increase in spending on travel and meetings of $1.4 million, an increase in spending on software of $1.4 million, and increases in other operating expenses. The increase was partially offset by a decrease of $4.6 million in acquisition-related expenses.

[0000926326-22-000033:mdna:105]
Interest and Other Income (Expense), Net. Interest and other income (expense), net changed by $4.9 million for the three months ended September 30, 2022 compared to the three months ended September 30, 2021, primarily driven by a $3.9 million decrease in other expenses and a $1.0 million increase in other income. The decrease in other expenses during the three months ended September 30, 2022 as compared to the three months ended September 30, 2021 is primarily due to the adoption

[0000926326-22-000033:mdna:106]
of ASU 2020-06, effective January 1, 2022, which eliminated the imputed interest expense recognized on our convertible senior notes (refer to Note 1, Organization and Summary of Significant Accounting Policies, for additional information), partially offset by unfavorable foreign currency fluctuations during the three months ended September 30, 2022. The increase in other income during the three months ended September 30, 2022 as compared to the three months ended September 30, 2021 is primarily due to higher interest income received due to higher interest rates.

[0000926326-22-000033:mdna:107]
|  | Nine Months Ended September 30, |
|  |  |  |  |  | Change in |
|  | 2022 |  | 2021 |  | $ |  | % |
|  | (Dollars in thousands) |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | $ | 76,556 |  |  | $ | 53,770 |  |  | $ | 22,786 |  |  | 42% |
| As a percentage of total revenues | 8% |  | 7% |  |  |  |  |
| Selling, general, and administrative | 354,644 |  |  | 273,672 |  |  | 80,972 |  |  | 30% |
| As a percentage of total revenues | 36% |  | 33% |  |  |  |  |
| Total operating expenses | $ | 431,200 |  |  | $ | 327,442 |  |  | $ | 103,758 |  |  | 32% |
| As a percentage of total revenues | 43% |  | 40% |  |  |  |  |
| Interest and other income (expense), net | $ | (2,973) |  |  | $ | (18,715) |  |  | $ | 15,742 |  |  | (84)% |

[0000926326-22-000033:mdna:108]
Research and Development. Research and development expenses increased by $22.8 million for the nine months ended September 30, 2022 compared to the nine months ended September 30, 2021. The increase was primarily attributed to an increase in employee-related expenses of approximately $17.4 million due to increased headcount to support the continued development of our intelligent infrastructure and incremental headcount from recent acquisitions, as well as an increase of $1.8 million in employee-related expenses for restructuring initiatives.

[0000926326-22-000033:mdna:109]
Selling, General, and Administrative. Selling, general, and administrative expenses increased by $81.0 million for the nine months ended September 30, 2022 compared to the nine months ended September 30, 2021. The increase was primarily due to an increase of approximately $41.9 million in employee-related expenses primarily related to increased headcount, including the incremental headcount from recent acquisitions, as well as an increase of $1.3 million in employee-related expenses for restructuring initiatives. The increase was also driven by an increase in spending on travel and meetings of $6.8 million, an increase in intangible asset amortization expense of $6.2 million, an increase in shipping and handling costs of $4.9 million, an increase in spending on software of $3.2 million, an increase in consulting expenses of $2.2 million, and increases in other operating expenses. In addition, we incurred impairment and abandonment charges to operating lease right-of-use assets of $5.4 million and ransomware-related expenses, net of insurance recoveries, of $1.9 million during the nine months ended September 30, 2022. The increase was partially offset by a decrease of $6.5 million in acquisition-related expenses.

[0000926326-22-000033:mdna:110]
Interest and Other Income (Expense), Net. Interest and other income (expense), net changed by $15.7 million for the nine months ended September 30, 2022 compared to the nine months ended September 30, 2021, primarily driven by a $13.4 million decrease in other expenses and a $2.3 million increase in other income. The decrease in other expenses during the nine months ended September 30, 2022 as compared to the nine months ended September 30, 2021 is primarily due to the adoption of ASU 2020-06, effective January 1, 2022, which eliminated the imputed interest expense recognized on our convertible senior notes (refer to Note 1, Organization and Summary of Significant Accounting Policies, for additional information). The increase in other income during the nine months ended September 30, 2022 as compared to the nine months ended September 30, 2021 is primarily attributable to benefits from certain arrangements outside of our normal course of business, as well as higher interest income received due to higher interest rates.

[0000926326-22-000033:mdna:111]
41

[0000926326-22-000033:mdna:112]
[same as prior period, unchanged from 0000926326-22-000027:mdna:110]

[0000926326-22-000033:mdna:113]
|  | Three Months Ended September 30, |
|  |  |  |  |  | Change in |
|  | 2022 |  | 2021 |  | $ |  | % |
|  | (Dollars in thousands) |
| Provision for (benefit from) income taxes | $ | 543 |  |  | $ | (5,990) |  |  | $ | 6,533 |  |  | (109)% |

[0000926326-22-000033:mdna:114]
|  | Nine Months Ended September 30, |
|  |  |  |  |  | Change in |
|  | 2022 |  | 2021 |  | $ |  | % |
|  | (Dollars in thousands) |
| Provision for (benefit from) income taxes | $ | (995) |  |  | $ | (4,665) |  |  | $ | 3,670 |  |  | (79)% |

[0000926326-22-000033:mdna:115]
Our annual effective tax rate before discrete items was 17.8% and 28.2% for the nine months ended September 30, 2022 and 2021, respectively. The decrease in the estimated annual effective tax rate for the nine months ended September 30, 2022 compared to the same period in 2021 was primarily due to a decrease in non-deductible expenses, and an increase in research and development credits and FDII benefit.

[0000926326-22-000033:mdna:116]
Benefit from income taxes for the nine months ended September 30, 2022 included net discrete income tax benefit of $6.9 million, primarily due to a $6.2 million tax benefit from equity compensation.

[0000926326-22-000033:mdna:117]
Benefit from income taxes for the nine months ended September 30, 2021 included net discrete income tax benefit of $21.4 million, primarily due to a $14.5 million tax benefit from equity compensation.

[0000926326-22-000033:mdna:118]
Effective January 1, 2022, the Tax Cuts and Jobs Act of 2017 eliminated the ability to deduct research and development expenditures and required those expenditures to be amortized. While this change has not materially impacted our effective tax rate, the provision may impact our cash flows and increase the amount of cash taxes we pay.

[0000926326-22-000033:mdna:119]
[same as prior period, unchanged from 0000926326-22-000027:mdna:117]

[0000926326-22-000033:mdna:120]
[same as prior period, unchanged from 0000926326-22-000027:mdna:118]

[0000926326-22-000033:mdna:121]
We had cash and cash equivalents of $266.4 million at September 30, 2022 compared to $349.1 million at December 31, 2021. All of our cash and cash equivalents are invested in bank accounts and money market funds held in sweep and asset management accounts with major financial institutions.

[0000926326-22-000033:mdna:122]
Our cash position and working capital at September 30, 2022 and December 31, 2021 were as follows:

[0000926326-22-000033:mdna:123]
|  | September 30,2022 |  | December 31,2021 |
|  | (In thousands) |
| Cash and cash equivalents | $ | 266,402 |  |  | $ | 349,051 |  |
| Working capital (deficit) (1) | $ | 472,451 |  |  | $ | (95,456) |  |

[0000926326-22-000033:mdna:124]
[same as prior period, unchanged from 0000926326-22-000027:mdna:122]

[0000926326-22-000033:mdna:125]
[same as prior period, unchanged from 0000926326-22-000027:mdna:123]

[0000926326-22-000033:mdna:126]
Our ratio of current assets to current liabilities was 2.3:1 and 0.9:1 at September 30, 2022 and December 31, 2021, respectively.

[0000926326-22-000033:mdna:127]
[same as prior period, unchanged from 0000926326-22-000027:mdna:125]

[0000926326-22-000033:mdna:128]
Revolving Credit Facility

[0000926326-22-000033:mdna:129]
On November 15, 2019, we entered into an Amended and Restated Credit Agreement (as subsequently amended, as discussed below, the “A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers, and Wells Fargo Bank, National Association, as

[0000926326-22-000033:mdna:130]
administrative agent. The A&R Credit Agreement superseded our 2016 senior secured credit facility and provides for (a) a five-year revolving credit facility of $500.0 million (the “Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million. In addition, the A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million.

[0000926326-22-000033:mdna:131]
On September 22, 2020, the parties entered into an amendment to the A&R Credit Agreement to, among other changes, permit the issuance of the convertible senior notes and the purchase of the convertible note hedge transactions described below, expand our flexibility to repurchase our common stock and make other restricted payments, and replace the total net leverage covenant with a new secured net leverage covenant that required us to maintain a consolidated secured net leverage ratio not to exceed 3.50:1 for the calendar quarters ending September 30, 2020, December 31, 2020, and March 31, 2021 and requires us to maintain a consolidated secured net leverage ratio not to exceed 3.00:1 for the calendar quarters ending thereafter.

[0000926326-22-000033:mdna:132]
As of September 30, 2022, there was no outstanding balance for the Revolving Credit Facility and we were in compliance with all covenants. Refer to Note 9, Debt and Credit Agreement, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional information. We expect to use future loans under the Revolving Credit Facility, if any, for working capital, potential acquisitions, and other general corporate purposes.

[0000926326-22-000033:mdna:133]
[same as prior period, unchanged from 0000926326-22-000027:mdna:130]

[0000926326-22-000033:mdna:134]
[same as prior period, unchanged from 0000926326-22-000027:mdna:131]

[0000926326-22-000033:mdna:135]
The 2016 Repurchase Program has a total of $2.7 million remaining for future repurchases as of September 30, 2022, which may result in additional use of cash. During the first quarter of 2022, the 2014 Repurchase Program was completed. During the nine months ended September 30, 2022, we repurchased approximately 389,300 shares of our common stock under our repurchase programs at an average price of $134.11 per share for an aggregate purchase price of approximately $52.2 million. Refer to “Stock Repurchase Programs” under Note 15, Employee Benefits and Share-Based Compensation, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional information.

[0000926326-22-000033:mdna:136]
Based on our current business plan and product backlog, we believe that our existing cash and cash equivalents, our anticipated cash flows from operations, cash generated from the exercise of employee stock options and purchases under our Employee Stock Purchase Plan (“ESPP”), along with the availability of funds under the Revolving Credit Facility will be sufficient to meet our cash needs for working capital, capital expenditures, potential acquisitions, and other contractual obligations for at least the next twelve months. For periods beyond the next twelve months, we also anticipate that our net operating cash flows plus existing balances of cash and cash equivalents will suffice to fund the continued growth of our business.

[0000926326-22-000033:mdna:137]
[same as prior period, unchanged from 0000926326-22-000027:mdna:134]

[0000926326-22-000033:mdna:138]
[same as prior period, unchanged from 0000926326-22-000027:mdna:135]

[0000926326-22-000033:mdna:139]
|  | Nine Months Ended September 30, |
|  | 2022 |  | 2021 |
|  | (In thousands) |
| Net cash provided by (used in): |  |  |  |
| Operating activities | $ | (4,372) |  |  | $ | 172,177 |  |
| Investing activities | (41,417) |  |  | (220,113) |  |
| Financing activities | (24,515) |  |  | 40,697 |  |
| Effect of exchange rate changes on cash and cash equivalents | (1,425) |  |  | (492) |  |
| Net decrease in cash, cash equivalents, and restricted cash | $ | (71,729) |  |  | $ | (7,731) |  |

[0000926326-22-000033:mdna:140]
[same as prior period, unchanged from 0000926326-22-000027:mdna:137]

[0000926326-22-000033:mdna:141]
[same as prior period, unchanged from 0000926326-22-000027:mdna:138]

[0000926326-22-000033:mdna:142]
Net cash used in operating activities was $4.4 million for the nine months ended September 30, 2022, primarily consisting of net income of $34.1 million adjusted for non-cash items of $117.1 million, offset by changes in assets and liabilities of $155.6 million. The non-cash items primarily consisted of depreciation and amortization expense of $64.8 million, share-based compensation expense of $50.7 million, amortization of operating lease right-of-use assets of $9.7 million, impairment and abandonment of operating lease right-of-use assets of $5.4 million, amortization of debt issuance costs of $3.1 million, and a change in deferred income taxes of $17.1 million. Changes in assets and liabilities include cash outflows from (i) an increase in accounts receivable and unbilled receivables of $116.9 million primarily due to an increase in billings driven by overall business growth and the timing of shipments and collections, (ii) an increase in inventories of $32.3 million primarily to support forecasted sales, including advanced purchases of certain components, such as semiconductors, as well as higher costs of inventory and timing of shipments, (iii) a decrease in accrued compensation of $27.9 million primarily due to a decrease in accrued commissions and bonuses, as well as timing of payroll and ESPP purchases, (iv) an increase in investment in sales-type leases of $17.3 million primarily due to the increase in sales-type lease revenues associated with certain Advanced Services products, (v) a decrease in operating lease liabilities of $11.0 million, and (vi) an increase in prepaid expenses of $2.6 million. These cash outflows were partially offset by (i) an increase in deferred revenues of $17.7 million primarily due to an increase in billings driven by the timing of shipments in order to meet customers' implementation schedules and recognition of revenues for products requiring installation, (ii) an increase in accrued liabilities of $11.7 million primarily due to an increase in taxes payable, (iii) a decrease in prepaid commissions of $8.8 million, (iv) a decrease in other current assets, net of funds held for customers, of $6.7 million primarily due to a decrease in prepaid income taxes, (v) a decrease in other long-term assets of $4.2 million, (vi) an increase in accounts payable of $2.0 million, and (vii) an increase in other long-term liabilities of $1.4 million.

[0000926326-22-000033:mdna:143]
Net cash provided by operating activities was $172.2 million for the nine months ended September 30, 2021, primarily consisting of net income of $63.9 million adjusted for non-cash items of $119.2 million, offset by changes in assets and liabilities of $10.9 million. The non-cash items primarily consisted of depreciation and amortization expense of $53.1 million, share-based compensation expense of $38.5 million, amortization of discount on convertible senior notes of $13.9 million, amortization of operating lease right-of-use assets of $8.8 million, amortization of debt issuance costs of $2.6 million, and a change in deferred income taxes of $2.0 million. Changes in assets and liabilities include cash outflows from (i) an increase in accounts receivable and unbilled receivables of $39.6 million primarily due to an increase in billings driven by overall business growth and the timing of shipments as well as collections, (ii) a decrease in accrued compensation of $12.0 million primarily due to a decrease in accrued commissions and bonuses, (iii) an increase in inventories of $10.1 million to support forecasted sales, including advanced purchases of certain components, and as well as higher costs of inventory, (iv) a decrease in operating lease liabilities of $9.4 million, (v) a decrease in other long-term liabilities of $9.2 million primarily due to a $6.2 million release of a certain net unrecognized tax benefit as a result of effective settlement with the tax authorities, (vi) an increase in prepaid expenses of $8.2 million primarily as a result of timing of certain insurance policies and other subscription obligations, (vii) an increase in other current assets of $1.1 million, and (viii) an increase in prepaid commissions of $1.0 million. These cash outflows were partially offset by (i) an increase in accounts payable of $33.1 million primarily due to an overall increase in spending, as well as timing of payments, (ii) an increase in deferred revenues of $21.2 million primarily due to an increase in billings driven by the timing of shipments in order to meet customers’ implementation schedules and recognition of revenues for products requiring installation, (iii) an increase in accrued liabilities of $20.1 million primarily due to an increase in rebates and lease buyout liabilities, (iv) a decrease in investment in sales-type leases of $2.7 million, and (vi) a decrease in other long-term assets of $2.6 million.

[0000926326-22-000033:mdna:144]
[same as prior period, unchanged from 0000926326-22-000027:mdna:141]

[0000926326-22-000033:mdna:145]
Net cash used in investing activities was $41.4 million for the nine months ended September 30, 2022, which consisted of $3.4 million consideration paid for the acquisition of Hub and Spoke Innovations, net of cash acquired, capital expenditures of $33.9 million for property and equipment, and $9.6 million for costs of software development for external use, partially offset by purchase price adjustments from business acquisitions of $5.5 million.

[0000926326-22-000033:mdna:146]
Net cash used in investing activities was $220.1 million for the nine months ended September 30, 2021, which consisted of $178.1 million consideration paid for the acquisition of FDS Amplicare, net of cash acquired, capital expenditures of $17.9 million for property and equipment, and $24.1 million for costs of software development for external use.

[0000926326-22-000033:mdna:147]
[same as prior period, unchanged from 0000926326-22-000027:mdna:145]

[0000926326-22-000033:mdna:148]
Net cash used in financing activities was $24.5 million for the nine months ended September 30, 2022, primarily due to $52.2 million for repurchases of our stock, and $11.4 million in employees’ taxes paid related to restricted stock unit vesting, partially offset by $39.5 million in proceeds from employee stock option exercises and ESPP purchases.

[0000926326-22-000033:mdna:149]
Net cash provided by financing activities was $40.7 million for the nine months ended September 30, 2021, primarily due to $53.9 million in proceeds from employee stock option exercises and ESPP purchases, partially offset by $10.2 million in employees’ taxes paid related to restricted stock unit vesting, and a net decrease in the customer funds balances of $3.1 million.

[0000926326-22-000033:mdna:150]
[same as prior period, unchanged from 0000926326-22-000027:mdna:148]

[0000926326-22-000033:mdna:151]
There have been no significant changes during the nine months ended September 30, 2022 to the contractual obligations disclosed in “Management’s Discussion and Analysis of Financial Condition and Results of Operations,” set forth in Part II, Item 7, of our Annual Report on Form 10-K for the year ended December 31, 2021.

[0000926326-22-000033:mdna:152]
Contractual obligations as of September 30, 2022 were as follows:

[0000926326-22-000033:mdna:153]
|  | Payments Due By Period |
|  | Total |  | Remainder of 2022 |  | 2023 - 2024 |  | 2025 - 2026 |  | 2027 and thereafter |
|  | (In thousands) |
| Operating leases (1) | $ | 60,688 |  |  | $ | 3,279 |  |  | $ | 25,130 |  |  | $ | 17,973 |  |  | $ | 14,306 |  |
| Purchase obligations (2) | 186,949 |  |  | 115,913 |  |  | 70,777 |  |  | 230 |  |  | 29 |  |
| Convertible senior notes (3) | 579,313 |  |  | — |  |  | 2,875 |  |  | 576,438 |  |  | — |  |
| Other (4) | 750 |  |  | 62 |  |  | 440 |  |  | 248 |  |  | — |  |
| Total (5) | $ | 827,700 |  |  | $ | 119,254 |  |  | $ | 99,222 |  |  | $ | 594,889 |  |  | $ | 14,335 |  |

[0000926326-22-000033:mdna:154]
[same as prior period, unchanged from 0000926326-22-000027:mdna:152]

[0000926326-22-000033:mdna:155]
[same as prior period, unchanged from 0000926326-22-000027:mdna:153]

[0000926326-22-000033:mdna:156]
[same as prior period, unchanged from 0000926326-22-000027:mdna:154]

[0000926326-22-000033:mdna:157]
[same as prior period, unchanged from 0000926326-22-000027:mdna:155]

[0000926326-22-000033:mdna:158]
[same as prior period, unchanged from 0000926326-22-000027:mdna:156]

[0000926326-22-000033:mdna:159]
(5)Refer to Note 13, Commitments and Contingencies, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional information.
