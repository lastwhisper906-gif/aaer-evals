# OMCL note change history — 0000926326-22-000027 → 0000926326-22-000033


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-11-04):
[0000926326-22-000033:note_history:1]
As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any material accrual for contingent liabilities associated with the legal proceeding described above based on its belief that any potential material loss, while reasonably possible, is not probable. Further, any possible range of loss in this matter cannot be reasonably estimated at this time or is not deemed material. The Company believes that it has valid defenses with respect to the legal proceeding pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of the legal proceeding or because of the diversion of management’s attention and the creation of significant expenses.
  (was, 2022-08-09, similarity 0.9436):
[0000926326-22-000027:note_history:1]
As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any material accrual for contingent liabilities associated with the legal proceedings described above based on its belief that any potential material loss, while reasonably possible, is not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time or is not deemed material. The Company believes that it has valid defenses with respect to these legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of any of these legal proceedings or because of the diversion of management’s attention and the creation of significant expenses.


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-11-04):
[0000926326-22-000033:note_history:2]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of September 30, 2022, the Company had non-cancelable purchase commitments of $186.9 million, of which $115.9 million are expected to be paid within the year ending December 31, 2022.
  (was, 2022-08-09, similarity 0.9765):
[0000926326-22-000027:note_history:2]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of June 30, 2022, the Company had non-cancelable purchase commitments of $226.5 million, of which $175.8 million are expected to be paid within the year ending December 31, 2022.

- changed (2022-11-04):
[0000926326-22-000033:note_history:3]
During the three months ended September 30, 2022, the Company incurred $1.0 million of expenses related to the ransomware incident, and during the nine months ended September 30, 2022, the Company incurred $13.5 million of expenses related to the ransomware incident, partially offset by $11.1 million of expected insurance recoveries. Expenses include costs to investigate and remediate the ransomware incident, as well as legal and other professional services, all of which were expensed as incurred. For the three and nine months ended September 30, 2022, the Company included net expenses related to the ransomware incident in cost of revenues of $0.1 million and $0.3 million, respectively; in research and development of $0.2 million and $0.2 million, respectively; and in selling general and administrative expenses of $0.7 million and $1.9 million, respectively, in the Company’s Condensed Consolidated Statements of Operations.
  (was, 2022-08-09, similarity 0.6937):
[0000926326-22-000027:note_history:3]
During the three months ended June 30, 2022, the Company incurred $12.5 million of expenses related to the ransomware incident, partially offset by $11.1 million of expected insurance recoveries. Expenses include costs to investigate and remediate the ransomware incident, as well as legal and other professional services, all of which were expensed as incurred. For the three months ended June 30, 2022, the Company included net expenses of $0.2 million in cost of revenues and $1.2 million in selling, general, and administrative expenses in the Company’s Condensed Consolidated Statements of Operations.

- changed (2022-11-04):
[0000926326-22-000033:note_history:4]
A class action lawsuit was filed against the Company, on June 5, 2019, in the Circuit Court of Cook County, Illinois, Chancery Division, captioned Corey Heard, individually and on behalf of all others similarly situated v. Omnicell, Inc., Case No. 2019-CH-06817 (the “Heard Action”). The complaint seeks class certification, monetary damages in the form of statutory damages for willful and/or reckless or, in the alternative, negligent violation of the Illinois Biometric Information Privacy Act (“BIPA”), and certain declaratory, injunctive, and other relief based on causes of action directed to allegations of violation of BIPA by the Company. The complaint was served on the Company on June 13, 2019. On July 31, 2019, the Company filed a motion to stay or consolidate the case with the action Yana Mazya, et al. v. Northwestern Lake Forest Hospital, et al., Case No. 2018-CH-07161, pending in the Circuit Court of Cook County, Illinois, Chancery Division (the “Mazya Action”). The Court
  (was, 2022-08-09, similarity 0.8905):
[0000926326-22-000027:note_history:4]
A class action lawsuit was filed against the Company, on June 5, 2019, in the Circuit Court of Cook County, Illinois, Chancery Division, captioned Corey Heard, individually and on behalf of all others similarly situated v. Omnicell, Inc., Case No. 2019-CH-06817 (the “Heard Action”). The complaint seeks class certification, monetary damages in the form of statutory damages for willful and/or reckless or, in the alternative, negligent violation of the Illinois Biometric Information Privacy Act (“BIPA”), and certain declaratory, injunctive, and other relief based on causes of action directed to allegations of violation of BIPA by the Company. The complaint was served on the Company on June 13, 2019. On July 31, 2019, the Company filed a motion to stay or consolidate the case with the action Yana Mazya, et al. v. Northwestern Lake Forest Hospital, et al., Case No. 2018-CH-07161, pending in the Circuit Court of Cook County, Illinois, Chancery Division (the “Mazya Action”). The Court subsequently, on October 10, 2019, denied the motion, without prejudice, as being moot in view of the dismissal of the claims against the Company in the Mazya Action. The Company filed a motion to dismiss the complaint in the Heard Action on

- added (2022-11-04):
[0000926326-22-000033:note_history:5]
subsequently, on October 10, 2019, denied the motion, without prejudice, as being moot in view of the dismissal of the claims against the Company in the Mazya Action. The Company filed a motion to dismiss the complaint in the Heard Action on October 31, 2019. The hearing on the Company’s motion to dismiss was held on September 2, 2020. The Court ruled from the bench and dismissed the complaint without prejudice giving plaintiff leave to file an amended complaint by September 30, 2020. Plaintiff filed an amended complaint on September 30, 2020 and the Company subsequently filed a motion to dismiss the amended complaint on October 28, 2020, which was fully briefed, but the Court had not heard oral argument on the motion. The parties entered into a settlement agreement on January 25, 2022, (the “Settlement Agreement”). On February 1, 2022, the Court granted preliminary approval of the settlement. Following preliminary approval, plaintiff conducted discovery to identify class members and to determine the class size. Pursuant to the terms of the Settlement Agreement, and following class size discovery, the parties will participate in non-binding mediation, which is currently scheduled for November 21, 2022 to determine if the settlement will move forward. The Court has scheduled an interim status conference for November 30, 2022. Subject to final approval of the settlement, the Company intends to defend the lawsuit vigorously.

- changed (2022-11-04):
[0000926326-22-000033:note_history:6]
As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any material accrual for contingent liabilities associated with the legal proceeding described above based on its belief that any potential material loss, while reasonably possible, is not probable. Further, any possible range of loss in this matter cannot be reasonably estimated at this time or is not deemed material. The Company believes that it has valid defenses with respect to the legal proceeding pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of the legal proceeding or because of the diversion of management’s attention and the creation of significant expenses.
  (was, 2022-08-09, similarity 0.9436):
[0000926326-22-000027:note_history:6]
As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any material accrual for contingent liabilities associated with the legal proceedings described above based on its belief that any potential material loss, while reasonably possible, is not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time or is not deemed material. The Company believes that it has valid defenses with respect to these legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of any of these legal proceedings or because of the diversion of management’s attention and the creation of significant expenses.

- removed (2022-11-04):
[0000926326-22-000027:note_history:7]
October 31, 2019. The hearing on the Company’s motion to dismiss was held on September 2, 2020. The Court ruled from the bench and dismissed the complaint without prejudice giving plaintiff leave to file an amended complaint by September 30, 2020. Plaintiff filed an amended complaint on September 30, 2020 and the Company subsequently filed a motion to dismiss the amended complaint on October 28, 2020, which was fully briefed, but the Court had not heard oral argument on the motion. The parties entered into a settlement agreement on January 25, 2022. On February 1, 2022, the Court granted preliminary approval of the settlement. The Court has scheduled an interim status conference for September 2, 2022. Subject to final approval of the settlement, the Company intends to defend the lawsuit vigorously.

- removed (2022-11-04):
[0000926326-22-000027:note_history:8]
On December 21, 2020, Becton, Dickinson and Company (“BD”) filed a complaint against the Company in the United States District Court for the Middle District of North Carolina, asserting claims of misappropriation under the Defend Trade Secrets Act, misappropriation under the North Carolina Trade Secrets Protection Act, unfair competition, and unfair/deceptive trade practices in violation of North Carolina law (the “BD Complaint”). This action (the “BD Action”) was commenced in relation to another action brought by BD, in the same Court (the “Related Matter”) against a former BD employee who is also a former Company employee (the “Former Employee”) alleging that the Former Employee had violated the Former Employee’s legal obligations to BD regarding BD’s confidential and trade secret information when the Former Employee allegedly downloaded certain documents from BD’s information technology system following the end of the Former Employee’s employment with BD. In connection with the Related Matter, BD, the Former Employee, and the Company entered into a protocol with the purpose of facilitating the return to BD of any BD documents that may have been resident, as a result of the Former Employee’s actions, on any devices belonging to the Former Employee or the Company. The BD Complaint seeks injunctive relief and monetary damages in the form of compensatory, punitive, and exemplary damages, attorneys’ fees and costs, and pre-judgment and post-judgment interest. On March 8, 2022, the parties entered into a confidential settlement agreement. On May 23, 2022, the parties filed a stipulation to dismiss the case with prejudice. On May 24, 2022, the case was dismissed with prejudice.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-11-04):
[0000926326-22-000033:note_history:9]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of September 30, 2022 and December 31, 2021, the results of operations and comprehensive income for the three and nine months ended September 30, 2022 and 2021, and cash flows for the nine months ended September 30, 2022 and 2021. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s Annual Report on Form 10-K for the year ended December 31, 2021, filed with the SEC on February 25, 2022, except as discussed in the section entitled “Recently Adopted Authoritative Guidance” below. The Company’s results of operations and comprehensive income for the three and nine months ended September 30, 2022, and cash flows for the nine months ended September 30, 2022 are not necessarily indicative of results that may be expected for the year ending December 31, 2022, or for any future period.
  (was, 2022-08-09, similarity 0.8353):
[0000926326-22-000027:note_history:9]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of June 30, 2022 and December 31, 2021, the results of operations and comprehensive income for the three and six months ended June 30, 2022 and 2021, and cash flows for the six months ended June 30, 2022 and 2021. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s Annual Report on Form 10-K for the year ended December 31, 2021, filed with the SEC on February 25, 2022, except as discussed in the section entitled “Recently Adopted Authoritative Guidance” below. The Company’s results of operations and comprehensive income for the three and six months ended June 30, 2022, and cash flows for the six months ended June 30, 2022 are not necessarily indicative of results that may be expected for the year ending December 31, 2022, or for any future period.

- added (2022-11-04):
[0000926326-22-000033:note_history:10]
The Company’s critical accounting policies are those that affect its financial statements materially and involve difficult, subjective, or complex judgments by management. As of September 30, 2022, the Company is not aware of any events or circumstances that would require an update to its estimates, judgments, or revisions to the carrying value of its assets or liabilities.

- changed (2022-11-04):
[0000926326-22-000033:note_history:11]
In August 2020, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2020-06, Debt-Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging-Contracts in Entity’s Own Equity (Subtopic 815-40). The update simplifies the accounting for convertible debt instruments by reducing the number of accounting models and the number of embedded conversion features that could be recognized separately from the primary contract. ASU 2020-06 also enhances transparency and improves disclosures for convertible instruments and earnings per share guidance. ASU 2020-06 also requires the application of the if-converted method for calculating diluted earnings per share and the treasury stock method is no longer permitted for convertible instruments. This update permits the use of either the modified retrospective or fully retrospective method of transition. The Company adopted ASU 2020-06 on January 1, 2022, using the modified retrospective method of transition. Upon adoption of ASU 2020-06, the previously separated equity component and associated debt issuance costs for the Company’s outstanding convertible senior notes were reclassified to the liability component, thereby eliminating the subsequent amortization of the debt discount as interest expense. In addition, the Company derecognized the deferred tax liability related to the equity component.
  (was, 2022-08-09, similarity 0.9985):
[0000926326-22-000027:note_history:11]
In August 2020, the Financial Accounting Standards Board (“FASB“) issued Accounting Standards Update (“ASU“) 2020-06, Debt-Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging-Contracts in Entity’s Own Equity (Subtopic 815-40). The update simplifies the accounting for convertible debt instruments by reducing the number of accounting models and the number of embedded conversion features that could be recognized separately from the primary contract. ASU 2020-06 also enhances transparency and improves disclosures for convertible instruments and earnings per share guidance. ASU 2020-06 also requires the application of the if-converted method for calculating diluted earnings per share and the treasury stock method is no longer permitted for convertible instruments. This update permits the use of either the modified retrospective or fully retrospective method of transition. The Company adopted ASU 2020-06 on January 1, 2022, using the modified retrospective method of transition. Upon adoption of ASU 2020-06, the previously separated equity component and associated debt issuance costs for the Company’s outstanding convertible senior notes were reclassified to the liability component, thereby eliminating the subsequent amortization of the debt discount as interest expense. In addition, the Company derecognized the deferred tax liability related to the equity component.

- removed (2022-11-04):
[0000926326-22-000027:note_history:12]
The Company’s critical accounting policies are those that affect its financial statements materially and involve difficult, subjective, or complex judgments by management. As of June 30, 2022, the Company is not aware of any events or circumstances that would require an update to its estimates, judgments, or revisions to the carrying value of its assets or liabilities.


## omcl:ScheduleOfInterestExpenseDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-11-04):
[0000926326-22-000033:note_history:13]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three and nine months ended September 30, 2022 and 2021:
  (was, 2022-08-09, similarity 0.9055):
[0000926326-22-000027:note_history:13]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three and six months ended June 30, 2022 and 2021:

- added (2022-11-04):
[0000926326-22-000033:note_history:14]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2022 (1) |  | 2021 |  | 2022 (1) |  | 2021 |
|  | (In thousands) |
| Contractual coupon interest | $ | 359 |  |  | $ | 359 |  |  | $ | 1,078 |  |  | $ | 1,078 |  |
| Amortization of discount | $ | — |  |  | $ | 4,679 |  |  | $ | — |  |  | $ | 13,874 |  |
| Amortization of debt issuance costs | $ | 768 |  |  | $ | 589 |  |  | $ | 2,298 |  |  | $ | 1,747 |  |

- removed (2022-11-04):
[0000926326-22-000027:note_history:15]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2022 (1) |  | 2021 |  | 2022 (1) |  | 2021 |
|  | (In thousands) |
| Contractual coupon interest | $ | 359 |  |  | $ | 359 |  |  | $ | 719 |  |  | $ | 719 |  |
| Amortization of discount | $ | — |  |  | $ | 4,624 |  |  | $ | — |  |  | $ | 9,195 |  |
| Amortization of debt issuance costs | $ | 766 |  |  | $ | 583 |  |  | $ | 1,530 |  |  | $ | 1,158 |  |


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-11-04):
[0000926326-22-000033:note_history:16]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of September 30, 2022 and December 31, 2021:
  (was, 2022-08-09, similarity 0.9591):
[0000926326-22-000027:note_history:16]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of June 30, 2022 and December 31, 2021:

- changed (2022-11-04):
[0000926326-22-000033:note_history:17]
|  | September 30,2022 (2) |  | December 31,2021 |
|  | (In thousands) |
| Liability: |  |  |  |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized discount | — |  |  | (77,136) |  |
| Unamortized debt issuance costs | (9,197) |  |  | (9,712) |  |
| Convertible senior notes, liability component (1) | $ | 565,803 |  |  | $ | 488,152 |  |
| Convertible senior notes, equity component | $ | — |  |  | $ | 72,732 |  |
  (was, 2022-08-09, similarity 0.9819):
[0000926326-22-000027:note_history:17]
|  | June 30,2022 (2) |  | December 31,2021 |
|  | (In thousands) |
| Liability: |  |  |  |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized discount | — |  |  | (77,136) |  |
| Unamortized debt issuance costs | (9,965) |  |  | (9,712) |  |
| Convertible senior notes, liability component (1) | $ | 565,035 |  |  | $ | 488,152 |  |
| Convertible senior notes, equity component | $ | — |  |  | $ | 72,732 |  |

- changed (2022-11-04):
[0000926326-22-000033:note_history:18]
(1)    Classified as a long-term liability as of September 30, 2022, and a current liability as of December 31, 2021, in the Condensed Consolidated Balance Sheets.
  (was, 2022-08-09, similarity 0.9622):
[0000926326-22-000027:note_history:18]
(1)    Classified as a long-term liability as of June 30, 2022, and a current liability as of December 31, 2021, in the Condensed Consolidated Balance Sheets.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-11-04):
[0000926326-22-000033:note_history:19]
The A&R Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends, and other distributions. The A&R Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum total secured net leverage ratio (as described above) and maintain a minimum interest coverage ratio. In addition, the A&R Credit Agreement contains certain customary events of default including, but not limited to, failure to pay interest, principal, and fees, or other amounts when due, material misrepresentations or misstatements in any representation or warranty, covenant defaults, certain cross defaults to other material indebtedness, certain judgment defaults, and events of bankruptcy. The Company’s obligations under the A&R Credit Agreement and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and such subsidiary guarantors’ assets. In connection with entering into the A&R Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a reaffirmation agreement, which amends certain terms of the existing collateral agreement and reaffirms their obligations under the existing guaranty agreement. The Company was in compliance with all covenants as of September 30, 2022.
  (was, 2022-08-09, similarity 0.9963):
[0000926326-22-000027:note_history:19]
The A&R Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends, and other distributions. The A&R Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum total secured net leverage ratio (as described above) and maintain a minimum interest coverage ratio. In addition, the A&R Credit Agreement contains certain customary events of default including, but not limited to, failure to pay interest, principal, and fees, or other amounts when due, material misrepresentations or misstatements in any representation or warranty, covenant defaults, certain cross defaults to other material indebtedness, certain judgment defaults, and events of bankruptcy. The Company’s obligations under the A&R Credit Agreement and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and such subsidiary guarantors’ assets. In connection with entering into the A&R Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a reaffirmation agreement, which amends certain terms of the existing collateral agreement and reaffirms their obligations under the existing guaranty agreement. The Company was in compliance with all covenants as of June 30, 2022.

- changed (2022-11-04):
[0000926326-22-000033:note_history:20]
As of each of September 30, 2022 and December 31, 2021, there was no outstanding balance for the Revolving Credit Facility.
Convertible Senior Notes
0.25% Convertible Senior Notes due 2025
  (was, 2022-08-09, similarity 0.9674):
[0000926326-22-000027:note_history:20]
As of each of June 30, 2022 and December 31, 2021, there was no outstanding balance for the Revolving Credit Facility.
Convertible Senior Notes
0.25% Convertible Senior Notes due 2025

- changed (2022-11-04):
[0000926326-22-000033:note_history:21]
During the three months ended December 31, 2021, the conditional conversion feature of the Notes was triggered, based on the price of the Company’s common stock, as the last reported sale price of the Company’s common stock was greater than or equal to 130% of the then applicable conversion price for the Notes for at least 20 trading days during the period of 30 consecutive trading days ending on December 31, 2021, the last trading day of the respective fiscal quarter. Accordingly, the Notes were convertible during the first quarter of 2022 and were classified as a current liability in the Consolidated Financial Statements as of December 31, 2021. During the three months ended September 30, 2022, none of the conditional conversion features of the Notes were triggered, and therefore, the Notes are not convertible during the fourth quarter of 2022, commencing on October 1, 2022. Accordingly, the Company classified the Notes as a long-term liability in its Condensed Consolidated Financial Statements as of September 30, 2022. Whether the Notes will be convertible following the fourth fiscal quarter of 2022 will depend on the satisfaction of the conversion conditions in the future.
  (was, 2022-08-09, similarity 0.7166):
[0000926326-22-000027:note_history:21]
During the three months ended December 31, 2021 and March 31, 2022, the conditional conversion feature of the Notes was triggered, based on the price of the Company’s common stock, as the last reported sale price of the Company’s common stock was greater than or equal to 130% of the then applicable conversion price for the Notes for at least 20 trading days during the period of 30 consecutive trading days ending on December 31, 2021 and March 31, 2022, the last trading day of the respective fiscal quarters. Accordingly, the Notes were convertible during the first two quarters of 2022 and were classified as a current liability in the Consolidated Financial Statements as of December 31, 2021 and March 31, 2022. During the three months ended June 30, 2022, none of the conditional conversion features of the Notes were triggered, and therefore, the Notes are not convertible during the third quarter of 2022, commencing on July 1, 2022. Accordingly, the Company classified the Notes as a long-term liability in its Condensed Consolidated Financial Statements as of June 30, 2022. Whether the Notes will be convertible following the third fiscal quarter of 2022 will depend on the satisfaction of the conversion conditions in the future.

- changed (2022-11-04):
[0000926326-22-000033:note_history:22]
Under the original terms of the Indenture, upon conversion, the Company could satisfy its conversion obligation by paying or delivering cash, shares of its common stock, or a combination thereof, at the Company’s election, in the manner and subject to the terms and conditions provided in the Indenture. On December 13, 2021, the Company irrevocably elected to fix its settlement method to a combination of cash and shares of the Company’s common stock with the specified cash amount per $1,000 principal amount of Notes of at least $1,000. As a result, for Notes converted on or after December 13, 2021, a converting noteholder will receive (i) up to $1,000 in cash per $1,000 principal amount of Notes and (ii) cash and/or shares of the Company’s common stock, at the Company’s option for any conversion consideration in excess of $1,000. In addition, the Company continues to have the ability to set the specified cash amount per $1,000 principal amount of Notes above $1,000. The initial conversion rate for the Notes is 10.2751 shares of the Company’s common stock per $1,000 principal amount of Notes, which is equivalent to an initial conversion price of approximately $97.32 per share of the Company’s common stock, subject to adjustment under certain circumstances in accordance with the terms of the Indenture. In addition, following certain corporate events that could occur prior to the maturity date of the Notes or if the Company delivers a notice of redemption in respect of the Notes, the Company will, under certain circumstances, increase the conversion rate of the Notes for a holder who elects to convert its Notes (or any portion thereof) in connection with such a corporate event or convert its Notes called (or deemed called) for redemption during the related redemption period (as defined in the Indenture), as the case may be.
  (was, 2022-08-09, similarity 0.9983):
[0000926326-22-000027:note_history:22]
Under the original terms of the Indenture, upon conversion, the Company could satisfy its conversion obligation by paying or delivering cash, shares of its common stock, or a combination thereof, at the Company’s election, in the manner and subject to the terms and conditions provided in the Indenture. On December 13, 2021, the Company irrevocably elected to fix its settlement method to a combination of cash and shares of the Company’s common stock with the specified cash amount per $1,000 principal amount of Notes of at least $1,000. As a result, for Notes converted on or after December 13, 2021, a converting noteholder will receive (i) up to $1,000 in cash per $1,000 principal amount of Notes and (ii) cash and/or shares of the Company’s common stock, at the Company’s option for any conversion consideration in excess of $1,000. In addition, the Company continues to have the ability to set the specified cash amount per $1,000 principal amount of Notes above $1,000. The initial conversion rate for the Notes is 10.2751 shares of the Company’s common stock per $1,000 principal amount of Notes, which is equivalent to an initial conversion price of approximately $97.32 per share of the Company’s common stock, subject to adjustment under certain circumstances in accordance with the terms of the Indenture. In addition, following certain corporate events that occur prior to the maturity date of the Notes or if the Company delivers a notice of redemption in respect of the Notes, the Company will, under certain circumstances, increase the conversion rate of the Notes for a holder who elects to convert its Notes (or any portion thereof) in connection with such a corporate event or convert its Notes called (or deemed called) for redemption during the related redemption period (as defined in the Indenture), as the case may be.

- changed (2022-11-04):
[0000926326-22-000033:note_history:23]
If the Company undergoes a fundamental change, holders may require, subject to certain exceptions, the Company to repurchase for cash all or any portion of their Notes at a fundamental change repurchase price equal to 100% of the principal amount of the Notes to be repurchased, plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date. As of September 30, 2022, none of the criteria for a fundamental change or a conversion rate adjustment had been met.
  (was, 2022-08-09, similarity 0.8042):
[0000926326-22-000027:note_history:23]
If the Company undergoes a fundamental change, holders may require, subject to certain exceptions, the Company to repurchase for cash all or any portion of their Notes at a fundamental change repurchase price equal to 100% of the principal amount of the Notes to be repurchased, plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date. As of June 30, 2022, none of the criteria for a fundamental change or a conversion rate adjustment had been met.

- changed (2022-11-04):
[0000926326-22-000033:note_history:24]
As of September 30, 2022, the remaining life of the Notes and the related issuance cost accretion is approximately 3.0 years.
  (was, 2022-08-09, similarity 0.952):
[0000926326-22-000027:note_history:24]
As of June 30, 2022, the remaining life of the Notes and the related issuance cost accretion is approximately 3.2 years.

- changed (2022-11-04):
[0000926326-22-000033:note_history:25]
The maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to other conversion rate adjustments, would be 5.9 million shares. As of September 30, 2022, the if-converted value of the Notes did not exceed the principal amount.
  (was, 2022-08-09, similarity 0.6876):
[0000926326-22-000027:note_history:25]
The maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to other conversion rate adjustments, would be 5.9 million shares. As of June 30, 2022, the if-converted value of the Notes exceeded the principal amount by $97.1 million.

- changed (2022-11-04):
[0000926326-22-000033:note_history:26]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of September 30, 2022 and December 31, 2021:
  (was, 2022-08-09, similarity 0.9591):
[0000926326-22-000027:note_history:26]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of June 30, 2022 and December 31, 2021:

- changed (2022-11-04):
[0000926326-22-000033:note_history:27]
|  | September 30,2022 (2) |  | December 31,2021 |
|  | (In thousands) |
| Liability: |  |  |  |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized discount | — |  |  | (77,136) |  |
| Unamortized debt issuance costs | (9,197) |  |  | (9,712) |  |
| Convertible senior notes, liability component (1) | $ | 565,803 |  |  | $ | 488,152 |  |
| Convertible senior notes, equity component | $ | — |  |  | $ | 72,732 |  |
  (was, 2022-08-09, similarity 0.9819):
[0000926326-22-000027:note_history:27]
|  | June 30,2022 (2) |  | December 31,2021 |
|  | (In thousands) |
| Liability: |  |  |  |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized discount | — |  |  | (77,136) |  |
| Unamortized debt issuance costs | (9,965) |  |  | (9,712) |  |
| Convertible senior notes, liability component (1) | $ | 565,035 |  |  | $ | 488,152 |  |
| Convertible senior notes, equity component | $ | — |  |  | $ | 72,732 |  |

- changed (2022-11-04):
[0000926326-22-000033:note_history:28]
(1)    Classified as a long-term liability as of September 30, 2022, and a current liability as of December 31, 2021, in the Condensed Consolidated Balance Sheets.
  (was, 2022-08-09, similarity 0.9622):
[0000926326-22-000027:note_history:28]
(1)    Classified as a long-term liability as of June 30, 2022, and a current liability as of December 31, 2021, in the Condensed Consolidated Balance Sheets.

- changed (2022-11-04):
[0000926326-22-000033:note_history:29]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three and nine months ended September 30, 2022 and 2021:
  (was, 2022-08-09, similarity 0.9055):
[0000926326-22-000027:note_history:29]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three and six months ended June 30, 2022 and 2021:

- added (2022-11-04):
[0000926326-22-000033:note_history:30]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2022 (1) |  | 2021 |  | 2022 (1) |  | 2021 |
|  | (In thousands) |
| Contractual coupon interest | $ | 359 |  |  | $ | 359 |  |  | $ | 1,078 |  |  | $ | 1,078 |  |
| Amortization of discount | $ | — |  |  | $ | 4,679 |  |  | $ | — |  |  | $ | 13,874 |  |
| Amortization of debt issuance costs | $ | 768 |  |  | $ | 589 |  |  | $ | 2,298 |  |  | $ | 1,747 |  |

- removed (2022-11-04):
[0000926326-22-000027:note_history:31]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2022 (1) |  | 2021 |  | 2022 (1) |  | 2021 |
|  | (In thousands) |
| Contractual coupon interest | $ | 359 |  |  | $ | 359 |  |  | $ | 719 |  |  | $ | 719 |  |
| Amortization of discount | $ | — |  |  | $ | 4,624 |  |  | $ | — |  |  | $ | 9,195 |  |
| Amortization of debt issuance costs | $ | 766 |  |  | $ | 583 |  |  | $ | 1,530 |  |  | $ | 1,158 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-11-04):
[0000926326-22-000033:note_history:32]
SaaS, subscription software, and technology-enabled services. Emerging software and service solutions which are offered on a subscription basis with fees typically based either on transaction volume or a fee over a specified period of time. Solutions in this category include, but are not limited to, EnlivenHealth inclusive of FDS Amplicare and MarkeTouch Media, 340B solutions, Specialty Pharmacy Services, and services associated with Omnicell One™, Central Pharmacy Dispensing Services, including the XR2 Automated Central Pharmacy System, and Central Pharmacy Compounding Services, including IVX Station and IV compounding automation solutions.
  (was, 2022-08-09, similarity 0.9729):
[0000926326-22-000027:note_history:32]
SaaS, subscription software, and technology-enabled services. Emerging software and service solutions which are offered on a subscription basis with fees typically based either on transaction volume or a fee over a specified period of time. Solutions in this category include, but are not limited to, EnlivenHealth inclusive of FDS Amplicare and MarkeTouch Media, 340B solutions, ReCept management services, and services associated with Omnicell One™, Central Pharmacy Dispensing Services, including the XR2 Automated Central Pharmacy System, and Central Pharmacy Compounding Services, including IVX Station and IV compounding automation solutions.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-11-04):
[0000926326-22-000033:note_history:33]
SaaS, subscription software, and technology-enabled services. Emerging software and service solutions which are offered on a subscription basis with fees typically based either on transaction volume or a fee over a specified period of time. Solutions in this category include, but are not limited to, EnlivenHealth inclusive of FDS Amplicare and MarkeTouch Media, 340B solutions, Specialty Pharmacy Services, and services associated with Omnicell One™, Central Pharmacy Dispensing Services, including the XR2 Automated Central Pharmacy System, and Central Pharmacy Compounding Services, including IVX Station and IV compounding automation solutions.
  (was, 2022-08-09, similarity 0.9729):
[0000926326-22-000027:note_history:33]
SaaS, subscription software, and technology-enabled services. Emerging software and service solutions which are offered on a subscription basis with fees typically based either on transaction volume or a fee over a specified period of time. Solutions in this category include, but are not limited to, EnlivenHealth inclusive of FDS Amplicare and MarkeTouch Media, 340B solutions, ReCept management services, and services associated with Omnicell One™, Central Pharmacy Dispensing Services, including the XR2 Automated Central Pharmacy System, and Central Pharmacy Compounding Services, including IVX Station and IV compounding automation solutions.

- changed (2022-11-04):
[0000926326-22-000033:note_history:34]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”) and Federal agencies that purchase under a Federal Supply Schedule Contract with the Department of Veterans Affairs (the “GSA Contract”). GPOs are often fully or partially owned by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company also pays the Industrial Funding Fee (“IFF”) to the Department of Veterans Affairs under the GSA Contract. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs and the IFF were $4.8 million and $4.4 million for the three months ended September 30, 2022 and 2021, respectively, and $13.3 million and $12.0 million for the nine months ended September 30, 2022 and 2021, respectively.
  (was, 2022-08-09, similarity 0.9623):
[0000926326-22-000027:note_history:34]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”) and Federal agencies that purchase under a Federal Supply Schedule Contract with the Department of Veterans Affairs (the “GSA Contract”). GPOs are often fully or partially owned by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company also pays the Industrial Funding Fee (“IFF”) to the Department of Veterans Affairs under the GSA Contract. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs and the IFF were $4.0 million and $4.2 million for the three months ended June 30, 2022 and 2021, respectively, and $8.5 million and $7.6 million for the six months ended June 30, 2022 and 2021, respectively.

- changed (2022-11-04):
[0000926326-22-000033:note_history:35]
The following table summarizes the Company’s revenues disaggregated by revenue type for the three and nine months ended September 30, 2022 and 2021:
  (was, 2022-08-09, similarity 0.9416):
[0000926326-22-000027:note_history:35]
The following table summarizes the Company’s revenues disaggregated by revenue type for the three and six months ended June 30, 2022 and 2021:

- changed (2022-11-04):
[0000926326-22-000033:note_history:36]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
|  | (In thousands) |
| Connected devices, software licenses, and other | $ | 226,415 |  |  | $ | 195,820 |  |  | $ | 650,125 |  |  | $ | 534,582 |  |
| Technical services | 53,914 |  |  | 53,529 |  |  | 156,386 |  |  | 156,321 |  |
| Consumables | 20,150 |  |  | 18,150 |  |  | 56,121 |  |  | 54,424 |  |
| SaaS, subscription software, and technology-enabled services | 47,580 |  |  | 28,903 |  |  | 135,641 |  |  | 75,657 |  |
| Total revenues | $ | 348,059 |  |  | $ | 296,402 |  |  | $ | 998,273 |  |  | $ | 820,984 |  |
  (was, 2022-08-09, similarity 0.9221):
[0000926326-22-000027:note_history:36]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
|  | (In thousands) |
| Connected devices, software licenses, and other | $ | 215,632 |  |  | $ | 179,044 |  |  | $ | 423,710 |  |  | $ | 338,762 |  |
| Technical services | 53,303 |  |  | 51,932 |  |  | 102,472 |  |  | 102,792 |  |
| Consumables | 18,174 |  |  | 17,867 |  |  | 35,971 |  |  | 36,274 |  |
| SaaS, subscription software, and technology-enabled services | 44,277 |  |  | 23,896 |  |  | 88,061 |  |  | 46,754 |  |
| Total revenues | $ | 331,386 |  |  | $ | 272,739 |  |  | $ | 650,214 |  |  | $ | 524,582 |  |

- changed (2022-11-04):
[0000926326-22-000033:note_history:37]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location, for the three and nine months ended September 30, 2022 and 2021:
  (was, 2022-08-09, similarity 0.9581):
[0000926326-22-000027:note_history:37]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location, for the three and six months ended June 30, 2022 and 2021:

- changed (2022-11-04):
[0000926326-22-000033:note_history:38]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
|  | (In thousands) |
| United States | $ | 315,755 |  |  | $ | 271,276 |  |  | $ | 898,269 |  |  | $ | 738,411 |  |
| Rest of world (1) | 32,304 |  |  | 25,126 |  |  | 100,004 |  |  | 82,573 |  |
| Total revenues | $ | 348,059 |  |  | $ | 296,402 |  |  | $ | 998,273 |  |  | $ | 820,984 |  |
  (was, 2022-08-09, similarity 0.8752):
[0000926326-22-000027:note_history:38]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
|  | (In thousands) |
| United States | $ | 294,937 |  |  | $ | 242,859 |  |  | $ | 582,514 |  |  | $ | 467,135 |  |
| Rest of world (1) | 36,449 |  |  | 29,880 |  |  | 67,700 |  |  | 57,447 |  |
| Total revenues | $ | 331,386 |  |  | $ | 272,739 |  |  | $ | 650,214 |  |  | $ | 524,582 |  |

- changed (2022-11-04):
[0000926326-22-000033:note_history:39]
|  | September 30,2022 |  | December 31,2021 |
|  | (In thousands) |
| Short-term unbilled receivables, net (1) | $ | 28,354 |  |  | $ | 17,208 |  |
| Long-term unbilled receivables, net (2) | 13,815 |  |  | 18,084 |  |
| Total contract assets | $ | 42,169 |  |  | $ | 35,292 |  |
| Short-term deferred revenues, net | $ | 113,925 |  |  | $ | 112,196 |  |
| Long-term deferred revenues | 34,519 |  |  | 20,194 |  |
| Total contract liabilities | $ | 148,444 |  |  | $ | 132,390 |  |
  (was, 2022-08-09, similarity 0.983):
[0000926326-22-000027:note_history:39]
|  | June 30,2022 |  | December 31,2021 |
|  | (In thousands) |
| Short-term unbilled receivables, net (1) | $ | 19,567 |  |  | $ | 17,208 |  |
| Long-term unbilled receivables, net (2) | 16,185 |  |  | 18,084 |  |
| Total contract assets | $ | 35,752 |  |  | $ | 35,292 |  |
| Short-term deferred revenues, net | $ | 108,579 |  |  | $ | 112,196 |  |
| Long-term deferred revenues | 24,187 |  |  | 20,194 |  |
| Total contract liabilities | $ | 132,766 |  |  | $ | 132,390 |  |

- changed (2022-11-04):
[0000926326-22-000033:note_history:40]
Short-term deferred revenues of $113.9 million and $112.2 million include deferred revenues from product sales and service contracts, net of deferred cost of sales of $12.5 million and $22.4 million, as of September 30, 2022 and December 31, 2021, respectively. The short-term deferred revenues from product sales relate to delivered and invoiced products, pending installation and acceptance, expected to occur within the next twelve months. During the three and nine months ended September 30, 2022, the Company recognized revenues of $15.2 million and $104.2 million, respectively, that were included in the corresponding gross short-term deferred revenues balance of $134.6 million as of December 31, 2021.
  (was, 2022-08-09, similarity 0.9535):
[0000926326-22-000027:note_history:40]
Short-term deferred revenues of $108.6 million and $112.2 million include deferred revenues from product sales and service contracts, net of deferred cost of sales of $13.6 million and $22.4 million, as of June 30, 2022 and December 31, 2021, respectively. The short-term deferred revenues from product sales relate to delivered and invoiced products, pending installation and acceptance, expected to occur within the next twelve months. During the three and six months ended June 30, 2022, the Company recognized revenues of $22.4 million and $89.0 million, respectively, that were included in the corresponding gross short-term deferred revenues balance of $134.6 million as of December 31, 2021.

- added (2022-11-04):
[0000926326-22-000033:note_history:41]
Long-term deferred revenues include deferred revenues from product and service contracts of $34.5 million and $20.2 million as of September 30, 2022 and December 31, 2021, respectively. Remaining performance obligations are primarily recognized ratably over the remaining term of the contract, generally not more than ten years.

- changed (2022-11-04):
[0000926326-22-000033:note_history:42]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three and nine months ended September 30, 2022 and 2021. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable balance as of September 30, 2022 and December 31, 2021.
  (was, 2022-08-09, similarity 0.8526):
[0000926326-22-000027:note_history:42]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three and six months ended June 30, 2022 and 2021. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable balance as of June 30, 2022 and December 31, 2021.

- removed (2022-11-04):
[0000926326-22-000027:note_history:43]
Long-term deferred revenues include deferred revenues from product and service contracts of $24.2 million and $20.2 million as of June 30, 2022 and December 31, 2021, respectively. Remaining performance obligations are primarily recognized ratably over the remaining term of the contract, generally not more than ten years.
