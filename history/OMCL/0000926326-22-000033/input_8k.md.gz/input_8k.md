# OMCL 8-K — 0000926326-22-000031 filed 2022-11-02

## item codes, every 8-K on or before 2022-11-04

- 2022-11-02 0000926326-22-000031 — 2.02, 9.01
- 2022-10-21 0000926326-22-000029 — 5.03, 9.01
- 2022-09-20 0001104659-22-101566 — 7.01, 9.01
- 2022-09-20 0001104659-22-101360 — 7.01, 9.01
- 2022-08-04 0000926326-22-000025 — 2.02, 8.01, 9.01
- 2022-05-31 0000926326-22-000020 — 5.02, 5.07, 9.01
- 2022-05-24 0000926326-22-000016 — 5.02
- 2022-05-09 0000926326-22-000012 — 8.01
- 2022-04-28 0000926326-22-000009 — 2.02, 9.01
- 2022-03-01 0001104659-22-028681 — 5.02, 8.01, 9.01
- 2022-02-14 0000926326-22-000004 — 2.02, 9.01
- 2022-01-04 0000926326-22-000002 — 7.01, 9.01
- 2021-12-29 0001104659-21-154294 — 7.01, 9.01
- 2021-12-13 0000926326-21-000039 — 8.01
- 2021-12-02 0000926326-21-000037 — 7.01, 9.01
- 2021-11-02 0000926326-21-000031 — 2.02, 9.01
- 2021-09-09 0000926326-21-000028 — 7.01, 9.01
- 2021-07-29 0000926326-21-000024 — 2.02, 9.01
- 2021-07-26 0000926326-21-000022 — 7.01, 9.01
- 2021-07-12 0000926326-21-000019 — 5.02, 9.01
- 2021-05-28 0000926326-21-000015 — 5.07
- 2021-04-29 0000926326-21-000011 — 2.02, 9.01
- 2021-02-01 0000926326-21-000004 — 2.02, 9.01
- 2021-01-26 0000926326-21-000002 — 5.02
- 2021-01-13 0001104659-21-003672 — 2.02, 7.01, 9.01
- 2020-10-27 0000926326-20-000032 — 2.02, 9.01
- 2020-10-01 0000926326-20-000029 — 7.01, 9.01
- 2020-09-25 0001104659-20-108924 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2020-09-22 0001104659-20-107176 — 1.01, 8.01, 9.01
- 2020-08-12 0000926326-20-000027 — 2.03
- 2020-08-12 0000926326-20-000025 — 1.01, 5.03, 7.01, 9.01
- 2020-07-28 0000926326-20-000021 — 2.02, 9.01
- 2020-05-27 0000926326-20-000017 — 5.07
- 2020-05-07 0000926326-20-000012 — 2.02, 9.01
- 2020-02-18 0000926326-20-000007 — 5.02, 9.01
- 2020-02-13 0000926326-20-000005 — 8.01
- 2020-02-06 0000926326-20-000003 — 2.02, 9.01
- 2019-12-06 0001104659-19-070339 — 8.01
- 2019-11-18 0000926326-19-000035 — 1.01, 2.03, 9.01
- 2019-10-24 0000926326-19-000028 — 2.02, 9.01
- 2019-07-25 0000926326-19-000021 — 2.02, 9.01
- 2019-05-15 0000926326-19-000015 — 5.07
- 2019-04-25 0000926326-19-000011 — 2.02, 9.01
- 2019-03-08 0000926326-19-000009 — 5.02, 9.01
- 2019-02-19 0000926326-19-000005 — 5.02, 9.01
- 2019-02-07 0000926326-19-000003 — 2.02, 9.01
- 2018-10-25 0000926326-18-000028 — 2.02, 9.01
- 2018-09-14 0001104659-18-056929 — 5.02, 9.01
- 2018-07-26 0000926326-18-000022 — 2.02, 9.01
- 2018-06-06 0000926326-18-000019 — 5.02, 9.01
- 2018-05-16 0001104659-18-033801 — 5.07
- 2018-04-26 0000926326-18-000013 — 2.02, 9.01
- 2018-03-02 0001104659-18-014497 — 5.02
- 2018-02-08 0000926326-18-000007 — 5.02
- 2018-02-02 0000926326-18-000005 — 5.02
- 2018-02-01 0000926326-18-000003 — 2.02, 9.01
- 2017-12-26 0000926326-17-000041 — 1.01, 2.03, 9.01
- 2017-11-03 0001104659-17-066102 — 1.01, 8.01, 9.01
- 2017-10-26 0000926326-17-000035 — 2.02, 9.01
- 2017-08-03 0000926326-17-000028 — 5.07 — amendment, the index does not say of what
- 2017-07-27 0000926326-17-000026 — 2.02, 9.01
- 2017-07-25 0000926326-17-000023 — 5.02, 9.01
- 2017-05-24 0000926326-17-000019 — 5.07
- 2017-05-04 0001628280-17-004851 — 2.02, 9.01
- 2017-02-15 0000926326-17-000010 — 2.05
- 2017-02-15 0000926326-17-000008 — 2.02, 9.01
- 2017-02-13 0000926326-17-000002 — 5.02
- 2016-12-08 0001104659-16-161330 — 2.01, 2.03, 9.01
- 2016-12-06 0001104659-16-160709 — 7.01
- 2016-11-29 0001104659-16-159456 — 1.01, 7.01, 9.01
- 2016-10-27 0000926326-16-000075 — 2.02, 9.01
- 2016-10-07 0000926326-16-000072 — 5.02, 8.01
- 2016-08-05 0000926326-16-000068 — 8.01
- 2016-07-28 0000926326-16-000066 — 2.02, 9.01
- 2016-06-13 0001104659-16-126854 — 5.02
- 2016-05-25 0000926326-16-000060 — 5.07
- 2016-04-28 0000926326-16-000054 — 2.02, 9.01
- 2016-03-21 0001104659-16-106649 — 8.01, 9.01
- 2016-03-17 0000926326-16-000051 — 7.01, 9.01
- 2016-03-17 0000926326-16-000049 — 9.01 — amendment of 0000926326-16-000051
- 2016-02-10 0001104659-16-095486 — 5.02, 9.01
- 2016-02-04 0000926326-16-000041 — 2.02, 9.01
- 2016-01-06 0001104659-16-088299 — 1.01, 2.01, 2.03, 9.01
- 2015-12-10 0000926326-15-000038 — 8.01, 9.01
- 2015-10-29 0001104659-15-074138 — 1.01, 9.01
- 2015-10-29 0000926326-15-000031 — 2.02, 9.01
- 2015-08-20 0001104659-15-061135 — 5.02, 9.01
- 2015-07-30 0000926326-15-000024 — 2.02, 9.01
- 2015-05-22 0001104659-15-040440 — 5.07
- 2015-05-01 0001104659-15-032846 — 5.02
- 2015-05-01 0001104659-15-032844 — 7.01
- 2015-04-30 0000926326-15-000015 — 9.01
- 2015-04-22 0001104659-15-029356 — 8.01, 9.01
- 2015-03-20 0001104659-15-021435 — 3.01
- 2015-03-18 0001104659-15-020699 — 7.01
- 2015-03-17 0001104659-15-020483 — 8.01, 9.01
- 2015-03-02 0001104659-15-015802 — 1.01, 9.01
- 2015-02-12 0001104659-15-009234 — 5.02, 9.01
- 2015-02-03 0000926326-15-000003 — 9.01
- 2015-01-15 0001104659-15-002635 — 5.02
- 2014-11-07 0001104659-14-078398 — 1.01, 8.01, 9.01
- 2014-10-30 0000926326-14-000037 — 2.02, 9.01
- 2014-08-25 0001104659-14-062772 — 8.01, 9.01
- 2014-07-31 0000926326-14-000032 — 2.02, 9.01
- 2014-05-21 0001104659-14-040744 — 5.07
- 2014-05-01 0000926326-14-000008 — 2.02, 9.01
- 2014-04-08 0001104659-14-026441 — 4.01, 9.01
- 2014-04-02 0001104659-14-025179 — 5.02
- 2014-02-07 0001104659-14-007552 — 5.02, 9.01
- 2014-02-04 0001104659-14-006352 — 2.02, 9.01
- 2013-12-09 0001104659-13-088980 — 1.01, 9.01
- 2013-12-02 0001104659-13-087877 — 5.02
- 2013-10-31 0001104659-13-079660 — 2.02, 9.01
- 2013-09-26 0001104659-13-072435 — 1.01, 2.03, 9.01
- 2013-08-01 0001104659-13-058959 — 2.02, 9.01
- 2013-05-23 0001104659-13-044317 — 5.07
- 2013-05-02 0001104659-13-036605 — 2.02, 9.01
- 2013-03-11 0001104659-13-019143 — 8.01
- 2013-02-07 0001104659-13-008477 — 5.02, 9.01
- 2013-01-31 0001104659-13-006446 — 2.02, 9.01
- 2012-11-02 0001104659-12-073697 — 5.02
- 2012-10-25 0001104659-12-071211 — 2.02, 9.01
- 2012-08-06 0001104659-12-054635 — 8.01
- 2012-08-03 0001104659-12-054214 — 2.01, 9.01 — amendment of 0001104659-12-038888
- 2012-08-01 0001104659-12-053005 — 2.02, 9.01
- 2012-06-12 0001104659-12-042936 — 8.01, 9.01
- 2012-05-23 0001104659-12-039459 — 5.07
- 2012-05-22 0001104659-12-038888 — 2.01, 9.01
- 2012-05-02 0001104659-12-032048 — 2.02, 9.01
- 2012-05-02 0001104659-12-032036 — 1.01, 9.01
- 2012-04-04 0001104659-12-023883 — 5.02, 8.01
- 2012-03-20 0001104659-12-019462 — 1.01, 9.01
- 2012-02-13 0001104659-12-009353 — 5.02, 9.01
- 2012-01-26 0001104659-12-004244 — 2.02, 9.01
- 2011-10-27 0001104659-11-058464 — 2.02, 9.01
- 2011-10-25 0001104659-11-057721 — 1.01
- 2011-07-28 0001104659-11-041505 — 2.02, 9.01
- 2011-05-27 0001104659-11-032006 — 5.07
- 2011-05-02 0001104659-11-024908 — 2.02, 9.01
- 2011-04-15 0001104659-11-020407 — 5.02, 9.01 — amendment of 0001104659-11-005638
- 2011-02-08 0001104659-11-005638 — 5.02, 9.01
- 2011-01-27 0001104659-11-003419 — 2.02, 9.01
- 2010-12-22 0001104659-10-064003 — 5.02, 5.07, 9.01
- 2010-10-27 0001104659-10-054036 — 2.02, 9.01
- 2010-10-05 0001104659-10-051173 — 8.01
- 2010-07-22 0001104659-10-039126 — 2.02, 9.01
- 2010-07-09 0001104659-10-037594 — 2.05
- 2010-05-28 0001104659-10-031607 — 5.07
- 2010-04-26 0001104659-10-021797 — 2.02, 9.01
- 2010-03-17 0001104659-10-014849 — 5.02, 9.01
- 2010-02-08 0001104659-10-005457 — 5.02, 9.01
- 2010-01-28 0001104659-10-003627 — 2.02, 9.01
- 2009-10-22 0001104659-09-059972 — 2.02, 9.01
- 2009-07-23 0001104659-09-044508 — 2.02, 9.01
- 2009-05-20 0001104659-09-033938 — 5.02, 9.01
- 2009-04-30 0001104659-09-027707 — 2.02, 9.01
- 2009-03-10 0001104659-09-016178 — 5.02, 9.01
- 2009-02-09 0001104659-09-007692 — 5.02, 9.01
- 2009-01-29 0001104659-09-005022 — 2.02, 2.05, 9.01
- 2009-01-21 0001104659-09-003180 — 2.02, 8.01, 9.01
- 2009-01-06 0001104659-09-000625 — 5.02
- 2008-10-23 0001104659-08-065475 — 2.02, 9.01
- 2008-07-21 0001104659-08-046690 — 2.02, 9.01
- 2008-05-16 0001104659-08-034035 — 8.01, 9.01
- 2008-04-28 0001104659-08-027379 — 7.01, 9.01
- 2008-04-21 0001104659-08-025616 — 2.02, 9.01
- 2008-03-12 0001104659-08-016939 — 7.01, 9.01
- 2008-02-26 0001104659-08-012840 — 7.01, 9.01
- 2008-02-12 0001104659-08-009382 — 5.02, 9.01
- 2008-01-31 0001104659-08-006199 — 2.02, 9.01
- 2007-12-05 0001104659-07-087191 — 1.01, 9.01
- 2007-10-18 0001104659-07-075654 — 2.02, 9.01
- 2007-07-27 0001104659-07-056886 — 5.03, 9.01
- 2007-07-19 0001104659-07-054924 — 2.02, 9.01
- 2007-05-23 0001104659-07-042287 — 8.01, 9.01
- 2007-05-07 0001104659-07-036172 — 1.01, 5.02, 9.01
- 2007-04-24 0001104659-07-030578 — 2.02, 9.01 — amendment, the index does not say of what
- 2007-04-24 0001104659-07-030547 — 2.02, 9.01
- 2007-04-10 0001104659-07-027465 — 5.02, 9.01
- 2007-03-23 0001104659-07-021969 — 2.02, 4.02, 9.01
- 2007-01-30 0001104659-07-005772 — 2.02, 9.01
- 2007-01-09 0001104659-07-001600 — 5.02, 9.01
- 2006-10-30 0001104659-06-069612 — 1.01
- 2006-10-19 0001104659-06-067549 — 2.02, 9.01
- 2006-07-20 0001104659-06-048020 — 2.02, 4.02, 9.01
- 2006-05-17 0001104659-06-035522 — 1.01, 9.01 — amendment of 0001104659-05-011155
- 2006-05-09 0001104659-06-032706 — 1.01, 9.01
- 2006-04-25 0001104659-06-027438 — 2.02, 9.01
- 2006-04-04 0001104659-06-022204 — 1.01, 9.01
- 2006-03-15 0001104659-06-016861 — 1.01, 9.01
- 2006-01-30 0001104659-06-004749 — 2.02, 9.01
- 2006-01-24 0001104659-06-003504 — 1.01, 5.02, 9.01
- 2005-12-13 0001104659-05-060532 — 1.01, 9.01
- 2005-11-10 0001104659-05-054663 — 2.02, 9.01
- 2005-07-21 0001104659-05-033464 — 2.02, 9.01
- 2005-06-22 0001104659-05-029255 — 1.01
- 2005-05-16 0001104659-05-023473 — 2.02, 9.01 — amendment of 0001104659-05-018173
- 2005-05-16 0001104659-05-023471 — 2.02, 9.01 — amendment of 0001104659-05-017382
- 2005-05-10 0001104659-05-022127 — 1.01
- 2005-04-26 0001104659-05-018173 — 2.02, 9.01
- 2005-04-21 0001104659-05-017382 — 2.02, 9.01
- 2005-04-06 0001104659-05-015401 — 5.02
- 2005-03-15 0001104659-05-011155 — 1.01, 9.01
- 2005-03-08 0001104659-05-009975 — 1.01, 9.01
- 2005-02-03 0001104659-05-003943 — 2.02, 9.01
- 2005-01-13 0001104659-05-001314 — 5.02, 9.01
- 2004-10-21 0001104659-04-031413 — 2.02, 9.01
- 2004-07-22 0001104659-04-020572 — 12, 7
- 2004-04-14 0001104659-04-010039 — 12, 7
- 2004-04-05 0001104659-04-009437 — 12, 7
- 2004-01-26 0001104659-04-001655 — 12, 7
- 2003-10-16 0001104659-03-022990 — 12, 7
- 2003-07-17 0001104659-03-015053 — 9
- 2003-04-18 0001104659-03-006823 — 7, 9
- 2003-02-14 0001104659-03-002607 — 5, 7

## late-filing notifications on or before 2022-11-04

- 2015-03-02 0000926326-15-000006 — NT 10-K, for the period ended 2014-12-31
- 2007-03-16 0001104659-07-020094 — NT 10-K, for the period ended 2006-12-31

## item 2.02 — earnings release, exhibit 99.1

[0000926326-22-000031:8k_2_02:1]
EX-99.1
2
exhibit991q3-22.htm
EX-99.1

[0000926326-22-000031:8k_2_02:2]
Document

[0000926326-22-000031:8k_2_02:3]
Exhibit 99.1

[0000926326-22-000031:8k_2_02:4]
| Contact: |  |  |
| Kathleen Nemeth |  | Omnicell, Inc. |
| Senior Vice President, Investor Relations |  | 2625 Augustine Drive, Suite 301 |
| 650-435-3318 |  | Santa Clara, CA 95054 |
| Kathleen.Nemeth@Omnicell.com |  |  |

[0000926326-22-000031:8k_2_02:5]
Omnicell Announces Financial Results for Third Quarter 2022

[0000926326-22-000031:8k_2_02:6]
GAAP and non-GAAP revenues of $348 million

[0000926326-22-000031:8k_2_02:7]
GAAP net income per diluted share of $0.37

[0000926326-22-000031:8k_2_02:8]
Non-GAAP net income per diluted share of $1.00

[0000926326-22-000031:8k_2_02:9]
SANTA CLARA, Calif. -- November 2, 2022 -- Omnicell, Inc. (NASDAQ:OMCL) (“Omnicell,” “we,” “our,” “us,” “management,” or the “Company”), a leading provider of medication management solutions and adherence tools for healthcare systems and pharmacies, today announced results for its third quarter ended September 30, 2022 and updated 2022 guidance.

[0000926326-22-000031:8k_2_02:10]
Randall Lipps, Chairman, President, Chief Executive Officer, and founder of Omnicell, said, “In the third quarter, we experienced headwinds in our point of care products, driven by health system capital budget freezes and delays and ongoing customer labor availability challenges. These factors weighed on our results and drove our updated outlook for the full year. We intend to take steps to adjust our cost structure that are designed to address these headwinds, while remaining focused on investing in our innovation roadmap, and we will continue to be nimble in navigating this dynamic macro-economic environment. We continue to advance our strategy to transform the pharmacy care delivery model and provide what we believe are mission critical medication management solutions to our customers. Importantly, we believe our shift to an “as a service model” is working as demand for our Advanced Services including our EnlivenHealth Retail SaaS solutions remains strong. In addition, we had a record number of Central Pharmacy Dispensing Systems installed during the third quarter. While we anticipate operating against a challenging backdrop near-term, we continue to be confident in our strategy and our ability to drive long-term sustainable value for all of our stakeholders.”

[0000926326-22-000031:8k_2_02:11]
GAAP Results

[0000926326-22-000031:8k_2_02:12]
Total GAAP revenues for the third quarter of 2022 were $348 million, up $52 million, or 17%, from the third quarter of 2021. The increase in GAAP revenues reflects continued strong demand for Omnicell’s mission critical medication management solutions, as well as the contribution of revenues from recent acquisitions.

[0000926326-22-000031:8k_2_02:13]
GAAP net income for the third quarter of 2022 was $17 million, or $0.37 per diluted share. This compares to GAAP net income of $29 million, or $0.61 per diluted share, for the third quarter of 2021.

[0000926326-22-000031:8k_2_02:14]
Non-GAAP Results

[0000926326-22-000031:8k_2_02:15]
Total non-GAAP revenues for the third quarter of 2022 were $348 million, up $52 million, or 17%, from the third quarter of 2021. The increase in non-GAAP revenues reflects strong demand for Omnicell’s mission critical medication management solutions, as well as the contribution of revenues from recent acquisitions.

[0000926326-22-000031:8k_2_02:16]
Non-GAAP net income for the third quarter of 2022 was $45 million, or $1.00 per diluted share. This compares to non-GAAP net income of $50 million, or $1.08 per diluted share, for the third quarter of 2021.

[0000926326-22-000031:8k_2_02:17]
Non-GAAP EBITDA for the third quarter of 2022 was $61 million. This compares to non-GAAP EBITDA of $66 million for the third quarter of 2021.

[0000926326-22-000031:8k_2_02:18]
Balance Sheet

[0000926326-22-000031:8k_2_02:19]
As of September 30, 2022, Omnicell’s balance sheet reflected cash and cash equivalents of $266 million, total debt (net of unamortized debt issuance costs) of $566 million, and total assets of $2.18 billion. Cash flows provided by operating activities

[0000926326-22-000031:8k_2_02:20]
in the third quarter of 2022 totaled $21 million. This compares to cash flows provided by operating activities totaling $43 million in the third quarter of 2021.

[0000926326-22-000031:8k_2_02:21]
As of September 30, 2022, the Company had $500 million of availability under its revolving credit facility.

[0000926326-22-000031:8k_2_02:22]
Business Highlights

[0000926326-22-000031:8k_2_02:23]
•Robust demand for Advanced Services during the third quarter

[0000926326-22-000031:8k_2_02:24]
•Added two new long-term sole source customers, bringing total number of long-term sole source customers to 152 of the top 300 U.S. Health Systems1

[0000926326-22-000031:8k_2_02:25]
•Illuminate attended by key customers, with launch of Specialty Pharmacy Services offering

[0000926326-22-000031:8k_2_02:26]
2022 Guidance

[0000926326-22-000031:8k_2_02:27]
For the full year 2022, the Company now expects product bookings to be between $950 million and $1.050 billion. The Company expects full year 2022 total GAAP and non-GAAP revenues to be between $1.284 billion and $1.294 billion. Omnicell now expects full year 2022 GAAP and non-GAAP product revenues to be between $889 million and $894 million, and full year 2022 GAAP and non-GAAP service revenues to be between $395 million and $400 million. The Company now expects full year 2022 non-GAAP EBITDA to be between $177 million and $183 million. The Company expects full year 2022 non-GAAP earnings to be between $2.73 and $2.83 per share.

[0000926326-22-000031:8k_2_02:28]
For the fourth quarter of 2022, the Company expects total GAAP and non-GAAP revenues to be between $285 million and $295 million. The Company expects fourth quarter 2022 GAAP and non-GAAP product revenues to be between $183 million and $188 million, and fourth quarter 2022 GAAP and non-GAAP service revenues to be between $102 million and $107 million. The Company expects fourth quarter 2022 non-GAAP EBITDA to be between $10 million and $16 million. The Company expects fourth quarter 2022 non-GAAP earnings to be between $0.05 and $0.15 per share.

[0000926326-22-000031:8k_2_02:29]
The Company’s fourth quarter and full year 2022 guidance has been adjusted to include the anticipated contributions and integration costs of recent acquisitions, as well as the anticipated effects of the current inflationary environment and expected impact of current macro-economic headwinds.

[0000926326-22-000031:8k_2_02:30]
The table below summarizes Omnicell’s 2022 guidance outlined above.

[0000926326-22-000031:8k_2_02:31]
|  | Q4’22 | FY 2022 |
| Product Bookings | Not provided | $950 million - $1.050 billion |
| Total GAAP and Non-GAAP Revenues | $285 million - $295 million | $1.284 billion - $1.294 billion |
| GAAP and Non-GAAP Product Revenues | $183 million - $188 million | $889 million - $894 million |
| GAAP and Non-GAAP Service Revenues | $102 million - $107 million | $395 million - $400 million |
| Non-GAAP EBITDA | $10 million - $16 million | $177 million - $183 million |
| Non-GAAP Earnings Per Share | $0.05 - $0.15 | $2.73 - $2.83 |

[0000926326-22-000031:8k_2_02:32]
The Company does not provide guidance for GAAP net income or GAAP earnings per share, nor a reconciliation of these forward-looking non-GAAP financial measures to the most directly comparable GAAP financial measures on a forward-looking basis because it is unable to predict certain items contained in the GAAP measures without unreasonable efforts. These forward-looking non-GAAP financial measures do not include certain items, which may be significant, including, but not limited to, unusual gains and losses, costs associated with future restructurings, acquisition-related expenses, and certain tax and litigation outcomes.

[0000926326-22-000031:8k_2_02:33]
Omnicell Conference Call Information

[0000926326-22-000031:8k_2_02:34]
Omnicell will hold a conference call today, Wednesday, November 2, 2022 at 8:30 a.m. ET to discuss its third quarter 2022 financial results. The conference call can be accessed by dialing 1-888-550-5424 within the U.S. or 1-646-960-0819 for all other locations. The Conference ID # is 9581556. A link to the live and archived webcast will also be available on the Investor Relations section of Omnicell’s website at http://ir.omnicell.com/events-and-presentations/.

[0000926326-22-000031:8k_2_02:35]
1 As of 11/2/2022 and as defined by Definitive Healthcare

[0000926326-22-000031:8k_2_02:36]
About Omnicell

[0000926326-22-000031:8k_2_02:37]
Since 1992, Omnicell has been committed to transforming the pharmacy care delivery model to dramatically improve outcomes and lower costs. Through the industry vision of the Autonomous Pharmacy, a combination of automation, intelligence, and technology-enabled services, powered by a cloud data platform, Omnicell supports more efficient ways to manage medications across all care settings.

[0000926326-22-000031:8k_2_02:38]
Facilities worldwide use our automation and analytics solutions to increase operational efficiency, reduce medication errors, deliver actionable intelligence, and improve patient safety. Institutional and retail pharmacies across North America, the United Kingdom, Germany, and Australia leverage our innovative medication adherence and population health solutions to improve patient engagement and adherence to prescriptions, helping to reduce costly hospital readmissions.

[0000926326-22-000031:8k_2_02:39]
To learn more, visit www.omnicell.com. From time to time, Omnicell may use the Company’s investor relations website and other online social media channels, including its Twitter handle www.twitter.com/omnicell, LinkedIn page www.linkedin.com/company/omnicell, and Facebook page www.facebook.com/omnicellinc, to disclose material non-public information and comply with its disclosure obligations under Regulation Fair Disclosure (“Reg FD”).

[0000926326-22-000031:8k_2_02:40]
OMNICELL and the Omnicell logo are registered trademarks of Omnicell, Inc. or one of its subsidiaries.

[0000926326-22-000031:8k_2_02:41]
Forward-Looking Statements

[0000926326-22-000031:8k_2_02:42]
forward-looking statements, whether as a result of changed circumstances, new information, future events, or otherwise, except as required by law.

[0000926326-22-000031:8k_2_02:43]
Use of Non-GAAP Financial Information

[0000926326-22-000031:8k_2_02:44]
This press release contains financial measures that are not calculated in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”). Management evaluates and makes operating decisions using various performance measures. In addition to Omnicell’s GAAP results, we also consider non-GAAP revenues, non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP operating margin, non-GAAP net income, non-GAAP net income per diluted share, non-GAAP diluted shares, non-GAAP EBITDA, non-GAAP EBITDA margin, and non-GAAP free cash flow. These non-GAAP results and metrics should not be considered as an alternative to revenues, gross profit, operating expenses, income from operations, net income, net income per diluted share, diluted shares, net cash provided by operating activities, or any other performance measure derived in accordance with GAAP. We present these non-GAAP results and metrics because management considers them to be important supplemental measures of Omnicell’s performance and refers to such measures when analyzing Omnicell’s strategy and operations.

[0000926326-22-000031:8k_2_02:45]
Our non-GAAP revenues, non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP operating margin, non-GAAP net income, non-GAAP net income per diluted share, non-GAAP EBITDA, and non-GAAP EBITDA margin are exclusive of certain items to facilitate management’s review of the comparability of Omnicell’s core operating results on a period-to-period basis because such items are not related to Omnicell’s ongoing core operating results as viewed by management. We define our “core operating results” as those revenues recorded in a particular period and the expenses incurred within such period that directly drive operating income in such period. Management uses these non-GAAP financial measures in making operating decisions because, in addition to meaningful supplemental information regarding operating performance, the measures give us a better understanding of how we believe we should invest in research and development, fund infrastructure growth, and evaluate the effectiveness of marketing strategies. In calculating the above non-GAAP results: non-GAAP revenues excludes from its GAAP equivalent item a) below; non-GAAP gross profit and non-GAAP gross margin exclude from their GAAP equivalents items a), b), c), f), and g) below; non-GAAP operating expenses excludes from its GAAP equivalents items b), c), d), e), f), g), and j) below; non-GAAP income from operations and non-GAAP operating margin exclude from their GAAP equivalents items a), b), c), d), e), f), g), and j) below; and non-GAAP net income and non-GAAP net income per diluted share exclude from their GAAP equivalents items a) through k) below. Non-GAAP EBITDA is defined as earnings before interest income and expense, taxes, depreciation, amortization, and share-based compensation, as well as excluding certain other non-GAAP adjustments. Non-GAAP EBITDA and non-GAAP EBITDA margin exclude from their GAAP equivalents items a), b), d), e), f), g), h), i), and j) below:

[0000926326-22-000031:8k_2_02:46]
a)Acquisition accounting impact related to deferred revenues. In connection with the recent acquisition of FDS Amplicare, we recorded a fair value adjustment to acquired deferred revenues as part of the purchase accounting in accordance with GAAP. The adjustment represents revenues that would have been recognized in the normal course of business by FDS Amplicare if the acquisition had not occurred, but was not recognized due to GAAP purchase accounting requirements. The non-GAAP adjustment to our revenues is intended to include the full amounts of such revenues. We believe the adjustment to these revenues is useful as a measure of the ongoing performance of our business.

[0000926326-22-000031:8k_2_02:47]
b)Share-based compensation expense. We excluded from our non-GAAP results the expense related to equity-based compensation plans as it represents expenses that do not require cash settlement from Omnicell.

[0000926326-22-000031:8k_2_02:48]
c)Amortization of acquired intangible assets. We excluded from our non-GAAP results the intangible assets amortization expense resulting from our past acquisitions. These non-cash charges are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results.

[0000926326-22-000031:8k_2_02:49]
d)Acquisition-related expenses. We excluded from our non-GAAP results the expenses related to recent acquisitions, including amortization of representations and warranties insurance. These expenses are unrelated to our ongoing operations, vary in size and frequency, and are subject to significant fluctuations from period to period due to varying levels of acquisition activity. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of less acquisitive peer companies.

[0000926326-22-000031:8k_2_02:50]
e)Impairment and abandonment of operating lease right-of-use assets related to facilities. We excluded from our non-GAAP results the impairment and abandonment of operating lease right-of-use assets incurred in connection with restructuring activities for optimization of certain leased facilities. These non-cash charges are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results.

[0000926326-22-000031:8k_2_02:51]
f)Ransomware-related expenses, net of insurance recoveries. We excluded from our non-GAAP results the net expenses related to the previously disclosed ransomware incident identified by the Company on May 4, 2022. Expenses include costs to investigate and remediate the ransomware incident, as well as legal and other professional services, and are presented net of expected insurance recoveries. These expenses are unrelated to our ongoing operations and would not have otherwise been incurred by us in the normal course of business. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of peer companies.

[0000926326-22-000031:8k_2_02:52]
g)Severance-related expenses. We excluded from our non-GAAP results the expenses related to restructuring events. These expenses are unrelated to our ongoing operations, vary in size and frequency, and are subject to significant fluctuations from period to period due to varying levels of restructuring activity. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of peer companies.

[0000926326-22-000031:8k_2_02:53]
h)Amortization of debt issuance costs. Debt issuance costs represent costs associated with the issuance of term loan and revolving credit facilities, as well as the issuance of convertible senior notes. The costs include underwriting fees, original issue discount, ticking fees, and legal fees. These non-cash expenses are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results.

[0000926326-22-000031:8k_2_02:54]
i)Amortization of discount on convertible senior notes. We excluded from our non-GAAP results the amortization of the imputed discount on our convertible senior notes. Under GAAP (prior to the adoption of Accounting Standards Update 2020-06, effective January 1, 2022), certain convertible debt instruments that may be settled in cash upon conversion were required to be bifurcated into separate liability and equity components in a manner that reflects the issuer’s assumed non-convertible debt borrowing rate. For GAAP purposes, we were required to recognize the imputed interest expense on the difference between our assumed non-convertible debt borrowing rate and the coupon rate on our convertible senior notes. This non-cash expense is not considered by management to reflect the core cash-generating performance of the business and therefore is excluded from our non-GAAP results.

[0000926326-22-000031:8k_2_02:55]
j)Certain litigation costs. We excluded non-recurring charges and benefits, including litigation expenses and settlements, related to litigation matters that are outside of the ordinary course of our business or that are not representative of those that we historically have incurred. These expenses are unrelated to our ongoing operations and we do not expect them to occur in the ordinary course of business. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of peer companies.

[0000926326-22-000031:8k_2_02:56]
k)Tax impact of IP restructuring. We excluded from our non-GAAP results the tax impact related to the release of a net uncertain tax benefit as a result of effective settlement with the tax authorities related to prior IP restructuring. This impact is unrelated to our ongoing operations, and we do not expect it to occur in the ordinary course of business. We believe that excluding this impact provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of peer companies.

[0000926326-22-000031:8k_2_02:57]
Management adjusts for the above items because management believes that, in general, these items possess one or more of the following characteristics: their magnitude and timing is largely outside of Omnicell’s control; they are unrelated to the ongoing operation of the business in the ordinary course; they are unusual and we do not expect them to occur in the ordinary course of business; or they are non-operational or non-cash expenses involving stock compensation plans or other items.

[0000926326-22-000031:8k_2_02:58]
We believe that the presentation of non-GAAP revenues, non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP operating margin, non-GAAP net income, non-GAAP net income per diluted share, non-GAAP EBITDA, and non-GAAP EBITDA margin is warranted for several reasons:

[0000926326-22-000031:8k_2_02:59]
a)Such non-GAAP financial measures provide an additional analytical tool for understanding Omnicell’s financial performance by excluding the impact of items which may obscure trends in the core operating results of the business.

[0000926326-22-000031:8k_2_02:60]
b)Since we have historically reported non-GAAP results to the investment community, we believe the inclusion of non-GAAP numbers provides consistency and enhances investors’ ability to compare our performance across financial reporting periods.

[0000926326-22-000031:8k_2_02:61]
c)These non-GAAP financial measures are employed by management in its own evaluation of performance and are utilized in financial and operational decision-making processes, such as budget planning and forecasting.

[0000926326-22-000031:8k_2_02:62]
d)These non-GAAP financial measures facilitate comparisons to the operating results of other companies in our industry, which also use non-GAAP financial measures to supplement their GAAP results (although these companies may

[0000926326-22-000031:8k_2_02:63]
calculate non-GAAP financial measures differently than Omnicell does), thus enhancing the perspective of investors who wish to utilize such comparisons in their analysis of our performance.

[0000926326-22-000031:8k_2_02:64]
Set forth below are additional reasons why share-based compensation expense is excluded from our non-GAAP financial measures:

[0000926326-22-000031:8k_2_02:65]
i)While share-based compensation calculated in accordance with Accounting Standards Codification (“ASC”) 718 constitutes an ongoing and recurring expense of Omnicell, it is not an expense that requires cash settlement by Omnicell. We therefore exclude these charges for purposes of evaluating core operating results. Thus, our non-GAAP measurements are presented exclusive of share-based compensation expense to assist management and investors in evaluating our core operating results.

[0000926326-22-000031:8k_2_02:66]
ii)We present ASC 718 share-based payment compensation expense in our reconciliation of non-GAAP financial measures on a pre-tax basis because the exact tax differences related to the timing and deductibility of share-based compensation under ASC 718 are dependent upon the trading price of Omnicell’s common stock and the timing and exercise by employees of their stock options. As a result of these timing and market uncertainties, the tax effect related to share-based compensation expense would be inconsistent in amount and frequency and is therefore excluded from our non-GAAP results.

[0000926326-22-000031:8k_2_02:67]
Non-GAAP diluted shares is defined as our GAAP diluted shares, excluding the impact of dilutive convertible senior notes for which the Company is economically hedged through its anti-dilutive convertible note hedge transaction. We believe non-GAAP diluted shares is a useful non-GAAP metric because it provides insight into the offsetting economic effect of the hedge transaction against potential conversion of the convertible senior notes.

[0000926326-22-000031:8k_2_02:68]
Non-GAAP free cash flow is defined as net cash provided by operating activities less cash used for software development for external use and purchases of property and equipment. We believe free cash flow is important to enable investors to better understand and evaluate our ongoing operating results and allows for greater transparency in the review and understanding of our overall financial, operational, and economic performance, because free cash flow takes into account certain capital expenditures and cash used for software development necessary to operate our business.

[0000926326-22-000031:8k_2_02:69]
As stated above, we present non-GAAP financial measures because we consider them to be important supplemental measures of performance. However, non-GAAP financial measures have limitations as an analytical tool and should not be considered in isolation or as a substitute for Omnicell’s GAAP results. In the future, we expect to incur expenses similar to certain of the non-GAAP adjustments described above and expect to continue reporting non-GAAP financial measures excluding such items. Some of the limitations in relying on non-GAAP financial measures are:

[0000926326-22-000031:8k_2_02:70]
a)Omnicell’s equity incentive plans and stock purchase plans are important components of incentive compensation arrangements and will be reflected as expenses in Omnicell’s GAAP results for the foreseeable future under ASC 718.

[0000926326-22-000031:8k_2_02:71]
b)Other companies, including companies in Omnicell’s industry, may calculate non-GAAP financial measures differently than Omnicell, limiting their usefulness as a comparative measure.

[0000926326-22-000031:8k_2_02:72]
c)A limitation of the utility of free cash flow as a measure of financial performance is that it does not represent the total increase or decrease in Omnicell’s cash balance for the period.

[0000926326-22-000031:8k_2_02:73]
A detailed reconciliation between Omnicell’s non-GAAP and GAAP financial results is set forth in the financial tables at the end of this press release. Investors are advised to carefully review and consider this information strictly as a supplement to the GAAP results that are contained in this press release as well as in Omnicell’s other reports filed with or furnished to the SEC.

[0000926326-22-000031:8k_2_02:74]
Omnicell, Inc.

[0000926326-22-000031:8k_2_02:75]
Condensed Consolidated Statements of Operations

[0000926326-22-000031:8k_2_02:76]
(Unaudited, in thousands, except per share data)

[0000926326-22-000031:8k_2_02:77]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Revenues: |  |  |  |  |  |  |  |
| Product revenues | $ | 246,565 |  |  | $ | 213,970 |  |  | $ | 706,246 |  |  | $ | 589,006 |  |
| Services and other revenues | 101,494 |  |  | 82,432 |  |  | 292,027 |  |  | 231,978 |  |
| Total revenues | 348,059 |  |  | 296,402 |  |  | 998,273 |  |  | 820,984 |  |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | 134,023 |  |  | 110,743 |  |  | 374,175 |  |  | 303,597 |  |
| Cost of services and other revenues | 54,941 |  |  | 38,880 |  |  | 156,864 |  |  | 112,027 |  |
| Total cost of revenues | 188,964 |  |  | 149,623 |  |  | 531,039 |  |  | 415,624 |  |
| Gross profit | 159,095 |  |  | 146,779 |  |  | 467,234 |  |  | 405,360 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 25,171 |  |  | 19,477 |  |  | 76,556 |  |  | 53,770 |  |
| Selling, general, and administrative | 115,459 |  |  | 97,910 |  |  | 354,644 |  |  | 273,672 |  |
| Total operating expenses | 140,630 |  |  | 117,387 |  |  | 431,200 |  |  | 327,442 |  |
| Income from operations | 18,465 |  |  | 29,392 |  |  | 36,034 |  |  | 77,918 |  |
| Interest and other income (expense), net | (1,148) |  |  | (6,065) |  |  | (2,973) |  |  | (18,715) |  |
| Income before provision for income taxes | 17,317 |  |  | 23,327 |  |  | 33,061 |  |  | 59,203 |  |
| Provision for (benefit from) income taxes | 543 |  |  | (5,990) |  |  | (995) |  |  | (4,665) |  |
| Net income | $ | 16,774 |  |  | $ | 29,317 |  |  | $ | 34,056 |  |  | $ | 63,868 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.38 |  |  | $ | 0.67 |  |  | $ | 0.77 |  |  | $ | 1.48 |  |
| Diluted | $ | 0.37 |  |  | $ | 0.61 |  |  | $ | 0.73 |  |  | $ | 1.35 |  |
| Weighted-average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 44,441 |  |  | 43,648 |  |  | 44,304 |  |  | 43,293 |  |
| Diluted | 45,819 |  |  | 48,341 |  |  | 46,759 |  |  | 47,195 |  |

[0000926326-22-000031:8k_2_02:78]
7

[0000926326-22-000031:8k_2_02:79]
Omnicell, Inc.

[0000926326-22-000031:8k_2_02:80]
Condensed Consolidated Balance Sheets

[0000926326-22-000031:8k_2_02:81]
(Unaudited, in thousands)

[0000926326-22-000031:8k_2_02:82]
|  | September 30,2022 |  | December 31,2021 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 266,402 |  |  | $ | 349,051 |  |
| Accounts receivable and unbilled receivables, net | 354,098 |  |  | 240,894 |  |
| Inventories | 147,096 |  |  | 119,924 |  |
| Prepaid expenses | 24,862 |  |  | 22,499 |  |
| Other current assets | 56,674 |  |  | 48,334 |  |
| Total current assets | 849,132 |  |  | 780,702 |  |
| Property and equipment, net | 88,356 |  |  | 71,141 |  |
| Long-term investment in sales-type leases, net | 33,807 |  |  | 18,391 |  |
| Operating lease right-of-use assets | 44,133 |  |  | 48,549 |  |
| Goodwill | 731,294 |  |  | 738,900 |  |
| Intangible assets, net | 251,004 |  |  | 277,616 |  |
| Long-term deferred tax assets | 16,619 |  |  | 15,883 |  |
| Prepaid commissions | 54,994 |  |  | 63,795 |  |
| Other long-term assets | 110,346 |  |  | 127,519 |  |
| Total assets | $ | 2,179,685 |  |  | $ | 2,142,496 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 73,517 |  |  | $ | 71,513 |  |
| Accrued compensation | 42,799 |  |  | 71,130 |  |
| Accrued liabilities | 146,440 |  |  | 133,167 |  |
| Deferred revenues, net | 113,925 |  |  | 112,196 |  |
| Convertible senior notes, net | — |  |  | 488,152 |  |
| Total current liabilities | 376,681 |  |  | 876,158 |  |
| Long-term deferred revenues | 34,519 |  |  | 20,194 |  |
| Long-term deferred tax liabilities | 16,140 |  |  | 51,705 |  |
| Long-term operating lease liabilities | 41,862 |  |  | 39,911 |  |
| Other long-term liabilities | 9,285 |  |  | 7,839 |  |
| Convertible senior notes, net | 565,803 |  |  | — |  |
| Total liabilities | 1,044,290 |  |  | 995,807 |  |
| Total stockholders’ equity | 1,135,395 |  |  | 1,146,689 |  |
| Total liabilities and stockholders’ equity | $ | 2,179,685 |  |  | $ | 2,142,496 |  |

[0000926326-22-000031:8k_2_02:83]
Omnicell, Inc.

[0000926326-22-000031:8k_2_02:84]
Condensed Consolidated Statements of Cash Flows

[0000926326-22-000031:8k_2_02:85]
(Unaudited, in thousands)

[0000926326-22-000031:8k_2_02:86]
|  | Nine Months Ended September 30, |
|  | 2022 |  | 2021 |
| Operating Activities |  |  |  |
| Net income | $ | 34,056 |  |  | $ | 63,868 |  |
| Adjustments to reconcile net income to net cash provided by (used in) operating activities: |  |  |  |
| Depreciation and amortization | 64,843 |  |  | 53,140 |  |
| Loss on disposal of property and equipment | 331 |  |  | 297 |  |
| Share-based compensation expense | 50,731 |  |  | 38,477 |  |
| Deferred income taxes | (17,061) |  |  | 2,042 |  |
| Amortization of operating lease right-of-use assets | 9,709 |  |  | 8,764 |  |
| Impairment and abandonment of operating lease right-of-use assets related to facilities | 5,390 |  |  | — |  |
| Amortization of debt issuance costs | 3,121 |  |  | 2,570 |  |
| Amortization of discount on convertible senior notes | — |  |  | 13,874 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable and unbilled receivables | (116,895) |  |  | (39,561) |  |
| Inventories | (32,269) |  |  | (10,138) |  |
| Prepaid expenses | (2,602) |  |  | (8,229) |  |
| Other current assets | 6,692 |  |  | (1,059) |  |
| Investment in sales-type leases | (17,336) |  |  | 2,686 |  |
| Prepaid commissions | 8,801 |  |  | (1,030) |  |
| Other long-term assets | 4,189 |  |  | 2,567 |  |
| Accounts payable | 2,043 |  |  | 33,111 |  |
| Accrued compensation | (27,940) |  |  | (12,018) |  |
| Accrued liabilities | 11,678 |  |  | 20,149 |  |
| Deferred revenues | 17,667 |  |  | 21,225 |  |
| Operating lease liabilities | (10,966) |  |  | (9,392) |  |
| Other long-term liabilities | 1,446 |  |  | (9,166) |  |
| Net cash provided by (used in) operating activities | (4,372) |  |  | 172,177 |  |
| Investing Activities |  |  |  |
| Software development for external use | (9,648) |  |  | (24,141) |  |
| Purchases of property and equipment | (33,861) |  |  | (17,892) |  |
| Business acquisitions, net of cash acquired | (3,392) |  |  | (178,080) |  |
| Purchase price adjustments from business acquisitions | 5,484 |  |  | — |  |
| Net cash used in investing activities | (41,417) |  |  | (220,113) |  |
| Financing Activities |  |  |  |
| Proceeds from issuances under stock-based compensation plans | 39,539 |  |  | 53,917 |  |
| Employees’ taxes paid related to restricted stock units | (11,442) |  |  | (10,161) |  |
| Change in customer funds, net | (402) |  |  | (3,059) |  |
| Stock repurchases | (52,210) |  |  | — |  |
| Net cash provided by (used in) financing activities | (24,515) |  |  | 40,697 |  |
| Effect of exchange rate changes on cash and cash equivalents | (1,425) |  |  | (492) |  |
| Net decrease in cash, cash equivalents, and restricted cash | (71,729) |  |  | (7,731) |  |
| Cash, cash equivalents, and restricted cash at beginning of period | 355,620 |  |  | 489,920 |  |
| Cash, cash equivalents, and restricted cash at end of period | $ | 283,891 |  |  | $ | 482,189 |  |
| Reconciliation of cash, cash equivalents, and restricted cash to the Condensed Consolidated Balance Sheets: |
| Cash and cash equivalents | $ | 266,402 |  |  | $ | 481,549 |  |
| Restricted cash included in other current assets | 17,489 |  |  | 640 |  |
| Cash, cash equivalents, and restricted cash at end of period | $ | 283,891 |  |  | $ | 482,189 |  |

[0000926326-22-000031:8k_2_02:87]
9

[0000926326-22-000031:8k_2_02:88]
Omnicell, Inc.

[0000926326-22-000031:8k_2_02:89]
Reconciliation of GAAP to Non-GAAP

[0000926326-22-000031:8k_2_02:90]
(Unaudited, in thousands, except per share data and percentage)

[0000926326-22-000031:8k_2_02:91]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Reconciliation of GAAP revenues to non-GAAP revenues: |
| GAAP revenues | $ | 348,059 |  |  | $ | 296,402 |  |  | $ | 998,273 |  |  | $ | 820,984 |  |
| Acquisition accounting impact related to deferred revenues | 183 |  |  | 95 |  |  | 863 |  |  | 95 |  |
| Non-GAAP revenues | $ | 348,242 |  |  | $ | 296,497 |  |  | $ | 999,136 |  |  | $ | 821,079 |  |
| Reconciliation of GAAP gross profit to non-GAAP gross profit: |  |  |  |  |  |
| GAAP gross profit | $ | 159,095 |  |  | $ | 146,779 |  |  | $ | 467,234 |  |  | $ | 405,360 |  |
| GAAP gross margin | 45.7% |  | 49.5% |  | 46.8% |  | 49.4% |
| Share-based compensation expense | 2,203 |  |  | 1,909 |  |  | 6,607 |  |  | 5,890 |  |
| Amortization of acquired intangibles | 3,238 |  |  | 2,727 |  |  | 10,089 |  |  | 8,210 |  |
| Acquisition accounting impact related to deferred revenues | 183 |  |  | 95 |  |  | 863 |  |  | 95 |  |
| Ransomware-related expenses, net of insurance recoveries | 95 |  |  | — |  |  | 317 |  |  | — |  |
| Severance-related expenses | 444 |  |  | — |  |  | 600 |  |  | 389 |  |
| Non-GAAP gross profit | $ | 165,258 |  |  | $ | 151,510 |  |  | $ | 485,710 |  |  | $ | 419,944 |  |
| Non-GAAP gross margin | 47.5% |  | 51.1% |  | 48.6% |  | 51.1% |
| Reconciliation of GAAP operating expenses to non-GAAP operating expenses: |  |  |  |  |
| GAAP operating expenses | $ | 140,630 |  |  | $ | 117,387 |  |  | $ | 431,200 |  |  | $ | 327,442 |  |
| GAAP operating expenses % to total revenues | 40.4% |  | 39.6% |  | 43.2% |  | 39.9% |
| Share-based compensation expense | (15,107) |  |  | (11,757) |  |  | (44,124) |  |  | (32,587) |  |
| Amortization of acquired intangibles | (5,507) |  |  | (3,518) |  |  | (16,554) |  |  | (10,340) |  |
| Acquisition-related expenses | (251) |  |  | (4,772) |  |  | (1,909) |  |  | (6,758) |  |
| Impairment and abandonment of operating lease right-of-use assets related to facilities | (297) |  |  | — |  |  | (5,390) |  |  | — |  |
| Ransomware-related expenses, net of insurance recoveries | (932) |  |  | — |  |  | (2,084) |  |  | — |  |
| Severance-related and other expenses (a) | (2,050) |  |  | — |  |  | (5,421) |  |  | (2,582) |  |
| Non-GAAP operating expenses | $ | 116,486 |  |  | $ | 97,340 |  |  | $ | 355,718 |  |  | $ | 275,175 |  |
| Non-GAAP operating expenses as a % of total non-GAAP revenues | 33.4% |  | 32.8% |  | 35.6% |  | 33.5% |
| Reconciliation of GAAP income from operations to non-GAAP income from operations: |
| GAAP income from operations | $ | 18,465 |  |  | $ | 29,392 |  |  | $ | 36,034 |  |  | $ | 77,918 |  |
| GAAP operating income % to total revenues | 5.3% |  | 9.9% |  | 3.6% |  | 9.5% |
| Share-based compensation expense | 17,310 |  |  | 13,666 |  |  | 50,731 |  |  | 38,477 |  |
| Amortization of acquired intangibles | 8,745 |  |  | 6,245 |  |  | 26,643 |  |  | 18,550 |  |
| Acquisition accounting impact related to deferred revenues | 183 |  |  | 95 |  |  | 863 |  |  | 95 |  |
| Acquisition-related expenses | 251 |  |  | 4,772 |  |  | 1,909 |  |  | 6,758 |  |
| Impairment and abandonment of operating lease right-of-use assets related to facilities | 297 |  |  | — |  |  | 5,390 |  |  | — |  |
| Ransomware-related expenses, net of insurance recoveries | 1,027 |  |  | — |  |  | 2,401 |  |  | — |  |
| Severance-related and other expenses (a) | 2,494 |  |  | — |  |  | 6,021 |  |  | 2,971 |  |
| Non-GAAP income from operations | $ | 48,772 |  |  | $ | 54,170 |  |  | $ | 129,992 |  |  | $ | 144,769 |  |
| Non-GAAP operating margin (non-GAAP operating income as a % of total non-GAAP revenues) | 14.0% |  | 18.3% |  | 13.0% |  | 17.6% |

[0000926326-22-000031:8k_2_02:92]
Omnicell, Inc.

[0000926326-22-000031:8k_2_02:93]
Reconciliation of GAAP to Non-GAAP

[0000926326-22-000031:8k_2_02:94]
(Unaudited, in thousands, except per share data and percentage)

[0000926326-22-000031:8k_2_02:95]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Reconciliation of GAAP net income to non-GAAP net income: |
| GAAP net income | $ | 16,774 |  |  | $ | 29,317 |  |  | $ | 34,056 |  |  | $ | 63,868 |  |
| Tax impact of IP restructuring | — |  |  | (6,202) |  |  | — |  |  | (6,202) |  |
| Share-based compensation expense | 17,310 |  |  | 13,666 |  |  | 50,731 |  |  | 38,477 |  |
| Amortization of acquired intangibles | 8,745 |  |  | 6,245 |  |  | 26,643 |  |  | 18,550 |  |
| Acquisition accounting impact related to deferred revenues | 183 |  |  | 95 |  |  | 863 |  |  | 95 |  |
| Acquisition-related expenses | 251 |  |  | 4,772 |  |  | 1,909 |  |  | 6,758 |  |
| Impairment and abandonment of operating lease right-of-use assets related to facilities | 297 |  |  | — |  |  | 5,390 |  |  | — |  |
| Ransomware-related expenses, net of insurance recoveries | 1,027 |  |  | — |  |  | 2,401 |  |  | — |  |
| Severance-related and other expenses (a) | 2,494 |  |  | — |  |  | 6,021 |  |  | 2,971 |  |
| Amortization of debt issuance costs | 1,042 |  |  | 863 |  |  | 3,121 |  |  | 2,570 |  |
| Amortization of discount on convertible senior notes | — |  |  | 4,679 |  |  | — |  |  | 13,874 |  |
| Tax effect of the adjustments above (b) | (2,948) |  |  | (3,497) |  |  | (9,734) |  |  | (9,411) |  |
| Non-GAAP net income | $ | 45,175 |  |  | $ | 49,938 |  |  | $ | 121,401 |  |  | $ | 131,550 |  |
| Reconciliation of GAAP net income per share - diluted to non-GAAP net income per share - diluted: |
| Shares - diluted GAAP | 45,819 |  |  | 48,341 |  |  | 46,759 |  |  | 47,195 |  |
| Shares - diluted non-GAAP (c) | 45,384 |  |  | 46,185 |  |  | 45,597 |  |  | 45,379 |  |
| GAAP net income per share - diluted | $ | 0.37 |  |  | $ | 0.61 |  |  | $ | 0.73 |  |  | $ | 1.35 |  |
| Tax impact of IP restructuring | — |  |  | (0.13) |  |  | — |  |  | (0.14) |  |
| Share-based compensation expense | 0.38 |  |  | 0.29 |  |  | 1.11 |  |  | 0.85 |  |
| Amortization of acquired intangibles | 0.19 |  |  | 0.14 |  |  | 0.58 |  |  | 0.41 |  |
| Acquisition accounting impact related to deferred revenues | 0.00 |  |  | 0.00 |  |  | 0.02 |  |  | 0.00 |  |
| Acquisition-related expenses | 0.01 |  |  | 0.10 |  |  | 0.04 |  |  | 0.15 |  |
| Impairment and abandonment of operating lease right-of-use assets related to facilities | 0.01 |  |  | — |  |  | 0.12 |  |  | — |  |
| Ransomware-related expenses, net of insurance recoveries | 0.02 |  |  | — |  |  | 0.05 |  |  | — |  |
| Severance-related and other expenses | 0.06 |  |  | — |  |  | 0.13 |  |  | 0.07 |  |
| Amortization of debt issuance costs | 0.02 |  |  | 0.02 |  |  | 0.07 |  |  | 0.06 |  |
| Amortization of discount on convertible senior notes | — |  |  | 0.10 |  |  | — |  |  | 0.31 |  |
| Non-GAAP dilutive shares impact from convertible note hedge transaction (c) | 0.00 |  |  | 0.03 |  |  | 0.02 |  |  | 0.05 |  |
| Tax effect of the adjustments above (b) | (0.06) |  |  | (0.08) |  |  | (0.21) |  |  | (0.21) |  |
| Non-GAAP net income per share - diluted | $ | 1.00 |  |  | $ | 1.08 |  |  | $ | 2.66 |  |  | $ | 2.90 |  |
| Reconciliation of GAAP net income to non-GAAP EBITDA(d): |
| GAAP net income | $ | 16,774 |  |  | $ | 29,317 |  |  | $ | 34,056 |  |  | $ | 63,868 |  |
| Share-based compensation expense | 17,310 |  |  | 13,666 |  |  | 50,731 |  |  | 38,477 |  |
| Interest (income) and expense, net | (1,136) |  |  | 360 |  |  | (1,311) |  |  | 520 |  |
| Depreciation and amortization expense | 21,826 |  |  | 18,175 |  |  | 64,843 |  |  | 53,140 |  |
| Acquisition accounting impact related to deferred revenues | 183 |  |  | 95 |  |  | 863 |  |  | 95 |  |
| Acquisition-related expenses | 251 |  |  | 4,772 |  |  | 1,909 |  |  | 6,758 |  |
| Impairment and abandonment of operating lease right-of-use assets related to facilities | 297 |  |  | — |  |  | 5,390 |  |  | — |  |
| Ransomware-related expenses, net of insurance recoveries | 1,027 |  |  | — |  |  | 2,401 |  |  | — |  |
| Severance-related and other expenses (a) | 2,494 |  |  | — |  |  | 6,021 |  |  | 2,971 |  |
| Amortization of debt issuance costs | 1,042 |  |  | 863 |  |  | 3,121 |  |  | 2,570 |  |
| Amortization of discount on convertible senior notes | — |  |  | 4,679 |  |  | — |  |  | 13,874 |  |
| Income tax expense (benefit) | 543 |  |  | (5,990) |  |  | (995) |  |  | (4,665) |  |
| Non-GAAP EBITDA | $ | 60,611 |  |  | $ | 65,937 |  |  | $ | 167,029 |  |  | $ | 177,608 |  |
| Non-GAAP EBITDA margin (non-GAAP EBITDA as a % of total non-GAAP revenues) | 17.4% |  | 22.2% |  | 16.7% |  | 21.6% |

[0000926326-22-000031:8k_2_02:96]
11

[0000926326-22-000031:8k_2_02:97]
_________________________________________________

[0000926326-22-000031:8k_2_02:98]
(a)For the three and nine months ended September 30, 2022, other expenses included approximately $0.7 million of certain litigation costs. For the nine months ended September 30, 2021, other expenses included approximately $1.0 million of certain litigation costs.

[0000926326-22-000031:8k_2_02:99]
(b)Tax effects calculated for all adjustments except share-based compensation expense, using an estimated annual effective tax rate of 21% for both fiscal years 2022 and 2021.

[0000926326-22-000031:8k_2_02:100]
(c)For the three months ended September 30, 2022 and 2021, non-GAAP diluted shares exclude approximately 0.4 million and 2.2 million shares, respectively, related to the impact of dilutive convertible senior notes for which the Company is economically hedged through its anti-dilutive convertible note hedge transaction. For the nine months ended September 30, 2022 and 2021, non-GAAP diluted shares exclude approximately 1.2 million and 1.8 million shares, respectively.

[0000926326-22-000031:8k_2_02:101]
(d)Defined as earnings before interest income and expense, taxes, depreciation, amortization, and share-based compensation, as well as excluding certain other non-GAAP adjustments.

[0000926326-22-000031:8k_2_02:102]
Omnicell, Inc.

[0000926326-22-000031:8k_2_02:103]
Reconciliation of GAAP to Non-GAAP

[0000926326-22-000031:8k_2_02:104]
(Unaudited, in thousands)

[0000926326-22-000031:8k_2_02:105]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Reconciliation of GAAP net cash provided by (used in) operating activities to non-GAAP free cash flow: |
| GAAP net cash provided by (used in) operating activities | $ | 21,175 |  |  | $ | 42,989 |  |  | $ | (4,372) |  |  | $ | 172,177 |  |
| Software development for external use | (3,105) |  |  | (8,726) |  |  | (9,648) |  |  | (24,141) |  |
| Purchases of property and equipment | (12,762) |  |  | (6,825) |  |  | (33,861) |  |  | (17,892) |  |
| Non-GAAP free cash flow | $ | 5,308 |  |  | $ | 27,438 |  |  | $ | (47,881) |  |  | $ | 130,144 |  |

[0000926326-22-000031:8k_2_02:106]
13
