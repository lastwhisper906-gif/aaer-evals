# OMCL 8-K — 0000926326-18-000003 filed 2018-02-01

## item codes, every 8-K on or before 2018-02-27

- 2018-02-08 0000926326-18-000007 — 5.02
- 2018-02-02 0000926326-18-000005 — 5.02
- 2018-02-01 0000926326-18-000003 — 2.02, 9.01
- 2017-12-26 0000926326-17-000041 — 1.01, 2.03, 9.01
- 2017-11-03 0001104659-17-066102 — 1.01, 8.01, 9.01
- 2017-10-26 0000926326-17-000035 — 2.02, 9.01
- 2017-08-03 0000926326-17-000028 — 5.07 — amendment, the index does not say of what
- 2017-07-27 0000926326-17-000026 — 2.02, 9.01
- 2017-07-25 0000926326-17-000023 — 5.02, 9.01
- 2017-05-24 0000926326-17-000019 — 5.07
- 2017-05-04 0001628280-17-004851 — 2.02, 9.01
- 2017-02-15 0000926326-17-000010 — 2.05
- 2017-02-15 0000926326-17-000008 — 2.02, 9.01
- 2017-02-13 0000926326-17-000002 — 5.02
- 2016-12-08 0001104659-16-161330 — 2.01, 2.03, 9.01
- 2016-12-06 0001104659-16-160709 — 7.01
- 2016-11-29 0001104659-16-159456 — 1.01, 7.01, 9.01
- 2016-10-27 0000926326-16-000075 — 2.02, 9.01
- 2016-10-07 0000926326-16-000072 — 5.02, 8.01
- 2016-08-05 0000926326-16-000068 — 8.01
- 2016-07-28 0000926326-16-000066 — 2.02, 9.01
- 2016-06-13 0001104659-16-126854 — 5.02
- 2016-05-25 0000926326-16-000060 — 5.07
- 2016-04-28 0000926326-16-000054 — 2.02, 9.01
- 2016-03-21 0001104659-16-106649 — 8.01, 9.01
- 2016-03-17 0000926326-16-000051 — 7.01, 9.01
- 2016-03-17 0000926326-16-000049 — 9.01 — amendment of 0000926326-16-000051
- 2016-02-10 0001104659-16-095486 — 5.02, 9.01
- 2016-02-04 0000926326-16-000041 — 2.02, 9.01
- 2016-01-06 0001104659-16-088299 — 1.01, 2.01, 2.03, 9.01
- 2015-12-10 0000926326-15-000038 — 8.01, 9.01
- 2015-10-29 0001104659-15-074138 — 1.01, 9.01
- 2015-10-29 0000926326-15-000031 — 2.02, 9.01
- 2015-08-20 0001104659-15-061135 — 5.02, 9.01
- 2015-07-30 0000926326-15-000024 — 2.02, 9.01
- 2015-05-22 0001104659-15-040440 — 5.07
- 2015-05-01 0001104659-15-032846 — 5.02
- 2015-05-01 0001104659-15-032844 — 7.01
- 2015-04-30 0000926326-15-000015 — 9.01
- 2015-04-22 0001104659-15-029356 — 8.01, 9.01
- 2015-03-20 0001104659-15-021435 — 3.01
- 2015-03-18 0001104659-15-020699 — 7.01
- 2015-03-17 0001104659-15-020483 — 8.01, 9.01
- 2015-03-02 0001104659-15-015802 — 1.01, 9.01
- 2015-02-12 0001104659-15-009234 — 5.02, 9.01
- 2015-02-03 0000926326-15-000003 — 9.01
- 2015-01-15 0001104659-15-002635 — 5.02
- 2014-11-07 0001104659-14-078398 — 1.01, 8.01, 9.01
- 2014-10-30 0000926326-14-000037 — 2.02, 9.01
- 2014-08-25 0001104659-14-062772 — 8.01, 9.01
- 2014-07-31 0000926326-14-000032 — 2.02, 9.01
- 2014-05-21 0001104659-14-040744 — 5.07
- 2014-05-01 0000926326-14-000008 — 2.02, 9.01
- 2014-04-08 0001104659-14-026441 — 4.01, 9.01
- 2014-04-02 0001104659-14-025179 — 5.02
- 2014-02-07 0001104659-14-007552 — 5.02, 9.01
- 2014-02-04 0001104659-14-006352 — 2.02, 9.01
- 2013-12-09 0001104659-13-088980 — 1.01, 9.01
- 2013-12-02 0001104659-13-087877 — 5.02
- 2013-10-31 0001104659-13-079660 — 2.02, 9.01
- 2013-09-26 0001104659-13-072435 — 1.01, 2.03, 9.01
- 2013-08-01 0001104659-13-058959 — 2.02, 9.01
- 2013-05-23 0001104659-13-044317 — 5.07
- 2013-05-02 0001104659-13-036605 — 2.02, 9.01
- 2013-03-11 0001104659-13-019143 — 8.01
- 2013-02-07 0001104659-13-008477 — 5.02, 9.01
- 2013-01-31 0001104659-13-006446 — 2.02, 9.01
- 2012-11-02 0001104659-12-073697 — 5.02
- 2012-10-25 0001104659-12-071211 — 2.02, 9.01
- 2012-08-06 0001104659-12-054635 — 8.01
- 2012-08-03 0001104659-12-054214 — 2.01, 9.01 — amendment of 0001104659-12-038888
- 2012-08-01 0001104659-12-053005 — 2.02, 9.01
- 2012-06-12 0001104659-12-042936 — 8.01, 9.01
- 2012-05-23 0001104659-12-039459 — 5.07
- 2012-05-22 0001104659-12-038888 — 2.01, 9.01
- 2012-05-02 0001104659-12-032048 — 2.02, 9.01
- 2012-05-02 0001104659-12-032036 — 1.01, 9.01
- 2012-04-04 0001104659-12-023883 — 5.02, 8.01
- 2012-03-20 0001104659-12-019462 — 1.01, 9.01
- 2012-02-13 0001104659-12-009353 — 5.02, 9.01
- 2012-01-26 0001104659-12-004244 — 2.02, 9.01
- 2011-10-27 0001104659-11-058464 — 2.02, 9.01
- 2011-10-25 0001104659-11-057721 — 1.01
- 2011-07-28 0001104659-11-041505 — 2.02, 9.01
- 2011-05-27 0001104659-11-032006 — 5.07
- 2011-05-02 0001104659-11-024908 — 2.02, 9.01
- 2011-04-15 0001104659-11-020407 — 5.02, 9.01 — amendment of 0001104659-11-005638
- 2011-02-08 0001104659-11-005638 — 5.02, 9.01
- 2011-01-27 0001104659-11-003419 — 2.02, 9.01
- 2010-12-22 0001104659-10-064003 — 5.02, 5.07, 9.01
- 2010-10-27 0001104659-10-054036 — 2.02, 9.01
- 2010-10-05 0001104659-10-051173 — 8.01
- 2010-07-22 0001104659-10-039126 — 2.02, 9.01
- 2010-07-09 0001104659-10-037594 — 2.05
- 2010-05-28 0001104659-10-031607 — 5.07
- 2010-04-26 0001104659-10-021797 — 2.02, 9.01
- 2010-03-17 0001104659-10-014849 — 5.02, 9.01
- 2010-02-08 0001104659-10-005457 — 5.02, 9.01
- 2010-01-28 0001104659-10-003627 — 2.02, 9.01
- 2009-10-22 0001104659-09-059972 — 2.02, 9.01
- 2009-07-23 0001104659-09-044508 — 2.02, 9.01
- 2009-05-20 0001104659-09-033938 — 5.02, 9.01
- 2009-04-30 0001104659-09-027707 — 2.02, 9.01
- 2009-03-10 0001104659-09-016178 — 5.02, 9.01
- 2009-02-09 0001104659-09-007692 — 5.02, 9.01
- 2009-01-29 0001104659-09-005022 — 2.02, 2.05, 9.01
- 2009-01-21 0001104659-09-003180 — 2.02, 8.01, 9.01
- 2009-01-06 0001104659-09-000625 — 5.02
- 2008-10-23 0001104659-08-065475 — 2.02, 9.01
- 2008-07-21 0001104659-08-046690 — 2.02, 9.01
- 2008-05-16 0001104659-08-034035 — 8.01, 9.01
- 2008-04-28 0001104659-08-027379 — 7.01, 9.01
- 2008-04-21 0001104659-08-025616 — 2.02, 9.01
- 2008-03-12 0001104659-08-016939 — 7.01, 9.01
- 2008-02-26 0001104659-08-012840 — 7.01, 9.01
- 2008-02-12 0001104659-08-009382 — 5.02, 9.01
- 2008-01-31 0001104659-08-006199 — 2.02, 9.01
- 2007-12-05 0001104659-07-087191 — 1.01, 9.01
- 2007-10-18 0001104659-07-075654 — 2.02, 9.01
- 2007-07-27 0001104659-07-056886 — 5.03, 9.01
- 2007-07-19 0001104659-07-054924 — 2.02, 9.01
- 2007-05-23 0001104659-07-042287 — 8.01, 9.01
- 2007-05-07 0001104659-07-036172 — 1.01, 5.02, 9.01
- 2007-04-24 0001104659-07-030578 — 2.02, 9.01 — amendment, the index does not say of what
- 2007-04-24 0001104659-07-030547 — 2.02, 9.01
- 2007-04-10 0001104659-07-027465 — 5.02, 9.01
- 2007-03-23 0001104659-07-021969 — 2.02, 4.02, 9.01
- 2007-01-30 0001104659-07-005772 — 2.02, 9.01
- 2007-01-09 0001104659-07-001600 — 5.02, 9.01
- 2006-10-30 0001104659-06-069612 — 1.01
- 2006-10-19 0001104659-06-067549 — 2.02, 9.01
- 2006-07-20 0001104659-06-048020 — 2.02, 4.02, 9.01
- 2006-05-17 0001104659-06-035522 — 1.01, 9.01 — amendment of 0001104659-05-011155
- 2006-05-09 0001104659-06-032706 — 1.01, 9.01
- 2006-04-25 0001104659-06-027438 — 2.02, 9.01
- 2006-04-04 0001104659-06-022204 — 1.01, 9.01
- 2006-03-15 0001104659-06-016861 — 1.01, 9.01
- 2006-01-30 0001104659-06-004749 — 2.02, 9.01
- 2006-01-24 0001104659-06-003504 — 1.01, 5.02, 9.01
- 2005-12-13 0001104659-05-060532 — 1.01, 9.01
- 2005-11-10 0001104659-05-054663 — 2.02, 9.01
- 2005-07-21 0001104659-05-033464 — 2.02, 9.01
- 2005-06-22 0001104659-05-029255 — 1.01
- 2005-05-16 0001104659-05-023473 — 2.02, 9.01 — amendment of 0001104659-05-018173
- 2005-05-16 0001104659-05-023471 — 2.02, 9.01 — amendment of 0001104659-05-017382
- 2005-05-10 0001104659-05-022127 — 1.01
- 2005-04-26 0001104659-05-018173 — 2.02, 9.01
- 2005-04-21 0001104659-05-017382 — 2.02, 9.01
- 2005-04-06 0001104659-05-015401 — 5.02
- 2005-03-15 0001104659-05-011155 — 1.01, 9.01
- 2005-03-08 0001104659-05-009975 — 1.01, 9.01
- 2005-02-03 0001104659-05-003943 — 2.02, 9.01
- 2005-01-13 0001104659-05-001314 — 5.02, 9.01
- 2004-10-21 0001104659-04-031413 — 2.02, 9.01
- 2004-07-22 0001104659-04-020572 — 12, 7
- 2004-04-14 0001104659-04-010039 — 12, 7
- 2004-04-05 0001104659-04-009437 — 12, 7
- 2004-01-26 0001104659-04-001655 — 12, 7
- 2003-10-16 0001104659-03-022990 — 12, 7
- 2003-07-17 0001104659-03-015053 — 9
- 2003-04-18 0001104659-03-006823 — 7, 9
- 2003-02-14 0001104659-03-002607 — 5, 7

## late-filing notifications on or before 2018-02-27

- 2015-03-02 0000926326-15-000006 — NT 10-K, for the period ended 2014-12-31
- 2007-03-16 0001104659-07-020094 — NT 10-K, for the period ended 2006-12-31

## item 2.02 — earnings release, exhibit 99.1

[0000926326-18-000003:8k_2_02:1]
EX-99.1
2
exhibit991q4-17.htm
EXHIBIT 99.1

[0000926326-18-000003:8k_2_02:2]
Exhibit

[0000926326-18-000003:8k_2_02:3]
Exhibit 99.1

[0000926326-18-000003:8k_2_02:4]
| Contact: |  |  |
| Peter Kuipers |  | Omnicell, Inc. |
| Chief Financial Officer |  | 590 East Middlefield Road |
| 800-850-6664 |  | Mountain View, CA 94043 |
| Peter.kuipers@omnicell.com |  |  |

[0000926326-18-000003:8k_2_02:5]
Omnicell Reports Results for Fiscal Year and Fourth Quarter 2017

[0000926326-18-000003:8k_2_02:6]
Record yearly GAAP revenue of $716.2 million

[0000926326-18-000003:8k_2_02:7]
Record yearly Non-GAAP revenue of $717.4 million

[0000926326-18-000003:8k_2_02:8]
2017 GAAP net income per diluted share of $0.53

[0000926326-18-000003:8k_2_02:9]
2017 Non-GAAP net income per diluted share of $1.33

[0000926326-18-000003:8k_2_02:10]
Record ending product backlog of $345 million

[0000926326-18-000003:8k_2_02:11]
MOUNTAIN VIEW, Calif. -- February 1, 2018 -- Omnicell, Inc. (NASDAQ: OMCL), a leading provider of medication and supply management solutions to healthcare systems, today announced results for its fiscal year and fourth quarter ended December 31, 2017.

[0000926326-18-000003:8k_2_02:12]
GAAP results: Revenue for the fourth quarter of 2017 was $197.9 million, up $11.2 million or 6.0% from the third quarter of 2017, and up $26.0 million or 15.1% from the fourth quarter of 2016. Revenue for the year ended December 31, 2017 was $716.2 million, up $23.5 million or 3.4% from the year ended December 31, 2016.

[0000926326-18-000003:8k_2_02:13]
Fourth quarter 2017 net income as reported in accordance with U.S. generally accepted accounting principles (GAAP) was $24.3 million, or $0.62 per diluted share, which includes the favorable impact of the Tax Cuts and Jobs Act of 2017. This compares to GAAP net income of $6.2 million, or $0.16 per diluted share, for the third quarter of 2017, and GAAP net income of $0.2 million, or $0.00 per diluted share, for the fourth quarter of 2016.

[0000926326-18-000003:8k_2_02:14]
GAAP net income for the year ended December 31, 2017 was $20.6 million, or $0.53 per diluted share. GAAP net income was $0.6 million, or $0.02 per diluted share, for the year ended December 31, 2016.

[0000926326-18-000003:8k_2_02:15]
Non-GAAP results:  Non-GAAP revenue for the fourth quarter of 2017 was $198.3 million, up $11.2 million, or 6.0% from the third quarter of 2017, and up $23.6 million or 13.5% from the fourth quarter of 2016.  Non-GAAP revenue for the year ended December 31, 2017 was $717.4 million, up $14.1 million, or 2.0% from the year ended December 31, 2016.

[0000926326-18-000003:8k_2_02:16]
Non-GAAP net income for the fourth quarter of 2017 was $21.2 million, or $0.54 per diluted share. This compares to non-GAAP net income of $16.3 million, or $0.42 per diluted share, for the third quarter of 2017 and $13.8 million, or $0.37 per diluted share, for the fourth quarter of 2016.

[0000926326-18-000003:8k_2_02:17]
Non-GAAP net income for the year ended December 31, 2017 was $51.3 million, or $1.33 per diluted share.  This compares to non-GAAP net income of $55.7 million, or $1.51 per diluted share for the year ended December 31, 2016.

[0000926326-18-000003:8k_2_02:18]
Non-GAAP net income for each period presented excludes, when applicable, the effect of stock-based compensation expense, amortization expense of acquired intangible assets, acquisition-related expenses, fair value adjustments related to business acquisitions, severance and integration-related expenses, tax reform benefits, and amortization of debt issuance cost.

[0000926326-18-000003:8k_2_02:19]
Total product bookings for the year ended December 31, 2017 were $568 million compared to total bookings for the year ended December 31, 2016 of $541 million. Total product backlog for the year ended December 31, 2017 was $345 million compared to $301 million for the year ended December 31, 2016, or an increase of 14.3% year over year.

[0000926326-18-000003:8k_2_02:20]
"2017 was a successful year for Omnicell with record bookings and revenues," said Randall Lipps, chairman, CEO, president, and founder of Omnicell. "We are proud of the company’s financial performance and our strategic execution. We’re seeing rapid adoption of our latest solutions and services from our Omnicell platform, some of which leverage workflow automation on a cloud data platform, artificial intelligence for predictive analytics and performance-driven partnerships to help our customers achieve the highest level of success. The company is well positioned to take advantage of these great opportunities ahead in 2018."

[0000926326-18-000003:8k_2_02:21]
2017 Business Highlights:

[0000926326-18-000003:8k_2_02:22]
| • | The Company started the production of the XT series in January 2017 and successfully ramped up the production and installation throughout the year; |

[0000926326-18-000003:8k_2_02:23]
| • | In April, the Company announced the launch of AcuDose-Rx® software on XT hardware, which allows legacy Aesynt customers to take full advantage of the XT series; |

[0000926326-18-000003:8k_2_02:24]
| • | During the second quarter, the Company launched the XT series Automated Supply Dispensing Cabinet and the Controlled Substance Dispenser module, which provides innovative, efficient and secure workflow for dispensing and administration of controlled substances; |

[0000926326-18-000003:8k_2_02:25]
| • | In December, the Company announced the XR2 Automated Central Pharmacy System, a robotic solution that is a significant step towards fully automating central pharmacy operations in a variety of settings; |

[0000926326-18-000003:8k_2_02:26]
| • | In December, the Company announced the IVX Workflow which operates on the IVX Cloud, creating a significant technological advancement for sterile compounding workflow processes and enabling pharmacies to safely and efficiently compound and prepare IV doses; |

[0000926326-18-000003:8k_2_02:27]
| • | During the year the Company has experienced good momentum on new products and has received multiple contractual purchase commitments for both the XR2 Automated Central Pharmacy System and the IVX Workflow before their respective general availability dates in 2018; |

[0000926326-18-000003:8k_2_02:28]
| • | During the year the Company expanded its Medication Adherence ecosystem with the addition of advanced automated packaging solutions; |

[0000926326-18-000003:8k_2_02:29]
| • | During the year, the Company expanded the Performance Center's core capabilities of operational improvements into patient outcomes and regulatory compliance through internal development and the acquisition of InPharmics; |

[0000926326-18-000003:8k_2_02:30]
| • | For the twelve months ended December 31, 2017, the Company’s new and competitive conversion rate was 29%; and |

[0000926326-18-000003:8k_2_02:31]
| • | For the year ended December 31, 2017, the Company’s product backlog was $345 million, an increase of 14.3% from one year ago. |

[0000926326-18-000003:8k_2_02:32]
2018 Guidance:

[0000926326-18-000003:8k_2_02:33]
For 2018, we will adopt ASU 2014-09 Revenue from Contracts with Customers, which impacts the timing of revenue recognition and requires the presentation of certain costs previously reported as selling expenses as a reduction of revenue, both of which are not anticipated to be material. The reclassification of selling costs will result in a reduction of net sales, but has no impact on operating income or net earnings.

[0000926326-18-000003:8k_2_02:34]
For the first quarter of 2018, the Company expects non-GAAP revenue to be between $174 million and $179 million, which includes the impact of reclassification of selling costs as a reduction of revenue. The Company expects first quarter of 2018 non-GAAP earnings to be between $0.22 and $0.28 per share.

[0000926326-18-000003:8k_2_02:35]
For the year 2018, the Company expects product bookings to be between $625 million and $660 million.

[0000926326-18-000003:8k_2_02:36]
The Company expects non-GAAP revenue to be between $780 million and $800 million, which includes the impact of reclassification of selling costs as a reduction of revenue, and non-GAAP earnings to be between $1.85 and $2.05 per share.

[0000926326-18-000003:8k_2_02:37]
The table below summarizes Omnicell's 2018 guidance outlined above:

[0000926326-18-000003:8k_2_02:38]
|  | Q1'18 | Total Year 2018 |
| Product Bookings | Not provided | $625 million - $660 million |
| Non-GAAP Revenue | $174 million - $179 million | $780 million - $800 million |
| Non-GAAP EPS | $0.22 - $0.28 | $1.85 - $2.05 |

[0000926326-18-000003:8k_2_02:39]
Omnicell Conference Call Information

[0000926326-18-000003:8k_2_02:40]
Omnicell will hold a conference call today, Thursday, February 1, 2018 at 1:30 p.m. PT to discuss fourth quarter financial results. The conference call can be monitored by dialing 1-800-696-5518 within the U.S. or 1-706-758-4883 for all other locations. The Conference ID # is 3791479. Internet users can access the conference call at http://ir.omnicell.com/events.cfm. A replay of the call will be available today at approximately 4:30 p.m. PT and will be available until 11:59 p.m. PT on March 15, 2018. The replay access numbers are 1-855-859-2056 within the U.S. and 1-404-537-3406 for all other locations, Conference ID # is 3791479.

[0000926326-18-000003:8k_2_02:41]
About Omnicell

[0000926326-18-000003:8k_2_02:42]
Since 1992, Omnicell (NASDAQ: OMCL) has been inspired to create safer and more efficient ways to manage medications and supplies across all care settings. As a leader in medication and supply dispensing automation, central pharmacy automation, IV robotics, analytics software, and medication adherence and packaging systems, Omnicell is focused on improving care across the entire healthcare continuum-from the acute care hospital setting, to post-acute skilled nursing and long-term care facilities, to the patient’s home.

[0000926326-18-000003:8k_2_02:43]
Approximately 4,000 customers worldwide use Omnicell® automation and analytics solutions to increase operational efficiency, reduce medication errors, deliver actionable intelligence and improve patient safety.

[0000926326-18-000003:8k_2_02:44]
Omnicell’s innovative medication adherence solutions, used by over 32,000 institutional and retail pharmacies in North America and the United Kingdom, are designed to improve patient adherence to prescriptions, helping to reduce costly hospital readmissions.

[0000926326-18-000003:8k_2_02:45]
Recent Omnicell acquisitions add distinct capabilities, particularly in central pharmacy, IV robotics, and pharmacy software, creating the broadest medication management product portfolio in the industry.

[0000926326-18-000003:8k_2_02:46]
For more information about Omnicell, Inc. please visit www.omnicell.com.

[0000926326-18-000003:8k_2_02:47]
Forward-Looking Statements

[0000926326-18-000003:8k_2_02:48]
Use of Non-GAAP Financial Information

[0000926326-18-000003:8k_2_02:49]
This press release contains financial measures that are not calculated in accordance with GAAP. Our management evaluates and makes operating decisions using various performance measures. In addition to Omnicell’s GAAP results, we also consider non-GAAP revenue, non-GAAP gross profit, non-GAAP operating expenses, non-GAAP net income, and non-GAAP net income per diluted share. Additionally, we calculate Adjusted EBITDA (another non-GAAP measure) by means of adjustments to GAAP Net Income. These non-GAAP results should not be considered as an alternative to gross profit, operating expenses, net income, net income per diluted share, or any other performance measure derived in accordance with GAAP. We present these non-GAAP results because we consider them to be important supplemental measures of Omnicell’s performance.

[0000926326-18-000003:8k_2_02:50]
Our non-GAAP revenue, non-GAAP gross profit, non-GAAP operating expenses, non-GAAP net income and non-GAAP net income per diluted share are exclusive of certain items to facilitate management’s review of the comparability of Omnicell’s core operating results on a period to period basis because such items are not related to Omnicell’s ongoing core operating results as viewed by management. We define our “core operating results” as those revenues recorded in a particular period and the expenses incurred within that period that directly drive operating income in that period. Management uses these non-GAAP financial measures in making operating decisions because, in addition to meaningful supplemental information regarding operating performance, the measures give us a better understanding of how we should invest in research and development, fund infrastructure growth and evaluate the effectiveness of marketing strategies. In calculating the above non-GAAP results, management specifically adjusted for the following excluded items:

[0000926326-18-000003:8k_2_02:51]
a)  Share-based compensation expense. We excluded from our non-GAAP results the expense related to equity-based compensation plans as they represent expenses that do not require cash settlement from Omnicell.

[0000926326-18-000003:8k_2_02:52]
b) Amortization of acquired intangible assets. We excluded from our non-GAAP results the intangible assets amortization expense resulting from our past acquisitions. These non-cash charges are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results.

[0000926326-18-000003:8k_2_02:53]
c) Amortization of debt issuance cost. Debt issuance cost represents costs associated with the issuance of Term Loan and Revolving Line of Credit facilities. The cost includes underwriting fees, original issue discount, ticking fee, and legal fees. This non-cash expense is not considered by management to reflect the core cash-generating performance of the business and therefore is excluded from our non-GAAP results.

[0000926326-18-000003:8k_2_02:54]
d) Acquisition accounting impact related to deferred revenue. In connection with recent acquisitions, business combination rules require us to account for the fair values of arrangements for which acceptance has not been obtained, and post installation support has not been provided in our purchase accounting. The non-GAAP adjustment to our revenues is intended to include the full amounts of such revenues. We believe the adjustment to these revenues is useful as a measure of the ongoing performance of our business.

[0000926326-18-000003:8k_2_02:55]
e) Inventory fair value adjustments. In connection with the acquisition of Aesynt, business combination rules require us to account for the fair values of inventory acquired in our purchase accounting. The non-GAAP adjustment to the cost of revenues is intended to include the impact of such adjustment. We believe the adjustment is useful as a measure of the ongoing performance of our business.

[0000926326-18-000003:8k_2_02:56]
f) Acquisition related expenses. We excluded from the non-GAAP results the expenses which are related to recent acquisitions. These expenses are unrelated to our ongoing operations and we do not expect them to occur in the ordinary course of business. We believe that excluding these acquisition related expenses provides more meaningful comparisons of the financial results to our historical operations and forward looking guidance and the financial results of less acquisitive peer companies.

[0000926326-18-000003:8k_2_02:57]
g) Severance and other related expenses. We excluded from our non-GAAP results the expenses which are related to restructuring and integrations related events. These expenses are unrelated to our ongoing operations and we do not expect them to occur in the ordinary course of business. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward looking guidance and the financial results of peer companies.

[0000926326-18-000003:8k_2_02:58]
h) Tax reform impact. We excluded from our non-GAAP results the net one-time benefits related to the Tax Cuts and Jobs Act of 2017 based on the estimated impact of the revaluation of deferred tax assets and liabilities. These net benefits are unrelated to our ongoing operations and we do not expect them to occur in the ordinary course of business. We believe that excluding these net benefits provides more meaningful comparisons of the financial results to our historical operations and forward looking guidance and the financial results of peer companies.

[0000926326-18-000003:8k_2_02:59]
Management adjusts for the above items because management believes that, in general, these items possess one or more of the following characteristics: their magnitude and timing is largely outside of Omnicell’s control; they are unrelated to the ongoing

[0000926326-18-000003:8k_2_02:60]
operation of the business in the ordinary course; they are unusual and we do not expect them to occur in the ordinary course of business; or they are non-operational, or non-cash expenses involving stock compensation plans or other items.

[0000926326-18-000003:8k_2_02:61]
We believe that the presentation of these non-GAAP financial measures is warranted for several reasons:

[0000926326-18-000003:8k_2_02:62]
1) Such non-GAAP financial measures provide an additional analytical tool for understanding Omnicell’s financial performance by excluding the impact of items which may obscure trends in the core operating results of the business;

[0000926326-18-000003:8k_2_02:63]
2) Since we have historically reported non-GAAP results to the investment community, we believe the inclusion of non-GAAP numbers provides consistency and enhances investors’ ability to compare our performance across financial reporting periods;

[0000926326-18-000003:8k_2_02:64]
3) These non-GAAP financial measures are employed by Omnicell’s management in its own evaluation of performance and are utilized in financial and operational decision making processes, such as budget planning and forecasting; and

[0000926326-18-000003:8k_2_02:65]
4) These non-GAAP financial measures facilitate comparisons to the operating results of other companies in our industry, which use similar financial measures to supplement their GAAP results, thus enhancing the perspective of investors who wish to utilize such comparisons in their analysis of our performance.

[0000926326-18-000003:8k_2_02:66]
Set forth below are additional reasons why share-based compensation expense is excluded from our non-GAAP financial measures:

[0000926326-18-000003:8k_2_02:67]
i)  While share-based compensation calculated in accordance with ASC 718 constitutes an ongoing and recurring expense of Omnicell, it is not an expense that requires cash settlement by Omnicell. We therefore exclude these charges for purposes of evaluating core operating results. Thus, our non-GAAP measurements are presented exclusive of stock-based compensation expense to assist management and investors in evaluating our core operating results.

[0000926326-18-000003:8k_2_02:68]
ii) We present ASC 718 share-based payment compensation expense in our reconciliation of non-GAAP financial measures on a pre-tax basis because the exact tax differences related to the timing and deductibility of share-based compensation, under ASC 718 are dependent upon the trading price of Omnicell’s common stock and the timing and exercise by employees of their stock options. As a result of these timing and market uncertainties the tax effect related to share-based compensation expense would be inconsistent in amount and frequency and is therefore excluded from our non-GAAP results.

[0000926326-18-000003:8k_2_02:69]
Our Adjusted EBITDA calculation is defined as earnings before interest income and expense, taxes, depreciation and amortization, and non-cash expenses, including ASC 718 stock compensation expense, as well as certain non-GAAP adjustments.

[0000926326-18-000003:8k_2_02:70]
As stated above, we present non-GAAP financial measures because we consider them to be important supplemental measures of performance. However, non-GAAP financial measures have limitations as an analytical tool and should not be considered in isolation or as a substitute for Omnicell’s GAAP results. In the future, we expect to incur expenses similar to certain of the non-GAAP adjustments described above and expect to continue reporting non-GAAP financial measures excluding such items. Some of the limitations in relying on non-GAAP financial measures are:

[0000926326-18-000003:8k_2_02:71]
| • | Omnicell’s stock option and stock purchase plans are important components of incentive compensation arrangements and will be reflected as expenses in Omnicell’s GAAP results for the foreseeable future under ASC 718. |

[0000926326-18-000003:8k_2_02:72]
| • | Other companies, including companies in Omnicell’s industry, may calculate non-GAAP financial measures differently than Omnicell, limiting their usefulness as a comparative measure. |

[0000926326-18-000003:8k_2_02:73]
Pursuant to the requirements of SEC Regulation G, a detailed reconciliation between Omnicell’s non-GAAP and GAAP financial results is set forth in the financial tables at the end of this press release. Investors are advised to carefully review and consider this information strictly as a supplement to the GAAP results that are contained in this press release and in Omnicell’s SEC filings.

[0000926326-18-000003:8k_2_02:74]
With respect to the Company’s expectations under “Guidance” above, and regarding certain projections discussed on today’s teleconference, reconciliation of non-GAAP earnings ranges per share guidance for 2018, to the closest corresponding GAAP measures is not available without unreasonable efforts as we are unable to predict with reasonable certainty the matters we would allocate to “certain items,” including unusual gains and losses, costs associated with future restructurings,  acquisition-related expenses and litigation outcomes. These items are uncertain, complex, depend on various factors, have low visibility and could have a material impact on GAAP EPS in future periods.

[0000926326-18-000003:8k_2_02:75]
5

[0000926326-18-000003:8k_2_02:76]
Omnicell, Inc.

[0000926326-18-000003:8k_2_02:77]
Condensed Consolidated Statements of Operations

[0000926326-18-000003:8k_2_02:78]
(Unaudited, in thousands, except per share data)

[0000926326-18-000003:8k_2_02:79]
|  | Three Months Ended |  | Years Ended |
|  | December 31, 2017 |  | September 30, 2017 |  | December 31, 2016 |  | December 31, 2017 |  | December 31, 2016 |
| Revenues: |  |  |  |  |  |  |  |  |  |
| Product | $ | 144,120 |  |  | $ | 135,103 |  |  | $ | 125,753 |  |  | $ | 506,209 |  |  | $ | 517,944 |  |
| Services and other revenues | 53,824 |  |  | 51,679 |  |  | 46,221 |  |  | 209,956 |  |  | 174,679 |  |
| Total revenues | 197,944 |  |  | 186,782 |  |  | 171,974 |  |  | 716,165 |  |  | 692,623 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |
| Cost of product revenues | 79,791 |  |  | 79,725 |  |  | 78,024 |  |  | 304,842 |  |  | 302,437 |  |
| Cost of services and other revenues | 23,085 |  |  | 22,204 |  |  | 19,621 |  |  | 89,235 |  |  | 76,386 |  |
| Total cost of revenues | 102,876 |  |  | 101,929 |  |  | 97,645 |  |  | 394,077 |  |  | 378,823 |  |
| Gross profit | 95,068 |  |  | 84,853 |  |  | 74,329 |  |  | 322,088 |  |  | 313,800 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | 15,894 |  |  | 16,414 |  |  | 14,902 |  |  | 66,022 |  |  | 57,799 |  |
| Selling, general and administrative | 63,494 |  |  | 58,725 |  |  | 59,608 |  |  | 250,312 |  |  | 249,520 |  |
| Total operating expenses | 79,388 |  |  | 75,139 |  |  | 74,510 |  |  | 316,334 |  |  | 307,319 |  |
| Income (loss) from operations | 15,680 |  |  | 9,714 |  |  | (181 | ) |  | 5,754 |  |  | 6,481 |  |
| Interest and other income (expense), net | (1,641 | ) |  | (2,732 | ) |  | (1,656 | ) |  | (6,633 | ) |  | (8,429 | ) |
| Income (loss) before provision for income taxes | 14,039 |  |  | 6,982 |  |  | (1,837 | ) |  | (879 | ) |  | (1,948 | ) |
| Provision (benefit) for income taxes | (10,252 | ) |  | 751 |  |  | (1,994 | ) |  | (21,484 | ) |  | (2,551 | ) |
| Net income | $ | 24,291 |  |  | $ | 6,231 |  |  | $ | 157 |  |  | $ | 20,605 |  |  | $ | 603 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |
| Basic | $ | 0.64 |  |  | $ | 0.17 |  |  | $ | — |  |  | $ | 0.55 |  |  | $ | 0.02 |  |
| Diluted | $ | 0.62 |  |  | $ | 0.16 |  |  | $ | — |  |  | $ | 0.53 |  |  | $ | 0.02 |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |  |  |
| Basic | 38,127 |  |  | 37,698 |  |  | 36,553 |  |  | 37,483 |  |  | 36,156 |  |
| Diluted | 39,482 |  |  | 38,973 |  |  | 37,256 |  |  | 38,712 |  |  | 36,864 |  |

[0000926326-18-000003:8k_2_02:80]
6

[0000926326-18-000003:8k_2_02:81]
Omnicell, Inc.

[0000926326-18-000003:8k_2_02:82]
Condensed Consolidated Balance Sheets

[0000926326-18-000003:8k_2_02:83]
(Unaudited, in thousands)

[0000926326-18-000003:8k_2_02:84]
|  | December 31, |
|  | 2017 |  | 2016 |
| ASSETS |
| Current assets: |  |  |  |  |
| Cash and cash equivalents | $ | 32,424 |  |  | $ | 54,488 |  |
| Accounts receivable, net | 189,227 |  |  | 150,303 |  |
| Inventories | 96,137 |  |  | 69,297 |  |
| Prepaid expenses | 36,060 |  |  | 28,646 |  |
| Other current assets | 13,273 |  |  | 12,674 |  |
| Total current assets | 367,121 |  |  | 315,408 |  |
| Property and equipment, net | 42,595 |  |  | 42,011 |  |
| Long-term investment in sales-type leases, net | 15,435 |  |  | 20,585 |  |
| Goodwill | 337,751 |  |  | 327,724 |  |
| Intangible assets, net | 168,107 |  |  | 190,283 |  |
| Long-term deferred tax assets | 9,454 |  |  | 4,041 |  |
| Other long-term assets | 39,841 |  |  | 35,051 |  |
| Total assets | $ | 980,304 |  |  | $ | 935,103 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |
| Accounts payable | $ | 48,290 |  |  | $ | 27,069 |  |
| Accrued compensation | 27,241 |  |  | 26,722 |  |
| Accrued liabilities | 35,693 |  |  | 31,195 |  |
| Long-term debt, current portion, net | 15,208 |  |  | 8,410 |  |
| Deferred revenue, net | 86,104 |  |  | 87,516 |  |
| Total current liabilities | 212,536 |  |  | 180,912 |  |
| Long-term, deferred revenue | 17,244 |  |  | 17,051 |  |
| Long-term deferred tax liabilities | 28,579 |  |  | 51,592 |  |
| Other long-term liabilities | 9,829 |  |  | 8,210 |  |
| Long-term debt, net | 194,917 |  |  | 245,731 |  |
| Total liabilities | 463,105 |  |  | 503,496 |  |
| Stockholders’ equity: |  |  |  |  |  |
| Total stockholders’ equity | 517,199 |  |  | 431,607 |  |
| Total liabilities and stockholders’ equity | $ | 980,304 |  |  | $ | 935,103 |  |

[0000926326-18-000003:8k_2_02:85]
Omnicell, Inc.

[0000926326-18-000003:8k_2_02:86]
Condensed Consolidated Statements of Cash Flows

[0000926326-18-000003:8k_2_02:87]
(Unaudited, in thousands)

[0000926326-18-000003:8k_2_02:88]
|  | Year Ended December 31, |
|  | 2017 |  | 2016 |
| Operating Activities |  |  |  |
| Net income | $ | 20,605 |  |  | $ | 603 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 51,511 |  |  | 58,362 |  |
| Loss on disposal of fixed assets | 512 |  |  | 35 |  |
| Gain related to contingent liability | — |  |  | (600 | ) |
| Share-based compensation expense | 21,857 |  |  | 19,500 |  |
| Income tax benefits from employee stock plans | 11 |  |  | 1,703 |  |
| Deferred income taxes | (26,844 | ) |  | (10,882 | ) |
| Amortization of debt financing fees | 1,590 |  |  | 1,590 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable | (39,068 | ) |  | 8,047 |  |
| Inventories | (26,840 | ) |  | (3,362 | ) |
| Prepaid expenses | (7,414 | ) |  | (4,321 | ) |
| Other current assets | (2,074 | ) |  | (1,093 | ) |
| Investment in sales-type leases | 6,625 |  |  | (9,639 | ) |
| Other long-term assets | (98 | ) |  | 2,043 |  |
| Accounts payable | 19,709 |  |  | (4,963 | ) |
| Accrued compensation | 519 |  |  | (2,052 | ) |
| Accrued liabilities | 4,383 |  |  | (3,287 | ) |
| Deferred revenue | (1,219 | ) |  | 4,480 |  |
| Other long-term liabilities | 1,069 |  |  | (6,264 | ) |
| Net cash provided by operating activities | 24,834 |  |  | 49,900 |  |
| Investing Activities |  |  |  |
| Purchase of intangible assets, intellectual property and patents | (160 | ) |  | (1,372 | ) |
| Software development for external use | (15,040 | ) |  | (14,348 | ) |
| Purchases of property and equipment | (15,341 | ) |  | (13,445 | ) |
| Business acquisitions, net of cash acquired | (4,446 | ) |  | (312,158 | ) |
| Net cash used in investing activities | (34,987 | ) |  | (341,323 | ) |
| Financing Activities |  |  |  |
| Proceeds from debt, net | 56,894 |  |  | 287,051 |  |
| Repayment of debt and revolving credit facility | (102,500 | ) |  | (34,500 | ) |
| Payment for contingent consideration | (2,400 | ) |  | (3,000 | ) |
| At the market offering, net of offering costs | 13,900 |  |  | — |  |
| Proceeds from issuances under stock-based compensation plans | 30,121 |  |  | 17,691 |  |
| Employees' taxes paid related to restricted stock units | (5,892 | ) |  | (3,490 | ) |
| Net cash provided by (used in) financing activities | (9,877 | ) |  | 263,752 |  |
| Effect of exchange rate changes on cash and cash equivalents | (2,034 | ) |  | (58 | ) |
| Net decrease in cash and cash equivalents | (22,064 | ) |  | (27,729 | ) |
| Cash and cash equivalents at beginning of period | 54,488 |  |  | 82,217 |  |
| Cash and cash equivalents at end of period | $ | 32,424 |  |  | $ | 54,488 |  |

[0000926326-18-000003:8k_2_02:89]
8

[0000926326-18-000003:8k_2_02:90]
Omnicell, Inc.

[0000926326-18-000003:8k_2_02:91]
Reconciliation of GAAP to Non-GAAP

[0000926326-18-000003:8k_2_02:92]
(Unaudited, in thousands, except per share data and percentages)

[0000926326-18-000003:8k_2_02:93]
|  |  |  |  |  |  | Three Months Ended |  | Twelve Months Ended |
|  |  |  |  |  |  | December 31, 2017 |  | September 30, 2017 |  | December 31, 2016 |  | December 31, 2017 |  | December 31, 2016 |
| Reconciliation of GAAP revenue to non-GAAP revenue: |  |  |  |  |  |  |
| GAAP revenue |  | $ | 197,944 |  |  | $ | 186,782 |  |  | $ | 171,974 |  |  | $ | 716,165 |  |  | $ | 692,623 |  |
|  | Acquisition accounting impact related to deferred revenue | 313 |  |  | 313 |  |  | 2,663 |  |  | 1,252 |  |  | 10,652 |  |
| Non-GAAP revenue | $ | 198,257 |  |  | $ | 187,095 |  |  | $ | 174,637 |  |  | $ | 717,417 |  |  | $ | 703,275 |  |
| Reconciliation of GAAP gross profit to non-GAAP gross profit: |  |  |  |  |  |  |
| GAAP gross profit | $ | 95,068 |  |  | $ | 84,853 |  |  | $ | 74,329 |  |  | $ | 322,088 |  |  | $ | 313,800 |  |
| GAAP gross margin | 48.0% |  | 45.4% |  | 43.2% |  | 45.0% |  | 45.3% |
|  | Share-based compensation expense | 834 |  |  | 882 |  |  | 776 |  |  | 3,562 |  |  | 2,596 |  |
|  | Amortization of acquired intangibles | 2,818 |  |  | 2,985 |  |  | 5,266 |  |  | 11,488 |  |  | 20,890 |  |
|  | Acquisition accounting impact related to deferred revenue | 313 |  |  | 313 |  |  | 2,663 |  |  | 1,252 |  |  | 10,652 |  |
|  | Inventory fair value adjustments | — |  |  | — |  |  | 921 |  |  | — |  |  | 3,682 |  |
|  | Acquisition related expenses | — |  |  | — |  |  | 5 |  |  | — |  |  | 277 |  |
|  | Severance and other expenses* | 234 |  |  | 70 |  |  | — |  |  | 2,001 |  |  | — |  |
| Non-GAAP gross profit | $ | 99,267 |  |  | $ | 89,103 |  |  | $ | 83,960 |  |  | $ | 340,391 |  |  | $ | 351,897 |  |
| Non-GAAP gross margin | 50.1% |  | 47.6% |  | 48.1% |  | 47.4% |  | 50.0% |
| Reconciliation of GAAP operating expenses to non-GAAP operating expenses: |  |  |  |  |
| GAAP operating expenses | $ | 79,388 |  |  | $ | 75,139 |  |  | $ | 74,510 |  |  | $ | 316,334 |  |  | $ | 307,319 |  |
| GAAP operating expenses % to total revenue |  | 40.1% |  | 40.2% |  | 43.3% |  | 44.2% |  | 44.4% |
|  | Share-based compensation expense | (4,708 | ) |  | (4,377 | ) |  | (4,663 | ) |  | (18,295 | ) |  | (16,904 | ) |
|  | Amortization of acquired intangibles | (3,348 | ) |  | (3,381 | ) |  | (3,752 | ) |  | (14,008 | ) |  | (15,251 | ) |
|  | Acquisition related expenses | — |  |  | — |  |  | (829 | ) |  | (126 | ) |  | (5,753 | ) |
|  | Severance and other expenses* | (233 | ) |  | (229 | ) |  | — |  |  | (3,764 | ) |  | — |  |
| Non-GAAP operating expenses | $ | 71,099 |  |  | $ | 67,152 |  |  | $ | 65,266 |  |  | $ | 280,141 |  |  | $ | 269,411 |  |
| Non-GAAP operating expenses % to total revenue | 35.9% |  | 35.9% |  | 37.4% |  | 39.0% |  | 38.3% |

[0000926326-18-000003:8k_2_02:94]
* Other expenses include relocation charge of $578, restructuring rent expense of $510, integration consulting expense of $201 and depreciation adjustment related to purchase price allocation from acquisition of $1,013 for the year ended December 31, 2017.

[0000926326-18-000003:8k_2_02:95]
|  |  |  |  |  |  | Three Months Ended |  | Twelve Months Ended |
|  |  |  |  |  |  | December 31, 2017 |  | September 30, 2017 |  | December 31, 2016 |  | December 31, 2017 |  | December 31, 2016 |
| Reconciliation of GAAP income (loss) from operations to non-GAAP income from operations: |  |  |  |  |
| GAAP income (loss) from operations |  | $ | 15,680 |  |  | $ | 9,714 |  |  | $ | (181 | ) |  | $ | 5,754 |  |  | $ | 6,481 |  |
| GAAP operating income % to total revenue |  | 7.9% |  | 5.2% |  | (0.1)% |  | 0.8% |  | 0.9% |
|  | Share-based compensation expense | 5,542 |  |  | 5,259 |  |  | 5,438 |  |  | 21,857 |  |  | 19,500 |  |
|  | Amortization of acquired intangibles | 6,166 |  |  | 6,366 |  |  | 9,017 |  |  | 25,496 |  |  | 36,141 |  |
|  | Acquisition accounting impact related to deferred revenue | 313 |  |  | 313 |  |  | 2,663 |  |  | 1,252 |  |  | 10,652 |  |
|  | Inventory fair value adjustments | — |  |  | — |  |  | 921 |  |  | — |  |  | 3,682 |  |
|  | Acquisition related expenses | — |  |  | — |  |  | 834 |  |  | 126 |  |  | 6,029 |  |
|  | Severance and other expenses | 467 |  |  | 299 |  |  | — |  |  | 5,765 |  |  | — |  |
| Non-GAAP income from operations | $ | 28,168 |  |  | $ | 21,951 |  |  | $ | 18,692 |  |  | $ | 60,250 |  |  | $ | 82,485 |  |
| Non-GAAP operating income % to total Non-GAAP revenue | 14.2% |  | 11.7% |  | 10.7% |  | 8.4% |  | 11.7% |
| Reconciliation of GAAP net income to non-GAAP net income: |  |  |  |  |  |  |
| GAAP net income | $ | 24,291 |  |  | $ | 6,231 |  |  | $ | 157 |  |  | $ | 20,605 |  |  | $ | 603 |  |
|  | Tax reform benefit impact | (13,391 | ) |  | — |  |  | — |  |  | (13,391 | ) |  | — |  |
|  | Share-based compensation expense | 5,542 |  |  | 5,259 |  |  | 5,438 |  |  | 21,857 |  |  | 19,500 |  |
|  | Amortization of acquired intangibles | 6,166 |  |  | 6,366 |  |  | 9,017 |  |  | 25,496 |  |  | 36,141 |  |
|  | Acquisition accounting impact related to deferred revenue | 313 |  |  | 313 |  |  | 2,663 |  |  | 1,252 |  |  | 10,652 |  |
|  | Inventory fair value adjustments | — |  |  | — |  |  | 921 |  |  | — |  |  | 3,682 |  |
|  | Acquisition related expenses | 397 |  |  | 397 |  |  | 632 |  |  | 1,715 |  |  | 7,019 |  |
|  | Severance and other expenses | 467 |  |  | 299 |  |  | — |  |  | 5,765 |  |  | — |  |
|  | Tax effect of the adjustments above(a) | (2,570 | ) |  | (2,579 | ) |  | (5,031 | ) |  | (11,980 | ) |  | (21,850 | ) |
| Non-GAAP net income | $ | 21,215 |  |  | $ | 16,286 |  |  | $ | 13,797 |  |  | $ | 51,319 |  |  | $ | 55,747 |  |
| Reconciliation of GAAP net income per share - diluted to non-GAAP net income per share - diluted: |  |  |
| Shares - diluted GAAP | 39,482 |  |  | 38,973 |  |  | 37,256 |  |  | 38,712 |  |  | 36,864 |  |
| Shares - diluted Non-GAAP | 39,482 |  |  | 38,973 |  |  | 37,256 |  |  | 38,712 |  |  | 36,864 |  |
| GAAP net income per share - diluted | $ | 0.62 |  |  | $ | 0.16 |  |  | $ | — |  |  | $ | 0.53 |  |  | $ | 0.02 |  |
|  | Tax reform benefit impact | (0.34 | ) |  | — |  |  | — |  |  | (0.35 | ) |  | — |  |
|  | Share-based compensation expense | 0.14 |  |  | 0.14 |  |  | 0.15 |  |  | 0.56 |  |  | 0.53 |  |
|  | Amortization of acquired intangibles | 0.16 |  |  | 0.16 |  |  | 0.24 |  |  | 0.67 |  |  | 0.98 |  |
|  | Acquisition accounting impact related to deferred revenue | 0.01 |  |  | 0.01 |  |  | 0.07 |  |  | 0.03 |  |  | 0.29 |  |
|  | Inventory fair value adjustments | — |  |  | — |  |  | 0.02 |  |  | — |  |  | 0.10 |  |
|  | Acquisition related expenses | 0.01 |  |  | 0.01 |  |  | 0.02 |  |  | 0.04 |  |  | 0.19 |  |
|  | Severance and other expenses | 0.01 |  |  | 0.01 |  |  | — |  |  | 0.16 |  |  | — |  |
|  | Tax effect of the adjustments above(a) | (0.07 | ) |  | (0.07 | ) |  | (0.13 | ) |  | (0.31 | ) |  | (0.60 | ) |
| Non-GAAP net income per share - diluted | $ | 0.54 |  |  | $ | 0.42 |  |  | $ | 0.37 |  |  | $ | 1.33 |  |  | $ | 1.51 |  |
| Reconciliation of GAAP net income to non-GAAP Adjusted EBITDA: |  |  |  |  |  |  |
| GAAP net income | $ | 24,291 |  |  | $ | 6,231 |  |  | $ | 157 |  |  | $ | 20,605 |  |  | $ | 603 |  |
|  | Share-based compensation expense | 5,542 |  |  | 5,259 |  |  | 5,438 |  |  | 21,857 |  |  | 19,500 |  |
|  | Interest (income) and expense, net | 1,202 |  |  | 2,127 |  |  | 998 |  |  | 6,072 |  |  | 5,616 |  |
|  | Depreciation and amortization expense | 12,969 |  |  | 12,600 |  |  | 14,457 |  |  | 51,511 |  |  | 58,362 |  |
|  | Acquisition accounting impact related to deferred revenue | 313 |  |  | 313 |  |  | 2,663 |  |  | 1,252 |  |  | 10,652 |  |
|  | Inventory fair value adjustments | — |  |  | — |  |  | 921 |  |  | — |  |  | 3,682 |  |
|  | Acquisition related expenses | 397 |  |  | 397 |  |  | 632 |  |  | 1,715 |  |  | 7,019 |  |
|  | Severance and other expenses | 213 |  |  | 46 |  |  | — |  |  | 4,752 |  |  | — |  |
|  | Income tax expense (benefit) | (10,252 | ) |  | 751 |  |  | (1,994 | ) |  | (21,484 | ) |  | (2,551 | ) |
| Non-GAAP Adjusted EBITDA (b) | $ | 34,675 |  |  | $ | 27,724 |  |  | $ | 23,272 |  |  | $ | 86,280 |  |  | $ | 102,883 |  |

[0000926326-18-000003:8k_2_02:96]
_____________________

[0000926326-18-000003:8k_2_02:97]
10

[0000926326-18-000003:8k_2_02:98]
(a)Tax effects calculated for all adjustments except share-based compensation expense and tax reform benefit, using the tax rate of 35%.

[0000926326-18-000003:8k_2_02:99]
(b)Defined as earnings before interest income and expense, taxes, depreciation and amortization, share-based compensation expense, as well as excluding certain non-GAAP adjustments.

[0000926326-18-000003:8k_2_02:100]
11

[0000926326-18-000003:8k_2_02:101]
Omnicell, Inc.

[0000926326-18-000003:8k_2_02:102]
Segmented Information

[0000926326-18-000003:8k_2_02:103]
(Unaudited, in thousands, except for percentages)

[0000926326-18-000003:8k_2_02:104]
|  | Three Months Ended December 31, 2017 |  | Three Months Ended December 31, 2016 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |  | Automation andAnalytics |  | MedicationAdherence |  | Total |
| Revenues | $ | 163,142 |  |  | $ | 34,802 |  |  | $ | 197,944 |  |  | $ | 143,583 |  |  | $ | 28,391 |  |  | $ | 171,974 |  |
| Cost of revenues | 79,225 |  |  | 23,651 |  |  | 102,876 |  |  | 77,566 |  |  | 20,079 |  |  | 97,645 |  |
| Gross profit | 83,917 |  |  | 11,151 |  |  | 95,068 |  |  | 66,017 |  |  | 8,312 |  |  | 74,329 |  |
| Gross margin % | 51.4% |  | 32.0% |  | 48.0% |  | 46.0% |  | 29.3% |  | 43.2% |
| Operating expenses | 47,049 |  |  | 10,539 |  |  | 57,588 |  |  | 47,402 |  |  | 7,325 |  |  | 54,727 |  |
| Income from segment operations | $ | 36,868 |  |  | $ | 612 |  |  | $ | 37,480 |  |  | $ | 18,615 |  |  | $ | 987 |  |  | $ | 19,602 |  |
| Operating margin % | 22.6% |  | 1.8% |  | 18.9% |  | 13.0% |  | 3.5% |  | 11.4% |
| Corporate costs |  |  |  |  | 21,800 |  |  |  |  |  |  | 19,783 |  |
| Income (loss) from operations |  |  |  |  | $ | 15,680 |  |  |  |  |  |  | $ | (181 | ) |

[0000926326-18-000003:8k_2_02:105]
Omnicell, Inc.

[0000926326-18-000003:8k_2_02:106]
Segmented Information

[0000926326-18-000003:8k_2_02:107]
(Unaudited, in thousands, except for percentages)

[0000926326-18-000003:8k_2_02:108]
|  | Year Ended December 31, 2017 |  | Year Ended December 31, 2016 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |  | Automation andAnalytics |  | MedicationAdherence |  | Total |
| Revenues | $ | 590,392 |  |  | $ | 125,773 |  |  | $ | 716,165 |  |  | $ | 593,626 |  |  | $ | 98,997 |  |  | $ | 692,623 |  |
| Cost of revenues | 308,443 |  |  | 85,634 |  |  | 394,077 |  |  | 310,967 |  |  | 67,856 |  |  | 378,823 |  |
| Gross profit | 281,949 |  |  | 40,139 |  |  | 322,088 |  |  | 282,659 |  |  | 31,141 |  |  | 313,800 |  |
| Gross margin % | 47.8% |  | 31.9% |  | 45.0% |  | 47.6% |  | 31.5% |  | 45.3% |
| Operating expenses | 193,700 |  |  | 41,735 |  |  | 235,435 |  |  | 198,511 |  |  | 24,843 |  |  | 223,354 |  |
| Income from segment operations | $ | 88,249 |  |  | $ | (1,596 | ) |  | $ | 86,653 |  |  | $ | 84,148 |  |  | $ | 6,298 |  |  | $ | 90,446 |  |
| Operating margin % | 14.9% |  | (1.3)% |  | 12.1% |  | 14.2% |  | 6.4% |  | 13.1% |
| Corporate costs |  |  |  |  | 80,899 |  |  |  |  |  |  | 83,965 |  |
| Income from operations |  |  |  |  | $ | 5,754 |  |  |  |  |  |  | $ | 6,481 |  |

[0000926326-18-000003:8k_2_02:109]
13

[0000926326-18-000003:8k_2_02:110]
Omnicell, Inc.

[0000926326-18-000003:8k_2_02:111]
Segment Information - Non-GAAP Gross Profit and Non-GAAP Operating Margin

[0000926326-18-000003:8k_2_02:112]
(Unaudited, in thousands, except for percentages)

[0000926326-18-000003:8k_2_02:113]
|  | Three Months Ended December 31, 2017 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |
|  | Amount |  | % of GAAP Revenue |  | % of Non-GAAP Revenue |  | Amount |  | % of GAAP Revenue |  | % of Non-GAAP Revenue |  | Amount |  | % of GAAP Revenue |  | % of Non-GAAP Revenue |
| Revenues | $ | 163,142 |  |  |  |  |  |  | $ | 34,802 |  |  |  |  |  |  | $ | 197,944 |  |  |  |  |  |
| Acquisition accounting impact related to deferred revenue | — |  |  | — | % |  | — | % |  | 313 |  |  | 0.9 | % |  | 0.9 | % |  | 313 |  |  | 0.2 | % |  | 0.2 | % |
| Non-GAAP Revenues | $ | 163,142 |  |  |  |  |  |  | $ | 35,115 |  |  |  |  |  |  | $ | 198,257 |  |  |  |  |  |
| GAAP Gross profit | $ | 83,917 |  |  | 51.4 | % |  |  |  | $ | 11,151 |  |  | 32.0 | % |  |  |  | $ | 95,068 |  |  | 48.0 | % |  |  |
| Stock-based compensation expense | 704 |  |  | 0.4 | % |  | 0.4 | % |  | 130 |  |  | 0.4 | % |  | 0.4 | % |  | 834 |  |  | 0.4 | % |  | 0.4 | % |
| Amortization expense of acquired intangible assets | 2,251 |  |  | 1.4 | % |  | 1.4 | % |  | 567 |  |  | 1.6 | % |  | 1.6 | % |  | 2,818 |  |  | 1.4 | % |  | 1.4 | % |
| Acquisition accounting impact related to deferred revenue | — |  |  | — | % |  | — | % |  | 313 |  |  | 0.9 | % |  | 0.9 | % |  | 313 |  |  | 0.2 | % |  | 0.2 | % |
| Severance and other expenses | 234 |  |  | 0.1 | % |  | 0.1 | % |  | — |  |  | — | % |  | — | % |  | 234 |  |  | 0.1 | % |  | 0.1 | % |
| Non-GAAP Gross profit | $ | 87,106 |  |  |  |  | 53.4 | % |  | $ | 12,161 |  |  |  |  | 34.6 | % |  | $ | 99,267 |  |  |  |  | 50.1 | % |
| GAAP Operating income | $ | 36,868 |  |  | 22.6 | % |  |  |  | $ | 612 |  |  | 1.8 | % |  |  |  | $ | 37,480 |  |  | 18.9 | % |  |  |
| Stock-based compensation expense | 2,184 |  |  | 1.3 | % |  | 1.3 | % |  | 376 |  |  | 1.08 | % |  | 1.1 | % |  | 2,560 |  |  | 1.3 | % |  | 1.3 | % |
| Amortization expense of acquired intangible assets | 4,364 |  |  | 2.7 | % |  | 2.7 | % |  | 1,802 |  |  | 5.2 | % |  | 5.1 | % |  | 6,166 |  |  | 3.1 | % |  | 3.1 | % |
| Acquisition accounting impact related to deferred revenue | — |  |  | — | % |  | — | % |  | 313 |  |  | 0.9 | % |  | 0.9 | % |  | 313 |  |  | 0.2 | % |  | 0.2 | % |
| Severance and other expenses | 204 |  |  | 0.1 | % |  | 0.1 | % |  | — |  |  | — | % |  | — | % |  | 204 |  |  | 0.1 | % |  | 0.1 | % |
| Non-GAAP Operating income | $ | 43,620 |  |  |  |  | 26.7 | % |  | $ | 3,103 |  |  |  |  | 8.8 | % |  | $ | 46,723 |  |  |  |  | 23.6 | % |
| GAAP Corporate costs |  |  |  |  |  |  |  |  |  |  |  |  | $ | 21,800 |  |  | 11.0 | % |  |  |
| Less: Stock-based compensation expense |  |  |  |  |  |  |  |  |  |  |  |  | (2,982 | ) |  | (1.5 | )% |  | (1.5 | )% |
| Less: Acquisition-related expenses |  |  |  |  |  |  |  |  |  |  |  |  | (263 | ) |  | (0.1 | )% |  | (0.1 | )% |
| Non-GAAP Corporate costs |  |  |  |  |  |  |  |  |  |  |  |  | $ | 18,555 |  |  |  |  | 9.4 | % |
| Non-GAAP Income from operations |  |  |  |  |  |  |  |  |  |  |  |  | $ | 28,168 |  |  |  |  | 14.2 | % |

[0000926326-18-000003:8k_2_02:114]
Omnicell, Inc.

[0000926326-18-000003:8k_2_02:115]
Segment Information - Non-GAAP Gross Profit and Non-GAAP Operating Margin

[0000926326-18-000003:8k_2_02:116]
(Unaudited, in thousands, except for percentages)

[0000926326-18-000003:8k_2_02:117]
|  | Three Months Ended December 31, 2016 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |
|  | Amount |  | % of GAAP Revenue |  | % of Non-GAAP Revenue |  | Amount |  | % of GAAP Revenue |  | % of Non-GAAP Revenue |  | Amount |  | % of GAAP Revenue |  | % of Non-GAAP Revenue |
| Revenues | $ | 143,583 |  |  |  |  |  |  | $ | 28,391 |  |  |  |  |  |  | $ | 171,974 |  |  |  |  |  |
| Acquisition accounting impact related to deferred revenue | 2,663 |  |  | 1.9 | % |  | 1.8 | % |  | — |  |  | — | % |  | — | % |  | 2,663 |  |  | 1.5 | % |  | 1.5 | % |
| Non-GAAP Revenues | $ | 146,246 |  |  |  |  |  |  | $ | 28,391 |  |  |  |  |  |  | $ | 174,637 |  |  |  |  |  |
| GAAP Gross profit | $ | 66,017 |  |  | 46.0 | % |  |  |  | $ | 8,312 |  |  | 29.3 | % |  |  |  | $ | 74,329 |  |  | 43.2 | % |  |  |
| Stock-based compensation expense | 668 |  |  | 0.5 | % |  | 0.5 | % |  | 108 |  |  | 0.4 | % |  | 0.4 | % |  | 776 |  |  | 0.5 | % |  | 0.4 | % |
| Amortization expense of acquired intangible assets | 4,820 |  |  | 3.4 | % |  | 3.3 | % |  | 446 |  |  | 1.6 | % |  | 1.6 | % |  | 5,266 |  |  | 3.1 | % |  | 3.0 | % |
| Acquisition accounting impact related to deferred revenue | 2,663 |  |  | 1.9 | % |  | 1.8 | % |  | — |  |  | — | % |  | — | % |  | 2,663 |  |  | 1.5 | % |  | 1.5 | % |
| Inventory fair value adjustments | 921 |  |  | 0.6 | % |  | 0.6 | % |  | — |  |  | — | % |  | — | % |  | 921 |  |  | 0.5 | % |  | 0.5 | % |
| Acquisitions related expenses | 5 |  |  | — | % |  | — | % |  | — |  |  | — | % |  | — | % |  | 5 |  |  | — | % |  | — | % |
| Non-GAAP Gross profit | $ | 75,094 |  |  |  |  | 51.3 | % |  | $ | 8,866 |  |  |  |  | 31.2 | % |  | $ | 83,960 |  |  |  |  | 48.1 | % |
| GAAP Operating income | $ | 18,615 |  |  | 13.0 | % |  |  |  | $ | 988 |  |  | 3.5 | % |  |  |  | $ | 19,603 |  |  | 11.4 | % |  |  |
| Stock-based compensation expense | 2,672 |  |  | 1.9 | % |  | 1.8 | % |  | 270 |  |  | 1.0 | % |  | 1.0 | % |  | 2,942 |  |  | 1.7 | % |  | 1.7 | % |
| Amortization expense of acquired intangible assets | 7,494 |  |  | 5.2 | % |  | 5.1 | % |  | 1,523 |  |  | 5.4 | % |  | 5.4 | % |  | 9,017 |  |  | 5.2 | % |  | 5.2 | % |
| Acquisition accounting impact related to deferred revenue | 2,663 |  |  | 1.9 | % |  | 1.8 | % |  | — |  |  | — | % |  | — | % |  | 2,663 |  |  | 1.5 | % |  | 1.5 | % |
| Inventory fair value adjustments | 921 |  |  | 0.6 | % |  | 0.6 | % |  | — |  |  | — | % |  | — | % |  | 921 |  |  | 0.5 | % |  | 0.5 | % |
| Acquisitions related expenses | 23 |  |  | — | % |  | — | % |  | — |  |  | — | % |  | — | % |  | 23 |  |  | — | % |  | — | % |
| Non-GAAP Operating income | $ | 32,388 |  |  |  |  | 22.1 | % |  | $ | 2,781 |  |  |  |  | 9.8 | % |  | $ | 35,169 |  |  |  |  | 20.1 | % |
| GAAP Corporate costs |  |  |  |  |  |  |  |  |  |  |  |  | $ | 19,784 |  |  | 11.5 | % |  |  |
| Less: Stock-based compensation expense |  |  |  |  |  |  |  |  |  |  |  |  | 2,496 |  |  | 1.5 | % |  | 1.4 | % |
| Less: Acquisition-related expenses |  |  |  |  |  |  |  |  |  |  |  |  | 811 |  |  | 0.5 | % |  | 0.5 | % |
| Non-GAAP Corporate costs |  |  |  |  |  |  |  |  |  |  |  |  | $ | 16,477 |  |  |  |  | 9.4 | % |
| Non-GAAP Income from operations |  |  |  |  |  |  |  |  |  |  |  |  | $ | 18,692 |  |  |  |  | 10.7 | % |

[0000926326-18-000003:8k_2_02:118]
15
