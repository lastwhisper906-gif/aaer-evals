# OMCL MD&A — 0000926326-18-000010


## mdna

[0000926326-18-000010:mdna:1]
ITEM 7. MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0000926326-18-000010:mdna:2]
The following discussion and analysis should be read in conjunction with our Consolidated Financial Statements and related notes in this annual report. This discussion may contain forward-looking statements based upon current expectations that involve risks and uncertainties. Our actual results and the timing of selected events could differ materially from those anticipated in these forward-looking statements as a result of several factors, including those set forth under Item 1A "Risk Factors" and elsewhere in this annual report. Unless otherwise stated, references in this report to particular years or quarters refer to our fiscal year and the associated quarters of those fiscal years.

[0000926326-18-000010:mdna:3]
OVERVIEW

[0000926326-18-000010:mdna:4]
Our Business

[0000926326-18-000010:mdna:5]
We are a leading provider of comprehensive automation and business analytics software solutions for patient-centric medication and supply management across the entire healthcare continuum, from the acute care hospital setting to post-acute skilled nursing and long-term care facilities to the home.

[0000926326-18-000010:mdna:6]
We manage our business as two operating segments, Automation and Analytics and Medication Adherence.

[0000926326-18-000010:mdna:7]
| • | Automation and Analytics. The Automation and Analytics segment is organized around the design, manufacturing, selling and servicing of medication and supply dispensing systems, pharmacy inventory management systems, and related software. Our Automation and Analytics products are designed to enable our customers to enhance and improve the effectiveness of the medication-use process, the efficiency of the medical-surgical supply chain, overall patient care and clinical and financial outcomes of medical facilities. Through modular configuration and upgrades, our systems can be tailored to specific customer needs. |

[0000926326-18-000010:mdna:8]
| • | Medication Adherence. The Medication Adherence segment primarily includes the development, manufacturing and selling of solutions to assist patients to remain adherent to their medication regimens. These solutions are comprised of a variety of tools and aids that may be directly used by a pharmacist or a healthcare provider in their direct care for a patient, or the patient themselves, and include software based systems and medication adherence packaging, packaging equipment, and ancillary products and services. These products are used to manage medication administration outside of the hospital setting and include medication adherence products sold under the brand names MTS, SureMed, Ateb, and Omnicell. |

[0000926326-18-000010:mdna:9]
For further description of our operating segments, please refer to Note 14, Segment and Geographical Information, of the Notes to Consolidated Financial Statements in this annual report.

[0000926326-18-000010:mdna:10]
We sell our product and consumable solutions together with related service offerings. Revenue generated in the United States represented 86% of our total revenues in 2017. We have not sold in the past, and have no future plans to sell our products either directly or indirectly, to customers located in countries that are identified as state sponsors of terrorism by the U.S. Department of State, and are subject to economic sanctions and export controls.

[0000926326-18-000010:mdna:11]
Strategy

[0000926326-18-000010:mdna:12]
The healthcare market is experiencing a period of substantive change. The adoption of electronic healthcare records, new regulatory constraints, and changes in the reimbursement structure have caused healthcare institutions to re-examine their operating structures, re-prioritize their investments, and seek efficiencies. We believe our customers’ evolving operating environment creates challenges for any supplier, but also affords opportunities for suppliers that are able to partner with customers to help them meet the changing demands. We have and intend to continue to invest in the strategies which we believe have generated and will continue to generate our revenue and earnings growth, while supporting our customers’ initiatives and needs. These strategies include:

[0000926326-18-000010:mdna:13]
| • | Development of a differentiated platform. We invest in the development of products that we believe bring patient safety and workflow efficiency to our customers’ operations that they cannot get from other competing solutions. These differentiators may be as small as how a transaction operates or information provided on a report or as large as the entire automation of a workflow that would otherwise be completed manually. We intend to continue our focus on differentiating our products, and we carefully assess our investments regularly as we strive to ensure those investments provide the solutions most valuable to our customers. |

[0000926326-18-000010:mdna:14]
| • | Deliver our solutions to new markets. Areas of healthcare where work is done manually may benefit from our existing solutions. These areas include hospitals that continue to employ manual operations, healthcare segments of the U.S. market outside hospitals and markets outside the United States. We weigh the cost of entering these new markets against the expected benefits and focus on the markets that we believe are most likely to adopt our products. |

[0000926326-18-000010:mdna:15]
| • | Expansion of our solutions through acquisitions and partnerships. Our acquisitions have generally been focused on automation of manual workflows or data analytics, which is the enhancement of data for our customers’ decision-making processes. We believe that expansion of our product lines through acquisition and partnerships to meet our customers changing and evolving expectations is a key component to our historical and future success. |

[0000926326-18-000010:mdna:16]
Our investments have been consistent with the strategies outlined above. To differentiate our solutions from others available in the market, in December 2016 we announced the XT Series, our new generation of medication and supply automation that is fully integrated on our Unity enterprise platform. The XT Series includes automated medication and supply dispensing cabinets, the Anesthesia Workstation, and Controlled Substance Manager. The XT Automated Medication Cabinets have been integrated with Connect-Rx® from Aesynt, so customers in the United States and Canada who use AcuDose-Rx® cabinets can take advantage of the new hardware without changing their software or server infrastructure. As part of this product introduction we developed a new hardware and electronics architecture for the XT Series. The new design enables more medications to be stocked within the same footprint-the XT cabinets offer up to 50% more capacity compared with similar units on the market.  In November 2017, we introduced our new IVX Workflow Solution.  This new solution powered by IVX Cloud services helps enable pharmacies to safely and efficiently compound and prepare IV treatments. In December 2017, we announced our XR2 Central Pharmacy Automated System, allowing customers to more fully automate their central pharmacies.

[0000926326-18-000010:mdna:17]
Consistent with our strategy to enter new markets, we have made investments in our selling, general and administrative expenses to expand our sales team and market to new customers. Our international efforts have focused primarily on two markets: Western Europe where we sell solutions through a direct sales team in the United Kingdom, France, and Germany and through resellers in other markets; and in the Middle Eastern countries of the Arabian Peninsula. We have also expanded our sales efforts to medication adherence customers in the United States which has allowed us to sell our automated dispensing solutions and other products to this market.

[0000926326-18-000010:mdna:18]
Expansion of our solutions through acquisitions and partnerships include our acquisition of MTS in 2012, our acquisition of Surgichem in August 2014, our acquisitions of Mach4 and Avantec in April 2015, our acquisition of Aesynt in January 2016, our acquisition of Ateb in December 2016, and most recently, our acquisition of InPharmics in April 2017. Surgichem was a provider of medication adherence products in the United Kingdom. Mach4 is a provider of automated medication management systems to retail and hospital pharmacy customers primarily in Europe, with additional installations in China, Africa, the Middle East and Latin America. Avantec develops medication and supply automation products that complement our solutions for configurations suited to the United Kingdom marketplace. Aesynt is a provider of automated medication management systems, including dispensing robots with storage solutions, medication storage and dispensing carts and cabinets, I.V. sterile preparation robotics and software, including software related to medication management. Ateb is a provider of pharmacy-based patient care solutions and medication synchronization to independent and chain retail pharmacies. InPharmics is a provider of advanced pharmacy informatics solutions to hospital pharmacies. We have also developed relationships with major providers of hospital information management systems with the goal of enhancing the interoperability of our products with their systems. We believe that enhanced interoperability will help reduce implementation costs, time, and maintenance for shared clients, while providing new clinical workflows designed to enhance efficiency and patient safety.

[0000926326-18-000010:mdna:19]
We believe that the success of our three-leg strategy of differentiated products, expansion into new markets and acquisition and partnership in future periods will be based on, among other factors:

[0000926326-18-000010:mdna:20]
| • | Our expectation that the overall market demand for healthcare services will increase as the population grows, life expectancies continue to increase and the quality and availability of healthcare services increases; |

[0000926326-18-000010:mdna:21]
| • | Our expectation that the environment of increased patient safety awareness, increased regulatory control, increased demand for innovative products that improve the care experience and increased need for workflow efficiency through the adoption of technology in the healthcare industry will make our solutions a priority in the capital budgets of healthcare facilities; and |

[0000926326-18-000010:mdna:22]
| • | Our belief that healthcare customers will continue to value a consultative customer experience from their suppliers. |

[0000926326-18-000010:mdna:23]
Among other financial measures, we utilize product bookings to assess the current success of our strategies. Product bookings consist of all firm orders, as evidenced generally by a non-cancellable contract and purchase order for equipment and software, and by a purchase order for consumables. Equipment and software bookings are generally installable within twelve months and, other than subscription based sales, generally recorded as revenue upon customer acceptance of the installation. Consumables are recorded as revenue upon shipment to a customer or receipt by the customer, depending upon contract terms. Consumable bookings are generally recorded as revenue within one month. Product bookings increased by 5%, from $541 million in 2016 to $568 million in 2017, driven by the success of our growth strategies in differentiated products, new markets and, by the contributions from our acquisitions of Aesynt, Ateb, and InPharmics.

[0000926326-18-000010:mdna:24]
In addition to product solution sales, we provide services to our customers. We provide installation planning and consulting as part of every product sale which is included in the initial price of the solution. To help assure the maximum

[0000926326-18-000010:mdna:25]
availability of our systems, our customers typically purchase maintenance and support contracts in increments of one to five years.  As a result of the growth of our installed base of customers, our service revenues have also grown.

[0000926326-18-000010:mdna:26]
The growth in the Medication Adherence revenue was primarily driven by further market penetration and adoption of our automated and semi-automated packaging equipment within the United States and Europe, Middle East and Africa ("EMEA"), as well as modest price increases across the product lines.

[0000926326-18-000010:mdna:27]
In the future, we expect our strategies to evolve as the business environment of our customers evolves, but for our focus is to remain on improving healthcare with solutions that help change the practices in ways that improve patient and provider outcomes. We expect our investment in differentiated products, new markets, and acquisitions and partnerships to continue.

[0000926326-18-000010:mdna:28]
In fiscal year 2017, we created Centers of Excellence (“COE”) for product development, engineering and manufacturing with the Point of Use COE located at our facilities in California, the Robotics and Central Pharmacy COE located at our facilities near Pittsburgh, Pennsylvania and the Medication Adherence Consumables COE located at our facilities in St. Petersburg, Florida. As part of this initiative, we reduced our workforce in the first half of 2017 by approximately 100 full-time employees, or about 4% of the total headcount, and closed our Nashville, Tennessee and Slovenia facilities.

[0000926326-18-000010:mdna:29]
Our full-time headcount of approximately 2,350 on December 31, 2017, a decrease of approximately 100 from December 31, 2016, reflects our efforts to drive profitability and optimize resources allocation.

[0000926326-18-000010:mdna:30]
2017 Acquisitions

[0000926326-18-000010:mdna:31]
On April 12, 2017, we completed the acquisition of InPharmics, a technology and services company that provides advanced pharmacy informatics solutions to hospital pharmacies. The purchase price consideration was $5.0 million, net of cash acquired of $0.3 million. The results of InPharmics' operations have been included in our consolidated results of operations beginning April 13, 2017, and presented as part of the Automation and Analytics segment.

[0000926326-18-000010:mdna:32]
2016 Acquisitions

[0000926326-18-000010:mdna:33]
On January 5, 2016, we completed the acquisition of all of the membership interests of Aesynt. Aesynt is a provider of automated medication management systems, including dispensing robots with storage solutions, medication storage and dispensing carts and cabinets, I.V. sterile preparation robotics and software, including software related to medication management. The purchase price consideration was $271.5 million net of cash acquired of $8.2 million. The results of Aesynt's operations have been included in our consolidated results of operations since January 6, 2016, and presented as part of the Automation and Analytics segment.

[0000926326-18-000010:mdna:34]
On December 8, 2016, we completed our acquisition of Ateb, Inc., and Ateb Canada Ltd. (together, “Ateb”). Ateb is a provider of pharmacy-based patient care and medication synchronization solutions to independent and chain pharmacies. The purchase price consideration was $40.7 million, net of cash acquired of $0.9 million. The results of Ateb's operations have been included in our consolidated results of operations beginning December 9, 2016, and presented as part of the Medication Adherence segment.

[0000926326-18-000010:mdna:35]
CRITICAL ACCOUNTING POLICIES AND ESTIMATES

[0000926326-18-000010:mdna:36]
Our discussion and analysis of our financial condition and results of operations are based on our Consolidated Financial Statements, which have been prepared in accordance with United States Generally Accepted Accounting Principles ("U.S. GAAP"). The preparation of these financial statements requires us to make certain estimates and assumptions that affect the reported amounts of assets and liabilities, disclosure of any contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. We regularly review our estimates and assumptions, which are based on historical experience and various other factors that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of certain assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates and assumptions. We believe the following critical accounting policies are affected by significant judgments and estimates used in the preparation of our Consolidated Financial Statements:

[0000926326-18-000010:mdna:37]
Revenue recognition

[0000926326-18-000010:mdna:38]
We earn revenues from sales of our medication and medical and surgical supply automation systems along with consumables and related services, which are sold in the healthcare industry, our principal market. Revenues are reported net of discounts and rebates provided to our customers. Our customer arrangements typically include one or more of the following deliverables:

[0000926326-18-000010:mdna:39]
Products. Software-enabled equipment that manages and regulates the storage and dispensing of pharmaceuticals, consumable blister cards and packaging equipment and other medical supplies.

[0000926326-18-000010:mdna:40]
Software. Additional software applications that enable incremental functionality of our equipment.

[0000926326-18-000010:mdna:41]
Installation. Installation of equipment as integrated systems at customers' sites.

[0000926326-18-000010:mdna:42]
Post-installation technical support. Phone support, on-site service, parts and access to unspecified software upgrades and enhancements, if and when available.

[0000926326-18-000010:mdna:43]
Professional services. Other customer services, such as training and consulting.

[0000926326-18-000010:mdna:44]
We recognize revenue when the earnings process is complete, based upon its evaluation of whether the following four criteria have been met:

[0000926326-18-000010:mdna:45]
Persuasive evidence of an arrangement exists. We use signed customer contracts and signed customer purchase orders as evidence of an arrangement for leases and sales. For service engagements, we use a signed services agreement and a statement of work to evidence an arrangement.

[0000926326-18-000010:mdna:46]
Delivery has occurred. Equipment and embedded software product delivery is deemed to occur upon successful installation and receipt of a signed and dated customer confirmation of installation letter, providing evidence that we have delivered what a customer ordered. In instances of a customer self-installation, product delivery is deemed to have occurred upon receipt of a signed and dated customer confirmation letter. If a sale does not require installation, we recognize revenue on delivery of products to the customer, including transfer of title and risk of loss, assuming all other revenue criteria are met. For existing distributors, where installation of equipment training has been previously provided and the distributor is certified to install our equipment at the end-user customer facility, we recognize revenue from sales of products to the distributor upon shipment assuming all other revenue criteria are met, net of allowance for rights of return or refund. For new distributors, where we have not provided installation of equipment training, revenue on the sales of products to the distributor is deferred until the distributor has completed the Distributor Training Program and has been certified to install our equipment at the end-user facility. For the sale of consumable blister cards, we recognize revenue when title and risk of loss of the products shipped have transferred to the customer, which usually occurs upon shipment from our facilities. Assuming all other revenue criteria are met, we recognize revenue for support services ratably over the related support services contract period. We recognize revenue on training and professional services as they are performed.

[0000926326-18-000010:mdna:47]
Fee is fixed or determinable. We assess whether a fee is fixed or determinable at the outset of the arrangement based on the payment terms associated with the transaction. We have established a history of collecting under the original contract without providing concessions on payments, products or services.

[0000926326-18-000010:mdna:48]
Collection is probable. We assess the probability of collecting from each customer at the outset of the arrangement based on a number of factors, including the customer's payment history and its current creditworthiness. If, in our judgment, collection of a fee is not probable, we defer revenue recognition until the uncertainty is removed, which generally means revenue is recognized upon our receipt of cash payment assuming all other revenue criteria are met. Our historical experience has been that collection from our customers is generally probable.

[0000926326-18-000010:mdna:49]
In arrangements with multiple deliverables, assuming all other revenue criteria are met, we recognize revenue for individual delivered items if they have value to the customer on a standalone basis. We allocate arrangement consideration at the inception of the arrangement to all deliverables using the relative selling price method. This method requires us to determine the selling price at which each deliverable could be sold if it were sold regularly on a standalone basis. When available, we use vendor-specific objective evidence ("VSOE") of the selling price. VSOE represents the price charged for a deliverable when it is sold separately, or for a deliverable not yet being sold separately, the price established by management with the relevant authority. We consider VSOE to exist when approximately 80% or more of its standalone sales of an item are priced within a reasonably narrow pricing range (plus or minus 15% of the median rates). We have established VSOE of the selling price for our post-installation technical support services and professional services. When VSOE of selling price is not available, third-party evidence ("TPE") of selling price for similar products and services is acceptable; however, our offerings and market strategy differ from those of our competitors, such that we cannot obtain sufficient comparable information about third parties' prices. If neither VSOE nor TPE are available, we use our best estimates of selling prices ("BESP"). We determine BESP considering factors such as market conditions, sales channels, internal costs and product margin objectives and pricing practices. We regularly review and update our VSOE and BESP information.

[0000926326-18-000010:mdna:50]
The relative selling price method allocates total arrangement consideration proportionally to each deliverable on the basis of its estimated selling price. In addition, the amount recognized for any delivered items cannot exceed that which is not contingent upon delivery of any remaining items in the arrangement.

[0000926326-18-000010:mdna:51]
We also use the residual method to allocate revenue between the software products that enable incremental equipment functionality, and thus are not deemed to deliver its essential functionality, and the related post-installation technical support, as these products and services continue to be accounted for under software revenue recognition rules. Under the residual method, the amount allocated to the undelivered elements equals VSOE of fair value of these elements. Any remaining amounts are attributed to the delivered items and are recognized when those items are delivered.

[0000926326-18-000010:mdna:52]
46

[0000926326-18-000010:mdna:53]
A portion of our sales are made through multi-year lease agreements. Under sales-type leases, we recognize revenue for our hardware and software products net of lease execution costs such as post-installation product maintenance and technical support, at the net present value of the lease payment stream once our installation obligations have been met. We have no obligation to the leasing company once the lease has been sold. Some of our sales-type leases, mostly those relating to U.S. government hospitals which comprise approximately 33% of the lease receivable balance, are retained in-house. Interest income in these leases is recognized in product revenue using the effective interest method.

[0000926326-18-000010:mdna:54]
Allowance for doubtful accounts and notes receivables from investment in sales-types leases

[0000926326-18-000010:mdna:55]
We maintain an allowance for doubtful accounts for estimated losses resulting from the inability of our customers to make required payments. We record a specific allowance based on an analysis of individual past-due balances. Additionally, based on historical write-offs and our collection experience, we record an additional allowance based on a percentage of outstanding receivables. We perform credit evaluations of our customers' financial condition. These evaluations require significant judgment and are based on a variety of factors including, but not limited to, current economic trends, payment history and a financial review of the customer. Actual collection losses may differ from management's estimates, and such differences could be material to our financial position and results of operations.

[0000926326-18-000010:mdna:56]
There were no customers that accounted for more than 10% of our accounts receivable balance as of December 31, 2017 and 2016.

[0000926326-18-000010:mdna:57]
The retained in-house leases discussed above are considered financing receivables. Our credit policies and our evaluation of credit risk and write-off policies are applied alike to trade receivables and the net investment in sales-type leases. For both, an account is generally past due after thirty days. The financing receivables also have customer-specific reserves for accounts identified for specific impairment and a non-specific reserve applied to the remaining population, based on factors such as current trends, the length of time the receivables are past due and historical collection experience. The retained in-house leases are not stratified by portfolio or class.

[0000926326-18-000010:mdna:58]
Inventory

[0000926326-18-000010:mdna:59]
Inventories are stated at the lower of cost, computed using the first-in, first-out method, and net realizable value.  Inbound shipping costs are included in cost of inventory. We regularly monitor inventory quantities on hand and record write-downs for excess and obsolete inventories based on our estimate of demand for our products, potential obsolescence of technology, product life cycles, and whether pricing trends or forecasts indicate that the carrying value of inventory exceeds its estimated selling price. These factors are impacted by market and economic conditions, technology changes, and new product introductions and require estimates that may include elements that are uncertain. Actual demand may differ from forecasted demand and may have a material effect on gross margins. If inventory is written down, a new cost basis is established that cannot be increased in future periods. Shipments from suppliers or contract manufacturers before we receive them are recorded as in-transit inventory when title and the significant risks and rewards of ownership have passed to us.

[0000926326-18-000010:mdna:60]
Software development costs

[0000926326-18-000010:mdna:61]
We capitalize software development costs in accordance with ASC 985-20, Costs of Software to Be Sold, Leased, or Marketed, under which certain software development costs incurred subsequent to the establishment of technological feasibility may be capitalized and amortized over the estimated lives of the related products. We establish feasibility when we complete a working model and amortize development costs over the estimated lives of the related products ranging from three to five years. All development costs prior to the completion of a working model are recognized as research and development expense.

[0000926326-18-000010:mdna:62]
Business combinations

[0000926326-18-000010:mdna:63]
We use the acquisition method of accounting under the authoritative guidance on business combinations. Each acquired company’s operating results are included in our Consolidated Financial Statements starting on the date of acquisition. The purchase price is equivalent to the fair value of consideration transferred. Tangible and identifiable intangible assets acquired and liabilities assumed as of the date of acquisition are recorded at the acquisition date fair value. Goodwill is recognized for the excess of purchase price over the net fair value of assets acquired and liabilities assumed.

[0000926326-18-000010:mdna:64]
Amounts allocated to assets and liabilities are based upon fair values. Such valuations require management to make significant estimates and assumptions, especially with respect to the identifiable intangible assets. Management makes estimates of fair value based upon assumptions believed to be reasonable and that of a market participant. These estimates are based on historical experience and information obtained from the management of the acquired companies and the estimates are inherently uncertain. The separately identifiable intangible assets generally include customer relationships, technology, and trade names.

[0000926326-18-000010:mdna:65]
Goodwill and acquired intangible assets

[0000926326-18-000010:mdna:66]
Goodwill. We review goodwill for impairment on an annual basis on the first day of the fourth quarter of each year at the reporting unit level. Our reporting units are the same as our operating segments, which are Automation and Analytics and Medication Adherence. A qualitative assessment is initially made to determine whether it is necessary to perform quantitative testing. A qualitative assessment includes, among others, consideration of: (i) past, current and projected future earnings and equity; (ii) recent trends and market conditions; and (iii) valuation metrics involving similar companies that are publicly-traded and acquisitions of similar companies, if available. If this qualitative assessment indicates that it is more likely than not that impairment exists, or if we decide to bypass this option, we proceed to the quantitative assessment. The quantitative assessment involves a comparison between the estimated fair values of our reporting units with their respective carrying amounts including goodwill. If the carrying value exceeds estimated fair value, we will record an impairment charge based on that difference. The impairment charge will be limited to the amount of goodwill allocated to that reporting unit.

[0000926326-18-000010:mdna:67]
To determine each reporting unit's fair value under the quantitative approach, we use a combination of income and market approaches, equally weighting the two approaches, such as estimated discounted future cash flows of that reporting unit, multiples of earnings or revenues, and analysis of recent sales or offerings of comparable entities. We also consider our market capitalization on the date of the analysis to ensure the reasonableness of the sum of its reporting units’ fair value.

[0000926326-18-000010:mdna:68]
We performed a quantitative impairment analysis as of October 1, 2017 for our Medication Adherence reporting unit. We determined that the fair value of this reporting unit exceeded the carrying value by more than 40%, and thus no impairment was indicated. Additionally, we performed a qualitative impairment assessment analysis as of October 1, 2017 for our Automation and Analytics reporting unit taking into consideration past, current and projected future earnings, recent trends and market conditions; and valuation metrics involving similar companies that are publicly-traded. Based on the result of this analysis, the fair value of this reporting unit exceeded the carrying value, and thus no impairment was indicated.

[0000926326-18-000010:mdna:69]
Intangible assets. In connection with our acquisitions, we generally recognize assets for customer relationships, backlog, developed technology, and trade names. Intangible assets are carried at cost less accumulated amortization. Such amortization is provided on a straight-line basis or on an accelerated basis based on a pattern of economic benefit that is expected to be obtained over the estimated useful lives of the respective assets, generally from one to 30 years. Amortization for developed technology and backlog is recognized in cost of revenues, and amortization for customer relationships, non-compete agreements, and trade names is recognized in selling, general and administrative expenses.

[0000926326-18-000010:mdna:70]
We assess the impairment of identifiable intangible assets whenever events or changes in circumstances indicate that an asset's carrying amount may not be recoverable. Recoverability of an asset is measured by the comparison of the carrying amount to the sum of the undiscounted estimated future cash flows the asset is expected to generate, offset by estimated future costs to dispose of the product to which the asset relates. If an asset is considered to be impaired, the amount of such impairment would be measured as the difference between the carrying amount of the asset and its fair value. Our cash flow assumptions are based on historical and forecasted future revenue, operating costs, and other relevant factors. Assumptions and estimates about the remaining useful lives of our intangible assets are subjective and are affected by changes to our business strategies. If management’s estimates of future operating results change, or if there are changes to other assumptions, the estimate of the fair value of our assets could change significantly. Such change could result in impairment charges in future periods, which could have a significant impact on our operating results and financial condition.

[0000926326-18-000010:mdna:71]
Share-based compensation

[0000926326-18-000010:mdna:72]
We account for share-based compensation in accordance with ASC 718, Stock Compensation ("ASC 718"). We recognize compensation expense related to stock-based compensation based on the grant date estimated fair value.

[0000926326-18-000010:mdna:73]
The fair value of stock options ("options") on the grant date is estimated using the Black-Scholes option pricing model, which requires the following inputs: expected life, expected volatility, risk-free interest rate, expected dividend yield rate, exercise price, and closing price of its common stock on the date of grant. The expected volatility is based on a combination of historical and market-based implied volatility, and the expected life of the awards is based on our historical experience of employee stock option exercises, including forfeitures. Expense is recognized on a straight-line basis over the requisite service period.

[0000926326-18-000010:mdna:74]
The fair value of Restricted Stock Units ("RSUs") is based on the stock price on the grant date. The fair value of Restricted Stock Awards (“RSAs”) is their intrinsic value, which is the difference between the fair value of the underlying stock at the measurement date and the purchase price. The RSUs and RSAs are subject to a service vesting condition and are recognized on a straight-line basis over the requisite service period.

[0000926326-18-000010:mdna:75]
The fair value of PSUs with service and market conditions is estimated using a Monte Carlo simulation model applying multiple awards approach. Expense is recognized when it is probable that the performance condition will be met using the accelerated attribution method over the requisite service period.

[0000926326-18-000010:mdna:76]
The valuation assumptions used in estimating the fair value of employee share-based awards may change in future periods

[0000926326-18-000010:mdna:77]
Accounting for income taxes

[0000926326-18-000010:mdna:78]
On December 22, 2017, the Tax Cuts and Jobs Act (the Act) was signed into law. The Act changed many aspects of U.S. corporate income taxation and included reduction of the corporate income tax rate from 35% to 21%, implementation of a territorial tax system and imposition of a tax on deemed repatriated earnings of foreign subsidiaries. At December 31, 2017, we had not completed our accounting for the tax effects of enactment of the Act; however, we made a reasonable estimate of the effects on our existing deferred tax balances and the one-time transition tax. We will continue to assess our provision for income taxes as future guidance is issued, but do not currently anticipate significant revisions will be necessary. Any such revisions will be treated in accordance with the measurement period guidance outlined in Staff Accounting Bulletin No. 118.

[0000926326-18-000010:mdna:79]
We record an income tax provision for (benefit from) the anticipated tax consequences of the reported results of operations. In accordance with ASC 740, Income Taxes ("ASC 740"), the provision for (benefit from) income taxes is computed using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been included in the financial statements. Under this method, deferred tax assets and liabilities are determined on the basis of the differences between the financial statement and tax bases of assets and liabilities, and for operating losses and tax credit carry forwards. Deferred tax assets and liabilities are measured using the enacted tax rates in effect for the periods in which those tax assets and liabilities are expected to be realized or settled. In the event that these tax rates change, we will incur a benefit or detriment on our income tax expense in the period of change. If we were to determine that all or part of the net deferred tax assets are not realizable in the future, we will record a valuation allowance that would be charged to earnings in the period such determination is made.

[0000926326-18-000010:mdna:80]
In accordance with ASC 740, we recognize the tax benefit from an uncertain tax position if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement. The calculation of tax liabilities involves significant judgment in estimating the impact of uncertainties in the application of ASC 740 and complex tax laws. Resolution of these uncertainties in a manner inconsistent with management’s expectations could have a material impact on our financial condition and operating results.

[0000926326-18-000010:mdna:81]
Recently issued authoritative guidance

[0000926326-18-000010:mdna:82]
Refer to Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to Consolidated Financial Statements in this annual report for a description of recently issued accounting pronouncements, including the expected dates of adoption and estimated effects on our results of operations, financial position and cash flows.

[0000926326-18-000010:mdna:83]
RESULTS OF OPERATIONS

[0000926326-18-000010:mdna:84]
Total Revenues

[0000926326-18-000010:mdna:85]
|  |  |  | Change in |  |  |  | Change in |  |  |
|  | 2017 |  | $ |  | % |  | 2016 |  | $ |  | % |  | 2015 |
|  | (Dollars in thousands) |
| Product revenues | $ | 506,209 |  |  | $ | (11,735 | ) |  | (2)% |  | $ | 517,944 |  |  | $ | 129,547 |  |  | 33% |  | $ | 388,397 |  |
| Percentage of total revenues | 71% |  |  |  |  |  | 75% |  |  |  |  |  | 80% |
| Service and other revenues | 209,956 |  |  | 35,277 |  |  | 20% |  | 174,679 |  |  | 78,517 |  |  | 82% |  | 96,162 |  |
| Percentage of total revenues | 29% |  |  |  |  |  | 25% |  |  |  |  |  | 20% |
| Total revenues | $ | 716,165 |  |  | $ | 23,542 |  |  | 3% |  | $ | 692,623 |  |  | $ | 208,064 |  |  | 43% |  | $ | 484,559 |  |

[0000926326-18-000010:mdna:86]
2017 compared to 2016:

[0000926326-18-000010:mdna:87]
Revenues were $716.2 million for the year ended December 31, 2017 compared to $692.6 million for the year ended December 31, 2016, representing an increase of approximately 3%. The year-over-year revenue increase was primarily attributed to an increase in service and other revenues of $35.3 million, offset by a decrease in product revenues of $11.7 million.

[0000926326-18-000010:mdna:88]
Product revenues represented 71% and 75% of total revenues for the years ended December 31, 2017 and 2016, respectively. Product revenues decreased by $11.7 million due to decreased sales in our Automation and Analytics segment of $20.3 million, offset by increased sales of $8.6 million in our Medication Adherence segment. The decrease in the Automation and Analytics segment was attributed to a slower conversion of bookings and backlog into revenue due to the introduction of the new XT series of products in the fourth quarter of 2016. While we have experienced larger deal sizes, the administrative process of converting our existing bookings of G4 products into XT series products decreased revenue recognition for the year ended December 31, 2017 compared to the year ended December 31, 2016. The increase in the Medication Adherence segment was partially attributed to Ateb, acquired in the fourth quarter of 2016, which contributed $4.2 million to the increase in the product revenue during the year ended December 31, 2017. The remainder of the increase is primarily attributed to the introduction of the VBM product series in the fourth quarter of 2016.

[0000926326-18-000010:mdna:89]
Service and other revenues represented 29% and 25% of total revenues for the years ended December 31, 2017 and 2016, respectively. Service and other revenues include revenues from service and maintenance contracts and rentals of automation systems.  The increase in service and other revenues of $35.3 million was attributable to year over year increases of $17.1 million and $18.2 million in our Automation and Analytics and Medication Adherence segments, respectively. The increase in revenue growth in our Automation and Analytics segment was a result of higher service renewal fees driven mainly by an increase in installed customer base. The increase in the Medication Adherence segment was primarily attributed to Ateb, which contributed $18.7 million to the increase in the service revenue during the year ended December 31, 2017.

[0000926326-18-000010:mdna:90]
Our international sales represented 14%, 15% and 17% of total revenues for the years ended December 31, 2017, December 31, 2016 and December 31, 2015, respectively, and are expected to be affected by foreign currency exchange rates fluctuations. The decrease as a percentage of our total revenues in international revenues was primarily related to our recently acquired companies, Aesynt and Ateb, which have a higher market presence in United States compared to international markets. We are unable to predict the extent to which revenue in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-18-000010:mdna:91]
Our ability to continue to grow revenue is dependent on our ability to continue to obtain orders from customers, our ability to produce quality products and consumables to fulfill customer demand, the volume of installations we are able to complete, our ability to meet customer needs by providing a quality installation experience, and our flexibility in manpower allocations among customers to complete installations on a timely basis. The timing of our product revenues for equipment is primarily dependent on when our customers’ schedules allow for installations.

[0000926326-18-000010:mdna:92]
2016 compared to 2015:

[0000926326-18-000010:mdna:93]
Revenues were $692.6 million for the year ended December 31, 2016 compared to $484.6 million for the year ended December 31, 2015, representing an increase of approximately 43%. The year-over-year revenue increase was primarily attributed to increases in product revenues of $129.5 million and in services and other revenue of $78.5 million.

[0000926326-18-000010:mdna:94]
Product revenues represented 75% and 80% of total revenues for the years ended December 31, 2016 and 2015, respectively. The increase in product revenues of $129.5 million was due to the recently acquired companies, primarily Aesynt which contributed $86.9 million to the increase, and to a lesser degree, a full year of operations of Mach4 and Avantec. The remaining increase was attributed to revenue growth in our Automation and Analytics segment due to customer conversions, larger orders received from our existing customers, and higher implementations, partially offset by decreases in lease renewals.  Our Medication Adherence segment contributed $3.2 million to the overall product revenue growth, primarily due to the increase in the consumable products sales of $5.2 million, partially offset by decrease in equipment sales of $2.4 million due to the timing of installations.

[0000926326-18-000010:mdna:95]
Service and other revenues represented 25% and 20% of total revenues for the years ended December 31, 2016 and 2015, respectively.  The increase in service revenues of $78.5 million was due to the recently acquired companies, primarily Aesynt which contributed $68.9 million to the increase, and to a lesser degree, a full year of operations of Mach4 and Avantec. The remaining increase was primarily attributed to revenue growth in our Automation and Analytics segment as result of higher service renewal fees driven mainly by an increase in installed customer base. Our Medication Adherence segment contributed $1.6 million primarily due to the Ateb acquisition.

[0000926326-18-000010:mdna:96]
Financial Information by Segment

[0000926326-18-000010:mdna:97]
Revenues

[0000926326-18-000010:mdna:98]
|  |  |  | Change in |  |  |  | Change in |  |  |
|  | 2017 |  | $ |  | % |  | 2016 |  | $ |  | % |  | 2015 |
| Revenues: | (Dollars in thousands) |
| Automation and Analytics | $ | 590,392 |  |  | $ | (3,234 | ) |  | (1)% |  | $ | 593,626 |  |  | $ | 203,305 |  |  | 52% |  | $ | 390,321 |  |
| Percentage of total revenues | 82% |  |  |  |  |  | 86% |  |  |  |  |  | 81% |
| Medication Adherence | 125,773 |  |  | 26,776 |  |  | 27% |  | 98,997 |  |  | 4,759 |  |  | 5% |  | 94,238 |  |
| Percentage of total revenues | 18% |  |  |  |  |  | 14% |  |  |  |  |  | 19% |
| Total revenues | $ | 716,165 |  |  | $ | 23,542 |  |  | 3% |  | $ | 692,623 |  |  | $ | 208,064 |  |  | 43% |  | $ | 484,559 |  |

[0000926326-18-000010:mdna:99]
2017 compared to 2016:

[0000926326-18-000010:mdna:100]
The decrease in Automation and Analytics revenues of $3.2 million for the year ended December 31, 2017 as compared to the year ended December 31, 2016 was primarily related to a decrease in product revenues of $20.3 million partially offset by an increase in service revenue of $17.1 million. The decrease in revenues in the Automation and Analytics segment was attributed to a slower conversion of bookings and backlog into revenue due to the introduction of the new XT series of products in the fourth quarter of 2016. While we have experienced larger deal sizes, the administrative process of converting our existing bookings of G4 products into XT series products has decelerated revenue recognition for the year ended December 31, 2017 compared to the year ended December 31, 2016. Service revenue increase in the Automation and Analytics segment was primarily attributed to higher service renewal fees driven mainly by an increase in installed customer base.

[0000926326-18-000010:mdna:101]
The increase in Medication Adherence revenues of $26.8 million for the year ended December 31, 2017 as compared to the year ended December 31, 2016 was primarily attributed to increases in service revenues of $18.2 million and product revenues of $8.6 million. The increase in service revenues was primarily attributed to Ateb, which contributed $18.7 million to the increase during the year ended December 31, 2017. Product revenue increase was primarily attributed to Ateb, which contributed $4.2 million to the increase, as well as the introduction of the VBM product series in the fourth quarter of 2016.

[0000926326-18-000010:mdna:102]
2016 compared to 2015:

[0000926326-18-000010:mdna:103]
The increase in Automation and Analytics revenues for the year ended December 31, 2016 as compared to the year ended December 31, 2015 was primarily related to an increase in product revenues of $126.4 million and an increase in service revenue of $76.9 million. The increase in product and service revenue is attributable to the recently acquired companies, primarily Aesynt, and to a lesser degree a full year of operations for Mach4 and Avantec. Aesynt contributed $86.9 million and $68.9 million to the increase in product and service revenues, respectively. The remaining increase was attributed to customer conversions, larger orders received from our existing customers, higher implementations, and higher service renewal fees driven mainly by an increase in the installed customer base, partially offset by decreases in lease renewals.

[0000926326-18-000010:mdna:104]
Medication Adherence revenues increased for the year ended December 31, 2016 as compared to the year ended December 31, 2015 and was primarily attributable to an increase in product revenues of $3.2 million, mainly due to the increase in consumable product sales which increased $5.2 million compared to the year ended December 31, 2015. This increase was partially offset by a decrease in equipment sales of $2.4 million due to the timing of installations.

[0000926326-18-000010:mdna:105]
Cost of Revenues and Gross Profit

[0000926326-18-000010:mdna:106]
Cost of revenues is primarily comprised of three general categories: (i) standard product costs which accounts for the majority of the product cost of revenues that are provided to customers, and are inclusive of purchased material, labor to build the product and overhead costs associated with production; (ii) installation costs as we install our equipment at the customer site and include costs of the field installation personnel, including labor, travel expense, and other expenses; and (iii) other costs, including variances in standard costs and overhead, scrap costs, rework, warranty, provisions for excess and obsolete inventory and amortization of software development costs and intangibles.

[0000926326-18-000010:mdna:107]
|  |  |  | Change in |  |  |  | Change in |  |  |
|  | 2017 |  | $ |  | % |  | 2016 |  | $ |  | % |  | 2015 |
| Cost of revenues: | (Dollars in thousands) |
| Automation and Analytics | $ | 308,443 |  |  | $ | (2,524 | ) |  | (1)% |  | $ | 310,967 |  |  | $ | 139,024 |  |  | 81% |  | $ | 171,943 |  |
| As a percentage of related revenues | 52% |  |  |  |  |  | 52% |  |  |  |  |  | 44% |
| Medication Adherence | 85,634 |  |  | 17,778 |  |  | 26% |  | 67,856 |  |  | 3,170 |  |  | 5% |  | 64,686 |  |
| As a percentage of related revenues | 68% |  |  |  |  |  | 69% |  |  |  |  |  | 69% |
| Total cost of revenues | $ | 394,077 |  |  | $ | 15,254 |  |  | 4% |  | $ | 378,823 |  |  | $ | 142,194 |  |  | 60% |  | $ | 236,629 |  |
| As a percentage of total revenues | 55% |  |  |  |  |  | 55% |  |  |  |  |  | 49% |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 281,949 |  |  | $ | (710 | ) |  | —% |  | $ | 282,659 |  |  | $ | 64,281 |  |  | 29% |  | $ | 218,378 |  |
| Automation and Analytics gross margin | 48% |  |  |  |  |  | 48% |  |  |  |  |  | 56% |
| Medication Adherence | 40,139 |  |  | 8,998 |  |  | 29% |  | 31,141 |  |  | 1,589 |  |  | 5% |  | 29,552 |  |
| Medication Adherence gross margin | 32% |  |  |  |  |  | 31% |  |  |  |  |  | 31% |
| Total gross profit | $ | 322,088 |  |  | $ | 8,288 |  |  | 3% |  | $ | 313,800 |  |  | $ | 65,870 |  |  | 27% |  | $ | 247,930 |  |
| Total gross margin | 45% |  |  |  |  |  | 45% |  |  |  |  |  | 51% |

[0000926326-18-000010:mdna:108]
2017 compared to 2016:

[0000926326-18-000010:mdna:109]
Cost of Revenues

[0000926326-18-000010:mdna:110]
Automation and Analytics. Cost of revenues for the year ended December 31, 2017 decreased by $2.5 million compared to the year ended December 31, 2016 primarily due to a decrease in product costs of $9.1 million, partially offset by an increase in service costs of $6.5 million. The decrease in product costs is primarily due to the decrease in product revenues of $20.3 million partially offset by costs attributed to the XT series manufacturing ramp up, including costs related to design refinement and lower overhead absorption due to the decrease of revenues from the XT conversion. The increase in service costs is primarily due to the increase in service revenues of $17.1 million, which is offset by a slight decrease in costs due to efficiencies from scaling and cost saving activities.

[0000926326-18-000010:mdna:111]
Medication Adherence. Cost of revenues increased by $17.8 million for the year ended December 31, 2017 as compared to the year ended December 31, 2016 primarily due to the increase in product costs and service costs of $11.5 million and $6.3 million, respectively. The increase in product costs was attributed to (i) increase in product revenues of $8.6 million, (ii) increase in product costs of $5.4 million related to Ateb, and (iii) product mix from higher volume of sales of lower margin products. The increase in service costs was primarily attributed to the increase in service costs of $6.3 million related to Ateb.

[0000926326-18-000010:mdna:112]
2016 compared to 2015:

[0000926326-18-000010:mdna:113]
Cost of Revenues

[0000926326-18-000010:mdna:114]
Automation and Analytics. Cost of revenues increased by $139.0 million, primarily due to an increase in product costs of $101.7 million. The increase was attributed to the acquired companies, mainly Aesynt, and to a lesser degree Mach4 and Avantec due to a full year of operations in 2016. The increase in cost of product revenues from Aesynt of $78.1 million, includes the amortization expense for developed technology of $4.9 million, amortization of backlog of $13.7 million, and inventory step-up fair value adjustment of $3.7 million resulting from the purchase accounting. The remaining difference is due to customer and product mixes and overall growth in product sales. Cost of service revenues increased by $37.3 million primarily due to costs related to the acquired companies, mainly Aesynt which contributed $33.7 million to the increase in cost of service revenue.

[0000926326-18-000010:mdna:115]
Medication Adherence. Cost of revenues increased by $3.2 million compared to the year ended December 31, 2015. The change is due to product and service cost of revenues which increased $2.3 million and $0.9 million, respectively, mainly attributed to customer and product mixes and overall growth in product sales.

[0000926326-18-000010:mdna:116]
Operating Expenses and Income from Operations

[0000926326-18-000010:mdna:117]
|  |  |  | Change in |  |  |  | Change in |  |  |
|  | 2017 |  | $ |  | % |  | 2016 |  | $ |  | % |  | 2015 |
| Operating expenses: | (Dollars in thousands) |
| Research and development | $ | 66,022 |  |  | $ | 8,223 |  |  | 14% |  | $ | 57,799 |  |  | $ | 22,639 |  |  | 64% |  | $ | 35,160 |  |
| As a percentage of total revenues | 9% |  |  |  |  |  | 8% |  |  |  |  |  | 7% |
| Selling, general and administrative | 250,312 |  |  | 792 |  |  | —% |  | 249,520 |  |  | 81,939 |  |  | 49% |  | 167,581 |  |
| As a percentage of total revenues | 35% |  |  |  |  |  | 36% |  |  |  |  |  | 35% |
| Gain on business combination | — |  |  | — |  |  | —% |  | — |  |  | 3,443 |  |  | (100)% |  | (3,443 | ) |
| Total operating expenses | $ | 316,334 |  |  | $ | 9,015 |  |  | 3% |  | $ | 307,319 |  |  | $ | 108,021 |  |  | 54% |  | $ | 199,298 |  |
| As a percentage of total revenues | 44% |  |  |  |  |  | 44% |  |  |  |  |  | 41% |
| Income (loss) from operations: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 88,249 |  |  | $ | 4,101 |  |  | 5% |  | $ | 84,148 |  |  | $ | (20,146 | ) |  | (19)% |  | $ | 104,294 |  |
| Operating margin | 15% |  |  |  |  |  | 14% |  |  |  |  |  | 27% |
| Medication Adherence | (1,596 | ) |  | (7,894 | ) |  | (125)% |  | 6,298 |  |  | 1,004 |  |  | 19% |  | 5,294 |  |
| Operating margin | (1)% |  |  |  |  |  | 6% |  |  |  |  |  | 6% |
| Corporate expenses ("Common") | (80,899 | ) |  | 3,066 |  |  | (4)% |  | (83,965 | ) |  | (23,009 | ) |  | 38% |  | (60,956 | ) |
| Total income from operations | $ | 5,754 |  |  | $ | (727 | ) |  | (11)% |  | $ | 6,481 |  |  | $ | (42,151 | ) |  | (87)% |  | $ | 48,632 |  |
| Total operating margin | 1% |  |  |  |  |  | 1% |  |  |  |  |  | 10% |

[0000926326-18-000010:mdna:118]
2017 compared to 2016:

[0000926326-18-000010:mdna:119]
Research and Development. Research and development expenses increased $8.2 million for the year ended December 31, 2017 as compared to year ended December 31, 2016, primarily driven by increases of $0.2 million and $6.8 million in our Automation and Analytics and Medication Adherence segments, respectively. In addition, corporate-related research and development expenses increased by $1.2 million. The increase in our Medication and Adherence segment was primarily attributable to recently acquired Ateb, which contributed $5.5 million to the increase year over year. The remaining increase in the Medication Adherence segment is primarily related to continued investment in the segment. The increase in the corporate-related expenses related to new and ongoing research and development projects.

[0000926326-18-000010:mdna:120]
Selling, General and Administrative. Selling, general and administrative expenses increased $0.8 million for the year ended December 31, 2017 as compared to year ended December 31, 2016 due to an increase in our Medication Adherence segment of $10.1 million, offset by decreases from our Automation and Analytics segment of $5.0 million and corporate-related expenses of $4.3 million.  The increase from our Medication Adherence segment is primarily attributed to Ateb, which contributed $9.1 million to the increase. The remaining increase is primarily due to normal growth to support the business and attributed to higher commissions, benefits and salaries, and other investment in the business. The decrease in our Automation and Analytics segment was mainly due to (i) lower amortization expense related to intangible assets of $2.4 million, (ii) a decrease in commissions of $3.2 million due to decrease in product revenue, and (iii) a decrease in professional fees of $1.8 million related to Aesynt. The decreases are offset by normal growth of operations. The decrease in our corporate-related expenses was mainly due to lower integration and acquisition related cost as well as an overall reduction in cost as part of cost saving initiatives.

[0000926326-18-000010:mdna:121]
2016 compared to 2015:

[0000926326-18-000010:mdna:122]
Research and Development. Research and development expenses increased $22.6 million for the year ended December 31, 2016 as compared to year ended December 31, 2015, primarily driven by an increase of $22.9 million in our Automation and Analytics segment which was partially offset by a decrease of $0.3 million in our Medication Adherence segment. The increase in our Automation and Analytics segment was primarily attributable to recently acquired companies, primarily Aesynt which contributed $19.4 million to the increase year over year.  The remaining increase is mainly due to the increase in employee related expenses of $2.2 million as result of the increase in headcount and increase in consulting fees of $0.7 million related to ongoing research and development projects.

[0000926326-18-000010:mdna:123]
Selling, General and Administrative. Selling, general and administrative expenses increased $81.9 million for the year ended December 31, 2016 as compared to year ended December 31, 2015 due to increases from our Automation and Analytics segment of $58.3 million, increases in corporate expenses of $22.7 million and increases from our Medication Adherence

[0000926326-18-000010:mdna:124]
segment of $0.1 million. The increase from our Automation and Analytics segment was attributed to the newly acquired companies, primarily Aesynt which accounted for $40.7 million of the increase. The remaining increase is mainly due to (i) increase of $2.3 million in commission expense and $1.2 million in GPO fees due to increased revenue and timing of expense recognition, (ii) increase of $3.2 million in consulting and professional fees related to integration of recently acquired businesses and (iii) increase of $5.1 million employee related expenses as result of headcount increases. The increase in corporate related expenses is mainly due to (i) increase of $7.0 million in employee related expenses as result of headcount increases, (ii) increase of $1.7 million in bonus expenses, (iii) increase of $0.1 million in travel related expenses, (iv) increase of $2.5 million in depreciation expense, (v) increase of $1.8 million in software related fees and (vi) increase of $5.8 million in health and dental insurance costs.

[0000926326-18-000010:mdna:125]
Provision for (Benefit from) Taxes

[0000926326-18-000010:mdna:126]
|  |  |  | Change in |  |  |  | Change in |  |  |
|  | 2017 |  | $ |  | % |  | 2016 |  | $ |  | % |  | 2015 |
|  | (Dollars in thousands) |
| Provision for (benefit from) income taxes | $ | (21,484 | ) |  | $ | (18,933 | ) |  | 742% |  | $ | (2,551 | ) |  | $ | (18,035 | ) |  | (116)% |  | $ | 15,484 |  |
| Effective tax rate on earnings | 2,444% |  |  |  |  |  | 131% |  |  |  |  |  | 34% |

[0000926326-18-000010:mdna:127]
2017 compared to 2016:

[0000926326-18-000010:mdna:128]
We recorded a benefit from income taxes of $21.5 million and an effective tax rate of 2,444% for the year ended December 31, 2017, compared to a tax benefit of $2.6 million and an effective tax rate of 131% for the year ended December 31, 2016. The 2017 annual effective tax rate differed from the statutory tax rate of 35%, primarily due to a favorable impact from the U.S. tax reform legislation that resulted in the recognition of a one-time benefit of $13.4 million from the revaluation of deferred tax assets and liabilities, as well as recording of the excess tax benefit from the equity-based compensation within income tax expense effective 2017, and favorable impact of research and development credits, the domestic production activities deduction, offset by unfavorable impact of geographic mix of earnings. The increase in the annual effective tax rate as compared to 2016 was primarily due to the favorable impact from enactment of the U.S. tax reform entitled the 2017 Tax Cuts and Jobs Act (the "Act") discussed further in Note 15 to our Consolidated Financial Statements.

[0000926326-18-000010:mdna:129]
2016 compared to 2015:

[0000926326-18-000010:mdna:130]
We recorded a benefit from income taxes of $2.6 million and an effective tax rate of 131% for the year ended December 31, 2016, compared to a tax provision of $15.5 million and an effective tax rate of 34% for the year ended December 31, 2015. The 2016 annual effective tax rate differed from the statutory tax rate of 35%, primarily due to the favorable impact of the IRS settlement and release of reserves, the domestic production activities deduction, and a calculated benefit in state income taxes, offset by unfavorable items such as non-deductible transaction costs, and non-deductible equity charges under ASC 740-718. The increase in the annual effective tax rate as compared to 2015 was primarily due to a decrease in overall profitability and the benefit recorded as a result of reserve releases after the IRS' examination.

[0000926326-18-000010:mdna:131]
LIQUIDITY AND CAPITAL RESOURCES

[0000926326-18-000010:mdna:132]
We had cash and cash equivalents of $32.4 million at December 31, 2017, compared to $54.5 million at December 31, 2016. All of our cash and cash equivalents are invested in demand deposits only.

[0000926326-18-000010:mdna:133]
Our cash position and working capital at December 31, 2017 and December 31, 2016 were as follows:

[0000926326-18-000010:mdna:134]
|  | December 31, |
|  | 2017 |  | 2016 |
|  | (In thousands) |
| Cash | $ | 32,424 |  |  | $ | 54,488 |  |
| Working Capital | $ | 154,585 |  |  | $ | 134,496 |  |

[0000926326-18-000010:mdna:135]
Our ratio of current assets to current liabilities was 1.7:1 at December 31, 2017 and at December 31, 2016.

[0000926326-18-000010:mdna:136]
Sources of Cash

[0000926326-18-000010:mdna:137]
On January 5, 2016, we entered into a $400 million secured credit facility pursuant to a credit agreement, by and among us, the lenders from time to time party thereto, Wells Fargo Securities, LLC, as sole lead arranger and Wells Fargo Bank, National Association, as administrative agent (the “Credit Agreement”). The Credit Agreement provides for a $200 million term loan facility (the “Term Loan Facility”), and prior to the amendment discussed below, a $200 million revolving credit facility (the “Revolving Credit Facility” and together with the Term Loan Facility, the “Facilities”). In addition, the Credit Agreement includes a letter of credit sub-limit of up to $10 million and a swing line loan sub-limit of up to $10 million.

[0000926326-18-000010:mdna:138]
On December 26, 2017 and April 11, 2017, we entered into the amendments to the Credit Agreement. Under these amendments, the Revolving Credit Facility was increased from $200 million to $315 million and certain other modifications were made. Refer to Note 8, Debt, of the Notes to the Consolidated Financial Statements included in this annual report. We expect to use future loans under the Revolving Credit Facility, if any, for general corporate purposes, including acquisitions.

[0000926326-18-000010:mdna:139]
As of December 31, 2017, the outstanding balance from the Facilities was $217 million and we were in full compliance with all covenants.

[0000926326-18-000010:mdna:140]
On November 3, 2017, we entered into a Distribution Agreement (the “Distribution Agreement”) with J.P. Morgan Securities LLC, Wells Fargo Securities, LLC and HSBC Securities (USA) Inc., as our sales agents (collectively, the “Sales Agents”), pursuant to which we may offer and sell from time to time through the Sales Agents up to $125 million maximum aggregate offering price of our common stock. Sales of the common stock pursuant to the Distribution Agreement may be made in negotiated transactions or transactions that are deemed to be “at the market” offerings as defined in Rule 415 under the Securities Act, including sales made directly on the Nasdaq Stock Market, or sales made to or through a market maker other than on an exchange. We intend to use the net proceeds from the sale, if any, of common stock in the offering for general corporate purposes, which may include, without limitation, the acquisition of complementary businesses, the repayment of outstanding indebtedness, capital expenditures and working capital.

[0000926326-18-000010:mdna:141]
For the year ended December 31, 2017, we generated gross proceeds of $14.7 million from sales of our common stock under the Distribution Agreement and incurred issuance costs of $0.8 million on sales of approximately 294,000 shares of our common stock at an average price of approximately $49.85 per share.

[0000926326-18-000010:mdna:142]
Uses of Cash

[0000926326-18-000010:mdna:143]
Our future uses of cash are expected to be primarily for working capital, capital expenditures, loan principal and interest payments, and other contractual obligations. We also expect a continued use of cash for potential acquisitions and acquisition assessment activities.

[0000926326-18-000010:mdna:144]
On April 12, 2017, we completed the acquisition of all of the membership interest of InPharmics. The total consideration for the transaction was $5.0 million, net of cash on hand at signing of $0.3 million. Approximately $0.5 million of the total consideration was classified as a long-term liability for potential settlement of performance obligations.

[0000926326-18-000010:mdna:145]
On January 5, 2016, we completed the acquisition of all of the membership interests of Aesynt. The purchase price paid by us was $271.5 million, net of cash on hand of $8.2 million. On December 8, 2016, we completed the acquisition of Ateb. The purchase price paid by us was $40.7 million, net of cash on hand of $0.9 million. These acquisitions were funded with cash-on-hand and borrowings under the Credit Agreement.

[0000926326-18-000010:mdna:146]
In accordance with the share purchase agreement entered into on April 30, 2015 under which we acquired Avantec, we agreed to pay our potential earn-out payments of up to $3.0 million payable after December 31, 2015 and an additional $3.0 million payable after December 31, 2016, based on bookings targets. The fair value of these potential earn-out payments as of the acquisition date was $5.6 million. Additionally we retained $1.8 million of the purchase consideration to be held to settle any future indemnification claims within an 18- month period that we may make following the closing.  During the year ended December 31, 2016, we paid out $3.0 million in earn-out payments, $1.8 million in held back payments for future indemnifications, and recognized $0.6 million of contingent gain as certain booking targets were not met. During the year ended December 31, 2017, the Company concluded that the final payout had been earned and paid out $2.4 million during the third quarter of 2017.

[0000926326-18-000010:mdna:147]
Our stock repurchase programs have a total of $54.9 million remaining for future repurchases as of December 31, 2017, which may result in additional use of cash. See Note 12, Stock Repurchases, of the Notes to Consolidated Financial Statements included in this annual report. There were no stock repurchases in 2017 and 2016. In 2015, the Company repurchased approximately $50.0 million of shares.

[0000926326-18-000010:mdna:148]
Based on our current business plan and revenue backlog, we believe that our existing cash and cash equivalents, our anticipated cash flows from operations, cash generated from the exercise of employee stock options and purchases under our employee stock purchase plan, along with the availability of funds under the Facilities will be sufficient to meet our cash needs

[0000926326-18-000010:mdna:149]
for working capital, capital expenditures, potential acquisitions, and other contractual obligations for at least the next twelve months. For periods beyond the next twelve months, we also anticipate that our net operating cash flows plus existing balances of cash and cash equivalents will suffice to fund the continued growth of our business.

[0000926326-18-000010:mdna:150]
Cash Flows

[0000926326-18-000010:mdna:151]
The following table summarizes, for the periods indicated, selected items in our Consolidated Statements of Cash Flows (as adjusted for the adoption of ASU 2016-09):

[0000926326-18-000010:mdna:152]
|  | Year Ended December 31, |
|  | 2017 |  | 2016 |  | 2015 |
|  | (In thousands) |
| Net cash provided by (used in): |  |  |  |  |  |
| Operating activities | $ | 24,834 |  |  | $ | 49,900 |  |  | $ | 38,486 |  |
| Investing activities | (34,987 | ) |  | (341,323 | ) |  | (45,596 | ) |
| Financing activities | (9,877 | ) |  | 263,752 |  |  | (36,557 | ) |
| Effect of exchange rate changes on cash and cash equivalents | (2,034 | ) |  | (58 | ) |  | (4 | ) |
| Net increase (decrease) in cash and cash equivalents | $ | (22,064 | ) |  | $ | (27,729 | ) |  | $ | (43,671 | ) |

[0000926326-18-000010:mdna:153]
Operating activities

[0000926326-18-000010:mdna:154]
We expect cash from our operating activities to fluctuate in future periods as a result of a number of factors, including the timing of our billings and collections, our operating results and the timing of other liability payments.

[0000926326-18-000010:mdna:155]
Net cash provided by operating activities was $24.8 million for 2017, primarily as a result of the net income of $20.6 million adjusted for non-cash items and changes in assets and liabilities. The non-cash items primarily consisted of depreciation and amortization expense of $51.5 million, share-based compensation expense of $21.9 million, deferred income taxes of $26.8 million and $1.6 million of amortization of debt financing fees. The net cash outflow which was contributed to changes in assets and liabilities include (i) an increase in accounts receivable of $39.1 million due to the timing of billings and collections, (ii) an increase in inventories of $26.8 million for inventory buildup in support of forecasted sales, (iii) a decrease in deferred revenue of $1.2 million due to the timing of orders and revenue being recognized for installed product, (iv) an increase in other current assets of $2.1 million and (v) an increase in prepaid expenses of $7.4 million. These outflows were partially offset by an increase in accounts payable of $19.7 million primarily due to the increase in inventory and timing of payments, a decrease in the investment in sales-type leases of $6.6 million, and an increase in other accrued liabilities of $4.4 million.

[0000926326-18-000010:mdna:156]
Net cash provided by operating activities was $49.9 million for 2016, primarily as a result of $0.6 million in net income adjusted for non-cash items and changes in assets and liabilities. The non-cash items primarily consisted of depreciation and amortization expense of $58.4 million, share-based compensation expense of $19.5 million, and deferred income taxes of $10.9 million. The cash outflow attributed to changes in assets and liabilities includes (i) a $3.4 million increase in inventories to support sales forecast, (ii) a $6.3 million decrease in other long-term liabilities mainly due to other tax liabilities, (iii) a $5.0 million decrease in accounts payable due to timing of payments, and (iv) a $9.6 million increase in investment in sales-type leases due to additional lease transactions entered into during the year. These amounts were partially offset by an increase in the deferred revenue of $4.5 million due to timing of orders and revenue being recognized for installed product, and decrease of $8.0 million in receivables as result of higher collections in the fourth quarter of 2016.

[0000926326-18-000010:mdna:157]
Net cash provided by operating activities was $38.5 million for 2015, primarily as a result of $30.8 million in net income adjusted for non-cash items, including depreciation and amortization expense of $25.6 million and share-based compensation expense of $14.9 million, partially offset by increases of $17.9 million in receivables and $10.0 million in inventory and net outflows of $9.6 million in other asset and liability accounts.

[0000926326-18-000010:mdna:158]
Investing activities

[0000926326-18-000010:mdna:159]
Net cash used in investing activities was $35.0 million for 2017, which consisted of capital expenditures of $15.3 million for property and equipment, $15.0 million for costs of software development for external use, $0.2 million for purchase of intangible assets, and $4.4 million attributable to the acquisition of InPharmics.

[0000926326-18-000010:mdna:160]
Net cash used in investing activities was $341.3 million for 2016, $312.2 million of which was attributable to the acquisitions of Aesynt and Ateb. Capital expenditures related to software development costs for external use, purchases of property and equipment and, purchases of intangibles contributed $14.3 million, $13.4 million, and $1.4 million, respectively.

[0000926326-18-000010:mdna:161]
Net cash used in investing activities was $45.6 million for 2015, $25.5 million of which was attributable to the acquisitions of Mach4 and Avantec, and capital expenditures related to purchases of property and equipment and software development of software costs for external use of $7.5 million and $12.1 million, respectively.

[0000926326-18-000010:mdna:162]
Financing activities

[0000926326-18-000010:mdna:163]
Net cash used in financing activities was $9.9 million for 2017, primarily due to the repayment of $102.5 million of the credit facilities and $5.9 million in employees' taxes paid related to restricted stock unit vesting, partially offset by $30.1 million in proceeds from employee stock option exercises and employee stock plan purchases, and $56.9 million proceeds from term loan and revolving credit facilities.

[0000926326-18-000010:mdna:164]
Net cash provided by financing activities was $263.7 million for 2016, as a result of $287.1 million of net proceeds from debt, $17.7 million in proceeds from employee stock option exercises and employee stock plan purchases and $2.0 million in excess tax benefits from employee stock plans, partially offset by $34.5 million of repayments of debt and revolving credit facility, $3.5 million in employees taxes paid in relation to restricted stock units and $3.0 million of payment for contingent consideration.

[0000926326-18-000010:mdna:165]
Net cash used in financing activities was $36.6 million for 2015 as a result of $50.0 million in cash used for stock repurchases under our 2012 and 2014 Stock Repurchase Programs and $3.6 million in employees taxes paid in relation to restricted stock units, partially offset by $17.1 million in proceeds from employee stock option exercises and employee stock plan purchases and $4.7 million in excess tax benefits from employee stock plans.

[0000926326-18-000010:mdna:166]
Contractual Obligations

[0000926326-18-000010:mdna:167]
Contractual obligations as of December 31, 2017 are as follows:

[0000926326-18-000010:mdna:168]
|  | Payments Due by Period |
|  | Total |  | 2018 |  | 2019-2020 |  | 2021-2022 |  | 2023 and thereafter |
|  | (In thousands) |
| Operating leases (1) | $ | 80,357 |  |  | $ | 12,167 |  |  | $ | 22,700 |  |  | $ | 19,247 |  |  | $ | 26,243 |  |
| Purchase obligations (2) | 58,090 |  |  | 53,543 |  |  | 2,551 |  |  | 1,950 |  |  | 46 |  |
| Term loan facility (3) | 182,500 |  |  | 17,500 |  |  | 47,500 |  |  | 117,500 |  |  | — |  |
| Revolving credit facility (3) | 34,500 |  |  | — |  |  | — |  |  | 34,500 |  |  | — |  |
| Total (4) (5) | $ | 355,447 |  |  | $ | 83,210 |  |  | $ | 72,751 |  |  | $ | 173,197 |  |  | $ | 26,289 |  |

[0000926326-18-000010:mdna:169]
_________________________________________________

[0000926326-18-000010:mdna:170]
| (1) | Commitments under operating leases relate primarily to leased property and office equipment. Rent expense was $11.5 million, $9.8 million and $7.0 million for the years ended December 31, 2017, 2016 and 2015, respectively. |

[0000926326-18-000010:mdna:171]
| (2) | We purchase components from a variety of suppliers and use contract manufacturers to provide manufacturing services for our products. During the normal course of business, we issue purchase orders with estimates of our requirements several months ahead of the delivery dates. These amounts are associated with agreements that are enforceable and legally binding. The amounts under such contracts are included in the table above because we believe that cancellation of these contracts is unlikely and we expect to make future cash payments according to the contract terms or in similar amounts for similar materials. |

[0000926326-18-000010:mdna:172]
| (3) | Amounts shown for term loan and revolving credit facility are principal repayments only. Due to use of interest rate swaps, the cash interest expense is partly variable and partly fixed, and is not reflected in the above table. Refer to Note 8, Debt, of the Notes to the Consolidated Financial Statements included in this annual report. |

[0000926326-18-000010:mdna:173]
| (4) | We have recorded $7.1 million for uncertain tax positions under long-term liabilities as of December 31, 2017 in accordance with the authoritative guidance summarized in the section entitled "Critical Accounting Policies and Estimates" above. As these liabilities do not reflect actual tax assessments, the timing and amount of payments we might be required to make will depend upon a number of factors. Accordingly, as the timing and amount of payment cannot be estimated, $7.1 million in uncertain tax position liabilities have not been included in the table above. See Note 15, Income Taxes, of the Notes to Consolidated Financial Statements included in this annual report. |

[0000926326-18-000010:mdna:174]
| (5) | See Note 10, Commitments and Contingencies, of the Notes to Consolidated Financial Statements included in this annual report. |

[0000926326-18-000010:mdna:175]
Off-Balance Sheet Arrangements

[0000926326-18-000010:mdna:176]
As of December 31, 2017, we had no off-balance sheet arrangements as defined under Regulation S-K 303(a)(4) of the Securities Exchange Act of 1934, as amended, and the instructions thereto.
